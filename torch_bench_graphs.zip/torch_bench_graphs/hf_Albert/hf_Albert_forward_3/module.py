
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/hf_Albert/hf_Albert_forward_3/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7):
        view_default = torch.ops.aten.view.default(primals_7, [4096, 768]);  primals_7 = None
        t_default = torch.ops.aten.t.default(primals_6);  primals_6 = None
        addmm_default = torch.ops.aten.addmm.default(primals_5, view_default, t_default);  primals_5 = None
        view_default_1 = torch.ops.aten.view.default(addmm_default, [8, 512, 128]);  addmm_default = None
        mul_tensor = torch.ops.aten.mul.Tensor(view_default_1, 0.5)
        pow_tensor_scalar = torch.ops.aten.pow.Tensor_Scalar(view_default_1, 3.0)
        mul_tensor_1 = torch.ops.aten.mul.Tensor(pow_tensor_scalar, 0.044715);  pow_tensor_scalar = None
        add_tensor = torch.ops.aten.add.Tensor(view_default_1, mul_tensor_1);  mul_tensor_1 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(add_tensor, 0.7978845608028654);  add_tensor = None
        tanh_default = torch.ops.aten.tanh.default(mul_tensor_2);  mul_tensor_2 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(tanh_default, 1.0)
        mul_tensor_3 = torch.ops.aten.mul.Tensor(mul_tensor, add_tensor_1)
        native_layer_norm_default = torch.ops.aten.native_layer_norm.default(mul_tensor_3, [128], primals_2, primals_1, 1e-05)
        getitem = native_layer_norm_default[0]
        getitem_1 = native_layer_norm_default[1]
        getitem_2 = native_layer_norm_default[2];  native_layer_norm_default = None
        view_default_2 = torch.ops.aten.view.default(getitem, [4096, 128]);  getitem = None
        t_default_1 = torch.ops.aten.t.default(primals_4);  primals_4 = None
        addmm_default_1 = torch.ops.aten.addmm.default(primals_3, view_default_2, t_default_1);  primals_3 = None
        view_default_3 = torch.ops.aten.view.default(addmm_default_1, [8, 512, 30000]);  addmm_default_1 = None
        return [view_default_3, view_default_2, mul_tensor, tanh_default, t_default_1, getitem_1, t_default, getitem_2, view_default, primals_1, primals_2, add_tensor_1, view_default_1, mul_tensor_3]
        
