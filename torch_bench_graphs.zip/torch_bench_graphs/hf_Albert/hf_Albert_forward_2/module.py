
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/hf_Albert/hf_Albert_forward_2/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18):
        view_default = torch.ops.aten.view.default(primals_17, [4096, 768])
        t_default = torch.ops.aten.t.default(primals_8);  primals_8 = None
        addmm_default = torch.ops.aten.addmm.default(primals_7, view_default, t_default);  primals_7 = None
        view_default_1 = torch.ops.aten.view.default(addmm_default, [8, 512, 768]);  addmm_default = None
        view_default_2 = torch.ops.aten.view.default(primals_17, [4096, 768])
        t_default_1 = torch.ops.aten.t.default(primals_6);  primals_6 = None
        addmm_default_1 = torch.ops.aten.addmm.default(primals_5, view_default_2, t_default_1);  primals_5 = None
        view_default_3 = torch.ops.aten.view.default(addmm_default_1, [8, 512, 768]);  addmm_default_1 = None
        view_default_4 = torch.ops.aten.view.default(primals_17, [4096, 768])
        t_default_2 = torch.ops.aten.t.default(primals_10);  primals_10 = None
        addmm_default_2 = torch.ops.aten.addmm.default(primals_9, view_default_4, t_default_2);  primals_9 = None
        view_default_5 = torch.ops.aten.view.default(addmm_default_2, [8, 512, 768]);  addmm_default_2 = None
        view_default_6 = torch.ops.aten.view.default(view_default_1, [8, 512, 12, 64]);  view_default_1 = None
        permute_default = torch.ops.aten.permute.default(view_default_6, [0, 2, 1, 3]);  view_default_6 = None
        view_default_7 = torch.ops.aten.view.default(view_default_3, [8, 512, 12, 64]);  view_default_3 = None
        permute_default_1 = torch.ops.aten.permute.default(view_default_7, [0, 2, 1, 3]);  view_default_7 = None
        view_default_8 = torch.ops.aten.view.default(view_default_5, [8, 512, 12, 64]);  view_default_5 = None
        permute_default_2 = torch.ops.aten.permute.default(view_default_8, [0, 2, 1, 3]);  view_default_8 = None
        transpose_int = torch.ops.aten.transpose.int(permute_default_1, -1, -2);  permute_default_1 = None
        expand_default = torch.ops.aten.expand.default(permute_default, [8, 12, 512, 64]);  permute_default = None
        clone_default = torch.ops.aten.clone.default(expand_default, memory_format = torch.contiguous_format);  expand_default = None
        _unsafe_view_default = torch.ops.aten._unsafe_view.default(clone_default, [96, 512, 64]);  clone_default = None
        expand_default_1 = torch.ops.aten.expand.default(transpose_int, [8, 12, 64, 512]);  transpose_int = None
        clone_default_1 = torch.ops.aten.clone.default(expand_default_1, memory_format = torch.contiguous_format);  expand_default_1 = None
        _unsafe_view_default_1 = torch.ops.aten._unsafe_view.default(clone_default_1, [96, 64, 512]);  clone_default_1 = None
        bmm_default = torch.ops.aten.bmm.default(_unsafe_view_default, _unsafe_view_default_1)
        _unsafe_view_default_2 = torch.ops.aten._unsafe_view.default(bmm_default, [8, 12, 512, 512]);  bmm_default = None
        div_tensor = torch.ops.aten.div.Tensor(_unsafe_view_default_2, 8.0);  _unsafe_view_default_2 = None
        add_tensor = torch.ops.aten.add.Tensor(div_tensor, primals_18);  div_tensor = primals_18 = None
        _softmax_default = torch.ops.aten._softmax.default(add_tensor, -1, False);  add_tensor = None
        expand_default_2 = torch.ops.aten.expand.default(_softmax_default, [8, 12, 512, 512])
        view_default_9 = torch.ops.aten.view.default(expand_default_2, [96, 512, 512]);  expand_default_2 = None
        expand_default_3 = torch.ops.aten.expand.default(permute_default_2, [8, 12, 512, 64]);  permute_default_2 = None
        clone_default_2 = torch.ops.aten.clone.default(expand_default_3, memory_format = torch.contiguous_format);  expand_default_3 = None
        _unsafe_view_default_3 = torch.ops.aten._unsafe_view.default(clone_default_2, [96, 512, 64]);  clone_default_2 = None
        bmm_default_1 = torch.ops.aten.bmm.default(view_default_9, _unsafe_view_default_3)
        _unsafe_view_default_4 = torch.ops.aten._unsafe_view.default(bmm_default_1, [8, 12, 512, 64]);  bmm_default_1 = None
        transpose_int_1 = torch.ops.aten.transpose.int(_unsafe_view_default_4, 2, 1);  _unsafe_view_default_4 = None
        clone_default_3 = torch.ops.aten.clone.default(transpose_int_1, memory_format = torch.contiguous_format);  transpose_int_1 = None
        _unsafe_view_default_5 = torch.ops.aten._unsafe_view.default(clone_default_3, [8, 512, 768]);  clone_default_3 = None
        view_default_10 = torch.ops.aten.view.default(_unsafe_view_default_5, [4096, 768]);  _unsafe_view_default_5 = None
        t_default_3 = torch.ops.aten.t.default(primals_4);  primals_4 = None
        addmm_default_3 = torch.ops.aten.addmm.default(primals_3, view_default_10, t_default_3);  primals_3 = None
        view_default_11 = torch.ops.aten.view.default(addmm_default_3, [8, 512, 768]);  addmm_default_3 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(primals_17, view_default_11);  primals_17 = view_default_11 = None
        native_layer_norm_default = torch.ops.aten.native_layer_norm.default(add_tensor_1, [768], primals_2, primals_1, 1e-12)
        getitem = native_layer_norm_default[0]
        getitem_1 = native_layer_norm_default[1]
        getitem_2 = native_layer_norm_default[2];  native_layer_norm_default = None
        view_default_12 = torch.ops.aten.view.default(getitem, [4096, 768])
        t_default_4 = torch.ops.aten.t.default(primals_12);  primals_12 = None
        addmm_default_4 = torch.ops.aten.addmm.default(primals_11, view_default_12, t_default_4);  primals_11 = None
        view_default_13 = torch.ops.aten.view.default(addmm_default_4, [8, 512, 3072]);  addmm_default_4 = None
        mul_tensor = torch.ops.aten.mul.Tensor(view_default_13, 0.5)
        pow_tensor_scalar = torch.ops.aten.pow.Tensor_Scalar(view_default_13, 3.0)
        mul_tensor_1 = torch.ops.aten.mul.Tensor(pow_tensor_scalar, 0.044715);  pow_tensor_scalar = None
        add_tensor_2 = torch.ops.aten.add.Tensor(view_default_13, mul_tensor_1);  mul_tensor_1 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(add_tensor_2, 0.7978845608028654);  add_tensor_2 = None
        tanh_default = torch.ops.aten.tanh.default(mul_tensor_2);  mul_tensor_2 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(tanh_default, 1.0)
        mul_tensor_3 = torch.ops.aten.mul.Tensor(mul_tensor, add_tensor_3)
        view_default_14 = torch.ops.aten.view.default(mul_tensor_3, [4096, 3072]);  mul_tensor_3 = None
        t_default_5 = torch.ops.aten.t.default(primals_14);  primals_14 = None
        addmm_default_5 = torch.ops.aten.addmm.default(primals_13, view_default_14, t_default_5);  primals_13 = None
        view_default_15 = torch.ops.aten.view.default(addmm_default_5, [8, 512, 768]);  addmm_default_5 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(view_default_15, getitem);  view_default_15 = getitem = None
        native_layer_norm_default_1 = torch.ops.aten.native_layer_norm.default(add_tensor_4, [768], primals_16, primals_15, 1e-12)
        getitem_3 = native_layer_norm_default_1[0]
        getitem_4 = native_layer_norm_default_1[1]
        getitem_5 = native_layer_norm_default_1[2];  native_layer_norm_default_1 = None
        return [getitem_3, add_tensor_1, _softmax_default, add_tensor_3, t_default_2, t_default_3, getitem_4, view_default_10, getitem_5, view_default_4, tanh_default, t_default, view_default, primals_1, view_default_9, primals_2, _unsafe_view_default_1, getitem_1, primals_16, add_tensor_4, getitem_2, view_default_12, _unsafe_view_default_3, view_default_2, t_default_5, mul_tensor, primals_15, t_default_1, view_default_14, _unsafe_view_default, view_default_13, t_default_4]
        
