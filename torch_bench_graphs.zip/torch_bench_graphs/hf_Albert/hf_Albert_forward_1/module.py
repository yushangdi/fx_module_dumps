
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/hf_Albert/hf_Albert_forward_1/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3):
        view_default = torch.ops.aten.view.default(primals_3, [4096, 128]);  primals_3 = None
        t_default = torch.ops.aten.t.default(primals_2);  primals_2 = None
        addmm_default = torch.ops.aten.addmm.default(primals_1, view_default, t_default);  primals_1 = None
        view_default_1 = torch.ops.aten.view.default(addmm_default, [8, 512, 768]);  addmm_default = None
        return [view_default_1, t_default, view_default]
        
