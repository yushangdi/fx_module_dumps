
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/timm_vovnet/timm_vovnet_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198):
        convolution_default = torch.ops.aten.convolution.default(primals_198, primals_187, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_186, primals_183, primals_184, primals_185, False, 0.1, 1e-05);  primals_183 = None
        getitem = native_batch_norm_default[0];  native_batch_norm_default = None
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default, primals_192, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_191, primals_188, primals_189, primals_190, False, 0.1, 1e-05);  primals_188 = None
        getitem_3 = native_batch_norm_default_1[0];  native_batch_norm_default_1 = None
        relu__default_1 = torch.ops.aten.relu_.default(getitem_3);  getitem_3 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_197, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_196, primals_193, primals_194, primals_195, False, 0.1, 1e-05);  primals_193 = None
        getitem_6 = native_batch_norm_default_2[0];  native_batch_norm_default_2 = None
        relu__default_2 = torch.ops.aten.relu_.default(getitem_6);  getitem_6 = None
        convolution_default_3 = torch.ops.aten.convolution.default(relu__default_2, primals_12, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_11, primals_8, primals_9, primals_10, False, 0.1, 1e-05);  primals_8 = None
        getitem_9 = native_batch_norm_default_3[0];  native_batch_norm_default_3 = None
        relu__default_3 = torch.ops.aten.relu_.default(getitem_9);  getitem_9 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu__default_3, primals_17, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_16, primals_13, primals_14, primals_15, False, 0.1, 1e-05);  primals_13 = None
        getitem_12 = native_batch_norm_default_4[0];  native_batch_norm_default_4 = None
        relu__default_4 = torch.ops.aten.relu_.default(getitem_12);  getitem_12 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_4, primals_22, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_21, primals_18, primals_19, primals_20, False, 0.1, 1e-05);  primals_18 = None
        getitem_15 = native_batch_norm_default_5[0];  native_batch_norm_default_5 = None
        relu__default_5 = torch.ops.aten.relu_.default(getitem_15);  getitem_15 = None
        convolution_default_6 = torch.ops.aten.convolution.default(relu__default_5, primals_27, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_26, primals_23, primals_24, primals_25, False, 0.1, 1e-05);  primals_23 = None
        getitem_18 = native_batch_norm_default_6[0];  native_batch_norm_default_6 = None
        relu__default_6 = torch.ops.aten.relu_.default(getitem_18);  getitem_18 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_6, primals_32, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_31, primals_28, primals_29, primals_30, False, 0.1, 1e-05);  primals_28 = None
        getitem_21 = native_batch_norm_default_7[0];  native_batch_norm_default_7 = None
        relu__default_7 = torch.ops.aten.relu_.default(getitem_21);  getitem_21 = None
        cat_default = torch.ops.aten.cat.default([relu__default_2, relu__default_3, relu__default_4, relu__default_5, relu__default_6, relu__default_7], 1)
        convolution_default_8 = torch.ops.aten.convolution.default(cat_default, primals_7, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_6, primals_3, primals_4, primals_5, False, 0.1, 1e-05);  primals_3 = None
        getitem_24 = native_batch_norm_default_8[0];  native_batch_norm_default_8 = None
        relu__default_8 = torch.ops.aten.relu_.default(getitem_24);  getitem_24 = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu__default_8, [3, 3], [2, 2], [0, 0], [1, 1], True)
        getitem_27 = max_pool2d_with_indices_default[0]
        getitem_28 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_9 = torch.ops.aten.convolution.default(getitem_27, primals_42, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_41, primals_38, primals_39, primals_40, False, 0.1, 1e-05);  primals_38 = None
        getitem_29 = native_batch_norm_default_9[0];  native_batch_norm_default_9 = None
        relu__default_9 = torch.ops.aten.relu_.default(getitem_29);  getitem_29 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default_9, primals_47, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_46, primals_43, primals_44, primals_45, False, 0.1, 1e-05);  primals_43 = None
        getitem_32 = native_batch_norm_default_10[0];  native_batch_norm_default_10 = None
        relu__default_10 = torch.ops.aten.relu_.default(getitem_32);  getitem_32 = None
        convolution_default_11 = torch.ops.aten.convolution.default(relu__default_10, primals_52, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_51, primals_48, primals_49, primals_50, False, 0.1, 1e-05);  primals_48 = None
        getitem_35 = native_batch_norm_default_11[0];  native_batch_norm_default_11 = None
        relu__default_11 = torch.ops.aten.relu_.default(getitem_35);  getitem_35 = None
        convolution_default_12 = torch.ops.aten.convolution.default(relu__default_11, primals_57, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_56, primals_53, primals_54, primals_55, False, 0.1, 1e-05);  primals_53 = None
        getitem_38 = native_batch_norm_default_12[0];  native_batch_norm_default_12 = None
        relu__default_12 = torch.ops.aten.relu_.default(getitem_38);  getitem_38 = None
        convolution_default_13 = torch.ops.aten.convolution.default(relu__default_12, primals_62, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_61, primals_58, primals_59, primals_60, False, 0.1, 1e-05);  primals_58 = None
        getitem_41 = native_batch_norm_default_13[0];  native_batch_norm_default_13 = None
        relu__default_13 = torch.ops.aten.relu_.default(getitem_41);  getitem_41 = None
        cat_default_1 = torch.ops.aten.cat.default([getitem_27, relu__default_9, relu__default_10, relu__default_11, relu__default_12, relu__default_13], 1)
        convolution_default_14 = torch.ops.aten.convolution.default(cat_default_1, primals_37, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_36, primals_33, primals_34, primals_35, False, 0.1, 1e-05);  primals_33 = None
        getitem_44 = native_batch_norm_default_14[0];  native_batch_norm_default_14 = None
        relu__default_14 = torch.ops.aten.relu_.default(getitem_44);  getitem_44 = None
        max_pool2d_with_indices_default_1 = torch.ops.aten.max_pool2d_with_indices.default(relu__default_14, [3, 3], [2, 2], [0, 0], [1, 1], True)
        getitem_47 = max_pool2d_with_indices_default_1[0]
        getitem_48 = max_pool2d_with_indices_default_1[1];  max_pool2d_with_indices_default_1 = None
        convolution_default_15 = torch.ops.aten.convolution.default(getitem_47, primals_72, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_71, primals_68, primals_69, primals_70, False, 0.1, 1e-05);  primals_68 = None
        getitem_49 = native_batch_norm_default_15[0];  native_batch_norm_default_15 = None
        relu__default_15 = torch.ops.aten.relu_.default(getitem_49);  getitem_49 = None
        convolution_default_16 = torch.ops.aten.convolution.default(relu__default_15, primals_77, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_76, primals_73, primals_74, primals_75, False, 0.1, 1e-05);  primals_73 = None
        getitem_52 = native_batch_norm_default_16[0];  native_batch_norm_default_16 = None
        relu__default_16 = torch.ops.aten.relu_.default(getitem_52);  getitem_52 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu__default_16, primals_82, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_81, primals_78, primals_79, primals_80, False, 0.1, 1e-05);  primals_78 = None
        getitem_55 = native_batch_norm_default_17[0];  native_batch_norm_default_17 = None
        relu__default_17 = torch.ops.aten.relu_.default(getitem_55);  getitem_55 = None
        convolution_default_18 = torch.ops.aten.convolution.default(relu__default_17, primals_87, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_86, primals_83, primals_84, primals_85, False, 0.1, 1e-05);  primals_83 = None
        getitem_58 = native_batch_norm_default_18[0];  native_batch_norm_default_18 = None
        relu__default_18 = torch.ops.aten.relu_.default(getitem_58);  getitem_58 = None
        convolution_default_19 = torch.ops.aten.convolution.default(relu__default_18, primals_92, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_91, primals_88, primals_89, primals_90, False, 0.1, 1e-05);  primals_88 = None
        getitem_61 = native_batch_norm_default_19[0];  native_batch_norm_default_19 = None
        relu__default_19 = torch.ops.aten.relu_.default(getitem_61);  getitem_61 = None
        cat_default_2 = torch.ops.aten.cat.default([getitem_47, relu__default_15, relu__default_16, relu__default_17, relu__default_18, relu__default_19], 1)
        convolution_default_20 = torch.ops.aten.convolution.default(cat_default_2, primals_67, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_66, primals_63, primals_64, primals_65, False, 0.1, 1e-05);  primals_63 = None
        getitem_64 = native_batch_norm_default_20[0];  native_batch_norm_default_20 = None
        relu__default_20 = torch.ops.aten.relu_.default(getitem_64);  getitem_64 = None
        convolution_default_21 = torch.ops.aten.convolution.default(relu__default_20, primals_102, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_101, primals_98, primals_99, primals_100, False, 0.1, 1e-05);  primals_98 = None
        getitem_67 = native_batch_norm_default_21[0];  native_batch_norm_default_21 = None
        relu__default_21 = torch.ops.aten.relu_.default(getitem_67);  getitem_67 = None
        convolution_default_22 = torch.ops.aten.convolution.default(relu__default_21, primals_107, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_106, primals_103, primals_104, primals_105, False, 0.1, 1e-05);  primals_103 = None
        getitem_70 = native_batch_norm_default_22[0];  native_batch_norm_default_22 = None
        relu__default_22 = torch.ops.aten.relu_.default(getitem_70);  getitem_70 = None
        convolution_default_23 = torch.ops.aten.convolution.default(relu__default_22, primals_112, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_111, primals_108, primals_109, primals_110, False, 0.1, 1e-05);  primals_108 = None
        getitem_73 = native_batch_norm_default_23[0];  native_batch_norm_default_23 = None
        relu__default_23 = torch.ops.aten.relu_.default(getitem_73);  getitem_73 = None
        convolution_default_24 = torch.ops.aten.convolution.default(relu__default_23, primals_117, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_116, primals_113, primals_114, primals_115, False, 0.1, 1e-05);  primals_113 = None
        getitem_76 = native_batch_norm_default_24[0];  native_batch_norm_default_24 = None
        relu__default_24 = torch.ops.aten.relu_.default(getitem_76);  getitem_76 = None
        convolution_default_25 = torch.ops.aten.convolution.default(relu__default_24, primals_122, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_121, primals_118, primals_119, primals_120, False, 0.1, 1e-05);  primals_118 = None
        getitem_79 = native_batch_norm_default_25[0];  native_batch_norm_default_25 = None
        relu__default_25 = torch.ops.aten.relu_.default(getitem_79);  getitem_79 = None
        cat_default_3 = torch.ops.aten.cat.default([relu__default_20, relu__default_21, relu__default_22, relu__default_23, relu__default_24, relu__default_25], 1)
        convolution_default_26 = torch.ops.aten.convolution.default(cat_default_3, primals_97, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_96, primals_93, primals_94, primals_95, False, 0.1, 1e-05);  primals_93 = None
        getitem_82 = native_batch_norm_default_26[0];  native_batch_norm_default_26 = None
        relu__default_26 = torch.ops.aten.relu_.default(getitem_82);  getitem_82 = None
        max_pool2d_with_indices_default_2 = torch.ops.aten.max_pool2d_with_indices.default(relu__default_26, [3, 3], [2, 2], [0, 0], [1, 1], True)
        getitem_85 = max_pool2d_with_indices_default_2[0]
        getitem_86 = max_pool2d_with_indices_default_2[1];  max_pool2d_with_indices_default_2 = None
        convolution_default_27 = torch.ops.aten.convolution.default(getitem_85, primals_132, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_131, primals_128, primals_129, primals_130, False, 0.1, 1e-05);  primals_128 = None
        getitem_87 = native_batch_norm_default_27[0];  native_batch_norm_default_27 = None
        relu__default_27 = torch.ops.aten.relu_.default(getitem_87);  getitem_87 = None
        convolution_default_28 = torch.ops.aten.convolution.default(relu__default_27, primals_137, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_136, primals_133, primals_134, primals_135, False, 0.1, 1e-05);  primals_133 = None
        getitem_90 = native_batch_norm_default_28[0];  native_batch_norm_default_28 = None
        relu__default_28 = torch.ops.aten.relu_.default(getitem_90);  getitem_90 = None
        convolution_default_29 = torch.ops.aten.convolution.default(relu__default_28, primals_142, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_141, primals_138, primals_139, primals_140, False, 0.1, 1e-05);  primals_138 = None
        getitem_93 = native_batch_norm_default_29[0];  native_batch_norm_default_29 = None
        relu__default_29 = torch.ops.aten.relu_.default(getitem_93);  getitem_93 = None
        convolution_default_30 = torch.ops.aten.convolution.default(relu__default_29, primals_147, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_146, primals_143, primals_144, primals_145, False, 0.1, 1e-05);  primals_143 = None
        getitem_96 = native_batch_norm_default_30[0];  native_batch_norm_default_30 = None
        relu__default_30 = torch.ops.aten.relu_.default(getitem_96);  getitem_96 = None
        convolution_default_31 = torch.ops.aten.convolution.default(relu__default_30, primals_152, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_31, primals_151, primals_148, primals_149, primals_150, False, 0.1, 1e-05);  primals_148 = None
        getitem_99 = native_batch_norm_default_31[0];  native_batch_norm_default_31 = None
        relu__default_31 = torch.ops.aten.relu_.default(getitem_99);  getitem_99 = None
        cat_default_4 = torch.ops.aten.cat.default([getitem_85, relu__default_27, relu__default_28, relu__default_29, relu__default_30, relu__default_31], 1)
        convolution_default_32 = torch.ops.aten.convolution.default(cat_default_4, primals_127, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_126, primals_123, primals_124, primals_125, False, 0.1, 1e-05);  primals_123 = None
        getitem_102 = native_batch_norm_default_32[0];  native_batch_norm_default_32 = None
        relu__default_32 = torch.ops.aten.relu_.default(getitem_102);  getitem_102 = None
        convolution_default_33 = torch.ops.aten.convolution.default(relu__default_32, primals_162, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_161, primals_158, primals_159, primals_160, False, 0.1, 1e-05);  primals_158 = None
        getitem_105 = native_batch_norm_default_33[0];  native_batch_norm_default_33 = None
        relu__default_33 = torch.ops.aten.relu_.default(getitem_105);  getitem_105 = None
        convolution_default_34 = torch.ops.aten.convolution.default(relu__default_33, primals_167, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_166, primals_163, primals_164, primals_165, False, 0.1, 1e-05);  primals_163 = None
        getitem_108 = native_batch_norm_default_34[0];  native_batch_norm_default_34 = None
        relu__default_34 = torch.ops.aten.relu_.default(getitem_108);  getitem_108 = None
        convolution_default_35 = torch.ops.aten.convolution.default(relu__default_34, primals_172, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_171, primals_168, primals_169, primals_170, False, 0.1, 1e-05);  primals_168 = None
        getitem_111 = native_batch_norm_default_35[0];  native_batch_norm_default_35 = None
        relu__default_35 = torch.ops.aten.relu_.default(getitem_111);  getitem_111 = None
        convolution_default_36 = torch.ops.aten.convolution.default(relu__default_35, primals_177, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_176, primals_173, primals_174, primals_175, False, 0.1, 1e-05);  primals_173 = None
        getitem_114 = native_batch_norm_default_36[0];  native_batch_norm_default_36 = None
        relu__default_36 = torch.ops.aten.relu_.default(getitem_114);  getitem_114 = None
        convolution_default_37 = torch.ops.aten.convolution.default(relu__default_36, primals_182, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_37, primals_181, primals_178, primals_179, primals_180, False, 0.1, 1e-05);  primals_178 = None
        getitem_117 = native_batch_norm_default_37[0];  native_batch_norm_default_37 = None
        relu__default_37 = torch.ops.aten.relu_.default(getitem_117);  getitem_117 = None
        cat_default_5 = torch.ops.aten.cat.default([relu__default_32, relu__default_33, relu__default_34, relu__default_35, relu__default_36, relu__default_37], 1)
        convolution_default_38 = torch.ops.aten.convolution.default(cat_default_5, primals_157, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_156, primals_153, primals_154, primals_155, False, 0.1, 1e-05);  primals_153 = None
        getitem_120 = native_batch_norm_default_38[0];  native_batch_norm_default_38 = None
        relu__default_38 = torch.ops.aten.relu_.default(getitem_120);  getitem_120 = None
        mean_dim = torch.ops.aten.mean.dim(relu__default_38, [-1, -2], True)
        view_default = torch.ops.aten.view.default(mean_dim, [32, 1024]);  mean_dim = None
        t_default = torch.ops.aten.t.default(primals_2);  primals_2 = None
        addmm_default = torch.ops.aten.addmm.default(primals_1, view_default, t_default);  primals_1 = None
        return [addmm_default, primals_107, primals_10, primals_75, primals_14, primals_74, primals_21, primals_106, primals_15, primals_109, primals_81, primals_7, primals_80, primals_25, primals_100, primals_71, primals_72, primals_24, primals_17, primals_101, primals_16, primals_29, primals_26, primals_77, primals_19, primals_104, primals_9, primals_79, primals_102, primals_110, primals_76, primals_99, relu__default_4, primals_12, primals_105, primals_27, primals_11, primals_82, primals_22, primals_20, convolution_default_5, primals_4, convolution_default_30, convolution_default_12, relu__default_11, convolution_default_20, primals_164, convolution_default_21, relu__default_21, convolution_default_17, primals_156, cat_default_3, relu__default_20, primals_155, cat_default_2, getitem_85, convolution_default_29, relu__default_10, getitem_86, primals_159, relu__default_16, relu__default_27, relu__default_28, relu__default_26, convolution_default_19, primals_162, relu__default_29, primals_160, primals_5, primals_165, convolution_default_11, convolution_default_28, relu__default_18, convolution_default_22, primals_161, primals_6, primals_157, convolution_default_27, primals_154, relu__default_19, relu__default_6, relu__default_12, getitem_47, convolution_default_16, convolution_default_9, cat_default, getitem_48, convolution_default_7, primals_189, primals_185, convolution_default_4, primals_186, primals_196, primals_181, relu__default_17, primals_197, relu__default_30, primals_187, primals_195, convolution_default_31, primals_184, primals_191, primals_198, primals_190, primals_182, primals_192, cat_default_4, convolution_default_32, relu__default_31, convolution_default_18, convolution_default_3, relu__default_3, primals_194, primals_180, relu__default_2, primals_149, relu__default_38, primals_61, primals_90, primals_151, primals_96, primals_152, relu__default_15, primals_142, view_default, primals_146, primals_95, primals_141, primals_64, primals_85, convolution_default_15, primals_139, primals_62, primals_57, primals_87, primals_86, primals_70, primals_84, convolution_default_14, cat_default_1, primals_94, primals_144, primals_145, primals_67, primals_66, primals_69, primals_147, primals_65, primals_92, primals_150, primals_56, primals_89, t_default, primals_60, convolution_default_13, primals_140, relu__default_13, primals_91, primals_59, primals_97, relu__default_14, relu__default_1, primals_136, convolution_default_25, primals_131, primals_129, primals_126, relu__default_25, convolution_default_35, primals_130, convolution_default_24, convolution_default_36, convolution_default_1, relu__default_24, relu__default_34, relu__default_22, relu__default_23, primals_134, relu__default_35, convolution_default_26, getitem_27, convolution_default_2, primals_135, relu__default, primals_127, primals_137, primals_125, relu__default_8, getitem_28, primals_132, convolution_default_23, convolution_default, convolution_default_38, relu__default_36, cat_default_5, primals_47, primals_51, primals_50, primals_54, relu__default_7, relu__default_37, primals_49, primals_52, convolution_default_8, primals_55, convolution_default_37, primals_114, primals_179, convolution_default_34, primals_169, convolution_default_6, primals_112, primals_175, primals_170, primals_36, primals_167, primals_32, primals_120, primals_111, relu__default_33, primals_30, primals_44, primals_177, primals_45, primals_171, primals_39, primals_172, relu__default_32, primals_166, primals_37, primals_41, primals_31, primals_117, primals_119, primals_40, primals_34, primals_124, primals_116, primals_46, primals_176, primals_122, primals_174, relu__default_9, primals_35, primals_42, primals_121, relu__default_5, convolution_default_10, primals_115, convolution_default_33]
        
