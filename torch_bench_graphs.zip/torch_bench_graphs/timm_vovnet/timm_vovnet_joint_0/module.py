
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/timm_vovnet/timm_vovnet_joint_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, tangents_1):
        convolution_default = torch.ops.aten.convolution.default(primals_198, primals_187, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_186, primals_183, primals_184, primals_185, False, 0.1, 1e-05);  primals_183 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        new_zeros_default = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_2 = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default, primals_192, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_191, primals_188, primals_189, primals_190, False, 0.1, 1e-05);  primals_188 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_5 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_1 = torch.ops.aten.relu_.default(getitem_3);  getitem_3 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_197, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_196, primals_193, primals_194, primals_195, False, 0.1, 1e-05);  primals_193 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_8 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_2 = torch.ops.aten.relu_.default(getitem_6);  getitem_6 = None
        convolution_default_3 = torch.ops.aten.convolution.default(relu__default_2, primals_12, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_11, primals_8, primals_9, primals_10, False, 0.1, 1e-05);  primals_8 = None
        getitem_9 = native_batch_norm_default_3[0]
        getitem_10 = native_batch_norm_default_3[1]
        getitem_11 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        new_zeros_default_9 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_10 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_11 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_3 = torch.ops.aten.relu_.default(getitem_9);  getitem_9 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu__default_3, primals_17, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_16, primals_13, primals_14, primals_15, False, 0.1, 1e-05);  primals_13 = None
        getitem_12 = native_batch_norm_default_4[0]
        getitem_13 = native_batch_norm_default_4[1]
        getitem_14 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        new_zeros_default_12 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_13 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_14 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_4 = torch.ops.aten.relu_.default(getitem_12);  getitem_12 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_4, primals_22, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_21, primals_18, primals_19, primals_20, False, 0.1, 1e-05);  primals_18 = None
        getitem_15 = native_batch_norm_default_5[0]
        getitem_16 = native_batch_norm_default_5[1]
        getitem_17 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        new_zeros_default_15 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_16 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_17 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_5 = torch.ops.aten.relu_.default(getitem_15);  getitem_15 = None
        convolution_default_6 = torch.ops.aten.convolution.default(relu__default_5, primals_27, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_26, primals_23, primals_24, primals_25, False, 0.1, 1e-05);  primals_23 = None
        getitem_18 = native_batch_norm_default_6[0]
        getitem_19 = native_batch_norm_default_6[1]
        getitem_20 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        new_zeros_default_18 = torch.ops.aten.new_zeros.default(convolution_default_6, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_19 = torch.ops.aten.new_zeros.default(convolution_default_6, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_20 = torch.ops.aten.new_zeros.default(convolution_default_6, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_6 = torch.ops.aten.relu_.default(getitem_18);  getitem_18 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_6, primals_32, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_31, primals_28, primals_29, primals_30, False, 0.1, 1e-05);  primals_28 = None
        getitem_21 = native_batch_norm_default_7[0]
        getitem_22 = native_batch_norm_default_7[1]
        getitem_23 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        new_zeros_default_21 = torch.ops.aten.new_zeros.default(convolution_default_7, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_22 = torch.ops.aten.new_zeros.default(convolution_default_7, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_23 = torch.ops.aten.new_zeros.default(convolution_default_7, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_7 = torch.ops.aten.relu_.default(getitem_21);  getitem_21 = None
        cat_default = torch.ops.aten.cat.default([relu__default_2, relu__default_3, relu__default_4, relu__default_5, relu__default_6, relu__default_7], 1)
        convolution_default_8 = torch.ops.aten.convolution.default(cat_default, primals_7, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_6, primals_3, primals_4, primals_5, False, 0.1, 1e-05);  primals_3 = None
        getitem_24 = native_batch_norm_default_8[0]
        getitem_25 = native_batch_norm_default_8[1]
        getitem_26 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        new_zeros_default_24 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_25 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_26 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_8 = torch.ops.aten.relu_.default(getitem_24);  getitem_24 = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu__default_8, [3, 3], [2, 2], [0, 0], [1, 1], True)
        getitem_27 = max_pool2d_with_indices_default[0]
        getitem_28 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_9 = torch.ops.aten.convolution.default(getitem_27, primals_42, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_41, primals_38, primals_39, primals_40, False, 0.1, 1e-05);  primals_38 = None
        getitem_29 = native_batch_norm_default_9[0]
        getitem_30 = native_batch_norm_default_9[1]
        getitem_31 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        new_zeros_default_27 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_28 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_29 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_9 = torch.ops.aten.relu_.default(getitem_29);  getitem_29 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default_9, primals_47, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_46, primals_43, primals_44, primals_45, False, 0.1, 1e-05);  primals_43 = None
        getitem_32 = native_batch_norm_default_10[0]
        getitem_33 = native_batch_norm_default_10[1]
        getitem_34 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        new_zeros_default_30 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_31 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_32 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_10 = torch.ops.aten.relu_.default(getitem_32);  getitem_32 = None
        convolution_default_11 = torch.ops.aten.convolution.default(relu__default_10, primals_52, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_51, primals_48, primals_49, primals_50, False, 0.1, 1e-05);  primals_48 = None
        getitem_35 = native_batch_norm_default_11[0]
        getitem_36 = native_batch_norm_default_11[1]
        getitem_37 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        new_zeros_default_33 = torch.ops.aten.new_zeros.default(convolution_default_11, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_34 = torch.ops.aten.new_zeros.default(convolution_default_11, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_35 = torch.ops.aten.new_zeros.default(convolution_default_11, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_11 = torch.ops.aten.relu_.default(getitem_35);  getitem_35 = None
        convolution_default_12 = torch.ops.aten.convolution.default(relu__default_11, primals_57, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_56, primals_53, primals_54, primals_55, False, 0.1, 1e-05);  primals_53 = None
        getitem_38 = native_batch_norm_default_12[0]
        getitem_39 = native_batch_norm_default_12[1]
        getitem_40 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        new_zeros_default_36 = torch.ops.aten.new_zeros.default(convolution_default_12, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_37 = torch.ops.aten.new_zeros.default(convolution_default_12, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_38 = torch.ops.aten.new_zeros.default(convolution_default_12, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_12 = torch.ops.aten.relu_.default(getitem_38);  getitem_38 = None
        convolution_default_13 = torch.ops.aten.convolution.default(relu__default_12, primals_62, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_61, primals_58, primals_59, primals_60, False, 0.1, 1e-05);  primals_58 = None
        getitem_41 = native_batch_norm_default_13[0]
        getitem_42 = native_batch_norm_default_13[1]
        getitem_43 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        new_zeros_default_39 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_40 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_41 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_13 = torch.ops.aten.relu_.default(getitem_41);  getitem_41 = None
        cat_default_1 = torch.ops.aten.cat.default([getitem_27, relu__default_9, relu__default_10, relu__default_11, relu__default_12, relu__default_13], 1)
        convolution_default_14 = torch.ops.aten.convolution.default(cat_default_1, primals_37, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_36, primals_33, primals_34, primals_35, False, 0.1, 1e-05);  primals_33 = None
        getitem_44 = native_batch_norm_default_14[0]
        getitem_45 = native_batch_norm_default_14[1]
        getitem_46 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        new_zeros_default_42 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_43 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_44 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_14 = torch.ops.aten.relu_.default(getitem_44);  getitem_44 = None
        max_pool2d_with_indices_default_1 = torch.ops.aten.max_pool2d_with_indices.default(relu__default_14, [3, 3], [2, 2], [0, 0], [1, 1], True)
        getitem_47 = max_pool2d_with_indices_default_1[0]
        getitem_48 = max_pool2d_with_indices_default_1[1];  max_pool2d_with_indices_default_1 = None
        convolution_default_15 = torch.ops.aten.convolution.default(getitem_47, primals_72, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_71, primals_68, primals_69, primals_70, False, 0.1, 1e-05);  primals_68 = None
        getitem_49 = native_batch_norm_default_15[0]
        getitem_50 = native_batch_norm_default_15[1]
        getitem_51 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        new_zeros_default_45 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_46 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_47 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_15 = torch.ops.aten.relu_.default(getitem_49);  getitem_49 = None
        convolution_default_16 = torch.ops.aten.convolution.default(relu__default_15, primals_77, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_76, primals_73, primals_74, primals_75, False, 0.1, 1e-05);  primals_73 = None
        getitem_52 = native_batch_norm_default_16[0]
        getitem_53 = native_batch_norm_default_16[1]
        getitem_54 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        new_zeros_default_48 = torch.ops.aten.new_zeros.default(convolution_default_16, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_49 = torch.ops.aten.new_zeros.default(convolution_default_16, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_50 = torch.ops.aten.new_zeros.default(convolution_default_16, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_16 = torch.ops.aten.relu_.default(getitem_52);  getitem_52 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu__default_16, primals_82, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_81, primals_78, primals_79, primals_80, False, 0.1, 1e-05);  primals_78 = None
        getitem_55 = native_batch_norm_default_17[0]
        getitem_56 = native_batch_norm_default_17[1]
        getitem_57 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        new_zeros_default_51 = torch.ops.aten.new_zeros.default(convolution_default_17, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_52 = torch.ops.aten.new_zeros.default(convolution_default_17, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_53 = torch.ops.aten.new_zeros.default(convolution_default_17, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_17 = torch.ops.aten.relu_.default(getitem_55);  getitem_55 = None
        convolution_default_18 = torch.ops.aten.convolution.default(relu__default_17, primals_87, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_86, primals_83, primals_84, primals_85, False, 0.1, 1e-05);  primals_83 = None
        getitem_58 = native_batch_norm_default_18[0]
        getitem_59 = native_batch_norm_default_18[1]
        getitem_60 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        new_zeros_default_54 = torch.ops.aten.new_zeros.default(convolution_default_18, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_55 = torch.ops.aten.new_zeros.default(convolution_default_18, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_56 = torch.ops.aten.new_zeros.default(convolution_default_18, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_18 = torch.ops.aten.relu_.default(getitem_58);  getitem_58 = None
        convolution_default_19 = torch.ops.aten.convolution.default(relu__default_18, primals_92, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_91, primals_88, primals_89, primals_90, False, 0.1, 1e-05);  primals_88 = None
        getitem_61 = native_batch_norm_default_19[0]
        getitem_62 = native_batch_norm_default_19[1]
        getitem_63 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        new_zeros_default_57 = torch.ops.aten.new_zeros.default(convolution_default_19, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_58 = torch.ops.aten.new_zeros.default(convolution_default_19, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_59 = torch.ops.aten.new_zeros.default(convolution_default_19, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_19 = torch.ops.aten.relu_.default(getitem_61);  getitem_61 = None
        cat_default_2 = torch.ops.aten.cat.default([getitem_47, relu__default_15, relu__default_16, relu__default_17, relu__default_18, relu__default_19], 1)
        convolution_default_20 = torch.ops.aten.convolution.default(cat_default_2, primals_67, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_66, primals_63, primals_64, primals_65, False, 0.1, 1e-05);  primals_63 = None
        getitem_64 = native_batch_norm_default_20[0]
        getitem_65 = native_batch_norm_default_20[1]
        getitem_66 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        new_zeros_default_60 = torch.ops.aten.new_zeros.default(convolution_default_20, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_61 = torch.ops.aten.new_zeros.default(convolution_default_20, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_62 = torch.ops.aten.new_zeros.default(convolution_default_20, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_20 = torch.ops.aten.relu_.default(getitem_64);  getitem_64 = None
        convolution_default_21 = torch.ops.aten.convolution.default(relu__default_20, primals_102, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_101, primals_98, primals_99, primals_100, False, 0.1, 1e-05);  primals_98 = None
        getitem_67 = native_batch_norm_default_21[0]
        getitem_68 = native_batch_norm_default_21[1]
        getitem_69 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        new_zeros_default_63 = torch.ops.aten.new_zeros.default(convolution_default_21, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_64 = torch.ops.aten.new_zeros.default(convolution_default_21, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_65 = torch.ops.aten.new_zeros.default(convolution_default_21, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_21 = torch.ops.aten.relu_.default(getitem_67);  getitem_67 = None
        convolution_default_22 = torch.ops.aten.convolution.default(relu__default_21, primals_107, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_106, primals_103, primals_104, primals_105, False, 0.1, 1e-05);  primals_103 = None
        getitem_70 = native_batch_norm_default_22[0]
        getitem_71 = native_batch_norm_default_22[1]
        getitem_72 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        new_zeros_default_66 = torch.ops.aten.new_zeros.default(convolution_default_22, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_67 = torch.ops.aten.new_zeros.default(convolution_default_22, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_68 = torch.ops.aten.new_zeros.default(convolution_default_22, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_22 = torch.ops.aten.relu_.default(getitem_70);  getitem_70 = None
        convolution_default_23 = torch.ops.aten.convolution.default(relu__default_22, primals_112, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_111, primals_108, primals_109, primals_110, False, 0.1, 1e-05);  primals_108 = None
        getitem_73 = native_batch_norm_default_23[0]
        getitem_74 = native_batch_norm_default_23[1]
        getitem_75 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        new_zeros_default_69 = torch.ops.aten.new_zeros.default(convolution_default_23, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_70 = torch.ops.aten.new_zeros.default(convolution_default_23, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_71 = torch.ops.aten.new_zeros.default(convolution_default_23, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_23 = torch.ops.aten.relu_.default(getitem_73);  getitem_73 = None
        convolution_default_24 = torch.ops.aten.convolution.default(relu__default_23, primals_117, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_116, primals_113, primals_114, primals_115, False, 0.1, 1e-05);  primals_113 = None
        getitem_76 = native_batch_norm_default_24[0]
        getitem_77 = native_batch_norm_default_24[1]
        getitem_78 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        new_zeros_default_72 = torch.ops.aten.new_zeros.default(convolution_default_24, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_73 = torch.ops.aten.new_zeros.default(convolution_default_24, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_74 = torch.ops.aten.new_zeros.default(convolution_default_24, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_24 = torch.ops.aten.relu_.default(getitem_76);  getitem_76 = None
        convolution_default_25 = torch.ops.aten.convolution.default(relu__default_24, primals_122, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_121, primals_118, primals_119, primals_120, False, 0.1, 1e-05);  primals_118 = None
        getitem_79 = native_batch_norm_default_25[0]
        getitem_80 = native_batch_norm_default_25[1]
        getitem_81 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        new_zeros_default_75 = torch.ops.aten.new_zeros.default(convolution_default_25, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_76 = torch.ops.aten.new_zeros.default(convolution_default_25, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_77 = torch.ops.aten.new_zeros.default(convolution_default_25, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_25 = torch.ops.aten.relu_.default(getitem_79);  getitem_79 = None
        cat_default_3 = torch.ops.aten.cat.default([relu__default_20, relu__default_21, relu__default_22, relu__default_23, relu__default_24, relu__default_25], 1)
        convolution_default_26 = torch.ops.aten.convolution.default(cat_default_3, primals_97, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_96, primals_93, primals_94, primals_95, False, 0.1, 1e-05);  primals_93 = None
        getitem_82 = native_batch_norm_default_26[0]
        getitem_83 = native_batch_norm_default_26[1]
        getitem_84 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        new_zeros_default_78 = torch.ops.aten.new_zeros.default(convolution_default_26, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_79 = torch.ops.aten.new_zeros.default(convolution_default_26, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_80 = torch.ops.aten.new_zeros.default(convolution_default_26, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_26 = torch.ops.aten.relu_.default(getitem_82);  getitem_82 = None
        max_pool2d_with_indices_default_2 = torch.ops.aten.max_pool2d_with_indices.default(relu__default_26, [3, 3], [2, 2], [0, 0], [1, 1], True)
        getitem_85 = max_pool2d_with_indices_default_2[0]
        getitem_86 = max_pool2d_with_indices_default_2[1];  max_pool2d_with_indices_default_2 = None
        convolution_default_27 = torch.ops.aten.convolution.default(getitem_85, primals_132, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_131, primals_128, primals_129, primals_130, False, 0.1, 1e-05);  primals_128 = None
        getitem_87 = native_batch_norm_default_27[0]
        getitem_88 = native_batch_norm_default_27[1]
        getitem_89 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        new_zeros_default_81 = torch.ops.aten.new_zeros.default(convolution_default_27, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_82 = torch.ops.aten.new_zeros.default(convolution_default_27, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_83 = torch.ops.aten.new_zeros.default(convolution_default_27, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_27 = torch.ops.aten.relu_.default(getitem_87);  getitem_87 = None
        convolution_default_28 = torch.ops.aten.convolution.default(relu__default_27, primals_137, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_136, primals_133, primals_134, primals_135, False, 0.1, 1e-05);  primals_133 = None
        getitem_90 = native_batch_norm_default_28[0]
        getitem_91 = native_batch_norm_default_28[1]
        getitem_92 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        new_zeros_default_84 = torch.ops.aten.new_zeros.default(convolution_default_28, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_85 = torch.ops.aten.new_zeros.default(convolution_default_28, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_86 = torch.ops.aten.new_zeros.default(convolution_default_28, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_28 = torch.ops.aten.relu_.default(getitem_90);  getitem_90 = None
        convolution_default_29 = torch.ops.aten.convolution.default(relu__default_28, primals_142, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_141, primals_138, primals_139, primals_140, False, 0.1, 1e-05);  primals_138 = None
        getitem_93 = native_batch_norm_default_29[0]
        getitem_94 = native_batch_norm_default_29[1]
        getitem_95 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        new_zeros_default_87 = torch.ops.aten.new_zeros.default(convolution_default_29, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_88 = torch.ops.aten.new_zeros.default(convolution_default_29, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_89 = torch.ops.aten.new_zeros.default(convolution_default_29, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_29 = torch.ops.aten.relu_.default(getitem_93);  getitem_93 = None
        convolution_default_30 = torch.ops.aten.convolution.default(relu__default_29, primals_147, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_146, primals_143, primals_144, primals_145, False, 0.1, 1e-05);  primals_143 = None
        getitem_96 = native_batch_norm_default_30[0]
        getitem_97 = native_batch_norm_default_30[1]
        getitem_98 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        new_zeros_default_90 = torch.ops.aten.new_zeros.default(convolution_default_30, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_91 = torch.ops.aten.new_zeros.default(convolution_default_30, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_92 = torch.ops.aten.new_zeros.default(convolution_default_30, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_30 = torch.ops.aten.relu_.default(getitem_96);  getitem_96 = None
        convolution_default_31 = torch.ops.aten.convolution.default(relu__default_30, primals_152, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_31, primals_151, primals_148, primals_149, primals_150, False, 0.1, 1e-05);  primals_148 = None
        getitem_99 = native_batch_norm_default_31[0]
        getitem_100 = native_batch_norm_default_31[1]
        getitem_101 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        new_zeros_default_93 = torch.ops.aten.new_zeros.default(convolution_default_31, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_94 = torch.ops.aten.new_zeros.default(convolution_default_31, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_95 = torch.ops.aten.new_zeros.default(convolution_default_31, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_31 = torch.ops.aten.relu_.default(getitem_99);  getitem_99 = None
        cat_default_4 = torch.ops.aten.cat.default([getitem_85, relu__default_27, relu__default_28, relu__default_29, relu__default_30, relu__default_31], 1)
        convolution_default_32 = torch.ops.aten.convolution.default(cat_default_4, primals_127, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_126, primals_123, primals_124, primals_125, False, 0.1, 1e-05);  primals_123 = None
        getitem_102 = native_batch_norm_default_32[0]
        getitem_103 = native_batch_norm_default_32[1]
        getitem_104 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        new_zeros_default_96 = torch.ops.aten.new_zeros.default(convolution_default_32, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_97 = torch.ops.aten.new_zeros.default(convolution_default_32, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_98 = torch.ops.aten.new_zeros.default(convolution_default_32, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_32 = torch.ops.aten.relu_.default(getitem_102);  getitem_102 = None
        convolution_default_33 = torch.ops.aten.convolution.default(relu__default_32, primals_162, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_161, primals_158, primals_159, primals_160, False, 0.1, 1e-05);  primals_158 = None
        getitem_105 = native_batch_norm_default_33[0]
        getitem_106 = native_batch_norm_default_33[1]
        getitem_107 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        new_zeros_default_99 = torch.ops.aten.new_zeros.default(convolution_default_33, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_100 = torch.ops.aten.new_zeros.default(convolution_default_33, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_101 = torch.ops.aten.new_zeros.default(convolution_default_33, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_33 = torch.ops.aten.relu_.default(getitem_105);  getitem_105 = None
        convolution_default_34 = torch.ops.aten.convolution.default(relu__default_33, primals_167, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_166, primals_163, primals_164, primals_165, False, 0.1, 1e-05);  primals_163 = None
        getitem_108 = native_batch_norm_default_34[0]
        getitem_109 = native_batch_norm_default_34[1]
        getitem_110 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        new_zeros_default_102 = torch.ops.aten.new_zeros.default(convolution_default_34, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_103 = torch.ops.aten.new_zeros.default(convolution_default_34, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_104 = torch.ops.aten.new_zeros.default(convolution_default_34, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_34 = torch.ops.aten.relu_.default(getitem_108);  getitem_108 = None
        convolution_default_35 = torch.ops.aten.convolution.default(relu__default_34, primals_172, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_171, primals_168, primals_169, primals_170, False, 0.1, 1e-05);  primals_168 = None
        getitem_111 = native_batch_norm_default_35[0]
        getitem_112 = native_batch_norm_default_35[1]
        getitem_113 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        new_zeros_default_105 = torch.ops.aten.new_zeros.default(convolution_default_35, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_106 = torch.ops.aten.new_zeros.default(convolution_default_35, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_107 = torch.ops.aten.new_zeros.default(convolution_default_35, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_35 = torch.ops.aten.relu_.default(getitem_111);  getitem_111 = None
        convolution_default_36 = torch.ops.aten.convolution.default(relu__default_35, primals_177, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_176, primals_173, primals_174, primals_175, False, 0.1, 1e-05);  primals_173 = None
        getitem_114 = native_batch_norm_default_36[0]
        getitem_115 = native_batch_norm_default_36[1]
        getitem_116 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        new_zeros_default_108 = torch.ops.aten.new_zeros.default(convolution_default_36, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_109 = torch.ops.aten.new_zeros.default(convolution_default_36, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_110 = torch.ops.aten.new_zeros.default(convolution_default_36, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_36 = torch.ops.aten.relu_.default(getitem_114);  getitem_114 = None
        convolution_default_37 = torch.ops.aten.convolution.default(relu__default_36, primals_182, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_37, primals_181, primals_178, primals_179, primals_180, False, 0.1, 1e-05);  primals_178 = None
        getitem_117 = native_batch_norm_default_37[0]
        getitem_118 = native_batch_norm_default_37[1]
        getitem_119 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        new_zeros_default_111 = torch.ops.aten.new_zeros.default(convolution_default_37, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_112 = torch.ops.aten.new_zeros.default(convolution_default_37, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_113 = torch.ops.aten.new_zeros.default(convolution_default_37, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_37 = torch.ops.aten.relu_.default(getitem_117);  getitem_117 = None
        cat_default_5 = torch.ops.aten.cat.default([relu__default_32, relu__default_33, relu__default_34, relu__default_35, relu__default_36, relu__default_37], 1)
        convolution_default_38 = torch.ops.aten.convolution.default(cat_default_5, primals_157, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_156, primals_153, primals_154, primals_155, False, 0.1, 1e-05);  primals_153 = None
        getitem_120 = native_batch_norm_default_38[0]
        getitem_121 = native_batch_norm_default_38[1]
        getitem_122 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        new_zeros_default_114 = torch.ops.aten.new_zeros.default(convolution_default_38, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_115 = torch.ops.aten.new_zeros.default(convolution_default_38, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_116 = torch.ops.aten.new_zeros.default(convolution_default_38, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_38 = torch.ops.aten.relu_.default(getitem_120);  getitem_120 = None
        mean_dim = torch.ops.aten.mean.dim(relu__default_38, [-1, -2], True)
        view_default = torch.ops.aten.view.default(mean_dim, [32, 1024]);  mean_dim = None
        t_default = torch.ops.aten.t.default(primals_2);  primals_2 = None
        addmm_default = torch.ops.aten.addmm.default(primals_1, view_default, t_default);  primals_1 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(addmm_default, tangents_1)
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, view_default);  t_default_2 = view_default = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_1 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        view_default_2 = torch.ops.aten.view.default(mm_default, [32, 1024, 1, 1]);  mm_default = None
        expand_default = torch.ops.aten.expand.default(view_default_2, [32, 1024, 7, 7]);  view_default_2 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 49);  expand_default = None
        to_dtype = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default_38, torch.float32);  relu__default_38 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default_117 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_117, to_dtype);  le_scalar = new_zeros_default_117 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_2, convolution_default_38, primals_156, primals_154, primals_155, new_zeros_default_114, new_zeros_default_115, False, 1e-05, [True, True, True]);  to_dtype_2 = convolution_default_38 = primals_156 = primals_154 = primals_155 = new_zeros_default_114 = new_zeros_default_115 = None
        getitem_123 = native_batch_norm_backward_default[0]
        getitem_124 = native_batch_norm_backward_default[1]
        getitem_125 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(getitem_123, cat_default_5, primals_157, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_123 = cat_default_5 = primals_157 = None
        getitem_126 = convolution_backward_default[0]
        getitem_127 = convolution_backward_default[1]
        getitem_128 = convolution_backward_default[2];  convolution_backward_default = None
        slice_tensor = torch.ops.aten.slice.Tensor(getitem_126, 1, 0, 1024)
        slice_tensor_1 = torch.ops.aten.slice.Tensor(getitem_126, 1, 1024, 1248)
        slice_tensor_2 = torch.ops.aten.slice.Tensor(getitem_126, 1, 1248, 1472)
        slice_tensor_3 = torch.ops.aten.slice.Tensor(getitem_126, 1, 1472, 1696)
        slice_tensor_4 = torch.ops.aten.slice.Tensor(getitem_126, 1, 1696, 1920)
        slice_tensor_5 = torch.ops.aten.slice.Tensor(getitem_126, 1, 1920, 2144);  getitem_126 = None
        to_dtype_3 = torch.ops.aten.to.dtype(slice_tensor_5, torch.float32);  slice_tensor_5 = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu__default_37, torch.float32);  relu__default_37 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_118 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_118, to_dtype_3);  le_scalar_1 = new_zeros_default_118 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_5, convolution_default_37, primals_181, primals_179, primals_180, new_zeros_default_111, new_zeros_default_112, False, 1e-05, [True, True, True]);  to_dtype_5 = convolution_default_37 = primals_181 = primals_179 = primals_180 = new_zeros_default_111 = new_zeros_default_112 = None
        getitem_129 = native_batch_norm_backward_default_1[0]
        getitem_130 = native_batch_norm_backward_default_1[1]
        getitem_131 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_129, relu__default_36, primals_182, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_129 = primals_182 = None
        getitem_132 = convolution_backward_default_1[0]
        getitem_133 = convolution_backward_default_1[1]
        getitem_134 = convolution_backward_default_1[2];  convolution_backward_default_1 = None
        add_tensor = torch.ops.aten.add.Tensor(slice_tensor_4, getitem_132);  slice_tensor_4 = getitem_132 = None
        to_dtype_6 = torch.ops.aten.to.dtype(add_tensor, torch.float32);  add_tensor = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_36, torch.float32);  relu__default_36 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_119 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_119, to_dtype_6);  le_scalar_2 = new_zeros_default_119 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_8, convolution_default_36, primals_176, primals_174, primals_175, new_zeros_default_108, new_zeros_default_109, False, 1e-05, [True, True, True]);  to_dtype_8 = convolution_default_36 = primals_176 = primals_174 = primals_175 = new_zeros_default_108 = new_zeros_default_109 = None
        getitem_135 = native_batch_norm_backward_default_2[0]
        getitem_136 = native_batch_norm_backward_default_2[1]
        getitem_137 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_135, relu__default_35, primals_177, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_135 = primals_177 = None
        getitem_138 = convolution_backward_default_2[0]
        getitem_139 = convolution_backward_default_2[1]
        getitem_140 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(slice_tensor_3, getitem_138);  slice_tensor_3 = getitem_138 = None
        to_dtype_9 = torch.ops.aten.to.dtype(add_tensor_1, torch.float32);  add_tensor_1 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu__default_35, torch.float32);  relu__default_35 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_120 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_120, to_dtype_9);  le_scalar_3 = new_zeros_default_120 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_35, primals_171, primals_169, primals_170, new_zeros_default_105, new_zeros_default_106, False, 1e-05, [True, True, True]);  to_dtype_11 = convolution_default_35 = primals_171 = primals_169 = primals_170 = new_zeros_default_105 = new_zeros_default_106 = None
        getitem_141 = native_batch_norm_backward_default_3[0]
        getitem_142 = native_batch_norm_backward_default_3[1]
        getitem_143 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_141, relu__default_34, primals_172, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_141 = primals_172 = None
        getitem_144 = convolution_backward_default_3[0]
        getitem_145 = convolution_backward_default_3[1]
        getitem_146 = convolution_backward_default_3[2];  convolution_backward_default_3 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(slice_tensor_2, getitem_144);  slice_tensor_2 = getitem_144 = None
        to_dtype_12 = torch.ops.aten.to.dtype(add_tensor_2, torch.float32);  add_tensor_2 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_34, torch.float32);  relu__default_34 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_121 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_121, to_dtype_12);  le_scalar_4 = new_zeros_default_121 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_34, primals_166, primals_164, primals_165, new_zeros_default_102, new_zeros_default_103, False, 1e-05, [True, True, True]);  to_dtype_14 = convolution_default_34 = primals_166 = primals_164 = primals_165 = new_zeros_default_102 = new_zeros_default_103 = None
        getitem_147 = native_batch_norm_backward_default_4[0]
        getitem_148 = native_batch_norm_backward_default_4[1]
        getitem_149 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_147, relu__default_33, primals_167, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_147 = primals_167 = None
        getitem_150 = convolution_backward_default_4[0]
        getitem_151 = convolution_backward_default_4[1]
        getitem_152 = convolution_backward_default_4[2];  convolution_backward_default_4 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(slice_tensor_1, getitem_150);  slice_tensor_1 = getitem_150 = None
        to_dtype_15 = torch.ops.aten.to.dtype(add_tensor_3, torch.float32);  add_tensor_3 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu__default_33, torch.float32);  relu__default_33 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_122 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_122, to_dtype_15);  le_scalar_5 = new_zeros_default_122 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_17, convolution_default_33, primals_161, primals_159, primals_160, new_zeros_default_99, new_zeros_default_100, False, 1e-05, [True, True, True]);  to_dtype_17 = convolution_default_33 = primals_161 = primals_159 = primals_160 = new_zeros_default_99 = new_zeros_default_100 = None
        getitem_153 = native_batch_norm_backward_default_5[0]
        getitem_154 = native_batch_norm_backward_default_5[1]
        getitem_155 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_153, relu__default_32, primals_162, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_153 = primals_162 = None
        getitem_156 = convolution_backward_default_5[0]
        getitem_157 = convolution_backward_default_5[1]
        getitem_158 = convolution_backward_default_5[2];  convolution_backward_default_5 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(slice_tensor, getitem_156);  slice_tensor = getitem_156 = None
        to_dtype_18 = torch.ops.aten.to.dtype(add_tensor_4, torch.float32);  add_tensor_4 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu__default_32, torch.float32);  relu__default_32 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_123 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_123, to_dtype_18);  le_scalar_6 = new_zeros_default_123 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_20, convolution_default_32, primals_126, primals_124, primals_125, new_zeros_default_96, new_zeros_default_97, False, 1e-05, [True, True, True]);  to_dtype_20 = convolution_default_32 = primals_126 = primals_124 = primals_125 = new_zeros_default_96 = new_zeros_default_97 = None
        getitem_159 = native_batch_norm_backward_default_6[0]
        getitem_160 = native_batch_norm_backward_default_6[1]
        getitem_161 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(getitem_159, cat_default_4, primals_127, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_159 = cat_default_4 = primals_127 = None
        getitem_162 = convolution_backward_default_6[0]
        getitem_163 = convolution_backward_default_6[1]
        getitem_164 = convolution_backward_default_6[2];  convolution_backward_default_6 = None
        slice_tensor_6 = torch.ops.aten.slice.Tensor(getitem_162, 1, 0, 768)
        slice_tensor_7 = torch.ops.aten.slice.Tensor(getitem_162, 1, 768, 992)
        slice_tensor_8 = torch.ops.aten.slice.Tensor(getitem_162, 1, 992, 1216)
        slice_tensor_9 = torch.ops.aten.slice.Tensor(getitem_162, 1, 1216, 1440)
        slice_tensor_10 = torch.ops.aten.slice.Tensor(getitem_162, 1, 1440, 1664)
        slice_tensor_11 = torch.ops.aten.slice.Tensor(getitem_162, 1, 1664, 1888);  getitem_162 = None
        to_dtype_21 = torch.ops.aten.to.dtype(slice_tensor_11, torch.float32);  slice_tensor_11 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_31, torch.float32);  relu__default_31 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_124 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_124, to_dtype_21);  le_scalar_7 = new_zeros_default_124 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_23, convolution_default_31, primals_151, primals_149, primals_150, new_zeros_default_93, new_zeros_default_94, False, 1e-05, [True, True, True]);  to_dtype_23 = convolution_default_31 = primals_151 = primals_149 = primals_150 = new_zeros_default_93 = new_zeros_default_94 = None
        getitem_165 = native_batch_norm_backward_default_7[0]
        getitem_166 = native_batch_norm_backward_default_7[1]
        getitem_167 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(getitem_165, relu__default_30, primals_152, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_165 = primals_152 = None
        getitem_168 = convolution_backward_default_7[0]
        getitem_169 = convolution_backward_default_7[1]
        getitem_170 = convolution_backward_default_7[2];  convolution_backward_default_7 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(slice_tensor_10, getitem_168);  slice_tensor_10 = getitem_168 = None
        to_dtype_24 = torch.ops.aten.to.dtype(add_tensor_5, torch.float32);  add_tensor_5 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_30, torch.float32);  relu__default_30 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_125 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_125, to_dtype_24);  le_scalar_8 = new_zeros_default_125 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_30, primals_146, primals_144, primals_145, new_zeros_default_90, new_zeros_default_91, False, 1e-05, [True, True, True]);  to_dtype_26 = convolution_default_30 = primals_146 = primals_144 = primals_145 = new_zeros_default_90 = new_zeros_default_91 = None
        getitem_171 = native_batch_norm_backward_default_8[0]
        getitem_172 = native_batch_norm_backward_default_8[1]
        getitem_173 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(getitem_171, relu__default_29, primals_147, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_171 = primals_147 = None
        getitem_174 = convolution_backward_default_8[0]
        getitem_175 = convolution_backward_default_8[1]
        getitem_176 = convolution_backward_default_8[2];  convolution_backward_default_8 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(slice_tensor_9, getitem_174);  slice_tensor_9 = getitem_174 = None
        to_dtype_27 = torch.ops.aten.to.dtype(add_tensor_6, torch.float32);  add_tensor_6 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu__default_29, torch.float32);  relu__default_29 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_126 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_126, to_dtype_27);  le_scalar_9 = new_zeros_default_126 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_29, convolution_default_29, primals_141, primals_139, primals_140, new_zeros_default_87, new_zeros_default_88, False, 1e-05, [True, True, True]);  to_dtype_29 = convolution_default_29 = primals_141 = primals_139 = primals_140 = new_zeros_default_87 = new_zeros_default_88 = None
        getitem_177 = native_batch_norm_backward_default_9[0]
        getitem_178 = native_batch_norm_backward_default_9[1]
        getitem_179 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_177, relu__default_28, primals_142, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_177 = primals_142 = None
        getitem_180 = convolution_backward_default_9[0]
        getitem_181 = convolution_backward_default_9[1]
        getitem_182 = convolution_backward_default_9[2];  convolution_backward_default_9 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(slice_tensor_8, getitem_180);  slice_tensor_8 = getitem_180 = None
        to_dtype_30 = torch.ops.aten.to.dtype(add_tensor_7, torch.float32);  add_tensor_7 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu__default_28, torch.float32);  relu__default_28 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_127 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_127, to_dtype_30);  le_scalar_10 = new_zeros_default_127 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default_28, primals_136, primals_134, primals_135, new_zeros_default_84, new_zeros_default_85, False, 1e-05, [True, True, True]);  to_dtype_32 = convolution_default_28 = primals_136 = primals_134 = primals_135 = new_zeros_default_84 = new_zeros_default_85 = None
        getitem_183 = native_batch_norm_backward_default_10[0]
        getitem_184 = native_batch_norm_backward_default_10[1]
        getitem_185 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_183, relu__default_27, primals_137, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_183 = primals_137 = None
        getitem_186 = convolution_backward_default_10[0]
        getitem_187 = convolution_backward_default_10[1]
        getitem_188 = convolution_backward_default_10[2];  convolution_backward_default_10 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(slice_tensor_7, getitem_186);  slice_tensor_7 = getitem_186 = None
        to_dtype_33 = torch.ops.aten.to.dtype(add_tensor_8, torch.float32);  add_tensor_8 = None
        to_dtype_34 = torch.ops.aten.to.dtype(relu__default_27, torch.float32);  relu__default_27 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        new_zeros_default_128 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_128, to_dtype_33);  le_scalar_11 = new_zeros_default_128 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_35, convolution_default_27, primals_131, primals_129, primals_130, new_zeros_default_81, new_zeros_default_82, False, 1e-05, [True, True, True]);  to_dtype_35 = convolution_default_27 = primals_131 = primals_129 = primals_130 = new_zeros_default_81 = new_zeros_default_82 = None
        getitem_189 = native_batch_norm_backward_default_11[0]
        getitem_190 = native_batch_norm_backward_default_11[1]
        getitem_191 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_189, getitem_85, primals_132, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_189 = getitem_85 = primals_132 = None
        getitem_192 = convolution_backward_default_11[0]
        getitem_193 = convolution_backward_default_11[1]
        getitem_194 = convolution_backward_default_11[2];  convolution_backward_default_11 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(slice_tensor_6, getitem_192);  slice_tensor_6 = getitem_192 = None
        max_pool2d_with_indices_backward_default = torch.ops.aten.max_pool2d_with_indices_backward.default(add_tensor_9, relu__default_26, [3, 3], [2, 2], [0, 0], [1, 1], True, getitem_86);  add_tensor_9 = getitem_86 = None
        to_dtype_36 = torch.ops.aten.to.dtype(max_pool2d_with_indices_backward_default, torch.float32);  max_pool2d_with_indices_backward_default = None
        to_dtype_37 = torch.ops.aten.to.dtype(relu__default_26, torch.float32);  relu__default_26 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        new_zeros_default_129 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_129, to_dtype_36);  le_scalar_12 = new_zeros_default_129 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_38, convolution_default_26, primals_96, primals_94, primals_95, new_zeros_default_78, new_zeros_default_79, False, 1e-05, [True, True, True]);  to_dtype_38 = convolution_default_26 = primals_96 = primals_94 = primals_95 = new_zeros_default_78 = new_zeros_default_79 = None
        getitem_195 = native_batch_norm_backward_default_12[0]
        getitem_196 = native_batch_norm_backward_default_12[1]
        getitem_197 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(getitem_195, cat_default_3, primals_97, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_195 = cat_default_3 = primals_97 = None
        getitem_198 = convolution_backward_default_12[0]
        getitem_199 = convolution_backward_default_12[1]
        getitem_200 = convolution_backward_default_12[2];  convolution_backward_default_12 = None
        slice_tensor_12 = torch.ops.aten.slice.Tensor(getitem_198, 1, 0, 768)
        slice_tensor_13 = torch.ops.aten.slice.Tensor(getitem_198, 1, 768, 960)
        slice_tensor_14 = torch.ops.aten.slice.Tensor(getitem_198, 1, 960, 1152)
        slice_tensor_15 = torch.ops.aten.slice.Tensor(getitem_198, 1, 1152, 1344)
        slice_tensor_16 = torch.ops.aten.slice.Tensor(getitem_198, 1, 1344, 1536)
        slice_tensor_17 = torch.ops.aten.slice.Tensor(getitem_198, 1, 1536, 1728);  getitem_198 = None
        to_dtype_39 = torch.ops.aten.to.dtype(slice_tensor_17, torch.float32);  slice_tensor_17 = None
        to_dtype_40 = torch.ops.aten.to.dtype(relu__default_25, torch.float32);  relu__default_25 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        new_zeros_default_130 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_130, to_dtype_39);  le_scalar_13 = new_zeros_default_130 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_41, convolution_default_25, primals_121, primals_119, primals_120, new_zeros_default_75, new_zeros_default_76, False, 1e-05, [True, True, True]);  to_dtype_41 = convolution_default_25 = primals_121 = primals_119 = primals_120 = new_zeros_default_75 = new_zeros_default_76 = None
        getitem_201 = native_batch_norm_backward_default_13[0]
        getitem_202 = native_batch_norm_backward_default_13[1]
        getitem_203 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_201, relu__default_24, primals_122, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_201 = primals_122 = None
        getitem_204 = convolution_backward_default_13[0]
        getitem_205 = convolution_backward_default_13[1]
        getitem_206 = convolution_backward_default_13[2];  convolution_backward_default_13 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(slice_tensor_16, getitem_204);  slice_tensor_16 = getitem_204 = None
        to_dtype_42 = torch.ops.aten.to.dtype(add_tensor_10, torch.float32);  add_tensor_10 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu__default_24, torch.float32);  relu__default_24 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_131 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_131, to_dtype_42);  le_scalar_14 = new_zeros_default_131 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_44, convolution_default_24, primals_116, primals_114, primals_115, new_zeros_default_72, new_zeros_default_73, False, 1e-05, [True, True, True]);  to_dtype_44 = convolution_default_24 = primals_116 = primals_114 = primals_115 = new_zeros_default_72 = new_zeros_default_73 = None
        getitem_207 = native_batch_norm_backward_default_14[0]
        getitem_208 = native_batch_norm_backward_default_14[1]
        getitem_209 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_207, relu__default_23, primals_117, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_207 = primals_117 = None
        getitem_210 = convolution_backward_default_14[0]
        getitem_211 = convolution_backward_default_14[1]
        getitem_212 = convolution_backward_default_14[2];  convolution_backward_default_14 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(slice_tensor_15, getitem_210);  slice_tensor_15 = getitem_210 = None
        to_dtype_45 = torch.ops.aten.to.dtype(add_tensor_11, torch.float32);  add_tensor_11 = None
        to_dtype_46 = torch.ops.aten.to.dtype(relu__default_23, torch.float32);  relu__default_23 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_46, 0);  to_dtype_46 = None
        new_zeros_default_132 = torch.ops.aten.new_zeros.default(to_dtype_45, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_132, to_dtype_45);  le_scalar_15 = new_zeros_default_132 = to_dtype_45 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_47, convolution_default_23, primals_111, primals_109, primals_110, new_zeros_default_69, new_zeros_default_70, False, 1e-05, [True, True, True]);  to_dtype_47 = convolution_default_23 = primals_111 = primals_109 = primals_110 = new_zeros_default_69 = new_zeros_default_70 = None
        getitem_213 = native_batch_norm_backward_default_15[0]
        getitem_214 = native_batch_norm_backward_default_15[1]
        getitem_215 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_213, relu__default_22, primals_112, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_213 = primals_112 = None
        getitem_216 = convolution_backward_default_15[0]
        getitem_217 = convolution_backward_default_15[1]
        getitem_218 = convolution_backward_default_15[2];  convolution_backward_default_15 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(slice_tensor_14, getitem_216);  slice_tensor_14 = getitem_216 = None
        to_dtype_48 = torch.ops.aten.to.dtype(add_tensor_12, torch.float32);  add_tensor_12 = None
        to_dtype_49 = torch.ops.aten.to.dtype(relu__default_22, torch.float32);  relu__default_22 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_49, 0);  to_dtype_49 = None
        new_zeros_default_133 = torch.ops.aten.new_zeros.default(to_dtype_48, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_133, to_dtype_48);  le_scalar_16 = new_zeros_default_133 = to_dtype_48 = None
        to_dtype_50 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_50, convolution_default_22, primals_106, primals_104, primals_105, new_zeros_default_66, new_zeros_default_67, False, 1e-05, [True, True, True]);  to_dtype_50 = convolution_default_22 = primals_106 = primals_104 = primals_105 = new_zeros_default_66 = new_zeros_default_67 = None
        getitem_219 = native_batch_norm_backward_default_16[0]
        getitem_220 = native_batch_norm_backward_default_16[1]
        getitem_221 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(getitem_219, relu__default_21, primals_107, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_219 = primals_107 = None
        getitem_222 = convolution_backward_default_16[0]
        getitem_223 = convolution_backward_default_16[1]
        getitem_224 = convolution_backward_default_16[2];  convolution_backward_default_16 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(slice_tensor_13, getitem_222);  slice_tensor_13 = getitem_222 = None
        to_dtype_51 = torch.ops.aten.to.dtype(add_tensor_13, torch.float32);  add_tensor_13 = None
        to_dtype_52 = torch.ops.aten.to.dtype(relu__default_21, torch.float32);  relu__default_21 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_52, 0);  to_dtype_52 = None
        new_zeros_default_134 = torch.ops.aten.new_zeros.default(to_dtype_51, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_17, new_zeros_default_134, to_dtype_51);  le_scalar_17 = new_zeros_default_134 = to_dtype_51 = None
        to_dtype_53 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_53, convolution_default_21, primals_101, primals_99, primals_100, new_zeros_default_63, new_zeros_default_64, False, 1e-05, [True, True, True]);  to_dtype_53 = convolution_default_21 = primals_101 = primals_99 = primals_100 = new_zeros_default_63 = new_zeros_default_64 = None
        getitem_225 = native_batch_norm_backward_default_17[0]
        getitem_226 = native_batch_norm_backward_default_17[1]
        getitem_227 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(getitem_225, relu__default_20, primals_102, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_225 = primals_102 = None
        getitem_228 = convolution_backward_default_17[0]
        getitem_229 = convolution_backward_default_17[1]
        getitem_230 = convolution_backward_default_17[2];  convolution_backward_default_17 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(slice_tensor_12, getitem_228);  slice_tensor_12 = getitem_228 = None
        to_dtype_54 = torch.ops.aten.to.dtype(add_tensor_14, torch.float32);  add_tensor_14 = None
        to_dtype_55 = torch.ops.aten.to.dtype(relu__default_20, torch.float32);  relu__default_20 = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_55, 0);  to_dtype_55 = None
        new_zeros_default_135 = torch.ops.aten.new_zeros.default(to_dtype_54, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_18 = torch.ops.aten.where.self(le_scalar_18, new_zeros_default_135, to_dtype_54);  le_scalar_18 = new_zeros_default_135 = to_dtype_54 = None
        to_dtype_56 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_56, convolution_default_20, primals_66, primals_64, primals_65, new_zeros_default_60, new_zeros_default_61, False, 1e-05, [True, True, True]);  to_dtype_56 = convolution_default_20 = primals_66 = primals_64 = primals_65 = new_zeros_default_60 = new_zeros_default_61 = None
        getitem_231 = native_batch_norm_backward_default_18[0]
        getitem_232 = native_batch_norm_backward_default_18[1]
        getitem_233 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(getitem_231, cat_default_2, primals_67, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_231 = cat_default_2 = primals_67 = None
        getitem_234 = convolution_backward_default_18[0]
        getitem_235 = convolution_backward_default_18[1]
        getitem_236 = convolution_backward_default_18[2];  convolution_backward_default_18 = None
        slice_tensor_18 = torch.ops.aten.slice.Tensor(getitem_234, 1, 0, 512)
        slice_tensor_19 = torch.ops.aten.slice.Tensor(getitem_234, 1, 512, 704)
        slice_tensor_20 = torch.ops.aten.slice.Tensor(getitem_234, 1, 704, 896)
        slice_tensor_21 = torch.ops.aten.slice.Tensor(getitem_234, 1, 896, 1088)
        slice_tensor_22 = torch.ops.aten.slice.Tensor(getitem_234, 1, 1088, 1280)
        slice_tensor_23 = torch.ops.aten.slice.Tensor(getitem_234, 1, 1280, 1472);  getitem_234 = None
        to_dtype_57 = torch.ops.aten.to.dtype(slice_tensor_23, torch.float32);  slice_tensor_23 = None
        to_dtype_58 = torch.ops.aten.to.dtype(relu__default_19, torch.float32);  relu__default_19 = None
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_58, 0);  to_dtype_58 = None
        new_zeros_default_136 = torch.ops.aten.new_zeros.default(to_dtype_57, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_19 = torch.ops.aten.where.self(le_scalar_19, new_zeros_default_136, to_dtype_57);  le_scalar_19 = new_zeros_default_136 = to_dtype_57 = None
        to_dtype_59 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_59, convolution_default_19, primals_91, primals_89, primals_90, new_zeros_default_57, new_zeros_default_58, False, 1e-05, [True, True, True]);  to_dtype_59 = convolution_default_19 = primals_91 = primals_89 = primals_90 = new_zeros_default_57 = new_zeros_default_58 = None
        getitem_237 = native_batch_norm_backward_default_19[0]
        getitem_238 = native_batch_norm_backward_default_19[1]
        getitem_239 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_237, relu__default_18, primals_92, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_237 = primals_92 = None
        getitem_240 = convolution_backward_default_19[0]
        getitem_241 = convolution_backward_default_19[1]
        getitem_242 = convolution_backward_default_19[2];  convolution_backward_default_19 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(slice_tensor_22, getitem_240);  slice_tensor_22 = getitem_240 = None
        to_dtype_60 = torch.ops.aten.to.dtype(add_tensor_15, torch.float32);  add_tensor_15 = None
        to_dtype_61 = torch.ops.aten.to.dtype(relu__default_18, torch.float32);  relu__default_18 = None
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_61, 0);  to_dtype_61 = None
        new_zeros_default_137 = torch.ops.aten.new_zeros.default(to_dtype_60, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_20 = torch.ops.aten.where.self(le_scalar_20, new_zeros_default_137, to_dtype_60);  le_scalar_20 = new_zeros_default_137 = to_dtype_60 = None
        to_dtype_62 = torch.ops.aten.to.dtype(where_self_20, torch.float32);  where_self_20 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_62, convolution_default_18, primals_86, primals_84, primals_85, new_zeros_default_54, new_zeros_default_55, False, 1e-05, [True, True, True]);  to_dtype_62 = convolution_default_18 = primals_86 = primals_84 = primals_85 = new_zeros_default_54 = new_zeros_default_55 = None
        getitem_243 = native_batch_norm_backward_default_20[0]
        getitem_244 = native_batch_norm_backward_default_20[1]
        getitem_245 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(getitem_243, relu__default_17, primals_87, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_243 = primals_87 = None
        getitem_246 = convolution_backward_default_20[0]
        getitem_247 = convolution_backward_default_20[1]
        getitem_248 = convolution_backward_default_20[2];  convolution_backward_default_20 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(slice_tensor_21, getitem_246);  slice_tensor_21 = getitem_246 = None
        to_dtype_63 = torch.ops.aten.to.dtype(add_tensor_16, torch.float32);  add_tensor_16 = None
        to_dtype_64 = torch.ops.aten.to.dtype(relu__default_17, torch.float32);  relu__default_17 = None
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_64, 0);  to_dtype_64 = None
        new_zeros_default_138 = torch.ops.aten.new_zeros.default(to_dtype_63, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_21 = torch.ops.aten.where.self(le_scalar_21, new_zeros_default_138, to_dtype_63);  le_scalar_21 = new_zeros_default_138 = to_dtype_63 = None
        to_dtype_65 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_65, convolution_default_17, primals_81, primals_79, primals_80, new_zeros_default_51, new_zeros_default_52, False, 1e-05, [True, True, True]);  to_dtype_65 = convolution_default_17 = primals_81 = primals_79 = primals_80 = new_zeros_default_51 = new_zeros_default_52 = None
        getitem_249 = native_batch_norm_backward_default_21[0]
        getitem_250 = native_batch_norm_backward_default_21[1]
        getitem_251 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(getitem_249, relu__default_16, primals_82, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_249 = primals_82 = None
        getitem_252 = convolution_backward_default_21[0]
        getitem_253 = convolution_backward_default_21[1]
        getitem_254 = convolution_backward_default_21[2];  convolution_backward_default_21 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(slice_tensor_20, getitem_252);  slice_tensor_20 = getitem_252 = None
        to_dtype_66 = torch.ops.aten.to.dtype(add_tensor_17, torch.float32);  add_tensor_17 = None
        to_dtype_67 = torch.ops.aten.to.dtype(relu__default_16, torch.float32);  relu__default_16 = None
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_67, 0);  to_dtype_67 = None
        new_zeros_default_139 = torch.ops.aten.new_zeros.default(to_dtype_66, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_22 = torch.ops.aten.where.self(le_scalar_22, new_zeros_default_139, to_dtype_66);  le_scalar_22 = new_zeros_default_139 = to_dtype_66 = None
        to_dtype_68 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_68, convolution_default_16, primals_76, primals_74, primals_75, new_zeros_default_48, new_zeros_default_49, False, 1e-05, [True, True, True]);  to_dtype_68 = convolution_default_16 = primals_76 = primals_74 = primals_75 = new_zeros_default_48 = new_zeros_default_49 = None
        getitem_255 = native_batch_norm_backward_default_22[0]
        getitem_256 = native_batch_norm_backward_default_22[1]
        getitem_257 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(getitem_255, relu__default_15, primals_77, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_255 = primals_77 = None
        getitem_258 = convolution_backward_default_22[0]
        getitem_259 = convolution_backward_default_22[1]
        getitem_260 = convolution_backward_default_22[2];  convolution_backward_default_22 = None
        add_tensor_18 = torch.ops.aten.add.Tensor(slice_tensor_19, getitem_258);  slice_tensor_19 = getitem_258 = None
        to_dtype_69 = torch.ops.aten.to.dtype(add_tensor_18, torch.float32);  add_tensor_18 = None
        to_dtype_70 = torch.ops.aten.to.dtype(relu__default_15, torch.float32);  relu__default_15 = None
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_70, 0);  to_dtype_70 = None
        new_zeros_default_140 = torch.ops.aten.new_zeros.default(to_dtype_69, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(le_scalar_23, new_zeros_default_140, to_dtype_69);  le_scalar_23 = new_zeros_default_140 = to_dtype_69 = None
        to_dtype_71 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_71, convolution_default_15, primals_71, primals_69, primals_70, new_zeros_default_45, new_zeros_default_46, False, 1e-05, [True, True, True]);  to_dtype_71 = convolution_default_15 = primals_71 = primals_69 = primals_70 = new_zeros_default_45 = new_zeros_default_46 = None
        getitem_261 = native_batch_norm_backward_default_23[0]
        getitem_262 = native_batch_norm_backward_default_23[1]
        getitem_263 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(getitem_261, getitem_47, primals_72, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_261 = getitem_47 = primals_72 = None
        getitem_264 = convolution_backward_default_23[0]
        getitem_265 = convolution_backward_default_23[1]
        getitem_266 = convolution_backward_default_23[2];  convolution_backward_default_23 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(slice_tensor_18, getitem_264);  slice_tensor_18 = getitem_264 = None
        max_pool2d_with_indices_backward_default_1 = torch.ops.aten.max_pool2d_with_indices_backward.default(add_tensor_19, relu__default_14, [3, 3], [2, 2], [0, 0], [1, 1], True, getitem_48);  add_tensor_19 = getitem_48 = None
        to_dtype_72 = torch.ops.aten.to.dtype(max_pool2d_with_indices_backward_default_1, torch.float32);  max_pool2d_with_indices_backward_default_1 = None
        to_dtype_73 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_73, 0);  to_dtype_73 = None
        new_zeros_default_141 = torch.ops.aten.new_zeros.default(to_dtype_72, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_24 = torch.ops.aten.where.self(le_scalar_24, new_zeros_default_141, to_dtype_72);  le_scalar_24 = new_zeros_default_141 = to_dtype_72 = None
        to_dtype_74 = torch.ops.aten.to.dtype(where_self_24, torch.float32);  where_self_24 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_74, convolution_default_14, primals_36, primals_34, primals_35, new_zeros_default_42, new_zeros_default_43, False, 1e-05, [True, True, True]);  to_dtype_74 = convolution_default_14 = primals_36 = primals_34 = primals_35 = new_zeros_default_42 = new_zeros_default_43 = None
        getitem_267 = native_batch_norm_backward_default_24[0]
        getitem_268 = native_batch_norm_backward_default_24[1]
        getitem_269 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_267, cat_default_1, primals_37, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_267 = cat_default_1 = primals_37 = None
        getitem_270 = convolution_backward_default_24[0]
        getitem_271 = convolution_backward_default_24[1]
        getitem_272 = convolution_backward_default_24[2];  convolution_backward_default_24 = None
        slice_tensor_24 = torch.ops.aten.slice.Tensor(getitem_270, 1, 0, 256)
        slice_tensor_25 = torch.ops.aten.slice.Tensor(getitem_270, 1, 256, 416)
        slice_tensor_26 = torch.ops.aten.slice.Tensor(getitem_270, 1, 416, 576)
        slice_tensor_27 = torch.ops.aten.slice.Tensor(getitem_270, 1, 576, 736)
        slice_tensor_28 = torch.ops.aten.slice.Tensor(getitem_270, 1, 736, 896)
        slice_tensor_29 = torch.ops.aten.slice.Tensor(getitem_270, 1, 896, 1056);  getitem_270 = None
        to_dtype_75 = torch.ops.aten.to.dtype(slice_tensor_29, torch.float32);  slice_tensor_29 = None
        to_dtype_76 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_76, 0);  to_dtype_76 = None
        new_zeros_default_142 = torch.ops.aten.new_zeros.default(to_dtype_75, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_25 = torch.ops.aten.where.self(le_scalar_25, new_zeros_default_142, to_dtype_75);  le_scalar_25 = new_zeros_default_142 = to_dtype_75 = None
        to_dtype_77 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_77, convolution_default_13, primals_61, primals_59, primals_60, new_zeros_default_39, new_zeros_default_40, False, 1e-05, [True, True, True]);  to_dtype_77 = convolution_default_13 = primals_61 = primals_59 = primals_60 = new_zeros_default_39 = new_zeros_default_40 = None
        getitem_273 = native_batch_norm_backward_default_25[0]
        getitem_274 = native_batch_norm_backward_default_25[1]
        getitem_275 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_273, relu__default_12, primals_62, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_273 = primals_62 = None
        getitem_276 = convolution_backward_default_25[0]
        getitem_277 = convolution_backward_default_25[1]
        getitem_278 = convolution_backward_default_25[2];  convolution_backward_default_25 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(slice_tensor_28, getitem_276);  slice_tensor_28 = getitem_276 = None
        to_dtype_78 = torch.ops.aten.to.dtype(add_tensor_20, torch.float32);  add_tensor_20 = None
        to_dtype_79 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_26 = torch.ops.aten.le.Scalar(to_dtype_79, 0);  to_dtype_79 = None
        new_zeros_default_143 = torch.ops.aten.new_zeros.default(to_dtype_78, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_26 = torch.ops.aten.where.self(le_scalar_26, new_zeros_default_143, to_dtype_78);  le_scalar_26 = new_zeros_default_143 = to_dtype_78 = None
        to_dtype_80 = torch.ops.aten.to.dtype(where_self_26, torch.float32);  where_self_26 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_80, convolution_default_12, primals_56, primals_54, primals_55, new_zeros_default_36, new_zeros_default_37, False, 1e-05, [True, True, True]);  to_dtype_80 = convolution_default_12 = primals_56 = primals_54 = primals_55 = new_zeros_default_36 = new_zeros_default_37 = None
        getitem_279 = native_batch_norm_backward_default_26[0]
        getitem_280 = native_batch_norm_backward_default_26[1]
        getitem_281 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(getitem_279, relu__default_11, primals_57, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_279 = primals_57 = None
        getitem_282 = convolution_backward_default_26[0]
        getitem_283 = convolution_backward_default_26[1]
        getitem_284 = convolution_backward_default_26[2];  convolution_backward_default_26 = None
        add_tensor_21 = torch.ops.aten.add.Tensor(slice_tensor_27, getitem_282);  slice_tensor_27 = getitem_282 = None
        to_dtype_81 = torch.ops.aten.to.dtype(add_tensor_21, torch.float32);  add_tensor_21 = None
        to_dtype_82 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_27 = torch.ops.aten.le.Scalar(to_dtype_82, 0);  to_dtype_82 = None
        new_zeros_default_144 = torch.ops.aten.new_zeros.default(to_dtype_81, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_27 = torch.ops.aten.where.self(le_scalar_27, new_zeros_default_144, to_dtype_81);  le_scalar_27 = new_zeros_default_144 = to_dtype_81 = None
        to_dtype_83 = torch.ops.aten.to.dtype(where_self_27, torch.float32);  where_self_27 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_83, convolution_default_11, primals_51, primals_49, primals_50, new_zeros_default_33, new_zeros_default_34, False, 1e-05, [True, True, True]);  to_dtype_83 = convolution_default_11 = primals_51 = primals_49 = primals_50 = new_zeros_default_33 = new_zeros_default_34 = None
        getitem_285 = native_batch_norm_backward_default_27[0]
        getitem_286 = native_batch_norm_backward_default_27[1]
        getitem_287 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(getitem_285, relu__default_10, primals_52, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_285 = primals_52 = None
        getitem_288 = convolution_backward_default_27[0]
        getitem_289 = convolution_backward_default_27[1]
        getitem_290 = convolution_backward_default_27[2];  convolution_backward_default_27 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(slice_tensor_26, getitem_288);  slice_tensor_26 = getitem_288 = None
        to_dtype_84 = torch.ops.aten.to.dtype(add_tensor_22, torch.float32);  add_tensor_22 = None
        to_dtype_85 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_28 = torch.ops.aten.le.Scalar(to_dtype_85, 0);  to_dtype_85 = None
        new_zeros_default_145 = torch.ops.aten.new_zeros.default(to_dtype_84, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_28 = torch.ops.aten.where.self(le_scalar_28, new_zeros_default_145, to_dtype_84);  le_scalar_28 = new_zeros_default_145 = to_dtype_84 = None
        to_dtype_86 = torch.ops.aten.to.dtype(where_self_28, torch.float32);  where_self_28 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_86, convolution_default_10, primals_46, primals_44, primals_45, new_zeros_default_30, new_zeros_default_31, False, 1e-05, [True, True, True]);  to_dtype_86 = convolution_default_10 = primals_46 = primals_44 = primals_45 = new_zeros_default_30 = new_zeros_default_31 = None
        getitem_291 = native_batch_norm_backward_default_28[0]
        getitem_292 = native_batch_norm_backward_default_28[1]
        getitem_293 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(getitem_291, relu__default_9, primals_47, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_291 = primals_47 = None
        getitem_294 = convolution_backward_default_28[0]
        getitem_295 = convolution_backward_default_28[1]
        getitem_296 = convolution_backward_default_28[2];  convolution_backward_default_28 = None
        add_tensor_23 = torch.ops.aten.add.Tensor(slice_tensor_25, getitem_294);  slice_tensor_25 = getitem_294 = None
        to_dtype_87 = torch.ops.aten.to.dtype(add_tensor_23, torch.float32);  add_tensor_23 = None
        to_dtype_88 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_29 = torch.ops.aten.le.Scalar(to_dtype_88, 0);  to_dtype_88 = None
        new_zeros_default_146 = torch.ops.aten.new_zeros.default(to_dtype_87, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_29 = torch.ops.aten.where.self(le_scalar_29, new_zeros_default_146, to_dtype_87);  le_scalar_29 = new_zeros_default_146 = to_dtype_87 = None
        to_dtype_89 = torch.ops.aten.to.dtype(where_self_29, torch.float32);  where_self_29 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_89, convolution_default_9, primals_41, primals_39, primals_40, new_zeros_default_27, new_zeros_default_28, False, 1e-05, [True, True, True]);  to_dtype_89 = convolution_default_9 = primals_41 = primals_39 = primals_40 = new_zeros_default_27 = new_zeros_default_28 = None
        getitem_297 = native_batch_norm_backward_default_29[0]
        getitem_298 = native_batch_norm_backward_default_29[1]
        getitem_299 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(getitem_297, getitem_27, primals_42, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_297 = getitem_27 = primals_42 = None
        getitem_300 = convolution_backward_default_29[0]
        getitem_301 = convolution_backward_default_29[1]
        getitem_302 = convolution_backward_default_29[2];  convolution_backward_default_29 = None
        add_tensor_24 = torch.ops.aten.add.Tensor(slice_tensor_24, getitem_300);  slice_tensor_24 = getitem_300 = None
        max_pool2d_with_indices_backward_default_2 = torch.ops.aten.max_pool2d_with_indices_backward.default(add_tensor_24, relu__default_8, [3, 3], [2, 2], [0, 0], [1, 1], True, getitem_28);  add_tensor_24 = getitem_28 = None
        to_dtype_90 = torch.ops.aten.to.dtype(max_pool2d_with_indices_backward_default_2, torch.float32);  max_pool2d_with_indices_backward_default_2 = None
        to_dtype_91 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_30 = torch.ops.aten.le.Scalar(to_dtype_91, 0);  to_dtype_91 = None
        new_zeros_default_147 = torch.ops.aten.new_zeros.default(to_dtype_90, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_30 = torch.ops.aten.where.self(le_scalar_30, new_zeros_default_147, to_dtype_90);  le_scalar_30 = new_zeros_default_147 = to_dtype_90 = None
        to_dtype_92 = torch.ops.aten.to.dtype(where_self_30, torch.float32);  where_self_30 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_92, convolution_default_8, primals_6, primals_4, primals_5, new_zeros_default_24, new_zeros_default_25, False, 1e-05, [True, True, True]);  to_dtype_92 = convolution_default_8 = primals_6 = primals_4 = primals_5 = new_zeros_default_24 = new_zeros_default_25 = None
        getitem_303 = native_batch_norm_backward_default_30[0]
        getitem_304 = native_batch_norm_backward_default_30[1]
        getitem_305 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_303, cat_default, primals_7, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_303 = cat_default = primals_7 = None
        getitem_306 = convolution_backward_default_30[0]
        getitem_307 = convolution_backward_default_30[1]
        getitem_308 = convolution_backward_default_30[2];  convolution_backward_default_30 = None
        slice_tensor_30 = torch.ops.aten.slice.Tensor(getitem_306, 1, 0, 128)
        slice_tensor_31 = torch.ops.aten.slice.Tensor(getitem_306, 1, 128, 256)
        slice_tensor_32 = torch.ops.aten.slice.Tensor(getitem_306, 1, 256, 384)
        slice_tensor_33 = torch.ops.aten.slice.Tensor(getitem_306, 1, 384, 512)
        slice_tensor_34 = torch.ops.aten.slice.Tensor(getitem_306, 1, 512, 640)
        slice_tensor_35 = torch.ops.aten.slice.Tensor(getitem_306, 1, 640, 768);  getitem_306 = None
        to_dtype_93 = torch.ops.aten.to.dtype(slice_tensor_35, torch.float32);  slice_tensor_35 = None
        to_dtype_94 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_31 = torch.ops.aten.le.Scalar(to_dtype_94, 0);  to_dtype_94 = None
        new_zeros_default_148 = torch.ops.aten.new_zeros.default(to_dtype_93, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_31 = torch.ops.aten.where.self(le_scalar_31, new_zeros_default_148, to_dtype_93);  le_scalar_31 = new_zeros_default_148 = to_dtype_93 = None
        to_dtype_95 = torch.ops.aten.to.dtype(where_self_31, torch.float32);  where_self_31 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_95, convolution_default_7, primals_31, primals_29, primals_30, new_zeros_default_21, new_zeros_default_22, False, 1e-05, [True, True, True]);  to_dtype_95 = convolution_default_7 = primals_31 = primals_29 = primals_30 = new_zeros_default_21 = new_zeros_default_22 = None
        getitem_309 = native_batch_norm_backward_default_31[0]
        getitem_310 = native_batch_norm_backward_default_31[1]
        getitem_311 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(getitem_309, relu__default_6, primals_32, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_309 = primals_32 = None
        getitem_312 = convolution_backward_default_31[0]
        getitem_313 = convolution_backward_default_31[1]
        getitem_314 = convolution_backward_default_31[2];  convolution_backward_default_31 = None
        add_tensor_25 = torch.ops.aten.add.Tensor(slice_tensor_34, getitem_312);  slice_tensor_34 = getitem_312 = None
        to_dtype_96 = torch.ops.aten.to.dtype(add_tensor_25, torch.float32);  add_tensor_25 = None
        to_dtype_97 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_32 = torch.ops.aten.le.Scalar(to_dtype_97, 0);  to_dtype_97 = None
        new_zeros_default_149 = torch.ops.aten.new_zeros.default(to_dtype_96, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_32 = torch.ops.aten.where.self(le_scalar_32, new_zeros_default_149, to_dtype_96);  le_scalar_32 = new_zeros_default_149 = to_dtype_96 = None
        to_dtype_98 = torch.ops.aten.to.dtype(where_self_32, torch.float32);  where_self_32 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_98, convolution_default_6, primals_26, primals_24, primals_25, new_zeros_default_18, new_zeros_default_19, False, 1e-05, [True, True, True]);  to_dtype_98 = convolution_default_6 = primals_26 = primals_24 = primals_25 = new_zeros_default_18 = new_zeros_default_19 = None
        getitem_315 = native_batch_norm_backward_default_32[0]
        getitem_316 = native_batch_norm_backward_default_32[1]
        getitem_317 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(getitem_315, relu__default_5, primals_27, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_315 = primals_27 = None
        getitem_318 = convolution_backward_default_32[0]
        getitem_319 = convolution_backward_default_32[1]
        getitem_320 = convolution_backward_default_32[2];  convolution_backward_default_32 = None
        add_tensor_26 = torch.ops.aten.add.Tensor(slice_tensor_33, getitem_318);  slice_tensor_33 = getitem_318 = None
        to_dtype_99 = torch.ops.aten.to.dtype(add_tensor_26, torch.float32);  add_tensor_26 = None
        to_dtype_100 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_33 = torch.ops.aten.le.Scalar(to_dtype_100, 0);  to_dtype_100 = None
        new_zeros_default_150 = torch.ops.aten.new_zeros.default(to_dtype_99, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_33 = torch.ops.aten.where.self(le_scalar_33, new_zeros_default_150, to_dtype_99);  le_scalar_33 = new_zeros_default_150 = to_dtype_99 = None
        to_dtype_101 = torch.ops.aten.to.dtype(where_self_33, torch.float32);  where_self_33 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_101, convolution_default_5, primals_21, primals_19, primals_20, new_zeros_default_15, new_zeros_default_16, False, 1e-05, [True, True, True]);  to_dtype_101 = convolution_default_5 = primals_21 = primals_19 = primals_20 = new_zeros_default_15 = new_zeros_default_16 = None
        getitem_321 = native_batch_norm_backward_default_33[0]
        getitem_322 = native_batch_norm_backward_default_33[1]
        getitem_323 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(getitem_321, relu__default_4, primals_22, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_321 = primals_22 = None
        getitem_324 = convolution_backward_default_33[0]
        getitem_325 = convolution_backward_default_33[1]
        getitem_326 = convolution_backward_default_33[2];  convolution_backward_default_33 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(slice_tensor_32, getitem_324);  slice_tensor_32 = getitem_324 = None
        to_dtype_102 = torch.ops.aten.to.dtype(add_tensor_27, torch.float32);  add_tensor_27 = None
        to_dtype_103 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_34 = torch.ops.aten.le.Scalar(to_dtype_103, 0);  to_dtype_103 = None
        new_zeros_default_151 = torch.ops.aten.new_zeros.default(to_dtype_102, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_34 = torch.ops.aten.where.self(le_scalar_34, new_zeros_default_151, to_dtype_102);  le_scalar_34 = new_zeros_default_151 = to_dtype_102 = None
        to_dtype_104 = torch.ops.aten.to.dtype(where_self_34, torch.float32);  where_self_34 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_104, convolution_default_4, primals_16, primals_14, primals_15, new_zeros_default_12, new_zeros_default_13, False, 1e-05, [True, True, True]);  to_dtype_104 = convolution_default_4 = primals_16 = primals_14 = primals_15 = new_zeros_default_12 = new_zeros_default_13 = None
        getitem_327 = native_batch_norm_backward_default_34[0]
        getitem_328 = native_batch_norm_backward_default_34[1]
        getitem_329 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(getitem_327, relu__default_3, primals_17, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_327 = primals_17 = None
        getitem_330 = convolution_backward_default_34[0]
        getitem_331 = convolution_backward_default_34[1]
        getitem_332 = convolution_backward_default_34[2];  convolution_backward_default_34 = None
        add_tensor_28 = torch.ops.aten.add.Tensor(slice_tensor_31, getitem_330);  slice_tensor_31 = getitem_330 = None
        to_dtype_105 = torch.ops.aten.to.dtype(add_tensor_28, torch.float32);  add_tensor_28 = None
        to_dtype_106 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_35 = torch.ops.aten.le.Scalar(to_dtype_106, 0);  to_dtype_106 = None
        new_zeros_default_152 = torch.ops.aten.new_zeros.default(to_dtype_105, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_35 = torch.ops.aten.where.self(le_scalar_35, new_zeros_default_152, to_dtype_105);  le_scalar_35 = new_zeros_default_152 = to_dtype_105 = None
        to_dtype_107 = torch.ops.aten.to.dtype(where_self_35, torch.float32);  where_self_35 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_107, convolution_default_3, primals_11, primals_9, primals_10, new_zeros_default_9, new_zeros_default_10, False, 1e-05, [True, True, True]);  to_dtype_107 = convolution_default_3 = primals_11 = primals_9 = primals_10 = new_zeros_default_9 = new_zeros_default_10 = None
        getitem_333 = native_batch_norm_backward_default_35[0]
        getitem_334 = native_batch_norm_backward_default_35[1]
        getitem_335 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_333, relu__default_2, primals_12, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_333 = primals_12 = None
        getitem_336 = convolution_backward_default_35[0]
        getitem_337 = convolution_backward_default_35[1]
        getitem_338 = convolution_backward_default_35[2];  convolution_backward_default_35 = None
        add_tensor_29 = torch.ops.aten.add.Tensor(slice_tensor_30, getitem_336);  slice_tensor_30 = getitem_336 = None
        to_dtype_108 = torch.ops.aten.to.dtype(add_tensor_29, torch.float32);  add_tensor_29 = None
        to_dtype_109 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_36 = torch.ops.aten.le.Scalar(to_dtype_109, 0);  to_dtype_109 = None
        new_zeros_default_153 = torch.ops.aten.new_zeros.default(to_dtype_108, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_36 = torch.ops.aten.where.self(le_scalar_36, new_zeros_default_153, to_dtype_108);  le_scalar_36 = new_zeros_default_153 = to_dtype_108 = None
        to_dtype_110 = torch.ops.aten.to.dtype(where_self_36, torch.float32);  where_self_36 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_110, convolution_default_2, primals_196, primals_194, primals_195, new_zeros_default_6, new_zeros_default_7, False, 1e-05, [True, True, True]);  to_dtype_110 = convolution_default_2 = primals_196 = primals_194 = primals_195 = new_zeros_default_6 = new_zeros_default_7 = None
        getitem_339 = native_batch_norm_backward_default_36[0]
        getitem_340 = native_batch_norm_backward_default_36[1]
        getitem_341 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(getitem_339, relu__default_1, primals_197, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_339 = primals_197 = None
        getitem_342 = convolution_backward_default_36[0]
        getitem_343 = convolution_backward_default_36[1]
        getitem_344 = convolution_backward_default_36[2];  convolution_backward_default_36 = None
        to_dtype_111 = torch.ops.aten.to.dtype(getitem_342, torch.float32);  getitem_342 = None
        to_dtype_112 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_37 = torch.ops.aten.le.Scalar(to_dtype_112, 0);  to_dtype_112 = None
        new_zeros_default_154 = torch.ops.aten.new_zeros.default(to_dtype_111, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_37 = torch.ops.aten.where.self(le_scalar_37, new_zeros_default_154, to_dtype_111);  le_scalar_37 = new_zeros_default_154 = to_dtype_111 = None
        to_dtype_113 = torch.ops.aten.to.dtype(where_self_37, torch.float32);  where_self_37 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_113, convolution_default_1, primals_191, primals_189, primals_190, new_zeros_default_3, new_zeros_default_4, False, 1e-05, [True, True, True]);  to_dtype_113 = convolution_default_1 = primals_191 = primals_189 = primals_190 = new_zeros_default_3 = new_zeros_default_4 = None
        getitem_345 = native_batch_norm_backward_default_37[0]
        getitem_346 = native_batch_norm_backward_default_37[1]
        getitem_347 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(getitem_345, relu__default, primals_192, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_345 = primals_192 = None
        getitem_348 = convolution_backward_default_37[0]
        getitem_349 = convolution_backward_default_37[1]
        getitem_350 = convolution_backward_default_37[2];  convolution_backward_default_37 = None
        to_dtype_114 = torch.ops.aten.to.dtype(getitem_348, torch.float32);  getitem_348 = None
        to_dtype_115 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_38 = torch.ops.aten.le.Scalar(to_dtype_115, 0);  to_dtype_115 = None
        new_zeros_default_155 = torch.ops.aten.new_zeros.default(to_dtype_114, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_38 = torch.ops.aten.where.self(le_scalar_38, new_zeros_default_155, to_dtype_114);  le_scalar_38 = new_zeros_default_155 = to_dtype_114 = None
        to_dtype_116 = torch.ops.aten.to.dtype(where_self_38, torch.float32);  where_self_38 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_116, convolution_default, primals_186, primals_184, primals_185, new_zeros_default, new_zeros_default_1, False, 1e-05, [True, True, True]);  to_dtype_116 = convolution_default = primals_186 = primals_184 = primals_185 = new_zeros_default = new_zeros_default_1 = None
        getitem_351 = native_batch_norm_backward_default_38[0]
        getitem_352 = native_batch_norm_backward_default_38[1]
        getitem_353 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(getitem_351, primals_198, primals_187, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_351 = primals_198 = primals_187 = None
        getitem_354 = convolution_backward_default_38[0]
        getitem_355 = convolution_backward_default_38[1]
        getitem_356 = convolution_backward_default_38[2];  convolution_backward_default_38 = None
        return [addmm_default, view_default_1, t_default_4, getitem_305, None, None, getitem_304, getitem_307, getitem_335, None, None, getitem_334, getitem_337, getitem_329, None, None, getitem_328, getitem_331, getitem_323, None, None, getitem_322, getitem_325, getitem_317, None, None, getitem_316, getitem_319, getitem_311, None, None, getitem_310, getitem_313, getitem_269, None, None, getitem_268, getitem_271, getitem_299, None, None, getitem_298, getitem_301, getitem_293, None, None, getitem_292, getitem_295, getitem_287, None, None, getitem_286, getitem_289, getitem_281, None, None, getitem_280, getitem_283, getitem_275, None, None, getitem_274, getitem_277, getitem_233, None, None, getitem_232, getitem_235, getitem_263, None, None, getitem_262, getitem_265, getitem_257, None, None, getitem_256, getitem_259, getitem_251, None, None, getitem_250, getitem_253, getitem_245, None, None, getitem_244, getitem_247, getitem_239, None, None, getitem_238, getitem_241, getitem_197, None, None, getitem_196, getitem_199, getitem_227, None, None, getitem_226, getitem_229, getitem_221, None, None, getitem_220, getitem_223, getitem_215, None, None, getitem_214, getitem_217, getitem_209, None, None, getitem_208, getitem_211, getitem_203, None, None, getitem_202, getitem_205, getitem_161, None, None, getitem_160, getitem_163, getitem_191, None, None, getitem_190, getitem_193, getitem_185, None, None, getitem_184, getitem_187, getitem_179, None, None, getitem_178, getitem_181, getitem_173, None, None, getitem_172, getitem_175, getitem_167, None, None, getitem_166, getitem_169, getitem_125, None, None, getitem_124, getitem_127, getitem_155, None, None, getitem_154, getitem_157, getitem_149, None, None, getitem_148, getitem_151, getitem_143, None, None, getitem_142, getitem_145, getitem_137, None, None, getitem_136, getitem_139, getitem_131, None, None, getitem_130, getitem_133, getitem_353, None, None, getitem_352, getitem_355, getitem_347, None, None, getitem_346, getitem_349, getitem_341, None, None, getitem_340, getitem_343, None]
        
