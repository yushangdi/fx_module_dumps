
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/pytorch_unet/pytorch_unet_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129):
        convolution_default = torch.ops.aten.convolution.default(primals_129, primals_58, primals_57, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_57 = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_63, primals_59, primals_61, primals_62, False, 0.1, 1e-05);  primals_59 = None
        getitem = native_batch_norm_default[0];  native_batch_norm_default = None
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default, primals_65, primals_64, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_64 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_70, primals_66, primals_68, primals_69, False, 0.1, 1e-05);  primals_66 = None
        getitem_3 = native_batch_norm_default_1[0];  native_batch_norm_default_1 = None
        relu__default_1 = torch.ops.aten.relu_.default(getitem_3);  getitem_3 = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu__default_1, [2, 2], [2, 2])
        getitem_6 = max_pool2d_with_indices_default[0]
        getitem_7 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_2 = torch.ops.aten.convolution.default(getitem_6, primals_2, primals_1, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_1 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_7, primals_3, primals_5, primals_6, False, 0.1, 1e-05);  primals_3 = None
        getitem_8 = native_batch_norm_default_2[0];  native_batch_norm_default_2 = None
        relu__default_2 = torch.ops.aten.relu_.default(getitem_8);  getitem_8 = None
        convolution_default_3 = torch.ops.aten.convolution.default(relu__default_2, primals_9, primals_8, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_8 = None
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_14, primals_10, primals_12, primals_13, False, 0.1, 1e-05);  primals_10 = None
        getitem_11 = native_batch_norm_default_3[0];  native_batch_norm_default_3 = None
        relu__default_3 = torch.ops.aten.relu_.default(getitem_11);  getitem_11 = None
        max_pool2d_with_indices_default_1 = torch.ops.aten.max_pool2d_with_indices.default(relu__default_3, [2, 2], [2, 2])
        getitem_14 = max_pool2d_with_indices_default_1[0]
        getitem_15 = max_pool2d_with_indices_default_1[1];  max_pool2d_with_indices_default_1 = None
        convolution_default_4 = torch.ops.aten.convolution.default(getitem_14, primals_16, primals_15, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_15 = None
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_21, primals_17, primals_19, primals_20, False, 0.1, 1e-05);  primals_17 = None
        getitem_16 = native_batch_norm_default_4[0];  native_batch_norm_default_4 = None
        relu__default_4 = torch.ops.aten.relu_.default(getitem_16);  getitem_16 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_4, primals_23, primals_22, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_22 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_28, primals_24, primals_26, primals_27, False, 0.1, 1e-05);  primals_24 = None
        getitem_19 = native_batch_norm_default_5[0];  native_batch_norm_default_5 = None
        relu__default_5 = torch.ops.aten.relu_.default(getitem_19);  getitem_19 = None
        max_pool2d_with_indices_default_2 = torch.ops.aten.max_pool2d_with_indices.default(relu__default_5, [2, 2], [2, 2])
        getitem_22 = max_pool2d_with_indices_default_2[0]
        getitem_23 = max_pool2d_with_indices_default_2[1];  max_pool2d_with_indices_default_2 = None
        convolution_default_6 = torch.ops.aten.convolution.default(getitem_22, primals_30, primals_29, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_29 = None
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_35, primals_31, primals_33, primals_34, False, 0.1, 1e-05);  primals_31 = None
        getitem_24 = native_batch_norm_default_6[0];  native_batch_norm_default_6 = None
        relu__default_6 = torch.ops.aten.relu_.default(getitem_24);  getitem_24 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_6, primals_37, primals_36, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_36 = None
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_42, primals_38, primals_40, primals_41, False, 0.1, 1e-05);  primals_38 = None
        getitem_27 = native_batch_norm_default_7[0];  native_batch_norm_default_7 = None
        relu__default_7 = torch.ops.aten.relu_.default(getitem_27);  getitem_27 = None
        max_pool2d_with_indices_default_3 = torch.ops.aten.max_pool2d_with_indices.default(relu__default_7, [2, 2], [2, 2])
        getitem_30 = max_pool2d_with_indices_default_3[0]
        getitem_31 = max_pool2d_with_indices_default_3[1];  max_pool2d_with_indices_default_3 = None
        convolution_default_8 = torch.ops.aten.convolution.default(getitem_30, primals_44, primals_43, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_43 = None
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_49, primals_45, primals_47, primals_48, False, 0.1, 1e-05);  primals_45 = None
        getitem_32 = native_batch_norm_default_8[0];  native_batch_norm_default_8 = None
        relu__default_8 = torch.ops.aten.relu_.default(getitem_32);  getitem_32 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_8, primals_51, primals_50, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_50 = None
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_56, primals_52, primals_54, primals_55, False, 0.1, 1e-05);  primals_52 = None
        getitem_35 = native_batch_norm_default_9[0];  native_batch_norm_default_9 = None
        relu__default_9 = torch.ops.aten.relu_.default(getitem_35);  getitem_35 = None
        upsample_bilinear2d_vec = torch.ops.aten.upsample_bilinear2d.vec(relu__default_9, None, True, [2.0, 2.0])
        constant_pad_nd_default = torch.ops.aten.constant_pad_nd.default(upsample_bilinear2d_vec, [0, 1, 0, 0], 0.0);  upsample_bilinear2d_vec = None
        cat_default = torch.ops.aten.cat.default([relu__default_7, constant_pad_nd_default], 1);  constant_pad_nd_default = None
        convolution_default_10 = torch.ops.aten.convolution.default(cat_default, primals_74, primals_73, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_73 = None
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_79, primals_75, primals_77, primals_78, False, 0.1, 1e-05);  primals_75 = None
        getitem_38 = native_batch_norm_default_10[0];  native_batch_norm_default_10 = None
        relu__default_10 = torch.ops.aten.relu_.default(getitem_38);  getitem_38 = None
        convolution_default_11 = torch.ops.aten.convolution.default(relu__default_10, primals_81, primals_80, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_80 = None
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_86, primals_82, primals_84, primals_85, False, 0.1, 1e-05);  primals_82 = None
        getitem_41 = native_batch_norm_default_11[0];  native_batch_norm_default_11 = None
        relu__default_11 = torch.ops.aten.relu_.default(getitem_41);  getitem_41 = None
        upsample_bilinear2d_vec_1 = torch.ops.aten.upsample_bilinear2d.vec(relu__default_11, None, True, [2.0, 2.0])
        constant_pad_nd_default_1 = torch.ops.aten.constant_pad_nd.default(upsample_bilinear2d_vec_1, [0, 1, 0, 0], 0.0);  upsample_bilinear2d_vec_1 = None
        cat_default_1 = torch.ops.aten.cat.default([relu__default_5, constant_pad_nd_default_1], 1);  constant_pad_nd_default_1 = None
        convolution_default_12 = torch.ops.aten.convolution.default(cat_default_1, primals_88, primals_87, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_87 = None
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_93, primals_89, primals_91, primals_92, False, 0.1, 1e-05);  primals_89 = None
        getitem_44 = native_batch_norm_default_12[0];  native_batch_norm_default_12 = None
        relu__default_12 = torch.ops.aten.relu_.default(getitem_44);  getitem_44 = None
        convolution_default_13 = torch.ops.aten.convolution.default(relu__default_12, primals_95, primals_94, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_94 = None
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_100, primals_96, primals_98, primals_99, False, 0.1, 1e-05);  primals_96 = None
        getitem_47 = native_batch_norm_default_13[0];  native_batch_norm_default_13 = None
        relu__default_13 = torch.ops.aten.relu_.default(getitem_47);  getitem_47 = None
        upsample_bilinear2d_vec_2 = torch.ops.aten.upsample_bilinear2d.vec(relu__default_13, None, True, [2.0, 2.0])
        constant_pad_nd_default_2 = torch.ops.aten.constant_pad_nd.default(upsample_bilinear2d_vec_2, [0, 1, 0, 0], 0.0);  upsample_bilinear2d_vec_2 = None
        cat_default_2 = torch.ops.aten.cat.default([relu__default_3, constant_pad_nd_default_2], 1);  constant_pad_nd_default_2 = None
        convolution_default_14 = torch.ops.aten.convolution.default(cat_default_2, primals_102, primals_101, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_101 = None
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_107, primals_103, primals_105, primals_106, False, 0.1, 1e-05);  primals_103 = None
        getitem_50 = native_batch_norm_default_14[0];  native_batch_norm_default_14 = None
        relu__default_14 = torch.ops.aten.relu_.default(getitem_50);  getitem_50 = None
        convolution_default_15 = torch.ops.aten.convolution.default(relu__default_14, primals_109, primals_108, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_108 = None
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_114, primals_110, primals_112, primals_113, False, 0.1, 1e-05);  primals_110 = None
        getitem_53 = native_batch_norm_default_15[0];  native_batch_norm_default_15 = None
        relu__default_15 = torch.ops.aten.relu_.default(getitem_53);  getitem_53 = None
        upsample_bilinear2d_vec_3 = torch.ops.aten.upsample_bilinear2d.vec(relu__default_15, None, True, [2.0, 2.0])
        constant_pad_nd_default_3 = torch.ops.aten.constant_pad_nd.default(upsample_bilinear2d_vec_3, [0, 1, 0, 0], 0.0);  upsample_bilinear2d_vec_3 = None
        cat_default_3 = torch.ops.aten.cat.default([relu__default_1, constant_pad_nd_default_3], 1);  constant_pad_nd_default_3 = None
        convolution_default_16 = torch.ops.aten.convolution.default(cat_default_3, primals_116, primals_115, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_115 = None
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_121, primals_117, primals_119, primals_120, False, 0.1, 1e-05);  primals_117 = None
        getitem_56 = native_batch_norm_default_16[0];  native_batch_norm_default_16 = None
        relu__default_16 = torch.ops.aten.relu_.default(getitem_56);  getitem_56 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu__default_16, primals_123, primals_122, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_122 = None
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_128, primals_124, primals_126, primals_127, False, 0.1, 1e-05);  primals_124 = None
        getitem_59 = native_batch_norm_default_17[0];  native_batch_norm_default_17 = None
        relu__default_17 = torch.ops.aten.relu_.default(getitem_59);  getitem_59 = None
        convolution_default_18 = torch.ops.aten.convolution.default(relu__default_17, primals_72, primals_71, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_71 = None
        return [convolution_default_18, primals_77, primals_105, primals_85, primals_126, relu__default_5, relu__default_3, relu__default_9, primals_86, primals_49, primals_65, primals_98, primals_106, primals_68, primals_127, primals_19, primals_107, primals_128, primals_7, primals_62, primals_74, primals_20, primals_95, relu__default_7, primals_27, primals_58, primals_129, primals_47, primals_23, primals_109, convolution_default_14, primals_102, primals_34, relu__default_14, relu__default_16, primals_26, primals_28, primals_30, primals_81, primals_48, primals_16, cat_default, convolution_default_17, primals_9, primals_55, primals_112, getitem_30, primals_14, primals_56, primals_72, primals_99, primals_113, primals_88, relu__default_15, getitem_22, getitem_31, primals_37, primals_63, primals_114, relu__default_6, convolution_default_10, getitem_14, getitem_23, convolution_default_8, primals_21, relu__default_4, primals_51, relu__default_10, primals_41, primals_116, getitem_15, primals_70, primals_33, convolution_default_11, primals_93, convolution_default_4, convolution_default_15, primals_78, relu__default_8, relu__default_17, primals_119, convolution_default_9, primals_6, primals_84, convolution_default_16, primals_35, primals_120, primals_42, primals_12, primals_92, primals_121, primals_91, primals_40, primals_123, primals_100, convolution_default_7, primals_13, primals_79, relu__default_11, primals_61, primals_54, primals_69, convolution_default_5, relu__default_1, convolution_default_6, cat_default_1, convolution_default_3, primals_5, convolution_default_12, primals_2, relu__default_12, convolution_default_13, primals_44, getitem_6, convolution_default_2, getitem_7, relu__default, relu__default_2, convolution_default, convolution_default_1, relu__default_13, cat_default_2, cat_default_3]
        
