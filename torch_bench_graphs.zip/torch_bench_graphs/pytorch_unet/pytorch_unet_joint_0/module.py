
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/pytorch_unet/pytorch_unet_joint_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, tangents_1):
        convolution_default = torch.ops.aten.convolution.default(primals_129, primals_58, primals_57, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_57 = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_63, primals_59, primals_61, primals_62, False, 0.1, 1e-05);  primals_59 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        new_zeros_default = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_2 = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default, primals_65, primals_64, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_64 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_70, primals_66, primals_68, primals_69, False, 0.1, 1e-05);  primals_66 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_5 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_1 = torch.ops.aten.relu_.default(getitem_3);  getitem_3 = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu__default_1, [2, 2], [2, 2])
        getitem_6 = max_pool2d_with_indices_default[0]
        getitem_7 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_2 = torch.ops.aten.convolution.default(getitem_6, primals_2, primals_1, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_1 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_7, primals_3, primals_5, primals_6, False, 0.1, 1e-05);  primals_3 = None
        getitem_8 = native_batch_norm_default_2[0]
        getitem_9 = native_batch_norm_default_2[1]
        getitem_10 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_8 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_2 = torch.ops.aten.relu_.default(getitem_8);  getitem_8 = None
        convolution_default_3 = torch.ops.aten.convolution.default(relu__default_2, primals_9, primals_8, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_8 = None
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_14, primals_10, primals_12, primals_13, False, 0.1, 1e-05);  primals_10 = None
        getitem_11 = native_batch_norm_default_3[0]
        getitem_12 = native_batch_norm_default_3[1]
        getitem_13 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        new_zeros_default_9 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_10 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_11 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_3 = torch.ops.aten.relu_.default(getitem_11);  getitem_11 = None
        max_pool2d_with_indices_default_1 = torch.ops.aten.max_pool2d_with_indices.default(relu__default_3, [2, 2], [2, 2])
        getitem_14 = max_pool2d_with_indices_default_1[0]
        getitem_15 = max_pool2d_with_indices_default_1[1];  max_pool2d_with_indices_default_1 = None
        convolution_default_4 = torch.ops.aten.convolution.default(getitem_14, primals_16, primals_15, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_15 = None
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_21, primals_17, primals_19, primals_20, False, 0.1, 1e-05);  primals_17 = None
        getitem_16 = native_batch_norm_default_4[0]
        getitem_17 = native_batch_norm_default_4[1]
        getitem_18 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        new_zeros_default_12 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_13 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_14 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_4 = torch.ops.aten.relu_.default(getitem_16);  getitem_16 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_4, primals_23, primals_22, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_22 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_28, primals_24, primals_26, primals_27, False, 0.1, 1e-05);  primals_24 = None
        getitem_19 = native_batch_norm_default_5[0]
        getitem_20 = native_batch_norm_default_5[1]
        getitem_21 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        new_zeros_default_15 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_16 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_17 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_5 = torch.ops.aten.relu_.default(getitem_19);  getitem_19 = None
        max_pool2d_with_indices_default_2 = torch.ops.aten.max_pool2d_with_indices.default(relu__default_5, [2, 2], [2, 2])
        getitem_22 = max_pool2d_with_indices_default_2[0]
        getitem_23 = max_pool2d_with_indices_default_2[1];  max_pool2d_with_indices_default_2 = None
        convolution_default_6 = torch.ops.aten.convolution.default(getitem_22, primals_30, primals_29, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_29 = None
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_35, primals_31, primals_33, primals_34, False, 0.1, 1e-05);  primals_31 = None
        getitem_24 = native_batch_norm_default_6[0]
        getitem_25 = native_batch_norm_default_6[1]
        getitem_26 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        new_zeros_default_18 = torch.ops.aten.new_zeros.default(convolution_default_6, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_19 = torch.ops.aten.new_zeros.default(convolution_default_6, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_20 = torch.ops.aten.new_zeros.default(convolution_default_6, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_6 = torch.ops.aten.relu_.default(getitem_24);  getitem_24 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_6, primals_37, primals_36, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_36 = None
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_42, primals_38, primals_40, primals_41, False, 0.1, 1e-05);  primals_38 = None
        getitem_27 = native_batch_norm_default_7[0]
        getitem_28 = native_batch_norm_default_7[1]
        getitem_29 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        new_zeros_default_21 = torch.ops.aten.new_zeros.default(convolution_default_7, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_22 = torch.ops.aten.new_zeros.default(convolution_default_7, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_23 = torch.ops.aten.new_zeros.default(convolution_default_7, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_7 = torch.ops.aten.relu_.default(getitem_27);  getitem_27 = None
        max_pool2d_with_indices_default_3 = torch.ops.aten.max_pool2d_with_indices.default(relu__default_7, [2, 2], [2, 2])
        getitem_30 = max_pool2d_with_indices_default_3[0]
        getitem_31 = max_pool2d_with_indices_default_3[1];  max_pool2d_with_indices_default_3 = None
        convolution_default_8 = torch.ops.aten.convolution.default(getitem_30, primals_44, primals_43, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_43 = None
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_49, primals_45, primals_47, primals_48, False, 0.1, 1e-05);  primals_45 = None
        getitem_32 = native_batch_norm_default_8[0]
        getitem_33 = native_batch_norm_default_8[1]
        getitem_34 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        new_zeros_default_24 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_25 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_26 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_8 = torch.ops.aten.relu_.default(getitem_32);  getitem_32 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_8, primals_51, primals_50, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_50 = None
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_56, primals_52, primals_54, primals_55, False, 0.1, 1e-05);  primals_52 = None
        getitem_35 = native_batch_norm_default_9[0]
        getitem_36 = native_batch_norm_default_9[1]
        getitem_37 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        new_zeros_default_27 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_28 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_29 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_9 = torch.ops.aten.relu_.default(getitem_35);  getitem_35 = None
        upsample_bilinear2d_vec = torch.ops.aten.upsample_bilinear2d.vec(relu__default_9, None, True, [2.0, 2.0])
        constant_pad_nd_default = torch.ops.aten.constant_pad_nd.default(upsample_bilinear2d_vec, [0, 1, 0, 0], 0.0);  upsample_bilinear2d_vec = None
        cat_default = torch.ops.aten.cat.default([relu__default_7, constant_pad_nd_default], 1);  constant_pad_nd_default = None
        convolution_default_10 = torch.ops.aten.convolution.default(cat_default, primals_74, primals_73, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_73 = None
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_79, primals_75, primals_77, primals_78, False, 0.1, 1e-05);  primals_75 = None
        getitem_38 = native_batch_norm_default_10[0]
        getitem_39 = native_batch_norm_default_10[1]
        getitem_40 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        new_zeros_default_30 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_31 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_32 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_10 = torch.ops.aten.relu_.default(getitem_38);  getitem_38 = None
        convolution_default_11 = torch.ops.aten.convolution.default(relu__default_10, primals_81, primals_80, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_80 = None
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_86, primals_82, primals_84, primals_85, False, 0.1, 1e-05);  primals_82 = None
        getitem_41 = native_batch_norm_default_11[0]
        getitem_42 = native_batch_norm_default_11[1]
        getitem_43 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        new_zeros_default_33 = torch.ops.aten.new_zeros.default(convolution_default_11, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_34 = torch.ops.aten.new_zeros.default(convolution_default_11, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_35 = torch.ops.aten.new_zeros.default(convolution_default_11, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_11 = torch.ops.aten.relu_.default(getitem_41);  getitem_41 = None
        upsample_bilinear2d_vec_1 = torch.ops.aten.upsample_bilinear2d.vec(relu__default_11, None, True, [2.0, 2.0])
        constant_pad_nd_default_1 = torch.ops.aten.constant_pad_nd.default(upsample_bilinear2d_vec_1, [0, 1, 0, 0], 0.0);  upsample_bilinear2d_vec_1 = None
        cat_default_1 = torch.ops.aten.cat.default([relu__default_5, constant_pad_nd_default_1], 1);  constant_pad_nd_default_1 = None
        convolution_default_12 = torch.ops.aten.convolution.default(cat_default_1, primals_88, primals_87, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_87 = None
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_93, primals_89, primals_91, primals_92, False, 0.1, 1e-05);  primals_89 = None
        getitem_44 = native_batch_norm_default_12[0]
        getitem_45 = native_batch_norm_default_12[1]
        getitem_46 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        new_zeros_default_36 = torch.ops.aten.new_zeros.default(convolution_default_12, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_37 = torch.ops.aten.new_zeros.default(convolution_default_12, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_38 = torch.ops.aten.new_zeros.default(convolution_default_12, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_12 = torch.ops.aten.relu_.default(getitem_44);  getitem_44 = None
        convolution_default_13 = torch.ops.aten.convolution.default(relu__default_12, primals_95, primals_94, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_94 = None
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_100, primals_96, primals_98, primals_99, False, 0.1, 1e-05);  primals_96 = None
        getitem_47 = native_batch_norm_default_13[0]
        getitem_48 = native_batch_norm_default_13[1]
        getitem_49 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        new_zeros_default_39 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_40 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_41 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_13 = torch.ops.aten.relu_.default(getitem_47);  getitem_47 = None
        upsample_bilinear2d_vec_2 = torch.ops.aten.upsample_bilinear2d.vec(relu__default_13, None, True, [2.0, 2.0])
        constant_pad_nd_default_2 = torch.ops.aten.constant_pad_nd.default(upsample_bilinear2d_vec_2, [0, 1, 0, 0], 0.0);  upsample_bilinear2d_vec_2 = None
        cat_default_2 = torch.ops.aten.cat.default([relu__default_3, constant_pad_nd_default_2], 1);  constant_pad_nd_default_2 = None
        convolution_default_14 = torch.ops.aten.convolution.default(cat_default_2, primals_102, primals_101, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_101 = None
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_107, primals_103, primals_105, primals_106, False, 0.1, 1e-05);  primals_103 = None
        getitem_50 = native_batch_norm_default_14[0]
        getitem_51 = native_batch_norm_default_14[1]
        getitem_52 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        new_zeros_default_42 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_43 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_44 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_14 = torch.ops.aten.relu_.default(getitem_50);  getitem_50 = None
        convolution_default_15 = torch.ops.aten.convolution.default(relu__default_14, primals_109, primals_108, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_108 = None
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_114, primals_110, primals_112, primals_113, False, 0.1, 1e-05);  primals_110 = None
        getitem_53 = native_batch_norm_default_15[0]
        getitem_54 = native_batch_norm_default_15[1]
        getitem_55 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        new_zeros_default_45 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_46 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_47 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_15 = torch.ops.aten.relu_.default(getitem_53);  getitem_53 = None
        upsample_bilinear2d_vec_3 = torch.ops.aten.upsample_bilinear2d.vec(relu__default_15, None, True, [2.0, 2.0])
        constant_pad_nd_default_3 = torch.ops.aten.constant_pad_nd.default(upsample_bilinear2d_vec_3, [0, 1, 0, 0], 0.0);  upsample_bilinear2d_vec_3 = None
        cat_default_3 = torch.ops.aten.cat.default([relu__default_1, constant_pad_nd_default_3], 1);  constant_pad_nd_default_3 = None
        convolution_default_16 = torch.ops.aten.convolution.default(cat_default_3, primals_116, primals_115, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_115 = None
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_121, primals_117, primals_119, primals_120, False, 0.1, 1e-05);  primals_117 = None
        getitem_56 = native_batch_norm_default_16[0]
        getitem_57 = native_batch_norm_default_16[1]
        getitem_58 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        new_zeros_default_48 = torch.ops.aten.new_zeros.default(convolution_default_16, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_49 = torch.ops.aten.new_zeros.default(convolution_default_16, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_50 = torch.ops.aten.new_zeros.default(convolution_default_16, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_16 = torch.ops.aten.relu_.default(getitem_56);  getitem_56 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu__default_16, primals_123, primals_122, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_122 = None
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_128, primals_124, primals_126, primals_127, False, 0.1, 1e-05);  primals_124 = None
        getitem_59 = native_batch_norm_default_17[0]
        getitem_60 = native_batch_norm_default_17[1]
        getitem_61 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        new_zeros_default_51 = torch.ops.aten.new_zeros.default(convolution_default_17, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_52 = torch.ops.aten.new_zeros.default(convolution_default_17, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_53 = torch.ops.aten.new_zeros.default(convolution_default_17, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_17 = torch.ops.aten.relu_.default(getitem_59);  getitem_59 = None
        convolution_default_18 = torch.ops.aten.convolution.default(relu__default_17, primals_72, primals_71, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_71 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(convolution_default_18, tangents_1)
        convolution_backward_default = torch.ops.aten.convolution_backward.default(tangents_1, relu__default_17, primals_72, [2], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  tangents_1 = primals_72 = None
        getitem_62 = convolution_backward_default[0]
        getitem_63 = convolution_backward_default[1]
        getitem_64 = convolution_backward_default[2];  convolution_backward_default = None
        to_dtype = torch.ops.aten.to.dtype(getitem_62, torch.float32);  getitem_62 = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default_17, torch.float32);  relu__default_17 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default_54 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_54, to_dtype);  le_scalar = new_zeros_default_54 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_2, convolution_default_17, primals_128, primals_126, primals_127, new_zeros_default_51, new_zeros_default_52, False, 1e-05, [True, True, True]);  to_dtype_2 = convolution_default_17 = primals_128 = primals_126 = primals_127 = new_zeros_default_51 = new_zeros_default_52 = None
        getitem_65 = native_batch_norm_backward_default[0]
        getitem_66 = native_batch_norm_backward_default[1]
        getitem_67 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_65, relu__default_16, primals_123, [64], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_65 = primals_123 = None
        getitem_68 = convolution_backward_default_1[0]
        getitem_69 = convolution_backward_default_1[1]
        getitem_70 = convolution_backward_default_1[2];  convolution_backward_default_1 = None
        to_dtype_3 = torch.ops.aten.to.dtype(getitem_68, torch.float32);  getitem_68 = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu__default_16, torch.float32);  relu__default_16 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_55 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_55, to_dtype_3);  le_scalar_1 = new_zeros_default_55 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_5, convolution_default_16, primals_121, primals_119, primals_120, new_zeros_default_48, new_zeros_default_49, False, 1e-05, [True, True, True]);  to_dtype_5 = convolution_default_16 = primals_121 = primals_119 = primals_120 = new_zeros_default_48 = new_zeros_default_49 = None
        getitem_71 = native_batch_norm_backward_default_1[0]
        getitem_72 = native_batch_norm_backward_default_1[1]
        getitem_73 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_71, cat_default_3, primals_116, [64], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_71 = cat_default_3 = primals_116 = None
        getitem_74 = convolution_backward_default_2[0]
        getitem_75 = convolution_backward_default_2[1]
        getitem_76 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        slice_tensor = torch.ops.aten.slice.Tensor(getitem_74, 1, 0, 64)
        slice_tensor_1 = torch.ops.aten.slice.Tensor(getitem_74, 1, 64, 128);  getitem_74 = None
        constant_pad_nd_default_4 = torch.ops.aten.constant_pad_nd.default(slice_tensor_1, [0, -1, 0, 0]);  slice_tensor_1 = None
        upsample_bilinear2d_backward_vec = torch.ops.aten.upsample_bilinear2d_backward.vec(constant_pad_nd_default_4, None, [1, 64, 320, 479], True, [2.0, 2.0]);  constant_pad_nd_default_4 = None
        to_dtype_6 = torch.ops.aten.to.dtype(upsample_bilinear2d_backward_vec, torch.float32);  upsample_bilinear2d_backward_vec = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_15, torch.float32);  relu__default_15 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_56 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_56, to_dtype_6);  le_scalar_2 = new_zeros_default_56 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_8, convolution_default_15, primals_114, primals_112, primals_113, new_zeros_default_45, new_zeros_default_46, False, 1e-05, [True, True, True]);  to_dtype_8 = convolution_default_15 = primals_114 = primals_112 = primals_113 = new_zeros_default_45 = new_zeros_default_46 = None
        getitem_77 = native_batch_norm_backward_default_2[0]
        getitem_78 = native_batch_norm_backward_default_2[1]
        getitem_79 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_77, relu__default_14, primals_109, [64], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_77 = primals_109 = None
        getitem_80 = convolution_backward_default_3[0]
        getitem_81 = convolution_backward_default_3[1]
        getitem_82 = convolution_backward_default_3[2];  convolution_backward_default_3 = None
        to_dtype_9 = torch.ops.aten.to.dtype(getitem_80, torch.float32);  getitem_80 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_57 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_57, to_dtype_9);  le_scalar_3 = new_zeros_default_57 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_14, primals_107, primals_105, primals_106, new_zeros_default_42, new_zeros_default_43, False, 1e-05, [True, True, True]);  to_dtype_11 = convolution_default_14 = primals_107 = primals_105 = primals_106 = new_zeros_default_42 = new_zeros_default_43 = None
        getitem_83 = native_batch_norm_backward_default_3[0]
        getitem_84 = native_batch_norm_backward_default_3[1]
        getitem_85 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_83, cat_default_2, primals_102, [128], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_83 = cat_default_2 = primals_102 = None
        getitem_86 = convolution_backward_default_4[0]
        getitem_87 = convolution_backward_default_4[1]
        getitem_88 = convolution_backward_default_4[2];  convolution_backward_default_4 = None
        slice_tensor_2 = torch.ops.aten.slice.Tensor(getitem_86, 1, 0, 128)
        slice_tensor_3 = torch.ops.aten.slice.Tensor(getitem_86, 1, 128, 256);  getitem_86 = None
        constant_pad_nd_default_5 = torch.ops.aten.constant_pad_nd.default(slice_tensor_3, [0, -1, 0, 0]);  slice_tensor_3 = None
        upsample_bilinear2d_backward_vec_1 = torch.ops.aten.upsample_bilinear2d_backward.vec(constant_pad_nd_default_5, None, [1, 128, 160, 239], True, [2.0, 2.0]);  constant_pad_nd_default_5 = None
        to_dtype_12 = torch.ops.aten.to.dtype(upsample_bilinear2d_backward_vec_1, torch.float32);  upsample_bilinear2d_backward_vec_1 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_58 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_58, to_dtype_12);  le_scalar_4 = new_zeros_default_58 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_13, primals_100, primals_98, primals_99, new_zeros_default_39, new_zeros_default_40, False, 1e-05, [True, True, True]);  to_dtype_14 = convolution_default_13 = primals_100 = primals_98 = primals_99 = new_zeros_default_39 = new_zeros_default_40 = None
        getitem_89 = native_batch_norm_backward_default_4[0]
        getitem_90 = native_batch_norm_backward_default_4[1]
        getitem_91 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_89, relu__default_12, primals_95, [128], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_89 = primals_95 = None
        getitem_92 = convolution_backward_default_5[0]
        getitem_93 = convolution_backward_default_5[1]
        getitem_94 = convolution_backward_default_5[2];  convolution_backward_default_5 = None
        to_dtype_15 = torch.ops.aten.to.dtype(getitem_92, torch.float32);  getitem_92 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_59 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_59, to_dtype_15);  le_scalar_5 = new_zeros_default_59 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_17, convolution_default_12, primals_93, primals_91, primals_92, new_zeros_default_36, new_zeros_default_37, False, 1e-05, [True, True, True]);  to_dtype_17 = convolution_default_12 = primals_93 = primals_91 = primals_92 = new_zeros_default_36 = new_zeros_default_37 = None
        getitem_95 = native_batch_norm_backward_default_5[0]
        getitem_96 = native_batch_norm_backward_default_5[1]
        getitem_97 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(getitem_95, cat_default_1, primals_88, [256], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_95 = cat_default_1 = primals_88 = None
        getitem_98 = convolution_backward_default_6[0]
        getitem_99 = convolution_backward_default_6[1]
        getitem_100 = convolution_backward_default_6[2];  convolution_backward_default_6 = None
        slice_tensor_4 = torch.ops.aten.slice.Tensor(getitem_98, 1, 0, 256)
        slice_tensor_5 = torch.ops.aten.slice.Tensor(getitem_98, 1, 256, 512);  getitem_98 = None
        constant_pad_nd_default_6 = torch.ops.aten.constant_pad_nd.default(slice_tensor_5, [0, -1, 0, 0]);  slice_tensor_5 = None
        upsample_bilinear2d_backward_vec_2 = torch.ops.aten.upsample_bilinear2d_backward.vec(constant_pad_nd_default_6, None, [1, 256, 80, 119], True, [2.0, 2.0]);  constant_pad_nd_default_6 = None
        to_dtype_18 = torch.ops.aten.to.dtype(upsample_bilinear2d_backward_vec_2, torch.float32);  upsample_bilinear2d_backward_vec_2 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_60 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_60, to_dtype_18);  le_scalar_6 = new_zeros_default_60 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_20, convolution_default_11, primals_86, primals_84, primals_85, new_zeros_default_33, new_zeros_default_34, False, 1e-05, [True, True, True]);  to_dtype_20 = convolution_default_11 = primals_86 = primals_84 = primals_85 = new_zeros_default_33 = new_zeros_default_34 = None
        getitem_101 = native_batch_norm_backward_default_6[0]
        getitem_102 = native_batch_norm_backward_default_6[1]
        getitem_103 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(getitem_101, relu__default_10, primals_81, [256], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_101 = primals_81 = None
        getitem_104 = convolution_backward_default_7[0]
        getitem_105 = convolution_backward_default_7[1]
        getitem_106 = convolution_backward_default_7[2];  convolution_backward_default_7 = None
        to_dtype_21 = torch.ops.aten.to.dtype(getitem_104, torch.float32);  getitem_104 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_61 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_61, to_dtype_21);  le_scalar_7 = new_zeros_default_61 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_23, convolution_default_10, primals_79, primals_77, primals_78, new_zeros_default_30, new_zeros_default_31, False, 1e-05, [True, True, True]);  to_dtype_23 = convolution_default_10 = primals_79 = primals_77 = primals_78 = new_zeros_default_30 = new_zeros_default_31 = None
        getitem_107 = native_batch_norm_backward_default_7[0]
        getitem_108 = native_batch_norm_backward_default_7[1]
        getitem_109 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(getitem_107, cat_default, primals_74, [512], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_107 = cat_default = primals_74 = None
        getitem_110 = convolution_backward_default_8[0]
        getitem_111 = convolution_backward_default_8[1]
        getitem_112 = convolution_backward_default_8[2];  convolution_backward_default_8 = None
        slice_tensor_6 = torch.ops.aten.slice.Tensor(getitem_110, 1, 0, 512)
        slice_tensor_7 = torch.ops.aten.slice.Tensor(getitem_110, 1, 512, 1024);  getitem_110 = None
        constant_pad_nd_default_7 = torch.ops.aten.constant_pad_nd.default(slice_tensor_7, [0, -1, 0, 0]);  slice_tensor_7 = None
        upsample_bilinear2d_backward_vec_3 = torch.ops.aten.upsample_bilinear2d_backward.vec(constant_pad_nd_default_7, None, [1, 512, 40, 59], True, [2.0, 2.0]);  constant_pad_nd_default_7 = None
        to_dtype_24 = torch.ops.aten.to.dtype(upsample_bilinear2d_backward_vec_3, torch.float32);  upsample_bilinear2d_backward_vec_3 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_62 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_62, to_dtype_24);  le_scalar_8 = new_zeros_default_62 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_9, primals_56, primals_54, primals_55, new_zeros_default_27, new_zeros_default_28, False, 1e-05, [True, True, True]);  to_dtype_26 = convolution_default_9 = primals_56 = primals_54 = primals_55 = new_zeros_default_27 = new_zeros_default_28 = None
        getitem_113 = native_batch_norm_backward_default_8[0]
        getitem_114 = native_batch_norm_backward_default_8[1]
        getitem_115 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_113, relu__default_8, primals_51, [512], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_113 = primals_51 = None
        getitem_116 = convolution_backward_default_9[0]
        getitem_117 = convolution_backward_default_9[1]
        getitem_118 = convolution_backward_default_9[2];  convolution_backward_default_9 = None
        to_dtype_27 = torch.ops.aten.to.dtype(getitem_116, torch.float32);  getitem_116 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_63 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_63, to_dtype_27);  le_scalar_9 = new_zeros_default_63 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_29, convolution_default_8, primals_49, primals_47, primals_48, new_zeros_default_24, new_zeros_default_25, False, 1e-05, [True, True, True]);  to_dtype_29 = convolution_default_8 = primals_49 = primals_47 = primals_48 = new_zeros_default_24 = new_zeros_default_25 = None
        getitem_119 = native_batch_norm_backward_default_9[0]
        getitem_120 = native_batch_norm_backward_default_9[1]
        getitem_121 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_119, getitem_30, primals_44, [512], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_119 = getitem_30 = primals_44 = None
        getitem_122 = convolution_backward_default_10[0]
        getitem_123 = convolution_backward_default_10[1]
        getitem_124 = convolution_backward_default_10[2];  convolution_backward_default_10 = None
        max_pool2d_with_indices_backward_default = torch.ops.aten.max_pool2d_with_indices_backward.default(getitem_122, relu__default_7, [2, 2], [2, 2], [0, 0], [1, 1], False, getitem_31);  getitem_122 = getitem_31 = None
        add_tensor = torch.ops.aten.add.Tensor(slice_tensor_6, max_pool2d_with_indices_backward_default);  slice_tensor_6 = max_pool2d_with_indices_backward_default = None
        to_dtype_30 = torch.ops.aten.to.dtype(add_tensor, torch.float32);  add_tensor = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_64 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_64, to_dtype_30);  le_scalar_10 = new_zeros_default_64 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default_7, primals_42, primals_40, primals_41, new_zeros_default_21, new_zeros_default_22, False, 1e-05, [True, True, True]);  to_dtype_32 = convolution_default_7 = primals_42 = primals_40 = primals_41 = new_zeros_default_21 = new_zeros_default_22 = None
        getitem_125 = native_batch_norm_backward_default_10[0]
        getitem_126 = native_batch_norm_backward_default_10[1]
        getitem_127 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_125, relu__default_6, primals_37, [512], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_125 = primals_37 = None
        getitem_128 = convolution_backward_default_11[0]
        getitem_129 = convolution_backward_default_11[1]
        getitem_130 = convolution_backward_default_11[2];  convolution_backward_default_11 = None
        to_dtype_33 = torch.ops.aten.to.dtype(getitem_128, torch.float32);  getitem_128 = None
        to_dtype_34 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        new_zeros_default_65 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_65, to_dtype_33);  le_scalar_11 = new_zeros_default_65 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_35, convolution_default_6, primals_35, primals_33, primals_34, new_zeros_default_18, new_zeros_default_19, False, 1e-05, [True, True, True]);  to_dtype_35 = convolution_default_6 = primals_35 = primals_33 = primals_34 = new_zeros_default_18 = new_zeros_default_19 = None
        getitem_131 = native_batch_norm_backward_default_11[0]
        getitem_132 = native_batch_norm_backward_default_11[1]
        getitem_133 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(getitem_131, getitem_22, primals_30, [512], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_131 = getitem_22 = primals_30 = None
        getitem_134 = convolution_backward_default_12[0]
        getitem_135 = convolution_backward_default_12[1]
        getitem_136 = convolution_backward_default_12[2];  convolution_backward_default_12 = None
        max_pool2d_with_indices_backward_default_1 = torch.ops.aten.max_pool2d_with_indices_backward.default(getitem_134, relu__default_5, [2, 2], [2, 2], [0, 0], [1, 1], False, getitem_23);  getitem_134 = getitem_23 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(slice_tensor_4, max_pool2d_with_indices_backward_default_1);  slice_tensor_4 = max_pool2d_with_indices_backward_default_1 = None
        to_dtype_36 = torch.ops.aten.to.dtype(add_tensor_1, torch.float32);  add_tensor_1 = None
        to_dtype_37 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        new_zeros_default_66 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_66, to_dtype_36);  le_scalar_12 = new_zeros_default_66 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_38, convolution_default_5, primals_28, primals_26, primals_27, new_zeros_default_15, new_zeros_default_16, False, 1e-05, [True, True, True]);  to_dtype_38 = convolution_default_5 = primals_28 = primals_26 = primals_27 = new_zeros_default_15 = new_zeros_default_16 = None
        getitem_137 = native_batch_norm_backward_default_12[0]
        getitem_138 = native_batch_norm_backward_default_12[1]
        getitem_139 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_137, relu__default_4, primals_23, [256], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_137 = primals_23 = None
        getitem_140 = convolution_backward_default_13[0]
        getitem_141 = convolution_backward_default_13[1]
        getitem_142 = convolution_backward_default_13[2];  convolution_backward_default_13 = None
        to_dtype_39 = torch.ops.aten.to.dtype(getitem_140, torch.float32);  getitem_140 = None
        to_dtype_40 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        new_zeros_default_67 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_67, to_dtype_39);  le_scalar_13 = new_zeros_default_67 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_41, convolution_default_4, primals_21, primals_19, primals_20, new_zeros_default_12, new_zeros_default_13, False, 1e-05, [True, True, True]);  to_dtype_41 = convolution_default_4 = primals_21 = primals_19 = primals_20 = new_zeros_default_12 = new_zeros_default_13 = None
        getitem_143 = native_batch_norm_backward_default_13[0]
        getitem_144 = native_batch_norm_backward_default_13[1]
        getitem_145 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_143, getitem_14, primals_16, [256], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_143 = getitem_14 = primals_16 = None
        getitem_146 = convolution_backward_default_14[0]
        getitem_147 = convolution_backward_default_14[1]
        getitem_148 = convolution_backward_default_14[2];  convolution_backward_default_14 = None
        max_pool2d_with_indices_backward_default_2 = torch.ops.aten.max_pool2d_with_indices_backward.default(getitem_146, relu__default_3, [2, 2], [2, 2], [0, 0], [1, 1], False, getitem_15);  getitem_146 = getitem_15 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(slice_tensor_2, max_pool2d_with_indices_backward_default_2);  slice_tensor_2 = max_pool2d_with_indices_backward_default_2 = None
        to_dtype_42 = torch.ops.aten.to.dtype(add_tensor_2, torch.float32);  add_tensor_2 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_68 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_68, to_dtype_42);  le_scalar_14 = new_zeros_default_68 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_44, convolution_default_3, primals_14, primals_12, primals_13, new_zeros_default_9, new_zeros_default_10, False, 1e-05, [True, True, True]);  to_dtype_44 = convolution_default_3 = primals_14 = primals_12 = primals_13 = new_zeros_default_9 = new_zeros_default_10 = None
        getitem_149 = native_batch_norm_backward_default_14[0]
        getitem_150 = native_batch_norm_backward_default_14[1]
        getitem_151 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_149, relu__default_2, primals_9, [128], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_149 = primals_9 = None
        getitem_152 = convolution_backward_default_15[0]
        getitem_153 = convolution_backward_default_15[1]
        getitem_154 = convolution_backward_default_15[2];  convolution_backward_default_15 = None
        to_dtype_45 = torch.ops.aten.to.dtype(getitem_152, torch.float32);  getitem_152 = None
        to_dtype_46 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_46, 0);  to_dtype_46 = None
        new_zeros_default_69 = torch.ops.aten.new_zeros.default(to_dtype_45, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_69, to_dtype_45);  le_scalar_15 = new_zeros_default_69 = to_dtype_45 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_47, convolution_default_2, primals_7, primals_5, primals_6, new_zeros_default_6, new_zeros_default_7, False, 1e-05, [True, True, True]);  to_dtype_47 = convolution_default_2 = primals_7 = primals_5 = primals_6 = new_zeros_default_6 = new_zeros_default_7 = None
        getitem_155 = native_batch_norm_backward_default_15[0]
        getitem_156 = native_batch_norm_backward_default_15[1]
        getitem_157 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(getitem_155, getitem_6, primals_2, [128], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_155 = getitem_6 = primals_2 = None
        getitem_158 = convolution_backward_default_16[0]
        getitem_159 = convolution_backward_default_16[1]
        getitem_160 = convolution_backward_default_16[2];  convolution_backward_default_16 = None
        max_pool2d_with_indices_backward_default_3 = torch.ops.aten.max_pool2d_with_indices_backward.default(getitem_158, relu__default_1, [2, 2], [2, 2], [0, 0], [1, 1], False, getitem_7);  getitem_158 = getitem_7 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(slice_tensor, max_pool2d_with_indices_backward_default_3);  slice_tensor = max_pool2d_with_indices_backward_default_3 = None
        to_dtype_48 = torch.ops.aten.to.dtype(add_tensor_3, torch.float32);  add_tensor_3 = None
        to_dtype_49 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_49, 0);  to_dtype_49 = None
        new_zeros_default_70 = torch.ops.aten.new_zeros.default(to_dtype_48, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_70, to_dtype_48);  le_scalar_16 = new_zeros_default_70 = to_dtype_48 = None
        to_dtype_50 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_50, convolution_default_1, primals_70, primals_68, primals_69, new_zeros_default_3, new_zeros_default_4, False, 1e-05, [True, True, True]);  to_dtype_50 = convolution_default_1 = primals_70 = primals_68 = primals_69 = new_zeros_default_3 = new_zeros_default_4 = None
        getitem_161 = native_batch_norm_backward_default_16[0]
        getitem_162 = native_batch_norm_backward_default_16[1]
        getitem_163 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(getitem_161, relu__default, primals_65, [64], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_161 = primals_65 = None
        getitem_164 = convolution_backward_default_17[0]
        getitem_165 = convolution_backward_default_17[1]
        getitem_166 = convolution_backward_default_17[2];  convolution_backward_default_17 = None
        to_dtype_51 = torch.ops.aten.to.dtype(getitem_164, torch.float32);  getitem_164 = None
        to_dtype_52 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_52, 0);  to_dtype_52 = None
        new_zeros_default_71 = torch.ops.aten.new_zeros.default(to_dtype_51, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_17, new_zeros_default_71, to_dtype_51);  le_scalar_17 = new_zeros_default_71 = to_dtype_51 = None
        to_dtype_53 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_53, convolution_default, primals_63, primals_61, primals_62, new_zeros_default, new_zeros_default_1, False, 1e-05, [True, True, True]);  to_dtype_53 = convolution_default = primals_63 = primals_61 = primals_62 = new_zeros_default = new_zeros_default_1 = None
        getitem_167 = native_batch_norm_backward_default_17[0]
        getitem_168 = native_batch_norm_backward_default_17[1]
        getitem_169 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(getitem_167, primals_129, primals_58, [64], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [False, True, True]);  getitem_167 = primals_129 = primals_58 = None
        getitem_170 = convolution_backward_default_18[0]
        getitem_171 = convolution_backward_default_18[1]
        getitem_172 = convolution_backward_default_18[2];  convolution_backward_default_18 = None
        return [convolution_default_18, getitem_160, getitem_159, getitem_157, None, None, None, getitem_156, getitem_154, getitem_153, getitem_151, None, None, None, getitem_150, getitem_148, getitem_147, getitem_145, None, None, None, getitem_144, getitem_142, getitem_141, getitem_139, None, None, None, getitem_138, getitem_136, getitem_135, getitem_133, None, None, None, getitem_132, getitem_130, getitem_129, getitem_127, None, None, None, getitem_126, getitem_124, getitem_123, getitem_121, None, None, None, getitem_120, getitem_118, getitem_117, getitem_115, None, None, None, getitem_114, getitem_172, getitem_171, getitem_169, None, None, None, getitem_168, getitem_166, getitem_165, getitem_163, None, None, None, getitem_162, getitem_64, getitem_63, getitem_112, getitem_111, getitem_109, None, None, None, getitem_108, getitem_106, getitem_105, getitem_103, None, None, None, getitem_102, getitem_100, getitem_99, getitem_97, None, None, None, getitem_96, getitem_94, getitem_93, getitem_91, None, None, None, getitem_90, getitem_88, getitem_87, getitem_85, None, None, None, getitem_84, getitem_82, getitem_81, getitem_79, None, None, None, getitem_78, getitem_76, getitem_75, getitem_73, None, None, None, getitem_72, getitem_70, getitem_69, getitem_67, None, None, None, getitem_66, None]
        
