
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/soft_actor_critic/soft_actor_critic_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7):
        t_default = torch.ops.aten.t.default(primals_2);  primals_2 = None
        addmm_default = torch.ops.aten.addmm.default(primals_1, primals_7, t_default);  primals_1 = t_default = None
        relu_default = torch.ops.aten.relu.default(addmm_default);  addmm_default = None
        t_default_1 = torch.ops.aten.t.default(primals_4);  primals_4 = None
        addmm_default_1 = torch.ops.aten.addmm.default(primals_3, relu_default, t_default_1);  primals_3 = None
        relu_default_1 = torch.ops.aten.relu.default(addmm_default_1);  addmm_default_1 = None
        t_default_2 = torch.ops.aten.t.default(primals_6);  primals_6 = None
        addmm_default_2 = torch.ops.aten.addmm.default(primals_5, relu_default_1, t_default_2);  primals_5 = None
        split_tensor = torch.ops.aten.split.Tensor(addmm_default_2, 1, 1);  addmm_default_2 = None
        getitem = split_tensor[0]
        getitem_1 = split_tensor[1];  split_tensor = None
        tanh_default = torch.ops.aten.tanh.default(getitem_1);  getitem_1 = None
        add_tensor = torch.ops.aten.add.Tensor(tanh_default, 1)
        mul_tensor = torch.ops.aten.mul.Tensor(add_tensor, 6.0);  add_tensor = None
        add_tensor_1 = torch.ops.aten.add.Tensor(mul_tensor, -10.0);  mul_tensor = None
        exp_default = torch.ops.aten.exp.default(add_tensor_1);  add_tensor_1 = None
        return [getitem, exp_default, getitem, exp_default, t_default_1, primals_7, exp_default, relu_default_1, tanh_default, t_default_2, relu_default]
        
