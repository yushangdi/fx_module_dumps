
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/soft_actor_critic/soft_actor_critic_joint_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, tangents_1, tangents_2, tangents_3, tangents_4):
        t_default = torch.ops.aten.t.default(primals_2);  primals_2 = None
        addmm_default = torch.ops.aten.addmm.default(primals_1, primals_7, t_default);  primals_1 = t_default = None
        relu_default = torch.ops.aten.relu.default(addmm_default);  addmm_default = None
        t_default_1 = torch.ops.aten.t.default(primals_4);  primals_4 = None
        addmm_default_1 = torch.ops.aten.addmm.default(primals_3, relu_default, t_default_1);  primals_3 = None
        relu_default_1 = torch.ops.aten.relu.default(addmm_default_1);  addmm_default_1 = None
        t_default_2 = torch.ops.aten.t.default(primals_6);  primals_6 = None
        addmm_default_2 = torch.ops.aten.addmm.default(primals_5, relu_default_1, t_default_2);  primals_5 = None
        split_tensor = torch.ops.aten.split.Tensor(addmm_default_2, 1, 1);  addmm_default_2 = None
        getitem = split_tensor[0]
        getitem_1 = split_tensor[1];  split_tensor = None
        tanh_default = torch.ops.aten.tanh.default(getitem_1);  getitem_1 = None
        add_tensor = torch.ops.aten.add.Tensor(tanh_default, 1)
        mul_tensor = torch.ops.aten.mul.Tensor(add_tensor, 6.0);  add_tensor = None
        add_tensor_1 = torch.ops.aten.add.Tensor(mul_tensor, -10.0);  mul_tensor = None
        exp_default = torch.ops.aten.exp.default(add_tensor_1);  add_tensor_1 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(getitem, tangents_1)
        is_same_size_default_1 = torch.ops.aten.is_same_size.default(exp_default, tangents_2)
        is_same_size_default_2 = torch.ops.aten.is_same_size.default(getitem, tangents_3)
        is_same_size_default_3 = torch.ops.aten.is_same_size.default(exp_default, tangents_4)
        add_tensor_2 = torch.ops.aten.add.Tensor(tangents_1, tangents_3);  tangents_1 = tangents_3 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(tangents_2, tangents_4);  tangents_2 = tangents_4 = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(add_tensor_3, exp_default);  add_tensor_3 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(mul_tensor_1, 6.0);  mul_tensor_1 = None
        to_dtype = torch.ops.aten.to.dtype(mul_tensor_2, torch.float32);  mul_tensor_2 = None
        to_dtype_1 = torch.ops.aten.to.dtype(tanh_default, torch.float32);  tanh_default = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(to_dtype_1, to_dtype_1);  to_dtype_1 = None
        rsub_scalar = torch.ops.aten.rsub.Scalar(mul_tensor_3, 1);  mul_tensor_3 = None
        conj_physical_default = torch.ops.aten.conj_physical.default(rsub_scalar);  rsub_scalar = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(to_dtype, conj_physical_default);  to_dtype = conj_physical_default = None
        to_dtype_2 = torch.ops.aten.to.dtype(mul_tensor_4, torch.float32);  mul_tensor_4 = None
        cat_default = torch.ops.aten.cat.default([add_tensor_2, to_dtype_2], 1);  add_tensor_2 = to_dtype_2 = None
        t_default_3 = torch.ops.aten.t.default(t_default_2);  t_default_2 = None
        mm_default = torch.ops.aten.mm.default(cat_default, t_default_3);  t_default_3 = None
        t_default_4 = torch.ops.aten.t.default(cat_default)
        mm_default_1 = torch.ops.aten.mm.default(t_default_4, relu_default_1);  t_default_4 = None
        t_default_5 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(cat_default, [0], True);  cat_default = None
        view_default = torch.ops.aten.view.default(sum_dim_int_list, [2]);  sum_dim_int_list = None
        t_default_6 = torch.ops.aten.t.default(t_default_5);  t_default_5 = None
        to_dtype_3 = torch.ops.aten.to.dtype(mm_default, torch.float32);  mm_default = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu_default_1, torch.float32);  relu_default_1 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default, to_dtype_3);  le_scalar = new_zeros_default = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        t_default_7 = torch.ops.aten.t.default(t_default_1);  t_default_1 = None
        mm_default_2 = torch.ops.aten.mm.default(to_dtype_5, t_default_7);  t_default_7 = None
        t_default_8 = torch.ops.aten.t.default(to_dtype_5)
        mm_default_3 = torch.ops.aten.mm.default(t_default_8, relu_default);  t_default_8 = None
        t_default_9 = torch.ops.aten.t.default(mm_default_3);  mm_default_3 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(to_dtype_5, [0], True);  to_dtype_5 = None
        view_default_1 = torch.ops.aten.view.default(sum_dim_int_list_1, [1024]);  sum_dim_int_list_1 = None
        t_default_10 = torch.ops.aten.t.default(t_default_9);  t_default_9 = None
        to_dtype_6 = torch.ops.aten.to.dtype(mm_default_2, torch.float32);  mm_default_2 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu_default, torch.float32);  relu_default = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_1, to_dtype_6);  le_scalar_1 = new_zeros_default_1 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        t_default_11 = torch.ops.aten.t.default(to_dtype_8)
        mm_default_4 = torch.ops.aten.mm.default(t_default_11, primals_7);  t_default_11 = primals_7 = None
        t_default_12 = torch.ops.aten.t.default(mm_default_4);  mm_default_4 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(to_dtype_8, [0], True);  to_dtype_8 = None
        view_default_2 = torch.ops.aten.view.default(sum_dim_int_list_2, [1024]);  sum_dim_int_list_2 = None
        t_default_13 = torch.ops.aten.t.default(t_default_12);  t_default_12 = None
        return [getitem, exp_default, getitem, exp_default, view_default_2, t_default_13, view_default_1, t_default_10, view_default, t_default_6, None]
        
