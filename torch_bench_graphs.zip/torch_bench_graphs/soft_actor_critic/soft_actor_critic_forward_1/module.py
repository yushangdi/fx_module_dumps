
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/soft_actor_critic/soft_actor_critic_forward_1/state_dict.pt'))

    
    
    def forward(self, primals_1):
        tanh_default = torch.ops.aten.tanh.default(primals_1);  primals_1 = None
        return [tanh_default, tanh_default]
        
