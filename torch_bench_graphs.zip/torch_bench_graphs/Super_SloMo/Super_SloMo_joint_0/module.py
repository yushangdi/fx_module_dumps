
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/Super_SloMo/Super_SloMo_joint_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, tangents_1, tangents_2):
        cat_default = torch.ops.aten.cat.default([primals_116, primals_117], 1)
        convolution_default = torch.ops.aten.convolution.default(cat_default, primals_48, primals_47, [1, 1], [3, 3], [1, 1], False, [0, 0], 1);  primals_47 = None
        gt_scalar = torch.ops.aten.gt.Scalar(convolution_default, 0)
        mul_tensor = torch.ops.aten.mul.Tensor(convolution_default, 0.1)
        where_self = torch.ops.aten.where.self(gt_scalar, convolution_default, mul_tensor);  gt_scalar = mul_tensor = None
        convolution_default_1 = torch.ops.aten.convolution.default(where_self, primals_50, primals_49, [1, 1], [3, 3], [1, 1], False, [0, 0], 1);  primals_49 = None
        gt_scalar_1 = torch.ops.aten.gt.Scalar(convolution_default_1, 0)
        mul_tensor_1 = torch.ops.aten.mul.Tensor(convolution_default_1, 0.1)
        where_self_1 = torch.ops.aten.where.self(gt_scalar_1, convolution_default_1, mul_tensor_1);  gt_scalar_1 = mul_tensor_1 = None
        avg_pool2d_default = torch.ops.aten.avg_pool2d.default(where_self_1, [2, 2])
        convolution_default_2 = torch.ops.aten.convolution.default(avg_pool2d_default, primals_54, primals_53, [1, 1], [2, 2], [1, 1], False, [0, 0], 1);  primals_53 = None
        gt_scalar_2 = torch.ops.aten.gt.Scalar(convolution_default_2, 0)
        mul_tensor_2 = torch.ops.aten.mul.Tensor(convolution_default_2, 0.1)
        where_self_2 = torch.ops.aten.where.self(gt_scalar_2, convolution_default_2, mul_tensor_2);  gt_scalar_2 = mul_tensor_2 = None
        convolution_default_3 = torch.ops.aten.convolution.default(where_self_2, primals_56, primals_55, [1, 1], [2, 2], [1, 1], False, [0, 0], 1);  primals_55 = None
        gt_scalar_3 = torch.ops.aten.gt.Scalar(convolution_default_3, 0)
        mul_tensor_3 = torch.ops.aten.mul.Tensor(convolution_default_3, 0.1)
        where_self_3 = torch.ops.aten.where.self(gt_scalar_3, convolution_default_3, mul_tensor_3);  gt_scalar_3 = mul_tensor_3 = None
        avg_pool2d_default_1 = torch.ops.aten.avg_pool2d.default(where_self_3, [2, 2])
        convolution_default_4 = torch.ops.aten.convolution.default(avg_pool2d_default_1, primals_58, primals_57, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_57 = None
        gt_scalar_4 = torch.ops.aten.gt.Scalar(convolution_default_4, 0)
        mul_tensor_4 = torch.ops.aten.mul.Tensor(convolution_default_4, 0.1)
        where_self_4 = torch.ops.aten.where.self(gt_scalar_4, convolution_default_4, mul_tensor_4);  gt_scalar_4 = mul_tensor_4 = None
        convolution_default_5 = torch.ops.aten.convolution.default(where_self_4, primals_60, primals_59, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_59 = None
        gt_scalar_5 = torch.ops.aten.gt.Scalar(convolution_default_5, 0)
        mul_tensor_5 = torch.ops.aten.mul.Tensor(convolution_default_5, 0.1)
        where_self_5 = torch.ops.aten.where.self(gt_scalar_5, convolution_default_5, mul_tensor_5);  gt_scalar_5 = mul_tensor_5 = None
        avg_pool2d_default_2 = torch.ops.aten.avg_pool2d.default(where_self_5, [2, 2])
        convolution_default_6 = torch.ops.aten.convolution.default(avg_pool2d_default_2, primals_62, primals_61, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_61 = None
        gt_scalar_6 = torch.ops.aten.gt.Scalar(convolution_default_6, 0)
        mul_tensor_6 = torch.ops.aten.mul.Tensor(convolution_default_6, 0.1)
        where_self_6 = torch.ops.aten.where.self(gt_scalar_6, convolution_default_6, mul_tensor_6);  gt_scalar_6 = mul_tensor_6 = None
        convolution_default_7 = torch.ops.aten.convolution.default(where_self_6, primals_64, primals_63, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_63 = None
        gt_scalar_7 = torch.ops.aten.gt.Scalar(convolution_default_7, 0)
        mul_tensor_7 = torch.ops.aten.mul.Tensor(convolution_default_7, 0.1)
        where_self_7 = torch.ops.aten.where.self(gt_scalar_7, convolution_default_7, mul_tensor_7);  gt_scalar_7 = mul_tensor_7 = None
        avg_pool2d_default_3 = torch.ops.aten.avg_pool2d.default(where_self_7, [2, 2])
        convolution_default_8 = torch.ops.aten.convolution.default(avg_pool2d_default_3, primals_66, primals_65, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_65 = None
        gt_scalar_8 = torch.ops.aten.gt.Scalar(convolution_default_8, 0)
        mul_tensor_8 = torch.ops.aten.mul.Tensor(convolution_default_8, 0.1)
        where_self_8 = torch.ops.aten.where.self(gt_scalar_8, convolution_default_8, mul_tensor_8);  gt_scalar_8 = mul_tensor_8 = None
        convolution_default_9 = torch.ops.aten.convolution.default(where_self_8, primals_68, primals_67, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_67 = None
        gt_scalar_9 = torch.ops.aten.gt.Scalar(convolution_default_9, 0)
        mul_tensor_9 = torch.ops.aten.mul.Tensor(convolution_default_9, 0.1)
        where_self_9 = torch.ops.aten.where.self(gt_scalar_9, convolution_default_9, mul_tensor_9);  gt_scalar_9 = mul_tensor_9 = None
        avg_pool2d_default_4 = torch.ops.aten.avg_pool2d.default(where_self_9, [2, 2])
        convolution_default_10 = torch.ops.aten.convolution.default(avg_pool2d_default_4, primals_70, primals_69, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_69 = None
        gt_scalar_10 = torch.ops.aten.gt.Scalar(convolution_default_10, 0)
        mul_tensor_10 = torch.ops.aten.mul.Tensor(convolution_default_10, 0.1)
        where_self_10 = torch.ops.aten.where.self(gt_scalar_10, convolution_default_10, mul_tensor_10);  gt_scalar_10 = mul_tensor_10 = None
        convolution_default_11 = torch.ops.aten.convolution.default(where_self_10, primals_72, primals_71, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_71 = None
        gt_scalar_11 = torch.ops.aten.gt.Scalar(convolution_default_11, 0)
        mul_tensor_11 = torch.ops.aten.mul.Tensor(convolution_default_11, 0.1)
        where_self_11 = torch.ops.aten.where.self(gt_scalar_11, convolution_default_11, mul_tensor_11);  gt_scalar_11 = mul_tensor_11 = None
        upsample_bilinear2d_vec = torch.ops.aten.upsample_bilinear2d.vec(where_self_11, None, False, [2.0, 2.0]);  where_self_11 = None
        convolution_default_12 = torch.ops.aten.convolution.default(upsample_bilinear2d_vec, primals_74, primals_73, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_73 = None
        gt_scalar_12 = torch.ops.aten.gt.Scalar(convolution_default_12, 0)
        mul_tensor_12 = torch.ops.aten.mul.Tensor(convolution_default_12, 0.1)
        where_self_12 = torch.ops.aten.where.self(gt_scalar_12, convolution_default_12, mul_tensor_12);  gt_scalar_12 = mul_tensor_12 = None
        cat_default_1 = torch.ops.aten.cat.default([where_self_12, where_self_9], 1);  where_self_12 = None
        convolution_default_13 = torch.ops.aten.convolution.default(cat_default_1, primals_76, primals_75, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_75 = None
        gt_scalar_13 = torch.ops.aten.gt.Scalar(convolution_default_13, 0)
        mul_tensor_13 = torch.ops.aten.mul.Tensor(convolution_default_13, 0.1)
        where_self_13 = torch.ops.aten.where.self(gt_scalar_13, convolution_default_13, mul_tensor_13);  gt_scalar_13 = mul_tensor_13 = None
        upsample_bilinear2d_vec_1 = torch.ops.aten.upsample_bilinear2d.vec(where_self_13, None, False, [2.0, 2.0]);  where_self_13 = None
        convolution_default_14 = torch.ops.aten.convolution.default(upsample_bilinear2d_vec_1, primals_78, primals_77, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_77 = None
        gt_scalar_14 = torch.ops.aten.gt.Scalar(convolution_default_14, 0)
        mul_tensor_14 = torch.ops.aten.mul.Tensor(convolution_default_14, 0.1)
        where_self_14 = torch.ops.aten.where.self(gt_scalar_14, convolution_default_14, mul_tensor_14);  gt_scalar_14 = mul_tensor_14 = None
        cat_default_2 = torch.ops.aten.cat.default([where_self_14, where_self_7], 1);  where_self_14 = None
        convolution_default_15 = torch.ops.aten.convolution.default(cat_default_2, primals_80, primals_79, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_79 = None
        gt_scalar_15 = torch.ops.aten.gt.Scalar(convolution_default_15, 0)
        mul_tensor_15 = torch.ops.aten.mul.Tensor(convolution_default_15, 0.1)
        where_self_15 = torch.ops.aten.where.self(gt_scalar_15, convolution_default_15, mul_tensor_15);  gt_scalar_15 = mul_tensor_15 = None
        upsample_bilinear2d_vec_2 = torch.ops.aten.upsample_bilinear2d.vec(where_self_15, None, False, [2.0, 2.0]);  where_self_15 = None
        convolution_default_16 = torch.ops.aten.convolution.default(upsample_bilinear2d_vec_2, primals_82, primals_81, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_81 = None
        gt_scalar_16 = torch.ops.aten.gt.Scalar(convolution_default_16, 0)
        mul_tensor_16 = torch.ops.aten.mul.Tensor(convolution_default_16, 0.1)
        where_self_16 = torch.ops.aten.where.self(gt_scalar_16, convolution_default_16, mul_tensor_16);  gt_scalar_16 = mul_tensor_16 = None
        cat_default_3 = torch.ops.aten.cat.default([where_self_16, where_self_5], 1);  where_self_16 = None
        convolution_default_17 = torch.ops.aten.convolution.default(cat_default_3, primals_84, primals_83, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_83 = None
        gt_scalar_17 = torch.ops.aten.gt.Scalar(convolution_default_17, 0)
        mul_tensor_17 = torch.ops.aten.mul.Tensor(convolution_default_17, 0.1)
        where_self_17 = torch.ops.aten.where.self(gt_scalar_17, convolution_default_17, mul_tensor_17);  gt_scalar_17 = mul_tensor_17 = None
        upsample_bilinear2d_vec_3 = torch.ops.aten.upsample_bilinear2d.vec(where_self_17, None, False, [2.0, 2.0]);  where_self_17 = None
        convolution_default_18 = torch.ops.aten.convolution.default(upsample_bilinear2d_vec_3, primals_86, primals_85, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_85 = None
        gt_scalar_18 = torch.ops.aten.gt.Scalar(convolution_default_18, 0)
        mul_tensor_18 = torch.ops.aten.mul.Tensor(convolution_default_18, 0.1)
        where_self_18 = torch.ops.aten.where.self(gt_scalar_18, convolution_default_18, mul_tensor_18);  gt_scalar_18 = mul_tensor_18 = None
        cat_default_4 = torch.ops.aten.cat.default([where_self_18, where_self_3], 1);  where_self_18 = None
        convolution_default_19 = torch.ops.aten.convolution.default(cat_default_4, primals_88, primals_87, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_87 = None
        gt_scalar_19 = torch.ops.aten.gt.Scalar(convolution_default_19, 0)
        mul_tensor_19 = torch.ops.aten.mul.Tensor(convolution_default_19, 0.1)
        where_self_19 = torch.ops.aten.where.self(gt_scalar_19, convolution_default_19, mul_tensor_19);  gt_scalar_19 = mul_tensor_19 = None
        upsample_bilinear2d_vec_4 = torch.ops.aten.upsample_bilinear2d.vec(where_self_19, None, False, [2.0, 2.0]);  where_self_19 = None
        convolution_default_20 = torch.ops.aten.convolution.default(upsample_bilinear2d_vec_4, primals_90, primals_89, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_89 = None
        gt_scalar_20 = torch.ops.aten.gt.Scalar(convolution_default_20, 0)
        mul_tensor_20 = torch.ops.aten.mul.Tensor(convolution_default_20, 0.1)
        where_self_20 = torch.ops.aten.where.self(gt_scalar_20, convolution_default_20, mul_tensor_20);  gt_scalar_20 = mul_tensor_20 = None
        cat_default_5 = torch.ops.aten.cat.default([where_self_20, where_self_1], 1);  where_self_20 = None
        convolution_default_21 = torch.ops.aten.convolution.default(cat_default_5, primals_92, primals_91, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_91 = None
        gt_scalar_21 = torch.ops.aten.gt.Scalar(convolution_default_21, 0)
        mul_tensor_21 = torch.ops.aten.mul.Tensor(convolution_default_21, 0.1)
        where_self_21 = torch.ops.aten.where.self(gt_scalar_21, convolution_default_21, mul_tensor_21);  gt_scalar_21 = mul_tensor_21 = None
        convolution_default_22 = torch.ops.aten.convolution.default(where_self_21, primals_52, primals_51, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_51 = None
        gt_scalar_22 = torch.ops.aten.gt.Scalar(convolution_default_22, 0)
        mul_tensor_22 = torch.ops.aten.mul.Tensor(convolution_default_22, 0.1)
        where_self_22 = torch.ops.aten.where.self(gt_scalar_22, convolution_default_22, mul_tensor_22);  gt_scalar_22 = mul_tensor_22 = None
        slice_tensor = torch.ops.aten.slice.Tensor(where_self_22, 0, 0, 9223372036854775807)
        slice_tensor_1 = torch.ops.aten.slice.Tensor(slice_tensor, 1, 0, 2);  slice_tensor = None
        slice_tensor_2 = torch.ops.aten.slice.Tensor(slice_tensor_1, 2, 0, 9223372036854775807);  slice_tensor_1 = None
        slice_tensor_3 = torch.ops.aten.slice.Tensor(slice_tensor_2, 3, 0, 9223372036854775807);  slice_tensor_2 = None
        slice_tensor_4 = torch.ops.aten.slice.Tensor(where_self_22, 0, 0, 9223372036854775807);  where_self_22 = None
        slice_tensor_5 = torch.ops.aten.slice.Tensor(slice_tensor_4, 1, 2, 9223372036854775807);  slice_tensor_4 = None
        slice_tensor_6 = torch.ops.aten.slice.Tensor(slice_tensor_5, 2, 0, 9223372036854775807);  slice_tensor_5 = None
        slice_tensor_7 = torch.ops.aten.slice.Tensor(slice_tensor_6, 3, 0, 9223372036854775807);  slice_tensor_6 = None
        linspace = torch.ops.aten.linspace.default(0.125, 0.875, 7, dtype = torch.float32, device = device(type='cuda', index=0), pin_memory = False)
        index_tensor = torch.ops.aten.index.Tensor(linspace, [primals_115])
        rsub_scalar = torch.ops.aten.rsub.Scalar(index_tensor, 1);  index_tensor = None
        neg_default = torch.ops.aten.neg.default(rsub_scalar);  rsub_scalar = None
        index_tensor_1 = torch.ops.aten.index.Tensor(linspace, [primals_115])
        mul_tensor_23 = torch.ops.aten.mul.Tensor(neg_default, index_tensor_1);  neg_default = index_tensor_1 = None
        index_tensor_2 = torch.ops.aten.index.Tensor(linspace, [primals_115])
        index_tensor_3 = torch.ops.aten.index.Tensor(linspace, [primals_115])
        mul_tensor_24 = torch.ops.aten.mul.Tensor(index_tensor_2, index_tensor_3);  index_tensor_2 = index_tensor_3 = None
        index_tensor_4 = torch.ops.aten.index.Tensor(linspace, [primals_115])
        rsub_scalar_1 = torch.ops.aten.rsub.Scalar(index_tensor_4, 1);  index_tensor_4 = None
        index_tensor_5 = torch.ops.aten.index.Tensor(linspace, [primals_115]);  linspace = None
        rsub_scalar_2 = torch.ops.aten.rsub.Scalar(index_tensor_5, 1);  index_tensor_5 = None
        mul_tensor_25 = torch.ops.aten.mul.Tensor(rsub_scalar_1, rsub_scalar_2);  rsub_scalar_1 = rsub_scalar_2 = None
        unsqueeze_default = torch.ops.aten.unsqueeze.default(mul_tensor_23, 0)
        unsqueeze_default_1 = torch.ops.aten.unsqueeze.default(unsqueeze_default, 1);  unsqueeze_default = None
        unsqueeze_default_2 = torch.ops.aten.unsqueeze.default(unsqueeze_default_1, 2);  unsqueeze_default_1 = None
        slice_tensor_8 = torch.ops.aten.slice.Tensor(unsqueeze_default_2, 3, 0, 9223372036854775807);  unsqueeze_default_2 = None
        permute_default = torch.ops.aten.permute.default(slice_tensor_8, [3, 0, 1, 2]);  slice_tensor_8 = None
        unsqueeze_default_3 = torch.ops.aten.unsqueeze.default(mul_tensor_24, 0);  mul_tensor_24 = None
        unsqueeze_default_4 = torch.ops.aten.unsqueeze.default(unsqueeze_default_3, 1);  unsqueeze_default_3 = None
        unsqueeze_default_5 = torch.ops.aten.unsqueeze.default(unsqueeze_default_4, 2);  unsqueeze_default_4 = None
        slice_tensor_9 = torch.ops.aten.slice.Tensor(unsqueeze_default_5, 3, 0, 9223372036854775807);  unsqueeze_default_5 = None
        permute_default_1 = torch.ops.aten.permute.default(slice_tensor_9, [3, 0, 1, 2]);  slice_tensor_9 = None
        unsqueeze_default_6 = torch.ops.aten.unsqueeze.default(mul_tensor_25, 0);  mul_tensor_25 = None
        unsqueeze_default_7 = torch.ops.aten.unsqueeze.default(unsqueeze_default_6, 1);  unsqueeze_default_6 = None
        unsqueeze_default_8 = torch.ops.aten.unsqueeze.default(unsqueeze_default_7, 2);  unsqueeze_default_7 = None
        slice_tensor_10 = torch.ops.aten.slice.Tensor(unsqueeze_default_8, 3, 0, 9223372036854775807);  unsqueeze_default_8 = None
        permute_default_2 = torch.ops.aten.permute.default(slice_tensor_10, [3, 0, 1, 2]);  slice_tensor_10 = None
        unsqueeze_default_9 = torch.ops.aten.unsqueeze.default(mul_tensor_23, 0);  mul_tensor_23 = None
        unsqueeze_default_10 = torch.ops.aten.unsqueeze.default(unsqueeze_default_9, 1);  unsqueeze_default_9 = None
        unsqueeze_default_11 = torch.ops.aten.unsqueeze.default(unsqueeze_default_10, 2);  unsqueeze_default_10 = None
        slice_tensor_11 = torch.ops.aten.slice.Tensor(unsqueeze_default_11, 3, 0, 9223372036854775807);  unsqueeze_default_11 = None
        permute_default_3 = torch.ops.aten.permute.default(slice_tensor_11, [3, 0, 1, 2]);  slice_tensor_11 = None
        mul_tensor_26 = torch.ops.aten.mul.Tensor(permute_default, slice_tensor_3)
        mul_tensor_27 = torch.ops.aten.mul.Tensor(permute_default_1, slice_tensor_7)
        add_tensor = torch.ops.aten.add.Tensor(mul_tensor_26, mul_tensor_27);  mul_tensor_26 = mul_tensor_27 = None
        mul_tensor_28 = torch.ops.aten.mul.Tensor(permute_default_2, slice_tensor_3)
        mul_tensor_29 = torch.ops.aten.mul.Tensor(permute_default_3, slice_tensor_7)
        add_tensor_1 = torch.ops.aten.add.Tensor(mul_tensor_28, mul_tensor_29);  mul_tensor_28 = mul_tensor_29 = None
        slice_tensor_12 = torch.ops.aten.slice.Tensor(add_tensor, 0, 0, 9223372036854775807)
        select_int = torch.ops.aten.select.int(slice_tensor_12, 1, 0);  slice_tensor_12 = None
        slice_tensor_13 = torch.ops.aten.slice.Tensor(select_int, 1, 0, 9223372036854775807);  select_int = None
        slice_tensor_14 = torch.ops.aten.slice.Tensor(slice_tensor_13, 2, 0, 9223372036854775807);  slice_tensor_13 = None
        slice_tensor_15 = torch.ops.aten.slice.Tensor(add_tensor, 0, 0, 9223372036854775807)
        select_int_1 = torch.ops.aten.select.int(slice_tensor_15, 1, 1);  slice_tensor_15 = None
        slice_tensor_16 = torch.ops.aten.slice.Tensor(select_int_1, 1, 0, 9223372036854775807);  select_int_1 = None
        slice_tensor_17 = torch.ops.aten.slice.Tensor(slice_tensor_16, 2, 0, 9223372036854775807);  slice_tensor_16 = None
        unsqueeze_default_12 = torch.ops.aten.unsqueeze.default(primals_93, 0)
        expand_default = torch.ops.aten.expand.default(unsqueeze_default_12, [6, 352, 352]);  unsqueeze_default_12 = None
        _to_copy_default = torch.ops.aten._to_copy.default(expand_default, dtype = torch.float32);  expand_default = None
        add_tensor_2 = torch.ops.aten.add.Tensor(_to_copy_default, slice_tensor_14);  _to_copy_default = slice_tensor_14 = None
        unsqueeze_default_13 = torch.ops.aten.unsqueeze.default(primals_94, 0)
        expand_default_1 = torch.ops.aten.expand.default(unsqueeze_default_13, [6, 352, 352]);  unsqueeze_default_13 = None
        _to_copy_default_1 = torch.ops.aten._to_copy.default(expand_default_1, dtype = torch.float32);  expand_default_1 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(_to_copy_default_1, slice_tensor_17);  _to_copy_default_1 = slice_tensor_17 = None
        div_tensor = torch.ops.aten.div.Tensor(add_tensor_2, 352);  add_tensor_2 = None
        sub_tensor = torch.ops.aten.sub.Tensor(div_tensor, 0.5);  div_tensor = None
        mul_tensor_30 = torch.ops.aten.mul.Tensor(sub_tensor, 2);  sub_tensor = None
        div_tensor_1 = torch.ops.aten.div.Tensor(add_tensor_3, 352);  add_tensor_3 = None
        sub_tensor_1 = torch.ops.aten.sub.Tensor(div_tensor_1, 0.5);  div_tensor_1 = None
        mul_tensor_31 = torch.ops.aten.mul.Tensor(sub_tensor_1, 2);  sub_tensor_1 = None
        stack_default = torch.ops.aten.stack.default([mul_tensor_30, mul_tensor_31], 3);  mul_tensor_30 = mul_tensor_31 = None
        grid_sampler_2d_default = torch.ops.aten.grid_sampler_2d.default(primals_116, stack_default, 0, 0, False)
        slice_tensor_18 = torch.ops.aten.slice.Tensor(add_tensor_1, 0, 0, 9223372036854775807)
        select_int_2 = torch.ops.aten.select.int(slice_tensor_18, 1, 0);  slice_tensor_18 = None
        slice_tensor_19 = torch.ops.aten.slice.Tensor(select_int_2, 1, 0, 9223372036854775807);  select_int_2 = None
        slice_tensor_20 = torch.ops.aten.slice.Tensor(slice_tensor_19, 2, 0, 9223372036854775807);  slice_tensor_19 = None
        slice_tensor_21 = torch.ops.aten.slice.Tensor(add_tensor_1, 0, 0, 9223372036854775807)
        select_int_3 = torch.ops.aten.select.int(slice_tensor_21, 1, 1);  slice_tensor_21 = None
        slice_tensor_22 = torch.ops.aten.slice.Tensor(select_int_3, 1, 0, 9223372036854775807);  select_int_3 = None
        slice_tensor_23 = torch.ops.aten.slice.Tensor(slice_tensor_22, 2, 0, 9223372036854775807);  slice_tensor_22 = None
        unsqueeze_default_14 = torch.ops.aten.unsqueeze.default(primals_93, 0)
        expand_default_2 = torch.ops.aten.expand.default(unsqueeze_default_14, [6, 352, 352]);  unsqueeze_default_14 = None
        _to_copy_default_2 = torch.ops.aten._to_copy.default(expand_default_2, dtype = torch.float32);  expand_default_2 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(_to_copy_default_2, slice_tensor_20);  _to_copy_default_2 = slice_tensor_20 = None
        unsqueeze_default_15 = torch.ops.aten.unsqueeze.default(primals_94, 0)
        expand_default_3 = torch.ops.aten.expand.default(unsqueeze_default_15, [6, 352, 352]);  unsqueeze_default_15 = None
        _to_copy_default_3 = torch.ops.aten._to_copy.default(expand_default_3, dtype = torch.float32);  expand_default_3 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(_to_copy_default_3, slice_tensor_23);  _to_copy_default_3 = slice_tensor_23 = None
        div_tensor_2 = torch.ops.aten.div.Tensor(add_tensor_4, 352);  add_tensor_4 = None
        sub_tensor_2 = torch.ops.aten.sub.Tensor(div_tensor_2, 0.5);  div_tensor_2 = None
        mul_tensor_32 = torch.ops.aten.mul.Tensor(sub_tensor_2, 2);  sub_tensor_2 = None
        div_tensor_3 = torch.ops.aten.div.Tensor(add_tensor_5, 352);  add_tensor_5 = None
        sub_tensor_3 = torch.ops.aten.sub.Tensor(div_tensor_3, 0.5);  div_tensor_3 = None
        mul_tensor_33 = torch.ops.aten.mul.Tensor(sub_tensor_3, 2);  sub_tensor_3 = None
        stack_default_1 = torch.ops.aten.stack.default([mul_tensor_32, mul_tensor_33], 3);  mul_tensor_32 = mul_tensor_33 = None
        grid_sampler_2d_default_1 = torch.ops.aten.grid_sampler_2d.default(primals_117, stack_default_1, 0, 0, False)
        cat_default_6 = torch.ops.aten.cat.default([primals_116, primals_117, slice_tensor_3, slice_tensor_7, add_tensor_1, add_tensor, grid_sampler_2d_default_1, grid_sampler_2d_default], 1)
        convolution_default_23 = torch.ops.aten.convolution.default(cat_default_6, primals_2, primals_1, [1, 1], [3, 3], [1, 1], False, [0, 0], 1);  primals_1 = None
        gt_scalar_23 = torch.ops.aten.gt.Scalar(convolution_default_23, 0)
        mul_tensor_34 = torch.ops.aten.mul.Tensor(convolution_default_23, 0.1)
        where_self_23 = torch.ops.aten.where.self(gt_scalar_23, convolution_default_23, mul_tensor_34);  gt_scalar_23 = mul_tensor_34 = None
        convolution_default_24 = torch.ops.aten.convolution.default(where_self_23, primals_4, primals_3, [1, 1], [3, 3], [1, 1], False, [0, 0], 1);  primals_3 = None
        gt_scalar_24 = torch.ops.aten.gt.Scalar(convolution_default_24, 0)
        mul_tensor_35 = torch.ops.aten.mul.Tensor(convolution_default_24, 0.1)
        where_self_24 = torch.ops.aten.where.self(gt_scalar_24, convolution_default_24, mul_tensor_35);  gt_scalar_24 = mul_tensor_35 = None
        avg_pool2d_default_5 = torch.ops.aten.avg_pool2d.default(where_self_24, [2, 2])
        convolution_default_25 = torch.ops.aten.convolution.default(avg_pool2d_default_5, primals_8, primals_7, [1, 1], [2, 2], [1, 1], False, [0, 0], 1);  primals_7 = None
        gt_scalar_25 = torch.ops.aten.gt.Scalar(convolution_default_25, 0)
        mul_tensor_36 = torch.ops.aten.mul.Tensor(convolution_default_25, 0.1)
        where_self_25 = torch.ops.aten.where.self(gt_scalar_25, convolution_default_25, mul_tensor_36);  gt_scalar_25 = mul_tensor_36 = None
        convolution_default_26 = torch.ops.aten.convolution.default(where_self_25, primals_10, primals_9, [1, 1], [2, 2], [1, 1], False, [0, 0], 1);  primals_9 = None
        gt_scalar_26 = torch.ops.aten.gt.Scalar(convolution_default_26, 0)
        mul_tensor_37 = torch.ops.aten.mul.Tensor(convolution_default_26, 0.1)
        where_self_26 = torch.ops.aten.where.self(gt_scalar_26, convolution_default_26, mul_tensor_37);  gt_scalar_26 = mul_tensor_37 = None
        avg_pool2d_default_6 = torch.ops.aten.avg_pool2d.default(where_self_26, [2, 2])
        convolution_default_27 = torch.ops.aten.convolution.default(avg_pool2d_default_6, primals_12, primals_11, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_11 = None
        gt_scalar_27 = torch.ops.aten.gt.Scalar(convolution_default_27, 0)
        mul_tensor_38 = torch.ops.aten.mul.Tensor(convolution_default_27, 0.1)
        where_self_27 = torch.ops.aten.where.self(gt_scalar_27, convolution_default_27, mul_tensor_38);  gt_scalar_27 = mul_tensor_38 = None
        convolution_default_28 = torch.ops.aten.convolution.default(where_self_27, primals_14, primals_13, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_13 = None
        gt_scalar_28 = torch.ops.aten.gt.Scalar(convolution_default_28, 0)
        mul_tensor_39 = torch.ops.aten.mul.Tensor(convolution_default_28, 0.1)
        where_self_28 = torch.ops.aten.where.self(gt_scalar_28, convolution_default_28, mul_tensor_39);  gt_scalar_28 = mul_tensor_39 = None
        avg_pool2d_default_7 = torch.ops.aten.avg_pool2d.default(where_self_28, [2, 2])
        convolution_default_29 = torch.ops.aten.convolution.default(avg_pool2d_default_7, primals_16, primals_15, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_15 = None
        gt_scalar_29 = torch.ops.aten.gt.Scalar(convolution_default_29, 0)
        mul_tensor_40 = torch.ops.aten.mul.Tensor(convolution_default_29, 0.1)
        where_self_29 = torch.ops.aten.where.self(gt_scalar_29, convolution_default_29, mul_tensor_40);  gt_scalar_29 = mul_tensor_40 = None
        convolution_default_30 = torch.ops.aten.convolution.default(where_self_29, primals_18, primals_17, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_17 = None
        gt_scalar_30 = torch.ops.aten.gt.Scalar(convolution_default_30, 0)
        mul_tensor_41 = torch.ops.aten.mul.Tensor(convolution_default_30, 0.1)
        where_self_30 = torch.ops.aten.where.self(gt_scalar_30, convolution_default_30, mul_tensor_41);  gt_scalar_30 = mul_tensor_41 = None
        avg_pool2d_default_8 = torch.ops.aten.avg_pool2d.default(where_self_30, [2, 2])
        convolution_default_31 = torch.ops.aten.convolution.default(avg_pool2d_default_8, primals_20, primals_19, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_19 = None
        gt_scalar_31 = torch.ops.aten.gt.Scalar(convolution_default_31, 0)
        mul_tensor_42 = torch.ops.aten.mul.Tensor(convolution_default_31, 0.1)
        where_self_31 = torch.ops.aten.where.self(gt_scalar_31, convolution_default_31, mul_tensor_42);  gt_scalar_31 = mul_tensor_42 = None
        convolution_default_32 = torch.ops.aten.convolution.default(where_self_31, primals_22, primals_21, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_21 = None
        gt_scalar_32 = torch.ops.aten.gt.Scalar(convolution_default_32, 0)
        mul_tensor_43 = torch.ops.aten.mul.Tensor(convolution_default_32, 0.1)
        where_self_32 = torch.ops.aten.where.self(gt_scalar_32, convolution_default_32, mul_tensor_43);  gt_scalar_32 = mul_tensor_43 = None
        avg_pool2d_default_9 = torch.ops.aten.avg_pool2d.default(where_self_32, [2, 2])
        convolution_default_33 = torch.ops.aten.convolution.default(avg_pool2d_default_9, primals_24, primals_23, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_23 = None
        gt_scalar_33 = torch.ops.aten.gt.Scalar(convolution_default_33, 0)
        mul_tensor_44 = torch.ops.aten.mul.Tensor(convolution_default_33, 0.1)
        where_self_33 = torch.ops.aten.where.self(gt_scalar_33, convolution_default_33, mul_tensor_44);  gt_scalar_33 = mul_tensor_44 = None
        convolution_default_34 = torch.ops.aten.convolution.default(where_self_33, primals_26, primals_25, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_25 = None
        gt_scalar_34 = torch.ops.aten.gt.Scalar(convolution_default_34, 0)
        mul_tensor_45 = torch.ops.aten.mul.Tensor(convolution_default_34, 0.1)
        where_self_34 = torch.ops.aten.where.self(gt_scalar_34, convolution_default_34, mul_tensor_45);  gt_scalar_34 = mul_tensor_45 = None
        upsample_bilinear2d_vec_5 = torch.ops.aten.upsample_bilinear2d.vec(where_self_34, None, False, [2.0, 2.0]);  where_self_34 = None
        convolution_default_35 = torch.ops.aten.convolution.default(upsample_bilinear2d_vec_5, primals_28, primals_27, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_27 = None
        gt_scalar_35 = torch.ops.aten.gt.Scalar(convolution_default_35, 0)
        mul_tensor_46 = torch.ops.aten.mul.Tensor(convolution_default_35, 0.1)
        where_self_35 = torch.ops.aten.where.self(gt_scalar_35, convolution_default_35, mul_tensor_46);  gt_scalar_35 = mul_tensor_46 = None
        cat_default_7 = torch.ops.aten.cat.default([where_self_35, where_self_32], 1);  where_self_35 = None
        convolution_default_36 = torch.ops.aten.convolution.default(cat_default_7, primals_30, primals_29, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_29 = None
        gt_scalar_36 = torch.ops.aten.gt.Scalar(convolution_default_36, 0)
        mul_tensor_47 = torch.ops.aten.mul.Tensor(convolution_default_36, 0.1)
        where_self_36 = torch.ops.aten.where.self(gt_scalar_36, convolution_default_36, mul_tensor_47);  gt_scalar_36 = mul_tensor_47 = None
        upsample_bilinear2d_vec_6 = torch.ops.aten.upsample_bilinear2d.vec(where_self_36, None, False, [2.0, 2.0]);  where_self_36 = None
        convolution_default_37 = torch.ops.aten.convolution.default(upsample_bilinear2d_vec_6, primals_32, primals_31, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_31 = None
        gt_scalar_37 = torch.ops.aten.gt.Scalar(convolution_default_37, 0)
        mul_tensor_48 = torch.ops.aten.mul.Tensor(convolution_default_37, 0.1)
        where_self_37 = torch.ops.aten.where.self(gt_scalar_37, convolution_default_37, mul_tensor_48);  gt_scalar_37 = mul_tensor_48 = None
        cat_default_8 = torch.ops.aten.cat.default([where_self_37, where_self_30], 1);  where_self_37 = None
        convolution_default_38 = torch.ops.aten.convolution.default(cat_default_8, primals_34, primals_33, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_33 = None
        gt_scalar_38 = torch.ops.aten.gt.Scalar(convolution_default_38, 0)
        mul_tensor_49 = torch.ops.aten.mul.Tensor(convolution_default_38, 0.1)
        where_self_38 = torch.ops.aten.where.self(gt_scalar_38, convolution_default_38, mul_tensor_49);  gt_scalar_38 = mul_tensor_49 = None
        upsample_bilinear2d_vec_7 = torch.ops.aten.upsample_bilinear2d.vec(where_self_38, None, False, [2.0, 2.0]);  where_self_38 = None
        convolution_default_39 = torch.ops.aten.convolution.default(upsample_bilinear2d_vec_7, primals_36, primals_35, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_35 = None
        gt_scalar_39 = torch.ops.aten.gt.Scalar(convolution_default_39, 0)
        mul_tensor_50 = torch.ops.aten.mul.Tensor(convolution_default_39, 0.1)
        where_self_39 = torch.ops.aten.where.self(gt_scalar_39, convolution_default_39, mul_tensor_50);  gt_scalar_39 = mul_tensor_50 = None
        cat_default_9 = torch.ops.aten.cat.default([where_self_39, where_self_28], 1);  where_self_39 = None
        convolution_default_40 = torch.ops.aten.convolution.default(cat_default_9, primals_38, primals_37, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_37 = None
        gt_scalar_40 = torch.ops.aten.gt.Scalar(convolution_default_40, 0)
        mul_tensor_51 = torch.ops.aten.mul.Tensor(convolution_default_40, 0.1)
        where_self_40 = torch.ops.aten.where.self(gt_scalar_40, convolution_default_40, mul_tensor_51);  gt_scalar_40 = mul_tensor_51 = None
        upsample_bilinear2d_vec_8 = torch.ops.aten.upsample_bilinear2d.vec(where_self_40, None, False, [2.0, 2.0]);  where_self_40 = None
        convolution_default_41 = torch.ops.aten.convolution.default(upsample_bilinear2d_vec_8, primals_40, primals_39, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_39 = None
        gt_scalar_41 = torch.ops.aten.gt.Scalar(convolution_default_41, 0)
        mul_tensor_52 = torch.ops.aten.mul.Tensor(convolution_default_41, 0.1)
        where_self_41 = torch.ops.aten.where.self(gt_scalar_41, convolution_default_41, mul_tensor_52);  gt_scalar_41 = mul_tensor_52 = None
        cat_default_10 = torch.ops.aten.cat.default([where_self_41, where_self_26], 1);  where_self_41 = None
        convolution_default_42 = torch.ops.aten.convolution.default(cat_default_10, primals_42, primals_41, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_41 = None
        gt_scalar_42 = torch.ops.aten.gt.Scalar(convolution_default_42, 0)
        mul_tensor_53 = torch.ops.aten.mul.Tensor(convolution_default_42, 0.1)
        where_self_42 = torch.ops.aten.where.self(gt_scalar_42, convolution_default_42, mul_tensor_53);  gt_scalar_42 = mul_tensor_53 = None
        upsample_bilinear2d_vec_9 = torch.ops.aten.upsample_bilinear2d.vec(where_self_42, None, False, [2.0, 2.0]);  where_self_42 = None
        convolution_default_43 = torch.ops.aten.convolution.default(upsample_bilinear2d_vec_9, primals_44, primals_43, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_43 = None
        gt_scalar_43 = torch.ops.aten.gt.Scalar(convolution_default_43, 0)
        mul_tensor_54 = torch.ops.aten.mul.Tensor(convolution_default_43, 0.1)
        where_self_43 = torch.ops.aten.where.self(gt_scalar_43, convolution_default_43, mul_tensor_54);  gt_scalar_43 = mul_tensor_54 = None
        cat_default_11 = torch.ops.aten.cat.default([where_self_43, where_self_24], 1);  where_self_43 = None
        convolution_default_44 = torch.ops.aten.convolution.default(cat_default_11, primals_46, primals_45, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_45 = None
        gt_scalar_44 = torch.ops.aten.gt.Scalar(convolution_default_44, 0)
        mul_tensor_55 = torch.ops.aten.mul.Tensor(convolution_default_44, 0.1)
        where_self_44 = torch.ops.aten.where.self(gt_scalar_44, convolution_default_44, mul_tensor_55);  gt_scalar_44 = mul_tensor_55 = None
        convolution_default_45 = torch.ops.aten.convolution.default(where_self_44, primals_6, primals_5, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_5 = None
        gt_scalar_45 = torch.ops.aten.gt.Scalar(convolution_default_45, 0)
        mul_tensor_56 = torch.ops.aten.mul.Tensor(convolution_default_45, 0.1)
        where_self_45 = torch.ops.aten.where.self(gt_scalar_45, convolution_default_45, mul_tensor_56);  gt_scalar_45 = mul_tensor_56 = None
        slice_tensor_24 = torch.ops.aten.slice.Tensor(where_self_45, 0, 0, 9223372036854775807)
        slice_tensor_25 = torch.ops.aten.slice.Tensor(slice_tensor_24, 1, 0, 2);  slice_tensor_24 = None
        slice_tensor_26 = torch.ops.aten.slice.Tensor(slice_tensor_25, 2, 0, 9223372036854775807);  slice_tensor_25 = None
        slice_tensor_27 = torch.ops.aten.slice.Tensor(slice_tensor_26, 3, 0, 9223372036854775807);  slice_tensor_26 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(slice_tensor_27, add_tensor);  slice_tensor_27 = add_tensor = None
        slice_tensor_28 = torch.ops.aten.slice.Tensor(where_self_45, 0, 0, 9223372036854775807)
        slice_tensor_29 = torch.ops.aten.slice.Tensor(slice_tensor_28, 1, 2, 4);  slice_tensor_28 = None
        slice_tensor_30 = torch.ops.aten.slice.Tensor(slice_tensor_29, 2, 0, 9223372036854775807);  slice_tensor_29 = None
        slice_tensor_31 = torch.ops.aten.slice.Tensor(slice_tensor_30, 3, 0, 9223372036854775807);  slice_tensor_30 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(slice_tensor_31, add_tensor_1);  slice_tensor_31 = add_tensor_1 = None
        slice_tensor_32 = torch.ops.aten.slice.Tensor(where_self_45, 0, 0, 9223372036854775807);  where_self_45 = None
        slice_tensor_33 = torch.ops.aten.slice.Tensor(slice_tensor_32, 1, 4, 5);  slice_tensor_32 = None
        slice_tensor_34 = torch.ops.aten.slice.Tensor(slice_tensor_33, 2, 0, 9223372036854775807);  slice_tensor_33 = None
        slice_tensor_35 = torch.ops.aten.slice.Tensor(slice_tensor_34, 3, 0, 9223372036854775807);  slice_tensor_34 = None
        sigmoid_default = torch.ops.aten.sigmoid.default(slice_tensor_35);  slice_tensor_35 = None
        rsub_scalar_3 = torch.ops.aten.rsub.Scalar(sigmoid_default, 1)
        slice_tensor_36 = torch.ops.aten.slice.Tensor(add_tensor_6, 0, 0, 9223372036854775807)
        select_int_4 = torch.ops.aten.select.int(slice_tensor_36, 1, 0);  slice_tensor_36 = None
        slice_tensor_37 = torch.ops.aten.slice.Tensor(select_int_4, 1, 0, 9223372036854775807);  select_int_4 = None
        slice_tensor_38 = torch.ops.aten.slice.Tensor(slice_tensor_37, 2, 0, 9223372036854775807);  slice_tensor_37 = None
        slice_tensor_39 = torch.ops.aten.slice.Tensor(add_tensor_6, 0, 0, 9223372036854775807);  add_tensor_6 = None
        select_int_5 = torch.ops.aten.select.int(slice_tensor_39, 1, 1);  slice_tensor_39 = None
        slice_tensor_40 = torch.ops.aten.slice.Tensor(select_int_5, 1, 0, 9223372036854775807);  select_int_5 = None
        slice_tensor_41 = torch.ops.aten.slice.Tensor(slice_tensor_40, 2, 0, 9223372036854775807);  slice_tensor_40 = None
        unsqueeze_default_16 = torch.ops.aten.unsqueeze.default(primals_93, 0)
        expand_default_4 = torch.ops.aten.expand.default(unsqueeze_default_16, [6, 352, 352]);  unsqueeze_default_16 = None
        _to_copy_default_4 = torch.ops.aten._to_copy.default(expand_default_4, dtype = torch.float32);  expand_default_4 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(_to_copy_default_4, slice_tensor_38);  _to_copy_default_4 = slice_tensor_38 = None
        unsqueeze_default_17 = torch.ops.aten.unsqueeze.default(primals_94, 0)
        expand_default_5 = torch.ops.aten.expand.default(unsqueeze_default_17, [6, 352, 352]);  unsqueeze_default_17 = None
        _to_copy_default_5 = torch.ops.aten._to_copy.default(expand_default_5, dtype = torch.float32);  expand_default_5 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(_to_copy_default_5, slice_tensor_41);  _to_copy_default_5 = slice_tensor_41 = None
        div_tensor_4 = torch.ops.aten.div.Tensor(add_tensor_8, 352);  add_tensor_8 = None
        sub_tensor_4 = torch.ops.aten.sub.Tensor(div_tensor_4, 0.5);  div_tensor_4 = None
        mul_tensor_57 = torch.ops.aten.mul.Tensor(sub_tensor_4, 2);  sub_tensor_4 = None
        div_tensor_5 = torch.ops.aten.div.Tensor(add_tensor_9, 352);  add_tensor_9 = None
        sub_tensor_5 = torch.ops.aten.sub.Tensor(div_tensor_5, 0.5);  div_tensor_5 = None
        mul_tensor_58 = torch.ops.aten.mul.Tensor(sub_tensor_5, 2);  sub_tensor_5 = None
        stack_default_2 = torch.ops.aten.stack.default([mul_tensor_57, mul_tensor_58], 3);  mul_tensor_57 = mul_tensor_58 = None
        grid_sampler_2d_default_2 = torch.ops.aten.grid_sampler_2d.default(primals_116, stack_default_2, 0, 0, False)
        slice_tensor_42 = torch.ops.aten.slice.Tensor(add_tensor_7, 0, 0, 9223372036854775807)
        select_int_6 = torch.ops.aten.select.int(slice_tensor_42, 1, 0);  slice_tensor_42 = None
        slice_tensor_43 = torch.ops.aten.slice.Tensor(select_int_6, 1, 0, 9223372036854775807);  select_int_6 = None
        slice_tensor_44 = torch.ops.aten.slice.Tensor(slice_tensor_43, 2, 0, 9223372036854775807);  slice_tensor_43 = None
        slice_tensor_45 = torch.ops.aten.slice.Tensor(add_tensor_7, 0, 0, 9223372036854775807);  add_tensor_7 = None
        select_int_7 = torch.ops.aten.select.int(slice_tensor_45, 1, 1);  slice_tensor_45 = None
        slice_tensor_46 = torch.ops.aten.slice.Tensor(select_int_7, 1, 0, 9223372036854775807);  select_int_7 = None
        slice_tensor_47 = torch.ops.aten.slice.Tensor(slice_tensor_46, 2, 0, 9223372036854775807);  slice_tensor_46 = None
        unsqueeze_default_18 = torch.ops.aten.unsqueeze.default(primals_93, 0)
        expand_default_6 = torch.ops.aten.expand.default(unsqueeze_default_18, [6, 352, 352]);  unsqueeze_default_18 = None
        _to_copy_default_6 = torch.ops.aten._to_copy.default(expand_default_6, dtype = torch.float32);  expand_default_6 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(_to_copy_default_6, slice_tensor_44);  _to_copy_default_6 = slice_tensor_44 = None
        unsqueeze_default_19 = torch.ops.aten.unsqueeze.default(primals_94, 0)
        expand_default_7 = torch.ops.aten.expand.default(unsqueeze_default_19, [6, 352, 352]);  unsqueeze_default_19 = None
        _to_copy_default_7 = torch.ops.aten._to_copy.default(expand_default_7, dtype = torch.float32);  expand_default_7 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(_to_copy_default_7, slice_tensor_47);  _to_copy_default_7 = slice_tensor_47 = None
        div_tensor_6 = torch.ops.aten.div.Tensor(add_tensor_10, 352);  add_tensor_10 = None
        sub_tensor_6 = torch.ops.aten.sub.Tensor(div_tensor_6, 0.5);  div_tensor_6 = None
        mul_tensor_59 = torch.ops.aten.mul.Tensor(sub_tensor_6, 2);  sub_tensor_6 = None
        div_tensor_7 = torch.ops.aten.div.Tensor(add_tensor_11, 352);  add_tensor_11 = None
        sub_tensor_7 = torch.ops.aten.sub.Tensor(div_tensor_7, 0.5);  div_tensor_7 = None
        mul_tensor_60 = torch.ops.aten.mul.Tensor(sub_tensor_7, 2);  sub_tensor_7 = None
        stack_default_3 = torch.ops.aten.stack.default([mul_tensor_59, mul_tensor_60], 3);  mul_tensor_59 = mul_tensor_60 = None
        grid_sampler_2d_default_3 = torch.ops.aten.grid_sampler_2d.default(primals_117, stack_default_3, 0, 0, False)
        linspace_1 = torch.ops.aten.linspace.default(0.125, 0.875, 7, dtype = torch.float32, device = device(type='cuda', index=0), pin_memory = False)
        index_tensor_6 = torch.ops.aten.index.Tensor(linspace_1, [primals_115])
        rsub_scalar_4 = torch.ops.aten.rsub.Scalar(index_tensor_6, 1);  index_tensor_6 = None
        index_tensor_7 = torch.ops.aten.index.Tensor(linspace_1, [primals_115]);  linspace_1 = primals_115 = None
        unsqueeze_default_20 = torch.ops.aten.unsqueeze.default(rsub_scalar_4, 0);  rsub_scalar_4 = None
        unsqueeze_default_21 = torch.ops.aten.unsqueeze.default(unsqueeze_default_20, 1);  unsqueeze_default_20 = None
        unsqueeze_default_22 = torch.ops.aten.unsqueeze.default(unsqueeze_default_21, 2);  unsqueeze_default_21 = None
        slice_tensor_48 = torch.ops.aten.slice.Tensor(unsqueeze_default_22, 3, 0, 9223372036854775807);  unsqueeze_default_22 = None
        permute_default_4 = torch.ops.aten.permute.default(slice_tensor_48, [3, 0, 1, 2]);  slice_tensor_48 = None
        unsqueeze_default_23 = torch.ops.aten.unsqueeze.default(index_tensor_7, 0);  index_tensor_7 = None
        unsqueeze_default_24 = torch.ops.aten.unsqueeze.default(unsqueeze_default_23, 1);  unsqueeze_default_23 = None
        unsqueeze_default_25 = torch.ops.aten.unsqueeze.default(unsqueeze_default_24, 2);  unsqueeze_default_24 = None
        slice_tensor_49 = torch.ops.aten.slice.Tensor(unsqueeze_default_25, 3, 0, 9223372036854775807);  unsqueeze_default_25 = None
        permute_default_5 = torch.ops.aten.permute.default(slice_tensor_49, [3, 0, 1, 2]);  slice_tensor_49 = None
        mul_tensor_61 = torch.ops.aten.mul.Tensor(permute_default_4, sigmoid_default)
        mul_tensor_62 = torch.ops.aten.mul.Tensor(mul_tensor_61, grid_sampler_2d_default_2)
        mul_tensor_63 = torch.ops.aten.mul.Tensor(permute_default_5, rsub_scalar_3)
        mul_tensor_64 = torch.ops.aten.mul.Tensor(mul_tensor_63, grid_sampler_2d_default_3)
        add_tensor_12 = torch.ops.aten.add.Tensor(mul_tensor_62, mul_tensor_64);  mul_tensor_62 = mul_tensor_64 = None
        mul_tensor_65 = torch.ops.aten.mul.Tensor(permute_default_4, sigmoid_default)
        mul_tensor_66 = torch.ops.aten.mul.Tensor(permute_default_5, rsub_scalar_3);  rsub_scalar_3 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(mul_tensor_65, mul_tensor_66);  mul_tensor_65 = mul_tensor_66 = None
        div_tensor_8 = torch.ops.aten.div.Tensor(add_tensor_12, add_tensor_13)
        sub_tensor_8 = torch.ops.aten.sub.Tensor(div_tensor_8, primals_118)
        abs_default = torch.ops.aten.abs.default(sub_tensor_8)
        mean_default = torch.ops.aten.mean.default(abs_default);  abs_default = None
        convolution_default_46 = torch.ops.aten.convolution.default(div_tensor_8, primals_96, primals_95, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        relu__default = torch.ops.aten.relu_.default(convolution_default_46);  convolution_default_46 = None
        convolution_default_47 = torch.ops.aten.convolution.default(relu__default, primals_108, primals_107, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        relu__default_1 = torch.ops.aten.relu_.default(convolution_default_47);  convolution_default_47 = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu__default_1, [2, 2], [2, 2])
        getitem = max_pool2d_with_indices_default[0]
        getitem_1 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_48 = torch.ops.aten.convolution.default(getitem, primals_112, primals_111, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        relu__default_2 = torch.ops.aten.relu_.default(convolution_default_48);  convolution_default_48 = None
        convolution_default_49 = torch.ops.aten.convolution.default(relu__default_2, primals_114, primals_113, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        relu__default_3 = torch.ops.aten.relu_.default(convolution_default_49);  convolution_default_49 = None
        max_pool2d_with_indices_default_1 = torch.ops.aten.max_pool2d_with_indices.default(relu__default_3, [2, 2], [2, 2])
        getitem_2 = max_pool2d_with_indices_default_1[0]
        getitem_3 = max_pool2d_with_indices_default_1[1];  max_pool2d_with_indices_default_1 = None
        convolution_default_50 = torch.ops.aten.convolution.default(getitem_2, primals_98, primals_97, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        relu__default_4 = torch.ops.aten.relu_.default(convolution_default_50);  convolution_default_50 = None
        convolution_default_51 = torch.ops.aten.convolution.default(relu__default_4, primals_100, primals_99, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        relu__default_5 = torch.ops.aten.relu_.default(convolution_default_51);  convolution_default_51 = None
        convolution_default_52 = torch.ops.aten.convolution.default(relu__default_5, primals_102, primals_101, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        relu__default_6 = torch.ops.aten.relu_.default(convolution_default_52);  convolution_default_52 = None
        max_pool2d_with_indices_default_2 = torch.ops.aten.max_pool2d_with_indices.default(relu__default_6, [2, 2], [2, 2])
        getitem_4 = max_pool2d_with_indices_default_2[0]
        getitem_5 = max_pool2d_with_indices_default_2[1];  max_pool2d_with_indices_default_2 = None
        convolution_default_53 = torch.ops.aten.convolution.default(getitem_4, primals_104, primals_103, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        relu__default_7 = torch.ops.aten.relu_.default(convolution_default_53);  convolution_default_53 = None
        convolution_default_54 = torch.ops.aten.convolution.default(relu__default_7, primals_106, primals_105, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        relu__default_8 = torch.ops.aten.relu_.default(convolution_default_54);  convolution_default_54 = None
        convolution_default_55 = torch.ops.aten.convolution.default(relu__default_8, primals_110, primals_109, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        convolution_default_56 = torch.ops.aten.convolution.default(primals_118, primals_96, primals_95, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_95 = None
        relu__default_9 = torch.ops.aten.relu_.default(convolution_default_56);  convolution_default_56 = None
        convolution_default_57 = torch.ops.aten.convolution.default(relu__default_9, primals_108, primals_107, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  relu__default_9 = primals_107 = None
        relu__default_10 = torch.ops.aten.relu_.default(convolution_default_57);  convolution_default_57 = None
        max_pool2d_with_indices_default_3 = torch.ops.aten.max_pool2d_with_indices.default(relu__default_10, [2, 2], [2, 2]);  relu__default_10 = None
        getitem_6 = max_pool2d_with_indices_default_3[0]
        getitem_7 = max_pool2d_with_indices_default_3[1];  max_pool2d_with_indices_default_3 = None
        convolution_default_58 = torch.ops.aten.convolution.default(getitem_6, primals_112, primals_111, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  getitem_6 = primals_111 = None
        relu__default_11 = torch.ops.aten.relu_.default(convolution_default_58);  convolution_default_58 = None
        convolution_default_59 = torch.ops.aten.convolution.default(relu__default_11, primals_114, primals_113, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  relu__default_11 = primals_113 = None
        relu__default_12 = torch.ops.aten.relu_.default(convolution_default_59);  convolution_default_59 = None
        max_pool2d_with_indices_default_4 = torch.ops.aten.max_pool2d_with_indices.default(relu__default_12, [2, 2], [2, 2]);  relu__default_12 = None
        getitem_8 = max_pool2d_with_indices_default_4[0]
        getitem_9 = max_pool2d_with_indices_default_4[1];  max_pool2d_with_indices_default_4 = None
        convolution_default_60 = torch.ops.aten.convolution.default(getitem_8, primals_98, primals_97, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  getitem_8 = primals_97 = None
        relu__default_13 = torch.ops.aten.relu_.default(convolution_default_60);  convolution_default_60 = None
        convolution_default_61 = torch.ops.aten.convolution.default(relu__default_13, primals_100, primals_99, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  relu__default_13 = primals_99 = None
        relu__default_14 = torch.ops.aten.relu_.default(convolution_default_61);  convolution_default_61 = None
        convolution_default_62 = torch.ops.aten.convolution.default(relu__default_14, primals_102, primals_101, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  relu__default_14 = primals_101 = None
        relu__default_15 = torch.ops.aten.relu_.default(convolution_default_62);  convolution_default_62 = None
        max_pool2d_with_indices_default_5 = torch.ops.aten.max_pool2d_with_indices.default(relu__default_15, [2, 2], [2, 2]);  relu__default_15 = None
        getitem_10 = max_pool2d_with_indices_default_5[0]
        getitem_11 = max_pool2d_with_indices_default_5[1];  max_pool2d_with_indices_default_5 = None
        convolution_default_63 = torch.ops.aten.convolution.default(getitem_10, primals_104, primals_103, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  getitem_10 = primals_103 = None
        relu__default_16 = torch.ops.aten.relu_.default(convolution_default_63);  convolution_default_63 = None
        convolution_default_64 = torch.ops.aten.convolution.default(relu__default_16, primals_106, primals_105, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  relu__default_16 = primals_105 = None
        relu__default_17 = torch.ops.aten.relu_.default(convolution_default_64);  convolution_default_64 = None
        convolution_default_65 = torch.ops.aten.convolution.default(relu__default_17, primals_110, primals_109, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  relu__default_17 = primals_109 = None
        mse_loss_default = torch.ops.aten.mse_loss.default(convolution_default_55, convolution_default_65)
        sub_tensor_9 = torch.ops.aten.sub.Tensor(grid_sampler_2d_default, primals_118);  grid_sampler_2d_default = None
        abs_default_1 = torch.ops.aten.abs.default(sub_tensor_9)
        mean_default_1 = torch.ops.aten.mean.default(abs_default_1);  abs_default_1 = None
        sub_tensor_10 = torch.ops.aten.sub.Tensor(grid_sampler_2d_default_1, primals_118);  grid_sampler_2d_default_1 = primals_118 = None
        abs_default_2 = torch.ops.aten.abs.default(sub_tensor_10)
        mean_default_2 = torch.ops.aten.mean.default(abs_default_2);  abs_default_2 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(mean_default_1, mean_default_2);  mean_default_1 = mean_default_2 = None
        slice_tensor_50 = torch.ops.aten.slice.Tensor(slice_tensor_7, 0, 0, 9223372036854775807)
        select_int_8 = torch.ops.aten.select.int(slice_tensor_50, 1, 0);  slice_tensor_50 = None
        slice_tensor_51 = torch.ops.aten.slice.Tensor(select_int_8, 1, 0, 9223372036854775807);  select_int_8 = None
        slice_tensor_52 = torch.ops.aten.slice.Tensor(slice_tensor_51, 2, 0, 9223372036854775807);  slice_tensor_51 = None
        slice_tensor_53 = torch.ops.aten.slice.Tensor(slice_tensor_7, 0, 0, 9223372036854775807)
        select_int_9 = torch.ops.aten.select.int(slice_tensor_53, 1, 1);  slice_tensor_53 = None
        slice_tensor_54 = torch.ops.aten.slice.Tensor(select_int_9, 1, 0, 9223372036854775807);  select_int_9 = None
        slice_tensor_55 = torch.ops.aten.slice.Tensor(slice_tensor_54, 2, 0, 9223372036854775807);  slice_tensor_54 = None
        unsqueeze_default_26 = torch.ops.aten.unsqueeze.default(primals_93, 0)
        expand_default_8 = torch.ops.aten.expand.default(unsqueeze_default_26, [6, 352, 352]);  unsqueeze_default_26 = None
        _to_copy_default_8 = torch.ops.aten._to_copy.default(expand_default_8, dtype = torch.float32);  expand_default_8 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(_to_copy_default_8, slice_tensor_52);  _to_copy_default_8 = slice_tensor_52 = None
        unsqueeze_default_27 = torch.ops.aten.unsqueeze.default(primals_94, 0)
        expand_default_9 = torch.ops.aten.expand.default(unsqueeze_default_27, [6, 352, 352]);  unsqueeze_default_27 = None
        _to_copy_default_9 = torch.ops.aten._to_copy.default(expand_default_9, dtype = torch.float32);  expand_default_9 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(_to_copy_default_9, slice_tensor_55);  _to_copy_default_9 = slice_tensor_55 = None
        div_tensor_9 = torch.ops.aten.div.Tensor(add_tensor_15, 352);  add_tensor_15 = None
        sub_tensor_11 = torch.ops.aten.sub.Tensor(div_tensor_9, 0.5);  div_tensor_9 = None
        mul_tensor_67 = torch.ops.aten.mul.Tensor(sub_tensor_11, 2);  sub_tensor_11 = None
        div_tensor_10 = torch.ops.aten.div.Tensor(add_tensor_16, 352);  add_tensor_16 = None
        sub_tensor_12 = torch.ops.aten.sub.Tensor(div_tensor_10, 0.5);  div_tensor_10 = None
        mul_tensor_68 = torch.ops.aten.mul.Tensor(sub_tensor_12, 2);  sub_tensor_12 = None
        stack_default_4 = torch.ops.aten.stack.default([mul_tensor_67, mul_tensor_68], 3);  mul_tensor_67 = mul_tensor_68 = None
        grid_sampler_2d_default_4 = torch.ops.aten.grid_sampler_2d.default(primals_116, stack_default_4, 0, 0, False)
        sub_tensor_13 = torch.ops.aten.sub.Tensor(grid_sampler_2d_default_4, primals_117);  grid_sampler_2d_default_4 = None
        abs_default_3 = torch.ops.aten.abs.default(sub_tensor_13)
        mean_default_3 = torch.ops.aten.mean.default(abs_default_3);  abs_default_3 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(add_tensor_14, mean_default_3);  add_tensor_14 = mean_default_3 = None
        slice_tensor_56 = torch.ops.aten.slice.Tensor(slice_tensor_3, 0, 0, 9223372036854775807)
        select_int_10 = torch.ops.aten.select.int(slice_tensor_56, 1, 0);  slice_tensor_56 = None
        slice_tensor_57 = torch.ops.aten.slice.Tensor(select_int_10, 1, 0, 9223372036854775807);  select_int_10 = None
        slice_tensor_58 = torch.ops.aten.slice.Tensor(slice_tensor_57, 2, 0, 9223372036854775807);  slice_tensor_57 = None
        slice_tensor_59 = torch.ops.aten.slice.Tensor(slice_tensor_3, 0, 0, 9223372036854775807)
        select_int_11 = torch.ops.aten.select.int(slice_tensor_59, 1, 1);  slice_tensor_59 = None
        slice_tensor_60 = torch.ops.aten.slice.Tensor(select_int_11, 1, 0, 9223372036854775807);  select_int_11 = None
        slice_tensor_61 = torch.ops.aten.slice.Tensor(slice_tensor_60, 2, 0, 9223372036854775807);  slice_tensor_60 = None
        unsqueeze_default_28 = torch.ops.aten.unsqueeze.default(primals_93, 0);  primals_93 = None
        expand_default_10 = torch.ops.aten.expand.default(unsqueeze_default_28, [6, 352, 352]);  unsqueeze_default_28 = None
        _to_copy_default_10 = torch.ops.aten._to_copy.default(expand_default_10, dtype = torch.float32);  expand_default_10 = None
        add_tensor_18 = torch.ops.aten.add.Tensor(_to_copy_default_10, slice_tensor_58);  _to_copy_default_10 = slice_tensor_58 = None
        unsqueeze_default_29 = torch.ops.aten.unsqueeze.default(primals_94, 0);  primals_94 = None
        expand_default_11 = torch.ops.aten.expand.default(unsqueeze_default_29, [6, 352, 352]);  unsqueeze_default_29 = None
        _to_copy_default_11 = torch.ops.aten._to_copy.default(expand_default_11, dtype = torch.float32);  expand_default_11 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(_to_copy_default_11, slice_tensor_61);  _to_copy_default_11 = slice_tensor_61 = None
        div_tensor_11 = torch.ops.aten.div.Tensor(add_tensor_18, 352);  add_tensor_18 = None
        sub_tensor_14 = torch.ops.aten.sub.Tensor(div_tensor_11, 0.5);  div_tensor_11 = None
        mul_tensor_69 = torch.ops.aten.mul.Tensor(sub_tensor_14, 2);  sub_tensor_14 = None
        div_tensor_12 = torch.ops.aten.div.Tensor(add_tensor_19, 352);  add_tensor_19 = None
        sub_tensor_15 = torch.ops.aten.sub.Tensor(div_tensor_12, 0.5);  div_tensor_12 = None
        mul_tensor_70 = torch.ops.aten.mul.Tensor(sub_tensor_15, 2);  sub_tensor_15 = None
        stack_default_5 = torch.ops.aten.stack.default([mul_tensor_69, mul_tensor_70], 3);  mul_tensor_69 = mul_tensor_70 = None
        grid_sampler_2d_default_5 = torch.ops.aten.grid_sampler_2d.default(primals_117, stack_default_5, 0, 0, False)
        sub_tensor_16 = torch.ops.aten.sub.Tensor(grid_sampler_2d_default_5, primals_116);  grid_sampler_2d_default_5 = None
        abs_default_4 = torch.ops.aten.abs.default(sub_tensor_16)
        mean_default_4 = torch.ops.aten.mean.default(abs_default_4);  abs_default_4 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(add_tensor_17, mean_default_4);  add_tensor_17 = mean_default_4 = None
        slice_tensor_62 = torch.ops.aten.slice.Tensor(slice_tensor_7, 0, 0, 9223372036854775807)
        slice_tensor_63 = torch.ops.aten.slice.Tensor(slice_tensor_62, 1, 0, 9223372036854775807);  slice_tensor_62 = None
        slice_tensor_64 = torch.ops.aten.slice.Tensor(slice_tensor_63, 2, 0, 9223372036854775807);  slice_tensor_63 = None
        slice_tensor_65 = torch.ops.aten.slice.Tensor(slice_tensor_64, 3, 0, -1);  slice_tensor_64 = None
        slice_tensor_66 = torch.ops.aten.slice.Tensor(slice_tensor_7, 0, 0, 9223372036854775807)
        slice_tensor_67 = torch.ops.aten.slice.Tensor(slice_tensor_66, 1, 0, 9223372036854775807);  slice_tensor_66 = None
        slice_tensor_68 = torch.ops.aten.slice.Tensor(slice_tensor_67, 2, 0, 9223372036854775807);  slice_tensor_67 = None
        slice_tensor_69 = torch.ops.aten.slice.Tensor(slice_tensor_68, 3, 1, 9223372036854775807);  slice_tensor_68 = None
        sub_tensor_17 = torch.ops.aten.sub.Tensor(slice_tensor_65, slice_tensor_69);  slice_tensor_65 = slice_tensor_69 = None
        abs_default_5 = torch.ops.aten.abs.default(sub_tensor_17)
        mean_default_5 = torch.ops.aten.mean.default(abs_default_5);  abs_default_5 = None
        slice_tensor_70 = torch.ops.aten.slice.Tensor(slice_tensor_7, 0, 0, 9223372036854775807)
        slice_tensor_71 = torch.ops.aten.slice.Tensor(slice_tensor_70, 1, 0, 9223372036854775807);  slice_tensor_70 = None
        slice_tensor_72 = torch.ops.aten.slice.Tensor(slice_tensor_71, 2, 0, -1);  slice_tensor_71 = None
        slice_tensor_73 = torch.ops.aten.slice.Tensor(slice_tensor_72, 3, 0, 9223372036854775807);  slice_tensor_72 = None
        slice_tensor_74 = torch.ops.aten.slice.Tensor(slice_tensor_7, 0, 0, 9223372036854775807);  slice_tensor_7 = None
        slice_tensor_75 = torch.ops.aten.slice.Tensor(slice_tensor_74, 1, 0, 9223372036854775807);  slice_tensor_74 = None
        slice_tensor_76 = torch.ops.aten.slice.Tensor(slice_tensor_75, 2, 1, 9223372036854775807);  slice_tensor_75 = None
        slice_tensor_77 = torch.ops.aten.slice.Tensor(slice_tensor_76, 3, 0, 9223372036854775807);  slice_tensor_76 = None
        sub_tensor_18 = torch.ops.aten.sub.Tensor(slice_tensor_73, slice_tensor_77);  slice_tensor_73 = slice_tensor_77 = None
        abs_default_6 = torch.ops.aten.abs.default(sub_tensor_18)
        mean_default_6 = torch.ops.aten.mean.default(abs_default_6);  abs_default_6 = None
        add_tensor_21 = torch.ops.aten.add.Tensor(mean_default_5, mean_default_6);  mean_default_5 = mean_default_6 = None
        slice_tensor_78 = torch.ops.aten.slice.Tensor(slice_tensor_3, 0, 0, 9223372036854775807)
        slice_tensor_79 = torch.ops.aten.slice.Tensor(slice_tensor_78, 1, 0, 9223372036854775807);  slice_tensor_78 = None
        slice_tensor_80 = torch.ops.aten.slice.Tensor(slice_tensor_79, 2, 0, 9223372036854775807);  slice_tensor_79 = None
        slice_tensor_81 = torch.ops.aten.slice.Tensor(slice_tensor_80, 3, 0, -1);  slice_tensor_80 = None
        slice_tensor_82 = torch.ops.aten.slice.Tensor(slice_tensor_3, 0, 0, 9223372036854775807)
        slice_tensor_83 = torch.ops.aten.slice.Tensor(slice_tensor_82, 1, 0, 9223372036854775807);  slice_tensor_82 = None
        slice_tensor_84 = torch.ops.aten.slice.Tensor(slice_tensor_83, 2, 0, 9223372036854775807);  slice_tensor_83 = None
        slice_tensor_85 = torch.ops.aten.slice.Tensor(slice_tensor_84, 3, 1, 9223372036854775807);  slice_tensor_84 = None
        sub_tensor_19 = torch.ops.aten.sub.Tensor(slice_tensor_81, slice_tensor_85);  slice_tensor_81 = slice_tensor_85 = None
        abs_default_7 = torch.ops.aten.abs.default(sub_tensor_19)
        mean_default_7 = torch.ops.aten.mean.default(abs_default_7);  abs_default_7 = None
        slice_tensor_86 = torch.ops.aten.slice.Tensor(slice_tensor_3, 0, 0, 9223372036854775807)
        slice_tensor_87 = torch.ops.aten.slice.Tensor(slice_tensor_86, 1, 0, 9223372036854775807);  slice_tensor_86 = None
        slice_tensor_88 = torch.ops.aten.slice.Tensor(slice_tensor_87, 2, 0, -1);  slice_tensor_87 = None
        slice_tensor_89 = torch.ops.aten.slice.Tensor(slice_tensor_88, 3, 0, 9223372036854775807);  slice_tensor_88 = None
        slice_tensor_90 = torch.ops.aten.slice.Tensor(slice_tensor_3, 0, 0, 9223372036854775807);  slice_tensor_3 = None
        slice_tensor_91 = torch.ops.aten.slice.Tensor(slice_tensor_90, 1, 0, 9223372036854775807);  slice_tensor_90 = None
        slice_tensor_92 = torch.ops.aten.slice.Tensor(slice_tensor_91, 2, 1, 9223372036854775807);  slice_tensor_91 = None
        slice_tensor_93 = torch.ops.aten.slice.Tensor(slice_tensor_92, 3, 0, 9223372036854775807);  slice_tensor_92 = None
        sub_tensor_20 = torch.ops.aten.sub.Tensor(slice_tensor_89, slice_tensor_93);  slice_tensor_89 = slice_tensor_93 = None
        abs_default_8 = torch.ops.aten.abs.default(sub_tensor_20)
        mean_default_8 = torch.ops.aten.mean.default(abs_default_8);  abs_default_8 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(mean_default_7, mean_default_8);  mean_default_7 = mean_default_8 = None
        add_tensor_23 = torch.ops.aten.add.Tensor(add_tensor_21, add_tensor_22);  add_tensor_21 = add_tensor_22 = None
        mul_tensor_71 = torch.ops.aten.mul.Tensor(mean_default, 204);  mean_default = None
        mul_tensor_72 = torch.ops.aten.mul.Tensor(add_tensor_20, 102);  add_tensor_20 = None
        add_tensor_24 = torch.ops.aten.add.Tensor(mul_tensor_71, mul_tensor_72);  mul_tensor_71 = mul_tensor_72 = None
        mul_tensor_73 = torch.ops.aten.mul.Tensor(mse_loss_default, 0.005);  mse_loss_default = None
        add_tensor_25 = torch.ops.aten.add.Tensor(add_tensor_24, mul_tensor_73);  add_tensor_24 = mul_tensor_73 = None
        add_tensor_26 = torch.ops.aten.add.Tensor(add_tensor_25, add_tensor_23);  add_tensor_25 = add_tensor_23 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(div_tensor_8, tangents_1)
        is_same_size_default_1 = torch.ops.aten.is_same_size.default(add_tensor_26, tangents_2)
        mul_tensor_74 = torch.ops.aten.mul.Tensor(tangents_2, 0.005)
        mul_tensor_75 = torch.ops.aten.mul.Tensor(tangents_2, 102)
        mul_tensor_76 = torch.ops.aten.mul.Tensor(tangents_2, 204)
        expand_default_12 = torch.ops.aten.expand.default(tangents_2, [6, 2, 351, 352])
        div_scalar = torch.ops.aten.div.Scalar(expand_default_12, 1482624);  expand_default_12 = None
        sgn_default = torch.ops.aten.sgn.default(sub_tensor_20);  sub_tensor_20 = None
        mul_tensor_77 = torch.ops.aten.mul.Tensor(div_scalar, sgn_default);  div_scalar = sgn_default = None
        neg_default_1 = torch.ops.aten.neg.default(mul_tensor_77)
        slice_backward_default = torch.ops.aten.slice_backward.default(neg_default_1, [6, 2, 351, 352], 3, 0, 9223372036854775807, 1);  neg_default_1 = None
        slice_backward_default_1 = torch.ops.aten.slice_backward.default(slice_backward_default, [6, 2, 352, 352], 2, 1, 9223372036854775807, 1);  slice_backward_default = None
        slice_backward_default_2 = torch.ops.aten.slice_backward.default(slice_backward_default_1, [6, 2, 352, 352], 1, 0, 9223372036854775807, 1);  slice_backward_default_1 = None
        slice_backward_default_3 = torch.ops.aten.slice_backward.default(slice_backward_default_2, [6, 2, 352, 352], 0, 0, 9223372036854775807, 1);  slice_backward_default_2 = None
        slice_backward_default_4 = torch.ops.aten.slice_backward.default(mul_tensor_77, [6, 2, 351, 352], 3, 0, 9223372036854775807, 1);  mul_tensor_77 = None
        slice_backward_default_5 = torch.ops.aten.slice_backward.default(slice_backward_default_4, [6, 2, 352, 352], 2, 0, -1, 1);  slice_backward_default_4 = None
        slice_backward_default_6 = torch.ops.aten.slice_backward.default(slice_backward_default_5, [6, 2, 352, 352], 1, 0, 9223372036854775807, 1);  slice_backward_default_5 = None
        slice_backward_default_7 = torch.ops.aten.slice_backward.default(slice_backward_default_6, [6, 2, 352, 352], 0, 0, 9223372036854775807, 1);  slice_backward_default_6 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(slice_backward_default_3, slice_backward_default_7);  slice_backward_default_3 = slice_backward_default_7 = None
        expand_default_13 = torch.ops.aten.expand.default(tangents_2, [6, 2, 352, 351])
        div_scalar_1 = torch.ops.aten.div.Scalar(expand_default_13, 1482624);  expand_default_13 = None
        sgn_default_1 = torch.ops.aten.sgn.default(sub_tensor_19);  sub_tensor_19 = None
        mul_tensor_78 = torch.ops.aten.mul.Tensor(div_scalar_1, sgn_default_1);  div_scalar_1 = sgn_default_1 = None
        neg_default_2 = torch.ops.aten.neg.default(mul_tensor_78)
        slice_backward_default_8 = torch.ops.aten.slice_backward.default(neg_default_2, [6, 2, 352, 352], 3, 1, 9223372036854775807, 1);  neg_default_2 = None
        slice_backward_default_9 = torch.ops.aten.slice_backward.default(slice_backward_default_8, [6, 2, 352, 352], 2, 0, 9223372036854775807, 1);  slice_backward_default_8 = None
        slice_backward_default_10 = torch.ops.aten.slice_backward.default(slice_backward_default_9, [6, 2, 352, 352], 1, 0, 9223372036854775807, 1);  slice_backward_default_9 = None
        slice_backward_default_11 = torch.ops.aten.slice_backward.default(slice_backward_default_10, [6, 2, 352, 352], 0, 0, 9223372036854775807, 1);  slice_backward_default_10 = None
        add_tensor_28 = torch.ops.aten.add.Tensor(add_tensor_27, slice_backward_default_11);  add_tensor_27 = slice_backward_default_11 = None
        slice_backward_default_12 = torch.ops.aten.slice_backward.default(mul_tensor_78, [6, 2, 352, 352], 3, 0, -1, 1);  mul_tensor_78 = None
        slice_backward_default_13 = torch.ops.aten.slice_backward.default(slice_backward_default_12, [6, 2, 352, 352], 2, 0, 9223372036854775807, 1);  slice_backward_default_12 = None
        slice_backward_default_14 = torch.ops.aten.slice_backward.default(slice_backward_default_13, [6, 2, 352, 352], 1, 0, 9223372036854775807, 1);  slice_backward_default_13 = None
        slice_backward_default_15 = torch.ops.aten.slice_backward.default(slice_backward_default_14, [6, 2, 352, 352], 0, 0, 9223372036854775807, 1);  slice_backward_default_14 = None
        add_tensor_29 = torch.ops.aten.add.Tensor(add_tensor_28, slice_backward_default_15);  add_tensor_28 = slice_backward_default_15 = None
        expand_default_14 = torch.ops.aten.expand.default(tangents_2, [6, 2, 351, 352])
        div_scalar_2 = torch.ops.aten.div.Scalar(expand_default_14, 1482624);  expand_default_14 = None
        sgn_default_2 = torch.ops.aten.sgn.default(sub_tensor_18);  sub_tensor_18 = None
        mul_tensor_79 = torch.ops.aten.mul.Tensor(div_scalar_2, sgn_default_2);  div_scalar_2 = sgn_default_2 = None
        neg_default_3 = torch.ops.aten.neg.default(mul_tensor_79)
        slice_backward_default_16 = torch.ops.aten.slice_backward.default(neg_default_3, [6, 2, 351, 352], 3, 0, 9223372036854775807, 1);  neg_default_3 = None
        slice_backward_default_17 = torch.ops.aten.slice_backward.default(slice_backward_default_16, [6, 2, 352, 352], 2, 1, 9223372036854775807, 1);  slice_backward_default_16 = None
        slice_backward_default_18 = torch.ops.aten.slice_backward.default(slice_backward_default_17, [6, 2, 352, 352], 1, 0, 9223372036854775807, 1);  slice_backward_default_17 = None
        slice_backward_default_19 = torch.ops.aten.slice_backward.default(slice_backward_default_18, [6, 2, 352, 352], 0, 0, 9223372036854775807, 1);  slice_backward_default_18 = None
        slice_backward_default_20 = torch.ops.aten.slice_backward.default(mul_tensor_79, [6, 2, 351, 352], 3, 0, 9223372036854775807, 1);  mul_tensor_79 = None
        slice_backward_default_21 = torch.ops.aten.slice_backward.default(slice_backward_default_20, [6, 2, 352, 352], 2, 0, -1, 1);  slice_backward_default_20 = None
        slice_backward_default_22 = torch.ops.aten.slice_backward.default(slice_backward_default_21, [6, 2, 352, 352], 1, 0, 9223372036854775807, 1);  slice_backward_default_21 = None
        slice_backward_default_23 = torch.ops.aten.slice_backward.default(slice_backward_default_22, [6, 2, 352, 352], 0, 0, 9223372036854775807, 1);  slice_backward_default_22 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(slice_backward_default_19, slice_backward_default_23);  slice_backward_default_19 = slice_backward_default_23 = None
        expand_default_15 = torch.ops.aten.expand.default(tangents_2, [6, 2, 352, 351]);  tangents_2 = None
        div_scalar_3 = torch.ops.aten.div.Scalar(expand_default_15, 1482624);  expand_default_15 = None
        sgn_default_3 = torch.ops.aten.sgn.default(sub_tensor_17);  sub_tensor_17 = None
        mul_tensor_80 = torch.ops.aten.mul.Tensor(div_scalar_3, sgn_default_3);  div_scalar_3 = sgn_default_3 = None
        neg_default_4 = torch.ops.aten.neg.default(mul_tensor_80)
        slice_backward_default_24 = torch.ops.aten.slice_backward.default(neg_default_4, [6, 2, 352, 352], 3, 1, 9223372036854775807, 1);  neg_default_4 = None
        slice_backward_default_25 = torch.ops.aten.slice_backward.default(slice_backward_default_24, [6, 2, 352, 352], 2, 0, 9223372036854775807, 1);  slice_backward_default_24 = None
        slice_backward_default_26 = torch.ops.aten.slice_backward.default(slice_backward_default_25, [6, 2, 352, 352], 1, 0, 9223372036854775807, 1);  slice_backward_default_25 = None
        slice_backward_default_27 = torch.ops.aten.slice_backward.default(slice_backward_default_26, [6, 2, 352, 352], 0, 0, 9223372036854775807, 1);  slice_backward_default_26 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(add_tensor_30, slice_backward_default_27);  add_tensor_30 = slice_backward_default_27 = None
        slice_backward_default_28 = torch.ops.aten.slice_backward.default(mul_tensor_80, [6, 2, 352, 352], 3, 0, -1, 1);  mul_tensor_80 = None
        slice_backward_default_29 = torch.ops.aten.slice_backward.default(slice_backward_default_28, [6, 2, 352, 352], 2, 0, 9223372036854775807, 1);  slice_backward_default_28 = None
        slice_backward_default_30 = torch.ops.aten.slice_backward.default(slice_backward_default_29, [6, 2, 352, 352], 1, 0, 9223372036854775807, 1);  slice_backward_default_29 = None
        slice_backward_default_31 = torch.ops.aten.slice_backward.default(slice_backward_default_30, [6, 2, 352, 352], 0, 0, 9223372036854775807, 1);  slice_backward_default_30 = None
        add_tensor_32 = torch.ops.aten.add.Tensor(add_tensor_31, slice_backward_default_31);  add_tensor_31 = slice_backward_default_31 = None
        expand_default_16 = torch.ops.aten.expand.default(mul_tensor_75, [6, 3, 352, 352])
        div_scalar_4 = torch.ops.aten.div.Scalar(expand_default_16, 2230272);  expand_default_16 = None
        sgn_default_4 = torch.ops.aten.sgn.default(sub_tensor_16);  sub_tensor_16 = None
        mul_tensor_81 = torch.ops.aten.mul.Tensor(div_scalar_4, sgn_default_4);  div_scalar_4 = sgn_default_4 = None
        grid_sampler_2d_backward_default = torch.ops.aten.grid_sampler_2d_backward.default(mul_tensor_81, primals_117, stack_default_5, 0, 0, False, [False, True]);  mul_tensor_81 = stack_default_5 = None
        getitem_12 = grid_sampler_2d_backward_default[0]
        getitem_13 = grid_sampler_2d_backward_default[1];  grid_sampler_2d_backward_default = None
        unbind_int = torch.ops.aten.unbind.int(getitem_13, 3);  getitem_13 = None
        getitem_14 = unbind_int[0]
        getitem_15 = unbind_int[1];  unbind_int = None
        mul_tensor_82 = torch.ops.aten.mul.Tensor(getitem_15, 2);  getitem_15 = None
        div_tensor_13 = torch.ops.aten.div.Tensor(mul_tensor_82, 352);  mul_tensor_82 = None
        mul_tensor_83 = torch.ops.aten.mul.Tensor(getitem_14, 2);  getitem_14 = None
        div_tensor_14 = torch.ops.aten.div.Tensor(mul_tensor_83, 352);  mul_tensor_83 = None
        slice_backward_default_32 = torch.ops.aten.slice_backward.default(div_tensor_13, [6, 352, 352], 2, 0, 9223372036854775807, 1);  div_tensor_13 = None
        slice_backward_default_33 = torch.ops.aten.slice_backward.default(slice_backward_default_32, [6, 352, 352], 1, 0, 9223372036854775807, 1);  slice_backward_default_32 = None
        select_backward_default = torch.ops.aten.select_backward.default(slice_backward_default_33, [6, 2, 352, 352], 1, 1);  slice_backward_default_33 = None
        slice_backward_default_34 = torch.ops.aten.slice_backward.default(select_backward_default, [6, 2, 352, 352], 0, 0, 9223372036854775807, 1);  select_backward_default = None
        add_tensor_33 = torch.ops.aten.add.Tensor(add_tensor_29, slice_backward_default_34);  add_tensor_29 = slice_backward_default_34 = None
        slice_backward_default_35 = torch.ops.aten.slice_backward.default(div_tensor_14, [6, 352, 352], 2, 0, 9223372036854775807, 1);  div_tensor_14 = None
        slice_backward_default_36 = torch.ops.aten.slice_backward.default(slice_backward_default_35, [6, 352, 352], 1, 0, 9223372036854775807, 1);  slice_backward_default_35 = None
        select_backward_default_1 = torch.ops.aten.select_backward.default(slice_backward_default_36, [6, 2, 352, 352], 1, 0);  slice_backward_default_36 = None
        slice_backward_default_37 = torch.ops.aten.slice_backward.default(select_backward_default_1, [6, 2, 352, 352], 0, 0, 9223372036854775807, 1);  select_backward_default_1 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(add_tensor_33, slice_backward_default_37);  add_tensor_33 = slice_backward_default_37 = None
        expand_default_17 = torch.ops.aten.expand.default(mul_tensor_75, [6, 3, 352, 352])
        div_scalar_5 = torch.ops.aten.div.Scalar(expand_default_17, 2230272);  expand_default_17 = None
        sgn_default_5 = torch.ops.aten.sgn.default(sub_tensor_13);  sub_tensor_13 = None
        mul_tensor_84 = torch.ops.aten.mul.Tensor(div_scalar_5, sgn_default_5);  div_scalar_5 = sgn_default_5 = None
        grid_sampler_2d_backward_default_1 = torch.ops.aten.grid_sampler_2d_backward.default(mul_tensor_84, primals_116, stack_default_4, 0, 0, False, [False, True]);  mul_tensor_84 = stack_default_4 = None
        getitem_16 = grid_sampler_2d_backward_default_1[0]
        getitem_17 = grid_sampler_2d_backward_default_1[1];  grid_sampler_2d_backward_default_1 = None
        unbind_int_1 = torch.ops.aten.unbind.int(getitem_17, 3);  getitem_17 = None
        getitem_18 = unbind_int_1[0]
        getitem_19 = unbind_int_1[1];  unbind_int_1 = None
        mul_tensor_85 = torch.ops.aten.mul.Tensor(getitem_19, 2);  getitem_19 = None
        div_tensor_15 = torch.ops.aten.div.Tensor(mul_tensor_85, 352);  mul_tensor_85 = None
        mul_tensor_86 = torch.ops.aten.mul.Tensor(getitem_18, 2);  getitem_18 = None
        div_tensor_16 = torch.ops.aten.div.Tensor(mul_tensor_86, 352);  mul_tensor_86 = None
        slice_backward_default_38 = torch.ops.aten.slice_backward.default(div_tensor_15, [6, 352, 352], 2, 0, 9223372036854775807, 1);  div_tensor_15 = None
        slice_backward_default_39 = torch.ops.aten.slice_backward.default(slice_backward_default_38, [6, 352, 352], 1, 0, 9223372036854775807, 1);  slice_backward_default_38 = None
        select_backward_default_2 = torch.ops.aten.select_backward.default(slice_backward_default_39, [6, 2, 352, 352], 1, 1);  slice_backward_default_39 = None
        slice_backward_default_40 = torch.ops.aten.slice_backward.default(select_backward_default_2, [6, 2, 352, 352], 0, 0, 9223372036854775807, 1);  select_backward_default_2 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(add_tensor_32, slice_backward_default_40);  add_tensor_32 = slice_backward_default_40 = None
        slice_backward_default_41 = torch.ops.aten.slice_backward.default(div_tensor_16, [6, 352, 352], 2, 0, 9223372036854775807, 1);  div_tensor_16 = None
        slice_backward_default_42 = torch.ops.aten.slice_backward.default(slice_backward_default_41, [6, 352, 352], 1, 0, 9223372036854775807, 1);  slice_backward_default_41 = None
        select_backward_default_3 = torch.ops.aten.select_backward.default(slice_backward_default_42, [6, 2, 352, 352], 1, 0);  slice_backward_default_42 = None
        slice_backward_default_43 = torch.ops.aten.slice_backward.default(select_backward_default_3, [6, 2, 352, 352], 0, 0, 9223372036854775807, 1);  select_backward_default_3 = None
        add_tensor_36 = torch.ops.aten.add.Tensor(add_tensor_35, slice_backward_default_43);  add_tensor_35 = slice_backward_default_43 = None
        expand_default_18 = torch.ops.aten.expand.default(mul_tensor_75, [6, 3, 352, 352])
        div_scalar_6 = torch.ops.aten.div.Scalar(expand_default_18, 2230272);  expand_default_18 = None
        sgn_default_6 = torch.ops.aten.sgn.default(sub_tensor_10);  sub_tensor_10 = None
        mul_tensor_87 = torch.ops.aten.mul.Tensor(div_scalar_6, sgn_default_6);  div_scalar_6 = sgn_default_6 = None
        expand_default_19 = torch.ops.aten.expand.default(mul_tensor_75, [6, 3, 352, 352]);  mul_tensor_75 = None
        div_scalar_7 = torch.ops.aten.div.Scalar(expand_default_19, 2230272);  expand_default_19 = None
        sgn_default_7 = torch.ops.aten.sgn.default(sub_tensor_9);  sub_tensor_9 = None
        mul_tensor_88 = torch.ops.aten.mul.Tensor(div_scalar_7, sgn_default_7);  div_scalar_7 = sgn_default_7 = None
        mse_loss_backward_default = torch.ops.aten.mse_loss_backward.default(mul_tensor_74, convolution_default_55, convolution_default_65, 1);  mul_tensor_74 = convolution_default_55 = convolution_default_65 = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(mse_loss_backward_default, relu__default_8, primals_110, [512], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, False, False]);  mse_loss_backward_default = primals_110 = None
        getitem_20 = convolution_backward_default[0]
        getitem_21 = convolution_backward_default[1]
        getitem_22 = convolution_backward_default[2];  convolution_backward_default = None
        to_dtype = torch.ops.aten.to.dtype(getitem_20, torch.float32);  getitem_20 = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_46 = torch.ops.aten.where.self(le_scalar, new_zeros_default, to_dtype);  le_scalar = new_zeros_default = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self_46, torch.float32);  where_self_46 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(to_dtype_2, relu__default_7, primals_106, [512], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, False, False]);  to_dtype_2 = primals_106 = None
        getitem_23 = convolution_backward_default_1[0]
        getitem_24 = convolution_backward_default_1[1]
        getitem_25 = convolution_backward_default_1[2];  convolution_backward_default_1 = None
        to_dtype_3 = torch.ops.aten.to.dtype(getitem_23, torch.float32);  getitem_23 = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_47 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_1, to_dtype_3);  le_scalar_1 = new_zeros_default_1 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_47, torch.float32);  where_self_47 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(to_dtype_5, getitem_4, primals_104, [512], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, False, False]);  to_dtype_5 = getitem_4 = primals_104 = None
        getitem_26 = convolution_backward_default_2[0]
        getitem_27 = convolution_backward_default_2[1]
        getitem_28 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        max_pool2d_with_indices_backward_default = torch.ops.aten.max_pool2d_with_indices_backward.default(getitem_26, relu__default_6, [2, 2], [2, 2], [0, 0], [1, 1], False, getitem_5);  getitem_26 = getitem_5 = None
        to_dtype_6 = torch.ops.aten.to.dtype(max_pool2d_with_indices_backward_default, torch.float32);  max_pool2d_with_indices_backward_default = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_2 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_48 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_2, to_dtype_6);  le_scalar_2 = new_zeros_default_2 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_48, torch.float32);  where_self_48 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(to_dtype_8, relu__default_5, primals_102, [256], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, False, False]);  to_dtype_8 = primals_102 = None
        getitem_29 = convolution_backward_default_3[0]
        getitem_30 = convolution_backward_default_3[1]
        getitem_31 = convolution_backward_default_3[2];  convolution_backward_default_3 = None
        to_dtype_9 = torch.ops.aten.to.dtype(getitem_29, torch.float32);  getitem_29 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_49 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_3, to_dtype_9);  le_scalar_3 = new_zeros_default_3 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_49, torch.float32);  where_self_49 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(to_dtype_11, relu__default_4, primals_100, [256], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, False, False]);  to_dtype_11 = primals_100 = None
        getitem_32 = convolution_backward_default_4[0]
        getitem_33 = convolution_backward_default_4[1]
        getitem_34 = convolution_backward_default_4[2];  convolution_backward_default_4 = None
        to_dtype_12 = torch.ops.aten.to.dtype(getitem_32, torch.float32);  getitem_32 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_50 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_4, to_dtype_12);  le_scalar_4 = new_zeros_default_4 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_50, torch.float32);  where_self_50 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(to_dtype_14, getitem_2, primals_98, [256], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, False, False]);  to_dtype_14 = getitem_2 = primals_98 = None
        getitem_35 = convolution_backward_default_5[0]
        getitem_36 = convolution_backward_default_5[1]
        getitem_37 = convolution_backward_default_5[2];  convolution_backward_default_5 = None
        max_pool2d_with_indices_backward_default_1 = torch.ops.aten.max_pool2d_with_indices_backward.default(getitem_35, relu__default_3, [2, 2], [2, 2], [0, 0], [1, 1], False, getitem_3);  getitem_35 = getitem_3 = None
        to_dtype_15 = torch.ops.aten.to.dtype(max_pool2d_with_indices_backward_default_1, torch.float32);  max_pool2d_with_indices_backward_default_1 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_5 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_51 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_5, to_dtype_15);  le_scalar_5 = new_zeros_default_5 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_51, torch.float32);  where_self_51 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(to_dtype_17, relu__default_2, primals_114, [128], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, False, False]);  to_dtype_17 = primals_114 = None
        getitem_38 = convolution_backward_default_6[0]
        getitem_39 = convolution_backward_default_6[1]
        getitem_40 = convolution_backward_default_6[2];  convolution_backward_default_6 = None
        to_dtype_18 = torch.ops.aten.to.dtype(getitem_38, torch.float32);  getitem_38 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_52 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_6, to_dtype_18);  le_scalar_6 = new_zeros_default_6 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_52, torch.float32);  where_self_52 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(to_dtype_20, getitem, primals_112, [128], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, False, False]);  to_dtype_20 = getitem = primals_112 = None
        getitem_41 = convolution_backward_default_7[0]
        getitem_42 = convolution_backward_default_7[1]
        getitem_43 = convolution_backward_default_7[2];  convolution_backward_default_7 = None
        max_pool2d_with_indices_backward_default_2 = torch.ops.aten.max_pool2d_with_indices_backward.default(getitem_41, relu__default_1, [2, 2], [2, 2], [0, 0], [1, 1], False, getitem_1);  getitem_41 = getitem_1 = None
        to_dtype_21 = torch.ops.aten.to.dtype(max_pool2d_with_indices_backward_default_2, torch.float32);  max_pool2d_with_indices_backward_default_2 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_53 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_7, to_dtype_21);  le_scalar_7 = new_zeros_default_7 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_53, torch.float32);  where_self_53 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(to_dtype_23, relu__default, primals_108, [64], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, False, False]);  to_dtype_23 = primals_108 = None
        getitem_44 = convolution_backward_default_8[0]
        getitem_45 = convolution_backward_default_8[1]
        getitem_46 = convolution_backward_default_8[2];  convolution_backward_default_8 = None
        to_dtype_24 = torch.ops.aten.to.dtype(getitem_44, torch.float32);  getitem_44 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_8 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_54 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_8, to_dtype_24);  le_scalar_8 = new_zeros_default_8 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_54, torch.float32);  where_self_54 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(to_dtype_26, div_tensor_8, primals_96, [64], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, False, False]);  to_dtype_26 = primals_96 = None
        getitem_47 = convolution_backward_default_9[0]
        getitem_48 = convolution_backward_default_9[1]
        getitem_49 = convolution_backward_default_9[2];  convolution_backward_default_9 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(tangents_1, getitem_47);  tangents_1 = getitem_47 = None
        expand_default_20 = torch.ops.aten.expand.default(mul_tensor_76, [6, 3, 352, 352]);  mul_tensor_76 = None
        div_scalar_8 = torch.ops.aten.div.Scalar(expand_default_20, 2230272);  expand_default_20 = None
        sgn_default_8 = torch.ops.aten.sgn.default(sub_tensor_8);  sub_tensor_8 = None
        mul_tensor_89 = torch.ops.aten.mul.Tensor(div_scalar_8, sgn_default_8);  div_scalar_8 = sgn_default_8 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(add_tensor_37, mul_tensor_89);  add_tensor_37 = mul_tensor_89 = None
        neg_default_5 = torch.ops.aten.neg.default(add_tensor_38)
        div_tensor_17 = torch.ops.aten.div.Tensor(add_tensor_12, add_tensor_13);  add_tensor_12 = None
        div_tensor_18 = torch.ops.aten.div.Tensor(div_tensor_17, add_tensor_13);  div_tensor_17 = None
        mul_tensor_90 = torch.ops.aten.mul.Tensor(neg_default_5, div_tensor_18);  neg_default_5 = div_tensor_18 = None
        div_tensor_19 = torch.ops.aten.div.Tensor(add_tensor_38, add_tensor_13);  add_tensor_38 = add_tensor_13 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(mul_tensor_90, [1], True);  mul_tensor_90 = None
        mul_tensor_91 = torch.ops.aten.mul.Tensor(sum_dim_int_list, permute_default_5)
        mul_tensor_92 = torch.ops.aten.mul.Tensor(sum_dim_int_list, permute_default_4);  sum_dim_int_list = None
        mul_tensor_93 = torch.ops.aten.mul.Tensor(div_tensor_19, mul_tensor_63);  mul_tensor_63 = None
        mul_tensor_94 = torch.ops.aten.mul.Tensor(div_tensor_19, grid_sampler_2d_default_3);  grid_sampler_2d_default_3 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(mul_tensor_94, [1], True);  mul_tensor_94 = None
        mul_tensor_95 = torch.ops.aten.mul.Tensor(sum_dim_int_list_1, permute_default_5);  sum_dim_int_list_1 = permute_default_5 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(mul_tensor_91, mul_tensor_95);  mul_tensor_91 = mul_tensor_95 = None
        mul_tensor_96 = torch.ops.aten.mul.Tensor(div_tensor_19, mul_tensor_61);  mul_tensor_61 = None
        mul_tensor_97 = torch.ops.aten.mul.Tensor(div_tensor_19, grid_sampler_2d_default_2);  div_tensor_19 = grid_sampler_2d_default_2 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(mul_tensor_97, [1], True);  mul_tensor_97 = None
        mul_tensor_98 = torch.ops.aten.mul.Tensor(sum_dim_int_list_2, permute_default_4);  sum_dim_int_list_2 = permute_default_4 = None
        add_tensor_40 = torch.ops.aten.add.Tensor(mul_tensor_92, mul_tensor_98);  mul_tensor_92 = mul_tensor_98 = None
        grid_sampler_2d_backward_default_2 = torch.ops.aten.grid_sampler_2d_backward.default(mul_tensor_93, primals_117, stack_default_3, 0, 0, False, [False, True]);  mul_tensor_93 = stack_default_3 = None
        getitem_50 = grid_sampler_2d_backward_default_2[0]
        getitem_51 = grid_sampler_2d_backward_default_2[1];  grid_sampler_2d_backward_default_2 = None
        unbind_int_2 = torch.ops.aten.unbind.int(getitem_51, 3);  getitem_51 = None
        getitem_52 = unbind_int_2[0]
        getitem_53 = unbind_int_2[1];  unbind_int_2 = None
        mul_tensor_99 = torch.ops.aten.mul.Tensor(getitem_53, 2);  getitem_53 = None
        div_tensor_20 = torch.ops.aten.div.Tensor(mul_tensor_99, 352);  mul_tensor_99 = None
        mul_tensor_100 = torch.ops.aten.mul.Tensor(getitem_52, 2);  getitem_52 = None
        div_tensor_21 = torch.ops.aten.div.Tensor(mul_tensor_100, 352);  mul_tensor_100 = None
        slice_backward_default_44 = torch.ops.aten.slice_backward.default(div_tensor_20, [6, 352, 352], 2, 0, 9223372036854775807, 1);  div_tensor_20 = None
        slice_backward_default_45 = torch.ops.aten.slice_backward.default(slice_backward_default_44, [6, 352, 352], 1, 0, 9223372036854775807, 1);  slice_backward_default_44 = None
        select_backward_default_4 = torch.ops.aten.select_backward.default(slice_backward_default_45, [6, 2, 352, 352], 1, 1);  slice_backward_default_45 = None
        slice_backward_default_46 = torch.ops.aten.slice_backward.default(select_backward_default_4, [6, 2, 352, 352], 0, 0, 9223372036854775807, 1);  select_backward_default_4 = None
        slice_backward_default_47 = torch.ops.aten.slice_backward.default(div_tensor_21, [6, 352, 352], 2, 0, 9223372036854775807, 1);  div_tensor_21 = None
        slice_backward_default_48 = torch.ops.aten.slice_backward.default(slice_backward_default_47, [6, 352, 352], 1, 0, 9223372036854775807, 1);  slice_backward_default_47 = None
        select_backward_default_5 = torch.ops.aten.select_backward.default(slice_backward_default_48, [6, 2, 352, 352], 1, 0);  slice_backward_default_48 = None
        slice_backward_default_49 = torch.ops.aten.slice_backward.default(select_backward_default_5, [6, 2, 352, 352], 0, 0, 9223372036854775807, 1);  select_backward_default_5 = None
        add_tensor_41 = torch.ops.aten.add.Tensor(slice_backward_default_46, slice_backward_default_49);  slice_backward_default_46 = slice_backward_default_49 = None
        grid_sampler_2d_backward_default_3 = torch.ops.aten.grid_sampler_2d_backward.default(mul_tensor_96, primals_116, stack_default_2, 0, 0, False, [False, True]);  mul_tensor_96 = stack_default_2 = None
        getitem_54 = grid_sampler_2d_backward_default_3[0]
        getitem_55 = grid_sampler_2d_backward_default_3[1];  grid_sampler_2d_backward_default_3 = None
        unbind_int_3 = torch.ops.aten.unbind.int(getitem_55, 3);  getitem_55 = None
        getitem_56 = unbind_int_3[0]
        getitem_57 = unbind_int_3[1];  unbind_int_3 = None
        mul_tensor_101 = torch.ops.aten.mul.Tensor(getitem_57, 2);  getitem_57 = None
        div_tensor_22 = torch.ops.aten.div.Tensor(mul_tensor_101, 352);  mul_tensor_101 = None
        mul_tensor_102 = torch.ops.aten.mul.Tensor(getitem_56, 2);  getitem_56 = None
        div_tensor_23 = torch.ops.aten.div.Tensor(mul_tensor_102, 352);  mul_tensor_102 = None
        slice_backward_default_50 = torch.ops.aten.slice_backward.default(div_tensor_22, [6, 352, 352], 2, 0, 9223372036854775807, 1);  div_tensor_22 = None
        slice_backward_default_51 = torch.ops.aten.slice_backward.default(slice_backward_default_50, [6, 352, 352], 1, 0, 9223372036854775807, 1);  slice_backward_default_50 = None
        select_backward_default_6 = torch.ops.aten.select_backward.default(slice_backward_default_51, [6, 2, 352, 352], 1, 1);  slice_backward_default_51 = None
        slice_backward_default_52 = torch.ops.aten.slice_backward.default(select_backward_default_6, [6, 2, 352, 352], 0, 0, 9223372036854775807, 1);  select_backward_default_6 = None
        slice_backward_default_53 = torch.ops.aten.slice_backward.default(div_tensor_23, [6, 352, 352], 2, 0, 9223372036854775807, 1);  div_tensor_23 = None
        slice_backward_default_54 = torch.ops.aten.slice_backward.default(slice_backward_default_53, [6, 352, 352], 1, 0, 9223372036854775807, 1);  slice_backward_default_53 = None
        select_backward_default_7 = torch.ops.aten.select_backward.default(slice_backward_default_54, [6, 2, 352, 352], 1, 0);  slice_backward_default_54 = None
        slice_backward_default_55 = torch.ops.aten.slice_backward.default(select_backward_default_7, [6, 2, 352, 352], 0, 0, 9223372036854775807, 1);  select_backward_default_7 = None
        add_tensor_42 = torch.ops.aten.add.Tensor(slice_backward_default_52, slice_backward_default_55);  slice_backward_default_52 = slice_backward_default_55 = None
        neg_default_6 = torch.ops.aten.neg.default(add_tensor_39);  add_tensor_39 = None
        add_tensor_43 = torch.ops.aten.add.Tensor(add_tensor_40, neg_default_6);  add_tensor_40 = neg_default_6 = None
        to_dtype_27 = torch.ops.aten.to.dtype(add_tensor_43, torch.float32);  add_tensor_43 = None
        to_dtype_28 = torch.ops.aten.to.dtype(sigmoid_default, torch.float32);  sigmoid_default = None
        rsub_scalar_5 = torch.ops.aten.rsub.Scalar(to_dtype_28, 1)
        mul_tensor_103 = torch.ops.aten.mul.Tensor(to_dtype_28, rsub_scalar_5);  to_dtype_28 = rsub_scalar_5 = None
        conj_physical_default = torch.ops.aten.conj_physical.default(mul_tensor_103);  mul_tensor_103 = None
        mul_tensor_104 = torch.ops.aten.mul.Tensor(to_dtype_27, conj_physical_default);  to_dtype_27 = conj_physical_default = None
        to_dtype_29 = torch.ops.aten.to.dtype(mul_tensor_104, torch.float32);  mul_tensor_104 = None
        slice_backward_default_56 = torch.ops.aten.slice_backward.default(to_dtype_29, [6, 1, 352, 352], 3, 0, 9223372036854775807, 1);  to_dtype_29 = None
        slice_backward_default_57 = torch.ops.aten.slice_backward.default(slice_backward_default_56, [6, 1, 352, 352], 2, 0, 9223372036854775807, 1);  slice_backward_default_56 = None
        slice_backward_default_58 = torch.ops.aten.slice_backward.default(slice_backward_default_57, [6, 5, 352, 352], 1, 4, 5, 1);  slice_backward_default_57 = None
        slice_backward_default_59 = torch.ops.aten.slice_backward.default(slice_backward_default_58, [6, 5, 352, 352], 0, 0, 9223372036854775807, 1);  slice_backward_default_58 = None
        slice_backward_default_60 = torch.ops.aten.slice_backward.default(add_tensor_41, [6, 2, 352, 352], 3, 0, 9223372036854775807, 1)
        slice_backward_default_61 = torch.ops.aten.slice_backward.default(slice_backward_default_60, [6, 2, 352, 352], 2, 0, 9223372036854775807, 1);  slice_backward_default_60 = None
        slice_backward_default_62 = torch.ops.aten.slice_backward.default(slice_backward_default_61, [6, 5, 352, 352], 1, 2, 4, 1);  slice_backward_default_61 = None
        slice_backward_default_63 = torch.ops.aten.slice_backward.default(slice_backward_default_62, [6, 5, 352, 352], 0, 0, 9223372036854775807, 1);  slice_backward_default_62 = None
        add_tensor_44 = torch.ops.aten.add.Tensor(slice_backward_default_59, slice_backward_default_63);  slice_backward_default_59 = slice_backward_default_63 = None
        slice_backward_default_64 = torch.ops.aten.slice_backward.default(add_tensor_42, [6, 2, 352, 352], 3, 0, 9223372036854775807, 1)
        slice_backward_default_65 = torch.ops.aten.slice_backward.default(slice_backward_default_64, [6, 2, 352, 352], 2, 0, 9223372036854775807, 1);  slice_backward_default_64 = None
        slice_backward_default_66 = torch.ops.aten.slice_backward.default(slice_backward_default_65, [6, 5, 352, 352], 1, 0, 2, 1);  slice_backward_default_65 = None
        slice_backward_default_67 = torch.ops.aten.slice_backward.default(slice_backward_default_66, [6, 5, 352, 352], 0, 0, 9223372036854775807, 1);  slice_backward_default_66 = None
        add_tensor_45 = torch.ops.aten.add.Tensor(add_tensor_44, slice_backward_default_67);  add_tensor_44 = slice_backward_default_67 = None
        to_dtype_30 = torch.ops.aten.to.dtype(add_tensor_45, torch.float32);  add_tensor_45 = None
        to_dtype_31 = torch.ops.aten.to.dtype(convolution_default_45, torch.float32);  convolution_default_45 = None
        gt_scalar_46 = torch.ops.aten.gt.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        mul_tensor_105 = torch.ops.aten.mul.Tensor(to_dtype_30, 0.1)
        where_self_55 = torch.ops.aten.where.self(gt_scalar_46, to_dtype_30, mul_tensor_105);  gt_scalar_46 = to_dtype_30 = mul_tensor_105 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_55, torch.float32);  where_self_55 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(to_dtype_32, where_self_44, primals_6, [5], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_32 = where_self_44 = primals_6 = None
        getitem_58 = convolution_backward_default_10[0]
        getitem_59 = convolution_backward_default_10[1]
        getitem_60 = convolution_backward_default_10[2];  convolution_backward_default_10 = None
        to_dtype_33 = torch.ops.aten.to.dtype(getitem_58, torch.float32);  getitem_58 = None
        to_dtype_34 = torch.ops.aten.to.dtype(convolution_default_44, torch.float32);  convolution_default_44 = None
        gt_scalar_47 = torch.ops.aten.gt.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        mul_tensor_106 = torch.ops.aten.mul.Tensor(to_dtype_33, 0.1)
        where_self_56 = torch.ops.aten.where.self(gt_scalar_47, to_dtype_33, mul_tensor_106);  gt_scalar_47 = to_dtype_33 = mul_tensor_106 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_56, torch.float32);  where_self_56 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(to_dtype_35, cat_default_11, primals_46, [32], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_35 = cat_default_11 = primals_46 = None
        getitem_61 = convolution_backward_default_11[0]
        getitem_62 = convolution_backward_default_11[1]
        getitem_63 = convolution_backward_default_11[2];  convolution_backward_default_11 = None
        slice_tensor_94 = torch.ops.aten.slice.Tensor(getitem_61, 1, 0, 32)
        slice_tensor_95 = torch.ops.aten.slice.Tensor(getitem_61, 1, 32, 64);  getitem_61 = None
        to_dtype_36 = torch.ops.aten.to.dtype(slice_tensor_94, torch.float32);  slice_tensor_94 = None
        to_dtype_37 = torch.ops.aten.to.dtype(convolution_default_43, torch.float32);  convolution_default_43 = None
        gt_scalar_48 = torch.ops.aten.gt.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        mul_tensor_107 = torch.ops.aten.mul.Tensor(to_dtype_36, 0.1)
        where_self_57 = torch.ops.aten.where.self(gt_scalar_48, to_dtype_36, mul_tensor_107);  gt_scalar_48 = to_dtype_36 = mul_tensor_107 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_57, torch.float32);  where_self_57 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(to_dtype_38, upsample_bilinear2d_vec_9, primals_44, [32], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_38 = upsample_bilinear2d_vec_9 = primals_44 = None
        getitem_64 = convolution_backward_default_12[0]
        getitem_65 = convolution_backward_default_12[1]
        getitem_66 = convolution_backward_default_12[2];  convolution_backward_default_12 = None
        upsample_bilinear2d_backward_vec = torch.ops.aten.upsample_bilinear2d_backward.vec(getitem_64, None, [6, 64, 176, 176], False, [2.0, 2.0]);  getitem_64 = None
        to_dtype_39 = torch.ops.aten.to.dtype(upsample_bilinear2d_backward_vec, torch.float32);  upsample_bilinear2d_backward_vec = None
        to_dtype_40 = torch.ops.aten.to.dtype(convolution_default_42, torch.float32);  convolution_default_42 = None
        gt_scalar_49 = torch.ops.aten.gt.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        mul_tensor_108 = torch.ops.aten.mul.Tensor(to_dtype_39, 0.1)
        where_self_58 = torch.ops.aten.where.self(gt_scalar_49, to_dtype_39, mul_tensor_108);  gt_scalar_49 = to_dtype_39 = mul_tensor_108 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_58, torch.float32);  where_self_58 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(to_dtype_41, cat_default_10, primals_42, [64], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_41 = cat_default_10 = primals_42 = None
        getitem_67 = convolution_backward_default_13[0]
        getitem_68 = convolution_backward_default_13[1]
        getitem_69 = convolution_backward_default_13[2];  convolution_backward_default_13 = None
        slice_tensor_96 = torch.ops.aten.slice.Tensor(getitem_67, 1, 0, 64)
        slice_tensor_97 = torch.ops.aten.slice.Tensor(getitem_67, 1, 64, 128);  getitem_67 = None
        to_dtype_42 = torch.ops.aten.to.dtype(slice_tensor_96, torch.float32);  slice_tensor_96 = None
        to_dtype_43 = torch.ops.aten.to.dtype(convolution_default_41, torch.float32);  convolution_default_41 = None
        gt_scalar_50 = torch.ops.aten.gt.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        mul_tensor_109 = torch.ops.aten.mul.Tensor(to_dtype_42, 0.1)
        where_self_59 = torch.ops.aten.where.self(gt_scalar_50, to_dtype_42, mul_tensor_109);  gt_scalar_50 = to_dtype_42 = mul_tensor_109 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_59, torch.float32);  where_self_59 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(to_dtype_44, upsample_bilinear2d_vec_8, primals_40, [64], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_44 = upsample_bilinear2d_vec_8 = primals_40 = None
        getitem_70 = convolution_backward_default_14[0]
        getitem_71 = convolution_backward_default_14[1]
        getitem_72 = convolution_backward_default_14[2];  convolution_backward_default_14 = None
        upsample_bilinear2d_backward_vec_1 = torch.ops.aten.upsample_bilinear2d_backward.vec(getitem_70, None, [6, 128, 88, 88], False, [2.0, 2.0]);  getitem_70 = None
        to_dtype_45 = torch.ops.aten.to.dtype(upsample_bilinear2d_backward_vec_1, torch.float32);  upsample_bilinear2d_backward_vec_1 = None
        to_dtype_46 = torch.ops.aten.to.dtype(convolution_default_40, torch.float32);  convolution_default_40 = None
        gt_scalar_51 = torch.ops.aten.gt.Scalar(to_dtype_46, 0);  to_dtype_46 = None
        mul_tensor_110 = torch.ops.aten.mul.Tensor(to_dtype_45, 0.1)
        where_self_60 = torch.ops.aten.where.self(gt_scalar_51, to_dtype_45, mul_tensor_110);  gt_scalar_51 = to_dtype_45 = mul_tensor_110 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_60, torch.float32);  where_self_60 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(to_dtype_47, cat_default_9, primals_38, [128], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_47 = cat_default_9 = primals_38 = None
        getitem_73 = convolution_backward_default_15[0]
        getitem_74 = convolution_backward_default_15[1]
        getitem_75 = convolution_backward_default_15[2];  convolution_backward_default_15 = None
        slice_tensor_98 = torch.ops.aten.slice.Tensor(getitem_73, 1, 0, 128)
        slice_tensor_99 = torch.ops.aten.slice.Tensor(getitem_73, 1, 128, 256);  getitem_73 = None
        to_dtype_48 = torch.ops.aten.to.dtype(slice_tensor_98, torch.float32);  slice_tensor_98 = None
        to_dtype_49 = torch.ops.aten.to.dtype(convolution_default_39, torch.float32);  convolution_default_39 = None
        gt_scalar_52 = torch.ops.aten.gt.Scalar(to_dtype_49, 0);  to_dtype_49 = None
        mul_tensor_111 = torch.ops.aten.mul.Tensor(to_dtype_48, 0.1)
        where_self_61 = torch.ops.aten.where.self(gt_scalar_52, to_dtype_48, mul_tensor_111);  gt_scalar_52 = to_dtype_48 = mul_tensor_111 = None
        to_dtype_50 = torch.ops.aten.to.dtype(where_self_61, torch.float32);  where_self_61 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(to_dtype_50, upsample_bilinear2d_vec_7, primals_36, [128], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_50 = upsample_bilinear2d_vec_7 = primals_36 = None
        getitem_76 = convolution_backward_default_16[0]
        getitem_77 = convolution_backward_default_16[1]
        getitem_78 = convolution_backward_default_16[2];  convolution_backward_default_16 = None
        upsample_bilinear2d_backward_vec_2 = torch.ops.aten.upsample_bilinear2d_backward.vec(getitem_76, None, [6, 256, 44, 44], False, [2.0, 2.0]);  getitem_76 = None
        to_dtype_51 = torch.ops.aten.to.dtype(upsample_bilinear2d_backward_vec_2, torch.float32);  upsample_bilinear2d_backward_vec_2 = None
        to_dtype_52 = torch.ops.aten.to.dtype(convolution_default_38, torch.float32);  convolution_default_38 = None
        gt_scalar_53 = torch.ops.aten.gt.Scalar(to_dtype_52, 0);  to_dtype_52 = None
        mul_tensor_112 = torch.ops.aten.mul.Tensor(to_dtype_51, 0.1)
        where_self_62 = torch.ops.aten.where.self(gt_scalar_53, to_dtype_51, mul_tensor_112);  gt_scalar_53 = to_dtype_51 = mul_tensor_112 = None
        to_dtype_53 = torch.ops.aten.to.dtype(where_self_62, torch.float32);  where_self_62 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(to_dtype_53, cat_default_8, primals_34, [256], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_53 = cat_default_8 = primals_34 = None
        getitem_79 = convolution_backward_default_17[0]
        getitem_80 = convolution_backward_default_17[1]
        getitem_81 = convolution_backward_default_17[2];  convolution_backward_default_17 = None
        slice_tensor_100 = torch.ops.aten.slice.Tensor(getitem_79, 1, 0, 256)
        slice_tensor_101 = torch.ops.aten.slice.Tensor(getitem_79, 1, 256, 512);  getitem_79 = None
        to_dtype_54 = torch.ops.aten.to.dtype(slice_tensor_100, torch.float32);  slice_tensor_100 = None
        to_dtype_55 = torch.ops.aten.to.dtype(convolution_default_37, torch.float32);  convolution_default_37 = None
        gt_scalar_54 = torch.ops.aten.gt.Scalar(to_dtype_55, 0);  to_dtype_55 = None
        mul_tensor_113 = torch.ops.aten.mul.Tensor(to_dtype_54, 0.1)
        where_self_63 = torch.ops.aten.where.self(gt_scalar_54, to_dtype_54, mul_tensor_113);  gt_scalar_54 = to_dtype_54 = mul_tensor_113 = None
        to_dtype_56 = torch.ops.aten.to.dtype(where_self_63, torch.float32);  where_self_63 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(to_dtype_56, upsample_bilinear2d_vec_6, primals_32, [256], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_56 = upsample_bilinear2d_vec_6 = primals_32 = None
        getitem_82 = convolution_backward_default_18[0]
        getitem_83 = convolution_backward_default_18[1]
        getitem_84 = convolution_backward_default_18[2];  convolution_backward_default_18 = None
        upsample_bilinear2d_backward_vec_3 = torch.ops.aten.upsample_bilinear2d_backward.vec(getitem_82, None, [6, 512, 22, 22], False, [2.0, 2.0]);  getitem_82 = None
        to_dtype_57 = torch.ops.aten.to.dtype(upsample_bilinear2d_backward_vec_3, torch.float32);  upsample_bilinear2d_backward_vec_3 = None
        to_dtype_58 = torch.ops.aten.to.dtype(convolution_default_36, torch.float32);  convolution_default_36 = None
        gt_scalar_55 = torch.ops.aten.gt.Scalar(to_dtype_58, 0);  to_dtype_58 = None
        mul_tensor_114 = torch.ops.aten.mul.Tensor(to_dtype_57, 0.1)
        where_self_64 = torch.ops.aten.where.self(gt_scalar_55, to_dtype_57, mul_tensor_114);  gt_scalar_55 = to_dtype_57 = mul_tensor_114 = None
        to_dtype_59 = torch.ops.aten.to.dtype(where_self_64, torch.float32);  where_self_64 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(to_dtype_59, cat_default_7, primals_30, [512], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_59 = cat_default_7 = primals_30 = None
        getitem_85 = convolution_backward_default_19[0]
        getitem_86 = convolution_backward_default_19[1]
        getitem_87 = convolution_backward_default_19[2];  convolution_backward_default_19 = None
        slice_tensor_102 = torch.ops.aten.slice.Tensor(getitem_85, 1, 0, 512)
        slice_tensor_103 = torch.ops.aten.slice.Tensor(getitem_85, 1, 512, 1024);  getitem_85 = None
        to_dtype_60 = torch.ops.aten.to.dtype(slice_tensor_102, torch.float32);  slice_tensor_102 = None
        to_dtype_61 = torch.ops.aten.to.dtype(convolution_default_35, torch.float32);  convolution_default_35 = None
        gt_scalar_56 = torch.ops.aten.gt.Scalar(to_dtype_61, 0);  to_dtype_61 = None
        mul_tensor_115 = torch.ops.aten.mul.Tensor(to_dtype_60, 0.1)
        where_self_65 = torch.ops.aten.where.self(gt_scalar_56, to_dtype_60, mul_tensor_115);  gt_scalar_56 = to_dtype_60 = mul_tensor_115 = None
        to_dtype_62 = torch.ops.aten.to.dtype(where_self_65, torch.float32);  where_self_65 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(to_dtype_62, upsample_bilinear2d_vec_5, primals_28, [512], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_62 = upsample_bilinear2d_vec_5 = primals_28 = None
        getitem_88 = convolution_backward_default_20[0]
        getitem_89 = convolution_backward_default_20[1]
        getitem_90 = convolution_backward_default_20[2];  convolution_backward_default_20 = None
        upsample_bilinear2d_backward_vec_4 = torch.ops.aten.upsample_bilinear2d_backward.vec(getitem_88, None, [6, 512, 11, 11], False, [2.0, 2.0]);  getitem_88 = None
        to_dtype_63 = torch.ops.aten.to.dtype(upsample_bilinear2d_backward_vec_4, torch.float32);  upsample_bilinear2d_backward_vec_4 = None
        to_dtype_64 = torch.ops.aten.to.dtype(convolution_default_34, torch.float32);  convolution_default_34 = None
        gt_scalar_57 = torch.ops.aten.gt.Scalar(to_dtype_64, 0);  to_dtype_64 = None
        mul_tensor_116 = torch.ops.aten.mul.Tensor(to_dtype_63, 0.1)
        where_self_66 = torch.ops.aten.where.self(gt_scalar_57, to_dtype_63, mul_tensor_116);  gt_scalar_57 = to_dtype_63 = mul_tensor_116 = None
        to_dtype_65 = torch.ops.aten.to.dtype(where_self_66, torch.float32);  where_self_66 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(to_dtype_65, where_self_33, primals_26, [512], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_65 = where_self_33 = primals_26 = None
        getitem_91 = convolution_backward_default_21[0]
        getitem_92 = convolution_backward_default_21[1]
        getitem_93 = convolution_backward_default_21[2];  convolution_backward_default_21 = None
        to_dtype_66 = torch.ops.aten.to.dtype(getitem_91, torch.float32);  getitem_91 = None
        to_dtype_67 = torch.ops.aten.to.dtype(convolution_default_33, torch.float32);  convolution_default_33 = None
        gt_scalar_58 = torch.ops.aten.gt.Scalar(to_dtype_67, 0);  to_dtype_67 = None
        mul_tensor_117 = torch.ops.aten.mul.Tensor(to_dtype_66, 0.1)
        where_self_67 = torch.ops.aten.where.self(gt_scalar_58, to_dtype_66, mul_tensor_117);  gt_scalar_58 = to_dtype_66 = mul_tensor_117 = None
        to_dtype_68 = torch.ops.aten.to.dtype(where_self_67, torch.float32);  where_self_67 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(to_dtype_68, avg_pool2d_default_9, primals_24, [512], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_68 = avg_pool2d_default_9 = primals_24 = None
        getitem_94 = convolution_backward_default_22[0]
        getitem_95 = convolution_backward_default_22[1]
        getitem_96 = convolution_backward_default_22[2];  convolution_backward_default_22 = None
        avg_pool2d_backward_default = torch.ops.aten.avg_pool2d_backward.default(getitem_94, where_self_32, [2, 2], [], [0, 0], False, True, None);  getitem_94 = where_self_32 = None
        add_tensor_46 = torch.ops.aten.add.Tensor(slice_tensor_103, avg_pool2d_backward_default);  slice_tensor_103 = avg_pool2d_backward_default = None
        to_dtype_69 = torch.ops.aten.to.dtype(add_tensor_46, torch.float32);  add_tensor_46 = None
        to_dtype_70 = torch.ops.aten.to.dtype(convolution_default_32, torch.float32);  convolution_default_32 = None
        gt_scalar_59 = torch.ops.aten.gt.Scalar(to_dtype_70, 0);  to_dtype_70 = None
        mul_tensor_118 = torch.ops.aten.mul.Tensor(to_dtype_69, 0.1)
        where_self_68 = torch.ops.aten.where.self(gt_scalar_59, to_dtype_69, mul_tensor_118);  gt_scalar_59 = to_dtype_69 = mul_tensor_118 = None
        to_dtype_71 = torch.ops.aten.to.dtype(where_self_68, torch.float32);  where_self_68 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(to_dtype_71, where_self_31, primals_22, [512], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_71 = where_self_31 = primals_22 = None
        getitem_97 = convolution_backward_default_23[0]
        getitem_98 = convolution_backward_default_23[1]
        getitem_99 = convolution_backward_default_23[2];  convolution_backward_default_23 = None
        to_dtype_72 = torch.ops.aten.to.dtype(getitem_97, torch.float32);  getitem_97 = None
        to_dtype_73 = torch.ops.aten.to.dtype(convolution_default_31, torch.float32);  convolution_default_31 = None
        gt_scalar_60 = torch.ops.aten.gt.Scalar(to_dtype_73, 0);  to_dtype_73 = None
        mul_tensor_119 = torch.ops.aten.mul.Tensor(to_dtype_72, 0.1)
        where_self_69 = torch.ops.aten.where.self(gt_scalar_60, to_dtype_72, mul_tensor_119);  gt_scalar_60 = to_dtype_72 = mul_tensor_119 = None
        to_dtype_74 = torch.ops.aten.to.dtype(where_self_69, torch.float32);  where_self_69 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(to_dtype_74, avg_pool2d_default_8, primals_20, [512], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_74 = avg_pool2d_default_8 = primals_20 = None
        getitem_100 = convolution_backward_default_24[0]
        getitem_101 = convolution_backward_default_24[1]
        getitem_102 = convolution_backward_default_24[2];  convolution_backward_default_24 = None
        avg_pool2d_backward_default_1 = torch.ops.aten.avg_pool2d_backward.default(getitem_100, where_self_30, [2, 2], [], [0, 0], False, True, None);  getitem_100 = where_self_30 = None
        add_tensor_47 = torch.ops.aten.add.Tensor(slice_tensor_101, avg_pool2d_backward_default_1);  slice_tensor_101 = avg_pool2d_backward_default_1 = None
        to_dtype_75 = torch.ops.aten.to.dtype(add_tensor_47, torch.float32);  add_tensor_47 = None
        to_dtype_76 = torch.ops.aten.to.dtype(convolution_default_30, torch.float32);  convolution_default_30 = None
        gt_scalar_61 = torch.ops.aten.gt.Scalar(to_dtype_76, 0);  to_dtype_76 = None
        mul_tensor_120 = torch.ops.aten.mul.Tensor(to_dtype_75, 0.1)
        where_self_70 = torch.ops.aten.where.self(gt_scalar_61, to_dtype_75, mul_tensor_120);  gt_scalar_61 = to_dtype_75 = mul_tensor_120 = None
        to_dtype_77 = torch.ops.aten.to.dtype(where_self_70, torch.float32);  where_self_70 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(to_dtype_77, where_self_29, primals_18, [256], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_77 = where_self_29 = primals_18 = None
        getitem_103 = convolution_backward_default_25[0]
        getitem_104 = convolution_backward_default_25[1]
        getitem_105 = convolution_backward_default_25[2];  convolution_backward_default_25 = None
        to_dtype_78 = torch.ops.aten.to.dtype(getitem_103, torch.float32);  getitem_103 = None
        to_dtype_79 = torch.ops.aten.to.dtype(convolution_default_29, torch.float32);  convolution_default_29 = None
        gt_scalar_62 = torch.ops.aten.gt.Scalar(to_dtype_79, 0);  to_dtype_79 = None
        mul_tensor_121 = torch.ops.aten.mul.Tensor(to_dtype_78, 0.1)
        where_self_71 = torch.ops.aten.where.self(gt_scalar_62, to_dtype_78, mul_tensor_121);  gt_scalar_62 = to_dtype_78 = mul_tensor_121 = None
        to_dtype_80 = torch.ops.aten.to.dtype(where_self_71, torch.float32);  where_self_71 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(to_dtype_80, avg_pool2d_default_7, primals_16, [256], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_80 = avg_pool2d_default_7 = primals_16 = None
        getitem_106 = convolution_backward_default_26[0]
        getitem_107 = convolution_backward_default_26[1]
        getitem_108 = convolution_backward_default_26[2];  convolution_backward_default_26 = None
        avg_pool2d_backward_default_2 = torch.ops.aten.avg_pool2d_backward.default(getitem_106, where_self_28, [2, 2], [], [0, 0], False, True, None);  getitem_106 = where_self_28 = None
        add_tensor_48 = torch.ops.aten.add.Tensor(slice_tensor_99, avg_pool2d_backward_default_2);  slice_tensor_99 = avg_pool2d_backward_default_2 = None
        to_dtype_81 = torch.ops.aten.to.dtype(add_tensor_48, torch.float32);  add_tensor_48 = None
        to_dtype_82 = torch.ops.aten.to.dtype(convolution_default_28, torch.float32);  convolution_default_28 = None
        gt_scalar_63 = torch.ops.aten.gt.Scalar(to_dtype_82, 0);  to_dtype_82 = None
        mul_tensor_122 = torch.ops.aten.mul.Tensor(to_dtype_81, 0.1)
        where_self_72 = torch.ops.aten.where.self(gt_scalar_63, to_dtype_81, mul_tensor_122);  gt_scalar_63 = to_dtype_81 = mul_tensor_122 = None
        to_dtype_83 = torch.ops.aten.to.dtype(where_self_72, torch.float32);  where_self_72 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(to_dtype_83, where_self_27, primals_14, [128], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_83 = where_self_27 = primals_14 = None
        getitem_109 = convolution_backward_default_27[0]
        getitem_110 = convolution_backward_default_27[1]
        getitem_111 = convolution_backward_default_27[2];  convolution_backward_default_27 = None
        to_dtype_84 = torch.ops.aten.to.dtype(getitem_109, torch.float32);  getitem_109 = None
        to_dtype_85 = torch.ops.aten.to.dtype(convolution_default_27, torch.float32);  convolution_default_27 = None
        gt_scalar_64 = torch.ops.aten.gt.Scalar(to_dtype_85, 0);  to_dtype_85 = None
        mul_tensor_123 = torch.ops.aten.mul.Tensor(to_dtype_84, 0.1)
        where_self_73 = torch.ops.aten.where.self(gt_scalar_64, to_dtype_84, mul_tensor_123);  gt_scalar_64 = to_dtype_84 = mul_tensor_123 = None
        to_dtype_86 = torch.ops.aten.to.dtype(where_self_73, torch.float32);  where_self_73 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(to_dtype_86, avg_pool2d_default_6, primals_12, [128], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_86 = avg_pool2d_default_6 = primals_12 = None
        getitem_112 = convolution_backward_default_28[0]
        getitem_113 = convolution_backward_default_28[1]
        getitem_114 = convolution_backward_default_28[2];  convolution_backward_default_28 = None
        avg_pool2d_backward_default_3 = torch.ops.aten.avg_pool2d_backward.default(getitem_112, where_self_26, [2, 2], [], [0, 0], False, True, None);  getitem_112 = where_self_26 = None
        add_tensor_49 = torch.ops.aten.add.Tensor(slice_tensor_97, avg_pool2d_backward_default_3);  slice_tensor_97 = avg_pool2d_backward_default_3 = None
        to_dtype_87 = torch.ops.aten.to.dtype(add_tensor_49, torch.float32);  add_tensor_49 = None
        to_dtype_88 = torch.ops.aten.to.dtype(convolution_default_26, torch.float32);  convolution_default_26 = None
        gt_scalar_65 = torch.ops.aten.gt.Scalar(to_dtype_88, 0);  to_dtype_88 = None
        mul_tensor_124 = torch.ops.aten.mul.Tensor(to_dtype_87, 0.1)
        where_self_74 = torch.ops.aten.where.self(gt_scalar_65, to_dtype_87, mul_tensor_124);  gt_scalar_65 = to_dtype_87 = mul_tensor_124 = None
        to_dtype_89 = torch.ops.aten.to.dtype(where_self_74, torch.float32);  where_self_74 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(to_dtype_89, where_self_25, primals_10, [64], [1, 1], [2, 2], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_89 = where_self_25 = primals_10 = None
        getitem_115 = convolution_backward_default_29[0]
        getitem_116 = convolution_backward_default_29[1]
        getitem_117 = convolution_backward_default_29[2];  convolution_backward_default_29 = None
        to_dtype_90 = torch.ops.aten.to.dtype(getitem_115, torch.float32);  getitem_115 = None
        to_dtype_91 = torch.ops.aten.to.dtype(convolution_default_25, torch.float32);  convolution_default_25 = None
        gt_scalar_66 = torch.ops.aten.gt.Scalar(to_dtype_91, 0);  to_dtype_91 = None
        mul_tensor_125 = torch.ops.aten.mul.Tensor(to_dtype_90, 0.1)
        where_self_75 = torch.ops.aten.where.self(gt_scalar_66, to_dtype_90, mul_tensor_125);  gt_scalar_66 = to_dtype_90 = mul_tensor_125 = None
        to_dtype_92 = torch.ops.aten.to.dtype(where_self_75, torch.float32);  where_self_75 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(to_dtype_92, avg_pool2d_default_5, primals_8, [64], [1, 1], [2, 2], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_92 = avg_pool2d_default_5 = primals_8 = None
        getitem_118 = convolution_backward_default_30[0]
        getitem_119 = convolution_backward_default_30[1]
        getitem_120 = convolution_backward_default_30[2];  convolution_backward_default_30 = None
        avg_pool2d_backward_default_4 = torch.ops.aten.avg_pool2d_backward.default(getitem_118, where_self_24, [2, 2], [], [0, 0], False, True, None);  getitem_118 = where_self_24 = None
        add_tensor_50 = torch.ops.aten.add.Tensor(slice_tensor_95, avg_pool2d_backward_default_4);  slice_tensor_95 = avg_pool2d_backward_default_4 = None
        to_dtype_93 = torch.ops.aten.to.dtype(add_tensor_50, torch.float32);  add_tensor_50 = None
        to_dtype_94 = torch.ops.aten.to.dtype(convolution_default_24, torch.float32);  convolution_default_24 = None
        gt_scalar_67 = torch.ops.aten.gt.Scalar(to_dtype_94, 0);  to_dtype_94 = None
        mul_tensor_126 = torch.ops.aten.mul.Tensor(to_dtype_93, 0.1)
        where_self_76 = torch.ops.aten.where.self(gt_scalar_67, to_dtype_93, mul_tensor_126);  gt_scalar_67 = to_dtype_93 = mul_tensor_126 = None
        to_dtype_95 = torch.ops.aten.to.dtype(where_self_76, torch.float32);  where_self_76 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(to_dtype_95, where_self_23, primals_4, [32], [1, 1], [3, 3], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_95 = where_self_23 = primals_4 = None
        getitem_121 = convolution_backward_default_31[0]
        getitem_122 = convolution_backward_default_31[1]
        getitem_123 = convolution_backward_default_31[2];  convolution_backward_default_31 = None
        to_dtype_96 = torch.ops.aten.to.dtype(getitem_121, torch.float32);  getitem_121 = None
        to_dtype_97 = torch.ops.aten.to.dtype(convolution_default_23, torch.float32);  convolution_default_23 = None
        gt_scalar_68 = torch.ops.aten.gt.Scalar(to_dtype_97, 0);  to_dtype_97 = None
        mul_tensor_127 = torch.ops.aten.mul.Tensor(to_dtype_96, 0.1)
        where_self_77 = torch.ops.aten.where.self(gt_scalar_68, to_dtype_96, mul_tensor_127);  gt_scalar_68 = to_dtype_96 = mul_tensor_127 = None
        to_dtype_98 = torch.ops.aten.to.dtype(where_self_77, torch.float32);  where_self_77 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(to_dtype_98, cat_default_6, primals_2, [32], [1, 1], [3, 3], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_98 = cat_default_6 = primals_2 = None
        getitem_124 = convolution_backward_default_32[0]
        getitem_125 = convolution_backward_default_32[1]
        getitem_126 = convolution_backward_default_32[2];  convolution_backward_default_32 = None
        slice_tensor_104 = torch.ops.aten.slice.Tensor(getitem_124, 1, 0, 3)
        slice_tensor_105 = torch.ops.aten.slice.Tensor(getitem_124, 1, 3, 6)
        slice_tensor_106 = torch.ops.aten.slice.Tensor(getitem_124, 1, 6, 8)
        slice_tensor_107 = torch.ops.aten.slice.Tensor(getitem_124, 1, 8, 10)
        slice_tensor_108 = torch.ops.aten.slice.Tensor(getitem_124, 1, 10, 12)
        slice_tensor_109 = torch.ops.aten.slice.Tensor(getitem_124, 1, 12, 14)
        slice_tensor_110 = torch.ops.aten.slice.Tensor(getitem_124, 1, 14, 17)
        slice_tensor_111 = torch.ops.aten.slice.Tensor(getitem_124, 1, 17, 20);  getitem_124 = None
        add_tensor_51 = torch.ops.aten.add.Tensor(add_tensor_34, slice_tensor_106);  add_tensor_34 = slice_tensor_106 = None
        add_tensor_52 = torch.ops.aten.add.Tensor(add_tensor_36, slice_tensor_107);  add_tensor_36 = slice_tensor_107 = None
        add_tensor_53 = torch.ops.aten.add.Tensor(add_tensor_41, slice_tensor_108);  add_tensor_41 = slice_tensor_108 = None
        add_tensor_54 = torch.ops.aten.add.Tensor(add_tensor_42, slice_tensor_109);  add_tensor_42 = slice_tensor_109 = None
        add_tensor_55 = torch.ops.aten.add.Tensor(mul_tensor_87, slice_tensor_110);  mul_tensor_87 = slice_tensor_110 = None
        add_tensor_56 = torch.ops.aten.add.Tensor(mul_tensor_88, slice_tensor_111);  mul_tensor_88 = slice_tensor_111 = None
        grid_sampler_2d_backward_default_4 = torch.ops.aten.grid_sampler_2d_backward.default(add_tensor_55, primals_117, stack_default_1, 0, 0, False, [False, True]);  add_tensor_55 = primals_117 = stack_default_1 = None
        getitem_127 = grid_sampler_2d_backward_default_4[0]
        getitem_128 = grid_sampler_2d_backward_default_4[1];  grid_sampler_2d_backward_default_4 = None
        unbind_int_4 = torch.ops.aten.unbind.int(getitem_128, 3);  getitem_128 = None
        getitem_129 = unbind_int_4[0]
        getitem_130 = unbind_int_4[1];  unbind_int_4 = None
        mul_tensor_128 = torch.ops.aten.mul.Tensor(getitem_130, 2);  getitem_130 = None
        div_tensor_24 = torch.ops.aten.div.Tensor(mul_tensor_128, 352);  mul_tensor_128 = None
        mul_tensor_129 = torch.ops.aten.mul.Tensor(getitem_129, 2);  getitem_129 = None
        div_tensor_25 = torch.ops.aten.div.Tensor(mul_tensor_129, 352);  mul_tensor_129 = None
        slice_backward_default_68 = torch.ops.aten.slice_backward.default(div_tensor_24, [6, 352, 352], 2, 0, 9223372036854775807, 1);  div_tensor_24 = None
        slice_backward_default_69 = torch.ops.aten.slice_backward.default(slice_backward_default_68, [6, 352, 352], 1, 0, 9223372036854775807, 1);  slice_backward_default_68 = None
        select_backward_default_8 = torch.ops.aten.select_backward.default(slice_backward_default_69, [6, 2, 352, 352], 1, 1);  slice_backward_default_69 = None
        slice_backward_default_70 = torch.ops.aten.slice_backward.default(select_backward_default_8, [6, 2, 352, 352], 0, 0, 9223372036854775807, 1);  select_backward_default_8 = None
        add_tensor_57 = torch.ops.aten.add.Tensor(add_tensor_53, slice_backward_default_70);  add_tensor_53 = slice_backward_default_70 = None
        slice_backward_default_71 = torch.ops.aten.slice_backward.default(div_tensor_25, [6, 352, 352], 2, 0, 9223372036854775807, 1);  div_tensor_25 = None
        slice_backward_default_72 = torch.ops.aten.slice_backward.default(slice_backward_default_71, [6, 352, 352], 1, 0, 9223372036854775807, 1);  slice_backward_default_71 = None
        select_backward_default_9 = torch.ops.aten.select_backward.default(slice_backward_default_72, [6, 2, 352, 352], 1, 0);  slice_backward_default_72 = None
        slice_backward_default_73 = torch.ops.aten.slice_backward.default(select_backward_default_9, [6, 2, 352, 352], 0, 0, 9223372036854775807, 1);  select_backward_default_9 = None
        add_tensor_58 = torch.ops.aten.add.Tensor(add_tensor_57, slice_backward_default_73);  add_tensor_57 = slice_backward_default_73 = None
        grid_sampler_2d_backward_default_5 = torch.ops.aten.grid_sampler_2d_backward.default(add_tensor_56, primals_116, stack_default, 0, 0, False, [False, True]);  add_tensor_56 = primals_116 = stack_default = None
        getitem_131 = grid_sampler_2d_backward_default_5[0]
        getitem_132 = grid_sampler_2d_backward_default_5[1];  grid_sampler_2d_backward_default_5 = None
        unbind_int_5 = torch.ops.aten.unbind.int(getitem_132, 3);  getitem_132 = None
        getitem_133 = unbind_int_5[0]
        getitem_134 = unbind_int_5[1];  unbind_int_5 = None
        mul_tensor_130 = torch.ops.aten.mul.Tensor(getitem_134, 2);  getitem_134 = None
        div_tensor_26 = torch.ops.aten.div.Tensor(mul_tensor_130, 352);  mul_tensor_130 = None
        mul_tensor_131 = torch.ops.aten.mul.Tensor(getitem_133, 2);  getitem_133 = None
        div_tensor_27 = torch.ops.aten.div.Tensor(mul_tensor_131, 352);  mul_tensor_131 = None
        slice_backward_default_74 = torch.ops.aten.slice_backward.default(div_tensor_26, [6, 352, 352], 2, 0, 9223372036854775807, 1);  div_tensor_26 = None
        slice_backward_default_75 = torch.ops.aten.slice_backward.default(slice_backward_default_74, [6, 352, 352], 1, 0, 9223372036854775807, 1);  slice_backward_default_74 = None
        select_backward_default_10 = torch.ops.aten.select_backward.default(slice_backward_default_75, [6, 2, 352, 352], 1, 1);  slice_backward_default_75 = None
        slice_backward_default_76 = torch.ops.aten.slice_backward.default(select_backward_default_10, [6, 2, 352, 352], 0, 0, 9223372036854775807, 1);  select_backward_default_10 = None
        add_tensor_59 = torch.ops.aten.add.Tensor(add_tensor_54, slice_backward_default_76);  add_tensor_54 = slice_backward_default_76 = None
        slice_backward_default_77 = torch.ops.aten.slice_backward.default(div_tensor_27, [6, 352, 352], 2, 0, 9223372036854775807, 1);  div_tensor_27 = None
        slice_backward_default_78 = torch.ops.aten.slice_backward.default(slice_backward_default_77, [6, 352, 352], 1, 0, 9223372036854775807, 1);  slice_backward_default_77 = None
        select_backward_default_11 = torch.ops.aten.select_backward.default(slice_backward_default_78, [6, 2, 352, 352], 1, 0);  slice_backward_default_78 = None
        slice_backward_default_79 = torch.ops.aten.slice_backward.default(select_backward_default_11, [6, 2, 352, 352], 0, 0, 9223372036854775807, 1);  select_backward_default_11 = None
        add_tensor_60 = torch.ops.aten.add.Tensor(add_tensor_59, slice_backward_default_79);  add_tensor_59 = slice_backward_default_79 = None
        mul_tensor_132 = torch.ops.aten.mul.Tensor(add_tensor_58, permute_default_3);  permute_default_3 = None
        add_tensor_61 = torch.ops.aten.add.Tensor(add_tensor_52, mul_tensor_132);  add_tensor_52 = mul_tensor_132 = None
        mul_tensor_133 = torch.ops.aten.mul.Tensor(add_tensor_58, permute_default_2);  add_tensor_58 = permute_default_2 = None
        add_tensor_62 = torch.ops.aten.add.Tensor(add_tensor_51, mul_tensor_133);  add_tensor_51 = mul_tensor_133 = None
        mul_tensor_134 = torch.ops.aten.mul.Tensor(add_tensor_60, permute_default_1);  permute_default_1 = None
        add_tensor_63 = torch.ops.aten.add.Tensor(add_tensor_61, mul_tensor_134);  add_tensor_61 = mul_tensor_134 = None
        mul_tensor_135 = torch.ops.aten.mul.Tensor(add_tensor_60, permute_default);  add_tensor_60 = permute_default = None
        add_tensor_64 = torch.ops.aten.add.Tensor(add_tensor_62, mul_tensor_135);  add_tensor_62 = mul_tensor_135 = None
        slice_backward_default_80 = torch.ops.aten.slice_backward.default(add_tensor_63, [6, 2, 352, 352], 3, 0, 9223372036854775807, 1);  add_tensor_63 = None
        slice_backward_default_81 = torch.ops.aten.slice_backward.default(slice_backward_default_80, [6, 2, 352, 352], 2, 0, 9223372036854775807, 1);  slice_backward_default_80 = None
        slice_backward_default_82 = torch.ops.aten.slice_backward.default(slice_backward_default_81, [6, 4, 352, 352], 1, 2, 9223372036854775807, 1);  slice_backward_default_81 = None
        slice_backward_default_83 = torch.ops.aten.slice_backward.default(slice_backward_default_82, [6, 4, 352, 352], 0, 0, 9223372036854775807, 1);  slice_backward_default_82 = None
        slice_backward_default_84 = torch.ops.aten.slice_backward.default(add_tensor_64, [6, 2, 352, 352], 3, 0, 9223372036854775807, 1);  add_tensor_64 = None
        slice_backward_default_85 = torch.ops.aten.slice_backward.default(slice_backward_default_84, [6, 2, 352, 352], 2, 0, 9223372036854775807, 1);  slice_backward_default_84 = None
        slice_backward_default_86 = torch.ops.aten.slice_backward.default(slice_backward_default_85, [6, 4, 352, 352], 1, 0, 2, 1);  slice_backward_default_85 = None
        slice_backward_default_87 = torch.ops.aten.slice_backward.default(slice_backward_default_86, [6, 4, 352, 352], 0, 0, 9223372036854775807, 1);  slice_backward_default_86 = None
        add_tensor_65 = torch.ops.aten.add.Tensor(slice_backward_default_83, slice_backward_default_87);  slice_backward_default_83 = slice_backward_default_87 = None
        to_dtype_99 = torch.ops.aten.to.dtype(add_tensor_65, torch.float32);  add_tensor_65 = None
        to_dtype_100 = torch.ops.aten.to.dtype(convolution_default_22, torch.float32);  convolution_default_22 = None
        gt_scalar_69 = torch.ops.aten.gt.Scalar(to_dtype_100, 0);  to_dtype_100 = None
        mul_tensor_136 = torch.ops.aten.mul.Tensor(to_dtype_99, 0.1)
        where_self_78 = torch.ops.aten.where.self(gt_scalar_69, to_dtype_99, mul_tensor_136);  gt_scalar_69 = to_dtype_99 = mul_tensor_136 = None
        to_dtype_101 = torch.ops.aten.to.dtype(where_self_78, torch.float32);  where_self_78 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(to_dtype_101, where_self_21, primals_52, [4], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_101 = where_self_21 = primals_52 = None
        getitem_135 = convolution_backward_default_33[0]
        getitem_136 = convolution_backward_default_33[1]
        getitem_137 = convolution_backward_default_33[2];  convolution_backward_default_33 = None
        to_dtype_102 = torch.ops.aten.to.dtype(getitem_135, torch.float32);  getitem_135 = None
        to_dtype_103 = torch.ops.aten.to.dtype(convolution_default_21, torch.float32);  convolution_default_21 = None
        gt_scalar_70 = torch.ops.aten.gt.Scalar(to_dtype_103, 0);  to_dtype_103 = None
        mul_tensor_137 = torch.ops.aten.mul.Tensor(to_dtype_102, 0.1)
        where_self_79 = torch.ops.aten.where.self(gt_scalar_70, to_dtype_102, mul_tensor_137);  gt_scalar_70 = to_dtype_102 = mul_tensor_137 = None
        to_dtype_104 = torch.ops.aten.to.dtype(where_self_79, torch.float32);  where_self_79 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(to_dtype_104, cat_default_5, primals_92, [32], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_104 = cat_default_5 = primals_92 = None
        getitem_138 = convolution_backward_default_34[0]
        getitem_139 = convolution_backward_default_34[1]
        getitem_140 = convolution_backward_default_34[2];  convolution_backward_default_34 = None
        slice_tensor_112 = torch.ops.aten.slice.Tensor(getitem_138, 1, 0, 32)
        slice_tensor_113 = torch.ops.aten.slice.Tensor(getitem_138, 1, 32, 64);  getitem_138 = None
        to_dtype_105 = torch.ops.aten.to.dtype(slice_tensor_112, torch.float32);  slice_tensor_112 = None
        to_dtype_106 = torch.ops.aten.to.dtype(convolution_default_20, torch.float32);  convolution_default_20 = None
        gt_scalar_71 = torch.ops.aten.gt.Scalar(to_dtype_106, 0);  to_dtype_106 = None
        mul_tensor_138 = torch.ops.aten.mul.Tensor(to_dtype_105, 0.1)
        where_self_80 = torch.ops.aten.where.self(gt_scalar_71, to_dtype_105, mul_tensor_138);  gt_scalar_71 = to_dtype_105 = mul_tensor_138 = None
        to_dtype_107 = torch.ops.aten.to.dtype(where_self_80, torch.float32);  where_self_80 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(to_dtype_107, upsample_bilinear2d_vec_4, primals_90, [32], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_107 = upsample_bilinear2d_vec_4 = primals_90 = None
        getitem_141 = convolution_backward_default_35[0]
        getitem_142 = convolution_backward_default_35[1]
        getitem_143 = convolution_backward_default_35[2];  convolution_backward_default_35 = None
        upsample_bilinear2d_backward_vec_5 = torch.ops.aten.upsample_bilinear2d_backward.vec(getitem_141, None, [6, 64, 176, 176], False, [2.0, 2.0]);  getitem_141 = None
        to_dtype_108 = torch.ops.aten.to.dtype(upsample_bilinear2d_backward_vec_5, torch.float32);  upsample_bilinear2d_backward_vec_5 = None
        to_dtype_109 = torch.ops.aten.to.dtype(convolution_default_19, torch.float32);  convolution_default_19 = None
        gt_scalar_72 = torch.ops.aten.gt.Scalar(to_dtype_109, 0);  to_dtype_109 = None
        mul_tensor_139 = torch.ops.aten.mul.Tensor(to_dtype_108, 0.1)
        where_self_81 = torch.ops.aten.where.self(gt_scalar_72, to_dtype_108, mul_tensor_139);  gt_scalar_72 = to_dtype_108 = mul_tensor_139 = None
        to_dtype_110 = torch.ops.aten.to.dtype(where_self_81, torch.float32);  where_self_81 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(to_dtype_110, cat_default_4, primals_88, [64], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_110 = cat_default_4 = primals_88 = None
        getitem_144 = convolution_backward_default_36[0]
        getitem_145 = convolution_backward_default_36[1]
        getitem_146 = convolution_backward_default_36[2];  convolution_backward_default_36 = None
        slice_tensor_114 = torch.ops.aten.slice.Tensor(getitem_144, 1, 0, 64)
        slice_tensor_115 = torch.ops.aten.slice.Tensor(getitem_144, 1, 64, 128);  getitem_144 = None
        to_dtype_111 = torch.ops.aten.to.dtype(slice_tensor_114, torch.float32);  slice_tensor_114 = None
        to_dtype_112 = torch.ops.aten.to.dtype(convolution_default_18, torch.float32);  convolution_default_18 = None
        gt_scalar_73 = torch.ops.aten.gt.Scalar(to_dtype_112, 0);  to_dtype_112 = None
        mul_tensor_140 = torch.ops.aten.mul.Tensor(to_dtype_111, 0.1)
        where_self_82 = torch.ops.aten.where.self(gt_scalar_73, to_dtype_111, mul_tensor_140);  gt_scalar_73 = to_dtype_111 = mul_tensor_140 = None
        to_dtype_113 = torch.ops.aten.to.dtype(where_self_82, torch.float32);  where_self_82 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(to_dtype_113, upsample_bilinear2d_vec_3, primals_86, [64], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_113 = upsample_bilinear2d_vec_3 = primals_86 = None
        getitem_147 = convolution_backward_default_37[0]
        getitem_148 = convolution_backward_default_37[1]
        getitem_149 = convolution_backward_default_37[2];  convolution_backward_default_37 = None
        upsample_bilinear2d_backward_vec_6 = torch.ops.aten.upsample_bilinear2d_backward.vec(getitem_147, None, [6, 128, 88, 88], False, [2.0, 2.0]);  getitem_147 = None
        to_dtype_114 = torch.ops.aten.to.dtype(upsample_bilinear2d_backward_vec_6, torch.float32);  upsample_bilinear2d_backward_vec_6 = None
        to_dtype_115 = torch.ops.aten.to.dtype(convolution_default_17, torch.float32);  convolution_default_17 = None
        gt_scalar_74 = torch.ops.aten.gt.Scalar(to_dtype_115, 0);  to_dtype_115 = None
        mul_tensor_141 = torch.ops.aten.mul.Tensor(to_dtype_114, 0.1)
        where_self_83 = torch.ops.aten.where.self(gt_scalar_74, to_dtype_114, mul_tensor_141);  gt_scalar_74 = to_dtype_114 = mul_tensor_141 = None
        to_dtype_116 = torch.ops.aten.to.dtype(where_self_83, torch.float32);  where_self_83 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(to_dtype_116, cat_default_3, primals_84, [128], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_116 = cat_default_3 = primals_84 = None
        getitem_150 = convolution_backward_default_38[0]
        getitem_151 = convolution_backward_default_38[1]
        getitem_152 = convolution_backward_default_38[2];  convolution_backward_default_38 = None
        slice_tensor_116 = torch.ops.aten.slice.Tensor(getitem_150, 1, 0, 128)
        slice_tensor_117 = torch.ops.aten.slice.Tensor(getitem_150, 1, 128, 256);  getitem_150 = None
        to_dtype_117 = torch.ops.aten.to.dtype(slice_tensor_116, torch.float32);  slice_tensor_116 = None
        to_dtype_118 = torch.ops.aten.to.dtype(convolution_default_16, torch.float32);  convolution_default_16 = None
        gt_scalar_75 = torch.ops.aten.gt.Scalar(to_dtype_118, 0);  to_dtype_118 = None
        mul_tensor_142 = torch.ops.aten.mul.Tensor(to_dtype_117, 0.1)
        where_self_84 = torch.ops.aten.where.self(gt_scalar_75, to_dtype_117, mul_tensor_142);  gt_scalar_75 = to_dtype_117 = mul_tensor_142 = None
        to_dtype_119 = torch.ops.aten.to.dtype(where_self_84, torch.float32);  where_self_84 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(to_dtype_119, upsample_bilinear2d_vec_2, primals_82, [128], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_119 = upsample_bilinear2d_vec_2 = primals_82 = None
        getitem_153 = convolution_backward_default_39[0]
        getitem_154 = convolution_backward_default_39[1]
        getitem_155 = convolution_backward_default_39[2];  convolution_backward_default_39 = None
        upsample_bilinear2d_backward_vec_7 = torch.ops.aten.upsample_bilinear2d_backward.vec(getitem_153, None, [6, 256, 44, 44], False, [2.0, 2.0]);  getitem_153 = None
        to_dtype_120 = torch.ops.aten.to.dtype(upsample_bilinear2d_backward_vec_7, torch.float32);  upsample_bilinear2d_backward_vec_7 = None
        to_dtype_121 = torch.ops.aten.to.dtype(convolution_default_15, torch.float32);  convolution_default_15 = None
        gt_scalar_76 = torch.ops.aten.gt.Scalar(to_dtype_121, 0);  to_dtype_121 = None
        mul_tensor_143 = torch.ops.aten.mul.Tensor(to_dtype_120, 0.1)
        where_self_85 = torch.ops.aten.where.self(gt_scalar_76, to_dtype_120, mul_tensor_143);  gt_scalar_76 = to_dtype_120 = mul_tensor_143 = None
        to_dtype_122 = torch.ops.aten.to.dtype(where_self_85, torch.float32);  where_self_85 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(to_dtype_122, cat_default_2, primals_80, [256], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_122 = cat_default_2 = primals_80 = None
        getitem_156 = convolution_backward_default_40[0]
        getitem_157 = convolution_backward_default_40[1]
        getitem_158 = convolution_backward_default_40[2];  convolution_backward_default_40 = None
        slice_tensor_118 = torch.ops.aten.slice.Tensor(getitem_156, 1, 0, 256)
        slice_tensor_119 = torch.ops.aten.slice.Tensor(getitem_156, 1, 256, 512);  getitem_156 = None
        to_dtype_123 = torch.ops.aten.to.dtype(slice_tensor_118, torch.float32);  slice_tensor_118 = None
        to_dtype_124 = torch.ops.aten.to.dtype(convolution_default_14, torch.float32);  convolution_default_14 = None
        gt_scalar_77 = torch.ops.aten.gt.Scalar(to_dtype_124, 0);  to_dtype_124 = None
        mul_tensor_144 = torch.ops.aten.mul.Tensor(to_dtype_123, 0.1)
        where_self_86 = torch.ops.aten.where.self(gt_scalar_77, to_dtype_123, mul_tensor_144);  gt_scalar_77 = to_dtype_123 = mul_tensor_144 = None
        to_dtype_125 = torch.ops.aten.to.dtype(where_self_86, torch.float32);  where_self_86 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(to_dtype_125, upsample_bilinear2d_vec_1, primals_78, [256], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_125 = upsample_bilinear2d_vec_1 = primals_78 = None
        getitem_159 = convolution_backward_default_41[0]
        getitem_160 = convolution_backward_default_41[1]
        getitem_161 = convolution_backward_default_41[2];  convolution_backward_default_41 = None
        upsample_bilinear2d_backward_vec_8 = torch.ops.aten.upsample_bilinear2d_backward.vec(getitem_159, None, [6, 512, 22, 22], False, [2.0, 2.0]);  getitem_159 = None
        to_dtype_126 = torch.ops.aten.to.dtype(upsample_bilinear2d_backward_vec_8, torch.float32);  upsample_bilinear2d_backward_vec_8 = None
        to_dtype_127 = torch.ops.aten.to.dtype(convolution_default_13, torch.float32);  convolution_default_13 = None
        gt_scalar_78 = torch.ops.aten.gt.Scalar(to_dtype_127, 0);  to_dtype_127 = None
        mul_tensor_145 = torch.ops.aten.mul.Tensor(to_dtype_126, 0.1)
        where_self_87 = torch.ops.aten.where.self(gt_scalar_78, to_dtype_126, mul_tensor_145);  gt_scalar_78 = to_dtype_126 = mul_tensor_145 = None
        to_dtype_128 = torch.ops.aten.to.dtype(where_self_87, torch.float32);  where_self_87 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(to_dtype_128, cat_default_1, primals_76, [512], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_128 = cat_default_1 = primals_76 = None
        getitem_162 = convolution_backward_default_42[0]
        getitem_163 = convolution_backward_default_42[1]
        getitem_164 = convolution_backward_default_42[2];  convolution_backward_default_42 = None
        slice_tensor_120 = torch.ops.aten.slice.Tensor(getitem_162, 1, 0, 512)
        slice_tensor_121 = torch.ops.aten.slice.Tensor(getitem_162, 1, 512, 1024);  getitem_162 = None
        to_dtype_129 = torch.ops.aten.to.dtype(slice_tensor_120, torch.float32);  slice_tensor_120 = None
        to_dtype_130 = torch.ops.aten.to.dtype(convolution_default_12, torch.float32);  convolution_default_12 = None
        gt_scalar_79 = torch.ops.aten.gt.Scalar(to_dtype_130, 0);  to_dtype_130 = None
        mul_tensor_146 = torch.ops.aten.mul.Tensor(to_dtype_129, 0.1)
        where_self_88 = torch.ops.aten.where.self(gt_scalar_79, to_dtype_129, mul_tensor_146);  gt_scalar_79 = to_dtype_129 = mul_tensor_146 = None
        to_dtype_131 = torch.ops.aten.to.dtype(where_self_88, torch.float32);  where_self_88 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(to_dtype_131, upsample_bilinear2d_vec, primals_74, [512], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_131 = upsample_bilinear2d_vec = primals_74 = None
        getitem_165 = convolution_backward_default_43[0]
        getitem_166 = convolution_backward_default_43[1]
        getitem_167 = convolution_backward_default_43[2];  convolution_backward_default_43 = None
        upsample_bilinear2d_backward_vec_9 = torch.ops.aten.upsample_bilinear2d_backward.vec(getitem_165, None, [6, 512, 11, 11], False, [2.0, 2.0]);  getitem_165 = None
        to_dtype_132 = torch.ops.aten.to.dtype(upsample_bilinear2d_backward_vec_9, torch.float32);  upsample_bilinear2d_backward_vec_9 = None
        to_dtype_133 = torch.ops.aten.to.dtype(convolution_default_11, torch.float32);  convolution_default_11 = None
        gt_scalar_80 = torch.ops.aten.gt.Scalar(to_dtype_133, 0);  to_dtype_133 = None
        mul_tensor_147 = torch.ops.aten.mul.Tensor(to_dtype_132, 0.1)
        where_self_89 = torch.ops.aten.where.self(gt_scalar_80, to_dtype_132, mul_tensor_147);  gt_scalar_80 = to_dtype_132 = mul_tensor_147 = None
        to_dtype_134 = torch.ops.aten.to.dtype(where_self_89, torch.float32);  where_self_89 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(to_dtype_134, where_self_10, primals_72, [512], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_134 = where_self_10 = primals_72 = None
        getitem_168 = convolution_backward_default_44[0]
        getitem_169 = convolution_backward_default_44[1]
        getitem_170 = convolution_backward_default_44[2];  convolution_backward_default_44 = None
        to_dtype_135 = torch.ops.aten.to.dtype(getitem_168, torch.float32);  getitem_168 = None
        to_dtype_136 = torch.ops.aten.to.dtype(convolution_default_10, torch.float32);  convolution_default_10 = None
        gt_scalar_81 = torch.ops.aten.gt.Scalar(to_dtype_136, 0);  to_dtype_136 = None
        mul_tensor_148 = torch.ops.aten.mul.Tensor(to_dtype_135, 0.1)
        where_self_90 = torch.ops.aten.where.self(gt_scalar_81, to_dtype_135, mul_tensor_148);  gt_scalar_81 = to_dtype_135 = mul_tensor_148 = None
        to_dtype_137 = torch.ops.aten.to.dtype(where_self_90, torch.float32);  where_self_90 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(to_dtype_137, avg_pool2d_default_4, primals_70, [512], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_137 = avg_pool2d_default_4 = primals_70 = None
        getitem_171 = convolution_backward_default_45[0]
        getitem_172 = convolution_backward_default_45[1]
        getitem_173 = convolution_backward_default_45[2];  convolution_backward_default_45 = None
        avg_pool2d_backward_default_5 = torch.ops.aten.avg_pool2d_backward.default(getitem_171, where_self_9, [2, 2], [], [0, 0], False, True, None);  getitem_171 = where_self_9 = None
        add_tensor_66 = torch.ops.aten.add.Tensor(slice_tensor_121, avg_pool2d_backward_default_5);  slice_tensor_121 = avg_pool2d_backward_default_5 = None
        to_dtype_138 = torch.ops.aten.to.dtype(add_tensor_66, torch.float32);  add_tensor_66 = None
        to_dtype_139 = torch.ops.aten.to.dtype(convolution_default_9, torch.float32);  convolution_default_9 = None
        gt_scalar_82 = torch.ops.aten.gt.Scalar(to_dtype_139, 0);  to_dtype_139 = None
        mul_tensor_149 = torch.ops.aten.mul.Tensor(to_dtype_138, 0.1)
        where_self_91 = torch.ops.aten.where.self(gt_scalar_82, to_dtype_138, mul_tensor_149);  gt_scalar_82 = to_dtype_138 = mul_tensor_149 = None
        to_dtype_140 = torch.ops.aten.to.dtype(where_self_91, torch.float32);  where_self_91 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(to_dtype_140, where_self_8, primals_68, [512], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_140 = where_self_8 = primals_68 = None
        getitem_174 = convolution_backward_default_46[0]
        getitem_175 = convolution_backward_default_46[1]
        getitem_176 = convolution_backward_default_46[2];  convolution_backward_default_46 = None
        to_dtype_141 = torch.ops.aten.to.dtype(getitem_174, torch.float32);  getitem_174 = None
        to_dtype_142 = torch.ops.aten.to.dtype(convolution_default_8, torch.float32);  convolution_default_8 = None
        gt_scalar_83 = torch.ops.aten.gt.Scalar(to_dtype_142, 0);  to_dtype_142 = None
        mul_tensor_150 = torch.ops.aten.mul.Tensor(to_dtype_141, 0.1)
        where_self_92 = torch.ops.aten.where.self(gt_scalar_83, to_dtype_141, mul_tensor_150);  gt_scalar_83 = to_dtype_141 = mul_tensor_150 = None
        to_dtype_143 = torch.ops.aten.to.dtype(where_self_92, torch.float32);  where_self_92 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(to_dtype_143, avg_pool2d_default_3, primals_66, [512], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_143 = avg_pool2d_default_3 = primals_66 = None
        getitem_177 = convolution_backward_default_47[0]
        getitem_178 = convolution_backward_default_47[1]
        getitem_179 = convolution_backward_default_47[2];  convolution_backward_default_47 = None
        avg_pool2d_backward_default_6 = torch.ops.aten.avg_pool2d_backward.default(getitem_177, where_self_7, [2, 2], [], [0, 0], False, True, None);  getitem_177 = where_self_7 = None
        add_tensor_67 = torch.ops.aten.add.Tensor(slice_tensor_119, avg_pool2d_backward_default_6);  slice_tensor_119 = avg_pool2d_backward_default_6 = None
        to_dtype_144 = torch.ops.aten.to.dtype(add_tensor_67, torch.float32);  add_tensor_67 = None
        to_dtype_145 = torch.ops.aten.to.dtype(convolution_default_7, torch.float32);  convolution_default_7 = None
        gt_scalar_84 = torch.ops.aten.gt.Scalar(to_dtype_145, 0);  to_dtype_145 = None
        mul_tensor_151 = torch.ops.aten.mul.Tensor(to_dtype_144, 0.1)
        where_self_93 = torch.ops.aten.where.self(gt_scalar_84, to_dtype_144, mul_tensor_151);  gt_scalar_84 = to_dtype_144 = mul_tensor_151 = None
        to_dtype_146 = torch.ops.aten.to.dtype(where_self_93, torch.float32);  where_self_93 = None
        convolution_backward_default_48 = torch.ops.aten.convolution_backward.default(to_dtype_146, where_self_6, primals_64, [256], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_146 = where_self_6 = primals_64 = None
        getitem_180 = convolution_backward_default_48[0]
        getitem_181 = convolution_backward_default_48[1]
        getitem_182 = convolution_backward_default_48[2];  convolution_backward_default_48 = None
        to_dtype_147 = torch.ops.aten.to.dtype(getitem_180, torch.float32);  getitem_180 = None
        to_dtype_148 = torch.ops.aten.to.dtype(convolution_default_6, torch.float32);  convolution_default_6 = None
        gt_scalar_85 = torch.ops.aten.gt.Scalar(to_dtype_148, 0);  to_dtype_148 = None
        mul_tensor_152 = torch.ops.aten.mul.Tensor(to_dtype_147, 0.1)
        where_self_94 = torch.ops.aten.where.self(gt_scalar_85, to_dtype_147, mul_tensor_152);  gt_scalar_85 = to_dtype_147 = mul_tensor_152 = None
        to_dtype_149 = torch.ops.aten.to.dtype(where_self_94, torch.float32);  where_self_94 = None
        convolution_backward_default_49 = torch.ops.aten.convolution_backward.default(to_dtype_149, avg_pool2d_default_2, primals_62, [256], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_149 = avg_pool2d_default_2 = primals_62 = None
        getitem_183 = convolution_backward_default_49[0]
        getitem_184 = convolution_backward_default_49[1]
        getitem_185 = convolution_backward_default_49[2];  convolution_backward_default_49 = None
        avg_pool2d_backward_default_7 = torch.ops.aten.avg_pool2d_backward.default(getitem_183, where_self_5, [2, 2], [], [0, 0], False, True, None);  getitem_183 = where_self_5 = None
        add_tensor_68 = torch.ops.aten.add.Tensor(slice_tensor_117, avg_pool2d_backward_default_7);  slice_tensor_117 = avg_pool2d_backward_default_7 = None
        to_dtype_150 = torch.ops.aten.to.dtype(add_tensor_68, torch.float32);  add_tensor_68 = None
        to_dtype_151 = torch.ops.aten.to.dtype(convolution_default_5, torch.float32);  convolution_default_5 = None
        gt_scalar_86 = torch.ops.aten.gt.Scalar(to_dtype_151, 0);  to_dtype_151 = None
        mul_tensor_153 = torch.ops.aten.mul.Tensor(to_dtype_150, 0.1)
        where_self_95 = torch.ops.aten.where.self(gt_scalar_86, to_dtype_150, mul_tensor_153);  gt_scalar_86 = to_dtype_150 = mul_tensor_153 = None
        to_dtype_152 = torch.ops.aten.to.dtype(where_self_95, torch.float32);  where_self_95 = None
        convolution_backward_default_50 = torch.ops.aten.convolution_backward.default(to_dtype_152, where_self_4, primals_60, [128], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_152 = where_self_4 = primals_60 = None
        getitem_186 = convolution_backward_default_50[0]
        getitem_187 = convolution_backward_default_50[1]
        getitem_188 = convolution_backward_default_50[2];  convolution_backward_default_50 = None
        to_dtype_153 = torch.ops.aten.to.dtype(getitem_186, torch.float32);  getitem_186 = None
        to_dtype_154 = torch.ops.aten.to.dtype(convolution_default_4, torch.float32);  convolution_default_4 = None
        gt_scalar_87 = torch.ops.aten.gt.Scalar(to_dtype_154, 0);  to_dtype_154 = None
        mul_tensor_154 = torch.ops.aten.mul.Tensor(to_dtype_153, 0.1)
        where_self_96 = torch.ops.aten.where.self(gt_scalar_87, to_dtype_153, mul_tensor_154);  gt_scalar_87 = to_dtype_153 = mul_tensor_154 = None
        to_dtype_155 = torch.ops.aten.to.dtype(where_self_96, torch.float32);  where_self_96 = None
        convolution_backward_default_51 = torch.ops.aten.convolution_backward.default(to_dtype_155, avg_pool2d_default_1, primals_58, [128], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_155 = avg_pool2d_default_1 = primals_58 = None
        getitem_189 = convolution_backward_default_51[0]
        getitem_190 = convolution_backward_default_51[1]
        getitem_191 = convolution_backward_default_51[2];  convolution_backward_default_51 = None
        avg_pool2d_backward_default_8 = torch.ops.aten.avg_pool2d_backward.default(getitem_189, where_self_3, [2, 2], [], [0, 0], False, True, None);  getitem_189 = where_self_3 = None
        add_tensor_69 = torch.ops.aten.add.Tensor(slice_tensor_115, avg_pool2d_backward_default_8);  slice_tensor_115 = avg_pool2d_backward_default_8 = None
        to_dtype_156 = torch.ops.aten.to.dtype(add_tensor_69, torch.float32);  add_tensor_69 = None
        to_dtype_157 = torch.ops.aten.to.dtype(convolution_default_3, torch.float32);  convolution_default_3 = None
        gt_scalar_88 = torch.ops.aten.gt.Scalar(to_dtype_157, 0);  to_dtype_157 = None
        mul_tensor_155 = torch.ops.aten.mul.Tensor(to_dtype_156, 0.1)
        where_self_97 = torch.ops.aten.where.self(gt_scalar_88, to_dtype_156, mul_tensor_155);  gt_scalar_88 = to_dtype_156 = mul_tensor_155 = None
        to_dtype_158 = torch.ops.aten.to.dtype(where_self_97, torch.float32);  where_self_97 = None
        convolution_backward_default_52 = torch.ops.aten.convolution_backward.default(to_dtype_158, where_self_2, primals_56, [64], [1, 1], [2, 2], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_158 = where_self_2 = primals_56 = None
        getitem_192 = convolution_backward_default_52[0]
        getitem_193 = convolution_backward_default_52[1]
        getitem_194 = convolution_backward_default_52[2];  convolution_backward_default_52 = None
        to_dtype_159 = torch.ops.aten.to.dtype(getitem_192, torch.float32);  getitem_192 = None
        to_dtype_160 = torch.ops.aten.to.dtype(convolution_default_2, torch.float32);  convolution_default_2 = None
        gt_scalar_89 = torch.ops.aten.gt.Scalar(to_dtype_160, 0);  to_dtype_160 = None
        mul_tensor_156 = torch.ops.aten.mul.Tensor(to_dtype_159, 0.1)
        where_self_98 = torch.ops.aten.where.self(gt_scalar_89, to_dtype_159, mul_tensor_156);  gt_scalar_89 = to_dtype_159 = mul_tensor_156 = None
        to_dtype_161 = torch.ops.aten.to.dtype(where_self_98, torch.float32);  where_self_98 = None
        convolution_backward_default_53 = torch.ops.aten.convolution_backward.default(to_dtype_161, avg_pool2d_default, primals_54, [64], [1, 1], [2, 2], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_161 = avg_pool2d_default = primals_54 = None
        getitem_195 = convolution_backward_default_53[0]
        getitem_196 = convolution_backward_default_53[1]
        getitem_197 = convolution_backward_default_53[2];  convolution_backward_default_53 = None
        avg_pool2d_backward_default_9 = torch.ops.aten.avg_pool2d_backward.default(getitem_195, where_self_1, [2, 2], [], [0, 0], False, True, None);  getitem_195 = where_self_1 = None
        add_tensor_70 = torch.ops.aten.add.Tensor(slice_tensor_113, avg_pool2d_backward_default_9);  slice_tensor_113 = avg_pool2d_backward_default_9 = None
        to_dtype_162 = torch.ops.aten.to.dtype(add_tensor_70, torch.float32);  add_tensor_70 = None
        to_dtype_163 = torch.ops.aten.to.dtype(convolution_default_1, torch.float32);  convolution_default_1 = None
        gt_scalar_90 = torch.ops.aten.gt.Scalar(to_dtype_163, 0);  to_dtype_163 = None
        mul_tensor_157 = torch.ops.aten.mul.Tensor(to_dtype_162, 0.1)
        where_self_99 = torch.ops.aten.where.self(gt_scalar_90, to_dtype_162, mul_tensor_157);  gt_scalar_90 = to_dtype_162 = mul_tensor_157 = None
        to_dtype_164 = torch.ops.aten.to.dtype(where_self_99, torch.float32);  where_self_99 = None
        convolution_backward_default_54 = torch.ops.aten.convolution_backward.default(to_dtype_164, where_self, primals_50, [32], [1, 1], [3, 3], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_164 = where_self = primals_50 = None
        getitem_198 = convolution_backward_default_54[0]
        getitem_199 = convolution_backward_default_54[1]
        getitem_200 = convolution_backward_default_54[2];  convolution_backward_default_54 = None
        to_dtype_165 = torch.ops.aten.to.dtype(getitem_198, torch.float32);  getitem_198 = None
        to_dtype_166 = torch.ops.aten.to.dtype(convolution_default, torch.float32);  convolution_default = None
        gt_scalar_91 = torch.ops.aten.gt.Scalar(to_dtype_166, 0);  to_dtype_166 = None
        mul_tensor_158 = torch.ops.aten.mul.Tensor(to_dtype_165, 0.1)
        where_self_100 = torch.ops.aten.where.self(gt_scalar_91, to_dtype_165, mul_tensor_158);  gt_scalar_91 = to_dtype_165 = mul_tensor_158 = None
        to_dtype_167 = torch.ops.aten.to.dtype(where_self_100, torch.float32);  where_self_100 = None
        convolution_backward_default_55 = torch.ops.aten.convolution_backward.default(to_dtype_167, cat_default, primals_48, [32], [1, 1], [3, 3], [1, 1], False, [0, 0], 1, [False, True, True]);  to_dtype_167 = cat_default = primals_48 = None
        getitem_201 = convolution_backward_default_55[0]
        getitem_202 = convolution_backward_default_55[1]
        getitem_203 = convolution_backward_default_55[2];  convolution_backward_default_55 = None
        return [div_tensor_8, add_tensor_26, getitem_126, getitem_125, getitem_123, getitem_122, getitem_60, getitem_59, getitem_120, getitem_119, getitem_117, getitem_116, getitem_114, getitem_113, getitem_111, getitem_110, getitem_108, getitem_107, getitem_105, getitem_104, getitem_102, getitem_101, getitem_99, getitem_98, getitem_96, getitem_95, getitem_93, getitem_92, getitem_90, getitem_89, getitem_87, getitem_86, getitem_84, getitem_83, getitem_81, getitem_80, getitem_78, getitem_77, getitem_75, getitem_74, getitem_72, getitem_71, getitem_69, getitem_68, getitem_66, getitem_65, getitem_63, getitem_62, getitem_203, getitem_202, getitem_200, getitem_199, getitem_137, getitem_136, getitem_197, getitem_196, getitem_194, getitem_193, getitem_191, getitem_190, getitem_188, getitem_187, getitem_185, getitem_184, getitem_182, getitem_181, getitem_179, getitem_178, getitem_176, getitem_175, getitem_173, getitem_172, getitem_170, getitem_169, getitem_167, getitem_166, getitem_164, getitem_163, getitem_161, getitem_160, getitem_158, getitem_157, getitem_155, getitem_154, getitem_152, getitem_151, getitem_149, getitem_148, getitem_146, getitem_145, getitem_143, getitem_142, getitem_140, getitem_139, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None]
        
