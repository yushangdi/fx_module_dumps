
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/Super_SloMo/Super_SloMo_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118):
        cat_default = torch.ops.aten.cat.default([primals_116, primals_117], 1)
        convolution_default = torch.ops.aten.convolution.default(cat_default, primals_48, primals_47, [1, 1], [3, 3], [1, 1], False, [0, 0], 1);  primals_47 = None
        gt_scalar = torch.ops.aten.gt.Scalar(convolution_default, 0)
        mul_tensor = torch.ops.aten.mul.Tensor(convolution_default, 0.1)
        where_self = torch.ops.aten.where.self(gt_scalar, convolution_default, mul_tensor);  gt_scalar = mul_tensor = None
        convolution_default_1 = torch.ops.aten.convolution.default(where_self, primals_50, primals_49, [1, 1], [3, 3], [1, 1], False, [0, 0], 1);  primals_49 = None
        gt_scalar_1 = torch.ops.aten.gt.Scalar(convolution_default_1, 0)
        mul_tensor_1 = torch.ops.aten.mul.Tensor(convolution_default_1, 0.1)
        where_self_1 = torch.ops.aten.where.self(gt_scalar_1, convolution_default_1, mul_tensor_1);  gt_scalar_1 = mul_tensor_1 = None
        avg_pool2d_default = torch.ops.aten.avg_pool2d.default(where_self_1, [2, 2])
        convolution_default_2 = torch.ops.aten.convolution.default(avg_pool2d_default, primals_54, primals_53, [1, 1], [2, 2], [1, 1], False, [0, 0], 1);  primals_53 = None
        gt_scalar_2 = torch.ops.aten.gt.Scalar(convolution_default_2, 0)
        mul_tensor_2 = torch.ops.aten.mul.Tensor(convolution_default_2, 0.1)
        where_self_2 = torch.ops.aten.where.self(gt_scalar_2, convolution_default_2, mul_tensor_2);  gt_scalar_2 = mul_tensor_2 = None
        convolution_default_3 = torch.ops.aten.convolution.default(where_self_2, primals_56, primals_55, [1, 1], [2, 2], [1, 1], False, [0, 0], 1);  primals_55 = None
        gt_scalar_3 = torch.ops.aten.gt.Scalar(convolution_default_3, 0)
        mul_tensor_3 = torch.ops.aten.mul.Tensor(convolution_default_3, 0.1)
        where_self_3 = torch.ops.aten.where.self(gt_scalar_3, convolution_default_3, mul_tensor_3);  gt_scalar_3 = mul_tensor_3 = None
        avg_pool2d_default_1 = torch.ops.aten.avg_pool2d.default(where_self_3, [2, 2])
        convolution_default_4 = torch.ops.aten.convolution.default(avg_pool2d_default_1, primals_58, primals_57, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_57 = None
        gt_scalar_4 = torch.ops.aten.gt.Scalar(convolution_default_4, 0)
        mul_tensor_4 = torch.ops.aten.mul.Tensor(convolution_default_4, 0.1)
        where_self_4 = torch.ops.aten.where.self(gt_scalar_4, convolution_default_4, mul_tensor_4);  gt_scalar_4 = mul_tensor_4 = None
        convolution_default_5 = torch.ops.aten.convolution.default(where_self_4, primals_60, primals_59, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_59 = None
        gt_scalar_5 = torch.ops.aten.gt.Scalar(convolution_default_5, 0)
        mul_tensor_5 = torch.ops.aten.mul.Tensor(convolution_default_5, 0.1)
        where_self_5 = torch.ops.aten.where.self(gt_scalar_5, convolution_default_5, mul_tensor_5);  gt_scalar_5 = mul_tensor_5 = None
        avg_pool2d_default_2 = torch.ops.aten.avg_pool2d.default(where_self_5, [2, 2])
        convolution_default_6 = torch.ops.aten.convolution.default(avg_pool2d_default_2, primals_62, primals_61, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_61 = None
        gt_scalar_6 = torch.ops.aten.gt.Scalar(convolution_default_6, 0)
        mul_tensor_6 = torch.ops.aten.mul.Tensor(convolution_default_6, 0.1)
        where_self_6 = torch.ops.aten.where.self(gt_scalar_6, convolution_default_6, mul_tensor_6);  gt_scalar_6 = mul_tensor_6 = None
        convolution_default_7 = torch.ops.aten.convolution.default(where_self_6, primals_64, primals_63, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_63 = None
        gt_scalar_7 = torch.ops.aten.gt.Scalar(convolution_default_7, 0)
        mul_tensor_7 = torch.ops.aten.mul.Tensor(convolution_default_7, 0.1)
        where_self_7 = torch.ops.aten.where.self(gt_scalar_7, convolution_default_7, mul_tensor_7);  gt_scalar_7 = mul_tensor_7 = None
        avg_pool2d_default_3 = torch.ops.aten.avg_pool2d.default(where_self_7, [2, 2])
        convolution_default_8 = torch.ops.aten.convolution.default(avg_pool2d_default_3, primals_66, primals_65, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_65 = None
        gt_scalar_8 = torch.ops.aten.gt.Scalar(convolution_default_8, 0)
        mul_tensor_8 = torch.ops.aten.mul.Tensor(convolution_default_8, 0.1)
        where_self_8 = torch.ops.aten.where.self(gt_scalar_8, convolution_default_8, mul_tensor_8);  gt_scalar_8 = mul_tensor_8 = None
        convolution_default_9 = torch.ops.aten.convolution.default(where_self_8, primals_68, primals_67, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_67 = None
        gt_scalar_9 = torch.ops.aten.gt.Scalar(convolution_default_9, 0)
        mul_tensor_9 = torch.ops.aten.mul.Tensor(convolution_default_9, 0.1)
        where_self_9 = torch.ops.aten.where.self(gt_scalar_9, convolution_default_9, mul_tensor_9);  gt_scalar_9 = mul_tensor_9 = None
        avg_pool2d_default_4 = torch.ops.aten.avg_pool2d.default(where_self_9, [2, 2])
        convolution_default_10 = torch.ops.aten.convolution.default(avg_pool2d_default_4, primals_70, primals_69, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_69 = None
        gt_scalar_10 = torch.ops.aten.gt.Scalar(convolution_default_10, 0)
        mul_tensor_10 = torch.ops.aten.mul.Tensor(convolution_default_10, 0.1)
        where_self_10 = torch.ops.aten.where.self(gt_scalar_10, convolution_default_10, mul_tensor_10);  gt_scalar_10 = mul_tensor_10 = None
        convolution_default_11 = torch.ops.aten.convolution.default(where_self_10, primals_72, primals_71, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_71 = None
        gt_scalar_11 = torch.ops.aten.gt.Scalar(convolution_default_11, 0)
        mul_tensor_11 = torch.ops.aten.mul.Tensor(convolution_default_11, 0.1)
        where_self_11 = torch.ops.aten.where.self(gt_scalar_11, convolution_default_11, mul_tensor_11);  gt_scalar_11 = mul_tensor_11 = None
        upsample_bilinear2d_vec = torch.ops.aten.upsample_bilinear2d.vec(where_self_11, None, False, [2.0, 2.0]);  where_self_11 = None
        convolution_default_12 = torch.ops.aten.convolution.default(upsample_bilinear2d_vec, primals_74, primals_73, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_73 = None
        gt_scalar_12 = torch.ops.aten.gt.Scalar(convolution_default_12, 0)
        mul_tensor_12 = torch.ops.aten.mul.Tensor(convolution_default_12, 0.1)
        where_self_12 = torch.ops.aten.where.self(gt_scalar_12, convolution_default_12, mul_tensor_12);  gt_scalar_12 = mul_tensor_12 = None
        cat_default_1 = torch.ops.aten.cat.default([where_self_12, where_self_9], 1);  where_self_12 = None
        convolution_default_13 = torch.ops.aten.convolution.default(cat_default_1, primals_76, primals_75, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_75 = None
        gt_scalar_13 = torch.ops.aten.gt.Scalar(convolution_default_13, 0)
        mul_tensor_13 = torch.ops.aten.mul.Tensor(convolution_default_13, 0.1)
        where_self_13 = torch.ops.aten.where.self(gt_scalar_13, convolution_default_13, mul_tensor_13);  gt_scalar_13 = mul_tensor_13 = None
        upsample_bilinear2d_vec_1 = torch.ops.aten.upsample_bilinear2d.vec(where_self_13, None, False, [2.0, 2.0]);  where_self_13 = None
        convolution_default_14 = torch.ops.aten.convolution.default(upsample_bilinear2d_vec_1, primals_78, primals_77, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_77 = None
        gt_scalar_14 = torch.ops.aten.gt.Scalar(convolution_default_14, 0)
        mul_tensor_14 = torch.ops.aten.mul.Tensor(convolution_default_14, 0.1)
        where_self_14 = torch.ops.aten.where.self(gt_scalar_14, convolution_default_14, mul_tensor_14);  gt_scalar_14 = mul_tensor_14 = None
        cat_default_2 = torch.ops.aten.cat.default([where_self_14, where_self_7], 1);  where_self_14 = None
        convolution_default_15 = torch.ops.aten.convolution.default(cat_default_2, primals_80, primals_79, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_79 = None
        gt_scalar_15 = torch.ops.aten.gt.Scalar(convolution_default_15, 0)
        mul_tensor_15 = torch.ops.aten.mul.Tensor(convolution_default_15, 0.1)
        where_self_15 = torch.ops.aten.where.self(gt_scalar_15, convolution_default_15, mul_tensor_15);  gt_scalar_15 = mul_tensor_15 = None
        upsample_bilinear2d_vec_2 = torch.ops.aten.upsample_bilinear2d.vec(where_self_15, None, False, [2.0, 2.0]);  where_self_15 = None
        convolution_default_16 = torch.ops.aten.convolution.default(upsample_bilinear2d_vec_2, primals_82, primals_81, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_81 = None
        gt_scalar_16 = torch.ops.aten.gt.Scalar(convolution_default_16, 0)
        mul_tensor_16 = torch.ops.aten.mul.Tensor(convolution_default_16, 0.1)
        where_self_16 = torch.ops.aten.where.self(gt_scalar_16, convolution_default_16, mul_tensor_16);  gt_scalar_16 = mul_tensor_16 = None
        cat_default_3 = torch.ops.aten.cat.default([where_self_16, where_self_5], 1);  where_self_16 = None
        convolution_default_17 = torch.ops.aten.convolution.default(cat_default_3, primals_84, primals_83, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_83 = None
        gt_scalar_17 = torch.ops.aten.gt.Scalar(convolution_default_17, 0)
        mul_tensor_17 = torch.ops.aten.mul.Tensor(convolution_default_17, 0.1)
        where_self_17 = torch.ops.aten.where.self(gt_scalar_17, convolution_default_17, mul_tensor_17);  gt_scalar_17 = mul_tensor_17 = None
        upsample_bilinear2d_vec_3 = torch.ops.aten.upsample_bilinear2d.vec(where_self_17, None, False, [2.0, 2.0]);  where_self_17 = None
        convolution_default_18 = torch.ops.aten.convolution.default(upsample_bilinear2d_vec_3, primals_86, primals_85, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_85 = None
        gt_scalar_18 = torch.ops.aten.gt.Scalar(convolution_default_18, 0)
        mul_tensor_18 = torch.ops.aten.mul.Tensor(convolution_default_18, 0.1)
        where_self_18 = torch.ops.aten.where.self(gt_scalar_18, convolution_default_18, mul_tensor_18);  gt_scalar_18 = mul_tensor_18 = None
        cat_default_4 = torch.ops.aten.cat.default([where_self_18, where_self_3], 1);  where_self_18 = None
        convolution_default_19 = torch.ops.aten.convolution.default(cat_default_4, primals_88, primals_87, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_87 = None
        gt_scalar_19 = torch.ops.aten.gt.Scalar(convolution_default_19, 0)
        mul_tensor_19 = torch.ops.aten.mul.Tensor(convolution_default_19, 0.1)
        where_self_19 = torch.ops.aten.where.self(gt_scalar_19, convolution_default_19, mul_tensor_19);  gt_scalar_19 = mul_tensor_19 = None
        upsample_bilinear2d_vec_4 = torch.ops.aten.upsample_bilinear2d.vec(where_self_19, None, False, [2.0, 2.0]);  where_self_19 = None
        convolution_default_20 = torch.ops.aten.convolution.default(upsample_bilinear2d_vec_4, primals_90, primals_89, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_89 = None
        gt_scalar_20 = torch.ops.aten.gt.Scalar(convolution_default_20, 0)
        mul_tensor_20 = torch.ops.aten.mul.Tensor(convolution_default_20, 0.1)
        where_self_20 = torch.ops.aten.where.self(gt_scalar_20, convolution_default_20, mul_tensor_20);  gt_scalar_20 = mul_tensor_20 = None
        cat_default_5 = torch.ops.aten.cat.default([where_self_20, where_self_1], 1);  where_self_20 = None
        convolution_default_21 = torch.ops.aten.convolution.default(cat_default_5, primals_92, primals_91, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_91 = None
        gt_scalar_21 = torch.ops.aten.gt.Scalar(convolution_default_21, 0)
        mul_tensor_21 = torch.ops.aten.mul.Tensor(convolution_default_21, 0.1)
        where_self_21 = torch.ops.aten.where.self(gt_scalar_21, convolution_default_21, mul_tensor_21);  gt_scalar_21 = mul_tensor_21 = None
        convolution_default_22 = torch.ops.aten.convolution.default(where_self_21, primals_52, primals_51, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_51 = None
        gt_scalar_22 = torch.ops.aten.gt.Scalar(convolution_default_22, 0)
        mul_tensor_22 = torch.ops.aten.mul.Tensor(convolution_default_22, 0.1)
        where_self_22 = torch.ops.aten.where.self(gt_scalar_22, convolution_default_22, mul_tensor_22);  gt_scalar_22 = mul_tensor_22 = None
        slice_tensor = torch.ops.aten.slice.Tensor(where_self_22, 0, 0, 9223372036854775807)
        slice_tensor_1 = torch.ops.aten.slice.Tensor(slice_tensor, 1, 0, 2);  slice_tensor = None
        slice_tensor_2 = torch.ops.aten.slice.Tensor(slice_tensor_1, 2, 0, 9223372036854775807);  slice_tensor_1 = None
        slice_tensor_3 = torch.ops.aten.slice.Tensor(slice_tensor_2, 3, 0, 9223372036854775807);  slice_tensor_2 = None
        slice_tensor_4 = torch.ops.aten.slice.Tensor(where_self_22, 0, 0, 9223372036854775807);  where_self_22 = None
        slice_tensor_5 = torch.ops.aten.slice.Tensor(slice_tensor_4, 1, 2, 9223372036854775807);  slice_tensor_4 = None
        slice_tensor_6 = torch.ops.aten.slice.Tensor(slice_tensor_5, 2, 0, 9223372036854775807);  slice_tensor_5 = None
        slice_tensor_7 = torch.ops.aten.slice.Tensor(slice_tensor_6, 3, 0, 9223372036854775807);  slice_tensor_6 = None
        linspace = torch.ops.aten.linspace.default(0.125, 0.875, 7, dtype = torch.float32, device = device(type='cuda', index=0), pin_memory = False)
        index_tensor = torch.ops.aten.index.Tensor(linspace, [primals_115])
        rsub_scalar = torch.ops.aten.rsub.Scalar(index_tensor, 1);  index_tensor = None
        neg_default = torch.ops.aten.neg.default(rsub_scalar);  rsub_scalar = None
        index_tensor_1 = torch.ops.aten.index.Tensor(linspace, [primals_115])
        mul_tensor_23 = torch.ops.aten.mul.Tensor(neg_default, index_tensor_1);  neg_default = index_tensor_1 = None
        index_tensor_2 = torch.ops.aten.index.Tensor(linspace, [primals_115])
        index_tensor_3 = torch.ops.aten.index.Tensor(linspace, [primals_115])
        mul_tensor_24 = torch.ops.aten.mul.Tensor(index_tensor_2, index_tensor_3);  index_tensor_2 = index_tensor_3 = None
        index_tensor_4 = torch.ops.aten.index.Tensor(linspace, [primals_115])
        rsub_scalar_1 = torch.ops.aten.rsub.Scalar(index_tensor_4, 1);  index_tensor_4 = None
        index_tensor_5 = torch.ops.aten.index.Tensor(linspace, [primals_115]);  linspace = None
        rsub_scalar_2 = torch.ops.aten.rsub.Scalar(index_tensor_5, 1);  index_tensor_5 = None
        mul_tensor_25 = torch.ops.aten.mul.Tensor(rsub_scalar_1, rsub_scalar_2);  rsub_scalar_1 = rsub_scalar_2 = None
        unsqueeze_default = torch.ops.aten.unsqueeze.default(mul_tensor_23, 0)
        unsqueeze_default_1 = torch.ops.aten.unsqueeze.default(unsqueeze_default, 1);  unsqueeze_default = None
        unsqueeze_default_2 = torch.ops.aten.unsqueeze.default(unsqueeze_default_1, 2);  unsqueeze_default_1 = None
        slice_tensor_8 = torch.ops.aten.slice.Tensor(unsqueeze_default_2, 3, 0, 9223372036854775807);  unsqueeze_default_2 = None
        permute_default = torch.ops.aten.permute.default(slice_tensor_8, [3, 0, 1, 2]);  slice_tensor_8 = None
        unsqueeze_default_3 = torch.ops.aten.unsqueeze.default(mul_tensor_24, 0);  mul_tensor_24 = None
        unsqueeze_default_4 = torch.ops.aten.unsqueeze.default(unsqueeze_default_3, 1);  unsqueeze_default_3 = None
        unsqueeze_default_5 = torch.ops.aten.unsqueeze.default(unsqueeze_default_4, 2);  unsqueeze_default_4 = None
        slice_tensor_9 = torch.ops.aten.slice.Tensor(unsqueeze_default_5, 3, 0, 9223372036854775807);  unsqueeze_default_5 = None
        permute_default_1 = torch.ops.aten.permute.default(slice_tensor_9, [3, 0, 1, 2]);  slice_tensor_9 = None
        unsqueeze_default_6 = torch.ops.aten.unsqueeze.default(mul_tensor_25, 0);  mul_tensor_25 = None
        unsqueeze_default_7 = torch.ops.aten.unsqueeze.default(unsqueeze_default_6, 1);  unsqueeze_default_6 = None
        unsqueeze_default_8 = torch.ops.aten.unsqueeze.default(unsqueeze_default_7, 2);  unsqueeze_default_7 = None
        slice_tensor_10 = torch.ops.aten.slice.Tensor(unsqueeze_default_8, 3, 0, 9223372036854775807);  unsqueeze_default_8 = None
        permute_default_2 = torch.ops.aten.permute.default(slice_tensor_10, [3, 0, 1, 2]);  slice_tensor_10 = None
        unsqueeze_default_9 = torch.ops.aten.unsqueeze.default(mul_tensor_23, 0);  mul_tensor_23 = None
        unsqueeze_default_10 = torch.ops.aten.unsqueeze.default(unsqueeze_default_9, 1);  unsqueeze_default_9 = None
        unsqueeze_default_11 = torch.ops.aten.unsqueeze.default(unsqueeze_default_10, 2);  unsqueeze_default_10 = None
        slice_tensor_11 = torch.ops.aten.slice.Tensor(unsqueeze_default_11, 3, 0, 9223372036854775807);  unsqueeze_default_11 = None
        permute_default_3 = torch.ops.aten.permute.default(slice_tensor_11, [3, 0, 1, 2]);  slice_tensor_11 = None
        mul_tensor_26 = torch.ops.aten.mul.Tensor(permute_default, slice_tensor_3)
        mul_tensor_27 = torch.ops.aten.mul.Tensor(permute_default_1, slice_tensor_7)
        add_tensor = torch.ops.aten.add.Tensor(mul_tensor_26, mul_tensor_27);  mul_tensor_26 = mul_tensor_27 = None
        mul_tensor_28 = torch.ops.aten.mul.Tensor(permute_default_2, slice_tensor_3)
        mul_tensor_29 = torch.ops.aten.mul.Tensor(permute_default_3, slice_tensor_7)
        add_tensor_1 = torch.ops.aten.add.Tensor(mul_tensor_28, mul_tensor_29);  mul_tensor_28 = mul_tensor_29 = None
        slice_tensor_12 = torch.ops.aten.slice.Tensor(add_tensor, 0, 0, 9223372036854775807)
        select_int = torch.ops.aten.select.int(slice_tensor_12, 1, 0);  slice_tensor_12 = None
        slice_tensor_13 = torch.ops.aten.slice.Tensor(select_int, 1, 0, 9223372036854775807);  select_int = None
        slice_tensor_14 = torch.ops.aten.slice.Tensor(slice_tensor_13, 2, 0, 9223372036854775807);  slice_tensor_13 = None
        slice_tensor_15 = torch.ops.aten.slice.Tensor(add_tensor, 0, 0, 9223372036854775807)
        select_int_1 = torch.ops.aten.select.int(slice_tensor_15, 1, 1);  slice_tensor_15 = None
        slice_tensor_16 = torch.ops.aten.slice.Tensor(select_int_1, 1, 0, 9223372036854775807);  select_int_1 = None
        slice_tensor_17 = torch.ops.aten.slice.Tensor(slice_tensor_16, 2, 0, 9223372036854775807);  slice_tensor_16 = None
        unsqueeze_default_12 = torch.ops.aten.unsqueeze.default(primals_93, 0)
        expand_default = torch.ops.aten.expand.default(unsqueeze_default_12, [6, 352, 352]);  unsqueeze_default_12 = None
        _to_copy_default = torch.ops.aten._to_copy.default(expand_default, dtype = torch.float32);  expand_default = None
        add_tensor_2 = torch.ops.aten.add.Tensor(_to_copy_default, slice_tensor_14);  _to_copy_default = slice_tensor_14 = None
        unsqueeze_default_13 = torch.ops.aten.unsqueeze.default(primals_94, 0)
        expand_default_1 = torch.ops.aten.expand.default(unsqueeze_default_13, [6, 352, 352]);  unsqueeze_default_13 = None
        _to_copy_default_1 = torch.ops.aten._to_copy.default(expand_default_1, dtype = torch.float32);  expand_default_1 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(_to_copy_default_1, slice_tensor_17);  _to_copy_default_1 = slice_tensor_17 = None
        div_tensor = torch.ops.aten.div.Tensor(add_tensor_2, 352);  add_tensor_2 = None
        sub_tensor = torch.ops.aten.sub.Tensor(div_tensor, 0.5);  div_tensor = None
        mul_tensor_30 = torch.ops.aten.mul.Tensor(sub_tensor, 2);  sub_tensor = None
        div_tensor_1 = torch.ops.aten.div.Tensor(add_tensor_3, 352);  add_tensor_3 = None
        sub_tensor_1 = torch.ops.aten.sub.Tensor(div_tensor_1, 0.5);  div_tensor_1 = None
        mul_tensor_31 = torch.ops.aten.mul.Tensor(sub_tensor_1, 2);  sub_tensor_1 = None
        stack_default = torch.ops.aten.stack.default([mul_tensor_30, mul_tensor_31], 3);  mul_tensor_30 = mul_tensor_31 = None
        grid_sampler_2d_default = torch.ops.aten.grid_sampler_2d.default(primals_116, stack_default, 0, 0, False)
        slice_tensor_18 = torch.ops.aten.slice.Tensor(add_tensor_1, 0, 0, 9223372036854775807)
        select_int_2 = torch.ops.aten.select.int(slice_tensor_18, 1, 0);  slice_tensor_18 = None
        slice_tensor_19 = torch.ops.aten.slice.Tensor(select_int_2, 1, 0, 9223372036854775807);  select_int_2 = None
        slice_tensor_20 = torch.ops.aten.slice.Tensor(slice_tensor_19, 2, 0, 9223372036854775807);  slice_tensor_19 = None
        slice_tensor_21 = torch.ops.aten.slice.Tensor(add_tensor_1, 0, 0, 9223372036854775807)
        select_int_3 = torch.ops.aten.select.int(slice_tensor_21, 1, 1);  slice_tensor_21 = None
        slice_tensor_22 = torch.ops.aten.slice.Tensor(select_int_3, 1, 0, 9223372036854775807);  select_int_3 = None
        slice_tensor_23 = torch.ops.aten.slice.Tensor(slice_tensor_22, 2, 0, 9223372036854775807);  slice_tensor_22 = None
        unsqueeze_default_14 = torch.ops.aten.unsqueeze.default(primals_93, 0)
        expand_default_2 = torch.ops.aten.expand.default(unsqueeze_default_14, [6, 352, 352]);  unsqueeze_default_14 = None
        _to_copy_default_2 = torch.ops.aten._to_copy.default(expand_default_2, dtype = torch.float32);  expand_default_2 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(_to_copy_default_2, slice_tensor_20);  _to_copy_default_2 = slice_tensor_20 = None
        unsqueeze_default_15 = torch.ops.aten.unsqueeze.default(primals_94, 0)
        expand_default_3 = torch.ops.aten.expand.default(unsqueeze_default_15, [6, 352, 352]);  unsqueeze_default_15 = None
        _to_copy_default_3 = torch.ops.aten._to_copy.default(expand_default_3, dtype = torch.float32);  expand_default_3 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(_to_copy_default_3, slice_tensor_23);  _to_copy_default_3 = slice_tensor_23 = None
        div_tensor_2 = torch.ops.aten.div.Tensor(add_tensor_4, 352);  add_tensor_4 = None
        sub_tensor_2 = torch.ops.aten.sub.Tensor(div_tensor_2, 0.5);  div_tensor_2 = None
        mul_tensor_32 = torch.ops.aten.mul.Tensor(sub_tensor_2, 2);  sub_tensor_2 = None
        div_tensor_3 = torch.ops.aten.div.Tensor(add_tensor_5, 352);  add_tensor_5 = None
        sub_tensor_3 = torch.ops.aten.sub.Tensor(div_tensor_3, 0.5);  div_tensor_3 = None
        mul_tensor_33 = torch.ops.aten.mul.Tensor(sub_tensor_3, 2);  sub_tensor_3 = None
        stack_default_1 = torch.ops.aten.stack.default([mul_tensor_32, mul_tensor_33], 3);  mul_tensor_32 = mul_tensor_33 = None
        grid_sampler_2d_default_1 = torch.ops.aten.grid_sampler_2d.default(primals_117, stack_default_1, 0, 0, False)
        cat_default_6 = torch.ops.aten.cat.default([primals_116, primals_117, slice_tensor_3, slice_tensor_7, add_tensor_1, add_tensor, grid_sampler_2d_default_1, grid_sampler_2d_default], 1)
        convolution_default_23 = torch.ops.aten.convolution.default(cat_default_6, primals_2, primals_1, [1, 1], [3, 3], [1, 1], False, [0, 0], 1);  primals_1 = None
        gt_scalar_23 = torch.ops.aten.gt.Scalar(convolution_default_23, 0)
        mul_tensor_34 = torch.ops.aten.mul.Tensor(convolution_default_23, 0.1)
        where_self_23 = torch.ops.aten.where.self(gt_scalar_23, convolution_default_23, mul_tensor_34);  gt_scalar_23 = mul_tensor_34 = None
        convolution_default_24 = torch.ops.aten.convolution.default(where_self_23, primals_4, primals_3, [1, 1], [3, 3], [1, 1], False, [0, 0], 1);  primals_3 = None
        gt_scalar_24 = torch.ops.aten.gt.Scalar(convolution_default_24, 0)
        mul_tensor_35 = torch.ops.aten.mul.Tensor(convolution_default_24, 0.1)
        where_self_24 = torch.ops.aten.where.self(gt_scalar_24, convolution_default_24, mul_tensor_35);  gt_scalar_24 = mul_tensor_35 = None
        avg_pool2d_default_5 = torch.ops.aten.avg_pool2d.default(where_self_24, [2, 2])
        convolution_default_25 = torch.ops.aten.convolution.default(avg_pool2d_default_5, primals_8, primals_7, [1, 1], [2, 2], [1, 1], False, [0, 0], 1);  primals_7 = None
        gt_scalar_25 = torch.ops.aten.gt.Scalar(convolution_default_25, 0)
        mul_tensor_36 = torch.ops.aten.mul.Tensor(convolution_default_25, 0.1)
        where_self_25 = torch.ops.aten.where.self(gt_scalar_25, convolution_default_25, mul_tensor_36);  gt_scalar_25 = mul_tensor_36 = None
        convolution_default_26 = torch.ops.aten.convolution.default(where_self_25, primals_10, primals_9, [1, 1], [2, 2], [1, 1], False, [0, 0], 1);  primals_9 = None
        gt_scalar_26 = torch.ops.aten.gt.Scalar(convolution_default_26, 0)
        mul_tensor_37 = torch.ops.aten.mul.Tensor(convolution_default_26, 0.1)
        where_self_26 = torch.ops.aten.where.self(gt_scalar_26, convolution_default_26, mul_tensor_37);  gt_scalar_26 = mul_tensor_37 = None
        avg_pool2d_default_6 = torch.ops.aten.avg_pool2d.default(where_self_26, [2, 2])
        convolution_default_27 = torch.ops.aten.convolution.default(avg_pool2d_default_6, primals_12, primals_11, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_11 = None
        gt_scalar_27 = torch.ops.aten.gt.Scalar(convolution_default_27, 0)
        mul_tensor_38 = torch.ops.aten.mul.Tensor(convolution_default_27, 0.1)
        where_self_27 = torch.ops.aten.where.self(gt_scalar_27, convolution_default_27, mul_tensor_38);  gt_scalar_27 = mul_tensor_38 = None
        convolution_default_28 = torch.ops.aten.convolution.default(where_self_27, primals_14, primals_13, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_13 = None
        gt_scalar_28 = torch.ops.aten.gt.Scalar(convolution_default_28, 0)
        mul_tensor_39 = torch.ops.aten.mul.Tensor(convolution_default_28, 0.1)
        where_self_28 = torch.ops.aten.where.self(gt_scalar_28, convolution_default_28, mul_tensor_39);  gt_scalar_28 = mul_tensor_39 = None
        avg_pool2d_default_7 = torch.ops.aten.avg_pool2d.default(where_self_28, [2, 2])
        convolution_default_29 = torch.ops.aten.convolution.default(avg_pool2d_default_7, primals_16, primals_15, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_15 = None
        gt_scalar_29 = torch.ops.aten.gt.Scalar(convolution_default_29, 0)
        mul_tensor_40 = torch.ops.aten.mul.Tensor(convolution_default_29, 0.1)
        where_self_29 = torch.ops.aten.where.self(gt_scalar_29, convolution_default_29, mul_tensor_40);  gt_scalar_29 = mul_tensor_40 = None
        convolution_default_30 = torch.ops.aten.convolution.default(where_self_29, primals_18, primals_17, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_17 = None
        gt_scalar_30 = torch.ops.aten.gt.Scalar(convolution_default_30, 0)
        mul_tensor_41 = torch.ops.aten.mul.Tensor(convolution_default_30, 0.1)
        where_self_30 = torch.ops.aten.where.self(gt_scalar_30, convolution_default_30, mul_tensor_41);  gt_scalar_30 = mul_tensor_41 = None
        avg_pool2d_default_8 = torch.ops.aten.avg_pool2d.default(where_self_30, [2, 2])
        convolution_default_31 = torch.ops.aten.convolution.default(avg_pool2d_default_8, primals_20, primals_19, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_19 = None
        gt_scalar_31 = torch.ops.aten.gt.Scalar(convolution_default_31, 0)
        mul_tensor_42 = torch.ops.aten.mul.Tensor(convolution_default_31, 0.1)
        where_self_31 = torch.ops.aten.where.self(gt_scalar_31, convolution_default_31, mul_tensor_42);  gt_scalar_31 = mul_tensor_42 = None
        convolution_default_32 = torch.ops.aten.convolution.default(where_self_31, primals_22, primals_21, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_21 = None
        gt_scalar_32 = torch.ops.aten.gt.Scalar(convolution_default_32, 0)
        mul_tensor_43 = torch.ops.aten.mul.Tensor(convolution_default_32, 0.1)
        where_self_32 = torch.ops.aten.where.self(gt_scalar_32, convolution_default_32, mul_tensor_43);  gt_scalar_32 = mul_tensor_43 = None
        avg_pool2d_default_9 = torch.ops.aten.avg_pool2d.default(where_self_32, [2, 2])
        convolution_default_33 = torch.ops.aten.convolution.default(avg_pool2d_default_9, primals_24, primals_23, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_23 = None
        gt_scalar_33 = torch.ops.aten.gt.Scalar(convolution_default_33, 0)
        mul_tensor_44 = torch.ops.aten.mul.Tensor(convolution_default_33, 0.1)
        where_self_33 = torch.ops.aten.where.self(gt_scalar_33, convolution_default_33, mul_tensor_44);  gt_scalar_33 = mul_tensor_44 = None
        convolution_default_34 = torch.ops.aten.convolution.default(where_self_33, primals_26, primals_25, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_25 = None
        gt_scalar_34 = torch.ops.aten.gt.Scalar(convolution_default_34, 0)
        mul_tensor_45 = torch.ops.aten.mul.Tensor(convolution_default_34, 0.1)
        where_self_34 = torch.ops.aten.where.self(gt_scalar_34, convolution_default_34, mul_tensor_45);  gt_scalar_34 = mul_tensor_45 = None
        upsample_bilinear2d_vec_5 = torch.ops.aten.upsample_bilinear2d.vec(where_self_34, None, False, [2.0, 2.0]);  where_self_34 = None
        convolution_default_35 = torch.ops.aten.convolution.default(upsample_bilinear2d_vec_5, primals_28, primals_27, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_27 = None
        gt_scalar_35 = torch.ops.aten.gt.Scalar(convolution_default_35, 0)
        mul_tensor_46 = torch.ops.aten.mul.Tensor(convolution_default_35, 0.1)
        where_self_35 = torch.ops.aten.where.self(gt_scalar_35, convolution_default_35, mul_tensor_46);  gt_scalar_35 = mul_tensor_46 = None
        cat_default_7 = torch.ops.aten.cat.default([where_self_35, where_self_32], 1);  where_self_35 = None
        convolution_default_36 = torch.ops.aten.convolution.default(cat_default_7, primals_30, primals_29, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_29 = None
        gt_scalar_36 = torch.ops.aten.gt.Scalar(convolution_default_36, 0)
        mul_tensor_47 = torch.ops.aten.mul.Tensor(convolution_default_36, 0.1)
        where_self_36 = torch.ops.aten.where.self(gt_scalar_36, convolution_default_36, mul_tensor_47);  gt_scalar_36 = mul_tensor_47 = None
        upsample_bilinear2d_vec_6 = torch.ops.aten.upsample_bilinear2d.vec(where_self_36, None, False, [2.0, 2.0]);  where_self_36 = None
        convolution_default_37 = torch.ops.aten.convolution.default(upsample_bilinear2d_vec_6, primals_32, primals_31, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_31 = None
        gt_scalar_37 = torch.ops.aten.gt.Scalar(convolution_default_37, 0)
        mul_tensor_48 = torch.ops.aten.mul.Tensor(convolution_default_37, 0.1)
        where_self_37 = torch.ops.aten.where.self(gt_scalar_37, convolution_default_37, mul_tensor_48);  gt_scalar_37 = mul_tensor_48 = None
        cat_default_8 = torch.ops.aten.cat.default([where_self_37, where_self_30], 1);  where_self_37 = None
        convolution_default_38 = torch.ops.aten.convolution.default(cat_default_8, primals_34, primals_33, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_33 = None
        gt_scalar_38 = torch.ops.aten.gt.Scalar(convolution_default_38, 0)
        mul_tensor_49 = torch.ops.aten.mul.Tensor(convolution_default_38, 0.1)
        where_self_38 = torch.ops.aten.where.self(gt_scalar_38, convolution_default_38, mul_tensor_49);  gt_scalar_38 = mul_tensor_49 = None
        upsample_bilinear2d_vec_7 = torch.ops.aten.upsample_bilinear2d.vec(where_self_38, None, False, [2.0, 2.0]);  where_self_38 = None
        convolution_default_39 = torch.ops.aten.convolution.default(upsample_bilinear2d_vec_7, primals_36, primals_35, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_35 = None
        gt_scalar_39 = torch.ops.aten.gt.Scalar(convolution_default_39, 0)
        mul_tensor_50 = torch.ops.aten.mul.Tensor(convolution_default_39, 0.1)
        where_self_39 = torch.ops.aten.where.self(gt_scalar_39, convolution_default_39, mul_tensor_50);  gt_scalar_39 = mul_tensor_50 = None
        cat_default_9 = torch.ops.aten.cat.default([where_self_39, where_self_28], 1);  where_self_39 = None
        convolution_default_40 = torch.ops.aten.convolution.default(cat_default_9, primals_38, primals_37, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_37 = None
        gt_scalar_40 = torch.ops.aten.gt.Scalar(convolution_default_40, 0)
        mul_tensor_51 = torch.ops.aten.mul.Tensor(convolution_default_40, 0.1)
        where_self_40 = torch.ops.aten.where.self(gt_scalar_40, convolution_default_40, mul_tensor_51);  gt_scalar_40 = mul_tensor_51 = None
        upsample_bilinear2d_vec_8 = torch.ops.aten.upsample_bilinear2d.vec(where_self_40, None, False, [2.0, 2.0]);  where_self_40 = None
        convolution_default_41 = torch.ops.aten.convolution.default(upsample_bilinear2d_vec_8, primals_40, primals_39, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_39 = None
        gt_scalar_41 = torch.ops.aten.gt.Scalar(convolution_default_41, 0)
        mul_tensor_52 = torch.ops.aten.mul.Tensor(convolution_default_41, 0.1)
        where_self_41 = torch.ops.aten.where.self(gt_scalar_41, convolution_default_41, mul_tensor_52);  gt_scalar_41 = mul_tensor_52 = None
        cat_default_10 = torch.ops.aten.cat.default([where_self_41, where_self_26], 1);  where_self_41 = None
        convolution_default_42 = torch.ops.aten.convolution.default(cat_default_10, primals_42, primals_41, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_41 = None
        gt_scalar_42 = torch.ops.aten.gt.Scalar(convolution_default_42, 0)
        mul_tensor_53 = torch.ops.aten.mul.Tensor(convolution_default_42, 0.1)
        where_self_42 = torch.ops.aten.where.self(gt_scalar_42, convolution_default_42, mul_tensor_53);  gt_scalar_42 = mul_tensor_53 = None
        upsample_bilinear2d_vec_9 = torch.ops.aten.upsample_bilinear2d.vec(where_self_42, None, False, [2.0, 2.0]);  where_self_42 = None
        convolution_default_43 = torch.ops.aten.convolution.default(upsample_bilinear2d_vec_9, primals_44, primals_43, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_43 = None
        gt_scalar_43 = torch.ops.aten.gt.Scalar(convolution_default_43, 0)
        mul_tensor_54 = torch.ops.aten.mul.Tensor(convolution_default_43, 0.1)
        where_self_43 = torch.ops.aten.where.self(gt_scalar_43, convolution_default_43, mul_tensor_54);  gt_scalar_43 = mul_tensor_54 = None
        cat_default_11 = torch.ops.aten.cat.default([where_self_43, where_self_24], 1);  where_self_43 = None
        convolution_default_44 = torch.ops.aten.convolution.default(cat_default_11, primals_46, primals_45, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_45 = None
        gt_scalar_44 = torch.ops.aten.gt.Scalar(convolution_default_44, 0)
        mul_tensor_55 = torch.ops.aten.mul.Tensor(convolution_default_44, 0.1)
        where_self_44 = torch.ops.aten.where.self(gt_scalar_44, convolution_default_44, mul_tensor_55);  gt_scalar_44 = mul_tensor_55 = None
        convolution_default_45 = torch.ops.aten.convolution.default(where_self_44, primals_6, primals_5, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_5 = None
        gt_scalar_45 = torch.ops.aten.gt.Scalar(convolution_default_45, 0)
        mul_tensor_56 = torch.ops.aten.mul.Tensor(convolution_default_45, 0.1)
        where_self_45 = torch.ops.aten.where.self(gt_scalar_45, convolution_default_45, mul_tensor_56);  gt_scalar_45 = mul_tensor_56 = None
        slice_tensor_24 = torch.ops.aten.slice.Tensor(where_self_45, 0, 0, 9223372036854775807)
        slice_tensor_25 = torch.ops.aten.slice.Tensor(slice_tensor_24, 1, 0, 2);  slice_tensor_24 = None
        slice_tensor_26 = torch.ops.aten.slice.Tensor(slice_tensor_25, 2, 0, 9223372036854775807);  slice_tensor_25 = None
        slice_tensor_27 = torch.ops.aten.slice.Tensor(slice_tensor_26, 3, 0, 9223372036854775807);  slice_tensor_26 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(slice_tensor_27, add_tensor);  slice_tensor_27 = add_tensor = None
        slice_tensor_28 = torch.ops.aten.slice.Tensor(where_self_45, 0, 0, 9223372036854775807)
        slice_tensor_29 = torch.ops.aten.slice.Tensor(slice_tensor_28, 1, 2, 4);  slice_tensor_28 = None
        slice_tensor_30 = torch.ops.aten.slice.Tensor(slice_tensor_29, 2, 0, 9223372036854775807);  slice_tensor_29 = None
        slice_tensor_31 = torch.ops.aten.slice.Tensor(slice_tensor_30, 3, 0, 9223372036854775807);  slice_tensor_30 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(slice_tensor_31, add_tensor_1);  slice_tensor_31 = add_tensor_1 = None
        slice_tensor_32 = torch.ops.aten.slice.Tensor(where_self_45, 0, 0, 9223372036854775807);  where_self_45 = None
        slice_tensor_33 = torch.ops.aten.slice.Tensor(slice_tensor_32, 1, 4, 5);  slice_tensor_32 = None
        slice_tensor_34 = torch.ops.aten.slice.Tensor(slice_tensor_33, 2, 0, 9223372036854775807);  slice_tensor_33 = None
        slice_tensor_35 = torch.ops.aten.slice.Tensor(slice_tensor_34, 3, 0, 9223372036854775807);  slice_tensor_34 = None
        sigmoid_default = torch.ops.aten.sigmoid.default(slice_tensor_35);  slice_tensor_35 = None
        rsub_scalar_3 = torch.ops.aten.rsub.Scalar(sigmoid_default, 1)
        slice_tensor_36 = torch.ops.aten.slice.Tensor(add_tensor_6, 0, 0, 9223372036854775807)
        select_int_4 = torch.ops.aten.select.int(slice_tensor_36, 1, 0);  slice_tensor_36 = None
        slice_tensor_37 = torch.ops.aten.slice.Tensor(select_int_4, 1, 0, 9223372036854775807);  select_int_4 = None
        slice_tensor_38 = torch.ops.aten.slice.Tensor(slice_tensor_37, 2, 0, 9223372036854775807);  slice_tensor_37 = None
        slice_tensor_39 = torch.ops.aten.slice.Tensor(add_tensor_6, 0, 0, 9223372036854775807);  add_tensor_6 = None
        select_int_5 = torch.ops.aten.select.int(slice_tensor_39, 1, 1);  slice_tensor_39 = None
        slice_tensor_40 = torch.ops.aten.slice.Tensor(select_int_5, 1, 0, 9223372036854775807);  select_int_5 = None
        slice_tensor_41 = torch.ops.aten.slice.Tensor(slice_tensor_40, 2, 0, 9223372036854775807);  slice_tensor_40 = None
        unsqueeze_default_16 = torch.ops.aten.unsqueeze.default(primals_93, 0)
        expand_default_4 = torch.ops.aten.expand.default(unsqueeze_default_16, [6, 352, 352]);  unsqueeze_default_16 = None
        _to_copy_default_4 = torch.ops.aten._to_copy.default(expand_default_4, dtype = torch.float32);  expand_default_4 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(_to_copy_default_4, slice_tensor_38);  _to_copy_default_4 = slice_tensor_38 = None
        unsqueeze_default_17 = torch.ops.aten.unsqueeze.default(primals_94, 0)
        expand_default_5 = torch.ops.aten.expand.default(unsqueeze_default_17, [6, 352, 352]);  unsqueeze_default_17 = None
        _to_copy_default_5 = torch.ops.aten._to_copy.default(expand_default_5, dtype = torch.float32);  expand_default_5 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(_to_copy_default_5, slice_tensor_41);  _to_copy_default_5 = slice_tensor_41 = None
        div_tensor_4 = torch.ops.aten.div.Tensor(add_tensor_8, 352);  add_tensor_8 = None
        sub_tensor_4 = torch.ops.aten.sub.Tensor(div_tensor_4, 0.5);  div_tensor_4 = None
        mul_tensor_57 = torch.ops.aten.mul.Tensor(sub_tensor_4, 2);  sub_tensor_4 = None
        div_tensor_5 = torch.ops.aten.div.Tensor(add_tensor_9, 352);  add_tensor_9 = None
        sub_tensor_5 = torch.ops.aten.sub.Tensor(div_tensor_5, 0.5);  div_tensor_5 = None
        mul_tensor_58 = torch.ops.aten.mul.Tensor(sub_tensor_5, 2);  sub_tensor_5 = None
        stack_default_2 = torch.ops.aten.stack.default([mul_tensor_57, mul_tensor_58], 3);  mul_tensor_57 = mul_tensor_58 = None
        grid_sampler_2d_default_2 = torch.ops.aten.grid_sampler_2d.default(primals_116, stack_default_2, 0, 0, False)
        slice_tensor_42 = torch.ops.aten.slice.Tensor(add_tensor_7, 0, 0, 9223372036854775807)
        select_int_6 = torch.ops.aten.select.int(slice_tensor_42, 1, 0);  slice_tensor_42 = None
        slice_tensor_43 = torch.ops.aten.slice.Tensor(select_int_6, 1, 0, 9223372036854775807);  select_int_6 = None
        slice_tensor_44 = torch.ops.aten.slice.Tensor(slice_tensor_43, 2, 0, 9223372036854775807);  slice_tensor_43 = None
        slice_tensor_45 = torch.ops.aten.slice.Tensor(add_tensor_7, 0, 0, 9223372036854775807);  add_tensor_7 = None
        select_int_7 = torch.ops.aten.select.int(slice_tensor_45, 1, 1);  slice_tensor_45 = None
        slice_tensor_46 = torch.ops.aten.slice.Tensor(select_int_7, 1, 0, 9223372036854775807);  select_int_7 = None
        slice_tensor_47 = torch.ops.aten.slice.Tensor(slice_tensor_46, 2, 0, 9223372036854775807);  slice_tensor_46 = None
        unsqueeze_default_18 = torch.ops.aten.unsqueeze.default(primals_93, 0)
        expand_default_6 = torch.ops.aten.expand.default(unsqueeze_default_18, [6, 352, 352]);  unsqueeze_default_18 = None
        _to_copy_default_6 = torch.ops.aten._to_copy.default(expand_default_6, dtype = torch.float32);  expand_default_6 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(_to_copy_default_6, slice_tensor_44);  _to_copy_default_6 = slice_tensor_44 = None
        unsqueeze_default_19 = torch.ops.aten.unsqueeze.default(primals_94, 0)
        expand_default_7 = torch.ops.aten.expand.default(unsqueeze_default_19, [6, 352, 352]);  unsqueeze_default_19 = None
        _to_copy_default_7 = torch.ops.aten._to_copy.default(expand_default_7, dtype = torch.float32);  expand_default_7 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(_to_copy_default_7, slice_tensor_47);  _to_copy_default_7 = slice_tensor_47 = None
        div_tensor_6 = torch.ops.aten.div.Tensor(add_tensor_10, 352);  add_tensor_10 = None
        sub_tensor_6 = torch.ops.aten.sub.Tensor(div_tensor_6, 0.5);  div_tensor_6 = None
        mul_tensor_59 = torch.ops.aten.mul.Tensor(sub_tensor_6, 2);  sub_tensor_6 = None
        div_tensor_7 = torch.ops.aten.div.Tensor(add_tensor_11, 352);  add_tensor_11 = None
        sub_tensor_7 = torch.ops.aten.sub.Tensor(div_tensor_7, 0.5);  div_tensor_7 = None
        mul_tensor_60 = torch.ops.aten.mul.Tensor(sub_tensor_7, 2);  sub_tensor_7 = None
        stack_default_3 = torch.ops.aten.stack.default([mul_tensor_59, mul_tensor_60], 3);  mul_tensor_59 = mul_tensor_60 = None
        grid_sampler_2d_default_3 = torch.ops.aten.grid_sampler_2d.default(primals_117, stack_default_3, 0, 0, False)
        linspace_1 = torch.ops.aten.linspace.default(0.125, 0.875, 7, dtype = torch.float32, device = device(type='cuda', index=0), pin_memory = False)
        index_tensor_6 = torch.ops.aten.index.Tensor(linspace_1, [primals_115])
        rsub_scalar_4 = torch.ops.aten.rsub.Scalar(index_tensor_6, 1);  index_tensor_6 = None
        index_tensor_7 = torch.ops.aten.index.Tensor(linspace_1, [primals_115]);  linspace_1 = primals_115 = None
        unsqueeze_default_20 = torch.ops.aten.unsqueeze.default(rsub_scalar_4, 0);  rsub_scalar_4 = None
        unsqueeze_default_21 = torch.ops.aten.unsqueeze.default(unsqueeze_default_20, 1);  unsqueeze_default_20 = None
        unsqueeze_default_22 = torch.ops.aten.unsqueeze.default(unsqueeze_default_21, 2);  unsqueeze_default_21 = None
        slice_tensor_48 = torch.ops.aten.slice.Tensor(unsqueeze_default_22, 3, 0, 9223372036854775807);  unsqueeze_default_22 = None
        permute_default_4 = torch.ops.aten.permute.default(slice_tensor_48, [3, 0, 1, 2]);  slice_tensor_48 = None
        unsqueeze_default_23 = torch.ops.aten.unsqueeze.default(index_tensor_7, 0);  index_tensor_7 = None
        unsqueeze_default_24 = torch.ops.aten.unsqueeze.default(unsqueeze_default_23, 1);  unsqueeze_default_23 = None
        unsqueeze_default_25 = torch.ops.aten.unsqueeze.default(unsqueeze_default_24, 2);  unsqueeze_default_24 = None
        slice_tensor_49 = torch.ops.aten.slice.Tensor(unsqueeze_default_25, 3, 0, 9223372036854775807);  unsqueeze_default_25 = None
        permute_default_5 = torch.ops.aten.permute.default(slice_tensor_49, [3, 0, 1, 2]);  slice_tensor_49 = None
        mul_tensor_61 = torch.ops.aten.mul.Tensor(permute_default_4, sigmoid_default)
        mul_tensor_62 = torch.ops.aten.mul.Tensor(mul_tensor_61, grid_sampler_2d_default_2)
        mul_tensor_63 = torch.ops.aten.mul.Tensor(permute_default_5, rsub_scalar_3)
        mul_tensor_64 = torch.ops.aten.mul.Tensor(mul_tensor_63, grid_sampler_2d_default_3)
        add_tensor_12 = torch.ops.aten.add.Tensor(mul_tensor_62, mul_tensor_64);  mul_tensor_62 = mul_tensor_64 = None
        mul_tensor_65 = torch.ops.aten.mul.Tensor(permute_default_4, sigmoid_default)
        mul_tensor_66 = torch.ops.aten.mul.Tensor(permute_default_5, rsub_scalar_3);  rsub_scalar_3 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(mul_tensor_65, mul_tensor_66);  mul_tensor_65 = mul_tensor_66 = None
        div_tensor_8 = torch.ops.aten.div.Tensor(add_tensor_12, add_tensor_13)
        sub_tensor_8 = torch.ops.aten.sub.Tensor(div_tensor_8, primals_118)
        abs_default = torch.ops.aten.abs.default(sub_tensor_8)
        mean_default = torch.ops.aten.mean.default(abs_default);  abs_default = None
        convolution_default_46 = torch.ops.aten.convolution.default(div_tensor_8, primals_96, primals_95, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        relu__default = torch.ops.aten.relu_.default(convolution_default_46);  convolution_default_46 = None
        convolution_default_47 = torch.ops.aten.convolution.default(relu__default, primals_108, primals_107, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        relu__default_1 = torch.ops.aten.relu_.default(convolution_default_47);  convolution_default_47 = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu__default_1, [2, 2], [2, 2])
        getitem = max_pool2d_with_indices_default[0]
        getitem_1 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_48 = torch.ops.aten.convolution.default(getitem, primals_112, primals_111, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        relu__default_2 = torch.ops.aten.relu_.default(convolution_default_48);  convolution_default_48 = None
        convolution_default_49 = torch.ops.aten.convolution.default(relu__default_2, primals_114, primals_113, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        relu__default_3 = torch.ops.aten.relu_.default(convolution_default_49);  convolution_default_49 = None
        max_pool2d_with_indices_default_1 = torch.ops.aten.max_pool2d_with_indices.default(relu__default_3, [2, 2], [2, 2])
        getitem_2 = max_pool2d_with_indices_default_1[0]
        getitem_3 = max_pool2d_with_indices_default_1[1];  max_pool2d_with_indices_default_1 = None
        convolution_default_50 = torch.ops.aten.convolution.default(getitem_2, primals_98, primals_97, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        relu__default_4 = torch.ops.aten.relu_.default(convolution_default_50);  convolution_default_50 = None
        convolution_default_51 = torch.ops.aten.convolution.default(relu__default_4, primals_100, primals_99, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        relu__default_5 = torch.ops.aten.relu_.default(convolution_default_51);  convolution_default_51 = None
        convolution_default_52 = torch.ops.aten.convolution.default(relu__default_5, primals_102, primals_101, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        relu__default_6 = torch.ops.aten.relu_.default(convolution_default_52);  convolution_default_52 = None
        max_pool2d_with_indices_default_2 = torch.ops.aten.max_pool2d_with_indices.default(relu__default_6, [2, 2], [2, 2])
        getitem_4 = max_pool2d_with_indices_default_2[0]
        getitem_5 = max_pool2d_with_indices_default_2[1];  max_pool2d_with_indices_default_2 = None
        convolution_default_53 = torch.ops.aten.convolution.default(getitem_4, primals_104, primals_103, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        relu__default_7 = torch.ops.aten.relu_.default(convolution_default_53);  convolution_default_53 = None
        convolution_default_54 = torch.ops.aten.convolution.default(relu__default_7, primals_106, primals_105, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        relu__default_8 = torch.ops.aten.relu_.default(convolution_default_54);  convolution_default_54 = None
        convolution_default_55 = torch.ops.aten.convolution.default(relu__default_8, primals_110, primals_109, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        convolution_default_56 = torch.ops.aten.convolution.default(primals_118, primals_96, primals_95, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_95 = None
        relu__default_9 = torch.ops.aten.relu_.default(convolution_default_56);  convolution_default_56 = None
        convolution_default_57 = torch.ops.aten.convolution.default(relu__default_9, primals_108, primals_107, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  relu__default_9 = primals_107 = None
        relu__default_10 = torch.ops.aten.relu_.default(convolution_default_57);  convolution_default_57 = None
        max_pool2d_with_indices_default_3 = torch.ops.aten.max_pool2d_with_indices.default(relu__default_10, [2, 2], [2, 2]);  relu__default_10 = None
        getitem_6 = max_pool2d_with_indices_default_3[0];  max_pool2d_with_indices_default_3 = None
        convolution_default_58 = torch.ops.aten.convolution.default(getitem_6, primals_112, primals_111, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  getitem_6 = primals_111 = None
        relu__default_11 = torch.ops.aten.relu_.default(convolution_default_58);  convolution_default_58 = None
        convolution_default_59 = torch.ops.aten.convolution.default(relu__default_11, primals_114, primals_113, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  relu__default_11 = primals_113 = None
        relu__default_12 = torch.ops.aten.relu_.default(convolution_default_59);  convolution_default_59 = None
        max_pool2d_with_indices_default_4 = torch.ops.aten.max_pool2d_with_indices.default(relu__default_12, [2, 2], [2, 2]);  relu__default_12 = None
        getitem_8 = max_pool2d_with_indices_default_4[0];  max_pool2d_with_indices_default_4 = None
        convolution_default_60 = torch.ops.aten.convolution.default(getitem_8, primals_98, primals_97, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  getitem_8 = primals_97 = None
        relu__default_13 = torch.ops.aten.relu_.default(convolution_default_60);  convolution_default_60 = None
        convolution_default_61 = torch.ops.aten.convolution.default(relu__default_13, primals_100, primals_99, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  relu__default_13 = primals_99 = None
        relu__default_14 = torch.ops.aten.relu_.default(convolution_default_61);  convolution_default_61 = None
        convolution_default_62 = torch.ops.aten.convolution.default(relu__default_14, primals_102, primals_101, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  relu__default_14 = primals_101 = None
        relu__default_15 = torch.ops.aten.relu_.default(convolution_default_62);  convolution_default_62 = None
        max_pool2d_with_indices_default_5 = torch.ops.aten.max_pool2d_with_indices.default(relu__default_15, [2, 2], [2, 2]);  relu__default_15 = None
        getitem_10 = max_pool2d_with_indices_default_5[0];  max_pool2d_with_indices_default_5 = None
        convolution_default_63 = torch.ops.aten.convolution.default(getitem_10, primals_104, primals_103, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  getitem_10 = primals_103 = None
        relu__default_16 = torch.ops.aten.relu_.default(convolution_default_63);  convolution_default_63 = None
        convolution_default_64 = torch.ops.aten.convolution.default(relu__default_16, primals_106, primals_105, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  relu__default_16 = primals_105 = None
        relu__default_17 = torch.ops.aten.relu_.default(convolution_default_64);  convolution_default_64 = None
        convolution_default_65 = torch.ops.aten.convolution.default(relu__default_17, primals_110, primals_109, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  relu__default_17 = primals_109 = None
        mse_loss_default = torch.ops.aten.mse_loss.default(convolution_default_55, convolution_default_65)
        sub_tensor_9 = torch.ops.aten.sub.Tensor(grid_sampler_2d_default, primals_118);  grid_sampler_2d_default = None
        abs_default_1 = torch.ops.aten.abs.default(sub_tensor_9)
        mean_default_1 = torch.ops.aten.mean.default(abs_default_1);  abs_default_1 = None
        sub_tensor_10 = torch.ops.aten.sub.Tensor(grid_sampler_2d_default_1, primals_118);  grid_sampler_2d_default_1 = primals_118 = None
        abs_default_2 = torch.ops.aten.abs.default(sub_tensor_10)
        mean_default_2 = torch.ops.aten.mean.default(abs_default_2);  abs_default_2 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(mean_default_1, mean_default_2);  mean_default_1 = mean_default_2 = None
        slice_tensor_50 = torch.ops.aten.slice.Tensor(slice_tensor_7, 0, 0, 9223372036854775807)
        select_int_8 = torch.ops.aten.select.int(slice_tensor_50, 1, 0);  slice_tensor_50 = None
        slice_tensor_51 = torch.ops.aten.slice.Tensor(select_int_8, 1, 0, 9223372036854775807);  select_int_8 = None
        slice_tensor_52 = torch.ops.aten.slice.Tensor(slice_tensor_51, 2, 0, 9223372036854775807);  slice_tensor_51 = None
        slice_tensor_53 = torch.ops.aten.slice.Tensor(slice_tensor_7, 0, 0, 9223372036854775807)
        select_int_9 = torch.ops.aten.select.int(slice_tensor_53, 1, 1);  slice_tensor_53 = None
        slice_tensor_54 = torch.ops.aten.slice.Tensor(select_int_9, 1, 0, 9223372036854775807);  select_int_9 = None
        slice_tensor_55 = torch.ops.aten.slice.Tensor(slice_tensor_54, 2, 0, 9223372036854775807);  slice_tensor_54 = None
        unsqueeze_default_26 = torch.ops.aten.unsqueeze.default(primals_93, 0)
        expand_default_8 = torch.ops.aten.expand.default(unsqueeze_default_26, [6, 352, 352]);  unsqueeze_default_26 = None
        _to_copy_default_8 = torch.ops.aten._to_copy.default(expand_default_8, dtype = torch.float32);  expand_default_8 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(_to_copy_default_8, slice_tensor_52);  _to_copy_default_8 = slice_tensor_52 = None
        unsqueeze_default_27 = torch.ops.aten.unsqueeze.default(primals_94, 0)
        expand_default_9 = torch.ops.aten.expand.default(unsqueeze_default_27, [6, 352, 352]);  unsqueeze_default_27 = None
        _to_copy_default_9 = torch.ops.aten._to_copy.default(expand_default_9, dtype = torch.float32);  expand_default_9 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(_to_copy_default_9, slice_tensor_55);  _to_copy_default_9 = slice_tensor_55 = None
        div_tensor_9 = torch.ops.aten.div.Tensor(add_tensor_15, 352);  add_tensor_15 = None
        sub_tensor_11 = torch.ops.aten.sub.Tensor(div_tensor_9, 0.5);  div_tensor_9 = None
        mul_tensor_67 = torch.ops.aten.mul.Tensor(sub_tensor_11, 2);  sub_tensor_11 = None
        div_tensor_10 = torch.ops.aten.div.Tensor(add_tensor_16, 352);  add_tensor_16 = None
        sub_tensor_12 = torch.ops.aten.sub.Tensor(div_tensor_10, 0.5);  div_tensor_10 = None
        mul_tensor_68 = torch.ops.aten.mul.Tensor(sub_tensor_12, 2);  sub_tensor_12 = None
        stack_default_4 = torch.ops.aten.stack.default([mul_tensor_67, mul_tensor_68], 3);  mul_tensor_67 = mul_tensor_68 = None
        grid_sampler_2d_default_4 = torch.ops.aten.grid_sampler_2d.default(primals_116, stack_default_4, 0, 0, False)
        sub_tensor_13 = torch.ops.aten.sub.Tensor(grid_sampler_2d_default_4, primals_117);  grid_sampler_2d_default_4 = None
        abs_default_3 = torch.ops.aten.abs.default(sub_tensor_13)
        mean_default_3 = torch.ops.aten.mean.default(abs_default_3);  abs_default_3 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(add_tensor_14, mean_default_3);  add_tensor_14 = mean_default_3 = None
        slice_tensor_56 = torch.ops.aten.slice.Tensor(slice_tensor_3, 0, 0, 9223372036854775807)
        select_int_10 = torch.ops.aten.select.int(slice_tensor_56, 1, 0);  slice_tensor_56 = None
        slice_tensor_57 = torch.ops.aten.slice.Tensor(select_int_10, 1, 0, 9223372036854775807);  select_int_10 = None
        slice_tensor_58 = torch.ops.aten.slice.Tensor(slice_tensor_57, 2, 0, 9223372036854775807);  slice_tensor_57 = None
        slice_tensor_59 = torch.ops.aten.slice.Tensor(slice_tensor_3, 0, 0, 9223372036854775807)
        select_int_11 = torch.ops.aten.select.int(slice_tensor_59, 1, 1);  slice_tensor_59 = None
        slice_tensor_60 = torch.ops.aten.slice.Tensor(select_int_11, 1, 0, 9223372036854775807);  select_int_11 = None
        slice_tensor_61 = torch.ops.aten.slice.Tensor(slice_tensor_60, 2, 0, 9223372036854775807);  slice_tensor_60 = None
        unsqueeze_default_28 = torch.ops.aten.unsqueeze.default(primals_93, 0);  primals_93 = None
        expand_default_10 = torch.ops.aten.expand.default(unsqueeze_default_28, [6, 352, 352]);  unsqueeze_default_28 = None
        _to_copy_default_10 = torch.ops.aten._to_copy.default(expand_default_10, dtype = torch.float32);  expand_default_10 = None
        add_tensor_18 = torch.ops.aten.add.Tensor(_to_copy_default_10, slice_tensor_58);  _to_copy_default_10 = slice_tensor_58 = None
        unsqueeze_default_29 = torch.ops.aten.unsqueeze.default(primals_94, 0);  primals_94 = None
        expand_default_11 = torch.ops.aten.expand.default(unsqueeze_default_29, [6, 352, 352]);  unsqueeze_default_29 = None
        _to_copy_default_11 = torch.ops.aten._to_copy.default(expand_default_11, dtype = torch.float32);  expand_default_11 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(_to_copy_default_11, slice_tensor_61);  _to_copy_default_11 = slice_tensor_61 = None
        div_tensor_11 = torch.ops.aten.div.Tensor(add_tensor_18, 352);  add_tensor_18 = None
        sub_tensor_14 = torch.ops.aten.sub.Tensor(div_tensor_11, 0.5);  div_tensor_11 = None
        mul_tensor_69 = torch.ops.aten.mul.Tensor(sub_tensor_14, 2);  sub_tensor_14 = None
        div_tensor_12 = torch.ops.aten.div.Tensor(add_tensor_19, 352);  add_tensor_19 = None
        sub_tensor_15 = torch.ops.aten.sub.Tensor(div_tensor_12, 0.5);  div_tensor_12 = None
        mul_tensor_70 = torch.ops.aten.mul.Tensor(sub_tensor_15, 2);  sub_tensor_15 = None
        stack_default_5 = torch.ops.aten.stack.default([mul_tensor_69, mul_tensor_70], 3);  mul_tensor_69 = mul_tensor_70 = None
        grid_sampler_2d_default_5 = torch.ops.aten.grid_sampler_2d.default(primals_117, stack_default_5, 0, 0, False)
        sub_tensor_16 = torch.ops.aten.sub.Tensor(grid_sampler_2d_default_5, primals_116);  grid_sampler_2d_default_5 = None
        abs_default_4 = torch.ops.aten.abs.default(sub_tensor_16)
        mean_default_4 = torch.ops.aten.mean.default(abs_default_4);  abs_default_4 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(add_tensor_17, mean_default_4);  add_tensor_17 = mean_default_4 = None
        slice_tensor_62 = torch.ops.aten.slice.Tensor(slice_tensor_7, 0, 0, 9223372036854775807)
        slice_tensor_63 = torch.ops.aten.slice.Tensor(slice_tensor_62, 1, 0, 9223372036854775807);  slice_tensor_62 = None
        slice_tensor_64 = torch.ops.aten.slice.Tensor(slice_tensor_63, 2, 0, 9223372036854775807);  slice_tensor_63 = None
        slice_tensor_65 = torch.ops.aten.slice.Tensor(slice_tensor_64, 3, 0, -1);  slice_tensor_64 = None
        slice_tensor_66 = torch.ops.aten.slice.Tensor(slice_tensor_7, 0, 0, 9223372036854775807)
        slice_tensor_67 = torch.ops.aten.slice.Tensor(slice_tensor_66, 1, 0, 9223372036854775807);  slice_tensor_66 = None
        slice_tensor_68 = torch.ops.aten.slice.Tensor(slice_tensor_67, 2, 0, 9223372036854775807);  slice_tensor_67 = None
        slice_tensor_69 = torch.ops.aten.slice.Tensor(slice_tensor_68, 3, 1, 9223372036854775807);  slice_tensor_68 = None
        sub_tensor_17 = torch.ops.aten.sub.Tensor(slice_tensor_65, slice_tensor_69);  slice_tensor_65 = slice_tensor_69 = None
        abs_default_5 = torch.ops.aten.abs.default(sub_tensor_17)
        mean_default_5 = torch.ops.aten.mean.default(abs_default_5);  abs_default_5 = None
        slice_tensor_70 = torch.ops.aten.slice.Tensor(slice_tensor_7, 0, 0, 9223372036854775807)
        slice_tensor_71 = torch.ops.aten.slice.Tensor(slice_tensor_70, 1, 0, 9223372036854775807);  slice_tensor_70 = None
        slice_tensor_72 = torch.ops.aten.slice.Tensor(slice_tensor_71, 2, 0, -1);  slice_tensor_71 = None
        slice_tensor_73 = torch.ops.aten.slice.Tensor(slice_tensor_72, 3, 0, 9223372036854775807);  slice_tensor_72 = None
        slice_tensor_74 = torch.ops.aten.slice.Tensor(slice_tensor_7, 0, 0, 9223372036854775807);  slice_tensor_7 = None
        slice_tensor_75 = torch.ops.aten.slice.Tensor(slice_tensor_74, 1, 0, 9223372036854775807);  slice_tensor_74 = None
        slice_tensor_76 = torch.ops.aten.slice.Tensor(slice_tensor_75, 2, 1, 9223372036854775807);  slice_tensor_75 = None
        slice_tensor_77 = torch.ops.aten.slice.Tensor(slice_tensor_76, 3, 0, 9223372036854775807);  slice_tensor_76 = None
        sub_tensor_18 = torch.ops.aten.sub.Tensor(slice_tensor_73, slice_tensor_77);  slice_tensor_73 = slice_tensor_77 = None
        abs_default_6 = torch.ops.aten.abs.default(sub_tensor_18)
        mean_default_6 = torch.ops.aten.mean.default(abs_default_6);  abs_default_6 = None
        add_tensor_21 = torch.ops.aten.add.Tensor(mean_default_5, mean_default_6);  mean_default_5 = mean_default_6 = None
        slice_tensor_78 = torch.ops.aten.slice.Tensor(slice_tensor_3, 0, 0, 9223372036854775807)
        slice_tensor_79 = torch.ops.aten.slice.Tensor(slice_tensor_78, 1, 0, 9223372036854775807);  slice_tensor_78 = None
        slice_tensor_80 = torch.ops.aten.slice.Tensor(slice_tensor_79, 2, 0, 9223372036854775807);  slice_tensor_79 = None
        slice_tensor_81 = torch.ops.aten.slice.Tensor(slice_tensor_80, 3, 0, -1);  slice_tensor_80 = None
        slice_tensor_82 = torch.ops.aten.slice.Tensor(slice_tensor_3, 0, 0, 9223372036854775807)
        slice_tensor_83 = torch.ops.aten.slice.Tensor(slice_tensor_82, 1, 0, 9223372036854775807);  slice_tensor_82 = None
        slice_tensor_84 = torch.ops.aten.slice.Tensor(slice_tensor_83, 2, 0, 9223372036854775807);  slice_tensor_83 = None
        slice_tensor_85 = torch.ops.aten.slice.Tensor(slice_tensor_84, 3, 1, 9223372036854775807);  slice_tensor_84 = None
        sub_tensor_19 = torch.ops.aten.sub.Tensor(slice_tensor_81, slice_tensor_85);  slice_tensor_81 = slice_tensor_85 = None
        abs_default_7 = torch.ops.aten.abs.default(sub_tensor_19)
        mean_default_7 = torch.ops.aten.mean.default(abs_default_7);  abs_default_7 = None
        slice_tensor_86 = torch.ops.aten.slice.Tensor(slice_tensor_3, 0, 0, 9223372036854775807)
        slice_tensor_87 = torch.ops.aten.slice.Tensor(slice_tensor_86, 1, 0, 9223372036854775807);  slice_tensor_86 = None
        slice_tensor_88 = torch.ops.aten.slice.Tensor(slice_tensor_87, 2, 0, -1);  slice_tensor_87 = None
        slice_tensor_89 = torch.ops.aten.slice.Tensor(slice_tensor_88, 3, 0, 9223372036854775807);  slice_tensor_88 = None
        slice_tensor_90 = torch.ops.aten.slice.Tensor(slice_tensor_3, 0, 0, 9223372036854775807);  slice_tensor_3 = None
        slice_tensor_91 = torch.ops.aten.slice.Tensor(slice_tensor_90, 1, 0, 9223372036854775807);  slice_tensor_90 = None
        slice_tensor_92 = torch.ops.aten.slice.Tensor(slice_tensor_91, 2, 1, 9223372036854775807);  slice_tensor_91 = None
        slice_tensor_93 = torch.ops.aten.slice.Tensor(slice_tensor_92, 3, 0, 9223372036854775807);  slice_tensor_92 = None
        sub_tensor_20 = torch.ops.aten.sub.Tensor(slice_tensor_89, slice_tensor_93);  slice_tensor_89 = slice_tensor_93 = None
        abs_default_8 = torch.ops.aten.abs.default(sub_tensor_20)
        mean_default_8 = torch.ops.aten.mean.default(abs_default_8);  abs_default_8 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(mean_default_7, mean_default_8);  mean_default_7 = mean_default_8 = None
        add_tensor_23 = torch.ops.aten.add.Tensor(add_tensor_21, add_tensor_22);  add_tensor_21 = add_tensor_22 = None
        mul_tensor_71 = torch.ops.aten.mul.Tensor(mean_default, 204);  mean_default = None
        mul_tensor_72 = torch.ops.aten.mul.Tensor(add_tensor_20, 102);  add_tensor_20 = None
        add_tensor_24 = torch.ops.aten.add.Tensor(mul_tensor_71, mul_tensor_72);  mul_tensor_71 = mul_tensor_72 = None
        mul_tensor_73 = torch.ops.aten.mul.Tensor(mse_loss_default, 0.005);  mse_loss_default = None
        add_tensor_25 = torch.ops.aten.add.Tensor(add_tensor_24, mul_tensor_73);  add_tensor_24 = mul_tensor_73 = None
        add_tensor_26 = torch.ops.aten.add.Tensor(add_tensor_25, add_tensor_23);  add_tensor_25 = add_tensor_23 = None
        return [div_tensor_8, add_tensor_26, primals_110, primals_92, convolution_default_41, primals_90, convolution_default_40, primals_76, avg_pool2d_default_9, primals_80, convolution_default_45, primals_16, primals_116, where_self_30, primals_117, where_self_44, convolution_default_31, upsample_bilinear2d_vec_8, primals_108, convolution_default_42, primals_82, sub_tensor_10, primals_12, convolution_default_32, where_self_31, primals_98, convolution_default_43, primals_86, primals_112, primals_74, convolution_default_33, primals_30, primals_20, primals_96, primals_106, cat_default_10, primals_104, where_self_32, upsample_bilinear2d_vec_9, primals_114, convolution_default_35, permute_default, convolution_default_44, primals_102, sigmoid_default, primals_100, primals_18, convolution_default_34, permute_default_1, primals_84, cat_default_11, permute_default_3, primals_78, primals_88, where_self_33, permute_default_2, primals_72, primals_14, sub_tensor_18, primals_68, stack_default_5, sub_tensor_20, sub_tensor_13, sub_tensor_17, primals_66, primals_62, primals_70, sub_tensor_16, primals_64, sub_tensor_19, convolution_default, relu__default_1, getitem_1, getitem, relu__default_2, relu__default_3, getitem_3, convolution_default_65, getitem_2, relu__default_4, relu__default_5, primals_38, primals_44, where_self_4, relu__default_6, convolution_default_6, primals_40, where_self_5, getitem_5, primals_2, getitem_4, primals_26, avg_pool2d_default_2, convolution_default_7, where_self_6, relu__default_7, primals_32, convolution_default_55, primals_34, convolution_default_8, avg_pool2d_default_3, relu__default_8, primals_46, where_self_7, primals_36, where_self_8, primals_42, convolution_default_9, avg_pool2d_default_4, convolution_default_12, primals_24, where_self_9, convolution_default_1, mul_tensor_63, where_self, convolution_default_10, convolution_default_2, permute_default_4, div_tensor_8, sub_tensor_9, convolution_default_11, avg_pool2d_default, mul_tensor_61, where_self_10, permute_default_5, where_self_1, upsample_bilinear2d_vec, stack_default_4, add_tensor_12, convolution_default_13, sub_tensor_8, where_self_2, avg_pool2d_default_1, primals_22, convolution_default_14, convolution_default_3, convolution_default_4, where_self_3, relu__default, cat_default, convolution_default_5, cat_default_1, upsample_bilinear2d_vec_5, stack_default, convolution_default_37, convolution_default_38, cat_default_7, upsample_bilinear2d_vec_6, convolution_default_36, cat_default_8, convolution_default_39, upsample_bilinear2d_vec_7, cat_default_9, primals_56, convolution_default_20, convolution_default_19, avg_pool2d_default_7, where_self_25, convolution_default_27, primals_52, upsample_bilinear2d_vec_4, primals_50, convolution_default_21, where_self_26, avg_pool2d_default_6, convolution_default_28, where_self_27, primals_60, cat_default_5, convolution_default_29, primals_54, convolution_default_22, where_self_28, primals_48, where_self_21, primals_58, where_self_29, avg_pool2d_default_8, convolution_default_30, stack_default_3, upsample_bilinear2d_vec_1, convolution_default_16, primals_28, convolution_default_17, cat_default_2, stack_default_2, stack_default_1, upsample_bilinear2d_vec_2, primals_10, primals_4, convolution_default_15, convolution_default_23, grid_sampler_2d_default_2, grid_sampler_2d_default_3, cat_default_6, add_tensor_13, where_self_23, avg_pool2d_default_5, primals_8, cat_default_3, convolution_default_18, primals_6, upsample_bilinear2d_vec_3, convolution_default_24, convolution_default_25, cat_default_4, where_self_24, convolution_default_26]
        
