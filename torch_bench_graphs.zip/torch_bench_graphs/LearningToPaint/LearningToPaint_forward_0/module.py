
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/LearningToPaint/LearningToPaint_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129):
        convolution_default = torch.ops.aten.convolution.default(primals_129, primals_6, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_5, primals_1, primals_3, primals_4, False, 0.1, 1e-05);  primals_1 = None
        getitem = native_batch_norm_default[0];  native_batch_norm_default = None
        relu_default = torch.ops.aten.relu.default(getitem);  getitem = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu_default, primals_19, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_13, primals_9, primals_11, primals_12, False, 0.1, 1e-05);  primals_9 = None
        getitem_3 = native_batch_norm_default_1[0];  native_batch_norm_default_1 = None
        relu_default_1 = torch.ops.aten.relu.default(getitem_3);  getitem_3 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu_default_1, primals_20, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_18, primals_14, primals_16, primals_17, False, 0.1, 1e-05);  primals_14 = None
        getitem_6 = native_batch_norm_default_2[0];  native_batch_norm_default_2 = None
        convolution_default_3 = torch.ops.aten.convolution.default(relu_default, primals_21, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_26, primals_22, primals_24, primals_25, False, 0.1, 1e-05);  primals_22 = None
        getitem_9 = native_batch_norm_default_3[0];  native_batch_norm_default_3 = None
        add__tensor = torch.ops.aten.add_.Tensor(getitem_6, getitem_9);  getitem_6 = getitem_9 = None
        relu_default_2 = torch.ops.aten.relu.default(add__tensor);  add__tensor = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu_default_2, primals_37, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_31, primals_27, primals_29, primals_30, False, 0.1, 1e-05);  primals_27 = None
        getitem_12 = native_batch_norm_default_4[0];  native_batch_norm_default_4 = None
        relu_default_3 = torch.ops.aten.relu.default(getitem_12);  getitem_12 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu_default_3, primals_38, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_36, primals_32, primals_34, primals_35, False, 0.1, 1e-05);  primals_32 = None
        getitem_15 = native_batch_norm_default_5[0];  native_batch_norm_default_5 = None
        add__tensor_1 = torch.ops.aten.add_.Tensor(getitem_15, relu_default_2);  getitem_15 = None
        relu_default_4 = torch.ops.aten.relu.default(add__tensor_1);  add__tensor_1 = None
        convolution_default_6 = torch.ops.aten.convolution.default(relu_default_4, primals_49, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_43, primals_39, primals_41, primals_42, False, 0.1, 1e-05);  primals_39 = None
        getitem_18 = native_batch_norm_default_6[0];  native_batch_norm_default_6 = None
        relu_default_5 = torch.ops.aten.relu.default(getitem_18);  getitem_18 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu_default_5, primals_50, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_48, primals_44, primals_46, primals_47, False, 0.1, 1e-05);  primals_44 = None
        getitem_21 = native_batch_norm_default_7[0];  native_batch_norm_default_7 = None
        convolution_default_8 = torch.ops.aten.convolution.default(relu_default_4, primals_51, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_56, primals_52, primals_54, primals_55, False, 0.1, 1e-05);  primals_52 = None
        getitem_24 = native_batch_norm_default_8[0];  native_batch_norm_default_8 = None
        add__tensor_2 = torch.ops.aten.add_.Tensor(getitem_21, getitem_24);  getitem_21 = getitem_24 = None
        relu_default_6 = torch.ops.aten.relu.default(add__tensor_2);  add__tensor_2 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu_default_6, primals_67, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_61, primals_57, primals_59, primals_60, False, 0.1, 1e-05);  primals_57 = None
        getitem_27 = native_batch_norm_default_9[0];  native_batch_norm_default_9 = None
        relu_default_7 = torch.ops.aten.relu.default(getitem_27);  getitem_27 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu_default_7, primals_68, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_66, primals_62, primals_64, primals_65, False, 0.1, 1e-05);  primals_62 = None
        getitem_30 = native_batch_norm_default_10[0];  native_batch_norm_default_10 = None
        add__tensor_3 = torch.ops.aten.add_.Tensor(getitem_30, relu_default_6);  getitem_30 = None
        relu_default_8 = torch.ops.aten.relu.default(add__tensor_3);  add__tensor_3 = None
        convolution_default_11 = torch.ops.aten.convolution.default(relu_default_8, primals_79, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_73, primals_69, primals_71, primals_72, False, 0.1, 1e-05);  primals_69 = None
        getitem_33 = native_batch_norm_default_11[0];  native_batch_norm_default_11 = None
        relu_default_9 = torch.ops.aten.relu.default(getitem_33);  getitem_33 = None
        convolution_default_12 = torch.ops.aten.convolution.default(relu_default_9, primals_80, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_78, primals_74, primals_76, primals_77, False, 0.1, 1e-05);  primals_74 = None
        getitem_36 = native_batch_norm_default_12[0];  native_batch_norm_default_12 = None
        convolution_default_13 = torch.ops.aten.convolution.default(relu_default_8, primals_81, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_86, primals_82, primals_84, primals_85, False, 0.1, 1e-05);  primals_82 = None
        getitem_39 = native_batch_norm_default_13[0];  native_batch_norm_default_13 = None
        add__tensor_4 = torch.ops.aten.add_.Tensor(getitem_36, getitem_39);  getitem_36 = getitem_39 = None
        relu_default_10 = torch.ops.aten.relu.default(add__tensor_4);  add__tensor_4 = None
        convolution_default_14 = torch.ops.aten.convolution.default(relu_default_10, primals_97, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_91, primals_87, primals_89, primals_90, False, 0.1, 1e-05);  primals_87 = None
        getitem_42 = native_batch_norm_default_14[0];  native_batch_norm_default_14 = None
        relu_default_11 = torch.ops.aten.relu.default(getitem_42);  getitem_42 = None
        convolution_default_15 = torch.ops.aten.convolution.default(relu_default_11, primals_98, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_96, primals_92, primals_94, primals_95, False, 0.1, 1e-05);  primals_92 = None
        getitem_45 = native_batch_norm_default_15[0];  native_batch_norm_default_15 = None
        add__tensor_5 = torch.ops.aten.add_.Tensor(getitem_45, relu_default_10);  getitem_45 = None
        relu_default_12 = torch.ops.aten.relu.default(add__tensor_5);  add__tensor_5 = None
        convolution_default_16 = torch.ops.aten.convolution.default(relu_default_12, primals_109, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_103, primals_99, primals_101, primals_102, False, 0.1, 1e-05);  primals_99 = None
        getitem_48 = native_batch_norm_default_16[0];  native_batch_norm_default_16 = None
        relu_default_13 = torch.ops.aten.relu.default(getitem_48);  getitem_48 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu_default_13, primals_110, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_108, primals_104, primals_106, primals_107, False, 0.1, 1e-05);  primals_104 = None
        getitem_51 = native_batch_norm_default_17[0];  native_batch_norm_default_17 = None
        convolution_default_18 = torch.ops.aten.convolution.default(relu_default_12, primals_111, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_116, primals_112, primals_114, primals_115, False, 0.1, 1e-05);  primals_112 = None
        getitem_54 = native_batch_norm_default_18[0];  native_batch_norm_default_18 = None
        add__tensor_6 = torch.ops.aten.add_.Tensor(getitem_51, getitem_54);  getitem_51 = getitem_54 = None
        relu_default_14 = torch.ops.aten.relu.default(add__tensor_6);  add__tensor_6 = None
        convolution_default_19 = torch.ops.aten.convolution.default(relu_default_14, primals_127, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_121, primals_117, primals_119, primals_120, False, 0.1, 1e-05);  primals_117 = None
        getitem_57 = native_batch_norm_default_19[0];  native_batch_norm_default_19 = None
        relu_default_15 = torch.ops.aten.relu.default(getitem_57);  getitem_57 = None
        convolution_default_20 = torch.ops.aten.convolution.default(relu_default_15, primals_128, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_126, primals_122, primals_124, primals_125, False, 0.1, 1e-05);  primals_122 = None
        getitem_60 = native_batch_norm_default_20[0];  native_batch_norm_default_20 = None
        add__tensor_7 = torch.ops.aten.add_.Tensor(getitem_60, relu_default_14);  getitem_60 = None
        relu_default_16 = torch.ops.aten.relu.default(add__tensor_7);  add__tensor_7 = None
        avg_pool2d_default = torch.ops.aten.avg_pool2d.default(relu_default_16, [4, 4])
        view_default = torch.ops.aten.view.default(avg_pool2d_default, [96, -1]);  avg_pool2d_default = None
        t_default = torch.ops.aten.t.default(primals_8);  primals_8 = None
        addmm_default = torch.ops.aten.addmm.default(primals_7, view_default, t_default);  primals_7 = None
        sigmoid_default = torch.ops.aten.sigmoid.default(addmm_default);  addmm_default = None
        return [sigmoid_default, primals_60, primals_81, primals_102, convolution_default_13, relu_default_11, primals_61, primals_103, convolution_default_18, relu_default_1, primals_84, convolution_default_2, primals_64, primals_85, primals_106, primals_65, primals_86, primals_107, primals_66, primals_108, primals_67, primals_109, primals_68, primals_89, primals_110, convolution_default_3, convolution_default_16, primals_90, primals_111, relu_default_2, primals_91, primals_71, primals_72, primals_114, relu_default, relu_default_14, primals_73, primals_94, primals_115, convolution_default_15, primals_95, primals_116, relu_default_10, relu_default_12, convolution_default_19, primals_96, convolution_default_14, primals_76, primals_97, primals_77, primals_98, primals_119, convolution_default_17, primals_78, primals_120, convolution_default_1, convolution_default_4, relu_default_13, primals_79, primals_121, relu_default_15, primals_80, primals_101, convolution_default_20, primals_18, relu_default_7, convolution_default_8, primals_19, primals_124, primals_4, relu_default_3, primals_20, primals_41, primals_125, primals_5, primals_21, primals_42, primals_126, convolution_default_10, view_default, primals_43, primals_127, primals_128, primals_3, convolution_default_5, primals_24, primals_129, primals_25, primals_46, primals_26, primals_47, primals_48, primals_11, convolution_default, primals_49, primals_13, convolution_default_11, primals_29, primals_50, convolution_default_6, primals_30, primals_51, convolution_default_7, t_default, primals_6, relu_default_16, primals_31, primals_12, primals_54, relu_default_9, relu_default_6, relu_default_8, primals_34, primals_55, primals_35, primals_56, convolution_default_9, relu_default_4, sigmoid_default, primals_36, primals_37, primals_16, convolution_default_12, primals_38, primals_59, primals_17, relu_default_5]
        
