
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/hf_Bert/hf_Bert_forward_1/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194):
        view_default = torch.ops.aten.view.default(primals_193, [2048, 768])
        t_default = torch.ops.aten.t.default(primals_8);  primals_8 = None
        addmm_default = torch.ops.aten.addmm.default(primals_7, view_default, t_default);  primals_7 = None
        view_default_1 = torch.ops.aten.view.default(addmm_default, [4, 512, 768]);  addmm_default = None
        view_default_2 = torch.ops.aten.view.default(primals_193, [2048, 768])
        t_default_1 = torch.ops.aten.t.default(primals_6);  primals_6 = None
        addmm_default_1 = torch.ops.aten.addmm.default(primals_5, view_default_2, t_default_1);  primals_5 = None
        view_default_3 = torch.ops.aten.view.default(addmm_default_1, [4, 512, 768]);  addmm_default_1 = None
        view_default_4 = torch.ops.aten.view.default(view_default_3, [4, 512, 12, 64]);  view_default_3 = None
        permute_default = torch.ops.aten.permute.default(view_default_4, [0, 2, 1, 3]);  view_default_4 = None
        view_default_5 = torch.ops.aten.view.default(primals_193, [2048, 768])
        t_default_2 = torch.ops.aten.t.default(primals_10);  primals_10 = None
        addmm_default_2 = torch.ops.aten.addmm.default(primals_9, view_default_5, t_default_2);  primals_9 = None
        view_default_6 = torch.ops.aten.view.default(addmm_default_2, [4, 512, 768]);  addmm_default_2 = None
        view_default_7 = torch.ops.aten.view.default(view_default_6, [4, 512, 12, 64]);  view_default_6 = None
        permute_default_1 = torch.ops.aten.permute.default(view_default_7, [0, 2, 1, 3]);  view_default_7 = None
        view_default_8 = torch.ops.aten.view.default(view_default_1, [4, 512, 12, 64]);  view_default_1 = None
        permute_default_2 = torch.ops.aten.permute.default(view_default_8, [0, 2, 1, 3]);  view_default_8 = None
        transpose_int = torch.ops.aten.transpose.int(permute_default, -1, -2);  permute_default = None
        expand_default = torch.ops.aten.expand.default(permute_default_2, [4, 12, 512, 64]);  permute_default_2 = None
        clone_default = torch.ops.aten.clone.default(expand_default, memory_format = torch.contiguous_format);  expand_default = None
        _unsafe_view_default = torch.ops.aten._unsafe_view.default(clone_default, [48, 512, 64]);  clone_default = None
        expand_default_1 = torch.ops.aten.expand.default(transpose_int, [4, 12, 64, 512]);  transpose_int = None
        clone_default_1 = torch.ops.aten.clone.default(expand_default_1, memory_format = torch.contiguous_format);  expand_default_1 = None
        _unsafe_view_default_1 = torch.ops.aten._unsafe_view.default(clone_default_1, [48, 64, 512]);  clone_default_1 = None
        bmm_default = torch.ops.aten.bmm.default(_unsafe_view_default, _unsafe_view_default_1)
        _unsafe_view_default_2 = torch.ops.aten._unsafe_view.default(bmm_default, [4, 12, 512, 512]);  bmm_default = None
        div_tensor = torch.ops.aten.div.Tensor(_unsafe_view_default_2, 8.0);  _unsafe_view_default_2 = None
        add_tensor = torch.ops.aten.add.Tensor(div_tensor, primals_194);  div_tensor = None
        _softmax_default = torch.ops.aten._softmax.default(add_tensor, -1, False);  add_tensor = None
        expand_default_2 = torch.ops.aten.expand.default(_softmax_default, [4, 12, 512, 512])
        view_default_9 = torch.ops.aten.view.default(expand_default_2, [48, 512, 512]);  expand_default_2 = None
        expand_default_3 = torch.ops.aten.expand.default(permute_default_1, [4, 12, 512, 64]);  permute_default_1 = None
        clone_default_2 = torch.ops.aten.clone.default(expand_default_3, memory_format = torch.contiguous_format);  expand_default_3 = None
        _unsafe_view_default_3 = torch.ops.aten._unsafe_view.default(clone_default_2, [48, 512, 64]);  clone_default_2 = None
        bmm_default_1 = torch.ops.aten.bmm.default(view_default_9, _unsafe_view_default_3)
        _unsafe_view_default_4 = torch.ops.aten._unsafe_view.default(bmm_default_1, [4, 12, 512, 64]);  bmm_default_1 = None
        permute_default_3 = torch.ops.aten.permute.default(_unsafe_view_default_4, [0, 2, 1, 3]);  _unsafe_view_default_4 = None
        clone_default_3 = torch.ops.aten.clone.default(permute_default_3, memory_format = torch.contiguous_format);  permute_default_3 = None
        view_default_10 = torch.ops.aten.view.default(clone_default_3, [4, 512, 768]);  clone_default_3 = None
        view_default_11 = torch.ops.aten.view.default(view_default_10, [2048, 768]);  view_default_10 = None
        t_default_3 = torch.ops.aten.t.default(primals_4);  primals_4 = None
        addmm_default_3 = torch.ops.aten.addmm.default(primals_3, view_default_11, t_default_3);  primals_3 = None
        view_default_12 = torch.ops.aten.view.default(addmm_default_3, [4, 512, 768]);  addmm_default_3 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(view_default_12, primals_193);  view_default_12 = primals_193 = None
        native_layer_norm_default = torch.ops.aten.native_layer_norm.default(add_tensor_1, [768], primals_2, primals_1, 1e-12)
        getitem = native_layer_norm_default[0]
        getitem_1 = native_layer_norm_default[1]
        getitem_2 = native_layer_norm_default[2];  native_layer_norm_default = None
        view_default_13 = torch.ops.aten.view.default(getitem, [2048, 768])
        t_default_4 = torch.ops.aten.t.default(primals_12);  primals_12 = None
        addmm_default_4 = torch.ops.aten.addmm.default(primals_11, view_default_13, t_default_4);  primals_11 = None
        view_default_14 = torch.ops.aten.view.default(addmm_default_4, [4, 512, 3072]);  addmm_default_4 = None
        gelu_default = torch.ops.aten.gelu.default(view_default_14)
        view_default_15 = torch.ops.aten.view.default(gelu_default, [2048, 3072]);  gelu_default = None
        t_default_5 = torch.ops.aten.t.default(primals_16);  primals_16 = None
        addmm_default_5 = torch.ops.aten.addmm.default(primals_15, view_default_15, t_default_5);  primals_15 = None
        view_default_16 = torch.ops.aten.view.default(addmm_default_5, [4, 512, 768]);  addmm_default_5 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(view_default_16, getitem);  view_default_16 = getitem = None
        native_layer_norm_default_1 = torch.ops.aten.native_layer_norm.default(add_tensor_2, [768], primals_14, primals_13, 1e-12)
        getitem_3 = native_layer_norm_default_1[0]
        getitem_4 = native_layer_norm_default_1[1]
        getitem_5 = native_layer_norm_default_1[2];  native_layer_norm_default_1 = None
        view_default_17 = torch.ops.aten.view.default(getitem_3, [2048, 768])
        t_default_6 = torch.ops.aten.t.default(primals_56);  primals_56 = None
        addmm_default_6 = torch.ops.aten.addmm.default(primals_55, view_default_17, t_default_6);  primals_55 = None
        view_default_18 = torch.ops.aten.view.default(addmm_default_6, [4, 512, 768]);  addmm_default_6 = None
        view_default_19 = torch.ops.aten.view.default(getitem_3, [2048, 768])
        t_default_7 = torch.ops.aten.t.default(primals_54);  primals_54 = None
        addmm_default_7 = torch.ops.aten.addmm.default(primals_53, view_default_19, t_default_7);  primals_53 = None
        view_default_20 = torch.ops.aten.view.default(addmm_default_7, [4, 512, 768]);  addmm_default_7 = None
        view_default_21 = torch.ops.aten.view.default(view_default_20, [4, 512, 12, 64]);  view_default_20 = None
        permute_default_4 = torch.ops.aten.permute.default(view_default_21, [0, 2, 1, 3]);  view_default_21 = None
        view_default_22 = torch.ops.aten.view.default(getitem_3, [2048, 768])
        t_default_8 = torch.ops.aten.t.default(primals_58);  primals_58 = None
        addmm_default_8 = torch.ops.aten.addmm.default(primals_57, view_default_22, t_default_8);  primals_57 = None
        view_default_23 = torch.ops.aten.view.default(addmm_default_8, [4, 512, 768]);  addmm_default_8 = None
        view_default_24 = torch.ops.aten.view.default(view_default_23, [4, 512, 12, 64]);  view_default_23 = None
        permute_default_5 = torch.ops.aten.permute.default(view_default_24, [0, 2, 1, 3]);  view_default_24 = None
        view_default_25 = torch.ops.aten.view.default(view_default_18, [4, 512, 12, 64]);  view_default_18 = None
        permute_default_6 = torch.ops.aten.permute.default(view_default_25, [0, 2, 1, 3]);  view_default_25 = None
        transpose_int_1 = torch.ops.aten.transpose.int(permute_default_4, -1, -2);  permute_default_4 = None
        expand_default_4 = torch.ops.aten.expand.default(permute_default_6, [4, 12, 512, 64]);  permute_default_6 = None
        clone_default_4 = torch.ops.aten.clone.default(expand_default_4, memory_format = torch.contiguous_format);  expand_default_4 = None
        _unsafe_view_default_5 = torch.ops.aten._unsafe_view.default(clone_default_4, [48, 512, 64]);  clone_default_4 = None
        expand_default_5 = torch.ops.aten.expand.default(transpose_int_1, [4, 12, 64, 512]);  transpose_int_1 = None
        clone_default_5 = torch.ops.aten.clone.default(expand_default_5, memory_format = torch.contiguous_format);  expand_default_5 = None
        _unsafe_view_default_6 = torch.ops.aten._unsafe_view.default(clone_default_5, [48, 64, 512]);  clone_default_5 = None
        bmm_default_2 = torch.ops.aten.bmm.default(_unsafe_view_default_5, _unsafe_view_default_6)
        _unsafe_view_default_7 = torch.ops.aten._unsafe_view.default(bmm_default_2, [4, 12, 512, 512]);  bmm_default_2 = None
        div_tensor_1 = torch.ops.aten.div.Tensor(_unsafe_view_default_7, 8.0);  _unsafe_view_default_7 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(div_tensor_1, primals_194);  div_tensor_1 = None
        _softmax_default_1 = torch.ops.aten._softmax.default(add_tensor_3, -1, False);  add_tensor_3 = None
        expand_default_6 = torch.ops.aten.expand.default(_softmax_default_1, [4, 12, 512, 512])
        view_default_26 = torch.ops.aten.view.default(expand_default_6, [48, 512, 512]);  expand_default_6 = None
        expand_default_7 = torch.ops.aten.expand.default(permute_default_5, [4, 12, 512, 64]);  permute_default_5 = None
        clone_default_6 = torch.ops.aten.clone.default(expand_default_7, memory_format = torch.contiguous_format);  expand_default_7 = None
        _unsafe_view_default_8 = torch.ops.aten._unsafe_view.default(clone_default_6, [48, 512, 64]);  clone_default_6 = None
        bmm_default_3 = torch.ops.aten.bmm.default(view_default_26, _unsafe_view_default_8)
        _unsafe_view_default_9 = torch.ops.aten._unsafe_view.default(bmm_default_3, [4, 12, 512, 64]);  bmm_default_3 = None
        permute_default_7 = torch.ops.aten.permute.default(_unsafe_view_default_9, [0, 2, 1, 3]);  _unsafe_view_default_9 = None
        clone_default_7 = torch.ops.aten.clone.default(permute_default_7, memory_format = torch.contiguous_format);  permute_default_7 = None
        view_default_27 = torch.ops.aten.view.default(clone_default_7, [4, 512, 768]);  clone_default_7 = None
        view_default_28 = torch.ops.aten.view.default(view_default_27, [2048, 768]);  view_default_27 = None
        t_default_9 = torch.ops.aten.t.default(primals_52);  primals_52 = None
        addmm_default_9 = torch.ops.aten.addmm.default(primals_51, view_default_28, t_default_9);  primals_51 = None
        view_default_29 = torch.ops.aten.view.default(addmm_default_9, [4, 512, 768]);  addmm_default_9 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(view_default_29, getitem_3);  view_default_29 = getitem_3 = None
        native_layer_norm_default_2 = torch.ops.aten.native_layer_norm.default(add_tensor_4, [768], primals_50, primals_49, 1e-12)
        getitem_6 = native_layer_norm_default_2[0]
        getitem_7 = native_layer_norm_default_2[1]
        getitem_8 = native_layer_norm_default_2[2];  native_layer_norm_default_2 = None
        view_default_30 = torch.ops.aten.view.default(getitem_6, [2048, 768])
        t_default_10 = torch.ops.aten.t.default(primals_60);  primals_60 = None
        addmm_default_10 = torch.ops.aten.addmm.default(primals_59, view_default_30, t_default_10);  primals_59 = None
        view_default_31 = torch.ops.aten.view.default(addmm_default_10, [4, 512, 3072]);  addmm_default_10 = None
        gelu_default_1 = torch.ops.aten.gelu.default(view_default_31)
        view_default_32 = torch.ops.aten.view.default(gelu_default_1, [2048, 3072]);  gelu_default_1 = None
        t_default_11 = torch.ops.aten.t.default(primals_64);  primals_64 = None
        addmm_default_11 = torch.ops.aten.addmm.default(primals_63, view_default_32, t_default_11);  primals_63 = None
        view_default_33 = torch.ops.aten.view.default(addmm_default_11, [4, 512, 768]);  addmm_default_11 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(view_default_33, getitem_6);  view_default_33 = getitem_6 = None
        native_layer_norm_default_3 = torch.ops.aten.native_layer_norm.default(add_tensor_5, [768], primals_62, primals_61, 1e-12)
        getitem_9 = native_layer_norm_default_3[0]
        getitem_10 = native_layer_norm_default_3[1]
        getitem_11 = native_layer_norm_default_3[2];  native_layer_norm_default_3 = None
        view_default_34 = torch.ops.aten.view.default(getitem_9, [2048, 768])
        t_default_12 = torch.ops.aten.t.default(primals_72);  primals_72 = None
        addmm_default_12 = torch.ops.aten.addmm.default(primals_71, view_default_34, t_default_12);  primals_71 = None
        view_default_35 = torch.ops.aten.view.default(addmm_default_12, [4, 512, 768]);  addmm_default_12 = None
        view_default_36 = torch.ops.aten.view.default(getitem_9, [2048, 768])
        t_default_13 = torch.ops.aten.t.default(primals_70);  primals_70 = None
        addmm_default_13 = torch.ops.aten.addmm.default(primals_69, view_default_36, t_default_13);  primals_69 = None
        view_default_37 = torch.ops.aten.view.default(addmm_default_13, [4, 512, 768]);  addmm_default_13 = None
        view_default_38 = torch.ops.aten.view.default(view_default_37, [4, 512, 12, 64]);  view_default_37 = None
        permute_default_8 = torch.ops.aten.permute.default(view_default_38, [0, 2, 1, 3]);  view_default_38 = None
        view_default_39 = torch.ops.aten.view.default(getitem_9, [2048, 768])
        t_default_14 = torch.ops.aten.t.default(primals_74);  primals_74 = None
        addmm_default_14 = torch.ops.aten.addmm.default(primals_73, view_default_39, t_default_14);  primals_73 = None
        view_default_40 = torch.ops.aten.view.default(addmm_default_14, [4, 512, 768]);  addmm_default_14 = None
        view_default_41 = torch.ops.aten.view.default(view_default_40, [4, 512, 12, 64]);  view_default_40 = None
        permute_default_9 = torch.ops.aten.permute.default(view_default_41, [0, 2, 1, 3]);  view_default_41 = None
        view_default_42 = torch.ops.aten.view.default(view_default_35, [4, 512, 12, 64]);  view_default_35 = None
        permute_default_10 = torch.ops.aten.permute.default(view_default_42, [0, 2, 1, 3]);  view_default_42 = None
        transpose_int_2 = torch.ops.aten.transpose.int(permute_default_8, -1, -2);  permute_default_8 = None
        expand_default_8 = torch.ops.aten.expand.default(permute_default_10, [4, 12, 512, 64]);  permute_default_10 = None
        clone_default_8 = torch.ops.aten.clone.default(expand_default_8, memory_format = torch.contiguous_format);  expand_default_8 = None
        _unsafe_view_default_10 = torch.ops.aten._unsafe_view.default(clone_default_8, [48, 512, 64]);  clone_default_8 = None
        expand_default_9 = torch.ops.aten.expand.default(transpose_int_2, [4, 12, 64, 512]);  transpose_int_2 = None
        clone_default_9 = torch.ops.aten.clone.default(expand_default_9, memory_format = torch.contiguous_format);  expand_default_9 = None
        _unsafe_view_default_11 = torch.ops.aten._unsafe_view.default(clone_default_9, [48, 64, 512]);  clone_default_9 = None
        bmm_default_4 = torch.ops.aten.bmm.default(_unsafe_view_default_10, _unsafe_view_default_11)
        _unsafe_view_default_12 = torch.ops.aten._unsafe_view.default(bmm_default_4, [4, 12, 512, 512]);  bmm_default_4 = None
        div_tensor_2 = torch.ops.aten.div.Tensor(_unsafe_view_default_12, 8.0);  _unsafe_view_default_12 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(div_tensor_2, primals_194);  div_tensor_2 = None
        _softmax_default_2 = torch.ops.aten._softmax.default(add_tensor_6, -1, False);  add_tensor_6 = None
        expand_default_10 = torch.ops.aten.expand.default(_softmax_default_2, [4, 12, 512, 512])
        view_default_43 = torch.ops.aten.view.default(expand_default_10, [48, 512, 512]);  expand_default_10 = None
        expand_default_11 = torch.ops.aten.expand.default(permute_default_9, [4, 12, 512, 64]);  permute_default_9 = None
        clone_default_10 = torch.ops.aten.clone.default(expand_default_11, memory_format = torch.contiguous_format);  expand_default_11 = None
        _unsafe_view_default_13 = torch.ops.aten._unsafe_view.default(clone_default_10, [48, 512, 64]);  clone_default_10 = None
        bmm_default_5 = torch.ops.aten.bmm.default(view_default_43, _unsafe_view_default_13)
        _unsafe_view_default_14 = torch.ops.aten._unsafe_view.default(bmm_default_5, [4, 12, 512, 64]);  bmm_default_5 = None
        permute_default_11 = torch.ops.aten.permute.default(_unsafe_view_default_14, [0, 2, 1, 3]);  _unsafe_view_default_14 = None
        clone_default_11 = torch.ops.aten.clone.default(permute_default_11, memory_format = torch.contiguous_format);  permute_default_11 = None
        view_default_44 = torch.ops.aten.view.default(clone_default_11, [4, 512, 768]);  clone_default_11 = None
        view_default_45 = torch.ops.aten.view.default(view_default_44, [2048, 768]);  view_default_44 = None
        t_default_15 = torch.ops.aten.t.default(primals_68);  primals_68 = None
        addmm_default_15 = torch.ops.aten.addmm.default(primals_67, view_default_45, t_default_15);  primals_67 = None
        view_default_46 = torch.ops.aten.view.default(addmm_default_15, [4, 512, 768]);  addmm_default_15 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(view_default_46, getitem_9);  view_default_46 = getitem_9 = None
        native_layer_norm_default_4 = torch.ops.aten.native_layer_norm.default(add_tensor_7, [768], primals_66, primals_65, 1e-12)
        getitem_12 = native_layer_norm_default_4[0]
        getitem_13 = native_layer_norm_default_4[1]
        getitem_14 = native_layer_norm_default_4[2];  native_layer_norm_default_4 = None
        view_default_47 = torch.ops.aten.view.default(getitem_12, [2048, 768])
        t_default_16 = torch.ops.aten.t.default(primals_76);  primals_76 = None
        addmm_default_16 = torch.ops.aten.addmm.default(primals_75, view_default_47, t_default_16);  primals_75 = None
        view_default_48 = torch.ops.aten.view.default(addmm_default_16, [4, 512, 3072]);  addmm_default_16 = None
        gelu_default_2 = torch.ops.aten.gelu.default(view_default_48)
        view_default_49 = torch.ops.aten.view.default(gelu_default_2, [2048, 3072]);  gelu_default_2 = None
        t_default_17 = torch.ops.aten.t.default(primals_80);  primals_80 = None
        addmm_default_17 = torch.ops.aten.addmm.default(primals_79, view_default_49, t_default_17);  primals_79 = None
        view_default_50 = torch.ops.aten.view.default(addmm_default_17, [4, 512, 768]);  addmm_default_17 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(view_default_50, getitem_12);  view_default_50 = getitem_12 = None
        native_layer_norm_default_5 = torch.ops.aten.native_layer_norm.default(add_tensor_8, [768], primals_78, primals_77, 1e-12)
        getitem_15 = native_layer_norm_default_5[0]
        getitem_16 = native_layer_norm_default_5[1]
        getitem_17 = native_layer_norm_default_5[2];  native_layer_norm_default_5 = None
        view_default_51 = torch.ops.aten.view.default(getitem_15, [2048, 768])
        t_default_18 = torch.ops.aten.t.default(primals_88);  primals_88 = None
        addmm_default_18 = torch.ops.aten.addmm.default(primals_87, view_default_51, t_default_18);  primals_87 = None
        view_default_52 = torch.ops.aten.view.default(addmm_default_18, [4, 512, 768]);  addmm_default_18 = None
        view_default_53 = torch.ops.aten.view.default(getitem_15, [2048, 768])
        t_default_19 = torch.ops.aten.t.default(primals_86);  primals_86 = None
        addmm_default_19 = torch.ops.aten.addmm.default(primals_85, view_default_53, t_default_19);  primals_85 = None
        view_default_54 = torch.ops.aten.view.default(addmm_default_19, [4, 512, 768]);  addmm_default_19 = None
        view_default_55 = torch.ops.aten.view.default(view_default_54, [4, 512, 12, 64]);  view_default_54 = None
        permute_default_12 = torch.ops.aten.permute.default(view_default_55, [0, 2, 1, 3]);  view_default_55 = None
        view_default_56 = torch.ops.aten.view.default(getitem_15, [2048, 768])
        t_default_20 = torch.ops.aten.t.default(primals_90);  primals_90 = None
        addmm_default_20 = torch.ops.aten.addmm.default(primals_89, view_default_56, t_default_20);  primals_89 = None
        view_default_57 = torch.ops.aten.view.default(addmm_default_20, [4, 512, 768]);  addmm_default_20 = None
        view_default_58 = torch.ops.aten.view.default(view_default_57, [4, 512, 12, 64]);  view_default_57 = None
        permute_default_13 = torch.ops.aten.permute.default(view_default_58, [0, 2, 1, 3]);  view_default_58 = None
        view_default_59 = torch.ops.aten.view.default(view_default_52, [4, 512, 12, 64]);  view_default_52 = None
        permute_default_14 = torch.ops.aten.permute.default(view_default_59, [0, 2, 1, 3]);  view_default_59 = None
        transpose_int_3 = torch.ops.aten.transpose.int(permute_default_12, -1, -2);  permute_default_12 = None
        expand_default_12 = torch.ops.aten.expand.default(permute_default_14, [4, 12, 512, 64]);  permute_default_14 = None
        clone_default_12 = torch.ops.aten.clone.default(expand_default_12, memory_format = torch.contiguous_format);  expand_default_12 = None
        _unsafe_view_default_15 = torch.ops.aten._unsafe_view.default(clone_default_12, [48, 512, 64]);  clone_default_12 = None
        expand_default_13 = torch.ops.aten.expand.default(transpose_int_3, [4, 12, 64, 512]);  transpose_int_3 = None
        clone_default_13 = torch.ops.aten.clone.default(expand_default_13, memory_format = torch.contiguous_format);  expand_default_13 = None
        _unsafe_view_default_16 = torch.ops.aten._unsafe_view.default(clone_default_13, [48, 64, 512]);  clone_default_13 = None
        bmm_default_6 = torch.ops.aten.bmm.default(_unsafe_view_default_15, _unsafe_view_default_16)
        _unsafe_view_default_17 = torch.ops.aten._unsafe_view.default(bmm_default_6, [4, 12, 512, 512]);  bmm_default_6 = None
        div_tensor_3 = torch.ops.aten.div.Tensor(_unsafe_view_default_17, 8.0);  _unsafe_view_default_17 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(div_tensor_3, primals_194);  div_tensor_3 = None
        _softmax_default_3 = torch.ops.aten._softmax.default(add_tensor_9, -1, False);  add_tensor_9 = None
        expand_default_14 = torch.ops.aten.expand.default(_softmax_default_3, [4, 12, 512, 512])
        view_default_60 = torch.ops.aten.view.default(expand_default_14, [48, 512, 512]);  expand_default_14 = None
        expand_default_15 = torch.ops.aten.expand.default(permute_default_13, [4, 12, 512, 64]);  permute_default_13 = None
        clone_default_14 = torch.ops.aten.clone.default(expand_default_15, memory_format = torch.contiguous_format);  expand_default_15 = None
        _unsafe_view_default_18 = torch.ops.aten._unsafe_view.default(clone_default_14, [48, 512, 64]);  clone_default_14 = None
        bmm_default_7 = torch.ops.aten.bmm.default(view_default_60, _unsafe_view_default_18)
        _unsafe_view_default_19 = torch.ops.aten._unsafe_view.default(bmm_default_7, [4, 12, 512, 64]);  bmm_default_7 = None
        permute_default_15 = torch.ops.aten.permute.default(_unsafe_view_default_19, [0, 2, 1, 3]);  _unsafe_view_default_19 = None
        clone_default_15 = torch.ops.aten.clone.default(permute_default_15, memory_format = torch.contiguous_format);  permute_default_15 = None
        view_default_61 = torch.ops.aten.view.default(clone_default_15, [4, 512, 768]);  clone_default_15 = None
        view_default_62 = torch.ops.aten.view.default(view_default_61, [2048, 768]);  view_default_61 = None
        t_default_21 = torch.ops.aten.t.default(primals_84);  primals_84 = None
        addmm_default_21 = torch.ops.aten.addmm.default(primals_83, view_default_62, t_default_21);  primals_83 = None
        view_default_63 = torch.ops.aten.view.default(addmm_default_21, [4, 512, 768]);  addmm_default_21 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(view_default_63, getitem_15);  view_default_63 = getitem_15 = None
        native_layer_norm_default_6 = torch.ops.aten.native_layer_norm.default(add_tensor_10, [768], primals_82, primals_81, 1e-12)
        getitem_18 = native_layer_norm_default_6[0]
        getitem_19 = native_layer_norm_default_6[1]
        getitem_20 = native_layer_norm_default_6[2];  native_layer_norm_default_6 = None
        view_default_64 = torch.ops.aten.view.default(getitem_18, [2048, 768])
        t_default_22 = torch.ops.aten.t.default(primals_92);  primals_92 = None
        addmm_default_22 = torch.ops.aten.addmm.default(primals_91, view_default_64, t_default_22);  primals_91 = None
        view_default_65 = torch.ops.aten.view.default(addmm_default_22, [4, 512, 3072]);  addmm_default_22 = None
        gelu_default_3 = torch.ops.aten.gelu.default(view_default_65)
        view_default_66 = torch.ops.aten.view.default(gelu_default_3, [2048, 3072]);  gelu_default_3 = None
        t_default_23 = torch.ops.aten.t.default(primals_96);  primals_96 = None
        addmm_default_23 = torch.ops.aten.addmm.default(primals_95, view_default_66, t_default_23);  primals_95 = None
        view_default_67 = torch.ops.aten.view.default(addmm_default_23, [4, 512, 768]);  addmm_default_23 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(view_default_67, getitem_18);  view_default_67 = getitem_18 = None
        native_layer_norm_default_7 = torch.ops.aten.native_layer_norm.default(add_tensor_11, [768], primals_94, primals_93, 1e-12)
        getitem_21 = native_layer_norm_default_7[0]
        getitem_22 = native_layer_norm_default_7[1]
        getitem_23 = native_layer_norm_default_7[2];  native_layer_norm_default_7 = None
        view_default_68 = torch.ops.aten.view.default(getitem_21, [2048, 768])
        t_default_24 = torch.ops.aten.t.default(primals_104);  primals_104 = None
        addmm_default_24 = torch.ops.aten.addmm.default(primals_103, view_default_68, t_default_24);  primals_103 = None
        view_default_69 = torch.ops.aten.view.default(addmm_default_24, [4, 512, 768]);  addmm_default_24 = None
        view_default_70 = torch.ops.aten.view.default(getitem_21, [2048, 768])
        t_default_25 = torch.ops.aten.t.default(primals_102);  primals_102 = None
        addmm_default_25 = torch.ops.aten.addmm.default(primals_101, view_default_70, t_default_25);  primals_101 = None
        view_default_71 = torch.ops.aten.view.default(addmm_default_25, [4, 512, 768]);  addmm_default_25 = None
        view_default_72 = torch.ops.aten.view.default(view_default_71, [4, 512, 12, 64]);  view_default_71 = None
        permute_default_16 = torch.ops.aten.permute.default(view_default_72, [0, 2, 1, 3]);  view_default_72 = None
        view_default_73 = torch.ops.aten.view.default(getitem_21, [2048, 768])
        t_default_26 = torch.ops.aten.t.default(primals_106);  primals_106 = None
        addmm_default_26 = torch.ops.aten.addmm.default(primals_105, view_default_73, t_default_26);  primals_105 = None
        view_default_74 = torch.ops.aten.view.default(addmm_default_26, [4, 512, 768]);  addmm_default_26 = None
        view_default_75 = torch.ops.aten.view.default(view_default_74, [4, 512, 12, 64]);  view_default_74 = None
        permute_default_17 = torch.ops.aten.permute.default(view_default_75, [0, 2, 1, 3]);  view_default_75 = None
        view_default_76 = torch.ops.aten.view.default(view_default_69, [4, 512, 12, 64]);  view_default_69 = None
        permute_default_18 = torch.ops.aten.permute.default(view_default_76, [0, 2, 1, 3]);  view_default_76 = None
        transpose_int_4 = torch.ops.aten.transpose.int(permute_default_16, -1, -2);  permute_default_16 = None
        expand_default_16 = torch.ops.aten.expand.default(permute_default_18, [4, 12, 512, 64]);  permute_default_18 = None
        clone_default_16 = torch.ops.aten.clone.default(expand_default_16, memory_format = torch.contiguous_format);  expand_default_16 = None
        _unsafe_view_default_20 = torch.ops.aten._unsafe_view.default(clone_default_16, [48, 512, 64]);  clone_default_16 = None
        expand_default_17 = torch.ops.aten.expand.default(transpose_int_4, [4, 12, 64, 512]);  transpose_int_4 = None
        clone_default_17 = torch.ops.aten.clone.default(expand_default_17, memory_format = torch.contiguous_format);  expand_default_17 = None
        _unsafe_view_default_21 = torch.ops.aten._unsafe_view.default(clone_default_17, [48, 64, 512]);  clone_default_17 = None
        bmm_default_8 = torch.ops.aten.bmm.default(_unsafe_view_default_20, _unsafe_view_default_21)
        _unsafe_view_default_22 = torch.ops.aten._unsafe_view.default(bmm_default_8, [4, 12, 512, 512]);  bmm_default_8 = None
        div_tensor_4 = torch.ops.aten.div.Tensor(_unsafe_view_default_22, 8.0);  _unsafe_view_default_22 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(div_tensor_4, primals_194);  div_tensor_4 = None
        _softmax_default_4 = torch.ops.aten._softmax.default(add_tensor_12, -1, False);  add_tensor_12 = None
        expand_default_18 = torch.ops.aten.expand.default(_softmax_default_4, [4, 12, 512, 512])
        view_default_77 = torch.ops.aten.view.default(expand_default_18, [48, 512, 512]);  expand_default_18 = None
        expand_default_19 = torch.ops.aten.expand.default(permute_default_17, [4, 12, 512, 64]);  permute_default_17 = None
        clone_default_18 = torch.ops.aten.clone.default(expand_default_19, memory_format = torch.contiguous_format);  expand_default_19 = None
        _unsafe_view_default_23 = torch.ops.aten._unsafe_view.default(clone_default_18, [48, 512, 64]);  clone_default_18 = None
        bmm_default_9 = torch.ops.aten.bmm.default(view_default_77, _unsafe_view_default_23)
        _unsafe_view_default_24 = torch.ops.aten._unsafe_view.default(bmm_default_9, [4, 12, 512, 64]);  bmm_default_9 = None
        permute_default_19 = torch.ops.aten.permute.default(_unsafe_view_default_24, [0, 2, 1, 3]);  _unsafe_view_default_24 = None
        clone_default_19 = torch.ops.aten.clone.default(permute_default_19, memory_format = torch.contiguous_format);  permute_default_19 = None
        view_default_78 = torch.ops.aten.view.default(clone_default_19, [4, 512, 768]);  clone_default_19 = None
        view_default_79 = torch.ops.aten.view.default(view_default_78, [2048, 768]);  view_default_78 = None
        t_default_27 = torch.ops.aten.t.default(primals_100);  primals_100 = None
        addmm_default_27 = torch.ops.aten.addmm.default(primals_99, view_default_79, t_default_27);  primals_99 = None
        view_default_80 = torch.ops.aten.view.default(addmm_default_27, [4, 512, 768]);  addmm_default_27 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(view_default_80, getitem_21);  view_default_80 = getitem_21 = None
        native_layer_norm_default_8 = torch.ops.aten.native_layer_norm.default(add_tensor_13, [768], primals_98, primals_97, 1e-12)
        getitem_24 = native_layer_norm_default_8[0]
        getitem_25 = native_layer_norm_default_8[1]
        getitem_26 = native_layer_norm_default_8[2];  native_layer_norm_default_8 = None
        view_default_81 = torch.ops.aten.view.default(getitem_24, [2048, 768])
        t_default_28 = torch.ops.aten.t.default(primals_108);  primals_108 = None
        addmm_default_28 = torch.ops.aten.addmm.default(primals_107, view_default_81, t_default_28);  primals_107 = None
        view_default_82 = torch.ops.aten.view.default(addmm_default_28, [4, 512, 3072]);  addmm_default_28 = None
        gelu_default_4 = torch.ops.aten.gelu.default(view_default_82)
        view_default_83 = torch.ops.aten.view.default(gelu_default_4, [2048, 3072]);  gelu_default_4 = None
        t_default_29 = torch.ops.aten.t.default(primals_112);  primals_112 = None
        addmm_default_29 = torch.ops.aten.addmm.default(primals_111, view_default_83, t_default_29);  primals_111 = None
        view_default_84 = torch.ops.aten.view.default(addmm_default_29, [4, 512, 768]);  addmm_default_29 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(view_default_84, getitem_24);  view_default_84 = getitem_24 = None
        native_layer_norm_default_9 = torch.ops.aten.native_layer_norm.default(add_tensor_14, [768], primals_110, primals_109, 1e-12)
        getitem_27 = native_layer_norm_default_9[0]
        getitem_28 = native_layer_norm_default_9[1]
        getitem_29 = native_layer_norm_default_9[2];  native_layer_norm_default_9 = None
        view_default_85 = torch.ops.aten.view.default(getitem_27, [2048, 768])
        t_default_30 = torch.ops.aten.t.default(primals_120);  primals_120 = None
        addmm_default_30 = torch.ops.aten.addmm.default(primals_119, view_default_85, t_default_30);  primals_119 = None
        view_default_86 = torch.ops.aten.view.default(addmm_default_30, [4, 512, 768]);  addmm_default_30 = None
        view_default_87 = torch.ops.aten.view.default(getitem_27, [2048, 768])
        t_default_31 = torch.ops.aten.t.default(primals_118);  primals_118 = None
        addmm_default_31 = torch.ops.aten.addmm.default(primals_117, view_default_87, t_default_31);  primals_117 = None
        view_default_88 = torch.ops.aten.view.default(addmm_default_31, [4, 512, 768]);  addmm_default_31 = None
        view_default_89 = torch.ops.aten.view.default(view_default_88, [4, 512, 12, 64]);  view_default_88 = None
        permute_default_20 = torch.ops.aten.permute.default(view_default_89, [0, 2, 1, 3]);  view_default_89 = None
        view_default_90 = torch.ops.aten.view.default(getitem_27, [2048, 768])
        t_default_32 = torch.ops.aten.t.default(primals_122);  primals_122 = None
        addmm_default_32 = torch.ops.aten.addmm.default(primals_121, view_default_90, t_default_32);  primals_121 = None
        view_default_91 = torch.ops.aten.view.default(addmm_default_32, [4, 512, 768]);  addmm_default_32 = None
        view_default_92 = torch.ops.aten.view.default(view_default_91, [4, 512, 12, 64]);  view_default_91 = None
        permute_default_21 = torch.ops.aten.permute.default(view_default_92, [0, 2, 1, 3]);  view_default_92 = None
        view_default_93 = torch.ops.aten.view.default(view_default_86, [4, 512, 12, 64]);  view_default_86 = None
        permute_default_22 = torch.ops.aten.permute.default(view_default_93, [0, 2, 1, 3]);  view_default_93 = None
        transpose_int_5 = torch.ops.aten.transpose.int(permute_default_20, -1, -2);  permute_default_20 = None
        expand_default_20 = torch.ops.aten.expand.default(permute_default_22, [4, 12, 512, 64]);  permute_default_22 = None
        clone_default_20 = torch.ops.aten.clone.default(expand_default_20, memory_format = torch.contiguous_format);  expand_default_20 = None
        _unsafe_view_default_25 = torch.ops.aten._unsafe_view.default(clone_default_20, [48, 512, 64]);  clone_default_20 = None
        expand_default_21 = torch.ops.aten.expand.default(transpose_int_5, [4, 12, 64, 512]);  transpose_int_5 = None
        clone_default_21 = torch.ops.aten.clone.default(expand_default_21, memory_format = torch.contiguous_format);  expand_default_21 = None
        _unsafe_view_default_26 = torch.ops.aten._unsafe_view.default(clone_default_21, [48, 64, 512]);  clone_default_21 = None
        bmm_default_10 = torch.ops.aten.bmm.default(_unsafe_view_default_25, _unsafe_view_default_26)
        _unsafe_view_default_27 = torch.ops.aten._unsafe_view.default(bmm_default_10, [4, 12, 512, 512]);  bmm_default_10 = None
        div_tensor_5 = torch.ops.aten.div.Tensor(_unsafe_view_default_27, 8.0);  _unsafe_view_default_27 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(div_tensor_5, primals_194);  div_tensor_5 = None
        _softmax_default_5 = torch.ops.aten._softmax.default(add_tensor_15, -1, False);  add_tensor_15 = None
        expand_default_22 = torch.ops.aten.expand.default(_softmax_default_5, [4, 12, 512, 512])
        view_default_94 = torch.ops.aten.view.default(expand_default_22, [48, 512, 512]);  expand_default_22 = None
        expand_default_23 = torch.ops.aten.expand.default(permute_default_21, [4, 12, 512, 64]);  permute_default_21 = None
        clone_default_22 = torch.ops.aten.clone.default(expand_default_23, memory_format = torch.contiguous_format);  expand_default_23 = None
        _unsafe_view_default_28 = torch.ops.aten._unsafe_view.default(clone_default_22, [48, 512, 64]);  clone_default_22 = None
        bmm_default_11 = torch.ops.aten.bmm.default(view_default_94, _unsafe_view_default_28)
        _unsafe_view_default_29 = torch.ops.aten._unsafe_view.default(bmm_default_11, [4, 12, 512, 64]);  bmm_default_11 = None
        permute_default_23 = torch.ops.aten.permute.default(_unsafe_view_default_29, [0, 2, 1, 3]);  _unsafe_view_default_29 = None
        clone_default_23 = torch.ops.aten.clone.default(permute_default_23, memory_format = torch.contiguous_format);  permute_default_23 = None
        view_default_95 = torch.ops.aten.view.default(clone_default_23, [4, 512, 768]);  clone_default_23 = None
        view_default_96 = torch.ops.aten.view.default(view_default_95, [2048, 768]);  view_default_95 = None
        t_default_33 = torch.ops.aten.t.default(primals_116);  primals_116 = None
        addmm_default_33 = torch.ops.aten.addmm.default(primals_115, view_default_96, t_default_33);  primals_115 = None
        view_default_97 = torch.ops.aten.view.default(addmm_default_33, [4, 512, 768]);  addmm_default_33 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(view_default_97, getitem_27);  view_default_97 = getitem_27 = None
        native_layer_norm_default_10 = torch.ops.aten.native_layer_norm.default(add_tensor_16, [768], primals_114, primals_113, 1e-12)
        getitem_30 = native_layer_norm_default_10[0]
        getitem_31 = native_layer_norm_default_10[1]
        getitem_32 = native_layer_norm_default_10[2];  native_layer_norm_default_10 = None
        view_default_98 = torch.ops.aten.view.default(getitem_30, [2048, 768])
        t_default_34 = torch.ops.aten.t.default(primals_124);  primals_124 = None
        addmm_default_34 = torch.ops.aten.addmm.default(primals_123, view_default_98, t_default_34);  primals_123 = None
        view_default_99 = torch.ops.aten.view.default(addmm_default_34, [4, 512, 3072]);  addmm_default_34 = None
        gelu_default_5 = torch.ops.aten.gelu.default(view_default_99)
        view_default_100 = torch.ops.aten.view.default(gelu_default_5, [2048, 3072]);  gelu_default_5 = None
        t_default_35 = torch.ops.aten.t.default(primals_128);  primals_128 = None
        addmm_default_35 = torch.ops.aten.addmm.default(primals_127, view_default_100, t_default_35);  primals_127 = None
        view_default_101 = torch.ops.aten.view.default(addmm_default_35, [4, 512, 768]);  addmm_default_35 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(view_default_101, getitem_30);  view_default_101 = getitem_30 = None
        native_layer_norm_default_11 = torch.ops.aten.native_layer_norm.default(add_tensor_17, [768], primals_126, primals_125, 1e-12)
        getitem_33 = native_layer_norm_default_11[0]
        getitem_34 = native_layer_norm_default_11[1]
        getitem_35 = native_layer_norm_default_11[2];  native_layer_norm_default_11 = None
        view_default_102 = torch.ops.aten.view.default(getitem_33, [2048, 768])
        t_default_36 = torch.ops.aten.t.default(primals_136);  primals_136 = None
        addmm_default_36 = torch.ops.aten.addmm.default(primals_135, view_default_102, t_default_36);  primals_135 = None
        view_default_103 = torch.ops.aten.view.default(addmm_default_36, [4, 512, 768]);  addmm_default_36 = None
        view_default_104 = torch.ops.aten.view.default(getitem_33, [2048, 768])
        t_default_37 = torch.ops.aten.t.default(primals_134);  primals_134 = None
        addmm_default_37 = torch.ops.aten.addmm.default(primals_133, view_default_104, t_default_37);  primals_133 = None
        view_default_105 = torch.ops.aten.view.default(addmm_default_37, [4, 512, 768]);  addmm_default_37 = None
        view_default_106 = torch.ops.aten.view.default(view_default_105, [4, 512, 12, 64]);  view_default_105 = None
        permute_default_24 = torch.ops.aten.permute.default(view_default_106, [0, 2, 1, 3]);  view_default_106 = None
        view_default_107 = torch.ops.aten.view.default(getitem_33, [2048, 768])
        t_default_38 = torch.ops.aten.t.default(primals_138);  primals_138 = None
        addmm_default_38 = torch.ops.aten.addmm.default(primals_137, view_default_107, t_default_38);  primals_137 = None
        view_default_108 = torch.ops.aten.view.default(addmm_default_38, [4, 512, 768]);  addmm_default_38 = None
        view_default_109 = torch.ops.aten.view.default(view_default_108, [4, 512, 12, 64]);  view_default_108 = None
        permute_default_25 = torch.ops.aten.permute.default(view_default_109, [0, 2, 1, 3]);  view_default_109 = None
        view_default_110 = torch.ops.aten.view.default(view_default_103, [4, 512, 12, 64]);  view_default_103 = None
        permute_default_26 = torch.ops.aten.permute.default(view_default_110, [0, 2, 1, 3]);  view_default_110 = None
        transpose_int_6 = torch.ops.aten.transpose.int(permute_default_24, -1, -2);  permute_default_24 = None
        expand_default_24 = torch.ops.aten.expand.default(permute_default_26, [4, 12, 512, 64]);  permute_default_26 = None
        clone_default_24 = torch.ops.aten.clone.default(expand_default_24, memory_format = torch.contiguous_format);  expand_default_24 = None
        _unsafe_view_default_30 = torch.ops.aten._unsafe_view.default(clone_default_24, [48, 512, 64]);  clone_default_24 = None
        expand_default_25 = torch.ops.aten.expand.default(transpose_int_6, [4, 12, 64, 512]);  transpose_int_6 = None
        clone_default_25 = torch.ops.aten.clone.default(expand_default_25, memory_format = torch.contiguous_format);  expand_default_25 = None
        _unsafe_view_default_31 = torch.ops.aten._unsafe_view.default(clone_default_25, [48, 64, 512]);  clone_default_25 = None
        bmm_default_12 = torch.ops.aten.bmm.default(_unsafe_view_default_30, _unsafe_view_default_31)
        _unsafe_view_default_32 = torch.ops.aten._unsafe_view.default(bmm_default_12, [4, 12, 512, 512]);  bmm_default_12 = None
        div_tensor_6 = torch.ops.aten.div.Tensor(_unsafe_view_default_32, 8.0);  _unsafe_view_default_32 = None
        add_tensor_18 = torch.ops.aten.add.Tensor(div_tensor_6, primals_194);  div_tensor_6 = None
        _softmax_default_6 = torch.ops.aten._softmax.default(add_tensor_18, -1, False);  add_tensor_18 = None
        expand_default_26 = torch.ops.aten.expand.default(_softmax_default_6, [4, 12, 512, 512])
        view_default_111 = torch.ops.aten.view.default(expand_default_26, [48, 512, 512]);  expand_default_26 = None
        expand_default_27 = torch.ops.aten.expand.default(permute_default_25, [4, 12, 512, 64]);  permute_default_25 = None
        clone_default_26 = torch.ops.aten.clone.default(expand_default_27, memory_format = torch.contiguous_format);  expand_default_27 = None
        _unsafe_view_default_33 = torch.ops.aten._unsafe_view.default(clone_default_26, [48, 512, 64]);  clone_default_26 = None
        bmm_default_13 = torch.ops.aten.bmm.default(view_default_111, _unsafe_view_default_33)
        _unsafe_view_default_34 = torch.ops.aten._unsafe_view.default(bmm_default_13, [4, 12, 512, 64]);  bmm_default_13 = None
        permute_default_27 = torch.ops.aten.permute.default(_unsafe_view_default_34, [0, 2, 1, 3]);  _unsafe_view_default_34 = None
        clone_default_27 = torch.ops.aten.clone.default(permute_default_27, memory_format = torch.contiguous_format);  permute_default_27 = None
        view_default_112 = torch.ops.aten.view.default(clone_default_27, [4, 512, 768]);  clone_default_27 = None
        view_default_113 = torch.ops.aten.view.default(view_default_112, [2048, 768]);  view_default_112 = None
        t_default_39 = torch.ops.aten.t.default(primals_132);  primals_132 = None
        addmm_default_39 = torch.ops.aten.addmm.default(primals_131, view_default_113, t_default_39);  primals_131 = None
        view_default_114 = torch.ops.aten.view.default(addmm_default_39, [4, 512, 768]);  addmm_default_39 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(view_default_114, getitem_33);  view_default_114 = getitem_33 = None
        native_layer_norm_default_12 = torch.ops.aten.native_layer_norm.default(add_tensor_19, [768], primals_130, primals_129, 1e-12)
        getitem_36 = native_layer_norm_default_12[0]
        getitem_37 = native_layer_norm_default_12[1]
        getitem_38 = native_layer_norm_default_12[2];  native_layer_norm_default_12 = None
        view_default_115 = torch.ops.aten.view.default(getitem_36, [2048, 768])
        t_default_40 = torch.ops.aten.t.default(primals_140);  primals_140 = None
        addmm_default_40 = torch.ops.aten.addmm.default(primals_139, view_default_115, t_default_40);  primals_139 = None
        view_default_116 = torch.ops.aten.view.default(addmm_default_40, [4, 512, 3072]);  addmm_default_40 = None
        gelu_default_6 = torch.ops.aten.gelu.default(view_default_116)
        view_default_117 = torch.ops.aten.view.default(gelu_default_6, [2048, 3072]);  gelu_default_6 = None
        t_default_41 = torch.ops.aten.t.default(primals_144);  primals_144 = None
        addmm_default_41 = torch.ops.aten.addmm.default(primals_143, view_default_117, t_default_41);  primals_143 = None
        view_default_118 = torch.ops.aten.view.default(addmm_default_41, [4, 512, 768]);  addmm_default_41 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(view_default_118, getitem_36);  view_default_118 = getitem_36 = None
        native_layer_norm_default_13 = torch.ops.aten.native_layer_norm.default(add_tensor_20, [768], primals_142, primals_141, 1e-12)
        getitem_39 = native_layer_norm_default_13[0]
        getitem_40 = native_layer_norm_default_13[1]
        getitem_41 = native_layer_norm_default_13[2];  native_layer_norm_default_13 = None
        view_default_119 = torch.ops.aten.view.default(getitem_39, [2048, 768])
        t_default_42 = torch.ops.aten.t.default(primals_152);  primals_152 = None
        addmm_default_42 = torch.ops.aten.addmm.default(primals_151, view_default_119, t_default_42);  primals_151 = None
        view_default_120 = torch.ops.aten.view.default(addmm_default_42, [4, 512, 768]);  addmm_default_42 = None
        view_default_121 = torch.ops.aten.view.default(getitem_39, [2048, 768])
        t_default_43 = torch.ops.aten.t.default(primals_150);  primals_150 = None
        addmm_default_43 = torch.ops.aten.addmm.default(primals_149, view_default_121, t_default_43);  primals_149 = None
        view_default_122 = torch.ops.aten.view.default(addmm_default_43, [4, 512, 768]);  addmm_default_43 = None
        view_default_123 = torch.ops.aten.view.default(view_default_122, [4, 512, 12, 64]);  view_default_122 = None
        permute_default_28 = torch.ops.aten.permute.default(view_default_123, [0, 2, 1, 3]);  view_default_123 = None
        view_default_124 = torch.ops.aten.view.default(getitem_39, [2048, 768])
        t_default_44 = torch.ops.aten.t.default(primals_154);  primals_154 = None
        addmm_default_44 = torch.ops.aten.addmm.default(primals_153, view_default_124, t_default_44);  primals_153 = None
        view_default_125 = torch.ops.aten.view.default(addmm_default_44, [4, 512, 768]);  addmm_default_44 = None
        view_default_126 = torch.ops.aten.view.default(view_default_125, [4, 512, 12, 64]);  view_default_125 = None
        permute_default_29 = torch.ops.aten.permute.default(view_default_126, [0, 2, 1, 3]);  view_default_126 = None
        view_default_127 = torch.ops.aten.view.default(view_default_120, [4, 512, 12, 64]);  view_default_120 = None
        permute_default_30 = torch.ops.aten.permute.default(view_default_127, [0, 2, 1, 3]);  view_default_127 = None
        transpose_int_7 = torch.ops.aten.transpose.int(permute_default_28, -1, -2);  permute_default_28 = None
        expand_default_28 = torch.ops.aten.expand.default(permute_default_30, [4, 12, 512, 64]);  permute_default_30 = None
        clone_default_28 = torch.ops.aten.clone.default(expand_default_28, memory_format = torch.contiguous_format);  expand_default_28 = None
        _unsafe_view_default_35 = torch.ops.aten._unsafe_view.default(clone_default_28, [48, 512, 64]);  clone_default_28 = None
        expand_default_29 = torch.ops.aten.expand.default(transpose_int_7, [4, 12, 64, 512]);  transpose_int_7 = None
        clone_default_29 = torch.ops.aten.clone.default(expand_default_29, memory_format = torch.contiguous_format);  expand_default_29 = None
        _unsafe_view_default_36 = torch.ops.aten._unsafe_view.default(clone_default_29, [48, 64, 512]);  clone_default_29 = None
        bmm_default_14 = torch.ops.aten.bmm.default(_unsafe_view_default_35, _unsafe_view_default_36)
        _unsafe_view_default_37 = torch.ops.aten._unsafe_view.default(bmm_default_14, [4, 12, 512, 512]);  bmm_default_14 = None
        div_tensor_7 = torch.ops.aten.div.Tensor(_unsafe_view_default_37, 8.0);  _unsafe_view_default_37 = None
        add_tensor_21 = torch.ops.aten.add.Tensor(div_tensor_7, primals_194);  div_tensor_7 = None
        _softmax_default_7 = torch.ops.aten._softmax.default(add_tensor_21, -1, False);  add_tensor_21 = None
        expand_default_30 = torch.ops.aten.expand.default(_softmax_default_7, [4, 12, 512, 512])
        view_default_128 = torch.ops.aten.view.default(expand_default_30, [48, 512, 512]);  expand_default_30 = None
        expand_default_31 = torch.ops.aten.expand.default(permute_default_29, [4, 12, 512, 64]);  permute_default_29 = None
        clone_default_30 = torch.ops.aten.clone.default(expand_default_31, memory_format = torch.contiguous_format);  expand_default_31 = None
        _unsafe_view_default_38 = torch.ops.aten._unsafe_view.default(clone_default_30, [48, 512, 64]);  clone_default_30 = None
        bmm_default_15 = torch.ops.aten.bmm.default(view_default_128, _unsafe_view_default_38)
        _unsafe_view_default_39 = torch.ops.aten._unsafe_view.default(bmm_default_15, [4, 12, 512, 64]);  bmm_default_15 = None
        permute_default_31 = torch.ops.aten.permute.default(_unsafe_view_default_39, [0, 2, 1, 3]);  _unsafe_view_default_39 = None
        clone_default_31 = torch.ops.aten.clone.default(permute_default_31, memory_format = torch.contiguous_format);  permute_default_31 = None
        view_default_129 = torch.ops.aten.view.default(clone_default_31, [4, 512, 768]);  clone_default_31 = None
        view_default_130 = torch.ops.aten.view.default(view_default_129, [2048, 768]);  view_default_129 = None
        t_default_45 = torch.ops.aten.t.default(primals_148);  primals_148 = None
        addmm_default_45 = torch.ops.aten.addmm.default(primals_147, view_default_130, t_default_45);  primals_147 = None
        view_default_131 = torch.ops.aten.view.default(addmm_default_45, [4, 512, 768]);  addmm_default_45 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(view_default_131, getitem_39);  view_default_131 = getitem_39 = None
        native_layer_norm_default_14 = torch.ops.aten.native_layer_norm.default(add_tensor_22, [768], primals_146, primals_145, 1e-12)
        getitem_42 = native_layer_norm_default_14[0]
        getitem_43 = native_layer_norm_default_14[1]
        getitem_44 = native_layer_norm_default_14[2];  native_layer_norm_default_14 = None
        view_default_132 = torch.ops.aten.view.default(getitem_42, [2048, 768])
        t_default_46 = torch.ops.aten.t.default(primals_156);  primals_156 = None
        addmm_default_46 = torch.ops.aten.addmm.default(primals_155, view_default_132, t_default_46);  primals_155 = None
        view_default_133 = torch.ops.aten.view.default(addmm_default_46, [4, 512, 3072]);  addmm_default_46 = None
        gelu_default_7 = torch.ops.aten.gelu.default(view_default_133)
        view_default_134 = torch.ops.aten.view.default(gelu_default_7, [2048, 3072]);  gelu_default_7 = None
        t_default_47 = torch.ops.aten.t.default(primals_160);  primals_160 = None
        addmm_default_47 = torch.ops.aten.addmm.default(primals_159, view_default_134, t_default_47);  primals_159 = None
        view_default_135 = torch.ops.aten.view.default(addmm_default_47, [4, 512, 768]);  addmm_default_47 = None
        add_tensor_23 = torch.ops.aten.add.Tensor(view_default_135, getitem_42);  view_default_135 = getitem_42 = None
        native_layer_norm_default_15 = torch.ops.aten.native_layer_norm.default(add_tensor_23, [768], primals_158, primals_157, 1e-12)
        getitem_45 = native_layer_norm_default_15[0]
        getitem_46 = native_layer_norm_default_15[1]
        getitem_47 = native_layer_norm_default_15[2];  native_layer_norm_default_15 = None
        view_default_136 = torch.ops.aten.view.default(getitem_45, [2048, 768])
        t_default_48 = torch.ops.aten.t.default(primals_168);  primals_168 = None
        addmm_default_48 = torch.ops.aten.addmm.default(primals_167, view_default_136, t_default_48);  primals_167 = None
        view_default_137 = torch.ops.aten.view.default(addmm_default_48, [4, 512, 768]);  addmm_default_48 = None
        view_default_138 = torch.ops.aten.view.default(getitem_45, [2048, 768])
        t_default_49 = torch.ops.aten.t.default(primals_166);  primals_166 = None
        addmm_default_49 = torch.ops.aten.addmm.default(primals_165, view_default_138, t_default_49);  primals_165 = None
        view_default_139 = torch.ops.aten.view.default(addmm_default_49, [4, 512, 768]);  addmm_default_49 = None
        view_default_140 = torch.ops.aten.view.default(view_default_139, [4, 512, 12, 64]);  view_default_139 = None
        permute_default_32 = torch.ops.aten.permute.default(view_default_140, [0, 2, 1, 3]);  view_default_140 = None
        view_default_141 = torch.ops.aten.view.default(getitem_45, [2048, 768])
        t_default_50 = torch.ops.aten.t.default(primals_170);  primals_170 = None
        addmm_default_50 = torch.ops.aten.addmm.default(primals_169, view_default_141, t_default_50);  primals_169 = None
        view_default_142 = torch.ops.aten.view.default(addmm_default_50, [4, 512, 768]);  addmm_default_50 = None
        view_default_143 = torch.ops.aten.view.default(view_default_142, [4, 512, 12, 64]);  view_default_142 = None
        permute_default_33 = torch.ops.aten.permute.default(view_default_143, [0, 2, 1, 3]);  view_default_143 = None
        view_default_144 = torch.ops.aten.view.default(view_default_137, [4, 512, 12, 64]);  view_default_137 = None
        permute_default_34 = torch.ops.aten.permute.default(view_default_144, [0, 2, 1, 3]);  view_default_144 = None
        transpose_int_8 = torch.ops.aten.transpose.int(permute_default_32, -1, -2);  permute_default_32 = None
        expand_default_32 = torch.ops.aten.expand.default(permute_default_34, [4, 12, 512, 64]);  permute_default_34 = None
        clone_default_32 = torch.ops.aten.clone.default(expand_default_32, memory_format = torch.contiguous_format);  expand_default_32 = None
        _unsafe_view_default_40 = torch.ops.aten._unsafe_view.default(clone_default_32, [48, 512, 64]);  clone_default_32 = None
        expand_default_33 = torch.ops.aten.expand.default(transpose_int_8, [4, 12, 64, 512]);  transpose_int_8 = None
        clone_default_33 = torch.ops.aten.clone.default(expand_default_33, memory_format = torch.contiguous_format);  expand_default_33 = None
        _unsafe_view_default_41 = torch.ops.aten._unsafe_view.default(clone_default_33, [48, 64, 512]);  clone_default_33 = None
        bmm_default_16 = torch.ops.aten.bmm.default(_unsafe_view_default_40, _unsafe_view_default_41)
        _unsafe_view_default_42 = torch.ops.aten._unsafe_view.default(bmm_default_16, [4, 12, 512, 512]);  bmm_default_16 = None
        div_tensor_8 = torch.ops.aten.div.Tensor(_unsafe_view_default_42, 8.0);  _unsafe_view_default_42 = None
        add_tensor_24 = torch.ops.aten.add.Tensor(div_tensor_8, primals_194);  div_tensor_8 = None
        _softmax_default_8 = torch.ops.aten._softmax.default(add_tensor_24, -1, False);  add_tensor_24 = None
        expand_default_34 = torch.ops.aten.expand.default(_softmax_default_8, [4, 12, 512, 512])
        view_default_145 = torch.ops.aten.view.default(expand_default_34, [48, 512, 512]);  expand_default_34 = None
        expand_default_35 = torch.ops.aten.expand.default(permute_default_33, [4, 12, 512, 64]);  permute_default_33 = None
        clone_default_34 = torch.ops.aten.clone.default(expand_default_35, memory_format = torch.contiguous_format);  expand_default_35 = None
        _unsafe_view_default_43 = torch.ops.aten._unsafe_view.default(clone_default_34, [48, 512, 64]);  clone_default_34 = None
        bmm_default_17 = torch.ops.aten.bmm.default(view_default_145, _unsafe_view_default_43)
        _unsafe_view_default_44 = torch.ops.aten._unsafe_view.default(bmm_default_17, [4, 12, 512, 64]);  bmm_default_17 = None
        permute_default_35 = torch.ops.aten.permute.default(_unsafe_view_default_44, [0, 2, 1, 3]);  _unsafe_view_default_44 = None
        clone_default_35 = torch.ops.aten.clone.default(permute_default_35, memory_format = torch.contiguous_format);  permute_default_35 = None
        view_default_146 = torch.ops.aten.view.default(clone_default_35, [4, 512, 768]);  clone_default_35 = None
        view_default_147 = torch.ops.aten.view.default(view_default_146, [2048, 768]);  view_default_146 = None
        t_default_51 = torch.ops.aten.t.default(primals_164);  primals_164 = None
        addmm_default_51 = torch.ops.aten.addmm.default(primals_163, view_default_147, t_default_51);  primals_163 = None
        view_default_148 = torch.ops.aten.view.default(addmm_default_51, [4, 512, 768]);  addmm_default_51 = None
        add_tensor_25 = torch.ops.aten.add.Tensor(view_default_148, getitem_45);  view_default_148 = getitem_45 = None
        native_layer_norm_default_16 = torch.ops.aten.native_layer_norm.default(add_tensor_25, [768], primals_162, primals_161, 1e-12)
        getitem_48 = native_layer_norm_default_16[0]
        getitem_49 = native_layer_norm_default_16[1]
        getitem_50 = native_layer_norm_default_16[2];  native_layer_norm_default_16 = None
        view_default_149 = torch.ops.aten.view.default(getitem_48, [2048, 768])
        t_default_52 = torch.ops.aten.t.default(primals_172);  primals_172 = None
        addmm_default_52 = torch.ops.aten.addmm.default(primals_171, view_default_149, t_default_52);  primals_171 = None
        view_default_150 = torch.ops.aten.view.default(addmm_default_52, [4, 512, 3072]);  addmm_default_52 = None
        gelu_default_8 = torch.ops.aten.gelu.default(view_default_150)
        view_default_151 = torch.ops.aten.view.default(gelu_default_8, [2048, 3072]);  gelu_default_8 = None
        t_default_53 = torch.ops.aten.t.default(primals_176);  primals_176 = None
        addmm_default_53 = torch.ops.aten.addmm.default(primals_175, view_default_151, t_default_53);  primals_175 = None
        view_default_152 = torch.ops.aten.view.default(addmm_default_53, [4, 512, 768]);  addmm_default_53 = None
        add_tensor_26 = torch.ops.aten.add.Tensor(view_default_152, getitem_48);  view_default_152 = getitem_48 = None
        native_layer_norm_default_17 = torch.ops.aten.native_layer_norm.default(add_tensor_26, [768], primals_174, primals_173, 1e-12)
        getitem_51 = native_layer_norm_default_17[0]
        getitem_52 = native_layer_norm_default_17[1]
        getitem_53 = native_layer_norm_default_17[2];  native_layer_norm_default_17 = None
        view_default_153 = torch.ops.aten.view.default(getitem_51, [2048, 768])
        t_default_54 = torch.ops.aten.t.default(primals_184);  primals_184 = None
        addmm_default_54 = torch.ops.aten.addmm.default(primals_183, view_default_153, t_default_54);  primals_183 = None
        view_default_154 = torch.ops.aten.view.default(addmm_default_54, [4, 512, 768]);  addmm_default_54 = None
        view_default_155 = torch.ops.aten.view.default(getitem_51, [2048, 768])
        t_default_55 = torch.ops.aten.t.default(primals_182);  primals_182 = None
        addmm_default_55 = torch.ops.aten.addmm.default(primals_181, view_default_155, t_default_55);  primals_181 = None
        view_default_156 = torch.ops.aten.view.default(addmm_default_55, [4, 512, 768]);  addmm_default_55 = None
        view_default_157 = torch.ops.aten.view.default(view_default_156, [4, 512, 12, 64]);  view_default_156 = None
        permute_default_36 = torch.ops.aten.permute.default(view_default_157, [0, 2, 1, 3]);  view_default_157 = None
        view_default_158 = torch.ops.aten.view.default(getitem_51, [2048, 768])
        t_default_56 = torch.ops.aten.t.default(primals_186);  primals_186 = None
        addmm_default_56 = torch.ops.aten.addmm.default(primals_185, view_default_158, t_default_56);  primals_185 = None
        view_default_159 = torch.ops.aten.view.default(addmm_default_56, [4, 512, 768]);  addmm_default_56 = None
        view_default_160 = torch.ops.aten.view.default(view_default_159, [4, 512, 12, 64]);  view_default_159 = None
        permute_default_37 = torch.ops.aten.permute.default(view_default_160, [0, 2, 1, 3]);  view_default_160 = None
        view_default_161 = torch.ops.aten.view.default(view_default_154, [4, 512, 12, 64]);  view_default_154 = None
        permute_default_38 = torch.ops.aten.permute.default(view_default_161, [0, 2, 1, 3]);  view_default_161 = None
        transpose_int_9 = torch.ops.aten.transpose.int(permute_default_36, -1, -2);  permute_default_36 = None
        expand_default_36 = torch.ops.aten.expand.default(permute_default_38, [4, 12, 512, 64]);  permute_default_38 = None
        clone_default_36 = torch.ops.aten.clone.default(expand_default_36, memory_format = torch.contiguous_format);  expand_default_36 = None
        _unsafe_view_default_45 = torch.ops.aten._unsafe_view.default(clone_default_36, [48, 512, 64]);  clone_default_36 = None
        expand_default_37 = torch.ops.aten.expand.default(transpose_int_9, [4, 12, 64, 512]);  transpose_int_9 = None
        clone_default_37 = torch.ops.aten.clone.default(expand_default_37, memory_format = torch.contiguous_format);  expand_default_37 = None
        _unsafe_view_default_46 = torch.ops.aten._unsafe_view.default(clone_default_37, [48, 64, 512]);  clone_default_37 = None
        bmm_default_18 = torch.ops.aten.bmm.default(_unsafe_view_default_45, _unsafe_view_default_46)
        _unsafe_view_default_47 = torch.ops.aten._unsafe_view.default(bmm_default_18, [4, 12, 512, 512]);  bmm_default_18 = None
        div_tensor_9 = torch.ops.aten.div.Tensor(_unsafe_view_default_47, 8.0);  _unsafe_view_default_47 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(div_tensor_9, primals_194);  div_tensor_9 = None
        _softmax_default_9 = torch.ops.aten._softmax.default(add_tensor_27, -1, False);  add_tensor_27 = None
        expand_default_38 = torch.ops.aten.expand.default(_softmax_default_9, [4, 12, 512, 512])
        view_default_162 = torch.ops.aten.view.default(expand_default_38, [48, 512, 512]);  expand_default_38 = None
        expand_default_39 = torch.ops.aten.expand.default(permute_default_37, [4, 12, 512, 64]);  permute_default_37 = None
        clone_default_38 = torch.ops.aten.clone.default(expand_default_39, memory_format = torch.contiguous_format);  expand_default_39 = None
        _unsafe_view_default_48 = torch.ops.aten._unsafe_view.default(clone_default_38, [48, 512, 64]);  clone_default_38 = None
        bmm_default_19 = torch.ops.aten.bmm.default(view_default_162, _unsafe_view_default_48)
        _unsafe_view_default_49 = torch.ops.aten._unsafe_view.default(bmm_default_19, [4, 12, 512, 64]);  bmm_default_19 = None
        permute_default_39 = torch.ops.aten.permute.default(_unsafe_view_default_49, [0, 2, 1, 3]);  _unsafe_view_default_49 = None
        clone_default_39 = torch.ops.aten.clone.default(permute_default_39, memory_format = torch.contiguous_format);  permute_default_39 = None
        view_default_163 = torch.ops.aten.view.default(clone_default_39, [4, 512, 768]);  clone_default_39 = None
        view_default_164 = torch.ops.aten.view.default(view_default_163, [2048, 768]);  view_default_163 = None
        t_default_57 = torch.ops.aten.t.default(primals_180);  primals_180 = None
        addmm_default_57 = torch.ops.aten.addmm.default(primals_179, view_default_164, t_default_57);  primals_179 = None
        view_default_165 = torch.ops.aten.view.default(addmm_default_57, [4, 512, 768]);  addmm_default_57 = None
        add_tensor_28 = torch.ops.aten.add.Tensor(view_default_165, getitem_51);  view_default_165 = getitem_51 = None
        native_layer_norm_default_18 = torch.ops.aten.native_layer_norm.default(add_tensor_28, [768], primals_178, primals_177, 1e-12)
        getitem_54 = native_layer_norm_default_18[0]
        getitem_55 = native_layer_norm_default_18[1]
        getitem_56 = native_layer_norm_default_18[2];  native_layer_norm_default_18 = None
        view_default_166 = torch.ops.aten.view.default(getitem_54, [2048, 768])
        t_default_58 = torch.ops.aten.t.default(primals_188);  primals_188 = None
        addmm_default_58 = torch.ops.aten.addmm.default(primals_187, view_default_166, t_default_58);  primals_187 = None
        view_default_167 = torch.ops.aten.view.default(addmm_default_58, [4, 512, 3072]);  addmm_default_58 = None
        gelu_default_9 = torch.ops.aten.gelu.default(view_default_167)
        view_default_168 = torch.ops.aten.view.default(gelu_default_9, [2048, 3072]);  gelu_default_9 = None
        t_default_59 = torch.ops.aten.t.default(primals_192);  primals_192 = None
        addmm_default_59 = torch.ops.aten.addmm.default(primals_191, view_default_168, t_default_59);  primals_191 = None
        view_default_169 = torch.ops.aten.view.default(addmm_default_59, [4, 512, 768]);  addmm_default_59 = None
        add_tensor_29 = torch.ops.aten.add.Tensor(view_default_169, getitem_54);  view_default_169 = getitem_54 = None
        native_layer_norm_default_19 = torch.ops.aten.native_layer_norm.default(add_tensor_29, [768], primals_190, primals_189, 1e-12)
        getitem_57 = native_layer_norm_default_19[0]
        getitem_58 = native_layer_norm_default_19[1]
        getitem_59 = native_layer_norm_default_19[2];  native_layer_norm_default_19 = None
        view_default_170 = torch.ops.aten.view.default(getitem_57, [2048, 768])
        t_default_60 = torch.ops.aten.t.default(primals_24);  primals_24 = None
        addmm_default_60 = torch.ops.aten.addmm.default(primals_23, view_default_170, t_default_60);  primals_23 = None
        view_default_171 = torch.ops.aten.view.default(addmm_default_60, [4, 512, 768]);  addmm_default_60 = None
        view_default_172 = torch.ops.aten.view.default(getitem_57, [2048, 768])
        t_default_61 = torch.ops.aten.t.default(primals_22);  primals_22 = None
        addmm_default_61 = torch.ops.aten.addmm.default(primals_21, view_default_172, t_default_61);  primals_21 = None
        view_default_173 = torch.ops.aten.view.default(addmm_default_61, [4, 512, 768]);  addmm_default_61 = None
        view_default_174 = torch.ops.aten.view.default(view_default_173, [4, 512, 12, 64]);  view_default_173 = None
        permute_default_40 = torch.ops.aten.permute.default(view_default_174, [0, 2, 1, 3]);  view_default_174 = None
        view_default_175 = torch.ops.aten.view.default(getitem_57, [2048, 768])
        t_default_62 = torch.ops.aten.t.default(primals_26);  primals_26 = None
        addmm_default_62 = torch.ops.aten.addmm.default(primals_25, view_default_175, t_default_62);  primals_25 = None
        view_default_176 = torch.ops.aten.view.default(addmm_default_62, [4, 512, 768]);  addmm_default_62 = None
        view_default_177 = torch.ops.aten.view.default(view_default_176, [4, 512, 12, 64]);  view_default_176 = None
        permute_default_41 = torch.ops.aten.permute.default(view_default_177, [0, 2, 1, 3]);  view_default_177 = None
        view_default_178 = torch.ops.aten.view.default(view_default_171, [4, 512, 12, 64]);  view_default_171 = None
        permute_default_42 = torch.ops.aten.permute.default(view_default_178, [0, 2, 1, 3]);  view_default_178 = None
        transpose_int_10 = torch.ops.aten.transpose.int(permute_default_40, -1, -2);  permute_default_40 = None
        expand_default_40 = torch.ops.aten.expand.default(permute_default_42, [4, 12, 512, 64]);  permute_default_42 = None
        clone_default_40 = torch.ops.aten.clone.default(expand_default_40, memory_format = torch.contiguous_format);  expand_default_40 = None
        _unsafe_view_default_50 = torch.ops.aten._unsafe_view.default(clone_default_40, [48, 512, 64]);  clone_default_40 = None
        expand_default_41 = torch.ops.aten.expand.default(transpose_int_10, [4, 12, 64, 512]);  transpose_int_10 = None
        clone_default_41 = torch.ops.aten.clone.default(expand_default_41, memory_format = torch.contiguous_format);  expand_default_41 = None
        _unsafe_view_default_51 = torch.ops.aten._unsafe_view.default(clone_default_41, [48, 64, 512]);  clone_default_41 = None
        bmm_default_20 = torch.ops.aten.bmm.default(_unsafe_view_default_50, _unsafe_view_default_51)
        _unsafe_view_default_52 = torch.ops.aten._unsafe_view.default(bmm_default_20, [4, 12, 512, 512]);  bmm_default_20 = None
        div_tensor_10 = torch.ops.aten.div.Tensor(_unsafe_view_default_52, 8.0);  _unsafe_view_default_52 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(div_tensor_10, primals_194);  div_tensor_10 = None
        _softmax_default_10 = torch.ops.aten._softmax.default(add_tensor_30, -1, False);  add_tensor_30 = None
        expand_default_42 = torch.ops.aten.expand.default(_softmax_default_10, [4, 12, 512, 512])
        view_default_179 = torch.ops.aten.view.default(expand_default_42, [48, 512, 512]);  expand_default_42 = None
        expand_default_43 = torch.ops.aten.expand.default(permute_default_41, [4, 12, 512, 64]);  permute_default_41 = None
        clone_default_42 = torch.ops.aten.clone.default(expand_default_43, memory_format = torch.contiguous_format);  expand_default_43 = None
        _unsafe_view_default_53 = torch.ops.aten._unsafe_view.default(clone_default_42, [48, 512, 64]);  clone_default_42 = None
        bmm_default_21 = torch.ops.aten.bmm.default(view_default_179, _unsafe_view_default_53)
        _unsafe_view_default_54 = torch.ops.aten._unsafe_view.default(bmm_default_21, [4, 12, 512, 64]);  bmm_default_21 = None
        permute_default_43 = torch.ops.aten.permute.default(_unsafe_view_default_54, [0, 2, 1, 3]);  _unsafe_view_default_54 = None
        clone_default_43 = torch.ops.aten.clone.default(permute_default_43, memory_format = torch.contiguous_format);  permute_default_43 = None
        view_default_180 = torch.ops.aten.view.default(clone_default_43, [4, 512, 768]);  clone_default_43 = None
        view_default_181 = torch.ops.aten.view.default(view_default_180, [2048, 768]);  view_default_180 = None
        t_default_63 = torch.ops.aten.t.default(primals_20);  primals_20 = None
        addmm_default_63 = torch.ops.aten.addmm.default(primals_19, view_default_181, t_default_63);  primals_19 = None
        view_default_182 = torch.ops.aten.view.default(addmm_default_63, [4, 512, 768]);  addmm_default_63 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(view_default_182, getitem_57);  view_default_182 = getitem_57 = None
        native_layer_norm_default_20 = torch.ops.aten.native_layer_norm.default(add_tensor_31, [768], primals_18, primals_17, 1e-12)
        getitem_60 = native_layer_norm_default_20[0]
        getitem_61 = native_layer_norm_default_20[1]
        getitem_62 = native_layer_norm_default_20[2];  native_layer_norm_default_20 = None
        view_default_183 = torch.ops.aten.view.default(getitem_60, [2048, 768])
        t_default_64 = torch.ops.aten.t.default(primals_28);  primals_28 = None
        addmm_default_64 = torch.ops.aten.addmm.default(primals_27, view_default_183, t_default_64);  primals_27 = None
        view_default_184 = torch.ops.aten.view.default(addmm_default_64, [4, 512, 3072]);  addmm_default_64 = None
        gelu_default_10 = torch.ops.aten.gelu.default(view_default_184)
        view_default_185 = torch.ops.aten.view.default(gelu_default_10, [2048, 3072]);  gelu_default_10 = None
        t_default_65 = torch.ops.aten.t.default(primals_32);  primals_32 = None
        addmm_default_65 = torch.ops.aten.addmm.default(primals_31, view_default_185, t_default_65);  primals_31 = None
        view_default_186 = torch.ops.aten.view.default(addmm_default_65, [4, 512, 768]);  addmm_default_65 = None
        add_tensor_32 = torch.ops.aten.add.Tensor(view_default_186, getitem_60);  view_default_186 = getitem_60 = None
        native_layer_norm_default_21 = torch.ops.aten.native_layer_norm.default(add_tensor_32, [768], primals_30, primals_29, 1e-12)
        getitem_63 = native_layer_norm_default_21[0]
        getitem_64 = native_layer_norm_default_21[1]
        getitem_65 = native_layer_norm_default_21[2];  native_layer_norm_default_21 = None
        view_default_187 = torch.ops.aten.view.default(getitem_63, [2048, 768])
        t_default_66 = torch.ops.aten.t.default(primals_40);  primals_40 = None
        addmm_default_66 = torch.ops.aten.addmm.default(primals_39, view_default_187, t_default_66);  primals_39 = None
        view_default_188 = torch.ops.aten.view.default(addmm_default_66, [4, 512, 768]);  addmm_default_66 = None
        view_default_189 = torch.ops.aten.view.default(getitem_63, [2048, 768])
        t_default_67 = torch.ops.aten.t.default(primals_38);  primals_38 = None
        addmm_default_67 = torch.ops.aten.addmm.default(primals_37, view_default_189, t_default_67);  primals_37 = None
        view_default_190 = torch.ops.aten.view.default(addmm_default_67, [4, 512, 768]);  addmm_default_67 = None
        view_default_191 = torch.ops.aten.view.default(view_default_190, [4, 512, 12, 64]);  view_default_190 = None
        permute_default_44 = torch.ops.aten.permute.default(view_default_191, [0, 2, 1, 3]);  view_default_191 = None
        view_default_192 = torch.ops.aten.view.default(getitem_63, [2048, 768])
        t_default_68 = torch.ops.aten.t.default(primals_42);  primals_42 = None
        addmm_default_68 = torch.ops.aten.addmm.default(primals_41, view_default_192, t_default_68);  primals_41 = None
        view_default_193 = torch.ops.aten.view.default(addmm_default_68, [4, 512, 768]);  addmm_default_68 = None
        view_default_194 = torch.ops.aten.view.default(view_default_193, [4, 512, 12, 64]);  view_default_193 = None
        permute_default_45 = torch.ops.aten.permute.default(view_default_194, [0, 2, 1, 3]);  view_default_194 = None
        view_default_195 = torch.ops.aten.view.default(view_default_188, [4, 512, 12, 64]);  view_default_188 = None
        permute_default_46 = torch.ops.aten.permute.default(view_default_195, [0, 2, 1, 3]);  view_default_195 = None
        transpose_int_11 = torch.ops.aten.transpose.int(permute_default_44, -1, -2);  permute_default_44 = None
        expand_default_44 = torch.ops.aten.expand.default(permute_default_46, [4, 12, 512, 64]);  permute_default_46 = None
        clone_default_44 = torch.ops.aten.clone.default(expand_default_44, memory_format = torch.contiguous_format);  expand_default_44 = None
        _unsafe_view_default_55 = torch.ops.aten._unsafe_view.default(clone_default_44, [48, 512, 64]);  clone_default_44 = None
        expand_default_45 = torch.ops.aten.expand.default(transpose_int_11, [4, 12, 64, 512]);  transpose_int_11 = None
        clone_default_45 = torch.ops.aten.clone.default(expand_default_45, memory_format = torch.contiguous_format);  expand_default_45 = None
        _unsafe_view_default_56 = torch.ops.aten._unsafe_view.default(clone_default_45, [48, 64, 512]);  clone_default_45 = None
        bmm_default_22 = torch.ops.aten.bmm.default(_unsafe_view_default_55, _unsafe_view_default_56)
        _unsafe_view_default_57 = torch.ops.aten._unsafe_view.default(bmm_default_22, [4, 12, 512, 512]);  bmm_default_22 = None
        div_tensor_11 = torch.ops.aten.div.Tensor(_unsafe_view_default_57, 8.0);  _unsafe_view_default_57 = None
        add_tensor_33 = torch.ops.aten.add.Tensor(div_tensor_11, primals_194);  div_tensor_11 = primals_194 = None
        _softmax_default_11 = torch.ops.aten._softmax.default(add_tensor_33, -1, False);  add_tensor_33 = None
        expand_default_46 = torch.ops.aten.expand.default(_softmax_default_11, [4, 12, 512, 512])
        view_default_196 = torch.ops.aten.view.default(expand_default_46, [48, 512, 512]);  expand_default_46 = None
        expand_default_47 = torch.ops.aten.expand.default(permute_default_45, [4, 12, 512, 64]);  permute_default_45 = None
        clone_default_46 = torch.ops.aten.clone.default(expand_default_47, memory_format = torch.contiguous_format);  expand_default_47 = None
        _unsafe_view_default_58 = torch.ops.aten._unsafe_view.default(clone_default_46, [48, 512, 64]);  clone_default_46 = None
        bmm_default_23 = torch.ops.aten.bmm.default(view_default_196, _unsafe_view_default_58)
        _unsafe_view_default_59 = torch.ops.aten._unsafe_view.default(bmm_default_23, [4, 12, 512, 64]);  bmm_default_23 = None
        permute_default_47 = torch.ops.aten.permute.default(_unsafe_view_default_59, [0, 2, 1, 3]);  _unsafe_view_default_59 = None
        clone_default_47 = torch.ops.aten.clone.default(permute_default_47, memory_format = torch.contiguous_format);  permute_default_47 = None
        view_default_197 = torch.ops.aten.view.default(clone_default_47, [4, 512, 768]);  clone_default_47 = None
        view_default_198 = torch.ops.aten.view.default(view_default_197, [2048, 768]);  view_default_197 = None
        t_default_69 = torch.ops.aten.t.default(primals_36);  primals_36 = None
        addmm_default_69 = torch.ops.aten.addmm.default(primals_35, view_default_198, t_default_69);  primals_35 = None
        view_default_199 = torch.ops.aten.view.default(addmm_default_69, [4, 512, 768]);  addmm_default_69 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(view_default_199, getitem_63);  view_default_199 = getitem_63 = None
        native_layer_norm_default_22 = torch.ops.aten.native_layer_norm.default(add_tensor_34, [768], primals_34, primals_33, 1e-12)
        getitem_66 = native_layer_norm_default_22[0]
        getitem_67 = native_layer_norm_default_22[1]
        getitem_68 = native_layer_norm_default_22[2];  native_layer_norm_default_22 = None
        view_default_200 = torch.ops.aten.view.default(getitem_66, [2048, 768])
        t_default_70 = torch.ops.aten.t.default(primals_44);  primals_44 = None
        addmm_default_70 = torch.ops.aten.addmm.default(primals_43, view_default_200, t_default_70);  primals_43 = None
        view_default_201 = torch.ops.aten.view.default(addmm_default_70, [4, 512, 3072]);  addmm_default_70 = None
        gelu_default_11 = torch.ops.aten.gelu.default(view_default_201)
        view_default_202 = torch.ops.aten.view.default(gelu_default_11, [2048, 3072]);  gelu_default_11 = None
        t_default_71 = torch.ops.aten.t.default(primals_48);  primals_48 = None
        addmm_default_71 = torch.ops.aten.addmm.default(primals_47, view_default_202, t_default_71);  primals_47 = None
        view_default_203 = torch.ops.aten.view.default(addmm_default_71, [4, 512, 768]);  addmm_default_71 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(view_default_203, getitem_66);  view_default_203 = getitem_66 = None
        native_layer_norm_default_23 = torch.ops.aten.native_layer_norm.default(add_tensor_35, [768], primals_46, primals_45, 1e-12)
        getitem_69 = native_layer_norm_default_23[0]
        getitem_70 = native_layer_norm_default_23[1]
        getitem_71 = native_layer_norm_default_23[2];  native_layer_norm_default_23 = None
        return [getitem_69, t_default_25, _unsafe_view_default_23, primals_177, getitem_71, t_default_27, primals_98, view_default_162, getitem_58, view_default_170, t_default_71, view_default_60, t_default_45, primals_146, _unsafe_view_default_40, t_default_20, getitem_59, primals_158, _softmax_default_1, _unsafe_view_default_15, view_default_102, view_default_166, view_default_132, view_default_56, primals_94, primals_162, add_tensor_13, primals_178, view_default_79, _unsafe_view_default_48, t_default_60, getitem_70, t_default_6, t_default_7, t_default_19, _softmax_default_10, view_default_201, view_default_77, add_tensor_10, view_default_19, primals_173, add_tensor_23, getitem_44, t_default_57, view_default_175, t_default_46, primals_157, _unsafe_view_default_21, primals_161, view_default_141, _softmax_default_3, add_tensor_29, primals_93, _unsafe_view_default_20, t_default_61, add_tensor_28, view_default_164, getitem_43, primals_97, t_default_24, primals_174, view_default_70, view_default_192, getitem_56, primals_110, primals_114, primals_45, primals_126, t_default_32, _unsafe_view_default_25, getitem_55, primals_125, primals_46, view_default_94, primals_113, primals_109, add_tensor_16, primals_50, view_default_90, primals_49, view_default_111, view_default_51, _unsafe_view_default_43, _unsafe_view_default_33, view_default_134, t_default_50, add_tensor_26, view_default_133, view_default_53, _softmax_default_8, view_default_145, view_default_117, getitem_17, getitem_16, view_default_151, add_tensor_8, t_default_49, add_tensor_25, t_default_18, add_tensor_20, add_tensor_19, t_default_17, _unsafe_view_default_30, view_default_47, t_default, getitem_25, view_default_100, getitem_47, getitem_50, t_default_23, primals_130, view_default_2, primals_141, view_default_138, _unsafe_view_default_31, view_default_83, add_tensor_35, view_default_136, view_default_48, view_default_66, add_tensor_17, view_default_85, _unsafe_view_default_46, t_default_15, t_default_29, view_default_104, getitem_34, t_default_28, getitem_46, t_default_69, getitem_26, view_default_147, add_tensor_11, add_tensor_14, primals_129, getitem_14, t_default_16, t_default_47, view_default_49, t_default_35, getitem_49, view_default_81, _unsafe_view_default_41, view_default_149, t_default_51, view_default_82, view_default_65, getitem_67, primals_142, getitem_13, primals_145, view_default_124, t_default_36, t_default_48, view_default, t_default_52, view_default_45, view_default_200, t_default_70, getitem_35, getitem_7, t_default_66, getitem_10, t_default_68, view_default_36, t_default_55, view_default_15, primals_18, view_default_30, getitem_19, getitem_52, view_default_43, add_tensor_2, view_default_158, primals_14, t_default_59, primals_17, view_default_14, view_default_196, _unsafe_view_default_13, view_default_198, primals_13, _unsafe_view_default_10, view_default_167, t_default_9, view_default_64, add_tensor_34, getitem_53, t_default_58, t_default_12, t_default_4, view_default_62, _softmax_default_2, getitem_20, view_default_172, view_default_168, add_tensor_7, _unsafe_view_default_58, t_default_56, _unsafe_view_default_45, t_default_21, _unsafe_view_default_11, _softmax_default_9, getitem_11, t_default_13, t_default_54, view_default_28, t_default_14, t_default_5, view_default_153, view_default_39, t_default_22, _unsafe_view_default_51, view_default_130, _softmax_default_5, t_default_2, primals_2, getitem_5, getitem_29, t_default_44, t_default_39, view_default_5, getitem_23, view_default_87, _unsafe_view_default_38, view_default_128, view_default_11, view_default_9, view_default_68, view_default_113, view_default_115, add_tensor_22, t_default_43, getitem_4, getitem_28, primals_1, getitem_38, getitem_22, add_tensor_1, _softmax_default, t_default_30, t_default_1, view_default_17, t_default_31, getitem_37, t_default_62, _softmax_default_4, view_default_32, getitem_2, _unsafe_view_default_18, view_default_13, _unsafe_view_default_56, _unsafe_view_default_53, _unsafe_view_default_55, getitem_65, add_tensor_5, primals_34, _unsafe_view_default_50, primals_189, view_default_179, primals_33, primals_66, add_tensor_32, primals_30, view_default_183, primals_82, primals_77, view_default_181, primals_78, view_default_202, view_default_187, add_tensor_31, primals_190, view_default_185, primals_62, _softmax_default_11, primals_29, _unsafe_view_default, view_default_34, _unsafe_view_default_16, _unsafe_view_default_1, primals_65, _unsafe_view_default_3, primals_61, getitem_1, t_default_26, t_default_3, getitem_64, view_default_73, t_default_67, primals_81, t_default_11, getitem_68, _softmax_default_7, view_default_107, t_default_37, view_default_98, getitem_41, t_default_40, t_default_65, _unsafe_view_default_26, _softmax_default_6, view_default_121, getitem_8, t_default_42, view_default_96, getitem_31, view_default_150, _unsafe_view_default_8, view_default_116, view_default_26, view_default_31, t_default_10, view_default_99, _unsafe_view_default_28, _unsafe_view_default_6, _unsafe_view_default_5, getitem_40, view_default_189, t_default_53, getitem_62, view_default_184, _unsafe_view_default_36, t_default_63, t_default_8, t_default_41, t_default_64, _unsafe_view_default_35, t_default_38, view_default_22, getitem_32, getitem_61, view_default_155, add_tensor_4, view_default_119, t_default_33, t_default_34]
        
