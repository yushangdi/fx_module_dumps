
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/hf_Bert/hf_Bert_forward_2/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7):
        view_default = torch.ops.aten.view.default(primals_7, [2048, 768]);  primals_7 = None
        t_default = torch.ops.aten.t.default(primals_6);  primals_6 = None
        addmm_default = torch.ops.aten.addmm.default(primals_5, view_default, t_default);  primals_5 = None
        view_default_1 = torch.ops.aten.view.default(addmm_default, [4, 512, 768]);  addmm_default = None
        gelu_default = torch.ops.aten.gelu.default(view_default_1)
        native_layer_norm_default = torch.ops.aten.native_layer_norm.default(gelu_default, [768], primals_4, primals_3, 1e-12)
        getitem = native_layer_norm_default[0]
        getitem_1 = native_layer_norm_default[1]
        getitem_2 = native_layer_norm_default[2];  native_layer_norm_default = None
        view_default_2 = torch.ops.aten.view.default(getitem, [2048, 768]);  getitem = None
        t_default_1 = torch.ops.aten.t.default(primals_2);  primals_2 = None
        addmm_default_1 = torch.ops.aten.addmm.default(primals_1, view_default_2, t_default_1);  primals_1 = None
        view_default_3 = torch.ops.aten.view.default(addmm_default_1, [4, 512, 30522]);  addmm_default_1 = None
        return [view_default_3, gelu_default, t_default, view_default_1, getitem_2, view_default, getitem_1, primals_4, primals_3, view_default_2, t_default_1]
        
