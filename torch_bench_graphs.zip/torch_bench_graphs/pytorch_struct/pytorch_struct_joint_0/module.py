
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/pytorch_struct/pytorch_struct_joint_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, tangents_1, tangents_2, tangents_3):
        t_default = torch.ops.aten.t.default(primals_10);  primals_10 = None
        addmm_default = torch.ops.aten.addmm.default(primals_9, primals_25, t_default);  primals_9 = None
        t_default_1 = torch.ops.aten.t.default(primals_2);  primals_2 = None
        addmm_default_1 = torch.ops.aten.addmm.default(primals_1, addmm_default, t_default_1);  primals_1 = None
        relu_default = torch.ops.aten.relu.default(addmm_default_1);  addmm_default_1 = None
        t_default_2 = torch.ops.aten.t.default(primals_6);  primals_6 = None
        addmm_default_2 = torch.ops.aten.addmm.default(primals_5, relu_default, t_default_2);  primals_5 = None
        relu_default_1 = torch.ops.aten.relu.default(addmm_default_2);  addmm_default_2 = None
        add_tensor = torch.ops.aten.add.Tensor(addmm_default, relu_default_1)
        t_default_3 = torch.ops.aten.t.default(primals_4);  primals_4 = None
        addmm_default_3 = torch.ops.aten.addmm.default(primals_3, add_tensor, t_default_3);  primals_3 = None
        relu_default_2 = torch.ops.aten.relu.default(addmm_default_3);  addmm_default_3 = None
        t_default_4 = torch.ops.aten.t.default(primals_8);  primals_8 = None
        addmm_default_4 = torch.ops.aten.addmm.default(primals_7, relu_default_2, t_default_4);  primals_7 = None
        relu_default_3 = torch.ops.aten.relu.default(addmm_default_4);  addmm_default_4 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(add_tensor, relu_default_3)
        unsqueeze_default = torch.ops.aten.unsqueeze.default(primals_26, -1);  primals_26 = None
        permute_default = torch.ops.aten.permute.default(unsqueeze_default, [2, 0, 1]);  unsqueeze_default = None
        unsqueeze_default_1 = torch.ops.aten.unsqueeze.default(add_tensor_1, -1);  add_tensor_1 = None
        permute_default_1 = torch.ops.aten.permute.default(unsqueeze_default_1, [0, 2, 1]);  unsqueeze_default_1 = None
        permute_default_2 = torch.ops.aten.permute.default(permute_default, [1, 2, 0]);  permute_default = None
        view_default = torch.ops.aten.view.default(permute_default_2, [1, 4771, 256]);  permute_default_2 = None
        permute_default_3 = torch.ops.aten.permute.default(permute_default_1, [2, 0, 1]);  permute_default_1 = None
        view_default_1 = torch.ops.aten.view.default(permute_default_3, [1, 256, 30]);  permute_default_3 = None
        bmm_default = torch.ops.aten.bmm.default(view_default, view_default_1)
        view_default_2 = torch.ops.aten.view.default(bmm_default, [4771, 1, 30]);  bmm_default = None
        permute_default_4 = torch.ops.aten.permute.default(view_default_2, [2, 0, 1]);  view_default_2 = None
        view_default_3 = torch.ops.aten.view.default(permute_default_4, [30, 4771]);  permute_default_4 = None
        _log_softmax_default = torch.ops.aten._log_softmax.default(view_default_3, -1, False);  view_default_3 = None
        unsqueeze_default_2 = torch.ops.aten.unsqueeze.default(_log_softmax_default, 0)
        unsqueeze_default_3 = torch.ops.aten.unsqueeze.default(unsqueeze_default_2, 0);  unsqueeze_default_2 = None
        expand_sym_int = torch.ops.aten.expand.SymInt(unsqueeze_default_3, [40, 29, 30, 4771]);  unsqueeze_default_3 = None
        unsqueeze_default_4 = torch.ops.aten.unsqueeze.default(primals_27, 2);  primals_27 = None
        expand_sym_int_1 = torch.ops.aten.expand.SymInt(unsqueeze_default_4, [40, 29, 30]);  unsqueeze_default_4 = None
        unsqueeze_default_5 = torch.ops.aten.unsqueeze.default(expand_sym_int_1, 3);  expand_sym_int_1 = None
        gather_default = torch.ops.aten.gather.default(expand_sym_int, 3, unsqueeze_default_5);  expand_sym_int = None
        squeeze_dim = torch.ops.aten.squeeze.dim(gather_default, 3);  gather_default = None
        unsqueeze_default_6 = torch.ops.aten.unsqueeze.default(primals_21, -1);  primals_21 = None
        unsqueeze_default_7 = torch.ops.aten.unsqueeze.default(unsqueeze_default_6, -1);  unsqueeze_default_6 = None
        permute_default_5 = torch.ops.aten.permute.default(unsqueeze_default_7, [0, 2, 3, 1]);  unsqueeze_default_7 = None
        unsqueeze_default_8 = torch.ops.aten.unsqueeze.default(primals_22, -1);  primals_22 = None
        permute_default_6 = torch.ops.aten.permute.default(unsqueeze_default_8, [3, 0, 1, 2]);  unsqueeze_default_8 = None
        permute_default_7 = torch.ops.aten.permute.default(permute_default_5, [0, 3, 1, 2]);  permute_default_5 = None
        view_default_4 = torch.ops.aten.view.default(permute_default_7, [1, 30, 256]);  permute_default_7 = None
        permute_default_8 = torch.ops.aten.permute.default(permute_default_6, [3, 1, 2, 0]);  permute_default_6 = None
        view_default_5 = torch.ops.aten.view.default(permute_default_8, [1, 256, 3600]);  permute_default_8 = None
        bmm_default_1 = torch.ops.aten.bmm.default(view_default_4, view_default_5)
        view_default_6 = torch.ops.aten.view.default(bmm_default_1, [30, 1, 60, 60]);  bmm_default_1 = None
        permute_default_9 = torch.ops.aten.permute.default(view_default_6, [0, 2, 3, 1]);  view_default_6 = None
        view_default_7 = torch.ops.aten.view.default(permute_default_9, [30, 60, 60]);  permute_default_9 = None
        view_default_8 = torch.ops.aten.view.default(view_default_7, [30, -1]);  view_default_7 = None
        _log_softmax_default_1 = torch.ops.aten._log_softmax.default(view_default_8, -1, False);  view_default_8 = None
        view_default_9 = torch.ops.aten.view.default(_log_softmax_default_1, [1, 30, 60, 60])
        expand_sym_int_2 = torch.ops.aten.expand.SymInt(view_default_9, [40, 30, 60, 60]);  view_default_9 = None
        t_default_5 = torch.ops.aten.t.default(primals_20);  primals_20 = None
        addmm_default_5 = torch.ops.aten.addmm.default(primals_19, primals_23, t_default_5);  primals_19 = None
        t_default_6 = torch.ops.aten.t.default(primals_12);  primals_12 = None
        addmm_default_6 = torch.ops.aten.addmm.default(primals_11, addmm_default_5, t_default_6);  primals_11 = None
        relu_default_4 = torch.ops.aten.relu.default(addmm_default_6);  addmm_default_6 = None
        t_default_7 = torch.ops.aten.t.default(primals_16);  primals_16 = None
        addmm_default_7 = torch.ops.aten.addmm.default(primals_15, relu_default_4, t_default_7);  primals_15 = None
        relu_default_5 = torch.ops.aten.relu.default(addmm_default_7);  addmm_default_7 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(addmm_default_5, relu_default_5)
        t_default_8 = torch.ops.aten.t.default(primals_14);  primals_14 = None
        addmm_default_8 = torch.ops.aten.addmm.default(primals_13, add_tensor_2, t_default_8);  primals_13 = None
        relu_default_6 = torch.ops.aten.relu.default(addmm_default_8);  addmm_default_8 = None
        t_default_9 = torch.ops.aten.t.default(primals_18);  primals_18 = None
        addmm_default_9 = torch.ops.aten.addmm.default(primals_17, relu_default_6, t_default_9);  primals_17 = None
        relu_default_7 = torch.ops.aten.relu.default(addmm_default_9);  addmm_default_9 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(add_tensor_2, relu_default_7)
        unsqueeze_default_9 = torch.ops.aten.unsqueeze.default(primals_24, -1);  primals_24 = None
        permute_default_10 = torch.ops.aten.permute.default(unsqueeze_default_9, [2, 0, 1]);  unsqueeze_default_9 = None
        unsqueeze_default_10 = torch.ops.aten.unsqueeze.default(add_tensor_3, -1);  add_tensor_3 = None
        permute_default_11 = torch.ops.aten.permute.default(unsqueeze_default_10, [0, 2, 1]);  unsqueeze_default_10 = None
        squeeze_dim_1 = torch.ops.aten.squeeze.dim(permute_default_10, 1);  permute_default_10 = None
        squeeze_dim_2 = torch.ops.aten.squeeze.dim(permute_default_11, 1);  permute_default_11 = None
        permute_default_12 = torch.ops.aten.permute.default(squeeze_dim_1, [1, 0]);  squeeze_dim_1 = None
        view_default_10 = torch.ops.aten.view.default(permute_default_12, [1, 1, 256]);  permute_default_12 = None
        permute_default_13 = torch.ops.aten.permute.default(squeeze_dim_2, [1, 0]);  squeeze_dim_2 = None
        view_default_11 = torch.ops.aten.view.default(permute_default_13, [1, 256, 30]);  permute_default_13 = None
        bmm_default_2 = torch.ops.aten.bmm.default(view_default_10, view_default_11)
        view_default_12 = torch.ops.aten.view.default(bmm_default_2, [1, 30]);  bmm_default_2 = None
        permute_default_14 = torch.ops.aten.permute.default(view_default_12, [1, 0]);  view_default_12 = None
        view_default_13 = torch.ops.aten.view.default(permute_default_14, [30]);  permute_default_14 = None
        _log_softmax_default_2 = torch.ops.aten._log_softmax.default(view_default_13, -1, False);  view_default_13 = None
        view_default_14 = torch.ops.aten.view.default(_log_softmax_default_2, [1, 30])
        expand_sym_int_3 = torch.ops.aten.expand.SymInt(view_default_14, [40, 30]);  view_default_14 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(squeeze_dim, tangents_1)
        is_same_size_default_1 = torch.ops.aten.is_same_size.default(expand_sym_int_2, tangents_2)
        is_same_size_default_2 = torch.ops.aten.is_same_size.default(expand_sym_int_3, tangents_3)
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_3, [0], True);  tangents_3 = None
        view_default_15 = torch.ops.aten.view.default(sum_dim_int_list, [30]);  sum_dim_int_list = None
        _log_softmax_backward_data_default = torch.ops.aten._log_softmax_backward_data.default(view_default_15, _log_softmax_default_2, -1, torch.float32);  view_default_15 = _log_softmax_default_2 = None
        view_default_16 = torch.ops.aten.view.default(_log_softmax_backward_data_default, [30, 1]);  _log_softmax_backward_data_default = None
        permute_default_15 = torch.ops.aten.permute.default(view_default_16, [1, 0]);  view_default_16 = None
        view_default_17 = torch.ops.aten.view.default(permute_default_15, [1, 1, 30]);  permute_default_15 = None
        transpose_int = torch.ops.aten.transpose.int(view_default_10, 1, 2);  view_default_10 = None
        bmm_default_3 = torch.ops.aten.bmm.default(transpose_int, view_default_17);  transpose_int = None
        transpose_int_1 = torch.ops.aten.transpose.int(view_default_11, 1, 2);  view_default_11 = None
        bmm_default_4 = torch.ops.aten.bmm.default(view_default_17, transpose_int_1);  view_default_17 = transpose_int_1 = None
        view_default_18 = torch.ops.aten.view.default(bmm_default_3, [256, 30]);  bmm_default_3 = None
        permute_default_16 = torch.ops.aten.permute.default(view_default_18, [1, 0]);  view_default_18 = None
        view_default_19 = torch.ops.aten.view.default(bmm_default_4, [256, 1]);  bmm_default_4 = None
        permute_default_17 = torch.ops.aten.permute.default(view_default_19, [1, 0]);  view_default_19 = None
        unsqueeze_default_11 = torch.ops.aten.unsqueeze.default(permute_default_16, 1);  permute_default_16 = None
        unsqueeze_default_12 = torch.ops.aten.unsqueeze.default(permute_default_17, 1);  permute_default_17 = None
        permute_default_18 = torch.ops.aten.permute.default(unsqueeze_default_11, [0, 2, 1]);  unsqueeze_default_11 = None
        squeeze_dim_3 = torch.ops.aten.squeeze.dim(permute_default_18, -1);  permute_default_18 = None
        permute_default_19 = torch.ops.aten.permute.default(unsqueeze_default_12, [1, 2, 0]);  unsqueeze_default_12 = None
        squeeze_dim_4 = torch.ops.aten.squeeze.dim(permute_default_19, -1);  permute_default_19 = None
        to_dtype = torch.ops.aten.to.dtype(squeeze_dim_3, torch.float32)
        to_dtype_1 = torch.ops.aten.to.dtype(relu_default_7, torch.float32);  relu_default_7 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default, to_dtype);  le_scalar = new_zeros_default = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        t_default_10 = torch.ops.aten.t.default(t_default_9);  t_default_9 = None
        mm_default = torch.ops.aten.mm.default(to_dtype_2, t_default_10);  t_default_10 = None
        t_default_11 = torch.ops.aten.t.default(to_dtype_2)
        mm_default_1 = torch.ops.aten.mm.default(t_default_11, relu_default_6);  t_default_11 = None
        t_default_12 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(to_dtype_2, [0], True);  to_dtype_2 = None
        view_default_20 = torch.ops.aten.view.default(sum_dim_int_list_1, [256]);  sum_dim_int_list_1 = None
        t_default_13 = torch.ops.aten.t.default(t_default_12);  t_default_12 = None
        to_dtype_3 = torch.ops.aten.to.dtype(mm_default, torch.float32);  mm_default = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu_default_6, torch.float32);  relu_default_6 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_1, to_dtype_3);  le_scalar_1 = new_zeros_default_1 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        t_default_14 = torch.ops.aten.t.default(t_default_8);  t_default_8 = None
        mm_default_2 = torch.ops.aten.mm.default(to_dtype_5, t_default_14);  t_default_14 = None
        t_default_15 = torch.ops.aten.t.default(to_dtype_5)
        mm_default_3 = torch.ops.aten.mm.default(t_default_15, add_tensor_2);  t_default_15 = add_tensor_2 = None
        t_default_16 = torch.ops.aten.t.default(mm_default_3);  mm_default_3 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(to_dtype_5, [0], True);  to_dtype_5 = None
        view_default_21 = torch.ops.aten.view.default(sum_dim_int_list_2, [256]);  sum_dim_int_list_2 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(squeeze_dim_3, mm_default_2);  squeeze_dim_3 = mm_default_2 = None
        t_default_17 = torch.ops.aten.t.default(t_default_16);  t_default_16 = None
        to_dtype_6 = torch.ops.aten.to.dtype(add_tensor_4, torch.float32)
        to_dtype_7 = torch.ops.aten.to.dtype(relu_default_5, torch.float32);  relu_default_5 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_2 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_2, to_dtype_6);  le_scalar_2 = new_zeros_default_2 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        t_default_18 = torch.ops.aten.t.default(t_default_7);  t_default_7 = None
        mm_default_4 = torch.ops.aten.mm.default(to_dtype_8, t_default_18);  t_default_18 = None
        t_default_19 = torch.ops.aten.t.default(to_dtype_8)
        mm_default_5 = torch.ops.aten.mm.default(t_default_19, relu_default_4);  t_default_19 = None
        t_default_20 = torch.ops.aten.t.default(mm_default_5);  mm_default_5 = None
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(to_dtype_8, [0], True);  to_dtype_8 = None
        view_default_22 = torch.ops.aten.view.default(sum_dim_int_list_3, [256]);  sum_dim_int_list_3 = None
        t_default_21 = torch.ops.aten.t.default(t_default_20);  t_default_20 = None
        to_dtype_9 = torch.ops.aten.to.dtype(mm_default_4, torch.float32);  mm_default_4 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu_default_4, torch.float32);  relu_default_4 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_3, to_dtype_9);  le_scalar_3 = new_zeros_default_3 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        t_default_22 = torch.ops.aten.t.default(t_default_6);  t_default_6 = None
        mm_default_6 = torch.ops.aten.mm.default(to_dtype_11, t_default_22);  t_default_22 = None
        t_default_23 = torch.ops.aten.t.default(to_dtype_11)
        mm_default_7 = torch.ops.aten.mm.default(t_default_23, addmm_default_5);  t_default_23 = addmm_default_5 = None
        t_default_24 = torch.ops.aten.t.default(mm_default_7);  mm_default_7 = None
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(to_dtype_11, [0], True);  to_dtype_11 = None
        view_default_23 = torch.ops.aten.view.default(sum_dim_int_list_4, [256]);  sum_dim_int_list_4 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(add_tensor_4, mm_default_6);  add_tensor_4 = mm_default_6 = None
        t_default_25 = torch.ops.aten.t.default(t_default_24);  t_default_24 = None
        t_default_26 = torch.ops.aten.t.default(t_default_5);  t_default_5 = None
        mm_default_8 = torch.ops.aten.mm.default(add_tensor_5, t_default_26);  t_default_26 = None
        t_default_27 = torch.ops.aten.t.default(add_tensor_5)
        mm_default_9 = torch.ops.aten.mm.default(t_default_27, primals_23);  t_default_27 = primals_23 = None
        t_default_28 = torch.ops.aten.t.default(mm_default_9);  mm_default_9 = None
        sum_dim_int_list_5 = torch.ops.aten.sum.dim_IntList(add_tensor_5, [0], True);  add_tensor_5 = None
        view_default_24 = torch.ops.aten.view.default(sum_dim_int_list_5, [256]);  sum_dim_int_list_5 = None
        t_default_29 = torch.ops.aten.t.default(t_default_28);  t_default_28 = None
        sum_dim_int_list_6 = torch.ops.aten.sum.dim_IntList(tangents_2, [0], True);  tangents_2 = None
        view_default_25 = torch.ops.aten.view.default(sum_dim_int_list_6, [30, 3600]);  sum_dim_int_list_6 = None
        _log_softmax_backward_data_default_1 = torch.ops.aten._log_softmax_backward_data.default(view_default_25, _log_softmax_default_1, -1, torch.float32);  view_default_25 = _log_softmax_default_1 = None
        view_default_26 = torch.ops.aten.view.default(_log_softmax_backward_data_default_1, [30, 60, 60]);  _log_softmax_backward_data_default_1 = None
        view_default_27 = torch.ops.aten.view.default(view_default_26, [30, 60, 60, 1]);  view_default_26 = None
        permute_default_20 = torch.ops.aten.permute.default(view_default_27, [0, 3, 1, 2]);  view_default_27 = None
        view_default_28 = torch.ops.aten.view.default(permute_default_20, [1, 30, 3600]);  permute_default_20 = None
        transpose_int_2 = torch.ops.aten.transpose.int(view_default_4, 1, 2);  view_default_4 = None
        bmm_default_5 = torch.ops.aten.bmm.default(transpose_int_2, view_default_28);  transpose_int_2 = None
        transpose_int_3 = torch.ops.aten.transpose.int(view_default_5, 1, 2);  view_default_5 = None
        bmm_default_6 = torch.ops.aten.bmm.default(view_default_28, transpose_int_3);  view_default_28 = transpose_int_3 = None
        view_default_29 = torch.ops.aten.view.default(bmm_default_5, [256, 60, 60, 1]);  bmm_default_5 = None
        permute_default_21 = torch.ops.aten.permute.default(view_default_29, [3, 1, 2, 0]);  view_default_29 = None
        view_default_30 = torch.ops.aten.view.default(bmm_default_6, [30, 256, 1, 1]);  bmm_default_6 = None
        permute_default_22 = torch.ops.aten.permute.default(view_default_30, [0, 2, 3, 1]);  view_default_30 = None
        permute_default_23 = torch.ops.aten.permute.default(permute_default_21, [1, 2, 3, 0]);  permute_default_21 = None
        squeeze_dim_5 = torch.ops.aten.squeeze.dim(permute_default_23, -1);  permute_default_23 = None
        permute_default_24 = torch.ops.aten.permute.default(permute_default_22, [0, 3, 1, 2]);  permute_default_22 = None
        squeeze_dim_6 = torch.ops.aten.squeeze.dim(permute_default_24, -1);  permute_default_24 = None
        squeeze_dim_7 = torch.ops.aten.squeeze.dim(squeeze_dim_6, -1);  squeeze_dim_6 = None
        unsqueeze_default_13 = torch.ops.aten.unsqueeze.default(tangents_1, 3);  tangents_1 = None
        new_empty_default = torch.ops.aten.new_empty.default(unsqueeze_default_13, [40, 29, 30, 4771])
        zero__default = torch.ops.aten.zero_.default(new_empty_default);  new_empty_default = None
        scatter_add_default = torch.ops.aten.scatter_add.default(zero__default, 3, unsqueeze_default_5, unsqueeze_default_13);  zero__default = unsqueeze_default_5 = unsqueeze_default_13 = None
        sum_dim_int_list_7 = torch.ops.aten.sum.dim_IntList(scatter_add_default, [0, 1], True);  scatter_add_default = None
        squeeze_dim_8 = torch.ops.aten.squeeze.dim(sum_dim_int_list_7, 0);  sum_dim_int_list_7 = None
        squeeze_dim_9 = torch.ops.aten.squeeze.dim(squeeze_dim_8, 0);  squeeze_dim_8 = None
        _log_softmax_backward_data_default_2 = torch.ops.aten._log_softmax_backward_data.default(squeeze_dim_9, _log_softmax_default, -1, torch.float32);  squeeze_dim_9 = _log_softmax_default = None
        view_default_31 = torch.ops.aten.view.default(_log_softmax_backward_data_default_2, [30, 4771, 1]);  _log_softmax_backward_data_default_2 = None
        permute_default_25 = torch.ops.aten.permute.default(view_default_31, [1, 2, 0]);  view_default_31 = None
        view_default_32 = torch.ops.aten.view.default(permute_default_25, [1, 4771, 30]);  permute_default_25 = None
        transpose_int_4 = torch.ops.aten.transpose.int(view_default, 1, 2);  view_default = None
        bmm_default_7 = torch.ops.aten.bmm.default(transpose_int_4, view_default_32);  transpose_int_4 = None
        transpose_int_5 = torch.ops.aten.transpose.int(view_default_1, 1, 2);  view_default_1 = None
        bmm_default_8 = torch.ops.aten.bmm.default(view_default_32, transpose_int_5);  view_default_32 = transpose_int_5 = None
        view_default_33 = torch.ops.aten.view.default(bmm_default_7, [256, 30, 1]);  bmm_default_7 = None
        permute_default_26 = torch.ops.aten.permute.default(view_default_33, [1, 2, 0]);  view_default_33 = None
        view_default_34 = torch.ops.aten.view.default(bmm_default_8, [4771, 256, 1]);  bmm_default_8 = None
        permute_default_27 = torch.ops.aten.permute.default(view_default_34, [2, 0, 1]);  view_default_34 = None
        permute_default_28 = torch.ops.aten.permute.default(permute_default_26, [0, 2, 1]);  permute_default_26 = None
        squeeze_dim_10 = torch.ops.aten.squeeze.dim(permute_default_28, -1);  permute_default_28 = None
        permute_default_29 = torch.ops.aten.permute.default(permute_default_27, [1, 2, 0]);  permute_default_27 = None
        squeeze_dim_11 = torch.ops.aten.squeeze.dim(permute_default_29, -1);  permute_default_29 = None
        to_dtype_12 = torch.ops.aten.to.dtype(squeeze_dim_10, torch.float32)
        to_dtype_13 = torch.ops.aten.to.dtype(relu_default_3, torch.float32);  relu_default_3 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_4, to_dtype_12);  le_scalar_4 = new_zeros_default_4 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        t_default_30 = torch.ops.aten.t.default(t_default_4);  t_default_4 = None
        mm_default_10 = torch.ops.aten.mm.default(to_dtype_14, t_default_30);  t_default_30 = None
        t_default_31 = torch.ops.aten.t.default(to_dtype_14)
        mm_default_11 = torch.ops.aten.mm.default(t_default_31, relu_default_2);  t_default_31 = None
        t_default_32 = torch.ops.aten.t.default(mm_default_11);  mm_default_11 = None
        sum_dim_int_list_8 = torch.ops.aten.sum.dim_IntList(to_dtype_14, [0], True);  to_dtype_14 = None
        view_default_35 = torch.ops.aten.view.default(sum_dim_int_list_8, [256]);  sum_dim_int_list_8 = None
        t_default_33 = torch.ops.aten.t.default(t_default_32);  t_default_32 = None
        to_dtype_15 = torch.ops.aten.to.dtype(mm_default_10, torch.float32);  mm_default_10 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu_default_2, torch.float32);  relu_default_2 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_5 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_5, to_dtype_15);  le_scalar_5 = new_zeros_default_5 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        t_default_34 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        mm_default_12 = torch.ops.aten.mm.default(to_dtype_17, t_default_34);  t_default_34 = None
        t_default_35 = torch.ops.aten.t.default(to_dtype_17)
        mm_default_13 = torch.ops.aten.mm.default(t_default_35, add_tensor);  t_default_35 = add_tensor = None
        t_default_36 = torch.ops.aten.t.default(mm_default_13);  mm_default_13 = None
        sum_dim_int_list_9 = torch.ops.aten.sum.dim_IntList(to_dtype_17, [0], True);  to_dtype_17 = None
        view_default_36 = torch.ops.aten.view.default(sum_dim_int_list_9, [256]);  sum_dim_int_list_9 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(squeeze_dim_10, mm_default_12);  squeeze_dim_10 = mm_default_12 = None
        t_default_37 = torch.ops.aten.t.default(t_default_36);  t_default_36 = None
        to_dtype_18 = torch.ops.aten.to.dtype(add_tensor_6, torch.float32)
        to_dtype_19 = torch.ops.aten.to.dtype(relu_default_1, torch.float32);  relu_default_1 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_6, to_dtype_18);  le_scalar_6 = new_zeros_default_6 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        t_default_38 = torch.ops.aten.t.default(t_default_2);  t_default_2 = None
        mm_default_14 = torch.ops.aten.mm.default(to_dtype_20, t_default_38);  t_default_38 = None
        t_default_39 = torch.ops.aten.t.default(to_dtype_20)
        mm_default_15 = torch.ops.aten.mm.default(t_default_39, relu_default);  t_default_39 = None
        t_default_40 = torch.ops.aten.t.default(mm_default_15);  mm_default_15 = None
        sum_dim_int_list_10 = torch.ops.aten.sum.dim_IntList(to_dtype_20, [0], True);  to_dtype_20 = None
        view_default_37 = torch.ops.aten.view.default(sum_dim_int_list_10, [256]);  sum_dim_int_list_10 = None
        t_default_41 = torch.ops.aten.t.default(t_default_40);  t_default_40 = None
        to_dtype_21 = torch.ops.aten.to.dtype(mm_default_14, torch.float32);  mm_default_14 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu_default, torch.float32);  relu_default = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_7, to_dtype_21);  le_scalar_7 = new_zeros_default_7 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        t_default_42 = torch.ops.aten.t.default(t_default_1);  t_default_1 = None
        mm_default_16 = torch.ops.aten.mm.default(to_dtype_23, t_default_42);  t_default_42 = None
        t_default_43 = torch.ops.aten.t.default(to_dtype_23)
        mm_default_17 = torch.ops.aten.mm.default(t_default_43, addmm_default);  t_default_43 = addmm_default = None
        t_default_44 = torch.ops.aten.t.default(mm_default_17);  mm_default_17 = None
        sum_dim_int_list_11 = torch.ops.aten.sum.dim_IntList(to_dtype_23, [0], True);  to_dtype_23 = None
        view_default_38 = torch.ops.aten.view.default(sum_dim_int_list_11, [256]);  sum_dim_int_list_11 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(add_tensor_6, mm_default_16);  add_tensor_6 = mm_default_16 = None
        t_default_45 = torch.ops.aten.t.default(t_default_44);  t_default_44 = None
        t_default_46 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default_18 = torch.ops.aten.mm.default(add_tensor_7, t_default_46);  t_default_46 = None
        t_default_47 = torch.ops.aten.t.default(add_tensor_7)
        mm_default_19 = torch.ops.aten.mm.default(t_default_47, primals_25);  t_default_47 = primals_25 = None
        t_default_48 = torch.ops.aten.t.default(mm_default_19);  mm_default_19 = None
        sum_dim_int_list_12 = torch.ops.aten.sum.dim_IntList(add_tensor_7, [0], True);  add_tensor_7 = None
        view_default_39 = torch.ops.aten.view.default(sum_dim_int_list_12, [256]);  sum_dim_int_list_12 = None
        t_default_49 = torch.ops.aten.t.default(t_default_48);  t_default_48 = None
        return [squeeze_dim, expand_sym_int_2, expand_sym_int_3, view_default_38, t_default_45, view_default_36, t_default_37, view_default_37, t_default_41, view_default_35, t_default_33, view_default_39, t_default_49, view_default_23, t_default_25, view_default_21, t_default_17, view_default_22, t_default_21, view_default_20, t_default_13, view_default_24, t_default_29, squeeze_dim_7, squeeze_dim_5, mm_default_8, squeeze_dim_4, mm_default_18, squeeze_dim_11, None]
        
