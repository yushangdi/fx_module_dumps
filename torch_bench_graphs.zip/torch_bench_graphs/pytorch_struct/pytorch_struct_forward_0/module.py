
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/pytorch_struct/pytorch_struct_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27):
        t_default = torch.ops.aten.t.default(primals_10);  primals_10 = None
        addmm_default = torch.ops.aten.addmm.default(primals_9, primals_25, t_default);  primals_9 = None
        t_default_1 = torch.ops.aten.t.default(primals_2);  primals_2 = None
        addmm_default_1 = torch.ops.aten.addmm.default(primals_1, addmm_default, t_default_1);  primals_1 = None
        relu_default = torch.ops.aten.relu.default(addmm_default_1);  addmm_default_1 = None
        t_default_2 = torch.ops.aten.t.default(primals_6);  primals_6 = None
        addmm_default_2 = torch.ops.aten.addmm.default(primals_5, relu_default, t_default_2);  primals_5 = None
        relu_default_1 = torch.ops.aten.relu.default(addmm_default_2);  addmm_default_2 = None
        add_tensor = torch.ops.aten.add.Tensor(addmm_default, relu_default_1)
        t_default_3 = torch.ops.aten.t.default(primals_4);  primals_4 = None
        addmm_default_3 = torch.ops.aten.addmm.default(primals_3, add_tensor, t_default_3);  primals_3 = None
        relu_default_2 = torch.ops.aten.relu.default(addmm_default_3);  addmm_default_3 = None
        t_default_4 = torch.ops.aten.t.default(primals_8);  primals_8 = None
        addmm_default_4 = torch.ops.aten.addmm.default(primals_7, relu_default_2, t_default_4);  primals_7 = None
        relu_default_3 = torch.ops.aten.relu.default(addmm_default_4);  addmm_default_4 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(add_tensor, relu_default_3)
        unsqueeze_default = torch.ops.aten.unsqueeze.default(primals_26, -1);  primals_26 = None
        permute_default = torch.ops.aten.permute.default(unsqueeze_default, [2, 0, 1]);  unsqueeze_default = None
        unsqueeze_default_1 = torch.ops.aten.unsqueeze.default(add_tensor_1, -1);  add_tensor_1 = None
        permute_default_1 = torch.ops.aten.permute.default(unsqueeze_default_1, [0, 2, 1]);  unsqueeze_default_1 = None
        permute_default_2 = torch.ops.aten.permute.default(permute_default, [1, 2, 0]);  permute_default = None
        view_default = torch.ops.aten.view.default(permute_default_2, [1, 4771, 256]);  permute_default_2 = None
        permute_default_3 = torch.ops.aten.permute.default(permute_default_1, [2, 0, 1]);  permute_default_1 = None
        view_default_1 = torch.ops.aten.view.default(permute_default_3, [1, 256, 30]);  permute_default_3 = None
        bmm_default = torch.ops.aten.bmm.default(view_default, view_default_1)
        view_default_2 = torch.ops.aten.view.default(bmm_default, [4771, 1, 30]);  bmm_default = None
        permute_default_4 = torch.ops.aten.permute.default(view_default_2, [2, 0, 1]);  view_default_2 = None
        view_default_3 = torch.ops.aten.view.default(permute_default_4, [30, 4771]);  permute_default_4 = None
        _log_softmax_default = torch.ops.aten._log_softmax.default(view_default_3, -1, False);  view_default_3 = None
        unsqueeze_default_2 = torch.ops.aten.unsqueeze.default(_log_softmax_default, 0)
        unsqueeze_default_3 = torch.ops.aten.unsqueeze.default(unsqueeze_default_2, 0);  unsqueeze_default_2 = None
        expand_sym_int = torch.ops.aten.expand.SymInt(unsqueeze_default_3, [40, 29, 30, 4771]);  unsqueeze_default_3 = None
        unsqueeze_default_4 = torch.ops.aten.unsqueeze.default(primals_27, 2);  primals_27 = None
        expand_sym_int_1 = torch.ops.aten.expand.SymInt(unsqueeze_default_4, [40, 29, 30]);  unsqueeze_default_4 = None
        unsqueeze_default_5 = torch.ops.aten.unsqueeze.default(expand_sym_int_1, 3);  expand_sym_int_1 = None
        gather_default = torch.ops.aten.gather.default(expand_sym_int, 3, unsqueeze_default_5);  expand_sym_int = None
        squeeze_dim = torch.ops.aten.squeeze.dim(gather_default, 3);  gather_default = None
        unsqueeze_default_6 = torch.ops.aten.unsqueeze.default(primals_21, -1);  primals_21 = None
        unsqueeze_default_7 = torch.ops.aten.unsqueeze.default(unsqueeze_default_6, -1);  unsqueeze_default_6 = None
        permute_default_5 = torch.ops.aten.permute.default(unsqueeze_default_7, [0, 2, 3, 1]);  unsqueeze_default_7 = None
        unsqueeze_default_8 = torch.ops.aten.unsqueeze.default(primals_22, -1);  primals_22 = None
        permute_default_6 = torch.ops.aten.permute.default(unsqueeze_default_8, [3, 0, 1, 2]);  unsqueeze_default_8 = None
        permute_default_7 = torch.ops.aten.permute.default(permute_default_5, [0, 3, 1, 2]);  permute_default_5 = None
        view_default_4 = torch.ops.aten.view.default(permute_default_7, [1, 30, 256]);  permute_default_7 = None
        permute_default_8 = torch.ops.aten.permute.default(permute_default_6, [3, 1, 2, 0]);  permute_default_6 = None
        view_default_5 = torch.ops.aten.view.default(permute_default_8, [1, 256, 3600]);  permute_default_8 = None
        bmm_default_1 = torch.ops.aten.bmm.default(view_default_4, view_default_5)
        view_default_6 = torch.ops.aten.view.default(bmm_default_1, [30, 1, 60, 60]);  bmm_default_1 = None
        permute_default_9 = torch.ops.aten.permute.default(view_default_6, [0, 2, 3, 1]);  view_default_6 = None
        view_default_7 = torch.ops.aten.view.default(permute_default_9, [30, 60, 60]);  permute_default_9 = None
        view_default_8 = torch.ops.aten.view.default(view_default_7, [30, -1]);  view_default_7 = None
        _log_softmax_default_1 = torch.ops.aten._log_softmax.default(view_default_8, -1, False);  view_default_8 = None
        view_default_9 = torch.ops.aten.view.default(_log_softmax_default_1, [1, 30, 60, 60])
        expand_sym_int_2 = torch.ops.aten.expand.SymInt(view_default_9, [40, 30, 60, 60]);  view_default_9 = None
        t_default_5 = torch.ops.aten.t.default(primals_20);  primals_20 = None
        addmm_default_5 = torch.ops.aten.addmm.default(primals_19, primals_23, t_default_5);  primals_19 = None
        t_default_6 = torch.ops.aten.t.default(primals_12);  primals_12 = None
        addmm_default_6 = torch.ops.aten.addmm.default(primals_11, addmm_default_5, t_default_6);  primals_11 = None
        relu_default_4 = torch.ops.aten.relu.default(addmm_default_6);  addmm_default_6 = None
        t_default_7 = torch.ops.aten.t.default(primals_16);  primals_16 = None
        addmm_default_7 = torch.ops.aten.addmm.default(primals_15, relu_default_4, t_default_7);  primals_15 = None
        relu_default_5 = torch.ops.aten.relu.default(addmm_default_7);  addmm_default_7 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(addmm_default_5, relu_default_5)
        t_default_8 = torch.ops.aten.t.default(primals_14);  primals_14 = None
        addmm_default_8 = torch.ops.aten.addmm.default(primals_13, add_tensor_2, t_default_8);  primals_13 = None
        relu_default_6 = torch.ops.aten.relu.default(addmm_default_8);  addmm_default_8 = None
        t_default_9 = torch.ops.aten.t.default(primals_18);  primals_18 = None
        addmm_default_9 = torch.ops.aten.addmm.default(primals_17, relu_default_6, t_default_9);  primals_17 = None
        relu_default_7 = torch.ops.aten.relu.default(addmm_default_9);  addmm_default_9 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(add_tensor_2, relu_default_7)
        unsqueeze_default_9 = torch.ops.aten.unsqueeze.default(primals_24, -1);  primals_24 = None
        permute_default_10 = torch.ops.aten.permute.default(unsqueeze_default_9, [2, 0, 1]);  unsqueeze_default_9 = None
        unsqueeze_default_10 = torch.ops.aten.unsqueeze.default(add_tensor_3, -1);  add_tensor_3 = None
        permute_default_11 = torch.ops.aten.permute.default(unsqueeze_default_10, [0, 2, 1]);  unsqueeze_default_10 = None
        squeeze_dim_1 = torch.ops.aten.squeeze.dim(permute_default_10, 1);  permute_default_10 = None
        squeeze_dim_2 = torch.ops.aten.squeeze.dim(permute_default_11, 1);  permute_default_11 = None
        permute_default_12 = torch.ops.aten.permute.default(squeeze_dim_1, [1, 0]);  squeeze_dim_1 = None
        view_default_10 = torch.ops.aten.view.default(permute_default_12, [1, 1, 256]);  permute_default_12 = None
        permute_default_13 = torch.ops.aten.permute.default(squeeze_dim_2, [1, 0]);  squeeze_dim_2 = None
        view_default_11 = torch.ops.aten.view.default(permute_default_13, [1, 256, 30]);  permute_default_13 = None
        bmm_default_2 = torch.ops.aten.bmm.default(view_default_10, view_default_11)
        view_default_12 = torch.ops.aten.view.default(bmm_default_2, [1, 30]);  bmm_default_2 = None
        permute_default_14 = torch.ops.aten.permute.default(view_default_12, [1, 0]);  view_default_12 = None
        view_default_13 = torch.ops.aten.view.default(permute_default_14, [30]);  permute_default_14 = None
        _log_softmax_default_2 = torch.ops.aten._log_softmax.default(view_default_13, -1, False);  view_default_13 = None
        view_default_14 = torch.ops.aten.view.default(_log_softmax_default_2, [1, 30])
        expand_sym_int_3 = torch.ops.aten.expand.SymInt(view_default_14, [40, 30]);  view_default_14 = None
        return [squeeze_dim, expand_sym_int_2, expand_sym_int_3, t_default, view_default_4, relu_default_6, t_default_1, view_default_5, addmm_default, t_default_9, t_default_5, relu_default, relu_default_7, t_default_2, t_default_6, addmm_default_5, relu_default_1, relu_default_4, add_tensor, _log_softmax_default_2, t_default_3, t_default_7, relu_default_2, relu_default_5, view_default_10, t_default_4, add_tensor_2, t_default_8, view_default_11, relu_default_3, view_default, view_default_1, primals_23, _log_softmax_default_1, _log_softmax_default, unsqueeze_default_5, primals_25]
        
