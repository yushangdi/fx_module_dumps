
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/hf_DistilBert/hf_DistilBert_joint_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, tangents_1):
        slice_tensor = torch.ops.aten.slice.Tensor(primals_4, 0, 0, 9223372036854775807);  primals_4 = None
        embedding_default = torch.ops.aten.embedding.default(primals_5, primals_6, 0);  primals_5 = None
        embedding_default_1 = torch.ops.aten.embedding.default(primals_3, slice_tensor);  primals_3 = None
        add_tensor = torch.ops.aten.add.Tensor(embedding_default, embedding_default_1);  embedding_default = embedding_default_1 = None
        native_layer_norm_default = torch.ops.aten.native_layer_norm.default(add_tensor, [768], primals_2, primals_1, 1e-12)
        getitem = native_layer_norm_default[0]
        getitem_1 = native_layer_norm_default[1]
        getitem_2 = native_layer_norm_default[2];  native_layer_norm_default = None
        is_same_size_default = torch.ops.aten.is_same_size.default(getitem, tangents_1)
        native_layer_norm_backward_default = torch.ops.aten.native_layer_norm_backward.default(tangents_1, add_tensor, [768], getitem_1, getitem_2, primals_2, primals_1, [True, True, True]);  tangents_1 = add_tensor = getitem_1 = getitem_2 = primals_2 = primals_1 = None
        getitem_3 = native_layer_norm_backward_default[0]
        getitem_4 = native_layer_norm_backward_default[1]
        getitem_5 = native_layer_norm_backward_default[2];  native_layer_norm_backward_default = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(getitem_3, [0], True)
        embedding_dense_backward_default = torch.ops.aten.embedding_dense_backward.default(sum_dim_int_list, slice_tensor, 512, -1, False);  sum_dim_int_list = slice_tensor = None
        embedding_dense_backward_default_1 = torch.ops.aten.embedding_dense_backward.default(getitem_3, primals_6, 30522, 0, False);  getitem_3 = primals_6 = None
        return [getitem, getitem_5, getitem_4, embedding_dense_backward_default, None, embedding_dense_backward_default_1, None]
        
