
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/hf_DistilBert/hf_DistilBert_forward_1/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98):
        view_default = torch.ops.aten.view.default(primals_97, [4096, 768])
        t_default = torch.ops.aten.t.default(primals_6);  primals_6 = None
        addmm_default = torch.ops.aten.addmm.default(primals_5, view_default, t_default);  primals_5 = None
        view_default_1 = torch.ops.aten.view.default(addmm_default, [8, 512, 768]);  addmm_default = None
        view_default_2 = torch.ops.aten.view.default(view_default_1, [8, -1, 12, 64]);  view_default_1 = None
        transpose_int = torch.ops.aten.transpose.int(view_default_2, 1, 2);  view_default_2 = None
        view_default_3 = torch.ops.aten.view.default(primals_97, [4096, 768])
        t_default_1 = torch.ops.aten.t.default(primals_2);  primals_2 = None
        addmm_default_1 = torch.ops.aten.addmm.default(primals_1, view_default_3, t_default_1);  primals_1 = None
        view_default_4 = torch.ops.aten.view.default(addmm_default_1, [8, 512, 768]);  addmm_default_1 = None
        view_default_5 = torch.ops.aten.view.default(view_default_4, [8, -1, 12, 64]);  view_default_4 = None
        transpose_int_1 = torch.ops.aten.transpose.int(view_default_5, 1, 2);  view_default_5 = None
        view_default_6 = torch.ops.aten.view.default(primals_97, [4096, 768])
        t_default_2 = torch.ops.aten.t.default(primals_8);  primals_8 = None
        addmm_default_2 = torch.ops.aten.addmm.default(primals_7, view_default_6, t_default_2);  primals_7 = None
        view_default_7 = torch.ops.aten.view.default(addmm_default_2, [8, 512, 768]);  addmm_default_2 = None
        view_default_8 = torch.ops.aten.view.default(view_default_7, [8, -1, 12, 64]);  view_default_7 = None
        transpose_int_2 = torch.ops.aten.transpose.int(view_default_8, 1, 2);  view_default_8 = None
        div_tensor = torch.ops.aten.div.Tensor(transpose_int, 8.0);  transpose_int = None
        transpose_int_3 = torch.ops.aten.transpose.int(transpose_int_1, 2, 3);  transpose_int_1 = None
        expand_default = torch.ops.aten.expand.default(div_tensor, [8, 12, 512, 64]);  div_tensor = None
        clone_default = torch.ops.aten.clone.default(expand_default, memory_format = torch.contiguous_format);  expand_default = None
        _unsafe_view_default = torch.ops.aten._unsafe_view.default(clone_default, [96, 512, 64]);  clone_default = None
        expand_default_1 = torch.ops.aten.expand.default(transpose_int_3, [8, 12, 64, 512]);  transpose_int_3 = None
        clone_default_1 = torch.ops.aten.clone.default(expand_default_1, memory_format = torch.contiguous_format);  expand_default_1 = None
        _unsafe_view_default_1 = torch.ops.aten._unsafe_view.default(clone_default_1, [96, 64, 512]);  clone_default_1 = None
        bmm_default = torch.ops.aten.bmm.default(_unsafe_view_default, _unsafe_view_default_1)
        _unsafe_view_default_2 = torch.ops.aten._unsafe_view.default(bmm_default, [8, 12, 512, 512]);  bmm_default = None
        eq_scalar = torch.ops.aten.eq.Scalar(primals_98, 0)
        view_default_9 = torch.ops.aten.view.default(eq_scalar, [8, 1, 1, 512]);  eq_scalar = None
        expand_default_2 = torch.ops.aten.expand.default(view_default_9, [8, 12, 512, 512]);  view_default_9 = None
        where_scalar_self = torch.ops.aten.where.ScalarSelf(expand_default_2, -inf, _unsafe_view_default_2);  _unsafe_view_default_2 = None
        _softmax_default = torch.ops.aten._softmax.default(where_scalar_self, -1, False);  where_scalar_self = None
        expand_default_3 = torch.ops.aten.expand.default(_softmax_default, [8, 12, 512, 512])
        view_default_10 = torch.ops.aten.view.default(expand_default_3, [96, 512, 512]);  expand_default_3 = None
        expand_default_4 = torch.ops.aten.expand.default(transpose_int_2, [8, 12, 512, 64]);  transpose_int_2 = None
        clone_default_2 = torch.ops.aten.clone.default(expand_default_4, memory_format = torch.contiguous_format);  expand_default_4 = None
        _unsafe_view_default_3 = torch.ops.aten._unsafe_view.default(clone_default_2, [96, 512, 64]);  clone_default_2 = None
        bmm_default_1 = torch.ops.aten.bmm.default(view_default_10, _unsafe_view_default_3)
        _unsafe_view_default_4 = torch.ops.aten._unsafe_view.default(bmm_default_1, [8, 12, 512, 64]);  bmm_default_1 = None
        transpose_int_4 = torch.ops.aten.transpose.int(_unsafe_view_default_4, 1, 2);  _unsafe_view_default_4 = None
        clone_default_3 = torch.ops.aten.clone.default(transpose_int_4, memory_format = torch.contiguous_format);  transpose_int_4 = None
        view_default_11 = torch.ops.aten.view.default(clone_default_3, [8, -1, 768]);  clone_default_3 = None
        view_default_12 = torch.ops.aten.view.default(view_default_11, [4096, 768]);  view_default_11 = None
        t_default_3 = torch.ops.aten.t.default(primals_4);  primals_4 = None
        addmm_default_3 = torch.ops.aten.addmm.default(primals_3, view_default_12, t_default_3);  primals_3 = None
        view_default_13 = torch.ops.aten.view.default(addmm_default_3, [8, 512, 768]);  addmm_default_3 = None
        add_tensor = torch.ops.aten.add.Tensor(view_default_13, primals_97);  view_default_13 = primals_97 = None
        native_layer_norm_default = torch.ops.aten.native_layer_norm.default(add_tensor, [768], primals_16, primals_15, 1e-12)
        getitem = native_layer_norm_default[0]
        getitem_1 = native_layer_norm_default[1]
        getitem_2 = native_layer_norm_default[2];  native_layer_norm_default = None
        view_default_14 = torch.ops.aten.view.default(getitem, [4096, 768])
        t_default_4 = torch.ops.aten.t.default(primals_10);  primals_10 = None
        addmm_default_4 = torch.ops.aten.addmm.default(primals_9, view_default_14, t_default_4);  primals_9 = None
        view_default_15 = torch.ops.aten.view.default(addmm_default_4, [8, 512, 3072]);  addmm_default_4 = None
        gelu_default = torch.ops.aten.gelu.default(view_default_15)
        view_default_16 = torch.ops.aten.view.default(gelu_default, [4096, 3072]);  gelu_default = None
        t_default_5 = torch.ops.aten.t.default(primals_12);  primals_12 = None
        addmm_default_5 = torch.ops.aten.addmm.default(primals_11, view_default_16, t_default_5);  primals_11 = None
        view_default_17 = torch.ops.aten.view.default(addmm_default_5, [8, 512, 768]);  addmm_default_5 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(view_default_17, getitem);  view_default_17 = getitem = None
        native_layer_norm_default_1 = torch.ops.aten.native_layer_norm.default(add_tensor_1, [768], primals_14, primals_13, 1e-12)
        getitem_3 = native_layer_norm_default_1[0]
        getitem_4 = native_layer_norm_default_1[1]
        getitem_5 = native_layer_norm_default_1[2];  native_layer_norm_default_1 = None
        view_default_18 = torch.ops.aten.view.default(getitem_3, [4096, 768])
        t_default_6 = torch.ops.aten.t.default(primals_22);  primals_22 = None
        addmm_default_6 = torch.ops.aten.addmm.default(primals_21, view_default_18, t_default_6);  primals_21 = None
        view_default_19 = torch.ops.aten.view.default(addmm_default_6, [8, 512, 768]);  addmm_default_6 = None
        view_default_20 = torch.ops.aten.view.default(view_default_19, [8, -1, 12, 64]);  view_default_19 = None
        transpose_int_5 = torch.ops.aten.transpose.int(view_default_20, 1, 2);  view_default_20 = None
        view_default_21 = torch.ops.aten.view.default(getitem_3, [4096, 768])
        t_default_7 = torch.ops.aten.t.default(primals_18);  primals_18 = None
        addmm_default_7 = torch.ops.aten.addmm.default(primals_17, view_default_21, t_default_7);  primals_17 = None
        view_default_22 = torch.ops.aten.view.default(addmm_default_7, [8, 512, 768]);  addmm_default_7 = None
        view_default_23 = torch.ops.aten.view.default(view_default_22, [8, -1, 12, 64]);  view_default_22 = None
        transpose_int_6 = torch.ops.aten.transpose.int(view_default_23, 1, 2);  view_default_23 = None
        view_default_24 = torch.ops.aten.view.default(getitem_3, [4096, 768])
        t_default_8 = torch.ops.aten.t.default(primals_24);  primals_24 = None
        addmm_default_8 = torch.ops.aten.addmm.default(primals_23, view_default_24, t_default_8);  primals_23 = None
        view_default_25 = torch.ops.aten.view.default(addmm_default_8, [8, 512, 768]);  addmm_default_8 = None
        view_default_26 = torch.ops.aten.view.default(view_default_25, [8, -1, 12, 64]);  view_default_25 = None
        transpose_int_7 = torch.ops.aten.transpose.int(view_default_26, 1, 2);  view_default_26 = None
        div_tensor_1 = torch.ops.aten.div.Tensor(transpose_int_5, 8.0);  transpose_int_5 = None
        transpose_int_8 = torch.ops.aten.transpose.int(transpose_int_6, 2, 3);  transpose_int_6 = None
        expand_default_5 = torch.ops.aten.expand.default(div_tensor_1, [8, 12, 512, 64]);  div_tensor_1 = None
        clone_default_4 = torch.ops.aten.clone.default(expand_default_5, memory_format = torch.contiguous_format);  expand_default_5 = None
        _unsafe_view_default_5 = torch.ops.aten._unsafe_view.default(clone_default_4, [96, 512, 64]);  clone_default_4 = None
        expand_default_6 = torch.ops.aten.expand.default(transpose_int_8, [8, 12, 64, 512]);  transpose_int_8 = None
        clone_default_5 = torch.ops.aten.clone.default(expand_default_6, memory_format = torch.contiguous_format);  expand_default_6 = None
        _unsafe_view_default_6 = torch.ops.aten._unsafe_view.default(clone_default_5, [96, 64, 512]);  clone_default_5 = None
        bmm_default_2 = torch.ops.aten.bmm.default(_unsafe_view_default_5, _unsafe_view_default_6)
        _unsafe_view_default_7 = torch.ops.aten._unsafe_view.default(bmm_default_2, [8, 12, 512, 512]);  bmm_default_2 = None
        eq_scalar_1 = torch.ops.aten.eq.Scalar(primals_98, 0)
        view_default_27 = torch.ops.aten.view.default(eq_scalar_1, [8, 1, 1, 512]);  eq_scalar_1 = None
        expand_default_7 = torch.ops.aten.expand.default(view_default_27, [8, 12, 512, 512]);  view_default_27 = None
        where_scalar_self_1 = torch.ops.aten.where.ScalarSelf(expand_default_7, -inf, _unsafe_view_default_7);  _unsafe_view_default_7 = None
        _softmax_default_1 = torch.ops.aten._softmax.default(where_scalar_self_1, -1, False);  where_scalar_self_1 = None
        expand_default_8 = torch.ops.aten.expand.default(_softmax_default_1, [8, 12, 512, 512])
        view_default_28 = torch.ops.aten.view.default(expand_default_8, [96, 512, 512]);  expand_default_8 = None
        expand_default_9 = torch.ops.aten.expand.default(transpose_int_7, [8, 12, 512, 64]);  transpose_int_7 = None
        clone_default_6 = torch.ops.aten.clone.default(expand_default_9, memory_format = torch.contiguous_format);  expand_default_9 = None
        _unsafe_view_default_8 = torch.ops.aten._unsafe_view.default(clone_default_6, [96, 512, 64]);  clone_default_6 = None
        bmm_default_3 = torch.ops.aten.bmm.default(view_default_28, _unsafe_view_default_8)
        _unsafe_view_default_9 = torch.ops.aten._unsafe_view.default(bmm_default_3, [8, 12, 512, 64]);  bmm_default_3 = None
        transpose_int_9 = torch.ops.aten.transpose.int(_unsafe_view_default_9, 1, 2);  _unsafe_view_default_9 = None
        clone_default_7 = torch.ops.aten.clone.default(transpose_int_9, memory_format = torch.contiguous_format);  transpose_int_9 = None
        view_default_29 = torch.ops.aten.view.default(clone_default_7, [8, -1, 768]);  clone_default_7 = None
        view_default_30 = torch.ops.aten.view.default(view_default_29, [4096, 768]);  view_default_29 = None
        t_default_9 = torch.ops.aten.t.default(primals_20);  primals_20 = None
        addmm_default_9 = torch.ops.aten.addmm.default(primals_19, view_default_30, t_default_9);  primals_19 = None
        view_default_31 = torch.ops.aten.view.default(addmm_default_9, [8, 512, 768]);  addmm_default_9 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(view_default_31, getitem_3);  view_default_31 = getitem_3 = None
        native_layer_norm_default_2 = torch.ops.aten.native_layer_norm.default(add_tensor_2, [768], primals_32, primals_31, 1e-12)
        getitem_6 = native_layer_norm_default_2[0]
        getitem_7 = native_layer_norm_default_2[1]
        getitem_8 = native_layer_norm_default_2[2];  native_layer_norm_default_2 = None
        view_default_32 = torch.ops.aten.view.default(getitem_6, [4096, 768])
        t_default_10 = torch.ops.aten.t.default(primals_26);  primals_26 = None
        addmm_default_10 = torch.ops.aten.addmm.default(primals_25, view_default_32, t_default_10);  primals_25 = None
        view_default_33 = torch.ops.aten.view.default(addmm_default_10, [8, 512, 3072]);  addmm_default_10 = None
        gelu_default_1 = torch.ops.aten.gelu.default(view_default_33)
        view_default_34 = torch.ops.aten.view.default(gelu_default_1, [4096, 3072]);  gelu_default_1 = None
        t_default_11 = torch.ops.aten.t.default(primals_28);  primals_28 = None
        addmm_default_11 = torch.ops.aten.addmm.default(primals_27, view_default_34, t_default_11);  primals_27 = None
        view_default_35 = torch.ops.aten.view.default(addmm_default_11, [8, 512, 768]);  addmm_default_11 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(view_default_35, getitem_6);  view_default_35 = getitem_6 = None
        native_layer_norm_default_3 = torch.ops.aten.native_layer_norm.default(add_tensor_3, [768], primals_30, primals_29, 1e-12)
        getitem_9 = native_layer_norm_default_3[0]
        getitem_10 = native_layer_norm_default_3[1]
        getitem_11 = native_layer_norm_default_3[2];  native_layer_norm_default_3 = None
        view_default_36 = torch.ops.aten.view.default(getitem_9, [4096, 768])
        t_default_12 = torch.ops.aten.t.default(primals_38);  primals_38 = None
        addmm_default_12 = torch.ops.aten.addmm.default(primals_37, view_default_36, t_default_12);  primals_37 = None
        view_default_37 = torch.ops.aten.view.default(addmm_default_12, [8, 512, 768]);  addmm_default_12 = None
        view_default_38 = torch.ops.aten.view.default(view_default_37, [8, -1, 12, 64]);  view_default_37 = None
        transpose_int_10 = torch.ops.aten.transpose.int(view_default_38, 1, 2);  view_default_38 = None
        view_default_39 = torch.ops.aten.view.default(getitem_9, [4096, 768])
        t_default_13 = torch.ops.aten.t.default(primals_34);  primals_34 = None
        addmm_default_13 = torch.ops.aten.addmm.default(primals_33, view_default_39, t_default_13);  primals_33 = None
        view_default_40 = torch.ops.aten.view.default(addmm_default_13, [8, 512, 768]);  addmm_default_13 = None
        view_default_41 = torch.ops.aten.view.default(view_default_40, [8, -1, 12, 64]);  view_default_40 = None
        transpose_int_11 = torch.ops.aten.transpose.int(view_default_41, 1, 2);  view_default_41 = None
        view_default_42 = torch.ops.aten.view.default(getitem_9, [4096, 768])
        t_default_14 = torch.ops.aten.t.default(primals_40);  primals_40 = None
        addmm_default_14 = torch.ops.aten.addmm.default(primals_39, view_default_42, t_default_14);  primals_39 = None
        view_default_43 = torch.ops.aten.view.default(addmm_default_14, [8, 512, 768]);  addmm_default_14 = None
        view_default_44 = torch.ops.aten.view.default(view_default_43, [8, -1, 12, 64]);  view_default_43 = None
        transpose_int_12 = torch.ops.aten.transpose.int(view_default_44, 1, 2);  view_default_44 = None
        div_tensor_2 = torch.ops.aten.div.Tensor(transpose_int_10, 8.0);  transpose_int_10 = None
        transpose_int_13 = torch.ops.aten.transpose.int(transpose_int_11, 2, 3);  transpose_int_11 = None
        expand_default_10 = torch.ops.aten.expand.default(div_tensor_2, [8, 12, 512, 64]);  div_tensor_2 = None
        clone_default_8 = torch.ops.aten.clone.default(expand_default_10, memory_format = torch.contiguous_format);  expand_default_10 = None
        _unsafe_view_default_10 = torch.ops.aten._unsafe_view.default(clone_default_8, [96, 512, 64]);  clone_default_8 = None
        expand_default_11 = torch.ops.aten.expand.default(transpose_int_13, [8, 12, 64, 512]);  transpose_int_13 = None
        clone_default_9 = torch.ops.aten.clone.default(expand_default_11, memory_format = torch.contiguous_format);  expand_default_11 = None
        _unsafe_view_default_11 = torch.ops.aten._unsafe_view.default(clone_default_9, [96, 64, 512]);  clone_default_9 = None
        bmm_default_4 = torch.ops.aten.bmm.default(_unsafe_view_default_10, _unsafe_view_default_11)
        _unsafe_view_default_12 = torch.ops.aten._unsafe_view.default(bmm_default_4, [8, 12, 512, 512]);  bmm_default_4 = None
        eq_scalar_2 = torch.ops.aten.eq.Scalar(primals_98, 0)
        view_default_45 = torch.ops.aten.view.default(eq_scalar_2, [8, 1, 1, 512]);  eq_scalar_2 = None
        expand_default_12 = torch.ops.aten.expand.default(view_default_45, [8, 12, 512, 512]);  view_default_45 = None
        where_scalar_self_2 = torch.ops.aten.where.ScalarSelf(expand_default_12, -inf, _unsafe_view_default_12);  _unsafe_view_default_12 = None
        _softmax_default_2 = torch.ops.aten._softmax.default(where_scalar_self_2, -1, False);  where_scalar_self_2 = None
        expand_default_13 = torch.ops.aten.expand.default(_softmax_default_2, [8, 12, 512, 512])
        view_default_46 = torch.ops.aten.view.default(expand_default_13, [96, 512, 512]);  expand_default_13 = None
        expand_default_14 = torch.ops.aten.expand.default(transpose_int_12, [8, 12, 512, 64]);  transpose_int_12 = None
        clone_default_10 = torch.ops.aten.clone.default(expand_default_14, memory_format = torch.contiguous_format);  expand_default_14 = None
        _unsafe_view_default_13 = torch.ops.aten._unsafe_view.default(clone_default_10, [96, 512, 64]);  clone_default_10 = None
        bmm_default_5 = torch.ops.aten.bmm.default(view_default_46, _unsafe_view_default_13)
        _unsafe_view_default_14 = torch.ops.aten._unsafe_view.default(bmm_default_5, [8, 12, 512, 64]);  bmm_default_5 = None
        transpose_int_14 = torch.ops.aten.transpose.int(_unsafe_view_default_14, 1, 2);  _unsafe_view_default_14 = None
        clone_default_11 = torch.ops.aten.clone.default(transpose_int_14, memory_format = torch.contiguous_format);  transpose_int_14 = None
        view_default_47 = torch.ops.aten.view.default(clone_default_11, [8, -1, 768]);  clone_default_11 = None
        view_default_48 = torch.ops.aten.view.default(view_default_47, [4096, 768]);  view_default_47 = None
        t_default_15 = torch.ops.aten.t.default(primals_36);  primals_36 = None
        addmm_default_15 = torch.ops.aten.addmm.default(primals_35, view_default_48, t_default_15);  primals_35 = None
        view_default_49 = torch.ops.aten.view.default(addmm_default_15, [8, 512, 768]);  addmm_default_15 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(view_default_49, getitem_9);  view_default_49 = getitem_9 = None
        native_layer_norm_default_4 = torch.ops.aten.native_layer_norm.default(add_tensor_4, [768], primals_48, primals_47, 1e-12)
        getitem_12 = native_layer_norm_default_4[0]
        getitem_13 = native_layer_norm_default_4[1]
        getitem_14 = native_layer_norm_default_4[2];  native_layer_norm_default_4 = None
        view_default_50 = torch.ops.aten.view.default(getitem_12, [4096, 768])
        t_default_16 = torch.ops.aten.t.default(primals_42);  primals_42 = None
        addmm_default_16 = torch.ops.aten.addmm.default(primals_41, view_default_50, t_default_16);  primals_41 = None
        view_default_51 = torch.ops.aten.view.default(addmm_default_16, [8, 512, 3072]);  addmm_default_16 = None
        gelu_default_2 = torch.ops.aten.gelu.default(view_default_51)
        view_default_52 = torch.ops.aten.view.default(gelu_default_2, [4096, 3072]);  gelu_default_2 = None
        t_default_17 = torch.ops.aten.t.default(primals_44);  primals_44 = None
        addmm_default_17 = torch.ops.aten.addmm.default(primals_43, view_default_52, t_default_17);  primals_43 = None
        view_default_53 = torch.ops.aten.view.default(addmm_default_17, [8, 512, 768]);  addmm_default_17 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(view_default_53, getitem_12);  view_default_53 = getitem_12 = None
        native_layer_norm_default_5 = torch.ops.aten.native_layer_norm.default(add_tensor_5, [768], primals_46, primals_45, 1e-12)
        getitem_15 = native_layer_norm_default_5[0]
        getitem_16 = native_layer_norm_default_5[1]
        getitem_17 = native_layer_norm_default_5[2];  native_layer_norm_default_5 = None
        view_default_54 = torch.ops.aten.view.default(getitem_15, [4096, 768])
        t_default_18 = torch.ops.aten.t.default(primals_54);  primals_54 = None
        addmm_default_18 = torch.ops.aten.addmm.default(primals_53, view_default_54, t_default_18);  primals_53 = None
        view_default_55 = torch.ops.aten.view.default(addmm_default_18, [8, 512, 768]);  addmm_default_18 = None
        view_default_56 = torch.ops.aten.view.default(view_default_55, [8, -1, 12, 64]);  view_default_55 = None
        transpose_int_15 = torch.ops.aten.transpose.int(view_default_56, 1, 2);  view_default_56 = None
        view_default_57 = torch.ops.aten.view.default(getitem_15, [4096, 768])
        t_default_19 = torch.ops.aten.t.default(primals_50);  primals_50 = None
        addmm_default_19 = torch.ops.aten.addmm.default(primals_49, view_default_57, t_default_19);  primals_49 = None
        view_default_58 = torch.ops.aten.view.default(addmm_default_19, [8, 512, 768]);  addmm_default_19 = None
        view_default_59 = torch.ops.aten.view.default(view_default_58, [8, -1, 12, 64]);  view_default_58 = None
        transpose_int_16 = torch.ops.aten.transpose.int(view_default_59, 1, 2);  view_default_59 = None
        view_default_60 = torch.ops.aten.view.default(getitem_15, [4096, 768])
        t_default_20 = torch.ops.aten.t.default(primals_56);  primals_56 = None
        addmm_default_20 = torch.ops.aten.addmm.default(primals_55, view_default_60, t_default_20);  primals_55 = None
        view_default_61 = torch.ops.aten.view.default(addmm_default_20, [8, 512, 768]);  addmm_default_20 = None
        view_default_62 = torch.ops.aten.view.default(view_default_61, [8, -1, 12, 64]);  view_default_61 = None
        transpose_int_17 = torch.ops.aten.transpose.int(view_default_62, 1, 2);  view_default_62 = None
        div_tensor_3 = torch.ops.aten.div.Tensor(transpose_int_15, 8.0);  transpose_int_15 = None
        transpose_int_18 = torch.ops.aten.transpose.int(transpose_int_16, 2, 3);  transpose_int_16 = None
        expand_default_15 = torch.ops.aten.expand.default(div_tensor_3, [8, 12, 512, 64]);  div_tensor_3 = None
        clone_default_12 = torch.ops.aten.clone.default(expand_default_15, memory_format = torch.contiguous_format);  expand_default_15 = None
        _unsafe_view_default_15 = torch.ops.aten._unsafe_view.default(clone_default_12, [96, 512, 64]);  clone_default_12 = None
        expand_default_16 = torch.ops.aten.expand.default(transpose_int_18, [8, 12, 64, 512]);  transpose_int_18 = None
        clone_default_13 = torch.ops.aten.clone.default(expand_default_16, memory_format = torch.contiguous_format);  expand_default_16 = None
        _unsafe_view_default_16 = torch.ops.aten._unsafe_view.default(clone_default_13, [96, 64, 512]);  clone_default_13 = None
        bmm_default_6 = torch.ops.aten.bmm.default(_unsafe_view_default_15, _unsafe_view_default_16)
        _unsafe_view_default_17 = torch.ops.aten._unsafe_view.default(bmm_default_6, [8, 12, 512, 512]);  bmm_default_6 = None
        eq_scalar_3 = torch.ops.aten.eq.Scalar(primals_98, 0)
        view_default_63 = torch.ops.aten.view.default(eq_scalar_3, [8, 1, 1, 512]);  eq_scalar_3 = None
        expand_default_17 = torch.ops.aten.expand.default(view_default_63, [8, 12, 512, 512]);  view_default_63 = None
        where_scalar_self_3 = torch.ops.aten.where.ScalarSelf(expand_default_17, -inf, _unsafe_view_default_17);  _unsafe_view_default_17 = None
        _softmax_default_3 = torch.ops.aten._softmax.default(where_scalar_self_3, -1, False);  where_scalar_self_3 = None
        expand_default_18 = torch.ops.aten.expand.default(_softmax_default_3, [8, 12, 512, 512])
        view_default_64 = torch.ops.aten.view.default(expand_default_18, [96, 512, 512]);  expand_default_18 = None
        expand_default_19 = torch.ops.aten.expand.default(transpose_int_17, [8, 12, 512, 64]);  transpose_int_17 = None
        clone_default_14 = torch.ops.aten.clone.default(expand_default_19, memory_format = torch.contiguous_format);  expand_default_19 = None
        _unsafe_view_default_18 = torch.ops.aten._unsafe_view.default(clone_default_14, [96, 512, 64]);  clone_default_14 = None
        bmm_default_7 = torch.ops.aten.bmm.default(view_default_64, _unsafe_view_default_18)
        _unsafe_view_default_19 = torch.ops.aten._unsafe_view.default(bmm_default_7, [8, 12, 512, 64]);  bmm_default_7 = None
        transpose_int_19 = torch.ops.aten.transpose.int(_unsafe_view_default_19, 1, 2);  _unsafe_view_default_19 = None
        clone_default_15 = torch.ops.aten.clone.default(transpose_int_19, memory_format = torch.contiguous_format);  transpose_int_19 = None
        view_default_65 = torch.ops.aten.view.default(clone_default_15, [8, -1, 768]);  clone_default_15 = None
        view_default_66 = torch.ops.aten.view.default(view_default_65, [4096, 768]);  view_default_65 = None
        t_default_21 = torch.ops.aten.t.default(primals_52);  primals_52 = None
        addmm_default_21 = torch.ops.aten.addmm.default(primals_51, view_default_66, t_default_21);  primals_51 = None
        view_default_67 = torch.ops.aten.view.default(addmm_default_21, [8, 512, 768]);  addmm_default_21 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(view_default_67, getitem_15);  view_default_67 = getitem_15 = None
        native_layer_norm_default_6 = torch.ops.aten.native_layer_norm.default(add_tensor_6, [768], primals_64, primals_63, 1e-12)
        getitem_18 = native_layer_norm_default_6[0]
        getitem_19 = native_layer_norm_default_6[1]
        getitem_20 = native_layer_norm_default_6[2];  native_layer_norm_default_6 = None
        view_default_68 = torch.ops.aten.view.default(getitem_18, [4096, 768])
        t_default_22 = torch.ops.aten.t.default(primals_58);  primals_58 = None
        addmm_default_22 = torch.ops.aten.addmm.default(primals_57, view_default_68, t_default_22);  primals_57 = None
        view_default_69 = torch.ops.aten.view.default(addmm_default_22, [8, 512, 3072]);  addmm_default_22 = None
        gelu_default_3 = torch.ops.aten.gelu.default(view_default_69)
        view_default_70 = torch.ops.aten.view.default(gelu_default_3, [4096, 3072]);  gelu_default_3 = None
        t_default_23 = torch.ops.aten.t.default(primals_60);  primals_60 = None
        addmm_default_23 = torch.ops.aten.addmm.default(primals_59, view_default_70, t_default_23);  primals_59 = None
        view_default_71 = torch.ops.aten.view.default(addmm_default_23, [8, 512, 768]);  addmm_default_23 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(view_default_71, getitem_18);  view_default_71 = getitem_18 = None
        native_layer_norm_default_7 = torch.ops.aten.native_layer_norm.default(add_tensor_7, [768], primals_62, primals_61, 1e-12)
        getitem_21 = native_layer_norm_default_7[0]
        getitem_22 = native_layer_norm_default_7[1]
        getitem_23 = native_layer_norm_default_7[2];  native_layer_norm_default_7 = None
        view_default_72 = torch.ops.aten.view.default(getitem_21, [4096, 768])
        t_default_24 = torch.ops.aten.t.default(primals_70);  primals_70 = None
        addmm_default_24 = torch.ops.aten.addmm.default(primals_69, view_default_72, t_default_24);  primals_69 = None
        view_default_73 = torch.ops.aten.view.default(addmm_default_24, [8, 512, 768]);  addmm_default_24 = None
        view_default_74 = torch.ops.aten.view.default(view_default_73, [8, -1, 12, 64]);  view_default_73 = None
        transpose_int_20 = torch.ops.aten.transpose.int(view_default_74, 1, 2);  view_default_74 = None
        view_default_75 = torch.ops.aten.view.default(getitem_21, [4096, 768])
        t_default_25 = torch.ops.aten.t.default(primals_66);  primals_66 = None
        addmm_default_25 = torch.ops.aten.addmm.default(primals_65, view_default_75, t_default_25);  primals_65 = None
        view_default_76 = torch.ops.aten.view.default(addmm_default_25, [8, 512, 768]);  addmm_default_25 = None
        view_default_77 = torch.ops.aten.view.default(view_default_76, [8, -1, 12, 64]);  view_default_76 = None
        transpose_int_21 = torch.ops.aten.transpose.int(view_default_77, 1, 2);  view_default_77 = None
        view_default_78 = torch.ops.aten.view.default(getitem_21, [4096, 768])
        t_default_26 = torch.ops.aten.t.default(primals_72);  primals_72 = None
        addmm_default_26 = torch.ops.aten.addmm.default(primals_71, view_default_78, t_default_26);  primals_71 = None
        view_default_79 = torch.ops.aten.view.default(addmm_default_26, [8, 512, 768]);  addmm_default_26 = None
        view_default_80 = torch.ops.aten.view.default(view_default_79, [8, -1, 12, 64]);  view_default_79 = None
        transpose_int_22 = torch.ops.aten.transpose.int(view_default_80, 1, 2);  view_default_80 = None
        div_tensor_4 = torch.ops.aten.div.Tensor(transpose_int_20, 8.0);  transpose_int_20 = None
        transpose_int_23 = torch.ops.aten.transpose.int(transpose_int_21, 2, 3);  transpose_int_21 = None
        expand_default_20 = torch.ops.aten.expand.default(div_tensor_4, [8, 12, 512, 64]);  div_tensor_4 = None
        clone_default_16 = torch.ops.aten.clone.default(expand_default_20, memory_format = torch.contiguous_format);  expand_default_20 = None
        _unsafe_view_default_20 = torch.ops.aten._unsafe_view.default(clone_default_16, [96, 512, 64]);  clone_default_16 = None
        expand_default_21 = torch.ops.aten.expand.default(transpose_int_23, [8, 12, 64, 512]);  transpose_int_23 = None
        clone_default_17 = torch.ops.aten.clone.default(expand_default_21, memory_format = torch.contiguous_format);  expand_default_21 = None
        _unsafe_view_default_21 = torch.ops.aten._unsafe_view.default(clone_default_17, [96, 64, 512]);  clone_default_17 = None
        bmm_default_8 = torch.ops.aten.bmm.default(_unsafe_view_default_20, _unsafe_view_default_21)
        _unsafe_view_default_22 = torch.ops.aten._unsafe_view.default(bmm_default_8, [8, 12, 512, 512]);  bmm_default_8 = None
        eq_scalar_4 = torch.ops.aten.eq.Scalar(primals_98, 0)
        view_default_81 = torch.ops.aten.view.default(eq_scalar_4, [8, 1, 1, 512]);  eq_scalar_4 = None
        expand_default_22 = torch.ops.aten.expand.default(view_default_81, [8, 12, 512, 512]);  view_default_81 = None
        where_scalar_self_4 = torch.ops.aten.where.ScalarSelf(expand_default_22, -inf, _unsafe_view_default_22);  _unsafe_view_default_22 = None
        _softmax_default_4 = torch.ops.aten._softmax.default(where_scalar_self_4, -1, False);  where_scalar_self_4 = None
        expand_default_23 = torch.ops.aten.expand.default(_softmax_default_4, [8, 12, 512, 512])
        view_default_82 = torch.ops.aten.view.default(expand_default_23, [96, 512, 512]);  expand_default_23 = None
        expand_default_24 = torch.ops.aten.expand.default(transpose_int_22, [8, 12, 512, 64]);  transpose_int_22 = None
        clone_default_18 = torch.ops.aten.clone.default(expand_default_24, memory_format = torch.contiguous_format);  expand_default_24 = None
        _unsafe_view_default_23 = torch.ops.aten._unsafe_view.default(clone_default_18, [96, 512, 64]);  clone_default_18 = None
        bmm_default_9 = torch.ops.aten.bmm.default(view_default_82, _unsafe_view_default_23)
        _unsafe_view_default_24 = torch.ops.aten._unsafe_view.default(bmm_default_9, [8, 12, 512, 64]);  bmm_default_9 = None
        transpose_int_24 = torch.ops.aten.transpose.int(_unsafe_view_default_24, 1, 2);  _unsafe_view_default_24 = None
        clone_default_19 = torch.ops.aten.clone.default(transpose_int_24, memory_format = torch.contiguous_format);  transpose_int_24 = None
        view_default_83 = torch.ops.aten.view.default(clone_default_19, [8, -1, 768]);  clone_default_19 = None
        view_default_84 = torch.ops.aten.view.default(view_default_83, [4096, 768]);  view_default_83 = None
        t_default_27 = torch.ops.aten.t.default(primals_68);  primals_68 = None
        addmm_default_27 = torch.ops.aten.addmm.default(primals_67, view_default_84, t_default_27);  primals_67 = None
        view_default_85 = torch.ops.aten.view.default(addmm_default_27, [8, 512, 768]);  addmm_default_27 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(view_default_85, getitem_21);  view_default_85 = getitem_21 = None
        native_layer_norm_default_8 = torch.ops.aten.native_layer_norm.default(add_tensor_8, [768], primals_80, primals_79, 1e-12)
        getitem_24 = native_layer_norm_default_8[0]
        getitem_25 = native_layer_norm_default_8[1]
        getitem_26 = native_layer_norm_default_8[2];  native_layer_norm_default_8 = None
        view_default_86 = torch.ops.aten.view.default(getitem_24, [4096, 768])
        t_default_28 = torch.ops.aten.t.default(primals_74);  primals_74 = None
        addmm_default_28 = torch.ops.aten.addmm.default(primals_73, view_default_86, t_default_28);  primals_73 = None
        view_default_87 = torch.ops.aten.view.default(addmm_default_28, [8, 512, 3072]);  addmm_default_28 = None
        gelu_default_4 = torch.ops.aten.gelu.default(view_default_87)
        view_default_88 = torch.ops.aten.view.default(gelu_default_4, [4096, 3072]);  gelu_default_4 = None
        t_default_29 = torch.ops.aten.t.default(primals_76);  primals_76 = None
        addmm_default_29 = torch.ops.aten.addmm.default(primals_75, view_default_88, t_default_29);  primals_75 = None
        view_default_89 = torch.ops.aten.view.default(addmm_default_29, [8, 512, 768]);  addmm_default_29 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(view_default_89, getitem_24);  view_default_89 = getitem_24 = None
        native_layer_norm_default_9 = torch.ops.aten.native_layer_norm.default(add_tensor_9, [768], primals_78, primals_77, 1e-12)
        getitem_27 = native_layer_norm_default_9[0]
        getitem_28 = native_layer_norm_default_9[1]
        getitem_29 = native_layer_norm_default_9[2];  native_layer_norm_default_9 = None
        view_default_90 = torch.ops.aten.view.default(getitem_27, [4096, 768])
        t_default_30 = torch.ops.aten.t.default(primals_86);  primals_86 = None
        addmm_default_30 = torch.ops.aten.addmm.default(primals_85, view_default_90, t_default_30);  primals_85 = None
        view_default_91 = torch.ops.aten.view.default(addmm_default_30, [8, 512, 768]);  addmm_default_30 = None
        view_default_92 = torch.ops.aten.view.default(view_default_91, [8, -1, 12, 64]);  view_default_91 = None
        transpose_int_25 = torch.ops.aten.transpose.int(view_default_92, 1, 2);  view_default_92 = None
        view_default_93 = torch.ops.aten.view.default(getitem_27, [4096, 768])
        t_default_31 = torch.ops.aten.t.default(primals_82);  primals_82 = None
        addmm_default_31 = torch.ops.aten.addmm.default(primals_81, view_default_93, t_default_31);  primals_81 = None
        view_default_94 = torch.ops.aten.view.default(addmm_default_31, [8, 512, 768]);  addmm_default_31 = None
        view_default_95 = torch.ops.aten.view.default(view_default_94, [8, -1, 12, 64]);  view_default_94 = None
        transpose_int_26 = torch.ops.aten.transpose.int(view_default_95, 1, 2);  view_default_95 = None
        view_default_96 = torch.ops.aten.view.default(getitem_27, [4096, 768])
        t_default_32 = torch.ops.aten.t.default(primals_88);  primals_88 = None
        addmm_default_32 = torch.ops.aten.addmm.default(primals_87, view_default_96, t_default_32);  primals_87 = None
        view_default_97 = torch.ops.aten.view.default(addmm_default_32, [8, 512, 768]);  addmm_default_32 = None
        view_default_98 = torch.ops.aten.view.default(view_default_97, [8, -1, 12, 64]);  view_default_97 = None
        transpose_int_27 = torch.ops.aten.transpose.int(view_default_98, 1, 2);  view_default_98 = None
        div_tensor_5 = torch.ops.aten.div.Tensor(transpose_int_25, 8.0);  transpose_int_25 = None
        transpose_int_28 = torch.ops.aten.transpose.int(transpose_int_26, 2, 3);  transpose_int_26 = None
        expand_default_25 = torch.ops.aten.expand.default(div_tensor_5, [8, 12, 512, 64]);  div_tensor_5 = None
        clone_default_20 = torch.ops.aten.clone.default(expand_default_25, memory_format = torch.contiguous_format);  expand_default_25 = None
        _unsafe_view_default_25 = torch.ops.aten._unsafe_view.default(clone_default_20, [96, 512, 64]);  clone_default_20 = None
        expand_default_26 = torch.ops.aten.expand.default(transpose_int_28, [8, 12, 64, 512]);  transpose_int_28 = None
        clone_default_21 = torch.ops.aten.clone.default(expand_default_26, memory_format = torch.contiguous_format);  expand_default_26 = None
        _unsafe_view_default_26 = torch.ops.aten._unsafe_view.default(clone_default_21, [96, 64, 512]);  clone_default_21 = None
        bmm_default_10 = torch.ops.aten.bmm.default(_unsafe_view_default_25, _unsafe_view_default_26)
        _unsafe_view_default_27 = torch.ops.aten._unsafe_view.default(bmm_default_10, [8, 12, 512, 512]);  bmm_default_10 = None
        eq_scalar_5 = torch.ops.aten.eq.Scalar(primals_98, 0);  primals_98 = None
        view_default_99 = torch.ops.aten.view.default(eq_scalar_5, [8, 1, 1, 512]);  eq_scalar_5 = None
        expand_default_27 = torch.ops.aten.expand.default(view_default_99, [8, 12, 512, 512]);  view_default_99 = None
        where_scalar_self_5 = torch.ops.aten.where.ScalarSelf(expand_default_27, -inf, _unsafe_view_default_27);  _unsafe_view_default_27 = None
        _softmax_default_5 = torch.ops.aten._softmax.default(where_scalar_self_5, -1, False);  where_scalar_self_5 = None
        expand_default_28 = torch.ops.aten.expand.default(_softmax_default_5, [8, 12, 512, 512])
        view_default_100 = torch.ops.aten.view.default(expand_default_28, [96, 512, 512]);  expand_default_28 = None
        expand_default_29 = torch.ops.aten.expand.default(transpose_int_27, [8, 12, 512, 64]);  transpose_int_27 = None
        clone_default_22 = torch.ops.aten.clone.default(expand_default_29, memory_format = torch.contiguous_format);  expand_default_29 = None
        _unsafe_view_default_28 = torch.ops.aten._unsafe_view.default(clone_default_22, [96, 512, 64]);  clone_default_22 = None
        bmm_default_11 = torch.ops.aten.bmm.default(view_default_100, _unsafe_view_default_28)
        _unsafe_view_default_29 = torch.ops.aten._unsafe_view.default(bmm_default_11, [8, 12, 512, 64]);  bmm_default_11 = None
        transpose_int_29 = torch.ops.aten.transpose.int(_unsafe_view_default_29, 1, 2);  _unsafe_view_default_29 = None
        clone_default_23 = torch.ops.aten.clone.default(transpose_int_29, memory_format = torch.contiguous_format);  transpose_int_29 = None
        view_default_101 = torch.ops.aten.view.default(clone_default_23, [8, -1, 768]);  clone_default_23 = None
        view_default_102 = torch.ops.aten.view.default(view_default_101, [4096, 768]);  view_default_101 = None
        t_default_33 = torch.ops.aten.t.default(primals_84);  primals_84 = None
        addmm_default_33 = torch.ops.aten.addmm.default(primals_83, view_default_102, t_default_33);  primals_83 = None
        view_default_103 = torch.ops.aten.view.default(addmm_default_33, [8, 512, 768]);  addmm_default_33 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(view_default_103, getitem_27);  view_default_103 = getitem_27 = None
        native_layer_norm_default_10 = torch.ops.aten.native_layer_norm.default(add_tensor_10, [768], primals_96, primals_95, 1e-12)
        getitem_30 = native_layer_norm_default_10[0]
        getitem_31 = native_layer_norm_default_10[1]
        getitem_32 = native_layer_norm_default_10[2];  native_layer_norm_default_10 = None
        view_default_104 = torch.ops.aten.view.default(getitem_30, [4096, 768])
        t_default_34 = torch.ops.aten.t.default(primals_90);  primals_90 = None
        addmm_default_34 = torch.ops.aten.addmm.default(primals_89, view_default_104, t_default_34);  primals_89 = None
        view_default_105 = torch.ops.aten.view.default(addmm_default_34, [8, 512, 3072]);  addmm_default_34 = None
        gelu_default_5 = torch.ops.aten.gelu.default(view_default_105)
        view_default_106 = torch.ops.aten.view.default(gelu_default_5, [4096, 3072]);  gelu_default_5 = None
        t_default_35 = torch.ops.aten.t.default(primals_92);  primals_92 = None
        addmm_default_35 = torch.ops.aten.addmm.default(primals_91, view_default_106, t_default_35);  primals_91 = None
        view_default_107 = torch.ops.aten.view.default(addmm_default_35, [8, 512, 768]);  addmm_default_35 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(view_default_107, getitem_30);  view_default_107 = getitem_30 = None
        native_layer_norm_default_11 = torch.ops.aten.native_layer_norm.default(add_tensor_11, [768], primals_94, primals_93, 1e-12)
        getitem_33 = native_layer_norm_default_11[0]
        getitem_34 = native_layer_norm_default_11[1]
        getitem_35 = native_layer_norm_default_11[2];  native_layer_norm_default_11 = None
        return [getitem_33, _unsafe_view_default_11, _unsafe_view_default_10, _unsafe_view_default_23, view_default_46, view_default_84, _softmax_default_2, primals_48, t_default_27, getitem_26, getitem_25, view_default_86, _unsafe_view_default_13, getitem_13, view_default, view_default_48, t_default, t_default_28, add_tensor_9, view_default_87, t_default_15, view_default_96, view_default_50, view_default_88, t_default_29, view_default_90, getitem_28, getitem_29, t_default_30, _unsafe_view_default_26, _unsafe_view_default_25, t_default_31, _unsafe_view_default_28, view_default_106, t_default_32, expand_default_27, _unsafe_view_default_3, t_default_3, _unsafe_view_default_1, view_default_12, primals_77, primals_64, primals_62, expand_default_2, view_default_6, t_default_2, add_tensor, view_default_10, primals_63, view_default_3, _unsafe_view_default, _softmax_default, t_default_1, primals_78, view_default_69, t_default_6, getitem_5, view_default_32, getitem_7, getitem_8, view_default_70, view_default_72, t_default_7, view_default_21, t_default_23, t_default_10, view_default_33, getitem_22, getitem_23, add_tensor_7, view_default_34, t_default_8, t_default_24, view_default_18, view_default_24, t_default_11, getitem_4, view_default_75, add_tensor_3, view_default_36, t_default_25, view_default_28, getitem_14, add_tensor_6, t_default_19, expand_default_7, primals_93, t_default_16, t_default_26, _unsafe_view_default_15, expand_default_17, view_default_57, view_default_51, primals_30, view_default_78, _unsafe_view_default_5, _softmax_default_1, primals_32, t_default_20, _unsafe_view_default_20, primals_29, view_default_52, _unsafe_view_default_8, view_default_60, add_tensor_8, view_default_54, primals_94, primals_80, t_default_17, add_tensor_2, view_default_82, getitem_16, view_default_30, _unsafe_view_default_21, primals_31, getitem_17, _unsafe_view_default_16, add_tensor_5, _unsafe_view_default_6, primals_79, expand_default_22, _softmax_default_4, _softmax_default_3, t_default_9, t_default_18, getitem_2, view_default_16, getitem_11, add_tensor_1, _softmax_default_5, view_default_15, getitem_10, view_default_14, primals_13, t_default_12, view_default_102, getitem_1, primals_95, t_default_13, expand_default_12, view_default_100, view_default_39, primals_96, add_tensor_10, t_default_5, t_default_14, t_default_33, primals_61, view_default_42, add_tensor_11, t_default_4, add_tensor_4, getitem_32, t_default_34, view_default_104, getitem_31, primals_47, view_default_64, view_default_105, primals_16, primals_46, _unsafe_view_default_18, t_default_35, view_default_66, getitem_34, primals_14, primals_45, getitem_35, primals_15, t_default_21, view_default_93, getitem_20, getitem_19, view_default_68, t_default_22]
        
