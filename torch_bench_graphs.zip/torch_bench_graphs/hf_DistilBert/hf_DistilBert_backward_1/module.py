
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/hf_DistilBert/hf_DistilBert_backward_1/state_dict.pt'))

    
    
    def forward(self, _unsafe_view_default_11, _unsafe_view_default_10, _unsafe_view_default_23, view_default_46, view_default_84, _softmax_default_2, primals_48, t_default_27, getitem_26, getitem_25, view_default_86, _unsafe_view_default_13, getitem_13, view_default, view_default_48, t_default, t_default_28, add_tensor_9, view_default_87, t_default_15, view_default_96, view_default_50, view_default_88, t_default_29, view_default_90, getitem_28, getitem_29, t_default_30, _unsafe_view_default_26, _unsafe_view_default_25, t_default_31, _unsafe_view_default_28, view_default_106, t_default_32, expand_default_27, _unsafe_view_default_3, t_default_3, _unsafe_view_default_1, view_default_12, primals_77, primals_64, primals_62, expand_default_2, view_default_6, t_default_2, add_tensor, view_default_10, primals_63, view_default_3, _unsafe_view_default, _softmax_default, t_default_1, primals_78, view_default_69, t_default_6, getitem_5, view_default_32, getitem_7, getitem_8, view_default_70, view_default_72, t_default_7, view_default_21, t_default_23, t_default_10, view_default_33, getitem_22, getitem_23, add_tensor_7, view_default_34, t_default_8, t_default_24, view_default_18, view_default_24, t_default_11, getitem_4, view_default_75, add_tensor_3, view_default_36, t_default_25, view_default_28, getitem_14, add_tensor_6, t_default_19, expand_default_7, primals_93, t_default_16, t_default_26, _unsafe_view_default_15, expand_default_17, view_default_57, view_default_51, primals_30, view_default_78, _unsafe_view_default_5, _softmax_default_1, primals_32, t_default_20, _unsafe_view_default_20, primals_29, view_default_52, _unsafe_view_default_8, view_default_60, add_tensor_8, view_default_54, primals_94, primals_80, t_default_17, add_tensor_2, view_default_82, getitem_16, view_default_30, _unsafe_view_default_21, primals_31, getitem_17, _unsafe_view_default_16, add_tensor_5, _unsafe_view_default_6, primals_79, expand_default_22, _softmax_default_4, _softmax_default_3, t_default_9, t_default_18, getitem_2, view_default_16, getitem_11, add_tensor_1, _softmax_default_5, view_default_15, getitem_10, view_default_14, primals_13, t_default_12, view_default_102, getitem_1, primals_95, t_default_13, expand_default_12, view_default_100, view_default_39, primals_96, add_tensor_10, t_default_5, t_default_14, t_default_33, primals_61, view_default_42, add_tensor_11, t_default_4, add_tensor_4, getitem_32, t_default_34, view_default_104, getitem_31, primals_47, view_default_64, view_default_105, primals_16, primals_46, _unsafe_view_default_18, t_default_35, view_default_66, getitem_34, primals_14, primals_45, getitem_35, primals_15, t_default_21, view_default_93, getitem_20, getitem_19, view_default_68, t_default_22, tangents_1):
        native_layer_norm_backward_default = torch.ops.aten.native_layer_norm_backward.default(tangents_1, add_tensor_11, [768], getitem_34, getitem_35, primals_94, primals_93, [True, True, True]);  tangents_1 = add_tensor_11 = getitem_34 = getitem_35 = primals_94 = primals_93 = None
        getitem_36 = native_layer_norm_backward_default[0]
        getitem_37 = native_layer_norm_backward_default[1]
        getitem_38 = native_layer_norm_backward_default[2];  native_layer_norm_backward_default = None
        view_default_108 = torch.ops.aten.view.default(getitem_36, [4096, 768])
        t_default_36 = torch.ops.aten.t.default(t_default_35);  t_default_35 = None
        mm_default = torch.ops.aten.mm.default(view_default_108, t_default_36);  t_default_36 = None
        t_default_37 = torch.ops.aten.t.default(view_default_108)
        mm_default_1 = torch.ops.aten.mm.default(t_default_37, view_default_106);  t_default_37 = view_default_106 = None
        t_default_38 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(view_default_108, [0], True);  view_default_108 = None
        view_default_109 = torch.ops.aten.view.default(sum_dim_int_list, [768]);  sum_dim_int_list = None
        t_default_39 = torch.ops.aten.t.default(t_default_38);  t_default_38 = None
        view_default_110 = torch.ops.aten.view.default(mm_default, [8, 512, 3072]);  mm_default = None
        to_dtype = torch.ops.aten.to.dtype(view_default_110, torch.float32);  view_default_110 = None
        to_dtype_1 = torch.ops.aten.to.dtype(view_default_105, torch.float32);  view_default_105 = None
        mul_tensor = torch.ops.aten.mul.Tensor(to_dtype_1, 0.7071067811865476)
        erf_default = torch.ops.aten.erf.default(mul_tensor);  mul_tensor = None
        add_tensor_12 = torch.ops.aten.add.Tensor(erf_default, 1);  erf_default = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(add_tensor_12, 0.5);  add_tensor_12 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(to_dtype_1, to_dtype_1)
        mul_tensor_3 = torch.ops.aten.mul.Tensor(mul_tensor_2, -0.5);  mul_tensor_2 = None
        exp_default = torch.ops.aten.exp.default(mul_tensor_3);  mul_tensor_3 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(exp_default, 0.3989422804014327);  exp_default = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(to_dtype_1, mul_tensor_4);  to_dtype_1 = mul_tensor_4 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(mul_tensor_1, mul_tensor_5);  mul_tensor_1 = mul_tensor_5 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(to_dtype, add_tensor_13);  to_dtype = add_tensor_13 = None
        to_dtype_2 = torch.ops.aten.to.dtype(mul_tensor_6, torch.float32);  mul_tensor_6 = None
        view_default_111 = torch.ops.aten.view.default(to_dtype_2, [4096, 3072]);  to_dtype_2 = None
        t_default_40 = torch.ops.aten.t.default(t_default_34);  t_default_34 = None
        mm_default_2 = torch.ops.aten.mm.default(view_default_111, t_default_40);  t_default_40 = None
        t_default_41 = torch.ops.aten.t.default(view_default_111)
        mm_default_3 = torch.ops.aten.mm.default(t_default_41, view_default_104);  t_default_41 = view_default_104 = None
        t_default_42 = torch.ops.aten.t.default(mm_default_3);  mm_default_3 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(view_default_111, [0], True);  view_default_111 = None
        view_default_112 = torch.ops.aten.view.default(sum_dim_int_list_1, [3072]);  sum_dim_int_list_1 = None
        t_default_43 = torch.ops.aten.t.default(t_default_42);  t_default_42 = None
        view_default_113 = torch.ops.aten.view.default(mm_default_2, [8, 512, 768]);  mm_default_2 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(getitem_36, view_default_113);  getitem_36 = view_default_113 = None
        native_layer_norm_backward_default_1 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_14, add_tensor_10, [768], getitem_31, getitem_32, primals_96, primals_95, [True, True, True]);  add_tensor_14 = add_tensor_10 = getitem_31 = getitem_32 = primals_96 = primals_95 = None
        getitem_39 = native_layer_norm_backward_default_1[0]
        getitem_40 = native_layer_norm_backward_default_1[1]
        getitem_41 = native_layer_norm_backward_default_1[2];  native_layer_norm_backward_default_1 = None
        view_default_114 = torch.ops.aten.view.default(getitem_39, [4096, 768])
        t_default_44 = torch.ops.aten.t.default(t_default_33);  t_default_33 = None
        mm_default_4 = torch.ops.aten.mm.default(view_default_114, t_default_44);  t_default_44 = None
        t_default_45 = torch.ops.aten.t.default(view_default_114)
        mm_default_5 = torch.ops.aten.mm.default(t_default_45, view_default_102);  t_default_45 = view_default_102 = None
        t_default_46 = torch.ops.aten.t.default(mm_default_5);  mm_default_5 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(view_default_114, [0], True);  view_default_114 = None
        view_default_115 = torch.ops.aten.view.default(sum_dim_int_list_2, [768]);  sum_dim_int_list_2 = None
        t_default_47 = torch.ops.aten.t.default(t_default_46);  t_default_46 = None
        view_default_116 = torch.ops.aten.view.default(mm_default_4, [8, 512, 768]);  mm_default_4 = None
        view_default_117 = torch.ops.aten.view.default(view_default_116, [8, 512, 12, 64]);  view_default_116 = None
        transpose_int_30 = torch.ops.aten.transpose.int(view_default_117, 1, 2);  view_default_117 = None
        clone_default_24 = torch.ops.aten.clone.default(transpose_int_30, memory_format = torch.contiguous_format);  transpose_int_30 = None
        _unsafe_view_default_30 = torch.ops.aten._unsafe_view.default(clone_default_24, [96, 512, 64]);  clone_default_24 = None
        transpose_int_31 = torch.ops.aten.transpose.int(view_default_100, 1, 2);  view_default_100 = None
        bmm_default_12 = torch.ops.aten.bmm.default(transpose_int_31, _unsafe_view_default_30);  transpose_int_31 = None
        transpose_int_32 = torch.ops.aten.transpose.int(_unsafe_view_default_28, 1, 2);  _unsafe_view_default_28 = None
        bmm_default_13 = torch.ops.aten.bmm.default(_unsafe_view_default_30, transpose_int_32);  _unsafe_view_default_30 = transpose_int_32 = None
        view_default_118 = torch.ops.aten.view.default(bmm_default_12, [8, 12, 512, 64]);  bmm_default_12 = None
        view_default_119 = torch.ops.aten.view.default(bmm_default_13, [8, 12, 512, 512]);  bmm_default_13 = None
        _softmax_backward_data_default = torch.ops.aten._softmax_backward_data.default(view_default_119, _softmax_default_5, -1, torch.float32);  view_default_119 = _softmax_default_5 = None
        where_scalar_self_6 = torch.ops.aten.where.ScalarSelf(expand_default_27, 0.0, _softmax_backward_data_default);  expand_default_27 = _softmax_backward_data_default = None
        view_default_120 = torch.ops.aten.view.default(where_scalar_self_6, [96, 512, 512]);  where_scalar_self_6 = None
        transpose_int_33 = torch.ops.aten.transpose.int(_unsafe_view_default_25, 1, 2);  _unsafe_view_default_25 = None
        bmm_default_14 = torch.ops.aten.bmm.default(transpose_int_33, view_default_120);  transpose_int_33 = None
        transpose_int_34 = torch.ops.aten.transpose.int(_unsafe_view_default_26, 1, 2);  _unsafe_view_default_26 = None
        bmm_default_15 = torch.ops.aten.bmm.default(view_default_120, transpose_int_34);  view_default_120 = transpose_int_34 = None
        view_default_121 = torch.ops.aten.view.default(bmm_default_14, [8, 12, 64, 512]);  bmm_default_14 = None
        view_default_122 = torch.ops.aten.view.default(bmm_default_15, [8, 12, 512, 64]);  bmm_default_15 = None
        transpose_int_35 = torch.ops.aten.transpose.int(view_default_121, 2, 3);  view_default_121 = None
        div_tensor_6 = torch.ops.aten.div.Tensor(view_default_122, 8.0);  view_default_122 = None
        transpose_int_36 = torch.ops.aten.transpose.int(view_default_118, 1, 2);  view_default_118 = None
        clone_default_25 = torch.ops.aten.clone.default(transpose_int_36, memory_format = torch.contiguous_format);  transpose_int_36 = None
        _unsafe_view_default_31 = torch.ops.aten._unsafe_view.default(clone_default_25, [8, 512, 768]);  clone_default_25 = None
        view_default_123 = torch.ops.aten.view.default(_unsafe_view_default_31, [4096, 768]);  _unsafe_view_default_31 = None
        t_default_48 = torch.ops.aten.t.default(t_default_32);  t_default_32 = None
        mm_default_6 = torch.ops.aten.mm.default(view_default_123, t_default_48);  t_default_48 = None
        t_default_49 = torch.ops.aten.t.default(view_default_123)
        mm_default_7 = torch.ops.aten.mm.default(t_default_49, view_default_96);  t_default_49 = view_default_96 = None
        t_default_50 = torch.ops.aten.t.default(mm_default_7);  mm_default_7 = None
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(view_default_123, [0], True);  view_default_123 = None
        view_default_124 = torch.ops.aten.view.default(sum_dim_int_list_3, [768]);  sum_dim_int_list_3 = None
        t_default_51 = torch.ops.aten.t.default(t_default_50);  t_default_50 = None
        view_default_125 = torch.ops.aten.view.default(mm_default_6, [8, 512, 768]);  mm_default_6 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(getitem_39, view_default_125);  getitem_39 = view_default_125 = None
        transpose_int_37 = torch.ops.aten.transpose.int(transpose_int_35, 1, 2);  transpose_int_35 = None
        view_default_126 = torch.ops.aten.view.default(transpose_int_37, [8, 512, 768]);  transpose_int_37 = None
        clone_default_26 = torch.ops.aten.clone.default(view_default_126, memory_format = torch.contiguous_format);  view_default_126 = None
        _unsafe_view_default_32 = torch.ops.aten._unsafe_view.default(clone_default_26, [4096, 768]);  clone_default_26 = None
        t_default_52 = torch.ops.aten.t.default(t_default_31);  t_default_31 = None
        mm_default_8 = torch.ops.aten.mm.default(_unsafe_view_default_32, t_default_52);  t_default_52 = None
        t_default_53 = torch.ops.aten.t.default(_unsafe_view_default_32)
        mm_default_9 = torch.ops.aten.mm.default(t_default_53, view_default_93);  t_default_53 = view_default_93 = None
        t_default_54 = torch.ops.aten.t.default(mm_default_9);  mm_default_9 = None
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_32, [0], True);  _unsafe_view_default_32 = None
        view_default_127 = torch.ops.aten.view.default(sum_dim_int_list_4, [768]);  sum_dim_int_list_4 = None
        t_default_55 = torch.ops.aten.t.default(t_default_54);  t_default_54 = None
        view_default_128 = torch.ops.aten.view.default(mm_default_8, [8, 512, 768]);  mm_default_8 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(add_tensor_15, view_default_128);  add_tensor_15 = view_default_128 = None
        transpose_int_38 = torch.ops.aten.transpose.int(div_tensor_6, 1, 2);  div_tensor_6 = None
        clone_default_27 = torch.ops.aten.clone.default(transpose_int_38, memory_format = torch.contiguous_format);  transpose_int_38 = None
        _unsafe_view_default_33 = torch.ops.aten._unsafe_view.default(clone_default_27, [8, 512, 768]);  clone_default_27 = None
        view_default_129 = torch.ops.aten.view.default(_unsafe_view_default_33, [4096, 768]);  _unsafe_view_default_33 = None
        t_default_56 = torch.ops.aten.t.default(t_default_30);  t_default_30 = None
        mm_default_10 = torch.ops.aten.mm.default(view_default_129, t_default_56);  t_default_56 = None
        t_default_57 = torch.ops.aten.t.default(view_default_129)
        mm_default_11 = torch.ops.aten.mm.default(t_default_57, view_default_90);  t_default_57 = view_default_90 = None
        t_default_58 = torch.ops.aten.t.default(mm_default_11);  mm_default_11 = None
        sum_dim_int_list_5 = torch.ops.aten.sum.dim_IntList(view_default_129, [0], True);  view_default_129 = None
        view_default_130 = torch.ops.aten.view.default(sum_dim_int_list_5, [768]);  sum_dim_int_list_5 = None
        t_default_59 = torch.ops.aten.t.default(t_default_58);  t_default_58 = None
        view_default_131 = torch.ops.aten.view.default(mm_default_10, [8, 512, 768]);  mm_default_10 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(add_tensor_16, view_default_131);  add_tensor_16 = view_default_131 = None
        native_layer_norm_backward_default_2 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_17, add_tensor_9, [768], getitem_28, getitem_29, primals_78, primals_77, [True, True, True]);  add_tensor_17 = add_tensor_9 = getitem_28 = getitem_29 = primals_78 = primals_77 = None
        getitem_42 = native_layer_norm_backward_default_2[0]
        getitem_43 = native_layer_norm_backward_default_2[1]
        getitem_44 = native_layer_norm_backward_default_2[2];  native_layer_norm_backward_default_2 = None
        view_default_132 = torch.ops.aten.view.default(getitem_42, [4096, 768])
        t_default_60 = torch.ops.aten.t.default(t_default_29);  t_default_29 = None
        mm_default_12 = torch.ops.aten.mm.default(view_default_132, t_default_60);  t_default_60 = None
        t_default_61 = torch.ops.aten.t.default(view_default_132)
        mm_default_13 = torch.ops.aten.mm.default(t_default_61, view_default_88);  t_default_61 = view_default_88 = None
        t_default_62 = torch.ops.aten.t.default(mm_default_13);  mm_default_13 = None
        sum_dim_int_list_6 = torch.ops.aten.sum.dim_IntList(view_default_132, [0], True);  view_default_132 = None
        view_default_133 = torch.ops.aten.view.default(sum_dim_int_list_6, [768]);  sum_dim_int_list_6 = None
        t_default_63 = torch.ops.aten.t.default(t_default_62);  t_default_62 = None
        view_default_134 = torch.ops.aten.view.default(mm_default_12, [8, 512, 3072]);  mm_default_12 = None
        to_dtype_3 = torch.ops.aten.to.dtype(view_default_134, torch.float32);  view_default_134 = None
        to_dtype_4 = torch.ops.aten.to.dtype(view_default_87, torch.float32);  view_default_87 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(to_dtype_4, 0.7071067811865476)
        erf_default_1 = torch.ops.aten.erf.default(mul_tensor_7);  mul_tensor_7 = None
        add_tensor_18 = torch.ops.aten.add.Tensor(erf_default_1, 1);  erf_default_1 = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(add_tensor_18, 0.5);  add_tensor_18 = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(to_dtype_4, to_dtype_4)
        mul_tensor_10 = torch.ops.aten.mul.Tensor(mul_tensor_9, -0.5);  mul_tensor_9 = None
        exp_default_1 = torch.ops.aten.exp.default(mul_tensor_10);  mul_tensor_10 = None
        mul_tensor_11 = torch.ops.aten.mul.Tensor(exp_default_1, 0.3989422804014327);  exp_default_1 = None
        mul_tensor_12 = torch.ops.aten.mul.Tensor(to_dtype_4, mul_tensor_11);  to_dtype_4 = mul_tensor_11 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(mul_tensor_8, mul_tensor_12);  mul_tensor_8 = mul_tensor_12 = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(to_dtype_3, add_tensor_19);  to_dtype_3 = add_tensor_19 = None
        to_dtype_5 = torch.ops.aten.to.dtype(mul_tensor_13, torch.float32);  mul_tensor_13 = None
        view_default_135 = torch.ops.aten.view.default(to_dtype_5, [4096, 3072]);  to_dtype_5 = None
        t_default_64 = torch.ops.aten.t.default(t_default_28);  t_default_28 = None
        mm_default_14 = torch.ops.aten.mm.default(view_default_135, t_default_64);  t_default_64 = None
        t_default_65 = torch.ops.aten.t.default(view_default_135)
        mm_default_15 = torch.ops.aten.mm.default(t_default_65, view_default_86);  t_default_65 = view_default_86 = None
        t_default_66 = torch.ops.aten.t.default(mm_default_15);  mm_default_15 = None
        sum_dim_int_list_7 = torch.ops.aten.sum.dim_IntList(view_default_135, [0], True);  view_default_135 = None
        view_default_136 = torch.ops.aten.view.default(sum_dim_int_list_7, [3072]);  sum_dim_int_list_7 = None
        t_default_67 = torch.ops.aten.t.default(t_default_66);  t_default_66 = None
        view_default_137 = torch.ops.aten.view.default(mm_default_14, [8, 512, 768]);  mm_default_14 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(getitem_42, view_default_137);  getitem_42 = view_default_137 = None
        native_layer_norm_backward_default_3 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_20, add_tensor_8, [768], getitem_25, getitem_26, primals_80, primals_79, [True, True, True]);  add_tensor_20 = add_tensor_8 = getitem_25 = getitem_26 = primals_80 = primals_79 = None
        getitem_45 = native_layer_norm_backward_default_3[0]
        getitem_46 = native_layer_norm_backward_default_3[1]
        getitem_47 = native_layer_norm_backward_default_3[2];  native_layer_norm_backward_default_3 = None
        view_default_138 = torch.ops.aten.view.default(getitem_45, [4096, 768])
        t_default_68 = torch.ops.aten.t.default(t_default_27);  t_default_27 = None
        mm_default_16 = torch.ops.aten.mm.default(view_default_138, t_default_68);  t_default_68 = None
        t_default_69 = torch.ops.aten.t.default(view_default_138)
        mm_default_17 = torch.ops.aten.mm.default(t_default_69, view_default_84);  t_default_69 = view_default_84 = None
        t_default_70 = torch.ops.aten.t.default(mm_default_17);  mm_default_17 = None
        sum_dim_int_list_8 = torch.ops.aten.sum.dim_IntList(view_default_138, [0], True);  view_default_138 = None
        view_default_139 = torch.ops.aten.view.default(sum_dim_int_list_8, [768]);  sum_dim_int_list_8 = None
        t_default_71 = torch.ops.aten.t.default(t_default_70);  t_default_70 = None
        view_default_140 = torch.ops.aten.view.default(mm_default_16, [8, 512, 768]);  mm_default_16 = None
        view_default_141 = torch.ops.aten.view.default(view_default_140, [8, 512, 12, 64]);  view_default_140 = None
        transpose_int_39 = torch.ops.aten.transpose.int(view_default_141, 1, 2);  view_default_141 = None
        clone_default_28 = torch.ops.aten.clone.default(transpose_int_39, memory_format = torch.contiguous_format);  transpose_int_39 = None
        _unsafe_view_default_34 = torch.ops.aten._unsafe_view.default(clone_default_28, [96, 512, 64]);  clone_default_28 = None
        transpose_int_40 = torch.ops.aten.transpose.int(view_default_82, 1, 2);  view_default_82 = None
        bmm_default_16 = torch.ops.aten.bmm.default(transpose_int_40, _unsafe_view_default_34);  transpose_int_40 = None
        transpose_int_41 = torch.ops.aten.transpose.int(_unsafe_view_default_23, 1, 2);  _unsafe_view_default_23 = None
        bmm_default_17 = torch.ops.aten.bmm.default(_unsafe_view_default_34, transpose_int_41);  _unsafe_view_default_34 = transpose_int_41 = None
        view_default_142 = torch.ops.aten.view.default(bmm_default_16, [8, 12, 512, 64]);  bmm_default_16 = None
        view_default_143 = torch.ops.aten.view.default(bmm_default_17, [8, 12, 512, 512]);  bmm_default_17 = None
        _softmax_backward_data_default_1 = torch.ops.aten._softmax_backward_data.default(view_default_143, _softmax_default_4, -1, torch.float32);  view_default_143 = _softmax_default_4 = None
        where_scalar_self_7 = torch.ops.aten.where.ScalarSelf(expand_default_22, 0.0, _softmax_backward_data_default_1);  expand_default_22 = _softmax_backward_data_default_1 = None
        view_default_144 = torch.ops.aten.view.default(where_scalar_self_7, [96, 512, 512]);  where_scalar_self_7 = None
        transpose_int_42 = torch.ops.aten.transpose.int(_unsafe_view_default_20, 1, 2);  _unsafe_view_default_20 = None
        bmm_default_18 = torch.ops.aten.bmm.default(transpose_int_42, view_default_144);  transpose_int_42 = None
        transpose_int_43 = torch.ops.aten.transpose.int(_unsafe_view_default_21, 1, 2);  _unsafe_view_default_21 = None
        bmm_default_19 = torch.ops.aten.bmm.default(view_default_144, transpose_int_43);  view_default_144 = transpose_int_43 = None
        view_default_145 = torch.ops.aten.view.default(bmm_default_18, [8, 12, 64, 512]);  bmm_default_18 = None
        view_default_146 = torch.ops.aten.view.default(bmm_default_19, [8, 12, 512, 64]);  bmm_default_19 = None
        transpose_int_44 = torch.ops.aten.transpose.int(view_default_145, 2, 3);  view_default_145 = None
        div_tensor_7 = torch.ops.aten.div.Tensor(view_default_146, 8.0);  view_default_146 = None
        transpose_int_45 = torch.ops.aten.transpose.int(view_default_142, 1, 2);  view_default_142 = None
        clone_default_29 = torch.ops.aten.clone.default(transpose_int_45, memory_format = torch.contiguous_format);  transpose_int_45 = None
        _unsafe_view_default_35 = torch.ops.aten._unsafe_view.default(clone_default_29, [8, 512, 768]);  clone_default_29 = None
        view_default_147 = torch.ops.aten.view.default(_unsafe_view_default_35, [4096, 768]);  _unsafe_view_default_35 = None
        t_default_72 = torch.ops.aten.t.default(t_default_26);  t_default_26 = None
        mm_default_18 = torch.ops.aten.mm.default(view_default_147, t_default_72);  t_default_72 = None
        t_default_73 = torch.ops.aten.t.default(view_default_147)
        mm_default_19 = torch.ops.aten.mm.default(t_default_73, view_default_78);  t_default_73 = view_default_78 = None
        t_default_74 = torch.ops.aten.t.default(mm_default_19);  mm_default_19 = None
        sum_dim_int_list_9 = torch.ops.aten.sum.dim_IntList(view_default_147, [0], True);  view_default_147 = None
        view_default_148 = torch.ops.aten.view.default(sum_dim_int_list_9, [768]);  sum_dim_int_list_9 = None
        t_default_75 = torch.ops.aten.t.default(t_default_74);  t_default_74 = None
        view_default_149 = torch.ops.aten.view.default(mm_default_18, [8, 512, 768]);  mm_default_18 = None
        add_tensor_21 = torch.ops.aten.add.Tensor(getitem_45, view_default_149);  getitem_45 = view_default_149 = None
        transpose_int_46 = torch.ops.aten.transpose.int(transpose_int_44, 1, 2);  transpose_int_44 = None
        view_default_150 = torch.ops.aten.view.default(transpose_int_46, [8, 512, 768]);  transpose_int_46 = None
        clone_default_30 = torch.ops.aten.clone.default(view_default_150, memory_format = torch.contiguous_format);  view_default_150 = None
        _unsafe_view_default_36 = torch.ops.aten._unsafe_view.default(clone_default_30, [4096, 768]);  clone_default_30 = None
        t_default_76 = torch.ops.aten.t.default(t_default_25);  t_default_25 = None
        mm_default_20 = torch.ops.aten.mm.default(_unsafe_view_default_36, t_default_76);  t_default_76 = None
        t_default_77 = torch.ops.aten.t.default(_unsafe_view_default_36)
        mm_default_21 = torch.ops.aten.mm.default(t_default_77, view_default_75);  t_default_77 = view_default_75 = None
        t_default_78 = torch.ops.aten.t.default(mm_default_21);  mm_default_21 = None
        sum_dim_int_list_10 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_36, [0], True);  _unsafe_view_default_36 = None
        view_default_151 = torch.ops.aten.view.default(sum_dim_int_list_10, [768]);  sum_dim_int_list_10 = None
        t_default_79 = torch.ops.aten.t.default(t_default_78);  t_default_78 = None
        view_default_152 = torch.ops.aten.view.default(mm_default_20, [8, 512, 768]);  mm_default_20 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(add_tensor_21, view_default_152);  add_tensor_21 = view_default_152 = None
        transpose_int_47 = torch.ops.aten.transpose.int(div_tensor_7, 1, 2);  div_tensor_7 = None
        clone_default_31 = torch.ops.aten.clone.default(transpose_int_47, memory_format = torch.contiguous_format);  transpose_int_47 = None
        _unsafe_view_default_37 = torch.ops.aten._unsafe_view.default(clone_default_31, [8, 512, 768]);  clone_default_31 = None
        view_default_153 = torch.ops.aten.view.default(_unsafe_view_default_37, [4096, 768]);  _unsafe_view_default_37 = None
        t_default_80 = torch.ops.aten.t.default(t_default_24);  t_default_24 = None
        mm_default_22 = torch.ops.aten.mm.default(view_default_153, t_default_80);  t_default_80 = None
        t_default_81 = torch.ops.aten.t.default(view_default_153)
        mm_default_23 = torch.ops.aten.mm.default(t_default_81, view_default_72);  t_default_81 = view_default_72 = None
        t_default_82 = torch.ops.aten.t.default(mm_default_23);  mm_default_23 = None
        sum_dim_int_list_11 = torch.ops.aten.sum.dim_IntList(view_default_153, [0], True);  view_default_153 = None
        view_default_154 = torch.ops.aten.view.default(sum_dim_int_list_11, [768]);  sum_dim_int_list_11 = None
        t_default_83 = torch.ops.aten.t.default(t_default_82);  t_default_82 = None
        view_default_155 = torch.ops.aten.view.default(mm_default_22, [8, 512, 768]);  mm_default_22 = None
        add_tensor_23 = torch.ops.aten.add.Tensor(add_tensor_22, view_default_155);  add_tensor_22 = view_default_155 = None
        native_layer_norm_backward_default_4 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_23, add_tensor_7, [768], getitem_22, getitem_23, primals_62, primals_61, [True, True, True]);  add_tensor_23 = add_tensor_7 = getitem_22 = getitem_23 = primals_62 = primals_61 = None
        getitem_48 = native_layer_norm_backward_default_4[0]
        getitem_49 = native_layer_norm_backward_default_4[1]
        getitem_50 = native_layer_norm_backward_default_4[2];  native_layer_norm_backward_default_4 = None
        view_default_156 = torch.ops.aten.view.default(getitem_48, [4096, 768])
        t_default_84 = torch.ops.aten.t.default(t_default_23);  t_default_23 = None
        mm_default_24 = torch.ops.aten.mm.default(view_default_156, t_default_84);  t_default_84 = None
        t_default_85 = torch.ops.aten.t.default(view_default_156)
        mm_default_25 = torch.ops.aten.mm.default(t_default_85, view_default_70);  t_default_85 = view_default_70 = None
        t_default_86 = torch.ops.aten.t.default(mm_default_25);  mm_default_25 = None
        sum_dim_int_list_12 = torch.ops.aten.sum.dim_IntList(view_default_156, [0], True);  view_default_156 = None
        view_default_157 = torch.ops.aten.view.default(sum_dim_int_list_12, [768]);  sum_dim_int_list_12 = None
        t_default_87 = torch.ops.aten.t.default(t_default_86);  t_default_86 = None
        view_default_158 = torch.ops.aten.view.default(mm_default_24, [8, 512, 3072]);  mm_default_24 = None
        to_dtype_6 = torch.ops.aten.to.dtype(view_default_158, torch.float32);  view_default_158 = None
        to_dtype_7 = torch.ops.aten.to.dtype(view_default_69, torch.float32);  view_default_69 = None
        mul_tensor_14 = torch.ops.aten.mul.Tensor(to_dtype_7, 0.7071067811865476)
        erf_default_2 = torch.ops.aten.erf.default(mul_tensor_14);  mul_tensor_14 = None
        add_tensor_24 = torch.ops.aten.add.Tensor(erf_default_2, 1);  erf_default_2 = None
        mul_tensor_15 = torch.ops.aten.mul.Tensor(add_tensor_24, 0.5);  add_tensor_24 = None
        mul_tensor_16 = torch.ops.aten.mul.Tensor(to_dtype_7, to_dtype_7)
        mul_tensor_17 = torch.ops.aten.mul.Tensor(mul_tensor_16, -0.5);  mul_tensor_16 = None
        exp_default_2 = torch.ops.aten.exp.default(mul_tensor_17);  mul_tensor_17 = None
        mul_tensor_18 = torch.ops.aten.mul.Tensor(exp_default_2, 0.3989422804014327);  exp_default_2 = None
        mul_tensor_19 = torch.ops.aten.mul.Tensor(to_dtype_7, mul_tensor_18);  to_dtype_7 = mul_tensor_18 = None
        add_tensor_25 = torch.ops.aten.add.Tensor(mul_tensor_15, mul_tensor_19);  mul_tensor_15 = mul_tensor_19 = None
        mul_tensor_20 = torch.ops.aten.mul.Tensor(to_dtype_6, add_tensor_25);  to_dtype_6 = add_tensor_25 = None
        to_dtype_8 = torch.ops.aten.to.dtype(mul_tensor_20, torch.float32);  mul_tensor_20 = None
        view_default_159 = torch.ops.aten.view.default(to_dtype_8, [4096, 3072]);  to_dtype_8 = None
        t_default_88 = torch.ops.aten.t.default(t_default_22);  t_default_22 = None
        mm_default_26 = torch.ops.aten.mm.default(view_default_159, t_default_88);  t_default_88 = None
        t_default_89 = torch.ops.aten.t.default(view_default_159)
        mm_default_27 = torch.ops.aten.mm.default(t_default_89, view_default_68);  t_default_89 = view_default_68 = None
        t_default_90 = torch.ops.aten.t.default(mm_default_27);  mm_default_27 = None
        sum_dim_int_list_13 = torch.ops.aten.sum.dim_IntList(view_default_159, [0], True);  view_default_159 = None
        view_default_160 = torch.ops.aten.view.default(sum_dim_int_list_13, [3072]);  sum_dim_int_list_13 = None
        t_default_91 = torch.ops.aten.t.default(t_default_90);  t_default_90 = None
        view_default_161 = torch.ops.aten.view.default(mm_default_26, [8, 512, 768]);  mm_default_26 = None
        add_tensor_26 = torch.ops.aten.add.Tensor(getitem_48, view_default_161);  getitem_48 = view_default_161 = None
        native_layer_norm_backward_default_5 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_26, add_tensor_6, [768], getitem_19, getitem_20, primals_64, primals_63, [True, True, True]);  add_tensor_26 = add_tensor_6 = getitem_19 = getitem_20 = primals_64 = primals_63 = None
        getitem_51 = native_layer_norm_backward_default_5[0]
        getitem_52 = native_layer_norm_backward_default_5[1]
        getitem_53 = native_layer_norm_backward_default_5[2];  native_layer_norm_backward_default_5 = None
        view_default_162 = torch.ops.aten.view.default(getitem_51, [4096, 768])
        t_default_92 = torch.ops.aten.t.default(t_default_21);  t_default_21 = None
        mm_default_28 = torch.ops.aten.mm.default(view_default_162, t_default_92);  t_default_92 = None
        t_default_93 = torch.ops.aten.t.default(view_default_162)
        mm_default_29 = torch.ops.aten.mm.default(t_default_93, view_default_66);  t_default_93 = view_default_66 = None
        t_default_94 = torch.ops.aten.t.default(mm_default_29);  mm_default_29 = None
        sum_dim_int_list_14 = torch.ops.aten.sum.dim_IntList(view_default_162, [0], True);  view_default_162 = None
        view_default_163 = torch.ops.aten.view.default(sum_dim_int_list_14, [768]);  sum_dim_int_list_14 = None
        t_default_95 = torch.ops.aten.t.default(t_default_94);  t_default_94 = None
        view_default_164 = torch.ops.aten.view.default(mm_default_28, [8, 512, 768]);  mm_default_28 = None
        view_default_165 = torch.ops.aten.view.default(view_default_164, [8, 512, 12, 64]);  view_default_164 = None
        transpose_int_48 = torch.ops.aten.transpose.int(view_default_165, 1, 2);  view_default_165 = None
        clone_default_32 = torch.ops.aten.clone.default(transpose_int_48, memory_format = torch.contiguous_format);  transpose_int_48 = None
        _unsafe_view_default_38 = torch.ops.aten._unsafe_view.default(clone_default_32, [96, 512, 64]);  clone_default_32 = None
        transpose_int_49 = torch.ops.aten.transpose.int(view_default_64, 1, 2);  view_default_64 = None
        bmm_default_20 = torch.ops.aten.bmm.default(transpose_int_49, _unsafe_view_default_38);  transpose_int_49 = None
        transpose_int_50 = torch.ops.aten.transpose.int(_unsafe_view_default_18, 1, 2);  _unsafe_view_default_18 = None
        bmm_default_21 = torch.ops.aten.bmm.default(_unsafe_view_default_38, transpose_int_50);  _unsafe_view_default_38 = transpose_int_50 = None
        view_default_166 = torch.ops.aten.view.default(bmm_default_20, [8, 12, 512, 64]);  bmm_default_20 = None
        view_default_167 = torch.ops.aten.view.default(bmm_default_21, [8, 12, 512, 512]);  bmm_default_21 = None
        _softmax_backward_data_default_2 = torch.ops.aten._softmax_backward_data.default(view_default_167, _softmax_default_3, -1, torch.float32);  view_default_167 = _softmax_default_3 = None
        where_scalar_self_8 = torch.ops.aten.where.ScalarSelf(expand_default_17, 0.0, _softmax_backward_data_default_2);  expand_default_17 = _softmax_backward_data_default_2 = None
        view_default_168 = torch.ops.aten.view.default(where_scalar_self_8, [96, 512, 512]);  where_scalar_self_8 = None
        transpose_int_51 = torch.ops.aten.transpose.int(_unsafe_view_default_15, 1, 2);  _unsafe_view_default_15 = None
        bmm_default_22 = torch.ops.aten.bmm.default(transpose_int_51, view_default_168);  transpose_int_51 = None
        transpose_int_52 = torch.ops.aten.transpose.int(_unsafe_view_default_16, 1, 2);  _unsafe_view_default_16 = None
        bmm_default_23 = torch.ops.aten.bmm.default(view_default_168, transpose_int_52);  view_default_168 = transpose_int_52 = None
        view_default_169 = torch.ops.aten.view.default(bmm_default_22, [8, 12, 64, 512]);  bmm_default_22 = None
        view_default_170 = torch.ops.aten.view.default(bmm_default_23, [8, 12, 512, 64]);  bmm_default_23 = None
        transpose_int_53 = torch.ops.aten.transpose.int(view_default_169, 2, 3);  view_default_169 = None
        div_tensor_8 = torch.ops.aten.div.Tensor(view_default_170, 8.0);  view_default_170 = None
        transpose_int_54 = torch.ops.aten.transpose.int(view_default_166, 1, 2);  view_default_166 = None
        clone_default_33 = torch.ops.aten.clone.default(transpose_int_54, memory_format = torch.contiguous_format);  transpose_int_54 = None
        _unsafe_view_default_39 = torch.ops.aten._unsafe_view.default(clone_default_33, [8, 512, 768]);  clone_default_33 = None
        view_default_171 = torch.ops.aten.view.default(_unsafe_view_default_39, [4096, 768]);  _unsafe_view_default_39 = None
        t_default_96 = torch.ops.aten.t.default(t_default_20);  t_default_20 = None
        mm_default_30 = torch.ops.aten.mm.default(view_default_171, t_default_96);  t_default_96 = None
        t_default_97 = torch.ops.aten.t.default(view_default_171)
        mm_default_31 = torch.ops.aten.mm.default(t_default_97, view_default_60);  t_default_97 = view_default_60 = None
        t_default_98 = torch.ops.aten.t.default(mm_default_31);  mm_default_31 = None
        sum_dim_int_list_15 = torch.ops.aten.sum.dim_IntList(view_default_171, [0], True);  view_default_171 = None
        view_default_172 = torch.ops.aten.view.default(sum_dim_int_list_15, [768]);  sum_dim_int_list_15 = None
        t_default_99 = torch.ops.aten.t.default(t_default_98);  t_default_98 = None
        view_default_173 = torch.ops.aten.view.default(mm_default_30, [8, 512, 768]);  mm_default_30 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(getitem_51, view_default_173);  getitem_51 = view_default_173 = None
        transpose_int_55 = torch.ops.aten.transpose.int(transpose_int_53, 1, 2);  transpose_int_53 = None
        view_default_174 = torch.ops.aten.view.default(transpose_int_55, [8, 512, 768]);  transpose_int_55 = None
        clone_default_34 = torch.ops.aten.clone.default(view_default_174, memory_format = torch.contiguous_format);  view_default_174 = None
        _unsafe_view_default_40 = torch.ops.aten._unsafe_view.default(clone_default_34, [4096, 768]);  clone_default_34 = None
        t_default_100 = torch.ops.aten.t.default(t_default_19);  t_default_19 = None
        mm_default_32 = torch.ops.aten.mm.default(_unsafe_view_default_40, t_default_100);  t_default_100 = None
        t_default_101 = torch.ops.aten.t.default(_unsafe_view_default_40)
        mm_default_33 = torch.ops.aten.mm.default(t_default_101, view_default_57);  t_default_101 = view_default_57 = None
        t_default_102 = torch.ops.aten.t.default(mm_default_33);  mm_default_33 = None
        sum_dim_int_list_16 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_40, [0], True);  _unsafe_view_default_40 = None
        view_default_175 = torch.ops.aten.view.default(sum_dim_int_list_16, [768]);  sum_dim_int_list_16 = None
        t_default_103 = torch.ops.aten.t.default(t_default_102);  t_default_102 = None
        view_default_176 = torch.ops.aten.view.default(mm_default_32, [8, 512, 768]);  mm_default_32 = None
        add_tensor_28 = torch.ops.aten.add.Tensor(add_tensor_27, view_default_176);  add_tensor_27 = view_default_176 = None
        transpose_int_56 = torch.ops.aten.transpose.int(div_tensor_8, 1, 2);  div_tensor_8 = None
        clone_default_35 = torch.ops.aten.clone.default(transpose_int_56, memory_format = torch.contiguous_format);  transpose_int_56 = None
        _unsafe_view_default_41 = torch.ops.aten._unsafe_view.default(clone_default_35, [8, 512, 768]);  clone_default_35 = None
        view_default_177 = torch.ops.aten.view.default(_unsafe_view_default_41, [4096, 768]);  _unsafe_view_default_41 = None
        t_default_104 = torch.ops.aten.t.default(t_default_18);  t_default_18 = None
        mm_default_34 = torch.ops.aten.mm.default(view_default_177, t_default_104);  t_default_104 = None
        t_default_105 = torch.ops.aten.t.default(view_default_177)
        mm_default_35 = torch.ops.aten.mm.default(t_default_105, view_default_54);  t_default_105 = view_default_54 = None
        t_default_106 = torch.ops.aten.t.default(mm_default_35);  mm_default_35 = None
        sum_dim_int_list_17 = torch.ops.aten.sum.dim_IntList(view_default_177, [0], True);  view_default_177 = None
        view_default_178 = torch.ops.aten.view.default(sum_dim_int_list_17, [768]);  sum_dim_int_list_17 = None
        t_default_107 = torch.ops.aten.t.default(t_default_106);  t_default_106 = None
        view_default_179 = torch.ops.aten.view.default(mm_default_34, [8, 512, 768]);  mm_default_34 = None
        add_tensor_29 = torch.ops.aten.add.Tensor(add_tensor_28, view_default_179);  add_tensor_28 = view_default_179 = None
        native_layer_norm_backward_default_6 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_29, add_tensor_5, [768], getitem_16, getitem_17, primals_46, primals_45, [True, True, True]);  add_tensor_29 = add_tensor_5 = getitem_16 = getitem_17 = primals_46 = primals_45 = None
        getitem_54 = native_layer_norm_backward_default_6[0]
        getitem_55 = native_layer_norm_backward_default_6[1]
        getitem_56 = native_layer_norm_backward_default_6[2];  native_layer_norm_backward_default_6 = None
        view_default_180 = torch.ops.aten.view.default(getitem_54, [4096, 768])
        t_default_108 = torch.ops.aten.t.default(t_default_17);  t_default_17 = None
        mm_default_36 = torch.ops.aten.mm.default(view_default_180, t_default_108);  t_default_108 = None
        t_default_109 = torch.ops.aten.t.default(view_default_180)
        mm_default_37 = torch.ops.aten.mm.default(t_default_109, view_default_52);  t_default_109 = view_default_52 = None
        t_default_110 = torch.ops.aten.t.default(mm_default_37);  mm_default_37 = None
        sum_dim_int_list_18 = torch.ops.aten.sum.dim_IntList(view_default_180, [0], True);  view_default_180 = None
        view_default_181 = torch.ops.aten.view.default(sum_dim_int_list_18, [768]);  sum_dim_int_list_18 = None
        t_default_111 = torch.ops.aten.t.default(t_default_110);  t_default_110 = None
        view_default_182 = torch.ops.aten.view.default(mm_default_36, [8, 512, 3072]);  mm_default_36 = None
        to_dtype_9 = torch.ops.aten.to.dtype(view_default_182, torch.float32);  view_default_182 = None
        to_dtype_10 = torch.ops.aten.to.dtype(view_default_51, torch.float32);  view_default_51 = None
        mul_tensor_21 = torch.ops.aten.mul.Tensor(to_dtype_10, 0.7071067811865476)
        erf_default_3 = torch.ops.aten.erf.default(mul_tensor_21);  mul_tensor_21 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(erf_default_3, 1);  erf_default_3 = None
        mul_tensor_22 = torch.ops.aten.mul.Tensor(add_tensor_30, 0.5);  add_tensor_30 = None
        mul_tensor_23 = torch.ops.aten.mul.Tensor(to_dtype_10, to_dtype_10)
        mul_tensor_24 = torch.ops.aten.mul.Tensor(mul_tensor_23, -0.5);  mul_tensor_23 = None
        exp_default_3 = torch.ops.aten.exp.default(mul_tensor_24);  mul_tensor_24 = None
        mul_tensor_25 = torch.ops.aten.mul.Tensor(exp_default_3, 0.3989422804014327);  exp_default_3 = None
        mul_tensor_26 = torch.ops.aten.mul.Tensor(to_dtype_10, mul_tensor_25);  to_dtype_10 = mul_tensor_25 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(mul_tensor_22, mul_tensor_26);  mul_tensor_22 = mul_tensor_26 = None
        mul_tensor_27 = torch.ops.aten.mul.Tensor(to_dtype_9, add_tensor_31);  to_dtype_9 = add_tensor_31 = None
        to_dtype_11 = torch.ops.aten.to.dtype(mul_tensor_27, torch.float32);  mul_tensor_27 = None
        view_default_183 = torch.ops.aten.view.default(to_dtype_11, [4096, 3072]);  to_dtype_11 = None
        t_default_112 = torch.ops.aten.t.default(t_default_16);  t_default_16 = None
        mm_default_38 = torch.ops.aten.mm.default(view_default_183, t_default_112);  t_default_112 = None
        t_default_113 = torch.ops.aten.t.default(view_default_183)
        mm_default_39 = torch.ops.aten.mm.default(t_default_113, view_default_50);  t_default_113 = view_default_50 = None
        t_default_114 = torch.ops.aten.t.default(mm_default_39);  mm_default_39 = None
        sum_dim_int_list_19 = torch.ops.aten.sum.dim_IntList(view_default_183, [0], True);  view_default_183 = None
        view_default_184 = torch.ops.aten.view.default(sum_dim_int_list_19, [3072]);  sum_dim_int_list_19 = None
        t_default_115 = torch.ops.aten.t.default(t_default_114);  t_default_114 = None
        view_default_185 = torch.ops.aten.view.default(mm_default_38, [8, 512, 768]);  mm_default_38 = None
        add_tensor_32 = torch.ops.aten.add.Tensor(getitem_54, view_default_185);  getitem_54 = view_default_185 = None
        native_layer_norm_backward_default_7 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_32, add_tensor_4, [768], getitem_13, getitem_14, primals_48, primals_47, [True, True, True]);  add_tensor_32 = add_tensor_4 = getitem_13 = getitem_14 = primals_48 = primals_47 = None
        getitem_57 = native_layer_norm_backward_default_7[0]
        getitem_58 = native_layer_norm_backward_default_7[1]
        getitem_59 = native_layer_norm_backward_default_7[2];  native_layer_norm_backward_default_7 = None
        view_default_186 = torch.ops.aten.view.default(getitem_57, [4096, 768])
        t_default_116 = torch.ops.aten.t.default(t_default_15);  t_default_15 = None
        mm_default_40 = torch.ops.aten.mm.default(view_default_186, t_default_116);  t_default_116 = None
        t_default_117 = torch.ops.aten.t.default(view_default_186)
        mm_default_41 = torch.ops.aten.mm.default(t_default_117, view_default_48);  t_default_117 = view_default_48 = None
        t_default_118 = torch.ops.aten.t.default(mm_default_41);  mm_default_41 = None
        sum_dim_int_list_20 = torch.ops.aten.sum.dim_IntList(view_default_186, [0], True);  view_default_186 = None
        view_default_187 = torch.ops.aten.view.default(sum_dim_int_list_20, [768]);  sum_dim_int_list_20 = None
        t_default_119 = torch.ops.aten.t.default(t_default_118);  t_default_118 = None
        view_default_188 = torch.ops.aten.view.default(mm_default_40, [8, 512, 768]);  mm_default_40 = None
        view_default_189 = torch.ops.aten.view.default(view_default_188, [8, 512, 12, 64]);  view_default_188 = None
        transpose_int_57 = torch.ops.aten.transpose.int(view_default_189, 1, 2);  view_default_189 = None
        clone_default_36 = torch.ops.aten.clone.default(transpose_int_57, memory_format = torch.contiguous_format);  transpose_int_57 = None
        _unsafe_view_default_42 = torch.ops.aten._unsafe_view.default(clone_default_36, [96, 512, 64]);  clone_default_36 = None
        transpose_int_58 = torch.ops.aten.transpose.int(view_default_46, 1, 2);  view_default_46 = None
        bmm_default_24 = torch.ops.aten.bmm.default(transpose_int_58, _unsafe_view_default_42);  transpose_int_58 = None
        transpose_int_59 = torch.ops.aten.transpose.int(_unsafe_view_default_13, 1, 2);  _unsafe_view_default_13 = None
        bmm_default_25 = torch.ops.aten.bmm.default(_unsafe_view_default_42, transpose_int_59);  _unsafe_view_default_42 = transpose_int_59 = None
        view_default_190 = torch.ops.aten.view.default(bmm_default_24, [8, 12, 512, 64]);  bmm_default_24 = None
        view_default_191 = torch.ops.aten.view.default(bmm_default_25, [8, 12, 512, 512]);  bmm_default_25 = None
        _softmax_backward_data_default_3 = torch.ops.aten._softmax_backward_data.default(view_default_191, _softmax_default_2, -1, torch.float32);  view_default_191 = _softmax_default_2 = None
        where_scalar_self_9 = torch.ops.aten.where.ScalarSelf(expand_default_12, 0.0, _softmax_backward_data_default_3);  expand_default_12 = _softmax_backward_data_default_3 = None
        view_default_192 = torch.ops.aten.view.default(where_scalar_self_9, [96, 512, 512]);  where_scalar_self_9 = None
        transpose_int_60 = torch.ops.aten.transpose.int(_unsafe_view_default_10, 1, 2);  _unsafe_view_default_10 = None
        bmm_default_26 = torch.ops.aten.bmm.default(transpose_int_60, view_default_192);  transpose_int_60 = None
        transpose_int_61 = torch.ops.aten.transpose.int(_unsafe_view_default_11, 1, 2);  _unsafe_view_default_11 = None
        bmm_default_27 = torch.ops.aten.bmm.default(view_default_192, transpose_int_61);  view_default_192 = transpose_int_61 = None
        view_default_193 = torch.ops.aten.view.default(bmm_default_26, [8, 12, 64, 512]);  bmm_default_26 = None
        view_default_194 = torch.ops.aten.view.default(bmm_default_27, [8, 12, 512, 64]);  bmm_default_27 = None
        transpose_int_62 = torch.ops.aten.transpose.int(view_default_193, 2, 3);  view_default_193 = None
        div_tensor_9 = torch.ops.aten.div.Tensor(view_default_194, 8.0);  view_default_194 = None
        transpose_int_63 = torch.ops.aten.transpose.int(view_default_190, 1, 2);  view_default_190 = None
        clone_default_37 = torch.ops.aten.clone.default(transpose_int_63, memory_format = torch.contiguous_format);  transpose_int_63 = None
        _unsafe_view_default_43 = torch.ops.aten._unsafe_view.default(clone_default_37, [8, 512, 768]);  clone_default_37 = None
        view_default_195 = torch.ops.aten.view.default(_unsafe_view_default_43, [4096, 768]);  _unsafe_view_default_43 = None
        t_default_120 = torch.ops.aten.t.default(t_default_14);  t_default_14 = None
        mm_default_42 = torch.ops.aten.mm.default(view_default_195, t_default_120);  t_default_120 = None
        t_default_121 = torch.ops.aten.t.default(view_default_195)
        mm_default_43 = torch.ops.aten.mm.default(t_default_121, view_default_42);  t_default_121 = view_default_42 = None
        t_default_122 = torch.ops.aten.t.default(mm_default_43);  mm_default_43 = None
        sum_dim_int_list_21 = torch.ops.aten.sum.dim_IntList(view_default_195, [0], True);  view_default_195 = None
        view_default_196 = torch.ops.aten.view.default(sum_dim_int_list_21, [768]);  sum_dim_int_list_21 = None
        t_default_123 = torch.ops.aten.t.default(t_default_122);  t_default_122 = None
        view_default_197 = torch.ops.aten.view.default(mm_default_42, [8, 512, 768]);  mm_default_42 = None
        add_tensor_33 = torch.ops.aten.add.Tensor(getitem_57, view_default_197);  getitem_57 = view_default_197 = None
        transpose_int_64 = torch.ops.aten.transpose.int(transpose_int_62, 1, 2);  transpose_int_62 = None
        view_default_198 = torch.ops.aten.view.default(transpose_int_64, [8, 512, 768]);  transpose_int_64 = None
        clone_default_38 = torch.ops.aten.clone.default(view_default_198, memory_format = torch.contiguous_format);  view_default_198 = None
        _unsafe_view_default_44 = torch.ops.aten._unsafe_view.default(clone_default_38, [4096, 768]);  clone_default_38 = None
        t_default_124 = torch.ops.aten.t.default(t_default_13);  t_default_13 = None
        mm_default_44 = torch.ops.aten.mm.default(_unsafe_view_default_44, t_default_124);  t_default_124 = None
        t_default_125 = torch.ops.aten.t.default(_unsafe_view_default_44)
        mm_default_45 = torch.ops.aten.mm.default(t_default_125, view_default_39);  t_default_125 = view_default_39 = None
        t_default_126 = torch.ops.aten.t.default(mm_default_45);  mm_default_45 = None
        sum_dim_int_list_22 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_44, [0], True);  _unsafe_view_default_44 = None
        view_default_199 = torch.ops.aten.view.default(sum_dim_int_list_22, [768]);  sum_dim_int_list_22 = None
        t_default_127 = torch.ops.aten.t.default(t_default_126);  t_default_126 = None
        view_default_200 = torch.ops.aten.view.default(mm_default_44, [8, 512, 768]);  mm_default_44 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(add_tensor_33, view_default_200);  add_tensor_33 = view_default_200 = None
        transpose_int_65 = torch.ops.aten.transpose.int(div_tensor_9, 1, 2);  div_tensor_9 = None
        clone_default_39 = torch.ops.aten.clone.default(transpose_int_65, memory_format = torch.contiguous_format);  transpose_int_65 = None
        _unsafe_view_default_45 = torch.ops.aten._unsafe_view.default(clone_default_39, [8, 512, 768]);  clone_default_39 = None
        view_default_201 = torch.ops.aten.view.default(_unsafe_view_default_45, [4096, 768]);  _unsafe_view_default_45 = None
        t_default_128 = torch.ops.aten.t.default(t_default_12);  t_default_12 = None
        mm_default_46 = torch.ops.aten.mm.default(view_default_201, t_default_128);  t_default_128 = None
        t_default_129 = torch.ops.aten.t.default(view_default_201)
        mm_default_47 = torch.ops.aten.mm.default(t_default_129, view_default_36);  t_default_129 = view_default_36 = None
        t_default_130 = torch.ops.aten.t.default(mm_default_47);  mm_default_47 = None
        sum_dim_int_list_23 = torch.ops.aten.sum.dim_IntList(view_default_201, [0], True);  view_default_201 = None
        view_default_202 = torch.ops.aten.view.default(sum_dim_int_list_23, [768]);  sum_dim_int_list_23 = None
        t_default_131 = torch.ops.aten.t.default(t_default_130);  t_default_130 = None
        view_default_203 = torch.ops.aten.view.default(mm_default_46, [8, 512, 768]);  mm_default_46 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(add_tensor_34, view_default_203);  add_tensor_34 = view_default_203 = None
        native_layer_norm_backward_default_8 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_35, add_tensor_3, [768], getitem_10, getitem_11, primals_30, primals_29, [True, True, True]);  add_tensor_35 = add_tensor_3 = getitem_10 = getitem_11 = primals_30 = primals_29 = None
        getitem_60 = native_layer_norm_backward_default_8[0]
        getitem_61 = native_layer_norm_backward_default_8[1]
        getitem_62 = native_layer_norm_backward_default_8[2];  native_layer_norm_backward_default_8 = None
        view_default_204 = torch.ops.aten.view.default(getitem_60, [4096, 768])
        t_default_132 = torch.ops.aten.t.default(t_default_11);  t_default_11 = None
        mm_default_48 = torch.ops.aten.mm.default(view_default_204, t_default_132);  t_default_132 = None
        t_default_133 = torch.ops.aten.t.default(view_default_204)
        mm_default_49 = torch.ops.aten.mm.default(t_default_133, view_default_34);  t_default_133 = view_default_34 = None
        t_default_134 = torch.ops.aten.t.default(mm_default_49);  mm_default_49 = None
        sum_dim_int_list_24 = torch.ops.aten.sum.dim_IntList(view_default_204, [0], True);  view_default_204 = None
        view_default_205 = torch.ops.aten.view.default(sum_dim_int_list_24, [768]);  sum_dim_int_list_24 = None
        t_default_135 = torch.ops.aten.t.default(t_default_134);  t_default_134 = None
        view_default_206 = torch.ops.aten.view.default(mm_default_48, [8, 512, 3072]);  mm_default_48 = None
        to_dtype_12 = torch.ops.aten.to.dtype(view_default_206, torch.float32);  view_default_206 = None
        to_dtype_13 = torch.ops.aten.to.dtype(view_default_33, torch.float32);  view_default_33 = None
        mul_tensor_28 = torch.ops.aten.mul.Tensor(to_dtype_13, 0.7071067811865476)
        erf_default_4 = torch.ops.aten.erf.default(mul_tensor_28);  mul_tensor_28 = None
        add_tensor_36 = torch.ops.aten.add.Tensor(erf_default_4, 1);  erf_default_4 = None
        mul_tensor_29 = torch.ops.aten.mul.Tensor(add_tensor_36, 0.5);  add_tensor_36 = None
        mul_tensor_30 = torch.ops.aten.mul.Tensor(to_dtype_13, to_dtype_13)
        mul_tensor_31 = torch.ops.aten.mul.Tensor(mul_tensor_30, -0.5);  mul_tensor_30 = None
        exp_default_4 = torch.ops.aten.exp.default(mul_tensor_31);  mul_tensor_31 = None
        mul_tensor_32 = torch.ops.aten.mul.Tensor(exp_default_4, 0.3989422804014327);  exp_default_4 = None
        mul_tensor_33 = torch.ops.aten.mul.Tensor(to_dtype_13, mul_tensor_32);  to_dtype_13 = mul_tensor_32 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(mul_tensor_29, mul_tensor_33);  mul_tensor_29 = mul_tensor_33 = None
        mul_tensor_34 = torch.ops.aten.mul.Tensor(to_dtype_12, add_tensor_37);  to_dtype_12 = add_tensor_37 = None
        to_dtype_14 = torch.ops.aten.to.dtype(mul_tensor_34, torch.float32);  mul_tensor_34 = None
        view_default_207 = torch.ops.aten.view.default(to_dtype_14, [4096, 3072]);  to_dtype_14 = None
        t_default_136 = torch.ops.aten.t.default(t_default_10);  t_default_10 = None
        mm_default_50 = torch.ops.aten.mm.default(view_default_207, t_default_136);  t_default_136 = None
        t_default_137 = torch.ops.aten.t.default(view_default_207)
        mm_default_51 = torch.ops.aten.mm.default(t_default_137, view_default_32);  t_default_137 = view_default_32 = None
        t_default_138 = torch.ops.aten.t.default(mm_default_51);  mm_default_51 = None
        sum_dim_int_list_25 = torch.ops.aten.sum.dim_IntList(view_default_207, [0], True);  view_default_207 = None
        view_default_208 = torch.ops.aten.view.default(sum_dim_int_list_25, [3072]);  sum_dim_int_list_25 = None
        t_default_139 = torch.ops.aten.t.default(t_default_138);  t_default_138 = None
        view_default_209 = torch.ops.aten.view.default(mm_default_50, [8, 512, 768]);  mm_default_50 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(getitem_60, view_default_209);  getitem_60 = view_default_209 = None
        native_layer_norm_backward_default_9 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_38, add_tensor_2, [768], getitem_7, getitem_8, primals_32, primals_31, [True, True, True]);  add_tensor_38 = add_tensor_2 = getitem_7 = getitem_8 = primals_32 = primals_31 = None
        getitem_63 = native_layer_norm_backward_default_9[0]
        getitem_64 = native_layer_norm_backward_default_9[1]
        getitem_65 = native_layer_norm_backward_default_9[2];  native_layer_norm_backward_default_9 = None
        view_default_210 = torch.ops.aten.view.default(getitem_63, [4096, 768])
        t_default_140 = torch.ops.aten.t.default(t_default_9);  t_default_9 = None
        mm_default_52 = torch.ops.aten.mm.default(view_default_210, t_default_140);  t_default_140 = None
        t_default_141 = torch.ops.aten.t.default(view_default_210)
        mm_default_53 = torch.ops.aten.mm.default(t_default_141, view_default_30);  t_default_141 = view_default_30 = None
        t_default_142 = torch.ops.aten.t.default(mm_default_53);  mm_default_53 = None
        sum_dim_int_list_26 = torch.ops.aten.sum.dim_IntList(view_default_210, [0], True);  view_default_210 = None
        view_default_211 = torch.ops.aten.view.default(sum_dim_int_list_26, [768]);  sum_dim_int_list_26 = None
        t_default_143 = torch.ops.aten.t.default(t_default_142);  t_default_142 = None
        view_default_212 = torch.ops.aten.view.default(mm_default_52, [8, 512, 768]);  mm_default_52 = None
        view_default_213 = torch.ops.aten.view.default(view_default_212, [8, 512, 12, 64]);  view_default_212 = None
        transpose_int_66 = torch.ops.aten.transpose.int(view_default_213, 1, 2);  view_default_213 = None
        clone_default_40 = torch.ops.aten.clone.default(transpose_int_66, memory_format = torch.contiguous_format);  transpose_int_66 = None
        _unsafe_view_default_46 = torch.ops.aten._unsafe_view.default(clone_default_40, [96, 512, 64]);  clone_default_40 = None
        transpose_int_67 = torch.ops.aten.transpose.int(view_default_28, 1, 2);  view_default_28 = None
        bmm_default_28 = torch.ops.aten.bmm.default(transpose_int_67, _unsafe_view_default_46);  transpose_int_67 = None
        transpose_int_68 = torch.ops.aten.transpose.int(_unsafe_view_default_8, 1, 2);  _unsafe_view_default_8 = None
        bmm_default_29 = torch.ops.aten.bmm.default(_unsafe_view_default_46, transpose_int_68);  _unsafe_view_default_46 = transpose_int_68 = None
        view_default_214 = torch.ops.aten.view.default(bmm_default_28, [8, 12, 512, 64]);  bmm_default_28 = None
        view_default_215 = torch.ops.aten.view.default(bmm_default_29, [8, 12, 512, 512]);  bmm_default_29 = None
        _softmax_backward_data_default_4 = torch.ops.aten._softmax_backward_data.default(view_default_215, _softmax_default_1, -1, torch.float32);  view_default_215 = _softmax_default_1 = None
        where_scalar_self_10 = torch.ops.aten.where.ScalarSelf(expand_default_7, 0.0, _softmax_backward_data_default_4);  expand_default_7 = _softmax_backward_data_default_4 = None
        view_default_216 = torch.ops.aten.view.default(where_scalar_self_10, [96, 512, 512]);  where_scalar_self_10 = None
        transpose_int_69 = torch.ops.aten.transpose.int(_unsafe_view_default_5, 1, 2);  _unsafe_view_default_5 = None
        bmm_default_30 = torch.ops.aten.bmm.default(transpose_int_69, view_default_216);  transpose_int_69 = None
        transpose_int_70 = torch.ops.aten.transpose.int(_unsafe_view_default_6, 1, 2);  _unsafe_view_default_6 = None
        bmm_default_31 = torch.ops.aten.bmm.default(view_default_216, transpose_int_70);  view_default_216 = transpose_int_70 = None
        view_default_217 = torch.ops.aten.view.default(bmm_default_30, [8, 12, 64, 512]);  bmm_default_30 = None
        view_default_218 = torch.ops.aten.view.default(bmm_default_31, [8, 12, 512, 64]);  bmm_default_31 = None
        transpose_int_71 = torch.ops.aten.transpose.int(view_default_217, 2, 3);  view_default_217 = None
        div_tensor_10 = torch.ops.aten.div.Tensor(view_default_218, 8.0);  view_default_218 = None
        transpose_int_72 = torch.ops.aten.transpose.int(view_default_214, 1, 2);  view_default_214 = None
        clone_default_41 = torch.ops.aten.clone.default(transpose_int_72, memory_format = torch.contiguous_format);  transpose_int_72 = None
        _unsafe_view_default_47 = torch.ops.aten._unsafe_view.default(clone_default_41, [8, 512, 768]);  clone_default_41 = None
        view_default_219 = torch.ops.aten.view.default(_unsafe_view_default_47, [4096, 768]);  _unsafe_view_default_47 = None
        t_default_144 = torch.ops.aten.t.default(t_default_8);  t_default_8 = None
        mm_default_54 = torch.ops.aten.mm.default(view_default_219, t_default_144);  t_default_144 = None
        t_default_145 = torch.ops.aten.t.default(view_default_219)
        mm_default_55 = torch.ops.aten.mm.default(t_default_145, view_default_24);  t_default_145 = view_default_24 = None
        t_default_146 = torch.ops.aten.t.default(mm_default_55);  mm_default_55 = None
        sum_dim_int_list_27 = torch.ops.aten.sum.dim_IntList(view_default_219, [0], True);  view_default_219 = None
        view_default_220 = torch.ops.aten.view.default(sum_dim_int_list_27, [768]);  sum_dim_int_list_27 = None
        t_default_147 = torch.ops.aten.t.default(t_default_146);  t_default_146 = None
        view_default_221 = torch.ops.aten.view.default(mm_default_54, [8, 512, 768]);  mm_default_54 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(getitem_63, view_default_221);  getitem_63 = view_default_221 = None
        transpose_int_73 = torch.ops.aten.transpose.int(transpose_int_71, 1, 2);  transpose_int_71 = None
        view_default_222 = torch.ops.aten.view.default(transpose_int_73, [8, 512, 768]);  transpose_int_73 = None
        clone_default_42 = torch.ops.aten.clone.default(view_default_222, memory_format = torch.contiguous_format);  view_default_222 = None
        _unsafe_view_default_48 = torch.ops.aten._unsafe_view.default(clone_default_42, [4096, 768]);  clone_default_42 = None
        t_default_148 = torch.ops.aten.t.default(t_default_7);  t_default_7 = None
        mm_default_56 = torch.ops.aten.mm.default(_unsafe_view_default_48, t_default_148);  t_default_148 = None
        t_default_149 = torch.ops.aten.t.default(_unsafe_view_default_48)
        mm_default_57 = torch.ops.aten.mm.default(t_default_149, view_default_21);  t_default_149 = view_default_21 = None
        t_default_150 = torch.ops.aten.t.default(mm_default_57);  mm_default_57 = None
        sum_dim_int_list_28 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_48, [0], True);  _unsafe_view_default_48 = None
        view_default_223 = torch.ops.aten.view.default(sum_dim_int_list_28, [768]);  sum_dim_int_list_28 = None
        t_default_151 = torch.ops.aten.t.default(t_default_150);  t_default_150 = None
        view_default_224 = torch.ops.aten.view.default(mm_default_56, [8, 512, 768]);  mm_default_56 = None
        add_tensor_40 = torch.ops.aten.add.Tensor(add_tensor_39, view_default_224);  add_tensor_39 = view_default_224 = None
        transpose_int_74 = torch.ops.aten.transpose.int(div_tensor_10, 1, 2);  div_tensor_10 = None
        clone_default_43 = torch.ops.aten.clone.default(transpose_int_74, memory_format = torch.contiguous_format);  transpose_int_74 = None
        _unsafe_view_default_49 = torch.ops.aten._unsafe_view.default(clone_default_43, [8, 512, 768]);  clone_default_43 = None
        view_default_225 = torch.ops.aten.view.default(_unsafe_view_default_49, [4096, 768]);  _unsafe_view_default_49 = None
        t_default_152 = torch.ops.aten.t.default(t_default_6);  t_default_6 = None
        mm_default_58 = torch.ops.aten.mm.default(view_default_225, t_default_152);  t_default_152 = None
        t_default_153 = torch.ops.aten.t.default(view_default_225)
        mm_default_59 = torch.ops.aten.mm.default(t_default_153, view_default_18);  t_default_153 = view_default_18 = None
        t_default_154 = torch.ops.aten.t.default(mm_default_59);  mm_default_59 = None
        sum_dim_int_list_29 = torch.ops.aten.sum.dim_IntList(view_default_225, [0], True);  view_default_225 = None
        view_default_226 = torch.ops.aten.view.default(sum_dim_int_list_29, [768]);  sum_dim_int_list_29 = None
        t_default_155 = torch.ops.aten.t.default(t_default_154);  t_default_154 = None
        view_default_227 = torch.ops.aten.view.default(mm_default_58, [8, 512, 768]);  mm_default_58 = None
        add_tensor_41 = torch.ops.aten.add.Tensor(add_tensor_40, view_default_227);  add_tensor_40 = view_default_227 = None
        native_layer_norm_backward_default_10 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_41, add_tensor_1, [768], getitem_4, getitem_5, primals_14, primals_13, [True, True, True]);  add_tensor_41 = add_tensor_1 = getitem_4 = getitem_5 = primals_14 = primals_13 = None
        getitem_66 = native_layer_norm_backward_default_10[0]
        getitem_67 = native_layer_norm_backward_default_10[1]
        getitem_68 = native_layer_norm_backward_default_10[2];  native_layer_norm_backward_default_10 = None
        view_default_228 = torch.ops.aten.view.default(getitem_66, [4096, 768])
        t_default_156 = torch.ops.aten.t.default(t_default_5);  t_default_5 = None
        mm_default_60 = torch.ops.aten.mm.default(view_default_228, t_default_156);  t_default_156 = None
        t_default_157 = torch.ops.aten.t.default(view_default_228)
        mm_default_61 = torch.ops.aten.mm.default(t_default_157, view_default_16);  t_default_157 = view_default_16 = None
        t_default_158 = torch.ops.aten.t.default(mm_default_61);  mm_default_61 = None
        sum_dim_int_list_30 = torch.ops.aten.sum.dim_IntList(view_default_228, [0], True);  view_default_228 = None
        view_default_229 = torch.ops.aten.view.default(sum_dim_int_list_30, [768]);  sum_dim_int_list_30 = None
        t_default_159 = torch.ops.aten.t.default(t_default_158);  t_default_158 = None
        view_default_230 = torch.ops.aten.view.default(mm_default_60, [8, 512, 3072]);  mm_default_60 = None
        to_dtype_15 = torch.ops.aten.to.dtype(view_default_230, torch.float32);  view_default_230 = None
        to_dtype_16 = torch.ops.aten.to.dtype(view_default_15, torch.float32);  view_default_15 = None
        mul_tensor_35 = torch.ops.aten.mul.Tensor(to_dtype_16, 0.7071067811865476)
        erf_default_5 = torch.ops.aten.erf.default(mul_tensor_35);  mul_tensor_35 = None
        add_tensor_42 = torch.ops.aten.add.Tensor(erf_default_5, 1);  erf_default_5 = None
        mul_tensor_36 = torch.ops.aten.mul.Tensor(add_tensor_42, 0.5);  add_tensor_42 = None
        mul_tensor_37 = torch.ops.aten.mul.Tensor(to_dtype_16, to_dtype_16)
        mul_tensor_38 = torch.ops.aten.mul.Tensor(mul_tensor_37, -0.5);  mul_tensor_37 = None
        exp_default_5 = torch.ops.aten.exp.default(mul_tensor_38);  mul_tensor_38 = None
        mul_tensor_39 = torch.ops.aten.mul.Tensor(exp_default_5, 0.3989422804014327);  exp_default_5 = None
        mul_tensor_40 = torch.ops.aten.mul.Tensor(to_dtype_16, mul_tensor_39);  to_dtype_16 = mul_tensor_39 = None
        add_tensor_43 = torch.ops.aten.add.Tensor(mul_tensor_36, mul_tensor_40);  mul_tensor_36 = mul_tensor_40 = None
        mul_tensor_41 = torch.ops.aten.mul.Tensor(to_dtype_15, add_tensor_43);  to_dtype_15 = add_tensor_43 = None
        to_dtype_17 = torch.ops.aten.to.dtype(mul_tensor_41, torch.float32);  mul_tensor_41 = None
        view_default_231 = torch.ops.aten.view.default(to_dtype_17, [4096, 3072]);  to_dtype_17 = None
        t_default_160 = torch.ops.aten.t.default(t_default_4);  t_default_4 = None
        mm_default_62 = torch.ops.aten.mm.default(view_default_231, t_default_160);  t_default_160 = None
        t_default_161 = torch.ops.aten.t.default(view_default_231)
        mm_default_63 = torch.ops.aten.mm.default(t_default_161, view_default_14);  t_default_161 = view_default_14 = None
        t_default_162 = torch.ops.aten.t.default(mm_default_63);  mm_default_63 = None
        sum_dim_int_list_31 = torch.ops.aten.sum.dim_IntList(view_default_231, [0], True);  view_default_231 = None
        view_default_232 = torch.ops.aten.view.default(sum_dim_int_list_31, [3072]);  sum_dim_int_list_31 = None
        t_default_163 = torch.ops.aten.t.default(t_default_162);  t_default_162 = None
        view_default_233 = torch.ops.aten.view.default(mm_default_62, [8, 512, 768]);  mm_default_62 = None
        add_tensor_44 = torch.ops.aten.add.Tensor(getitem_66, view_default_233);  getitem_66 = view_default_233 = None
        native_layer_norm_backward_default_11 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_44, add_tensor, [768], getitem_1, getitem_2, primals_16, primals_15, [True, True, True]);  add_tensor_44 = add_tensor = getitem_1 = getitem_2 = primals_16 = primals_15 = None
        getitem_69 = native_layer_norm_backward_default_11[0]
        getitem_70 = native_layer_norm_backward_default_11[1]
        getitem_71 = native_layer_norm_backward_default_11[2];  native_layer_norm_backward_default_11 = None
        view_default_234 = torch.ops.aten.view.default(getitem_69, [4096, 768])
        t_default_164 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        mm_default_64 = torch.ops.aten.mm.default(view_default_234, t_default_164);  t_default_164 = None
        t_default_165 = torch.ops.aten.t.default(view_default_234)
        mm_default_65 = torch.ops.aten.mm.default(t_default_165, view_default_12);  t_default_165 = view_default_12 = None
        t_default_166 = torch.ops.aten.t.default(mm_default_65);  mm_default_65 = None
        sum_dim_int_list_32 = torch.ops.aten.sum.dim_IntList(view_default_234, [0], True);  view_default_234 = None
        view_default_235 = torch.ops.aten.view.default(sum_dim_int_list_32, [768]);  sum_dim_int_list_32 = None
        t_default_167 = torch.ops.aten.t.default(t_default_166);  t_default_166 = None
        view_default_236 = torch.ops.aten.view.default(mm_default_64, [8, 512, 768]);  mm_default_64 = None
        view_default_237 = torch.ops.aten.view.default(view_default_236, [8, 512, 12, 64]);  view_default_236 = None
        transpose_int_75 = torch.ops.aten.transpose.int(view_default_237, 1, 2);  view_default_237 = None
        clone_default_44 = torch.ops.aten.clone.default(transpose_int_75, memory_format = torch.contiguous_format);  transpose_int_75 = None
        _unsafe_view_default_50 = torch.ops.aten._unsafe_view.default(clone_default_44, [96, 512, 64]);  clone_default_44 = None
        transpose_int_76 = torch.ops.aten.transpose.int(view_default_10, 1, 2);  view_default_10 = None
        bmm_default_32 = torch.ops.aten.bmm.default(transpose_int_76, _unsafe_view_default_50);  transpose_int_76 = None
        transpose_int_77 = torch.ops.aten.transpose.int(_unsafe_view_default_3, 1, 2);  _unsafe_view_default_3 = None
        bmm_default_33 = torch.ops.aten.bmm.default(_unsafe_view_default_50, transpose_int_77);  _unsafe_view_default_50 = transpose_int_77 = None
        view_default_238 = torch.ops.aten.view.default(bmm_default_32, [8, 12, 512, 64]);  bmm_default_32 = None
        view_default_239 = torch.ops.aten.view.default(bmm_default_33, [8, 12, 512, 512]);  bmm_default_33 = None
        _softmax_backward_data_default_5 = torch.ops.aten._softmax_backward_data.default(view_default_239, _softmax_default, -1, torch.float32);  view_default_239 = _softmax_default = None
        where_scalar_self_11 = torch.ops.aten.where.ScalarSelf(expand_default_2, 0.0, _softmax_backward_data_default_5);  expand_default_2 = _softmax_backward_data_default_5 = None
        view_default_240 = torch.ops.aten.view.default(where_scalar_self_11, [96, 512, 512]);  where_scalar_self_11 = None
        transpose_int_78 = torch.ops.aten.transpose.int(_unsafe_view_default, 1, 2);  _unsafe_view_default = None
        bmm_default_34 = torch.ops.aten.bmm.default(transpose_int_78, view_default_240);  transpose_int_78 = None
        transpose_int_79 = torch.ops.aten.transpose.int(_unsafe_view_default_1, 1, 2);  _unsafe_view_default_1 = None
        bmm_default_35 = torch.ops.aten.bmm.default(view_default_240, transpose_int_79);  view_default_240 = transpose_int_79 = None
        view_default_241 = torch.ops.aten.view.default(bmm_default_34, [8, 12, 64, 512]);  bmm_default_34 = None
        view_default_242 = torch.ops.aten.view.default(bmm_default_35, [8, 12, 512, 64]);  bmm_default_35 = None
        transpose_int_80 = torch.ops.aten.transpose.int(view_default_241, 2, 3);  view_default_241 = None
        div_tensor_11 = torch.ops.aten.div.Tensor(view_default_242, 8.0);  view_default_242 = None
        transpose_int_81 = torch.ops.aten.transpose.int(view_default_238, 1, 2);  view_default_238 = None
        clone_default_45 = torch.ops.aten.clone.default(transpose_int_81, memory_format = torch.contiguous_format);  transpose_int_81 = None
        _unsafe_view_default_51 = torch.ops.aten._unsafe_view.default(clone_default_45, [8, 512, 768]);  clone_default_45 = None
        view_default_243 = torch.ops.aten.view.default(_unsafe_view_default_51, [4096, 768]);  _unsafe_view_default_51 = None
        t_default_168 = torch.ops.aten.t.default(t_default_2);  t_default_2 = None
        mm_default_66 = torch.ops.aten.mm.default(view_default_243, t_default_168);  t_default_168 = None
        t_default_169 = torch.ops.aten.t.default(view_default_243)
        mm_default_67 = torch.ops.aten.mm.default(t_default_169, view_default_6);  t_default_169 = view_default_6 = None
        t_default_170 = torch.ops.aten.t.default(mm_default_67);  mm_default_67 = None
        sum_dim_int_list_33 = torch.ops.aten.sum.dim_IntList(view_default_243, [0], True);  view_default_243 = None
        view_default_244 = torch.ops.aten.view.default(sum_dim_int_list_33, [768]);  sum_dim_int_list_33 = None
        t_default_171 = torch.ops.aten.t.default(t_default_170);  t_default_170 = None
        view_default_245 = torch.ops.aten.view.default(mm_default_66, [8, 512, 768]);  mm_default_66 = None
        add_tensor_45 = torch.ops.aten.add.Tensor(getitem_69, view_default_245);  getitem_69 = view_default_245 = None
        transpose_int_82 = torch.ops.aten.transpose.int(transpose_int_80, 1, 2);  transpose_int_80 = None
        view_default_246 = torch.ops.aten.view.default(transpose_int_82, [8, 512, 768]);  transpose_int_82 = None
        clone_default_46 = torch.ops.aten.clone.default(view_default_246, memory_format = torch.contiguous_format);  view_default_246 = None
        _unsafe_view_default_52 = torch.ops.aten._unsafe_view.default(clone_default_46, [4096, 768]);  clone_default_46 = None
        t_default_172 = torch.ops.aten.t.default(t_default_1);  t_default_1 = None
        mm_default_68 = torch.ops.aten.mm.default(_unsafe_view_default_52, t_default_172);  t_default_172 = None
        t_default_173 = torch.ops.aten.t.default(_unsafe_view_default_52)
        mm_default_69 = torch.ops.aten.mm.default(t_default_173, view_default_3);  t_default_173 = view_default_3 = None
        t_default_174 = torch.ops.aten.t.default(mm_default_69);  mm_default_69 = None
        sum_dim_int_list_34 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_52, [0], True);  _unsafe_view_default_52 = None
        view_default_247 = torch.ops.aten.view.default(sum_dim_int_list_34, [768]);  sum_dim_int_list_34 = None
        t_default_175 = torch.ops.aten.t.default(t_default_174);  t_default_174 = None
        view_default_248 = torch.ops.aten.view.default(mm_default_68, [8, 512, 768]);  mm_default_68 = None
        add_tensor_46 = torch.ops.aten.add.Tensor(add_tensor_45, view_default_248);  add_tensor_45 = view_default_248 = None
        transpose_int_83 = torch.ops.aten.transpose.int(div_tensor_11, 1, 2);  div_tensor_11 = None
        clone_default_47 = torch.ops.aten.clone.default(transpose_int_83, memory_format = torch.contiguous_format);  transpose_int_83 = None
        _unsafe_view_default_53 = torch.ops.aten._unsafe_view.default(clone_default_47, [8, 512, 768]);  clone_default_47 = None
        view_default_249 = torch.ops.aten.view.default(_unsafe_view_default_53, [4096, 768]);  _unsafe_view_default_53 = None
        t_default_176 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default_70 = torch.ops.aten.mm.default(view_default_249, t_default_176);  t_default_176 = None
        t_default_177 = torch.ops.aten.t.default(view_default_249)
        mm_default_71 = torch.ops.aten.mm.default(t_default_177, view_default);  t_default_177 = view_default = None
        t_default_178 = torch.ops.aten.t.default(mm_default_71);  mm_default_71 = None
        sum_dim_int_list_35 = torch.ops.aten.sum.dim_IntList(view_default_249, [0], True);  view_default_249 = None
        view_default_250 = torch.ops.aten.view.default(sum_dim_int_list_35, [768]);  sum_dim_int_list_35 = None
        t_default_179 = torch.ops.aten.t.default(t_default_178);  t_default_178 = None
        view_default_251 = torch.ops.aten.view.default(mm_default_70, [8, 512, 768]);  mm_default_70 = None
        add_tensor_47 = torch.ops.aten.add.Tensor(add_tensor_46, view_default_251);  add_tensor_46 = view_default_251 = None
        return [view_default_247, t_default_175, view_default_235, t_default_167, view_default_250, t_default_179, view_default_244, t_default_171, view_default_232, t_default_163, view_default_229, t_default_159, getitem_68, getitem_67, getitem_71, getitem_70, view_default_223, t_default_151, view_default_211, t_default_143, view_default_226, t_default_155, view_default_220, t_default_147, view_default_208, t_default_139, view_default_205, t_default_135, getitem_62, getitem_61, getitem_65, getitem_64, view_default_199, t_default_127, view_default_187, t_default_119, view_default_202, t_default_131, view_default_196, t_default_123, view_default_184, t_default_115, view_default_181, t_default_111, getitem_56, getitem_55, getitem_59, getitem_58, view_default_175, t_default_103, view_default_163, t_default_95, view_default_178, t_default_107, view_default_172, t_default_99, view_default_160, t_default_91, view_default_157, t_default_87, getitem_50, getitem_49, getitem_53, getitem_52, view_default_151, t_default_79, view_default_139, t_default_71, view_default_154, t_default_83, view_default_148, t_default_75, view_default_136, t_default_67, view_default_133, t_default_63, getitem_44, getitem_43, getitem_47, getitem_46, view_default_127, t_default_55, view_default_115, t_default_47, view_default_130, t_default_59, view_default_124, t_default_51, view_default_112, t_default_43, view_default_109, t_default_39, getitem_38, getitem_37, getitem_41, getitem_40, add_tensor_47, None]
        
