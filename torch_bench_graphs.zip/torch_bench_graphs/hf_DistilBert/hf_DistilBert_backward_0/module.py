
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/hf_DistilBert/hf_DistilBert_backward_0/state_dict.pt'))

    
    
    def forward(self, add_tensor, primals_1, getitem_1, primals_2, slice_tensor, primals_6, getitem_2, tangents_1):
        native_layer_norm_backward_default = torch.ops.aten.native_layer_norm_backward.default(tangents_1, add_tensor, [768], getitem_1, getitem_2, primals_2, primals_1, [True, True, True]);  tangents_1 = add_tensor = getitem_1 = getitem_2 = primals_2 = primals_1 = None
        getitem_3 = native_layer_norm_backward_default[0]
        getitem_4 = native_layer_norm_backward_default[1]
        getitem_5 = native_layer_norm_backward_default[2];  native_layer_norm_backward_default = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(getitem_3, [0], True)
        embedding_dense_backward_default = torch.ops.aten.embedding_dense_backward.default(sum_dim_int_list, slice_tensor, 512, -1, False);  sum_dim_int_list = slice_tensor = None
        embedding_dense_backward_default_1 = torch.ops.aten.embedding_dense_backward.default(getitem_3, primals_6, 30522, 0, False);  getitem_3 = primals_6 = None
        return [getitem_5, getitem_4, embedding_dense_backward_default, None, embedding_dense_backward_default_1, None]
        
