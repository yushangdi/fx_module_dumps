
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/mobilenet_v2/mobilenet_v2_joint_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, tangents_1):
        convolution_default = torch.ops.aten.convolution.default(primals_315, primals_3, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_8, primals_4, primals_6, primals_7, False, 0.1, 1e-05);  primals_4 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        new_zeros_default = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_2 = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default = torch.ops.aten.clone.default(getitem)
        hardtanh__default = torch.ops.aten.hardtanh_.default(getitem, 0.0, 6.0);  getitem = None
        convolution_default_1 = torch.ops.aten.convolution.default(hardtanh__default, primals_159, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_164, primals_160, primals_162, primals_163, False, 0.1, 1e-05);  primals_160 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_5 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_1 = torch.ops.aten.clone.default(getitem_3)
        hardtanh__default_1 = torch.ops.aten.hardtanh_.default(getitem_3, 0.0, 6.0);  getitem_3 = None
        convolution_default_2 = torch.ops.aten.convolution.default(hardtanh__default_1, primals_165, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_170, primals_166, primals_168, primals_169, False, 0.1, 1e-05);  primals_166 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_8 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_3 = torch.ops.aten.convolution.default(getitem_6, primals_171, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_176, primals_172, primals_174, primals_175, False, 0.1, 1e-05);  primals_172 = None
        getitem_9 = native_batch_norm_default_3[0]
        getitem_10 = native_batch_norm_default_3[1]
        getitem_11 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        new_zeros_default_9 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_10 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_11 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_2 = torch.ops.aten.clone.default(getitem_9)
        hardtanh__default_2 = torch.ops.aten.hardtanh_.default(getitem_9, 0.0, 6.0);  getitem_9 = None
        convolution_default_4 = torch.ops.aten.convolution.default(hardtanh__default_2, primals_177, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 96)
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_182, primals_178, primals_180, primals_181, False, 0.1, 1e-05);  primals_178 = None
        getitem_12 = native_batch_norm_default_4[0]
        getitem_13 = native_batch_norm_default_4[1]
        getitem_14 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        new_zeros_default_12 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_13 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_14 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_3 = torch.ops.aten.clone.default(getitem_12)
        hardtanh__default_3 = torch.ops.aten.hardtanh_.default(getitem_12, 0.0, 6.0);  getitem_12 = None
        convolution_default_5 = torch.ops.aten.convolution.default(hardtanh__default_3, primals_183, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_188, primals_184, primals_186, primals_187, False, 0.1, 1e-05);  primals_184 = None
        getitem_15 = native_batch_norm_default_5[0]
        getitem_16 = native_batch_norm_default_5[1]
        getitem_17 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        new_zeros_default_15 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_16 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_17 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_6 = torch.ops.aten.convolution.default(getitem_15, primals_189, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_194, primals_190, primals_192, primals_193, False, 0.1, 1e-05);  primals_190 = None
        getitem_18 = native_batch_norm_default_6[0]
        getitem_19 = native_batch_norm_default_6[1]
        getitem_20 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        new_zeros_default_18 = torch.ops.aten.new_zeros.default(convolution_default_6, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_19 = torch.ops.aten.new_zeros.default(convolution_default_6, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_20 = torch.ops.aten.new_zeros.default(convolution_default_6, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_4 = torch.ops.aten.clone.default(getitem_18)
        hardtanh__default_4 = torch.ops.aten.hardtanh_.default(getitem_18, 0.0, 6.0);  getitem_18 = None
        convolution_default_7 = torch.ops.aten.convolution.default(hardtanh__default_4, primals_195, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 144)
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_200, primals_196, primals_198, primals_199, False, 0.1, 1e-05);  primals_196 = None
        getitem_21 = native_batch_norm_default_7[0]
        getitem_22 = native_batch_norm_default_7[1]
        getitem_23 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        new_zeros_default_21 = torch.ops.aten.new_zeros.default(convolution_default_7, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_22 = torch.ops.aten.new_zeros.default(convolution_default_7, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_23 = torch.ops.aten.new_zeros.default(convolution_default_7, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_5 = torch.ops.aten.clone.default(getitem_21)
        hardtanh__default_5 = torch.ops.aten.hardtanh_.default(getitem_21, 0.0, 6.0);  getitem_21 = None
        convolution_default_8 = torch.ops.aten.convolution.default(hardtanh__default_5, primals_201, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_206, primals_202, primals_204, primals_205, False, 0.1, 1e-05);  primals_202 = None
        getitem_24 = native_batch_norm_default_8[0]
        getitem_25 = native_batch_norm_default_8[1]
        getitem_26 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        new_zeros_default_24 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_25 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_26 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor = torch.ops.aten.add.Tensor(getitem_15, getitem_24);  getitem_24 = None
        convolution_default_9 = torch.ops.aten.convolution.default(add_tensor, primals_207, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_212, primals_208, primals_210, primals_211, False, 0.1, 1e-05);  primals_208 = None
        getitem_27 = native_batch_norm_default_9[0]
        getitem_28 = native_batch_norm_default_9[1]
        getitem_29 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        new_zeros_default_27 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_28 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_29 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_6 = torch.ops.aten.clone.default(getitem_27)
        hardtanh__default_6 = torch.ops.aten.hardtanh_.default(getitem_27, 0.0, 6.0);  getitem_27 = None
        convolution_default_10 = torch.ops.aten.convolution.default(hardtanh__default_6, primals_213, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 144)
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_218, primals_214, primals_216, primals_217, False, 0.1, 1e-05);  primals_214 = None
        getitem_30 = native_batch_norm_default_10[0]
        getitem_31 = native_batch_norm_default_10[1]
        getitem_32 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        new_zeros_default_30 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_31 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_32 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_7 = torch.ops.aten.clone.default(getitem_30)
        hardtanh__default_7 = torch.ops.aten.hardtanh_.default(getitem_30, 0.0, 6.0);  getitem_30 = None
        convolution_default_11 = torch.ops.aten.convolution.default(hardtanh__default_7, primals_219, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_224, primals_220, primals_222, primals_223, False, 0.1, 1e-05);  primals_220 = None
        getitem_33 = native_batch_norm_default_11[0]
        getitem_34 = native_batch_norm_default_11[1]
        getitem_35 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        new_zeros_default_33 = torch.ops.aten.new_zeros.default(convolution_default_11, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_34 = torch.ops.aten.new_zeros.default(convolution_default_11, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_35 = torch.ops.aten.new_zeros.default(convolution_default_11, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_12 = torch.ops.aten.convolution.default(getitem_33, primals_225, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_230, primals_226, primals_228, primals_229, False, 0.1, 1e-05);  primals_226 = None
        getitem_36 = native_batch_norm_default_12[0]
        getitem_37 = native_batch_norm_default_12[1]
        getitem_38 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        new_zeros_default_36 = torch.ops.aten.new_zeros.default(convolution_default_12, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_37 = torch.ops.aten.new_zeros.default(convolution_default_12, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_38 = torch.ops.aten.new_zeros.default(convolution_default_12, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_8 = torch.ops.aten.clone.default(getitem_36)
        hardtanh__default_8 = torch.ops.aten.hardtanh_.default(getitem_36, 0.0, 6.0);  getitem_36 = None
        convolution_default_13 = torch.ops.aten.convolution.default(hardtanh__default_8, primals_231, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 192)
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_236, primals_232, primals_234, primals_235, False, 0.1, 1e-05);  primals_232 = None
        getitem_39 = native_batch_norm_default_13[0]
        getitem_40 = native_batch_norm_default_13[1]
        getitem_41 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        new_zeros_default_39 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_40 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_41 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_9 = torch.ops.aten.clone.default(getitem_39)
        hardtanh__default_9 = torch.ops.aten.hardtanh_.default(getitem_39, 0.0, 6.0);  getitem_39 = None
        convolution_default_14 = torch.ops.aten.convolution.default(hardtanh__default_9, primals_237, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_242, primals_238, primals_240, primals_241, False, 0.1, 1e-05);  primals_238 = None
        getitem_42 = native_batch_norm_default_14[0]
        getitem_43 = native_batch_norm_default_14[1]
        getitem_44 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        new_zeros_default_42 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_43 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_44 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_1 = torch.ops.aten.add.Tensor(getitem_33, getitem_42);  getitem_42 = None
        convolution_default_15 = torch.ops.aten.convolution.default(add_tensor_1, primals_243, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_248, primals_244, primals_246, primals_247, False, 0.1, 1e-05);  primals_244 = None
        getitem_45 = native_batch_norm_default_15[0]
        getitem_46 = native_batch_norm_default_15[1]
        getitem_47 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        new_zeros_default_45 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_46 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_47 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_10 = torch.ops.aten.clone.default(getitem_45)
        hardtanh__default_10 = torch.ops.aten.hardtanh_.default(getitem_45, 0.0, 6.0);  getitem_45 = None
        convolution_default_16 = torch.ops.aten.convolution.default(hardtanh__default_10, primals_249, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 192)
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_254, primals_250, primals_252, primals_253, False, 0.1, 1e-05);  primals_250 = None
        getitem_48 = native_batch_norm_default_16[0]
        getitem_49 = native_batch_norm_default_16[1]
        getitem_50 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        new_zeros_default_48 = torch.ops.aten.new_zeros.default(convolution_default_16, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_49 = torch.ops.aten.new_zeros.default(convolution_default_16, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_50 = torch.ops.aten.new_zeros.default(convolution_default_16, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_11 = torch.ops.aten.clone.default(getitem_48)
        hardtanh__default_11 = torch.ops.aten.hardtanh_.default(getitem_48, 0.0, 6.0);  getitem_48 = None
        convolution_default_17 = torch.ops.aten.convolution.default(hardtanh__default_11, primals_255, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_260, primals_256, primals_258, primals_259, False, 0.1, 1e-05);  primals_256 = None
        getitem_51 = native_batch_norm_default_17[0]
        getitem_52 = native_batch_norm_default_17[1]
        getitem_53 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        new_zeros_default_51 = torch.ops.aten.new_zeros.default(convolution_default_17, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_52 = torch.ops.aten.new_zeros.default(convolution_default_17, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_53 = torch.ops.aten.new_zeros.default(convolution_default_17, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_2 = torch.ops.aten.add.Tensor(add_tensor_1, getitem_51);  getitem_51 = None
        convolution_default_18 = torch.ops.aten.convolution.default(add_tensor_2, primals_261, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_266, primals_262, primals_264, primals_265, False, 0.1, 1e-05);  primals_262 = None
        getitem_54 = native_batch_norm_default_18[0]
        getitem_55 = native_batch_norm_default_18[1]
        getitem_56 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        new_zeros_default_54 = torch.ops.aten.new_zeros.default(convolution_default_18, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_55 = torch.ops.aten.new_zeros.default(convolution_default_18, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_56 = torch.ops.aten.new_zeros.default(convolution_default_18, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_12 = torch.ops.aten.clone.default(getitem_54)
        hardtanh__default_12 = torch.ops.aten.hardtanh_.default(getitem_54, 0.0, 6.0);  getitem_54 = None
        convolution_default_19 = torch.ops.aten.convolution.default(hardtanh__default_12, primals_267, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 192)
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_272, primals_268, primals_270, primals_271, False, 0.1, 1e-05);  primals_268 = None
        getitem_57 = native_batch_norm_default_19[0]
        getitem_58 = native_batch_norm_default_19[1]
        getitem_59 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        new_zeros_default_57 = torch.ops.aten.new_zeros.default(convolution_default_19, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_58 = torch.ops.aten.new_zeros.default(convolution_default_19, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_59 = torch.ops.aten.new_zeros.default(convolution_default_19, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_13 = torch.ops.aten.clone.default(getitem_57)
        hardtanh__default_13 = torch.ops.aten.hardtanh_.default(getitem_57, 0.0, 6.0);  getitem_57 = None
        convolution_default_20 = torch.ops.aten.convolution.default(hardtanh__default_13, primals_273, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_278, primals_274, primals_276, primals_277, False, 0.1, 1e-05);  primals_274 = None
        getitem_60 = native_batch_norm_default_20[0]
        getitem_61 = native_batch_norm_default_20[1]
        getitem_62 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        new_zeros_default_60 = torch.ops.aten.new_zeros.default(convolution_default_20, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_61 = torch.ops.aten.new_zeros.default(convolution_default_20, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_62 = torch.ops.aten.new_zeros.default(convolution_default_20, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_21 = torch.ops.aten.convolution.default(getitem_60, primals_279, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_284, primals_280, primals_282, primals_283, False, 0.1, 1e-05);  primals_280 = None
        getitem_63 = native_batch_norm_default_21[0]
        getitem_64 = native_batch_norm_default_21[1]
        getitem_65 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        new_zeros_default_63 = torch.ops.aten.new_zeros.default(convolution_default_21, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_64 = torch.ops.aten.new_zeros.default(convolution_default_21, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_65 = torch.ops.aten.new_zeros.default(convolution_default_21, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_14 = torch.ops.aten.clone.default(getitem_63)
        hardtanh__default_14 = torch.ops.aten.hardtanh_.default(getitem_63, 0.0, 6.0);  getitem_63 = None
        convolution_default_22 = torch.ops.aten.convolution.default(hardtanh__default_14, primals_285, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 384)
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_290, primals_286, primals_288, primals_289, False, 0.1, 1e-05);  primals_286 = None
        getitem_66 = native_batch_norm_default_22[0]
        getitem_67 = native_batch_norm_default_22[1]
        getitem_68 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        new_zeros_default_66 = torch.ops.aten.new_zeros.default(convolution_default_22, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_67 = torch.ops.aten.new_zeros.default(convolution_default_22, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_68 = torch.ops.aten.new_zeros.default(convolution_default_22, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_15 = torch.ops.aten.clone.default(getitem_66)
        hardtanh__default_15 = torch.ops.aten.hardtanh_.default(getitem_66, 0.0, 6.0);  getitem_66 = None
        convolution_default_23 = torch.ops.aten.convolution.default(hardtanh__default_15, primals_291, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_296, primals_292, primals_294, primals_295, False, 0.1, 1e-05);  primals_292 = None
        getitem_69 = native_batch_norm_default_23[0]
        getitem_70 = native_batch_norm_default_23[1]
        getitem_71 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        new_zeros_default_69 = torch.ops.aten.new_zeros.default(convolution_default_23, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_70 = torch.ops.aten.new_zeros.default(convolution_default_23, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_71 = torch.ops.aten.new_zeros.default(convolution_default_23, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_3 = torch.ops.aten.add.Tensor(getitem_60, getitem_69);  getitem_69 = None
        convolution_default_24 = torch.ops.aten.convolution.default(add_tensor_3, primals_297, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_302, primals_298, primals_300, primals_301, False, 0.1, 1e-05);  primals_298 = None
        getitem_72 = native_batch_norm_default_24[0]
        getitem_73 = native_batch_norm_default_24[1]
        getitem_74 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        new_zeros_default_72 = torch.ops.aten.new_zeros.default(convolution_default_24, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_73 = torch.ops.aten.new_zeros.default(convolution_default_24, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_74 = torch.ops.aten.new_zeros.default(convolution_default_24, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_16 = torch.ops.aten.clone.default(getitem_72)
        hardtanh__default_16 = torch.ops.aten.hardtanh_.default(getitem_72, 0.0, 6.0);  getitem_72 = None
        convolution_default_25 = torch.ops.aten.convolution.default(hardtanh__default_16, primals_303, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 384)
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_308, primals_304, primals_306, primals_307, False, 0.1, 1e-05);  primals_304 = None
        getitem_75 = native_batch_norm_default_25[0]
        getitem_76 = native_batch_norm_default_25[1]
        getitem_77 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        new_zeros_default_75 = torch.ops.aten.new_zeros.default(convolution_default_25, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_76 = torch.ops.aten.new_zeros.default(convolution_default_25, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_77 = torch.ops.aten.new_zeros.default(convolution_default_25, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_17 = torch.ops.aten.clone.default(getitem_75)
        hardtanh__default_17 = torch.ops.aten.hardtanh_.default(getitem_75, 0.0, 6.0);  getitem_75 = None
        convolution_default_26 = torch.ops.aten.convolution.default(hardtanh__default_17, primals_309, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_314, primals_310, primals_312, primals_313, False, 0.1, 1e-05);  primals_310 = None
        getitem_78 = native_batch_norm_default_26[0]
        getitem_79 = native_batch_norm_default_26[1]
        getitem_80 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        new_zeros_default_78 = torch.ops.aten.new_zeros.default(convolution_default_26, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_79 = torch.ops.aten.new_zeros.default(convolution_default_26, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_80 = torch.ops.aten.new_zeros.default(convolution_default_26, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_4 = torch.ops.aten.add.Tensor(add_tensor_3, getitem_78);  getitem_78 = None
        convolution_default_27 = torch.ops.aten.convolution.default(add_tensor_4, primals_9, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_14, primals_10, primals_12, primals_13, False, 0.1, 1e-05);  primals_10 = None
        getitem_81 = native_batch_norm_default_27[0]
        getitem_82 = native_batch_norm_default_27[1]
        getitem_83 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        new_zeros_default_81 = torch.ops.aten.new_zeros.default(convolution_default_27, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_82 = torch.ops.aten.new_zeros.default(convolution_default_27, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_83 = torch.ops.aten.new_zeros.default(convolution_default_27, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_18 = torch.ops.aten.clone.default(getitem_81)
        hardtanh__default_18 = torch.ops.aten.hardtanh_.default(getitem_81, 0.0, 6.0);  getitem_81 = None
        convolution_default_28 = torch.ops.aten.convolution.default(hardtanh__default_18, primals_15, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 384)
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_20, primals_16, primals_18, primals_19, False, 0.1, 1e-05);  primals_16 = None
        getitem_84 = native_batch_norm_default_28[0]
        getitem_85 = native_batch_norm_default_28[1]
        getitem_86 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        new_zeros_default_84 = torch.ops.aten.new_zeros.default(convolution_default_28, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_85 = torch.ops.aten.new_zeros.default(convolution_default_28, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_86 = torch.ops.aten.new_zeros.default(convolution_default_28, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_19 = torch.ops.aten.clone.default(getitem_84)
        hardtanh__default_19 = torch.ops.aten.hardtanh_.default(getitem_84, 0.0, 6.0);  getitem_84 = None
        convolution_default_29 = torch.ops.aten.convolution.default(hardtanh__default_19, primals_21, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_26, primals_22, primals_24, primals_25, False, 0.1, 1e-05);  primals_22 = None
        getitem_87 = native_batch_norm_default_29[0]
        getitem_88 = native_batch_norm_default_29[1]
        getitem_89 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        new_zeros_default_87 = torch.ops.aten.new_zeros.default(convolution_default_29, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_88 = torch.ops.aten.new_zeros.default(convolution_default_29, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_89 = torch.ops.aten.new_zeros.default(convolution_default_29, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_5 = torch.ops.aten.add.Tensor(add_tensor_4, getitem_87);  getitem_87 = None
        convolution_default_30 = torch.ops.aten.convolution.default(add_tensor_5, primals_27, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_32, primals_28, primals_30, primals_31, False, 0.1, 1e-05);  primals_28 = None
        getitem_90 = native_batch_norm_default_30[0]
        getitem_91 = native_batch_norm_default_30[1]
        getitem_92 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        new_zeros_default_90 = torch.ops.aten.new_zeros.default(convolution_default_30, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_91 = torch.ops.aten.new_zeros.default(convolution_default_30, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_92 = torch.ops.aten.new_zeros.default(convolution_default_30, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_20 = torch.ops.aten.clone.default(getitem_90)
        hardtanh__default_20 = torch.ops.aten.hardtanh_.default(getitem_90, 0.0, 6.0);  getitem_90 = None
        convolution_default_31 = torch.ops.aten.convolution.default(hardtanh__default_20, primals_33, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 384)
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_31, primals_38, primals_34, primals_36, primals_37, False, 0.1, 1e-05);  primals_34 = None
        getitem_93 = native_batch_norm_default_31[0]
        getitem_94 = native_batch_norm_default_31[1]
        getitem_95 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        new_zeros_default_93 = torch.ops.aten.new_zeros.default(convolution_default_31, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_94 = torch.ops.aten.new_zeros.default(convolution_default_31, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_95 = torch.ops.aten.new_zeros.default(convolution_default_31, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_21 = torch.ops.aten.clone.default(getitem_93)
        hardtanh__default_21 = torch.ops.aten.hardtanh_.default(getitem_93, 0.0, 6.0);  getitem_93 = None
        convolution_default_32 = torch.ops.aten.convolution.default(hardtanh__default_21, primals_39, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_44, primals_40, primals_42, primals_43, False, 0.1, 1e-05);  primals_40 = None
        getitem_96 = native_batch_norm_default_32[0]
        getitem_97 = native_batch_norm_default_32[1]
        getitem_98 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        new_zeros_default_96 = torch.ops.aten.new_zeros.default(convolution_default_32, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_97 = torch.ops.aten.new_zeros.default(convolution_default_32, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_98 = torch.ops.aten.new_zeros.default(convolution_default_32, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_33 = torch.ops.aten.convolution.default(getitem_96, primals_45, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_50, primals_46, primals_48, primals_49, False, 0.1, 1e-05);  primals_46 = None
        getitem_99 = native_batch_norm_default_33[0]
        getitem_100 = native_batch_norm_default_33[1]
        getitem_101 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        new_zeros_default_99 = torch.ops.aten.new_zeros.default(convolution_default_33, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_100 = torch.ops.aten.new_zeros.default(convolution_default_33, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_101 = torch.ops.aten.new_zeros.default(convolution_default_33, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_22 = torch.ops.aten.clone.default(getitem_99)
        hardtanh__default_22 = torch.ops.aten.hardtanh_.default(getitem_99, 0.0, 6.0);  getitem_99 = None
        convolution_default_34 = torch.ops.aten.convolution.default(hardtanh__default_22, primals_51, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 576)
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_56, primals_52, primals_54, primals_55, False, 0.1, 1e-05);  primals_52 = None
        getitem_102 = native_batch_norm_default_34[0]
        getitem_103 = native_batch_norm_default_34[1]
        getitem_104 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        new_zeros_default_102 = torch.ops.aten.new_zeros.default(convolution_default_34, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_103 = torch.ops.aten.new_zeros.default(convolution_default_34, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_104 = torch.ops.aten.new_zeros.default(convolution_default_34, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_23 = torch.ops.aten.clone.default(getitem_102)
        hardtanh__default_23 = torch.ops.aten.hardtanh_.default(getitem_102, 0.0, 6.0);  getitem_102 = None
        convolution_default_35 = torch.ops.aten.convolution.default(hardtanh__default_23, primals_57, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_62, primals_58, primals_60, primals_61, False, 0.1, 1e-05);  primals_58 = None
        getitem_105 = native_batch_norm_default_35[0]
        getitem_106 = native_batch_norm_default_35[1]
        getitem_107 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        new_zeros_default_105 = torch.ops.aten.new_zeros.default(convolution_default_35, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_106 = torch.ops.aten.new_zeros.default(convolution_default_35, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_107 = torch.ops.aten.new_zeros.default(convolution_default_35, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_6 = torch.ops.aten.add.Tensor(getitem_96, getitem_105);  getitem_105 = None
        convolution_default_36 = torch.ops.aten.convolution.default(add_tensor_6, primals_63, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_68, primals_64, primals_66, primals_67, False, 0.1, 1e-05);  primals_64 = None
        getitem_108 = native_batch_norm_default_36[0]
        getitem_109 = native_batch_norm_default_36[1]
        getitem_110 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        new_zeros_default_108 = torch.ops.aten.new_zeros.default(convolution_default_36, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_109 = torch.ops.aten.new_zeros.default(convolution_default_36, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_110 = torch.ops.aten.new_zeros.default(convolution_default_36, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_24 = torch.ops.aten.clone.default(getitem_108)
        hardtanh__default_24 = torch.ops.aten.hardtanh_.default(getitem_108, 0.0, 6.0);  getitem_108 = None
        convolution_default_37 = torch.ops.aten.convolution.default(hardtanh__default_24, primals_69, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 576)
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_37, primals_74, primals_70, primals_72, primals_73, False, 0.1, 1e-05);  primals_70 = None
        getitem_111 = native_batch_norm_default_37[0]
        getitem_112 = native_batch_norm_default_37[1]
        getitem_113 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        new_zeros_default_111 = torch.ops.aten.new_zeros.default(convolution_default_37, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_112 = torch.ops.aten.new_zeros.default(convolution_default_37, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_113 = torch.ops.aten.new_zeros.default(convolution_default_37, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_25 = torch.ops.aten.clone.default(getitem_111)
        hardtanh__default_25 = torch.ops.aten.hardtanh_.default(getitem_111, 0.0, 6.0);  getitem_111 = None
        convolution_default_38 = torch.ops.aten.convolution.default(hardtanh__default_25, primals_75, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_80, primals_76, primals_78, primals_79, False, 0.1, 1e-05);  primals_76 = None
        getitem_114 = native_batch_norm_default_38[0]
        getitem_115 = native_batch_norm_default_38[1]
        getitem_116 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        new_zeros_default_114 = torch.ops.aten.new_zeros.default(convolution_default_38, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_115 = torch.ops.aten.new_zeros.default(convolution_default_38, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_116 = torch.ops.aten.new_zeros.default(convolution_default_38, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_7 = torch.ops.aten.add.Tensor(add_tensor_6, getitem_114);  getitem_114 = None
        convolution_default_39 = torch.ops.aten.convolution.default(add_tensor_7, primals_81, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_39, primals_86, primals_82, primals_84, primals_85, False, 0.1, 1e-05);  primals_82 = None
        getitem_117 = native_batch_norm_default_39[0]
        getitem_118 = native_batch_norm_default_39[1]
        getitem_119 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        new_zeros_default_117 = torch.ops.aten.new_zeros.default(convolution_default_39, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_118 = torch.ops.aten.new_zeros.default(convolution_default_39, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_119 = torch.ops.aten.new_zeros.default(convolution_default_39, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_26 = torch.ops.aten.clone.default(getitem_117)
        hardtanh__default_26 = torch.ops.aten.hardtanh_.default(getitem_117, 0.0, 6.0);  getitem_117 = None
        convolution_default_40 = torch.ops.aten.convolution.default(hardtanh__default_26, primals_87, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 576)
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_92, primals_88, primals_90, primals_91, False, 0.1, 1e-05);  primals_88 = None
        getitem_120 = native_batch_norm_default_40[0]
        getitem_121 = native_batch_norm_default_40[1]
        getitem_122 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        new_zeros_default_120 = torch.ops.aten.new_zeros.default(convolution_default_40, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_121 = torch.ops.aten.new_zeros.default(convolution_default_40, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_122 = torch.ops.aten.new_zeros.default(convolution_default_40, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_27 = torch.ops.aten.clone.default(getitem_120)
        hardtanh__default_27 = torch.ops.aten.hardtanh_.default(getitem_120, 0.0, 6.0);  getitem_120 = None
        convolution_default_41 = torch.ops.aten.convolution.default(hardtanh__default_27, primals_93, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_41, primals_98, primals_94, primals_96, primals_97, False, 0.1, 1e-05);  primals_94 = None
        getitem_123 = native_batch_norm_default_41[0]
        getitem_124 = native_batch_norm_default_41[1]
        getitem_125 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        new_zeros_default_123 = torch.ops.aten.new_zeros.default(convolution_default_41, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_124 = torch.ops.aten.new_zeros.default(convolution_default_41, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_125 = torch.ops.aten.new_zeros.default(convolution_default_41, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_42 = torch.ops.aten.convolution.default(getitem_123, primals_99, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_42, primals_104, primals_100, primals_102, primals_103, False, 0.1, 1e-05);  primals_100 = None
        getitem_126 = native_batch_norm_default_42[0]
        getitem_127 = native_batch_norm_default_42[1]
        getitem_128 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        new_zeros_default_126 = torch.ops.aten.new_zeros.default(convolution_default_42, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_127 = torch.ops.aten.new_zeros.default(convolution_default_42, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_128 = torch.ops.aten.new_zeros.default(convolution_default_42, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_28 = torch.ops.aten.clone.default(getitem_126)
        hardtanh__default_28 = torch.ops.aten.hardtanh_.default(getitem_126, 0.0, 6.0);  getitem_126 = None
        convolution_default_43 = torch.ops.aten.convolution.default(hardtanh__default_28, primals_105, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 960)
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_43, primals_110, primals_106, primals_108, primals_109, False, 0.1, 1e-05);  primals_106 = None
        getitem_129 = native_batch_norm_default_43[0]
        getitem_130 = native_batch_norm_default_43[1]
        getitem_131 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        new_zeros_default_129 = torch.ops.aten.new_zeros.default(convolution_default_43, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_130 = torch.ops.aten.new_zeros.default(convolution_default_43, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_131 = torch.ops.aten.new_zeros.default(convolution_default_43, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_29 = torch.ops.aten.clone.default(getitem_129)
        hardtanh__default_29 = torch.ops.aten.hardtanh_.default(getitem_129, 0.0, 6.0);  getitem_129 = None
        convolution_default_44 = torch.ops.aten.convolution.default(hardtanh__default_29, primals_111, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_116, primals_112, primals_114, primals_115, False, 0.1, 1e-05);  primals_112 = None
        getitem_132 = native_batch_norm_default_44[0]
        getitem_133 = native_batch_norm_default_44[1]
        getitem_134 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        new_zeros_default_132 = torch.ops.aten.new_zeros.default(convolution_default_44, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_133 = torch.ops.aten.new_zeros.default(convolution_default_44, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_134 = torch.ops.aten.new_zeros.default(convolution_default_44, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_8 = torch.ops.aten.add.Tensor(getitem_123, getitem_132);  getitem_132 = None
        convolution_default_45 = torch.ops.aten.convolution.default(add_tensor_8, primals_117, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_45, primals_122, primals_118, primals_120, primals_121, False, 0.1, 1e-05);  primals_118 = None
        getitem_135 = native_batch_norm_default_45[0]
        getitem_136 = native_batch_norm_default_45[1]
        getitem_137 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        new_zeros_default_135 = torch.ops.aten.new_zeros.default(convolution_default_45, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_136 = torch.ops.aten.new_zeros.default(convolution_default_45, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_137 = torch.ops.aten.new_zeros.default(convolution_default_45, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_30 = torch.ops.aten.clone.default(getitem_135)
        hardtanh__default_30 = torch.ops.aten.hardtanh_.default(getitem_135, 0.0, 6.0);  getitem_135 = None
        convolution_default_46 = torch.ops.aten.convolution.default(hardtanh__default_30, primals_123, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 960)
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(convolution_default_46, primals_128, primals_124, primals_126, primals_127, False, 0.1, 1e-05);  primals_124 = None
        getitem_138 = native_batch_norm_default_46[0]
        getitem_139 = native_batch_norm_default_46[1]
        getitem_140 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        new_zeros_default_138 = torch.ops.aten.new_zeros.default(convolution_default_46, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_139 = torch.ops.aten.new_zeros.default(convolution_default_46, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_140 = torch.ops.aten.new_zeros.default(convolution_default_46, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_31 = torch.ops.aten.clone.default(getitem_138)
        hardtanh__default_31 = torch.ops.aten.hardtanh_.default(getitem_138, 0.0, 6.0);  getitem_138 = None
        convolution_default_47 = torch.ops.aten.convolution.default(hardtanh__default_31, primals_129, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(convolution_default_47, primals_134, primals_130, primals_132, primals_133, False, 0.1, 1e-05);  primals_130 = None
        getitem_141 = native_batch_norm_default_47[0]
        getitem_142 = native_batch_norm_default_47[1]
        getitem_143 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        new_zeros_default_141 = torch.ops.aten.new_zeros.default(convolution_default_47, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_142 = torch.ops.aten.new_zeros.default(convolution_default_47, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_143 = torch.ops.aten.new_zeros.default(convolution_default_47, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_9 = torch.ops.aten.add.Tensor(add_tensor_8, getitem_141);  getitem_141 = None
        convolution_default_48 = torch.ops.aten.convolution.default(add_tensor_9, primals_135, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_48, primals_140, primals_136, primals_138, primals_139, False, 0.1, 1e-05);  primals_136 = None
        getitem_144 = native_batch_norm_default_48[0]
        getitem_145 = native_batch_norm_default_48[1]
        getitem_146 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        new_zeros_default_144 = torch.ops.aten.new_zeros.default(convolution_default_48, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_145 = torch.ops.aten.new_zeros.default(convolution_default_48, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_146 = torch.ops.aten.new_zeros.default(convolution_default_48, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_32 = torch.ops.aten.clone.default(getitem_144)
        hardtanh__default_32 = torch.ops.aten.hardtanh_.default(getitem_144, 0.0, 6.0);  getitem_144 = None
        convolution_default_49 = torch.ops.aten.convolution.default(hardtanh__default_32, primals_141, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 960)
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(convolution_default_49, primals_146, primals_142, primals_144, primals_145, False, 0.1, 1e-05);  primals_142 = None
        getitem_147 = native_batch_norm_default_49[0]
        getitem_148 = native_batch_norm_default_49[1]
        getitem_149 = native_batch_norm_default_49[2];  native_batch_norm_default_49 = None
        new_zeros_default_147 = torch.ops.aten.new_zeros.default(convolution_default_49, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_148 = torch.ops.aten.new_zeros.default(convolution_default_49, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_149 = torch.ops.aten.new_zeros.default(convolution_default_49, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_33 = torch.ops.aten.clone.default(getitem_147)
        hardtanh__default_33 = torch.ops.aten.hardtanh_.default(getitem_147, 0.0, 6.0);  getitem_147 = None
        convolution_default_50 = torch.ops.aten.convolution.default(hardtanh__default_33, primals_147, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(convolution_default_50, primals_152, primals_148, primals_150, primals_151, False, 0.1, 1e-05);  primals_148 = None
        getitem_150 = native_batch_norm_default_50[0]
        getitem_151 = native_batch_norm_default_50[1]
        getitem_152 = native_batch_norm_default_50[2];  native_batch_norm_default_50 = None
        new_zeros_default_150 = torch.ops.aten.new_zeros.default(convolution_default_50, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_151 = torch.ops.aten.new_zeros.default(convolution_default_50, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_152 = torch.ops.aten.new_zeros.default(convolution_default_50, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_51 = torch.ops.aten.convolution.default(getitem_150, primals_153, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(convolution_default_51, primals_158, primals_154, primals_156, primals_157, False, 0.1, 1e-05);  primals_154 = None
        getitem_153 = native_batch_norm_default_51[0]
        getitem_154 = native_batch_norm_default_51[1]
        getitem_155 = native_batch_norm_default_51[2];  native_batch_norm_default_51 = None
        new_zeros_default_153 = torch.ops.aten.new_zeros.default(convolution_default_51, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_154 = torch.ops.aten.new_zeros.default(convolution_default_51, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_155 = torch.ops.aten.new_zeros.default(convolution_default_51, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_34 = torch.ops.aten.clone.default(getitem_153)
        hardtanh__default_34 = torch.ops.aten.hardtanh_.default(getitem_153, 0.0, 6.0);  getitem_153 = None
        mean_dim = torch.ops.aten.mean.dim(hardtanh__default_34, [-1, -2], True);  hardtanh__default_34 = None
        view_default = torch.ops.aten.view.default(mean_dim, [96, 1280]);  mean_dim = None
        t_default = torch.ops.aten.t.default(primals_2);  primals_2 = None
        addmm_default = torch.ops.aten.addmm.default(primals_1, view_default, t_default);  primals_1 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(addmm_default, tangents_1)
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, view_default);  t_default_2 = view_default = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_1 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        view_default_2 = torch.ops.aten.view.default(mm_default, [96, 1280, 1, 1]);  mm_default = None
        expand_default = torch.ops.aten.expand.default(view_default_2, [96, 1280, 7, 7]);  view_default_2 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 49);  expand_default = None
        to_dtype = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_1 = torch.ops.aten.to.dtype(clone_default_34, torch.float32);  clone_default_34 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0.0)
        ge_scalar = torch.ops.aten.ge.Scalar(to_dtype_1, 6.0);  to_dtype_1 = None
        __or___tensor = torch.ops.aten.__or__.Tensor(le_scalar, ge_scalar);  le_scalar = ge_scalar = None
        new_zeros_default_156 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(__or___tensor, new_zeros_default_156, to_dtype);  __or___tensor = new_zeros_default_156 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_2, convolution_default_51, primals_158, primals_156, primals_157, new_zeros_default_153, new_zeros_default_154, False, 1e-05, [True, True, True]);  to_dtype_2 = convolution_default_51 = primals_158 = primals_156 = primals_157 = new_zeros_default_153 = new_zeros_default_154 = None
        getitem_156 = native_batch_norm_backward_default[0]
        getitem_157 = native_batch_norm_backward_default[1]
        getitem_158 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(getitem_156, getitem_150, primals_153, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_156 = getitem_150 = primals_153 = None
        getitem_159 = convolution_backward_default[0]
        getitem_160 = convolution_backward_default[1]
        getitem_161 = convolution_backward_default[2];  convolution_backward_default = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(getitem_159, convolution_default_50, primals_152, primals_150, primals_151, new_zeros_default_150, new_zeros_default_151, False, 1e-05, [True, True, True]);  getitem_159 = convolution_default_50 = primals_152 = primals_150 = primals_151 = new_zeros_default_150 = new_zeros_default_151 = None
        getitem_162 = native_batch_norm_backward_default_1[0]
        getitem_163 = native_batch_norm_backward_default_1[1]
        getitem_164 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_162, hardtanh__default_33, primals_147, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_162 = hardtanh__default_33 = primals_147 = None
        getitem_165 = convolution_backward_default_1[0]
        getitem_166 = convolution_backward_default_1[1]
        getitem_167 = convolution_backward_default_1[2];  convolution_backward_default_1 = None
        to_dtype_3 = torch.ops.aten.to.dtype(getitem_165, torch.float32);  getitem_165 = None
        to_dtype_4 = torch.ops.aten.to.dtype(clone_default_33, torch.float32);  clone_default_33 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0.0)
        ge_scalar_1 = torch.ops.aten.ge.Scalar(to_dtype_4, 6.0);  to_dtype_4 = None
        __or___tensor_1 = torch.ops.aten.__or__.Tensor(le_scalar_1, ge_scalar_1);  le_scalar_1 = ge_scalar_1 = None
        new_zeros_default_157 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(__or___tensor_1, new_zeros_default_157, to_dtype_3);  __or___tensor_1 = new_zeros_default_157 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_5, convolution_default_49, primals_146, primals_144, primals_145, new_zeros_default_147, new_zeros_default_148, False, 1e-05, [True, True, True]);  to_dtype_5 = convolution_default_49 = primals_146 = primals_144 = primals_145 = new_zeros_default_147 = new_zeros_default_148 = None
        getitem_168 = native_batch_norm_backward_default_2[0]
        getitem_169 = native_batch_norm_backward_default_2[1]
        getitem_170 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_168, hardtanh__default_32, primals_141, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 960, [True, True, False]);  getitem_168 = hardtanh__default_32 = primals_141 = None
        getitem_171 = convolution_backward_default_2[0]
        getitem_172 = convolution_backward_default_2[1]
        getitem_173 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        to_dtype_6 = torch.ops.aten.to.dtype(getitem_171, torch.float32);  getitem_171 = None
        to_dtype_7 = torch.ops.aten.to.dtype(clone_default_32, torch.float32);  clone_default_32 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0.0)
        ge_scalar_2 = torch.ops.aten.ge.Scalar(to_dtype_7, 6.0);  to_dtype_7 = None
        __or___tensor_2 = torch.ops.aten.__or__.Tensor(le_scalar_2, ge_scalar_2);  le_scalar_2 = ge_scalar_2 = None
        new_zeros_default_158 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(__or___tensor_2, new_zeros_default_158, to_dtype_6);  __or___tensor_2 = new_zeros_default_158 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_8, convolution_default_48, primals_140, primals_138, primals_139, new_zeros_default_144, new_zeros_default_145, False, 1e-05, [True, True, True]);  to_dtype_8 = convolution_default_48 = primals_140 = primals_138 = primals_139 = new_zeros_default_144 = new_zeros_default_145 = None
        getitem_174 = native_batch_norm_backward_default_3[0]
        getitem_175 = native_batch_norm_backward_default_3[1]
        getitem_176 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_174, add_tensor_9, primals_135, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_174 = add_tensor_9 = primals_135 = None
        getitem_177 = convolution_backward_default_3[0]
        getitem_178 = convolution_backward_default_3[1]
        getitem_179 = convolution_backward_default_3[2];  convolution_backward_default_3 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(getitem_177, convolution_default_47, primals_134, primals_132, primals_133, new_zeros_default_141, new_zeros_default_142, False, 1e-05, [True, True, True]);  convolution_default_47 = primals_134 = primals_132 = primals_133 = new_zeros_default_141 = new_zeros_default_142 = None
        getitem_180 = native_batch_norm_backward_default_4[0]
        getitem_181 = native_batch_norm_backward_default_4[1]
        getitem_182 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_180, hardtanh__default_31, primals_129, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_180 = hardtanh__default_31 = primals_129 = None
        getitem_183 = convolution_backward_default_4[0]
        getitem_184 = convolution_backward_default_4[1]
        getitem_185 = convolution_backward_default_4[2];  convolution_backward_default_4 = None
        to_dtype_9 = torch.ops.aten.to.dtype(getitem_183, torch.float32);  getitem_183 = None
        to_dtype_10 = torch.ops.aten.to.dtype(clone_default_31, torch.float32);  clone_default_31 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0.0)
        ge_scalar_3 = torch.ops.aten.ge.Scalar(to_dtype_10, 6.0);  to_dtype_10 = None
        __or___tensor_3 = torch.ops.aten.__or__.Tensor(le_scalar_3, ge_scalar_3);  le_scalar_3 = ge_scalar_3 = None
        new_zeros_default_159 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(__or___tensor_3, new_zeros_default_159, to_dtype_9);  __or___tensor_3 = new_zeros_default_159 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_46, primals_128, primals_126, primals_127, new_zeros_default_138, new_zeros_default_139, False, 1e-05, [True, True, True]);  to_dtype_11 = convolution_default_46 = primals_128 = primals_126 = primals_127 = new_zeros_default_138 = new_zeros_default_139 = None
        getitem_186 = native_batch_norm_backward_default_5[0]
        getitem_187 = native_batch_norm_backward_default_5[1]
        getitem_188 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_186, hardtanh__default_30, primals_123, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 960, [True, True, False]);  getitem_186 = hardtanh__default_30 = primals_123 = None
        getitem_189 = convolution_backward_default_5[0]
        getitem_190 = convolution_backward_default_5[1]
        getitem_191 = convolution_backward_default_5[2];  convolution_backward_default_5 = None
        to_dtype_12 = torch.ops.aten.to.dtype(getitem_189, torch.float32);  getitem_189 = None
        to_dtype_13 = torch.ops.aten.to.dtype(clone_default_30, torch.float32);  clone_default_30 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0.0)
        ge_scalar_4 = torch.ops.aten.ge.Scalar(to_dtype_13, 6.0);  to_dtype_13 = None
        __or___tensor_4 = torch.ops.aten.__or__.Tensor(le_scalar_4, ge_scalar_4);  le_scalar_4 = ge_scalar_4 = None
        new_zeros_default_160 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(__or___tensor_4, new_zeros_default_160, to_dtype_12);  __or___tensor_4 = new_zeros_default_160 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_45, primals_122, primals_120, primals_121, new_zeros_default_135, new_zeros_default_136, False, 1e-05, [True, True, True]);  to_dtype_14 = convolution_default_45 = primals_122 = primals_120 = primals_121 = new_zeros_default_135 = new_zeros_default_136 = None
        getitem_192 = native_batch_norm_backward_default_6[0]
        getitem_193 = native_batch_norm_backward_default_6[1]
        getitem_194 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(getitem_192, add_tensor_8, primals_117, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_192 = add_tensor_8 = primals_117 = None
        getitem_195 = convolution_backward_default_6[0]
        getitem_196 = convolution_backward_default_6[1]
        getitem_197 = convolution_backward_default_6[2];  convolution_backward_default_6 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(getitem_177, getitem_195);  getitem_177 = getitem_195 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_10, convolution_default_44, primals_116, primals_114, primals_115, new_zeros_default_132, new_zeros_default_133, False, 1e-05, [True, True, True]);  convolution_default_44 = primals_116 = primals_114 = primals_115 = new_zeros_default_132 = new_zeros_default_133 = None
        getitem_198 = native_batch_norm_backward_default_7[0]
        getitem_199 = native_batch_norm_backward_default_7[1]
        getitem_200 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(getitem_198, hardtanh__default_29, primals_111, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_198 = hardtanh__default_29 = primals_111 = None
        getitem_201 = convolution_backward_default_7[0]
        getitem_202 = convolution_backward_default_7[1]
        getitem_203 = convolution_backward_default_7[2];  convolution_backward_default_7 = None
        to_dtype_15 = torch.ops.aten.to.dtype(getitem_201, torch.float32);  getitem_201 = None
        to_dtype_16 = torch.ops.aten.to.dtype(clone_default_29, torch.float32);  clone_default_29 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_16, 0.0)
        ge_scalar_5 = torch.ops.aten.ge.Scalar(to_dtype_16, 6.0);  to_dtype_16 = None
        __or___tensor_5 = torch.ops.aten.__or__.Tensor(le_scalar_5, ge_scalar_5);  le_scalar_5 = ge_scalar_5 = None
        new_zeros_default_161 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(__or___tensor_5, new_zeros_default_161, to_dtype_15);  __or___tensor_5 = new_zeros_default_161 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_17, convolution_default_43, primals_110, primals_108, primals_109, new_zeros_default_129, new_zeros_default_130, False, 1e-05, [True, True, True]);  to_dtype_17 = convolution_default_43 = primals_110 = primals_108 = primals_109 = new_zeros_default_129 = new_zeros_default_130 = None
        getitem_204 = native_batch_norm_backward_default_8[0]
        getitem_205 = native_batch_norm_backward_default_8[1]
        getitem_206 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(getitem_204, hardtanh__default_28, primals_105, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 960, [True, True, False]);  getitem_204 = hardtanh__default_28 = primals_105 = None
        getitem_207 = convolution_backward_default_8[0]
        getitem_208 = convolution_backward_default_8[1]
        getitem_209 = convolution_backward_default_8[2];  convolution_backward_default_8 = None
        to_dtype_18 = torch.ops.aten.to.dtype(getitem_207, torch.float32);  getitem_207 = None
        to_dtype_19 = torch.ops.aten.to.dtype(clone_default_28, torch.float32);  clone_default_28 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_19, 0.0)
        ge_scalar_6 = torch.ops.aten.ge.Scalar(to_dtype_19, 6.0);  to_dtype_19 = None
        __or___tensor_6 = torch.ops.aten.__or__.Tensor(le_scalar_6, ge_scalar_6);  le_scalar_6 = ge_scalar_6 = None
        new_zeros_default_162 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(__or___tensor_6, new_zeros_default_162, to_dtype_18);  __or___tensor_6 = new_zeros_default_162 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_20, convolution_default_42, primals_104, primals_102, primals_103, new_zeros_default_126, new_zeros_default_127, False, 1e-05, [True, True, True]);  to_dtype_20 = convolution_default_42 = primals_104 = primals_102 = primals_103 = new_zeros_default_126 = new_zeros_default_127 = None
        getitem_210 = native_batch_norm_backward_default_9[0]
        getitem_211 = native_batch_norm_backward_default_9[1]
        getitem_212 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_210, getitem_123, primals_99, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_210 = getitem_123 = primals_99 = None
        getitem_213 = convolution_backward_default_9[0]
        getitem_214 = convolution_backward_default_9[1]
        getitem_215 = convolution_backward_default_9[2];  convolution_backward_default_9 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(add_tensor_10, getitem_213);  add_tensor_10 = getitem_213 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_11, convolution_default_41, primals_98, primals_96, primals_97, new_zeros_default_123, new_zeros_default_124, False, 1e-05, [True, True, True]);  add_tensor_11 = convolution_default_41 = primals_98 = primals_96 = primals_97 = new_zeros_default_123 = new_zeros_default_124 = None
        getitem_216 = native_batch_norm_backward_default_10[0]
        getitem_217 = native_batch_norm_backward_default_10[1]
        getitem_218 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_216, hardtanh__default_27, primals_93, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_216 = hardtanh__default_27 = primals_93 = None
        getitem_219 = convolution_backward_default_10[0]
        getitem_220 = convolution_backward_default_10[1]
        getitem_221 = convolution_backward_default_10[2];  convolution_backward_default_10 = None
        to_dtype_21 = torch.ops.aten.to.dtype(getitem_219, torch.float32);  getitem_219 = None
        to_dtype_22 = torch.ops.aten.to.dtype(clone_default_27, torch.float32);  clone_default_27 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_22, 0.0)
        ge_scalar_7 = torch.ops.aten.ge.Scalar(to_dtype_22, 6.0);  to_dtype_22 = None
        __or___tensor_7 = torch.ops.aten.__or__.Tensor(le_scalar_7, ge_scalar_7);  le_scalar_7 = ge_scalar_7 = None
        new_zeros_default_163 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(__or___tensor_7, new_zeros_default_163, to_dtype_21);  __or___tensor_7 = new_zeros_default_163 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_23, convolution_default_40, primals_92, primals_90, primals_91, new_zeros_default_120, new_zeros_default_121, False, 1e-05, [True, True, True]);  to_dtype_23 = convolution_default_40 = primals_92 = primals_90 = primals_91 = new_zeros_default_120 = new_zeros_default_121 = None
        getitem_222 = native_batch_norm_backward_default_11[0]
        getitem_223 = native_batch_norm_backward_default_11[1]
        getitem_224 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_222, hardtanh__default_26, primals_87, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 576, [True, True, False]);  getitem_222 = hardtanh__default_26 = primals_87 = None
        getitem_225 = convolution_backward_default_11[0]
        getitem_226 = convolution_backward_default_11[1]
        getitem_227 = convolution_backward_default_11[2];  convolution_backward_default_11 = None
        to_dtype_24 = torch.ops.aten.to.dtype(getitem_225, torch.float32);  getitem_225 = None
        to_dtype_25 = torch.ops.aten.to.dtype(clone_default_26, torch.float32);  clone_default_26 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_25, 0.0)
        ge_scalar_8 = torch.ops.aten.ge.Scalar(to_dtype_25, 6.0);  to_dtype_25 = None
        __or___tensor_8 = torch.ops.aten.__or__.Tensor(le_scalar_8, ge_scalar_8);  le_scalar_8 = ge_scalar_8 = None
        new_zeros_default_164 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(__or___tensor_8, new_zeros_default_164, to_dtype_24);  __or___tensor_8 = new_zeros_default_164 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_39, primals_86, primals_84, primals_85, new_zeros_default_117, new_zeros_default_118, False, 1e-05, [True, True, True]);  to_dtype_26 = convolution_default_39 = primals_86 = primals_84 = primals_85 = new_zeros_default_117 = new_zeros_default_118 = None
        getitem_228 = native_batch_norm_backward_default_12[0]
        getitem_229 = native_batch_norm_backward_default_12[1]
        getitem_230 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(getitem_228, add_tensor_7, primals_81, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_228 = add_tensor_7 = primals_81 = None
        getitem_231 = convolution_backward_default_12[0]
        getitem_232 = convolution_backward_default_12[1]
        getitem_233 = convolution_backward_default_12[2];  convolution_backward_default_12 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(getitem_231, convolution_default_38, primals_80, primals_78, primals_79, new_zeros_default_114, new_zeros_default_115, False, 1e-05, [True, True, True]);  convolution_default_38 = primals_80 = primals_78 = primals_79 = new_zeros_default_114 = new_zeros_default_115 = None
        getitem_234 = native_batch_norm_backward_default_13[0]
        getitem_235 = native_batch_norm_backward_default_13[1]
        getitem_236 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_234, hardtanh__default_25, primals_75, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_234 = hardtanh__default_25 = primals_75 = None
        getitem_237 = convolution_backward_default_13[0]
        getitem_238 = convolution_backward_default_13[1]
        getitem_239 = convolution_backward_default_13[2];  convolution_backward_default_13 = None
        to_dtype_27 = torch.ops.aten.to.dtype(getitem_237, torch.float32);  getitem_237 = None
        to_dtype_28 = torch.ops.aten.to.dtype(clone_default_25, torch.float32);  clone_default_25 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_28, 0.0)
        ge_scalar_9 = torch.ops.aten.ge.Scalar(to_dtype_28, 6.0);  to_dtype_28 = None
        __or___tensor_9 = torch.ops.aten.__or__.Tensor(le_scalar_9, ge_scalar_9);  le_scalar_9 = ge_scalar_9 = None
        new_zeros_default_165 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(__or___tensor_9, new_zeros_default_165, to_dtype_27);  __or___tensor_9 = new_zeros_default_165 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_29, convolution_default_37, primals_74, primals_72, primals_73, new_zeros_default_111, new_zeros_default_112, False, 1e-05, [True, True, True]);  to_dtype_29 = convolution_default_37 = primals_74 = primals_72 = primals_73 = new_zeros_default_111 = new_zeros_default_112 = None
        getitem_240 = native_batch_norm_backward_default_14[0]
        getitem_241 = native_batch_norm_backward_default_14[1]
        getitem_242 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_240, hardtanh__default_24, primals_69, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 576, [True, True, False]);  getitem_240 = hardtanh__default_24 = primals_69 = None
        getitem_243 = convolution_backward_default_14[0]
        getitem_244 = convolution_backward_default_14[1]
        getitem_245 = convolution_backward_default_14[2];  convolution_backward_default_14 = None
        to_dtype_30 = torch.ops.aten.to.dtype(getitem_243, torch.float32);  getitem_243 = None
        to_dtype_31 = torch.ops.aten.to.dtype(clone_default_24, torch.float32);  clone_default_24 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_31, 0.0)
        ge_scalar_10 = torch.ops.aten.ge.Scalar(to_dtype_31, 6.0);  to_dtype_31 = None
        __or___tensor_10 = torch.ops.aten.__or__.Tensor(le_scalar_10, ge_scalar_10);  le_scalar_10 = ge_scalar_10 = None
        new_zeros_default_166 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(__or___tensor_10, new_zeros_default_166, to_dtype_30);  __or___tensor_10 = new_zeros_default_166 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default_36, primals_68, primals_66, primals_67, new_zeros_default_108, new_zeros_default_109, False, 1e-05, [True, True, True]);  to_dtype_32 = convolution_default_36 = primals_68 = primals_66 = primals_67 = new_zeros_default_108 = new_zeros_default_109 = None
        getitem_246 = native_batch_norm_backward_default_15[0]
        getitem_247 = native_batch_norm_backward_default_15[1]
        getitem_248 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_246, add_tensor_6, primals_63, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_246 = add_tensor_6 = primals_63 = None
        getitem_249 = convolution_backward_default_15[0]
        getitem_250 = convolution_backward_default_15[1]
        getitem_251 = convolution_backward_default_15[2];  convolution_backward_default_15 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(getitem_231, getitem_249);  getitem_231 = getitem_249 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_12, convolution_default_35, primals_62, primals_60, primals_61, new_zeros_default_105, new_zeros_default_106, False, 1e-05, [True, True, True]);  convolution_default_35 = primals_62 = primals_60 = primals_61 = new_zeros_default_105 = new_zeros_default_106 = None
        getitem_252 = native_batch_norm_backward_default_16[0]
        getitem_253 = native_batch_norm_backward_default_16[1]
        getitem_254 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(getitem_252, hardtanh__default_23, primals_57, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_252 = hardtanh__default_23 = primals_57 = None
        getitem_255 = convolution_backward_default_16[0]
        getitem_256 = convolution_backward_default_16[1]
        getitem_257 = convolution_backward_default_16[2];  convolution_backward_default_16 = None
        to_dtype_33 = torch.ops.aten.to.dtype(getitem_255, torch.float32);  getitem_255 = None
        to_dtype_34 = torch.ops.aten.to.dtype(clone_default_23, torch.float32);  clone_default_23 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_34, 0.0)
        ge_scalar_11 = torch.ops.aten.ge.Scalar(to_dtype_34, 6.0);  to_dtype_34 = None
        __or___tensor_11 = torch.ops.aten.__or__.Tensor(le_scalar_11, ge_scalar_11);  le_scalar_11 = ge_scalar_11 = None
        new_zeros_default_167 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(__or___tensor_11, new_zeros_default_167, to_dtype_33);  __or___tensor_11 = new_zeros_default_167 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_35, convolution_default_34, primals_56, primals_54, primals_55, new_zeros_default_102, new_zeros_default_103, False, 1e-05, [True, True, True]);  to_dtype_35 = convolution_default_34 = primals_56 = primals_54 = primals_55 = new_zeros_default_102 = new_zeros_default_103 = None
        getitem_258 = native_batch_norm_backward_default_17[0]
        getitem_259 = native_batch_norm_backward_default_17[1]
        getitem_260 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(getitem_258, hardtanh__default_22, primals_51, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 576, [True, True, False]);  getitem_258 = hardtanh__default_22 = primals_51 = None
        getitem_261 = convolution_backward_default_17[0]
        getitem_262 = convolution_backward_default_17[1]
        getitem_263 = convolution_backward_default_17[2];  convolution_backward_default_17 = None
        to_dtype_36 = torch.ops.aten.to.dtype(getitem_261, torch.float32);  getitem_261 = None
        to_dtype_37 = torch.ops.aten.to.dtype(clone_default_22, torch.float32);  clone_default_22 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_37, 0.0)
        ge_scalar_12 = torch.ops.aten.ge.Scalar(to_dtype_37, 6.0);  to_dtype_37 = None
        __or___tensor_12 = torch.ops.aten.__or__.Tensor(le_scalar_12, ge_scalar_12);  le_scalar_12 = ge_scalar_12 = None
        new_zeros_default_168 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(__or___tensor_12, new_zeros_default_168, to_dtype_36);  __or___tensor_12 = new_zeros_default_168 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_38, convolution_default_33, primals_50, primals_48, primals_49, new_zeros_default_99, new_zeros_default_100, False, 1e-05, [True, True, True]);  to_dtype_38 = convolution_default_33 = primals_50 = primals_48 = primals_49 = new_zeros_default_99 = new_zeros_default_100 = None
        getitem_264 = native_batch_norm_backward_default_18[0]
        getitem_265 = native_batch_norm_backward_default_18[1]
        getitem_266 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(getitem_264, getitem_96, primals_45, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_264 = getitem_96 = primals_45 = None
        getitem_267 = convolution_backward_default_18[0]
        getitem_268 = convolution_backward_default_18[1]
        getitem_269 = convolution_backward_default_18[2];  convolution_backward_default_18 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(add_tensor_12, getitem_267);  add_tensor_12 = getitem_267 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_13, convolution_default_32, primals_44, primals_42, primals_43, new_zeros_default_96, new_zeros_default_97, False, 1e-05, [True, True, True]);  add_tensor_13 = convolution_default_32 = primals_44 = primals_42 = primals_43 = new_zeros_default_96 = new_zeros_default_97 = None
        getitem_270 = native_batch_norm_backward_default_19[0]
        getitem_271 = native_batch_norm_backward_default_19[1]
        getitem_272 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_270, hardtanh__default_21, primals_39, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_270 = hardtanh__default_21 = primals_39 = None
        getitem_273 = convolution_backward_default_19[0]
        getitem_274 = convolution_backward_default_19[1]
        getitem_275 = convolution_backward_default_19[2];  convolution_backward_default_19 = None
        to_dtype_39 = torch.ops.aten.to.dtype(getitem_273, torch.float32);  getitem_273 = None
        to_dtype_40 = torch.ops.aten.to.dtype(clone_default_21, torch.float32);  clone_default_21 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_40, 0.0)
        ge_scalar_13 = torch.ops.aten.ge.Scalar(to_dtype_40, 6.0);  to_dtype_40 = None
        __or___tensor_13 = torch.ops.aten.__or__.Tensor(le_scalar_13, ge_scalar_13);  le_scalar_13 = ge_scalar_13 = None
        new_zeros_default_169 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(__or___tensor_13, new_zeros_default_169, to_dtype_39);  __or___tensor_13 = new_zeros_default_169 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_41, convolution_default_31, primals_38, primals_36, primals_37, new_zeros_default_93, new_zeros_default_94, False, 1e-05, [True, True, True]);  to_dtype_41 = convolution_default_31 = primals_38 = primals_36 = primals_37 = new_zeros_default_93 = new_zeros_default_94 = None
        getitem_276 = native_batch_norm_backward_default_20[0]
        getitem_277 = native_batch_norm_backward_default_20[1]
        getitem_278 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(getitem_276, hardtanh__default_20, primals_33, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 384, [True, True, False]);  getitem_276 = hardtanh__default_20 = primals_33 = None
        getitem_279 = convolution_backward_default_20[0]
        getitem_280 = convolution_backward_default_20[1]
        getitem_281 = convolution_backward_default_20[2];  convolution_backward_default_20 = None
        to_dtype_42 = torch.ops.aten.to.dtype(getitem_279, torch.float32);  getitem_279 = None
        to_dtype_43 = torch.ops.aten.to.dtype(clone_default_20, torch.float32);  clone_default_20 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_43, 0.0)
        ge_scalar_14 = torch.ops.aten.ge.Scalar(to_dtype_43, 6.0);  to_dtype_43 = None
        __or___tensor_14 = torch.ops.aten.__or__.Tensor(le_scalar_14, ge_scalar_14);  le_scalar_14 = ge_scalar_14 = None
        new_zeros_default_170 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(__or___tensor_14, new_zeros_default_170, to_dtype_42);  __or___tensor_14 = new_zeros_default_170 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_44, convolution_default_30, primals_32, primals_30, primals_31, new_zeros_default_90, new_zeros_default_91, False, 1e-05, [True, True, True]);  to_dtype_44 = convolution_default_30 = primals_32 = primals_30 = primals_31 = new_zeros_default_90 = new_zeros_default_91 = None
        getitem_282 = native_batch_norm_backward_default_21[0]
        getitem_283 = native_batch_norm_backward_default_21[1]
        getitem_284 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(getitem_282, add_tensor_5, primals_27, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_282 = add_tensor_5 = primals_27 = None
        getitem_285 = convolution_backward_default_21[0]
        getitem_286 = convolution_backward_default_21[1]
        getitem_287 = convolution_backward_default_21[2];  convolution_backward_default_21 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(getitem_285, convolution_default_29, primals_26, primals_24, primals_25, new_zeros_default_87, new_zeros_default_88, False, 1e-05, [True, True, True]);  convolution_default_29 = primals_26 = primals_24 = primals_25 = new_zeros_default_87 = new_zeros_default_88 = None
        getitem_288 = native_batch_norm_backward_default_22[0]
        getitem_289 = native_batch_norm_backward_default_22[1]
        getitem_290 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(getitem_288, hardtanh__default_19, primals_21, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_288 = hardtanh__default_19 = primals_21 = None
        getitem_291 = convolution_backward_default_22[0]
        getitem_292 = convolution_backward_default_22[1]
        getitem_293 = convolution_backward_default_22[2];  convolution_backward_default_22 = None
        to_dtype_45 = torch.ops.aten.to.dtype(getitem_291, torch.float32);  getitem_291 = None
        to_dtype_46 = torch.ops.aten.to.dtype(clone_default_19, torch.float32);  clone_default_19 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_46, 0.0)
        ge_scalar_15 = torch.ops.aten.ge.Scalar(to_dtype_46, 6.0);  to_dtype_46 = None
        __or___tensor_15 = torch.ops.aten.__or__.Tensor(le_scalar_15, ge_scalar_15);  le_scalar_15 = ge_scalar_15 = None
        new_zeros_default_171 = torch.ops.aten.new_zeros.default(to_dtype_45, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(__or___tensor_15, new_zeros_default_171, to_dtype_45);  __or___tensor_15 = new_zeros_default_171 = to_dtype_45 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_47, convolution_default_28, primals_20, primals_18, primals_19, new_zeros_default_84, new_zeros_default_85, False, 1e-05, [True, True, True]);  to_dtype_47 = convolution_default_28 = primals_20 = primals_18 = primals_19 = new_zeros_default_84 = new_zeros_default_85 = None
        getitem_294 = native_batch_norm_backward_default_23[0]
        getitem_295 = native_batch_norm_backward_default_23[1]
        getitem_296 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(getitem_294, hardtanh__default_18, primals_15, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 384, [True, True, False]);  getitem_294 = hardtanh__default_18 = primals_15 = None
        getitem_297 = convolution_backward_default_23[0]
        getitem_298 = convolution_backward_default_23[1]
        getitem_299 = convolution_backward_default_23[2];  convolution_backward_default_23 = None
        to_dtype_48 = torch.ops.aten.to.dtype(getitem_297, torch.float32);  getitem_297 = None
        to_dtype_49 = torch.ops.aten.to.dtype(clone_default_18, torch.float32);  clone_default_18 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_49, 0.0)
        ge_scalar_16 = torch.ops.aten.ge.Scalar(to_dtype_49, 6.0);  to_dtype_49 = None
        __or___tensor_16 = torch.ops.aten.__or__.Tensor(le_scalar_16, ge_scalar_16);  le_scalar_16 = ge_scalar_16 = None
        new_zeros_default_172 = torch.ops.aten.new_zeros.default(to_dtype_48, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(__or___tensor_16, new_zeros_default_172, to_dtype_48);  __or___tensor_16 = new_zeros_default_172 = to_dtype_48 = None
        to_dtype_50 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_50, convolution_default_27, primals_14, primals_12, primals_13, new_zeros_default_81, new_zeros_default_82, False, 1e-05, [True, True, True]);  to_dtype_50 = convolution_default_27 = primals_14 = primals_12 = primals_13 = new_zeros_default_81 = new_zeros_default_82 = None
        getitem_300 = native_batch_norm_backward_default_24[0]
        getitem_301 = native_batch_norm_backward_default_24[1]
        getitem_302 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_300, add_tensor_4, primals_9, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_300 = add_tensor_4 = primals_9 = None
        getitem_303 = convolution_backward_default_24[0]
        getitem_304 = convolution_backward_default_24[1]
        getitem_305 = convolution_backward_default_24[2];  convolution_backward_default_24 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(getitem_285, getitem_303);  getitem_285 = getitem_303 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_14, convolution_default_26, primals_314, primals_312, primals_313, new_zeros_default_78, new_zeros_default_79, False, 1e-05, [True, True, True]);  convolution_default_26 = primals_314 = primals_312 = primals_313 = new_zeros_default_78 = new_zeros_default_79 = None
        getitem_306 = native_batch_norm_backward_default_25[0]
        getitem_307 = native_batch_norm_backward_default_25[1]
        getitem_308 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_306, hardtanh__default_17, primals_309, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_306 = hardtanh__default_17 = primals_309 = None
        getitem_309 = convolution_backward_default_25[0]
        getitem_310 = convolution_backward_default_25[1]
        getitem_311 = convolution_backward_default_25[2];  convolution_backward_default_25 = None
        to_dtype_51 = torch.ops.aten.to.dtype(getitem_309, torch.float32);  getitem_309 = None
        to_dtype_52 = torch.ops.aten.to.dtype(clone_default_17, torch.float32);  clone_default_17 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_52, 0.0)
        ge_scalar_17 = torch.ops.aten.ge.Scalar(to_dtype_52, 6.0);  to_dtype_52 = None
        __or___tensor_17 = torch.ops.aten.__or__.Tensor(le_scalar_17, ge_scalar_17);  le_scalar_17 = ge_scalar_17 = None
        new_zeros_default_173 = torch.ops.aten.new_zeros.default(to_dtype_51, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(__or___tensor_17, new_zeros_default_173, to_dtype_51);  __or___tensor_17 = new_zeros_default_173 = to_dtype_51 = None
        to_dtype_53 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_53, convolution_default_25, primals_308, primals_306, primals_307, new_zeros_default_75, new_zeros_default_76, False, 1e-05, [True, True, True]);  to_dtype_53 = convolution_default_25 = primals_308 = primals_306 = primals_307 = new_zeros_default_75 = new_zeros_default_76 = None
        getitem_312 = native_batch_norm_backward_default_26[0]
        getitem_313 = native_batch_norm_backward_default_26[1]
        getitem_314 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(getitem_312, hardtanh__default_16, primals_303, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 384, [True, True, False]);  getitem_312 = hardtanh__default_16 = primals_303 = None
        getitem_315 = convolution_backward_default_26[0]
        getitem_316 = convolution_backward_default_26[1]
        getitem_317 = convolution_backward_default_26[2];  convolution_backward_default_26 = None
        to_dtype_54 = torch.ops.aten.to.dtype(getitem_315, torch.float32);  getitem_315 = None
        to_dtype_55 = torch.ops.aten.to.dtype(clone_default_16, torch.float32);  clone_default_16 = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_55, 0.0)
        ge_scalar_18 = torch.ops.aten.ge.Scalar(to_dtype_55, 6.0);  to_dtype_55 = None
        __or___tensor_18 = torch.ops.aten.__or__.Tensor(le_scalar_18, ge_scalar_18);  le_scalar_18 = ge_scalar_18 = None
        new_zeros_default_174 = torch.ops.aten.new_zeros.default(to_dtype_54, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_18 = torch.ops.aten.where.self(__or___tensor_18, new_zeros_default_174, to_dtype_54);  __or___tensor_18 = new_zeros_default_174 = to_dtype_54 = None
        to_dtype_56 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_56, convolution_default_24, primals_302, primals_300, primals_301, new_zeros_default_72, new_zeros_default_73, False, 1e-05, [True, True, True]);  to_dtype_56 = convolution_default_24 = primals_302 = primals_300 = primals_301 = new_zeros_default_72 = new_zeros_default_73 = None
        getitem_318 = native_batch_norm_backward_default_27[0]
        getitem_319 = native_batch_norm_backward_default_27[1]
        getitem_320 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(getitem_318, add_tensor_3, primals_297, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_318 = add_tensor_3 = primals_297 = None
        getitem_321 = convolution_backward_default_27[0]
        getitem_322 = convolution_backward_default_27[1]
        getitem_323 = convolution_backward_default_27[2];  convolution_backward_default_27 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(add_tensor_14, getitem_321);  add_tensor_14 = getitem_321 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_15, convolution_default_23, primals_296, primals_294, primals_295, new_zeros_default_69, new_zeros_default_70, False, 1e-05, [True, True, True]);  convolution_default_23 = primals_296 = primals_294 = primals_295 = new_zeros_default_69 = new_zeros_default_70 = None
        getitem_324 = native_batch_norm_backward_default_28[0]
        getitem_325 = native_batch_norm_backward_default_28[1]
        getitem_326 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(getitem_324, hardtanh__default_15, primals_291, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_324 = hardtanh__default_15 = primals_291 = None
        getitem_327 = convolution_backward_default_28[0]
        getitem_328 = convolution_backward_default_28[1]
        getitem_329 = convolution_backward_default_28[2];  convolution_backward_default_28 = None
        to_dtype_57 = torch.ops.aten.to.dtype(getitem_327, torch.float32);  getitem_327 = None
        to_dtype_58 = torch.ops.aten.to.dtype(clone_default_15, torch.float32);  clone_default_15 = None
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_58, 0.0)
        ge_scalar_19 = torch.ops.aten.ge.Scalar(to_dtype_58, 6.0);  to_dtype_58 = None
        __or___tensor_19 = torch.ops.aten.__or__.Tensor(le_scalar_19, ge_scalar_19);  le_scalar_19 = ge_scalar_19 = None
        new_zeros_default_175 = torch.ops.aten.new_zeros.default(to_dtype_57, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_19 = torch.ops.aten.where.self(__or___tensor_19, new_zeros_default_175, to_dtype_57);  __or___tensor_19 = new_zeros_default_175 = to_dtype_57 = None
        to_dtype_59 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_59, convolution_default_22, primals_290, primals_288, primals_289, new_zeros_default_66, new_zeros_default_67, False, 1e-05, [True, True, True]);  to_dtype_59 = convolution_default_22 = primals_290 = primals_288 = primals_289 = new_zeros_default_66 = new_zeros_default_67 = None
        getitem_330 = native_batch_norm_backward_default_29[0]
        getitem_331 = native_batch_norm_backward_default_29[1]
        getitem_332 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(getitem_330, hardtanh__default_14, primals_285, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 384, [True, True, False]);  getitem_330 = hardtanh__default_14 = primals_285 = None
        getitem_333 = convolution_backward_default_29[0]
        getitem_334 = convolution_backward_default_29[1]
        getitem_335 = convolution_backward_default_29[2];  convolution_backward_default_29 = None
        to_dtype_60 = torch.ops.aten.to.dtype(getitem_333, torch.float32);  getitem_333 = None
        to_dtype_61 = torch.ops.aten.to.dtype(clone_default_14, torch.float32);  clone_default_14 = None
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_61, 0.0)
        ge_scalar_20 = torch.ops.aten.ge.Scalar(to_dtype_61, 6.0);  to_dtype_61 = None
        __or___tensor_20 = torch.ops.aten.__or__.Tensor(le_scalar_20, ge_scalar_20);  le_scalar_20 = ge_scalar_20 = None
        new_zeros_default_176 = torch.ops.aten.new_zeros.default(to_dtype_60, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_20 = torch.ops.aten.where.self(__or___tensor_20, new_zeros_default_176, to_dtype_60);  __or___tensor_20 = new_zeros_default_176 = to_dtype_60 = None
        to_dtype_62 = torch.ops.aten.to.dtype(where_self_20, torch.float32);  where_self_20 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_62, convolution_default_21, primals_284, primals_282, primals_283, new_zeros_default_63, new_zeros_default_64, False, 1e-05, [True, True, True]);  to_dtype_62 = convolution_default_21 = primals_284 = primals_282 = primals_283 = new_zeros_default_63 = new_zeros_default_64 = None
        getitem_336 = native_batch_norm_backward_default_30[0]
        getitem_337 = native_batch_norm_backward_default_30[1]
        getitem_338 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_336, getitem_60, primals_279, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_336 = getitem_60 = primals_279 = None
        getitem_339 = convolution_backward_default_30[0]
        getitem_340 = convolution_backward_default_30[1]
        getitem_341 = convolution_backward_default_30[2];  convolution_backward_default_30 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(add_tensor_15, getitem_339);  add_tensor_15 = getitem_339 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_16, convolution_default_20, primals_278, primals_276, primals_277, new_zeros_default_60, new_zeros_default_61, False, 1e-05, [True, True, True]);  add_tensor_16 = convolution_default_20 = primals_278 = primals_276 = primals_277 = new_zeros_default_60 = new_zeros_default_61 = None
        getitem_342 = native_batch_norm_backward_default_31[0]
        getitem_343 = native_batch_norm_backward_default_31[1]
        getitem_344 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(getitem_342, hardtanh__default_13, primals_273, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_342 = hardtanh__default_13 = primals_273 = None
        getitem_345 = convolution_backward_default_31[0]
        getitem_346 = convolution_backward_default_31[1]
        getitem_347 = convolution_backward_default_31[2];  convolution_backward_default_31 = None
        to_dtype_63 = torch.ops.aten.to.dtype(getitem_345, torch.float32);  getitem_345 = None
        to_dtype_64 = torch.ops.aten.to.dtype(clone_default_13, torch.float32);  clone_default_13 = None
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_64, 0.0)
        ge_scalar_21 = torch.ops.aten.ge.Scalar(to_dtype_64, 6.0);  to_dtype_64 = None
        __or___tensor_21 = torch.ops.aten.__or__.Tensor(le_scalar_21, ge_scalar_21);  le_scalar_21 = ge_scalar_21 = None
        new_zeros_default_177 = torch.ops.aten.new_zeros.default(to_dtype_63, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_21 = torch.ops.aten.where.self(__or___tensor_21, new_zeros_default_177, to_dtype_63);  __or___tensor_21 = new_zeros_default_177 = to_dtype_63 = None
        to_dtype_65 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_65, convolution_default_19, primals_272, primals_270, primals_271, new_zeros_default_57, new_zeros_default_58, False, 1e-05, [True, True, True]);  to_dtype_65 = convolution_default_19 = primals_272 = primals_270 = primals_271 = new_zeros_default_57 = new_zeros_default_58 = None
        getitem_348 = native_batch_norm_backward_default_32[0]
        getitem_349 = native_batch_norm_backward_default_32[1]
        getitem_350 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(getitem_348, hardtanh__default_12, primals_267, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 192, [True, True, False]);  getitem_348 = hardtanh__default_12 = primals_267 = None
        getitem_351 = convolution_backward_default_32[0]
        getitem_352 = convolution_backward_default_32[1]
        getitem_353 = convolution_backward_default_32[2];  convolution_backward_default_32 = None
        to_dtype_66 = torch.ops.aten.to.dtype(getitem_351, torch.float32);  getitem_351 = None
        to_dtype_67 = torch.ops.aten.to.dtype(clone_default_12, torch.float32);  clone_default_12 = None
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_67, 0.0)
        ge_scalar_22 = torch.ops.aten.ge.Scalar(to_dtype_67, 6.0);  to_dtype_67 = None
        __or___tensor_22 = torch.ops.aten.__or__.Tensor(le_scalar_22, ge_scalar_22);  le_scalar_22 = ge_scalar_22 = None
        new_zeros_default_178 = torch.ops.aten.new_zeros.default(to_dtype_66, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_22 = torch.ops.aten.where.self(__or___tensor_22, new_zeros_default_178, to_dtype_66);  __or___tensor_22 = new_zeros_default_178 = to_dtype_66 = None
        to_dtype_68 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_68, convolution_default_18, primals_266, primals_264, primals_265, new_zeros_default_54, new_zeros_default_55, False, 1e-05, [True, True, True]);  to_dtype_68 = convolution_default_18 = primals_266 = primals_264 = primals_265 = new_zeros_default_54 = new_zeros_default_55 = None
        getitem_354 = native_batch_norm_backward_default_33[0]
        getitem_355 = native_batch_norm_backward_default_33[1]
        getitem_356 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(getitem_354, add_tensor_2, primals_261, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_354 = add_tensor_2 = primals_261 = None
        getitem_357 = convolution_backward_default_33[0]
        getitem_358 = convolution_backward_default_33[1]
        getitem_359 = convolution_backward_default_33[2];  convolution_backward_default_33 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(getitem_357, convolution_default_17, primals_260, primals_258, primals_259, new_zeros_default_51, new_zeros_default_52, False, 1e-05, [True, True, True]);  convolution_default_17 = primals_260 = primals_258 = primals_259 = new_zeros_default_51 = new_zeros_default_52 = None
        getitem_360 = native_batch_norm_backward_default_34[0]
        getitem_361 = native_batch_norm_backward_default_34[1]
        getitem_362 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(getitem_360, hardtanh__default_11, primals_255, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_360 = hardtanh__default_11 = primals_255 = None
        getitem_363 = convolution_backward_default_34[0]
        getitem_364 = convolution_backward_default_34[1]
        getitem_365 = convolution_backward_default_34[2];  convolution_backward_default_34 = None
        to_dtype_69 = torch.ops.aten.to.dtype(getitem_363, torch.float32);  getitem_363 = None
        to_dtype_70 = torch.ops.aten.to.dtype(clone_default_11, torch.float32);  clone_default_11 = None
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_70, 0.0)
        ge_scalar_23 = torch.ops.aten.ge.Scalar(to_dtype_70, 6.0);  to_dtype_70 = None
        __or___tensor_23 = torch.ops.aten.__or__.Tensor(le_scalar_23, ge_scalar_23);  le_scalar_23 = ge_scalar_23 = None
        new_zeros_default_179 = torch.ops.aten.new_zeros.default(to_dtype_69, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(__or___tensor_23, new_zeros_default_179, to_dtype_69);  __or___tensor_23 = new_zeros_default_179 = to_dtype_69 = None
        to_dtype_71 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_71, convolution_default_16, primals_254, primals_252, primals_253, new_zeros_default_48, new_zeros_default_49, False, 1e-05, [True, True, True]);  to_dtype_71 = convolution_default_16 = primals_254 = primals_252 = primals_253 = new_zeros_default_48 = new_zeros_default_49 = None
        getitem_366 = native_batch_norm_backward_default_35[0]
        getitem_367 = native_batch_norm_backward_default_35[1]
        getitem_368 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_366, hardtanh__default_10, primals_249, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 192, [True, True, False]);  getitem_366 = hardtanh__default_10 = primals_249 = None
        getitem_369 = convolution_backward_default_35[0]
        getitem_370 = convolution_backward_default_35[1]
        getitem_371 = convolution_backward_default_35[2];  convolution_backward_default_35 = None
        to_dtype_72 = torch.ops.aten.to.dtype(getitem_369, torch.float32);  getitem_369 = None
        to_dtype_73 = torch.ops.aten.to.dtype(clone_default_10, torch.float32);  clone_default_10 = None
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_73, 0.0)
        ge_scalar_24 = torch.ops.aten.ge.Scalar(to_dtype_73, 6.0);  to_dtype_73 = None
        __or___tensor_24 = torch.ops.aten.__or__.Tensor(le_scalar_24, ge_scalar_24);  le_scalar_24 = ge_scalar_24 = None
        new_zeros_default_180 = torch.ops.aten.new_zeros.default(to_dtype_72, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_24 = torch.ops.aten.where.self(__or___tensor_24, new_zeros_default_180, to_dtype_72);  __or___tensor_24 = new_zeros_default_180 = to_dtype_72 = None
        to_dtype_74 = torch.ops.aten.to.dtype(where_self_24, torch.float32);  where_self_24 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_74, convolution_default_15, primals_248, primals_246, primals_247, new_zeros_default_45, new_zeros_default_46, False, 1e-05, [True, True, True]);  to_dtype_74 = convolution_default_15 = primals_248 = primals_246 = primals_247 = new_zeros_default_45 = new_zeros_default_46 = None
        getitem_372 = native_batch_norm_backward_default_36[0]
        getitem_373 = native_batch_norm_backward_default_36[1]
        getitem_374 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(getitem_372, add_tensor_1, primals_243, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_372 = add_tensor_1 = primals_243 = None
        getitem_375 = convolution_backward_default_36[0]
        getitem_376 = convolution_backward_default_36[1]
        getitem_377 = convolution_backward_default_36[2];  convolution_backward_default_36 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(getitem_357, getitem_375);  getitem_357 = getitem_375 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_17, convolution_default_14, primals_242, primals_240, primals_241, new_zeros_default_42, new_zeros_default_43, False, 1e-05, [True, True, True]);  convolution_default_14 = primals_242 = primals_240 = primals_241 = new_zeros_default_42 = new_zeros_default_43 = None
        getitem_378 = native_batch_norm_backward_default_37[0]
        getitem_379 = native_batch_norm_backward_default_37[1]
        getitem_380 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(getitem_378, hardtanh__default_9, primals_237, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_378 = hardtanh__default_9 = primals_237 = None
        getitem_381 = convolution_backward_default_37[0]
        getitem_382 = convolution_backward_default_37[1]
        getitem_383 = convolution_backward_default_37[2];  convolution_backward_default_37 = None
        to_dtype_75 = torch.ops.aten.to.dtype(getitem_381, torch.float32);  getitem_381 = None
        to_dtype_76 = torch.ops.aten.to.dtype(clone_default_9, torch.float32);  clone_default_9 = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_76, 0.0)
        ge_scalar_25 = torch.ops.aten.ge.Scalar(to_dtype_76, 6.0);  to_dtype_76 = None
        __or___tensor_25 = torch.ops.aten.__or__.Tensor(le_scalar_25, ge_scalar_25);  le_scalar_25 = ge_scalar_25 = None
        new_zeros_default_181 = torch.ops.aten.new_zeros.default(to_dtype_75, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_25 = torch.ops.aten.where.self(__or___tensor_25, new_zeros_default_181, to_dtype_75);  __or___tensor_25 = new_zeros_default_181 = to_dtype_75 = None
        to_dtype_77 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_77, convolution_default_13, primals_236, primals_234, primals_235, new_zeros_default_39, new_zeros_default_40, False, 1e-05, [True, True, True]);  to_dtype_77 = convolution_default_13 = primals_236 = primals_234 = primals_235 = new_zeros_default_39 = new_zeros_default_40 = None
        getitem_384 = native_batch_norm_backward_default_38[0]
        getitem_385 = native_batch_norm_backward_default_38[1]
        getitem_386 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(getitem_384, hardtanh__default_8, primals_231, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 192, [True, True, False]);  getitem_384 = hardtanh__default_8 = primals_231 = None
        getitem_387 = convolution_backward_default_38[0]
        getitem_388 = convolution_backward_default_38[1]
        getitem_389 = convolution_backward_default_38[2];  convolution_backward_default_38 = None
        to_dtype_78 = torch.ops.aten.to.dtype(getitem_387, torch.float32);  getitem_387 = None
        to_dtype_79 = torch.ops.aten.to.dtype(clone_default_8, torch.float32);  clone_default_8 = None
        le_scalar_26 = torch.ops.aten.le.Scalar(to_dtype_79, 0.0)
        ge_scalar_26 = torch.ops.aten.ge.Scalar(to_dtype_79, 6.0);  to_dtype_79 = None
        __or___tensor_26 = torch.ops.aten.__or__.Tensor(le_scalar_26, ge_scalar_26);  le_scalar_26 = ge_scalar_26 = None
        new_zeros_default_182 = torch.ops.aten.new_zeros.default(to_dtype_78, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_26 = torch.ops.aten.where.self(__or___tensor_26, new_zeros_default_182, to_dtype_78);  __or___tensor_26 = new_zeros_default_182 = to_dtype_78 = None
        to_dtype_80 = torch.ops.aten.to.dtype(where_self_26, torch.float32);  where_self_26 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_80, convolution_default_12, primals_230, primals_228, primals_229, new_zeros_default_36, new_zeros_default_37, False, 1e-05, [True, True, True]);  to_dtype_80 = convolution_default_12 = primals_230 = primals_228 = primals_229 = new_zeros_default_36 = new_zeros_default_37 = None
        getitem_390 = native_batch_norm_backward_default_39[0]
        getitem_391 = native_batch_norm_backward_default_39[1]
        getitem_392 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(getitem_390, getitem_33, primals_225, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_390 = getitem_33 = primals_225 = None
        getitem_393 = convolution_backward_default_39[0]
        getitem_394 = convolution_backward_default_39[1]
        getitem_395 = convolution_backward_default_39[2];  convolution_backward_default_39 = None
        add_tensor_18 = torch.ops.aten.add.Tensor(add_tensor_17, getitem_393);  add_tensor_17 = getitem_393 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_18, convolution_default_11, primals_224, primals_222, primals_223, new_zeros_default_33, new_zeros_default_34, False, 1e-05, [True, True, True]);  add_tensor_18 = convolution_default_11 = primals_224 = primals_222 = primals_223 = new_zeros_default_33 = new_zeros_default_34 = None
        getitem_396 = native_batch_norm_backward_default_40[0]
        getitem_397 = native_batch_norm_backward_default_40[1]
        getitem_398 = native_batch_norm_backward_default_40[2];  native_batch_norm_backward_default_40 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(getitem_396, hardtanh__default_7, primals_219, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_396 = hardtanh__default_7 = primals_219 = None
        getitem_399 = convolution_backward_default_40[0]
        getitem_400 = convolution_backward_default_40[1]
        getitem_401 = convolution_backward_default_40[2];  convolution_backward_default_40 = None
        to_dtype_81 = torch.ops.aten.to.dtype(getitem_399, torch.float32);  getitem_399 = None
        to_dtype_82 = torch.ops.aten.to.dtype(clone_default_7, torch.float32);  clone_default_7 = None
        le_scalar_27 = torch.ops.aten.le.Scalar(to_dtype_82, 0.0)
        ge_scalar_27 = torch.ops.aten.ge.Scalar(to_dtype_82, 6.0);  to_dtype_82 = None
        __or___tensor_27 = torch.ops.aten.__or__.Tensor(le_scalar_27, ge_scalar_27);  le_scalar_27 = ge_scalar_27 = None
        new_zeros_default_183 = torch.ops.aten.new_zeros.default(to_dtype_81, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_27 = torch.ops.aten.where.self(__or___tensor_27, new_zeros_default_183, to_dtype_81);  __or___tensor_27 = new_zeros_default_183 = to_dtype_81 = None
        to_dtype_83 = torch.ops.aten.to.dtype(where_self_27, torch.float32);  where_self_27 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_83, convolution_default_10, primals_218, primals_216, primals_217, new_zeros_default_30, new_zeros_default_31, False, 1e-05, [True, True, True]);  to_dtype_83 = convolution_default_10 = primals_218 = primals_216 = primals_217 = new_zeros_default_30 = new_zeros_default_31 = None
        getitem_402 = native_batch_norm_backward_default_41[0]
        getitem_403 = native_batch_norm_backward_default_41[1]
        getitem_404 = native_batch_norm_backward_default_41[2];  native_batch_norm_backward_default_41 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(getitem_402, hardtanh__default_6, primals_213, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 144, [True, True, False]);  getitem_402 = hardtanh__default_6 = primals_213 = None
        getitem_405 = convolution_backward_default_41[0]
        getitem_406 = convolution_backward_default_41[1]
        getitem_407 = convolution_backward_default_41[2];  convolution_backward_default_41 = None
        to_dtype_84 = torch.ops.aten.to.dtype(getitem_405, torch.float32);  getitem_405 = None
        to_dtype_85 = torch.ops.aten.to.dtype(clone_default_6, torch.float32);  clone_default_6 = None
        le_scalar_28 = torch.ops.aten.le.Scalar(to_dtype_85, 0.0)
        ge_scalar_28 = torch.ops.aten.ge.Scalar(to_dtype_85, 6.0);  to_dtype_85 = None
        __or___tensor_28 = torch.ops.aten.__or__.Tensor(le_scalar_28, ge_scalar_28);  le_scalar_28 = ge_scalar_28 = None
        new_zeros_default_184 = torch.ops.aten.new_zeros.default(to_dtype_84, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_28 = torch.ops.aten.where.self(__or___tensor_28, new_zeros_default_184, to_dtype_84);  __or___tensor_28 = new_zeros_default_184 = to_dtype_84 = None
        to_dtype_86 = torch.ops.aten.to.dtype(where_self_28, torch.float32);  where_self_28 = None
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_86, convolution_default_9, primals_212, primals_210, primals_211, new_zeros_default_27, new_zeros_default_28, False, 1e-05, [True, True, True]);  to_dtype_86 = convolution_default_9 = primals_212 = primals_210 = primals_211 = new_zeros_default_27 = new_zeros_default_28 = None
        getitem_408 = native_batch_norm_backward_default_42[0]
        getitem_409 = native_batch_norm_backward_default_42[1]
        getitem_410 = native_batch_norm_backward_default_42[2];  native_batch_norm_backward_default_42 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(getitem_408, add_tensor, primals_207, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_408 = add_tensor = primals_207 = None
        getitem_411 = convolution_backward_default_42[0]
        getitem_412 = convolution_backward_default_42[1]
        getitem_413 = convolution_backward_default_42[2];  convolution_backward_default_42 = None
        native_batch_norm_backward_default_43 = torch.ops.aten.native_batch_norm_backward.default(getitem_411, convolution_default_8, primals_206, primals_204, primals_205, new_zeros_default_24, new_zeros_default_25, False, 1e-05, [True, True, True]);  convolution_default_8 = primals_206 = primals_204 = primals_205 = new_zeros_default_24 = new_zeros_default_25 = None
        getitem_414 = native_batch_norm_backward_default_43[0]
        getitem_415 = native_batch_norm_backward_default_43[1]
        getitem_416 = native_batch_norm_backward_default_43[2];  native_batch_norm_backward_default_43 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(getitem_414, hardtanh__default_5, primals_201, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_414 = hardtanh__default_5 = primals_201 = None
        getitem_417 = convolution_backward_default_43[0]
        getitem_418 = convolution_backward_default_43[1]
        getitem_419 = convolution_backward_default_43[2];  convolution_backward_default_43 = None
        to_dtype_87 = torch.ops.aten.to.dtype(getitem_417, torch.float32);  getitem_417 = None
        to_dtype_88 = torch.ops.aten.to.dtype(clone_default_5, torch.float32);  clone_default_5 = None
        le_scalar_29 = torch.ops.aten.le.Scalar(to_dtype_88, 0.0)
        ge_scalar_29 = torch.ops.aten.ge.Scalar(to_dtype_88, 6.0);  to_dtype_88 = None
        __or___tensor_29 = torch.ops.aten.__or__.Tensor(le_scalar_29, ge_scalar_29);  le_scalar_29 = ge_scalar_29 = None
        new_zeros_default_185 = torch.ops.aten.new_zeros.default(to_dtype_87, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_29 = torch.ops.aten.where.self(__or___tensor_29, new_zeros_default_185, to_dtype_87);  __or___tensor_29 = new_zeros_default_185 = to_dtype_87 = None
        to_dtype_89 = torch.ops.aten.to.dtype(where_self_29, torch.float32);  where_self_29 = None
        native_batch_norm_backward_default_44 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_89, convolution_default_7, primals_200, primals_198, primals_199, new_zeros_default_21, new_zeros_default_22, False, 1e-05, [True, True, True]);  to_dtype_89 = convolution_default_7 = primals_200 = primals_198 = primals_199 = new_zeros_default_21 = new_zeros_default_22 = None
        getitem_420 = native_batch_norm_backward_default_44[0]
        getitem_421 = native_batch_norm_backward_default_44[1]
        getitem_422 = native_batch_norm_backward_default_44[2];  native_batch_norm_backward_default_44 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(getitem_420, hardtanh__default_4, primals_195, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 144, [True, True, False]);  getitem_420 = hardtanh__default_4 = primals_195 = None
        getitem_423 = convolution_backward_default_44[0]
        getitem_424 = convolution_backward_default_44[1]
        getitem_425 = convolution_backward_default_44[2];  convolution_backward_default_44 = None
        to_dtype_90 = torch.ops.aten.to.dtype(getitem_423, torch.float32);  getitem_423 = None
        to_dtype_91 = torch.ops.aten.to.dtype(clone_default_4, torch.float32);  clone_default_4 = None
        le_scalar_30 = torch.ops.aten.le.Scalar(to_dtype_91, 0.0)
        ge_scalar_30 = torch.ops.aten.ge.Scalar(to_dtype_91, 6.0);  to_dtype_91 = None
        __or___tensor_30 = torch.ops.aten.__or__.Tensor(le_scalar_30, ge_scalar_30);  le_scalar_30 = ge_scalar_30 = None
        new_zeros_default_186 = torch.ops.aten.new_zeros.default(to_dtype_90, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_30 = torch.ops.aten.where.self(__or___tensor_30, new_zeros_default_186, to_dtype_90);  __or___tensor_30 = new_zeros_default_186 = to_dtype_90 = None
        to_dtype_92 = torch.ops.aten.to.dtype(where_self_30, torch.float32);  where_self_30 = None
        native_batch_norm_backward_default_45 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_92, convolution_default_6, primals_194, primals_192, primals_193, new_zeros_default_18, new_zeros_default_19, False, 1e-05, [True, True, True]);  to_dtype_92 = convolution_default_6 = primals_194 = primals_192 = primals_193 = new_zeros_default_18 = new_zeros_default_19 = None
        getitem_426 = native_batch_norm_backward_default_45[0]
        getitem_427 = native_batch_norm_backward_default_45[1]
        getitem_428 = native_batch_norm_backward_default_45[2];  native_batch_norm_backward_default_45 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(getitem_426, getitem_15, primals_189, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_426 = getitem_15 = primals_189 = None
        getitem_429 = convolution_backward_default_45[0]
        getitem_430 = convolution_backward_default_45[1]
        getitem_431 = convolution_backward_default_45[2];  convolution_backward_default_45 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(getitem_411, getitem_429);  getitem_411 = getitem_429 = None
        native_batch_norm_backward_default_46 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_19, convolution_default_5, primals_188, primals_186, primals_187, new_zeros_default_15, new_zeros_default_16, False, 1e-05, [True, True, True]);  add_tensor_19 = convolution_default_5 = primals_188 = primals_186 = primals_187 = new_zeros_default_15 = new_zeros_default_16 = None
        getitem_432 = native_batch_norm_backward_default_46[0]
        getitem_433 = native_batch_norm_backward_default_46[1]
        getitem_434 = native_batch_norm_backward_default_46[2];  native_batch_norm_backward_default_46 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(getitem_432, hardtanh__default_3, primals_183, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_432 = hardtanh__default_3 = primals_183 = None
        getitem_435 = convolution_backward_default_46[0]
        getitem_436 = convolution_backward_default_46[1]
        getitem_437 = convolution_backward_default_46[2];  convolution_backward_default_46 = None
        to_dtype_93 = torch.ops.aten.to.dtype(getitem_435, torch.float32);  getitem_435 = None
        to_dtype_94 = torch.ops.aten.to.dtype(clone_default_3, torch.float32);  clone_default_3 = None
        le_scalar_31 = torch.ops.aten.le.Scalar(to_dtype_94, 0.0)
        ge_scalar_31 = torch.ops.aten.ge.Scalar(to_dtype_94, 6.0);  to_dtype_94 = None
        __or___tensor_31 = torch.ops.aten.__or__.Tensor(le_scalar_31, ge_scalar_31);  le_scalar_31 = ge_scalar_31 = None
        new_zeros_default_187 = torch.ops.aten.new_zeros.default(to_dtype_93, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_31 = torch.ops.aten.where.self(__or___tensor_31, new_zeros_default_187, to_dtype_93);  __or___tensor_31 = new_zeros_default_187 = to_dtype_93 = None
        to_dtype_95 = torch.ops.aten.to.dtype(where_self_31, torch.float32);  where_self_31 = None
        native_batch_norm_backward_default_47 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_95, convolution_default_4, primals_182, primals_180, primals_181, new_zeros_default_12, new_zeros_default_13, False, 1e-05, [True, True, True]);  to_dtype_95 = convolution_default_4 = primals_182 = primals_180 = primals_181 = new_zeros_default_12 = new_zeros_default_13 = None
        getitem_438 = native_batch_norm_backward_default_47[0]
        getitem_439 = native_batch_norm_backward_default_47[1]
        getitem_440 = native_batch_norm_backward_default_47[2];  native_batch_norm_backward_default_47 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(getitem_438, hardtanh__default_2, primals_177, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 96, [True, True, False]);  getitem_438 = hardtanh__default_2 = primals_177 = None
        getitem_441 = convolution_backward_default_47[0]
        getitem_442 = convolution_backward_default_47[1]
        getitem_443 = convolution_backward_default_47[2];  convolution_backward_default_47 = None
        to_dtype_96 = torch.ops.aten.to.dtype(getitem_441, torch.float32);  getitem_441 = None
        to_dtype_97 = torch.ops.aten.to.dtype(clone_default_2, torch.float32);  clone_default_2 = None
        le_scalar_32 = torch.ops.aten.le.Scalar(to_dtype_97, 0.0)
        ge_scalar_32 = torch.ops.aten.ge.Scalar(to_dtype_97, 6.0);  to_dtype_97 = None
        __or___tensor_32 = torch.ops.aten.__or__.Tensor(le_scalar_32, ge_scalar_32);  le_scalar_32 = ge_scalar_32 = None
        new_zeros_default_188 = torch.ops.aten.new_zeros.default(to_dtype_96, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_32 = torch.ops.aten.where.self(__or___tensor_32, new_zeros_default_188, to_dtype_96);  __or___tensor_32 = new_zeros_default_188 = to_dtype_96 = None
        to_dtype_98 = torch.ops.aten.to.dtype(where_self_32, torch.float32);  where_self_32 = None
        native_batch_norm_backward_default_48 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_98, convolution_default_3, primals_176, primals_174, primals_175, new_zeros_default_9, new_zeros_default_10, False, 1e-05, [True, True, True]);  to_dtype_98 = convolution_default_3 = primals_176 = primals_174 = primals_175 = new_zeros_default_9 = new_zeros_default_10 = None
        getitem_444 = native_batch_norm_backward_default_48[0]
        getitem_445 = native_batch_norm_backward_default_48[1]
        getitem_446 = native_batch_norm_backward_default_48[2];  native_batch_norm_backward_default_48 = None
        convolution_backward_default_48 = torch.ops.aten.convolution_backward.default(getitem_444, getitem_6, primals_171, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_444 = getitem_6 = primals_171 = None
        getitem_447 = convolution_backward_default_48[0]
        getitem_448 = convolution_backward_default_48[1]
        getitem_449 = convolution_backward_default_48[2];  convolution_backward_default_48 = None
        native_batch_norm_backward_default_49 = torch.ops.aten.native_batch_norm_backward.default(getitem_447, convolution_default_2, primals_170, primals_168, primals_169, new_zeros_default_6, new_zeros_default_7, False, 1e-05, [True, True, True]);  getitem_447 = convolution_default_2 = primals_170 = primals_168 = primals_169 = new_zeros_default_6 = new_zeros_default_7 = None
        getitem_450 = native_batch_norm_backward_default_49[0]
        getitem_451 = native_batch_norm_backward_default_49[1]
        getitem_452 = native_batch_norm_backward_default_49[2];  native_batch_norm_backward_default_49 = None
        convolution_backward_default_49 = torch.ops.aten.convolution_backward.default(getitem_450, hardtanh__default_1, primals_165, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_450 = hardtanh__default_1 = primals_165 = None
        getitem_453 = convolution_backward_default_49[0]
        getitem_454 = convolution_backward_default_49[1]
        getitem_455 = convolution_backward_default_49[2];  convolution_backward_default_49 = None
        to_dtype_99 = torch.ops.aten.to.dtype(getitem_453, torch.float32);  getitem_453 = None
        to_dtype_100 = torch.ops.aten.to.dtype(clone_default_1, torch.float32);  clone_default_1 = None
        le_scalar_33 = torch.ops.aten.le.Scalar(to_dtype_100, 0.0)
        ge_scalar_33 = torch.ops.aten.ge.Scalar(to_dtype_100, 6.0);  to_dtype_100 = None
        __or___tensor_33 = torch.ops.aten.__or__.Tensor(le_scalar_33, ge_scalar_33);  le_scalar_33 = ge_scalar_33 = None
        new_zeros_default_189 = torch.ops.aten.new_zeros.default(to_dtype_99, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_33 = torch.ops.aten.where.self(__or___tensor_33, new_zeros_default_189, to_dtype_99);  __or___tensor_33 = new_zeros_default_189 = to_dtype_99 = None
        to_dtype_101 = torch.ops.aten.to.dtype(where_self_33, torch.float32);  where_self_33 = None
        native_batch_norm_backward_default_50 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_101, convolution_default_1, primals_164, primals_162, primals_163, new_zeros_default_3, new_zeros_default_4, False, 1e-05, [True, True, True]);  to_dtype_101 = convolution_default_1 = primals_164 = primals_162 = primals_163 = new_zeros_default_3 = new_zeros_default_4 = None
        getitem_456 = native_batch_norm_backward_default_50[0]
        getitem_457 = native_batch_norm_backward_default_50[1]
        getitem_458 = native_batch_norm_backward_default_50[2];  native_batch_norm_backward_default_50 = None
        convolution_backward_default_50 = torch.ops.aten.convolution_backward.default(getitem_456, hardtanh__default, primals_159, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 32, [True, True, False]);  getitem_456 = hardtanh__default = primals_159 = None
        getitem_459 = convolution_backward_default_50[0]
        getitem_460 = convolution_backward_default_50[1]
        getitem_461 = convolution_backward_default_50[2];  convolution_backward_default_50 = None
        to_dtype_102 = torch.ops.aten.to.dtype(getitem_459, torch.float32);  getitem_459 = None
        to_dtype_103 = torch.ops.aten.to.dtype(clone_default, torch.float32);  clone_default = None
        le_scalar_34 = torch.ops.aten.le.Scalar(to_dtype_103, 0.0)
        ge_scalar_34 = torch.ops.aten.ge.Scalar(to_dtype_103, 6.0);  to_dtype_103 = None
        __or___tensor_34 = torch.ops.aten.__or__.Tensor(le_scalar_34, ge_scalar_34);  le_scalar_34 = ge_scalar_34 = None
        new_zeros_default_190 = torch.ops.aten.new_zeros.default(to_dtype_102, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_34 = torch.ops.aten.where.self(__or___tensor_34, new_zeros_default_190, to_dtype_102);  __or___tensor_34 = new_zeros_default_190 = to_dtype_102 = None
        to_dtype_104 = torch.ops.aten.to.dtype(where_self_34, torch.float32);  where_self_34 = None
        native_batch_norm_backward_default_51 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_104, convolution_default, primals_8, primals_6, primals_7, new_zeros_default, new_zeros_default_1, False, 1e-05, [True, True, True]);  to_dtype_104 = convolution_default = primals_8 = primals_6 = primals_7 = new_zeros_default = new_zeros_default_1 = None
        getitem_462 = native_batch_norm_backward_default_51[0]
        getitem_463 = native_batch_norm_backward_default_51[1]
        getitem_464 = native_batch_norm_backward_default_51[2];  native_batch_norm_backward_default_51 = None
        convolution_backward_default_51 = torch.ops.aten.convolution_backward.default(getitem_462, primals_315, primals_3, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_462 = primals_315 = primals_3 = None
        getitem_465 = convolution_backward_default_51[0]
        getitem_466 = convolution_backward_default_51[1]
        getitem_467 = convolution_backward_default_51[2];  convolution_backward_default_51 = None
        return [addmm_default, view_default_1, t_default_4, getitem_466, getitem_464, None, None, None, getitem_463, getitem_304, getitem_302, None, None, None, getitem_301, getitem_298, getitem_296, None, None, None, getitem_295, getitem_292, getitem_290, None, None, None, getitem_289, getitem_286, getitem_284, None, None, None, getitem_283, getitem_280, getitem_278, None, None, None, getitem_277, getitem_274, getitem_272, None, None, None, getitem_271, getitem_268, getitem_266, None, None, None, getitem_265, getitem_262, getitem_260, None, None, None, getitem_259, getitem_256, getitem_254, None, None, None, getitem_253, getitem_250, getitem_248, None, None, None, getitem_247, getitem_244, getitem_242, None, None, None, getitem_241, getitem_238, getitem_236, None, None, None, getitem_235, getitem_232, getitem_230, None, None, None, getitem_229, getitem_226, getitem_224, None, None, None, getitem_223, getitem_220, getitem_218, None, None, None, getitem_217, getitem_214, getitem_212, None, None, None, getitem_211, getitem_208, getitem_206, None, None, None, getitem_205, getitem_202, getitem_200, None, None, None, getitem_199, getitem_196, getitem_194, None, None, None, getitem_193, getitem_190, getitem_188, None, None, None, getitem_187, getitem_184, getitem_182, None, None, None, getitem_181, getitem_178, getitem_176, None, None, None, getitem_175, getitem_172, getitem_170, None, None, None, getitem_169, getitem_166, getitem_164, None, None, None, getitem_163, getitem_160, getitem_158, None, None, None, getitem_157, getitem_460, getitem_458, None, None, None, getitem_457, getitem_454, getitem_452, None, None, None, getitem_451, getitem_448, getitem_446, None, None, None, getitem_445, getitem_442, getitem_440, None, None, None, getitem_439, getitem_436, getitem_434, None, None, None, getitem_433, getitem_430, getitem_428, None, None, None, getitem_427, getitem_424, getitem_422, None, None, None, getitem_421, getitem_418, getitem_416, None, None, None, getitem_415, getitem_412, getitem_410, None, None, None, getitem_409, getitem_406, getitem_404, None, None, None, getitem_403, getitem_400, getitem_398, None, None, None, getitem_397, getitem_394, getitem_392, None, None, None, getitem_391, getitem_388, getitem_386, None, None, None, getitem_385, getitem_382, getitem_380, None, None, None, getitem_379, getitem_376, getitem_374, None, None, None, getitem_373, getitem_370, getitem_368, None, None, None, getitem_367, getitem_364, getitem_362, None, None, None, getitem_361, getitem_358, getitem_356, None, None, None, getitem_355, getitem_352, getitem_350, None, None, None, getitem_349, getitem_346, getitem_344, None, None, None, getitem_343, getitem_340, getitem_338, None, None, None, getitem_337, getitem_334, getitem_332, None, None, None, getitem_331, getitem_328, getitem_326, None, None, None, getitem_325, getitem_322, getitem_320, None, None, None, getitem_319, getitem_316, getitem_314, None, None, None, getitem_313, getitem_310, getitem_308, None, None, None, getitem_307, None]
        
