
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/hf_Bart/hf_Bart_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101):
        view_default = torch.ops.aten.view.default(primals_101, [-1, 512]);  primals_101 = None
        embedding_default = torch.ops.aten.embedding.default(primals_2, view_default, 1);  primals_2 = None
        mul_tensor = torch.ops.aten.mul.Tensor(embedding_default, 1.0);  embedding_default = None
        arange = torch.ops.aten.arange.start_step(0, 512, 1, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        add_tensor = torch.ops.aten.add.Tensor(arange, 2);  arange = None
        embedding_default_1 = torch.ops.aten.embedding.default(primals_1, add_tensor);  primals_1 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(mul_tensor, embedding_default_1);  mul_tensor = embedding_default_1 = None
        native_layer_norm_default = torch.ops.aten.native_layer_norm.default(add_tensor_1, [768], primals_4, primals_3, 1e-05)
        getitem = native_layer_norm_default[0]
        getitem_1 = native_layer_norm_default[1]
        getitem_2 = native_layer_norm_default[2];  native_layer_norm_default = None
        view_default_1 = torch.ops.aten.view.default(getitem, [2048, 768])
        t_default = torch.ops.aten.t.default(primals_18);  primals_18 = None
        addmm_default = torch.ops.aten.addmm.default(primals_17, view_default_1, t_default);  primals_17 = None
        view_default_2 = torch.ops.aten.view.default(addmm_default, [4, 512, 768]);  addmm_default = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(view_default_2, 0.125);  view_default_2 = None
        view_default_3 = torch.ops.aten.view.default(getitem, [2048, 768])
        t_default_1 = torch.ops.aten.t.default(primals_12);  primals_12 = None
        addmm_default_1 = torch.ops.aten.addmm.default(primals_11, view_default_3, t_default_1);  primals_11 = None
        view_default_4 = torch.ops.aten.view.default(addmm_default_1, [4, 512, 768]);  addmm_default_1 = None
        view_default_5 = torch.ops.aten.view.default(view_default_4, [4, -1, 12, 64]);  view_default_4 = None
        transpose_int = torch.ops.aten.transpose.int(view_default_5, 1, 2);  view_default_5 = None
        clone_default = torch.ops.aten.clone.default(transpose_int, memory_format = torch.contiguous_format);  transpose_int = None
        view_default_6 = torch.ops.aten.view.default(getitem, [2048, 768])
        t_default_2 = torch.ops.aten.t.default(primals_20);  primals_20 = None
        addmm_default_2 = torch.ops.aten.addmm.default(primals_19, view_default_6, t_default_2);  primals_19 = None
        view_default_7 = torch.ops.aten.view.default(addmm_default_2, [4, 512, 768]);  addmm_default_2 = None
        view_default_8 = torch.ops.aten.view.default(view_default_7, [4, -1, 12, 64]);  view_default_7 = None
        transpose_int_1 = torch.ops.aten.transpose.int(view_default_8, 1, 2);  view_default_8 = None
        clone_default_1 = torch.ops.aten.clone.default(transpose_int_1, memory_format = torch.contiguous_format);  transpose_int_1 = None
        view_default_9 = torch.ops.aten.view.default(mul_tensor_1, [4, 512, 12, 64]);  mul_tensor_1 = None
        transpose_int_2 = torch.ops.aten.transpose.int(view_default_9, 1, 2);  view_default_9 = None
        clone_default_2 = torch.ops.aten.clone.default(transpose_int_2, memory_format = torch.contiguous_format);  transpose_int_2 = None
        view_default_10 = torch.ops.aten.view.default(clone_default_2, [48, -1, 64]);  clone_default_2 = None
        view_default_11 = torch.ops.aten.view.default(clone_default, [48, -1, 64]);  clone_default = None
        view_default_12 = torch.ops.aten.view.default(clone_default_1, [48, -1, 64]);  clone_default_1 = None
        transpose_int_3 = torch.ops.aten.transpose.int(view_default_11, 1, 2);  view_default_11 = None
        bmm_default = torch.ops.aten.bmm.default(view_default_10, transpose_int_3)
        _softmax_default = torch.ops.aten._softmax.default(bmm_default, -1, False);  bmm_default = None
        bmm_default_1 = torch.ops.aten.bmm.default(_softmax_default, view_default_12)
        view_default_13 = torch.ops.aten.view.default(bmm_default_1, [4, 12, 512, 64]);  bmm_default_1 = None
        transpose_int_4 = torch.ops.aten.transpose.int(view_default_13, 1, 2);  view_default_13 = None
        clone_default_3 = torch.ops.aten.clone.default(transpose_int_4, memory_format = torch.contiguous_format);  transpose_int_4 = None
        _unsafe_view_default = torch.ops.aten._unsafe_view.default(clone_default_3, [4, 512, 768]);  clone_default_3 = None
        view_default_14 = torch.ops.aten.view.default(_unsafe_view_default, [2048, 768]);  _unsafe_view_default = None
        t_default_3 = torch.ops.aten.t.default(primals_16);  primals_16 = None
        addmm_default_3 = torch.ops.aten.addmm.default(primals_15, view_default_14, t_default_3);  primals_15 = None
        view_default_15 = torch.ops.aten.view.default(addmm_default_3, [4, 512, 768]);  addmm_default_3 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(getitem, view_default_15);  getitem = view_default_15 = None
        native_layer_norm_default_1 = torch.ops.aten.native_layer_norm.default(add_tensor_2, [768], primals_14, primals_13, 1e-05)
        getitem_3 = native_layer_norm_default_1[0]
        getitem_4 = native_layer_norm_default_1[1]
        getitem_5 = native_layer_norm_default_1[2];  native_layer_norm_default_1 = None
        view_default_16 = torch.ops.aten.view.default(getitem_3, [2048, 768])
        t_default_4 = torch.ops.aten.t.default(primals_6);  primals_6 = None
        addmm_default_4 = torch.ops.aten.addmm.default(primals_5, view_default_16, t_default_4);  primals_5 = None
        view_default_17 = torch.ops.aten.view.default(addmm_default_4, [4, 512, 3072]);  addmm_default_4 = None
        gelu_default = torch.ops.aten.gelu.default(view_default_17)
        view_default_18 = torch.ops.aten.view.default(gelu_default, [2048, 3072]);  gelu_default = None
        t_default_5 = torch.ops.aten.t.default(primals_8);  primals_8 = None
        addmm_default_5 = torch.ops.aten.addmm.default(primals_7, view_default_18, t_default_5);  primals_7 = None
        view_default_19 = torch.ops.aten.view.default(addmm_default_5, [4, 512, 768]);  addmm_default_5 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(getitem_3, view_default_19);  getitem_3 = view_default_19 = None
        native_layer_norm_default_2 = torch.ops.aten.native_layer_norm.default(add_tensor_3, [768], primals_10, primals_9, 1e-05)
        getitem_6 = native_layer_norm_default_2[0]
        getitem_7 = native_layer_norm_default_2[1]
        getitem_8 = native_layer_norm_default_2[2];  native_layer_norm_default_2 = None
        view_default_20 = torch.ops.aten.view.default(getitem_6, [2048, 768])
        t_default_6 = torch.ops.aten.t.default(primals_34);  primals_34 = None
        addmm_default_6 = torch.ops.aten.addmm.default(primals_33, view_default_20, t_default_6);  primals_33 = None
        view_default_21 = torch.ops.aten.view.default(addmm_default_6, [4, 512, 768]);  addmm_default_6 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(view_default_21, 0.125);  view_default_21 = None
        view_default_22 = torch.ops.aten.view.default(getitem_6, [2048, 768])
        t_default_7 = torch.ops.aten.t.default(primals_28);  primals_28 = None
        addmm_default_7 = torch.ops.aten.addmm.default(primals_27, view_default_22, t_default_7);  primals_27 = None
        view_default_23 = torch.ops.aten.view.default(addmm_default_7, [4, 512, 768]);  addmm_default_7 = None
        view_default_24 = torch.ops.aten.view.default(view_default_23, [4, -1, 12, 64]);  view_default_23 = None
        transpose_int_5 = torch.ops.aten.transpose.int(view_default_24, 1, 2);  view_default_24 = None
        clone_default_4 = torch.ops.aten.clone.default(transpose_int_5, memory_format = torch.contiguous_format);  transpose_int_5 = None
        view_default_25 = torch.ops.aten.view.default(getitem_6, [2048, 768])
        t_default_8 = torch.ops.aten.t.default(primals_36);  primals_36 = None
        addmm_default_8 = torch.ops.aten.addmm.default(primals_35, view_default_25, t_default_8);  primals_35 = None
        view_default_26 = torch.ops.aten.view.default(addmm_default_8, [4, 512, 768]);  addmm_default_8 = None
        view_default_27 = torch.ops.aten.view.default(view_default_26, [4, -1, 12, 64]);  view_default_26 = None
        transpose_int_6 = torch.ops.aten.transpose.int(view_default_27, 1, 2);  view_default_27 = None
        clone_default_5 = torch.ops.aten.clone.default(transpose_int_6, memory_format = torch.contiguous_format);  transpose_int_6 = None
        view_default_28 = torch.ops.aten.view.default(mul_tensor_2, [4, 512, 12, 64]);  mul_tensor_2 = None
        transpose_int_7 = torch.ops.aten.transpose.int(view_default_28, 1, 2);  view_default_28 = None
        clone_default_6 = torch.ops.aten.clone.default(transpose_int_7, memory_format = torch.contiguous_format);  transpose_int_7 = None
        view_default_29 = torch.ops.aten.view.default(clone_default_6, [48, -1, 64]);  clone_default_6 = None
        view_default_30 = torch.ops.aten.view.default(clone_default_4, [48, -1, 64]);  clone_default_4 = None
        view_default_31 = torch.ops.aten.view.default(clone_default_5, [48, -1, 64]);  clone_default_5 = None
        transpose_int_8 = torch.ops.aten.transpose.int(view_default_30, 1, 2);  view_default_30 = None
        bmm_default_2 = torch.ops.aten.bmm.default(view_default_29, transpose_int_8)
        _softmax_default_1 = torch.ops.aten._softmax.default(bmm_default_2, -1, False);  bmm_default_2 = None
        bmm_default_3 = torch.ops.aten.bmm.default(_softmax_default_1, view_default_31)
        view_default_32 = torch.ops.aten.view.default(bmm_default_3, [4, 12, 512, 64]);  bmm_default_3 = None
        transpose_int_9 = torch.ops.aten.transpose.int(view_default_32, 1, 2);  view_default_32 = None
        clone_default_7 = torch.ops.aten.clone.default(transpose_int_9, memory_format = torch.contiguous_format);  transpose_int_9 = None
        _unsafe_view_default_1 = torch.ops.aten._unsafe_view.default(clone_default_7, [4, 512, 768]);  clone_default_7 = None
        view_default_33 = torch.ops.aten.view.default(_unsafe_view_default_1, [2048, 768]);  _unsafe_view_default_1 = None
        t_default_9 = torch.ops.aten.t.default(primals_32);  primals_32 = None
        addmm_default_9 = torch.ops.aten.addmm.default(primals_31, view_default_33, t_default_9);  primals_31 = None
        view_default_34 = torch.ops.aten.view.default(addmm_default_9, [4, 512, 768]);  addmm_default_9 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(getitem_6, view_default_34);  getitem_6 = view_default_34 = None
        native_layer_norm_default_3 = torch.ops.aten.native_layer_norm.default(add_tensor_4, [768], primals_30, primals_29, 1e-05)
        getitem_9 = native_layer_norm_default_3[0]
        getitem_10 = native_layer_norm_default_3[1]
        getitem_11 = native_layer_norm_default_3[2];  native_layer_norm_default_3 = None
        view_default_35 = torch.ops.aten.view.default(getitem_9, [2048, 768])
        t_default_10 = torch.ops.aten.t.default(primals_22);  primals_22 = None
        addmm_default_10 = torch.ops.aten.addmm.default(primals_21, view_default_35, t_default_10);  primals_21 = None
        view_default_36 = torch.ops.aten.view.default(addmm_default_10, [4, 512, 3072]);  addmm_default_10 = None
        gelu_default_1 = torch.ops.aten.gelu.default(view_default_36)
        view_default_37 = torch.ops.aten.view.default(gelu_default_1, [2048, 3072]);  gelu_default_1 = None
        t_default_11 = torch.ops.aten.t.default(primals_24);  primals_24 = None
        addmm_default_11 = torch.ops.aten.addmm.default(primals_23, view_default_37, t_default_11);  primals_23 = None
        view_default_38 = torch.ops.aten.view.default(addmm_default_11, [4, 512, 768]);  addmm_default_11 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(getitem_9, view_default_38);  getitem_9 = view_default_38 = None
        native_layer_norm_default_4 = torch.ops.aten.native_layer_norm.default(add_tensor_5, [768], primals_26, primals_25, 1e-05)
        getitem_12 = native_layer_norm_default_4[0]
        getitem_13 = native_layer_norm_default_4[1]
        getitem_14 = native_layer_norm_default_4[2];  native_layer_norm_default_4 = None
        view_default_39 = torch.ops.aten.view.default(getitem_12, [2048, 768])
        t_default_12 = torch.ops.aten.t.default(primals_50);  primals_50 = None
        addmm_default_12 = torch.ops.aten.addmm.default(primals_49, view_default_39, t_default_12);  primals_49 = None
        view_default_40 = torch.ops.aten.view.default(addmm_default_12, [4, 512, 768]);  addmm_default_12 = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(view_default_40, 0.125);  view_default_40 = None
        view_default_41 = torch.ops.aten.view.default(getitem_12, [2048, 768])
        t_default_13 = torch.ops.aten.t.default(primals_44);  primals_44 = None
        addmm_default_13 = torch.ops.aten.addmm.default(primals_43, view_default_41, t_default_13);  primals_43 = None
        view_default_42 = torch.ops.aten.view.default(addmm_default_13, [4, 512, 768]);  addmm_default_13 = None
        view_default_43 = torch.ops.aten.view.default(view_default_42, [4, -1, 12, 64]);  view_default_42 = None
        transpose_int_10 = torch.ops.aten.transpose.int(view_default_43, 1, 2);  view_default_43 = None
        clone_default_8 = torch.ops.aten.clone.default(transpose_int_10, memory_format = torch.contiguous_format);  transpose_int_10 = None
        view_default_44 = torch.ops.aten.view.default(getitem_12, [2048, 768])
        t_default_14 = torch.ops.aten.t.default(primals_52);  primals_52 = None
        addmm_default_14 = torch.ops.aten.addmm.default(primals_51, view_default_44, t_default_14);  primals_51 = None
        view_default_45 = torch.ops.aten.view.default(addmm_default_14, [4, 512, 768]);  addmm_default_14 = None
        view_default_46 = torch.ops.aten.view.default(view_default_45, [4, -1, 12, 64]);  view_default_45 = None
        transpose_int_11 = torch.ops.aten.transpose.int(view_default_46, 1, 2);  view_default_46 = None
        clone_default_9 = torch.ops.aten.clone.default(transpose_int_11, memory_format = torch.contiguous_format);  transpose_int_11 = None
        view_default_47 = torch.ops.aten.view.default(mul_tensor_3, [4, 512, 12, 64]);  mul_tensor_3 = None
        transpose_int_12 = torch.ops.aten.transpose.int(view_default_47, 1, 2);  view_default_47 = None
        clone_default_10 = torch.ops.aten.clone.default(transpose_int_12, memory_format = torch.contiguous_format);  transpose_int_12 = None
        view_default_48 = torch.ops.aten.view.default(clone_default_10, [48, -1, 64]);  clone_default_10 = None
        view_default_49 = torch.ops.aten.view.default(clone_default_8, [48, -1, 64]);  clone_default_8 = None
        view_default_50 = torch.ops.aten.view.default(clone_default_9, [48, -1, 64]);  clone_default_9 = None
        transpose_int_13 = torch.ops.aten.transpose.int(view_default_49, 1, 2);  view_default_49 = None
        bmm_default_4 = torch.ops.aten.bmm.default(view_default_48, transpose_int_13)
        _softmax_default_2 = torch.ops.aten._softmax.default(bmm_default_4, -1, False);  bmm_default_4 = None
        bmm_default_5 = torch.ops.aten.bmm.default(_softmax_default_2, view_default_50)
        view_default_51 = torch.ops.aten.view.default(bmm_default_5, [4, 12, 512, 64]);  bmm_default_5 = None
        transpose_int_14 = torch.ops.aten.transpose.int(view_default_51, 1, 2);  view_default_51 = None
        clone_default_11 = torch.ops.aten.clone.default(transpose_int_14, memory_format = torch.contiguous_format);  transpose_int_14 = None
        _unsafe_view_default_2 = torch.ops.aten._unsafe_view.default(clone_default_11, [4, 512, 768]);  clone_default_11 = None
        view_default_52 = torch.ops.aten.view.default(_unsafe_view_default_2, [2048, 768]);  _unsafe_view_default_2 = None
        t_default_15 = torch.ops.aten.t.default(primals_48);  primals_48 = None
        addmm_default_15 = torch.ops.aten.addmm.default(primals_47, view_default_52, t_default_15);  primals_47 = None
        view_default_53 = torch.ops.aten.view.default(addmm_default_15, [4, 512, 768]);  addmm_default_15 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(getitem_12, view_default_53);  getitem_12 = view_default_53 = None
        native_layer_norm_default_5 = torch.ops.aten.native_layer_norm.default(add_tensor_6, [768], primals_46, primals_45, 1e-05)
        getitem_15 = native_layer_norm_default_5[0]
        getitem_16 = native_layer_norm_default_5[1]
        getitem_17 = native_layer_norm_default_5[2];  native_layer_norm_default_5 = None
        view_default_54 = torch.ops.aten.view.default(getitem_15, [2048, 768])
        t_default_16 = torch.ops.aten.t.default(primals_38);  primals_38 = None
        addmm_default_16 = torch.ops.aten.addmm.default(primals_37, view_default_54, t_default_16);  primals_37 = None
        view_default_55 = torch.ops.aten.view.default(addmm_default_16, [4, 512, 3072]);  addmm_default_16 = None
        gelu_default_2 = torch.ops.aten.gelu.default(view_default_55)
        view_default_56 = torch.ops.aten.view.default(gelu_default_2, [2048, 3072]);  gelu_default_2 = None
        t_default_17 = torch.ops.aten.t.default(primals_40);  primals_40 = None
        addmm_default_17 = torch.ops.aten.addmm.default(primals_39, view_default_56, t_default_17);  primals_39 = None
        view_default_57 = torch.ops.aten.view.default(addmm_default_17, [4, 512, 768]);  addmm_default_17 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(getitem_15, view_default_57);  getitem_15 = view_default_57 = None
        native_layer_norm_default_6 = torch.ops.aten.native_layer_norm.default(add_tensor_7, [768], primals_42, primals_41, 1e-05)
        getitem_18 = native_layer_norm_default_6[0]
        getitem_19 = native_layer_norm_default_6[1]
        getitem_20 = native_layer_norm_default_6[2];  native_layer_norm_default_6 = None
        view_default_58 = torch.ops.aten.view.default(getitem_18, [2048, 768])
        t_default_18 = torch.ops.aten.t.default(primals_66);  primals_66 = None
        addmm_default_18 = torch.ops.aten.addmm.default(primals_65, view_default_58, t_default_18);  primals_65 = None
        view_default_59 = torch.ops.aten.view.default(addmm_default_18, [4, 512, 768]);  addmm_default_18 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(view_default_59, 0.125);  view_default_59 = None
        view_default_60 = torch.ops.aten.view.default(getitem_18, [2048, 768])
        t_default_19 = torch.ops.aten.t.default(primals_60);  primals_60 = None
        addmm_default_19 = torch.ops.aten.addmm.default(primals_59, view_default_60, t_default_19);  primals_59 = None
        view_default_61 = torch.ops.aten.view.default(addmm_default_19, [4, 512, 768]);  addmm_default_19 = None
        view_default_62 = torch.ops.aten.view.default(view_default_61, [4, -1, 12, 64]);  view_default_61 = None
        transpose_int_15 = torch.ops.aten.transpose.int(view_default_62, 1, 2);  view_default_62 = None
        clone_default_12 = torch.ops.aten.clone.default(transpose_int_15, memory_format = torch.contiguous_format);  transpose_int_15 = None
        view_default_63 = torch.ops.aten.view.default(getitem_18, [2048, 768])
        t_default_20 = torch.ops.aten.t.default(primals_68);  primals_68 = None
        addmm_default_20 = torch.ops.aten.addmm.default(primals_67, view_default_63, t_default_20);  primals_67 = None
        view_default_64 = torch.ops.aten.view.default(addmm_default_20, [4, 512, 768]);  addmm_default_20 = None
        view_default_65 = torch.ops.aten.view.default(view_default_64, [4, -1, 12, 64]);  view_default_64 = None
        transpose_int_16 = torch.ops.aten.transpose.int(view_default_65, 1, 2);  view_default_65 = None
        clone_default_13 = torch.ops.aten.clone.default(transpose_int_16, memory_format = torch.contiguous_format);  transpose_int_16 = None
        view_default_66 = torch.ops.aten.view.default(mul_tensor_4, [4, 512, 12, 64]);  mul_tensor_4 = None
        transpose_int_17 = torch.ops.aten.transpose.int(view_default_66, 1, 2);  view_default_66 = None
        clone_default_14 = torch.ops.aten.clone.default(transpose_int_17, memory_format = torch.contiguous_format);  transpose_int_17 = None
        view_default_67 = torch.ops.aten.view.default(clone_default_14, [48, -1, 64]);  clone_default_14 = None
        view_default_68 = torch.ops.aten.view.default(clone_default_12, [48, -1, 64]);  clone_default_12 = None
        view_default_69 = torch.ops.aten.view.default(clone_default_13, [48, -1, 64]);  clone_default_13 = None
        transpose_int_18 = torch.ops.aten.transpose.int(view_default_68, 1, 2);  view_default_68 = None
        bmm_default_6 = torch.ops.aten.bmm.default(view_default_67, transpose_int_18)
        _softmax_default_3 = torch.ops.aten._softmax.default(bmm_default_6, -1, False);  bmm_default_6 = None
        bmm_default_7 = torch.ops.aten.bmm.default(_softmax_default_3, view_default_69)
        view_default_70 = torch.ops.aten.view.default(bmm_default_7, [4, 12, 512, 64]);  bmm_default_7 = None
        transpose_int_19 = torch.ops.aten.transpose.int(view_default_70, 1, 2);  view_default_70 = None
        clone_default_15 = torch.ops.aten.clone.default(transpose_int_19, memory_format = torch.contiguous_format);  transpose_int_19 = None
        _unsafe_view_default_3 = torch.ops.aten._unsafe_view.default(clone_default_15, [4, 512, 768]);  clone_default_15 = None
        view_default_71 = torch.ops.aten.view.default(_unsafe_view_default_3, [2048, 768]);  _unsafe_view_default_3 = None
        t_default_21 = torch.ops.aten.t.default(primals_64);  primals_64 = None
        addmm_default_21 = torch.ops.aten.addmm.default(primals_63, view_default_71, t_default_21);  primals_63 = None
        view_default_72 = torch.ops.aten.view.default(addmm_default_21, [4, 512, 768]);  addmm_default_21 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(getitem_18, view_default_72);  getitem_18 = view_default_72 = None
        native_layer_norm_default_7 = torch.ops.aten.native_layer_norm.default(add_tensor_8, [768], primals_62, primals_61, 1e-05)
        getitem_21 = native_layer_norm_default_7[0]
        getitem_22 = native_layer_norm_default_7[1]
        getitem_23 = native_layer_norm_default_7[2];  native_layer_norm_default_7 = None
        view_default_73 = torch.ops.aten.view.default(getitem_21, [2048, 768])
        t_default_22 = torch.ops.aten.t.default(primals_54);  primals_54 = None
        addmm_default_22 = torch.ops.aten.addmm.default(primals_53, view_default_73, t_default_22);  primals_53 = None
        view_default_74 = torch.ops.aten.view.default(addmm_default_22, [4, 512, 3072]);  addmm_default_22 = None
        gelu_default_3 = torch.ops.aten.gelu.default(view_default_74)
        view_default_75 = torch.ops.aten.view.default(gelu_default_3, [2048, 3072]);  gelu_default_3 = None
        t_default_23 = torch.ops.aten.t.default(primals_56);  primals_56 = None
        addmm_default_23 = torch.ops.aten.addmm.default(primals_55, view_default_75, t_default_23);  primals_55 = None
        view_default_76 = torch.ops.aten.view.default(addmm_default_23, [4, 512, 768]);  addmm_default_23 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(getitem_21, view_default_76);  getitem_21 = view_default_76 = None
        native_layer_norm_default_8 = torch.ops.aten.native_layer_norm.default(add_tensor_9, [768], primals_58, primals_57, 1e-05)
        getitem_24 = native_layer_norm_default_8[0]
        getitem_25 = native_layer_norm_default_8[1]
        getitem_26 = native_layer_norm_default_8[2];  native_layer_norm_default_8 = None
        view_default_77 = torch.ops.aten.view.default(getitem_24, [2048, 768])
        t_default_24 = torch.ops.aten.t.default(primals_82);  primals_82 = None
        addmm_default_24 = torch.ops.aten.addmm.default(primals_81, view_default_77, t_default_24);  primals_81 = None
        view_default_78 = torch.ops.aten.view.default(addmm_default_24, [4, 512, 768]);  addmm_default_24 = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(view_default_78, 0.125);  view_default_78 = None
        view_default_79 = torch.ops.aten.view.default(getitem_24, [2048, 768])
        t_default_25 = torch.ops.aten.t.default(primals_76);  primals_76 = None
        addmm_default_25 = torch.ops.aten.addmm.default(primals_75, view_default_79, t_default_25);  primals_75 = None
        view_default_80 = torch.ops.aten.view.default(addmm_default_25, [4, 512, 768]);  addmm_default_25 = None
        view_default_81 = torch.ops.aten.view.default(view_default_80, [4, -1, 12, 64]);  view_default_80 = None
        transpose_int_20 = torch.ops.aten.transpose.int(view_default_81, 1, 2);  view_default_81 = None
        clone_default_16 = torch.ops.aten.clone.default(transpose_int_20, memory_format = torch.contiguous_format);  transpose_int_20 = None
        view_default_82 = torch.ops.aten.view.default(getitem_24, [2048, 768])
        t_default_26 = torch.ops.aten.t.default(primals_84);  primals_84 = None
        addmm_default_26 = torch.ops.aten.addmm.default(primals_83, view_default_82, t_default_26);  primals_83 = None
        view_default_83 = torch.ops.aten.view.default(addmm_default_26, [4, 512, 768]);  addmm_default_26 = None
        view_default_84 = torch.ops.aten.view.default(view_default_83, [4, -1, 12, 64]);  view_default_83 = None
        transpose_int_21 = torch.ops.aten.transpose.int(view_default_84, 1, 2);  view_default_84 = None
        clone_default_17 = torch.ops.aten.clone.default(transpose_int_21, memory_format = torch.contiguous_format);  transpose_int_21 = None
        view_default_85 = torch.ops.aten.view.default(mul_tensor_5, [4, 512, 12, 64]);  mul_tensor_5 = None
        transpose_int_22 = torch.ops.aten.transpose.int(view_default_85, 1, 2);  view_default_85 = None
        clone_default_18 = torch.ops.aten.clone.default(transpose_int_22, memory_format = torch.contiguous_format);  transpose_int_22 = None
        view_default_86 = torch.ops.aten.view.default(clone_default_18, [48, -1, 64]);  clone_default_18 = None
        view_default_87 = torch.ops.aten.view.default(clone_default_16, [48, -1, 64]);  clone_default_16 = None
        view_default_88 = torch.ops.aten.view.default(clone_default_17, [48, -1, 64]);  clone_default_17 = None
        transpose_int_23 = torch.ops.aten.transpose.int(view_default_87, 1, 2);  view_default_87 = None
        bmm_default_8 = torch.ops.aten.bmm.default(view_default_86, transpose_int_23)
        _softmax_default_4 = torch.ops.aten._softmax.default(bmm_default_8, -1, False);  bmm_default_8 = None
        bmm_default_9 = torch.ops.aten.bmm.default(_softmax_default_4, view_default_88)
        view_default_89 = torch.ops.aten.view.default(bmm_default_9, [4, 12, 512, 64]);  bmm_default_9 = None
        transpose_int_24 = torch.ops.aten.transpose.int(view_default_89, 1, 2);  view_default_89 = None
        clone_default_19 = torch.ops.aten.clone.default(transpose_int_24, memory_format = torch.contiguous_format);  transpose_int_24 = None
        _unsafe_view_default_4 = torch.ops.aten._unsafe_view.default(clone_default_19, [4, 512, 768]);  clone_default_19 = None
        view_default_90 = torch.ops.aten.view.default(_unsafe_view_default_4, [2048, 768]);  _unsafe_view_default_4 = None
        t_default_27 = torch.ops.aten.t.default(primals_80);  primals_80 = None
        addmm_default_27 = torch.ops.aten.addmm.default(primals_79, view_default_90, t_default_27);  primals_79 = None
        view_default_91 = torch.ops.aten.view.default(addmm_default_27, [4, 512, 768]);  addmm_default_27 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(getitem_24, view_default_91);  getitem_24 = view_default_91 = None
        native_layer_norm_default_9 = torch.ops.aten.native_layer_norm.default(add_tensor_10, [768], primals_78, primals_77, 1e-05)
        getitem_27 = native_layer_norm_default_9[0]
        getitem_28 = native_layer_norm_default_9[1]
        getitem_29 = native_layer_norm_default_9[2];  native_layer_norm_default_9 = None
        view_default_92 = torch.ops.aten.view.default(getitem_27, [2048, 768])
        t_default_28 = torch.ops.aten.t.default(primals_70);  primals_70 = None
        addmm_default_28 = torch.ops.aten.addmm.default(primals_69, view_default_92, t_default_28);  primals_69 = None
        view_default_93 = torch.ops.aten.view.default(addmm_default_28, [4, 512, 3072]);  addmm_default_28 = None
        gelu_default_4 = torch.ops.aten.gelu.default(view_default_93)
        view_default_94 = torch.ops.aten.view.default(gelu_default_4, [2048, 3072]);  gelu_default_4 = None
        t_default_29 = torch.ops.aten.t.default(primals_72);  primals_72 = None
        addmm_default_29 = torch.ops.aten.addmm.default(primals_71, view_default_94, t_default_29);  primals_71 = None
        view_default_95 = torch.ops.aten.view.default(addmm_default_29, [4, 512, 768]);  addmm_default_29 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(getitem_27, view_default_95);  getitem_27 = view_default_95 = None
        native_layer_norm_default_10 = torch.ops.aten.native_layer_norm.default(add_tensor_11, [768], primals_74, primals_73, 1e-05)
        getitem_30 = native_layer_norm_default_10[0]
        getitem_31 = native_layer_norm_default_10[1]
        getitem_32 = native_layer_norm_default_10[2];  native_layer_norm_default_10 = None
        view_default_96 = torch.ops.aten.view.default(getitem_30, [2048, 768])
        t_default_30 = torch.ops.aten.t.default(primals_98);  primals_98 = None
        addmm_default_30 = torch.ops.aten.addmm.default(primals_97, view_default_96, t_default_30);  primals_97 = None
        view_default_97 = torch.ops.aten.view.default(addmm_default_30, [4, 512, 768]);  addmm_default_30 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(view_default_97, 0.125);  view_default_97 = None
        view_default_98 = torch.ops.aten.view.default(getitem_30, [2048, 768])
        t_default_31 = torch.ops.aten.t.default(primals_92);  primals_92 = None
        addmm_default_31 = torch.ops.aten.addmm.default(primals_91, view_default_98, t_default_31);  primals_91 = None
        view_default_99 = torch.ops.aten.view.default(addmm_default_31, [4, 512, 768]);  addmm_default_31 = None
        view_default_100 = torch.ops.aten.view.default(view_default_99, [4, -1, 12, 64]);  view_default_99 = None
        transpose_int_25 = torch.ops.aten.transpose.int(view_default_100, 1, 2);  view_default_100 = None
        clone_default_20 = torch.ops.aten.clone.default(transpose_int_25, memory_format = torch.contiguous_format);  transpose_int_25 = None
        view_default_101 = torch.ops.aten.view.default(getitem_30, [2048, 768])
        t_default_32 = torch.ops.aten.t.default(primals_100);  primals_100 = None
        addmm_default_32 = torch.ops.aten.addmm.default(primals_99, view_default_101, t_default_32);  primals_99 = None
        view_default_102 = torch.ops.aten.view.default(addmm_default_32, [4, 512, 768]);  addmm_default_32 = None
        view_default_103 = torch.ops.aten.view.default(view_default_102, [4, -1, 12, 64]);  view_default_102 = None
        transpose_int_26 = torch.ops.aten.transpose.int(view_default_103, 1, 2);  view_default_103 = None
        clone_default_21 = torch.ops.aten.clone.default(transpose_int_26, memory_format = torch.contiguous_format);  transpose_int_26 = None
        view_default_104 = torch.ops.aten.view.default(mul_tensor_6, [4, 512, 12, 64]);  mul_tensor_6 = None
        transpose_int_27 = torch.ops.aten.transpose.int(view_default_104, 1, 2);  view_default_104 = None
        clone_default_22 = torch.ops.aten.clone.default(transpose_int_27, memory_format = torch.contiguous_format);  transpose_int_27 = None
        view_default_105 = torch.ops.aten.view.default(clone_default_22, [48, -1, 64]);  clone_default_22 = None
        view_default_106 = torch.ops.aten.view.default(clone_default_20, [48, -1, 64]);  clone_default_20 = None
        view_default_107 = torch.ops.aten.view.default(clone_default_21, [48, -1, 64]);  clone_default_21 = None
        transpose_int_28 = torch.ops.aten.transpose.int(view_default_106, 1, 2);  view_default_106 = None
        bmm_default_10 = torch.ops.aten.bmm.default(view_default_105, transpose_int_28)
        _softmax_default_5 = torch.ops.aten._softmax.default(bmm_default_10, -1, False);  bmm_default_10 = None
        bmm_default_11 = torch.ops.aten.bmm.default(_softmax_default_5, view_default_107)
        view_default_108 = torch.ops.aten.view.default(bmm_default_11, [4, 12, 512, 64]);  bmm_default_11 = None
        transpose_int_29 = torch.ops.aten.transpose.int(view_default_108, 1, 2);  view_default_108 = None
        clone_default_23 = torch.ops.aten.clone.default(transpose_int_29, memory_format = torch.contiguous_format);  transpose_int_29 = None
        _unsafe_view_default_5 = torch.ops.aten._unsafe_view.default(clone_default_23, [4, 512, 768]);  clone_default_23 = None
        view_default_109 = torch.ops.aten.view.default(_unsafe_view_default_5, [2048, 768]);  _unsafe_view_default_5 = None
        t_default_33 = torch.ops.aten.t.default(primals_96);  primals_96 = None
        addmm_default_33 = torch.ops.aten.addmm.default(primals_95, view_default_109, t_default_33);  primals_95 = None
        view_default_110 = torch.ops.aten.view.default(addmm_default_33, [4, 512, 768]);  addmm_default_33 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(getitem_30, view_default_110);  getitem_30 = view_default_110 = None
        native_layer_norm_default_11 = torch.ops.aten.native_layer_norm.default(add_tensor_12, [768], primals_94, primals_93, 1e-05)
        getitem_33 = native_layer_norm_default_11[0]
        getitem_34 = native_layer_norm_default_11[1]
        getitem_35 = native_layer_norm_default_11[2];  native_layer_norm_default_11 = None
        view_default_111 = torch.ops.aten.view.default(getitem_33, [2048, 768])
        t_default_34 = torch.ops.aten.t.default(primals_86);  primals_86 = None
        addmm_default_34 = torch.ops.aten.addmm.default(primals_85, view_default_111, t_default_34);  primals_85 = None
        view_default_112 = torch.ops.aten.view.default(addmm_default_34, [4, 512, 3072]);  addmm_default_34 = None
        gelu_default_5 = torch.ops.aten.gelu.default(view_default_112)
        view_default_113 = torch.ops.aten.view.default(gelu_default_5, [2048, 3072]);  gelu_default_5 = None
        t_default_35 = torch.ops.aten.t.default(primals_88);  primals_88 = None
        addmm_default_35 = torch.ops.aten.addmm.default(primals_87, view_default_113, t_default_35);  primals_87 = None
        view_default_114 = torch.ops.aten.view.default(addmm_default_35, [4, 512, 768]);  addmm_default_35 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(getitem_33, view_default_114);  getitem_33 = view_default_114 = None
        native_layer_norm_default_12 = torch.ops.aten.native_layer_norm.default(add_tensor_13, [768], primals_90, primals_89, 1e-05)
        getitem_36 = native_layer_norm_default_12[0]
        getitem_37 = native_layer_norm_default_12[1]
        getitem_38 = native_layer_norm_default_12[2];  native_layer_norm_default_12 = None
        return [getitem_36, view_default_1, t_default_32, view_default_73, add_tensor_1, primals_9, _softmax_default_3, add_tensor_8, getitem_22, transpose_int_18, view_default_107, view_default_69, transpose_int_28, primals_13, view_default_109, t_default_21, _softmax_default_5, add_tensor_13, view_default_71, add_tensor, view_default, view_default_111, t_default_33, view_default_29, add_tensor_12, getitem_34, getitem_35, t_default_2, t_default_34, view_default_10, t_default, view_default_6, view_default_112, view_default_3, t_default_35, getitem_1, getitem_37, primals_45, getitem_38, primals_46, t_default_1, getitem_2, primals_26, transpose_int_13, t_default_23, _softmax_default_2, t_default_24, t_default_15, primals_30, view_default_54, view_default_77, primals_29, getitem_26, getitem_25, t_default_22, add_tensor_6, add_tensor_9, primals_42, view_default_74, getitem_23, primals_25, primals_41, view_default_75, view_default_52, view_default_50, t_default_3, add_tensor_2, t_default_7, getitem_7, view_default_20, add_tensor_3, primals_14, _softmax_default, view_default_22, view_default_14, view_default_18, getitem_8, t_default_5, transpose_int_3, t_default_6, view_default_12, view_default_25, primals_10, t_default_25, view_default_33, getitem_10, t_default_26, add_tensor_4, primals_58, _softmax_default_1, view_default_35, view_default_82, view_default_79, primals_73, primals_61, t_default_9, view_default_31, transpose_int_8, primals_4, primals_62, primals_3, view_default_86, t_default_8, getitem_5, t_default_11, add_tensor_5, t_default_10, view_default_39, view_default_37, getitem_4, t_default_4, view_default_16, view_default_36, getitem_13, view_default_17, getitem_11, t_default_18, getitem_20, primals_94, t_default_19, view_default_63, getitem_19, view_default_67, view_default_60, t_default_20, primals_93, view_default_93, view_default_44, view_default_101, t_default_14, view_default_92, getitem_16, view_default_55, view_default_56, primals_90, t_default_27, view_default_94, view_default_90, view_default_96, view_default_88, t_default_29, t_default_17, getitem_28, getitem_14, getitem_31, view_default_41, add_tensor_7, t_default_16, getitem_32, add_tensor_11, t_default_13, getitem_29, primals_74, t_default_12, _softmax_default_4, view_default_58, add_tensor_10, t_default_30, primals_77, view_default_98, t_default_28, view_default_48, t_default_31, primals_57, primals_78, getitem_17, transpose_int_23, view_default_113, view_default_105, primals_89]
        
