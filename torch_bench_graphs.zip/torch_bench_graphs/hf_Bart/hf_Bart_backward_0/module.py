
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/hf_Bart/hf_Bart_backward_0/state_dict.pt'))

    
    
    def forward(self, view_default_1, t_default_32, view_default_73, add_tensor_1, primals_9, _softmax_default_3, add_tensor_8, getitem_22, transpose_int_18, view_default_107, view_default_69, transpose_int_28, primals_13, view_default_109, t_default_21, _softmax_default_5, add_tensor_13, view_default_71, add_tensor, view_default, view_default_111, t_default_33, view_default_29, add_tensor_12, getitem_34, getitem_35, t_default_2, t_default_34, view_default_10, t_default, view_default_6, view_default_112, view_default_3, t_default_35, getitem_1, getitem_37, primals_45, getitem_38, primals_46, t_default_1, getitem_2, primals_26, transpose_int_13, t_default_23, _softmax_default_2, t_default_24, t_default_15, primals_30, view_default_54, view_default_77, primals_29, getitem_26, getitem_25, t_default_22, add_tensor_6, add_tensor_9, primals_42, view_default_74, getitem_23, primals_25, primals_41, view_default_75, view_default_52, view_default_50, t_default_3, add_tensor_2, t_default_7, getitem_7, view_default_20, add_tensor_3, primals_14, _softmax_default, view_default_22, view_default_14, view_default_18, getitem_8, t_default_5, transpose_int_3, t_default_6, view_default_12, view_default_25, primals_10, t_default_25, view_default_33, getitem_10, t_default_26, add_tensor_4, primals_58, _softmax_default_1, view_default_35, view_default_82, view_default_79, primals_73, primals_61, t_default_9, view_default_31, transpose_int_8, primals_4, primals_62, primals_3, view_default_86, t_default_8, getitem_5, t_default_11, add_tensor_5, t_default_10, view_default_39, view_default_37, getitem_4, t_default_4, view_default_16, view_default_36, getitem_13, view_default_17, getitem_11, t_default_18, getitem_20, primals_94, t_default_19, view_default_63, getitem_19, view_default_67, view_default_60, t_default_20, primals_93, view_default_93, view_default_44, view_default_101, t_default_14, view_default_92, getitem_16, view_default_55, view_default_56, primals_90, t_default_27, view_default_94, view_default_90, view_default_96, view_default_88, t_default_29, t_default_17, getitem_28, getitem_14, getitem_31, view_default_41, add_tensor_7, t_default_16, getitem_32, add_tensor_11, t_default_13, getitem_29, primals_74, t_default_12, _softmax_default_4, view_default_58, add_tensor_10, t_default_30, primals_77, view_default_98, t_default_28, view_default_48, t_default_31, primals_57, primals_78, getitem_17, transpose_int_23, view_default_113, view_default_105, primals_89, tangents_1):
        native_layer_norm_backward_default = torch.ops.aten.native_layer_norm_backward.default(tangents_1, add_tensor_13, [768], getitem_37, getitem_38, primals_90, primals_89, [True, True, True]);  tangents_1 = add_tensor_13 = getitem_37 = getitem_38 = primals_90 = primals_89 = None
        getitem_39 = native_layer_norm_backward_default[0]
        getitem_40 = native_layer_norm_backward_default[1]
        getitem_41 = native_layer_norm_backward_default[2];  native_layer_norm_backward_default = None
        view_default_115 = torch.ops.aten.view.default(getitem_39, [2048, 768])
        t_default_36 = torch.ops.aten.t.default(t_default_35);  t_default_35 = None
        mm_default = torch.ops.aten.mm.default(view_default_115, t_default_36);  t_default_36 = None
        t_default_37 = torch.ops.aten.t.default(view_default_115)
        mm_default_1 = torch.ops.aten.mm.default(t_default_37, view_default_113);  t_default_37 = view_default_113 = None
        t_default_38 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(view_default_115, [0], True);  view_default_115 = None
        view_default_116 = torch.ops.aten.view.default(sum_dim_int_list, [768]);  sum_dim_int_list = None
        t_default_39 = torch.ops.aten.t.default(t_default_38);  t_default_38 = None
        view_default_117 = torch.ops.aten.view.default(mm_default, [4, 512, 3072]);  mm_default = None
        to_dtype = torch.ops.aten.to.dtype(view_default_117, torch.float32);  view_default_117 = None
        to_dtype_1 = torch.ops.aten.to.dtype(view_default_112, torch.float32);  view_default_112 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(to_dtype_1, 0.7071067811865476)
        erf_default = torch.ops.aten.erf.default(mul_tensor_7);  mul_tensor_7 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(erf_default, 1);  erf_default = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(add_tensor_14, 0.5);  add_tensor_14 = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(to_dtype_1, to_dtype_1)
        mul_tensor_10 = torch.ops.aten.mul.Tensor(mul_tensor_9, -0.5);  mul_tensor_9 = None
        exp_default = torch.ops.aten.exp.default(mul_tensor_10);  mul_tensor_10 = None
        mul_tensor_11 = torch.ops.aten.mul.Tensor(exp_default, 0.3989422804014327);  exp_default = None
        mul_tensor_12 = torch.ops.aten.mul.Tensor(to_dtype_1, mul_tensor_11);  to_dtype_1 = mul_tensor_11 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(mul_tensor_8, mul_tensor_12);  mul_tensor_8 = mul_tensor_12 = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(to_dtype, add_tensor_15);  to_dtype = add_tensor_15 = None
        to_dtype_2 = torch.ops.aten.to.dtype(mul_tensor_13, torch.float32);  mul_tensor_13 = None
        view_default_118 = torch.ops.aten.view.default(to_dtype_2, [2048, 3072]);  to_dtype_2 = None
        t_default_40 = torch.ops.aten.t.default(t_default_34);  t_default_34 = None
        mm_default_2 = torch.ops.aten.mm.default(view_default_118, t_default_40);  t_default_40 = None
        t_default_41 = torch.ops.aten.t.default(view_default_118)
        mm_default_3 = torch.ops.aten.mm.default(t_default_41, view_default_111);  t_default_41 = view_default_111 = None
        t_default_42 = torch.ops.aten.t.default(mm_default_3);  mm_default_3 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(view_default_118, [0], True);  view_default_118 = None
        view_default_119 = torch.ops.aten.view.default(sum_dim_int_list_1, [3072]);  sum_dim_int_list_1 = None
        t_default_43 = torch.ops.aten.t.default(t_default_42);  t_default_42 = None
        view_default_120 = torch.ops.aten.view.default(mm_default_2, [4, 512, 768]);  mm_default_2 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(getitem_39, view_default_120);  getitem_39 = view_default_120 = None
        native_layer_norm_backward_default_1 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_16, add_tensor_12, [768], getitem_34, getitem_35, primals_94, primals_93, [True, True, True]);  add_tensor_16 = add_tensor_12 = getitem_34 = getitem_35 = primals_94 = primals_93 = None
        getitem_42 = native_layer_norm_backward_default_1[0]
        getitem_43 = native_layer_norm_backward_default_1[1]
        getitem_44 = native_layer_norm_backward_default_1[2];  native_layer_norm_backward_default_1 = None
        view_default_121 = torch.ops.aten.view.default(getitem_42, [2048, 768])
        t_default_44 = torch.ops.aten.t.default(t_default_33);  t_default_33 = None
        mm_default_4 = torch.ops.aten.mm.default(view_default_121, t_default_44);  t_default_44 = None
        t_default_45 = torch.ops.aten.t.default(view_default_121)
        mm_default_5 = torch.ops.aten.mm.default(t_default_45, view_default_109);  t_default_45 = view_default_109 = None
        t_default_46 = torch.ops.aten.t.default(mm_default_5);  mm_default_5 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(view_default_121, [0], True);  view_default_121 = None
        view_default_122 = torch.ops.aten.view.default(sum_dim_int_list_2, [768]);  sum_dim_int_list_2 = None
        t_default_47 = torch.ops.aten.t.default(t_default_46);  t_default_46 = None
        view_default_123 = torch.ops.aten.view.default(mm_default_4, [4, 512, 768]);  mm_default_4 = None
        view_default_124 = torch.ops.aten.view.default(view_default_123, [4, 512, 12, 64]);  view_default_123 = None
        transpose_int_30 = torch.ops.aten.transpose.int(view_default_124, 1, 2);  view_default_124 = None
        clone_default_24 = torch.ops.aten.clone.default(transpose_int_30, memory_format = torch.contiguous_format);  transpose_int_30 = None
        _unsafe_view_default_6 = torch.ops.aten._unsafe_view.default(clone_default_24, [48, 512, 64]);  clone_default_24 = None
        transpose_int_31 = torch.ops.aten.transpose.int(_softmax_default_5, 1, 2)
        bmm_default_12 = torch.ops.aten.bmm.default(transpose_int_31, _unsafe_view_default_6);  transpose_int_31 = None
        transpose_int_32 = torch.ops.aten.transpose.int(view_default_107, 1, 2);  view_default_107 = None
        bmm_default_13 = torch.ops.aten.bmm.default(_unsafe_view_default_6, transpose_int_32);  _unsafe_view_default_6 = transpose_int_32 = None
        _softmax_backward_data_default = torch.ops.aten._softmax_backward_data.default(bmm_default_13, _softmax_default_5, -1, torch.float32);  bmm_default_13 = _softmax_default_5 = None
        transpose_int_33 = torch.ops.aten.transpose.int(view_default_105, 1, 2);  view_default_105 = None
        bmm_default_14 = torch.ops.aten.bmm.default(transpose_int_33, _softmax_backward_data_default);  transpose_int_33 = None
        transpose_int_34 = torch.ops.aten.transpose.int(transpose_int_28, 1, 2);  transpose_int_28 = None
        bmm_default_15 = torch.ops.aten.bmm.default(_softmax_backward_data_default, transpose_int_34);  _softmax_backward_data_default = transpose_int_34 = None
        transpose_int_35 = torch.ops.aten.transpose.int(bmm_default_14, 1, 2);  bmm_default_14 = None
        view_default_125 = torch.ops.aten.view.default(bmm_default_12, [4, 12, 512, 64]);  bmm_default_12 = None
        view_default_126 = torch.ops.aten.view.default(transpose_int_35, [4, 12, 512, 64]);  transpose_int_35 = None
        view_default_127 = torch.ops.aten.view.default(bmm_default_15, [4, 12, 512, 64]);  bmm_default_15 = None
        transpose_int_36 = torch.ops.aten.transpose.int(view_default_127, 1, 2);  view_default_127 = None
        clone_default_25 = torch.ops.aten.clone.default(transpose_int_36, memory_format = torch.contiguous_format);  transpose_int_36 = None
        _unsafe_view_default_7 = torch.ops.aten._unsafe_view.default(clone_default_25, [4, 512, 768]);  clone_default_25 = None
        transpose_int_37 = torch.ops.aten.transpose.int(view_default_125, 1, 2);  view_default_125 = None
        clone_default_26 = torch.ops.aten.clone.default(transpose_int_37, memory_format = torch.contiguous_format);  transpose_int_37 = None
        _unsafe_view_default_8 = torch.ops.aten._unsafe_view.default(clone_default_26, [4, 512, 768]);  clone_default_26 = None
        view_default_128 = torch.ops.aten.view.default(_unsafe_view_default_8, [2048, 768]);  _unsafe_view_default_8 = None
        t_default_48 = torch.ops.aten.t.default(t_default_32);  t_default_32 = None
        mm_default_6 = torch.ops.aten.mm.default(view_default_128, t_default_48);  t_default_48 = None
        t_default_49 = torch.ops.aten.t.default(view_default_128)
        mm_default_7 = torch.ops.aten.mm.default(t_default_49, view_default_101);  t_default_49 = view_default_101 = None
        t_default_50 = torch.ops.aten.t.default(mm_default_7);  mm_default_7 = None
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(view_default_128, [0], True);  view_default_128 = None
        view_default_129 = torch.ops.aten.view.default(sum_dim_int_list_3, [768]);  sum_dim_int_list_3 = None
        t_default_51 = torch.ops.aten.t.default(t_default_50);  t_default_50 = None
        view_default_130 = torch.ops.aten.view.default(mm_default_6, [4, 512, 768]);  mm_default_6 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(getitem_42, view_default_130);  getitem_42 = view_default_130 = None
        transpose_int_38 = torch.ops.aten.transpose.int(view_default_126, 1, 2);  view_default_126 = None
        view_default_131 = torch.ops.aten.view.default(transpose_int_38, [4, 512, 768]);  transpose_int_38 = None
        clone_default_27 = torch.ops.aten.clone.default(view_default_131, memory_format = torch.contiguous_format);  view_default_131 = None
        _unsafe_view_default_9 = torch.ops.aten._unsafe_view.default(clone_default_27, [2048, 768]);  clone_default_27 = None
        t_default_52 = torch.ops.aten.t.default(t_default_31);  t_default_31 = None
        mm_default_8 = torch.ops.aten.mm.default(_unsafe_view_default_9, t_default_52);  t_default_52 = None
        t_default_53 = torch.ops.aten.t.default(_unsafe_view_default_9)
        mm_default_9 = torch.ops.aten.mm.default(t_default_53, view_default_98);  t_default_53 = view_default_98 = None
        t_default_54 = torch.ops.aten.t.default(mm_default_9);  mm_default_9 = None
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_9, [0], True);  _unsafe_view_default_9 = None
        view_default_132 = torch.ops.aten.view.default(sum_dim_int_list_4, [768]);  sum_dim_int_list_4 = None
        t_default_55 = torch.ops.aten.t.default(t_default_54);  t_default_54 = None
        view_default_133 = torch.ops.aten.view.default(mm_default_8, [4, 512, 768]);  mm_default_8 = None
        add_tensor_18 = torch.ops.aten.add.Tensor(add_tensor_17, view_default_133);  add_tensor_17 = view_default_133 = None
        mul_tensor_14 = torch.ops.aten.mul.Tensor(_unsafe_view_default_7, 0.125);  _unsafe_view_default_7 = None
        view_default_134 = torch.ops.aten.view.default(mul_tensor_14, [2048, 768]);  mul_tensor_14 = None
        t_default_56 = torch.ops.aten.t.default(t_default_30);  t_default_30 = None
        mm_default_10 = torch.ops.aten.mm.default(view_default_134, t_default_56);  t_default_56 = None
        t_default_57 = torch.ops.aten.t.default(view_default_134)
        mm_default_11 = torch.ops.aten.mm.default(t_default_57, view_default_96);  t_default_57 = view_default_96 = None
        t_default_58 = torch.ops.aten.t.default(mm_default_11);  mm_default_11 = None
        sum_dim_int_list_5 = torch.ops.aten.sum.dim_IntList(view_default_134, [0], True);  view_default_134 = None
        view_default_135 = torch.ops.aten.view.default(sum_dim_int_list_5, [768]);  sum_dim_int_list_5 = None
        t_default_59 = torch.ops.aten.t.default(t_default_58);  t_default_58 = None
        view_default_136 = torch.ops.aten.view.default(mm_default_10, [4, 512, 768]);  mm_default_10 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(add_tensor_18, view_default_136);  add_tensor_18 = view_default_136 = None
        native_layer_norm_backward_default_2 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_19, add_tensor_11, [768], getitem_31, getitem_32, primals_74, primals_73, [True, True, True]);  add_tensor_19 = add_tensor_11 = getitem_31 = getitem_32 = primals_74 = primals_73 = None
        getitem_45 = native_layer_norm_backward_default_2[0]
        getitem_46 = native_layer_norm_backward_default_2[1]
        getitem_47 = native_layer_norm_backward_default_2[2];  native_layer_norm_backward_default_2 = None
        view_default_137 = torch.ops.aten.view.default(getitem_45, [2048, 768])
        t_default_60 = torch.ops.aten.t.default(t_default_29);  t_default_29 = None
        mm_default_12 = torch.ops.aten.mm.default(view_default_137, t_default_60);  t_default_60 = None
        t_default_61 = torch.ops.aten.t.default(view_default_137)
        mm_default_13 = torch.ops.aten.mm.default(t_default_61, view_default_94);  t_default_61 = view_default_94 = None
        t_default_62 = torch.ops.aten.t.default(mm_default_13);  mm_default_13 = None
        sum_dim_int_list_6 = torch.ops.aten.sum.dim_IntList(view_default_137, [0], True);  view_default_137 = None
        view_default_138 = torch.ops.aten.view.default(sum_dim_int_list_6, [768]);  sum_dim_int_list_6 = None
        t_default_63 = torch.ops.aten.t.default(t_default_62);  t_default_62 = None
        view_default_139 = torch.ops.aten.view.default(mm_default_12, [4, 512, 3072]);  mm_default_12 = None
        to_dtype_3 = torch.ops.aten.to.dtype(view_default_139, torch.float32);  view_default_139 = None
        to_dtype_4 = torch.ops.aten.to.dtype(view_default_93, torch.float32);  view_default_93 = None
        mul_tensor_15 = torch.ops.aten.mul.Tensor(to_dtype_4, 0.7071067811865476)
        erf_default_1 = torch.ops.aten.erf.default(mul_tensor_15);  mul_tensor_15 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(erf_default_1, 1);  erf_default_1 = None
        mul_tensor_16 = torch.ops.aten.mul.Tensor(add_tensor_20, 0.5);  add_tensor_20 = None
        mul_tensor_17 = torch.ops.aten.mul.Tensor(to_dtype_4, to_dtype_4)
        mul_tensor_18 = torch.ops.aten.mul.Tensor(mul_tensor_17, -0.5);  mul_tensor_17 = None
        exp_default_1 = torch.ops.aten.exp.default(mul_tensor_18);  mul_tensor_18 = None
        mul_tensor_19 = torch.ops.aten.mul.Tensor(exp_default_1, 0.3989422804014327);  exp_default_1 = None
        mul_tensor_20 = torch.ops.aten.mul.Tensor(to_dtype_4, mul_tensor_19);  to_dtype_4 = mul_tensor_19 = None
        add_tensor_21 = torch.ops.aten.add.Tensor(mul_tensor_16, mul_tensor_20);  mul_tensor_16 = mul_tensor_20 = None
        mul_tensor_21 = torch.ops.aten.mul.Tensor(to_dtype_3, add_tensor_21);  to_dtype_3 = add_tensor_21 = None
        to_dtype_5 = torch.ops.aten.to.dtype(mul_tensor_21, torch.float32);  mul_tensor_21 = None
        view_default_140 = torch.ops.aten.view.default(to_dtype_5, [2048, 3072]);  to_dtype_5 = None
        t_default_64 = torch.ops.aten.t.default(t_default_28);  t_default_28 = None
        mm_default_14 = torch.ops.aten.mm.default(view_default_140, t_default_64);  t_default_64 = None
        t_default_65 = torch.ops.aten.t.default(view_default_140)
        mm_default_15 = torch.ops.aten.mm.default(t_default_65, view_default_92);  t_default_65 = view_default_92 = None
        t_default_66 = torch.ops.aten.t.default(mm_default_15);  mm_default_15 = None
        sum_dim_int_list_7 = torch.ops.aten.sum.dim_IntList(view_default_140, [0], True);  view_default_140 = None
        view_default_141 = torch.ops.aten.view.default(sum_dim_int_list_7, [3072]);  sum_dim_int_list_7 = None
        t_default_67 = torch.ops.aten.t.default(t_default_66);  t_default_66 = None
        view_default_142 = torch.ops.aten.view.default(mm_default_14, [4, 512, 768]);  mm_default_14 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(getitem_45, view_default_142);  getitem_45 = view_default_142 = None
        native_layer_norm_backward_default_3 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_22, add_tensor_10, [768], getitem_28, getitem_29, primals_78, primals_77, [True, True, True]);  add_tensor_22 = add_tensor_10 = getitem_28 = getitem_29 = primals_78 = primals_77 = None
        getitem_48 = native_layer_norm_backward_default_3[0]
        getitem_49 = native_layer_norm_backward_default_3[1]
        getitem_50 = native_layer_norm_backward_default_3[2];  native_layer_norm_backward_default_3 = None
        view_default_143 = torch.ops.aten.view.default(getitem_48, [2048, 768])
        t_default_68 = torch.ops.aten.t.default(t_default_27);  t_default_27 = None
        mm_default_16 = torch.ops.aten.mm.default(view_default_143, t_default_68);  t_default_68 = None
        t_default_69 = torch.ops.aten.t.default(view_default_143)
        mm_default_17 = torch.ops.aten.mm.default(t_default_69, view_default_90);  t_default_69 = view_default_90 = None
        t_default_70 = torch.ops.aten.t.default(mm_default_17);  mm_default_17 = None
        sum_dim_int_list_8 = torch.ops.aten.sum.dim_IntList(view_default_143, [0], True);  view_default_143 = None
        view_default_144 = torch.ops.aten.view.default(sum_dim_int_list_8, [768]);  sum_dim_int_list_8 = None
        t_default_71 = torch.ops.aten.t.default(t_default_70);  t_default_70 = None
        view_default_145 = torch.ops.aten.view.default(mm_default_16, [4, 512, 768]);  mm_default_16 = None
        view_default_146 = torch.ops.aten.view.default(view_default_145, [4, 512, 12, 64]);  view_default_145 = None
        transpose_int_39 = torch.ops.aten.transpose.int(view_default_146, 1, 2);  view_default_146 = None
        clone_default_28 = torch.ops.aten.clone.default(transpose_int_39, memory_format = torch.contiguous_format);  transpose_int_39 = None
        _unsafe_view_default_10 = torch.ops.aten._unsafe_view.default(clone_default_28, [48, 512, 64]);  clone_default_28 = None
        transpose_int_40 = torch.ops.aten.transpose.int(_softmax_default_4, 1, 2)
        bmm_default_16 = torch.ops.aten.bmm.default(transpose_int_40, _unsafe_view_default_10);  transpose_int_40 = None
        transpose_int_41 = torch.ops.aten.transpose.int(view_default_88, 1, 2);  view_default_88 = None
        bmm_default_17 = torch.ops.aten.bmm.default(_unsafe_view_default_10, transpose_int_41);  _unsafe_view_default_10 = transpose_int_41 = None
        _softmax_backward_data_default_1 = torch.ops.aten._softmax_backward_data.default(bmm_default_17, _softmax_default_4, -1, torch.float32);  bmm_default_17 = _softmax_default_4 = None
        transpose_int_42 = torch.ops.aten.transpose.int(view_default_86, 1, 2);  view_default_86 = None
        bmm_default_18 = torch.ops.aten.bmm.default(transpose_int_42, _softmax_backward_data_default_1);  transpose_int_42 = None
        transpose_int_43 = torch.ops.aten.transpose.int(transpose_int_23, 1, 2);  transpose_int_23 = None
        bmm_default_19 = torch.ops.aten.bmm.default(_softmax_backward_data_default_1, transpose_int_43);  _softmax_backward_data_default_1 = transpose_int_43 = None
        transpose_int_44 = torch.ops.aten.transpose.int(bmm_default_18, 1, 2);  bmm_default_18 = None
        view_default_147 = torch.ops.aten.view.default(bmm_default_16, [4, 12, 512, 64]);  bmm_default_16 = None
        view_default_148 = torch.ops.aten.view.default(transpose_int_44, [4, 12, 512, 64]);  transpose_int_44 = None
        view_default_149 = torch.ops.aten.view.default(bmm_default_19, [4, 12, 512, 64]);  bmm_default_19 = None
        transpose_int_45 = torch.ops.aten.transpose.int(view_default_149, 1, 2);  view_default_149 = None
        clone_default_29 = torch.ops.aten.clone.default(transpose_int_45, memory_format = torch.contiguous_format);  transpose_int_45 = None
        _unsafe_view_default_11 = torch.ops.aten._unsafe_view.default(clone_default_29, [4, 512, 768]);  clone_default_29 = None
        transpose_int_46 = torch.ops.aten.transpose.int(view_default_147, 1, 2);  view_default_147 = None
        clone_default_30 = torch.ops.aten.clone.default(transpose_int_46, memory_format = torch.contiguous_format);  transpose_int_46 = None
        _unsafe_view_default_12 = torch.ops.aten._unsafe_view.default(clone_default_30, [4, 512, 768]);  clone_default_30 = None
        view_default_150 = torch.ops.aten.view.default(_unsafe_view_default_12, [2048, 768]);  _unsafe_view_default_12 = None
        t_default_72 = torch.ops.aten.t.default(t_default_26);  t_default_26 = None
        mm_default_18 = torch.ops.aten.mm.default(view_default_150, t_default_72);  t_default_72 = None
        t_default_73 = torch.ops.aten.t.default(view_default_150)
        mm_default_19 = torch.ops.aten.mm.default(t_default_73, view_default_82);  t_default_73 = view_default_82 = None
        t_default_74 = torch.ops.aten.t.default(mm_default_19);  mm_default_19 = None
        sum_dim_int_list_9 = torch.ops.aten.sum.dim_IntList(view_default_150, [0], True);  view_default_150 = None
        view_default_151 = torch.ops.aten.view.default(sum_dim_int_list_9, [768]);  sum_dim_int_list_9 = None
        t_default_75 = torch.ops.aten.t.default(t_default_74);  t_default_74 = None
        view_default_152 = torch.ops.aten.view.default(mm_default_18, [4, 512, 768]);  mm_default_18 = None
        add_tensor_23 = torch.ops.aten.add.Tensor(getitem_48, view_default_152);  getitem_48 = view_default_152 = None
        transpose_int_47 = torch.ops.aten.transpose.int(view_default_148, 1, 2);  view_default_148 = None
        view_default_153 = torch.ops.aten.view.default(transpose_int_47, [4, 512, 768]);  transpose_int_47 = None
        clone_default_31 = torch.ops.aten.clone.default(view_default_153, memory_format = torch.contiguous_format);  view_default_153 = None
        _unsafe_view_default_13 = torch.ops.aten._unsafe_view.default(clone_default_31, [2048, 768]);  clone_default_31 = None
        t_default_76 = torch.ops.aten.t.default(t_default_25);  t_default_25 = None
        mm_default_20 = torch.ops.aten.mm.default(_unsafe_view_default_13, t_default_76);  t_default_76 = None
        t_default_77 = torch.ops.aten.t.default(_unsafe_view_default_13)
        mm_default_21 = torch.ops.aten.mm.default(t_default_77, view_default_79);  t_default_77 = view_default_79 = None
        t_default_78 = torch.ops.aten.t.default(mm_default_21);  mm_default_21 = None
        sum_dim_int_list_10 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_13, [0], True);  _unsafe_view_default_13 = None
        view_default_154 = torch.ops.aten.view.default(sum_dim_int_list_10, [768]);  sum_dim_int_list_10 = None
        t_default_79 = torch.ops.aten.t.default(t_default_78);  t_default_78 = None
        view_default_155 = torch.ops.aten.view.default(mm_default_20, [4, 512, 768]);  mm_default_20 = None
        add_tensor_24 = torch.ops.aten.add.Tensor(add_tensor_23, view_default_155);  add_tensor_23 = view_default_155 = None
        mul_tensor_22 = torch.ops.aten.mul.Tensor(_unsafe_view_default_11, 0.125);  _unsafe_view_default_11 = None
        view_default_156 = torch.ops.aten.view.default(mul_tensor_22, [2048, 768]);  mul_tensor_22 = None
        t_default_80 = torch.ops.aten.t.default(t_default_24);  t_default_24 = None
        mm_default_22 = torch.ops.aten.mm.default(view_default_156, t_default_80);  t_default_80 = None
        t_default_81 = torch.ops.aten.t.default(view_default_156)
        mm_default_23 = torch.ops.aten.mm.default(t_default_81, view_default_77);  t_default_81 = view_default_77 = None
        t_default_82 = torch.ops.aten.t.default(mm_default_23);  mm_default_23 = None
        sum_dim_int_list_11 = torch.ops.aten.sum.dim_IntList(view_default_156, [0], True);  view_default_156 = None
        view_default_157 = torch.ops.aten.view.default(sum_dim_int_list_11, [768]);  sum_dim_int_list_11 = None
        t_default_83 = torch.ops.aten.t.default(t_default_82);  t_default_82 = None
        view_default_158 = torch.ops.aten.view.default(mm_default_22, [4, 512, 768]);  mm_default_22 = None
        add_tensor_25 = torch.ops.aten.add.Tensor(add_tensor_24, view_default_158);  add_tensor_24 = view_default_158 = None
        native_layer_norm_backward_default_4 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_25, add_tensor_9, [768], getitem_25, getitem_26, primals_58, primals_57, [True, True, True]);  add_tensor_25 = add_tensor_9 = getitem_25 = getitem_26 = primals_58 = primals_57 = None
        getitem_51 = native_layer_norm_backward_default_4[0]
        getitem_52 = native_layer_norm_backward_default_4[1]
        getitem_53 = native_layer_norm_backward_default_4[2];  native_layer_norm_backward_default_4 = None
        view_default_159 = torch.ops.aten.view.default(getitem_51, [2048, 768])
        t_default_84 = torch.ops.aten.t.default(t_default_23);  t_default_23 = None
        mm_default_24 = torch.ops.aten.mm.default(view_default_159, t_default_84);  t_default_84 = None
        t_default_85 = torch.ops.aten.t.default(view_default_159)
        mm_default_25 = torch.ops.aten.mm.default(t_default_85, view_default_75);  t_default_85 = view_default_75 = None
        t_default_86 = torch.ops.aten.t.default(mm_default_25);  mm_default_25 = None
        sum_dim_int_list_12 = torch.ops.aten.sum.dim_IntList(view_default_159, [0], True);  view_default_159 = None
        view_default_160 = torch.ops.aten.view.default(sum_dim_int_list_12, [768]);  sum_dim_int_list_12 = None
        t_default_87 = torch.ops.aten.t.default(t_default_86);  t_default_86 = None
        view_default_161 = torch.ops.aten.view.default(mm_default_24, [4, 512, 3072]);  mm_default_24 = None
        to_dtype_6 = torch.ops.aten.to.dtype(view_default_161, torch.float32);  view_default_161 = None
        to_dtype_7 = torch.ops.aten.to.dtype(view_default_74, torch.float32);  view_default_74 = None
        mul_tensor_23 = torch.ops.aten.mul.Tensor(to_dtype_7, 0.7071067811865476)
        erf_default_2 = torch.ops.aten.erf.default(mul_tensor_23);  mul_tensor_23 = None
        add_tensor_26 = torch.ops.aten.add.Tensor(erf_default_2, 1);  erf_default_2 = None
        mul_tensor_24 = torch.ops.aten.mul.Tensor(add_tensor_26, 0.5);  add_tensor_26 = None
        mul_tensor_25 = torch.ops.aten.mul.Tensor(to_dtype_7, to_dtype_7)
        mul_tensor_26 = torch.ops.aten.mul.Tensor(mul_tensor_25, -0.5);  mul_tensor_25 = None
        exp_default_2 = torch.ops.aten.exp.default(mul_tensor_26);  mul_tensor_26 = None
        mul_tensor_27 = torch.ops.aten.mul.Tensor(exp_default_2, 0.3989422804014327);  exp_default_2 = None
        mul_tensor_28 = torch.ops.aten.mul.Tensor(to_dtype_7, mul_tensor_27);  to_dtype_7 = mul_tensor_27 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(mul_tensor_24, mul_tensor_28);  mul_tensor_24 = mul_tensor_28 = None
        mul_tensor_29 = torch.ops.aten.mul.Tensor(to_dtype_6, add_tensor_27);  to_dtype_6 = add_tensor_27 = None
        to_dtype_8 = torch.ops.aten.to.dtype(mul_tensor_29, torch.float32);  mul_tensor_29 = None
        view_default_162 = torch.ops.aten.view.default(to_dtype_8, [2048, 3072]);  to_dtype_8 = None
        t_default_88 = torch.ops.aten.t.default(t_default_22);  t_default_22 = None
        mm_default_26 = torch.ops.aten.mm.default(view_default_162, t_default_88);  t_default_88 = None
        t_default_89 = torch.ops.aten.t.default(view_default_162)
        mm_default_27 = torch.ops.aten.mm.default(t_default_89, view_default_73);  t_default_89 = view_default_73 = None
        t_default_90 = torch.ops.aten.t.default(mm_default_27);  mm_default_27 = None
        sum_dim_int_list_13 = torch.ops.aten.sum.dim_IntList(view_default_162, [0], True);  view_default_162 = None
        view_default_163 = torch.ops.aten.view.default(sum_dim_int_list_13, [3072]);  sum_dim_int_list_13 = None
        t_default_91 = torch.ops.aten.t.default(t_default_90);  t_default_90 = None
        view_default_164 = torch.ops.aten.view.default(mm_default_26, [4, 512, 768]);  mm_default_26 = None
        add_tensor_28 = torch.ops.aten.add.Tensor(getitem_51, view_default_164);  getitem_51 = view_default_164 = None
        native_layer_norm_backward_default_5 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_28, add_tensor_8, [768], getitem_22, getitem_23, primals_62, primals_61, [True, True, True]);  add_tensor_28 = add_tensor_8 = getitem_22 = getitem_23 = primals_62 = primals_61 = None
        getitem_54 = native_layer_norm_backward_default_5[0]
        getitem_55 = native_layer_norm_backward_default_5[1]
        getitem_56 = native_layer_norm_backward_default_5[2];  native_layer_norm_backward_default_5 = None
        view_default_165 = torch.ops.aten.view.default(getitem_54, [2048, 768])
        t_default_92 = torch.ops.aten.t.default(t_default_21);  t_default_21 = None
        mm_default_28 = torch.ops.aten.mm.default(view_default_165, t_default_92);  t_default_92 = None
        t_default_93 = torch.ops.aten.t.default(view_default_165)
        mm_default_29 = torch.ops.aten.mm.default(t_default_93, view_default_71);  t_default_93 = view_default_71 = None
        t_default_94 = torch.ops.aten.t.default(mm_default_29);  mm_default_29 = None
        sum_dim_int_list_14 = torch.ops.aten.sum.dim_IntList(view_default_165, [0], True);  view_default_165 = None
        view_default_166 = torch.ops.aten.view.default(sum_dim_int_list_14, [768]);  sum_dim_int_list_14 = None
        t_default_95 = torch.ops.aten.t.default(t_default_94);  t_default_94 = None
        view_default_167 = torch.ops.aten.view.default(mm_default_28, [4, 512, 768]);  mm_default_28 = None
        view_default_168 = torch.ops.aten.view.default(view_default_167, [4, 512, 12, 64]);  view_default_167 = None
        transpose_int_48 = torch.ops.aten.transpose.int(view_default_168, 1, 2);  view_default_168 = None
        clone_default_32 = torch.ops.aten.clone.default(transpose_int_48, memory_format = torch.contiguous_format);  transpose_int_48 = None
        _unsafe_view_default_14 = torch.ops.aten._unsafe_view.default(clone_default_32, [48, 512, 64]);  clone_default_32 = None
        transpose_int_49 = torch.ops.aten.transpose.int(_softmax_default_3, 1, 2)
        bmm_default_20 = torch.ops.aten.bmm.default(transpose_int_49, _unsafe_view_default_14);  transpose_int_49 = None
        transpose_int_50 = torch.ops.aten.transpose.int(view_default_69, 1, 2);  view_default_69 = None
        bmm_default_21 = torch.ops.aten.bmm.default(_unsafe_view_default_14, transpose_int_50);  _unsafe_view_default_14 = transpose_int_50 = None
        _softmax_backward_data_default_2 = torch.ops.aten._softmax_backward_data.default(bmm_default_21, _softmax_default_3, -1, torch.float32);  bmm_default_21 = _softmax_default_3 = None
        transpose_int_51 = torch.ops.aten.transpose.int(view_default_67, 1, 2);  view_default_67 = None
        bmm_default_22 = torch.ops.aten.bmm.default(transpose_int_51, _softmax_backward_data_default_2);  transpose_int_51 = None
        transpose_int_52 = torch.ops.aten.transpose.int(transpose_int_18, 1, 2);  transpose_int_18 = None
        bmm_default_23 = torch.ops.aten.bmm.default(_softmax_backward_data_default_2, transpose_int_52);  _softmax_backward_data_default_2 = transpose_int_52 = None
        transpose_int_53 = torch.ops.aten.transpose.int(bmm_default_22, 1, 2);  bmm_default_22 = None
        view_default_169 = torch.ops.aten.view.default(bmm_default_20, [4, 12, 512, 64]);  bmm_default_20 = None
        view_default_170 = torch.ops.aten.view.default(transpose_int_53, [4, 12, 512, 64]);  transpose_int_53 = None
        view_default_171 = torch.ops.aten.view.default(bmm_default_23, [4, 12, 512, 64]);  bmm_default_23 = None
        transpose_int_54 = torch.ops.aten.transpose.int(view_default_171, 1, 2);  view_default_171 = None
        clone_default_33 = torch.ops.aten.clone.default(transpose_int_54, memory_format = torch.contiguous_format);  transpose_int_54 = None
        _unsafe_view_default_15 = torch.ops.aten._unsafe_view.default(clone_default_33, [4, 512, 768]);  clone_default_33 = None
        transpose_int_55 = torch.ops.aten.transpose.int(view_default_169, 1, 2);  view_default_169 = None
        clone_default_34 = torch.ops.aten.clone.default(transpose_int_55, memory_format = torch.contiguous_format);  transpose_int_55 = None
        _unsafe_view_default_16 = torch.ops.aten._unsafe_view.default(clone_default_34, [4, 512, 768]);  clone_default_34 = None
        view_default_172 = torch.ops.aten.view.default(_unsafe_view_default_16, [2048, 768]);  _unsafe_view_default_16 = None
        t_default_96 = torch.ops.aten.t.default(t_default_20);  t_default_20 = None
        mm_default_30 = torch.ops.aten.mm.default(view_default_172, t_default_96);  t_default_96 = None
        t_default_97 = torch.ops.aten.t.default(view_default_172)
        mm_default_31 = torch.ops.aten.mm.default(t_default_97, view_default_63);  t_default_97 = view_default_63 = None
        t_default_98 = torch.ops.aten.t.default(mm_default_31);  mm_default_31 = None
        sum_dim_int_list_15 = torch.ops.aten.sum.dim_IntList(view_default_172, [0], True);  view_default_172 = None
        view_default_173 = torch.ops.aten.view.default(sum_dim_int_list_15, [768]);  sum_dim_int_list_15 = None
        t_default_99 = torch.ops.aten.t.default(t_default_98);  t_default_98 = None
        view_default_174 = torch.ops.aten.view.default(mm_default_30, [4, 512, 768]);  mm_default_30 = None
        add_tensor_29 = torch.ops.aten.add.Tensor(getitem_54, view_default_174);  getitem_54 = view_default_174 = None
        transpose_int_56 = torch.ops.aten.transpose.int(view_default_170, 1, 2);  view_default_170 = None
        view_default_175 = torch.ops.aten.view.default(transpose_int_56, [4, 512, 768]);  transpose_int_56 = None
        clone_default_35 = torch.ops.aten.clone.default(view_default_175, memory_format = torch.contiguous_format);  view_default_175 = None
        _unsafe_view_default_17 = torch.ops.aten._unsafe_view.default(clone_default_35, [2048, 768]);  clone_default_35 = None
        t_default_100 = torch.ops.aten.t.default(t_default_19);  t_default_19 = None
        mm_default_32 = torch.ops.aten.mm.default(_unsafe_view_default_17, t_default_100);  t_default_100 = None
        t_default_101 = torch.ops.aten.t.default(_unsafe_view_default_17)
        mm_default_33 = torch.ops.aten.mm.default(t_default_101, view_default_60);  t_default_101 = view_default_60 = None
        t_default_102 = torch.ops.aten.t.default(mm_default_33);  mm_default_33 = None
        sum_dim_int_list_16 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_17, [0], True);  _unsafe_view_default_17 = None
        view_default_176 = torch.ops.aten.view.default(sum_dim_int_list_16, [768]);  sum_dim_int_list_16 = None
        t_default_103 = torch.ops.aten.t.default(t_default_102);  t_default_102 = None
        view_default_177 = torch.ops.aten.view.default(mm_default_32, [4, 512, 768]);  mm_default_32 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(add_tensor_29, view_default_177);  add_tensor_29 = view_default_177 = None
        mul_tensor_30 = torch.ops.aten.mul.Tensor(_unsafe_view_default_15, 0.125);  _unsafe_view_default_15 = None
        view_default_178 = torch.ops.aten.view.default(mul_tensor_30, [2048, 768]);  mul_tensor_30 = None
        t_default_104 = torch.ops.aten.t.default(t_default_18);  t_default_18 = None
        mm_default_34 = torch.ops.aten.mm.default(view_default_178, t_default_104);  t_default_104 = None
        t_default_105 = torch.ops.aten.t.default(view_default_178)
        mm_default_35 = torch.ops.aten.mm.default(t_default_105, view_default_58);  t_default_105 = view_default_58 = None
        t_default_106 = torch.ops.aten.t.default(mm_default_35);  mm_default_35 = None
        sum_dim_int_list_17 = torch.ops.aten.sum.dim_IntList(view_default_178, [0], True);  view_default_178 = None
        view_default_179 = torch.ops.aten.view.default(sum_dim_int_list_17, [768]);  sum_dim_int_list_17 = None
        t_default_107 = torch.ops.aten.t.default(t_default_106);  t_default_106 = None
        view_default_180 = torch.ops.aten.view.default(mm_default_34, [4, 512, 768]);  mm_default_34 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(add_tensor_30, view_default_180);  add_tensor_30 = view_default_180 = None
        native_layer_norm_backward_default_6 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_31, add_tensor_7, [768], getitem_19, getitem_20, primals_42, primals_41, [True, True, True]);  add_tensor_31 = add_tensor_7 = getitem_19 = getitem_20 = primals_42 = primals_41 = None
        getitem_57 = native_layer_norm_backward_default_6[0]
        getitem_58 = native_layer_norm_backward_default_6[1]
        getitem_59 = native_layer_norm_backward_default_6[2];  native_layer_norm_backward_default_6 = None
        view_default_181 = torch.ops.aten.view.default(getitem_57, [2048, 768])
        t_default_108 = torch.ops.aten.t.default(t_default_17);  t_default_17 = None
        mm_default_36 = torch.ops.aten.mm.default(view_default_181, t_default_108);  t_default_108 = None
        t_default_109 = torch.ops.aten.t.default(view_default_181)
        mm_default_37 = torch.ops.aten.mm.default(t_default_109, view_default_56);  t_default_109 = view_default_56 = None
        t_default_110 = torch.ops.aten.t.default(mm_default_37);  mm_default_37 = None
        sum_dim_int_list_18 = torch.ops.aten.sum.dim_IntList(view_default_181, [0], True);  view_default_181 = None
        view_default_182 = torch.ops.aten.view.default(sum_dim_int_list_18, [768]);  sum_dim_int_list_18 = None
        t_default_111 = torch.ops.aten.t.default(t_default_110);  t_default_110 = None
        view_default_183 = torch.ops.aten.view.default(mm_default_36, [4, 512, 3072]);  mm_default_36 = None
        to_dtype_9 = torch.ops.aten.to.dtype(view_default_183, torch.float32);  view_default_183 = None
        to_dtype_10 = torch.ops.aten.to.dtype(view_default_55, torch.float32);  view_default_55 = None
        mul_tensor_31 = torch.ops.aten.mul.Tensor(to_dtype_10, 0.7071067811865476)
        erf_default_3 = torch.ops.aten.erf.default(mul_tensor_31);  mul_tensor_31 = None
        add_tensor_32 = torch.ops.aten.add.Tensor(erf_default_3, 1);  erf_default_3 = None
        mul_tensor_32 = torch.ops.aten.mul.Tensor(add_tensor_32, 0.5);  add_tensor_32 = None
        mul_tensor_33 = torch.ops.aten.mul.Tensor(to_dtype_10, to_dtype_10)
        mul_tensor_34 = torch.ops.aten.mul.Tensor(mul_tensor_33, -0.5);  mul_tensor_33 = None
        exp_default_3 = torch.ops.aten.exp.default(mul_tensor_34);  mul_tensor_34 = None
        mul_tensor_35 = torch.ops.aten.mul.Tensor(exp_default_3, 0.3989422804014327);  exp_default_3 = None
        mul_tensor_36 = torch.ops.aten.mul.Tensor(to_dtype_10, mul_tensor_35);  to_dtype_10 = mul_tensor_35 = None
        add_tensor_33 = torch.ops.aten.add.Tensor(mul_tensor_32, mul_tensor_36);  mul_tensor_32 = mul_tensor_36 = None
        mul_tensor_37 = torch.ops.aten.mul.Tensor(to_dtype_9, add_tensor_33);  to_dtype_9 = add_tensor_33 = None
        to_dtype_11 = torch.ops.aten.to.dtype(mul_tensor_37, torch.float32);  mul_tensor_37 = None
        view_default_184 = torch.ops.aten.view.default(to_dtype_11, [2048, 3072]);  to_dtype_11 = None
        t_default_112 = torch.ops.aten.t.default(t_default_16);  t_default_16 = None
        mm_default_38 = torch.ops.aten.mm.default(view_default_184, t_default_112);  t_default_112 = None
        t_default_113 = torch.ops.aten.t.default(view_default_184)
        mm_default_39 = torch.ops.aten.mm.default(t_default_113, view_default_54);  t_default_113 = view_default_54 = None
        t_default_114 = torch.ops.aten.t.default(mm_default_39);  mm_default_39 = None
        sum_dim_int_list_19 = torch.ops.aten.sum.dim_IntList(view_default_184, [0], True);  view_default_184 = None
        view_default_185 = torch.ops.aten.view.default(sum_dim_int_list_19, [3072]);  sum_dim_int_list_19 = None
        t_default_115 = torch.ops.aten.t.default(t_default_114);  t_default_114 = None
        view_default_186 = torch.ops.aten.view.default(mm_default_38, [4, 512, 768]);  mm_default_38 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(getitem_57, view_default_186);  getitem_57 = view_default_186 = None
        native_layer_norm_backward_default_7 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_34, add_tensor_6, [768], getitem_16, getitem_17, primals_46, primals_45, [True, True, True]);  add_tensor_34 = add_tensor_6 = getitem_16 = getitem_17 = primals_46 = primals_45 = None
        getitem_60 = native_layer_norm_backward_default_7[0]
        getitem_61 = native_layer_norm_backward_default_7[1]
        getitem_62 = native_layer_norm_backward_default_7[2];  native_layer_norm_backward_default_7 = None
        view_default_187 = torch.ops.aten.view.default(getitem_60, [2048, 768])
        t_default_116 = torch.ops.aten.t.default(t_default_15);  t_default_15 = None
        mm_default_40 = torch.ops.aten.mm.default(view_default_187, t_default_116);  t_default_116 = None
        t_default_117 = torch.ops.aten.t.default(view_default_187)
        mm_default_41 = torch.ops.aten.mm.default(t_default_117, view_default_52);  t_default_117 = view_default_52 = None
        t_default_118 = torch.ops.aten.t.default(mm_default_41);  mm_default_41 = None
        sum_dim_int_list_20 = torch.ops.aten.sum.dim_IntList(view_default_187, [0], True);  view_default_187 = None
        view_default_188 = torch.ops.aten.view.default(sum_dim_int_list_20, [768]);  sum_dim_int_list_20 = None
        t_default_119 = torch.ops.aten.t.default(t_default_118);  t_default_118 = None
        view_default_189 = torch.ops.aten.view.default(mm_default_40, [4, 512, 768]);  mm_default_40 = None
        view_default_190 = torch.ops.aten.view.default(view_default_189, [4, 512, 12, 64]);  view_default_189 = None
        transpose_int_57 = torch.ops.aten.transpose.int(view_default_190, 1, 2);  view_default_190 = None
        clone_default_36 = torch.ops.aten.clone.default(transpose_int_57, memory_format = torch.contiguous_format);  transpose_int_57 = None
        _unsafe_view_default_18 = torch.ops.aten._unsafe_view.default(clone_default_36, [48, 512, 64]);  clone_default_36 = None
        transpose_int_58 = torch.ops.aten.transpose.int(_softmax_default_2, 1, 2)
        bmm_default_24 = torch.ops.aten.bmm.default(transpose_int_58, _unsafe_view_default_18);  transpose_int_58 = None
        transpose_int_59 = torch.ops.aten.transpose.int(view_default_50, 1, 2);  view_default_50 = None
        bmm_default_25 = torch.ops.aten.bmm.default(_unsafe_view_default_18, transpose_int_59);  _unsafe_view_default_18 = transpose_int_59 = None
        _softmax_backward_data_default_3 = torch.ops.aten._softmax_backward_data.default(bmm_default_25, _softmax_default_2, -1, torch.float32);  bmm_default_25 = _softmax_default_2 = None
        transpose_int_60 = torch.ops.aten.transpose.int(view_default_48, 1, 2);  view_default_48 = None
        bmm_default_26 = torch.ops.aten.bmm.default(transpose_int_60, _softmax_backward_data_default_3);  transpose_int_60 = None
        transpose_int_61 = torch.ops.aten.transpose.int(transpose_int_13, 1, 2);  transpose_int_13 = None
        bmm_default_27 = torch.ops.aten.bmm.default(_softmax_backward_data_default_3, transpose_int_61);  _softmax_backward_data_default_3 = transpose_int_61 = None
        transpose_int_62 = torch.ops.aten.transpose.int(bmm_default_26, 1, 2);  bmm_default_26 = None
        view_default_191 = torch.ops.aten.view.default(bmm_default_24, [4, 12, 512, 64]);  bmm_default_24 = None
        view_default_192 = torch.ops.aten.view.default(transpose_int_62, [4, 12, 512, 64]);  transpose_int_62 = None
        view_default_193 = torch.ops.aten.view.default(bmm_default_27, [4, 12, 512, 64]);  bmm_default_27 = None
        transpose_int_63 = torch.ops.aten.transpose.int(view_default_193, 1, 2);  view_default_193 = None
        clone_default_37 = torch.ops.aten.clone.default(transpose_int_63, memory_format = torch.contiguous_format);  transpose_int_63 = None
        _unsafe_view_default_19 = torch.ops.aten._unsafe_view.default(clone_default_37, [4, 512, 768]);  clone_default_37 = None
        transpose_int_64 = torch.ops.aten.transpose.int(view_default_191, 1, 2);  view_default_191 = None
        clone_default_38 = torch.ops.aten.clone.default(transpose_int_64, memory_format = torch.contiguous_format);  transpose_int_64 = None
        _unsafe_view_default_20 = torch.ops.aten._unsafe_view.default(clone_default_38, [4, 512, 768]);  clone_default_38 = None
        view_default_194 = torch.ops.aten.view.default(_unsafe_view_default_20, [2048, 768]);  _unsafe_view_default_20 = None
        t_default_120 = torch.ops.aten.t.default(t_default_14);  t_default_14 = None
        mm_default_42 = torch.ops.aten.mm.default(view_default_194, t_default_120);  t_default_120 = None
        t_default_121 = torch.ops.aten.t.default(view_default_194)
        mm_default_43 = torch.ops.aten.mm.default(t_default_121, view_default_44);  t_default_121 = view_default_44 = None
        t_default_122 = torch.ops.aten.t.default(mm_default_43);  mm_default_43 = None
        sum_dim_int_list_21 = torch.ops.aten.sum.dim_IntList(view_default_194, [0], True);  view_default_194 = None
        view_default_195 = torch.ops.aten.view.default(sum_dim_int_list_21, [768]);  sum_dim_int_list_21 = None
        t_default_123 = torch.ops.aten.t.default(t_default_122);  t_default_122 = None
        view_default_196 = torch.ops.aten.view.default(mm_default_42, [4, 512, 768]);  mm_default_42 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(getitem_60, view_default_196);  getitem_60 = view_default_196 = None
        transpose_int_65 = torch.ops.aten.transpose.int(view_default_192, 1, 2);  view_default_192 = None
        view_default_197 = torch.ops.aten.view.default(transpose_int_65, [4, 512, 768]);  transpose_int_65 = None
        clone_default_39 = torch.ops.aten.clone.default(view_default_197, memory_format = torch.contiguous_format);  view_default_197 = None
        _unsafe_view_default_21 = torch.ops.aten._unsafe_view.default(clone_default_39, [2048, 768]);  clone_default_39 = None
        t_default_124 = torch.ops.aten.t.default(t_default_13);  t_default_13 = None
        mm_default_44 = torch.ops.aten.mm.default(_unsafe_view_default_21, t_default_124);  t_default_124 = None
        t_default_125 = torch.ops.aten.t.default(_unsafe_view_default_21)
        mm_default_45 = torch.ops.aten.mm.default(t_default_125, view_default_41);  t_default_125 = view_default_41 = None
        t_default_126 = torch.ops.aten.t.default(mm_default_45);  mm_default_45 = None
        sum_dim_int_list_22 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_21, [0], True);  _unsafe_view_default_21 = None
        view_default_198 = torch.ops.aten.view.default(sum_dim_int_list_22, [768]);  sum_dim_int_list_22 = None
        t_default_127 = torch.ops.aten.t.default(t_default_126);  t_default_126 = None
        view_default_199 = torch.ops.aten.view.default(mm_default_44, [4, 512, 768]);  mm_default_44 = None
        add_tensor_36 = torch.ops.aten.add.Tensor(add_tensor_35, view_default_199);  add_tensor_35 = view_default_199 = None
        mul_tensor_38 = torch.ops.aten.mul.Tensor(_unsafe_view_default_19, 0.125);  _unsafe_view_default_19 = None
        view_default_200 = torch.ops.aten.view.default(mul_tensor_38, [2048, 768]);  mul_tensor_38 = None
        t_default_128 = torch.ops.aten.t.default(t_default_12);  t_default_12 = None
        mm_default_46 = torch.ops.aten.mm.default(view_default_200, t_default_128);  t_default_128 = None
        t_default_129 = torch.ops.aten.t.default(view_default_200)
        mm_default_47 = torch.ops.aten.mm.default(t_default_129, view_default_39);  t_default_129 = view_default_39 = None
        t_default_130 = torch.ops.aten.t.default(mm_default_47);  mm_default_47 = None
        sum_dim_int_list_23 = torch.ops.aten.sum.dim_IntList(view_default_200, [0], True);  view_default_200 = None
        view_default_201 = torch.ops.aten.view.default(sum_dim_int_list_23, [768]);  sum_dim_int_list_23 = None
        t_default_131 = torch.ops.aten.t.default(t_default_130);  t_default_130 = None
        view_default_202 = torch.ops.aten.view.default(mm_default_46, [4, 512, 768]);  mm_default_46 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(add_tensor_36, view_default_202);  add_tensor_36 = view_default_202 = None
        native_layer_norm_backward_default_8 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_37, add_tensor_5, [768], getitem_13, getitem_14, primals_26, primals_25, [True, True, True]);  add_tensor_37 = add_tensor_5 = getitem_13 = getitem_14 = primals_26 = primals_25 = None
        getitem_63 = native_layer_norm_backward_default_8[0]
        getitem_64 = native_layer_norm_backward_default_8[1]
        getitem_65 = native_layer_norm_backward_default_8[2];  native_layer_norm_backward_default_8 = None
        view_default_203 = torch.ops.aten.view.default(getitem_63, [2048, 768])
        t_default_132 = torch.ops.aten.t.default(t_default_11);  t_default_11 = None
        mm_default_48 = torch.ops.aten.mm.default(view_default_203, t_default_132);  t_default_132 = None
        t_default_133 = torch.ops.aten.t.default(view_default_203)
        mm_default_49 = torch.ops.aten.mm.default(t_default_133, view_default_37);  t_default_133 = view_default_37 = None
        t_default_134 = torch.ops.aten.t.default(mm_default_49);  mm_default_49 = None
        sum_dim_int_list_24 = torch.ops.aten.sum.dim_IntList(view_default_203, [0], True);  view_default_203 = None
        view_default_204 = torch.ops.aten.view.default(sum_dim_int_list_24, [768]);  sum_dim_int_list_24 = None
        t_default_135 = torch.ops.aten.t.default(t_default_134);  t_default_134 = None
        view_default_205 = torch.ops.aten.view.default(mm_default_48, [4, 512, 3072]);  mm_default_48 = None
        to_dtype_12 = torch.ops.aten.to.dtype(view_default_205, torch.float32);  view_default_205 = None
        to_dtype_13 = torch.ops.aten.to.dtype(view_default_36, torch.float32);  view_default_36 = None
        mul_tensor_39 = torch.ops.aten.mul.Tensor(to_dtype_13, 0.7071067811865476)
        erf_default_4 = torch.ops.aten.erf.default(mul_tensor_39);  mul_tensor_39 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(erf_default_4, 1);  erf_default_4 = None
        mul_tensor_40 = torch.ops.aten.mul.Tensor(add_tensor_38, 0.5);  add_tensor_38 = None
        mul_tensor_41 = torch.ops.aten.mul.Tensor(to_dtype_13, to_dtype_13)
        mul_tensor_42 = torch.ops.aten.mul.Tensor(mul_tensor_41, -0.5);  mul_tensor_41 = None
        exp_default_4 = torch.ops.aten.exp.default(mul_tensor_42);  mul_tensor_42 = None
        mul_tensor_43 = torch.ops.aten.mul.Tensor(exp_default_4, 0.3989422804014327);  exp_default_4 = None
        mul_tensor_44 = torch.ops.aten.mul.Tensor(to_dtype_13, mul_tensor_43);  to_dtype_13 = mul_tensor_43 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(mul_tensor_40, mul_tensor_44);  mul_tensor_40 = mul_tensor_44 = None
        mul_tensor_45 = torch.ops.aten.mul.Tensor(to_dtype_12, add_tensor_39);  to_dtype_12 = add_tensor_39 = None
        to_dtype_14 = torch.ops.aten.to.dtype(mul_tensor_45, torch.float32);  mul_tensor_45 = None
        view_default_206 = torch.ops.aten.view.default(to_dtype_14, [2048, 3072]);  to_dtype_14 = None
        t_default_136 = torch.ops.aten.t.default(t_default_10);  t_default_10 = None
        mm_default_50 = torch.ops.aten.mm.default(view_default_206, t_default_136);  t_default_136 = None
        t_default_137 = torch.ops.aten.t.default(view_default_206)
        mm_default_51 = torch.ops.aten.mm.default(t_default_137, view_default_35);  t_default_137 = view_default_35 = None
        t_default_138 = torch.ops.aten.t.default(mm_default_51);  mm_default_51 = None
        sum_dim_int_list_25 = torch.ops.aten.sum.dim_IntList(view_default_206, [0], True);  view_default_206 = None
        view_default_207 = torch.ops.aten.view.default(sum_dim_int_list_25, [3072]);  sum_dim_int_list_25 = None
        t_default_139 = torch.ops.aten.t.default(t_default_138);  t_default_138 = None
        view_default_208 = torch.ops.aten.view.default(mm_default_50, [4, 512, 768]);  mm_default_50 = None
        add_tensor_40 = torch.ops.aten.add.Tensor(getitem_63, view_default_208);  getitem_63 = view_default_208 = None
        native_layer_norm_backward_default_9 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_40, add_tensor_4, [768], getitem_10, getitem_11, primals_30, primals_29, [True, True, True]);  add_tensor_40 = add_tensor_4 = getitem_10 = getitem_11 = primals_30 = primals_29 = None
        getitem_66 = native_layer_norm_backward_default_9[0]
        getitem_67 = native_layer_norm_backward_default_9[1]
        getitem_68 = native_layer_norm_backward_default_9[2];  native_layer_norm_backward_default_9 = None
        view_default_209 = torch.ops.aten.view.default(getitem_66, [2048, 768])
        t_default_140 = torch.ops.aten.t.default(t_default_9);  t_default_9 = None
        mm_default_52 = torch.ops.aten.mm.default(view_default_209, t_default_140);  t_default_140 = None
        t_default_141 = torch.ops.aten.t.default(view_default_209)
        mm_default_53 = torch.ops.aten.mm.default(t_default_141, view_default_33);  t_default_141 = view_default_33 = None
        t_default_142 = torch.ops.aten.t.default(mm_default_53);  mm_default_53 = None
        sum_dim_int_list_26 = torch.ops.aten.sum.dim_IntList(view_default_209, [0], True);  view_default_209 = None
        view_default_210 = torch.ops.aten.view.default(sum_dim_int_list_26, [768]);  sum_dim_int_list_26 = None
        t_default_143 = torch.ops.aten.t.default(t_default_142);  t_default_142 = None
        view_default_211 = torch.ops.aten.view.default(mm_default_52, [4, 512, 768]);  mm_default_52 = None
        view_default_212 = torch.ops.aten.view.default(view_default_211, [4, 512, 12, 64]);  view_default_211 = None
        transpose_int_66 = torch.ops.aten.transpose.int(view_default_212, 1, 2);  view_default_212 = None
        clone_default_40 = torch.ops.aten.clone.default(transpose_int_66, memory_format = torch.contiguous_format);  transpose_int_66 = None
        _unsafe_view_default_22 = torch.ops.aten._unsafe_view.default(clone_default_40, [48, 512, 64]);  clone_default_40 = None
        transpose_int_67 = torch.ops.aten.transpose.int(_softmax_default_1, 1, 2)
        bmm_default_28 = torch.ops.aten.bmm.default(transpose_int_67, _unsafe_view_default_22);  transpose_int_67 = None
        transpose_int_68 = torch.ops.aten.transpose.int(view_default_31, 1, 2);  view_default_31 = None
        bmm_default_29 = torch.ops.aten.bmm.default(_unsafe_view_default_22, transpose_int_68);  _unsafe_view_default_22 = transpose_int_68 = None
        _softmax_backward_data_default_4 = torch.ops.aten._softmax_backward_data.default(bmm_default_29, _softmax_default_1, -1, torch.float32);  bmm_default_29 = _softmax_default_1 = None
        transpose_int_69 = torch.ops.aten.transpose.int(view_default_29, 1, 2);  view_default_29 = None
        bmm_default_30 = torch.ops.aten.bmm.default(transpose_int_69, _softmax_backward_data_default_4);  transpose_int_69 = None
        transpose_int_70 = torch.ops.aten.transpose.int(transpose_int_8, 1, 2);  transpose_int_8 = None
        bmm_default_31 = torch.ops.aten.bmm.default(_softmax_backward_data_default_4, transpose_int_70);  _softmax_backward_data_default_4 = transpose_int_70 = None
        transpose_int_71 = torch.ops.aten.transpose.int(bmm_default_30, 1, 2);  bmm_default_30 = None
        view_default_213 = torch.ops.aten.view.default(bmm_default_28, [4, 12, 512, 64]);  bmm_default_28 = None
        view_default_214 = torch.ops.aten.view.default(transpose_int_71, [4, 12, 512, 64]);  transpose_int_71 = None
        view_default_215 = torch.ops.aten.view.default(bmm_default_31, [4, 12, 512, 64]);  bmm_default_31 = None
        transpose_int_72 = torch.ops.aten.transpose.int(view_default_215, 1, 2);  view_default_215 = None
        clone_default_41 = torch.ops.aten.clone.default(transpose_int_72, memory_format = torch.contiguous_format);  transpose_int_72 = None
        _unsafe_view_default_23 = torch.ops.aten._unsafe_view.default(clone_default_41, [4, 512, 768]);  clone_default_41 = None
        transpose_int_73 = torch.ops.aten.transpose.int(view_default_213, 1, 2);  view_default_213 = None
        clone_default_42 = torch.ops.aten.clone.default(transpose_int_73, memory_format = torch.contiguous_format);  transpose_int_73 = None
        _unsafe_view_default_24 = torch.ops.aten._unsafe_view.default(clone_default_42, [4, 512, 768]);  clone_default_42 = None
        view_default_216 = torch.ops.aten.view.default(_unsafe_view_default_24, [2048, 768]);  _unsafe_view_default_24 = None
        t_default_144 = torch.ops.aten.t.default(t_default_8);  t_default_8 = None
        mm_default_54 = torch.ops.aten.mm.default(view_default_216, t_default_144);  t_default_144 = None
        t_default_145 = torch.ops.aten.t.default(view_default_216)
        mm_default_55 = torch.ops.aten.mm.default(t_default_145, view_default_25);  t_default_145 = view_default_25 = None
        t_default_146 = torch.ops.aten.t.default(mm_default_55);  mm_default_55 = None
        sum_dim_int_list_27 = torch.ops.aten.sum.dim_IntList(view_default_216, [0], True);  view_default_216 = None
        view_default_217 = torch.ops.aten.view.default(sum_dim_int_list_27, [768]);  sum_dim_int_list_27 = None
        t_default_147 = torch.ops.aten.t.default(t_default_146);  t_default_146 = None
        view_default_218 = torch.ops.aten.view.default(mm_default_54, [4, 512, 768]);  mm_default_54 = None
        add_tensor_41 = torch.ops.aten.add.Tensor(getitem_66, view_default_218);  getitem_66 = view_default_218 = None
        transpose_int_74 = torch.ops.aten.transpose.int(view_default_214, 1, 2);  view_default_214 = None
        view_default_219 = torch.ops.aten.view.default(transpose_int_74, [4, 512, 768]);  transpose_int_74 = None
        clone_default_43 = torch.ops.aten.clone.default(view_default_219, memory_format = torch.contiguous_format);  view_default_219 = None
        _unsafe_view_default_25 = torch.ops.aten._unsafe_view.default(clone_default_43, [2048, 768]);  clone_default_43 = None
        t_default_148 = torch.ops.aten.t.default(t_default_7);  t_default_7 = None
        mm_default_56 = torch.ops.aten.mm.default(_unsafe_view_default_25, t_default_148);  t_default_148 = None
        t_default_149 = torch.ops.aten.t.default(_unsafe_view_default_25)
        mm_default_57 = torch.ops.aten.mm.default(t_default_149, view_default_22);  t_default_149 = view_default_22 = None
        t_default_150 = torch.ops.aten.t.default(mm_default_57);  mm_default_57 = None
        sum_dim_int_list_28 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_25, [0], True);  _unsafe_view_default_25 = None
        view_default_220 = torch.ops.aten.view.default(sum_dim_int_list_28, [768]);  sum_dim_int_list_28 = None
        t_default_151 = torch.ops.aten.t.default(t_default_150);  t_default_150 = None
        view_default_221 = torch.ops.aten.view.default(mm_default_56, [4, 512, 768]);  mm_default_56 = None
        add_tensor_42 = torch.ops.aten.add.Tensor(add_tensor_41, view_default_221);  add_tensor_41 = view_default_221 = None
        mul_tensor_46 = torch.ops.aten.mul.Tensor(_unsafe_view_default_23, 0.125);  _unsafe_view_default_23 = None
        view_default_222 = torch.ops.aten.view.default(mul_tensor_46, [2048, 768]);  mul_tensor_46 = None
        t_default_152 = torch.ops.aten.t.default(t_default_6);  t_default_6 = None
        mm_default_58 = torch.ops.aten.mm.default(view_default_222, t_default_152);  t_default_152 = None
        t_default_153 = torch.ops.aten.t.default(view_default_222)
        mm_default_59 = torch.ops.aten.mm.default(t_default_153, view_default_20);  t_default_153 = view_default_20 = None
        t_default_154 = torch.ops.aten.t.default(mm_default_59);  mm_default_59 = None
        sum_dim_int_list_29 = torch.ops.aten.sum.dim_IntList(view_default_222, [0], True);  view_default_222 = None
        view_default_223 = torch.ops.aten.view.default(sum_dim_int_list_29, [768]);  sum_dim_int_list_29 = None
        t_default_155 = torch.ops.aten.t.default(t_default_154);  t_default_154 = None
        view_default_224 = torch.ops.aten.view.default(mm_default_58, [4, 512, 768]);  mm_default_58 = None
        add_tensor_43 = torch.ops.aten.add.Tensor(add_tensor_42, view_default_224);  add_tensor_42 = view_default_224 = None
        native_layer_norm_backward_default_10 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_43, add_tensor_3, [768], getitem_7, getitem_8, primals_10, primals_9, [True, True, True]);  add_tensor_43 = add_tensor_3 = getitem_7 = getitem_8 = primals_10 = primals_9 = None
        getitem_69 = native_layer_norm_backward_default_10[0]
        getitem_70 = native_layer_norm_backward_default_10[1]
        getitem_71 = native_layer_norm_backward_default_10[2];  native_layer_norm_backward_default_10 = None
        view_default_225 = torch.ops.aten.view.default(getitem_69, [2048, 768])
        t_default_156 = torch.ops.aten.t.default(t_default_5);  t_default_5 = None
        mm_default_60 = torch.ops.aten.mm.default(view_default_225, t_default_156);  t_default_156 = None
        t_default_157 = torch.ops.aten.t.default(view_default_225)
        mm_default_61 = torch.ops.aten.mm.default(t_default_157, view_default_18);  t_default_157 = view_default_18 = None
        t_default_158 = torch.ops.aten.t.default(mm_default_61);  mm_default_61 = None
        sum_dim_int_list_30 = torch.ops.aten.sum.dim_IntList(view_default_225, [0], True);  view_default_225 = None
        view_default_226 = torch.ops.aten.view.default(sum_dim_int_list_30, [768]);  sum_dim_int_list_30 = None
        t_default_159 = torch.ops.aten.t.default(t_default_158);  t_default_158 = None
        view_default_227 = torch.ops.aten.view.default(mm_default_60, [4, 512, 3072]);  mm_default_60 = None
        to_dtype_15 = torch.ops.aten.to.dtype(view_default_227, torch.float32);  view_default_227 = None
        to_dtype_16 = torch.ops.aten.to.dtype(view_default_17, torch.float32);  view_default_17 = None
        mul_tensor_47 = torch.ops.aten.mul.Tensor(to_dtype_16, 0.7071067811865476)
        erf_default_5 = torch.ops.aten.erf.default(mul_tensor_47);  mul_tensor_47 = None
        add_tensor_44 = torch.ops.aten.add.Tensor(erf_default_5, 1);  erf_default_5 = None
        mul_tensor_48 = torch.ops.aten.mul.Tensor(add_tensor_44, 0.5);  add_tensor_44 = None
        mul_tensor_49 = torch.ops.aten.mul.Tensor(to_dtype_16, to_dtype_16)
        mul_tensor_50 = torch.ops.aten.mul.Tensor(mul_tensor_49, -0.5);  mul_tensor_49 = None
        exp_default_5 = torch.ops.aten.exp.default(mul_tensor_50);  mul_tensor_50 = None
        mul_tensor_51 = torch.ops.aten.mul.Tensor(exp_default_5, 0.3989422804014327);  exp_default_5 = None
        mul_tensor_52 = torch.ops.aten.mul.Tensor(to_dtype_16, mul_tensor_51);  to_dtype_16 = mul_tensor_51 = None
        add_tensor_45 = torch.ops.aten.add.Tensor(mul_tensor_48, mul_tensor_52);  mul_tensor_48 = mul_tensor_52 = None
        mul_tensor_53 = torch.ops.aten.mul.Tensor(to_dtype_15, add_tensor_45);  to_dtype_15 = add_tensor_45 = None
        to_dtype_17 = torch.ops.aten.to.dtype(mul_tensor_53, torch.float32);  mul_tensor_53 = None
        view_default_228 = torch.ops.aten.view.default(to_dtype_17, [2048, 3072]);  to_dtype_17 = None
        t_default_160 = torch.ops.aten.t.default(t_default_4);  t_default_4 = None
        mm_default_62 = torch.ops.aten.mm.default(view_default_228, t_default_160);  t_default_160 = None
        t_default_161 = torch.ops.aten.t.default(view_default_228)
        mm_default_63 = torch.ops.aten.mm.default(t_default_161, view_default_16);  t_default_161 = view_default_16 = None
        t_default_162 = torch.ops.aten.t.default(mm_default_63);  mm_default_63 = None
        sum_dim_int_list_31 = torch.ops.aten.sum.dim_IntList(view_default_228, [0], True);  view_default_228 = None
        view_default_229 = torch.ops.aten.view.default(sum_dim_int_list_31, [3072]);  sum_dim_int_list_31 = None
        t_default_163 = torch.ops.aten.t.default(t_default_162);  t_default_162 = None
        view_default_230 = torch.ops.aten.view.default(mm_default_62, [4, 512, 768]);  mm_default_62 = None
        add_tensor_46 = torch.ops.aten.add.Tensor(getitem_69, view_default_230);  getitem_69 = view_default_230 = None
        native_layer_norm_backward_default_11 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_46, add_tensor_2, [768], getitem_4, getitem_5, primals_14, primals_13, [True, True, True]);  add_tensor_46 = add_tensor_2 = getitem_4 = getitem_5 = primals_14 = primals_13 = None
        getitem_72 = native_layer_norm_backward_default_11[0]
        getitem_73 = native_layer_norm_backward_default_11[1]
        getitem_74 = native_layer_norm_backward_default_11[2];  native_layer_norm_backward_default_11 = None
        view_default_231 = torch.ops.aten.view.default(getitem_72, [2048, 768])
        t_default_164 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        mm_default_64 = torch.ops.aten.mm.default(view_default_231, t_default_164);  t_default_164 = None
        t_default_165 = torch.ops.aten.t.default(view_default_231)
        mm_default_65 = torch.ops.aten.mm.default(t_default_165, view_default_14);  t_default_165 = view_default_14 = None
        t_default_166 = torch.ops.aten.t.default(mm_default_65);  mm_default_65 = None
        sum_dim_int_list_32 = torch.ops.aten.sum.dim_IntList(view_default_231, [0], True);  view_default_231 = None
        view_default_232 = torch.ops.aten.view.default(sum_dim_int_list_32, [768]);  sum_dim_int_list_32 = None
        t_default_167 = torch.ops.aten.t.default(t_default_166);  t_default_166 = None
        view_default_233 = torch.ops.aten.view.default(mm_default_64, [4, 512, 768]);  mm_default_64 = None
        view_default_234 = torch.ops.aten.view.default(view_default_233, [4, 512, 12, 64]);  view_default_233 = None
        transpose_int_75 = torch.ops.aten.transpose.int(view_default_234, 1, 2);  view_default_234 = None
        clone_default_44 = torch.ops.aten.clone.default(transpose_int_75, memory_format = torch.contiguous_format);  transpose_int_75 = None
        _unsafe_view_default_26 = torch.ops.aten._unsafe_view.default(clone_default_44, [48, 512, 64]);  clone_default_44 = None
        transpose_int_76 = torch.ops.aten.transpose.int(_softmax_default, 1, 2)
        bmm_default_32 = torch.ops.aten.bmm.default(transpose_int_76, _unsafe_view_default_26);  transpose_int_76 = None
        transpose_int_77 = torch.ops.aten.transpose.int(view_default_12, 1, 2);  view_default_12 = None
        bmm_default_33 = torch.ops.aten.bmm.default(_unsafe_view_default_26, transpose_int_77);  _unsafe_view_default_26 = transpose_int_77 = None
        _softmax_backward_data_default_5 = torch.ops.aten._softmax_backward_data.default(bmm_default_33, _softmax_default, -1, torch.float32);  bmm_default_33 = _softmax_default = None
        transpose_int_78 = torch.ops.aten.transpose.int(view_default_10, 1, 2);  view_default_10 = None
        bmm_default_34 = torch.ops.aten.bmm.default(transpose_int_78, _softmax_backward_data_default_5);  transpose_int_78 = None
        transpose_int_79 = torch.ops.aten.transpose.int(transpose_int_3, 1, 2);  transpose_int_3 = None
        bmm_default_35 = torch.ops.aten.bmm.default(_softmax_backward_data_default_5, transpose_int_79);  _softmax_backward_data_default_5 = transpose_int_79 = None
        transpose_int_80 = torch.ops.aten.transpose.int(bmm_default_34, 1, 2);  bmm_default_34 = None
        view_default_235 = torch.ops.aten.view.default(bmm_default_32, [4, 12, 512, 64]);  bmm_default_32 = None
        view_default_236 = torch.ops.aten.view.default(transpose_int_80, [4, 12, 512, 64]);  transpose_int_80 = None
        view_default_237 = torch.ops.aten.view.default(bmm_default_35, [4, 12, 512, 64]);  bmm_default_35 = None
        transpose_int_81 = torch.ops.aten.transpose.int(view_default_237, 1, 2);  view_default_237 = None
        clone_default_45 = torch.ops.aten.clone.default(transpose_int_81, memory_format = torch.contiguous_format);  transpose_int_81 = None
        _unsafe_view_default_27 = torch.ops.aten._unsafe_view.default(clone_default_45, [4, 512, 768]);  clone_default_45 = None
        transpose_int_82 = torch.ops.aten.transpose.int(view_default_235, 1, 2);  view_default_235 = None
        clone_default_46 = torch.ops.aten.clone.default(transpose_int_82, memory_format = torch.contiguous_format);  transpose_int_82 = None
        _unsafe_view_default_28 = torch.ops.aten._unsafe_view.default(clone_default_46, [4, 512, 768]);  clone_default_46 = None
        view_default_238 = torch.ops.aten.view.default(_unsafe_view_default_28, [2048, 768]);  _unsafe_view_default_28 = None
        t_default_168 = torch.ops.aten.t.default(t_default_2);  t_default_2 = None
        mm_default_66 = torch.ops.aten.mm.default(view_default_238, t_default_168);  t_default_168 = None
        t_default_169 = torch.ops.aten.t.default(view_default_238)
        mm_default_67 = torch.ops.aten.mm.default(t_default_169, view_default_6);  t_default_169 = view_default_6 = None
        t_default_170 = torch.ops.aten.t.default(mm_default_67);  mm_default_67 = None
        sum_dim_int_list_33 = torch.ops.aten.sum.dim_IntList(view_default_238, [0], True);  view_default_238 = None
        view_default_239 = torch.ops.aten.view.default(sum_dim_int_list_33, [768]);  sum_dim_int_list_33 = None
        t_default_171 = torch.ops.aten.t.default(t_default_170);  t_default_170 = None
        view_default_240 = torch.ops.aten.view.default(mm_default_66, [4, 512, 768]);  mm_default_66 = None
        add_tensor_47 = torch.ops.aten.add.Tensor(getitem_72, view_default_240);  getitem_72 = view_default_240 = None
        transpose_int_83 = torch.ops.aten.transpose.int(view_default_236, 1, 2);  view_default_236 = None
        view_default_241 = torch.ops.aten.view.default(transpose_int_83, [4, 512, 768]);  transpose_int_83 = None
        clone_default_47 = torch.ops.aten.clone.default(view_default_241, memory_format = torch.contiguous_format);  view_default_241 = None
        _unsafe_view_default_29 = torch.ops.aten._unsafe_view.default(clone_default_47, [2048, 768]);  clone_default_47 = None
        t_default_172 = torch.ops.aten.t.default(t_default_1);  t_default_1 = None
        mm_default_68 = torch.ops.aten.mm.default(_unsafe_view_default_29, t_default_172);  t_default_172 = None
        t_default_173 = torch.ops.aten.t.default(_unsafe_view_default_29)
        mm_default_69 = torch.ops.aten.mm.default(t_default_173, view_default_3);  t_default_173 = view_default_3 = None
        t_default_174 = torch.ops.aten.t.default(mm_default_69);  mm_default_69 = None
        sum_dim_int_list_34 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_29, [0], True);  _unsafe_view_default_29 = None
        view_default_242 = torch.ops.aten.view.default(sum_dim_int_list_34, [768]);  sum_dim_int_list_34 = None
        t_default_175 = torch.ops.aten.t.default(t_default_174);  t_default_174 = None
        view_default_243 = torch.ops.aten.view.default(mm_default_68, [4, 512, 768]);  mm_default_68 = None
        add_tensor_48 = torch.ops.aten.add.Tensor(add_tensor_47, view_default_243);  add_tensor_47 = view_default_243 = None
        mul_tensor_54 = torch.ops.aten.mul.Tensor(_unsafe_view_default_27, 0.125);  _unsafe_view_default_27 = None
        view_default_244 = torch.ops.aten.view.default(mul_tensor_54, [2048, 768]);  mul_tensor_54 = None
        t_default_176 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default_70 = torch.ops.aten.mm.default(view_default_244, t_default_176);  t_default_176 = None
        t_default_177 = torch.ops.aten.t.default(view_default_244)
        mm_default_71 = torch.ops.aten.mm.default(t_default_177, view_default_1);  t_default_177 = view_default_1 = None
        t_default_178 = torch.ops.aten.t.default(mm_default_71);  mm_default_71 = None
        sum_dim_int_list_35 = torch.ops.aten.sum.dim_IntList(view_default_244, [0], True);  view_default_244 = None
        view_default_245 = torch.ops.aten.view.default(sum_dim_int_list_35, [768]);  sum_dim_int_list_35 = None
        t_default_179 = torch.ops.aten.t.default(t_default_178);  t_default_178 = None
        view_default_246 = torch.ops.aten.view.default(mm_default_70, [4, 512, 768]);  mm_default_70 = None
        add_tensor_49 = torch.ops.aten.add.Tensor(add_tensor_48, view_default_246);  add_tensor_48 = view_default_246 = None
        native_layer_norm_backward_default_12 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_49, add_tensor_1, [768], getitem_1, getitem_2, primals_4, primals_3, [True, True, True]);  add_tensor_49 = add_tensor_1 = getitem_1 = getitem_2 = primals_4 = primals_3 = None
        getitem_75 = native_layer_norm_backward_default_12[0]
        getitem_76 = native_layer_norm_backward_default_12[1]
        getitem_77 = native_layer_norm_backward_default_12[2];  native_layer_norm_backward_default_12 = None
        sum_dim_int_list_36 = torch.ops.aten.sum.dim_IntList(getitem_75, [0], True)
        view_default_247 = torch.ops.aten.view.default(sum_dim_int_list_36, [512, 768]);  sum_dim_int_list_36 = None
        embedding_dense_backward_default = torch.ops.aten.embedding_dense_backward.default(view_default_247, add_tensor, 1026, -1, False);  view_default_247 = add_tensor = None
        mul_tensor_55 = torch.ops.aten.mul.Tensor(getitem_75, 1.0);  getitem_75 = None
        embedding_dense_backward_default_1 = torch.ops.aten.embedding_dense_backward.default(mul_tensor_55, view_default, 50265, 1, False);  mul_tensor_55 = view_default = None
        return [embedding_dense_backward_default, embedding_dense_backward_default_1, getitem_77, getitem_76, view_default_229, t_default_163, view_default_226, t_default_159, getitem_71, getitem_70, view_default_242, t_default_175, getitem_74, getitem_73, view_default_232, t_default_167, view_default_245, t_default_179, view_default_239, t_default_171, view_default_207, t_default_139, view_default_204, t_default_135, getitem_65, getitem_64, view_default_220, t_default_151, getitem_68, getitem_67, view_default_210, t_default_143, view_default_223, t_default_155, view_default_217, t_default_147, view_default_185, t_default_115, view_default_182, t_default_111, getitem_59, getitem_58, view_default_198, t_default_127, getitem_62, getitem_61, view_default_188, t_default_119, view_default_201, t_default_131, view_default_195, t_default_123, view_default_163, t_default_91, view_default_160, t_default_87, getitem_53, getitem_52, view_default_176, t_default_103, getitem_56, getitem_55, view_default_166, t_default_95, view_default_179, t_default_107, view_default_173, t_default_99, view_default_141, t_default_67, view_default_138, t_default_63, getitem_47, getitem_46, view_default_154, t_default_79, getitem_50, getitem_49, view_default_144, t_default_71, view_default_157, t_default_83, view_default_151, t_default_75, view_default_119, t_default_43, view_default_116, t_default_39, getitem_41, getitem_40, view_default_132, t_default_55, getitem_44, getitem_43, view_default_122, t_default_47, view_default_135, t_default_59, view_default_129, t_default_51, None]
        
