
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/hf_Bart/hf_Bart_forward_1/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162):
        view_default = torch.ops.aten.view.default(primals_161, [-1, 512]);  primals_161 = None
        embedding_default = torch.ops.aten.embedding.default(primals_2, view_default, 1);  primals_2 = None
        mul_tensor = torch.ops.aten.mul.Tensor(embedding_default, 1.0);  embedding_default = None
        full = torch.ops.aten.full.default([512, 512], -inf, layout = torch.strided, device = device(type='cpu'), pin_memory = False)
        arange = torch.ops.aten.arange.default(512, layout = torch.strided, device = device(type='cpu'), pin_memory = False)
        add_tensor = torch.ops.aten.add.Tensor(arange, 1)
        view_default_1 = torch.ops.aten.view.default(add_tensor, [512, 1]);  add_tensor = None
        lt_tensor = torch.ops.aten.lt.Tensor(arange, view_default_1);  arange = view_default_1 = None
        masked_fill__scalar = torch.ops.aten.masked_fill_.Scalar(full, lt_tensor, 0);  full = lt_tensor = None
        unsqueeze_default = torch.ops.aten.unsqueeze.default(masked_fill__scalar, 0);  masked_fill__scalar = None
        unsqueeze_default_1 = torch.ops.aten.unsqueeze.default(unsqueeze_default, 1);  unsqueeze_default = None
        slice_tensor = torch.ops.aten.slice.Tensor(unsqueeze_default_1, 2, 0, 9223372036854775807);  unsqueeze_default_1 = None
        slice_tensor_1 = torch.ops.aten.slice.Tensor(slice_tensor, 3, 0, 9223372036854775807);  slice_tensor = None
        expand_sym_int = torch.ops.aten.expand.SymInt(slice_tensor_1, [4, 1, 512, 512]);  slice_tensor_1 = None
        _to_copy_default = torch.ops.aten._to_copy.default(expand_sym_int, device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided);  expand_sym_int = None
        arange_1 = torch.ops.aten.arange.start_step(0, 512, 1, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        add_tensor_1 = torch.ops.aten.add.Tensor(arange_1, 2);  arange_1 = None
        embedding_default_1 = torch.ops.aten.embedding.default(primals_1, add_tensor_1);  primals_1 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(mul_tensor, embedding_default_1);  mul_tensor = embedding_default_1 = None
        native_layer_norm_default = torch.ops.aten.native_layer_norm.default(add_tensor_2, [768], primals_4, primals_3, 1e-05)
        getitem = native_layer_norm_default[0]
        getitem_1 = native_layer_norm_default[1]
        getitem_2 = native_layer_norm_default[2];  native_layer_norm_default = None
        view_default_2 = torch.ops.aten.view.default(getitem, [2048, 768])
        t_default = torch.ops.aten.t.default(primals_28);  primals_28 = None
        addmm_default = torch.ops.aten.addmm.default(primals_27, view_default_2, t_default);  primals_27 = None
        view_default_3 = torch.ops.aten.view.default(addmm_default, [4, 512, 768]);  addmm_default = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(view_default_3, 0.125);  view_default_3 = None
        view_default_4 = torch.ops.aten.view.default(getitem, [2048, 768])
        t_default_1 = torch.ops.aten.t.default(primals_22);  primals_22 = None
        addmm_default_1 = torch.ops.aten.addmm.default(primals_21, view_default_4, t_default_1);  primals_21 = None
        view_default_5 = torch.ops.aten.view.default(addmm_default_1, [4, 512, 768]);  addmm_default_1 = None
        view_default_6 = torch.ops.aten.view.default(view_default_5, [4, -1, 12, 64]);  view_default_5 = None
        transpose_int = torch.ops.aten.transpose.int(view_default_6, 1, 2);  view_default_6 = None
        clone_default = torch.ops.aten.clone.default(transpose_int, memory_format = torch.contiguous_format);  transpose_int = None
        view_default_7 = torch.ops.aten.view.default(getitem, [2048, 768])
        t_default_2 = torch.ops.aten.t.default(primals_30);  primals_30 = None
        addmm_default_2 = torch.ops.aten.addmm.default(primals_29, view_default_7, t_default_2);  primals_29 = None
        view_default_8 = torch.ops.aten.view.default(addmm_default_2, [4, 512, 768]);  addmm_default_2 = None
        view_default_9 = torch.ops.aten.view.default(view_default_8, [4, -1, 12, 64]);  view_default_8 = None
        transpose_int_1 = torch.ops.aten.transpose.int(view_default_9, 1, 2);  view_default_9 = None
        clone_default_1 = torch.ops.aten.clone.default(transpose_int_1, memory_format = torch.contiguous_format);  transpose_int_1 = None
        view_default_10 = torch.ops.aten.view.default(mul_tensor_1, [4, 512, 12, 64]);  mul_tensor_1 = None
        transpose_int_2 = torch.ops.aten.transpose.int(view_default_10, 1, 2);  view_default_10 = None
        clone_default_2 = torch.ops.aten.clone.default(transpose_int_2, memory_format = torch.contiguous_format);  transpose_int_2 = None
        view_default_11 = torch.ops.aten.view.default(clone_default_2, [48, -1, 64]);  clone_default_2 = None
        view_default_12 = torch.ops.aten.view.default(clone_default, [48, -1, 64])
        view_default_13 = torch.ops.aten.view.default(clone_default_1, [48, -1, 64])
        transpose_int_3 = torch.ops.aten.transpose.int(view_default_12, 1, 2);  view_default_12 = None
        bmm_default = torch.ops.aten.bmm.default(view_default_11, transpose_int_3)
        view_default_14 = torch.ops.aten.view.default(bmm_default, [4, 12, 512, 512]);  bmm_default = None
        add_tensor_3 = torch.ops.aten.add.Tensor(view_default_14, _to_copy_default);  view_default_14 = None
        view_default_15 = torch.ops.aten.view.default(add_tensor_3, [48, 512, 512]);  add_tensor_3 = None
        _softmax_default = torch.ops.aten._softmax.default(view_default_15, -1, False);  view_default_15 = None
        bmm_default_1 = torch.ops.aten.bmm.default(_softmax_default, view_default_13)
        view_default_16 = torch.ops.aten.view.default(bmm_default_1, [4, 12, 512, 64]);  bmm_default_1 = None
        transpose_int_4 = torch.ops.aten.transpose.int(view_default_16, 1, 2);  view_default_16 = None
        clone_default_3 = torch.ops.aten.clone.default(transpose_int_4, memory_format = torch.contiguous_format);  transpose_int_4 = None
        _unsafe_view_default = torch.ops.aten._unsafe_view.default(clone_default_3, [4, 512, 768]);  clone_default_3 = None
        view_default_17 = torch.ops.aten.view.default(_unsafe_view_default, [2048, 768]);  _unsafe_view_default = None
        t_default_3 = torch.ops.aten.t.default(primals_26);  primals_26 = None
        addmm_default_3 = torch.ops.aten.addmm.default(primals_25, view_default_17, t_default_3);  primals_25 = None
        view_default_18 = torch.ops.aten.view.default(addmm_default_3, [4, 512, 768]);  addmm_default_3 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(getitem, view_default_18);  getitem = view_default_18 = None
        native_layer_norm_default_1 = torch.ops.aten.native_layer_norm.default(add_tensor_4, [768], primals_24, primals_23, 1e-05)
        getitem_3 = native_layer_norm_default_1[0]
        getitem_4 = native_layer_norm_default_1[1]
        getitem_5 = native_layer_norm_default_1[2];  native_layer_norm_default_1 = None
        view_default_19 = torch.ops.aten.view.default(getitem_3, [2048, 768])
        t_default_4 = torch.ops.aten.t.default(primals_12);  primals_12 = None
        addmm_default_4 = torch.ops.aten.addmm.default(primals_11, view_default_19, t_default_4);  primals_11 = None
        view_default_20 = torch.ops.aten.view.default(addmm_default_4, [4, 512, 768]);  addmm_default_4 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(view_default_20, 0.125);  view_default_20 = None
        view_default_21 = torch.ops.aten.view.default(primals_162, [2048, 768])
        t_default_5 = torch.ops.aten.t.default(primals_6);  primals_6 = None
        addmm_default_5 = torch.ops.aten.addmm.default(primals_5, view_default_21, t_default_5);  primals_5 = None
        view_default_22 = torch.ops.aten.view.default(addmm_default_5, [4, 512, 768]);  addmm_default_5 = None
        view_default_23 = torch.ops.aten.view.default(view_default_22, [4, -1, 12, 64]);  view_default_22 = None
        transpose_int_5 = torch.ops.aten.transpose.int(view_default_23, 1, 2);  view_default_23 = None
        clone_default_4 = torch.ops.aten.clone.default(transpose_int_5, memory_format = torch.contiguous_format);  transpose_int_5 = None
        view_default_24 = torch.ops.aten.view.default(primals_162, [2048, 768])
        t_default_6 = torch.ops.aten.t.default(primals_14);  primals_14 = None
        addmm_default_6 = torch.ops.aten.addmm.default(primals_13, view_default_24, t_default_6);  primals_13 = None
        view_default_25 = torch.ops.aten.view.default(addmm_default_6, [4, 512, 768]);  addmm_default_6 = None
        view_default_26 = torch.ops.aten.view.default(view_default_25, [4, -1, 12, 64]);  view_default_25 = None
        transpose_int_6 = torch.ops.aten.transpose.int(view_default_26, 1, 2);  view_default_26 = None
        clone_default_5 = torch.ops.aten.clone.default(transpose_int_6, memory_format = torch.contiguous_format);  transpose_int_6 = None
        view_default_27 = torch.ops.aten.view.default(mul_tensor_2, [4, 512, 12, 64]);  mul_tensor_2 = None
        transpose_int_7 = torch.ops.aten.transpose.int(view_default_27, 1, 2);  view_default_27 = None
        clone_default_6 = torch.ops.aten.clone.default(transpose_int_7, memory_format = torch.contiguous_format);  transpose_int_7 = None
        view_default_28 = torch.ops.aten.view.default(clone_default_6, [48, -1, 64]);  clone_default_6 = None
        view_default_29 = torch.ops.aten.view.default(clone_default_4, [48, -1, 64])
        view_default_30 = torch.ops.aten.view.default(clone_default_5, [48, -1, 64])
        transpose_int_8 = torch.ops.aten.transpose.int(view_default_29, 1, 2);  view_default_29 = None
        bmm_default_2 = torch.ops.aten.bmm.default(view_default_28, transpose_int_8)
        _softmax_default_1 = torch.ops.aten._softmax.default(bmm_default_2, -1, False);  bmm_default_2 = None
        bmm_default_3 = torch.ops.aten.bmm.default(_softmax_default_1, view_default_30)
        view_default_31 = torch.ops.aten.view.default(bmm_default_3, [4, 12, 512, 64]);  bmm_default_3 = None
        transpose_int_9 = torch.ops.aten.transpose.int(view_default_31, 1, 2);  view_default_31 = None
        clone_default_7 = torch.ops.aten.clone.default(transpose_int_9, memory_format = torch.contiguous_format);  transpose_int_9 = None
        _unsafe_view_default_1 = torch.ops.aten._unsafe_view.default(clone_default_7, [4, 512, 768]);  clone_default_7 = None
        view_default_32 = torch.ops.aten.view.default(_unsafe_view_default_1, [2048, 768]);  _unsafe_view_default_1 = None
        t_default_7 = torch.ops.aten.t.default(primals_10);  primals_10 = None
        addmm_default_7 = torch.ops.aten.addmm.default(primals_9, view_default_32, t_default_7);  primals_9 = None
        view_default_33 = torch.ops.aten.view.default(addmm_default_7, [4, 512, 768]);  addmm_default_7 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(getitem_3, view_default_33);  getitem_3 = view_default_33 = None
        native_layer_norm_default_2 = torch.ops.aten.native_layer_norm.default(add_tensor_5, [768], primals_8, primals_7, 1e-05)
        getitem_6 = native_layer_norm_default_2[0]
        getitem_7 = native_layer_norm_default_2[1]
        getitem_8 = native_layer_norm_default_2[2];  native_layer_norm_default_2 = None
        view_default_34 = torch.ops.aten.view.default(getitem_6, [2048, 768])
        t_default_8 = torch.ops.aten.t.default(primals_16);  primals_16 = None
        addmm_default_8 = torch.ops.aten.addmm.default(primals_15, view_default_34, t_default_8);  primals_15 = None
        view_default_35 = torch.ops.aten.view.default(addmm_default_8, [4, 512, 3072]);  addmm_default_8 = None
        gelu_default = torch.ops.aten.gelu.default(view_default_35)
        view_default_36 = torch.ops.aten.view.default(gelu_default, [2048, 3072]);  gelu_default = None
        t_default_9 = torch.ops.aten.t.default(primals_18);  primals_18 = None
        addmm_default_9 = torch.ops.aten.addmm.default(primals_17, view_default_36, t_default_9);  primals_17 = None
        view_default_37 = torch.ops.aten.view.default(addmm_default_9, [4, 512, 768]);  addmm_default_9 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(getitem_6, view_default_37);  getitem_6 = view_default_37 = None
        native_layer_norm_default_3 = torch.ops.aten.native_layer_norm.default(add_tensor_6, [768], primals_20, primals_19, 1e-05)
        getitem_9 = native_layer_norm_default_3[0]
        getitem_10 = native_layer_norm_default_3[1]
        getitem_11 = native_layer_norm_default_3[2];  native_layer_norm_default_3 = None
        view_default_38 = torch.ops.aten.view.default(getitem_9, [2048, 768])
        t_default_10 = torch.ops.aten.t.default(primals_54);  primals_54 = None
        addmm_default_10 = torch.ops.aten.addmm.default(primals_53, view_default_38, t_default_10);  primals_53 = None
        view_default_39 = torch.ops.aten.view.default(addmm_default_10, [4, 512, 768]);  addmm_default_10 = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(view_default_39, 0.125);  view_default_39 = None
        view_default_40 = torch.ops.aten.view.default(getitem_9, [2048, 768])
        t_default_11 = torch.ops.aten.t.default(primals_48);  primals_48 = None
        addmm_default_11 = torch.ops.aten.addmm.default(primals_47, view_default_40, t_default_11);  primals_47 = None
        view_default_41 = torch.ops.aten.view.default(addmm_default_11, [4, 512, 768]);  addmm_default_11 = None
        view_default_42 = torch.ops.aten.view.default(view_default_41, [4, -1, 12, 64]);  view_default_41 = None
        transpose_int_10 = torch.ops.aten.transpose.int(view_default_42, 1, 2);  view_default_42 = None
        clone_default_8 = torch.ops.aten.clone.default(transpose_int_10, memory_format = torch.contiguous_format);  transpose_int_10 = None
        view_default_43 = torch.ops.aten.view.default(getitem_9, [2048, 768])
        t_default_12 = torch.ops.aten.t.default(primals_56);  primals_56 = None
        addmm_default_12 = torch.ops.aten.addmm.default(primals_55, view_default_43, t_default_12);  primals_55 = None
        view_default_44 = torch.ops.aten.view.default(addmm_default_12, [4, 512, 768]);  addmm_default_12 = None
        view_default_45 = torch.ops.aten.view.default(view_default_44, [4, -1, 12, 64]);  view_default_44 = None
        transpose_int_11 = torch.ops.aten.transpose.int(view_default_45, 1, 2);  view_default_45 = None
        clone_default_9 = torch.ops.aten.clone.default(transpose_int_11, memory_format = torch.contiguous_format);  transpose_int_11 = None
        view_default_46 = torch.ops.aten.view.default(mul_tensor_3, [4, 512, 12, 64]);  mul_tensor_3 = None
        transpose_int_12 = torch.ops.aten.transpose.int(view_default_46, 1, 2);  view_default_46 = None
        clone_default_10 = torch.ops.aten.clone.default(transpose_int_12, memory_format = torch.contiguous_format);  transpose_int_12 = None
        view_default_47 = torch.ops.aten.view.default(clone_default_10, [48, -1, 64]);  clone_default_10 = None
        view_default_48 = torch.ops.aten.view.default(clone_default_8, [48, -1, 64])
        view_default_49 = torch.ops.aten.view.default(clone_default_9, [48, -1, 64])
        transpose_int_13 = torch.ops.aten.transpose.int(view_default_48, 1, 2);  view_default_48 = None
        bmm_default_4 = torch.ops.aten.bmm.default(view_default_47, transpose_int_13)
        view_default_50 = torch.ops.aten.view.default(bmm_default_4, [4, 12, 512, 512]);  bmm_default_4 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(view_default_50, _to_copy_default);  view_default_50 = None
        view_default_51 = torch.ops.aten.view.default(add_tensor_7, [48, 512, 512]);  add_tensor_7 = None
        _softmax_default_2 = torch.ops.aten._softmax.default(view_default_51, -1, False);  view_default_51 = None
        bmm_default_5 = torch.ops.aten.bmm.default(_softmax_default_2, view_default_49)
        view_default_52 = torch.ops.aten.view.default(bmm_default_5, [4, 12, 512, 64]);  bmm_default_5 = None
        transpose_int_14 = torch.ops.aten.transpose.int(view_default_52, 1, 2);  view_default_52 = None
        clone_default_11 = torch.ops.aten.clone.default(transpose_int_14, memory_format = torch.contiguous_format);  transpose_int_14 = None
        _unsafe_view_default_2 = torch.ops.aten._unsafe_view.default(clone_default_11, [4, 512, 768]);  clone_default_11 = None
        view_default_53 = torch.ops.aten.view.default(_unsafe_view_default_2, [2048, 768]);  _unsafe_view_default_2 = None
        t_default_13 = torch.ops.aten.t.default(primals_52);  primals_52 = None
        addmm_default_13 = torch.ops.aten.addmm.default(primals_51, view_default_53, t_default_13);  primals_51 = None
        view_default_54 = torch.ops.aten.view.default(addmm_default_13, [4, 512, 768]);  addmm_default_13 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(getitem_9, view_default_54);  getitem_9 = view_default_54 = None
        native_layer_norm_default_4 = torch.ops.aten.native_layer_norm.default(add_tensor_8, [768], primals_50, primals_49, 1e-05)
        getitem_12 = native_layer_norm_default_4[0]
        getitem_13 = native_layer_norm_default_4[1]
        getitem_14 = native_layer_norm_default_4[2];  native_layer_norm_default_4 = None
        view_default_55 = torch.ops.aten.view.default(getitem_12, [2048, 768])
        t_default_14 = torch.ops.aten.t.default(primals_38);  primals_38 = None
        addmm_default_14 = torch.ops.aten.addmm.default(primals_37, view_default_55, t_default_14);  primals_37 = None
        view_default_56 = torch.ops.aten.view.default(addmm_default_14, [4, 512, 768]);  addmm_default_14 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(view_default_56, 0.125);  view_default_56 = None
        view_default_57 = torch.ops.aten.view.default(primals_162, [2048, 768])
        t_default_15 = torch.ops.aten.t.default(primals_32);  primals_32 = None
        addmm_default_15 = torch.ops.aten.addmm.default(primals_31, view_default_57, t_default_15);  primals_31 = None
        view_default_58 = torch.ops.aten.view.default(addmm_default_15, [4, 512, 768]);  addmm_default_15 = None
        view_default_59 = torch.ops.aten.view.default(view_default_58, [4, -1, 12, 64]);  view_default_58 = None
        transpose_int_15 = torch.ops.aten.transpose.int(view_default_59, 1, 2);  view_default_59 = None
        clone_default_12 = torch.ops.aten.clone.default(transpose_int_15, memory_format = torch.contiguous_format);  transpose_int_15 = None
        view_default_60 = torch.ops.aten.view.default(primals_162, [2048, 768])
        t_default_16 = torch.ops.aten.t.default(primals_40);  primals_40 = None
        addmm_default_16 = torch.ops.aten.addmm.default(primals_39, view_default_60, t_default_16);  primals_39 = None
        view_default_61 = torch.ops.aten.view.default(addmm_default_16, [4, 512, 768]);  addmm_default_16 = None
        view_default_62 = torch.ops.aten.view.default(view_default_61, [4, -1, 12, 64]);  view_default_61 = None
        transpose_int_16 = torch.ops.aten.transpose.int(view_default_62, 1, 2);  view_default_62 = None
        clone_default_13 = torch.ops.aten.clone.default(transpose_int_16, memory_format = torch.contiguous_format);  transpose_int_16 = None
        view_default_63 = torch.ops.aten.view.default(mul_tensor_4, [4, 512, 12, 64]);  mul_tensor_4 = None
        transpose_int_17 = torch.ops.aten.transpose.int(view_default_63, 1, 2);  view_default_63 = None
        clone_default_14 = torch.ops.aten.clone.default(transpose_int_17, memory_format = torch.contiguous_format);  transpose_int_17 = None
        view_default_64 = torch.ops.aten.view.default(clone_default_14, [48, -1, 64]);  clone_default_14 = None
        view_default_65 = torch.ops.aten.view.default(clone_default_12, [48, -1, 64])
        view_default_66 = torch.ops.aten.view.default(clone_default_13, [48, -1, 64])
        transpose_int_18 = torch.ops.aten.transpose.int(view_default_65, 1, 2);  view_default_65 = None
        bmm_default_6 = torch.ops.aten.bmm.default(view_default_64, transpose_int_18)
        _softmax_default_3 = torch.ops.aten._softmax.default(bmm_default_6, -1, False);  bmm_default_6 = None
        bmm_default_7 = torch.ops.aten.bmm.default(_softmax_default_3, view_default_66)
        view_default_67 = torch.ops.aten.view.default(bmm_default_7, [4, 12, 512, 64]);  bmm_default_7 = None
        transpose_int_19 = torch.ops.aten.transpose.int(view_default_67, 1, 2);  view_default_67 = None
        clone_default_15 = torch.ops.aten.clone.default(transpose_int_19, memory_format = torch.contiguous_format);  transpose_int_19 = None
        _unsafe_view_default_3 = torch.ops.aten._unsafe_view.default(clone_default_15, [4, 512, 768]);  clone_default_15 = None
        view_default_68 = torch.ops.aten.view.default(_unsafe_view_default_3, [2048, 768]);  _unsafe_view_default_3 = None
        t_default_17 = torch.ops.aten.t.default(primals_36);  primals_36 = None
        addmm_default_17 = torch.ops.aten.addmm.default(primals_35, view_default_68, t_default_17);  primals_35 = None
        view_default_69 = torch.ops.aten.view.default(addmm_default_17, [4, 512, 768]);  addmm_default_17 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(getitem_12, view_default_69);  getitem_12 = view_default_69 = None
        native_layer_norm_default_5 = torch.ops.aten.native_layer_norm.default(add_tensor_9, [768], primals_34, primals_33, 1e-05)
        getitem_15 = native_layer_norm_default_5[0]
        getitem_16 = native_layer_norm_default_5[1]
        getitem_17 = native_layer_norm_default_5[2];  native_layer_norm_default_5 = None
        view_default_70 = torch.ops.aten.view.default(getitem_15, [2048, 768])
        t_default_18 = torch.ops.aten.t.default(primals_42);  primals_42 = None
        addmm_default_18 = torch.ops.aten.addmm.default(primals_41, view_default_70, t_default_18);  primals_41 = None
        view_default_71 = torch.ops.aten.view.default(addmm_default_18, [4, 512, 3072]);  addmm_default_18 = None
        gelu_default_1 = torch.ops.aten.gelu.default(view_default_71)
        view_default_72 = torch.ops.aten.view.default(gelu_default_1, [2048, 3072]);  gelu_default_1 = None
        t_default_19 = torch.ops.aten.t.default(primals_44);  primals_44 = None
        addmm_default_19 = torch.ops.aten.addmm.default(primals_43, view_default_72, t_default_19);  primals_43 = None
        view_default_73 = torch.ops.aten.view.default(addmm_default_19, [4, 512, 768]);  addmm_default_19 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(getitem_15, view_default_73);  getitem_15 = view_default_73 = None
        native_layer_norm_default_6 = torch.ops.aten.native_layer_norm.default(add_tensor_10, [768], primals_46, primals_45, 1e-05)
        getitem_18 = native_layer_norm_default_6[0]
        getitem_19 = native_layer_norm_default_6[1]
        getitem_20 = native_layer_norm_default_6[2];  native_layer_norm_default_6 = None
        view_default_74 = torch.ops.aten.view.default(getitem_18, [2048, 768])
        t_default_20 = torch.ops.aten.t.default(primals_80);  primals_80 = None
        addmm_default_20 = torch.ops.aten.addmm.default(primals_79, view_default_74, t_default_20);  primals_79 = None
        view_default_75 = torch.ops.aten.view.default(addmm_default_20, [4, 512, 768]);  addmm_default_20 = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(view_default_75, 0.125);  view_default_75 = None
        view_default_76 = torch.ops.aten.view.default(getitem_18, [2048, 768])
        t_default_21 = torch.ops.aten.t.default(primals_74);  primals_74 = None
        addmm_default_21 = torch.ops.aten.addmm.default(primals_73, view_default_76, t_default_21);  primals_73 = None
        view_default_77 = torch.ops.aten.view.default(addmm_default_21, [4, 512, 768]);  addmm_default_21 = None
        view_default_78 = torch.ops.aten.view.default(view_default_77, [4, -1, 12, 64]);  view_default_77 = None
        transpose_int_20 = torch.ops.aten.transpose.int(view_default_78, 1, 2);  view_default_78 = None
        clone_default_16 = torch.ops.aten.clone.default(transpose_int_20, memory_format = torch.contiguous_format);  transpose_int_20 = None
        view_default_79 = torch.ops.aten.view.default(getitem_18, [2048, 768])
        t_default_22 = torch.ops.aten.t.default(primals_82);  primals_82 = None
        addmm_default_22 = torch.ops.aten.addmm.default(primals_81, view_default_79, t_default_22);  primals_81 = None
        view_default_80 = torch.ops.aten.view.default(addmm_default_22, [4, 512, 768]);  addmm_default_22 = None
        view_default_81 = torch.ops.aten.view.default(view_default_80, [4, -1, 12, 64]);  view_default_80 = None
        transpose_int_21 = torch.ops.aten.transpose.int(view_default_81, 1, 2);  view_default_81 = None
        clone_default_17 = torch.ops.aten.clone.default(transpose_int_21, memory_format = torch.contiguous_format);  transpose_int_21 = None
        view_default_82 = torch.ops.aten.view.default(mul_tensor_5, [4, 512, 12, 64]);  mul_tensor_5 = None
        transpose_int_22 = torch.ops.aten.transpose.int(view_default_82, 1, 2);  view_default_82 = None
        clone_default_18 = torch.ops.aten.clone.default(transpose_int_22, memory_format = torch.contiguous_format);  transpose_int_22 = None
        view_default_83 = torch.ops.aten.view.default(clone_default_18, [48, -1, 64]);  clone_default_18 = None
        view_default_84 = torch.ops.aten.view.default(clone_default_16, [48, -1, 64])
        view_default_85 = torch.ops.aten.view.default(clone_default_17, [48, -1, 64])
        transpose_int_23 = torch.ops.aten.transpose.int(view_default_84, 1, 2);  view_default_84 = None
        bmm_default_8 = torch.ops.aten.bmm.default(view_default_83, transpose_int_23)
        view_default_86 = torch.ops.aten.view.default(bmm_default_8, [4, 12, 512, 512]);  bmm_default_8 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(view_default_86, _to_copy_default);  view_default_86 = None
        view_default_87 = torch.ops.aten.view.default(add_tensor_11, [48, 512, 512]);  add_tensor_11 = None
        _softmax_default_4 = torch.ops.aten._softmax.default(view_default_87, -1, False);  view_default_87 = None
        bmm_default_9 = torch.ops.aten.bmm.default(_softmax_default_4, view_default_85)
        view_default_88 = torch.ops.aten.view.default(bmm_default_9, [4, 12, 512, 64]);  bmm_default_9 = None
        transpose_int_24 = torch.ops.aten.transpose.int(view_default_88, 1, 2);  view_default_88 = None
        clone_default_19 = torch.ops.aten.clone.default(transpose_int_24, memory_format = torch.contiguous_format);  transpose_int_24 = None
        _unsafe_view_default_4 = torch.ops.aten._unsafe_view.default(clone_default_19, [4, 512, 768]);  clone_default_19 = None
        view_default_89 = torch.ops.aten.view.default(_unsafe_view_default_4, [2048, 768]);  _unsafe_view_default_4 = None
        t_default_23 = torch.ops.aten.t.default(primals_78);  primals_78 = None
        addmm_default_23 = torch.ops.aten.addmm.default(primals_77, view_default_89, t_default_23);  primals_77 = None
        view_default_90 = torch.ops.aten.view.default(addmm_default_23, [4, 512, 768]);  addmm_default_23 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(getitem_18, view_default_90);  getitem_18 = view_default_90 = None
        native_layer_norm_default_7 = torch.ops.aten.native_layer_norm.default(add_tensor_12, [768], primals_76, primals_75, 1e-05)
        getitem_21 = native_layer_norm_default_7[0]
        getitem_22 = native_layer_norm_default_7[1]
        getitem_23 = native_layer_norm_default_7[2];  native_layer_norm_default_7 = None
        view_default_91 = torch.ops.aten.view.default(getitem_21, [2048, 768])
        t_default_24 = torch.ops.aten.t.default(primals_64);  primals_64 = None
        addmm_default_24 = torch.ops.aten.addmm.default(primals_63, view_default_91, t_default_24);  primals_63 = None
        view_default_92 = torch.ops.aten.view.default(addmm_default_24, [4, 512, 768]);  addmm_default_24 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(view_default_92, 0.125);  view_default_92 = None
        view_default_93 = torch.ops.aten.view.default(primals_162, [2048, 768])
        t_default_25 = torch.ops.aten.t.default(primals_58);  primals_58 = None
        addmm_default_25 = torch.ops.aten.addmm.default(primals_57, view_default_93, t_default_25);  primals_57 = None
        view_default_94 = torch.ops.aten.view.default(addmm_default_25, [4, 512, 768]);  addmm_default_25 = None
        view_default_95 = torch.ops.aten.view.default(view_default_94, [4, -1, 12, 64]);  view_default_94 = None
        transpose_int_25 = torch.ops.aten.transpose.int(view_default_95, 1, 2);  view_default_95 = None
        clone_default_20 = torch.ops.aten.clone.default(transpose_int_25, memory_format = torch.contiguous_format);  transpose_int_25 = None
        view_default_96 = torch.ops.aten.view.default(primals_162, [2048, 768])
        t_default_26 = torch.ops.aten.t.default(primals_66);  primals_66 = None
        addmm_default_26 = torch.ops.aten.addmm.default(primals_65, view_default_96, t_default_26);  primals_65 = None
        view_default_97 = torch.ops.aten.view.default(addmm_default_26, [4, 512, 768]);  addmm_default_26 = None
        view_default_98 = torch.ops.aten.view.default(view_default_97, [4, -1, 12, 64]);  view_default_97 = None
        transpose_int_26 = torch.ops.aten.transpose.int(view_default_98, 1, 2);  view_default_98 = None
        clone_default_21 = torch.ops.aten.clone.default(transpose_int_26, memory_format = torch.contiguous_format);  transpose_int_26 = None
        view_default_99 = torch.ops.aten.view.default(mul_tensor_6, [4, 512, 12, 64]);  mul_tensor_6 = None
        transpose_int_27 = torch.ops.aten.transpose.int(view_default_99, 1, 2);  view_default_99 = None
        clone_default_22 = torch.ops.aten.clone.default(transpose_int_27, memory_format = torch.contiguous_format);  transpose_int_27 = None
        view_default_100 = torch.ops.aten.view.default(clone_default_22, [48, -1, 64]);  clone_default_22 = None
        view_default_101 = torch.ops.aten.view.default(clone_default_20, [48, -1, 64])
        view_default_102 = torch.ops.aten.view.default(clone_default_21, [48, -1, 64])
        transpose_int_28 = torch.ops.aten.transpose.int(view_default_101, 1, 2);  view_default_101 = None
        bmm_default_10 = torch.ops.aten.bmm.default(view_default_100, transpose_int_28)
        _softmax_default_5 = torch.ops.aten._softmax.default(bmm_default_10, -1, False);  bmm_default_10 = None
        bmm_default_11 = torch.ops.aten.bmm.default(_softmax_default_5, view_default_102)
        view_default_103 = torch.ops.aten.view.default(bmm_default_11, [4, 12, 512, 64]);  bmm_default_11 = None
        transpose_int_29 = torch.ops.aten.transpose.int(view_default_103, 1, 2);  view_default_103 = None
        clone_default_23 = torch.ops.aten.clone.default(transpose_int_29, memory_format = torch.contiguous_format);  transpose_int_29 = None
        _unsafe_view_default_5 = torch.ops.aten._unsafe_view.default(clone_default_23, [4, 512, 768]);  clone_default_23 = None
        view_default_104 = torch.ops.aten.view.default(_unsafe_view_default_5, [2048, 768]);  _unsafe_view_default_5 = None
        t_default_27 = torch.ops.aten.t.default(primals_62);  primals_62 = None
        addmm_default_27 = torch.ops.aten.addmm.default(primals_61, view_default_104, t_default_27);  primals_61 = None
        view_default_105 = torch.ops.aten.view.default(addmm_default_27, [4, 512, 768]);  addmm_default_27 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(getitem_21, view_default_105);  getitem_21 = view_default_105 = None
        native_layer_norm_default_8 = torch.ops.aten.native_layer_norm.default(add_tensor_13, [768], primals_60, primals_59, 1e-05)
        getitem_24 = native_layer_norm_default_8[0]
        getitem_25 = native_layer_norm_default_8[1]
        getitem_26 = native_layer_norm_default_8[2];  native_layer_norm_default_8 = None
        view_default_106 = torch.ops.aten.view.default(getitem_24, [2048, 768])
        t_default_28 = torch.ops.aten.t.default(primals_68);  primals_68 = None
        addmm_default_28 = torch.ops.aten.addmm.default(primals_67, view_default_106, t_default_28);  primals_67 = None
        view_default_107 = torch.ops.aten.view.default(addmm_default_28, [4, 512, 3072]);  addmm_default_28 = None
        gelu_default_2 = torch.ops.aten.gelu.default(view_default_107)
        view_default_108 = torch.ops.aten.view.default(gelu_default_2, [2048, 3072]);  gelu_default_2 = None
        t_default_29 = torch.ops.aten.t.default(primals_70);  primals_70 = None
        addmm_default_29 = torch.ops.aten.addmm.default(primals_69, view_default_108, t_default_29);  primals_69 = None
        view_default_109 = torch.ops.aten.view.default(addmm_default_29, [4, 512, 768]);  addmm_default_29 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(getitem_24, view_default_109);  getitem_24 = view_default_109 = None
        native_layer_norm_default_9 = torch.ops.aten.native_layer_norm.default(add_tensor_14, [768], primals_72, primals_71, 1e-05)
        getitem_27 = native_layer_norm_default_9[0]
        getitem_28 = native_layer_norm_default_9[1]
        getitem_29 = native_layer_norm_default_9[2];  native_layer_norm_default_9 = None
        view_default_110 = torch.ops.aten.view.default(getitem_27, [2048, 768])
        t_default_30 = torch.ops.aten.t.default(primals_106);  primals_106 = None
        addmm_default_30 = torch.ops.aten.addmm.default(primals_105, view_default_110, t_default_30);  primals_105 = None
        view_default_111 = torch.ops.aten.view.default(addmm_default_30, [4, 512, 768]);  addmm_default_30 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(view_default_111, 0.125);  view_default_111 = None
        view_default_112 = torch.ops.aten.view.default(getitem_27, [2048, 768])
        t_default_31 = torch.ops.aten.t.default(primals_100);  primals_100 = None
        addmm_default_31 = torch.ops.aten.addmm.default(primals_99, view_default_112, t_default_31);  primals_99 = None
        view_default_113 = torch.ops.aten.view.default(addmm_default_31, [4, 512, 768]);  addmm_default_31 = None
        view_default_114 = torch.ops.aten.view.default(view_default_113, [4, -1, 12, 64]);  view_default_113 = None
        transpose_int_30 = torch.ops.aten.transpose.int(view_default_114, 1, 2);  view_default_114 = None
        clone_default_24 = torch.ops.aten.clone.default(transpose_int_30, memory_format = torch.contiguous_format);  transpose_int_30 = None
        view_default_115 = torch.ops.aten.view.default(getitem_27, [2048, 768])
        t_default_32 = torch.ops.aten.t.default(primals_108);  primals_108 = None
        addmm_default_32 = torch.ops.aten.addmm.default(primals_107, view_default_115, t_default_32);  primals_107 = None
        view_default_116 = torch.ops.aten.view.default(addmm_default_32, [4, 512, 768]);  addmm_default_32 = None
        view_default_117 = torch.ops.aten.view.default(view_default_116, [4, -1, 12, 64]);  view_default_116 = None
        transpose_int_31 = torch.ops.aten.transpose.int(view_default_117, 1, 2);  view_default_117 = None
        clone_default_25 = torch.ops.aten.clone.default(transpose_int_31, memory_format = torch.contiguous_format);  transpose_int_31 = None
        view_default_118 = torch.ops.aten.view.default(mul_tensor_7, [4, 512, 12, 64]);  mul_tensor_7 = None
        transpose_int_32 = torch.ops.aten.transpose.int(view_default_118, 1, 2);  view_default_118 = None
        clone_default_26 = torch.ops.aten.clone.default(transpose_int_32, memory_format = torch.contiguous_format);  transpose_int_32 = None
        view_default_119 = torch.ops.aten.view.default(clone_default_26, [48, -1, 64]);  clone_default_26 = None
        view_default_120 = torch.ops.aten.view.default(clone_default_24, [48, -1, 64])
        view_default_121 = torch.ops.aten.view.default(clone_default_25, [48, -1, 64])
        transpose_int_33 = torch.ops.aten.transpose.int(view_default_120, 1, 2);  view_default_120 = None
        bmm_default_12 = torch.ops.aten.bmm.default(view_default_119, transpose_int_33)
        view_default_122 = torch.ops.aten.view.default(bmm_default_12, [4, 12, 512, 512]);  bmm_default_12 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(view_default_122, _to_copy_default);  view_default_122 = None
        view_default_123 = torch.ops.aten.view.default(add_tensor_15, [48, 512, 512]);  add_tensor_15 = None
        _softmax_default_6 = torch.ops.aten._softmax.default(view_default_123, -1, False);  view_default_123 = None
        bmm_default_13 = torch.ops.aten.bmm.default(_softmax_default_6, view_default_121)
        view_default_124 = torch.ops.aten.view.default(bmm_default_13, [4, 12, 512, 64]);  bmm_default_13 = None
        transpose_int_34 = torch.ops.aten.transpose.int(view_default_124, 1, 2);  view_default_124 = None
        clone_default_27 = torch.ops.aten.clone.default(transpose_int_34, memory_format = torch.contiguous_format);  transpose_int_34 = None
        _unsafe_view_default_6 = torch.ops.aten._unsafe_view.default(clone_default_27, [4, 512, 768]);  clone_default_27 = None
        view_default_125 = torch.ops.aten.view.default(_unsafe_view_default_6, [2048, 768]);  _unsafe_view_default_6 = None
        t_default_33 = torch.ops.aten.t.default(primals_104);  primals_104 = None
        addmm_default_33 = torch.ops.aten.addmm.default(primals_103, view_default_125, t_default_33);  primals_103 = None
        view_default_126 = torch.ops.aten.view.default(addmm_default_33, [4, 512, 768]);  addmm_default_33 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(getitem_27, view_default_126);  getitem_27 = view_default_126 = None
        native_layer_norm_default_10 = torch.ops.aten.native_layer_norm.default(add_tensor_16, [768], primals_102, primals_101, 1e-05)
        getitem_30 = native_layer_norm_default_10[0]
        getitem_31 = native_layer_norm_default_10[1]
        getitem_32 = native_layer_norm_default_10[2];  native_layer_norm_default_10 = None
        view_default_127 = torch.ops.aten.view.default(getitem_30, [2048, 768])
        t_default_34 = torch.ops.aten.t.default(primals_90);  primals_90 = None
        addmm_default_34 = torch.ops.aten.addmm.default(primals_89, view_default_127, t_default_34);  primals_89 = None
        view_default_128 = torch.ops.aten.view.default(addmm_default_34, [4, 512, 768]);  addmm_default_34 = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(view_default_128, 0.125);  view_default_128 = None
        view_default_129 = torch.ops.aten.view.default(primals_162, [2048, 768])
        t_default_35 = torch.ops.aten.t.default(primals_84);  primals_84 = None
        addmm_default_35 = torch.ops.aten.addmm.default(primals_83, view_default_129, t_default_35);  primals_83 = None
        view_default_130 = torch.ops.aten.view.default(addmm_default_35, [4, 512, 768]);  addmm_default_35 = None
        view_default_131 = torch.ops.aten.view.default(view_default_130, [4, -1, 12, 64]);  view_default_130 = None
        transpose_int_35 = torch.ops.aten.transpose.int(view_default_131, 1, 2);  view_default_131 = None
        clone_default_28 = torch.ops.aten.clone.default(transpose_int_35, memory_format = torch.contiguous_format);  transpose_int_35 = None
        view_default_132 = torch.ops.aten.view.default(primals_162, [2048, 768])
        t_default_36 = torch.ops.aten.t.default(primals_92);  primals_92 = None
        addmm_default_36 = torch.ops.aten.addmm.default(primals_91, view_default_132, t_default_36);  primals_91 = None
        view_default_133 = torch.ops.aten.view.default(addmm_default_36, [4, 512, 768]);  addmm_default_36 = None
        view_default_134 = torch.ops.aten.view.default(view_default_133, [4, -1, 12, 64]);  view_default_133 = None
        transpose_int_36 = torch.ops.aten.transpose.int(view_default_134, 1, 2);  view_default_134 = None
        clone_default_29 = torch.ops.aten.clone.default(transpose_int_36, memory_format = torch.contiguous_format);  transpose_int_36 = None
        view_default_135 = torch.ops.aten.view.default(mul_tensor_8, [4, 512, 12, 64]);  mul_tensor_8 = None
        transpose_int_37 = torch.ops.aten.transpose.int(view_default_135, 1, 2);  view_default_135 = None
        clone_default_30 = torch.ops.aten.clone.default(transpose_int_37, memory_format = torch.contiguous_format);  transpose_int_37 = None
        view_default_136 = torch.ops.aten.view.default(clone_default_30, [48, -1, 64]);  clone_default_30 = None
        view_default_137 = torch.ops.aten.view.default(clone_default_28, [48, -1, 64])
        view_default_138 = torch.ops.aten.view.default(clone_default_29, [48, -1, 64])
        transpose_int_38 = torch.ops.aten.transpose.int(view_default_137, 1, 2);  view_default_137 = None
        bmm_default_14 = torch.ops.aten.bmm.default(view_default_136, transpose_int_38)
        _softmax_default_7 = torch.ops.aten._softmax.default(bmm_default_14, -1, False);  bmm_default_14 = None
        bmm_default_15 = torch.ops.aten.bmm.default(_softmax_default_7, view_default_138)
        view_default_139 = torch.ops.aten.view.default(bmm_default_15, [4, 12, 512, 64]);  bmm_default_15 = None
        transpose_int_39 = torch.ops.aten.transpose.int(view_default_139, 1, 2);  view_default_139 = None
        clone_default_31 = torch.ops.aten.clone.default(transpose_int_39, memory_format = torch.contiguous_format);  transpose_int_39 = None
        _unsafe_view_default_7 = torch.ops.aten._unsafe_view.default(clone_default_31, [4, 512, 768]);  clone_default_31 = None
        view_default_140 = torch.ops.aten.view.default(_unsafe_view_default_7, [2048, 768]);  _unsafe_view_default_7 = None
        t_default_37 = torch.ops.aten.t.default(primals_88);  primals_88 = None
        addmm_default_37 = torch.ops.aten.addmm.default(primals_87, view_default_140, t_default_37);  primals_87 = None
        view_default_141 = torch.ops.aten.view.default(addmm_default_37, [4, 512, 768]);  addmm_default_37 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(getitem_30, view_default_141);  getitem_30 = view_default_141 = None
        native_layer_norm_default_11 = torch.ops.aten.native_layer_norm.default(add_tensor_17, [768], primals_86, primals_85, 1e-05)
        getitem_33 = native_layer_norm_default_11[0]
        getitem_34 = native_layer_norm_default_11[1]
        getitem_35 = native_layer_norm_default_11[2];  native_layer_norm_default_11 = None
        view_default_142 = torch.ops.aten.view.default(getitem_33, [2048, 768])
        t_default_38 = torch.ops.aten.t.default(primals_94);  primals_94 = None
        addmm_default_38 = torch.ops.aten.addmm.default(primals_93, view_default_142, t_default_38);  primals_93 = None
        view_default_143 = torch.ops.aten.view.default(addmm_default_38, [4, 512, 3072]);  addmm_default_38 = None
        gelu_default_3 = torch.ops.aten.gelu.default(view_default_143)
        view_default_144 = torch.ops.aten.view.default(gelu_default_3, [2048, 3072]);  gelu_default_3 = None
        t_default_39 = torch.ops.aten.t.default(primals_96);  primals_96 = None
        addmm_default_39 = torch.ops.aten.addmm.default(primals_95, view_default_144, t_default_39);  primals_95 = None
        view_default_145 = torch.ops.aten.view.default(addmm_default_39, [4, 512, 768]);  addmm_default_39 = None
        add_tensor_18 = torch.ops.aten.add.Tensor(getitem_33, view_default_145);  getitem_33 = view_default_145 = None
        native_layer_norm_default_12 = torch.ops.aten.native_layer_norm.default(add_tensor_18, [768], primals_98, primals_97, 1e-05)
        getitem_36 = native_layer_norm_default_12[0]
        getitem_37 = native_layer_norm_default_12[1]
        getitem_38 = native_layer_norm_default_12[2];  native_layer_norm_default_12 = None
        view_default_146 = torch.ops.aten.view.default(getitem_36, [2048, 768])
        t_default_40 = torch.ops.aten.t.default(primals_132);  primals_132 = None
        addmm_default_40 = torch.ops.aten.addmm.default(primals_131, view_default_146, t_default_40);  primals_131 = None
        view_default_147 = torch.ops.aten.view.default(addmm_default_40, [4, 512, 768]);  addmm_default_40 = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(view_default_147, 0.125);  view_default_147 = None
        view_default_148 = torch.ops.aten.view.default(getitem_36, [2048, 768])
        t_default_41 = torch.ops.aten.t.default(primals_126);  primals_126 = None
        addmm_default_41 = torch.ops.aten.addmm.default(primals_125, view_default_148, t_default_41);  primals_125 = None
        view_default_149 = torch.ops.aten.view.default(addmm_default_41, [4, 512, 768]);  addmm_default_41 = None
        view_default_150 = torch.ops.aten.view.default(view_default_149, [4, -1, 12, 64]);  view_default_149 = None
        transpose_int_40 = torch.ops.aten.transpose.int(view_default_150, 1, 2);  view_default_150 = None
        clone_default_32 = torch.ops.aten.clone.default(transpose_int_40, memory_format = torch.contiguous_format);  transpose_int_40 = None
        view_default_151 = torch.ops.aten.view.default(getitem_36, [2048, 768])
        t_default_42 = torch.ops.aten.t.default(primals_134);  primals_134 = None
        addmm_default_42 = torch.ops.aten.addmm.default(primals_133, view_default_151, t_default_42);  primals_133 = None
        view_default_152 = torch.ops.aten.view.default(addmm_default_42, [4, 512, 768]);  addmm_default_42 = None
        view_default_153 = torch.ops.aten.view.default(view_default_152, [4, -1, 12, 64]);  view_default_152 = None
        transpose_int_41 = torch.ops.aten.transpose.int(view_default_153, 1, 2);  view_default_153 = None
        clone_default_33 = torch.ops.aten.clone.default(transpose_int_41, memory_format = torch.contiguous_format);  transpose_int_41 = None
        view_default_154 = torch.ops.aten.view.default(mul_tensor_9, [4, 512, 12, 64]);  mul_tensor_9 = None
        transpose_int_42 = torch.ops.aten.transpose.int(view_default_154, 1, 2);  view_default_154 = None
        clone_default_34 = torch.ops.aten.clone.default(transpose_int_42, memory_format = torch.contiguous_format);  transpose_int_42 = None
        view_default_155 = torch.ops.aten.view.default(clone_default_34, [48, -1, 64]);  clone_default_34 = None
        view_default_156 = torch.ops.aten.view.default(clone_default_32, [48, -1, 64])
        view_default_157 = torch.ops.aten.view.default(clone_default_33, [48, -1, 64])
        transpose_int_43 = torch.ops.aten.transpose.int(view_default_156, 1, 2);  view_default_156 = None
        bmm_default_16 = torch.ops.aten.bmm.default(view_default_155, transpose_int_43)
        view_default_158 = torch.ops.aten.view.default(bmm_default_16, [4, 12, 512, 512]);  bmm_default_16 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(view_default_158, _to_copy_default);  view_default_158 = None
        view_default_159 = torch.ops.aten.view.default(add_tensor_19, [48, 512, 512]);  add_tensor_19 = None
        _softmax_default_8 = torch.ops.aten._softmax.default(view_default_159, -1, False);  view_default_159 = None
        bmm_default_17 = torch.ops.aten.bmm.default(_softmax_default_8, view_default_157)
        view_default_160 = torch.ops.aten.view.default(bmm_default_17, [4, 12, 512, 64]);  bmm_default_17 = None
        transpose_int_44 = torch.ops.aten.transpose.int(view_default_160, 1, 2);  view_default_160 = None
        clone_default_35 = torch.ops.aten.clone.default(transpose_int_44, memory_format = torch.contiguous_format);  transpose_int_44 = None
        _unsafe_view_default_8 = torch.ops.aten._unsafe_view.default(clone_default_35, [4, 512, 768]);  clone_default_35 = None
        view_default_161 = torch.ops.aten.view.default(_unsafe_view_default_8, [2048, 768]);  _unsafe_view_default_8 = None
        t_default_43 = torch.ops.aten.t.default(primals_130);  primals_130 = None
        addmm_default_43 = torch.ops.aten.addmm.default(primals_129, view_default_161, t_default_43);  primals_129 = None
        view_default_162 = torch.ops.aten.view.default(addmm_default_43, [4, 512, 768]);  addmm_default_43 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(getitem_36, view_default_162);  getitem_36 = view_default_162 = None
        native_layer_norm_default_13 = torch.ops.aten.native_layer_norm.default(add_tensor_20, [768], primals_128, primals_127, 1e-05)
        getitem_39 = native_layer_norm_default_13[0]
        getitem_40 = native_layer_norm_default_13[1]
        getitem_41 = native_layer_norm_default_13[2];  native_layer_norm_default_13 = None
        view_default_163 = torch.ops.aten.view.default(getitem_39, [2048, 768])
        t_default_44 = torch.ops.aten.t.default(primals_116);  primals_116 = None
        addmm_default_44 = torch.ops.aten.addmm.default(primals_115, view_default_163, t_default_44);  primals_115 = None
        view_default_164 = torch.ops.aten.view.default(addmm_default_44, [4, 512, 768]);  addmm_default_44 = None
        mul_tensor_10 = torch.ops.aten.mul.Tensor(view_default_164, 0.125);  view_default_164 = None
        view_default_165 = torch.ops.aten.view.default(primals_162, [2048, 768])
        t_default_45 = torch.ops.aten.t.default(primals_110);  primals_110 = None
        addmm_default_45 = torch.ops.aten.addmm.default(primals_109, view_default_165, t_default_45);  primals_109 = None
        view_default_166 = torch.ops.aten.view.default(addmm_default_45, [4, 512, 768]);  addmm_default_45 = None
        view_default_167 = torch.ops.aten.view.default(view_default_166, [4, -1, 12, 64]);  view_default_166 = None
        transpose_int_45 = torch.ops.aten.transpose.int(view_default_167, 1, 2);  view_default_167 = None
        clone_default_36 = torch.ops.aten.clone.default(transpose_int_45, memory_format = torch.contiguous_format);  transpose_int_45 = None
        view_default_168 = torch.ops.aten.view.default(primals_162, [2048, 768])
        t_default_46 = torch.ops.aten.t.default(primals_118);  primals_118 = None
        addmm_default_46 = torch.ops.aten.addmm.default(primals_117, view_default_168, t_default_46);  primals_117 = None
        view_default_169 = torch.ops.aten.view.default(addmm_default_46, [4, 512, 768]);  addmm_default_46 = None
        view_default_170 = torch.ops.aten.view.default(view_default_169, [4, -1, 12, 64]);  view_default_169 = None
        transpose_int_46 = torch.ops.aten.transpose.int(view_default_170, 1, 2);  view_default_170 = None
        clone_default_37 = torch.ops.aten.clone.default(transpose_int_46, memory_format = torch.contiguous_format);  transpose_int_46 = None
        view_default_171 = torch.ops.aten.view.default(mul_tensor_10, [4, 512, 12, 64]);  mul_tensor_10 = None
        transpose_int_47 = torch.ops.aten.transpose.int(view_default_171, 1, 2);  view_default_171 = None
        clone_default_38 = torch.ops.aten.clone.default(transpose_int_47, memory_format = torch.contiguous_format);  transpose_int_47 = None
        view_default_172 = torch.ops.aten.view.default(clone_default_38, [48, -1, 64]);  clone_default_38 = None
        view_default_173 = torch.ops.aten.view.default(clone_default_36, [48, -1, 64])
        view_default_174 = torch.ops.aten.view.default(clone_default_37, [48, -1, 64])
        transpose_int_48 = torch.ops.aten.transpose.int(view_default_173, 1, 2);  view_default_173 = None
        bmm_default_18 = torch.ops.aten.bmm.default(view_default_172, transpose_int_48)
        _softmax_default_9 = torch.ops.aten._softmax.default(bmm_default_18, -1, False);  bmm_default_18 = None
        bmm_default_19 = torch.ops.aten.bmm.default(_softmax_default_9, view_default_174)
        view_default_175 = torch.ops.aten.view.default(bmm_default_19, [4, 12, 512, 64]);  bmm_default_19 = None
        transpose_int_49 = torch.ops.aten.transpose.int(view_default_175, 1, 2);  view_default_175 = None
        clone_default_39 = torch.ops.aten.clone.default(transpose_int_49, memory_format = torch.contiguous_format);  transpose_int_49 = None
        _unsafe_view_default_9 = torch.ops.aten._unsafe_view.default(clone_default_39, [4, 512, 768]);  clone_default_39 = None
        view_default_176 = torch.ops.aten.view.default(_unsafe_view_default_9, [2048, 768]);  _unsafe_view_default_9 = None
        t_default_47 = torch.ops.aten.t.default(primals_114);  primals_114 = None
        addmm_default_47 = torch.ops.aten.addmm.default(primals_113, view_default_176, t_default_47);  primals_113 = None
        view_default_177 = torch.ops.aten.view.default(addmm_default_47, [4, 512, 768]);  addmm_default_47 = None
        add_tensor_21 = torch.ops.aten.add.Tensor(getitem_39, view_default_177);  getitem_39 = view_default_177 = None
        native_layer_norm_default_14 = torch.ops.aten.native_layer_norm.default(add_tensor_21, [768], primals_112, primals_111, 1e-05)
        getitem_42 = native_layer_norm_default_14[0]
        getitem_43 = native_layer_norm_default_14[1]
        getitem_44 = native_layer_norm_default_14[2];  native_layer_norm_default_14 = None
        view_default_178 = torch.ops.aten.view.default(getitem_42, [2048, 768])
        t_default_48 = torch.ops.aten.t.default(primals_120);  primals_120 = None
        addmm_default_48 = torch.ops.aten.addmm.default(primals_119, view_default_178, t_default_48);  primals_119 = None
        view_default_179 = torch.ops.aten.view.default(addmm_default_48, [4, 512, 3072]);  addmm_default_48 = None
        gelu_default_4 = torch.ops.aten.gelu.default(view_default_179)
        view_default_180 = torch.ops.aten.view.default(gelu_default_4, [2048, 3072]);  gelu_default_4 = None
        t_default_49 = torch.ops.aten.t.default(primals_122);  primals_122 = None
        addmm_default_49 = torch.ops.aten.addmm.default(primals_121, view_default_180, t_default_49);  primals_121 = None
        view_default_181 = torch.ops.aten.view.default(addmm_default_49, [4, 512, 768]);  addmm_default_49 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(getitem_42, view_default_181);  getitem_42 = view_default_181 = None
        native_layer_norm_default_15 = torch.ops.aten.native_layer_norm.default(add_tensor_22, [768], primals_124, primals_123, 1e-05)
        getitem_45 = native_layer_norm_default_15[0]
        getitem_46 = native_layer_norm_default_15[1]
        getitem_47 = native_layer_norm_default_15[2];  native_layer_norm_default_15 = None
        view_default_182 = torch.ops.aten.view.default(getitem_45, [2048, 768])
        t_default_50 = torch.ops.aten.t.default(primals_158);  primals_158 = None
        addmm_default_50 = torch.ops.aten.addmm.default(primals_157, view_default_182, t_default_50);  primals_157 = None
        view_default_183 = torch.ops.aten.view.default(addmm_default_50, [4, 512, 768]);  addmm_default_50 = None
        mul_tensor_11 = torch.ops.aten.mul.Tensor(view_default_183, 0.125);  view_default_183 = None
        view_default_184 = torch.ops.aten.view.default(getitem_45, [2048, 768])
        t_default_51 = torch.ops.aten.t.default(primals_152);  primals_152 = None
        addmm_default_51 = torch.ops.aten.addmm.default(primals_151, view_default_184, t_default_51);  primals_151 = None
        view_default_185 = torch.ops.aten.view.default(addmm_default_51, [4, 512, 768]);  addmm_default_51 = None
        view_default_186 = torch.ops.aten.view.default(view_default_185, [4, -1, 12, 64]);  view_default_185 = None
        transpose_int_50 = torch.ops.aten.transpose.int(view_default_186, 1, 2);  view_default_186 = None
        clone_default_40 = torch.ops.aten.clone.default(transpose_int_50, memory_format = torch.contiguous_format);  transpose_int_50 = None
        view_default_187 = torch.ops.aten.view.default(getitem_45, [2048, 768])
        t_default_52 = torch.ops.aten.t.default(primals_160);  primals_160 = None
        addmm_default_52 = torch.ops.aten.addmm.default(primals_159, view_default_187, t_default_52);  primals_159 = None
        view_default_188 = torch.ops.aten.view.default(addmm_default_52, [4, 512, 768]);  addmm_default_52 = None
        view_default_189 = torch.ops.aten.view.default(view_default_188, [4, -1, 12, 64]);  view_default_188 = None
        transpose_int_51 = torch.ops.aten.transpose.int(view_default_189, 1, 2);  view_default_189 = None
        clone_default_41 = torch.ops.aten.clone.default(transpose_int_51, memory_format = torch.contiguous_format);  transpose_int_51 = None
        view_default_190 = torch.ops.aten.view.default(mul_tensor_11, [4, 512, 12, 64]);  mul_tensor_11 = None
        transpose_int_52 = torch.ops.aten.transpose.int(view_default_190, 1, 2);  view_default_190 = None
        clone_default_42 = torch.ops.aten.clone.default(transpose_int_52, memory_format = torch.contiguous_format);  transpose_int_52 = None
        view_default_191 = torch.ops.aten.view.default(clone_default_42, [48, -1, 64]);  clone_default_42 = None
        view_default_192 = torch.ops.aten.view.default(clone_default_40, [48, -1, 64])
        view_default_193 = torch.ops.aten.view.default(clone_default_41, [48, -1, 64])
        transpose_int_53 = torch.ops.aten.transpose.int(view_default_192, 1, 2);  view_default_192 = None
        bmm_default_20 = torch.ops.aten.bmm.default(view_default_191, transpose_int_53)
        view_default_194 = torch.ops.aten.view.default(bmm_default_20, [4, 12, 512, 512]);  bmm_default_20 = None
        add_tensor_23 = torch.ops.aten.add.Tensor(view_default_194, _to_copy_default);  view_default_194 = _to_copy_default = None
        view_default_195 = torch.ops.aten.view.default(add_tensor_23, [48, 512, 512]);  add_tensor_23 = None
        _softmax_default_10 = torch.ops.aten._softmax.default(view_default_195, -1, False);  view_default_195 = None
        bmm_default_21 = torch.ops.aten.bmm.default(_softmax_default_10, view_default_193)
        view_default_196 = torch.ops.aten.view.default(bmm_default_21, [4, 12, 512, 64]);  bmm_default_21 = None
        transpose_int_54 = torch.ops.aten.transpose.int(view_default_196, 1, 2);  view_default_196 = None
        clone_default_43 = torch.ops.aten.clone.default(transpose_int_54, memory_format = torch.contiguous_format);  transpose_int_54 = None
        _unsafe_view_default_10 = torch.ops.aten._unsafe_view.default(clone_default_43, [4, 512, 768]);  clone_default_43 = None
        view_default_197 = torch.ops.aten.view.default(_unsafe_view_default_10, [2048, 768]);  _unsafe_view_default_10 = None
        t_default_53 = torch.ops.aten.t.default(primals_156);  primals_156 = None
        addmm_default_53 = torch.ops.aten.addmm.default(primals_155, view_default_197, t_default_53);  primals_155 = None
        view_default_198 = torch.ops.aten.view.default(addmm_default_53, [4, 512, 768]);  addmm_default_53 = None
        add_tensor_24 = torch.ops.aten.add.Tensor(getitem_45, view_default_198);  getitem_45 = view_default_198 = None
        native_layer_norm_default_16 = torch.ops.aten.native_layer_norm.default(add_tensor_24, [768], primals_154, primals_153, 1e-05)
        getitem_48 = native_layer_norm_default_16[0]
        getitem_49 = native_layer_norm_default_16[1]
        getitem_50 = native_layer_norm_default_16[2];  native_layer_norm_default_16 = None
        view_default_199 = torch.ops.aten.view.default(getitem_48, [2048, 768])
        t_default_54 = torch.ops.aten.t.default(primals_142);  primals_142 = None
        addmm_default_54 = torch.ops.aten.addmm.default(primals_141, view_default_199, t_default_54);  primals_141 = None
        view_default_200 = torch.ops.aten.view.default(addmm_default_54, [4, 512, 768]);  addmm_default_54 = None
        mul_tensor_12 = torch.ops.aten.mul.Tensor(view_default_200, 0.125);  view_default_200 = None
        view_default_201 = torch.ops.aten.view.default(primals_162, [2048, 768])
        t_default_55 = torch.ops.aten.t.default(primals_136);  primals_136 = None
        addmm_default_55 = torch.ops.aten.addmm.default(primals_135, view_default_201, t_default_55);  primals_135 = None
        view_default_202 = torch.ops.aten.view.default(addmm_default_55, [4, 512, 768]);  addmm_default_55 = None
        view_default_203 = torch.ops.aten.view.default(view_default_202, [4, -1, 12, 64]);  view_default_202 = None
        transpose_int_55 = torch.ops.aten.transpose.int(view_default_203, 1, 2);  view_default_203 = None
        clone_default_44 = torch.ops.aten.clone.default(transpose_int_55, memory_format = torch.contiguous_format);  transpose_int_55 = None
        view_default_204 = torch.ops.aten.view.default(primals_162, [2048, 768]);  primals_162 = None
        t_default_56 = torch.ops.aten.t.default(primals_144);  primals_144 = None
        addmm_default_56 = torch.ops.aten.addmm.default(primals_143, view_default_204, t_default_56);  primals_143 = None
        view_default_205 = torch.ops.aten.view.default(addmm_default_56, [4, 512, 768]);  addmm_default_56 = None
        view_default_206 = torch.ops.aten.view.default(view_default_205, [4, -1, 12, 64]);  view_default_205 = None
        transpose_int_56 = torch.ops.aten.transpose.int(view_default_206, 1, 2);  view_default_206 = None
        clone_default_45 = torch.ops.aten.clone.default(transpose_int_56, memory_format = torch.contiguous_format);  transpose_int_56 = None
        view_default_207 = torch.ops.aten.view.default(mul_tensor_12, [4, 512, 12, 64]);  mul_tensor_12 = None
        transpose_int_57 = torch.ops.aten.transpose.int(view_default_207, 1, 2);  view_default_207 = None
        clone_default_46 = torch.ops.aten.clone.default(transpose_int_57, memory_format = torch.contiguous_format);  transpose_int_57 = None
        view_default_208 = torch.ops.aten.view.default(clone_default_46, [48, -1, 64]);  clone_default_46 = None
        view_default_209 = torch.ops.aten.view.default(clone_default_44, [48, -1, 64])
        view_default_210 = torch.ops.aten.view.default(clone_default_45, [48, -1, 64])
        transpose_int_58 = torch.ops.aten.transpose.int(view_default_209, 1, 2);  view_default_209 = None
        bmm_default_22 = torch.ops.aten.bmm.default(view_default_208, transpose_int_58)
        _softmax_default_11 = torch.ops.aten._softmax.default(bmm_default_22, -1, False);  bmm_default_22 = None
        bmm_default_23 = torch.ops.aten.bmm.default(_softmax_default_11, view_default_210)
        view_default_211 = torch.ops.aten.view.default(bmm_default_23, [4, 12, 512, 64]);  bmm_default_23 = None
        transpose_int_59 = torch.ops.aten.transpose.int(view_default_211, 1, 2);  view_default_211 = None
        clone_default_47 = torch.ops.aten.clone.default(transpose_int_59, memory_format = torch.contiguous_format);  transpose_int_59 = None
        _unsafe_view_default_11 = torch.ops.aten._unsafe_view.default(clone_default_47, [4, 512, 768]);  clone_default_47 = None
        view_default_212 = torch.ops.aten.view.default(_unsafe_view_default_11, [2048, 768]);  _unsafe_view_default_11 = None
        t_default_57 = torch.ops.aten.t.default(primals_140);  primals_140 = None
        addmm_default_57 = torch.ops.aten.addmm.default(primals_139, view_default_212, t_default_57);  primals_139 = None
        view_default_213 = torch.ops.aten.view.default(addmm_default_57, [4, 512, 768]);  addmm_default_57 = None
        add_tensor_25 = torch.ops.aten.add.Tensor(getitem_48, view_default_213);  getitem_48 = view_default_213 = None
        native_layer_norm_default_17 = torch.ops.aten.native_layer_norm.default(add_tensor_25, [768], primals_138, primals_137, 1e-05)
        getitem_51 = native_layer_norm_default_17[0]
        getitem_52 = native_layer_norm_default_17[1]
        getitem_53 = native_layer_norm_default_17[2];  native_layer_norm_default_17 = None
        view_default_214 = torch.ops.aten.view.default(getitem_51, [2048, 768])
        t_default_58 = torch.ops.aten.t.default(primals_146);  primals_146 = None
        addmm_default_58 = torch.ops.aten.addmm.default(primals_145, view_default_214, t_default_58);  primals_145 = None
        view_default_215 = torch.ops.aten.view.default(addmm_default_58, [4, 512, 3072]);  addmm_default_58 = None
        gelu_default_5 = torch.ops.aten.gelu.default(view_default_215)
        view_default_216 = torch.ops.aten.view.default(gelu_default_5, [2048, 3072]);  gelu_default_5 = None
        t_default_59 = torch.ops.aten.t.default(primals_148);  primals_148 = None
        addmm_default_59 = torch.ops.aten.addmm.default(primals_147, view_default_216, t_default_59);  primals_147 = None
        view_default_217 = torch.ops.aten.view.default(addmm_default_59, [4, 512, 768]);  addmm_default_59 = None
        add_tensor_26 = torch.ops.aten.add.Tensor(getitem_51, view_default_217);  getitem_51 = view_default_217 = None
        native_layer_norm_default_18 = torch.ops.aten.native_layer_norm.default(add_tensor_26, [768], primals_150, primals_149, 1e-05)
        getitem_54 = native_layer_norm_default_18[0]
        getitem_55 = native_layer_norm_default_18[1]
        getitem_56 = native_layer_norm_default_18[2];  native_layer_norm_default_18 = None
        return [getitem_54, clone_default, clone_default_1, clone_default_4, clone_default_5, clone_default_8, clone_default_9, clone_default_12, clone_default_13, clone_default_16, clone_default_17, clone_default_20, clone_default_21, clone_default_24, clone_default_25, clone_default_28, clone_default_29, clone_default_32, clone_default_33, clone_default_36, clone_default_37, clone_default_40, clone_default_41, clone_default_44, clone_default_45, view_default_121, primals_150, primals_23, t_default_32, primals_127, t_default_51, primals_4, view_default_125, primals_154, view_default_191, primals_128, primals_149, _softmax_default_6, view_default_184, t_default_52, transpose_int_33, t_default_50, view_default_187, primals_3, primals_153, view_default_106, add_tensor_26, getitem_56, view_default_216, primals_59, t_default_26, primals_49, primals_60, getitem_55, t_default_59, primals_50, t_default_23, view_default_127, primals_45, view_default_110, getitem_43, add_tensor_14, t_default_30, getitem_13, primals_46, primals_97, getitem_14, t_default_29, _softmax_default_4, view_default_178, primals_98, t_default_31, view_default_176, getitem_29, view_default_174, primals_101, t_default_47, primals_102, t_default_14, view_default_108, _softmax_default_9, add_tensor_12, view_default_89, t_default_15, view_default_55, view_default_57, transpose_int_48, view_default_119, add_tensor_21, getitem_28, view_default_112, _softmax_default_1, add_tensor_5, add_tensor_10, t_default_46, t_default_45, view_default_74, t_default_19, primals_24, primals_111, view_default, getitem_44, view_default_180, t_default_48, add_tensor_22, view_default_32, view_default_71, getitem_19, primals_124, view_default_72, primals_7, t_default_6, getitem_46, view_default_76, primals_33, view_default_168, primals_137, view_default_172, primals_19, primals_34, t_default_20, primals_8, view_default_179, primals_20, view_default_30, view_default_182, primals_112, primals_123, getitem_47, transpose_int_8, primals_138, t_default_21, t_default_7, t_default_49, getitem_20, t_default_39, _softmax_default_3, view_default_143, view_default_107, primals_71, primals_72, view_default_115, getitem_34, t_default_25, primals_75, view_default_208, primals_76, t_default_16, _softmax_default_10, view_default_91, getitem_22, view_default_193, getitem_26, view_default_93, t_default_38, getitem_25, t_default_28, transpose_int_18, view_default_96, view_default_144, view_default_60, add_tensor_18, view_default_66, primals_85, primals_86, view_default_142, getitem_35, getitem_23, view_default_83, t_default_24, t_default_27, view_default_68, view_default_70, _softmax_default_11, transpose_int_58, t_default_58, add_tensor_9, add_tensor_8, t_default_13, view_default_212, view_default_214, t_default_17, t_default_1, t_default_12, view_default_4, getitem_17, view_default_210, t_default_2, t_default_57, transpose_int_13, getitem_53, transpose_int_28, view_default_49, add_tensor_13, view_default_104, view_default_7, view_default_102, view_default_215, getitem_16, _softmax_default_5, _softmax_default_2, view_default_11, t_default_18, view_default_53, getitem_52, add_tensor_25, getitem_7, add_tensor_1, getitem_1, getitem_8, getitem_2, view_default_132, view_default_197, add_tensor_2, transpose_int_38, transpose_int_3, view_default_13, view_default_47, view_default_35, t_default_11, view_default_136, view_default_40, t_default_5, view_default_34, t_default_10, getitem_50, view_default_199, getitem_49, getitem_5, getitem_11, view_default_24, add_tensor_6, t_default_35, t_default_54, view_default_28, add_tensor_4, view_default_36, t_default_4, view_default_138, t_default_37, t_default_9, view_default_19, view_default_140, _softmax_default, t_default_36, view_default_129, t_default, getitem_10, view_default_17, t_default_8, view_default_38, view_default_64, _softmax_default_7, add_tensor_17, view_default_43, getitem_4, t_default_3, t_default_53, add_tensor_24, view_default_21, transpose_int_53, view_default_2, view_default_100, view_default_148, view_default_163, t_default_56, view_default_151, getitem_32, view_default_157, add_tensor_16, view_default_85, transpose_int_43, view_default_204, t_default_33, t_default_40, _softmax_default_8, add_tensor_20, view_default_79, t_default_44, t_default_42, view_default_201, getitem_41, getitem_37, view_default_146, getitem_31, t_default_34, view_default_165, t_default_22, transpose_int_23, t_default_43, t_default_55, getitem_40, t_default_41, view_default_155, view_default_161, getitem_38]
        
