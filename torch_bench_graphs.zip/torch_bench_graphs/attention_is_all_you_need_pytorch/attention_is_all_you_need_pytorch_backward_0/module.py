
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/attention_is_all_you_need_pytorch/attention_is_all_you_need_pytorch_backward_0/state_dict.pt'))

    
    
    def forward(self, primals_183, primals_76, primals_171, primals_77, primals_182, primals_175, primals_176, primals_22, primals_28, primals_23, primals_27, _unsafe_view_default_15, t_default_57, add__tensor_2, _unsafe_view_default_96, t_default_55, _softmax_default_1, t_default_9, getitem_58, _unsafe_view_default_13, _unsafe_view_default_93, getitem_59, t_default_56, view_default_122, _unsafe_view_default_12, view_default_19, _unsafe_view_default_94, eq_scalar_10, view_default_124, _unsafe_view_default_102, t_default_58, primals_170, add__tensor_13, view_default_152, view_default_96, primals_41, eq_scalar_13, view_default_91, add__tensor_14, t_default_69, _softmax_default_7, view_default_98, t_default_42, view_default_95, getitem_71, relu_default_6, t_default_70, primals_158, primals_35, primals_159, getitem_70, primals_40, _unsafe_view_default_69, t_default_43, _unsafe_view_default_120, primals_163, view_default_153, primals_164, t_default_71, view_default_93, primals_34, _unsafe_view_default_49, relu_default, getitem_8, view_default_192, _softmax_default_2, getitem_23, add__tensor_4, getitem_22, t_default_15, view_default_11, add__tensor_10, view_default_71, t_default_22, view_default_194, _unsafe_view_default_21, relu_default_3, view_default_73, view_default_196, add__tensor_27, view_default_50, _unsafe_view_default_157, _unsafe_view_default_51, t_default_89, t_default_5, t_default_23, t_default_33, view_default_32, _unsafe_view_default_22, t_default_24, view_default_34, _softmax_default_5, _unsafe_view_default_24, view_default_35, getitem_25, add__tensor_1, _unsafe_view_default_48, getitem_88, add__tensor_7, getitem_89, getitem_26, t_default_90, getitem_20, _unsafe_view_default_103, getitem_1, t_default, t_default_20, view_default_41, view_default_131, getitem_13, add__tensor_12, primals_123, relu_default_8, t_default_8, eq_scalar_11, t_default_61, _unsafe_view_default_105, view_default, eq_scalar_3, view_default_133, t_default_12, view_default_142, _unsafe_view_default_112, add__tensor_20, view_default_15, getitem_14, t_default_62, view_default_135, primals_122, view_default_17, _softmax_default_11, view_default_39, view_default_137, add__tensor_19, t_default_7, t_default_19, view_default_43, getitem_2, view_default_26, view_default_13, eq_scalar_1, add_tensor, primals_71, primals_147, primals_70, primals_146, primals_89, primals_81, primals_88, primals_63, primals_82, primals_64, view_default_37, t_default_16, t_default_17, getitem_19, getitem_16, add__tensor_5, relu_default_2, getitem_17, t_default_18, getitem_37, getitem_40, add_tensor_1, getitem_38, t_default_36, getitem_41, t_default_37, view_default_80, view_default_78, t_default_76, getitem_74, getitem_73, t_default_74, getitem_76, t_default_75, _unsafe_view_default_130, _unsafe_view_default_129, getitem_77, view_default_166, _softmax_default_15, add__tensor_25, view_default_183, t_default_83, view_default_181, getitem_83, t_default_84, getitem_7, view_default_203, t_default_6, view_default_184, getitem_82, primals_16, primals_140, primals_139, getitem_31, view_default_65, getitem_32, add__tensor_9, primals_134, t_default_29, t_default_30, view_default_63, relu_default_4, t_default_28, primals_135, primals_127, primals_128, getitem_44, _unsafe_view_default_66, _unsafe_view_default_87, t_default_41, view_default_102, t_default_50, _softmax_default_8, t_default_48, eq_scalar_7, view_default_104, eq_scalar_8, add__tensor_17, view_default_87, t_default_39, add__tensor_15, view_default_89, _unsafe_view_default_60, getitem_43, _unsafe_view_default_67, t_default_49, view_default_106, view_default_86, _unsafe_view_default_78, primals_45, _unsafe_view_default_159, view_default_197, primals_53, primals_52, relu_default_11, primals_58, t_default_91, primals_59, eq_scalar_17, view_default_199, add__tensor_29, t_default_92, view_default_201, primals_46, add__tensor_28, _softmax_default_17, view_default_208, _softmax_default_16, t_default_87, t_default_85, getitem_85, _unsafe_view_default_147, getitem_86, t_default_86, view_default_188, _unsafe_view_default_148, t_default_88, view_default_190, eq_scalar_16, t_default_63, view_default_139, getitem_65, getitem_64, view_default_140, t_default_64, t_default_65, t_default_66, _unsafe_view_default_121, primals_114, getitem_95, getitem_94, view_default_210, eq_scalar_5, view_default_67, primals_116, primals_113, t_default_31, _unsafe_view_default_156, primals_115, view_default_69, primals_107, _unsafe_view_default_150, primals_17, t_default_32, _unsafe_view_default_141, t_default_77, add__tensor_24, view_default_168, _softmax_default_14, t_default_78, view_default_170, eq_scalar_14, primals_151, view_default_172, t_default_79, add__tensor_26, t_default_80, primals_152, _unsafe_view_default_132, view_default_4, _unsafe_view_default_3, view_default_115, t_default_1, view_default_2, add__tensor_16, view_default_117, t_default_2, view_default_6, _softmax_default, t_default_53, add__tensor, eq_scalar, getitem_56, view_default_118, t_default_54, getitem_55, view_default_126, view_default_9, _softmax_default_10, t_default_4, add__tensor_18, view_default_130, _unsafe_view_default_4, getitem_5, t_default_59, primals_191, getitem_4, view_default_128, _unsafe_view_default_6, getitem_61, view_default_8, t_default_3, primals_190, t_default_60, getitem_62, primals_1, _softmax_default_13, getitem_91, view_default_155, view_default_205, t_default_93, t_default_72, view_default_164, view_default_157, primals_5, getitem_92, add__tensor_23, view_default_206, primals_9, view_default_162, add__tensor_22, t_default_94, primals_4, _unsafe_view_default_123, relu_default_9, view_default_159, t_default_95, primals_2, t_default_73, t_default_96, primals_10, view_default_161, t_default_13, view_default_30, t_default_14, _unsafe_view_default_39, t_default_27, view_default_60, view_default_61, _unsafe_view_default_40, view_default_58, _unsafe_view_default_42, view_default_28, getitem_29, eq_scalar_2, getitem_28, view_default_120, view_default_108, t_default_52, getitem_52, getitem_53, _softmax_default_9, eq_scalar_9, view_default_109, t_default_51, _unsafe_view_default_84, view_default_111, relu_default_7, _unsafe_view_default_85, view_default_113, getitem_68, view_default_186, getitem_67, _softmax_default_4, view_default_174, _softmax_default_3, view_default_48, t_default_82, view_default_52, view_default_150, getitem_79, view_default_47, view_default_144, getitem_80, add__tensor_8, t_default_21, _unsafe_view_default_31, t_default_67, view_default_175, _unsafe_view_default_111, view_default_146, _unsafe_view_default_33, eq_scalar_15, t_default_26, view_default_54, _unsafe_view_default_139, t_default_81, _softmax_default_12, _unsafe_view_default_138, view_default_177, t_default_68, view_default_148, eq_scalar_4, t_default_25, add__tensor_6, relu_default_10, view_default_45, add__tensor_21, _unsafe_view_default_30, view_default_56, eq_scalar_12, view_default_179, _unsafe_view_default_114, getitem_47, primals_106, getitem_46, t_default_44, t_default_45, _unsafe_view_default_76, getitem_49, getitem_50, t_default_47, view_default_100, t_default_46, _unsafe_view_default_75, primals_99, primals_94, primals_95, primals_100, relu_default_5, view_default_74, getitem_34, t_default_35, view_default_76, getitem_35, t_default_34, add__tensor_11, t_default_10, t_default_11, getitem_11, add__tensor_3, _unsafe_view_default_58, getitem_10, view_default_21, view_default_82, t_default_40, eq_scalar_6, view_default_84, view_default_24, view_default_22, t_default_38, relu_default_1, _unsafe_view_default_57, _softmax_default_6, tangents_1):
        view_default_212 = torch.ops.aten.view.default(tangents_1, [256, 31, 9521]);  tangents_1 = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(view_default_212, 1.0);  view_default_212 = None
        view_default_213 = torch.ops.aten.view.default(mul_tensor_1, [7936, 9521]);  mul_tensor_1 = None
        t_default_97 = torch.ops.aten.t.default(view_default_213)
        mm_default_73 = torch.ops.aten.mm.default(t_default_97, view_default_210);  t_default_97 = view_default_210 = None
        t_default_98 = torch.ops.aten.t.default(mm_default_73);  mm_default_73 = None
        t_default_99 = torch.ops.aten.t.default(t_default_96);  t_default_96 = None
        mm_default_74 = torch.ops.aten.mm.default(view_default_213, t_default_99);  view_default_213 = t_default_99 = None
        view_default_214 = torch.ops.aten.view.default(mm_default_74, [256, 31, 512]);  mm_default_74 = None
        t_default_100 = torch.ops.aten.t.default(t_default_98);  t_default_98 = None
        native_layer_norm_backward_default = torch.ops.aten.native_layer_norm_backward.default(view_default_214, add__tensor_29, [512], getitem_94, getitem_95, primals_100, primals_99, [True, True, True]);  view_default_214 = add__tensor_29 = getitem_94 = getitem_95 = primals_100 = primals_99 = None
        getitem_96 = native_layer_norm_backward_default[0]
        getitem_97 = native_layer_norm_backward_default[1]
        getitem_98 = native_layer_norm_backward_default[2];  native_layer_norm_backward_default = None
        new_empty_default = torch.ops.aten.new_empty.default(getitem_96, [4063232]);  getitem_96 = None
        zero__default = torch.ops.aten.zero_.default(new_empty_default);  new_empty_default = None
        as_strided_default_1 = torch.ops.aten.as_strided.default(zero__default, [7936, 512], [512, 1], 0);  zero__default = None
        new_empty_strided_default = torch.ops.aten.new_empty_strided.default(as_strided_default_1, [7936, 512], [512, 1])
        copy__default_1 = torch.ops.aten.copy_.default(new_empty_strided_default, as_strided_default_1);  new_empty_strided_default = as_strided_default_1 = None
        as_strided_default_2 = torch.ops.aten.as_strided.default(copy__default_1, [256, 31, 512], [15872, 512, 1], 0)
        clone_default_74 = torch.ops.aten.clone.default(as_strided_default_2, memory_format = torch.contiguous_format);  as_strided_default_2 = None
        t_default_101 = torch.ops.aten.t.default(t_default_95);  t_default_95 = None
        mm_default_75 = torch.ops.aten.mm.default(copy__default_1, t_default_101);  t_default_101 = None
        t_default_102 = torch.ops.aten.t.default(copy__default_1)
        mm_default_76 = torch.ops.aten.mm.default(t_default_102, view_default_208);  t_default_102 = view_default_208 = None
        t_default_103 = torch.ops.aten.t.default(mm_default_76);  mm_default_76 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(copy__default_1, [0], True);  copy__default_1 = None
        view_default_215 = torch.ops.aten.view.default(sum_dim_int_list, [512]);  sum_dim_int_list = None
        t_default_104 = torch.ops.aten.t.default(t_default_103);  t_default_103 = None
        view_default_216 = torch.ops.aten.view.default(mm_default_75, [256, 31, 2048]);  mm_default_75 = None
        to_dtype = torch.ops.aten.to.dtype(view_default_216, torch.float32);  view_default_216 = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu_default_11, torch.float32);  relu_default_11 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default, to_dtype);  le_scalar = new_zeros_default = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        view_default_217 = torch.ops.aten.view.default(to_dtype_2, [7936, 2048]);  to_dtype_2 = None
        t_default_105 = torch.ops.aten.t.default(t_default_94);  t_default_94 = None
        mm_default_77 = torch.ops.aten.mm.default(view_default_217, t_default_105);  t_default_105 = None
        t_default_106 = torch.ops.aten.t.default(view_default_217)
        mm_default_78 = torch.ops.aten.mm.default(t_default_106, view_default_206);  t_default_106 = view_default_206 = None
        t_default_107 = torch.ops.aten.t.default(mm_default_78);  mm_default_78 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(view_default_217, [0], True);  view_default_217 = None
        view_default_218 = torch.ops.aten.view.default(sum_dim_int_list_1, [2048]);  sum_dim_int_list_1 = None
        t_default_108 = torch.ops.aten.t.default(t_default_107);  t_default_107 = None
        view_default_219 = torch.ops.aten.view.default(mm_default_77, [256, 31, 512]);  mm_default_77 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(clone_default_74, view_default_219);  clone_default_74 = view_default_219 = None
        native_layer_norm_backward_default_1 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_2, add__tensor_28, [512], getitem_91, getitem_92, primals_95, primals_94, [True, True, True]);  add_tensor_2 = add__tensor_28 = getitem_91 = getitem_92 = primals_95 = primals_94 = None
        getitem_99 = native_layer_norm_backward_default_1[0]
        getitem_100 = native_layer_norm_backward_default_1[1]
        getitem_101 = native_layer_norm_backward_default_1[2];  native_layer_norm_backward_default_1 = None
        view_default_220 = torch.ops.aten.view.default(getitem_99, [7936, 512])
        t_default_109 = torch.ops.aten.t.default(view_default_220)
        mm_default_79 = torch.ops.aten.mm.default(t_default_109, view_default_205);  t_default_109 = view_default_205 = None
        t_default_110 = torch.ops.aten.t.default(mm_default_79);  mm_default_79 = None
        t_default_111 = torch.ops.aten.t.default(t_default_93);  t_default_93 = None
        mm_default_80 = torch.ops.aten.mm.default(view_default_220, t_default_111);  view_default_220 = t_default_111 = None
        view_default_221 = torch.ops.aten.view.default(mm_default_80, [256, 31, 512]);  mm_default_80 = None
        t_default_112 = torch.ops.aten.t.default(t_default_110);  t_default_110 = None
        view_default_222 = torch.ops.aten.view.default(view_default_221, [256, 31, 8, 64]);  view_default_221 = None
        transpose_int_90 = torch.ops.aten.transpose.int(view_default_222, 1, 2);  view_default_222 = None
        clone_default_75 = torch.ops.aten.clone.default(transpose_int_90, memory_format = torch.contiguous_format);  transpose_int_90 = None
        _unsafe_view_default_163 = torch.ops.aten._unsafe_view.default(clone_default_75, [2048, 31, 64]);  clone_default_75 = None
        transpose_int_91 = torch.ops.aten.transpose.int(view_default_203, 1, 2);  view_default_203 = None
        bmm_default_36 = torch.ops.aten.bmm.default(transpose_int_91, _unsafe_view_default_163);  transpose_int_91 = None
        transpose_int_92 = torch.ops.aten.transpose.int(_unsafe_view_default_159, 1, 2);  _unsafe_view_default_159 = None
        bmm_default_37 = torch.ops.aten.bmm.default(_unsafe_view_default_163, transpose_int_92);  _unsafe_view_default_163 = transpose_int_92 = None
        view_default_223 = torch.ops.aten.view.default(bmm_default_36, [256, 8, 33, 64]);  bmm_default_36 = None
        view_default_224 = torch.ops.aten.view.default(bmm_default_37, [256, 8, 31, 33]);  bmm_default_37 = None
        _softmax_backward_data_default = torch.ops.aten._softmax_backward_data.default(view_default_224, _softmax_default_17, -1, torch.float32);  view_default_224 = _softmax_default_17 = None
        where_scalar_self_18 = torch.ops.aten.where.ScalarSelf(eq_scalar_17, 0.0, _softmax_backward_data_default);  eq_scalar_17 = _softmax_backward_data_default = None
        view_default_225 = torch.ops.aten.view.default(where_scalar_self_18, [2048, 31, 33]);  where_scalar_self_18 = None
        transpose_int_93 = torch.ops.aten.transpose.int(_unsafe_view_default_156, 1, 2);  _unsafe_view_default_156 = None
        bmm_default_38 = torch.ops.aten.bmm.default(transpose_int_93, view_default_225);  transpose_int_93 = None
        transpose_int_94 = torch.ops.aten.transpose.int(_unsafe_view_default_157, 1, 2);  _unsafe_view_default_157 = None
        bmm_default_39 = torch.ops.aten.bmm.default(view_default_225, transpose_int_94);  view_default_225 = transpose_int_94 = None
        view_default_226 = torch.ops.aten.view.default(bmm_default_38, [256, 8, 64, 33]);  bmm_default_38 = None
        view_default_227 = torch.ops.aten.view.default(bmm_default_39, [256, 8, 31, 64]);  bmm_default_39 = None
        transpose_int_95 = torch.ops.aten.transpose.int(view_default_226, 2, 3);  view_default_226 = None
        div_tensor_18 = torch.ops.aten.div.Tensor(view_default_227, 8.0);  view_default_227 = None
        transpose_int_96 = torch.ops.aten.transpose.int(view_default_223, 1, 2);  view_default_223 = None
        transpose_int_97 = torch.ops.aten.transpose.int(transpose_int_95, 1, 2);  transpose_int_95 = None
        transpose_int_98 = torch.ops.aten.transpose.int(div_tensor_18, 1, 2);  div_tensor_18 = None
        clone_default_76 = torch.ops.aten.clone.default(transpose_int_96, memory_format = torch.contiguous_format);  transpose_int_96 = None
        _unsafe_view_default_164 = torch.ops.aten._unsafe_view.default(clone_default_76, [256, 33, 512]);  clone_default_76 = None
        view_default_228 = torch.ops.aten.view.default(_unsafe_view_default_164, [8448, 512]);  _unsafe_view_default_164 = None
        t_default_113 = torch.ops.aten.t.default(view_default_228)
        mm_default_81 = torch.ops.aten.mm.default(t_default_113, view_default_201);  t_default_113 = view_default_201 = None
        t_default_114 = torch.ops.aten.t.default(mm_default_81);  mm_default_81 = None
        t_default_115 = torch.ops.aten.t.default(t_default_92);  t_default_92 = None
        mm_default_82 = torch.ops.aten.mm.default(view_default_228, t_default_115);  view_default_228 = t_default_115 = None
        view_default_229 = torch.ops.aten.view.default(mm_default_82, [256, 33, 512]);  mm_default_82 = None
        t_default_116 = torch.ops.aten.t.default(t_default_114);  t_default_114 = None
        view_default_230 = torch.ops.aten.view.default(transpose_int_97, [256, 33, 512]);  transpose_int_97 = None
        clone_default_77 = torch.ops.aten.clone.default(view_default_230, memory_format = torch.contiguous_format);  view_default_230 = None
        _unsafe_view_default_165 = torch.ops.aten._unsafe_view.default(clone_default_77, [8448, 512]);  clone_default_77 = None
        t_default_117 = torch.ops.aten.t.default(_unsafe_view_default_165)
        mm_default_83 = torch.ops.aten.mm.default(t_default_117, view_default_199);  t_default_117 = view_default_199 = None
        t_default_118 = torch.ops.aten.t.default(mm_default_83);  mm_default_83 = None
        t_default_119 = torch.ops.aten.t.default(t_default_91);  t_default_91 = None
        mm_default_84 = torch.ops.aten.mm.default(_unsafe_view_default_165, t_default_119);  _unsafe_view_default_165 = t_default_119 = None
        view_default_231 = torch.ops.aten.view.default(mm_default_84, [256, 33, 512]);  mm_default_84 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(view_default_229, view_default_231);  view_default_229 = view_default_231 = None
        t_default_120 = torch.ops.aten.t.default(t_default_118);  t_default_118 = None
        clone_default_78 = torch.ops.aten.clone.default(transpose_int_98, memory_format = torch.contiguous_format);  transpose_int_98 = None
        _unsafe_view_default_166 = torch.ops.aten._unsafe_view.default(clone_default_78, [256, 31, 512]);  clone_default_78 = None
        view_default_232 = torch.ops.aten.view.default(_unsafe_view_default_166, [7936, 512]);  _unsafe_view_default_166 = None
        t_default_121 = torch.ops.aten.t.default(view_default_232)
        mm_default_85 = torch.ops.aten.mm.default(t_default_121, view_default_197);  t_default_121 = view_default_197 = None
        t_default_122 = torch.ops.aten.t.default(mm_default_85);  mm_default_85 = None
        t_default_123 = torch.ops.aten.t.default(t_default_90);  t_default_90 = None
        mm_default_86 = torch.ops.aten.mm.default(view_default_232, t_default_123);  view_default_232 = t_default_123 = None
        view_default_233 = torch.ops.aten.view.default(mm_default_86, [256, 31, 512]);  mm_default_86 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(getitem_99, view_default_233);  getitem_99 = view_default_233 = None
        t_default_124 = torch.ops.aten.t.default(t_default_122);  t_default_122 = None
        native_layer_norm_backward_default_2 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_4, add__tensor_27, [512], getitem_88, getitem_89, primals_107, primals_106, [True, True, True]);  add_tensor_4 = add__tensor_27 = getitem_88 = getitem_89 = primals_107 = primals_106 = None
        getitem_102 = native_layer_norm_backward_default_2[0]
        getitem_103 = native_layer_norm_backward_default_2[1]
        getitem_104 = native_layer_norm_backward_default_2[2];  native_layer_norm_backward_default_2 = None
        view_default_234 = torch.ops.aten.view.default(getitem_102, [7936, 512])
        t_default_125 = torch.ops.aten.t.default(view_default_234)
        mm_default_87 = torch.ops.aten.mm.default(t_default_125, view_default_196);  t_default_125 = view_default_196 = None
        t_default_126 = torch.ops.aten.t.default(mm_default_87);  mm_default_87 = None
        t_default_127 = torch.ops.aten.t.default(t_default_89);  t_default_89 = None
        mm_default_88 = torch.ops.aten.mm.default(view_default_234, t_default_127);  view_default_234 = t_default_127 = None
        view_default_235 = torch.ops.aten.view.default(mm_default_88, [256, 31, 512]);  mm_default_88 = None
        t_default_128 = torch.ops.aten.t.default(t_default_126);  t_default_126 = None
        view_default_236 = torch.ops.aten.view.default(view_default_235, [256, 31, 8, 64]);  view_default_235 = None
        transpose_int_99 = torch.ops.aten.transpose.int(view_default_236, 1, 2);  view_default_236 = None
        clone_default_79 = torch.ops.aten.clone.default(transpose_int_99, memory_format = torch.contiguous_format);  transpose_int_99 = None
        _unsafe_view_default_167 = torch.ops.aten._unsafe_view.default(clone_default_79, [2048, 31, 64]);  clone_default_79 = None
        transpose_int_100 = torch.ops.aten.transpose.int(view_default_194, 1, 2);  view_default_194 = None
        bmm_default_40 = torch.ops.aten.bmm.default(transpose_int_100, _unsafe_view_default_167);  transpose_int_100 = None
        transpose_int_101 = torch.ops.aten.transpose.int(_unsafe_view_default_150, 1, 2);  _unsafe_view_default_150 = None
        bmm_default_41 = torch.ops.aten.bmm.default(_unsafe_view_default_167, transpose_int_101);  _unsafe_view_default_167 = transpose_int_101 = None
        view_default_237 = torch.ops.aten.view.default(bmm_default_40, [256, 8, 31, 64]);  bmm_default_40 = None
        view_default_238 = torch.ops.aten.view.default(bmm_default_41, [256, 8, 31, 31]);  bmm_default_41 = None
        _softmax_backward_data_default_1 = torch.ops.aten._softmax_backward_data.default(view_default_238, _softmax_default_16, -1, torch.float32);  view_default_238 = _softmax_default_16 = None
        where_scalar_self_19 = torch.ops.aten.where.ScalarSelf(eq_scalar_16, 0.0, _softmax_backward_data_default_1);  eq_scalar_16 = _softmax_backward_data_default_1 = None
        view_default_239 = torch.ops.aten.view.default(where_scalar_self_19, [2048, 31, 31]);  where_scalar_self_19 = None
        transpose_int_102 = torch.ops.aten.transpose.int(_unsafe_view_default_147, 1, 2);  _unsafe_view_default_147 = None
        bmm_default_42 = torch.ops.aten.bmm.default(transpose_int_102, view_default_239);  transpose_int_102 = None
        transpose_int_103 = torch.ops.aten.transpose.int(_unsafe_view_default_148, 1, 2);  _unsafe_view_default_148 = None
        bmm_default_43 = torch.ops.aten.bmm.default(view_default_239, transpose_int_103);  view_default_239 = transpose_int_103 = None
        view_default_240 = torch.ops.aten.view.default(bmm_default_42, [256, 8, 64, 31]);  bmm_default_42 = None
        view_default_241 = torch.ops.aten.view.default(bmm_default_43, [256, 8, 31, 64]);  bmm_default_43 = None
        transpose_int_104 = torch.ops.aten.transpose.int(view_default_240, 2, 3);  view_default_240 = None
        div_tensor_19 = torch.ops.aten.div.Tensor(view_default_241, 8.0);  view_default_241 = None
        transpose_int_105 = torch.ops.aten.transpose.int(view_default_237, 1, 2);  view_default_237 = None
        transpose_int_106 = torch.ops.aten.transpose.int(transpose_int_104, 1, 2);  transpose_int_104 = None
        transpose_int_107 = torch.ops.aten.transpose.int(div_tensor_19, 1, 2);  div_tensor_19 = None
        clone_default_80 = torch.ops.aten.clone.default(transpose_int_105, memory_format = torch.contiguous_format);  transpose_int_105 = None
        _unsafe_view_default_168 = torch.ops.aten._unsafe_view.default(clone_default_80, [256, 31, 512]);  clone_default_80 = None
        view_default_242 = torch.ops.aten.view.default(_unsafe_view_default_168, [7936, 512]);  _unsafe_view_default_168 = None
        t_default_129 = torch.ops.aten.t.default(view_default_242)
        mm_default_89 = torch.ops.aten.mm.default(t_default_129, view_default_192);  t_default_129 = view_default_192 = None
        t_default_130 = torch.ops.aten.t.default(mm_default_89);  mm_default_89 = None
        t_default_131 = torch.ops.aten.t.default(t_default_88);  t_default_88 = None
        mm_default_90 = torch.ops.aten.mm.default(view_default_242, t_default_131);  view_default_242 = t_default_131 = None
        view_default_243 = torch.ops.aten.view.default(mm_default_90, [256, 31, 512]);  mm_default_90 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(getitem_102, view_default_243);  getitem_102 = view_default_243 = None
        t_default_132 = torch.ops.aten.t.default(t_default_130);  t_default_130 = None
        view_default_244 = torch.ops.aten.view.default(transpose_int_106, [256, 31, 512]);  transpose_int_106 = None
        clone_default_81 = torch.ops.aten.clone.default(view_default_244, memory_format = torch.contiguous_format);  view_default_244 = None
        _unsafe_view_default_169 = torch.ops.aten._unsafe_view.default(clone_default_81, [7936, 512]);  clone_default_81 = None
        t_default_133 = torch.ops.aten.t.default(_unsafe_view_default_169)
        mm_default_91 = torch.ops.aten.mm.default(t_default_133, view_default_190);  t_default_133 = view_default_190 = None
        t_default_134 = torch.ops.aten.t.default(mm_default_91);  mm_default_91 = None
        t_default_135 = torch.ops.aten.t.default(t_default_87);  t_default_87 = None
        mm_default_92 = torch.ops.aten.mm.default(_unsafe_view_default_169, t_default_135);  _unsafe_view_default_169 = t_default_135 = None
        view_default_245 = torch.ops.aten.view.default(mm_default_92, [256, 31, 512]);  mm_default_92 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(add_tensor_5, view_default_245);  add_tensor_5 = view_default_245 = None
        t_default_136 = torch.ops.aten.t.default(t_default_134);  t_default_134 = None
        clone_default_82 = torch.ops.aten.clone.default(transpose_int_107, memory_format = torch.contiguous_format);  transpose_int_107 = None
        _unsafe_view_default_170 = torch.ops.aten._unsafe_view.default(clone_default_82, [256, 31, 512]);  clone_default_82 = None
        view_default_246 = torch.ops.aten.view.default(_unsafe_view_default_170, [7936, 512]);  _unsafe_view_default_170 = None
        t_default_137 = torch.ops.aten.t.default(view_default_246)
        mm_default_93 = torch.ops.aten.mm.default(t_default_137, view_default_188);  t_default_137 = view_default_188 = None
        t_default_138 = torch.ops.aten.t.default(mm_default_93);  mm_default_93 = None
        t_default_139 = torch.ops.aten.t.default(t_default_86);  t_default_86 = None
        mm_default_94 = torch.ops.aten.mm.default(view_default_246, t_default_139);  view_default_246 = t_default_139 = None
        view_default_247 = torch.ops.aten.view.default(mm_default_94, [256, 31, 512]);  mm_default_94 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(add_tensor_6, view_default_247);  add_tensor_6 = view_default_247 = None
        t_default_140 = torch.ops.aten.t.default(t_default_138);  t_default_138 = None
        native_layer_norm_backward_default_3 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_7, add__tensor_26, [512], getitem_85, getitem_86, primals_82, primals_81, [True, True, True]);  add_tensor_7 = add__tensor_26 = getitem_85 = getitem_86 = primals_82 = primals_81 = None
        getitem_105 = native_layer_norm_backward_default_3[0]
        getitem_106 = native_layer_norm_backward_default_3[1]
        getitem_107 = native_layer_norm_backward_default_3[2];  native_layer_norm_backward_default_3 = None
        new_empty_default_1 = torch.ops.aten.new_empty.default(getitem_105, [4063232]);  getitem_105 = None
        zero__default_1 = torch.ops.aten.zero_.default(new_empty_default_1);  new_empty_default_1 = None
        as_strided_default_4 = torch.ops.aten.as_strided.default(zero__default_1, [7936, 512], [512, 1], 0);  zero__default_1 = None
        new_empty_strided_default_1 = torch.ops.aten.new_empty_strided.default(as_strided_default_4, [7936, 512], [512, 1])
        copy__default_4 = torch.ops.aten.copy_.default(new_empty_strided_default_1, as_strided_default_4);  new_empty_strided_default_1 = as_strided_default_4 = None
        as_strided_default_5 = torch.ops.aten.as_strided.default(copy__default_4, [256, 31, 512], [15872, 512, 1], 0)
        clone_default_83 = torch.ops.aten.clone.default(as_strided_default_5, memory_format = torch.contiguous_format);  as_strided_default_5 = None
        t_default_141 = torch.ops.aten.t.default(t_default_85);  t_default_85 = None
        mm_default_95 = torch.ops.aten.mm.default(copy__default_4, t_default_141);  t_default_141 = None
        t_default_142 = torch.ops.aten.t.default(copy__default_4)
        mm_default_96 = torch.ops.aten.mm.default(t_default_142, view_default_186);  t_default_142 = view_default_186 = None
        t_default_143 = torch.ops.aten.t.default(mm_default_96);  mm_default_96 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(copy__default_4, [0], True);  copy__default_4 = None
        view_default_248 = torch.ops.aten.view.default(sum_dim_int_list_2, [512]);  sum_dim_int_list_2 = None
        t_default_144 = torch.ops.aten.t.default(t_default_143);  t_default_143 = None
        view_default_249 = torch.ops.aten.view.default(mm_default_95, [256, 31, 2048]);  mm_default_95 = None
        to_dtype_3 = torch.ops.aten.to.dtype(view_default_249, torch.float32);  view_default_249 = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu_default_10, torch.float32);  relu_default_10 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_1, to_dtype_3);  le_scalar_1 = new_zeros_default_1 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        view_default_250 = torch.ops.aten.view.default(to_dtype_5, [7936, 2048]);  to_dtype_5 = None
        t_default_145 = torch.ops.aten.t.default(t_default_84);  t_default_84 = None
        mm_default_97 = torch.ops.aten.mm.default(view_default_250, t_default_145);  t_default_145 = None
        t_default_146 = torch.ops.aten.t.default(view_default_250)
        mm_default_98 = torch.ops.aten.mm.default(t_default_146, view_default_184);  t_default_146 = view_default_184 = None
        t_default_147 = torch.ops.aten.t.default(mm_default_98);  mm_default_98 = None
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(view_default_250, [0], True);  view_default_250 = None
        view_default_251 = torch.ops.aten.view.default(sum_dim_int_list_3, [2048]);  sum_dim_int_list_3 = None
        t_default_148 = torch.ops.aten.t.default(t_default_147);  t_default_147 = None
        view_default_252 = torch.ops.aten.view.default(mm_default_97, [256, 31, 512]);  mm_default_97 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(clone_default_83, view_default_252);  clone_default_83 = view_default_252 = None
        native_layer_norm_backward_default_4 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_8, add__tensor_25, [512], getitem_82, getitem_83, primals_77, primals_76, [True, True, True]);  add_tensor_8 = add__tensor_25 = getitem_82 = getitem_83 = primals_77 = primals_76 = None
        getitem_108 = native_layer_norm_backward_default_4[0]
        getitem_109 = native_layer_norm_backward_default_4[1]
        getitem_110 = native_layer_norm_backward_default_4[2];  native_layer_norm_backward_default_4 = None
        view_default_253 = torch.ops.aten.view.default(getitem_108, [7936, 512])
        t_default_149 = torch.ops.aten.t.default(view_default_253)
        mm_default_99 = torch.ops.aten.mm.default(t_default_149, view_default_183);  t_default_149 = view_default_183 = None
        t_default_150 = torch.ops.aten.t.default(mm_default_99);  mm_default_99 = None
        t_default_151 = torch.ops.aten.t.default(t_default_83);  t_default_83 = None
        mm_default_100 = torch.ops.aten.mm.default(view_default_253, t_default_151);  view_default_253 = t_default_151 = None
        view_default_254 = torch.ops.aten.view.default(mm_default_100, [256, 31, 512]);  mm_default_100 = None
        t_default_152 = torch.ops.aten.t.default(t_default_150);  t_default_150 = None
        view_default_255 = torch.ops.aten.view.default(view_default_254, [256, 31, 8, 64]);  view_default_254 = None
        transpose_int_108 = torch.ops.aten.transpose.int(view_default_255, 1, 2);  view_default_255 = None
        clone_default_84 = torch.ops.aten.clone.default(transpose_int_108, memory_format = torch.contiguous_format);  transpose_int_108 = None
        _unsafe_view_default_171 = torch.ops.aten._unsafe_view.default(clone_default_84, [2048, 31, 64]);  clone_default_84 = None
        transpose_int_109 = torch.ops.aten.transpose.int(view_default_181, 1, 2);  view_default_181 = None
        bmm_default_44 = torch.ops.aten.bmm.default(transpose_int_109, _unsafe_view_default_171);  transpose_int_109 = None
        transpose_int_110 = torch.ops.aten.transpose.int(_unsafe_view_default_141, 1, 2);  _unsafe_view_default_141 = None
        bmm_default_45 = torch.ops.aten.bmm.default(_unsafe_view_default_171, transpose_int_110);  _unsafe_view_default_171 = transpose_int_110 = None
        view_default_256 = torch.ops.aten.view.default(bmm_default_44, [256, 8, 33, 64]);  bmm_default_44 = None
        view_default_257 = torch.ops.aten.view.default(bmm_default_45, [256, 8, 31, 33]);  bmm_default_45 = None
        _softmax_backward_data_default_2 = torch.ops.aten._softmax_backward_data.default(view_default_257, _softmax_default_15, -1, torch.float32);  view_default_257 = _softmax_default_15 = None
        where_scalar_self_20 = torch.ops.aten.where.ScalarSelf(eq_scalar_15, 0.0, _softmax_backward_data_default_2);  eq_scalar_15 = _softmax_backward_data_default_2 = None
        view_default_258 = torch.ops.aten.view.default(where_scalar_self_20, [2048, 31, 33]);  where_scalar_self_20 = None
        transpose_int_111 = torch.ops.aten.transpose.int(_unsafe_view_default_138, 1, 2);  _unsafe_view_default_138 = None
        bmm_default_46 = torch.ops.aten.bmm.default(transpose_int_111, view_default_258);  transpose_int_111 = None
        transpose_int_112 = torch.ops.aten.transpose.int(_unsafe_view_default_139, 1, 2);  _unsafe_view_default_139 = None
        bmm_default_47 = torch.ops.aten.bmm.default(view_default_258, transpose_int_112);  view_default_258 = transpose_int_112 = None
        view_default_259 = torch.ops.aten.view.default(bmm_default_46, [256, 8, 64, 33]);  bmm_default_46 = None
        view_default_260 = torch.ops.aten.view.default(bmm_default_47, [256, 8, 31, 64]);  bmm_default_47 = None
        transpose_int_113 = torch.ops.aten.transpose.int(view_default_259, 2, 3);  view_default_259 = None
        div_tensor_20 = torch.ops.aten.div.Tensor(view_default_260, 8.0);  view_default_260 = None
        transpose_int_114 = torch.ops.aten.transpose.int(view_default_256, 1, 2);  view_default_256 = None
        transpose_int_115 = torch.ops.aten.transpose.int(transpose_int_113, 1, 2);  transpose_int_113 = None
        transpose_int_116 = torch.ops.aten.transpose.int(div_tensor_20, 1, 2);  div_tensor_20 = None
        clone_default_85 = torch.ops.aten.clone.default(transpose_int_114, memory_format = torch.contiguous_format);  transpose_int_114 = None
        _unsafe_view_default_172 = torch.ops.aten._unsafe_view.default(clone_default_85, [256, 33, 512]);  clone_default_85 = None
        view_default_261 = torch.ops.aten.view.default(_unsafe_view_default_172, [8448, 512]);  _unsafe_view_default_172 = None
        t_default_153 = torch.ops.aten.t.default(view_default_261)
        mm_default_101 = torch.ops.aten.mm.default(t_default_153, view_default_179);  t_default_153 = view_default_179 = None
        t_default_154 = torch.ops.aten.t.default(mm_default_101);  mm_default_101 = None
        t_default_155 = torch.ops.aten.t.default(t_default_82);  t_default_82 = None
        mm_default_102 = torch.ops.aten.mm.default(view_default_261, t_default_155);  view_default_261 = t_default_155 = None
        view_default_262 = torch.ops.aten.view.default(mm_default_102, [256, 33, 512]);  mm_default_102 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(add_tensor_3, view_default_262);  add_tensor_3 = view_default_262 = None
        t_default_156 = torch.ops.aten.t.default(t_default_154);  t_default_154 = None
        view_default_263 = torch.ops.aten.view.default(transpose_int_115, [256, 33, 512]);  transpose_int_115 = None
        clone_default_86 = torch.ops.aten.clone.default(view_default_263, memory_format = torch.contiguous_format);  view_default_263 = None
        _unsafe_view_default_173 = torch.ops.aten._unsafe_view.default(clone_default_86, [8448, 512]);  clone_default_86 = None
        t_default_157 = torch.ops.aten.t.default(_unsafe_view_default_173)
        mm_default_103 = torch.ops.aten.mm.default(t_default_157, view_default_177);  t_default_157 = view_default_177 = None
        t_default_158 = torch.ops.aten.t.default(mm_default_103);  mm_default_103 = None
        t_default_159 = torch.ops.aten.t.default(t_default_81);  t_default_81 = None
        mm_default_104 = torch.ops.aten.mm.default(_unsafe_view_default_173, t_default_159);  _unsafe_view_default_173 = t_default_159 = None
        view_default_264 = torch.ops.aten.view.default(mm_default_104, [256, 33, 512]);  mm_default_104 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(add_tensor_9, view_default_264);  add_tensor_9 = view_default_264 = None
        t_default_160 = torch.ops.aten.t.default(t_default_158);  t_default_158 = None
        clone_default_87 = torch.ops.aten.clone.default(transpose_int_116, memory_format = torch.contiguous_format);  transpose_int_116 = None
        _unsafe_view_default_174 = torch.ops.aten._unsafe_view.default(clone_default_87, [256, 31, 512]);  clone_default_87 = None
        view_default_265 = torch.ops.aten.view.default(_unsafe_view_default_174, [7936, 512]);  _unsafe_view_default_174 = None
        t_default_161 = torch.ops.aten.t.default(view_default_265)
        mm_default_105 = torch.ops.aten.mm.default(t_default_161, view_default_175);  t_default_161 = view_default_175 = None
        t_default_162 = torch.ops.aten.t.default(mm_default_105);  mm_default_105 = None
        t_default_163 = torch.ops.aten.t.default(t_default_80);  t_default_80 = None
        mm_default_106 = torch.ops.aten.mm.default(view_default_265, t_default_163);  view_default_265 = t_default_163 = None
        view_default_266 = torch.ops.aten.view.default(mm_default_106, [256, 31, 512]);  mm_default_106 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(getitem_108, view_default_266);  getitem_108 = view_default_266 = None
        t_default_164 = torch.ops.aten.t.default(t_default_162);  t_default_162 = None
        native_layer_norm_backward_default_5 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_11, add__tensor_24, [512], getitem_79, getitem_80, primals_89, primals_88, [True, True, True]);  add_tensor_11 = add__tensor_24 = getitem_79 = getitem_80 = primals_89 = primals_88 = None
        getitem_111 = native_layer_norm_backward_default_5[0]
        getitem_112 = native_layer_norm_backward_default_5[1]
        getitem_113 = native_layer_norm_backward_default_5[2];  native_layer_norm_backward_default_5 = None
        view_default_267 = torch.ops.aten.view.default(getitem_111, [7936, 512])
        t_default_165 = torch.ops.aten.t.default(view_default_267)
        mm_default_107 = torch.ops.aten.mm.default(t_default_165, view_default_174);  t_default_165 = view_default_174 = None
        t_default_166 = torch.ops.aten.t.default(mm_default_107);  mm_default_107 = None
        t_default_167 = torch.ops.aten.t.default(t_default_79);  t_default_79 = None
        mm_default_108 = torch.ops.aten.mm.default(view_default_267, t_default_167);  view_default_267 = t_default_167 = None
        view_default_268 = torch.ops.aten.view.default(mm_default_108, [256, 31, 512]);  mm_default_108 = None
        t_default_168 = torch.ops.aten.t.default(t_default_166);  t_default_166 = None
        view_default_269 = torch.ops.aten.view.default(view_default_268, [256, 31, 8, 64]);  view_default_268 = None
        transpose_int_117 = torch.ops.aten.transpose.int(view_default_269, 1, 2);  view_default_269 = None
        clone_default_88 = torch.ops.aten.clone.default(transpose_int_117, memory_format = torch.contiguous_format);  transpose_int_117 = None
        _unsafe_view_default_175 = torch.ops.aten._unsafe_view.default(clone_default_88, [2048, 31, 64]);  clone_default_88 = None
        transpose_int_118 = torch.ops.aten.transpose.int(view_default_172, 1, 2);  view_default_172 = None
        bmm_default_48 = torch.ops.aten.bmm.default(transpose_int_118, _unsafe_view_default_175);  transpose_int_118 = None
        transpose_int_119 = torch.ops.aten.transpose.int(_unsafe_view_default_132, 1, 2);  _unsafe_view_default_132 = None
        bmm_default_49 = torch.ops.aten.bmm.default(_unsafe_view_default_175, transpose_int_119);  _unsafe_view_default_175 = transpose_int_119 = None
        view_default_270 = torch.ops.aten.view.default(bmm_default_48, [256, 8, 31, 64]);  bmm_default_48 = None
        view_default_271 = torch.ops.aten.view.default(bmm_default_49, [256, 8, 31, 31]);  bmm_default_49 = None
        _softmax_backward_data_default_3 = torch.ops.aten._softmax_backward_data.default(view_default_271, _softmax_default_14, -1, torch.float32);  view_default_271 = _softmax_default_14 = None
        where_scalar_self_21 = torch.ops.aten.where.ScalarSelf(eq_scalar_14, 0.0, _softmax_backward_data_default_3);  eq_scalar_14 = _softmax_backward_data_default_3 = None
        view_default_272 = torch.ops.aten.view.default(where_scalar_self_21, [2048, 31, 31]);  where_scalar_self_21 = None
        transpose_int_120 = torch.ops.aten.transpose.int(_unsafe_view_default_129, 1, 2);  _unsafe_view_default_129 = None
        bmm_default_50 = torch.ops.aten.bmm.default(transpose_int_120, view_default_272);  transpose_int_120 = None
        transpose_int_121 = torch.ops.aten.transpose.int(_unsafe_view_default_130, 1, 2);  _unsafe_view_default_130 = None
        bmm_default_51 = torch.ops.aten.bmm.default(view_default_272, transpose_int_121);  view_default_272 = transpose_int_121 = None
        view_default_273 = torch.ops.aten.view.default(bmm_default_50, [256, 8, 64, 31]);  bmm_default_50 = None
        view_default_274 = torch.ops.aten.view.default(bmm_default_51, [256, 8, 31, 64]);  bmm_default_51 = None
        transpose_int_122 = torch.ops.aten.transpose.int(view_default_273, 2, 3);  view_default_273 = None
        div_tensor_21 = torch.ops.aten.div.Tensor(view_default_274, 8.0);  view_default_274 = None
        transpose_int_123 = torch.ops.aten.transpose.int(view_default_270, 1, 2);  view_default_270 = None
        transpose_int_124 = torch.ops.aten.transpose.int(transpose_int_122, 1, 2);  transpose_int_122 = None
        transpose_int_125 = torch.ops.aten.transpose.int(div_tensor_21, 1, 2);  div_tensor_21 = None
        clone_default_89 = torch.ops.aten.clone.default(transpose_int_123, memory_format = torch.contiguous_format);  transpose_int_123 = None
        _unsafe_view_default_176 = torch.ops.aten._unsafe_view.default(clone_default_89, [256, 31, 512]);  clone_default_89 = None
        view_default_275 = torch.ops.aten.view.default(_unsafe_view_default_176, [7936, 512]);  _unsafe_view_default_176 = None
        t_default_169 = torch.ops.aten.t.default(view_default_275)
        mm_default_109 = torch.ops.aten.mm.default(t_default_169, view_default_170);  t_default_169 = view_default_170 = None
        t_default_170 = torch.ops.aten.t.default(mm_default_109);  mm_default_109 = None
        t_default_171 = torch.ops.aten.t.default(t_default_78);  t_default_78 = None
        mm_default_110 = torch.ops.aten.mm.default(view_default_275, t_default_171);  view_default_275 = t_default_171 = None
        view_default_276 = torch.ops.aten.view.default(mm_default_110, [256, 31, 512]);  mm_default_110 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(getitem_111, view_default_276);  getitem_111 = view_default_276 = None
        t_default_172 = torch.ops.aten.t.default(t_default_170);  t_default_170 = None
        view_default_277 = torch.ops.aten.view.default(transpose_int_124, [256, 31, 512]);  transpose_int_124 = None
        clone_default_90 = torch.ops.aten.clone.default(view_default_277, memory_format = torch.contiguous_format);  view_default_277 = None
        _unsafe_view_default_177 = torch.ops.aten._unsafe_view.default(clone_default_90, [7936, 512]);  clone_default_90 = None
        t_default_173 = torch.ops.aten.t.default(_unsafe_view_default_177)
        mm_default_111 = torch.ops.aten.mm.default(t_default_173, view_default_168);  t_default_173 = view_default_168 = None
        t_default_174 = torch.ops.aten.t.default(mm_default_111);  mm_default_111 = None
        t_default_175 = torch.ops.aten.t.default(t_default_77);  t_default_77 = None
        mm_default_112 = torch.ops.aten.mm.default(_unsafe_view_default_177, t_default_175);  _unsafe_view_default_177 = t_default_175 = None
        view_default_278 = torch.ops.aten.view.default(mm_default_112, [256, 31, 512]);  mm_default_112 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(add_tensor_12, view_default_278);  add_tensor_12 = view_default_278 = None
        t_default_176 = torch.ops.aten.t.default(t_default_174);  t_default_174 = None
        clone_default_91 = torch.ops.aten.clone.default(transpose_int_125, memory_format = torch.contiguous_format);  transpose_int_125 = None
        _unsafe_view_default_178 = torch.ops.aten._unsafe_view.default(clone_default_91, [256, 31, 512]);  clone_default_91 = None
        view_default_279 = torch.ops.aten.view.default(_unsafe_view_default_178, [7936, 512]);  _unsafe_view_default_178 = None
        t_default_177 = torch.ops.aten.t.default(view_default_279)
        mm_default_113 = torch.ops.aten.mm.default(t_default_177, view_default_166);  t_default_177 = view_default_166 = None
        t_default_178 = torch.ops.aten.t.default(mm_default_113);  mm_default_113 = None
        t_default_179 = torch.ops.aten.t.default(t_default_76);  t_default_76 = None
        mm_default_114 = torch.ops.aten.mm.default(view_default_279, t_default_179);  view_default_279 = t_default_179 = None
        view_default_280 = torch.ops.aten.view.default(mm_default_114, [256, 31, 512]);  mm_default_114 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(add_tensor_13, view_default_280);  add_tensor_13 = view_default_280 = None
        t_default_180 = torch.ops.aten.t.default(t_default_178);  t_default_178 = None
        native_layer_norm_backward_default_6 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_14, add__tensor_23, [512], getitem_76, getitem_77, primals_64, primals_63, [True, True, True]);  add_tensor_14 = add__tensor_23 = getitem_76 = getitem_77 = primals_64 = primals_63 = None
        getitem_114 = native_layer_norm_backward_default_6[0]
        getitem_115 = native_layer_norm_backward_default_6[1]
        getitem_116 = native_layer_norm_backward_default_6[2];  native_layer_norm_backward_default_6 = None
        new_empty_default_2 = torch.ops.aten.new_empty.default(getitem_114, [4063232]);  getitem_114 = None
        zero__default_2 = torch.ops.aten.zero_.default(new_empty_default_2);  new_empty_default_2 = None
        as_strided_default_7 = torch.ops.aten.as_strided.default(zero__default_2, [7936, 512], [512, 1], 0);  zero__default_2 = None
        new_empty_strided_default_2 = torch.ops.aten.new_empty_strided.default(as_strided_default_7, [7936, 512], [512, 1])
        copy__default_7 = torch.ops.aten.copy_.default(new_empty_strided_default_2, as_strided_default_7);  new_empty_strided_default_2 = as_strided_default_7 = None
        as_strided_default_8 = torch.ops.aten.as_strided.default(copy__default_7, [256, 31, 512], [15872, 512, 1], 0)
        clone_default_92 = torch.ops.aten.clone.default(as_strided_default_8, memory_format = torch.contiguous_format);  as_strided_default_8 = None
        t_default_181 = torch.ops.aten.t.default(t_default_75);  t_default_75 = None
        mm_default_115 = torch.ops.aten.mm.default(copy__default_7, t_default_181);  t_default_181 = None
        t_default_182 = torch.ops.aten.t.default(copy__default_7)
        mm_default_116 = torch.ops.aten.mm.default(t_default_182, view_default_164);  t_default_182 = view_default_164 = None
        t_default_183 = torch.ops.aten.t.default(mm_default_116);  mm_default_116 = None
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(copy__default_7, [0], True);  copy__default_7 = None
        view_default_281 = torch.ops.aten.view.default(sum_dim_int_list_4, [512]);  sum_dim_int_list_4 = None
        t_default_184 = torch.ops.aten.t.default(t_default_183);  t_default_183 = None
        view_default_282 = torch.ops.aten.view.default(mm_default_115, [256, 31, 2048]);  mm_default_115 = None
        to_dtype_6 = torch.ops.aten.to.dtype(view_default_282, torch.float32);  view_default_282 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu_default_9, torch.float32);  relu_default_9 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_2 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_2, to_dtype_6);  le_scalar_2 = new_zeros_default_2 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        view_default_283 = torch.ops.aten.view.default(to_dtype_8, [7936, 2048]);  to_dtype_8 = None
        t_default_185 = torch.ops.aten.t.default(t_default_74);  t_default_74 = None
        mm_default_117 = torch.ops.aten.mm.default(view_default_283, t_default_185);  t_default_185 = None
        t_default_186 = torch.ops.aten.t.default(view_default_283)
        mm_default_118 = torch.ops.aten.mm.default(t_default_186, view_default_162);  t_default_186 = view_default_162 = None
        t_default_187 = torch.ops.aten.t.default(mm_default_118);  mm_default_118 = None
        sum_dim_int_list_5 = torch.ops.aten.sum.dim_IntList(view_default_283, [0], True);  view_default_283 = None
        view_default_284 = torch.ops.aten.view.default(sum_dim_int_list_5, [2048]);  sum_dim_int_list_5 = None
        t_default_188 = torch.ops.aten.t.default(t_default_187);  t_default_187 = None
        view_default_285 = torch.ops.aten.view.default(mm_default_117, [256, 31, 512]);  mm_default_117 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(clone_default_92, view_default_285);  clone_default_92 = view_default_285 = None
        native_layer_norm_backward_default_7 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_15, add__tensor_22, [512], getitem_73, getitem_74, primals_59, primals_58, [True, True, True]);  add_tensor_15 = add__tensor_22 = getitem_73 = getitem_74 = primals_59 = primals_58 = None
        getitem_117 = native_layer_norm_backward_default_7[0]
        getitem_118 = native_layer_norm_backward_default_7[1]
        getitem_119 = native_layer_norm_backward_default_7[2];  native_layer_norm_backward_default_7 = None
        view_default_286 = torch.ops.aten.view.default(getitem_117, [7936, 512])
        t_default_189 = torch.ops.aten.t.default(view_default_286)
        mm_default_119 = torch.ops.aten.mm.default(t_default_189, view_default_161);  t_default_189 = view_default_161 = None
        t_default_190 = torch.ops.aten.t.default(mm_default_119);  mm_default_119 = None
        t_default_191 = torch.ops.aten.t.default(t_default_73);  t_default_73 = None
        mm_default_120 = torch.ops.aten.mm.default(view_default_286, t_default_191);  view_default_286 = t_default_191 = None
        view_default_287 = torch.ops.aten.view.default(mm_default_120, [256, 31, 512]);  mm_default_120 = None
        t_default_192 = torch.ops.aten.t.default(t_default_190);  t_default_190 = None
        view_default_288 = torch.ops.aten.view.default(view_default_287, [256, 31, 8, 64]);  view_default_287 = None
        transpose_int_126 = torch.ops.aten.transpose.int(view_default_288, 1, 2);  view_default_288 = None
        clone_default_93 = torch.ops.aten.clone.default(transpose_int_126, memory_format = torch.contiguous_format);  transpose_int_126 = None
        _unsafe_view_default_179 = torch.ops.aten._unsafe_view.default(clone_default_93, [2048, 31, 64]);  clone_default_93 = None
        transpose_int_127 = torch.ops.aten.transpose.int(view_default_159, 1, 2);  view_default_159 = None
        bmm_default_52 = torch.ops.aten.bmm.default(transpose_int_127, _unsafe_view_default_179);  transpose_int_127 = None
        transpose_int_128 = torch.ops.aten.transpose.int(_unsafe_view_default_123, 1, 2);  _unsafe_view_default_123 = None
        bmm_default_53 = torch.ops.aten.bmm.default(_unsafe_view_default_179, transpose_int_128);  _unsafe_view_default_179 = transpose_int_128 = None
        view_default_289 = torch.ops.aten.view.default(bmm_default_52, [256, 8, 33, 64]);  bmm_default_52 = None
        view_default_290 = torch.ops.aten.view.default(bmm_default_53, [256, 8, 31, 33]);  bmm_default_53 = None
        _softmax_backward_data_default_4 = torch.ops.aten._softmax_backward_data.default(view_default_290, _softmax_default_13, -1, torch.float32);  view_default_290 = _softmax_default_13 = None
        where_scalar_self_22 = torch.ops.aten.where.ScalarSelf(eq_scalar_13, 0.0, _softmax_backward_data_default_4);  eq_scalar_13 = _softmax_backward_data_default_4 = None
        view_default_291 = torch.ops.aten.view.default(where_scalar_self_22, [2048, 31, 33]);  where_scalar_self_22 = None
        transpose_int_129 = torch.ops.aten.transpose.int(_unsafe_view_default_120, 1, 2);  _unsafe_view_default_120 = None
        bmm_default_54 = torch.ops.aten.bmm.default(transpose_int_129, view_default_291);  transpose_int_129 = None
        transpose_int_130 = torch.ops.aten.transpose.int(_unsafe_view_default_121, 1, 2);  _unsafe_view_default_121 = None
        bmm_default_55 = torch.ops.aten.bmm.default(view_default_291, transpose_int_130);  view_default_291 = transpose_int_130 = None
        view_default_292 = torch.ops.aten.view.default(bmm_default_54, [256, 8, 64, 33]);  bmm_default_54 = None
        view_default_293 = torch.ops.aten.view.default(bmm_default_55, [256, 8, 31, 64]);  bmm_default_55 = None
        transpose_int_131 = torch.ops.aten.transpose.int(view_default_292, 2, 3);  view_default_292 = None
        div_tensor_22 = torch.ops.aten.div.Tensor(view_default_293, 8.0);  view_default_293 = None
        transpose_int_132 = torch.ops.aten.transpose.int(view_default_289, 1, 2);  view_default_289 = None
        transpose_int_133 = torch.ops.aten.transpose.int(transpose_int_131, 1, 2);  transpose_int_131 = None
        transpose_int_134 = torch.ops.aten.transpose.int(div_tensor_22, 1, 2);  div_tensor_22 = None
        clone_default_94 = torch.ops.aten.clone.default(transpose_int_132, memory_format = torch.contiguous_format);  transpose_int_132 = None
        _unsafe_view_default_180 = torch.ops.aten._unsafe_view.default(clone_default_94, [256, 33, 512]);  clone_default_94 = None
        view_default_294 = torch.ops.aten.view.default(_unsafe_view_default_180, [8448, 512]);  _unsafe_view_default_180 = None
        t_default_193 = torch.ops.aten.t.default(view_default_294)
        mm_default_121 = torch.ops.aten.mm.default(t_default_193, view_default_157);  t_default_193 = view_default_157 = None
        t_default_194 = torch.ops.aten.t.default(mm_default_121);  mm_default_121 = None
        t_default_195 = torch.ops.aten.t.default(t_default_72);  t_default_72 = None
        mm_default_122 = torch.ops.aten.mm.default(view_default_294, t_default_195);  view_default_294 = t_default_195 = None
        view_default_295 = torch.ops.aten.view.default(mm_default_122, [256, 33, 512]);  mm_default_122 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(add_tensor_10, view_default_295);  add_tensor_10 = view_default_295 = None
        t_default_196 = torch.ops.aten.t.default(t_default_194);  t_default_194 = None
        view_default_296 = torch.ops.aten.view.default(transpose_int_133, [256, 33, 512]);  transpose_int_133 = None
        clone_default_95 = torch.ops.aten.clone.default(view_default_296, memory_format = torch.contiguous_format);  view_default_296 = None
        _unsafe_view_default_181 = torch.ops.aten._unsafe_view.default(clone_default_95, [8448, 512]);  clone_default_95 = None
        t_default_197 = torch.ops.aten.t.default(_unsafe_view_default_181)
        mm_default_123 = torch.ops.aten.mm.default(t_default_197, view_default_155);  t_default_197 = view_default_155 = None
        t_default_198 = torch.ops.aten.t.default(mm_default_123);  mm_default_123 = None
        t_default_199 = torch.ops.aten.t.default(t_default_71);  t_default_71 = None
        mm_default_124 = torch.ops.aten.mm.default(_unsafe_view_default_181, t_default_199);  _unsafe_view_default_181 = t_default_199 = None
        view_default_297 = torch.ops.aten.view.default(mm_default_124, [256, 33, 512]);  mm_default_124 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(add_tensor_16, view_default_297);  add_tensor_16 = view_default_297 = None
        t_default_200 = torch.ops.aten.t.default(t_default_198);  t_default_198 = None
        clone_default_96 = torch.ops.aten.clone.default(transpose_int_134, memory_format = torch.contiguous_format);  transpose_int_134 = None
        _unsafe_view_default_182 = torch.ops.aten._unsafe_view.default(clone_default_96, [256, 31, 512]);  clone_default_96 = None
        view_default_298 = torch.ops.aten.view.default(_unsafe_view_default_182, [7936, 512]);  _unsafe_view_default_182 = None
        t_default_201 = torch.ops.aten.t.default(view_default_298)
        mm_default_125 = torch.ops.aten.mm.default(t_default_201, view_default_153);  t_default_201 = view_default_153 = None
        t_default_202 = torch.ops.aten.t.default(mm_default_125);  mm_default_125 = None
        t_default_203 = torch.ops.aten.t.default(t_default_70);  t_default_70 = None
        mm_default_126 = torch.ops.aten.mm.default(view_default_298, t_default_203);  view_default_298 = t_default_203 = None
        view_default_299 = torch.ops.aten.view.default(mm_default_126, [256, 31, 512]);  mm_default_126 = None
        add_tensor_18 = torch.ops.aten.add.Tensor(getitem_117, view_default_299);  getitem_117 = view_default_299 = None
        t_default_204 = torch.ops.aten.t.default(t_default_202);  t_default_202 = None
        native_layer_norm_backward_default_8 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_18, add__tensor_21, [512], getitem_70, getitem_71, primals_71, primals_70, [True, True, True]);  add_tensor_18 = add__tensor_21 = getitem_70 = getitem_71 = primals_71 = primals_70 = None
        getitem_120 = native_layer_norm_backward_default_8[0]
        getitem_121 = native_layer_norm_backward_default_8[1]
        getitem_122 = native_layer_norm_backward_default_8[2];  native_layer_norm_backward_default_8 = None
        view_default_300 = torch.ops.aten.view.default(getitem_120, [7936, 512])
        t_default_205 = torch.ops.aten.t.default(view_default_300)
        mm_default_127 = torch.ops.aten.mm.default(t_default_205, view_default_152);  t_default_205 = view_default_152 = None
        t_default_206 = torch.ops.aten.t.default(mm_default_127);  mm_default_127 = None
        t_default_207 = torch.ops.aten.t.default(t_default_69);  t_default_69 = None
        mm_default_128 = torch.ops.aten.mm.default(view_default_300, t_default_207);  view_default_300 = t_default_207 = None
        view_default_301 = torch.ops.aten.view.default(mm_default_128, [256, 31, 512]);  mm_default_128 = None
        t_default_208 = torch.ops.aten.t.default(t_default_206);  t_default_206 = None
        view_default_302 = torch.ops.aten.view.default(view_default_301, [256, 31, 8, 64]);  view_default_301 = None
        transpose_int_135 = torch.ops.aten.transpose.int(view_default_302, 1, 2);  view_default_302 = None
        clone_default_97 = torch.ops.aten.clone.default(transpose_int_135, memory_format = torch.contiguous_format);  transpose_int_135 = None
        _unsafe_view_default_183 = torch.ops.aten._unsafe_view.default(clone_default_97, [2048, 31, 64]);  clone_default_97 = None
        transpose_int_136 = torch.ops.aten.transpose.int(view_default_150, 1, 2);  view_default_150 = None
        bmm_default_56 = torch.ops.aten.bmm.default(transpose_int_136, _unsafe_view_default_183);  transpose_int_136 = None
        transpose_int_137 = torch.ops.aten.transpose.int(_unsafe_view_default_114, 1, 2);  _unsafe_view_default_114 = None
        bmm_default_57 = torch.ops.aten.bmm.default(_unsafe_view_default_183, transpose_int_137);  _unsafe_view_default_183 = transpose_int_137 = None
        view_default_303 = torch.ops.aten.view.default(bmm_default_56, [256, 8, 31, 64]);  bmm_default_56 = None
        view_default_304 = torch.ops.aten.view.default(bmm_default_57, [256, 8, 31, 31]);  bmm_default_57 = None
        _softmax_backward_data_default_5 = torch.ops.aten._softmax_backward_data.default(view_default_304, _softmax_default_12, -1, torch.float32);  view_default_304 = _softmax_default_12 = None
        where_scalar_self_23 = torch.ops.aten.where.ScalarSelf(eq_scalar_12, 0.0, _softmax_backward_data_default_5);  eq_scalar_12 = _softmax_backward_data_default_5 = None
        view_default_305 = torch.ops.aten.view.default(where_scalar_self_23, [2048, 31, 31]);  where_scalar_self_23 = None
        transpose_int_138 = torch.ops.aten.transpose.int(_unsafe_view_default_111, 1, 2);  _unsafe_view_default_111 = None
        bmm_default_58 = torch.ops.aten.bmm.default(transpose_int_138, view_default_305);  transpose_int_138 = None
        transpose_int_139 = torch.ops.aten.transpose.int(_unsafe_view_default_112, 1, 2);  _unsafe_view_default_112 = None
        bmm_default_59 = torch.ops.aten.bmm.default(view_default_305, transpose_int_139);  view_default_305 = transpose_int_139 = None
        view_default_306 = torch.ops.aten.view.default(bmm_default_58, [256, 8, 64, 31]);  bmm_default_58 = None
        view_default_307 = torch.ops.aten.view.default(bmm_default_59, [256, 8, 31, 64]);  bmm_default_59 = None
        transpose_int_140 = torch.ops.aten.transpose.int(view_default_306, 2, 3);  view_default_306 = None
        div_tensor_23 = torch.ops.aten.div.Tensor(view_default_307, 8.0);  view_default_307 = None
        transpose_int_141 = torch.ops.aten.transpose.int(view_default_303, 1, 2);  view_default_303 = None
        transpose_int_142 = torch.ops.aten.transpose.int(transpose_int_140, 1, 2);  transpose_int_140 = None
        transpose_int_143 = torch.ops.aten.transpose.int(div_tensor_23, 1, 2);  div_tensor_23 = None
        clone_default_98 = torch.ops.aten.clone.default(transpose_int_141, memory_format = torch.contiguous_format);  transpose_int_141 = None
        _unsafe_view_default_184 = torch.ops.aten._unsafe_view.default(clone_default_98, [256, 31, 512]);  clone_default_98 = None
        view_default_308 = torch.ops.aten.view.default(_unsafe_view_default_184, [7936, 512]);  _unsafe_view_default_184 = None
        t_default_209 = torch.ops.aten.t.default(view_default_308)
        mm_default_129 = torch.ops.aten.mm.default(t_default_209, view_default_148);  t_default_209 = view_default_148 = None
        t_default_210 = torch.ops.aten.t.default(mm_default_129);  mm_default_129 = None
        t_default_211 = torch.ops.aten.t.default(t_default_68);  t_default_68 = None
        mm_default_130 = torch.ops.aten.mm.default(view_default_308, t_default_211);  view_default_308 = t_default_211 = None
        view_default_309 = torch.ops.aten.view.default(mm_default_130, [256, 31, 512]);  mm_default_130 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(getitem_120, view_default_309);  getitem_120 = view_default_309 = None
        t_default_212 = torch.ops.aten.t.default(t_default_210);  t_default_210 = None
        view_default_310 = torch.ops.aten.view.default(transpose_int_142, [256, 31, 512]);  transpose_int_142 = None
        clone_default_99 = torch.ops.aten.clone.default(view_default_310, memory_format = torch.contiguous_format);  view_default_310 = None
        _unsafe_view_default_185 = torch.ops.aten._unsafe_view.default(clone_default_99, [7936, 512]);  clone_default_99 = None
        t_default_213 = torch.ops.aten.t.default(_unsafe_view_default_185)
        mm_default_131 = torch.ops.aten.mm.default(t_default_213, view_default_146);  t_default_213 = view_default_146 = None
        t_default_214 = torch.ops.aten.t.default(mm_default_131);  mm_default_131 = None
        t_default_215 = torch.ops.aten.t.default(t_default_67);  t_default_67 = None
        mm_default_132 = torch.ops.aten.mm.default(_unsafe_view_default_185, t_default_215);  _unsafe_view_default_185 = t_default_215 = None
        view_default_311 = torch.ops.aten.view.default(mm_default_132, [256, 31, 512]);  mm_default_132 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(add_tensor_19, view_default_311);  add_tensor_19 = view_default_311 = None
        t_default_216 = torch.ops.aten.t.default(t_default_214);  t_default_214 = None
        clone_default_100 = torch.ops.aten.clone.default(transpose_int_143, memory_format = torch.contiguous_format);  transpose_int_143 = None
        _unsafe_view_default_186 = torch.ops.aten._unsafe_view.default(clone_default_100, [256, 31, 512]);  clone_default_100 = None
        view_default_312 = torch.ops.aten.view.default(_unsafe_view_default_186, [7936, 512]);  _unsafe_view_default_186 = None
        t_default_217 = torch.ops.aten.t.default(view_default_312)
        mm_default_133 = torch.ops.aten.mm.default(t_default_217, view_default_144);  t_default_217 = view_default_144 = None
        t_default_218 = torch.ops.aten.t.default(mm_default_133);  mm_default_133 = None
        t_default_219 = torch.ops.aten.t.default(t_default_66);  t_default_66 = None
        mm_default_134 = torch.ops.aten.mm.default(view_default_312, t_default_219);  view_default_312 = t_default_219 = None
        view_default_313 = torch.ops.aten.view.default(mm_default_134, [256, 31, 512]);  mm_default_134 = None
        add_tensor_21 = torch.ops.aten.add.Tensor(add_tensor_20, view_default_313);  add_tensor_20 = view_default_313 = None
        t_default_220 = torch.ops.aten.t.default(t_default_218);  t_default_218 = None
        native_layer_norm_backward_default_9 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_21, add__tensor_20, [512], getitem_67, getitem_68, primals_46, primals_45, [True, True, True]);  add_tensor_21 = add__tensor_20 = getitem_67 = getitem_68 = primals_46 = primals_45 = None
        getitem_123 = native_layer_norm_backward_default_9[0]
        getitem_124 = native_layer_norm_backward_default_9[1]
        getitem_125 = native_layer_norm_backward_default_9[2];  native_layer_norm_backward_default_9 = None
        new_empty_default_3 = torch.ops.aten.new_empty.default(getitem_123, [4063232]);  getitem_123 = None
        zero__default_3 = torch.ops.aten.zero_.default(new_empty_default_3);  new_empty_default_3 = None
        as_strided_default_10 = torch.ops.aten.as_strided.default(zero__default_3, [7936, 512], [512, 1], 0);  zero__default_3 = None
        new_empty_strided_default_3 = torch.ops.aten.new_empty_strided.default(as_strided_default_10, [7936, 512], [512, 1])
        copy__default_10 = torch.ops.aten.copy_.default(new_empty_strided_default_3, as_strided_default_10);  new_empty_strided_default_3 = as_strided_default_10 = None
        as_strided_default_11 = torch.ops.aten.as_strided.default(copy__default_10, [256, 31, 512], [15872, 512, 1], 0)
        clone_default_101 = torch.ops.aten.clone.default(as_strided_default_11, memory_format = torch.contiguous_format);  as_strided_default_11 = None
        t_default_221 = torch.ops.aten.t.default(t_default_65);  t_default_65 = None
        mm_default_135 = torch.ops.aten.mm.default(copy__default_10, t_default_221);  t_default_221 = None
        t_default_222 = torch.ops.aten.t.default(copy__default_10)
        mm_default_136 = torch.ops.aten.mm.default(t_default_222, view_default_142);  t_default_222 = view_default_142 = None
        t_default_223 = torch.ops.aten.t.default(mm_default_136);  mm_default_136 = None
        sum_dim_int_list_6 = torch.ops.aten.sum.dim_IntList(copy__default_10, [0], True);  copy__default_10 = None
        view_default_314 = torch.ops.aten.view.default(sum_dim_int_list_6, [512]);  sum_dim_int_list_6 = None
        t_default_224 = torch.ops.aten.t.default(t_default_223);  t_default_223 = None
        view_default_315 = torch.ops.aten.view.default(mm_default_135, [256, 31, 2048]);  mm_default_135 = None
        to_dtype_9 = torch.ops.aten.to.dtype(view_default_315, torch.float32);  view_default_315 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu_default_8, torch.float32);  relu_default_8 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_3, to_dtype_9);  le_scalar_3 = new_zeros_default_3 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        view_default_316 = torch.ops.aten.view.default(to_dtype_11, [7936, 2048]);  to_dtype_11 = None
        t_default_225 = torch.ops.aten.t.default(t_default_64);  t_default_64 = None
        mm_default_137 = torch.ops.aten.mm.default(view_default_316, t_default_225);  t_default_225 = None
        t_default_226 = torch.ops.aten.t.default(view_default_316)
        mm_default_138 = torch.ops.aten.mm.default(t_default_226, view_default_140);  t_default_226 = view_default_140 = None
        t_default_227 = torch.ops.aten.t.default(mm_default_138);  mm_default_138 = None
        sum_dim_int_list_7 = torch.ops.aten.sum.dim_IntList(view_default_316, [0], True);  view_default_316 = None
        view_default_317 = torch.ops.aten.view.default(sum_dim_int_list_7, [2048]);  sum_dim_int_list_7 = None
        t_default_228 = torch.ops.aten.t.default(t_default_227);  t_default_227 = None
        view_default_318 = torch.ops.aten.view.default(mm_default_137, [256, 31, 512]);  mm_default_137 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(clone_default_101, view_default_318);  clone_default_101 = view_default_318 = None
        native_layer_norm_backward_default_10 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_22, add__tensor_19, [512], getitem_64, getitem_65, primals_41, primals_40, [True, True, True]);  add_tensor_22 = add__tensor_19 = getitem_64 = getitem_65 = primals_41 = primals_40 = None
        getitem_126 = native_layer_norm_backward_default_10[0]
        getitem_127 = native_layer_norm_backward_default_10[1]
        getitem_128 = native_layer_norm_backward_default_10[2];  native_layer_norm_backward_default_10 = None
        view_default_319 = torch.ops.aten.view.default(getitem_126, [7936, 512])
        t_default_229 = torch.ops.aten.t.default(view_default_319)
        mm_default_139 = torch.ops.aten.mm.default(t_default_229, view_default_139);  t_default_229 = view_default_139 = None
        t_default_230 = torch.ops.aten.t.default(mm_default_139);  mm_default_139 = None
        t_default_231 = torch.ops.aten.t.default(t_default_63);  t_default_63 = None
        mm_default_140 = torch.ops.aten.mm.default(view_default_319, t_default_231);  view_default_319 = t_default_231 = None
        view_default_320 = torch.ops.aten.view.default(mm_default_140, [256, 31, 512]);  mm_default_140 = None
        t_default_232 = torch.ops.aten.t.default(t_default_230);  t_default_230 = None
        view_default_321 = torch.ops.aten.view.default(view_default_320, [256, 31, 8, 64]);  view_default_320 = None
        transpose_int_144 = torch.ops.aten.transpose.int(view_default_321, 1, 2);  view_default_321 = None
        clone_default_102 = torch.ops.aten.clone.default(transpose_int_144, memory_format = torch.contiguous_format);  transpose_int_144 = None
        _unsafe_view_default_187 = torch.ops.aten._unsafe_view.default(clone_default_102, [2048, 31, 64]);  clone_default_102 = None
        transpose_int_145 = torch.ops.aten.transpose.int(view_default_137, 1, 2);  view_default_137 = None
        bmm_default_60 = torch.ops.aten.bmm.default(transpose_int_145, _unsafe_view_default_187);  transpose_int_145 = None
        transpose_int_146 = torch.ops.aten.transpose.int(_unsafe_view_default_105, 1, 2);  _unsafe_view_default_105 = None
        bmm_default_61 = torch.ops.aten.bmm.default(_unsafe_view_default_187, transpose_int_146);  _unsafe_view_default_187 = transpose_int_146 = None
        view_default_322 = torch.ops.aten.view.default(bmm_default_60, [256, 8, 33, 64]);  bmm_default_60 = None
        view_default_323 = torch.ops.aten.view.default(bmm_default_61, [256, 8, 31, 33]);  bmm_default_61 = None
        _softmax_backward_data_default_6 = torch.ops.aten._softmax_backward_data.default(view_default_323, _softmax_default_11, -1, torch.float32);  view_default_323 = _softmax_default_11 = None
        where_scalar_self_24 = torch.ops.aten.where.ScalarSelf(eq_scalar_11, 0.0, _softmax_backward_data_default_6);  eq_scalar_11 = _softmax_backward_data_default_6 = None
        view_default_324 = torch.ops.aten.view.default(where_scalar_self_24, [2048, 31, 33]);  where_scalar_self_24 = None
        transpose_int_147 = torch.ops.aten.transpose.int(_unsafe_view_default_102, 1, 2);  _unsafe_view_default_102 = None
        bmm_default_62 = torch.ops.aten.bmm.default(transpose_int_147, view_default_324);  transpose_int_147 = None
        transpose_int_148 = torch.ops.aten.transpose.int(_unsafe_view_default_103, 1, 2);  _unsafe_view_default_103 = None
        bmm_default_63 = torch.ops.aten.bmm.default(view_default_324, transpose_int_148);  view_default_324 = transpose_int_148 = None
        view_default_325 = torch.ops.aten.view.default(bmm_default_62, [256, 8, 64, 33]);  bmm_default_62 = None
        view_default_326 = torch.ops.aten.view.default(bmm_default_63, [256, 8, 31, 64]);  bmm_default_63 = None
        transpose_int_149 = torch.ops.aten.transpose.int(view_default_325, 2, 3);  view_default_325 = None
        div_tensor_24 = torch.ops.aten.div.Tensor(view_default_326, 8.0);  view_default_326 = None
        transpose_int_150 = torch.ops.aten.transpose.int(view_default_322, 1, 2);  view_default_322 = None
        transpose_int_151 = torch.ops.aten.transpose.int(transpose_int_149, 1, 2);  transpose_int_149 = None
        transpose_int_152 = torch.ops.aten.transpose.int(div_tensor_24, 1, 2);  div_tensor_24 = None
        clone_default_103 = torch.ops.aten.clone.default(transpose_int_150, memory_format = torch.contiguous_format);  transpose_int_150 = None
        _unsafe_view_default_188 = torch.ops.aten._unsafe_view.default(clone_default_103, [256, 33, 512]);  clone_default_103 = None
        view_default_327 = torch.ops.aten.view.default(_unsafe_view_default_188, [8448, 512]);  _unsafe_view_default_188 = None
        t_default_233 = torch.ops.aten.t.default(view_default_327)
        mm_default_141 = torch.ops.aten.mm.default(t_default_233, view_default_135);  t_default_233 = view_default_135 = None
        t_default_234 = torch.ops.aten.t.default(mm_default_141);  mm_default_141 = None
        t_default_235 = torch.ops.aten.t.default(t_default_62);  t_default_62 = None
        mm_default_142 = torch.ops.aten.mm.default(view_default_327, t_default_235);  view_default_327 = t_default_235 = None
        view_default_328 = torch.ops.aten.view.default(mm_default_142, [256, 33, 512]);  mm_default_142 = None
        add_tensor_23 = torch.ops.aten.add.Tensor(add_tensor_17, view_default_328);  add_tensor_17 = view_default_328 = None
        t_default_236 = torch.ops.aten.t.default(t_default_234);  t_default_234 = None
        view_default_329 = torch.ops.aten.view.default(transpose_int_151, [256, 33, 512]);  transpose_int_151 = None
        clone_default_104 = torch.ops.aten.clone.default(view_default_329, memory_format = torch.contiguous_format);  view_default_329 = None
        _unsafe_view_default_189 = torch.ops.aten._unsafe_view.default(clone_default_104, [8448, 512]);  clone_default_104 = None
        t_default_237 = torch.ops.aten.t.default(_unsafe_view_default_189)
        mm_default_143 = torch.ops.aten.mm.default(t_default_237, view_default_133);  t_default_237 = view_default_133 = None
        t_default_238 = torch.ops.aten.t.default(mm_default_143);  mm_default_143 = None
        t_default_239 = torch.ops.aten.t.default(t_default_61);  t_default_61 = None
        mm_default_144 = torch.ops.aten.mm.default(_unsafe_view_default_189, t_default_239);  _unsafe_view_default_189 = t_default_239 = None
        view_default_330 = torch.ops.aten.view.default(mm_default_144, [256, 33, 512]);  mm_default_144 = None
        add_tensor_24 = torch.ops.aten.add.Tensor(add_tensor_23, view_default_330);  add_tensor_23 = view_default_330 = None
        t_default_240 = torch.ops.aten.t.default(t_default_238);  t_default_238 = None
        clone_default_105 = torch.ops.aten.clone.default(transpose_int_152, memory_format = torch.contiguous_format);  transpose_int_152 = None
        _unsafe_view_default_190 = torch.ops.aten._unsafe_view.default(clone_default_105, [256, 31, 512]);  clone_default_105 = None
        view_default_331 = torch.ops.aten.view.default(_unsafe_view_default_190, [7936, 512]);  _unsafe_view_default_190 = None
        t_default_241 = torch.ops.aten.t.default(view_default_331)
        mm_default_145 = torch.ops.aten.mm.default(t_default_241, view_default_131);  t_default_241 = view_default_131 = None
        t_default_242 = torch.ops.aten.t.default(mm_default_145);  mm_default_145 = None
        t_default_243 = torch.ops.aten.t.default(t_default_60);  t_default_60 = None
        mm_default_146 = torch.ops.aten.mm.default(view_default_331, t_default_243);  view_default_331 = t_default_243 = None
        view_default_332 = torch.ops.aten.view.default(mm_default_146, [256, 31, 512]);  mm_default_146 = None
        add_tensor_25 = torch.ops.aten.add.Tensor(getitem_126, view_default_332);  getitem_126 = view_default_332 = None
        t_default_244 = torch.ops.aten.t.default(t_default_242);  t_default_242 = None
        native_layer_norm_backward_default_11 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_25, add__tensor_18, [512], getitem_61, getitem_62, primals_53, primals_52, [True, True, True]);  add_tensor_25 = add__tensor_18 = getitem_61 = getitem_62 = primals_53 = primals_52 = None
        getitem_129 = native_layer_norm_backward_default_11[0]
        getitem_130 = native_layer_norm_backward_default_11[1]
        getitem_131 = native_layer_norm_backward_default_11[2];  native_layer_norm_backward_default_11 = None
        view_default_333 = torch.ops.aten.view.default(getitem_129, [7936, 512])
        t_default_245 = torch.ops.aten.t.default(view_default_333)
        mm_default_147 = torch.ops.aten.mm.default(t_default_245, view_default_130);  t_default_245 = view_default_130 = None
        t_default_246 = torch.ops.aten.t.default(mm_default_147);  mm_default_147 = None
        t_default_247 = torch.ops.aten.t.default(t_default_59);  t_default_59 = None
        mm_default_148 = torch.ops.aten.mm.default(view_default_333, t_default_247);  view_default_333 = t_default_247 = None
        view_default_334 = torch.ops.aten.view.default(mm_default_148, [256, 31, 512]);  mm_default_148 = None
        t_default_248 = torch.ops.aten.t.default(t_default_246);  t_default_246 = None
        view_default_335 = torch.ops.aten.view.default(view_default_334, [256, 31, 8, 64]);  view_default_334 = None
        transpose_int_153 = torch.ops.aten.transpose.int(view_default_335, 1, 2);  view_default_335 = None
        clone_default_106 = torch.ops.aten.clone.default(transpose_int_153, memory_format = torch.contiguous_format);  transpose_int_153 = None
        _unsafe_view_default_191 = torch.ops.aten._unsafe_view.default(clone_default_106, [2048, 31, 64]);  clone_default_106 = None
        transpose_int_154 = torch.ops.aten.transpose.int(view_default_128, 1, 2);  view_default_128 = None
        bmm_default_64 = torch.ops.aten.bmm.default(transpose_int_154, _unsafe_view_default_191);  transpose_int_154 = None
        transpose_int_155 = torch.ops.aten.transpose.int(_unsafe_view_default_96, 1, 2);  _unsafe_view_default_96 = None
        bmm_default_65 = torch.ops.aten.bmm.default(_unsafe_view_default_191, transpose_int_155);  _unsafe_view_default_191 = transpose_int_155 = None
        view_default_336 = torch.ops.aten.view.default(bmm_default_64, [256, 8, 31, 64]);  bmm_default_64 = None
        view_default_337 = torch.ops.aten.view.default(bmm_default_65, [256, 8, 31, 31]);  bmm_default_65 = None
        _softmax_backward_data_default_7 = torch.ops.aten._softmax_backward_data.default(view_default_337, _softmax_default_10, -1, torch.float32);  view_default_337 = _softmax_default_10 = None
        where_scalar_self_25 = torch.ops.aten.where.ScalarSelf(eq_scalar_10, 0.0, _softmax_backward_data_default_7);  eq_scalar_10 = _softmax_backward_data_default_7 = None
        view_default_338 = torch.ops.aten.view.default(where_scalar_self_25, [2048, 31, 31]);  where_scalar_self_25 = None
        transpose_int_156 = torch.ops.aten.transpose.int(_unsafe_view_default_93, 1, 2);  _unsafe_view_default_93 = None
        bmm_default_66 = torch.ops.aten.bmm.default(transpose_int_156, view_default_338);  transpose_int_156 = None
        transpose_int_157 = torch.ops.aten.transpose.int(_unsafe_view_default_94, 1, 2);  _unsafe_view_default_94 = None
        bmm_default_67 = torch.ops.aten.bmm.default(view_default_338, transpose_int_157);  view_default_338 = transpose_int_157 = None
        view_default_339 = torch.ops.aten.view.default(bmm_default_66, [256, 8, 64, 31]);  bmm_default_66 = None
        view_default_340 = torch.ops.aten.view.default(bmm_default_67, [256, 8, 31, 64]);  bmm_default_67 = None
        transpose_int_158 = torch.ops.aten.transpose.int(view_default_339, 2, 3);  view_default_339 = None
        div_tensor_25 = torch.ops.aten.div.Tensor(view_default_340, 8.0);  view_default_340 = None
        transpose_int_159 = torch.ops.aten.transpose.int(view_default_336, 1, 2);  view_default_336 = None
        transpose_int_160 = torch.ops.aten.transpose.int(transpose_int_158, 1, 2);  transpose_int_158 = None
        transpose_int_161 = torch.ops.aten.transpose.int(div_tensor_25, 1, 2);  div_tensor_25 = None
        clone_default_107 = torch.ops.aten.clone.default(transpose_int_159, memory_format = torch.contiguous_format);  transpose_int_159 = None
        _unsafe_view_default_192 = torch.ops.aten._unsafe_view.default(clone_default_107, [256, 31, 512]);  clone_default_107 = None
        view_default_341 = torch.ops.aten.view.default(_unsafe_view_default_192, [7936, 512]);  _unsafe_view_default_192 = None
        t_default_249 = torch.ops.aten.t.default(view_default_341)
        mm_default_149 = torch.ops.aten.mm.default(t_default_249, view_default_126);  t_default_249 = view_default_126 = None
        t_default_250 = torch.ops.aten.t.default(mm_default_149);  mm_default_149 = None
        t_default_251 = torch.ops.aten.t.default(t_default_58);  t_default_58 = None
        mm_default_150 = torch.ops.aten.mm.default(view_default_341, t_default_251);  view_default_341 = t_default_251 = None
        view_default_342 = torch.ops.aten.view.default(mm_default_150, [256, 31, 512]);  mm_default_150 = None
        add_tensor_26 = torch.ops.aten.add.Tensor(getitem_129, view_default_342);  getitem_129 = view_default_342 = None
        t_default_252 = torch.ops.aten.t.default(t_default_250);  t_default_250 = None
        view_default_343 = torch.ops.aten.view.default(transpose_int_160, [256, 31, 512]);  transpose_int_160 = None
        clone_default_108 = torch.ops.aten.clone.default(view_default_343, memory_format = torch.contiguous_format);  view_default_343 = None
        _unsafe_view_default_193 = torch.ops.aten._unsafe_view.default(clone_default_108, [7936, 512]);  clone_default_108 = None
        t_default_253 = torch.ops.aten.t.default(_unsafe_view_default_193)
        mm_default_151 = torch.ops.aten.mm.default(t_default_253, view_default_124);  t_default_253 = view_default_124 = None
        t_default_254 = torch.ops.aten.t.default(mm_default_151);  mm_default_151 = None
        t_default_255 = torch.ops.aten.t.default(t_default_57);  t_default_57 = None
        mm_default_152 = torch.ops.aten.mm.default(_unsafe_view_default_193, t_default_255);  _unsafe_view_default_193 = t_default_255 = None
        view_default_344 = torch.ops.aten.view.default(mm_default_152, [256, 31, 512]);  mm_default_152 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(add_tensor_26, view_default_344);  add_tensor_26 = view_default_344 = None
        t_default_256 = torch.ops.aten.t.default(t_default_254);  t_default_254 = None
        clone_default_109 = torch.ops.aten.clone.default(transpose_int_161, memory_format = torch.contiguous_format);  transpose_int_161 = None
        _unsafe_view_default_194 = torch.ops.aten._unsafe_view.default(clone_default_109, [256, 31, 512]);  clone_default_109 = None
        view_default_345 = torch.ops.aten.view.default(_unsafe_view_default_194, [7936, 512]);  _unsafe_view_default_194 = None
        t_default_257 = torch.ops.aten.t.default(view_default_345)
        mm_default_153 = torch.ops.aten.mm.default(t_default_257, view_default_122);  t_default_257 = view_default_122 = None
        t_default_258 = torch.ops.aten.t.default(mm_default_153);  mm_default_153 = None
        t_default_259 = torch.ops.aten.t.default(t_default_56);  t_default_56 = None
        mm_default_154 = torch.ops.aten.mm.default(view_default_345, t_default_259);  view_default_345 = t_default_259 = None
        view_default_346 = torch.ops.aten.view.default(mm_default_154, [256, 31, 512]);  mm_default_154 = None
        add_tensor_28 = torch.ops.aten.add.Tensor(add_tensor_27, view_default_346);  add_tensor_27 = view_default_346 = None
        t_default_260 = torch.ops.aten.t.default(t_default_258);  t_default_258 = None
        native_layer_norm_backward_default_12 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_28, add__tensor_17, [512], getitem_58, getitem_59, primals_28, primals_27, [True, True, True]);  add_tensor_28 = add__tensor_17 = getitem_58 = getitem_59 = primals_28 = primals_27 = None
        getitem_132 = native_layer_norm_backward_default_12[0]
        getitem_133 = native_layer_norm_backward_default_12[1]
        getitem_134 = native_layer_norm_backward_default_12[2];  native_layer_norm_backward_default_12 = None
        new_empty_default_4 = torch.ops.aten.new_empty.default(getitem_132, [4063232]);  getitem_132 = None
        zero__default_4 = torch.ops.aten.zero_.default(new_empty_default_4);  new_empty_default_4 = None
        as_strided_default_13 = torch.ops.aten.as_strided.default(zero__default_4, [7936, 512], [512, 1], 0);  zero__default_4 = None
        new_empty_strided_default_4 = torch.ops.aten.new_empty_strided.default(as_strided_default_13, [7936, 512], [512, 1])
        copy__default_13 = torch.ops.aten.copy_.default(new_empty_strided_default_4, as_strided_default_13);  new_empty_strided_default_4 = as_strided_default_13 = None
        as_strided_default_14 = torch.ops.aten.as_strided.default(copy__default_13, [256, 31, 512], [15872, 512, 1], 0)
        clone_default_110 = torch.ops.aten.clone.default(as_strided_default_14, memory_format = torch.contiguous_format);  as_strided_default_14 = None
        t_default_261 = torch.ops.aten.t.default(t_default_55);  t_default_55 = None
        mm_default_155 = torch.ops.aten.mm.default(copy__default_13, t_default_261);  t_default_261 = None
        t_default_262 = torch.ops.aten.t.default(copy__default_13)
        mm_default_156 = torch.ops.aten.mm.default(t_default_262, view_default_120);  t_default_262 = view_default_120 = None
        t_default_263 = torch.ops.aten.t.default(mm_default_156);  mm_default_156 = None
        sum_dim_int_list_8 = torch.ops.aten.sum.dim_IntList(copy__default_13, [0], True);  copy__default_13 = None
        view_default_347 = torch.ops.aten.view.default(sum_dim_int_list_8, [512]);  sum_dim_int_list_8 = None
        t_default_264 = torch.ops.aten.t.default(t_default_263);  t_default_263 = None
        view_default_348 = torch.ops.aten.view.default(mm_default_155, [256, 31, 2048]);  mm_default_155 = None
        to_dtype_12 = torch.ops.aten.to.dtype(view_default_348, torch.float32);  view_default_348 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu_default_7, torch.float32);  relu_default_7 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_4, to_dtype_12);  le_scalar_4 = new_zeros_default_4 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        view_default_349 = torch.ops.aten.view.default(to_dtype_14, [7936, 2048]);  to_dtype_14 = None
        t_default_265 = torch.ops.aten.t.default(t_default_54);  t_default_54 = None
        mm_default_157 = torch.ops.aten.mm.default(view_default_349, t_default_265);  t_default_265 = None
        t_default_266 = torch.ops.aten.t.default(view_default_349)
        mm_default_158 = torch.ops.aten.mm.default(t_default_266, view_default_118);  t_default_266 = view_default_118 = None
        t_default_267 = torch.ops.aten.t.default(mm_default_158);  mm_default_158 = None
        sum_dim_int_list_9 = torch.ops.aten.sum.dim_IntList(view_default_349, [0], True);  view_default_349 = None
        view_default_350 = torch.ops.aten.view.default(sum_dim_int_list_9, [2048]);  sum_dim_int_list_9 = None
        t_default_268 = torch.ops.aten.t.default(t_default_267);  t_default_267 = None
        view_default_351 = torch.ops.aten.view.default(mm_default_157, [256, 31, 512]);  mm_default_157 = None
        add_tensor_29 = torch.ops.aten.add.Tensor(clone_default_110, view_default_351);  clone_default_110 = view_default_351 = None
        native_layer_norm_backward_default_13 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_29, add__tensor_16, [512], getitem_55, getitem_56, primals_23, primals_22, [True, True, True]);  add_tensor_29 = add__tensor_16 = getitem_55 = getitem_56 = primals_23 = primals_22 = None
        getitem_135 = native_layer_norm_backward_default_13[0]
        getitem_136 = native_layer_norm_backward_default_13[1]
        getitem_137 = native_layer_norm_backward_default_13[2];  native_layer_norm_backward_default_13 = None
        view_default_352 = torch.ops.aten.view.default(getitem_135, [7936, 512])
        t_default_269 = torch.ops.aten.t.default(view_default_352)
        mm_default_159 = torch.ops.aten.mm.default(t_default_269, view_default_117);  t_default_269 = view_default_117 = None
        t_default_270 = torch.ops.aten.t.default(mm_default_159);  mm_default_159 = None
        t_default_271 = torch.ops.aten.t.default(t_default_53);  t_default_53 = None
        mm_default_160 = torch.ops.aten.mm.default(view_default_352, t_default_271);  view_default_352 = t_default_271 = None
        view_default_353 = torch.ops.aten.view.default(mm_default_160, [256, 31, 512]);  mm_default_160 = None
        t_default_272 = torch.ops.aten.t.default(t_default_270);  t_default_270 = None
        view_default_354 = torch.ops.aten.view.default(view_default_353, [256, 31, 8, 64]);  view_default_353 = None
        transpose_int_162 = torch.ops.aten.transpose.int(view_default_354, 1, 2);  view_default_354 = None
        clone_default_111 = torch.ops.aten.clone.default(transpose_int_162, memory_format = torch.contiguous_format);  transpose_int_162 = None
        _unsafe_view_default_195 = torch.ops.aten._unsafe_view.default(clone_default_111, [2048, 31, 64]);  clone_default_111 = None
        transpose_int_163 = torch.ops.aten.transpose.int(view_default_115, 1, 2);  view_default_115 = None
        bmm_default_68 = torch.ops.aten.bmm.default(transpose_int_163, _unsafe_view_default_195);  transpose_int_163 = None
        transpose_int_164 = torch.ops.aten.transpose.int(_unsafe_view_default_87, 1, 2);  _unsafe_view_default_87 = None
        bmm_default_69 = torch.ops.aten.bmm.default(_unsafe_view_default_195, transpose_int_164);  _unsafe_view_default_195 = transpose_int_164 = None
        view_default_355 = torch.ops.aten.view.default(bmm_default_68, [256, 8, 33, 64]);  bmm_default_68 = None
        view_default_356 = torch.ops.aten.view.default(bmm_default_69, [256, 8, 31, 33]);  bmm_default_69 = None
        _softmax_backward_data_default_8 = torch.ops.aten._softmax_backward_data.default(view_default_356, _softmax_default_9, -1, torch.float32);  view_default_356 = _softmax_default_9 = None
        where_scalar_self_26 = torch.ops.aten.where.ScalarSelf(eq_scalar_9, 0.0, _softmax_backward_data_default_8);  eq_scalar_9 = _softmax_backward_data_default_8 = None
        view_default_357 = torch.ops.aten.view.default(where_scalar_self_26, [2048, 31, 33]);  where_scalar_self_26 = None
        transpose_int_165 = torch.ops.aten.transpose.int(_unsafe_view_default_84, 1, 2);  _unsafe_view_default_84 = None
        bmm_default_70 = torch.ops.aten.bmm.default(transpose_int_165, view_default_357);  transpose_int_165 = None
        transpose_int_166 = torch.ops.aten.transpose.int(_unsafe_view_default_85, 1, 2);  _unsafe_view_default_85 = None
        bmm_default_71 = torch.ops.aten.bmm.default(view_default_357, transpose_int_166);  view_default_357 = transpose_int_166 = None
        view_default_358 = torch.ops.aten.view.default(bmm_default_70, [256, 8, 64, 33]);  bmm_default_70 = None
        view_default_359 = torch.ops.aten.view.default(bmm_default_71, [256, 8, 31, 64]);  bmm_default_71 = None
        transpose_int_167 = torch.ops.aten.transpose.int(view_default_358, 2, 3);  view_default_358 = None
        div_tensor_26 = torch.ops.aten.div.Tensor(view_default_359, 8.0);  view_default_359 = None
        transpose_int_168 = torch.ops.aten.transpose.int(view_default_355, 1, 2);  view_default_355 = None
        transpose_int_169 = torch.ops.aten.transpose.int(transpose_int_167, 1, 2);  transpose_int_167 = None
        transpose_int_170 = torch.ops.aten.transpose.int(div_tensor_26, 1, 2);  div_tensor_26 = None
        clone_default_112 = torch.ops.aten.clone.default(transpose_int_168, memory_format = torch.contiguous_format);  transpose_int_168 = None
        _unsafe_view_default_196 = torch.ops.aten._unsafe_view.default(clone_default_112, [256, 33, 512]);  clone_default_112 = None
        view_default_360 = torch.ops.aten.view.default(_unsafe_view_default_196, [8448, 512]);  _unsafe_view_default_196 = None
        t_default_273 = torch.ops.aten.t.default(view_default_360)
        mm_default_161 = torch.ops.aten.mm.default(t_default_273, view_default_113);  t_default_273 = view_default_113 = None
        t_default_274 = torch.ops.aten.t.default(mm_default_161);  mm_default_161 = None
        t_default_275 = torch.ops.aten.t.default(t_default_52);  t_default_52 = None
        mm_default_162 = torch.ops.aten.mm.default(view_default_360, t_default_275);  view_default_360 = t_default_275 = None
        view_default_361 = torch.ops.aten.view.default(mm_default_162, [256, 33, 512]);  mm_default_162 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(add_tensor_24, view_default_361);  add_tensor_24 = view_default_361 = None
        t_default_276 = torch.ops.aten.t.default(t_default_274);  t_default_274 = None
        view_default_362 = torch.ops.aten.view.default(transpose_int_169, [256, 33, 512]);  transpose_int_169 = None
        clone_default_113 = torch.ops.aten.clone.default(view_default_362, memory_format = torch.contiguous_format);  view_default_362 = None
        _unsafe_view_default_197 = torch.ops.aten._unsafe_view.default(clone_default_113, [8448, 512]);  clone_default_113 = None
        t_default_277 = torch.ops.aten.t.default(_unsafe_view_default_197)
        mm_default_163 = torch.ops.aten.mm.default(t_default_277, view_default_111);  t_default_277 = view_default_111 = None
        t_default_278 = torch.ops.aten.t.default(mm_default_163);  mm_default_163 = None
        t_default_279 = torch.ops.aten.t.default(t_default_51);  t_default_51 = None
        mm_default_164 = torch.ops.aten.mm.default(_unsafe_view_default_197, t_default_279);  _unsafe_view_default_197 = t_default_279 = None
        view_default_363 = torch.ops.aten.view.default(mm_default_164, [256, 33, 512]);  mm_default_164 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(add_tensor_30, view_default_363);  add_tensor_30 = view_default_363 = None
        t_default_280 = torch.ops.aten.t.default(t_default_278);  t_default_278 = None
        clone_default_114 = torch.ops.aten.clone.default(transpose_int_170, memory_format = torch.contiguous_format);  transpose_int_170 = None
        _unsafe_view_default_198 = torch.ops.aten._unsafe_view.default(clone_default_114, [256, 31, 512]);  clone_default_114 = None
        view_default_364 = torch.ops.aten.view.default(_unsafe_view_default_198, [7936, 512]);  _unsafe_view_default_198 = None
        t_default_281 = torch.ops.aten.t.default(view_default_364)
        mm_default_165 = torch.ops.aten.mm.default(t_default_281, view_default_109);  t_default_281 = view_default_109 = None
        t_default_282 = torch.ops.aten.t.default(mm_default_165);  mm_default_165 = None
        t_default_283 = torch.ops.aten.t.default(t_default_50);  t_default_50 = None
        mm_default_166 = torch.ops.aten.mm.default(view_default_364, t_default_283);  view_default_364 = t_default_283 = None
        view_default_365 = torch.ops.aten.view.default(mm_default_166, [256, 31, 512]);  mm_default_166 = None
        add_tensor_32 = torch.ops.aten.add.Tensor(getitem_135, view_default_365);  getitem_135 = view_default_365 = None
        t_default_284 = torch.ops.aten.t.default(t_default_282);  t_default_282 = None
        native_layer_norm_backward_default_14 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_32, add__tensor_15, [512], getitem_52, getitem_53, primals_35, primals_34, [True, True, True]);  add_tensor_32 = add__tensor_15 = getitem_52 = getitem_53 = primals_35 = primals_34 = None
        getitem_138 = native_layer_norm_backward_default_14[0]
        getitem_139 = native_layer_norm_backward_default_14[1]
        getitem_140 = native_layer_norm_backward_default_14[2];  native_layer_norm_backward_default_14 = None
        view_default_366 = torch.ops.aten.view.default(getitem_138, [7936, 512])
        t_default_285 = torch.ops.aten.t.default(view_default_366)
        mm_default_167 = torch.ops.aten.mm.default(t_default_285, view_default_108);  t_default_285 = view_default_108 = None
        t_default_286 = torch.ops.aten.t.default(mm_default_167);  mm_default_167 = None
        t_default_287 = torch.ops.aten.t.default(t_default_49);  t_default_49 = None
        mm_default_168 = torch.ops.aten.mm.default(view_default_366, t_default_287);  view_default_366 = t_default_287 = None
        view_default_367 = torch.ops.aten.view.default(mm_default_168, [256, 31, 512]);  mm_default_168 = None
        t_default_288 = torch.ops.aten.t.default(t_default_286);  t_default_286 = None
        view_default_368 = torch.ops.aten.view.default(view_default_367, [256, 31, 8, 64]);  view_default_367 = None
        transpose_int_171 = torch.ops.aten.transpose.int(view_default_368, 1, 2);  view_default_368 = None
        clone_default_115 = torch.ops.aten.clone.default(transpose_int_171, memory_format = torch.contiguous_format);  transpose_int_171 = None
        _unsafe_view_default_199 = torch.ops.aten._unsafe_view.default(clone_default_115, [2048, 31, 64]);  clone_default_115 = None
        transpose_int_172 = torch.ops.aten.transpose.int(view_default_106, 1, 2);  view_default_106 = None
        bmm_default_72 = torch.ops.aten.bmm.default(transpose_int_172, _unsafe_view_default_199);  transpose_int_172 = None
        transpose_int_173 = torch.ops.aten.transpose.int(_unsafe_view_default_78, 1, 2);  _unsafe_view_default_78 = None
        bmm_default_73 = torch.ops.aten.bmm.default(_unsafe_view_default_199, transpose_int_173);  _unsafe_view_default_199 = transpose_int_173 = None
        view_default_369 = torch.ops.aten.view.default(bmm_default_72, [256, 8, 31, 64]);  bmm_default_72 = None
        view_default_370 = torch.ops.aten.view.default(bmm_default_73, [256, 8, 31, 31]);  bmm_default_73 = None
        _softmax_backward_data_default_9 = torch.ops.aten._softmax_backward_data.default(view_default_370, _softmax_default_8, -1, torch.float32);  view_default_370 = _softmax_default_8 = None
        where_scalar_self_27 = torch.ops.aten.where.ScalarSelf(eq_scalar_8, 0.0, _softmax_backward_data_default_9);  eq_scalar_8 = _softmax_backward_data_default_9 = None
        view_default_371 = torch.ops.aten.view.default(where_scalar_self_27, [2048, 31, 31]);  where_scalar_self_27 = None
        transpose_int_174 = torch.ops.aten.transpose.int(_unsafe_view_default_75, 1, 2);  _unsafe_view_default_75 = None
        bmm_default_74 = torch.ops.aten.bmm.default(transpose_int_174, view_default_371);  transpose_int_174 = None
        transpose_int_175 = torch.ops.aten.transpose.int(_unsafe_view_default_76, 1, 2);  _unsafe_view_default_76 = None
        bmm_default_75 = torch.ops.aten.bmm.default(view_default_371, transpose_int_175);  view_default_371 = transpose_int_175 = None
        view_default_372 = torch.ops.aten.view.default(bmm_default_74, [256, 8, 64, 31]);  bmm_default_74 = None
        view_default_373 = torch.ops.aten.view.default(bmm_default_75, [256, 8, 31, 64]);  bmm_default_75 = None
        transpose_int_176 = torch.ops.aten.transpose.int(view_default_372, 2, 3);  view_default_372 = None
        div_tensor_27 = torch.ops.aten.div.Tensor(view_default_373, 8.0);  view_default_373 = None
        transpose_int_177 = torch.ops.aten.transpose.int(view_default_369, 1, 2);  view_default_369 = None
        transpose_int_178 = torch.ops.aten.transpose.int(transpose_int_176, 1, 2);  transpose_int_176 = None
        transpose_int_179 = torch.ops.aten.transpose.int(div_tensor_27, 1, 2);  div_tensor_27 = None
        clone_default_116 = torch.ops.aten.clone.default(transpose_int_177, memory_format = torch.contiguous_format);  transpose_int_177 = None
        _unsafe_view_default_200 = torch.ops.aten._unsafe_view.default(clone_default_116, [256, 31, 512]);  clone_default_116 = None
        view_default_374 = torch.ops.aten.view.default(_unsafe_view_default_200, [7936, 512]);  _unsafe_view_default_200 = None
        t_default_289 = torch.ops.aten.t.default(view_default_374)
        mm_default_169 = torch.ops.aten.mm.default(t_default_289, view_default_104);  t_default_289 = view_default_104 = None
        t_default_290 = torch.ops.aten.t.default(mm_default_169);  mm_default_169 = None
        t_default_291 = torch.ops.aten.t.default(t_default_48);  t_default_48 = None
        mm_default_170 = torch.ops.aten.mm.default(view_default_374, t_default_291);  view_default_374 = t_default_291 = None
        view_default_375 = torch.ops.aten.view.default(mm_default_170, [256, 31, 512]);  mm_default_170 = None
        add_tensor_33 = torch.ops.aten.add.Tensor(getitem_138, view_default_375);  getitem_138 = view_default_375 = None
        t_default_292 = torch.ops.aten.t.default(t_default_290);  t_default_290 = None
        view_default_376 = torch.ops.aten.view.default(transpose_int_178, [256, 31, 512]);  transpose_int_178 = None
        clone_default_117 = torch.ops.aten.clone.default(view_default_376, memory_format = torch.contiguous_format);  view_default_376 = None
        _unsafe_view_default_201 = torch.ops.aten._unsafe_view.default(clone_default_117, [7936, 512]);  clone_default_117 = None
        t_default_293 = torch.ops.aten.t.default(_unsafe_view_default_201)
        mm_default_171 = torch.ops.aten.mm.default(t_default_293, view_default_102);  t_default_293 = view_default_102 = None
        t_default_294 = torch.ops.aten.t.default(mm_default_171);  mm_default_171 = None
        t_default_295 = torch.ops.aten.t.default(t_default_47);  t_default_47 = None
        mm_default_172 = torch.ops.aten.mm.default(_unsafe_view_default_201, t_default_295);  _unsafe_view_default_201 = t_default_295 = None
        view_default_377 = torch.ops.aten.view.default(mm_default_172, [256, 31, 512]);  mm_default_172 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(add_tensor_33, view_default_377);  add_tensor_33 = view_default_377 = None
        t_default_296 = torch.ops.aten.t.default(t_default_294);  t_default_294 = None
        clone_default_118 = torch.ops.aten.clone.default(transpose_int_179, memory_format = torch.contiguous_format);  transpose_int_179 = None
        _unsafe_view_default_202 = torch.ops.aten._unsafe_view.default(clone_default_118, [256, 31, 512]);  clone_default_118 = None
        view_default_378 = torch.ops.aten.view.default(_unsafe_view_default_202, [7936, 512]);  _unsafe_view_default_202 = None
        t_default_297 = torch.ops.aten.t.default(view_default_378)
        mm_default_173 = torch.ops.aten.mm.default(t_default_297, view_default_100);  t_default_297 = view_default_100 = None
        t_default_298 = torch.ops.aten.t.default(mm_default_173);  mm_default_173 = None
        t_default_299 = torch.ops.aten.t.default(t_default_46);  t_default_46 = None
        mm_default_174 = torch.ops.aten.mm.default(view_default_378, t_default_299);  view_default_378 = t_default_299 = None
        view_default_379 = torch.ops.aten.view.default(mm_default_174, [256, 31, 512]);  mm_default_174 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(add_tensor_34, view_default_379);  add_tensor_34 = view_default_379 = None
        t_default_300 = torch.ops.aten.t.default(t_default_298);  t_default_298 = None
        native_layer_norm_backward_default_15 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_35, add__tensor_14, [512], getitem_49, getitem_50, primals_10, primals_9, [True, True, True]);  add_tensor_35 = add__tensor_14 = getitem_49 = getitem_50 = primals_10 = primals_9 = None
        getitem_141 = native_layer_norm_backward_default_15[0]
        getitem_142 = native_layer_norm_backward_default_15[1]
        getitem_143 = native_layer_norm_backward_default_15[2];  native_layer_norm_backward_default_15 = None
        new_empty_default_5 = torch.ops.aten.new_empty.default(getitem_141, [4063232]);  getitem_141 = None
        zero__default_5 = torch.ops.aten.zero_.default(new_empty_default_5);  new_empty_default_5 = None
        as_strided_default_16 = torch.ops.aten.as_strided.default(zero__default_5, [7936, 512], [512, 1], 0);  zero__default_5 = None
        new_empty_strided_default_5 = torch.ops.aten.new_empty_strided.default(as_strided_default_16, [7936, 512], [512, 1])
        copy__default_16 = torch.ops.aten.copy_.default(new_empty_strided_default_5, as_strided_default_16);  new_empty_strided_default_5 = as_strided_default_16 = None
        as_strided_default_17 = torch.ops.aten.as_strided.default(copy__default_16, [256, 31, 512], [15872, 512, 1], 0)
        clone_default_119 = torch.ops.aten.clone.default(as_strided_default_17, memory_format = torch.contiguous_format);  as_strided_default_17 = None
        t_default_301 = torch.ops.aten.t.default(t_default_45);  t_default_45 = None
        mm_default_175 = torch.ops.aten.mm.default(copy__default_16, t_default_301);  t_default_301 = None
        t_default_302 = torch.ops.aten.t.default(copy__default_16)
        mm_default_176 = torch.ops.aten.mm.default(t_default_302, view_default_98);  t_default_302 = view_default_98 = None
        t_default_303 = torch.ops.aten.t.default(mm_default_176);  mm_default_176 = None
        sum_dim_int_list_10 = torch.ops.aten.sum.dim_IntList(copy__default_16, [0], True);  copy__default_16 = None
        view_default_380 = torch.ops.aten.view.default(sum_dim_int_list_10, [512]);  sum_dim_int_list_10 = None
        t_default_304 = torch.ops.aten.t.default(t_default_303);  t_default_303 = None
        view_default_381 = torch.ops.aten.view.default(mm_default_175, [256, 31, 2048]);  mm_default_175 = None
        to_dtype_15 = torch.ops.aten.to.dtype(view_default_381, torch.float32);  view_default_381 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu_default_6, torch.float32);  relu_default_6 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_5 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_5, to_dtype_15);  le_scalar_5 = new_zeros_default_5 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        view_default_382 = torch.ops.aten.view.default(to_dtype_17, [7936, 2048]);  to_dtype_17 = None
        t_default_305 = torch.ops.aten.t.default(t_default_44);  t_default_44 = None
        mm_default_177 = torch.ops.aten.mm.default(view_default_382, t_default_305);  t_default_305 = None
        t_default_306 = torch.ops.aten.t.default(view_default_382)
        mm_default_178 = torch.ops.aten.mm.default(t_default_306, view_default_96);  t_default_306 = view_default_96 = None
        t_default_307 = torch.ops.aten.t.default(mm_default_178);  mm_default_178 = None
        sum_dim_int_list_11 = torch.ops.aten.sum.dim_IntList(view_default_382, [0], True);  view_default_382 = None
        view_default_383 = torch.ops.aten.view.default(sum_dim_int_list_11, [2048]);  sum_dim_int_list_11 = None
        t_default_308 = torch.ops.aten.t.default(t_default_307);  t_default_307 = None
        view_default_384 = torch.ops.aten.view.default(mm_default_177, [256, 31, 512]);  mm_default_177 = None
        add_tensor_36 = torch.ops.aten.add.Tensor(clone_default_119, view_default_384);  clone_default_119 = view_default_384 = None
        native_layer_norm_backward_default_16 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_36, add__tensor_13, [512], getitem_46, getitem_47, primals_5, primals_4, [True, True, True]);  add_tensor_36 = add__tensor_13 = getitem_46 = getitem_47 = primals_5 = primals_4 = None
        getitem_144 = native_layer_norm_backward_default_16[0]
        getitem_145 = native_layer_norm_backward_default_16[1]
        getitem_146 = native_layer_norm_backward_default_16[2];  native_layer_norm_backward_default_16 = None
        view_default_385 = torch.ops.aten.view.default(getitem_144, [7936, 512])
        t_default_309 = torch.ops.aten.t.default(view_default_385)
        mm_default_179 = torch.ops.aten.mm.default(t_default_309, view_default_95);  t_default_309 = view_default_95 = None
        t_default_310 = torch.ops.aten.t.default(mm_default_179);  mm_default_179 = None
        t_default_311 = torch.ops.aten.t.default(t_default_43);  t_default_43 = None
        mm_default_180 = torch.ops.aten.mm.default(view_default_385, t_default_311);  view_default_385 = t_default_311 = None
        view_default_386 = torch.ops.aten.view.default(mm_default_180, [256, 31, 512]);  mm_default_180 = None
        t_default_312 = torch.ops.aten.t.default(t_default_310);  t_default_310 = None
        view_default_387 = torch.ops.aten.view.default(view_default_386, [256, 31, 8, 64]);  view_default_386 = None
        transpose_int_180 = torch.ops.aten.transpose.int(view_default_387, 1, 2);  view_default_387 = None
        clone_default_120 = torch.ops.aten.clone.default(transpose_int_180, memory_format = torch.contiguous_format);  transpose_int_180 = None
        _unsafe_view_default_203 = torch.ops.aten._unsafe_view.default(clone_default_120, [2048, 31, 64]);  clone_default_120 = None
        transpose_int_181 = torch.ops.aten.transpose.int(view_default_93, 1, 2);  view_default_93 = None
        bmm_default_76 = torch.ops.aten.bmm.default(transpose_int_181, _unsafe_view_default_203);  transpose_int_181 = None
        transpose_int_182 = torch.ops.aten.transpose.int(_unsafe_view_default_69, 1, 2);  _unsafe_view_default_69 = None
        bmm_default_77 = torch.ops.aten.bmm.default(_unsafe_view_default_203, transpose_int_182);  _unsafe_view_default_203 = transpose_int_182 = None
        view_default_388 = torch.ops.aten.view.default(bmm_default_76, [256, 8, 33, 64]);  bmm_default_76 = None
        view_default_389 = torch.ops.aten.view.default(bmm_default_77, [256, 8, 31, 33]);  bmm_default_77 = None
        _softmax_backward_data_default_10 = torch.ops.aten._softmax_backward_data.default(view_default_389, _softmax_default_7, -1, torch.float32);  view_default_389 = _softmax_default_7 = None
        where_scalar_self_28 = torch.ops.aten.where.ScalarSelf(eq_scalar_7, 0.0, _softmax_backward_data_default_10);  eq_scalar_7 = _softmax_backward_data_default_10 = None
        view_default_390 = torch.ops.aten.view.default(where_scalar_self_28, [2048, 31, 33]);  where_scalar_self_28 = None
        transpose_int_183 = torch.ops.aten.transpose.int(_unsafe_view_default_66, 1, 2);  _unsafe_view_default_66 = None
        bmm_default_78 = torch.ops.aten.bmm.default(transpose_int_183, view_default_390);  transpose_int_183 = None
        transpose_int_184 = torch.ops.aten.transpose.int(_unsafe_view_default_67, 1, 2);  _unsafe_view_default_67 = None
        bmm_default_79 = torch.ops.aten.bmm.default(view_default_390, transpose_int_184);  view_default_390 = transpose_int_184 = None
        view_default_391 = torch.ops.aten.view.default(bmm_default_78, [256, 8, 64, 33]);  bmm_default_78 = None
        view_default_392 = torch.ops.aten.view.default(bmm_default_79, [256, 8, 31, 64]);  bmm_default_79 = None
        transpose_int_185 = torch.ops.aten.transpose.int(view_default_391, 2, 3);  view_default_391 = None
        div_tensor_28 = torch.ops.aten.div.Tensor(view_default_392, 8.0);  view_default_392 = None
        transpose_int_186 = torch.ops.aten.transpose.int(view_default_388, 1, 2);  view_default_388 = None
        transpose_int_187 = torch.ops.aten.transpose.int(transpose_int_185, 1, 2);  transpose_int_185 = None
        transpose_int_188 = torch.ops.aten.transpose.int(div_tensor_28, 1, 2);  div_tensor_28 = None
        clone_default_121 = torch.ops.aten.clone.default(transpose_int_186, memory_format = torch.contiguous_format);  transpose_int_186 = None
        _unsafe_view_default_204 = torch.ops.aten._unsafe_view.default(clone_default_121, [256, 33, 512]);  clone_default_121 = None
        view_default_393 = torch.ops.aten.view.default(_unsafe_view_default_204, [8448, 512]);  _unsafe_view_default_204 = None
        t_default_313 = torch.ops.aten.t.default(view_default_393)
        mm_default_181 = torch.ops.aten.mm.default(t_default_313, view_default_91);  t_default_313 = view_default_91 = None
        t_default_314 = torch.ops.aten.t.default(mm_default_181);  mm_default_181 = None
        t_default_315 = torch.ops.aten.t.default(t_default_42);  t_default_42 = None
        mm_default_182 = torch.ops.aten.mm.default(view_default_393, t_default_315);  view_default_393 = t_default_315 = None
        view_default_394 = torch.ops.aten.view.default(mm_default_182, [256, 33, 512]);  mm_default_182 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(add_tensor_31, view_default_394);  add_tensor_31 = view_default_394 = None
        t_default_316 = torch.ops.aten.t.default(t_default_314);  t_default_314 = None
        view_default_395 = torch.ops.aten.view.default(transpose_int_187, [256, 33, 512]);  transpose_int_187 = None
        clone_default_122 = torch.ops.aten.clone.default(view_default_395, memory_format = torch.contiguous_format);  view_default_395 = None
        _unsafe_view_default_205 = torch.ops.aten._unsafe_view.default(clone_default_122, [8448, 512]);  clone_default_122 = None
        t_default_317 = torch.ops.aten.t.default(_unsafe_view_default_205)
        mm_default_183 = torch.ops.aten.mm.default(t_default_317, view_default_89);  t_default_317 = view_default_89 = None
        t_default_318 = torch.ops.aten.t.default(mm_default_183);  mm_default_183 = None
        t_default_319 = torch.ops.aten.t.default(t_default_41);  t_default_41 = None
        mm_default_184 = torch.ops.aten.mm.default(_unsafe_view_default_205, t_default_319);  _unsafe_view_default_205 = t_default_319 = None
        view_default_396 = torch.ops.aten.view.default(mm_default_184, [256, 33, 512]);  mm_default_184 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(add_tensor_37, view_default_396);  add_tensor_37 = view_default_396 = None
        t_default_320 = torch.ops.aten.t.default(t_default_318);  t_default_318 = None
        clone_default_123 = torch.ops.aten.clone.default(transpose_int_188, memory_format = torch.contiguous_format);  transpose_int_188 = None
        _unsafe_view_default_206 = torch.ops.aten._unsafe_view.default(clone_default_123, [256, 31, 512]);  clone_default_123 = None
        view_default_397 = torch.ops.aten.view.default(_unsafe_view_default_206, [7936, 512]);  _unsafe_view_default_206 = None
        t_default_321 = torch.ops.aten.t.default(view_default_397)
        mm_default_185 = torch.ops.aten.mm.default(t_default_321, view_default_87);  t_default_321 = view_default_87 = None
        t_default_322 = torch.ops.aten.t.default(mm_default_185);  mm_default_185 = None
        t_default_323 = torch.ops.aten.t.default(t_default_40);  t_default_40 = None
        mm_default_186 = torch.ops.aten.mm.default(view_default_397, t_default_323);  view_default_397 = t_default_323 = None
        view_default_398 = torch.ops.aten.view.default(mm_default_186, [256, 31, 512]);  mm_default_186 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(getitem_144, view_default_398);  getitem_144 = view_default_398 = None
        t_default_324 = torch.ops.aten.t.default(t_default_322);  t_default_322 = None
        native_layer_norm_backward_default_17 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_39, add__tensor_12, [512], getitem_43, getitem_44, primals_17, primals_16, [True, True, True]);  add_tensor_39 = add__tensor_12 = getitem_43 = getitem_44 = primals_17 = primals_16 = None
        getitem_147 = native_layer_norm_backward_default_17[0]
        getitem_148 = native_layer_norm_backward_default_17[1]
        getitem_149 = native_layer_norm_backward_default_17[2];  native_layer_norm_backward_default_17 = None
        view_default_399 = torch.ops.aten.view.default(getitem_147, [7936, 512])
        t_default_325 = torch.ops.aten.t.default(view_default_399)
        mm_default_187 = torch.ops.aten.mm.default(t_default_325, view_default_86);  t_default_325 = view_default_86 = None
        t_default_326 = torch.ops.aten.t.default(mm_default_187);  mm_default_187 = None
        t_default_327 = torch.ops.aten.t.default(t_default_39);  t_default_39 = None
        mm_default_188 = torch.ops.aten.mm.default(view_default_399, t_default_327);  view_default_399 = t_default_327 = None
        view_default_400 = torch.ops.aten.view.default(mm_default_188, [256, 31, 512]);  mm_default_188 = None
        t_default_328 = torch.ops.aten.t.default(t_default_326);  t_default_326 = None
        view_default_401 = torch.ops.aten.view.default(view_default_400, [256, 31, 8, 64]);  view_default_400 = None
        transpose_int_189 = torch.ops.aten.transpose.int(view_default_401, 1, 2);  view_default_401 = None
        clone_default_124 = torch.ops.aten.clone.default(transpose_int_189, memory_format = torch.contiguous_format);  transpose_int_189 = None
        _unsafe_view_default_207 = torch.ops.aten._unsafe_view.default(clone_default_124, [2048, 31, 64]);  clone_default_124 = None
        transpose_int_190 = torch.ops.aten.transpose.int(view_default_84, 1, 2);  view_default_84 = None
        bmm_default_80 = torch.ops.aten.bmm.default(transpose_int_190, _unsafe_view_default_207);  transpose_int_190 = None
        transpose_int_191 = torch.ops.aten.transpose.int(_unsafe_view_default_60, 1, 2);  _unsafe_view_default_60 = None
        bmm_default_81 = torch.ops.aten.bmm.default(_unsafe_view_default_207, transpose_int_191);  _unsafe_view_default_207 = transpose_int_191 = None
        view_default_402 = torch.ops.aten.view.default(bmm_default_80, [256, 8, 31, 64]);  bmm_default_80 = None
        view_default_403 = torch.ops.aten.view.default(bmm_default_81, [256, 8, 31, 31]);  bmm_default_81 = None
        _softmax_backward_data_default_11 = torch.ops.aten._softmax_backward_data.default(view_default_403, _softmax_default_6, -1, torch.float32);  view_default_403 = _softmax_default_6 = None
        where_scalar_self_29 = torch.ops.aten.where.ScalarSelf(eq_scalar_6, 0.0, _softmax_backward_data_default_11);  eq_scalar_6 = _softmax_backward_data_default_11 = None
        view_default_404 = torch.ops.aten.view.default(where_scalar_self_29, [2048, 31, 31]);  where_scalar_self_29 = None
        transpose_int_192 = torch.ops.aten.transpose.int(_unsafe_view_default_57, 1, 2);  _unsafe_view_default_57 = None
        bmm_default_82 = torch.ops.aten.bmm.default(transpose_int_192, view_default_404);  transpose_int_192 = None
        transpose_int_193 = torch.ops.aten.transpose.int(_unsafe_view_default_58, 1, 2);  _unsafe_view_default_58 = None
        bmm_default_83 = torch.ops.aten.bmm.default(view_default_404, transpose_int_193);  view_default_404 = transpose_int_193 = None
        view_default_405 = torch.ops.aten.view.default(bmm_default_82, [256, 8, 64, 31]);  bmm_default_82 = None
        view_default_406 = torch.ops.aten.view.default(bmm_default_83, [256, 8, 31, 64]);  bmm_default_83 = None
        transpose_int_194 = torch.ops.aten.transpose.int(view_default_405, 2, 3);  view_default_405 = None
        div_tensor_29 = torch.ops.aten.div.Tensor(view_default_406, 8.0);  view_default_406 = None
        transpose_int_195 = torch.ops.aten.transpose.int(view_default_402, 1, 2);  view_default_402 = None
        transpose_int_196 = torch.ops.aten.transpose.int(transpose_int_194, 1, 2);  transpose_int_194 = None
        transpose_int_197 = torch.ops.aten.transpose.int(div_tensor_29, 1, 2);  div_tensor_29 = None
        clone_default_125 = torch.ops.aten.clone.default(transpose_int_195, memory_format = torch.contiguous_format);  transpose_int_195 = None
        _unsafe_view_default_208 = torch.ops.aten._unsafe_view.default(clone_default_125, [256, 31, 512]);  clone_default_125 = None
        view_default_407 = torch.ops.aten.view.default(_unsafe_view_default_208, [7936, 512]);  _unsafe_view_default_208 = None
        t_default_329 = torch.ops.aten.t.default(view_default_407)
        mm_default_189 = torch.ops.aten.mm.default(t_default_329, view_default_82);  t_default_329 = view_default_82 = None
        t_default_330 = torch.ops.aten.t.default(mm_default_189);  mm_default_189 = None
        t_default_331 = torch.ops.aten.t.default(t_default_38);  t_default_38 = None
        mm_default_190 = torch.ops.aten.mm.default(view_default_407, t_default_331);  view_default_407 = t_default_331 = None
        view_default_408 = torch.ops.aten.view.default(mm_default_190, [256, 31, 512]);  mm_default_190 = None
        add_tensor_40 = torch.ops.aten.add.Tensor(getitem_147, view_default_408);  getitem_147 = view_default_408 = None
        t_default_332 = torch.ops.aten.t.default(t_default_330);  t_default_330 = None
        view_default_409 = torch.ops.aten.view.default(transpose_int_196, [256, 31, 512]);  transpose_int_196 = None
        clone_default_126 = torch.ops.aten.clone.default(view_default_409, memory_format = torch.contiguous_format);  view_default_409 = None
        _unsafe_view_default_209 = torch.ops.aten._unsafe_view.default(clone_default_126, [7936, 512]);  clone_default_126 = None
        t_default_333 = torch.ops.aten.t.default(_unsafe_view_default_209)
        mm_default_191 = torch.ops.aten.mm.default(t_default_333, view_default_80);  t_default_333 = view_default_80 = None
        t_default_334 = torch.ops.aten.t.default(mm_default_191);  mm_default_191 = None
        t_default_335 = torch.ops.aten.t.default(t_default_37);  t_default_37 = None
        mm_default_192 = torch.ops.aten.mm.default(_unsafe_view_default_209, t_default_335);  _unsafe_view_default_209 = t_default_335 = None
        view_default_410 = torch.ops.aten.view.default(mm_default_192, [256, 31, 512]);  mm_default_192 = None
        add_tensor_41 = torch.ops.aten.add.Tensor(add_tensor_40, view_default_410);  add_tensor_40 = view_default_410 = None
        t_default_336 = torch.ops.aten.t.default(t_default_334);  t_default_334 = None
        clone_default_127 = torch.ops.aten.clone.default(transpose_int_197, memory_format = torch.contiguous_format);  transpose_int_197 = None
        _unsafe_view_default_210 = torch.ops.aten._unsafe_view.default(clone_default_127, [256, 31, 512]);  clone_default_127 = None
        view_default_411 = torch.ops.aten.view.default(_unsafe_view_default_210, [7936, 512]);  _unsafe_view_default_210 = None
        t_default_337 = torch.ops.aten.t.default(view_default_411)
        mm_default_193 = torch.ops.aten.mm.default(t_default_337, view_default_78);  t_default_337 = view_default_78 = None
        t_default_338 = torch.ops.aten.t.default(mm_default_193);  mm_default_193 = None
        t_default_339 = torch.ops.aten.t.default(t_default_36);  t_default_36 = None
        mm_default_194 = torch.ops.aten.mm.default(view_default_411, t_default_339);  view_default_411 = t_default_339 = None
        view_default_412 = torch.ops.aten.view.default(mm_default_194, [256, 31, 512]);  mm_default_194 = None
        add_tensor_42 = torch.ops.aten.add.Tensor(add_tensor_41, view_default_412);  add_tensor_41 = view_default_412 = None
        t_default_340 = torch.ops.aten.t.default(t_default_338);  t_default_338 = None
        native_layer_norm_backward_default_18 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_42, add_tensor_1, [512], getitem_40, getitem_41, primals_2, primals_1, [True, True, True]);  add_tensor_42 = add_tensor_1 = getitem_40 = getitem_41 = primals_2 = primals_1 = None
        getitem_150 = native_layer_norm_backward_default_18[0]
        getitem_151 = native_layer_norm_backward_default_18[1]
        getitem_152 = native_layer_norm_backward_default_18[2];  native_layer_norm_backward_default_18 = None
        embedding_dense_backward_default = torch.ops.aten.embedding_dense_backward.default(getitem_150, primals_191, 9521, 1, False);  getitem_150 = primals_191 = None
        native_layer_norm_backward_default_19 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_38, add__tensor_11, [512], getitem_37, getitem_38, primals_176, primals_175, [True, True, True]);  add_tensor_38 = add__tensor_11 = getitem_37 = getitem_38 = primals_176 = primals_175 = None
        getitem_153 = native_layer_norm_backward_default_19[0]
        getitem_154 = native_layer_norm_backward_default_19[1]
        getitem_155 = native_layer_norm_backward_default_19[2];  native_layer_norm_backward_default_19 = None
        new_empty_default_6 = torch.ops.aten.new_empty.default(getitem_153, [4325376]);  getitem_153 = None
        zero__default_6 = torch.ops.aten.zero_.default(new_empty_default_6);  new_empty_default_6 = None
        as_strided_default_19 = torch.ops.aten.as_strided.default(zero__default_6, [8448, 512], [512, 1], 0);  zero__default_6 = None
        new_empty_strided_default_6 = torch.ops.aten.new_empty_strided.default(as_strided_default_19, [8448, 512], [512, 1])
        copy__default_19 = torch.ops.aten.copy_.default(new_empty_strided_default_6, as_strided_default_19);  new_empty_strided_default_6 = as_strided_default_19 = None
        as_strided_default_20 = torch.ops.aten.as_strided.default(copy__default_19, [256, 33, 512], [16896, 512, 1], 0)
        clone_default_128 = torch.ops.aten.clone.default(as_strided_default_20, memory_format = torch.contiguous_format);  as_strided_default_20 = None
        t_default_341 = torch.ops.aten.t.default(t_default_35);  t_default_35 = None
        mm_default_195 = torch.ops.aten.mm.default(copy__default_19, t_default_341);  t_default_341 = None
        t_default_342 = torch.ops.aten.t.default(copy__default_19)
        mm_default_196 = torch.ops.aten.mm.default(t_default_342, view_default_76);  t_default_342 = view_default_76 = None
        t_default_343 = torch.ops.aten.t.default(mm_default_196);  mm_default_196 = None
        sum_dim_int_list_12 = torch.ops.aten.sum.dim_IntList(copy__default_19, [0], True);  copy__default_19 = None
        view_default_413 = torch.ops.aten.view.default(sum_dim_int_list_12, [512]);  sum_dim_int_list_12 = None
        t_default_344 = torch.ops.aten.t.default(t_default_343);  t_default_343 = None
        view_default_414 = torch.ops.aten.view.default(mm_default_195, [256, 33, 2048]);  mm_default_195 = None
        to_dtype_18 = torch.ops.aten.to.dtype(view_default_414, torch.float32);  view_default_414 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu_default_5, torch.float32);  relu_default_5 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_6, to_dtype_18);  le_scalar_6 = new_zeros_default_6 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        view_default_415 = torch.ops.aten.view.default(to_dtype_20, [8448, 2048]);  to_dtype_20 = None
        t_default_345 = torch.ops.aten.t.default(t_default_34);  t_default_34 = None
        mm_default_197 = torch.ops.aten.mm.default(view_default_415, t_default_345);  t_default_345 = None
        t_default_346 = torch.ops.aten.t.default(view_default_415)
        mm_default_198 = torch.ops.aten.mm.default(t_default_346, view_default_74);  t_default_346 = view_default_74 = None
        t_default_347 = torch.ops.aten.t.default(mm_default_198);  mm_default_198 = None
        sum_dim_int_list_13 = torch.ops.aten.sum.dim_IntList(view_default_415, [0], True);  view_default_415 = None
        view_default_416 = torch.ops.aten.view.default(sum_dim_int_list_13, [2048]);  sum_dim_int_list_13 = None
        t_default_348 = torch.ops.aten.t.default(t_default_347);  t_default_347 = None
        view_default_417 = torch.ops.aten.view.default(mm_default_197, [256, 33, 512]);  mm_default_197 = None
        add_tensor_43 = torch.ops.aten.add.Tensor(clone_default_128, view_default_417);  clone_default_128 = view_default_417 = None
        native_layer_norm_backward_default_20 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_43, add__tensor_10, [512], getitem_34, getitem_35, primals_183, primals_182, [True, True, True]);  add_tensor_43 = add__tensor_10 = getitem_34 = getitem_35 = primals_183 = primals_182 = None
        getitem_156 = native_layer_norm_backward_default_20[0]
        getitem_157 = native_layer_norm_backward_default_20[1]
        getitem_158 = native_layer_norm_backward_default_20[2];  native_layer_norm_backward_default_20 = None
        view_default_418 = torch.ops.aten.view.default(getitem_156, [8448, 512])
        t_default_349 = torch.ops.aten.t.default(view_default_418)
        mm_default_199 = torch.ops.aten.mm.default(t_default_349, view_default_73);  t_default_349 = view_default_73 = None
        t_default_350 = torch.ops.aten.t.default(mm_default_199);  mm_default_199 = None
        t_default_351 = torch.ops.aten.t.default(t_default_33);  t_default_33 = None
        mm_default_200 = torch.ops.aten.mm.default(view_default_418, t_default_351);  view_default_418 = t_default_351 = None
        view_default_419 = torch.ops.aten.view.default(mm_default_200, [256, 33, 512]);  mm_default_200 = None
        t_default_352 = torch.ops.aten.t.default(t_default_350);  t_default_350 = None
        view_default_420 = torch.ops.aten.view.default(view_default_419, [256, 33, 8, 64]);  view_default_419 = None
        transpose_int_198 = torch.ops.aten.transpose.int(view_default_420, 1, 2);  view_default_420 = None
        clone_default_129 = torch.ops.aten.clone.default(transpose_int_198, memory_format = torch.contiguous_format);  transpose_int_198 = None
        _unsafe_view_default_211 = torch.ops.aten._unsafe_view.default(clone_default_129, [2048, 33, 64]);  clone_default_129 = None
        transpose_int_199 = torch.ops.aten.transpose.int(view_default_71, 1, 2);  view_default_71 = None
        bmm_default_84 = torch.ops.aten.bmm.default(transpose_int_199, _unsafe_view_default_211);  transpose_int_199 = None
        transpose_int_200 = torch.ops.aten.transpose.int(_unsafe_view_default_51, 1, 2);  _unsafe_view_default_51 = None
        bmm_default_85 = torch.ops.aten.bmm.default(_unsafe_view_default_211, transpose_int_200);  _unsafe_view_default_211 = transpose_int_200 = None
        view_default_421 = torch.ops.aten.view.default(bmm_default_84, [256, 8, 33, 64]);  bmm_default_84 = None
        view_default_422 = torch.ops.aten.view.default(bmm_default_85, [256, 8, 33, 33]);  bmm_default_85 = None
        _softmax_backward_data_default_12 = torch.ops.aten._softmax_backward_data.default(view_default_422, _softmax_default_5, -1, torch.float32);  view_default_422 = _softmax_default_5 = None
        where_scalar_self_30 = torch.ops.aten.where.ScalarSelf(eq_scalar_5, 0.0, _softmax_backward_data_default_12);  eq_scalar_5 = _softmax_backward_data_default_12 = None
        view_default_423 = torch.ops.aten.view.default(where_scalar_self_30, [2048, 33, 33]);  where_scalar_self_30 = None
        transpose_int_201 = torch.ops.aten.transpose.int(_unsafe_view_default_48, 1, 2);  _unsafe_view_default_48 = None
        bmm_default_86 = torch.ops.aten.bmm.default(transpose_int_201, view_default_423);  transpose_int_201 = None
        transpose_int_202 = torch.ops.aten.transpose.int(_unsafe_view_default_49, 1, 2);  _unsafe_view_default_49 = None
        bmm_default_87 = torch.ops.aten.bmm.default(view_default_423, transpose_int_202);  view_default_423 = transpose_int_202 = None
        view_default_424 = torch.ops.aten.view.default(bmm_default_86, [256, 8, 64, 33]);  bmm_default_86 = None
        view_default_425 = torch.ops.aten.view.default(bmm_default_87, [256, 8, 33, 64]);  bmm_default_87 = None
        transpose_int_203 = torch.ops.aten.transpose.int(view_default_424, 2, 3);  view_default_424 = None
        div_tensor_30 = torch.ops.aten.div.Tensor(view_default_425, 8.0);  view_default_425 = None
        transpose_int_204 = torch.ops.aten.transpose.int(view_default_421, 1, 2);  view_default_421 = None
        transpose_int_205 = torch.ops.aten.transpose.int(transpose_int_203, 1, 2);  transpose_int_203 = None
        transpose_int_206 = torch.ops.aten.transpose.int(div_tensor_30, 1, 2);  div_tensor_30 = None
        clone_default_130 = torch.ops.aten.clone.default(transpose_int_204, memory_format = torch.contiguous_format);  transpose_int_204 = None
        _unsafe_view_default_212 = torch.ops.aten._unsafe_view.default(clone_default_130, [256, 33, 512]);  clone_default_130 = None
        view_default_426 = torch.ops.aten.view.default(_unsafe_view_default_212, [8448, 512]);  _unsafe_view_default_212 = None
        t_default_353 = torch.ops.aten.t.default(view_default_426)
        mm_default_201 = torch.ops.aten.mm.default(t_default_353, view_default_69);  t_default_353 = view_default_69 = None
        t_default_354 = torch.ops.aten.t.default(mm_default_201);  mm_default_201 = None
        t_default_355 = torch.ops.aten.t.default(t_default_32);  t_default_32 = None
        mm_default_202 = torch.ops.aten.mm.default(view_default_426, t_default_355);  view_default_426 = t_default_355 = None
        view_default_427 = torch.ops.aten.view.default(mm_default_202, [256, 33, 512]);  mm_default_202 = None
        add_tensor_44 = torch.ops.aten.add.Tensor(getitem_156, view_default_427);  getitem_156 = view_default_427 = None
        t_default_356 = torch.ops.aten.t.default(t_default_354);  t_default_354 = None
        view_default_428 = torch.ops.aten.view.default(transpose_int_205, [256, 33, 512]);  transpose_int_205 = None
        clone_default_131 = torch.ops.aten.clone.default(view_default_428, memory_format = torch.contiguous_format);  view_default_428 = None
        _unsafe_view_default_213 = torch.ops.aten._unsafe_view.default(clone_default_131, [8448, 512]);  clone_default_131 = None
        t_default_357 = torch.ops.aten.t.default(_unsafe_view_default_213)
        mm_default_203 = torch.ops.aten.mm.default(t_default_357, view_default_67);  t_default_357 = view_default_67 = None
        t_default_358 = torch.ops.aten.t.default(mm_default_203);  mm_default_203 = None
        t_default_359 = torch.ops.aten.t.default(t_default_31);  t_default_31 = None
        mm_default_204 = torch.ops.aten.mm.default(_unsafe_view_default_213, t_default_359);  _unsafe_view_default_213 = t_default_359 = None
        view_default_429 = torch.ops.aten.view.default(mm_default_204, [256, 33, 512]);  mm_default_204 = None
        add_tensor_45 = torch.ops.aten.add.Tensor(add_tensor_44, view_default_429);  add_tensor_44 = view_default_429 = None
        t_default_360 = torch.ops.aten.t.default(t_default_358);  t_default_358 = None
        clone_default_132 = torch.ops.aten.clone.default(transpose_int_206, memory_format = torch.contiguous_format);  transpose_int_206 = None
        _unsafe_view_default_214 = torch.ops.aten._unsafe_view.default(clone_default_132, [256, 33, 512]);  clone_default_132 = None
        view_default_430 = torch.ops.aten.view.default(_unsafe_view_default_214, [8448, 512]);  _unsafe_view_default_214 = None
        t_default_361 = torch.ops.aten.t.default(view_default_430)
        mm_default_205 = torch.ops.aten.mm.default(t_default_361, view_default_65);  t_default_361 = view_default_65 = None
        t_default_362 = torch.ops.aten.t.default(mm_default_205);  mm_default_205 = None
        t_default_363 = torch.ops.aten.t.default(t_default_30);  t_default_30 = None
        mm_default_206 = torch.ops.aten.mm.default(view_default_430, t_default_363);  view_default_430 = t_default_363 = None
        view_default_431 = torch.ops.aten.view.default(mm_default_206, [256, 33, 512]);  mm_default_206 = None
        add_tensor_46 = torch.ops.aten.add.Tensor(add_tensor_45, view_default_431);  add_tensor_45 = view_default_431 = None
        t_default_364 = torch.ops.aten.t.default(t_default_362);  t_default_362 = None
        native_layer_norm_backward_default_21 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_46, add__tensor_9, [512], getitem_31, getitem_32, primals_164, primals_163, [True, True, True]);  add_tensor_46 = add__tensor_9 = getitem_31 = getitem_32 = primals_164 = primals_163 = None
        getitem_159 = native_layer_norm_backward_default_21[0]
        getitem_160 = native_layer_norm_backward_default_21[1]
        getitem_161 = native_layer_norm_backward_default_21[2];  native_layer_norm_backward_default_21 = None
        new_empty_default_7 = torch.ops.aten.new_empty.default(getitem_159, [4325376]);  getitem_159 = None
        zero__default_7 = torch.ops.aten.zero_.default(new_empty_default_7);  new_empty_default_7 = None
        as_strided_default_22 = torch.ops.aten.as_strided.default(zero__default_7, [8448, 512], [512, 1], 0);  zero__default_7 = None
        new_empty_strided_default_7 = torch.ops.aten.new_empty_strided.default(as_strided_default_22, [8448, 512], [512, 1])
        copy__default_22 = torch.ops.aten.copy_.default(new_empty_strided_default_7, as_strided_default_22);  new_empty_strided_default_7 = as_strided_default_22 = None
        as_strided_default_23 = torch.ops.aten.as_strided.default(copy__default_22, [256, 33, 512], [16896, 512, 1], 0)
        clone_default_133 = torch.ops.aten.clone.default(as_strided_default_23, memory_format = torch.contiguous_format);  as_strided_default_23 = None
        t_default_365 = torch.ops.aten.t.default(t_default_29);  t_default_29 = None
        mm_default_207 = torch.ops.aten.mm.default(copy__default_22, t_default_365);  t_default_365 = None
        t_default_366 = torch.ops.aten.t.default(copy__default_22)
        mm_default_208 = torch.ops.aten.mm.default(t_default_366, view_default_63);  t_default_366 = view_default_63 = None
        t_default_367 = torch.ops.aten.t.default(mm_default_208);  mm_default_208 = None
        sum_dim_int_list_14 = torch.ops.aten.sum.dim_IntList(copy__default_22, [0], True);  copy__default_22 = None
        view_default_432 = torch.ops.aten.view.default(sum_dim_int_list_14, [512]);  sum_dim_int_list_14 = None
        t_default_368 = torch.ops.aten.t.default(t_default_367);  t_default_367 = None
        view_default_433 = torch.ops.aten.view.default(mm_default_207, [256, 33, 2048]);  mm_default_207 = None
        to_dtype_21 = torch.ops.aten.to.dtype(view_default_433, torch.float32);  view_default_433 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu_default_4, torch.float32);  relu_default_4 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_7, to_dtype_21);  le_scalar_7 = new_zeros_default_7 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        view_default_434 = torch.ops.aten.view.default(to_dtype_23, [8448, 2048]);  to_dtype_23 = None
        t_default_369 = torch.ops.aten.t.default(t_default_28);  t_default_28 = None
        mm_default_209 = torch.ops.aten.mm.default(view_default_434, t_default_369);  t_default_369 = None
        t_default_370 = torch.ops.aten.t.default(view_default_434)
        mm_default_210 = torch.ops.aten.mm.default(t_default_370, view_default_61);  t_default_370 = view_default_61 = None
        t_default_371 = torch.ops.aten.t.default(mm_default_210);  mm_default_210 = None
        sum_dim_int_list_15 = torch.ops.aten.sum.dim_IntList(view_default_434, [0], True);  view_default_434 = None
        view_default_435 = torch.ops.aten.view.default(sum_dim_int_list_15, [2048]);  sum_dim_int_list_15 = None
        t_default_372 = torch.ops.aten.t.default(t_default_371);  t_default_371 = None
        view_default_436 = torch.ops.aten.view.default(mm_default_209, [256, 33, 512]);  mm_default_209 = None
        add_tensor_47 = torch.ops.aten.add.Tensor(clone_default_133, view_default_436);  clone_default_133 = view_default_436 = None
        native_layer_norm_backward_default_22 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_47, add__tensor_8, [512], getitem_28, getitem_29, primals_171, primals_170, [True, True, True]);  add_tensor_47 = add__tensor_8 = getitem_28 = getitem_29 = primals_171 = primals_170 = None
        getitem_162 = native_layer_norm_backward_default_22[0]
        getitem_163 = native_layer_norm_backward_default_22[1]
        getitem_164 = native_layer_norm_backward_default_22[2];  native_layer_norm_backward_default_22 = None
        view_default_437 = torch.ops.aten.view.default(getitem_162, [8448, 512])
        t_default_373 = torch.ops.aten.t.default(view_default_437)
        mm_default_211 = torch.ops.aten.mm.default(t_default_373, view_default_60);  t_default_373 = view_default_60 = None
        t_default_374 = torch.ops.aten.t.default(mm_default_211);  mm_default_211 = None
        t_default_375 = torch.ops.aten.t.default(t_default_27);  t_default_27 = None
        mm_default_212 = torch.ops.aten.mm.default(view_default_437, t_default_375);  view_default_437 = t_default_375 = None
        view_default_438 = torch.ops.aten.view.default(mm_default_212, [256, 33, 512]);  mm_default_212 = None
        t_default_376 = torch.ops.aten.t.default(t_default_374);  t_default_374 = None
        view_default_439 = torch.ops.aten.view.default(view_default_438, [256, 33, 8, 64]);  view_default_438 = None
        transpose_int_207 = torch.ops.aten.transpose.int(view_default_439, 1, 2);  view_default_439 = None
        clone_default_134 = torch.ops.aten.clone.default(transpose_int_207, memory_format = torch.contiguous_format);  transpose_int_207 = None
        _unsafe_view_default_215 = torch.ops.aten._unsafe_view.default(clone_default_134, [2048, 33, 64]);  clone_default_134 = None
        transpose_int_208 = torch.ops.aten.transpose.int(view_default_58, 1, 2);  view_default_58 = None
        bmm_default_88 = torch.ops.aten.bmm.default(transpose_int_208, _unsafe_view_default_215);  transpose_int_208 = None
        transpose_int_209 = torch.ops.aten.transpose.int(_unsafe_view_default_42, 1, 2);  _unsafe_view_default_42 = None
        bmm_default_89 = torch.ops.aten.bmm.default(_unsafe_view_default_215, transpose_int_209);  _unsafe_view_default_215 = transpose_int_209 = None
        view_default_440 = torch.ops.aten.view.default(bmm_default_88, [256, 8, 33, 64]);  bmm_default_88 = None
        view_default_441 = torch.ops.aten.view.default(bmm_default_89, [256, 8, 33, 33]);  bmm_default_89 = None
        _softmax_backward_data_default_13 = torch.ops.aten._softmax_backward_data.default(view_default_441, _softmax_default_4, -1, torch.float32);  view_default_441 = _softmax_default_4 = None
        where_scalar_self_31 = torch.ops.aten.where.ScalarSelf(eq_scalar_4, 0.0, _softmax_backward_data_default_13);  eq_scalar_4 = _softmax_backward_data_default_13 = None
        view_default_442 = torch.ops.aten.view.default(where_scalar_self_31, [2048, 33, 33]);  where_scalar_self_31 = None
        transpose_int_210 = torch.ops.aten.transpose.int(_unsafe_view_default_39, 1, 2);  _unsafe_view_default_39 = None
        bmm_default_90 = torch.ops.aten.bmm.default(transpose_int_210, view_default_442);  transpose_int_210 = None
        transpose_int_211 = torch.ops.aten.transpose.int(_unsafe_view_default_40, 1, 2);  _unsafe_view_default_40 = None
        bmm_default_91 = torch.ops.aten.bmm.default(view_default_442, transpose_int_211);  view_default_442 = transpose_int_211 = None
        view_default_443 = torch.ops.aten.view.default(bmm_default_90, [256, 8, 64, 33]);  bmm_default_90 = None
        view_default_444 = torch.ops.aten.view.default(bmm_default_91, [256, 8, 33, 64]);  bmm_default_91 = None
        transpose_int_212 = torch.ops.aten.transpose.int(view_default_443, 2, 3);  view_default_443 = None
        div_tensor_31 = torch.ops.aten.div.Tensor(view_default_444, 8.0);  view_default_444 = None
        transpose_int_213 = torch.ops.aten.transpose.int(view_default_440, 1, 2);  view_default_440 = None
        transpose_int_214 = torch.ops.aten.transpose.int(transpose_int_212, 1, 2);  transpose_int_212 = None
        transpose_int_215 = torch.ops.aten.transpose.int(div_tensor_31, 1, 2);  div_tensor_31 = None
        clone_default_135 = torch.ops.aten.clone.default(transpose_int_213, memory_format = torch.contiguous_format);  transpose_int_213 = None
        _unsafe_view_default_216 = torch.ops.aten._unsafe_view.default(clone_default_135, [256, 33, 512]);  clone_default_135 = None
        view_default_445 = torch.ops.aten.view.default(_unsafe_view_default_216, [8448, 512]);  _unsafe_view_default_216 = None
        t_default_377 = torch.ops.aten.t.default(view_default_445)
        mm_default_213 = torch.ops.aten.mm.default(t_default_377, view_default_56);  t_default_377 = view_default_56 = None
        t_default_378 = torch.ops.aten.t.default(mm_default_213);  mm_default_213 = None
        t_default_379 = torch.ops.aten.t.default(t_default_26);  t_default_26 = None
        mm_default_214 = torch.ops.aten.mm.default(view_default_445, t_default_379);  view_default_445 = t_default_379 = None
        view_default_446 = torch.ops.aten.view.default(mm_default_214, [256, 33, 512]);  mm_default_214 = None
        add_tensor_48 = torch.ops.aten.add.Tensor(getitem_162, view_default_446);  getitem_162 = view_default_446 = None
        t_default_380 = torch.ops.aten.t.default(t_default_378);  t_default_378 = None
        view_default_447 = torch.ops.aten.view.default(transpose_int_214, [256, 33, 512]);  transpose_int_214 = None
        clone_default_136 = torch.ops.aten.clone.default(view_default_447, memory_format = torch.contiguous_format);  view_default_447 = None
        _unsafe_view_default_217 = torch.ops.aten._unsafe_view.default(clone_default_136, [8448, 512]);  clone_default_136 = None
        t_default_381 = torch.ops.aten.t.default(_unsafe_view_default_217)
        mm_default_215 = torch.ops.aten.mm.default(t_default_381, view_default_54);  t_default_381 = view_default_54 = None
        t_default_382 = torch.ops.aten.t.default(mm_default_215);  mm_default_215 = None
        t_default_383 = torch.ops.aten.t.default(t_default_25);  t_default_25 = None
        mm_default_216 = torch.ops.aten.mm.default(_unsafe_view_default_217, t_default_383);  _unsafe_view_default_217 = t_default_383 = None
        view_default_448 = torch.ops.aten.view.default(mm_default_216, [256, 33, 512]);  mm_default_216 = None
        add_tensor_49 = torch.ops.aten.add.Tensor(add_tensor_48, view_default_448);  add_tensor_48 = view_default_448 = None
        t_default_384 = torch.ops.aten.t.default(t_default_382);  t_default_382 = None
        clone_default_137 = torch.ops.aten.clone.default(transpose_int_215, memory_format = torch.contiguous_format);  transpose_int_215 = None
        _unsafe_view_default_218 = torch.ops.aten._unsafe_view.default(clone_default_137, [256, 33, 512]);  clone_default_137 = None
        view_default_449 = torch.ops.aten.view.default(_unsafe_view_default_218, [8448, 512]);  _unsafe_view_default_218 = None
        t_default_385 = torch.ops.aten.t.default(view_default_449)
        mm_default_217 = torch.ops.aten.mm.default(t_default_385, view_default_52);  t_default_385 = view_default_52 = None
        t_default_386 = torch.ops.aten.t.default(mm_default_217);  mm_default_217 = None
        t_default_387 = torch.ops.aten.t.default(t_default_24);  t_default_24 = None
        mm_default_218 = torch.ops.aten.mm.default(view_default_449, t_default_387);  view_default_449 = t_default_387 = None
        view_default_450 = torch.ops.aten.view.default(mm_default_218, [256, 33, 512]);  mm_default_218 = None
        add_tensor_50 = torch.ops.aten.add.Tensor(add_tensor_49, view_default_450);  add_tensor_49 = view_default_450 = None
        t_default_388 = torch.ops.aten.t.default(t_default_386);  t_default_386 = None
        native_layer_norm_backward_default_23 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_50, add__tensor_7, [512], getitem_25, getitem_26, primals_152, primals_151, [True, True, True]);  add_tensor_50 = add__tensor_7 = getitem_25 = getitem_26 = primals_152 = primals_151 = None
        getitem_165 = native_layer_norm_backward_default_23[0]
        getitem_166 = native_layer_norm_backward_default_23[1]
        getitem_167 = native_layer_norm_backward_default_23[2];  native_layer_norm_backward_default_23 = None
        new_empty_default_8 = torch.ops.aten.new_empty.default(getitem_165, [4325376]);  getitem_165 = None
        zero__default_8 = torch.ops.aten.zero_.default(new_empty_default_8);  new_empty_default_8 = None
        as_strided_default_25 = torch.ops.aten.as_strided.default(zero__default_8, [8448, 512], [512, 1], 0);  zero__default_8 = None
        new_empty_strided_default_8 = torch.ops.aten.new_empty_strided.default(as_strided_default_25, [8448, 512], [512, 1])
        copy__default_25 = torch.ops.aten.copy_.default(new_empty_strided_default_8, as_strided_default_25);  new_empty_strided_default_8 = as_strided_default_25 = None
        as_strided_default_26 = torch.ops.aten.as_strided.default(copy__default_25, [256, 33, 512], [16896, 512, 1], 0)
        clone_default_138 = torch.ops.aten.clone.default(as_strided_default_26, memory_format = torch.contiguous_format);  as_strided_default_26 = None
        t_default_389 = torch.ops.aten.t.default(t_default_23);  t_default_23 = None
        mm_default_219 = torch.ops.aten.mm.default(copy__default_25, t_default_389);  t_default_389 = None
        t_default_390 = torch.ops.aten.t.default(copy__default_25)
        mm_default_220 = torch.ops.aten.mm.default(t_default_390, view_default_50);  t_default_390 = view_default_50 = None
        t_default_391 = torch.ops.aten.t.default(mm_default_220);  mm_default_220 = None
        sum_dim_int_list_16 = torch.ops.aten.sum.dim_IntList(copy__default_25, [0], True);  copy__default_25 = None
        view_default_451 = torch.ops.aten.view.default(sum_dim_int_list_16, [512]);  sum_dim_int_list_16 = None
        t_default_392 = torch.ops.aten.t.default(t_default_391);  t_default_391 = None
        view_default_452 = torch.ops.aten.view.default(mm_default_219, [256, 33, 2048]);  mm_default_219 = None
        to_dtype_24 = torch.ops.aten.to.dtype(view_default_452, torch.float32);  view_default_452 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu_default_3, torch.float32);  relu_default_3 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_8 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_8, to_dtype_24);  le_scalar_8 = new_zeros_default_8 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        view_default_453 = torch.ops.aten.view.default(to_dtype_26, [8448, 2048]);  to_dtype_26 = None
        t_default_393 = torch.ops.aten.t.default(t_default_22);  t_default_22 = None
        mm_default_221 = torch.ops.aten.mm.default(view_default_453, t_default_393);  t_default_393 = None
        t_default_394 = torch.ops.aten.t.default(view_default_453)
        mm_default_222 = torch.ops.aten.mm.default(t_default_394, view_default_48);  t_default_394 = view_default_48 = None
        t_default_395 = torch.ops.aten.t.default(mm_default_222);  mm_default_222 = None
        sum_dim_int_list_17 = torch.ops.aten.sum.dim_IntList(view_default_453, [0], True);  view_default_453 = None
        view_default_454 = torch.ops.aten.view.default(sum_dim_int_list_17, [2048]);  sum_dim_int_list_17 = None
        t_default_396 = torch.ops.aten.t.default(t_default_395);  t_default_395 = None
        view_default_455 = torch.ops.aten.view.default(mm_default_221, [256, 33, 512]);  mm_default_221 = None
        add_tensor_51 = torch.ops.aten.add.Tensor(clone_default_138, view_default_455);  clone_default_138 = view_default_455 = None
        native_layer_norm_backward_default_24 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_51, add__tensor_6, [512], getitem_22, getitem_23, primals_159, primals_158, [True, True, True]);  add_tensor_51 = add__tensor_6 = getitem_22 = getitem_23 = primals_159 = primals_158 = None
        getitem_168 = native_layer_norm_backward_default_24[0]
        getitem_169 = native_layer_norm_backward_default_24[1]
        getitem_170 = native_layer_norm_backward_default_24[2];  native_layer_norm_backward_default_24 = None
        view_default_456 = torch.ops.aten.view.default(getitem_168, [8448, 512])
        t_default_397 = torch.ops.aten.t.default(view_default_456)
        mm_default_223 = torch.ops.aten.mm.default(t_default_397, view_default_47);  t_default_397 = view_default_47 = None
        t_default_398 = torch.ops.aten.t.default(mm_default_223);  mm_default_223 = None
        t_default_399 = torch.ops.aten.t.default(t_default_21);  t_default_21 = None
        mm_default_224 = torch.ops.aten.mm.default(view_default_456, t_default_399);  view_default_456 = t_default_399 = None
        view_default_457 = torch.ops.aten.view.default(mm_default_224, [256, 33, 512]);  mm_default_224 = None
        t_default_400 = torch.ops.aten.t.default(t_default_398);  t_default_398 = None
        view_default_458 = torch.ops.aten.view.default(view_default_457, [256, 33, 8, 64]);  view_default_457 = None
        transpose_int_216 = torch.ops.aten.transpose.int(view_default_458, 1, 2);  view_default_458 = None
        clone_default_139 = torch.ops.aten.clone.default(transpose_int_216, memory_format = torch.contiguous_format);  transpose_int_216 = None
        _unsafe_view_default_219 = torch.ops.aten._unsafe_view.default(clone_default_139, [2048, 33, 64]);  clone_default_139 = None
        transpose_int_217 = torch.ops.aten.transpose.int(view_default_45, 1, 2);  view_default_45 = None
        bmm_default_92 = torch.ops.aten.bmm.default(transpose_int_217, _unsafe_view_default_219);  transpose_int_217 = None
        transpose_int_218 = torch.ops.aten.transpose.int(_unsafe_view_default_33, 1, 2);  _unsafe_view_default_33 = None
        bmm_default_93 = torch.ops.aten.bmm.default(_unsafe_view_default_219, transpose_int_218);  _unsafe_view_default_219 = transpose_int_218 = None
        view_default_459 = torch.ops.aten.view.default(bmm_default_92, [256, 8, 33, 64]);  bmm_default_92 = None
        view_default_460 = torch.ops.aten.view.default(bmm_default_93, [256, 8, 33, 33]);  bmm_default_93 = None
        _softmax_backward_data_default_14 = torch.ops.aten._softmax_backward_data.default(view_default_460, _softmax_default_3, -1, torch.float32);  view_default_460 = _softmax_default_3 = None
        where_scalar_self_32 = torch.ops.aten.where.ScalarSelf(eq_scalar_3, 0.0, _softmax_backward_data_default_14);  eq_scalar_3 = _softmax_backward_data_default_14 = None
        view_default_461 = torch.ops.aten.view.default(where_scalar_self_32, [2048, 33, 33]);  where_scalar_self_32 = None
        transpose_int_219 = torch.ops.aten.transpose.int(_unsafe_view_default_30, 1, 2);  _unsafe_view_default_30 = None
        bmm_default_94 = torch.ops.aten.bmm.default(transpose_int_219, view_default_461);  transpose_int_219 = None
        transpose_int_220 = torch.ops.aten.transpose.int(_unsafe_view_default_31, 1, 2);  _unsafe_view_default_31 = None
        bmm_default_95 = torch.ops.aten.bmm.default(view_default_461, transpose_int_220);  view_default_461 = transpose_int_220 = None
        view_default_462 = torch.ops.aten.view.default(bmm_default_94, [256, 8, 64, 33]);  bmm_default_94 = None
        view_default_463 = torch.ops.aten.view.default(bmm_default_95, [256, 8, 33, 64]);  bmm_default_95 = None
        transpose_int_221 = torch.ops.aten.transpose.int(view_default_462, 2, 3);  view_default_462 = None
        div_tensor_32 = torch.ops.aten.div.Tensor(view_default_463, 8.0);  view_default_463 = None
        transpose_int_222 = torch.ops.aten.transpose.int(view_default_459, 1, 2);  view_default_459 = None
        transpose_int_223 = torch.ops.aten.transpose.int(transpose_int_221, 1, 2);  transpose_int_221 = None
        transpose_int_224 = torch.ops.aten.transpose.int(div_tensor_32, 1, 2);  div_tensor_32 = None
        clone_default_140 = torch.ops.aten.clone.default(transpose_int_222, memory_format = torch.contiguous_format);  transpose_int_222 = None
        _unsafe_view_default_220 = torch.ops.aten._unsafe_view.default(clone_default_140, [256, 33, 512]);  clone_default_140 = None
        view_default_464 = torch.ops.aten.view.default(_unsafe_view_default_220, [8448, 512]);  _unsafe_view_default_220 = None
        t_default_401 = torch.ops.aten.t.default(view_default_464)
        mm_default_225 = torch.ops.aten.mm.default(t_default_401, view_default_43);  t_default_401 = view_default_43 = None
        t_default_402 = torch.ops.aten.t.default(mm_default_225);  mm_default_225 = None
        t_default_403 = torch.ops.aten.t.default(t_default_20);  t_default_20 = None
        mm_default_226 = torch.ops.aten.mm.default(view_default_464, t_default_403);  view_default_464 = t_default_403 = None
        view_default_465 = torch.ops.aten.view.default(mm_default_226, [256, 33, 512]);  mm_default_226 = None
        add_tensor_52 = torch.ops.aten.add.Tensor(getitem_168, view_default_465);  getitem_168 = view_default_465 = None
        t_default_404 = torch.ops.aten.t.default(t_default_402);  t_default_402 = None
        view_default_466 = torch.ops.aten.view.default(transpose_int_223, [256, 33, 512]);  transpose_int_223 = None
        clone_default_141 = torch.ops.aten.clone.default(view_default_466, memory_format = torch.contiguous_format);  view_default_466 = None
        _unsafe_view_default_221 = torch.ops.aten._unsafe_view.default(clone_default_141, [8448, 512]);  clone_default_141 = None
        t_default_405 = torch.ops.aten.t.default(_unsafe_view_default_221)
        mm_default_227 = torch.ops.aten.mm.default(t_default_405, view_default_41);  t_default_405 = view_default_41 = None
        t_default_406 = torch.ops.aten.t.default(mm_default_227);  mm_default_227 = None
        t_default_407 = torch.ops.aten.t.default(t_default_19);  t_default_19 = None
        mm_default_228 = torch.ops.aten.mm.default(_unsafe_view_default_221, t_default_407);  _unsafe_view_default_221 = t_default_407 = None
        view_default_467 = torch.ops.aten.view.default(mm_default_228, [256, 33, 512]);  mm_default_228 = None
        add_tensor_53 = torch.ops.aten.add.Tensor(add_tensor_52, view_default_467);  add_tensor_52 = view_default_467 = None
        t_default_408 = torch.ops.aten.t.default(t_default_406);  t_default_406 = None
        clone_default_142 = torch.ops.aten.clone.default(transpose_int_224, memory_format = torch.contiguous_format);  transpose_int_224 = None
        _unsafe_view_default_222 = torch.ops.aten._unsafe_view.default(clone_default_142, [256, 33, 512]);  clone_default_142 = None
        view_default_468 = torch.ops.aten.view.default(_unsafe_view_default_222, [8448, 512]);  _unsafe_view_default_222 = None
        t_default_409 = torch.ops.aten.t.default(view_default_468)
        mm_default_229 = torch.ops.aten.mm.default(t_default_409, view_default_39);  t_default_409 = view_default_39 = None
        t_default_410 = torch.ops.aten.t.default(mm_default_229);  mm_default_229 = None
        t_default_411 = torch.ops.aten.t.default(t_default_18);  t_default_18 = None
        mm_default_230 = torch.ops.aten.mm.default(view_default_468, t_default_411);  view_default_468 = t_default_411 = None
        view_default_469 = torch.ops.aten.view.default(mm_default_230, [256, 33, 512]);  mm_default_230 = None
        add_tensor_54 = torch.ops.aten.add.Tensor(add_tensor_53, view_default_469);  add_tensor_53 = view_default_469 = None
        t_default_412 = torch.ops.aten.t.default(t_default_410);  t_default_410 = None
        native_layer_norm_backward_default_25 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_54, add__tensor_5, [512], getitem_19, getitem_20, primals_140, primals_139, [True, True, True]);  add_tensor_54 = add__tensor_5 = getitem_19 = getitem_20 = primals_140 = primals_139 = None
        getitem_171 = native_layer_norm_backward_default_25[0]
        getitem_172 = native_layer_norm_backward_default_25[1]
        getitem_173 = native_layer_norm_backward_default_25[2];  native_layer_norm_backward_default_25 = None
        new_empty_default_9 = torch.ops.aten.new_empty.default(getitem_171, [4325376]);  getitem_171 = None
        zero__default_9 = torch.ops.aten.zero_.default(new_empty_default_9);  new_empty_default_9 = None
        as_strided_default_28 = torch.ops.aten.as_strided.default(zero__default_9, [8448, 512], [512, 1], 0);  zero__default_9 = None
        new_empty_strided_default_9 = torch.ops.aten.new_empty_strided.default(as_strided_default_28, [8448, 512], [512, 1])
        copy__default_28 = torch.ops.aten.copy_.default(new_empty_strided_default_9, as_strided_default_28);  new_empty_strided_default_9 = as_strided_default_28 = None
        as_strided_default_29 = torch.ops.aten.as_strided.default(copy__default_28, [256, 33, 512], [16896, 512, 1], 0)
        clone_default_143 = torch.ops.aten.clone.default(as_strided_default_29, memory_format = torch.contiguous_format);  as_strided_default_29 = None
        t_default_413 = torch.ops.aten.t.default(t_default_17);  t_default_17 = None
        mm_default_231 = torch.ops.aten.mm.default(copy__default_28, t_default_413);  t_default_413 = None
        t_default_414 = torch.ops.aten.t.default(copy__default_28)
        mm_default_232 = torch.ops.aten.mm.default(t_default_414, view_default_37);  t_default_414 = view_default_37 = None
        t_default_415 = torch.ops.aten.t.default(mm_default_232);  mm_default_232 = None
        sum_dim_int_list_18 = torch.ops.aten.sum.dim_IntList(copy__default_28, [0], True);  copy__default_28 = None
        view_default_470 = torch.ops.aten.view.default(sum_dim_int_list_18, [512]);  sum_dim_int_list_18 = None
        t_default_416 = torch.ops.aten.t.default(t_default_415);  t_default_415 = None
        view_default_471 = torch.ops.aten.view.default(mm_default_231, [256, 33, 2048]);  mm_default_231 = None
        to_dtype_27 = torch.ops.aten.to.dtype(view_default_471, torch.float32);  view_default_471 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu_default_2, torch.float32);  relu_default_2 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_9 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_9, to_dtype_27);  le_scalar_9 = new_zeros_default_9 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        view_default_472 = torch.ops.aten.view.default(to_dtype_29, [8448, 2048]);  to_dtype_29 = None
        t_default_417 = torch.ops.aten.t.default(t_default_16);  t_default_16 = None
        mm_default_233 = torch.ops.aten.mm.default(view_default_472, t_default_417);  t_default_417 = None
        t_default_418 = torch.ops.aten.t.default(view_default_472)
        mm_default_234 = torch.ops.aten.mm.default(t_default_418, view_default_35);  t_default_418 = view_default_35 = None
        t_default_419 = torch.ops.aten.t.default(mm_default_234);  mm_default_234 = None
        sum_dim_int_list_19 = torch.ops.aten.sum.dim_IntList(view_default_472, [0], True);  view_default_472 = None
        view_default_473 = torch.ops.aten.view.default(sum_dim_int_list_19, [2048]);  sum_dim_int_list_19 = None
        t_default_420 = torch.ops.aten.t.default(t_default_419);  t_default_419 = None
        view_default_474 = torch.ops.aten.view.default(mm_default_233, [256, 33, 512]);  mm_default_233 = None
        add_tensor_55 = torch.ops.aten.add.Tensor(clone_default_143, view_default_474);  clone_default_143 = view_default_474 = None
        native_layer_norm_backward_default_26 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_55, add__tensor_4, [512], getitem_16, getitem_17, primals_147, primals_146, [True, True, True]);  add_tensor_55 = add__tensor_4 = getitem_16 = getitem_17 = primals_147 = primals_146 = None
        getitem_174 = native_layer_norm_backward_default_26[0]
        getitem_175 = native_layer_norm_backward_default_26[1]
        getitem_176 = native_layer_norm_backward_default_26[2];  native_layer_norm_backward_default_26 = None
        view_default_475 = torch.ops.aten.view.default(getitem_174, [8448, 512])
        t_default_421 = torch.ops.aten.t.default(view_default_475)
        mm_default_235 = torch.ops.aten.mm.default(t_default_421, view_default_34);  t_default_421 = view_default_34 = None
        t_default_422 = torch.ops.aten.t.default(mm_default_235);  mm_default_235 = None
        t_default_423 = torch.ops.aten.t.default(t_default_15);  t_default_15 = None
        mm_default_236 = torch.ops.aten.mm.default(view_default_475, t_default_423);  view_default_475 = t_default_423 = None
        view_default_476 = torch.ops.aten.view.default(mm_default_236, [256, 33, 512]);  mm_default_236 = None
        t_default_424 = torch.ops.aten.t.default(t_default_422);  t_default_422 = None
        view_default_477 = torch.ops.aten.view.default(view_default_476, [256, 33, 8, 64]);  view_default_476 = None
        transpose_int_225 = torch.ops.aten.transpose.int(view_default_477, 1, 2);  view_default_477 = None
        clone_default_144 = torch.ops.aten.clone.default(transpose_int_225, memory_format = torch.contiguous_format);  transpose_int_225 = None
        _unsafe_view_default_223 = torch.ops.aten._unsafe_view.default(clone_default_144, [2048, 33, 64]);  clone_default_144 = None
        transpose_int_226 = torch.ops.aten.transpose.int(view_default_32, 1, 2);  view_default_32 = None
        bmm_default_96 = torch.ops.aten.bmm.default(transpose_int_226, _unsafe_view_default_223);  transpose_int_226 = None
        transpose_int_227 = torch.ops.aten.transpose.int(_unsafe_view_default_24, 1, 2);  _unsafe_view_default_24 = None
        bmm_default_97 = torch.ops.aten.bmm.default(_unsafe_view_default_223, transpose_int_227);  _unsafe_view_default_223 = transpose_int_227 = None
        view_default_478 = torch.ops.aten.view.default(bmm_default_96, [256, 8, 33, 64]);  bmm_default_96 = None
        view_default_479 = torch.ops.aten.view.default(bmm_default_97, [256, 8, 33, 33]);  bmm_default_97 = None
        _softmax_backward_data_default_15 = torch.ops.aten._softmax_backward_data.default(view_default_479, _softmax_default_2, -1, torch.float32);  view_default_479 = _softmax_default_2 = None
        where_scalar_self_33 = torch.ops.aten.where.ScalarSelf(eq_scalar_2, 0.0, _softmax_backward_data_default_15);  eq_scalar_2 = _softmax_backward_data_default_15 = None
        view_default_480 = torch.ops.aten.view.default(where_scalar_self_33, [2048, 33, 33]);  where_scalar_self_33 = None
        transpose_int_228 = torch.ops.aten.transpose.int(_unsafe_view_default_21, 1, 2);  _unsafe_view_default_21 = None
        bmm_default_98 = torch.ops.aten.bmm.default(transpose_int_228, view_default_480);  transpose_int_228 = None
        transpose_int_229 = torch.ops.aten.transpose.int(_unsafe_view_default_22, 1, 2);  _unsafe_view_default_22 = None
        bmm_default_99 = torch.ops.aten.bmm.default(view_default_480, transpose_int_229);  view_default_480 = transpose_int_229 = None
        view_default_481 = torch.ops.aten.view.default(bmm_default_98, [256, 8, 64, 33]);  bmm_default_98 = None
        view_default_482 = torch.ops.aten.view.default(bmm_default_99, [256, 8, 33, 64]);  bmm_default_99 = None
        transpose_int_230 = torch.ops.aten.transpose.int(view_default_481, 2, 3);  view_default_481 = None
        div_tensor_33 = torch.ops.aten.div.Tensor(view_default_482, 8.0);  view_default_482 = None
        transpose_int_231 = torch.ops.aten.transpose.int(view_default_478, 1, 2);  view_default_478 = None
        transpose_int_232 = torch.ops.aten.transpose.int(transpose_int_230, 1, 2);  transpose_int_230 = None
        transpose_int_233 = torch.ops.aten.transpose.int(div_tensor_33, 1, 2);  div_tensor_33 = None
        clone_default_145 = torch.ops.aten.clone.default(transpose_int_231, memory_format = torch.contiguous_format);  transpose_int_231 = None
        _unsafe_view_default_224 = torch.ops.aten._unsafe_view.default(clone_default_145, [256, 33, 512]);  clone_default_145 = None
        view_default_483 = torch.ops.aten.view.default(_unsafe_view_default_224, [8448, 512]);  _unsafe_view_default_224 = None
        t_default_425 = torch.ops.aten.t.default(view_default_483)
        mm_default_237 = torch.ops.aten.mm.default(t_default_425, view_default_30);  t_default_425 = view_default_30 = None
        t_default_426 = torch.ops.aten.t.default(mm_default_237);  mm_default_237 = None
        t_default_427 = torch.ops.aten.t.default(t_default_14);  t_default_14 = None
        mm_default_238 = torch.ops.aten.mm.default(view_default_483, t_default_427);  view_default_483 = t_default_427 = None
        view_default_484 = torch.ops.aten.view.default(mm_default_238, [256, 33, 512]);  mm_default_238 = None
        add_tensor_56 = torch.ops.aten.add.Tensor(getitem_174, view_default_484);  getitem_174 = view_default_484 = None
        t_default_428 = torch.ops.aten.t.default(t_default_426);  t_default_426 = None
        view_default_485 = torch.ops.aten.view.default(transpose_int_232, [256, 33, 512]);  transpose_int_232 = None
        clone_default_146 = torch.ops.aten.clone.default(view_default_485, memory_format = torch.contiguous_format);  view_default_485 = None
        _unsafe_view_default_225 = torch.ops.aten._unsafe_view.default(clone_default_146, [8448, 512]);  clone_default_146 = None
        t_default_429 = torch.ops.aten.t.default(_unsafe_view_default_225)
        mm_default_239 = torch.ops.aten.mm.default(t_default_429, view_default_28);  t_default_429 = view_default_28 = None
        t_default_430 = torch.ops.aten.t.default(mm_default_239);  mm_default_239 = None
        t_default_431 = torch.ops.aten.t.default(t_default_13);  t_default_13 = None
        mm_default_240 = torch.ops.aten.mm.default(_unsafe_view_default_225, t_default_431);  _unsafe_view_default_225 = t_default_431 = None
        view_default_486 = torch.ops.aten.view.default(mm_default_240, [256, 33, 512]);  mm_default_240 = None
        add_tensor_57 = torch.ops.aten.add.Tensor(add_tensor_56, view_default_486);  add_tensor_56 = view_default_486 = None
        t_default_432 = torch.ops.aten.t.default(t_default_430);  t_default_430 = None
        clone_default_147 = torch.ops.aten.clone.default(transpose_int_233, memory_format = torch.contiguous_format);  transpose_int_233 = None
        _unsafe_view_default_226 = torch.ops.aten._unsafe_view.default(clone_default_147, [256, 33, 512]);  clone_default_147 = None
        view_default_487 = torch.ops.aten.view.default(_unsafe_view_default_226, [8448, 512]);  _unsafe_view_default_226 = None
        t_default_433 = torch.ops.aten.t.default(view_default_487)
        mm_default_241 = torch.ops.aten.mm.default(t_default_433, view_default_26);  t_default_433 = view_default_26 = None
        t_default_434 = torch.ops.aten.t.default(mm_default_241);  mm_default_241 = None
        t_default_435 = torch.ops.aten.t.default(t_default_12);  t_default_12 = None
        mm_default_242 = torch.ops.aten.mm.default(view_default_487, t_default_435);  view_default_487 = t_default_435 = None
        view_default_488 = torch.ops.aten.view.default(mm_default_242, [256, 33, 512]);  mm_default_242 = None
        add_tensor_58 = torch.ops.aten.add.Tensor(add_tensor_57, view_default_488);  add_tensor_57 = view_default_488 = None
        t_default_436 = torch.ops.aten.t.default(t_default_434);  t_default_434 = None
        native_layer_norm_backward_default_27 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_58, add__tensor_3, [512], getitem_13, getitem_14, primals_128, primals_127, [True, True, True]);  add_tensor_58 = add__tensor_3 = getitem_13 = getitem_14 = primals_128 = primals_127 = None
        getitem_177 = native_layer_norm_backward_default_27[0]
        getitem_178 = native_layer_norm_backward_default_27[1]
        getitem_179 = native_layer_norm_backward_default_27[2];  native_layer_norm_backward_default_27 = None
        new_empty_default_10 = torch.ops.aten.new_empty.default(getitem_177, [4325376]);  getitem_177 = None
        zero__default_10 = torch.ops.aten.zero_.default(new_empty_default_10);  new_empty_default_10 = None
        as_strided_default_31 = torch.ops.aten.as_strided.default(zero__default_10, [8448, 512], [512, 1], 0);  zero__default_10 = None
        new_empty_strided_default_10 = torch.ops.aten.new_empty_strided.default(as_strided_default_31, [8448, 512], [512, 1])
        copy__default_31 = torch.ops.aten.copy_.default(new_empty_strided_default_10, as_strided_default_31);  new_empty_strided_default_10 = as_strided_default_31 = None
        as_strided_default_32 = torch.ops.aten.as_strided.default(copy__default_31, [256, 33, 512], [16896, 512, 1], 0)
        clone_default_148 = torch.ops.aten.clone.default(as_strided_default_32, memory_format = torch.contiguous_format);  as_strided_default_32 = None
        t_default_437 = torch.ops.aten.t.default(t_default_11);  t_default_11 = None
        mm_default_243 = torch.ops.aten.mm.default(copy__default_31, t_default_437);  t_default_437 = None
        t_default_438 = torch.ops.aten.t.default(copy__default_31)
        mm_default_244 = torch.ops.aten.mm.default(t_default_438, view_default_24);  t_default_438 = view_default_24 = None
        t_default_439 = torch.ops.aten.t.default(mm_default_244);  mm_default_244 = None
        sum_dim_int_list_20 = torch.ops.aten.sum.dim_IntList(copy__default_31, [0], True);  copy__default_31 = None
        view_default_489 = torch.ops.aten.view.default(sum_dim_int_list_20, [512]);  sum_dim_int_list_20 = None
        t_default_440 = torch.ops.aten.t.default(t_default_439);  t_default_439 = None
        view_default_490 = torch.ops.aten.view.default(mm_default_243, [256, 33, 2048]);  mm_default_243 = None
        to_dtype_30 = torch.ops.aten.to.dtype(view_default_490, torch.float32);  view_default_490 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu_default_1, torch.float32);  relu_default_1 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_10 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_10, to_dtype_30);  le_scalar_10 = new_zeros_default_10 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        view_default_491 = torch.ops.aten.view.default(to_dtype_32, [8448, 2048]);  to_dtype_32 = None
        t_default_441 = torch.ops.aten.t.default(t_default_10);  t_default_10 = None
        mm_default_245 = torch.ops.aten.mm.default(view_default_491, t_default_441);  t_default_441 = None
        t_default_442 = torch.ops.aten.t.default(view_default_491)
        mm_default_246 = torch.ops.aten.mm.default(t_default_442, view_default_22);  t_default_442 = view_default_22 = None
        t_default_443 = torch.ops.aten.t.default(mm_default_246);  mm_default_246 = None
        sum_dim_int_list_21 = torch.ops.aten.sum.dim_IntList(view_default_491, [0], True);  view_default_491 = None
        view_default_492 = torch.ops.aten.view.default(sum_dim_int_list_21, [2048]);  sum_dim_int_list_21 = None
        t_default_444 = torch.ops.aten.t.default(t_default_443);  t_default_443 = None
        view_default_493 = torch.ops.aten.view.default(mm_default_245, [256, 33, 512]);  mm_default_245 = None
        add_tensor_59 = torch.ops.aten.add.Tensor(clone_default_148, view_default_493);  clone_default_148 = view_default_493 = None
        native_layer_norm_backward_default_28 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_59, add__tensor_2, [512], getitem_10, getitem_11, primals_135, primals_134, [True, True, True]);  add_tensor_59 = add__tensor_2 = getitem_10 = getitem_11 = primals_135 = primals_134 = None
        getitem_180 = native_layer_norm_backward_default_28[0]
        getitem_181 = native_layer_norm_backward_default_28[1]
        getitem_182 = native_layer_norm_backward_default_28[2];  native_layer_norm_backward_default_28 = None
        view_default_494 = torch.ops.aten.view.default(getitem_180, [8448, 512])
        t_default_445 = torch.ops.aten.t.default(view_default_494)
        mm_default_247 = torch.ops.aten.mm.default(t_default_445, view_default_21);  t_default_445 = view_default_21 = None
        t_default_446 = torch.ops.aten.t.default(mm_default_247);  mm_default_247 = None
        t_default_447 = torch.ops.aten.t.default(t_default_9);  t_default_9 = None
        mm_default_248 = torch.ops.aten.mm.default(view_default_494, t_default_447);  view_default_494 = t_default_447 = None
        view_default_495 = torch.ops.aten.view.default(mm_default_248, [256, 33, 512]);  mm_default_248 = None
        t_default_448 = torch.ops.aten.t.default(t_default_446);  t_default_446 = None
        view_default_496 = torch.ops.aten.view.default(view_default_495, [256, 33, 8, 64]);  view_default_495 = None
        transpose_int_234 = torch.ops.aten.transpose.int(view_default_496, 1, 2);  view_default_496 = None
        clone_default_149 = torch.ops.aten.clone.default(transpose_int_234, memory_format = torch.contiguous_format);  transpose_int_234 = None
        _unsafe_view_default_227 = torch.ops.aten._unsafe_view.default(clone_default_149, [2048, 33, 64]);  clone_default_149 = None
        transpose_int_235 = torch.ops.aten.transpose.int(view_default_19, 1, 2);  view_default_19 = None
        bmm_default_100 = torch.ops.aten.bmm.default(transpose_int_235, _unsafe_view_default_227);  transpose_int_235 = None
        transpose_int_236 = torch.ops.aten.transpose.int(_unsafe_view_default_15, 1, 2);  _unsafe_view_default_15 = None
        bmm_default_101 = torch.ops.aten.bmm.default(_unsafe_view_default_227, transpose_int_236);  _unsafe_view_default_227 = transpose_int_236 = None
        view_default_497 = torch.ops.aten.view.default(bmm_default_100, [256, 8, 33, 64]);  bmm_default_100 = None
        view_default_498 = torch.ops.aten.view.default(bmm_default_101, [256, 8, 33, 33]);  bmm_default_101 = None
        _softmax_backward_data_default_16 = torch.ops.aten._softmax_backward_data.default(view_default_498, _softmax_default_1, -1, torch.float32);  view_default_498 = _softmax_default_1 = None
        where_scalar_self_34 = torch.ops.aten.where.ScalarSelf(eq_scalar_1, 0.0, _softmax_backward_data_default_16);  eq_scalar_1 = _softmax_backward_data_default_16 = None
        view_default_499 = torch.ops.aten.view.default(where_scalar_self_34, [2048, 33, 33]);  where_scalar_self_34 = None
        transpose_int_237 = torch.ops.aten.transpose.int(_unsafe_view_default_12, 1, 2);  _unsafe_view_default_12 = None
        bmm_default_102 = torch.ops.aten.bmm.default(transpose_int_237, view_default_499);  transpose_int_237 = None
        transpose_int_238 = torch.ops.aten.transpose.int(_unsafe_view_default_13, 1, 2);  _unsafe_view_default_13 = None
        bmm_default_103 = torch.ops.aten.bmm.default(view_default_499, transpose_int_238);  view_default_499 = transpose_int_238 = None
        view_default_500 = torch.ops.aten.view.default(bmm_default_102, [256, 8, 64, 33]);  bmm_default_102 = None
        view_default_501 = torch.ops.aten.view.default(bmm_default_103, [256, 8, 33, 64]);  bmm_default_103 = None
        transpose_int_239 = torch.ops.aten.transpose.int(view_default_500, 2, 3);  view_default_500 = None
        div_tensor_34 = torch.ops.aten.div.Tensor(view_default_501, 8.0);  view_default_501 = None
        transpose_int_240 = torch.ops.aten.transpose.int(view_default_497, 1, 2);  view_default_497 = None
        transpose_int_241 = torch.ops.aten.transpose.int(transpose_int_239, 1, 2);  transpose_int_239 = None
        transpose_int_242 = torch.ops.aten.transpose.int(div_tensor_34, 1, 2);  div_tensor_34 = None
        clone_default_150 = torch.ops.aten.clone.default(transpose_int_240, memory_format = torch.contiguous_format);  transpose_int_240 = None
        _unsafe_view_default_228 = torch.ops.aten._unsafe_view.default(clone_default_150, [256, 33, 512]);  clone_default_150 = None
        view_default_502 = torch.ops.aten.view.default(_unsafe_view_default_228, [8448, 512]);  _unsafe_view_default_228 = None
        t_default_449 = torch.ops.aten.t.default(view_default_502)
        mm_default_249 = torch.ops.aten.mm.default(t_default_449, view_default_17);  t_default_449 = view_default_17 = None
        t_default_450 = torch.ops.aten.t.default(mm_default_249);  mm_default_249 = None
        t_default_451 = torch.ops.aten.t.default(t_default_8);  t_default_8 = None
        mm_default_250 = torch.ops.aten.mm.default(view_default_502, t_default_451);  view_default_502 = t_default_451 = None
        view_default_503 = torch.ops.aten.view.default(mm_default_250, [256, 33, 512]);  mm_default_250 = None
        add_tensor_60 = torch.ops.aten.add.Tensor(getitem_180, view_default_503);  getitem_180 = view_default_503 = None
        t_default_452 = torch.ops.aten.t.default(t_default_450);  t_default_450 = None
        view_default_504 = torch.ops.aten.view.default(transpose_int_241, [256, 33, 512]);  transpose_int_241 = None
        clone_default_151 = torch.ops.aten.clone.default(view_default_504, memory_format = torch.contiguous_format);  view_default_504 = None
        _unsafe_view_default_229 = torch.ops.aten._unsafe_view.default(clone_default_151, [8448, 512]);  clone_default_151 = None
        t_default_453 = torch.ops.aten.t.default(_unsafe_view_default_229)
        mm_default_251 = torch.ops.aten.mm.default(t_default_453, view_default_15);  t_default_453 = view_default_15 = None
        t_default_454 = torch.ops.aten.t.default(mm_default_251);  mm_default_251 = None
        t_default_455 = torch.ops.aten.t.default(t_default_7);  t_default_7 = None
        mm_default_252 = torch.ops.aten.mm.default(_unsafe_view_default_229, t_default_455);  _unsafe_view_default_229 = t_default_455 = None
        view_default_505 = torch.ops.aten.view.default(mm_default_252, [256, 33, 512]);  mm_default_252 = None
        add_tensor_61 = torch.ops.aten.add.Tensor(add_tensor_60, view_default_505);  add_tensor_60 = view_default_505 = None
        t_default_456 = torch.ops.aten.t.default(t_default_454);  t_default_454 = None
        clone_default_152 = torch.ops.aten.clone.default(transpose_int_242, memory_format = torch.contiguous_format);  transpose_int_242 = None
        _unsafe_view_default_230 = torch.ops.aten._unsafe_view.default(clone_default_152, [256, 33, 512]);  clone_default_152 = None
        view_default_506 = torch.ops.aten.view.default(_unsafe_view_default_230, [8448, 512]);  _unsafe_view_default_230 = None
        t_default_457 = torch.ops.aten.t.default(view_default_506)
        mm_default_253 = torch.ops.aten.mm.default(t_default_457, view_default_13);  t_default_457 = view_default_13 = None
        t_default_458 = torch.ops.aten.t.default(mm_default_253);  mm_default_253 = None
        t_default_459 = torch.ops.aten.t.default(t_default_6);  t_default_6 = None
        mm_default_254 = torch.ops.aten.mm.default(view_default_506, t_default_459);  view_default_506 = t_default_459 = None
        view_default_507 = torch.ops.aten.view.default(mm_default_254, [256, 33, 512]);  mm_default_254 = None
        add_tensor_62 = torch.ops.aten.add.Tensor(add_tensor_61, view_default_507);  add_tensor_61 = view_default_507 = None
        t_default_460 = torch.ops.aten.t.default(t_default_458);  t_default_458 = None
        native_layer_norm_backward_default_29 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_62, add__tensor_1, [512], getitem_7, getitem_8, primals_116, primals_115, [True, True, True]);  add_tensor_62 = add__tensor_1 = getitem_7 = getitem_8 = primals_116 = primals_115 = None
        getitem_183 = native_layer_norm_backward_default_29[0]
        getitem_184 = native_layer_norm_backward_default_29[1]
        getitem_185 = native_layer_norm_backward_default_29[2];  native_layer_norm_backward_default_29 = None
        new_empty_default_11 = torch.ops.aten.new_empty.default(getitem_183, [4325376]);  getitem_183 = None
        zero__default_11 = torch.ops.aten.zero_.default(new_empty_default_11);  new_empty_default_11 = None
        as_strided_default_34 = torch.ops.aten.as_strided.default(zero__default_11, [8448, 512], [512, 1], 0);  zero__default_11 = None
        new_empty_strided_default_11 = torch.ops.aten.new_empty_strided.default(as_strided_default_34, [8448, 512], [512, 1])
        copy__default_34 = torch.ops.aten.copy_.default(new_empty_strided_default_11, as_strided_default_34);  new_empty_strided_default_11 = as_strided_default_34 = None
        as_strided_default_35 = torch.ops.aten.as_strided.default(copy__default_34, [256, 33, 512], [16896, 512, 1], 0)
        clone_default_153 = torch.ops.aten.clone.default(as_strided_default_35, memory_format = torch.contiguous_format);  as_strided_default_35 = None
        t_default_461 = torch.ops.aten.t.default(t_default_5);  t_default_5 = None
        mm_default_255 = torch.ops.aten.mm.default(copy__default_34, t_default_461);  t_default_461 = None
        t_default_462 = torch.ops.aten.t.default(copy__default_34)
        mm_default_256 = torch.ops.aten.mm.default(t_default_462, view_default_11);  t_default_462 = view_default_11 = None
        t_default_463 = torch.ops.aten.t.default(mm_default_256);  mm_default_256 = None
        sum_dim_int_list_22 = torch.ops.aten.sum.dim_IntList(copy__default_34, [0], True);  copy__default_34 = None
        view_default_508 = torch.ops.aten.view.default(sum_dim_int_list_22, [512]);  sum_dim_int_list_22 = None
        t_default_464 = torch.ops.aten.t.default(t_default_463);  t_default_463 = None
        view_default_509 = torch.ops.aten.view.default(mm_default_255, [256, 33, 2048]);  mm_default_255 = None
        to_dtype_33 = torch.ops.aten.to.dtype(view_default_509, torch.float32);  view_default_509 = None
        to_dtype_34 = torch.ops.aten.to.dtype(relu_default, torch.float32);  relu_default = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        new_zeros_default_11 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_11, to_dtype_33);  le_scalar_11 = new_zeros_default_11 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        view_default_510 = torch.ops.aten.view.default(to_dtype_35, [8448, 2048]);  to_dtype_35 = None
        t_default_465 = torch.ops.aten.t.default(t_default_4);  t_default_4 = None
        mm_default_257 = torch.ops.aten.mm.default(view_default_510, t_default_465);  t_default_465 = None
        t_default_466 = torch.ops.aten.t.default(view_default_510)
        mm_default_258 = torch.ops.aten.mm.default(t_default_466, view_default_9);  t_default_466 = view_default_9 = None
        t_default_467 = torch.ops.aten.t.default(mm_default_258);  mm_default_258 = None
        sum_dim_int_list_23 = torch.ops.aten.sum.dim_IntList(view_default_510, [0], True);  view_default_510 = None
        view_default_511 = torch.ops.aten.view.default(sum_dim_int_list_23, [2048]);  sum_dim_int_list_23 = None
        t_default_468 = torch.ops.aten.t.default(t_default_467);  t_default_467 = None
        view_default_512 = torch.ops.aten.view.default(mm_default_257, [256, 33, 512]);  mm_default_257 = None
        add_tensor_63 = torch.ops.aten.add.Tensor(clone_default_153, view_default_512);  clone_default_153 = view_default_512 = None
        native_layer_norm_backward_default_30 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_63, add__tensor, [512], getitem_4, getitem_5, primals_123, primals_122, [True, True, True]);  add_tensor_63 = add__tensor = getitem_4 = getitem_5 = primals_123 = primals_122 = None
        getitem_186 = native_layer_norm_backward_default_30[0]
        getitem_187 = native_layer_norm_backward_default_30[1]
        getitem_188 = native_layer_norm_backward_default_30[2];  native_layer_norm_backward_default_30 = None
        view_default_513 = torch.ops.aten.view.default(getitem_186, [8448, 512])
        t_default_469 = torch.ops.aten.t.default(view_default_513)
        mm_default_259 = torch.ops.aten.mm.default(t_default_469, view_default_8);  t_default_469 = view_default_8 = None
        t_default_470 = torch.ops.aten.t.default(mm_default_259);  mm_default_259 = None
        t_default_471 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        mm_default_260 = torch.ops.aten.mm.default(view_default_513, t_default_471);  view_default_513 = t_default_471 = None
        view_default_514 = torch.ops.aten.view.default(mm_default_260, [256, 33, 512]);  mm_default_260 = None
        t_default_472 = torch.ops.aten.t.default(t_default_470);  t_default_470 = None
        view_default_515 = torch.ops.aten.view.default(view_default_514, [256, 33, 8, 64]);  view_default_514 = None
        transpose_int_243 = torch.ops.aten.transpose.int(view_default_515, 1, 2);  view_default_515 = None
        clone_default_154 = torch.ops.aten.clone.default(transpose_int_243, memory_format = torch.contiguous_format);  transpose_int_243 = None
        _unsafe_view_default_231 = torch.ops.aten._unsafe_view.default(clone_default_154, [2048, 33, 64]);  clone_default_154 = None
        transpose_int_244 = torch.ops.aten.transpose.int(view_default_6, 1, 2);  view_default_6 = None
        bmm_default_104 = torch.ops.aten.bmm.default(transpose_int_244, _unsafe_view_default_231);  transpose_int_244 = None
        transpose_int_245 = torch.ops.aten.transpose.int(_unsafe_view_default_6, 1, 2);  _unsafe_view_default_6 = None
        bmm_default_105 = torch.ops.aten.bmm.default(_unsafe_view_default_231, transpose_int_245);  _unsafe_view_default_231 = transpose_int_245 = None
        view_default_516 = torch.ops.aten.view.default(bmm_default_104, [256, 8, 33, 64]);  bmm_default_104 = None
        view_default_517 = torch.ops.aten.view.default(bmm_default_105, [256, 8, 33, 33]);  bmm_default_105 = None
        _softmax_backward_data_default_17 = torch.ops.aten._softmax_backward_data.default(view_default_517, _softmax_default, -1, torch.float32);  view_default_517 = _softmax_default = None
        where_scalar_self_35 = torch.ops.aten.where.ScalarSelf(eq_scalar, 0.0, _softmax_backward_data_default_17);  eq_scalar = _softmax_backward_data_default_17 = None
        view_default_518 = torch.ops.aten.view.default(where_scalar_self_35, [2048, 33, 33]);  where_scalar_self_35 = None
        transpose_int_246 = torch.ops.aten.transpose.int(_unsafe_view_default_3, 1, 2);  _unsafe_view_default_3 = None
        bmm_default_106 = torch.ops.aten.bmm.default(transpose_int_246, view_default_518);  transpose_int_246 = None
        transpose_int_247 = torch.ops.aten.transpose.int(_unsafe_view_default_4, 1, 2);  _unsafe_view_default_4 = None
        bmm_default_107 = torch.ops.aten.bmm.default(view_default_518, transpose_int_247);  view_default_518 = transpose_int_247 = None
        view_default_519 = torch.ops.aten.view.default(bmm_default_106, [256, 8, 64, 33]);  bmm_default_106 = None
        view_default_520 = torch.ops.aten.view.default(bmm_default_107, [256, 8, 33, 64]);  bmm_default_107 = None
        transpose_int_248 = torch.ops.aten.transpose.int(view_default_519, 2, 3);  view_default_519 = None
        div_tensor_35 = torch.ops.aten.div.Tensor(view_default_520, 8.0);  view_default_520 = None
        transpose_int_249 = torch.ops.aten.transpose.int(view_default_516, 1, 2);  view_default_516 = None
        transpose_int_250 = torch.ops.aten.transpose.int(transpose_int_248, 1, 2);  transpose_int_248 = None
        transpose_int_251 = torch.ops.aten.transpose.int(div_tensor_35, 1, 2);  div_tensor_35 = None
        clone_default_155 = torch.ops.aten.clone.default(transpose_int_249, memory_format = torch.contiguous_format);  transpose_int_249 = None
        _unsafe_view_default_232 = torch.ops.aten._unsafe_view.default(clone_default_155, [256, 33, 512]);  clone_default_155 = None
        view_default_521 = torch.ops.aten.view.default(_unsafe_view_default_232, [8448, 512]);  _unsafe_view_default_232 = None
        t_default_473 = torch.ops.aten.t.default(view_default_521)
        mm_default_261 = torch.ops.aten.mm.default(t_default_473, view_default_4);  t_default_473 = view_default_4 = None
        t_default_474 = torch.ops.aten.t.default(mm_default_261);  mm_default_261 = None
        t_default_475 = torch.ops.aten.t.default(t_default_2);  t_default_2 = None
        mm_default_262 = torch.ops.aten.mm.default(view_default_521, t_default_475);  view_default_521 = t_default_475 = None
        view_default_522 = torch.ops.aten.view.default(mm_default_262, [256, 33, 512]);  mm_default_262 = None
        add_tensor_64 = torch.ops.aten.add.Tensor(getitem_186, view_default_522);  getitem_186 = view_default_522 = None
        t_default_476 = torch.ops.aten.t.default(t_default_474);  t_default_474 = None
        view_default_523 = torch.ops.aten.view.default(transpose_int_250, [256, 33, 512]);  transpose_int_250 = None
        clone_default_156 = torch.ops.aten.clone.default(view_default_523, memory_format = torch.contiguous_format);  view_default_523 = None
        _unsafe_view_default_233 = torch.ops.aten._unsafe_view.default(clone_default_156, [8448, 512]);  clone_default_156 = None
        t_default_477 = torch.ops.aten.t.default(_unsafe_view_default_233)
        mm_default_263 = torch.ops.aten.mm.default(t_default_477, view_default_2);  t_default_477 = view_default_2 = None
        t_default_478 = torch.ops.aten.t.default(mm_default_263);  mm_default_263 = None
        t_default_479 = torch.ops.aten.t.default(t_default_1);  t_default_1 = None
        mm_default_264 = torch.ops.aten.mm.default(_unsafe_view_default_233, t_default_479);  _unsafe_view_default_233 = t_default_479 = None
        view_default_524 = torch.ops.aten.view.default(mm_default_264, [256, 33, 512]);  mm_default_264 = None
        add_tensor_65 = torch.ops.aten.add.Tensor(add_tensor_64, view_default_524);  add_tensor_64 = view_default_524 = None
        t_default_480 = torch.ops.aten.t.default(t_default_478);  t_default_478 = None
        clone_default_157 = torch.ops.aten.clone.default(transpose_int_251, memory_format = torch.contiguous_format);  transpose_int_251 = None
        _unsafe_view_default_234 = torch.ops.aten._unsafe_view.default(clone_default_157, [256, 33, 512]);  clone_default_157 = None
        view_default_525 = torch.ops.aten.view.default(_unsafe_view_default_234, [8448, 512]);  _unsafe_view_default_234 = None
        t_default_481 = torch.ops.aten.t.default(view_default_525)
        mm_default_265 = torch.ops.aten.mm.default(t_default_481, view_default);  t_default_481 = view_default = None
        t_default_482 = torch.ops.aten.t.default(mm_default_265);  mm_default_265 = None
        t_default_483 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default_266 = torch.ops.aten.mm.default(view_default_525, t_default_483);  view_default_525 = t_default_483 = None
        view_default_526 = torch.ops.aten.view.default(mm_default_266, [256, 33, 512]);  mm_default_266 = None
        add_tensor_66 = torch.ops.aten.add.Tensor(add_tensor_65, view_default_526);  add_tensor_65 = view_default_526 = None
        t_default_484 = torch.ops.aten.t.default(t_default_482);  t_default_482 = None
        native_layer_norm_backward_default_31 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_66, add_tensor, [512], getitem_1, getitem_2, primals_114, primals_113, [True, True, True]);  add_tensor_66 = add_tensor = getitem_1 = getitem_2 = primals_114 = primals_113 = None
        getitem_189 = native_layer_norm_backward_default_31[0]
        getitem_190 = native_layer_norm_backward_default_31[1]
        getitem_191 = native_layer_norm_backward_default_31[2];  native_layer_norm_backward_default_31 = None
        embedding_dense_backward_default_1 = torch.ops.aten.embedding_dense_backward.default(getitem_189, primals_190, 9521, 1, False);  getitem_189 = primals_190 = None
        return [getitem_152, getitem_151, t_default_312, getitem_146, getitem_145, t_default_320, t_default_324, t_default_316, getitem_143, getitem_142, view_default_383, t_default_308, view_default_380, t_default_304, t_default_328, getitem_149, getitem_148, t_default_336, t_default_340, t_default_332, t_default_272, getitem_137, getitem_136, t_default_280, t_default_284, t_default_276, getitem_134, getitem_133, view_default_350, t_default_268, view_default_347, t_default_264, t_default_288, getitem_140, getitem_139, t_default_296, t_default_300, t_default_292, t_default_232, getitem_128, getitem_127, t_default_240, t_default_244, t_default_236, getitem_125, getitem_124, view_default_317, t_default_228, view_default_314, t_default_224, t_default_248, getitem_131, getitem_130, t_default_256, t_default_260, t_default_252, t_default_192, getitem_119, getitem_118, t_default_200, t_default_204, t_default_196, getitem_116, getitem_115, view_default_284, t_default_188, view_default_281, t_default_184, t_default_208, getitem_122, getitem_121, t_default_216, t_default_220, t_default_212, t_default_152, getitem_110, getitem_109, t_default_160, t_default_164, t_default_156, getitem_107, getitem_106, view_default_251, t_default_148, view_default_248, t_default_144, t_default_168, getitem_113, getitem_112, t_default_176, t_default_180, t_default_172, t_default_112, getitem_101, getitem_100, t_default_120, t_default_124, t_default_116, getitem_98, getitem_97, view_default_218, t_default_108, view_default_215, t_default_104, t_default_128, getitem_104, getitem_103, t_default_136, t_default_140, t_default_132, None, embedding_dense_backward_default, getitem_191, getitem_190, getitem_185, getitem_184, view_default_511, t_default_468, view_default_508, t_default_464, t_default_472, getitem_188, getitem_187, t_default_480, t_default_484, t_default_476, getitem_179, getitem_178, view_default_492, t_default_444, view_default_489, t_default_440, t_default_448, getitem_182, getitem_181, t_default_456, t_default_460, t_default_452, getitem_173, getitem_172, view_default_473, t_default_420, view_default_470, t_default_416, t_default_424, getitem_176, getitem_175, t_default_432, t_default_436, t_default_428, getitem_167, getitem_166, view_default_454, t_default_396, view_default_451, t_default_392, t_default_400, getitem_170, getitem_169, t_default_408, t_default_412, t_default_404, getitem_161, getitem_160, view_default_435, t_default_372, view_default_432, t_default_368, t_default_376, getitem_164, getitem_163, t_default_384, t_default_388, t_default_380, getitem_155, getitem_154, view_default_416, t_default_348, view_default_413, t_default_344, t_default_352, getitem_158, getitem_157, t_default_360, t_default_364, t_default_356, None, embedding_dense_backward_default_1, t_default_100, None, None]
        
