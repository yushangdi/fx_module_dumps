
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/attention_is_all_you_need_pytorch/attention_is_all_you_need_pytorch_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191):
        ne_scalar = torch.ops.aten.ne.Scalar(primals_190, 1)
        unsqueeze_default = torch.ops.aten.unsqueeze.default(ne_scalar, -2);  ne_scalar = None
        ne_scalar_1 = torch.ops.aten.ne.Scalar(primals_191, 1)
        unsqueeze_default_1 = torch.ops.aten.unsqueeze.default(ne_scalar_1, -2);  ne_scalar_1 = None
        ones = torch.ops.aten.ones.default([1, 31, 31], dtype = torch.float32, device = device(type='cuda', index=0), pin_memory = False)
        triu_default = torch.ops.aten.triu.default(ones, 1);  ones = None
        rsub_scalar = torch.ops.aten.rsub.Scalar(triu_default, 1);  triu_default = None
        _to_copy_default = torch.ops.aten._to_copy.default(rsub_scalar, dtype = torch.bool);  rsub_scalar = None
        bitwise_and_tensor = torch.ops.aten.bitwise_and.Tensor(unsqueeze_default_1, _to_copy_default);  unsqueeze_default_1 = _to_copy_default = None
        embedding_default = torch.ops.aten.embedding.default(primals_188, primals_190, 1);  primals_188 = None
        slice_tensor = torch.ops.aten.slice.Tensor(primals_187, 0, 0, 9223372036854775807);  primals_187 = None
        slice_tensor_1 = torch.ops.aten.slice.Tensor(slice_tensor, 1, 0, 33);  slice_tensor = None
        clone_default = torch.ops.aten.clone.default(slice_tensor_1);  slice_tensor_1 = None
        add_tensor = torch.ops.aten.add.Tensor(embedding_default, clone_default);  embedding_default = clone_default = None
        native_layer_norm_default = torch.ops.aten.native_layer_norm.default(add_tensor, [512], primals_114, primals_113, 1e-06)
        getitem = native_layer_norm_default[0]
        getitem_1 = native_layer_norm_default[1]
        getitem_2 = native_layer_norm_default[2];  native_layer_norm_default = None
        t_default = torch.ops.aten.t.default(primals_125);  primals_125 = None
        view_default = torch.ops.aten.view.default(getitem, [8448, 512])
        mm_default = torch.ops.aten.mm.default(view_default, t_default)
        _unsafe_view_default = torch.ops.aten._unsafe_view.default(mm_default, [256, 33, 512]);  mm_default = None
        view_default_1 = torch.ops.aten.view.default(_unsafe_view_default, [256, 33, 8, 64]);  _unsafe_view_default = None
        t_default_1 = torch.ops.aten.t.default(primals_124);  primals_124 = None
        view_default_2 = torch.ops.aten.view.default(getitem, [8448, 512])
        mm_default_1 = torch.ops.aten.mm.default(view_default_2, t_default_1)
        _unsafe_view_default_1 = torch.ops.aten._unsafe_view.default(mm_default_1, [256, 33, 512]);  mm_default_1 = None
        view_default_3 = torch.ops.aten.view.default(_unsafe_view_default_1, [256, 33, 8, 64]);  _unsafe_view_default_1 = None
        t_default_2 = torch.ops.aten.t.default(primals_126);  primals_126 = None
        view_default_4 = torch.ops.aten.view.default(getitem, [8448, 512])
        mm_default_2 = torch.ops.aten.mm.default(view_default_4, t_default_2)
        _unsafe_view_default_2 = torch.ops.aten._unsafe_view.default(mm_default_2, [256, 33, 512]);  mm_default_2 = None
        view_default_5 = torch.ops.aten.view.default(_unsafe_view_default_2, [256, 33, 8, 64]);  _unsafe_view_default_2 = None
        transpose_int = torch.ops.aten.transpose.int(view_default_1, 1, 2);  view_default_1 = None
        transpose_int_1 = torch.ops.aten.transpose.int(view_default_3, 1, 2);  view_default_3 = None
        transpose_int_2 = torch.ops.aten.transpose.int(view_default_5, 1, 2);  view_default_5 = None
        unsqueeze_default_2 = torch.ops.aten.unsqueeze.default(unsqueeze_default, 1)
        div_tensor = torch.ops.aten.div.Tensor(transpose_int, 8.0);  transpose_int = None
        transpose_int_3 = torch.ops.aten.transpose.int(transpose_int_1, 2, 3);  transpose_int_1 = None
        expand_default = torch.ops.aten.expand.default(div_tensor, [256, 8, 33, 64]);  div_tensor = None
        clone_default_1 = torch.ops.aten.clone.default(expand_default, memory_format = torch.contiguous_format);  expand_default = None
        _unsafe_view_default_3 = torch.ops.aten._unsafe_view.default(clone_default_1, [2048, 33, 64]);  clone_default_1 = None
        expand_default_1 = torch.ops.aten.expand.default(transpose_int_3, [256, 8, 64, 33]);  transpose_int_3 = None
        clone_default_2 = torch.ops.aten.clone.default(expand_default_1, memory_format = torch.contiguous_format);  expand_default_1 = None
        _unsafe_view_default_4 = torch.ops.aten._unsafe_view.default(clone_default_2, [2048, 64, 33]);  clone_default_2 = None
        bmm_default = torch.ops.aten.bmm.default(_unsafe_view_default_3, _unsafe_view_default_4)
        _unsafe_view_default_5 = torch.ops.aten._unsafe_view.default(bmm_default, [256, 8, 33, 33]);  bmm_default = None
        eq_scalar = torch.ops.aten.eq.Scalar(unsqueeze_default_2, 0);  unsqueeze_default_2 = None
        where_scalar_self = torch.ops.aten.where.ScalarSelf(eq_scalar, -1000000000.0, _unsafe_view_default_5);  _unsafe_view_default_5 = None
        _softmax_default = torch.ops.aten._softmax.default(where_scalar_self, -1, False);  where_scalar_self = None
        expand_default_2 = torch.ops.aten.expand.default(_softmax_default, [256, 8, 33, 33])
        view_default_6 = torch.ops.aten.view.default(expand_default_2, [2048, 33, 33]);  expand_default_2 = None
        expand_default_3 = torch.ops.aten.expand.default(transpose_int_2, [256, 8, 33, 64]);  transpose_int_2 = None
        clone_default_3 = torch.ops.aten.clone.default(expand_default_3, memory_format = torch.contiguous_format);  expand_default_3 = None
        _unsafe_view_default_6 = torch.ops.aten._unsafe_view.default(clone_default_3, [2048, 33, 64]);  clone_default_3 = None
        bmm_default_1 = torch.ops.aten.bmm.default(view_default_6, _unsafe_view_default_6)
        _unsafe_view_default_7 = torch.ops.aten._unsafe_view.default(bmm_default_1, [256, 8, 33, 64]);  bmm_default_1 = None
        transpose_int_4 = torch.ops.aten.transpose.int(_unsafe_view_default_7, 1, 2);  _unsafe_view_default_7 = None
        clone_default_4 = torch.ops.aten.clone.default(transpose_int_4, memory_format = torch.contiguous_format);  transpose_int_4 = None
        view_default_7 = torch.ops.aten.view.default(clone_default_4, [256, 33, -1]);  clone_default_4 = None
        t_default_3 = torch.ops.aten.t.default(primals_121);  primals_121 = None
        view_default_8 = torch.ops.aten.view.default(view_default_7, [8448, 512]);  view_default_7 = None
        mm_default_3 = torch.ops.aten.mm.default(view_default_8, t_default_3)
        _unsafe_view_default_8 = torch.ops.aten._unsafe_view.default(mm_default_3, [256, 33, 512]);  mm_default_3 = None
        add__tensor = torch.ops.aten.add_.Tensor(_unsafe_view_default_8, getitem);  _unsafe_view_default_8 = getitem = None
        native_layer_norm_default_1 = torch.ops.aten.native_layer_norm.default(add__tensor, [512], primals_123, primals_122, 1e-06)
        getitem_3 = native_layer_norm_default_1[0]
        getitem_4 = native_layer_norm_default_1[1]
        getitem_5 = native_layer_norm_default_1[2];  native_layer_norm_default_1 = None
        view_default_9 = torch.ops.aten.view.default(getitem_3, [8448, 512])
        t_default_4 = torch.ops.aten.t.default(primals_118);  primals_118 = None
        addmm_default = torch.ops.aten.addmm.default(primals_117, view_default_9, t_default_4);  primals_117 = None
        view_default_10 = torch.ops.aten.view.default(addmm_default, [256, 33, 2048]);  addmm_default = None
        relu_default = torch.ops.aten.relu.default(view_default_10);  view_default_10 = None
        view_default_11 = torch.ops.aten.view.default(relu_default, [8448, 2048])
        t_default_5 = torch.ops.aten.t.default(primals_120);  primals_120 = None
        addmm_default_1 = torch.ops.aten.addmm.default(primals_119, view_default_11, t_default_5);  primals_119 = None
        view_default_12 = torch.ops.aten.view.default(addmm_default_1, [256, 33, 512]);  addmm_default_1 = None
        add__tensor_1 = torch.ops.aten.add_.Tensor(view_default_12, getitem_3);  view_default_12 = getitem_3 = None
        native_layer_norm_default_2 = torch.ops.aten.native_layer_norm.default(add__tensor_1, [512], primals_116, primals_115, 1e-06)
        getitem_6 = native_layer_norm_default_2[0]
        getitem_7 = native_layer_norm_default_2[1]
        getitem_8 = native_layer_norm_default_2[2];  native_layer_norm_default_2 = None
        t_default_6 = torch.ops.aten.t.default(primals_137);  primals_137 = None
        view_default_13 = torch.ops.aten.view.default(getitem_6, [8448, 512])
        mm_default_4 = torch.ops.aten.mm.default(view_default_13, t_default_6)
        _unsafe_view_default_9 = torch.ops.aten._unsafe_view.default(mm_default_4, [256, 33, 512]);  mm_default_4 = None
        view_default_14 = torch.ops.aten.view.default(_unsafe_view_default_9, [256, 33, 8, 64]);  _unsafe_view_default_9 = None
        t_default_7 = torch.ops.aten.t.default(primals_136);  primals_136 = None
        view_default_15 = torch.ops.aten.view.default(getitem_6, [8448, 512])
        mm_default_5 = torch.ops.aten.mm.default(view_default_15, t_default_7)
        _unsafe_view_default_10 = torch.ops.aten._unsafe_view.default(mm_default_5, [256, 33, 512]);  mm_default_5 = None
        view_default_16 = torch.ops.aten.view.default(_unsafe_view_default_10, [256, 33, 8, 64]);  _unsafe_view_default_10 = None
        t_default_8 = torch.ops.aten.t.default(primals_138);  primals_138 = None
        view_default_17 = torch.ops.aten.view.default(getitem_6, [8448, 512])
        mm_default_6 = torch.ops.aten.mm.default(view_default_17, t_default_8)
        _unsafe_view_default_11 = torch.ops.aten._unsafe_view.default(mm_default_6, [256, 33, 512]);  mm_default_6 = None
        view_default_18 = torch.ops.aten.view.default(_unsafe_view_default_11, [256, 33, 8, 64]);  _unsafe_view_default_11 = None
        transpose_int_5 = torch.ops.aten.transpose.int(view_default_14, 1, 2);  view_default_14 = None
        transpose_int_6 = torch.ops.aten.transpose.int(view_default_16, 1, 2);  view_default_16 = None
        transpose_int_7 = torch.ops.aten.transpose.int(view_default_18, 1, 2);  view_default_18 = None
        unsqueeze_default_3 = torch.ops.aten.unsqueeze.default(unsqueeze_default, 1)
        div_tensor_1 = torch.ops.aten.div.Tensor(transpose_int_5, 8.0);  transpose_int_5 = None
        transpose_int_8 = torch.ops.aten.transpose.int(transpose_int_6, 2, 3);  transpose_int_6 = None
        expand_default_4 = torch.ops.aten.expand.default(div_tensor_1, [256, 8, 33, 64]);  div_tensor_1 = None
        clone_default_5 = torch.ops.aten.clone.default(expand_default_4, memory_format = torch.contiguous_format);  expand_default_4 = None
        _unsafe_view_default_12 = torch.ops.aten._unsafe_view.default(clone_default_5, [2048, 33, 64]);  clone_default_5 = None
        expand_default_5 = torch.ops.aten.expand.default(transpose_int_8, [256, 8, 64, 33]);  transpose_int_8 = None
        clone_default_6 = torch.ops.aten.clone.default(expand_default_5, memory_format = torch.contiguous_format);  expand_default_5 = None
        _unsafe_view_default_13 = torch.ops.aten._unsafe_view.default(clone_default_6, [2048, 64, 33]);  clone_default_6 = None
        bmm_default_2 = torch.ops.aten.bmm.default(_unsafe_view_default_12, _unsafe_view_default_13)
        _unsafe_view_default_14 = torch.ops.aten._unsafe_view.default(bmm_default_2, [256, 8, 33, 33]);  bmm_default_2 = None
        eq_scalar_1 = torch.ops.aten.eq.Scalar(unsqueeze_default_3, 0);  unsqueeze_default_3 = None
        where_scalar_self_1 = torch.ops.aten.where.ScalarSelf(eq_scalar_1, -1000000000.0, _unsafe_view_default_14);  _unsafe_view_default_14 = None
        _softmax_default_1 = torch.ops.aten._softmax.default(where_scalar_self_1, -1, False);  where_scalar_self_1 = None
        expand_default_6 = torch.ops.aten.expand.default(_softmax_default_1, [256, 8, 33, 33])
        view_default_19 = torch.ops.aten.view.default(expand_default_6, [2048, 33, 33]);  expand_default_6 = None
        expand_default_7 = torch.ops.aten.expand.default(transpose_int_7, [256, 8, 33, 64]);  transpose_int_7 = None
        clone_default_7 = torch.ops.aten.clone.default(expand_default_7, memory_format = torch.contiguous_format);  expand_default_7 = None
        _unsafe_view_default_15 = torch.ops.aten._unsafe_view.default(clone_default_7, [2048, 33, 64]);  clone_default_7 = None
        bmm_default_3 = torch.ops.aten.bmm.default(view_default_19, _unsafe_view_default_15)
        _unsafe_view_default_16 = torch.ops.aten._unsafe_view.default(bmm_default_3, [256, 8, 33, 64]);  bmm_default_3 = None
        transpose_int_9 = torch.ops.aten.transpose.int(_unsafe_view_default_16, 1, 2);  _unsafe_view_default_16 = None
        clone_default_8 = torch.ops.aten.clone.default(transpose_int_9, memory_format = torch.contiguous_format);  transpose_int_9 = None
        view_default_20 = torch.ops.aten.view.default(clone_default_8, [256, 33, -1]);  clone_default_8 = None
        t_default_9 = torch.ops.aten.t.default(primals_133);  primals_133 = None
        view_default_21 = torch.ops.aten.view.default(view_default_20, [8448, 512]);  view_default_20 = None
        mm_default_7 = torch.ops.aten.mm.default(view_default_21, t_default_9)
        _unsafe_view_default_17 = torch.ops.aten._unsafe_view.default(mm_default_7, [256, 33, 512]);  mm_default_7 = None
        add__tensor_2 = torch.ops.aten.add_.Tensor(_unsafe_view_default_17, getitem_6);  _unsafe_view_default_17 = getitem_6 = None
        native_layer_norm_default_3 = torch.ops.aten.native_layer_norm.default(add__tensor_2, [512], primals_135, primals_134, 1e-06)
        getitem_9 = native_layer_norm_default_3[0]
        getitem_10 = native_layer_norm_default_3[1]
        getitem_11 = native_layer_norm_default_3[2];  native_layer_norm_default_3 = None
        view_default_22 = torch.ops.aten.view.default(getitem_9, [8448, 512])
        t_default_10 = torch.ops.aten.t.default(primals_130);  primals_130 = None
        addmm_default_2 = torch.ops.aten.addmm.default(primals_129, view_default_22, t_default_10);  primals_129 = None
        view_default_23 = torch.ops.aten.view.default(addmm_default_2, [256, 33, 2048]);  addmm_default_2 = None
        relu_default_1 = torch.ops.aten.relu.default(view_default_23);  view_default_23 = None
        view_default_24 = torch.ops.aten.view.default(relu_default_1, [8448, 2048])
        t_default_11 = torch.ops.aten.t.default(primals_132);  primals_132 = None
        addmm_default_3 = torch.ops.aten.addmm.default(primals_131, view_default_24, t_default_11);  primals_131 = None
        view_default_25 = torch.ops.aten.view.default(addmm_default_3, [256, 33, 512]);  addmm_default_3 = None
        add__tensor_3 = torch.ops.aten.add_.Tensor(view_default_25, getitem_9);  view_default_25 = getitem_9 = None
        native_layer_norm_default_4 = torch.ops.aten.native_layer_norm.default(add__tensor_3, [512], primals_128, primals_127, 1e-06)
        getitem_12 = native_layer_norm_default_4[0]
        getitem_13 = native_layer_norm_default_4[1]
        getitem_14 = native_layer_norm_default_4[2];  native_layer_norm_default_4 = None
        t_default_12 = torch.ops.aten.t.default(primals_149);  primals_149 = None
        view_default_26 = torch.ops.aten.view.default(getitem_12, [8448, 512])
        mm_default_8 = torch.ops.aten.mm.default(view_default_26, t_default_12)
        _unsafe_view_default_18 = torch.ops.aten._unsafe_view.default(mm_default_8, [256, 33, 512]);  mm_default_8 = None
        view_default_27 = torch.ops.aten.view.default(_unsafe_view_default_18, [256, 33, 8, 64]);  _unsafe_view_default_18 = None
        t_default_13 = torch.ops.aten.t.default(primals_148);  primals_148 = None
        view_default_28 = torch.ops.aten.view.default(getitem_12, [8448, 512])
        mm_default_9 = torch.ops.aten.mm.default(view_default_28, t_default_13)
        _unsafe_view_default_19 = torch.ops.aten._unsafe_view.default(mm_default_9, [256, 33, 512]);  mm_default_9 = None
        view_default_29 = torch.ops.aten.view.default(_unsafe_view_default_19, [256, 33, 8, 64]);  _unsafe_view_default_19 = None
        t_default_14 = torch.ops.aten.t.default(primals_150);  primals_150 = None
        view_default_30 = torch.ops.aten.view.default(getitem_12, [8448, 512])
        mm_default_10 = torch.ops.aten.mm.default(view_default_30, t_default_14)
        _unsafe_view_default_20 = torch.ops.aten._unsafe_view.default(mm_default_10, [256, 33, 512]);  mm_default_10 = None
        view_default_31 = torch.ops.aten.view.default(_unsafe_view_default_20, [256, 33, 8, 64]);  _unsafe_view_default_20 = None
        transpose_int_10 = torch.ops.aten.transpose.int(view_default_27, 1, 2);  view_default_27 = None
        transpose_int_11 = torch.ops.aten.transpose.int(view_default_29, 1, 2);  view_default_29 = None
        transpose_int_12 = torch.ops.aten.transpose.int(view_default_31, 1, 2);  view_default_31 = None
        unsqueeze_default_4 = torch.ops.aten.unsqueeze.default(unsqueeze_default, 1)
        div_tensor_2 = torch.ops.aten.div.Tensor(transpose_int_10, 8.0);  transpose_int_10 = None
        transpose_int_13 = torch.ops.aten.transpose.int(transpose_int_11, 2, 3);  transpose_int_11 = None
        expand_default_8 = torch.ops.aten.expand.default(div_tensor_2, [256, 8, 33, 64]);  div_tensor_2 = None
        clone_default_9 = torch.ops.aten.clone.default(expand_default_8, memory_format = torch.contiguous_format);  expand_default_8 = None
        _unsafe_view_default_21 = torch.ops.aten._unsafe_view.default(clone_default_9, [2048, 33, 64]);  clone_default_9 = None
        expand_default_9 = torch.ops.aten.expand.default(transpose_int_13, [256, 8, 64, 33]);  transpose_int_13 = None
        clone_default_10 = torch.ops.aten.clone.default(expand_default_9, memory_format = torch.contiguous_format);  expand_default_9 = None
        _unsafe_view_default_22 = torch.ops.aten._unsafe_view.default(clone_default_10, [2048, 64, 33]);  clone_default_10 = None
        bmm_default_4 = torch.ops.aten.bmm.default(_unsafe_view_default_21, _unsafe_view_default_22)
        _unsafe_view_default_23 = torch.ops.aten._unsafe_view.default(bmm_default_4, [256, 8, 33, 33]);  bmm_default_4 = None
        eq_scalar_2 = torch.ops.aten.eq.Scalar(unsqueeze_default_4, 0);  unsqueeze_default_4 = None
        where_scalar_self_2 = torch.ops.aten.where.ScalarSelf(eq_scalar_2, -1000000000.0, _unsafe_view_default_23);  _unsafe_view_default_23 = None
        _softmax_default_2 = torch.ops.aten._softmax.default(where_scalar_self_2, -1, False);  where_scalar_self_2 = None
        expand_default_10 = torch.ops.aten.expand.default(_softmax_default_2, [256, 8, 33, 33])
        view_default_32 = torch.ops.aten.view.default(expand_default_10, [2048, 33, 33]);  expand_default_10 = None
        expand_default_11 = torch.ops.aten.expand.default(transpose_int_12, [256, 8, 33, 64]);  transpose_int_12 = None
        clone_default_11 = torch.ops.aten.clone.default(expand_default_11, memory_format = torch.contiguous_format);  expand_default_11 = None
        _unsafe_view_default_24 = torch.ops.aten._unsafe_view.default(clone_default_11, [2048, 33, 64]);  clone_default_11 = None
        bmm_default_5 = torch.ops.aten.bmm.default(view_default_32, _unsafe_view_default_24)
        _unsafe_view_default_25 = torch.ops.aten._unsafe_view.default(bmm_default_5, [256, 8, 33, 64]);  bmm_default_5 = None
        transpose_int_14 = torch.ops.aten.transpose.int(_unsafe_view_default_25, 1, 2);  _unsafe_view_default_25 = None
        clone_default_12 = torch.ops.aten.clone.default(transpose_int_14, memory_format = torch.contiguous_format);  transpose_int_14 = None
        view_default_33 = torch.ops.aten.view.default(clone_default_12, [256, 33, -1]);  clone_default_12 = None
        t_default_15 = torch.ops.aten.t.default(primals_145);  primals_145 = None
        view_default_34 = torch.ops.aten.view.default(view_default_33, [8448, 512]);  view_default_33 = None
        mm_default_11 = torch.ops.aten.mm.default(view_default_34, t_default_15)
        _unsafe_view_default_26 = torch.ops.aten._unsafe_view.default(mm_default_11, [256, 33, 512]);  mm_default_11 = None
        add__tensor_4 = torch.ops.aten.add_.Tensor(_unsafe_view_default_26, getitem_12);  _unsafe_view_default_26 = getitem_12 = None
        native_layer_norm_default_5 = torch.ops.aten.native_layer_norm.default(add__tensor_4, [512], primals_147, primals_146, 1e-06)
        getitem_15 = native_layer_norm_default_5[0]
        getitem_16 = native_layer_norm_default_5[1]
        getitem_17 = native_layer_norm_default_5[2];  native_layer_norm_default_5 = None
        view_default_35 = torch.ops.aten.view.default(getitem_15, [8448, 512])
        t_default_16 = torch.ops.aten.t.default(primals_142);  primals_142 = None
        addmm_default_4 = torch.ops.aten.addmm.default(primals_141, view_default_35, t_default_16);  primals_141 = None
        view_default_36 = torch.ops.aten.view.default(addmm_default_4, [256, 33, 2048]);  addmm_default_4 = None
        relu_default_2 = torch.ops.aten.relu.default(view_default_36);  view_default_36 = None
        view_default_37 = torch.ops.aten.view.default(relu_default_2, [8448, 2048])
        t_default_17 = torch.ops.aten.t.default(primals_144);  primals_144 = None
        addmm_default_5 = torch.ops.aten.addmm.default(primals_143, view_default_37, t_default_17);  primals_143 = None
        view_default_38 = torch.ops.aten.view.default(addmm_default_5, [256, 33, 512]);  addmm_default_5 = None
        add__tensor_5 = torch.ops.aten.add_.Tensor(view_default_38, getitem_15);  view_default_38 = getitem_15 = None
        native_layer_norm_default_6 = torch.ops.aten.native_layer_norm.default(add__tensor_5, [512], primals_140, primals_139, 1e-06)
        getitem_18 = native_layer_norm_default_6[0]
        getitem_19 = native_layer_norm_default_6[1]
        getitem_20 = native_layer_norm_default_6[2];  native_layer_norm_default_6 = None
        t_default_18 = torch.ops.aten.t.default(primals_161);  primals_161 = None
        view_default_39 = torch.ops.aten.view.default(getitem_18, [8448, 512])
        mm_default_12 = torch.ops.aten.mm.default(view_default_39, t_default_18)
        _unsafe_view_default_27 = torch.ops.aten._unsafe_view.default(mm_default_12, [256, 33, 512]);  mm_default_12 = None
        view_default_40 = torch.ops.aten.view.default(_unsafe_view_default_27, [256, 33, 8, 64]);  _unsafe_view_default_27 = None
        t_default_19 = torch.ops.aten.t.default(primals_160);  primals_160 = None
        view_default_41 = torch.ops.aten.view.default(getitem_18, [8448, 512])
        mm_default_13 = torch.ops.aten.mm.default(view_default_41, t_default_19)
        _unsafe_view_default_28 = torch.ops.aten._unsafe_view.default(mm_default_13, [256, 33, 512]);  mm_default_13 = None
        view_default_42 = torch.ops.aten.view.default(_unsafe_view_default_28, [256, 33, 8, 64]);  _unsafe_view_default_28 = None
        t_default_20 = torch.ops.aten.t.default(primals_162);  primals_162 = None
        view_default_43 = torch.ops.aten.view.default(getitem_18, [8448, 512])
        mm_default_14 = torch.ops.aten.mm.default(view_default_43, t_default_20)
        _unsafe_view_default_29 = torch.ops.aten._unsafe_view.default(mm_default_14, [256, 33, 512]);  mm_default_14 = None
        view_default_44 = torch.ops.aten.view.default(_unsafe_view_default_29, [256, 33, 8, 64]);  _unsafe_view_default_29 = None
        transpose_int_15 = torch.ops.aten.transpose.int(view_default_40, 1, 2);  view_default_40 = None
        transpose_int_16 = torch.ops.aten.transpose.int(view_default_42, 1, 2);  view_default_42 = None
        transpose_int_17 = torch.ops.aten.transpose.int(view_default_44, 1, 2);  view_default_44 = None
        unsqueeze_default_5 = torch.ops.aten.unsqueeze.default(unsqueeze_default, 1)
        div_tensor_3 = torch.ops.aten.div.Tensor(transpose_int_15, 8.0);  transpose_int_15 = None
        transpose_int_18 = torch.ops.aten.transpose.int(transpose_int_16, 2, 3);  transpose_int_16 = None
        expand_default_12 = torch.ops.aten.expand.default(div_tensor_3, [256, 8, 33, 64]);  div_tensor_3 = None
        clone_default_13 = torch.ops.aten.clone.default(expand_default_12, memory_format = torch.contiguous_format);  expand_default_12 = None
        _unsafe_view_default_30 = torch.ops.aten._unsafe_view.default(clone_default_13, [2048, 33, 64]);  clone_default_13 = None
        expand_default_13 = torch.ops.aten.expand.default(transpose_int_18, [256, 8, 64, 33]);  transpose_int_18 = None
        clone_default_14 = torch.ops.aten.clone.default(expand_default_13, memory_format = torch.contiguous_format);  expand_default_13 = None
        _unsafe_view_default_31 = torch.ops.aten._unsafe_view.default(clone_default_14, [2048, 64, 33]);  clone_default_14 = None
        bmm_default_6 = torch.ops.aten.bmm.default(_unsafe_view_default_30, _unsafe_view_default_31)
        _unsafe_view_default_32 = torch.ops.aten._unsafe_view.default(bmm_default_6, [256, 8, 33, 33]);  bmm_default_6 = None
        eq_scalar_3 = torch.ops.aten.eq.Scalar(unsqueeze_default_5, 0);  unsqueeze_default_5 = None
        where_scalar_self_3 = torch.ops.aten.where.ScalarSelf(eq_scalar_3, -1000000000.0, _unsafe_view_default_32);  _unsafe_view_default_32 = None
        _softmax_default_3 = torch.ops.aten._softmax.default(where_scalar_self_3, -1, False);  where_scalar_self_3 = None
        expand_default_14 = torch.ops.aten.expand.default(_softmax_default_3, [256, 8, 33, 33])
        view_default_45 = torch.ops.aten.view.default(expand_default_14, [2048, 33, 33]);  expand_default_14 = None
        expand_default_15 = torch.ops.aten.expand.default(transpose_int_17, [256, 8, 33, 64]);  transpose_int_17 = None
        clone_default_15 = torch.ops.aten.clone.default(expand_default_15, memory_format = torch.contiguous_format);  expand_default_15 = None
        _unsafe_view_default_33 = torch.ops.aten._unsafe_view.default(clone_default_15, [2048, 33, 64]);  clone_default_15 = None
        bmm_default_7 = torch.ops.aten.bmm.default(view_default_45, _unsafe_view_default_33)
        _unsafe_view_default_34 = torch.ops.aten._unsafe_view.default(bmm_default_7, [256, 8, 33, 64]);  bmm_default_7 = None
        transpose_int_19 = torch.ops.aten.transpose.int(_unsafe_view_default_34, 1, 2);  _unsafe_view_default_34 = None
        clone_default_16 = torch.ops.aten.clone.default(transpose_int_19, memory_format = torch.contiguous_format);  transpose_int_19 = None
        view_default_46 = torch.ops.aten.view.default(clone_default_16, [256, 33, -1]);  clone_default_16 = None
        t_default_21 = torch.ops.aten.t.default(primals_157);  primals_157 = None
        view_default_47 = torch.ops.aten.view.default(view_default_46, [8448, 512]);  view_default_46 = None
        mm_default_15 = torch.ops.aten.mm.default(view_default_47, t_default_21)
        _unsafe_view_default_35 = torch.ops.aten._unsafe_view.default(mm_default_15, [256, 33, 512]);  mm_default_15 = None
        add__tensor_6 = torch.ops.aten.add_.Tensor(_unsafe_view_default_35, getitem_18);  _unsafe_view_default_35 = getitem_18 = None
        native_layer_norm_default_7 = torch.ops.aten.native_layer_norm.default(add__tensor_6, [512], primals_159, primals_158, 1e-06)
        getitem_21 = native_layer_norm_default_7[0]
        getitem_22 = native_layer_norm_default_7[1]
        getitem_23 = native_layer_norm_default_7[2];  native_layer_norm_default_7 = None
        view_default_48 = torch.ops.aten.view.default(getitem_21, [8448, 512])
        t_default_22 = torch.ops.aten.t.default(primals_154);  primals_154 = None
        addmm_default_6 = torch.ops.aten.addmm.default(primals_153, view_default_48, t_default_22);  primals_153 = None
        view_default_49 = torch.ops.aten.view.default(addmm_default_6, [256, 33, 2048]);  addmm_default_6 = None
        relu_default_3 = torch.ops.aten.relu.default(view_default_49);  view_default_49 = None
        view_default_50 = torch.ops.aten.view.default(relu_default_3, [8448, 2048])
        t_default_23 = torch.ops.aten.t.default(primals_156);  primals_156 = None
        addmm_default_7 = torch.ops.aten.addmm.default(primals_155, view_default_50, t_default_23);  primals_155 = None
        view_default_51 = torch.ops.aten.view.default(addmm_default_7, [256, 33, 512]);  addmm_default_7 = None
        add__tensor_7 = torch.ops.aten.add_.Tensor(view_default_51, getitem_21);  view_default_51 = getitem_21 = None
        native_layer_norm_default_8 = torch.ops.aten.native_layer_norm.default(add__tensor_7, [512], primals_152, primals_151, 1e-06)
        getitem_24 = native_layer_norm_default_8[0]
        getitem_25 = native_layer_norm_default_8[1]
        getitem_26 = native_layer_norm_default_8[2];  native_layer_norm_default_8 = None
        t_default_24 = torch.ops.aten.t.default(primals_173);  primals_173 = None
        view_default_52 = torch.ops.aten.view.default(getitem_24, [8448, 512])
        mm_default_16 = torch.ops.aten.mm.default(view_default_52, t_default_24)
        _unsafe_view_default_36 = torch.ops.aten._unsafe_view.default(mm_default_16, [256, 33, 512]);  mm_default_16 = None
        view_default_53 = torch.ops.aten.view.default(_unsafe_view_default_36, [256, 33, 8, 64]);  _unsafe_view_default_36 = None
        t_default_25 = torch.ops.aten.t.default(primals_172);  primals_172 = None
        view_default_54 = torch.ops.aten.view.default(getitem_24, [8448, 512])
        mm_default_17 = torch.ops.aten.mm.default(view_default_54, t_default_25)
        _unsafe_view_default_37 = torch.ops.aten._unsafe_view.default(mm_default_17, [256, 33, 512]);  mm_default_17 = None
        view_default_55 = torch.ops.aten.view.default(_unsafe_view_default_37, [256, 33, 8, 64]);  _unsafe_view_default_37 = None
        t_default_26 = torch.ops.aten.t.default(primals_174);  primals_174 = None
        view_default_56 = torch.ops.aten.view.default(getitem_24, [8448, 512])
        mm_default_18 = torch.ops.aten.mm.default(view_default_56, t_default_26)
        _unsafe_view_default_38 = torch.ops.aten._unsafe_view.default(mm_default_18, [256, 33, 512]);  mm_default_18 = None
        view_default_57 = torch.ops.aten.view.default(_unsafe_view_default_38, [256, 33, 8, 64]);  _unsafe_view_default_38 = None
        transpose_int_20 = torch.ops.aten.transpose.int(view_default_53, 1, 2);  view_default_53 = None
        transpose_int_21 = torch.ops.aten.transpose.int(view_default_55, 1, 2);  view_default_55 = None
        transpose_int_22 = torch.ops.aten.transpose.int(view_default_57, 1, 2);  view_default_57 = None
        unsqueeze_default_6 = torch.ops.aten.unsqueeze.default(unsqueeze_default, 1)
        div_tensor_4 = torch.ops.aten.div.Tensor(transpose_int_20, 8.0);  transpose_int_20 = None
        transpose_int_23 = torch.ops.aten.transpose.int(transpose_int_21, 2, 3);  transpose_int_21 = None
        expand_default_16 = torch.ops.aten.expand.default(div_tensor_4, [256, 8, 33, 64]);  div_tensor_4 = None
        clone_default_17 = torch.ops.aten.clone.default(expand_default_16, memory_format = torch.contiguous_format);  expand_default_16 = None
        _unsafe_view_default_39 = torch.ops.aten._unsafe_view.default(clone_default_17, [2048, 33, 64]);  clone_default_17 = None
        expand_default_17 = torch.ops.aten.expand.default(transpose_int_23, [256, 8, 64, 33]);  transpose_int_23 = None
        clone_default_18 = torch.ops.aten.clone.default(expand_default_17, memory_format = torch.contiguous_format);  expand_default_17 = None
        _unsafe_view_default_40 = torch.ops.aten._unsafe_view.default(clone_default_18, [2048, 64, 33]);  clone_default_18 = None
        bmm_default_8 = torch.ops.aten.bmm.default(_unsafe_view_default_39, _unsafe_view_default_40)
        _unsafe_view_default_41 = torch.ops.aten._unsafe_view.default(bmm_default_8, [256, 8, 33, 33]);  bmm_default_8 = None
        eq_scalar_4 = torch.ops.aten.eq.Scalar(unsqueeze_default_6, 0);  unsqueeze_default_6 = None
        where_scalar_self_4 = torch.ops.aten.where.ScalarSelf(eq_scalar_4, -1000000000.0, _unsafe_view_default_41);  _unsafe_view_default_41 = None
        _softmax_default_4 = torch.ops.aten._softmax.default(where_scalar_self_4, -1, False);  where_scalar_self_4 = None
        expand_default_18 = torch.ops.aten.expand.default(_softmax_default_4, [256, 8, 33, 33])
        view_default_58 = torch.ops.aten.view.default(expand_default_18, [2048, 33, 33]);  expand_default_18 = None
        expand_default_19 = torch.ops.aten.expand.default(transpose_int_22, [256, 8, 33, 64]);  transpose_int_22 = None
        clone_default_19 = torch.ops.aten.clone.default(expand_default_19, memory_format = torch.contiguous_format);  expand_default_19 = None
        _unsafe_view_default_42 = torch.ops.aten._unsafe_view.default(clone_default_19, [2048, 33, 64]);  clone_default_19 = None
        bmm_default_9 = torch.ops.aten.bmm.default(view_default_58, _unsafe_view_default_42)
        _unsafe_view_default_43 = torch.ops.aten._unsafe_view.default(bmm_default_9, [256, 8, 33, 64]);  bmm_default_9 = None
        transpose_int_24 = torch.ops.aten.transpose.int(_unsafe_view_default_43, 1, 2);  _unsafe_view_default_43 = None
        clone_default_20 = torch.ops.aten.clone.default(transpose_int_24, memory_format = torch.contiguous_format);  transpose_int_24 = None
        view_default_59 = torch.ops.aten.view.default(clone_default_20, [256, 33, -1]);  clone_default_20 = None
        t_default_27 = torch.ops.aten.t.default(primals_169);  primals_169 = None
        view_default_60 = torch.ops.aten.view.default(view_default_59, [8448, 512]);  view_default_59 = None
        mm_default_19 = torch.ops.aten.mm.default(view_default_60, t_default_27)
        _unsafe_view_default_44 = torch.ops.aten._unsafe_view.default(mm_default_19, [256, 33, 512]);  mm_default_19 = None
        add__tensor_8 = torch.ops.aten.add_.Tensor(_unsafe_view_default_44, getitem_24);  _unsafe_view_default_44 = getitem_24 = None
        native_layer_norm_default_9 = torch.ops.aten.native_layer_norm.default(add__tensor_8, [512], primals_171, primals_170, 1e-06)
        getitem_27 = native_layer_norm_default_9[0]
        getitem_28 = native_layer_norm_default_9[1]
        getitem_29 = native_layer_norm_default_9[2];  native_layer_norm_default_9 = None
        view_default_61 = torch.ops.aten.view.default(getitem_27, [8448, 512])
        t_default_28 = torch.ops.aten.t.default(primals_166);  primals_166 = None
        addmm_default_8 = torch.ops.aten.addmm.default(primals_165, view_default_61, t_default_28);  primals_165 = None
        view_default_62 = torch.ops.aten.view.default(addmm_default_8, [256, 33, 2048]);  addmm_default_8 = None
        relu_default_4 = torch.ops.aten.relu.default(view_default_62);  view_default_62 = None
        view_default_63 = torch.ops.aten.view.default(relu_default_4, [8448, 2048])
        t_default_29 = torch.ops.aten.t.default(primals_168);  primals_168 = None
        addmm_default_9 = torch.ops.aten.addmm.default(primals_167, view_default_63, t_default_29);  primals_167 = None
        view_default_64 = torch.ops.aten.view.default(addmm_default_9, [256, 33, 512]);  addmm_default_9 = None
        add__tensor_9 = torch.ops.aten.add_.Tensor(view_default_64, getitem_27);  view_default_64 = getitem_27 = None
        native_layer_norm_default_10 = torch.ops.aten.native_layer_norm.default(add__tensor_9, [512], primals_164, primals_163, 1e-06)
        getitem_30 = native_layer_norm_default_10[0]
        getitem_31 = native_layer_norm_default_10[1]
        getitem_32 = native_layer_norm_default_10[2];  native_layer_norm_default_10 = None
        t_default_30 = torch.ops.aten.t.default(primals_185);  primals_185 = None
        view_default_65 = torch.ops.aten.view.default(getitem_30, [8448, 512])
        mm_default_20 = torch.ops.aten.mm.default(view_default_65, t_default_30)
        _unsafe_view_default_45 = torch.ops.aten._unsafe_view.default(mm_default_20, [256, 33, 512]);  mm_default_20 = None
        view_default_66 = torch.ops.aten.view.default(_unsafe_view_default_45, [256, 33, 8, 64]);  _unsafe_view_default_45 = None
        t_default_31 = torch.ops.aten.t.default(primals_184);  primals_184 = None
        view_default_67 = torch.ops.aten.view.default(getitem_30, [8448, 512])
        mm_default_21 = torch.ops.aten.mm.default(view_default_67, t_default_31)
        _unsafe_view_default_46 = torch.ops.aten._unsafe_view.default(mm_default_21, [256, 33, 512]);  mm_default_21 = None
        view_default_68 = torch.ops.aten.view.default(_unsafe_view_default_46, [256, 33, 8, 64]);  _unsafe_view_default_46 = None
        t_default_32 = torch.ops.aten.t.default(primals_186);  primals_186 = None
        view_default_69 = torch.ops.aten.view.default(getitem_30, [8448, 512])
        mm_default_22 = torch.ops.aten.mm.default(view_default_69, t_default_32)
        _unsafe_view_default_47 = torch.ops.aten._unsafe_view.default(mm_default_22, [256, 33, 512]);  mm_default_22 = None
        view_default_70 = torch.ops.aten.view.default(_unsafe_view_default_47, [256, 33, 8, 64]);  _unsafe_view_default_47 = None
        transpose_int_25 = torch.ops.aten.transpose.int(view_default_66, 1, 2);  view_default_66 = None
        transpose_int_26 = torch.ops.aten.transpose.int(view_default_68, 1, 2);  view_default_68 = None
        transpose_int_27 = torch.ops.aten.transpose.int(view_default_70, 1, 2);  view_default_70 = None
        unsqueeze_default_7 = torch.ops.aten.unsqueeze.default(unsqueeze_default, 1)
        div_tensor_5 = torch.ops.aten.div.Tensor(transpose_int_25, 8.0);  transpose_int_25 = None
        transpose_int_28 = torch.ops.aten.transpose.int(transpose_int_26, 2, 3);  transpose_int_26 = None
        expand_default_20 = torch.ops.aten.expand.default(div_tensor_5, [256, 8, 33, 64]);  div_tensor_5 = None
        clone_default_21 = torch.ops.aten.clone.default(expand_default_20, memory_format = torch.contiguous_format);  expand_default_20 = None
        _unsafe_view_default_48 = torch.ops.aten._unsafe_view.default(clone_default_21, [2048, 33, 64]);  clone_default_21 = None
        expand_default_21 = torch.ops.aten.expand.default(transpose_int_28, [256, 8, 64, 33]);  transpose_int_28 = None
        clone_default_22 = torch.ops.aten.clone.default(expand_default_21, memory_format = torch.contiguous_format);  expand_default_21 = None
        _unsafe_view_default_49 = torch.ops.aten._unsafe_view.default(clone_default_22, [2048, 64, 33]);  clone_default_22 = None
        bmm_default_10 = torch.ops.aten.bmm.default(_unsafe_view_default_48, _unsafe_view_default_49)
        _unsafe_view_default_50 = torch.ops.aten._unsafe_view.default(bmm_default_10, [256, 8, 33, 33]);  bmm_default_10 = None
        eq_scalar_5 = torch.ops.aten.eq.Scalar(unsqueeze_default_7, 0);  unsqueeze_default_7 = None
        where_scalar_self_5 = torch.ops.aten.where.ScalarSelf(eq_scalar_5, -1000000000.0, _unsafe_view_default_50);  _unsafe_view_default_50 = None
        _softmax_default_5 = torch.ops.aten._softmax.default(where_scalar_self_5, -1, False);  where_scalar_self_5 = None
        expand_default_22 = torch.ops.aten.expand.default(_softmax_default_5, [256, 8, 33, 33])
        view_default_71 = torch.ops.aten.view.default(expand_default_22, [2048, 33, 33]);  expand_default_22 = None
        expand_default_23 = torch.ops.aten.expand.default(transpose_int_27, [256, 8, 33, 64]);  transpose_int_27 = None
        clone_default_23 = torch.ops.aten.clone.default(expand_default_23, memory_format = torch.contiguous_format);  expand_default_23 = None
        _unsafe_view_default_51 = torch.ops.aten._unsafe_view.default(clone_default_23, [2048, 33, 64]);  clone_default_23 = None
        bmm_default_11 = torch.ops.aten.bmm.default(view_default_71, _unsafe_view_default_51)
        _unsafe_view_default_52 = torch.ops.aten._unsafe_view.default(bmm_default_11, [256, 8, 33, 64]);  bmm_default_11 = None
        transpose_int_29 = torch.ops.aten.transpose.int(_unsafe_view_default_52, 1, 2);  _unsafe_view_default_52 = None
        clone_default_24 = torch.ops.aten.clone.default(transpose_int_29, memory_format = torch.contiguous_format);  transpose_int_29 = None
        view_default_72 = torch.ops.aten.view.default(clone_default_24, [256, 33, -1]);  clone_default_24 = None
        t_default_33 = torch.ops.aten.t.default(primals_181);  primals_181 = None
        view_default_73 = torch.ops.aten.view.default(view_default_72, [8448, 512]);  view_default_72 = None
        mm_default_23 = torch.ops.aten.mm.default(view_default_73, t_default_33)
        _unsafe_view_default_53 = torch.ops.aten._unsafe_view.default(mm_default_23, [256, 33, 512]);  mm_default_23 = None
        add__tensor_10 = torch.ops.aten.add_.Tensor(_unsafe_view_default_53, getitem_30);  _unsafe_view_default_53 = getitem_30 = None
        native_layer_norm_default_11 = torch.ops.aten.native_layer_norm.default(add__tensor_10, [512], primals_183, primals_182, 1e-06)
        getitem_33 = native_layer_norm_default_11[0]
        getitem_34 = native_layer_norm_default_11[1]
        getitem_35 = native_layer_norm_default_11[2];  native_layer_norm_default_11 = None
        view_default_74 = torch.ops.aten.view.default(getitem_33, [8448, 512])
        t_default_34 = torch.ops.aten.t.default(primals_178);  primals_178 = None
        addmm_default_10 = torch.ops.aten.addmm.default(primals_177, view_default_74, t_default_34);  primals_177 = None
        view_default_75 = torch.ops.aten.view.default(addmm_default_10, [256, 33, 2048]);  addmm_default_10 = None
        relu_default_5 = torch.ops.aten.relu.default(view_default_75);  view_default_75 = None
        view_default_76 = torch.ops.aten.view.default(relu_default_5, [8448, 2048])
        t_default_35 = torch.ops.aten.t.default(primals_180);  primals_180 = None
        addmm_default_11 = torch.ops.aten.addmm.default(primals_179, view_default_76, t_default_35);  primals_179 = None
        view_default_77 = torch.ops.aten.view.default(addmm_default_11, [256, 33, 512]);  addmm_default_11 = None
        add__tensor_11 = torch.ops.aten.add_.Tensor(view_default_77, getitem_33);  view_default_77 = getitem_33 = None
        native_layer_norm_default_12 = torch.ops.aten.native_layer_norm.default(add__tensor_11, [512], primals_176, primals_175, 1e-06)
        getitem_36 = native_layer_norm_default_12[0]
        getitem_37 = native_layer_norm_default_12[1]
        getitem_38 = native_layer_norm_default_12[2];  native_layer_norm_default_12 = None
        embedding_default_1 = torch.ops.aten.embedding.default(primals_112, primals_191, 1);  primals_112 = None
        slice_tensor_2 = torch.ops.aten.slice.Tensor(primals_111, 0, 0, 9223372036854775807);  primals_111 = None
        slice_tensor_3 = torch.ops.aten.slice.Tensor(slice_tensor_2, 1, 0, 31);  slice_tensor_2 = None
        clone_default_25 = torch.ops.aten.clone.default(slice_tensor_3);  slice_tensor_3 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(embedding_default_1, clone_default_25);  embedding_default_1 = clone_default_25 = None
        native_layer_norm_default_13 = torch.ops.aten.native_layer_norm.default(add_tensor_1, [512], primals_2, primals_1, 1e-06)
        getitem_39 = native_layer_norm_default_13[0]
        getitem_40 = native_layer_norm_default_13[1]
        getitem_41 = native_layer_norm_default_13[2];  native_layer_norm_default_13 = None
        t_default_36 = torch.ops.aten.t.default(primals_19);  primals_19 = None
        view_default_78 = torch.ops.aten.view.default(getitem_39, [7936, 512])
        mm_default_24 = torch.ops.aten.mm.default(view_default_78, t_default_36)
        _unsafe_view_default_54 = torch.ops.aten._unsafe_view.default(mm_default_24, [256, 31, 512]);  mm_default_24 = None
        view_default_79 = torch.ops.aten.view.default(_unsafe_view_default_54, [256, 31, 8, 64]);  _unsafe_view_default_54 = None
        t_default_37 = torch.ops.aten.t.default(primals_18);  primals_18 = None
        view_default_80 = torch.ops.aten.view.default(getitem_39, [7936, 512])
        mm_default_25 = torch.ops.aten.mm.default(view_default_80, t_default_37)
        _unsafe_view_default_55 = torch.ops.aten._unsafe_view.default(mm_default_25, [256, 31, 512]);  mm_default_25 = None
        view_default_81 = torch.ops.aten.view.default(_unsafe_view_default_55, [256, 31, 8, 64]);  _unsafe_view_default_55 = None
        t_default_38 = torch.ops.aten.t.default(primals_20);  primals_20 = None
        view_default_82 = torch.ops.aten.view.default(getitem_39, [7936, 512])
        mm_default_26 = torch.ops.aten.mm.default(view_default_82, t_default_38)
        _unsafe_view_default_56 = torch.ops.aten._unsafe_view.default(mm_default_26, [256, 31, 512]);  mm_default_26 = None
        view_default_83 = torch.ops.aten.view.default(_unsafe_view_default_56, [256, 31, 8, 64]);  _unsafe_view_default_56 = None
        transpose_int_30 = torch.ops.aten.transpose.int(view_default_79, 1, 2);  view_default_79 = None
        transpose_int_31 = torch.ops.aten.transpose.int(view_default_81, 1, 2);  view_default_81 = None
        transpose_int_32 = torch.ops.aten.transpose.int(view_default_83, 1, 2);  view_default_83 = None
        unsqueeze_default_8 = torch.ops.aten.unsqueeze.default(bitwise_and_tensor, 1)
        div_tensor_6 = torch.ops.aten.div.Tensor(transpose_int_30, 8.0);  transpose_int_30 = None
        transpose_int_33 = torch.ops.aten.transpose.int(transpose_int_31, 2, 3);  transpose_int_31 = None
        expand_default_24 = torch.ops.aten.expand.default(div_tensor_6, [256, 8, 31, 64]);  div_tensor_6 = None
        clone_default_26 = torch.ops.aten.clone.default(expand_default_24, memory_format = torch.contiguous_format);  expand_default_24 = None
        _unsafe_view_default_57 = torch.ops.aten._unsafe_view.default(clone_default_26, [2048, 31, 64]);  clone_default_26 = None
        expand_default_25 = torch.ops.aten.expand.default(transpose_int_33, [256, 8, 64, 31]);  transpose_int_33 = None
        clone_default_27 = torch.ops.aten.clone.default(expand_default_25, memory_format = torch.contiguous_format);  expand_default_25 = None
        _unsafe_view_default_58 = torch.ops.aten._unsafe_view.default(clone_default_27, [2048, 64, 31]);  clone_default_27 = None
        bmm_default_12 = torch.ops.aten.bmm.default(_unsafe_view_default_57, _unsafe_view_default_58)
        _unsafe_view_default_59 = torch.ops.aten._unsafe_view.default(bmm_default_12, [256, 8, 31, 31]);  bmm_default_12 = None
        eq_scalar_6 = torch.ops.aten.eq.Scalar(unsqueeze_default_8, 0);  unsqueeze_default_8 = None
        where_scalar_self_6 = torch.ops.aten.where.ScalarSelf(eq_scalar_6, -1000000000.0, _unsafe_view_default_59);  _unsafe_view_default_59 = None
        _softmax_default_6 = torch.ops.aten._softmax.default(where_scalar_self_6, -1, False);  where_scalar_self_6 = None
        expand_default_26 = torch.ops.aten.expand.default(_softmax_default_6, [256, 8, 31, 31])
        view_default_84 = torch.ops.aten.view.default(expand_default_26, [2048, 31, 31]);  expand_default_26 = None
        expand_default_27 = torch.ops.aten.expand.default(transpose_int_32, [256, 8, 31, 64]);  transpose_int_32 = None
        clone_default_28 = torch.ops.aten.clone.default(expand_default_27, memory_format = torch.contiguous_format);  expand_default_27 = None
        _unsafe_view_default_60 = torch.ops.aten._unsafe_view.default(clone_default_28, [2048, 31, 64]);  clone_default_28 = None
        bmm_default_13 = torch.ops.aten.bmm.default(view_default_84, _unsafe_view_default_60)
        _unsafe_view_default_61 = torch.ops.aten._unsafe_view.default(bmm_default_13, [256, 8, 31, 64]);  bmm_default_13 = None
        transpose_int_34 = torch.ops.aten.transpose.int(_unsafe_view_default_61, 1, 2);  _unsafe_view_default_61 = None
        clone_default_29 = torch.ops.aten.clone.default(transpose_int_34, memory_format = torch.contiguous_format);  transpose_int_34 = None
        view_default_85 = torch.ops.aten.view.default(clone_default_29, [256, 31, -1]);  clone_default_29 = None
        t_default_39 = torch.ops.aten.t.default(primals_15);  primals_15 = None
        view_default_86 = torch.ops.aten.view.default(view_default_85, [7936, 512]);  view_default_85 = None
        mm_default_27 = torch.ops.aten.mm.default(view_default_86, t_default_39)
        _unsafe_view_default_62 = torch.ops.aten._unsafe_view.default(mm_default_27, [256, 31, 512]);  mm_default_27 = None
        add__tensor_12 = torch.ops.aten.add_.Tensor(_unsafe_view_default_62, getitem_39);  _unsafe_view_default_62 = getitem_39 = None
        native_layer_norm_default_14 = torch.ops.aten.native_layer_norm.default(add__tensor_12, [512], primals_17, primals_16, 1e-06)
        getitem_42 = native_layer_norm_default_14[0]
        getitem_43 = native_layer_norm_default_14[1]
        getitem_44 = native_layer_norm_default_14[2];  native_layer_norm_default_14 = None
        t_default_40 = torch.ops.aten.t.default(primals_7);  primals_7 = None
        view_default_87 = torch.ops.aten.view.default(getitem_42, [7936, 512])
        mm_default_28 = torch.ops.aten.mm.default(view_default_87, t_default_40)
        _unsafe_view_default_63 = torch.ops.aten._unsafe_view.default(mm_default_28, [256, 31, 512]);  mm_default_28 = None
        view_default_88 = torch.ops.aten.view.default(_unsafe_view_default_63, [256, 31, 8, 64]);  _unsafe_view_default_63 = None
        t_default_41 = torch.ops.aten.t.default(primals_6);  primals_6 = None
        view_default_89 = torch.ops.aten.view.default(getitem_36, [8448, 512])
        mm_default_29 = torch.ops.aten.mm.default(view_default_89, t_default_41)
        _unsafe_view_default_64 = torch.ops.aten._unsafe_view.default(mm_default_29, [256, 33, 512]);  mm_default_29 = None
        view_default_90 = torch.ops.aten.view.default(_unsafe_view_default_64, [256, 33, 8, 64]);  _unsafe_view_default_64 = None
        t_default_42 = torch.ops.aten.t.default(primals_8);  primals_8 = None
        view_default_91 = torch.ops.aten.view.default(getitem_36, [8448, 512])
        mm_default_30 = torch.ops.aten.mm.default(view_default_91, t_default_42)
        _unsafe_view_default_65 = torch.ops.aten._unsafe_view.default(mm_default_30, [256, 33, 512]);  mm_default_30 = None
        view_default_92 = torch.ops.aten.view.default(_unsafe_view_default_65, [256, 33, 8, 64]);  _unsafe_view_default_65 = None
        transpose_int_35 = torch.ops.aten.transpose.int(view_default_88, 1, 2);  view_default_88 = None
        transpose_int_36 = torch.ops.aten.transpose.int(view_default_90, 1, 2);  view_default_90 = None
        transpose_int_37 = torch.ops.aten.transpose.int(view_default_92, 1, 2);  view_default_92 = None
        unsqueeze_default_9 = torch.ops.aten.unsqueeze.default(unsqueeze_default, 1)
        div_tensor_7 = torch.ops.aten.div.Tensor(transpose_int_35, 8.0);  transpose_int_35 = None
        transpose_int_38 = torch.ops.aten.transpose.int(transpose_int_36, 2, 3);  transpose_int_36 = None
        expand_default_28 = torch.ops.aten.expand.default(div_tensor_7, [256, 8, 31, 64]);  div_tensor_7 = None
        clone_default_30 = torch.ops.aten.clone.default(expand_default_28, memory_format = torch.contiguous_format);  expand_default_28 = None
        _unsafe_view_default_66 = torch.ops.aten._unsafe_view.default(clone_default_30, [2048, 31, 64]);  clone_default_30 = None
        expand_default_29 = torch.ops.aten.expand.default(transpose_int_38, [256, 8, 64, 33]);  transpose_int_38 = None
        clone_default_31 = torch.ops.aten.clone.default(expand_default_29, memory_format = torch.contiguous_format);  expand_default_29 = None
        _unsafe_view_default_67 = torch.ops.aten._unsafe_view.default(clone_default_31, [2048, 64, 33]);  clone_default_31 = None
        bmm_default_14 = torch.ops.aten.bmm.default(_unsafe_view_default_66, _unsafe_view_default_67)
        _unsafe_view_default_68 = torch.ops.aten._unsafe_view.default(bmm_default_14, [256, 8, 31, 33]);  bmm_default_14 = None
        eq_scalar_7 = torch.ops.aten.eq.Scalar(unsqueeze_default_9, 0);  unsqueeze_default_9 = None
        where_scalar_self_7 = torch.ops.aten.where.ScalarSelf(eq_scalar_7, -1000000000.0, _unsafe_view_default_68);  _unsafe_view_default_68 = None
        _softmax_default_7 = torch.ops.aten._softmax.default(where_scalar_self_7, -1, False);  where_scalar_self_7 = None
        expand_default_30 = torch.ops.aten.expand.default(_softmax_default_7, [256, 8, 31, 33])
        view_default_93 = torch.ops.aten.view.default(expand_default_30, [2048, 31, 33]);  expand_default_30 = None
        expand_default_31 = torch.ops.aten.expand.default(transpose_int_37, [256, 8, 33, 64]);  transpose_int_37 = None
        clone_default_32 = torch.ops.aten.clone.default(expand_default_31, memory_format = torch.contiguous_format);  expand_default_31 = None
        _unsafe_view_default_69 = torch.ops.aten._unsafe_view.default(clone_default_32, [2048, 33, 64]);  clone_default_32 = None
        bmm_default_15 = torch.ops.aten.bmm.default(view_default_93, _unsafe_view_default_69)
        _unsafe_view_default_70 = torch.ops.aten._unsafe_view.default(bmm_default_15, [256, 8, 31, 64]);  bmm_default_15 = None
        transpose_int_39 = torch.ops.aten.transpose.int(_unsafe_view_default_70, 1, 2);  _unsafe_view_default_70 = None
        clone_default_33 = torch.ops.aten.clone.default(transpose_int_39, memory_format = torch.contiguous_format);  transpose_int_39 = None
        view_default_94 = torch.ops.aten.view.default(clone_default_33, [256, 31, -1]);  clone_default_33 = None
        t_default_43 = torch.ops.aten.t.default(primals_3);  primals_3 = None
        view_default_95 = torch.ops.aten.view.default(view_default_94, [7936, 512]);  view_default_94 = None
        mm_default_31 = torch.ops.aten.mm.default(view_default_95, t_default_43)
        _unsafe_view_default_71 = torch.ops.aten._unsafe_view.default(mm_default_31, [256, 31, 512]);  mm_default_31 = None
        add__tensor_13 = torch.ops.aten.add_.Tensor(_unsafe_view_default_71, getitem_42);  _unsafe_view_default_71 = getitem_42 = None
        native_layer_norm_default_15 = torch.ops.aten.native_layer_norm.default(add__tensor_13, [512], primals_5, primals_4, 1e-06)
        getitem_45 = native_layer_norm_default_15[0]
        getitem_46 = native_layer_norm_default_15[1]
        getitem_47 = native_layer_norm_default_15[2];  native_layer_norm_default_15 = None
        view_default_96 = torch.ops.aten.view.default(getitem_45, [7936, 512])
        t_default_44 = torch.ops.aten.t.default(primals_12);  primals_12 = None
        addmm_default_12 = torch.ops.aten.addmm.default(primals_11, view_default_96, t_default_44);  primals_11 = None
        view_default_97 = torch.ops.aten.view.default(addmm_default_12, [256, 31, 2048]);  addmm_default_12 = None
        relu_default_6 = torch.ops.aten.relu.default(view_default_97);  view_default_97 = None
        view_default_98 = torch.ops.aten.view.default(relu_default_6, [7936, 2048])
        t_default_45 = torch.ops.aten.t.default(primals_14);  primals_14 = None
        addmm_default_13 = torch.ops.aten.addmm.default(primals_13, view_default_98, t_default_45);  primals_13 = None
        view_default_99 = torch.ops.aten.view.default(addmm_default_13, [256, 31, 512]);  addmm_default_13 = None
        add__tensor_14 = torch.ops.aten.add_.Tensor(view_default_99, getitem_45);  view_default_99 = getitem_45 = None
        native_layer_norm_default_16 = torch.ops.aten.native_layer_norm.default(add__tensor_14, [512], primals_10, primals_9, 1e-06)
        getitem_48 = native_layer_norm_default_16[0]
        getitem_49 = native_layer_norm_default_16[1]
        getitem_50 = native_layer_norm_default_16[2];  native_layer_norm_default_16 = None
        t_default_46 = torch.ops.aten.t.default(primals_37);  primals_37 = None
        view_default_100 = torch.ops.aten.view.default(getitem_48, [7936, 512])
        mm_default_32 = torch.ops.aten.mm.default(view_default_100, t_default_46)
        _unsafe_view_default_72 = torch.ops.aten._unsafe_view.default(mm_default_32, [256, 31, 512]);  mm_default_32 = None
        view_default_101 = torch.ops.aten.view.default(_unsafe_view_default_72, [256, 31, 8, 64]);  _unsafe_view_default_72 = None
        t_default_47 = torch.ops.aten.t.default(primals_36);  primals_36 = None
        view_default_102 = torch.ops.aten.view.default(getitem_48, [7936, 512])
        mm_default_33 = torch.ops.aten.mm.default(view_default_102, t_default_47)
        _unsafe_view_default_73 = torch.ops.aten._unsafe_view.default(mm_default_33, [256, 31, 512]);  mm_default_33 = None
        view_default_103 = torch.ops.aten.view.default(_unsafe_view_default_73, [256, 31, 8, 64]);  _unsafe_view_default_73 = None
        t_default_48 = torch.ops.aten.t.default(primals_38);  primals_38 = None
        view_default_104 = torch.ops.aten.view.default(getitem_48, [7936, 512])
        mm_default_34 = torch.ops.aten.mm.default(view_default_104, t_default_48)
        _unsafe_view_default_74 = torch.ops.aten._unsafe_view.default(mm_default_34, [256, 31, 512]);  mm_default_34 = None
        view_default_105 = torch.ops.aten.view.default(_unsafe_view_default_74, [256, 31, 8, 64]);  _unsafe_view_default_74 = None
        transpose_int_40 = torch.ops.aten.transpose.int(view_default_101, 1, 2);  view_default_101 = None
        transpose_int_41 = torch.ops.aten.transpose.int(view_default_103, 1, 2);  view_default_103 = None
        transpose_int_42 = torch.ops.aten.transpose.int(view_default_105, 1, 2);  view_default_105 = None
        unsqueeze_default_10 = torch.ops.aten.unsqueeze.default(bitwise_and_tensor, 1)
        div_tensor_8 = torch.ops.aten.div.Tensor(transpose_int_40, 8.0);  transpose_int_40 = None
        transpose_int_43 = torch.ops.aten.transpose.int(transpose_int_41, 2, 3);  transpose_int_41 = None
        expand_default_32 = torch.ops.aten.expand.default(div_tensor_8, [256, 8, 31, 64]);  div_tensor_8 = None
        clone_default_34 = torch.ops.aten.clone.default(expand_default_32, memory_format = torch.contiguous_format);  expand_default_32 = None
        _unsafe_view_default_75 = torch.ops.aten._unsafe_view.default(clone_default_34, [2048, 31, 64]);  clone_default_34 = None
        expand_default_33 = torch.ops.aten.expand.default(transpose_int_43, [256, 8, 64, 31]);  transpose_int_43 = None
        clone_default_35 = torch.ops.aten.clone.default(expand_default_33, memory_format = torch.contiguous_format);  expand_default_33 = None
        _unsafe_view_default_76 = torch.ops.aten._unsafe_view.default(clone_default_35, [2048, 64, 31]);  clone_default_35 = None
        bmm_default_16 = torch.ops.aten.bmm.default(_unsafe_view_default_75, _unsafe_view_default_76)
        _unsafe_view_default_77 = torch.ops.aten._unsafe_view.default(bmm_default_16, [256, 8, 31, 31]);  bmm_default_16 = None
        eq_scalar_8 = torch.ops.aten.eq.Scalar(unsqueeze_default_10, 0);  unsqueeze_default_10 = None
        where_scalar_self_8 = torch.ops.aten.where.ScalarSelf(eq_scalar_8, -1000000000.0, _unsafe_view_default_77);  _unsafe_view_default_77 = None
        _softmax_default_8 = torch.ops.aten._softmax.default(where_scalar_self_8, -1, False);  where_scalar_self_8 = None
        expand_default_34 = torch.ops.aten.expand.default(_softmax_default_8, [256, 8, 31, 31])
        view_default_106 = torch.ops.aten.view.default(expand_default_34, [2048, 31, 31]);  expand_default_34 = None
        expand_default_35 = torch.ops.aten.expand.default(transpose_int_42, [256, 8, 31, 64]);  transpose_int_42 = None
        clone_default_36 = torch.ops.aten.clone.default(expand_default_35, memory_format = torch.contiguous_format);  expand_default_35 = None
        _unsafe_view_default_78 = torch.ops.aten._unsafe_view.default(clone_default_36, [2048, 31, 64]);  clone_default_36 = None
        bmm_default_17 = torch.ops.aten.bmm.default(view_default_106, _unsafe_view_default_78)
        _unsafe_view_default_79 = torch.ops.aten._unsafe_view.default(bmm_default_17, [256, 8, 31, 64]);  bmm_default_17 = None
        transpose_int_44 = torch.ops.aten.transpose.int(_unsafe_view_default_79, 1, 2);  _unsafe_view_default_79 = None
        clone_default_37 = torch.ops.aten.clone.default(transpose_int_44, memory_format = torch.contiguous_format);  transpose_int_44 = None
        view_default_107 = torch.ops.aten.view.default(clone_default_37, [256, 31, -1]);  clone_default_37 = None
        t_default_49 = torch.ops.aten.t.default(primals_33);  primals_33 = None
        view_default_108 = torch.ops.aten.view.default(view_default_107, [7936, 512]);  view_default_107 = None
        mm_default_35 = torch.ops.aten.mm.default(view_default_108, t_default_49)
        _unsafe_view_default_80 = torch.ops.aten._unsafe_view.default(mm_default_35, [256, 31, 512]);  mm_default_35 = None
        add__tensor_15 = torch.ops.aten.add_.Tensor(_unsafe_view_default_80, getitem_48);  _unsafe_view_default_80 = getitem_48 = None
        native_layer_norm_default_17 = torch.ops.aten.native_layer_norm.default(add__tensor_15, [512], primals_35, primals_34, 1e-06)
        getitem_51 = native_layer_norm_default_17[0]
        getitem_52 = native_layer_norm_default_17[1]
        getitem_53 = native_layer_norm_default_17[2];  native_layer_norm_default_17 = None
        t_default_50 = torch.ops.aten.t.default(primals_25);  primals_25 = None
        view_default_109 = torch.ops.aten.view.default(getitem_51, [7936, 512])
        mm_default_36 = torch.ops.aten.mm.default(view_default_109, t_default_50)
        _unsafe_view_default_81 = torch.ops.aten._unsafe_view.default(mm_default_36, [256, 31, 512]);  mm_default_36 = None
        view_default_110 = torch.ops.aten.view.default(_unsafe_view_default_81, [256, 31, 8, 64]);  _unsafe_view_default_81 = None
        t_default_51 = torch.ops.aten.t.default(primals_24);  primals_24 = None
        view_default_111 = torch.ops.aten.view.default(getitem_36, [8448, 512])
        mm_default_37 = torch.ops.aten.mm.default(view_default_111, t_default_51)
        _unsafe_view_default_82 = torch.ops.aten._unsafe_view.default(mm_default_37, [256, 33, 512]);  mm_default_37 = None
        view_default_112 = torch.ops.aten.view.default(_unsafe_view_default_82, [256, 33, 8, 64]);  _unsafe_view_default_82 = None
        t_default_52 = torch.ops.aten.t.default(primals_26);  primals_26 = None
        view_default_113 = torch.ops.aten.view.default(getitem_36, [8448, 512])
        mm_default_38 = torch.ops.aten.mm.default(view_default_113, t_default_52)
        _unsafe_view_default_83 = torch.ops.aten._unsafe_view.default(mm_default_38, [256, 33, 512]);  mm_default_38 = None
        view_default_114 = torch.ops.aten.view.default(_unsafe_view_default_83, [256, 33, 8, 64]);  _unsafe_view_default_83 = None
        transpose_int_45 = torch.ops.aten.transpose.int(view_default_110, 1, 2);  view_default_110 = None
        transpose_int_46 = torch.ops.aten.transpose.int(view_default_112, 1, 2);  view_default_112 = None
        transpose_int_47 = torch.ops.aten.transpose.int(view_default_114, 1, 2);  view_default_114 = None
        unsqueeze_default_11 = torch.ops.aten.unsqueeze.default(unsqueeze_default, 1)
        div_tensor_9 = torch.ops.aten.div.Tensor(transpose_int_45, 8.0);  transpose_int_45 = None
        transpose_int_48 = torch.ops.aten.transpose.int(transpose_int_46, 2, 3);  transpose_int_46 = None
        expand_default_36 = torch.ops.aten.expand.default(div_tensor_9, [256, 8, 31, 64]);  div_tensor_9 = None
        clone_default_38 = torch.ops.aten.clone.default(expand_default_36, memory_format = torch.contiguous_format);  expand_default_36 = None
        _unsafe_view_default_84 = torch.ops.aten._unsafe_view.default(clone_default_38, [2048, 31, 64]);  clone_default_38 = None
        expand_default_37 = torch.ops.aten.expand.default(transpose_int_48, [256, 8, 64, 33]);  transpose_int_48 = None
        clone_default_39 = torch.ops.aten.clone.default(expand_default_37, memory_format = torch.contiguous_format);  expand_default_37 = None
        _unsafe_view_default_85 = torch.ops.aten._unsafe_view.default(clone_default_39, [2048, 64, 33]);  clone_default_39 = None
        bmm_default_18 = torch.ops.aten.bmm.default(_unsafe_view_default_84, _unsafe_view_default_85)
        _unsafe_view_default_86 = torch.ops.aten._unsafe_view.default(bmm_default_18, [256, 8, 31, 33]);  bmm_default_18 = None
        eq_scalar_9 = torch.ops.aten.eq.Scalar(unsqueeze_default_11, 0);  unsqueeze_default_11 = None
        where_scalar_self_9 = torch.ops.aten.where.ScalarSelf(eq_scalar_9, -1000000000.0, _unsafe_view_default_86);  _unsafe_view_default_86 = None
        _softmax_default_9 = torch.ops.aten._softmax.default(where_scalar_self_9, -1, False);  where_scalar_self_9 = None
        expand_default_38 = torch.ops.aten.expand.default(_softmax_default_9, [256, 8, 31, 33])
        view_default_115 = torch.ops.aten.view.default(expand_default_38, [2048, 31, 33]);  expand_default_38 = None
        expand_default_39 = torch.ops.aten.expand.default(transpose_int_47, [256, 8, 33, 64]);  transpose_int_47 = None
        clone_default_40 = torch.ops.aten.clone.default(expand_default_39, memory_format = torch.contiguous_format);  expand_default_39 = None
        _unsafe_view_default_87 = torch.ops.aten._unsafe_view.default(clone_default_40, [2048, 33, 64]);  clone_default_40 = None
        bmm_default_19 = torch.ops.aten.bmm.default(view_default_115, _unsafe_view_default_87)
        _unsafe_view_default_88 = torch.ops.aten._unsafe_view.default(bmm_default_19, [256, 8, 31, 64]);  bmm_default_19 = None
        transpose_int_49 = torch.ops.aten.transpose.int(_unsafe_view_default_88, 1, 2);  _unsafe_view_default_88 = None
        clone_default_41 = torch.ops.aten.clone.default(transpose_int_49, memory_format = torch.contiguous_format);  transpose_int_49 = None
        view_default_116 = torch.ops.aten.view.default(clone_default_41, [256, 31, -1]);  clone_default_41 = None
        t_default_53 = torch.ops.aten.t.default(primals_21);  primals_21 = None
        view_default_117 = torch.ops.aten.view.default(view_default_116, [7936, 512]);  view_default_116 = None
        mm_default_39 = torch.ops.aten.mm.default(view_default_117, t_default_53)
        _unsafe_view_default_89 = torch.ops.aten._unsafe_view.default(mm_default_39, [256, 31, 512]);  mm_default_39 = None
        add__tensor_16 = torch.ops.aten.add_.Tensor(_unsafe_view_default_89, getitem_51);  _unsafe_view_default_89 = getitem_51 = None
        native_layer_norm_default_18 = torch.ops.aten.native_layer_norm.default(add__tensor_16, [512], primals_23, primals_22, 1e-06)
        getitem_54 = native_layer_norm_default_18[0]
        getitem_55 = native_layer_norm_default_18[1]
        getitem_56 = native_layer_norm_default_18[2];  native_layer_norm_default_18 = None
        view_default_118 = torch.ops.aten.view.default(getitem_54, [7936, 512])
        t_default_54 = torch.ops.aten.t.default(primals_30);  primals_30 = None
        addmm_default_14 = torch.ops.aten.addmm.default(primals_29, view_default_118, t_default_54);  primals_29 = None
        view_default_119 = torch.ops.aten.view.default(addmm_default_14, [256, 31, 2048]);  addmm_default_14 = None
        relu_default_7 = torch.ops.aten.relu.default(view_default_119);  view_default_119 = None
        view_default_120 = torch.ops.aten.view.default(relu_default_7, [7936, 2048])
        t_default_55 = torch.ops.aten.t.default(primals_32);  primals_32 = None
        addmm_default_15 = torch.ops.aten.addmm.default(primals_31, view_default_120, t_default_55);  primals_31 = None
        view_default_121 = torch.ops.aten.view.default(addmm_default_15, [256, 31, 512]);  addmm_default_15 = None
        add__tensor_17 = torch.ops.aten.add_.Tensor(view_default_121, getitem_54);  view_default_121 = getitem_54 = None
        native_layer_norm_default_19 = torch.ops.aten.native_layer_norm.default(add__tensor_17, [512], primals_28, primals_27, 1e-06)
        getitem_57 = native_layer_norm_default_19[0]
        getitem_58 = native_layer_norm_default_19[1]
        getitem_59 = native_layer_norm_default_19[2];  native_layer_norm_default_19 = None
        t_default_56 = torch.ops.aten.t.default(primals_55);  primals_55 = None
        view_default_122 = torch.ops.aten.view.default(getitem_57, [7936, 512])
        mm_default_40 = torch.ops.aten.mm.default(view_default_122, t_default_56)
        _unsafe_view_default_90 = torch.ops.aten._unsafe_view.default(mm_default_40, [256, 31, 512]);  mm_default_40 = None
        view_default_123 = torch.ops.aten.view.default(_unsafe_view_default_90, [256, 31, 8, 64]);  _unsafe_view_default_90 = None
        t_default_57 = torch.ops.aten.t.default(primals_54);  primals_54 = None
        view_default_124 = torch.ops.aten.view.default(getitem_57, [7936, 512])
        mm_default_41 = torch.ops.aten.mm.default(view_default_124, t_default_57)
        _unsafe_view_default_91 = torch.ops.aten._unsafe_view.default(mm_default_41, [256, 31, 512]);  mm_default_41 = None
        view_default_125 = torch.ops.aten.view.default(_unsafe_view_default_91, [256, 31, 8, 64]);  _unsafe_view_default_91 = None
        t_default_58 = torch.ops.aten.t.default(primals_56);  primals_56 = None
        view_default_126 = torch.ops.aten.view.default(getitem_57, [7936, 512])
        mm_default_42 = torch.ops.aten.mm.default(view_default_126, t_default_58)
        _unsafe_view_default_92 = torch.ops.aten._unsafe_view.default(mm_default_42, [256, 31, 512]);  mm_default_42 = None
        view_default_127 = torch.ops.aten.view.default(_unsafe_view_default_92, [256, 31, 8, 64]);  _unsafe_view_default_92 = None
        transpose_int_50 = torch.ops.aten.transpose.int(view_default_123, 1, 2);  view_default_123 = None
        transpose_int_51 = torch.ops.aten.transpose.int(view_default_125, 1, 2);  view_default_125 = None
        transpose_int_52 = torch.ops.aten.transpose.int(view_default_127, 1, 2);  view_default_127 = None
        unsqueeze_default_12 = torch.ops.aten.unsqueeze.default(bitwise_and_tensor, 1)
        div_tensor_10 = torch.ops.aten.div.Tensor(transpose_int_50, 8.0);  transpose_int_50 = None
        transpose_int_53 = torch.ops.aten.transpose.int(transpose_int_51, 2, 3);  transpose_int_51 = None
        expand_default_40 = torch.ops.aten.expand.default(div_tensor_10, [256, 8, 31, 64]);  div_tensor_10 = None
        clone_default_42 = torch.ops.aten.clone.default(expand_default_40, memory_format = torch.contiguous_format);  expand_default_40 = None
        _unsafe_view_default_93 = torch.ops.aten._unsafe_view.default(clone_default_42, [2048, 31, 64]);  clone_default_42 = None
        expand_default_41 = torch.ops.aten.expand.default(transpose_int_53, [256, 8, 64, 31]);  transpose_int_53 = None
        clone_default_43 = torch.ops.aten.clone.default(expand_default_41, memory_format = torch.contiguous_format);  expand_default_41 = None
        _unsafe_view_default_94 = torch.ops.aten._unsafe_view.default(clone_default_43, [2048, 64, 31]);  clone_default_43 = None
        bmm_default_20 = torch.ops.aten.bmm.default(_unsafe_view_default_93, _unsafe_view_default_94)
        _unsafe_view_default_95 = torch.ops.aten._unsafe_view.default(bmm_default_20, [256, 8, 31, 31]);  bmm_default_20 = None
        eq_scalar_10 = torch.ops.aten.eq.Scalar(unsqueeze_default_12, 0);  unsqueeze_default_12 = None
        where_scalar_self_10 = torch.ops.aten.where.ScalarSelf(eq_scalar_10, -1000000000.0, _unsafe_view_default_95);  _unsafe_view_default_95 = None
        _softmax_default_10 = torch.ops.aten._softmax.default(where_scalar_self_10, -1, False);  where_scalar_self_10 = None
        expand_default_42 = torch.ops.aten.expand.default(_softmax_default_10, [256, 8, 31, 31])
        view_default_128 = torch.ops.aten.view.default(expand_default_42, [2048, 31, 31]);  expand_default_42 = None
        expand_default_43 = torch.ops.aten.expand.default(transpose_int_52, [256, 8, 31, 64]);  transpose_int_52 = None
        clone_default_44 = torch.ops.aten.clone.default(expand_default_43, memory_format = torch.contiguous_format);  expand_default_43 = None
        _unsafe_view_default_96 = torch.ops.aten._unsafe_view.default(clone_default_44, [2048, 31, 64]);  clone_default_44 = None
        bmm_default_21 = torch.ops.aten.bmm.default(view_default_128, _unsafe_view_default_96)
        _unsafe_view_default_97 = torch.ops.aten._unsafe_view.default(bmm_default_21, [256, 8, 31, 64]);  bmm_default_21 = None
        transpose_int_54 = torch.ops.aten.transpose.int(_unsafe_view_default_97, 1, 2);  _unsafe_view_default_97 = None
        clone_default_45 = torch.ops.aten.clone.default(transpose_int_54, memory_format = torch.contiguous_format);  transpose_int_54 = None
        view_default_129 = torch.ops.aten.view.default(clone_default_45, [256, 31, -1]);  clone_default_45 = None
        t_default_59 = torch.ops.aten.t.default(primals_51);  primals_51 = None
        view_default_130 = torch.ops.aten.view.default(view_default_129, [7936, 512]);  view_default_129 = None
        mm_default_43 = torch.ops.aten.mm.default(view_default_130, t_default_59)
        _unsafe_view_default_98 = torch.ops.aten._unsafe_view.default(mm_default_43, [256, 31, 512]);  mm_default_43 = None
        add__tensor_18 = torch.ops.aten.add_.Tensor(_unsafe_view_default_98, getitem_57);  _unsafe_view_default_98 = getitem_57 = None
        native_layer_norm_default_20 = torch.ops.aten.native_layer_norm.default(add__tensor_18, [512], primals_53, primals_52, 1e-06)
        getitem_60 = native_layer_norm_default_20[0]
        getitem_61 = native_layer_norm_default_20[1]
        getitem_62 = native_layer_norm_default_20[2];  native_layer_norm_default_20 = None
        t_default_60 = torch.ops.aten.t.default(primals_43);  primals_43 = None
        view_default_131 = torch.ops.aten.view.default(getitem_60, [7936, 512])
        mm_default_44 = torch.ops.aten.mm.default(view_default_131, t_default_60)
        _unsafe_view_default_99 = torch.ops.aten._unsafe_view.default(mm_default_44, [256, 31, 512]);  mm_default_44 = None
        view_default_132 = torch.ops.aten.view.default(_unsafe_view_default_99, [256, 31, 8, 64]);  _unsafe_view_default_99 = None
        t_default_61 = torch.ops.aten.t.default(primals_42);  primals_42 = None
        view_default_133 = torch.ops.aten.view.default(getitem_36, [8448, 512])
        mm_default_45 = torch.ops.aten.mm.default(view_default_133, t_default_61)
        _unsafe_view_default_100 = torch.ops.aten._unsafe_view.default(mm_default_45, [256, 33, 512]);  mm_default_45 = None
        view_default_134 = torch.ops.aten.view.default(_unsafe_view_default_100, [256, 33, 8, 64]);  _unsafe_view_default_100 = None
        t_default_62 = torch.ops.aten.t.default(primals_44);  primals_44 = None
        view_default_135 = torch.ops.aten.view.default(getitem_36, [8448, 512])
        mm_default_46 = torch.ops.aten.mm.default(view_default_135, t_default_62)
        _unsafe_view_default_101 = torch.ops.aten._unsafe_view.default(mm_default_46, [256, 33, 512]);  mm_default_46 = None
        view_default_136 = torch.ops.aten.view.default(_unsafe_view_default_101, [256, 33, 8, 64]);  _unsafe_view_default_101 = None
        transpose_int_55 = torch.ops.aten.transpose.int(view_default_132, 1, 2);  view_default_132 = None
        transpose_int_56 = torch.ops.aten.transpose.int(view_default_134, 1, 2);  view_default_134 = None
        transpose_int_57 = torch.ops.aten.transpose.int(view_default_136, 1, 2);  view_default_136 = None
        unsqueeze_default_13 = torch.ops.aten.unsqueeze.default(unsqueeze_default, 1)
        div_tensor_11 = torch.ops.aten.div.Tensor(transpose_int_55, 8.0);  transpose_int_55 = None
        transpose_int_58 = torch.ops.aten.transpose.int(transpose_int_56, 2, 3);  transpose_int_56 = None
        expand_default_44 = torch.ops.aten.expand.default(div_tensor_11, [256, 8, 31, 64]);  div_tensor_11 = None
        clone_default_46 = torch.ops.aten.clone.default(expand_default_44, memory_format = torch.contiguous_format);  expand_default_44 = None
        _unsafe_view_default_102 = torch.ops.aten._unsafe_view.default(clone_default_46, [2048, 31, 64]);  clone_default_46 = None
        expand_default_45 = torch.ops.aten.expand.default(transpose_int_58, [256, 8, 64, 33]);  transpose_int_58 = None
        clone_default_47 = torch.ops.aten.clone.default(expand_default_45, memory_format = torch.contiguous_format);  expand_default_45 = None
        _unsafe_view_default_103 = torch.ops.aten._unsafe_view.default(clone_default_47, [2048, 64, 33]);  clone_default_47 = None
        bmm_default_22 = torch.ops.aten.bmm.default(_unsafe_view_default_102, _unsafe_view_default_103)
        _unsafe_view_default_104 = torch.ops.aten._unsafe_view.default(bmm_default_22, [256, 8, 31, 33]);  bmm_default_22 = None
        eq_scalar_11 = torch.ops.aten.eq.Scalar(unsqueeze_default_13, 0);  unsqueeze_default_13 = None
        where_scalar_self_11 = torch.ops.aten.where.ScalarSelf(eq_scalar_11, -1000000000.0, _unsafe_view_default_104);  _unsafe_view_default_104 = None
        _softmax_default_11 = torch.ops.aten._softmax.default(where_scalar_self_11, -1, False);  where_scalar_self_11 = None
        expand_default_46 = torch.ops.aten.expand.default(_softmax_default_11, [256, 8, 31, 33])
        view_default_137 = torch.ops.aten.view.default(expand_default_46, [2048, 31, 33]);  expand_default_46 = None
        expand_default_47 = torch.ops.aten.expand.default(transpose_int_57, [256, 8, 33, 64]);  transpose_int_57 = None
        clone_default_48 = torch.ops.aten.clone.default(expand_default_47, memory_format = torch.contiguous_format);  expand_default_47 = None
        _unsafe_view_default_105 = torch.ops.aten._unsafe_view.default(clone_default_48, [2048, 33, 64]);  clone_default_48 = None
        bmm_default_23 = torch.ops.aten.bmm.default(view_default_137, _unsafe_view_default_105)
        _unsafe_view_default_106 = torch.ops.aten._unsafe_view.default(bmm_default_23, [256, 8, 31, 64]);  bmm_default_23 = None
        transpose_int_59 = torch.ops.aten.transpose.int(_unsafe_view_default_106, 1, 2);  _unsafe_view_default_106 = None
        clone_default_49 = torch.ops.aten.clone.default(transpose_int_59, memory_format = torch.contiguous_format);  transpose_int_59 = None
        view_default_138 = torch.ops.aten.view.default(clone_default_49, [256, 31, -1]);  clone_default_49 = None
        t_default_63 = torch.ops.aten.t.default(primals_39);  primals_39 = None
        view_default_139 = torch.ops.aten.view.default(view_default_138, [7936, 512]);  view_default_138 = None
        mm_default_47 = torch.ops.aten.mm.default(view_default_139, t_default_63)
        _unsafe_view_default_107 = torch.ops.aten._unsafe_view.default(mm_default_47, [256, 31, 512]);  mm_default_47 = None
        add__tensor_19 = torch.ops.aten.add_.Tensor(_unsafe_view_default_107, getitem_60);  _unsafe_view_default_107 = getitem_60 = None
        native_layer_norm_default_21 = torch.ops.aten.native_layer_norm.default(add__tensor_19, [512], primals_41, primals_40, 1e-06)
        getitem_63 = native_layer_norm_default_21[0]
        getitem_64 = native_layer_norm_default_21[1]
        getitem_65 = native_layer_norm_default_21[2];  native_layer_norm_default_21 = None
        view_default_140 = torch.ops.aten.view.default(getitem_63, [7936, 512])
        t_default_64 = torch.ops.aten.t.default(primals_48);  primals_48 = None
        addmm_default_16 = torch.ops.aten.addmm.default(primals_47, view_default_140, t_default_64);  primals_47 = None
        view_default_141 = torch.ops.aten.view.default(addmm_default_16, [256, 31, 2048]);  addmm_default_16 = None
        relu_default_8 = torch.ops.aten.relu.default(view_default_141);  view_default_141 = None
        view_default_142 = torch.ops.aten.view.default(relu_default_8, [7936, 2048])
        t_default_65 = torch.ops.aten.t.default(primals_50);  primals_50 = None
        addmm_default_17 = torch.ops.aten.addmm.default(primals_49, view_default_142, t_default_65);  primals_49 = None
        view_default_143 = torch.ops.aten.view.default(addmm_default_17, [256, 31, 512]);  addmm_default_17 = None
        add__tensor_20 = torch.ops.aten.add_.Tensor(view_default_143, getitem_63);  view_default_143 = getitem_63 = None
        native_layer_norm_default_22 = torch.ops.aten.native_layer_norm.default(add__tensor_20, [512], primals_46, primals_45, 1e-06)
        getitem_66 = native_layer_norm_default_22[0]
        getitem_67 = native_layer_norm_default_22[1]
        getitem_68 = native_layer_norm_default_22[2];  native_layer_norm_default_22 = None
        t_default_66 = torch.ops.aten.t.default(primals_73);  primals_73 = None
        view_default_144 = torch.ops.aten.view.default(getitem_66, [7936, 512])
        mm_default_48 = torch.ops.aten.mm.default(view_default_144, t_default_66)
        _unsafe_view_default_108 = torch.ops.aten._unsafe_view.default(mm_default_48, [256, 31, 512]);  mm_default_48 = None
        view_default_145 = torch.ops.aten.view.default(_unsafe_view_default_108, [256, 31, 8, 64]);  _unsafe_view_default_108 = None
        t_default_67 = torch.ops.aten.t.default(primals_72);  primals_72 = None
        view_default_146 = torch.ops.aten.view.default(getitem_66, [7936, 512])
        mm_default_49 = torch.ops.aten.mm.default(view_default_146, t_default_67)
        _unsafe_view_default_109 = torch.ops.aten._unsafe_view.default(mm_default_49, [256, 31, 512]);  mm_default_49 = None
        view_default_147 = torch.ops.aten.view.default(_unsafe_view_default_109, [256, 31, 8, 64]);  _unsafe_view_default_109 = None
        t_default_68 = torch.ops.aten.t.default(primals_74);  primals_74 = None
        view_default_148 = torch.ops.aten.view.default(getitem_66, [7936, 512])
        mm_default_50 = torch.ops.aten.mm.default(view_default_148, t_default_68)
        _unsafe_view_default_110 = torch.ops.aten._unsafe_view.default(mm_default_50, [256, 31, 512]);  mm_default_50 = None
        view_default_149 = torch.ops.aten.view.default(_unsafe_view_default_110, [256, 31, 8, 64]);  _unsafe_view_default_110 = None
        transpose_int_60 = torch.ops.aten.transpose.int(view_default_145, 1, 2);  view_default_145 = None
        transpose_int_61 = torch.ops.aten.transpose.int(view_default_147, 1, 2);  view_default_147 = None
        transpose_int_62 = torch.ops.aten.transpose.int(view_default_149, 1, 2);  view_default_149 = None
        unsqueeze_default_14 = torch.ops.aten.unsqueeze.default(bitwise_and_tensor, 1)
        div_tensor_12 = torch.ops.aten.div.Tensor(transpose_int_60, 8.0);  transpose_int_60 = None
        transpose_int_63 = torch.ops.aten.transpose.int(transpose_int_61, 2, 3);  transpose_int_61 = None
        expand_default_48 = torch.ops.aten.expand.default(div_tensor_12, [256, 8, 31, 64]);  div_tensor_12 = None
        clone_default_50 = torch.ops.aten.clone.default(expand_default_48, memory_format = torch.contiguous_format);  expand_default_48 = None
        _unsafe_view_default_111 = torch.ops.aten._unsafe_view.default(clone_default_50, [2048, 31, 64]);  clone_default_50 = None
        expand_default_49 = torch.ops.aten.expand.default(transpose_int_63, [256, 8, 64, 31]);  transpose_int_63 = None
        clone_default_51 = torch.ops.aten.clone.default(expand_default_49, memory_format = torch.contiguous_format);  expand_default_49 = None
        _unsafe_view_default_112 = torch.ops.aten._unsafe_view.default(clone_default_51, [2048, 64, 31]);  clone_default_51 = None
        bmm_default_24 = torch.ops.aten.bmm.default(_unsafe_view_default_111, _unsafe_view_default_112)
        _unsafe_view_default_113 = torch.ops.aten._unsafe_view.default(bmm_default_24, [256, 8, 31, 31]);  bmm_default_24 = None
        eq_scalar_12 = torch.ops.aten.eq.Scalar(unsqueeze_default_14, 0);  unsqueeze_default_14 = None
        where_scalar_self_12 = torch.ops.aten.where.ScalarSelf(eq_scalar_12, -1000000000.0, _unsafe_view_default_113);  _unsafe_view_default_113 = None
        _softmax_default_12 = torch.ops.aten._softmax.default(where_scalar_self_12, -1, False);  where_scalar_self_12 = None
        expand_default_50 = torch.ops.aten.expand.default(_softmax_default_12, [256, 8, 31, 31])
        view_default_150 = torch.ops.aten.view.default(expand_default_50, [2048, 31, 31]);  expand_default_50 = None
        expand_default_51 = torch.ops.aten.expand.default(transpose_int_62, [256, 8, 31, 64]);  transpose_int_62 = None
        clone_default_52 = torch.ops.aten.clone.default(expand_default_51, memory_format = torch.contiguous_format);  expand_default_51 = None
        _unsafe_view_default_114 = torch.ops.aten._unsafe_view.default(clone_default_52, [2048, 31, 64]);  clone_default_52 = None
        bmm_default_25 = torch.ops.aten.bmm.default(view_default_150, _unsafe_view_default_114)
        _unsafe_view_default_115 = torch.ops.aten._unsafe_view.default(bmm_default_25, [256, 8, 31, 64]);  bmm_default_25 = None
        transpose_int_64 = torch.ops.aten.transpose.int(_unsafe_view_default_115, 1, 2);  _unsafe_view_default_115 = None
        clone_default_53 = torch.ops.aten.clone.default(transpose_int_64, memory_format = torch.contiguous_format);  transpose_int_64 = None
        view_default_151 = torch.ops.aten.view.default(clone_default_53, [256, 31, -1]);  clone_default_53 = None
        t_default_69 = torch.ops.aten.t.default(primals_69);  primals_69 = None
        view_default_152 = torch.ops.aten.view.default(view_default_151, [7936, 512]);  view_default_151 = None
        mm_default_51 = torch.ops.aten.mm.default(view_default_152, t_default_69)
        _unsafe_view_default_116 = torch.ops.aten._unsafe_view.default(mm_default_51, [256, 31, 512]);  mm_default_51 = None
        add__tensor_21 = torch.ops.aten.add_.Tensor(_unsafe_view_default_116, getitem_66);  _unsafe_view_default_116 = getitem_66 = None
        native_layer_norm_default_23 = torch.ops.aten.native_layer_norm.default(add__tensor_21, [512], primals_71, primals_70, 1e-06)
        getitem_69 = native_layer_norm_default_23[0]
        getitem_70 = native_layer_norm_default_23[1]
        getitem_71 = native_layer_norm_default_23[2];  native_layer_norm_default_23 = None
        t_default_70 = torch.ops.aten.t.default(primals_61);  primals_61 = None
        view_default_153 = torch.ops.aten.view.default(getitem_69, [7936, 512])
        mm_default_52 = torch.ops.aten.mm.default(view_default_153, t_default_70)
        _unsafe_view_default_117 = torch.ops.aten._unsafe_view.default(mm_default_52, [256, 31, 512]);  mm_default_52 = None
        view_default_154 = torch.ops.aten.view.default(_unsafe_view_default_117, [256, 31, 8, 64]);  _unsafe_view_default_117 = None
        t_default_71 = torch.ops.aten.t.default(primals_60);  primals_60 = None
        view_default_155 = torch.ops.aten.view.default(getitem_36, [8448, 512])
        mm_default_53 = torch.ops.aten.mm.default(view_default_155, t_default_71)
        _unsafe_view_default_118 = torch.ops.aten._unsafe_view.default(mm_default_53, [256, 33, 512]);  mm_default_53 = None
        view_default_156 = torch.ops.aten.view.default(_unsafe_view_default_118, [256, 33, 8, 64]);  _unsafe_view_default_118 = None
        t_default_72 = torch.ops.aten.t.default(primals_62);  primals_62 = None
        view_default_157 = torch.ops.aten.view.default(getitem_36, [8448, 512])
        mm_default_54 = torch.ops.aten.mm.default(view_default_157, t_default_72)
        _unsafe_view_default_119 = torch.ops.aten._unsafe_view.default(mm_default_54, [256, 33, 512]);  mm_default_54 = None
        view_default_158 = torch.ops.aten.view.default(_unsafe_view_default_119, [256, 33, 8, 64]);  _unsafe_view_default_119 = None
        transpose_int_65 = torch.ops.aten.transpose.int(view_default_154, 1, 2);  view_default_154 = None
        transpose_int_66 = torch.ops.aten.transpose.int(view_default_156, 1, 2);  view_default_156 = None
        transpose_int_67 = torch.ops.aten.transpose.int(view_default_158, 1, 2);  view_default_158 = None
        unsqueeze_default_15 = torch.ops.aten.unsqueeze.default(unsqueeze_default, 1)
        div_tensor_13 = torch.ops.aten.div.Tensor(transpose_int_65, 8.0);  transpose_int_65 = None
        transpose_int_68 = torch.ops.aten.transpose.int(transpose_int_66, 2, 3);  transpose_int_66 = None
        expand_default_52 = torch.ops.aten.expand.default(div_tensor_13, [256, 8, 31, 64]);  div_tensor_13 = None
        clone_default_54 = torch.ops.aten.clone.default(expand_default_52, memory_format = torch.contiguous_format);  expand_default_52 = None
        _unsafe_view_default_120 = torch.ops.aten._unsafe_view.default(clone_default_54, [2048, 31, 64]);  clone_default_54 = None
        expand_default_53 = torch.ops.aten.expand.default(transpose_int_68, [256, 8, 64, 33]);  transpose_int_68 = None
        clone_default_55 = torch.ops.aten.clone.default(expand_default_53, memory_format = torch.contiguous_format);  expand_default_53 = None
        _unsafe_view_default_121 = torch.ops.aten._unsafe_view.default(clone_default_55, [2048, 64, 33]);  clone_default_55 = None
        bmm_default_26 = torch.ops.aten.bmm.default(_unsafe_view_default_120, _unsafe_view_default_121)
        _unsafe_view_default_122 = torch.ops.aten._unsafe_view.default(bmm_default_26, [256, 8, 31, 33]);  bmm_default_26 = None
        eq_scalar_13 = torch.ops.aten.eq.Scalar(unsqueeze_default_15, 0);  unsqueeze_default_15 = None
        where_scalar_self_13 = torch.ops.aten.where.ScalarSelf(eq_scalar_13, -1000000000.0, _unsafe_view_default_122);  _unsafe_view_default_122 = None
        _softmax_default_13 = torch.ops.aten._softmax.default(where_scalar_self_13, -1, False);  where_scalar_self_13 = None
        expand_default_54 = torch.ops.aten.expand.default(_softmax_default_13, [256, 8, 31, 33])
        view_default_159 = torch.ops.aten.view.default(expand_default_54, [2048, 31, 33]);  expand_default_54 = None
        expand_default_55 = torch.ops.aten.expand.default(transpose_int_67, [256, 8, 33, 64]);  transpose_int_67 = None
        clone_default_56 = torch.ops.aten.clone.default(expand_default_55, memory_format = torch.contiguous_format);  expand_default_55 = None
        _unsafe_view_default_123 = torch.ops.aten._unsafe_view.default(clone_default_56, [2048, 33, 64]);  clone_default_56 = None
        bmm_default_27 = torch.ops.aten.bmm.default(view_default_159, _unsafe_view_default_123)
        _unsafe_view_default_124 = torch.ops.aten._unsafe_view.default(bmm_default_27, [256, 8, 31, 64]);  bmm_default_27 = None
        transpose_int_69 = torch.ops.aten.transpose.int(_unsafe_view_default_124, 1, 2);  _unsafe_view_default_124 = None
        clone_default_57 = torch.ops.aten.clone.default(transpose_int_69, memory_format = torch.contiguous_format);  transpose_int_69 = None
        view_default_160 = torch.ops.aten.view.default(clone_default_57, [256, 31, -1]);  clone_default_57 = None
        t_default_73 = torch.ops.aten.t.default(primals_57);  primals_57 = None
        view_default_161 = torch.ops.aten.view.default(view_default_160, [7936, 512]);  view_default_160 = None
        mm_default_55 = torch.ops.aten.mm.default(view_default_161, t_default_73)
        _unsafe_view_default_125 = torch.ops.aten._unsafe_view.default(mm_default_55, [256, 31, 512]);  mm_default_55 = None
        add__tensor_22 = torch.ops.aten.add_.Tensor(_unsafe_view_default_125, getitem_69);  _unsafe_view_default_125 = getitem_69 = None
        native_layer_norm_default_24 = torch.ops.aten.native_layer_norm.default(add__tensor_22, [512], primals_59, primals_58, 1e-06)
        getitem_72 = native_layer_norm_default_24[0]
        getitem_73 = native_layer_norm_default_24[1]
        getitem_74 = native_layer_norm_default_24[2];  native_layer_norm_default_24 = None
        view_default_162 = torch.ops.aten.view.default(getitem_72, [7936, 512])
        t_default_74 = torch.ops.aten.t.default(primals_66);  primals_66 = None
        addmm_default_18 = torch.ops.aten.addmm.default(primals_65, view_default_162, t_default_74);  primals_65 = None
        view_default_163 = torch.ops.aten.view.default(addmm_default_18, [256, 31, 2048]);  addmm_default_18 = None
        relu_default_9 = torch.ops.aten.relu.default(view_default_163);  view_default_163 = None
        view_default_164 = torch.ops.aten.view.default(relu_default_9, [7936, 2048])
        t_default_75 = torch.ops.aten.t.default(primals_68);  primals_68 = None
        addmm_default_19 = torch.ops.aten.addmm.default(primals_67, view_default_164, t_default_75);  primals_67 = None
        view_default_165 = torch.ops.aten.view.default(addmm_default_19, [256, 31, 512]);  addmm_default_19 = None
        add__tensor_23 = torch.ops.aten.add_.Tensor(view_default_165, getitem_72);  view_default_165 = getitem_72 = None
        native_layer_norm_default_25 = torch.ops.aten.native_layer_norm.default(add__tensor_23, [512], primals_64, primals_63, 1e-06)
        getitem_75 = native_layer_norm_default_25[0]
        getitem_76 = native_layer_norm_default_25[1]
        getitem_77 = native_layer_norm_default_25[2];  native_layer_norm_default_25 = None
        t_default_76 = torch.ops.aten.t.default(primals_91);  primals_91 = None
        view_default_166 = torch.ops.aten.view.default(getitem_75, [7936, 512])
        mm_default_56 = torch.ops.aten.mm.default(view_default_166, t_default_76)
        _unsafe_view_default_126 = torch.ops.aten._unsafe_view.default(mm_default_56, [256, 31, 512]);  mm_default_56 = None
        view_default_167 = torch.ops.aten.view.default(_unsafe_view_default_126, [256, 31, 8, 64]);  _unsafe_view_default_126 = None
        t_default_77 = torch.ops.aten.t.default(primals_90);  primals_90 = None
        view_default_168 = torch.ops.aten.view.default(getitem_75, [7936, 512])
        mm_default_57 = torch.ops.aten.mm.default(view_default_168, t_default_77)
        _unsafe_view_default_127 = torch.ops.aten._unsafe_view.default(mm_default_57, [256, 31, 512]);  mm_default_57 = None
        view_default_169 = torch.ops.aten.view.default(_unsafe_view_default_127, [256, 31, 8, 64]);  _unsafe_view_default_127 = None
        t_default_78 = torch.ops.aten.t.default(primals_92);  primals_92 = None
        view_default_170 = torch.ops.aten.view.default(getitem_75, [7936, 512])
        mm_default_58 = torch.ops.aten.mm.default(view_default_170, t_default_78)
        _unsafe_view_default_128 = torch.ops.aten._unsafe_view.default(mm_default_58, [256, 31, 512]);  mm_default_58 = None
        view_default_171 = torch.ops.aten.view.default(_unsafe_view_default_128, [256, 31, 8, 64]);  _unsafe_view_default_128 = None
        transpose_int_70 = torch.ops.aten.transpose.int(view_default_167, 1, 2);  view_default_167 = None
        transpose_int_71 = torch.ops.aten.transpose.int(view_default_169, 1, 2);  view_default_169 = None
        transpose_int_72 = torch.ops.aten.transpose.int(view_default_171, 1, 2);  view_default_171 = None
        unsqueeze_default_16 = torch.ops.aten.unsqueeze.default(bitwise_and_tensor, 1)
        div_tensor_14 = torch.ops.aten.div.Tensor(transpose_int_70, 8.0);  transpose_int_70 = None
        transpose_int_73 = torch.ops.aten.transpose.int(transpose_int_71, 2, 3);  transpose_int_71 = None
        expand_default_56 = torch.ops.aten.expand.default(div_tensor_14, [256, 8, 31, 64]);  div_tensor_14 = None
        clone_default_58 = torch.ops.aten.clone.default(expand_default_56, memory_format = torch.contiguous_format);  expand_default_56 = None
        _unsafe_view_default_129 = torch.ops.aten._unsafe_view.default(clone_default_58, [2048, 31, 64]);  clone_default_58 = None
        expand_default_57 = torch.ops.aten.expand.default(transpose_int_73, [256, 8, 64, 31]);  transpose_int_73 = None
        clone_default_59 = torch.ops.aten.clone.default(expand_default_57, memory_format = torch.contiguous_format);  expand_default_57 = None
        _unsafe_view_default_130 = torch.ops.aten._unsafe_view.default(clone_default_59, [2048, 64, 31]);  clone_default_59 = None
        bmm_default_28 = torch.ops.aten.bmm.default(_unsafe_view_default_129, _unsafe_view_default_130)
        _unsafe_view_default_131 = torch.ops.aten._unsafe_view.default(bmm_default_28, [256, 8, 31, 31]);  bmm_default_28 = None
        eq_scalar_14 = torch.ops.aten.eq.Scalar(unsqueeze_default_16, 0);  unsqueeze_default_16 = None
        where_scalar_self_14 = torch.ops.aten.where.ScalarSelf(eq_scalar_14, -1000000000.0, _unsafe_view_default_131);  _unsafe_view_default_131 = None
        _softmax_default_14 = torch.ops.aten._softmax.default(where_scalar_self_14, -1, False);  where_scalar_self_14 = None
        expand_default_58 = torch.ops.aten.expand.default(_softmax_default_14, [256, 8, 31, 31])
        view_default_172 = torch.ops.aten.view.default(expand_default_58, [2048, 31, 31]);  expand_default_58 = None
        expand_default_59 = torch.ops.aten.expand.default(transpose_int_72, [256, 8, 31, 64]);  transpose_int_72 = None
        clone_default_60 = torch.ops.aten.clone.default(expand_default_59, memory_format = torch.contiguous_format);  expand_default_59 = None
        _unsafe_view_default_132 = torch.ops.aten._unsafe_view.default(clone_default_60, [2048, 31, 64]);  clone_default_60 = None
        bmm_default_29 = torch.ops.aten.bmm.default(view_default_172, _unsafe_view_default_132)
        _unsafe_view_default_133 = torch.ops.aten._unsafe_view.default(bmm_default_29, [256, 8, 31, 64]);  bmm_default_29 = None
        transpose_int_74 = torch.ops.aten.transpose.int(_unsafe_view_default_133, 1, 2);  _unsafe_view_default_133 = None
        clone_default_61 = torch.ops.aten.clone.default(transpose_int_74, memory_format = torch.contiguous_format);  transpose_int_74 = None
        view_default_173 = torch.ops.aten.view.default(clone_default_61, [256, 31, -1]);  clone_default_61 = None
        t_default_79 = torch.ops.aten.t.default(primals_87);  primals_87 = None
        view_default_174 = torch.ops.aten.view.default(view_default_173, [7936, 512]);  view_default_173 = None
        mm_default_59 = torch.ops.aten.mm.default(view_default_174, t_default_79)
        _unsafe_view_default_134 = torch.ops.aten._unsafe_view.default(mm_default_59, [256, 31, 512]);  mm_default_59 = None
        add__tensor_24 = torch.ops.aten.add_.Tensor(_unsafe_view_default_134, getitem_75);  _unsafe_view_default_134 = getitem_75 = None
        native_layer_norm_default_26 = torch.ops.aten.native_layer_norm.default(add__tensor_24, [512], primals_89, primals_88, 1e-06)
        getitem_78 = native_layer_norm_default_26[0]
        getitem_79 = native_layer_norm_default_26[1]
        getitem_80 = native_layer_norm_default_26[2];  native_layer_norm_default_26 = None
        t_default_80 = torch.ops.aten.t.default(primals_79);  primals_79 = None
        view_default_175 = torch.ops.aten.view.default(getitem_78, [7936, 512])
        mm_default_60 = torch.ops.aten.mm.default(view_default_175, t_default_80)
        _unsafe_view_default_135 = torch.ops.aten._unsafe_view.default(mm_default_60, [256, 31, 512]);  mm_default_60 = None
        view_default_176 = torch.ops.aten.view.default(_unsafe_view_default_135, [256, 31, 8, 64]);  _unsafe_view_default_135 = None
        t_default_81 = torch.ops.aten.t.default(primals_78);  primals_78 = None
        view_default_177 = torch.ops.aten.view.default(getitem_36, [8448, 512])
        mm_default_61 = torch.ops.aten.mm.default(view_default_177, t_default_81)
        _unsafe_view_default_136 = torch.ops.aten._unsafe_view.default(mm_default_61, [256, 33, 512]);  mm_default_61 = None
        view_default_178 = torch.ops.aten.view.default(_unsafe_view_default_136, [256, 33, 8, 64]);  _unsafe_view_default_136 = None
        t_default_82 = torch.ops.aten.t.default(primals_80);  primals_80 = None
        view_default_179 = torch.ops.aten.view.default(getitem_36, [8448, 512])
        mm_default_62 = torch.ops.aten.mm.default(view_default_179, t_default_82)
        _unsafe_view_default_137 = torch.ops.aten._unsafe_view.default(mm_default_62, [256, 33, 512]);  mm_default_62 = None
        view_default_180 = torch.ops.aten.view.default(_unsafe_view_default_137, [256, 33, 8, 64]);  _unsafe_view_default_137 = None
        transpose_int_75 = torch.ops.aten.transpose.int(view_default_176, 1, 2);  view_default_176 = None
        transpose_int_76 = torch.ops.aten.transpose.int(view_default_178, 1, 2);  view_default_178 = None
        transpose_int_77 = torch.ops.aten.transpose.int(view_default_180, 1, 2);  view_default_180 = None
        unsqueeze_default_17 = torch.ops.aten.unsqueeze.default(unsqueeze_default, 1)
        div_tensor_15 = torch.ops.aten.div.Tensor(transpose_int_75, 8.0);  transpose_int_75 = None
        transpose_int_78 = torch.ops.aten.transpose.int(transpose_int_76, 2, 3);  transpose_int_76 = None
        expand_default_60 = torch.ops.aten.expand.default(div_tensor_15, [256, 8, 31, 64]);  div_tensor_15 = None
        clone_default_62 = torch.ops.aten.clone.default(expand_default_60, memory_format = torch.contiguous_format);  expand_default_60 = None
        _unsafe_view_default_138 = torch.ops.aten._unsafe_view.default(clone_default_62, [2048, 31, 64]);  clone_default_62 = None
        expand_default_61 = torch.ops.aten.expand.default(transpose_int_78, [256, 8, 64, 33]);  transpose_int_78 = None
        clone_default_63 = torch.ops.aten.clone.default(expand_default_61, memory_format = torch.contiguous_format);  expand_default_61 = None
        _unsafe_view_default_139 = torch.ops.aten._unsafe_view.default(clone_default_63, [2048, 64, 33]);  clone_default_63 = None
        bmm_default_30 = torch.ops.aten.bmm.default(_unsafe_view_default_138, _unsafe_view_default_139)
        _unsafe_view_default_140 = torch.ops.aten._unsafe_view.default(bmm_default_30, [256, 8, 31, 33]);  bmm_default_30 = None
        eq_scalar_15 = torch.ops.aten.eq.Scalar(unsqueeze_default_17, 0);  unsqueeze_default_17 = None
        where_scalar_self_15 = torch.ops.aten.where.ScalarSelf(eq_scalar_15, -1000000000.0, _unsafe_view_default_140);  _unsafe_view_default_140 = None
        _softmax_default_15 = torch.ops.aten._softmax.default(where_scalar_self_15, -1, False);  where_scalar_self_15 = None
        expand_default_62 = torch.ops.aten.expand.default(_softmax_default_15, [256, 8, 31, 33])
        view_default_181 = torch.ops.aten.view.default(expand_default_62, [2048, 31, 33]);  expand_default_62 = None
        expand_default_63 = torch.ops.aten.expand.default(transpose_int_77, [256, 8, 33, 64]);  transpose_int_77 = None
        clone_default_64 = torch.ops.aten.clone.default(expand_default_63, memory_format = torch.contiguous_format);  expand_default_63 = None
        _unsafe_view_default_141 = torch.ops.aten._unsafe_view.default(clone_default_64, [2048, 33, 64]);  clone_default_64 = None
        bmm_default_31 = torch.ops.aten.bmm.default(view_default_181, _unsafe_view_default_141)
        _unsafe_view_default_142 = torch.ops.aten._unsafe_view.default(bmm_default_31, [256, 8, 31, 64]);  bmm_default_31 = None
        transpose_int_79 = torch.ops.aten.transpose.int(_unsafe_view_default_142, 1, 2);  _unsafe_view_default_142 = None
        clone_default_65 = torch.ops.aten.clone.default(transpose_int_79, memory_format = torch.contiguous_format);  transpose_int_79 = None
        view_default_182 = torch.ops.aten.view.default(clone_default_65, [256, 31, -1]);  clone_default_65 = None
        t_default_83 = torch.ops.aten.t.default(primals_75);  primals_75 = None
        view_default_183 = torch.ops.aten.view.default(view_default_182, [7936, 512]);  view_default_182 = None
        mm_default_63 = torch.ops.aten.mm.default(view_default_183, t_default_83)
        _unsafe_view_default_143 = torch.ops.aten._unsafe_view.default(mm_default_63, [256, 31, 512]);  mm_default_63 = None
        add__tensor_25 = torch.ops.aten.add_.Tensor(_unsafe_view_default_143, getitem_78);  _unsafe_view_default_143 = getitem_78 = None
        native_layer_norm_default_27 = torch.ops.aten.native_layer_norm.default(add__tensor_25, [512], primals_77, primals_76, 1e-06)
        getitem_81 = native_layer_norm_default_27[0]
        getitem_82 = native_layer_norm_default_27[1]
        getitem_83 = native_layer_norm_default_27[2];  native_layer_norm_default_27 = None
        view_default_184 = torch.ops.aten.view.default(getitem_81, [7936, 512])
        t_default_84 = torch.ops.aten.t.default(primals_84);  primals_84 = None
        addmm_default_20 = torch.ops.aten.addmm.default(primals_83, view_default_184, t_default_84);  primals_83 = None
        view_default_185 = torch.ops.aten.view.default(addmm_default_20, [256, 31, 2048]);  addmm_default_20 = None
        relu_default_10 = torch.ops.aten.relu.default(view_default_185);  view_default_185 = None
        view_default_186 = torch.ops.aten.view.default(relu_default_10, [7936, 2048])
        t_default_85 = torch.ops.aten.t.default(primals_86);  primals_86 = None
        addmm_default_21 = torch.ops.aten.addmm.default(primals_85, view_default_186, t_default_85);  primals_85 = None
        view_default_187 = torch.ops.aten.view.default(addmm_default_21, [256, 31, 512]);  addmm_default_21 = None
        add__tensor_26 = torch.ops.aten.add_.Tensor(view_default_187, getitem_81);  view_default_187 = getitem_81 = None
        native_layer_norm_default_28 = torch.ops.aten.native_layer_norm.default(add__tensor_26, [512], primals_82, primals_81, 1e-06)
        getitem_84 = native_layer_norm_default_28[0]
        getitem_85 = native_layer_norm_default_28[1]
        getitem_86 = native_layer_norm_default_28[2];  native_layer_norm_default_28 = None
        t_default_86 = torch.ops.aten.t.default(primals_109);  primals_109 = None
        view_default_188 = torch.ops.aten.view.default(getitem_84, [7936, 512])
        mm_default_64 = torch.ops.aten.mm.default(view_default_188, t_default_86)
        _unsafe_view_default_144 = torch.ops.aten._unsafe_view.default(mm_default_64, [256, 31, 512]);  mm_default_64 = None
        view_default_189 = torch.ops.aten.view.default(_unsafe_view_default_144, [256, 31, 8, 64]);  _unsafe_view_default_144 = None
        t_default_87 = torch.ops.aten.t.default(primals_108);  primals_108 = None
        view_default_190 = torch.ops.aten.view.default(getitem_84, [7936, 512])
        mm_default_65 = torch.ops.aten.mm.default(view_default_190, t_default_87)
        _unsafe_view_default_145 = torch.ops.aten._unsafe_view.default(mm_default_65, [256, 31, 512]);  mm_default_65 = None
        view_default_191 = torch.ops.aten.view.default(_unsafe_view_default_145, [256, 31, 8, 64]);  _unsafe_view_default_145 = None
        t_default_88 = torch.ops.aten.t.default(primals_110);  primals_110 = None
        view_default_192 = torch.ops.aten.view.default(getitem_84, [7936, 512])
        mm_default_66 = torch.ops.aten.mm.default(view_default_192, t_default_88)
        _unsafe_view_default_146 = torch.ops.aten._unsafe_view.default(mm_default_66, [256, 31, 512]);  mm_default_66 = None
        view_default_193 = torch.ops.aten.view.default(_unsafe_view_default_146, [256, 31, 8, 64]);  _unsafe_view_default_146 = None
        transpose_int_80 = torch.ops.aten.transpose.int(view_default_189, 1, 2);  view_default_189 = None
        transpose_int_81 = torch.ops.aten.transpose.int(view_default_191, 1, 2);  view_default_191 = None
        transpose_int_82 = torch.ops.aten.transpose.int(view_default_193, 1, 2);  view_default_193 = None
        unsqueeze_default_18 = torch.ops.aten.unsqueeze.default(bitwise_and_tensor, 1);  bitwise_and_tensor = None
        div_tensor_16 = torch.ops.aten.div.Tensor(transpose_int_80, 8.0);  transpose_int_80 = None
        transpose_int_83 = torch.ops.aten.transpose.int(transpose_int_81, 2, 3);  transpose_int_81 = None
        expand_default_64 = torch.ops.aten.expand.default(div_tensor_16, [256, 8, 31, 64]);  div_tensor_16 = None
        clone_default_66 = torch.ops.aten.clone.default(expand_default_64, memory_format = torch.contiguous_format);  expand_default_64 = None
        _unsafe_view_default_147 = torch.ops.aten._unsafe_view.default(clone_default_66, [2048, 31, 64]);  clone_default_66 = None
        expand_default_65 = torch.ops.aten.expand.default(transpose_int_83, [256, 8, 64, 31]);  transpose_int_83 = None
        clone_default_67 = torch.ops.aten.clone.default(expand_default_65, memory_format = torch.contiguous_format);  expand_default_65 = None
        _unsafe_view_default_148 = torch.ops.aten._unsafe_view.default(clone_default_67, [2048, 64, 31]);  clone_default_67 = None
        bmm_default_32 = torch.ops.aten.bmm.default(_unsafe_view_default_147, _unsafe_view_default_148)
        _unsafe_view_default_149 = torch.ops.aten._unsafe_view.default(bmm_default_32, [256, 8, 31, 31]);  bmm_default_32 = None
        eq_scalar_16 = torch.ops.aten.eq.Scalar(unsqueeze_default_18, 0);  unsqueeze_default_18 = None
        where_scalar_self_16 = torch.ops.aten.where.ScalarSelf(eq_scalar_16, -1000000000.0, _unsafe_view_default_149);  _unsafe_view_default_149 = None
        _softmax_default_16 = torch.ops.aten._softmax.default(where_scalar_self_16, -1, False);  where_scalar_self_16 = None
        expand_default_66 = torch.ops.aten.expand.default(_softmax_default_16, [256, 8, 31, 31])
        view_default_194 = torch.ops.aten.view.default(expand_default_66, [2048, 31, 31]);  expand_default_66 = None
        expand_default_67 = torch.ops.aten.expand.default(transpose_int_82, [256, 8, 31, 64]);  transpose_int_82 = None
        clone_default_68 = torch.ops.aten.clone.default(expand_default_67, memory_format = torch.contiguous_format);  expand_default_67 = None
        _unsafe_view_default_150 = torch.ops.aten._unsafe_view.default(clone_default_68, [2048, 31, 64]);  clone_default_68 = None
        bmm_default_33 = torch.ops.aten.bmm.default(view_default_194, _unsafe_view_default_150)
        _unsafe_view_default_151 = torch.ops.aten._unsafe_view.default(bmm_default_33, [256, 8, 31, 64]);  bmm_default_33 = None
        transpose_int_84 = torch.ops.aten.transpose.int(_unsafe_view_default_151, 1, 2);  _unsafe_view_default_151 = None
        clone_default_69 = torch.ops.aten.clone.default(transpose_int_84, memory_format = torch.contiguous_format);  transpose_int_84 = None
        view_default_195 = torch.ops.aten.view.default(clone_default_69, [256, 31, -1]);  clone_default_69 = None
        t_default_89 = torch.ops.aten.t.default(primals_105);  primals_105 = None
        view_default_196 = torch.ops.aten.view.default(view_default_195, [7936, 512]);  view_default_195 = None
        mm_default_67 = torch.ops.aten.mm.default(view_default_196, t_default_89)
        _unsafe_view_default_152 = torch.ops.aten._unsafe_view.default(mm_default_67, [256, 31, 512]);  mm_default_67 = None
        add__tensor_27 = torch.ops.aten.add_.Tensor(_unsafe_view_default_152, getitem_84);  _unsafe_view_default_152 = getitem_84 = None
        native_layer_norm_default_29 = torch.ops.aten.native_layer_norm.default(add__tensor_27, [512], primals_107, primals_106, 1e-06)
        getitem_87 = native_layer_norm_default_29[0]
        getitem_88 = native_layer_norm_default_29[1]
        getitem_89 = native_layer_norm_default_29[2];  native_layer_norm_default_29 = None
        t_default_90 = torch.ops.aten.t.default(primals_97);  primals_97 = None
        view_default_197 = torch.ops.aten.view.default(getitem_87, [7936, 512])
        mm_default_68 = torch.ops.aten.mm.default(view_default_197, t_default_90)
        _unsafe_view_default_153 = torch.ops.aten._unsafe_view.default(mm_default_68, [256, 31, 512]);  mm_default_68 = None
        view_default_198 = torch.ops.aten.view.default(_unsafe_view_default_153, [256, 31, 8, 64]);  _unsafe_view_default_153 = None
        t_default_91 = torch.ops.aten.t.default(primals_96);  primals_96 = None
        view_default_199 = torch.ops.aten.view.default(getitem_36, [8448, 512])
        mm_default_69 = torch.ops.aten.mm.default(view_default_199, t_default_91)
        _unsafe_view_default_154 = torch.ops.aten._unsafe_view.default(mm_default_69, [256, 33, 512]);  mm_default_69 = None
        view_default_200 = torch.ops.aten.view.default(_unsafe_view_default_154, [256, 33, 8, 64]);  _unsafe_view_default_154 = None
        t_default_92 = torch.ops.aten.t.default(primals_98);  primals_98 = None
        view_default_201 = torch.ops.aten.view.default(getitem_36, [8448, 512]);  getitem_36 = None
        mm_default_70 = torch.ops.aten.mm.default(view_default_201, t_default_92)
        _unsafe_view_default_155 = torch.ops.aten._unsafe_view.default(mm_default_70, [256, 33, 512]);  mm_default_70 = None
        view_default_202 = torch.ops.aten.view.default(_unsafe_view_default_155, [256, 33, 8, 64]);  _unsafe_view_default_155 = None
        transpose_int_85 = torch.ops.aten.transpose.int(view_default_198, 1, 2);  view_default_198 = None
        transpose_int_86 = torch.ops.aten.transpose.int(view_default_200, 1, 2);  view_default_200 = None
        transpose_int_87 = torch.ops.aten.transpose.int(view_default_202, 1, 2);  view_default_202 = None
        unsqueeze_default_19 = torch.ops.aten.unsqueeze.default(unsqueeze_default, 1);  unsqueeze_default = None
        div_tensor_17 = torch.ops.aten.div.Tensor(transpose_int_85, 8.0);  transpose_int_85 = None
        transpose_int_88 = torch.ops.aten.transpose.int(transpose_int_86, 2, 3);  transpose_int_86 = None
        expand_default_68 = torch.ops.aten.expand.default(div_tensor_17, [256, 8, 31, 64]);  div_tensor_17 = None
        clone_default_70 = torch.ops.aten.clone.default(expand_default_68, memory_format = torch.contiguous_format);  expand_default_68 = None
        _unsafe_view_default_156 = torch.ops.aten._unsafe_view.default(clone_default_70, [2048, 31, 64]);  clone_default_70 = None
        expand_default_69 = torch.ops.aten.expand.default(transpose_int_88, [256, 8, 64, 33]);  transpose_int_88 = None
        clone_default_71 = torch.ops.aten.clone.default(expand_default_69, memory_format = torch.contiguous_format);  expand_default_69 = None
        _unsafe_view_default_157 = torch.ops.aten._unsafe_view.default(clone_default_71, [2048, 64, 33]);  clone_default_71 = None
        bmm_default_34 = torch.ops.aten.bmm.default(_unsafe_view_default_156, _unsafe_view_default_157)
        _unsafe_view_default_158 = torch.ops.aten._unsafe_view.default(bmm_default_34, [256, 8, 31, 33]);  bmm_default_34 = None
        eq_scalar_17 = torch.ops.aten.eq.Scalar(unsqueeze_default_19, 0);  unsqueeze_default_19 = None
        where_scalar_self_17 = torch.ops.aten.where.ScalarSelf(eq_scalar_17, -1000000000.0, _unsafe_view_default_158);  _unsafe_view_default_158 = None
        _softmax_default_17 = torch.ops.aten._softmax.default(where_scalar_self_17, -1, False);  where_scalar_self_17 = None
        expand_default_70 = torch.ops.aten.expand.default(_softmax_default_17, [256, 8, 31, 33])
        view_default_203 = torch.ops.aten.view.default(expand_default_70, [2048, 31, 33]);  expand_default_70 = None
        expand_default_71 = torch.ops.aten.expand.default(transpose_int_87, [256, 8, 33, 64]);  transpose_int_87 = None
        clone_default_72 = torch.ops.aten.clone.default(expand_default_71, memory_format = torch.contiguous_format);  expand_default_71 = None
        _unsafe_view_default_159 = torch.ops.aten._unsafe_view.default(clone_default_72, [2048, 33, 64]);  clone_default_72 = None
        bmm_default_35 = torch.ops.aten.bmm.default(view_default_203, _unsafe_view_default_159)
        _unsafe_view_default_160 = torch.ops.aten._unsafe_view.default(bmm_default_35, [256, 8, 31, 64]);  bmm_default_35 = None
        transpose_int_89 = torch.ops.aten.transpose.int(_unsafe_view_default_160, 1, 2);  _unsafe_view_default_160 = None
        clone_default_73 = torch.ops.aten.clone.default(transpose_int_89, memory_format = torch.contiguous_format);  transpose_int_89 = None
        view_default_204 = torch.ops.aten.view.default(clone_default_73, [256, 31, -1]);  clone_default_73 = None
        t_default_93 = torch.ops.aten.t.default(primals_93);  primals_93 = None
        view_default_205 = torch.ops.aten.view.default(view_default_204, [7936, 512]);  view_default_204 = None
        mm_default_71 = torch.ops.aten.mm.default(view_default_205, t_default_93)
        _unsafe_view_default_161 = torch.ops.aten._unsafe_view.default(mm_default_71, [256, 31, 512]);  mm_default_71 = None
        add__tensor_28 = torch.ops.aten.add_.Tensor(_unsafe_view_default_161, getitem_87);  _unsafe_view_default_161 = getitem_87 = None
        native_layer_norm_default_30 = torch.ops.aten.native_layer_norm.default(add__tensor_28, [512], primals_95, primals_94, 1e-06)
        getitem_90 = native_layer_norm_default_30[0]
        getitem_91 = native_layer_norm_default_30[1]
        getitem_92 = native_layer_norm_default_30[2];  native_layer_norm_default_30 = None
        view_default_206 = torch.ops.aten.view.default(getitem_90, [7936, 512])
        t_default_94 = torch.ops.aten.t.default(primals_102);  primals_102 = None
        addmm_default_22 = torch.ops.aten.addmm.default(primals_101, view_default_206, t_default_94);  primals_101 = None
        view_default_207 = torch.ops.aten.view.default(addmm_default_22, [256, 31, 2048]);  addmm_default_22 = None
        relu_default_11 = torch.ops.aten.relu.default(view_default_207);  view_default_207 = None
        view_default_208 = torch.ops.aten.view.default(relu_default_11, [7936, 2048])
        t_default_95 = torch.ops.aten.t.default(primals_104);  primals_104 = None
        addmm_default_23 = torch.ops.aten.addmm.default(primals_103, view_default_208, t_default_95);  primals_103 = None
        view_default_209 = torch.ops.aten.view.default(addmm_default_23, [256, 31, 512]);  addmm_default_23 = None
        add__tensor_29 = torch.ops.aten.add_.Tensor(view_default_209, getitem_90);  view_default_209 = getitem_90 = None
        native_layer_norm_default_31 = torch.ops.aten.native_layer_norm.default(add__tensor_29, [512], primals_100, primals_99, 1e-06)
        getitem_93 = native_layer_norm_default_31[0]
        getitem_94 = native_layer_norm_default_31[1]
        getitem_95 = native_layer_norm_default_31[2];  native_layer_norm_default_31 = None
        t_default_96 = torch.ops.aten.t.default(primals_189);  primals_189 = None
        view_default_210 = torch.ops.aten.view.default(getitem_93, [7936, 512]);  getitem_93 = None
        mm_default_72 = torch.ops.aten.mm.default(view_default_210, t_default_96)
        _unsafe_view_default_162 = torch.ops.aten._unsafe_view.default(mm_default_72, [256, 31, 9521]);  mm_default_72 = None
        mul_tensor = torch.ops.aten.mul.Tensor(_unsafe_view_default_162, 1.0);  _unsafe_view_default_162 = None
        view_default_211 = torch.ops.aten.view.default(mul_tensor, [-1, 9521]);  mul_tensor = None
        return [view_default_211, primals_183, primals_76, primals_171, primals_77, primals_182, primals_175, primals_176, primals_22, primals_28, primals_23, primals_27, _unsafe_view_default_15, t_default_57, add__tensor_2, _unsafe_view_default_96, t_default_55, _softmax_default_1, t_default_9, getitem_58, _unsafe_view_default_13, _unsafe_view_default_93, getitem_59, t_default_56, view_default_122, _unsafe_view_default_12, view_default_19, _unsafe_view_default_94, eq_scalar_10, view_default_124, _unsafe_view_default_102, t_default_58, primals_170, add__tensor_13, view_default_152, view_default_96, primals_41, eq_scalar_13, view_default_91, add__tensor_14, t_default_69, _softmax_default_7, view_default_98, t_default_42, view_default_95, getitem_71, relu_default_6, t_default_70, primals_158, primals_35, primals_159, getitem_70, primals_40, _unsafe_view_default_69, t_default_43, _unsafe_view_default_120, primals_163, view_default_153, primals_164, t_default_71, view_default_93, primals_34, _unsafe_view_default_49, relu_default, getitem_8, view_default_192, _softmax_default_2, getitem_23, add__tensor_4, getitem_22, t_default_15, view_default_11, add__tensor_10, view_default_71, t_default_22, view_default_194, _unsafe_view_default_21, relu_default_3, view_default_73, view_default_196, add__tensor_27, view_default_50, _unsafe_view_default_157, _unsafe_view_default_51, t_default_89, t_default_5, t_default_23, t_default_33, view_default_32, _unsafe_view_default_22, t_default_24, view_default_34, _softmax_default_5, _unsafe_view_default_24, view_default_35, getitem_25, add__tensor_1, _unsafe_view_default_48, getitem_88, add__tensor_7, getitem_89, getitem_26, t_default_90, getitem_20, _unsafe_view_default_103, getitem_1, t_default, t_default_20, view_default_41, view_default_131, getitem_13, add__tensor_12, primals_123, relu_default_8, t_default_8, eq_scalar_11, t_default_61, _unsafe_view_default_105, view_default, eq_scalar_3, view_default_133, t_default_12, view_default_142, _unsafe_view_default_112, add__tensor_20, view_default_15, getitem_14, t_default_62, view_default_135, primals_122, view_default_17, _softmax_default_11, view_default_39, view_default_137, add__tensor_19, t_default_7, t_default_19, view_default_43, getitem_2, view_default_26, view_default_13, eq_scalar_1, add_tensor, primals_71, primals_147, primals_70, primals_146, primals_89, primals_81, primals_88, primals_63, primals_82, primals_64, view_default_37, t_default_16, t_default_17, getitem_19, getitem_16, add__tensor_5, relu_default_2, getitem_17, t_default_18, getitem_37, getitem_40, add_tensor_1, getitem_38, t_default_36, getitem_41, t_default_37, view_default_80, view_default_78, t_default_76, getitem_74, getitem_73, t_default_74, getitem_76, t_default_75, _unsafe_view_default_130, _unsafe_view_default_129, getitem_77, view_default_166, _softmax_default_15, add__tensor_25, view_default_183, t_default_83, view_default_181, getitem_83, t_default_84, getitem_7, view_default_203, t_default_6, view_default_184, getitem_82, primals_16, primals_140, primals_139, getitem_31, view_default_65, getitem_32, add__tensor_9, primals_134, t_default_29, t_default_30, view_default_63, relu_default_4, t_default_28, primals_135, primals_127, primals_128, getitem_44, _unsafe_view_default_66, _unsafe_view_default_87, t_default_41, view_default_102, t_default_50, _softmax_default_8, t_default_48, eq_scalar_7, view_default_104, eq_scalar_8, add__tensor_17, view_default_87, t_default_39, add__tensor_15, view_default_89, _unsafe_view_default_60, getitem_43, _unsafe_view_default_67, t_default_49, view_default_106, view_default_86, _unsafe_view_default_78, primals_45, _unsafe_view_default_159, view_default_197, primals_53, primals_52, relu_default_11, primals_58, t_default_91, primals_59, eq_scalar_17, view_default_199, add__tensor_29, t_default_92, view_default_201, primals_46, add__tensor_28, _softmax_default_17, view_default_208, _softmax_default_16, t_default_87, t_default_85, getitem_85, _unsafe_view_default_147, getitem_86, t_default_86, view_default_188, _unsafe_view_default_148, t_default_88, view_default_190, eq_scalar_16, t_default_63, view_default_139, getitem_65, getitem_64, view_default_140, t_default_64, t_default_65, t_default_66, _unsafe_view_default_121, primals_114, getitem_95, getitem_94, view_default_210, eq_scalar_5, view_default_67, primals_116, primals_113, t_default_31, _unsafe_view_default_156, primals_115, view_default_69, primals_107, _unsafe_view_default_150, primals_17, t_default_32, _unsafe_view_default_141, t_default_77, add__tensor_24, view_default_168, _softmax_default_14, t_default_78, view_default_170, eq_scalar_14, primals_151, view_default_172, t_default_79, add__tensor_26, t_default_80, primals_152, _unsafe_view_default_132, view_default_4, _unsafe_view_default_3, view_default_115, t_default_1, view_default_2, add__tensor_16, view_default_117, t_default_2, view_default_6, _softmax_default, t_default_53, add__tensor, eq_scalar, getitem_56, view_default_118, t_default_54, getitem_55, view_default_126, view_default_9, _softmax_default_10, t_default_4, add__tensor_18, view_default_130, _unsafe_view_default_4, getitem_5, t_default_59, primals_191, getitem_4, view_default_128, _unsafe_view_default_6, getitem_61, view_default_8, t_default_3, primals_190, t_default_60, getitem_62, primals_1, _softmax_default_13, getitem_91, view_default_155, view_default_205, t_default_93, t_default_72, view_default_164, view_default_157, primals_5, getitem_92, add__tensor_23, view_default_206, primals_9, view_default_162, add__tensor_22, t_default_94, primals_4, _unsafe_view_default_123, relu_default_9, view_default_159, t_default_95, primals_2, t_default_73, t_default_96, primals_10, view_default_161, t_default_13, view_default_30, t_default_14, _unsafe_view_default_39, t_default_27, view_default_60, view_default_61, _unsafe_view_default_40, view_default_58, _unsafe_view_default_42, view_default_28, getitem_29, eq_scalar_2, getitem_28, view_default_120, view_default_108, t_default_52, getitem_52, getitem_53, _softmax_default_9, eq_scalar_9, view_default_109, t_default_51, _unsafe_view_default_84, view_default_111, relu_default_7, _unsafe_view_default_85, view_default_113, getitem_68, view_default_186, getitem_67, _softmax_default_4, view_default_174, _softmax_default_3, view_default_48, t_default_82, view_default_52, view_default_150, getitem_79, view_default_47, view_default_144, getitem_80, add__tensor_8, t_default_21, _unsafe_view_default_31, t_default_67, view_default_175, _unsafe_view_default_111, view_default_146, _unsafe_view_default_33, eq_scalar_15, t_default_26, view_default_54, _unsafe_view_default_139, t_default_81, _softmax_default_12, _unsafe_view_default_138, view_default_177, t_default_68, view_default_148, eq_scalar_4, t_default_25, add__tensor_6, relu_default_10, view_default_45, add__tensor_21, _unsafe_view_default_30, view_default_56, eq_scalar_12, view_default_179, _unsafe_view_default_114, getitem_47, primals_106, getitem_46, t_default_44, t_default_45, _unsafe_view_default_76, getitem_49, getitem_50, t_default_47, view_default_100, t_default_46, _unsafe_view_default_75, primals_99, primals_94, primals_95, primals_100, relu_default_5, view_default_74, getitem_34, t_default_35, view_default_76, getitem_35, t_default_34, add__tensor_11, t_default_10, t_default_11, getitem_11, add__tensor_3, _unsafe_view_default_58, getitem_10, view_default_21, view_default_82, t_default_40, eq_scalar_6, view_default_84, view_default_24, view_default_22, t_default_38, relu_default_1, _unsafe_view_default_57, _softmax_default_6]
        
