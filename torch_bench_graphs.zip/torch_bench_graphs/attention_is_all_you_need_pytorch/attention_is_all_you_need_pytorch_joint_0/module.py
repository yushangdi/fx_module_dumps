
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/attention_is_all_you_need_pytorch/attention_is_all_you_need_pytorch_joint_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, tangents_1):
        ne_scalar = torch.ops.aten.ne.Scalar(primals_190, 1)
        unsqueeze_default = torch.ops.aten.unsqueeze.default(ne_scalar, -2);  ne_scalar = None
        ne_scalar_1 = torch.ops.aten.ne.Scalar(primals_191, 1)
        unsqueeze_default_1 = torch.ops.aten.unsqueeze.default(ne_scalar_1, -2);  ne_scalar_1 = None
        ones = torch.ops.aten.ones.default([1, 31, 31], dtype = torch.float32, device = device(type='cuda', index=0), pin_memory = False)
        triu_default = torch.ops.aten.triu.default(ones, 1);  ones = None
        rsub_scalar = torch.ops.aten.rsub.Scalar(triu_default, 1);  triu_default = None
        _to_copy_default = torch.ops.aten._to_copy.default(rsub_scalar, dtype = torch.bool);  rsub_scalar = None
        bitwise_and_tensor = torch.ops.aten.bitwise_and.Tensor(unsqueeze_default_1, _to_copy_default);  unsqueeze_default_1 = _to_copy_default = None
        embedding_default = torch.ops.aten.embedding.default(primals_188, primals_190, 1);  primals_188 = None
        slice_tensor = torch.ops.aten.slice.Tensor(primals_187, 0, 0, 9223372036854775807);  primals_187 = None
        slice_tensor_1 = torch.ops.aten.slice.Tensor(slice_tensor, 1, 0, 33);  slice_tensor = None
        clone_default = torch.ops.aten.clone.default(slice_tensor_1);  slice_tensor_1 = None
        add_tensor = torch.ops.aten.add.Tensor(embedding_default, clone_default);  embedding_default = clone_default = None
        native_layer_norm_default = torch.ops.aten.native_layer_norm.default(add_tensor, [512], primals_114, primals_113, 1e-06)
        getitem = native_layer_norm_default[0]
        getitem_1 = native_layer_norm_default[1]
        getitem_2 = native_layer_norm_default[2];  native_layer_norm_default = None
        t_default = torch.ops.aten.t.default(primals_125);  primals_125 = None
        view_default = torch.ops.aten.view.default(getitem, [8448, 512])
        mm_default = torch.ops.aten.mm.default(view_default, t_default)
        _unsafe_view_default = torch.ops.aten._unsafe_view.default(mm_default, [256, 33, 512]);  mm_default = None
        view_default_1 = torch.ops.aten.view.default(_unsafe_view_default, [256, 33, 8, 64]);  _unsafe_view_default = None
        t_default_1 = torch.ops.aten.t.default(primals_124);  primals_124 = None
        view_default_2 = torch.ops.aten.view.default(getitem, [8448, 512])
        mm_default_1 = torch.ops.aten.mm.default(view_default_2, t_default_1)
        _unsafe_view_default_1 = torch.ops.aten._unsafe_view.default(mm_default_1, [256, 33, 512]);  mm_default_1 = None
        view_default_3 = torch.ops.aten.view.default(_unsafe_view_default_1, [256, 33, 8, 64]);  _unsafe_view_default_1 = None
        t_default_2 = torch.ops.aten.t.default(primals_126);  primals_126 = None
        view_default_4 = torch.ops.aten.view.default(getitem, [8448, 512])
        mm_default_2 = torch.ops.aten.mm.default(view_default_4, t_default_2)
        _unsafe_view_default_2 = torch.ops.aten._unsafe_view.default(mm_default_2, [256, 33, 512]);  mm_default_2 = None
        view_default_5 = torch.ops.aten.view.default(_unsafe_view_default_2, [256, 33, 8, 64]);  _unsafe_view_default_2 = None
        transpose_int = torch.ops.aten.transpose.int(view_default_1, 1, 2);  view_default_1 = None
        transpose_int_1 = torch.ops.aten.transpose.int(view_default_3, 1, 2);  view_default_3 = None
        transpose_int_2 = torch.ops.aten.transpose.int(view_default_5, 1, 2);  view_default_5 = None
        unsqueeze_default_2 = torch.ops.aten.unsqueeze.default(unsqueeze_default, 1)
        div_tensor = torch.ops.aten.div.Tensor(transpose_int, 8.0);  transpose_int = None
        transpose_int_3 = torch.ops.aten.transpose.int(transpose_int_1, 2, 3);  transpose_int_1 = None
        expand_default = torch.ops.aten.expand.default(div_tensor, [256, 8, 33, 64]);  div_tensor = None
        clone_default_1 = torch.ops.aten.clone.default(expand_default, memory_format = torch.contiguous_format);  expand_default = None
        _unsafe_view_default_3 = torch.ops.aten._unsafe_view.default(clone_default_1, [2048, 33, 64]);  clone_default_1 = None
        expand_default_1 = torch.ops.aten.expand.default(transpose_int_3, [256, 8, 64, 33]);  transpose_int_3 = None
        clone_default_2 = torch.ops.aten.clone.default(expand_default_1, memory_format = torch.contiguous_format);  expand_default_1 = None
        _unsafe_view_default_4 = torch.ops.aten._unsafe_view.default(clone_default_2, [2048, 64, 33]);  clone_default_2 = None
        bmm_default = torch.ops.aten.bmm.default(_unsafe_view_default_3, _unsafe_view_default_4)
        _unsafe_view_default_5 = torch.ops.aten._unsafe_view.default(bmm_default, [256, 8, 33, 33]);  bmm_default = None
        eq_scalar = torch.ops.aten.eq.Scalar(unsqueeze_default_2, 0);  unsqueeze_default_2 = None
        where_scalar_self = torch.ops.aten.where.ScalarSelf(eq_scalar, -1000000000.0, _unsafe_view_default_5);  _unsafe_view_default_5 = None
        _softmax_default = torch.ops.aten._softmax.default(where_scalar_self, -1, False);  where_scalar_self = None
        expand_default_2 = torch.ops.aten.expand.default(_softmax_default, [256, 8, 33, 33])
        view_default_6 = torch.ops.aten.view.default(expand_default_2, [2048, 33, 33]);  expand_default_2 = None
        expand_default_3 = torch.ops.aten.expand.default(transpose_int_2, [256, 8, 33, 64]);  transpose_int_2 = None
        clone_default_3 = torch.ops.aten.clone.default(expand_default_3, memory_format = torch.contiguous_format);  expand_default_3 = None
        _unsafe_view_default_6 = torch.ops.aten._unsafe_view.default(clone_default_3, [2048, 33, 64]);  clone_default_3 = None
        bmm_default_1 = torch.ops.aten.bmm.default(view_default_6, _unsafe_view_default_6)
        _unsafe_view_default_7 = torch.ops.aten._unsafe_view.default(bmm_default_1, [256, 8, 33, 64]);  bmm_default_1 = None
        transpose_int_4 = torch.ops.aten.transpose.int(_unsafe_view_default_7, 1, 2);  _unsafe_view_default_7 = None
        clone_default_4 = torch.ops.aten.clone.default(transpose_int_4, memory_format = torch.contiguous_format);  transpose_int_4 = None
        view_default_7 = torch.ops.aten.view.default(clone_default_4, [256, 33, -1]);  clone_default_4 = None
        t_default_3 = torch.ops.aten.t.default(primals_121);  primals_121 = None
        view_default_8 = torch.ops.aten.view.default(view_default_7, [8448, 512]);  view_default_7 = None
        mm_default_3 = torch.ops.aten.mm.default(view_default_8, t_default_3)
        _unsafe_view_default_8 = torch.ops.aten._unsafe_view.default(mm_default_3, [256, 33, 512]);  mm_default_3 = None
        add__tensor = torch.ops.aten.add_.Tensor(_unsafe_view_default_8, getitem);  _unsafe_view_default_8 = getitem = None
        native_layer_norm_default_1 = torch.ops.aten.native_layer_norm.default(add__tensor, [512], primals_123, primals_122, 1e-06)
        getitem_3 = native_layer_norm_default_1[0]
        getitem_4 = native_layer_norm_default_1[1]
        getitem_5 = native_layer_norm_default_1[2];  native_layer_norm_default_1 = None
        view_default_9 = torch.ops.aten.view.default(getitem_3, [8448, 512])
        t_default_4 = torch.ops.aten.t.default(primals_118);  primals_118 = None
        addmm_default = torch.ops.aten.addmm.default(primals_117, view_default_9, t_default_4);  primals_117 = None
        view_default_10 = torch.ops.aten.view.default(addmm_default, [256, 33, 2048]);  addmm_default = None
        relu_default = torch.ops.aten.relu.default(view_default_10);  view_default_10 = None
        view_default_11 = torch.ops.aten.view.default(relu_default, [8448, 2048])
        t_default_5 = torch.ops.aten.t.default(primals_120);  primals_120 = None
        addmm_default_1 = torch.ops.aten.addmm.default(primals_119, view_default_11, t_default_5);  primals_119 = None
        view_default_12 = torch.ops.aten.view.default(addmm_default_1, [256, 33, 512]);  addmm_default_1 = None
        add__tensor_1 = torch.ops.aten.add_.Tensor(view_default_12, getitem_3);  view_default_12 = getitem_3 = None
        native_layer_norm_default_2 = torch.ops.aten.native_layer_norm.default(add__tensor_1, [512], primals_116, primals_115, 1e-06)
        getitem_6 = native_layer_norm_default_2[0]
        getitem_7 = native_layer_norm_default_2[1]
        getitem_8 = native_layer_norm_default_2[2];  native_layer_norm_default_2 = None
        t_default_6 = torch.ops.aten.t.default(primals_137);  primals_137 = None
        view_default_13 = torch.ops.aten.view.default(getitem_6, [8448, 512])
        mm_default_4 = torch.ops.aten.mm.default(view_default_13, t_default_6)
        _unsafe_view_default_9 = torch.ops.aten._unsafe_view.default(mm_default_4, [256, 33, 512]);  mm_default_4 = None
        view_default_14 = torch.ops.aten.view.default(_unsafe_view_default_9, [256, 33, 8, 64]);  _unsafe_view_default_9 = None
        t_default_7 = torch.ops.aten.t.default(primals_136);  primals_136 = None
        view_default_15 = torch.ops.aten.view.default(getitem_6, [8448, 512])
        mm_default_5 = torch.ops.aten.mm.default(view_default_15, t_default_7)
        _unsafe_view_default_10 = torch.ops.aten._unsafe_view.default(mm_default_5, [256, 33, 512]);  mm_default_5 = None
        view_default_16 = torch.ops.aten.view.default(_unsafe_view_default_10, [256, 33, 8, 64]);  _unsafe_view_default_10 = None
        t_default_8 = torch.ops.aten.t.default(primals_138);  primals_138 = None
        view_default_17 = torch.ops.aten.view.default(getitem_6, [8448, 512])
        mm_default_6 = torch.ops.aten.mm.default(view_default_17, t_default_8)
        _unsafe_view_default_11 = torch.ops.aten._unsafe_view.default(mm_default_6, [256, 33, 512]);  mm_default_6 = None
        view_default_18 = torch.ops.aten.view.default(_unsafe_view_default_11, [256, 33, 8, 64]);  _unsafe_view_default_11 = None
        transpose_int_5 = torch.ops.aten.transpose.int(view_default_14, 1, 2);  view_default_14 = None
        transpose_int_6 = torch.ops.aten.transpose.int(view_default_16, 1, 2);  view_default_16 = None
        transpose_int_7 = torch.ops.aten.transpose.int(view_default_18, 1, 2);  view_default_18 = None
        unsqueeze_default_3 = torch.ops.aten.unsqueeze.default(unsqueeze_default, 1)
        div_tensor_1 = torch.ops.aten.div.Tensor(transpose_int_5, 8.0);  transpose_int_5 = None
        transpose_int_8 = torch.ops.aten.transpose.int(transpose_int_6, 2, 3);  transpose_int_6 = None
        expand_default_4 = torch.ops.aten.expand.default(div_tensor_1, [256, 8, 33, 64]);  div_tensor_1 = None
        clone_default_5 = torch.ops.aten.clone.default(expand_default_4, memory_format = torch.contiguous_format);  expand_default_4 = None
        _unsafe_view_default_12 = torch.ops.aten._unsafe_view.default(clone_default_5, [2048, 33, 64]);  clone_default_5 = None
        expand_default_5 = torch.ops.aten.expand.default(transpose_int_8, [256, 8, 64, 33]);  transpose_int_8 = None
        clone_default_6 = torch.ops.aten.clone.default(expand_default_5, memory_format = torch.contiguous_format);  expand_default_5 = None
        _unsafe_view_default_13 = torch.ops.aten._unsafe_view.default(clone_default_6, [2048, 64, 33]);  clone_default_6 = None
        bmm_default_2 = torch.ops.aten.bmm.default(_unsafe_view_default_12, _unsafe_view_default_13)
        _unsafe_view_default_14 = torch.ops.aten._unsafe_view.default(bmm_default_2, [256, 8, 33, 33]);  bmm_default_2 = None
        eq_scalar_1 = torch.ops.aten.eq.Scalar(unsqueeze_default_3, 0);  unsqueeze_default_3 = None
        where_scalar_self_1 = torch.ops.aten.where.ScalarSelf(eq_scalar_1, -1000000000.0, _unsafe_view_default_14);  _unsafe_view_default_14 = None
        _softmax_default_1 = torch.ops.aten._softmax.default(where_scalar_self_1, -1, False);  where_scalar_self_1 = None
        expand_default_6 = torch.ops.aten.expand.default(_softmax_default_1, [256, 8, 33, 33])
        view_default_19 = torch.ops.aten.view.default(expand_default_6, [2048, 33, 33]);  expand_default_6 = None
        expand_default_7 = torch.ops.aten.expand.default(transpose_int_7, [256, 8, 33, 64]);  transpose_int_7 = None
        clone_default_7 = torch.ops.aten.clone.default(expand_default_7, memory_format = torch.contiguous_format);  expand_default_7 = None
        _unsafe_view_default_15 = torch.ops.aten._unsafe_view.default(clone_default_7, [2048, 33, 64]);  clone_default_7 = None
        bmm_default_3 = torch.ops.aten.bmm.default(view_default_19, _unsafe_view_default_15)
        _unsafe_view_default_16 = torch.ops.aten._unsafe_view.default(bmm_default_3, [256, 8, 33, 64]);  bmm_default_3 = None
        transpose_int_9 = torch.ops.aten.transpose.int(_unsafe_view_default_16, 1, 2);  _unsafe_view_default_16 = None
        clone_default_8 = torch.ops.aten.clone.default(transpose_int_9, memory_format = torch.contiguous_format);  transpose_int_9 = None
        view_default_20 = torch.ops.aten.view.default(clone_default_8, [256, 33, -1]);  clone_default_8 = None
        t_default_9 = torch.ops.aten.t.default(primals_133);  primals_133 = None
        view_default_21 = torch.ops.aten.view.default(view_default_20, [8448, 512]);  view_default_20 = None
        mm_default_7 = torch.ops.aten.mm.default(view_default_21, t_default_9)
        _unsafe_view_default_17 = torch.ops.aten._unsafe_view.default(mm_default_7, [256, 33, 512]);  mm_default_7 = None
        add__tensor_2 = torch.ops.aten.add_.Tensor(_unsafe_view_default_17, getitem_6);  _unsafe_view_default_17 = getitem_6 = None
        native_layer_norm_default_3 = torch.ops.aten.native_layer_norm.default(add__tensor_2, [512], primals_135, primals_134, 1e-06)
        getitem_9 = native_layer_norm_default_3[0]
        getitem_10 = native_layer_norm_default_3[1]
        getitem_11 = native_layer_norm_default_3[2];  native_layer_norm_default_3 = None
        view_default_22 = torch.ops.aten.view.default(getitem_9, [8448, 512])
        t_default_10 = torch.ops.aten.t.default(primals_130);  primals_130 = None
        addmm_default_2 = torch.ops.aten.addmm.default(primals_129, view_default_22, t_default_10);  primals_129 = None
        view_default_23 = torch.ops.aten.view.default(addmm_default_2, [256, 33, 2048]);  addmm_default_2 = None
        relu_default_1 = torch.ops.aten.relu.default(view_default_23);  view_default_23 = None
        view_default_24 = torch.ops.aten.view.default(relu_default_1, [8448, 2048])
        t_default_11 = torch.ops.aten.t.default(primals_132);  primals_132 = None
        addmm_default_3 = torch.ops.aten.addmm.default(primals_131, view_default_24, t_default_11);  primals_131 = None
        view_default_25 = torch.ops.aten.view.default(addmm_default_3, [256, 33, 512]);  addmm_default_3 = None
        add__tensor_3 = torch.ops.aten.add_.Tensor(view_default_25, getitem_9);  view_default_25 = getitem_9 = None
        native_layer_norm_default_4 = torch.ops.aten.native_layer_norm.default(add__tensor_3, [512], primals_128, primals_127, 1e-06)
        getitem_12 = native_layer_norm_default_4[0]
        getitem_13 = native_layer_norm_default_4[1]
        getitem_14 = native_layer_norm_default_4[2];  native_layer_norm_default_4 = None
        t_default_12 = torch.ops.aten.t.default(primals_149);  primals_149 = None
        view_default_26 = torch.ops.aten.view.default(getitem_12, [8448, 512])
        mm_default_8 = torch.ops.aten.mm.default(view_default_26, t_default_12)
        _unsafe_view_default_18 = torch.ops.aten._unsafe_view.default(mm_default_8, [256, 33, 512]);  mm_default_8 = None
        view_default_27 = torch.ops.aten.view.default(_unsafe_view_default_18, [256, 33, 8, 64]);  _unsafe_view_default_18 = None
        t_default_13 = torch.ops.aten.t.default(primals_148);  primals_148 = None
        view_default_28 = torch.ops.aten.view.default(getitem_12, [8448, 512])
        mm_default_9 = torch.ops.aten.mm.default(view_default_28, t_default_13)
        _unsafe_view_default_19 = torch.ops.aten._unsafe_view.default(mm_default_9, [256, 33, 512]);  mm_default_9 = None
        view_default_29 = torch.ops.aten.view.default(_unsafe_view_default_19, [256, 33, 8, 64]);  _unsafe_view_default_19 = None
        t_default_14 = torch.ops.aten.t.default(primals_150);  primals_150 = None
        view_default_30 = torch.ops.aten.view.default(getitem_12, [8448, 512])
        mm_default_10 = torch.ops.aten.mm.default(view_default_30, t_default_14)
        _unsafe_view_default_20 = torch.ops.aten._unsafe_view.default(mm_default_10, [256, 33, 512]);  mm_default_10 = None
        view_default_31 = torch.ops.aten.view.default(_unsafe_view_default_20, [256, 33, 8, 64]);  _unsafe_view_default_20 = None
        transpose_int_10 = torch.ops.aten.transpose.int(view_default_27, 1, 2);  view_default_27 = None
        transpose_int_11 = torch.ops.aten.transpose.int(view_default_29, 1, 2);  view_default_29 = None
        transpose_int_12 = torch.ops.aten.transpose.int(view_default_31, 1, 2);  view_default_31 = None
        unsqueeze_default_4 = torch.ops.aten.unsqueeze.default(unsqueeze_default, 1)
        div_tensor_2 = torch.ops.aten.div.Tensor(transpose_int_10, 8.0);  transpose_int_10 = None
        transpose_int_13 = torch.ops.aten.transpose.int(transpose_int_11, 2, 3);  transpose_int_11 = None
        expand_default_8 = torch.ops.aten.expand.default(div_tensor_2, [256, 8, 33, 64]);  div_tensor_2 = None
        clone_default_9 = torch.ops.aten.clone.default(expand_default_8, memory_format = torch.contiguous_format);  expand_default_8 = None
        _unsafe_view_default_21 = torch.ops.aten._unsafe_view.default(clone_default_9, [2048, 33, 64]);  clone_default_9 = None
        expand_default_9 = torch.ops.aten.expand.default(transpose_int_13, [256, 8, 64, 33]);  transpose_int_13 = None
        clone_default_10 = torch.ops.aten.clone.default(expand_default_9, memory_format = torch.contiguous_format);  expand_default_9 = None
        _unsafe_view_default_22 = torch.ops.aten._unsafe_view.default(clone_default_10, [2048, 64, 33]);  clone_default_10 = None
        bmm_default_4 = torch.ops.aten.bmm.default(_unsafe_view_default_21, _unsafe_view_default_22)
        _unsafe_view_default_23 = torch.ops.aten._unsafe_view.default(bmm_default_4, [256, 8, 33, 33]);  bmm_default_4 = None
        eq_scalar_2 = torch.ops.aten.eq.Scalar(unsqueeze_default_4, 0);  unsqueeze_default_4 = None
        where_scalar_self_2 = torch.ops.aten.where.ScalarSelf(eq_scalar_2, -1000000000.0, _unsafe_view_default_23);  _unsafe_view_default_23 = None
        _softmax_default_2 = torch.ops.aten._softmax.default(where_scalar_self_2, -1, False);  where_scalar_self_2 = None
        expand_default_10 = torch.ops.aten.expand.default(_softmax_default_2, [256, 8, 33, 33])
        view_default_32 = torch.ops.aten.view.default(expand_default_10, [2048, 33, 33]);  expand_default_10 = None
        expand_default_11 = torch.ops.aten.expand.default(transpose_int_12, [256, 8, 33, 64]);  transpose_int_12 = None
        clone_default_11 = torch.ops.aten.clone.default(expand_default_11, memory_format = torch.contiguous_format);  expand_default_11 = None
        _unsafe_view_default_24 = torch.ops.aten._unsafe_view.default(clone_default_11, [2048, 33, 64]);  clone_default_11 = None
        bmm_default_5 = torch.ops.aten.bmm.default(view_default_32, _unsafe_view_default_24)
        _unsafe_view_default_25 = torch.ops.aten._unsafe_view.default(bmm_default_5, [256, 8, 33, 64]);  bmm_default_5 = None
        transpose_int_14 = torch.ops.aten.transpose.int(_unsafe_view_default_25, 1, 2);  _unsafe_view_default_25 = None
        clone_default_12 = torch.ops.aten.clone.default(transpose_int_14, memory_format = torch.contiguous_format);  transpose_int_14 = None
        view_default_33 = torch.ops.aten.view.default(clone_default_12, [256, 33, -1]);  clone_default_12 = None
        t_default_15 = torch.ops.aten.t.default(primals_145);  primals_145 = None
        view_default_34 = torch.ops.aten.view.default(view_default_33, [8448, 512]);  view_default_33 = None
        mm_default_11 = torch.ops.aten.mm.default(view_default_34, t_default_15)
        _unsafe_view_default_26 = torch.ops.aten._unsafe_view.default(mm_default_11, [256, 33, 512]);  mm_default_11 = None
        add__tensor_4 = torch.ops.aten.add_.Tensor(_unsafe_view_default_26, getitem_12);  _unsafe_view_default_26 = getitem_12 = None
        native_layer_norm_default_5 = torch.ops.aten.native_layer_norm.default(add__tensor_4, [512], primals_147, primals_146, 1e-06)
        getitem_15 = native_layer_norm_default_5[0]
        getitem_16 = native_layer_norm_default_5[1]
        getitem_17 = native_layer_norm_default_5[2];  native_layer_norm_default_5 = None
        view_default_35 = torch.ops.aten.view.default(getitem_15, [8448, 512])
        t_default_16 = torch.ops.aten.t.default(primals_142);  primals_142 = None
        addmm_default_4 = torch.ops.aten.addmm.default(primals_141, view_default_35, t_default_16);  primals_141 = None
        view_default_36 = torch.ops.aten.view.default(addmm_default_4, [256, 33, 2048]);  addmm_default_4 = None
        relu_default_2 = torch.ops.aten.relu.default(view_default_36);  view_default_36 = None
        view_default_37 = torch.ops.aten.view.default(relu_default_2, [8448, 2048])
        t_default_17 = torch.ops.aten.t.default(primals_144);  primals_144 = None
        addmm_default_5 = torch.ops.aten.addmm.default(primals_143, view_default_37, t_default_17);  primals_143 = None
        view_default_38 = torch.ops.aten.view.default(addmm_default_5, [256, 33, 512]);  addmm_default_5 = None
        add__tensor_5 = torch.ops.aten.add_.Tensor(view_default_38, getitem_15);  view_default_38 = getitem_15 = None
        native_layer_norm_default_6 = torch.ops.aten.native_layer_norm.default(add__tensor_5, [512], primals_140, primals_139, 1e-06)
        getitem_18 = native_layer_norm_default_6[0]
        getitem_19 = native_layer_norm_default_6[1]
        getitem_20 = native_layer_norm_default_6[2];  native_layer_norm_default_6 = None
        t_default_18 = torch.ops.aten.t.default(primals_161);  primals_161 = None
        view_default_39 = torch.ops.aten.view.default(getitem_18, [8448, 512])
        mm_default_12 = torch.ops.aten.mm.default(view_default_39, t_default_18)
        _unsafe_view_default_27 = torch.ops.aten._unsafe_view.default(mm_default_12, [256, 33, 512]);  mm_default_12 = None
        view_default_40 = torch.ops.aten.view.default(_unsafe_view_default_27, [256, 33, 8, 64]);  _unsafe_view_default_27 = None
        t_default_19 = torch.ops.aten.t.default(primals_160);  primals_160 = None
        view_default_41 = torch.ops.aten.view.default(getitem_18, [8448, 512])
        mm_default_13 = torch.ops.aten.mm.default(view_default_41, t_default_19)
        _unsafe_view_default_28 = torch.ops.aten._unsafe_view.default(mm_default_13, [256, 33, 512]);  mm_default_13 = None
        view_default_42 = torch.ops.aten.view.default(_unsafe_view_default_28, [256, 33, 8, 64]);  _unsafe_view_default_28 = None
        t_default_20 = torch.ops.aten.t.default(primals_162);  primals_162 = None
        view_default_43 = torch.ops.aten.view.default(getitem_18, [8448, 512])
        mm_default_14 = torch.ops.aten.mm.default(view_default_43, t_default_20)
        _unsafe_view_default_29 = torch.ops.aten._unsafe_view.default(mm_default_14, [256, 33, 512]);  mm_default_14 = None
        view_default_44 = torch.ops.aten.view.default(_unsafe_view_default_29, [256, 33, 8, 64]);  _unsafe_view_default_29 = None
        transpose_int_15 = torch.ops.aten.transpose.int(view_default_40, 1, 2);  view_default_40 = None
        transpose_int_16 = torch.ops.aten.transpose.int(view_default_42, 1, 2);  view_default_42 = None
        transpose_int_17 = torch.ops.aten.transpose.int(view_default_44, 1, 2);  view_default_44 = None
        unsqueeze_default_5 = torch.ops.aten.unsqueeze.default(unsqueeze_default, 1)
        div_tensor_3 = torch.ops.aten.div.Tensor(transpose_int_15, 8.0);  transpose_int_15 = None
        transpose_int_18 = torch.ops.aten.transpose.int(transpose_int_16, 2, 3);  transpose_int_16 = None
        expand_default_12 = torch.ops.aten.expand.default(div_tensor_3, [256, 8, 33, 64]);  div_tensor_3 = None
        clone_default_13 = torch.ops.aten.clone.default(expand_default_12, memory_format = torch.contiguous_format);  expand_default_12 = None
        _unsafe_view_default_30 = torch.ops.aten._unsafe_view.default(clone_default_13, [2048, 33, 64]);  clone_default_13 = None
        expand_default_13 = torch.ops.aten.expand.default(transpose_int_18, [256, 8, 64, 33]);  transpose_int_18 = None
        clone_default_14 = torch.ops.aten.clone.default(expand_default_13, memory_format = torch.contiguous_format);  expand_default_13 = None
        _unsafe_view_default_31 = torch.ops.aten._unsafe_view.default(clone_default_14, [2048, 64, 33]);  clone_default_14 = None
        bmm_default_6 = torch.ops.aten.bmm.default(_unsafe_view_default_30, _unsafe_view_default_31)
        _unsafe_view_default_32 = torch.ops.aten._unsafe_view.default(bmm_default_6, [256, 8, 33, 33]);  bmm_default_6 = None
        eq_scalar_3 = torch.ops.aten.eq.Scalar(unsqueeze_default_5, 0);  unsqueeze_default_5 = None
        where_scalar_self_3 = torch.ops.aten.where.ScalarSelf(eq_scalar_3, -1000000000.0, _unsafe_view_default_32);  _unsafe_view_default_32 = None
        _softmax_default_3 = torch.ops.aten._softmax.default(where_scalar_self_3, -1, False);  where_scalar_self_3 = None
        expand_default_14 = torch.ops.aten.expand.default(_softmax_default_3, [256, 8, 33, 33])
        view_default_45 = torch.ops.aten.view.default(expand_default_14, [2048, 33, 33]);  expand_default_14 = None
        expand_default_15 = torch.ops.aten.expand.default(transpose_int_17, [256, 8, 33, 64]);  transpose_int_17 = None
        clone_default_15 = torch.ops.aten.clone.default(expand_default_15, memory_format = torch.contiguous_format);  expand_default_15 = None
        _unsafe_view_default_33 = torch.ops.aten._unsafe_view.default(clone_default_15, [2048, 33, 64]);  clone_default_15 = None
        bmm_default_7 = torch.ops.aten.bmm.default(view_default_45, _unsafe_view_default_33)
        _unsafe_view_default_34 = torch.ops.aten._unsafe_view.default(bmm_default_7, [256, 8, 33, 64]);  bmm_default_7 = None
        transpose_int_19 = torch.ops.aten.transpose.int(_unsafe_view_default_34, 1, 2);  _unsafe_view_default_34 = None
        clone_default_16 = torch.ops.aten.clone.default(transpose_int_19, memory_format = torch.contiguous_format);  transpose_int_19 = None
        view_default_46 = torch.ops.aten.view.default(clone_default_16, [256, 33, -1]);  clone_default_16 = None
        t_default_21 = torch.ops.aten.t.default(primals_157);  primals_157 = None
        view_default_47 = torch.ops.aten.view.default(view_default_46, [8448, 512]);  view_default_46 = None
        mm_default_15 = torch.ops.aten.mm.default(view_default_47, t_default_21)
        _unsafe_view_default_35 = torch.ops.aten._unsafe_view.default(mm_default_15, [256, 33, 512]);  mm_default_15 = None
        add__tensor_6 = torch.ops.aten.add_.Tensor(_unsafe_view_default_35, getitem_18);  _unsafe_view_default_35 = getitem_18 = None
        native_layer_norm_default_7 = torch.ops.aten.native_layer_norm.default(add__tensor_6, [512], primals_159, primals_158, 1e-06)
        getitem_21 = native_layer_norm_default_7[0]
        getitem_22 = native_layer_norm_default_7[1]
        getitem_23 = native_layer_norm_default_7[2];  native_layer_norm_default_7 = None
        view_default_48 = torch.ops.aten.view.default(getitem_21, [8448, 512])
        t_default_22 = torch.ops.aten.t.default(primals_154);  primals_154 = None
        addmm_default_6 = torch.ops.aten.addmm.default(primals_153, view_default_48, t_default_22);  primals_153 = None
        view_default_49 = torch.ops.aten.view.default(addmm_default_6, [256, 33, 2048]);  addmm_default_6 = None
        relu_default_3 = torch.ops.aten.relu.default(view_default_49);  view_default_49 = None
        view_default_50 = torch.ops.aten.view.default(relu_default_3, [8448, 2048])
        t_default_23 = torch.ops.aten.t.default(primals_156);  primals_156 = None
        addmm_default_7 = torch.ops.aten.addmm.default(primals_155, view_default_50, t_default_23);  primals_155 = None
        view_default_51 = torch.ops.aten.view.default(addmm_default_7, [256, 33, 512]);  addmm_default_7 = None
        add__tensor_7 = torch.ops.aten.add_.Tensor(view_default_51, getitem_21);  view_default_51 = getitem_21 = None
        native_layer_norm_default_8 = torch.ops.aten.native_layer_norm.default(add__tensor_7, [512], primals_152, primals_151, 1e-06)
        getitem_24 = native_layer_norm_default_8[0]
        getitem_25 = native_layer_norm_default_8[1]
        getitem_26 = native_layer_norm_default_8[2];  native_layer_norm_default_8 = None
        t_default_24 = torch.ops.aten.t.default(primals_173);  primals_173 = None
        view_default_52 = torch.ops.aten.view.default(getitem_24, [8448, 512])
        mm_default_16 = torch.ops.aten.mm.default(view_default_52, t_default_24)
        _unsafe_view_default_36 = torch.ops.aten._unsafe_view.default(mm_default_16, [256, 33, 512]);  mm_default_16 = None
        view_default_53 = torch.ops.aten.view.default(_unsafe_view_default_36, [256, 33, 8, 64]);  _unsafe_view_default_36 = None
        t_default_25 = torch.ops.aten.t.default(primals_172);  primals_172 = None
        view_default_54 = torch.ops.aten.view.default(getitem_24, [8448, 512])
        mm_default_17 = torch.ops.aten.mm.default(view_default_54, t_default_25)
        _unsafe_view_default_37 = torch.ops.aten._unsafe_view.default(mm_default_17, [256, 33, 512]);  mm_default_17 = None
        view_default_55 = torch.ops.aten.view.default(_unsafe_view_default_37, [256, 33, 8, 64]);  _unsafe_view_default_37 = None
        t_default_26 = torch.ops.aten.t.default(primals_174);  primals_174 = None
        view_default_56 = torch.ops.aten.view.default(getitem_24, [8448, 512])
        mm_default_18 = torch.ops.aten.mm.default(view_default_56, t_default_26)
        _unsafe_view_default_38 = torch.ops.aten._unsafe_view.default(mm_default_18, [256, 33, 512]);  mm_default_18 = None
        view_default_57 = torch.ops.aten.view.default(_unsafe_view_default_38, [256, 33, 8, 64]);  _unsafe_view_default_38 = None
        transpose_int_20 = torch.ops.aten.transpose.int(view_default_53, 1, 2);  view_default_53 = None
        transpose_int_21 = torch.ops.aten.transpose.int(view_default_55, 1, 2);  view_default_55 = None
        transpose_int_22 = torch.ops.aten.transpose.int(view_default_57, 1, 2);  view_default_57 = None
        unsqueeze_default_6 = torch.ops.aten.unsqueeze.default(unsqueeze_default, 1)
        div_tensor_4 = torch.ops.aten.div.Tensor(transpose_int_20, 8.0);  transpose_int_20 = None
        transpose_int_23 = torch.ops.aten.transpose.int(transpose_int_21, 2, 3);  transpose_int_21 = None
        expand_default_16 = torch.ops.aten.expand.default(div_tensor_4, [256, 8, 33, 64]);  div_tensor_4 = None
        clone_default_17 = torch.ops.aten.clone.default(expand_default_16, memory_format = torch.contiguous_format);  expand_default_16 = None
        _unsafe_view_default_39 = torch.ops.aten._unsafe_view.default(clone_default_17, [2048, 33, 64]);  clone_default_17 = None
        expand_default_17 = torch.ops.aten.expand.default(transpose_int_23, [256, 8, 64, 33]);  transpose_int_23 = None
        clone_default_18 = torch.ops.aten.clone.default(expand_default_17, memory_format = torch.contiguous_format);  expand_default_17 = None
        _unsafe_view_default_40 = torch.ops.aten._unsafe_view.default(clone_default_18, [2048, 64, 33]);  clone_default_18 = None
        bmm_default_8 = torch.ops.aten.bmm.default(_unsafe_view_default_39, _unsafe_view_default_40)
        _unsafe_view_default_41 = torch.ops.aten._unsafe_view.default(bmm_default_8, [256, 8, 33, 33]);  bmm_default_8 = None
        eq_scalar_4 = torch.ops.aten.eq.Scalar(unsqueeze_default_6, 0);  unsqueeze_default_6 = None
        where_scalar_self_4 = torch.ops.aten.where.ScalarSelf(eq_scalar_4, -1000000000.0, _unsafe_view_default_41);  _unsafe_view_default_41 = None
        _softmax_default_4 = torch.ops.aten._softmax.default(where_scalar_self_4, -1, False);  where_scalar_self_4 = None
        expand_default_18 = torch.ops.aten.expand.default(_softmax_default_4, [256, 8, 33, 33])
        view_default_58 = torch.ops.aten.view.default(expand_default_18, [2048, 33, 33]);  expand_default_18 = None
        expand_default_19 = torch.ops.aten.expand.default(transpose_int_22, [256, 8, 33, 64]);  transpose_int_22 = None
        clone_default_19 = torch.ops.aten.clone.default(expand_default_19, memory_format = torch.contiguous_format);  expand_default_19 = None
        _unsafe_view_default_42 = torch.ops.aten._unsafe_view.default(clone_default_19, [2048, 33, 64]);  clone_default_19 = None
        bmm_default_9 = torch.ops.aten.bmm.default(view_default_58, _unsafe_view_default_42)
        _unsafe_view_default_43 = torch.ops.aten._unsafe_view.default(bmm_default_9, [256, 8, 33, 64]);  bmm_default_9 = None
        transpose_int_24 = torch.ops.aten.transpose.int(_unsafe_view_default_43, 1, 2);  _unsafe_view_default_43 = None
        clone_default_20 = torch.ops.aten.clone.default(transpose_int_24, memory_format = torch.contiguous_format);  transpose_int_24 = None
        view_default_59 = torch.ops.aten.view.default(clone_default_20, [256, 33, -1]);  clone_default_20 = None
        t_default_27 = torch.ops.aten.t.default(primals_169);  primals_169 = None
        view_default_60 = torch.ops.aten.view.default(view_default_59, [8448, 512]);  view_default_59 = None
        mm_default_19 = torch.ops.aten.mm.default(view_default_60, t_default_27)
        _unsafe_view_default_44 = torch.ops.aten._unsafe_view.default(mm_default_19, [256, 33, 512]);  mm_default_19 = None
        add__tensor_8 = torch.ops.aten.add_.Tensor(_unsafe_view_default_44, getitem_24);  _unsafe_view_default_44 = getitem_24 = None
        native_layer_norm_default_9 = torch.ops.aten.native_layer_norm.default(add__tensor_8, [512], primals_171, primals_170, 1e-06)
        getitem_27 = native_layer_norm_default_9[0]
        getitem_28 = native_layer_norm_default_9[1]
        getitem_29 = native_layer_norm_default_9[2];  native_layer_norm_default_9 = None
        view_default_61 = torch.ops.aten.view.default(getitem_27, [8448, 512])
        t_default_28 = torch.ops.aten.t.default(primals_166);  primals_166 = None
        addmm_default_8 = torch.ops.aten.addmm.default(primals_165, view_default_61, t_default_28);  primals_165 = None
        view_default_62 = torch.ops.aten.view.default(addmm_default_8, [256, 33, 2048]);  addmm_default_8 = None
        relu_default_4 = torch.ops.aten.relu.default(view_default_62);  view_default_62 = None
        view_default_63 = torch.ops.aten.view.default(relu_default_4, [8448, 2048])
        t_default_29 = torch.ops.aten.t.default(primals_168);  primals_168 = None
        addmm_default_9 = torch.ops.aten.addmm.default(primals_167, view_default_63, t_default_29);  primals_167 = None
        view_default_64 = torch.ops.aten.view.default(addmm_default_9, [256, 33, 512]);  addmm_default_9 = None
        add__tensor_9 = torch.ops.aten.add_.Tensor(view_default_64, getitem_27);  view_default_64 = getitem_27 = None
        native_layer_norm_default_10 = torch.ops.aten.native_layer_norm.default(add__tensor_9, [512], primals_164, primals_163, 1e-06)
        getitem_30 = native_layer_norm_default_10[0]
        getitem_31 = native_layer_norm_default_10[1]
        getitem_32 = native_layer_norm_default_10[2];  native_layer_norm_default_10 = None
        t_default_30 = torch.ops.aten.t.default(primals_185);  primals_185 = None
        view_default_65 = torch.ops.aten.view.default(getitem_30, [8448, 512])
        mm_default_20 = torch.ops.aten.mm.default(view_default_65, t_default_30)
        _unsafe_view_default_45 = torch.ops.aten._unsafe_view.default(mm_default_20, [256, 33, 512]);  mm_default_20 = None
        view_default_66 = torch.ops.aten.view.default(_unsafe_view_default_45, [256, 33, 8, 64]);  _unsafe_view_default_45 = None
        t_default_31 = torch.ops.aten.t.default(primals_184);  primals_184 = None
        view_default_67 = torch.ops.aten.view.default(getitem_30, [8448, 512])
        mm_default_21 = torch.ops.aten.mm.default(view_default_67, t_default_31)
        _unsafe_view_default_46 = torch.ops.aten._unsafe_view.default(mm_default_21, [256, 33, 512]);  mm_default_21 = None
        view_default_68 = torch.ops.aten.view.default(_unsafe_view_default_46, [256, 33, 8, 64]);  _unsafe_view_default_46 = None
        t_default_32 = torch.ops.aten.t.default(primals_186);  primals_186 = None
        view_default_69 = torch.ops.aten.view.default(getitem_30, [8448, 512])
        mm_default_22 = torch.ops.aten.mm.default(view_default_69, t_default_32)
        _unsafe_view_default_47 = torch.ops.aten._unsafe_view.default(mm_default_22, [256, 33, 512]);  mm_default_22 = None
        view_default_70 = torch.ops.aten.view.default(_unsafe_view_default_47, [256, 33, 8, 64]);  _unsafe_view_default_47 = None
        transpose_int_25 = torch.ops.aten.transpose.int(view_default_66, 1, 2);  view_default_66 = None
        transpose_int_26 = torch.ops.aten.transpose.int(view_default_68, 1, 2);  view_default_68 = None
        transpose_int_27 = torch.ops.aten.transpose.int(view_default_70, 1, 2);  view_default_70 = None
        unsqueeze_default_7 = torch.ops.aten.unsqueeze.default(unsqueeze_default, 1)
        div_tensor_5 = torch.ops.aten.div.Tensor(transpose_int_25, 8.0);  transpose_int_25 = None
        transpose_int_28 = torch.ops.aten.transpose.int(transpose_int_26, 2, 3);  transpose_int_26 = None
        expand_default_20 = torch.ops.aten.expand.default(div_tensor_5, [256, 8, 33, 64]);  div_tensor_5 = None
        clone_default_21 = torch.ops.aten.clone.default(expand_default_20, memory_format = torch.contiguous_format);  expand_default_20 = None
        _unsafe_view_default_48 = torch.ops.aten._unsafe_view.default(clone_default_21, [2048, 33, 64]);  clone_default_21 = None
        expand_default_21 = torch.ops.aten.expand.default(transpose_int_28, [256, 8, 64, 33]);  transpose_int_28 = None
        clone_default_22 = torch.ops.aten.clone.default(expand_default_21, memory_format = torch.contiguous_format);  expand_default_21 = None
        _unsafe_view_default_49 = torch.ops.aten._unsafe_view.default(clone_default_22, [2048, 64, 33]);  clone_default_22 = None
        bmm_default_10 = torch.ops.aten.bmm.default(_unsafe_view_default_48, _unsafe_view_default_49)
        _unsafe_view_default_50 = torch.ops.aten._unsafe_view.default(bmm_default_10, [256, 8, 33, 33]);  bmm_default_10 = None
        eq_scalar_5 = torch.ops.aten.eq.Scalar(unsqueeze_default_7, 0);  unsqueeze_default_7 = None
        where_scalar_self_5 = torch.ops.aten.where.ScalarSelf(eq_scalar_5, -1000000000.0, _unsafe_view_default_50);  _unsafe_view_default_50 = None
        _softmax_default_5 = torch.ops.aten._softmax.default(where_scalar_self_5, -1, False);  where_scalar_self_5 = None
        expand_default_22 = torch.ops.aten.expand.default(_softmax_default_5, [256, 8, 33, 33])
        view_default_71 = torch.ops.aten.view.default(expand_default_22, [2048, 33, 33]);  expand_default_22 = None
        expand_default_23 = torch.ops.aten.expand.default(transpose_int_27, [256, 8, 33, 64]);  transpose_int_27 = None
        clone_default_23 = torch.ops.aten.clone.default(expand_default_23, memory_format = torch.contiguous_format);  expand_default_23 = None
        _unsafe_view_default_51 = torch.ops.aten._unsafe_view.default(clone_default_23, [2048, 33, 64]);  clone_default_23 = None
        bmm_default_11 = torch.ops.aten.bmm.default(view_default_71, _unsafe_view_default_51)
        _unsafe_view_default_52 = torch.ops.aten._unsafe_view.default(bmm_default_11, [256, 8, 33, 64]);  bmm_default_11 = None
        transpose_int_29 = torch.ops.aten.transpose.int(_unsafe_view_default_52, 1, 2);  _unsafe_view_default_52 = None
        clone_default_24 = torch.ops.aten.clone.default(transpose_int_29, memory_format = torch.contiguous_format);  transpose_int_29 = None
        view_default_72 = torch.ops.aten.view.default(clone_default_24, [256, 33, -1]);  clone_default_24 = None
        t_default_33 = torch.ops.aten.t.default(primals_181);  primals_181 = None
        view_default_73 = torch.ops.aten.view.default(view_default_72, [8448, 512]);  view_default_72 = None
        mm_default_23 = torch.ops.aten.mm.default(view_default_73, t_default_33)
        _unsafe_view_default_53 = torch.ops.aten._unsafe_view.default(mm_default_23, [256, 33, 512]);  mm_default_23 = None
        add__tensor_10 = torch.ops.aten.add_.Tensor(_unsafe_view_default_53, getitem_30);  _unsafe_view_default_53 = getitem_30 = None
        native_layer_norm_default_11 = torch.ops.aten.native_layer_norm.default(add__tensor_10, [512], primals_183, primals_182, 1e-06)
        getitem_33 = native_layer_norm_default_11[0]
        getitem_34 = native_layer_norm_default_11[1]
        getitem_35 = native_layer_norm_default_11[2];  native_layer_norm_default_11 = None
        view_default_74 = torch.ops.aten.view.default(getitem_33, [8448, 512])
        t_default_34 = torch.ops.aten.t.default(primals_178);  primals_178 = None
        addmm_default_10 = torch.ops.aten.addmm.default(primals_177, view_default_74, t_default_34);  primals_177 = None
        view_default_75 = torch.ops.aten.view.default(addmm_default_10, [256, 33, 2048]);  addmm_default_10 = None
        relu_default_5 = torch.ops.aten.relu.default(view_default_75);  view_default_75 = None
        view_default_76 = torch.ops.aten.view.default(relu_default_5, [8448, 2048])
        t_default_35 = torch.ops.aten.t.default(primals_180);  primals_180 = None
        addmm_default_11 = torch.ops.aten.addmm.default(primals_179, view_default_76, t_default_35);  primals_179 = None
        view_default_77 = torch.ops.aten.view.default(addmm_default_11, [256, 33, 512]);  addmm_default_11 = None
        add__tensor_11 = torch.ops.aten.add_.Tensor(view_default_77, getitem_33);  view_default_77 = getitem_33 = None
        native_layer_norm_default_12 = torch.ops.aten.native_layer_norm.default(add__tensor_11, [512], primals_176, primals_175, 1e-06)
        getitem_36 = native_layer_norm_default_12[0]
        getitem_37 = native_layer_norm_default_12[1]
        getitem_38 = native_layer_norm_default_12[2];  native_layer_norm_default_12 = None
        embedding_default_1 = torch.ops.aten.embedding.default(primals_112, primals_191, 1);  primals_112 = None
        slice_tensor_2 = torch.ops.aten.slice.Tensor(primals_111, 0, 0, 9223372036854775807);  primals_111 = None
        slice_tensor_3 = torch.ops.aten.slice.Tensor(slice_tensor_2, 1, 0, 31);  slice_tensor_2 = None
        clone_default_25 = torch.ops.aten.clone.default(slice_tensor_3);  slice_tensor_3 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(embedding_default_1, clone_default_25);  embedding_default_1 = clone_default_25 = None
        native_layer_norm_default_13 = torch.ops.aten.native_layer_norm.default(add_tensor_1, [512], primals_2, primals_1, 1e-06)
        getitem_39 = native_layer_norm_default_13[0]
        getitem_40 = native_layer_norm_default_13[1]
        getitem_41 = native_layer_norm_default_13[2];  native_layer_norm_default_13 = None
        t_default_36 = torch.ops.aten.t.default(primals_19);  primals_19 = None
        view_default_78 = torch.ops.aten.view.default(getitem_39, [7936, 512])
        mm_default_24 = torch.ops.aten.mm.default(view_default_78, t_default_36)
        _unsafe_view_default_54 = torch.ops.aten._unsafe_view.default(mm_default_24, [256, 31, 512]);  mm_default_24 = None
        view_default_79 = torch.ops.aten.view.default(_unsafe_view_default_54, [256, 31, 8, 64]);  _unsafe_view_default_54 = None
        t_default_37 = torch.ops.aten.t.default(primals_18);  primals_18 = None
        view_default_80 = torch.ops.aten.view.default(getitem_39, [7936, 512])
        mm_default_25 = torch.ops.aten.mm.default(view_default_80, t_default_37)
        _unsafe_view_default_55 = torch.ops.aten._unsafe_view.default(mm_default_25, [256, 31, 512]);  mm_default_25 = None
        view_default_81 = torch.ops.aten.view.default(_unsafe_view_default_55, [256, 31, 8, 64]);  _unsafe_view_default_55 = None
        t_default_38 = torch.ops.aten.t.default(primals_20);  primals_20 = None
        view_default_82 = torch.ops.aten.view.default(getitem_39, [7936, 512])
        mm_default_26 = torch.ops.aten.mm.default(view_default_82, t_default_38)
        _unsafe_view_default_56 = torch.ops.aten._unsafe_view.default(mm_default_26, [256, 31, 512]);  mm_default_26 = None
        view_default_83 = torch.ops.aten.view.default(_unsafe_view_default_56, [256, 31, 8, 64]);  _unsafe_view_default_56 = None
        transpose_int_30 = torch.ops.aten.transpose.int(view_default_79, 1, 2);  view_default_79 = None
        transpose_int_31 = torch.ops.aten.transpose.int(view_default_81, 1, 2);  view_default_81 = None
        transpose_int_32 = torch.ops.aten.transpose.int(view_default_83, 1, 2);  view_default_83 = None
        unsqueeze_default_8 = torch.ops.aten.unsqueeze.default(bitwise_and_tensor, 1)
        div_tensor_6 = torch.ops.aten.div.Tensor(transpose_int_30, 8.0);  transpose_int_30 = None
        transpose_int_33 = torch.ops.aten.transpose.int(transpose_int_31, 2, 3);  transpose_int_31 = None
        expand_default_24 = torch.ops.aten.expand.default(div_tensor_6, [256, 8, 31, 64]);  div_tensor_6 = None
        clone_default_26 = torch.ops.aten.clone.default(expand_default_24, memory_format = torch.contiguous_format);  expand_default_24 = None
        _unsafe_view_default_57 = torch.ops.aten._unsafe_view.default(clone_default_26, [2048, 31, 64]);  clone_default_26 = None
        expand_default_25 = torch.ops.aten.expand.default(transpose_int_33, [256, 8, 64, 31]);  transpose_int_33 = None
        clone_default_27 = torch.ops.aten.clone.default(expand_default_25, memory_format = torch.contiguous_format);  expand_default_25 = None
        _unsafe_view_default_58 = torch.ops.aten._unsafe_view.default(clone_default_27, [2048, 64, 31]);  clone_default_27 = None
        bmm_default_12 = torch.ops.aten.bmm.default(_unsafe_view_default_57, _unsafe_view_default_58)
        _unsafe_view_default_59 = torch.ops.aten._unsafe_view.default(bmm_default_12, [256, 8, 31, 31]);  bmm_default_12 = None
        eq_scalar_6 = torch.ops.aten.eq.Scalar(unsqueeze_default_8, 0);  unsqueeze_default_8 = None
        where_scalar_self_6 = torch.ops.aten.where.ScalarSelf(eq_scalar_6, -1000000000.0, _unsafe_view_default_59);  _unsafe_view_default_59 = None
        _softmax_default_6 = torch.ops.aten._softmax.default(where_scalar_self_6, -1, False);  where_scalar_self_6 = None
        expand_default_26 = torch.ops.aten.expand.default(_softmax_default_6, [256, 8, 31, 31])
        view_default_84 = torch.ops.aten.view.default(expand_default_26, [2048, 31, 31]);  expand_default_26 = None
        expand_default_27 = torch.ops.aten.expand.default(transpose_int_32, [256, 8, 31, 64]);  transpose_int_32 = None
        clone_default_28 = torch.ops.aten.clone.default(expand_default_27, memory_format = torch.contiguous_format);  expand_default_27 = None
        _unsafe_view_default_60 = torch.ops.aten._unsafe_view.default(clone_default_28, [2048, 31, 64]);  clone_default_28 = None
        bmm_default_13 = torch.ops.aten.bmm.default(view_default_84, _unsafe_view_default_60)
        _unsafe_view_default_61 = torch.ops.aten._unsafe_view.default(bmm_default_13, [256, 8, 31, 64]);  bmm_default_13 = None
        transpose_int_34 = torch.ops.aten.transpose.int(_unsafe_view_default_61, 1, 2);  _unsafe_view_default_61 = None
        clone_default_29 = torch.ops.aten.clone.default(transpose_int_34, memory_format = torch.contiguous_format);  transpose_int_34 = None
        view_default_85 = torch.ops.aten.view.default(clone_default_29, [256, 31, -1]);  clone_default_29 = None
        t_default_39 = torch.ops.aten.t.default(primals_15);  primals_15 = None
        view_default_86 = torch.ops.aten.view.default(view_default_85, [7936, 512]);  view_default_85 = None
        mm_default_27 = torch.ops.aten.mm.default(view_default_86, t_default_39)
        _unsafe_view_default_62 = torch.ops.aten._unsafe_view.default(mm_default_27, [256, 31, 512]);  mm_default_27 = None
        add__tensor_12 = torch.ops.aten.add_.Tensor(_unsafe_view_default_62, getitem_39);  _unsafe_view_default_62 = getitem_39 = None
        native_layer_norm_default_14 = torch.ops.aten.native_layer_norm.default(add__tensor_12, [512], primals_17, primals_16, 1e-06)
        getitem_42 = native_layer_norm_default_14[0]
        getitem_43 = native_layer_norm_default_14[1]
        getitem_44 = native_layer_norm_default_14[2];  native_layer_norm_default_14 = None
        t_default_40 = torch.ops.aten.t.default(primals_7);  primals_7 = None
        view_default_87 = torch.ops.aten.view.default(getitem_42, [7936, 512])
        mm_default_28 = torch.ops.aten.mm.default(view_default_87, t_default_40)
        _unsafe_view_default_63 = torch.ops.aten._unsafe_view.default(mm_default_28, [256, 31, 512]);  mm_default_28 = None
        view_default_88 = torch.ops.aten.view.default(_unsafe_view_default_63, [256, 31, 8, 64]);  _unsafe_view_default_63 = None
        t_default_41 = torch.ops.aten.t.default(primals_6);  primals_6 = None
        view_default_89 = torch.ops.aten.view.default(getitem_36, [8448, 512])
        mm_default_29 = torch.ops.aten.mm.default(view_default_89, t_default_41)
        _unsafe_view_default_64 = torch.ops.aten._unsafe_view.default(mm_default_29, [256, 33, 512]);  mm_default_29 = None
        view_default_90 = torch.ops.aten.view.default(_unsafe_view_default_64, [256, 33, 8, 64]);  _unsafe_view_default_64 = None
        t_default_42 = torch.ops.aten.t.default(primals_8);  primals_8 = None
        view_default_91 = torch.ops.aten.view.default(getitem_36, [8448, 512])
        mm_default_30 = torch.ops.aten.mm.default(view_default_91, t_default_42)
        _unsafe_view_default_65 = torch.ops.aten._unsafe_view.default(mm_default_30, [256, 33, 512]);  mm_default_30 = None
        view_default_92 = torch.ops.aten.view.default(_unsafe_view_default_65, [256, 33, 8, 64]);  _unsafe_view_default_65 = None
        transpose_int_35 = torch.ops.aten.transpose.int(view_default_88, 1, 2);  view_default_88 = None
        transpose_int_36 = torch.ops.aten.transpose.int(view_default_90, 1, 2);  view_default_90 = None
        transpose_int_37 = torch.ops.aten.transpose.int(view_default_92, 1, 2);  view_default_92 = None
        unsqueeze_default_9 = torch.ops.aten.unsqueeze.default(unsqueeze_default, 1)
        div_tensor_7 = torch.ops.aten.div.Tensor(transpose_int_35, 8.0);  transpose_int_35 = None
        transpose_int_38 = torch.ops.aten.transpose.int(transpose_int_36, 2, 3);  transpose_int_36 = None
        expand_default_28 = torch.ops.aten.expand.default(div_tensor_7, [256, 8, 31, 64]);  div_tensor_7 = None
        clone_default_30 = torch.ops.aten.clone.default(expand_default_28, memory_format = torch.contiguous_format);  expand_default_28 = None
        _unsafe_view_default_66 = torch.ops.aten._unsafe_view.default(clone_default_30, [2048, 31, 64]);  clone_default_30 = None
        expand_default_29 = torch.ops.aten.expand.default(transpose_int_38, [256, 8, 64, 33]);  transpose_int_38 = None
        clone_default_31 = torch.ops.aten.clone.default(expand_default_29, memory_format = torch.contiguous_format);  expand_default_29 = None
        _unsafe_view_default_67 = torch.ops.aten._unsafe_view.default(clone_default_31, [2048, 64, 33]);  clone_default_31 = None
        bmm_default_14 = torch.ops.aten.bmm.default(_unsafe_view_default_66, _unsafe_view_default_67)
        _unsafe_view_default_68 = torch.ops.aten._unsafe_view.default(bmm_default_14, [256, 8, 31, 33]);  bmm_default_14 = None
        eq_scalar_7 = torch.ops.aten.eq.Scalar(unsqueeze_default_9, 0);  unsqueeze_default_9 = None
        where_scalar_self_7 = torch.ops.aten.where.ScalarSelf(eq_scalar_7, -1000000000.0, _unsafe_view_default_68);  _unsafe_view_default_68 = None
        _softmax_default_7 = torch.ops.aten._softmax.default(where_scalar_self_7, -1, False);  where_scalar_self_7 = None
        expand_default_30 = torch.ops.aten.expand.default(_softmax_default_7, [256, 8, 31, 33])
        view_default_93 = torch.ops.aten.view.default(expand_default_30, [2048, 31, 33]);  expand_default_30 = None
        expand_default_31 = torch.ops.aten.expand.default(transpose_int_37, [256, 8, 33, 64]);  transpose_int_37 = None
        clone_default_32 = torch.ops.aten.clone.default(expand_default_31, memory_format = torch.contiguous_format);  expand_default_31 = None
        _unsafe_view_default_69 = torch.ops.aten._unsafe_view.default(clone_default_32, [2048, 33, 64]);  clone_default_32 = None
        bmm_default_15 = torch.ops.aten.bmm.default(view_default_93, _unsafe_view_default_69)
        _unsafe_view_default_70 = torch.ops.aten._unsafe_view.default(bmm_default_15, [256, 8, 31, 64]);  bmm_default_15 = None
        transpose_int_39 = torch.ops.aten.transpose.int(_unsafe_view_default_70, 1, 2);  _unsafe_view_default_70 = None
        clone_default_33 = torch.ops.aten.clone.default(transpose_int_39, memory_format = torch.contiguous_format);  transpose_int_39 = None
        view_default_94 = torch.ops.aten.view.default(clone_default_33, [256, 31, -1]);  clone_default_33 = None
        t_default_43 = torch.ops.aten.t.default(primals_3);  primals_3 = None
        view_default_95 = torch.ops.aten.view.default(view_default_94, [7936, 512]);  view_default_94 = None
        mm_default_31 = torch.ops.aten.mm.default(view_default_95, t_default_43)
        _unsafe_view_default_71 = torch.ops.aten._unsafe_view.default(mm_default_31, [256, 31, 512]);  mm_default_31 = None
        add__tensor_13 = torch.ops.aten.add_.Tensor(_unsafe_view_default_71, getitem_42);  _unsafe_view_default_71 = getitem_42 = None
        native_layer_norm_default_15 = torch.ops.aten.native_layer_norm.default(add__tensor_13, [512], primals_5, primals_4, 1e-06)
        getitem_45 = native_layer_norm_default_15[0]
        getitem_46 = native_layer_norm_default_15[1]
        getitem_47 = native_layer_norm_default_15[2];  native_layer_norm_default_15 = None
        view_default_96 = torch.ops.aten.view.default(getitem_45, [7936, 512])
        t_default_44 = torch.ops.aten.t.default(primals_12);  primals_12 = None
        addmm_default_12 = torch.ops.aten.addmm.default(primals_11, view_default_96, t_default_44);  primals_11 = None
        view_default_97 = torch.ops.aten.view.default(addmm_default_12, [256, 31, 2048]);  addmm_default_12 = None
        relu_default_6 = torch.ops.aten.relu.default(view_default_97);  view_default_97 = None
        view_default_98 = torch.ops.aten.view.default(relu_default_6, [7936, 2048])
        t_default_45 = torch.ops.aten.t.default(primals_14);  primals_14 = None
        addmm_default_13 = torch.ops.aten.addmm.default(primals_13, view_default_98, t_default_45);  primals_13 = None
        view_default_99 = torch.ops.aten.view.default(addmm_default_13, [256, 31, 512]);  addmm_default_13 = None
        add__tensor_14 = torch.ops.aten.add_.Tensor(view_default_99, getitem_45);  view_default_99 = getitem_45 = None
        native_layer_norm_default_16 = torch.ops.aten.native_layer_norm.default(add__tensor_14, [512], primals_10, primals_9, 1e-06)
        getitem_48 = native_layer_norm_default_16[0]
        getitem_49 = native_layer_norm_default_16[1]
        getitem_50 = native_layer_norm_default_16[2];  native_layer_norm_default_16 = None
        t_default_46 = torch.ops.aten.t.default(primals_37);  primals_37 = None
        view_default_100 = torch.ops.aten.view.default(getitem_48, [7936, 512])
        mm_default_32 = torch.ops.aten.mm.default(view_default_100, t_default_46)
        _unsafe_view_default_72 = torch.ops.aten._unsafe_view.default(mm_default_32, [256, 31, 512]);  mm_default_32 = None
        view_default_101 = torch.ops.aten.view.default(_unsafe_view_default_72, [256, 31, 8, 64]);  _unsafe_view_default_72 = None
        t_default_47 = torch.ops.aten.t.default(primals_36);  primals_36 = None
        view_default_102 = torch.ops.aten.view.default(getitem_48, [7936, 512])
        mm_default_33 = torch.ops.aten.mm.default(view_default_102, t_default_47)
        _unsafe_view_default_73 = torch.ops.aten._unsafe_view.default(mm_default_33, [256, 31, 512]);  mm_default_33 = None
        view_default_103 = torch.ops.aten.view.default(_unsafe_view_default_73, [256, 31, 8, 64]);  _unsafe_view_default_73 = None
        t_default_48 = torch.ops.aten.t.default(primals_38);  primals_38 = None
        view_default_104 = torch.ops.aten.view.default(getitem_48, [7936, 512])
        mm_default_34 = torch.ops.aten.mm.default(view_default_104, t_default_48)
        _unsafe_view_default_74 = torch.ops.aten._unsafe_view.default(mm_default_34, [256, 31, 512]);  mm_default_34 = None
        view_default_105 = torch.ops.aten.view.default(_unsafe_view_default_74, [256, 31, 8, 64]);  _unsafe_view_default_74 = None
        transpose_int_40 = torch.ops.aten.transpose.int(view_default_101, 1, 2);  view_default_101 = None
        transpose_int_41 = torch.ops.aten.transpose.int(view_default_103, 1, 2);  view_default_103 = None
        transpose_int_42 = torch.ops.aten.transpose.int(view_default_105, 1, 2);  view_default_105 = None
        unsqueeze_default_10 = torch.ops.aten.unsqueeze.default(bitwise_and_tensor, 1)
        div_tensor_8 = torch.ops.aten.div.Tensor(transpose_int_40, 8.0);  transpose_int_40 = None
        transpose_int_43 = torch.ops.aten.transpose.int(transpose_int_41, 2, 3);  transpose_int_41 = None
        expand_default_32 = torch.ops.aten.expand.default(div_tensor_8, [256, 8, 31, 64]);  div_tensor_8 = None
        clone_default_34 = torch.ops.aten.clone.default(expand_default_32, memory_format = torch.contiguous_format);  expand_default_32 = None
        _unsafe_view_default_75 = torch.ops.aten._unsafe_view.default(clone_default_34, [2048, 31, 64]);  clone_default_34 = None
        expand_default_33 = torch.ops.aten.expand.default(transpose_int_43, [256, 8, 64, 31]);  transpose_int_43 = None
        clone_default_35 = torch.ops.aten.clone.default(expand_default_33, memory_format = torch.contiguous_format);  expand_default_33 = None
        _unsafe_view_default_76 = torch.ops.aten._unsafe_view.default(clone_default_35, [2048, 64, 31]);  clone_default_35 = None
        bmm_default_16 = torch.ops.aten.bmm.default(_unsafe_view_default_75, _unsafe_view_default_76)
        _unsafe_view_default_77 = torch.ops.aten._unsafe_view.default(bmm_default_16, [256, 8, 31, 31]);  bmm_default_16 = None
        eq_scalar_8 = torch.ops.aten.eq.Scalar(unsqueeze_default_10, 0);  unsqueeze_default_10 = None
        where_scalar_self_8 = torch.ops.aten.where.ScalarSelf(eq_scalar_8, -1000000000.0, _unsafe_view_default_77);  _unsafe_view_default_77 = None
        _softmax_default_8 = torch.ops.aten._softmax.default(where_scalar_self_8, -1, False);  where_scalar_self_8 = None
        expand_default_34 = torch.ops.aten.expand.default(_softmax_default_8, [256, 8, 31, 31])
        view_default_106 = torch.ops.aten.view.default(expand_default_34, [2048, 31, 31]);  expand_default_34 = None
        expand_default_35 = torch.ops.aten.expand.default(transpose_int_42, [256, 8, 31, 64]);  transpose_int_42 = None
        clone_default_36 = torch.ops.aten.clone.default(expand_default_35, memory_format = torch.contiguous_format);  expand_default_35 = None
        _unsafe_view_default_78 = torch.ops.aten._unsafe_view.default(clone_default_36, [2048, 31, 64]);  clone_default_36 = None
        bmm_default_17 = torch.ops.aten.bmm.default(view_default_106, _unsafe_view_default_78)
        _unsafe_view_default_79 = torch.ops.aten._unsafe_view.default(bmm_default_17, [256, 8, 31, 64]);  bmm_default_17 = None
        transpose_int_44 = torch.ops.aten.transpose.int(_unsafe_view_default_79, 1, 2);  _unsafe_view_default_79 = None
        clone_default_37 = torch.ops.aten.clone.default(transpose_int_44, memory_format = torch.contiguous_format);  transpose_int_44 = None
        view_default_107 = torch.ops.aten.view.default(clone_default_37, [256, 31, -1]);  clone_default_37 = None
        t_default_49 = torch.ops.aten.t.default(primals_33);  primals_33 = None
        view_default_108 = torch.ops.aten.view.default(view_default_107, [7936, 512]);  view_default_107 = None
        mm_default_35 = torch.ops.aten.mm.default(view_default_108, t_default_49)
        _unsafe_view_default_80 = torch.ops.aten._unsafe_view.default(mm_default_35, [256, 31, 512]);  mm_default_35 = None
        add__tensor_15 = torch.ops.aten.add_.Tensor(_unsafe_view_default_80, getitem_48);  _unsafe_view_default_80 = getitem_48 = None
        native_layer_norm_default_17 = torch.ops.aten.native_layer_norm.default(add__tensor_15, [512], primals_35, primals_34, 1e-06)
        getitem_51 = native_layer_norm_default_17[0]
        getitem_52 = native_layer_norm_default_17[1]
        getitem_53 = native_layer_norm_default_17[2];  native_layer_norm_default_17 = None
        t_default_50 = torch.ops.aten.t.default(primals_25);  primals_25 = None
        view_default_109 = torch.ops.aten.view.default(getitem_51, [7936, 512])
        mm_default_36 = torch.ops.aten.mm.default(view_default_109, t_default_50)
        _unsafe_view_default_81 = torch.ops.aten._unsafe_view.default(mm_default_36, [256, 31, 512]);  mm_default_36 = None
        view_default_110 = torch.ops.aten.view.default(_unsafe_view_default_81, [256, 31, 8, 64]);  _unsafe_view_default_81 = None
        t_default_51 = torch.ops.aten.t.default(primals_24);  primals_24 = None
        view_default_111 = torch.ops.aten.view.default(getitem_36, [8448, 512])
        mm_default_37 = torch.ops.aten.mm.default(view_default_111, t_default_51)
        _unsafe_view_default_82 = torch.ops.aten._unsafe_view.default(mm_default_37, [256, 33, 512]);  mm_default_37 = None
        view_default_112 = torch.ops.aten.view.default(_unsafe_view_default_82, [256, 33, 8, 64]);  _unsafe_view_default_82 = None
        t_default_52 = torch.ops.aten.t.default(primals_26);  primals_26 = None
        view_default_113 = torch.ops.aten.view.default(getitem_36, [8448, 512])
        mm_default_38 = torch.ops.aten.mm.default(view_default_113, t_default_52)
        _unsafe_view_default_83 = torch.ops.aten._unsafe_view.default(mm_default_38, [256, 33, 512]);  mm_default_38 = None
        view_default_114 = torch.ops.aten.view.default(_unsafe_view_default_83, [256, 33, 8, 64]);  _unsafe_view_default_83 = None
        transpose_int_45 = torch.ops.aten.transpose.int(view_default_110, 1, 2);  view_default_110 = None
        transpose_int_46 = torch.ops.aten.transpose.int(view_default_112, 1, 2);  view_default_112 = None
        transpose_int_47 = torch.ops.aten.transpose.int(view_default_114, 1, 2);  view_default_114 = None
        unsqueeze_default_11 = torch.ops.aten.unsqueeze.default(unsqueeze_default, 1)
        div_tensor_9 = torch.ops.aten.div.Tensor(transpose_int_45, 8.0);  transpose_int_45 = None
        transpose_int_48 = torch.ops.aten.transpose.int(transpose_int_46, 2, 3);  transpose_int_46 = None
        expand_default_36 = torch.ops.aten.expand.default(div_tensor_9, [256, 8, 31, 64]);  div_tensor_9 = None
        clone_default_38 = torch.ops.aten.clone.default(expand_default_36, memory_format = torch.contiguous_format);  expand_default_36 = None
        _unsafe_view_default_84 = torch.ops.aten._unsafe_view.default(clone_default_38, [2048, 31, 64]);  clone_default_38 = None
        expand_default_37 = torch.ops.aten.expand.default(transpose_int_48, [256, 8, 64, 33]);  transpose_int_48 = None
        clone_default_39 = torch.ops.aten.clone.default(expand_default_37, memory_format = torch.contiguous_format);  expand_default_37 = None
        _unsafe_view_default_85 = torch.ops.aten._unsafe_view.default(clone_default_39, [2048, 64, 33]);  clone_default_39 = None
        bmm_default_18 = torch.ops.aten.bmm.default(_unsafe_view_default_84, _unsafe_view_default_85)
        _unsafe_view_default_86 = torch.ops.aten._unsafe_view.default(bmm_default_18, [256, 8, 31, 33]);  bmm_default_18 = None
        eq_scalar_9 = torch.ops.aten.eq.Scalar(unsqueeze_default_11, 0);  unsqueeze_default_11 = None
        where_scalar_self_9 = torch.ops.aten.where.ScalarSelf(eq_scalar_9, -1000000000.0, _unsafe_view_default_86);  _unsafe_view_default_86 = None
        _softmax_default_9 = torch.ops.aten._softmax.default(where_scalar_self_9, -1, False);  where_scalar_self_9 = None
        expand_default_38 = torch.ops.aten.expand.default(_softmax_default_9, [256, 8, 31, 33])
        view_default_115 = torch.ops.aten.view.default(expand_default_38, [2048, 31, 33]);  expand_default_38 = None
        expand_default_39 = torch.ops.aten.expand.default(transpose_int_47, [256, 8, 33, 64]);  transpose_int_47 = None
        clone_default_40 = torch.ops.aten.clone.default(expand_default_39, memory_format = torch.contiguous_format);  expand_default_39 = None
        _unsafe_view_default_87 = torch.ops.aten._unsafe_view.default(clone_default_40, [2048, 33, 64]);  clone_default_40 = None
        bmm_default_19 = torch.ops.aten.bmm.default(view_default_115, _unsafe_view_default_87)
        _unsafe_view_default_88 = torch.ops.aten._unsafe_view.default(bmm_default_19, [256, 8, 31, 64]);  bmm_default_19 = None
        transpose_int_49 = torch.ops.aten.transpose.int(_unsafe_view_default_88, 1, 2);  _unsafe_view_default_88 = None
        clone_default_41 = torch.ops.aten.clone.default(transpose_int_49, memory_format = torch.contiguous_format);  transpose_int_49 = None
        view_default_116 = torch.ops.aten.view.default(clone_default_41, [256, 31, -1]);  clone_default_41 = None
        t_default_53 = torch.ops.aten.t.default(primals_21);  primals_21 = None
        view_default_117 = torch.ops.aten.view.default(view_default_116, [7936, 512]);  view_default_116 = None
        mm_default_39 = torch.ops.aten.mm.default(view_default_117, t_default_53)
        _unsafe_view_default_89 = torch.ops.aten._unsafe_view.default(mm_default_39, [256, 31, 512]);  mm_default_39 = None
        add__tensor_16 = torch.ops.aten.add_.Tensor(_unsafe_view_default_89, getitem_51);  _unsafe_view_default_89 = getitem_51 = None
        native_layer_norm_default_18 = torch.ops.aten.native_layer_norm.default(add__tensor_16, [512], primals_23, primals_22, 1e-06)
        getitem_54 = native_layer_norm_default_18[0]
        getitem_55 = native_layer_norm_default_18[1]
        getitem_56 = native_layer_norm_default_18[2];  native_layer_norm_default_18 = None
        view_default_118 = torch.ops.aten.view.default(getitem_54, [7936, 512])
        t_default_54 = torch.ops.aten.t.default(primals_30);  primals_30 = None
        addmm_default_14 = torch.ops.aten.addmm.default(primals_29, view_default_118, t_default_54);  primals_29 = None
        view_default_119 = torch.ops.aten.view.default(addmm_default_14, [256, 31, 2048]);  addmm_default_14 = None
        relu_default_7 = torch.ops.aten.relu.default(view_default_119);  view_default_119 = None
        view_default_120 = torch.ops.aten.view.default(relu_default_7, [7936, 2048])
        t_default_55 = torch.ops.aten.t.default(primals_32);  primals_32 = None
        addmm_default_15 = torch.ops.aten.addmm.default(primals_31, view_default_120, t_default_55);  primals_31 = None
        view_default_121 = torch.ops.aten.view.default(addmm_default_15, [256, 31, 512]);  addmm_default_15 = None
        add__tensor_17 = torch.ops.aten.add_.Tensor(view_default_121, getitem_54);  view_default_121 = getitem_54 = None
        native_layer_norm_default_19 = torch.ops.aten.native_layer_norm.default(add__tensor_17, [512], primals_28, primals_27, 1e-06)
        getitem_57 = native_layer_norm_default_19[0]
        getitem_58 = native_layer_norm_default_19[1]
        getitem_59 = native_layer_norm_default_19[2];  native_layer_norm_default_19 = None
        t_default_56 = torch.ops.aten.t.default(primals_55);  primals_55 = None
        view_default_122 = torch.ops.aten.view.default(getitem_57, [7936, 512])
        mm_default_40 = torch.ops.aten.mm.default(view_default_122, t_default_56)
        _unsafe_view_default_90 = torch.ops.aten._unsafe_view.default(mm_default_40, [256, 31, 512]);  mm_default_40 = None
        view_default_123 = torch.ops.aten.view.default(_unsafe_view_default_90, [256, 31, 8, 64]);  _unsafe_view_default_90 = None
        t_default_57 = torch.ops.aten.t.default(primals_54);  primals_54 = None
        view_default_124 = torch.ops.aten.view.default(getitem_57, [7936, 512])
        mm_default_41 = torch.ops.aten.mm.default(view_default_124, t_default_57)
        _unsafe_view_default_91 = torch.ops.aten._unsafe_view.default(mm_default_41, [256, 31, 512]);  mm_default_41 = None
        view_default_125 = torch.ops.aten.view.default(_unsafe_view_default_91, [256, 31, 8, 64]);  _unsafe_view_default_91 = None
        t_default_58 = torch.ops.aten.t.default(primals_56);  primals_56 = None
        view_default_126 = torch.ops.aten.view.default(getitem_57, [7936, 512])
        mm_default_42 = torch.ops.aten.mm.default(view_default_126, t_default_58)
        _unsafe_view_default_92 = torch.ops.aten._unsafe_view.default(mm_default_42, [256, 31, 512]);  mm_default_42 = None
        view_default_127 = torch.ops.aten.view.default(_unsafe_view_default_92, [256, 31, 8, 64]);  _unsafe_view_default_92 = None
        transpose_int_50 = torch.ops.aten.transpose.int(view_default_123, 1, 2);  view_default_123 = None
        transpose_int_51 = torch.ops.aten.transpose.int(view_default_125, 1, 2);  view_default_125 = None
        transpose_int_52 = torch.ops.aten.transpose.int(view_default_127, 1, 2);  view_default_127 = None
        unsqueeze_default_12 = torch.ops.aten.unsqueeze.default(bitwise_and_tensor, 1)
        div_tensor_10 = torch.ops.aten.div.Tensor(transpose_int_50, 8.0);  transpose_int_50 = None
        transpose_int_53 = torch.ops.aten.transpose.int(transpose_int_51, 2, 3);  transpose_int_51 = None
        expand_default_40 = torch.ops.aten.expand.default(div_tensor_10, [256, 8, 31, 64]);  div_tensor_10 = None
        clone_default_42 = torch.ops.aten.clone.default(expand_default_40, memory_format = torch.contiguous_format);  expand_default_40 = None
        _unsafe_view_default_93 = torch.ops.aten._unsafe_view.default(clone_default_42, [2048, 31, 64]);  clone_default_42 = None
        expand_default_41 = torch.ops.aten.expand.default(transpose_int_53, [256, 8, 64, 31]);  transpose_int_53 = None
        clone_default_43 = torch.ops.aten.clone.default(expand_default_41, memory_format = torch.contiguous_format);  expand_default_41 = None
        _unsafe_view_default_94 = torch.ops.aten._unsafe_view.default(clone_default_43, [2048, 64, 31]);  clone_default_43 = None
        bmm_default_20 = torch.ops.aten.bmm.default(_unsafe_view_default_93, _unsafe_view_default_94)
        _unsafe_view_default_95 = torch.ops.aten._unsafe_view.default(bmm_default_20, [256, 8, 31, 31]);  bmm_default_20 = None
        eq_scalar_10 = torch.ops.aten.eq.Scalar(unsqueeze_default_12, 0);  unsqueeze_default_12 = None
        where_scalar_self_10 = torch.ops.aten.where.ScalarSelf(eq_scalar_10, -1000000000.0, _unsafe_view_default_95);  _unsafe_view_default_95 = None
        _softmax_default_10 = torch.ops.aten._softmax.default(where_scalar_self_10, -1, False);  where_scalar_self_10 = None
        expand_default_42 = torch.ops.aten.expand.default(_softmax_default_10, [256, 8, 31, 31])
        view_default_128 = torch.ops.aten.view.default(expand_default_42, [2048, 31, 31]);  expand_default_42 = None
        expand_default_43 = torch.ops.aten.expand.default(transpose_int_52, [256, 8, 31, 64]);  transpose_int_52 = None
        clone_default_44 = torch.ops.aten.clone.default(expand_default_43, memory_format = torch.contiguous_format);  expand_default_43 = None
        _unsafe_view_default_96 = torch.ops.aten._unsafe_view.default(clone_default_44, [2048, 31, 64]);  clone_default_44 = None
        bmm_default_21 = torch.ops.aten.bmm.default(view_default_128, _unsafe_view_default_96)
        _unsafe_view_default_97 = torch.ops.aten._unsafe_view.default(bmm_default_21, [256, 8, 31, 64]);  bmm_default_21 = None
        transpose_int_54 = torch.ops.aten.transpose.int(_unsafe_view_default_97, 1, 2);  _unsafe_view_default_97 = None
        clone_default_45 = torch.ops.aten.clone.default(transpose_int_54, memory_format = torch.contiguous_format);  transpose_int_54 = None
        view_default_129 = torch.ops.aten.view.default(clone_default_45, [256, 31, -1]);  clone_default_45 = None
        t_default_59 = torch.ops.aten.t.default(primals_51);  primals_51 = None
        view_default_130 = torch.ops.aten.view.default(view_default_129, [7936, 512]);  view_default_129 = None
        mm_default_43 = torch.ops.aten.mm.default(view_default_130, t_default_59)
        _unsafe_view_default_98 = torch.ops.aten._unsafe_view.default(mm_default_43, [256, 31, 512]);  mm_default_43 = None
        add__tensor_18 = torch.ops.aten.add_.Tensor(_unsafe_view_default_98, getitem_57);  _unsafe_view_default_98 = getitem_57 = None
        native_layer_norm_default_20 = torch.ops.aten.native_layer_norm.default(add__tensor_18, [512], primals_53, primals_52, 1e-06)
        getitem_60 = native_layer_norm_default_20[0]
        getitem_61 = native_layer_norm_default_20[1]
        getitem_62 = native_layer_norm_default_20[2];  native_layer_norm_default_20 = None
        t_default_60 = torch.ops.aten.t.default(primals_43);  primals_43 = None
        view_default_131 = torch.ops.aten.view.default(getitem_60, [7936, 512])
        mm_default_44 = torch.ops.aten.mm.default(view_default_131, t_default_60)
        _unsafe_view_default_99 = torch.ops.aten._unsafe_view.default(mm_default_44, [256, 31, 512]);  mm_default_44 = None
        view_default_132 = torch.ops.aten.view.default(_unsafe_view_default_99, [256, 31, 8, 64]);  _unsafe_view_default_99 = None
        t_default_61 = torch.ops.aten.t.default(primals_42);  primals_42 = None
        view_default_133 = torch.ops.aten.view.default(getitem_36, [8448, 512])
        mm_default_45 = torch.ops.aten.mm.default(view_default_133, t_default_61)
        _unsafe_view_default_100 = torch.ops.aten._unsafe_view.default(mm_default_45, [256, 33, 512]);  mm_default_45 = None
        view_default_134 = torch.ops.aten.view.default(_unsafe_view_default_100, [256, 33, 8, 64]);  _unsafe_view_default_100 = None
        t_default_62 = torch.ops.aten.t.default(primals_44);  primals_44 = None
        view_default_135 = torch.ops.aten.view.default(getitem_36, [8448, 512])
        mm_default_46 = torch.ops.aten.mm.default(view_default_135, t_default_62)
        _unsafe_view_default_101 = torch.ops.aten._unsafe_view.default(mm_default_46, [256, 33, 512]);  mm_default_46 = None
        view_default_136 = torch.ops.aten.view.default(_unsafe_view_default_101, [256, 33, 8, 64]);  _unsafe_view_default_101 = None
        transpose_int_55 = torch.ops.aten.transpose.int(view_default_132, 1, 2);  view_default_132 = None
        transpose_int_56 = torch.ops.aten.transpose.int(view_default_134, 1, 2);  view_default_134 = None
        transpose_int_57 = torch.ops.aten.transpose.int(view_default_136, 1, 2);  view_default_136 = None
        unsqueeze_default_13 = torch.ops.aten.unsqueeze.default(unsqueeze_default, 1)
        div_tensor_11 = torch.ops.aten.div.Tensor(transpose_int_55, 8.0);  transpose_int_55 = None
        transpose_int_58 = torch.ops.aten.transpose.int(transpose_int_56, 2, 3);  transpose_int_56 = None
        expand_default_44 = torch.ops.aten.expand.default(div_tensor_11, [256, 8, 31, 64]);  div_tensor_11 = None
        clone_default_46 = torch.ops.aten.clone.default(expand_default_44, memory_format = torch.contiguous_format);  expand_default_44 = None
        _unsafe_view_default_102 = torch.ops.aten._unsafe_view.default(clone_default_46, [2048, 31, 64]);  clone_default_46 = None
        expand_default_45 = torch.ops.aten.expand.default(transpose_int_58, [256, 8, 64, 33]);  transpose_int_58 = None
        clone_default_47 = torch.ops.aten.clone.default(expand_default_45, memory_format = torch.contiguous_format);  expand_default_45 = None
        _unsafe_view_default_103 = torch.ops.aten._unsafe_view.default(clone_default_47, [2048, 64, 33]);  clone_default_47 = None
        bmm_default_22 = torch.ops.aten.bmm.default(_unsafe_view_default_102, _unsafe_view_default_103)
        _unsafe_view_default_104 = torch.ops.aten._unsafe_view.default(bmm_default_22, [256, 8, 31, 33]);  bmm_default_22 = None
        eq_scalar_11 = torch.ops.aten.eq.Scalar(unsqueeze_default_13, 0);  unsqueeze_default_13 = None
        where_scalar_self_11 = torch.ops.aten.where.ScalarSelf(eq_scalar_11, -1000000000.0, _unsafe_view_default_104);  _unsafe_view_default_104 = None
        _softmax_default_11 = torch.ops.aten._softmax.default(where_scalar_self_11, -1, False);  where_scalar_self_11 = None
        expand_default_46 = torch.ops.aten.expand.default(_softmax_default_11, [256, 8, 31, 33])
        view_default_137 = torch.ops.aten.view.default(expand_default_46, [2048, 31, 33]);  expand_default_46 = None
        expand_default_47 = torch.ops.aten.expand.default(transpose_int_57, [256, 8, 33, 64]);  transpose_int_57 = None
        clone_default_48 = torch.ops.aten.clone.default(expand_default_47, memory_format = torch.contiguous_format);  expand_default_47 = None
        _unsafe_view_default_105 = torch.ops.aten._unsafe_view.default(clone_default_48, [2048, 33, 64]);  clone_default_48 = None
        bmm_default_23 = torch.ops.aten.bmm.default(view_default_137, _unsafe_view_default_105)
        _unsafe_view_default_106 = torch.ops.aten._unsafe_view.default(bmm_default_23, [256, 8, 31, 64]);  bmm_default_23 = None
        transpose_int_59 = torch.ops.aten.transpose.int(_unsafe_view_default_106, 1, 2);  _unsafe_view_default_106 = None
        clone_default_49 = torch.ops.aten.clone.default(transpose_int_59, memory_format = torch.contiguous_format);  transpose_int_59 = None
        view_default_138 = torch.ops.aten.view.default(clone_default_49, [256, 31, -1]);  clone_default_49 = None
        t_default_63 = torch.ops.aten.t.default(primals_39);  primals_39 = None
        view_default_139 = torch.ops.aten.view.default(view_default_138, [7936, 512]);  view_default_138 = None
        mm_default_47 = torch.ops.aten.mm.default(view_default_139, t_default_63)
        _unsafe_view_default_107 = torch.ops.aten._unsafe_view.default(mm_default_47, [256, 31, 512]);  mm_default_47 = None
        add__tensor_19 = torch.ops.aten.add_.Tensor(_unsafe_view_default_107, getitem_60);  _unsafe_view_default_107 = getitem_60 = None
        native_layer_norm_default_21 = torch.ops.aten.native_layer_norm.default(add__tensor_19, [512], primals_41, primals_40, 1e-06)
        getitem_63 = native_layer_norm_default_21[0]
        getitem_64 = native_layer_norm_default_21[1]
        getitem_65 = native_layer_norm_default_21[2];  native_layer_norm_default_21 = None
        view_default_140 = torch.ops.aten.view.default(getitem_63, [7936, 512])
        t_default_64 = torch.ops.aten.t.default(primals_48);  primals_48 = None
        addmm_default_16 = torch.ops.aten.addmm.default(primals_47, view_default_140, t_default_64);  primals_47 = None
        view_default_141 = torch.ops.aten.view.default(addmm_default_16, [256, 31, 2048]);  addmm_default_16 = None
        relu_default_8 = torch.ops.aten.relu.default(view_default_141);  view_default_141 = None
        view_default_142 = torch.ops.aten.view.default(relu_default_8, [7936, 2048])
        t_default_65 = torch.ops.aten.t.default(primals_50);  primals_50 = None
        addmm_default_17 = torch.ops.aten.addmm.default(primals_49, view_default_142, t_default_65);  primals_49 = None
        view_default_143 = torch.ops.aten.view.default(addmm_default_17, [256, 31, 512]);  addmm_default_17 = None
        add__tensor_20 = torch.ops.aten.add_.Tensor(view_default_143, getitem_63);  view_default_143 = getitem_63 = None
        native_layer_norm_default_22 = torch.ops.aten.native_layer_norm.default(add__tensor_20, [512], primals_46, primals_45, 1e-06)
        getitem_66 = native_layer_norm_default_22[0]
        getitem_67 = native_layer_norm_default_22[1]
        getitem_68 = native_layer_norm_default_22[2];  native_layer_norm_default_22 = None
        t_default_66 = torch.ops.aten.t.default(primals_73);  primals_73 = None
        view_default_144 = torch.ops.aten.view.default(getitem_66, [7936, 512])
        mm_default_48 = torch.ops.aten.mm.default(view_default_144, t_default_66)
        _unsafe_view_default_108 = torch.ops.aten._unsafe_view.default(mm_default_48, [256, 31, 512]);  mm_default_48 = None
        view_default_145 = torch.ops.aten.view.default(_unsafe_view_default_108, [256, 31, 8, 64]);  _unsafe_view_default_108 = None
        t_default_67 = torch.ops.aten.t.default(primals_72);  primals_72 = None
        view_default_146 = torch.ops.aten.view.default(getitem_66, [7936, 512])
        mm_default_49 = torch.ops.aten.mm.default(view_default_146, t_default_67)
        _unsafe_view_default_109 = torch.ops.aten._unsafe_view.default(mm_default_49, [256, 31, 512]);  mm_default_49 = None
        view_default_147 = torch.ops.aten.view.default(_unsafe_view_default_109, [256, 31, 8, 64]);  _unsafe_view_default_109 = None
        t_default_68 = torch.ops.aten.t.default(primals_74);  primals_74 = None
        view_default_148 = torch.ops.aten.view.default(getitem_66, [7936, 512])
        mm_default_50 = torch.ops.aten.mm.default(view_default_148, t_default_68)
        _unsafe_view_default_110 = torch.ops.aten._unsafe_view.default(mm_default_50, [256, 31, 512]);  mm_default_50 = None
        view_default_149 = torch.ops.aten.view.default(_unsafe_view_default_110, [256, 31, 8, 64]);  _unsafe_view_default_110 = None
        transpose_int_60 = torch.ops.aten.transpose.int(view_default_145, 1, 2);  view_default_145 = None
        transpose_int_61 = torch.ops.aten.transpose.int(view_default_147, 1, 2);  view_default_147 = None
        transpose_int_62 = torch.ops.aten.transpose.int(view_default_149, 1, 2);  view_default_149 = None
        unsqueeze_default_14 = torch.ops.aten.unsqueeze.default(bitwise_and_tensor, 1)
        div_tensor_12 = torch.ops.aten.div.Tensor(transpose_int_60, 8.0);  transpose_int_60 = None
        transpose_int_63 = torch.ops.aten.transpose.int(transpose_int_61, 2, 3);  transpose_int_61 = None
        expand_default_48 = torch.ops.aten.expand.default(div_tensor_12, [256, 8, 31, 64]);  div_tensor_12 = None
        clone_default_50 = torch.ops.aten.clone.default(expand_default_48, memory_format = torch.contiguous_format);  expand_default_48 = None
        _unsafe_view_default_111 = torch.ops.aten._unsafe_view.default(clone_default_50, [2048, 31, 64]);  clone_default_50 = None
        expand_default_49 = torch.ops.aten.expand.default(transpose_int_63, [256, 8, 64, 31]);  transpose_int_63 = None
        clone_default_51 = torch.ops.aten.clone.default(expand_default_49, memory_format = torch.contiguous_format);  expand_default_49 = None
        _unsafe_view_default_112 = torch.ops.aten._unsafe_view.default(clone_default_51, [2048, 64, 31]);  clone_default_51 = None
        bmm_default_24 = torch.ops.aten.bmm.default(_unsafe_view_default_111, _unsafe_view_default_112)
        _unsafe_view_default_113 = torch.ops.aten._unsafe_view.default(bmm_default_24, [256, 8, 31, 31]);  bmm_default_24 = None
        eq_scalar_12 = torch.ops.aten.eq.Scalar(unsqueeze_default_14, 0);  unsqueeze_default_14 = None
        where_scalar_self_12 = torch.ops.aten.where.ScalarSelf(eq_scalar_12, -1000000000.0, _unsafe_view_default_113);  _unsafe_view_default_113 = None
        _softmax_default_12 = torch.ops.aten._softmax.default(where_scalar_self_12, -1, False);  where_scalar_self_12 = None
        expand_default_50 = torch.ops.aten.expand.default(_softmax_default_12, [256, 8, 31, 31])
        view_default_150 = torch.ops.aten.view.default(expand_default_50, [2048, 31, 31]);  expand_default_50 = None
        expand_default_51 = torch.ops.aten.expand.default(transpose_int_62, [256, 8, 31, 64]);  transpose_int_62 = None
        clone_default_52 = torch.ops.aten.clone.default(expand_default_51, memory_format = torch.contiguous_format);  expand_default_51 = None
        _unsafe_view_default_114 = torch.ops.aten._unsafe_view.default(clone_default_52, [2048, 31, 64]);  clone_default_52 = None
        bmm_default_25 = torch.ops.aten.bmm.default(view_default_150, _unsafe_view_default_114)
        _unsafe_view_default_115 = torch.ops.aten._unsafe_view.default(bmm_default_25, [256, 8, 31, 64]);  bmm_default_25 = None
        transpose_int_64 = torch.ops.aten.transpose.int(_unsafe_view_default_115, 1, 2);  _unsafe_view_default_115 = None
        clone_default_53 = torch.ops.aten.clone.default(transpose_int_64, memory_format = torch.contiguous_format);  transpose_int_64 = None
        view_default_151 = torch.ops.aten.view.default(clone_default_53, [256, 31, -1]);  clone_default_53 = None
        t_default_69 = torch.ops.aten.t.default(primals_69);  primals_69 = None
        view_default_152 = torch.ops.aten.view.default(view_default_151, [7936, 512]);  view_default_151 = None
        mm_default_51 = torch.ops.aten.mm.default(view_default_152, t_default_69)
        _unsafe_view_default_116 = torch.ops.aten._unsafe_view.default(mm_default_51, [256, 31, 512]);  mm_default_51 = None
        add__tensor_21 = torch.ops.aten.add_.Tensor(_unsafe_view_default_116, getitem_66);  _unsafe_view_default_116 = getitem_66 = None
        native_layer_norm_default_23 = torch.ops.aten.native_layer_norm.default(add__tensor_21, [512], primals_71, primals_70, 1e-06)
        getitem_69 = native_layer_norm_default_23[0]
        getitem_70 = native_layer_norm_default_23[1]
        getitem_71 = native_layer_norm_default_23[2];  native_layer_norm_default_23 = None
        t_default_70 = torch.ops.aten.t.default(primals_61);  primals_61 = None
        view_default_153 = torch.ops.aten.view.default(getitem_69, [7936, 512])
        mm_default_52 = torch.ops.aten.mm.default(view_default_153, t_default_70)
        _unsafe_view_default_117 = torch.ops.aten._unsafe_view.default(mm_default_52, [256, 31, 512]);  mm_default_52 = None
        view_default_154 = torch.ops.aten.view.default(_unsafe_view_default_117, [256, 31, 8, 64]);  _unsafe_view_default_117 = None
        t_default_71 = torch.ops.aten.t.default(primals_60);  primals_60 = None
        view_default_155 = torch.ops.aten.view.default(getitem_36, [8448, 512])
        mm_default_53 = torch.ops.aten.mm.default(view_default_155, t_default_71)
        _unsafe_view_default_118 = torch.ops.aten._unsafe_view.default(mm_default_53, [256, 33, 512]);  mm_default_53 = None
        view_default_156 = torch.ops.aten.view.default(_unsafe_view_default_118, [256, 33, 8, 64]);  _unsafe_view_default_118 = None
        t_default_72 = torch.ops.aten.t.default(primals_62);  primals_62 = None
        view_default_157 = torch.ops.aten.view.default(getitem_36, [8448, 512])
        mm_default_54 = torch.ops.aten.mm.default(view_default_157, t_default_72)
        _unsafe_view_default_119 = torch.ops.aten._unsafe_view.default(mm_default_54, [256, 33, 512]);  mm_default_54 = None
        view_default_158 = torch.ops.aten.view.default(_unsafe_view_default_119, [256, 33, 8, 64]);  _unsafe_view_default_119 = None
        transpose_int_65 = torch.ops.aten.transpose.int(view_default_154, 1, 2);  view_default_154 = None
        transpose_int_66 = torch.ops.aten.transpose.int(view_default_156, 1, 2);  view_default_156 = None
        transpose_int_67 = torch.ops.aten.transpose.int(view_default_158, 1, 2);  view_default_158 = None
        unsqueeze_default_15 = torch.ops.aten.unsqueeze.default(unsqueeze_default, 1)
        div_tensor_13 = torch.ops.aten.div.Tensor(transpose_int_65, 8.0);  transpose_int_65 = None
        transpose_int_68 = torch.ops.aten.transpose.int(transpose_int_66, 2, 3);  transpose_int_66 = None
        expand_default_52 = torch.ops.aten.expand.default(div_tensor_13, [256, 8, 31, 64]);  div_tensor_13 = None
        clone_default_54 = torch.ops.aten.clone.default(expand_default_52, memory_format = torch.contiguous_format);  expand_default_52 = None
        _unsafe_view_default_120 = torch.ops.aten._unsafe_view.default(clone_default_54, [2048, 31, 64]);  clone_default_54 = None
        expand_default_53 = torch.ops.aten.expand.default(transpose_int_68, [256, 8, 64, 33]);  transpose_int_68 = None
        clone_default_55 = torch.ops.aten.clone.default(expand_default_53, memory_format = torch.contiguous_format);  expand_default_53 = None
        _unsafe_view_default_121 = torch.ops.aten._unsafe_view.default(clone_default_55, [2048, 64, 33]);  clone_default_55 = None
        bmm_default_26 = torch.ops.aten.bmm.default(_unsafe_view_default_120, _unsafe_view_default_121)
        _unsafe_view_default_122 = torch.ops.aten._unsafe_view.default(bmm_default_26, [256, 8, 31, 33]);  bmm_default_26 = None
        eq_scalar_13 = torch.ops.aten.eq.Scalar(unsqueeze_default_15, 0);  unsqueeze_default_15 = None
        where_scalar_self_13 = torch.ops.aten.where.ScalarSelf(eq_scalar_13, -1000000000.0, _unsafe_view_default_122);  _unsafe_view_default_122 = None
        _softmax_default_13 = torch.ops.aten._softmax.default(where_scalar_self_13, -1, False);  where_scalar_self_13 = None
        expand_default_54 = torch.ops.aten.expand.default(_softmax_default_13, [256, 8, 31, 33])
        view_default_159 = torch.ops.aten.view.default(expand_default_54, [2048, 31, 33]);  expand_default_54 = None
        expand_default_55 = torch.ops.aten.expand.default(transpose_int_67, [256, 8, 33, 64]);  transpose_int_67 = None
        clone_default_56 = torch.ops.aten.clone.default(expand_default_55, memory_format = torch.contiguous_format);  expand_default_55 = None
        _unsafe_view_default_123 = torch.ops.aten._unsafe_view.default(clone_default_56, [2048, 33, 64]);  clone_default_56 = None
        bmm_default_27 = torch.ops.aten.bmm.default(view_default_159, _unsafe_view_default_123)
        _unsafe_view_default_124 = torch.ops.aten._unsafe_view.default(bmm_default_27, [256, 8, 31, 64]);  bmm_default_27 = None
        transpose_int_69 = torch.ops.aten.transpose.int(_unsafe_view_default_124, 1, 2);  _unsafe_view_default_124 = None
        clone_default_57 = torch.ops.aten.clone.default(transpose_int_69, memory_format = torch.contiguous_format);  transpose_int_69 = None
        view_default_160 = torch.ops.aten.view.default(clone_default_57, [256, 31, -1]);  clone_default_57 = None
        t_default_73 = torch.ops.aten.t.default(primals_57);  primals_57 = None
        view_default_161 = torch.ops.aten.view.default(view_default_160, [7936, 512]);  view_default_160 = None
        mm_default_55 = torch.ops.aten.mm.default(view_default_161, t_default_73)
        _unsafe_view_default_125 = torch.ops.aten._unsafe_view.default(mm_default_55, [256, 31, 512]);  mm_default_55 = None
        add__tensor_22 = torch.ops.aten.add_.Tensor(_unsafe_view_default_125, getitem_69);  _unsafe_view_default_125 = getitem_69 = None
        native_layer_norm_default_24 = torch.ops.aten.native_layer_norm.default(add__tensor_22, [512], primals_59, primals_58, 1e-06)
        getitem_72 = native_layer_norm_default_24[0]
        getitem_73 = native_layer_norm_default_24[1]
        getitem_74 = native_layer_norm_default_24[2];  native_layer_norm_default_24 = None
        view_default_162 = torch.ops.aten.view.default(getitem_72, [7936, 512])
        t_default_74 = torch.ops.aten.t.default(primals_66);  primals_66 = None
        addmm_default_18 = torch.ops.aten.addmm.default(primals_65, view_default_162, t_default_74);  primals_65 = None
        view_default_163 = torch.ops.aten.view.default(addmm_default_18, [256, 31, 2048]);  addmm_default_18 = None
        relu_default_9 = torch.ops.aten.relu.default(view_default_163);  view_default_163 = None
        view_default_164 = torch.ops.aten.view.default(relu_default_9, [7936, 2048])
        t_default_75 = torch.ops.aten.t.default(primals_68);  primals_68 = None
        addmm_default_19 = torch.ops.aten.addmm.default(primals_67, view_default_164, t_default_75);  primals_67 = None
        view_default_165 = torch.ops.aten.view.default(addmm_default_19, [256, 31, 512]);  addmm_default_19 = None
        add__tensor_23 = torch.ops.aten.add_.Tensor(view_default_165, getitem_72);  view_default_165 = getitem_72 = None
        native_layer_norm_default_25 = torch.ops.aten.native_layer_norm.default(add__tensor_23, [512], primals_64, primals_63, 1e-06)
        getitem_75 = native_layer_norm_default_25[0]
        getitem_76 = native_layer_norm_default_25[1]
        getitem_77 = native_layer_norm_default_25[2];  native_layer_norm_default_25 = None
        t_default_76 = torch.ops.aten.t.default(primals_91);  primals_91 = None
        view_default_166 = torch.ops.aten.view.default(getitem_75, [7936, 512])
        mm_default_56 = torch.ops.aten.mm.default(view_default_166, t_default_76)
        _unsafe_view_default_126 = torch.ops.aten._unsafe_view.default(mm_default_56, [256, 31, 512]);  mm_default_56 = None
        view_default_167 = torch.ops.aten.view.default(_unsafe_view_default_126, [256, 31, 8, 64]);  _unsafe_view_default_126 = None
        t_default_77 = torch.ops.aten.t.default(primals_90);  primals_90 = None
        view_default_168 = torch.ops.aten.view.default(getitem_75, [7936, 512])
        mm_default_57 = torch.ops.aten.mm.default(view_default_168, t_default_77)
        _unsafe_view_default_127 = torch.ops.aten._unsafe_view.default(mm_default_57, [256, 31, 512]);  mm_default_57 = None
        view_default_169 = torch.ops.aten.view.default(_unsafe_view_default_127, [256, 31, 8, 64]);  _unsafe_view_default_127 = None
        t_default_78 = torch.ops.aten.t.default(primals_92);  primals_92 = None
        view_default_170 = torch.ops.aten.view.default(getitem_75, [7936, 512])
        mm_default_58 = torch.ops.aten.mm.default(view_default_170, t_default_78)
        _unsafe_view_default_128 = torch.ops.aten._unsafe_view.default(mm_default_58, [256, 31, 512]);  mm_default_58 = None
        view_default_171 = torch.ops.aten.view.default(_unsafe_view_default_128, [256, 31, 8, 64]);  _unsafe_view_default_128 = None
        transpose_int_70 = torch.ops.aten.transpose.int(view_default_167, 1, 2);  view_default_167 = None
        transpose_int_71 = torch.ops.aten.transpose.int(view_default_169, 1, 2);  view_default_169 = None
        transpose_int_72 = torch.ops.aten.transpose.int(view_default_171, 1, 2);  view_default_171 = None
        unsqueeze_default_16 = torch.ops.aten.unsqueeze.default(bitwise_and_tensor, 1)
        div_tensor_14 = torch.ops.aten.div.Tensor(transpose_int_70, 8.0);  transpose_int_70 = None
        transpose_int_73 = torch.ops.aten.transpose.int(transpose_int_71, 2, 3);  transpose_int_71 = None
        expand_default_56 = torch.ops.aten.expand.default(div_tensor_14, [256, 8, 31, 64]);  div_tensor_14 = None
        clone_default_58 = torch.ops.aten.clone.default(expand_default_56, memory_format = torch.contiguous_format);  expand_default_56 = None
        _unsafe_view_default_129 = torch.ops.aten._unsafe_view.default(clone_default_58, [2048, 31, 64]);  clone_default_58 = None
        expand_default_57 = torch.ops.aten.expand.default(transpose_int_73, [256, 8, 64, 31]);  transpose_int_73 = None
        clone_default_59 = torch.ops.aten.clone.default(expand_default_57, memory_format = torch.contiguous_format);  expand_default_57 = None
        _unsafe_view_default_130 = torch.ops.aten._unsafe_view.default(clone_default_59, [2048, 64, 31]);  clone_default_59 = None
        bmm_default_28 = torch.ops.aten.bmm.default(_unsafe_view_default_129, _unsafe_view_default_130)
        _unsafe_view_default_131 = torch.ops.aten._unsafe_view.default(bmm_default_28, [256, 8, 31, 31]);  bmm_default_28 = None
        eq_scalar_14 = torch.ops.aten.eq.Scalar(unsqueeze_default_16, 0);  unsqueeze_default_16 = None
        where_scalar_self_14 = torch.ops.aten.where.ScalarSelf(eq_scalar_14, -1000000000.0, _unsafe_view_default_131);  _unsafe_view_default_131 = None
        _softmax_default_14 = torch.ops.aten._softmax.default(where_scalar_self_14, -1, False);  where_scalar_self_14 = None
        expand_default_58 = torch.ops.aten.expand.default(_softmax_default_14, [256, 8, 31, 31])
        view_default_172 = torch.ops.aten.view.default(expand_default_58, [2048, 31, 31]);  expand_default_58 = None
        expand_default_59 = torch.ops.aten.expand.default(transpose_int_72, [256, 8, 31, 64]);  transpose_int_72 = None
        clone_default_60 = torch.ops.aten.clone.default(expand_default_59, memory_format = torch.contiguous_format);  expand_default_59 = None
        _unsafe_view_default_132 = torch.ops.aten._unsafe_view.default(clone_default_60, [2048, 31, 64]);  clone_default_60 = None
        bmm_default_29 = torch.ops.aten.bmm.default(view_default_172, _unsafe_view_default_132)
        _unsafe_view_default_133 = torch.ops.aten._unsafe_view.default(bmm_default_29, [256, 8, 31, 64]);  bmm_default_29 = None
        transpose_int_74 = torch.ops.aten.transpose.int(_unsafe_view_default_133, 1, 2);  _unsafe_view_default_133 = None
        clone_default_61 = torch.ops.aten.clone.default(transpose_int_74, memory_format = torch.contiguous_format);  transpose_int_74 = None
        view_default_173 = torch.ops.aten.view.default(clone_default_61, [256, 31, -1]);  clone_default_61 = None
        t_default_79 = torch.ops.aten.t.default(primals_87);  primals_87 = None
        view_default_174 = torch.ops.aten.view.default(view_default_173, [7936, 512]);  view_default_173 = None
        mm_default_59 = torch.ops.aten.mm.default(view_default_174, t_default_79)
        _unsafe_view_default_134 = torch.ops.aten._unsafe_view.default(mm_default_59, [256, 31, 512]);  mm_default_59 = None
        add__tensor_24 = torch.ops.aten.add_.Tensor(_unsafe_view_default_134, getitem_75);  _unsafe_view_default_134 = getitem_75 = None
        native_layer_norm_default_26 = torch.ops.aten.native_layer_norm.default(add__tensor_24, [512], primals_89, primals_88, 1e-06)
        getitem_78 = native_layer_norm_default_26[0]
        getitem_79 = native_layer_norm_default_26[1]
        getitem_80 = native_layer_norm_default_26[2];  native_layer_norm_default_26 = None
        t_default_80 = torch.ops.aten.t.default(primals_79);  primals_79 = None
        view_default_175 = torch.ops.aten.view.default(getitem_78, [7936, 512])
        mm_default_60 = torch.ops.aten.mm.default(view_default_175, t_default_80)
        _unsafe_view_default_135 = torch.ops.aten._unsafe_view.default(mm_default_60, [256, 31, 512]);  mm_default_60 = None
        view_default_176 = torch.ops.aten.view.default(_unsafe_view_default_135, [256, 31, 8, 64]);  _unsafe_view_default_135 = None
        t_default_81 = torch.ops.aten.t.default(primals_78);  primals_78 = None
        view_default_177 = torch.ops.aten.view.default(getitem_36, [8448, 512])
        mm_default_61 = torch.ops.aten.mm.default(view_default_177, t_default_81)
        _unsafe_view_default_136 = torch.ops.aten._unsafe_view.default(mm_default_61, [256, 33, 512]);  mm_default_61 = None
        view_default_178 = torch.ops.aten.view.default(_unsafe_view_default_136, [256, 33, 8, 64]);  _unsafe_view_default_136 = None
        t_default_82 = torch.ops.aten.t.default(primals_80);  primals_80 = None
        view_default_179 = torch.ops.aten.view.default(getitem_36, [8448, 512])
        mm_default_62 = torch.ops.aten.mm.default(view_default_179, t_default_82)
        _unsafe_view_default_137 = torch.ops.aten._unsafe_view.default(mm_default_62, [256, 33, 512]);  mm_default_62 = None
        view_default_180 = torch.ops.aten.view.default(_unsafe_view_default_137, [256, 33, 8, 64]);  _unsafe_view_default_137 = None
        transpose_int_75 = torch.ops.aten.transpose.int(view_default_176, 1, 2);  view_default_176 = None
        transpose_int_76 = torch.ops.aten.transpose.int(view_default_178, 1, 2);  view_default_178 = None
        transpose_int_77 = torch.ops.aten.transpose.int(view_default_180, 1, 2);  view_default_180 = None
        unsqueeze_default_17 = torch.ops.aten.unsqueeze.default(unsqueeze_default, 1)
        div_tensor_15 = torch.ops.aten.div.Tensor(transpose_int_75, 8.0);  transpose_int_75 = None
        transpose_int_78 = torch.ops.aten.transpose.int(transpose_int_76, 2, 3);  transpose_int_76 = None
        expand_default_60 = torch.ops.aten.expand.default(div_tensor_15, [256, 8, 31, 64]);  div_tensor_15 = None
        clone_default_62 = torch.ops.aten.clone.default(expand_default_60, memory_format = torch.contiguous_format);  expand_default_60 = None
        _unsafe_view_default_138 = torch.ops.aten._unsafe_view.default(clone_default_62, [2048, 31, 64]);  clone_default_62 = None
        expand_default_61 = torch.ops.aten.expand.default(transpose_int_78, [256, 8, 64, 33]);  transpose_int_78 = None
        clone_default_63 = torch.ops.aten.clone.default(expand_default_61, memory_format = torch.contiguous_format);  expand_default_61 = None
        _unsafe_view_default_139 = torch.ops.aten._unsafe_view.default(clone_default_63, [2048, 64, 33]);  clone_default_63 = None
        bmm_default_30 = torch.ops.aten.bmm.default(_unsafe_view_default_138, _unsafe_view_default_139)
        _unsafe_view_default_140 = torch.ops.aten._unsafe_view.default(bmm_default_30, [256, 8, 31, 33]);  bmm_default_30 = None
        eq_scalar_15 = torch.ops.aten.eq.Scalar(unsqueeze_default_17, 0);  unsqueeze_default_17 = None
        where_scalar_self_15 = torch.ops.aten.where.ScalarSelf(eq_scalar_15, -1000000000.0, _unsafe_view_default_140);  _unsafe_view_default_140 = None
        _softmax_default_15 = torch.ops.aten._softmax.default(where_scalar_self_15, -1, False);  where_scalar_self_15 = None
        expand_default_62 = torch.ops.aten.expand.default(_softmax_default_15, [256, 8, 31, 33])
        view_default_181 = torch.ops.aten.view.default(expand_default_62, [2048, 31, 33]);  expand_default_62 = None
        expand_default_63 = torch.ops.aten.expand.default(transpose_int_77, [256, 8, 33, 64]);  transpose_int_77 = None
        clone_default_64 = torch.ops.aten.clone.default(expand_default_63, memory_format = torch.contiguous_format);  expand_default_63 = None
        _unsafe_view_default_141 = torch.ops.aten._unsafe_view.default(clone_default_64, [2048, 33, 64]);  clone_default_64 = None
        bmm_default_31 = torch.ops.aten.bmm.default(view_default_181, _unsafe_view_default_141)
        _unsafe_view_default_142 = torch.ops.aten._unsafe_view.default(bmm_default_31, [256, 8, 31, 64]);  bmm_default_31 = None
        transpose_int_79 = torch.ops.aten.transpose.int(_unsafe_view_default_142, 1, 2);  _unsafe_view_default_142 = None
        clone_default_65 = torch.ops.aten.clone.default(transpose_int_79, memory_format = torch.contiguous_format);  transpose_int_79 = None
        view_default_182 = torch.ops.aten.view.default(clone_default_65, [256, 31, -1]);  clone_default_65 = None
        t_default_83 = torch.ops.aten.t.default(primals_75);  primals_75 = None
        view_default_183 = torch.ops.aten.view.default(view_default_182, [7936, 512]);  view_default_182 = None
        mm_default_63 = torch.ops.aten.mm.default(view_default_183, t_default_83)
        _unsafe_view_default_143 = torch.ops.aten._unsafe_view.default(mm_default_63, [256, 31, 512]);  mm_default_63 = None
        add__tensor_25 = torch.ops.aten.add_.Tensor(_unsafe_view_default_143, getitem_78);  _unsafe_view_default_143 = getitem_78 = None
        native_layer_norm_default_27 = torch.ops.aten.native_layer_norm.default(add__tensor_25, [512], primals_77, primals_76, 1e-06)
        getitem_81 = native_layer_norm_default_27[0]
        getitem_82 = native_layer_norm_default_27[1]
        getitem_83 = native_layer_norm_default_27[2];  native_layer_norm_default_27 = None
        view_default_184 = torch.ops.aten.view.default(getitem_81, [7936, 512])
        t_default_84 = torch.ops.aten.t.default(primals_84);  primals_84 = None
        addmm_default_20 = torch.ops.aten.addmm.default(primals_83, view_default_184, t_default_84);  primals_83 = None
        view_default_185 = torch.ops.aten.view.default(addmm_default_20, [256, 31, 2048]);  addmm_default_20 = None
        relu_default_10 = torch.ops.aten.relu.default(view_default_185);  view_default_185 = None
        view_default_186 = torch.ops.aten.view.default(relu_default_10, [7936, 2048])
        t_default_85 = torch.ops.aten.t.default(primals_86);  primals_86 = None
        addmm_default_21 = torch.ops.aten.addmm.default(primals_85, view_default_186, t_default_85);  primals_85 = None
        view_default_187 = torch.ops.aten.view.default(addmm_default_21, [256, 31, 512]);  addmm_default_21 = None
        add__tensor_26 = torch.ops.aten.add_.Tensor(view_default_187, getitem_81);  view_default_187 = getitem_81 = None
        native_layer_norm_default_28 = torch.ops.aten.native_layer_norm.default(add__tensor_26, [512], primals_82, primals_81, 1e-06)
        getitem_84 = native_layer_norm_default_28[0]
        getitem_85 = native_layer_norm_default_28[1]
        getitem_86 = native_layer_norm_default_28[2];  native_layer_norm_default_28 = None
        t_default_86 = torch.ops.aten.t.default(primals_109);  primals_109 = None
        view_default_188 = torch.ops.aten.view.default(getitem_84, [7936, 512])
        mm_default_64 = torch.ops.aten.mm.default(view_default_188, t_default_86)
        _unsafe_view_default_144 = torch.ops.aten._unsafe_view.default(mm_default_64, [256, 31, 512]);  mm_default_64 = None
        view_default_189 = torch.ops.aten.view.default(_unsafe_view_default_144, [256, 31, 8, 64]);  _unsafe_view_default_144 = None
        t_default_87 = torch.ops.aten.t.default(primals_108);  primals_108 = None
        view_default_190 = torch.ops.aten.view.default(getitem_84, [7936, 512])
        mm_default_65 = torch.ops.aten.mm.default(view_default_190, t_default_87)
        _unsafe_view_default_145 = torch.ops.aten._unsafe_view.default(mm_default_65, [256, 31, 512]);  mm_default_65 = None
        view_default_191 = torch.ops.aten.view.default(_unsafe_view_default_145, [256, 31, 8, 64]);  _unsafe_view_default_145 = None
        t_default_88 = torch.ops.aten.t.default(primals_110);  primals_110 = None
        view_default_192 = torch.ops.aten.view.default(getitem_84, [7936, 512])
        mm_default_66 = torch.ops.aten.mm.default(view_default_192, t_default_88)
        _unsafe_view_default_146 = torch.ops.aten._unsafe_view.default(mm_default_66, [256, 31, 512]);  mm_default_66 = None
        view_default_193 = torch.ops.aten.view.default(_unsafe_view_default_146, [256, 31, 8, 64]);  _unsafe_view_default_146 = None
        transpose_int_80 = torch.ops.aten.transpose.int(view_default_189, 1, 2);  view_default_189 = None
        transpose_int_81 = torch.ops.aten.transpose.int(view_default_191, 1, 2);  view_default_191 = None
        transpose_int_82 = torch.ops.aten.transpose.int(view_default_193, 1, 2);  view_default_193 = None
        unsqueeze_default_18 = torch.ops.aten.unsqueeze.default(bitwise_and_tensor, 1);  bitwise_and_tensor = None
        div_tensor_16 = torch.ops.aten.div.Tensor(transpose_int_80, 8.0);  transpose_int_80 = None
        transpose_int_83 = torch.ops.aten.transpose.int(transpose_int_81, 2, 3);  transpose_int_81 = None
        expand_default_64 = torch.ops.aten.expand.default(div_tensor_16, [256, 8, 31, 64]);  div_tensor_16 = None
        clone_default_66 = torch.ops.aten.clone.default(expand_default_64, memory_format = torch.contiguous_format);  expand_default_64 = None
        _unsafe_view_default_147 = torch.ops.aten._unsafe_view.default(clone_default_66, [2048, 31, 64]);  clone_default_66 = None
        expand_default_65 = torch.ops.aten.expand.default(transpose_int_83, [256, 8, 64, 31]);  transpose_int_83 = None
        clone_default_67 = torch.ops.aten.clone.default(expand_default_65, memory_format = torch.contiguous_format);  expand_default_65 = None
        _unsafe_view_default_148 = torch.ops.aten._unsafe_view.default(clone_default_67, [2048, 64, 31]);  clone_default_67 = None
        bmm_default_32 = torch.ops.aten.bmm.default(_unsafe_view_default_147, _unsafe_view_default_148)
        _unsafe_view_default_149 = torch.ops.aten._unsafe_view.default(bmm_default_32, [256, 8, 31, 31]);  bmm_default_32 = None
        eq_scalar_16 = torch.ops.aten.eq.Scalar(unsqueeze_default_18, 0);  unsqueeze_default_18 = None
        where_scalar_self_16 = torch.ops.aten.where.ScalarSelf(eq_scalar_16, -1000000000.0, _unsafe_view_default_149);  _unsafe_view_default_149 = None
        _softmax_default_16 = torch.ops.aten._softmax.default(where_scalar_self_16, -1, False);  where_scalar_self_16 = None
        expand_default_66 = torch.ops.aten.expand.default(_softmax_default_16, [256, 8, 31, 31])
        view_default_194 = torch.ops.aten.view.default(expand_default_66, [2048, 31, 31]);  expand_default_66 = None
        expand_default_67 = torch.ops.aten.expand.default(transpose_int_82, [256, 8, 31, 64]);  transpose_int_82 = None
        clone_default_68 = torch.ops.aten.clone.default(expand_default_67, memory_format = torch.contiguous_format);  expand_default_67 = None
        _unsafe_view_default_150 = torch.ops.aten._unsafe_view.default(clone_default_68, [2048, 31, 64]);  clone_default_68 = None
        bmm_default_33 = torch.ops.aten.bmm.default(view_default_194, _unsafe_view_default_150)
        _unsafe_view_default_151 = torch.ops.aten._unsafe_view.default(bmm_default_33, [256, 8, 31, 64]);  bmm_default_33 = None
        transpose_int_84 = torch.ops.aten.transpose.int(_unsafe_view_default_151, 1, 2);  _unsafe_view_default_151 = None
        clone_default_69 = torch.ops.aten.clone.default(transpose_int_84, memory_format = torch.contiguous_format);  transpose_int_84 = None
        view_default_195 = torch.ops.aten.view.default(clone_default_69, [256, 31, -1]);  clone_default_69 = None
        t_default_89 = torch.ops.aten.t.default(primals_105);  primals_105 = None
        view_default_196 = torch.ops.aten.view.default(view_default_195, [7936, 512]);  view_default_195 = None
        mm_default_67 = torch.ops.aten.mm.default(view_default_196, t_default_89)
        _unsafe_view_default_152 = torch.ops.aten._unsafe_view.default(mm_default_67, [256, 31, 512]);  mm_default_67 = None
        add__tensor_27 = torch.ops.aten.add_.Tensor(_unsafe_view_default_152, getitem_84);  _unsafe_view_default_152 = getitem_84 = None
        native_layer_norm_default_29 = torch.ops.aten.native_layer_norm.default(add__tensor_27, [512], primals_107, primals_106, 1e-06)
        getitem_87 = native_layer_norm_default_29[0]
        getitem_88 = native_layer_norm_default_29[1]
        getitem_89 = native_layer_norm_default_29[2];  native_layer_norm_default_29 = None
        t_default_90 = torch.ops.aten.t.default(primals_97);  primals_97 = None
        view_default_197 = torch.ops.aten.view.default(getitem_87, [7936, 512])
        mm_default_68 = torch.ops.aten.mm.default(view_default_197, t_default_90)
        _unsafe_view_default_153 = torch.ops.aten._unsafe_view.default(mm_default_68, [256, 31, 512]);  mm_default_68 = None
        view_default_198 = torch.ops.aten.view.default(_unsafe_view_default_153, [256, 31, 8, 64]);  _unsafe_view_default_153 = None
        t_default_91 = torch.ops.aten.t.default(primals_96);  primals_96 = None
        view_default_199 = torch.ops.aten.view.default(getitem_36, [8448, 512])
        mm_default_69 = torch.ops.aten.mm.default(view_default_199, t_default_91)
        _unsafe_view_default_154 = torch.ops.aten._unsafe_view.default(mm_default_69, [256, 33, 512]);  mm_default_69 = None
        view_default_200 = torch.ops.aten.view.default(_unsafe_view_default_154, [256, 33, 8, 64]);  _unsafe_view_default_154 = None
        t_default_92 = torch.ops.aten.t.default(primals_98);  primals_98 = None
        view_default_201 = torch.ops.aten.view.default(getitem_36, [8448, 512]);  getitem_36 = None
        mm_default_70 = torch.ops.aten.mm.default(view_default_201, t_default_92)
        _unsafe_view_default_155 = torch.ops.aten._unsafe_view.default(mm_default_70, [256, 33, 512]);  mm_default_70 = None
        view_default_202 = torch.ops.aten.view.default(_unsafe_view_default_155, [256, 33, 8, 64]);  _unsafe_view_default_155 = None
        transpose_int_85 = torch.ops.aten.transpose.int(view_default_198, 1, 2);  view_default_198 = None
        transpose_int_86 = torch.ops.aten.transpose.int(view_default_200, 1, 2);  view_default_200 = None
        transpose_int_87 = torch.ops.aten.transpose.int(view_default_202, 1, 2);  view_default_202 = None
        unsqueeze_default_19 = torch.ops.aten.unsqueeze.default(unsqueeze_default, 1);  unsqueeze_default = None
        div_tensor_17 = torch.ops.aten.div.Tensor(transpose_int_85, 8.0);  transpose_int_85 = None
        transpose_int_88 = torch.ops.aten.transpose.int(transpose_int_86, 2, 3);  transpose_int_86 = None
        expand_default_68 = torch.ops.aten.expand.default(div_tensor_17, [256, 8, 31, 64]);  div_tensor_17 = None
        clone_default_70 = torch.ops.aten.clone.default(expand_default_68, memory_format = torch.contiguous_format);  expand_default_68 = None
        _unsafe_view_default_156 = torch.ops.aten._unsafe_view.default(clone_default_70, [2048, 31, 64]);  clone_default_70 = None
        expand_default_69 = torch.ops.aten.expand.default(transpose_int_88, [256, 8, 64, 33]);  transpose_int_88 = None
        clone_default_71 = torch.ops.aten.clone.default(expand_default_69, memory_format = torch.contiguous_format);  expand_default_69 = None
        _unsafe_view_default_157 = torch.ops.aten._unsafe_view.default(clone_default_71, [2048, 64, 33]);  clone_default_71 = None
        bmm_default_34 = torch.ops.aten.bmm.default(_unsafe_view_default_156, _unsafe_view_default_157)
        _unsafe_view_default_158 = torch.ops.aten._unsafe_view.default(bmm_default_34, [256, 8, 31, 33]);  bmm_default_34 = None
        eq_scalar_17 = torch.ops.aten.eq.Scalar(unsqueeze_default_19, 0);  unsqueeze_default_19 = None
        where_scalar_self_17 = torch.ops.aten.where.ScalarSelf(eq_scalar_17, -1000000000.0, _unsafe_view_default_158);  _unsafe_view_default_158 = None
        _softmax_default_17 = torch.ops.aten._softmax.default(where_scalar_self_17, -1, False);  where_scalar_self_17 = None
        expand_default_70 = torch.ops.aten.expand.default(_softmax_default_17, [256, 8, 31, 33])
        view_default_203 = torch.ops.aten.view.default(expand_default_70, [2048, 31, 33]);  expand_default_70 = None
        expand_default_71 = torch.ops.aten.expand.default(transpose_int_87, [256, 8, 33, 64]);  transpose_int_87 = None
        clone_default_72 = torch.ops.aten.clone.default(expand_default_71, memory_format = torch.contiguous_format);  expand_default_71 = None
        _unsafe_view_default_159 = torch.ops.aten._unsafe_view.default(clone_default_72, [2048, 33, 64]);  clone_default_72 = None
        bmm_default_35 = torch.ops.aten.bmm.default(view_default_203, _unsafe_view_default_159)
        _unsafe_view_default_160 = torch.ops.aten._unsafe_view.default(bmm_default_35, [256, 8, 31, 64]);  bmm_default_35 = None
        transpose_int_89 = torch.ops.aten.transpose.int(_unsafe_view_default_160, 1, 2);  _unsafe_view_default_160 = None
        clone_default_73 = torch.ops.aten.clone.default(transpose_int_89, memory_format = torch.contiguous_format);  transpose_int_89 = None
        view_default_204 = torch.ops.aten.view.default(clone_default_73, [256, 31, -1]);  clone_default_73 = None
        t_default_93 = torch.ops.aten.t.default(primals_93);  primals_93 = None
        view_default_205 = torch.ops.aten.view.default(view_default_204, [7936, 512]);  view_default_204 = None
        mm_default_71 = torch.ops.aten.mm.default(view_default_205, t_default_93)
        _unsafe_view_default_161 = torch.ops.aten._unsafe_view.default(mm_default_71, [256, 31, 512]);  mm_default_71 = None
        add__tensor_28 = torch.ops.aten.add_.Tensor(_unsafe_view_default_161, getitem_87);  _unsafe_view_default_161 = getitem_87 = None
        native_layer_norm_default_30 = torch.ops.aten.native_layer_norm.default(add__tensor_28, [512], primals_95, primals_94, 1e-06)
        getitem_90 = native_layer_norm_default_30[0]
        getitem_91 = native_layer_norm_default_30[1]
        getitem_92 = native_layer_norm_default_30[2];  native_layer_norm_default_30 = None
        view_default_206 = torch.ops.aten.view.default(getitem_90, [7936, 512])
        t_default_94 = torch.ops.aten.t.default(primals_102);  primals_102 = None
        addmm_default_22 = torch.ops.aten.addmm.default(primals_101, view_default_206, t_default_94);  primals_101 = None
        view_default_207 = torch.ops.aten.view.default(addmm_default_22, [256, 31, 2048]);  addmm_default_22 = None
        relu_default_11 = torch.ops.aten.relu.default(view_default_207);  view_default_207 = None
        view_default_208 = torch.ops.aten.view.default(relu_default_11, [7936, 2048])
        t_default_95 = torch.ops.aten.t.default(primals_104);  primals_104 = None
        addmm_default_23 = torch.ops.aten.addmm.default(primals_103, view_default_208, t_default_95);  primals_103 = None
        view_default_209 = torch.ops.aten.view.default(addmm_default_23, [256, 31, 512]);  addmm_default_23 = None
        add__tensor_29 = torch.ops.aten.add_.Tensor(view_default_209, getitem_90);  view_default_209 = getitem_90 = None
        native_layer_norm_default_31 = torch.ops.aten.native_layer_norm.default(add__tensor_29, [512], primals_100, primals_99, 1e-06)
        getitem_93 = native_layer_norm_default_31[0]
        getitem_94 = native_layer_norm_default_31[1]
        getitem_95 = native_layer_norm_default_31[2];  native_layer_norm_default_31 = None
        t_default_96 = torch.ops.aten.t.default(primals_189);  primals_189 = None
        view_default_210 = torch.ops.aten.view.default(getitem_93, [7936, 512]);  getitem_93 = None
        mm_default_72 = torch.ops.aten.mm.default(view_default_210, t_default_96)
        _unsafe_view_default_162 = torch.ops.aten._unsafe_view.default(mm_default_72, [256, 31, 9521]);  mm_default_72 = None
        mul_tensor = torch.ops.aten.mul.Tensor(_unsafe_view_default_162, 1.0);  _unsafe_view_default_162 = None
        view_default_211 = torch.ops.aten.view.default(mul_tensor, [-1, 9521]);  mul_tensor = None
        is_same_size_default = torch.ops.aten.is_same_size.default(view_default_211, tangents_1)
        view_default_212 = torch.ops.aten.view.default(tangents_1, [256, 31, 9521]);  tangents_1 = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(view_default_212, 1.0);  view_default_212 = None
        view_default_213 = torch.ops.aten.view.default(mul_tensor_1, [7936, 9521]);  mul_tensor_1 = None
        t_default_97 = torch.ops.aten.t.default(view_default_213)
        mm_default_73 = torch.ops.aten.mm.default(t_default_97, view_default_210);  t_default_97 = view_default_210 = None
        t_default_98 = torch.ops.aten.t.default(mm_default_73);  mm_default_73 = None
        t_default_99 = torch.ops.aten.t.default(t_default_96);  t_default_96 = None
        mm_default_74 = torch.ops.aten.mm.default(view_default_213, t_default_99);  view_default_213 = t_default_99 = None
        view_default_214 = torch.ops.aten.view.default(mm_default_74, [256, 31, 512]);  mm_default_74 = None
        t_default_100 = torch.ops.aten.t.default(t_default_98);  t_default_98 = None
        native_layer_norm_backward_default = torch.ops.aten.native_layer_norm_backward.default(view_default_214, add__tensor_29, [512], getitem_94, getitem_95, primals_100, primals_99, [True, True, True]);  view_default_214 = add__tensor_29 = getitem_94 = getitem_95 = primals_100 = primals_99 = None
        getitem_96 = native_layer_norm_backward_default[0]
        getitem_97 = native_layer_norm_backward_default[1]
        getitem_98 = native_layer_norm_backward_default[2];  native_layer_norm_backward_default = None
        new_empty_default = torch.ops.aten.new_empty.default(getitem_96, [4063232])
        zero__default = torch.ops.aten.zero_.default(new_empty_default);  new_empty_default = None
        as_strided_default = torch.ops.aten.as_strided.default(zero__default, [256, 31, 512], [15872, 512, 1], 0)
        copy__default = torch.ops.aten.copy_.default(as_strided_default, getitem_96);  as_strided_default = getitem_96 = None
        as_strided_default_1 = torch.ops.aten.as_strided.default(zero__default, [7936, 512], [512, 1], 0);  zero__default = None
        new_empty_strided_default = torch.ops.aten.new_empty_strided.default(as_strided_default_1, [7936, 512], [512, 1])
        copy__default_1 = torch.ops.aten.copy_.default(new_empty_strided_default, as_strided_default_1);  new_empty_strided_default = as_strided_default_1 = None
        as_strided_default_2 = torch.ops.aten.as_strided.default(copy__default_1, [256, 31, 512], [15872, 512, 1], 0)
        clone_default_74 = torch.ops.aten.clone.default(as_strided_default_2, memory_format = torch.contiguous_format)
        copy__default_2 = torch.ops.aten.copy_.default(as_strided_default_2, clone_default_74);  as_strided_default_2 = None
        t_default_101 = torch.ops.aten.t.default(t_default_95);  t_default_95 = None
        mm_default_75 = torch.ops.aten.mm.default(copy__default_1, t_default_101);  t_default_101 = None
        t_default_102 = torch.ops.aten.t.default(copy__default_1)
        mm_default_76 = torch.ops.aten.mm.default(t_default_102, view_default_208);  t_default_102 = view_default_208 = None
        t_default_103 = torch.ops.aten.t.default(mm_default_76);  mm_default_76 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(copy__default_1, [0], True);  copy__default_1 = None
        view_default_215 = torch.ops.aten.view.default(sum_dim_int_list, [512]);  sum_dim_int_list = None
        t_default_104 = torch.ops.aten.t.default(t_default_103);  t_default_103 = None
        view_default_216 = torch.ops.aten.view.default(mm_default_75, [256, 31, 2048]);  mm_default_75 = None
        to_dtype = torch.ops.aten.to.dtype(view_default_216, torch.float32);  view_default_216 = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu_default_11, torch.float32);  relu_default_11 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default, to_dtype);  le_scalar = new_zeros_default = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        view_default_217 = torch.ops.aten.view.default(to_dtype_2, [7936, 2048]);  to_dtype_2 = None
        t_default_105 = torch.ops.aten.t.default(t_default_94);  t_default_94 = None
        mm_default_77 = torch.ops.aten.mm.default(view_default_217, t_default_105);  t_default_105 = None
        t_default_106 = torch.ops.aten.t.default(view_default_217)
        mm_default_78 = torch.ops.aten.mm.default(t_default_106, view_default_206);  t_default_106 = view_default_206 = None
        t_default_107 = torch.ops.aten.t.default(mm_default_78);  mm_default_78 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(view_default_217, [0], True);  view_default_217 = None
        view_default_218 = torch.ops.aten.view.default(sum_dim_int_list_1, [2048]);  sum_dim_int_list_1 = None
        t_default_108 = torch.ops.aten.t.default(t_default_107);  t_default_107 = None
        view_default_219 = torch.ops.aten.view.default(mm_default_77, [256, 31, 512]);  mm_default_77 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(clone_default_74, view_default_219);  clone_default_74 = view_default_219 = None
        native_layer_norm_backward_default_1 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_2, add__tensor_28, [512], getitem_91, getitem_92, primals_95, primals_94, [True, True, True]);  add_tensor_2 = add__tensor_28 = getitem_91 = getitem_92 = primals_95 = primals_94 = None
        getitem_99 = native_layer_norm_backward_default_1[0]
        getitem_100 = native_layer_norm_backward_default_1[1]
        getitem_101 = native_layer_norm_backward_default_1[2];  native_layer_norm_backward_default_1 = None
        view_default_220 = torch.ops.aten.view.default(getitem_99, [7936, 512])
        t_default_109 = torch.ops.aten.t.default(view_default_220)
        mm_default_79 = torch.ops.aten.mm.default(t_default_109, view_default_205);  t_default_109 = view_default_205 = None
        t_default_110 = torch.ops.aten.t.default(mm_default_79);  mm_default_79 = None
        t_default_111 = torch.ops.aten.t.default(t_default_93);  t_default_93 = None
        mm_default_80 = torch.ops.aten.mm.default(view_default_220, t_default_111);  view_default_220 = t_default_111 = None
        view_default_221 = torch.ops.aten.view.default(mm_default_80, [256, 31, 512]);  mm_default_80 = None
        t_default_112 = torch.ops.aten.t.default(t_default_110);  t_default_110 = None
        view_default_222 = torch.ops.aten.view.default(view_default_221, [256, 31, 8, 64]);  view_default_221 = None
        transpose_int_90 = torch.ops.aten.transpose.int(view_default_222, 1, 2);  view_default_222 = None
        clone_default_75 = torch.ops.aten.clone.default(transpose_int_90, memory_format = torch.contiguous_format);  transpose_int_90 = None
        _unsafe_view_default_163 = torch.ops.aten._unsafe_view.default(clone_default_75, [2048, 31, 64]);  clone_default_75 = None
        transpose_int_91 = torch.ops.aten.transpose.int(view_default_203, 1, 2);  view_default_203 = None
        bmm_default_36 = torch.ops.aten.bmm.default(transpose_int_91, _unsafe_view_default_163);  transpose_int_91 = None
        transpose_int_92 = torch.ops.aten.transpose.int(_unsafe_view_default_159, 1, 2);  _unsafe_view_default_159 = None
        bmm_default_37 = torch.ops.aten.bmm.default(_unsafe_view_default_163, transpose_int_92);  _unsafe_view_default_163 = transpose_int_92 = None
        view_default_223 = torch.ops.aten.view.default(bmm_default_36, [256, 8, 33, 64]);  bmm_default_36 = None
        view_default_224 = torch.ops.aten.view.default(bmm_default_37, [256, 8, 31, 33]);  bmm_default_37 = None
        _softmax_backward_data_default = torch.ops.aten._softmax_backward_data.default(view_default_224, _softmax_default_17, -1, torch.float32);  view_default_224 = _softmax_default_17 = None
        where_scalar_self_18 = torch.ops.aten.where.ScalarSelf(eq_scalar_17, 0.0, _softmax_backward_data_default);  eq_scalar_17 = _softmax_backward_data_default = None
        view_default_225 = torch.ops.aten.view.default(where_scalar_self_18, [2048, 31, 33]);  where_scalar_self_18 = None
        transpose_int_93 = torch.ops.aten.transpose.int(_unsafe_view_default_156, 1, 2);  _unsafe_view_default_156 = None
        bmm_default_38 = torch.ops.aten.bmm.default(transpose_int_93, view_default_225);  transpose_int_93 = None
        transpose_int_94 = torch.ops.aten.transpose.int(_unsafe_view_default_157, 1, 2);  _unsafe_view_default_157 = None
        bmm_default_39 = torch.ops.aten.bmm.default(view_default_225, transpose_int_94);  view_default_225 = transpose_int_94 = None
        view_default_226 = torch.ops.aten.view.default(bmm_default_38, [256, 8, 64, 33]);  bmm_default_38 = None
        view_default_227 = torch.ops.aten.view.default(bmm_default_39, [256, 8, 31, 64]);  bmm_default_39 = None
        transpose_int_95 = torch.ops.aten.transpose.int(view_default_226, 2, 3);  view_default_226 = None
        div_tensor_18 = torch.ops.aten.div.Tensor(view_default_227, 8.0);  view_default_227 = None
        transpose_int_96 = torch.ops.aten.transpose.int(view_default_223, 1, 2);  view_default_223 = None
        transpose_int_97 = torch.ops.aten.transpose.int(transpose_int_95, 1, 2);  transpose_int_95 = None
        transpose_int_98 = torch.ops.aten.transpose.int(div_tensor_18, 1, 2);  div_tensor_18 = None
        clone_default_76 = torch.ops.aten.clone.default(transpose_int_96, memory_format = torch.contiguous_format);  transpose_int_96 = None
        _unsafe_view_default_164 = torch.ops.aten._unsafe_view.default(clone_default_76, [256, 33, 512]);  clone_default_76 = None
        view_default_228 = torch.ops.aten.view.default(_unsafe_view_default_164, [8448, 512]);  _unsafe_view_default_164 = None
        t_default_113 = torch.ops.aten.t.default(view_default_228)
        mm_default_81 = torch.ops.aten.mm.default(t_default_113, view_default_201);  t_default_113 = view_default_201 = None
        t_default_114 = torch.ops.aten.t.default(mm_default_81);  mm_default_81 = None
        t_default_115 = torch.ops.aten.t.default(t_default_92);  t_default_92 = None
        mm_default_82 = torch.ops.aten.mm.default(view_default_228, t_default_115);  view_default_228 = t_default_115 = None
        view_default_229 = torch.ops.aten.view.default(mm_default_82, [256, 33, 512]);  mm_default_82 = None
        t_default_116 = torch.ops.aten.t.default(t_default_114);  t_default_114 = None
        view_default_230 = torch.ops.aten.view.default(transpose_int_97, [256, 33, 512]);  transpose_int_97 = None
        clone_default_77 = torch.ops.aten.clone.default(view_default_230, memory_format = torch.contiguous_format);  view_default_230 = None
        _unsafe_view_default_165 = torch.ops.aten._unsafe_view.default(clone_default_77, [8448, 512]);  clone_default_77 = None
        t_default_117 = torch.ops.aten.t.default(_unsafe_view_default_165)
        mm_default_83 = torch.ops.aten.mm.default(t_default_117, view_default_199);  t_default_117 = view_default_199 = None
        t_default_118 = torch.ops.aten.t.default(mm_default_83);  mm_default_83 = None
        t_default_119 = torch.ops.aten.t.default(t_default_91);  t_default_91 = None
        mm_default_84 = torch.ops.aten.mm.default(_unsafe_view_default_165, t_default_119);  _unsafe_view_default_165 = t_default_119 = None
        view_default_231 = torch.ops.aten.view.default(mm_default_84, [256, 33, 512]);  mm_default_84 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(view_default_229, view_default_231);  view_default_229 = view_default_231 = None
        t_default_120 = torch.ops.aten.t.default(t_default_118);  t_default_118 = None
        clone_default_78 = torch.ops.aten.clone.default(transpose_int_98, memory_format = torch.contiguous_format);  transpose_int_98 = None
        _unsafe_view_default_166 = torch.ops.aten._unsafe_view.default(clone_default_78, [256, 31, 512]);  clone_default_78 = None
        view_default_232 = torch.ops.aten.view.default(_unsafe_view_default_166, [7936, 512]);  _unsafe_view_default_166 = None
        t_default_121 = torch.ops.aten.t.default(view_default_232)
        mm_default_85 = torch.ops.aten.mm.default(t_default_121, view_default_197);  t_default_121 = view_default_197 = None
        t_default_122 = torch.ops.aten.t.default(mm_default_85);  mm_default_85 = None
        t_default_123 = torch.ops.aten.t.default(t_default_90);  t_default_90 = None
        mm_default_86 = torch.ops.aten.mm.default(view_default_232, t_default_123);  view_default_232 = t_default_123 = None
        view_default_233 = torch.ops.aten.view.default(mm_default_86, [256, 31, 512]);  mm_default_86 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(getitem_99, view_default_233);  getitem_99 = view_default_233 = None
        t_default_124 = torch.ops.aten.t.default(t_default_122);  t_default_122 = None
        native_layer_norm_backward_default_2 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_4, add__tensor_27, [512], getitem_88, getitem_89, primals_107, primals_106, [True, True, True]);  add_tensor_4 = add__tensor_27 = getitem_88 = getitem_89 = primals_107 = primals_106 = None
        getitem_102 = native_layer_norm_backward_default_2[0]
        getitem_103 = native_layer_norm_backward_default_2[1]
        getitem_104 = native_layer_norm_backward_default_2[2];  native_layer_norm_backward_default_2 = None
        view_default_234 = torch.ops.aten.view.default(getitem_102, [7936, 512])
        t_default_125 = torch.ops.aten.t.default(view_default_234)
        mm_default_87 = torch.ops.aten.mm.default(t_default_125, view_default_196);  t_default_125 = view_default_196 = None
        t_default_126 = torch.ops.aten.t.default(mm_default_87);  mm_default_87 = None
        t_default_127 = torch.ops.aten.t.default(t_default_89);  t_default_89 = None
        mm_default_88 = torch.ops.aten.mm.default(view_default_234, t_default_127);  view_default_234 = t_default_127 = None
        view_default_235 = torch.ops.aten.view.default(mm_default_88, [256, 31, 512]);  mm_default_88 = None
        t_default_128 = torch.ops.aten.t.default(t_default_126);  t_default_126 = None
        view_default_236 = torch.ops.aten.view.default(view_default_235, [256, 31, 8, 64]);  view_default_235 = None
        transpose_int_99 = torch.ops.aten.transpose.int(view_default_236, 1, 2);  view_default_236 = None
        clone_default_79 = torch.ops.aten.clone.default(transpose_int_99, memory_format = torch.contiguous_format);  transpose_int_99 = None
        _unsafe_view_default_167 = torch.ops.aten._unsafe_view.default(clone_default_79, [2048, 31, 64]);  clone_default_79 = None
        transpose_int_100 = torch.ops.aten.transpose.int(view_default_194, 1, 2);  view_default_194 = None
        bmm_default_40 = torch.ops.aten.bmm.default(transpose_int_100, _unsafe_view_default_167);  transpose_int_100 = None
        transpose_int_101 = torch.ops.aten.transpose.int(_unsafe_view_default_150, 1, 2);  _unsafe_view_default_150 = None
        bmm_default_41 = torch.ops.aten.bmm.default(_unsafe_view_default_167, transpose_int_101);  _unsafe_view_default_167 = transpose_int_101 = None
        view_default_237 = torch.ops.aten.view.default(bmm_default_40, [256, 8, 31, 64]);  bmm_default_40 = None
        view_default_238 = torch.ops.aten.view.default(bmm_default_41, [256, 8, 31, 31]);  bmm_default_41 = None
        _softmax_backward_data_default_1 = torch.ops.aten._softmax_backward_data.default(view_default_238, _softmax_default_16, -1, torch.float32);  view_default_238 = _softmax_default_16 = None
        where_scalar_self_19 = torch.ops.aten.where.ScalarSelf(eq_scalar_16, 0.0, _softmax_backward_data_default_1);  eq_scalar_16 = _softmax_backward_data_default_1 = None
        view_default_239 = torch.ops.aten.view.default(where_scalar_self_19, [2048, 31, 31]);  where_scalar_self_19 = None
        transpose_int_102 = torch.ops.aten.transpose.int(_unsafe_view_default_147, 1, 2);  _unsafe_view_default_147 = None
        bmm_default_42 = torch.ops.aten.bmm.default(transpose_int_102, view_default_239);  transpose_int_102 = None
        transpose_int_103 = torch.ops.aten.transpose.int(_unsafe_view_default_148, 1, 2);  _unsafe_view_default_148 = None
        bmm_default_43 = torch.ops.aten.bmm.default(view_default_239, transpose_int_103);  view_default_239 = transpose_int_103 = None
        view_default_240 = torch.ops.aten.view.default(bmm_default_42, [256, 8, 64, 31]);  bmm_default_42 = None
        view_default_241 = torch.ops.aten.view.default(bmm_default_43, [256, 8, 31, 64]);  bmm_default_43 = None
        transpose_int_104 = torch.ops.aten.transpose.int(view_default_240, 2, 3);  view_default_240 = None
        div_tensor_19 = torch.ops.aten.div.Tensor(view_default_241, 8.0);  view_default_241 = None
        transpose_int_105 = torch.ops.aten.transpose.int(view_default_237, 1, 2);  view_default_237 = None
        transpose_int_106 = torch.ops.aten.transpose.int(transpose_int_104, 1, 2);  transpose_int_104 = None
        transpose_int_107 = torch.ops.aten.transpose.int(div_tensor_19, 1, 2);  div_tensor_19 = None
        clone_default_80 = torch.ops.aten.clone.default(transpose_int_105, memory_format = torch.contiguous_format);  transpose_int_105 = None
        _unsafe_view_default_168 = torch.ops.aten._unsafe_view.default(clone_default_80, [256, 31, 512]);  clone_default_80 = None
        view_default_242 = torch.ops.aten.view.default(_unsafe_view_default_168, [7936, 512]);  _unsafe_view_default_168 = None
        t_default_129 = torch.ops.aten.t.default(view_default_242)
        mm_default_89 = torch.ops.aten.mm.default(t_default_129, view_default_192);  t_default_129 = view_default_192 = None
        t_default_130 = torch.ops.aten.t.default(mm_default_89);  mm_default_89 = None
        t_default_131 = torch.ops.aten.t.default(t_default_88);  t_default_88 = None
        mm_default_90 = torch.ops.aten.mm.default(view_default_242, t_default_131);  view_default_242 = t_default_131 = None
        view_default_243 = torch.ops.aten.view.default(mm_default_90, [256, 31, 512]);  mm_default_90 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(getitem_102, view_default_243);  getitem_102 = view_default_243 = None
        t_default_132 = torch.ops.aten.t.default(t_default_130);  t_default_130 = None
        view_default_244 = torch.ops.aten.view.default(transpose_int_106, [256, 31, 512]);  transpose_int_106 = None
        clone_default_81 = torch.ops.aten.clone.default(view_default_244, memory_format = torch.contiguous_format);  view_default_244 = None
        _unsafe_view_default_169 = torch.ops.aten._unsafe_view.default(clone_default_81, [7936, 512]);  clone_default_81 = None
        t_default_133 = torch.ops.aten.t.default(_unsafe_view_default_169)
        mm_default_91 = torch.ops.aten.mm.default(t_default_133, view_default_190);  t_default_133 = view_default_190 = None
        t_default_134 = torch.ops.aten.t.default(mm_default_91);  mm_default_91 = None
        t_default_135 = torch.ops.aten.t.default(t_default_87);  t_default_87 = None
        mm_default_92 = torch.ops.aten.mm.default(_unsafe_view_default_169, t_default_135);  _unsafe_view_default_169 = t_default_135 = None
        view_default_245 = torch.ops.aten.view.default(mm_default_92, [256, 31, 512]);  mm_default_92 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(add_tensor_5, view_default_245);  add_tensor_5 = view_default_245 = None
        t_default_136 = torch.ops.aten.t.default(t_default_134);  t_default_134 = None
        clone_default_82 = torch.ops.aten.clone.default(transpose_int_107, memory_format = torch.contiguous_format);  transpose_int_107 = None
        _unsafe_view_default_170 = torch.ops.aten._unsafe_view.default(clone_default_82, [256, 31, 512]);  clone_default_82 = None
        view_default_246 = torch.ops.aten.view.default(_unsafe_view_default_170, [7936, 512]);  _unsafe_view_default_170 = None
        t_default_137 = torch.ops.aten.t.default(view_default_246)
        mm_default_93 = torch.ops.aten.mm.default(t_default_137, view_default_188);  t_default_137 = view_default_188 = None
        t_default_138 = torch.ops.aten.t.default(mm_default_93);  mm_default_93 = None
        t_default_139 = torch.ops.aten.t.default(t_default_86);  t_default_86 = None
        mm_default_94 = torch.ops.aten.mm.default(view_default_246, t_default_139);  view_default_246 = t_default_139 = None
        view_default_247 = torch.ops.aten.view.default(mm_default_94, [256, 31, 512]);  mm_default_94 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(add_tensor_6, view_default_247);  add_tensor_6 = view_default_247 = None
        t_default_140 = torch.ops.aten.t.default(t_default_138);  t_default_138 = None
        native_layer_norm_backward_default_3 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_7, add__tensor_26, [512], getitem_85, getitem_86, primals_82, primals_81, [True, True, True]);  add_tensor_7 = add__tensor_26 = getitem_85 = getitem_86 = primals_82 = primals_81 = None
        getitem_105 = native_layer_norm_backward_default_3[0]
        getitem_106 = native_layer_norm_backward_default_3[1]
        getitem_107 = native_layer_norm_backward_default_3[2];  native_layer_norm_backward_default_3 = None
        new_empty_default_1 = torch.ops.aten.new_empty.default(getitem_105, [4063232])
        zero__default_1 = torch.ops.aten.zero_.default(new_empty_default_1);  new_empty_default_1 = None
        as_strided_default_3 = torch.ops.aten.as_strided.default(zero__default_1, [256, 31, 512], [15872, 512, 1], 0)
        copy__default_3 = torch.ops.aten.copy_.default(as_strided_default_3, getitem_105);  as_strided_default_3 = getitem_105 = None
        as_strided_default_4 = torch.ops.aten.as_strided.default(zero__default_1, [7936, 512], [512, 1], 0);  zero__default_1 = None
        new_empty_strided_default_1 = torch.ops.aten.new_empty_strided.default(as_strided_default_4, [7936, 512], [512, 1])
        copy__default_4 = torch.ops.aten.copy_.default(new_empty_strided_default_1, as_strided_default_4);  new_empty_strided_default_1 = as_strided_default_4 = None
        as_strided_default_5 = torch.ops.aten.as_strided.default(copy__default_4, [256, 31, 512], [15872, 512, 1], 0)
        clone_default_83 = torch.ops.aten.clone.default(as_strided_default_5, memory_format = torch.contiguous_format)
        copy__default_5 = torch.ops.aten.copy_.default(as_strided_default_5, clone_default_83);  as_strided_default_5 = None
        t_default_141 = torch.ops.aten.t.default(t_default_85);  t_default_85 = None
        mm_default_95 = torch.ops.aten.mm.default(copy__default_4, t_default_141);  t_default_141 = None
        t_default_142 = torch.ops.aten.t.default(copy__default_4)
        mm_default_96 = torch.ops.aten.mm.default(t_default_142, view_default_186);  t_default_142 = view_default_186 = None
        t_default_143 = torch.ops.aten.t.default(mm_default_96);  mm_default_96 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(copy__default_4, [0], True);  copy__default_4 = None
        view_default_248 = torch.ops.aten.view.default(sum_dim_int_list_2, [512]);  sum_dim_int_list_2 = None
        t_default_144 = torch.ops.aten.t.default(t_default_143);  t_default_143 = None
        view_default_249 = torch.ops.aten.view.default(mm_default_95, [256, 31, 2048]);  mm_default_95 = None
        to_dtype_3 = torch.ops.aten.to.dtype(view_default_249, torch.float32);  view_default_249 = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu_default_10, torch.float32);  relu_default_10 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_1, to_dtype_3);  le_scalar_1 = new_zeros_default_1 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        view_default_250 = torch.ops.aten.view.default(to_dtype_5, [7936, 2048]);  to_dtype_5 = None
        t_default_145 = torch.ops.aten.t.default(t_default_84);  t_default_84 = None
        mm_default_97 = torch.ops.aten.mm.default(view_default_250, t_default_145);  t_default_145 = None
        t_default_146 = torch.ops.aten.t.default(view_default_250)
        mm_default_98 = torch.ops.aten.mm.default(t_default_146, view_default_184);  t_default_146 = view_default_184 = None
        t_default_147 = torch.ops.aten.t.default(mm_default_98);  mm_default_98 = None
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(view_default_250, [0], True);  view_default_250 = None
        view_default_251 = torch.ops.aten.view.default(sum_dim_int_list_3, [2048]);  sum_dim_int_list_3 = None
        t_default_148 = torch.ops.aten.t.default(t_default_147);  t_default_147 = None
        view_default_252 = torch.ops.aten.view.default(mm_default_97, [256, 31, 512]);  mm_default_97 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(clone_default_83, view_default_252);  clone_default_83 = view_default_252 = None
        native_layer_norm_backward_default_4 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_8, add__tensor_25, [512], getitem_82, getitem_83, primals_77, primals_76, [True, True, True]);  add_tensor_8 = add__tensor_25 = getitem_82 = getitem_83 = primals_77 = primals_76 = None
        getitem_108 = native_layer_norm_backward_default_4[0]
        getitem_109 = native_layer_norm_backward_default_4[1]
        getitem_110 = native_layer_norm_backward_default_4[2];  native_layer_norm_backward_default_4 = None
        view_default_253 = torch.ops.aten.view.default(getitem_108, [7936, 512])
        t_default_149 = torch.ops.aten.t.default(view_default_253)
        mm_default_99 = torch.ops.aten.mm.default(t_default_149, view_default_183);  t_default_149 = view_default_183 = None
        t_default_150 = torch.ops.aten.t.default(mm_default_99);  mm_default_99 = None
        t_default_151 = torch.ops.aten.t.default(t_default_83);  t_default_83 = None
        mm_default_100 = torch.ops.aten.mm.default(view_default_253, t_default_151);  view_default_253 = t_default_151 = None
        view_default_254 = torch.ops.aten.view.default(mm_default_100, [256, 31, 512]);  mm_default_100 = None
        t_default_152 = torch.ops.aten.t.default(t_default_150);  t_default_150 = None
        view_default_255 = torch.ops.aten.view.default(view_default_254, [256, 31, 8, 64]);  view_default_254 = None
        transpose_int_108 = torch.ops.aten.transpose.int(view_default_255, 1, 2);  view_default_255 = None
        clone_default_84 = torch.ops.aten.clone.default(transpose_int_108, memory_format = torch.contiguous_format);  transpose_int_108 = None
        _unsafe_view_default_171 = torch.ops.aten._unsafe_view.default(clone_default_84, [2048, 31, 64]);  clone_default_84 = None
        transpose_int_109 = torch.ops.aten.transpose.int(view_default_181, 1, 2);  view_default_181 = None
        bmm_default_44 = torch.ops.aten.bmm.default(transpose_int_109, _unsafe_view_default_171);  transpose_int_109 = None
        transpose_int_110 = torch.ops.aten.transpose.int(_unsafe_view_default_141, 1, 2);  _unsafe_view_default_141 = None
        bmm_default_45 = torch.ops.aten.bmm.default(_unsafe_view_default_171, transpose_int_110);  _unsafe_view_default_171 = transpose_int_110 = None
        view_default_256 = torch.ops.aten.view.default(bmm_default_44, [256, 8, 33, 64]);  bmm_default_44 = None
        view_default_257 = torch.ops.aten.view.default(bmm_default_45, [256, 8, 31, 33]);  bmm_default_45 = None
        _softmax_backward_data_default_2 = torch.ops.aten._softmax_backward_data.default(view_default_257, _softmax_default_15, -1, torch.float32);  view_default_257 = _softmax_default_15 = None
        where_scalar_self_20 = torch.ops.aten.where.ScalarSelf(eq_scalar_15, 0.0, _softmax_backward_data_default_2);  eq_scalar_15 = _softmax_backward_data_default_2 = None
        view_default_258 = torch.ops.aten.view.default(where_scalar_self_20, [2048, 31, 33]);  where_scalar_self_20 = None
        transpose_int_111 = torch.ops.aten.transpose.int(_unsafe_view_default_138, 1, 2);  _unsafe_view_default_138 = None
        bmm_default_46 = torch.ops.aten.bmm.default(transpose_int_111, view_default_258);  transpose_int_111 = None
        transpose_int_112 = torch.ops.aten.transpose.int(_unsafe_view_default_139, 1, 2);  _unsafe_view_default_139 = None
        bmm_default_47 = torch.ops.aten.bmm.default(view_default_258, transpose_int_112);  view_default_258 = transpose_int_112 = None
        view_default_259 = torch.ops.aten.view.default(bmm_default_46, [256, 8, 64, 33]);  bmm_default_46 = None
        view_default_260 = torch.ops.aten.view.default(bmm_default_47, [256, 8, 31, 64]);  bmm_default_47 = None
        transpose_int_113 = torch.ops.aten.transpose.int(view_default_259, 2, 3);  view_default_259 = None
        div_tensor_20 = torch.ops.aten.div.Tensor(view_default_260, 8.0);  view_default_260 = None
        transpose_int_114 = torch.ops.aten.transpose.int(view_default_256, 1, 2);  view_default_256 = None
        transpose_int_115 = torch.ops.aten.transpose.int(transpose_int_113, 1, 2);  transpose_int_113 = None
        transpose_int_116 = torch.ops.aten.transpose.int(div_tensor_20, 1, 2);  div_tensor_20 = None
        clone_default_85 = torch.ops.aten.clone.default(transpose_int_114, memory_format = torch.contiguous_format);  transpose_int_114 = None
        _unsafe_view_default_172 = torch.ops.aten._unsafe_view.default(clone_default_85, [256, 33, 512]);  clone_default_85 = None
        view_default_261 = torch.ops.aten.view.default(_unsafe_view_default_172, [8448, 512]);  _unsafe_view_default_172 = None
        t_default_153 = torch.ops.aten.t.default(view_default_261)
        mm_default_101 = torch.ops.aten.mm.default(t_default_153, view_default_179);  t_default_153 = view_default_179 = None
        t_default_154 = torch.ops.aten.t.default(mm_default_101);  mm_default_101 = None
        t_default_155 = torch.ops.aten.t.default(t_default_82);  t_default_82 = None
        mm_default_102 = torch.ops.aten.mm.default(view_default_261, t_default_155);  view_default_261 = t_default_155 = None
        view_default_262 = torch.ops.aten.view.default(mm_default_102, [256, 33, 512]);  mm_default_102 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(add_tensor_3, view_default_262);  add_tensor_3 = view_default_262 = None
        t_default_156 = torch.ops.aten.t.default(t_default_154);  t_default_154 = None
        view_default_263 = torch.ops.aten.view.default(transpose_int_115, [256, 33, 512]);  transpose_int_115 = None
        clone_default_86 = torch.ops.aten.clone.default(view_default_263, memory_format = torch.contiguous_format);  view_default_263 = None
        _unsafe_view_default_173 = torch.ops.aten._unsafe_view.default(clone_default_86, [8448, 512]);  clone_default_86 = None
        t_default_157 = torch.ops.aten.t.default(_unsafe_view_default_173)
        mm_default_103 = torch.ops.aten.mm.default(t_default_157, view_default_177);  t_default_157 = view_default_177 = None
        t_default_158 = torch.ops.aten.t.default(mm_default_103);  mm_default_103 = None
        t_default_159 = torch.ops.aten.t.default(t_default_81);  t_default_81 = None
        mm_default_104 = torch.ops.aten.mm.default(_unsafe_view_default_173, t_default_159);  _unsafe_view_default_173 = t_default_159 = None
        view_default_264 = torch.ops.aten.view.default(mm_default_104, [256, 33, 512]);  mm_default_104 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(add_tensor_9, view_default_264);  add_tensor_9 = view_default_264 = None
        t_default_160 = torch.ops.aten.t.default(t_default_158);  t_default_158 = None
        clone_default_87 = torch.ops.aten.clone.default(transpose_int_116, memory_format = torch.contiguous_format);  transpose_int_116 = None
        _unsafe_view_default_174 = torch.ops.aten._unsafe_view.default(clone_default_87, [256, 31, 512]);  clone_default_87 = None
        view_default_265 = torch.ops.aten.view.default(_unsafe_view_default_174, [7936, 512]);  _unsafe_view_default_174 = None
        t_default_161 = torch.ops.aten.t.default(view_default_265)
        mm_default_105 = torch.ops.aten.mm.default(t_default_161, view_default_175);  t_default_161 = view_default_175 = None
        t_default_162 = torch.ops.aten.t.default(mm_default_105);  mm_default_105 = None
        t_default_163 = torch.ops.aten.t.default(t_default_80);  t_default_80 = None
        mm_default_106 = torch.ops.aten.mm.default(view_default_265, t_default_163);  view_default_265 = t_default_163 = None
        view_default_266 = torch.ops.aten.view.default(mm_default_106, [256, 31, 512]);  mm_default_106 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(getitem_108, view_default_266);  getitem_108 = view_default_266 = None
        t_default_164 = torch.ops.aten.t.default(t_default_162);  t_default_162 = None
        native_layer_norm_backward_default_5 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_11, add__tensor_24, [512], getitem_79, getitem_80, primals_89, primals_88, [True, True, True]);  add_tensor_11 = add__tensor_24 = getitem_79 = getitem_80 = primals_89 = primals_88 = None
        getitem_111 = native_layer_norm_backward_default_5[0]
        getitem_112 = native_layer_norm_backward_default_5[1]
        getitem_113 = native_layer_norm_backward_default_5[2];  native_layer_norm_backward_default_5 = None
        view_default_267 = torch.ops.aten.view.default(getitem_111, [7936, 512])
        t_default_165 = torch.ops.aten.t.default(view_default_267)
        mm_default_107 = torch.ops.aten.mm.default(t_default_165, view_default_174);  t_default_165 = view_default_174 = None
        t_default_166 = torch.ops.aten.t.default(mm_default_107);  mm_default_107 = None
        t_default_167 = torch.ops.aten.t.default(t_default_79);  t_default_79 = None
        mm_default_108 = torch.ops.aten.mm.default(view_default_267, t_default_167);  view_default_267 = t_default_167 = None
        view_default_268 = torch.ops.aten.view.default(mm_default_108, [256, 31, 512]);  mm_default_108 = None
        t_default_168 = torch.ops.aten.t.default(t_default_166);  t_default_166 = None
        view_default_269 = torch.ops.aten.view.default(view_default_268, [256, 31, 8, 64]);  view_default_268 = None
        transpose_int_117 = torch.ops.aten.transpose.int(view_default_269, 1, 2);  view_default_269 = None
        clone_default_88 = torch.ops.aten.clone.default(transpose_int_117, memory_format = torch.contiguous_format);  transpose_int_117 = None
        _unsafe_view_default_175 = torch.ops.aten._unsafe_view.default(clone_default_88, [2048, 31, 64]);  clone_default_88 = None
        transpose_int_118 = torch.ops.aten.transpose.int(view_default_172, 1, 2);  view_default_172 = None
        bmm_default_48 = torch.ops.aten.bmm.default(transpose_int_118, _unsafe_view_default_175);  transpose_int_118 = None
        transpose_int_119 = torch.ops.aten.transpose.int(_unsafe_view_default_132, 1, 2);  _unsafe_view_default_132 = None
        bmm_default_49 = torch.ops.aten.bmm.default(_unsafe_view_default_175, transpose_int_119);  _unsafe_view_default_175 = transpose_int_119 = None
        view_default_270 = torch.ops.aten.view.default(bmm_default_48, [256, 8, 31, 64]);  bmm_default_48 = None
        view_default_271 = torch.ops.aten.view.default(bmm_default_49, [256, 8, 31, 31]);  bmm_default_49 = None
        _softmax_backward_data_default_3 = torch.ops.aten._softmax_backward_data.default(view_default_271, _softmax_default_14, -1, torch.float32);  view_default_271 = _softmax_default_14 = None
        where_scalar_self_21 = torch.ops.aten.where.ScalarSelf(eq_scalar_14, 0.0, _softmax_backward_data_default_3);  eq_scalar_14 = _softmax_backward_data_default_3 = None
        view_default_272 = torch.ops.aten.view.default(where_scalar_self_21, [2048, 31, 31]);  where_scalar_self_21 = None
        transpose_int_120 = torch.ops.aten.transpose.int(_unsafe_view_default_129, 1, 2);  _unsafe_view_default_129 = None
        bmm_default_50 = torch.ops.aten.bmm.default(transpose_int_120, view_default_272);  transpose_int_120 = None
        transpose_int_121 = torch.ops.aten.transpose.int(_unsafe_view_default_130, 1, 2);  _unsafe_view_default_130 = None
        bmm_default_51 = torch.ops.aten.bmm.default(view_default_272, transpose_int_121);  view_default_272 = transpose_int_121 = None
        view_default_273 = torch.ops.aten.view.default(bmm_default_50, [256, 8, 64, 31]);  bmm_default_50 = None
        view_default_274 = torch.ops.aten.view.default(bmm_default_51, [256, 8, 31, 64]);  bmm_default_51 = None
        transpose_int_122 = torch.ops.aten.transpose.int(view_default_273, 2, 3);  view_default_273 = None
        div_tensor_21 = torch.ops.aten.div.Tensor(view_default_274, 8.0);  view_default_274 = None
        transpose_int_123 = torch.ops.aten.transpose.int(view_default_270, 1, 2);  view_default_270 = None
        transpose_int_124 = torch.ops.aten.transpose.int(transpose_int_122, 1, 2);  transpose_int_122 = None
        transpose_int_125 = torch.ops.aten.transpose.int(div_tensor_21, 1, 2);  div_tensor_21 = None
        clone_default_89 = torch.ops.aten.clone.default(transpose_int_123, memory_format = torch.contiguous_format);  transpose_int_123 = None
        _unsafe_view_default_176 = torch.ops.aten._unsafe_view.default(clone_default_89, [256, 31, 512]);  clone_default_89 = None
        view_default_275 = torch.ops.aten.view.default(_unsafe_view_default_176, [7936, 512]);  _unsafe_view_default_176 = None
        t_default_169 = torch.ops.aten.t.default(view_default_275)
        mm_default_109 = torch.ops.aten.mm.default(t_default_169, view_default_170);  t_default_169 = view_default_170 = None
        t_default_170 = torch.ops.aten.t.default(mm_default_109);  mm_default_109 = None
        t_default_171 = torch.ops.aten.t.default(t_default_78);  t_default_78 = None
        mm_default_110 = torch.ops.aten.mm.default(view_default_275, t_default_171);  view_default_275 = t_default_171 = None
        view_default_276 = torch.ops.aten.view.default(mm_default_110, [256, 31, 512]);  mm_default_110 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(getitem_111, view_default_276);  getitem_111 = view_default_276 = None
        t_default_172 = torch.ops.aten.t.default(t_default_170);  t_default_170 = None
        view_default_277 = torch.ops.aten.view.default(transpose_int_124, [256, 31, 512]);  transpose_int_124 = None
        clone_default_90 = torch.ops.aten.clone.default(view_default_277, memory_format = torch.contiguous_format);  view_default_277 = None
        _unsafe_view_default_177 = torch.ops.aten._unsafe_view.default(clone_default_90, [7936, 512]);  clone_default_90 = None
        t_default_173 = torch.ops.aten.t.default(_unsafe_view_default_177)
        mm_default_111 = torch.ops.aten.mm.default(t_default_173, view_default_168);  t_default_173 = view_default_168 = None
        t_default_174 = torch.ops.aten.t.default(mm_default_111);  mm_default_111 = None
        t_default_175 = torch.ops.aten.t.default(t_default_77);  t_default_77 = None
        mm_default_112 = torch.ops.aten.mm.default(_unsafe_view_default_177, t_default_175);  _unsafe_view_default_177 = t_default_175 = None
        view_default_278 = torch.ops.aten.view.default(mm_default_112, [256, 31, 512]);  mm_default_112 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(add_tensor_12, view_default_278);  add_tensor_12 = view_default_278 = None
        t_default_176 = torch.ops.aten.t.default(t_default_174);  t_default_174 = None
        clone_default_91 = torch.ops.aten.clone.default(transpose_int_125, memory_format = torch.contiguous_format);  transpose_int_125 = None
        _unsafe_view_default_178 = torch.ops.aten._unsafe_view.default(clone_default_91, [256, 31, 512]);  clone_default_91 = None
        view_default_279 = torch.ops.aten.view.default(_unsafe_view_default_178, [7936, 512]);  _unsafe_view_default_178 = None
        t_default_177 = torch.ops.aten.t.default(view_default_279)
        mm_default_113 = torch.ops.aten.mm.default(t_default_177, view_default_166);  t_default_177 = view_default_166 = None
        t_default_178 = torch.ops.aten.t.default(mm_default_113);  mm_default_113 = None
        t_default_179 = torch.ops.aten.t.default(t_default_76);  t_default_76 = None
        mm_default_114 = torch.ops.aten.mm.default(view_default_279, t_default_179);  view_default_279 = t_default_179 = None
        view_default_280 = torch.ops.aten.view.default(mm_default_114, [256, 31, 512]);  mm_default_114 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(add_tensor_13, view_default_280);  add_tensor_13 = view_default_280 = None
        t_default_180 = torch.ops.aten.t.default(t_default_178);  t_default_178 = None
        native_layer_norm_backward_default_6 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_14, add__tensor_23, [512], getitem_76, getitem_77, primals_64, primals_63, [True, True, True]);  add_tensor_14 = add__tensor_23 = getitem_76 = getitem_77 = primals_64 = primals_63 = None
        getitem_114 = native_layer_norm_backward_default_6[0]
        getitem_115 = native_layer_norm_backward_default_6[1]
        getitem_116 = native_layer_norm_backward_default_6[2];  native_layer_norm_backward_default_6 = None
        new_empty_default_2 = torch.ops.aten.new_empty.default(getitem_114, [4063232])
        zero__default_2 = torch.ops.aten.zero_.default(new_empty_default_2);  new_empty_default_2 = None
        as_strided_default_6 = torch.ops.aten.as_strided.default(zero__default_2, [256, 31, 512], [15872, 512, 1], 0)
        copy__default_6 = torch.ops.aten.copy_.default(as_strided_default_6, getitem_114);  as_strided_default_6 = getitem_114 = None
        as_strided_default_7 = torch.ops.aten.as_strided.default(zero__default_2, [7936, 512], [512, 1], 0);  zero__default_2 = None
        new_empty_strided_default_2 = torch.ops.aten.new_empty_strided.default(as_strided_default_7, [7936, 512], [512, 1])
        copy__default_7 = torch.ops.aten.copy_.default(new_empty_strided_default_2, as_strided_default_7);  new_empty_strided_default_2 = as_strided_default_7 = None
        as_strided_default_8 = torch.ops.aten.as_strided.default(copy__default_7, [256, 31, 512], [15872, 512, 1], 0)
        clone_default_92 = torch.ops.aten.clone.default(as_strided_default_8, memory_format = torch.contiguous_format)
        copy__default_8 = torch.ops.aten.copy_.default(as_strided_default_8, clone_default_92);  as_strided_default_8 = None
        t_default_181 = torch.ops.aten.t.default(t_default_75);  t_default_75 = None
        mm_default_115 = torch.ops.aten.mm.default(copy__default_7, t_default_181);  t_default_181 = None
        t_default_182 = torch.ops.aten.t.default(copy__default_7)
        mm_default_116 = torch.ops.aten.mm.default(t_default_182, view_default_164);  t_default_182 = view_default_164 = None
        t_default_183 = torch.ops.aten.t.default(mm_default_116);  mm_default_116 = None
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(copy__default_7, [0], True);  copy__default_7 = None
        view_default_281 = torch.ops.aten.view.default(sum_dim_int_list_4, [512]);  sum_dim_int_list_4 = None
        t_default_184 = torch.ops.aten.t.default(t_default_183);  t_default_183 = None
        view_default_282 = torch.ops.aten.view.default(mm_default_115, [256, 31, 2048]);  mm_default_115 = None
        to_dtype_6 = torch.ops.aten.to.dtype(view_default_282, torch.float32);  view_default_282 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu_default_9, torch.float32);  relu_default_9 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_2 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_2, to_dtype_6);  le_scalar_2 = new_zeros_default_2 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        view_default_283 = torch.ops.aten.view.default(to_dtype_8, [7936, 2048]);  to_dtype_8 = None
        t_default_185 = torch.ops.aten.t.default(t_default_74);  t_default_74 = None
        mm_default_117 = torch.ops.aten.mm.default(view_default_283, t_default_185);  t_default_185 = None
        t_default_186 = torch.ops.aten.t.default(view_default_283)
        mm_default_118 = torch.ops.aten.mm.default(t_default_186, view_default_162);  t_default_186 = view_default_162 = None
        t_default_187 = torch.ops.aten.t.default(mm_default_118);  mm_default_118 = None
        sum_dim_int_list_5 = torch.ops.aten.sum.dim_IntList(view_default_283, [0], True);  view_default_283 = None
        view_default_284 = torch.ops.aten.view.default(sum_dim_int_list_5, [2048]);  sum_dim_int_list_5 = None
        t_default_188 = torch.ops.aten.t.default(t_default_187);  t_default_187 = None
        view_default_285 = torch.ops.aten.view.default(mm_default_117, [256, 31, 512]);  mm_default_117 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(clone_default_92, view_default_285);  clone_default_92 = view_default_285 = None
        native_layer_norm_backward_default_7 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_15, add__tensor_22, [512], getitem_73, getitem_74, primals_59, primals_58, [True, True, True]);  add_tensor_15 = add__tensor_22 = getitem_73 = getitem_74 = primals_59 = primals_58 = None
        getitem_117 = native_layer_norm_backward_default_7[0]
        getitem_118 = native_layer_norm_backward_default_7[1]
        getitem_119 = native_layer_norm_backward_default_7[2];  native_layer_norm_backward_default_7 = None
        view_default_286 = torch.ops.aten.view.default(getitem_117, [7936, 512])
        t_default_189 = torch.ops.aten.t.default(view_default_286)
        mm_default_119 = torch.ops.aten.mm.default(t_default_189, view_default_161);  t_default_189 = view_default_161 = None
        t_default_190 = torch.ops.aten.t.default(mm_default_119);  mm_default_119 = None
        t_default_191 = torch.ops.aten.t.default(t_default_73);  t_default_73 = None
        mm_default_120 = torch.ops.aten.mm.default(view_default_286, t_default_191);  view_default_286 = t_default_191 = None
        view_default_287 = torch.ops.aten.view.default(mm_default_120, [256, 31, 512]);  mm_default_120 = None
        t_default_192 = torch.ops.aten.t.default(t_default_190);  t_default_190 = None
        view_default_288 = torch.ops.aten.view.default(view_default_287, [256, 31, 8, 64]);  view_default_287 = None
        transpose_int_126 = torch.ops.aten.transpose.int(view_default_288, 1, 2);  view_default_288 = None
        clone_default_93 = torch.ops.aten.clone.default(transpose_int_126, memory_format = torch.contiguous_format);  transpose_int_126 = None
        _unsafe_view_default_179 = torch.ops.aten._unsafe_view.default(clone_default_93, [2048, 31, 64]);  clone_default_93 = None
        transpose_int_127 = torch.ops.aten.transpose.int(view_default_159, 1, 2);  view_default_159 = None
        bmm_default_52 = torch.ops.aten.bmm.default(transpose_int_127, _unsafe_view_default_179);  transpose_int_127 = None
        transpose_int_128 = torch.ops.aten.transpose.int(_unsafe_view_default_123, 1, 2);  _unsafe_view_default_123 = None
        bmm_default_53 = torch.ops.aten.bmm.default(_unsafe_view_default_179, transpose_int_128);  _unsafe_view_default_179 = transpose_int_128 = None
        view_default_289 = torch.ops.aten.view.default(bmm_default_52, [256, 8, 33, 64]);  bmm_default_52 = None
        view_default_290 = torch.ops.aten.view.default(bmm_default_53, [256, 8, 31, 33]);  bmm_default_53 = None
        _softmax_backward_data_default_4 = torch.ops.aten._softmax_backward_data.default(view_default_290, _softmax_default_13, -1, torch.float32);  view_default_290 = _softmax_default_13 = None
        where_scalar_self_22 = torch.ops.aten.where.ScalarSelf(eq_scalar_13, 0.0, _softmax_backward_data_default_4);  eq_scalar_13 = _softmax_backward_data_default_4 = None
        view_default_291 = torch.ops.aten.view.default(where_scalar_self_22, [2048, 31, 33]);  where_scalar_self_22 = None
        transpose_int_129 = torch.ops.aten.transpose.int(_unsafe_view_default_120, 1, 2);  _unsafe_view_default_120 = None
        bmm_default_54 = torch.ops.aten.bmm.default(transpose_int_129, view_default_291);  transpose_int_129 = None
        transpose_int_130 = torch.ops.aten.transpose.int(_unsafe_view_default_121, 1, 2);  _unsafe_view_default_121 = None
        bmm_default_55 = torch.ops.aten.bmm.default(view_default_291, transpose_int_130);  view_default_291 = transpose_int_130 = None
        view_default_292 = torch.ops.aten.view.default(bmm_default_54, [256, 8, 64, 33]);  bmm_default_54 = None
        view_default_293 = torch.ops.aten.view.default(bmm_default_55, [256, 8, 31, 64]);  bmm_default_55 = None
        transpose_int_131 = torch.ops.aten.transpose.int(view_default_292, 2, 3);  view_default_292 = None
        div_tensor_22 = torch.ops.aten.div.Tensor(view_default_293, 8.0);  view_default_293 = None
        transpose_int_132 = torch.ops.aten.transpose.int(view_default_289, 1, 2);  view_default_289 = None
        transpose_int_133 = torch.ops.aten.transpose.int(transpose_int_131, 1, 2);  transpose_int_131 = None
        transpose_int_134 = torch.ops.aten.transpose.int(div_tensor_22, 1, 2);  div_tensor_22 = None
        clone_default_94 = torch.ops.aten.clone.default(transpose_int_132, memory_format = torch.contiguous_format);  transpose_int_132 = None
        _unsafe_view_default_180 = torch.ops.aten._unsafe_view.default(clone_default_94, [256, 33, 512]);  clone_default_94 = None
        view_default_294 = torch.ops.aten.view.default(_unsafe_view_default_180, [8448, 512]);  _unsafe_view_default_180 = None
        t_default_193 = torch.ops.aten.t.default(view_default_294)
        mm_default_121 = torch.ops.aten.mm.default(t_default_193, view_default_157);  t_default_193 = view_default_157 = None
        t_default_194 = torch.ops.aten.t.default(mm_default_121);  mm_default_121 = None
        t_default_195 = torch.ops.aten.t.default(t_default_72);  t_default_72 = None
        mm_default_122 = torch.ops.aten.mm.default(view_default_294, t_default_195);  view_default_294 = t_default_195 = None
        view_default_295 = torch.ops.aten.view.default(mm_default_122, [256, 33, 512]);  mm_default_122 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(add_tensor_10, view_default_295);  add_tensor_10 = view_default_295 = None
        t_default_196 = torch.ops.aten.t.default(t_default_194);  t_default_194 = None
        view_default_296 = torch.ops.aten.view.default(transpose_int_133, [256, 33, 512]);  transpose_int_133 = None
        clone_default_95 = torch.ops.aten.clone.default(view_default_296, memory_format = torch.contiguous_format);  view_default_296 = None
        _unsafe_view_default_181 = torch.ops.aten._unsafe_view.default(clone_default_95, [8448, 512]);  clone_default_95 = None
        t_default_197 = torch.ops.aten.t.default(_unsafe_view_default_181)
        mm_default_123 = torch.ops.aten.mm.default(t_default_197, view_default_155);  t_default_197 = view_default_155 = None
        t_default_198 = torch.ops.aten.t.default(mm_default_123);  mm_default_123 = None
        t_default_199 = torch.ops.aten.t.default(t_default_71);  t_default_71 = None
        mm_default_124 = torch.ops.aten.mm.default(_unsafe_view_default_181, t_default_199);  _unsafe_view_default_181 = t_default_199 = None
        view_default_297 = torch.ops.aten.view.default(mm_default_124, [256, 33, 512]);  mm_default_124 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(add_tensor_16, view_default_297);  add_tensor_16 = view_default_297 = None
        t_default_200 = torch.ops.aten.t.default(t_default_198);  t_default_198 = None
        clone_default_96 = torch.ops.aten.clone.default(transpose_int_134, memory_format = torch.contiguous_format);  transpose_int_134 = None
        _unsafe_view_default_182 = torch.ops.aten._unsafe_view.default(clone_default_96, [256, 31, 512]);  clone_default_96 = None
        view_default_298 = torch.ops.aten.view.default(_unsafe_view_default_182, [7936, 512]);  _unsafe_view_default_182 = None
        t_default_201 = torch.ops.aten.t.default(view_default_298)
        mm_default_125 = torch.ops.aten.mm.default(t_default_201, view_default_153);  t_default_201 = view_default_153 = None
        t_default_202 = torch.ops.aten.t.default(mm_default_125);  mm_default_125 = None
        t_default_203 = torch.ops.aten.t.default(t_default_70);  t_default_70 = None
        mm_default_126 = torch.ops.aten.mm.default(view_default_298, t_default_203);  view_default_298 = t_default_203 = None
        view_default_299 = torch.ops.aten.view.default(mm_default_126, [256, 31, 512]);  mm_default_126 = None
        add_tensor_18 = torch.ops.aten.add.Tensor(getitem_117, view_default_299);  getitem_117 = view_default_299 = None
        t_default_204 = torch.ops.aten.t.default(t_default_202);  t_default_202 = None
        native_layer_norm_backward_default_8 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_18, add__tensor_21, [512], getitem_70, getitem_71, primals_71, primals_70, [True, True, True]);  add_tensor_18 = add__tensor_21 = getitem_70 = getitem_71 = primals_71 = primals_70 = None
        getitem_120 = native_layer_norm_backward_default_8[0]
        getitem_121 = native_layer_norm_backward_default_8[1]
        getitem_122 = native_layer_norm_backward_default_8[2];  native_layer_norm_backward_default_8 = None
        view_default_300 = torch.ops.aten.view.default(getitem_120, [7936, 512])
        t_default_205 = torch.ops.aten.t.default(view_default_300)
        mm_default_127 = torch.ops.aten.mm.default(t_default_205, view_default_152);  t_default_205 = view_default_152 = None
        t_default_206 = torch.ops.aten.t.default(mm_default_127);  mm_default_127 = None
        t_default_207 = torch.ops.aten.t.default(t_default_69);  t_default_69 = None
        mm_default_128 = torch.ops.aten.mm.default(view_default_300, t_default_207);  view_default_300 = t_default_207 = None
        view_default_301 = torch.ops.aten.view.default(mm_default_128, [256, 31, 512]);  mm_default_128 = None
        t_default_208 = torch.ops.aten.t.default(t_default_206);  t_default_206 = None
        view_default_302 = torch.ops.aten.view.default(view_default_301, [256, 31, 8, 64]);  view_default_301 = None
        transpose_int_135 = torch.ops.aten.transpose.int(view_default_302, 1, 2);  view_default_302 = None
        clone_default_97 = torch.ops.aten.clone.default(transpose_int_135, memory_format = torch.contiguous_format);  transpose_int_135 = None
        _unsafe_view_default_183 = torch.ops.aten._unsafe_view.default(clone_default_97, [2048, 31, 64]);  clone_default_97 = None
        transpose_int_136 = torch.ops.aten.transpose.int(view_default_150, 1, 2);  view_default_150 = None
        bmm_default_56 = torch.ops.aten.bmm.default(transpose_int_136, _unsafe_view_default_183);  transpose_int_136 = None
        transpose_int_137 = torch.ops.aten.transpose.int(_unsafe_view_default_114, 1, 2);  _unsafe_view_default_114 = None
        bmm_default_57 = torch.ops.aten.bmm.default(_unsafe_view_default_183, transpose_int_137);  _unsafe_view_default_183 = transpose_int_137 = None
        view_default_303 = torch.ops.aten.view.default(bmm_default_56, [256, 8, 31, 64]);  bmm_default_56 = None
        view_default_304 = torch.ops.aten.view.default(bmm_default_57, [256, 8, 31, 31]);  bmm_default_57 = None
        _softmax_backward_data_default_5 = torch.ops.aten._softmax_backward_data.default(view_default_304, _softmax_default_12, -1, torch.float32);  view_default_304 = _softmax_default_12 = None
        where_scalar_self_23 = torch.ops.aten.where.ScalarSelf(eq_scalar_12, 0.0, _softmax_backward_data_default_5);  eq_scalar_12 = _softmax_backward_data_default_5 = None
        view_default_305 = torch.ops.aten.view.default(where_scalar_self_23, [2048, 31, 31]);  where_scalar_self_23 = None
        transpose_int_138 = torch.ops.aten.transpose.int(_unsafe_view_default_111, 1, 2);  _unsafe_view_default_111 = None
        bmm_default_58 = torch.ops.aten.bmm.default(transpose_int_138, view_default_305);  transpose_int_138 = None
        transpose_int_139 = torch.ops.aten.transpose.int(_unsafe_view_default_112, 1, 2);  _unsafe_view_default_112 = None
        bmm_default_59 = torch.ops.aten.bmm.default(view_default_305, transpose_int_139);  view_default_305 = transpose_int_139 = None
        view_default_306 = torch.ops.aten.view.default(bmm_default_58, [256, 8, 64, 31]);  bmm_default_58 = None
        view_default_307 = torch.ops.aten.view.default(bmm_default_59, [256, 8, 31, 64]);  bmm_default_59 = None
        transpose_int_140 = torch.ops.aten.transpose.int(view_default_306, 2, 3);  view_default_306 = None
        div_tensor_23 = torch.ops.aten.div.Tensor(view_default_307, 8.0);  view_default_307 = None
        transpose_int_141 = torch.ops.aten.transpose.int(view_default_303, 1, 2);  view_default_303 = None
        transpose_int_142 = torch.ops.aten.transpose.int(transpose_int_140, 1, 2);  transpose_int_140 = None
        transpose_int_143 = torch.ops.aten.transpose.int(div_tensor_23, 1, 2);  div_tensor_23 = None
        clone_default_98 = torch.ops.aten.clone.default(transpose_int_141, memory_format = torch.contiguous_format);  transpose_int_141 = None
        _unsafe_view_default_184 = torch.ops.aten._unsafe_view.default(clone_default_98, [256, 31, 512]);  clone_default_98 = None
        view_default_308 = torch.ops.aten.view.default(_unsafe_view_default_184, [7936, 512]);  _unsafe_view_default_184 = None
        t_default_209 = torch.ops.aten.t.default(view_default_308)
        mm_default_129 = torch.ops.aten.mm.default(t_default_209, view_default_148);  t_default_209 = view_default_148 = None
        t_default_210 = torch.ops.aten.t.default(mm_default_129);  mm_default_129 = None
        t_default_211 = torch.ops.aten.t.default(t_default_68);  t_default_68 = None
        mm_default_130 = torch.ops.aten.mm.default(view_default_308, t_default_211);  view_default_308 = t_default_211 = None
        view_default_309 = torch.ops.aten.view.default(mm_default_130, [256, 31, 512]);  mm_default_130 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(getitem_120, view_default_309);  getitem_120 = view_default_309 = None
        t_default_212 = torch.ops.aten.t.default(t_default_210);  t_default_210 = None
        view_default_310 = torch.ops.aten.view.default(transpose_int_142, [256, 31, 512]);  transpose_int_142 = None
        clone_default_99 = torch.ops.aten.clone.default(view_default_310, memory_format = torch.contiguous_format);  view_default_310 = None
        _unsafe_view_default_185 = torch.ops.aten._unsafe_view.default(clone_default_99, [7936, 512]);  clone_default_99 = None
        t_default_213 = torch.ops.aten.t.default(_unsafe_view_default_185)
        mm_default_131 = torch.ops.aten.mm.default(t_default_213, view_default_146);  t_default_213 = view_default_146 = None
        t_default_214 = torch.ops.aten.t.default(mm_default_131);  mm_default_131 = None
        t_default_215 = torch.ops.aten.t.default(t_default_67);  t_default_67 = None
        mm_default_132 = torch.ops.aten.mm.default(_unsafe_view_default_185, t_default_215);  _unsafe_view_default_185 = t_default_215 = None
        view_default_311 = torch.ops.aten.view.default(mm_default_132, [256, 31, 512]);  mm_default_132 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(add_tensor_19, view_default_311);  add_tensor_19 = view_default_311 = None
        t_default_216 = torch.ops.aten.t.default(t_default_214);  t_default_214 = None
        clone_default_100 = torch.ops.aten.clone.default(transpose_int_143, memory_format = torch.contiguous_format);  transpose_int_143 = None
        _unsafe_view_default_186 = torch.ops.aten._unsafe_view.default(clone_default_100, [256, 31, 512]);  clone_default_100 = None
        view_default_312 = torch.ops.aten.view.default(_unsafe_view_default_186, [7936, 512]);  _unsafe_view_default_186 = None
        t_default_217 = torch.ops.aten.t.default(view_default_312)
        mm_default_133 = torch.ops.aten.mm.default(t_default_217, view_default_144);  t_default_217 = view_default_144 = None
        t_default_218 = torch.ops.aten.t.default(mm_default_133);  mm_default_133 = None
        t_default_219 = torch.ops.aten.t.default(t_default_66);  t_default_66 = None
        mm_default_134 = torch.ops.aten.mm.default(view_default_312, t_default_219);  view_default_312 = t_default_219 = None
        view_default_313 = torch.ops.aten.view.default(mm_default_134, [256, 31, 512]);  mm_default_134 = None
        add_tensor_21 = torch.ops.aten.add.Tensor(add_tensor_20, view_default_313);  add_tensor_20 = view_default_313 = None
        t_default_220 = torch.ops.aten.t.default(t_default_218);  t_default_218 = None
        native_layer_norm_backward_default_9 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_21, add__tensor_20, [512], getitem_67, getitem_68, primals_46, primals_45, [True, True, True]);  add_tensor_21 = add__tensor_20 = getitem_67 = getitem_68 = primals_46 = primals_45 = None
        getitem_123 = native_layer_norm_backward_default_9[0]
        getitem_124 = native_layer_norm_backward_default_9[1]
        getitem_125 = native_layer_norm_backward_default_9[2];  native_layer_norm_backward_default_9 = None
        new_empty_default_3 = torch.ops.aten.new_empty.default(getitem_123, [4063232])
        zero__default_3 = torch.ops.aten.zero_.default(new_empty_default_3);  new_empty_default_3 = None
        as_strided_default_9 = torch.ops.aten.as_strided.default(zero__default_3, [256, 31, 512], [15872, 512, 1], 0)
        copy__default_9 = torch.ops.aten.copy_.default(as_strided_default_9, getitem_123);  as_strided_default_9 = getitem_123 = None
        as_strided_default_10 = torch.ops.aten.as_strided.default(zero__default_3, [7936, 512], [512, 1], 0);  zero__default_3 = None
        new_empty_strided_default_3 = torch.ops.aten.new_empty_strided.default(as_strided_default_10, [7936, 512], [512, 1])
        copy__default_10 = torch.ops.aten.copy_.default(new_empty_strided_default_3, as_strided_default_10);  new_empty_strided_default_3 = as_strided_default_10 = None
        as_strided_default_11 = torch.ops.aten.as_strided.default(copy__default_10, [256, 31, 512], [15872, 512, 1], 0)
        clone_default_101 = torch.ops.aten.clone.default(as_strided_default_11, memory_format = torch.contiguous_format)
        copy__default_11 = torch.ops.aten.copy_.default(as_strided_default_11, clone_default_101);  as_strided_default_11 = None
        t_default_221 = torch.ops.aten.t.default(t_default_65);  t_default_65 = None
        mm_default_135 = torch.ops.aten.mm.default(copy__default_10, t_default_221);  t_default_221 = None
        t_default_222 = torch.ops.aten.t.default(copy__default_10)
        mm_default_136 = torch.ops.aten.mm.default(t_default_222, view_default_142);  t_default_222 = view_default_142 = None
        t_default_223 = torch.ops.aten.t.default(mm_default_136);  mm_default_136 = None
        sum_dim_int_list_6 = torch.ops.aten.sum.dim_IntList(copy__default_10, [0], True);  copy__default_10 = None
        view_default_314 = torch.ops.aten.view.default(sum_dim_int_list_6, [512]);  sum_dim_int_list_6 = None
        t_default_224 = torch.ops.aten.t.default(t_default_223);  t_default_223 = None
        view_default_315 = torch.ops.aten.view.default(mm_default_135, [256, 31, 2048]);  mm_default_135 = None
        to_dtype_9 = torch.ops.aten.to.dtype(view_default_315, torch.float32);  view_default_315 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu_default_8, torch.float32);  relu_default_8 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_3, to_dtype_9);  le_scalar_3 = new_zeros_default_3 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        view_default_316 = torch.ops.aten.view.default(to_dtype_11, [7936, 2048]);  to_dtype_11 = None
        t_default_225 = torch.ops.aten.t.default(t_default_64);  t_default_64 = None
        mm_default_137 = torch.ops.aten.mm.default(view_default_316, t_default_225);  t_default_225 = None
        t_default_226 = torch.ops.aten.t.default(view_default_316)
        mm_default_138 = torch.ops.aten.mm.default(t_default_226, view_default_140);  t_default_226 = view_default_140 = None
        t_default_227 = torch.ops.aten.t.default(mm_default_138);  mm_default_138 = None
        sum_dim_int_list_7 = torch.ops.aten.sum.dim_IntList(view_default_316, [0], True);  view_default_316 = None
        view_default_317 = torch.ops.aten.view.default(sum_dim_int_list_7, [2048]);  sum_dim_int_list_7 = None
        t_default_228 = torch.ops.aten.t.default(t_default_227);  t_default_227 = None
        view_default_318 = torch.ops.aten.view.default(mm_default_137, [256, 31, 512]);  mm_default_137 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(clone_default_101, view_default_318);  clone_default_101 = view_default_318 = None
        native_layer_norm_backward_default_10 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_22, add__tensor_19, [512], getitem_64, getitem_65, primals_41, primals_40, [True, True, True]);  add_tensor_22 = add__tensor_19 = getitem_64 = getitem_65 = primals_41 = primals_40 = None
        getitem_126 = native_layer_norm_backward_default_10[0]
        getitem_127 = native_layer_norm_backward_default_10[1]
        getitem_128 = native_layer_norm_backward_default_10[2];  native_layer_norm_backward_default_10 = None
        view_default_319 = torch.ops.aten.view.default(getitem_126, [7936, 512])
        t_default_229 = torch.ops.aten.t.default(view_default_319)
        mm_default_139 = torch.ops.aten.mm.default(t_default_229, view_default_139);  t_default_229 = view_default_139 = None
        t_default_230 = torch.ops.aten.t.default(mm_default_139);  mm_default_139 = None
        t_default_231 = torch.ops.aten.t.default(t_default_63);  t_default_63 = None
        mm_default_140 = torch.ops.aten.mm.default(view_default_319, t_default_231);  view_default_319 = t_default_231 = None
        view_default_320 = torch.ops.aten.view.default(mm_default_140, [256, 31, 512]);  mm_default_140 = None
        t_default_232 = torch.ops.aten.t.default(t_default_230);  t_default_230 = None
        view_default_321 = torch.ops.aten.view.default(view_default_320, [256, 31, 8, 64]);  view_default_320 = None
        transpose_int_144 = torch.ops.aten.transpose.int(view_default_321, 1, 2);  view_default_321 = None
        clone_default_102 = torch.ops.aten.clone.default(transpose_int_144, memory_format = torch.contiguous_format);  transpose_int_144 = None
        _unsafe_view_default_187 = torch.ops.aten._unsafe_view.default(clone_default_102, [2048, 31, 64]);  clone_default_102 = None
        transpose_int_145 = torch.ops.aten.transpose.int(view_default_137, 1, 2);  view_default_137 = None
        bmm_default_60 = torch.ops.aten.bmm.default(transpose_int_145, _unsafe_view_default_187);  transpose_int_145 = None
        transpose_int_146 = torch.ops.aten.transpose.int(_unsafe_view_default_105, 1, 2);  _unsafe_view_default_105 = None
        bmm_default_61 = torch.ops.aten.bmm.default(_unsafe_view_default_187, transpose_int_146);  _unsafe_view_default_187 = transpose_int_146 = None
        view_default_322 = torch.ops.aten.view.default(bmm_default_60, [256, 8, 33, 64]);  bmm_default_60 = None
        view_default_323 = torch.ops.aten.view.default(bmm_default_61, [256, 8, 31, 33]);  bmm_default_61 = None
        _softmax_backward_data_default_6 = torch.ops.aten._softmax_backward_data.default(view_default_323, _softmax_default_11, -1, torch.float32);  view_default_323 = _softmax_default_11 = None
        where_scalar_self_24 = torch.ops.aten.where.ScalarSelf(eq_scalar_11, 0.0, _softmax_backward_data_default_6);  eq_scalar_11 = _softmax_backward_data_default_6 = None
        view_default_324 = torch.ops.aten.view.default(where_scalar_self_24, [2048, 31, 33]);  where_scalar_self_24 = None
        transpose_int_147 = torch.ops.aten.transpose.int(_unsafe_view_default_102, 1, 2);  _unsafe_view_default_102 = None
        bmm_default_62 = torch.ops.aten.bmm.default(transpose_int_147, view_default_324);  transpose_int_147 = None
        transpose_int_148 = torch.ops.aten.transpose.int(_unsafe_view_default_103, 1, 2);  _unsafe_view_default_103 = None
        bmm_default_63 = torch.ops.aten.bmm.default(view_default_324, transpose_int_148);  view_default_324 = transpose_int_148 = None
        view_default_325 = torch.ops.aten.view.default(bmm_default_62, [256, 8, 64, 33]);  bmm_default_62 = None
        view_default_326 = torch.ops.aten.view.default(bmm_default_63, [256, 8, 31, 64]);  bmm_default_63 = None
        transpose_int_149 = torch.ops.aten.transpose.int(view_default_325, 2, 3);  view_default_325 = None
        div_tensor_24 = torch.ops.aten.div.Tensor(view_default_326, 8.0);  view_default_326 = None
        transpose_int_150 = torch.ops.aten.transpose.int(view_default_322, 1, 2);  view_default_322 = None
        transpose_int_151 = torch.ops.aten.transpose.int(transpose_int_149, 1, 2);  transpose_int_149 = None
        transpose_int_152 = torch.ops.aten.transpose.int(div_tensor_24, 1, 2);  div_tensor_24 = None
        clone_default_103 = torch.ops.aten.clone.default(transpose_int_150, memory_format = torch.contiguous_format);  transpose_int_150 = None
        _unsafe_view_default_188 = torch.ops.aten._unsafe_view.default(clone_default_103, [256, 33, 512]);  clone_default_103 = None
        view_default_327 = torch.ops.aten.view.default(_unsafe_view_default_188, [8448, 512]);  _unsafe_view_default_188 = None
        t_default_233 = torch.ops.aten.t.default(view_default_327)
        mm_default_141 = torch.ops.aten.mm.default(t_default_233, view_default_135);  t_default_233 = view_default_135 = None
        t_default_234 = torch.ops.aten.t.default(mm_default_141);  mm_default_141 = None
        t_default_235 = torch.ops.aten.t.default(t_default_62);  t_default_62 = None
        mm_default_142 = torch.ops.aten.mm.default(view_default_327, t_default_235);  view_default_327 = t_default_235 = None
        view_default_328 = torch.ops.aten.view.default(mm_default_142, [256, 33, 512]);  mm_default_142 = None
        add_tensor_23 = torch.ops.aten.add.Tensor(add_tensor_17, view_default_328);  add_tensor_17 = view_default_328 = None
        t_default_236 = torch.ops.aten.t.default(t_default_234);  t_default_234 = None
        view_default_329 = torch.ops.aten.view.default(transpose_int_151, [256, 33, 512]);  transpose_int_151 = None
        clone_default_104 = torch.ops.aten.clone.default(view_default_329, memory_format = torch.contiguous_format);  view_default_329 = None
        _unsafe_view_default_189 = torch.ops.aten._unsafe_view.default(clone_default_104, [8448, 512]);  clone_default_104 = None
        t_default_237 = torch.ops.aten.t.default(_unsafe_view_default_189)
        mm_default_143 = torch.ops.aten.mm.default(t_default_237, view_default_133);  t_default_237 = view_default_133 = None
        t_default_238 = torch.ops.aten.t.default(mm_default_143);  mm_default_143 = None
        t_default_239 = torch.ops.aten.t.default(t_default_61);  t_default_61 = None
        mm_default_144 = torch.ops.aten.mm.default(_unsafe_view_default_189, t_default_239);  _unsafe_view_default_189 = t_default_239 = None
        view_default_330 = torch.ops.aten.view.default(mm_default_144, [256, 33, 512]);  mm_default_144 = None
        add_tensor_24 = torch.ops.aten.add.Tensor(add_tensor_23, view_default_330);  add_tensor_23 = view_default_330 = None
        t_default_240 = torch.ops.aten.t.default(t_default_238);  t_default_238 = None
        clone_default_105 = torch.ops.aten.clone.default(transpose_int_152, memory_format = torch.contiguous_format);  transpose_int_152 = None
        _unsafe_view_default_190 = torch.ops.aten._unsafe_view.default(clone_default_105, [256, 31, 512]);  clone_default_105 = None
        view_default_331 = torch.ops.aten.view.default(_unsafe_view_default_190, [7936, 512]);  _unsafe_view_default_190 = None
        t_default_241 = torch.ops.aten.t.default(view_default_331)
        mm_default_145 = torch.ops.aten.mm.default(t_default_241, view_default_131);  t_default_241 = view_default_131 = None
        t_default_242 = torch.ops.aten.t.default(mm_default_145);  mm_default_145 = None
        t_default_243 = torch.ops.aten.t.default(t_default_60);  t_default_60 = None
        mm_default_146 = torch.ops.aten.mm.default(view_default_331, t_default_243);  view_default_331 = t_default_243 = None
        view_default_332 = torch.ops.aten.view.default(mm_default_146, [256, 31, 512]);  mm_default_146 = None
        add_tensor_25 = torch.ops.aten.add.Tensor(getitem_126, view_default_332);  getitem_126 = view_default_332 = None
        t_default_244 = torch.ops.aten.t.default(t_default_242);  t_default_242 = None
        native_layer_norm_backward_default_11 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_25, add__tensor_18, [512], getitem_61, getitem_62, primals_53, primals_52, [True, True, True]);  add_tensor_25 = add__tensor_18 = getitem_61 = getitem_62 = primals_53 = primals_52 = None
        getitem_129 = native_layer_norm_backward_default_11[0]
        getitem_130 = native_layer_norm_backward_default_11[1]
        getitem_131 = native_layer_norm_backward_default_11[2];  native_layer_norm_backward_default_11 = None
        view_default_333 = torch.ops.aten.view.default(getitem_129, [7936, 512])
        t_default_245 = torch.ops.aten.t.default(view_default_333)
        mm_default_147 = torch.ops.aten.mm.default(t_default_245, view_default_130);  t_default_245 = view_default_130 = None
        t_default_246 = torch.ops.aten.t.default(mm_default_147);  mm_default_147 = None
        t_default_247 = torch.ops.aten.t.default(t_default_59);  t_default_59 = None
        mm_default_148 = torch.ops.aten.mm.default(view_default_333, t_default_247);  view_default_333 = t_default_247 = None
        view_default_334 = torch.ops.aten.view.default(mm_default_148, [256, 31, 512]);  mm_default_148 = None
        t_default_248 = torch.ops.aten.t.default(t_default_246);  t_default_246 = None
        view_default_335 = torch.ops.aten.view.default(view_default_334, [256, 31, 8, 64]);  view_default_334 = None
        transpose_int_153 = torch.ops.aten.transpose.int(view_default_335, 1, 2);  view_default_335 = None
        clone_default_106 = torch.ops.aten.clone.default(transpose_int_153, memory_format = torch.contiguous_format);  transpose_int_153 = None
        _unsafe_view_default_191 = torch.ops.aten._unsafe_view.default(clone_default_106, [2048, 31, 64]);  clone_default_106 = None
        transpose_int_154 = torch.ops.aten.transpose.int(view_default_128, 1, 2);  view_default_128 = None
        bmm_default_64 = torch.ops.aten.bmm.default(transpose_int_154, _unsafe_view_default_191);  transpose_int_154 = None
        transpose_int_155 = torch.ops.aten.transpose.int(_unsafe_view_default_96, 1, 2);  _unsafe_view_default_96 = None
        bmm_default_65 = torch.ops.aten.bmm.default(_unsafe_view_default_191, transpose_int_155);  _unsafe_view_default_191 = transpose_int_155 = None
        view_default_336 = torch.ops.aten.view.default(bmm_default_64, [256, 8, 31, 64]);  bmm_default_64 = None
        view_default_337 = torch.ops.aten.view.default(bmm_default_65, [256, 8, 31, 31]);  bmm_default_65 = None
        _softmax_backward_data_default_7 = torch.ops.aten._softmax_backward_data.default(view_default_337, _softmax_default_10, -1, torch.float32);  view_default_337 = _softmax_default_10 = None
        where_scalar_self_25 = torch.ops.aten.where.ScalarSelf(eq_scalar_10, 0.0, _softmax_backward_data_default_7);  eq_scalar_10 = _softmax_backward_data_default_7 = None
        view_default_338 = torch.ops.aten.view.default(where_scalar_self_25, [2048, 31, 31]);  where_scalar_self_25 = None
        transpose_int_156 = torch.ops.aten.transpose.int(_unsafe_view_default_93, 1, 2);  _unsafe_view_default_93 = None
        bmm_default_66 = torch.ops.aten.bmm.default(transpose_int_156, view_default_338);  transpose_int_156 = None
        transpose_int_157 = torch.ops.aten.transpose.int(_unsafe_view_default_94, 1, 2);  _unsafe_view_default_94 = None
        bmm_default_67 = torch.ops.aten.bmm.default(view_default_338, transpose_int_157);  view_default_338 = transpose_int_157 = None
        view_default_339 = torch.ops.aten.view.default(bmm_default_66, [256, 8, 64, 31]);  bmm_default_66 = None
        view_default_340 = torch.ops.aten.view.default(bmm_default_67, [256, 8, 31, 64]);  bmm_default_67 = None
        transpose_int_158 = torch.ops.aten.transpose.int(view_default_339, 2, 3);  view_default_339 = None
        div_tensor_25 = torch.ops.aten.div.Tensor(view_default_340, 8.0);  view_default_340 = None
        transpose_int_159 = torch.ops.aten.transpose.int(view_default_336, 1, 2);  view_default_336 = None
        transpose_int_160 = torch.ops.aten.transpose.int(transpose_int_158, 1, 2);  transpose_int_158 = None
        transpose_int_161 = torch.ops.aten.transpose.int(div_tensor_25, 1, 2);  div_tensor_25 = None
        clone_default_107 = torch.ops.aten.clone.default(transpose_int_159, memory_format = torch.contiguous_format);  transpose_int_159 = None
        _unsafe_view_default_192 = torch.ops.aten._unsafe_view.default(clone_default_107, [256, 31, 512]);  clone_default_107 = None
        view_default_341 = torch.ops.aten.view.default(_unsafe_view_default_192, [7936, 512]);  _unsafe_view_default_192 = None
        t_default_249 = torch.ops.aten.t.default(view_default_341)
        mm_default_149 = torch.ops.aten.mm.default(t_default_249, view_default_126);  t_default_249 = view_default_126 = None
        t_default_250 = torch.ops.aten.t.default(mm_default_149);  mm_default_149 = None
        t_default_251 = torch.ops.aten.t.default(t_default_58);  t_default_58 = None
        mm_default_150 = torch.ops.aten.mm.default(view_default_341, t_default_251);  view_default_341 = t_default_251 = None
        view_default_342 = torch.ops.aten.view.default(mm_default_150, [256, 31, 512]);  mm_default_150 = None
        add_tensor_26 = torch.ops.aten.add.Tensor(getitem_129, view_default_342);  getitem_129 = view_default_342 = None
        t_default_252 = torch.ops.aten.t.default(t_default_250);  t_default_250 = None
        view_default_343 = torch.ops.aten.view.default(transpose_int_160, [256, 31, 512]);  transpose_int_160 = None
        clone_default_108 = torch.ops.aten.clone.default(view_default_343, memory_format = torch.contiguous_format);  view_default_343 = None
        _unsafe_view_default_193 = torch.ops.aten._unsafe_view.default(clone_default_108, [7936, 512]);  clone_default_108 = None
        t_default_253 = torch.ops.aten.t.default(_unsafe_view_default_193)
        mm_default_151 = torch.ops.aten.mm.default(t_default_253, view_default_124);  t_default_253 = view_default_124 = None
        t_default_254 = torch.ops.aten.t.default(mm_default_151);  mm_default_151 = None
        t_default_255 = torch.ops.aten.t.default(t_default_57);  t_default_57 = None
        mm_default_152 = torch.ops.aten.mm.default(_unsafe_view_default_193, t_default_255);  _unsafe_view_default_193 = t_default_255 = None
        view_default_344 = torch.ops.aten.view.default(mm_default_152, [256, 31, 512]);  mm_default_152 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(add_tensor_26, view_default_344);  add_tensor_26 = view_default_344 = None
        t_default_256 = torch.ops.aten.t.default(t_default_254);  t_default_254 = None
        clone_default_109 = torch.ops.aten.clone.default(transpose_int_161, memory_format = torch.contiguous_format);  transpose_int_161 = None
        _unsafe_view_default_194 = torch.ops.aten._unsafe_view.default(clone_default_109, [256, 31, 512]);  clone_default_109 = None
        view_default_345 = torch.ops.aten.view.default(_unsafe_view_default_194, [7936, 512]);  _unsafe_view_default_194 = None
        t_default_257 = torch.ops.aten.t.default(view_default_345)
        mm_default_153 = torch.ops.aten.mm.default(t_default_257, view_default_122);  t_default_257 = view_default_122 = None
        t_default_258 = torch.ops.aten.t.default(mm_default_153);  mm_default_153 = None
        t_default_259 = torch.ops.aten.t.default(t_default_56);  t_default_56 = None
        mm_default_154 = torch.ops.aten.mm.default(view_default_345, t_default_259);  view_default_345 = t_default_259 = None
        view_default_346 = torch.ops.aten.view.default(mm_default_154, [256, 31, 512]);  mm_default_154 = None
        add_tensor_28 = torch.ops.aten.add.Tensor(add_tensor_27, view_default_346);  add_tensor_27 = view_default_346 = None
        t_default_260 = torch.ops.aten.t.default(t_default_258);  t_default_258 = None
        native_layer_norm_backward_default_12 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_28, add__tensor_17, [512], getitem_58, getitem_59, primals_28, primals_27, [True, True, True]);  add_tensor_28 = add__tensor_17 = getitem_58 = getitem_59 = primals_28 = primals_27 = None
        getitem_132 = native_layer_norm_backward_default_12[0]
        getitem_133 = native_layer_norm_backward_default_12[1]
        getitem_134 = native_layer_norm_backward_default_12[2];  native_layer_norm_backward_default_12 = None
        new_empty_default_4 = torch.ops.aten.new_empty.default(getitem_132, [4063232])
        zero__default_4 = torch.ops.aten.zero_.default(new_empty_default_4);  new_empty_default_4 = None
        as_strided_default_12 = torch.ops.aten.as_strided.default(zero__default_4, [256, 31, 512], [15872, 512, 1], 0)
        copy__default_12 = torch.ops.aten.copy_.default(as_strided_default_12, getitem_132);  as_strided_default_12 = getitem_132 = None
        as_strided_default_13 = torch.ops.aten.as_strided.default(zero__default_4, [7936, 512], [512, 1], 0);  zero__default_4 = None
        new_empty_strided_default_4 = torch.ops.aten.new_empty_strided.default(as_strided_default_13, [7936, 512], [512, 1])
        copy__default_13 = torch.ops.aten.copy_.default(new_empty_strided_default_4, as_strided_default_13);  new_empty_strided_default_4 = as_strided_default_13 = None
        as_strided_default_14 = torch.ops.aten.as_strided.default(copy__default_13, [256, 31, 512], [15872, 512, 1], 0)
        clone_default_110 = torch.ops.aten.clone.default(as_strided_default_14, memory_format = torch.contiguous_format)
        copy__default_14 = torch.ops.aten.copy_.default(as_strided_default_14, clone_default_110);  as_strided_default_14 = None
        t_default_261 = torch.ops.aten.t.default(t_default_55);  t_default_55 = None
        mm_default_155 = torch.ops.aten.mm.default(copy__default_13, t_default_261);  t_default_261 = None
        t_default_262 = torch.ops.aten.t.default(copy__default_13)
        mm_default_156 = torch.ops.aten.mm.default(t_default_262, view_default_120);  t_default_262 = view_default_120 = None
        t_default_263 = torch.ops.aten.t.default(mm_default_156);  mm_default_156 = None
        sum_dim_int_list_8 = torch.ops.aten.sum.dim_IntList(copy__default_13, [0], True);  copy__default_13 = None
        view_default_347 = torch.ops.aten.view.default(sum_dim_int_list_8, [512]);  sum_dim_int_list_8 = None
        t_default_264 = torch.ops.aten.t.default(t_default_263);  t_default_263 = None
        view_default_348 = torch.ops.aten.view.default(mm_default_155, [256, 31, 2048]);  mm_default_155 = None
        to_dtype_12 = torch.ops.aten.to.dtype(view_default_348, torch.float32);  view_default_348 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu_default_7, torch.float32);  relu_default_7 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_4, to_dtype_12);  le_scalar_4 = new_zeros_default_4 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        view_default_349 = torch.ops.aten.view.default(to_dtype_14, [7936, 2048]);  to_dtype_14 = None
        t_default_265 = torch.ops.aten.t.default(t_default_54);  t_default_54 = None
        mm_default_157 = torch.ops.aten.mm.default(view_default_349, t_default_265);  t_default_265 = None
        t_default_266 = torch.ops.aten.t.default(view_default_349)
        mm_default_158 = torch.ops.aten.mm.default(t_default_266, view_default_118);  t_default_266 = view_default_118 = None
        t_default_267 = torch.ops.aten.t.default(mm_default_158);  mm_default_158 = None
        sum_dim_int_list_9 = torch.ops.aten.sum.dim_IntList(view_default_349, [0], True);  view_default_349 = None
        view_default_350 = torch.ops.aten.view.default(sum_dim_int_list_9, [2048]);  sum_dim_int_list_9 = None
        t_default_268 = torch.ops.aten.t.default(t_default_267);  t_default_267 = None
        view_default_351 = torch.ops.aten.view.default(mm_default_157, [256, 31, 512]);  mm_default_157 = None
        add_tensor_29 = torch.ops.aten.add.Tensor(clone_default_110, view_default_351);  clone_default_110 = view_default_351 = None
        native_layer_norm_backward_default_13 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_29, add__tensor_16, [512], getitem_55, getitem_56, primals_23, primals_22, [True, True, True]);  add_tensor_29 = add__tensor_16 = getitem_55 = getitem_56 = primals_23 = primals_22 = None
        getitem_135 = native_layer_norm_backward_default_13[0]
        getitem_136 = native_layer_norm_backward_default_13[1]
        getitem_137 = native_layer_norm_backward_default_13[2];  native_layer_norm_backward_default_13 = None
        view_default_352 = torch.ops.aten.view.default(getitem_135, [7936, 512])
        t_default_269 = torch.ops.aten.t.default(view_default_352)
        mm_default_159 = torch.ops.aten.mm.default(t_default_269, view_default_117);  t_default_269 = view_default_117 = None
        t_default_270 = torch.ops.aten.t.default(mm_default_159);  mm_default_159 = None
        t_default_271 = torch.ops.aten.t.default(t_default_53);  t_default_53 = None
        mm_default_160 = torch.ops.aten.mm.default(view_default_352, t_default_271);  view_default_352 = t_default_271 = None
        view_default_353 = torch.ops.aten.view.default(mm_default_160, [256, 31, 512]);  mm_default_160 = None
        t_default_272 = torch.ops.aten.t.default(t_default_270);  t_default_270 = None
        view_default_354 = torch.ops.aten.view.default(view_default_353, [256, 31, 8, 64]);  view_default_353 = None
        transpose_int_162 = torch.ops.aten.transpose.int(view_default_354, 1, 2);  view_default_354 = None
        clone_default_111 = torch.ops.aten.clone.default(transpose_int_162, memory_format = torch.contiguous_format);  transpose_int_162 = None
        _unsafe_view_default_195 = torch.ops.aten._unsafe_view.default(clone_default_111, [2048, 31, 64]);  clone_default_111 = None
        transpose_int_163 = torch.ops.aten.transpose.int(view_default_115, 1, 2);  view_default_115 = None
        bmm_default_68 = torch.ops.aten.bmm.default(transpose_int_163, _unsafe_view_default_195);  transpose_int_163 = None
        transpose_int_164 = torch.ops.aten.transpose.int(_unsafe_view_default_87, 1, 2);  _unsafe_view_default_87 = None
        bmm_default_69 = torch.ops.aten.bmm.default(_unsafe_view_default_195, transpose_int_164);  _unsafe_view_default_195 = transpose_int_164 = None
        view_default_355 = torch.ops.aten.view.default(bmm_default_68, [256, 8, 33, 64]);  bmm_default_68 = None
        view_default_356 = torch.ops.aten.view.default(bmm_default_69, [256, 8, 31, 33]);  bmm_default_69 = None
        _softmax_backward_data_default_8 = torch.ops.aten._softmax_backward_data.default(view_default_356, _softmax_default_9, -1, torch.float32);  view_default_356 = _softmax_default_9 = None
        where_scalar_self_26 = torch.ops.aten.where.ScalarSelf(eq_scalar_9, 0.0, _softmax_backward_data_default_8);  eq_scalar_9 = _softmax_backward_data_default_8 = None
        view_default_357 = torch.ops.aten.view.default(where_scalar_self_26, [2048, 31, 33]);  where_scalar_self_26 = None
        transpose_int_165 = torch.ops.aten.transpose.int(_unsafe_view_default_84, 1, 2);  _unsafe_view_default_84 = None
        bmm_default_70 = torch.ops.aten.bmm.default(transpose_int_165, view_default_357);  transpose_int_165 = None
        transpose_int_166 = torch.ops.aten.transpose.int(_unsafe_view_default_85, 1, 2);  _unsafe_view_default_85 = None
        bmm_default_71 = torch.ops.aten.bmm.default(view_default_357, transpose_int_166);  view_default_357 = transpose_int_166 = None
        view_default_358 = torch.ops.aten.view.default(bmm_default_70, [256, 8, 64, 33]);  bmm_default_70 = None
        view_default_359 = torch.ops.aten.view.default(bmm_default_71, [256, 8, 31, 64]);  bmm_default_71 = None
        transpose_int_167 = torch.ops.aten.transpose.int(view_default_358, 2, 3);  view_default_358 = None
        div_tensor_26 = torch.ops.aten.div.Tensor(view_default_359, 8.0);  view_default_359 = None
        transpose_int_168 = torch.ops.aten.transpose.int(view_default_355, 1, 2);  view_default_355 = None
        transpose_int_169 = torch.ops.aten.transpose.int(transpose_int_167, 1, 2);  transpose_int_167 = None
        transpose_int_170 = torch.ops.aten.transpose.int(div_tensor_26, 1, 2);  div_tensor_26 = None
        clone_default_112 = torch.ops.aten.clone.default(transpose_int_168, memory_format = torch.contiguous_format);  transpose_int_168 = None
        _unsafe_view_default_196 = torch.ops.aten._unsafe_view.default(clone_default_112, [256, 33, 512]);  clone_default_112 = None
        view_default_360 = torch.ops.aten.view.default(_unsafe_view_default_196, [8448, 512]);  _unsafe_view_default_196 = None
        t_default_273 = torch.ops.aten.t.default(view_default_360)
        mm_default_161 = torch.ops.aten.mm.default(t_default_273, view_default_113);  t_default_273 = view_default_113 = None
        t_default_274 = torch.ops.aten.t.default(mm_default_161);  mm_default_161 = None
        t_default_275 = torch.ops.aten.t.default(t_default_52);  t_default_52 = None
        mm_default_162 = torch.ops.aten.mm.default(view_default_360, t_default_275);  view_default_360 = t_default_275 = None
        view_default_361 = torch.ops.aten.view.default(mm_default_162, [256, 33, 512]);  mm_default_162 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(add_tensor_24, view_default_361);  add_tensor_24 = view_default_361 = None
        t_default_276 = torch.ops.aten.t.default(t_default_274);  t_default_274 = None
        view_default_362 = torch.ops.aten.view.default(transpose_int_169, [256, 33, 512]);  transpose_int_169 = None
        clone_default_113 = torch.ops.aten.clone.default(view_default_362, memory_format = torch.contiguous_format);  view_default_362 = None
        _unsafe_view_default_197 = torch.ops.aten._unsafe_view.default(clone_default_113, [8448, 512]);  clone_default_113 = None
        t_default_277 = torch.ops.aten.t.default(_unsafe_view_default_197)
        mm_default_163 = torch.ops.aten.mm.default(t_default_277, view_default_111);  t_default_277 = view_default_111 = None
        t_default_278 = torch.ops.aten.t.default(mm_default_163);  mm_default_163 = None
        t_default_279 = torch.ops.aten.t.default(t_default_51);  t_default_51 = None
        mm_default_164 = torch.ops.aten.mm.default(_unsafe_view_default_197, t_default_279);  _unsafe_view_default_197 = t_default_279 = None
        view_default_363 = torch.ops.aten.view.default(mm_default_164, [256, 33, 512]);  mm_default_164 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(add_tensor_30, view_default_363);  add_tensor_30 = view_default_363 = None
        t_default_280 = torch.ops.aten.t.default(t_default_278);  t_default_278 = None
        clone_default_114 = torch.ops.aten.clone.default(transpose_int_170, memory_format = torch.contiguous_format);  transpose_int_170 = None
        _unsafe_view_default_198 = torch.ops.aten._unsafe_view.default(clone_default_114, [256, 31, 512]);  clone_default_114 = None
        view_default_364 = torch.ops.aten.view.default(_unsafe_view_default_198, [7936, 512]);  _unsafe_view_default_198 = None
        t_default_281 = torch.ops.aten.t.default(view_default_364)
        mm_default_165 = torch.ops.aten.mm.default(t_default_281, view_default_109);  t_default_281 = view_default_109 = None
        t_default_282 = torch.ops.aten.t.default(mm_default_165);  mm_default_165 = None
        t_default_283 = torch.ops.aten.t.default(t_default_50);  t_default_50 = None
        mm_default_166 = torch.ops.aten.mm.default(view_default_364, t_default_283);  view_default_364 = t_default_283 = None
        view_default_365 = torch.ops.aten.view.default(mm_default_166, [256, 31, 512]);  mm_default_166 = None
        add_tensor_32 = torch.ops.aten.add.Tensor(getitem_135, view_default_365);  getitem_135 = view_default_365 = None
        t_default_284 = torch.ops.aten.t.default(t_default_282);  t_default_282 = None
        native_layer_norm_backward_default_14 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_32, add__tensor_15, [512], getitem_52, getitem_53, primals_35, primals_34, [True, True, True]);  add_tensor_32 = add__tensor_15 = getitem_52 = getitem_53 = primals_35 = primals_34 = None
        getitem_138 = native_layer_norm_backward_default_14[0]
        getitem_139 = native_layer_norm_backward_default_14[1]
        getitem_140 = native_layer_norm_backward_default_14[2];  native_layer_norm_backward_default_14 = None
        view_default_366 = torch.ops.aten.view.default(getitem_138, [7936, 512])
        t_default_285 = torch.ops.aten.t.default(view_default_366)
        mm_default_167 = torch.ops.aten.mm.default(t_default_285, view_default_108);  t_default_285 = view_default_108 = None
        t_default_286 = torch.ops.aten.t.default(mm_default_167);  mm_default_167 = None
        t_default_287 = torch.ops.aten.t.default(t_default_49);  t_default_49 = None
        mm_default_168 = torch.ops.aten.mm.default(view_default_366, t_default_287);  view_default_366 = t_default_287 = None
        view_default_367 = torch.ops.aten.view.default(mm_default_168, [256, 31, 512]);  mm_default_168 = None
        t_default_288 = torch.ops.aten.t.default(t_default_286);  t_default_286 = None
        view_default_368 = torch.ops.aten.view.default(view_default_367, [256, 31, 8, 64]);  view_default_367 = None
        transpose_int_171 = torch.ops.aten.transpose.int(view_default_368, 1, 2);  view_default_368 = None
        clone_default_115 = torch.ops.aten.clone.default(transpose_int_171, memory_format = torch.contiguous_format);  transpose_int_171 = None
        _unsafe_view_default_199 = torch.ops.aten._unsafe_view.default(clone_default_115, [2048, 31, 64]);  clone_default_115 = None
        transpose_int_172 = torch.ops.aten.transpose.int(view_default_106, 1, 2);  view_default_106 = None
        bmm_default_72 = torch.ops.aten.bmm.default(transpose_int_172, _unsafe_view_default_199);  transpose_int_172 = None
        transpose_int_173 = torch.ops.aten.transpose.int(_unsafe_view_default_78, 1, 2);  _unsafe_view_default_78 = None
        bmm_default_73 = torch.ops.aten.bmm.default(_unsafe_view_default_199, transpose_int_173);  _unsafe_view_default_199 = transpose_int_173 = None
        view_default_369 = torch.ops.aten.view.default(bmm_default_72, [256, 8, 31, 64]);  bmm_default_72 = None
        view_default_370 = torch.ops.aten.view.default(bmm_default_73, [256, 8, 31, 31]);  bmm_default_73 = None
        _softmax_backward_data_default_9 = torch.ops.aten._softmax_backward_data.default(view_default_370, _softmax_default_8, -1, torch.float32);  view_default_370 = _softmax_default_8 = None
        where_scalar_self_27 = torch.ops.aten.where.ScalarSelf(eq_scalar_8, 0.0, _softmax_backward_data_default_9);  eq_scalar_8 = _softmax_backward_data_default_9 = None
        view_default_371 = torch.ops.aten.view.default(where_scalar_self_27, [2048, 31, 31]);  where_scalar_self_27 = None
        transpose_int_174 = torch.ops.aten.transpose.int(_unsafe_view_default_75, 1, 2);  _unsafe_view_default_75 = None
        bmm_default_74 = torch.ops.aten.bmm.default(transpose_int_174, view_default_371);  transpose_int_174 = None
        transpose_int_175 = torch.ops.aten.transpose.int(_unsafe_view_default_76, 1, 2);  _unsafe_view_default_76 = None
        bmm_default_75 = torch.ops.aten.bmm.default(view_default_371, transpose_int_175);  view_default_371 = transpose_int_175 = None
        view_default_372 = torch.ops.aten.view.default(bmm_default_74, [256, 8, 64, 31]);  bmm_default_74 = None
        view_default_373 = torch.ops.aten.view.default(bmm_default_75, [256, 8, 31, 64]);  bmm_default_75 = None
        transpose_int_176 = torch.ops.aten.transpose.int(view_default_372, 2, 3);  view_default_372 = None
        div_tensor_27 = torch.ops.aten.div.Tensor(view_default_373, 8.0);  view_default_373 = None
        transpose_int_177 = torch.ops.aten.transpose.int(view_default_369, 1, 2);  view_default_369 = None
        transpose_int_178 = torch.ops.aten.transpose.int(transpose_int_176, 1, 2);  transpose_int_176 = None
        transpose_int_179 = torch.ops.aten.transpose.int(div_tensor_27, 1, 2);  div_tensor_27 = None
        clone_default_116 = torch.ops.aten.clone.default(transpose_int_177, memory_format = torch.contiguous_format);  transpose_int_177 = None
        _unsafe_view_default_200 = torch.ops.aten._unsafe_view.default(clone_default_116, [256, 31, 512]);  clone_default_116 = None
        view_default_374 = torch.ops.aten.view.default(_unsafe_view_default_200, [7936, 512]);  _unsafe_view_default_200 = None
        t_default_289 = torch.ops.aten.t.default(view_default_374)
        mm_default_169 = torch.ops.aten.mm.default(t_default_289, view_default_104);  t_default_289 = view_default_104 = None
        t_default_290 = torch.ops.aten.t.default(mm_default_169);  mm_default_169 = None
        t_default_291 = torch.ops.aten.t.default(t_default_48);  t_default_48 = None
        mm_default_170 = torch.ops.aten.mm.default(view_default_374, t_default_291);  view_default_374 = t_default_291 = None
        view_default_375 = torch.ops.aten.view.default(mm_default_170, [256, 31, 512]);  mm_default_170 = None
        add_tensor_33 = torch.ops.aten.add.Tensor(getitem_138, view_default_375);  getitem_138 = view_default_375 = None
        t_default_292 = torch.ops.aten.t.default(t_default_290);  t_default_290 = None
        view_default_376 = torch.ops.aten.view.default(transpose_int_178, [256, 31, 512]);  transpose_int_178 = None
        clone_default_117 = torch.ops.aten.clone.default(view_default_376, memory_format = torch.contiguous_format);  view_default_376 = None
        _unsafe_view_default_201 = torch.ops.aten._unsafe_view.default(clone_default_117, [7936, 512]);  clone_default_117 = None
        t_default_293 = torch.ops.aten.t.default(_unsafe_view_default_201)
        mm_default_171 = torch.ops.aten.mm.default(t_default_293, view_default_102);  t_default_293 = view_default_102 = None
        t_default_294 = torch.ops.aten.t.default(mm_default_171);  mm_default_171 = None
        t_default_295 = torch.ops.aten.t.default(t_default_47);  t_default_47 = None
        mm_default_172 = torch.ops.aten.mm.default(_unsafe_view_default_201, t_default_295);  _unsafe_view_default_201 = t_default_295 = None
        view_default_377 = torch.ops.aten.view.default(mm_default_172, [256, 31, 512]);  mm_default_172 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(add_tensor_33, view_default_377);  add_tensor_33 = view_default_377 = None
        t_default_296 = torch.ops.aten.t.default(t_default_294);  t_default_294 = None
        clone_default_118 = torch.ops.aten.clone.default(transpose_int_179, memory_format = torch.contiguous_format);  transpose_int_179 = None
        _unsafe_view_default_202 = torch.ops.aten._unsafe_view.default(clone_default_118, [256, 31, 512]);  clone_default_118 = None
        view_default_378 = torch.ops.aten.view.default(_unsafe_view_default_202, [7936, 512]);  _unsafe_view_default_202 = None
        t_default_297 = torch.ops.aten.t.default(view_default_378)
        mm_default_173 = torch.ops.aten.mm.default(t_default_297, view_default_100);  t_default_297 = view_default_100 = None
        t_default_298 = torch.ops.aten.t.default(mm_default_173);  mm_default_173 = None
        t_default_299 = torch.ops.aten.t.default(t_default_46);  t_default_46 = None
        mm_default_174 = torch.ops.aten.mm.default(view_default_378, t_default_299);  view_default_378 = t_default_299 = None
        view_default_379 = torch.ops.aten.view.default(mm_default_174, [256, 31, 512]);  mm_default_174 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(add_tensor_34, view_default_379);  add_tensor_34 = view_default_379 = None
        t_default_300 = torch.ops.aten.t.default(t_default_298);  t_default_298 = None
        native_layer_norm_backward_default_15 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_35, add__tensor_14, [512], getitem_49, getitem_50, primals_10, primals_9, [True, True, True]);  add_tensor_35 = add__tensor_14 = getitem_49 = getitem_50 = primals_10 = primals_9 = None
        getitem_141 = native_layer_norm_backward_default_15[0]
        getitem_142 = native_layer_norm_backward_default_15[1]
        getitem_143 = native_layer_norm_backward_default_15[2];  native_layer_norm_backward_default_15 = None
        new_empty_default_5 = torch.ops.aten.new_empty.default(getitem_141, [4063232])
        zero__default_5 = torch.ops.aten.zero_.default(new_empty_default_5);  new_empty_default_5 = None
        as_strided_default_15 = torch.ops.aten.as_strided.default(zero__default_5, [256, 31, 512], [15872, 512, 1], 0)
        copy__default_15 = torch.ops.aten.copy_.default(as_strided_default_15, getitem_141);  as_strided_default_15 = getitem_141 = None
        as_strided_default_16 = torch.ops.aten.as_strided.default(zero__default_5, [7936, 512], [512, 1], 0);  zero__default_5 = None
        new_empty_strided_default_5 = torch.ops.aten.new_empty_strided.default(as_strided_default_16, [7936, 512], [512, 1])
        copy__default_16 = torch.ops.aten.copy_.default(new_empty_strided_default_5, as_strided_default_16);  new_empty_strided_default_5 = as_strided_default_16 = None
        as_strided_default_17 = torch.ops.aten.as_strided.default(copy__default_16, [256, 31, 512], [15872, 512, 1], 0)
        clone_default_119 = torch.ops.aten.clone.default(as_strided_default_17, memory_format = torch.contiguous_format)
        copy__default_17 = torch.ops.aten.copy_.default(as_strided_default_17, clone_default_119);  as_strided_default_17 = None
        t_default_301 = torch.ops.aten.t.default(t_default_45);  t_default_45 = None
        mm_default_175 = torch.ops.aten.mm.default(copy__default_16, t_default_301);  t_default_301 = None
        t_default_302 = torch.ops.aten.t.default(copy__default_16)
        mm_default_176 = torch.ops.aten.mm.default(t_default_302, view_default_98);  t_default_302 = view_default_98 = None
        t_default_303 = torch.ops.aten.t.default(mm_default_176);  mm_default_176 = None
        sum_dim_int_list_10 = torch.ops.aten.sum.dim_IntList(copy__default_16, [0], True);  copy__default_16 = None
        view_default_380 = torch.ops.aten.view.default(sum_dim_int_list_10, [512]);  sum_dim_int_list_10 = None
        t_default_304 = torch.ops.aten.t.default(t_default_303);  t_default_303 = None
        view_default_381 = torch.ops.aten.view.default(mm_default_175, [256, 31, 2048]);  mm_default_175 = None
        to_dtype_15 = torch.ops.aten.to.dtype(view_default_381, torch.float32);  view_default_381 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu_default_6, torch.float32);  relu_default_6 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_5 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_5, to_dtype_15);  le_scalar_5 = new_zeros_default_5 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        view_default_382 = torch.ops.aten.view.default(to_dtype_17, [7936, 2048]);  to_dtype_17 = None
        t_default_305 = torch.ops.aten.t.default(t_default_44);  t_default_44 = None
        mm_default_177 = torch.ops.aten.mm.default(view_default_382, t_default_305);  t_default_305 = None
        t_default_306 = torch.ops.aten.t.default(view_default_382)
        mm_default_178 = torch.ops.aten.mm.default(t_default_306, view_default_96);  t_default_306 = view_default_96 = None
        t_default_307 = torch.ops.aten.t.default(mm_default_178);  mm_default_178 = None
        sum_dim_int_list_11 = torch.ops.aten.sum.dim_IntList(view_default_382, [0], True);  view_default_382 = None
        view_default_383 = torch.ops.aten.view.default(sum_dim_int_list_11, [2048]);  sum_dim_int_list_11 = None
        t_default_308 = torch.ops.aten.t.default(t_default_307);  t_default_307 = None
        view_default_384 = torch.ops.aten.view.default(mm_default_177, [256, 31, 512]);  mm_default_177 = None
        add_tensor_36 = torch.ops.aten.add.Tensor(clone_default_119, view_default_384);  clone_default_119 = view_default_384 = None
        native_layer_norm_backward_default_16 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_36, add__tensor_13, [512], getitem_46, getitem_47, primals_5, primals_4, [True, True, True]);  add_tensor_36 = add__tensor_13 = getitem_46 = getitem_47 = primals_5 = primals_4 = None
        getitem_144 = native_layer_norm_backward_default_16[0]
        getitem_145 = native_layer_norm_backward_default_16[1]
        getitem_146 = native_layer_norm_backward_default_16[2];  native_layer_norm_backward_default_16 = None
        view_default_385 = torch.ops.aten.view.default(getitem_144, [7936, 512])
        t_default_309 = torch.ops.aten.t.default(view_default_385)
        mm_default_179 = torch.ops.aten.mm.default(t_default_309, view_default_95);  t_default_309 = view_default_95 = None
        t_default_310 = torch.ops.aten.t.default(mm_default_179);  mm_default_179 = None
        t_default_311 = torch.ops.aten.t.default(t_default_43);  t_default_43 = None
        mm_default_180 = torch.ops.aten.mm.default(view_default_385, t_default_311);  view_default_385 = t_default_311 = None
        view_default_386 = torch.ops.aten.view.default(mm_default_180, [256, 31, 512]);  mm_default_180 = None
        t_default_312 = torch.ops.aten.t.default(t_default_310);  t_default_310 = None
        view_default_387 = torch.ops.aten.view.default(view_default_386, [256, 31, 8, 64]);  view_default_386 = None
        transpose_int_180 = torch.ops.aten.transpose.int(view_default_387, 1, 2);  view_default_387 = None
        clone_default_120 = torch.ops.aten.clone.default(transpose_int_180, memory_format = torch.contiguous_format);  transpose_int_180 = None
        _unsafe_view_default_203 = torch.ops.aten._unsafe_view.default(clone_default_120, [2048, 31, 64]);  clone_default_120 = None
        transpose_int_181 = torch.ops.aten.transpose.int(view_default_93, 1, 2);  view_default_93 = None
        bmm_default_76 = torch.ops.aten.bmm.default(transpose_int_181, _unsafe_view_default_203);  transpose_int_181 = None
        transpose_int_182 = torch.ops.aten.transpose.int(_unsafe_view_default_69, 1, 2);  _unsafe_view_default_69 = None
        bmm_default_77 = torch.ops.aten.bmm.default(_unsafe_view_default_203, transpose_int_182);  _unsafe_view_default_203 = transpose_int_182 = None
        view_default_388 = torch.ops.aten.view.default(bmm_default_76, [256, 8, 33, 64]);  bmm_default_76 = None
        view_default_389 = torch.ops.aten.view.default(bmm_default_77, [256, 8, 31, 33]);  bmm_default_77 = None
        _softmax_backward_data_default_10 = torch.ops.aten._softmax_backward_data.default(view_default_389, _softmax_default_7, -1, torch.float32);  view_default_389 = _softmax_default_7 = None
        where_scalar_self_28 = torch.ops.aten.where.ScalarSelf(eq_scalar_7, 0.0, _softmax_backward_data_default_10);  eq_scalar_7 = _softmax_backward_data_default_10 = None
        view_default_390 = torch.ops.aten.view.default(where_scalar_self_28, [2048, 31, 33]);  where_scalar_self_28 = None
        transpose_int_183 = torch.ops.aten.transpose.int(_unsafe_view_default_66, 1, 2);  _unsafe_view_default_66 = None
        bmm_default_78 = torch.ops.aten.bmm.default(transpose_int_183, view_default_390);  transpose_int_183 = None
        transpose_int_184 = torch.ops.aten.transpose.int(_unsafe_view_default_67, 1, 2);  _unsafe_view_default_67 = None
        bmm_default_79 = torch.ops.aten.bmm.default(view_default_390, transpose_int_184);  view_default_390 = transpose_int_184 = None
        view_default_391 = torch.ops.aten.view.default(bmm_default_78, [256, 8, 64, 33]);  bmm_default_78 = None
        view_default_392 = torch.ops.aten.view.default(bmm_default_79, [256, 8, 31, 64]);  bmm_default_79 = None
        transpose_int_185 = torch.ops.aten.transpose.int(view_default_391, 2, 3);  view_default_391 = None
        div_tensor_28 = torch.ops.aten.div.Tensor(view_default_392, 8.0);  view_default_392 = None
        transpose_int_186 = torch.ops.aten.transpose.int(view_default_388, 1, 2);  view_default_388 = None
        transpose_int_187 = torch.ops.aten.transpose.int(transpose_int_185, 1, 2);  transpose_int_185 = None
        transpose_int_188 = torch.ops.aten.transpose.int(div_tensor_28, 1, 2);  div_tensor_28 = None
        clone_default_121 = torch.ops.aten.clone.default(transpose_int_186, memory_format = torch.contiguous_format);  transpose_int_186 = None
        _unsafe_view_default_204 = torch.ops.aten._unsafe_view.default(clone_default_121, [256, 33, 512]);  clone_default_121 = None
        view_default_393 = torch.ops.aten.view.default(_unsafe_view_default_204, [8448, 512]);  _unsafe_view_default_204 = None
        t_default_313 = torch.ops.aten.t.default(view_default_393)
        mm_default_181 = torch.ops.aten.mm.default(t_default_313, view_default_91);  t_default_313 = view_default_91 = None
        t_default_314 = torch.ops.aten.t.default(mm_default_181);  mm_default_181 = None
        t_default_315 = torch.ops.aten.t.default(t_default_42);  t_default_42 = None
        mm_default_182 = torch.ops.aten.mm.default(view_default_393, t_default_315);  view_default_393 = t_default_315 = None
        view_default_394 = torch.ops.aten.view.default(mm_default_182, [256, 33, 512]);  mm_default_182 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(add_tensor_31, view_default_394);  add_tensor_31 = view_default_394 = None
        t_default_316 = torch.ops.aten.t.default(t_default_314);  t_default_314 = None
        view_default_395 = torch.ops.aten.view.default(transpose_int_187, [256, 33, 512]);  transpose_int_187 = None
        clone_default_122 = torch.ops.aten.clone.default(view_default_395, memory_format = torch.contiguous_format);  view_default_395 = None
        _unsafe_view_default_205 = torch.ops.aten._unsafe_view.default(clone_default_122, [8448, 512]);  clone_default_122 = None
        t_default_317 = torch.ops.aten.t.default(_unsafe_view_default_205)
        mm_default_183 = torch.ops.aten.mm.default(t_default_317, view_default_89);  t_default_317 = view_default_89 = None
        t_default_318 = torch.ops.aten.t.default(mm_default_183);  mm_default_183 = None
        t_default_319 = torch.ops.aten.t.default(t_default_41);  t_default_41 = None
        mm_default_184 = torch.ops.aten.mm.default(_unsafe_view_default_205, t_default_319);  _unsafe_view_default_205 = t_default_319 = None
        view_default_396 = torch.ops.aten.view.default(mm_default_184, [256, 33, 512]);  mm_default_184 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(add_tensor_37, view_default_396);  add_tensor_37 = view_default_396 = None
        t_default_320 = torch.ops.aten.t.default(t_default_318);  t_default_318 = None
        clone_default_123 = torch.ops.aten.clone.default(transpose_int_188, memory_format = torch.contiguous_format);  transpose_int_188 = None
        _unsafe_view_default_206 = torch.ops.aten._unsafe_view.default(clone_default_123, [256, 31, 512]);  clone_default_123 = None
        view_default_397 = torch.ops.aten.view.default(_unsafe_view_default_206, [7936, 512]);  _unsafe_view_default_206 = None
        t_default_321 = torch.ops.aten.t.default(view_default_397)
        mm_default_185 = torch.ops.aten.mm.default(t_default_321, view_default_87);  t_default_321 = view_default_87 = None
        t_default_322 = torch.ops.aten.t.default(mm_default_185);  mm_default_185 = None
        t_default_323 = torch.ops.aten.t.default(t_default_40);  t_default_40 = None
        mm_default_186 = torch.ops.aten.mm.default(view_default_397, t_default_323);  view_default_397 = t_default_323 = None
        view_default_398 = torch.ops.aten.view.default(mm_default_186, [256, 31, 512]);  mm_default_186 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(getitem_144, view_default_398);  getitem_144 = view_default_398 = None
        t_default_324 = torch.ops.aten.t.default(t_default_322);  t_default_322 = None
        native_layer_norm_backward_default_17 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_39, add__tensor_12, [512], getitem_43, getitem_44, primals_17, primals_16, [True, True, True]);  add_tensor_39 = add__tensor_12 = getitem_43 = getitem_44 = primals_17 = primals_16 = None
        getitem_147 = native_layer_norm_backward_default_17[0]
        getitem_148 = native_layer_norm_backward_default_17[1]
        getitem_149 = native_layer_norm_backward_default_17[2];  native_layer_norm_backward_default_17 = None
        view_default_399 = torch.ops.aten.view.default(getitem_147, [7936, 512])
        t_default_325 = torch.ops.aten.t.default(view_default_399)
        mm_default_187 = torch.ops.aten.mm.default(t_default_325, view_default_86);  t_default_325 = view_default_86 = None
        t_default_326 = torch.ops.aten.t.default(mm_default_187);  mm_default_187 = None
        t_default_327 = torch.ops.aten.t.default(t_default_39);  t_default_39 = None
        mm_default_188 = torch.ops.aten.mm.default(view_default_399, t_default_327);  view_default_399 = t_default_327 = None
        view_default_400 = torch.ops.aten.view.default(mm_default_188, [256, 31, 512]);  mm_default_188 = None
        t_default_328 = torch.ops.aten.t.default(t_default_326);  t_default_326 = None
        view_default_401 = torch.ops.aten.view.default(view_default_400, [256, 31, 8, 64]);  view_default_400 = None
        transpose_int_189 = torch.ops.aten.transpose.int(view_default_401, 1, 2);  view_default_401 = None
        clone_default_124 = torch.ops.aten.clone.default(transpose_int_189, memory_format = torch.contiguous_format);  transpose_int_189 = None
        _unsafe_view_default_207 = torch.ops.aten._unsafe_view.default(clone_default_124, [2048, 31, 64]);  clone_default_124 = None
        transpose_int_190 = torch.ops.aten.transpose.int(view_default_84, 1, 2);  view_default_84 = None
        bmm_default_80 = torch.ops.aten.bmm.default(transpose_int_190, _unsafe_view_default_207);  transpose_int_190 = None
        transpose_int_191 = torch.ops.aten.transpose.int(_unsafe_view_default_60, 1, 2);  _unsafe_view_default_60 = None
        bmm_default_81 = torch.ops.aten.bmm.default(_unsafe_view_default_207, transpose_int_191);  _unsafe_view_default_207 = transpose_int_191 = None
        view_default_402 = torch.ops.aten.view.default(bmm_default_80, [256, 8, 31, 64]);  bmm_default_80 = None
        view_default_403 = torch.ops.aten.view.default(bmm_default_81, [256, 8, 31, 31]);  bmm_default_81 = None
        _softmax_backward_data_default_11 = torch.ops.aten._softmax_backward_data.default(view_default_403, _softmax_default_6, -1, torch.float32);  view_default_403 = _softmax_default_6 = None
        where_scalar_self_29 = torch.ops.aten.where.ScalarSelf(eq_scalar_6, 0.0, _softmax_backward_data_default_11);  eq_scalar_6 = _softmax_backward_data_default_11 = None
        view_default_404 = torch.ops.aten.view.default(where_scalar_self_29, [2048, 31, 31]);  where_scalar_self_29 = None
        transpose_int_192 = torch.ops.aten.transpose.int(_unsafe_view_default_57, 1, 2);  _unsafe_view_default_57 = None
        bmm_default_82 = torch.ops.aten.bmm.default(transpose_int_192, view_default_404);  transpose_int_192 = None
        transpose_int_193 = torch.ops.aten.transpose.int(_unsafe_view_default_58, 1, 2);  _unsafe_view_default_58 = None
        bmm_default_83 = torch.ops.aten.bmm.default(view_default_404, transpose_int_193);  view_default_404 = transpose_int_193 = None
        view_default_405 = torch.ops.aten.view.default(bmm_default_82, [256, 8, 64, 31]);  bmm_default_82 = None
        view_default_406 = torch.ops.aten.view.default(bmm_default_83, [256, 8, 31, 64]);  bmm_default_83 = None
        transpose_int_194 = torch.ops.aten.transpose.int(view_default_405, 2, 3);  view_default_405 = None
        div_tensor_29 = torch.ops.aten.div.Tensor(view_default_406, 8.0);  view_default_406 = None
        transpose_int_195 = torch.ops.aten.transpose.int(view_default_402, 1, 2);  view_default_402 = None
        transpose_int_196 = torch.ops.aten.transpose.int(transpose_int_194, 1, 2);  transpose_int_194 = None
        transpose_int_197 = torch.ops.aten.transpose.int(div_tensor_29, 1, 2);  div_tensor_29 = None
        clone_default_125 = torch.ops.aten.clone.default(transpose_int_195, memory_format = torch.contiguous_format);  transpose_int_195 = None
        _unsafe_view_default_208 = torch.ops.aten._unsafe_view.default(clone_default_125, [256, 31, 512]);  clone_default_125 = None
        view_default_407 = torch.ops.aten.view.default(_unsafe_view_default_208, [7936, 512]);  _unsafe_view_default_208 = None
        t_default_329 = torch.ops.aten.t.default(view_default_407)
        mm_default_189 = torch.ops.aten.mm.default(t_default_329, view_default_82);  t_default_329 = view_default_82 = None
        t_default_330 = torch.ops.aten.t.default(mm_default_189);  mm_default_189 = None
        t_default_331 = torch.ops.aten.t.default(t_default_38);  t_default_38 = None
        mm_default_190 = torch.ops.aten.mm.default(view_default_407, t_default_331);  view_default_407 = t_default_331 = None
        view_default_408 = torch.ops.aten.view.default(mm_default_190, [256, 31, 512]);  mm_default_190 = None
        add_tensor_40 = torch.ops.aten.add.Tensor(getitem_147, view_default_408);  getitem_147 = view_default_408 = None
        t_default_332 = torch.ops.aten.t.default(t_default_330);  t_default_330 = None
        view_default_409 = torch.ops.aten.view.default(transpose_int_196, [256, 31, 512]);  transpose_int_196 = None
        clone_default_126 = torch.ops.aten.clone.default(view_default_409, memory_format = torch.contiguous_format);  view_default_409 = None
        _unsafe_view_default_209 = torch.ops.aten._unsafe_view.default(clone_default_126, [7936, 512]);  clone_default_126 = None
        t_default_333 = torch.ops.aten.t.default(_unsafe_view_default_209)
        mm_default_191 = torch.ops.aten.mm.default(t_default_333, view_default_80);  t_default_333 = view_default_80 = None
        t_default_334 = torch.ops.aten.t.default(mm_default_191);  mm_default_191 = None
        t_default_335 = torch.ops.aten.t.default(t_default_37);  t_default_37 = None
        mm_default_192 = torch.ops.aten.mm.default(_unsafe_view_default_209, t_default_335);  _unsafe_view_default_209 = t_default_335 = None
        view_default_410 = torch.ops.aten.view.default(mm_default_192, [256, 31, 512]);  mm_default_192 = None
        add_tensor_41 = torch.ops.aten.add.Tensor(add_tensor_40, view_default_410);  add_tensor_40 = view_default_410 = None
        t_default_336 = torch.ops.aten.t.default(t_default_334);  t_default_334 = None
        clone_default_127 = torch.ops.aten.clone.default(transpose_int_197, memory_format = torch.contiguous_format);  transpose_int_197 = None
        _unsafe_view_default_210 = torch.ops.aten._unsafe_view.default(clone_default_127, [256, 31, 512]);  clone_default_127 = None
        view_default_411 = torch.ops.aten.view.default(_unsafe_view_default_210, [7936, 512]);  _unsafe_view_default_210 = None
        t_default_337 = torch.ops.aten.t.default(view_default_411)
        mm_default_193 = torch.ops.aten.mm.default(t_default_337, view_default_78);  t_default_337 = view_default_78 = None
        t_default_338 = torch.ops.aten.t.default(mm_default_193);  mm_default_193 = None
        t_default_339 = torch.ops.aten.t.default(t_default_36);  t_default_36 = None
        mm_default_194 = torch.ops.aten.mm.default(view_default_411, t_default_339);  view_default_411 = t_default_339 = None
        view_default_412 = torch.ops.aten.view.default(mm_default_194, [256, 31, 512]);  mm_default_194 = None
        add_tensor_42 = torch.ops.aten.add.Tensor(add_tensor_41, view_default_412);  add_tensor_41 = view_default_412 = None
        t_default_340 = torch.ops.aten.t.default(t_default_338);  t_default_338 = None
        native_layer_norm_backward_default_18 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_42, add_tensor_1, [512], getitem_40, getitem_41, primals_2, primals_1, [True, True, True]);  add_tensor_42 = add_tensor_1 = getitem_40 = getitem_41 = primals_2 = primals_1 = None
        getitem_150 = native_layer_norm_backward_default_18[0]
        getitem_151 = native_layer_norm_backward_default_18[1]
        getitem_152 = native_layer_norm_backward_default_18[2];  native_layer_norm_backward_default_18 = None
        embedding_dense_backward_default = torch.ops.aten.embedding_dense_backward.default(getitem_150, primals_191, 9521, 1, False);  getitem_150 = primals_191 = None
        native_layer_norm_backward_default_19 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_38, add__tensor_11, [512], getitem_37, getitem_38, primals_176, primals_175, [True, True, True]);  add_tensor_38 = add__tensor_11 = getitem_37 = getitem_38 = primals_176 = primals_175 = None
        getitem_153 = native_layer_norm_backward_default_19[0]
        getitem_154 = native_layer_norm_backward_default_19[1]
        getitem_155 = native_layer_norm_backward_default_19[2];  native_layer_norm_backward_default_19 = None
        new_empty_default_6 = torch.ops.aten.new_empty.default(getitem_153, [4325376])
        zero__default_6 = torch.ops.aten.zero_.default(new_empty_default_6);  new_empty_default_6 = None
        as_strided_default_18 = torch.ops.aten.as_strided.default(zero__default_6, [256, 33, 512], [16896, 512, 1], 0)
        copy__default_18 = torch.ops.aten.copy_.default(as_strided_default_18, getitem_153);  as_strided_default_18 = getitem_153 = None
        as_strided_default_19 = torch.ops.aten.as_strided.default(zero__default_6, [8448, 512], [512, 1], 0);  zero__default_6 = None
        new_empty_strided_default_6 = torch.ops.aten.new_empty_strided.default(as_strided_default_19, [8448, 512], [512, 1])
        copy__default_19 = torch.ops.aten.copy_.default(new_empty_strided_default_6, as_strided_default_19);  new_empty_strided_default_6 = as_strided_default_19 = None
        as_strided_default_20 = torch.ops.aten.as_strided.default(copy__default_19, [256, 33, 512], [16896, 512, 1], 0)
        clone_default_128 = torch.ops.aten.clone.default(as_strided_default_20, memory_format = torch.contiguous_format)
        copy__default_20 = torch.ops.aten.copy_.default(as_strided_default_20, clone_default_128);  as_strided_default_20 = None
        t_default_341 = torch.ops.aten.t.default(t_default_35);  t_default_35 = None
        mm_default_195 = torch.ops.aten.mm.default(copy__default_19, t_default_341);  t_default_341 = None
        t_default_342 = torch.ops.aten.t.default(copy__default_19)
        mm_default_196 = torch.ops.aten.mm.default(t_default_342, view_default_76);  t_default_342 = view_default_76 = None
        t_default_343 = torch.ops.aten.t.default(mm_default_196);  mm_default_196 = None
        sum_dim_int_list_12 = torch.ops.aten.sum.dim_IntList(copy__default_19, [0], True);  copy__default_19 = None
        view_default_413 = torch.ops.aten.view.default(sum_dim_int_list_12, [512]);  sum_dim_int_list_12 = None
        t_default_344 = torch.ops.aten.t.default(t_default_343);  t_default_343 = None
        view_default_414 = torch.ops.aten.view.default(mm_default_195, [256, 33, 2048]);  mm_default_195 = None
        to_dtype_18 = torch.ops.aten.to.dtype(view_default_414, torch.float32);  view_default_414 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu_default_5, torch.float32);  relu_default_5 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_6, to_dtype_18);  le_scalar_6 = new_zeros_default_6 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        view_default_415 = torch.ops.aten.view.default(to_dtype_20, [8448, 2048]);  to_dtype_20 = None
        t_default_345 = torch.ops.aten.t.default(t_default_34);  t_default_34 = None
        mm_default_197 = torch.ops.aten.mm.default(view_default_415, t_default_345);  t_default_345 = None
        t_default_346 = torch.ops.aten.t.default(view_default_415)
        mm_default_198 = torch.ops.aten.mm.default(t_default_346, view_default_74);  t_default_346 = view_default_74 = None
        t_default_347 = torch.ops.aten.t.default(mm_default_198);  mm_default_198 = None
        sum_dim_int_list_13 = torch.ops.aten.sum.dim_IntList(view_default_415, [0], True);  view_default_415 = None
        view_default_416 = torch.ops.aten.view.default(sum_dim_int_list_13, [2048]);  sum_dim_int_list_13 = None
        t_default_348 = torch.ops.aten.t.default(t_default_347);  t_default_347 = None
        view_default_417 = torch.ops.aten.view.default(mm_default_197, [256, 33, 512]);  mm_default_197 = None
        add_tensor_43 = torch.ops.aten.add.Tensor(clone_default_128, view_default_417);  clone_default_128 = view_default_417 = None
        native_layer_norm_backward_default_20 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_43, add__tensor_10, [512], getitem_34, getitem_35, primals_183, primals_182, [True, True, True]);  add_tensor_43 = add__tensor_10 = getitem_34 = getitem_35 = primals_183 = primals_182 = None
        getitem_156 = native_layer_norm_backward_default_20[0]
        getitem_157 = native_layer_norm_backward_default_20[1]
        getitem_158 = native_layer_norm_backward_default_20[2];  native_layer_norm_backward_default_20 = None
        view_default_418 = torch.ops.aten.view.default(getitem_156, [8448, 512])
        t_default_349 = torch.ops.aten.t.default(view_default_418)
        mm_default_199 = torch.ops.aten.mm.default(t_default_349, view_default_73);  t_default_349 = view_default_73 = None
        t_default_350 = torch.ops.aten.t.default(mm_default_199);  mm_default_199 = None
        t_default_351 = torch.ops.aten.t.default(t_default_33);  t_default_33 = None
        mm_default_200 = torch.ops.aten.mm.default(view_default_418, t_default_351);  view_default_418 = t_default_351 = None
        view_default_419 = torch.ops.aten.view.default(mm_default_200, [256, 33, 512]);  mm_default_200 = None
        t_default_352 = torch.ops.aten.t.default(t_default_350);  t_default_350 = None
        view_default_420 = torch.ops.aten.view.default(view_default_419, [256, 33, 8, 64]);  view_default_419 = None
        transpose_int_198 = torch.ops.aten.transpose.int(view_default_420, 1, 2);  view_default_420 = None
        clone_default_129 = torch.ops.aten.clone.default(transpose_int_198, memory_format = torch.contiguous_format);  transpose_int_198 = None
        _unsafe_view_default_211 = torch.ops.aten._unsafe_view.default(clone_default_129, [2048, 33, 64]);  clone_default_129 = None
        transpose_int_199 = torch.ops.aten.transpose.int(view_default_71, 1, 2);  view_default_71 = None
        bmm_default_84 = torch.ops.aten.bmm.default(transpose_int_199, _unsafe_view_default_211);  transpose_int_199 = None
        transpose_int_200 = torch.ops.aten.transpose.int(_unsafe_view_default_51, 1, 2);  _unsafe_view_default_51 = None
        bmm_default_85 = torch.ops.aten.bmm.default(_unsafe_view_default_211, transpose_int_200);  _unsafe_view_default_211 = transpose_int_200 = None
        view_default_421 = torch.ops.aten.view.default(bmm_default_84, [256, 8, 33, 64]);  bmm_default_84 = None
        view_default_422 = torch.ops.aten.view.default(bmm_default_85, [256, 8, 33, 33]);  bmm_default_85 = None
        _softmax_backward_data_default_12 = torch.ops.aten._softmax_backward_data.default(view_default_422, _softmax_default_5, -1, torch.float32);  view_default_422 = _softmax_default_5 = None
        where_scalar_self_30 = torch.ops.aten.where.ScalarSelf(eq_scalar_5, 0.0, _softmax_backward_data_default_12);  eq_scalar_5 = _softmax_backward_data_default_12 = None
        view_default_423 = torch.ops.aten.view.default(where_scalar_self_30, [2048, 33, 33]);  where_scalar_self_30 = None
        transpose_int_201 = torch.ops.aten.transpose.int(_unsafe_view_default_48, 1, 2);  _unsafe_view_default_48 = None
        bmm_default_86 = torch.ops.aten.bmm.default(transpose_int_201, view_default_423);  transpose_int_201 = None
        transpose_int_202 = torch.ops.aten.transpose.int(_unsafe_view_default_49, 1, 2);  _unsafe_view_default_49 = None
        bmm_default_87 = torch.ops.aten.bmm.default(view_default_423, transpose_int_202);  view_default_423 = transpose_int_202 = None
        view_default_424 = torch.ops.aten.view.default(bmm_default_86, [256, 8, 64, 33]);  bmm_default_86 = None
        view_default_425 = torch.ops.aten.view.default(bmm_default_87, [256, 8, 33, 64]);  bmm_default_87 = None
        transpose_int_203 = torch.ops.aten.transpose.int(view_default_424, 2, 3);  view_default_424 = None
        div_tensor_30 = torch.ops.aten.div.Tensor(view_default_425, 8.0);  view_default_425 = None
        transpose_int_204 = torch.ops.aten.transpose.int(view_default_421, 1, 2);  view_default_421 = None
        transpose_int_205 = torch.ops.aten.transpose.int(transpose_int_203, 1, 2);  transpose_int_203 = None
        transpose_int_206 = torch.ops.aten.transpose.int(div_tensor_30, 1, 2);  div_tensor_30 = None
        clone_default_130 = torch.ops.aten.clone.default(transpose_int_204, memory_format = torch.contiguous_format);  transpose_int_204 = None
        _unsafe_view_default_212 = torch.ops.aten._unsafe_view.default(clone_default_130, [256, 33, 512]);  clone_default_130 = None
        view_default_426 = torch.ops.aten.view.default(_unsafe_view_default_212, [8448, 512]);  _unsafe_view_default_212 = None
        t_default_353 = torch.ops.aten.t.default(view_default_426)
        mm_default_201 = torch.ops.aten.mm.default(t_default_353, view_default_69);  t_default_353 = view_default_69 = None
        t_default_354 = torch.ops.aten.t.default(mm_default_201);  mm_default_201 = None
        t_default_355 = torch.ops.aten.t.default(t_default_32);  t_default_32 = None
        mm_default_202 = torch.ops.aten.mm.default(view_default_426, t_default_355);  view_default_426 = t_default_355 = None
        view_default_427 = torch.ops.aten.view.default(mm_default_202, [256, 33, 512]);  mm_default_202 = None
        add_tensor_44 = torch.ops.aten.add.Tensor(getitem_156, view_default_427);  getitem_156 = view_default_427 = None
        t_default_356 = torch.ops.aten.t.default(t_default_354);  t_default_354 = None
        view_default_428 = torch.ops.aten.view.default(transpose_int_205, [256, 33, 512]);  transpose_int_205 = None
        clone_default_131 = torch.ops.aten.clone.default(view_default_428, memory_format = torch.contiguous_format);  view_default_428 = None
        _unsafe_view_default_213 = torch.ops.aten._unsafe_view.default(clone_default_131, [8448, 512]);  clone_default_131 = None
        t_default_357 = torch.ops.aten.t.default(_unsafe_view_default_213)
        mm_default_203 = torch.ops.aten.mm.default(t_default_357, view_default_67);  t_default_357 = view_default_67 = None
        t_default_358 = torch.ops.aten.t.default(mm_default_203);  mm_default_203 = None
        t_default_359 = torch.ops.aten.t.default(t_default_31);  t_default_31 = None
        mm_default_204 = torch.ops.aten.mm.default(_unsafe_view_default_213, t_default_359);  _unsafe_view_default_213 = t_default_359 = None
        view_default_429 = torch.ops.aten.view.default(mm_default_204, [256, 33, 512]);  mm_default_204 = None
        add_tensor_45 = torch.ops.aten.add.Tensor(add_tensor_44, view_default_429);  add_tensor_44 = view_default_429 = None
        t_default_360 = torch.ops.aten.t.default(t_default_358);  t_default_358 = None
        clone_default_132 = torch.ops.aten.clone.default(transpose_int_206, memory_format = torch.contiguous_format);  transpose_int_206 = None
        _unsafe_view_default_214 = torch.ops.aten._unsafe_view.default(clone_default_132, [256, 33, 512]);  clone_default_132 = None
        view_default_430 = torch.ops.aten.view.default(_unsafe_view_default_214, [8448, 512]);  _unsafe_view_default_214 = None
        t_default_361 = torch.ops.aten.t.default(view_default_430)
        mm_default_205 = torch.ops.aten.mm.default(t_default_361, view_default_65);  t_default_361 = view_default_65 = None
        t_default_362 = torch.ops.aten.t.default(mm_default_205);  mm_default_205 = None
        t_default_363 = torch.ops.aten.t.default(t_default_30);  t_default_30 = None
        mm_default_206 = torch.ops.aten.mm.default(view_default_430, t_default_363);  view_default_430 = t_default_363 = None
        view_default_431 = torch.ops.aten.view.default(mm_default_206, [256, 33, 512]);  mm_default_206 = None
        add_tensor_46 = torch.ops.aten.add.Tensor(add_tensor_45, view_default_431);  add_tensor_45 = view_default_431 = None
        t_default_364 = torch.ops.aten.t.default(t_default_362);  t_default_362 = None
        native_layer_norm_backward_default_21 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_46, add__tensor_9, [512], getitem_31, getitem_32, primals_164, primals_163, [True, True, True]);  add_tensor_46 = add__tensor_9 = getitem_31 = getitem_32 = primals_164 = primals_163 = None
        getitem_159 = native_layer_norm_backward_default_21[0]
        getitem_160 = native_layer_norm_backward_default_21[1]
        getitem_161 = native_layer_norm_backward_default_21[2];  native_layer_norm_backward_default_21 = None
        new_empty_default_7 = torch.ops.aten.new_empty.default(getitem_159, [4325376])
        zero__default_7 = torch.ops.aten.zero_.default(new_empty_default_7);  new_empty_default_7 = None
        as_strided_default_21 = torch.ops.aten.as_strided.default(zero__default_7, [256, 33, 512], [16896, 512, 1], 0)
        copy__default_21 = torch.ops.aten.copy_.default(as_strided_default_21, getitem_159);  as_strided_default_21 = getitem_159 = None
        as_strided_default_22 = torch.ops.aten.as_strided.default(zero__default_7, [8448, 512], [512, 1], 0);  zero__default_7 = None
        new_empty_strided_default_7 = torch.ops.aten.new_empty_strided.default(as_strided_default_22, [8448, 512], [512, 1])
        copy__default_22 = torch.ops.aten.copy_.default(new_empty_strided_default_7, as_strided_default_22);  new_empty_strided_default_7 = as_strided_default_22 = None
        as_strided_default_23 = torch.ops.aten.as_strided.default(copy__default_22, [256, 33, 512], [16896, 512, 1], 0)
        clone_default_133 = torch.ops.aten.clone.default(as_strided_default_23, memory_format = torch.contiguous_format)
        copy__default_23 = torch.ops.aten.copy_.default(as_strided_default_23, clone_default_133);  as_strided_default_23 = None
        t_default_365 = torch.ops.aten.t.default(t_default_29);  t_default_29 = None
        mm_default_207 = torch.ops.aten.mm.default(copy__default_22, t_default_365);  t_default_365 = None
        t_default_366 = torch.ops.aten.t.default(copy__default_22)
        mm_default_208 = torch.ops.aten.mm.default(t_default_366, view_default_63);  t_default_366 = view_default_63 = None
        t_default_367 = torch.ops.aten.t.default(mm_default_208);  mm_default_208 = None
        sum_dim_int_list_14 = torch.ops.aten.sum.dim_IntList(copy__default_22, [0], True);  copy__default_22 = None
        view_default_432 = torch.ops.aten.view.default(sum_dim_int_list_14, [512]);  sum_dim_int_list_14 = None
        t_default_368 = torch.ops.aten.t.default(t_default_367);  t_default_367 = None
        view_default_433 = torch.ops.aten.view.default(mm_default_207, [256, 33, 2048]);  mm_default_207 = None
        to_dtype_21 = torch.ops.aten.to.dtype(view_default_433, torch.float32);  view_default_433 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu_default_4, torch.float32);  relu_default_4 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_7, to_dtype_21);  le_scalar_7 = new_zeros_default_7 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        view_default_434 = torch.ops.aten.view.default(to_dtype_23, [8448, 2048]);  to_dtype_23 = None
        t_default_369 = torch.ops.aten.t.default(t_default_28);  t_default_28 = None
        mm_default_209 = torch.ops.aten.mm.default(view_default_434, t_default_369);  t_default_369 = None
        t_default_370 = torch.ops.aten.t.default(view_default_434)
        mm_default_210 = torch.ops.aten.mm.default(t_default_370, view_default_61);  t_default_370 = view_default_61 = None
        t_default_371 = torch.ops.aten.t.default(mm_default_210);  mm_default_210 = None
        sum_dim_int_list_15 = torch.ops.aten.sum.dim_IntList(view_default_434, [0], True);  view_default_434 = None
        view_default_435 = torch.ops.aten.view.default(sum_dim_int_list_15, [2048]);  sum_dim_int_list_15 = None
        t_default_372 = torch.ops.aten.t.default(t_default_371);  t_default_371 = None
        view_default_436 = torch.ops.aten.view.default(mm_default_209, [256, 33, 512]);  mm_default_209 = None
        add_tensor_47 = torch.ops.aten.add.Tensor(clone_default_133, view_default_436);  clone_default_133 = view_default_436 = None
        native_layer_norm_backward_default_22 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_47, add__tensor_8, [512], getitem_28, getitem_29, primals_171, primals_170, [True, True, True]);  add_tensor_47 = add__tensor_8 = getitem_28 = getitem_29 = primals_171 = primals_170 = None
        getitem_162 = native_layer_norm_backward_default_22[0]
        getitem_163 = native_layer_norm_backward_default_22[1]
        getitem_164 = native_layer_norm_backward_default_22[2];  native_layer_norm_backward_default_22 = None
        view_default_437 = torch.ops.aten.view.default(getitem_162, [8448, 512])
        t_default_373 = torch.ops.aten.t.default(view_default_437)
        mm_default_211 = torch.ops.aten.mm.default(t_default_373, view_default_60);  t_default_373 = view_default_60 = None
        t_default_374 = torch.ops.aten.t.default(mm_default_211);  mm_default_211 = None
        t_default_375 = torch.ops.aten.t.default(t_default_27);  t_default_27 = None
        mm_default_212 = torch.ops.aten.mm.default(view_default_437, t_default_375);  view_default_437 = t_default_375 = None
        view_default_438 = torch.ops.aten.view.default(mm_default_212, [256, 33, 512]);  mm_default_212 = None
        t_default_376 = torch.ops.aten.t.default(t_default_374);  t_default_374 = None
        view_default_439 = torch.ops.aten.view.default(view_default_438, [256, 33, 8, 64]);  view_default_438 = None
        transpose_int_207 = torch.ops.aten.transpose.int(view_default_439, 1, 2);  view_default_439 = None
        clone_default_134 = torch.ops.aten.clone.default(transpose_int_207, memory_format = torch.contiguous_format);  transpose_int_207 = None
        _unsafe_view_default_215 = torch.ops.aten._unsafe_view.default(clone_default_134, [2048, 33, 64]);  clone_default_134 = None
        transpose_int_208 = torch.ops.aten.transpose.int(view_default_58, 1, 2);  view_default_58 = None
        bmm_default_88 = torch.ops.aten.bmm.default(transpose_int_208, _unsafe_view_default_215);  transpose_int_208 = None
        transpose_int_209 = torch.ops.aten.transpose.int(_unsafe_view_default_42, 1, 2);  _unsafe_view_default_42 = None
        bmm_default_89 = torch.ops.aten.bmm.default(_unsafe_view_default_215, transpose_int_209);  _unsafe_view_default_215 = transpose_int_209 = None
        view_default_440 = torch.ops.aten.view.default(bmm_default_88, [256, 8, 33, 64]);  bmm_default_88 = None
        view_default_441 = torch.ops.aten.view.default(bmm_default_89, [256, 8, 33, 33]);  bmm_default_89 = None
        _softmax_backward_data_default_13 = torch.ops.aten._softmax_backward_data.default(view_default_441, _softmax_default_4, -1, torch.float32);  view_default_441 = _softmax_default_4 = None
        where_scalar_self_31 = torch.ops.aten.where.ScalarSelf(eq_scalar_4, 0.0, _softmax_backward_data_default_13);  eq_scalar_4 = _softmax_backward_data_default_13 = None
        view_default_442 = torch.ops.aten.view.default(where_scalar_self_31, [2048, 33, 33]);  where_scalar_self_31 = None
        transpose_int_210 = torch.ops.aten.transpose.int(_unsafe_view_default_39, 1, 2);  _unsafe_view_default_39 = None
        bmm_default_90 = torch.ops.aten.bmm.default(transpose_int_210, view_default_442);  transpose_int_210 = None
        transpose_int_211 = torch.ops.aten.transpose.int(_unsafe_view_default_40, 1, 2);  _unsafe_view_default_40 = None
        bmm_default_91 = torch.ops.aten.bmm.default(view_default_442, transpose_int_211);  view_default_442 = transpose_int_211 = None
        view_default_443 = torch.ops.aten.view.default(bmm_default_90, [256, 8, 64, 33]);  bmm_default_90 = None
        view_default_444 = torch.ops.aten.view.default(bmm_default_91, [256, 8, 33, 64]);  bmm_default_91 = None
        transpose_int_212 = torch.ops.aten.transpose.int(view_default_443, 2, 3);  view_default_443 = None
        div_tensor_31 = torch.ops.aten.div.Tensor(view_default_444, 8.0);  view_default_444 = None
        transpose_int_213 = torch.ops.aten.transpose.int(view_default_440, 1, 2);  view_default_440 = None
        transpose_int_214 = torch.ops.aten.transpose.int(transpose_int_212, 1, 2);  transpose_int_212 = None
        transpose_int_215 = torch.ops.aten.transpose.int(div_tensor_31, 1, 2);  div_tensor_31 = None
        clone_default_135 = torch.ops.aten.clone.default(transpose_int_213, memory_format = torch.contiguous_format);  transpose_int_213 = None
        _unsafe_view_default_216 = torch.ops.aten._unsafe_view.default(clone_default_135, [256, 33, 512]);  clone_default_135 = None
        view_default_445 = torch.ops.aten.view.default(_unsafe_view_default_216, [8448, 512]);  _unsafe_view_default_216 = None
        t_default_377 = torch.ops.aten.t.default(view_default_445)
        mm_default_213 = torch.ops.aten.mm.default(t_default_377, view_default_56);  t_default_377 = view_default_56 = None
        t_default_378 = torch.ops.aten.t.default(mm_default_213);  mm_default_213 = None
        t_default_379 = torch.ops.aten.t.default(t_default_26);  t_default_26 = None
        mm_default_214 = torch.ops.aten.mm.default(view_default_445, t_default_379);  view_default_445 = t_default_379 = None
        view_default_446 = torch.ops.aten.view.default(mm_default_214, [256, 33, 512]);  mm_default_214 = None
        add_tensor_48 = torch.ops.aten.add.Tensor(getitem_162, view_default_446);  getitem_162 = view_default_446 = None
        t_default_380 = torch.ops.aten.t.default(t_default_378);  t_default_378 = None
        view_default_447 = torch.ops.aten.view.default(transpose_int_214, [256, 33, 512]);  transpose_int_214 = None
        clone_default_136 = torch.ops.aten.clone.default(view_default_447, memory_format = torch.contiguous_format);  view_default_447 = None
        _unsafe_view_default_217 = torch.ops.aten._unsafe_view.default(clone_default_136, [8448, 512]);  clone_default_136 = None
        t_default_381 = torch.ops.aten.t.default(_unsafe_view_default_217)
        mm_default_215 = torch.ops.aten.mm.default(t_default_381, view_default_54);  t_default_381 = view_default_54 = None
        t_default_382 = torch.ops.aten.t.default(mm_default_215);  mm_default_215 = None
        t_default_383 = torch.ops.aten.t.default(t_default_25);  t_default_25 = None
        mm_default_216 = torch.ops.aten.mm.default(_unsafe_view_default_217, t_default_383);  _unsafe_view_default_217 = t_default_383 = None
        view_default_448 = torch.ops.aten.view.default(mm_default_216, [256, 33, 512]);  mm_default_216 = None
        add_tensor_49 = torch.ops.aten.add.Tensor(add_tensor_48, view_default_448);  add_tensor_48 = view_default_448 = None
        t_default_384 = torch.ops.aten.t.default(t_default_382);  t_default_382 = None
        clone_default_137 = torch.ops.aten.clone.default(transpose_int_215, memory_format = torch.contiguous_format);  transpose_int_215 = None
        _unsafe_view_default_218 = torch.ops.aten._unsafe_view.default(clone_default_137, [256, 33, 512]);  clone_default_137 = None
        view_default_449 = torch.ops.aten.view.default(_unsafe_view_default_218, [8448, 512]);  _unsafe_view_default_218 = None
        t_default_385 = torch.ops.aten.t.default(view_default_449)
        mm_default_217 = torch.ops.aten.mm.default(t_default_385, view_default_52);  t_default_385 = view_default_52 = None
        t_default_386 = torch.ops.aten.t.default(mm_default_217);  mm_default_217 = None
        t_default_387 = torch.ops.aten.t.default(t_default_24);  t_default_24 = None
        mm_default_218 = torch.ops.aten.mm.default(view_default_449, t_default_387);  view_default_449 = t_default_387 = None
        view_default_450 = torch.ops.aten.view.default(mm_default_218, [256, 33, 512]);  mm_default_218 = None
        add_tensor_50 = torch.ops.aten.add.Tensor(add_tensor_49, view_default_450);  add_tensor_49 = view_default_450 = None
        t_default_388 = torch.ops.aten.t.default(t_default_386);  t_default_386 = None
        native_layer_norm_backward_default_23 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_50, add__tensor_7, [512], getitem_25, getitem_26, primals_152, primals_151, [True, True, True]);  add_tensor_50 = add__tensor_7 = getitem_25 = getitem_26 = primals_152 = primals_151 = None
        getitem_165 = native_layer_norm_backward_default_23[0]
        getitem_166 = native_layer_norm_backward_default_23[1]
        getitem_167 = native_layer_norm_backward_default_23[2];  native_layer_norm_backward_default_23 = None
        new_empty_default_8 = torch.ops.aten.new_empty.default(getitem_165, [4325376])
        zero__default_8 = torch.ops.aten.zero_.default(new_empty_default_8);  new_empty_default_8 = None
        as_strided_default_24 = torch.ops.aten.as_strided.default(zero__default_8, [256, 33, 512], [16896, 512, 1], 0)
        copy__default_24 = torch.ops.aten.copy_.default(as_strided_default_24, getitem_165);  as_strided_default_24 = getitem_165 = None
        as_strided_default_25 = torch.ops.aten.as_strided.default(zero__default_8, [8448, 512], [512, 1], 0);  zero__default_8 = None
        new_empty_strided_default_8 = torch.ops.aten.new_empty_strided.default(as_strided_default_25, [8448, 512], [512, 1])
        copy__default_25 = torch.ops.aten.copy_.default(new_empty_strided_default_8, as_strided_default_25);  new_empty_strided_default_8 = as_strided_default_25 = None
        as_strided_default_26 = torch.ops.aten.as_strided.default(copy__default_25, [256, 33, 512], [16896, 512, 1], 0)
        clone_default_138 = torch.ops.aten.clone.default(as_strided_default_26, memory_format = torch.contiguous_format)
        copy__default_26 = torch.ops.aten.copy_.default(as_strided_default_26, clone_default_138);  as_strided_default_26 = None
        t_default_389 = torch.ops.aten.t.default(t_default_23);  t_default_23 = None
        mm_default_219 = torch.ops.aten.mm.default(copy__default_25, t_default_389);  t_default_389 = None
        t_default_390 = torch.ops.aten.t.default(copy__default_25)
        mm_default_220 = torch.ops.aten.mm.default(t_default_390, view_default_50);  t_default_390 = view_default_50 = None
        t_default_391 = torch.ops.aten.t.default(mm_default_220);  mm_default_220 = None
        sum_dim_int_list_16 = torch.ops.aten.sum.dim_IntList(copy__default_25, [0], True);  copy__default_25 = None
        view_default_451 = torch.ops.aten.view.default(sum_dim_int_list_16, [512]);  sum_dim_int_list_16 = None
        t_default_392 = torch.ops.aten.t.default(t_default_391);  t_default_391 = None
        view_default_452 = torch.ops.aten.view.default(mm_default_219, [256, 33, 2048]);  mm_default_219 = None
        to_dtype_24 = torch.ops.aten.to.dtype(view_default_452, torch.float32);  view_default_452 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu_default_3, torch.float32);  relu_default_3 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_8 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_8, to_dtype_24);  le_scalar_8 = new_zeros_default_8 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        view_default_453 = torch.ops.aten.view.default(to_dtype_26, [8448, 2048]);  to_dtype_26 = None
        t_default_393 = torch.ops.aten.t.default(t_default_22);  t_default_22 = None
        mm_default_221 = torch.ops.aten.mm.default(view_default_453, t_default_393);  t_default_393 = None
        t_default_394 = torch.ops.aten.t.default(view_default_453)
        mm_default_222 = torch.ops.aten.mm.default(t_default_394, view_default_48);  t_default_394 = view_default_48 = None
        t_default_395 = torch.ops.aten.t.default(mm_default_222);  mm_default_222 = None
        sum_dim_int_list_17 = torch.ops.aten.sum.dim_IntList(view_default_453, [0], True);  view_default_453 = None
        view_default_454 = torch.ops.aten.view.default(sum_dim_int_list_17, [2048]);  sum_dim_int_list_17 = None
        t_default_396 = torch.ops.aten.t.default(t_default_395);  t_default_395 = None
        view_default_455 = torch.ops.aten.view.default(mm_default_221, [256, 33, 512]);  mm_default_221 = None
        add_tensor_51 = torch.ops.aten.add.Tensor(clone_default_138, view_default_455);  clone_default_138 = view_default_455 = None
        native_layer_norm_backward_default_24 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_51, add__tensor_6, [512], getitem_22, getitem_23, primals_159, primals_158, [True, True, True]);  add_tensor_51 = add__tensor_6 = getitem_22 = getitem_23 = primals_159 = primals_158 = None
        getitem_168 = native_layer_norm_backward_default_24[0]
        getitem_169 = native_layer_norm_backward_default_24[1]
        getitem_170 = native_layer_norm_backward_default_24[2];  native_layer_norm_backward_default_24 = None
        view_default_456 = torch.ops.aten.view.default(getitem_168, [8448, 512])
        t_default_397 = torch.ops.aten.t.default(view_default_456)
        mm_default_223 = torch.ops.aten.mm.default(t_default_397, view_default_47);  t_default_397 = view_default_47 = None
        t_default_398 = torch.ops.aten.t.default(mm_default_223);  mm_default_223 = None
        t_default_399 = torch.ops.aten.t.default(t_default_21);  t_default_21 = None
        mm_default_224 = torch.ops.aten.mm.default(view_default_456, t_default_399);  view_default_456 = t_default_399 = None
        view_default_457 = torch.ops.aten.view.default(mm_default_224, [256, 33, 512]);  mm_default_224 = None
        t_default_400 = torch.ops.aten.t.default(t_default_398);  t_default_398 = None
        view_default_458 = torch.ops.aten.view.default(view_default_457, [256, 33, 8, 64]);  view_default_457 = None
        transpose_int_216 = torch.ops.aten.transpose.int(view_default_458, 1, 2);  view_default_458 = None
        clone_default_139 = torch.ops.aten.clone.default(transpose_int_216, memory_format = torch.contiguous_format);  transpose_int_216 = None
        _unsafe_view_default_219 = torch.ops.aten._unsafe_view.default(clone_default_139, [2048, 33, 64]);  clone_default_139 = None
        transpose_int_217 = torch.ops.aten.transpose.int(view_default_45, 1, 2);  view_default_45 = None
        bmm_default_92 = torch.ops.aten.bmm.default(transpose_int_217, _unsafe_view_default_219);  transpose_int_217 = None
        transpose_int_218 = torch.ops.aten.transpose.int(_unsafe_view_default_33, 1, 2);  _unsafe_view_default_33 = None
        bmm_default_93 = torch.ops.aten.bmm.default(_unsafe_view_default_219, transpose_int_218);  _unsafe_view_default_219 = transpose_int_218 = None
        view_default_459 = torch.ops.aten.view.default(bmm_default_92, [256, 8, 33, 64]);  bmm_default_92 = None
        view_default_460 = torch.ops.aten.view.default(bmm_default_93, [256, 8, 33, 33]);  bmm_default_93 = None
        _softmax_backward_data_default_14 = torch.ops.aten._softmax_backward_data.default(view_default_460, _softmax_default_3, -1, torch.float32);  view_default_460 = _softmax_default_3 = None
        where_scalar_self_32 = torch.ops.aten.where.ScalarSelf(eq_scalar_3, 0.0, _softmax_backward_data_default_14);  eq_scalar_3 = _softmax_backward_data_default_14 = None
        view_default_461 = torch.ops.aten.view.default(where_scalar_self_32, [2048, 33, 33]);  where_scalar_self_32 = None
        transpose_int_219 = torch.ops.aten.transpose.int(_unsafe_view_default_30, 1, 2);  _unsafe_view_default_30 = None
        bmm_default_94 = torch.ops.aten.bmm.default(transpose_int_219, view_default_461);  transpose_int_219 = None
        transpose_int_220 = torch.ops.aten.transpose.int(_unsafe_view_default_31, 1, 2);  _unsafe_view_default_31 = None
        bmm_default_95 = torch.ops.aten.bmm.default(view_default_461, transpose_int_220);  view_default_461 = transpose_int_220 = None
        view_default_462 = torch.ops.aten.view.default(bmm_default_94, [256, 8, 64, 33]);  bmm_default_94 = None
        view_default_463 = torch.ops.aten.view.default(bmm_default_95, [256, 8, 33, 64]);  bmm_default_95 = None
        transpose_int_221 = torch.ops.aten.transpose.int(view_default_462, 2, 3);  view_default_462 = None
        div_tensor_32 = torch.ops.aten.div.Tensor(view_default_463, 8.0);  view_default_463 = None
        transpose_int_222 = torch.ops.aten.transpose.int(view_default_459, 1, 2);  view_default_459 = None
        transpose_int_223 = torch.ops.aten.transpose.int(transpose_int_221, 1, 2);  transpose_int_221 = None
        transpose_int_224 = torch.ops.aten.transpose.int(div_tensor_32, 1, 2);  div_tensor_32 = None
        clone_default_140 = torch.ops.aten.clone.default(transpose_int_222, memory_format = torch.contiguous_format);  transpose_int_222 = None
        _unsafe_view_default_220 = torch.ops.aten._unsafe_view.default(clone_default_140, [256, 33, 512]);  clone_default_140 = None
        view_default_464 = torch.ops.aten.view.default(_unsafe_view_default_220, [8448, 512]);  _unsafe_view_default_220 = None
        t_default_401 = torch.ops.aten.t.default(view_default_464)
        mm_default_225 = torch.ops.aten.mm.default(t_default_401, view_default_43);  t_default_401 = view_default_43 = None
        t_default_402 = torch.ops.aten.t.default(mm_default_225);  mm_default_225 = None
        t_default_403 = torch.ops.aten.t.default(t_default_20);  t_default_20 = None
        mm_default_226 = torch.ops.aten.mm.default(view_default_464, t_default_403);  view_default_464 = t_default_403 = None
        view_default_465 = torch.ops.aten.view.default(mm_default_226, [256, 33, 512]);  mm_default_226 = None
        add_tensor_52 = torch.ops.aten.add.Tensor(getitem_168, view_default_465);  getitem_168 = view_default_465 = None
        t_default_404 = torch.ops.aten.t.default(t_default_402);  t_default_402 = None
        view_default_466 = torch.ops.aten.view.default(transpose_int_223, [256, 33, 512]);  transpose_int_223 = None
        clone_default_141 = torch.ops.aten.clone.default(view_default_466, memory_format = torch.contiguous_format);  view_default_466 = None
        _unsafe_view_default_221 = torch.ops.aten._unsafe_view.default(clone_default_141, [8448, 512]);  clone_default_141 = None
        t_default_405 = torch.ops.aten.t.default(_unsafe_view_default_221)
        mm_default_227 = torch.ops.aten.mm.default(t_default_405, view_default_41);  t_default_405 = view_default_41 = None
        t_default_406 = torch.ops.aten.t.default(mm_default_227);  mm_default_227 = None
        t_default_407 = torch.ops.aten.t.default(t_default_19);  t_default_19 = None
        mm_default_228 = torch.ops.aten.mm.default(_unsafe_view_default_221, t_default_407);  _unsafe_view_default_221 = t_default_407 = None
        view_default_467 = torch.ops.aten.view.default(mm_default_228, [256, 33, 512]);  mm_default_228 = None
        add_tensor_53 = torch.ops.aten.add.Tensor(add_tensor_52, view_default_467);  add_tensor_52 = view_default_467 = None
        t_default_408 = torch.ops.aten.t.default(t_default_406);  t_default_406 = None
        clone_default_142 = torch.ops.aten.clone.default(transpose_int_224, memory_format = torch.contiguous_format);  transpose_int_224 = None
        _unsafe_view_default_222 = torch.ops.aten._unsafe_view.default(clone_default_142, [256, 33, 512]);  clone_default_142 = None
        view_default_468 = torch.ops.aten.view.default(_unsafe_view_default_222, [8448, 512]);  _unsafe_view_default_222 = None
        t_default_409 = torch.ops.aten.t.default(view_default_468)
        mm_default_229 = torch.ops.aten.mm.default(t_default_409, view_default_39);  t_default_409 = view_default_39 = None
        t_default_410 = torch.ops.aten.t.default(mm_default_229);  mm_default_229 = None
        t_default_411 = torch.ops.aten.t.default(t_default_18);  t_default_18 = None
        mm_default_230 = torch.ops.aten.mm.default(view_default_468, t_default_411);  view_default_468 = t_default_411 = None
        view_default_469 = torch.ops.aten.view.default(mm_default_230, [256, 33, 512]);  mm_default_230 = None
        add_tensor_54 = torch.ops.aten.add.Tensor(add_tensor_53, view_default_469);  add_tensor_53 = view_default_469 = None
        t_default_412 = torch.ops.aten.t.default(t_default_410);  t_default_410 = None
        native_layer_norm_backward_default_25 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_54, add__tensor_5, [512], getitem_19, getitem_20, primals_140, primals_139, [True, True, True]);  add_tensor_54 = add__tensor_5 = getitem_19 = getitem_20 = primals_140 = primals_139 = None
        getitem_171 = native_layer_norm_backward_default_25[0]
        getitem_172 = native_layer_norm_backward_default_25[1]
        getitem_173 = native_layer_norm_backward_default_25[2];  native_layer_norm_backward_default_25 = None
        new_empty_default_9 = torch.ops.aten.new_empty.default(getitem_171, [4325376])
        zero__default_9 = torch.ops.aten.zero_.default(new_empty_default_9);  new_empty_default_9 = None
        as_strided_default_27 = torch.ops.aten.as_strided.default(zero__default_9, [256, 33, 512], [16896, 512, 1], 0)
        copy__default_27 = torch.ops.aten.copy_.default(as_strided_default_27, getitem_171);  as_strided_default_27 = getitem_171 = None
        as_strided_default_28 = torch.ops.aten.as_strided.default(zero__default_9, [8448, 512], [512, 1], 0);  zero__default_9 = None
        new_empty_strided_default_9 = torch.ops.aten.new_empty_strided.default(as_strided_default_28, [8448, 512], [512, 1])
        copy__default_28 = torch.ops.aten.copy_.default(new_empty_strided_default_9, as_strided_default_28);  new_empty_strided_default_9 = as_strided_default_28 = None
        as_strided_default_29 = torch.ops.aten.as_strided.default(copy__default_28, [256, 33, 512], [16896, 512, 1], 0)
        clone_default_143 = torch.ops.aten.clone.default(as_strided_default_29, memory_format = torch.contiguous_format)
        copy__default_29 = torch.ops.aten.copy_.default(as_strided_default_29, clone_default_143);  as_strided_default_29 = None
        t_default_413 = torch.ops.aten.t.default(t_default_17);  t_default_17 = None
        mm_default_231 = torch.ops.aten.mm.default(copy__default_28, t_default_413);  t_default_413 = None
        t_default_414 = torch.ops.aten.t.default(copy__default_28)
        mm_default_232 = torch.ops.aten.mm.default(t_default_414, view_default_37);  t_default_414 = view_default_37 = None
        t_default_415 = torch.ops.aten.t.default(mm_default_232);  mm_default_232 = None
        sum_dim_int_list_18 = torch.ops.aten.sum.dim_IntList(copy__default_28, [0], True);  copy__default_28 = None
        view_default_470 = torch.ops.aten.view.default(sum_dim_int_list_18, [512]);  sum_dim_int_list_18 = None
        t_default_416 = torch.ops.aten.t.default(t_default_415);  t_default_415 = None
        view_default_471 = torch.ops.aten.view.default(mm_default_231, [256, 33, 2048]);  mm_default_231 = None
        to_dtype_27 = torch.ops.aten.to.dtype(view_default_471, torch.float32);  view_default_471 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu_default_2, torch.float32);  relu_default_2 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_9 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_9, to_dtype_27);  le_scalar_9 = new_zeros_default_9 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        view_default_472 = torch.ops.aten.view.default(to_dtype_29, [8448, 2048]);  to_dtype_29 = None
        t_default_417 = torch.ops.aten.t.default(t_default_16);  t_default_16 = None
        mm_default_233 = torch.ops.aten.mm.default(view_default_472, t_default_417);  t_default_417 = None
        t_default_418 = torch.ops.aten.t.default(view_default_472)
        mm_default_234 = torch.ops.aten.mm.default(t_default_418, view_default_35);  t_default_418 = view_default_35 = None
        t_default_419 = torch.ops.aten.t.default(mm_default_234);  mm_default_234 = None
        sum_dim_int_list_19 = torch.ops.aten.sum.dim_IntList(view_default_472, [0], True);  view_default_472 = None
        view_default_473 = torch.ops.aten.view.default(sum_dim_int_list_19, [2048]);  sum_dim_int_list_19 = None
        t_default_420 = torch.ops.aten.t.default(t_default_419);  t_default_419 = None
        view_default_474 = torch.ops.aten.view.default(mm_default_233, [256, 33, 512]);  mm_default_233 = None
        add_tensor_55 = torch.ops.aten.add.Tensor(clone_default_143, view_default_474);  clone_default_143 = view_default_474 = None
        native_layer_norm_backward_default_26 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_55, add__tensor_4, [512], getitem_16, getitem_17, primals_147, primals_146, [True, True, True]);  add_tensor_55 = add__tensor_4 = getitem_16 = getitem_17 = primals_147 = primals_146 = None
        getitem_174 = native_layer_norm_backward_default_26[0]
        getitem_175 = native_layer_norm_backward_default_26[1]
        getitem_176 = native_layer_norm_backward_default_26[2];  native_layer_norm_backward_default_26 = None
        view_default_475 = torch.ops.aten.view.default(getitem_174, [8448, 512])
        t_default_421 = torch.ops.aten.t.default(view_default_475)
        mm_default_235 = torch.ops.aten.mm.default(t_default_421, view_default_34);  t_default_421 = view_default_34 = None
        t_default_422 = torch.ops.aten.t.default(mm_default_235);  mm_default_235 = None
        t_default_423 = torch.ops.aten.t.default(t_default_15);  t_default_15 = None
        mm_default_236 = torch.ops.aten.mm.default(view_default_475, t_default_423);  view_default_475 = t_default_423 = None
        view_default_476 = torch.ops.aten.view.default(mm_default_236, [256, 33, 512]);  mm_default_236 = None
        t_default_424 = torch.ops.aten.t.default(t_default_422);  t_default_422 = None
        view_default_477 = torch.ops.aten.view.default(view_default_476, [256, 33, 8, 64]);  view_default_476 = None
        transpose_int_225 = torch.ops.aten.transpose.int(view_default_477, 1, 2);  view_default_477 = None
        clone_default_144 = torch.ops.aten.clone.default(transpose_int_225, memory_format = torch.contiguous_format);  transpose_int_225 = None
        _unsafe_view_default_223 = torch.ops.aten._unsafe_view.default(clone_default_144, [2048, 33, 64]);  clone_default_144 = None
        transpose_int_226 = torch.ops.aten.transpose.int(view_default_32, 1, 2);  view_default_32 = None
        bmm_default_96 = torch.ops.aten.bmm.default(transpose_int_226, _unsafe_view_default_223);  transpose_int_226 = None
        transpose_int_227 = torch.ops.aten.transpose.int(_unsafe_view_default_24, 1, 2);  _unsafe_view_default_24 = None
        bmm_default_97 = torch.ops.aten.bmm.default(_unsafe_view_default_223, transpose_int_227);  _unsafe_view_default_223 = transpose_int_227 = None
        view_default_478 = torch.ops.aten.view.default(bmm_default_96, [256, 8, 33, 64]);  bmm_default_96 = None
        view_default_479 = torch.ops.aten.view.default(bmm_default_97, [256, 8, 33, 33]);  bmm_default_97 = None
        _softmax_backward_data_default_15 = torch.ops.aten._softmax_backward_data.default(view_default_479, _softmax_default_2, -1, torch.float32);  view_default_479 = _softmax_default_2 = None
        where_scalar_self_33 = torch.ops.aten.where.ScalarSelf(eq_scalar_2, 0.0, _softmax_backward_data_default_15);  eq_scalar_2 = _softmax_backward_data_default_15 = None
        view_default_480 = torch.ops.aten.view.default(where_scalar_self_33, [2048, 33, 33]);  where_scalar_self_33 = None
        transpose_int_228 = torch.ops.aten.transpose.int(_unsafe_view_default_21, 1, 2);  _unsafe_view_default_21 = None
        bmm_default_98 = torch.ops.aten.bmm.default(transpose_int_228, view_default_480);  transpose_int_228 = None
        transpose_int_229 = torch.ops.aten.transpose.int(_unsafe_view_default_22, 1, 2);  _unsafe_view_default_22 = None
        bmm_default_99 = torch.ops.aten.bmm.default(view_default_480, transpose_int_229);  view_default_480 = transpose_int_229 = None
        view_default_481 = torch.ops.aten.view.default(bmm_default_98, [256, 8, 64, 33]);  bmm_default_98 = None
        view_default_482 = torch.ops.aten.view.default(bmm_default_99, [256, 8, 33, 64]);  bmm_default_99 = None
        transpose_int_230 = torch.ops.aten.transpose.int(view_default_481, 2, 3);  view_default_481 = None
        div_tensor_33 = torch.ops.aten.div.Tensor(view_default_482, 8.0);  view_default_482 = None
        transpose_int_231 = torch.ops.aten.transpose.int(view_default_478, 1, 2);  view_default_478 = None
        transpose_int_232 = torch.ops.aten.transpose.int(transpose_int_230, 1, 2);  transpose_int_230 = None
        transpose_int_233 = torch.ops.aten.transpose.int(div_tensor_33, 1, 2);  div_tensor_33 = None
        clone_default_145 = torch.ops.aten.clone.default(transpose_int_231, memory_format = torch.contiguous_format);  transpose_int_231 = None
        _unsafe_view_default_224 = torch.ops.aten._unsafe_view.default(clone_default_145, [256, 33, 512]);  clone_default_145 = None
        view_default_483 = torch.ops.aten.view.default(_unsafe_view_default_224, [8448, 512]);  _unsafe_view_default_224 = None
        t_default_425 = torch.ops.aten.t.default(view_default_483)
        mm_default_237 = torch.ops.aten.mm.default(t_default_425, view_default_30);  t_default_425 = view_default_30 = None
        t_default_426 = torch.ops.aten.t.default(mm_default_237);  mm_default_237 = None
        t_default_427 = torch.ops.aten.t.default(t_default_14);  t_default_14 = None
        mm_default_238 = torch.ops.aten.mm.default(view_default_483, t_default_427);  view_default_483 = t_default_427 = None
        view_default_484 = torch.ops.aten.view.default(mm_default_238, [256, 33, 512]);  mm_default_238 = None
        add_tensor_56 = torch.ops.aten.add.Tensor(getitem_174, view_default_484);  getitem_174 = view_default_484 = None
        t_default_428 = torch.ops.aten.t.default(t_default_426);  t_default_426 = None
        view_default_485 = torch.ops.aten.view.default(transpose_int_232, [256, 33, 512]);  transpose_int_232 = None
        clone_default_146 = torch.ops.aten.clone.default(view_default_485, memory_format = torch.contiguous_format);  view_default_485 = None
        _unsafe_view_default_225 = torch.ops.aten._unsafe_view.default(clone_default_146, [8448, 512]);  clone_default_146 = None
        t_default_429 = torch.ops.aten.t.default(_unsafe_view_default_225)
        mm_default_239 = torch.ops.aten.mm.default(t_default_429, view_default_28);  t_default_429 = view_default_28 = None
        t_default_430 = torch.ops.aten.t.default(mm_default_239);  mm_default_239 = None
        t_default_431 = torch.ops.aten.t.default(t_default_13);  t_default_13 = None
        mm_default_240 = torch.ops.aten.mm.default(_unsafe_view_default_225, t_default_431);  _unsafe_view_default_225 = t_default_431 = None
        view_default_486 = torch.ops.aten.view.default(mm_default_240, [256, 33, 512]);  mm_default_240 = None
        add_tensor_57 = torch.ops.aten.add.Tensor(add_tensor_56, view_default_486);  add_tensor_56 = view_default_486 = None
        t_default_432 = torch.ops.aten.t.default(t_default_430);  t_default_430 = None
        clone_default_147 = torch.ops.aten.clone.default(transpose_int_233, memory_format = torch.contiguous_format);  transpose_int_233 = None
        _unsafe_view_default_226 = torch.ops.aten._unsafe_view.default(clone_default_147, [256, 33, 512]);  clone_default_147 = None
        view_default_487 = torch.ops.aten.view.default(_unsafe_view_default_226, [8448, 512]);  _unsafe_view_default_226 = None
        t_default_433 = torch.ops.aten.t.default(view_default_487)
        mm_default_241 = torch.ops.aten.mm.default(t_default_433, view_default_26);  t_default_433 = view_default_26 = None
        t_default_434 = torch.ops.aten.t.default(mm_default_241);  mm_default_241 = None
        t_default_435 = torch.ops.aten.t.default(t_default_12);  t_default_12 = None
        mm_default_242 = torch.ops.aten.mm.default(view_default_487, t_default_435);  view_default_487 = t_default_435 = None
        view_default_488 = torch.ops.aten.view.default(mm_default_242, [256, 33, 512]);  mm_default_242 = None
        add_tensor_58 = torch.ops.aten.add.Tensor(add_tensor_57, view_default_488);  add_tensor_57 = view_default_488 = None
        t_default_436 = torch.ops.aten.t.default(t_default_434);  t_default_434 = None
        native_layer_norm_backward_default_27 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_58, add__tensor_3, [512], getitem_13, getitem_14, primals_128, primals_127, [True, True, True]);  add_tensor_58 = add__tensor_3 = getitem_13 = getitem_14 = primals_128 = primals_127 = None
        getitem_177 = native_layer_norm_backward_default_27[0]
        getitem_178 = native_layer_norm_backward_default_27[1]
        getitem_179 = native_layer_norm_backward_default_27[2];  native_layer_norm_backward_default_27 = None
        new_empty_default_10 = torch.ops.aten.new_empty.default(getitem_177, [4325376])
        zero__default_10 = torch.ops.aten.zero_.default(new_empty_default_10);  new_empty_default_10 = None
        as_strided_default_30 = torch.ops.aten.as_strided.default(zero__default_10, [256, 33, 512], [16896, 512, 1], 0)
        copy__default_30 = torch.ops.aten.copy_.default(as_strided_default_30, getitem_177);  as_strided_default_30 = getitem_177 = None
        as_strided_default_31 = torch.ops.aten.as_strided.default(zero__default_10, [8448, 512], [512, 1], 0);  zero__default_10 = None
        new_empty_strided_default_10 = torch.ops.aten.new_empty_strided.default(as_strided_default_31, [8448, 512], [512, 1])
        copy__default_31 = torch.ops.aten.copy_.default(new_empty_strided_default_10, as_strided_default_31);  new_empty_strided_default_10 = as_strided_default_31 = None
        as_strided_default_32 = torch.ops.aten.as_strided.default(copy__default_31, [256, 33, 512], [16896, 512, 1], 0)
        clone_default_148 = torch.ops.aten.clone.default(as_strided_default_32, memory_format = torch.contiguous_format)
        copy__default_32 = torch.ops.aten.copy_.default(as_strided_default_32, clone_default_148);  as_strided_default_32 = None
        t_default_437 = torch.ops.aten.t.default(t_default_11);  t_default_11 = None
        mm_default_243 = torch.ops.aten.mm.default(copy__default_31, t_default_437);  t_default_437 = None
        t_default_438 = torch.ops.aten.t.default(copy__default_31)
        mm_default_244 = torch.ops.aten.mm.default(t_default_438, view_default_24);  t_default_438 = view_default_24 = None
        t_default_439 = torch.ops.aten.t.default(mm_default_244);  mm_default_244 = None
        sum_dim_int_list_20 = torch.ops.aten.sum.dim_IntList(copy__default_31, [0], True);  copy__default_31 = None
        view_default_489 = torch.ops.aten.view.default(sum_dim_int_list_20, [512]);  sum_dim_int_list_20 = None
        t_default_440 = torch.ops.aten.t.default(t_default_439);  t_default_439 = None
        view_default_490 = torch.ops.aten.view.default(mm_default_243, [256, 33, 2048]);  mm_default_243 = None
        to_dtype_30 = torch.ops.aten.to.dtype(view_default_490, torch.float32);  view_default_490 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu_default_1, torch.float32);  relu_default_1 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_10 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_10, to_dtype_30);  le_scalar_10 = new_zeros_default_10 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        view_default_491 = torch.ops.aten.view.default(to_dtype_32, [8448, 2048]);  to_dtype_32 = None
        t_default_441 = torch.ops.aten.t.default(t_default_10);  t_default_10 = None
        mm_default_245 = torch.ops.aten.mm.default(view_default_491, t_default_441);  t_default_441 = None
        t_default_442 = torch.ops.aten.t.default(view_default_491)
        mm_default_246 = torch.ops.aten.mm.default(t_default_442, view_default_22);  t_default_442 = view_default_22 = None
        t_default_443 = torch.ops.aten.t.default(mm_default_246);  mm_default_246 = None
        sum_dim_int_list_21 = torch.ops.aten.sum.dim_IntList(view_default_491, [0], True);  view_default_491 = None
        view_default_492 = torch.ops.aten.view.default(sum_dim_int_list_21, [2048]);  sum_dim_int_list_21 = None
        t_default_444 = torch.ops.aten.t.default(t_default_443);  t_default_443 = None
        view_default_493 = torch.ops.aten.view.default(mm_default_245, [256, 33, 512]);  mm_default_245 = None
        add_tensor_59 = torch.ops.aten.add.Tensor(clone_default_148, view_default_493);  clone_default_148 = view_default_493 = None
        native_layer_norm_backward_default_28 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_59, add__tensor_2, [512], getitem_10, getitem_11, primals_135, primals_134, [True, True, True]);  add_tensor_59 = add__tensor_2 = getitem_10 = getitem_11 = primals_135 = primals_134 = None
        getitem_180 = native_layer_norm_backward_default_28[0]
        getitem_181 = native_layer_norm_backward_default_28[1]
        getitem_182 = native_layer_norm_backward_default_28[2];  native_layer_norm_backward_default_28 = None
        view_default_494 = torch.ops.aten.view.default(getitem_180, [8448, 512])
        t_default_445 = torch.ops.aten.t.default(view_default_494)
        mm_default_247 = torch.ops.aten.mm.default(t_default_445, view_default_21);  t_default_445 = view_default_21 = None
        t_default_446 = torch.ops.aten.t.default(mm_default_247);  mm_default_247 = None
        t_default_447 = torch.ops.aten.t.default(t_default_9);  t_default_9 = None
        mm_default_248 = torch.ops.aten.mm.default(view_default_494, t_default_447);  view_default_494 = t_default_447 = None
        view_default_495 = torch.ops.aten.view.default(mm_default_248, [256, 33, 512]);  mm_default_248 = None
        t_default_448 = torch.ops.aten.t.default(t_default_446);  t_default_446 = None
        view_default_496 = torch.ops.aten.view.default(view_default_495, [256, 33, 8, 64]);  view_default_495 = None
        transpose_int_234 = torch.ops.aten.transpose.int(view_default_496, 1, 2);  view_default_496 = None
        clone_default_149 = torch.ops.aten.clone.default(transpose_int_234, memory_format = torch.contiguous_format);  transpose_int_234 = None
        _unsafe_view_default_227 = torch.ops.aten._unsafe_view.default(clone_default_149, [2048, 33, 64]);  clone_default_149 = None
        transpose_int_235 = torch.ops.aten.transpose.int(view_default_19, 1, 2);  view_default_19 = None
        bmm_default_100 = torch.ops.aten.bmm.default(transpose_int_235, _unsafe_view_default_227);  transpose_int_235 = None
        transpose_int_236 = torch.ops.aten.transpose.int(_unsafe_view_default_15, 1, 2);  _unsafe_view_default_15 = None
        bmm_default_101 = torch.ops.aten.bmm.default(_unsafe_view_default_227, transpose_int_236);  _unsafe_view_default_227 = transpose_int_236 = None
        view_default_497 = torch.ops.aten.view.default(bmm_default_100, [256, 8, 33, 64]);  bmm_default_100 = None
        view_default_498 = torch.ops.aten.view.default(bmm_default_101, [256, 8, 33, 33]);  bmm_default_101 = None
        _softmax_backward_data_default_16 = torch.ops.aten._softmax_backward_data.default(view_default_498, _softmax_default_1, -1, torch.float32);  view_default_498 = _softmax_default_1 = None
        where_scalar_self_34 = torch.ops.aten.where.ScalarSelf(eq_scalar_1, 0.0, _softmax_backward_data_default_16);  eq_scalar_1 = _softmax_backward_data_default_16 = None
        view_default_499 = torch.ops.aten.view.default(where_scalar_self_34, [2048, 33, 33]);  where_scalar_self_34 = None
        transpose_int_237 = torch.ops.aten.transpose.int(_unsafe_view_default_12, 1, 2);  _unsafe_view_default_12 = None
        bmm_default_102 = torch.ops.aten.bmm.default(transpose_int_237, view_default_499);  transpose_int_237 = None
        transpose_int_238 = torch.ops.aten.transpose.int(_unsafe_view_default_13, 1, 2);  _unsafe_view_default_13 = None
        bmm_default_103 = torch.ops.aten.bmm.default(view_default_499, transpose_int_238);  view_default_499 = transpose_int_238 = None
        view_default_500 = torch.ops.aten.view.default(bmm_default_102, [256, 8, 64, 33]);  bmm_default_102 = None
        view_default_501 = torch.ops.aten.view.default(bmm_default_103, [256, 8, 33, 64]);  bmm_default_103 = None
        transpose_int_239 = torch.ops.aten.transpose.int(view_default_500, 2, 3);  view_default_500 = None
        div_tensor_34 = torch.ops.aten.div.Tensor(view_default_501, 8.0);  view_default_501 = None
        transpose_int_240 = torch.ops.aten.transpose.int(view_default_497, 1, 2);  view_default_497 = None
        transpose_int_241 = torch.ops.aten.transpose.int(transpose_int_239, 1, 2);  transpose_int_239 = None
        transpose_int_242 = torch.ops.aten.transpose.int(div_tensor_34, 1, 2);  div_tensor_34 = None
        clone_default_150 = torch.ops.aten.clone.default(transpose_int_240, memory_format = torch.contiguous_format);  transpose_int_240 = None
        _unsafe_view_default_228 = torch.ops.aten._unsafe_view.default(clone_default_150, [256, 33, 512]);  clone_default_150 = None
        view_default_502 = torch.ops.aten.view.default(_unsafe_view_default_228, [8448, 512]);  _unsafe_view_default_228 = None
        t_default_449 = torch.ops.aten.t.default(view_default_502)
        mm_default_249 = torch.ops.aten.mm.default(t_default_449, view_default_17);  t_default_449 = view_default_17 = None
        t_default_450 = torch.ops.aten.t.default(mm_default_249);  mm_default_249 = None
        t_default_451 = torch.ops.aten.t.default(t_default_8);  t_default_8 = None
        mm_default_250 = torch.ops.aten.mm.default(view_default_502, t_default_451);  view_default_502 = t_default_451 = None
        view_default_503 = torch.ops.aten.view.default(mm_default_250, [256, 33, 512]);  mm_default_250 = None
        add_tensor_60 = torch.ops.aten.add.Tensor(getitem_180, view_default_503);  getitem_180 = view_default_503 = None
        t_default_452 = torch.ops.aten.t.default(t_default_450);  t_default_450 = None
        view_default_504 = torch.ops.aten.view.default(transpose_int_241, [256, 33, 512]);  transpose_int_241 = None
        clone_default_151 = torch.ops.aten.clone.default(view_default_504, memory_format = torch.contiguous_format);  view_default_504 = None
        _unsafe_view_default_229 = torch.ops.aten._unsafe_view.default(clone_default_151, [8448, 512]);  clone_default_151 = None
        t_default_453 = torch.ops.aten.t.default(_unsafe_view_default_229)
        mm_default_251 = torch.ops.aten.mm.default(t_default_453, view_default_15);  t_default_453 = view_default_15 = None
        t_default_454 = torch.ops.aten.t.default(mm_default_251);  mm_default_251 = None
        t_default_455 = torch.ops.aten.t.default(t_default_7);  t_default_7 = None
        mm_default_252 = torch.ops.aten.mm.default(_unsafe_view_default_229, t_default_455);  _unsafe_view_default_229 = t_default_455 = None
        view_default_505 = torch.ops.aten.view.default(mm_default_252, [256, 33, 512]);  mm_default_252 = None
        add_tensor_61 = torch.ops.aten.add.Tensor(add_tensor_60, view_default_505);  add_tensor_60 = view_default_505 = None
        t_default_456 = torch.ops.aten.t.default(t_default_454);  t_default_454 = None
        clone_default_152 = torch.ops.aten.clone.default(transpose_int_242, memory_format = torch.contiguous_format);  transpose_int_242 = None
        _unsafe_view_default_230 = torch.ops.aten._unsafe_view.default(clone_default_152, [256, 33, 512]);  clone_default_152 = None
        view_default_506 = torch.ops.aten.view.default(_unsafe_view_default_230, [8448, 512]);  _unsafe_view_default_230 = None
        t_default_457 = torch.ops.aten.t.default(view_default_506)
        mm_default_253 = torch.ops.aten.mm.default(t_default_457, view_default_13);  t_default_457 = view_default_13 = None
        t_default_458 = torch.ops.aten.t.default(mm_default_253);  mm_default_253 = None
        t_default_459 = torch.ops.aten.t.default(t_default_6);  t_default_6 = None
        mm_default_254 = torch.ops.aten.mm.default(view_default_506, t_default_459);  view_default_506 = t_default_459 = None
        view_default_507 = torch.ops.aten.view.default(mm_default_254, [256, 33, 512]);  mm_default_254 = None
        add_tensor_62 = torch.ops.aten.add.Tensor(add_tensor_61, view_default_507);  add_tensor_61 = view_default_507 = None
        t_default_460 = torch.ops.aten.t.default(t_default_458);  t_default_458 = None
        native_layer_norm_backward_default_29 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_62, add__tensor_1, [512], getitem_7, getitem_8, primals_116, primals_115, [True, True, True]);  add_tensor_62 = add__tensor_1 = getitem_7 = getitem_8 = primals_116 = primals_115 = None
        getitem_183 = native_layer_norm_backward_default_29[0]
        getitem_184 = native_layer_norm_backward_default_29[1]
        getitem_185 = native_layer_norm_backward_default_29[2];  native_layer_norm_backward_default_29 = None
        new_empty_default_11 = torch.ops.aten.new_empty.default(getitem_183, [4325376])
        zero__default_11 = torch.ops.aten.zero_.default(new_empty_default_11);  new_empty_default_11 = None
        as_strided_default_33 = torch.ops.aten.as_strided.default(zero__default_11, [256, 33, 512], [16896, 512, 1], 0)
        copy__default_33 = torch.ops.aten.copy_.default(as_strided_default_33, getitem_183);  as_strided_default_33 = getitem_183 = None
        as_strided_default_34 = torch.ops.aten.as_strided.default(zero__default_11, [8448, 512], [512, 1], 0);  zero__default_11 = None
        new_empty_strided_default_11 = torch.ops.aten.new_empty_strided.default(as_strided_default_34, [8448, 512], [512, 1])
        copy__default_34 = torch.ops.aten.copy_.default(new_empty_strided_default_11, as_strided_default_34);  new_empty_strided_default_11 = as_strided_default_34 = None
        as_strided_default_35 = torch.ops.aten.as_strided.default(copy__default_34, [256, 33, 512], [16896, 512, 1], 0)
        clone_default_153 = torch.ops.aten.clone.default(as_strided_default_35, memory_format = torch.contiguous_format)
        copy__default_35 = torch.ops.aten.copy_.default(as_strided_default_35, clone_default_153);  as_strided_default_35 = None
        t_default_461 = torch.ops.aten.t.default(t_default_5);  t_default_5 = None
        mm_default_255 = torch.ops.aten.mm.default(copy__default_34, t_default_461);  t_default_461 = None
        t_default_462 = torch.ops.aten.t.default(copy__default_34)
        mm_default_256 = torch.ops.aten.mm.default(t_default_462, view_default_11);  t_default_462 = view_default_11 = None
        t_default_463 = torch.ops.aten.t.default(mm_default_256);  mm_default_256 = None
        sum_dim_int_list_22 = torch.ops.aten.sum.dim_IntList(copy__default_34, [0], True);  copy__default_34 = None
        view_default_508 = torch.ops.aten.view.default(sum_dim_int_list_22, [512]);  sum_dim_int_list_22 = None
        t_default_464 = torch.ops.aten.t.default(t_default_463);  t_default_463 = None
        view_default_509 = torch.ops.aten.view.default(mm_default_255, [256, 33, 2048]);  mm_default_255 = None
        to_dtype_33 = torch.ops.aten.to.dtype(view_default_509, torch.float32);  view_default_509 = None
        to_dtype_34 = torch.ops.aten.to.dtype(relu_default, torch.float32);  relu_default = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        new_zeros_default_11 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_11, to_dtype_33);  le_scalar_11 = new_zeros_default_11 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        view_default_510 = torch.ops.aten.view.default(to_dtype_35, [8448, 2048]);  to_dtype_35 = None
        t_default_465 = torch.ops.aten.t.default(t_default_4);  t_default_4 = None
        mm_default_257 = torch.ops.aten.mm.default(view_default_510, t_default_465);  t_default_465 = None
        t_default_466 = torch.ops.aten.t.default(view_default_510)
        mm_default_258 = torch.ops.aten.mm.default(t_default_466, view_default_9);  t_default_466 = view_default_9 = None
        t_default_467 = torch.ops.aten.t.default(mm_default_258);  mm_default_258 = None
        sum_dim_int_list_23 = torch.ops.aten.sum.dim_IntList(view_default_510, [0], True);  view_default_510 = None
        view_default_511 = torch.ops.aten.view.default(sum_dim_int_list_23, [2048]);  sum_dim_int_list_23 = None
        t_default_468 = torch.ops.aten.t.default(t_default_467);  t_default_467 = None
        view_default_512 = torch.ops.aten.view.default(mm_default_257, [256, 33, 512]);  mm_default_257 = None
        add_tensor_63 = torch.ops.aten.add.Tensor(clone_default_153, view_default_512);  clone_default_153 = view_default_512 = None
        native_layer_norm_backward_default_30 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_63, add__tensor, [512], getitem_4, getitem_5, primals_123, primals_122, [True, True, True]);  add_tensor_63 = add__tensor = getitem_4 = getitem_5 = primals_123 = primals_122 = None
        getitem_186 = native_layer_norm_backward_default_30[0]
        getitem_187 = native_layer_norm_backward_default_30[1]
        getitem_188 = native_layer_norm_backward_default_30[2];  native_layer_norm_backward_default_30 = None
        view_default_513 = torch.ops.aten.view.default(getitem_186, [8448, 512])
        t_default_469 = torch.ops.aten.t.default(view_default_513)
        mm_default_259 = torch.ops.aten.mm.default(t_default_469, view_default_8);  t_default_469 = view_default_8 = None
        t_default_470 = torch.ops.aten.t.default(mm_default_259);  mm_default_259 = None
        t_default_471 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        mm_default_260 = torch.ops.aten.mm.default(view_default_513, t_default_471);  view_default_513 = t_default_471 = None
        view_default_514 = torch.ops.aten.view.default(mm_default_260, [256, 33, 512]);  mm_default_260 = None
        t_default_472 = torch.ops.aten.t.default(t_default_470);  t_default_470 = None
        view_default_515 = torch.ops.aten.view.default(view_default_514, [256, 33, 8, 64]);  view_default_514 = None
        transpose_int_243 = torch.ops.aten.transpose.int(view_default_515, 1, 2);  view_default_515 = None
        clone_default_154 = torch.ops.aten.clone.default(transpose_int_243, memory_format = torch.contiguous_format);  transpose_int_243 = None
        _unsafe_view_default_231 = torch.ops.aten._unsafe_view.default(clone_default_154, [2048, 33, 64]);  clone_default_154 = None
        transpose_int_244 = torch.ops.aten.transpose.int(view_default_6, 1, 2);  view_default_6 = None
        bmm_default_104 = torch.ops.aten.bmm.default(transpose_int_244, _unsafe_view_default_231);  transpose_int_244 = None
        transpose_int_245 = torch.ops.aten.transpose.int(_unsafe_view_default_6, 1, 2);  _unsafe_view_default_6 = None
        bmm_default_105 = torch.ops.aten.bmm.default(_unsafe_view_default_231, transpose_int_245);  _unsafe_view_default_231 = transpose_int_245 = None
        view_default_516 = torch.ops.aten.view.default(bmm_default_104, [256, 8, 33, 64]);  bmm_default_104 = None
        view_default_517 = torch.ops.aten.view.default(bmm_default_105, [256, 8, 33, 33]);  bmm_default_105 = None
        _softmax_backward_data_default_17 = torch.ops.aten._softmax_backward_data.default(view_default_517, _softmax_default, -1, torch.float32);  view_default_517 = _softmax_default = None
        where_scalar_self_35 = torch.ops.aten.where.ScalarSelf(eq_scalar, 0.0, _softmax_backward_data_default_17);  eq_scalar = _softmax_backward_data_default_17 = None
        view_default_518 = torch.ops.aten.view.default(where_scalar_self_35, [2048, 33, 33]);  where_scalar_self_35 = None
        transpose_int_246 = torch.ops.aten.transpose.int(_unsafe_view_default_3, 1, 2);  _unsafe_view_default_3 = None
        bmm_default_106 = torch.ops.aten.bmm.default(transpose_int_246, view_default_518);  transpose_int_246 = None
        transpose_int_247 = torch.ops.aten.transpose.int(_unsafe_view_default_4, 1, 2);  _unsafe_view_default_4 = None
        bmm_default_107 = torch.ops.aten.bmm.default(view_default_518, transpose_int_247);  view_default_518 = transpose_int_247 = None
        view_default_519 = torch.ops.aten.view.default(bmm_default_106, [256, 8, 64, 33]);  bmm_default_106 = None
        view_default_520 = torch.ops.aten.view.default(bmm_default_107, [256, 8, 33, 64]);  bmm_default_107 = None
        transpose_int_248 = torch.ops.aten.transpose.int(view_default_519, 2, 3);  view_default_519 = None
        div_tensor_35 = torch.ops.aten.div.Tensor(view_default_520, 8.0);  view_default_520 = None
        transpose_int_249 = torch.ops.aten.transpose.int(view_default_516, 1, 2);  view_default_516 = None
        transpose_int_250 = torch.ops.aten.transpose.int(transpose_int_248, 1, 2);  transpose_int_248 = None
        transpose_int_251 = torch.ops.aten.transpose.int(div_tensor_35, 1, 2);  div_tensor_35 = None
        clone_default_155 = torch.ops.aten.clone.default(transpose_int_249, memory_format = torch.contiguous_format);  transpose_int_249 = None
        _unsafe_view_default_232 = torch.ops.aten._unsafe_view.default(clone_default_155, [256, 33, 512]);  clone_default_155 = None
        view_default_521 = torch.ops.aten.view.default(_unsafe_view_default_232, [8448, 512]);  _unsafe_view_default_232 = None
        t_default_473 = torch.ops.aten.t.default(view_default_521)
        mm_default_261 = torch.ops.aten.mm.default(t_default_473, view_default_4);  t_default_473 = view_default_4 = None
        t_default_474 = torch.ops.aten.t.default(mm_default_261);  mm_default_261 = None
        t_default_475 = torch.ops.aten.t.default(t_default_2);  t_default_2 = None
        mm_default_262 = torch.ops.aten.mm.default(view_default_521, t_default_475);  view_default_521 = t_default_475 = None
        view_default_522 = torch.ops.aten.view.default(mm_default_262, [256, 33, 512]);  mm_default_262 = None
        add_tensor_64 = torch.ops.aten.add.Tensor(getitem_186, view_default_522);  getitem_186 = view_default_522 = None
        t_default_476 = torch.ops.aten.t.default(t_default_474);  t_default_474 = None
        view_default_523 = torch.ops.aten.view.default(transpose_int_250, [256, 33, 512]);  transpose_int_250 = None
        clone_default_156 = torch.ops.aten.clone.default(view_default_523, memory_format = torch.contiguous_format);  view_default_523 = None
        _unsafe_view_default_233 = torch.ops.aten._unsafe_view.default(clone_default_156, [8448, 512]);  clone_default_156 = None
        t_default_477 = torch.ops.aten.t.default(_unsafe_view_default_233)
        mm_default_263 = torch.ops.aten.mm.default(t_default_477, view_default_2);  t_default_477 = view_default_2 = None
        t_default_478 = torch.ops.aten.t.default(mm_default_263);  mm_default_263 = None
        t_default_479 = torch.ops.aten.t.default(t_default_1);  t_default_1 = None
        mm_default_264 = torch.ops.aten.mm.default(_unsafe_view_default_233, t_default_479);  _unsafe_view_default_233 = t_default_479 = None
        view_default_524 = torch.ops.aten.view.default(mm_default_264, [256, 33, 512]);  mm_default_264 = None
        add_tensor_65 = torch.ops.aten.add.Tensor(add_tensor_64, view_default_524);  add_tensor_64 = view_default_524 = None
        t_default_480 = torch.ops.aten.t.default(t_default_478);  t_default_478 = None
        clone_default_157 = torch.ops.aten.clone.default(transpose_int_251, memory_format = torch.contiguous_format);  transpose_int_251 = None
        _unsafe_view_default_234 = torch.ops.aten._unsafe_view.default(clone_default_157, [256, 33, 512]);  clone_default_157 = None
        view_default_525 = torch.ops.aten.view.default(_unsafe_view_default_234, [8448, 512]);  _unsafe_view_default_234 = None
        t_default_481 = torch.ops.aten.t.default(view_default_525)
        mm_default_265 = torch.ops.aten.mm.default(t_default_481, view_default);  t_default_481 = view_default = None
        t_default_482 = torch.ops.aten.t.default(mm_default_265);  mm_default_265 = None
        t_default_483 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default_266 = torch.ops.aten.mm.default(view_default_525, t_default_483);  view_default_525 = t_default_483 = None
        view_default_526 = torch.ops.aten.view.default(mm_default_266, [256, 33, 512]);  mm_default_266 = None
        add_tensor_66 = torch.ops.aten.add.Tensor(add_tensor_65, view_default_526);  add_tensor_65 = view_default_526 = None
        t_default_484 = torch.ops.aten.t.default(t_default_482);  t_default_482 = None
        native_layer_norm_backward_default_31 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_66, add_tensor, [512], getitem_1, getitem_2, primals_114, primals_113, [True, True, True]);  add_tensor_66 = add_tensor = getitem_1 = getitem_2 = primals_114 = primals_113 = None
        getitem_189 = native_layer_norm_backward_default_31[0]
        getitem_190 = native_layer_norm_backward_default_31[1]
        getitem_191 = native_layer_norm_backward_default_31[2];  native_layer_norm_backward_default_31 = None
        embedding_dense_backward_default_1 = torch.ops.aten.embedding_dense_backward.default(getitem_189, primals_190, 9521, 1, False);  getitem_189 = primals_190 = None
        return [view_default_211, getitem_152, getitem_151, t_default_312, getitem_146, getitem_145, t_default_320, t_default_324, t_default_316, getitem_143, getitem_142, view_default_383, t_default_308, view_default_380, t_default_304, t_default_328, getitem_149, getitem_148, t_default_336, t_default_340, t_default_332, t_default_272, getitem_137, getitem_136, t_default_280, t_default_284, t_default_276, getitem_134, getitem_133, view_default_350, t_default_268, view_default_347, t_default_264, t_default_288, getitem_140, getitem_139, t_default_296, t_default_300, t_default_292, t_default_232, getitem_128, getitem_127, t_default_240, t_default_244, t_default_236, getitem_125, getitem_124, view_default_317, t_default_228, view_default_314, t_default_224, t_default_248, getitem_131, getitem_130, t_default_256, t_default_260, t_default_252, t_default_192, getitem_119, getitem_118, t_default_200, t_default_204, t_default_196, getitem_116, getitem_115, view_default_284, t_default_188, view_default_281, t_default_184, t_default_208, getitem_122, getitem_121, t_default_216, t_default_220, t_default_212, t_default_152, getitem_110, getitem_109, t_default_160, t_default_164, t_default_156, getitem_107, getitem_106, view_default_251, t_default_148, view_default_248, t_default_144, t_default_168, getitem_113, getitem_112, t_default_176, t_default_180, t_default_172, t_default_112, getitem_101, getitem_100, t_default_120, t_default_124, t_default_116, getitem_98, getitem_97, view_default_218, t_default_108, view_default_215, t_default_104, t_default_128, getitem_104, getitem_103, t_default_136, t_default_140, t_default_132, None, embedding_dense_backward_default, getitem_191, getitem_190, getitem_185, getitem_184, view_default_511, t_default_468, view_default_508, t_default_464, t_default_472, getitem_188, getitem_187, t_default_480, t_default_484, t_default_476, getitem_179, getitem_178, view_default_492, t_default_444, view_default_489, t_default_440, t_default_448, getitem_182, getitem_181, t_default_456, t_default_460, t_default_452, getitem_173, getitem_172, view_default_473, t_default_420, view_default_470, t_default_416, t_default_424, getitem_176, getitem_175, t_default_432, t_default_436, t_default_428, getitem_167, getitem_166, view_default_454, t_default_396, view_default_451, t_default_392, t_default_400, getitem_170, getitem_169, t_default_408, t_default_412, t_default_404, getitem_161, getitem_160, view_default_435, t_default_372, view_default_432, t_default_368, t_default_376, getitem_164, getitem_163, t_default_384, t_default_388, t_default_380, getitem_155, getitem_154, view_default_416, t_default_348, view_default_413, t_default_344, t_default_352, getitem_158, getitem_157, t_default_360, t_default_364, t_default_356, None, embedding_dense_backward_default_1, t_default_100, None, None]
        
