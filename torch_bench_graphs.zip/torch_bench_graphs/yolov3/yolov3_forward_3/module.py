
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/yolov3/yolov3_forward_3/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3):
        view_default = torch.ops.aten.view.default(primals_3, [16, 3, 85, 12, 16]);  primals_3 = None
        permute_default = torch.ops.aten.permute.default(view_default, [0, 1, 3, 4, 2]);  view_default = None
        clone_default = torch.ops.aten.clone.default(permute_default, memory_format = torch.contiguous_format);  permute_default = None
        clone_default_1 = torch.ops.aten.clone.default(clone_default)
        view_default_1 = torch.ops.aten.view.default(clone_default_1, [16, -1, 85])
        return [view_default_1, clone_default, clone_default_1, primals_1]
        
