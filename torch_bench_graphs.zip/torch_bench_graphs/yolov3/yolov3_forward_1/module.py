
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.register_buffer('_tensor_constant0', torch.empty([2], dtype=torch.float32))
        self.load_state_dict(torch.load(r'torch_bench_graphs/yolov3/yolov3_forward_1/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3):
        _tensor_constant0 = self._tensor_constant0
        lift = torch.ops.aten.lift.default(_tensor_constant0);  _tensor_constant0 = None
        arange = torch.ops.aten.arange.default(12, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        arange_1 = torch.ops.aten.arange.default(16, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        view_default = torch.ops.aten.view.default(arange, [-1, 1]);  arange = None
        expand_default = torch.ops.aten.expand.default(view_default, [12, 16]);  view_default = None
        view_default_1 = torch.ops.aten.view.default(arange_1, [1, -1]);  arange_1 = None
        expand_default_1 = torch.ops.aten.expand.default(view_default_1, [12, 16]);  view_default_1 = None
        stack_default = torch.ops.aten.stack.default([expand_default_1, expand_default], 2);  expand_default_1 = expand_default = None
        view_default_2 = torch.ops.aten.view.default(stack_default, [1, 1, 12, 16, 2]);  stack_default = None
        _to_copy_default = torch.ops.aten._to_copy.default(view_default_2, dtype = torch.float32);  view_default_2 = None
        _to_copy_default_1 = torch.ops.aten._to_copy.default(primals_2, device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided);  primals_2 = None
        _to_copy_default_2 = torch.ops.aten._to_copy.default(primals_3, device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided);  primals_3 = None
        view_default_3 = torch.ops.aten.view.default(primals_1, [16, 3, 85, 12, 16]);  primals_1 = None
        permute_default = torch.ops.aten.permute.default(view_default_3, [0, 1, 3, 4, 2]);  view_default_3 = None
        clone_default = torch.ops.aten.clone.default(permute_default, memory_format = torch.contiguous_format);  permute_default = None
        clone_default_1 = torch.ops.aten.clone.default(clone_default)
        view_default_4 = torch.ops.aten.view.default(clone_default_1, [16, -1, 85])
        return [view_default_4, clone_default, lift, _to_copy_default, _to_copy_default_1, _to_copy_default_2, _to_copy_default_2, clone_default_1]
        
