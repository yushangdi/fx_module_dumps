
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/yolov3/yolov3_backward_1/state_dict.pt'))

    
    
    def forward(self, _to_copy_default_2, clone_default_1, tangents_1, tangents_2, tangents_3, tangents_4, tangents_5, tangents_6):
        slice_tensor = torch.ops.aten.slice.Tensor(clone_default_1, 4, 0, 2)
        sigmoid_default = torch.ops.aten.sigmoid.default(slice_tensor);  slice_tensor = None
        slice_tensor_2 = torch.ops.aten.slice.Tensor(clone_default_1, 4, 2, 4);  clone_default_1 = None
        exp_default = torch.ops.aten.exp.default(slice_tensor_2);  slice_tensor_2 = None
        view_default_5 = torch.ops.aten.view.default(tangents_1, [16, 3, 12, 16, 85]);  tangents_1 = None
        new_empty_strided_default = torch.ops.aten.new_empty_strided.default(view_default_5, [16, 3, 12, 16, 85], [48960, 16320, 1360, 85, 1])
        copy__default_3 = torch.ops.aten.copy_.default(new_empty_strided_default, view_default_5);  new_empty_strided_default = view_default_5 = None
        new_empty_strided_default_1 = torch.ops.aten.new_empty_strided.default(copy__default_3, [16, 3, 12, 16, 85], [48960, 16320, 1360, 85, 1])
        copy__default_5 = torch.ops.aten.copy_.default(new_empty_strided_default_1, copy__default_3);  new_empty_strided_default_1 = copy__default_3 = None
        as_strided_default_1 = torch.ops.aten.as_strided.default(copy__default_5, [16, 3, 12, 16, 4], [48960, 16320, 1360, 85, 1], 0)
        clone_default_3 = torch.ops.aten.clone.default(as_strided_default_1, memory_format = torch.contiguous_format);  as_strided_default_1 = None
        new_empty_default = torch.ops.aten.new_empty.default(clone_default_3, [783360]);  clone_default_3 = None
        zero__default_1 = torch.ops.aten.zero_.default(new_empty_default);  new_empty_default = None
        as_strided_default_3 = torch.ops.aten.as_strided.default(zero__default_1, [16, 3, 12, 16, 85], [48960, 16320, 1360, 85, 1], 0);  zero__default_1 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(copy__default_5, as_strided_default_3);  copy__default_5 = as_strided_default_3 = None
        new_empty_strided_default_2 = torch.ops.aten.new_empty_strided.default(add_tensor_1, [16, 3, 12, 16, 85], [48960, 16320, 1360, 85, 1])
        copy__default_8 = torch.ops.aten.copy_.default(new_empty_strided_default_2, add_tensor_1);  new_empty_strided_default_2 = add_tensor_1 = None
        new_empty_strided_default_3 = torch.ops.aten.new_empty_strided.default(copy__default_8, [16, 3, 12, 16, 85], [48960, 16320, 1360, 85, 1])
        copy__default_10 = torch.ops.aten.copy_.default(new_empty_strided_default_3, copy__default_8);  new_empty_strided_default_3 = copy__default_8 = None
        as_strided_default_5 = torch.ops.aten.as_strided.default(copy__default_10, [16, 3, 12, 16, 2], [48960, 16320, 1360, 85, 1], 2)
        clone_default_5 = torch.ops.aten.clone.default(as_strided_default_5, memory_format = torch.contiguous_format);  as_strided_default_5 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(clone_default_5, _to_copy_default_2);  clone_default_5 = _to_copy_default_2 = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(mul_tensor_4, exp_default);  mul_tensor_4 = exp_default = None
        slice_backward_default = torch.ops.aten.slice_backward.default(mul_tensor_5, [16, 3, 12, 16, 85], 4, 2, 4, 1);  mul_tensor_5 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(copy__default_10, slice_backward_default);  copy__default_10 = slice_backward_default = None
        new_empty_strided_default_4 = torch.ops.aten.new_empty_strided.default(add_tensor_2, [16, 3, 12, 16, 85], [48960, 16320, 1360, 85, 1])
        copy__default_12 = torch.ops.aten.copy_.default(new_empty_strided_default_4, add_tensor_2);  new_empty_strided_default_4 = add_tensor_2 = None
        as_strided_default_6 = torch.ops.aten.as_strided.default(copy__default_12, [16, 3, 12, 16, 2], [48960, 16320, 1360, 85, 1], 0)
        clone_default_6 = torch.ops.aten.clone.default(as_strided_default_6, memory_format = torch.contiguous_format);  as_strided_default_6 = None
        to_dtype_3 = torch.ops.aten.to.dtype(clone_default_6, torch.float32);  clone_default_6 = None
        to_dtype_4 = torch.ops.aten.to.dtype(sigmoid_default, torch.float32);  sigmoid_default = None
        rsub_scalar_1 = torch.ops.aten.rsub.Scalar(to_dtype_4, 1)
        mul_tensor_6 = torch.ops.aten.mul.Tensor(to_dtype_4, rsub_scalar_1);  to_dtype_4 = rsub_scalar_1 = None
        conj_physical_default_1 = torch.ops.aten.conj_physical.default(mul_tensor_6);  mul_tensor_6 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(to_dtype_3, conj_physical_default_1);  to_dtype_3 = conj_physical_default_1 = None
        to_dtype_5 = torch.ops.aten.to.dtype(mul_tensor_7, torch.float32);  mul_tensor_7 = None
        slice_backward_default_1 = torch.ops.aten.slice_backward.default(to_dtype_5, [16, 3, 12, 16, 85], 4, 0, 2, 1);  to_dtype_5 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(copy__default_12, slice_backward_default_1);  copy__default_12 = slice_backward_default_1 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(tangents_2, add_tensor_3);  tangents_2 = add_tensor_3 = None
        permute_default_1 = torch.ops.aten.permute.default(add_tensor_4, [0, 1, 4, 2, 3]);  add_tensor_4 = None
        clone_default_7 = torch.ops.aten.clone.default(permute_default_1, memory_format = torch.contiguous_format);  permute_default_1 = None
        _unsafe_view_default = torch.ops.aten._unsafe_view.default(clone_default_7, [16, 255, 12, 16]);  clone_default_7 = None
        return [_unsafe_view_default, None, None]
        
