
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/yolov3/yolov3_joint_3/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, tangents_1, tangents_2):
        view_default = torch.ops.aten.view.default(primals_3, [16, 3, 85, 12, 16]);  primals_3 = None
        permute_default = torch.ops.aten.permute.default(view_default, [0, 1, 3, 4, 2]);  view_default = None
        clone_default = torch.ops.aten.clone.default(permute_default, memory_format = torch.contiguous_format);  permute_default = None
        clone_default_1 = torch.ops.aten.clone.default(clone_default)
        slice_tensor = torch.ops.aten.slice.Tensor(clone_default_1, 4, 0, 2)
        sigmoid_default = torch.ops.aten.sigmoid.default(slice_tensor);  slice_tensor = None
        add_tensor = torch.ops.aten.add.Tensor(sigmoid_default, primals_2);  primals_2 = None
        slice_tensor_1 = torch.ops.aten.slice.Tensor(clone_default_1, 4, 0, 2)
        copy__default = torch.ops.aten.copy_.default(slice_tensor_1, add_tensor);  slice_tensor_1 = add_tensor = None
        slice_tensor_2 = torch.ops.aten.slice.Tensor(clone_default_1, 4, 2, 4)
        exp_default = torch.ops.aten.exp.default(slice_tensor_2);  slice_tensor_2 = None
        mul_tensor = torch.ops.aten.mul.Tensor(exp_default, primals_1)
        slice_tensor_3 = torch.ops.aten.slice.Tensor(clone_default_1, 4, 2, 4)
        copy__default_1 = torch.ops.aten.copy_.default(slice_tensor_3, mul_tensor);  slice_tensor_3 = mul_tensor = None
        slice_tensor_4 = torch.ops.aten.slice.Tensor(clone_default_1, 4, 0, 4)
        mul__tensor = torch.ops.aten.mul_.Tensor(slice_tensor_4, 32);  slice_tensor_4 = None
        slice_tensor_5 = torch.ops.aten.slice.Tensor(clone_default_1, 4, 0, 4)
        copy__default_2 = torch.ops.aten.copy_.default(slice_tensor_5, mul__tensor);  slice_tensor_5 = mul__tensor = None
        slice_tensor_6 = torch.ops.aten.slice.Tensor(clone_default_1, 4, 4, 9223372036854775807)
        sigmoid__default = torch.ops.aten.sigmoid_.default(slice_tensor_6);  slice_tensor_6 = None
        view_default_1 = torch.ops.aten.view.default(clone_default_1, [16, -1, 85]);  clone_default_1 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(view_default_1, tangents_1)
        is_same_size_default_1 = torch.ops.aten.is_same_size.default(clone_default, tangents_2)
        view_default_2 = torch.ops.aten.view.default(tangents_1, [16, 3, 12, 16, 85]);  tangents_1 = None
        new_empty_strided_default = torch.ops.aten.new_empty_strided.default(view_default_2, [16, 3, 12, 16, 85], [48960, 16320, 1360, 85, 1])
        copy__default_3 = torch.ops.aten.copy_.default(new_empty_strided_default, view_default_2);  new_empty_strided_default = view_default_2 = None
        as_strided_default = torch.ops.aten.as_strided.default(copy__default_3, [16, 3, 12, 16, 81], [48960, 16320, 1360, 85, 1], 4)
        clone_default_2 = torch.ops.aten.clone.default(as_strided_default, memory_format = torch.contiguous_format)
        to_dtype = torch.ops.aten.to.dtype(clone_default_2, torch.float32);  clone_default_2 = None
        to_dtype_1 = torch.ops.aten.to.dtype(sigmoid__default, torch.float32);  sigmoid__default = None
        rsub_scalar = torch.ops.aten.rsub.Scalar(to_dtype_1, 1)
        mul_tensor_1 = torch.ops.aten.mul.Tensor(to_dtype_1, rsub_scalar);  to_dtype_1 = rsub_scalar = None
        conj_physical_default = torch.ops.aten.conj_physical.default(mul_tensor_1);  mul_tensor_1 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(to_dtype, conj_physical_default);  to_dtype = conj_physical_default = None
        to_dtype_2 = torch.ops.aten.to.dtype(mul_tensor_2, torch.float32);  mul_tensor_2 = None
        copy__default_4 = torch.ops.aten.copy_.default(as_strided_default, to_dtype_2);  as_strided_default = to_dtype_2 = None
        new_empty_strided_default_1 = torch.ops.aten.new_empty_strided.default(copy__default_3, [16, 3, 12, 16, 85], [48960, 16320, 1360, 85, 1])
        copy__default_5 = torch.ops.aten.copy_.default(new_empty_strided_default_1, copy__default_3);  new_empty_strided_default_1 = copy__default_3 = None
        as_strided_default_1 = torch.ops.aten.as_strided.default(copy__default_5, [16, 3, 12, 16, 4], [48960, 16320, 1360, 85, 1], 0)
        clone_default_3 = torch.ops.aten.clone.default(as_strided_default_1, memory_format = torch.contiguous_format)
        empty_like_default = torch.ops.aten.empty_like.default(clone_default_3, memory_format = torch.contiguous_format)
        zero__default = torch.ops.aten.zero_.default(empty_like_default);  empty_like_default = None
        copy__default_6 = torch.ops.aten.copy_.default(as_strided_default_1, zero__default);  as_strided_default_1 = zero__default = None
        new_empty_default = torch.ops.aten.new_empty.default(clone_default_3, [783360])
        zero__default_1 = torch.ops.aten.zero_.default(new_empty_default);  new_empty_default = None
        as_strided_default_2 = torch.ops.aten.as_strided.default(zero__default_1, [16, 3, 12, 16, 4], [48960, 16320, 1360, 85, 1], 0)
        copy__default_7 = torch.ops.aten.copy_.default(as_strided_default_2, clone_default_3);  as_strided_default_2 = clone_default_3 = None
        as_strided_default_3 = torch.ops.aten.as_strided.default(zero__default_1, [16, 3, 12, 16, 85], [48960, 16320, 1360, 85, 1], 0);  zero__default_1 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(copy__default_5, as_strided_default_3);  copy__default_5 = as_strided_default_3 = None
        new_empty_strided_default_2 = torch.ops.aten.new_empty_strided.default(add_tensor_1, [16, 3, 12, 16, 85], [48960, 16320, 1360, 85, 1])
        copy__default_8 = torch.ops.aten.copy_.default(new_empty_strided_default_2, add_tensor_1);  new_empty_strided_default_2 = add_tensor_1 = None
        as_strided_default_4 = torch.ops.aten.as_strided.default(copy__default_8, [16, 3, 12, 16, 4], [48960, 16320, 1360, 85, 1], 0)
        clone_default_4 = torch.ops.aten.clone.default(as_strided_default_4, memory_format = torch.contiguous_format)
        mul_tensor_3 = torch.ops.aten.mul.Tensor(clone_default_4, 32);  clone_default_4 = None
        copy__default_9 = torch.ops.aten.copy_.default(as_strided_default_4, mul_tensor_3);  as_strided_default_4 = mul_tensor_3 = None
        new_empty_strided_default_3 = torch.ops.aten.new_empty_strided.default(copy__default_8, [16, 3, 12, 16, 85], [48960, 16320, 1360, 85, 1])
        copy__default_10 = torch.ops.aten.copy_.default(new_empty_strided_default_3, copy__default_8);  new_empty_strided_default_3 = copy__default_8 = None
        as_strided_default_5 = torch.ops.aten.as_strided.default(copy__default_10, [16, 3, 12, 16, 2], [48960, 16320, 1360, 85, 1], 2)
        clone_default_5 = torch.ops.aten.clone.default(as_strided_default_5, memory_format = torch.contiguous_format)
        empty_like_default_1 = torch.ops.aten.empty_like.default(clone_default_5, memory_format = torch.contiguous_format)
        zero__default_2 = torch.ops.aten.zero_.default(empty_like_default_1);  empty_like_default_1 = None
        copy__default_11 = torch.ops.aten.copy_.default(as_strided_default_5, zero__default_2);  as_strided_default_5 = zero__default_2 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(clone_default_5, exp_default)
        mul_tensor_5 = torch.ops.aten.mul.Tensor(clone_default_5, primals_1);  clone_default_5 = primals_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(mul_tensor_4, [0, 2, 3], True);  mul_tensor_4 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(mul_tensor_5, exp_default);  mul_tensor_5 = exp_default = None
        slice_backward_default = torch.ops.aten.slice_backward.default(mul_tensor_6, [16, 3, 12, 16, 85], 4, 2, 4, 1);  mul_tensor_6 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(copy__default_10, slice_backward_default);  copy__default_10 = slice_backward_default = None
        new_empty_strided_default_4 = torch.ops.aten.new_empty_strided.default(add_tensor_2, [16, 3, 12, 16, 85], [48960, 16320, 1360, 85, 1])
        copy__default_12 = torch.ops.aten.copy_.default(new_empty_strided_default_4, add_tensor_2);  new_empty_strided_default_4 = add_tensor_2 = None
        as_strided_default_6 = torch.ops.aten.as_strided.default(copy__default_12, [16, 3, 12, 16, 2], [48960, 16320, 1360, 85, 1], 0)
        clone_default_6 = torch.ops.aten.clone.default(as_strided_default_6, memory_format = torch.contiguous_format)
        empty_like_default_2 = torch.ops.aten.empty_like.default(clone_default_6, memory_format = torch.contiguous_format)
        zero__default_3 = torch.ops.aten.zero_.default(empty_like_default_2);  empty_like_default_2 = None
        copy__default_13 = torch.ops.aten.copy_.default(as_strided_default_6, zero__default_3);  as_strided_default_6 = zero__default_3 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(clone_default_6, [0, 1], True)
        to_dtype_3 = torch.ops.aten.to.dtype(clone_default_6, torch.float32);  clone_default_6 = None
        to_dtype_4 = torch.ops.aten.to.dtype(sigmoid_default, torch.float32);  sigmoid_default = None
        rsub_scalar_1 = torch.ops.aten.rsub.Scalar(to_dtype_4, 1)
        mul_tensor_7 = torch.ops.aten.mul.Tensor(to_dtype_4, rsub_scalar_1);  to_dtype_4 = rsub_scalar_1 = None
        conj_physical_default_1 = torch.ops.aten.conj_physical.default(mul_tensor_7);  mul_tensor_7 = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(to_dtype_3, conj_physical_default_1);  to_dtype_3 = conj_physical_default_1 = None
        to_dtype_5 = torch.ops.aten.to.dtype(mul_tensor_8, torch.float32);  mul_tensor_8 = None
        slice_backward_default_1 = torch.ops.aten.slice_backward.default(to_dtype_5, [16, 3, 12, 16, 85], 4, 0, 2, 1);  to_dtype_5 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(copy__default_12, slice_backward_default_1);  copy__default_12 = slice_backward_default_1 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(tangents_2, add_tensor_3);  tangents_2 = add_tensor_3 = None
        permute_default_1 = torch.ops.aten.permute.default(add_tensor_4, [0, 1, 4, 2, 3]);  add_tensor_4 = None
        clone_default_7 = torch.ops.aten.clone.default(permute_default_1, memory_format = torch.contiguous_format);  permute_default_1 = None
        _unsafe_view_default = torch.ops.aten._unsafe_view.default(clone_default_7, [16, 255, 12, 16]);  clone_default_7 = None
        return [view_default_1, clone_default, sum_dim_int_list, sum_dim_int_list_1, _unsafe_view_default]
        
