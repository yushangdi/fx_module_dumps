
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/yolov3/yolov3_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339, primals_340, primals_341, primals_342, primals_343, primals_344, primals_345, primals_346, primals_347, primals_348, primals_349, primals_350, primals_351, primals_352, primals_353, primals_354, primals_355, primals_356, primals_357):
        convolution_default = torch.ops.aten.convolution.default(primals_357, primals_1, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_6, primals_2, primals_4, primals_5, False, 0.03, 0.0001);  primals_2 = None
        getitem = native_batch_norm_default[0];  native_batch_norm_default = None
        leaky_relu__default = torch.ops.aten.leaky_relu_.default(getitem, 0.1);  getitem = None
        convolution_default_1 = torch.ops.aten.convolution.default(leaky_relu__default, primals_49, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_54, primals_50, primals_52, primals_53, False, 0.03, 0.0001);  primals_50 = None
        getitem_3 = native_batch_norm_default_1[0];  native_batch_norm_default_1 = None
        leaky_relu__default_1 = torch.ops.aten.leaky_relu_.default(getitem_3, 0.1);  getitem_3 = None
        convolution_default_2 = torch.ops.aten.convolution.default(leaky_relu__default_1, primals_97, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_102, primals_98, primals_100, primals_101, False, 0.03, 0.0001);  primals_98 = None
        getitem_6 = native_batch_norm_default_2[0];  native_batch_norm_default_2 = None
        leaky_relu__default_2 = torch.ops.aten.leaky_relu_.default(getitem_6, 0.1);  getitem_6 = None
        convolution_default_3 = torch.ops.aten.convolution.default(leaky_relu__default_2, primals_145, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_150, primals_146, primals_148, primals_149, False, 0.03, 0.0001);  primals_146 = None
        getitem_9 = native_batch_norm_default_3[0];  native_batch_norm_default_3 = None
        leaky_relu__default_3 = torch.ops.aten.leaky_relu_.default(getitem_9, 0.1);  getitem_9 = None
        add_tensor = torch.ops.aten.add.Tensor(leaky_relu__default_3, leaky_relu__default_1)
        convolution_default_4 = torch.ops.aten.convolution.default(add_tensor, primals_229, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_234, primals_230, primals_232, primals_233, False, 0.03, 0.0001);  primals_230 = None
        getitem_12 = native_batch_norm_default_4[0];  native_batch_norm_default_4 = None
        leaky_relu__default_4 = torch.ops.aten.leaky_relu_.default(getitem_12, 0.1);  getitem_12 = None
        convolution_default_5 = torch.ops.aten.convolution.default(leaky_relu__default_4, primals_277, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_282, primals_278, primals_280, primals_281, False, 0.03, 0.0001);  primals_278 = None
        getitem_15 = native_batch_norm_default_5[0];  native_batch_norm_default_5 = None
        leaky_relu__default_5 = torch.ops.aten.leaky_relu_.default(getitem_15, 0.1);  getitem_15 = None
        convolution_default_6 = torch.ops.aten.convolution.default(leaky_relu__default_5, primals_319, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_324, primals_320, primals_322, primals_323, False, 0.03, 0.0001);  primals_320 = None
        getitem_18 = native_batch_norm_default_6[0];  native_batch_norm_default_6 = None
        leaky_relu__default_6 = torch.ops.aten.leaky_relu_.default(getitem_18, 0.1);  getitem_18 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(leaky_relu__default_6, leaky_relu__default_4)
        convolution_default_7 = torch.ops.aten.convolution.default(add_tensor_1, primals_351, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_356, primals_352, primals_354, primals_355, False, 0.03, 0.0001);  primals_352 = None
        getitem_21 = native_batch_norm_default_7[0];  native_batch_norm_default_7 = None
        leaky_relu__default_7 = torch.ops.aten.leaky_relu_.default(getitem_21, 0.1);  getitem_21 = None
        convolution_default_8 = torch.ops.aten.convolution.default(leaky_relu__default_7, primals_7, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_12, primals_8, primals_10, primals_11, False, 0.03, 0.0001);  primals_8 = None
        getitem_24 = native_batch_norm_default_8[0];  native_batch_norm_default_8 = None
        leaky_relu__default_8 = torch.ops.aten.leaky_relu_.default(getitem_24, 0.1);  getitem_24 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(leaky_relu__default_8, add_tensor_1)
        convolution_default_9 = torch.ops.aten.convolution.default(add_tensor_2, primals_13, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_18, primals_14, primals_16, primals_17, False, 0.03, 0.0001);  primals_14 = None
        getitem_27 = native_batch_norm_default_9[0];  native_batch_norm_default_9 = None
        leaky_relu__default_9 = torch.ops.aten.leaky_relu_.default(getitem_27, 0.1);  getitem_27 = None
        convolution_default_10 = torch.ops.aten.convolution.default(leaky_relu__default_9, primals_19, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_24, primals_20, primals_22, primals_23, False, 0.03, 0.0001);  primals_20 = None
        getitem_30 = native_batch_norm_default_10[0];  native_batch_norm_default_10 = None
        leaky_relu__default_10 = torch.ops.aten.leaky_relu_.default(getitem_30, 0.1);  getitem_30 = None
        convolution_default_11 = torch.ops.aten.convolution.default(leaky_relu__default_10, primals_25, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_30, primals_26, primals_28, primals_29, False, 0.03, 0.0001);  primals_26 = None
        getitem_33 = native_batch_norm_default_11[0];  native_batch_norm_default_11 = None
        leaky_relu__default_11 = torch.ops.aten.leaky_relu_.default(getitem_33, 0.1);  getitem_33 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(leaky_relu__default_11, leaky_relu__default_9)
        convolution_default_12 = torch.ops.aten.convolution.default(add_tensor_3, primals_31, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_36, primals_32, primals_34, primals_35, False, 0.03, 0.0001);  primals_32 = None
        getitem_36 = native_batch_norm_default_12[0];  native_batch_norm_default_12 = None
        leaky_relu__default_12 = torch.ops.aten.leaky_relu_.default(getitem_36, 0.1);  getitem_36 = None
        convolution_default_13 = torch.ops.aten.convolution.default(leaky_relu__default_12, primals_37, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_42, primals_38, primals_40, primals_41, False, 0.03, 0.0001);  primals_38 = None
        getitem_39 = native_batch_norm_default_13[0];  native_batch_norm_default_13 = None
        leaky_relu__default_13 = torch.ops.aten.leaky_relu_.default(getitem_39, 0.1);  getitem_39 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(leaky_relu__default_13, add_tensor_3)
        convolution_default_14 = torch.ops.aten.convolution.default(add_tensor_4, primals_43, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_48, primals_44, primals_46, primals_47, False, 0.03, 0.0001);  primals_44 = None
        getitem_42 = native_batch_norm_default_14[0];  native_batch_norm_default_14 = None
        leaky_relu__default_14 = torch.ops.aten.leaky_relu_.default(getitem_42, 0.1);  getitem_42 = None
        convolution_default_15 = torch.ops.aten.convolution.default(leaky_relu__default_14, primals_55, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_60, primals_56, primals_58, primals_59, False, 0.03, 0.0001);  primals_56 = None
        getitem_45 = native_batch_norm_default_15[0];  native_batch_norm_default_15 = None
        leaky_relu__default_15 = torch.ops.aten.leaky_relu_.default(getitem_45, 0.1);  getitem_45 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(leaky_relu__default_15, add_tensor_4)
        convolution_default_16 = torch.ops.aten.convolution.default(add_tensor_5, primals_61, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_66, primals_62, primals_64, primals_65, False, 0.03, 0.0001);  primals_62 = None
        getitem_48 = native_batch_norm_default_16[0];  native_batch_norm_default_16 = None
        leaky_relu__default_16 = torch.ops.aten.leaky_relu_.default(getitem_48, 0.1);  getitem_48 = None
        convolution_default_17 = torch.ops.aten.convolution.default(leaky_relu__default_16, primals_67, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_72, primals_68, primals_70, primals_71, False, 0.03, 0.0001);  primals_68 = None
        getitem_51 = native_batch_norm_default_17[0];  native_batch_norm_default_17 = None
        leaky_relu__default_17 = torch.ops.aten.leaky_relu_.default(getitem_51, 0.1);  getitem_51 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(leaky_relu__default_17, add_tensor_5)
        convolution_default_18 = torch.ops.aten.convolution.default(add_tensor_6, primals_73, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_78, primals_74, primals_76, primals_77, False, 0.03, 0.0001);  primals_74 = None
        getitem_54 = native_batch_norm_default_18[0];  native_batch_norm_default_18 = None
        leaky_relu__default_18 = torch.ops.aten.leaky_relu_.default(getitem_54, 0.1);  getitem_54 = None
        convolution_default_19 = torch.ops.aten.convolution.default(leaky_relu__default_18, primals_79, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_84, primals_80, primals_82, primals_83, False, 0.03, 0.0001);  primals_80 = None
        getitem_57 = native_batch_norm_default_19[0];  native_batch_norm_default_19 = None
        leaky_relu__default_19 = torch.ops.aten.leaky_relu_.default(getitem_57, 0.1);  getitem_57 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(leaky_relu__default_19, add_tensor_6)
        convolution_default_20 = torch.ops.aten.convolution.default(add_tensor_7, primals_85, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_90, primals_86, primals_88, primals_89, False, 0.03, 0.0001);  primals_86 = None
        getitem_60 = native_batch_norm_default_20[0];  native_batch_norm_default_20 = None
        leaky_relu__default_20 = torch.ops.aten.leaky_relu_.default(getitem_60, 0.1);  getitem_60 = None
        convolution_default_21 = torch.ops.aten.convolution.default(leaky_relu__default_20, primals_91, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_96, primals_92, primals_94, primals_95, False, 0.03, 0.0001);  primals_92 = None
        getitem_63 = native_batch_norm_default_21[0];  native_batch_norm_default_21 = None
        leaky_relu__default_21 = torch.ops.aten.leaky_relu_.default(getitem_63, 0.1);  getitem_63 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(leaky_relu__default_21, add_tensor_7)
        convolution_default_22 = torch.ops.aten.convolution.default(add_tensor_8, primals_103, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_108, primals_104, primals_106, primals_107, False, 0.03, 0.0001);  primals_104 = None
        getitem_66 = native_batch_norm_default_22[0];  native_batch_norm_default_22 = None
        leaky_relu__default_22 = torch.ops.aten.leaky_relu_.default(getitem_66, 0.1);  getitem_66 = None
        convolution_default_23 = torch.ops.aten.convolution.default(leaky_relu__default_22, primals_109, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_114, primals_110, primals_112, primals_113, False, 0.03, 0.0001);  primals_110 = None
        getitem_69 = native_batch_norm_default_23[0];  native_batch_norm_default_23 = None
        leaky_relu__default_23 = torch.ops.aten.leaky_relu_.default(getitem_69, 0.1);  getitem_69 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(leaky_relu__default_23, add_tensor_8)
        convolution_default_24 = torch.ops.aten.convolution.default(add_tensor_9, primals_115, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_120, primals_116, primals_118, primals_119, False, 0.03, 0.0001);  primals_116 = None
        getitem_72 = native_batch_norm_default_24[0];  native_batch_norm_default_24 = None
        leaky_relu__default_24 = torch.ops.aten.leaky_relu_.default(getitem_72, 0.1);  getitem_72 = None
        convolution_default_25 = torch.ops.aten.convolution.default(leaky_relu__default_24, primals_121, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_126, primals_122, primals_124, primals_125, False, 0.03, 0.0001);  primals_122 = None
        getitem_75 = native_batch_norm_default_25[0];  native_batch_norm_default_25 = None
        leaky_relu__default_25 = torch.ops.aten.leaky_relu_.default(getitem_75, 0.1);  getitem_75 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(leaky_relu__default_25, add_tensor_9)
        convolution_default_26 = torch.ops.aten.convolution.default(add_tensor_10, primals_127, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_132, primals_128, primals_130, primals_131, False, 0.03, 0.0001);  primals_128 = None
        getitem_78 = native_batch_norm_default_26[0];  native_batch_norm_default_26 = None
        leaky_relu__default_26 = torch.ops.aten.leaky_relu_.default(getitem_78, 0.1);  getitem_78 = None
        convolution_default_27 = torch.ops.aten.convolution.default(leaky_relu__default_26, primals_133, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_138, primals_134, primals_136, primals_137, False, 0.03, 0.0001);  primals_134 = None
        getitem_81 = native_batch_norm_default_27[0];  native_batch_norm_default_27 = None
        leaky_relu__default_27 = torch.ops.aten.leaky_relu_.default(getitem_81, 0.1);  getitem_81 = None
        convolution_default_28 = torch.ops.aten.convolution.default(leaky_relu__default_27, primals_139, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_144, primals_140, primals_142, primals_143, False, 0.03, 0.0001);  primals_140 = None
        getitem_84 = native_batch_norm_default_28[0];  native_batch_norm_default_28 = None
        leaky_relu__default_28 = torch.ops.aten.leaky_relu_.default(getitem_84, 0.1);  getitem_84 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(leaky_relu__default_28, leaky_relu__default_26)
        convolution_default_29 = torch.ops.aten.convolution.default(add_tensor_11, primals_151, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_156, primals_152, primals_154, primals_155, False, 0.03, 0.0001);  primals_152 = None
        getitem_87 = native_batch_norm_default_29[0];  native_batch_norm_default_29 = None
        leaky_relu__default_29 = torch.ops.aten.leaky_relu_.default(getitem_87, 0.1);  getitem_87 = None
        convolution_default_30 = torch.ops.aten.convolution.default(leaky_relu__default_29, primals_157, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_162, primals_158, primals_160, primals_161, False, 0.03, 0.0001);  primals_158 = None
        getitem_90 = native_batch_norm_default_30[0];  native_batch_norm_default_30 = None
        leaky_relu__default_30 = torch.ops.aten.leaky_relu_.default(getitem_90, 0.1);  getitem_90 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(leaky_relu__default_30, add_tensor_11)
        convolution_default_31 = torch.ops.aten.convolution.default(add_tensor_12, primals_163, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_31, primals_168, primals_164, primals_166, primals_167, False, 0.03, 0.0001);  primals_164 = None
        getitem_93 = native_batch_norm_default_31[0];  native_batch_norm_default_31 = None
        leaky_relu__default_31 = torch.ops.aten.leaky_relu_.default(getitem_93, 0.1);  getitem_93 = None
        convolution_default_32 = torch.ops.aten.convolution.default(leaky_relu__default_31, primals_169, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_174, primals_170, primals_172, primals_173, False, 0.03, 0.0001);  primals_170 = None
        getitem_96 = native_batch_norm_default_32[0];  native_batch_norm_default_32 = None
        leaky_relu__default_32 = torch.ops.aten.leaky_relu_.default(getitem_96, 0.1);  getitem_96 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(leaky_relu__default_32, add_tensor_12)
        convolution_default_33 = torch.ops.aten.convolution.default(add_tensor_13, primals_175, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_180, primals_176, primals_178, primals_179, False, 0.03, 0.0001);  primals_176 = None
        getitem_99 = native_batch_norm_default_33[0];  native_batch_norm_default_33 = None
        leaky_relu__default_33 = torch.ops.aten.leaky_relu_.default(getitem_99, 0.1);  getitem_99 = None
        convolution_default_34 = torch.ops.aten.convolution.default(leaky_relu__default_33, primals_181, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_186, primals_182, primals_184, primals_185, False, 0.03, 0.0001);  primals_182 = None
        getitem_102 = native_batch_norm_default_34[0];  native_batch_norm_default_34 = None
        leaky_relu__default_34 = torch.ops.aten.leaky_relu_.default(getitem_102, 0.1);  getitem_102 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(leaky_relu__default_34, add_tensor_13)
        convolution_default_35 = torch.ops.aten.convolution.default(add_tensor_14, primals_187, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_192, primals_188, primals_190, primals_191, False, 0.03, 0.0001);  primals_188 = None
        getitem_105 = native_batch_norm_default_35[0];  native_batch_norm_default_35 = None
        leaky_relu__default_35 = torch.ops.aten.leaky_relu_.default(getitem_105, 0.1);  getitem_105 = None
        convolution_default_36 = torch.ops.aten.convolution.default(leaky_relu__default_35, primals_193, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_198, primals_194, primals_196, primals_197, False, 0.03, 0.0001);  primals_194 = None
        getitem_108 = native_batch_norm_default_36[0];  native_batch_norm_default_36 = None
        leaky_relu__default_36 = torch.ops.aten.leaky_relu_.default(getitem_108, 0.1);  getitem_108 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(leaky_relu__default_36, add_tensor_14)
        convolution_default_37 = torch.ops.aten.convolution.default(add_tensor_15, primals_199, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_37, primals_204, primals_200, primals_202, primals_203, False, 0.03, 0.0001);  primals_200 = None
        getitem_111 = native_batch_norm_default_37[0];  native_batch_norm_default_37 = None
        leaky_relu__default_37 = torch.ops.aten.leaky_relu_.default(getitem_111, 0.1);  getitem_111 = None
        convolution_default_38 = torch.ops.aten.convolution.default(leaky_relu__default_37, primals_205, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_210, primals_206, primals_208, primals_209, False, 0.03, 0.0001);  primals_206 = None
        getitem_114 = native_batch_norm_default_38[0];  native_batch_norm_default_38 = None
        leaky_relu__default_38 = torch.ops.aten.leaky_relu_.default(getitem_114, 0.1);  getitem_114 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(leaky_relu__default_38, add_tensor_15)
        convolution_default_39 = torch.ops.aten.convolution.default(add_tensor_16, primals_211, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_39, primals_216, primals_212, primals_214, primals_215, False, 0.03, 0.0001);  primals_212 = None
        getitem_117 = native_batch_norm_default_39[0];  native_batch_norm_default_39 = None
        leaky_relu__default_39 = torch.ops.aten.leaky_relu_.default(getitem_117, 0.1);  getitem_117 = None
        convolution_default_40 = torch.ops.aten.convolution.default(leaky_relu__default_39, primals_217, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_222, primals_218, primals_220, primals_221, False, 0.03, 0.0001);  primals_218 = None
        getitem_120 = native_batch_norm_default_40[0];  native_batch_norm_default_40 = None
        leaky_relu__default_40 = torch.ops.aten.leaky_relu_.default(getitem_120, 0.1);  getitem_120 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(leaky_relu__default_40, add_tensor_16)
        convolution_default_41 = torch.ops.aten.convolution.default(add_tensor_17, primals_223, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_41, primals_228, primals_224, primals_226, primals_227, False, 0.03, 0.0001);  primals_224 = None
        getitem_123 = native_batch_norm_default_41[0];  native_batch_norm_default_41 = None
        leaky_relu__default_41 = torch.ops.aten.leaky_relu_.default(getitem_123, 0.1);  getitem_123 = None
        convolution_default_42 = torch.ops.aten.convolution.default(leaky_relu__default_41, primals_235, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_42, primals_240, primals_236, primals_238, primals_239, False, 0.03, 0.0001);  primals_236 = None
        getitem_126 = native_batch_norm_default_42[0];  native_batch_norm_default_42 = None
        leaky_relu__default_42 = torch.ops.aten.leaky_relu_.default(getitem_126, 0.1);  getitem_126 = None
        add_tensor_18 = torch.ops.aten.add.Tensor(leaky_relu__default_42, add_tensor_17)
        convolution_default_43 = torch.ops.aten.convolution.default(add_tensor_18, primals_241, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_43, primals_246, primals_242, primals_244, primals_245, False, 0.03, 0.0001);  primals_242 = None
        getitem_129 = native_batch_norm_default_43[0];  native_batch_norm_default_43 = None
        leaky_relu__default_43 = torch.ops.aten.leaky_relu_.default(getitem_129, 0.1);  getitem_129 = None
        convolution_default_44 = torch.ops.aten.convolution.default(leaky_relu__default_43, primals_247, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_252, primals_248, primals_250, primals_251, False, 0.03, 0.0001);  primals_248 = None
        getitem_132 = native_batch_norm_default_44[0];  native_batch_norm_default_44 = None
        leaky_relu__default_44 = torch.ops.aten.leaky_relu_.default(getitem_132, 0.1);  getitem_132 = None
        convolution_default_45 = torch.ops.aten.convolution.default(leaky_relu__default_44, primals_253, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_45, primals_258, primals_254, primals_256, primals_257, False, 0.03, 0.0001);  primals_254 = None
        getitem_135 = native_batch_norm_default_45[0];  native_batch_norm_default_45 = None
        leaky_relu__default_45 = torch.ops.aten.leaky_relu_.default(getitem_135, 0.1);  getitem_135 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(leaky_relu__default_45, leaky_relu__default_43)
        convolution_default_46 = torch.ops.aten.convolution.default(add_tensor_19, primals_259, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(convolution_default_46, primals_264, primals_260, primals_262, primals_263, False, 0.03, 0.0001);  primals_260 = None
        getitem_138 = native_batch_norm_default_46[0];  native_batch_norm_default_46 = None
        leaky_relu__default_46 = torch.ops.aten.leaky_relu_.default(getitem_138, 0.1);  getitem_138 = None
        convolution_default_47 = torch.ops.aten.convolution.default(leaky_relu__default_46, primals_265, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(convolution_default_47, primals_270, primals_266, primals_268, primals_269, False, 0.03, 0.0001);  primals_266 = None
        getitem_141 = native_batch_norm_default_47[0];  native_batch_norm_default_47 = None
        leaky_relu__default_47 = torch.ops.aten.leaky_relu_.default(getitem_141, 0.1);  getitem_141 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(leaky_relu__default_47, add_tensor_19)
        convolution_default_48 = torch.ops.aten.convolution.default(add_tensor_20, primals_271, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_48, primals_276, primals_272, primals_274, primals_275, False, 0.03, 0.0001);  primals_272 = None
        getitem_144 = native_batch_norm_default_48[0];  native_batch_norm_default_48 = None
        leaky_relu__default_48 = torch.ops.aten.leaky_relu_.default(getitem_144, 0.1);  getitem_144 = None
        convolution_default_49 = torch.ops.aten.convolution.default(leaky_relu__default_48, primals_283, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(convolution_default_49, primals_288, primals_284, primals_286, primals_287, False, 0.03, 0.0001);  primals_284 = None
        getitem_147 = native_batch_norm_default_49[0];  native_batch_norm_default_49 = None
        leaky_relu__default_49 = torch.ops.aten.leaky_relu_.default(getitem_147, 0.1);  getitem_147 = None
        add_tensor_21 = torch.ops.aten.add.Tensor(leaky_relu__default_49, add_tensor_20)
        convolution_default_50 = torch.ops.aten.convolution.default(add_tensor_21, primals_289, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(convolution_default_50, primals_294, primals_290, primals_292, primals_293, False, 0.03, 0.0001);  primals_290 = None
        getitem_150 = native_batch_norm_default_50[0];  native_batch_norm_default_50 = None
        leaky_relu__default_50 = torch.ops.aten.leaky_relu_.default(getitem_150, 0.1);  getitem_150 = None
        convolution_default_51 = torch.ops.aten.convolution.default(leaky_relu__default_50, primals_295, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(convolution_default_51, primals_300, primals_296, primals_298, primals_299, False, 0.03, 0.0001);  primals_296 = None
        getitem_153 = native_batch_norm_default_51[0];  native_batch_norm_default_51 = None
        leaky_relu__default_51 = torch.ops.aten.leaky_relu_.default(getitem_153, 0.1);  getitem_153 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(leaky_relu__default_51, add_tensor_21)
        convolution_default_52 = torch.ops.aten.convolution.default(add_tensor_22, primals_301, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(convolution_default_52, primals_306, primals_302, primals_304, primals_305, False, 0.03, 0.0001);  primals_302 = None
        getitem_156 = native_batch_norm_default_52[0];  native_batch_norm_default_52 = None
        leaky_relu__default_52 = torch.ops.aten.leaky_relu_.default(getitem_156, 0.1);  getitem_156 = None
        convolution_default_53 = torch.ops.aten.convolution.default(leaky_relu__default_52, primals_307, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_53 = torch.ops.aten.native_batch_norm.default(convolution_default_53, primals_312, primals_308, primals_310, primals_311, False, 0.03, 0.0001);  primals_308 = None
        getitem_159 = native_batch_norm_default_53[0];  native_batch_norm_default_53 = None
        leaky_relu__default_53 = torch.ops.aten.leaky_relu_.default(getitem_159, 0.1);  getitem_159 = None
        convolution_default_54 = torch.ops.aten.convolution.default(leaky_relu__default_53, primals_313, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_54 = torch.ops.aten.native_batch_norm.default(convolution_default_54, primals_318, primals_314, primals_316, primals_317, False, 0.03, 0.0001);  primals_314 = None
        getitem_162 = native_batch_norm_default_54[0];  native_batch_norm_default_54 = None
        leaky_relu__default_54 = torch.ops.aten.leaky_relu_.default(getitem_162, 0.1);  getitem_162 = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(leaky_relu__default_54, [5, 5], [1, 1], [2, 2])
        getitem_165 = max_pool2d_with_indices_default[0]
        getitem_166 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        max_pool2d_with_indices_default_1 = torch.ops.aten.max_pool2d_with_indices.default(leaky_relu__default_54, [9, 9], [1, 1], [4, 4])
        getitem_167 = max_pool2d_with_indices_default_1[0]
        getitem_168 = max_pool2d_with_indices_default_1[1];  max_pool2d_with_indices_default_1 = None
        max_pool2d_with_indices_default_2 = torch.ops.aten.max_pool2d_with_indices.default(leaky_relu__default_54, [13, 13], [1, 1], [6, 6])
        getitem_169 = max_pool2d_with_indices_default_2[0]
        getitem_170 = max_pool2d_with_indices_default_2[1];  max_pool2d_with_indices_default_2 = None
        cat_default = torch.ops.aten.cat.default([getitem_169, getitem_167, getitem_165, leaky_relu__default_54], 1)
        convolution_default_55 = torch.ops.aten.convolution.default(cat_default, primals_325, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_55 = torch.ops.aten.native_batch_norm.default(convolution_default_55, primals_330, primals_326, primals_328, primals_329, False, 0.03, 0.0001);  primals_326 = None
        getitem_171 = native_batch_norm_default_55[0];  native_batch_norm_default_55 = None
        leaky_relu__default_55 = torch.ops.aten.leaky_relu_.default(getitem_171, 0.1);  getitem_171 = None
        convolution_default_56 = torch.ops.aten.convolution.default(leaky_relu__default_55, primals_331, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_56 = torch.ops.aten.native_batch_norm.default(convolution_default_56, primals_336, primals_332, primals_334, primals_335, False, 0.03, 0.0001);  primals_332 = None
        getitem_174 = native_batch_norm_default_56[0];  native_batch_norm_default_56 = None
        leaky_relu__default_56 = torch.ops.aten.leaky_relu_.default(getitem_174, 0.1);  getitem_174 = None
        convolution_default_57 = torch.ops.aten.convolution.default(leaky_relu__default_56, primals_337, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_57 = torch.ops.aten.native_batch_norm.default(convolution_default_57, primals_342, primals_338, primals_340, primals_341, False, 0.03, 0.0001);  primals_338 = None
        getitem_177 = native_batch_norm_default_57[0];  native_batch_norm_default_57 = None
        leaky_relu__default_57 = torch.ops.aten.leaky_relu_.default(getitem_177, 0.1);  getitem_177 = None
        convolution_default_58 = torch.ops.aten.convolution.default(leaky_relu__default_57, primals_343, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_58 = torch.ops.aten.native_batch_norm.default(convolution_default_58, primals_348, primals_344, primals_346, primals_347, False, 0.03, 0.0001);  primals_344 = None
        getitem_180 = native_batch_norm_default_58[0];  native_batch_norm_default_58 = None
        leaky_relu__default_58 = torch.ops.aten.leaky_relu_.default(getitem_180, 0.1);  getitem_180 = None
        convolution_default_59 = torch.ops.aten.convolution.default(leaky_relu__default_58, primals_350, primals_349, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_349 = None
        return [convolution_default_59, leaky_relu__default_1, leaky_relu__default_4, add_tensor_1, leaky_relu__default_9, add_tensor_3, add_tensor_4, add_tensor_5, add_tensor_6, add_tensor_7, add_tensor_8, add_tensor_9, add_tensor_10, leaky_relu__default_26, add_tensor_11, add_tensor_12, add_tensor_13, add_tensor_14, add_tensor_15, add_tensor_16, add_tensor_17, add_tensor_18, leaky_relu__default_43, add_tensor_19, add_tensor_20, add_tensor_21, leaky_relu__default_54, getitem_165, getitem_167, getitem_169, leaky_relu__default_57, convolution_default_22, primals_161, primals_163, primals_268, convolution_default_23, primals_89, leaky_relu__default_22, primals_167, primals_276, add_tensor_9, primals_172, primals_275, primals_168, primals_269, primals_166, leaky_relu__default_23, primals_160, primals_274, convolution_default_24, primals_169, primals_271, primals_162, primals_90, primals_259, primals_270, primals_280, primals_282, add_tensor_1, primals_197, leaky_relu__default_5, primals_46, add_tensor_15, leaky_relu__default_35, primals_233, convolution_default_6, add_tensor_7, primals_191, primals_288, convolution_default_36, add_tensor_3, convolution_default_20, primals_53, primals_238, leaky_relu__default_19, primals_281, convolution_default_12, primals_187, primals_186, leaky_relu__default_11, primals_277, primals_227, primals_52, primals_228, primals_185, primals_54, leaky_relu__default_6, primals_286, primals_196, leaky_relu__default_36, convolution_default_7, convolution_default_21, convolution_default_37, convolution_default_13, primals_55, leaky_relu__default_7, leaky_relu__default_20, leaky_relu__default_37, primals_5, leaky_relu__default_12, primals_47, convolution_default_8, convolution_default_38, primals_190, primals_239, leaky_relu__default_21, primals_234, primals_48, primals_49, primals_192, primals_198, primals_283, primals_4, primals_184, primals_229, primals_257, primals_232, primals_287, leaky_relu__default_13, primals_1, primals_289, primals_235, primals_241, primals_193, primals_240, add_tensor_8, add_tensor_4, primals_319, convolution_default_44, primals_154, primals_19, primals_157, leaky_relu__default_43, convolution_default_52, primals_11, primals_72, primals_25, primals_221, primals_318, add_tensor_12, primals_28, convolution_default_31, primals_84, primals_313, leaky_relu__default_30, primals_83, primals_317, add_tensor, primals_7, leaky_relu__default_3, primals_312, convolution_default_4, convolution_default_53, convolution_default, leaky_relu__default_52, primals_6, primals_216, convolution_default_45, leaky_relu__default_4, leaky_relu__default_44, primals_31, primals_82, primals_10, primals_226, getitem_166, primals_12, primals_16, primals_85, primals_78, primals_215, convolution_default_55, convolution_default_32, primals_151, primals_148, primals_220, getitem_168, primals_30, leaky_relu__default_31, primals_222, convolution_default_54, primals_29, primals_145, primals_17, primals_149, primals_311, add_tensor_19, getitem_170, primals_23, primals_73, leaky_relu__default_55, primals_18, primals_144, primals_156, primals_217, convolution_default_56, primals_77, primals_142, primals_22, cat_default, primals_150, primals_139, primals_143, leaky_relu__default_32, primals_24, leaky_relu__default_53, primals_13, primals_79, primals_223, primals_310, convolution_default_46, primals_76, convolution_default_5, primals_316, leaky_relu__default_45, primals_155, add_tensor_13, primals_112, primals_350, primals_65, add_tensor_6, leaky_relu__default_16, convolution_default_17, primals_357, primals_115, primals_103, primals_114, primals_101, primals_58, primals_354, leaky_relu__default_17, primals_329, primals_322, primals_351, convolution_default_18, primals_64, primals_323, primals_108, primals_356, leaky_relu__default_18, primals_106, convolution_default_19, primals_324, primals_59, primals_330, primals_328, primals_60, primals_355, primals_67, primals_109, primals_66, primals_61, primals_100, primals_107, primals_325, primals_113, primals_102, convolution_default_28, convolution_default_41, primals_96, primals_94, leaky_relu__default_27, primals_131, add_tensor_21, primals_250, primals_126, add_tensor_11, primals_264, convolution_default_50, leaky_relu__default_49, convolution_default_42, primals_253, primals_41, leaky_relu__default_41, add_tensor_18, primals_245, primals_91, primals_118, primals_247, primals_127, leaky_relu__default_28, primals_71, primals_252, convolution_default_51, primals_125, primals_263, convolution_default_29, leaky_relu__default_50, primals_244, leaky_relu__default_29, leaky_relu__default_42, primals_42, convolution_default_30, convolution_default_43, primals_258, primals_120, primals_119, primals_262, primals_95, primals_133, primals_265, primals_130, primals_124, primals_132, primals_121, primals_43, primals_246, leaky_relu__default_51, add_tensor_22, primals_97, primals_251, primals_300, primals_136, add_tensor_16, primals_214, add_tensor_20, leaky_relu__default_46, convolution_default_39, leaky_relu__default_38, primals_137, primals_256, primals_293, primals_174, primals_208, primals_307, primals_202, primals_298, convolution_default_47, primals_301, primals_210, convolution_default_40, primals_138, leaky_relu__default_47, primals_306, primals_173, convolution_default_48, leaky_relu__default_39, primals_181, primals_204, primals_295, leaky_relu__default_48, primals_179, primals_178, primals_180, primals_205, primals_299, primals_209, convolution_default_49, primals_175, primals_211, leaky_relu__default_54, primals_294, leaky_relu__default_40, primals_292, primals_199, add_tensor_17, primals_203, primals_304, primals_305, leaky_relu__default_24, add_tensor_10, add_tensor_2, convolution_default_33, convolution_default_9, convolution_default_25, leaky_relu__default_8, convolution_default_57, leaky_relu__default_2, convolution_default_58, leaky_relu__default_56, primals_343, leaky_relu__default_1, convolution_default_34, leaky_relu__default_33, primals_35, primals_40, convolution_default_27, leaky_relu__default_25, primals_334, convolution_default_10, leaky_relu__default_58, leaky_relu__default_10, convolution_default_11, leaky_relu__default_9, leaky_relu__default_57, primals_340, leaky_relu__default, convolution_default_2, primals_335, primals_347, primals_34, convolution_default_26, add_tensor_14, primals_346, primals_341, primals_37, convolution_default_35, convolution_default_1, primals_331, primals_36, primals_336, primals_342, primals_348, leaky_relu__default_34, primals_337, convolution_default_3, leaky_relu__default_26, convolution_default_14, convolution_default_15, leaky_relu__default_14, primals_70, add_tensor_5, primals_88, convolution_default_16, leaky_relu__default_15]
        
