
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/yolov3/yolov3_forward_4/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96):
        convolution_default = torch.ops.aten.convolution.default(primals_96, primals_35, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_40, primals_36, primals_38, primals_39, False, 0.03, 0.0001);  primals_36 = None
        getitem = native_batch_norm_default[0];  native_batch_norm_default = None
        leaky_relu__default = torch.ops.aten.leaky_relu_.default(getitem, 0.1);  getitem = None
        upsample_nearest2d_vec = torch.ops.aten.upsample_nearest2d.vec(leaky_relu__default, None, [2.0, 2.0])
        cat_default = torch.ops.aten.cat.default([upsample_nearest2d_vec, primals_95], 1);  primals_95 = None
        convolution_default_1 = torch.ops.aten.convolution.default(cat_default, primals_57, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_62, primals_58, primals_60, primals_61, False, 0.03, 0.0001);  primals_58 = None
        getitem_3 = native_batch_norm_default_1[0];  native_batch_norm_default_1 = None
        leaky_relu__default_1 = torch.ops.aten.leaky_relu_.default(getitem_3, 0.1);  getitem_3 = None
        convolution_default_2 = torch.ops.aten.convolution.default(leaky_relu__default_1, primals_63, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_68, primals_64, primals_66, primals_67, False, 0.03, 0.0001);  primals_64 = None
        getitem_6 = native_batch_norm_default_2[0];  native_batch_norm_default_2 = None
        leaky_relu__default_2 = torch.ops.aten.leaky_relu_.default(getitem_6, 0.1);  getitem_6 = None
        convolution_default_3 = torch.ops.aten.convolution.default(leaky_relu__default_2, primals_69, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_74, primals_70, primals_72, primals_73, False, 0.03, 0.0001);  primals_70 = None
        getitem_9 = native_batch_norm_default_3[0];  native_batch_norm_default_3 = None
        leaky_relu__default_3 = torch.ops.aten.leaky_relu_.default(getitem_9, 0.1);  getitem_9 = None
        convolution_default_4 = torch.ops.aten.convolution.default(leaky_relu__default_3, primals_75, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_80, primals_76, primals_78, primals_79, False, 0.03, 0.0001);  primals_76 = None
        getitem_12 = native_batch_norm_default_4[0];  native_batch_norm_default_4 = None
        leaky_relu__default_4 = torch.ops.aten.leaky_relu_.default(getitem_12, 0.1);  getitem_12 = None
        convolution_default_5 = torch.ops.aten.convolution.default(leaky_relu__default_4, primals_81, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_86, primals_82, primals_84, primals_85, False, 0.03, 0.0001);  primals_82 = None
        getitem_15 = native_batch_norm_default_5[0];  native_batch_norm_default_5 = None
        leaky_relu__default_5 = torch.ops.aten.leaky_relu_.default(getitem_15, 0.1);  getitem_15 = None
        convolution_default_6 = torch.ops.aten.convolution.default(leaky_relu__default_5, primals_87, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_92, primals_88, primals_90, primals_91, False, 0.03, 0.0001);  primals_88 = None
        getitem_18 = native_batch_norm_default_6[0];  native_batch_norm_default_6 = None
        leaky_relu__default_6 = torch.ops.aten.leaky_relu_.default(getitem_18, 0.1);  getitem_18 = None
        convolution_default_7 = torch.ops.aten.convolution.default(leaky_relu__default_6, primals_2, primals_1, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1 = None
        view_default = torch.ops.aten.view.default(convolution_default_7, [16, 3, 85, 24, 32])
        permute_default = torch.ops.aten.permute.default(view_default, [0, 1, 3, 4, 2]);  view_default = None
        clone_default = torch.ops.aten.clone.default(permute_default, memory_format = torch.contiguous_format);  permute_default = None
        clone_default_1 = torch.ops.aten.clone.default(clone_default)
        view_default_1 = torch.ops.aten.view.default(clone_default_1, [16, -1, 85])
        convolution_default_8 = torch.ops.aten.convolution.default(leaky_relu__default_5, primals_5, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_10, primals_6, primals_8, primals_9, False, 0.03, 0.0001);  primals_6 = None
        getitem_21 = native_batch_norm_default_7[0];  native_batch_norm_default_7 = None
        leaky_relu__default_7 = torch.ops.aten.leaky_relu_.default(getitem_21, 0.1);  getitem_21 = None
        upsample_nearest2d_vec_1 = torch.ops.aten.upsample_nearest2d.vec(leaky_relu__default_7, None, [2.0, 2.0])
        cat_default_1 = torch.ops.aten.cat.default([upsample_nearest2d_vec_1, primals_94], 1);  primals_94 = None
        convolution_default_9 = torch.ops.aten.convolution.default(cat_default_1, primals_11, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_16, primals_12, primals_14, primals_15, False, 0.03, 0.0001);  primals_12 = None
        getitem_24 = native_batch_norm_default_8[0];  native_batch_norm_default_8 = None
        leaky_relu__default_8 = torch.ops.aten.leaky_relu_.default(getitem_24, 0.1);  getitem_24 = None
        convolution_default_10 = torch.ops.aten.convolution.default(leaky_relu__default_8, primals_17, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_22, primals_18, primals_20, primals_21, False, 0.03, 0.0001);  primals_18 = None
        getitem_27 = native_batch_norm_default_9[0];  native_batch_norm_default_9 = None
        leaky_relu__default_9 = torch.ops.aten.leaky_relu_.default(getitem_27, 0.1);  getitem_27 = None
        convolution_default_11 = torch.ops.aten.convolution.default(leaky_relu__default_9, primals_23, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_28, primals_24, primals_26, primals_27, False, 0.03, 0.0001);  primals_24 = None
        getitem_30 = native_batch_norm_default_10[0];  native_batch_norm_default_10 = None
        leaky_relu__default_10 = torch.ops.aten.leaky_relu_.default(getitem_30, 0.1);  getitem_30 = None
        convolution_default_12 = torch.ops.aten.convolution.default(leaky_relu__default_10, primals_29, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_34, primals_30, primals_32, primals_33, False, 0.03, 0.0001);  primals_30 = None
        getitem_33 = native_batch_norm_default_11[0];  native_batch_norm_default_11 = None
        leaky_relu__default_11 = torch.ops.aten.leaky_relu_.default(getitem_33, 0.1);  getitem_33 = None
        convolution_default_13 = torch.ops.aten.convolution.default(leaky_relu__default_11, primals_41, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_46, primals_42, primals_44, primals_45, False, 0.03, 0.0001);  primals_42 = None
        getitem_36 = native_batch_norm_default_12[0];  native_batch_norm_default_12 = None
        leaky_relu__default_12 = torch.ops.aten.leaky_relu_.default(getitem_36, 0.1);  getitem_36 = None
        convolution_default_14 = torch.ops.aten.convolution.default(leaky_relu__default_12, primals_47, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_52, primals_48, primals_50, primals_51, False, 0.03, 0.0001);  primals_48 = None
        getitem_39 = native_batch_norm_default_13[0];  native_batch_norm_default_13 = None
        leaky_relu__default_13 = torch.ops.aten.leaky_relu_.default(getitem_39, 0.1);  getitem_39 = None
        convolution_default_15 = torch.ops.aten.convolution.default(leaky_relu__default_13, primals_54, primals_53, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_53 = None
        view_default_2 = torch.ops.aten.view.default(convolution_default_15, [16, 3, 85, 48, 64])
        permute_default_1 = torch.ops.aten.permute.default(view_default_2, [0, 1, 3, 4, 2]);  view_default_2 = None
        clone_default_2 = torch.ops.aten.clone.default(permute_default_1, memory_format = torch.contiguous_format);  permute_default_1 = None
        clone_default_3 = torch.ops.aten.clone.default(clone_default_2)
        view_default_3 = torch.ops.aten.view.default(clone_default_3, [16, -1, 85])
        cat_default_2 = torch.ops.aten.cat.default([primals_93, view_default_1, view_default_3], 1);  primals_93 = None
        return [cat_default_2, clone_default, clone_default_2, view_default_1, view_default_3, upsample_nearest2d_vec, leaky_relu__default_5, convolution_default_7, upsample_nearest2d_vec_1, convolution_default_15, primals_61, primals_62, primals_11, primals_45, primals_29, leaky_relu__default_10, primals_2, convolution_default_9, leaky_relu__default_11, primals_33, primals_75, primals_90, primals_72, primals_86, primals_85, leaky_relu__default_12, primals_15, primals_55, primals_69, convolution_default_13, primals_74, primals_54, primals_66, primals_27, primals_47, primals_80, primals_79, primals_34, primals_28, primals_39, convolution_default_14, primals_3, primals_14, primals_32, clone_default_3, primals_78, primals_16, primals_57, primals_68, primals_51, primals_63, primals_81, primals_73, primals_52, primals_84, leaky_relu__default_13, primals_50, primals_67, primals_5, primals_87, primals_46, primals_60, leaky_relu__default_8, primals_44, leaky_relu__default_6, convolution_default_4, leaky_relu__default_5, convolution_default_12, primals_92, convolution_default_10, primals_23, primals_96, convolution_default_1, primals_35, cat_default, primals_17, primals_91, leaky_relu__default_9, convolution_default_5, primals_21, primals_9, leaky_relu__default_1, convolution_default_11, primals_38, leaky_relu__default_7, convolution_default_6, primals_8, leaky_relu__default_2, primals_40, leaky_relu__default_4, primals_26, convolution_default, primals_22, convolution_default_8, primals_10, leaky_relu__default, convolution_default_2, primals_20, cat_default_1, clone_default_1, leaky_relu__default_3, convolution_default_3, primals_41]
        
