
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.register_buffer('_tensor_constant0', torch.empty([2], dtype=torch.float32))
        self.register_buffer('_tensor_constant1', torch.empty([2], dtype=torch.float32))
        self.load_state_dict(torch.load(r'torch_bench_graphs/yolov3/yolov3_joint_2/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, tangents_1, tangents_2, tangents_3, tangents_4, tangents_5, tangents_6, tangents_7, tangents_8, tangents_9, tangents_10, tangents_11, tangents_12, tangents_13, tangents_14, tangents_15, tangents_16, tangents_17, tangents_18):
        convolution_default = torch.ops.aten.convolution.default(primals_92, primals_33, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_38, primals_34, primals_36, primals_37, False, 0.03, 0.0001);  primals_34 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        new_zeros_default = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_2 = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        leaky_relu__default = torch.ops.aten.leaky_relu_.default(getitem, 0.1);  getitem = None
        upsample_nearest2d_vec = torch.ops.aten.upsample_nearest2d.vec(leaky_relu__default, None, [2.0, 2.0])
        cat_default = torch.ops.aten.cat.default([upsample_nearest2d_vec, primals_91], 1);  primals_91 = None
        convolution_default_1 = torch.ops.aten.convolution.default(cat_default, primals_53, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_58, primals_54, primals_56, primals_57, False, 0.03, 0.0001);  primals_54 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_5 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        leaky_relu__default_1 = torch.ops.aten.leaky_relu_.default(getitem_3, 0.1);  getitem_3 = None
        convolution_default_2 = torch.ops.aten.convolution.default(leaky_relu__default_1, primals_59, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_64, primals_60, primals_62, primals_63, False, 0.03, 0.0001);  primals_60 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_8 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        leaky_relu__default_2 = torch.ops.aten.leaky_relu_.default(getitem_6, 0.1);  getitem_6 = None
        convolution_default_3 = torch.ops.aten.convolution.default(leaky_relu__default_2, primals_65, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_70, primals_66, primals_68, primals_69, False, 0.03, 0.0001);  primals_66 = None
        getitem_9 = native_batch_norm_default_3[0]
        getitem_10 = native_batch_norm_default_3[1]
        getitem_11 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        new_zeros_default_9 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_10 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_11 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        leaky_relu__default_3 = torch.ops.aten.leaky_relu_.default(getitem_9, 0.1);  getitem_9 = None
        convolution_default_4 = torch.ops.aten.convolution.default(leaky_relu__default_3, primals_71, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_76, primals_72, primals_74, primals_75, False, 0.03, 0.0001);  primals_72 = None
        getitem_12 = native_batch_norm_default_4[0]
        getitem_13 = native_batch_norm_default_4[1]
        getitem_14 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        new_zeros_default_12 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_13 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_14 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        leaky_relu__default_4 = torch.ops.aten.leaky_relu_.default(getitem_12, 0.1);  getitem_12 = None
        convolution_default_5 = torch.ops.aten.convolution.default(leaky_relu__default_4, primals_77, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_82, primals_78, primals_80, primals_81, False, 0.03, 0.0001);  primals_78 = None
        getitem_15 = native_batch_norm_default_5[0]
        getitem_16 = native_batch_norm_default_5[1]
        getitem_17 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        new_zeros_default_15 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_16 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_17 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        leaky_relu__default_5 = torch.ops.aten.leaky_relu_.default(getitem_15, 0.1);  getitem_15 = None
        convolution_default_6 = torch.ops.aten.convolution.default(leaky_relu__default_5, primals_83, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_88, primals_84, primals_86, primals_87, False, 0.03, 0.0001);  primals_84 = None
        getitem_18 = native_batch_norm_default_6[0]
        getitem_19 = native_batch_norm_default_6[1]
        getitem_20 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        new_zeros_default_18 = torch.ops.aten.new_zeros.default(convolution_default_6, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_19 = torch.ops.aten.new_zeros.default(convolution_default_6, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_20 = torch.ops.aten.new_zeros.default(convolution_default_6, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        leaky_relu__default_6 = torch.ops.aten.leaky_relu_.default(getitem_18, 0.1);  getitem_18 = None
        convolution_default_7 = torch.ops.aten.convolution.default(leaky_relu__default_6, primals_2, primals_1, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1 = None
        _tensor_constant0 = self._tensor_constant0
        lift = torch.ops.aten.lift.default(_tensor_constant0);  _tensor_constant0 = None
        arange = torch.ops.aten.arange.default(24, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        arange_1 = torch.ops.aten.arange.default(32, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        view_default = torch.ops.aten.view.default(arange, [-1, 1]);  arange = None
        expand_default = torch.ops.aten.expand.default(view_default, [24, 32]);  view_default = None
        view_default_1 = torch.ops.aten.view.default(arange_1, [1, -1]);  arange_1 = None
        expand_default_1 = torch.ops.aten.expand.default(view_default_1, [24, 32]);  view_default_1 = None
        stack_default = torch.ops.aten.stack.default([expand_default_1, expand_default], 2);  expand_default_1 = expand_default = None
        view_default_2 = torch.ops.aten.view.default(stack_default, [1, 1, 24, 32, 2]);  stack_default = None
        _to_copy_default = torch.ops.aten._to_copy.default(view_default_2, dtype = torch.float32);  view_default_2 = None
        _to_copy_default_1 = torch.ops.aten._to_copy.default(primals_93, device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided);  primals_93 = None
        _to_copy_default_2 = torch.ops.aten._to_copy.default(primals_94, device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided);  primals_94 = None
        view_default_3 = torch.ops.aten.view.default(convolution_default_7, [16, 3, 85, 24, 32])
        permute_default = torch.ops.aten.permute.default(view_default_3, [0, 1, 3, 4, 2]);  view_default_3 = None
        clone_default = torch.ops.aten.clone.default(permute_default, memory_format = torch.contiguous_format);  permute_default = None
        clone_default_1 = torch.ops.aten.clone.default(clone_default)
        slice_tensor = torch.ops.aten.slice.Tensor(clone_default_1, 4, 0, 2)
        sigmoid_default = torch.ops.aten.sigmoid.default(slice_tensor);  slice_tensor = None
        add_tensor = torch.ops.aten.add.Tensor(sigmoid_default, _to_copy_default)
        slice_tensor_1 = torch.ops.aten.slice.Tensor(clone_default_1, 4, 0, 2)
        copy__default = torch.ops.aten.copy_.default(slice_tensor_1, add_tensor);  slice_tensor_1 = add_tensor = None
        slice_tensor_2 = torch.ops.aten.slice.Tensor(clone_default_1, 4, 2, 4)
        exp_default = torch.ops.aten.exp.default(slice_tensor_2);  slice_tensor_2 = None
        mul_tensor = torch.ops.aten.mul.Tensor(exp_default, _to_copy_default_2)
        slice_tensor_3 = torch.ops.aten.slice.Tensor(clone_default_1, 4, 2, 4)
        copy__default_1 = torch.ops.aten.copy_.default(slice_tensor_3, mul_tensor);  slice_tensor_3 = mul_tensor = None
        slice_tensor_4 = torch.ops.aten.slice.Tensor(clone_default_1, 4, 0, 4)
        mul__tensor = torch.ops.aten.mul_.Tensor(slice_tensor_4, 16);  slice_tensor_4 = None
        slice_tensor_5 = torch.ops.aten.slice.Tensor(clone_default_1, 4, 0, 4)
        copy__default_2 = torch.ops.aten.copy_.default(slice_tensor_5, mul__tensor);  slice_tensor_5 = mul__tensor = None
        slice_tensor_6 = torch.ops.aten.slice.Tensor(clone_default_1, 4, 4, 9223372036854775807)
        sigmoid__default = torch.ops.aten.sigmoid_.default(slice_tensor_6);  slice_tensor_6 = None
        view_default_4 = torch.ops.aten.view.default(clone_default_1, [16, -1, 85]);  clone_default_1 = None
        convolution_default_8 = torch.ops.aten.convolution.default(leaky_relu__default_5, primals_3, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_8, primals_4, primals_6, primals_7, False, 0.03, 0.0001);  primals_4 = None
        getitem_21 = native_batch_norm_default_7[0]
        getitem_22 = native_batch_norm_default_7[1]
        getitem_23 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        new_zeros_default_21 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_22 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_23 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        leaky_relu__default_7 = torch.ops.aten.leaky_relu_.default(getitem_21, 0.1);  getitem_21 = None
        upsample_nearest2d_vec_1 = torch.ops.aten.upsample_nearest2d.vec(leaky_relu__default_7, None, [2.0, 2.0])
        cat_default_1 = torch.ops.aten.cat.default([upsample_nearest2d_vec_1, primals_90], 1);  primals_90 = None
        convolution_default_9 = torch.ops.aten.convolution.default(cat_default_1, primals_9, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_14, primals_10, primals_12, primals_13, False, 0.03, 0.0001);  primals_10 = None
        getitem_24 = native_batch_norm_default_8[0]
        getitem_25 = native_batch_norm_default_8[1]
        getitem_26 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        new_zeros_default_24 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_25 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_26 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        leaky_relu__default_8 = torch.ops.aten.leaky_relu_.default(getitem_24, 0.1);  getitem_24 = None
        convolution_default_10 = torch.ops.aten.convolution.default(leaky_relu__default_8, primals_15, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_20, primals_16, primals_18, primals_19, False, 0.03, 0.0001);  primals_16 = None
        getitem_27 = native_batch_norm_default_9[0]
        getitem_28 = native_batch_norm_default_9[1]
        getitem_29 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        new_zeros_default_27 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_28 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_29 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        leaky_relu__default_9 = torch.ops.aten.leaky_relu_.default(getitem_27, 0.1);  getitem_27 = None
        convolution_default_11 = torch.ops.aten.convolution.default(leaky_relu__default_9, primals_21, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_26, primals_22, primals_24, primals_25, False, 0.03, 0.0001);  primals_22 = None
        getitem_30 = native_batch_norm_default_10[0]
        getitem_31 = native_batch_norm_default_10[1]
        getitem_32 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        new_zeros_default_30 = torch.ops.aten.new_zeros.default(convolution_default_11, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_31 = torch.ops.aten.new_zeros.default(convolution_default_11, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_32 = torch.ops.aten.new_zeros.default(convolution_default_11, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        leaky_relu__default_10 = torch.ops.aten.leaky_relu_.default(getitem_30, 0.1);  getitem_30 = None
        convolution_default_12 = torch.ops.aten.convolution.default(leaky_relu__default_10, primals_27, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_32, primals_28, primals_30, primals_31, False, 0.03, 0.0001);  primals_28 = None
        getitem_33 = native_batch_norm_default_11[0]
        getitem_34 = native_batch_norm_default_11[1]
        getitem_35 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        new_zeros_default_33 = torch.ops.aten.new_zeros.default(convolution_default_12, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_34 = torch.ops.aten.new_zeros.default(convolution_default_12, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_35 = torch.ops.aten.new_zeros.default(convolution_default_12, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        leaky_relu__default_11 = torch.ops.aten.leaky_relu_.default(getitem_33, 0.1);  getitem_33 = None
        convolution_default_13 = torch.ops.aten.convolution.default(leaky_relu__default_11, primals_39, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_44, primals_40, primals_42, primals_43, False, 0.03, 0.0001);  primals_40 = None
        getitem_36 = native_batch_norm_default_12[0]
        getitem_37 = native_batch_norm_default_12[1]
        getitem_38 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        new_zeros_default_36 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_37 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_38 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        leaky_relu__default_12 = torch.ops.aten.leaky_relu_.default(getitem_36, 0.1);  getitem_36 = None
        convolution_default_14 = torch.ops.aten.convolution.default(leaky_relu__default_12, primals_45, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_50, primals_46, primals_48, primals_49, False, 0.03, 0.0001);  primals_46 = None
        getitem_39 = native_batch_norm_default_13[0]
        getitem_40 = native_batch_norm_default_13[1]
        getitem_41 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        new_zeros_default_39 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_40 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_41 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        leaky_relu__default_13 = torch.ops.aten.leaky_relu_.default(getitem_39, 0.1);  getitem_39 = None
        convolution_default_15 = torch.ops.aten.convolution.default(leaky_relu__default_13, primals_52, primals_51, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_51 = None
        _tensor_constant1 = self._tensor_constant1
        lift_1 = torch.ops.aten.lift.default(_tensor_constant1);  _tensor_constant1 = None
        arange_2 = torch.ops.aten.arange.default(48, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        arange_3 = torch.ops.aten.arange.default(64, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        view_default_5 = torch.ops.aten.view.default(arange_2, [-1, 1]);  arange_2 = None
        expand_default_2 = torch.ops.aten.expand.default(view_default_5, [48, 64]);  view_default_5 = None
        view_default_6 = torch.ops.aten.view.default(arange_3, [1, -1]);  arange_3 = None
        expand_default_3 = torch.ops.aten.expand.default(view_default_6, [48, 64]);  view_default_6 = None
        stack_default_1 = torch.ops.aten.stack.default([expand_default_3, expand_default_2], 2);  expand_default_3 = expand_default_2 = None
        view_default_7 = torch.ops.aten.view.default(stack_default_1, [1, 1, 48, 64, 2]);  stack_default_1 = None
        _to_copy_default_3 = torch.ops.aten._to_copy.default(view_default_7, dtype = torch.float32);  view_default_7 = None
        _to_copy_default_4 = torch.ops.aten._to_copy.default(primals_95, device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided);  primals_95 = None
        _to_copy_default_5 = torch.ops.aten._to_copy.default(primals_96, device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided);  primals_96 = None
        view_default_8 = torch.ops.aten.view.default(convolution_default_15, [16, 3, 85, 48, 64])
        permute_default_1 = torch.ops.aten.permute.default(view_default_8, [0, 1, 3, 4, 2]);  view_default_8 = None
        clone_default_2 = torch.ops.aten.clone.default(permute_default_1, memory_format = torch.contiguous_format);  permute_default_1 = None
        clone_default_3 = torch.ops.aten.clone.default(clone_default_2)
        slice_tensor_7 = torch.ops.aten.slice.Tensor(clone_default_3, 4, 0, 2)
        sigmoid_default_1 = torch.ops.aten.sigmoid.default(slice_tensor_7);  slice_tensor_7 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(sigmoid_default_1, _to_copy_default_3)
        slice_tensor_8 = torch.ops.aten.slice.Tensor(clone_default_3, 4, 0, 2)
        copy__default_3 = torch.ops.aten.copy_.default(slice_tensor_8, add_tensor_1);  slice_tensor_8 = add_tensor_1 = None
        slice_tensor_9 = torch.ops.aten.slice.Tensor(clone_default_3, 4, 2, 4)
        exp_default_1 = torch.ops.aten.exp.default(slice_tensor_9);  slice_tensor_9 = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(exp_default_1, _to_copy_default_5)
        slice_tensor_10 = torch.ops.aten.slice.Tensor(clone_default_3, 4, 2, 4)
        copy__default_4 = torch.ops.aten.copy_.default(slice_tensor_10, mul_tensor_1);  slice_tensor_10 = mul_tensor_1 = None
        slice_tensor_11 = torch.ops.aten.slice.Tensor(clone_default_3, 4, 0, 4)
        mul__tensor_1 = torch.ops.aten.mul_.Tensor(slice_tensor_11, 8);  slice_tensor_11 = None
        slice_tensor_12 = torch.ops.aten.slice.Tensor(clone_default_3, 4, 0, 4)
        copy__default_5 = torch.ops.aten.copy_.default(slice_tensor_12, mul__tensor_1);  slice_tensor_12 = mul__tensor_1 = None
        slice_tensor_13 = torch.ops.aten.slice.Tensor(clone_default_3, 4, 4, 9223372036854775807)
        sigmoid__default_1 = torch.ops.aten.sigmoid_.default(slice_tensor_13);  slice_tensor_13 = None
        view_default_9 = torch.ops.aten.view.default(clone_default_3, [16, -1, 85]);  clone_default_3 = None
        cat_default_2 = torch.ops.aten.cat.default([primals_89, view_default_4, view_default_9], 1);  primals_89 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(cat_default_2, tangents_1)
        is_same_size_default_1 = torch.ops.aten.is_same_size.default(clone_default, tangents_2)
        is_same_size_default_2 = torch.ops.aten.is_same_size.default(clone_default_2, tangents_3)
        is_same_size_default_3 = torch.ops.aten.is_same_size.default(view_default_4, tangents_12)
        is_same_size_default_4 = torch.ops.aten.is_same_size.default(view_default_9, tangents_13)
        is_same_size_default_5 = torch.ops.aten.is_same_size.default(upsample_nearest2d_vec, tangents_14)
        is_same_size_default_6 = torch.ops.aten.is_same_size.default(leaky_relu__default_5, tangents_15)
        is_same_size_default_7 = torch.ops.aten.is_same_size.default(convolution_default_7, tangents_16)
        is_same_size_default_8 = torch.ops.aten.is_same_size.default(upsample_nearest2d_vec_1, tangents_17)
        is_same_size_default_9 = torch.ops.aten.is_same_size.default(convolution_default_15, tangents_18)
        slice_tensor_14 = torch.ops.aten.slice.Tensor(tangents_1, 1, 0, 576)
        slice_tensor_15 = torch.ops.aten.slice.Tensor(tangents_1, 1, 576, 2880)
        slice_tensor_16 = torch.ops.aten.slice.Tensor(tangents_1, 1, 2880, 12096);  tangents_1 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(tangents_12, slice_tensor_15);  tangents_12 = slice_tensor_15 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(tangents_13, slice_tensor_16);  tangents_13 = slice_tensor_16 = None
        view_default_10 = torch.ops.aten.view.default(add_tensor_3, [16, 3, 48, 64, 85]);  add_tensor_3 = None
        new_empty_strided_default = torch.ops.aten.new_empty_strided.default(view_default_10, [16, 3, 48, 64, 85], [783360, 261120, 5440, 85, 1])
        copy__default_6 = torch.ops.aten.copy_.default(new_empty_strided_default, view_default_10);  new_empty_strided_default = view_default_10 = None
        as_strided_default = torch.ops.aten.as_strided.default(copy__default_6, [16, 3, 48, 64, 81], [783360, 261120, 5440, 85, 1], 4)
        clone_default_4 = torch.ops.aten.clone.default(as_strided_default, memory_format = torch.contiguous_format)
        to_dtype = torch.ops.aten.to.dtype(clone_default_4, torch.float32);  clone_default_4 = None
        to_dtype_1 = torch.ops.aten.to.dtype(sigmoid__default_1, torch.float32);  sigmoid__default_1 = None
        rsub_scalar = torch.ops.aten.rsub.Scalar(to_dtype_1, 1)
        mul_tensor_2 = torch.ops.aten.mul.Tensor(to_dtype_1, rsub_scalar);  to_dtype_1 = rsub_scalar = None
        conj_physical_default = torch.ops.aten.conj_physical.default(mul_tensor_2);  mul_tensor_2 = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(to_dtype, conj_physical_default);  to_dtype = conj_physical_default = None
        to_dtype_2 = torch.ops.aten.to.dtype(mul_tensor_3, torch.float32);  mul_tensor_3 = None
        copy__default_7 = torch.ops.aten.copy_.default(as_strided_default, to_dtype_2);  as_strided_default = to_dtype_2 = None
        new_empty_strided_default_1 = torch.ops.aten.new_empty_strided.default(copy__default_6, [16, 3, 48, 64, 85], [783360, 261120, 5440, 85, 1])
        copy__default_8 = torch.ops.aten.copy_.default(new_empty_strided_default_1, copy__default_6);  new_empty_strided_default_1 = copy__default_6 = None
        as_strided_default_1 = torch.ops.aten.as_strided.default(copy__default_8, [16, 3, 48, 64, 4], [783360, 261120, 5440, 85, 1], 0)
        clone_default_5 = torch.ops.aten.clone.default(as_strided_default_1, memory_format = torch.contiguous_format)
        empty_like_default = torch.ops.aten.empty_like.default(clone_default_5, memory_format = torch.contiguous_format)
        zero__default = torch.ops.aten.zero_.default(empty_like_default);  empty_like_default = None
        copy__default_9 = torch.ops.aten.copy_.default(as_strided_default_1, zero__default);  as_strided_default_1 = zero__default = None
        new_empty_default = torch.ops.aten.new_empty.default(clone_default_5, [12533760])
        zero__default_1 = torch.ops.aten.zero_.default(new_empty_default);  new_empty_default = None
        as_strided_default_2 = torch.ops.aten.as_strided.default(zero__default_1, [16, 3, 48, 64, 4], [783360, 261120, 5440, 85, 1], 0)
        copy__default_10 = torch.ops.aten.copy_.default(as_strided_default_2, clone_default_5);  as_strided_default_2 = clone_default_5 = None
        as_strided_default_3 = torch.ops.aten.as_strided.default(zero__default_1, [16, 3, 48, 64, 85], [783360, 261120, 5440, 85, 1], 0);  zero__default_1 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(copy__default_8, as_strided_default_3);  copy__default_8 = as_strided_default_3 = None
        new_empty_strided_default_2 = torch.ops.aten.new_empty_strided.default(add_tensor_4, [16, 3, 48, 64, 85], [783360, 261120, 5440, 85, 1])
        copy__default_11 = torch.ops.aten.copy_.default(new_empty_strided_default_2, add_tensor_4);  new_empty_strided_default_2 = add_tensor_4 = None
        as_strided_default_4 = torch.ops.aten.as_strided.default(copy__default_11, [16, 3, 48, 64, 4], [783360, 261120, 5440, 85, 1], 0)
        clone_default_6 = torch.ops.aten.clone.default(as_strided_default_4, memory_format = torch.contiguous_format)
        mul_tensor_4 = torch.ops.aten.mul.Tensor(clone_default_6, 8);  clone_default_6 = None
        copy__default_12 = torch.ops.aten.copy_.default(as_strided_default_4, mul_tensor_4);  as_strided_default_4 = mul_tensor_4 = None
        new_empty_strided_default_3 = torch.ops.aten.new_empty_strided.default(copy__default_11, [16, 3, 48, 64, 85], [783360, 261120, 5440, 85, 1])
        copy__default_13 = torch.ops.aten.copy_.default(new_empty_strided_default_3, copy__default_11);  new_empty_strided_default_3 = copy__default_11 = None
        as_strided_default_5 = torch.ops.aten.as_strided.default(copy__default_13, [16, 3, 48, 64, 2], [783360, 261120, 5440, 85, 1], 2)
        clone_default_7 = torch.ops.aten.clone.default(as_strided_default_5, memory_format = torch.contiguous_format)
        empty_like_default_1 = torch.ops.aten.empty_like.default(clone_default_7, memory_format = torch.contiguous_format)
        zero__default_2 = torch.ops.aten.zero_.default(empty_like_default_1);  empty_like_default_1 = None
        copy__default_14 = torch.ops.aten.copy_.default(as_strided_default_5, zero__default_2);  as_strided_default_5 = zero__default_2 = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(clone_default_7, _to_copy_default_5);  clone_default_7 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(mul_tensor_5, exp_default_1);  mul_tensor_5 = exp_default_1 = None
        slice_backward_default = torch.ops.aten.slice_backward.default(mul_tensor_6, [16, 3, 48, 64, 85], 4, 2, 4, 1);  mul_tensor_6 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(copy__default_13, slice_backward_default);  copy__default_13 = slice_backward_default = None
        new_empty_strided_default_4 = torch.ops.aten.new_empty_strided.default(add_tensor_5, [16, 3, 48, 64, 85], [783360, 261120, 5440, 85, 1])
        copy__default_15 = torch.ops.aten.copy_.default(new_empty_strided_default_4, add_tensor_5);  new_empty_strided_default_4 = add_tensor_5 = None
        as_strided_default_6 = torch.ops.aten.as_strided.default(copy__default_15, [16, 3, 48, 64, 2], [783360, 261120, 5440, 85, 1], 0)
        clone_default_8 = torch.ops.aten.clone.default(as_strided_default_6, memory_format = torch.contiguous_format)
        empty_like_default_2 = torch.ops.aten.empty_like.default(clone_default_8, memory_format = torch.contiguous_format)
        zero__default_3 = torch.ops.aten.zero_.default(empty_like_default_2);  empty_like_default_2 = None
        copy__default_16 = torch.ops.aten.copy_.default(as_strided_default_6, zero__default_3);  as_strided_default_6 = zero__default_3 = None
        to_dtype_3 = torch.ops.aten.to.dtype(clone_default_8, torch.float32);  clone_default_8 = None
        to_dtype_4 = torch.ops.aten.to.dtype(sigmoid_default_1, torch.float32);  sigmoid_default_1 = None
        rsub_scalar_1 = torch.ops.aten.rsub.Scalar(to_dtype_4, 1)
        mul_tensor_7 = torch.ops.aten.mul.Tensor(to_dtype_4, rsub_scalar_1);  to_dtype_4 = rsub_scalar_1 = None
        conj_physical_default_1 = torch.ops.aten.conj_physical.default(mul_tensor_7);  mul_tensor_7 = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(to_dtype_3, conj_physical_default_1);  to_dtype_3 = conj_physical_default_1 = None
        to_dtype_5 = torch.ops.aten.to.dtype(mul_tensor_8, torch.float32);  mul_tensor_8 = None
        slice_backward_default_1 = torch.ops.aten.slice_backward.default(to_dtype_5, [16, 3, 48, 64, 85], 4, 0, 2, 1);  to_dtype_5 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(copy__default_15, slice_backward_default_1);  copy__default_15 = slice_backward_default_1 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(tangents_3, add_tensor_6);  tangents_3 = add_tensor_6 = None
        permute_default_2 = torch.ops.aten.permute.default(add_tensor_7, [0, 1, 4, 2, 3]);  add_tensor_7 = None
        clone_default_9 = torch.ops.aten.clone.default(permute_default_2, memory_format = torch.contiguous_format);  permute_default_2 = None
        _unsafe_view_default = torch.ops.aten._unsafe_view.default(clone_default_9, [16, 255, 48, 64]);  clone_default_9 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(tangents_18, _unsafe_view_default);  tangents_18 = _unsafe_view_default = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(add_tensor_8, leaky_relu__default_13, primals_52, [255], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  add_tensor_8 = primals_52 = None
        getitem_42 = convolution_backward_default[0]
        getitem_43 = convolution_backward_default[1]
        getitem_44 = convolution_backward_default[2];  convolution_backward_default = None
        to_dtype_6 = torch.ops.aten.to.dtype(getitem_42, torch.float32);  getitem_42 = None
        to_dtype_7 = torch.ops.aten.to.dtype(leaky_relu__default_13, torch.float32);  leaky_relu__default_13 = None
        gt_scalar = torch.ops.aten.gt.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(to_dtype_6, 0.1)
        where_self = torch.ops.aten.where.self(gt_scalar, to_dtype_6, mul_tensor_9);  gt_scalar = to_dtype_6 = mul_tensor_9 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_8, convolution_default_14, primals_50, primals_48, primals_49, new_zeros_default_39, new_zeros_default_40, False, 0.0001, [True, True, True]);  to_dtype_8 = convolution_default_14 = primals_50 = primals_48 = primals_49 = new_zeros_default_39 = new_zeros_default_40 = None
        getitem_45 = native_batch_norm_backward_default[0]
        getitem_46 = native_batch_norm_backward_default[1]
        getitem_47 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_45, leaky_relu__default_12, primals_45, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_45 = primals_45 = None
        getitem_48 = convolution_backward_default_1[0]
        getitem_49 = convolution_backward_default_1[1]
        getitem_50 = convolution_backward_default_1[2];  convolution_backward_default_1 = None
        to_dtype_9 = torch.ops.aten.to.dtype(getitem_48, torch.float32);  getitem_48 = None
        to_dtype_10 = torch.ops.aten.to.dtype(leaky_relu__default_12, torch.float32);  leaky_relu__default_12 = None
        gt_scalar_1 = torch.ops.aten.gt.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        mul_tensor_10 = torch.ops.aten.mul.Tensor(to_dtype_9, 0.1)
        where_self_1 = torch.ops.aten.where.self(gt_scalar_1, to_dtype_9, mul_tensor_10);  gt_scalar_1 = to_dtype_9 = mul_tensor_10 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_13, primals_44, primals_42, primals_43, new_zeros_default_36, new_zeros_default_37, False, 0.0001, [True, True, True]);  to_dtype_11 = convolution_default_13 = primals_44 = primals_42 = primals_43 = new_zeros_default_36 = new_zeros_default_37 = None
        getitem_51 = native_batch_norm_backward_default_1[0]
        getitem_52 = native_batch_norm_backward_default_1[1]
        getitem_53 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_51, leaky_relu__default_11, primals_39, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_51 = primals_39 = None
        getitem_54 = convolution_backward_default_2[0]
        getitem_55 = convolution_backward_default_2[1]
        getitem_56 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        to_dtype_12 = torch.ops.aten.to.dtype(getitem_54, torch.float32);  getitem_54 = None
        to_dtype_13 = torch.ops.aten.to.dtype(leaky_relu__default_11, torch.float32);  leaky_relu__default_11 = None
        gt_scalar_2 = torch.ops.aten.gt.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        mul_tensor_11 = torch.ops.aten.mul.Tensor(to_dtype_12, 0.1)
        where_self_2 = torch.ops.aten.where.self(gt_scalar_2, to_dtype_12, mul_tensor_11);  gt_scalar_2 = to_dtype_12 = mul_tensor_11 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_12, primals_32, primals_30, primals_31, new_zeros_default_33, new_zeros_default_34, False, 0.0001, [True, True, True]);  to_dtype_14 = convolution_default_12 = primals_32 = primals_30 = primals_31 = new_zeros_default_33 = new_zeros_default_34 = None
        getitem_57 = native_batch_norm_backward_default_2[0]
        getitem_58 = native_batch_norm_backward_default_2[1]
        getitem_59 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_57, leaky_relu__default_10, primals_27, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_57 = primals_27 = None
        getitem_60 = convolution_backward_default_3[0]
        getitem_61 = convolution_backward_default_3[1]
        getitem_62 = convolution_backward_default_3[2];  convolution_backward_default_3 = None
        to_dtype_15 = torch.ops.aten.to.dtype(getitem_60, torch.float32);  getitem_60 = None
        to_dtype_16 = torch.ops.aten.to.dtype(leaky_relu__default_10, torch.float32);  leaky_relu__default_10 = None
        gt_scalar_3 = torch.ops.aten.gt.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        mul_tensor_12 = torch.ops.aten.mul.Tensor(to_dtype_15, 0.1)
        where_self_3 = torch.ops.aten.where.self(gt_scalar_3, to_dtype_15, mul_tensor_12);  gt_scalar_3 = to_dtype_15 = mul_tensor_12 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_17, convolution_default_11, primals_26, primals_24, primals_25, new_zeros_default_30, new_zeros_default_31, False, 0.0001, [True, True, True]);  to_dtype_17 = convolution_default_11 = primals_26 = primals_24 = primals_25 = new_zeros_default_30 = new_zeros_default_31 = None
        getitem_63 = native_batch_norm_backward_default_3[0]
        getitem_64 = native_batch_norm_backward_default_3[1]
        getitem_65 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_63, leaky_relu__default_9, primals_21, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_63 = primals_21 = None
        getitem_66 = convolution_backward_default_4[0]
        getitem_67 = convolution_backward_default_4[1]
        getitem_68 = convolution_backward_default_4[2];  convolution_backward_default_4 = None
        to_dtype_18 = torch.ops.aten.to.dtype(getitem_66, torch.float32);  getitem_66 = None
        to_dtype_19 = torch.ops.aten.to.dtype(leaky_relu__default_9, torch.float32);  leaky_relu__default_9 = None
        gt_scalar_4 = torch.ops.aten.gt.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(to_dtype_18, 0.1)
        where_self_4 = torch.ops.aten.where.self(gt_scalar_4, to_dtype_18, mul_tensor_13);  gt_scalar_4 = to_dtype_18 = mul_tensor_13 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_20, convolution_default_10, primals_20, primals_18, primals_19, new_zeros_default_27, new_zeros_default_28, False, 0.0001, [True, True, True]);  to_dtype_20 = convolution_default_10 = primals_20 = primals_18 = primals_19 = new_zeros_default_27 = new_zeros_default_28 = None
        getitem_69 = native_batch_norm_backward_default_4[0]
        getitem_70 = native_batch_norm_backward_default_4[1]
        getitem_71 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_69, leaky_relu__default_8, primals_15, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_69 = primals_15 = None
        getitem_72 = convolution_backward_default_5[0]
        getitem_73 = convolution_backward_default_5[1]
        getitem_74 = convolution_backward_default_5[2];  convolution_backward_default_5 = None
        to_dtype_21 = torch.ops.aten.to.dtype(getitem_72, torch.float32);  getitem_72 = None
        to_dtype_22 = torch.ops.aten.to.dtype(leaky_relu__default_8, torch.float32);  leaky_relu__default_8 = None
        gt_scalar_5 = torch.ops.aten.gt.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        mul_tensor_14 = torch.ops.aten.mul.Tensor(to_dtype_21, 0.1)
        where_self_5 = torch.ops.aten.where.self(gt_scalar_5, to_dtype_21, mul_tensor_14);  gt_scalar_5 = to_dtype_21 = mul_tensor_14 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_23, convolution_default_9, primals_14, primals_12, primals_13, new_zeros_default_24, new_zeros_default_25, False, 0.0001, [True, True, True]);  to_dtype_23 = convolution_default_9 = primals_14 = primals_12 = primals_13 = new_zeros_default_24 = new_zeros_default_25 = None
        getitem_75 = native_batch_norm_backward_default_5[0]
        getitem_76 = native_batch_norm_backward_default_5[1]
        getitem_77 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(getitem_75, cat_default_1, primals_9, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_75 = cat_default_1 = primals_9 = None
        getitem_78 = convolution_backward_default_6[0]
        getitem_79 = convolution_backward_default_6[1]
        getitem_80 = convolution_backward_default_6[2];  convolution_backward_default_6 = None
        slice_tensor_17 = torch.ops.aten.slice.Tensor(getitem_78, 1, 0, 128)
        slice_tensor_18 = torch.ops.aten.slice.Tensor(getitem_78, 1, 128, 384);  getitem_78 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(tangents_17, slice_tensor_17);  tangents_17 = slice_tensor_17 = None
        upsample_nearest2d_backward_vec = torch.ops.aten.upsample_nearest2d_backward.vec(add_tensor_9, None, [16, 128, 24, 32], [2.0, 2.0]);  add_tensor_9 = None
        to_dtype_24 = torch.ops.aten.to.dtype(upsample_nearest2d_backward_vec, torch.float32);  upsample_nearest2d_backward_vec = None
        to_dtype_25 = torch.ops.aten.to.dtype(leaky_relu__default_7, torch.float32);  leaky_relu__default_7 = None
        gt_scalar_6 = torch.ops.aten.gt.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        mul_tensor_15 = torch.ops.aten.mul.Tensor(to_dtype_24, 0.1)
        where_self_6 = torch.ops.aten.where.self(gt_scalar_6, to_dtype_24, mul_tensor_15);  gt_scalar_6 = to_dtype_24 = mul_tensor_15 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_8, primals_8, primals_6, primals_7, new_zeros_default_21, new_zeros_default_22, False, 0.0001, [True, True, True]);  to_dtype_26 = convolution_default_8 = primals_8 = primals_6 = primals_7 = new_zeros_default_21 = new_zeros_default_22 = None
        getitem_81 = native_batch_norm_backward_default_6[0]
        getitem_82 = native_batch_norm_backward_default_6[1]
        getitem_83 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(getitem_81, leaky_relu__default_5, primals_3, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_81 = primals_3 = None
        getitem_84 = convolution_backward_default_7[0]
        getitem_85 = convolution_backward_default_7[1]
        getitem_86 = convolution_backward_default_7[2];  convolution_backward_default_7 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(tangents_15, getitem_84);  tangents_15 = getitem_84 = None
        view_default_11 = torch.ops.aten.view.default(add_tensor_2, [16, 3, 24, 32, 85]);  add_tensor_2 = None
        new_empty_strided_default_5 = torch.ops.aten.new_empty_strided.default(view_default_11, [16, 3, 24, 32, 85], [195840, 65280, 2720, 85, 1])
        copy__default_17 = torch.ops.aten.copy_.default(new_empty_strided_default_5, view_default_11);  new_empty_strided_default_5 = view_default_11 = None
        as_strided_default_7 = torch.ops.aten.as_strided.default(copy__default_17, [16, 3, 24, 32, 81], [195840, 65280, 2720, 85, 1], 4)
        clone_default_10 = torch.ops.aten.clone.default(as_strided_default_7, memory_format = torch.contiguous_format)
        to_dtype_27 = torch.ops.aten.to.dtype(clone_default_10, torch.float32);  clone_default_10 = None
        to_dtype_28 = torch.ops.aten.to.dtype(sigmoid__default, torch.float32);  sigmoid__default = None
        rsub_scalar_2 = torch.ops.aten.rsub.Scalar(to_dtype_28, 1)
        mul_tensor_16 = torch.ops.aten.mul.Tensor(to_dtype_28, rsub_scalar_2);  to_dtype_28 = rsub_scalar_2 = None
        conj_physical_default_2 = torch.ops.aten.conj_physical.default(mul_tensor_16);  mul_tensor_16 = None
        mul_tensor_17 = torch.ops.aten.mul.Tensor(to_dtype_27, conj_physical_default_2);  to_dtype_27 = conj_physical_default_2 = None
        to_dtype_29 = torch.ops.aten.to.dtype(mul_tensor_17, torch.float32);  mul_tensor_17 = None
        copy__default_18 = torch.ops.aten.copy_.default(as_strided_default_7, to_dtype_29);  as_strided_default_7 = to_dtype_29 = None
        new_empty_strided_default_6 = torch.ops.aten.new_empty_strided.default(copy__default_17, [16, 3, 24, 32, 85], [195840, 65280, 2720, 85, 1])
        copy__default_19 = torch.ops.aten.copy_.default(new_empty_strided_default_6, copy__default_17);  new_empty_strided_default_6 = copy__default_17 = None
        as_strided_default_8 = torch.ops.aten.as_strided.default(copy__default_19, [16, 3, 24, 32, 4], [195840, 65280, 2720, 85, 1], 0)
        clone_default_11 = torch.ops.aten.clone.default(as_strided_default_8, memory_format = torch.contiguous_format)
        empty_like_default_3 = torch.ops.aten.empty_like.default(clone_default_11, memory_format = torch.contiguous_format)
        zero__default_4 = torch.ops.aten.zero_.default(empty_like_default_3);  empty_like_default_3 = None
        copy__default_20 = torch.ops.aten.copy_.default(as_strided_default_8, zero__default_4);  as_strided_default_8 = zero__default_4 = None
        new_empty_default_1 = torch.ops.aten.new_empty.default(clone_default_11, [3133440])
        zero__default_5 = torch.ops.aten.zero_.default(new_empty_default_1);  new_empty_default_1 = None
        as_strided_default_9 = torch.ops.aten.as_strided.default(zero__default_5, [16, 3, 24, 32, 4], [195840, 65280, 2720, 85, 1], 0)
        copy__default_21 = torch.ops.aten.copy_.default(as_strided_default_9, clone_default_11);  as_strided_default_9 = clone_default_11 = None
        as_strided_default_10 = torch.ops.aten.as_strided.default(zero__default_5, [16, 3, 24, 32, 85], [195840, 65280, 2720, 85, 1], 0);  zero__default_5 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(copy__default_19, as_strided_default_10);  copy__default_19 = as_strided_default_10 = None
        new_empty_strided_default_7 = torch.ops.aten.new_empty_strided.default(add_tensor_11, [16, 3, 24, 32, 85], [195840, 65280, 2720, 85, 1])
        copy__default_22 = torch.ops.aten.copy_.default(new_empty_strided_default_7, add_tensor_11);  new_empty_strided_default_7 = add_tensor_11 = None
        as_strided_default_11 = torch.ops.aten.as_strided.default(copy__default_22, [16, 3, 24, 32, 4], [195840, 65280, 2720, 85, 1], 0)
        clone_default_12 = torch.ops.aten.clone.default(as_strided_default_11, memory_format = torch.contiguous_format)
        mul_tensor_18 = torch.ops.aten.mul.Tensor(clone_default_12, 16);  clone_default_12 = None
        copy__default_23 = torch.ops.aten.copy_.default(as_strided_default_11, mul_tensor_18);  as_strided_default_11 = mul_tensor_18 = None
        new_empty_strided_default_8 = torch.ops.aten.new_empty_strided.default(copy__default_22, [16, 3, 24, 32, 85], [195840, 65280, 2720, 85, 1])
        copy__default_24 = torch.ops.aten.copy_.default(new_empty_strided_default_8, copy__default_22);  new_empty_strided_default_8 = copy__default_22 = None
        as_strided_default_12 = torch.ops.aten.as_strided.default(copy__default_24, [16, 3, 24, 32, 2], [195840, 65280, 2720, 85, 1], 2)
        clone_default_13 = torch.ops.aten.clone.default(as_strided_default_12, memory_format = torch.contiguous_format)
        empty_like_default_4 = torch.ops.aten.empty_like.default(clone_default_13, memory_format = torch.contiguous_format)
        zero__default_6 = torch.ops.aten.zero_.default(empty_like_default_4);  empty_like_default_4 = None
        copy__default_25 = torch.ops.aten.copy_.default(as_strided_default_12, zero__default_6);  as_strided_default_12 = zero__default_6 = None
        mul_tensor_19 = torch.ops.aten.mul.Tensor(clone_default_13, _to_copy_default_2);  clone_default_13 = None
        mul_tensor_20 = torch.ops.aten.mul.Tensor(mul_tensor_19, exp_default);  mul_tensor_19 = exp_default = None
        slice_backward_default_2 = torch.ops.aten.slice_backward.default(mul_tensor_20, [16, 3, 24, 32, 85], 4, 2, 4, 1);  mul_tensor_20 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(copy__default_24, slice_backward_default_2);  copy__default_24 = slice_backward_default_2 = None
        new_empty_strided_default_9 = torch.ops.aten.new_empty_strided.default(add_tensor_12, [16, 3, 24, 32, 85], [195840, 65280, 2720, 85, 1])
        copy__default_26 = torch.ops.aten.copy_.default(new_empty_strided_default_9, add_tensor_12);  new_empty_strided_default_9 = add_tensor_12 = None
        as_strided_default_13 = torch.ops.aten.as_strided.default(copy__default_26, [16, 3, 24, 32, 2], [195840, 65280, 2720, 85, 1], 0)
        clone_default_14 = torch.ops.aten.clone.default(as_strided_default_13, memory_format = torch.contiguous_format)
        empty_like_default_5 = torch.ops.aten.empty_like.default(clone_default_14, memory_format = torch.contiguous_format)
        zero__default_7 = torch.ops.aten.zero_.default(empty_like_default_5);  empty_like_default_5 = None
        copy__default_27 = torch.ops.aten.copy_.default(as_strided_default_13, zero__default_7);  as_strided_default_13 = zero__default_7 = None
        to_dtype_30 = torch.ops.aten.to.dtype(clone_default_14, torch.float32);  clone_default_14 = None
        to_dtype_31 = torch.ops.aten.to.dtype(sigmoid_default, torch.float32);  sigmoid_default = None
        rsub_scalar_3 = torch.ops.aten.rsub.Scalar(to_dtype_31, 1)
        mul_tensor_21 = torch.ops.aten.mul.Tensor(to_dtype_31, rsub_scalar_3);  to_dtype_31 = rsub_scalar_3 = None
        conj_physical_default_3 = torch.ops.aten.conj_physical.default(mul_tensor_21);  mul_tensor_21 = None
        mul_tensor_22 = torch.ops.aten.mul.Tensor(to_dtype_30, conj_physical_default_3);  to_dtype_30 = conj_physical_default_3 = None
        to_dtype_32 = torch.ops.aten.to.dtype(mul_tensor_22, torch.float32);  mul_tensor_22 = None
        slice_backward_default_3 = torch.ops.aten.slice_backward.default(to_dtype_32, [16, 3, 24, 32, 85], 4, 0, 2, 1);  to_dtype_32 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(copy__default_26, slice_backward_default_3);  copy__default_26 = slice_backward_default_3 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(tangents_2, add_tensor_13);  tangents_2 = add_tensor_13 = None
        permute_default_3 = torch.ops.aten.permute.default(add_tensor_14, [0, 1, 4, 2, 3]);  add_tensor_14 = None
        clone_default_15 = torch.ops.aten.clone.default(permute_default_3, memory_format = torch.contiguous_format);  permute_default_3 = None
        _unsafe_view_default_1 = torch.ops.aten._unsafe_view.default(clone_default_15, [16, 255, 24, 32]);  clone_default_15 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(tangents_16, _unsafe_view_default_1);  tangents_16 = _unsafe_view_default_1 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(add_tensor_15, leaky_relu__default_6, primals_2, [255], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  add_tensor_15 = primals_2 = None
        getitem_87 = convolution_backward_default_8[0]
        getitem_88 = convolution_backward_default_8[1]
        getitem_89 = convolution_backward_default_8[2];  convolution_backward_default_8 = None
        to_dtype_33 = torch.ops.aten.to.dtype(getitem_87, torch.float32);  getitem_87 = None
        to_dtype_34 = torch.ops.aten.to.dtype(leaky_relu__default_6, torch.float32);  leaky_relu__default_6 = None
        gt_scalar_7 = torch.ops.aten.gt.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        mul_tensor_23 = torch.ops.aten.mul.Tensor(to_dtype_33, 0.1)
        where_self_7 = torch.ops.aten.where.self(gt_scalar_7, to_dtype_33, mul_tensor_23);  gt_scalar_7 = to_dtype_33 = mul_tensor_23 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_35, convolution_default_6, primals_88, primals_86, primals_87, new_zeros_default_18, new_zeros_default_19, False, 0.0001, [True, True, True]);  to_dtype_35 = convolution_default_6 = primals_88 = primals_86 = primals_87 = new_zeros_default_18 = new_zeros_default_19 = None
        getitem_90 = native_batch_norm_backward_default_7[0]
        getitem_91 = native_batch_norm_backward_default_7[1]
        getitem_92 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_90, leaky_relu__default_5, primals_83, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_90 = primals_83 = None
        getitem_93 = convolution_backward_default_9[0]
        getitem_94 = convolution_backward_default_9[1]
        getitem_95 = convolution_backward_default_9[2];  convolution_backward_default_9 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(add_tensor_10, getitem_93);  add_tensor_10 = getitem_93 = None
        to_dtype_36 = torch.ops.aten.to.dtype(add_tensor_16, torch.float32);  add_tensor_16 = None
        to_dtype_37 = torch.ops.aten.to.dtype(leaky_relu__default_5, torch.float32)
        gt_scalar_8 = torch.ops.aten.gt.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        mul_tensor_24 = torch.ops.aten.mul.Tensor(to_dtype_36, 0.1)
        where_self_8 = torch.ops.aten.where.self(gt_scalar_8, to_dtype_36, mul_tensor_24);  gt_scalar_8 = to_dtype_36 = mul_tensor_24 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_38, convolution_default_5, primals_82, primals_80, primals_81, new_zeros_default_15, new_zeros_default_16, False, 0.0001, [True, True, True]);  to_dtype_38 = convolution_default_5 = primals_82 = primals_80 = primals_81 = new_zeros_default_15 = new_zeros_default_16 = None
        getitem_96 = native_batch_norm_backward_default_8[0]
        getitem_97 = native_batch_norm_backward_default_8[1]
        getitem_98 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_96, leaky_relu__default_4, primals_77, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_96 = primals_77 = None
        getitem_99 = convolution_backward_default_10[0]
        getitem_100 = convolution_backward_default_10[1]
        getitem_101 = convolution_backward_default_10[2];  convolution_backward_default_10 = None
        to_dtype_39 = torch.ops.aten.to.dtype(getitem_99, torch.float32);  getitem_99 = None
        to_dtype_40 = torch.ops.aten.to.dtype(leaky_relu__default_4, torch.float32);  leaky_relu__default_4 = None
        gt_scalar_9 = torch.ops.aten.gt.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        mul_tensor_25 = torch.ops.aten.mul.Tensor(to_dtype_39, 0.1)
        where_self_9 = torch.ops.aten.where.self(gt_scalar_9, to_dtype_39, mul_tensor_25);  gt_scalar_9 = to_dtype_39 = mul_tensor_25 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_41, convolution_default_4, primals_76, primals_74, primals_75, new_zeros_default_12, new_zeros_default_13, False, 0.0001, [True, True, True]);  to_dtype_41 = convolution_default_4 = primals_76 = primals_74 = primals_75 = new_zeros_default_12 = new_zeros_default_13 = None
        getitem_102 = native_batch_norm_backward_default_9[0]
        getitem_103 = native_batch_norm_backward_default_9[1]
        getitem_104 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_102, leaky_relu__default_3, primals_71, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_102 = primals_71 = None
        getitem_105 = convolution_backward_default_11[0]
        getitem_106 = convolution_backward_default_11[1]
        getitem_107 = convolution_backward_default_11[2];  convolution_backward_default_11 = None
        to_dtype_42 = torch.ops.aten.to.dtype(getitem_105, torch.float32);  getitem_105 = None
        to_dtype_43 = torch.ops.aten.to.dtype(leaky_relu__default_3, torch.float32);  leaky_relu__default_3 = None
        gt_scalar_10 = torch.ops.aten.gt.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        mul_tensor_26 = torch.ops.aten.mul.Tensor(to_dtype_42, 0.1)
        where_self_10 = torch.ops.aten.where.self(gt_scalar_10, to_dtype_42, mul_tensor_26);  gt_scalar_10 = to_dtype_42 = mul_tensor_26 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_44, convolution_default_3, primals_70, primals_68, primals_69, new_zeros_default_9, new_zeros_default_10, False, 0.0001, [True, True, True]);  to_dtype_44 = convolution_default_3 = primals_70 = primals_68 = primals_69 = new_zeros_default_9 = new_zeros_default_10 = None
        getitem_108 = native_batch_norm_backward_default_10[0]
        getitem_109 = native_batch_norm_backward_default_10[1]
        getitem_110 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(getitem_108, leaky_relu__default_2, primals_65, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_108 = primals_65 = None
        getitem_111 = convolution_backward_default_12[0]
        getitem_112 = convolution_backward_default_12[1]
        getitem_113 = convolution_backward_default_12[2];  convolution_backward_default_12 = None
        to_dtype_45 = torch.ops.aten.to.dtype(getitem_111, torch.float32);  getitem_111 = None
        to_dtype_46 = torch.ops.aten.to.dtype(leaky_relu__default_2, torch.float32);  leaky_relu__default_2 = None
        gt_scalar_11 = torch.ops.aten.gt.Scalar(to_dtype_46, 0);  to_dtype_46 = None
        mul_tensor_27 = torch.ops.aten.mul.Tensor(to_dtype_45, 0.1)
        where_self_11 = torch.ops.aten.where.self(gt_scalar_11, to_dtype_45, mul_tensor_27);  gt_scalar_11 = to_dtype_45 = mul_tensor_27 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_47, convolution_default_2, primals_64, primals_62, primals_63, new_zeros_default_6, new_zeros_default_7, False, 0.0001, [True, True, True]);  to_dtype_47 = convolution_default_2 = primals_64 = primals_62 = primals_63 = new_zeros_default_6 = new_zeros_default_7 = None
        getitem_114 = native_batch_norm_backward_default_11[0]
        getitem_115 = native_batch_norm_backward_default_11[1]
        getitem_116 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_114, leaky_relu__default_1, primals_59, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_114 = primals_59 = None
        getitem_117 = convolution_backward_default_13[0]
        getitem_118 = convolution_backward_default_13[1]
        getitem_119 = convolution_backward_default_13[2];  convolution_backward_default_13 = None
        to_dtype_48 = torch.ops.aten.to.dtype(getitem_117, torch.float32);  getitem_117 = None
        to_dtype_49 = torch.ops.aten.to.dtype(leaky_relu__default_1, torch.float32);  leaky_relu__default_1 = None
        gt_scalar_12 = torch.ops.aten.gt.Scalar(to_dtype_49, 0);  to_dtype_49 = None
        mul_tensor_28 = torch.ops.aten.mul.Tensor(to_dtype_48, 0.1)
        where_self_12 = torch.ops.aten.where.self(gt_scalar_12, to_dtype_48, mul_tensor_28);  gt_scalar_12 = to_dtype_48 = mul_tensor_28 = None
        to_dtype_50 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_50, convolution_default_1, primals_58, primals_56, primals_57, new_zeros_default_3, new_zeros_default_4, False, 0.0001, [True, True, True]);  to_dtype_50 = convolution_default_1 = primals_58 = primals_56 = primals_57 = new_zeros_default_3 = new_zeros_default_4 = None
        getitem_120 = native_batch_norm_backward_default_12[0]
        getitem_121 = native_batch_norm_backward_default_12[1]
        getitem_122 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_120, cat_default, primals_53, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_120 = cat_default = primals_53 = None
        getitem_123 = convolution_backward_default_14[0]
        getitem_124 = convolution_backward_default_14[1]
        getitem_125 = convolution_backward_default_14[2];  convolution_backward_default_14 = None
        slice_tensor_19 = torch.ops.aten.slice.Tensor(getitem_123, 1, 0, 256)
        slice_tensor_20 = torch.ops.aten.slice.Tensor(getitem_123, 1, 256, 768);  getitem_123 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(tangents_14, slice_tensor_19);  tangents_14 = slice_tensor_19 = None
        upsample_nearest2d_backward_vec_1 = torch.ops.aten.upsample_nearest2d_backward.vec(add_tensor_17, None, [16, 256, 12, 16], [2.0, 2.0]);  add_tensor_17 = None
        to_dtype_51 = torch.ops.aten.to.dtype(upsample_nearest2d_backward_vec_1, torch.float32);  upsample_nearest2d_backward_vec_1 = None
        to_dtype_52 = torch.ops.aten.to.dtype(leaky_relu__default, torch.float32);  leaky_relu__default = None
        gt_scalar_13 = torch.ops.aten.gt.Scalar(to_dtype_52, 0);  to_dtype_52 = None
        mul_tensor_29 = torch.ops.aten.mul.Tensor(to_dtype_51, 0.1)
        where_self_13 = torch.ops.aten.where.self(gt_scalar_13, to_dtype_51, mul_tensor_29);  gt_scalar_13 = to_dtype_51 = mul_tensor_29 = None
        to_dtype_53 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_53, convolution_default, primals_38, primals_36, primals_37, new_zeros_default, new_zeros_default_1, False, 0.0001, [True, True, True]);  to_dtype_53 = convolution_default = primals_38 = primals_36 = primals_37 = new_zeros_default = new_zeros_default_1 = None
        getitem_126 = native_batch_norm_backward_default_13[0]
        getitem_127 = native_batch_norm_backward_default_13[1]
        getitem_128 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_126, primals_92, primals_33, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_126 = primals_92 = primals_33 = None
        getitem_129 = convolution_backward_default_15[0]
        getitem_130 = convolution_backward_default_15[1]
        getitem_131 = convolution_backward_default_15[2];  convolution_backward_default_15 = None
        return [cat_default_2, clone_default, clone_default_2, lift, _to_copy_default, _to_copy_default_1, _to_copy_default_2, lift_1, _to_copy_default_3, _to_copy_default_4, _to_copy_default_5, view_default_4, view_default_9, upsample_nearest2d_vec, leaky_relu__default_5, convolution_default_7, upsample_nearest2d_vec_1, convolution_default_15, getitem_89, getitem_88, getitem_85, getitem_83, None, None, None, getitem_82, getitem_79, getitem_77, None, None, None, getitem_76, getitem_73, getitem_71, None, None, None, getitem_70, getitem_67, getitem_65, None, None, None, getitem_64, getitem_61, getitem_59, None, None, None, getitem_58, getitem_130, getitem_128, None, None, None, getitem_127, getitem_55, getitem_53, None, None, None, getitem_52, getitem_49, getitem_47, None, None, None, getitem_46, getitem_44, getitem_43, getitem_124, getitem_122, None, None, None, getitem_121, getitem_118, getitem_116, None, None, None, getitem_115, getitem_112, getitem_110, None, None, None, getitem_109, getitem_106, getitem_104, None, None, None, getitem_103, getitem_100, getitem_98, None, None, None, getitem_97, getitem_94, getitem_92, None, None, None, getitem_91, slice_tensor_14, slice_tensor_18, slice_tensor_20, getitem_129, None, None, None, None]
        
