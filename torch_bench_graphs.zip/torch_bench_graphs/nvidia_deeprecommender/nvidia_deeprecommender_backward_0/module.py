
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/nvidia_deeprecommender/nvidia_deeprecommender_backward_0/state_dict.pt'))

    
    
    def forward(self, to_dtype_1, t_default_4, to_dtype_7, primals_13, addmm_default_1, addmm_default_4, t_default_2, t_default_5, to_dtype_3, to_dtype_9, addmm_default_2, addmm_default, addmm_default_5, addmm_default_3, t_default_3, to_dtype_5, t_default_1, tangents_1):
        to_dtype_12 = torch.ops.aten.to.dtype(tangents_1, torch.float32);  tangents_1 = None
        to_dtype_13 = torch.ops.aten.to.dtype(addmm_default_5, torch.float32);  addmm_default_5 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_13, 0)
        mul_tensor_18 = torch.ops.aten.mul.Tensor(to_dtype_12, 1)
        mul_tensor_19 = torch.ops.aten.mul.Tensor(mul_tensor_18, 1.7580993408473766);  mul_tensor_18 = None
        mul_tensor_20 = torch.ops.aten.mul.Tensor(to_dtype_13, 1);  to_dtype_13 = None
        exp_default_6 = torch.ops.aten.exp.default(mul_tensor_20);  mul_tensor_20 = None
        mul_tensor_21 = torch.ops.aten.mul.Tensor(mul_tensor_19, exp_default_6);  mul_tensor_19 = exp_default_6 = None
        mul_tensor_22 = torch.ops.aten.mul.Tensor(to_dtype_12, 1.0507009873554805);  to_dtype_12 = None
        where_self_6 = torch.ops.aten.where.self(le_scalar, mul_tensor_21, mul_tensor_22);  le_scalar = mul_tensor_21 = mul_tensor_22 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        t_default_6 = torch.ops.aten.t.default(t_default_5);  t_default_5 = None
        mm_default = torch.ops.aten.mm.default(to_dtype_14, t_default_6);  t_default_6 = None
        t_default_7 = torch.ops.aten.t.default(to_dtype_14)
        mm_default_1 = torch.ops.aten.mm.default(t_default_7, to_dtype_9);  t_default_7 = to_dtype_9 = None
        t_default_8 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(to_dtype_14, [0], True);  to_dtype_14 = None
        view_default = torch.ops.aten.view.default(sum_dim_int_list, [197951]);  sum_dim_int_list = None
        t_default_9 = torch.ops.aten.t.default(t_default_8);  t_default_8 = None
        to_dtype_15 = torch.ops.aten.to.dtype(mm_default, torch.float32);  mm_default = None
        to_dtype_16 = torch.ops.aten.to.dtype(addmm_default_4, torch.float32);  addmm_default_4 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_16, 0)
        mul_tensor_23 = torch.ops.aten.mul.Tensor(to_dtype_15, 1)
        mul_tensor_24 = torch.ops.aten.mul.Tensor(mul_tensor_23, 1.7580993408473766);  mul_tensor_23 = None
        mul_tensor_25 = torch.ops.aten.mul.Tensor(to_dtype_16, 1);  to_dtype_16 = None
        exp_default_7 = torch.ops.aten.exp.default(mul_tensor_25);  mul_tensor_25 = None
        mul_tensor_26 = torch.ops.aten.mul.Tensor(mul_tensor_24, exp_default_7);  mul_tensor_24 = exp_default_7 = None
        mul_tensor_27 = torch.ops.aten.mul.Tensor(to_dtype_15, 1.0507009873554805);  to_dtype_15 = None
        where_self_7 = torch.ops.aten.where.self(le_scalar_1, mul_tensor_26, mul_tensor_27);  le_scalar_1 = mul_tensor_26 = mul_tensor_27 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        t_default_10 = torch.ops.aten.t.default(t_default_4);  t_default_4 = None
        mm_default_2 = torch.ops.aten.mm.default(to_dtype_17, t_default_10);  t_default_10 = None
        t_default_11 = torch.ops.aten.t.default(to_dtype_17)
        mm_default_3 = torch.ops.aten.mm.default(t_default_11, to_dtype_7);  t_default_11 = to_dtype_7 = None
        t_default_12 = torch.ops.aten.t.default(mm_default_3);  mm_default_3 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(to_dtype_17, [0], True);  to_dtype_17 = None
        view_default_1 = torch.ops.aten.view.default(sum_dim_int_list_1, [512]);  sum_dim_int_list_1 = None
        t_default_13 = torch.ops.aten.t.default(t_default_12);  t_default_12 = None
        to_dtype_18 = torch.ops.aten.to.dtype(mm_default_2, torch.float32);  mm_default_2 = None
        to_dtype_19 = torch.ops.aten.to.dtype(addmm_default_3, torch.float32);  addmm_default_3 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_19, 0)
        mul_tensor_28 = torch.ops.aten.mul.Tensor(to_dtype_18, 1)
        mul_tensor_29 = torch.ops.aten.mul.Tensor(mul_tensor_28, 1.7580993408473766);  mul_tensor_28 = None
        mul_tensor_30 = torch.ops.aten.mul.Tensor(to_dtype_19, 1);  to_dtype_19 = None
        exp_default_8 = torch.ops.aten.exp.default(mul_tensor_30);  mul_tensor_30 = None
        mul_tensor_31 = torch.ops.aten.mul.Tensor(mul_tensor_29, exp_default_8);  mul_tensor_29 = exp_default_8 = None
        mul_tensor_32 = torch.ops.aten.mul.Tensor(to_dtype_18, 1.0507009873554805);  to_dtype_18 = None
        where_self_8 = torch.ops.aten.where.self(le_scalar_2, mul_tensor_31, mul_tensor_32);  le_scalar_2 = mul_tensor_31 = mul_tensor_32 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        t_default_14 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        mm_default_4 = torch.ops.aten.mm.default(to_dtype_20, t_default_14);  t_default_14 = None
        t_default_15 = torch.ops.aten.t.default(to_dtype_20)
        mm_default_5 = torch.ops.aten.mm.default(t_default_15, to_dtype_5);  t_default_15 = to_dtype_5 = None
        t_default_16 = torch.ops.aten.t.default(mm_default_5);  mm_default_5 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(to_dtype_20, [0], True);  to_dtype_20 = None
        view_default_2 = torch.ops.aten.view.default(sum_dim_int_list_2, [512]);  sum_dim_int_list_2 = None
        t_default_17 = torch.ops.aten.t.default(t_default_16);  t_default_16 = None
        to_dtype_21 = torch.ops.aten.to.dtype(mm_default_4, torch.float32);  mm_default_4 = None
        to_dtype_22 = torch.ops.aten.to.dtype(addmm_default_2, torch.float32);  addmm_default_2 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_22, 0)
        mul_tensor_33 = torch.ops.aten.mul.Tensor(to_dtype_21, 1)
        mul_tensor_34 = torch.ops.aten.mul.Tensor(mul_tensor_33, 1.7580993408473766);  mul_tensor_33 = None
        mul_tensor_35 = torch.ops.aten.mul.Tensor(to_dtype_22, 1);  to_dtype_22 = None
        exp_default_9 = torch.ops.aten.exp.default(mul_tensor_35);  mul_tensor_35 = None
        mul_tensor_36 = torch.ops.aten.mul.Tensor(mul_tensor_34, exp_default_9);  mul_tensor_34 = exp_default_9 = None
        mul_tensor_37 = torch.ops.aten.mul.Tensor(to_dtype_21, 1.0507009873554805);  to_dtype_21 = None
        where_self_9 = torch.ops.aten.where.self(le_scalar_3, mul_tensor_36, mul_tensor_37);  le_scalar_3 = mul_tensor_36 = mul_tensor_37 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        t_default_18 = torch.ops.aten.t.default(t_default_2);  t_default_2 = None
        mm_default_6 = torch.ops.aten.mm.default(to_dtype_23, t_default_18);  t_default_18 = None
        t_default_19 = torch.ops.aten.t.default(to_dtype_23)
        mm_default_7 = torch.ops.aten.mm.default(t_default_19, to_dtype_3);  t_default_19 = to_dtype_3 = None
        t_default_20 = torch.ops.aten.t.default(mm_default_7);  mm_default_7 = None
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(to_dtype_23, [0], True);  to_dtype_23 = None
        view_default_3 = torch.ops.aten.view.default(sum_dim_int_list_3, [1024]);  sum_dim_int_list_3 = None
        t_default_21 = torch.ops.aten.t.default(t_default_20);  t_default_20 = None
        to_dtype_24 = torch.ops.aten.to.dtype(mm_default_6, torch.float32);  mm_default_6 = None
        to_dtype_25 = torch.ops.aten.to.dtype(addmm_default_1, torch.float32);  addmm_default_1 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_25, 0)
        mul_tensor_38 = torch.ops.aten.mul.Tensor(to_dtype_24, 1)
        mul_tensor_39 = torch.ops.aten.mul.Tensor(mul_tensor_38, 1.7580993408473766);  mul_tensor_38 = None
        mul_tensor_40 = torch.ops.aten.mul.Tensor(to_dtype_25, 1);  to_dtype_25 = None
        exp_default_10 = torch.ops.aten.exp.default(mul_tensor_40);  mul_tensor_40 = None
        mul_tensor_41 = torch.ops.aten.mul.Tensor(mul_tensor_39, exp_default_10);  mul_tensor_39 = exp_default_10 = None
        mul_tensor_42 = torch.ops.aten.mul.Tensor(to_dtype_24, 1.0507009873554805);  to_dtype_24 = None
        where_self_10 = torch.ops.aten.where.self(le_scalar_4, mul_tensor_41, mul_tensor_42);  le_scalar_4 = mul_tensor_41 = mul_tensor_42 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        t_default_22 = torch.ops.aten.t.default(t_default_1);  t_default_1 = None
        mm_default_8 = torch.ops.aten.mm.default(to_dtype_26, t_default_22);  t_default_22 = None
        t_default_23 = torch.ops.aten.t.default(to_dtype_26)
        mm_default_9 = torch.ops.aten.mm.default(t_default_23, to_dtype_1);  t_default_23 = to_dtype_1 = None
        t_default_24 = torch.ops.aten.t.default(mm_default_9);  mm_default_9 = None
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(to_dtype_26, [0], True);  to_dtype_26 = None
        view_default_4 = torch.ops.aten.view.default(sum_dim_int_list_4, [512]);  sum_dim_int_list_4 = None
        t_default_25 = torch.ops.aten.t.default(t_default_24);  t_default_24 = None
        to_dtype_27 = torch.ops.aten.to.dtype(mm_default_8, torch.float32);  mm_default_8 = None
        to_dtype_28 = torch.ops.aten.to.dtype(addmm_default, torch.float32);  addmm_default = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_28, 0)
        mul_tensor_43 = torch.ops.aten.mul.Tensor(to_dtype_27, 1)
        mul_tensor_44 = torch.ops.aten.mul.Tensor(mul_tensor_43, 1.7580993408473766);  mul_tensor_43 = None
        mul_tensor_45 = torch.ops.aten.mul.Tensor(to_dtype_28, 1);  to_dtype_28 = None
        exp_default_11 = torch.ops.aten.exp.default(mul_tensor_45);  mul_tensor_45 = None
        mul_tensor_46 = torch.ops.aten.mul.Tensor(mul_tensor_44, exp_default_11);  mul_tensor_44 = exp_default_11 = None
        mul_tensor_47 = torch.ops.aten.mul.Tensor(to_dtype_27, 1.0507009873554805);  to_dtype_27 = None
        where_self_11 = torch.ops.aten.where.self(le_scalar_5, mul_tensor_46, mul_tensor_47);  le_scalar_5 = mul_tensor_46 = mul_tensor_47 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        t_default_26 = torch.ops.aten.t.default(to_dtype_29)
        mm_default_10 = torch.ops.aten.mm.default(t_default_26, primals_13);  t_default_26 = primals_13 = None
        t_default_27 = torch.ops.aten.t.default(mm_default_10);  mm_default_10 = None
        sum_dim_int_list_5 = torch.ops.aten.sum.dim_IntList(to_dtype_29, [0], True);  to_dtype_29 = None
        view_default_5 = torch.ops.aten.view.default(sum_dim_int_list_5, [512]);  sum_dim_int_list_5 = None
        t_default_28 = torch.ops.aten.t.default(t_default_27);  t_default_27 = None
        return [t_default_17, t_default_13, t_default_9, t_default_28, t_default_25, t_default_21, view_default_5, view_default_2, view_default_4, view_default_1, view_default_3, view_default, None]
        
