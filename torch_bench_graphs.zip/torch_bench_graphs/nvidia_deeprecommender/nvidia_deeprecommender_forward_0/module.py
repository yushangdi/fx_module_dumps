
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/nvidia_deeprecommender/nvidia_deeprecommender_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13):
        t_default = torch.ops.aten.t.default(primals_4);  primals_4 = None
        addmm_default = torch.ops.aten.addmm.default(primals_7, primals_13, t_default);  primals_7 = t_default = None
        to_dtype = torch.ops.aten.to.dtype(addmm_default, torch.float32)
        gt_scalar = torch.ops.aten.gt.Scalar(to_dtype, 0)
        mul_tensor = torch.ops.aten.mul.Tensor(to_dtype, 1.0507009873554805)
        mul_tensor_1 = torch.ops.aten.mul.Tensor(to_dtype, 1);  to_dtype = None
        exp_default = torch.ops.aten.exp.default(mul_tensor_1);  mul_tensor_1 = None
        sub_tensor = torch.ops.aten.sub.Tensor(exp_default, 1);  exp_default = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(sub_tensor, 1.7580993408473766);  sub_tensor = None
        where_self = torch.ops.aten.where.self(gt_scalar, mul_tensor, mul_tensor_2);  gt_scalar = mul_tensor = mul_tensor_2 = None
        to_dtype_1 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        t_default_1 = torch.ops.aten.t.default(primals_5);  primals_5 = None
        addmm_default_1 = torch.ops.aten.addmm.default(primals_9, to_dtype_1, t_default_1);  primals_9 = None
        to_dtype_2 = torch.ops.aten.to.dtype(addmm_default_1, torch.float32)
        gt_scalar_1 = torch.ops.aten.gt.Scalar(to_dtype_2, 0)
        mul_tensor_3 = torch.ops.aten.mul.Tensor(to_dtype_2, 1.0507009873554805)
        mul_tensor_4 = torch.ops.aten.mul.Tensor(to_dtype_2, 1);  to_dtype_2 = None
        exp_default_1 = torch.ops.aten.exp.default(mul_tensor_4);  mul_tensor_4 = None
        sub_tensor_1 = torch.ops.aten.sub.Tensor(exp_default_1, 1);  exp_default_1 = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(sub_tensor_1, 1.7580993408473766);  sub_tensor_1 = None
        where_self_1 = torch.ops.aten.where.self(gt_scalar_1, mul_tensor_3, mul_tensor_5);  gt_scalar_1 = mul_tensor_3 = mul_tensor_5 = None
        to_dtype_3 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        t_default_2 = torch.ops.aten.t.default(primals_6);  primals_6 = None
        addmm_default_2 = torch.ops.aten.addmm.default(primals_11, to_dtype_3, t_default_2);  primals_11 = None
        to_dtype_4 = torch.ops.aten.to.dtype(addmm_default_2, torch.float32)
        gt_scalar_2 = torch.ops.aten.gt.Scalar(to_dtype_4, 0)
        mul_tensor_6 = torch.ops.aten.mul.Tensor(to_dtype_4, 1.0507009873554805)
        mul_tensor_7 = torch.ops.aten.mul.Tensor(to_dtype_4, 1);  to_dtype_4 = None
        exp_default_2 = torch.ops.aten.exp.default(mul_tensor_7);  mul_tensor_7 = None
        sub_tensor_2 = torch.ops.aten.sub.Tensor(exp_default_2, 1);  exp_default_2 = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(sub_tensor_2, 1.7580993408473766);  sub_tensor_2 = None
        where_self_2 = torch.ops.aten.where.self(gt_scalar_2, mul_tensor_6, mul_tensor_8);  gt_scalar_2 = mul_tensor_6 = mul_tensor_8 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        t_default_3 = torch.ops.aten.t.default(primals_1);  primals_1 = None
        addmm_default_3 = torch.ops.aten.addmm.default(primals_8, to_dtype_5, t_default_3);  primals_8 = None
        to_dtype_6 = torch.ops.aten.to.dtype(addmm_default_3, torch.float32)
        gt_scalar_3 = torch.ops.aten.gt.Scalar(to_dtype_6, 0)
        mul_tensor_9 = torch.ops.aten.mul.Tensor(to_dtype_6, 1.0507009873554805)
        mul_tensor_10 = torch.ops.aten.mul.Tensor(to_dtype_6, 1);  to_dtype_6 = None
        exp_default_3 = torch.ops.aten.exp.default(mul_tensor_10);  mul_tensor_10 = None
        sub_tensor_3 = torch.ops.aten.sub.Tensor(exp_default_3, 1);  exp_default_3 = None
        mul_tensor_11 = torch.ops.aten.mul.Tensor(sub_tensor_3, 1.7580993408473766);  sub_tensor_3 = None
        where_self_3 = torch.ops.aten.where.self(gt_scalar_3, mul_tensor_9, mul_tensor_11);  gt_scalar_3 = mul_tensor_9 = mul_tensor_11 = None
        to_dtype_7 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        t_default_4 = torch.ops.aten.t.default(primals_2);  primals_2 = None
        addmm_default_4 = torch.ops.aten.addmm.default(primals_10, to_dtype_7, t_default_4);  primals_10 = None
        to_dtype_8 = torch.ops.aten.to.dtype(addmm_default_4, torch.float32)
        gt_scalar_4 = torch.ops.aten.gt.Scalar(to_dtype_8, 0)
        mul_tensor_12 = torch.ops.aten.mul.Tensor(to_dtype_8, 1.0507009873554805)
        mul_tensor_13 = torch.ops.aten.mul.Tensor(to_dtype_8, 1);  to_dtype_8 = None
        exp_default_4 = torch.ops.aten.exp.default(mul_tensor_13);  mul_tensor_13 = None
        sub_tensor_4 = torch.ops.aten.sub.Tensor(exp_default_4, 1);  exp_default_4 = None
        mul_tensor_14 = torch.ops.aten.mul.Tensor(sub_tensor_4, 1.7580993408473766);  sub_tensor_4 = None
        where_self_4 = torch.ops.aten.where.self(gt_scalar_4, mul_tensor_12, mul_tensor_14);  gt_scalar_4 = mul_tensor_12 = mul_tensor_14 = None
        to_dtype_9 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        t_default_5 = torch.ops.aten.t.default(primals_3);  primals_3 = None
        addmm_default_5 = torch.ops.aten.addmm.default(primals_12, to_dtype_9, t_default_5);  primals_12 = None
        to_dtype_10 = torch.ops.aten.to.dtype(addmm_default_5, torch.float32)
        gt_scalar_5 = torch.ops.aten.gt.Scalar(to_dtype_10, 0)
        mul_tensor_15 = torch.ops.aten.mul.Tensor(to_dtype_10, 1.0507009873554805)
        mul_tensor_16 = torch.ops.aten.mul.Tensor(to_dtype_10, 1);  to_dtype_10 = None
        exp_default_5 = torch.ops.aten.exp.default(mul_tensor_16);  mul_tensor_16 = None
        sub_tensor_5 = torch.ops.aten.sub.Tensor(exp_default_5, 1);  exp_default_5 = None
        mul_tensor_17 = torch.ops.aten.mul.Tensor(sub_tensor_5, 1.7580993408473766);  sub_tensor_5 = None
        where_self_5 = torch.ops.aten.where.self(gt_scalar_5, mul_tensor_15, mul_tensor_17);  gt_scalar_5 = mul_tensor_15 = mul_tensor_17 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        return [to_dtype_11, to_dtype_1, t_default_4, to_dtype_7, primals_13, addmm_default_1, addmm_default_4, t_default_2, t_default_5, to_dtype_3, to_dtype_9, addmm_default_2, addmm_default, addmm_default_5, addmm_default_3, t_default_3, to_dtype_5, t_default_1]
        
