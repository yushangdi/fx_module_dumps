
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/pytorch_CycleGAN_and_pix2pix/pytorch_CycleGAN_and_pix2pix_backward_0/state_dict.pt'))

    
    
    def forward(self, getitem_26, getitem_20, getitem_64, getitem_8, getitem_65, getitem_52, getitem_53, view_default_18, getitem_28, view_default_14, getitem_22, relu__default_12, getitem_29, view_default_6, getitem_10, getitem_23, relu__default_10, getitem_11, view_default_44, getitem_67, reflection_pad2d_default_16, getitem_68, relu__default_6, primals_6, relu__default_5, view_default_36, tanh_default, getitem_55, relu__default_3, reflection_pad2d_default_8, reflection_pad2d_default_6, getitem_56, reflection_pad2d_default_3, view_default_38, reflection_pad2d_default_2, relu__default_13, add_tensor_3, view_default_20, reflection_pad2d_default_17, primals_48, getitem_31, add_tensor_2, view_default_16, reflection_pad2d_default_9, reflection_pad2d_default_19, getitem_32, add_tensor_5, add_tensor, reflection_pad2d_default_7, add_tensor_7, view_default_8, getitem_25, primals_4, primals_28, getitem_2, getitem_14, primals_8, primals_30, getitem_13, getitem_58, primals_10, getitem_59, view_default_26, getitem_40, primals_32, getitem_46, view_default_22, getitem_34, primals_12, getitem_47, getitem_41, view_default_42, primals_34, getitem_35, view_default_10, view_default_2, getitem_16, primals_14, getitem_4, primals_36, relu__default_11, getitem_17, getitem_5, primals_16, relu__default_9, getitem_19, primals_38, relu__default_8, reflection_pad2d_default_18, primals_18, relu__default_7, reflection_pad2d_default_14, primals_40, reflection_pad2d_default_12, view_default_40, view_default_34, getitem_61, primals_20, relu__default_4, reflection_pad2d_default_5, reflection_pad2d_default_10, relu__default_1, add_tensor_6, primals_42, view_default_32, getitem_49, getitem_62, add_tensor_4, reflection_pad2d_default_15, primals_22, getitem_43, reflection_pad2d_default, reflection_pad2d_default_4, view_default_28, reflection_pad2d_default_13, primals_44, relu__default_2, view_default_24, reflection_pad2d_default_11, getitem_50, relu__default, getitem_44, primals_24, getitem_37, reflection_pad2d_default_1, primals_46, primals_2, view_default_4, getitem_38, primals_26, view_default, add_tensor_1, view_default_12, view_default_30, add_tensor_8, getitem_1, getitem_7, tangents_1):
        to_dtype = torch.ops.aten.to.dtype(tangents_1, torch.float32);  tangents_1 = None
        to_dtype_1 = torch.ops.aten.to.dtype(tanh_default, torch.float32);  tanh_default = None
        mul_tensor = torch.ops.aten.mul.Tensor(to_dtype_1, to_dtype_1);  to_dtype_1 = None
        rsub_scalar = torch.ops.aten.rsub.Scalar(mul_tensor, 1);  mul_tensor = None
        conj_physical_default = torch.ops.aten.conj_physical.default(rsub_scalar);  rsub_scalar = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(to_dtype, conj_physical_default);  to_dtype = conj_physical_default = None
        to_dtype_2 = torch.ops.aten.to.dtype(mul_tensor_1, torch.float32);  mul_tensor_1 = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(to_dtype_2, reflection_pad2d_default_19, primals_44, [3], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_2 = reflection_pad2d_default_19 = primals_44 = None
        getitem_69 = convolution_backward_default[0]
        getitem_70 = convolution_backward_default[1]
        getitem_71 = convolution_backward_default[2];  convolution_backward_default = None
        reflection_pad2d_backward_default = torch.ops.aten.reflection_pad2d_backward.default(getitem_69, relu__default_13, [3, 3, 3, 3]);  getitem_69 = relu__default_13 = None
        squeeze_dim = torch.ops.aten.squeeze.dim(reflection_pad2d_backward_default, 0);  reflection_pad2d_backward_default = None
        new_empty_default = torch.ops.aten.new_empty.default(squeeze_dim, [4194304]);  squeeze_dim = None
        zero__default = torch.ops.aten.zero_.default(new_empty_default);  new_empty_default = None
        as_strided_default_1 = torch.ops.aten.as_strided.default(zero__default, [1, 64, 256, 256], [4194304, 65536, 256, 1], 0);  zero__default = None
        new_empty_strided_default = torch.ops.aten.new_empty_strided.default(as_strided_default_1, [1, 64, 256, 256], [4194304, 65536, 256, 1])
        copy__default_1 = torch.ops.aten.copy_.default(new_empty_strided_default, as_strided_default_1);  new_empty_strided_default = as_strided_default_1 = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(copy__default_1, view_default_44, None, None, None, getitem_67, getitem_68, True, 1e-05, [True, False, False]);  copy__default_1 = view_default_44 = getitem_67 = getitem_68 = None
        getitem_72 = native_batch_norm_backward_default[0];  native_batch_norm_backward_default = None
        view_default_46 = torch.ops.aten.view.default(getitem_72, [1, 64, 256, 256]);  getitem_72 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(view_default_46, relu__default_12, primals_42, [64], [2, 2], [1, 1], [1, 1], True, [1, 1], 1, [True, True, True]);  view_default_46 = relu__default_12 = primals_42 = None
        getitem_75 = convolution_backward_default_1[0]
        getitem_76 = convolution_backward_default_1[1]
        getitem_77 = convolution_backward_default_1[2];  convolution_backward_default_1 = None
        squeeze_dim_1 = torch.ops.aten.squeeze.dim(getitem_75, 0);  getitem_75 = None
        new_empty_default_1 = torch.ops.aten.new_empty.default(squeeze_dim_1, [2097152]);  squeeze_dim_1 = None
        zero__default_1 = torch.ops.aten.zero_.default(new_empty_default_1);  new_empty_default_1 = None
        as_strided_default_4 = torch.ops.aten.as_strided.default(zero__default_1, [1, 128, 128, 128], [2097152, 16384, 128, 1], 0);  zero__default_1 = None
        new_empty_strided_default_1 = torch.ops.aten.new_empty_strided.default(as_strided_default_4, [1, 128, 128, 128], [2097152, 16384, 128, 1])
        copy__default_4 = torch.ops.aten.copy_.default(new_empty_strided_default_1, as_strided_default_4);  new_empty_strided_default_1 = as_strided_default_4 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(copy__default_4, view_default_42, None, None, None, getitem_64, getitem_65, True, 1e-05, [True, False, False]);  copy__default_4 = view_default_42 = getitem_64 = getitem_65 = None
        getitem_78 = native_batch_norm_backward_default_1[0];  native_batch_norm_backward_default_1 = None
        view_default_47 = torch.ops.aten.view.default(getitem_78, [1, 128, 128, 128]);  getitem_78 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(view_default_47, add_tensor_8, primals_40, [128], [2, 2], [1, 1], [1, 1], True, [1, 1], 1, [True, True, True]);  view_default_47 = add_tensor_8 = primals_40 = None
        getitem_81 = convolution_backward_default_2[0]
        getitem_82 = convolution_backward_default_2[1]
        getitem_83 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        view_default_48 = torch.ops.aten.view.default(getitem_81, [1, 256, 64, 64])
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(view_default_48, view_default_40, None, None, None, getitem_61, getitem_62, True, 1e-05, [True, False, False]);  view_default_48 = view_default_40 = getitem_61 = getitem_62 = None
        getitem_84 = native_batch_norm_backward_default_2[0];  native_batch_norm_backward_default_2 = None
        view_default_49 = torch.ops.aten.view.default(getitem_84, [1, 256, 64, 64]);  getitem_84 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(view_default_49, reflection_pad2d_default_18, primals_38, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_49 = reflection_pad2d_default_18 = primals_38 = None
        getitem_87 = convolution_backward_default_3[0]
        getitem_88 = convolution_backward_default_3[1]
        getitem_89 = convolution_backward_default_3[2];  convolution_backward_default_3 = None
        reflection_pad2d_backward_default_1 = torch.ops.aten.reflection_pad2d_backward.default(getitem_87, relu__default_11, [1, 1, 1, 1]);  getitem_87 = relu__default_11 = None
        squeeze_dim_2 = torch.ops.aten.squeeze.dim(reflection_pad2d_backward_default_1, 0);  reflection_pad2d_backward_default_1 = None
        new_empty_default_2 = torch.ops.aten.new_empty.default(squeeze_dim_2, [1048576]);  squeeze_dim_2 = None
        zero__default_2 = torch.ops.aten.zero_.default(new_empty_default_2);  new_empty_default_2 = None
        as_strided_default_7 = torch.ops.aten.as_strided.default(zero__default_2, [1, 256, 64, 64], [1048576, 4096, 64, 1], 0);  zero__default_2 = None
        new_empty_strided_default_2 = torch.ops.aten.new_empty_strided.default(as_strided_default_7, [1, 256, 64, 64], [1048576, 4096, 64, 1])
        copy__default_7 = torch.ops.aten.copy_.default(new_empty_strided_default_2, as_strided_default_7);  new_empty_strided_default_2 = as_strided_default_7 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(copy__default_7, view_default_38, None, None, None, getitem_58, getitem_59, True, 1e-05, [True, False, False]);  copy__default_7 = view_default_38 = getitem_58 = getitem_59 = None
        getitem_90 = native_batch_norm_backward_default_3[0];  native_batch_norm_backward_default_3 = None
        view_default_50 = torch.ops.aten.view.default(getitem_90, [1, 256, 64, 64]);  getitem_90 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(view_default_50, reflection_pad2d_default_17, primals_36, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_50 = reflection_pad2d_default_17 = primals_36 = None
        getitem_93 = convolution_backward_default_4[0]
        getitem_94 = convolution_backward_default_4[1]
        getitem_95 = convolution_backward_default_4[2];  convolution_backward_default_4 = None
        reflection_pad2d_backward_default_2 = torch.ops.aten.reflection_pad2d_backward.default(getitem_93, add_tensor_7, [1, 1, 1, 1]);  getitem_93 = add_tensor_7 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(getitem_81, reflection_pad2d_backward_default_2);  getitem_81 = reflection_pad2d_backward_default_2 = None
        view_default_51 = torch.ops.aten.view.default(add_tensor_9, [1, 256, 64, 64])
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(view_default_51, view_default_36, None, None, None, getitem_55, getitem_56, True, 1e-05, [True, False, False]);  view_default_51 = view_default_36 = getitem_55 = getitem_56 = None
        getitem_96 = native_batch_norm_backward_default_4[0];  native_batch_norm_backward_default_4 = None
        view_default_52 = torch.ops.aten.view.default(getitem_96, [1, 256, 64, 64]);  getitem_96 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(view_default_52, reflection_pad2d_default_16, primals_34, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_52 = reflection_pad2d_default_16 = primals_34 = None
        getitem_99 = convolution_backward_default_5[0]
        getitem_100 = convolution_backward_default_5[1]
        getitem_101 = convolution_backward_default_5[2];  convolution_backward_default_5 = None
        reflection_pad2d_backward_default_3 = torch.ops.aten.reflection_pad2d_backward.default(getitem_99, relu__default_10, [1, 1, 1, 1]);  getitem_99 = relu__default_10 = None
        squeeze_dim_3 = torch.ops.aten.squeeze.dim(reflection_pad2d_backward_default_3, 0);  reflection_pad2d_backward_default_3 = None
        new_empty_default_3 = torch.ops.aten.new_empty.default(squeeze_dim_3, [1048576]);  squeeze_dim_3 = None
        zero__default_3 = torch.ops.aten.zero_.default(new_empty_default_3);  new_empty_default_3 = None
        as_strided_default_10 = torch.ops.aten.as_strided.default(zero__default_3, [1, 256, 64, 64], [1048576, 4096, 64, 1], 0);  zero__default_3 = None
        new_empty_strided_default_3 = torch.ops.aten.new_empty_strided.default(as_strided_default_10, [1, 256, 64, 64], [1048576, 4096, 64, 1])
        copy__default_10 = torch.ops.aten.copy_.default(new_empty_strided_default_3, as_strided_default_10);  new_empty_strided_default_3 = as_strided_default_10 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(copy__default_10, view_default_34, None, None, None, getitem_52, getitem_53, True, 1e-05, [True, False, False]);  copy__default_10 = view_default_34 = getitem_52 = getitem_53 = None
        getitem_102 = native_batch_norm_backward_default_5[0];  native_batch_norm_backward_default_5 = None
        view_default_53 = torch.ops.aten.view.default(getitem_102, [1, 256, 64, 64]);  getitem_102 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(view_default_53, reflection_pad2d_default_15, primals_32, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_53 = reflection_pad2d_default_15 = primals_32 = None
        getitem_105 = convolution_backward_default_6[0]
        getitem_106 = convolution_backward_default_6[1]
        getitem_107 = convolution_backward_default_6[2];  convolution_backward_default_6 = None
        reflection_pad2d_backward_default_4 = torch.ops.aten.reflection_pad2d_backward.default(getitem_105, add_tensor_6, [1, 1, 1, 1]);  getitem_105 = add_tensor_6 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(add_tensor_9, reflection_pad2d_backward_default_4);  add_tensor_9 = reflection_pad2d_backward_default_4 = None
        view_default_54 = torch.ops.aten.view.default(add_tensor_10, [1, 256, 64, 64])
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(view_default_54, view_default_32, None, None, None, getitem_49, getitem_50, True, 1e-05, [True, False, False]);  view_default_54 = view_default_32 = getitem_49 = getitem_50 = None
        getitem_108 = native_batch_norm_backward_default_6[0];  native_batch_norm_backward_default_6 = None
        view_default_55 = torch.ops.aten.view.default(getitem_108, [1, 256, 64, 64]);  getitem_108 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(view_default_55, reflection_pad2d_default_14, primals_30, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_55 = reflection_pad2d_default_14 = primals_30 = None
        getitem_111 = convolution_backward_default_7[0]
        getitem_112 = convolution_backward_default_7[1]
        getitem_113 = convolution_backward_default_7[2];  convolution_backward_default_7 = None
        reflection_pad2d_backward_default_5 = torch.ops.aten.reflection_pad2d_backward.default(getitem_111, relu__default_9, [1, 1, 1, 1]);  getitem_111 = relu__default_9 = None
        squeeze_dim_4 = torch.ops.aten.squeeze.dim(reflection_pad2d_backward_default_5, 0);  reflection_pad2d_backward_default_5 = None
        new_empty_default_4 = torch.ops.aten.new_empty.default(squeeze_dim_4, [1048576]);  squeeze_dim_4 = None
        zero__default_4 = torch.ops.aten.zero_.default(new_empty_default_4);  new_empty_default_4 = None
        as_strided_default_13 = torch.ops.aten.as_strided.default(zero__default_4, [1, 256, 64, 64], [1048576, 4096, 64, 1], 0);  zero__default_4 = None
        new_empty_strided_default_4 = torch.ops.aten.new_empty_strided.default(as_strided_default_13, [1, 256, 64, 64], [1048576, 4096, 64, 1])
        copy__default_13 = torch.ops.aten.copy_.default(new_empty_strided_default_4, as_strided_default_13);  new_empty_strided_default_4 = as_strided_default_13 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(copy__default_13, view_default_30, None, None, None, getitem_46, getitem_47, True, 1e-05, [True, False, False]);  copy__default_13 = view_default_30 = getitem_46 = getitem_47 = None
        getitem_114 = native_batch_norm_backward_default_7[0];  native_batch_norm_backward_default_7 = None
        view_default_56 = torch.ops.aten.view.default(getitem_114, [1, 256, 64, 64]);  getitem_114 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(view_default_56, reflection_pad2d_default_13, primals_28, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_56 = reflection_pad2d_default_13 = primals_28 = None
        getitem_117 = convolution_backward_default_8[0]
        getitem_118 = convolution_backward_default_8[1]
        getitem_119 = convolution_backward_default_8[2];  convolution_backward_default_8 = None
        reflection_pad2d_backward_default_6 = torch.ops.aten.reflection_pad2d_backward.default(getitem_117, add_tensor_5, [1, 1, 1, 1]);  getitem_117 = add_tensor_5 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(add_tensor_10, reflection_pad2d_backward_default_6);  add_tensor_10 = reflection_pad2d_backward_default_6 = None
        view_default_57 = torch.ops.aten.view.default(add_tensor_11, [1, 256, 64, 64])
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(view_default_57, view_default_28, None, None, None, getitem_43, getitem_44, True, 1e-05, [True, False, False]);  view_default_57 = view_default_28 = getitem_43 = getitem_44 = None
        getitem_120 = native_batch_norm_backward_default_8[0];  native_batch_norm_backward_default_8 = None
        view_default_58 = torch.ops.aten.view.default(getitem_120, [1, 256, 64, 64]);  getitem_120 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(view_default_58, reflection_pad2d_default_12, primals_26, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_58 = reflection_pad2d_default_12 = primals_26 = None
        getitem_123 = convolution_backward_default_9[0]
        getitem_124 = convolution_backward_default_9[1]
        getitem_125 = convolution_backward_default_9[2];  convolution_backward_default_9 = None
        reflection_pad2d_backward_default_7 = torch.ops.aten.reflection_pad2d_backward.default(getitem_123, relu__default_8, [1, 1, 1, 1]);  getitem_123 = relu__default_8 = None
        squeeze_dim_5 = torch.ops.aten.squeeze.dim(reflection_pad2d_backward_default_7, 0);  reflection_pad2d_backward_default_7 = None
        new_empty_default_5 = torch.ops.aten.new_empty.default(squeeze_dim_5, [1048576]);  squeeze_dim_5 = None
        zero__default_5 = torch.ops.aten.zero_.default(new_empty_default_5);  new_empty_default_5 = None
        as_strided_default_16 = torch.ops.aten.as_strided.default(zero__default_5, [1, 256, 64, 64], [1048576, 4096, 64, 1], 0);  zero__default_5 = None
        new_empty_strided_default_5 = torch.ops.aten.new_empty_strided.default(as_strided_default_16, [1, 256, 64, 64], [1048576, 4096, 64, 1])
        copy__default_16 = torch.ops.aten.copy_.default(new_empty_strided_default_5, as_strided_default_16);  new_empty_strided_default_5 = as_strided_default_16 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(copy__default_16, view_default_26, None, None, None, getitem_40, getitem_41, True, 1e-05, [True, False, False]);  copy__default_16 = view_default_26 = getitem_40 = getitem_41 = None
        getitem_126 = native_batch_norm_backward_default_9[0];  native_batch_norm_backward_default_9 = None
        view_default_59 = torch.ops.aten.view.default(getitem_126, [1, 256, 64, 64]);  getitem_126 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(view_default_59, reflection_pad2d_default_11, primals_24, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_59 = reflection_pad2d_default_11 = primals_24 = None
        getitem_129 = convolution_backward_default_10[0]
        getitem_130 = convolution_backward_default_10[1]
        getitem_131 = convolution_backward_default_10[2];  convolution_backward_default_10 = None
        reflection_pad2d_backward_default_8 = torch.ops.aten.reflection_pad2d_backward.default(getitem_129, add_tensor_4, [1, 1, 1, 1]);  getitem_129 = add_tensor_4 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(add_tensor_11, reflection_pad2d_backward_default_8);  add_tensor_11 = reflection_pad2d_backward_default_8 = None
        view_default_60 = torch.ops.aten.view.default(add_tensor_12, [1, 256, 64, 64])
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(view_default_60, view_default_24, None, None, None, getitem_37, getitem_38, True, 1e-05, [True, False, False]);  view_default_60 = view_default_24 = getitem_37 = getitem_38 = None
        getitem_132 = native_batch_norm_backward_default_10[0];  native_batch_norm_backward_default_10 = None
        view_default_61 = torch.ops.aten.view.default(getitem_132, [1, 256, 64, 64]);  getitem_132 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(view_default_61, reflection_pad2d_default_10, primals_22, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_61 = reflection_pad2d_default_10 = primals_22 = None
        getitem_135 = convolution_backward_default_11[0]
        getitem_136 = convolution_backward_default_11[1]
        getitem_137 = convolution_backward_default_11[2];  convolution_backward_default_11 = None
        reflection_pad2d_backward_default_9 = torch.ops.aten.reflection_pad2d_backward.default(getitem_135, relu__default_7, [1, 1, 1, 1]);  getitem_135 = relu__default_7 = None
        squeeze_dim_6 = torch.ops.aten.squeeze.dim(reflection_pad2d_backward_default_9, 0);  reflection_pad2d_backward_default_9 = None
        new_empty_default_6 = torch.ops.aten.new_empty.default(squeeze_dim_6, [1048576]);  squeeze_dim_6 = None
        zero__default_6 = torch.ops.aten.zero_.default(new_empty_default_6);  new_empty_default_6 = None
        as_strided_default_19 = torch.ops.aten.as_strided.default(zero__default_6, [1, 256, 64, 64], [1048576, 4096, 64, 1], 0);  zero__default_6 = None
        new_empty_strided_default_6 = torch.ops.aten.new_empty_strided.default(as_strided_default_19, [1, 256, 64, 64], [1048576, 4096, 64, 1])
        copy__default_19 = torch.ops.aten.copy_.default(new_empty_strided_default_6, as_strided_default_19);  new_empty_strided_default_6 = as_strided_default_19 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(copy__default_19, view_default_22, None, None, None, getitem_34, getitem_35, True, 1e-05, [True, False, False]);  copy__default_19 = view_default_22 = getitem_34 = getitem_35 = None
        getitem_138 = native_batch_norm_backward_default_11[0];  native_batch_norm_backward_default_11 = None
        view_default_62 = torch.ops.aten.view.default(getitem_138, [1, 256, 64, 64]);  getitem_138 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(view_default_62, reflection_pad2d_default_9, primals_20, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_62 = reflection_pad2d_default_9 = primals_20 = None
        getitem_141 = convolution_backward_default_12[0]
        getitem_142 = convolution_backward_default_12[1]
        getitem_143 = convolution_backward_default_12[2];  convolution_backward_default_12 = None
        reflection_pad2d_backward_default_10 = torch.ops.aten.reflection_pad2d_backward.default(getitem_141, add_tensor_3, [1, 1, 1, 1]);  getitem_141 = add_tensor_3 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(add_tensor_12, reflection_pad2d_backward_default_10);  add_tensor_12 = reflection_pad2d_backward_default_10 = None
        view_default_63 = torch.ops.aten.view.default(add_tensor_13, [1, 256, 64, 64])
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(view_default_63, view_default_20, None, None, None, getitem_31, getitem_32, True, 1e-05, [True, False, False]);  view_default_63 = view_default_20 = getitem_31 = getitem_32 = None
        getitem_144 = native_batch_norm_backward_default_12[0];  native_batch_norm_backward_default_12 = None
        view_default_64 = torch.ops.aten.view.default(getitem_144, [1, 256, 64, 64]);  getitem_144 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(view_default_64, reflection_pad2d_default_8, primals_18, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_64 = reflection_pad2d_default_8 = primals_18 = None
        getitem_147 = convolution_backward_default_13[0]
        getitem_148 = convolution_backward_default_13[1]
        getitem_149 = convolution_backward_default_13[2];  convolution_backward_default_13 = None
        reflection_pad2d_backward_default_11 = torch.ops.aten.reflection_pad2d_backward.default(getitem_147, relu__default_6, [1, 1, 1, 1]);  getitem_147 = relu__default_6 = None
        squeeze_dim_7 = torch.ops.aten.squeeze.dim(reflection_pad2d_backward_default_11, 0);  reflection_pad2d_backward_default_11 = None
        new_empty_default_7 = torch.ops.aten.new_empty.default(squeeze_dim_7, [1048576]);  squeeze_dim_7 = None
        zero__default_7 = torch.ops.aten.zero_.default(new_empty_default_7);  new_empty_default_7 = None
        as_strided_default_22 = torch.ops.aten.as_strided.default(zero__default_7, [1, 256, 64, 64], [1048576, 4096, 64, 1], 0);  zero__default_7 = None
        new_empty_strided_default_7 = torch.ops.aten.new_empty_strided.default(as_strided_default_22, [1, 256, 64, 64], [1048576, 4096, 64, 1])
        copy__default_22 = torch.ops.aten.copy_.default(new_empty_strided_default_7, as_strided_default_22);  new_empty_strided_default_7 = as_strided_default_22 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(copy__default_22, view_default_18, None, None, None, getitem_28, getitem_29, True, 1e-05, [True, False, False]);  copy__default_22 = view_default_18 = getitem_28 = getitem_29 = None
        getitem_150 = native_batch_norm_backward_default_13[0];  native_batch_norm_backward_default_13 = None
        view_default_65 = torch.ops.aten.view.default(getitem_150, [1, 256, 64, 64]);  getitem_150 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(view_default_65, reflection_pad2d_default_7, primals_16, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_65 = reflection_pad2d_default_7 = primals_16 = None
        getitem_153 = convolution_backward_default_14[0]
        getitem_154 = convolution_backward_default_14[1]
        getitem_155 = convolution_backward_default_14[2];  convolution_backward_default_14 = None
        reflection_pad2d_backward_default_12 = torch.ops.aten.reflection_pad2d_backward.default(getitem_153, add_tensor_2, [1, 1, 1, 1]);  getitem_153 = add_tensor_2 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(add_tensor_13, reflection_pad2d_backward_default_12);  add_tensor_13 = reflection_pad2d_backward_default_12 = None
        view_default_66 = torch.ops.aten.view.default(add_tensor_14, [1, 256, 64, 64])
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(view_default_66, view_default_16, None, None, None, getitem_25, getitem_26, True, 1e-05, [True, False, False]);  view_default_66 = view_default_16 = getitem_25 = getitem_26 = None
        getitem_156 = native_batch_norm_backward_default_14[0];  native_batch_norm_backward_default_14 = None
        view_default_67 = torch.ops.aten.view.default(getitem_156, [1, 256, 64, 64]);  getitem_156 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(view_default_67, reflection_pad2d_default_6, primals_14, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_67 = reflection_pad2d_default_6 = primals_14 = None
        getitem_159 = convolution_backward_default_15[0]
        getitem_160 = convolution_backward_default_15[1]
        getitem_161 = convolution_backward_default_15[2];  convolution_backward_default_15 = None
        reflection_pad2d_backward_default_13 = torch.ops.aten.reflection_pad2d_backward.default(getitem_159, relu__default_5, [1, 1, 1, 1]);  getitem_159 = relu__default_5 = None
        squeeze_dim_8 = torch.ops.aten.squeeze.dim(reflection_pad2d_backward_default_13, 0);  reflection_pad2d_backward_default_13 = None
        new_empty_default_8 = torch.ops.aten.new_empty.default(squeeze_dim_8, [1048576]);  squeeze_dim_8 = None
        zero__default_8 = torch.ops.aten.zero_.default(new_empty_default_8);  new_empty_default_8 = None
        as_strided_default_25 = torch.ops.aten.as_strided.default(zero__default_8, [1, 256, 64, 64], [1048576, 4096, 64, 1], 0);  zero__default_8 = None
        new_empty_strided_default_8 = torch.ops.aten.new_empty_strided.default(as_strided_default_25, [1, 256, 64, 64], [1048576, 4096, 64, 1])
        copy__default_25 = torch.ops.aten.copy_.default(new_empty_strided_default_8, as_strided_default_25);  new_empty_strided_default_8 = as_strided_default_25 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(copy__default_25, view_default_14, None, None, None, getitem_22, getitem_23, True, 1e-05, [True, False, False]);  copy__default_25 = view_default_14 = getitem_22 = getitem_23 = None
        getitem_162 = native_batch_norm_backward_default_15[0];  native_batch_norm_backward_default_15 = None
        view_default_68 = torch.ops.aten.view.default(getitem_162, [1, 256, 64, 64]);  getitem_162 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(view_default_68, reflection_pad2d_default_5, primals_12, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_68 = reflection_pad2d_default_5 = primals_12 = None
        getitem_165 = convolution_backward_default_16[0]
        getitem_166 = convolution_backward_default_16[1]
        getitem_167 = convolution_backward_default_16[2];  convolution_backward_default_16 = None
        reflection_pad2d_backward_default_14 = torch.ops.aten.reflection_pad2d_backward.default(getitem_165, add_tensor_1, [1, 1, 1, 1]);  getitem_165 = add_tensor_1 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(add_tensor_14, reflection_pad2d_backward_default_14);  add_tensor_14 = reflection_pad2d_backward_default_14 = None
        view_default_69 = torch.ops.aten.view.default(add_tensor_15, [1, 256, 64, 64])
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(view_default_69, view_default_12, None, None, None, getitem_19, getitem_20, True, 1e-05, [True, False, False]);  view_default_69 = view_default_12 = getitem_19 = getitem_20 = None
        getitem_168 = native_batch_norm_backward_default_16[0];  native_batch_norm_backward_default_16 = None
        view_default_70 = torch.ops.aten.view.default(getitem_168, [1, 256, 64, 64]);  getitem_168 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(view_default_70, reflection_pad2d_default_4, primals_10, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_70 = reflection_pad2d_default_4 = primals_10 = None
        getitem_171 = convolution_backward_default_17[0]
        getitem_172 = convolution_backward_default_17[1]
        getitem_173 = convolution_backward_default_17[2];  convolution_backward_default_17 = None
        reflection_pad2d_backward_default_15 = torch.ops.aten.reflection_pad2d_backward.default(getitem_171, relu__default_4, [1, 1, 1, 1]);  getitem_171 = relu__default_4 = None
        squeeze_dim_9 = torch.ops.aten.squeeze.dim(reflection_pad2d_backward_default_15, 0);  reflection_pad2d_backward_default_15 = None
        new_empty_default_9 = torch.ops.aten.new_empty.default(squeeze_dim_9, [1048576]);  squeeze_dim_9 = None
        zero__default_9 = torch.ops.aten.zero_.default(new_empty_default_9);  new_empty_default_9 = None
        as_strided_default_28 = torch.ops.aten.as_strided.default(zero__default_9, [1, 256, 64, 64], [1048576, 4096, 64, 1], 0);  zero__default_9 = None
        new_empty_strided_default_9 = torch.ops.aten.new_empty_strided.default(as_strided_default_28, [1, 256, 64, 64], [1048576, 4096, 64, 1])
        copy__default_28 = torch.ops.aten.copy_.default(new_empty_strided_default_9, as_strided_default_28);  new_empty_strided_default_9 = as_strided_default_28 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(copy__default_28, view_default_10, None, None, None, getitem_16, getitem_17, True, 1e-05, [True, False, False]);  copy__default_28 = view_default_10 = getitem_16 = getitem_17 = None
        getitem_174 = native_batch_norm_backward_default_17[0];  native_batch_norm_backward_default_17 = None
        view_default_71 = torch.ops.aten.view.default(getitem_174, [1, 256, 64, 64]);  getitem_174 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(view_default_71, reflection_pad2d_default_3, primals_8, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_71 = reflection_pad2d_default_3 = primals_8 = None
        getitem_177 = convolution_backward_default_18[0]
        getitem_178 = convolution_backward_default_18[1]
        getitem_179 = convolution_backward_default_18[2];  convolution_backward_default_18 = None
        reflection_pad2d_backward_default_16 = torch.ops.aten.reflection_pad2d_backward.default(getitem_177, add_tensor, [1, 1, 1, 1]);  getitem_177 = add_tensor = None
        add_tensor_16 = torch.ops.aten.add.Tensor(add_tensor_15, reflection_pad2d_backward_default_16);  add_tensor_15 = reflection_pad2d_backward_default_16 = None
        view_default_72 = torch.ops.aten.view.default(add_tensor_16, [1, 256, 64, 64])
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(view_default_72, view_default_8, None, None, None, getitem_13, getitem_14, True, 1e-05, [True, False, False]);  view_default_72 = view_default_8 = getitem_13 = getitem_14 = None
        getitem_180 = native_batch_norm_backward_default_18[0];  native_batch_norm_backward_default_18 = None
        view_default_73 = torch.ops.aten.view.default(getitem_180, [1, 256, 64, 64]);  getitem_180 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(view_default_73, reflection_pad2d_default_2, primals_6, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_73 = reflection_pad2d_default_2 = primals_6 = None
        getitem_183 = convolution_backward_default_19[0]
        getitem_184 = convolution_backward_default_19[1]
        getitem_185 = convolution_backward_default_19[2];  convolution_backward_default_19 = None
        reflection_pad2d_backward_default_17 = torch.ops.aten.reflection_pad2d_backward.default(getitem_183, relu__default_3, [1, 1, 1, 1]);  getitem_183 = relu__default_3 = None
        squeeze_dim_10 = torch.ops.aten.squeeze.dim(reflection_pad2d_backward_default_17, 0);  reflection_pad2d_backward_default_17 = None
        new_empty_default_10 = torch.ops.aten.new_empty.default(squeeze_dim_10, [1048576]);  squeeze_dim_10 = None
        zero__default_10 = torch.ops.aten.zero_.default(new_empty_default_10);  new_empty_default_10 = None
        as_strided_default_31 = torch.ops.aten.as_strided.default(zero__default_10, [1, 256, 64, 64], [1048576, 4096, 64, 1], 0);  zero__default_10 = None
        new_empty_strided_default_10 = torch.ops.aten.new_empty_strided.default(as_strided_default_31, [1, 256, 64, 64], [1048576, 4096, 64, 1])
        copy__default_31 = torch.ops.aten.copy_.default(new_empty_strided_default_10, as_strided_default_31);  new_empty_strided_default_10 = as_strided_default_31 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(copy__default_31, view_default_6, None, None, None, getitem_10, getitem_11, True, 1e-05, [True, False, False]);  copy__default_31 = view_default_6 = getitem_10 = getitem_11 = None
        getitem_186 = native_batch_norm_backward_default_19[0];  native_batch_norm_backward_default_19 = None
        view_default_74 = torch.ops.aten.view.default(getitem_186, [1, 256, 64, 64]);  getitem_186 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(view_default_74, reflection_pad2d_default_1, primals_4, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_74 = reflection_pad2d_default_1 = primals_4 = None
        getitem_189 = convolution_backward_default_20[0]
        getitem_190 = convolution_backward_default_20[1]
        getitem_191 = convolution_backward_default_20[2];  convolution_backward_default_20 = None
        reflection_pad2d_backward_default_18 = torch.ops.aten.reflection_pad2d_backward.default(getitem_189, relu__default_2, [1, 1, 1, 1]);  getitem_189 = relu__default_2 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(add_tensor_16, reflection_pad2d_backward_default_18);  add_tensor_16 = reflection_pad2d_backward_default_18 = None
        squeeze_dim_11 = torch.ops.aten.squeeze.dim(add_tensor_17, 0);  add_tensor_17 = None
        new_empty_default_11 = torch.ops.aten.new_empty.default(squeeze_dim_11, [1048576]);  squeeze_dim_11 = None
        zero__default_11 = torch.ops.aten.zero_.default(new_empty_default_11);  new_empty_default_11 = None
        as_strided_default_34 = torch.ops.aten.as_strided.default(zero__default_11, [1, 256, 64, 64], [1048576, 4096, 64, 1], 0);  zero__default_11 = None
        new_empty_strided_default_11 = torch.ops.aten.new_empty_strided.default(as_strided_default_34, [1, 256, 64, 64], [1048576, 4096, 64, 1])
        copy__default_34 = torch.ops.aten.copy_.default(new_empty_strided_default_11, as_strided_default_34);  new_empty_strided_default_11 = as_strided_default_34 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(copy__default_34, view_default_4, None, None, None, getitem_7, getitem_8, True, 1e-05, [True, False, False]);  copy__default_34 = view_default_4 = getitem_7 = getitem_8 = None
        getitem_192 = native_batch_norm_backward_default_20[0];  native_batch_norm_backward_default_20 = None
        view_default_75 = torch.ops.aten.view.default(getitem_192, [1, 256, 64, 64]);  getitem_192 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(view_default_75, relu__default_1, primals_48, [256], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_75 = relu__default_1 = primals_48 = None
        getitem_195 = convolution_backward_default_21[0]
        getitem_196 = convolution_backward_default_21[1]
        getitem_197 = convolution_backward_default_21[2];  convolution_backward_default_21 = None
        squeeze_dim_12 = torch.ops.aten.squeeze.dim(getitem_195, 0);  getitem_195 = None
        new_empty_default_12 = torch.ops.aten.new_empty.default(squeeze_dim_12, [2097152]);  squeeze_dim_12 = None
        zero__default_12 = torch.ops.aten.zero_.default(new_empty_default_12);  new_empty_default_12 = None
        as_strided_default_37 = torch.ops.aten.as_strided.default(zero__default_12, [1, 128, 128, 128], [2097152, 16384, 128, 1], 0);  zero__default_12 = None
        new_empty_strided_default_12 = torch.ops.aten.new_empty_strided.default(as_strided_default_37, [1, 128, 128, 128], [2097152, 16384, 128, 1])
        copy__default_37 = torch.ops.aten.copy_.default(new_empty_strided_default_12, as_strided_default_37);  new_empty_strided_default_12 = as_strided_default_37 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(copy__default_37, view_default_2, None, None, None, getitem_4, getitem_5, True, 1e-05, [True, False, False]);  copy__default_37 = view_default_2 = getitem_4 = getitem_5 = None
        getitem_198 = native_batch_norm_backward_default_21[0];  native_batch_norm_backward_default_21 = None
        view_default_76 = torch.ops.aten.view.default(getitem_198, [1, 128, 128, 128]);  getitem_198 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(view_default_76, relu__default, primals_46, [128], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_76 = relu__default = primals_46 = None
        getitem_201 = convolution_backward_default_22[0]
        getitem_202 = convolution_backward_default_22[1]
        getitem_203 = convolution_backward_default_22[2];  convolution_backward_default_22 = None
        squeeze_dim_13 = torch.ops.aten.squeeze.dim(getitem_201, 0);  getitem_201 = None
        new_empty_default_13 = torch.ops.aten.new_empty.default(squeeze_dim_13, [4194304]);  squeeze_dim_13 = None
        zero__default_13 = torch.ops.aten.zero_.default(new_empty_default_13);  new_empty_default_13 = None
        as_strided_default_40 = torch.ops.aten.as_strided.default(zero__default_13, [1, 64, 256, 256], [4194304, 65536, 256, 1], 0);  zero__default_13 = None
        new_empty_strided_default_13 = torch.ops.aten.new_empty_strided.default(as_strided_default_40, [1, 64, 256, 256], [4194304, 65536, 256, 1])
        copy__default_40 = torch.ops.aten.copy_.default(new_empty_strided_default_13, as_strided_default_40);  new_empty_strided_default_13 = as_strided_default_40 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(copy__default_40, view_default, None, None, None, getitem_1, getitem_2, True, 1e-05, [True, False, False]);  copy__default_40 = view_default = getitem_1 = getitem_2 = None
        getitem_204 = native_batch_norm_backward_default_22[0];  native_batch_norm_backward_default_22 = None
        view_default_77 = torch.ops.aten.view.default(getitem_204, [1, 64, 256, 256]);  getitem_204 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(view_default_77, reflection_pad2d_default, primals_2, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [False, True, True]);  view_default_77 = reflection_pad2d_default = primals_2 = None
        getitem_208 = convolution_backward_default_23[1]
        getitem_209 = convolution_backward_default_23[2];  convolution_backward_default_23 = None
        return [getitem_209, getitem_208, getitem_191, getitem_190, getitem_185, getitem_184, getitem_179, getitem_178, getitem_173, getitem_172, getitem_167, getitem_166, getitem_161, getitem_160, getitem_155, getitem_154, getitem_149, getitem_148, getitem_143, getitem_142, getitem_137, getitem_136, getitem_131, getitem_130, getitem_125, getitem_124, getitem_119, getitem_118, getitem_113, getitem_112, getitem_107, getitem_106, getitem_101, getitem_100, getitem_95, getitem_94, getitem_89, getitem_88, getitem_83, getitem_82, getitem_77, getitem_76, getitem_71, getitem_70, getitem_203, getitem_202, getitem_197, getitem_196, None]
        
