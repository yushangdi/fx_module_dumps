
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/pytorch_CycleGAN_and_pix2pix/pytorch_CycleGAN_and_pix2pix_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49):
        reflection_pad2d_default = torch.ops.aten.reflection_pad2d.default(primals_49, [3, 3, 3, 3]);  primals_49 = None
        convolution_default = torch.ops.aten.convolution.default(reflection_pad2d_default, primals_2, primals_1, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1 = None
        view_default = torch.ops.aten.view.default(convolution_default, [1, 64, 256, 256]);  convolution_default = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(view_default, None, None, None, None, True, 0.1, 1e-05)
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        view_default_1 = torch.ops.aten.view.default(getitem, [1, 64, 256, 256]);  getitem = None
        relu__default = torch.ops.aten.relu_.default(view_default_1);  view_default_1 = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default, primals_46, primals_45, [2, 2], [1, 1], [1, 1], False, [0, 0], 1);  primals_45 = None
        view_default_2 = torch.ops.aten.view.default(convolution_default_1, [1, 128, 128, 128]);  convolution_default_1 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(view_default_2, None, None, None, None, True, 0.1, 1e-05)
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        view_default_3 = torch.ops.aten.view.default(getitem_3, [1, 128, 128, 128]);  getitem_3 = None
        relu__default_1 = torch.ops.aten.relu_.default(view_default_3);  view_default_3 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_48, primals_47, [2, 2], [1, 1], [1, 1], False, [0, 0], 1);  primals_47 = None
        view_default_4 = torch.ops.aten.view.default(convolution_default_2, [1, 256, 64, 64]);  convolution_default_2 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(view_default_4, None, None, None, None, True, 0.1, 1e-05)
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        view_default_5 = torch.ops.aten.view.default(getitem_6, [1, 256, 64, 64]);  getitem_6 = None
        relu__default_2 = torch.ops.aten.relu_.default(view_default_5);  view_default_5 = None
        reflection_pad2d_default_1 = torch.ops.aten.reflection_pad2d.default(relu__default_2, [1, 1, 1, 1])
        convolution_default_3 = torch.ops.aten.convolution.default(reflection_pad2d_default_1, primals_4, primals_3, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_3 = None
        view_default_6 = torch.ops.aten.view.default(convolution_default_3, [1, 256, 64, 64]);  convolution_default_3 = None
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(view_default_6, None, None, None, None, True, 0.1, 1e-05)
        getitem_9 = native_batch_norm_default_3[0]
        getitem_10 = native_batch_norm_default_3[1]
        getitem_11 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        view_default_7 = torch.ops.aten.view.default(getitem_9, [1, 256, 64, 64]);  getitem_9 = None
        relu__default_3 = torch.ops.aten.relu_.default(view_default_7);  view_default_7 = None
        reflection_pad2d_default_2 = torch.ops.aten.reflection_pad2d.default(relu__default_3, [1, 1, 1, 1])
        convolution_default_4 = torch.ops.aten.convolution.default(reflection_pad2d_default_2, primals_6, primals_5, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_5 = None
        view_default_8 = torch.ops.aten.view.default(convolution_default_4, [1, 256, 64, 64]);  convolution_default_4 = None
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(view_default_8, None, None, None, None, True, 0.1, 1e-05)
        getitem_12 = native_batch_norm_default_4[0]
        getitem_13 = native_batch_norm_default_4[1]
        getitem_14 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        view_default_9 = torch.ops.aten.view.default(getitem_12, [1, 256, 64, 64]);  getitem_12 = None
        add_tensor = torch.ops.aten.add.Tensor(relu__default_2, view_default_9);  view_default_9 = None
        reflection_pad2d_default_3 = torch.ops.aten.reflection_pad2d.default(add_tensor, [1, 1, 1, 1])
        convolution_default_5 = torch.ops.aten.convolution.default(reflection_pad2d_default_3, primals_8, primals_7, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_7 = None
        view_default_10 = torch.ops.aten.view.default(convolution_default_5, [1, 256, 64, 64]);  convolution_default_5 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(view_default_10, None, None, None, None, True, 0.1, 1e-05)
        getitem_15 = native_batch_norm_default_5[0]
        getitem_16 = native_batch_norm_default_5[1]
        getitem_17 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        view_default_11 = torch.ops.aten.view.default(getitem_15, [1, 256, 64, 64]);  getitem_15 = None
        relu__default_4 = torch.ops.aten.relu_.default(view_default_11);  view_default_11 = None
        reflection_pad2d_default_4 = torch.ops.aten.reflection_pad2d.default(relu__default_4, [1, 1, 1, 1])
        convolution_default_6 = torch.ops.aten.convolution.default(reflection_pad2d_default_4, primals_10, primals_9, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_9 = None
        view_default_12 = torch.ops.aten.view.default(convolution_default_6, [1, 256, 64, 64]);  convolution_default_6 = None
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(view_default_12, None, None, None, None, True, 0.1, 1e-05)
        getitem_18 = native_batch_norm_default_6[0]
        getitem_19 = native_batch_norm_default_6[1]
        getitem_20 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        view_default_13 = torch.ops.aten.view.default(getitem_18, [1, 256, 64, 64]);  getitem_18 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(add_tensor, view_default_13);  view_default_13 = None
        reflection_pad2d_default_5 = torch.ops.aten.reflection_pad2d.default(add_tensor_1, [1, 1, 1, 1])
        convolution_default_7 = torch.ops.aten.convolution.default(reflection_pad2d_default_5, primals_12, primals_11, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_11 = None
        view_default_14 = torch.ops.aten.view.default(convolution_default_7, [1, 256, 64, 64]);  convolution_default_7 = None
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(view_default_14, None, None, None, None, True, 0.1, 1e-05)
        getitem_21 = native_batch_norm_default_7[0]
        getitem_22 = native_batch_norm_default_7[1]
        getitem_23 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        view_default_15 = torch.ops.aten.view.default(getitem_21, [1, 256, 64, 64]);  getitem_21 = None
        relu__default_5 = torch.ops.aten.relu_.default(view_default_15);  view_default_15 = None
        reflection_pad2d_default_6 = torch.ops.aten.reflection_pad2d.default(relu__default_5, [1, 1, 1, 1])
        convolution_default_8 = torch.ops.aten.convolution.default(reflection_pad2d_default_6, primals_14, primals_13, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_13 = None
        view_default_16 = torch.ops.aten.view.default(convolution_default_8, [1, 256, 64, 64]);  convolution_default_8 = None
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(view_default_16, None, None, None, None, True, 0.1, 1e-05)
        getitem_24 = native_batch_norm_default_8[0]
        getitem_25 = native_batch_norm_default_8[1]
        getitem_26 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        view_default_17 = torch.ops.aten.view.default(getitem_24, [1, 256, 64, 64]);  getitem_24 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(add_tensor_1, view_default_17);  view_default_17 = None
        reflection_pad2d_default_7 = torch.ops.aten.reflection_pad2d.default(add_tensor_2, [1, 1, 1, 1])
        convolution_default_9 = torch.ops.aten.convolution.default(reflection_pad2d_default_7, primals_16, primals_15, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_15 = None
        view_default_18 = torch.ops.aten.view.default(convolution_default_9, [1, 256, 64, 64]);  convolution_default_9 = None
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(view_default_18, None, None, None, None, True, 0.1, 1e-05)
        getitem_27 = native_batch_norm_default_9[0]
        getitem_28 = native_batch_norm_default_9[1]
        getitem_29 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        view_default_19 = torch.ops.aten.view.default(getitem_27, [1, 256, 64, 64]);  getitem_27 = None
        relu__default_6 = torch.ops.aten.relu_.default(view_default_19);  view_default_19 = None
        reflection_pad2d_default_8 = torch.ops.aten.reflection_pad2d.default(relu__default_6, [1, 1, 1, 1])
        convolution_default_10 = torch.ops.aten.convolution.default(reflection_pad2d_default_8, primals_18, primals_17, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_17 = None
        view_default_20 = torch.ops.aten.view.default(convolution_default_10, [1, 256, 64, 64]);  convolution_default_10 = None
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(view_default_20, None, None, None, None, True, 0.1, 1e-05)
        getitem_30 = native_batch_norm_default_10[0]
        getitem_31 = native_batch_norm_default_10[1]
        getitem_32 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        view_default_21 = torch.ops.aten.view.default(getitem_30, [1, 256, 64, 64]);  getitem_30 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(add_tensor_2, view_default_21);  view_default_21 = None
        reflection_pad2d_default_9 = torch.ops.aten.reflection_pad2d.default(add_tensor_3, [1, 1, 1, 1])
        convolution_default_11 = torch.ops.aten.convolution.default(reflection_pad2d_default_9, primals_20, primals_19, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_19 = None
        view_default_22 = torch.ops.aten.view.default(convolution_default_11, [1, 256, 64, 64]);  convolution_default_11 = None
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(view_default_22, None, None, None, None, True, 0.1, 1e-05)
        getitem_33 = native_batch_norm_default_11[0]
        getitem_34 = native_batch_norm_default_11[1]
        getitem_35 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        view_default_23 = torch.ops.aten.view.default(getitem_33, [1, 256, 64, 64]);  getitem_33 = None
        relu__default_7 = torch.ops.aten.relu_.default(view_default_23);  view_default_23 = None
        reflection_pad2d_default_10 = torch.ops.aten.reflection_pad2d.default(relu__default_7, [1, 1, 1, 1])
        convolution_default_12 = torch.ops.aten.convolution.default(reflection_pad2d_default_10, primals_22, primals_21, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_21 = None
        view_default_24 = torch.ops.aten.view.default(convolution_default_12, [1, 256, 64, 64]);  convolution_default_12 = None
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(view_default_24, None, None, None, None, True, 0.1, 1e-05)
        getitem_36 = native_batch_norm_default_12[0]
        getitem_37 = native_batch_norm_default_12[1]
        getitem_38 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        view_default_25 = torch.ops.aten.view.default(getitem_36, [1, 256, 64, 64]);  getitem_36 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(add_tensor_3, view_default_25);  view_default_25 = None
        reflection_pad2d_default_11 = torch.ops.aten.reflection_pad2d.default(add_tensor_4, [1, 1, 1, 1])
        convolution_default_13 = torch.ops.aten.convolution.default(reflection_pad2d_default_11, primals_24, primals_23, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_23 = None
        view_default_26 = torch.ops.aten.view.default(convolution_default_13, [1, 256, 64, 64]);  convolution_default_13 = None
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(view_default_26, None, None, None, None, True, 0.1, 1e-05)
        getitem_39 = native_batch_norm_default_13[0]
        getitem_40 = native_batch_norm_default_13[1]
        getitem_41 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        view_default_27 = torch.ops.aten.view.default(getitem_39, [1, 256, 64, 64]);  getitem_39 = None
        relu__default_8 = torch.ops.aten.relu_.default(view_default_27);  view_default_27 = None
        reflection_pad2d_default_12 = torch.ops.aten.reflection_pad2d.default(relu__default_8, [1, 1, 1, 1])
        convolution_default_14 = torch.ops.aten.convolution.default(reflection_pad2d_default_12, primals_26, primals_25, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_25 = None
        view_default_28 = torch.ops.aten.view.default(convolution_default_14, [1, 256, 64, 64]);  convolution_default_14 = None
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(view_default_28, None, None, None, None, True, 0.1, 1e-05)
        getitem_42 = native_batch_norm_default_14[0]
        getitem_43 = native_batch_norm_default_14[1]
        getitem_44 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        view_default_29 = torch.ops.aten.view.default(getitem_42, [1, 256, 64, 64]);  getitem_42 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(add_tensor_4, view_default_29);  view_default_29 = None
        reflection_pad2d_default_13 = torch.ops.aten.reflection_pad2d.default(add_tensor_5, [1, 1, 1, 1])
        convolution_default_15 = torch.ops.aten.convolution.default(reflection_pad2d_default_13, primals_28, primals_27, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_27 = None
        view_default_30 = torch.ops.aten.view.default(convolution_default_15, [1, 256, 64, 64]);  convolution_default_15 = None
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(view_default_30, None, None, None, None, True, 0.1, 1e-05)
        getitem_45 = native_batch_norm_default_15[0]
        getitem_46 = native_batch_norm_default_15[1]
        getitem_47 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        view_default_31 = torch.ops.aten.view.default(getitem_45, [1, 256, 64, 64]);  getitem_45 = None
        relu__default_9 = torch.ops.aten.relu_.default(view_default_31);  view_default_31 = None
        reflection_pad2d_default_14 = torch.ops.aten.reflection_pad2d.default(relu__default_9, [1, 1, 1, 1])
        convolution_default_16 = torch.ops.aten.convolution.default(reflection_pad2d_default_14, primals_30, primals_29, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_29 = None
        view_default_32 = torch.ops.aten.view.default(convolution_default_16, [1, 256, 64, 64]);  convolution_default_16 = None
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(view_default_32, None, None, None, None, True, 0.1, 1e-05)
        getitem_48 = native_batch_norm_default_16[0]
        getitem_49 = native_batch_norm_default_16[1]
        getitem_50 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        view_default_33 = torch.ops.aten.view.default(getitem_48, [1, 256, 64, 64]);  getitem_48 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(add_tensor_5, view_default_33);  view_default_33 = None
        reflection_pad2d_default_15 = torch.ops.aten.reflection_pad2d.default(add_tensor_6, [1, 1, 1, 1])
        convolution_default_17 = torch.ops.aten.convolution.default(reflection_pad2d_default_15, primals_32, primals_31, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_31 = None
        view_default_34 = torch.ops.aten.view.default(convolution_default_17, [1, 256, 64, 64]);  convolution_default_17 = None
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(view_default_34, None, None, None, None, True, 0.1, 1e-05)
        getitem_51 = native_batch_norm_default_17[0]
        getitem_52 = native_batch_norm_default_17[1]
        getitem_53 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        view_default_35 = torch.ops.aten.view.default(getitem_51, [1, 256, 64, 64]);  getitem_51 = None
        relu__default_10 = torch.ops.aten.relu_.default(view_default_35);  view_default_35 = None
        reflection_pad2d_default_16 = torch.ops.aten.reflection_pad2d.default(relu__default_10, [1, 1, 1, 1])
        convolution_default_18 = torch.ops.aten.convolution.default(reflection_pad2d_default_16, primals_34, primals_33, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_33 = None
        view_default_36 = torch.ops.aten.view.default(convolution_default_18, [1, 256, 64, 64]);  convolution_default_18 = None
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(view_default_36, None, None, None, None, True, 0.1, 1e-05)
        getitem_54 = native_batch_norm_default_18[0]
        getitem_55 = native_batch_norm_default_18[1]
        getitem_56 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        view_default_37 = torch.ops.aten.view.default(getitem_54, [1, 256, 64, 64]);  getitem_54 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(add_tensor_6, view_default_37);  view_default_37 = None
        reflection_pad2d_default_17 = torch.ops.aten.reflection_pad2d.default(add_tensor_7, [1, 1, 1, 1])
        convolution_default_19 = torch.ops.aten.convolution.default(reflection_pad2d_default_17, primals_36, primals_35, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_35 = None
        view_default_38 = torch.ops.aten.view.default(convolution_default_19, [1, 256, 64, 64]);  convolution_default_19 = None
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(view_default_38, None, None, None, None, True, 0.1, 1e-05)
        getitem_57 = native_batch_norm_default_19[0]
        getitem_58 = native_batch_norm_default_19[1]
        getitem_59 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        view_default_39 = torch.ops.aten.view.default(getitem_57, [1, 256, 64, 64]);  getitem_57 = None
        relu__default_11 = torch.ops.aten.relu_.default(view_default_39);  view_default_39 = None
        reflection_pad2d_default_18 = torch.ops.aten.reflection_pad2d.default(relu__default_11, [1, 1, 1, 1])
        convolution_default_20 = torch.ops.aten.convolution.default(reflection_pad2d_default_18, primals_38, primals_37, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_37 = None
        view_default_40 = torch.ops.aten.view.default(convolution_default_20, [1, 256, 64, 64]);  convolution_default_20 = None
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(view_default_40, None, None, None, None, True, 0.1, 1e-05)
        getitem_60 = native_batch_norm_default_20[0]
        getitem_61 = native_batch_norm_default_20[1]
        getitem_62 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        view_default_41 = torch.ops.aten.view.default(getitem_60, [1, 256, 64, 64]);  getitem_60 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(add_tensor_7, view_default_41);  view_default_41 = None
        convolution_default_21 = torch.ops.aten.convolution.default(add_tensor_8, primals_40, primals_39, [2, 2], [1, 1], [1, 1], True, [1, 1], 1);  primals_39 = None
        view_default_42 = torch.ops.aten.view.default(convolution_default_21, [1, 128, 128, 128]);  convolution_default_21 = None
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(view_default_42, None, None, None, None, True, 0.1, 1e-05)
        getitem_63 = native_batch_norm_default_21[0]
        getitem_64 = native_batch_norm_default_21[1]
        getitem_65 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        view_default_43 = torch.ops.aten.view.default(getitem_63, [1, 128, 128, 128]);  getitem_63 = None
        relu__default_12 = torch.ops.aten.relu_.default(view_default_43);  view_default_43 = None
        convolution_default_22 = torch.ops.aten.convolution.default(relu__default_12, primals_42, primals_41, [2, 2], [1, 1], [1, 1], True, [1, 1], 1);  primals_41 = None
        view_default_44 = torch.ops.aten.view.default(convolution_default_22, [1, 64, 256, 256]);  convolution_default_22 = None
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(view_default_44, None, None, None, None, True, 0.1, 1e-05)
        getitem_66 = native_batch_norm_default_22[0]
        getitem_67 = native_batch_norm_default_22[1]
        getitem_68 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        view_default_45 = torch.ops.aten.view.default(getitem_66, [1, 64, 256, 256]);  getitem_66 = None
        relu__default_13 = torch.ops.aten.relu_.default(view_default_45);  view_default_45 = None
        reflection_pad2d_default_19 = torch.ops.aten.reflection_pad2d.default(relu__default_13, [3, 3, 3, 3])
        convolution_default_23 = torch.ops.aten.convolution.default(reflection_pad2d_default_19, primals_44, primals_43, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_43 = None
        tanh_default = torch.ops.aten.tanh.default(convolution_default_23);  convolution_default_23 = None
        return [tanh_default, getitem_26, getitem_20, getitem_64, getitem_8, getitem_65, getitem_52, getitem_53, view_default_18, getitem_28, view_default_14, getitem_22, relu__default_12, getitem_29, view_default_6, getitem_10, getitem_23, relu__default_10, getitem_11, view_default_44, getitem_67, reflection_pad2d_default_16, getitem_68, relu__default_6, primals_6, relu__default_5, view_default_36, tanh_default, getitem_55, relu__default_3, reflection_pad2d_default_8, reflection_pad2d_default_6, getitem_56, reflection_pad2d_default_3, view_default_38, reflection_pad2d_default_2, relu__default_13, add_tensor_3, view_default_20, reflection_pad2d_default_17, primals_48, getitem_31, add_tensor_2, view_default_16, reflection_pad2d_default_9, reflection_pad2d_default_19, getitem_32, add_tensor_5, add_tensor, reflection_pad2d_default_7, add_tensor_7, view_default_8, getitem_25, primals_4, primals_28, getitem_2, getitem_14, primals_8, primals_30, getitem_13, getitem_58, primals_10, getitem_59, view_default_26, getitem_40, primals_32, getitem_46, view_default_22, getitem_34, primals_12, getitem_47, getitem_41, view_default_42, primals_34, getitem_35, view_default_10, view_default_2, getitem_16, primals_14, getitem_4, primals_36, relu__default_11, getitem_17, getitem_5, primals_16, relu__default_9, getitem_19, primals_38, relu__default_8, reflection_pad2d_default_18, primals_18, relu__default_7, reflection_pad2d_default_14, primals_40, reflection_pad2d_default_12, view_default_40, view_default_34, getitem_61, primals_20, relu__default_4, reflection_pad2d_default_5, reflection_pad2d_default_10, relu__default_1, add_tensor_6, primals_42, view_default_32, getitem_49, getitem_62, add_tensor_4, reflection_pad2d_default_15, primals_22, getitem_43, reflection_pad2d_default, reflection_pad2d_default_4, view_default_28, reflection_pad2d_default_13, primals_44, relu__default_2, view_default_24, reflection_pad2d_default_11, getitem_50, relu__default, getitem_44, primals_24, getitem_37, reflection_pad2d_default_1, primals_46, primals_2, view_default_4, getitem_38, primals_26, view_default, add_tensor_1, view_default_12, view_default_30, add_tensor_8, getitem_1, getitem_7]
        
