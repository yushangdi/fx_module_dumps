
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/pytorch_CycleGAN_and_pix2pix/pytorch_CycleGAN_and_pix2pix_joint_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, tangents_1):
        reflection_pad2d_default = torch.ops.aten.reflection_pad2d.default(primals_49, [3, 3, 3, 3]);  primals_49 = None
        convolution_default = torch.ops.aten.convolution.default(reflection_pad2d_default, primals_2, primals_1, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1 = None
        view_default = torch.ops.aten.view.default(convolution_default, [1, 64, 256, 256]);  convolution_default = None
        empty = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(view_default, None, None, None, None, True, 0.1, 1e-05)
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        view_default_1 = torch.ops.aten.view.default(getitem, [1, 64, 256, 256]);  getitem = None
        relu__default = torch.ops.aten.relu_.default(view_default_1);  view_default_1 = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default, primals_46, primals_45, [2, 2], [1, 1], [1, 1], False, [0, 0], 1);  primals_45 = None
        view_default_2 = torch.ops.aten.view.default(convolution_default_1, [1, 128, 128, 128]);  convolution_default_1 = None
        empty_1 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(view_default_2, None, None, None, None, True, 0.1, 1e-05)
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        view_default_3 = torch.ops.aten.view.default(getitem_3, [1, 128, 128, 128]);  getitem_3 = None
        relu__default_1 = torch.ops.aten.relu_.default(view_default_3);  view_default_3 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_48, primals_47, [2, 2], [1, 1], [1, 1], False, [0, 0], 1);  primals_47 = None
        view_default_4 = torch.ops.aten.view.default(convolution_default_2, [1, 256, 64, 64]);  convolution_default_2 = None
        empty_2 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(view_default_4, None, None, None, None, True, 0.1, 1e-05)
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        view_default_5 = torch.ops.aten.view.default(getitem_6, [1, 256, 64, 64]);  getitem_6 = None
        relu__default_2 = torch.ops.aten.relu_.default(view_default_5);  view_default_5 = None
        reflection_pad2d_default_1 = torch.ops.aten.reflection_pad2d.default(relu__default_2, [1, 1, 1, 1])
        convolution_default_3 = torch.ops.aten.convolution.default(reflection_pad2d_default_1, primals_4, primals_3, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_3 = None
        view_default_6 = torch.ops.aten.view.default(convolution_default_3, [1, 256, 64, 64]);  convolution_default_3 = None
        empty_3 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(view_default_6, None, None, None, None, True, 0.1, 1e-05)
        getitem_9 = native_batch_norm_default_3[0]
        getitem_10 = native_batch_norm_default_3[1]
        getitem_11 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        view_default_7 = torch.ops.aten.view.default(getitem_9, [1, 256, 64, 64]);  getitem_9 = None
        relu__default_3 = torch.ops.aten.relu_.default(view_default_7);  view_default_7 = None
        reflection_pad2d_default_2 = torch.ops.aten.reflection_pad2d.default(relu__default_3, [1, 1, 1, 1])
        convolution_default_4 = torch.ops.aten.convolution.default(reflection_pad2d_default_2, primals_6, primals_5, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_5 = None
        view_default_8 = torch.ops.aten.view.default(convolution_default_4, [1, 256, 64, 64]);  convolution_default_4 = None
        empty_4 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(view_default_8, None, None, None, None, True, 0.1, 1e-05)
        getitem_12 = native_batch_norm_default_4[0]
        getitem_13 = native_batch_norm_default_4[1]
        getitem_14 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        view_default_9 = torch.ops.aten.view.default(getitem_12, [1, 256, 64, 64]);  getitem_12 = None
        add_tensor = torch.ops.aten.add.Tensor(relu__default_2, view_default_9);  view_default_9 = None
        reflection_pad2d_default_3 = torch.ops.aten.reflection_pad2d.default(add_tensor, [1, 1, 1, 1])
        convolution_default_5 = torch.ops.aten.convolution.default(reflection_pad2d_default_3, primals_8, primals_7, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_7 = None
        view_default_10 = torch.ops.aten.view.default(convolution_default_5, [1, 256, 64, 64]);  convolution_default_5 = None
        empty_5 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(view_default_10, None, None, None, None, True, 0.1, 1e-05)
        getitem_15 = native_batch_norm_default_5[0]
        getitem_16 = native_batch_norm_default_5[1]
        getitem_17 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        view_default_11 = torch.ops.aten.view.default(getitem_15, [1, 256, 64, 64]);  getitem_15 = None
        relu__default_4 = torch.ops.aten.relu_.default(view_default_11);  view_default_11 = None
        reflection_pad2d_default_4 = torch.ops.aten.reflection_pad2d.default(relu__default_4, [1, 1, 1, 1])
        convolution_default_6 = torch.ops.aten.convolution.default(reflection_pad2d_default_4, primals_10, primals_9, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_9 = None
        view_default_12 = torch.ops.aten.view.default(convolution_default_6, [1, 256, 64, 64]);  convolution_default_6 = None
        empty_6 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(view_default_12, None, None, None, None, True, 0.1, 1e-05)
        getitem_18 = native_batch_norm_default_6[0]
        getitem_19 = native_batch_norm_default_6[1]
        getitem_20 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        view_default_13 = torch.ops.aten.view.default(getitem_18, [1, 256, 64, 64]);  getitem_18 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(add_tensor, view_default_13);  view_default_13 = None
        reflection_pad2d_default_5 = torch.ops.aten.reflection_pad2d.default(add_tensor_1, [1, 1, 1, 1])
        convolution_default_7 = torch.ops.aten.convolution.default(reflection_pad2d_default_5, primals_12, primals_11, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_11 = None
        view_default_14 = torch.ops.aten.view.default(convolution_default_7, [1, 256, 64, 64]);  convolution_default_7 = None
        empty_7 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(view_default_14, None, None, None, None, True, 0.1, 1e-05)
        getitem_21 = native_batch_norm_default_7[0]
        getitem_22 = native_batch_norm_default_7[1]
        getitem_23 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        view_default_15 = torch.ops.aten.view.default(getitem_21, [1, 256, 64, 64]);  getitem_21 = None
        relu__default_5 = torch.ops.aten.relu_.default(view_default_15);  view_default_15 = None
        reflection_pad2d_default_6 = torch.ops.aten.reflection_pad2d.default(relu__default_5, [1, 1, 1, 1])
        convolution_default_8 = torch.ops.aten.convolution.default(reflection_pad2d_default_6, primals_14, primals_13, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_13 = None
        view_default_16 = torch.ops.aten.view.default(convolution_default_8, [1, 256, 64, 64]);  convolution_default_8 = None
        empty_8 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(view_default_16, None, None, None, None, True, 0.1, 1e-05)
        getitem_24 = native_batch_norm_default_8[0]
        getitem_25 = native_batch_norm_default_8[1]
        getitem_26 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        view_default_17 = torch.ops.aten.view.default(getitem_24, [1, 256, 64, 64]);  getitem_24 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(add_tensor_1, view_default_17);  view_default_17 = None
        reflection_pad2d_default_7 = torch.ops.aten.reflection_pad2d.default(add_tensor_2, [1, 1, 1, 1])
        convolution_default_9 = torch.ops.aten.convolution.default(reflection_pad2d_default_7, primals_16, primals_15, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_15 = None
        view_default_18 = torch.ops.aten.view.default(convolution_default_9, [1, 256, 64, 64]);  convolution_default_9 = None
        empty_9 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(view_default_18, None, None, None, None, True, 0.1, 1e-05)
        getitem_27 = native_batch_norm_default_9[0]
        getitem_28 = native_batch_norm_default_9[1]
        getitem_29 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        view_default_19 = torch.ops.aten.view.default(getitem_27, [1, 256, 64, 64]);  getitem_27 = None
        relu__default_6 = torch.ops.aten.relu_.default(view_default_19);  view_default_19 = None
        reflection_pad2d_default_8 = torch.ops.aten.reflection_pad2d.default(relu__default_6, [1, 1, 1, 1])
        convolution_default_10 = torch.ops.aten.convolution.default(reflection_pad2d_default_8, primals_18, primals_17, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_17 = None
        view_default_20 = torch.ops.aten.view.default(convolution_default_10, [1, 256, 64, 64]);  convolution_default_10 = None
        empty_10 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(view_default_20, None, None, None, None, True, 0.1, 1e-05)
        getitem_30 = native_batch_norm_default_10[0]
        getitem_31 = native_batch_norm_default_10[1]
        getitem_32 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        view_default_21 = torch.ops.aten.view.default(getitem_30, [1, 256, 64, 64]);  getitem_30 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(add_tensor_2, view_default_21);  view_default_21 = None
        reflection_pad2d_default_9 = torch.ops.aten.reflection_pad2d.default(add_tensor_3, [1, 1, 1, 1])
        convolution_default_11 = torch.ops.aten.convolution.default(reflection_pad2d_default_9, primals_20, primals_19, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_19 = None
        view_default_22 = torch.ops.aten.view.default(convolution_default_11, [1, 256, 64, 64]);  convolution_default_11 = None
        empty_11 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(view_default_22, None, None, None, None, True, 0.1, 1e-05)
        getitem_33 = native_batch_norm_default_11[0]
        getitem_34 = native_batch_norm_default_11[1]
        getitem_35 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        view_default_23 = torch.ops.aten.view.default(getitem_33, [1, 256, 64, 64]);  getitem_33 = None
        relu__default_7 = torch.ops.aten.relu_.default(view_default_23);  view_default_23 = None
        reflection_pad2d_default_10 = torch.ops.aten.reflection_pad2d.default(relu__default_7, [1, 1, 1, 1])
        convolution_default_12 = torch.ops.aten.convolution.default(reflection_pad2d_default_10, primals_22, primals_21, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_21 = None
        view_default_24 = torch.ops.aten.view.default(convolution_default_12, [1, 256, 64, 64]);  convolution_default_12 = None
        empty_12 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(view_default_24, None, None, None, None, True, 0.1, 1e-05)
        getitem_36 = native_batch_norm_default_12[0]
        getitem_37 = native_batch_norm_default_12[1]
        getitem_38 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        view_default_25 = torch.ops.aten.view.default(getitem_36, [1, 256, 64, 64]);  getitem_36 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(add_tensor_3, view_default_25);  view_default_25 = None
        reflection_pad2d_default_11 = torch.ops.aten.reflection_pad2d.default(add_tensor_4, [1, 1, 1, 1])
        convolution_default_13 = torch.ops.aten.convolution.default(reflection_pad2d_default_11, primals_24, primals_23, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_23 = None
        view_default_26 = torch.ops.aten.view.default(convolution_default_13, [1, 256, 64, 64]);  convolution_default_13 = None
        empty_13 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(view_default_26, None, None, None, None, True, 0.1, 1e-05)
        getitem_39 = native_batch_norm_default_13[0]
        getitem_40 = native_batch_norm_default_13[1]
        getitem_41 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        view_default_27 = torch.ops.aten.view.default(getitem_39, [1, 256, 64, 64]);  getitem_39 = None
        relu__default_8 = torch.ops.aten.relu_.default(view_default_27);  view_default_27 = None
        reflection_pad2d_default_12 = torch.ops.aten.reflection_pad2d.default(relu__default_8, [1, 1, 1, 1])
        convolution_default_14 = torch.ops.aten.convolution.default(reflection_pad2d_default_12, primals_26, primals_25, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_25 = None
        view_default_28 = torch.ops.aten.view.default(convolution_default_14, [1, 256, 64, 64]);  convolution_default_14 = None
        empty_14 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(view_default_28, None, None, None, None, True, 0.1, 1e-05)
        getitem_42 = native_batch_norm_default_14[0]
        getitem_43 = native_batch_norm_default_14[1]
        getitem_44 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        view_default_29 = torch.ops.aten.view.default(getitem_42, [1, 256, 64, 64]);  getitem_42 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(add_tensor_4, view_default_29);  view_default_29 = None
        reflection_pad2d_default_13 = torch.ops.aten.reflection_pad2d.default(add_tensor_5, [1, 1, 1, 1])
        convolution_default_15 = torch.ops.aten.convolution.default(reflection_pad2d_default_13, primals_28, primals_27, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_27 = None
        view_default_30 = torch.ops.aten.view.default(convolution_default_15, [1, 256, 64, 64]);  convolution_default_15 = None
        empty_15 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(view_default_30, None, None, None, None, True, 0.1, 1e-05)
        getitem_45 = native_batch_norm_default_15[0]
        getitem_46 = native_batch_norm_default_15[1]
        getitem_47 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        view_default_31 = torch.ops.aten.view.default(getitem_45, [1, 256, 64, 64]);  getitem_45 = None
        relu__default_9 = torch.ops.aten.relu_.default(view_default_31);  view_default_31 = None
        reflection_pad2d_default_14 = torch.ops.aten.reflection_pad2d.default(relu__default_9, [1, 1, 1, 1])
        convolution_default_16 = torch.ops.aten.convolution.default(reflection_pad2d_default_14, primals_30, primals_29, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_29 = None
        view_default_32 = torch.ops.aten.view.default(convolution_default_16, [1, 256, 64, 64]);  convolution_default_16 = None
        empty_16 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(view_default_32, None, None, None, None, True, 0.1, 1e-05)
        getitem_48 = native_batch_norm_default_16[0]
        getitem_49 = native_batch_norm_default_16[1]
        getitem_50 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        view_default_33 = torch.ops.aten.view.default(getitem_48, [1, 256, 64, 64]);  getitem_48 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(add_tensor_5, view_default_33);  view_default_33 = None
        reflection_pad2d_default_15 = torch.ops.aten.reflection_pad2d.default(add_tensor_6, [1, 1, 1, 1])
        convolution_default_17 = torch.ops.aten.convolution.default(reflection_pad2d_default_15, primals_32, primals_31, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_31 = None
        view_default_34 = torch.ops.aten.view.default(convolution_default_17, [1, 256, 64, 64]);  convolution_default_17 = None
        empty_17 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(view_default_34, None, None, None, None, True, 0.1, 1e-05)
        getitem_51 = native_batch_norm_default_17[0]
        getitem_52 = native_batch_norm_default_17[1]
        getitem_53 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        view_default_35 = torch.ops.aten.view.default(getitem_51, [1, 256, 64, 64]);  getitem_51 = None
        relu__default_10 = torch.ops.aten.relu_.default(view_default_35);  view_default_35 = None
        reflection_pad2d_default_16 = torch.ops.aten.reflection_pad2d.default(relu__default_10, [1, 1, 1, 1])
        convolution_default_18 = torch.ops.aten.convolution.default(reflection_pad2d_default_16, primals_34, primals_33, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_33 = None
        view_default_36 = torch.ops.aten.view.default(convolution_default_18, [1, 256, 64, 64]);  convolution_default_18 = None
        empty_18 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(view_default_36, None, None, None, None, True, 0.1, 1e-05)
        getitem_54 = native_batch_norm_default_18[0]
        getitem_55 = native_batch_norm_default_18[1]
        getitem_56 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        view_default_37 = torch.ops.aten.view.default(getitem_54, [1, 256, 64, 64]);  getitem_54 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(add_tensor_6, view_default_37);  view_default_37 = None
        reflection_pad2d_default_17 = torch.ops.aten.reflection_pad2d.default(add_tensor_7, [1, 1, 1, 1])
        convolution_default_19 = torch.ops.aten.convolution.default(reflection_pad2d_default_17, primals_36, primals_35, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_35 = None
        view_default_38 = torch.ops.aten.view.default(convolution_default_19, [1, 256, 64, 64]);  convolution_default_19 = None
        empty_19 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(view_default_38, None, None, None, None, True, 0.1, 1e-05)
        getitem_57 = native_batch_norm_default_19[0]
        getitem_58 = native_batch_norm_default_19[1]
        getitem_59 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        view_default_39 = torch.ops.aten.view.default(getitem_57, [1, 256, 64, 64]);  getitem_57 = None
        relu__default_11 = torch.ops.aten.relu_.default(view_default_39);  view_default_39 = None
        reflection_pad2d_default_18 = torch.ops.aten.reflection_pad2d.default(relu__default_11, [1, 1, 1, 1])
        convolution_default_20 = torch.ops.aten.convolution.default(reflection_pad2d_default_18, primals_38, primals_37, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_37 = None
        view_default_40 = torch.ops.aten.view.default(convolution_default_20, [1, 256, 64, 64]);  convolution_default_20 = None
        empty_20 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(view_default_40, None, None, None, None, True, 0.1, 1e-05)
        getitem_60 = native_batch_norm_default_20[0]
        getitem_61 = native_batch_norm_default_20[1]
        getitem_62 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        view_default_41 = torch.ops.aten.view.default(getitem_60, [1, 256, 64, 64]);  getitem_60 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(add_tensor_7, view_default_41);  view_default_41 = None
        convolution_default_21 = torch.ops.aten.convolution.default(add_tensor_8, primals_40, primals_39, [2, 2], [1, 1], [1, 1], True, [1, 1], 1);  primals_39 = None
        view_default_42 = torch.ops.aten.view.default(convolution_default_21, [1, 128, 128, 128]);  convolution_default_21 = None
        empty_21 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(view_default_42, None, None, None, None, True, 0.1, 1e-05)
        getitem_63 = native_batch_norm_default_21[0]
        getitem_64 = native_batch_norm_default_21[1]
        getitem_65 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        view_default_43 = torch.ops.aten.view.default(getitem_63, [1, 128, 128, 128]);  getitem_63 = None
        relu__default_12 = torch.ops.aten.relu_.default(view_default_43);  view_default_43 = None
        convolution_default_22 = torch.ops.aten.convolution.default(relu__default_12, primals_42, primals_41, [2, 2], [1, 1], [1, 1], True, [1, 1], 1);  primals_41 = None
        view_default_44 = torch.ops.aten.view.default(convolution_default_22, [1, 64, 256, 256]);  convolution_default_22 = None
        empty_22 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(view_default_44, None, None, None, None, True, 0.1, 1e-05)
        getitem_66 = native_batch_norm_default_22[0]
        getitem_67 = native_batch_norm_default_22[1]
        getitem_68 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        view_default_45 = torch.ops.aten.view.default(getitem_66, [1, 64, 256, 256]);  getitem_66 = None
        relu__default_13 = torch.ops.aten.relu_.default(view_default_45);  view_default_45 = None
        reflection_pad2d_default_19 = torch.ops.aten.reflection_pad2d.default(relu__default_13, [3, 3, 3, 3])
        convolution_default_23 = torch.ops.aten.convolution.default(reflection_pad2d_default_19, primals_44, primals_43, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_43 = None
        tanh_default = torch.ops.aten.tanh.default(convolution_default_23);  convolution_default_23 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(tanh_default, tangents_1)
        to_dtype = torch.ops.aten.to.dtype(tangents_1, torch.float32);  tangents_1 = None
        to_dtype_1 = torch.ops.aten.to.dtype(tanh_default, torch.float32)
        mul_tensor = torch.ops.aten.mul.Tensor(to_dtype_1, to_dtype_1);  to_dtype_1 = None
        rsub_scalar = torch.ops.aten.rsub.Scalar(mul_tensor, 1);  mul_tensor = None
        conj_physical_default = torch.ops.aten.conj_physical.default(rsub_scalar);  rsub_scalar = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(to_dtype, conj_physical_default);  to_dtype = conj_physical_default = None
        to_dtype_2 = torch.ops.aten.to.dtype(mul_tensor_1, torch.float32);  mul_tensor_1 = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(to_dtype_2, reflection_pad2d_default_19, primals_44, [3], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_2 = reflection_pad2d_default_19 = primals_44 = None
        getitem_69 = convolution_backward_default[0]
        getitem_70 = convolution_backward_default[1]
        getitem_71 = convolution_backward_default[2];  convolution_backward_default = None
        reflection_pad2d_backward_default = torch.ops.aten.reflection_pad2d_backward.default(getitem_69, relu__default_13, [3, 3, 3, 3]);  getitem_69 = None
        squeeze_dim = torch.ops.aten.squeeze.dim(reflection_pad2d_backward_default, 0);  reflection_pad2d_backward_default = None
        new_empty_default = torch.ops.aten.new_empty.default(squeeze_dim, [4194304])
        zero__default = torch.ops.aten.zero_.default(new_empty_default);  new_empty_default = None
        as_strided_default = torch.ops.aten.as_strided.default(zero__default, [64, 256, 256], [65536, 256, 1], 0)
        copy__default = torch.ops.aten.copy_.default(as_strided_default, squeeze_dim);  as_strided_default = squeeze_dim = None
        as_strided_default_1 = torch.ops.aten.as_strided.default(zero__default, [1, 64, 256, 256], [4194304, 65536, 256, 1], 0);  zero__default = None
        new_empty_strided_default = torch.ops.aten.new_empty_strided.default(as_strided_default_1, [1, 64, 256, 256], [4194304, 65536, 256, 1])
        copy__default_1 = torch.ops.aten.copy_.default(new_empty_strided_default, as_strided_default_1);  new_empty_strided_default = as_strided_default_1 = None
        as_strided_default_2 = torch.ops.aten.as_strided.default(copy__default_1, [1, 64, 256, 256], [4194304, 65536, 256, 1], 0)
        clone_default = torch.ops.aten.clone.default(as_strided_default_2, memory_format = torch.contiguous_format)
        to_dtype_3 = torch.ops.aten.to.dtype(clone_default, torch.float32);  clone_default = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default, to_dtype_3);  le_scalar = new_zeros_default = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        copy__default_2 = torch.ops.aten.copy_.default(as_strided_default_2, to_dtype_5);  as_strided_default_2 = to_dtype_5 = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(copy__default_1, view_default_44, None, None, None, getitem_67, getitem_68, True, 1e-05, [True, False, False]);  copy__default_1 = view_default_44 = getitem_67 = getitem_68 = None
        getitem_72 = native_batch_norm_backward_default[0]
        getitem_73 = native_batch_norm_backward_default[1]
        getitem_74 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        view_default_46 = torch.ops.aten.view.default(getitem_72, [1, 64, 256, 256]);  getitem_72 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(view_default_46, relu__default_12, primals_42, [64], [2, 2], [1, 1], [1, 1], True, [1, 1], 1, [True, True, True]);  view_default_46 = primals_42 = None
        getitem_75 = convolution_backward_default_1[0]
        getitem_76 = convolution_backward_default_1[1]
        getitem_77 = convolution_backward_default_1[2];  convolution_backward_default_1 = None
        squeeze_dim_1 = torch.ops.aten.squeeze.dim(getitem_75, 0);  getitem_75 = None
        new_empty_default_1 = torch.ops.aten.new_empty.default(squeeze_dim_1, [2097152])
        zero__default_1 = torch.ops.aten.zero_.default(new_empty_default_1);  new_empty_default_1 = None
        as_strided_default_3 = torch.ops.aten.as_strided.default(zero__default_1, [128, 128, 128], [16384, 128, 1], 0)
        copy__default_3 = torch.ops.aten.copy_.default(as_strided_default_3, squeeze_dim_1);  as_strided_default_3 = squeeze_dim_1 = None
        as_strided_default_4 = torch.ops.aten.as_strided.default(zero__default_1, [1, 128, 128, 128], [2097152, 16384, 128, 1], 0);  zero__default_1 = None
        new_empty_strided_default_1 = torch.ops.aten.new_empty_strided.default(as_strided_default_4, [1, 128, 128, 128], [2097152, 16384, 128, 1])
        copy__default_4 = torch.ops.aten.copy_.default(new_empty_strided_default_1, as_strided_default_4);  new_empty_strided_default_1 = as_strided_default_4 = None
        as_strided_default_5 = torch.ops.aten.as_strided.default(copy__default_4, [1, 128, 128, 128], [2097152, 16384, 128, 1], 0)
        clone_default_1 = torch.ops.aten.clone.default(as_strided_default_5, memory_format = torch.contiguous_format)
        to_dtype_6 = torch.ops.aten.to.dtype(clone_default_1, torch.float32);  clone_default_1 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_1, to_dtype_6);  le_scalar_1 = new_zeros_default_1 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        copy__default_5 = torch.ops.aten.copy_.default(as_strided_default_5, to_dtype_8);  as_strided_default_5 = to_dtype_8 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(copy__default_4, view_default_42, None, None, None, getitem_64, getitem_65, True, 1e-05, [True, False, False]);  copy__default_4 = view_default_42 = getitem_64 = getitem_65 = None
        getitem_78 = native_batch_norm_backward_default_1[0]
        getitem_79 = native_batch_norm_backward_default_1[1]
        getitem_80 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        view_default_47 = torch.ops.aten.view.default(getitem_78, [1, 128, 128, 128]);  getitem_78 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(view_default_47, add_tensor_8, primals_40, [128], [2, 2], [1, 1], [1, 1], True, [1, 1], 1, [True, True, True]);  view_default_47 = add_tensor_8 = primals_40 = None
        getitem_81 = convolution_backward_default_2[0]
        getitem_82 = convolution_backward_default_2[1]
        getitem_83 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        view_default_48 = torch.ops.aten.view.default(getitem_81, [1, 256, 64, 64])
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(view_default_48, view_default_40, None, None, None, getitem_61, getitem_62, True, 1e-05, [True, False, False]);  view_default_48 = view_default_40 = getitem_61 = getitem_62 = None
        getitem_84 = native_batch_norm_backward_default_2[0]
        getitem_85 = native_batch_norm_backward_default_2[1]
        getitem_86 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        view_default_49 = torch.ops.aten.view.default(getitem_84, [1, 256, 64, 64]);  getitem_84 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(view_default_49, reflection_pad2d_default_18, primals_38, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_49 = reflection_pad2d_default_18 = primals_38 = None
        getitem_87 = convolution_backward_default_3[0]
        getitem_88 = convolution_backward_default_3[1]
        getitem_89 = convolution_backward_default_3[2];  convolution_backward_default_3 = None
        reflection_pad2d_backward_default_1 = torch.ops.aten.reflection_pad2d_backward.default(getitem_87, relu__default_11, [1, 1, 1, 1]);  getitem_87 = None
        squeeze_dim_2 = torch.ops.aten.squeeze.dim(reflection_pad2d_backward_default_1, 0);  reflection_pad2d_backward_default_1 = None
        new_empty_default_2 = torch.ops.aten.new_empty.default(squeeze_dim_2, [1048576])
        zero__default_2 = torch.ops.aten.zero_.default(new_empty_default_2);  new_empty_default_2 = None
        as_strided_default_6 = torch.ops.aten.as_strided.default(zero__default_2, [256, 64, 64], [4096, 64, 1], 0)
        copy__default_6 = torch.ops.aten.copy_.default(as_strided_default_6, squeeze_dim_2);  as_strided_default_6 = squeeze_dim_2 = None
        as_strided_default_7 = torch.ops.aten.as_strided.default(zero__default_2, [1, 256, 64, 64], [1048576, 4096, 64, 1], 0);  zero__default_2 = None
        new_empty_strided_default_2 = torch.ops.aten.new_empty_strided.default(as_strided_default_7, [1, 256, 64, 64], [1048576, 4096, 64, 1])
        copy__default_7 = torch.ops.aten.copy_.default(new_empty_strided_default_2, as_strided_default_7);  new_empty_strided_default_2 = as_strided_default_7 = None
        as_strided_default_8 = torch.ops.aten.as_strided.default(copy__default_7, [1, 256, 64, 64], [1048576, 4096, 64, 1], 0)
        clone_default_2 = torch.ops.aten.clone.default(as_strided_default_8, memory_format = torch.contiguous_format)
        to_dtype_9 = torch.ops.aten.to.dtype(clone_default_2, torch.float32);  clone_default_2 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_2 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_2, to_dtype_9);  le_scalar_2 = new_zeros_default_2 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        copy__default_8 = torch.ops.aten.copy_.default(as_strided_default_8, to_dtype_11);  as_strided_default_8 = to_dtype_11 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(copy__default_7, view_default_38, None, None, None, getitem_58, getitem_59, True, 1e-05, [True, False, False]);  copy__default_7 = view_default_38 = getitem_58 = getitem_59 = None
        getitem_90 = native_batch_norm_backward_default_3[0]
        getitem_91 = native_batch_norm_backward_default_3[1]
        getitem_92 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        view_default_50 = torch.ops.aten.view.default(getitem_90, [1, 256, 64, 64]);  getitem_90 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(view_default_50, reflection_pad2d_default_17, primals_36, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_50 = reflection_pad2d_default_17 = primals_36 = None
        getitem_93 = convolution_backward_default_4[0]
        getitem_94 = convolution_backward_default_4[1]
        getitem_95 = convolution_backward_default_4[2];  convolution_backward_default_4 = None
        reflection_pad2d_backward_default_2 = torch.ops.aten.reflection_pad2d_backward.default(getitem_93, add_tensor_7, [1, 1, 1, 1]);  getitem_93 = add_tensor_7 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(getitem_81, reflection_pad2d_backward_default_2);  getitem_81 = reflection_pad2d_backward_default_2 = None
        view_default_51 = torch.ops.aten.view.default(add_tensor_9, [1, 256, 64, 64])
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(view_default_51, view_default_36, None, None, None, getitem_55, getitem_56, True, 1e-05, [True, False, False]);  view_default_51 = view_default_36 = getitem_55 = getitem_56 = None
        getitem_96 = native_batch_norm_backward_default_4[0]
        getitem_97 = native_batch_norm_backward_default_4[1]
        getitem_98 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        view_default_52 = torch.ops.aten.view.default(getitem_96, [1, 256, 64, 64]);  getitem_96 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(view_default_52, reflection_pad2d_default_16, primals_34, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_52 = reflection_pad2d_default_16 = primals_34 = None
        getitem_99 = convolution_backward_default_5[0]
        getitem_100 = convolution_backward_default_5[1]
        getitem_101 = convolution_backward_default_5[2];  convolution_backward_default_5 = None
        reflection_pad2d_backward_default_3 = torch.ops.aten.reflection_pad2d_backward.default(getitem_99, relu__default_10, [1, 1, 1, 1]);  getitem_99 = None
        squeeze_dim_3 = torch.ops.aten.squeeze.dim(reflection_pad2d_backward_default_3, 0);  reflection_pad2d_backward_default_3 = None
        new_empty_default_3 = torch.ops.aten.new_empty.default(squeeze_dim_3, [1048576])
        zero__default_3 = torch.ops.aten.zero_.default(new_empty_default_3);  new_empty_default_3 = None
        as_strided_default_9 = torch.ops.aten.as_strided.default(zero__default_3, [256, 64, 64], [4096, 64, 1], 0)
        copy__default_9 = torch.ops.aten.copy_.default(as_strided_default_9, squeeze_dim_3);  as_strided_default_9 = squeeze_dim_3 = None
        as_strided_default_10 = torch.ops.aten.as_strided.default(zero__default_3, [1, 256, 64, 64], [1048576, 4096, 64, 1], 0);  zero__default_3 = None
        new_empty_strided_default_3 = torch.ops.aten.new_empty_strided.default(as_strided_default_10, [1, 256, 64, 64], [1048576, 4096, 64, 1])
        copy__default_10 = torch.ops.aten.copy_.default(new_empty_strided_default_3, as_strided_default_10);  new_empty_strided_default_3 = as_strided_default_10 = None
        as_strided_default_11 = torch.ops.aten.as_strided.default(copy__default_10, [1, 256, 64, 64], [1048576, 4096, 64, 1], 0)
        clone_default_3 = torch.ops.aten.clone.default(as_strided_default_11, memory_format = torch.contiguous_format)
        to_dtype_12 = torch.ops.aten.to.dtype(clone_default_3, torch.float32);  clone_default_3 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_3, to_dtype_12);  le_scalar_3 = new_zeros_default_3 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        copy__default_11 = torch.ops.aten.copy_.default(as_strided_default_11, to_dtype_14);  as_strided_default_11 = to_dtype_14 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(copy__default_10, view_default_34, None, None, None, getitem_52, getitem_53, True, 1e-05, [True, False, False]);  copy__default_10 = view_default_34 = getitem_52 = getitem_53 = None
        getitem_102 = native_batch_norm_backward_default_5[0]
        getitem_103 = native_batch_norm_backward_default_5[1]
        getitem_104 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        view_default_53 = torch.ops.aten.view.default(getitem_102, [1, 256, 64, 64]);  getitem_102 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(view_default_53, reflection_pad2d_default_15, primals_32, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_53 = reflection_pad2d_default_15 = primals_32 = None
        getitem_105 = convolution_backward_default_6[0]
        getitem_106 = convolution_backward_default_6[1]
        getitem_107 = convolution_backward_default_6[2];  convolution_backward_default_6 = None
        reflection_pad2d_backward_default_4 = torch.ops.aten.reflection_pad2d_backward.default(getitem_105, add_tensor_6, [1, 1, 1, 1]);  getitem_105 = add_tensor_6 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(add_tensor_9, reflection_pad2d_backward_default_4);  add_tensor_9 = reflection_pad2d_backward_default_4 = None
        view_default_54 = torch.ops.aten.view.default(add_tensor_10, [1, 256, 64, 64])
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(view_default_54, view_default_32, None, None, None, getitem_49, getitem_50, True, 1e-05, [True, False, False]);  view_default_54 = view_default_32 = getitem_49 = getitem_50 = None
        getitem_108 = native_batch_norm_backward_default_6[0]
        getitem_109 = native_batch_norm_backward_default_6[1]
        getitem_110 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        view_default_55 = torch.ops.aten.view.default(getitem_108, [1, 256, 64, 64]);  getitem_108 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(view_default_55, reflection_pad2d_default_14, primals_30, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_55 = reflection_pad2d_default_14 = primals_30 = None
        getitem_111 = convolution_backward_default_7[0]
        getitem_112 = convolution_backward_default_7[1]
        getitem_113 = convolution_backward_default_7[2];  convolution_backward_default_7 = None
        reflection_pad2d_backward_default_5 = torch.ops.aten.reflection_pad2d_backward.default(getitem_111, relu__default_9, [1, 1, 1, 1]);  getitem_111 = None
        squeeze_dim_4 = torch.ops.aten.squeeze.dim(reflection_pad2d_backward_default_5, 0);  reflection_pad2d_backward_default_5 = None
        new_empty_default_4 = torch.ops.aten.new_empty.default(squeeze_dim_4, [1048576])
        zero__default_4 = torch.ops.aten.zero_.default(new_empty_default_4);  new_empty_default_4 = None
        as_strided_default_12 = torch.ops.aten.as_strided.default(zero__default_4, [256, 64, 64], [4096, 64, 1], 0)
        copy__default_12 = torch.ops.aten.copy_.default(as_strided_default_12, squeeze_dim_4);  as_strided_default_12 = squeeze_dim_4 = None
        as_strided_default_13 = torch.ops.aten.as_strided.default(zero__default_4, [1, 256, 64, 64], [1048576, 4096, 64, 1], 0);  zero__default_4 = None
        new_empty_strided_default_4 = torch.ops.aten.new_empty_strided.default(as_strided_default_13, [1, 256, 64, 64], [1048576, 4096, 64, 1])
        copy__default_13 = torch.ops.aten.copy_.default(new_empty_strided_default_4, as_strided_default_13);  new_empty_strided_default_4 = as_strided_default_13 = None
        as_strided_default_14 = torch.ops.aten.as_strided.default(copy__default_13, [1, 256, 64, 64], [1048576, 4096, 64, 1], 0)
        clone_default_4 = torch.ops.aten.clone.default(as_strided_default_14, memory_format = torch.contiguous_format)
        to_dtype_15 = torch.ops.aten.to.dtype(clone_default_4, torch.float32);  clone_default_4 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_4, to_dtype_15);  le_scalar_4 = new_zeros_default_4 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        copy__default_14 = torch.ops.aten.copy_.default(as_strided_default_14, to_dtype_17);  as_strided_default_14 = to_dtype_17 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(copy__default_13, view_default_30, None, None, None, getitem_46, getitem_47, True, 1e-05, [True, False, False]);  copy__default_13 = view_default_30 = getitem_46 = getitem_47 = None
        getitem_114 = native_batch_norm_backward_default_7[0]
        getitem_115 = native_batch_norm_backward_default_7[1]
        getitem_116 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        view_default_56 = torch.ops.aten.view.default(getitem_114, [1, 256, 64, 64]);  getitem_114 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(view_default_56, reflection_pad2d_default_13, primals_28, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_56 = reflection_pad2d_default_13 = primals_28 = None
        getitem_117 = convolution_backward_default_8[0]
        getitem_118 = convolution_backward_default_8[1]
        getitem_119 = convolution_backward_default_8[2];  convolution_backward_default_8 = None
        reflection_pad2d_backward_default_6 = torch.ops.aten.reflection_pad2d_backward.default(getitem_117, add_tensor_5, [1, 1, 1, 1]);  getitem_117 = add_tensor_5 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(add_tensor_10, reflection_pad2d_backward_default_6);  add_tensor_10 = reflection_pad2d_backward_default_6 = None
        view_default_57 = torch.ops.aten.view.default(add_tensor_11, [1, 256, 64, 64])
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(view_default_57, view_default_28, None, None, None, getitem_43, getitem_44, True, 1e-05, [True, False, False]);  view_default_57 = view_default_28 = getitem_43 = getitem_44 = None
        getitem_120 = native_batch_norm_backward_default_8[0]
        getitem_121 = native_batch_norm_backward_default_8[1]
        getitem_122 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        view_default_58 = torch.ops.aten.view.default(getitem_120, [1, 256, 64, 64]);  getitem_120 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(view_default_58, reflection_pad2d_default_12, primals_26, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_58 = reflection_pad2d_default_12 = primals_26 = None
        getitem_123 = convolution_backward_default_9[0]
        getitem_124 = convolution_backward_default_9[1]
        getitem_125 = convolution_backward_default_9[2];  convolution_backward_default_9 = None
        reflection_pad2d_backward_default_7 = torch.ops.aten.reflection_pad2d_backward.default(getitem_123, relu__default_8, [1, 1, 1, 1]);  getitem_123 = None
        squeeze_dim_5 = torch.ops.aten.squeeze.dim(reflection_pad2d_backward_default_7, 0);  reflection_pad2d_backward_default_7 = None
        new_empty_default_5 = torch.ops.aten.new_empty.default(squeeze_dim_5, [1048576])
        zero__default_5 = torch.ops.aten.zero_.default(new_empty_default_5);  new_empty_default_5 = None
        as_strided_default_15 = torch.ops.aten.as_strided.default(zero__default_5, [256, 64, 64], [4096, 64, 1], 0)
        copy__default_15 = torch.ops.aten.copy_.default(as_strided_default_15, squeeze_dim_5);  as_strided_default_15 = squeeze_dim_5 = None
        as_strided_default_16 = torch.ops.aten.as_strided.default(zero__default_5, [1, 256, 64, 64], [1048576, 4096, 64, 1], 0);  zero__default_5 = None
        new_empty_strided_default_5 = torch.ops.aten.new_empty_strided.default(as_strided_default_16, [1, 256, 64, 64], [1048576, 4096, 64, 1])
        copy__default_16 = torch.ops.aten.copy_.default(new_empty_strided_default_5, as_strided_default_16);  new_empty_strided_default_5 = as_strided_default_16 = None
        as_strided_default_17 = torch.ops.aten.as_strided.default(copy__default_16, [1, 256, 64, 64], [1048576, 4096, 64, 1], 0)
        clone_default_5 = torch.ops.aten.clone.default(as_strided_default_17, memory_format = torch.contiguous_format)
        to_dtype_18 = torch.ops.aten.to.dtype(clone_default_5, torch.float32);  clone_default_5 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_5 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_5, to_dtype_18);  le_scalar_5 = new_zeros_default_5 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        copy__default_17 = torch.ops.aten.copy_.default(as_strided_default_17, to_dtype_20);  as_strided_default_17 = to_dtype_20 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(copy__default_16, view_default_26, None, None, None, getitem_40, getitem_41, True, 1e-05, [True, False, False]);  copy__default_16 = view_default_26 = getitem_40 = getitem_41 = None
        getitem_126 = native_batch_norm_backward_default_9[0]
        getitem_127 = native_batch_norm_backward_default_9[1]
        getitem_128 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        view_default_59 = torch.ops.aten.view.default(getitem_126, [1, 256, 64, 64]);  getitem_126 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(view_default_59, reflection_pad2d_default_11, primals_24, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_59 = reflection_pad2d_default_11 = primals_24 = None
        getitem_129 = convolution_backward_default_10[0]
        getitem_130 = convolution_backward_default_10[1]
        getitem_131 = convolution_backward_default_10[2];  convolution_backward_default_10 = None
        reflection_pad2d_backward_default_8 = torch.ops.aten.reflection_pad2d_backward.default(getitem_129, add_tensor_4, [1, 1, 1, 1]);  getitem_129 = add_tensor_4 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(add_tensor_11, reflection_pad2d_backward_default_8);  add_tensor_11 = reflection_pad2d_backward_default_8 = None
        view_default_60 = torch.ops.aten.view.default(add_tensor_12, [1, 256, 64, 64])
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(view_default_60, view_default_24, None, None, None, getitem_37, getitem_38, True, 1e-05, [True, False, False]);  view_default_60 = view_default_24 = getitem_37 = getitem_38 = None
        getitem_132 = native_batch_norm_backward_default_10[0]
        getitem_133 = native_batch_norm_backward_default_10[1]
        getitem_134 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        view_default_61 = torch.ops.aten.view.default(getitem_132, [1, 256, 64, 64]);  getitem_132 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(view_default_61, reflection_pad2d_default_10, primals_22, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_61 = reflection_pad2d_default_10 = primals_22 = None
        getitem_135 = convolution_backward_default_11[0]
        getitem_136 = convolution_backward_default_11[1]
        getitem_137 = convolution_backward_default_11[2];  convolution_backward_default_11 = None
        reflection_pad2d_backward_default_9 = torch.ops.aten.reflection_pad2d_backward.default(getitem_135, relu__default_7, [1, 1, 1, 1]);  getitem_135 = None
        squeeze_dim_6 = torch.ops.aten.squeeze.dim(reflection_pad2d_backward_default_9, 0);  reflection_pad2d_backward_default_9 = None
        new_empty_default_6 = torch.ops.aten.new_empty.default(squeeze_dim_6, [1048576])
        zero__default_6 = torch.ops.aten.zero_.default(new_empty_default_6);  new_empty_default_6 = None
        as_strided_default_18 = torch.ops.aten.as_strided.default(zero__default_6, [256, 64, 64], [4096, 64, 1], 0)
        copy__default_18 = torch.ops.aten.copy_.default(as_strided_default_18, squeeze_dim_6);  as_strided_default_18 = squeeze_dim_6 = None
        as_strided_default_19 = torch.ops.aten.as_strided.default(zero__default_6, [1, 256, 64, 64], [1048576, 4096, 64, 1], 0);  zero__default_6 = None
        new_empty_strided_default_6 = torch.ops.aten.new_empty_strided.default(as_strided_default_19, [1, 256, 64, 64], [1048576, 4096, 64, 1])
        copy__default_19 = torch.ops.aten.copy_.default(new_empty_strided_default_6, as_strided_default_19);  new_empty_strided_default_6 = as_strided_default_19 = None
        as_strided_default_20 = torch.ops.aten.as_strided.default(copy__default_19, [1, 256, 64, 64], [1048576, 4096, 64, 1], 0)
        clone_default_6 = torch.ops.aten.clone.default(as_strided_default_20, memory_format = torch.contiguous_format)
        to_dtype_21 = torch.ops.aten.to.dtype(clone_default_6, torch.float32);  clone_default_6 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_6, to_dtype_21);  le_scalar_6 = new_zeros_default_6 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        copy__default_20 = torch.ops.aten.copy_.default(as_strided_default_20, to_dtype_23);  as_strided_default_20 = to_dtype_23 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(copy__default_19, view_default_22, None, None, None, getitem_34, getitem_35, True, 1e-05, [True, False, False]);  copy__default_19 = view_default_22 = getitem_34 = getitem_35 = None
        getitem_138 = native_batch_norm_backward_default_11[0]
        getitem_139 = native_batch_norm_backward_default_11[1]
        getitem_140 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        view_default_62 = torch.ops.aten.view.default(getitem_138, [1, 256, 64, 64]);  getitem_138 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(view_default_62, reflection_pad2d_default_9, primals_20, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_62 = reflection_pad2d_default_9 = primals_20 = None
        getitem_141 = convolution_backward_default_12[0]
        getitem_142 = convolution_backward_default_12[1]
        getitem_143 = convolution_backward_default_12[2];  convolution_backward_default_12 = None
        reflection_pad2d_backward_default_10 = torch.ops.aten.reflection_pad2d_backward.default(getitem_141, add_tensor_3, [1, 1, 1, 1]);  getitem_141 = add_tensor_3 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(add_tensor_12, reflection_pad2d_backward_default_10);  add_tensor_12 = reflection_pad2d_backward_default_10 = None
        view_default_63 = torch.ops.aten.view.default(add_tensor_13, [1, 256, 64, 64])
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(view_default_63, view_default_20, None, None, None, getitem_31, getitem_32, True, 1e-05, [True, False, False]);  view_default_63 = view_default_20 = getitem_31 = getitem_32 = None
        getitem_144 = native_batch_norm_backward_default_12[0]
        getitem_145 = native_batch_norm_backward_default_12[1]
        getitem_146 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        view_default_64 = torch.ops.aten.view.default(getitem_144, [1, 256, 64, 64]);  getitem_144 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(view_default_64, reflection_pad2d_default_8, primals_18, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_64 = reflection_pad2d_default_8 = primals_18 = None
        getitem_147 = convolution_backward_default_13[0]
        getitem_148 = convolution_backward_default_13[1]
        getitem_149 = convolution_backward_default_13[2];  convolution_backward_default_13 = None
        reflection_pad2d_backward_default_11 = torch.ops.aten.reflection_pad2d_backward.default(getitem_147, relu__default_6, [1, 1, 1, 1]);  getitem_147 = None
        squeeze_dim_7 = torch.ops.aten.squeeze.dim(reflection_pad2d_backward_default_11, 0);  reflection_pad2d_backward_default_11 = None
        new_empty_default_7 = torch.ops.aten.new_empty.default(squeeze_dim_7, [1048576])
        zero__default_7 = torch.ops.aten.zero_.default(new_empty_default_7);  new_empty_default_7 = None
        as_strided_default_21 = torch.ops.aten.as_strided.default(zero__default_7, [256, 64, 64], [4096, 64, 1], 0)
        copy__default_21 = torch.ops.aten.copy_.default(as_strided_default_21, squeeze_dim_7);  as_strided_default_21 = squeeze_dim_7 = None
        as_strided_default_22 = torch.ops.aten.as_strided.default(zero__default_7, [1, 256, 64, 64], [1048576, 4096, 64, 1], 0);  zero__default_7 = None
        new_empty_strided_default_7 = torch.ops.aten.new_empty_strided.default(as_strided_default_22, [1, 256, 64, 64], [1048576, 4096, 64, 1])
        copy__default_22 = torch.ops.aten.copy_.default(new_empty_strided_default_7, as_strided_default_22);  new_empty_strided_default_7 = as_strided_default_22 = None
        as_strided_default_23 = torch.ops.aten.as_strided.default(copy__default_22, [1, 256, 64, 64], [1048576, 4096, 64, 1], 0)
        clone_default_7 = torch.ops.aten.clone.default(as_strided_default_23, memory_format = torch.contiguous_format)
        to_dtype_24 = torch.ops.aten.to.dtype(clone_default_7, torch.float32);  clone_default_7 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_7, to_dtype_24);  le_scalar_7 = new_zeros_default_7 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        copy__default_23 = torch.ops.aten.copy_.default(as_strided_default_23, to_dtype_26);  as_strided_default_23 = to_dtype_26 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(copy__default_22, view_default_18, None, None, None, getitem_28, getitem_29, True, 1e-05, [True, False, False]);  copy__default_22 = view_default_18 = getitem_28 = getitem_29 = None
        getitem_150 = native_batch_norm_backward_default_13[0]
        getitem_151 = native_batch_norm_backward_default_13[1]
        getitem_152 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        view_default_65 = torch.ops.aten.view.default(getitem_150, [1, 256, 64, 64]);  getitem_150 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(view_default_65, reflection_pad2d_default_7, primals_16, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_65 = reflection_pad2d_default_7 = primals_16 = None
        getitem_153 = convolution_backward_default_14[0]
        getitem_154 = convolution_backward_default_14[1]
        getitem_155 = convolution_backward_default_14[2];  convolution_backward_default_14 = None
        reflection_pad2d_backward_default_12 = torch.ops.aten.reflection_pad2d_backward.default(getitem_153, add_tensor_2, [1, 1, 1, 1]);  getitem_153 = add_tensor_2 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(add_tensor_13, reflection_pad2d_backward_default_12);  add_tensor_13 = reflection_pad2d_backward_default_12 = None
        view_default_66 = torch.ops.aten.view.default(add_tensor_14, [1, 256, 64, 64])
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(view_default_66, view_default_16, None, None, None, getitem_25, getitem_26, True, 1e-05, [True, False, False]);  view_default_66 = view_default_16 = getitem_25 = getitem_26 = None
        getitem_156 = native_batch_norm_backward_default_14[0]
        getitem_157 = native_batch_norm_backward_default_14[1]
        getitem_158 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        view_default_67 = torch.ops.aten.view.default(getitem_156, [1, 256, 64, 64]);  getitem_156 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(view_default_67, reflection_pad2d_default_6, primals_14, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_67 = reflection_pad2d_default_6 = primals_14 = None
        getitem_159 = convolution_backward_default_15[0]
        getitem_160 = convolution_backward_default_15[1]
        getitem_161 = convolution_backward_default_15[2];  convolution_backward_default_15 = None
        reflection_pad2d_backward_default_13 = torch.ops.aten.reflection_pad2d_backward.default(getitem_159, relu__default_5, [1, 1, 1, 1]);  getitem_159 = None
        squeeze_dim_8 = torch.ops.aten.squeeze.dim(reflection_pad2d_backward_default_13, 0);  reflection_pad2d_backward_default_13 = None
        new_empty_default_8 = torch.ops.aten.new_empty.default(squeeze_dim_8, [1048576])
        zero__default_8 = torch.ops.aten.zero_.default(new_empty_default_8);  new_empty_default_8 = None
        as_strided_default_24 = torch.ops.aten.as_strided.default(zero__default_8, [256, 64, 64], [4096, 64, 1], 0)
        copy__default_24 = torch.ops.aten.copy_.default(as_strided_default_24, squeeze_dim_8);  as_strided_default_24 = squeeze_dim_8 = None
        as_strided_default_25 = torch.ops.aten.as_strided.default(zero__default_8, [1, 256, 64, 64], [1048576, 4096, 64, 1], 0);  zero__default_8 = None
        new_empty_strided_default_8 = torch.ops.aten.new_empty_strided.default(as_strided_default_25, [1, 256, 64, 64], [1048576, 4096, 64, 1])
        copy__default_25 = torch.ops.aten.copy_.default(new_empty_strided_default_8, as_strided_default_25);  new_empty_strided_default_8 = as_strided_default_25 = None
        as_strided_default_26 = torch.ops.aten.as_strided.default(copy__default_25, [1, 256, 64, 64], [1048576, 4096, 64, 1], 0)
        clone_default_8 = torch.ops.aten.clone.default(as_strided_default_26, memory_format = torch.contiguous_format)
        to_dtype_27 = torch.ops.aten.to.dtype(clone_default_8, torch.float32);  clone_default_8 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_8 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_8, to_dtype_27);  le_scalar_8 = new_zeros_default_8 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        copy__default_26 = torch.ops.aten.copy_.default(as_strided_default_26, to_dtype_29);  as_strided_default_26 = to_dtype_29 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(copy__default_25, view_default_14, None, None, None, getitem_22, getitem_23, True, 1e-05, [True, False, False]);  copy__default_25 = view_default_14 = getitem_22 = getitem_23 = None
        getitem_162 = native_batch_norm_backward_default_15[0]
        getitem_163 = native_batch_norm_backward_default_15[1]
        getitem_164 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        view_default_68 = torch.ops.aten.view.default(getitem_162, [1, 256, 64, 64]);  getitem_162 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(view_default_68, reflection_pad2d_default_5, primals_12, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_68 = reflection_pad2d_default_5 = primals_12 = None
        getitem_165 = convolution_backward_default_16[0]
        getitem_166 = convolution_backward_default_16[1]
        getitem_167 = convolution_backward_default_16[2];  convolution_backward_default_16 = None
        reflection_pad2d_backward_default_14 = torch.ops.aten.reflection_pad2d_backward.default(getitem_165, add_tensor_1, [1, 1, 1, 1]);  getitem_165 = add_tensor_1 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(add_tensor_14, reflection_pad2d_backward_default_14);  add_tensor_14 = reflection_pad2d_backward_default_14 = None
        view_default_69 = torch.ops.aten.view.default(add_tensor_15, [1, 256, 64, 64])
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(view_default_69, view_default_12, None, None, None, getitem_19, getitem_20, True, 1e-05, [True, False, False]);  view_default_69 = view_default_12 = getitem_19 = getitem_20 = None
        getitem_168 = native_batch_norm_backward_default_16[0]
        getitem_169 = native_batch_norm_backward_default_16[1]
        getitem_170 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        view_default_70 = torch.ops.aten.view.default(getitem_168, [1, 256, 64, 64]);  getitem_168 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(view_default_70, reflection_pad2d_default_4, primals_10, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_70 = reflection_pad2d_default_4 = primals_10 = None
        getitem_171 = convolution_backward_default_17[0]
        getitem_172 = convolution_backward_default_17[1]
        getitem_173 = convolution_backward_default_17[2];  convolution_backward_default_17 = None
        reflection_pad2d_backward_default_15 = torch.ops.aten.reflection_pad2d_backward.default(getitem_171, relu__default_4, [1, 1, 1, 1]);  getitem_171 = None
        squeeze_dim_9 = torch.ops.aten.squeeze.dim(reflection_pad2d_backward_default_15, 0);  reflection_pad2d_backward_default_15 = None
        new_empty_default_9 = torch.ops.aten.new_empty.default(squeeze_dim_9, [1048576])
        zero__default_9 = torch.ops.aten.zero_.default(new_empty_default_9);  new_empty_default_9 = None
        as_strided_default_27 = torch.ops.aten.as_strided.default(zero__default_9, [256, 64, 64], [4096, 64, 1], 0)
        copy__default_27 = torch.ops.aten.copy_.default(as_strided_default_27, squeeze_dim_9);  as_strided_default_27 = squeeze_dim_9 = None
        as_strided_default_28 = torch.ops.aten.as_strided.default(zero__default_9, [1, 256, 64, 64], [1048576, 4096, 64, 1], 0);  zero__default_9 = None
        new_empty_strided_default_9 = torch.ops.aten.new_empty_strided.default(as_strided_default_28, [1, 256, 64, 64], [1048576, 4096, 64, 1])
        copy__default_28 = torch.ops.aten.copy_.default(new_empty_strided_default_9, as_strided_default_28);  new_empty_strided_default_9 = as_strided_default_28 = None
        as_strided_default_29 = torch.ops.aten.as_strided.default(copy__default_28, [1, 256, 64, 64], [1048576, 4096, 64, 1], 0)
        clone_default_9 = torch.ops.aten.clone.default(as_strided_default_29, memory_format = torch.contiguous_format)
        to_dtype_30 = torch.ops.aten.to.dtype(clone_default_9, torch.float32);  clone_default_9 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_9 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_9, to_dtype_30);  le_scalar_9 = new_zeros_default_9 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        copy__default_29 = torch.ops.aten.copy_.default(as_strided_default_29, to_dtype_32);  as_strided_default_29 = to_dtype_32 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(copy__default_28, view_default_10, None, None, None, getitem_16, getitem_17, True, 1e-05, [True, False, False]);  copy__default_28 = view_default_10 = getitem_16 = getitem_17 = None
        getitem_174 = native_batch_norm_backward_default_17[0]
        getitem_175 = native_batch_norm_backward_default_17[1]
        getitem_176 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        view_default_71 = torch.ops.aten.view.default(getitem_174, [1, 256, 64, 64]);  getitem_174 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(view_default_71, reflection_pad2d_default_3, primals_8, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_71 = reflection_pad2d_default_3 = primals_8 = None
        getitem_177 = convolution_backward_default_18[0]
        getitem_178 = convolution_backward_default_18[1]
        getitem_179 = convolution_backward_default_18[2];  convolution_backward_default_18 = None
        reflection_pad2d_backward_default_16 = torch.ops.aten.reflection_pad2d_backward.default(getitem_177, add_tensor, [1, 1, 1, 1]);  getitem_177 = add_tensor = None
        add_tensor_16 = torch.ops.aten.add.Tensor(add_tensor_15, reflection_pad2d_backward_default_16);  add_tensor_15 = reflection_pad2d_backward_default_16 = None
        view_default_72 = torch.ops.aten.view.default(add_tensor_16, [1, 256, 64, 64])
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(view_default_72, view_default_8, None, None, None, getitem_13, getitem_14, True, 1e-05, [True, False, False]);  view_default_72 = view_default_8 = getitem_13 = getitem_14 = None
        getitem_180 = native_batch_norm_backward_default_18[0]
        getitem_181 = native_batch_norm_backward_default_18[1]
        getitem_182 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        view_default_73 = torch.ops.aten.view.default(getitem_180, [1, 256, 64, 64]);  getitem_180 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(view_default_73, reflection_pad2d_default_2, primals_6, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_73 = reflection_pad2d_default_2 = primals_6 = None
        getitem_183 = convolution_backward_default_19[0]
        getitem_184 = convolution_backward_default_19[1]
        getitem_185 = convolution_backward_default_19[2];  convolution_backward_default_19 = None
        reflection_pad2d_backward_default_17 = torch.ops.aten.reflection_pad2d_backward.default(getitem_183, relu__default_3, [1, 1, 1, 1]);  getitem_183 = None
        squeeze_dim_10 = torch.ops.aten.squeeze.dim(reflection_pad2d_backward_default_17, 0);  reflection_pad2d_backward_default_17 = None
        new_empty_default_10 = torch.ops.aten.new_empty.default(squeeze_dim_10, [1048576])
        zero__default_10 = torch.ops.aten.zero_.default(new_empty_default_10);  new_empty_default_10 = None
        as_strided_default_30 = torch.ops.aten.as_strided.default(zero__default_10, [256, 64, 64], [4096, 64, 1], 0)
        copy__default_30 = torch.ops.aten.copy_.default(as_strided_default_30, squeeze_dim_10);  as_strided_default_30 = squeeze_dim_10 = None
        as_strided_default_31 = torch.ops.aten.as_strided.default(zero__default_10, [1, 256, 64, 64], [1048576, 4096, 64, 1], 0);  zero__default_10 = None
        new_empty_strided_default_10 = torch.ops.aten.new_empty_strided.default(as_strided_default_31, [1, 256, 64, 64], [1048576, 4096, 64, 1])
        copy__default_31 = torch.ops.aten.copy_.default(new_empty_strided_default_10, as_strided_default_31);  new_empty_strided_default_10 = as_strided_default_31 = None
        as_strided_default_32 = torch.ops.aten.as_strided.default(copy__default_31, [1, 256, 64, 64], [1048576, 4096, 64, 1], 0)
        clone_default_10 = torch.ops.aten.clone.default(as_strided_default_32, memory_format = torch.contiguous_format)
        to_dtype_33 = torch.ops.aten.to.dtype(clone_default_10, torch.float32);  clone_default_10 = None
        to_dtype_34 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        new_zeros_default_10 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_10, to_dtype_33);  le_scalar_10 = new_zeros_default_10 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        copy__default_32 = torch.ops.aten.copy_.default(as_strided_default_32, to_dtype_35);  as_strided_default_32 = to_dtype_35 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(copy__default_31, view_default_6, None, None, None, getitem_10, getitem_11, True, 1e-05, [True, False, False]);  copy__default_31 = view_default_6 = getitem_10 = getitem_11 = None
        getitem_186 = native_batch_norm_backward_default_19[0]
        getitem_187 = native_batch_norm_backward_default_19[1]
        getitem_188 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        view_default_74 = torch.ops.aten.view.default(getitem_186, [1, 256, 64, 64]);  getitem_186 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(view_default_74, reflection_pad2d_default_1, primals_4, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_74 = reflection_pad2d_default_1 = primals_4 = None
        getitem_189 = convolution_backward_default_20[0]
        getitem_190 = convolution_backward_default_20[1]
        getitem_191 = convolution_backward_default_20[2];  convolution_backward_default_20 = None
        reflection_pad2d_backward_default_18 = torch.ops.aten.reflection_pad2d_backward.default(getitem_189, relu__default_2, [1, 1, 1, 1]);  getitem_189 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(add_tensor_16, reflection_pad2d_backward_default_18);  add_tensor_16 = reflection_pad2d_backward_default_18 = None
        squeeze_dim_11 = torch.ops.aten.squeeze.dim(add_tensor_17, 0);  add_tensor_17 = None
        new_empty_default_11 = torch.ops.aten.new_empty.default(squeeze_dim_11, [1048576])
        zero__default_11 = torch.ops.aten.zero_.default(new_empty_default_11);  new_empty_default_11 = None
        as_strided_default_33 = torch.ops.aten.as_strided.default(zero__default_11, [256, 64, 64], [4096, 64, 1], 0)
        copy__default_33 = torch.ops.aten.copy_.default(as_strided_default_33, squeeze_dim_11);  as_strided_default_33 = squeeze_dim_11 = None
        as_strided_default_34 = torch.ops.aten.as_strided.default(zero__default_11, [1, 256, 64, 64], [1048576, 4096, 64, 1], 0);  zero__default_11 = None
        new_empty_strided_default_11 = torch.ops.aten.new_empty_strided.default(as_strided_default_34, [1, 256, 64, 64], [1048576, 4096, 64, 1])
        copy__default_34 = torch.ops.aten.copy_.default(new_empty_strided_default_11, as_strided_default_34);  new_empty_strided_default_11 = as_strided_default_34 = None
        as_strided_default_35 = torch.ops.aten.as_strided.default(copy__default_34, [1, 256, 64, 64], [1048576, 4096, 64, 1], 0)
        clone_default_11 = torch.ops.aten.clone.default(as_strided_default_35, memory_format = torch.contiguous_format)
        to_dtype_36 = torch.ops.aten.to.dtype(clone_default_11, torch.float32);  clone_default_11 = None
        to_dtype_37 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        new_zeros_default_11 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_11, to_dtype_36);  le_scalar_11 = new_zeros_default_11 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        copy__default_35 = torch.ops.aten.copy_.default(as_strided_default_35, to_dtype_38);  as_strided_default_35 = to_dtype_38 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(copy__default_34, view_default_4, None, None, None, getitem_7, getitem_8, True, 1e-05, [True, False, False]);  copy__default_34 = view_default_4 = getitem_7 = getitem_8 = None
        getitem_192 = native_batch_norm_backward_default_20[0]
        getitem_193 = native_batch_norm_backward_default_20[1]
        getitem_194 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        view_default_75 = torch.ops.aten.view.default(getitem_192, [1, 256, 64, 64]);  getitem_192 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(view_default_75, relu__default_1, primals_48, [256], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_75 = primals_48 = None
        getitem_195 = convolution_backward_default_21[0]
        getitem_196 = convolution_backward_default_21[1]
        getitem_197 = convolution_backward_default_21[2];  convolution_backward_default_21 = None
        squeeze_dim_12 = torch.ops.aten.squeeze.dim(getitem_195, 0);  getitem_195 = None
        new_empty_default_12 = torch.ops.aten.new_empty.default(squeeze_dim_12, [2097152])
        zero__default_12 = torch.ops.aten.zero_.default(new_empty_default_12);  new_empty_default_12 = None
        as_strided_default_36 = torch.ops.aten.as_strided.default(zero__default_12, [128, 128, 128], [16384, 128, 1], 0)
        copy__default_36 = torch.ops.aten.copy_.default(as_strided_default_36, squeeze_dim_12);  as_strided_default_36 = squeeze_dim_12 = None
        as_strided_default_37 = torch.ops.aten.as_strided.default(zero__default_12, [1, 128, 128, 128], [2097152, 16384, 128, 1], 0);  zero__default_12 = None
        new_empty_strided_default_12 = torch.ops.aten.new_empty_strided.default(as_strided_default_37, [1, 128, 128, 128], [2097152, 16384, 128, 1])
        copy__default_37 = torch.ops.aten.copy_.default(new_empty_strided_default_12, as_strided_default_37);  new_empty_strided_default_12 = as_strided_default_37 = None
        as_strided_default_38 = torch.ops.aten.as_strided.default(copy__default_37, [1, 128, 128, 128], [2097152, 16384, 128, 1], 0)
        clone_default_12 = torch.ops.aten.clone.default(as_strided_default_38, memory_format = torch.contiguous_format)
        to_dtype_39 = torch.ops.aten.to.dtype(clone_default_12, torch.float32);  clone_default_12 = None
        to_dtype_40 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        new_zeros_default_12 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_12, to_dtype_39);  le_scalar_12 = new_zeros_default_12 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        copy__default_38 = torch.ops.aten.copy_.default(as_strided_default_38, to_dtype_41);  as_strided_default_38 = to_dtype_41 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(copy__default_37, view_default_2, None, None, None, getitem_4, getitem_5, True, 1e-05, [True, False, False]);  copy__default_37 = view_default_2 = getitem_4 = getitem_5 = None
        getitem_198 = native_batch_norm_backward_default_21[0]
        getitem_199 = native_batch_norm_backward_default_21[1]
        getitem_200 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        view_default_76 = torch.ops.aten.view.default(getitem_198, [1, 128, 128, 128]);  getitem_198 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(view_default_76, relu__default, primals_46, [128], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_76 = primals_46 = None
        getitem_201 = convolution_backward_default_22[0]
        getitem_202 = convolution_backward_default_22[1]
        getitem_203 = convolution_backward_default_22[2];  convolution_backward_default_22 = None
        squeeze_dim_13 = torch.ops.aten.squeeze.dim(getitem_201, 0);  getitem_201 = None
        new_empty_default_13 = torch.ops.aten.new_empty.default(squeeze_dim_13, [4194304])
        zero__default_13 = torch.ops.aten.zero_.default(new_empty_default_13);  new_empty_default_13 = None
        as_strided_default_39 = torch.ops.aten.as_strided.default(zero__default_13, [64, 256, 256], [65536, 256, 1], 0)
        copy__default_39 = torch.ops.aten.copy_.default(as_strided_default_39, squeeze_dim_13);  as_strided_default_39 = squeeze_dim_13 = None
        as_strided_default_40 = torch.ops.aten.as_strided.default(zero__default_13, [1, 64, 256, 256], [4194304, 65536, 256, 1], 0);  zero__default_13 = None
        new_empty_strided_default_13 = torch.ops.aten.new_empty_strided.default(as_strided_default_40, [1, 64, 256, 256], [4194304, 65536, 256, 1])
        copy__default_40 = torch.ops.aten.copy_.default(new_empty_strided_default_13, as_strided_default_40);  new_empty_strided_default_13 = as_strided_default_40 = None
        as_strided_default_41 = torch.ops.aten.as_strided.default(copy__default_40, [1, 64, 256, 256], [4194304, 65536, 256, 1], 0)
        clone_default_13 = torch.ops.aten.clone.default(as_strided_default_41, memory_format = torch.contiguous_format)
        to_dtype_42 = torch.ops.aten.to.dtype(clone_default_13, torch.float32);  clone_default_13 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_13 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_13, to_dtype_42);  le_scalar_13 = new_zeros_default_13 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        copy__default_41 = torch.ops.aten.copy_.default(as_strided_default_41, to_dtype_44);  as_strided_default_41 = to_dtype_44 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(copy__default_40, view_default, None, None, None, getitem_1, getitem_2, True, 1e-05, [True, False, False]);  copy__default_40 = view_default = getitem_1 = getitem_2 = None
        getitem_204 = native_batch_norm_backward_default_22[0]
        getitem_205 = native_batch_norm_backward_default_22[1]
        getitem_206 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        view_default_77 = torch.ops.aten.view.default(getitem_204, [1, 64, 256, 256]);  getitem_204 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(view_default_77, reflection_pad2d_default, primals_2, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [False, True, True]);  view_default_77 = reflection_pad2d_default = primals_2 = None
        getitem_207 = convolution_backward_default_23[0]
        getitem_208 = convolution_backward_default_23[1]
        getitem_209 = convolution_backward_default_23[2];  convolution_backward_default_23 = None
        return [tanh_default, getitem_209, getitem_208, getitem_191, getitem_190, getitem_185, getitem_184, getitem_179, getitem_178, getitem_173, getitem_172, getitem_167, getitem_166, getitem_161, getitem_160, getitem_155, getitem_154, getitem_149, getitem_148, getitem_143, getitem_142, getitem_137, getitem_136, getitem_131, getitem_130, getitem_125, getitem_124, getitem_119, getitem_118, getitem_113, getitem_112, getitem_107, getitem_106, getitem_101, getitem_100, getitem_95, getitem_94, getitem_89, getitem_88, getitem_83, getitem_82, getitem_77, getitem_76, getitem_71, getitem_70, getitem_203, getitem_202, getitem_197, getitem_196, None]
        
