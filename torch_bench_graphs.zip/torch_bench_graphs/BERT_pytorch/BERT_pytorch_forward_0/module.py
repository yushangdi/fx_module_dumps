
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/BERT_pytorch/BERT_pytorch_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197):
        gt_scalar = torch.ops.aten.gt.Scalar(primals_196, 0)
        unsqueeze_default = torch.ops.aten.unsqueeze.default(gt_scalar, 1);  gt_scalar = None
        repeat_default = torch.ops.aten.repeat.default(unsqueeze_default, [1, 128, 1]);  unsqueeze_default = None
        unsqueeze_default_1 = torch.ops.aten.unsqueeze.default(repeat_default, 1);  repeat_default = None
        embedding_default = torch.ops.aten.embedding.default(primals_3, primals_196, 0);  primals_3 = None
        slice_tensor = torch.ops.aten.slice.Tensor(primals_1, 0, 0, 9223372036854775807);  primals_1 = None
        slice_tensor_1 = torch.ops.aten.slice.Tensor(slice_tensor, 1, 0, 128);  slice_tensor = None
        add_tensor = torch.ops.aten.add.Tensor(embedding_default, slice_tensor_1);  embedding_default = slice_tensor_1 = None
        embedding_default_1 = torch.ops.aten.embedding.default(primals_2, primals_197, 0);  primals_2 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(add_tensor, embedding_default_1);  add_tensor = embedding_default_1 = None
        mean_dim = torch.ops.aten.mean.dim(add_tensor_1, [-1], True)
        std_correction = torch.ops.aten.std.correction(add_tensor_1, [-1], correction = 1, keepdim = True)
        sub_tensor = torch.ops.aten.sub.Tensor(add_tensor_1, mean_dim);  mean_dim = None
        mul_tensor = torch.ops.aten.mul.Tensor(primals_8, sub_tensor)
        add_tensor_2 = torch.ops.aten.add.Tensor(std_correction, 1e-06)
        div_tensor = torch.ops.aten.div.Tensor(mul_tensor, add_tensor_2)
        add_tensor_3 = torch.ops.aten.add.Tensor(div_tensor, primals_9);  div_tensor = primals_9 = None
        view_default = torch.ops.aten.view.default(add_tensor_3, [2048, 768])
        t_default = torch.ops.aten.t.default(primals_11);  primals_11 = None
        addmm_default = torch.ops.aten.addmm.default(primals_10, view_default, t_default);  primals_10 = None
        view_default_1 = torch.ops.aten.view.default(addmm_default, [16, 128, 768]);  addmm_default = None
        view_default_2 = torch.ops.aten.view.default(view_default_1, [16, -1, 12, 64]);  view_default_1 = None
        transpose_int = torch.ops.aten.transpose.int(view_default_2, 1, 2);  view_default_2 = None
        view_default_3 = torch.ops.aten.view.default(add_tensor_3, [2048, 768])
        t_default_1 = torch.ops.aten.t.default(primals_13);  primals_13 = None
        addmm_default_1 = torch.ops.aten.addmm.default(primals_12, view_default_3, t_default_1);  primals_12 = None
        view_default_4 = torch.ops.aten.view.default(addmm_default_1, [16, 128, 768]);  addmm_default_1 = None
        view_default_5 = torch.ops.aten.view.default(view_default_4, [16, -1, 12, 64]);  view_default_4 = None
        transpose_int_1 = torch.ops.aten.transpose.int(view_default_5, 1, 2);  view_default_5 = None
        view_default_6 = torch.ops.aten.view.default(add_tensor_3, [2048, 768]);  add_tensor_3 = None
        t_default_2 = torch.ops.aten.t.default(primals_15);  primals_15 = None
        addmm_default_2 = torch.ops.aten.addmm.default(primals_14, view_default_6, t_default_2);  primals_14 = None
        view_default_7 = torch.ops.aten.view.default(addmm_default_2, [16, 128, 768]);  addmm_default_2 = None
        view_default_8 = torch.ops.aten.view.default(view_default_7, [16, -1, 12, 64]);  view_default_7 = None
        transpose_int_2 = torch.ops.aten.transpose.int(view_default_8, 1, 2);  view_default_8 = None
        transpose_int_3 = torch.ops.aten.transpose.int(transpose_int_1, -2, -1);  transpose_int_1 = None
        expand_default = torch.ops.aten.expand.default(transpose_int, [16, 12, 128, 64]);  transpose_int = None
        clone_default = torch.ops.aten.clone.default(expand_default, memory_format = torch.contiguous_format);  expand_default = None
        _unsafe_view_default = torch.ops.aten._unsafe_view.default(clone_default, [192, 128, 64]);  clone_default = None
        expand_default_1 = torch.ops.aten.expand.default(transpose_int_3, [16, 12, 64, 128]);  transpose_int_3 = None
        clone_default_1 = torch.ops.aten.clone.default(expand_default_1, memory_format = torch.contiguous_format);  expand_default_1 = None
        _unsafe_view_default_1 = torch.ops.aten._unsafe_view.default(clone_default_1, [192, 64, 128]);  clone_default_1 = None
        bmm_default = torch.ops.aten.bmm.default(_unsafe_view_default, _unsafe_view_default_1)
        _unsafe_view_default_2 = torch.ops.aten._unsafe_view.default(bmm_default, [16, 12, 128, 128]);  bmm_default = None
        div_tensor_1 = torch.ops.aten.div.Tensor(_unsafe_view_default_2, 8.0);  _unsafe_view_default_2 = None
        eq_scalar = torch.ops.aten.eq.Scalar(unsqueeze_default_1, 0)
        where_scalar_self = torch.ops.aten.where.ScalarSelf(eq_scalar, -1000000000.0, div_tensor_1);  div_tensor_1 = None
        _softmax_default = torch.ops.aten._softmax.default(where_scalar_self, -1, False);  where_scalar_self = None
        expand_default_2 = torch.ops.aten.expand.default(_softmax_default, [16, 12, 128, 128])
        view_default_9 = torch.ops.aten.view.default(expand_default_2, [192, 128, 128]);  expand_default_2 = None
        expand_default_3 = torch.ops.aten.expand.default(transpose_int_2, [16, 12, 128, 64]);  transpose_int_2 = None
        clone_default_2 = torch.ops.aten.clone.default(expand_default_3, memory_format = torch.contiguous_format);  expand_default_3 = None
        _unsafe_view_default_3 = torch.ops.aten._unsafe_view.default(clone_default_2, [192, 128, 64]);  clone_default_2 = None
        bmm_default_1 = torch.ops.aten.bmm.default(view_default_9, _unsafe_view_default_3)
        _unsafe_view_default_4 = torch.ops.aten._unsafe_view.default(bmm_default_1, [16, 12, 128, 64]);  bmm_default_1 = None
        transpose_int_4 = torch.ops.aten.transpose.int(_unsafe_view_default_4, 1, 2);  _unsafe_view_default_4 = None
        clone_default_3 = torch.ops.aten.clone.default(transpose_int_4, memory_format = torch.contiguous_format);  transpose_int_4 = None
        view_default_10 = torch.ops.aten.view.default(clone_default_3, [16, -1, 768]);  clone_default_3 = None
        view_default_11 = torch.ops.aten.view.default(view_default_10, [2048, 768]);  view_default_10 = None
        t_default_3 = torch.ops.aten.t.default(primals_17);  primals_17 = None
        addmm_default_3 = torch.ops.aten.addmm.default(primals_16, view_default_11, t_default_3);  primals_16 = None
        view_default_12 = torch.ops.aten.view.default(addmm_default_3, [16, 128, 768]);  addmm_default_3 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(add_tensor_1, view_default_12);  view_default_12 = None
        mean_dim_1 = torch.ops.aten.mean.dim(add_tensor_4, [-1], True)
        std_correction_1 = torch.ops.aten.std.correction(add_tensor_4, [-1], correction = 1, keepdim = True)
        sub_tensor_1 = torch.ops.aten.sub.Tensor(add_tensor_4, mean_dim_1);  mean_dim_1 = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(primals_18, sub_tensor_1)
        add_tensor_5 = torch.ops.aten.add.Tensor(std_correction_1, 1e-06)
        div_tensor_2 = torch.ops.aten.div.Tensor(mul_tensor_1, add_tensor_5)
        add_tensor_6 = torch.ops.aten.add.Tensor(div_tensor_2, primals_19);  div_tensor_2 = primals_19 = None
        view_default_13 = torch.ops.aten.view.default(add_tensor_6, [2048, 768]);  add_tensor_6 = None
        t_default_4 = torch.ops.aten.t.default(primals_5);  primals_5 = None
        addmm_default_4 = torch.ops.aten.addmm.default(primals_4, view_default_13, t_default_4);  primals_4 = None
        view_default_14 = torch.ops.aten.view.default(addmm_default_4, [16, 128, 3072]);  addmm_default_4 = None
        gelu_default = torch.ops.aten.gelu.default(view_default_14)
        view_default_15 = torch.ops.aten.view.default(gelu_default, [2048, 3072]);  gelu_default = None
        t_default_5 = torch.ops.aten.t.default(primals_7);  primals_7 = None
        addmm_default_5 = torch.ops.aten.addmm.default(primals_6, view_default_15, t_default_5);  primals_6 = None
        view_default_16 = torch.ops.aten.view.default(addmm_default_5, [16, 128, 768]);  addmm_default_5 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(add_tensor_4, view_default_16);  view_default_16 = None
        mean_dim_2 = torch.ops.aten.mean.dim(add_tensor_7, [-1], True)
        std_correction_2 = torch.ops.aten.std.correction(add_tensor_7, [-1], correction = 1, keepdim = True)
        sub_tensor_2 = torch.ops.aten.sub.Tensor(add_tensor_7, mean_dim_2);  mean_dim_2 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(primals_56, sub_tensor_2)
        add_tensor_8 = torch.ops.aten.add.Tensor(std_correction_2, 1e-06)
        div_tensor_3 = torch.ops.aten.div.Tensor(mul_tensor_2, add_tensor_8)
        add_tensor_9 = torch.ops.aten.add.Tensor(div_tensor_3, primals_57);  div_tensor_3 = primals_57 = None
        view_default_17 = torch.ops.aten.view.default(add_tensor_9, [2048, 768])
        t_default_6 = torch.ops.aten.t.default(primals_59);  primals_59 = None
        addmm_default_6 = torch.ops.aten.addmm.default(primals_58, view_default_17, t_default_6);  primals_58 = None
        view_default_18 = torch.ops.aten.view.default(addmm_default_6, [16, 128, 768]);  addmm_default_6 = None
        view_default_19 = torch.ops.aten.view.default(view_default_18, [16, -1, 12, 64]);  view_default_18 = None
        transpose_int_5 = torch.ops.aten.transpose.int(view_default_19, 1, 2);  view_default_19 = None
        view_default_20 = torch.ops.aten.view.default(add_tensor_9, [2048, 768])
        t_default_7 = torch.ops.aten.t.default(primals_61);  primals_61 = None
        addmm_default_7 = torch.ops.aten.addmm.default(primals_60, view_default_20, t_default_7);  primals_60 = None
        view_default_21 = torch.ops.aten.view.default(addmm_default_7, [16, 128, 768]);  addmm_default_7 = None
        view_default_22 = torch.ops.aten.view.default(view_default_21, [16, -1, 12, 64]);  view_default_21 = None
        transpose_int_6 = torch.ops.aten.transpose.int(view_default_22, 1, 2);  view_default_22 = None
        view_default_23 = torch.ops.aten.view.default(add_tensor_9, [2048, 768]);  add_tensor_9 = None
        t_default_8 = torch.ops.aten.t.default(primals_63);  primals_63 = None
        addmm_default_8 = torch.ops.aten.addmm.default(primals_62, view_default_23, t_default_8);  primals_62 = None
        view_default_24 = torch.ops.aten.view.default(addmm_default_8, [16, 128, 768]);  addmm_default_8 = None
        view_default_25 = torch.ops.aten.view.default(view_default_24, [16, -1, 12, 64]);  view_default_24 = None
        transpose_int_7 = torch.ops.aten.transpose.int(view_default_25, 1, 2);  view_default_25 = None
        transpose_int_8 = torch.ops.aten.transpose.int(transpose_int_6, -2, -1);  transpose_int_6 = None
        expand_default_4 = torch.ops.aten.expand.default(transpose_int_5, [16, 12, 128, 64]);  transpose_int_5 = None
        clone_default_4 = torch.ops.aten.clone.default(expand_default_4, memory_format = torch.contiguous_format);  expand_default_4 = None
        _unsafe_view_default_5 = torch.ops.aten._unsafe_view.default(clone_default_4, [192, 128, 64]);  clone_default_4 = None
        expand_default_5 = torch.ops.aten.expand.default(transpose_int_8, [16, 12, 64, 128]);  transpose_int_8 = None
        clone_default_5 = torch.ops.aten.clone.default(expand_default_5, memory_format = torch.contiguous_format);  expand_default_5 = None
        _unsafe_view_default_6 = torch.ops.aten._unsafe_view.default(clone_default_5, [192, 64, 128]);  clone_default_5 = None
        bmm_default_2 = torch.ops.aten.bmm.default(_unsafe_view_default_5, _unsafe_view_default_6)
        _unsafe_view_default_7 = torch.ops.aten._unsafe_view.default(bmm_default_2, [16, 12, 128, 128]);  bmm_default_2 = None
        div_tensor_4 = torch.ops.aten.div.Tensor(_unsafe_view_default_7, 8.0);  _unsafe_view_default_7 = None
        eq_scalar_1 = torch.ops.aten.eq.Scalar(unsqueeze_default_1, 0)
        where_scalar_self_1 = torch.ops.aten.where.ScalarSelf(eq_scalar_1, -1000000000.0, div_tensor_4);  div_tensor_4 = None
        _softmax_default_1 = torch.ops.aten._softmax.default(where_scalar_self_1, -1, False);  where_scalar_self_1 = None
        expand_default_6 = torch.ops.aten.expand.default(_softmax_default_1, [16, 12, 128, 128])
        view_default_26 = torch.ops.aten.view.default(expand_default_6, [192, 128, 128]);  expand_default_6 = None
        expand_default_7 = torch.ops.aten.expand.default(transpose_int_7, [16, 12, 128, 64]);  transpose_int_7 = None
        clone_default_6 = torch.ops.aten.clone.default(expand_default_7, memory_format = torch.contiguous_format);  expand_default_7 = None
        _unsafe_view_default_8 = torch.ops.aten._unsafe_view.default(clone_default_6, [192, 128, 64]);  clone_default_6 = None
        bmm_default_3 = torch.ops.aten.bmm.default(view_default_26, _unsafe_view_default_8)
        _unsafe_view_default_9 = torch.ops.aten._unsafe_view.default(bmm_default_3, [16, 12, 128, 64]);  bmm_default_3 = None
        transpose_int_9 = torch.ops.aten.transpose.int(_unsafe_view_default_9, 1, 2);  _unsafe_view_default_9 = None
        clone_default_7 = torch.ops.aten.clone.default(transpose_int_9, memory_format = torch.contiguous_format);  transpose_int_9 = None
        view_default_27 = torch.ops.aten.view.default(clone_default_7, [16, -1, 768]);  clone_default_7 = None
        view_default_28 = torch.ops.aten.view.default(view_default_27, [2048, 768]);  view_default_27 = None
        t_default_9 = torch.ops.aten.t.default(primals_65);  primals_65 = None
        addmm_default_9 = torch.ops.aten.addmm.default(primals_64, view_default_28, t_default_9);  primals_64 = None
        view_default_29 = torch.ops.aten.view.default(addmm_default_9, [16, 128, 768]);  addmm_default_9 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(add_tensor_7, view_default_29);  view_default_29 = None
        mean_dim_3 = torch.ops.aten.mean.dim(add_tensor_10, [-1], True)
        std_correction_3 = torch.ops.aten.std.correction(add_tensor_10, [-1], correction = 1, keepdim = True)
        sub_tensor_3 = torch.ops.aten.sub.Tensor(add_tensor_10, mean_dim_3);  mean_dim_3 = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(primals_66, sub_tensor_3)
        add_tensor_11 = torch.ops.aten.add.Tensor(std_correction_3, 1e-06)
        div_tensor_5 = torch.ops.aten.div.Tensor(mul_tensor_3, add_tensor_11)
        add_tensor_12 = torch.ops.aten.add.Tensor(div_tensor_5, primals_67);  div_tensor_5 = primals_67 = None
        view_default_30 = torch.ops.aten.view.default(add_tensor_12, [2048, 768]);  add_tensor_12 = None
        t_default_10 = torch.ops.aten.t.default(primals_53);  primals_53 = None
        addmm_default_10 = torch.ops.aten.addmm.default(primals_52, view_default_30, t_default_10);  primals_52 = None
        view_default_31 = torch.ops.aten.view.default(addmm_default_10, [16, 128, 3072]);  addmm_default_10 = None
        gelu_default_1 = torch.ops.aten.gelu.default(view_default_31)
        view_default_32 = torch.ops.aten.view.default(gelu_default_1, [2048, 3072]);  gelu_default_1 = None
        t_default_11 = torch.ops.aten.t.default(primals_55);  primals_55 = None
        addmm_default_11 = torch.ops.aten.addmm.default(primals_54, view_default_32, t_default_11);  primals_54 = None
        view_default_33 = torch.ops.aten.view.default(addmm_default_11, [16, 128, 768]);  addmm_default_11 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(add_tensor_10, view_default_33);  view_default_33 = None
        mean_dim_4 = torch.ops.aten.mean.dim(add_tensor_13, [-1], True)
        std_correction_4 = torch.ops.aten.std.correction(add_tensor_13, [-1], correction = 1, keepdim = True)
        sub_tensor_4 = torch.ops.aten.sub.Tensor(add_tensor_13, mean_dim_4);  mean_dim_4 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(primals_72, sub_tensor_4)
        add_tensor_14 = torch.ops.aten.add.Tensor(std_correction_4, 1e-06)
        div_tensor_6 = torch.ops.aten.div.Tensor(mul_tensor_4, add_tensor_14)
        add_tensor_15 = torch.ops.aten.add.Tensor(div_tensor_6, primals_73);  div_tensor_6 = primals_73 = None
        view_default_34 = torch.ops.aten.view.default(add_tensor_15, [2048, 768])
        t_default_12 = torch.ops.aten.t.default(primals_75);  primals_75 = None
        addmm_default_12 = torch.ops.aten.addmm.default(primals_74, view_default_34, t_default_12);  primals_74 = None
        view_default_35 = torch.ops.aten.view.default(addmm_default_12, [16, 128, 768]);  addmm_default_12 = None
        view_default_36 = torch.ops.aten.view.default(view_default_35, [16, -1, 12, 64]);  view_default_35 = None
        transpose_int_10 = torch.ops.aten.transpose.int(view_default_36, 1, 2);  view_default_36 = None
        view_default_37 = torch.ops.aten.view.default(add_tensor_15, [2048, 768])
        t_default_13 = torch.ops.aten.t.default(primals_77);  primals_77 = None
        addmm_default_13 = torch.ops.aten.addmm.default(primals_76, view_default_37, t_default_13);  primals_76 = None
        view_default_38 = torch.ops.aten.view.default(addmm_default_13, [16, 128, 768]);  addmm_default_13 = None
        view_default_39 = torch.ops.aten.view.default(view_default_38, [16, -1, 12, 64]);  view_default_38 = None
        transpose_int_11 = torch.ops.aten.transpose.int(view_default_39, 1, 2);  view_default_39 = None
        view_default_40 = torch.ops.aten.view.default(add_tensor_15, [2048, 768]);  add_tensor_15 = None
        t_default_14 = torch.ops.aten.t.default(primals_79);  primals_79 = None
        addmm_default_14 = torch.ops.aten.addmm.default(primals_78, view_default_40, t_default_14);  primals_78 = None
        view_default_41 = torch.ops.aten.view.default(addmm_default_14, [16, 128, 768]);  addmm_default_14 = None
        view_default_42 = torch.ops.aten.view.default(view_default_41, [16, -1, 12, 64]);  view_default_41 = None
        transpose_int_12 = torch.ops.aten.transpose.int(view_default_42, 1, 2);  view_default_42 = None
        transpose_int_13 = torch.ops.aten.transpose.int(transpose_int_11, -2, -1);  transpose_int_11 = None
        expand_default_8 = torch.ops.aten.expand.default(transpose_int_10, [16, 12, 128, 64]);  transpose_int_10 = None
        clone_default_8 = torch.ops.aten.clone.default(expand_default_8, memory_format = torch.contiguous_format);  expand_default_8 = None
        _unsafe_view_default_10 = torch.ops.aten._unsafe_view.default(clone_default_8, [192, 128, 64]);  clone_default_8 = None
        expand_default_9 = torch.ops.aten.expand.default(transpose_int_13, [16, 12, 64, 128]);  transpose_int_13 = None
        clone_default_9 = torch.ops.aten.clone.default(expand_default_9, memory_format = torch.contiguous_format);  expand_default_9 = None
        _unsafe_view_default_11 = torch.ops.aten._unsafe_view.default(clone_default_9, [192, 64, 128]);  clone_default_9 = None
        bmm_default_4 = torch.ops.aten.bmm.default(_unsafe_view_default_10, _unsafe_view_default_11)
        _unsafe_view_default_12 = torch.ops.aten._unsafe_view.default(bmm_default_4, [16, 12, 128, 128]);  bmm_default_4 = None
        div_tensor_7 = torch.ops.aten.div.Tensor(_unsafe_view_default_12, 8.0);  _unsafe_view_default_12 = None
        eq_scalar_2 = torch.ops.aten.eq.Scalar(unsqueeze_default_1, 0)
        where_scalar_self_2 = torch.ops.aten.where.ScalarSelf(eq_scalar_2, -1000000000.0, div_tensor_7);  div_tensor_7 = None
        _softmax_default_2 = torch.ops.aten._softmax.default(where_scalar_self_2, -1, False);  where_scalar_self_2 = None
        expand_default_10 = torch.ops.aten.expand.default(_softmax_default_2, [16, 12, 128, 128])
        view_default_43 = torch.ops.aten.view.default(expand_default_10, [192, 128, 128]);  expand_default_10 = None
        expand_default_11 = torch.ops.aten.expand.default(transpose_int_12, [16, 12, 128, 64]);  transpose_int_12 = None
        clone_default_10 = torch.ops.aten.clone.default(expand_default_11, memory_format = torch.contiguous_format);  expand_default_11 = None
        _unsafe_view_default_13 = torch.ops.aten._unsafe_view.default(clone_default_10, [192, 128, 64]);  clone_default_10 = None
        bmm_default_5 = torch.ops.aten.bmm.default(view_default_43, _unsafe_view_default_13)
        _unsafe_view_default_14 = torch.ops.aten._unsafe_view.default(bmm_default_5, [16, 12, 128, 64]);  bmm_default_5 = None
        transpose_int_14 = torch.ops.aten.transpose.int(_unsafe_view_default_14, 1, 2);  _unsafe_view_default_14 = None
        clone_default_11 = torch.ops.aten.clone.default(transpose_int_14, memory_format = torch.contiguous_format);  transpose_int_14 = None
        view_default_44 = torch.ops.aten.view.default(clone_default_11, [16, -1, 768]);  clone_default_11 = None
        view_default_45 = torch.ops.aten.view.default(view_default_44, [2048, 768]);  view_default_44 = None
        t_default_15 = torch.ops.aten.t.default(primals_81);  primals_81 = None
        addmm_default_15 = torch.ops.aten.addmm.default(primals_80, view_default_45, t_default_15);  primals_80 = None
        view_default_46 = torch.ops.aten.view.default(addmm_default_15, [16, 128, 768]);  addmm_default_15 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(add_tensor_13, view_default_46);  view_default_46 = None
        mean_dim_5 = torch.ops.aten.mean.dim(add_tensor_16, [-1], True)
        std_correction_5 = torch.ops.aten.std.correction(add_tensor_16, [-1], correction = 1, keepdim = True)
        sub_tensor_5 = torch.ops.aten.sub.Tensor(add_tensor_16, mean_dim_5);  mean_dim_5 = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(primals_82, sub_tensor_5)
        add_tensor_17 = torch.ops.aten.add.Tensor(std_correction_5, 1e-06)
        div_tensor_8 = torch.ops.aten.div.Tensor(mul_tensor_5, add_tensor_17)
        add_tensor_18 = torch.ops.aten.add.Tensor(div_tensor_8, primals_83);  div_tensor_8 = primals_83 = None
        view_default_47 = torch.ops.aten.view.default(add_tensor_18, [2048, 768]);  add_tensor_18 = None
        t_default_16 = torch.ops.aten.t.default(primals_69);  primals_69 = None
        addmm_default_16 = torch.ops.aten.addmm.default(primals_68, view_default_47, t_default_16);  primals_68 = None
        view_default_48 = torch.ops.aten.view.default(addmm_default_16, [16, 128, 3072]);  addmm_default_16 = None
        gelu_default_2 = torch.ops.aten.gelu.default(view_default_48)
        view_default_49 = torch.ops.aten.view.default(gelu_default_2, [2048, 3072]);  gelu_default_2 = None
        t_default_17 = torch.ops.aten.t.default(primals_71);  primals_71 = None
        addmm_default_17 = torch.ops.aten.addmm.default(primals_70, view_default_49, t_default_17);  primals_70 = None
        view_default_50 = torch.ops.aten.view.default(addmm_default_17, [16, 128, 768]);  addmm_default_17 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(add_tensor_16, view_default_50);  view_default_50 = None
        mean_dim_6 = torch.ops.aten.mean.dim(add_tensor_19, [-1], True)
        std_correction_6 = torch.ops.aten.std.correction(add_tensor_19, [-1], correction = 1, keepdim = True)
        sub_tensor_6 = torch.ops.aten.sub.Tensor(add_tensor_19, mean_dim_6);  mean_dim_6 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(primals_88, sub_tensor_6)
        add_tensor_20 = torch.ops.aten.add.Tensor(std_correction_6, 1e-06)
        div_tensor_9 = torch.ops.aten.div.Tensor(mul_tensor_6, add_tensor_20)
        add_tensor_21 = torch.ops.aten.add.Tensor(div_tensor_9, primals_89);  div_tensor_9 = primals_89 = None
        view_default_51 = torch.ops.aten.view.default(add_tensor_21, [2048, 768])
        t_default_18 = torch.ops.aten.t.default(primals_91);  primals_91 = None
        addmm_default_18 = torch.ops.aten.addmm.default(primals_90, view_default_51, t_default_18);  primals_90 = None
        view_default_52 = torch.ops.aten.view.default(addmm_default_18, [16, 128, 768]);  addmm_default_18 = None
        view_default_53 = torch.ops.aten.view.default(view_default_52, [16, -1, 12, 64]);  view_default_52 = None
        transpose_int_15 = torch.ops.aten.transpose.int(view_default_53, 1, 2);  view_default_53 = None
        view_default_54 = torch.ops.aten.view.default(add_tensor_21, [2048, 768])
        t_default_19 = torch.ops.aten.t.default(primals_93);  primals_93 = None
        addmm_default_19 = torch.ops.aten.addmm.default(primals_92, view_default_54, t_default_19);  primals_92 = None
        view_default_55 = torch.ops.aten.view.default(addmm_default_19, [16, 128, 768]);  addmm_default_19 = None
        view_default_56 = torch.ops.aten.view.default(view_default_55, [16, -1, 12, 64]);  view_default_55 = None
        transpose_int_16 = torch.ops.aten.transpose.int(view_default_56, 1, 2);  view_default_56 = None
        view_default_57 = torch.ops.aten.view.default(add_tensor_21, [2048, 768]);  add_tensor_21 = None
        t_default_20 = torch.ops.aten.t.default(primals_95);  primals_95 = None
        addmm_default_20 = torch.ops.aten.addmm.default(primals_94, view_default_57, t_default_20);  primals_94 = None
        view_default_58 = torch.ops.aten.view.default(addmm_default_20, [16, 128, 768]);  addmm_default_20 = None
        view_default_59 = torch.ops.aten.view.default(view_default_58, [16, -1, 12, 64]);  view_default_58 = None
        transpose_int_17 = torch.ops.aten.transpose.int(view_default_59, 1, 2);  view_default_59 = None
        transpose_int_18 = torch.ops.aten.transpose.int(transpose_int_16, -2, -1);  transpose_int_16 = None
        expand_default_12 = torch.ops.aten.expand.default(transpose_int_15, [16, 12, 128, 64]);  transpose_int_15 = None
        clone_default_12 = torch.ops.aten.clone.default(expand_default_12, memory_format = torch.contiguous_format);  expand_default_12 = None
        _unsafe_view_default_15 = torch.ops.aten._unsafe_view.default(clone_default_12, [192, 128, 64]);  clone_default_12 = None
        expand_default_13 = torch.ops.aten.expand.default(transpose_int_18, [16, 12, 64, 128]);  transpose_int_18 = None
        clone_default_13 = torch.ops.aten.clone.default(expand_default_13, memory_format = torch.contiguous_format);  expand_default_13 = None
        _unsafe_view_default_16 = torch.ops.aten._unsafe_view.default(clone_default_13, [192, 64, 128]);  clone_default_13 = None
        bmm_default_6 = torch.ops.aten.bmm.default(_unsafe_view_default_15, _unsafe_view_default_16)
        _unsafe_view_default_17 = torch.ops.aten._unsafe_view.default(bmm_default_6, [16, 12, 128, 128]);  bmm_default_6 = None
        div_tensor_10 = torch.ops.aten.div.Tensor(_unsafe_view_default_17, 8.0);  _unsafe_view_default_17 = None
        eq_scalar_3 = torch.ops.aten.eq.Scalar(unsqueeze_default_1, 0)
        where_scalar_self_3 = torch.ops.aten.where.ScalarSelf(eq_scalar_3, -1000000000.0, div_tensor_10);  div_tensor_10 = None
        _softmax_default_3 = torch.ops.aten._softmax.default(where_scalar_self_3, -1, False);  where_scalar_self_3 = None
        expand_default_14 = torch.ops.aten.expand.default(_softmax_default_3, [16, 12, 128, 128])
        view_default_60 = torch.ops.aten.view.default(expand_default_14, [192, 128, 128]);  expand_default_14 = None
        expand_default_15 = torch.ops.aten.expand.default(transpose_int_17, [16, 12, 128, 64]);  transpose_int_17 = None
        clone_default_14 = torch.ops.aten.clone.default(expand_default_15, memory_format = torch.contiguous_format);  expand_default_15 = None
        _unsafe_view_default_18 = torch.ops.aten._unsafe_view.default(clone_default_14, [192, 128, 64]);  clone_default_14 = None
        bmm_default_7 = torch.ops.aten.bmm.default(view_default_60, _unsafe_view_default_18)
        _unsafe_view_default_19 = torch.ops.aten._unsafe_view.default(bmm_default_7, [16, 12, 128, 64]);  bmm_default_7 = None
        transpose_int_19 = torch.ops.aten.transpose.int(_unsafe_view_default_19, 1, 2);  _unsafe_view_default_19 = None
        clone_default_15 = torch.ops.aten.clone.default(transpose_int_19, memory_format = torch.contiguous_format);  transpose_int_19 = None
        view_default_61 = torch.ops.aten.view.default(clone_default_15, [16, -1, 768]);  clone_default_15 = None
        view_default_62 = torch.ops.aten.view.default(view_default_61, [2048, 768]);  view_default_61 = None
        t_default_21 = torch.ops.aten.t.default(primals_97);  primals_97 = None
        addmm_default_21 = torch.ops.aten.addmm.default(primals_96, view_default_62, t_default_21);  primals_96 = None
        view_default_63 = torch.ops.aten.view.default(addmm_default_21, [16, 128, 768]);  addmm_default_21 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(add_tensor_19, view_default_63);  view_default_63 = None
        mean_dim_7 = torch.ops.aten.mean.dim(add_tensor_22, [-1], True)
        std_correction_7 = torch.ops.aten.std.correction(add_tensor_22, [-1], correction = 1, keepdim = True)
        sub_tensor_7 = torch.ops.aten.sub.Tensor(add_tensor_22, mean_dim_7);  mean_dim_7 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(primals_98, sub_tensor_7)
        add_tensor_23 = torch.ops.aten.add.Tensor(std_correction_7, 1e-06)
        div_tensor_11 = torch.ops.aten.div.Tensor(mul_tensor_7, add_tensor_23)
        add_tensor_24 = torch.ops.aten.add.Tensor(div_tensor_11, primals_99);  div_tensor_11 = primals_99 = None
        view_default_64 = torch.ops.aten.view.default(add_tensor_24, [2048, 768]);  add_tensor_24 = None
        t_default_22 = torch.ops.aten.t.default(primals_85);  primals_85 = None
        addmm_default_22 = torch.ops.aten.addmm.default(primals_84, view_default_64, t_default_22);  primals_84 = None
        view_default_65 = torch.ops.aten.view.default(addmm_default_22, [16, 128, 3072]);  addmm_default_22 = None
        gelu_default_3 = torch.ops.aten.gelu.default(view_default_65)
        view_default_66 = torch.ops.aten.view.default(gelu_default_3, [2048, 3072]);  gelu_default_3 = None
        t_default_23 = torch.ops.aten.t.default(primals_87);  primals_87 = None
        addmm_default_23 = torch.ops.aten.addmm.default(primals_86, view_default_66, t_default_23);  primals_86 = None
        view_default_67 = torch.ops.aten.view.default(addmm_default_23, [16, 128, 768]);  addmm_default_23 = None
        add_tensor_25 = torch.ops.aten.add.Tensor(add_tensor_22, view_default_67);  view_default_67 = None
        mean_dim_8 = torch.ops.aten.mean.dim(add_tensor_25, [-1], True)
        std_correction_8 = torch.ops.aten.std.correction(add_tensor_25, [-1], correction = 1, keepdim = True)
        sub_tensor_8 = torch.ops.aten.sub.Tensor(add_tensor_25, mean_dim_8);  mean_dim_8 = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(primals_104, sub_tensor_8)
        add_tensor_26 = torch.ops.aten.add.Tensor(std_correction_8, 1e-06)
        div_tensor_12 = torch.ops.aten.div.Tensor(mul_tensor_8, add_tensor_26)
        add_tensor_27 = torch.ops.aten.add.Tensor(div_tensor_12, primals_105);  div_tensor_12 = primals_105 = None
        view_default_68 = torch.ops.aten.view.default(add_tensor_27, [2048, 768])
        t_default_24 = torch.ops.aten.t.default(primals_107);  primals_107 = None
        addmm_default_24 = torch.ops.aten.addmm.default(primals_106, view_default_68, t_default_24);  primals_106 = None
        view_default_69 = torch.ops.aten.view.default(addmm_default_24, [16, 128, 768]);  addmm_default_24 = None
        view_default_70 = torch.ops.aten.view.default(view_default_69, [16, -1, 12, 64]);  view_default_69 = None
        transpose_int_20 = torch.ops.aten.transpose.int(view_default_70, 1, 2);  view_default_70 = None
        view_default_71 = torch.ops.aten.view.default(add_tensor_27, [2048, 768])
        t_default_25 = torch.ops.aten.t.default(primals_109);  primals_109 = None
        addmm_default_25 = torch.ops.aten.addmm.default(primals_108, view_default_71, t_default_25);  primals_108 = None
        view_default_72 = torch.ops.aten.view.default(addmm_default_25, [16, 128, 768]);  addmm_default_25 = None
        view_default_73 = torch.ops.aten.view.default(view_default_72, [16, -1, 12, 64]);  view_default_72 = None
        transpose_int_21 = torch.ops.aten.transpose.int(view_default_73, 1, 2);  view_default_73 = None
        view_default_74 = torch.ops.aten.view.default(add_tensor_27, [2048, 768]);  add_tensor_27 = None
        t_default_26 = torch.ops.aten.t.default(primals_111);  primals_111 = None
        addmm_default_26 = torch.ops.aten.addmm.default(primals_110, view_default_74, t_default_26);  primals_110 = None
        view_default_75 = torch.ops.aten.view.default(addmm_default_26, [16, 128, 768]);  addmm_default_26 = None
        view_default_76 = torch.ops.aten.view.default(view_default_75, [16, -1, 12, 64]);  view_default_75 = None
        transpose_int_22 = torch.ops.aten.transpose.int(view_default_76, 1, 2);  view_default_76 = None
        transpose_int_23 = torch.ops.aten.transpose.int(transpose_int_21, -2, -1);  transpose_int_21 = None
        expand_default_16 = torch.ops.aten.expand.default(transpose_int_20, [16, 12, 128, 64]);  transpose_int_20 = None
        clone_default_16 = torch.ops.aten.clone.default(expand_default_16, memory_format = torch.contiguous_format);  expand_default_16 = None
        _unsafe_view_default_20 = torch.ops.aten._unsafe_view.default(clone_default_16, [192, 128, 64]);  clone_default_16 = None
        expand_default_17 = torch.ops.aten.expand.default(transpose_int_23, [16, 12, 64, 128]);  transpose_int_23 = None
        clone_default_17 = torch.ops.aten.clone.default(expand_default_17, memory_format = torch.contiguous_format);  expand_default_17 = None
        _unsafe_view_default_21 = torch.ops.aten._unsafe_view.default(clone_default_17, [192, 64, 128]);  clone_default_17 = None
        bmm_default_8 = torch.ops.aten.bmm.default(_unsafe_view_default_20, _unsafe_view_default_21)
        _unsafe_view_default_22 = torch.ops.aten._unsafe_view.default(bmm_default_8, [16, 12, 128, 128]);  bmm_default_8 = None
        div_tensor_13 = torch.ops.aten.div.Tensor(_unsafe_view_default_22, 8.0);  _unsafe_view_default_22 = None
        eq_scalar_4 = torch.ops.aten.eq.Scalar(unsqueeze_default_1, 0)
        where_scalar_self_4 = torch.ops.aten.where.ScalarSelf(eq_scalar_4, -1000000000.0, div_tensor_13);  div_tensor_13 = None
        _softmax_default_4 = torch.ops.aten._softmax.default(where_scalar_self_4, -1, False);  where_scalar_self_4 = None
        expand_default_18 = torch.ops.aten.expand.default(_softmax_default_4, [16, 12, 128, 128])
        view_default_77 = torch.ops.aten.view.default(expand_default_18, [192, 128, 128]);  expand_default_18 = None
        expand_default_19 = torch.ops.aten.expand.default(transpose_int_22, [16, 12, 128, 64]);  transpose_int_22 = None
        clone_default_18 = torch.ops.aten.clone.default(expand_default_19, memory_format = torch.contiguous_format);  expand_default_19 = None
        _unsafe_view_default_23 = torch.ops.aten._unsafe_view.default(clone_default_18, [192, 128, 64]);  clone_default_18 = None
        bmm_default_9 = torch.ops.aten.bmm.default(view_default_77, _unsafe_view_default_23)
        _unsafe_view_default_24 = torch.ops.aten._unsafe_view.default(bmm_default_9, [16, 12, 128, 64]);  bmm_default_9 = None
        transpose_int_24 = torch.ops.aten.transpose.int(_unsafe_view_default_24, 1, 2);  _unsafe_view_default_24 = None
        clone_default_19 = torch.ops.aten.clone.default(transpose_int_24, memory_format = torch.contiguous_format);  transpose_int_24 = None
        view_default_78 = torch.ops.aten.view.default(clone_default_19, [16, -1, 768]);  clone_default_19 = None
        view_default_79 = torch.ops.aten.view.default(view_default_78, [2048, 768]);  view_default_78 = None
        t_default_27 = torch.ops.aten.t.default(primals_113);  primals_113 = None
        addmm_default_27 = torch.ops.aten.addmm.default(primals_112, view_default_79, t_default_27);  primals_112 = None
        view_default_80 = torch.ops.aten.view.default(addmm_default_27, [16, 128, 768]);  addmm_default_27 = None
        add_tensor_28 = torch.ops.aten.add.Tensor(add_tensor_25, view_default_80);  view_default_80 = None
        mean_dim_9 = torch.ops.aten.mean.dim(add_tensor_28, [-1], True)
        std_correction_9 = torch.ops.aten.std.correction(add_tensor_28, [-1], correction = 1, keepdim = True)
        sub_tensor_9 = torch.ops.aten.sub.Tensor(add_tensor_28, mean_dim_9);  mean_dim_9 = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(primals_114, sub_tensor_9)
        add_tensor_29 = torch.ops.aten.add.Tensor(std_correction_9, 1e-06)
        div_tensor_14 = torch.ops.aten.div.Tensor(mul_tensor_9, add_tensor_29)
        add_tensor_30 = torch.ops.aten.add.Tensor(div_tensor_14, primals_115);  div_tensor_14 = primals_115 = None
        view_default_81 = torch.ops.aten.view.default(add_tensor_30, [2048, 768]);  add_tensor_30 = None
        t_default_28 = torch.ops.aten.t.default(primals_101);  primals_101 = None
        addmm_default_28 = torch.ops.aten.addmm.default(primals_100, view_default_81, t_default_28);  primals_100 = None
        view_default_82 = torch.ops.aten.view.default(addmm_default_28, [16, 128, 3072]);  addmm_default_28 = None
        gelu_default_4 = torch.ops.aten.gelu.default(view_default_82)
        view_default_83 = torch.ops.aten.view.default(gelu_default_4, [2048, 3072]);  gelu_default_4 = None
        t_default_29 = torch.ops.aten.t.default(primals_103);  primals_103 = None
        addmm_default_29 = torch.ops.aten.addmm.default(primals_102, view_default_83, t_default_29);  primals_102 = None
        view_default_84 = torch.ops.aten.view.default(addmm_default_29, [16, 128, 768]);  addmm_default_29 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(add_tensor_28, view_default_84);  view_default_84 = None
        mean_dim_10 = torch.ops.aten.mean.dim(add_tensor_31, [-1], True)
        std_correction_10 = torch.ops.aten.std.correction(add_tensor_31, [-1], correction = 1, keepdim = True)
        sub_tensor_10 = torch.ops.aten.sub.Tensor(add_tensor_31, mean_dim_10);  mean_dim_10 = None
        mul_tensor_10 = torch.ops.aten.mul.Tensor(primals_120, sub_tensor_10)
        add_tensor_32 = torch.ops.aten.add.Tensor(std_correction_10, 1e-06)
        div_tensor_15 = torch.ops.aten.div.Tensor(mul_tensor_10, add_tensor_32)
        add_tensor_33 = torch.ops.aten.add.Tensor(div_tensor_15, primals_121);  div_tensor_15 = primals_121 = None
        view_default_85 = torch.ops.aten.view.default(add_tensor_33, [2048, 768])
        t_default_30 = torch.ops.aten.t.default(primals_123);  primals_123 = None
        addmm_default_30 = torch.ops.aten.addmm.default(primals_122, view_default_85, t_default_30);  primals_122 = None
        view_default_86 = torch.ops.aten.view.default(addmm_default_30, [16, 128, 768]);  addmm_default_30 = None
        view_default_87 = torch.ops.aten.view.default(view_default_86, [16, -1, 12, 64]);  view_default_86 = None
        transpose_int_25 = torch.ops.aten.transpose.int(view_default_87, 1, 2);  view_default_87 = None
        view_default_88 = torch.ops.aten.view.default(add_tensor_33, [2048, 768])
        t_default_31 = torch.ops.aten.t.default(primals_125);  primals_125 = None
        addmm_default_31 = torch.ops.aten.addmm.default(primals_124, view_default_88, t_default_31);  primals_124 = None
        view_default_89 = torch.ops.aten.view.default(addmm_default_31, [16, 128, 768]);  addmm_default_31 = None
        view_default_90 = torch.ops.aten.view.default(view_default_89, [16, -1, 12, 64]);  view_default_89 = None
        transpose_int_26 = torch.ops.aten.transpose.int(view_default_90, 1, 2);  view_default_90 = None
        view_default_91 = torch.ops.aten.view.default(add_tensor_33, [2048, 768]);  add_tensor_33 = None
        t_default_32 = torch.ops.aten.t.default(primals_127);  primals_127 = None
        addmm_default_32 = torch.ops.aten.addmm.default(primals_126, view_default_91, t_default_32);  primals_126 = None
        view_default_92 = torch.ops.aten.view.default(addmm_default_32, [16, 128, 768]);  addmm_default_32 = None
        view_default_93 = torch.ops.aten.view.default(view_default_92, [16, -1, 12, 64]);  view_default_92 = None
        transpose_int_27 = torch.ops.aten.transpose.int(view_default_93, 1, 2);  view_default_93 = None
        transpose_int_28 = torch.ops.aten.transpose.int(transpose_int_26, -2, -1);  transpose_int_26 = None
        expand_default_20 = torch.ops.aten.expand.default(transpose_int_25, [16, 12, 128, 64]);  transpose_int_25 = None
        clone_default_20 = torch.ops.aten.clone.default(expand_default_20, memory_format = torch.contiguous_format);  expand_default_20 = None
        _unsafe_view_default_25 = torch.ops.aten._unsafe_view.default(clone_default_20, [192, 128, 64]);  clone_default_20 = None
        expand_default_21 = torch.ops.aten.expand.default(transpose_int_28, [16, 12, 64, 128]);  transpose_int_28 = None
        clone_default_21 = torch.ops.aten.clone.default(expand_default_21, memory_format = torch.contiguous_format);  expand_default_21 = None
        _unsafe_view_default_26 = torch.ops.aten._unsafe_view.default(clone_default_21, [192, 64, 128]);  clone_default_21 = None
        bmm_default_10 = torch.ops.aten.bmm.default(_unsafe_view_default_25, _unsafe_view_default_26)
        _unsafe_view_default_27 = torch.ops.aten._unsafe_view.default(bmm_default_10, [16, 12, 128, 128]);  bmm_default_10 = None
        div_tensor_16 = torch.ops.aten.div.Tensor(_unsafe_view_default_27, 8.0);  _unsafe_view_default_27 = None
        eq_scalar_5 = torch.ops.aten.eq.Scalar(unsqueeze_default_1, 0)
        where_scalar_self_5 = torch.ops.aten.where.ScalarSelf(eq_scalar_5, -1000000000.0, div_tensor_16);  div_tensor_16 = None
        _softmax_default_5 = torch.ops.aten._softmax.default(where_scalar_self_5, -1, False);  where_scalar_self_5 = None
        expand_default_22 = torch.ops.aten.expand.default(_softmax_default_5, [16, 12, 128, 128])
        view_default_94 = torch.ops.aten.view.default(expand_default_22, [192, 128, 128]);  expand_default_22 = None
        expand_default_23 = torch.ops.aten.expand.default(transpose_int_27, [16, 12, 128, 64]);  transpose_int_27 = None
        clone_default_22 = torch.ops.aten.clone.default(expand_default_23, memory_format = torch.contiguous_format);  expand_default_23 = None
        _unsafe_view_default_28 = torch.ops.aten._unsafe_view.default(clone_default_22, [192, 128, 64]);  clone_default_22 = None
        bmm_default_11 = torch.ops.aten.bmm.default(view_default_94, _unsafe_view_default_28)
        _unsafe_view_default_29 = torch.ops.aten._unsafe_view.default(bmm_default_11, [16, 12, 128, 64]);  bmm_default_11 = None
        transpose_int_29 = torch.ops.aten.transpose.int(_unsafe_view_default_29, 1, 2);  _unsafe_view_default_29 = None
        clone_default_23 = torch.ops.aten.clone.default(transpose_int_29, memory_format = torch.contiguous_format);  transpose_int_29 = None
        view_default_95 = torch.ops.aten.view.default(clone_default_23, [16, -1, 768]);  clone_default_23 = None
        view_default_96 = torch.ops.aten.view.default(view_default_95, [2048, 768]);  view_default_95 = None
        t_default_33 = torch.ops.aten.t.default(primals_129);  primals_129 = None
        addmm_default_33 = torch.ops.aten.addmm.default(primals_128, view_default_96, t_default_33);  primals_128 = None
        view_default_97 = torch.ops.aten.view.default(addmm_default_33, [16, 128, 768]);  addmm_default_33 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(add_tensor_31, view_default_97);  view_default_97 = None
        mean_dim_11 = torch.ops.aten.mean.dim(add_tensor_34, [-1], True)
        std_correction_11 = torch.ops.aten.std.correction(add_tensor_34, [-1], correction = 1, keepdim = True)
        sub_tensor_11 = torch.ops.aten.sub.Tensor(add_tensor_34, mean_dim_11);  mean_dim_11 = None
        mul_tensor_11 = torch.ops.aten.mul.Tensor(primals_130, sub_tensor_11)
        add_tensor_35 = torch.ops.aten.add.Tensor(std_correction_11, 1e-06)
        div_tensor_17 = torch.ops.aten.div.Tensor(mul_tensor_11, add_tensor_35)
        add_tensor_36 = torch.ops.aten.add.Tensor(div_tensor_17, primals_131);  div_tensor_17 = primals_131 = None
        view_default_98 = torch.ops.aten.view.default(add_tensor_36, [2048, 768]);  add_tensor_36 = None
        t_default_34 = torch.ops.aten.t.default(primals_117);  primals_117 = None
        addmm_default_34 = torch.ops.aten.addmm.default(primals_116, view_default_98, t_default_34);  primals_116 = None
        view_default_99 = torch.ops.aten.view.default(addmm_default_34, [16, 128, 3072]);  addmm_default_34 = None
        gelu_default_5 = torch.ops.aten.gelu.default(view_default_99)
        view_default_100 = torch.ops.aten.view.default(gelu_default_5, [2048, 3072]);  gelu_default_5 = None
        t_default_35 = torch.ops.aten.t.default(primals_119);  primals_119 = None
        addmm_default_35 = torch.ops.aten.addmm.default(primals_118, view_default_100, t_default_35);  primals_118 = None
        view_default_101 = torch.ops.aten.view.default(addmm_default_35, [16, 128, 768]);  addmm_default_35 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(add_tensor_34, view_default_101);  view_default_101 = None
        mean_dim_12 = torch.ops.aten.mean.dim(add_tensor_37, [-1], True)
        std_correction_12 = torch.ops.aten.std.correction(add_tensor_37, [-1], correction = 1, keepdim = True)
        sub_tensor_12 = torch.ops.aten.sub.Tensor(add_tensor_37, mean_dim_12);  mean_dim_12 = None
        mul_tensor_12 = torch.ops.aten.mul.Tensor(primals_136, sub_tensor_12)
        add_tensor_38 = torch.ops.aten.add.Tensor(std_correction_12, 1e-06)
        div_tensor_18 = torch.ops.aten.div.Tensor(mul_tensor_12, add_tensor_38)
        add_tensor_39 = torch.ops.aten.add.Tensor(div_tensor_18, primals_137);  div_tensor_18 = primals_137 = None
        view_default_102 = torch.ops.aten.view.default(add_tensor_39, [2048, 768])
        t_default_36 = torch.ops.aten.t.default(primals_139);  primals_139 = None
        addmm_default_36 = torch.ops.aten.addmm.default(primals_138, view_default_102, t_default_36);  primals_138 = None
        view_default_103 = torch.ops.aten.view.default(addmm_default_36, [16, 128, 768]);  addmm_default_36 = None
        view_default_104 = torch.ops.aten.view.default(view_default_103, [16, -1, 12, 64]);  view_default_103 = None
        transpose_int_30 = torch.ops.aten.transpose.int(view_default_104, 1, 2);  view_default_104 = None
        view_default_105 = torch.ops.aten.view.default(add_tensor_39, [2048, 768])
        t_default_37 = torch.ops.aten.t.default(primals_141);  primals_141 = None
        addmm_default_37 = torch.ops.aten.addmm.default(primals_140, view_default_105, t_default_37);  primals_140 = None
        view_default_106 = torch.ops.aten.view.default(addmm_default_37, [16, 128, 768]);  addmm_default_37 = None
        view_default_107 = torch.ops.aten.view.default(view_default_106, [16, -1, 12, 64]);  view_default_106 = None
        transpose_int_31 = torch.ops.aten.transpose.int(view_default_107, 1, 2);  view_default_107 = None
        view_default_108 = torch.ops.aten.view.default(add_tensor_39, [2048, 768]);  add_tensor_39 = None
        t_default_38 = torch.ops.aten.t.default(primals_143);  primals_143 = None
        addmm_default_38 = torch.ops.aten.addmm.default(primals_142, view_default_108, t_default_38);  primals_142 = None
        view_default_109 = torch.ops.aten.view.default(addmm_default_38, [16, 128, 768]);  addmm_default_38 = None
        view_default_110 = torch.ops.aten.view.default(view_default_109, [16, -1, 12, 64]);  view_default_109 = None
        transpose_int_32 = torch.ops.aten.transpose.int(view_default_110, 1, 2);  view_default_110 = None
        transpose_int_33 = torch.ops.aten.transpose.int(transpose_int_31, -2, -1);  transpose_int_31 = None
        expand_default_24 = torch.ops.aten.expand.default(transpose_int_30, [16, 12, 128, 64]);  transpose_int_30 = None
        clone_default_24 = torch.ops.aten.clone.default(expand_default_24, memory_format = torch.contiguous_format);  expand_default_24 = None
        _unsafe_view_default_30 = torch.ops.aten._unsafe_view.default(clone_default_24, [192, 128, 64]);  clone_default_24 = None
        expand_default_25 = torch.ops.aten.expand.default(transpose_int_33, [16, 12, 64, 128]);  transpose_int_33 = None
        clone_default_25 = torch.ops.aten.clone.default(expand_default_25, memory_format = torch.contiguous_format);  expand_default_25 = None
        _unsafe_view_default_31 = torch.ops.aten._unsafe_view.default(clone_default_25, [192, 64, 128]);  clone_default_25 = None
        bmm_default_12 = torch.ops.aten.bmm.default(_unsafe_view_default_30, _unsafe_view_default_31)
        _unsafe_view_default_32 = torch.ops.aten._unsafe_view.default(bmm_default_12, [16, 12, 128, 128]);  bmm_default_12 = None
        div_tensor_19 = torch.ops.aten.div.Tensor(_unsafe_view_default_32, 8.0);  _unsafe_view_default_32 = None
        eq_scalar_6 = torch.ops.aten.eq.Scalar(unsqueeze_default_1, 0)
        where_scalar_self_6 = torch.ops.aten.where.ScalarSelf(eq_scalar_6, -1000000000.0, div_tensor_19);  div_tensor_19 = None
        _softmax_default_6 = torch.ops.aten._softmax.default(where_scalar_self_6, -1, False);  where_scalar_self_6 = None
        expand_default_26 = torch.ops.aten.expand.default(_softmax_default_6, [16, 12, 128, 128])
        view_default_111 = torch.ops.aten.view.default(expand_default_26, [192, 128, 128]);  expand_default_26 = None
        expand_default_27 = torch.ops.aten.expand.default(transpose_int_32, [16, 12, 128, 64]);  transpose_int_32 = None
        clone_default_26 = torch.ops.aten.clone.default(expand_default_27, memory_format = torch.contiguous_format);  expand_default_27 = None
        _unsafe_view_default_33 = torch.ops.aten._unsafe_view.default(clone_default_26, [192, 128, 64]);  clone_default_26 = None
        bmm_default_13 = torch.ops.aten.bmm.default(view_default_111, _unsafe_view_default_33)
        _unsafe_view_default_34 = torch.ops.aten._unsafe_view.default(bmm_default_13, [16, 12, 128, 64]);  bmm_default_13 = None
        transpose_int_34 = torch.ops.aten.transpose.int(_unsafe_view_default_34, 1, 2);  _unsafe_view_default_34 = None
        clone_default_27 = torch.ops.aten.clone.default(transpose_int_34, memory_format = torch.contiguous_format);  transpose_int_34 = None
        view_default_112 = torch.ops.aten.view.default(clone_default_27, [16, -1, 768]);  clone_default_27 = None
        view_default_113 = torch.ops.aten.view.default(view_default_112, [2048, 768]);  view_default_112 = None
        t_default_39 = torch.ops.aten.t.default(primals_145);  primals_145 = None
        addmm_default_39 = torch.ops.aten.addmm.default(primals_144, view_default_113, t_default_39);  primals_144 = None
        view_default_114 = torch.ops.aten.view.default(addmm_default_39, [16, 128, 768]);  addmm_default_39 = None
        add_tensor_40 = torch.ops.aten.add.Tensor(add_tensor_37, view_default_114);  view_default_114 = None
        mean_dim_13 = torch.ops.aten.mean.dim(add_tensor_40, [-1], True)
        std_correction_13 = torch.ops.aten.std.correction(add_tensor_40, [-1], correction = 1, keepdim = True)
        sub_tensor_13 = torch.ops.aten.sub.Tensor(add_tensor_40, mean_dim_13);  mean_dim_13 = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(primals_146, sub_tensor_13)
        add_tensor_41 = torch.ops.aten.add.Tensor(std_correction_13, 1e-06)
        div_tensor_20 = torch.ops.aten.div.Tensor(mul_tensor_13, add_tensor_41)
        add_tensor_42 = torch.ops.aten.add.Tensor(div_tensor_20, primals_147);  div_tensor_20 = primals_147 = None
        view_default_115 = torch.ops.aten.view.default(add_tensor_42, [2048, 768]);  add_tensor_42 = None
        t_default_40 = torch.ops.aten.t.default(primals_133);  primals_133 = None
        addmm_default_40 = torch.ops.aten.addmm.default(primals_132, view_default_115, t_default_40);  primals_132 = None
        view_default_116 = torch.ops.aten.view.default(addmm_default_40, [16, 128, 3072]);  addmm_default_40 = None
        gelu_default_6 = torch.ops.aten.gelu.default(view_default_116)
        view_default_117 = torch.ops.aten.view.default(gelu_default_6, [2048, 3072]);  gelu_default_6 = None
        t_default_41 = torch.ops.aten.t.default(primals_135);  primals_135 = None
        addmm_default_41 = torch.ops.aten.addmm.default(primals_134, view_default_117, t_default_41);  primals_134 = None
        view_default_118 = torch.ops.aten.view.default(addmm_default_41, [16, 128, 768]);  addmm_default_41 = None
        add_tensor_43 = torch.ops.aten.add.Tensor(add_tensor_40, view_default_118);  view_default_118 = None
        mean_dim_14 = torch.ops.aten.mean.dim(add_tensor_43, [-1], True)
        std_correction_14 = torch.ops.aten.std.correction(add_tensor_43, [-1], correction = 1, keepdim = True)
        sub_tensor_14 = torch.ops.aten.sub.Tensor(add_tensor_43, mean_dim_14);  mean_dim_14 = None
        mul_tensor_14 = torch.ops.aten.mul.Tensor(primals_152, sub_tensor_14)
        add_tensor_44 = torch.ops.aten.add.Tensor(std_correction_14, 1e-06)
        div_tensor_21 = torch.ops.aten.div.Tensor(mul_tensor_14, add_tensor_44)
        add_tensor_45 = torch.ops.aten.add.Tensor(div_tensor_21, primals_153);  div_tensor_21 = primals_153 = None
        view_default_119 = torch.ops.aten.view.default(add_tensor_45, [2048, 768])
        t_default_42 = torch.ops.aten.t.default(primals_155);  primals_155 = None
        addmm_default_42 = torch.ops.aten.addmm.default(primals_154, view_default_119, t_default_42);  primals_154 = None
        view_default_120 = torch.ops.aten.view.default(addmm_default_42, [16, 128, 768]);  addmm_default_42 = None
        view_default_121 = torch.ops.aten.view.default(view_default_120, [16, -1, 12, 64]);  view_default_120 = None
        transpose_int_35 = torch.ops.aten.transpose.int(view_default_121, 1, 2);  view_default_121 = None
        view_default_122 = torch.ops.aten.view.default(add_tensor_45, [2048, 768])
        t_default_43 = torch.ops.aten.t.default(primals_157);  primals_157 = None
        addmm_default_43 = torch.ops.aten.addmm.default(primals_156, view_default_122, t_default_43);  primals_156 = None
        view_default_123 = torch.ops.aten.view.default(addmm_default_43, [16, 128, 768]);  addmm_default_43 = None
        view_default_124 = torch.ops.aten.view.default(view_default_123, [16, -1, 12, 64]);  view_default_123 = None
        transpose_int_36 = torch.ops.aten.transpose.int(view_default_124, 1, 2);  view_default_124 = None
        view_default_125 = torch.ops.aten.view.default(add_tensor_45, [2048, 768]);  add_tensor_45 = None
        t_default_44 = torch.ops.aten.t.default(primals_159);  primals_159 = None
        addmm_default_44 = torch.ops.aten.addmm.default(primals_158, view_default_125, t_default_44);  primals_158 = None
        view_default_126 = torch.ops.aten.view.default(addmm_default_44, [16, 128, 768]);  addmm_default_44 = None
        view_default_127 = torch.ops.aten.view.default(view_default_126, [16, -1, 12, 64]);  view_default_126 = None
        transpose_int_37 = torch.ops.aten.transpose.int(view_default_127, 1, 2);  view_default_127 = None
        transpose_int_38 = torch.ops.aten.transpose.int(transpose_int_36, -2, -1);  transpose_int_36 = None
        expand_default_28 = torch.ops.aten.expand.default(transpose_int_35, [16, 12, 128, 64]);  transpose_int_35 = None
        clone_default_28 = torch.ops.aten.clone.default(expand_default_28, memory_format = torch.contiguous_format);  expand_default_28 = None
        _unsafe_view_default_35 = torch.ops.aten._unsafe_view.default(clone_default_28, [192, 128, 64]);  clone_default_28 = None
        expand_default_29 = torch.ops.aten.expand.default(transpose_int_38, [16, 12, 64, 128]);  transpose_int_38 = None
        clone_default_29 = torch.ops.aten.clone.default(expand_default_29, memory_format = torch.contiguous_format);  expand_default_29 = None
        _unsafe_view_default_36 = torch.ops.aten._unsafe_view.default(clone_default_29, [192, 64, 128]);  clone_default_29 = None
        bmm_default_14 = torch.ops.aten.bmm.default(_unsafe_view_default_35, _unsafe_view_default_36)
        _unsafe_view_default_37 = torch.ops.aten._unsafe_view.default(bmm_default_14, [16, 12, 128, 128]);  bmm_default_14 = None
        div_tensor_22 = torch.ops.aten.div.Tensor(_unsafe_view_default_37, 8.0);  _unsafe_view_default_37 = None
        eq_scalar_7 = torch.ops.aten.eq.Scalar(unsqueeze_default_1, 0)
        where_scalar_self_7 = torch.ops.aten.where.ScalarSelf(eq_scalar_7, -1000000000.0, div_tensor_22);  div_tensor_22 = None
        _softmax_default_7 = torch.ops.aten._softmax.default(where_scalar_self_7, -1, False);  where_scalar_self_7 = None
        expand_default_30 = torch.ops.aten.expand.default(_softmax_default_7, [16, 12, 128, 128])
        view_default_128 = torch.ops.aten.view.default(expand_default_30, [192, 128, 128]);  expand_default_30 = None
        expand_default_31 = torch.ops.aten.expand.default(transpose_int_37, [16, 12, 128, 64]);  transpose_int_37 = None
        clone_default_30 = torch.ops.aten.clone.default(expand_default_31, memory_format = torch.contiguous_format);  expand_default_31 = None
        _unsafe_view_default_38 = torch.ops.aten._unsafe_view.default(clone_default_30, [192, 128, 64]);  clone_default_30 = None
        bmm_default_15 = torch.ops.aten.bmm.default(view_default_128, _unsafe_view_default_38)
        _unsafe_view_default_39 = torch.ops.aten._unsafe_view.default(bmm_default_15, [16, 12, 128, 64]);  bmm_default_15 = None
        transpose_int_39 = torch.ops.aten.transpose.int(_unsafe_view_default_39, 1, 2);  _unsafe_view_default_39 = None
        clone_default_31 = torch.ops.aten.clone.default(transpose_int_39, memory_format = torch.contiguous_format);  transpose_int_39 = None
        view_default_129 = torch.ops.aten.view.default(clone_default_31, [16, -1, 768]);  clone_default_31 = None
        view_default_130 = torch.ops.aten.view.default(view_default_129, [2048, 768]);  view_default_129 = None
        t_default_45 = torch.ops.aten.t.default(primals_161);  primals_161 = None
        addmm_default_45 = torch.ops.aten.addmm.default(primals_160, view_default_130, t_default_45);  primals_160 = None
        view_default_131 = torch.ops.aten.view.default(addmm_default_45, [16, 128, 768]);  addmm_default_45 = None
        add_tensor_46 = torch.ops.aten.add.Tensor(add_tensor_43, view_default_131);  view_default_131 = None
        mean_dim_15 = torch.ops.aten.mean.dim(add_tensor_46, [-1], True)
        std_correction_15 = torch.ops.aten.std.correction(add_tensor_46, [-1], correction = 1, keepdim = True)
        sub_tensor_15 = torch.ops.aten.sub.Tensor(add_tensor_46, mean_dim_15);  mean_dim_15 = None
        mul_tensor_15 = torch.ops.aten.mul.Tensor(primals_162, sub_tensor_15)
        add_tensor_47 = torch.ops.aten.add.Tensor(std_correction_15, 1e-06)
        div_tensor_23 = torch.ops.aten.div.Tensor(mul_tensor_15, add_tensor_47)
        add_tensor_48 = torch.ops.aten.add.Tensor(div_tensor_23, primals_163);  div_tensor_23 = primals_163 = None
        view_default_132 = torch.ops.aten.view.default(add_tensor_48, [2048, 768]);  add_tensor_48 = None
        t_default_46 = torch.ops.aten.t.default(primals_149);  primals_149 = None
        addmm_default_46 = torch.ops.aten.addmm.default(primals_148, view_default_132, t_default_46);  primals_148 = None
        view_default_133 = torch.ops.aten.view.default(addmm_default_46, [16, 128, 3072]);  addmm_default_46 = None
        gelu_default_7 = torch.ops.aten.gelu.default(view_default_133)
        view_default_134 = torch.ops.aten.view.default(gelu_default_7, [2048, 3072]);  gelu_default_7 = None
        t_default_47 = torch.ops.aten.t.default(primals_151);  primals_151 = None
        addmm_default_47 = torch.ops.aten.addmm.default(primals_150, view_default_134, t_default_47);  primals_150 = None
        view_default_135 = torch.ops.aten.view.default(addmm_default_47, [16, 128, 768]);  addmm_default_47 = None
        add_tensor_49 = torch.ops.aten.add.Tensor(add_tensor_46, view_default_135);  view_default_135 = None
        mean_dim_16 = torch.ops.aten.mean.dim(add_tensor_49, [-1], True)
        std_correction_16 = torch.ops.aten.std.correction(add_tensor_49, [-1], correction = 1, keepdim = True)
        sub_tensor_16 = torch.ops.aten.sub.Tensor(add_tensor_49, mean_dim_16);  mean_dim_16 = None
        mul_tensor_16 = torch.ops.aten.mul.Tensor(primals_168, sub_tensor_16)
        add_tensor_50 = torch.ops.aten.add.Tensor(std_correction_16, 1e-06)
        div_tensor_24 = torch.ops.aten.div.Tensor(mul_tensor_16, add_tensor_50)
        add_tensor_51 = torch.ops.aten.add.Tensor(div_tensor_24, primals_169);  div_tensor_24 = primals_169 = None
        view_default_136 = torch.ops.aten.view.default(add_tensor_51, [2048, 768])
        t_default_48 = torch.ops.aten.t.default(primals_171);  primals_171 = None
        addmm_default_48 = torch.ops.aten.addmm.default(primals_170, view_default_136, t_default_48);  primals_170 = None
        view_default_137 = torch.ops.aten.view.default(addmm_default_48, [16, 128, 768]);  addmm_default_48 = None
        view_default_138 = torch.ops.aten.view.default(view_default_137, [16, -1, 12, 64]);  view_default_137 = None
        transpose_int_40 = torch.ops.aten.transpose.int(view_default_138, 1, 2);  view_default_138 = None
        view_default_139 = torch.ops.aten.view.default(add_tensor_51, [2048, 768])
        t_default_49 = torch.ops.aten.t.default(primals_173);  primals_173 = None
        addmm_default_49 = torch.ops.aten.addmm.default(primals_172, view_default_139, t_default_49);  primals_172 = None
        view_default_140 = torch.ops.aten.view.default(addmm_default_49, [16, 128, 768]);  addmm_default_49 = None
        view_default_141 = torch.ops.aten.view.default(view_default_140, [16, -1, 12, 64]);  view_default_140 = None
        transpose_int_41 = torch.ops.aten.transpose.int(view_default_141, 1, 2);  view_default_141 = None
        view_default_142 = torch.ops.aten.view.default(add_tensor_51, [2048, 768]);  add_tensor_51 = None
        t_default_50 = torch.ops.aten.t.default(primals_175);  primals_175 = None
        addmm_default_50 = torch.ops.aten.addmm.default(primals_174, view_default_142, t_default_50);  primals_174 = None
        view_default_143 = torch.ops.aten.view.default(addmm_default_50, [16, 128, 768]);  addmm_default_50 = None
        view_default_144 = torch.ops.aten.view.default(view_default_143, [16, -1, 12, 64]);  view_default_143 = None
        transpose_int_42 = torch.ops.aten.transpose.int(view_default_144, 1, 2);  view_default_144 = None
        transpose_int_43 = torch.ops.aten.transpose.int(transpose_int_41, -2, -1);  transpose_int_41 = None
        expand_default_32 = torch.ops.aten.expand.default(transpose_int_40, [16, 12, 128, 64]);  transpose_int_40 = None
        clone_default_32 = torch.ops.aten.clone.default(expand_default_32, memory_format = torch.contiguous_format);  expand_default_32 = None
        _unsafe_view_default_40 = torch.ops.aten._unsafe_view.default(clone_default_32, [192, 128, 64]);  clone_default_32 = None
        expand_default_33 = torch.ops.aten.expand.default(transpose_int_43, [16, 12, 64, 128]);  transpose_int_43 = None
        clone_default_33 = torch.ops.aten.clone.default(expand_default_33, memory_format = torch.contiguous_format);  expand_default_33 = None
        _unsafe_view_default_41 = torch.ops.aten._unsafe_view.default(clone_default_33, [192, 64, 128]);  clone_default_33 = None
        bmm_default_16 = torch.ops.aten.bmm.default(_unsafe_view_default_40, _unsafe_view_default_41)
        _unsafe_view_default_42 = torch.ops.aten._unsafe_view.default(bmm_default_16, [16, 12, 128, 128]);  bmm_default_16 = None
        div_tensor_25 = torch.ops.aten.div.Tensor(_unsafe_view_default_42, 8.0);  _unsafe_view_default_42 = None
        eq_scalar_8 = torch.ops.aten.eq.Scalar(unsqueeze_default_1, 0)
        where_scalar_self_8 = torch.ops.aten.where.ScalarSelf(eq_scalar_8, -1000000000.0, div_tensor_25);  div_tensor_25 = None
        _softmax_default_8 = torch.ops.aten._softmax.default(where_scalar_self_8, -1, False);  where_scalar_self_8 = None
        expand_default_34 = torch.ops.aten.expand.default(_softmax_default_8, [16, 12, 128, 128])
        view_default_145 = torch.ops.aten.view.default(expand_default_34, [192, 128, 128]);  expand_default_34 = None
        expand_default_35 = torch.ops.aten.expand.default(transpose_int_42, [16, 12, 128, 64]);  transpose_int_42 = None
        clone_default_34 = torch.ops.aten.clone.default(expand_default_35, memory_format = torch.contiguous_format);  expand_default_35 = None
        _unsafe_view_default_43 = torch.ops.aten._unsafe_view.default(clone_default_34, [192, 128, 64]);  clone_default_34 = None
        bmm_default_17 = torch.ops.aten.bmm.default(view_default_145, _unsafe_view_default_43)
        _unsafe_view_default_44 = torch.ops.aten._unsafe_view.default(bmm_default_17, [16, 12, 128, 64]);  bmm_default_17 = None
        transpose_int_44 = torch.ops.aten.transpose.int(_unsafe_view_default_44, 1, 2);  _unsafe_view_default_44 = None
        clone_default_35 = torch.ops.aten.clone.default(transpose_int_44, memory_format = torch.contiguous_format);  transpose_int_44 = None
        view_default_146 = torch.ops.aten.view.default(clone_default_35, [16, -1, 768]);  clone_default_35 = None
        view_default_147 = torch.ops.aten.view.default(view_default_146, [2048, 768]);  view_default_146 = None
        t_default_51 = torch.ops.aten.t.default(primals_177);  primals_177 = None
        addmm_default_51 = torch.ops.aten.addmm.default(primals_176, view_default_147, t_default_51);  primals_176 = None
        view_default_148 = torch.ops.aten.view.default(addmm_default_51, [16, 128, 768]);  addmm_default_51 = None
        add_tensor_52 = torch.ops.aten.add.Tensor(add_tensor_49, view_default_148);  view_default_148 = None
        mean_dim_17 = torch.ops.aten.mean.dim(add_tensor_52, [-1], True)
        std_correction_17 = torch.ops.aten.std.correction(add_tensor_52, [-1], correction = 1, keepdim = True)
        sub_tensor_17 = torch.ops.aten.sub.Tensor(add_tensor_52, mean_dim_17);  mean_dim_17 = None
        mul_tensor_17 = torch.ops.aten.mul.Tensor(primals_178, sub_tensor_17)
        add_tensor_53 = torch.ops.aten.add.Tensor(std_correction_17, 1e-06)
        div_tensor_26 = torch.ops.aten.div.Tensor(mul_tensor_17, add_tensor_53)
        add_tensor_54 = torch.ops.aten.add.Tensor(div_tensor_26, primals_179);  div_tensor_26 = primals_179 = None
        view_default_149 = torch.ops.aten.view.default(add_tensor_54, [2048, 768]);  add_tensor_54 = None
        t_default_52 = torch.ops.aten.t.default(primals_165);  primals_165 = None
        addmm_default_52 = torch.ops.aten.addmm.default(primals_164, view_default_149, t_default_52);  primals_164 = None
        view_default_150 = torch.ops.aten.view.default(addmm_default_52, [16, 128, 3072]);  addmm_default_52 = None
        gelu_default_8 = torch.ops.aten.gelu.default(view_default_150)
        view_default_151 = torch.ops.aten.view.default(gelu_default_8, [2048, 3072]);  gelu_default_8 = None
        t_default_53 = torch.ops.aten.t.default(primals_167);  primals_167 = None
        addmm_default_53 = torch.ops.aten.addmm.default(primals_166, view_default_151, t_default_53);  primals_166 = None
        view_default_152 = torch.ops.aten.view.default(addmm_default_53, [16, 128, 768]);  addmm_default_53 = None
        add_tensor_55 = torch.ops.aten.add.Tensor(add_tensor_52, view_default_152);  view_default_152 = None
        mean_dim_18 = torch.ops.aten.mean.dim(add_tensor_55, [-1], True)
        std_correction_18 = torch.ops.aten.std.correction(add_tensor_55, [-1], correction = 1, keepdim = True)
        sub_tensor_18 = torch.ops.aten.sub.Tensor(add_tensor_55, mean_dim_18);  mean_dim_18 = None
        mul_tensor_18 = torch.ops.aten.mul.Tensor(primals_184, sub_tensor_18)
        add_tensor_56 = torch.ops.aten.add.Tensor(std_correction_18, 1e-06)
        div_tensor_27 = torch.ops.aten.div.Tensor(mul_tensor_18, add_tensor_56)
        add_tensor_57 = torch.ops.aten.add.Tensor(div_tensor_27, primals_185);  div_tensor_27 = primals_185 = None
        view_default_153 = torch.ops.aten.view.default(add_tensor_57, [2048, 768])
        t_default_54 = torch.ops.aten.t.default(primals_187);  primals_187 = None
        addmm_default_54 = torch.ops.aten.addmm.default(primals_186, view_default_153, t_default_54);  primals_186 = None
        view_default_154 = torch.ops.aten.view.default(addmm_default_54, [16, 128, 768]);  addmm_default_54 = None
        view_default_155 = torch.ops.aten.view.default(view_default_154, [16, -1, 12, 64]);  view_default_154 = None
        transpose_int_45 = torch.ops.aten.transpose.int(view_default_155, 1, 2);  view_default_155 = None
        view_default_156 = torch.ops.aten.view.default(add_tensor_57, [2048, 768])
        t_default_55 = torch.ops.aten.t.default(primals_189);  primals_189 = None
        addmm_default_55 = torch.ops.aten.addmm.default(primals_188, view_default_156, t_default_55);  primals_188 = None
        view_default_157 = torch.ops.aten.view.default(addmm_default_55, [16, 128, 768]);  addmm_default_55 = None
        view_default_158 = torch.ops.aten.view.default(view_default_157, [16, -1, 12, 64]);  view_default_157 = None
        transpose_int_46 = torch.ops.aten.transpose.int(view_default_158, 1, 2);  view_default_158 = None
        view_default_159 = torch.ops.aten.view.default(add_tensor_57, [2048, 768]);  add_tensor_57 = None
        t_default_56 = torch.ops.aten.t.default(primals_191);  primals_191 = None
        addmm_default_56 = torch.ops.aten.addmm.default(primals_190, view_default_159, t_default_56);  primals_190 = None
        view_default_160 = torch.ops.aten.view.default(addmm_default_56, [16, 128, 768]);  addmm_default_56 = None
        view_default_161 = torch.ops.aten.view.default(view_default_160, [16, -1, 12, 64]);  view_default_160 = None
        transpose_int_47 = torch.ops.aten.transpose.int(view_default_161, 1, 2);  view_default_161 = None
        transpose_int_48 = torch.ops.aten.transpose.int(transpose_int_46, -2, -1);  transpose_int_46 = None
        expand_default_36 = torch.ops.aten.expand.default(transpose_int_45, [16, 12, 128, 64]);  transpose_int_45 = None
        clone_default_36 = torch.ops.aten.clone.default(expand_default_36, memory_format = torch.contiguous_format);  expand_default_36 = None
        _unsafe_view_default_45 = torch.ops.aten._unsafe_view.default(clone_default_36, [192, 128, 64]);  clone_default_36 = None
        expand_default_37 = torch.ops.aten.expand.default(transpose_int_48, [16, 12, 64, 128]);  transpose_int_48 = None
        clone_default_37 = torch.ops.aten.clone.default(expand_default_37, memory_format = torch.contiguous_format);  expand_default_37 = None
        _unsafe_view_default_46 = torch.ops.aten._unsafe_view.default(clone_default_37, [192, 64, 128]);  clone_default_37 = None
        bmm_default_18 = torch.ops.aten.bmm.default(_unsafe_view_default_45, _unsafe_view_default_46)
        _unsafe_view_default_47 = torch.ops.aten._unsafe_view.default(bmm_default_18, [16, 12, 128, 128]);  bmm_default_18 = None
        div_tensor_28 = torch.ops.aten.div.Tensor(_unsafe_view_default_47, 8.0);  _unsafe_view_default_47 = None
        eq_scalar_9 = torch.ops.aten.eq.Scalar(unsqueeze_default_1, 0)
        where_scalar_self_9 = torch.ops.aten.where.ScalarSelf(eq_scalar_9, -1000000000.0, div_tensor_28);  div_tensor_28 = None
        _softmax_default_9 = torch.ops.aten._softmax.default(where_scalar_self_9, -1, False);  where_scalar_self_9 = None
        expand_default_38 = torch.ops.aten.expand.default(_softmax_default_9, [16, 12, 128, 128])
        view_default_162 = torch.ops.aten.view.default(expand_default_38, [192, 128, 128]);  expand_default_38 = None
        expand_default_39 = torch.ops.aten.expand.default(transpose_int_47, [16, 12, 128, 64]);  transpose_int_47 = None
        clone_default_38 = torch.ops.aten.clone.default(expand_default_39, memory_format = torch.contiguous_format);  expand_default_39 = None
        _unsafe_view_default_48 = torch.ops.aten._unsafe_view.default(clone_default_38, [192, 128, 64]);  clone_default_38 = None
        bmm_default_19 = torch.ops.aten.bmm.default(view_default_162, _unsafe_view_default_48)
        _unsafe_view_default_49 = torch.ops.aten._unsafe_view.default(bmm_default_19, [16, 12, 128, 64]);  bmm_default_19 = None
        transpose_int_49 = torch.ops.aten.transpose.int(_unsafe_view_default_49, 1, 2);  _unsafe_view_default_49 = None
        clone_default_39 = torch.ops.aten.clone.default(transpose_int_49, memory_format = torch.contiguous_format);  transpose_int_49 = None
        view_default_163 = torch.ops.aten.view.default(clone_default_39, [16, -1, 768]);  clone_default_39 = None
        view_default_164 = torch.ops.aten.view.default(view_default_163, [2048, 768]);  view_default_163 = None
        t_default_57 = torch.ops.aten.t.default(primals_193);  primals_193 = None
        addmm_default_57 = torch.ops.aten.addmm.default(primals_192, view_default_164, t_default_57);  primals_192 = None
        view_default_165 = torch.ops.aten.view.default(addmm_default_57, [16, 128, 768]);  addmm_default_57 = None
        add_tensor_58 = torch.ops.aten.add.Tensor(add_tensor_55, view_default_165);  view_default_165 = None
        mean_dim_19 = torch.ops.aten.mean.dim(add_tensor_58, [-1], True)
        std_correction_19 = torch.ops.aten.std.correction(add_tensor_58, [-1], correction = 1, keepdim = True)
        sub_tensor_19 = torch.ops.aten.sub.Tensor(add_tensor_58, mean_dim_19);  mean_dim_19 = None
        mul_tensor_19 = torch.ops.aten.mul.Tensor(primals_194, sub_tensor_19)
        add_tensor_59 = torch.ops.aten.add.Tensor(std_correction_19, 1e-06)
        div_tensor_29 = torch.ops.aten.div.Tensor(mul_tensor_19, add_tensor_59)
        add_tensor_60 = torch.ops.aten.add.Tensor(div_tensor_29, primals_195);  div_tensor_29 = primals_195 = None
        view_default_166 = torch.ops.aten.view.default(add_tensor_60, [2048, 768]);  add_tensor_60 = None
        t_default_58 = torch.ops.aten.t.default(primals_181);  primals_181 = None
        addmm_default_58 = torch.ops.aten.addmm.default(primals_180, view_default_166, t_default_58);  primals_180 = None
        view_default_167 = torch.ops.aten.view.default(addmm_default_58, [16, 128, 3072]);  addmm_default_58 = None
        gelu_default_9 = torch.ops.aten.gelu.default(view_default_167)
        view_default_168 = torch.ops.aten.view.default(gelu_default_9, [2048, 3072]);  gelu_default_9 = None
        t_default_59 = torch.ops.aten.t.default(primals_183);  primals_183 = None
        addmm_default_59 = torch.ops.aten.addmm.default(primals_182, view_default_168, t_default_59);  primals_182 = None
        view_default_169 = torch.ops.aten.view.default(addmm_default_59, [16, 128, 768]);  addmm_default_59 = None
        add_tensor_61 = torch.ops.aten.add.Tensor(add_tensor_58, view_default_169);  view_default_169 = None
        mean_dim_20 = torch.ops.aten.mean.dim(add_tensor_61, [-1], True)
        std_correction_20 = torch.ops.aten.std.correction(add_tensor_61, [-1], correction = 1, keepdim = True)
        sub_tensor_20 = torch.ops.aten.sub.Tensor(add_tensor_61, mean_dim_20);  mean_dim_20 = None
        mul_tensor_20 = torch.ops.aten.mul.Tensor(primals_24, sub_tensor_20)
        add_tensor_62 = torch.ops.aten.add.Tensor(std_correction_20, 1e-06)
        div_tensor_30 = torch.ops.aten.div.Tensor(mul_tensor_20, add_tensor_62)
        add_tensor_63 = torch.ops.aten.add.Tensor(div_tensor_30, primals_25);  div_tensor_30 = primals_25 = None
        view_default_170 = torch.ops.aten.view.default(add_tensor_63, [2048, 768])
        t_default_60 = torch.ops.aten.t.default(primals_27);  primals_27 = None
        addmm_default_60 = torch.ops.aten.addmm.default(primals_26, view_default_170, t_default_60);  primals_26 = None
        view_default_171 = torch.ops.aten.view.default(addmm_default_60, [16, 128, 768]);  addmm_default_60 = None
        view_default_172 = torch.ops.aten.view.default(view_default_171, [16, -1, 12, 64]);  view_default_171 = None
        transpose_int_50 = torch.ops.aten.transpose.int(view_default_172, 1, 2);  view_default_172 = None
        view_default_173 = torch.ops.aten.view.default(add_tensor_63, [2048, 768])
        t_default_61 = torch.ops.aten.t.default(primals_29);  primals_29 = None
        addmm_default_61 = torch.ops.aten.addmm.default(primals_28, view_default_173, t_default_61);  primals_28 = None
        view_default_174 = torch.ops.aten.view.default(addmm_default_61, [16, 128, 768]);  addmm_default_61 = None
        view_default_175 = torch.ops.aten.view.default(view_default_174, [16, -1, 12, 64]);  view_default_174 = None
        transpose_int_51 = torch.ops.aten.transpose.int(view_default_175, 1, 2);  view_default_175 = None
        view_default_176 = torch.ops.aten.view.default(add_tensor_63, [2048, 768]);  add_tensor_63 = None
        t_default_62 = torch.ops.aten.t.default(primals_31);  primals_31 = None
        addmm_default_62 = torch.ops.aten.addmm.default(primals_30, view_default_176, t_default_62);  primals_30 = None
        view_default_177 = torch.ops.aten.view.default(addmm_default_62, [16, 128, 768]);  addmm_default_62 = None
        view_default_178 = torch.ops.aten.view.default(view_default_177, [16, -1, 12, 64]);  view_default_177 = None
        transpose_int_52 = torch.ops.aten.transpose.int(view_default_178, 1, 2);  view_default_178 = None
        transpose_int_53 = torch.ops.aten.transpose.int(transpose_int_51, -2, -1);  transpose_int_51 = None
        expand_default_40 = torch.ops.aten.expand.default(transpose_int_50, [16, 12, 128, 64]);  transpose_int_50 = None
        clone_default_40 = torch.ops.aten.clone.default(expand_default_40, memory_format = torch.contiguous_format);  expand_default_40 = None
        _unsafe_view_default_50 = torch.ops.aten._unsafe_view.default(clone_default_40, [192, 128, 64]);  clone_default_40 = None
        expand_default_41 = torch.ops.aten.expand.default(transpose_int_53, [16, 12, 64, 128]);  transpose_int_53 = None
        clone_default_41 = torch.ops.aten.clone.default(expand_default_41, memory_format = torch.contiguous_format);  expand_default_41 = None
        _unsafe_view_default_51 = torch.ops.aten._unsafe_view.default(clone_default_41, [192, 64, 128]);  clone_default_41 = None
        bmm_default_20 = torch.ops.aten.bmm.default(_unsafe_view_default_50, _unsafe_view_default_51)
        _unsafe_view_default_52 = torch.ops.aten._unsafe_view.default(bmm_default_20, [16, 12, 128, 128]);  bmm_default_20 = None
        div_tensor_31 = torch.ops.aten.div.Tensor(_unsafe_view_default_52, 8.0);  _unsafe_view_default_52 = None
        eq_scalar_10 = torch.ops.aten.eq.Scalar(unsqueeze_default_1, 0)
        where_scalar_self_10 = torch.ops.aten.where.ScalarSelf(eq_scalar_10, -1000000000.0, div_tensor_31);  div_tensor_31 = None
        _softmax_default_10 = torch.ops.aten._softmax.default(where_scalar_self_10, -1, False);  where_scalar_self_10 = None
        expand_default_42 = torch.ops.aten.expand.default(_softmax_default_10, [16, 12, 128, 128])
        view_default_179 = torch.ops.aten.view.default(expand_default_42, [192, 128, 128]);  expand_default_42 = None
        expand_default_43 = torch.ops.aten.expand.default(transpose_int_52, [16, 12, 128, 64]);  transpose_int_52 = None
        clone_default_42 = torch.ops.aten.clone.default(expand_default_43, memory_format = torch.contiguous_format);  expand_default_43 = None
        _unsafe_view_default_53 = torch.ops.aten._unsafe_view.default(clone_default_42, [192, 128, 64]);  clone_default_42 = None
        bmm_default_21 = torch.ops.aten.bmm.default(view_default_179, _unsafe_view_default_53)
        _unsafe_view_default_54 = torch.ops.aten._unsafe_view.default(bmm_default_21, [16, 12, 128, 64]);  bmm_default_21 = None
        transpose_int_54 = torch.ops.aten.transpose.int(_unsafe_view_default_54, 1, 2);  _unsafe_view_default_54 = None
        clone_default_43 = torch.ops.aten.clone.default(transpose_int_54, memory_format = torch.contiguous_format);  transpose_int_54 = None
        view_default_180 = torch.ops.aten.view.default(clone_default_43, [16, -1, 768]);  clone_default_43 = None
        view_default_181 = torch.ops.aten.view.default(view_default_180, [2048, 768]);  view_default_180 = None
        t_default_63 = torch.ops.aten.t.default(primals_33);  primals_33 = None
        addmm_default_63 = torch.ops.aten.addmm.default(primals_32, view_default_181, t_default_63);  primals_32 = None
        view_default_182 = torch.ops.aten.view.default(addmm_default_63, [16, 128, 768]);  addmm_default_63 = None
        add_tensor_64 = torch.ops.aten.add.Tensor(add_tensor_61, view_default_182);  view_default_182 = None
        mean_dim_21 = torch.ops.aten.mean.dim(add_tensor_64, [-1], True)
        std_correction_21 = torch.ops.aten.std.correction(add_tensor_64, [-1], correction = 1, keepdim = True)
        sub_tensor_21 = torch.ops.aten.sub.Tensor(add_tensor_64, mean_dim_21);  mean_dim_21 = None
        mul_tensor_21 = torch.ops.aten.mul.Tensor(primals_34, sub_tensor_21)
        add_tensor_65 = torch.ops.aten.add.Tensor(std_correction_21, 1e-06)
        div_tensor_32 = torch.ops.aten.div.Tensor(mul_tensor_21, add_tensor_65)
        add_tensor_66 = torch.ops.aten.add.Tensor(div_tensor_32, primals_35);  div_tensor_32 = primals_35 = None
        view_default_183 = torch.ops.aten.view.default(add_tensor_66, [2048, 768]);  add_tensor_66 = None
        t_default_64 = torch.ops.aten.t.default(primals_21);  primals_21 = None
        addmm_default_64 = torch.ops.aten.addmm.default(primals_20, view_default_183, t_default_64);  primals_20 = None
        view_default_184 = torch.ops.aten.view.default(addmm_default_64, [16, 128, 3072]);  addmm_default_64 = None
        gelu_default_10 = torch.ops.aten.gelu.default(view_default_184)
        view_default_185 = torch.ops.aten.view.default(gelu_default_10, [2048, 3072]);  gelu_default_10 = None
        t_default_65 = torch.ops.aten.t.default(primals_23);  primals_23 = None
        addmm_default_65 = torch.ops.aten.addmm.default(primals_22, view_default_185, t_default_65);  primals_22 = None
        view_default_186 = torch.ops.aten.view.default(addmm_default_65, [16, 128, 768]);  addmm_default_65 = None
        add_tensor_67 = torch.ops.aten.add.Tensor(add_tensor_64, view_default_186);  view_default_186 = None
        mean_dim_22 = torch.ops.aten.mean.dim(add_tensor_67, [-1], True)
        std_correction_22 = torch.ops.aten.std.correction(add_tensor_67, [-1], correction = 1, keepdim = True)
        sub_tensor_22 = torch.ops.aten.sub.Tensor(add_tensor_67, mean_dim_22);  mean_dim_22 = None
        mul_tensor_22 = torch.ops.aten.mul.Tensor(primals_40, sub_tensor_22)
        add_tensor_68 = torch.ops.aten.add.Tensor(std_correction_22, 1e-06)
        div_tensor_33 = torch.ops.aten.div.Tensor(mul_tensor_22, add_tensor_68)
        add_tensor_69 = torch.ops.aten.add.Tensor(div_tensor_33, primals_41);  div_tensor_33 = primals_41 = None
        view_default_187 = torch.ops.aten.view.default(add_tensor_69, [2048, 768])
        t_default_66 = torch.ops.aten.t.default(primals_43);  primals_43 = None
        addmm_default_66 = torch.ops.aten.addmm.default(primals_42, view_default_187, t_default_66);  primals_42 = None
        view_default_188 = torch.ops.aten.view.default(addmm_default_66, [16, 128, 768]);  addmm_default_66 = None
        view_default_189 = torch.ops.aten.view.default(view_default_188, [16, -1, 12, 64]);  view_default_188 = None
        transpose_int_55 = torch.ops.aten.transpose.int(view_default_189, 1, 2);  view_default_189 = None
        view_default_190 = torch.ops.aten.view.default(add_tensor_69, [2048, 768])
        t_default_67 = torch.ops.aten.t.default(primals_45);  primals_45 = None
        addmm_default_67 = torch.ops.aten.addmm.default(primals_44, view_default_190, t_default_67);  primals_44 = None
        view_default_191 = torch.ops.aten.view.default(addmm_default_67, [16, 128, 768]);  addmm_default_67 = None
        view_default_192 = torch.ops.aten.view.default(view_default_191, [16, -1, 12, 64]);  view_default_191 = None
        transpose_int_56 = torch.ops.aten.transpose.int(view_default_192, 1, 2);  view_default_192 = None
        view_default_193 = torch.ops.aten.view.default(add_tensor_69, [2048, 768]);  add_tensor_69 = None
        t_default_68 = torch.ops.aten.t.default(primals_47);  primals_47 = None
        addmm_default_68 = torch.ops.aten.addmm.default(primals_46, view_default_193, t_default_68);  primals_46 = None
        view_default_194 = torch.ops.aten.view.default(addmm_default_68, [16, 128, 768]);  addmm_default_68 = None
        view_default_195 = torch.ops.aten.view.default(view_default_194, [16, -1, 12, 64]);  view_default_194 = None
        transpose_int_57 = torch.ops.aten.transpose.int(view_default_195, 1, 2);  view_default_195 = None
        transpose_int_58 = torch.ops.aten.transpose.int(transpose_int_56, -2, -1);  transpose_int_56 = None
        expand_default_44 = torch.ops.aten.expand.default(transpose_int_55, [16, 12, 128, 64]);  transpose_int_55 = None
        clone_default_44 = torch.ops.aten.clone.default(expand_default_44, memory_format = torch.contiguous_format);  expand_default_44 = None
        _unsafe_view_default_55 = torch.ops.aten._unsafe_view.default(clone_default_44, [192, 128, 64]);  clone_default_44 = None
        expand_default_45 = torch.ops.aten.expand.default(transpose_int_58, [16, 12, 64, 128]);  transpose_int_58 = None
        clone_default_45 = torch.ops.aten.clone.default(expand_default_45, memory_format = torch.contiguous_format);  expand_default_45 = None
        _unsafe_view_default_56 = torch.ops.aten._unsafe_view.default(clone_default_45, [192, 64, 128]);  clone_default_45 = None
        bmm_default_22 = torch.ops.aten.bmm.default(_unsafe_view_default_55, _unsafe_view_default_56)
        _unsafe_view_default_57 = torch.ops.aten._unsafe_view.default(bmm_default_22, [16, 12, 128, 128]);  bmm_default_22 = None
        div_tensor_34 = torch.ops.aten.div.Tensor(_unsafe_view_default_57, 8.0);  _unsafe_view_default_57 = None
        eq_scalar_11 = torch.ops.aten.eq.Scalar(unsqueeze_default_1, 0)
        where_scalar_self_11 = torch.ops.aten.where.ScalarSelf(eq_scalar_11, -1000000000.0, div_tensor_34);  div_tensor_34 = None
        _softmax_default_11 = torch.ops.aten._softmax.default(where_scalar_self_11, -1, False);  where_scalar_self_11 = None
        expand_default_46 = torch.ops.aten.expand.default(_softmax_default_11, [16, 12, 128, 128])
        view_default_196 = torch.ops.aten.view.default(expand_default_46, [192, 128, 128]);  expand_default_46 = None
        expand_default_47 = torch.ops.aten.expand.default(transpose_int_57, [16, 12, 128, 64]);  transpose_int_57 = None
        clone_default_46 = torch.ops.aten.clone.default(expand_default_47, memory_format = torch.contiguous_format);  expand_default_47 = None
        _unsafe_view_default_58 = torch.ops.aten._unsafe_view.default(clone_default_46, [192, 128, 64]);  clone_default_46 = None
        bmm_default_23 = torch.ops.aten.bmm.default(view_default_196, _unsafe_view_default_58)
        _unsafe_view_default_59 = torch.ops.aten._unsafe_view.default(bmm_default_23, [16, 12, 128, 64]);  bmm_default_23 = None
        transpose_int_59 = torch.ops.aten.transpose.int(_unsafe_view_default_59, 1, 2);  _unsafe_view_default_59 = None
        clone_default_47 = torch.ops.aten.clone.default(transpose_int_59, memory_format = torch.contiguous_format);  transpose_int_59 = None
        view_default_197 = torch.ops.aten.view.default(clone_default_47, [16, -1, 768]);  clone_default_47 = None
        view_default_198 = torch.ops.aten.view.default(view_default_197, [2048, 768]);  view_default_197 = None
        t_default_69 = torch.ops.aten.t.default(primals_49);  primals_49 = None
        addmm_default_69 = torch.ops.aten.addmm.default(primals_48, view_default_198, t_default_69);  primals_48 = None
        view_default_199 = torch.ops.aten.view.default(addmm_default_69, [16, 128, 768]);  addmm_default_69 = None
        add_tensor_70 = torch.ops.aten.add.Tensor(add_tensor_67, view_default_199);  view_default_199 = None
        mean_dim_23 = torch.ops.aten.mean.dim(add_tensor_70, [-1], True)
        std_correction_23 = torch.ops.aten.std.correction(add_tensor_70, [-1], correction = 1, keepdim = True)
        sub_tensor_23 = torch.ops.aten.sub.Tensor(add_tensor_70, mean_dim_23);  mean_dim_23 = None
        mul_tensor_23 = torch.ops.aten.mul.Tensor(primals_50, sub_tensor_23)
        add_tensor_71 = torch.ops.aten.add.Tensor(std_correction_23, 1e-06)
        div_tensor_35 = torch.ops.aten.div.Tensor(mul_tensor_23, add_tensor_71)
        add_tensor_72 = torch.ops.aten.add.Tensor(div_tensor_35, primals_51);  div_tensor_35 = primals_51 = None
        view_default_200 = torch.ops.aten.view.default(add_tensor_72, [2048, 768]);  add_tensor_72 = None
        t_default_70 = torch.ops.aten.t.default(primals_37);  primals_37 = None
        addmm_default_70 = torch.ops.aten.addmm.default(primals_36, view_default_200, t_default_70);  primals_36 = None
        view_default_201 = torch.ops.aten.view.default(addmm_default_70, [16, 128, 3072]);  addmm_default_70 = None
        gelu_default_11 = torch.ops.aten.gelu.default(view_default_201)
        view_default_202 = torch.ops.aten.view.default(gelu_default_11, [2048, 3072]);  gelu_default_11 = None
        t_default_71 = torch.ops.aten.t.default(primals_39);  primals_39 = None
        addmm_default_71 = torch.ops.aten.addmm.default(primals_38, view_default_202, t_default_71);  primals_38 = None
        view_default_203 = torch.ops.aten.view.default(addmm_default_71, [16, 128, 768]);  addmm_default_71 = None
        add_tensor_73 = torch.ops.aten.add.Tensor(add_tensor_70, view_default_203);  view_default_203 = None
        return [add_tensor_73, unsqueeze_default_1, eq_scalar_5, t_default_30, _unsafe_view_default_6, _softmax_default_5, _unsafe_view_default_8, primals_18, primals_8, _unsafe_view_default_30, primals_104, view_default_85, _unsafe_view_default_5, view_default_139, t_default_32, t_default_46, view_default_26, view_default_91, view_default_88, t_default_9, t_default_31, sub_tensor_16, view_default_132, view_default_28, view_default_198, add_tensor_47, view_default_185, primals_56, primals_130, t_default_43, mul_tensor_11, t_default_62, t_default_68, view_default_15, view_default_99, _unsafe_view_default_53, add_tensor_8, t_default_42, primals_50, add_tensor_49, t_default_63, view_default_119, view_default_14, primals_136, mul_tensor_15, t_default_6, t_default_45, mul_tensor_21, sub_tensor_15, view_default_196, add_tensor_44, add_tensor_65, t_default_34, view_default_13, eq_scalar_10, t_default_4, view_default_17, add_tensor_5, mul_tensor_14, view_default_125, primals_152, t_default_35, t_default_41, sub_tensor_2, std_correction_2, add_tensor_35, view_default_98, _unsafe_view_default_35, _softmax_default_10, std_correction_21, t_default_61, std_correction_14, eq_scalar_7, add_tensor_64, primals_146, sub_tensor_1, t_default_5, std_correction_15, sub_tensor_14, std_correction_11, view_default_181, add_tensor_37, _unsafe_view_default_36, mul_tensor_2, add_tensor_67, view_default_100, add_tensor_7, t_default_33, sub_tensor_11, mul_tensor_20, sub_tensor_17, std_correction_4, add_tensor_53, add_tensor_62, t_default_71, mul_tensor_4, view_default_150, t_default_65, primals_197, sub_tensor_20, _unsafe_view_default_56, std_correction_17, t_default_69, mul_tensor_23, mul_tensor_17, add_tensor_56, primals_196, t_default_51, std_correction_18, sub_tensor_18, view_default_170, add_tensor_14, t_default_52, t_default_57, std_correction_23, t_default_53, add_tensor_50, view_default_149, t_default_60, sub_tensor_4, mul_tensor_18, primals_194, view_default_179, std_correction_20, _softmax_default_3, t_default_11, view_default_54, view_default_32, add_tensor_70, eq_scalar_3, _unsafe_view_default_31, _softmax_default_2, t_default_19, view_default_57, view_default_40, eq_scalar_2, t_default_13, sub_tensor_23, view_default_31, t_default_12, view_default_37, view_default_34, add_tensor_13, t_default_18, view_default_187, view_default_43, sub_tensor_10, mul_tensor_5, t_default_22, t_default_15, _unsafe_view_default_15, _unsafe_view_default_25, eq_scalar_11, add_tensor_71, view_default_81, view_default_200, t_default_70, view_default_94, _unsafe_view_default_13, add_tensor_22, primals_184, add_tensor_23, t_default_29, add_tensor_16, view_default_102, view_default_49, view_default_176, _unsafe_view_default_33, std_correction_6, _unsafe_view_default_28, t_default_67, add_tensor_32, std_correction_5, view_default_47, mul_tensor_10, _unsafe_view_default_10, mul_tensor_6, _softmax_default_6, add_tensor_43, primals_178, add_tensor_34, view_default_105, sub_tensor_13, std_correction_10, _unsafe_view_default_26, sub_tensor_22, sub_tensor_7, t_default_20, view_default_159, _unsafe_view_default_11, view_default_60, sub_tensor_5, t_default_37, add_tensor_17, view_default_108, view_default_82, mul_tensor_16, t_default_39, view_default_133, view_default_51, mul_tensor_13, std_correction_7, primals_98, t_default_17, add_tensor_31, view_default_96, add_tensor_40, t_default_47, t_default_16, std_correction_16, _unsafe_view_default_16, _unsafe_view_default_58, _softmax_default_11, view_default_113, view_default_48, t_default_14, t_default_38, add_tensor_19, mul_tensor_7, eq_scalar_6, view_default_117, view_default_45, add_tensor_20, t_default_28, view_default_64, view_default_111, sub_tensor_6, view_default_83, t_default_36, view_default_201, _unsafe_view_default_1, primals_40, _unsafe_view_default_23, view_default_9, add_tensor_28, _unsafe_view_default_3, t_default_54, primals_168, primals_114, t_default_26, view_default_173, _unsafe_view_default, sub_tensor_21, view_default_77, primals_120, view_default_153, mul_tensor_3, _unsafe_view_default_21, view_default_79, _unsafe_view_default_46, primals_88, t_default_55, primals_82, add_tensor_4, _unsafe_view_default_45, primals_162, add_tensor_61, add_tensor_68, eq_scalar_9, std_correction_22, _unsafe_view_default_20, _softmax_default_9, view_default_11, add_tensor_41, std_correction_12, primals_34, primals_66, mul_tensor_1, t_default_50, primals_72, view_default_151, add_tensor_55, view_default_30, _unsafe_view_default_43, _softmax_default_7, t_default_40, mul_tensor_12, view_default_156, t_default_58, sub_tensor_12, sub_tensor_3, view_default_122, std_correction_1, view_default_145, _unsafe_view_default_40, _unsafe_view_default_51, view_default_116, t_default_49, view_default_167, add_tensor_11, add_tensor_52, view_default_166, view_default_147, t_default_66, eq_scalar_8, t_default_10, std_correction_13, std_correction_3, add_tensor_38, view_default_115, t_default_3, primals_24, view_default_202, view_default_62, t_default_64, view_default_68, t_default_27, _unsafe_view_default_50, t_default_48, mul_tensor_22, t_default_7, view_default_74, view_default_190, eq_scalar_1, mul_tensor_8, add_tensor_1, sub_tensor_8, view_default_162, view_default_193, _unsafe_view_default_55, t_default_44, std_correction, std_correction_19, view_default_3, mul_tensor_9, _softmax_default, eq_scalar_4, sub_tensor, t_default_21, t_default_24, t_default_8, eq_scalar, add_tensor_59, t_default_25, add_tensor_2, _softmax_default_1, add_tensor_58, view_default_65, t_default_1, _unsafe_view_default_41, view_default_134, view_default_136, t_default_23, view_default_184, sub_tensor_9, view_default_71, view_default_20, sub_tensor_19, add_tensor_10, _softmax_default_4, add_tensor_25, add_tensor_29, _unsafe_view_default_38, view_default_168, t_default_59, mul_tensor, add_tensor_46, view_default_183, add_tensor_26, t_default_56, view_default_23, _unsafe_view_default_18, view_default, std_correction_8, view_default_142, view_default_66, view_default_128, view_default_6, _unsafe_view_default_48, t_default, _softmax_default_8, t_default_2, view_default_164, view_default_130, std_correction_9, mul_tensor_19]
        
