
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/BERT_pytorch/BERT_pytorch_backward_0/state_dict.pt'))

    
    
    def forward(self, eq_scalar_5, t_default_30, _unsafe_view_default_6, _softmax_default_5, _unsafe_view_default_8, primals_18, primals_8, _unsafe_view_default_30, primals_104, view_default_85, _unsafe_view_default_5, view_default_139, t_default_32, t_default_46, view_default_26, view_default_91, view_default_88, t_default_9, t_default_31, sub_tensor_16, view_default_132, view_default_28, view_default_198, add_tensor_47, view_default_185, primals_56, primals_130, t_default_43, mul_tensor_11, t_default_62, t_default_68, view_default_15, view_default_99, _unsafe_view_default_53, add_tensor_8, t_default_42, primals_50, add_tensor_49, t_default_63, view_default_119, view_default_14, primals_136, mul_tensor_15, t_default_6, t_default_45, mul_tensor_21, sub_tensor_15, view_default_196, add_tensor_44, add_tensor_65, t_default_34, view_default_13, eq_scalar_10, t_default_4, view_default_17, add_tensor_5, mul_tensor_14, view_default_125, primals_152, t_default_35, t_default_41, sub_tensor_2, std_correction_2, add_tensor_35, view_default_98, _unsafe_view_default_35, _softmax_default_10, std_correction_21, t_default_61, std_correction_14, eq_scalar_7, add_tensor_64, primals_146, sub_tensor_1, t_default_5, std_correction_15, sub_tensor_14, std_correction_11, view_default_181, add_tensor_37, _unsafe_view_default_36, mul_tensor_2, add_tensor_67, view_default_100, add_tensor_7, t_default_33, sub_tensor_11, mul_tensor_20, sub_tensor_17, std_correction_4, add_tensor_53, add_tensor_62, t_default_71, mul_tensor_4, view_default_150, t_default_65, primals_197, sub_tensor_20, _unsafe_view_default_56, std_correction_17, t_default_69, mul_tensor_23, mul_tensor_17, add_tensor_56, primals_196, t_default_51, std_correction_18, sub_tensor_18, view_default_170, add_tensor_14, t_default_52, t_default_57, std_correction_23, t_default_53, add_tensor_50, view_default_149, t_default_60, sub_tensor_4, mul_tensor_18, primals_194, view_default_179, std_correction_20, _softmax_default_3, t_default_11, view_default_54, view_default_32, add_tensor_70, eq_scalar_3, _unsafe_view_default_31, _softmax_default_2, t_default_19, view_default_57, view_default_40, eq_scalar_2, t_default_13, sub_tensor_23, view_default_31, t_default_12, view_default_37, view_default_34, add_tensor_13, t_default_18, view_default_187, view_default_43, sub_tensor_10, mul_tensor_5, t_default_22, t_default_15, _unsafe_view_default_15, _unsafe_view_default_25, eq_scalar_11, add_tensor_71, view_default_81, view_default_200, t_default_70, view_default_94, _unsafe_view_default_13, add_tensor_22, primals_184, add_tensor_23, t_default_29, add_tensor_16, view_default_102, view_default_49, view_default_176, _unsafe_view_default_33, std_correction_6, _unsafe_view_default_28, t_default_67, add_tensor_32, std_correction_5, view_default_47, mul_tensor_10, _unsafe_view_default_10, mul_tensor_6, _softmax_default_6, add_tensor_43, primals_178, add_tensor_34, view_default_105, sub_tensor_13, std_correction_10, _unsafe_view_default_26, sub_tensor_22, sub_tensor_7, t_default_20, view_default_159, _unsafe_view_default_11, view_default_60, sub_tensor_5, t_default_37, add_tensor_17, view_default_108, view_default_82, mul_tensor_16, t_default_39, view_default_133, view_default_51, mul_tensor_13, std_correction_7, primals_98, t_default_17, add_tensor_31, view_default_96, add_tensor_40, t_default_47, t_default_16, std_correction_16, _unsafe_view_default_16, _unsafe_view_default_58, _softmax_default_11, view_default_113, view_default_48, t_default_14, t_default_38, add_tensor_19, mul_tensor_7, eq_scalar_6, view_default_117, view_default_45, add_tensor_20, t_default_28, view_default_64, view_default_111, sub_tensor_6, view_default_83, t_default_36, view_default_201, _unsafe_view_default_1, primals_40, _unsafe_view_default_23, view_default_9, add_tensor_28, _unsafe_view_default_3, t_default_54, primals_168, primals_114, t_default_26, view_default_173, _unsafe_view_default, sub_tensor_21, view_default_77, primals_120, view_default_153, mul_tensor_3, _unsafe_view_default_21, view_default_79, _unsafe_view_default_46, primals_88, t_default_55, primals_82, add_tensor_4, _unsafe_view_default_45, primals_162, add_tensor_61, add_tensor_68, eq_scalar_9, std_correction_22, _unsafe_view_default_20, _softmax_default_9, view_default_11, add_tensor_41, std_correction_12, primals_34, primals_66, mul_tensor_1, t_default_50, primals_72, view_default_151, add_tensor_55, view_default_30, _unsafe_view_default_43, _softmax_default_7, t_default_40, mul_tensor_12, view_default_156, t_default_58, sub_tensor_12, sub_tensor_3, view_default_122, std_correction_1, view_default_145, _unsafe_view_default_40, _unsafe_view_default_51, view_default_116, t_default_49, view_default_167, add_tensor_11, add_tensor_52, view_default_166, view_default_147, t_default_66, eq_scalar_8, t_default_10, std_correction_13, std_correction_3, add_tensor_38, view_default_115, t_default_3, primals_24, view_default_202, view_default_62, t_default_64, view_default_68, t_default_27, _unsafe_view_default_50, t_default_48, mul_tensor_22, t_default_7, view_default_74, view_default_190, eq_scalar_1, mul_tensor_8, add_tensor_1, sub_tensor_8, view_default_162, view_default_193, _unsafe_view_default_55, t_default_44, std_correction, std_correction_19, view_default_3, mul_tensor_9, _softmax_default, eq_scalar_4, sub_tensor, t_default_21, t_default_24, t_default_8, eq_scalar, add_tensor_59, t_default_25, add_tensor_2, _softmax_default_1, add_tensor_58, view_default_65, t_default_1, _unsafe_view_default_41, view_default_134, view_default_136, t_default_23, view_default_184, sub_tensor_9, view_default_71, view_default_20, sub_tensor_19, add_tensor_10, _softmax_default_4, add_tensor_25, add_tensor_29, _unsafe_view_default_38, view_default_168, t_default_59, mul_tensor, add_tensor_46, view_default_183, add_tensor_26, t_default_56, view_default_23, _unsafe_view_default_18, view_default, std_correction_8, view_default_142, view_default_66, view_default_128, view_default_6, _unsafe_view_default_48, t_default, _softmax_default_8, t_default_2, view_default_164, view_default_130, std_correction_9, mul_tensor_19, tangents_1, tangents_2):
        view_default_204 = torch.ops.aten.view.default(tangents_1, [2048, 768])
        t_default_72 = torch.ops.aten.t.default(t_default_71);  t_default_71 = None
        mm_default = torch.ops.aten.mm.default(view_default_204, t_default_72);  t_default_72 = None
        t_default_73 = torch.ops.aten.t.default(view_default_204)
        mm_default_1 = torch.ops.aten.mm.default(t_default_73, view_default_202);  t_default_73 = view_default_202 = None
        t_default_74 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(view_default_204, [0], True);  view_default_204 = None
        view_default_205 = torch.ops.aten.view.default(sum_dim_int_list, [768]);  sum_dim_int_list = None
        t_default_75 = torch.ops.aten.t.default(t_default_74);  t_default_74 = None
        view_default_206 = torch.ops.aten.view.default(mm_default, [16, 128, 3072]);  mm_default = None
        to_dtype = torch.ops.aten.to.dtype(view_default_206, torch.float32);  view_default_206 = None
        to_dtype_1 = torch.ops.aten.to.dtype(view_default_201, torch.float32);  view_default_201 = None
        mul_tensor_24 = torch.ops.aten.mul.Tensor(to_dtype_1, 0.7071067811865476)
        erf_default = torch.ops.aten.erf.default(mul_tensor_24);  mul_tensor_24 = None
        add_tensor_74 = torch.ops.aten.add.Tensor(erf_default, 1);  erf_default = None
        mul_tensor_25 = torch.ops.aten.mul.Tensor(add_tensor_74, 0.5);  add_tensor_74 = None
        mul_tensor_26 = torch.ops.aten.mul.Tensor(to_dtype_1, to_dtype_1)
        mul_tensor_27 = torch.ops.aten.mul.Tensor(mul_tensor_26, -0.5);  mul_tensor_26 = None
        exp_default = torch.ops.aten.exp.default(mul_tensor_27);  mul_tensor_27 = None
        mul_tensor_28 = torch.ops.aten.mul.Tensor(exp_default, 0.3989422804014327);  exp_default = None
        mul_tensor_29 = torch.ops.aten.mul.Tensor(to_dtype_1, mul_tensor_28);  to_dtype_1 = mul_tensor_28 = None
        add_tensor_75 = torch.ops.aten.add.Tensor(mul_tensor_25, mul_tensor_29);  mul_tensor_25 = mul_tensor_29 = None
        mul_tensor_30 = torch.ops.aten.mul.Tensor(to_dtype, add_tensor_75);  to_dtype = add_tensor_75 = None
        to_dtype_2 = torch.ops.aten.to.dtype(mul_tensor_30, torch.float32);  mul_tensor_30 = None
        view_default_207 = torch.ops.aten.view.default(to_dtype_2, [2048, 3072]);  to_dtype_2 = None
        t_default_76 = torch.ops.aten.t.default(t_default_70);  t_default_70 = None
        mm_default_2 = torch.ops.aten.mm.default(view_default_207, t_default_76);  t_default_76 = None
        t_default_77 = torch.ops.aten.t.default(view_default_207)
        mm_default_3 = torch.ops.aten.mm.default(t_default_77, view_default_200);  t_default_77 = view_default_200 = None
        t_default_78 = torch.ops.aten.t.default(mm_default_3);  mm_default_3 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(view_default_207, [0], True);  view_default_207 = None
        view_default_208 = torch.ops.aten.view.default(sum_dim_int_list_1, [3072]);  sum_dim_int_list_1 = None
        t_default_79 = torch.ops.aten.t.default(t_default_78);  t_default_78 = None
        view_default_209 = torch.ops.aten.view.default(mm_default_2, [16, 128, 768]);  mm_default_2 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(view_default_209, [0, 1], True)
        view_default_210 = torch.ops.aten.view.default(sum_dim_int_list_2, [768]);  sum_dim_int_list_2 = None
        neg_default = torch.ops.aten.neg.default(view_default_209)
        div_tensor_36 = torch.ops.aten.div.Tensor(mul_tensor_23, add_tensor_71);  mul_tensor_23 = None
        div_tensor_37 = torch.ops.aten.div.Tensor(div_tensor_36, add_tensor_71);  div_tensor_36 = None
        mul_tensor_31 = torch.ops.aten.mul.Tensor(neg_default, div_tensor_37);  neg_default = div_tensor_37 = None
        div_tensor_38 = torch.ops.aten.div.Tensor(view_default_209, add_tensor_71);  view_default_209 = add_tensor_71 = None
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(mul_tensor_31, [2], True);  mul_tensor_31 = None
        mul_tensor_32 = torch.ops.aten.mul.Tensor(div_tensor_38, primals_50);  primals_50 = None
        mul_tensor_33 = torch.ops.aten.mul.Tensor(div_tensor_38, sub_tensor_23);  div_tensor_38 = sub_tensor_23 = None
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(mul_tensor_33, [0, 1], True);  mul_tensor_33 = None
        view_default_211 = torch.ops.aten.view.default(sum_dim_int_list_4, [768]);  sum_dim_int_list_4 = None
        neg_default_1 = torch.ops.aten.neg.default(mul_tensor_32)
        sum_dim_int_list_5 = torch.ops.aten.sum.dim_IntList(neg_default_1, [2], True);  neg_default_1 = None
        add_tensor_76 = torch.ops.aten.add.Tensor(tangents_1, mul_tensor_32);  tangents_1 = mul_tensor_32 = None
        mul_scalar = torch.ops.aten.mul.Scalar(std_correction_23, 2)
        div_tensor_39 = torch.ops.aten.div.Tensor(sum_dim_int_list_3, mul_scalar);  sum_dim_int_list_3 = mul_scalar = None
        eq_scalar_12 = torch.ops.aten.eq.Scalar(std_correction_23, 0);  std_correction_23 = None
        masked_fill__scalar = torch.ops.aten.masked_fill_.Scalar(div_tensor_39, eq_scalar_12, 0);  div_tensor_39 = eq_scalar_12 = None
        mul_scalar_1 = torch.ops.aten.mul.Scalar(masked_fill__scalar, 0.002607561929595828);  masked_fill__scalar = None
        mean_dim_24 = torch.ops.aten.mean.dim(add_tensor_70, [-1], True)
        sub_tensor_24 = torch.ops.aten.sub.Tensor(add_tensor_70, mean_dim_24);  add_tensor_70 = mean_dim_24 = None
        mul_tensor_34 = torch.ops.aten.mul.Tensor(mul_scalar_1, sub_tensor_24);  mul_scalar_1 = sub_tensor_24 = None
        add_tensor_77 = torch.ops.aten.add.Tensor(add_tensor_76, mul_tensor_34);  add_tensor_76 = mul_tensor_34 = None
        expand_default_48 = torch.ops.aten.expand.default(sum_dim_int_list_5, [16, 128, 768]);  sum_dim_int_list_5 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default_48, 768);  expand_default_48 = None
        add_tensor_78 = torch.ops.aten.add.Tensor(add_tensor_77, div_scalar);  add_tensor_77 = div_scalar = None
        view_default_212 = torch.ops.aten.view.default(add_tensor_78, [2048, 768])
        t_default_80 = torch.ops.aten.t.default(t_default_69);  t_default_69 = None
        mm_default_4 = torch.ops.aten.mm.default(view_default_212, t_default_80);  t_default_80 = None
        t_default_81 = torch.ops.aten.t.default(view_default_212)
        mm_default_5 = torch.ops.aten.mm.default(t_default_81, view_default_198);  t_default_81 = view_default_198 = None
        t_default_82 = torch.ops.aten.t.default(mm_default_5);  mm_default_5 = None
        sum_dim_int_list_6 = torch.ops.aten.sum.dim_IntList(view_default_212, [0], True);  view_default_212 = None
        view_default_213 = torch.ops.aten.view.default(sum_dim_int_list_6, [768]);  sum_dim_int_list_6 = None
        t_default_83 = torch.ops.aten.t.default(t_default_82);  t_default_82 = None
        view_default_214 = torch.ops.aten.view.default(mm_default_4, [16, 128, 768]);  mm_default_4 = None
        view_default_215 = torch.ops.aten.view.default(view_default_214, [16, 128, 12, 64]);  view_default_214 = None
        transpose_int_60 = torch.ops.aten.transpose.int(view_default_215, 1, 2);  view_default_215 = None
        clone_default_48 = torch.ops.aten.clone.default(transpose_int_60, memory_format = torch.contiguous_format);  transpose_int_60 = None
        _unsafe_view_default_60 = torch.ops.aten._unsafe_view.default(clone_default_48, [192, 128, 64]);  clone_default_48 = None
        transpose_int_61 = torch.ops.aten.transpose.int(view_default_196, 1, 2);  view_default_196 = None
        bmm_default_24 = torch.ops.aten.bmm.default(transpose_int_61, _unsafe_view_default_60);  transpose_int_61 = None
        transpose_int_62 = torch.ops.aten.transpose.int(_unsafe_view_default_58, 1, 2);  _unsafe_view_default_58 = None
        bmm_default_25 = torch.ops.aten.bmm.default(_unsafe_view_default_60, transpose_int_62);  _unsafe_view_default_60 = transpose_int_62 = None
        view_default_216 = torch.ops.aten.view.default(bmm_default_24, [16, 12, 128, 64]);  bmm_default_24 = None
        view_default_217 = torch.ops.aten.view.default(bmm_default_25, [16, 12, 128, 128]);  bmm_default_25 = None
        _softmax_backward_data_default = torch.ops.aten._softmax_backward_data.default(view_default_217, _softmax_default_11, -1, torch.float32);  view_default_217 = _softmax_default_11 = None
        where_scalar_self_12 = torch.ops.aten.where.ScalarSelf(eq_scalar_11, 0.0, _softmax_backward_data_default);  eq_scalar_11 = _softmax_backward_data_default = None
        div_tensor_40 = torch.ops.aten.div.Tensor(where_scalar_self_12, 8.0);  where_scalar_self_12 = None
        view_default_218 = torch.ops.aten.view.default(div_tensor_40, [192, 128, 128]);  div_tensor_40 = None
        transpose_int_63 = torch.ops.aten.transpose.int(_unsafe_view_default_55, 1, 2);  _unsafe_view_default_55 = None
        bmm_default_26 = torch.ops.aten.bmm.default(transpose_int_63, view_default_218);  transpose_int_63 = None
        transpose_int_64 = torch.ops.aten.transpose.int(_unsafe_view_default_56, 1, 2);  _unsafe_view_default_56 = None
        bmm_default_27 = torch.ops.aten.bmm.default(view_default_218, transpose_int_64);  view_default_218 = transpose_int_64 = None
        view_default_219 = torch.ops.aten.view.default(bmm_default_26, [16, 12, 64, 128]);  bmm_default_26 = None
        view_default_220 = torch.ops.aten.view.default(bmm_default_27, [16, 12, 128, 64]);  bmm_default_27 = None
        transpose_int_65 = torch.ops.aten.transpose.int(view_default_219, -2, -1);  view_default_219 = None
        transpose_int_66 = torch.ops.aten.transpose.int(view_default_216, 1, 2);  view_default_216 = None
        clone_default_49 = torch.ops.aten.clone.default(transpose_int_66, memory_format = torch.contiguous_format);  transpose_int_66 = None
        _unsafe_view_default_61 = torch.ops.aten._unsafe_view.default(clone_default_49, [16, 128, 768]);  clone_default_49 = None
        view_default_221 = torch.ops.aten.view.default(_unsafe_view_default_61, [2048, 768]);  _unsafe_view_default_61 = None
        t_default_84 = torch.ops.aten.t.default(t_default_68);  t_default_68 = None
        mm_default_6 = torch.ops.aten.mm.default(view_default_221, t_default_84);  t_default_84 = None
        t_default_85 = torch.ops.aten.t.default(view_default_221)
        mm_default_7 = torch.ops.aten.mm.default(t_default_85, view_default_193);  t_default_85 = view_default_193 = None
        t_default_86 = torch.ops.aten.t.default(mm_default_7);  mm_default_7 = None
        sum_dim_int_list_7 = torch.ops.aten.sum.dim_IntList(view_default_221, [0], True);  view_default_221 = None
        view_default_222 = torch.ops.aten.view.default(sum_dim_int_list_7, [768]);  sum_dim_int_list_7 = None
        t_default_87 = torch.ops.aten.t.default(t_default_86);  t_default_86 = None
        view_default_223 = torch.ops.aten.view.default(mm_default_6, [16, 128, 768]);  mm_default_6 = None
        transpose_int_67 = torch.ops.aten.transpose.int(transpose_int_65, 1, 2);  transpose_int_65 = None
        view_default_224 = torch.ops.aten.view.default(transpose_int_67, [16, 128, 768]);  transpose_int_67 = None
        clone_default_50 = torch.ops.aten.clone.default(view_default_224, memory_format = torch.contiguous_format);  view_default_224 = None
        _unsafe_view_default_62 = torch.ops.aten._unsafe_view.default(clone_default_50, [2048, 768]);  clone_default_50 = None
        t_default_88 = torch.ops.aten.t.default(t_default_67);  t_default_67 = None
        mm_default_8 = torch.ops.aten.mm.default(_unsafe_view_default_62, t_default_88);  t_default_88 = None
        t_default_89 = torch.ops.aten.t.default(_unsafe_view_default_62)
        mm_default_9 = torch.ops.aten.mm.default(t_default_89, view_default_190);  t_default_89 = view_default_190 = None
        t_default_90 = torch.ops.aten.t.default(mm_default_9);  mm_default_9 = None
        sum_dim_int_list_8 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_62, [0], True);  _unsafe_view_default_62 = None
        view_default_225 = torch.ops.aten.view.default(sum_dim_int_list_8, [768]);  sum_dim_int_list_8 = None
        t_default_91 = torch.ops.aten.t.default(t_default_90);  t_default_90 = None
        view_default_226 = torch.ops.aten.view.default(mm_default_8, [16, 128, 768]);  mm_default_8 = None
        add_tensor_79 = torch.ops.aten.add.Tensor(view_default_223, view_default_226);  view_default_223 = view_default_226 = None
        transpose_int_68 = torch.ops.aten.transpose.int(view_default_220, 1, 2);  view_default_220 = None
        clone_default_51 = torch.ops.aten.clone.default(transpose_int_68, memory_format = torch.contiguous_format);  transpose_int_68 = None
        _unsafe_view_default_63 = torch.ops.aten._unsafe_view.default(clone_default_51, [16, 128, 768]);  clone_default_51 = None
        view_default_227 = torch.ops.aten.view.default(_unsafe_view_default_63, [2048, 768]);  _unsafe_view_default_63 = None
        t_default_92 = torch.ops.aten.t.default(t_default_66);  t_default_66 = None
        mm_default_10 = torch.ops.aten.mm.default(view_default_227, t_default_92);  t_default_92 = None
        t_default_93 = torch.ops.aten.t.default(view_default_227)
        mm_default_11 = torch.ops.aten.mm.default(t_default_93, view_default_187);  t_default_93 = view_default_187 = None
        t_default_94 = torch.ops.aten.t.default(mm_default_11);  mm_default_11 = None
        sum_dim_int_list_9 = torch.ops.aten.sum.dim_IntList(view_default_227, [0], True);  view_default_227 = None
        view_default_228 = torch.ops.aten.view.default(sum_dim_int_list_9, [768]);  sum_dim_int_list_9 = None
        t_default_95 = torch.ops.aten.t.default(t_default_94);  t_default_94 = None
        view_default_229 = torch.ops.aten.view.default(mm_default_10, [16, 128, 768]);  mm_default_10 = None
        add_tensor_80 = torch.ops.aten.add.Tensor(add_tensor_79, view_default_229);  add_tensor_79 = view_default_229 = None
        sum_dim_int_list_10 = torch.ops.aten.sum.dim_IntList(add_tensor_80, [0, 1], True)
        view_default_230 = torch.ops.aten.view.default(sum_dim_int_list_10, [768]);  sum_dim_int_list_10 = None
        neg_default_2 = torch.ops.aten.neg.default(add_tensor_80)
        div_tensor_41 = torch.ops.aten.div.Tensor(mul_tensor_22, add_tensor_68);  mul_tensor_22 = None
        div_tensor_42 = torch.ops.aten.div.Tensor(div_tensor_41, add_tensor_68);  div_tensor_41 = None
        mul_tensor_35 = torch.ops.aten.mul.Tensor(neg_default_2, div_tensor_42);  neg_default_2 = div_tensor_42 = None
        div_tensor_43 = torch.ops.aten.div.Tensor(add_tensor_80, add_tensor_68);  add_tensor_80 = add_tensor_68 = None
        sum_dim_int_list_11 = torch.ops.aten.sum.dim_IntList(mul_tensor_35, [2], True);  mul_tensor_35 = None
        mul_tensor_36 = torch.ops.aten.mul.Tensor(div_tensor_43, primals_40);  primals_40 = None
        mul_tensor_37 = torch.ops.aten.mul.Tensor(div_tensor_43, sub_tensor_22);  div_tensor_43 = sub_tensor_22 = None
        sum_dim_int_list_12 = torch.ops.aten.sum.dim_IntList(mul_tensor_37, [0, 1], True);  mul_tensor_37 = None
        view_default_231 = torch.ops.aten.view.default(sum_dim_int_list_12, [768]);  sum_dim_int_list_12 = None
        neg_default_3 = torch.ops.aten.neg.default(mul_tensor_36)
        sum_dim_int_list_13 = torch.ops.aten.sum.dim_IntList(neg_default_3, [2], True);  neg_default_3 = None
        add_tensor_81 = torch.ops.aten.add.Tensor(add_tensor_78, mul_tensor_36);  add_tensor_78 = mul_tensor_36 = None
        mul_scalar_2 = torch.ops.aten.mul.Scalar(std_correction_22, 2)
        div_tensor_44 = torch.ops.aten.div.Tensor(sum_dim_int_list_11, mul_scalar_2);  sum_dim_int_list_11 = mul_scalar_2 = None
        eq_scalar_13 = torch.ops.aten.eq.Scalar(std_correction_22, 0);  std_correction_22 = None
        masked_fill__scalar_1 = torch.ops.aten.masked_fill_.Scalar(div_tensor_44, eq_scalar_13, 0);  div_tensor_44 = eq_scalar_13 = None
        mul_scalar_3 = torch.ops.aten.mul.Scalar(masked_fill__scalar_1, 0.002607561929595828);  masked_fill__scalar_1 = None
        mean_dim_25 = torch.ops.aten.mean.dim(add_tensor_67, [-1], True)
        sub_tensor_25 = torch.ops.aten.sub.Tensor(add_tensor_67, mean_dim_25);  add_tensor_67 = mean_dim_25 = None
        mul_tensor_38 = torch.ops.aten.mul.Tensor(mul_scalar_3, sub_tensor_25);  mul_scalar_3 = sub_tensor_25 = None
        add_tensor_82 = torch.ops.aten.add.Tensor(add_tensor_81, mul_tensor_38);  add_tensor_81 = mul_tensor_38 = None
        expand_default_49 = torch.ops.aten.expand.default(sum_dim_int_list_13, [16, 128, 768]);  sum_dim_int_list_13 = None
        div_scalar_1 = torch.ops.aten.div.Scalar(expand_default_49, 768);  expand_default_49 = None
        add_tensor_83 = torch.ops.aten.add.Tensor(add_tensor_82, div_scalar_1);  add_tensor_82 = div_scalar_1 = None
        view_default_232 = torch.ops.aten.view.default(add_tensor_83, [2048, 768])
        t_default_96 = torch.ops.aten.t.default(t_default_65);  t_default_65 = None
        mm_default_12 = torch.ops.aten.mm.default(view_default_232, t_default_96);  t_default_96 = None
        t_default_97 = torch.ops.aten.t.default(view_default_232)
        mm_default_13 = torch.ops.aten.mm.default(t_default_97, view_default_185);  t_default_97 = view_default_185 = None
        t_default_98 = torch.ops.aten.t.default(mm_default_13);  mm_default_13 = None
        sum_dim_int_list_14 = torch.ops.aten.sum.dim_IntList(view_default_232, [0], True);  view_default_232 = None
        view_default_233 = torch.ops.aten.view.default(sum_dim_int_list_14, [768]);  sum_dim_int_list_14 = None
        t_default_99 = torch.ops.aten.t.default(t_default_98);  t_default_98 = None
        view_default_234 = torch.ops.aten.view.default(mm_default_12, [16, 128, 3072]);  mm_default_12 = None
        to_dtype_3 = torch.ops.aten.to.dtype(view_default_234, torch.float32);  view_default_234 = None
        to_dtype_4 = torch.ops.aten.to.dtype(view_default_184, torch.float32);  view_default_184 = None
        mul_tensor_39 = torch.ops.aten.mul.Tensor(to_dtype_4, 0.7071067811865476)
        erf_default_1 = torch.ops.aten.erf.default(mul_tensor_39);  mul_tensor_39 = None
        add_tensor_84 = torch.ops.aten.add.Tensor(erf_default_1, 1);  erf_default_1 = None
        mul_tensor_40 = torch.ops.aten.mul.Tensor(add_tensor_84, 0.5);  add_tensor_84 = None
        mul_tensor_41 = torch.ops.aten.mul.Tensor(to_dtype_4, to_dtype_4)
        mul_tensor_42 = torch.ops.aten.mul.Tensor(mul_tensor_41, -0.5);  mul_tensor_41 = None
        exp_default_1 = torch.ops.aten.exp.default(mul_tensor_42);  mul_tensor_42 = None
        mul_tensor_43 = torch.ops.aten.mul.Tensor(exp_default_1, 0.3989422804014327);  exp_default_1 = None
        mul_tensor_44 = torch.ops.aten.mul.Tensor(to_dtype_4, mul_tensor_43);  to_dtype_4 = mul_tensor_43 = None
        add_tensor_85 = torch.ops.aten.add.Tensor(mul_tensor_40, mul_tensor_44);  mul_tensor_40 = mul_tensor_44 = None
        mul_tensor_45 = torch.ops.aten.mul.Tensor(to_dtype_3, add_tensor_85);  to_dtype_3 = add_tensor_85 = None
        to_dtype_5 = torch.ops.aten.to.dtype(mul_tensor_45, torch.float32);  mul_tensor_45 = None
        view_default_235 = torch.ops.aten.view.default(to_dtype_5, [2048, 3072]);  to_dtype_5 = None
        t_default_100 = torch.ops.aten.t.default(t_default_64);  t_default_64 = None
        mm_default_14 = torch.ops.aten.mm.default(view_default_235, t_default_100);  t_default_100 = None
        t_default_101 = torch.ops.aten.t.default(view_default_235)
        mm_default_15 = torch.ops.aten.mm.default(t_default_101, view_default_183);  t_default_101 = view_default_183 = None
        t_default_102 = torch.ops.aten.t.default(mm_default_15);  mm_default_15 = None
        sum_dim_int_list_15 = torch.ops.aten.sum.dim_IntList(view_default_235, [0], True);  view_default_235 = None
        view_default_236 = torch.ops.aten.view.default(sum_dim_int_list_15, [3072]);  sum_dim_int_list_15 = None
        t_default_103 = torch.ops.aten.t.default(t_default_102);  t_default_102 = None
        view_default_237 = torch.ops.aten.view.default(mm_default_14, [16, 128, 768]);  mm_default_14 = None
        sum_dim_int_list_16 = torch.ops.aten.sum.dim_IntList(view_default_237, [0, 1], True)
        view_default_238 = torch.ops.aten.view.default(sum_dim_int_list_16, [768]);  sum_dim_int_list_16 = None
        neg_default_4 = torch.ops.aten.neg.default(view_default_237)
        div_tensor_45 = torch.ops.aten.div.Tensor(mul_tensor_21, add_tensor_65);  mul_tensor_21 = None
        div_tensor_46 = torch.ops.aten.div.Tensor(div_tensor_45, add_tensor_65);  div_tensor_45 = None
        mul_tensor_46 = torch.ops.aten.mul.Tensor(neg_default_4, div_tensor_46);  neg_default_4 = div_tensor_46 = None
        div_tensor_47 = torch.ops.aten.div.Tensor(view_default_237, add_tensor_65);  view_default_237 = add_tensor_65 = None
        sum_dim_int_list_17 = torch.ops.aten.sum.dim_IntList(mul_tensor_46, [2], True);  mul_tensor_46 = None
        mul_tensor_47 = torch.ops.aten.mul.Tensor(div_tensor_47, primals_34);  primals_34 = None
        mul_tensor_48 = torch.ops.aten.mul.Tensor(div_tensor_47, sub_tensor_21);  div_tensor_47 = sub_tensor_21 = None
        sum_dim_int_list_18 = torch.ops.aten.sum.dim_IntList(mul_tensor_48, [0, 1], True);  mul_tensor_48 = None
        view_default_239 = torch.ops.aten.view.default(sum_dim_int_list_18, [768]);  sum_dim_int_list_18 = None
        neg_default_5 = torch.ops.aten.neg.default(mul_tensor_47)
        sum_dim_int_list_19 = torch.ops.aten.sum.dim_IntList(neg_default_5, [2], True);  neg_default_5 = None
        add_tensor_86 = torch.ops.aten.add.Tensor(add_tensor_83, mul_tensor_47);  add_tensor_83 = mul_tensor_47 = None
        mul_scalar_4 = torch.ops.aten.mul.Scalar(std_correction_21, 2)
        div_tensor_48 = torch.ops.aten.div.Tensor(sum_dim_int_list_17, mul_scalar_4);  sum_dim_int_list_17 = mul_scalar_4 = None
        eq_scalar_14 = torch.ops.aten.eq.Scalar(std_correction_21, 0);  std_correction_21 = None
        masked_fill__scalar_2 = torch.ops.aten.masked_fill_.Scalar(div_tensor_48, eq_scalar_14, 0);  div_tensor_48 = eq_scalar_14 = None
        mul_scalar_5 = torch.ops.aten.mul.Scalar(masked_fill__scalar_2, 0.002607561929595828);  masked_fill__scalar_2 = None
        mean_dim_26 = torch.ops.aten.mean.dim(add_tensor_64, [-1], True)
        sub_tensor_26 = torch.ops.aten.sub.Tensor(add_tensor_64, mean_dim_26);  add_tensor_64 = mean_dim_26 = None
        mul_tensor_49 = torch.ops.aten.mul.Tensor(mul_scalar_5, sub_tensor_26);  mul_scalar_5 = sub_tensor_26 = None
        add_tensor_87 = torch.ops.aten.add.Tensor(add_tensor_86, mul_tensor_49);  add_tensor_86 = mul_tensor_49 = None
        expand_default_50 = torch.ops.aten.expand.default(sum_dim_int_list_19, [16, 128, 768]);  sum_dim_int_list_19 = None
        div_scalar_2 = torch.ops.aten.div.Scalar(expand_default_50, 768);  expand_default_50 = None
        add_tensor_88 = torch.ops.aten.add.Tensor(add_tensor_87, div_scalar_2);  add_tensor_87 = div_scalar_2 = None
        view_default_240 = torch.ops.aten.view.default(add_tensor_88, [2048, 768])
        t_default_104 = torch.ops.aten.t.default(t_default_63);  t_default_63 = None
        mm_default_16 = torch.ops.aten.mm.default(view_default_240, t_default_104);  t_default_104 = None
        t_default_105 = torch.ops.aten.t.default(view_default_240)
        mm_default_17 = torch.ops.aten.mm.default(t_default_105, view_default_181);  t_default_105 = view_default_181 = None
        t_default_106 = torch.ops.aten.t.default(mm_default_17);  mm_default_17 = None
        sum_dim_int_list_20 = torch.ops.aten.sum.dim_IntList(view_default_240, [0], True);  view_default_240 = None
        view_default_241 = torch.ops.aten.view.default(sum_dim_int_list_20, [768]);  sum_dim_int_list_20 = None
        t_default_107 = torch.ops.aten.t.default(t_default_106);  t_default_106 = None
        view_default_242 = torch.ops.aten.view.default(mm_default_16, [16, 128, 768]);  mm_default_16 = None
        view_default_243 = torch.ops.aten.view.default(view_default_242, [16, 128, 12, 64]);  view_default_242 = None
        transpose_int_69 = torch.ops.aten.transpose.int(view_default_243, 1, 2);  view_default_243 = None
        clone_default_52 = torch.ops.aten.clone.default(transpose_int_69, memory_format = torch.contiguous_format);  transpose_int_69 = None
        _unsafe_view_default_64 = torch.ops.aten._unsafe_view.default(clone_default_52, [192, 128, 64]);  clone_default_52 = None
        transpose_int_70 = torch.ops.aten.transpose.int(view_default_179, 1, 2);  view_default_179 = None
        bmm_default_28 = torch.ops.aten.bmm.default(transpose_int_70, _unsafe_view_default_64);  transpose_int_70 = None
        transpose_int_71 = torch.ops.aten.transpose.int(_unsafe_view_default_53, 1, 2);  _unsafe_view_default_53 = None
        bmm_default_29 = torch.ops.aten.bmm.default(_unsafe_view_default_64, transpose_int_71);  _unsafe_view_default_64 = transpose_int_71 = None
        view_default_244 = torch.ops.aten.view.default(bmm_default_28, [16, 12, 128, 64]);  bmm_default_28 = None
        view_default_245 = torch.ops.aten.view.default(bmm_default_29, [16, 12, 128, 128]);  bmm_default_29 = None
        _softmax_backward_data_default_1 = torch.ops.aten._softmax_backward_data.default(view_default_245, _softmax_default_10, -1, torch.float32);  view_default_245 = _softmax_default_10 = None
        where_scalar_self_13 = torch.ops.aten.where.ScalarSelf(eq_scalar_10, 0.0, _softmax_backward_data_default_1);  eq_scalar_10 = _softmax_backward_data_default_1 = None
        div_tensor_49 = torch.ops.aten.div.Tensor(where_scalar_self_13, 8.0);  where_scalar_self_13 = None
        view_default_246 = torch.ops.aten.view.default(div_tensor_49, [192, 128, 128]);  div_tensor_49 = None
        transpose_int_72 = torch.ops.aten.transpose.int(_unsafe_view_default_50, 1, 2);  _unsafe_view_default_50 = None
        bmm_default_30 = torch.ops.aten.bmm.default(transpose_int_72, view_default_246);  transpose_int_72 = None
        transpose_int_73 = torch.ops.aten.transpose.int(_unsafe_view_default_51, 1, 2);  _unsafe_view_default_51 = None
        bmm_default_31 = torch.ops.aten.bmm.default(view_default_246, transpose_int_73);  view_default_246 = transpose_int_73 = None
        view_default_247 = torch.ops.aten.view.default(bmm_default_30, [16, 12, 64, 128]);  bmm_default_30 = None
        view_default_248 = torch.ops.aten.view.default(bmm_default_31, [16, 12, 128, 64]);  bmm_default_31 = None
        transpose_int_74 = torch.ops.aten.transpose.int(view_default_247, -2, -1);  view_default_247 = None
        transpose_int_75 = torch.ops.aten.transpose.int(view_default_244, 1, 2);  view_default_244 = None
        clone_default_53 = torch.ops.aten.clone.default(transpose_int_75, memory_format = torch.contiguous_format);  transpose_int_75 = None
        _unsafe_view_default_65 = torch.ops.aten._unsafe_view.default(clone_default_53, [16, 128, 768]);  clone_default_53 = None
        view_default_249 = torch.ops.aten.view.default(_unsafe_view_default_65, [2048, 768]);  _unsafe_view_default_65 = None
        t_default_108 = torch.ops.aten.t.default(t_default_62);  t_default_62 = None
        mm_default_18 = torch.ops.aten.mm.default(view_default_249, t_default_108);  t_default_108 = None
        t_default_109 = torch.ops.aten.t.default(view_default_249)
        mm_default_19 = torch.ops.aten.mm.default(t_default_109, view_default_176);  t_default_109 = view_default_176 = None
        t_default_110 = torch.ops.aten.t.default(mm_default_19);  mm_default_19 = None
        sum_dim_int_list_21 = torch.ops.aten.sum.dim_IntList(view_default_249, [0], True);  view_default_249 = None
        view_default_250 = torch.ops.aten.view.default(sum_dim_int_list_21, [768]);  sum_dim_int_list_21 = None
        t_default_111 = torch.ops.aten.t.default(t_default_110);  t_default_110 = None
        view_default_251 = torch.ops.aten.view.default(mm_default_18, [16, 128, 768]);  mm_default_18 = None
        transpose_int_76 = torch.ops.aten.transpose.int(transpose_int_74, 1, 2);  transpose_int_74 = None
        view_default_252 = torch.ops.aten.view.default(transpose_int_76, [16, 128, 768]);  transpose_int_76 = None
        clone_default_54 = torch.ops.aten.clone.default(view_default_252, memory_format = torch.contiguous_format);  view_default_252 = None
        _unsafe_view_default_66 = torch.ops.aten._unsafe_view.default(clone_default_54, [2048, 768]);  clone_default_54 = None
        t_default_112 = torch.ops.aten.t.default(t_default_61);  t_default_61 = None
        mm_default_20 = torch.ops.aten.mm.default(_unsafe_view_default_66, t_default_112);  t_default_112 = None
        t_default_113 = torch.ops.aten.t.default(_unsafe_view_default_66)
        mm_default_21 = torch.ops.aten.mm.default(t_default_113, view_default_173);  t_default_113 = view_default_173 = None
        t_default_114 = torch.ops.aten.t.default(mm_default_21);  mm_default_21 = None
        sum_dim_int_list_22 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_66, [0], True);  _unsafe_view_default_66 = None
        view_default_253 = torch.ops.aten.view.default(sum_dim_int_list_22, [768]);  sum_dim_int_list_22 = None
        t_default_115 = torch.ops.aten.t.default(t_default_114);  t_default_114 = None
        view_default_254 = torch.ops.aten.view.default(mm_default_20, [16, 128, 768]);  mm_default_20 = None
        add_tensor_89 = torch.ops.aten.add.Tensor(view_default_251, view_default_254);  view_default_251 = view_default_254 = None
        transpose_int_77 = torch.ops.aten.transpose.int(view_default_248, 1, 2);  view_default_248 = None
        clone_default_55 = torch.ops.aten.clone.default(transpose_int_77, memory_format = torch.contiguous_format);  transpose_int_77 = None
        _unsafe_view_default_67 = torch.ops.aten._unsafe_view.default(clone_default_55, [16, 128, 768]);  clone_default_55 = None
        view_default_255 = torch.ops.aten.view.default(_unsafe_view_default_67, [2048, 768]);  _unsafe_view_default_67 = None
        t_default_116 = torch.ops.aten.t.default(t_default_60);  t_default_60 = None
        mm_default_22 = torch.ops.aten.mm.default(view_default_255, t_default_116);  t_default_116 = None
        t_default_117 = torch.ops.aten.t.default(view_default_255)
        mm_default_23 = torch.ops.aten.mm.default(t_default_117, view_default_170);  t_default_117 = view_default_170 = None
        t_default_118 = torch.ops.aten.t.default(mm_default_23);  mm_default_23 = None
        sum_dim_int_list_23 = torch.ops.aten.sum.dim_IntList(view_default_255, [0], True);  view_default_255 = None
        view_default_256 = torch.ops.aten.view.default(sum_dim_int_list_23, [768]);  sum_dim_int_list_23 = None
        t_default_119 = torch.ops.aten.t.default(t_default_118);  t_default_118 = None
        view_default_257 = torch.ops.aten.view.default(mm_default_22, [16, 128, 768]);  mm_default_22 = None
        add_tensor_90 = torch.ops.aten.add.Tensor(add_tensor_89, view_default_257);  add_tensor_89 = view_default_257 = None
        sum_dim_int_list_24 = torch.ops.aten.sum.dim_IntList(add_tensor_90, [0, 1], True)
        view_default_258 = torch.ops.aten.view.default(sum_dim_int_list_24, [768]);  sum_dim_int_list_24 = None
        neg_default_6 = torch.ops.aten.neg.default(add_tensor_90)
        div_tensor_50 = torch.ops.aten.div.Tensor(mul_tensor_20, add_tensor_62);  mul_tensor_20 = None
        div_tensor_51 = torch.ops.aten.div.Tensor(div_tensor_50, add_tensor_62);  div_tensor_50 = None
        mul_tensor_50 = torch.ops.aten.mul.Tensor(neg_default_6, div_tensor_51);  neg_default_6 = div_tensor_51 = None
        div_tensor_52 = torch.ops.aten.div.Tensor(add_tensor_90, add_tensor_62);  add_tensor_90 = add_tensor_62 = None
        sum_dim_int_list_25 = torch.ops.aten.sum.dim_IntList(mul_tensor_50, [2], True);  mul_tensor_50 = None
        mul_tensor_51 = torch.ops.aten.mul.Tensor(div_tensor_52, primals_24);  primals_24 = None
        mul_tensor_52 = torch.ops.aten.mul.Tensor(div_tensor_52, sub_tensor_20);  div_tensor_52 = sub_tensor_20 = None
        sum_dim_int_list_26 = torch.ops.aten.sum.dim_IntList(mul_tensor_52, [0, 1], True);  mul_tensor_52 = None
        view_default_259 = torch.ops.aten.view.default(sum_dim_int_list_26, [768]);  sum_dim_int_list_26 = None
        neg_default_7 = torch.ops.aten.neg.default(mul_tensor_51)
        sum_dim_int_list_27 = torch.ops.aten.sum.dim_IntList(neg_default_7, [2], True);  neg_default_7 = None
        add_tensor_91 = torch.ops.aten.add.Tensor(add_tensor_88, mul_tensor_51);  add_tensor_88 = mul_tensor_51 = None
        mul_scalar_6 = torch.ops.aten.mul.Scalar(std_correction_20, 2)
        div_tensor_53 = torch.ops.aten.div.Tensor(sum_dim_int_list_25, mul_scalar_6);  sum_dim_int_list_25 = mul_scalar_6 = None
        eq_scalar_15 = torch.ops.aten.eq.Scalar(std_correction_20, 0);  std_correction_20 = None
        masked_fill__scalar_3 = torch.ops.aten.masked_fill_.Scalar(div_tensor_53, eq_scalar_15, 0);  div_tensor_53 = eq_scalar_15 = None
        mul_scalar_7 = torch.ops.aten.mul.Scalar(masked_fill__scalar_3, 0.002607561929595828);  masked_fill__scalar_3 = None
        mean_dim_27 = torch.ops.aten.mean.dim(add_tensor_61, [-1], True)
        sub_tensor_27 = torch.ops.aten.sub.Tensor(add_tensor_61, mean_dim_27);  add_tensor_61 = mean_dim_27 = None
        mul_tensor_53 = torch.ops.aten.mul.Tensor(mul_scalar_7, sub_tensor_27);  mul_scalar_7 = sub_tensor_27 = None
        add_tensor_92 = torch.ops.aten.add.Tensor(add_tensor_91, mul_tensor_53);  add_tensor_91 = mul_tensor_53 = None
        expand_default_51 = torch.ops.aten.expand.default(sum_dim_int_list_27, [16, 128, 768]);  sum_dim_int_list_27 = None
        div_scalar_3 = torch.ops.aten.div.Scalar(expand_default_51, 768);  expand_default_51 = None
        add_tensor_93 = torch.ops.aten.add.Tensor(add_tensor_92, div_scalar_3);  add_tensor_92 = div_scalar_3 = None
        view_default_260 = torch.ops.aten.view.default(add_tensor_93, [2048, 768])
        t_default_120 = torch.ops.aten.t.default(t_default_59);  t_default_59 = None
        mm_default_24 = torch.ops.aten.mm.default(view_default_260, t_default_120);  t_default_120 = None
        t_default_121 = torch.ops.aten.t.default(view_default_260)
        mm_default_25 = torch.ops.aten.mm.default(t_default_121, view_default_168);  t_default_121 = view_default_168 = None
        t_default_122 = torch.ops.aten.t.default(mm_default_25);  mm_default_25 = None
        sum_dim_int_list_28 = torch.ops.aten.sum.dim_IntList(view_default_260, [0], True);  view_default_260 = None
        view_default_261 = torch.ops.aten.view.default(sum_dim_int_list_28, [768]);  sum_dim_int_list_28 = None
        t_default_123 = torch.ops.aten.t.default(t_default_122);  t_default_122 = None
        view_default_262 = torch.ops.aten.view.default(mm_default_24, [16, 128, 3072]);  mm_default_24 = None
        to_dtype_6 = torch.ops.aten.to.dtype(view_default_262, torch.float32);  view_default_262 = None
        to_dtype_7 = torch.ops.aten.to.dtype(view_default_167, torch.float32);  view_default_167 = None
        mul_tensor_54 = torch.ops.aten.mul.Tensor(to_dtype_7, 0.7071067811865476)
        erf_default_2 = torch.ops.aten.erf.default(mul_tensor_54);  mul_tensor_54 = None
        add_tensor_94 = torch.ops.aten.add.Tensor(erf_default_2, 1);  erf_default_2 = None
        mul_tensor_55 = torch.ops.aten.mul.Tensor(add_tensor_94, 0.5);  add_tensor_94 = None
        mul_tensor_56 = torch.ops.aten.mul.Tensor(to_dtype_7, to_dtype_7)
        mul_tensor_57 = torch.ops.aten.mul.Tensor(mul_tensor_56, -0.5);  mul_tensor_56 = None
        exp_default_2 = torch.ops.aten.exp.default(mul_tensor_57);  mul_tensor_57 = None
        mul_tensor_58 = torch.ops.aten.mul.Tensor(exp_default_2, 0.3989422804014327);  exp_default_2 = None
        mul_tensor_59 = torch.ops.aten.mul.Tensor(to_dtype_7, mul_tensor_58);  to_dtype_7 = mul_tensor_58 = None
        add_tensor_95 = torch.ops.aten.add.Tensor(mul_tensor_55, mul_tensor_59);  mul_tensor_55 = mul_tensor_59 = None
        mul_tensor_60 = torch.ops.aten.mul.Tensor(to_dtype_6, add_tensor_95);  to_dtype_6 = add_tensor_95 = None
        to_dtype_8 = torch.ops.aten.to.dtype(mul_tensor_60, torch.float32);  mul_tensor_60 = None
        view_default_263 = torch.ops.aten.view.default(to_dtype_8, [2048, 3072]);  to_dtype_8 = None
        t_default_124 = torch.ops.aten.t.default(t_default_58);  t_default_58 = None
        mm_default_26 = torch.ops.aten.mm.default(view_default_263, t_default_124);  t_default_124 = None
        t_default_125 = torch.ops.aten.t.default(view_default_263)
        mm_default_27 = torch.ops.aten.mm.default(t_default_125, view_default_166);  t_default_125 = view_default_166 = None
        t_default_126 = torch.ops.aten.t.default(mm_default_27);  mm_default_27 = None
        sum_dim_int_list_29 = torch.ops.aten.sum.dim_IntList(view_default_263, [0], True);  view_default_263 = None
        view_default_264 = torch.ops.aten.view.default(sum_dim_int_list_29, [3072]);  sum_dim_int_list_29 = None
        t_default_127 = torch.ops.aten.t.default(t_default_126);  t_default_126 = None
        view_default_265 = torch.ops.aten.view.default(mm_default_26, [16, 128, 768]);  mm_default_26 = None
        sum_dim_int_list_30 = torch.ops.aten.sum.dim_IntList(view_default_265, [0, 1], True)
        view_default_266 = torch.ops.aten.view.default(sum_dim_int_list_30, [768]);  sum_dim_int_list_30 = None
        neg_default_8 = torch.ops.aten.neg.default(view_default_265)
        div_tensor_54 = torch.ops.aten.div.Tensor(mul_tensor_19, add_tensor_59);  mul_tensor_19 = None
        div_tensor_55 = torch.ops.aten.div.Tensor(div_tensor_54, add_tensor_59);  div_tensor_54 = None
        mul_tensor_61 = torch.ops.aten.mul.Tensor(neg_default_8, div_tensor_55);  neg_default_8 = div_tensor_55 = None
        div_tensor_56 = torch.ops.aten.div.Tensor(view_default_265, add_tensor_59);  view_default_265 = add_tensor_59 = None
        sum_dim_int_list_31 = torch.ops.aten.sum.dim_IntList(mul_tensor_61, [2], True);  mul_tensor_61 = None
        mul_tensor_62 = torch.ops.aten.mul.Tensor(div_tensor_56, primals_194);  primals_194 = None
        mul_tensor_63 = torch.ops.aten.mul.Tensor(div_tensor_56, sub_tensor_19);  div_tensor_56 = sub_tensor_19 = None
        sum_dim_int_list_32 = torch.ops.aten.sum.dim_IntList(mul_tensor_63, [0, 1], True);  mul_tensor_63 = None
        view_default_267 = torch.ops.aten.view.default(sum_dim_int_list_32, [768]);  sum_dim_int_list_32 = None
        neg_default_9 = torch.ops.aten.neg.default(mul_tensor_62)
        sum_dim_int_list_33 = torch.ops.aten.sum.dim_IntList(neg_default_9, [2], True);  neg_default_9 = None
        add_tensor_96 = torch.ops.aten.add.Tensor(add_tensor_93, mul_tensor_62);  add_tensor_93 = mul_tensor_62 = None
        mul_scalar_8 = torch.ops.aten.mul.Scalar(std_correction_19, 2)
        div_tensor_57 = torch.ops.aten.div.Tensor(sum_dim_int_list_31, mul_scalar_8);  sum_dim_int_list_31 = mul_scalar_8 = None
        eq_scalar_16 = torch.ops.aten.eq.Scalar(std_correction_19, 0);  std_correction_19 = None
        masked_fill__scalar_4 = torch.ops.aten.masked_fill_.Scalar(div_tensor_57, eq_scalar_16, 0);  div_tensor_57 = eq_scalar_16 = None
        mul_scalar_9 = torch.ops.aten.mul.Scalar(masked_fill__scalar_4, 0.002607561929595828);  masked_fill__scalar_4 = None
        mean_dim_28 = torch.ops.aten.mean.dim(add_tensor_58, [-1], True)
        sub_tensor_28 = torch.ops.aten.sub.Tensor(add_tensor_58, mean_dim_28);  add_tensor_58 = mean_dim_28 = None
        mul_tensor_64 = torch.ops.aten.mul.Tensor(mul_scalar_9, sub_tensor_28);  mul_scalar_9 = sub_tensor_28 = None
        add_tensor_97 = torch.ops.aten.add.Tensor(add_tensor_96, mul_tensor_64);  add_tensor_96 = mul_tensor_64 = None
        expand_default_52 = torch.ops.aten.expand.default(sum_dim_int_list_33, [16, 128, 768]);  sum_dim_int_list_33 = None
        div_scalar_4 = torch.ops.aten.div.Scalar(expand_default_52, 768);  expand_default_52 = None
        add_tensor_98 = torch.ops.aten.add.Tensor(add_tensor_97, div_scalar_4);  add_tensor_97 = div_scalar_4 = None
        view_default_268 = torch.ops.aten.view.default(add_tensor_98, [2048, 768])
        t_default_128 = torch.ops.aten.t.default(t_default_57);  t_default_57 = None
        mm_default_28 = torch.ops.aten.mm.default(view_default_268, t_default_128);  t_default_128 = None
        t_default_129 = torch.ops.aten.t.default(view_default_268)
        mm_default_29 = torch.ops.aten.mm.default(t_default_129, view_default_164);  t_default_129 = view_default_164 = None
        t_default_130 = torch.ops.aten.t.default(mm_default_29);  mm_default_29 = None
        sum_dim_int_list_34 = torch.ops.aten.sum.dim_IntList(view_default_268, [0], True);  view_default_268 = None
        view_default_269 = torch.ops.aten.view.default(sum_dim_int_list_34, [768]);  sum_dim_int_list_34 = None
        t_default_131 = torch.ops.aten.t.default(t_default_130);  t_default_130 = None
        view_default_270 = torch.ops.aten.view.default(mm_default_28, [16, 128, 768]);  mm_default_28 = None
        view_default_271 = torch.ops.aten.view.default(view_default_270, [16, 128, 12, 64]);  view_default_270 = None
        transpose_int_78 = torch.ops.aten.transpose.int(view_default_271, 1, 2);  view_default_271 = None
        clone_default_56 = torch.ops.aten.clone.default(transpose_int_78, memory_format = torch.contiguous_format);  transpose_int_78 = None
        _unsafe_view_default_68 = torch.ops.aten._unsafe_view.default(clone_default_56, [192, 128, 64]);  clone_default_56 = None
        transpose_int_79 = torch.ops.aten.transpose.int(view_default_162, 1, 2);  view_default_162 = None
        bmm_default_32 = torch.ops.aten.bmm.default(transpose_int_79, _unsafe_view_default_68);  transpose_int_79 = None
        transpose_int_80 = torch.ops.aten.transpose.int(_unsafe_view_default_48, 1, 2);  _unsafe_view_default_48 = None
        bmm_default_33 = torch.ops.aten.bmm.default(_unsafe_view_default_68, transpose_int_80);  _unsafe_view_default_68 = transpose_int_80 = None
        view_default_272 = torch.ops.aten.view.default(bmm_default_32, [16, 12, 128, 64]);  bmm_default_32 = None
        view_default_273 = torch.ops.aten.view.default(bmm_default_33, [16, 12, 128, 128]);  bmm_default_33 = None
        _softmax_backward_data_default_2 = torch.ops.aten._softmax_backward_data.default(view_default_273, _softmax_default_9, -1, torch.float32);  view_default_273 = _softmax_default_9 = None
        where_scalar_self_14 = torch.ops.aten.where.ScalarSelf(eq_scalar_9, 0.0, _softmax_backward_data_default_2);  eq_scalar_9 = _softmax_backward_data_default_2 = None
        div_tensor_58 = torch.ops.aten.div.Tensor(where_scalar_self_14, 8.0);  where_scalar_self_14 = None
        view_default_274 = torch.ops.aten.view.default(div_tensor_58, [192, 128, 128]);  div_tensor_58 = None
        transpose_int_81 = torch.ops.aten.transpose.int(_unsafe_view_default_45, 1, 2);  _unsafe_view_default_45 = None
        bmm_default_34 = torch.ops.aten.bmm.default(transpose_int_81, view_default_274);  transpose_int_81 = None
        transpose_int_82 = torch.ops.aten.transpose.int(_unsafe_view_default_46, 1, 2);  _unsafe_view_default_46 = None
        bmm_default_35 = torch.ops.aten.bmm.default(view_default_274, transpose_int_82);  view_default_274 = transpose_int_82 = None
        view_default_275 = torch.ops.aten.view.default(bmm_default_34, [16, 12, 64, 128]);  bmm_default_34 = None
        view_default_276 = torch.ops.aten.view.default(bmm_default_35, [16, 12, 128, 64]);  bmm_default_35 = None
        transpose_int_83 = torch.ops.aten.transpose.int(view_default_275, -2, -1);  view_default_275 = None
        transpose_int_84 = torch.ops.aten.transpose.int(view_default_272, 1, 2);  view_default_272 = None
        clone_default_57 = torch.ops.aten.clone.default(transpose_int_84, memory_format = torch.contiguous_format);  transpose_int_84 = None
        _unsafe_view_default_69 = torch.ops.aten._unsafe_view.default(clone_default_57, [16, 128, 768]);  clone_default_57 = None
        view_default_277 = torch.ops.aten.view.default(_unsafe_view_default_69, [2048, 768]);  _unsafe_view_default_69 = None
        t_default_132 = torch.ops.aten.t.default(t_default_56);  t_default_56 = None
        mm_default_30 = torch.ops.aten.mm.default(view_default_277, t_default_132);  t_default_132 = None
        t_default_133 = torch.ops.aten.t.default(view_default_277)
        mm_default_31 = torch.ops.aten.mm.default(t_default_133, view_default_159);  t_default_133 = view_default_159 = None
        t_default_134 = torch.ops.aten.t.default(mm_default_31);  mm_default_31 = None
        sum_dim_int_list_35 = torch.ops.aten.sum.dim_IntList(view_default_277, [0], True);  view_default_277 = None
        view_default_278 = torch.ops.aten.view.default(sum_dim_int_list_35, [768]);  sum_dim_int_list_35 = None
        t_default_135 = torch.ops.aten.t.default(t_default_134);  t_default_134 = None
        view_default_279 = torch.ops.aten.view.default(mm_default_30, [16, 128, 768]);  mm_default_30 = None
        transpose_int_85 = torch.ops.aten.transpose.int(transpose_int_83, 1, 2);  transpose_int_83 = None
        view_default_280 = torch.ops.aten.view.default(transpose_int_85, [16, 128, 768]);  transpose_int_85 = None
        clone_default_58 = torch.ops.aten.clone.default(view_default_280, memory_format = torch.contiguous_format);  view_default_280 = None
        _unsafe_view_default_70 = torch.ops.aten._unsafe_view.default(clone_default_58, [2048, 768]);  clone_default_58 = None
        t_default_136 = torch.ops.aten.t.default(t_default_55);  t_default_55 = None
        mm_default_32 = torch.ops.aten.mm.default(_unsafe_view_default_70, t_default_136);  t_default_136 = None
        t_default_137 = torch.ops.aten.t.default(_unsafe_view_default_70)
        mm_default_33 = torch.ops.aten.mm.default(t_default_137, view_default_156);  t_default_137 = view_default_156 = None
        t_default_138 = torch.ops.aten.t.default(mm_default_33);  mm_default_33 = None
        sum_dim_int_list_36 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_70, [0], True);  _unsafe_view_default_70 = None
        view_default_281 = torch.ops.aten.view.default(sum_dim_int_list_36, [768]);  sum_dim_int_list_36 = None
        t_default_139 = torch.ops.aten.t.default(t_default_138);  t_default_138 = None
        view_default_282 = torch.ops.aten.view.default(mm_default_32, [16, 128, 768]);  mm_default_32 = None
        add_tensor_99 = torch.ops.aten.add.Tensor(view_default_279, view_default_282);  view_default_279 = view_default_282 = None
        transpose_int_86 = torch.ops.aten.transpose.int(view_default_276, 1, 2);  view_default_276 = None
        clone_default_59 = torch.ops.aten.clone.default(transpose_int_86, memory_format = torch.contiguous_format);  transpose_int_86 = None
        _unsafe_view_default_71 = torch.ops.aten._unsafe_view.default(clone_default_59, [16, 128, 768]);  clone_default_59 = None
        view_default_283 = torch.ops.aten.view.default(_unsafe_view_default_71, [2048, 768]);  _unsafe_view_default_71 = None
        t_default_140 = torch.ops.aten.t.default(t_default_54);  t_default_54 = None
        mm_default_34 = torch.ops.aten.mm.default(view_default_283, t_default_140);  t_default_140 = None
        t_default_141 = torch.ops.aten.t.default(view_default_283)
        mm_default_35 = torch.ops.aten.mm.default(t_default_141, view_default_153);  t_default_141 = view_default_153 = None
        t_default_142 = torch.ops.aten.t.default(mm_default_35);  mm_default_35 = None
        sum_dim_int_list_37 = torch.ops.aten.sum.dim_IntList(view_default_283, [0], True);  view_default_283 = None
        view_default_284 = torch.ops.aten.view.default(sum_dim_int_list_37, [768]);  sum_dim_int_list_37 = None
        t_default_143 = torch.ops.aten.t.default(t_default_142);  t_default_142 = None
        view_default_285 = torch.ops.aten.view.default(mm_default_34, [16, 128, 768]);  mm_default_34 = None
        add_tensor_100 = torch.ops.aten.add.Tensor(add_tensor_99, view_default_285);  add_tensor_99 = view_default_285 = None
        sum_dim_int_list_38 = torch.ops.aten.sum.dim_IntList(add_tensor_100, [0, 1], True)
        view_default_286 = torch.ops.aten.view.default(sum_dim_int_list_38, [768]);  sum_dim_int_list_38 = None
        neg_default_10 = torch.ops.aten.neg.default(add_tensor_100)
        div_tensor_59 = torch.ops.aten.div.Tensor(mul_tensor_18, add_tensor_56);  mul_tensor_18 = None
        div_tensor_60 = torch.ops.aten.div.Tensor(div_tensor_59, add_tensor_56);  div_tensor_59 = None
        mul_tensor_65 = torch.ops.aten.mul.Tensor(neg_default_10, div_tensor_60);  neg_default_10 = div_tensor_60 = None
        div_tensor_61 = torch.ops.aten.div.Tensor(add_tensor_100, add_tensor_56);  add_tensor_100 = add_tensor_56 = None
        sum_dim_int_list_39 = torch.ops.aten.sum.dim_IntList(mul_tensor_65, [2], True);  mul_tensor_65 = None
        mul_tensor_66 = torch.ops.aten.mul.Tensor(div_tensor_61, primals_184);  primals_184 = None
        mul_tensor_67 = torch.ops.aten.mul.Tensor(div_tensor_61, sub_tensor_18);  div_tensor_61 = sub_tensor_18 = None
        sum_dim_int_list_40 = torch.ops.aten.sum.dim_IntList(mul_tensor_67, [0, 1], True);  mul_tensor_67 = None
        view_default_287 = torch.ops.aten.view.default(sum_dim_int_list_40, [768]);  sum_dim_int_list_40 = None
        neg_default_11 = torch.ops.aten.neg.default(mul_tensor_66)
        sum_dim_int_list_41 = torch.ops.aten.sum.dim_IntList(neg_default_11, [2], True);  neg_default_11 = None
        add_tensor_101 = torch.ops.aten.add.Tensor(add_tensor_98, mul_tensor_66);  add_tensor_98 = mul_tensor_66 = None
        mul_scalar_10 = torch.ops.aten.mul.Scalar(std_correction_18, 2)
        div_tensor_62 = torch.ops.aten.div.Tensor(sum_dim_int_list_39, mul_scalar_10);  sum_dim_int_list_39 = mul_scalar_10 = None
        eq_scalar_17 = torch.ops.aten.eq.Scalar(std_correction_18, 0);  std_correction_18 = None
        masked_fill__scalar_5 = torch.ops.aten.masked_fill_.Scalar(div_tensor_62, eq_scalar_17, 0);  div_tensor_62 = eq_scalar_17 = None
        mul_scalar_11 = torch.ops.aten.mul.Scalar(masked_fill__scalar_5, 0.002607561929595828);  masked_fill__scalar_5 = None
        mean_dim_29 = torch.ops.aten.mean.dim(add_tensor_55, [-1], True)
        sub_tensor_29 = torch.ops.aten.sub.Tensor(add_tensor_55, mean_dim_29);  add_tensor_55 = mean_dim_29 = None
        mul_tensor_68 = torch.ops.aten.mul.Tensor(mul_scalar_11, sub_tensor_29);  mul_scalar_11 = sub_tensor_29 = None
        add_tensor_102 = torch.ops.aten.add.Tensor(add_tensor_101, mul_tensor_68);  add_tensor_101 = mul_tensor_68 = None
        expand_default_53 = torch.ops.aten.expand.default(sum_dim_int_list_41, [16, 128, 768]);  sum_dim_int_list_41 = None
        div_scalar_5 = torch.ops.aten.div.Scalar(expand_default_53, 768);  expand_default_53 = None
        add_tensor_103 = torch.ops.aten.add.Tensor(add_tensor_102, div_scalar_5);  add_tensor_102 = div_scalar_5 = None
        view_default_288 = torch.ops.aten.view.default(add_tensor_103, [2048, 768])
        t_default_144 = torch.ops.aten.t.default(t_default_53);  t_default_53 = None
        mm_default_36 = torch.ops.aten.mm.default(view_default_288, t_default_144);  t_default_144 = None
        t_default_145 = torch.ops.aten.t.default(view_default_288)
        mm_default_37 = torch.ops.aten.mm.default(t_default_145, view_default_151);  t_default_145 = view_default_151 = None
        t_default_146 = torch.ops.aten.t.default(mm_default_37);  mm_default_37 = None
        sum_dim_int_list_42 = torch.ops.aten.sum.dim_IntList(view_default_288, [0], True);  view_default_288 = None
        view_default_289 = torch.ops.aten.view.default(sum_dim_int_list_42, [768]);  sum_dim_int_list_42 = None
        t_default_147 = torch.ops.aten.t.default(t_default_146);  t_default_146 = None
        view_default_290 = torch.ops.aten.view.default(mm_default_36, [16, 128, 3072]);  mm_default_36 = None
        to_dtype_9 = torch.ops.aten.to.dtype(view_default_290, torch.float32);  view_default_290 = None
        to_dtype_10 = torch.ops.aten.to.dtype(view_default_150, torch.float32);  view_default_150 = None
        mul_tensor_69 = torch.ops.aten.mul.Tensor(to_dtype_10, 0.7071067811865476)
        erf_default_3 = torch.ops.aten.erf.default(mul_tensor_69);  mul_tensor_69 = None
        add_tensor_104 = torch.ops.aten.add.Tensor(erf_default_3, 1);  erf_default_3 = None
        mul_tensor_70 = torch.ops.aten.mul.Tensor(add_tensor_104, 0.5);  add_tensor_104 = None
        mul_tensor_71 = torch.ops.aten.mul.Tensor(to_dtype_10, to_dtype_10)
        mul_tensor_72 = torch.ops.aten.mul.Tensor(mul_tensor_71, -0.5);  mul_tensor_71 = None
        exp_default_3 = torch.ops.aten.exp.default(mul_tensor_72);  mul_tensor_72 = None
        mul_tensor_73 = torch.ops.aten.mul.Tensor(exp_default_3, 0.3989422804014327);  exp_default_3 = None
        mul_tensor_74 = torch.ops.aten.mul.Tensor(to_dtype_10, mul_tensor_73);  to_dtype_10 = mul_tensor_73 = None
        add_tensor_105 = torch.ops.aten.add.Tensor(mul_tensor_70, mul_tensor_74);  mul_tensor_70 = mul_tensor_74 = None
        mul_tensor_75 = torch.ops.aten.mul.Tensor(to_dtype_9, add_tensor_105);  to_dtype_9 = add_tensor_105 = None
        to_dtype_11 = torch.ops.aten.to.dtype(mul_tensor_75, torch.float32);  mul_tensor_75 = None
        view_default_291 = torch.ops.aten.view.default(to_dtype_11, [2048, 3072]);  to_dtype_11 = None
        t_default_148 = torch.ops.aten.t.default(t_default_52);  t_default_52 = None
        mm_default_38 = torch.ops.aten.mm.default(view_default_291, t_default_148);  t_default_148 = None
        t_default_149 = torch.ops.aten.t.default(view_default_291)
        mm_default_39 = torch.ops.aten.mm.default(t_default_149, view_default_149);  t_default_149 = view_default_149 = None
        t_default_150 = torch.ops.aten.t.default(mm_default_39);  mm_default_39 = None
        sum_dim_int_list_43 = torch.ops.aten.sum.dim_IntList(view_default_291, [0], True);  view_default_291 = None
        view_default_292 = torch.ops.aten.view.default(sum_dim_int_list_43, [3072]);  sum_dim_int_list_43 = None
        t_default_151 = torch.ops.aten.t.default(t_default_150);  t_default_150 = None
        view_default_293 = torch.ops.aten.view.default(mm_default_38, [16, 128, 768]);  mm_default_38 = None
        sum_dim_int_list_44 = torch.ops.aten.sum.dim_IntList(view_default_293, [0, 1], True)
        view_default_294 = torch.ops.aten.view.default(sum_dim_int_list_44, [768]);  sum_dim_int_list_44 = None
        neg_default_12 = torch.ops.aten.neg.default(view_default_293)
        div_tensor_63 = torch.ops.aten.div.Tensor(mul_tensor_17, add_tensor_53);  mul_tensor_17 = None
        div_tensor_64 = torch.ops.aten.div.Tensor(div_tensor_63, add_tensor_53);  div_tensor_63 = None
        mul_tensor_76 = torch.ops.aten.mul.Tensor(neg_default_12, div_tensor_64);  neg_default_12 = div_tensor_64 = None
        div_tensor_65 = torch.ops.aten.div.Tensor(view_default_293, add_tensor_53);  view_default_293 = add_tensor_53 = None
        sum_dim_int_list_45 = torch.ops.aten.sum.dim_IntList(mul_tensor_76, [2], True);  mul_tensor_76 = None
        mul_tensor_77 = torch.ops.aten.mul.Tensor(div_tensor_65, primals_178);  primals_178 = None
        mul_tensor_78 = torch.ops.aten.mul.Tensor(div_tensor_65, sub_tensor_17);  div_tensor_65 = sub_tensor_17 = None
        sum_dim_int_list_46 = torch.ops.aten.sum.dim_IntList(mul_tensor_78, [0, 1], True);  mul_tensor_78 = None
        view_default_295 = torch.ops.aten.view.default(sum_dim_int_list_46, [768]);  sum_dim_int_list_46 = None
        neg_default_13 = torch.ops.aten.neg.default(mul_tensor_77)
        sum_dim_int_list_47 = torch.ops.aten.sum.dim_IntList(neg_default_13, [2], True);  neg_default_13 = None
        add_tensor_106 = torch.ops.aten.add.Tensor(add_tensor_103, mul_tensor_77);  add_tensor_103 = mul_tensor_77 = None
        mul_scalar_12 = torch.ops.aten.mul.Scalar(std_correction_17, 2)
        div_tensor_66 = torch.ops.aten.div.Tensor(sum_dim_int_list_45, mul_scalar_12);  sum_dim_int_list_45 = mul_scalar_12 = None
        eq_scalar_18 = torch.ops.aten.eq.Scalar(std_correction_17, 0);  std_correction_17 = None
        masked_fill__scalar_6 = torch.ops.aten.masked_fill_.Scalar(div_tensor_66, eq_scalar_18, 0);  div_tensor_66 = eq_scalar_18 = None
        mul_scalar_13 = torch.ops.aten.mul.Scalar(masked_fill__scalar_6, 0.002607561929595828);  masked_fill__scalar_6 = None
        mean_dim_30 = torch.ops.aten.mean.dim(add_tensor_52, [-1], True)
        sub_tensor_30 = torch.ops.aten.sub.Tensor(add_tensor_52, mean_dim_30);  add_tensor_52 = mean_dim_30 = None
        mul_tensor_79 = torch.ops.aten.mul.Tensor(mul_scalar_13, sub_tensor_30);  mul_scalar_13 = sub_tensor_30 = None
        add_tensor_107 = torch.ops.aten.add.Tensor(add_tensor_106, mul_tensor_79);  add_tensor_106 = mul_tensor_79 = None
        expand_default_54 = torch.ops.aten.expand.default(sum_dim_int_list_47, [16, 128, 768]);  sum_dim_int_list_47 = None
        div_scalar_6 = torch.ops.aten.div.Scalar(expand_default_54, 768);  expand_default_54 = None
        add_tensor_108 = torch.ops.aten.add.Tensor(add_tensor_107, div_scalar_6);  add_tensor_107 = div_scalar_6 = None
        view_default_296 = torch.ops.aten.view.default(add_tensor_108, [2048, 768])
        t_default_152 = torch.ops.aten.t.default(t_default_51);  t_default_51 = None
        mm_default_40 = torch.ops.aten.mm.default(view_default_296, t_default_152);  t_default_152 = None
        t_default_153 = torch.ops.aten.t.default(view_default_296)
        mm_default_41 = torch.ops.aten.mm.default(t_default_153, view_default_147);  t_default_153 = view_default_147 = None
        t_default_154 = torch.ops.aten.t.default(mm_default_41);  mm_default_41 = None
        sum_dim_int_list_48 = torch.ops.aten.sum.dim_IntList(view_default_296, [0], True);  view_default_296 = None
        view_default_297 = torch.ops.aten.view.default(sum_dim_int_list_48, [768]);  sum_dim_int_list_48 = None
        t_default_155 = torch.ops.aten.t.default(t_default_154);  t_default_154 = None
        view_default_298 = torch.ops.aten.view.default(mm_default_40, [16, 128, 768]);  mm_default_40 = None
        view_default_299 = torch.ops.aten.view.default(view_default_298, [16, 128, 12, 64]);  view_default_298 = None
        transpose_int_87 = torch.ops.aten.transpose.int(view_default_299, 1, 2);  view_default_299 = None
        clone_default_60 = torch.ops.aten.clone.default(transpose_int_87, memory_format = torch.contiguous_format);  transpose_int_87 = None
        _unsafe_view_default_72 = torch.ops.aten._unsafe_view.default(clone_default_60, [192, 128, 64]);  clone_default_60 = None
        transpose_int_88 = torch.ops.aten.transpose.int(view_default_145, 1, 2);  view_default_145 = None
        bmm_default_36 = torch.ops.aten.bmm.default(transpose_int_88, _unsafe_view_default_72);  transpose_int_88 = None
        transpose_int_89 = torch.ops.aten.transpose.int(_unsafe_view_default_43, 1, 2);  _unsafe_view_default_43 = None
        bmm_default_37 = torch.ops.aten.bmm.default(_unsafe_view_default_72, transpose_int_89);  _unsafe_view_default_72 = transpose_int_89 = None
        view_default_300 = torch.ops.aten.view.default(bmm_default_36, [16, 12, 128, 64]);  bmm_default_36 = None
        view_default_301 = torch.ops.aten.view.default(bmm_default_37, [16, 12, 128, 128]);  bmm_default_37 = None
        _softmax_backward_data_default_3 = torch.ops.aten._softmax_backward_data.default(view_default_301, _softmax_default_8, -1, torch.float32);  view_default_301 = _softmax_default_8 = None
        where_scalar_self_15 = torch.ops.aten.where.ScalarSelf(eq_scalar_8, 0.0, _softmax_backward_data_default_3);  eq_scalar_8 = _softmax_backward_data_default_3 = None
        div_tensor_67 = torch.ops.aten.div.Tensor(where_scalar_self_15, 8.0);  where_scalar_self_15 = None
        view_default_302 = torch.ops.aten.view.default(div_tensor_67, [192, 128, 128]);  div_tensor_67 = None
        transpose_int_90 = torch.ops.aten.transpose.int(_unsafe_view_default_40, 1, 2);  _unsafe_view_default_40 = None
        bmm_default_38 = torch.ops.aten.bmm.default(transpose_int_90, view_default_302);  transpose_int_90 = None
        transpose_int_91 = torch.ops.aten.transpose.int(_unsafe_view_default_41, 1, 2);  _unsafe_view_default_41 = None
        bmm_default_39 = torch.ops.aten.bmm.default(view_default_302, transpose_int_91);  view_default_302 = transpose_int_91 = None
        view_default_303 = torch.ops.aten.view.default(bmm_default_38, [16, 12, 64, 128]);  bmm_default_38 = None
        view_default_304 = torch.ops.aten.view.default(bmm_default_39, [16, 12, 128, 64]);  bmm_default_39 = None
        transpose_int_92 = torch.ops.aten.transpose.int(view_default_303, -2, -1);  view_default_303 = None
        transpose_int_93 = torch.ops.aten.transpose.int(view_default_300, 1, 2);  view_default_300 = None
        clone_default_61 = torch.ops.aten.clone.default(transpose_int_93, memory_format = torch.contiguous_format);  transpose_int_93 = None
        _unsafe_view_default_73 = torch.ops.aten._unsafe_view.default(clone_default_61, [16, 128, 768]);  clone_default_61 = None
        view_default_305 = torch.ops.aten.view.default(_unsafe_view_default_73, [2048, 768]);  _unsafe_view_default_73 = None
        t_default_156 = torch.ops.aten.t.default(t_default_50);  t_default_50 = None
        mm_default_42 = torch.ops.aten.mm.default(view_default_305, t_default_156);  t_default_156 = None
        t_default_157 = torch.ops.aten.t.default(view_default_305)
        mm_default_43 = torch.ops.aten.mm.default(t_default_157, view_default_142);  t_default_157 = view_default_142 = None
        t_default_158 = torch.ops.aten.t.default(mm_default_43);  mm_default_43 = None
        sum_dim_int_list_49 = torch.ops.aten.sum.dim_IntList(view_default_305, [0], True);  view_default_305 = None
        view_default_306 = torch.ops.aten.view.default(sum_dim_int_list_49, [768]);  sum_dim_int_list_49 = None
        t_default_159 = torch.ops.aten.t.default(t_default_158);  t_default_158 = None
        view_default_307 = torch.ops.aten.view.default(mm_default_42, [16, 128, 768]);  mm_default_42 = None
        transpose_int_94 = torch.ops.aten.transpose.int(transpose_int_92, 1, 2);  transpose_int_92 = None
        view_default_308 = torch.ops.aten.view.default(transpose_int_94, [16, 128, 768]);  transpose_int_94 = None
        clone_default_62 = torch.ops.aten.clone.default(view_default_308, memory_format = torch.contiguous_format);  view_default_308 = None
        _unsafe_view_default_74 = torch.ops.aten._unsafe_view.default(clone_default_62, [2048, 768]);  clone_default_62 = None
        t_default_160 = torch.ops.aten.t.default(t_default_49);  t_default_49 = None
        mm_default_44 = torch.ops.aten.mm.default(_unsafe_view_default_74, t_default_160);  t_default_160 = None
        t_default_161 = torch.ops.aten.t.default(_unsafe_view_default_74)
        mm_default_45 = torch.ops.aten.mm.default(t_default_161, view_default_139);  t_default_161 = view_default_139 = None
        t_default_162 = torch.ops.aten.t.default(mm_default_45);  mm_default_45 = None
        sum_dim_int_list_50 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_74, [0], True);  _unsafe_view_default_74 = None
        view_default_309 = torch.ops.aten.view.default(sum_dim_int_list_50, [768]);  sum_dim_int_list_50 = None
        t_default_163 = torch.ops.aten.t.default(t_default_162);  t_default_162 = None
        view_default_310 = torch.ops.aten.view.default(mm_default_44, [16, 128, 768]);  mm_default_44 = None
        add_tensor_109 = torch.ops.aten.add.Tensor(view_default_307, view_default_310);  view_default_307 = view_default_310 = None
        transpose_int_95 = torch.ops.aten.transpose.int(view_default_304, 1, 2);  view_default_304 = None
        clone_default_63 = torch.ops.aten.clone.default(transpose_int_95, memory_format = torch.contiguous_format);  transpose_int_95 = None
        _unsafe_view_default_75 = torch.ops.aten._unsafe_view.default(clone_default_63, [16, 128, 768]);  clone_default_63 = None
        view_default_311 = torch.ops.aten.view.default(_unsafe_view_default_75, [2048, 768]);  _unsafe_view_default_75 = None
        t_default_164 = torch.ops.aten.t.default(t_default_48);  t_default_48 = None
        mm_default_46 = torch.ops.aten.mm.default(view_default_311, t_default_164);  t_default_164 = None
        t_default_165 = torch.ops.aten.t.default(view_default_311)
        mm_default_47 = torch.ops.aten.mm.default(t_default_165, view_default_136);  t_default_165 = view_default_136 = None
        t_default_166 = torch.ops.aten.t.default(mm_default_47);  mm_default_47 = None
        sum_dim_int_list_51 = torch.ops.aten.sum.dim_IntList(view_default_311, [0], True);  view_default_311 = None
        view_default_312 = torch.ops.aten.view.default(sum_dim_int_list_51, [768]);  sum_dim_int_list_51 = None
        t_default_167 = torch.ops.aten.t.default(t_default_166);  t_default_166 = None
        view_default_313 = torch.ops.aten.view.default(mm_default_46, [16, 128, 768]);  mm_default_46 = None
        add_tensor_110 = torch.ops.aten.add.Tensor(add_tensor_109, view_default_313);  add_tensor_109 = view_default_313 = None
        sum_dim_int_list_52 = torch.ops.aten.sum.dim_IntList(add_tensor_110, [0, 1], True)
        view_default_314 = torch.ops.aten.view.default(sum_dim_int_list_52, [768]);  sum_dim_int_list_52 = None
        neg_default_14 = torch.ops.aten.neg.default(add_tensor_110)
        div_tensor_68 = torch.ops.aten.div.Tensor(mul_tensor_16, add_tensor_50);  mul_tensor_16 = None
        div_tensor_69 = torch.ops.aten.div.Tensor(div_tensor_68, add_tensor_50);  div_tensor_68 = None
        mul_tensor_80 = torch.ops.aten.mul.Tensor(neg_default_14, div_tensor_69);  neg_default_14 = div_tensor_69 = None
        div_tensor_70 = torch.ops.aten.div.Tensor(add_tensor_110, add_tensor_50);  add_tensor_110 = add_tensor_50 = None
        sum_dim_int_list_53 = torch.ops.aten.sum.dim_IntList(mul_tensor_80, [2], True);  mul_tensor_80 = None
        mul_tensor_81 = torch.ops.aten.mul.Tensor(div_tensor_70, primals_168);  primals_168 = None
        mul_tensor_82 = torch.ops.aten.mul.Tensor(div_tensor_70, sub_tensor_16);  div_tensor_70 = sub_tensor_16 = None
        sum_dim_int_list_54 = torch.ops.aten.sum.dim_IntList(mul_tensor_82, [0, 1], True);  mul_tensor_82 = None
        view_default_315 = torch.ops.aten.view.default(sum_dim_int_list_54, [768]);  sum_dim_int_list_54 = None
        neg_default_15 = torch.ops.aten.neg.default(mul_tensor_81)
        sum_dim_int_list_55 = torch.ops.aten.sum.dim_IntList(neg_default_15, [2], True);  neg_default_15 = None
        add_tensor_111 = torch.ops.aten.add.Tensor(add_tensor_108, mul_tensor_81);  add_tensor_108 = mul_tensor_81 = None
        mul_scalar_14 = torch.ops.aten.mul.Scalar(std_correction_16, 2)
        div_tensor_71 = torch.ops.aten.div.Tensor(sum_dim_int_list_53, mul_scalar_14);  sum_dim_int_list_53 = mul_scalar_14 = None
        eq_scalar_19 = torch.ops.aten.eq.Scalar(std_correction_16, 0);  std_correction_16 = None
        masked_fill__scalar_7 = torch.ops.aten.masked_fill_.Scalar(div_tensor_71, eq_scalar_19, 0);  div_tensor_71 = eq_scalar_19 = None
        mul_scalar_15 = torch.ops.aten.mul.Scalar(masked_fill__scalar_7, 0.002607561929595828);  masked_fill__scalar_7 = None
        mean_dim_31 = torch.ops.aten.mean.dim(add_tensor_49, [-1], True)
        sub_tensor_31 = torch.ops.aten.sub.Tensor(add_tensor_49, mean_dim_31);  add_tensor_49 = mean_dim_31 = None
        mul_tensor_83 = torch.ops.aten.mul.Tensor(mul_scalar_15, sub_tensor_31);  mul_scalar_15 = sub_tensor_31 = None
        add_tensor_112 = torch.ops.aten.add.Tensor(add_tensor_111, mul_tensor_83);  add_tensor_111 = mul_tensor_83 = None
        expand_default_55 = torch.ops.aten.expand.default(sum_dim_int_list_55, [16, 128, 768]);  sum_dim_int_list_55 = None
        div_scalar_7 = torch.ops.aten.div.Scalar(expand_default_55, 768);  expand_default_55 = None
        add_tensor_113 = torch.ops.aten.add.Tensor(add_tensor_112, div_scalar_7);  add_tensor_112 = div_scalar_7 = None
        view_default_316 = torch.ops.aten.view.default(add_tensor_113, [2048, 768])
        t_default_168 = torch.ops.aten.t.default(t_default_47);  t_default_47 = None
        mm_default_48 = torch.ops.aten.mm.default(view_default_316, t_default_168);  t_default_168 = None
        t_default_169 = torch.ops.aten.t.default(view_default_316)
        mm_default_49 = torch.ops.aten.mm.default(t_default_169, view_default_134);  t_default_169 = view_default_134 = None
        t_default_170 = torch.ops.aten.t.default(mm_default_49);  mm_default_49 = None
        sum_dim_int_list_56 = torch.ops.aten.sum.dim_IntList(view_default_316, [0], True);  view_default_316 = None
        view_default_317 = torch.ops.aten.view.default(sum_dim_int_list_56, [768]);  sum_dim_int_list_56 = None
        t_default_171 = torch.ops.aten.t.default(t_default_170);  t_default_170 = None
        view_default_318 = torch.ops.aten.view.default(mm_default_48, [16, 128, 3072]);  mm_default_48 = None
        to_dtype_12 = torch.ops.aten.to.dtype(view_default_318, torch.float32);  view_default_318 = None
        to_dtype_13 = torch.ops.aten.to.dtype(view_default_133, torch.float32);  view_default_133 = None
        mul_tensor_84 = torch.ops.aten.mul.Tensor(to_dtype_13, 0.7071067811865476)
        erf_default_4 = torch.ops.aten.erf.default(mul_tensor_84);  mul_tensor_84 = None
        add_tensor_114 = torch.ops.aten.add.Tensor(erf_default_4, 1);  erf_default_4 = None
        mul_tensor_85 = torch.ops.aten.mul.Tensor(add_tensor_114, 0.5);  add_tensor_114 = None
        mul_tensor_86 = torch.ops.aten.mul.Tensor(to_dtype_13, to_dtype_13)
        mul_tensor_87 = torch.ops.aten.mul.Tensor(mul_tensor_86, -0.5);  mul_tensor_86 = None
        exp_default_4 = torch.ops.aten.exp.default(mul_tensor_87);  mul_tensor_87 = None
        mul_tensor_88 = torch.ops.aten.mul.Tensor(exp_default_4, 0.3989422804014327);  exp_default_4 = None
        mul_tensor_89 = torch.ops.aten.mul.Tensor(to_dtype_13, mul_tensor_88);  to_dtype_13 = mul_tensor_88 = None
        add_tensor_115 = torch.ops.aten.add.Tensor(mul_tensor_85, mul_tensor_89);  mul_tensor_85 = mul_tensor_89 = None
        mul_tensor_90 = torch.ops.aten.mul.Tensor(to_dtype_12, add_tensor_115);  to_dtype_12 = add_tensor_115 = None
        to_dtype_14 = torch.ops.aten.to.dtype(mul_tensor_90, torch.float32);  mul_tensor_90 = None
        view_default_319 = torch.ops.aten.view.default(to_dtype_14, [2048, 3072]);  to_dtype_14 = None
        t_default_172 = torch.ops.aten.t.default(t_default_46);  t_default_46 = None
        mm_default_50 = torch.ops.aten.mm.default(view_default_319, t_default_172);  t_default_172 = None
        t_default_173 = torch.ops.aten.t.default(view_default_319)
        mm_default_51 = torch.ops.aten.mm.default(t_default_173, view_default_132);  t_default_173 = view_default_132 = None
        t_default_174 = torch.ops.aten.t.default(mm_default_51);  mm_default_51 = None
        sum_dim_int_list_57 = torch.ops.aten.sum.dim_IntList(view_default_319, [0], True);  view_default_319 = None
        view_default_320 = torch.ops.aten.view.default(sum_dim_int_list_57, [3072]);  sum_dim_int_list_57 = None
        t_default_175 = torch.ops.aten.t.default(t_default_174);  t_default_174 = None
        view_default_321 = torch.ops.aten.view.default(mm_default_50, [16, 128, 768]);  mm_default_50 = None
        sum_dim_int_list_58 = torch.ops.aten.sum.dim_IntList(view_default_321, [0, 1], True)
        view_default_322 = torch.ops.aten.view.default(sum_dim_int_list_58, [768]);  sum_dim_int_list_58 = None
        neg_default_16 = torch.ops.aten.neg.default(view_default_321)
        div_tensor_72 = torch.ops.aten.div.Tensor(mul_tensor_15, add_tensor_47);  mul_tensor_15 = None
        div_tensor_73 = torch.ops.aten.div.Tensor(div_tensor_72, add_tensor_47);  div_tensor_72 = None
        mul_tensor_91 = torch.ops.aten.mul.Tensor(neg_default_16, div_tensor_73);  neg_default_16 = div_tensor_73 = None
        div_tensor_74 = torch.ops.aten.div.Tensor(view_default_321, add_tensor_47);  view_default_321 = add_tensor_47 = None
        sum_dim_int_list_59 = torch.ops.aten.sum.dim_IntList(mul_tensor_91, [2], True);  mul_tensor_91 = None
        mul_tensor_92 = torch.ops.aten.mul.Tensor(div_tensor_74, primals_162);  primals_162 = None
        mul_tensor_93 = torch.ops.aten.mul.Tensor(div_tensor_74, sub_tensor_15);  div_tensor_74 = sub_tensor_15 = None
        sum_dim_int_list_60 = torch.ops.aten.sum.dim_IntList(mul_tensor_93, [0, 1], True);  mul_tensor_93 = None
        view_default_323 = torch.ops.aten.view.default(sum_dim_int_list_60, [768]);  sum_dim_int_list_60 = None
        neg_default_17 = torch.ops.aten.neg.default(mul_tensor_92)
        sum_dim_int_list_61 = torch.ops.aten.sum.dim_IntList(neg_default_17, [2], True);  neg_default_17 = None
        add_tensor_116 = torch.ops.aten.add.Tensor(add_tensor_113, mul_tensor_92);  add_tensor_113 = mul_tensor_92 = None
        mul_scalar_16 = torch.ops.aten.mul.Scalar(std_correction_15, 2)
        div_tensor_75 = torch.ops.aten.div.Tensor(sum_dim_int_list_59, mul_scalar_16);  sum_dim_int_list_59 = mul_scalar_16 = None
        eq_scalar_20 = torch.ops.aten.eq.Scalar(std_correction_15, 0);  std_correction_15 = None
        masked_fill__scalar_8 = torch.ops.aten.masked_fill_.Scalar(div_tensor_75, eq_scalar_20, 0);  div_tensor_75 = eq_scalar_20 = None
        mul_scalar_17 = torch.ops.aten.mul.Scalar(masked_fill__scalar_8, 0.002607561929595828);  masked_fill__scalar_8 = None
        mean_dim_32 = torch.ops.aten.mean.dim(add_tensor_46, [-1], True)
        sub_tensor_32 = torch.ops.aten.sub.Tensor(add_tensor_46, mean_dim_32);  add_tensor_46 = mean_dim_32 = None
        mul_tensor_94 = torch.ops.aten.mul.Tensor(mul_scalar_17, sub_tensor_32);  mul_scalar_17 = sub_tensor_32 = None
        add_tensor_117 = torch.ops.aten.add.Tensor(add_tensor_116, mul_tensor_94);  add_tensor_116 = mul_tensor_94 = None
        expand_default_56 = torch.ops.aten.expand.default(sum_dim_int_list_61, [16, 128, 768]);  sum_dim_int_list_61 = None
        div_scalar_8 = torch.ops.aten.div.Scalar(expand_default_56, 768);  expand_default_56 = None
        add_tensor_118 = torch.ops.aten.add.Tensor(add_tensor_117, div_scalar_8);  add_tensor_117 = div_scalar_8 = None
        view_default_324 = torch.ops.aten.view.default(add_tensor_118, [2048, 768])
        t_default_176 = torch.ops.aten.t.default(t_default_45);  t_default_45 = None
        mm_default_52 = torch.ops.aten.mm.default(view_default_324, t_default_176);  t_default_176 = None
        t_default_177 = torch.ops.aten.t.default(view_default_324)
        mm_default_53 = torch.ops.aten.mm.default(t_default_177, view_default_130);  t_default_177 = view_default_130 = None
        t_default_178 = torch.ops.aten.t.default(mm_default_53);  mm_default_53 = None
        sum_dim_int_list_62 = torch.ops.aten.sum.dim_IntList(view_default_324, [0], True);  view_default_324 = None
        view_default_325 = torch.ops.aten.view.default(sum_dim_int_list_62, [768]);  sum_dim_int_list_62 = None
        t_default_179 = torch.ops.aten.t.default(t_default_178);  t_default_178 = None
        view_default_326 = torch.ops.aten.view.default(mm_default_52, [16, 128, 768]);  mm_default_52 = None
        view_default_327 = torch.ops.aten.view.default(view_default_326, [16, 128, 12, 64]);  view_default_326 = None
        transpose_int_96 = torch.ops.aten.transpose.int(view_default_327, 1, 2);  view_default_327 = None
        clone_default_64 = torch.ops.aten.clone.default(transpose_int_96, memory_format = torch.contiguous_format);  transpose_int_96 = None
        _unsafe_view_default_76 = torch.ops.aten._unsafe_view.default(clone_default_64, [192, 128, 64]);  clone_default_64 = None
        transpose_int_97 = torch.ops.aten.transpose.int(view_default_128, 1, 2);  view_default_128 = None
        bmm_default_40 = torch.ops.aten.bmm.default(transpose_int_97, _unsafe_view_default_76);  transpose_int_97 = None
        transpose_int_98 = torch.ops.aten.transpose.int(_unsafe_view_default_38, 1, 2);  _unsafe_view_default_38 = None
        bmm_default_41 = torch.ops.aten.bmm.default(_unsafe_view_default_76, transpose_int_98);  _unsafe_view_default_76 = transpose_int_98 = None
        view_default_328 = torch.ops.aten.view.default(bmm_default_40, [16, 12, 128, 64]);  bmm_default_40 = None
        view_default_329 = torch.ops.aten.view.default(bmm_default_41, [16, 12, 128, 128]);  bmm_default_41 = None
        _softmax_backward_data_default_4 = torch.ops.aten._softmax_backward_data.default(view_default_329, _softmax_default_7, -1, torch.float32);  view_default_329 = _softmax_default_7 = None
        where_scalar_self_16 = torch.ops.aten.where.ScalarSelf(eq_scalar_7, 0.0, _softmax_backward_data_default_4);  eq_scalar_7 = _softmax_backward_data_default_4 = None
        div_tensor_76 = torch.ops.aten.div.Tensor(where_scalar_self_16, 8.0);  where_scalar_self_16 = None
        view_default_330 = torch.ops.aten.view.default(div_tensor_76, [192, 128, 128]);  div_tensor_76 = None
        transpose_int_99 = torch.ops.aten.transpose.int(_unsafe_view_default_35, 1, 2);  _unsafe_view_default_35 = None
        bmm_default_42 = torch.ops.aten.bmm.default(transpose_int_99, view_default_330);  transpose_int_99 = None
        transpose_int_100 = torch.ops.aten.transpose.int(_unsafe_view_default_36, 1, 2);  _unsafe_view_default_36 = None
        bmm_default_43 = torch.ops.aten.bmm.default(view_default_330, transpose_int_100);  view_default_330 = transpose_int_100 = None
        view_default_331 = torch.ops.aten.view.default(bmm_default_42, [16, 12, 64, 128]);  bmm_default_42 = None
        view_default_332 = torch.ops.aten.view.default(bmm_default_43, [16, 12, 128, 64]);  bmm_default_43 = None
        transpose_int_101 = torch.ops.aten.transpose.int(view_default_331, -2, -1);  view_default_331 = None
        transpose_int_102 = torch.ops.aten.transpose.int(view_default_328, 1, 2);  view_default_328 = None
        clone_default_65 = torch.ops.aten.clone.default(transpose_int_102, memory_format = torch.contiguous_format);  transpose_int_102 = None
        _unsafe_view_default_77 = torch.ops.aten._unsafe_view.default(clone_default_65, [16, 128, 768]);  clone_default_65 = None
        view_default_333 = torch.ops.aten.view.default(_unsafe_view_default_77, [2048, 768]);  _unsafe_view_default_77 = None
        t_default_180 = torch.ops.aten.t.default(t_default_44);  t_default_44 = None
        mm_default_54 = torch.ops.aten.mm.default(view_default_333, t_default_180);  t_default_180 = None
        t_default_181 = torch.ops.aten.t.default(view_default_333)
        mm_default_55 = torch.ops.aten.mm.default(t_default_181, view_default_125);  t_default_181 = view_default_125 = None
        t_default_182 = torch.ops.aten.t.default(mm_default_55);  mm_default_55 = None
        sum_dim_int_list_63 = torch.ops.aten.sum.dim_IntList(view_default_333, [0], True);  view_default_333 = None
        view_default_334 = torch.ops.aten.view.default(sum_dim_int_list_63, [768]);  sum_dim_int_list_63 = None
        t_default_183 = torch.ops.aten.t.default(t_default_182);  t_default_182 = None
        view_default_335 = torch.ops.aten.view.default(mm_default_54, [16, 128, 768]);  mm_default_54 = None
        transpose_int_103 = torch.ops.aten.transpose.int(transpose_int_101, 1, 2);  transpose_int_101 = None
        view_default_336 = torch.ops.aten.view.default(transpose_int_103, [16, 128, 768]);  transpose_int_103 = None
        clone_default_66 = torch.ops.aten.clone.default(view_default_336, memory_format = torch.contiguous_format);  view_default_336 = None
        _unsafe_view_default_78 = torch.ops.aten._unsafe_view.default(clone_default_66, [2048, 768]);  clone_default_66 = None
        t_default_184 = torch.ops.aten.t.default(t_default_43);  t_default_43 = None
        mm_default_56 = torch.ops.aten.mm.default(_unsafe_view_default_78, t_default_184);  t_default_184 = None
        t_default_185 = torch.ops.aten.t.default(_unsafe_view_default_78)
        mm_default_57 = torch.ops.aten.mm.default(t_default_185, view_default_122);  t_default_185 = view_default_122 = None
        t_default_186 = torch.ops.aten.t.default(mm_default_57);  mm_default_57 = None
        sum_dim_int_list_64 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_78, [0], True);  _unsafe_view_default_78 = None
        view_default_337 = torch.ops.aten.view.default(sum_dim_int_list_64, [768]);  sum_dim_int_list_64 = None
        t_default_187 = torch.ops.aten.t.default(t_default_186);  t_default_186 = None
        view_default_338 = torch.ops.aten.view.default(mm_default_56, [16, 128, 768]);  mm_default_56 = None
        add_tensor_119 = torch.ops.aten.add.Tensor(view_default_335, view_default_338);  view_default_335 = view_default_338 = None
        transpose_int_104 = torch.ops.aten.transpose.int(view_default_332, 1, 2);  view_default_332 = None
        clone_default_67 = torch.ops.aten.clone.default(transpose_int_104, memory_format = torch.contiguous_format);  transpose_int_104 = None
        _unsafe_view_default_79 = torch.ops.aten._unsafe_view.default(clone_default_67, [16, 128, 768]);  clone_default_67 = None
        view_default_339 = torch.ops.aten.view.default(_unsafe_view_default_79, [2048, 768]);  _unsafe_view_default_79 = None
        t_default_188 = torch.ops.aten.t.default(t_default_42);  t_default_42 = None
        mm_default_58 = torch.ops.aten.mm.default(view_default_339, t_default_188);  t_default_188 = None
        t_default_189 = torch.ops.aten.t.default(view_default_339)
        mm_default_59 = torch.ops.aten.mm.default(t_default_189, view_default_119);  t_default_189 = view_default_119 = None
        t_default_190 = torch.ops.aten.t.default(mm_default_59);  mm_default_59 = None
        sum_dim_int_list_65 = torch.ops.aten.sum.dim_IntList(view_default_339, [0], True);  view_default_339 = None
        view_default_340 = torch.ops.aten.view.default(sum_dim_int_list_65, [768]);  sum_dim_int_list_65 = None
        t_default_191 = torch.ops.aten.t.default(t_default_190);  t_default_190 = None
        view_default_341 = torch.ops.aten.view.default(mm_default_58, [16, 128, 768]);  mm_default_58 = None
        add_tensor_120 = torch.ops.aten.add.Tensor(add_tensor_119, view_default_341);  add_tensor_119 = view_default_341 = None
        sum_dim_int_list_66 = torch.ops.aten.sum.dim_IntList(add_tensor_120, [0, 1], True)
        view_default_342 = torch.ops.aten.view.default(sum_dim_int_list_66, [768]);  sum_dim_int_list_66 = None
        neg_default_18 = torch.ops.aten.neg.default(add_tensor_120)
        div_tensor_77 = torch.ops.aten.div.Tensor(mul_tensor_14, add_tensor_44);  mul_tensor_14 = None
        div_tensor_78 = torch.ops.aten.div.Tensor(div_tensor_77, add_tensor_44);  div_tensor_77 = None
        mul_tensor_95 = torch.ops.aten.mul.Tensor(neg_default_18, div_tensor_78);  neg_default_18 = div_tensor_78 = None
        div_tensor_79 = torch.ops.aten.div.Tensor(add_tensor_120, add_tensor_44);  add_tensor_120 = add_tensor_44 = None
        sum_dim_int_list_67 = torch.ops.aten.sum.dim_IntList(mul_tensor_95, [2], True);  mul_tensor_95 = None
        mul_tensor_96 = torch.ops.aten.mul.Tensor(div_tensor_79, primals_152);  primals_152 = None
        mul_tensor_97 = torch.ops.aten.mul.Tensor(div_tensor_79, sub_tensor_14);  div_tensor_79 = sub_tensor_14 = None
        sum_dim_int_list_68 = torch.ops.aten.sum.dim_IntList(mul_tensor_97, [0, 1], True);  mul_tensor_97 = None
        view_default_343 = torch.ops.aten.view.default(sum_dim_int_list_68, [768]);  sum_dim_int_list_68 = None
        neg_default_19 = torch.ops.aten.neg.default(mul_tensor_96)
        sum_dim_int_list_69 = torch.ops.aten.sum.dim_IntList(neg_default_19, [2], True);  neg_default_19 = None
        add_tensor_121 = torch.ops.aten.add.Tensor(add_tensor_118, mul_tensor_96);  add_tensor_118 = mul_tensor_96 = None
        mul_scalar_18 = torch.ops.aten.mul.Scalar(std_correction_14, 2)
        div_tensor_80 = torch.ops.aten.div.Tensor(sum_dim_int_list_67, mul_scalar_18);  sum_dim_int_list_67 = mul_scalar_18 = None
        eq_scalar_21 = torch.ops.aten.eq.Scalar(std_correction_14, 0);  std_correction_14 = None
        masked_fill__scalar_9 = torch.ops.aten.masked_fill_.Scalar(div_tensor_80, eq_scalar_21, 0);  div_tensor_80 = eq_scalar_21 = None
        mul_scalar_19 = torch.ops.aten.mul.Scalar(masked_fill__scalar_9, 0.002607561929595828);  masked_fill__scalar_9 = None
        mean_dim_33 = torch.ops.aten.mean.dim(add_tensor_43, [-1], True)
        sub_tensor_33 = torch.ops.aten.sub.Tensor(add_tensor_43, mean_dim_33);  add_tensor_43 = mean_dim_33 = None
        mul_tensor_98 = torch.ops.aten.mul.Tensor(mul_scalar_19, sub_tensor_33);  mul_scalar_19 = sub_tensor_33 = None
        add_tensor_122 = torch.ops.aten.add.Tensor(add_tensor_121, mul_tensor_98);  add_tensor_121 = mul_tensor_98 = None
        expand_default_57 = torch.ops.aten.expand.default(sum_dim_int_list_69, [16, 128, 768]);  sum_dim_int_list_69 = None
        div_scalar_9 = torch.ops.aten.div.Scalar(expand_default_57, 768);  expand_default_57 = None
        add_tensor_123 = torch.ops.aten.add.Tensor(add_tensor_122, div_scalar_9);  add_tensor_122 = div_scalar_9 = None
        view_default_344 = torch.ops.aten.view.default(add_tensor_123, [2048, 768])
        t_default_192 = torch.ops.aten.t.default(t_default_41);  t_default_41 = None
        mm_default_60 = torch.ops.aten.mm.default(view_default_344, t_default_192);  t_default_192 = None
        t_default_193 = torch.ops.aten.t.default(view_default_344)
        mm_default_61 = torch.ops.aten.mm.default(t_default_193, view_default_117);  t_default_193 = view_default_117 = None
        t_default_194 = torch.ops.aten.t.default(mm_default_61);  mm_default_61 = None
        sum_dim_int_list_70 = torch.ops.aten.sum.dim_IntList(view_default_344, [0], True);  view_default_344 = None
        view_default_345 = torch.ops.aten.view.default(sum_dim_int_list_70, [768]);  sum_dim_int_list_70 = None
        t_default_195 = torch.ops.aten.t.default(t_default_194);  t_default_194 = None
        view_default_346 = torch.ops.aten.view.default(mm_default_60, [16, 128, 3072]);  mm_default_60 = None
        to_dtype_15 = torch.ops.aten.to.dtype(view_default_346, torch.float32);  view_default_346 = None
        to_dtype_16 = torch.ops.aten.to.dtype(view_default_116, torch.float32);  view_default_116 = None
        mul_tensor_99 = torch.ops.aten.mul.Tensor(to_dtype_16, 0.7071067811865476)
        erf_default_5 = torch.ops.aten.erf.default(mul_tensor_99);  mul_tensor_99 = None
        add_tensor_124 = torch.ops.aten.add.Tensor(erf_default_5, 1);  erf_default_5 = None
        mul_tensor_100 = torch.ops.aten.mul.Tensor(add_tensor_124, 0.5);  add_tensor_124 = None
        mul_tensor_101 = torch.ops.aten.mul.Tensor(to_dtype_16, to_dtype_16)
        mul_tensor_102 = torch.ops.aten.mul.Tensor(mul_tensor_101, -0.5);  mul_tensor_101 = None
        exp_default_5 = torch.ops.aten.exp.default(mul_tensor_102);  mul_tensor_102 = None
        mul_tensor_103 = torch.ops.aten.mul.Tensor(exp_default_5, 0.3989422804014327);  exp_default_5 = None
        mul_tensor_104 = torch.ops.aten.mul.Tensor(to_dtype_16, mul_tensor_103);  to_dtype_16 = mul_tensor_103 = None
        add_tensor_125 = torch.ops.aten.add.Tensor(mul_tensor_100, mul_tensor_104);  mul_tensor_100 = mul_tensor_104 = None
        mul_tensor_105 = torch.ops.aten.mul.Tensor(to_dtype_15, add_tensor_125);  to_dtype_15 = add_tensor_125 = None
        to_dtype_17 = torch.ops.aten.to.dtype(mul_tensor_105, torch.float32);  mul_tensor_105 = None
        view_default_347 = torch.ops.aten.view.default(to_dtype_17, [2048, 3072]);  to_dtype_17 = None
        t_default_196 = torch.ops.aten.t.default(t_default_40);  t_default_40 = None
        mm_default_62 = torch.ops.aten.mm.default(view_default_347, t_default_196);  t_default_196 = None
        t_default_197 = torch.ops.aten.t.default(view_default_347)
        mm_default_63 = torch.ops.aten.mm.default(t_default_197, view_default_115);  t_default_197 = view_default_115 = None
        t_default_198 = torch.ops.aten.t.default(mm_default_63);  mm_default_63 = None
        sum_dim_int_list_71 = torch.ops.aten.sum.dim_IntList(view_default_347, [0], True);  view_default_347 = None
        view_default_348 = torch.ops.aten.view.default(sum_dim_int_list_71, [3072]);  sum_dim_int_list_71 = None
        t_default_199 = torch.ops.aten.t.default(t_default_198);  t_default_198 = None
        view_default_349 = torch.ops.aten.view.default(mm_default_62, [16, 128, 768]);  mm_default_62 = None
        sum_dim_int_list_72 = torch.ops.aten.sum.dim_IntList(view_default_349, [0, 1], True)
        view_default_350 = torch.ops.aten.view.default(sum_dim_int_list_72, [768]);  sum_dim_int_list_72 = None
        neg_default_20 = torch.ops.aten.neg.default(view_default_349)
        div_tensor_81 = torch.ops.aten.div.Tensor(mul_tensor_13, add_tensor_41);  mul_tensor_13 = None
        div_tensor_82 = torch.ops.aten.div.Tensor(div_tensor_81, add_tensor_41);  div_tensor_81 = None
        mul_tensor_106 = torch.ops.aten.mul.Tensor(neg_default_20, div_tensor_82);  neg_default_20 = div_tensor_82 = None
        div_tensor_83 = torch.ops.aten.div.Tensor(view_default_349, add_tensor_41);  view_default_349 = add_tensor_41 = None
        sum_dim_int_list_73 = torch.ops.aten.sum.dim_IntList(mul_tensor_106, [2], True);  mul_tensor_106 = None
        mul_tensor_107 = torch.ops.aten.mul.Tensor(div_tensor_83, primals_146);  primals_146 = None
        mul_tensor_108 = torch.ops.aten.mul.Tensor(div_tensor_83, sub_tensor_13);  div_tensor_83 = sub_tensor_13 = None
        sum_dim_int_list_74 = torch.ops.aten.sum.dim_IntList(mul_tensor_108, [0, 1], True);  mul_tensor_108 = None
        view_default_351 = torch.ops.aten.view.default(sum_dim_int_list_74, [768]);  sum_dim_int_list_74 = None
        neg_default_21 = torch.ops.aten.neg.default(mul_tensor_107)
        sum_dim_int_list_75 = torch.ops.aten.sum.dim_IntList(neg_default_21, [2], True);  neg_default_21 = None
        add_tensor_126 = torch.ops.aten.add.Tensor(add_tensor_123, mul_tensor_107);  add_tensor_123 = mul_tensor_107 = None
        mul_scalar_20 = torch.ops.aten.mul.Scalar(std_correction_13, 2)
        div_tensor_84 = torch.ops.aten.div.Tensor(sum_dim_int_list_73, mul_scalar_20);  sum_dim_int_list_73 = mul_scalar_20 = None
        eq_scalar_22 = torch.ops.aten.eq.Scalar(std_correction_13, 0);  std_correction_13 = None
        masked_fill__scalar_10 = torch.ops.aten.masked_fill_.Scalar(div_tensor_84, eq_scalar_22, 0);  div_tensor_84 = eq_scalar_22 = None
        mul_scalar_21 = torch.ops.aten.mul.Scalar(masked_fill__scalar_10, 0.002607561929595828);  masked_fill__scalar_10 = None
        mean_dim_34 = torch.ops.aten.mean.dim(add_tensor_40, [-1], True)
        sub_tensor_34 = torch.ops.aten.sub.Tensor(add_tensor_40, mean_dim_34);  add_tensor_40 = mean_dim_34 = None
        mul_tensor_109 = torch.ops.aten.mul.Tensor(mul_scalar_21, sub_tensor_34);  mul_scalar_21 = sub_tensor_34 = None
        add_tensor_127 = torch.ops.aten.add.Tensor(add_tensor_126, mul_tensor_109);  add_tensor_126 = mul_tensor_109 = None
        expand_default_58 = torch.ops.aten.expand.default(sum_dim_int_list_75, [16, 128, 768]);  sum_dim_int_list_75 = None
        div_scalar_10 = torch.ops.aten.div.Scalar(expand_default_58, 768);  expand_default_58 = None
        add_tensor_128 = torch.ops.aten.add.Tensor(add_tensor_127, div_scalar_10);  add_tensor_127 = div_scalar_10 = None
        view_default_352 = torch.ops.aten.view.default(add_tensor_128, [2048, 768])
        t_default_200 = torch.ops.aten.t.default(t_default_39);  t_default_39 = None
        mm_default_64 = torch.ops.aten.mm.default(view_default_352, t_default_200);  t_default_200 = None
        t_default_201 = torch.ops.aten.t.default(view_default_352)
        mm_default_65 = torch.ops.aten.mm.default(t_default_201, view_default_113);  t_default_201 = view_default_113 = None
        t_default_202 = torch.ops.aten.t.default(mm_default_65);  mm_default_65 = None
        sum_dim_int_list_76 = torch.ops.aten.sum.dim_IntList(view_default_352, [0], True);  view_default_352 = None
        view_default_353 = torch.ops.aten.view.default(sum_dim_int_list_76, [768]);  sum_dim_int_list_76 = None
        t_default_203 = torch.ops.aten.t.default(t_default_202);  t_default_202 = None
        view_default_354 = torch.ops.aten.view.default(mm_default_64, [16, 128, 768]);  mm_default_64 = None
        view_default_355 = torch.ops.aten.view.default(view_default_354, [16, 128, 12, 64]);  view_default_354 = None
        transpose_int_105 = torch.ops.aten.transpose.int(view_default_355, 1, 2);  view_default_355 = None
        clone_default_68 = torch.ops.aten.clone.default(transpose_int_105, memory_format = torch.contiguous_format);  transpose_int_105 = None
        _unsafe_view_default_80 = torch.ops.aten._unsafe_view.default(clone_default_68, [192, 128, 64]);  clone_default_68 = None
        transpose_int_106 = torch.ops.aten.transpose.int(view_default_111, 1, 2);  view_default_111 = None
        bmm_default_44 = torch.ops.aten.bmm.default(transpose_int_106, _unsafe_view_default_80);  transpose_int_106 = None
        transpose_int_107 = torch.ops.aten.transpose.int(_unsafe_view_default_33, 1, 2);  _unsafe_view_default_33 = None
        bmm_default_45 = torch.ops.aten.bmm.default(_unsafe_view_default_80, transpose_int_107);  _unsafe_view_default_80 = transpose_int_107 = None
        view_default_356 = torch.ops.aten.view.default(bmm_default_44, [16, 12, 128, 64]);  bmm_default_44 = None
        view_default_357 = torch.ops.aten.view.default(bmm_default_45, [16, 12, 128, 128]);  bmm_default_45 = None
        _softmax_backward_data_default_5 = torch.ops.aten._softmax_backward_data.default(view_default_357, _softmax_default_6, -1, torch.float32);  view_default_357 = _softmax_default_6 = None
        where_scalar_self_17 = torch.ops.aten.where.ScalarSelf(eq_scalar_6, 0.0, _softmax_backward_data_default_5);  eq_scalar_6 = _softmax_backward_data_default_5 = None
        div_tensor_85 = torch.ops.aten.div.Tensor(where_scalar_self_17, 8.0);  where_scalar_self_17 = None
        view_default_358 = torch.ops.aten.view.default(div_tensor_85, [192, 128, 128]);  div_tensor_85 = None
        transpose_int_108 = torch.ops.aten.transpose.int(_unsafe_view_default_30, 1, 2);  _unsafe_view_default_30 = None
        bmm_default_46 = torch.ops.aten.bmm.default(transpose_int_108, view_default_358);  transpose_int_108 = None
        transpose_int_109 = torch.ops.aten.transpose.int(_unsafe_view_default_31, 1, 2);  _unsafe_view_default_31 = None
        bmm_default_47 = torch.ops.aten.bmm.default(view_default_358, transpose_int_109);  view_default_358 = transpose_int_109 = None
        view_default_359 = torch.ops.aten.view.default(bmm_default_46, [16, 12, 64, 128]);  bmm_default_46 = None
        view_default_360 = torch.ops.aten.view.default(bmm_default_47, [16, 12, 128, 64]);  bmm_default_47 = None
        transpose_int_110 = torch.ops.aten.transpose.int(view_default_359, -2, -1);  view_default_359 = None
        transpose_int_111 = torch.ops.aten.transpose.int(view_default_356, 1, 2);  view_default_356 = None
        clone_default_69 = torch.ops.aten.clone.default(transpose_int_111, memory_format = torch.contiguous_format);  transpose_int_111 = None
        _unsafe_view_default_81 = torch.ops.aten._unsafe_view.default(clone_default_69, [16, 128, 768]);  clone_default_69 = None
        view_default_361 = torch.ops.aten.view.default(_unsafe_view_default_81, [2048, 768]);  _unsafe_view_default_81 = None
        t_default_204 = torch.ops.aten.t.default(t_default_38);  t_default_38 = None
        mm_default_66 = torch.ops.aten.mm.default(view_default_361, t_default_204);  t_default_204 = None
        t_default_205 = torch.ops.aten.t.default(view_default_361)
        mm_default_67 = torch.ops.aten.mm.default(t_default_205, view_default_108);  t_default_205 = view_default_108 = None
        t_default_206 = torch.ops.aten.t.default(mm_default_67);  mm_default_67 = None
        sum_dim_int_list_77 = torch.ops.aten.sum.dim_IntList(view_default_361, [0], True);  view_default_361 = None
        view_default_362 = torch.ops.aten.view.default(sum_dim_int_list_77, [768]);  sum_dim_int_list_77 = None
        t_default_207 = torch.ops.aten.t.default(t_default_206);  t_default_206 = None
        view_default_363 = torch.ops.aten.view.default(mm_default_66, [16, 128, 768]);  mm_default_66 = None
        transpose_int_112 = torch.ops.aten.transpose.int(transpose_int_110, 1, 2);  transpose_int_110 = None
        view_default_364 = torch.ops.aten.view.default(transpose_int_112, [16, 128, 768]);  transpose_int_112 = None
        clone_default_70 = torch.ops.aten.clone.default(view_default_364, memory_format = torch.contiguous_format);  view_default_364 = None
        _unsafe_view_default_82 = torch.ops.aten._unsafe_view.default(clone_default_70, [2048, 768]);  clone_default_70 = None
        t_default_208 = torch.ops.aten.t.default(t_default_37);  t_default_37 = None
        mm_default_68 = torch.ops.aten.mm.default(_unsafe_view_default_82, t_default_208);  t_default_208 = None
        t_default_209 = torch.ops.aten.t.default(_unsafe_view_default_82)
        mm_default_69 = torch.ops.aten.mm.default(t_default_209, view_default_105);  t_default_209 = view_default_105 = None
        t_default_210 = torch.ops.aten.t.default(mm_default_69);  mm_default_69 = None
        sum_dim_int_list_78 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_82, [0], True);  _unsafe_view_default_82 = None
        view_default_365 = torch.ops.aten.view.default(sum_dim_int_list_78, [768]);  sum_dim_int_list_78 = None
        t_default_211 = torch.ops.aten.t.default(t_default_210);  t_default_210 = None
        view_default_366 = torch.ops.aten.view.default(mm_default_68, [16, 128, 768]);  mm_default_68 = None
        add_tensor_129 = torch.ops.aten.add.Tensor(view_default_363, view_default_366);  view_default_363 = view_default_366 = None
        transpose_int_113 = torch.ops.aten.transpose.int(view_default_360, 1, 2);  view_default_360 = None
        clone_default_71 = torch.ops.aten.clone.default(transpose_int_113, memory_format = torch.contiguous_format);  transpose_int_113 = None
        _unsafe_view_default_83 = torch.ops.aten._unsafe_view.default(clone_default_71, [16, 128, 768]);  clone_default_71 = None
        view_default_367 = torch.ops.aten.view.default(_unsafe_view_default_83, [2048, 768]);  _unsafe_view_default_83 = None
        t_default_212 = torch.ops.aten.t.default(t_default_36);  t_default_36 = None
        mm_default_70 = torch.ops.aten.mm.default(view_default_367, t_default_212);  t_default_212 = None
        t_default_213 = torch.ops.aten.t.default(view_default_367)
        mm_default_71 = torch.ops.aten.mm.default(t_default_213, view_default_102);  t_default_213 = view_default_102 = None
        t_default_214 = torch.ops.aten.t.default(mm_default_71);  mm_default_71 = None
        sum_dim_int_list_79 = torch.ops.aten.sum.dim_IntList(view_default_367, [0], True);  view_default_367 = None
        view_default_368 = torch.ops.aten.view.default(sum_dim_int_list_79, [768]);  sum_dim_int_list_79 = None
        t_default_215 = torch.ops.aten.t.default(t_default_214);  t_default_214 = None
        view_default_369 = torch.ops.aten.view.default(mm_default_70, [16, 128, 768]);  mm_default_70 = None
        add_tensor_130 = torch.ops.aten.add.Tensor(add_tensor_129, view_default_369);  add_tensor_129 = view_default_369 = None
        sum_dim_int_list_80 = torch.ops.aten.sum.dim_IntList(add_tensor_130, [0, 1], True)
        view_default_370 = torch.ops.aten.view.default(sum_dim_int_list_80, [768]);  sum_dim_int_list_80 = None
        neg_default_22 = torch.ops.aten.neg.default(add_tensor_130)
        div_tensor_86 = torch.ops.aten.div.Tensor(mul_tensor_12, add_tensor_38);  mul_tensor_12 = None
        div_tensor_87 = torch.ops.aten.div.Tensor(div_tensor_86, add_tensor_38);  div_tensor_86 = None
        mul_tensor_110 = torch.ops.aten.mul.Tensor(neg_default_22, div_tensor_87);  neg_default_22 = div_tensor_87 = None
        div_tensor_88 = torch.ops.aten.div.Tensor(add_tensor_130, add_tensor_38);  add_tensor_130 = add_tensor_38 = None
        sum_dim_int_list_81 = torch.ops.aten.sum.dim_IntList(mul_tensor_110, [2], True);  mul_tensor_110 = None
        mul_tensor_111 = torch.ops.aten.mul.Tensor(div_tensor_88, primals_136);  primals_136 = None
        mul_tensor_112 = torch.ops.aten.mul.Tensor(div_tensor_88, sub_tensor_12);  div_tensor_88 = sub_tensor_12 = None
        sum_dim_int_list_82 = torch.ops.aten.sum.dim_IntList(mul_tensor_112, [0, 1], True);  mul_tensor_112 = None
        view_default_371 = torch.ops.aten.view.default(sum_dim_int_list_82, [768]);  sum_dim_int_list_82 = None
        neg_default_23 = torch.ops.aten.neg.default(mul_tensor_111)
        sum_dim_int_list_83 = torch.ops.aten.sum.dim_IntList(neg_default_23, [2], True);  neg_default_23 = None
        add_tensor_131 = torch.ops.aten.add.Tensor(add_tensor_128, mul_tensor_111);  add_tensor_128 = mul_tensor_111 = None
        mul_scalar_22 = torch.ops.aten.mul.Scalar(std_correction_12, 2)
        div_tensor_89 = torch.ops.aten.div.Tensor(sum_dim_int_list_81, mul_scalar_22);  sum_dim_int_list_81 = mul_scalar_22 = None
        eq_scalar_23 = torch.ops.aten.eq.Scalar(std_correction_12, 0);  std_correction_12 = None
        masked_fill__scalar_11 = torch.ops.aten.masked_fill_.Scalar(div_tensor_89, eq_scalar_23, 0);  div_tensor_89 = eq_scalar_23 = None
        mul_scalar_23 = torch.ops.aten.mul.Scalar(masked_fill__scalar_11, 0.002607561929595828);  masked_fill__scalar_11 = None
        mean_dim_35 = torch.ops.aten.mean.dim(add_tensor_37, [-1], True)
        sub_tensor_35 = torch.ops.aten.sub.Tensor(add_tensor_37, mean_dim_35);  add_tensor_37 = mean_dim_35 = None
        mul_tensor_113 = torch.ops.aten.mul.Tensor(mul_scalar_23, sub_tensor_35);  mul_scalar_23 = sub_tensor_35 = None
        add_tensor_132 = torch.ops.aten.add.Tensor(add_tensor_131, mul_tensor_113);  add_tensor_131 = mul_tensor_113 = None
        expand_default_59 = torch.ops.aten.expand.default(sum_dim_int_list_83, [16, 128, 768]);  sum_dim_int_list_83 = None
        div_scalar_11 = torch.ops.aten.div.Scalar(expand_default_59, 768);  expand_default_59 = None
        add_tensor_133 = torch.ops.aten.add.Tensor(add_tensor_132, div_scalar_11);  add_tensor_132 = div_scalar_11 = None
        view_default_372 = torch.ops.aten.view.default(add_tensor_133, [2048, 768])
        t_default_216 = torch.ops.aten.t.default(t_default_35);  t_default_35 = None
        mm_default_72 = torch.ops.aten.mm.default(view_default_372, t_default_216);  t_default_216 = None
        t_default_217 = torch.ops.aten.t.default(view_default_372)
        mm_default_73 = torch.ops.aten.mm.default(t_default_217, view_default_100);  t_default_217 = view_default_100 = None
        t_default_218 = torch.ops.aten.t.default(mm_default_73);  mm_default_73 = None
        sum_dim_int_list_84 = torch.ops.aten.sum.dim_IntList(view_default_372, [0], True);  view_default_372 = None
        view_default_373 = torch.ops.aten.view.default(sum_dim_int_list_84, [768]);  sum_dim_int_list_84 = None
        t_default_219 = torch.ops.aten.t.default(t_default_218);  t_default_218 = None
        view_default_374 = torch.ops.aten.view.default(mm_default_72, [16, 128, 3072]);  mm_default_72 = None
        to_dtype_18 = torch.ops.aten.to.dtype(view_default_374, torch.float32);  view_default_374 = None
        to_dtype_19 = torch.ops.aten.to.dtype(view_default_99, torch.float32);  view_default_99 = None
        mul_tensor_114 = torch.ops.aten.mul.Tensor(to_dtype_19, 0.7071067811865476)
        erf_default_6 = torch.ops.aten.erf.default(mul_tensor_114);  mul_tensor_114 = None
        add_tensor_134 = torch.ops.aten.add.Tensor(erf_default_6, 1);  erf_default_6 = None
        mul_tensor_115 = torch.ops.aten.mul.Tensor(add_tensor_134, 0.5);  add_tensor_134 = None
        mul_tensor_116 = torch.ops.aten.mul.Tensor(to_dtype_19, to_dtype_19)
        mul_tensor_117 = torch.ops.aten.mul.Tensor(mul_tensor_116, -0.5);  mul_tensor_116 = None
        exp_default_6 = torch.ops.aten.exp.default(mul_tensor_117);  mul_tensor_117 = None
        mul_tensor_118 = torch.ops.aten.mul.Tensor(exp_default_6, 0.3989422804014327);  exp_default_6 = None
        mul_tensor_119 = torch.ops.aten.mul.Tensor(to_dtype_19, mul_tensor_118);  to_dtype_19 = mul_tensor_118 = None
        add_tensor_135 = torch.ops.aten.add.Tensor(mul_tensor_115, mul_tensor_119);  mul_tensor_115 = mul_tensor_119 = None
        mul_tensor_120 = torch.ops.aten.mul.Tensor(to_dtype_18, add_tensor_135);  to_dtype_18 = add_tensor_135 = None
        to_dtype_20 = torch.ops.aten.to.dtype(mul_tensor_120, torch.float32);  mul_tensor_120 = None
        view_default_375 = torch.ops.aten.view.default(to_dtype_20, [2048, 3072]);  to_dtype_20 = None
        t_default_220 = torch.ops.aten.t.default(t_default_34);  t_default_34 = None
        mm_default_74 = torch.ops.aten.mm.default(view_default_375, t_default_220);  t_default_220 = None
        t_default_221 = torch.ops.aten.t.default(view_default_375)
        mm_default_75 = torch.ops.aten.mm.default(t_default_221, view_default_98);  t_default_221 = view_default_98 = None
        t_default_222 = torch.ops.aten.t.default(mm_default_75);  mm_default_75 = None
        sum_dim_int_list_85 = torch.ops.aten.sum.dim_IntList(view_default_375, [0], True);  view_default_375 = None
        view_default_376 = torch.ops.aten.view.default(sum_dim_int_list_85, [3072]);  sum_dim_int_list_85 = None
        t_default_223 = torch.ops.aten.t.default(t_default_222);  t_default_222 = None
        view_default_377 = torch.ops.aten.view.default(mm_default_74, [16, 128, 768]);  mm_default_74 = None
        sum_dim_int_list_86 = torch.ops.aten.sum.dim_IntList(view_default_377, [0, 1], True)
        view_default_378 = torch.ops.aten.view.default(sum_dim_int_list_86, [768]);  sum_dim_int_list_86 = None
        neg_default_24 = torch.ops.aten.neg.default(view_default_377)
        div_tensor_90 = torch.ops.aten.div.Tensor(mul_tensor_11, add_tensor_35);  mul_tensor_11 = None
        div_tensor_91 = torch.ops.aten.div.Tensor(div_tensor_90, add_tensor_35);  div_tensor_90 = None
        mul_tensor_121 = torch.ops.aten.mul.Tensor(neg_default_24, div_tensor_91);  neg_default_24 = div_tensor_91 = None
        div_tensor_92 = torch.ops.aten.div.Tensor(view_default_377, add_tensor_35);  view_default_377 = add_tensor_35 = None
        sum_dim_int_list_87 = torch.ops.aten.sum.dim_IntList(mul_tensor_121, [2], True);  mul_tensor_121 = None
        mul_tensor_122 = torch.ops.aten.mul.Tensor(div_tensor_92, primals_130);  primals_130 = None
        mul_tensor_123 = torch.ops.aten.mul.Tensor(div_tensor_92, sub_tensor_11);  div_tensor_92 = sub_tensor_11 = None
        sum_dim_int_list_88 = torch.ops.aten.sum.dim_IntList(mul_tensor_123, [0, 1], True);  mul_tensor_123 = None
        view_default_379 = torch.ops.aten.view.default(sum_dim_int_list_88, [768]);  sum_dim_int_list_88 = None
        neg_default_25 = torch.ops.aten.neg.default(mul_tensor_122)
        sum_dim_int_list_89 = torch.ops.aten.sum.dim_IntList(neg_default_25, [2], True);  neg_default_25 = None
        add_tensor_136 = torch.ops.aten.add.Tensor(add_tensor_133, mul_tensor_122);  add_tensor_133 = mul_tensor_122 = None
        mul_scalar_24 = torch.ops.aten.mul.Scalar(std_correction_11, 2)
        div_tensor_93 = torch.ops.aten.div.Tensor(sum_dim_int_list_87, mul_scalar_24);  sum_dim_int_list_87 = mul_scalar_24 = None
        eq_scalar_24 = torch.ops.aten.eq.Scalar(std_correction_11, 0);  std_correction_11 = None
        masked_fill__scalar_12 = torch.ops.aten.masked_fill_.Scalar(div_tensor_93, eq_scalar_24, 0);  div_tensor_93 = eq_scalar_24 = None
        mul_scalar_25 = torch.ops.aten.mul.Scalar(masked_fill__scalar_12, 0.002607561929595828);  masked_fill__scalar_12 = None
        mean_dim_36 = torch.ops.aten.mean.dim(add_tensor_34, [-1], True)
        sub_tensor_36 = torch.ops.aten.sub.Tensor(add_tensor_34, mean_dim_36);  add_tensor_34 = mean_dim_36 = None
        mul_tensor_124 = torch.ops.aten.mul.Tensor(mul_scalar_25, sub_tensor_36);  mul_scalar_25 = sub_tensor_36 = None
        add_tensor_137 = torch.ops.aten.add.Tensor(add_tensor_136, mul_tensor_124);  add_tensor_136 = mul_tensor_124 = None
        expand_default_60 = torch.ops.aten.expand.default(sum_dim_int_list_89, [16, 128, 768]);  sum_dim_int_list_89 = None
        div_scalar_12 = torch.ops.aten.div.Scalar(expand_default_60, 768);  expand_default_60 = None
        add_tensor_138 = torch.ops.aten.add.Tensor(add_tensor_137, div_scalar_12);  add_tensor_137 = div_scalar_12 = None
        view_default_380 = torch.ops.aten.view.default(add_tensor_138, [2048, 768])
        t_default_224 = torch.ops.aten.t.default(t_default_33);  t_default_33 = None
        mm_default_76 = torch.ops.aten.mm.default(view_default_380, t_default_224);  t_default_224 = None
        t_default_225 = torch.ops.aten.t.default(view_default_380)
        mm_default_77 = torch.ops.aten.mm.default(t_default_225, view_default_96);  t_default_225 = view_default_96 = None
        t_default_226 = torch.ops.aten.t.default(mm_default_77);  mm_default_77 = None
        sum_dim_int_list_90 = torch.ops.aten.sum.dim_IntList(view_default_380, [0], True);  view_default_380 = None
        view_default_381 = torch.ops.aten.view.default(sum_dim_int_list_90, [768]);  sum_dim_int_list_90 = None
        t_default_227 = torch.ops.aten.t.default(t_default_226);  t_default_226 = None
        view_default_382 = torch.ops.aten.view.default(mm_default_76, [16, 128, 768]);  mm_default_76 = None
        view_default_383 = torch.ops.aten.view.default(view_default_382, [16, 128, 12, 64]);  view_default_382 = None
        transpose_int_114 = torch.ops.aten.transpose.int(view_default_383, 1, 2);  view_default_383 = None
        clone_default_72 = torch.ops.aten.clone.default(transpose_int_114, memory_format = torch.contiguous_format);  transpose_int_114 = None
        _unsafe_view_default_84 = torch.ops.aten._unsafe_view.default(clone_default_72, [192, 128, 64]);  clone_default_72 = None
        transpose_int_115 = torch.ops.aten.transpose.int(view_default_94, 1, 2);  view_default_94 = None
        bmm_default_48 = torch.ops.aten.bmm.default(transpose_int_115, _unsafe_view_default_84);  transpose_int_115 = None
        transpose_int_116 = torch.ops.aten.transpose.int(_unsafe_view_default_28, 1, 2);  _unsafe_view_default_28 = None
        bmm_default_49 = torch.ops.aten.bmm.default(_unsafe_view_default_84, transpose_int_116);  _unsafe_view_default_84 = transpose_int_116 = None
        view_default_384 = torch.ops.aten.view.default(bmm_default_48, [16, 12, 128, 64]);  bmm_default_48 = None
        view_default_385 = torch.ops.aten.view.default(bmm_default_49, [16, 12, 128, 128]);  bmm_default_49 = None
        _softmax_backward_data_default_6 = torch.ops.aten._softmax_backward_data.default(view_default_385, _softmax_default_5, -1, torch.float32);  view_default_385 = _softmax_default_5 = None
        where_scalar_self_18 = torch.ops.aten.where.ScalarSelf(eq_scalar_5, 0.0, _softmax_backward_data_default_6);  eq_scalar_5 = _softmax_backward_data_default_6 = None
        div_tensor_94 = torch.ops.aten.div.Tensor(where_scalar_self_18, 8.0);  where_scalar_self_18 = None
        view_default_386 = torch.ops.aten.view.default(div_tensor_94, [192, 128, 128]);  div_tensor_94 = None
        transpose_int_117 = torch.ops.aten.transpose.int(_unsafe_view_default_25, 1, 2);  _unsafe_view_default_25 = None
        bmm_default_50 = torch.ops.aten.bmm.default(transpose_int_117, view_default_386);  transpose_int_117 = None
        transpose_int_118 = torch.ops.aten.transpose.int(_unsafe_view_default_26, 1, 2);  _unsafe_view_default_26 = None
        bmm_default_51 = torch.ops.aten.bmm.default(view_default_386, transpose_int_118);  view_default_386 = transpose_int_118 = None
        view_default_387 = torch.ops.aten.view.default(bmm_default_50, [16, 12, 64, 128]);  bmm_default_50 = None
        view_default_388 = torch.ops.aten.view.default(bmm_default_51, [16, 12, 128, 64]);  bmm_default_51 = None
        transpose_int_119 = torch.ops.aten.transpose.int(view_default_387, -2, -1);  view_default_387 = None
        transpose_int_120 = torch.ops.aten.transpose.int(view_default_384, 1, 2);  view_default_384 = None
        clone_default_73 = torch.ops.aten.clone.default(transpose_int_120, memory_format = torch.contiguous_format);  transpose_int_120 = None
        _unsafe_view_default_85 = torch.ops.aten._unsafe_view.default(clone_default_73, [16, 128, 768]);  clone_default_73 = None
        view_default_389 = torch.ops.aten.view.default(_unsafe_view_default_85, [2048, 768]);  _unsafe_view_default_85 = None
        t_default_228 = torch.ops.aten.t.default(t_default_32);  t_default_32 = None
        mm_default_78 = torch.ops.aten.mm.default(view_default_389, t_default_228);  t_default_228 = None
        t_default_229 = torch.ops.aten.t.default(view_default_389)
        mm_default_79 = torch.ops.aten.mm.default(t_default_229, view_default_91);  t_default_229 = view_default_91 = None
        t_default_230 = torch.ops.aten.t.default(mm_default_79);  mm_default_79 = None
        sum_dim_int_list_91 = torch.ops.aten.sum.dim_IntList(view_default_389, [0], True);  view_default_389 = None
        view_default_390 = torch.ops.aten.view.default(sum_dim_int_list_91, [768]);  sum_dim_int_list_91 = None
        t_default_231 = torch.ops.aten.t.default(t_default_230);  t_default_230 = None
        view_default_391 = torch.ops.aten.view.default(mm_default_78, [16, 128, 768]);  mm_default_78 = None
        transpose_int_121 = torch.ops.aten.transpose.int(transpose_int_119, 1, 2);  transpose_int_119 = None
        view_default_392 = torch.ops.aten.view.default(transpose_int_121, [16, 128, 768]);  transpose_int_121 = None
        clone_default_74 = torch.ops.aten.clone.default(view_default_392, memory_format = torch.contiguous_format);  view_default_392 = None
        _unsafe_view_default_86 = torch.ops.aten._unsafe_view.default(clone_default_74, [2048, 768]);  clone_default_74 = None
        t_default_232 = torch.ops.aten.t.default(t_default_31);  t_default_31 = None
        mm_default_80 = torch.ops.aten.mm.default(_unsafe_view_default_86, t_default_232);  t_default_232 = None
        t_default_233 = torch.ops.aten.t.default(_unsafe_view_default_86)
        mm_default_81 = torch.ops.aten.mm.default(t_default_233, view_default_88);  t_default_233 = view_default_88 = None
        t_default_234 = torch.ops.aten.t.default(mm_default_81);  mm_default_81 = None
        sum_dim_int_list_92 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_86, [0], True);  _unsafe_view_default_86 = None
        view_default_393 = torch.ops.aten.view.default(sum_dim_int_list_92, [768]);  sum_dim_int_list_92 = None
        t_default_235 = torch.ops.aten.t.default(t_default_234);  t_default_234 = None
        view_default_394 = torch.ops.aten.view.default(mm_default_80, [16, 128, 768]);  mm_default_80 = None
        add_tensor_139 = torch.ops.aten.add.Tensor(view_default_391, view_default_394);  view_default_391 = view_default_394 = None
        transpose_int_122 = torch.ops.aten.transpose.int(view_default_388, 1, 2);  view_default_388 = None
        clone_default_75 = torch.ops.aten.clone.default(transpose_int_122, memory_format = torch.contiguous_format);  transpose_int_122 = None
        _unsafe_view_default_87 = torch.ops.aten._unsafe_view.default(clone_default_75, [16, 128, 768]);  clone_default_75 = None
        view_default_395 = torch.ops.aten.view.default(_unsafe_view_default_87, [2048, 768]);  _unsafe_view_default_87 = None
        t_default_236 = torch.ops.aten.t.default(t_default_30);  t_default_30 = None
        mm_default_82 = torch.ops.aten.mm.default(view_default_395, t_default_236);  t_default_236 = None
        t_default_237 = torch.ops.aten.t.default(view_default_395)
        mm_default_83 = torch.ops.aten.mm.default(t_default_237, view_default_85);  t_default_237 = view_default_85 = None
        t_default_238 = torch.ops.aten.t.default(mm_default_83);  mm_default_83 = None
        sum_dim_int_list_93 = torch.ops.aten.sum.dim_IntList(view_default_395, [0], True);  view_default_395 = None
        view_default_396 = torch.ops.aten.view.default(sum_dim_int_list_93, [768]);  sum_dim_int_list_93 = None
        t_default_239 = torch.ops.aten.t.default(t_default_238);  t_default_238 = None
        view_default_397 = torch.ops.aten.view.default(mm_default_82, [16, 128, 768]);  mm_default_82 = None
        add_tensor_140 = torch.ops.aten.add.Tensor(add_tensor_139, view_default_397);  add_tensor_139 = view_default_397 = None
        sum_dim_int_list_94 = torch.ops.aten.sum.dim_IntList(add_tensor_140, [0, 1], True)
        view_default_398 = torch.ops.aten.view.default(sum_dim_int_list_94, [768]);  sum_dim_int_list_94 = None
        neg_default_26 = torch.ops.aten.neg.default(add_tensor_140)
        div_tensor_95 = torch.ops.aten.div.Tensor(mul_tensor_10, add_tensor_32);  mul_tensor_10 = None
        div_tensor_96 = torch.ops.aten.div.Tensor(div_tensor_95, add_tensor_32);  div_tensor_95 = None
        mul_tensor_125 = torch.ops.aten.mul.Tensor(neg_default_26, div_tensor_96);  neg_default_26 = div_tensor_96 = None
        div_tensor_97 = torch.ops.aten.div.Tensor(add_tensor_140, add_tensor_32);  add_tensor_140 = add_tensor_32 = None
        sum_dim_int_list_95 = torch.ops.aten.sum.dim_IntList(mul_tensor_125, [2], True);  mul_tensor_125 = None
        mul_tensor_126 = torch.ops.aten.mul.Tensor(div_tensor_97, primals_120);  primals_120 = None
        mul_tensor_127 = torch.ops.aten.mul.Tensor(div_tensor_97, sub_tensor_10);  div_tensor_97 = sub_tensor_10 = None
        sum_dim_int_list_96 = torch.ops.aten.sum.dim_IntList(mul_tensor_127, [0, 1], True);  mul_tensor_127 = None
        view_default_399 = torch.ops.aten.view.default(sum_dim_int_list_96, [768]);  sum_dim_int_list_96 = None
        neg_default_27 = torch.ops.aten.neg.default(mul_tensor_126)
        sum_dim_int_list_97 = torch.ops.aten.sum.dim_IntList(neg_default_27, [2], True);  neg_default_27 = None
        add_tensor_141 = torch.ops.aten.add.Tensor(add_tensor_138, mul_tensor_126);  add_tensor_138 = mul_tensor_126 = None
        mul_scalar_26 = torch.ops.aten.mul.Scalar(std_correction_10, 2)
        div_tensor_98 = torch.ops.aten.div.Tensor(sum_dim_int_list_95, mul_scalar_26);  sum_dim_int_list_95 = mul_scalar_26 = None
        eq_scalar_25 = torch.ops.aten.eq.Scalar(std_correction_10, 0);  std_correction_10 = None
        masked_fill__scalar_13 = torch.ops.aten.masked_fill_.Scalar(div_tensor_98, eq_scalar_25, 0);  div_tensor_98 = eq_scalar_25 = None
        mul_scalar_27 = torch.ops.aten.mul.Scalar(masked_fill__scalar_13, 0.002607561929595828);  masked_fill__scalar_13 = None
        mean_dim_37 = torch.ops.aten.mean.dim(add_tensor_31, [-1], True)
        sub_tensor_37 = torch.ops.aten.sub.Tensor(add_tensor_31, mean_dim_37);  add_tensor_31 = mean_dim_37 = None
        mul_tensor_128 = torch.ops.aten.mul.Tensor(mul_scalar_27, sub_tensor_37);  mul_scalar_27 = sub_tensor_37 = None
        add_tensor_142 = torch.ops.aten.add.Tensor(add_tensor_141, mul_tensor_128);  add_tensor_141 = mul_tensor_128 = None
        expand_default_61 = torch.ops.aten.expand.default(sum_dim_int_list_97, [16, 128, 768]);  sum_dim_int_list_97 = None
        div_scalar_13 = torch.ops.aten.div.Scalar(expand_default_61, 768);  expand_default_61 = None
        add_tensor_143 = torch.ops.aten.add.Tensor(add_tensor_142, div_scalar_13);  add_tensor_142 = div_scalar_13 = None
        view_default_400 = torch.ops.aten.view.default(add_tensor_143, [2048, 768])
        t_default_240 = torch.ops.aten.t.default(t_default_29);  t_default_29 = None
        mm_default_84 = torch.ops.aten.mm.default(view_default_400, t_default_240);  t_default_240 = None
        t_default_241 = torch.ops.aten.t.default(view_default_400)
        mm_default_85 = torch.ops.aten.mm.default(t_default_241, view_default_83);  t_default_241 = view_default_83 = None
        t_default_242 = torch.ops.aten.t.default(mm_default_85);  mm_default_85 = None
        sum_dim_int_list_98 = torch.ops.aten.sum.dim_IntList(view_default_400, [0], True);  view_default_400 = None
        view_default_401 = torch.ops.aten.view.default(sum_dim_int_list_98, [768]);  sum_dim_int_list_98 = None
        t_default_243 = torch.ops.aten.t.default(t_default_242);  t_default_242 = None
        view_default_402 = torch.ops.aten.view.default(mm_default_84, [16, 128, 3072]);  mm_default_84 = None
        to_dtype_21 = torch.ops.aten.to.dtype(view_default_402, torch.float32);  view_default_402 = None
        to_dtype_22 = torch.ops.aten.to.dtype(view_default_82, torch.float32);  view_default_82 = None
        mul_tensor_129 = torch.ops.aten.mul.Tensor(to_dtype_22, 0.7071067811865476)
        erf_default_7 = torch.ops.aten.erf.default(mul_tensor_129);  mul_tensor_129 = None
        add_tensor_144 = torch.ops.aten.add.Tensor(erf_default_7, 1);  erf_default_7 = None
        mul_tensor_130 = torch.ops.aten.mul.Tensor(add_tensor_144, 0.5);  add_tensor_144 = None
        mul_tensor_131 = torch.ops.aten.mul.Tensor(to_dtype_22, to_dtype_22)
        mul_tensor_132 = torch.ops.aten.mul.Tensor(mul_tensor_131, -0.5);  mul_tensor_131 = None
        exp_default_7 = torch.ops.aten.exp.default(mul_tensor_132);  mul_tensor_132 = None
        mul_tensor_133 = torch.ops.aten.mul.Tensor(exp_default_7, 0.3989422804014327);  exp_default_7 = None
        mul_tensor_134 = torch.ops.aten.mul.Tensor(to_dtype_22, mul_tensor_133);  to_dtype_22 = mul_tensor_133 = None
        add_tensor_145 = torch.ops.aten.add.Tensor(mul_tensor_130, mul_tensor_134);  mul_tensor_130 = mul_tensor_134 = None
        mul_tensor_135 = torch.ops.aten.mul.Tensor(to_dtype_21, add_tensor_145);  to_dtype_21 = add_tensor_145 = None
        to_dtype_23 = torch.ops.aten.to.dtype(mul_tensor_135, torch.float32);  mul_tensor_135 = None
        view_default_403 = torch.ops.aten.view.default(to_dtype_23, [2048, 3072]);  to_dtype_23 = None
        t_default_244 = torch.ops.aten.t.default(t_default_28);  t_default_28 = None
        mm_default_86 = torch.ops.aten.mm.default(view_default_403, t_default_244);  t_default_244 = None
        t_default_245 = torch.ops.aten.t.default(view_default_403)
        mm_default_87 = torch.ops.aten.mm.default(t_default_245, view_default_81);  t_default_245 = view_default_81 = None
        t_default_246 = torch.ops.aten.t.default(mm_default_87);  mm_default_87 = None
        sum_dim_int_list_99 = torch.ops.aten.sum.dim_IntList(view_default_403, [0], True);  view_default_403 = None
        view_default_404 = torch.ops.aten.view.default(sum_dim_int_list_99, [3072]);  sum_dim_int_list_99 = None
        t_default_247 = torch.ops.aten.t.default(t_default_246);  t_default_246 = None
        view_default_405 = torch.ops.aten.view.default(mm_default_86, [16, 128, 768]);  mm_default_86 = None
        sum_dim_int_list_100 = torch.ops.aten.sum.dim_IntList(view_default_405, [0, 1], True)
        view_default_406 = torch.ops.aten.view.default(sum_dim_int_list_100, [768]);  sum_dim_int_list_100 = None
        neg_default_28 = torch.ops.aten.neg.default(view_default_405)
        div_tensor_99 = torch.ops.aten.div.Tensor(mul_tensor_9, add_tensor_29);  mul_tensor_9 = None
        div_tensor_100 = torch.ops.aten.div.Tensor(div_tensor_99, add_tensor_29);  div_tensor_99 = None
        mul_tensor_136 = torch.ops.aten.mul.Tensor(neg_default_28, div_tensor_100);  neg_default_28 = div_tensor_100 = None
        div_tensor_101 = torch.ops.aten.div.Tensor(view_default_405, add_tensor_29);  view_default_405 = add_tensor_29 = None
        sum_dim_int_list_101 = torch.ops.aten.sum.dim_IntList(mul_tensor_136, [2], True);  mul_tensor_136 = None
        mul_tensor_137 = torch.ops.aten.mul.Tensor(div_tensor_101, primals_114);  primals_114 = None
        mul_tensor_138 = torch.ops.aten.mul.Tensor(div_tensor_101, sub_tensor_9);  div_tensor_101 = sub_tensor_9 = None
        sum_dim_int_list_102 = torch.ops.aten.sum.dim_IntList(mul_tensor_138, [0, 1], True);  mul_tensor_138 = None
        view_default_407 = torch.ops.aten.view.default(sum_dim_int_list_102, [768]);  sum_dim_int_list_102 = None
        neg_default_29 = torch.ops.aten.neg.default(mul_tensor_137)
        sum_dim_int_list_103 = torch.ops.aten.sum.dim_IntList(neg_default_29, [2], True);  neg_default_29 = None
        add_tensor_146 = torch.ops.aten.add.Tensor(add_tensor_143, mul_tensor_137);  add_tensor_143 = mul_tensor_137 = None
        mul_scalar_28 = torch.ops.aten.mul.Scalar(std_correction_9, 2)
        div_tensor_102 = torch.ops.aten.div.Tensor(sum_dim_int_list_101, mul_scalar_28);  sum_dim_int_list_101 = mul_scalar_28 = None
        eq_scalar_26 = torch.ops.aten.eq.Scalar(std_correction_9, 0);  std_correction_9 = None
        masked_fill__scalar_14 = torch.ops.aten.masked_fill_.Scalar(div_tensor_102, eq_scalar_26, 0);  div_tensor_102 = eq_scalar_26 = None
        mul_scalar_29 = torch.ops.aten.mul.Scalar(masked_fill__scalar_14, 0.002607561929595828);  masked_fill__scalar_14 = None
        mean_dim_38 = torch.ops.aten.mean.dim(add_tensor_28, [-1], True)
        sub_tensor_38 = torch.ops.aten.sub.Tensor(add_tensor_28, mean_dim_38);  add_tensor_28 = mean_dim_38 = None
        mul_tensor_139 = torch.ops.aten.mul.Tensor(mul_scalar_29, sub_tensor_38);  mul_scalar_29 = sub_tensor_38 = None
        add_tensor_147 = torch.ops.aten.add.Tensor(add_tensor_146, mul_tensor_139);  add_tensor_146 = mul_tensor_139 = None
        expand_default_62 = torch.ops.aten.expand.default(sum_dim_int_list_103, [16, 128, 768]);  sum_dim_int_list_103 = None
        div_scalar_14 = torch.ops.aten.div.Scalar(expand_default_62, 768);  expand_default_62 = None
        add_tensor_148 = torch.ops.aten.add.Tensor(add_tensor_147, div_scalar_14);  add_tensor_147 = div_scalar_14 = None
        view_default_408 = torch.ops.aten.view.default(add_tensor_148, [2048, 768])
        t_default_248 = torch.ops.aten.t.default(t_default_27);  t_default_27 = None
        mm_default_88 = torch.ops.aten.mm.default(view_default_408, t_default_248);  t_default_248 = None
        t_default_249 = torch.ops.aten.t.default(view_default_408)
        mm_default_89 = torch.ops.aten.mm.default(t_default_249, view_default_79);  t_default_249 = view_default_79 = None
        t_default_250 = torch.ops.aten.t.default(mm_default_89);  mm_default_89 = None
        sum_dim_int_list_104 = torch.ops.aten.sum.dim_IntList(view_default_408, [0], True);  view_default_408 = None
        view_default_409 = torch.ops.aten.view.default(sum_dim_int_list_104, [768]);  sum_dim_int_list_104 = None
        t_default_251 = torch.ops.aten.t.default(t_default_250);  t_default_250 = None
        view_default_410 = torch.ops.aten.view.default(mm_default_88, [16, 128, 768]);  mm_default_88 = None
        view_default_411 = torch.ops.aten.view.default(view_default_410, [16, 128, 12, 64]);  view_default_410 = None
        transpose_int_123 = torch.ops.aten.transpose.int(view_default_411, 1, 2);  view_default_411 = None
        clone_default_76 = torch.ops.aten.clone.default(transpose_int_123, memory_format = torch.contiguous_format);  transpose_int_123 = None
        _unsafe_view_default_88 = torch.ops.aten._unsafe_view.default(clone_default_76, [192, 128, 64]);  clone_default_76 = None
        transpose_int_124 = torch.ops.aten.transpose.int(view_default_77, 1, 2);  view_default_77 = None
        bmm_default_52 = torch.ops.aten.bmm.default(transpose_int_124, _unsafe_view_default_88);  transpose_int_124 = None
        transpose_int_125 = torch.ops.aten.transpose.int(_unsafe_view_default_23, 1, 2);  _unsafe_view_default_23 = None
        bmm_default_53 = torch.ops.aten.bmm.default(_unsafe_view_default_88, transpose_int_125);  _unsafe_view_default_88 = transpose_int_125 = None
        view_default_412 = torch.ops.aten.view.default(bmm_default_52, [16, 12, 128, 64]);  bmm_default_52 = None
        view_default_413 = torch.ops.aten.view.default(bmm_default_53, [16, 12, 128, 128]);  bmm_default_53 = None
        _softmax_backward_data_default_7 = torch.ops.aten._softmax_backward_data.default(view_default_413, _softmax_default_4, -1, torch.float32);  view_default_413 = _softmax_default_4 = None
        where_scalar_self_19 = torch.ops.aten.where.ScalarSelf(eq_scalar_4, 0.0, _softmax_backward_data_default_7);  eq_scalar_4 = _softmax_backward_data_default_7 = None
        div_tensor_103 = torch.ops.aten.div.Tensor(where_scalar_self_19, 8.0);  where_scalar_self_19 = None
        view_default_414 = torch.ops.aten.view.default(div_tensor_103, [192, 128, 128]);  div_tensor_103 = None
        transpose_int_126 = torch.ops.aten.transpose.int(_unsafe_view_default_20, 1, 2);  _unsafe_view_default_20 = None
        bmm_default_54 = torch.ops.aten.bmm.default(transpose_int_126, view_default_414);  transpose_int_126 = None
        transpose_int_127 = torch.ops.aten.transpose.int(_unsafe_view_default_21, 1, 2);  _unsafe_view_default_21 = None
        bmm_default_55 = torch.ops.aten.bmm.default(view_default_414, transpose_int_127);  view_default_414 = transpose_int_127 = None
        view_default_415 = torch.ops.aten.view.default(bmm_default_54, [16, 12, 64, 128]);  bmm_default_54 = None
        view_default_416 = torch.ops.aten.view.default(bmm_default_55, [16, 12, 128, 64]);  bmm_default_55 = None
        transpose_int_128 = torch.ops.aten.transpose.int(view_default_415, -2, -1);  view_default_415 = None
        transpose_int_129 = torch.ops.aten.transpose.int(view_default_412, 1, 2);  view_default_412 = None
        clone_default_77 = torch.ops.aten.clone.default(transpose_int_129, memory_format = torch.contiguous_format);  transpose_int_129 = None
        _unsafe_view_default_89 = torch.ops.aten._unsafe_view.default(clone_default_77, [16, 128, 768]);  clone_default_77 = None
        view_default_417 = torch.ops.aten.view.default(_unsafe_view_default_89, [2048, 768]);  _unsafe_view_default_89 = None
        t_default_252 = torch.ops.aten.t.default(t_default_26);  t_default_26 = None
        mm_default_90 = torch.ops.aten.mm.default(view_default_417, t_default_252);  t_default_252 = None
        t_default_253 = torch.ops.aten.t.default(view_default_417)
        mm_default_91 = torch.ops.aten.mm.default(t_default_253, view_default_74);  t_default_253 = view_default_74 = None
        t_default_254 = torch.ops.aten.t.default(mm_default_91);  mm_default_91 = None
        sum_dim_int_list_105 = torch.ops.aten.sum.dim_IntList(view_default_417, [0], True);  view_default_417 = None
        view_default_418 = torch.ops.aten.view.default(sum_dim_int_list_105, [768]);  sum_dim_int_list_105 = None
        t_default_255 = torch.ops.aten.t.default(t_default_254);  t_default_254 = None
        view_default_419 = torch.ops.aten.view.default(mm_default_90, [16, 128, 768]);  mm_default_90 = None
        transpose_int_130 = torch.ops.aten.transpose.int(transpose_int_128, 1, 2);  transpose_int_128 = None
        view_default_420 = torch.ops.aten.view.default(transpose_int_130, [16, 128, 768]);  transpose_int_130 = None
        clone_default_78 = torch.ops.aten.clone.default(view_default_420, memory_format = torch.contiguous_format);  view_default_420 = None
        _unsafe_view_default_90 = torch.ops.aten._unsafe_view.default(clone_default_78, [2048, 768]);  clone_default_78 = None
        t_default_256 = torch.ops.aten.t.default(t_default_25);  t_default_25 = None
        mm_default_92 = torch.ops.aten.mm.default(_unsafe_view_default_90, t_default_256);  t_default_256 = None
        t_default_257 = torch.ops.aten.t.default(_unsafe_view_default_90)
        mm_default_93 = torch.ops.aten.mm.default(t_default_257, view_default_71);  t_default_257 = view_default_71 = None
        t_default_258 = torch.ops.aten.t.default(mm_default_93);  mm_default_93 = None
        sum_dim_int_list_106 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_90, [0], True);  _unsafe_view_default_90 = None
        view_default_421 = torch.ops.aten.view.default(sum_dim_int_list_106, [768]);  sum_dim_int_list_106 = None
        t_default_259 = torch.ops.aten.t.default(t_default_258);  t_default_258 = None
        view_default_422 = torch.ops.aten.view.default(mm_default_92, [16, 128, 768]);  mm_default_92 = None
        add_tensor_149 = torch.ops.aten.add.Tensor(view_default_419, view_default_422);  view_default_419 = view_default_422 = None
        transpose_int_131 = torch.ops.aten.transpose.int(view_default_416, 1, 2);  view_default_416 = None
        clone_default_79 = torch.ops.aten.clone.default(transpose_int_131, memory_format = torch.contiguous_format);  transpose_int_131 = None
        _unsafe_view_default_91 = torch.ops.aten._unsafe_view.default(clone_default_79, [16, 128, 768]);  clone_default_79 = None
        view_default_423 = torch.ops.aten.view.default(_unsafe_view_default_91, [2048, 768]);  _unsafe_view_default_91 = None
        t_default_260 = torch.ops.aten.t.default(t_default_24);  t_default_24 = None
        mm_default_94 = torch.ops.aten.mm.default(view_default_423, t_default_260);  t_default_260 = None
        t_default_261 = torch.ops.aten.t.default(view_default_423)
        mm_default_95 = torch.ops.aten.mm.default(t_default_261, view_default_68);  t_default_261 = view_default_68 = None
        t_default_262 = torch.ops.aten.t.default(mm_default_95);  mm_default_95 = None
        sum_dim_int_list_107 = torch.ops.aten.sum.dim_IntList(view_default_423, [0], True);  view_default_423 = None
        view_default_424 = torch.ops.aten.view.default(sum_dim_int_list_107, [768]);  sum_dim_int_list_107 = None
        t_default_263 = torch.ops.aten.t.default(t_default_262);  t_default_262 = None
        view_default_425 = torch.ops.aten.view.default(mm_default_94, [16, 128, 768]);  mm_default_94 = None
        add_tensor_150 = torch.ops.aten.add.Tensor(add_tensor_149, view_default_425);  add_tensor_149 = view_default_425 = None
        sum_dim_int_list_108 = torch.ops.aten.sum.dim_IntList(add_tensor_150, [0, 1], True)
        view_default_426 = torch.ops.aten.view.default(sum_dim_int_list_108, [768]);  sum_dim_int_list_108 = None
        neg_default_30 = torch.ops.aten.neg.default(add_tensor_150)
        div_tensor_104 = torch.ops.aten.div.Tensor(mul_tensor_8, add_tensor_26);  mul_tensor_8 = None
        div_tensor_105 = torch.ops.aten.div.Tensor(div_tensor_104, add_tensor_26);  div_tensor_104 = None
        mul_tensor_140 = torch.ops.aten.mul.Tensor(neg_default_30, div_tensor_105);  neg_default_30 = div_tensor_105 = None
        div_tensor_106 = torch.ops.aten.div.Tensor(add_tensor_150, add_tensor_26);  add_tensor_150 = add_tensor_26 = None
        sum_dim_int_list_109 = torch.ops.aten.sum.dim_IntList(mul_tensor_140, [2], True);  mul_tensor_140 = None
        mul_tensor_141 = torch.ops.aten.mul.Tensor(div_tensor_106, primals_104);  primals_104 = None
        mul_tensor_142 = torch.ops.aten.mul.Tensor(div_tensor_106, sub_tensor_8);  div_tensor_106 = sub_tensor_8 = None
        sum_dim_int_list_110 = torch.ops.aten.sum.dim_IntList(mul_tensor_142, [0, 1], True);  mul_tensor_142 = None
        view_default_427 = torch.ops.aten.view.default(sum_dim_int_list_110, [768]);  sum_dim_int_list_110 = None
        neg_default_31 = torch.ops.aten.neg.default(mul_tensor_141)
        sum_dim_int_list_111 = torch.ops.aten.sum.dim_IntList(neg_default_31, [2], True);  neg_default_31 = None
        add_tensor_151 = torch.ops.aten.add.Tensor(add_tensor_148, mul_tensor_141);  add_tensor_148 = mul_tensor_141 = None
        mul_scalar_30 = torch.ops.aten.mul.Scalar(std_correction_8, 2)
        div_tensor_107 = torch.ops.aten.div.Tensor(sum_dim_int_list_109, mul_scalar_30);  sum_dim_int_list_109 = mul_scalar_30 = None
        eq_scalar_27 = torch.ops.aten.eq.Scalar(std_correction_8, 0);  std_correction_8 = None
        masked_fill__scalar_15 = torch.ops.aten.masked_fill_.Scalar(div_tensor_107, eq_scalar_27, 0);  div_tensor_107 = eq_scalar_27 = None
        mul_scalar_31 = torch.ops.aten.mul.Scalar(masked_fill__scalar_15, 0.002607561929595828);  masked_fill__scalar_15 = None
        mean_dim_39 = torch.ops.aten.mean.dim(add_tensor_25, [-1], True)
        sub_tensor_39 = torch.ops.aten.sub.Tensor(add_tensor_25, mean_dim_39);  add_tensor_25 = mean_dim_39 = None
        mul_tensor_143 = torch.ops.aten.mul.Tensor(mul_scalar_31, sub_tensor_39);  mul_scalar_31 = sub_tensor_39 = None
        add_tensor_152 = torch.ops.aten.add.Tensor(add_tensor_151, mul_tensor_143);  add_tensor_151 = mul_tensor_143 = None
        expand_default_63 = torch.ops.aten.expand.default(sum_dim_int_list_111, [16, 128, 768]);  sum_dim_int_list_111 = None
        div_scalar_15 = torch.ops.aten.div.Scalar(expand_default_63, 768);  expand_default_63 = None
        add_tensor_153 = torch.ops.aten.add.Tensor(add_tensor_152, div_scalar_15);  add_tensor_152 = div_scalar_15 = None
        view_default_428 = torch.ops.aten.view.default(add_tensor_153, [2048, 768])
        t_default_264 = torch.ops.aten.t.default(t_default_23);  t_default_23 = None
        mm_default_96 = torch.ops.aten.mm.default(view_default_428, t_default_264);  t_default_264 = None
        t_default_265 = torch.ops.aten.t.default(view_default_428)
        mm_default_97 = torch.ops.aten.mm.default(t_default_265, view_default_66);  t_default_265 = view_default_66 = None
        t_default_266 = torch.ops.aten.t.default(mm_default_97);  mm_default_97 = None
        sum_dim_int_list_112 = torch.ops.aten.sum.dim_IntList(view_default_428, [0], True);  view_default_428 = None
        view_default_429 = torch.ops.aten.view.default(sum_dim_int_list_112, [768]);  sum_dim_int_list_112 = None
        t_default_267 = torch.ops.aten.t.default(t_default_266);  t_default_266 = None
        view_default_430 = torch.ops.aten.view.default(mm_default_96, [16, 128, 3072]);  mm_default_96 = None
        to_dtype_24 = torch.ops.aten.to.dtype(view_default_430, torch.float32);  view_default_430 = None
        to_dtype_25 = torch.ops.aten.to.dtype(view_default_65, torch.float32);  view_default_65 = None
        mul_tensor_144 = torch.ops.aten.mul.Tensor(to_dtype_25, 0.7071067811865476)
        erf_default_8 = torch.ops.aten.erf.default(mul_tensor_144);  mul_tensor_144 = None
        add_tensor_154 = torch.ops.aten.add.Tensor(erf_default_8, 1);  erf_default_8 = None
        mul_tensor_145 = torch.ops.aten.mul.Tensor(add_tensor_154, 0.5);  add_tensor_154 = None
        mul_tensor_146 = torch.ops.aten.mul.Tensor(to_dtype_25, to_dtype_25)
        mul_tensor_147 = torch.ops.aten.mul.Tensor(mul_tensor_146, -0.5);  mul_tensor_146 = None
        exp_default_8 = torch.ops.aten.exp.default(mul_tensor_147);  mul_tensor_147 = None
        mul_tensor_148 = torch.ops.aten.mul.Tensor(exp_default_8, 0.3989422804014327);  exp_default_8 = None
        mul_tensor_149 = torch.ops.aten.mul.Tensor(to_dtype_25, mul_tensor_148);  to_dtype_25 = mul_tensor_148 = None
        add_tensor_155 = torch.ops.aten.add.Tensor(mul_tensor_145, mul_tensor_149);  mul_tensor_145 = mul_tensor_149 = None
        mul_tensor_150 = torch.ops.aten.mul.Tensor(to_dtype_24, add_tensor_155);  to_dtype_24 = add_tensor_155 = None
        to_dtype_26 = torch.ops.aten.to.dtype(mul_tensor_150, torch.float32);  mul_tensor_150 = None
        view_default_431 = torch.ops.aten.view.default(to_dtype_26, [2048, 3072]);  to_dtype_26 = None
        t_default_268 = torch.ops.aten.t.default(t_default_22);  t_default_22 = None
        mm_default_98 = torch.ops.aten.mm.default(view_default_431, t_default_268);  t_default_268 = None
        t_default_269 = torch.ops.aten.t.default(view_default_431)
        mm_default_99 = torch.ops.aten.mm.default(t_default_269, view_default_64);  t_default_269 = view_default_64 = None
        t_default_270 = torch.ops.aten.t.default(mm_default_99);  mm_default_99 = None
        sum_dim_int_list_113 = torch.ops.aten.sum.dim_IntList(view_default_431, [0], True);  view_default_431 = None
        view_default_432 = torch.ops.aten.view.default(sum_dim_int_list_113, [3072]);  sum_dim_int_list_113 = None
        t_default_271 = torch.ops.aten.t.default(t_default_270);  t_default_270 = None
        view_default_433 = torch.ops.aten.view.default(mm_default_98, [16, 128, 768]);  mm_default_98 = None
        sum_dim_int_list_114 = torch.ops.aten.sum.dim_IntList(view_default_433, [0, 1], True)
        view_default_434 = torch.ops.aten.view.default(sum_dim_int_list_114, [768]);  sum_dim_int_list_114 = None
        neg_default_32 = torch.ops.aten.neg.default(view_default_433)
        div_tensor_108 = torch.ops.aten.div.Tensor(mul_tensor_7, add_tensor_23);  mul_tensor_7 = None
        div_tensor_109 = torch.ops.aten.div.Tensor(div_tensor_108, add_tensor_23);  div_tensor_108 = None
        mul_tensor_151 = torch.ops.aten.mul.Tensor(neg_default_32, div_tensor_109);  neg_default_32 = div_tensor_109 = None
        div_tensor_110 = torch.ops.aten.div.Tensor(view_default_433, add_tensor_23);  view_default_433 = add_tensor_23 = None
        sum_dim_int_list_115 = torch.ops.aten.sum.dim_IntList(mul_tensor_151, [2], True);  mul_tensor_151 = None
        mul_tensor_152 = torch.ops.aten.mul.Tensor(div_tensor_110, primals_98);  primals_98 = None
        mul_tensor_153 = torch.ops.aten.mul.Tensor(div_tensor_110, sub_tensor_7);  div_tensor_110 = sub_tensor_7 = None
        sum_dim_int_list_116 = torch.ops.aten.sum.dim_IntList(mul_tensor_153, [0, 1], True);  mul_tensor_153 = None
        view_default_435 = torch.ops.aten.view.default(sum_dim_int_list_116, [768]);  sum_dim_int_list_116 = None
        neg_default_33 = torch.ops.aten.neg.default(mul_tensor_152)
        sum_dim_int_list_117 = torch.ops.aten.sum.dim_IntList(neg_default_33, [2], True);  neg_default_33 = None
        add_tensor_156 = torch.ops.aten.add.Tensor(add_tensor_153, mul_tensor_152);  add_tensor_153 = mul_tensor_152 = None
        mul_scalar_32 = torch.ops.aten.mul.Scalar(std_correction_7, 2)
        div_tensor_111 = torch.ops.aten.div.Tensor(sum_dim_int_list_115, mul_scalar_32);  sum_dim_int_list_115 = mul_scalar_32 = None
        eq_scalar_28 = torch.ops.aten.eq.Scalar(std_correction_7, 0);  std_correction_7 = None
        masked_fill__scalar_16 = torch.ops.aten.masked_fill_.Scalar(div_tensor_111, eq_scalar_28, 0);  div_tensor_111 = eq_scalar_28 = None
        mul_scalar_33 = torch.ops.aten.mul.Scalar(masked_fill__scalar_16, 0.002607561929595828);  masked_fill__scalar_16 = None
        mean_dim_40 = torch.ops.aten.mean.dim(add_tensor_22, [-1], True)
        sub_tensor_40 = torch.ops.aten.sub.Tensor(add_tensor_22, mean_dim_40);  add_tensor_22 = mean_dim_40 = None
        mul_tensor_154 = torch.ops.aten.mul.Tensor(mul_scalar_33, sub_tensor_40);  mul_scalar_33 = sub_tensor_40 = None
        add_tensor_157 = torch.ops.aten.add.Tensor(add_tensor_156, mul_tensor_154);  add_tensor_156 = mul_tensor_154 = None
        expand_default_64 = torch.ops.aten.expand.default(sum_dim_int_list_117, [16, 128, 768]);  sum_dim_int_list_117 = None
        div_scalar_16 = torch.ops.aten.div.Scalar(expand_default_64, 768);  expand_default_64 = None
        add_tensor_158 = torch.ops.aten.add.Tensor(add_tensor_157, div_scalar_16);  add_tensor_157 = div_scalar_16 = None
        view_default_436 = torch.ops.aten.view.default(add_tensor_158, [2048, 768])
        t_default_272 = torch.ops.aten.t.default(t_default_21);  t_default_21 = None
        mm_default_100 = torch.ops.aten.mm.default(view_default_436, t_default_272);  t_default_272 = None
        t_default_273 = torch.ops.aten.t.default(view_default_436)
        mm_default_101 = torch.ops.aten.mm.default(t_default_273, view_default_62);  t_default_273 = view_default_62 = None
        t_default_274 = torch.ops.aten.t.default(mm_default_101);  mm_default_101 = None
        sum_dim_int_list_118 = torch.ops.aten.sum.dim_IntList(view_default_436, [0], True);  view_default_436 = None
        view_default_437 = torch.ops.aten.view.default(sum_dim_int_list_118, [768]);  sum_dim_int_list_118 = None
        t_default_275 = torch.ops.aten.t.default(t_default_274);  t_default_274 = None
        view_default_438 = torch.ops.aten.view.default(mm_default_100, [16, 128, 768]);  mm_default_100 = None
        view_default_439 = torch.ops.aten.view.default(view_default_438, [16, 128, 12, 64]);  view_default_438 = None
        transpose_int_132 = torch.ops.aten.transpose.int(view_default_439, 1, 2);  view_default_439 = None
        clone_default_80 = torch.ops.aten.clone.default(transpose_int_132, memory_format = torch.contiguous_format);  transpose_int_132 = None
        _unsafe_view_default_92 = torch.ops.aten._unsafe_view.default(clone_default_80, [192, 128, 64]);  clone_default_80 = None
        transpose_int_133 = torch.ops.aten.transpose.int(view_default_60, 1, 2);  view_default_60 = None
        bmm_default_56 = torch.ops.aten.bmm.default(transpose_int_133, _unsafe_view_default_92);  transpose_int_133 = None
        transpose_int_134 = torch.ops.aten.transpose.int(_unsafe_view_default_18, 1, 2);  _unsafe_view_default_18 = None
        bmm_default_57 = torch.ops.aten.bmm.default(_unsafe_view_default_92, transpose_int_134);  _unsafe_view_default_92 = transpose_int_134 = None
        view_default_440 = torch.ops.aten.view.default(bmm_default_56, [16, 12, 128, 64]);  bmm_default_56 = None
        view_default_441 = torch.ops.aten.view.default(bmm_default_57, [16, 12, 128, 128]);  bmm_default_57 = None
        _softmax_backward_data_default_8 = torch.ops.aten._softmax_backward_data.default(view_default_441, _softmax_default_3, -1, torch.float32);  view_default_441 = _softmax_default_3 = None
        where_scalar_self_20 = torch.ops.aten.where.ScalarSelf(eq_scalar_3, 0.0, _softmax_backward_data_default_8);  eq_scalar_3 = _softmax_backward_data_default_8 = None
        div_tensor_112 = torch.ops.aten.div.Tensor(where_scalar_self_20, 8.0);  where_scalar_self_20 = None
        view_default_442 = torch.ops.aten.view.default(div_tensor_112, [192, 128, 128]);  div_tensor_112 = None
        transpose_int_135 = torch.ops.aten.transpose.int(_unsafe_view_default_15, 1, 2);  _unsafe_view_default_15 = None
        bmm_default_58 = torch.ops.aten.bmm.default(transpose_int_135, view_default_442);  transpose_int_135 = None
        transpose_int_136 = torch.ops.aten.transpose.int(_unsafe_view_default_16, 1, 2);  _unsafe_view_default_16 = None
        bmm_default_59 = torch.ops.aten.bmm.default(view_default_442, transpose_int_136);  view_default_442 = transpose_int_136 = None
        view_default_443 = torch.ops.aten.view.default(bmm_default_58, [16, 12, 64, 128]);  bmm_default_58 = None
        view_default_444 = torch.ops.aten.view.default(bmm_default_59, [16, 12, 128, 64]);  bmm_default_59 = None
        transpose_int_137 = torch.ops.aten.transpose.int(view_default_443, -2, -1);  view_default_443 = None
        transpose_int_138 = torch.ops.aten.transpose.int(view_default_440, 1, 2);  view_default_440 = None
        clone_default_81 = torch.ops.aten.clone.default(transpose_int_138, memory_format = torch.contiguous_format);  transpose_int_138 = None
        _unsafe_view_default_93 = torch.ops.aten._unsafe_view.default(clone_default_81, [16, 128, 768]);  clone_default_81 = None
        view_default_445 = torch.ops.aten.view.default(_unsafe_view_default_93, [2048, 768]);  _unsafe_view_default_93 = None
        t_default_276 = torch.ops.aten.t.default(t_default_20);  t_default_20 = None
        mm_default_102 = torch.ops.aten.mm.default(view_default_445, t_default_276);  t_default_276 = None
        t_default_277 = torch.ops.aten.t.default(view_default_445)
        mm_default_103 = torch.ops.aten.mm.default(t_default_277, view_default_57);  t_default_277 = view_default_57 = None
        t_default_278 = torch.ops.aten.t.default(mm_default_103);  mm_default_103 = None
        sum_dim_int_list_119 = torch.ops.aten.sum.dim_IntList(view_default_445, [0], True);  view_default_445 = None
        view_default_446 = torch.ops.aten.view.default(sum_dim_int_list_119, [768]);  sum_dim_int_list_119 = None
        t_default_279 = torch.ops.aten.t.default(t_default_278);  t_default_278 = None
        view_default_447 = torch.ops.aten.view.default(mm_default_102, [16, 128, 768]);  mm_default_102 = None
        transpose_int_139 = torch.ops.aten.transpose.int(transpose_int_137, 1, 2);  transpose_int_137 = None
        view_default_448 = torch.ops.aten.view.default(transpose_int_139, [16, 128, 768]);  transpose_int_139 = None
        clone_default_82 = torch.ops.aten.clone.default(view_default_448, memory_format = torch.contiguous_format);  view_default_448 = None
        _unsafe_view_default_94 = torch.ops.aten._unsafe_view.default(clone_default_82, [2048, 768]);  clone_default_82 = None
        t_default_280 = torch.ops.aten.t.default(t_default_19);  t_default_19 = None
        mm_default_104 = torch.ops.aten.mm.default(_unsafe_view_default_94, t_default_280);  t_default_280 = None
        t_default_281 = torch.ops.aten.t.default(_unsafe_view_default_94)
        mm_default_105 = torch.ops.aten.mm.default(t_default_281, view_default_54);  t_default_281 = view_default_54 = None
        t_default_282 = torch.ops.aten.t.default(mm_default_105);  mm_default_105 = None
        sum_dim_int_list_120 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_94, [0], True);  _unsafe_view_default_94 = None
        view_default_449 = torch.ops.aten.view.default(sum_dim_int_list_120, [768]);  sum_dim_int_list_120 = None
        t_default_283 = torch.ops.aten.t.default(t_default_282);  t_default_282 = None
        view_default_450 = torch.ops.aten.view.default(mm_default_104, [16, 128, 768]);  mm_default_104 = None
        add_tensor_159 = torch.ops.aten.add.Tensor(view_default_447, view_default_450);  view_default_447 = view_default_450 = None
        transpose_int_140 = torch.ops.aten.transpose.int(view_default_444, 1, 2);  view_default_444 = None
        clone_default_83 = torch.ops.aten.clone.default(transpose_int_140, memory_format = torch.contiguous_format);  transpose_int_140 = None
        _unsafe_view_default_95 = torch.ops.aten._unsafe_view.default(clone_default_83, [16, 128, 768]);  clone_default_83 = None
        view_default_451 = torch.ops.aten.view.default(_unsafe_view_default_95, [2048, 768]);  _unsafe_view_default_95 = None
        t_default_284 = torch.ops.aten.t.default(t_default_18);  t_default_18 = None
        mm_default_106 = torch.ops.aten.mm.default(view_default_451, t_default_284);  t_default_284 = None
        t_default_285 = torch.ops.aten.t.default(view_default_451)
        mm_default_107 = torch.ops.aten.mm.default(t_default_285, view_default_51);  t_default_285 = view_default_51 = None
        t_default_286 = torch.ops.aten.t.default(mm_default_107);  mm_default_107 = None
        sum_dim_int_list_121 = torch.ops.aten.sum.dim_IntList(view_default_451, [0], True);  view_default_451 = None
        view_default_452 = torch.ops.aten.view.default(sum_dim_int_list_121, [768]);  sum_dim_int_list_121 = None
        t_default_287 = torch.ops.aten.t.default(t_default_286);  t_default_286 = None
        view_default_453 = torch.ops.aten.view.default(mm_default_106, [16, 128, 768]);  mm_default_106 = None
        add_tensor_160 = torch.ops.aten.add.Tensor(add_tensor_159, view_default_453);  add_tensor_159 = view_default_453 = None
        sum_dim_int_list_122 = torch.ops.aten.sum.dim_IntList(add_tensor_160, [0, 1], True)
        view_default_454 = torch.ops.aten.view.default(sum_dim_int_list_122, [768]);  sum_dim_int_list_122 = None
        neg_default_34 = torch.ops.aten.neg.default(add_tensor_160)
        div_tensor_113 = torch.ops.aten.div.Tensor(mul_tensor_6, add_tensor_20);  mul_tensor_6 = None
        div_tensor_114 = torch.ops.aten.div.Tensor(div_tensor_113, add_tensor_20);  div_tensor_113 = None
        mul_tensor_155 = torch.ops.aten.mul.Tensor(neg_default_34, div_tensor_114);  neg_default_34 = div_tensor_114 = None
        div_tensor_115 = torch.ops.aten.div.Tensor(add_tensor_160, add_tensor_20);  add_tensor_160 = add_tensor_20 = None
        sum_dim_int_list_123 = torch.ops.aten.sum.dim_IntList(mul_tensor_155, [2], True);  mul_tensor_155 = None
        mul_tensor_156 = torch.ops.aten.mul.Tensor(div_tensor_115, primals_88);  primals_88 = None
        mul_tensor_157 = torch.ops.aten.mul.Tensor(div_tensor_115, sub_tensor_6);  div_tensor_115 = sub_tensor_6 = None
        sum_dim_int_list_124 = torch.ops.aten.sum.dim_IntList(mul_tensor_157, [0, 1], True);  mul_tensor_157 = None
        view_default_455 = torch.ops.aten.view.default(sum_dim_int_list_124, [768]);  sum_dim_int_list_124 = None
        neg_default_35 = torch.ops.aten.neg.default(mul_tensor_156)
        sum_dim_int_list_125 = torch.ops.aten.sum.dim_IntList(neg_default_35, [2], True);  neg_default_35 = None
        add_tensor_161 = torch.ops.aten.add.Tensor(add_tensor_158, mul_tensor_156);  add_tensor_158 = mul_tensor_156 = None
        mul_scalar_34 = torch.ops.aten.mul.Scalar(std_correction_6, 2)
        div_tensor_116 = torch.ops.aten.div.Tensor(sum_dim_int_list_123, mul_scalar_34);  sum_dim_int_list_123 = mul_scalar_34 = None
        eq_scalar_29 = torch.ops.aten.eq.Scalar(std_correction_6, 0);  std_correction_6 = None
        masked_fill__scalar_17 = torch.ops.aten.masked_fill_.Scalar(div_tensor_116, eq_scalar_29, 0);  div_tensor_116 = eq_scalar_29 = None
        mul_scalar_35 = torch.ops.aten.mul.Scalar(masked_fill__scalar_17, 0.002607561929595828);  masked_fill__scalar_17 = None
        mean_dim_41 = torch.ops.aten.mean.dim(add_tensor_19, [-1], True)
        sub_tensor_41 = torch.ops.aten.sub.Tensor(add_tensor_19, mean_dim_41);  add_tensor_19 = mean_dim_41 = None
        mul_tensor_158 = torch.ops.aten.mul.Tensor(mul_scalar_35, sub_tensor_41);  mul_scalar_35 = sub_tensor_41 = None
        add_tensor_162 = torch.ops.aten.add.Tensor(add_tensor_161, mul_tensor_158);  add_tensor_161 = mul_tensor_158 = None
        expand_default_65 = torch.ops.aten.expand.default(sum_dim_int_list_125, [16, 128, 768]);  sum_dim_int_list_125 = None
        div_scalar_17 = torch.ops.aten.div.Scalar(expand_default_65, 768);  expand_default_65 = None
        add_tensor_163 = torch.ops.aten.add.Tensor(add_tensor_162, div_scalar_17);  add_tensor_162 = div_scalar_17 = None
        view_default_456 = torch.ops.aten.view.default(add_tensor_163, [2048, 768])
        t_default_288 = torch.ops.aten.t.default(t_default_17);  t_default_17 = None
        mm_default_108 = torch.ops.aten.mm.default(view_default_456, t_default_288);  t_default_288 = None
        t_default_289 = torch.ops.aten.t.default(view_default_456)
        mm_default_109 = torch.ops.aten.mm.default(t_default_289, view_default_49);  t_default_289 = view_default_49 = None
        t_default_290 = torch.ops.aten.t.default(mm_default_109);  mm_default_109 = None
        sum_dim_int_list_126 = torch.ops.aten.sum.dim_IntList(view_default_456, [0], True);  view_default_456 = None
        view_default_457 = torch.ops.aten.view.default(sum_dim_int_list_126, [768]);  sum_dim_int_list_126 = None
        t_default_291 = torch.ops.aten.t.default(t_default_290);  t_default_290 = None
        view_default_458 = torch.ops.aten.view.default(mm_default_108, [16, 128, 3072]);  mm_default_108 = None
        to_dtype_27 = torch.ops.aten.to.dtype(view_default_458, torch.float32);  view_default_458 = None
        to_dtype_28 = torch.ops.aten.to.dtype(view_default_48, torch.float32);  view_default_48 = None
        mul_tensor_159 = torch.ops.aten.mul.Tensor(to_dtype_28, 0.7071067811865476)
        erf_default_9 = torch.ops.aten.erf.default(mul_tensor_159);  mul_tensor_159 = None
        add_tensor_164 = torch.ops.aten.add.Tensor(erf_default_9, 1);  erf_default_9 = None
        mul_tensor_160 = torch.ops.aten.mul.Tensor(add_tensor_164, 0.5);  add_tensor_164 = None
        mul_tensor_161 = torch.ops.aten.mul.Tensor(to_dtype_28, to_dtype_28)
        mul_tensor_162 = torch.ops.aten.mul.Tensor(mul_tensor_161, -0.5);  mul_tensor_161 = None
        exp_default_9 = torch.ops.aten.exp.default(mul_tensor_162);  mul_tensor_162 = None
        mul_tensor_163 = torch.ops.aten.mul.Tensor(exp_default_9, 0.3989422804014327);  exp_default_9 = None
        mul_tensor_164 = torch.ops.aten.mul.Tensor(to_dtype_28, mul_tensor_163);  to_dtype_28 = mul_tensor_163 = None
        add_tensor_165 = torch.ops.aten.add.Tensor(mul_tensor_160, mul_tensor_164);  mul_tensor_160 = mul_tensor_164 = None
        mul_tensor_165 = torch.ops.aten.mul.Tensor(to_dtype_27, add_tensor_165);  to_dtype_27 = add_tensor_165 = None
        to_dtype_29 = torch.ops.aten.to.dtype(mul_tensor_165, torch.float32);  mul_tensor_165 = None
        view_default_459 = torch.ops.aten.view.default(to_dtype_29, [2048, 3072]);  to_dtype_29 = None
        t_default_292 = torch.ops.aten.t.default(t_default_16);  t_default_16 = None
        mm_default_110 = torch.ops.aten.mm.default(view_default_459, t_default_292);  t_default_292 = None
        t_default_293 = torch.ops.aten.t.default(view_default_459)
        mm_default_111 = torch.ops.aten.mm.default(t_default_293, view_default_47);  t_default_293 = view_default_47 = None
        t_default_294 = torch.ops.aten.t.default(mm_default_111);  mm_default_111 = None
        sum_dim_int_list_127 = torch.ops.aten.sum.dim_IntList(view_default_459, [0], True);  view_default_459 = None
        view_default_460 = torch.ops.aten.view.default(sum_dim_int_list_127, [3072]);  sum_dim_int_list_127 = None
        t_default_295 = torch.ops.aten.t.default(t_default_294);  t_default_294 = None
        view_default_461 = torch.ops.aten.view.default(mm_default_110, [16, 128, 768]);  mm_default_110 = None
        sum_dim_int_list_128 = torch.ops.aten.sum.dim_IntList(view_default_461, [0, 1], True)
        view_default_462 = torch.ops.aten.view.default(sum_dim_int_list_128, [768]);  sum_dim_int_list_128 = None
        neg_default_36 = torch.ops.aten.neg.default(view_default_461)
        div_tensor_117 = torch.ops.aten.div.Tensor(mul_tensor_5, add_tensor_17);  mul_tensor_5 = None
        div_tensor_118 = torch.ops.aten.div.Tensor(div_tensor_117, add_tensor_17);  div_tensor_117 = None
        mul_tensor_166 = torch.ops.aten.mul.Tensor(neg_default_36, div_tensor_118);  neg_default_36 = div_tensor_118 = None
        div_tensor_119 = torch.ops.aten.div.Tensor(view_default_461, add_tensor_17);  view_default_461 = add_tensor_17 = None
        sum_dim_int_list_129 = torch.ops.aten.sum.dim_IntList(mul_tensor_166, [2], True);  mul_tensor_166 = None
        mul_tensor_167 = torch.ops.aten.mul.Tensor(div_tensor_119, primals_82);  primals_82 = None
        mul_tensor_168 = torch.ops.aten.mul.Tensor(div_tensor_119, sub_tensor_5);  div_tensor_119 = sub_tensor_5 = None
        sum_dim_int_list_130 = torch.ops.aten.sum.dim_IntList(mul_tensor_168, [0, 1], True);  mul_tensor_168 = None
        view_default_463 = torch.ops.aten.view.default(sum_dim_int_list_130, [768]);  sum_dim_int_list_130 = None
        neg_default_37 = torch.ops.aten.neg.default(mul_tensor_167)
        sum_dim_int_list_131 = torch.ops.aten.sum.dim_IntList(neg_default_37, [2], True);  neg_default_37 = None
        add_tensor_166 = torch.ops.aten.add.Tensor(add_tensor_163, mul_tensor_167);  add_tensor_163 = mul_tensor_167 = None
        mul_scalar_36 = torch.ops.aten.mul.Scalar(std_correction_5, 2)
        div_tensor_120 = torch.ops.aten.div.Tensor(sum_dim_int_list_129, mul_scalar_36);  sum_dim_int_list_129 = mul_scalar_36 = None
        eq_scalar_30 = torch.ops.aten.eq.Scalar(std_correction_5, 0);  std_correction_5 = None
        masked_fill__scalar_18 = torch.ops.aten.masked_fill_.Scalar(div_tensor_120, eq_scalar_30, 0);  div_tensor_120 = eq_scalar_30 = None
        mul_scalar_37 = torch.ops.aten.mul.Scalar(masked_fill__scalar_18, 0.002607561929595828);  masked_fill__scalar_18 = None
        mean_dim_42 = torch.ops.aten.mean.dim(add_tensor_16, [-1], True)
        sub_tensor_42 = torch.ops.aten.sub.Tensor(add_tensor_16, mean_dim_42);  add_tensor_16 = mean_dim_42 = None
        mul_tensor_169 = torch.ops.aten.mul.Tensor(mul_scalar_37, sub_tensor_42);  mul_scalar_37 = sub_tensor_42 = None
        add_tensor_167 = torch.ops.aten.add.Tensor(add_tensor_166, mul_tensor_169);  add_tensor_166 = mul_tensor_169 = None
        expand_default_66 = torch.ops.aten.expand.default(sum_dim_int_list_131, [16, 128, 768]);  sum_dim_int_list_131 = None
        div_scalar_18 = torch.ops.aten.div.Scalar(expand_default_66, 768);  expand_default_66 = None
        add_tensor_168 = torch.ops.aten.add.Tensor(add_tensor_167, div_scalar_18);  add_tensor_167 = div_scalar_18 = None
        view_default_464 = torch.ops.aten.view.default(add_tensor_168, [2048, 768])
        t_default_296 = torch.ops.aten.t.default(t_default_15);  t_default_15 = None
        mm_default_112 = torch.ops.aten.mm.default(view_default_464, t_default_296);  t_default_296 = None
        t_default_297 = torch.ops.aten.t.default(view_default_464)
        mm_default_113 = torch.ops.aten.mm.default(t_default_297, view_default_45);  t_default_297 = view_default_45 = None
        t_default_298 = torch.ops.aten.t.default(mm_default_113);  mm_default_113 = None
        sum_dim_int_list_132 = torch.ops.aten.sum.dim_IntList(view_default_464, [0], True);  view_default_464 = None
        view_default_465 = torch.ops.aten.view.default(sum_dim_int_list_132, [768]);  sum_dim_int_list_132 = None
        t_default_299 = torch.ops.aten.t.default(t_default_298);  t_default_298 = None
        view_default_466 = torch.ops.aten.view.default(mm_default_112, [16, 128, 768]);  mm_default_112 = None
        view_default_467 = torch.ops.aten.view.default(view_default_466, [16, 128, 12, 64]);  view_default_466 = None
        transpose_int_141 = torch.ops.aten.transpose.int(view_default_467, 1, 2);  view_default_467 = None
        clone_default_84 = torch.ops.aten.clone.default(transpose_int_141, memory_format = torch.contiguous_format);  transpose_int_141 = None
        _unsafe_view_default_96 = torch.ops.aten._unsafe_view.default(clone_default_84, [192, 128, 64]);  clone_default_84 = None
        transpose_int_142 = torch.ops.aten.transpose.int(view_default_43, 1, 2);  view_default_43 = None
        bmm_default_60 = torch.ops.aten.bmm.default(transpose_int_142, _unsafe_view_default_96);  transpose_int_142 = None
        transpose_int_143 = torch.ops.aten.transpose.int(_unsafe_view_default_13, 1, 2);  _unsafe_view_default_13 = None
        bmm_default_61 = torch.ops.aten.bmm.default(_unsafe_view_default_96, transpose_int_143);  _unsafe_view_default_96 = transpose_int_143 = None
        view_default_468 = torch.ops.aten.view.default(bmm_default_60, [16, 12, 128, 64]);  bmm_default_60 = None
        view_default_469 = torch.ops.aten.view.default(bmm_default_61, [16, 12, 128, 128]);  bmm_default_61 = None
        _softmax_backward_data_default_9 = torch.ops.aten._softmax_backward_data.default(view_default_469, _softmax_default_2, -1, torch.float32);  view_default_469 = _softmax_default_2 = None
        where_scalar_self_21 = torch.ops.aten.where.ScalarSelf(eq_scalar_2, 0.0, _softmax_backward_data_default_9);  eq_scalar_2 = _softmax_backward_data_default_9 = None
        div_tensor_121 = torch.ops.aten.div.Tensor(where_scalar_self_21, 8.0);  where_scalar_self_21 = None
        view_default_470 = torch.ops.aten.view.default(div_tensor_121, [192, 128, 128]);  div_tensor_121 = None
        transpose_int_144 = torch.ops.aten.transpose.int(_unsafe_view_default_10, 1, 2);  _unsafe_view_default_10 = None
        bmm_default_62 = torch.ops.aten.bmm.default(transpose_int_144, view_default_470);  transpose_int_144 = None
        transpose_int_145 = torch.ops.aten.transpose.int(_unsafe_view_default_11, 1, 2);  _unsafe_view_default_11 = None
        bmm_default_63 = torch.ops.aten.bmm.default(view_default_470, transpose_int_145);  view_default_470 = transpose_int_145 = None
        view_default_471 = torch.ops.aten.view.default(bmm_default_62, [16, 12, 64, 128]);  bmm_default_62 = None
        view_default_472 = torch.ops.aten.view.default(bmm_default_63, [16, 12, 128, 64]);  bmm_default_63 = None
        transpose_int_146 = torch.ops.aten.transpose.int(view_default_471, -2, -1);  view_default_471 = None
        transpose_int_147 = torch.ops.aten.transpose.int(view_default_468, 1, 2);  view_default_468 = None
        clone_default_85 = torch.ops.aten.clone.default(transpose_int_147, memory_format = torch.contiguous_format);  transpose_int_147 = None
        _unsafe_view_default_97 = torch.ops.aten._unsafe_view.default(clone_default_85, [16, 128, 768]);  clone_default_85 = None
        view_default_473 = torch.ops.aten.view.default(_unsafe_view_default_97, [2048, 768]);  _unsafe_view_default_97 = None
        t_default_300 = torch.ops.aten.t.default(t_default_14);  t_default_14 = None
        mm_default_114 = torch.ops.aten.mm.default(view_default_473, t_default_300);  t_default_300 = None
        t_default_301 = torch.ops.aten.t.default(view_default_473)
        mm_default_115 = torch.ops.aten.mm.default(t_default_301, view_default_40);  t_default_301 = view_default_40 = None
        t_default_302 = torch.ops.aten.t.default(mm_default_115);  mm_default_115 = None
        sum_dim_int_list_133 = torch.ops.aten.sum.dim_IntList(view_default_473, [0], True);  view_default_473 = None
        view_default_474 = torch.ops.aten.view.default(sum_dim_int_list_133, [768]);  sum_dim_int_list_133 = None
        t_default_303 = torch.ops.aten.t.default(t_default_302);  t_default_302 = None
        view_default_475 = torch.ops.aten.view.default(mm_default_114, [16, 128, 768]);  mm_default_114 = None
        transpose_int_148 = torch.ops.aten.transpose.int(transpose_int_146, 1, 2);  transpose_int_146 = None
        view_default_476 = torch.ops.aten.view.default(transpose_int_148, [16, 128, 768]);  transpose_int_148 = None
        clone_default_86 = torch.ops.aten.clone.default(view_default_476, memory_format = torch.contiguous_format);  view_default_476 = None
        _unsafe_view_default_98 = torch.ops.aten._unsafe_view.default(clone_default_86, [2048, 768]);  clone_default_86 = None
        t_default_304 = torch.ops.aten.t.default(t_default_13);  t_default_13 = None
        mm_default_116 = torch.ops.aten.mm.default(_unsafe_view_default_98, t_default_304);  t_default_304 = None
        t_default_305 = torch.ops.aten.t.default(_unsafe_view_default_98)
        mm_default_117 = torch.ops.aten.mm.default(t_default_305, view_default_37);  t_default_305 = view_default_37 = None
        t_default_306 = torch.ops.aten.t.default(mm_default_117);  mm_default_117 = None
        sum_dim_int_list_134 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_98, [0], True);  _unsafe_view_default_98 = None
        view_default_477 = torch.ops.aten.view.default(sum_dim_int_list_134, [768]);  sum_dim_int_list_134 = None
        t_default_307 = torch.ops.aten.t.default(t_default_306);  t_default_306 = None
        view_default_478 = torch.ops.aten.view.default(mm_default_116, [16, 128, 768]);  mm_default_116 = None
        add_tensor_169 = torch.ops.aten.add.Tensor(view_default_475, view_default_478);  view_default_475 = view_default_478 = None
        transpose_int_149 = torch.ops.aten.transpose.int(view_default_472, 1, 2);  view_default_472 = None
        clone_default_87 = torch.ops.aten.clone.default(transpose_int_149, memory_format = torch.contiguous_format);  transpose_int_149 = None
        _unsafe_view_default_99 = torch.ops.aten._unsafe_view.default(clone_default_87, [16, 128, 768]);  clone_default_87 = None
        view_default_479 = torch.ops.aten.view.default(_unsafe_view_default_99, [2048, 768]);  _unsafe_view_default_99 = None
        t_default_308 = torch.ops.aten.t.default(t_default_12);  t_default_12 = None
        mm_default_118 = torch.ops.aten.mm.default(view_default_479, t_default_308);  t_default_308 = None
        t_default_309 = torch.ops.aten.t.default(view_default_479)
        mm_default_119 = torch.ops.aten.mm.default(t_default_309, view_default_34);  t_default_309 = view_default_34 = None
        t_default_310 = torch.ops.aten.t.default(mm_default_119);  mm_default_119 = None
        sum_dim_int_list_135 = torch.ops.aten.sum.dim_IntList(view_default_479, [0], True);  view_default_479 = None
        view_default_480 = torch.ops.aten.view.default(sum_dim_int_list_135, [768]);  sum_dim_int_list_135 = None
        t_default_311 = torch.ops.aten.t.default(t_default_310);  t_default_310 = None
        view_default_481 = torch.ops.aten.view.default(mm_default_118, [16, 128, 768]);  mm_default_118 = None
        add_tensor_170 = torch.ops.aten.add.Tensor(add_tensor_169, view_default_481);  add_tensor_169 = view_default_481 = None
        sum_dim_int_list_136 = torch.ops.aten.sum.dim_IntList(add_tensor_170, [0, 1], True)
        view_default_482 = torch.ops.aten.view.default(sum_dim_int_list_136, [768]);  sum_dim_int_list_136 = None
        neg_default_38 = torch.ops.aten.neg.default(add_tensor_170)
        div_tensor_122 = torch.ops.aten.div.Tensor(mul_tensor_4, add_tensor_14);  mul_tensor_4 = None
        div_tensor_123 = torch.ops.aten.div.Tensor(div_tensor_122, add_tensor_14);  div_tensor_122 = None
        mul_tensor_170 = torch.ops.aten.mul.Tensor(neg_default_38, div_tensor_123);  neg_default_38 = div_tensor_123 = None
        div_tensor_124 = torch.ops.aten.div.Tensor(add_tensor_170, add_tensor_14);  add_tensor_170 = add_tensor_14 = None
        sum_dim_int_list_137 = torch.ops.aten.sum.dim_IntList(mul_tensor_170, [2], True);  mul_tensor_170 = None
        mul_tensor_171 = torch.ops.aten.mul.Tensor(div_tensor_124, primals_72);  primals_72 = None
        mul_tensor_172 = torch.ops.aten.mul.Tensor(div_tensor_124, sub_tensor_4);  div_tensor_124 = sub_tensor_4 = None
        sum_dim_int_list_138 = torch.ops.aten.sum.dim_IntList(mul_tensor_172, [0, 1], True);  mul_tensor_172 = None
        view_default_483 = torch.ops.aten.view.default(sum_dim_int_list_138, [768]);  sum_dim_int_list_138 = None
        neg_default_39 = torch.ops.aten.neg.default(mul_tensor_171)
        sum_dim_int_list_139 = torch.ops.aten.sum.dim_IntList(neg_default_39, [2], True);  neg_default_39 = None
        add_tensor_171 = torch.ops.aten.add.Tensor(add_tensor_168, mul_tensor_171);  add_tensor_168 = mul_tensor_171 = None
        mul_scalar_38 = torch.ops.aten.mul.Scalar(std_correction_4, 2)
        div_tensor_125 = torch.ops.aten.div.Tensor(sum_dim_int_list_137, mul_scalar_38);  sum_dim_int_list_137 = mul_scalar_38 = None
        eq_scalar_31 = torch.ops.aten.eq.Scalar(std_correction_4, 0);  std_correction_4 = None
        masked_fill__scalar_19 = torch.ops.aten.masked_fill_.Scalar(div_tensor_125, eq_scalar_31, 0);  div_tensor_125 = eq_scalar_31 = None
        mul_scalar_39 = torch.ops.aten.mul.Scalar(masked_fill__scalar_19, 0.002607561929595828);  masked_fill__scalar_19 = None
        mean_dim_43 = torch.ops.aten.mean.dim(add_tensor_13, [-1], True)
        sub_tensor_43 = torch.ops.aten.sub.Tensor(add_tensor_13, mean_dim_43);  add_tensor_13 = mean_dim_43 = None
        mul_tensor_173 = torch.ops.aten.mul.Tensor(mul_scalar_39, sub_tensor_43);  mul_scalar_39 = sub_tensor_43 = None
        add_tensor_172 = torch.ops.aten.add.Tensor(add_tensor_171, mul_tensor_173);  add_tensor_171 = mul_tensor_173 = None
        expand_default_67 = torch.ops.aten.expand.default(sum_dim_int_list_139, [16, 128, 768]);  sum_dim_int_list_139 = None
        div_scalar_19 = torch.ops.aten.div.Scalar(expand_default_67, 768);  expand_default_67 = None
        add_tensor_173 = torch.ops.aten.add.Tensor(add_tensor_172, div_scalar_19);  add_tensor_172 = div_scalar_19 = None
        view_default_484 = torch.ops.aten.view.default(add_tensor_173, [2048, 768])
        t_default_312 = torch.ops.aten.t.default(t_default_11);  t_default_11 = None
        mm_default_120 = torch.ops.aten.mm.default(view_default_484, t_default_312);  t_default_312 = None
        t_default_313 = torch.ops.aten.t.default(view_default_484)
        mm_default_121 = torch.ops.aten.mm.default(t_default_313, view_default_32);  t_default_313 = view_default_32 = None
        t_default_314 = torch.ops.aten.t.default(mm_default_121);  mm_default_121 = None
        sum_dim_int_list_140 = torch.ops.aten.sum.dim_IntList(view_default_484, [0], True);  view_default_484 = None
        view_default_485 = torch.ops.aten.view.default(sum_dim_int_list_140, [768]);  sum_dim_int_list_140 = None
        t_default_315 = torch.ops.aten.t.default(t_default_314);  t_default_314 = None
        view_default_486 = torch.ops.aten.view.default(mm_default_120, [16, 128, 3072]);  mm_default_120 = None
        to_dtype_30 = torch.ops.aten.to.dtype(view_default_486, torch.float32);  view_default_486 = None
        to_dtype_31 = torch.ops.aten.to.dtype(view_default_31, torch.float32);  view_default_31 = None
        mul_tensor_174 = torch.ops.aten.mul.Tensor(to_dtype_31, 0.7071067811865476)
        erf_default_10 = torch.ops.aten.erf.default(mul_tensor_174);  mul_tensor_174 = None
        add_tensor_174 = torch.ops.aten.add.Tensor(erf_default_10, 1);  erf_default_10 = None
        mul_tensor_175 = torch.ops.aten.mul.Tensor(add_tensor_174, 0.5);  add_tensor_174 = None
        mul_tensor_176 = torch.ops.aten.mul.Tensor(to_dtype_31, to_dtype_31)
        mul_tensor_177 = torch.ops.aten.mul.Tensor(mul_tensor_176, -0.5);  mul_tensor_176 = None
        exp_default_10 = torch.ops.aten.exp.default(mul_tensor_177);  mul_tensor_177 = None
        mul_tensor_178 = torch.ops.aten.mul.Tensor(exp_default_10, 0.3989422804014327);  exp_default_10 = None
        mul_tensor_179 = torch.ops.aten.mul.Tensor(to_dtype_31, mul_tensor_178);  to_dtype_31 = mul_tensor_178 = None
        add_tensor_175 = torch.ops.aten.add.Tensor(mul_tensor_175, mul_tensor_179);  mul_tensor_175 = mul_tensor_179 = None
        mul_tensor_180 = torch.ops.aten.mul.Tensor(to_dtype_30, add_tensor_175);  to_dtype_30 = add_tensor_175 = None
        to_dtype_32 = torch.ops.aten.to.dtype(mul_tensor_180, torch.float32);  mul_tensor_180 = None
        view_default_487 = torch.ops.aten.view.default(to_dtype_32, [2048, 3072]);  to_dtype_32 = None
        t_default_316 = torch.ops.aten.t.default(t_default_10);  t_default_10 = None
        mm_default_122 = torch.ops.aten.mm.default(view_default_487, t_default_316);  t_default_316 = None
        t_default_317 = torch.ops.aten.t.default(view_default_487)
        mm_default_123 = torch.ops.aten.mm.default(t_default_317, view_default_30);  t_default_317 = view_default_30 = None
        t_default_318 = torch.ops.aten.t.default(mm_default_123);  mm_default_123 = None
        sum_dim_int_list_141 = torch.ops.aten.sum.dim_IntList(view_default_487, [0], True);  view_default_487 = None
        view_default_488 = torch.ops.aten.view.default(sum_dim_int_list_141, [3072]);  sum_dim_int_list_141 = None
        t_default_319 = torch.ops.aten.t.default(t_default_318);  t_default_318 = None
        view_default_489 = torch.ops.aten.view.default(mm_default_122, [16, 128, 768]);  mm_default_122 = None
        sum_dim_int_list_142 = torch.ops.aten.sum.dim_IntList(view_default_489, [0, 1], True)
        view_default_490 = torch.ops.aten.view.default(sum_dim_int_list_142, [768]);  sum_dim_int_list_142 = None
        neg_default_40 = torch.ops.aten.neg.default(view_default_489)
        div_tensor_126 = torch.ops.aten.div.Tensor(mul_tensor_3, add_tensor_11);  mul_tensor_3 = None
        div_tensor_127 = torch.ops.aten.div.Tensor(div_tensor_126, add_tensor_11);  div_tensor_126 = None
        mul_tensor_181 = torch.ops.aten.mul.Tensor(neg_default_40, div_tensor_127);  neg_default_40 = div_tensor_127 = None
        div_tensor_128 = torch.ops.aten.div.Tensor(view_default_489, add_tensor_11);  view_default_489 = add_tensor_11 = None
        sum_dim_int_list_143 = torch.ops.aten.sum.dim_IntList(mul_tensor_181, [2], True);  mul_tensor_181 = None
        mul_tensor_182 = torch.ops.aten.mul.Tensor(div_tensor_128, primals_66);  primals_66 = None
        mul_tensor_183 = torch.ops.aten.mul.Tensor(div_tensor_128, sub_tensor_3);  div_tensor_128 = sub_tensor_3 = None
        sum_dim_int_list_144 = torch.ops.aten.sum.dim_IntList(mul_tensor_183, [0, 1], True);  mul_tensor_183 = None
        view_default_491 = torch.ops.aten.view.default(sum_dim_int_list_144, [768]);  sum_dim_int_list_144 = None
        neg_default_41 = torch.ops.aten.neg.default(mul_tensor_182)
        sum_dim_int_list_145 = torch.ops.aten.sum.dim_IntList(neg_default_41, [2], True);  neg_default_41 = None
        add_tensor_176 = torch.ops.aten.add.Tensor(add_tensor_173, mul_tensor_182);  add_tensor_173 = mul_tensor_182 = None
        mul_scalar_40 = torch.ops.aten.mul.Scalar(std_correction_3, 2)
        div_tensor_129 = torch.ops.aten.div.Tensor(sum_dim_int_list_143, mul_scalar_40);  sum_dim_int_list_143 = mul_scalar_40 = None
        eq_scalar_32 = torch.ops.aten.eq.Scalar(std_correction_3, 0);  std_correction_3 = None
        masked_fill__scalar_20 = torch.ops.aten.masked_fill_.Scalar(div_tensor_129, eq_scalar_32, 0);  div_tensor_129 = eq_scalar_32 = None
        mul_scalar_41 = torch.ops.aten.mul.Scalar(masked_fill__scalar_20, 0.002607561929595828);  masked_fill__scalar_20 = None
        mean_dim_44 = torch.ops.aten.mean.dim(add_tensor_10, [-1], True)
        sub_tensor_44 = torch.ops.aten.sub.Tensor(add_tensor_10, mean_dim_44);  add_tensor_10 = mean_dim_44 = None
        mul_tensor_184 = torch.ops.aten.mul.Tensor(mul_scalar_41, sub_tensor_44);  mul_scalar_41 = sub_tensor_44 = None
        add_tensor_177 = torch.ops.aten.add.Tensor(add_tensor_176, mul_tensor_184);  add_tensor_176 = mul_tensor_184 = None
        expand_default_68 = torch.ops.aten.expand.default(sum_dim_int_list_145, [16, 128, 768]);  sum_dim_int_list_145 = None
        div_scalar_20 = torch.ops.aten.div.Scalar(expand_default_68, 768);  expand_default_68 = None
        add_tensor_178 = torch.ops.aten.add.Tensor(add_tensor_177, div_scalar_20);  add_tensor_177 = div_scalar_20 = None
        view_default_492 = torch.ops.aten.view.default(add_tensor_178, [2048, 768])
        t_default_320 = torch.ops.aten.t.default(t_default_9);  t_default_9 = None
        mm_default_124 = torch.ops.aten.mm.default(view_default_492, t_default_320);  t_default_320 = None
        t_default_321 = torch.ops.aten.t.default(view_default_492)
        mm_default_125 = torch.ops.aten.mm.default(t_default_321, view_default_28);  t_default_321 = view_default_28 = None
        t_default_322 = torch.ops.aten.t.default(mm_default_125);  mm_default_125 = None
        sum_dim_int_list_146 = torch.ops.aten.sum.dim_IntList(view_default_492, [0], True);  view_default_492 = None
        view_default_493 = torch.ops.aten.view.default(sum_dim_int_list_146, [768]);  sum_dim_int_list_146 = None
        t_default_323 = torch.ops.aten.t.default(t_default_322);  t_default_322 = None
        view_default_494 = torch.ops.aten.view.default(mm_default_124, [16, 128, 768]);  mm_default_124 = None
        view_default_495 = torch.ops.aten.view.default(view_default_494, [16, 128, 12, 64]);  view_default_494 = None
        transpose_int_150 = torch.ops.aten.transpose.int(view_default_495, 1, 2);  view_default_495 = None
        clone_default_88 = torch.ops.aten.clone.default(transpose_int_150, memory_format = torch.contiguous_format);  transpose_int_150 = None
        _unsafe_view_default_100 = torch.ops.aten._unsafe_view.default(clone_default_88, [192, 128, 64]);  clone_default_88 = None
        transpose_int_151 = torch.ops.aten.transpose.int(view_default_26, 1, 2);  view_default_26 = None
        bmm_default_64 = torch.ops.aten.bmm.default(transpose_int_151, _unsafe_view_default_100);  transpose_int_151 = None
        transpose_int_152 = torch.ops.aten.transpose.int(_unsafe_view_default_8, 1, 2);  _unsafe_view_default_8 = None
        bmm_default_65 = torch.ops.aten.bmm.default(_unsafe_view_default_100, transpose_int_152);  _unsafe_view_default_100 = transpose_int_152 = None
        view_default_496 = torch.ops.aten.view.default(bmm_default_64, [16, 12, 128, 64]);  bmm_default_64 = None
        view_default_497 = torch.ops.aten.view.default(bmm_default_65, [16, 12, 128, 128]);  bmm_default_65 = None
        _softmax_backward_data_default_10 = torch.ops.aten._softmax_backward_data.default(view_default_497, _softmax_default_1, -1, torch.float32);  view_default_497 = _softmax_default_1 = None
        where_scalar_self_22 = torch.ops.aten.where.ScalarSelf(eq_scalar_1, 0.0, _softmax_backward_data_default_10);  eq_scalar_1 = _softmax_backward_data_default_10 = None
        div_tensor_130 = torch.ops.aten.div.Tensor(where_scalar_self_22, 8.0);  where_scalar_self_22 = None
        view_default_498 = torch.ops.aten.view.default(div_tensor_130, [192, 128, 128]);  div_tensor_130 = None
        transpose_int_153 = torch.ops.aten.transpose.int(_unsafe_view_default_5, 1, 2);  _unsafe_view_default_5 = None
        bmm_default_66 = torch.ops.aten.bmm.default(transpose_int_153, view_default_498);  transpose_int_153 = None
        transpose_int_154 = torch.ops.aten.transpose.int(_unsafe_view_default_6, 1, 2);  _unsafe_view_default_6 = None
        bmm_default_67 = torch.ops.aten.bmm.default(view_default_498, transpose_int_154);  view_default_498 = transpose_int_154 = None
        view_default_499 = torch.ops.aten.view.default(bmm_default_66, [16, 12, 64, 128]);  bmm_default_66 = None
        view_default_500 = torch.ops.aten.view.default(bmm_default_67, [16, 12, 128, 64]);  bmm_default_67 = None
        transpose_int_155 = torch.ops.aten.transpose.int(view_default_499, -2, -1);  view_default_499 = None
        transpose_int_156 = torch.ops.aten.transpose.int(view_default_496, 1, 2);  view_default_496 = None
        clone_default_89 = torch.ops.aten.clone.default(transpose_int_156, memory_format = torch.contiguous_format);  transpose_int_156 = None
        _unsafe_view_default_101 = torch.ops.aten._unsafe_view.default(clone_default_89, [16, 128, 768]);  clone_default_89 = None
        view_default_501 = torch.ops.aten.view.default(_unsafe_view_default_101, [2048, 768]);  _unsafe_view_default_101 = None
        t_default_324 = torch.ops.aten.t.default(t_default_8);  t_default_8 = None
        mm_default_126 = torch.ops.aten.mm.default(view_default_501, t_default_324);  t_default_324 = None
        t_default_325 = torch.ops.aten.t.default(view_default_501)
        mm_default_127 = torch.ops.aten.mm.default(t_default_325, view_default_23);  t_default_325 = view_default_23 = None
        t_default_326 = torch.ops.aten.t.default(mm_default_127);  mm_default_127 = None
        sum_dim_int_list_147 = torch.ops.aten.sum.dim_IntList(view_default_501, [0], True);  view_default_501 = None
        view_default_502 = torch.ops.aten.view.default(sum_dim_int_list_147, [768]);  sum_dim_int_list_147 = None
        t_default_327 = torch.ops.aten.t.default(t_default_326);  t_default_326 = None
        view_default_503 = torch.ops.aten.view.default(mm_default_126, [16, 128, 768]);  mm_default_126 = None
        transpose_int_157 = torch.ops.aten.transpose.int(transpose_int_155, 1, 2);  transpose_int_155 = None
        view_default_504 = torch.ops.aten.view.default(transpose_int_157, [16, 128, 768]);  transpose_int_157 = None
        clone_default_90 = torch.ops.aten.clone.default(view_default_504, memory_format = torch.contiguous_format);  view_default_504 = None
        _unsafe_view_default_102 = torch.ops.aten._unsafe_view.default(clone_default_90, [2048, 768]);  clone_default_90 = None
        t_default_328 = torch.ops.aten.t.default(t_default_7);  t_default_7 = None
        mm_default_128 = torch.ops.aten.mm.default(_unsafe_view_default_102, t_default_328);  t_default_328 = None
        t_default_329 = torch.ops.aten.t.default(_unsafe_view_default_102)
        mm_default_129 = torch.ops.aten.mm.default(t_default_329, view_default_20);  t_default_329 = view_default_20 = None
        t_default_330 = torch.ops.aten.t.default(mm_default_129);  mm_default_129 = None
        sum_dim_int_list_148 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_102, [0], True);  _unsafe_view_default_102 = None
        view_default_505 = torch.ops.aten.view.default(sum_dim_int_list_148, [768]);  sum_dim_int_list_148 = None
        t_default_331 = torch.ops.aten.t.default(t_default_330);  t_default_330 = None
        view_default_506 = torch.ops.aten.view.default(mm_default_128, [16, 128, 768]);  mm_default_128 = None
        add_tensor_179 = torch.ops.aten.add.Tensor(view_default_503, view_default_506);  view_default_503 = view_default_506 = None
        transpose_int_158 = torch.ops.aten.transpose.int(view_default_500, 1, 2);  view_default_500 = None
        clone_default_91 = torch.ops.aten.clone.default(transpose_int_158, memory_format = torch.contiguous_format);  transpose_int_158 = None
        _unsafe_view_default_103 = torch.ops.aten._unsafe_view.default(clone_default_91, [16, 128, 768]);  clone_default_91 = None
        view_default_507 = torch.ops.aten.view.default(_unsafe_view_default_103, [2048, 768]);  _unsafe_view_default_103 = None
        t_default_332 = torch.ops.aten.t.default(t_default_6);  t_default_6 = None
        mm_default_130 = torch.ops.aten.mm.default(view_default_507, t_default_332);  t_default_332 = None
        t_default_333 = torch.ops.aten.t.default(view_default_507)
        mm_default_131 = torch.ops.aten.mm.default(t_default_333, view_default_17);  t_default_333 = view_default_17 = None
        t_default_334 = torch.ops.aten.t.default(mm_default_131);  mm_default_131 = None
        sum_dim_int_list_149 = torch.ops.aten.sum.dim_IntList(view_default_507, [0], True);  view_default_507 = None
        view_default_508 = torch.ops.aten.view.default(sum_dim_int_list_149, [768]);  sum_dim_int_list_149 = None
        t_default_335 = torch.ops.aten.t.default(t_default_334);  t_default_334 = None
        view_default_509 = torch.ops.aten.view.default(mm_default_130, [16, 128, 768]);  mm_default_130 = None
        add_tensor_180 = torch.ops.aten.add.Tensor(add_tensor_179, view_default_509);  add_tensor_179 = view_default_509 = None
        sum_dim_int_list_150 = torch.ops.aten.sum.dim_IntList(add_tensor_180, [0, 1], True)
        view_default_510 = torch.ops.aten.view.default(sum_dim_int_list_150, [768]);  sum_dim_int_list_150 = None
        neg_default_42 = torch.ops.aten.neg.default(add_tensor_180)
        div_tensor_131 = torch.ops.aten.div.Tensor(mul_tensor_2, add_tensor_8);  mul_tensor_2 = None
        div_tensor_132 = torch.ops.aten.div.Tensor(div_tensor_131, add_tensor_8);  div_tensor_131 = None
        mul_tensor_185 = torch.ops.aten.mul.Tensor(neg_default_42, div_tensor_132);  neg_default_42 = div_tensor_132 = None
        div_tensor_133 = torch.ops.aten.div.Tensor(add_tensor_180, add_tensor_8);  add_tensor_180 = add_tensor_8 = None
        sum_dim_int_list_151 = torch.ops.aten.sum.dim_IntList(mul_tensor_185, [2], True);  mul_tensor_185 = None
        mul_tensor_186 = torch.ops.aten.mul.Tensor(div_tensor_133, primals_56);  primals_56 = None
        mul_tensor_187 = torch.ops.aten.mul.Tensor(div_tensor_133, sub_tensor_2);  div_tensor_133 = sub_tensor_2 = None
        sum_dim_int_list_152 = torch.ops.aten.sum.dim_IntList(mul_tensor_187, [0, 1], True);  mul_tensor_187 = None
        view_default_511 = torch.ops.aten.view.default(sum_dim_int_list_152, [768]);  sum_dim_int_list_152 = None
        neg_default_43 = torch.ops.aten.neg.default(mul_tensor_186)
        sum_dim_int_list_153 = torch.ops.aten.sum.dim_IntList(neg_default_43, [2], True);  neg_default_43 = None
        add_tensor_181 = torch.ops.aten.add.Tensor(add_tensor_178, mul_tensor_186);  add_tensor_178 = mul_tensor_186 = None
        mul_scalar_42 = torch.ops.aten.mul.Scalar(std_correction_2, 2)
        div_tensor_134 = torch.ops.aten.div.Tensor(sum_dim_int_list_151, mul_scalar_42);  sum_dim_int_list_151 = mul_scalar_42 = None
        eq_scalar_33 = torch.ops.aten.eq.Scalar(std_correction_2, 0);  std_correction_2 = None
        masked_fill__scalar_21 = torch.ops.aten.masked_fill_.Scalar(div_tensor_134, eq_scalar_33, 0);  div_tensor_134 = eq_scalar_33 = None
        mul_scalar_43 = torch.ops.aten.mul.Scalar(masked_fill__scalar_21, 0.002607561929595828);  masked_fill__scalar_21 = None
        mean_dim_45 = torch.ops.aten.mean.dim(add_tensor_7, [-1], True)
        sub_tensor_45 = torch.ops.aten.sub.Tensor(add_tensor_7, mean_dim_45);  add_tensor_7 = mean_dim_45 = None
        mul_tensor_188 = torch.ops.aten.mul.Tensor(mul_scalar_43, sub_tensor_45);  mul_scalar_43 = sub_tensor_45 = None
        add_tensor_182 = torch.ops.aten.add.Tensor(add_tensor_181, mul_tensor_188);  add_tensor_181 = mul_tensor_188 = None
        expand_default_69 = torch.ops.aten.expand.default(sum_dim_int_list_153, [16, 128, 768]);  sum_dim_int_list_153 = None
        div_scalar_21 = torch.ops.aten.div.Scalar(expand_default_69, 768);  expand_default_69 = None
        add_tensor_183 = torch.ops.aten.add.Tensor(add_tensor_182, div_scalar_21);  add_tensor_182 = div_scalar_21 = None
        view_default_512 = torch.ops.aten.view.default(add_tensor_183, [2048, 768])
        t_default_336 = torch.ops.aten.t.default(t_default_5);  t_default_5 = None
        mm_default_132 = torch.ops.aten.mm.default(view_default_512, t_default_336);  t_default_336 = None
        t_default_337 = torch.ops.aten.t.default(view_default_512)
        mm_default_133 = torch.ops.aten.mm.default(t_default_337, view_default_15);  t_default_337 = view_default_15 = None
        t_default_338 = torch.ops.aten.t.default(mm_default_133);  mm_default_133 = None
        sum_dim_int_list_154 = torch.ops.aten.sum.dim_IntList(view_default_512, [0], True);  view_default_512 = None
        view_default_513 = torch.ops.aten.view.default(sum_dim_int_list_154, [768]);  sum_dim_int_list_154 = None
        t_default_339 = torch.ops.aten.t.default(t_default_338);  t_default_338 = None
        view_default_514 = torch.ops.aten.view.default(mm_default_132, [16, 128, 3072]);  mm_default_132 = None
        to_dtype_33 = torch.ops.aten.to.dtype(view_default_514, torch.float32);  view_default_514 = None
        to_dtype_34 = torch.ops.aten.to.dtype(view_default_14, torch.float32);  view_default_14 = None
        mul_tensor_189 = torch.ops.aten.mul.Tensor(to_dtype_34, 0.7071067811865476)
        erf_default_11 = torch.ops.aten.erf.default(mul_tensor_189);  mul_tensor_189 = None
        add_tensor_184 = torch.ops.aten.add.Tensor(erf_default_11, 1);  erf_default_11 = None
        mul_tensor_190 = torch.ops.aten.mul.Tensor(add_tensor_184, 0.5);  add_tensor_184 = None
        mul_tensor_191 = torch.ops.aten.mul.Tensor(to_dtype_34, to_dtype_34)
        mul_tensor_192 = torch.ops.aten.mul.Tensor(mul_tensor_191, -0.5);  mul_tensor_191 = None
        exp_default_11 = torch.ops.aten.exp.default(mul_tensor_192);  mul_tensor_192 = None
        mul_tensor_193 = torch.ops.aten.mul.Tensor(exp_default_11, 0.3989422804014327);  exp_default_11 = None
        mul_tensor_194 = torch.ops.aten.mul.Tensor(to_dtype_34, mul_tensor_193);  to_dtype_34 = mul_tensor_193 = None
        add_tensor_185 = torch.ops.aten.add.Tensor(mul_tensor_190, mul_tensor_194);  mul_tensor_190 = mul_tensor_194 = None
        mul_tensor_195 = torch.ops.aten.mul.Tensor(to_dtype_33, add_tensor_185);  to_dtype_33 = add_tensor_185 = None
        to_dtype_35 = torch.ops.aten.to.dtype(mul_tensor_195, torch.float32);  mul_tensor_195 = None
        view_default_515 = torch.ops.aten.view.default(to_dtype_35, [2048, 3072]);  to_dtype_35 = None
        t_default_340 = torch.ops.aten.t.default(t_default_4);  t_default_4 = None
        mm_default_134 = torch.ops.aten.mm.default(view_default_515, t_default_340);  t_default_340 = None
        t_default_341 = torch.ops.aten.t.default(view_default_515)
        mm_default_135 = torch.ops.aten.mm.default(t_default_341, view_default_13);  t_default_341 = view_default_13 = None
        t_default_342 = torch.ops.aten.t.default(mm_default_135);  mm_default_135 = None
        sum_dim_int_list_155 = torch.ops.aten.sum.dim_IntList(view_default_515, [0], True);  view_default_515 = None
        view_default_516 = torch.ops.aten.view.default(sum_dim_int_list_155, [3072]);  sum_dim_int_list_155 = None
        t_default_343 = torch.ops.aten.t.default(t_default_342);  t_default_342 = None
        view_default_517 = torch.ops.aten.view.default(mm_default_134, [16, 128, 768]);  mm_default_134 = None
        sum_dim_int_list_156 = torch.ops.aten.sum.dim_IntList(view_default_517, [0, 1], True)
        view_default_518 = torch.ops.aten.view.default(sum_dim_int_list_156, [768]);  sum_dim_int_list_156 = None
        neg_default_44 = torch.ops.aten.neg.default(view_default_517)
        div_tensor_135 = torch.ops.aten.div.Tensor(mul_tensor_1, add_tensor_5);  mul_tensor_1 = None
        div_tensor_136 = torch.ops.aten.div.Tensor(div_tensor_135, add_tensor_5);  div_tensor_135 = None
        mul_tensor_196 = torch.ops.aten.mul.Tensor(neg_default_44, div_tensor_136);  neg_default_44 = div_tensor_136 = None
        div_tensor_137 = torch.ops.aten.div.Tensor(view_default_517, add_tensor_5);  view_default_517 = add_tensor_5 = None
        sum_dim_int_list_157 = torch.ops.aten.sum.dim_IntList(mul_tensor_196, [2], True);  mul_tensor_196 = None
        mul_tensor_197 = torch.ops.aten.mul.Tensor(div_tensor_137, primals_18);  primals_18 = None
        mul_tensor_198 = torch.ops.aten.mul.Tensor(div_tensor_137, sub_tensor_1);  div_tensor_137 = sub_tensor_1 = None
        sum_dim_int_list_158 = torch.ops.aten.sum.dim_IntList(mul_tensor_198, [0, 1], True);  mul_tensor_198 = None
        view_default_519 = torch.ops.aten.view.default(sum_dim_int_list_158, [768]);  sum_dim_int_list_158 = None
        neg_default_45 = torch.ops.aten.neg.default(mul_tensor_197)
        sum_dim_int_list_159 = torch.ops.aten.sum.dim_IntList(neg_default_45, [2], True);  neg_default_45 = None
        add_tensor_186 = torch.ops.aten.add.Tensor(add_tensor_183, mul_tensor_197);  add_tensor_183 = mul_tensor_197 = None
        mul_scalar_44 = torch.ops.aten.mul.Scalar(std_correction_1, 2)
        div_tensor_138 = torch.ops.aten.div.Tensor(sum_dim_int_list_157, mul_scalar_44);  sum_dim_int_list_157 = mul_scalar_44 = None
        eq_scalar_34 = torch.ops.aten.eq.Scalar(std_correction_1, 0);  std_correction_1 = None
        masked_fill__scalar_22 = torch.ops.aten.masked_fill_.Scalar(div_tensor_138, eq_scalar_34, 0);  div_tensor_138 = eq_scalar_34 = None
        mul_scalar_45 = torch.ops.aten.mul.Scalar(masked_fill__scalar_22, 0.002607561929595828);  masked_fill__scalar_22 = None
        mean_dim_46 = torch.ops.aten.mean.dim(add_tensor_4, [-1], True)
        sub_tensor_46 = torch.ops.aten.sub.Tensor(add_tensor_4, mean_dim_46);  add_tensor_4 = mean_dim_46 = None
        mul_tensor_199 = torch.ops.aten.mul.Tensor(mul_scalar_45, sub_tensor_46);  mul_scalar_45 = sub_tensor_46 = None
        add_tensor_187 = torch.ops.aten.add.Tensor(add_tensor_186, mul_tensor_199);  add_tensor_186 = mul_tensor_199 = None
        expand_default_70 = torch.ops.aten.expand.default(sum_dim_int_list_159, [16, 128, 768]);  sum_dim_int_list_159 = None
        div_scalar_22 = torch.ops.aten.div.Scalar(expand_default_70, 768);  expand_default_70 = None
        add_tensor_188 = torch.ops.aten.add.Tensor(add_tensor_187, div_scalar_22);  add_tensor_187 = div_scalar_22 = None
        view_default_520 = torch.ops.aten.view.default(add_tensor_188, [2048, 768])
        t_default_344 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        mm_default_136 = torch.ops.aten.mm.default(view_default_520, t_default_344);  t_default_344 = None
        t_default_345 = torch.ops.aten.t.default(view_default_520)
        mm_default_137 = torch.ops.aten.mm.default(t_default_345, view_default_11);  t_default_345 = view_default_11 = None
        t_default_346 = torch.ops.aten.t.default(mm_default_137);  mm_default_137 = None
        sum_dim_int_list_160 = torch.ops.aten.sum.dim_IntList(view_default_520, [0], True);  view_default_520 = None
        view_default_521 = torch.ops.aten.view.default(sum_dim_int_list_160, [768]);  sum_dim_int_list_160 = None
        t_default_347 = torch.ops.aten.t.default(t_default_346);  t_default_346 = None
        view_default_522 = torch.ops.aten.view.default(mm_default_136, [16, 128, 768]);  mm_default_136 = None
        view_default_523 = torch.ops.aten.view.default(view_default_522, [16, 128, 12, 64]);  view_default_522 = None
        transpose_int_159 = torch.ops.aten.transpose.int(view_default_523, 1, 2);  view_default_523 = None
        clone_default_92 = torch.ops.aten.clone.default(transpose_int_159, memory_format = torch.contiguous_format);  transpose_int_159 = None
        _unsafe_view_default_104 = torch.ops.aten._unsafe_view.default(clone_default_92, [192, 128, 64]);  clone_default_92 = None
        transpose_int_160 = torch.ops.aten.transpose.int(view_default_9, 1, 2);  view_default_9 = None
        bmm_default_68 = torch.ops.aten.bmm.default(transpose_int_160, _unsafe_view_default_104);  transpose_int_160 = None
        transpose_int_161 = torch.ops.aten.transpose.int(_unsafe_view_default_3, 1, 2);  _unsafe_view_default_3 = None
        bmm_default_69 = torch.ops.aten.bmm.default(_unsafe_view_default_104, transpose_int_161);  _unsafe_view_default_104 = transpose_int_161 = None
        view_default_524 = torch.ops.aten.view.default(bmm_default_68, [16, 12, 128, 64]);  bmm_default_68 = None
        view_default_525 = torch.ops.aten.view.default(bmm_default_69, [16, 12, 128, 128]);  bmm_default_69 = None
        _softmax_backward_data_default_11 = torch.ops.aten._softmax_backward_data.default(view_default_525, _softmax_default, -1, torch.float32);  view_default_525 = _softmax_default = None
        where_scalar_self_23 = torch.ops.aten.where.ScalarSelf(eq_scalar, 0.0, _softmax_backward_data_default_11);  eq_scalar = _softmax_backward_data_default_11 = None
        div_tensor_139 = torch.ops.aten.div.Tensor(where_scalar_self_23, 8.0);  where_scalar_self_23 = None
        view_default_526 = torch.ops.aten.view.default(div_tensor_139, [192, 128, 128]);  div_tensor_139 = None
        transpose_int_162 = torch.ops.aten.transpose.int(_unsafe_view_default, 1, 2);  _unsafe_view_default = None
        bmm_default_70 = torch.ops.aten.bmm.default(transpose_int_162, view_default_526);  transpose_int_162 = None
        transpose_int_163 = torch.ops.aten.transpose.int(_unsafe_view_default_1, 1, 2);  _unsafe_view_default_1 = None
        bmm_default_71 = torch.ops.aten.bmm.default(view_default_526, transpose_int_163);  view_default_526 = transpose_int_163 = None
        view_default_527 = torch.ops.aten.view.default(bmm_default_70, [16, 12, 64, 128]);  bmm_default_70 = None
        view_default_528 = torch.ops.aten.view.default(bmm_default_71, [16, 12, 128, 64]);  bmm_default_71 = None
        transpose_int_164 = torch.ops.aten.transpose.int(view_default_527, -2, -1);  view_default_527 = None
        transpose_int_165 = torch.ops.aten.transpose.int(view_default_524, 1, 2);  view_default_524 = None
        clone_default_93 = torch.ops.aten.clone.default(transpose_int_165, memory_format = torch.contiguous_format);  transpose_int_165 = None
        _unsafe_view_default_105 = torch.ops.aten._unsafe_view.default(clone_default_93, [16, 128, 768]);  clone_default_93 = None
        view_default_529 = torch.ops.aten.view.default(_unsafe_view_default_105, [2048, 768]);  _unsafe_view_default_105 = None
        t_default_348 = torch.ops.aten.t.default(t_default_2);  t_default_2 = None
        mm_default_138 = torch.ops.aten.mm.default(view_default_529, t_default_348);  t_default_348 = None
        t_default_349 = torch.ops.aten.t.default(view_default_529)
        mm_default_139 = torch.ops.aten.mm.default(t_default_349, view_default_6);  t_default_349 = view_default_6 = None
        t_default_350 = torch.ops.aten.t.default(mm_default_139);  mm_default_139 = None
        sum_dim_int_list_161 = torch.ops.aten.sum.dim_IntList(view_default_529, [0], True);  view_default_529 = None
        view_default_530 = torch.ops.aten.view.default(sum_dim_int_list_161, [768]);  sum_dim_int_list_161 = None
        t_default_351 = torch.ops.aten.t.default(t_default_350);  t_default_350 = None
        view_default_531 = torch.ops.aten.view.default(mm_default_138, [16, 128, 768]);  mm_default_138 = None
        transpose_int_166 = torch.ops.aten.transpose.int(transpose_int_164, 1, 2);  transpose_int_164 = None
        view_default_532 = torch.ops.aten.view.default(transpose_int_166, [16, 128, 768]);  transpose_int_166 = None
        clone_default_94 = torch.ops.aten.clone.default(view_default_532, memory_format = torch.contiguous_format);  view_default_532 = None
        _unsafe_view_default_106 = torch.ops.aten._unsafe_view.default(clone_default_94, [2048, 768]);  clone_default_94 = None
        t_default_352 = torch.ops.aten.t.default(t_default_1);  t_default_1 = None
        mm_default_140 = torch.ops.aten.mm.default(_unsafe_view_default_106, t_default_352);  t_default_352 = None
        t_default_353 = torch.ops.aten.t.default(_unsafe_view_default_106)
        mm_default_141 = torch.ops.aten.mm.default(t_default_353, view_default_3);  t_default_353 = view_default_3 = None
        t_default_354 = torch.ops.aten.t.default(mm_default_141);  mm_default_141 = None
        sum_dim_int_list_162 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_106, [0], True);  _unsafe_view_default_106 = None
        view_default_533 = torch.ops.aten.view.default(sum_dim_int_list_162, [768]);  sum_dim_int_list_162 = None
        t_default_355 = torch.ops.aten.t.default(t_default_354);  t_default_354 = None
        view_default_534 = torch.ops.aten.view.default(mm_default_140, [16, 128, 768]);  mm_default_140 = None
        add_tensor_189 = torch.ops.aten.add.Tensor(view_default_531, view_default_534);  view_default_531 = view_default_534 = None
        transpose_int_167 = torch.ops.aten.transpose.int(view_default_528, 1, 2);  view_default_528 = None
        clone_default_95 = torch.ops.aten.clone.default(transpose_int_167, memory_format = torch.contiguous_format);  transpose_int_167 = None
        _unsafe_view_default_107 = torch.ops.aten._unsafe_view.default(clone_default_95, [16, 128, 768]);  clone_default_95 = None
        view_default_535 = torch.ops.aten.view.default(_unsafe_view_default_107, [2048, 768]);  _unsafe_view_default_107 = None
        t_default_356 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default_142 = torch.ops.aten.mm.default(view_default_535, t_default_356);  t_default_356 = None
        t_default_357 = torch.ops.aten.t.default(view_default_535)
        mm_default_143 = torch.ops.aten.mm.default(t_default_357, view_default);  t_default_357 = view_default = None
        t_default_358 = torch.ops.aten.t.default(mm_default_143);  mm_default_143 = None
        sum_dim_int_list_163 = torch.ops.aten.sum.dim_IntList(view_default_535, [0], True);  view_default_535 = None
        view_default_536 = torch.ops.aten.view.default(sum_dim_int_list_163, [768]);  sum_dim_int_list_163 = None
        t_default_359 = torch.ops.aten.t.default(t_default_358);  t_default_358 = None
        view_default_537 = torch.ops.aten.view.default(mm_default_142, [16, 128, 768]);  mm_default_142 = None
        add_tensor_190 = torch.ops.aten.add.Tensor(add_tensor_189, view_default_537);  add_tensor_189 = view_default_537 = None
        sum_dim_int_list_164 = torch.ops.aten.sum.dim_IntList(add_tensor_190, [0, 1], True)
        view_default_538 = torch.ops.aten.view.default(sum_dim_int_list_164, [768]);  sum_dim_int_list_164 = None
        neg_default_46 = torch.ops.aten.neg.default(add_tensor_190)
        div_tensor_140 = torch.ops.aten.div.Tensor(mul_tensor, add_tensor_2);  mul_tensor = None
        div_tensor_141 = torch.ops.aten.div.Tensor(div_tensor_140, add_tensor_2);  div_tensor_140 = None
        mul_tensor_200 = torch.ops.aten.mul.Tensor(neg_default_46, div_tensor_141);  neg_default_46 = div_tensor_141 = None
        div_tensor_142 = torch.ops.aten.div.Tensor(add_tensor_190, add_tensor_2);  add_tensor_190 = add_tensor_2 = None
        sum_dim_int_list_165 = torch.ops.aten.sum.dim_IntList(mul_tensor_200, [2], True);  mul_tensor_200 = None
        mul_tensor_201 = torch.ops.aten.mul.Tensor(div_tensor_142, primals_8);  primals_8 = None
        mul_tensor_202 = torch.ops.aten.mul.Tensor(div_tensor_142, sub_tensor);  div_tensor_142 = sub_tensor = None
        sum_dim_int_list_166 = torch.ops.aten.sum.dim_IntList(mul_tensor_202, [0, 1], True);  mul_tensor_202 = None
        view_default_539 = torch.ops.aten.view.default(sum_dim_int_list_166, [768]);  sum_dim_int_list_166 = None
        neg_default_47 = torch.ops.aten.neg.default(mul_tensor_201)
        sum_dim_int_list_167 = torch.ops.aten.sum.dim_IntList(neg_default_47, [2], True);  neg_default_47 = None
        add_tensor_191 = torch.ops.aten.add.Tensor(add_tensor_188, mul_tensor_201);  add_tensor_188 = mul_tensor_201 = None
        mul_scalar_46 = torch.ops.aten.mul.Scalar(std_correction, 2)
        div_tensor_143 = torch.ops.aten.div.Tensor(sum_dim_int_list_165, mul_scalar_46);  sum_dim_int_list_165 = mul_scalar_46 = None
        eq_scalar_35 = torch.ops.aten.eq.Scalar(std_correction, 0);  std_correction = None
        masked_fill__scalar_23 = torch.ops.aten.masked_fill_.Scalar(div_tensor_143, eq_scalar_35, 0);  div_tensor_143 = eq_scalar_35 = None
        mul_scalar_47 = torch.ops.aten.mul.Scalar(masked_fill__scalar_23, 0.002607561929595828);  masked_fill__scalar_23 = None
        mean_dim_47 = torch.ops.aten.mean.dim(add_tensor_1, [-1], True)
        sub_tensor_47 = torch.ops.aten.sub.Tensor(add_tensor_1, mean_dim_47);  add_tensor_1 = mean_dim_47 = None
        mul_tensor_203 = torch.ops.aten.mul.Tensor(mul_scalar_47, sub_tensor_47);  mul_scalar_47 = sub_tensor_47 = None
        add_tensor_192 = torch.ops.aten.add.Tensor(add_tensor_191, mul_tensor_203);  add_tensor_191 = mul_tensor_203 = None
        expand_default_71 = torch.ops.aten.expand.default(sum_dim_int_list_167, [16, 128, 768]);  sum_dim_int_list_167 = None
        div_scalar_23 = torch.ops.aten.div.Scalar(expand_default_71, 768);  expand_default_71 = None
        add_tensor_193 = torch.ops.aten.add.Tensor(add_tensor_192, div_scalar_23);  add_tensor_192 = div_scalar_23 = None
        embedding_dense_backward_default = torch.ops.aten.embedding_dense_backward.default(add_tensor_193, primals_197, 3, 0, False);  primals_197 = None
        embedding_dense_backward_default_1 = torch.ops.aten.embedding_dense_backward.default(add_tensor_193, primals_196, 20005, 0, False);  add_tensor_193 = primals_196 = None
        return [None, embedding_dense_backward_default, embedding_dense_backward_default_1, view_default_516, t_default_343, view_default_513, t_default_339, view_default_539, view_default_538, view_default_536, t_default_359, view_default_533, t_default_355, view_default_530, t_default_351, view_default_521, t_default_347, view_default_519, view_default_518, view_default_236, t_default_103, view_default_233, t_default_99, view_default_259, view_default_258, view_default_256, t_default_119, view_default_253, t_default_115, view_default_250, t_default_111, view_default_241, t_default_107, view_default_239, view_default_238, view_default_208, t_default_79, view_default_205, t_default_75, view_default_231, view_default_230, view_default_228, t_default_95, view_default_225, t_default_91, view_default_222, t_default_87, view_default_213, t_default_83, view_default_211, view_default_210, view_default_488, t_default_319, view_default_485, t_default_315, view_default_511, view_default_510, view_default_508, t_default_335, view_default_505, t_default_331, view_default_502, t_default_327, view_default_493, t_default_323, view_default_491, view_default_490, view_default_460, t_default_295, view_default_457, t_default_291, view_default_483, view_default_482, view_default_480, t_default_311, view_default_477, t_default_307, view_default_474, t_default_303, view_default_465, t_default_299, view_default_463, view_default_462, view_default_432, t_default_271, view_default_429, t_default_267, view_default_455, view_default_454, view_default_452, t_default_287, view_default_449, t_default_283, view_default_446, t_default_279, view_default_437, t_default_275, view_default_435, view_default_434, view_default_404, t_default_247, view_default_401, t_default_243, view_default_427, view_default_426, view_default_424, t_default_263, view_default_421, t_default_259, view_default_418, t_default_255, view_default_409, t_default_251, view_default_407, view_default_406, view_default_376, t_default_223, view_default_373, t_default_219, view_default_399, view_default_398, view_default_396, t_default_239, view_default_393, t_default_235, view_default_390, t_default_231, view_default_381, t_default_227, view_default_379, view_default_378, view_default_348, t_default_199, view_default_345, t_default_195, view_default_371, view_default_370, view_default_368, t_default_215, view_default_365, t_default_211, view_default_362, t_default_207, view_default_353, t_default_203, view_default_351, view_default_350, view_default_320, t_default_175, view_default_317, t_default_171, view_default_343, view_default_342, view_default_340, t_default_191, view_default_337, t_default_187, view_default_334, t_default_183, view_default_325, t_default_179, view_default_323, view_default_322, view_default_292, t_default_151, view_default_289, t_default_147, view_default_315, view_default_314, view_default_312, t_default_167, view_default_309, t_default_163, view_default_306, t_default_159, view_default_297, t_default_155, view_default_295, view_default_294, view_default_264, t_default_127, view_default_261, t_default_123, view_default_287, view_default_286, view_default_284, t_default_143, view_default_281, t_default_139, view_default_278, t_default_135, view_default_269, t_default_131, view_default_267, view_default_266, None, None]
        
