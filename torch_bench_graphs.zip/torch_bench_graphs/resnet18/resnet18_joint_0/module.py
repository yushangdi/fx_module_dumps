
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/resnet18/resnet18_joint_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, tangents_1):
        convolution_default = torch.ops.aten.convolution.default(primals_123, primals_6, None, [2, 2], [3, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_5, primals_1, primals_3, primals_4, False, 0.1, 1e-05);  primals_1 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        new_zeros_default = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_2 = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu__default, [3, 3], [2, 2], [1, 1])
        getitem_3 = max_pool2d_with_indices_default[0]
        getitem_4 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_1 = torch.ops.aten.convolution.default(getitem_3, primals_19, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_13, primals_9, primals_11, primals_12, False, 0.1, 1e-05);  primals_9 = None
        getitem_5 = native_batch_norm_default_1[0]
        getitem_6 = native_batch_norm_default_1[1]
        getitem_7 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_5 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_1 = torch.ops.aten.relu_.default(getitem_5);  getitem_5 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_20, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_18, primals_14, primals_16, primals_17, False, 0.1, 1e-05);  primals_14 = None
        getitem_8 = native_batch_norm_default_2[0]
        getitem_9 = native_batch_norm_default_2[1]
        getitem_10 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_8 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor = torch.ops.aten.add_.Tensor(getitem_8, getitem_3);  getitem_8 = None
        relu__default_2 = torch.ops.aten.relu_.default(add__tensor);  add__tensor = None
        convolution_default_3 = torch.ops.aten.convolution.default(relu__default_2, primals_31, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_25, primals_21, primals_23, primals_24, False, 0.1, 1e-05);  primals_21 = None
        getitem_11 = native_batch_norm_default_3[0]
        getitem_12 = native_batch_norm_default_3[1]
        getitem_13 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        new_zeros_default_9 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_10 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_11 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_3 = torch.ops.aten.relu_.default(getitem_11);  getitem_11 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu__default_3, primals_32, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_30, primals_26, primals_28, primals_29, False, 0.1, 1e-05);  primals_26 = None
        getitem_14 = native_batch_norm_default_4[0]
        getitem_15 = native_batch_norm_default_4[1]
        getitem_16 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        new_zeros_default_12 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_13 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_14 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_1 = torch.ops.aten.add_.Tensor(getitem_14, relu__default_2);  getitem_14 = None
        relu__default_4 = torch.ops.aten.relu_.default(add__tensor_1);  add__tensor_1 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_4, primals_43, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_37, primals_33, primals_35, primals_36, False, 0.1, 1e-05);  primals_33 = None
        getitem_17 = native_batch_norm_default_5[0]
        getitem_18 = native_batch_norm_default_5[1]
        getitem_19 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        new_zeros_default_15 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_16 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_17 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_5 = torch.ops.aten.relu_.default(getitem_17);  getitem_17 = None
        convolution_default_6 = torch.ops.aten.convolution.default(relu__default_5, primals_44, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_42, primals_38, primals_40, primals_41, False, 0.1, 1e-05);  primals_38 = None
        getitem_20 = native_batch_norm_default_6[0]
        getitem_21 = native_batch_norm_default_6[1]
        getitem_22 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        new_zeros_default_18 = torch.ops.aten.new_zeros.default(convolution_default_6, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_19 = torch.ops.aten.new_zeros.default(convolution_default_6, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_20 = torch.ops.aten.new_zeros.default(convolution_default_6, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_4, primals_45, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_50, primals_46, primals_48, primals_49, False, 0.1, 1e-05);  primals_46 = None
        getitem_23 = native_batch_norm_default_7[0]
        getitem_24 = native_batch_norm_default_7[1]
        getitem_25 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        new_zeros_default_21 = torch.ops.aten.new_zeros.default(convolution_default_7, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_22 = torch.ops.aten.new_zeros.default(convolution_default_7, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_23 = torch.ops.aten.new_zeros.default(convolution_default_7, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_2 = torch.ops.aten.add_.Tensor(getitem_20, getitem_23);  getitem_20 = getitem_23 = None
        relu__default_6 = torch.ops.aten.relu_.default(add__tensor_2);  add__tensor_2 = None
        convolution_default_8 = torch.ops.aten.convolution.default(relu__default_6, primals_61, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_55, primals_51, primals_53, primals_54, False, 0.1, 1e-05);  primals_51 = None
        getitem_26 = native_batch_norm_default_8[0]
        getitem_27 = native_batch_norm_default_8[1]
        getitem_28 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        new_zeros_default_24 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_25 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_26 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_7 = torch.ops.aten.relu_.default(getitem_26);  getitem_26 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_7, primals_62, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_60, primals_56, primals_58, primals_59, False, 0.1, 1e-05);  primals_56 = None
        getitem_29 = native_batch_norm_default_9[0]
        getitem_30 = native_batch_norm_default_9[1]
        getitem_31 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        new_zeros_default_27 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_28 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_29 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_3 = torch.ops.aten.add_.Tensor(getitem_29, relu__default_6);  getitem_29 = None
        relu__default_8 = torch.ops.aten.relu_.default(add__tensor_3);  add__tensor_3 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default_8, primals_73, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_67, primals_63, primals_65, primals_66, False, 0.1, 1e-05);  primals_63 = None
        getitem_32 = native_batch_norm_default_10[0]
        getitem_33 = native_batch_norm_default_10[1]
        getitem_34 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        new_zeros_default_30 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_31 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_32 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_9 = torch.ops.aten.relu_.default(getitem_32);  getitem_32 = None
        convolution_default_11 = torch.ops.aten.convolution.default(relu__default_9, primals_74, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_72, primals_68, primals_70, primals_71, False, 0.1, 1e-05);  primals_68 = None
        getitem_35 = native_batch_norm_default_11[0]
        getitem_36 = native_batch_norm_default_11[1]
        getitem_37 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        new_zeros_default_33 = torch.ops.aten.new_zeros.default(convolution_default_11, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_34 = torch.ops.aten.new_zeros.default(convolution_default_11, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_35 = torch.ops.aten.new_zeros.default(convolution_default_11, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_12 = torch.ops.aten.convolution.default(relu__default_8, primals_75, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_80, primals_76, primals_78, primals_79, False, 0.1, 1e-05);  primals_76 = None
        getitem_38 = native_batch_norm_default_12[0]
        getitem_39 = native_batch_norm_default_12[1]
        getitem_40 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        new_zeros_default_36 = torch.ops.aten.new_zeros.default(convolution_default_12, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_37 = torch.ops.aten.new_zeros.default(convolution_default_12, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_38 = torch.ops.aten.new_zeros.default(convolution_default_12, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_4 = torch.ops.aten.add_.Tensor(getitem_35, getitem_38);  getitem_35 = getitem_38 = None
        relu__default_10 = torch.ops.aten.relu_.default(add__tensor_4);  add__tensor_4 = None
        convolution_default_13 = torch.ops.aten.convolution.default(relu__default_10, primals_91, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_85, primals_81, primals_83, primals_84, False, 0.1, 1e-05);  primals_81 = None
        getitem_41 = native_batch_norm_default_13[0]
        getitem_42 = native_batch_norm_default_13[1]
        getitem_43 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        new_zeros_default_39 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_40 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_41 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_11 = torch.ops.aten.relu_.default(getitem_41);  getitem_41 = None
        convolution_default_14 = torch.ops.aten.convolution.default(relu__default_11, primals_92, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_90, primals_86, primals_88, primals_89, False, 0.1, 1e-05);  primals_86 = None
        getitem_44 = native_batch_norm_default_14[0]
        getitem_45 = native_batch_norm_default_14[1]
        getitem_46 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        new_zeros_default_42 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_43 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_44 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_5 = torch.ops.aten.add_.Tensor(getitem_44, relu__default_10);  getitem_44 = None
        relu__default_12 = torch.ops.aten.relu_.default(add__tensor_5);  add__tensor_5 = None
        convolution_default_15 = torch.ops.aten.convolution.default(relu__default_12, primals_103, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_97, primals_93, primals_95, primals_96, False, 0.1, 1e-05);  primals_93 = None
        getitem_47 = native_batch_norm_default_15[0]
        getitem_48 = native_batch_norm_default_15[1]
        getitem_49 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        new_zeros_default_45 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_46 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_47 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_13 = torch.ops.aten.relu_.default(getitem_47);  getitem_47 = None
        convolution_default_16 = torch.ops.aten.convolution.default(relu__default_13, primals_104, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_102, primals_98, primals_100, primals_101, False, 0.1, 1e-05);  primals_98 = None
        getitem_50 = native_batch_norm_default_16[0]
        getitem_51 = native_batch_norm_default_16[1]
        getitem_52 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        new_zeros_default_48 = torch.ops.aten.new_zeros.default(convolution_default_16, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_49 = torch.ops.aten.new_zeros.default(convolution_default_16, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_50 = torch.ops.aten.new_zeros.default(convolution_default_16, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_17 = torch.ops.aten.convolution.default(relu__default_12, primals_105, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_110, primals_106, primals_108, primals_109, False, 0.1, 1e-05);  primals_106 = None
        getitem_53 = native_batch_norm_default_17[0]
        getitem_54 = native_batch_norm_default_17[1]
        getitem_55 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        new_zeros_default_51 = torch.ops.aten.new_zeros.default(convolution_default_17, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_52 = torch.ops.aten.new_zeros.default(convolution_default_17, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_53 = torch.ops.aten.new_zeros.default(convolution_default_17, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_6 = torch.ops.aten.add_.Tensor(getitem_50, getitem_53);  getitem_50 = getitem_53 = None
        relu__default_14 = torch.ops.aten.relu_.default(add__tensor_6);  add__tensor_6 = None
        convolution_default_18 = torch.ops.aten.convolution.default(relu__default_14, primals_121, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_115, primals_111, primals_113, primals_114, False, 0.1, 1e-05);  primals_111 = None
        getitem_56 = native_batch_norm_default_18[0]
        getitem_57 = native_batch_norm_default_18[1]
        getitem_58 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        new_zeros_default_54 = torch.ops.aten.new_zeros.default(convolution_default_18, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_55 = torch.ops.aten.new_zeros.default(convolution_default_18, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_56 = torch.ops.aten.new_zeros.default(convolution_default_18, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_15 = torch.ops.aten.relu_.default(getitem_56);  getitem_56 = None
        convolution_default_19 = torch.ops.aten.convolution.default(relu__default_15, primals_122, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_120, primals_116, primals_118, primals_119, False, 0.1, 1e-05);  primals_116 = None
        getitem_59 = native_batch_norm_default_19[0]
        getitem_60 = native_batch_norm_default_19[1]
        getitem_61 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        new_zeros_default_57 = torch.ops.aten.new_zeros.default(convolution_default_19, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_58 = torch.ops.aten.new_zeros.default(convolution_default_19, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_59 = torch.ops.aten.new_zeros.default(convolution_default_19, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_7 = torch.ops.aten.add_.Tensor(getitem_59, relu__default_14);  getitem_59 = None
        relu__default_16 = torch.ops.aten.relu_.default(add__tensor_7);  add__tensor_7 = None
        mean_dim = torch.ops.aten.mean.dim(relu__default_16, [-1, -2], True)
        view_default = torch.ops.aten.view.default(mean_dim, [16, 512]);  mean_dim = None
        t_default = torch.ops.aten.t.default(primals_8);  primals_8 = None
        addmm_default = torch.ops.aten.addmm.default(primals_7, view_default, t_default);  primals_7 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(addmm_default, tangents_1)
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, view_default);  t_default_2 = view_default = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_1 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        view_default_2 = torch.ops.aten.view.default(mm_default, [16, 512, 1, 1]);  mm_default = None
        expand_default = torch.ops.aten.expand.default(view_default_2, [16, 512, 7, 7]);  view_default_2 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 49);  expand_default = None
        to_dtype = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default_16, torch.float32);  relu__default_16 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default_60 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_60, to_dtype);  le_scalar = new_zeros_default_60 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_2, convolution_default_19, primals_120, primals_118, primals_119, new_zeros_default_57, new_zeros_default_58, False, 1e-05, [True, True, True]);  convolution_default_19 = primals_120 = primals_118 = primals_119 = new_zeros_default_57 = new_zeros_default_58 = None
        getitem_62 = native_batch_norm_backward_default[0]
        getitem_63 = native_batch_norm_backward_default[1]
        getitem_64 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(getitem_62, relu__default_15, primals_122, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_62 = primals_122 = None
        getitem_65 = convolution_backward_default[0]
        getitem_66 = convolution_backward_default[1]
        getitem_67 = convolution_backward_default[2];  convolution_backward_default = None
        to_dtype_3 = torch.ops.aten.to.dtype(getitem_65, torch.float32);  getitem_65 = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu__default_15, torch.float32);  relu__default_15 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_61 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_61, to_dtype_3);  le_scalar_1 = new_zeros_default_61 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_5, convolution_default_18, primals_115, primals_113, primals_114, new_zeros_default_54, new_zeros_default_55, False, 1e-05, [True, True, True]);  to_dtype_5 = convolution_default_18 = primals_115 = primals_113 = primals_114 = new_zeros_default_54 = new_zeros_default_55 = None
        getitem_68 = native_batch_norm_backward_default_1[0]
        getitem_69 = native_batch_norm_backward_default_1[1]
        getitem_70 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_68, relu__default_14, primals_121, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_68 = primals_121 = None
        getitem_71 = convolution_backward_default_1[0]
        getitem_72 = convolution_backward_default_1[1]
        getitem_73 = convolution_backward_default_1[2];  convolution_backward_default_1 = None
        add_tensor = torch.ops.aten.add.Tensor(to_dtype_2, getitem_71);  to_dtype_2 = getitem_71 = None
        to_dtype_6 = torch.ops.aten.to.dtype(add_tensor, torch.float32);  add_tensor = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_62 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_62, to_dtype_6);  le_scalar_2 = new_zeros_default_62 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_8, convolution_default_17, primals_110, primals_108, primals_109, new_zeros_default_51, new_zeros_default_52, False, 1e-05, [True, True, True]);  convolution_default_17 = primals_110 = primals_108 = primals_109 = new_zeros_default_51 = new_zeros_default_52 = None
        getitem_74 = native_batch_norm_backward_default_2[0]
        getitem_75 = native_batch_norm_backward_default_2[1]
        getitem_76 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_74, relu__default_12, primals_105, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_74 = primals_105 = None
        getitem_77 = convolution_backward_default_2[0]
        getitem_78 = convolution_backward_default_2[1]
        getitem_79 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_8, convolution_default_16, primals_102, primals_100, primals_101, new_zeros_default_48, new_zeros_default_49, False, 1e-05, [True, True, True]);  to_dtype_8 = convolution_default_16 = primals_102 = primals_100 = primals_101 = new_zeros_default_48 = new_zeros_default_49 = None
        getitem_80 = native_batch_norm_backward_default_3[0]
        getitem_81 = native_batch_norm_backward_default_3[1]
        getitem_82 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_80, relu__default_13, primals_104, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_80 = primals_104 = None
        getitem_83 = convolution_backward_default_3[0]
        getitem_84 = convolution_backward_default_3[1]
        getitem_85 = convolution_backward_default_3[2];  convolution_backward_default_3 = None
        to_dtype_9 = torch.ops.aten.to.dtype(getitem_83, torch.float32);  getitem_83 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_63 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_63, to_dtype_9);  le_scalar_3 = new_zeros_default_63 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_15, primals_97, primals_95, primals_96, new_zeros_default_45, new_zeros_default_46, False, 1e-05, [True, True, True]);  to_dtype_11 = convolution_default_15 = primals_97 = primals_95 = primals_96 = new_zeros_default_45 = new_zeros_default_46 = None
        getitem_86 = native_batch_norm_backward_default_4[0]
        getitem_87 = native_batch_norm_backward_default_4[1]
        getitem_88 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_86, relu__default_12, primals_103, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_86 = primals_103 = None
        getitem_89 = convolution_backward_default_4[0]
        getitem_90 = convolution_backward_default_4[1]
        getitem_91 = convolution_backward_default_4[2];  convolution_backward_default_4 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(getitem_77, getitem_89);  getitem_77 = getitem_89 = None
        to_dtype_12 = torch.ops.aten.to.dtype(add_tensor_1, torch.float32);  add_tensor_1 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_64 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_64, to_dtype_12);  le_scalar_4 = new_zeros_default_64 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_14, primals_90, primals_88, primals_89, new_zeros_default_42, new_zeros_default_43, False, 1e-05, [True, True, True]);  convolution_default_14 = primals_90 = primals_88 = primals_89 = new_zeros_default_42 = new_zeros_default_43 = None
        getitem_92 = native_batch_norm_backward_default_5[0]
        getitem_93 = native_batch_norm_backward_default_5[1]
        getitem_94 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_92, relu__default_11, primals_92, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_92 = primals_92 = None
        getitem_95 = convolution_backward_default_5[0]
        getitem_96 = convolution_backward_default_5[1]
        getitem_97 = convolution_backward_default_5[2];  convolution_backward_default_5 = None
        to_dtype_15 = torch.ops.aten.to.dtype(getitem_95, torch.float32);  getitem_95 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_65 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_65, to_dtype_15);  le_scalar_5 = new_zeros_default_65 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_17, convolution_default_13, primals_85, primals_83, primals_84, new_zeros_default_39, new_zeros_default_40, False, 1e-05, [True, True, True]);  to_dtype_17 = convolution_default_13 = primals_85 = primals_83 = primals_84 = new_zeros_default_39 = new_zeros_default_40 = None
        getitem_98 = native_batch_norm_backward_default_6[0]
        getitem_99 = native_batch_norm_backward_default_6[1]
        getitem_100 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(getitem_98, relu__default_10, primals_91, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_98 = primals_91 = None
        getitem_101 = convolution_backward_default_6[0]
        getitem_102 = convolution_backward_default_6[1]
        getitem_103 = convolution_backward_default_6[2];  convolution_backward_default_6 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(to_dtype_14, getitem_101);  to_dtype_14 = getitem_101 = None
        to_dtype_18 = torch.ops.aten.to.dtype(add_tensor_2, torch.float32);  add_tensor_2 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_66 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_66, to_dtype_18);  le_scalar_6 = new_zeros_default_66 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_20, convolution_default_12, primals_80, primals_78, primals_79, new_zeros_default_36, new_zeros_default_37, False, 1e-05, [True, True, True]);  convolution_default_12 = primals_80 = primals_78 = primals_79 = new_zeros_default_36 = new_zeros_default_37 = None
        getitem_104 = native_batch_norm_backward_default_7[0]
        getitem_105 = native_batch_norm_backward_default_7[1]
        getitem_106 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(getitem_104, relu__default_8, primals_75, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_104 = primals_75 = None
        getitem_107 = convolution_backward_default_7[0]
        getitem_108 = convolution_backward_default_7[1]
        getitem_109 = convolution_backward_default_7[2];  convolution_backward_default_7 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_20, convolution_default_11, primals_72, primals_70, primals_71, new_zeros_default_33, new_zeros_default_34, False, 1e-05, [True, True, True]);  to_dtype_20 = convolution_default_11 = primals_72 = primals_70 = primals_71 = new_zeros_default_33 = new_zeros_default_34 = None
        getitem_110 = native_batch_norm_backward_default_8[0]
        getitem_111 = native_batch_norm_backward_default_8[1]
        getitem_112 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(getitem_110, relu__default_9, primals_74, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_110 = primals_74 = None
        getitem_113 = convolution_backward_default_8[0]
        getitem_114 = convolution_backward_default_8[1]
        getitem_115 = convolution_backward_default_8[2];  convolution_backward_default_8 = None
        to_dtype_21 = torch.ops.aten.to.dtype(getitem_113, torch.float32);  getitem_113 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_67 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_67, to_dtype_21);  le_scalar_7 = new_zeros_default_67 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_23, convolution_default_10, primals_67, primals_65, primals_66, new_zeros_default_30, new_zeros_default_31, False, 1e-05, [True, True, True]);  to_dtype_23 = convolution_default_10 = primals_67 = primals_65 = primals_66 = new_zeros_default_30 = new_zeros_default_31 = None
        getitem_116 = native_batch_norm_backward_default_9[0]
        getitem_117 = native_batch_norm_backward_default_9[1]
        getitem_118 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_116, relu__default_8, primals_73, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_116 = primals_73 = None
        getitem_119 = convolution_backward_default_9[0]
        getitem_120 = convolution_backward_default_9[1]
        getitem_121 = convolution_backward_default_9[2];  convolution_backward_default_9 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(getitem_107, getitem_119);  getitem_107 = getitem_119 = None
        to_dtype_24 = torch.ops.aten.to.dtype(add_tensor_3, torch.float32);  add_tensor_3 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_68 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_68, to_dtype_24);  le_scalar_8 = new_zeros_default_68 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_9, primals_60, primals_58, primals_59, new_zeros_default_27, new_zeros_default_28, False, 1e-05, [True, True, True]);  convolution_default_9 = primals_60 = primals_58 = primals_59 = new_zeros_default_27 = new_zeros_default_28 = None
        getitem_122 = native_batch_norm_backward_default_10[0]
        getitem_123 = native_batch_norm_backward_default_10[1]
        getitem_124 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_122, relu__default_7, primals_62, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_122 = primals_62 = None
        getitem_125 = convolution_backward_default_10[0]
        getitem_126 = convolution_backward_default_10[1]
        getitem_127 = convolution_backward_default_10[2];  convolution_backward_default_10 = None
        to_dtype_27 = torch.ops.aten.to.dtype(getitem_125, torch.float32);  getitem_125 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_69 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_69, to_dtype_27);  le_scalar_9 = new_zeros_default_69 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_29, convolution_default_8, primals_55, primals_53, primals_54, new_zeros_default_24, new_zeros_default_25, False, 1e-05, [True, True, True]);  to_dtype_29 = convolution_default_8 = primals_55 = primals_53 = primals_54 = new_zeros_default_24 = new_zeros_default_25 = None
        getitem_128 = native_batch_norm_backward_default_11[0]
        getitem_129 = native_batch_norm_backward_default_11[1]
        getitem_130 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_128, relu__default_6, primals_61, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_128 = primals_61 = None
        getitem_131 = convolution_backward_default_11[0]
        getitem_132 = convolution_backward_default_11[1]
        getitem_133 = convolution_backward_default_11[2];  convolution_backward_default_11 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(to_dtype_26, getitem_131);  to_dtype_26 = getitem_131 = None
        to_dtype_30 = torch.ops.aten.to.dtype(add_tensor_4, torch.float32);  add_tensor_4 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_70 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_70, to_dtype_30);  le_scalar_10 = new_zeros_default_70 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default_7, primals_50, primals_48, primals_49, new_zeros_default_21, new_zeros_default_22, False, 1e-05, [True, True, True]);  convolution_default_7 = primals_50 = primals_48 = primals_49 = new_zeros_default_21 = new_zeros_default_22 = None
        getitem_134 = native_batch_norm_backward_default_12[0]
        getitem_135 = native_batch_norm_backward_default_12[1]
        getitem_136 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(getitem_134, relu__default_4, primals_45, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_134 = primals_45 = None
        getitem_137 = convolution_backward_default_12[0]
        getitem_138 = convolution_backward_default_12[1]
        getitem_139 = convolution_backward_default_12[2];  convolution_backward_default_12 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default_6, primals_42, primals_40, primals_41, new_zeros_default_18, new_zeros_default_19, False, 1e-05, [True, True, True]);  to_dtype_32 = convolution_default_6 = primals_42 = primals_40 = primals_41 = new_zeros_default_18 = new_zeros_default_19 = None
        getitem_140 = native_batch_norm_backward_default_13[0]
        getitem_141 = native_batch_norm_backward_default_13[1]
        getitem_142 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_140, relu__default_5, primals_44, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_140 = primals_44 = None
        getitem_143 = convolution_backward_default_13[0]
        getitem_144 = convolution_backward_default_13[1]
        getitem_145 = convolution_backward_default_13[2];  convolution_backward_default_13 = None
        to_dtype_33 = torch.ops.aten.to.dtype(getitem_143, torch.float32);  getitem_143 = None
        to_dtype_34 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        new_zeros_default_71 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_71, to_dtype_33);  le_scalar_11 = new_zeros_default_71 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_35, convolution_default_5, primals_37, primals_35, primals_36, new_zeros_default_15, new_zeros_default_16, False, 1e-05, [True, True, True]);  to_dtype_35 = convolution_default_5 = primals_37 = primals_35 = primals_36 = new_zeros_default_15 = new_zeros_default_16 = None
        getitem_146 = native_batch_norm_backward_default_14[0]
        getitem_147 = native_batch_norm_backward_default_14[1]
        getitem_148 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_146, relu__default_4, primals_43, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_146 = primals_43 = None
        getitem_149 = convolution_backward_default_14[0]
        getitem_150 = convolution_backward_default_14[1]
        getitem_151 = convolution_backward_default_14[2];  convolution_backward_default_14 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(getitem_137, getitem_149);  getitem_137 = getitem_149 = None
        to_dtype_36 = torch.ops.aten.to.dtype(add_tensor_5, torch.float32);  add_tensor_5 = None
        to_dtype_37 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        new_zeros_default_72 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_72, to_dtype_36);  le_scalar_12 = new_zeros_default_72 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_38, convolution_default_4, primals_30, primals_28, primals_29, new_zeros_default_12, new_zeros_default_13, False, 1e-05, [True, True, True]);  convolution_default_4 = primals_30 = primals_28 = primals_29 = new_zeros_default_12 = new_zeros_default_13 = None
        getitem_152 = native_batch_norm_backward_default_15[0]
        getitem_153 = native_batch_norm_backward_default_15[1]
        getitem_154 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_152, relu__default_3, primals_32, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_152 = primals_32 = None
        getitem_155 = convolution_backward_default_15[0]
        getitem_156 = convolution_backward_default_15[1]
        getitem_157 = convolution_backward_default_15[2];  convolution_backward_default_15 = None
        to_dtype_39 = torch.ops.aten.to.dtype(getitem_155, torch.float32);  getitem_155 = None
        to_dtype_40 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        new_zeros_default_73 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_73, to_dtype_39);  le_scalar_13 = new_zeros_default_73 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_41, convolution_default_3, primals_25, primals_23, primals_24, new_zeros_default_9, new_zeros_default_10, False, 1e-05, [True, True, True]);  to_dtype_41 = convolution_default_3 = primals_25 = primals_23 = primals_24 = new_zeros_default_9 = new_zeros_default_10 = None
        getitem_158 = native_batch_norm_backward_default_16[0]
        getitem_159 = native_batch_norm_backward_default_16[1]
        getitem_160 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(getitem_158, relu__default_2, primals_31, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_158 = primals_31 = None
        getitem_161 = convolution_backward_default_16[0]
        getitem_162 = convolution_backward_default_16[1]
        getitem_163 = convolution_backward_default_16[2];  convolution_backward_default_16 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(to_dtype_38, getitem_161);  to_dtype_38 = getitem_161 = None
        to_dtype_42 = torch.ops.aten.to.dtype(add_tensor_6, torch.float32);  add_tensor_6 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_74 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_74, to_dtype_42);  le_scalar_14 = new_zeros_default_74 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_44, convolution_default_2, primals_18, primals_16, primals_17, new_zeros_default_6, new_zeros_default_7, False, 1e-05, [True, True, True]);  convolution_default_2 = primals_18 = primals_16 = primals_17 = new_zeros_default_6 = new_zeros_default_7 = None
        getitem_164 = native_batch_norm_backward_default_17[0]
        getitem_165 = native_batch_norm_backward_default_17[1]
        getitem_166 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(getitem_164, relu__default_1, primals_20, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_164 = primals_20 = None
        getitem_167 = convolution_backward_default_17[0]
        getitem_168 = convolution_backward_default_17[1]
        getitem_169 = convolution_backward_default_17[2];  convolution_backward_default_17 = None
        to_dtype_45 = torch.ops.aten.to.dtype(getitem_167, torch.float32);  getitem_167 = None
        to_dtype_46 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_46, 0);  to_dtype_46 = None
        new_zeros_default_75 = torch.ops.aten.new_zeros.default(to_dtype_45, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_75, to_dtype_45);  le_scalar_15 = new_zeros_default_75 = to_dtype_45 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_47, convolution_default_1, primals_13, primals_11, primals_12, new_zeros_default_3, new_zeros_default_4, False, 1e-05, [True, True, True]);  to_dtype_47 = convolution_default_1 = primals_13 = primals_11 = primals_12 = new_zeros_default_3 = new_zeros_default_4 = None
        getitem_170 = native_batch_norm_backward_default_18[0]
        getitem_171 = native_batch_norm_backward_default_18[1]
        getitem_172 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(getitem_170, getitem_3, primals_19, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_170 = getitem_3 = primals_19 = None
        getitem_173 = convolution_backward_default_18[0]
        getitem_174 = convolution_backward_default_18[1]
        getitem_175 = convolution_backward_default_18[2];  convolution_backward_default_18 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(to_dtype_44, getitem_173);  to_dtype_44 = getitem_173 = None
        max_pool2d_with_indices_backward_default = torch.ops.aten.max_pool2d_with_indices_backward.default(add_tensor_7, relu__default, [3, 3], [2, 2], [1, 1], [1, 1], False, getitem_4);  add_tensor_7 = getitem_4 = None
        to_dtype_48 = torch.ops.aten.to.dtype(max_pool2d_with_indices_backward_default, torch.float32);  max_pool2d_with_indices_backward_default = None
        to_dtype_49 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_49, 0);  to_dtype_49 = None
        new_zeros_default_76 = torch.ops.aten.new_zeros.default(to_dtype_48, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_76, to_dtype_48);  le_scalar_16 = new_zeros_default_76 = to_dtype_48 = None
        to_dtype_50 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_50, convolution_default, primals_5, primals_3, primals_4, new_zeros_default, new_zeros_default_1, False, 1e-05, [True, True, True]);  to_dtype_50 = convolution_default = primals_5 = primals_3 = primals_4 = new_zeros_default = new_zeros_default_1 = None
        getitem_176 = native_batch_norm_backward_default_19[0]
        getitem_177 = native_batch_norm_backward_default_19[1]
        getitem_178 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_176, primals_123, primals_6, [0], [2, 2], [3, 3], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_176 = primals_123 = primals_6 = None
        getitem_179 = convolution_backward_default_19[0]
        getitem_180 = convolution_backward_default_19[1]
        getitem_181 = convolution_backward_default_19[2];  convolution_backward_default_19 = None
        return [addmm_default, getitem_178, None, None, None, getitem_177, getitem_180, view_default_1, t_default_4, getitem_172, None, None, None, getitem_171, getitem_166, None, None, None, getitem_165, getitem_174, getitem_168, getitem_160, None, None, None, getitem_159, getitem_154, None, None, None, getitem_153, getitem_162, getitem_156, getitem_148, None, None, None, getitem_147, getitem_142, None, None, None, getitem_141, getitem_150, getitem_144, getitem_138, getitem_136, None, None, None, getitem_135, getitem_130, None, None, None, getitem_129, getitem_124, None, None, None, getitem_123, getitem_132, getitem_126, getitem_118, None, None, None, getitem_117, getitem_112, None, None, None, getitem_111, getitem_120, getitem_114, getitem_108, getitem_106, None, None, None, getitem_105, getitem_100, None, None, None, getitem_99, getitem_94, None, None, None, getitem_93, getitem_102, getitem_96, getitem_88, None, None, None, getitem_87, getitem_82, None, None, None, getitem_81, getitem_90, getitem_84, getitem_78, getitem_76, None, None, None, getitem_75, getitem_70, None, None, None, getitem_69, getitem_64, None, None, None, getitem_63, getitem_72, getitem_66, None]
        
