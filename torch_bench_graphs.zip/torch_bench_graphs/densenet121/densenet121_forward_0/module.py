
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/densenet121/densenet121_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339, primals_340, primals_341, primals_342, primals_343, primals_344, primals_345, primals_346, primals_347, primals_348, primals_349, primals_350, primals_351, primals_352, primals_353, primals_354, primals_355, primals_356, primals_357, primals_358, primals_359, primals_360, primals_361, primals_362, primals_363, primals_364, primals_365, primals_366, primals_367, primals_368, primals_369, primals_370, primals_371, primals_372, primals_373, primals_374, primals_375, primals_376, primals_377, primals_378, primals_379, primals_380, primals_381, primals_382, primals_383, primals_384, primals_385, primals_386, primals_387, primals_388, primals_389, primals_390, primals_391, primals_392, primals_393, primals_394, primals_395, primals_396, primals_397, primals_398, primals_399, primals_400, primals_401, primals_402, primals_403, primals_404, primals_405, primals_406, primals_407, primals_408, primals_409, primals_410, primals_411, primals_412, primals_413, primals_414, primals_415, primals_416, primals_417, primals_418, primals_419, primals_420, primals_421, primals_422, primals_423, primals_424, primals_425, primals_426, primals_427, primals_428, primals_429, primals_430, primals_431, primals_432, primals_433, primals_434, primals_435, primals_436, primals_437, primals_438, primals_439, primals_440, primals_441, primals_442, primals_443, primals_444, primals_445, primals_446, primals_447, primals_448, primals_449, primals_450, primals_451, primals_452, primals_453, primals_454, primals_455, primals_456, primals_457, primals_458, primals_459, primals_460, primals_461, primals_462, primals_463, primals_464, primals_465, primals_466, primals_467, primals_468, primals_469, primals_470, primals_471, primals_472, primals_473, primals_474, primals_475, primals_476, primals_477, primals_478, primals_479, primals_480, primals_481, primals_482, primals_483, primals_484, primals_485, primals_486, primals_487, primals_488, primals_489, primals_490, primals_491, primals_492, primals_493, primals_494, primals_495, primals_496, primals_497, primals_498, primals_499, primals_500, primals_501, primals_502, primals_503, primals_504, primals_505, primals_506, primals_507, primals_508, primals_509, primals_510, primals_511, primals_512, primals_513, primals_514, primals_515, primals_516, primals_517, primals_518, primals_519, primals_520, primals_521, primals_522, primals_523, primals_524, primals_525, primals_526, primals_527, primals_528, primals_529, primals_530, primals_531, primals_532, primals_533, primals_534, primals_535, primals_536, primals_537, primals_538, primals_539, primals_540, primals_541, primals_542, primals_543, primals_544, primals_545, primals_546, primals_547, primals_548, primals_549, primals_550, primals_551, primals_552, primals_553, primals_554, primals_555, primals_556, primals_557, primals_558, primals_559, primals_560, primals_561, primals_562, primals_563, primals_564, primals_565, primals_566, primals_567, primals_568, primals_569, primals_570, primals_571, primals_572, primals_573, primals_574, primals_575, primals_576, primals_577, primals_578, primals_579, primals_580, primals_581, primals_582, primals_583, primals_584, primals_585, primals_586, primals_587, primals_588, primals_589, primals_590, primals_591, primals_592, primals_593, primals_594, primals_595, primals_596, primals_597, primals_598, primals_599, primals_600, primals_601, primals_602, primals_603, primals_604, primals_605, primals_606, primals_607, primals_608, primals_609, primals_610, primals_611, primals_612, primals_613, primals_614, primals_615, primals_616, primals_617, primals_618, primals_619, primals_620, primals_621, primals_622, primals_623, primals_624, primals_625, primals_626, primals_627, primals_628, primals_629, primals_630, primals_631, primals_632, primals_633, primals_634, primals_635, primals_636, primals_637, primals_638, primals_639, primals_640, primals_641, primals_642, primals_643, primals_644, primals_645, primals_646, primals_647, primals_648, primals_649, primals_650, primals_651, primals_652, primals_653, primals_654, primals_655, primals_656, primals_657, primals_658, primals_659, primals_660, primals_661, primals_662, primals_663, primals_664, primals_665, primals_666, primals_667, primals_668, primals_669, primals_670, primals_671, primals_672, primals_673, primals_674, primals_675, primals_676, primals_677, primals_678, primals_679, primals_680, primals_681, primals_682, primals_683, primals_684, primals_685, primals_686, primals_687, primals_688, primals_689, primals_690, primals_691, primals_692, primals_693, primals_694, primals_695, primals_696, primals_697, primals_698, primals_699, primals_700, primals_701, primals_702, primals_703, primals_704, primals_705, primals_706, primals_707, primals_708, primals_709, primals_710, primals_711, primals_712, primals_713, primals_714, primals_715, primals_716, primals_717, primals_718, primals_719, primals_720, primals_721, primals_722, primals_723, primals_724, primals_725, primals_726, primals_727, primals_728):
        convolution_default = torch.ops.aten.convolution.default(primals_728, primals_3, None, [2, 2], [3, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_8, primals_4, primals_6, primals_7, False, 0.1, 1e-05);  primals_4 = None
        getitem = native_batch_norm_default[0];  native_batch_norm_default = None
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu__default, [3, 3], [2, 2], [1, 1])
        getitem_3 = max_pool2d_with_indices_default[0]
        getitem_4 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        cat_default = torch.ops.aten.cat.default([getitem_3], 1)
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(cat_default, primals_212, primals_208, primals_210, primals_211, False, 0.1, 1e-05);  primals_208 = None
        getitem_5 = native_batch_norm_default_1[0];  native_batch_norm_default_1 = None
        relu__default_1 = torch.ops.aten.relu_.default(getitem_5);  getitem_5 = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default_1, primals_206, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_217, primals_213, primals_215, primals_216, False, 0.1, 1e-05);  primals_213 = None
        getitem_8 = native_batch_norm_default_2[0];  native_batch_norm_default_2 = None
        relu__default_2 = torch.ops.aten.relu_.default(getitem_8);  getitem_8 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_2, primals_207, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_1 = torch.ops.aten.cat.default([getitem_3, convolution_default_2], 1)
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(cat_default_1, primals_224, primals_220, primals_222, primals_223, False, 0.1, 1e-05);  primals_220 = None
        getitem_11 = native_batch_norm_default_3[0];  native_batch_norm_default_3 = None
        relu__default_3 = torch.ops.aten.relu_.default(getitem_11);  getitem_11 = None
        convolution_default_3 = torch.ops.aten.convolution.default(relu__default_3, primals_218, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_229, primals_225, primals_227, primals_228, False, 0.1, 1e-05);  primals_225 = None
        getitem_14 = native_batch_norm_default_4[0];  native_batch_norm_default_4 = None
        relu__default_4 = torch.ops.aten.relu_.default(getitem_14);  getitem_14 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu__default_4, primals_219, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_2 = torch.ops.aten.cat.default([getitem_3, convolution_default_2, convolution_default_4], 1)
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(cat_default_2, primals_236, primals_232, primals_234, primals_235, False, 0.1, 1e-05);  primals_232 = None
        getitem_17 = native_batch_norm_default_5[0];  native_batch_norm_default_5 = None
        relu__default_5 = torch.ops.aten.relu_.default(getitem_17);  getitem_17 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_5, primals_230, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_241, primals_237, primals_239, primals_240, False, 0.1, 1e-05);  primals_237 = None
        getitem_20 = native_batch_norm_default_6[0];  native_batch_norm_default_6 = None
        relu__default_6 = torch.ops.aten.relu_.default(getitem_20);  getitem_20 = None
        convolution_default_6 = torch.ops.aten.convolution.default(relu__default_6, primals_231, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_3 = torch.ops.aten.cat.default([getitem_3, convolution_default_2, convolution_default_4, convolution_default_6], 1)
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(cat_default_3, primals_248, primals_244, primals_246, primals_247, False, 0.1, 1e-05);  primals_244 = None
        getitem_23 = native_batch_norm_default_7[0];  native_batch_norm_default_7 = None
        relu__default_7 = torch.ops.aten.relu_.default(getitem_23);  getitem_23 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_7, primals_242, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_253, primals_249, primals_251, primals_252, False, 0.1, 1e-05);  primals_249 = None
        getitem_26 = native_batch_norm_default_8[0];  native_batch_norm_default_8 = None
        relu__default_8 = torch.ops.aten.relu_.default(getitem_26);  getitem_26 = None
        convolution_default_8 = torch.ops.aten.convolution.default(relu__default_8, primals_243, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_4 = torch.ops.aten.cat.default([getitem_3, convolution_default_2, convolution_default_4, convolution_default_6, convolution_default_8], 1)
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(cat_default_4, primals_260, primals_256, primals_258, primals_259, False, 0.1, 1e-05);  primals_256 = None
        getitem_29 = native_batch_norm_default_9[0];  native_batch_norm_default_9 = None
        relu__default_9 = torch.ops.aten.relu_.default(getitem_29);  getitem_29 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_9, primals_254, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_265, primals_261, primals_263, primals_264, False, 0.1, 1e-05);  primals_261 = None
        getitem_32 = native_batch_norm_default_10[0];  native_batch_norm_default_10 = None
        relu__default_10 = torch.ops.aten.relu_.default(getitem_32);  getitem_32 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default_10, primals_255, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_5 = torch.ops.aten.cat.default([getitem_3, convolution_default_2, convolution_default_4, convolution_default_6, convolution_default_8, convolution_default_10], 1)
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(cat_default_5, primals_272, primals_268, primals_270, primals_271, False, 0.1, 1e-05);  primals_268 = None
        getitem_35 = native_batch_norm_default_11[0];  native_batch_norm_default_11 = None
        relu__default_11 = torch.ops.aten.relu_.default(getitem_35);  getitem_35 = None
        convolution_default_11 = torch.ops.aten.convolution.default(relu__default_11, primals_266, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_277, primals_273, primals_275, primals_276, False, 0.1, 1e-05);  primals_273 = None
        getitem_38 = native_batch_norm_default_12[0];  native_batch_norm_default_12 = None
        relu__default_12 = torch.ops.aten.relu_.default(getitem_38);  getitem_38 = None
        convolution_default_12 = torch.ops.aten.convolution.default(relu__default_12, primals_267, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_6 = torch.ops.aten.cat.default([getitem_3, convolution_default_2, convolution_default_4, convolution_default_6, convolution_default_8, convolution_default_10, convolution_default_12], 1);  getitem_3 = convolution_default_2 = convolution_default_4 = convolution_default_6 = convolution_default_8 = convolution_default_10 = convolution_default_12 = None
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(cat_default_6, primals_282, primals_278, primals_280, primals_281, False, 0.1, 1e-05);  primals_278 = None
        getitem_41 = native_batch_norm_default_13[0];  native_batch_norm_default_13 = None
        relu__default_13 = torch.ops.aten.relu_.default(getitem_41);  getitem_41 = None
        convolution_default_13 = torch.ops.aten.convolution.default(relu__default_13, primals_283, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        avg_pool2d_default = torch.ops.aten.avg_pool2d.default(convolution_default_13, [2, 2], [2, 2])
        cat_default_7 = torch.ops.aten.cat.default([avg_pool2d_default], 1)
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(cat_default_7, primals_326, primals_322, primals_324, primals_325, False, 0.1, 1e-05);  primals_322 = None
        getitem_44 = native_batch_norm_default_14[0];  native_batch_norm_default_14 = None
        relu__default_14 = torch.ops.aten.relu_.default(getitem_44);  getitem_44 = None
        convolution_default_14 = torch.ops.aten.convolution.default(relu__default_14, primals_320, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_331, primals_327, primals_329, primals_330, False, 0.1, 1e-05);  primals_327 = None
        getitem_47 = native_batch_norm_default_15[0];  native_batch_norm_default_15 = None
        relu__default_15 = torch.ops.aten.relu_.default(getitem_47);  getitem_47 = None
        convolution_default_15 = torch.ops.aten.convolution.default(relu__default_15, primals_321, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_8 = torch.ops.aten.cat.default([avg_pool2d_default, convolution_default_15], 1)
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(cat_default_8, primals_338, primals_334, primals_336, primals_337, False, 0.1, 1e-05);  primals_334 = None
        getitem_50 = native_batch_norm_default_16[0];  native_batch_norm_default_16 = None
        relu__default_16 = torch.ops.aten.relu_.default(getitem_50);  getitem_50 = None
        convolution_default_16 = torch.ops.aten.convolution.default(relu__default_16, primals_332, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_343, primals_339, primals_341, primals_342, False, 0.1, 1e-05);  primals_339 = None
        getitem_53 = native_batch_norm_default_17[0];  native_batch_norm_default_17 = None
        relu__default_17 = torch.ops.aten.relu_.default(getitem_53);  getitem_53 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu__default_17, primals_333, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_9 = torch.ops.aten.cat.default([avg_pool2d_default, convolution_default_15, convolution_default_17], 1)
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(cat_default_9, primals_350, primals_346, primals_348, primals_349, False, 0.1, 1e-05);  primals_346 = None
        getitem_56 = native_batch_norm_default_18[0];  native_batch_norm_default_18 = None
        relu__default_18 = torch.ops.aten.relu_.default(getitem_56);  getitem_56 = None
        convolution_default_18 = torch.ops.aten.convolution.default(relu__default_18, primals_344, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_355, primals_351, primals_353, primals_354, False, 0.1, 1e-05);  primals_351 = None
        getitem_59 = native_batch_norm_default_19[0];  native_batch_norm_default_19 = None
        relu__default_19 = torch.ops.aten.relu_.default(getitem_59);  getitem_59 = None
        convolution_default_19 = torch.ops.aten.convolution.default(relu__default_19, primals_345, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_10 = torch.ops.aten.cat.default([avg_pool2d_default, convolution_default_15, convolution_default_17, convolution_default_19], 1)
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(cat_default_10, primals_362, primals_358, primals_360, primals_361, False, 0.1, 1e-05);  primals_358 = None
        getitem_62 = native_batch_norm_default_20[0];  native_batch_norm_default_20 = None
        relu__default_20 = torch.ops.aten.relu_.default(getitem_62);  getitem_62 = None
        convolution_default_20 = torch.ops.aten.convolution.default(relu__default_20, primals_356, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_367, primals_363, primals_365, primals_366, False, 0.1, 1e-05);  primals_363 = None
        getitem_65 = native_batch_norm_default_21[0];  native_batch_norm_default_21 = None
        relu__default_21 = torch.ops.aten.relu_.default(getitem_65);  getitem_65 = None
        convolution_default_21 = torch.ops.aten.convolution.default(relu__default_21, primals_357, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_11 = torch.ops.aten.cat.default([avg_pool2d_default, convolution_default_15, convolution_default_17, convolution_default_19, convolution_default_21], 1)
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(cat_default_11, primals_374, primals_370, primals_372, primals_373, False, 0.1, 1e-05);  primals_370 = None
        getitem_68 = native_batch_norm_default_22[0];  native_batch_norm_default_22 = None
        relu__default_22 = torch.ops.aten.relu_.default(getitem_68);  getitem_68 = None
        convolution_default_22 = torch.ops.aten.convolution.default(relu__default_22, primals_368, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_379, primals_375, primals_377, primals_378, False, 0.1, 1e-05);  primals_375 = None
        getitem_71 = native_batch_norm_default_23[0];  native_batch_norm_default_23 = None
        relu__default_23 = torch.ops.aten.relu_.default(getitem_71);  getitem_71 = None
        convolution_default_23 = torch.ops.aten.convolution.default(relu__default_23, primals_369, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_12 = torch.ops.aten.cat.default([avg_pool2d_default, convolution_default_15, convolution_default_17, convolution_default_19, convolution_default_21, convolution_default_23], 1)
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(cat_default_12, primals_386, primals_382, primals_384, primals_385, False, 0.1, 1e-05);  primals_382 = None
        getitem_74 = native_batch_norm_default_24[0];  native_batch_norm_default_24 = None
        relu__default_24 = torch.ops.aten.relu_.default(getitem_74);  getitem_74 = None
        convolution_default_24 = torch.ops.aten.convolution.default(relu__default_24, primals_380, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_391, primals_387, primals_389, primals_390, False, 0.1, 1e-05);  primals_387 = None
        getitem_77 = native_batch_norm_default_25[0];  native_batch_norm_default_25 = None
        relu__default_25 = torch.ops.aten.relu_.default(getitem_77);  getitem_77 = None
        convolution_default_25 = torch.ops.aten.convolution.default(relu__default_25, primals_381, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_13 = torch.ops.aten.cat.default([avg_pool2d_default, convolution_default_15, convolution_default_17, convolution_default_19, convolution_default_21, convolution_default_23, convolution_default_25], 1)
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(cat_default_13, primals_398, primals_394, primals_396, primals_397, False, 0.1, 1e-05);  primals_394 = None
        getitem_80 = native_batch_norm_default_26[0];  native_batch_norm_default_26 = None
        relu__default_26 = torch.ops.aten.relu_.default(getitem_80);  getitem_80 = None
        convolution_default_26 = torch.ops.aten.convolution.default(relu__default_26, primals_392, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_403, primals_399, primals_401, primals_402, False, 0.1, 1e-05);  primals_399 = None
        getitem_83 = native_batch_norm_default_27[0];  native_batch_norm_default_27 = None
        relu__default_27 = torch.ops.aten.relu_.default(getitem_83);  getitem_83 = None
        convolution_default_27 = torch.ops.aten.convolution.default(relu__default_27, primals_393, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_14 = torch.ops.aten.cat.default([avg_pool2d_default, convolution_default_15, convolution_default_17, convolution_default_19, convolution_default_21, convolution_default_23, convolution_default_25, convolution_default_27], 1)
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(cat_default_14, primals_410, primals_406, primals_408, primals_409, False, 0.1, 1e-05);  primals_406 = None
        getitem_86 = native_batch_norm_default_28[0];  native_batch_norm_default_28 = None
        relu__default_28 = torch.ops.aten.relu_.default(getitem_86);  getitem_86 = None
        convolution_default_28 = torch.ops.aten.convolution.default(relu__default_28, primals_404, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_415, primals_411, primals_413, primals_414, False, 0.1, 1e-05);  primals_411 = None
        getitem_89 = native_batch_norm_default_29[0];  native_batch_norm_default_29 = None
        relu__default_29 = torch.ops.aten.relu_.default(getitem_89);  getitem_89 = None
        convolution_default_29 = torch.ops.aten.convolution.default(relu__default_29, primals_405, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_15 = torch.ops.aten.cat.default([avg_pool2d_default, convolution_default_15, convolution_default_17, convolution_default_19, convolution_default_21, convolution_default_23, convolution_default_25, convolution_default_27, convolution_default_29], 1)
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(cat_default_15, primals_422, primals_418, primals_420, primals_421, False, 0.1, 1e-05);  primals_418 = None
        getitem_92 = native_batch_norm_default_30[0];  native_batch_norm_default_30 = None
        relu__default_30 = torch.ops.aten.relu_.default(getitem_92);  getitem_92 = None
        convolution_default_30 = torch.ops.aten.convolution.default(relu__default_30, primals_416, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_427, primals_423, primals_425, primals_426, False, 0.1, 1e-05);  primals_423 = None
        getitem_95 = native_batch_norm_default_31[0];  native_batch_norm_default_31 = None
        relu__default_31 = torch.ops.aten.relu_.default(getitem_95);  getitem_95 = None
        convolution_default_31 = torch.ops.aten.convolution.default(relu__default_31, primals_417, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_16 = torch.ops.aten.cat.default([avg_pool2d_default, convolution_default_15, convolution_default_17, convolution_default_19, convolution_default_21, convolution_default_23, convolution_default_25, convolution_default_27, convolution_default_29, convolution_default_31], 1)
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(cat_default_16, primals_290, primals_286, primals_288, primals_289, False, 0.1, 1e-05);  primals_286 = None
        getitem_98 = native_batch_norm_default_32[0];  native_batch_norm_default_32 = None
        relu__default_32 = torch.ops.aten.relu_.default(getitem_98);  getitem_98 = None
        convolution_default_32 = torch.ops.aten.convolution.default(relu__default_32, primals_284, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_295, primals_291, primals_293, primals_294, False, 0.1, 1e-05);  primals_291 = None
        getitem_101 = native_batch_norm_default_33[0];  native_batch_norm_default_33 = None
        relu__default_33 = torch.ops.aten.relu_.default(getitem_101);  getitem_101 = None
        convolution_default_33 = torch.ops.aten.convolution.default(relu__default_33, primals_285, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_17 = torch.ops.aten.cat.default([avg_pool2d_default, convolution_default_15, convolution_default_17, convolution_default_19, convolution_default_21, convolution_default_23, convolution_default_25, convolution_default_27, convolution_default_29, convolution_default_31, convolution_default_33], 1)
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(cat_default_17, primals_302, primals_298, primals_300, primals_301, False, 0.1, 1e-05);  primals_298 = None
        getitem_104 = native_batch_norm_default_34[0];  native_batch_norm_default_34 = None
        relu__default_34 = torch.ops.aten.relu_.default(getitem_104);  getitem_104 = None
        convolution_default_34 = torch.ops.aten.convolution.default(relu__default_34, primals_296, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_307, primals_303, primals_305, primals_306, False, 0.1, 1e-05);  primals_303 = None
        getitem_107 = native_batch_norm_default_35[0];  native_batch_norm_default_35 = None
        relu__default_35 = torch.ops.aten.relu_.default(getitem_107);  getitem_107 = None
        convolution_default_35 = torch.ops.aten.convolution.default(relu__default_35, primals_297, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_18 = torch.ops.aten.cat.default([avg_pool2d_default, convolution_default_15, convolution_default_17, convolution_default_19, convolution_default_21, convolution_default_23, convolution_default_25, convolution_default_27, convolution_default_29, convolution_default_31, convolution_default_33, convolution_default_35], 1)
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(cat_default_18, primals_314, primals_310, primals_312, primals_313, False, 0.1, 1e-05);  primals_310 = None
        getitem_110 = native_batch_norm_default_36[0];  native_batch_norm_default_36 = None
        relu__default_36 = torch.ops.aten.relu_.default(getitem_110);  getitem_110 = None
        convolution_default_36 = torch.ops.aten.convolution.default(relu__default_36, primals_308, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_319, primals_315, primals_317, primals_318, False, 0.1, 1e-05);  primals_315 = None
        getitem_113 = native_batch_norm_default_37[0];  native_batch_norm_default_37 = None
        relu__default_37 = torch.ops.aten.relu_.default(getitem_113);  getitem_113 = None
        convolution_default_37 = torch.ops.aten.convolution.default(relu__default_37, primals_309, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_19 = torch.ops.aten.cat.default([avg_pool2d_default, convolution_default_15, convolution_default_17, convolution_default_19, convolution_default_21, convolution_default_23, convolution_default_25, convolution_default_27, convolution_default_29, convolution_default_31, convolution_default_33, convolution_default_35, convolution_default_37], 1);  avg_pool2d_default = convolution_default_15 = convolution_default_17 = convolution_default_19 = convolution_default_21 = convolution_default_23 = convolution_default_25 = convolution_default_27 = convolution_default_29 = convolution_default_31 = convolution_default_33 = convolution_default_35 = convolution_default_37 = None
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(cat_default_19, primals_432, primals_428, primals_430, primals_431, False, 0.1, 1e-05);  primals_428 = None
        getitem_116 = native_batch_norm_default_38[0];  native_batch_norm_default_38 = None
        relu__default_38 = torch.ops.aten.relu_.default(getitem_116);  getitem_116 = None
        convolution_default_38 = torch.ops.aten.convolution.default(relu__default_38, primals_433, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        avg_pool2d_default_1 = torch.ops.aten.avg_pool2d.default(convolution_default_38, [2, 2], [2, 2])
        cat_default_20 = torch.ops.aten.cat.default([avg_pool2d_default_1], 1)
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(cat_default_20, primals_560, primals_556, primals_558, primals_559, False, 0.1, 1e-05);  primals_556 = None
        getitem_119 = native_batch_norm_default_39[0];  native_batch_norm_default_39 = None
        relu__default_39 = torch.ops.aten.relu_.default(getitem_119);  getitem_119 = None
        convolution_default_39 = torch.ops.aten.convolution.default(relu__default_39, primals_554, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_39, primals_565, primals_561, primals_563, primals_564, False, 0.1, 1e-05);  primals_561 = None
        getitem_122 = native_batch_norm_default_40[0];  native_batch_norm_default_40 = None
        relu__default_40 = torch.ops.aten.relu_.default(getitem_122);  getitem_122 = None
        convolution_default_40 = torch.ops.aten.convolution.default(relu__default_40, primals_555, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_21 = torch.ops.aten.cat.default([avg_pool2d_default_1, convolution_default_40], 1)
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(cat_default_21, primals_632, primals_628, primals_630, primals_631, False, 0.1, 1e-05);  primals_628 = None
        getitem_125 = native_batch_norm_default_41[0];  native_batch_norm_default_41 = None
        relu__default_41 = torch.ops.aten.relu_.default(getitem_125);  getitem_125 = None
        convolution_default_41 = torch.ops.aten.convolution.default(relu__default_41, primals_626, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_41, primals_637, primals_633, primals_635, primals_636, False, 0.1, 1e-05);  primals_633 = None
        getitem_128 = native_batch_norm_default_42[0];  native_batch_norm_default_42 = None
        relu__default_42 = torch.ops.aten.relu_.default(getitem_128);  getitem_128 = None
        convolution_default_42 = torch.ops.aten.convolution.default(relu__default_42, primals_627, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_22 = torch.ops.aten.cat.default([avg_pool2d_default_1, convolution_default_40, convolution_default_42], 1)
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(cat_default_22, primals_644, primals_640, primals_642, primals_643, False, 0.1, 1e-05);  primals_640 = None
        getitem_131 = native_batch_norm_default_43[0];  native_batch_norm_default_43 = None
        relu__default_43 = torch.ops.aten.relu_.default(getitem_131);  getitem_131 = None
        convolution_default_43 = torch.ops.aten.convolution.default(relu__default_43, primals_638, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_43, primals_649, primals_645, primals_647, primals_648, False, 0.1, 1e-05);  primals_645 = None
        getitem_134 = native_batch_norm_default_44[0];  native_batch_norm_default_44 = None
        relu__default_44 = torch.ops.aten.relu_.default(getitem_134);  getitem_134 = None
        convolution_default_44 = torch.ops.aten.convolution.default(relu__default_44, primals_639, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_23 = torch.ops.aten.cat.default([avg_pool2d_default_1, convolution_default_40, convolution_default_42, convolution_default_44], 1)
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(cat_default_23, primals_656, primals_652, primals_654, primals_655, False, 0.1, 1e-05);  primals_652 = None
        getitem_137 = native_batch_norm_default_45[0];  native_batch_norm_default_45 = None
        relu__default_45 = torch.ops.aten.relu_.default(getitem_137);  getitem_137 = None
        convolution_default_45 = torch.ops.aten.convolution.default(relu__default_45, primals_650, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(convolution_default_45, primals_661, primals_657, primals_659, primals_660, False, 0.1, 1e-05);  primals_657 = None
        getitem_140 = native_batch_norm_default_46[0];  native_batch_norm_default_46 = None
        relu__default_46 = torch.ops.aten.relu_.default(getitem_140);  getitem_140 = None
        convolution_default_46 = torch.ops.aten.convolution.default(relu__default_46, primals_651, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_24 = torch.ops.aten.cat.default([avg_pool2d_default_1, convolution_default_40, convolution_default_42, convolution_default_44, convolution_default_46], 1)
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(cat_default_24, primals_668, primals_664, primals_666, primals_667, False, 0.1, 1e-05);  primals_664 = None
        getitem_143 = native_batch_norm_default_47[0];  native_batch_norm_default_47 = None
        relu__default_47 = torch.ops.aten.relu_.default(getitem_143);  getitem_143 = None
        convolution_default_47 = torch.ops.aten.convolution.default(relu__default_47, primals_662, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_47, primals_673, primals_669, primals_671, primals_672, False, 0.1, 1e-05);  primals_669 = None
        getitem_146 = native_batch_norm_default_48[0];  native_batch_norm_default_48 = None
        relu__default_48 = torch.ops.aten.relu_.default(getitem_146);  getitem_146 = None
        convolution_default_48 = torch.ops.aten.convolution.default(relu__default_48, primals_663, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_25 = torch.ops.aten.cat.default([avg_pool2d_default_1, convolution_default_40, convolution_default_42, convolution_default_44, convolution_default_46, convolution_default_48], 1)
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(cat_default_25, primals_680, primals_676, primals_678, primals_679, False, 0.1, 1e-05);  primals_676 = None
        getitem_149 = native_batch_norm_default_49[0];  native_batch_norm_default_49 = None
        relu__default_49 = torch.ops.aten.relu_.default(getitem_149);  getitem_149 = None
        convolution_default_49 = torch.ops.aten.convolution.default(relu__default_49, primals_674, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(convolution_default_49, primals_685, primals_681, primals_683, primals_684, False, 0.1, 1e-05);  primals_681 = None
        getitem_152 = native_batch_norm_default_50[0];  native_batch_norm_default_50 = None
        relu__default_50 = torch.ops.aten.relu_.default(getitem_152);  getitem_152 = None
        convolution_default_50 = torch.ops.aten.convolution.default(relu__default_50, primals_675, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_26 = torch.ops.aten.cat.default([avg_pool2d_default_1, convolution_default_40, convolution_default_42, convolution_default_44, convolution_default_46, convolution_default_48, convolution_default_50], 1)
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(cat_default_26, primals_692, primals_688, primals_690, primals_691, False, 0.1, 1e-05);  primals_688 = None
        getitem_155 = native_batch_norm_default_51[0];  native_batch_norm_default_51 = None
        relu__default_51 = torch.ops.aten.relu_.default(getitem_155);  getitem_155 = None
        convolution_default_51 = torch.ops.aten.convolution.default(relu__default_51, primals_686, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(convolution_default_51, primals_697, primals_693, primals_695, primals_696, False, 0.1, 1e-05);  primals_693 = None
        getitem_158 = native_batch_norm_default_52[0];  native_batch_norm_default_52 = None
        relu__default_52 = torch.ops.aten.relu_.default(getitem_158);  getitem_158 = None
        convolution_default_52 = torch.ops.aten.convolution.default(relu__default_52, primals_687, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_27 = torch.ops.aten.cat.default([avg_pool2d_default_1, convolution_default_40, convolution_default_42, convolution_default_44, convolution_default_46, convolution_default_48, convolution_default_50, convolution_default_52], 1)
        native_batch_norm_default_53 = torch.ops.aten.native_batch_norm.default(cat_default_27, primals_704, primals_700, primals_702, primals_703, False, 0.1, 1e-05);  primals_700 = None
        getitem_161 = native_batch_norm_default_53[0];  native_batch_norm_default_53 = None
        relu__default_53 = torch.ops.aten.relu_.default(getitem_161);  getitem_161 = None
        convolution_default_53 = torch.ops.aten.convolution.default(relu__default_53, primals_698, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_54 = torch.ops.aten.native_batch_norm.default(convolution_default_53, primals_709, primals_705, primals_707, primals_708, False, 0.1, 1e-05);  primals_705 = None
        getitem_164 = native_batch_norm_default_54[0];  native_batch_norm_default_54 = None
        relu__default_54 = torch.ops.aten.relu_.default(getitem_164);  getitem_164 = None
        convolution_default_54 = torch.ops.aten.convolution.default(relu__default_54, primals_699, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_28 = torch.ops.aten.cat.default([avg_pool2d_default_1, convolution_default_40, convolution_default_42, convolution_default_44, convolution_default_46, convolution_default_48, convolution_default_50, convolution_default_52, convolution_default_54], 1)
        native_batch_norm_default_55 = torch.ops.aten.native_batch_norm.default(cat_default_28, primals_716, primals_712, primals_714, primals_715, False, 0.1, 1e-05);  primals_712 = None
        getitem_167 = native_batch_norm_default_55[0];  native_batch_norm_default_55 = None
        relu__default_55 = torch.ops.aten.relu_.default(getitem_167);  getitem_167 = None
        convolution_default_55 = torch.ops.aten.convolution.default(relu__default_55, primals_710, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_56 = torch.ops.aten.native_batch_norm.default(convolution_default_55, primals_721, primals_717, primals_719, primals_720, False, 0.1, 1e-05);  primals_717 = None
        getitem_170 = native_batch_norm_default_56[0];  native_batch_norm_default_56 = None
        relu__default_56 = torch.ops.aten.relu_.default(getitem_170);  getitem_170 = None
        convolution_default_56 = torch.ops.aten.convolution.default(relu__default_56, primals_711, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_29 = torch.ops.aten.cat.default([avg_pool2d_default_1, convolution_default_40, convolution_default_42, convolution_default_44, convolution_default_46, convolution_default_48, convolution_default_50, convolution_default_52, convolution_default_54, convolution_default_56], 1)
        native_batch_norm_default_57 = torch.ops.aten.native_batch_norm.default(cat_default_29, primals_440, primals_436, primals_438, primals_439, False, 0.1, 1e-05);  primals_436 = None
        getitem_173 = native_batch_norm_default_57[0];  native_batch_norm_default_57 = None
        relu__default_57 = torch.ops.aten.relu_.default(getitem_173);  getitem_173 = None
        convolution_default_57 = torch.ops.aten.convolution.default(relu__default_57, primals_434, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_58 = torch.ops.aten.native_batch_norm.default(convolution_default_57, primals_445, primals_441, primals_443, primals_444, False, 0.1, 1e-05);  primals_441 = None
        getitem_176 = native_batch_norm_default_58[0];  native_batch_norm_default_58 = None
        relu__default_58 = torch.ops.aten.relu_.default(getitem_176);  getitem_176 = None
        convolution_default_58 = torch.ops.aten.convolution.default(relu__default_58, primals_435, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_30 = torch.ops.aten.cat.default([avg_pool2d_default_1, convolution_default_40, convolution_default_42, convolution_default_44, convolution_default_46, convolution_default_48, convolution_default_50, convolution_default_52, convolution_default_54, convolution_default_56, convolution_default_58], 1)
        native_batch_norm_default_59 = torch.ops.aten.native_batch_norm.default(cat_default_30, primals_452, primals_448, primals_450, primals_451, False, 0.1, 1e-05);  primals_448 = None
        getitem_179 = native_batch_norm_default_59[0];  native_batch_norm_default_59 = None
        relu__default_59 = torch.ops.aten.relu_.default(getitem_179);  getitem_179 = None
        convolution_default_59 = torch.ops.aten.convolution.default(relu__default_59, primals_446, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_60 = torch.ops.aten.native_batch_norm.default(convolution_default_59, primals_457, primals_453, primals_455, primals_456, False, 0.1, 1e-05);  primals_453 = None
        getitem_182 = native_batch_norm_default_60[0];  native_batch_norm_default_60 = None
        relu__default_60 = torch.ops.aten.relu_.default(getitem_182);  getitem_182 = None
        convolution_default_60 = torch.ops.aten.convolution.default(relu__default_60, primals_447, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_31 = torch.ops.aten.cat.default([avg_pool2d_default_1, convolution_default_40, convolution_default_42, convolution_default_44, convolution_default_46, convolution_default_48, convolution_default_50, convolution_default_52, convolution_default_54, convolution_default_56, convolution_default_58, convolution_default_60], 1)
        native_batch_norm_default_61 = torch.ops.aten.native_batch_norm.default(cat_default_31, primals_464, primals_460, primals_462, primals_463, False, 0.1, 1e-05);  primals_460 = None
        getitem_185 = native_batch_norm_default_61[0];  native_batch_norm_default_61 = None
        relu__default_61 = torch.ops.aten.relu_.default(getitem_185);  getitem_185 = None
        convolution_default_61 = torch.ops.aten.convolution.default(relu__default_61, primals_458, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_62 = torch.ops.aten.native_batch_norm.default(convolution_default_61, primals_469, primals_465, primals_467, primals_468, False, 0.1, 1e-05);  primals_465 = None
        getitem_188 = native_batch_norm_default_62[0];  native_batch_norm_default_62 = None
        relu__default_62 = torch.ops.aten.relu_.default(getitem_188);  getitem_188 = None
        convolution_default_62 = torch.ops.aten.convolution.default(relu__default_62, primals_459, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_32 = torch.ops.aten.cat.default([avg_pool2d_default_1, convolution_default_40, convolution_default_42, convolution_default_44, convolution_default_46, convolution_default_48, convolution_default_50, convolution_default_52, convolution_default_54, convolution_default_56, convolution_default_58, convolution_default_60, convolution_default_62], 1)
        native_batch_norm_default_63 = torch.ops.aten.native_batch_norm.default(cat_default_32, primals_476, primals_472, primals_474, primals_475, False, 0.1, 1e-05);  primals_472 = None
        getitem_191 = native_batch_norm_default_63[0];  native_batch_norm_default_63 = None
        relu__default_63 = torch.ops.aten.relu_.default(getitem_191);  getitem_191 = None
        convolution_default_63 = torch.ops.aten.convolution.default(relu__default_63, primals_470, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_64 = torch.ops.aten.native_batch_norm.default(convolution_default_63, primals_481, primals_477, primals_479, primals_480, False, 0.1, 1e-05);  primals_477 = None
        getitem_194 = native_batch_norm_default_64[0];  native_batch_norm_default_64 = None
        relu__default_64 = torch.ops.aten.relu_.default(getitem_194);  getitem_194 = None
        convolution_default_64 = torch.ops.aten.convolution.default(relu__default_64, primals_471, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_33 = torch.ops.aten.cat.default([avg_pool2d_default_1, convolution_default_40, convolution_default_42, convolution_default_44, convolution_default_46, convolution_default_48, convolution_default_50, convolution_default_52, convolution_default_54, convolution_default_56, convolution_default_58, convolution_default_60, convolution_default_62, convolution_default_64], 1)
        native_batch_norm_default_65 = torch.ops.aten.native_batch_norm.default(cat_default_33, primals_488, primals_484, primals_486, primals_487, False, 0.1, 1e-05);  primals_484 = None
        getitem_197 = native_batch_norm_default_65[0];  native_batch_norm_default_65 = None
        relu__default_65 = torch.ops.aten.relu_.default(getitem_197);  getitem_197 = None
        convolution_default_65 = torch.ops.aten.convolution.default(relu__default_65, primals_482, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_66 = torch.ops.aten.native_batch_norm.default(convolution_default_65, primals_493, primals_489, primals_491, primals_492, False, 0.1, 1e-05);  primals_489 = None
        getitem_200 = native_batch_norm_default_66[0];  native_batch_norm_default_66 = None
        relu__default_66 = torch.ops.aten.relu_.default(getitem_200);  getitem_200 = None
        convolution_default_66 = torch.ops.aten.convolution.default(relu__default_66, primals_483, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_34 = torch.ops.aten.cat.default([avg_pool2d_default_1, convolution_default_40, convolution_default_42, convolution_default_44, convolution_default_46, convolution_default_48, convolution_default_50, convolution_default_52, convolution_default_54, convolution_default_56, convolution_default_58, convolution_default_60, convolution_default_62, convolution_default_64, convolution_default_66], 1)
        native_batch_norm_default_67 = torch.ops.aten.native_batch_norm.default(cat_default_34, primals_500, primals_496, primals_498, primals_499, False, 0.1, 1e-05);  primals_496 = None
        getitem_203 = native_batch_norm_default_67[0];  native_batch_norm_default_67 = None
        relu__default_67 = torch.ops.aten.relu_.default(getitem_203);  getitem_203 = None
        convolution_default_67 = torch.ops.aten.convolution.default(relu__default_67, primals_494, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_68 = torch.ops.aten.native_batch_norm.default(convolution_default_67, primals_505, primals_501, primals_503, primals_504, False, 0.1, 1e-05);  primals_501 = None
        getitem_206 = native_batch_norm_default_68[0];  native_batch_norm_default_68 = None
        relu__default_68 = torch.ops.aten.relu_.default(getitem_206);  getitem_206 = None
        convolution_default_68 = torch.ops.aten.convolution.default(relu__default_68, primals_495, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_35 = torch.ops.aten.cat.default([avg_pool2d_default_1, convolution_default_40, convolution_default_42, convolution_default_44, convolution_default_46, convolution_default_48, convolution_default_50, convolution_default_52, convolution_default_54, convolution_default_56, convolution_default_58, convolution_default_60, convolution_default_62, convolution_default_64, convolution_default_66, convolution_default_68], 1)
        native_batch_norm_default_69 = torch.ops.aten.native_batch_norm.default(cat_default_35, primals_512, primals_508, primals_510, primals_511, False, 0.1, 1e-05);  primals_508 = None
        getitem_209 = native_batch_norm_default_69[0];  native_batch_norm_default_69 = None
        relu__default_69 = torch.ops.aten.relu_.default(getitem_209);  getitem_209 = None
        convolution_default_69 = torch.ops.aten.convolution.default(relu__default_69, primals_506, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_70 = torch.ops.aten.native_batch_norm.default(convolution_default_69, primals_517, primals_513, primals_515, primals_516, False, 0.1, 1e-05);  primals_513 = None
        getitem_212 = native_batch_norm_default_70[0];  native_batch_norm_default_70 = None
        relu__default_70 = torch.ops.aten.relu_.default(getitem_212);  getitem_212 = None
        convolution_default_70 = torch.ops.aten.convolution.default(relu__default_70, primals_507, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_36 = torch.ops.aten.cat.default([avg_pool2d_default_1, convolution_default_40, convolution_default_42, convolution_default_44, convolution_default_46, convolution_default_48, convolution_default_50, convolution_default_52, convolution_default_54, convolution_default_56, convolution_default_58, convolution_default_60, convolution_default_62, convolution_default_64, convolution_default_66, convolution_default_68, convolution_default_70], 1)
        native_batch_norm_default_71 = torch.ops.aten.native_batch_norm.default(cat_default_36, primals_524, primals_520, primals_522, primals_523, False, 0.1, 1e-05);  primals_520 = None
        getitem_215 = native_batch_norm_default_71[0];  native_batch_norm_default_71 = None
        relu__default_71 = torch.ops.aten.relu_.default(getitem_215);  getitem_215 = None
        convolution_default_71 = torch.ops.aten.convolution.default(relu__default_71, primals_518, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_72 = torch.ops.aten.native_batch_norm.default(convolution_default_71, primals_529, primals_525, primals_527, primals_528, False, 0.1, 1e-05);  primals_525 = None
        getitem_218 = native_batch_norm_default_72[0];  native_batch_norm_default_72 = None
        relu__default_72 = torch.ops.aten.relu_.default(getitem_218);  getitem_218 = None
        convolution_default_72 = torch.ops.aten.convolution.default(relu__default_72, primals_519, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_37 = torch.ops.aten.cat.default([avg_pool2d_default_1, convolution_default_40, convolution_default_42, convolution_default_44, convolution_default_46, convolution_default_48, convolution_default_50, convolution_default_52, convolution_default_54, convolution_default_56, convolution_default_58, convolution_default_60, convolution_default_62, convolution_default_64, convolution_default_66, convolution_default_68, convolution_default_70, convolution_default_72], 1)
        native_batch_norm_default_73 = torch.ops.aten.native_batch_norm.default(cat_default_37, primals_536, primals_532, primals_534, primals_535, False, 0.1, 1e-05);  primals_532 = None
        getitem_221 = native_batch_norm_default_73[0];  native_batch_norm_default_73 = None
        relu__default_73 = torch.ops.aten.relu_.default(getitem_221);  getitem_221 = None
        convolution_default_73 = torch.ops.aten.convolution.default(relu__default_73, primals_530, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_74 = torch.ops.aten.native_batch_norm.default(convolution_default_73, primals_541, primals_537, primals_539, primals_540, False, 0.1, 1e-05);  primals_537 = None
        getitem_224 = native_batch_norm_default_74[0];  native_batch_norm_default_74 = None
        relu__default_74 = torch.ops.aten.relu_.default(getitem_224);  getitem_224 = None
        convolution_default_74 = torch.ops.aten.convolution.default(relu__default_74, primals_531, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_38 = torch.ops.aten.cat.default([avg_pool2d_default_1, convolution_default_40, convolution_default_42, convolution_default_44, convolution_default_46, convolution_default_48, convolution_default_50, convolution_default_52, convolution_default_54, convolution_default_56, convolution_default_58, convolution_default_60, convolution_default_62, convolution_default_64, convolution_default_66, convolution_default_68, convolution_default_70, convolution_default_72, convolution_default_74], 1)
        native_batch_norm_default_75 = torch.ops.aten.native_batch_norm.default(cat_default_38, primals_548, primals_544, primals_546, primals_547, False, 0.1, 1e-05);  primals_544 = None
        getitem_227 = native_batch_norm_default_75[0];  native_batch_norm_default_75 = None
        relu__default_75 = torch.ops.aten.relu_.default(getitem_227);  getitem_227 = None
        convolution_default_75 = torch.ops.aten.convolution.default(relu__default_75, primals_542, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_76 = torch.ops.aten.native_batch_norm.default(convolution_default_75, primals_553, primals_549, primals_551, primals_552, False, 0.1, 1e-05);  primals_549 = None
        getitem_230 = native_batch_norm_default_76[0];  native_batch_norm_default_76 = None
        relu__default_76 = torch.ops.aten.relu_.default(getitem_230);  getitem_230 = None
        convolution_default_76 = torch.ops.aten.convolution.default(relu__default_76, primals_543, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_39 = torch.ops.aten.cat.default([avg_pool2d_default_1, convolution_default_40, convolution_default_42, convolution_default_44, convolution_default_46, convolution_default_48, convolution_default_50, convolution_default_52, convolution_default_54, convolution_default_56, convolution_default_58, convolution_default_60, convolution_default_62, convolution_default_64, convolution_default_66, convolution_default_68, convolution_default_70, convolution_default_72, convolution_default_74, convolution_default_76], 1)
        native_batch_norm_default_77 = torch.ops.aten.native_batch_norm.default(cat_default_39, primals_572, primals_568, primals_570, primals_571, False, 0.1, 1e-05);  primals_568 = None
        getitem_233 = native_batch_norm_default_77[0];  native_batch_norm_default_77 = None
        relu__default_77 = torch.ops.aten.relu_.default(getitem_233);  getitem_233 = None
        convolution_default_77 = torch.ops.aten.convolution.default(relu__default_77, primals_566, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_78 = torch.ops.aten.native_batch_norm.default(convolution_default_77, primals_577, primals_573, primals_575, primals_576, False, 0.1, 1e-05);  primals_573 = None
        getitem_236 = native_batch_norm_default_78[0];  native_batch_norm_default_78 = None
        relu__default_78 = torch.ops.aten.relu_.default(getitem_236);  getitem_236 = None
        convolution_default_78 = torch.ops.aten.convolution.default(relu__default_78, primals_567, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_40 = torch.ops.aten.cat.default([avg_pool2d_default_1, convolution_default_40, convolution_default_42, convolution_default_44, convolution_default_46, convolution_default_48, convolution_default_50, convolution_default_52, convolution_default_54, convolution_default_56, convolution_default_58, convolution_default_60, convolution_default_62, convolution_default_64, convolution_default_66, convolution_default_68, convolution_default_70, convolution_default_72, convolution_default_74, convolution_default_76, convolution_default_78], 1)
        native_batch_norm_default_79 = torch.ops.aten.native_batch_norm.default(cat_default_40, primals_584, primals_580, primals_582, primals_583, False, 0.1, 1e-05);  primals_580 = None
        getitem_239 = native_batch_norm_default_79[0];  native_batch_norm_default_79 = None
        relu__default_79 = torch.ops.aten.relu_.default(getitem_239);  getitem_239 = None
        convolution_default_79 = torch.ops.aten.convolution.default(relu__default_79, primals_578, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_80 = torch.ops.aten.native_batch_norm.default(convolution_default_79, primals_589, primals_585, primals_587, primals_588, False, 0.1, 1e-05);  primals_585 = None
        getitem_242 = native_batch_norm_default_80[0];  native_batch_norm_default_80 = None
        relu__default_80 = torch.ops.aten.relu_.default(getitem_242);  getitem_242 = None
        convolution_default_80 = torch.ops.aten.convolution.default(relu__default_80, primals_579, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_41 = torch.ops.aten.cat.default([avg_pool2d_default_1, convolution_default_40, convolution_default_42, convolution_default_44, convolution_default_46, convolution_default_48, convolution_default_50, convolution_default_52, convolution_default_54, convolution_default_56, convolution_default_58, convolution_default_60, convolution_default_62, convolution_default_64, convolution_default_66, convolution_default_68, convolution_default_70, convolution_default_72, convolution_default_74, convolution_default_76, convolution_default_78, convolution_default_80], 1)
        native_batch_norm_default_81 = torch.ops.aten.native_batch_norm.default(cat_default_41, primals_596, primals_592, primals_594, primals_595, False, 0.1, 1e-05);  primals_592 = None
        getitem_245 = native_batch_norm_default_81[0];  native_batch_norm_default_81 = None
        relu__default_81 = torch.ops.aten.relu_.default(getitem_245);  getitem_245 = None
        convolution_default_81 = torch.ops.aten.convolution.default(relu__default_81, primals_590, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_82 = torch.ops.aten.native_batch_norm.default(convolution_default_81, primals_601, primals_597, primals_599, primals_600, False, 0.1, 1e-05);  primals_597 = None
        getitem_248 = native_batch_norm_default_82[0];  native_batch_norm_default_82 = None
        relu__default_82 = torch.ops.aten.relu_.default(getitem_248);  getitem_248 = None
        convolution_default_82 = torch.ops.aten.convolution.default(relu__default_82, primals_591, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_42 = torch.ops.aten.cat.default([avg_pool2d_default_1, convolution_default_40, convolution_default_42, convolution_default_44, convolution_default_46, convolution_default_48, convolution_default_50, convolution_default_52, convolution_default_54, convolution_default_56, convolution_default_58, convolution_default_60, convolution_default_62, convolution_default_64, convolution_default_66, convolution_default_68, convolution_default_70, convolution_default_72, convolution_default_74, convolution_default_76, convolution_default_78, convolution_default_80, convolution_default_82], 1)
        native_batch_norm_default_83 = torch.ops.aten.native_batch_norm.default(cat_default_42, primals_608, primals_604, primals_606, primals_607, False, 0.1, 1e-05);  primals_604 = None
        getitem_251 = native_batch_norm_default_83[0];  native_batch_norm_default_83 = None
        relu__default_83 = torch.ops.aten.relu_.default(getitem_251);  getitem_251 = None
        convolution_default_83 = torch.ops.aten.convolution.default(relu__default_83, primals_602, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_84 = torch.ops.aten.native_batch_norm.default(convolution_default_83, primals_613, primals_609, primals_611, primals_612, False, 0.1, 1e-05);  primals_609 = None
        getitem_254 = native_batch_norm_default_84[0];  native_batch_norm_default_84 = None
        relu__default_84 = torch.ops.aten.relu_.default(getitem_254);  getitem_254 = None
        convolution_default_84 = torch.ops.aten.convolution.default(relu__default_84, primals_603, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_43 = torch.ops.aten.cat.default([avg_pool2d_default_1, convolution_default_40, convolution_default_42, convolution_default_44, convolution_default_46, convolution_default_48, convolution_default_50, convolution_default_52, convolution_default_54, convolution_default_56, convolution_default_58, convolution_default_60, convolution_default_62, convolution_default_64, convolution_default_66, convolution_default_68, convolution_default_70, convolution_default_72, convolution_default_74, convolution_default_76, convolution_default_78, convolution_default_80, convolution_default_82, convolution_default_84], 1)
        native_batch_norm_default_85 = torch.ops.aten.native_batch_norm.default(cat_default_43, primals_620, primals_616, primals_618, primals_619, False, 0.1, 1e-05);  primals_616 = None
        getitem_257 = native_batch_norm_default_85[0];  native_batch_norm_default_85 = None
        relu__default_85 = torch.ops.aten.relu_.default(getitem_257);  getitem_257 = None
        convolution_default_85 = torch.ops.aten.convolution.default(relu__default_85, primals_614, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_86 = torch.ops.aten.native_batch_norm.default(convolution_default_85, primals_625, primals_621, primals_623, primals_624, False, 0.1, 1e-05);  primals_621 = None
        getitem_260 = native_batch_norm_default_86[0];  native_batch_norm_default_86 = None
        relu__default_86 = torch.ops.aten.relu_.default(getitem_260);  getitem_260 = None
        convolution_default_86 = torch.ops.aten.convolution.default(relu__default_86, primals_615, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_44 = torch.ops.aten.cat.default([avg_pool2d_default_1, convolution_default_40, convolution_default_42, convolution_default_44, convolution_default_46, convolution_default_48, convolution_default_50, convolution_default_52, convolution_default_54, convolution_default_56, convolution_default_58, convolution_default_60, convolution_default_62, convolution_default_64, convolution_default_66, convolution_default_68, convolution_default_70, convolution_default_72, convolution_default_74, convolution_default_76, convolution_default_78, convolution_default_80, convolution_default_82, convolution_default_84, convolution_default_86], 1);  avg_pool2d_default_1 = convolution_default_40 = convolution_default_42 = convolution_default_44 = convolution_default_46 = convolution_default_48 = convolution_default_50 = convolution_default_52 = convolution_default_54 = convolution_default_56 = convolution_default_58 = convolution_default_60 = convolution_default_62 = convolution_default_64 = convolution_default_66 = convolution_default_68 = convolution_default_70 = convolution_default_72 = convolution_default_74 = convolution_default_76 = convolution_default_78 = convolution_default_80 = convolution_default_82 = convolution_default_84 = convolution_default_86 = None
        native_batch_norm_default_87 = torch.ops.aten.native_batch_norm.default(cat_default_44, primals_726, primals_722, primals_724, primals_725, False, 0.1, 1e-05);  primals_722 = None
        getitem_263 = native_batch_norm_default_87[0];  native_batch_norm_default_87 = None
        relu__default_87 = torch.ops.aten.relu_.default(getitem_263);  getitem_263 = None
        convolution_default_87 = torch.ops.aten.convolution.default(relu__default_87, primals_727, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        avg_pool2d_default_2 = torch.ops.aten.avg_pool2d.default(convolution_default_87, [2, 2], [2, 2])
        cat_default_45 = torch.ops.aten.cat.default([avg_pool2d_default_2], 1)
        native_batch_norm_default_88 = torch.ops.aten.native_batch_norm.default(cat_default_45, primals_99, primals_95, primals_97, primals_98, False, 0.1, 1e-05);  primals_95 = None
        getitem_266 = native_batch_norm_default_88[0];  native_batch_norm_default_88 = None
        relu__default_88 = torch.ops.aten.relu_.default(getitem_266);  getitem_266 = None
        convolution_default_88 = torch.ops.aten.convolution.default(relu__default_88, primals_93, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_89 = torch.ops.aten.native_batch_norm.default(convolution_default_88, primals_104, primals_100, primals_102, primals_103, False, 0.1, 1e-05);  primals_100 = None
        getitem_269 = native_batch_norm_default_89[0];  native_batch_norm_default_89 = None
        relu__default_89 = torch.ops.aten.relu_.default(getitem_269);  getitem_269 = None
        convolution_default_89 = torch.ops.aten.convolution.default(relu__default_89, primals_94, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_46 = torch.ops.aten.cat.default([avg_pool2d_default_2, convolution_default_89], 1)
        native_batch_norm_default_90 = torch.ops.aten.native_batch_norm.default(cat_default_46, primals_111, primals_107, primals_109, primals_110, False, 0.1, 1e-05);  primals_107 = None
        getitem_272 = native_batch_norm_default_90[0];  native_batch_norm_default_90 = None
        relu__default_90 = torch.ops.aten.relu_.default(getitem_272);  getitem_272 = None
        convolution_default_90 = torch.ops.aten.convolution.default(relu__default_90, primals_105, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_91 = torch.ops.aten.native_batch_norm.default(convolution_default_90, primals_116, primals_112, primals_114, primals_115, False, 0.1, 1e-05);  primals_112 = None
        getitem_275 = native_batch_norm_default_91[0];  native_batch_norm_default_91 = None
        relu__default_91 = torch.ops.aten.relu_.default(getitem_275);  getitem_275 = None
        convolution_default_91 = torch.ops.aten.convolution.default(relu__default_91, primals_106, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_47 = torch.ops.aten.cat.default([avg_pool2d_default_2, convolution_default_89, convolution_default_91], 1)
        native_batch_norm_default_92 = torch.ops.aten.native_batch_norm.default(cat_default_47, primals_123, primals_119, primals_121, primals_122, False, 0.1, 1e-05);  primals_119 = None
        getitem_278 = native_batch_norm_default_92[0];  native_batch_norm_default_92 = None
        relu__default_92 = torch.ops.aten.relu_.default(getitem_278);  getitem_278 = None
        convolution_default_92 = torch.ops.aten.convolution.default(relu__default_92, primals_117, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_93 = torch.ops.aten.native_batch_norm.default(convolution_default_92, primals_128, primals_124, primals_126, primals_127, False, 0.1, 1e-05);  primals_124 = None
        getitem_281 = native_batch_norm_default_93[0];  native_batch_norm_default_93 = None
        relu__default_93 = torch.ops.aten.relu_.default(getitem_281);  getitem_281 = None
        convolution_default_93 = torch.ops.aten.convolution.default(relu__default_93, primals_118, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_48 = torch.ops.aten.cat.default([avg_pool2d_default_2, convolution_default_89, convolution_default_91, convolution_default_93], 1)
        native_batch_norm_default_94 = torch.ops.aten.native_batch_norm.default(cat_default_48, primals_135, primals_131, primals_133, primals_134, False, 0.1, 1e-05);  primals_131 = None
        getitem_284 = native_batch_norm_default_94[0];  native_batch_norm_default_94 = None
        relu__default_94 = torch.ops.aten.relu_.default(getitem_284);  getitem_284 = None
        convolution_default_94 = torch.ops.aten.convolution.default(relu__default_94, primals_129, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_95 = torch.ops.aten.native_batch_norm.default(convolution_default_94, primals_140, primals_136, primals_138, primals_139, False, 0.1, 1e-05);  primals_136 = None
        getitem_287 = native_batch_norm_default_95[0];  native_batch_norm_default_95 = None
        relu__default_95 = torch.ops.aten.relu_.default(getitem_287);  getitem_287 = None
        convolution_default_95 = torch.ops.aten.convolution.default(relu__default_95, primals_130, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_49 = torch.ops.aten.cat.default([avg_pool2d_default_2, convolution_default_89, convolution_default_91, convolution_default_93, convolution_default_95], 1)
        native_batch_norm_default_96 = torch.ops.aten.native_batch_norm.default(cat_default_49, primals_147, primals_143, primals_145, primals_146, False, 0.1, 1e-05);  primals_143 = None
        getitem_290 = native_batch_norm_default_96[0];  native_batch_norm_default_96 = None
        relu__default_96 = torch.ops.aten.relu_.default(getitem_290);  getitem_290 = None
        convolution_default_96 = torch.ops.aten.convolution.default(relu__default_96, primals_141, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_97 = torch.ops.aten.native_batch_norm.default(convolution_default_96, primals_152, primals_148, primals_150, primals_151, False, 0.1, 1e-05);  primals_148 = None
        getitem_293 = native_batch_norm_default_97[0];  native_batch_norm_default_97 = None
        relu__default_97 = torch.ops.aten.relu_.default(getitem_293);  getitem_293 = None
        convolution_default_97 = torch.ops.aten.convolution.default(relu__default_97, primals_142, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_50 = torch.ops.aten.cat.default([avg_pool2d_default_2, convolution_default_89, convolution_default_91, convolution_default_93, convolution_default_95, convolution_default_97], 1)
        native_batch_norm_default_98 = torch.ops.aten.native_batch_norm.default(cat_default_50, primals_159, primals_155, primals_157, primals_158, False, 0.1, 1e-05);  primals_155 = None
        getitem_296 = native_batch_norm_default_98[0];  native_batch_norm_default_98 = None
        relu__default_98 = torch.ops.aten.relu_.default(getitem_296);  getitem_296 = None
        convolution_default_98 = torch.ops.aten.convolution.default(relu__default_98, primals_153, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_99 = torch.ops.aten.native_batch_norm.default(convolution_default_98, primals_164, primals_160, primals_162, primals_163, False, 0.1, 1e-05);  primals_160 = None
        getitem_299 = native_batch_norm_default_99[0];  native_batch_norm_default_99 = None
        relu__default_99 = torch.ops.aten.relu_.default(getitem_299);  getitem_299 = None
        convolution_default_99 = torch.ops.aten.convolution.default(relu__default_99, primals_154, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_51 = torch.ops.aten.cat.default([avg_pool2d_default_2, convolution_default_89, convolution_default_91, convolution_default_93, convolution_default_95, convolution_default_97, convolution_default_99], 1)
        native_batch_norm_default_100 = torch.ops.aten.native_batch_norm.default(cat_default_51, primals_171, primals_167, primals_169, primals_170, False, 0.1, 1e-05);  primals_167 = None
        getitem_302 = native_batch_norm_default_100[0];  native_batch_norm_default_100 = None
        relu__default_100 = torch.ops.aten.relu_.default(getitem_302);  getitem_302 = None
        convolution_default_100 = torch.ops.aten.convolution.default(relu__default_100, primals_165, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_101 = torch.ops.aten.native_batch_norm.default(convolution_default_100, primals_176, primals_172, primals_174, primals_175, False, 0.1, 1e-05);  primals_172 = None
        getitem_305 = native_batch_norm_default_101[0];  native_batch_norm_default_101 = None
        relu__default_101 = torch.ops.aten.relu_.default(getitem_305);  getitem_305 = None
        convolution_default_101 = torch.ops.aten.convolution.default(relu__default_101, primals_166, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_52 = torch.ops.aten.cat.default([avg_pool2d_default_2, convolution_default_89, convolution_default_91, convolution_default_93, convolution_default_95, convolution_default_97, convolution_default_99, convolution_default_101], 1)
        native_batch_norm_default_102 = torch.ops.aten.native_batch_norm.default(cat_default_52, primals_183, primals_179, primals_181, primals_182, False, 0.1, 1e-05);  primals_179 = None
        getitem_308 = native_batch_norm_default_102[0];  native_batch_norm_default_102 = None
        relu__default_102 = torch.ops.aten.relu_.default(getitem_308);  getitem_308 = None
        convolution_default_102 = torch.ops.aten.convolution.default(relu__default_102, primals_177, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_103 = torch.ops.aten.native_batch_norm.default(convolution_default_102, primals_188, primals_184, primals_186, primals_187, False, 0.1, 1e-05);  primals_184 = None
        getitem_311 = native_batch_norm_default_103[0];  native_batch_norm_default_103 = None
        relu__default_103 = torch.ops.aten.relu_.default(getitem_311);  getitem_311 = None
        convolution_default_103 = torch.ops.aten.convolution.default(relu__default_103, primals_178, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_53 = torch.ops.aten.cat.default([avg_pool2d_default_2, convolution_default_89, convolution_default_91, convolution_default_93, convolution_default_95, convolution_default_97, convolution_default_99, convolution_default_101, convolution_default_103], 1)
        native_batch_norm_default_104 = torch.ops.aten.native_batch_norm.default(cat_default_53, primals_195, primals_191, primals_193, primals_194, False, 0.1, 1e-05);  primals_191 = None
        getitem_314 = native_batch_norm_default_104[0];  native_batch_norm_default_104 = None
        relu__default_104 = torch.ops.aten.relu_.default(getitem_314);  getitem_314 = None
        convolution_default_104 = torch.ops.aten.convolution.default(relu__default_104, primals_189, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_105 = torch.ops.aten.native_batch_norm.default(convolution_default_104, primals_200, primals_196, primals_198, primals_199, False, 0.1, 1e-05);  primals_196 = None
        getitem_317 = native_batch_norm_default_105[0];  native_batch_norm_default_105 = None
        relu__default_105 = torch.ops.aten.relu_.default(getitem_317);  getitem_317 = None
        convolution_default_105 = torch.ops.aten.convolution.default(relu__default_105, primals_190, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_54 = torch.ops.aten.cat.default([avg_pool2d_default_2, convolution_default_89, convolution_default_91, convolution_default_93, convolution_default_95, convolution_default_97, convolution_default_99, convolution_default_101, convolution_default_103, convolution_default_105], 1)
        native_batch_norm_default_106 = torch.ops.aten.native_batch_norm.default(cat_default_54, primals_15, primals_11, primals_13, primals_14, False, 0.1, 1e-05);  primals_11 = None
        getitem_320 = native_batch_norm_default_106[0];  native_batch_norm_default_106 = None
        relu__default_106 = torch.ops.aten.relu_.default(getitem_320);  getitem_320 = None
        convolution_default_106 = torch.ops.aten.convolution.default(relu__default_106, primals_9, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_107 = torch.ops.aten.native_batch_norm.default(convolution_default_106, primals_20, primals_16, primals_18, primals_19, False, 0.1, 1e-05);  primals_16 = None
        getitem_323 = native_batch_norm_default_107[0];  native_batch_norm_default_107 = None
        relu__default_107 = torch.ops.aten.relu_.default(getitem_323);  getitem_323 = None
        convolution_default_107 = torch.ops.aten.convolution.default(relu__default_107, primals_10, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_55 = torch.ops.aten.cat.default([avg_pool2d_default_2, convolution_default_89, convolution_default_91, convolution_default_93, convolution_default_95, convolution_default_97, convolution_default_99, convolution_default_101, convolution_default_103, convolution_default_105, convolution_default_107], 1)
        native_batch_norm_default_108 = torch.ops.aten.native_batch_norm.default(cat_default_55, primals_27, primals_23, primals_25, primals_26, False, 0.1, 1e-05);  primals_23 = None
        getitem_326 = native_batch_norm_default_108[0];  native_batch_norm_default_108 = None
        relu__default_108 = torch.ops.aten.relu_.default(getitem_326);  getitem_326 = None
        convolution_default_108 = torch.ops.aten.convolution.default(relu__default_108, primals_21, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_109 = torch.ops.aten.native_batch_norm.default(convolution_default_108, primals_32, primals_28, primals_30, primals_31, False, 0.1, 1e-05);  primals_28 = None
        getitem_329 = native_batch_norm_default_109[0];  native_batch_norm_default_109 = None
        relu__default_109 = torch.ops.aten.relu_.default(getitem_329);  getitem_329 = None
        convolution_default_109 = torch.ops.aten.convolution.default(relu__default_109, primals_22, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_56 = torch.ops.aten.cat.default([avg_pool2d_default_2, convolution_default_89, convolution_default_91, convolution_default_93, convolution_default_95, convolution_default_97, convolution_default_99, convolution_default_101, convolution_default_103, convolution_default_105, convolution_default_107, convolution_default_109], 1)
        native_batch_norm_default_110 = torch.ops.aten.native_batch_norm.default(cat_default_56, primals_39, primals_35, primals_37, primals_38, False, 0.1, 1e-05);  primals_35 = None
        getitem_332 = native_batch_norm_default_110[0];  native_batch_norm_default_110 = None
        relu__default_110 = torch.ops.aten.relu_.default(getitem_332);  getitem_332 = None
        convolution_default_110 = torch.ops.aten.convolution.default(relu__default_110, primals_33, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_111 = torch.ops.aten.native_batch_norm.default(convolution_default_110, primals_44, primals_40, primals_42, primals_43, False, 0.1, 1e-05);  primals_40 = None
        getitem_335 = native_batch_norm_default_111[0];  native_batch_norm_default_111 = None
        relu__default_111 = torch.ops.aten.relu_.default(getitem_335);  getitem_335 = None
        convolution_default_111 = torch.ops.aten.convolution.default(relu__default_111, primals_34, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_57 = torch.ops.aten.cat.default([avg_pool2d_default_2, convolution_default_89, convolution_default_91, convolution_default_93, convolution_default_95, convolution_default_97, convolution_default_99, convolution_default_101, convolution_default_103, convolution_default_105, convolution_default_107, convolution_default_109, convolution_default_111], 1)
        native_batch_norm_default_112 = torch.ops.aten.native_batch_norm.default(cat_default_57, primals_51, primals_47, primals_49, primals_50, False, 0.1, 1e-05);  primals_47 = None
        getitem_338 = native_batch_norm_default_112[0];  native_batch_norm_default_112 = None
        relu__default_112 = torch.ops.aten.relu_.default(getitem_338);  getitem_338 = None
        convolution_default_112 = torch.ops.aten.convolution.default(relu__default_112, primals_45, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_113 = torch.ops.aten.native_batch_norm.default(convolution_default_112, primals_56, primals_52, primals_54, primals_55, False, 0.1, 1e-05);  primals_52 = None
        getitem_341 = native_batch_norm_default_113[0];  native_batch_norm_default_113 = None
        relu__default_113 = torch.ops.aten.relu_.default(getitem_341);  getitem_341 = None
        convolution_default_113 = torch.ops.aten.convolution.default(relu__default_113, primals_46, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_58 = torch.ops.aten.cat.default([avg_pool2d_default_2, convolution_default_89, convolution_default_91, convolution_default_93, convolution_default_95, convolution_default_97, convolution_default_99, convolution_default_101, convolution_default_103, convolution_default_105, convolution_default_107, convolution_default_109, convolution_default_111, convolution_default_113], 1)
        native_batch_norm_default_114 = torch.ops.aten.native_batch_norm.default(cat_default_58, primals_63, primals_59, primals_61, primals_62, False, 0.1, 1e-05);  primals_59 = None
        getitem_344 = native_batch_norm_default_114[0];  native_batch_norm_default_114 = None
        relu__default_114 = torch.ops.aten.relu_.default(getitem_344);  getitem_344 = None
        convolution_default_114 = torch.ops.aten.convolution.default(relu__default_114, primals_57, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_115 = torch.ops.aten.native_batch_norm.default(convolution_default_114, primals_68, primals_64, primals_66, primals_67, False, 0.1, 1e-05);  primals_64 = None
        getitem_347 = native_batch_norm_default_115[0];  native_batch_norm_default_115 = None
        relu__default_115 = torch.ops.aten.relu_.default(getitem_347);  getitem_347 = None
        convolution_default_115 = torch.ops.aten.convolution.default(relu__default_115, primals_58, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_59 = torch.ops.aten.cat.default([avg_pool2d_default_2, convolution_default_89, convolution_default_91, convolution_default_93, convolution_default_95, convolution_default_97, convolution_default_99, convolution_default_101, convolution_default_103, convolution_default_105, convolution_default_107, convolution_default_109, convolution_default_111, convolution_default_113, convolution_default_115], 1)
        native_batch_norm_default_116 = torch.ops.aten.native_batch_norm.default(cat_default_59, primals_75, primals_71, primals_73, primals_74, False, 0.1, 1e-05);  primals_71 = None
        getitem_350 = native_batch_norm_default_116[0];  native_batch_norm_default_116 = None
        relu__default_116 = torch.ops.aten.relu_.default(getitem_350);  getitem_350 = None
        convolution_default_116 = torch.ops.aten.convolution.default(relu__default_116, primals_69, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_117 = torch.ops.aten.native_batch_norm.default(convolution_default_116, primals_80, primals_76, primals_78, primals_79, False, 0.1, 1e-05);  primals_76 = None
        getitem_353 = native_batch_norm_default_117[0];  native_batch_norm_default_117 = None
        relu__default_117 = torch.ops.aten.relu_.default(getitem_353);  getitem_353 = None
        convolution_default_117 = torch.ops.aten.convolution.default(relu__default_117, primals_70, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_60 = torch.ops.aten.cat.default([avg_pool2d_default_2, convolution_default_89, convolution_default_91, convolution_default_93, convolution_default_95, convolution_default_97, convolution_default_99, convolution_default_101, convolution_default_103, convolution_default_105, convolution_default_107, convolution_default_109, convolution_default_111, convolution_default_113, convolution_default_115, convolution_default_117], 1)
        native_batch_norm_default_118 = torch.ops.aten.native_batch_norm.default(cat_default_60, primals_87, primals_83, primals_85, primals_86, False, 0.1, 1e-05);  primals_83 = None
        getitem_356 = native_batch_norm_default_118[0];  native_batch_norm_default_118 = None
        relu__default_118 = torch.ops.aten.relu_.default(getitem_356);  getitem_356 = None
        convolution_default_118 = torch.ops.aten.convolution.default(relu__default_118, primals_81, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_119 = torch.ops.aten.native_batch_norm.default(convolution_default_118, primals_92, primals_88, primals_90, primals_91, False, 0.1, 1e-05);  primals_88 = None
        getitem_359 = native_batch_norm_default_119[0];  native_batch_norm_default_119 = None
        relu__default_119 = torch.ops.aten.relu_.default(getitem_359);  getitem_359 = None
        convolution_default_119 = torch.ops.aten.convolution.default(relu__default_119, primals_82, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_61 = torch.ops.aten.cat.default([avg_pool2d_default_2, convolution_default_89, convolution_default_91, convolution_default_93, convolution_default_95, convolution_default_97, convolution_default_99, convolution_default_101, convolution_default_103, convolution_default_105, convolution_default_107, convolution_default_109, convolution_default_111, convolution_default_113, convolution_default_115, convolution_default_117, convolution_default_119], 1);  avg_pool2d_default_2 = convolution_default_89 = convolution_default_91 = convolution_default_93 = convolution_default_95 = convolution_default_97 = convolution_default_99 = convolution_default_101 = convolution_default_103 = convolution_default_105 = convolution_default_107 = convolution_default_109 = convolution_default_111 = convolution_default_113 = convolution_default_115 = convolution_default_117 = convolution_default_119 = None
        native_batch_norm_default_120 = torch.ops.aten.native_batch_norm.default(cat_default_61, primals_205, primals_201, primals_203, primals_204, False, 0.1, 1e-05);  primals_201 = None
        getitem_362 = native_batch_norm_default_120[0];  native_batch_norm_default_120 = None
        relu__default_120 = torch.ops.aten.relu_.default(getitem_362);  getitem_362 = None
        mean_dim = torch.ops.aten.mean.dim(relu__default_120, [-1, -2], True)
        view_default = torch.ops.aten.view.default(mean_dim, [4, 1024]);  mean_dim = None
        t_default = torch.ops.aten.t.default(primals_2);  primals_2 = None
        addmm_default = torch.ops.aten.addmm.default(primals_1, view_default, t_default);  primals_1 = None
        return [addmm_default, primals_222, primals_230, primals_228, primals_224, primals_216, primals_217, primals_229, cat_default_60, primals_215, primals_223, primals_219, primals_218, primals_227, relu__default_117, convolution_default_114, relu__default_66, primals_188, relu__default_85, convolution_default_85, primals_178, primals_177, relu__default_7, relu__default_92, primals_176, cat_default_44, convolution_default_7, primals_189, primals_181, primals_194, view_default, primals_182, relu__default_93, relu__default_67, relu__default_119, primals_187, convolution_default_67, relu__default_86, relu__default_68, primals_193, relu__default_8, convolution_default_92, primals_186, cat_default_48, relu__default_114, cat_default_35, primals_190, primals_183, primals_175, cat_default_59, cat_default_4, primals_146, relu__default_21, primals_147, primals_138, primals_164, convolution_default_38, primals_151, primals_166, cat_default_20, primals_170, primals_158, relu__default_22, primals_154, primals_145, relu__default_23, relu__default_38, primals_157, primals_141, primals_142, cat_default_11, primals_171, convolution_default_22, primals_152, primals_162, primals_174, primals_165, primals_163, primals_140, primals_150, primals_169, primals_139, primals_153, primals_159, relu__default_73, primals_724, convolution_default_73, relu__default_74, primals_725, primals_726, primals_727, primals_728, cat_default_38, convolution_default_75, relu__default_75, primals_440, primals_294, relu__default_33, primals_434, relu__default_14, convolution_default_14, primals_599, cat_default_8, primals_600, primals_601, primals_432, primals_42, primals_602, primals_444, primals_44, primals_603, primals_433, primals_295, primals_284, convolution_default_110, primals_445, primals_45, relu__default_15, primals_606, primals_288, primals_607, primals_443, primals_608, relu__default_34, primals_447, primals_446, primals_282, relu__default_16, primals_296, primals_289, primals_438, convolution_default_34, primals_281, primals_611, primals_439, primals_612, cat_default_17, relu__default_110, primals_290, primals_39, primals_613, primals_293, primals_43, primals_285, primals_280, primals_614, primals_283, primals_435, primals_615, convolution_default_16, primals_38, primals_297, primals_451, primals_450, primals_46, primals_243, primals_239, cat_default_56, primals_240, relu__default_109, primals_242, primals_241, relu__default_48, relu__default_99, relu__default_28, convolution_default_28, relu__default_41, convolution_default_41, convolution_default_100, relu__default_29, relu__default_49, relu__default_42, convolution_default_88, cat_default_25, relu__default_100, cat_default_51, relu__default_30, convolution_default_30, convolution_default_49, cat_default_22, primals_106, cat_default_15, primals_98, relu__default_80, relu__default, primals_102, getitem_4, primals_97, relu__default_81, primals_103, relu__default_13, convolution_default_118, convolution_default_81, cat_default, primals_99, relu__default_82, primals_105, primals_92, primals_104, relu__default_1, primals_93, primals_91, convolution_default_1, cat_default_42, primals_94, cat_default_1, relu__default_118, primals_90, convolution_default_55, relu__default_55, relu__default_56, cat_default_29, primals_7, primals_618, cat_default_57, primals_619, primals_391, primals_620, primals_13, primals_389, convolution_default_69, relu__default_69, primals_384, primals_623, primals_3, primals_386, primals_390, primals_624, relu__default_70, primals_625, primals_6, primals_385, primals_626, primals_627, relu__default_111, primals_8, primals_630, cat_default_36, primals_631, primals_14, primals_632, primals_15, primals_635, primals_636, primals_10, primals_637, primals_638, primals_9, primals_492, relu__default_62, primals_362, primals_68, primals_493, primals_70, primals_494, primals_69, primals_360, primals_495, primals_82, primals_74, primals_81, primals_498, primals_356, primals_499, primals_85, primals_357, primals_500, primals_67, primals_78, primals_503, primals_79, primals_504, primals_75, primals_80, primals_355, primals_505, relu__default_63, primals_506, cat_default_45, primals_361, primals_507, primals_73, primals_510, primals_231, primals_511, cat_default_32, convolution_default_63, primals_512, primals_307, primals_300, primals_301, convolution_default_9, relu__default_9, primals_317, primals_318, primals_302, primals_305, relu__default_10, primals_314, primals_312, primals_309, primals_306, primals_236, primals_308, convolution_default_11, cat_default_61, relu__default_11, primals_313, cat_default_5, relu__default_35, relu__default_107, relu__default_37, relu__default_120, relu__default_106, relu__default_36, convolution_default_36, convolution_default_106, cat_default_18, cat_default_55, cat_default_19, primals_639, relu__default_76, primals_642, primals_251, primals_643, primals_644, relu__default_24, convolution_default_24, cat_default_12, relu__default_112, relu__default_25, primals_647, primals_648, primals_252, primals_649, primals_650, primals_651, relu__default_77, primals_654, cat_default_13, primals_253, primals_655, convolution_default_112, primals_656, cat_default_39, convolution_default_77, primals_659, relu__default_2, relu__default_17, primals_324, primals_321, primals_515, primals_332, primals_516, primals_330, primals_517, relu__default_94, convolution_default_94, primals_518, cat_default_9, primals_87, primals_519, relu__default_3, primals_326, primals_522, primals_523, primals_86, primals_331, primals_524, primals_333, convolution_default_3, primals_319, relu__default_95, primals_527, primals_528, convolution_default_18, primals_529, relu__default_18, primals_530, relu__default_4, primals_531, cat_default_2, primals_329, primals_320, primals_325, cat_default_49, primals_475, primals_482, primals_474, primals_481, primals_133, primals_134, primals_130, primals_476, primals_480, primals_483, primals_129, primals_486, primals_487, primals_479, primals_488, primals_127, primals_135, primals_491, primals_128, primals_338, primals_353, primals_336, primals_348, primals_341, primals_235, primals_349, primals_350, primals_342, primals_343, primals_345, primals_344, primals_354, primals_234, primals_337, primals_126, primals_115, primals_258, primals_254, primals_109, relu__default_43, convolution_default_43, primals_116, cat_default_23, primals_122, primals_111, primals_118, primals_255, primals_117, primals_114, relu__default_44, primals_110, primals_123, primals_121, relu__default_88, relu__default_50, primals_247, relu__default_51, cat_default_26, primals_246, convolution_default_51, cat_default_27, primals_248, primals_381, primals_50, primals_49, primals_660, primals_367, primals_377, primals_661, primals_58, convolution_default_57, primals_662, primals_66, relu__default_57, primals_663, primals_368, convolution_default_83, relu__default_83, primals_55, primals_62, primals_666, relu__default_84, primals_57, primals_378, primals_667, primals_63, cat_default_30, primals_668, primals_379, relu__default_58, cat_default_43, primals_671, primals_366, primals_56, primals_373, primals_672, primals_54, primals_673, primals_365, primals_61, primals_674, primals_380, primals_675, primals_374, primals_369, primals_678, primals_372, primals_679, primals_680, primals_51, primals_199, primals_534, relu__default_89, primals_535, primals_212, relu__default_90, cat_default_46, primals_536, primals_206, primals_198, primals_195, primals_539, primals_260, primals_540, primals_541, primals_207, primals_542, primals_204, primals_270, primals_271, primals_543, t_default, primals_276, primals_205, primals_272, primals_546, primals_265, convolution_default_90, primals_275, primals_547, primals_267, primals_548, primals_259, primals_210, primals_211, primals_266, primals_551, primals_200, primals_552, relu__default_91, primals_264, primals_553, primals_554, primals_263, primals_203, primals_277, cat_default_47, relu__default_64, relu__default_71, convolution_default_71, cat_default_37, relu__default_113, relu__default_65, relu__default_72, cat_default_58, convolution_default_65, cat_default_33, cat_default_34, relu__default_87, primals_398, relu__default_101, primals_37, primals_26, primals_22, primals_401, primals_25, primals_402, primals_19, primals_20, primals_403, primals_32, primals_408, primals_404, primals_31, primals_405, primals_34, primals_27, relu__default_102, primals_409, primals_410, primals_396, convolution_default_102, cat_default_52, primals_33, primals_397, primals_30, primals_18, primals_393, primals_21, primals_392, relu__default_12, relu__default_31, relu__default_5, convolution_default_5, convolution_default_32, relu__default_6, cat_default_3, relu__default_32, convolution_default_108, cat_default_6, cat_default_16, primals_683, primals_684, primals_685, primals_686, primals_687, primals_690, convolution_default_39, primals_691, primals_692, relu__default_40, relu__default_39, primals_695, primals_696, primals_697, cat_default_21, primals_698, primals_699, primals_555, primals_558, primals_559, primals_560, primals_563, primals_564, primals_565, primals_566, primals_567, primals_570, primals_571, primals_572, primals_575, relu__default_19, relu__default_78, convolution_default_26, relu__default_26, relu__default_116, convolution_default_116, cat_default_14, relu__default_79, cat_default_10, relu__default_20, convolution_default_79, relu__default_27, convolution_default_20, cat_default_41, relu__default_115, cat_default_40, convolution_default_96, primals_426, primals_425, relu__default_108, primals_421, primals_430, relu__default_96, primals_417, primals_416, relu__default_97, primals_422, primals_415, primals_420, primals_427, primals_413, relu__default_98, primals_414, primals_431, convolution_default_98, cat_default_50, primals_702, relu__default_52, relu__default_45, convolution_default_45, primals_703, relu__default_46, primals_704, primals_707, primals_708, primals_709, relu__default_53, primals_710, primals_711, convolution_default_53, primals_714, primals_715, relu__default_54, primals_716, relu__default_47, cat_default_28, primals_719, cat_default_24, primals_720, convolution_default_47, primals_721, primals_576, primals_577, primals_578, primals_579, primals_582, primals_583, primals_584, primals_587, primals_588, primals_589, primals_590, primals_591, cat_default_7, convolution_default_13, primals_594, primals_595, convolution_default, primals_596, primals_456, relu__default_59, convolution_default_59, relu__default_103, relu__default_60, primals_462, primals_458, primals_469, primals_457, relu__default_104, primals_464, primals_459, convolution_default_104, cat_default_53, primals_452, primals_455, primals_463, cat_default_31, primals_468, convolution_default_87, relu__default_105, convolution_default_61, primals_471, relu__default_61, primals_470, cat_default_54, primals_467]
        
