
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/timm_efficientnet/timm_efficientnet_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339, primals_340, primals_341, primals_342, primals_343, primals_344, primals_345, primals_346, primals_347, primals_348, primals_349, primals_350, primals_351, primals_352, primals_353, primals_354, primals_355, primals_356, primals_357, primals_358, primals_359, primals_360, primals_361):
        convolution_default = torch.ops.aten.convolution.default(primals_361, primals_360, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_351, primals_347, primals_349, primals_350, False, 0.1, 1e-05);  primals_347 = None
        getitem = native_batch_norm_default[0];  native_batch_norm_default = None
        silu__default = torch.ops.aten.silu_.default(getitem)
        convolution_default_1 = torch.ops.aten.convolution.default(silu__default, primals_11, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_5, primals_1, primals_3, primals_4, False, 0.1, 1e-05);  primals_1 = None
        getitem_3 = native_batch_norm_default_1[0];  native_batch_norm_default_1 = None
        silu__default_1 = torch.ops.aten.silu_.default(getitem_3)
        mean_dim = torch.ops.aten.mean.dim(silu__default_1, [2, 3], True)
        convolution_default_2 = torch.ops.aten.convolution.default(mean_dim, primals_16, primals_15, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_15 = None
        silu__default_2 = torch.ops.aten.silu_.default(convolution_default_2)
        convolution_default_3 = torch.ops.aten.convolution.default(silu__default_2, primals_14, primals_13, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_13 = None
        sigmoid_default = torch.ops.aten.sigmoid.default(convolution_default_3);  convolution_default_3 = None
        mul_tensor = torch.ops.aten.mul.Tensor(silu__default_1, sigmoid_default)
        convolution_default_4 = torch.ops.aten.convolution.default(mul_tensor, primals_12, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_10, primals_6, primals_8, primals_9, False, 0.1, 1e-05);  primals_6 = None
        getitem_6 = native_batch_norm_default_2[0];  native_batch_norm_default_2 = None
        convolution_default_5 = torch.ops.aten.convolution.default(getitem_6, primals_33, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_21, primals_17, primals_19, primals_20, False, 0.1, 1e-05);  primals_17 = None
        getitem_9 = native_batch_norm_default_3[0];  native_batch_norm_default_3 = None
        silu__default_3 = torch.ops.aten.silu_.default(getitem_9)
        convolution_default_6 = torch.ops.aten.convolution.default(silu__default_3, primals_32, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 96)
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_26, primals_22, primals_24, primals_25, False, 0.1, 1e-05);  primals_22 = None
        getitem_12 = native_batch_norm_default_4[0];  native_batch_norm_default_4 = None
        silu__default_4 = torch.ops.aten.silu_.default(getitem_12)
        mean_dim_1 = torch.ops.aten.mean.dim(silu__default_4, [2, 3], True)
        convolution_default_7 = torch.ops.aten.convolution.default(mean_dim_1, primals_38, primals_37, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_37 = None
        silu__default_5 = torch.ops.aten.silu_.default(convolution_default_7)
        convolution_default_8 = torch.ops.aten.convolution.default(silu__default_5, primals_36, primals_35, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_35 = None
        sigmoid_default_1 = torch.ops.aten.sigmoid.default(convolution_default_8);  convolution_default_8 = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(silu__default_4, sigmoid_default_1)
        convolution_default_9 = torch.ops.aten.convolution.default(mul_tensor_1, primals_34, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_31, primals_27, primals_29, primals_30, False, 0.1, 1e-05);  primals_27 = None
        getitem_15 = native_batch_norm_default_5[0];  native_batch_norm_default_5 = None
        convolution_default_10 = torch.ops.aten.convolution.default(getitem_15, primals_55, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_43, primals_39, primals_41, primals_42, False, 0.1, 1e-05);  primals_39 = None
        getitem_18 = native_batch_norm_default_6[0];  native_batch_norm_default_6 = None
        silu__default_6 = torch.ops.aten.silu_.default(getitem_18)
        convolution_default_11 = torch.ops.aten.convolution.default(silu__default_6, primals_54, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 144)
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_48, primals_44, primals_46, primals_47, False, 0.1, 1e-05);  primals_44 = None
        getitem_21 = native_batch_norm_default_7[0];  native_batch_norm_default_7 = None
        silu__default_7 = torch.ops.aten.silu_.default(getitem_21)
        mean_dim_2 = torch.ops.aten.mean.dim(silu__default_7, [2, 3], True)
        convolution_default_12 = torch.ops.aten.convolution.default(mean_dim_2, primals_60, primals_59, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_59 = None
        silu__default_8 = torch.ops.aten.silu_.default(convolution_default_12)
        convolution_default_13 = torch.ops.aten.convolution.default(silu__default_8, primals_58, primals_57, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_57 = None
        sigmoid_default_2 = torch.ops.aten.sigmoid.default(convolution_default_13);  convolution_default_13 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(silu__default_7, sigmoid_default_2)
        convolution_default_14 = torch.ops.aten.convolution.default(mul_tensor_2, primals_56, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_53, primals_49, primals_51, primals_52, False, 0.1, 1e-05);  primals_49 = None
        getitem_24 = native_batch_norm_default_8[0];  native_batch_norm_default_8 = None
        add__tensor = torch.ops.aten.add_.Tensor(getitem_24, getitem_15);  getitem_24 = None
        convolution_default_15 = torch.ops.aten.convolution.default(add__tensor, primals_77, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_65, primals_61, primals_63, primals_64, False, 0.1, 1e-05);  primals_61 = None
        getitem_27 = native_batch_norm_default_9[0];  native_batch_norm_default_9 = None
        silu__default_9 = torch.ops.aten.silu_.default(getitem_27)
        convolution_default_16 = torch.ops.aten.convolution.default(silu__default_9, primals_76, None, [2, 2], [2, 2], [1, 1], False, [0, 0], 144)
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_70, primals_66, primals_68, primals_69, False, 0.1, 1e-05);  primals_66 = None
        getitem_30 = native_batch_norm_default_10[0];  native_batch_norm_default_10 = None
        silu__default_10 = torch.ops.aten.silu_.default(getitem_30)
        mean_dim_3 = torch.ops.aten.mean.dim(silu__default_10, [2, 3], True)
        convolution_default_17 = torch.ops.aten.convolution.default(mean_dim_3, primals_82, primals_81, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_81 = None
        silu__default_11 = torch.ops.aten.silu_.default(convolution_default_17)
        convolution_default_18 = torch.ops.aten.convolution.default(silu__default_11, primals_80, primals_79, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_79 = None
        sigmoid_default_3 = torch.ops.aten.sigmoid.default(convolution_default_18);  convolution_default_18 = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(silu__default_10, sigmoid_default_3)
        convolution_default_19 = torch.ops.aten.convolution.default(mul_tensor_3, primals_78, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_75, primals_71, primals_73, primals_74, False, 0.1, 1e-05);  primals_71 = None
        getitem_33 = native_batch_norm_default_11[0];  native_batch_norm_default_11 = None
        convolution_default_20 = torch.ops.aten.convolution.default(getitem_33, primals_99, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_87, primals_83, primals_85, primals_86, False, 0.1, 1e-05);  primals_83 = None
        getitem_36 = native_batch_norm_default_12[0];  native_batch_norm_default_12 = None
        silu__default_12 = torch.ops.aten.silu_.default(getitem_36)
        convolution_default_21 = torch.ops.aten.convolution.default(silu__default_12, primals_98, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 240)
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_92, primals_88, primals_90, primals_91, False, 0.1, 1e-05);  primals_88 = None
        getitem_39 = native_batch_norm_default_13[0];  native_batch_norm_default_13 = None
        silu__default_13 = torch.ops.aten.silu_.default(getitem_39)
        mean_dim_4 = torch.ops.aten.mean.dim(silu__default_13, [2, 3], True)
        convolution_default_22 = torch.ops.aten.convolution.default(mean_dim_4, primals_104, primals_103, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_103 = None
        silu__default_14 = torch.ops.aten.silu_.default(convolution_default_22)
        convolution_default_23 = torch.ops.aten.convolution.default(silu__default_14, primals_102, primals_101, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_101 = None
        sigmoid_default_4 = torch.ops.aten.sigmoid.default(convolution_default_23);  convolution_default_23 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(silu__default_13, sigmoid_default_4)
        convolution_default_24 = torch.ops.aten.convolution.default(mul_tensor_4, primals_100, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_97, primals_93, primals_95, primals_96, False, 0.1, 1e-05);  primals_93 = None
        getitem_42 = native_batch_norm_default_14[0];  native_batch_norm_default_14 = None
        add__tensor_1 = torch.ops.aten.add_.Tensor(getitem_42, getitem_33);  getitem_42 = None
        convolution_default_25 = torch.ops.aten.convolution.default(add__tensor_1, primals_121, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_109, primals_105, primals_107, primals_108, False, 0.1, 1e-05);  primals_105 = None
        getitem_45 = native_batch_norm_default_15[0];  native_batch_norm_default_15 = None
        silu__default_15 = torch.ops.aten.silu_.default(getitem_45)
        convolution_default_26 = torch.ops.aten.convolution.default(silu__default_15, primals_120, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 240)
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_114, primals_110, primals_112, primals_113, False, 0.1, 1e-05);  primals_110 = None
        getitem_48 = native_batch_norm_default_16[0];  native_batch_norm_default_16 = None
        silu__default_16 = torch.ops.aten.silu_.default(getitem_48)
        mean_dim_5 = torch.ops.aten.mean.dim(silu__default_16, [2, 3], True)
        convolution_default_27 = torch.ops.aten.convolution.default(mean_dim_5, primals_126, primals_125, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_125 = None
        silu__default_17 = torch.ops.aten.silu_.default(convolution_default_27)
        convolution_default_28 = torch.ops.aten.convolution.default(silu__default_17, primals_124, primals_123, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_123 = None
        sigmoid_default_5 = torch.ops.aten.sigmoid.default(convolution_default_28);  convolution_default_28 = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(silu__default_16, sigmoid_default_5)
        convolution_default_29 = torch.ops.aten.convolution.default(mul_tensor_5, primals_122, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_119, primals_115, primals_117, primals_118, False, 0.1, 1e-05);  primals_115 = None
        getitem_51 = native_batch_norm_default_17[0];  native_batch_norm_default_17 = None
        convolution_default_30 = torch.ops.aten.convolution.default(getitem_51, primals_143, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_131, primals_127, primals_129, primals_130, False, 0.1, 1e-05);  primals_127 = None
        getitem_54 = native_batch_norm_default_18[0];  native_batch_norm_default_18 = None
        silu__default_18 = torch.ops.aten.silu_.default(getitem_54)
        convolution_default_31 = torch.ops.aten.convolution.default(silu__default_18, primals_142, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 480)
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_31, primals_136, primals_132, primals_134, primals_135, False, 0.1, 1e-05);  primals_132 = None
        getitem_57 = native_batch_norm_default_19[0];  native_batch_norm_default_19 = None
        silu__default_19 = torch.ops.aten.silu_.default(getitem_57)
        mean_dim_6 = torch.ops.aten.mean.dim(silu__default_19, [2, 3], True)
        convolution_default_32 = torch.ops.aten.convolution.default(mean_dim_6, primals_148, primals_147, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_147 = None
        silu__default_20 = torch.ops.aten.silu_.default(convolution_default_32)
        convolution_default_33 = torch.ops.aten.convolution.default(silu__default_20, primals_146, primals_145, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_145 = None
        sigmoid_default_6 = torch.ops.aten.sigmoid.default(convolution_default_33);  convolution_default_33 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(silu__default_19, sigmoid_default_6)
        convolution_default_34 = torch.ops.aten.convolution.default(mul_tensor_6, primals_144, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_141, primals_137, primals_139, primals_140, False, 0.1, 1e-05);  primals_137 = None
        getitem_60 = native_batch_norm_default_20[0];  native_batch_norm_default_20 = None
        add__tensor_2 = torch.ops.aten.add_.Tensor(getitem_60, getitem_51);  getitem_60 = None
        convolution_default_35 = torch.ops.aten.convolution.default(add__tensor_2, primals_165, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_153, primals_149, primals_151, primals_152, False, 0.1, 1e-05);  primals_149 = None
        getitem_63 = native_batch_norm_default_21[0];  native_batch_norm_default_21 = None
        silu__default_21 = torch.ops.aten.silu_.default(getitem_63)
        convolution_default_36 = torch.ops.aten.convolution.default(silu__default_21, primals_164, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 480)
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_158, primals_154, primals_156, primals_157, False, 0.1, 1e-05);  primals_154 = None
        getitem_66 = native_batch_norm_default_22[0];  native_batch_norm_default_22 = None
        silu__default_22 = torch.ops.aten.silu_.default(getitem_66)
        mean_dim_7 = torch.ops.aten.mean.dim(silu__default_22, [2, 3], True)
        convolution_default_37 = torch.ops.aten.convolution.default(mean_dim_7, primals_170, primals_169, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_169 = None
        silu__default_23 = torch.ops.aten.silu_.default(convolution_default_37)
        convolution_default_38 = torch.ops.aten.convolution.default(silu__default_23, primals_168, primals_167, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_167 = None
        sigmoid_default_7 = torch.ops.aten.sigmoid.default(convolution_default_38);  convolution_default_38 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(silu__default_22, sigmoid_default_7)
        convolution_default_39 = torch.ops.aten.convolution.default(mul_tensor_7, primals_166, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_39, primals_163, primals_159, primals_161, primals_162, False, 0.1, 1e-05);  primals_159 = None
        getitem_69 = native_batch_norm_default_23[0];  native_batch_norm_default_23 = None
        add__tensor_3 = torch.ops.aten.add_.Tensor(getitem_69, add__tensor_2);  getitem_69 = None
        convolution_default_40 = torch.ops.aten.convolution.default(add__tensor_3, primals_187, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_175, primals_171, primals_173, primals_174, False, 0.1, 1e-05);  primals_171 = None
        getitem_72 = native_batch_norm_default_24[0];  native_batch_norm_default_24 = None
        silu__default_24 = torch.ops.aten.silu_.default(getitem_72)
        convolution_default_41 = torch.ops.aten.convolution.default(silu__default_24, primals_186, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 480)
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_41, primals_180, primals_176, primals_178, primals_179, False, 0.1, 1e-05);  primals_176 = None
        getitem_75 = native_batch_norm_default_25[0];  native_batch_norm_default_25 = None
        silu__default_25 = torch.ops.aten.silu_.default(getitem_75)
        mean_dim_8 = torch.ops.aten.mean.dim(silu__default_25, [2, 3], True)
        convolution_default_42 = torch.ops.aten.convolution.default(mean_dim_8, primals_192, primals_191, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_191 = None
        silu__default_26 = torch.ops.aten.silu_.default(convolution_default_42)
        convolution_default_43 = torch.ops.aten.convolution.default(silu__default_26, primals_190, primals_189, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_189 = None
        sigmoid_default_8 = torch.ops.aten.sigmoid.default(convolution_default_43);  convolution_default_43 = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(silu__default_25, sigmoid_default_8)
        convolution_default_44 = torch.ops.aten.convolution.default(mul_tensor_8, primals_188, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_185, primals_181, primals_183, primals_184, False, 0.1, 1e-05);  primals_181 = None
        getitem_78 = native_batch_norm_default_26[0];  native_batch_norm_default_26 = None
        convolution_default_45 = torch.ops.aten.convolution.default(getitem_78, primals_209, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_45, primals_197, primals_193, primals_195, primals_196, False, 0.1, 1e-05);  primals_193 = None
        getitem_81 = native_batch_norm_default_27[0];  native_batch_norm_default_27 = None
        silu__default_27 = torch.ops.aten.silu_.default(getitem_81)
        convolution_default_46 = torch.ops.aten.convolution.default(silu__default_27, primals_208, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 672)
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_46, primals_202, primals_198, primals_200, primals_201, False, 0.1, 1e-05);  primals_198 = None
        getitem_84 = native_batch_norm_default_28[0];  native_batch_norm_default_28 = None
        silu__default_28 = torch.ops.aten.silu_.default(getitem_84)
        mean_dim_9 = torch.ops.aten.mean.dim(silu__default_28, [2, 3], True)
        convolution_default_47 = torch.ops.aten.convolution.default(mean_dim_9, primals_214, primals_213, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_213 = None
        silu__default_29 = torch.ops.aten.silu_.default(convolution_default_47)
        convolution_default_48 = torch.ops.aten.convolution.default(silu__default_29, primals_212, primals_211, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_211 = None
        sigmoid_default_9 = torch.ops.aten.sigmoid.default(convolution_default_48);  convolution_default_48 = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(silu__default_28, sigmoid_default_9)
        convolution_default_49 = torch.ops.aten.convolution.default(mul_tensor_9, primals_210, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_49, primals_207, primals_203, primals_205, primals_206, False, 0.1, 1e-05);  primals_203 = None
        getitem_87 = native_batch_norm_default_29[0];  native_batch_norm_default_29 = None
        add__tensor_4 = torch.ops.aten.add_.Tensor(getitem_87, getitem_78);  getitem_87 = None
        convolution_default_50 = torch.ops.aten.convolution.default(add__tensor_4, primals_231, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_50, primals_219, primals_215, primals_217, primals_218, False, 0.1, 1e-05);  primals_215 = None
        getitem_90 = native_batch_norm_default_30[0];  native_batch_norm_default_30 = None
        silu__default_30 = torch.ops.aten.silu_.default(getitem_90)
        convolution_default_51 = torch.ops.aten.convolution.default(silu__default_30, primals_230, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 672)
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_51, primals_224, primals_220, primals_222, primals_223, False, 0.1, 1e-05);  primals_220 = None
        getitem_93 = native_batch_norm_default_31[0];  native_batch_norm_default_31 = None
        silu__default_31 = torch.ops.aten.silu_.default(getitem_93)
        mean_dim_10 = torch.ops.aten.mean.dim(silu__default_31, [2, 3], True)
        convolution_default_52 = torch.ops.aten.convolution.default(mean_dim_10, primals_236, primals_235, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_235 = None
        silu__default_32 = torch.ops.aten.silu_.default(convolution_default_52)
        convolution_default_53 = torch.ops.aten.convolution.default(silu__default_32, primals_234, primals_233, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_233 = None
        sigmoid_default_10 = torch.ops.aten.sigmoid.default(convolution_default_53);  convolution_default_53 = None
        mul_tensor_10 = torch.ops.aten.mul.Tensor(silu__default_31, sigmoid_default_10)
        convolution_default_54 = torch.ops.aten.convolution.default(mul_tensor_10, primals_232, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_54, primals_229, primals_225, primals_227, primals_228, False, 0.1, 1e-05);  primals_225 = None
        getitem_96 = native_batch_norm_default_32[0];  native_batch_norm_default_32 = None
        add__tensor_5 = torch.ops.aten.add_.Tensor(getitem_96, add__tensor_4);  getitem_96 = None
        convolution_default_55 = torch.ops.aten.convolution.default(add__tensor_5, primals_253, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_55, primals_241, primals_237, primals_239, primals_240, False, 0.1, 1e-05);  primals_237 = None
        getitem_99 = native_batch_norm_default_33[0];  native_batch_norm_default_33 = None
        silu__default_33 = torch.ops.aten.silu_.default(getitem_99)
        convolution_default_56 = torch.ops.aten.convolution.default(silu__default_33, primals_252, None, [2, 2], [2, 2], [1, 1], False, [0, 0], 672)
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_56, primals_246, primals_242, primals_244, primals_245, False, 0.1, 1e-05);  primals_242 = None
        getitem_102 = native_batch_norm_default_34[0];  native_batch_norm_default_34 = None
        silu__default_34 = torch.ops.aten.silu_.default(getitem_102)
        mean_dim_11 = torch.ops.aten.mean.dim(silu__default_34, [2, 3], True)
        convolution_default_57 = torch.ops.aten.convolution.default(mean_dim_11, primals_258, primals_257, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_257 = None
        silu__default_35 = torch.ops.aten.silu_.default(convolution_default_57)
        convolution_default_58 = torch.ops.aten.convolution.default(silu__default_35, primals_256, primals_255, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_255 = None
        sigmoid_default_11 = torch.ops.aten.sigmoid.default(convolution_default_58);  convolution_default_58 = None
        mul_tensor_11 = torch.ops.aten.mul.Tensor(silu__default_34, sigmoid_default_11)
        convolution_default_59 = torch.ops.aten.convolution.default(mul_tensor_11, primals_254, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_59, primals_251, primals_247, primals_249, primals_250, False, 0.1, 1e-05);  primals_247 = None
        getitem_105 = native_batch_norm_default_35[0];  native_batch_norm_default_35 = None
        convolution_default_60 = torch.ops.aten.convolution.default(getitem_105, primals_275, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_60, primals_263, primals_259, primals_261, primals_262, False, 0.1, 1e-05);  primals_259 = None
        getitem_108 = native_batch_norm_default_36[0];  native_batch_norm_default_36 = None
        silu__default_36 = torch.ops.aten.silu_.default(getitem_108)
        convolution_default_61 = torch.ops.aten.convolution.default(silu__default_36, primals_274, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 1152)
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_61, primals_268, primals_264, primals_266, primals_267, False, 0.1, 1e-05);  primals_264 = None
        getitem_111 = native_batch_norm_default_37[0];  native_batch_norm_default_37 = None
        silu__default_37 = torch.ops.aten.silu_.default(getitem_111)
        mean_dim_12 = torch.ops.aten.mean.dim(silu__default_37, [2, 3], True)
        convolution_default_62 = torch.ops.aten.convolution.default(mean_dim_12, primals_280, primals_279, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_279 = None
        silu__default_38 = torch.ops.aten.silu_.default(convolution_default_62)
        convolution_default_63 = torch.ops.aten.convolution.default(silu__default_38, primals_278, primals_277, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_277 = None
        sigmoid_default_12 = torch.ops.aten.sigmoid.default(convolution_default_63);  convolution_default_63 = None
        mul_tensor_12 = torch.ops.aten.mul.Tensor(silu__default_37, sigmoid_default_12)
        convolution_default_64 = torch.ops.aten.convolution.default(mul_tensor_12, primals_276, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_64, primals_273, primals_269, primals_271, primals_272, False, 0.1, 1e-05);  primals_269 = None
        getitem_114 = native_batch_norm_default_38[0];  native_batch_norm_default_38 = None
        add__tensor_6 = torch.ops.aten.add_.Tensor(getitem_114, getitem_105);  getitem_114 = None
        convolution_default_65 = torch.ops.aten.convolution.default(add__tensor_6, primals_297, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_65, primals_285, primals_281, primals_283, primals_284, False, 0.1, 1e-05);  primals_281 = None
        getitem_117 = native_batch_norm_default_39[0];  native_batch_norm_default_39 = None
        silu__default_39 = torch.ops.aten.silu_.default(getitem_117)
        convolution_default_66 = torch.ops.aten.convolution.default(silu__default_39, primals_296, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 1152)
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_66, primals_290, primals_286, primals_288, primals_289, False, 0.1, 1e-05);  primals_286 = None
        getitem_120 = native_batch_norm_default_40[0];  native_batch_norm_default_40 = None
        silu__default_40 = torch.ops.aten.silu_.default(getitem_120)
        mean_dim_13 = torch.ops.aten.mean.dim(silu__default_40, [2, 3], True)
        convolution_default_67 = torch.ops.aten.convolution.default(mean_dim_13, primals_302, primals_301, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_301 = None
        silu__default_41 = torch.ops.aten.silu_.default(convolution_default_67)
        convolution_default_68 = torch.ops.aten.convolution.default(silu__default_41, primals_300, primals_299, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_299 = None
        sigmoid_default_13 = torch.ops.aten.sigmoid.default(convolution_default_68);  convolution_default_68 = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(silu__default_40, sigmoid_default_13)
        convolution_default_69 = torch.ops.aten.convolution.default(mul_tensor_13, primals_298, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_69, primals_295, primals_291, primals_293, primals_294, False, 0.1, 1e-05);  primals_291 = None
        getitem_123 = native_batch_norm_default_41[0];  native_batch_norm_default_41 = None
        add__tensor_7 = torch.ops.aten.add_.Tensor(getitem_123, add__tensor_6);  getitem_123 = None
        convolution_default_70 = torch.ops.aten.convolution.default(add__tensor_7, primals_319, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_70, primals_307, primals_303, primals_305, primals_306, False, 0.1, 1e-05);  primals_303 = None
        getitem_126 = native_batch_norm_default_42[0];  native_batch_norm_default_42 = None
        silu__default_42 = torch.ops.aten.silu_.default(getitem_126)
        convolution_default_71 = torch.ops.aten.convolution.default(silu__default_42, primals_318, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 1152)
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_71, primals_312, primals_308, primals_310, primals_311, False, 0.1, 1e-05);  primals_308 = None
        getitem_129 = native_batch_norm_default_43[0];  native_batch_norm_default_43 = None
        silu__default_43 = torch.ops.aten.silu_.default(getitem_129)
        mean_dim_14 = torch.ops.aten.mean.dim(silu__default_43, [2, 3], True)
        convolution_default_72 = torch.ops.aten.convolution.default(mean_dim_14, primals_324, primals_323, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_323 = None
        silu__default_44 = torch.ops.aten.silu_.default(convolution_default_72)
        convolution_default_73 = torch.ops.aten.convolution.default(silu__default_44, primals_322, primals_321, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_321 = None
        sigmoid_default_14 = torch.ops.aten.sigmoid.default(convolution_default_73);  convolution_default_73 = None
        mul_tensor_14 = torch.ops.aten.mul.Tensor(silu__default_43, sigmoid_default_14)
        convolution_default_74 = torch.ops.aten.convolution.default(mul_tensor_14, primals_320, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_74, primals_317, primals_313, primals_315, primals_316, False, 0.1, 1e-05);  primals_313 = None
        getitem_132 = native_batch_norm_default_44[0];  native_batch_norm_default_44 = None
        add__tensor_8 = torch.ops.aten.add_.Tensor(getitem_132, add__tensor_7);  getitem_132 = None
        convolution_default_75 = torch.ops.aten.convolution.default(add__tensor_8, primals_341, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_75, primals_329, primals_325, primals_327, primals_328, False, 0.1, 1e-05);  primals_325 = None
        getitem_135 = native_batch_norm_default_45[0];  native_batch_norm_default_45 = None
        silu__default_45 = torch.ops.aten.silu_.default(getitem_135)
        convolution_default_76 = torch.ops.aten.convolution.default(silu__default_45, primals_340, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1152)
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(convolution_default_76, primals_334, primals_330, primals_332, primals_333, False, 0.1, 1e-05);  primals_330 = None
        getitem_138 = native_batch_norm_default_46[0];  native_batch_norm_default_46 = None
        silu__default_46 = torch.ops.aten.silu_.default(getitem_138)
        mean_dim_15 = torch.ops.aten.mean.dim(silu__default_46, [2, 3], True)
        convolution_default_77 = torch.ops.aten.convolution.default(mean_dim_15, primals_346, primals_345, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_345 = None
        silu__default_47 = torch.ops.aten.silu_.default(convolution_default_77)
        convolution_default_78 = torch.ops.aten.convolution.default(silu__default_47, primals_344, primals_343, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_343 = None
        sigmoid_default_15 = torch.ops.aten.sigmoid.default(convolution_default_78);  convolution_default_78 = None
        mul_tensor_15 = torch.ops.aten.mul.Tensor(silu__default_46, sigmoid_default_15)
        convolution_default_79 = torch.ops.aten.convolution.default(mul_tensor_15, primals_342, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(convolution_default_79, primals_339, primals_335, primals_337, primals_338, False, 0.1, 1e-05);  primals_335 = None
        getitem_141 = native_batch_norm_default_47[0];  native_batch_norm_default_47 = None
        convolution_default_80 = torch.ops.aten.convolution.default(getitem_141, primals_359, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_80, primals_356, primals_352, primals_354, primals_355, False, 0.1, 1e-05);  primals_352 = None
        getitem_144 = native_batch_norm_default_48[0];  native_batch_norm_default_48 = None
        silu__default_48 = torch.ops.aten.silu_.default(getitem_144)
        mean_dim_16 = torch.ops.aten.mean.dim(silu__default_48, [-1, -2], True);  silu__default_48 = None
        view_default = torch.ops.aten.view.default(mean_dim_16, [32, 1280]);  mean_dim_16 = None
        t_default = torch.ops.aten.t.default(primals_358);  primals_358 = None
        addmm_default = torch.ops.aten.addmm.default(primals_357, view_default, t_default);  primals_357 = None
        return [addmm_default, convolution_default_25, primals_58, primals_275, silu__default_2, silu__default_3, convolution_default_57, primals_276, getitem_6, primals_56, mean_dim_11, mul_tensor, getitem_45, silu__default_13, convolution_default_32, primals_278, sigmoid_default, primals_55, convolution_default_4, mean_dim_1, getitem_144, primals_54, primals_53, primals_280, primals_52, silu__default_20, silu__default_34, convolution_default_22, convolution_default_35, convolution_default_5, primals_283, getitem_102, primals_46, sigmoid_default_6, primals_284, getitem_9, view_default, primals_47, silu__default_4, primals_51, primals_285, getitem_12, silu__default_15, primals_48, silu__default_14, add__tensor_2, mul_tensor_1, convolution_default_34, t_default, primals_288, convolution_default_7, primals_60, primals_289, sigmoid_default_4, convolution_default_26, primals_290, silu__default_35, primals_64, mul_tensor_4, getitem_48, mul_tensor_6, mean_dim_5, convolution_default_6, primals_63, convolution_default_24, mul_tensor_11, primals_293, add__tensor_1, primals_294, getitem, silu__default_5, primals_295, sigmoid_default_11, getitem_105, primals_212, primals_24, primals_151, primals_214, primals_152, convolution_default_36, getitem_63, convolution_default_60, primals_153, primals_157, convolution_default_59, primals_217, silu__default_21, primals_218, getitem_66, primals_219, primals_156, primals_158, getitem_108, primals_222, primals_223, primals_161, primals_224, primals_162, primals_163, primals_227, silu__default_36, primals_164, primals_228, primals_25, silu__default_22, primals_165, primals_229, mean_dim_7, primals_166, primals_190, primals_230, primals_231, primals_168, convolution_default_61, primals_232, convolution_default_37, primals_43, primals_26, primals_86, convolution_default_12, convolution_default_14, primals_87, silu__default_30, silu__default_43, mean_dim_2, getitem_27, convolution_default_15, primals_31, primals_30, add__tensor, mean_dim_10, primals_90, primals_91, primals_42, convolution_default_72, convolution_default_76, primals_38, primals_92, silu__default_7, getitem_21, silu__default_45, silu__default_44, silu__default_31, primals_95, getitem_135, primals_29, getitem_93, getitem_30, primals_96, primals_41, primals_97, primals_33, primals_98, mul_tensor_14, primals_32, convolution_default_52, getitem_138, primals_99, sigmoid_default_14, primals_100, silu__default_9, mean_dim_15, convolution_default_74, primals_102, silu__default_8, convolution_default_75, primals_36, mul_tensor_2, primals_34, primals_104, sigmoid_default_2, convolution_default_16, silu__default_32, mul_tensor_10, add__tensor_8, primals_254, primals_317, primals_318, convolution_default_70, silu__default, primals_256, primals_319, silu__default_26, primals_320, silu__default_40, getitem_126, mul_tensor_8, primals_258, getitem_78, primals_322, sigmoid_default_8, convolution_default_31, convolution_default_44, mean_dim, primals_261, primals_324, convolution_default_67, primals_262, silu__default_18, primals_263, primals_327, convolution_default_45, getitem_54, primals_328, silu__default_42, silu__default_41, primals_266, primals_329, silu__default_1, getitem_57, getitem_120, getitem_3, primals_267, primals_268, primals_332, mean_dim_6, sigmoid_default_13, convolution_default_71, getitem_129, convolution_default_2, primals_333, mul_tensor_13, primals_271, primals_334, getitem_81, convolution_default_69, mean_dim_14, silu__default_19, primals_272, primals_273, add__tensor_7, convolution_default_46, primals_274, primals_337, convolution_default_20, getitem_33, silu__default_16, primals_129, primals_192, silu__default_27, mean_dim_3, primals_130, primals_131, convolution_default_17, primals_195, getitem_36, silu__default_10, primals_196, convolution_default_27, primals_134, primals_197, mean_dim_9, primals_135, primals_136, silu__default_17, primals_200, primals_201, primals_139, primals_202, sigmoid_default_5, silu__default_28, primals_140, getitem_84, silu__default_12, primals_141, silu__default_11, primals_142, primals_205, primals_143, primals_206, convolution_default_29, convolution_default_47, primals_144, primals_207, convolution_default_21, primals_208, sigmoid_default_3, getitem_51, convolution_default_30, primals_146, primals_209, mul_tensor_5, mul_tensor_3, primals_210, getitem_39, primals_148, convolution_default_19, mean_dim_4, silu__default_29, primals_11, sigmoid_default_10, primals_65, primals_359, primals_4, primals_360, convolution_default_54, primals_361, primals_9, convolution_default_62, primals_68, mean_dim_12, getitem_99, primals_21, primals_10, primals_69, getitem_111, convolution_default_55, primals_70, silu__default_37, primals_19, add__tensor_5, primals_5, primals_8, primals_3, primals_73, primals_20, primals_74, primals_12, primals_75, primals_76, primals_14, primals_77, primals_78, convolution_default_64, primals_16, silu__default_38, convolution_default_56, primals_80, primals_82, sigmoid_default_12, silu__default_33, mul_tensor_12, primals_85, add__tensor_6, primals_296, silu__default_46, primals_234, primals_297, mul_tensor_9, primals_298, sigmoid_default_9, primals_236, convolution_default_49, convolution_default_77, silu__default_23, primals_300, primals_239, primals_302, sigmoid_default_7, silu__default_47, primals_240, convolution_default_39, add__tensor_4, convolution_default_50, primals_241, primals_305, sigmoid_default_15, primals_306, convolution_default_40, primals_244, primals_307, getitem_72, primals_245, add__tensor_3, convolution_default_80, getitem_90, primals_246, convolution_default_1, convolution_default_79, mul_tensor_7, primals_310, primals_311, getitem_141, convolution_default, primals_249, primals_312, convolution_default_51, mul_tensor_15, primals_250, primals_251, primals_252, primals_315, primals_253, primals_316, sigmoid_default_1, primals_107, primals_338, getitem_117, primals_170, primals_108, primals_339, convolution_default_65, convolution_default_9, primals_109, primals_340, convolution_default_41, getitem_75, primals_341, primals_173, silu__default_24, primals_342, primals_174, primals_112, primals_175, convolution_default_10, primals_113, primals_344, primals_180, primals_114, primals_346, primals_178, getitem_15, mean_dim_8, primals_179, primals_117, primals_118, primals_349, getitem_18, primals_119, primals_350, primals_120, primals_351, primals_187, silu__default_39, primals_183, primals_121, silu__default_25, primals_184, convolution_default_11, primals_122, primals_185, primals_354, primals_186, primals_124, primals_355, convolution_default_66, silu__default_6, convolution_default_42, primals_188, primals_356, mean_dim_13, primals_126]
        
