
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/pytorch_stargan/pytorch_stargan_joint_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, tangents_1):
        view_default = torch.ops.aten.view.default(primals_105, [16, 5, 1, 1]);  primals_105 = None
        repeat_default = torch.ops.aten.repeat.default(view_default, [1, 1, 128, 128]);  view_default = None
        cat_default = torch.ops.aten.cat.default([primals_104, repeat_default], 1);  primals_104 = repeat_default = None
        convolution_default = torch.ops.aten.convolution.default(cat_default, primals_1, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 1)
        repeat_default_1 = torch.ops.aten.repeat.default(primals_6, [16]);  primals_6 = None
        repeat_default_2 = torch.ops.aten.repeat.default(primals_2, [16]);  primals_2 = None
        repeat_default_3 = torch.ops.aten.repeat.default(primals_4, [16])
        repeat_default_4 = torch.ops.aten.repeat.default(primals_5, [16])
        view_default_1 = torch.ops.aten.view.default(convolution_default, [1, 1024, 128, 128]);  convolution_default = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(view_default_1, repeat_default_1, repeat_default_2, repeat_default_3, repeat_default_4, False, 0.1, 1e-05);  repeat_default_2 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        new_zeros_default = torch.ops.aten.new_zeros.default(view_default_1, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(view_default_1, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_2 = torch.ops.aten.new_zeros.default(view_default_1, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        alias_default = torch.ops.aten.alias.default(primals_4);  primals_4 = None
        view_default_2 = torch.ops.aten.view.default(repeat_default_3, [16, 64])
        mean_dim = torch.ops.aten.mean.dim(view_default_2, [0]);  view_default_2 = None
        copy__default = torch.ops.aten.copy_.default(alias_default, mean_dim);  alias_default = mean_dim = None
        alias_default_1 = torch.ops.aten.alias.default(primals_5);  primals_5 = None
        view_default_3 = torch.ops.aten.view.default(repeat_default_4, [16, 64])
        mean_dim_1 = torch.ops.aten.mean.dim(view_default_3, [0]);  view_default_3 = None
        copy__default_1 = torch.ops.aten.copy_.default(alias_default_1, mean_dim_1);  alias_default_1 = mean_dim_1 = None
        view_default_4 = torch.ops.aten.view.default(getitem, [16, 64, 128, 128]);  getitem = None
        relu__default = torch.ops.aten.relu_.default(view_default_4);  view_default_4 = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default, primals_80, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        repeat_default_5 = torch.ops.aten.repeat.default(primals_85, [16]);  primals_85 = None
        repeat_default_6 = torch.ops.aten.repeat.default(primals_81, [16]);  primals_81 = None
        repeat_default_7 = torch.ops.aten.repeat.default(primals_83, [16])
        repeat_default_8 = torch.ops.aten.repeat.default(primals_84, [16])
        view_default_5 = torch.ops.aten.view.default(convolution_default_1, [1, 2048, 64, 64]);  convolution_default_1 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(view_default_5, repeat_default_5, repeat_default_6, repeat_default_7, repeat_default_8, False, 0.1, 1e-05);  repeat_default_6 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(view_default_5, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(view_default_5, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_5 = torch.ops.aten.new_zeros.default(view_default_5, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        alias_default_2 = torch.ops.aten.alias.default(primals_83);  primals_83 = None
        view_default_6 = torch.ops.aten.view.default(repeat_default_7, [16, 128])
        mean_dim_2 = torch.ops.aten.mean.dim(view_default_6, [0]);  view_default_6 = None
        copy__default_2 = torch.ops.aten.copy_.default(alias_default_2, mean_dim_2);  alias_default_2 = mean_dim_2 = None
        alias_default_3 = torch.ops.aten.alias.default(primals_84);  primals_84 = None
        view_default_7 = torch.ops.aten.view.default(repeat_default_8, [16, 128])
        mean_dim_3 = torch.ops.aten.mean.dim(view_default_7, [0]);  view_default_7 = None
        copy__default_3 = torch.ops.aten.copy_.default(alias_default_3, mean_dim_3);  alias_default_3 = mean_dim_3 = None
        view_default_8 = torch.ops.aten.view.default(getitem_3, [16, 128, 64, 64]);  getitem_3 = None
        relu__default_1 = torch.ops.aten.relu_.default(view_default_8);  view_default_8 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_86, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        repeat_default_9 = torch.ops.aten.repeat.default(primals_91, [16]);  primals_91 = None
        repeat_default_10 = torch.ops.aten.repeat.default(primals_87, [16]);  primals_87 = None
        repeat_default_11 = torch.ops.aten.repeat.default(primals_89, [16])
        repeat_default_12 = torch.ops.aten.repeat.default(primals_90, [16])
        view_default_9 = torch.ops.aten.view.default(convolution_default_2, [1, 4096, 32, 32]);  convolution_default_2 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(view_default_9, repeat_default_9, repeat_default_10, repeat_default_11, repeat_default_12, False, 0.1, 1e-05);  repeat_default_10 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(view_default_9, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(view_default_9, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_8 = torch.ops.aten.new_zeros.default(view_default_9, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        alias_default_4 = torch.ops.aten.alias.default(primals_89);  primals_89 = None
        view_default_10 = torch.ops.aten.view.default(repeat_default_11, [16, 256])
        mean_dim_4 = torch.ops.aten.mean.dim(view_default_10, [0]);  view_default_10 = None
        copy__default_4 = torch.ops.aten.copy_.default(alias_default_4, mean_dim_4);  alias_default_4 = mean_dim_4 = None
        alias_default_5 = torch.ops.aten.alias.default(primals_90);  primals_90 = None
        view_default_11 = torch.ops.aten.view.default(repeat_default_12, [16, 256])
        mean_dim_5 = torch.ops.aten.mean.dim(view_default_11, [0]);  view_default_11 = None
        copy__default_5 = torch.ops.aten.copy_.default(alias_default_5, mean_dim_5);  alias_default_5 = mean_dim_5 = None
        view_default_12 = torch.ops.aten.view.default(getitem_6, [16, 256, 32, 32]);  getitem_6 = None
        relu__default_2 = torch.ops.aten.relu_.default(view_default_12);  view_default_12 = None
        convolution_default_3 = torch.ops.aten.convolution.default(relu__default_2, primals_92, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        repeat_default_13 = torch.ops.aten.repeat.default(primals_97, [16]);  primals_97 = None
        repeat_default_14 = torch.ops.aten.repeat.default(primals_93, [16]);  primals_93 = None
        repeat_default_15 = torch.ops.aten.repeat.default(primals_95, [16])
        repeat_default_16 = torch.ops.aten.repeat.default(primals_96, [16])
        view_default_13 = torch.ops.aten.view.default(convolution_default_3, [1, 4096, 32, 32]);  convolution_default_3 = None
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(view_default_13, repeat_default_13, repeat_default_14, repeat_default_15, repeat_default_16, False, 0.1, 1e-05);  repeat_default_14 = None
        getitem_9 = native_batch_norm_default_3[0]
        getitem_10 = native_batch_norm_default_3[1]
        getitem_11 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        new_zeros_default_9 = torch.ops.aten.new_zeros.default(view_default_13, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_10 = torch.ops.aten.new_zeros.default(view_default_13, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_11 = torch.ops.aten.new_zeros.default(view_default_13, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        alias_default_6 = torch.ops.aten.alias.default(primals_95);  primals_95 = None
        view_default_14 = torch.ops.aten.view.default(repeat_default_15, [16, 256])
        mean_dim_6 = torch.ops.aten.mean.dim(view_default_14, [0]);  view_default_14 = None
        copy__default_6 = torch.ops.aten.copy_.default(alias_default_6, mean_dim_6);  alias_default_6 = mean_dim_6 = None
        alias_default_7 = torch.ops.aten.alias.default(primals_96);  primals_96 = None
        view_default_15 = torch.ops.aten.view.default(repeat_default_16, [16, 256])
        mean_dim_7 = torch.ops.aten.mean.dim(view_default_15, [0]);  view_default_15 = None
        copy__default_7 = torch.ops.aten.copy_.default(alias_default_7, mean_dim_7);  alias_default_7 = mean_dim_7 = None
        view_default_16 = torch.ops.aten.view.default(getitem_9, [16, 256, 32, 32]);  getitem_9 = None
        relu__default_3 = torch.ops.aten.relu_.default(view_default_16);  view_default_16 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu__default_3, primals_98, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        repeat_default_17 = torch.ops.aten.repeat.default(primals_103, [16]);  primals_103 = None
        repeat_default_18 = torch.ops.aten.repeat.default(primals_99, [16]);  primals_99 = None
        repeat_default_19 = torch.ops.aten.repeat.default(primals_101, [16])
        repeat_default_20 = torch.ops.aten.repeat.default(primals_102, [16])
        view_default_17 = torch.ops.aten.view.default(convolution_default_4, [1, 4096, 32, 32]);  convolution_default_4 = None
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(view_default_17, repeat_default_17, repeat_default_18, repeat_default_19, repeat_default_20, False, 0.1, 1e-05);  repeat_default_18 = None
        getitem_12 = native_batch_norm_default_4[0]
        getitem_13 = native_batch_norm_default_4[1]
        getitem_14 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        new_zeros_default_12 = torch.ops.aten.new_zeros.default(view_default_17, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_13 = torch.ops.aten.new_zeros.default(view_default_17, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_14 = torch.ops.aten.new_zeros.default(view_default_17, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        alias_default_8 = torch.ops.aten.alias.default(primals_101);  primals_101 = None
        view_default_18 = torch.ops.aten.view.default(repeat_default_19, [16, 256])
        mean_dim_8 = torch.ops.aten.mean.dim(view_default_18, [0]);  view_default_18 = None
        copy__default_8 = torch.ops.aten.copy_.default(alias_default_8, mean_dim_8);  alias_default_8 = mean_dim_8 = None
        alias_default_9 = torch.ops.aten.alias.default(primals_102);  primals_102 = None
        view_default_19 = torch.ops.aten.view.default(repeat_default_20, [16, 256])
        mean_dim_9 = torch.ops.aten.mean.dim(view_default_19, [0]);  view_default_19 = None
        copy__default_9 = torch.ops.aten.copy_.default(alias_default_9, mean_dim_9);  alias_default_9 = mean_dim_9 = None
        view_default_20 = torch.ops.aten.view.default(getitem_12, [16, 256, 32, 32]);  getitem_12 = None
        add_tensor = torch.ops.aten.add.Tensor(relu__default_2, view_default_20);  view_default_20 = None
        convolution_default_5 = torch.ops.aten.convolution.default(add_tensor, primals_7, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        repeat_default_21 = torch.ops.aten.repeat.default(primals_12, [16]);  primals_12 = None
        repeat_default_22 = torch.ops.aten.repeat.default(primals_8, [16]);  primals_8 = None
        repeat_default_23 = torch.ops.aten.repeat.default(primals_10, [16])
        repeat_default_24 = torch.ops.aten.repeat.default(primals_11, [16])
        view_default_21 = torch.ops.aten.view.default(convolution_default_5, [1, 4096, 32, 32]);  convolution_default_5 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(view_default_21, repeat_default_21, repeat_default_22, repeat_default_23, repeat_default_24, False, 0.1, 1e-05);  repeat_default_22 = None
        getitem_15 = native_batch_norm_default_5[0]
        getitem_16 = native_batch_norm_default_5[1]
        getitem_17 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        new_zeros_default_15 = torch.ops.aten.new_zeros.default(view_default_21, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_16 = torch.ops.aten.new_zeros.default(view_default_21, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_17 = torch.ops.aten.new_zeros.default(view_default_21, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        alias_default_10 = torch.ops.aten.alias.default(primals_10);  primals_10 = None
        view_default_22 = torch.ops.aten.view.default(repeat_default_23, [16, 256])
        mean_dim_10 = torch.ops.aten.mean.dim(view_default_22, [0]);  view_default_22 = None
        copy__default_10 = torch.ops.aten.copy_.default(alias_default_10, mean_dim_10);  alias_default_10 = mean_dim_10 = None
        alias_default_11 = torch.ops.aten.alias.default(primals_11);  primals_11 = None
        view_default_23 = torch.ops.aten.view.default(repeat_default_24, [16, 256])
        mean_dim_11 = torch.ops.aten.mean.dim(view_default_23, [0]);  view_default_23 = None
        copy__default_11 = torch.ops.aten.copy_.default(alias_default_11, mean_dim_11);  alias_default_11 = mean_dim_11 = None
        view_default_24 = torch.ops.aten.view.default(getitem_15, [16, 256, 32, 32]);  getitem_15 = None
        relu__default_4 = torch.ops.aten.relu_.default(view_default_24);  view_default_24 = None
        convolution_default_6 = torch.ops.aten.convolution.default(relu__default_4, primals_13, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        repeat_default_25 = torch.ops.aten.repeat.default(primals_18, [16]);  primals_18 = None
        repeat_default_26 = torch.ops.aten.repeat.default(primals_14, [16]);  primals_14 = None
        repeat_default_27 = torch.ops.aten.repeat.default(primals_16, [16])
        repeat_default_28 = torch.ops.aten.repeat.default(primals_17, [16])
        view_default_25 = torch.ops.aten.view.default(convolution_default_6, [1, 4096, 32, 32]);  convolution_default_6 = None
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(view_default_25, repeat_default_25, repeat_default_26, repeat_default_27, repeat_default_28, False, 0.1, 1e-05);  repeat_default_26 = None
        getitem_18 = native_batch_norm_default_6[0]
        getitem_19 = native_batch_norm_default_6[1]
        getitem_20 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        new_zeros_default_18 = torch.ops.aten.new_zeros.default(view_default_25, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_19 = torch.ops.aten.new_zeros.default(view_default_25, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_20 = torch.ops.aten.new_zeros.default(view_default_25, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        alias_default_12 = torch.ops.aten.alias.default(primals_16);  primals_16 = None
        view_default_26 = torch.ops.aten.view.default(repeat_default_27, [16, 256])
        mean_dim_12 = torch.ops.aten.mean.dim(view_default_26, [0]);  view_default_26 = None
        copy__default_12 = torch.ops.aten.copy_.default(alias_default_12, mean_dim_12);  alias_default_12 = mean_dim_12 = None
        alias_default_13 = torch.ops.aten.alias.default(primals_17);  primals_17 = None
        view_default_27 = torch.ops.aten.view.default(repeat_default_28, [16, 256])
        mean_dim_13 = torch.ops.aten.mean.dim(view_default_27, [0]);  view_default_27 = None
        copy__default_13 = torch.ops.aten.copy_.default(alias_default_13, mean_dim_13);  alias_default_13 = mean_dim_13 = None
        view_default_28 = torch.ops.aten.view.default(getitem_18, [16, 256, 32, 32]);  getitem_18 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(add_tensor, view_default_28);  view_default_28 = None
        convolution_default_7 = torch.ops.aten.convolution.default(add_tensor_1, primals_19, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        repeat_default_29 = torch.ops.aten.repeat.default(primals_24, [16]);  primals_24 = None
        repeat_default_30 = torch.ops.aten.repeat.default(primals_20, [16]);  primals_20 = None
        repeat_default_31 = torch.ops.aten.repeat.default(primals_22, [16])
        repeat_default_32 = torch.ops.aten.repeat.default(primals_23, [16])
        view_default_29 = torch.ops.aten.view.default(convolution_default_7, [1, 4096, 32, 32]);  convolution_default_7 = None
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(view_default_29, repeat_default_29, repeat_default_30, repeat_default_31, repeat_default_32, False, 0.1, 1e-05);  repeat_default_30 = None
        getitem_21 = native_batch_norm_default_7[0]
        getitem_22 = native_batch_norm_default_7[1]
        getitem_23 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        new_zeros_default_21 = torch.ops.aten.new_zeros.default(view_default_29, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_22 = torch.ops.aten.new_zeros.default(view_default_29, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_23 = torch.ops.aten.new_zeros.default(view_default_29, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        alias_default_14 = torch.ops.aten.alias.default(primals_22);  primals_22 = None
        view_default_30 = torch.ops.aten.view.default(repeat_default_31, [16, 256])
        mean_dim_14 = torch.ops.aten.mean.dim(view_default_30, [0]);  view_default_30 = None
        copy__default_14 = torch.ops.aten.copy_.default(alias_default_14, mean_dim_14);  alias_default_14 = mean_dim_14 = None
        alias_default_15 = torch.ops.aten.alias.default(primals_23);  primals_23 = None
        view_default_31 = torch.ops.aten.view.default(repeat_default_32, [16, 256])
        mean_dim_15 = torch.ops.aten.mean.dim(view_default_31, [0]);  view_default_31 = None
        copy__default_15 = torch.ops.aten.copy_.default(alias_default_15, mean_dim_15);  alias_default_15 = mean_dim_15 = None
        view_default_32 = torch.ops.aten.view.default(getitem_21, [16, 256, 32, 32]);  getitem_21 = None
        relu__default_5 = torch.ops.aten.relu_.default(view_default_32);  view_default_32 = None
        convolution_default_8 = torch.ops.aten.convolution.default(relu__default_5, primals_25, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        repeat_default_33 = torch.ops.aten.repeat.default(primals_30, [16]);  primals_30 = None
        repeat_default_34 = torch.ops.aten.repeat.default(primals_26, [16]);  primals_26 = None
        repeat_default_35 = torch.ops.aten.repeat.default(primals_28, [16])
        repeat_default_36 = torch.ops.aten.repeat.default(primals_29, [16])
        view_default_33 = torch.ops.aten.view.default(convolution_default_8, [1, 4096, 32, 32]);  convolution_default_8 = None
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(view_default_33, repeat_default_33, repeat_default_34, repeat_default_35, repeat_default_36, False, 0.1, 1e-05);  repeat_default_34 = None
        getitem_24 = native_batch_norm_default_8[0]
        getitem_25 = native_batch_norm_default_8[1]
        getitem_26 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        new_zeros_default_24 = torch.ops.aten.new_zeros.default(view_default_33, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_25 = torch.ops.aten.new_zeros.default(view_default_33, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_26 = torch.ops.aten.new_zeros.default(view_default_33, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        alias_default_16 = torch.ops.aten.alias.default(primals_28);  primals_28 = None
        view_default_34 = torch.ops.aten.view.default(repeat_default_35, [16, 256])
        mean_dim_16 = torch.ops.aten.mean.dim(view_default_34, [0]);  view_default_34 = None
        copy__default_16 = torch.ops.aten.copy_.default(alias_default_16, mean_dim_16);  alias_default_16 = mean_dim_16 = None
        alias_default_17 = torch.ops.aten.alias.default(primals_29);  primals_29 = None
        view_default_35 = torch.ops.aten.view.default(repeat_default_36, [16, 256])
        mean_dim_17 = torch.ops.aten.mean.dim(view_default_35, [0]);  view_default_35 = None
        copy__default_17 = torch.ops.aten.copy_.default(alias_default_17, mean_dim_17);  alias_default_17 = mean_dim_17 = None
        view_default_36 = torch.ops.aten.view.default(getitem_24, [16, 256, 32, 32]);  getitem_24 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(add_tensor_1, view_default_36);  view_default_36 = None
        convolution_default_9 = torch.ops.aten.convolution.default(add_tensor_2, primals_31, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        repeat_default_37 = torch.ops.aten.repeat.default(primals_36, [16]);  primals_36 = None
        repeat_default_38 = torch.ops.aten.repeat.default(primals_32, [16]);  primals_32 = None
        repeat_default_39 = torch.ops.aten.repeat.default(primals_34, [16])
        repeat_default_40 = torch.ops.aten.repeat.default(primals_35, [16])
        view_default_37 = torch.ops.aten.view.default(convolution_default_9, [1, 4096, 32, 32]);  convolution_default_9 = None
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(view_default_37, repeat_default_37, repeat_default_38, repeat_default_39, repeat_default_40, False, 0.1, 1e-05);  repeat_default_38 = None
        getitem_27 = native_batch_norm_default_9[0]
        getitem_28 = native_batch_norm_default_9[1]
        getitem_29 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        new_zeros_default_27 = torch.ops.aten.new_zeros.default(view_default_37, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_28 = torch.ops.aten.new_zeros.default(view_default_37, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_29 = torch.ops.aten.new_zeros.default(view_default_37, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        alias_default_18 = torch.ops.aten.alias.default(primals_34);  primals_34 = None
        view_default_38 = torch.ops.aten.view.default(repeat_default_39, [16, 256])
        mean_dim_18 = torch.ops.aten.mean.dim(view_default_38, [0]);  view_default_38 = None
        copy__default_18 = torch.ops.aten.copy_.default(alias_default_18, mean_dim_18);  alias_default_18 = mean_dim_18 = None
        alias_default_19 = torch.ops.aten.alias.default(primals_35);  primals_35 = None
        view_default_39 = torch.ops.aten.view.default(repeat_default_40, [16, 256])
        mean_dim_19 = torch.ops.aten.mean.dim(view_default_39, [0]);  view_default_39 = None
        copy__default_19 = torch.ops.aten.copy_.default(alias_default_19, mean_dim_19);  alias_default_19 = mean_dim_19 = None
        view_default_40 = torch.ops.aten.view.default(getitem_27, [16, 256, 32, 32]);  getitem_27 = None
        relu__default_6 = torch.ops.aten.relu_.default(view_default_40);  view_default_40 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default_6, primals_37, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        repeat_default_41 = torch.ops.aten.repeat.default(primals_42, [16]);  primals_42 = None
        repeat_default_42 = torch.ops.aten.repeat.default(primals_38, [16]);  primals_38 = None
        repeat_default_43 = torch.ops.aten.repeat.default(primals_40, [16])
        repeat_default_44 = torch.ops.aten.repeat.default(primals_41, [16])
        view_default_41 = torch.ops.aten.view.default(convolution_default_10, [1, 4096, 32, 32]);  convolution_default_10 = None
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(view_default_41, repeat_default_41, repeat_default_42, repeat_default_43, repeat_default_44, False, 0.1, 1e-05);  repeat_default_42 = None
        getitem_30 = native_batch_norm_default_10[0]
        getitem_31 = native_batch_norm_default_10[1]
        getitem_32 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        new_zeros_default_30 = torch.ops.aten.new_zeros.default(view_default_41, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_31 = torch.ops.aten.new_zeros.default(view_default_41, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_32 = torch.ops.aten.new_zeros.default(view_default_41, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        alias_default_20 = torch.ops.aten.alias.default(primals_40);  primals_40 = None
        view_default_42 = torch.ops.aten.view.default(repeat_default_43, [16, 256])
        mean_dim_20 = torch.ops.aten.mean.dim(view_default_42, [0]);  view_default_42 = None
        copy__default_20 = torch.ops.aten.copy_.default(alias_default_20, mean_dim_20);  alias_default_20 = mean_dim_20 = None
        alias_default_21 = torch.ops.aten.alias.default(primals_41);  primals_41 = None
        view_default_43 = torch.ops.aten.view.default(repeat_default_44, [16, 256])
        mean_dim_21 = torch.ops.aten.mean.dim(view_default_43, [0]);  view_default_43 = None
        copy__default_21 = torch.ops.aten.copy_.default(alias_default_21, mean_dim_21);  alias_default_21 = mean_dim_21 = None
        view_default_44 = torch.ops.aten.view.default(getitem_30, [16, 256, 32, 32]);  getitem_30 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(add_tensor_2, view_default_44);  view_default_44 = None
        convolution_default_11 = torch.ops.aten.convolution.default(add_tensor_3, primals_43, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        repeat_default_45 = torch.ops.aten.repeat.default(primals_48, [16]);  primals_48 = None
        repeat_default_46 = torch.ops.aten.repeat.default(primals_44, [16]);  primals_44 = None
        repeat_default_47 = torch.ops.aten.repeat.default(primals_46, [16])
        repeat_default_48 = torch.ops.aten.repeat.default(primals_47, [16])
        view_default_45 = torch.ops.aten.view.default(convolution_default_11, [1, 4096, 32, 32]);  convolution_default_11 = None
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(view_default_45, repeat_default_45, repeat_default_46, repeat_default_47, repeat_default_48, False, 0.1, 1e-05);  repeat_default_46 = None
        getitem_33 = native_batch_norm_default_11[0]
        getitem_34 = native_batch_norm_default_11[1]
        getitem_35 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        new_zeros_default_33 = torch.ops.aten.new_zeros.default(view_default_45, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_34 = torch.ops.aten.new_zeros.default(view_default_45, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_35 = torch.ops.aten.new_zeros.default(view_default_45, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        alias_default_22 = torch.ops.aten.alias.default(primals_46);  primals_46 = None
        view_default_46 = torch.ops.aten.view.default(repeat_default_47, [16, 256])
        mean_dim_22 = torch.ops.aten.mean.dim(view_default_46, [0]);  view_default_46 = None
        copy__default_22 = torch.ops.aten.copy_.default(alias_default_22, mean_dim_22);  alias_default_22 = mean_dim_22 = None
        alias_default_23 = torch.ops.aten.alias.default(primals_47);  primals_47 = None
        view_default_47 = torch.ops.aten.view.default(repeat_default_48, [16, 256])
        mean_dim_23 = torch.ops.aten.mean.dim(view_default_47, [0]);  view_default_47 = None
        copy__default_23 = torch.ops.aten.copy_.default(alias_default_23, mean_dim_23);  alias_default_23 = mean_dim_23 = None
        view_default_48 = torch.ops.aten.view.default(getitem_33, [16, 256, 32, 32]);  getitem_33 = None
        relu__default_7 = torch.ops.aten.relu_.default(view_default_48);  view_default_48 = None
        convolution_default_12 = torch.ops.aten.convolution.default(relu__default_7, primals_49, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        repeat_default_49 = torch.ops.aten.repeat.default(primals_54, [16]);  primals_54 = None
        repeat_default_50 = torch.ops.aten.repeat.default(primals_50, [16]);  primals_50 = None
        repeat_default_51 = torch.ops.aten.repeat.default(primals_52, [16])
        repeat_default_52 = torch.ops.aten.repeat.default(primals_53, [16])
        view_default_49 = torch.ops.aten.view.default(convolution_default_12, [1, 4096, 32, 32]);  convolution_default_12 = None
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(view_default_49, repeat_default_49, repeat_default_50, repeat_default_51, repeat_default_52, False, 0.1, 1e-05);  repeat_default_50 = None
        getitem_36 = native_batch_norm_default_12[0]
        getitem_37 = native_batch_norm_default_12[1]
        getitem_38 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        new_zeros_default_36 = torch.ops.aten.new_zeros.default(view_default_49, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_37 = torch.ops.aten.new_zeros.default(view_default_49, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_38 = torch.ops.aten.new_zeros.default(view_default_49, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        alias_default_24 = torch.ops.aten.alias.default(primals_52);  primals_52 = None
        view_default_50 = torch.ops.aten.view.default(repeat_default_51, [16, 256])
        mean_dim_24 = torch.ops.aten.mean.dim(view_default_50, [0]);  view_default_50 = None
        copy__default_24 = torch.ops.aten.copy_.default(alias_default_24, mean_dim_24);  alias_default_24 = mean_dim_24 = None
        alias_default_25 = torch.ops.aten.alias.default(primals_53);  primals_53 = None
        view_default_51 = torch.ops.aten.view.default(repeat_default_52, [16, 256])
        mean_dim_25 = torch.ops.aten.mean.dim(view_default_51, [0]);  view_default_51 = None
        copy__default_25 = torch.ops.aten.copy_.default(alias_default_25, mean_dim_25);  alias_default_25 = mean_dim_25 = None
        view_default_52 = torch.ops.aten.view.default(getitem_36, [16, 256, 32, 32]);  getitem_36 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(add_tensor_3, view_default_52);  view_default_52 = None
        convolution_default_13 = torch.ops.aten.convolution.default(add_tensor_4, primals_55, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        repeat_default_53 = torch.ops.aten.repeat.default(primals_60, [16]);  primals_60 = None
        repeat_default_54 = torch.ops.aten.repeat.default(primals_56, [16]);  primals_56 = None
        repeat_default_55 = torch.ops.aten.repeat.default(primals_58, [16])
        repeat_default_56 = torch.ops.aten.repeat.default(primals_59, [16])
        view_default_53 = torch.ops.aten.view.default(convolution_default_13, [1, 4096, 32, 32]);  convolution_default_13 = None
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(view_default_53, repeat_default_53, repeat_default_54, repeat_default_55, repeat_default_56, False, 0.1, 1e-05);  repeat_default_54 = None
        getitem_39 = native_batch_norm_default_13[0]
        getitem_40 = native_batch_norm_default_13[1]
        getitem_41 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        new_zeros_default_39 = torch.ops.aten.new_zeros.default(view_default_53, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_40 = torch.ops.aten.new_zeros.default(view_default_53, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_41 = torch.ops.aten.new_zeros.default(view_default_53, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        alias_default_26 = torch.ops.aten.alias.default(primals_58);  primals_58 = None
        view_default_54 = torch.ops.aten.view.default(repeat_default_55, [16, 256])
        mean_dim_26 = torch.ops.aten.mean.dim(view_default_54, [0]);  view_default_54 = None
        copy__default_26 = torch.ops.aten.copy_.default(alias_default_26, mean_dim_26);  alias_default_26 = mean_dim_26 = None
        alias_default_27 = torch.ops.aten.alias.default(primals_59);  primals_59 = None
        view_default_55 = torch.ops.aten.view.default(repeat_default_56, [16, 256])
        mean_dim_27 = torch.ops.aten.mean.dim(view_default_55, [0]);  view_default_55 = None
        copy__default_27 = torch.ops.aten.copy_.default(alias_default_27, mean_dim_27);  alias_default_27 = mean_dim_27 = None
        view_default_56 = torch.ops.aten.view.default(getitem_39, [16, 256, 32, 32]);  getitem_39 = None
        relu__default_8 = torch.ops.aten.relu_.default(view_default_56);  view_default_56 = None
        convolution_default_14 = torch.ops.aten.convolution.default(relu__default_8, primals_61, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        repeat_default_57 = torch.ops.aten.repeat.default(primals_66, [16]);  primals_66 = None
        repeat_default_58 = torch.ops.aten.repeat.default(primals_62, [16]);  primals_62 = None
        repeat_default_59 = torch.ops.aten.repeat.default(primals_64, [16])
        repeat_default_60 = torch.ops.aten.repeat.default(primals_65, [16])
        view_default_57 = torch.ops.aten.view.default(convolution_default_14, [1, 4096, 32, 32]);  convolution_default_14 = None
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(view_default_57, repeat_default_57, repeat_default_58, repeat_default_59, repeat_default_60, False, 0.1, 1e-05);  repeat_default_58 = None
        getitem_42 = native_batch_norm_default_14[0]
        getitem_43 = native_batch_norm_default_14[1]
        getitem_44 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        new_zeros_default_42 = torch.ops.aten.new_zeros.default(view_default_57, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_43 = torch.ops.aten.new_zeros.default(view_default_57, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_44 = torch.ops.aten.new_zeros.default(view_default_57, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        alias_default_28 = torch.ops.aten.alias.default(primals_64);  primals_64 = None
        view_default_58 = torch.ops.aten.view.default(repeat_default_59, [16, 256])
        mean_dim_28 = torch.ops.aten.mean.dim(view_default_58, [0]);  view_default_58 = None
        copy__default_28 = torch.ops.aten.copy_.default(alias_default_28, mean_dim_28);  alias_default_28 = mean_dim_28 = None
        alias_default_29 = torch.ops.aten.alias.default(primals_65);  primals_65 = None
        view_default_59 = torch.ops.aten.view.default(repeat_default_60, [16, 256])
        mean_dim_29 = torch.ops.aten.mean.dim(view_default_59, [0]);  view_default_59 = None
        copy__default_29 = torch.ops.aten.copy_.default(alias_default_29, mean_dim_29);  alias_default_29 = mean_dim_29 = None
        view_default_60 = torch.ops.aten.view.default(getitem_42, [16, 256, 32, 32]);  getitem_42 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(add_tensor_4, view_default_60);  view_default_60 = None
        convolution_default_15 = torch.ops.aten.convolution.default(add_tensor_5, primals_67, None, [2, 2], [1, 1], [1, 1], True, [0, 0], 1)
        repeat_default_61 = torch.ops.aten.repeat.default(primals_72, [16]);  primals_72 = None
        repeat_default_62 = torch.ops.aten.repeat.default(primals_68, [16]);  primals_68 = None
        repeat_default_63 = torch.ops.aten.repeat.default(primals_70, [16])
        repeat_default_64 = torch.ops.aten.repeat.default(primals_71, [16])
        view_default_61 = torch.ops.aten.view.default(convolution_default_15, [1, 2048, 64, 64]);  convolution_default_15 = None
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(view_default_61, repeat_default_61, repeat_default_62, repeat_default_63, repeat_default_64, False, 0.1, 1e-05);  repeat_default_62 = None
        getitem_45 = native_batch_norm_default_15[0]
        getitem_46 = native_batch_norm_default_15[1]
        getitem_47 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        new_zeros_default_45 = torch.ops.aten.new_zeros.default(view_default_61, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_46 = torch.ops.aten.new_zeros.default(view_default_61, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_47 = torch.ops.aten.new_zeros.default(view_default_61, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        alias_default_30 = torch.ops.aten.alias.default(primals_70);  primals_70 = None
        view_default_62 = torch.ops.aten.view.default(repeat_default_63, [16, 128])
        mean_dim_30 = torch.ops.aten.mean.dim(view_default_62, [0]);  view_default_62 = None
        copy__default_30 = torch.ops.aten.copy_.default(alias_default_30, mean_dim_30);  alias_default_30 = mean_dim_30 = None
        alias_default_31 = torch.ops.aten.alias.default(primals_71);  primals_71 = None
        view_default_63 = torch.ops.aten.view.default(repeat_default_64, [16, 128])
        mean_dim_31 = torch.ops.aten.mean.dim(view_default_63, [0]);  view_default_63 = None
        copy__default_31 = torch.ops.aten.copy_.default(alias_default_31, mean_dim_31);  alias_default_31 = mean_dim_31 = None
        view_default_64 = torch.ops.aten.view.default(getitem_45, [16, 128, 64, 64]);  getitem_45 = None
        relu__default_9 = torch.ops.aten.relu_.default(view_default_64);  view_default_64 = None
        convolution_default_16 = torch.ops.aten.convolution.default(relu__default_9, primals_73, None, [2, 2], [1, 1], [1, 1], True, [0, 0], 1)
        repeat_default_65 = torch.ops.aten.repeat.default(primals_78, [16]);  primals_78 = None
        repeat_default_66 = torch.ops.aten.repeat.default(primals_74, [16]);  primals_74 = None
        repeat_default_67 = torch.ops.aten.repeat.default(primals_76, [16])
        repeat_default_68 = torch.ops.aten.repeat.default(primals_77, [16])
        view_default_65 = torch.ops.aten.view.default(convolution_default_16, [1, 1024, 128, 128]);  convolution_default_16 = None
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(view_default_65, repeat_default_65, repeat_default_66, repeat_default_67, repeat_default_68, False, 0.1, 1e-05);  repeat_default_66 = None
        getitem_48 = native_batch_norm_default_16[0]
        getitem_49 = native_batch_norm_default_16[1]
        getitem_50 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        new_zeros_default_48 = torch.ops.aten.new_zeros.default(view_default_65, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_49 = torch.ops.aten.new_zeros.default(view_default_65, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_50 = torch.ops.aten.new_zeros.default(view_default_65, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        alias_default_32 = torch.ops.aten.alias.default(primals_76);  primals_76 = None
        view_default_66 = torch.ops.aten.view.default(repeat_default_67, [16, 64])
        mean_dim_32 = torch.ops.aten.mean.dim(view_default_66, [0]);  view_default_66 = None
        copy__default_32 = torch.ops.aten.copy_.default(alias_default_32, mean_dim_32);  alias_default_32 = mean_dim_32 = None
        alias_default_33 = torch.ops.aten.alias.default(primals_77);  primals_77 = None
        view_default_67 = torch.ops.aten.view.default(repeat_default_68, [16, 64])
        mean_dim_33 = torch.ops.aten.mean.dim(view_default_67, [0]);  view_default_67 = None
        copy__default_33 = torch.ops.aten.copy_.default(alias_default_33, mean_dim_33);  alias_default_33 = mean_dim_33 = None
        view_default_68 = torch.ops.aten.view.default(getitem_48, [16, 64, 128, 128]);  getitem_48 = None
        relu__default_10 = torch.ops.aten.relu_.default(view_default_68);  view_default_68 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu__default_10, primals_79, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 1)
        tanh_default = torch.ops.aten.tanh.default(convolution_default_17);  convolution_default_17 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(tanh_default, tangents_1)
        to_dtype = torch.ops.aten.to.dtype(tangents_1, torch.float32);  tangents_1 = None
        to_dtype_1 = torch.ops.aten.to.dtype(tanh_default, torch.float32)
        mul_tensor = torch.ops.aten.mul.Tensor(to_dtype_1, to_dtype_1);  to_dtype_1 = None
        rsub_scalar = torch.ops.aten.rsub.Scalar(mul_tensor, 1);  mul_tensor = None
        conj_physical_default = torch.ops.aten.conj_physical.default(rsub_scalar);  rsub_scalar = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(to_dtype, conj_physical_default);  to_dtype = conj_physical_default = None
        to_dtype_2 = torch.ops.aten.to.dtype(mul_tensor_1, torch.float32);  mul_tensor_1 = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(to_dtype_2, relu__default_10, primals_79, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  to_dtype_2 = primals_79 = None
        getitem_51 = convolution_backward_default[0]
        getitem_52 = convolution_backward_default[1]
        getitem_53 = convolution_backward_default[2];  convolution_backward_default = None
        new_empty_default = torch.ops.aten.new_empty.default(getitem_51, [16777216])
        zero__default = torch.ops.aten.zero_.default(new_empty_default);  new_empty_default = None
        as_strided_default = torch.ops.aten.as_strided.default(zero__default, [16, 64, 128, 128], [1048576, 16384, 128, 1], 0)
        copy__default_34 = torch.ops.aten.copy_.default(as_strided_default, getitem_51);  as_strided_default = getitem_51 = None
        as_strided_default_1 = torch.ops.aten.as_strided.default(zero__default, [1, 1024, 128, 128], [16777216, 16384, 128, 1], 0);  zero__default = None
        new_empty_strided_default = torch.ops.aten.new_empty_strided.default(as_strided_default_1, [1, 1024, 128, 128], [16777216, 16384, 128, 1])
        copy__default_35 = torch.ops.aten.copy_.default(new_empty_strided_default, as_strided_default_1);  new_empty_strided_default = as_strided_default_1 = None
        as_strided_default_2 = torch.ops.aten.as_strided.default(copy__default_35, [16, 64, 128, 128], [1048576, 16384, 128, 1], 0)
        clone_default = torch.ops.aten.clone.default(as_strided_default_2, memory_format = torch.contiguous_format)
        to_dtype_3 = torch.ops.aten.to.dtype(clone_default, torch.float32);  clone_default = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_51 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_51, to_dtype_3);  le_scalar = new_zeros_default_51 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        copy__default_36 = torch.ops.aten.copy_.default(as_strided_default_2, to_dtype_5);  as_strided_default_2 = to_dtype_5 = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(copy__default_35, view_default_65, repeat_default_65, repeat_default_67, repeat_default_68, new_zeros_default_48, new_zeros_default_49, False, 1e-05, [True, True, True]);  copy__default_35 = view_default_65 = repeat_default_65 = repeat_default_67 = repeat_default_68 = new_zeros_default_48 = new_zeros_default_49 = None
        getitem_54 = native_batch_norm_backward_default[0]
        getitem_55 = native_batch_norm_backward_default[1]
        getitem_56 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        view_default_69 = torch.ops.aten.view.default(getitem_54, [16, 64, 128, 128]);  getitem_54 = None
        view_default_70 = torch.ops.aten.view.default(getitem_56, [16, 64]);  getitem_56 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(view_default_70, [0]);  view_default_70 = None
        view_default_71 = torch.ops.aten.view.default(getitem_55, [16, 64]);  getitem_55 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(view_default_71, [0]);  view_default_71 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(view_default_69, relu__default_9, primals_73, [0], [2, 2], [1, 1], [1, 1], True, [0, 0], 1, [True, True, False]);  view_default_69 = primals_73 = None
        getitem_57 = convolution_backward_default_1[0]
        getitem_58 = convolution_backward_default_1[1]
        getitem_59 = convolution_backward_default_1[2];  convolution_backward_default_1 = None
        new_empty_default_1 = torch.ops.aten.new_empty.default(getitem_57, [8388608])
        zero__default_1 = torch.ops.aten.zero_.default(new_empty_default_1);  new_empty_default_1 = None
        as_strided_default_3 = torch.ops.aten.as_strided.default(zero__default_1, [16, 128, 64, 64], [524288, 4096, 64, 1], 0)
        copy__default_37 = torch.ops.aten.copy_.default(as_strided_default_3, getitem_57);  as_strided_default_3 = getitem_57 = None
        as_strided_default_4 = torch.ops.aten.as_strided.default(zero__default_1, [1, 2048, 64, 64], [8388608, 4096, 64, 1], 0);  zero__default_1 = None
        new_empty_strided_default_1 = torch.ops.aten.new_empty_strided.default(as_strided_default_4, [1, 2048, 64, 64], [8388608, 4096, 64, 1])
        copy__default_38 = torch.ops.aten.copy_.default(new_empty_strided_default_1, as_strided_default_4);  new_empty_strided_default_1 = as_strided_default_4 = None
        as_strided_default_5 = torch.ops.aten.as_strided.default(copy__default_38, [16, 128, 64, 64], [524288, 4096, 64, 1], 0)
        clone_default_1 = torch.ops.aten.clone.default(as_strided_default_5, memory_format = torch.contiguous_format)
        to_dtype_6 = torch.ops.aten.to.dtype(clone_default_1, torch.float32);  clone_default_1 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_52 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_52, to_dtype_6);  le_scalar_1 = new_zeros_default_52 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        copy__default_39 = torch.ops.aten.copy_.default(as_strided_default_5, to_dtype_8);  as_strided_default_5 = to_dtype_8 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(copy__default_38, view_default_61, repeat_default_61, repeat_default_63, repeat_default_64, new_zeros_default_45, new_zeros_default_46, False, 1e-05, [True, True, True]);  copy__default_38 = view_default_61 = repeat_default_61 = repeat_default_63 = repeat_default_64 = new_zeros_default_45 = new_zeros_default_46 = None
        getitem_60 = native_batch_norm_backward_default_1[0]
        getitem_61 = native_batch_norm_backward_default_1[1]
        getitem_62 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        view_default_72 = torch.ops.aten.view.default(getitem_60, [16, 128, 64, 64]);  getitem_60 = None
        view_default_73 = torch.ops.aten.view.default(getitem_62, [16, 128]);  getitem_62 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(view_default_73, [0]);  view_default_73 = None
        view_default_74 = torch.ops.aten.view.default(getitem_61, [16, 128]);  getitem_61 = None
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(view_default_74, [0]);  view_default_74 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(view_default_72, add_tensor_5, primals_67, [0], [2, 2], [1, 1], [1, 1], True, [0, 0], 1, [True, True, False]);  view_default_72 = add_tensor_5 = primals_67 = None
        getitem_63 = convolution_backward_default_2[0]
        getitem_64 = convolution_backward_default_2[1]
        getitem_65 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        view_default_75 = torch.ops.aten.view.default(getitem_63, [1, 4096, 32, 32])
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(view_default_75, view_default_57, repeat_default_57, repeat_default_59, repeat_default_60, new_zeros_default_42, new_zeros_default_43, False, 1e-05, [True, True, True]);  view_default_75 = view_default_57 = repeat_default_57 = repeat_default_59 = repeat_default_60 = new_zeros_default_42 = new_zeros_default_43 = None
        getitem_66 = native_batch_norm_backward_default_2[0]
        getitem_67 = native_batch_norm_backward_default_2[1]
        getitem_68 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        view_default_76 = torch.ops.aten.view.default(getitem_66, [16, 256, 32, 32]);  getitem_66 = None
        view_default_77 = torch.ops.aten.view.default(getitem_68, [16, 256]);  getitem_68 = None
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(view_default_77, [0]);  view_default_77 = None
        view_default_78 = torch.ops.aten.view.default(getitem_67, [16, 256]);  getitem_67 = None
        sum_dim_int_list_5 = torch.ops.aten.sum.dim_IntList(view_default_78, [0]);  view_default_78 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(view_default_76, relu__default_8, primals_61, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_76 = primals_61 = None
        getitem_69 = convolution_backward_default_3[0]
        getitem_70 = convolution_backward_default_3[1]
        getitem_71 = convolution_backward_default_3[2];  convolution_backward_default_3 = None
        new_empty_default_2 = torch.ops.aten.new_empty.default(getitem_69, [4194304])
        zero__default_2 = torch.ops.aten.zero_.default(new_empty_default_2);  new_empty_default_2 = None
        as_strided_default_6 = torch.ops.aten.as_strided.default(zero__default_2, [16, 256, 32, 32], [262144, 1024, 32, 1], 0)
        copy__default_40 = torch.ops.aten.copy_.default(as_strided_default_6, getitem_69);  as_strided_default_6 = getitem_69 = None
        as_strided_default_7 = torch.ops.aten.as_strided.default(zero__default_2, [1, 4096, 32, 32], [4194304, 1024, 32, 1], 0);  zero__default_2 = None
        new_empty_strided_default_2 = torch.ops.aten.new_empty_strided.default(as_strided_default_7, [1, 4096, 32, 32], [4194304, 1024, 32, 1])
        copy__default_41 = torch.ops.aten.copy_.default(new_empty_strided_default_2, as_strided_default_7);  new_empty_strided_default_2 = as_strided_default_7 = None
        as_strided_default_8 = torch.ops.aten.as_strided.default(copy__default_41, [16, 256, 32, 32], [262144, 1024, 32, 1], 0)
        clone_default_2 = torch.ops.aten.clone.default(as_strided_default_8, memory_format = torch.contiguous_format)
        to_dtype_9 = torch.ops.aten.to.dtype(clone_default_2, torch.float32);  clone_default_2 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_53 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_53, to_dtype_9);  le_scalar_2 = new_zeros_default_53 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        copy__default_42 = torch.ops.aten.copy_.default(as_strided_default_8, to_dtype_11);  as_strided_default_8 = to_dtype_11 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(copy__default_41, view_default_53, repeat_default_53, repeat_default_55, repeat_default_56, new_zeros_default_39, new_zeros_default_40, False, 1e-05, [True, True, True]);  copy__default_41 = view_default_53 = repeat_default_53 = repeat_default_55 = repeat_default_56 = new_zeros_default_39 = new_zeros_default_40 = None
        getitem_72 = native_batch_norm_backward_default_3[0]
        getitem_73 = native_batch_norm_backward_default_3[1]
        getitem_74 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        view_default_79 = torch.ops.aten.view.default(getitem_72, [16, 256, 32, 32]);  getitem_72 = None
        view_default_80 = torch.ops.aten.view.default(getitem_74, [16, 256]);  getitem_74 = None
        sum_dim_int_list_6 = torch.ops.aten.sum.dim_IntList(view_default_80, [0]);  view_default_80 = None
        view_default_81 = torch.ops.aten.view.default(getitem_73, [16, 256]);  getitem_73 = None
        sum_dim_int_list_7 = torch.ops.aten.sum.dim_IntList(view_default_81, [0]);  view_default_81 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(view_default_79, add_tensor_4, primals_55, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_79 = add_tensor_4 = primals_55 = None
        getitem_75 = convolution_backward_default_4[0]
        getitem_76 = convolution_backward_default_4[1]
        getitem_77 = convolution_backward_default_4[2];  convolution_backward_default_4 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(getitem_63, getitem_75);  getitem_63 = getitem_75 = None
        view_default_82 = torch.ops.aten.view.default(add_tensor_6, [1, 4096, 32, 32])
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(view_default_82, view_default_49, repeat_default_49, repeat_default_51, repeat_default_52, new_zeros_default_36, new_zeros_default_37, False, 1e-05, [True, True, True]);  view_default_82 = view_default_49 = repeat_default_49 = repeat_default_51 = repeat_default_52 = new_zeros_default_36 = new_zeros_default_37 = None
        getitem_78 = native_batch_norm_backward_default_4[0]
        getitem_79 = native_batch_norm_backward_default_4[1]
        getitem_80 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        view_default_83 = torch.ops.aten.view.default(getitem_78, [16, 256, 32, 32]);  getitem_78 = None
        view_default_84 = torch.ops.aten.view.default(getitem_80, [16, 256]);  getitem_80 = None
        sum_dim_int_list_8 = torch.ops.aten.sum.dim_IntList(view_default_84, [0]);  view_default_84 = None
        view_default_85 = torch.ops.aten.view.default(getitem_79, [16, 256]);  getitem_79 = None
        sum_dim_int_list_9 = torch.ops.aten.sum.dim_IntList(view_default_85, [0]);  view_default_85 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(view_default_83, relu__default_7, primals_49, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_83 = primals_49 = None
        getitem_81 = convolution_backward_default_5[0]
        getitem_82 = convolution_backward_default_5[1]
        getitem_83 = convolution_backward_default_5[2];  convolution_backward_default_5 = None
        new_empty_default_3 = torch.ops.aten.new_empty.default(getitem_81, [4194304])
        zero__default_3 = torch.ops.aten.zero_.default(new_empty_default_3);  new_empty_default_3 = None
        as_strided_default_9 = torch.ops.aten.as_strided.default(zero__default_3, [16, 256, 32, 32], [262144, 1024, 32, 1], 0)
        copy__default_43 = torch.ops.aten.copy_.default(as_strided_default_9, getitem_81);  as_strided_default_9 = getitem_81 = None
        as_strided_default_10 = torch.ops.aten.as_strided.default(zero__default_3, [1, 4096, 32, 32], [4194304, 1024, 32, 1], 0);  zero__default_3 = None
        new_empty_strided_default_3 = torch.ops.aten.new_empty_strided.default(as_strided_default_10, [1, 4096, 32, 32], [4194304, 1024, 32, 1])
        copy__default_44 = torch.ops.aten.copy_.default(new_empty_strided_default_3, as_strided_default_10);  new_empty_strided_default_3 = as_strided_default_10 = None
        as_strided_default_11 = torch.ops.aten.as_strided.default(copy__default_44, [16, 256, 32, 32], [262144, 1024, 32, 1], 0)
        clone_default_3 = torch.ops.aten.clone.default(as_strided_default_11, memory_format = torch.contiguous_format)
        to_dtype_12 = torch.ops.aten.to.dtype(clone_default_3, torch.float32);  clone_default_3 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_54 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_54, to_dtype_12);  le_scalar_3 = new_zeros_default_54 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        copy__default_45 = torch.ops.aten.copy_.default(as_strided_default_11, to_dtype_14);  as_strided_default_11 = to_dtype_14 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(copy__default_44, view_default_45, repeat_default_45, repeat_default_47, repeat_default_48, new_zeros_default_33, new_zeros_default_34, False, 1e-05, [True, True, True]);  copy__default_44 = view_default_45 = repeat_default_45 = repeat_default_47 = repeat_default_48 = new_zeros_default_33 = new_zeros_default_34 = None
        getitem_84 = native_batch_norm_backward_default_5[0]
        getitem_85 = native_batch_norm_backward_default_5[1]
        getitem_86 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        view_default_86 = torch.ops.aten.view.default(getitem_84, [16, 256, 32, 32]);  getitem_84 = None
        view_default_87 = torch.ops.aten.view.default(getitem_86, [16, 256]);  getitem_86 = None
        sum_dim_int_list_10 = torch.ops.aten.sum.dim_IntList(view_default_87, [0]);  view_default_87 = None
        view_default_88 = torch.ops.aten.view.default(getitem_85, [16, 256]);  getitem_85 = None
        sum_dim_int_list_11 = torch.ops.aten.sum.dim_IntList(view_default_88, [0]);  view_default_88 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(view_default_86, add_tensor_3, primals_43, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_86 = add_tensor_3 = primals_43 = None
        getitem_87 = convolution_backward_default_6[0]
        getitem_88 = convolution_backward_default_6[1]
        getitem_89 = convolution_backward_default_6[2];  convolution_backward_default_6 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(add_tensor_6, getitem_87);  add_tensor_6 = getitem_87 = None
        view_default_89 = torch.ops.aten.view.default(add_tensor_7, [1, 4096, 32, 32])
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(view_default_89, view_default_41, repeat_default_41, repeat_default_43, repeat_default_44, new_zeros_default_30, new_zeros_default_31, False, 1e-05, [True, True, True]);  view_default_89 = view_default_41 = repeat_default_41 = repeat_default_43 = repeat_default_44 = new_zeros_default_30 = new_zeros_default_31 = None
        getitem_90 = native_batch_norm_backward_default_6[0]
        getitem_91 = native_batch_norm_backward_default_6[1]
        getitem_92 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        view_default_90 = torch.ops.aten.view.default(getitem_90, [16, 256, 32, 32]);  getitem_90 = None
        view_default_91 = torch.ops.aten.view.default(getitem_92, [16, 256]);  getitem_92 = None
        sum_dim_int_list_12 = torch.ops.aten.sum.dim_IntList(view_default_91, [0]);  view_default_91 = None
        view_default_92 = torch.ops.aten.view.default(getitem_91, [16, 256]);  getitem_91 = None
        sum_dim_int_list_13 = torch.ops.aten.sum.dim_IntList(view_default_92, [0]);  view_default_92 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(view_default_90, relu__default_6, primals_37, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_90 = primals_37 = None
        getitem_93 = convolution_backward_default_7[0]
        getitem_94 = convolution_backward_default_7[1]
        getitem_95 = convolution_backward_default_7[2];  convolution_backward_default_7 = None
        new_empty_default_4 = torch.ops.aten.new_empty.default(getitem_93, [4194304])
        zero__default_4 = torch.ops.aten.zero_.default(new_empty_default_4);  new_empty_default_4 = None
        as_strided_default_12 = torch.ops.aten.as_strided.default(zero__default_4, [16, 256, 32, 32], [262144, 1024, 32, 1], 0)
        copy__default_46 = torch.ops.aten.copy_.default(as_strided_default_12, getitem_93);  as_strided_default_12 = getitem_93 = None
        as_strided_default_13 = torch.ops.aten.as_strided.default(zero__default_4, [1, 4096, 32, 32], [4194304, 1024, 32, 1], 0);  zero__default_4 = None
        new_empty_strided_default_4 = torch.ops.aten.new_empty_strided.default(as_strided_default_13, [1, 4096, 32, 32], [4194304, 1024, 32, 1])
        copy__default_47 = torch.ops.aten.copy_.default(new_empty_strided_default_4, as_strided_default_13);  new_empty_strided_default_4 = as_strided_default_13 = None
        as_strided_default_14 = torch.ops.aten.as_strided.default(copy__default_47, [16, 256, 32, 32], [262144, 1024, 32, 1], 0)
        clone_default_4 = torch.ops.aten.clone.default(as_strided_default_14, memory_format = torch.contiguous_format)
        to_dtype_15 = torch.ops.aten.to.dtype(clone_default_4, torch.float32);  clone_default_4 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_55 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_55, to_dtype_15);  le_scalar_4 = new_zeros_default_55 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        copy__default_48 = torch.ops.aten.copy_.default(as_strided_default_14, to_dtype_17);  as_strided_default_14 = to_dtype_17 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(copy__default_47, view_default_37, repeat_default_37, repeat_default_39, repeat_default_40, new_zeros_default_27, new_zeros_default_28, False, 1e-05, [True, True, True]);  copy__default_47 = view_default_37 = repeat_default_37 = repeat_default_39 = repeat_default_40 = new_zeros_default_27 = new_zeros_default_28 = None
        getitem_96 = native_batch_norm_backward_default_7[0]
        getitem_97 = native_batch_norm_backward_default_7[1]
        getitem_98 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        view_default_93 = torch.ops.aten.view.default(getitem_96, [16, 256, 32, 32]);  getitem_96 = None
        view_default_94 = torch.ops.aten.view.default(getitem_98, [16, 256]);  getitem_98 = None
        sum_dim_int_list_14 = torch.ops.aten.sum.dim_IntList(view_default_94, [0]);  view_default_94 = None
        view_default_95 = torch.ops.aten.view.default(getitem_97, [16, 256]);  getitem_97 = None
        sum_dim_int_list_15 = torch.ops.aten.sum.dim_IntList(view_default_95, [0]);  view_default_95 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(view_default_93, add_tensor_2, primals_31, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_93 = add_tensor_2 = primals_31 = None
        getitem_99 = convolution_backward_default_8[0]
        getitem_100 = convolution_backward_default_8[1]
        getitem_101 = convolution_backward_default_8[2];  convolution_backward_default_8 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(add_tensor_7, getitem_99);  add_tensor_7 = getitem_99 = None
        view_default_96 = torch.ops.aten.view.default(add_tensor_8, [1, 4096, 32, 32])
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(view_default_96, view_default_33, repeat_default_33, repeat_default_35, repeat_default_36, new_zeros_default_24, new_zeros_default_25, False, 1e-05, [True, True, True]);  view_default_96 = view_default_33 = repeat_default_33 = repeat_default_35 = repeat_default_36 = new_zeros_default_24 = new_zeros_default_25 = None
        getitem_102 = native_batch_norm_backward_default_8[0]
        getitem_103 = native_batch_norm_backward_default_8[1]
        getitem_104 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        view_default_97 = torch.ops.aten.view.default(getitem_102, [16, 256, 32, 32]);  getitem_102 = None
        view_default_98 = torch.ops.aten.view.default(getitem_104, [16, 256]);  getitem_104 = None
        sum_dim_int_list_16 = torch.ops.aten.sum.dim_IntList(view_default_98, [0]);  view_default_98 = None
        view_default_99 = torch.ops.aten.view.default(getitem_103, [16, 256]);  getitem_103 = None
        sum_dim_int_list_17 = torch.ops.aten.sum.dim_IntList(view_default_99, [0]);  view_default_99 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(view_default_97, relu__default_5, primals_25, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_97 = primals_25 = None
        getitem_105 = convolution_backward_default_9[0]
        getitem_106 = convolution_backward_default_9[1]
        getitem_107 = convolution_backward_default_9[2];  convolution_backward_default_9 = None
        new_empty_default_5 = torch.ops.aten.new_empty.default(getitem_105, [4194304])
        zero__default_5 = torch.ops.aten.zero_.default(new_empty_default_5);  new_empty_default_5 = None
        as_strided_default_15 = torch.ops.aten.as_strided.default(zero__default_5, [16, 256, 32, 32], [262144, 1024, 32, 1], 0)
        copy__default_49 = torch.ops.aten.copy_.default(as_strided_default_15, getitem_105);  as_strided_default_15 = getitem_105 = None
        as_strided_default_16 = torch.ops.aten.as_strided.default(zero__default_5, [1, 4096, 32, 32], [4194304, 1024, 32, 1], 0);  zero__default_5 = None
        new_empty_strided_default_5 = torch.ops.aten.new_empty_strided.default(as_strided_default_16, [1, 4096, 32, 32], [4194304, 1024, 32, 1])
        copy__default_50 = torch.ops.aten.copy_.default(new_empty_strided_default_5, as_strided_default_16);  new_empty_strided_default_5 = as_strided_default_16 = None
        as_strided_default_17 = torch.ops.aten.as_strided.default(copy__default_50, [16, 256, 32, 32], [262144, 1024, 32, 1], 0)
        clone_default_5 = torch.ops.aten.clone.default(as_strided_default_17, memory_format = torch.contiguous_format)
        to_dtype_18 = torch.ops.aten.to.dtype(clone_default_5, torch.float32);  clone_default_5 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_56 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_56, to_dtype_18);  le_scalar_5 = new_zeros_default_56 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        copy__default_51 = torch.ops.aten.copy_.default(as_strided_default_17, to_dtype_20);  as_strided_default_17 = to_dtype_20 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(copy__default_50, view_default_29, repeat_default_29, repeat_default_31, repeat_default_32, new_zeros_default_21, new_zeros_default_22, False, 1e-05, [True, True, True]);  copy__default_50 = view_default_29 = repeat_default_29 = repeat_default_31 = repeat_default_32 = new_zeros_default_21 = new_zeros_default_22 = None
        getitem_108 = native_batch_norm_backward_default_9[0]
        getitem_109 = native_batch_norm_backward_default_9[1]
        getitem_110 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        view_default_100 = torch.ops.aten.view.default(getitem_108, [16, 256, 32, 32]);  getitem_108 = None
        view_default_101 = torch.ops.aten.view.default(getitem_110, [16, 256]);  getitem_110 = None
        sum_dim_int_list_18 = torch.ops.aten.sum.dim_IntList(view_default_101, [0]);  view_default_101 = None
        view_default_102 = torch.ops.aten.view.default(getitem_109, [16, 256]);  getitem_109 = None
        sum_dim_int_list_19 = torch.ops.aten.sum.dim_IntList(view_default_102, [0]);  view_default_102 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(view_default_100, add_tensor_1, primals_19, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_100 = add_tensor_1 = primals_19 = None
        getitem_111 = convolution_backward_default_10[0]
        getitem_112 = convolution_backward_default_10[1]
        getitem_113 = convolution_backward_default_10[2];  convolution_backward_default_10 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(add_tensor_8, getitem_111);  add_tensor_8 = getitem_111 = None
        view_default_103 = torch.ops.aten.view.default(add_tensor_9, [1, 4096, 32, 32])
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(view_default_103, view_default_25, repeat_default_25, repeat_default_27, repeat_default_28, new_zeros_default_18, new_zeros_default_19, False, 1e-05, [True, True, True]);  view_default_103 = view_default_25 = repeat_default_25 = repeat_default_27 = repeat_default_28 = new_zeros_default_18 = new_zeros_default_19 = None
        getitem_114 = native_batch_norm_backward_default_10[0]
        getitem_115 = native_batch_norm_backward_default_10[1]
        getitem_116 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        view_default_104 = torch.ops.aten.view.default(getitem_114, [16, 256, 32, 32]);  getitem_114 = None
        view_default_105 = torch.ops.aten.view.default(getitem_116, [16, 256]);  getitem_116 = None
        sum_dim_int_list_20 = torch.ops.aten.sum.dim_IntList(view_default_105, [0]);  view_default_105 = None
        view_default_106 = torch.ops.aten.view.default(getitem_115, [16, 256]);  getitem_115 = None
        sum_dim_int_list_21 = torch.ops.aten.sum.dim_IntList(view_default_106, [0]);  view_default_106 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(view_default_104, relu__default_4, primals_13, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_104 = primals_13 = None
        getitem_117 = convolution_backward_default_11[0]
        getitem_118 = convolution_backward_default_11[1]
        getitem_119 = convolution_backward_default_11[2];  convolution_backward_default_11 = None
        new_empty_default_6 = torch.ops.aten.new_empty.default(getitem_117, [4194304])
        zero__default_6 = torch.ops.aten.zero_.default(new_empty_default_6);  new_empty_default_6 = None
        as_strided_default_18 = torch.ops.aten.as_strided.default(zero__default_6, [16, 256, 32, 32], [262144, 1024, 32, 1], 0)
        copy__default_52 = torch.ops.aten.copy_.default(as_strided_default_18, getitem_117);  as_strided_default_18 = getitem_117 = None
        as_strided_default_19 = torch.ops.aten.as_strided.default(zero__default_6, [1, 4096, 32, 32], [4194304, 1024, 32, 1], 0);  zero__default_6 = None
        new_empty_strided_default_6 = torch.ops.aten.new_empty_strided.default(as_strided_default_19, [1, 4096, 32, 32], [4194304, 1024, 32, 1])
        copy__default_53 = torch.ops.aten.copy_.default(new_empty_strided_default_6, as_strided_default_19);  new_empty_strided_default_6 = as_strided_default_19 = None
        as_strided_default_20 = torch.ops.aten.as_strided.default(copy__default_53, [16, 256, 32, 32], [262144, 1024, 32, 1], 0)
        clone_default_6 = torch.ops.aten.clone.default(as_strided_default_20, memory_format = torch.contiguous_format)
        to_dtype_21 = torch.ops.aten.to.dtype(clone_default_6, torch.float32);  clone_default_6 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_57 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_57, to_dtype_21);  le_scalar_6 = new_zeros_default_57 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        copy__default_54 = torch.ops.aten.copy_.default(as_strided_default_20, to_dtype_23);  as_strided_default_20 = to_dtype_23 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(copy__default_53, view_default_21, repeat_default_21, repeat_default_23, repeat_default_24, new_zeros_default_15, new_zeros_default_16, False, 1e-05, [True, True, True]);  copy__default_53 = view_default_21 = repeat_default_21 = repeat_default_23 = repeat_default_24 = new_zeros_default_15 = new_zeros_default_16 = None
        getitem_120 = native_batch_norm_backward_default_11[0]
        getitem_121 = native_batch_norm_backward_default_11[1]
        getitem_122 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        view_default_107 = torch.ops.aten.view.default(getitem_120, [16, 256, 32, 32]);  getitem_120 = None
        view_default_108 = torch.ops.aten.view.default(getitem_122, [16, 256]);  getitem_122 = None
        sum_dim_int_list_22 = torch.ops.aten.sum.dim_IntList(view_default_108, [0]);  view_default_108 = None
        view_default_109 = torch.ops.aten.view.default(getitem_121, [16, 256]);  getitem_121 = None
        sum_dim_int_list_23 = torch.ops.aten.sum.dim_IntList(view_default_109, [0]);  view_default_109 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(view_default_107, add_tensor, primals_7, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_107 = add_tensor = primals_7 = None
        getitem_123 = convolution_backward_default_12[0]
        getitem_124 = convolution_backward_default_12[1]
        getitem_125 = convolution_backward_default_12[2];  convolution_backward_default_12 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(add_tensor_9, getitem_123);  add_tensor_9 = getitem_123 = None
        view_default_110 = torch.ops.aten.view.default(add_tensor_10, [1, 4096, 32, 32])
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(view_default_110, view_default_17, repeat_default_17, repeat_default_19, repeat_default_20, new_zeros_default_12, new_zeros_default_13, False, 1e-05, [True, True, True]);  view_default_110 = view_default_17 = repeat_default_17 = repeat_default_19 = repeat_default_20 = new_zeros_default_12 = new_zeros_default_13 = None
        getitem_126 = native_batch_norm_backward_default_12[0]
        getitem_127 = native_batch_norm_backward_default_12[1]
        getitem_128 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        view_default_111 = torch.ops.aten.view.default(getitem_126, [16, 256, 32, 32]);  getitem_126 = None
        view_default_112 = torch.ops.aten.view.default(getitem_128, [16, 256]);  getitem_128 = None
        sum_dim_int_list_24 = torch.ops.aten.sum.dim_IntList(view_default_112, [0]);  view_default_112 = None
        view_default_113 = torch.ops.aten.view.default(getitem_127, [16, 256]);  getitem_127 = None
        sum_dim_int_list_25 = torch.ops.aten.sum.dim_IntList(view_default_113, [0]);  view_default_113 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(view_default_111, relu__default_3, primals_98, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_111 = primals_98 = None
        getitem_129 = convolution_backward_default_13[0]
        getitem_130 = convolution_backward_default_13[1]
        getitem_131 = convolution_backward_default_13[2];  convolution_backward_default_13 = None
        new_empty_default_7 = torch.ops.aten.new_empty.default(getitem_129, [4194304])
        zero__default_7 = torch.ops.aten.zero_.default(new_empty_default_7);  new_empty_default_7 = None
        as_strided_default_21 = torch.ops.aten.as_strided.default(zero__default_7, [16, 256, 32, 32], [262144, 1024, 32, 1], 0)
        copy__default_55 = torch.ops.aten.copy_.default(as_strided_default_21, getitem_129);  as_strided_default_21 = getitem_129 = None
        as_strided_default_22 = torch.ops.aten.as_strided.default(zero__default_7, [1, 4096, 32, 32], [4194304, 1024, 32, 1], 0);  zero__default_7 = None
        new_empty_strided_default_7 = torch.ops.aten.new_empty_strided.default(as_strided_default_22, [1, 4096, 32, 32], [4194304, 1024, 32, 1])
        copy__default_56 = torch.ops.aten.copy_.default(new_empty_strided_default_7, as_strided_default_22);  new_empty_strided_default_7 = as_strided_default_22 = None
        as_strided_default_23 = torch.ops.aten.as_strided.default(copy__default_56, [16, 256, 32, 32], [262144, 1024, 32, 1], 0)
        clone_default_7 = torch.ops.aten.clone.default(as_strided_default_23, memory_format = torch.contiguous_format)
        to_dtype_24 = torch.ops.aten.to.dtype(clone_default_7, torch.float32);  clone_default_7 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_58 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_58, to_dtype_24);  le_scalar_7 = new_zeros_default_58 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        copy__default_57 = torch.ops.aten.copy_.default(as_strided_default_23, to_dtype_26);  as_strided_default_23 = to_dtype_26 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(copy__default_56, view_default_13, repeat_default_13, repeat_default_15, repeat_default_16, new_zeros_default_9, new_zeros_default_10, False, 1e-05, [True, True, True]);  copy__default_56 = view_default_13 = repeat_default_13 = repeat_default_15 = repeat_default_16 = new_zeros_default_9 = new_zeros_default_10 = None
        getitem_132 = native_batch_norm_backward_default_13[0]
        getitem_133 = native_batch_norm_backward_default_13[1]
        getitem_134 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        view_default_114 = torch.ops.aten.view.default(getitem_132, [16, 256, 32, 32]);  getitem_132 = None
        view_default_115 = torch.ops.aten.view.default(getitem_134, [16, 256]);  getitem_134 = None
        sum_dim_int_list_26 = torch.ops.aten.sum.dim_IntList(view_default_115, [0]);  view_default_115 = None
        view_default_116 = torch.ops.aten.view.default(getitem_133, [16, 256]);  getitem_133 = None
        sum_dim_int_list_27 = torch.ops.aten.sum.dim_IntList(view_default_116, [0]);  view_default_116 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(view_default_114, relu__default_2, primals_92, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_114 = primals_92 = None
        getitem_135 = convolution_backward_default_14[0]
        getitem_136 = convolution_backward_default_14[1]
        getitem_137 = convolution_backward_default_14[2];  convolution_backward_default_14 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(add_tensor_10, getitem_135);  add_tensor_10 = getitem_135 = None
        new_empty_default_8 = torch.ops.aten.new_empty.default(add_tensor_11, [4194304])
        zero__default_8 = torch.ops.aten.zero_.default(new_empty_default_8);  new_empty_default_8 = None
        as_strided_default_24 = torch.ops.aten.as_strided.default(zero__default_8, [16, 256, 32, 32], [262144, 1024, 32, 1], 0)
        copy__default_58 = torch.ops.aten.copy_.default(as_strided_default_24, add_tensor_11);  as_strided_default_24 = add_tensor_11 = None
        as_strided_default_25 = torch.ops.aten.as_strided.default(zero__default_8, [1, 4096, 32, 32], [4194304, 1024, 32, 1], 0);  zero__default_8 = None
        new_empty_strided_default_8 = torch.ops.aten.new_empty_strided.default(as_strided_default_25, [1, 4096, 32, 32], [4194304, 1024, 32, 1])
        copy__default_59 = torch.ops.aten.copy_.default(new_empty_strided_default_8, as_strided_default_25);  new_empty_strided_default_8 = as_strided_default_25 = None
        as_strided_default_26 = torch.ops.aten.as_strided.default(copy__default_59, [16, 256, 32, 32], [262144, 1024, 32, 1], 0)
        clone_default_8 = torch.ops.aten.clone.default(as_strided_default_26, memory_format = torch.contiguous_format)
        to_dtype_27 = torch.ops.aten.to.dtype(clone_default_8, torch.float32);  clone_default_8 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_59 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_59, to_dtype_27);  le_scalar_8 = new_zeros_default_59 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        copy__default_60 = torch.ops.aten.copy_.default(as_strided_default_26, to_dtype_29);  as_strided_default_26 = to_dtype_29 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(copy__default_59, view_default_9, repeat_default_9, repeat_default_11, repeat_default_12, new_zeros_default_6, new_zeros_default_7, False, 1e-05, [True, True, True]);  copy__default_59 = view_default_9 = repeat_default_9 = repeat_default_11 = repeat_default_12 = new_zeros_default_6 = new_zeros_default_7 = None
        getitem_138 = native_batch_norm_backward_default_14[0]
        getitem_139 = native_batch_norm_backward_default_14[1]
        getitem_140 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        view_default_117 = torch.ops.aten.view.default(getitem_138, [16, 256, 32, 32]);  getitem_138 = None
        view_default_118 = torch.ops.aten.view.default(getitem_140, [16, 256]);  getitem_140 = None
        sum_dim_int_list_28 = torch.ops.aten.sum.dim_IntList(view_default_118, [0]);  view_default_118 = None
        view_default_119 = torch.ops.aten.view.default(getitem_139, [16, 256]);  getitem_139 = None
        sum_dim_int_list_29 = torch.ops.aten.sum.dim_IntList(view_default_119, [0]);  view_default_119 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(view_default_117, relu__default_1, primals_86, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_117 = primals_86 = None
        getitem_141 = convolution_backward_default_15[0]
        getitem_142 = convolution_backward_default_15[1]
        getitem_143 = convolution_backward_default_15[2];  convolution_backward_default_15 = None
        new_empty_default_9 = torch.ops.aten.new_empty.default(getitem_141, [8388608])
        zero__default_9 = torch.ops.aten.zero_.default(new_empty_default_9);  new_empty_default_9 = None
        as_strided_default_27 = torch.ops.aten.as_strided.default(zero__default_9, [16, 128, 64, 64], [524288, 4096, 64, 1], 0)
        copy__default_61 = torch.ops.aten.copy_.default(as_strided_default_27, getitem_141);  as_strided_default_27 = getitem_141 = None
        as_strided_default_28 = torch.ops.aten.as_strided.default(zero__default_9, [1, 2048, 64, 64], [8388608, 4096, 64, 1], 0);  zero__default_9 = None
        new_empty_strided_default_9 = torch.ops.aten.new_empty_strided.default(as_strided_default_28, [1, 2048, 64, 64], [8388608, 4096, 64, 1])
        copy__default_62 = torch.ops.aten.copy_.default(new_empty_strided_default_9, as_strided_default_28);  new_empty_strided_default_9 = as_strided_default_28 = None
        as_strided_default_29 = torch.ops.aten.as_strided.default(copy__default_62, [16, 128, 64, 64], [524288, 4096, 64, 1], 0)
        clone_default_9 = torch.ops.aten.clone.default(as_strided_default_29, memory_format = torch.contiguous_format)
        to_dtype_30 = torch.ops.aten.to.dtype(clone_default_9, torch.float32);  clone_default_9 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_60 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_60, to_dtype_30);  le_scalar_9 = new_zeros_default_60 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        copy__default_63 = torch.ops.aten.copy_.default(as_strided_default_29, to_dtype_32);  as_strided_default_29 = to_dtype_32 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(copy__default_62, view_default_5, repeat_default_5, repeat_default_7, repeat_default_8, new_zeros_default_3, new_zeros_default_4, False, 1e-05, [True, True, True]);  copy__default_62 = view_default_5 = repeat_default_5 = repeat_default_7 = repeat_default_8 = new_zeros_default_3 = new_zeros_default_4 = None
        getitem_144 = native_batch_norm_backward_default_15[0]
        getitem_145 = native_batch_norm_backward_default_15[1]
        getitem_146 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        view_default_120 = torch.ops.aten.view.default(getitem_144, [16, 128, 64, 64]);  getitem_144 = None
        view_default_121 = torch.ops.aten.view.default(getitem_146, [16, 128]);  getitem_146 = None
        sum_dim_int_list_30 = torch.ops.aten.sum.dim_IntList(view_default_121, [0]);  view_default_121 = None
        view_default_122 = torch.ops.aten.view.default(getitem_145, [16, 128]);  getitem_145 = None
        sum_dim_int_list_31 = torch.ops.aten.sum.dim_IntList(view_default_122, [0]);  view_default_122 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(view_default_120, relu__default, primals_80, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_120 = primals_80 = None
        getitem_147 = convolution_backward_default_16[0]
        getitem_148 = convolution_backward_default_16[1]
        getitem_149 = convolution_backward_default_16[2];  convolution_backward_default_16 = None
        new_empty_default_10 = torch.ops.aten.new_empty.default(getitem_147, [16777216])
        zero__default_10 = torch.ops.aten.zero_.default(new_empty_default_10);  new_empty_default_10 = None
        as_strided_default_30 = torch.ops.aten.as_strided.default(zero__default_10, [16, 64, 128, 128], [1048576, 16384, 128, 1], 0)
        copy__default_64 = torch.ops.aten.copy_.default(as_strided_default_30, getitem_147);  as_strided_default_30 = getitem_147 = None
        as_strided_default_31 = torch.ops.aten.as_strided.default(zero__default_10, [1, 1024, 128, 128], [16777216, 16384, 128, 1], 0);  zero__default_10 = None
        new_empty_strided_default_10 = torch.ops.aten.new_empty_strided.default(as_strided_default_31, [1, 1024, 128, 128], [16777216, 16384, 128, 1])
        copy__default_65 = torch.ops.aten.copy_.default(new_empty_strided_default_10, as_strided_default_31);  new_empty_strided_default_10 = as_strided_default_31 = None
        as_strided_default_32 = torch.ops.aten.as_strided.default(copy__default_65, [16, 64, 128, 128], [1048576, 16384, 128, 1], 0)
        clone_default_10 = torch.ops.aten.clone.default(as_strided_default_32, memory_format = torch.contiguous_format)
        to_dtype_33 = torch.ops.aten.to.dtype(clone_default_10, torch.float32);  clone_default_10 = None
        to_dtype_34 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        new_zeros_default_61 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_61, to_dtype_33);  le_scalar_10 = new_zeros_default_61 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        copy__default_66 = torch.ops.aten.copy_.default(as_strided_default_32, to_dtype_35);  as_strided_default_32 = to_dtype_35 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(copy__default_65, view_default_1, repeat_default_1, repeat_default_3, repeat_default_4, new_zeros_default, new_zeros_default_1, False, 1e-05, [True, True, True]);  copy__default_65 = view_default_1 = repeat_default_1 = repeat_default_3 = repeat_default_4 = new_zeros_default = new_zeros_default_1 = None
        getitem_150 = native_batch_norm_backward_default_16[0]
        getitem_151 = native_batch_norm_backward_default_16[1]
        getitem_152 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        view_default_123 = torch.ops.aten.view.default(getitem_150, [16, 64, 128, 128]);  getitem_150 = None
        view_default_124 = torch.ops.aten.view.default(getitem_152, [16, 64]);  getitem_152 = None
        sum_dim_int_list_32 = torch.ops.aten.sum.dim_IntList(view_default_124, [0]);  view_default_124 = None
        view_default_125 = torch.ops.aten.view.default(getitem_151, [16, 64]);  getitem_151 = None
        sum_dim_int_list_33 = torch.ops.aten.sum.dim_IntList(view_default_125, [0]);  view_default_125 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(view_default_123, cat_default, primals_1, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 1, [False, True, False]);  view_default_123 = cat_default = primals_1 = None
        getitem_153 = convolution_backward_default_17[0]
        getitem_154 = convolution_backward_default_17[1]
        getitem_155 = convolution_backward_default_17[2];  convolution_backward_default_17 = None
        return [tanh_default, getitem_154, sum_dim_int_list_32, None, None, None, sum_dim_int_list_33, getitem_124, sum_dim_int_list_22, None, None, None, sum_dim_int_list_23, getitem_118, sum_dim_int_list_20, None, None, None, sum_dim_int_list_21, getitem_112, sum_dim_int_list_18, None, None, None, sum_dim_int_list_19, getitem_106, sum_dim_int_list_16, None, None, None, sum_dim_int_list_17, getitem_100, sum_dim_int_list_14, None, None, None, sum_dim_int_list_15, getitem_94, sum_dim_int_list_12, None, None, None, sum_dim_int_list_13, getitem_88, sum_dim_int_list_10, None, None, None, sum_dim_int_list_11, getitem_82, sum_dim_int_list_8, None, None, None, sum_dim_int_list_9, getitem_76, sum_dim_int_list_6, None, None, None, sum_dim_int_list_7, getitem_70, sum_dim_int_list_4, None, None, None, sum_dim_int_list_5, getitem_64, sum_dim_int_list_2, None, None, None, sum_dim_int_list_3, getitem_58, sum_dim_int_list, None, None, None, sum_dim_int_list_1, getitem_52, getitem_148, sum_dim_int_list_30, None, None, None, sum_dim_int_list_31, getitem_142, sum_dim_int_list_28, None, None, None, sum_dim_int_list_29, getitem_136, sum_dim_int_list_26, None, None, None, sum_dim_int_list_27, getitem_130, sum_dim_int_list_24, None, None, None, sum_dim_int_list_25, None, None]
        
