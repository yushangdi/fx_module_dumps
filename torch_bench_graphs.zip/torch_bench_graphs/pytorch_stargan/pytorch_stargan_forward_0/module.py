
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/pytorch_stargan/pytorch_stargan_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105):
        view_default = torch.ops.aten.view.default(primals_105, [16, 5, 1, 1]);  primals_105 = None
        repeat_default = torch.ops.aten.repeat.default(view_default, [1, 1, 128, 128]);  view_default = None
        cat_default = torch.ops.aten.cat.default([primals_104, repeat_default], 1);  primals_104 = repeat_default = None
        convolution_default = torch.ops.aten.convolution.default(cat_default, primals_1, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 1)
        repeat_default_1 = torch.ops.aten.repeat.default(primals_6, [16]);  primals_6 = None
        repeat_default_2 = torch.ops.aten.repeat.default(primals_2, [16]);  primals_2 = None
        repeat_default_3 = torch.ops.aten.repeat.default(primals_4, [16]);  primals_4 = None
        repeat_default_4 = torch.ops.aten.repeat.default(primals_5, [16]);  primals_5 = None
        view_default_1 = torch.ops.aten.view.default(convolution_default, [1, 1024, 128, 128]);  convolution_default = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(view_default_1, repeat_default_1, repeat_default_2, repeat_default_3, repeat_default_4, False, 0.1, 1e-05);  repeat_default_2 = None
        getitem = native_batch_norm_default[0];  native_batch_norm_default = None
        view_default_4 = torch.ops.aten.view.default(getitem, [16, 64, 128, 128]);  getitem = None
        relu__default = torch.ops.aten.relu_.default(view_default_4);  view_default_4 = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default, primals_80, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        repeat_default_5 = torch.ops.aten.repeat.default(primals_85, [16]);  primals_85 = None
        repeat_default_6 = torch.ops.aten.repeat.default(primals_81, [16]);  primals_81 = None
        repeat_default_7 = torch.ops.aten.repeat.default(primals_83, [16]);  primals_83 = None
        repeat_default_8 = torch.ops.aten.repeat.default(primals_84, [16]);  primals_84 = None
        view_default_5 = torch.ops.aten.view.default(convolution_default_1, [1, 2048, 64, 64]);  convolution_default_1 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(view_default_5, repeat_default_5, repeat_default_6, repeat_default_7, repeat_default_8, False, 0.1, 1e-05);  repeat_default_6 = None
        getitem_3 = native_batch_norm_default_1[0];  native_batch_norm_default_1 = None
        view_default_8 = torch.ops.aten.view.default(getitem_3, [16, 128, 64, 64]);  getitem_3 = None
        relu__default_1 = torch.ops.aten.relu_.default(view_default_8);  view_default_8 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_86, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        repeat_default_9 = torch.ops.aten.repeat.default(primals_91, [16]);  primals_91 = None
        repeat_default_10 = torch.ops.aten.repeat.default(primals_87, [16]);  primals_87 = None
        repeat_default_11 = torch.ops.aten.repeat.default(primals_89, [16]);  primals_89 = None
        repeat_default_12 = torch.ops.aten.repeat.default(primals_90, [16]);  primals_90 = None
        view_default_9 = torch.ops.aten.view.default(convolution_default_2, [1, 4096, 32, 32]);  convolution_default_2 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(view_default_9, repeat_default_9, repeat_default_10, repeat_default_11, repeat_default_12, False, 0.1, 1e-05);  repeat_default_10 = None
        getitem_6 = native_batch_norm_default_2[0];  native_batch_norm_default_2 = None
        view_default_12 = torch.ops.aten.view.default(getitem_6, [16, 256, 32, 32]);  getitem_6 = None
        relu__default_2 = torch.ops.aten.relu_.default(view_default_12);  view_default_12 = None
        convolution_default_3 = torch.ops.aten.convolution.default(relu__default_2, primals_92, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        repeat_default_13 = torch.ops.aten.repeat.default(primals_97, [16]);  primals_97 = None
        repeat_default_14 = torch.ops.aten.repeat.default(primals_93, [16]);  primals_93 = None
        repeat_default_15 = torch.ops.aten.repeat.default(primals_95, [16]);  primals_95 = None
        repeat_default_16 = torch.ops.aten.repeat.default(primals_96, [16]);  primals_96 = None
        view_default_13 = torch.ops.aten.view.default(convolution_default_3, [1, 4096, 32, 32]);  convolution_default_3 = None
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(view_default_13, repeat_default_13, repeat_default_14, repeat_default_15, repeat_default_16, False, 0.1, 1e-05);  repeat_default_14 = None
        getitem_9 = native_batch_norm_default_3[0];  native_batch_norm_default_3 = None
        view_default_16 = torch.ops.aten.view.default(getitem_9, [16, 256, 32, 32]);  getitem_9 = None
        relu__default_3 = torch.ops.aten.relu_.default(view_default_16);  view_default_16 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu__default_3, primals_98, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        repeat_default_17 = torch.ops.aten.repeat.default(primals_103, [16]);  primals_103 = None
        repeat_default_18 = torch.ops.aten.repeat.default(primals_99, [16]);  primals_99 = None
        repeat_default_19 = torch.ops.aten.repeat.default(primals_101, [16]);  primals_101 = None
        repeat_default_20 = torch.ops.aten.repeat.default(primals_102, [16]);  primals_102 = None
        view_default_17 = torch.ops.aten.view.default(convolution_default_4, [1, 4096, 32, 32]);  convolution_default_4 = None
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(view_default_17, repeat_default_17, repeat_default_18, repeat_default_19, repeat_default_20, False, 0.1, 1e-05);  repeat_default_18 = None
        getitem_12 = native_batch_norm_default_4[0];  native_batch_norm_default_4 = None
        view_default_20 = torch.ops.aten.view.default(getitem_12, [16, 256, 32, 32]);  getitem_12 = None
        add_tensor = torch.ops.aten.add.Tensor(relu__default_2, view_default_20);  view_default_20 = None
        convolution_default_5 = torch.ops.aten.convolution.default(add_tensor, primals_7, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        repeat_default_21 = torch.ops.aten.repeat.default(primals_12, [16]);  primals_12 = None
        repeat_default_22 = torch.ops.aten.repeat.default(primals_8, [16]);  primals_8 = None
        repeat_default_23 = torch.ops.aten.repeat.default(primals_10, [16]);  primals_10 = None
        repeat_default_24 = torch.ops.aten.repeat.default(primals_11, [16]);  primals_11 = None
        view_default_21 = torch.ops.aten.view.default(convolution_default_5, [1, 4096, 32, 32]);  convolution_default_5 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(view_default_21, repeat_default_21, repeat_default_22, repeat_default_23, repeat_default_24, False, 0.1, 1e-05);  repeat_default_22 = None
        getitem_15 = native_batch_norm_default_5[0];  native_batch_norm_default_5 = None
        view_default_24 = torch.ops.aten.view.default(getitem_15, [16, 256, 32, 32]);  getitem_15 = None
        relu__default_4 = torch.ops.aten.relu_.default(view_default_24);  view_default_24 = None
        convolution_default_6 = torch.ops.aten.convolution.default(relu__default_4, primals_13, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        repeat_default_25 = torch.ops.aten.repeat.default(primals_18, [16]);  primals_18 = None
        repeat_default_26 = torch.ops.aten.repeat.default(primals_14, [16]);  primals_14 = None
        repeat_default_27 = torch.ops.aten.repeat.default(primals_16, [16]);  primals_16 = None
        repeat_default_28 = torch.ops.aten.repeat.default(primals_17, [16]);  primals_17 = None
        view_default_25 = torch.ops.aten.view.default(convolution_default_6, [1, 4096, 32, 32]);  convolution_default_6 = None
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(view_default_25, repeat_default_25, repeat_default_26, repeat_default_27, repeat_default_28, False, 0.1, 1e-05);  repeat_default_26 = None
        getitem_18 = native_batch_norm_default_6[0];  native_batch_norm_default_6 = None
        view_default_28 = torch.ops.aten.view.default(getitem_18, [16, 256, 32, 32]);  getitem_18 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(add_tensor, view_default_28);  view_default_28 = None
        convolution_default_7 = torch.ops.aten.convolution.default(add_tensor_1, primals_19, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        repeat_default_29 = torch.ops.aten.repeat.default(primals_24, [16]);  primals_24 = None
        repeat_default_30 = torch.ops.aten.repeat.default(primals_20, [16]);  primals_20 = None
        repeat_default_31 = torch.ops.aten.repeat.default(primals_22, [16]);  primals_22 = None
        repeat_default_32 = torch.ops.aten.repeat.default(primals_23, [16]);  primals_23 = None
        view_default_29 = torch.ops.aten.view.default(convolution_default_7, [1, 4096, 32, 32]);  convolution_default_7 = None
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(view_default_29, repeat_default_29, repeat_default_30, repeat_default_31, repeat_default_32, False, 0.1, 1e-05);  repeat_default_30 = None
        getitem_21 = native_batch_norm_default_7[0];  native_batch_norm_default_7 = None
        view_default_32 = torch.ops.aten.view.default(getitem_21, [16, 256, 32, 32]);  getitem_21 = None
        relu__default_5 = torch.ops.aten.relu_.default(view_default_32);  view_default_32 = None
        convolution_default_8 = torch.ops.aten.convolution.default(relu__default_5, primals_25, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        repeat_default_33 = torch.ops.aten.repeat.default(primals_30, [16]);  primals_30 = None
        repeat_default_34 = torch.ops.aten.repeat.default(primals_26, [16]);  primals_26 = None
        repeat_default_35 = torch.ops.aten.repeat.default(primals_28, [16]);  primals_28 = None
        repeat_default_36 = torch.ops.aten.repeat.default(primals_29, [16]);  primals_29 = None
        view_default_33 = torch.ops.aten.view.default(convolution_default_8, [1, 4096, 32, 32]);  convolution_default_8 = None
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(view_default_33, repeat_default_33, repeat_default_34, repeat_default_35, repeat_default_36, False, 0.1, 1e-05);  repeat_default_34 = None
        getitem_24 = native_batch_norm_default_8[0];  native_batch_norm_default_8 = None
        view_default_36 = torch.ops.aten.view.default(getitem_24, [16, 256, 32, 32]);  getitem_24 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(add_tensor_1, view_default_36);  view_default_36 = None
        convolution_default_9 = torch.ops.aten.convolution.default(add_tensor_2, primals_31, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        repeat_default_37 = torch.ops.aten.repeat.default(primals_36, [16]);  primals_36 = None
        repeat_default_38 = torch.ops.aten.repeat.default(primals_32, [16]);  primals_32 = None
        repeat_default_39 = torch.ops.aten.repeat.default(primals_34, [16]);  primals_34 = None
        repeat_default_40 = torch.ops.aten.repeat.default(primals_35, [16]);  primals_35 = None
        view_default_37 = torch.ops.aten.view.default(convolution_default_9, [1, 4096, 32, 32]);  convolution_default_9 = None
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(view_default_37, repeat_default_37, repeat_default_38, repeat_default_39, repeat_default_40, False, 0.1, 1e-05);  repeat_default_38 = None
        getitem_27 = native_batch_norm_default_9[0];  native_batch_norm_default_9 = None
        view_default_40 = torch.ops.aten.view.default(getitem_27, [16, 256, 32, 32]);  getitem_27 = None
        relu__default_6 = torch.ops.aten.relu_.default(view_default_40);  view_default_40 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default_6, primals_37, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        repeat_default_41 = torch.ops.aten.repeat.default(primals_42, [16]);  primals_42 = None
        repeat_default_42 = torch.ops.aten.repeat.default(primals_38, [16]);  primals_38 = None
        repeat_default_43 = torch.ops.aten.repeat.default(primals_40, [16]);  primals_40 = None
        repeat_default_44 = torch.ops.aten.repeat.default(primals_41, [16]);  primals_41 = None
        view_default_41 = torch.ops.aten.view.default(convolution_default_10, [1, 4096, 32, 32]);  convolution_default_10 = None
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(view_default_41, repeat_default_41, repeat_default_42, repeat_default_43, repeat_default_44, False, 0.1, 1e-05);  repeat_default_42 = None
        getitem_30 = native_batch_norm_default_10[0];  native_batch_norm_default_10 = None
        view_default_44 = torch.ops.aten.view.default(getitem_30, [16, 256, 32, 32]);  getitem_30 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(add_tensor_2, view_default_44);  view_default_44 = None
        convolution_default_11 = torch.ops.aten.convolution.default(add_tensor_3, primals_43, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        repeat_default_45 = torch.ops.aten.repeat.default(primals_48, [16]);  primals_48 = None
        repeat_default_46 = torch.ops.aten.repeat.default(primals_44, [16]);  primals_44 = None
        repeat_default_47 = torch.ops.aten.repeat.default(primals_46, [16]);  primals_46 = None
        repeat_default_48 = torch.ops.aten.repeat.default(primals_47, [16]);  primals_47 = None
        view_default_45 = torch.ops.aten.view.default(convolution_default_11, [1, 4096, 32, 32]);  convolution_default_11 = None
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(view_default_45, repeat_default_45, repeat_default_46, repeat_default_47, repeat_default_48, False, 0.1, 1e-05);  repeat_default_46 = None
        getitem_33 = native_batch_norm_default_11[0];  native_batch_norm_default_11 = None
        view_default_48 = torch.ops.aten.view.default(getitem_33, [16, 256, 32, 32]);  getitem_33 = None
        relu__default_7 = torch.ops.aten.relu_.default(view_default_48);  view_default_48 = None
        convolution_default_12 = torch.ops.aten.convolution.default(relu__default_7, primals_49, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        repeat_default_49 = torch.ops.aten.repeat.default(primals_54, [16]);  primals_54 = None
        repeat_default_50 = torch.ops.aten.repeat.default(primals_50, [16]);  primals_50 = None
        repeat_default_51 = torch.ops.aten.repeat.default(primals_52, [16]);  primals_52 = None
        repeat_default_52 = torch.ops.aten.repeat.default(primals_53, [16]);  primals_53 = None
        view_default_49 = torch.ops.aten.view.default(convolution_default_12, [1, 4096, 32, 32]);  convolution_default_12 = None
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(view_default_49, repeat_default_49, repeat_default_50, repeat_default_51, repeat_default_52, False, 0.1, 1e-05);  repeat_default_50 = None
        getitem_36 = native_batch_norm_default_12[0];  native_batch_norm_default_12 = None
        view_default_52 = torch.ops.aten.view.default(getitem_36, [16, 256, 32, 32]);  getitem_36 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(add_tensor_3, view_default_52);  view_default_52 = None
        convolution_default_13 = torch.ops.aten.convolution.default(add_tensor_4, primals_55, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        repeat_default_53 = torch.ops.aten.repeat.default(primals_60, [16]);  primals_60 = None
        repeat_default_54 = torch.ops.aten.repeat.default(primals_56, [16]);  primals_56 = None
        repeat_default_55 = torch.ops.aten.repeat.default(primals_58, [16]);  primals_58 = None
        repeat_default_56 = torch.ops.aten.repeat.default(primals_59, [16]);  primals_59 = None
        view_default_53 = torch.ops.aten.view.default(convolution_default_13, [1, 4096, 32, 32]);  convolution_default_13 = None
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(view_default_53, repeat_default_53, repeat_default_54, repeat_default_55, repeat_default_56, False, 0.1, 1e-05);  repeat_default_54 = None
        getitem_39 = native_batch_norm_default_13[0];  native_batch_norm_default_13 = None
        view_default_56 = torch.ops.aten.view.default(getitem_39, [16, 256, 32, 32]);  getitem_39 = None
        relu__default_8 = torch.ops.aten.relu_.default(view_default_56);  view_default_56 = None
        convolution_default_14 = torch.ops.aten.convolution.default(relu__default_8, primals_61, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        repeat_default_57 = torch.ops.aten.repeat.default(primals_66, [16]);  primals_66 = None
        repeat_default_58 = torch.ops.aten.repeat.default(primals_62, [16]);  primals_62 = None
        repeat_default_59 = torch.ops.aten.repeat.default(primals_64, [16]);  primals_64 = None
        repeat_default_60 = torch.ops.aten.repeat.default(primals_65, [16]);  primals_65 = None
        view_default_57 = torch.ops.aten.view.default(convolution_default_14, [1, 4096, 32, 32]);  convolution_default_14 = None
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(view_default_57, repeat_default_57, repeat_default_58, repeat_default_59, repeat_default_60, False, 0.1, 1e-05);  repeat_default_58 = None
        getitem_42 = native_batch_norm_default_14[0];  native_batch_norm_default_14 = None
        view_default_60 = torch.ops.aten.view.default(getitem_42, [16, 256, 32, 32]);  getitem_42 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(add_tensor_4, view_default_60);  view_default_60 = None
        convolution_default_15 = torch.ops.aten.convolution.default(add_tensor_5, primals_67, None, [2, 2], [1, 1], [1, 1], True, [0, 0], 1)
        repeat_default_61 = torch.ops.aten.repeat.default(primals_72, [16]);  primals_72 = None
        repeat_default_62 = torch.ops.aten.repeat.default(primals_68, [16]);  primals_68 = None
        repeat_default_63 = torch.ops.aten.repeat.default(primals_70, [16]);  primals_70 = None
        repeat_default_64 = torch.ops.aten.repeat.default(primals_71, [16]);  primals_71 = None
        view_default_61 = torch.ops.aten.view.default(convolution_default_15, [1, 2048, 64, 64]);  convolution_default_15 = None
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(view_default_61, repeat_default_61, repeat_default_62, repeat_default_63, repeat_default_64, False, 0.1, 1e-05);  repeat_default_62 = None
        getitem_45 = native_batch_norm_default_15[0];  native_batch_norm_default_15 = None
        view_default_64 = torch.ops.aten.view.default(getitem_45, [16, 128, 64, 64]);  getitem_45 = None
        relu__default_9 = torch.ops.aten.relu_.default(view_default_64);  view_default_64 = None
        convolution_default_16 = torch.ops.aten.convolution.default(relu__default_9, primals_73, None, [2, 2], [1, 1], [1, 1], True, [0, 0], 1)
        repeat_default_65 = torch.ops.aten.repeat.default(primals_78, [16]);  primals_78 = None
        repeat_default_66 = torch.ops.aten.repeat.default(primals_74, [16]);  primals_74 = None
        repeat_default_67 = torch.ops.aten.repeat.default(primals_76, [16]);  primals_76 = None
        repeat_default_68 = torch.ops.aten.repeat.default(primals_77, [16]);  primals_77 = None
        view_default_65 = torch.ops.aten.view.default(convolution_default_16, [1, 1024, 128, 128]);  convolution_default_16 = None
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(view_default_65, repeat_default_65, repeat_default_66, repeat_default_67, repeat_default_68, False, 0.1, 1e-05);  repeat_default_66 = None
        getitem_48 = native_batch_norm_default_16[0];  native_batch_norm_default_16 = None
        view_default_68 = torch.ops.aten.view.default(getitem_48, [16, 64, 128, 128]);  getitem_48 = None
        relu__default_10 = torch.ops.aten.relu_.default(view_default_68);  view_default_68 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu__default_10, primals_79, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 1)
        tanh_default = torch.ops.aten.tanh.default(convolution_default_17);  convolution_default_17 = None
        return [tanh_default, primals_43, repeat_default_41, primals_19, repeat_default_19, primals_67, repeat_default_20, repeat_default_9, repeat_default_39, repeat_default_40, primals_49, view_default_17, repeat_default_63, repeat_default_11, repeat_default_64, repeat_default_12, view_default_37, primals_25, repeat_default_13, primals_73, view_default_61, relu__default_8, view_default_9, repeat_default_53, primals_55, repeat_default_55, repeat_default_56, primals_31, primals_79, view_default_53, primals_80, add_tensor, repeat_default_65, primals_61, repeat_default_23, relu__default_9, relu__default_2, repeat_default_21, primals_37, view_default_21, relu__default_6, repeat_default_24, primals_86, tanh_default, repeat_default_17, repeat_default_43, repeat_default_44, repeat_default_67, repeat_default_15, repeat_default_68, repeat_default_16, relu__default, primals_1, view_default_41, add_tensor_2, view_default_65, primals_92, repeat_default_5, view_default_13, repeat_default_61, repeat_default_33, view_default_45, add_tensor_5, repeat_default_29, repeat_default_57, repeat_default_7, repeat_default_1, repeat_default_8, repeat_default_35, relu__default_5, repeat_default_36, relu__default_1, repeat_default_59, primals_7, repeat_default_3, repeat_default_60, repeat_default_4, view_default_5, repeat_default_31, repeat_default_32, relu__default_4, view_default_33, primals_98, view_default_57, relu__default_7, view_default_1, add_tensor_1, repeat_default_25, view_default_29, cat_default, repeat_default_49, repeat_default_27, view_default_49, primals_13, repeat_default_28, repeat_default_51, add_tensor_4, add_tensor_3, repeat_default_52, relu__default_10, repeat_default_47, relu__default_3, view_default_25, repeat_default_45, repeat_default_37, repeat_default_48]
        
