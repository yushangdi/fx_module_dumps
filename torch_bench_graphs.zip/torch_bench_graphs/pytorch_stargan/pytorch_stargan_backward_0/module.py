
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/pytorch_stargan/pytorch_stargan_backward_0/state_dict.pt'))

    
    
    def forward(self, primals_43, repeat_default_41, primals_19, repeat_default_19, primals_67, repeat_default_20, repeat_default_9, repeat_default_39, repeat_default_40, primals_49, view_default_17, repeat_default_63, repeat_default_11, repeat_default_64, repeat_default_12, view_default_37, primals_25, repeat_default_13, primals_73, view_default_61, relu__default_8, view_default_9, repeat_default_53, primals_55, repeat_default_55, repeat_default_56, primals_31, primals_79, view_default_53, primals_80, add_tensor, repeat_default_65, primals_61, repeat_default_23, relu__default_9, relu__default_2, repeat_default_21, primals_37, view_default_21, relu__default_6, repeat_default_24, primals_86, tanh_default, repeat_default_17, repeat_default_43, repeat_default_44, repeat_default_67, repeat_default_15, repeat_default_68, repeat_default_16, relu__default, primals_1, view_default_41, add_tensor_2, view_default_65, primals_92, repeat_default_5, view_default_13, repeat_default_61, repeat_default_33, view_default_45, add_tensor_5, repeat_default_29, repeat_default_57, repeat_default_7, repeat_default_1, repeat_default_8, repeat_default_35, relu__default_5, repeat_default_36, relu__default_1, repeat_default_59, primals_7, repeat_default_3, repeat_default_60, repeat_default_4, view_default_5, repeat_default_31, repeat_default_32, relu__default_4, view_default_33, primals_98, view_default_57, relu__default_7, view_default_1, add_tensor_1, repeat_default_25, view_default_29, cat_default, repeat_default_49, repeat_default_27, view_default_49, primals_13, repeat_default_28, repeat_default_51, add_tensor_4, add_tensor_3, repeat_default_52, relu__default_10, repeat_default_47, relu__default_3, view_default_25, repeat_default_45, repeat_default_37, repeat_default_48, tangents_1):
        new_zeros_default = torch.ops.aten.new_zeros.default(view_default_1, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(view_default_1, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(view_default_5, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(view_default_5, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(view_default_9, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(view_default_9, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_9 = torch.ops.aten.new_zeros.default(view_default_13, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_10 = torch.ops.aten.new_zeros.default(view_default_13, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_12 = torch.ops.aten.new_zeros.default(view_default_17, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_13 = torch.ops.aten.new_zeros.default(view_default_17, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_15 = torch.ops.aten.new_zeros.default(view_default_21, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_16 = torch.ops.aten.new_zeros.default(view_default_21, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_18 = torch.ops.aten.new_zeros.default(view_default_25, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_19 = torch.ops.aten.new_zeros.default(view_default_25, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_21 = torch.ops.aten.new_zeros.default(view_default_29, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_22 = torch.ops.aten.new_zeros.default(view_default_29, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_24 = torch.ops.aten.new_zeros.default(view_default_33, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_25 = torch.ops.aten.new_zeros.default(view_default_33, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_27 = torch.ops.aten.new_zeros.default(view_default_37, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_28 = torch.ops.aten.new_zeros.default(view_default_37, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_30 = torch.ops.aten.new_zeros.default(view_default_41, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_31 = torch.ops.aten.new_zeros.default(view_default_41, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_33 = torch.ops.aten.new_zeros.default(view_default_45, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_34 = torch.ops.aten.new_zeros.default(view_default_45, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_36 = torch.ops.aten.new_zeros.default(view_default_49, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_37 = torch.ops.aten.new_zeros.default(view_default_49, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_39 = torch.ops.aten.new_zeros.default(view_default_53, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_40 = torch.ops.aten.new_zeros.default(view_default_53, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_42 = torch.ops.aten.new_zeros.default(view_default_57, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_43 = torch.ops.aten.new_zeros.default(view_default_57, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_45 = torch.ops.aten.new_zeros.default(view_default_61, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_46 = torch.ops.aten.new_zeros.default(view_default_61, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_48 = torch.ops.aten.new_zeros.default(view_default_65, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_49 = torch.ops.aten.new_zeros.default(view_default_65, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        to_dtype = torch.ops.aten.to.dtype(tangents_1, torch.float32);  tangents_1 = None
        to_dtype_1 = torch.ops.aten.to.dtype(tanh_default, torch.float32);  tanh_default = None
        mul_tensor = torch.ops.aten.mul.Tensor(to_dtype_1, to_dtype_1);  to_dtype_1 = None
        rsub_scalar = torch.ops.aten.rsub.Scalar(mul_tensor, 1);  mul_tensor = None
        conj_physical_default = torch.ops.aten.conj_physical.default(rsub_scalar);  rsub_scalar = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(to_dtype, conj_physical_default);  to_dtype = conj_physical_default = None
        to_dtype_2 = torch.ops.aten.to.dtype(mul_tensor_1, torch.float32);  mul_tensor_1 = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(to_dtype_2, relu__default_10, primals_79, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  to_dtype_2 = relu__default_10 = primals_79 = None
        getitem_51 = convolution_backward_default[0]
        getitem_52 = convolution_backward_default[1];  convolution_backward_default = None
        new_empty_default = torch.ops.aten.new_empty.default(getitem_51, [16777216]);  getitem_51 = None
        zero__default = torch.ops.aten.zero_.default(new_empty_default);  new_empty_default = None
        as_strided_default_1 = torch.ops.aten.as_strided.default(zero__default, [1, 1024, 128, 128], [16777216, 16384, 128, 1], 0);  zero__default = None
        new_empty_strided_default = torch.ops.aten.new_empty_strided.default(as_strided_default_1, [1, 1024, 128, 128], [16777216, 16384, 128, 1])
        copy__default_35 = torch.ops.aten.copy_.default(new_empty_strided_default, as_strided_default_1);  new_empty_strided_default = as_strided_default_1 = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(copy__default_35, view_default_65, repeat_default_65, repeat_default_67, repeat_default_68, new_zeros_default_48, new_zeros_default_49, False, 1e-05, [True, True, True]);  copy__default_35 = view_default_65 = repeat_default_65 = repeat_default_67 = repeat_default_68 = new_zeros_default_48 = new_zeros_default_49 = None
        getitem_54 = native_batch_norm_backward_default[0]
        getitem_55 = native_batch_norm_backward_default[1]
        getitem_56 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        view_default_69 = torch.ops.aten.view.default(getitem_54, [16, 64, 128, 128]);  getitem_54 = None
        view_default_70 = torch.ops.aten.view.default(getitem_56, [16, 64]);  getitem_56 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(view_default_70, [0]);  view_default_70 = None
        view_default_71 = torch.ops.aten.view.default(getitem_55, [16, 64]);  getitem_55 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(view_default_71, [0]);  view_default_71 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(view_default_69, relu__default_9, primals_73, [0], [2, 2], [1, 1], [1, 1], True, [0, 0], 1, [True, True, False]);  view_default_69 = relu__default_9 = primals_73 = None
        getitem_57 = convolution_backward_default_1[0]
        getitem_58 = convolution_backward_default_1[1];  convolution_backward_default_1 = None
        new_empty_default_1 = torch.ops.aten.new_empty.default(getitem_57, [8388608]);  getitem_57 = None
        zero__default_1 = torch.ops.aten.zero_.default(new_empty_default_1);  new_empty_default_1 = None
        as_strided_default_4 = torch.ops.aten.as_strided.default(zero__default_1, [1, 2048, 64, 64], [8388608, 4096, 64, 1], 0);  zero__default_1 = None
        new_empty_strided_default_1 = torch.ops.aten.new_empty_strided.default(as_strided_default_4, [1, 2048, 64, 64], [8388608, 4096, 64, 1])
        copy__default_38 = torch.ops.aten.copy_.default(new_empty_strided_default_1, as_strided_default_4);  new_empty_strided_default_1 = as_strided_default_4 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(copy__default_38, view_default_61, repeat_default_61, repeat_default_63, repeat_default_64, new_zeros_default_45, new_zeros_default_46, False, 1e-05, [True, True, True]);  copy__default_38 = view_default_61 = repeat_default_61 = repeat_default_63 = repeat_default_64 = new_zeros_default_45 = new_zeros_default_46 = None
        getitem_60 = native_batch_norm_backward_default_1[0]
        getitem_61 = native_batch_norm_backward_default_1[1]
        getitem_62 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        view_default_72 = torch.ops.aten.view.default(getitem_60, [16, 128, 64, 64]);  getitem_60 = None
        view_default_73 = torch.ops.aten.view.default(getitem_62, [16, 128]);  getitem_62 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(view_default_73, [0]);  view_default_73 = None
        view_default_74 = torch.ops.aten.view.default(getitem_61, [16, 128]);  getitem_61 = None
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(view_default_74, [0]);  view_default_74 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(view_default_72, add_tensor_5, primals_67, [0], [2, 2], [1, 1], [1, 1], True, [0, 0], 1, [True, True, False]);  view_default_72 = add_tensor_5 = primals_67 = None
        getitem_63 = convolution_backward_default_2[0]
        getitem_64 = convolution_backward_default_2[1];  convolution_backward_default_2 = None
        view_default_75 = torch.ops.aten.view.default(getitem_63, [1, 4096, 32, 32])
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(view_default_75, view_default_57, repeat_default_57, repeat_default_59, repeat_default_60, new_zeros_default_42, new_zeros_default_43, False, 1e-05, [True, True, True]);  view_default_75 = view_default_57 = repeat_default_57 = repeat_default_59 = repeat_default_60 = new_zeros_default_42 = new_zeros_default_43 = None
        getitem_66 = native_batch_norm_backward_default_2[0]
        getitem_67 = native_batch_norm_backward_default_2[1]
        getitem_68 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        view_default_76 = torch.ops.aten.view.default(getitem_66, [16, 256, 32, 32]);  getitem_66 = None
        view_default_77 = torch.ops.aten.view.default(getitem_68, [16, 256]);  getitem_68 = None
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(view_default_77, [0]);  view_default_77 = None
        view_default_78 = torch.ops.aten.view.default(getitem_67, [16, 256]);  getitem_67 = None
        sum_dim_int_list_5 = torch.ops.aten.sum.dim_IntList(view_default_78, [0]);  view_default_78 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(view_default_76, relu__default_8, primals_61, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_76 = relu__default_8 = primals_61 = None
        getitem_69 = convolution_backward_default_3[0]
        getitem_70 = convolution_backward_default_3[1];  convolution_backward_default_3 = None
        new_empty_default_2 = torch.ops.aten.new_empty.default(getitem_69, [4194304]);  getitem_69 = None
        zero__default_2 = torch.ops.aten.zero_.default(new_empty_default_2);  new_empty_default_2 = None
        as_strided_default_7 = torch.ops.aten.as_strided.default(zero__default_2, [1, 4096, 32, 32], [4194304, 1024, 32, 1], 0);  zero__default_2 = None
        new_empty_strided_default_2 = torch.ops.aten.new_empty_strided.default(as_strided_default_7, [1, 4096, 32, 32], [4194304, 1024, 32, 1])
        copy__default_41 = torch.ops.aten.copy_.default(new_empty_strided_default_2, as_strided_default_7);  new_empty_strided_default_2 = as_strided_default_7 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(copy__default_41, view_default_53, repeat_default_53, repeat_default_55, repeat_default_56, new_zeros_default_39, new_zeros_default_40, False, 1e-05, [True, True, True]);  copy__default_41 = view_default_53 = repeat_default_53 = repeat_default_55 = repeat_default_56 = new_zeros_default_39 = new_zeros_default_40 = None
        getitem_72 = native_batch_norm_backward_default_3[0]
        getitem_73 = native_batch_norm_backward_default_3[1]
        getitem_74 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        view_default_79 = torch.ops.aten.view.default(getitem_72, [16, 256, 32, 32]);  getitem_72 = None
        view_default_80 = torch.ops.aten.view.default(getitem_74, [16, 256]);  getitem_74 = None
        sum_dim_int_list_6 = torch.ops.aten.sum.dim_IntList(view_default_80, [0]);  view_default_80 = None
        view_default_81 = torch.ops.aten.view.default(getitem_73, [16, 256]);  getitem_73 = None
        sum_dim_int_list_7 = torch.ops.aten.sum.dim_IntList(view_default_81, [0]);  view_default_81 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(view_default_79, add_tensor_4, primals_55, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_79 = add_tensor_4 = primals_55 = None
        getitem_75 = convolution_backward_default_4[0]
        getitem_76 = convolution_backward_default_4[1];  convolution_backward_default_4 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(getitem_63, getitem_75);  getitem_63 = getitem_75 = None
        view_default_82 = torch.ops.aten.view.default(add_tensor_6, [1, 4096, 32, 32])
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(view_default_82, view_default_49, repeat_default_49, repeat_default_51, repeat_default_52, new_zeros_default_36, new_zeros_default_37, False, 1e-05, [True, True, True]);  view_default_82 = view_default_49 = repeat_default_49 = repeat_default_51 = repeat_default_52 = new_zeros_default_36 = new_zeros_default_37 = None
        getitem_78 = native_batch_norm_backward_default_4[0]
        getitem_79 = native_batch_norm_backward_default_4[1]
        getitem_80 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        view_default_83 = torch.ops.aten.view.default(getitem_78, [16, 256, 32, 32]);  getitem_78 = None
        view_default_84 = torch.ops.aten.view.default(getitem_80, [16, 256]);  getitem_80 = None
        sum_dim_int_list_8 = torch.ops.aten.sum.dim_IntList(view_default_84, [0]);  view_default_84 = None
        view_default_85 = torch.ops.aten.view.default(getitem_79, [16, 256]);  getitem_79 = None
        sum_dim_int_list_9 = torch.ops.aten.sum.dim_IntList(view_default_85, [0]);  view_default_85 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(view_default_83, relu__default_7, primals_49, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_83 = relu__default_7 = primals_49 = None
        getitem_81 = convolution_backward_default_5[0]
        getitem_82 = convolution_backward_default_5[1];  convolution_backward_default_5 = None
        new_empty_default_3 = torch.ops.aten.new_empty.default(getitem_81, [4194304]);  getitem_81 = None
        zero__default_3 = torch.ops.aten.zero_.default(new_empty_default_3);  new_empty_default_3 = None
        as_strided_default_10 = torch.ops.aten.as_strided.default(zero__default_3, [1, 4096, 32, 32], [4194304, 1024, 32, 1], 0);  zero__default_3 = None
        new_empty_strided_default_3 = torch.ops.aten.new_empty_strided.default(as_strided_default_10, [1, 4096, 32, 32], [4194304, 1024, 32, 1])
        copy__default_44 = torch.ops.aten.copy_.default(new_empty_strided_default_3, as_strided_default_10);  new_empty_strided_default_3 = as_strided_default_10 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(copy__default_44, view_default_45, repeat_default_45, repeat_default_47, repeat_default_48, new_zeros_default_33, new_zeros_default_34, False, 1e-05, [True, True, True]);  copy__default_44 = view_default_45 = repeat_default_45 = repeat_default_47 = repeat_default_48 = new_zeros_default_33 = new_zeros_default_34 = None
        getitem_84 = native_batch_norm_backward_default_5[0]
        getitem_85 = native_batch_norm_backward_default_5[1]
        getitem_86 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        view_default_86 = torch.ops.aten.view.default(getitem_84, [16, 256, 32, 32]);  getitem_84 = None
        view_default_87 = torch.ops.aten.view.default(getitem_86, [16, 256]);  getitem_86 = None
        sum_dim_int_list_10 = torch.ops.aten.sum.dim_IntList(view_default_87, [0]);  view_default_87 = None
        view_default_88 = torch.ops.aten.view.default(getitem_85, [16, 256]);  getitem_85 = None
        sum_dim_int_list_11 = torch.ops.aten.sum.dim_IntList(view_default_88, [0]);  view_default_88 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(view_default_86, add_tensor_3, primals_43, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_86 = add_tensor_3 = primals_43 = None
        getitem_87 = convolution_backward_default_6[0]
        getitem_88 = convolution_backward_default_6[1];  convolution_backward_default_6 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(add_tensor_6, getitem_87);  add_tensor_6 = getitem_87 = None
        view_default_89 = torch.ops.aten.view.default(add_tensor_7, [1, 4096, 32, 32])
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(view_default_89, view_default_41, repeat_default_41, repeat_default_43, repeat_default_44, new_zeros_default_30, new_zeros_default_31, False, 1e-05, [True, True, True]);  view_default_89 = view_default_41 = repeat_default_41 = repeat_default_43 = repeat_default_44 = new_zeros_default_30 = new_zeros_default_31 = None
        getitem_90 = native_batch_norm_backward_default_6[0]
        getitem_91 = native_batch_norm_backward_default_6[1]
        getitem_92 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        view_default_90 = torch.ops.aten.view.default(getitem_90, [16, 256, 32, 32]);  getitem_90 = None
        view_default_91 = torch.ops.aten.view.default(getitem_92, [16, 256]);  getitem_92 = None
        sum_dim_int_list_12 = torch.ops.aten.sum.dim_IntList(view_default_91, [0]);  view_default_91 = None
        view_default_92 = torch.ops.aten.view.default(getitem_91, [16, 256]);  getitem_91 = None
        sum_dim_int_list_13 = torch.ops.aten.sum.dim_IntList(view_default_92, [0]);  view_default_92 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(view_default_90, relu__default_6, primals_37, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_90 = relu__default_6 = primals_37 = None
        getitem_93 = convolution_backward_default_7[0]
        getitem_94 = convolution_backward_default_7[1];  convolution_backward_default_7 = None
        new_empty_default_4 = torch.ops.aten.new_empty.default(getitem_93, [4194304]);  getitem_93 = None
        zero__default_4 = torch.ops.aten.zero_.default(new_empty_default_4);  new_empty_default_4 = None
        as_strided_default_13 = torch.ops.aten.as_strided.default(zero__default_4, [1, 4096, 32, 32], [4194304, 1024, 32, 1], 0);  zero__default_4 = None
        new_empty_strided_default_4 = torch.ops.aten.new_empty_strided.default(as_strided_default_13, [1, 4096, 32, 32], [4194304, 1024, 32, 1])
        copy__default_47 = torch.ops.aten.copy_.default(new_empty_strided_default_4, as_strided_default_13);  new_empty_strided_default_4 = as_strided_default_13 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(copy__default_47, view_default_37, repeat_default_37, repeat_default_39, repeat_default_40, new_zeros_default_27, new_zeros_default_28, False, 1e-05, [True, True, True]);  copy__default_47 = view_default_37 = repeat_default_37 = repeat_default_39 = repeat_default_40 = new_zeros_default_27 = new_zeros_default_28 = None
        getitem_96 = native_batch_norm_backward_default_7[0]
        getitem_97 = native_batch_norm_backward_default_7[1]
        getitem_98 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        view_default_93 = torch.ops.aten.view.default(getitem_96, [16, 256, 32, 32]);  getitem_96 = None
        view_default_94 = torch.ops.aten.view.default(getitem_98, [16, 256]);  getitem_98 = None
        sum_dim_int_list_14 = torch.ops.aten.sum.dim_IntList(view_default_94, [0]);  view_default_94 = None
        view_default_95 = torch.ops.aten.view.default(getitem_97, [16, 256]);  getitem_97 = None
        sum_dim_int_list_15 = torch.ops.aten.sum.dim_IntList(view_default_95, [0]);  view_default_95 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(view_default_93, add_tensor_2, primals_31, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_93 = add_tensor_2 = primals_31 = None
        getitem_99 = convolution_backward_default_8[0]
        getitem_100 = convolution_backward_default_8[1];  convolution_backward_default_8 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(add_tensor_7, getitem_99);  add_tensor_7 = getitem_99 = None
        view_default_96 = torch.ops.aten.view.default(add_tensor_8, [1, 4096, 32, 32])
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(view_default_96, view_default_33, repeat_default_33, repeat_default_35, repeat_default_36, new_zeros_default_24, new_zeros_default_25, False, 1e-05, [True, True, True]);  view_default_96 = view_default_33 = repeat_default_33 = repeat_default_35 = repeat_default_36 = new_zeros_default_24 = new_zeros_default_25 = None
        getitem_102 = native_batch_norm_backward_default_8[0]
        getitem_103 = native_batch_norm_backward_default_8[1]
        getitem_104 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        view_default_97 = torch.ops.aten.view.default(getitem_102, [16, 256, 32, 32]);  getitem_102 = None
        view_default_98 = torch.ops.aten.view.default(getitem_104, [16, 256]);  getitem_104 = None
        sum_dim_int_list_16 = torch.ops.aten.sum.dim_IntList(view_default_98, [0]);  view_default_98 = None
        view_default_99 = torch.ops.aten.view.default(getitem_103, [16, 256]);  getitem_103 = None
        sum_dim_int_list_17 = torch.ops.aten.sum.dim_IntList(view_default_99, [0]);  view_default_99 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(view_default_97, relu__default_5, primals_25, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_97 = relu__default_5 = primals_25 = None
        getitem_105 = convolution_backward_default_9[0]
        getitem_106 = convolution_backward_default_9[1];  convolution_backward_default_9 = None
        new_empty_default_5 = torch.ops.aten.new_empty.default(getitem_105, [4194304]);  getitem_105 = None
        zero__default_5 = torch.ops.aten.zero_.default(new_empty_default_5);  new_empty_default_5 = None
        as_strided_default_16 = torch.ops.aten.as_strided.default(zero__default_5, [1, 4096, 32, 32], [4194304, 1024, 32, 1], 0);  zero__default_5 = None
        new_empty_strided_default_5 = torch.ops.aten.new_empty_strided.default(as_strided_default_16, [1, 4096, 32, 32], [4194304, 1024, 32, 1])
        copy__default_50 = torch.ops.aten.copy_.default(new_empty_strided_default_5, as_strided_default_16);  new_empty_strided_default_5 = as_strided_default_16 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(copy__default_50, view_default_29, repeat_default_29, repeat_default_31, repeat_default_32, new_zeros_default_21, new_zeros_default_22, False, 1e-05, [True, True, True]);  copy__default_50 = view_default_29 = repeat_default_29 = repeat_default_31 = repeat_default_32 = new_zeros_default_21 = new_zeros_default_22 = None
        getitem_108 = native_batch_norm_backward_default_9[0]
        getitem_109 = native_batch_norm_backward_default_9[1]
        getitem_110 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        view_default_100 = torch.ops.aten.view.default(getitem_108, [16, 256, 32, 32]);  getitem_108 = None
        view_default_101 = torch.ops.aten.view.default(getitem_110, [16, 256]);  getitem_110 = None
        sum_dim_int_list_18 = torch.ops.aten.sum.dim_IntList(view_default_101, [0]);  view_default_101 = None
        view_default_102 = torch.ops.aten.view.default(getitem_109, [16, 256]);  getitem_109 = None
        sum_dim_int_list_19 = torch.ops.aten.sum.dim_IntList(view_default_102, [0]);  view_default_102 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(view_default_100, add_tensor_1, primals_19, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_100 = add_tensor_1 = primals_19 = None
        getitem_111 = convolution_backward_default_10[0]
        getitem_112 = convolution_backward_default_10[1];  convolution_backward_default_10 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(add_tensor_8, getitem_111);  add_tensor_8 = getitem_111 = None
        view_default_103 = torch.ops.aten.view.default(add_tensor_9, [1, 4096, 32, 32])
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(view_default_103, view_default_25, repeat_default_25, repeat_default_27, repeat_default_28, new_zeros_default_18, new_zeros_default_19, False, 1e-05, [True, True, True]);  view_default_103 = view_default_25 = repeat_default_25 = repeat_default_27 = repeat_default_28 = new_zeros_default_18 = new_zeros_default_19 = None
        getitem_114 = native_batch_norm_backward_default_10[0]
        getitem_115 = native_batch_norm_backward_default_10[1]
        getitem_116 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        view_default_104 = torch.ops.aten.view.default(getitem_114, [16, 256, 32, 32]);  getitem_114 = None
        view_default_105 = torch.ops.aten.view.default(getitem_116, [16, 256]);  getitem_116 = None
        sum_dim_int_list_20 = torch.ops.aten.sum.dim_IntList(view_default_105, [0]);  view_default_105 = None
        view_default_106 = torch.ops.aten.view.default(getitem_115, [16, 256]);  getitem_115 = None
        sum_dim_int_list_21 = torch.ops.aten.sum.dim_IntList(view_default_106, [0]);  view_default_106 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(view_default_104, relu__default_4, primals_13, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_104 = relu__default_4 = primals_13 = None
        getitem_117 = convolution_backward_default_11[0]
        getitem_118 = convolution_backward_default_11[1];  convolution_backward_default_11 = None
        new_empty_default_6 = torch.ops.aten.new_empty.default(getitem_117, [4194304]);  getitem_117 = None
        zero__default_6 = torch.ops.aten.zero_.default(new_empty_default_6);  new_empty_default_6 = None
        as_strided_default_19 = torch.ops.aten.as_strided.default(zero__default_6, [1, 4096, 32, 32], [4194304, 1024, 32, 1], 0);  zero__default_6 = None
        new_empty_strided_default_6 = torch.ops.aten.new_empty_strided.default(as_strided_default_19, [1, 4096, 32, 32], [4194304, 1024, 32, 1])
        copy__default_53 = torch.ops.aten.copy_.default(new_empty_strided_default_6, as_strided_default_19);  new_empty_strided_default_6 = as_strided_default_19 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(copy__default_53, view_default_21, repeat_default_21, repeat_default_23, repeat_default_24, new_zeros_default_15, new_zeros_default_16, False, 1e-05, [True, True, True]);  copy__default_53 = view_default_21 = repeat_default_21 = repeat_default_23 = repeat_default_24 = new_zeros_default_15 = new_zeros_default_16 = None
        getitem_120 = native_batch_norm_backward_default_11[0]
        getitem_121 = native_batch_norm_backward_default_11[1]
        getitem_122 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        view_default_107 = torch.ops.aten.view.default(getitem_120, [16, 256, 32, 32]);  getitem_120 = None
        view_default_108 = torch.ops.aten.view.default(getitem_122, [16, 256]);  getitem_122 = None
        sum_dim_int_list_22 = torch.ops.aten.sum.dim_IntList(view_default_108, [0]);  view_default_108 = None
        view_default_109 = torch.ops.aten.view.default(getitem_121, [16, 256]);  getitem_121 = None
        sum_dim_int_list_23 = torch.ops.aten.sum.dim_IntList(view_default_109, [0]);  view_default_109 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(view_default_107, add_tensor, primals_7, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_107 = add_tensor = primals_7 = None
        getitem_123 = convolution_backward_default_12[0]
        getitem_124 = convolution_backward_default_12[1];  convolution_backward_default_12 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(add_tensor_9, getitem_123);  add_tensor_9 = getitem_123 = None
        view_default_110 = torch.ops.aten.view.default(add_tensor_10, [1, 4096, 32, 32])
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(view_default_110, view_default_17, repeat_default_17, repeat_default_19, repeat_default_20, new_zeros_default_12, new_zeros_default_13, False, 1e-05, [True, True, True]);  view_default_110 = view_default_17 = repeat_default_17 = repeat_default_19 = repeat_default_20 = new_zeros_default_12 = new_zeros_default_13 = None
        getitem_126 = native_batch_norm_backward_default_12[0]
        getitem_127 = native_batch_norm_backward_default_12[1]
        getitem_128 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        view_default_111 = torch.ops.aten.view.default(getitem_126, [16, 256, 32, 32]);  getitem_126 = None
        view_default_112 = torch.ops.aten.view.default(getitem_128, [16, 256]);  getitem_128 = None
        sum_dim_int_list_24 = torch.ops.aten.sum.dim_IntList(view_default_112, [0]);  view_default_112 = None
        view_default_113 = torch.ops.aten.view.default(getitem_127, [16, 256]);  getitem_127 = None
        sum_dim_int_list_25 = torch.ops.aten.sum.dim_IntList(view_default_113, [0]);  view_default_113 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(view_default_111, relu__default_3, primals_98, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_111 = relu__default_3 = primals_98 = None
        getitem_129 = convolution_backward_default_13[0]
        getitem_130 = convolution_backward_default_13[1];  convolution_backward_default_13 = None
        new_empty_default_7 = torch.ops.aten.new_empty.default(getitem_129, [4194304]);  getitem_129 = None
        zero__default_7 = torch.ops.aten.zero_.default(new_empty_default_7);  new_empty_default_7 = None
        as_strided_default_22 = torch.ops.aten.as_strided.default(zero__default_7, [1, 4096, 32, 32], [4194304, 1024, 32, 1], 0);  zero__default_7 = None
        new_empty_strided_default_7 = torch.ops.aten.new_empty_strided.default(as_strided_default_22, [1, 4096, 32, 32], [4194304, 1024, 32, 1])
        copy__default_56 = torch.ops.aten.copy_.default(new_empty_strided_default_7, as_strided_default_22);  new_empty_strided_default_7 = as_strided_default_22 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(copy__default_56, view_default_13, repeat_default_13, repeat_default_15, repeat_default_16, new_zeros_default_9, new_zeros_default_10, False, 1e-05, [True, True, True]);  copy__default_56 = view_default_13 = repeat_default_13 = repeat_default_15 = repeat_default_16 = new_zeros_default_9 = new_zeros_default_10 = None
        getitem_132 = native_batch_norm_backward_default_13[0]
        getitem_133 = native_batch_norm_backward_default_13[1]
        getitem_134 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        view_default_114 = torch.ops.aten.view.default(getitem_132, [16, 256, 32, 32]);  getitem_132 = None
        view_default_115 = torch.ops.aten.view.default(getitem_134, [16, 256]);  getitem_134 = None
        sum_dim_int_list_26 = torch.ops.aten.sum.dim_IntList(view_default_115, [0]);  view_default_115 = None
        view_default_116 = torch.ops.aten.view.default(getitem_133, [16, 256]);  getitem_133 = None
        sum_dim_int_list_27 = torch.ops.aten.sum.dim_IntList(view_default_116, [0]);  view_default_116 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(view_default_114, relu__default_2, primals_92, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_114 = relu__default_2 = primals_92 = None
        getitem_135 = convolution_backward_default_14[0]
        getitem_136 = convolution_backward_default_14[1];  convolution_backward_default_14 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(add_tensor_10, getitem_135);  add_tensor_10 = getitem_135 = None
        new_empty_default_8 = torch.ops.aten.new_empty.default(add_tensor_11, [4194304]);  add_tensor_11 = None
        zero__default_8 = torch.ops.aten.zero_.default(new_empty_default_8);  new_empty_default_8 = None
        as_strided_default_25 = torch.ops.aten.as_strided.default(zero__default_8, [1, 4096, 32, 32], [4194304, 1024, 32, 1], 0);  zero__default_8 = None
        new_empty_strided_default_8 = torch.ops.aten.new_empty_strided.default(as_strided_default_25, [1, 4096, 32, 32], [4194304, 1024, 32, 1])
        copy__default_59 = torch.ops.aten.copy_.default(new_empty_strided_default_8, as_strided_default_25);  new_empty_strided_default_8 = as_strided_default_25 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(copy__default_59, view_default_9, repeat_default_9, repeat_default_11, repeat_default_12, new_zeros_default_6, new_zeros_default_7, False, 1e-05, [True, True, True]);  copy__default_59 = view_default_9 = repeat_default_9 = repeat_default_11 = repeat_default_12 = new_zeros_default_6 = new_zeros_default_7 = None
        getitem_138 = native_batch_norm_backward_default_14[0]
        getitem_139 = native_batch_norm_backward_default_14[1]
        getitem_140 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        view_default_117 = torch.ops.aten.view.default(getitem_138, [16, 256, 32, 32]);  getitem_138 = None
        view_default_118 = torch.ops.aten.view.default(getitem_140, [16, 256]);  getitem_140 = None
        sum_dim_int_list_28 = torch.ops.aten.sum.dim_IntList(view_default_118, [0]);  view_default_118 = None
        view_default_119 = torch.ops.aten.view.default(getitem_139, [16, 256]);  getitem_139 = None
        sum_dim_int_list_29 = torch.ops.aten.sum.dim_IntList(view_default_119, [0]);  view_default_119 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(view_default_117, relu__default_1, primals_86, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_117 = relu__default_1 = primals_86 = None
        getitem_141 = convolution_backward_default_15[0]
        getitem_142 = convolution_backward_default_15[1];  convolution_backward_default_15 = None
        new_empty_default_9 = torch.ops.aten.new_empty.default(getitem_141, [8388608]);  getitem_141 = None
        zero__default_9 = torch.ops.aten.zero_.default(new_empty_default_9);  new_empty_default_9 = None
        as_strided_default_28 = torch.ops.aten.as_strided.default(zero__default_9, [1, 2048, 64, 64], [8388608, 4096, 64, 1], 0);  zero__default_9 = None
        new_empty_strided_default_9 = torch.ops.aten.new_empty_strided.default(as_strided_default_28, [1, 2048, 64, 64], [8388608, 4096, 64, 1])
        copy__default_62 = torch.ops.aten.copy_.default(new_empty_strided_default_9, as_strided_default_28);  new_empty_strided_default_9 = as_strided_default_28 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(copy__default_62, view_default_5, repeat_default_5, repeat_default_7, repeat_default_8, new_zeros_default_3, new_zeros_default_4, False, 1e-05, [True, True, True]);  copy__default_62 = view_default_5 = repeat_default_5 = repeat_default_7 = repeat_default_8 = new_zeros_default_3 = new_zeros_default_4 = None
        getitem_144 = native_batch_norm_backward_default_15[0]
        getitem_145 = native_batch_norm_backward_default_15[1]
        getitem_146 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        view_default_120 = torch.ops.aten.view.default(getitem_144, [16, 128, 64, 64]);  getitem_144 = None
        view_default_121 = torch.ops.aten.view.default(getitem_146, [16, 128]);  getitem_146 = None
        sum_dim_int_list_30 = torch.ops.aten.sum.dim_IntList(view_default_121, [0]);  view_default_121 = None
        view_default_122 = torch.ops.aten.view.default(getitem_145, [16, 128]);  getitem_145 = None
        sum_dim_int_list_31 = torch.ops.aten.sum.dim_IntList(view_default_122, [0]);  view_default_122 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(view_default_120, relu__default, primals_80, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_120 = relu__default = primals_80 = None
        getitem_147 = convolution_backward_default_16[0]
        getitem_148 = convolution_backward_default_16[1];  convolution_backward_default_16 = None
        new_empty_default_10 = torch.ops.aten.new_empty.default(getitem_147, [16777216]);  getitem_147 = None
        zero__default_10 = torch.ops.aten.zero_.default(new_empty_default_10);  new_empty_default_10 = None
        as_strided_default_31 = torch.ops.aten.as_strided.default(zero__default_10, [1, 1024, 128, 128], [16777216, 16384, 128, 1], 0);  zero__default_10 = None
        new_empty_strided_default_10 = torch.ops.aten.new_empty_strided.default(as_strided_default_31, [1, 1024, 128, 128], [16777216, 16384, 128, 1])
        copy__default_65 = torch.ops.aten.copy_.default(new_empty_strided_default_10, as_strided_default_31);  new_empty_strided_default_10 = as_strided_default_31 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(copy__default_65, view_default_1, repeat_default_1, repeat_default_3, repeat_default_4, new_zeros_default, new_zeros_default_1, False, 1e-05, [True, True, True]);  copy__default_65 = view_default_1 = repeat_default_1 = repeat_default_3 = repeat_default_4 = new_zeros_default = new_zeros_default_1 = None
        getitem_150 = native_batch_norm_backward_default_16[0]
        getitem_151 = native_batch_norm_backward_default_16[1]
        getitem_152 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        view_default_123 = torch.ops.aten.view.default(getitem_150, [16, 64, 128, 128]);  getitem_150 = None
        view_default_124 = torch.ops.aten.view.default(getitem_152, [16, 64]);  getitem_152 = None
        sum_dim_int_list_32 = torch.ops.aten.sum.dim_IntList(view_default_124, [0]);  view_default_124 = None
        view_default_125 = torch.ops.aten.view.default(getitem_151, [16, 64]);  getitem_151 = None
        sum_dim_int_list_33 = torch.ops.aten.sum.dim_IntList(view_default_125, [0]);  view_default_125 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(view_default_123, cat_default, primals_1, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 1, [False, True, False]);  view_default_123 = cat_default = primals_1 = None
        getitem_154 = convolution_backward_default_17[1];  convolution_backward_default_17 = None
        return [getitem_154, sum_dim_int_list_32, None, None, None, sum_dim_int_list_33, getitem_124, sum_dim_int_list_22, None, None, None, sum_dim_int_list_23, getitem_118, sum_dim_int_list_20, None, None, None, sum_dim_int_list_21, getitem_112, sum_dim_int_list_18, None, None, None, sum_dim_int_list_19, getitem_106, sum_dim_int_list_16, None, None, None, sum_dim_int_list_17, getitem_100, sum_dim_int_list_14, None, None, None, sum_dim_int_list_15, getitem_94, sum_dim_int_list_12, None, None, None, sum_dim_int_list_13, getitem_88, sum_dim_int_list_10, None, None, None, sum_dim_int_list_11, getitem_82, sum_dim_int_list_8, None, None, None, sum_dim_int_list_9, getitem_76, sum_dim_int_list_6, None, None, None, sum_dim_int_list_7, getitem_70, sum_dim_int_list_4, None, None, None, sum_dim_int_list_5, getitem_64, sum_dim_int_list_2, None, None, None, sum_dim_int_list_3, getitem_58, sum_dim_int_list, None, None, None, sum_dim_int_list_1, getitem_52, getitem_148, sum_dim_int_list_30, None, None, None, sum_dim_int_list_31, getitem_142, sum_dim_int_list_28, None, None, None, sum_dim_int_list_29, getitem_136, sum_dim_int_list_26, None, None, None, sum_dim_int_list_27, getitem_130, sum_dim_int_list_24, None, None, None, sum_dim_int_list_25, None, None]
        
