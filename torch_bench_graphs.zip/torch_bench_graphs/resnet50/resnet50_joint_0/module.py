
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/resnet50/resnet50_joint_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, tangents_1):
        convolution_default = torch.ops.aten.convolution.default(primals_321, primals_6, None, [2, 2], [3, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_5, primals_1, primals_3, primals_4, False, 0.1, 1e-05);  primals_1 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        new_zeros_default = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_2 = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu__default, [3, 3], [2, 2], [1, 1])
        getitem_3 = max_pool2d_with_indices_default[0]
        getitem_4 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_1 = torch.ops.aten.convolution.default(getitem_3, primals_24, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_13, primals_9, primals_11, primals_12, False, 0.1, 1e-05);  primals_9 = None
        getitem_5 = native_batch_norm_default_1[0]
        getitem_6 = native_batch_norm_default_1[1]
        getitem_7 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_5 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_1 = torch.ops.aten.relu_.default(getitem_5);  getitem_5 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_25, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_18, primals_14, primals_16, primals_17, False, 0.1, 1e-05);  primals_14 = None
        getitem_8 = native_batch_norm_default_2[0]
        getitem_9 = native_batch_norm_default_2[1]
        getitem_10 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_8 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_2 = torch.ops.aten.relu_.default(getitem_8);  getitem_8 = None
        convolution_default_3 = torch.ops.aten.convolution.default(relu__default_2, primals_26, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_23, primals_19, primals_21, primals_22, False, 0.1, 1e-05);  primals_19 = None
        getitem_11 = native_batch_norm_default_3[0]
        getitem_12 = native_batch_norm_default_3[1]
        getitem_13 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        new_zeros_default_9 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_10 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_11 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_4 = torch.ops.aten.convolution.default(getitem_3, primals_27, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_32, primals_28, primals_30, primals_31, False, 0.1, 1e-05);  primals_28 = None
        getitem_14 = native_batch_norm_default_4[0]
        getitem_15 = native_batch_norm_default_4[1]
        getitem_16 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        new_zeros_default_12 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_13 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_14 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor = torch.ops.aten.add_.Tensor(getitem_11, getitem_14);  getitem_11 = getitem_14 = None
        relu__default_3 = torch.ops.aten.relu_.default(add__tensor);  add__tensor = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_3, primals_48, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_37, primals_33, primals_35, primals_36, False, 0.1, 1e-05);  primals_33 = None
        getitem_17 = native_batch_norm_default_5[0]
        getitem_18 = native_batch_norm_default_5[1]
        getitem_19 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        new_zeros_default_15 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_16 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_17 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_4 = torch.ops.aten.relu_.default(getitem_17);  getitem_17 = None
        convolution_default_6 = torch.ops.aten.convolution.default(relu__default_4, primals_49, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_42, primals_38, primals_40, primals_41, False, 0.1, 1e-05);  primals_38 = None
        getitem_20 = native_batch_norm_default_6[0]
        getitem_21 = native_batch_norm_default_6[1]
        getitem_22 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        new_zeros_default_18 = torch.ops.aten.new_zeros.default(convolution_default_6, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_19 = torch.ops.aten.new_zeros.default(convolution_default_6, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_20 = torch.ops.aten.new_zeros.default(convolution_default_6, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_5 = torch.ops.aten.relu_.default(getitem_20);  getitem_20 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_5, primals_50, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_47, primals_43, primals_45, primals_46, False, 0.1, 1e-05);  primals_43 = None
        getitem_23 = native_batch_norm_default_7[0]
        getitem_24 = native_batch_norm_default_7[1]
        getitem_25 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        new_zeros_default_21 = torch.ops.aten.new_zeros.default(convolution_default_7, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_22 = torch.ops.aten.new_zeros.default(convolution_default_7, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_23 = torch.ops.aten.new_zeros.default(convolution_default_7, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_1 = torch.ops.aten.add_.Tensor(getitem_23, relu__default_3);  getitem_23 = None
        relu__default_6 = torch.ops.aten.relu_.default(add__tensor_1);  add__tensor_1 = None
        convolution_default_8 = torch.ops.aten.convolution.default(relu__default_6, primals_66, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_55, primals_51, primals_53, primals_54, False, 0.1, 1e-05);  primals_51 = None
        getitem_26 = native_batch_norm_default_8[0]
        getitem_27 = native_batch_norm_default_8[1]
        getitem_28 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        new_zeros_default_24 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_25 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_26 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_7 = torch.ops.aten.relu_.default(getitem_26);  getitem_26 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_7, primals_67, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_60, primals_56, primals_58, primals_59, False, 0.1, 1e-05);  primals_56 = None
        getitem_29 = native_batch_norm_default_9[0]
        getitem_30 = native_batch_norm_default_9[1]
        getitem_31 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        new_zeros_default_27 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_28 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_29 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_8 = torch.ops.aten.relu_.default(getitem_29);  getitem_29 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default_8, primals_68, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_65, primals_61, primals_63, primals_64, False, 0.1, 1e-05);  primals_61 = None
        getitem_32 = native_batch_norm_default_10[0]
        getitem_33 = native_batch_norm_default_10[1]
        getitem_34 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        new_zeros_default_30 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_31 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_32 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_2 = torch.ops.aten.add_.Tensor(getitem_32, relu__default_6);  getitem_32 = None
        relu__default_9 = torch.ops.aten.relu_.default(add__tensor_2);  add__tensor_2 = None
        convolution_default_11 = torch.ops.aten.convolution.default(relu__default_9, primals_84, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_73, primals_69, primals_71, primals_72, False, 0.1, 1e-05);  primals_69 = None
        getitem_35 = native_batch_norm_default_11[0]
        getitem_36 = native_batch_norm_default_11[1]
        getitem_37 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        new_zeros_default_33 = torch.ops.aten.new_zeros.default(convolution_default_11, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_34 = torch.ops.aten.new_zeros.default(convolution_default_11, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_35 = torch.ops.aten.new_zeros.default(convolution_default_11, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_10 = torch.ops.aten.relu_.default(getitem_35);  getitem_35 = None
        convolution_default_12 = torch.ops.aten.convolution.default(relu__default_10, primals_85, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_78, primals_74, primals_76, primals_77, False, 0.1, 1e-05);  primals_74 = None
        getitem_38 = native_batch_norm_default_12[0]
        getitem_39 = native_batch_norm_default_12[1]
        getitem_40 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        new_zeros_default_36 = torch.ops.aten.new_zeros.default(convolution_default_12, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_37 = torch.ops.aten.new_zeros.default(convolution_default_12, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_38 = torch.ops.aten.new_zeros.default(convolution_default_12, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_11 = torch.ops.aten.relu_.default(getitem_38);  getitem_38 = None
        convolution_default_13 = torch.ops.aten.convolution.default(relu__default_11, primals_86, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_83, primals_79, primals_81, primals_82, False, 0.1, 1e-05);  primals_79 = None
        getitem_41 = native_batch_norm_default_13[0]
        getitem_42 = native_batch_norm_default_13[1]
        getitem_43 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        new_zeros_default_39 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_40 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_41 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_14 = torch.ops.aten.convolution.default(relu__default_9, primals_87, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_92, primals_88, primals_90, primals_91, False, 0.1, 1e-05);  primals_88 = None
        getitem_44 = native_batch_norm_default_14[0]
        getitem_45 = native_batch_norm_default_14[1]
        getitem_46 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        new_zeros_default_42 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_43 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_44 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_3 = torch.ops.aten.add_.Tensor(getitem_41, getitem_44);  getitem_41 = getitem_44 = None
        relu__default_12 = torch.ops.aten.relu_.default(add__tensor_3);  add__tensor_3 = None
        convolution_default_15 = torch.ops.aten.convolution.default(relu__default_12, primals_108, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_97, primals_93, primals_95, primals_96, False, 0.1, 1e-05);  primals_93 = None
        getitem_47 = native_batch_norm_default_15[0]
        getitem_48 = native_batch_norm_default_15[1]
        getitem_49 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        new_zeros_default_45 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_46 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_47 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_13 = torch.ops.aten.relu_.default(getitem_47);  getitem_47 = None
        convolution_default_16 = torch.ops.aten.convolution.default(relu__default_13, primals_109, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_102, primals_98, primals_100, primals_101, False, 0.1, 1e-05);  primals_98 = None
        getitem_50 = native_batch_norm_default_16[0]
        getitem_51 = native_batch_norm_default_16[1]
        getitem_52 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        new_zeros_default_48 = torch.ops.aten.new_zeros.default(convolution_default_16, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_49 = torch.ops.aten.new_zeros.default(convolution_default_16, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_50 = torch.ops.aten.new_zeros.default(convolution_default_16, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_14 = torch.ops.aten.relu_.default(getitem_50);  getitem_50 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu__default_14, primals_110, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_107, primals_103, primals_105, primals_106, False, 0.1, 1e-05);  primals_103 = None
        getitem_53 = native_batch_norm_default_17[0]
        getitem_54 = native_batch_norm_default_17[1]
        getitem_55 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        new_zeros_default_51 = torch.ops.aten.new_zeros.default(convolution_default_17, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_52 = torch.ops.aten.new_zeros.default(convolution_default_17, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_53 = torch.ops.aten.new_zeros.default(convolution_default_17, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_4 = torch.ops.aten.add_.Tensor(getitem_53, relu__default_12);  getitem_53 = None
        relu__default_15 = torch.ops.aten.relu_.default(add__tensor_4);  add__tensor_4 = None
        convolution_default_18 = torch.ops.aten.convolution.default(relu__default_15, primals_126, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_115, primals_111, primals_113, primals_114, False, 0.1, 1e-05);  primals_111 = None
        getitem_56 = native_batch_norm_default_18[0]
        getitem_57 = native_batch_norm_default_18[1]
        getitem_58 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        new_zeros_default_54 = torch.ops.aten.new_zeros.default(convolution_default_18, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_55 = torch.ops.aten.new_zeros.default(convolution_default_18, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_56 = torch.ops.aten.new_zeros.default(convolution_default_18, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_16 = torch.ops.aten.relu_.default(getitem_56);  getitem_56 = None
        convolution_default_19 = torch.ops.aten.convolution.default(relu__default_16, primals_127, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_120, primals_116, primals_118, primals_119, False, 0.1, 1e-05);  primals_116 = None
        getitem_59 = native_batch_norm_default_19[0]
        getitem_60 = native_batch_norm_default_19[1]
        getitem_61 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        new_zeros_default_57 = torch.ops.aten.new_zeros.default(convolution_default_19, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_58 = torch.ops.aten.new_zeros.default(convolution_default_19, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_59 = torch.ops.aten.new_zeros.default(convolution_default_19, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_17 = torch.ops.aten.relu_.default(getitem_59);  getitem_59 = None
        convolution_default_20 = torch.ops.aten.convolution.default(relu__default_17, primals_128, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_125, primals_121, primals_123, primals_124, False, 0.1, 1e-05);  primals_121 = None
        getitem_62 = native_batch_norm_default_20[0]
        getitem_63 = native_batch_norm_default_20[1]
        getitem_64 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        new_zeros_default_60 = torch.ops.aten.new_zeros.default(convolution_default_20, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_61 = torch.ops.aten.new_zeros.default(convolution_default_20, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_62 = torch.ops.aten.new_zeros.default(convolution_default_20, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_5 = torch.ops.aten.add_.Tensor(getitem_62, relu__default_15);  getitem_62 = None
        relu__default_18 = torch.ops.aten.relu_.default(add__tensor_5);  add__tensor_5 = None
        convolution_default_21 = torch.ops.aten.convolution.default(relu__default_18, primals_144, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_133, primals_129, primals_131, primals_132, False, 0.1, 1e-05);  primals_129 = None
        getitem_65 = native_batch_norm_default_21[0]
        getitem_66 = native_batch_norm_default_21[1]
        getitem_67 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        new_zeros_default_63 = torch.ops.aten.new_zeros.default(convolution_default_21, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_64 = torch.ops.aten.new_zeros.default(convolution_default_21, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_65 = torch.ops.aten.new_zeros.default(convolution_default_21, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_19 = torch.ops.aten.relu_.default(getitem_65);  getitem_65 = None
        convolution_default_22 = torch.ops.aten.convolution.default(relu__default_19, primals_145, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_138, primals_134, primals_136, primals_137, False, 0.1, 1e-05);  primals_134 = None
        getitem_68 = native_batch_norm_default_22[0]
        getitem_69 = native_batch_norm_default_22[1]
        getitem_70 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        new_zeros_default_66 = torch.ops.aten.new_zeros.default(convolution_default_22, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_67 = torch.ops.aten.new_zeros.default(convolution_default_22, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_68 = torch.ops.aten.new_zeros.default(convolution_default_22, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_20 = torch.ops.aten.relu_.default(getitem_68);  getitem_68 = None
        convolution_default_23 = torch.ops.aten.convolution.default(relu__default_20, primals_146, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_143, primals_139, primals_141, primals_142, False, 0.1, 1e-05);  primals_139 = None
        getitem_71 = native_batch_norm_default_23[0]
        getitem_72 = native_batch_norm_default_23[1]
        getitem_73 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        new_zeros_default_69 = torch.ops.aten.new_zeros.default(convolution_default_23, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_70 = torch.ops.aten.new_zeros.default(convolution_default_23, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_71 = torch.ops.aten.new_zeros.default(convolution_default_23, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_6 = torch.ops.aten.add_.Tensor(getitem_71, relu__default_18);  getitem_71 = None
        relu__default_21 = torch.ops.aten.relu_.default(add__tensor_6);  add__tensor_6 = None
        convolution_default_24 = torch.ops.aten.convolution.default(relu__default_21, primals_162, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_151, primals_147, primals_149, primals_150, False, 0.1, 1e-05);  primals_147 = None
        getitem_74 = native_batch_norm_default_24[0]
        getitem_75 = native_batch_norm_default_24[1]
        getitem_76 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        new_zeros_default_72 = torch.ops.aten.new_zeros.default(convolution_default_24, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_73 = torch.ops.aten.new_zeros.default(convolution_default_24, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_74 = torch.ops.aten.new_zeros.default(convolution_default_24, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_22 = torch.ops.aten.relu_.default(getitem_74);  getitem_74 = None
        convolution_default_25 = torch.ops.aten.convolution.default(relu__default_22, primals_163, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_156, primals_152, primals_154, primals_155, False, 0.1, 1e-05);  primals_152 = None
        getitem_77 = native_batch_norm_default_25[0]
        getitem_78 = native_batch_norm_default_25[1]
        getitem_79 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        new_zeros_default_75 = torch.ops.aten.new_zeros.default(convolution_default_25, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_76 = torch.ops.aten.new_zeros.default(convolution_default_25, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_77 = torch.ops.aten.new_zeros.default(convolution_default_25, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_23 = torch.ops.aten.relu_.default(getitem_77);  getitem_77 = None
        convolution_default_26 = torch.ops.aten.convolution.default(relu__default_23, primals_164, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_161, primals_157, primals_159, primals_160, False, 0.1, 1e-05);  primals_157 = None
        getitem_80 = native_batch_norm_default_26[0]
        getitem_81 = native_batch_norm_default_26[1]
        getitem_82 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        new_zeros_default_78 = torch.ops.aten.new_zeros.default(convolution_default_26, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_79 = torch.ops.aten.new_zeros.default(convolution_default_26, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_80 = torch.ops.aten.new_zeros.default(convolution_default_26, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_27 = torch.ops.aten.convolution.default(relu__default_21, primals_165, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_170, primals_166, primals_168, primals_169, False, 0.1, 1e-05);  primals_166 = None
        getitem_83 = native_batch_norm_default_27[0]
        getitem_84 = native_batch_norm_default_27[1]
        getitem_85 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        new_zeros_default_81 = torch.ops.aten.new_zeros.default(convolution_default_27, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_82 = torch.ops.aten.new_zeros.default(convolution_default_27, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_83 = torch.ops.aten.new_zeros.default(convolution_default_27, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_7 = torch.ops.aten.add_.Tensor(getitem_80, getitem_83);  getitem_80 = getitem_83 = None
        relu__default_24 = torch.ops.aten.relu_.default(add__tensor_7);  add__tensor_7 = None
        convolution_default_28 = torch.ops.aten.convolution.default(relu__default_24, primals_186, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_175, primals_171, primals_173, primals_174, False, 0.1, 1e-05);  primals_171 = None
        getitem_86 = native_batch_norm_default_28[0]
        getitem_87 = native_batch_norm_default_28[1]
        getitem_88 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        new_zeros_default_84 = torch.ops.aten.new_zeros.default(convolution_default_28, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_85 = torch.ops.aten.new_zeros.default(convolution_default_28, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_86 = torch.ops.aten.new_zeros.default(convolution_default_28, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_25 = torch.ops.aten.relu_.default(getitem_86);  getitem_86 = None
        convolution_default_29 = torch.ops.aten.convolution.default(relu__default_25, primals_187, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_180, primals_176, primals_178, primals_179, False, 0.1, 1e-05);  primals_176 = None
        getitem_89 = native_batch_norm_default_29[0]
        getitem_90 = native_batch_norm_default_29[1]
        getitem_91 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        new_zeros_default_87 = torch.ops.aten.new_zeros.default(convolution_default_29, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_88 = torch.ops.aten.new_zeros.default(convolution_default_29, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_89 = torch.ops.aten.new_zeros.default(convolution_default_29, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_26 = torch.ops.aten.relu_.default(getitem_89);  getitem_89 = None
        convolution_default_30 = torch.ops.aten.convolution.default(relu__default_26, primals_188, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_185, primals_181, primals_183, primals_184, False, 0.1, 1e-05);  primals_181 = None
        getitem_92 = native_batch_norm_default_30[0]
        getitem_93 = native_batch_norm_default_30[1]
        getitem_94 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        new_zeros_default_90 = torch.ops.aten.new_zeros.default(convolution_default_30, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_91 = torch.ops.aten.new_zeros.default(convolution_default_30, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_92 = torch.ops.aten.new_zeros.default(convolution_default_30, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_8 = torch.ops.aten.add_.Tensor(getitem_92, relu__default_24);  getitem_92 = None
        relu__default_27 = torch.ops.aten.relu_.default(add__tensor_8);  add__tensor_8 = None
        convolution_default_31 = torch.ops.aten.convolution.default(relu__default_27, primals_204, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_31, primals_193, primals_189, primals_191, primals_192, False, 0.1, 1e-05);  primals_189 = None
        getitem_95 = native_batch_norm_default_31[0]
        getitem_96 = native_batch_norm_default_31[1]
        getitem_97 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        new_zeros_default_93 = torch.ops.aten.new_zeros.default(convolution_default_31, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_94 = torch.ops.aten.new_zeros.default(convolution_default_31, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_95 = torch.ops.aten.new_zeros.default(convolution_default_31, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_28 = torch.ops.aten.relu_.default(getitem_95);  getitem_95 = None
        convolution_default_32 = torch.ops.aten.convolution.default(relu__default_28, primals_205, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_198, primals_194, primals_196, primals_197, False, 0.1, 1e-05);  primals_194 = None
        getitem_98 = native_batch_norm_default_32[0]
        getitem_99 = native_batch_norm_default_32[1]
        getitem_100 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        new_zeros_default_96 = torch.ops.aten.new_zeros.default(convolution_default_32, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_97 = torch.ops.aten.new_zeros.default(convolution_default_32, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_98 = torch.ops.aten.new_zeros.default(convolution_default_32, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_29 = torch.ops.aten.relu_.default(getitem_98);  getitem_98 = None
        convolution_default_33 = torch.ops.aten.convolution.default(relu__default_29, primals_206, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_203, primals_199, primals_201, primals_202, False, 0.1, 1e-05);  primals_199 = None
        getitem_101 = native_batch_norm_default_33[0]
        getitem_102 = native_batch_norm_default_33[1]
        getitem_103 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        new_zeros_default_99 = torch.ops.aten.new_zeros.default(convolution_default_33, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_100 = torch.ops.aten.new_zeros.default(convolution_default_33, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_101 = torch.ops.aten.new_zeros.default(convolution_default_33, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_9 = torch.ops.aten.add_.Tensor(getitem_101, relu__default_27);  getitem_101 = None
        relu__default_30 = torch.ops.aten.relu_.default(add__tensor_9);  add__tensor_9 = None
        convolution_default_34 = torch.ops.aten.convolution.default(relu__default_30, primals_222, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_211, primals_207, primals_209, primals_210, False, 0.1, 1e-05);  primals_207 = None
        getitem_104 = native_batch_norm_default_34[0]
        getitem_105 = native_batch_norm_default_34[1]
        getitem_106 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        new_zeros_default_102 = torch.ops.aten.new_zeros.default(convolution_default_34, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_103 = torch.ops.aten.new_zeros.default(convolution_default_34, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_104 = torch.ops.aten.new_zeros.default(convolution_default_34, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_31 = torch.ops.aten.relu_.default(getitem_104);  getitem_104 = None
        convolution_default_35 = torch.ops.aten.convolution.default(relu__default_31, primals_223, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_216, primals_212, primals_214, primals_215, False, 0.1, 1e-05);  primals_212 = None
        getitem_107 = native_batch_norm_default_35[0]
        getitem_108 = native_batch_norm_default_35[1]
        getitem_109 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        new_zeros_default_105 = torch.ops.aten.new_zeros.default(convolution_default_35, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_106 = torch.ops.aten.new_zeros.default(convolution_default_35, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_107 = torch.ops.aten.new_zeros.default(convolution_default_35, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_32 = torch.ops.aten.relu_.default(getitem_107);  getitem_107 = None
        convolution_default_36 = torch.ops.aten.convolution.default(relu__default_32, primals_224, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_221, primals_217, primals_219, primals_220, False, 0.1, 1e-05);  primals_217 = None
        getitem_110 = native_batch_norm_default_36[0]
        getitem_111 = native_batch_norm_default_36[1]
        getitem_112 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        new_zeros_default_108 = torch.ops.aten.new_zeros.default(convolution_default_36, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_109 = torch.ops.aten.new_zeros.default(convolution_default_36, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_110 = torch.ops.aten.new_zeros.default(convolution_default_36, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_10 = torch.ops.aten.add_.Tensor(getitem_110, relu__default_30);  getitem_110 = None
        relu__default_33 = torch.ops.aten.relu_.default(add__tensor_10);  add__tensor_10 = None
        convolution_default_37 = torch.ops.aten.convolution.default(relu__default_33, primals_240, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_37, primals_229, primals_225, primals_227, primals_228, False, 0.1, 1e-05);  primals_225 = None
        getitem_113 = native_batch_norm_default_37[0]
        getitem_114 = native_batch_norm_default_37[1]
        getitem_115 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        new_zeros_default_111 = torch.ops.aten.new_zeros.default(convolution_default_37, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_112 = torch.ops.aten.new_zeros.default(convolution_default_37, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_113 = torch.ops.aten.new_zeros.default(convolution_default_37, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_34 = torch.ops.aten.relu_.default(getitem_113);  getitem_113 = None
        convolution_default_38 = torch.ops.aten.convolution.default(relu__default_34, primals_241, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_234, primals_230, primals_232, primals_233, False, 0.1, 1e-05);  primals_230 = None
        getitem_116 = native_batch_norm_default_38[0]
        getitem_117 = native_batch_norm_default_38[1]
        getitem_118 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        new_zeros_default_114 = torch.ops.aten.new_zeros.default(convolution_default_38, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_115 = torch.ops.aten.new_zeros.default(convolution_default_38, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_116 = torch.ops.aten.new_zeros.default(convolution_default_38, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_35 = torch.ops.aten.relu_.default(getitem_116);  getitem_116 = None
        convolution_default_39 = torch.ops.aten.convolution.default(relu__default_35, primals_242, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_39, primals_239, primals_235, primals_237, primals_238, False, 0.1, 1e-05);  primals_235 = None
        getitem_119 = native_batch_norm_default_39[0]
        getitem_120 = native_batch_norm_default_39[1]
        getitem_121 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        new_zeros_default_117 = torch.ops.aten.new_zeros.default(convolution_default_39, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_118 = torch.ops.aten.new_zeros.default(convolution_default_39, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_119 = torch.ops.aten.new_zeros.default(convolution_default_39, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_11 = torch.ops.aten.add_.Tensor(getitem_119, relu__default_33);  getitem_119 = None
        relu__default_36 = torch.ops.aten.relu_.default(add__tensor_11);  add__tensor_11 = None
        convolution_default_40 = torch.ops.aten.convolution.default(relu__default_36, primals_258, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_247, primals_243, primals_245, primals_246, False, 0.1, 1e-05);  primals_243 = None
        getitem_122 = native_batch_norm_default_40[0]
        getitem_123 = native_batch_norm_default_40[1]
        getitem_124 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        new_zeros_default_120 = torch.ops.aten.new_zeros.default(convolution_default_40, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_121 = torch.ops.aten.new_zeros.default(convolution_default_40, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_122 = torch.ops.aten.new_zeros.default(convolution_default_40, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_37 = torch.ops.aten.relu_.default(getitem_122);  getitem_122 = None
        convolution_default_41 = torch.ops.aten.convolution.default(relu__default_37, primals_259, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_41, primals_252, primals_248, primals_250, primals_251, False, 0.1, 1e-05);  primals_248 = None
        getitem_125 = native_batch_norm_default_41[0]
        getitem_126 = native_batch_norm_default_41[1]
        getitem_127 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        new_zeros_default_123 = torch.ops.aten.new_zeros.default(convolution_default_41, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_124 = torch.ops.aten.new_zeros.default(convolution_default_41, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_125 = torch.ops.aten.new_zeros.default(convolution_default_41, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_38 = torch.ops.aten.relu_.default(getitem_125);  getitem_125 = None
        convolution_default_42 = torch.ops.aten.convolution.default(relu__default_38, primals_260, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_42, primals_257, primals_253, primals_255, primals_256, False, 0.1, 1e-05);  primals_253 = None
        getitem_128 = native_batch_norm_default_42[0]
        getitem_129 = native_batch_norm_default_42[1]
        getitem_130 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        new_zeros_default_126 = torch.ops.aten.new_zeros.default(convolution_default_42, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_127 = torch.ops.aten.new_zeros.default(convolution_default_42, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_128 = torch.ops.aten.new_zeros.default(convolution_default_42, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_12 = torch.ops.aten.add_.Tensor(getitem_128, relu__default_36);  getitem_128 = None
        relu__default_39 = torch.ops.aten.relu_.default(add__tensor_12);  add__tensor_12 = None
        convolution_default_43 = torch.ops.aten.convolution.default(relu__default_39, primals_276, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_43, primals_265, primals_261, primals_263, primals_264, False, 0.1, 1e-05);  primals_261 = None
        getitem_131 = native_batch_norm_default_43[0]
        getitem_132 = native_batch_norm_default_43[1]
        getitem_133 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        new_zeros_default_129 = torch.ops.aten.new_zeros.default(convolution_default_43, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_130 = torch.ops.aten.new_zeros.default(convolution_default_43, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_131 = torch.ops.aten.new_zeros.default(convolution_default_43, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_40 = torch.ops.aten.relu_.default(getitem_131);  getitem_131 = None
        convolution_default_44 = torch.ops.aten.convolution.default(relu__default_40, primals_277, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_270, primals_266, primals_268, primals_269, False, 0.1, 1e-05);  primals_266 = None
        getitem_134 = native_batch_norm_default_44[0]
        getitem_135 = native_batch_norm_default_44[1]
        getitem_136 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        new_zeros_default_132 = torch.ops.aten.new_zeros.default(convolution_default_44, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_133 = torch.ops.aten.new_zeros.default(convolution_default_44, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_134 = torch.ops.aten.new_zeros.default(convolution_default_44, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_41 = torch.ops.aten.relu_.default(getitem_134);  getitem_134 = None
        convolution_default_45 = torch.ops.aten.convolution.default(relu__default_41, primals_278, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_45, primals_275, primals_271, primals_273, primals_274, False, 0.1, 1e-05);  primals_271 = None
        getitem_137 = native_batch_norm_default_45[0]
        getitem_138 = native_batch_norm_default_45[1]
        getitem_139 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        new_zeros_default_135 = torch.ops.aten.new_zeros.default(convolution_default_45, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_136 = torch.ops.aten.new_zeros.default(convolution_default_45, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_137 = torch.ops.aten.new_zeros.default(convolution_default_45, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_46 = torch.ops.aten.convolution.default(relu__default_39, primals_279, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(convolution_default_46, primals_284, primals_280, primals_282, primals_283, False, 0.1, 1e-05);  primals_280 = None
        getitem_140 = native_batch_norm_default_46[0]
        getitem_141 = native_batch_norm_default_46[1]
        getitem_142 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        new_zeros_default_138 = torch.ops.aten.new_zeros.default(convolution_default_46, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_139 = torch.ops.aten.new_zeros.default(convolution_default_46, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_140 = torch.ops.aten.new_zeros.default(convolution_default_46, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_13 = torch.ops.aten.add_.Tensor(getitem_137, getitem_140);  getitem_137 = getitem_140 = None
        relu__default_42 = torch.ops.aten.relu_.default(add__tensor_13);  add__tensor_13 = None
        convolution_default_47 = torch.ops.aten.convolution.default(relu__default_42, primals_300, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(convolution_default_47, primals_289, primals_285, primals_287, primals_288, False, 0.1, 1e-05);  primals_285 = None
        getitem_143 = native_batch_norm_default_47[0]
        getitem_144 = native_batch_norm_default_47[1]
        getitem_145 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        new_zeros_default_141 = torch.ops.aten.new_zeros.default(convolution_default_47, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_142 = torch.ops.aten.new_zeros.default(convolution_default_47, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_143 = torch.ops.aten.new_zeros.default(convolution_default_47, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_43 = torch.ops.aten.relu_.default(getitem_143);  getitem_143 = None
        convolution_default_48 = torch.ops.aten.convolution.default(relu__default_43, primals_301, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_48, primals_294, primals_290, primals_292, primals_293, False, 0.1, 1e-05);  primals_290 = None
        getitem_146 = native_batch_norm_default_48[0]
        getitem_147 = native_batch_norm_default_48[1]
        getitem_148 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        new_zeros_default_144 = torch.ops.aten.new_zeros.default(convolution_default_48, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_145 = torch.ops.aten.new_zeros.default(convolution_default_48, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_146 = torch.ops.aten.new_zeros.default(convolution_default_48, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_44 = torch.ops.aten.relu_.default(getitem_146);  getitem_146 = None
        convolution_default_49 = torch.ops.aten.convolution.default(relu__default_44, primals_302, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(convolution_default_49, primals_299, primals_295, primals_297, primals_298, False, 0.1, 1e-05);  primals_295 = None
        getitem_149 = native_batch_norm_default_49[0]
        getitem_150 = native_batch_norm_default_49[1]
        getitem_151 = native_batch_norm_default_49[2];  native_batch_norm_default_49 = None
        new_zeros_default_147 = torch.ops.aten.new_zeros.default(convolution_default_49, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_148 = torch.ops.aten.new_zeros.default(convolution_default_49, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_149 = torch.ops.aten.new_zeros.default(convolution_default_49, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_14 = torch.ops.aten.add_.Tensor(getitem_149, relu__default_42);  getitem_149 = None
        relu__default_45 = torch.ops.aten.relu_.default(add__tensor_14);  add__tensor_14 = None
        convolution_default_50 = torch.ops.aten.convolution.default(relu__default_45, primals_318, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(convolution_default_50, primals_307, primals_303, primals_305, primals_306, False, 0.1, 1e-05);  primals_303 = None
        getitem_152 = native_batch_norm_default_50[0]
        getitem_153 = native_batch_norm_default_50[1]
        getitem_154 = native_batch_norm_default_50[2];  native_batch_norm_default_50 = None
        new_zeros_default_150 = torch.ops.aten.new_zeros.default(convolution_default_50, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_151 = torch.ops.aten.new_zeros.default(convolution_default_50, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_152 = torch.ops.aten.new_zeros.default(convolution_default_50, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_46 = torch.ops.aten.relu_.default(getitem_152);  getitem_152 = None
        convolution_default_51 = torch.ops.aten.convolution.default(relu__default_46, primals_319, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(convolution_default_51, primals_312, primals_308, primals_310, primals_311, False, 0.1, 1e-05);  primals_308 = None
        getitem_155 = native_batch_norm_default_51[0]
        getitem_156 = native_batch_norm_default_51[1]
        getitem_157 = native_batch_norm_default_51[2];  native_batch_norm_default_51 = None
        new_zeros_default_153 = torch.ops.aten.new_zeros.default(convolution_default_51, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_154 = torch.ops.aten.new_zeros.default(convolution_default_51, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_155 = torch.ops.aten.new_zeros.default(convolution_default_51, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_47 = torch.ops.aten.relu_.default(getitem_155);  getitem_155 = None
        convolution_default_52 = torch.ops.aten.convolution.default(relu__default_47, primals_320, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(convolution_default_52, primals_317, primals_313, primals_315, primals_316, False, 0.1, 1e-05);  primals_313 = None
        getitem_158 = native_batch_norm_default_52[0]
        getitem_159 = native_batch_norm_default_52[1]
        getitem_160 = native_batch_norm_default_52[2];  native_batch_norm_default_52 = None
        new_zeros_default_156 = torch.ops.aten.new_zeros.default(convolution_default_52, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_157 = torch.ops.aten.new_zeros.default(convolution_default_52, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_158 = torch.ops.aten.new_zeros.default(convolution_default_52, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_15 = torch.ops.aten.add_.Tensor(getitem_158, relu__default_45);  getitem_158 = None
        relu__default_48 = torch.ops.aten.relu_.default(add__tensor_15);  add__tensor_15 = None
        mean_dim = torch.ops.aten.mean.dim(relu__default_48, [-1, -2], True)
        view_default = torch.ops.aten.view.default(mean_dim, [32, 2048]);  mean_dim = None
        t_default = torch.ops.aten.t.default(primals_8);  primals_8 = None
        addmm_default = torch.ops.aten.addmm.default(primals_7, view_default, t_default);  primals_7 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(addmm_default, tangents_1)
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, view_default);  t_default_2 = view_default = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_1 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        view_default_2 = torch.ops.aten.view.default(mm_default, [32, 2048, 1, 1]);  mm_default = None
        expand_default = torch.ops.aten.expand.default(view_default_2, [32, 2048, 7, 7]);  view_default_2 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 49);  expand_default = None
        to_dtype = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default_48, torch.float32);  relu__default_48 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default_159 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_159, to_dtype);  le_scalar = new_zeros_default_159 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_2, convolution_default_52, primals_317, primals_315, primals_316, new_zeros_default_156, new_zeros_default_157, False, 1e-05, [True, True, True]);  convolution_default_52 = primals_317 = primals_315 = primals_316 = new_zeros_default_156 = new_zeros_default_157 = None
        getitem_161 = native_batch_norm_backward_default[0]
        getitem_162 = native_batch_norm_backward_default[1]
        getitem_163 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(getitem_161, relu__default_47, primals_320, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_161 = primals_320 = None
        getitem_164 = convolution_backward_default[0]
        getitem_165 = convolution_backward_default[1]
        getitem_166 = convolution_backward_default[2];  convolution_backward_default = None
        to_dtype_3 = torch.ops.aten.to.dtype(getitem_164, torch.float32);  getitem_164 = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu__default_47, torch.float32);  relu__default_47 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_160 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_160, to_dtype_3);  le_scalar_1 = new_zeros_default_160 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_5, convolution_default_51, primals_312, primals_310, primals_311, new_zeros_default_153, new_zeros_default_154, False, 1e-05, [True, True, True]);  to_dtype_5 = convolution_default_51 = primals_312 = primals_310 = primals_311 = new_zeros_default_153 = new_zeros_default_154 = None
        getitem_167 = native_batch_norm_backward_default_1[0]
        getitem_168 = native_batch_norm_backward_default_1[1]
        getitem_169 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_167, relu__default_46, primals_319, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_167 = primals_319 = None
        getitem_170 = convolution_backward_default_1[0]
        getitem_171 = convolution_backward_default_1[1]
        getitem_172 = convolution_backward_default_1[2];  convolution_backward_default_1 = None
        to_dtype_6 = torch.ops.aten.to.dtype(getitem_170, torch.float32);  getitem_170 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_46, torch.float32);  relu__default_46 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_161 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_161, to_dtype_6);  le_scalar_2 = new_zeros_default_161 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_8, convolution_default_50, primals_307, primals_305, primals_306, new_zeros_default_150, new_zeros_default_151, False, 1e-05, [True, True, True]);  to_dtype_8 = convolution_default_50 = primals_307 = primals_305 = primals_306 = new_zeros_default_150 = new_zeros_default_151 = None
        getitem_173 = native_batch_norm_backward_default_2[0]
        getitem_174 = native_batch_norm_backward_default_2[1]
        getitem_175 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_173, relu__default_45, primals_318, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_173 = primals_318 = None
        getitem_176 = convolution_backward_default_2[0]
        getitem_177 = convolution_backward_default_2[1]
        getitem_178 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        add_tensor = torch.ops.aten.add.Tensor(to_dtype_2, getitem_176);  to_dtype_2 = getitem_176 = None
        to_dtype_9 = torch.ops.aten.to.dtype(add_tensor, torch.float32);  add_tensor = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu__default_45, torch.float32);  relu__default_45 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_162 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_162, to_dtype_9);  le_scalar_3 = new_zeros_default_162 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_49, primals_299, primals_297, primals_298, new_zeros_default_147, new_zeros_default_148, False, 1e-05, [True, True, True]);  convolution_default_49 = primals_299 = primals_297 = primals_298 = new_zeros_default_147 = new_zeros_default_148 = None
        getitem_179 = native_batch_norm_backward_default_3[0]
        getitem_180 = native_batch_norm_backward_default_3[1]
        getitem_181 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_179, relu__default_44, primals_302, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_179 = primals_302 = None
        getitem_182 = convolution_backward_default_3[0]
        getitem_183 = convolution_backward_default_3[1]
        getitem_184 = convolution_backward_default_3[2];  convolution_backward_default_3 = None
        to_dtype_12 = torch.ops.aten.to.dtype(getitem_182, torch.float32);  getitem_182 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_44, torch.float32);  relu__default_44 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_163 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_163, to_dtype_12);  le_scalar_4 = new_zeros_default_163 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_48, primals_294, primals_292, primals_293, new_zeros_default_144, new_zeros_default_145, False, 1e-05, [True, True, True]);  to_dtype_14 = convolution_default_48 = primals_294 = primals_292 = primals_293 = new_zeros_default_144 = new_zeros_default_145 = None
        getitem_185 = native_batch_norm_backward_default_4[0]
        getitem_186 = native_batch_norm_backward_default_4[1]
        getitem_187 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_185, relu__default_43, primals_301, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_185 = primals_301 = None
        getitem_188 = convolution_backward_default_4[0]
        getitem_189 = convolution_backward_default_4[1]
        getitem_190 = convolution_backward_default_4[2];  convolution_backward_default_4 = None
        to_dtype_15 = torch.ops.aten.to.dtype(getitem_188, torch.float32);  getitem_188 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu__default_43, torch.float32);  relu__default_43 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_164 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_164, to_dtype_15);  le_scalar_5 = new_zeros_default_164 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_17, convolution_default_47, primals_289, primals_287, primals_288, new_zeros_default_141, new_zeros_default_142, False, 1e-05, [True, True, True]);  to_dtype_17 = convolution_default_47 = primals_289 = primals_287 = primals_288 = new_zeros_default_141 = new_zeros_default_142 = None
        getitem_191 = native_batch_norm_backward_default_5[0]
        getitem_192 = native_batch_norm_backward_default_5[1]
        getitem_193 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_191, relu__default_42, primals_300, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_191 = primals_300 = None
        getitem_194 = convolution_backward_default_5[0]
        getitem_195 = convolution_backward_default_5[1]
        getitem_196 = convolution_backward_default_5[2];  convolution_backward_default_5 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(to_dtype_11, getitem_194);  to_dtype_11 = getitem_194 = None
        to_dtype_18 = torch.ops.aten.to.dtype(add_tensor_1, torch.float32);  add_tensor_1 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu__default_42, torch.float32);  relu__default_42 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_165 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_165, to_dtype_18);  le_scalar_6 = new_zeros_default_165 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_20, convolution_default_46, primals_284, primals_282, primals_283, new_zeros_default_138, new_zeros_default_139, False, 1e-05, [True, True, True]);  convolution_default_46 = primals_284 = primals_282 = primals_283 = new_zeros_default_138 = new_zeros_default_139 = None
        getitem_197 = native_batch_norm_backward_default_6[0]
        getitem_198 = native_batch_norm_backward_default_6[1]
        getitem_199 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(getitem_197, relu__default_39, primals_279, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_197 = primals_279 = None
        getitem_200 = convolution_backward_default_6[0]
        getitem_201 = convolution_backward_default_6[1]
        getitem_202 = convolution_backward_default_6[2];  convolution_backward_default_6 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_20, convolution_default_45, primals_275, primals_273, primals_274, new_zeros_default_135, new_zeros_default_136, False, 1e-05, [True, True, True]);  to_dtype_20 = convolution_default_45 = primals_275 = primals_273 = primals_274 = new_zeros_default_135 = new_zeros_default_136 = None
        getitem_203 = native_batch_norm_backward_default_7[0]
        getitem_204 = native_batch_norm_backward_default_7[1]
        getitem_205 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(getitem_203, relu__default_41, primals_278, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_203 = primals_278 = None
        getitem_206 = convolution_backward_default_7[0]
        getitem_207 = convolution_backward_default_7[1]
        getitem_208 = convolution_backward_default_7[2];  convolution_backward_default_7 = None
        to_dtype_21 = torch.ops.aten.to.dtype(getitem_206, torch.float32);  getitem_206 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_41, torch.float32);  relu__default_41 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_166 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_166, to_dtype_21);  le_scalar_7 = new_zeros_default_166 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_23, convolution_default_44, primals_270, primals_268, primals_269, new_zeros_default_132, new_zeros_default_133, False, 1e-05, [True, True, True]);  to_dtype_23 = convolution_default_44 = primals_270 = primals_268 = primals_269 = new_zeros_default_132 = new_zeros_default_133 = None
        getitem_209 = native_batch_norm_backward_default_8[0]
        getitem_210 = native_batch_norm_backward_default_8[1]
        getitem_211 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(getitem_209, relu__default_40, primals_277, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_209 = primals_277 = None
        getitem_212 = convolution_backward_default_8[0]
        getitem_213 = convolution_backward_default_8[1]
        getitem_214 = convolution_backward_default_8[2];  convolution_backward_default_8 = None
        to_dtype_24 = torch.ops.aten.to.dtype(getitem_212, torch.float32);  getitem_212 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_40, torch.float32);  relu__default_40 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_167 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_167, to_dtype_24);  le_scalar_8 = new_zeros_default_167 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_43, primals_265, primals_263, primals_264, new_zeros_default_129, new_zeros_default_130, False, 1e-05, [True, True, True]);  to_dtype_26 = convolution_default_43 = primals_265 = primals_263 = primals_264 = new_zeros_default_129 = new_zeros_default_130 = None
        getitem_215 = native_batch_norm_backward_default_9[0]
        getitem_216 = native_batch_norm_backward_default_9[1]
        getitem_217 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_215, relu__default_39, primals_276, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_215 = primals_276 = None
        getitem_218 = convolution_backward_default_9[0]
        getitem_219 = convolution_backward_default_9[1]
        getitem_220 = convolution_backward_default_9[2];  convolution_backward_default_9 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(getitem_200, getitem_218);  getitem_200 = getitem_218 = None
        to_dtype_27 = torch.ops.aten.to.dtype(add_tensor_2, torch.float32);  add_tensor_2 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu__default_39, torch.float32);  relu__default_39 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_168 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_168, to_dtype_27);  le_scalar_9 = new_zeros_default_168 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_29, convolution_default_42, primals_257, primals_255, primals_256, new_zeros_default_126, new_zeros_default_127, False, 1e-05, [True, True, True]);  convolution_default_42 = primals_257 = primals_255 = primals_256 = new_zeros_default_126 = new_zeros_default_127 = None
        getitem_221 = native_batch_norm_backward_default_10[0]
        getitem_222 = native_batch_norm_backward_default_10[1]
        getitem_223 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_221, relu__default_38, primals_260, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_221 = primals_260 = None
        getitem_224 = convolution_backward_default_10[0]
        getitem_225 = convolution_backward_default_10[1]
        getitem_226 = convolution_backward_default_10[2];  convolution_backward_default_10 = None
        to_dtype_30 = torch.ops.aten.to.dtype(getitem_224, torch.float32);  getitem_224 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu__default_38, torch.float32);  relu__default_38 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_169 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_169, to_dtype_30);  le_scalar_10 = new_zeros_default_169 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default_41, primals_252, primals_250, primals_251, new_zeros_default_123, new_zeros_default_124, False, 1e-05, [True, True, True]);  to_dtype_32 = convolution_default_41 = primals_252 = primals_250 = primals_251 = new_zeros_default_123 = new_zeros_default_124 = None
        getitem_227 = native_batch_norm_backward_default_11[0]
        getitem_228 = native_batch_norm_backward_default_11[1]
        getitem_229 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_227, relu__default_37, primals_259, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_227 = primals_259 = None
        getitem_230 = convolution_backward_default_11[0]
        getitem_231 = convolution_backward_default_11[1]
        getitem_232 = convolution_backward_default_11[2];  convolution_backward_default_11 = None
        to_dtype_33 = torch.ops.aten.to.dtype(getitem_230, torch.float32);  getitem_230 = None
        to_dtype_34 = torch.ops.aten.to.dtype(relu__default_37, torch.float32);  relu__default_37 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        new_zeros_default_170 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_170, to_dtype_33);  le_scalar_11 = new_zeros_default_170 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_35, convolution_default_40, primals_247, primals_245, primals_246, new_zeros_default_120, new_zeros_default_121, False, 1e-05, [True, True, True]);  to_dtype_35 = convolution_default_40 = primals_247 = primals_245 = primals_246 = new_zeros_default_120 = new_zeros_default_121 = None
        getitem_233 = native_batch_norm_backward_default_12[0]
        getitem_234 = native_batch_norm_backward_default_12[1]
        getitem_235 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(getitem_233, relu__default_36, primals_258, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_233 = primals_258 = None
        getitem_236 = convolution_backward_default_12[0]
        getitem_237 = convolution_backward_default_12[1]
        getitem_238 = convolution_backward_default_12[2];  convolution_backward_default_12 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(to_dtype_29, getitem_236);  to_dtype_29 = getitem_236 = None
        to_dtype_36 = torch.ops.aten.to.dtype(add_tensor_3, torch.float32);  add_tensor_3 = None
        to_dtype_37 = torch.ops.aten.to.dtype(relu__default_36, torch.float32);  relu__default_36 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        new_zeros_default_171 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_171, to_dtype_36);  le_scalar_12 = new_zeros_default_171 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_38, convolution_default_39, primals_239, primals_237, primals_238, new_zeros_default_117, new_zeros_default_118, False, 1e-05, [True, True, True]);  convolution_default_39 = primals_239 = primals_237 = primals_238 = new_zeros_default_117 = new_zeros_default_118 = None
        getitem_239 = native_batch_norm_backward_default_13[0]
        getitem_240 = native_batch_norm_backward_default_13[1]
        getitem_241 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_239, relu__default_35, primals_242, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_239 = primals_242 = None
        getitem_242 = convolution_backward_default_13[0]
        getitem_243 = convolution_backward_default_13[1]
        getitem_244 = convolution_backward_default_13[2];  convolution_backward_default_13 = None
        to_dtype_39 = torch.ops.aten.to.dtype(getitem_242, torch.float32);  getitem_242 = None
        to_dtype_40 = torch.ops.aten.to.dtype(relu__default_35, torch.float32);  relu__default_35 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        new_zeros_default_172 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_172, to_dtype_39);  le_scalar_13 = new_zeros_default_172 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_41, convolution_default_38, primals_234, primals_232, primals_233, new_zeros_default_114, new_zeros_default_115, False, 1e-05, [True, True, True]);  to_dtype_41 = convolution_default_38 = primals_234 = primals_232 = primals_233 = new_zeros_default_114 = new_zeros_default_115 = None
        getitem_245 = native_batch_norm_backward_default_14[0]
        getitem_246 = native_batch_norm_backward_default_14[1]
        getitem_247 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_245, relu__default_34, primals_241, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_245 = primals_241 = None
        getitem_248 = convolution_backward_default_14[0]
        getitem_249 = convolution_backward_default_14[1]
        getitem_250 = convolution_backward_default_14[2];  convolution_backward_default_14 = None
        to_dtype_42 = torch.ops.aten.to.dtype(getitem_248, torch.float32);  getitem_248 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu__default_34, torch.float32);  relu__default_34 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_173 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_173, to_dtype_42);  le_scalar_14 = new_zeros_default_173 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_44, convolution_default_37, primals_229, primals_227, primals_228, new_zeros_default_111, new_zeros_default_112, False, 1e-05, [True, True, True]);  to_dtype_44 = convolution_default_37 = primals_229 = primals_227 = primals_228 = new_zeros_default_111 = new_zeros_default_112 = None
        getitem_251 = native_batch_norm_backward_default_15[0]
        getitem_252 = native_batch_norm_backward_default_15[1]
        getitem_253 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_251, relu__default_33, primals_240, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_251 = primals_240 = None
        getitem_254 = convolution_backward_default_15[0]
        getitem_255 = convolution_backward_default_15[1]
        getitem_256 = convolution_backward_default_15[2];  convolution_backward_default_15 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(to_dtype_38, getitem_254);  to_dtype_38 = getitem_254 = None
        to_dtype_45 = torch.ops.aten.to.dtype(add_tensor_4, torch.float32);  add_tensor_4 = None
        to_dtype_46 = torch.ops.aten.to.dtype(relu__default_33, torch.float32);  relu__default_33 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_46, 0);  to_dtype_46 = None
        new_zeros_default_174 = torch.ops.aten.new_zeros.default(to_dtype_45, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_174, to_dtype_45);  le_scalar_15 = new_zeros_default_174 = to_dtype_45 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_47, convolution_default_36, primals_221, primals_219, primals_220, new_zeros_default_108, new_zeros_default_109, False, 1e-05, [True, True, True]);  convolution_default_36 = primals_221 = primals_219 = primals_220 = new_zeros_default_108 = new_zeros_default_109 = None
        getitem_257 = native_batch_norm_backward_default_16[0]
        getitem_258 = native_batch_norm_backward_default_16[1]
        getitem_259 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(getitem_257, relu__default_32, primals_224, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_257 = primals_224 = None
        getitem_260 = convolution_backward_default_16[0]
        getitem_261 = convolution_backward_default_16[1]
        getitem_262 = convolution_backward_default_16[2];  convolution_backward_default_16 = None
        to_dtype_48 = torch.ops.aten.to.dtype(getitem_260, torch.float32);  getitem_260 = None
        to_dtype_49 = torch.ops.aten.to.dtype(relu__default_32, torch.float32);  relu__default_32 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_49, 0);  to_dtype_49 = None
        new_zeros_default_175 = torch.ops.aten.new_zeros.default(to_dtype_48, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_175, to_dtype_48);  le_scalar_16 = new_zeros_default_175 = to_dtype_48 = None
        to_dtype_50 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_50, convolution_default_35, primals_216, primals_214, primals_215, new_zeros_default_105, new_zeros_default_106, False, 1e-05, [True, True, True]);  to_dtype_50 = convolution_default_35 = primals_216 = primals_214 = primals_215 = new_zeros_default_105 = new_zeros_default_106 = None
        getitem_263 = native_batch_norm_backward_default_17[0]
        getitem_264 = native_batch_norm_backward_default_17[1]
        getitem_265 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(getitem_263, relu__default_31, primals_223, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_263 = primals_223 = None
        getitem_266 = convolution_backward_default_17[0]
        getitem_267 = convolution_backward_default_17[1]
        getitem_268 = convolution_backward_default_17[2];  convolution_backward_default_17 = None
        to_dtype_51 = torch.ops.aten.to.dtype(getitem_266, torch.float32);  getitem_266 = None
        to_dtype_52 = torch.ops.aten.to.dtype(relu__default_31, torch.float32);  relu__default_31 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_52, 0);  to_dtype_52 = None
        new_zeros_default_176 = torch.ops.aten.new_zeros.default(to_dtype_51, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_17, new_zeros_default_176, to_dtype_51);  le_scalar_17 = new_zeros_default_176 = to_dtype_51 = None
        to_dtype_53 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_53, convolution_default_34, primals_211, primals_209, primals_210, new_zeros_default_102, new_zeros_default_103, False, 1e-05, [True, True, True]);  to_dtype_53 = convolution_default_34 = primals_211 = primals_209 = primals_210 = new_zeros_default_102 = new_zeros_default_103 = None
        getitem_269 = native_batch_norm_backward_default_18[0]
        getitem_270 = native_batch_norm_backward_default_18[1]
        getitem_271 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(getitem_269, relu__default_30, primals_222, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_269 = primals_222 = None
        getitem_272 = convolution_backward_default_18[0]
        getitem_273 = convolution_backward_default_18[1]
        getitem_274 = convolution_backward_default_18[2];  convolution_backward_default_18 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(to_dtype_47, getitem_272);  to_dtype_47 = getitem_272 = None
        to_dtype_54 = torch.ops.aten.to.dtype(add_tensor_5, torch.float32);  add_tensor_5 = None
        to_dtype_55 = torch.ops.aten.to.dtype(relu__default_30, torch.float32);  relu__default_30 = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_55, 0);  to_dtype_55 = None
        new_zeros_default_177 = torch.ops.aten.new_zeros.default(to_dtype_54, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_18 = torch.ops.aten.where.self(le_scalar_18, new_zeros_default_177, to_dtype_54);  le_scalar_18 = new_zeros_default_177 = to_dtype_54 = None
        to_dtype_56 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_56, convolution_default_33, primals_203, primals_201, primals_202, new_zeros_default_99, new_zeros_default_100, False, 1e-05, [True, True, True]);  convolution_default_33 = primals_203 = primals_201 = primals_202 = new_zeros_default_99 = new_zeros_default_100 = None
        getitem_275 = native_batch_norm_backward_default_19[0]
        getitem_276 = native_batch_norm_backward_default_19[1]
        getitem_277 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_275, relu__default_29, primals_206, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_275 = primals_206 = None
        getitem_278 = convolution_backward_default_19[0]
        getitem_279 = convolution_backward_default_19[1]
        getitem_280 = convolution_backward_default_19[2];  convolution_backward_default_19 = None
        to_dtype_57 = torch.ops.aten.to.dtype(getitem_278, torch.float32);  getitem_278 = None
        to_dtype_58 = torch.ops.aten.to.dtype(relu__default_29, torch.float32);  relu__default_29 = None
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_58, 0);  to_dtype_58 = None
        new_zeros_default_178 = torch.ops.aten.new_zeros.default(to_dtype_57, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_19 = torch.ops.aten.where.self(le_scalar_19, new_zeros_default_178, to_dtype_57);  le_scalar_19 = new_zeros_default_178 = to_dtype_57 = None
        to_dtype_59 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_59, convolution_default_32, primals_198, primals_196, primals_197, new_zeros_default_96, new_zeros_default_97, False, 1e-05, [True, True, True]);  to_dtype_59 = convolution_default_32 = primals_198 = primals_196 = primals_197 = new_zeros_default_96 = new_zeros_default_97 = None
        getitem_281 = native_batch_norm_backward_default_20[0]
        getitem_282 = native_batch_norm_backward_default_20[1]
        getitem_283 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(getitem_281, relu__default_28, primals_205, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_281 = primals_205 = None
        getitem_284 = convolution_backward_default_20[0]
        getitem_285 = convolution_backward_default_20[1]
        getitem_286 = convolution_backward_default_20[2];  convolution_backward_default_20 = None
        to_dtype_60 = torch.ops.aten.to.dtype(getitem_284, torch.float32);  getitem_284 = None
        to_dtype_61 = torch.ops.aten.to.dtype(relu__default_28, torch.float32);  relu__default_28 = None
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_61, 0);  to_dtype_61 = None
        new_zeros_default_179 = torch.ops.aten.new_zeros.default(to_dtype_60, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_20 = torch.ops.aten.where.self(le_scalar_20, new_zeros_default_179, to_dtype_60);  le_scalar_20 = new_zeros_default_179 = to_dtype_60 = None
        to_dtype_62 = torch.ops.aten.to.dtype(where_self_20, torch.float32);  where_self_20 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_62, convolution_default_31, primals_193, primals_191, primals_192, new_zeros_default_93, new_zeros_default_94, False, 1e-05, [True, True, True]);  to_dtype_62 = convolution_default_31 = primals_193 = primals_191 = primals_192 = new_zeros_default_93 = new_zeros_default_94 = None
        getitem_287 = native_batch_norm_backward_default_21[0]
        getitem_288 = native_batch_norm_backward_default_21[1]
        getitem_289 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(getitem_287, relu__default_27, primals_204, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_287 = primals_204 = None
        getitem_290 = convolution_backward_default_21[0]
        getitem_291 = convolution_backward_default_21[1]
        getitem_292 = convolution_backward_default_21[2];  convolution_backward_default_21 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(to_dtype_56, getitem_290);  to_dtype_56 = getitem_290 = None
        to_dtype_63 = torch.ops.aten.to.dtype(add_tensor_6, torch.float32);  add_tensor_6 = None
        to_dtype_64 = torch.ops.aten.to.dtype(relu__default_27, torch.float32);  relu__default_27 = None
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_64, 0);  to_dtype_64 = None
        new_zeros_default_180 = torch.ops.aten.new_zeros.default(to_dtype_63, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_21 = torch.ops.aten.where.self(le_scalar_21, new_zeros_default_180, to_dtype_63);  le_scalar_21 = new_zeros_default_180 = to_dtype_63 = None
        to_dtype_65 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_65, convolution_default_30, primals_185, primals_183, primals_184, new_zeros_default_90, new_zeros_default_91, False, 1e-05, [True, True, True]);  convolution_default_30 = primals_185 = primals_183 = primals_184 = new_zeros_default_90 = new_zeros_default_91 = None
        getitem_293 = native_batch_norm_backward_default_22[0]
        getitem_294 = native_batch_norm_backward_default_22[1]
        getitem_295 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(getitem_293, relu__default_26, primals_188, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_293 = primals_188 = None
        getitem_296 = convolution_backward_default_22[0]
        getitem_297 = convolution_backward_default_22[1]
        getitem_298 = convolution_backward_default_22[2];  convolution_backward_default_22 = None
        to_dtype_66 = torch.ops.aten.to.dtype(getitem_296, torch.float32);  getitem_296 = None
        to_dtype_67 = torch.ops.aten.to.dtype(relu__default_26, torch.float32);  relu__default_26 = None
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_67, 0);  to_dtype_67 = None
        new_zeros_default_181 = torch.ops.aten.new_zeros.default(to_dtype_66, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_22 = torch.ops.aten.where.self(le_scalar_22, new_zeros_default_181, to_dtype_66);  le_scalar_22 = new_zeros_default_181 = to_dtype_66 = None
        to_dtype_68 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_68, convolution_default_29, primals_180, primals_178, primals_179, new_zeros_default_87, new_zeros_default_88, False, 1e-05, [True, True, True]);  to_dtype_68 = convolution_default_29 = primals_180 = primals_178 = primals_179 = new_zeros_default_87 = new_zeros_default_88 = None
        getitem_299 = native_batch_norm_backward_default_23[0]
        getitem_300 = native_batch_norm_backward_default_23[1]
        getitem_301 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(getitem_299, relu__default_25, primals_187, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_299 = primals_187 = None
        getitem_302 = convolution_backward_default_23[0]
        getitem_303 = convolution_backward_default_23[1]
        getitem_304 = convolution_backward_default_23[2];  convolution_backward_default_23 = None
        to_dtype_69 = torch.ops.aten.to.dtype(getitem_302, torch.float32);  getitem_302 = None
        to_dtype_70 = torch.ops.aten.to.dtype(relu__default_25, torch.float32);  relu__default_25 = None
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_70, 0);  to_dtype_70 = None
        new_zeros_default_182 = torch.ops.aten.new_zeros.default(to_dtype_69, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(le_scalar_23, new_zeros_default_182, to_dtype_69);  le_scalar_23 = new_zeros_default_182 = to_dtype_69 = None
        to_dtype_71 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_71, convolution_default_28, primals_175, primals_173, primals_174, new_zeros_default_84, new_zeros_default_85, False, 1e-05, [True, True, True]);  to_dtype_71 = convolution_default_28 = primals_175 = primals_173 = primals_174 = new_zeros_default_84 = new_zeros_default_85 = None
        getitem_305 = native_batch_norm_backward_default_24[0]
        getitem_306 = native_batch_norm_backward_default_24[1]
        getitem_307 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_305, relu__default_24, primals_186, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_305 = primals_186 = None
        getitem_308 = convolution_backward_default_24[0]
        getitem_309 = convolution_backward_default_24[1]
        getitem_310 = convolution_backward_default_24[2];  convolution_backward_default_24 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(to_dtype_65, getitem_308);  to_dtype_65 = getitem_308 = None
        to_dtype_72 = torch.ops.aten.to.dtype(add_tensor_7, torch.float32);  add_tensor_7 = None
        to_dtype_73 = torch.ops.aten.to.dtype(relu__default_24, torch.float32);  relu__default_24 = None
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_73, 0);  to_dtype_73 = None
        new_zeros_default_183 = torch.ops.aten.new_zeros.default(to_dtype_72, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_24 = torch.ops.aten.where.self(le_scalar_24, new_zeros_default_183, to_dtype_72);  le_scalar_24 = new_zeros_default_183 = to_dtype_72 = None
        to_dtype_74 = torch.ops.aten.to.dtype(where_self_24, torch.float32);  where_self_24 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_74, convolution_default_27, primals_170, primals_168, primals_169, new_zeros_default_81, new_zeros_default_82, False, 1e-05, [True, True, True]);  convolution_default_27 = primals_170 = primals_168 = primals_169 = new_zeros_default_81 = new_zeros_default_82 = None
        getitem_311 = native_batch_norm_backward_default_25[0]
        getitem_312 = native_batch_norm_backward_default_25[1]
        getitem_313 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_311, relu__default_21, primals_165, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_311 = primals_165 = None
        getitem_314 = convolution_backward_default_25[0]
        getitem_315 = convolution_backward_default_25[1]
        getitem_316 = convolution_backward_default_25[2];  convolution_backward_default_25 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_74, convolution_default_26, primals_161, primals_159, primals_160, new_zeros_default_78, new_zeros_default_79, False, 1e-05, [True, True, True]);  to_dtype_74 = convolution_default_26 = primals_161 = primals_159 = primals_160 = new_zeros_default_78 = new_zeros_default_79 = None
        getitem_317 = native_batch_norm_backward_default_26[0]
        getitem_318 = native_batch_norm_backward_default_26[1]
        getitem_319 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(getitem_317, relu__default_23, primals_164, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_317 = primals_164 = None
        getitem_320 = convolution_backward_default_26[0]
        getitem_321 = convolution_backward_default_26[1]
        getitem_322 = convolution_backward_default_26[2];  convolution_backward_default_26 = None
        to_dtype_75 = torch.ops.aten.to.dtype(getitem_320, torch.float32);  getitem_320 = None
        to_dtype_76 = torch.ops.aten.to.dtype(relu__default_23, torch.float32);  relu__default_23 = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_76, 0);  to_dtype_76 = None
        new_zeros_default_184 = torch.ops.aten.new_zeros.default(to_dtype_75, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_25 = torch.ops.aten.where.self(le_scalar_25, new_zeros_default_184, to_dtype_75);  le_scalar_25 = new_zeros_default_184 = to_dtype_75 = None
        to_dtype_77 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_77, convolution_default_25, primals_156, primals_154, primals_155, new_zeros_default_75, new_zeros_default_76, False, 1e-05, [True, True, True]);  to_dtype_77 = convolution_default_25 = primals_156 = primals_154 = primals_155 = new_zeros_default_75 = new_zeros_default_76 = None
        getitem_323 = native_batch_norm_backward_default_27[0]
        getitem_324 = native_batch_norm_backward_default_27[1]
        getitem_325 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(getitem_323, relu__default_22, primals_163, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_323 = primals_163 = None
        getitem_326 = convolution_backward_default_27[0]
        getitem_327 = convolution_backward_default_27[1]
        getitem_328 = convolution_backward_default_27[2];  convolution_backward_default_27 = None
        to_dtype_78 = torch.ops.aten.to.dtype(getitem_326, torch.float32);  getitem_326 = None
        to_dtype_79 = torch.ops.aten.to.dtype(relu__default_22, torch.float32);  relu__default_22 = None
        le_scalar_26 = torch.ops.aten.le.Scalar(to_dtype_79, 0);  to_dtype_79 = None
        new_zeros_default_185 = torch.ops.aten.new_zeros.default(to_dtype_78, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_26 = torch.ops.aten.where.self(le_scalar_26, new_zeros_default_185, to_dtype_78);  le_scalar_26 = new_zeros_default_185 = to_dtype_78 = None
        to_dtype_80 = torch.ops.aten.to.dtype(where_self_26, torch.float32);  where_self_26 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_80, convolution_default_24, primals_151, primals_149, primals_150, new_zeros_default_72, new_zeros_default_73, False, 1e-05, [True, True, True]);  to_dtype_80 = convolution_default_24 = primals_151 = primals_149 = primals_150 = new_zeros_default_72 = new_zeros_default_73 = None
        getitem_329 = native_batch_norm_backward_default_28[0]
        getitem_330 = native_batch_norm_backward_default_28[1]
        getitem_331 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(getitem_329, relu__default_21, primals_162, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_329 = primals_162 = None
        getitem_332 = convolution_backward_default_28[0]
        getitem_333 = convolution_backward_default_28[1]
        getitem_334 = convolution_backward_default_28[2];  convolution_backward_default_28 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(getitem_314, getitem_332);  getitem_314 = getitem_332 = None
        to_dtype_81 = torch.ops.aten.to.dtype(add_tensor_8, torch.float32);  add_tensor_8 = None
        to_dtype_82 = torch.ops.aten.to.dtype(relu__default_21, torch.float32);  relu__default_21 = None
        le_scalar_27 = torch.ops.aten.le.Scalar(to_dtype_82, 0);  to_dtype_82 = None
        new_zeros_default_186 = torch.ops.aten.new_zeros.default(to_dtype_81, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_27 = torch.ops.aten.where.self(le_scalar_27, new_zeros_default_186, to_dtype_81);  le_scalar_27 = new_zeros_default_186 = to_dtype_81 = None
        to_dtype_83 = torch.ops.aten.to.dtype(where_self_27, torch.float32);  where_self_27 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_83, convolution_default_23, primals_143, primals_141, primals_142, new_zeros_default_69, new_zeros_default_70, False, 1e-05, [True, True, True]);  convolution_default_23 = primals_143 = primals_141 = primals_142 = new_zeros_default_69 = new_zeros_default_70 = None
        getitem_335 = native_batch_norm_backward_default_29[0]
        getitem_336 = native_batch_norm_backward_default_29[1]
        getitem_337 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(getitem_335, relu__default_20, primals_146, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_335 = primals_146 = None
        getitem_338 = convolution_backward_default_29[0]
        getitem_339 = convolution_backward_default_29[1]
        getitem_340 = convolution_backward_default_29[2];  convolution_backward_default_29 = None
        to_dtype_84 = torch.ops.aten.to.dtype(getitem_338, torch.float32);  getitem_338 = None
        to_dtype_85 = torch.ops.aten.to.dtype(relu__default_20, torch.float32);  relu__default_20 = None
        le_scalar_28 = torch.ops.aten.le.Scalar(to_dtype_85, 0);  to_dtype_85 = None
        new_zeros_default_187 = torch.ops.aten.new_zeros.default(to_dtype_84, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_28 = torch.ops.aten.where.self(le_scalar_28, new_zeros_default_187, to_dtype_84);  le_scalar_28 = new_zeros_default_187 = to_dtype_84 = None
        to_dtype_86 = torch.ops.aten.to.dtype(where_self_28, torch.float32);  where_self_28 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_86, convolution_default_22, primals_138, primals_136, primals_137, new_zeros_default_66, new_zeros_default_67, False, 1e-05, [True, True, True]);  to_dtype_86 = convolution_default_22 = primals_138 = primals_136 = primals_137 = new_zeros_default_66 = new_zeros_default_67 = None
        getitem_341 = native_batch_norm_backward_default_30[0]
        getitem_342 = native_batch_norm_backward_default_30[1]
        getitem_343 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_341, relu__default_19, primals_145, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_341 = primals_145 = None
        getitem_344 = convolution_backward_default_30[0]
        getitem_345 = convolution_backward_default_30[1]
        getitem_346 = convolution_backward_default_30[2];  convolution_backward_default_30 = None
        to_dtype_87 = torch.ops.aten.to.dtype(getitem_344, torch.float32);  getitem_344 = None
        to_dtype_88 = torch.ops.aten.to.dtype(relu__default_19, torch.float32);  relu__default_19 = None
        le_scalar_29 = torch.ops.aten.le.Scalar(to_dtype_88, 0);  to_dtype_88 = None
        new_zeros_default_188 = torch.ops.aten.new_zeros.default(to_dtype_87, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_29 = torch.ops.aten.where.self(le_scalar_29, new_zeros_default_188, to_dtype_87);  le_scalar_29 = new_zeros_default_188 = to_dtype_87 = None
        to_dtype_89 = torch.ops.aten.to.dtype(where_self_29, torch.float32);  where_self_29 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_89, convolution_default_21, primals_133, primals_131, primals_132, new_zeros_default_63, new_zeros_default_64, False, 1e-05, [True, True, True]);  to_dtype_89 = convolution_default_21 = primals_133 = primals_131 = primals_132 = new_zeros_default_63 = new_zeros_default_64 = None
        getitem_347 = native_batch_norm_backward_default_31[0]
        getitem_348 = native_batch_norm_backward_default_31[1]
        getitem_349 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(getitem_347, relu__default_18, primals_144, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_347 = primals_144 = None
        getitem_350 = convolution_backward_default_31[0]
        getitem_351 = convolution_backward_default_31[1]
        getitem_352 = convolution_backward_default_31[2];  convolution_backward_default_31 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(to_dtype_83, getitem_350);  to_dtype_83 = getitem_350 = None
        to_dtype_90 = torch.ops.aten.to.dtype(add_tensor_9, torch.float32);  add_tensor_9 = None
        to_dtype_91 = torch.ops.aten.to.dtype(relu__default_18, torch.float32);  relu__default_18 = None
        le_scalar_30 = torch.ops.aten.le.Scalar(to_dtype_91, 0);  to_dtype_91 = None
        new_zeros_default_189 = torch.ops.aten.new_zeros.default(to_dtype_90, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_30 = torch.ops.aten.where.self(le_scalar_30, new_zeros_default_189, to_dtype_90);  le_scalar_30 = new_zeros_default_189 = to_dtype_90 = None
        to_dtype_92 = torch.ops.aten.to.dtype(where_self_30, torch.float32);  where_self_30 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_92, convolution_default_20, primals_125, primals_123, primals_124, new_zeros_default_60, new_zeros_default_61, False, 1e-05, [True, True, True]);  convolution_default_20 = primals_125 = primals_123 = primals_124 = new_zeros_default_60 = new_zeros_default_61 = None
        getitem_353 = native_batch_norm_backward_default_32[0]
        getitem_354 = native_batch_norm_backward_default_32[1]
        getitem_355 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(getitem_353, relu__default_17, primals_128, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_353 = primals_128 = None
        getitem_356 = convolution_backward_default_32[0]
        getitem_357 = convolution_backward_default_32[1]
        getitem_358 = convolution_backward_default_32[2];  convolution_backward_default_32 = None
        to_dtype_93 = torch.ops.aten.to.dtype(getitem_356, torch.float32);  getitem_356 = None
        to_dtype_94 = torch.ops.aten.to.dtype(relu__default_17, torch.float32);  relu__default_17 = None
        le_scalar_31 = torch.ops.aten.le.Scalar(to_dtype_94, 0);  to_dtype_94 = None
        new_zeros_default_190 = torch.ops.aten.new_zeros.default(to_dtype_93, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_31 = torch.ops.aten.where.self(le_scalar_31, new_zeros_default_190, to_dtype_93);  le_scalar_31 = new_zeros_default_190 = to_dtype_93 = None
        to_dtype_95 = torch.ops.aten.to.dtype(where_self_31, torch.float32);  where_self_31 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_95, convolution_default_19, primals_120, primals_118, primals_119, new_zeros_default_57, new_zeros_default_58, False, 1e-05, [True, True, True]);  to_dtype_95 = convolution_default_19 = primals_120 = primals_118 = primals_119 = new_zeros_default_57 = new_zeros_default_58 = None
        getitem_359 = native_batch_norm_backward_default_33[0]
        getitem_360 = native_batch_norm_backward_default_33[1]
        getitem_361 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(getitem_359, relu__default_16, primals_127, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_359 = primals_127 = None
        getitem_362 = convolution_backward_default_33[0]
        getitem_363 = convolution_backward_default_33[1]
        getitem_364 = convolution_backward_default_33[2];  convolution_backward_default_33 = None
        to_dtype_96 = torch.ops.aten.to.dtype(getitem_362, torch.float32);  getitem_362 = None
        to_dtype_97 = torch.ops.aten.to.dtype(relu__default_16, torch.float32);  relu__default_16 = None
        le_scalar_32 = torch.ops.aten.le.Scalar(to_dtype_97, 0);  to_dtype_97 = None
        new_zeros_default_191 = torch.ops.aten.new_zeros.default(to_dtype_96, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_32 = torch.ops.aten.where.self(le_scalar_32, new_zeros_default_191, to_dtype_96);  le_scalar_32 = new_zeros_default_191 = to_dtype_96 = None
        to_dtype_98 = torch.ops.aten.to.dtype(where_self_32, torch.float32);  where_self_32 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_98, convolution_default_18, primals_115, primals_113, primals_114, new_zeros_default_54, new_zeros_default_55, False, 1e-05, [True, True, True]);  to_dtype_98 = convolution_default_18 = primals_115 = primals_113 = primals_114 = new_zeros_default_54 = new_zeros_default_55 = None
        getitem_365 = native_batch_norm_backward_default_34[0]
        getitem_366 = native_batch_norm_backward_default_34[1]
        getitem_367 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(getitem_365, relu__default_15, primals_126, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_365 = primals_126 = None
        getitem_368 = convolution_backward_default_34[0]
        getitem_369 = convolution_backward_default_34[1]
        getitem_370 = convolution_backward_default_34[2];  convolution_backward_default_34 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(to_dtype_92, getitem_368);  to_dtype_92 = getitem_368 = None
        to_dtype_99 = torch.ops.aten.to.dtype(add_tensor_10, torch.float32);  add_tensor_10 = None
        to_dtype_100 = torch.ops.aten.to.dtype(relu__default_15, torch.float32);  relu__default_15 = None
        le_scalar_33 = torch.ops.aten.le.Scalar(to_dtype_100, 0);  to_dtype_100 = None
        new_zeros_default_192 = torch.ops.aten.new_zeros.default(to_dtype_99, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_33 = torch.ops.aten.where.self(le_scalar_33, new_zeros_default_192, to_dtype_99);  le_scalar_33 = new_zeros_default_192 = to_dtype_99 = None
        to_dtype_101 = torch.ops.aten.to.dtype(where_self_33, torch.float32);  where_self_33 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_101, convolution_default_17, primals_107, primals_105, primals_106, new_zeros_default_51, new_zeros_default_52, False, 1e-05, [True, True, True]);  convolution_default_17 = primals_107 = primals_105 = primals_106 = new_zeros_default_51 = new_zeros_default_52 = None
        getitem_371 = native_batch_norm_backward_default_35[0]
        getitem_372 = native_batch_norm_backward_default_35[1]
        getitem_373 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_371, relu__default_14, primals_110, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_371 = primals_110 = None
        getitem_374 = convolution_backward_default_35[0]
        getitem_375 = convolution_backward_default_35[1]
        getitem_376 = convolution_backward_default_35[2];  convolution_backward_default_35 = None
        to_dtype_102 = torch.ops.aten.to.dtype(getitem_374, torch.float32);  getitem_374 = None
        to_dtype_103 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar_34 = torch.ops.aten.le.Scalar(to_dtype_103, 0);  to_dtype_103 = None
        new_zeros_default_193 = torch.ops.aten.new_zeros.default(to_dtype_102, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_34 = torch.ops.aten.where.self(le_scalar_34, new_zeros_default_193, to_dtype_102);  le_scalar_34 = new_zeros_default_193 = to_dtype_102 = None
        to_dtype_104 = torch.ops.aten.to.dtype(where_self_34, torch.float32);  where_self_34 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_104, convolution_default_16, primals_102, primals_100, primals_101, new_zeros_default_48, new_zeros_default_49, False, 1e-05, [True, True, True]);  to_dtype_104 = convolution_default_16 = primals_102 = primals_100 = primals_101 = new_zeros_default_48 = new_zeros_default_49 = None
        getitem_377 = native_batch_norm_backward_default_36[0]
        getitem_378 = native_batch_norm_backward_default_36[1]
        getitem_379 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(getitem_377, relu__default_13, primals_109, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_377 = primals_109 = None
        getitem_380 = convolution_backward_default_36[0]
        getitem_381 = convolution_backward_default_36[1]
        getitem_382 = convolution_backward_default_36[2];  convolution_backward_default_36 = None
        to_dtype_105 = torch.ops.aten.to.dtype(getitem_380, torch.float32);  getitem_380 = None
        to_dtype_106 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_35 = torch.ops.aten.le.Scalar(to_dtype_106, 0);  to_dtype_106 = None
        new_zeros_default_194 = torch.ops.aten.new_zeros.default(to_dtype_105, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_35 = torch.ops.aten.where.self(le_scalar_35, new_zeros_default_194, to_dtype_105);  le_scalar_35 = new_zeros_default_194 = to_dtype_105 = None
        to_dtype_107 = torch.ops.aten.to.dtype(where_self_35, torch.float32);  where_self_35 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_107, convolution_default_15, primals_97, primals_95, primals_96, new_zeros_default_45, new_zeros_default_46, False, 1e-05, [True, True, True]);  to_dtype_107 = convolution_default_15 = primals_97 = primals_95 = primals_96 = new_zeros_default_45 = new_zeros_default_46 = None
        getitem_383 = native_batch_norm_backward_default_37[0]
        getitem_384 = native_batch_norm_backward_default_37[1]
        getitem_385 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(getitem_383, relu__default_12, primals_108, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_383 = primals_108 = None
        getitem_386 = convolution_backward_default_37[0]
        getitem_387 = convolution_backward_default_37[1]
        getitem_388 = convolution_backward_default_37[2];  convolution_backward_default_37 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(to_dtype_101, getitem_386);  to_dtype_101 = getitem_386 = None
        to_dtype_108 = torch.ops.aten.to.dtype(add_tensor_11, torch.float32);  add_tensor_11 = None
        to_dtype_109 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_36 = torch.ops.aten.le.Scalar(to_dtype_109, 0);  to_dtype_109 = None
        new_zeros_default_195 = torch.ops.aten.new_zeros.default(to_dtype_108, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_36 = torch.ops.aten.where.self(le_scalar_36, new_zeros_default_195, to_dtype_108);  le_scalar_36 = new_zeros_default_195 = to_dtype_108 = None
        to_dtype_110 = torch.ops.aten.to.dtype(where_self_36, torch.float32);  where_self_36 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_110, convolution_default_14, primals_92, primals_90, primals_91, new_zeros_default_42, new_zeros_default_43, False, 1e-05, [True, True, True]);  convolution_default_14 = primals_92 = primals_90 = primals_91 = new_zeros_default_42 = new_zeros_default_43 = None
        getitem_389 = native_batch_norm_backward_default_38[0]
        getitem_390 = native_batch_norm_backward_default_38[1]
        getitem_391 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(getitem_389, relu__default_9, primals_87, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_389 = primals_87 = None
        getitem_392 = convolution_backward_default_38[0]
        getitem_393 = convolution_backward_default_38[1]
        getitem_394 = convolution_backward_default_38[2];  convolution_backward_default_38 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_110, convolution_default_13, primals_83, primals_81, primals_82, new_zeros_default_39, new_zeros_default_40, False, 1e-05, [True, True, True]);  to_dtype_110 = convolution_default_13 = primals_83 = primals_81 = primals_82 = new_zeros_default_39 = new_zeros_default_40 = None
        getitem_395 = native_batch_norm_backward_default_39[0]
        getitem_396 = native_batch_norm_backward_default_39[1]
        getitem_397 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(getitem_395, relu__default_11, primals_86, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_395 = primals_86 = None
        getitem_398 = convolution_backward_default_39[0]
        getitem_399 = convolution_backward_default_39[1]
        getitem_400 = convolution_backward_default_39[2];  convolution_backward_default_39 = None
        to_dtype_111 = torch.ops.aten.to.dtype(getitem_398, torch.float32);  getitem_398 = None
        to_dtype_112 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_37 = torch.ops.aten.le.Scalar(to_dtype_112, 0);  to_dtype_112 = None
        new_zeros_default_196 = torch.ops.aten.new_zeros.default(to_dtype_111, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_37 = torch.ops.aten.where.self(le_scalar_37, new_zeros_default_196, to_dtype_111);  le_scalar_37 = new_zeros_default_196 = to_dtype_111 = None
        to_dtype_113 = torch.ops.aten.to.dtype(where_self_37, torch.float32);  where_self_37 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_113, convolution_default_12, primals_78, primals_76, primals_77, new_zeros_default_36, new_zeros_default_37, False, 1e-05, [True, True, True]);  to_dtype_113 = convolution_default_12 = primals_78 = primals_76 = primals_77 = new_zeros_default_36 = new_zeros_default_37 = None
        getitem_401 = native_batch_norm_backward_default_40[0]
        getitem_402 = native_batch_norm_backward_default_40[1]
        getitem_403 = native_batch_norm_backward_default_40[2];  native_batch_norm_backward_default_40 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(getitem_401, relu__default_10, primals_85, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_401 = primals_85 = None
        getitem_404 = convolution_backward_default_40[0]
        getitem_405 = convolution_backward_default_40[1]
        getitem_406 = convolution_backward_default_40[2];  convolution_backward_default_40 = None
        to_dtype_114 = torch.ops.aten.to.dtype(getitem_404, torch.float32);  getitem_404 = None
        to_dtype_115 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_38 = torch.ops.aten.le.Scalar(to_dtype_115, 0);  to_dtype_115 = None
        new_zeros_default_197 = torch.ops.aten.new_zeros.default(to_dtype_114, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_38 = torch.ops.aten.where.self(le_scalar_38, new_zeros_default_197, to_dtype_114);  le_scalar_38 = new_zeros_default_197 = to_dtype_114 = None
        to_dtype_116 = torch.ops.aten.to.dtype(where_self_38, torch.float32);  where_self_38 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_116, convolution_default_11, primals_73, primals_71, primals_72, new_zeros_default_33, new_zeros_default_34, False, 1e-05, [True, True, True]);  to_dtype_116 = convolution_default_11 = primals_73 = primals_71 = primals_72 = new_zeros_default_33 = new_zeros_default_34 = None
        getitem_407 = native_batch_norm_backward_default_41[0]
        getitem_408 = native_batch_norm_backward_default_41[1]
        getitem_409 = native_batch_norm_backward_default_41[2];  native_batch_norm_backward_default_41 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(getitem_407, relu__default_9, primals_84, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_407 = primals_84 = None
        getitem_410 = convolution_backward_default_41[0]
        getitem_411 = convolution_backward_default_41[1]
        getitem_412 = convolution_backward_default_41[2];  convolution_backward_default_41 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(getitem_392, getitem_410);  getitem_392 = getitem_410 = None
        to_dtype_117 = torch.ops.aten.to.dtype(add_tensor_12, torch.float32);  add_tensor_12 = None
        to_dtype_118 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_39 = torch.ops.aten.le.Scalar(to_dtype_118, 0);  to_dtype_118 = None
        new_zeros_default_198 = torch.ops.aten.new_zeros.default(to_dtype_117, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_39 = torch.ops.aten.where.self(le_scalar_39, new_zeros_default_198, to_dtype_117);  le_scalar_39 = new_zeros_default_198 = to_dtype_117 = None
        to_dtype_119 = torch.ops.aten.to.dtype(where_self_39, torch.float32);  where_self_39 = None
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_119, convolution_default_10, primals_65, primals_63, primals_64, new_zeros_default_30, new_zeros_default_31, False, 1e-05, [True, True, True]);  convolution_default_10 = primals_65 = primals_63 = primals_64 = new_zeros_default_30 = new_zeros_default_31 = None
        getitem_413 = native_batch_norm_backward_default_42[0]
        getitem_414 = native_batch_norm_backward_default_42[1]
        getitem_415 = native_batch_norm_backward_default_42[2];  native_batch_norm_backward_default_42 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(getitem_413, relu__default_8, primals_68, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_413 = primals_68 = None
        getitem_416 = convolution_backward_default_42[0]
        getitem_417 = convolution_backward_default_42[1]
        getitem_418 = convolution_backward_default_42[2];  convolution_backward_default_42 = None
        to_dtype_120 = torch.ops.aten.to.dtype(getitem_416, torch.float32);  getitem_416 = None
        to_dtype_121 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_40 = torch.ops.aten.le.Scalar(to_dtype_121, 0);  to_dtype_121 = None
        new_zeros_default_199 = torch.ops.aten.new_zeros.default(to_dtype_120, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_40 = torch.ops.aten.where.self(le_scalar_40, new_zeros_default_199, to_dtype_120);  le_scalar_40 = new_zeros_default_199 = to_dtype_120 = None
        to_dtype_122 = torch.ops.aten.to.dtype(where_self_40, torch.float32);  where_self_40 = None
        native_batch_norm_backward_default_43 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_122, convolution_default_9, primals_60, primals_58, primals_59, new_zeros_default_27, new_zeros_default_28, False, 1e-05, [True, True, True]);  to_dtype_122 = convolution_default_9 = primals_60 = primals_58 = primals_59 = new_zeros_default_27 = new_zeros_default_28 = None
        getitem_419 = native_batch_norm_backward_default_43[0]
        getitem_420 = native_batch_norm_backward_default_43[1]
        getitem_421 = native_batch_norm_backward_default_43[2];  native_batch_norm_backward_default_43 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(getitem_419, relu__default_7, primals_67, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_419 = primals_67 = None
        getitem_422 = convolution_backward_default_43[0]
        getitem_423 = convolution_backward_default_43[1]
        getitem_424 = convolution_backward_default_43[2];  convolution_backward_default_43 = None
        to_dtype_123 = torch.ops.aten.to.dtype(getitem_422, torch.float32);  getitem_422 = None
        to_dtype_124 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_41 = torch.ops.aten.le.Scalar(to_dtype_124, 0);  to_dtype_124 = None
        new_zeros_default_200 = torch.ops.aten.new_zeros.default(to_dtype_123, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_41 = torch.ops.aten.where.self(le_scalar_41, new_zeros_default_200, to_dtype_123);  le_scalar_41 = new_zeros_default_200 = to_dtype_123 = None
        to_dtype_125 = torch.ops.aten.to.dtype(where_self_41, torch.float32);  where_self_41 = None
        native_batch_norm_backward_default_44 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_125, convolution_default_8, primals_55, primals_53, primals_54, new_zeros_default_24, new_zeros_default_25, False, 1e-05, [True, True, True]);  to_dtype_125 = convolution_default_8 = primals_55 = primals_53 = primals_54 = new_zeros_default_24 = new_zeros_default_25 = None
        getitem_425 = native_batch_norm_backward_default_44[0]
        getitem_426 = native_batch_norm_backward_default_44[1]
        getitem_427 = native_batch_norm_backward_default_44[2];  native_batch_norm_backward_default_44 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(getitem_425, relu__default_6, primals_66, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_425 = primals_66 = None
        getitem_428 = convolution_backward_default_44[0]
        getitem_429 = convolution_backward_default_44[1]
        getitem_430 = convolution_backward_default_44[2];  convolution_backward_default_44 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(to_dtype_119, getitem_428);  to_dtype_119 = getitem_428 = None
        to_dtype_126 = torch.ops.aten.to.dtype(add_tensor_13, torch.float32);  add_tensor_13 = None
        to_dtype_127 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_42 = torch.ops.aten.le.Scalar(to_dtype_127, 0);  to_dtype_127 = None
        new_zeros_default_201 = torch.ops.aten.new_zeros.default(to_dtype_126, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_42 = torch.ops.aten.where.self(le_scalar_42, new_zeros_default_201, to_dtype_126);  le_scalar_42 = new_zeros_default_201 = to_dtype_126 = None
        to_dtype_128 = torch.ops.aten.to.dtype(where_self_42, torch.float32);  where_self_42 = None
        native_batch_norm_backward_default_45 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_128, convolution_default_7, primals_47, primals_45, primals_46, new_zeros_default_21, new_zeros_default_22, False, 1e-05, [True, True, True]);  convolution_default_7 = primals_47 = primals_45 = primals_46 = new_zeros_default_21 = new_zeros_default_22 = None
        getitem_431 = native_batch_norm_backward_default_45[0]
        getitem_432 = native_batch_norm_backward_default_45[1]
        getitem_433 = native_batch_norm_backward_default_45[2];  native_batch_norm_backward_default_45 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(getitem_431, relu__default_5, primals_50, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_431 = primals_50 = None
        getitem_434 = convolution_backward_default_45[0]
        getitem_435 = convolution_backward_default_45[1]
        getitem_436 = convolution_backward_default_45[2];  convolution_backward_default_45 = None
        to_dtype_129 = torch.ops.aten.to.dtype(getitem_434, torch.float32);  getitem_434 = None
        to_dtype_130 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_43 = torch.ops.aten.le.Scalar(to_dtype_130, 0);  to_dtype_130 = None
        new_zeros_default_202 = torch.ops.aten.new_zeros.default(to_dtype_129, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_43 = torch.ops.aten.where.self(le_scalar_43, new_zeros_default_202, to_dtype_129);  le_scalar_43 = new_zeros_default_202 = to_dtype_129 = None
        to_dtype_131 = torch.ops.aten.to.dtype(where_self_43, torch.float32);  where_self_43 = None
        native_batch_norm_backward_default_46 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_131, convolution_default_6, primals_42, primals_40, primals_41, new_zeros_default_18, new_zeros_default_19, False, 1e-05, [True, True, True]);  to_dtype_131 = convolution_default_6 = primals_42 = primals_40 = primals_41 = new_zeros_default_18 = new_zeros_default_19 = None
        getitem_437 = native_batch_norm_backward_default_46[0]
        getitem_438 = native_batch_norm_backward_default_46[1]
        getitem_439 = native_batch_norm_backward_default_46[2];  native_batch_norm_backward_default_46 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(getitem_437, relu__default_4, primals_49, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_437 = primals_49 = None
        getitem_440 = convolution_backward_default_46[0]
        getitem_441 = convolution_backward_default_46[1]
        getitem_442 = convolution_backward_default_46[2];  convolution_backward_default_46 = None
        to_dtype_132 = torch.ops.aten.to.dtype(getitem_440, torch.float32);  getitem_440 = None
        to_dtype_133 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_44 = torch.ops.aten.le.Scalar(to_dtype_133, 0);  to_dtype_133 = None
        new_zeros_default_203 = torch.ops.aten.new_zeros.default(to_dtype_132, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_44 = torch.ops.aten.where.self(le_scalar_44, new_zeros_default_203, to_dtype_132);  le_scalar_44 = new_zeros_default_203 = to_dtype_132 = None
        to_dtype_134 = torch.ops.aten.to.dtype(where_self_44, torch.float32);  where_self_44 = None
        native_batch_norm_backward_default_47 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_134, convolution_default_5, primals_37, primals_35, primals_36, new_zeros_default_15, new_zeros_default_16, False, 1e-05, [True, True, True]);  to_dtype_134 = convolution_default_5 = primals_37 = primals_35 = primals_36 = new_zeros_default_15 = new_zeros_default_16 = None
        getitem_443 = native_batch_norm_backward_default_47[0]
        getitem_444 = native_batch_norm_backward_default_47[1]
        getitem_445 = native_batch_norm_backward_default_47[2];  native_batch_norm_backward_default_47 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(getitem_443, relu__default_3, primals_48, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_443 = primals_48 = None
        getitem_446 = convolution_backward_default_47[0]
        getitem_447 = convolution_backward_default_47[1]
        getitem_448 = convolution_backward_default_47[2];  convolution_backward_default_47 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(to_dtype_128, getitem_446);  to_dtype_128 = getitem_446 = None
        to_dtype_135 = torch.ops.aten.to.dtype(add_tensor_14, torch.float32);  add_tensor_14 = None
        to_dtype_136 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_45 = torch.ops.aten.le.Scalar(to_dtype_136, 0);  to_dtype_136 = None
        new_zeros_default_204 = torch.ops.aten.new_zeros.default(to_dtype_135, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_45 = torch.ops.aten.where.self(le_scalar_45, new_zeros_default_204, to_dtype_135);  le_scalar_45 = new_zeros_default_204 = to_dtype_135 = None
        to_dtype_137 = torch.ops.aten.to.dtype(where_self_45, torch.float32);  where_self_45 = None
        native_batch_norm_backward_default_48 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_137, convolution_default_4, primals_32, primals_30, primals_31, new_zeros_default_12, new_zeros_default_13, False, 1e-05, [True, True, True]);  convolution_default_4 = primals_32 = primals_30 = primals_31 = new_zeros_default_12 = new_zeros_default_13 = None
        getitem_449 = native_batch_norm_backward_default_48[0]
        getitem_450 = native_batch_norm_backward_default_48[1]
        getitem_451 = native_batch_norm_backward_default_48[2];  native_batch_norm_backward_default_48 = None
        convolution_backward_default_48 = torch.ops.aten.convolution_backward.default(getitem_449, getitem_3, primals_27, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_449 = primals_27 = None
        getitem_452 = convolution_backward_default_48[0]
        getitem_453 = convolution_backward_default_48[1]
        getitem_454 = convolution_backward_default_48[2];  convolution_backward_default_48 = None
        native_batch_norm_backward_default_49 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_137, convolution_default_3, primals_23, primals_21, primals_22, new_zeros_default_9, new_zeros_default_10, False, 1e-05, [True, True, True]);  to_dtype_137 = convolution_default_3 = primals_23 = primals_21 = primals_22 = new_zeros_default_9 = new_zeros_default_10 = None
        getitem_455 = native_batch_norm_backward_default_49[0]
        getitem_456 = native_batch_norm_backward_default_49[1]
        getitem_457 = native_batch_norm_backward_default_49[2];  native_batch_norm_backward_default_49 = None
        convolution_backward_default_49 = torch.ops.aten.convolution_backward.default(getitem_455, relu__default_2, primals_26, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_455 = primals_26 = None
        getitem_458 = convolution_backward_default_49[0]
        getitem_459 = convolution_backward_default_49[1]
        getitem_460 = convolution_backward_default_49[2];  convolution_backward_default_49 = None
        to_dtype_138 = torch.ops.aten.to.dtype(getitem_458, torch.float32);  getitem_458 = None
        to_dtype_139 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_46 = torch.ops.aten.le.Scalar(to_dtype_139, 0);  to_dtype_139 = None
        new_zeros_default_205 = torch.ops.aten.new_zeros.default(to_dtype_138, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_46 = torch.ops.aten.where.self(le_scalar_46, new_zeros_default_205, to_dtype_138);  le_scalar_46 = new_zeros_default_205 = to_dtype_138 = None
        to_dtype_140 = torch.ops.aten.to.dtype(where_self_46, torch.float32);  where_self_46 = None
        native_batch_norm_backward_default_50 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_140, convolution_default_2, primals_18, primals_16, primals_17, new_zeros_default_6, new_zeros_default_7, False, 1e-05, [True, True, True]);  to_dtype_140 = convolution_default_2 = primals_18 = primals_16 = primals_17 = new_zeros_default_6 = new_zeros_default_7 = None
        getitem_461 = native_batch_norm_backward_default_50[0]
        getitem_462 = native_batch_norm_backward_default_50[1]
        getitem_463 = native_batch_norm_backward_default_50[2];  native_batch_norm_backward_default_50 = None
        convolution_backward_default_50 = torch.ops.aten.convolution_backward.default(getitem_461, relu__default_1, primals_25, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_461 = primals_25 = None
        getitem_464 = convolution_backward_default_50[0]
        getitem_465 = convolution_backward_default_50[1]
        getitem_466 = convolution_backward_default_50[2];  convolution_backward_default_50 = None
        to_dtype_141 = torch.ops.aten.to.dtype(getitem_464, torch.float32);  getitem_464 = None
        to_dtype_142 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_47 = torch.ops.aten.le.Scalar(to_dtype_142, 0);  to_dtype_142 = None
        new_zeros_default_206 = torch.ops.aten.new_zeros.default(to_dtype_141, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_47 = torch.ops.aten.where.self(le_scalar_47, new_zeros_default_206, to_dtype_141);  le_scalar_47 = new_zeros_default_206 = to_dtype_141 = None
        to_dtype_143 = torch.ops.aten.to.dtype(where_self_47, torch.float32);  where_self_47 = None
        native_batch_norm_backward_default_51 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_143, convolution_default_1, primals_13, primals_11, primals_12, new_zeros_default_3, new_zeros_default_4, False, 1e-05, [True, True, True]);  to_dtype_143 = convolution_default_1 = primals_13 = primals_11 = primals_12 = new_zeros_default_3 = new_zeros_default_4 = None
        getitem_467 = native_batch_norm_backward_default_51[0]
        getitem_468 = native_batch_norm_backward_default_51[1]
        getitem_469 = native_batch_norm_backward_default_51[2];  native_batch_norm_backward_default_51 = None
        convolution_backward_default_51 = torch.ops.aten.convolution_backward.default(getitem_467, getitem_3, primals_24, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_467 = getitem_3 = primals_24 = None
        getitem_470 = convolution_backward_default_51[0]
        getitem_471 = convolution_backward_default_51[1]
        getitem_472 = convolution_backward_default_51[2];  convolution_backward_default_51 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(getitem_452, getitem_470);  getitem_452 = getitem_470 = None
        max_pool2d_with_indices_backward_default = torch.ops.aten.max_pool2d_with_indices_backward.default(add_tensor_15, relu__default, [3, 3], [2, 2], [1, 1], [1, 1], False, getitem_4);  add_tensor_15 = getitem_4 = None
        to_dtype_144 = torch.ops.aten.to.dtype(max_pool2d_with_indices_backward_default, torch.float32);  max_pool2d_with_indices_backward_default = None
        to_dtype_145 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_48 = torch.ops.aten.le.Scalar(to_dtype_145, 0);  to_dtype_145 = None
        new_zeros_default_207 = torch.ops.aten.new_zeros.default(to_dtype_144, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_48 = torch.ops.aten.where.self(le_scalar_48, new_zeros_default_207, to_dtype_144);  le_scalar_48 = new_zeros_default_207 = to_dtype_144 = None
        to_dtype_146 = torch.ops.aten.to.dtype(where_self_48, torch.float32);  where_self_48 = None
        native_batch_norm_backward_default_52 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_146, convolution_default, primals_5, primals_3, primals_4, new_zeros_default, new_zeros_default_1, False, 1e-05, [True, True, True]);  to_dtype_146 = convolution_default = primals_5 = primals_3 = primals_4 = new_zeros_default = new_zeros_default_1 = None
        getitem_473 = native_batch_norm_backward_default_52[0]
        getitem_474 = native_batch_norm_backward_default_52[1]
        getitem_475 = native_batch_norm_backward_default_52[2];  native_batch_norm_backward_default_52 = None
        convolution_backward_default_52 = torch.ops.aten.convolution_backward.default(getitem_473, primals_321, primals_6, [0], [2, 2], [3, 3], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_473 = primals_321 = primals_6 = None
        getitem_476 = convolution_backward_default_52[0]
        getitem_477 = convolution_backward_default_52[1]
        getitem_478 = convolution_backward_default_52[2];  convolution_backward_default_52 = None
        return [addmm_default, getitem_475, None, None, None, getitem_474, getitem_477, view_default_1, t_default_4, getitem_469, None, None, None, getitem_468, getitem_463, None, None, None, getitem_462, getitem_457, None, None, None, getitem_456, getitem_471, getitem_465, getitem_459, getitem_453, getitem_451, None, None, None, getitem_450, getitem_445, None, None, None, getitem_444, getitem_439, None, None, None, getitem_438, getitem_433, None, None, None, getitem_432, getitem_447, getitem_441, getitem_435, getitem_427, None, None, None, getitem_426, getitem_421, None, None, None, getitem_420, getitem_415, None, None, None, getitem_414, getitem_429, getitem_423, getitem_417, getitem_409, None, None, None, getitem_408, getitem_403, None, None, None, getitem_402, getitem_397, None, None, None, getitem_396, getitem_411, getitem_405, getitem_399, getitem_393, getitem_391, None, None, None, getitem_390, getitem_385, None, None, None, getitem_384, getitem_379, None, None, None, getitem_378, getitem_373, None, None, None, getitem_372, getitem_387, getitem_381, getitem_375, getitem_367, None, None, None, getitem_366, getitem_361, None, None, None, getitem_360, getitem_355, None, None, None, getitem_354, getitem_369, getitem_363, getitem_357, getitem_349, None, None, None, getitem_348, getitem_343, None, None, None, getitem_342, getitem_337, None, None, None, getitem_336, getitem_351, getitem_345, getitem_339, getitem_331, None, None, None, getitem_330, getitem_325, None, None, None, getitem_324, getitem_319, None, None, None, getitem_318, getitem_333, getitem_327, getitem_321, getitem_315, getitem_313, None, None, None, getitem_312, getitem_307, None, None, None, getitem_306, getitem_301, None, None, None, getitem_300, getitem_295, None, None, None, getitem_294, getitem_309, getitem_303, getitem_297, getitem_289, None, None, None, getitem_288, getitem_283, None, None, None, getitem_282, getitem_277, None, None, None, getitem_276, getitem_291, getitem_285, getitem_279, getitem_271, None, None, None, getitem_270, getitem_265, None, None, None, getitem_264, getitem_259, None, None, None, getitem_258, getitem_273, getitem_267, getitem_261, getitem_253, None, None, None, getitem_252, getitem_247, None, None, None, getitem_246, getitem_241, None, None, None, getitem_240, getitem_255, getitem_249, getitem_243, getitem_235, None, None, None, getitem_234, getitem_229, None, None, None, getitem_228, getitem_223, None, None, None, getitem_222, getitem_237, getitem_231, getitem_225, getitem_217, None, None, None, getitem_216, getitem_211, None, None, None, getitem_210, getitem_205, None, None, None, getitem_204, getitem_219, getitem_213, getitem_207, getitem_201, getitem_199, None, None, None, getitem_198, getitem_193, None, None, None, getitem_192, getitem_187, None, None, None, getitem_186, getitem_181, None, None, None, getitem_180, getitem_195, getitem_189, getitem_183, getitem_175, None, None, None, getitem_174, getitem_169, None, None, None, getitem_168, getitem_163, None, None, None, getitem_162, getitem_177, getitem_171, getitem_165, None]
        
