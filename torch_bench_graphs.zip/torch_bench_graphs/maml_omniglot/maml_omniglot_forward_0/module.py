
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/maml_omniglot/maml_omniglot_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24):
        convolution_default = torch.ops.aten.convolution.default(primals_24, primals_2, primals_1, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1 = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_7, primals_3, primals_5, primals_6, False, 1.0, 1e-05);  primals_3 = None
        getitem = native_batch_norm_default[0];  native_batch_norm_default = None
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu__default, [2, 2], [2, 2])
        getitem_3 = max_pool2d_with_indices_default[0]
        getitem_4 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_1 = torch.ops.aten.convolution.default(getitem_3, primals_11, primals_10, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_10 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_16, primals_12, primals_14, primals_15, False, 1.0, 1e-05);  primals_12 = None
        getitem_5 = native_batch_norm_default_1[0];  native_batch_norm_default_1 = None
        relu__default_1 = torch.ops.aten.relu_.default(getitem_5);  getitem_5 = None
        max_pool2d_with_indices_default_1 = torch.ops.aten.max_pool2d_with_indices.default(relu__default_1, [2, 2], [2, 2])
        getitem_8 = max_pool2d_with_indices_default_1[0]
        getitem_9 = max_pool2d_with_indices_default_1[1];  max_pool2d_with_indices_default_1 = None
        convolution_default_2 = torch.ops.aten.convolution.default(getitem_8, primals_18, primals_17, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_17 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_23, primals_19, primals_21, primals_22, False, 1.0, 1e-05);  primals_19 = None
        getitem_10 = native_batch_norm_default_2[0];  native_batch_norm_default_2 = None
        relu__default_2 = torch.ops.aten.relu_.default(getitem_10);  getitem_10 = None
        max_pool2d_with_indices_default_2 = torch.ops.aten.max_pool2d_with_indices.default(relu__default_2, [2, 2], [2, 2])
        getitem_13 = max_pool2d_with_indices_default_2[0]
        getitem_14 = max_pool2d_with_indices_default_2[1];  max_pool2d_with_indices_default_2 = None
        view_default = torch.ops.aten.view.default(getitem_13, [5, 64]);  getitem_13 = None
        t_default = torch.ops.aten.t.default(primals_9);  primals_9 = None
        addmm_default = torch.ops.aten.addmm.default(primals_8, view_default, t_default);  primals_8 = None
        return [addmm_default, primals_23, primals_2, relu__default, primals_24, primals_14, getitem_3, getitem_8, getitem_4, convolution_default_2, primals_15, primals_5, convolution_default, convolution_default_1, getitem_9, primals_16, getitem_14, primals_6, relu__default_2, relu__default_1, primals_7, primals_18, view_default, t_default, primals_21, primals_11, primals_22]
        
