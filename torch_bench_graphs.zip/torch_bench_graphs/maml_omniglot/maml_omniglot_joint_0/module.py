
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/maml_omniglot/maml_omniglot_joint_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, tangents_1):
        convolution_default = torch.ops.aten.convolution.default(primals_24, primals_2, primals_1, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1 = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_7, primals_3, primals_5, primals_6, False, 1.0, 1e-05);  primals_3 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        new_zeros_default = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_2 = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu__default, [2, 2], [2, 2])
        getitem_3 = max_pool2d_with_indices_default[0]
        getitem_4 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_1 = torch.ops.aten.convolution.default(getitem_3, primals_11, primals_10, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_10 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_16, primals_12, primals_14, primals_15, False, 1.0, 1e-05);  primals_12 = None
        getitem_5 = native_batch_norm_default_1[0]
        getitem_6 = native_batch_norm_default_1[1]
        getitem_7 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_5 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_1 = torch.ops.aten.relu_.default(getitem_5);  getitem_5 = None
        max_pool2d_with_indices_default_1 = torch.ops.aten.max_pool2d_with_indices.default(relu__default_1, [2, 2], [2, 2])
        getitem_8 = max_pool2d_with_indices_default_1[0]
        getitem_9 = max_pool2d_with_indices_default_1[1];  max_pool2d_with_indices_default_1 = None
        convolution_default_2 = torch.ops.aten.convolution.default(getitem_8, primals_18, primals_17, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_17 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_23, primals_19, primals_21, primals_22, False, 1.0, 1e-05);  primals_19 = None
        getitem_10 = native_batch_norm_default_2[0]
        getitem_11 = native_batch_norm_default_2[1]
        getitem_12 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_8 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_2 = torch.ops.aten.relu_.default(getitem_10);  getitem_10 = None
        max_pool2d_with_indices_default_2 = torch.ops.aten.max_pool2d_with_indices.default(relu__default_2, [2, 2], [2, 2])
        getitem_13 = max_pool2d_with_indices_default_2[0]
        getitem_14 = max_pool2d_with_indices_default_2[1];  max_pool2d_with_indices_default_2 = None
        view_default = torch.ops.aten.view.default(getitem_13, [5, 64]);  getitem_13 = None
        t_default = torch.ops.aten.t.default(primals_9);  primals_9 = None
        addmm_default = torch.ops.aten.addmm.default(primals_8, view_default, t_default);  primals_8 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(addmm_default, tangents_1)
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, view_default);  t_default_2 = view_default = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_1 = torch.ops.aten.view.default(sum_dim_int_list, [5]);  sum_dim_int_list = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        view_default_2 = torch.ops.aten.view.default(mm_default, [5, 64, 1, 1]);  mm_default = None
        max_pool2d_with_indices_backward_default = torch.ops.aten.max_pool2d_with_indices_backward.default(view_default_2, relu__default_2, [2, 2], [2, 2], [0, 0], [1, 1], False, getitem_14);  view_default_2 = getitem_14 = None
        to_dtype = torch.ops.aten.to.dtype(max_pool2d_with_indices_backward_default, torch.float32);  max_pool2d_with_indices_backward_default = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default_9 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_9, to_dtype);  le_scalar = new_zeros_default_9 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_2, convolution_default_2, primals_23, primals_21, primals_22, new_zeros_default_6, new_zeros_default_7, False, 1e-05, [True, True, True]);  to_dtype_2 = convolution_default_2 = primals_23 = primals_21 = primals_22 = new_zeros_default_6 = new_zeros_default_7 = None
        getitem_15 = native_batch_norm_backward_default[0]
        getitem_16 = native_batch_norm_backward_default[1]
        getitem_17 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(getitem_15, getitem_8, primals_18, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_15 = getitem_8 = primals_18 = None
        getitem_18 = convolution_backward_default[0]
        getitem_19 = convolution_backward_default[1]
        getitem_20 = convolution_backward_default[2];  convolution_backward_default = None
        max_pool2d_with_indices_backward_default_1 = torch.ops.aten.max_pool2d_with_indices_backward.default(getitem_18, relu__default_1, [2, 2], [2, 2], [0, 0], [1, 1], False, getitem_9);  getitem_18 = getitem_9 = None
        to_dtype_3 = torch.ops.aten.to.dtype(max_pool2d_with_indices_backward_default_1, torch.float32);  max_pool2d_with_indices_backward_default_1 = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_10 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_10, to_dtype_3);  le_scalar_1 = new_zeros_default_10 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_5, convolution_default_1, primals_16, primals_14, primals_15, new_zeros_default_3, new_zeros_default_4, False, 1e-05, [True, True, True]);  to_dtype_5 = convolution_default_1 = primals_16 = primals_14 = primals_15 = new_zeros_default_3 = new_zeros_default_4 = None
        getitem_21 = native_batch_norm_backward_default_1[0]
        getitem_22 = native_batch_norm_backward_default_1[1]
        getitem_23 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_21, getitem_3, primals_11, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_21 = getitem_3 = primals_11 = None
        getitem_24 = convolution_backward_default_1[0]
        getitem_25 = convolution_backward_default_1[1]
        getitem_26 = convolution_backward_default_1[2];  convolution_backward_default_1 = None
        max_pool2d_with_indices_backward_default_2 = torch.ops.aten.max_pool2d_with_indices_backward.default(getitem_24, relu__default, [2, 2], [2, 2], [0, 0], [1, 1], False, getitem_4);  getitem_24 = getitem_4 = None
        to_dtype_6 = torch.ops.aten.to.dtype(max_pool2d_with_indices_backward_default_2, torch.float32);  max_pool2d_with_indices_backward_default_2 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_11 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_11, to_dtype_6);  le_scalar_2 = new_zeros_default_11 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_8, convolution_default, primals_7, primals_5, primals_6, new_zeros_default, new_zeros_default_1, False, 1e-05, [True, True, True]);  to_dtype_8 = convolution_default = primals_7 = primals_5 = primals_6 = new_zeros_default = new_zeros_default_1 = None
        getitem_27 = native_batch_norm_backward_default_2[0]
        getitem_28 = native_batch_norm_backward_default_2[1]
        getitem_29 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_27, primals_24, primals_2, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [False, True, True]);  getitem_27 = primals_24 = primals_2 = None
        getitem_30 = convolution_backward_default_2[0]
        getitem_31 = convolution_backward_default_2[1]
        getitem_32 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        return [addmm_default, getitem_32, getitem_31, getitem_29, None, None, None, getitem_28, view_default_1, t_default_4, getitem_26, getitem_25, getitem_23, None, None, None, getitem_22, getitem_20, getitem_19, getitem_17, None, None, None, getitem_16, None]
        
