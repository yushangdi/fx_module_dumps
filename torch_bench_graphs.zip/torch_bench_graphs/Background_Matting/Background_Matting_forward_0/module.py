
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/Background_Matting/Background_Matting_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326):
        reflection_pad2d_default = torch.ops.aten.reflection_pad2d.default(primals_323, [3, 3, 3, 3]);  primals_323 = None
        convolution_default = torch.ops.aten.convolution.default(reflection_pad2d_default, primals_43, primals_42, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_42 = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_48, primals_44, primals_46, primals_47, False, 0.1, 1e-05);  primals_44 = None
        getitem = native_batch_norm_default[0];  native_batch_norm_default = None
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default, primals_50, primals_49, [2, 2], [1, 1], [1, 1], False, [0, 0], 1);  primals_49 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_55, primals_51, primals_53, primals_54, False, 0.1, 1e-05);  primals_51 = None
        getitem_3 = native_batch_norm_default_1[0];  native_batch_norm_default_1 = None
        relu__default_1 = torch.ops.aten.relu_.default(getitem_3);  getitem_3 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_57, primals_56, [2, 2], [1, 1], [1, 1], False, [0, 0], 1);  primals_56 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_62, primals_58, primals_60, primals_61, False, 0.1, 1e-05);  primals_58 = None
        getitem_6 = native_batch_norm_default_2[0];  native_batch_norm_default_2 = None
        relu__default_2 = torch.ops.aten.relu_.default(getitem_6);  getitem_6 = None
        reflection_pad2d_default_1 = torch.ops.aten.reflection_pad2d.default(primals_324, [3, 3, 3, 3]);  primals_324 = None
        convolution_default_3 = torch.ops.aten.convolution.default(reflection_pad2d_default_1, primals_64, primals_63, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_63 = None
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_69, primals_65, primals_67, primals_68, False, 0.1, 1e-05);  primals_65 = None
        getitem_9 = native_batch_norm_default_3[0];  native_batch_norm_default_3 = None
        relu__default_3 = torch.ops.aten.relu_.default(getitem_9);  getitem_9 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu__default_3, primals_71, primals_70, [2, 2], [1, 1], [1, 1], False, [0, 0], 1);  primals_70 = None
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_76, primals_72, primals_74, primals_75, False, 0.1, 1e-05);  primals_72 = None
        getitem_12 = native_batch_norm_default_4[0];  native_batch_norm_default_4 = None
        relu__default_4 = torch.ops.aten.relu_.default(getitem_12);  getitem_12 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_4, primals_78, primals_77, [2, 2], [1, 1], [1, 1], False, [0, 0], 1);  primals_77 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_83, primals_79, primals_81, primals_82, False, 0.1, 1e-05);  primals_79 = None
        getitem_15 = native_batch_norm_default_5[0];  native_batch_norm_default_5 = None
        relu__default_5 = torch.ops.aten.relu_.default(getitem_15);  getitem_15 = None
        reflection_pad2d_default_2 = torch.ops.aten.reflection_pad2d.default(primals_325, [3, 3, 3, 3]);  primals_325 = None
        convolution_default_6 = torch.ops.aten.convolution.default(reflection_pad2d_default_2, primals_106, primals_105, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_105 = None
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_111, primals_107, primals_109, primals_110, False, 0.1, 1e-05);  primals_107 = None
        getitem_18 = native_batch_norm_default_6[0];  native_batch_norm_default_6 = None
        relu__default_6 = torch.ops.aten.relu_.default(getitem_18);  getitem_18 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_6, primals_113, primals_112, [2, 2], [1, 1], [1, 1], False, [0, 0], 1);  primals_112 = None
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_118, primals_114, primals_116, primals_117, False, 0.1, 1e-05);  primals_114 = None
        getitem_21 = native_batch_norm_default_7[0];  native_batch_norm_default_7 = None
        relu__default_7 = torch.ops.aten.relu_.default(getitem_21);  getitem_21 = None
        convolution_default_8 = torch.ops.aten.convolution.default(relu__default_7, primals_120, primals_119, [2, 2], [1, 1], [1, 1], False, [0, 0], 1);  primals_119 = None
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_125, primals_121, primals_123, primals_124, False, 0.1, 1e-05);  primals_121 = None
        getitem_24 = native_batch_norm_default_8[0];  native_batch_norm_default_8 = None
        relu__default_8 = torch.ops.aten.relu_.default(getitem_24);  getitem_24 = None
        cat_default = torch.ops.aten.cat.default([relu__default_2, relu__default_5], 1)
        convolution_default_12 = torch.ops.aten.convolution.default(cat_default, primals_1, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_6, primals_2, primals_4, primals_5, False, 0.1, 1e-05);  primals_2 = None
        getitem_36 = native_batch_norm_default_12[0];  native_batch_norm_default_12 = None
        relu__default_12 = torch.ops.aten.relu_.default(getitem_36);  getitem_36 = None
        cat_default_1 = torch.ops.aten.cat.default([relu__default_2, relu__default_8], 1)
        convolution_default_13 = torch.ops.aten.convolution.default(cat_default_1, primals_13, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_18, primals_14, primals_16, primals_17, False, 0.1, 1e-05);  primals_14 = None
        getitem_39 = native_batch_norm_default_13[0];  native_batch_norm_default_13 = None
        relu__default_13 = torch.ops.aten.relu_.default(getitem_39);  getitem_39 = None
        cat_default_2 = torch.ops.aten.cat.default([relu__default_2, relu__default_5], 1)
        convolution_default_14 = torch.ops.aten.convolution.default(cat_default_2, primals_7, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_12, primals_8, primals_10, primals_11, False, 0.1, 1e-05);  primals_8 = None
        getitem_42 = native_batch_norm_default_14[0];  native_batch_norm_default_14 = None
        relu__default_14 = torch.ops.aten.relu_.default(getitem_42);  getitem_42 = None
        cat_default_3 = torch.ops.aten.cat.default([relu__default_12, relu__default_13, relu__default_14], 1)
        cat_default_4 = torch.ops.aten.cat.default([relu__default_2, cat_default_3], 1);  cat_default_3 = None
        convolution_default_15 = torch.ops.aten.convolution.default(cat_default_4, primals_135, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_140, primals_136, primals_138, primals_139, False, 0.1, 1e-05);  primals_136 = None
        getitem_45 = native_batch_norm_default_15[0];  native_batch_norm_default_15 = None
        relu__default_15 = torch.ops.aten.relu_.default(getitem_45);  getitem_45 = None
        reflection_pad2d_default_4 = torch.ops.aten.reflection_pad2d.default(relu__default_15, [1, 1, 1, 1])
        convolution_default_16 = torch.ops.aten.convolution.default(reflection_pad2d_default_4, primals_142, primals_141, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_141 = None
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_147, primals_143, primals_145, primals_146, False, 0.1, 1e-05);  primals_143 = None
        getitem_48 = native_batch_norm_default_16[0];  native_batch_norm_default_16 = None
        relu__default_16 = torch.ops.aten.relu_.default(getitem_48);  getitem_48 = None
        reflection_pad2d_default_5 = torch.ops.aten.reflection_pad2d.default(relu__default_16, [1, 1, 1, 1])
        convolution_default_17 = torch.ops.aten.convolution.default(reflection_pad2d_default_5, primals_149, primals_148, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_148 = None
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_154, primals_150, primals_152, primals_153, False, 0.1, 1e-05);  primals_150 = None
        getitem_51 = native_batch_norm_default_17[0];  native_batch_norm_default_17 = None
        add_tensor = torch.ops.aten.add.Tensor(relu__default_15, getitem_51);  getitem_51 = None
        reflection_pad2d_default_6 = torch.ops.aten.reflection_pad2d.default(add_tensor, [1, 1, 1, 1])
        convolution_default_18 = torch.ops.aten.convolution.default(reflection_pad2d_default_6, primals_156, primals_155, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_155 = None
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_161, primals_157, primals_159, primals_160, False, 0.1, 1e-05);  primals_157 = None
        getitem_54 = native_batch_norm_default_18[0];  native_batch_norm_default_18 = None
        relu__default_17 = torch.ops.aten.relu_.default(getitem_54);  getitem_54 = None
        reflection_pad2d_default_7 = torch.ops.aten.reflection_pad2d.default(relu__default_17, [1, 1, 1, 1])
        convolution_default_19 = torch.ops.aten.convolution.default(reflection_pad2d_default_7, primals_163, primals_162, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_162 = None
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_168, primals_164, primals_166, primals_167, False, 0.1, 1e-05);  primals_164 = None
        getitem_57 = native_batch_norm_default_19[0];  native_batch_norm_default_19 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(add_tensor, getitem_57);  getitem_57 = None
        reflection_pad2d_default_8 = torch.ops.aten.reflection_pad2d.default(add_tensor_1, [1, 1, 1, 1])
        convolution_default_20 = torch.ops.aten.convolution.default(reflection_pad2d_default_8, primals_170, primals_169, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_169 = None
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_175, primals_171, primals_173, primals_174, False, 0.1, 1e-05);  primals_171 = None
        getitem_60 = native_batch_norm_default_20[0];  native_batch_norm_default_20 = None
        relu__default_18 = torch.ops.aten.relu_.default(getitem_60);  getitem_60 = None
        reflection_pad2d_default_9 = torch.ops.aten.reflection_pad2d.default(relu__default_18, [1, 1, 1, 1])
        convolution_default_21 = torch.ops.aten.convolution.default(reflection_pad2d_default_9, primals_177, primals_176, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_176 = None
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_182, primals_178, primals_180, primals_181, False, 0.1, 1e-05);  primals_178 = None
        getitem_63 = native_batch_norm_default_21[0];  native_batch_norm_default_21 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(add_tensor_1, getitem_63);  getitem_63 = None
        reflection_pad2d_default_10 = torch.ops.aten.reflection_pad2d.default(add_tensor_2, [1, 1, 1, 1])
        convolution_default_22 = torch.ops.aten.convolution.default(reflection_pad2d_default_10, primals_184, primals_183, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_183 = None
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_189, primals_185, primals_187, primals_188, False, 0.1, 1e-05);  primals_185 = None
        getitem_66 = native_batch_norm_default_22[0];  native_batch_norm_default_22 = None
        relu__default_19 = torch.ops.aten.relu_.default(getitem_66);  getitem_66 = None
        reflection_pad2d_default_11 = torch.ops.aten.reflection_pad2d.default(relu__default_19, [1, 1, 1, 1])
        convolution_default_23 = torch.ops.aten.convolution.default(reflection_pad2d_default_11, primals_191, primals_190, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_190 = None
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_196, primals_192, primals_194, primals_195, False, 0.1, 1e-05);  primals_192 = None
        getitem_69 = native_batch_norm_default_23[0];  native_batch_norm_default_23 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(add_tensor_2, getitem_69);  getitem_69 = None
        reflection_pad2d_default_12 = torch.ops.aten.reflection_pad2d.default(add_tensor_3, [1, 1, 1, 1])
        convolution_default_24 = torch.ops.aten.convolution.default(reflection_pad2d_default_12, primals_198, primals_197, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_197 = None
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_203, primals_199, primals_201, primals_202, False, 0.1, 1e-05);  primals_199 = None
        getitem_72 = native_batch_norm_default_24[0];  native_batch_norm_default_24 = None
        relu__default_20 = torch.ops.aten.relu_.default(getitem_72);  getitem_72 = None
        reflection_pad2d_default_13 = torch.ops.aten.reflection_pad2d.default(relu__default_20, [1, 1, 1, 1])
        convolution_default_25 = torch.ops.aten.convolution.default(reflection_pad2d_default_13, primals_205, primals_204, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_204 = None
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_210, primals_206, primals_208, primals_209, False, 0.1, 1e-05);  primals_206 = None
        getitem_75 = native_batch_norm_default_25[0];  native_batch_norm_default_25 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(add_tensor_3, getitem_75);  getitem_75 = None
        reflection_pad2d_default_14 = torch.ops.aten.reflection_pad2d.default(add_tensor_4, [1, 1, 1, 1])
        convolution_default_26 = torch.ops.aten.convolution.default(reflection_pad2d_default_14, primals_212, primals_211, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_211 = None
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_217, primals_213, primals_215, primals_216, False, 0.1, 1e-05);  primals_213 = None
        getitem_78 = native_batch_norm_default_26[0];  native_batch_norm_default_26 = None
        relu__default_21 = torch.ops.aten.relu_.default(getitem_78);  getitem_78 = None
        reflection_pad2d_default_15 = torch.ops.aten.reflection_pad2d.default(relu__default_21, [1, 1, 1, 1])
        convolution_default_27 = torch.ops.aten.convolution.default(reflection_pad2d_default_15, primals_219, primals_218, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_218 = None
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_224, primals_220, primals_222, primals_223, False, 0.1, 1e-05);  primals_220 = None
        getitem_81 = native_batch_norm_default_27[0];  native_batch_norm_default_27 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(add_tensor_4, getitem_81);  getitem_81 = None
        reflection_pad2d_default_16 = torch.ops.aten.reflection_pad2d.default(add_tensor_5, [1, 1, 1, 1])
        convolution_default_28 = torch.ops.aten.convolution.default(reflection_pad2d_default_16, primals_226, primals_225, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_225 = None
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_231, primals_227, primals_229, primals_230, False, 0.1, 1e-05);  primals_227 = None
        getitem_84 = native_batch_norm_default_28[0];  native_batch_norm_default_28 = None
        relu__default_22 = torch.ops.aten.relu_.default(getitem_84);  getitem_84 = None
        reflection_pad2d_default_17 = torch.ops.aten.reflection_pad2d.default(relu__default_22, [1, 1, 1, 1])
        convolution_default_29 = torch.ops.aten.convolution.default(reflection_pad2d_default_17, primals_233, primals_232, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_232 = None
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_238, primals_234, primals_236, primals_237, False, 0.1, 1e-05);  primals_234 = None
        getitem_87 = native_batch_norm_default_29[0];  native_batch_norm_default_29 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(add_tensor_5, getitem_87);  getitem_87 = None
        reflection_pad2d_default_18 = torch.ops.aten.reflection_pad2d.default(add_tensor_6, [1, 1, 1, 1])
        convolution_default_30 = torch.ops.aten.convolution.default(reflection_pad2d_default_18, primals_240, primals_239, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_239 = None
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_245, primals_241, primals_243, primals_244, False, 0.1, 1e-05);  primals_241 = None
        getitem_90 = native_batch_norm_default_30[0];  native_batch_norm_default_30 = None
        relu__default_23 = torch.ops.aten.relu_.default(getitem_90);  getitem_90 = None
        reflection_pad2d_default_19 = torch.ops.aten.reflection_pad2d.default(relu__default_23, [1, 1, 1, 1])
        convolution_default_31 = torch.ops.aten.convolution.default(reflection_pad2d_default_19, primals_247, primals_246, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_246 = None
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_31, primals_252, primals_248, primals_250, primals_251, False, 0.1, 1e-05);  primals_248 = None
        getitem_93 = native_batch_norm_default_31[0];  native_batch_norm_default_31 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(add_tensor_6, getitem_93);  getitem_93 = None
        reflection_pad2d_default_20 = torch.ops.aten.reflection_pad2d.default(add_tensor_7, [1, 1, 1, 1])
        convolution_default_32 = torch.ops.aten.convolution.default(reflection_pad2d_default_20, primals_254, primals_253, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_253 = None
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_259, primals_255, primals_257, primals_258, False, 0.1, 1e-05);  primals_255 = None
        getitem_96 = native_batch_norm_default_32[0];  native_batch_norm_default_32 = None
        relu__default_24 = torch.ops.aten.relu_.default(getitem_96);  getitem_96 = None
        reflection_pad2d_default_21 = torch.ops.aten.reflection_pad2d.default(relu__default_24, [1, 1, 1, 1])
        convolution_default_33 = torch.ops.aten.convolution.default(reflection_pad2d_default_21, primals_261, primals_260, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_260 = None
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_266, primals_262, primals_264, primals_265, False, 0.1, 1e-05);  primals_262 = None
        getitem_99 = native_batch_norm_default_33[0];  native_batch_norm_default_33 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(add_tensor_7, getitem_99);  getitem_99 = None
        reflection_pad2d_default_22 = torch.ops.aten.reflection_pad2d.default(add_tensor_8, [1, 1, 1, 1])
        convolution_default_34 = torch.ops.aten.convolution.default(reflection_pad2d_default_22, primals_268, primals_267, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_267 = None
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_273, primals_269, primals_271, primals_272, False, 0.1, 1e-05);  primals_269 = None
        getitem_102 = native_batch_norm_default_34[0];  native_batch_norm_default_34 = None
        relu__default_25 = torch.ops.aten.relu_.default(getitem_102);  getitem_102 = None
        reflection_pad2d_default_23 = torch.ops.aten.reflection_pad2d.default(relu__default_25, [1, 1, 1, 1])
        convolution_default_35 = torch.ops.aten.convolution.default(reflection_pad2d_default_23, primals_275, primals_274, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_274 = None
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_280, primals_276, primals_278, primals_279, False, 0.1, 1e-05);  primals_276 = None
        getitem_105 = native_batch_norm_default_35[0];  native_batch_norm_default_35 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(add_tensor_8, getitem_105);  getitem_105 = None
        upsample_bilinear2d_vec = torch.ops.aten.upsample_bilinear2d.vec(add_tensor_9, None, True, [2.0, 2.0]);  add_tensor_9 = None
        convolution_default_36 = torch.ops.aten.convolution.default(upsample_bilinear2d_vec, primals_20, primals_19, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_19 = None
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_25, primals_21, primals_23, primals_24, False, 0.1, 1e-05);  primals_21 = None
        getitem_108 = native_batch_norm_default_36[0];  native_batch_norm_default_36 = None
        relu__default_26 = torch.ops.aten.relu_.default(getitem_108);  getitem_108 = None
        upsample_bilinear2d_vec_1 = torch.ops.aten.upsample_bilinear2d.vec(relu__default_26, None, True, [2.0, 2.0])
        convolution_default_37 = torch.ops.aten.convolution.default(upsample_bilinear2d_vec_1, primals_27, primals_26, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_26 = None
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_37, primals_32, primals_28, primals_30, primals_31, False, 0.1, 1e-05);  primals_28 = None
        getitem_111 = native_batch_norm_default_37[0];  native_batch_norm_default_37 = None
        relu__default_27 = torch.ops.aten.relu_.default(getitem_111);  getitem_111 = None
        reflection_pad2d_default_24 = torch.ops.aten.reflection_pad2d.default(relu__default_27, [3, 3, 3, 3])
        convolution_default_38 = torch.ops.aten.convolution.default(reflection_pad2d_default_24, primals_34, primals_33, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_33 = None
        tanh_default = torch.ops.aten.tanh.default(convolution_default_38);  convolution_default_38 = None
        reflection_pad2d_default_25 = torch.ops.aten.reflection_pad2d.default(add_tensor_6, [1, 1, 1, 1])
        convolution_default_39 = torch.ops.aten.convolution.default(reflection_pad2d_default_25, primals_282, primals_281, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_281 = None
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_39, primals_287, primals_283, primals_285, primals_286, False, 0.1, 1e-05);  primals_283 = None
        getitem_114 = native_batch_norm_default_38[0];  native_batch_norm_default_38 = None
        relu__default_28 = torch.ops.aten.relu_.default(getitem_114);  getitem_114 = None
        reflection_pad2d_default_26 = torch.ops.aten.reflection_pad2d.default(relu__default_28, [1, 1, 1, 1])
        convolution_default_40 = torch.ops.aten.convolution.default(reflection_pad2d_default_26, primals_289, primals_288, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_288 = None
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_294, primals_290, primals_292, primals_293, False, 0.1, 1e-05);  primals_290 = None
        getitem_117 = native_batch_norm_default_39[0];  native_batch_norm_default_39 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(add_tensor_6, getitem_117);  getitem_117 = None
        reflection_pad2d_default_27 = torch.ops.aten.reflection_pad2d.default(add_tensor_10, [1, 1, 1, 1])
        convolution_default_41 = torch.ops.aten.convolution.default(reflection_pad2d_default_27, primals_296, primals_295, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_295 = None
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_41, primals_301, primals_297, primals_299, primals_300, False, 0.1, 1e-05);  primals_297 = None
        getitem_120 = native_batch_norm_default_40[0];  native_batch_norm_default_40 = None
        relu__default_29 = torch.ops.aten.relu_.default(getitem_120);  getitem_120 = None
        reflection_pad2d_default_28 = torch.ops.aten.reflection_pad2d.default(relu__default_29, [1, 1, 1, 1])
        convolution_default_42 = torch.ops.aten.convolution.default(reflection_pad2d_default_28, primals_303, primals_302, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_302 = None
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_42, primals_308, primals_304, primals_306, primals_307, False, 0.1, 1e-05);  primals_304 = None
        getitem_123 = native_batch_norm_default_41[0];  native_batch_norm_default_41 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(add_tensor_10, getitem_123);  getitem_123 = None
        reflection_pad2d_default_29 = torch.ops.aten.reflection_pad2d.default(add_tensor_11, [1, 1, 1, 1])
        convolution_default_43 = torch.ops.aten.convolution.default(reflection_pad2d_default_29, primals_310, primals_309, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_309 = None
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_43, primals_315, primals_311, primals_313, primals_314, False, 0.1, 1e-05);  primals_311 = None
        getitem_126 = native_batch_norm_default_42[0];  native_batch_norm_default_42 = None
        relu__default_30 = torch.ops.aten.relu_.default(getitem_126);  getitem_126 = None
        reflection_pad2d_default_30 = torch.ops.aten.reflection_pad2d.default(relu__default_30, [1, 1, 1, 1])
        convolution_default_44 = torch.ops.aten.convolution.default(reflection_pad2d_default_30, primals_317, primals_316, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_316 = None
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_322, primals_318, primals_320, primals_321, False, 0.1, 1e-05);  primals_318 = None
        getitem_129 = native_batch_norm_default_43[0];  native_batch_norm_default_43 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(add_tensor_11, getitem_129);  getitem_129 = None
        upsample_bilinear2d_vec_2 = torch.ops.aten.upsample_bilinear2d.vec(add_tensor_12, None, True, [2.0, 2.0]);  add_tensor_12 = None
        convolution_default_45 = torch.ops.aten.convolution.default(upsample_bilinear2d_vec_2, primals_36, primals_35, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_35 = None
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_45, primals_41, primals_37, primals_39, primals_40, False, 0.1, 1e-05);  primals_37 = None
        getitem_132 = native_batch_norm_default_44[0];  native_batch_norm_default_44 = None
        relu__default_31 = torch.ops.aten.relu_.default(getitem_132);  getitem_132 = None
        cat_default_5 = torch.ops.aten.cat.default([relu__default_31, relu__default_1], 1)
        upsample_bilinear2d_vec_3 = torch.ops.aten.upsample_bilinear2d.vec(cat_default_5, None, True, [2.0, 2.0]);  cat_default_5 = None
        convolution_default_46 = torch.ops.aten.convolution.default(upsample_bilinear2d_vec_3, primals_127, primals_126, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_126 = None
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_46, primals_132, primals_128, primals_130, primals_131, False, 0.1, 1e-05);  primals_128 = None
        getitem_135 = native_batch_norm_default_45[0];  native_batch_norm_default_45 = None
        relu__default_32 = torch.ops.aten.relu_.default(getitem_135);  getitem_135 = None
        reflection_pad2d_default_31 = torch.ops.aten.reflection_pad2d.default(relu__default_32, [3, 3, 3, 3])
        convolution_default_47 = torch.ops.aten.convolution.default(reflection_pad2d_default_31, primals_134, primals_133, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_133 = None
        return [tanh_default, convolution_default_47, primals_280, relu__default_17, primals_30, primals_282, primals_6, primals_5, primals_31, convolution_default_18, primals_32, primals_285, primals_1, primals_34, primals_286, primals_287, primals_36, primals_289, primals_4, primals_39, primals_40, primals_292, primals_41, primals_293, convolution_default_19, primals_10, primals_294, reflection_pad2d_default_7, add_tensor_1, primals_43, primals_296, reflection_pad2d_default_8, primals_7, primals_46, primals_47, primals_299, primals_48, primals_300, convolution_default_20, primals_154, primals_217, relu__default_6, primals_50, convolution_default_7, primals_156, primals_219, convolution_default_42, convolution_default_25, primals_53, primals_54, primals_159, primals_222, convolution_default_40, primals_55, primals_160, primals_223, primals_161, primals_224, primals_57, reflection_pad2d_default_15, primals_163, primals_226, relu__default_7, reflection_pad2d_default_29, convolution_default_43, primals_60, convolution_default_8, reflection_pad2d_default_14, convolution_default_26, primals_61, primals_166, primals_229, relu__default_30, primals_62, primals_167, primals_230, relu__default_21, reflection_pad2d_default_27, convolution_default_41, primals_168, primals_231, primals_64, relu__default_29, primals_170, primals_233, add_tensor_11, reflection_pad2d_default_28, relu__default_8, primals_67, convolution_default_44, primals_68, primals_173, primals_236, convolution_default_27, add_tensor_5, primals_69, primals_174, primals_237, reflection_pad2d_default_30, cat_default, cat_default_1, convolution_default, relu__default, convolution_default_12, convolution_default_1, relu__default_12, convolution_default_13, primals_106, convolution_default_2, primals_109, primals_110, relu__default_1, primals_111, primals_259, primals_322, primals_16, primals_261, primals_13, primals_264, primals_265, primals_266, relu__default_24, primals_24, primals_268, primals_11, reflection_pad2d_default, convolution_default_33, reflection_pad2d_default_21, primals_271, add_tensor_8, primals_272, primals_27, primals_273, primals_20, primals_12, primals_275, primals_17, primals_23, reflection_pad2d_default_22, primals_278, convolution_default_34, primals_279, primals_25, primals_18, primals_196, relu__default_23, relu__default_19, primals_134, relu__default_15, relu__default_2, primals_135, primals_198, convolution_default_30, primals_138, primals_201, primals_139, primals_202, convolution_default_23, primals_140, primals_203, reflection_pad2d_default_11, convolution_default_16, reflection_pad2d_default_4, relu__default_3, primals_142, primals_205, relu__default_16, primals_145, primals_208, primals_146, primals_209, convolution_default_31, primals_147, primals_210, reflection_pad2d_default_19, reflection_pad2d_default_12, add_tensor_7, reflection_pad2d_default_1, convolution_default_3, convolution_default_24, primals_149, primals_212, convolution_default_4, reflection_pad2d_default_20, add_tensor_4, reflection_pad2d_default_5, convolution_default_17, relu__default_20, primals_152, primals_215, reflection_pad2d_default_13, primals_153, primals_216, reflection_pad2d_default_6, add_tensor, convolution_default_32, upsample_bilinear2d_vec_1, primals_71, primals_74, relu__default_27, primals_75, primals_76, primals_78, primals_81, primals_82, primals_83, reflection_pad2d_default_24, tanh_default, reflection_pad2d_default_25, reflection_pad2d_default_26, convolution_default_39, relu__default_28, add_tensor_10, primals_238, primals_301, relu__default_4, convolution_default_45, convolution_default_5, relu__default_25, relu__default_13, upsample_bilinear2d_vec_2, primals_240, primals_303, relu__default_31, cat_default_2, primals_243, primals_306, primals_244, primals_307, convolution_default_35, primals_245, primals_308, reflection_pad2d_default_23, reflection_pad2d_default_16, convolution_default_14, convolution_default_28, convolution_default_36, relu__default_32, upsample_bilinear2d_vec, primals_247, primals_310, relu__default_22, convolution_default_37, relu__default_14, primals_250, primals_313, convolution_default_15, relu__default_5, primals_251, primals_314, primals_252, primals_315, convolution_default_6, upsample_bilinear2d_vec_3, primals_254, primals_317, reflection_pad2d_default_31, convolution_default_46, cat_default_4, reflection_pad2d_default_17, convolution_default_29, relu__default_26, primals_257, primals_320, primals_258, primals_321, reflection_pad2d_default_18, reflection_pad2d_default_2, add_tensor_6, primals_175, relu__default_18, primals_113, primals_177, primals_116, primals_117, primals_180, primals_118, primals_181, primals_182, primals_120, primals_184, convolution_default_21, reflection_pad2d_default_9, primals_123, primals_124, primals_187, add_tensor_2, primals_125, primals_188, primals_189, primals_127, primals_191, add_tensor_3, primals_130, reflection_pad2d_default_10, primals_131, primals_194, convolution_default_22, primals_132, primals_195]
        
