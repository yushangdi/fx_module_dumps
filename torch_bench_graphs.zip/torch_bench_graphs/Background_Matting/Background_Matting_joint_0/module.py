
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/Background_Matting/Background_Matting_joint_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, tangents_1, tangents_2):
        reflection_pad2d_default = torch.ops.aten.reflection_pad2d.default(primals_323, [3, 3, 3, 3]);  primals_323 = None
        convolution_default = torch.ops.aten.convolution.default(reflection_pad2d_default, primals_43, primals_42, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_42 = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_48, primals_44, primals_46, primals_47, False, 0.1, 1e-05);  primals_44 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        new_zeros_default = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_2 = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default, primals_50, primals_49, [2, 2], [1, 1], [1, 1], False, [0, 0], 1);  primals_49 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_55, primals_51, primals_53, primals_54, False, 0.1, 1e-05);  primals_51 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_5 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_1 = torch.ops.aten.relu_.default(getitem_3);  getitem_3 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_57, primals_56, [2, 2], [1, 1], [1, 1], False, [0, 0], 1);  primals_56 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_62, primals_58, primals_60, primals_61, False, 0.1, 1e-05);  primals_58 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_8 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_2 = torch.ops.aten.relu_.default(getitem_6);  getitem_6 = None
        reflection_pad2d_default_1 = torch.ops.aten.reflection_pad2d.default(primals_324, [3, 3, 3, 3]);  primals_324 = None
        convolution_default_3 = torch.ops.aten.convolution.default(reflection_pad2d_default_1, primals_64, primals_63, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_63 = None
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_69, primals_65, primals_67, primals_68, False, 0.1, 1e-05);  primals_65 = None
        getitem_9 = native_batch_norm_default_3[0]
        getitem_10 = native_batch_norm_default_3[1]
        getitem_11 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        new_zeros_default_9 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_10 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_11 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_3 = torch.ops.aten.relu_.default(getitem_9);  getitem_9 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu__default_3, primals_71, primals_70, [2, 2], [1, 1], [1, 1], False, [0, 0], 1);  primals_70 = None
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_76, primals_72, primals_74, primals_75, False, 0.1, 1e-05);  primals_72 = None
        getitem_12 = native_batch_norm_default_4[0]
        getitem_13 = native_batch_norm_default_4[1]
        getitem_14 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        new_zeros_default_12 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_13 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_14 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_4 = torch.ops.aten.relu_.default(getitem_12);  getitem_12 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_4, primals_78, primals_77, [2, 2], [1, 1], [1, 1], False, [0, 0], 1);  primals_77 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_83, primals_79, primals_81, primals_82, False, 0.1, 1e-05);  primals_79 = None
        getitem_15 = native_batch_norm_default_5[0]
        getitem_16 = native_batch_norm_default_5[1]
        getitem_17 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        new_zeros_default_15 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_16 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_17 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_5 = torch.ops.aten.relu_.default(getitem_15);  getitem_15 = None
        reflection_pad2d_default_2 = torch.ops.aten.reflection_pad2d.default(primals_325, [3, 3, 3, 3]);  primals_325 = None
        convolution_default_6 = torch.ops.aten.convolution.default(reflection_pad2d_default_2, primals_106, primals_105, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_105 = None
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_111, primals_107, primals_109, primals_110, False, 0.1, 1e-05);  primals_107 = None
        getitem_18 = native_batch_norm_default_6[0]
        getitem_19 = native_batch_norm_default_6[1]
        getitem_20 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        new_zeros_default_18 = torch.ops.aten.new_zeros.default(convolution_default_6, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_19 = torch.ops.aten.new_zeros.default(convolution_default_6, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_20 = torch.ops.aten.new_zeros.default(convolution_default_6, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_6 = torch.ops.aten.relu_.default(getitem_18);  getitem_18 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_6, primals_113, primals_112, [2, 2], [1, 1], [1, 1], False, [0, 0], 1);  primals_112 = None
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_118, primals_114, primals_116, primals_117, False, 0.1, 1e-05);  primals_114 = None
        getitem_21 = native_batch_norm_default_7[0]
        getitem_22 = native_batch_norm_default_7[1]
        getitem_23 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        new_zeros_default_21 = torch.ops.aten.new_zeros.default(convolution_default_7, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_22 = torch.ops.aten.new_zeros.default(convolution_default_7, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_23 = torch.ops.aten.new_zeros.default(convolution_default_7, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_7 = torch.ops.aten.relu_.default(getitem_21);  getitem_21 = None
        convolution_default_8 = torch.ops.aten.convolution.default(relu__default_7, primals_120, primals_119, [2, 2], [1, 1], [1, 1], False, [0, 0], 1);  primals_119 = None
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_125, primals_121, primals_123, primals_124, False, 0.1, 1e-05);  primals_121 = None
        getitem_24 = native_batch_norm_default_8[0]
        getitem_25 = native_batch_norm_default_8[1]
        getitem_26 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        new_zeros_default_24 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_25 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_26 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_8 = torch.ops.aten.relu_.default(getitem_24);  getitem_24 = None
        reflection_pad2d_default_3 = torch.ops.aten.reflection_pad2d.default(primals_326, [3, 3, 3, 3]);  primals_326 = None
        convolution_default_9 = torch.ops.aten.convolution.default(reflection_pad2d_default_3, primals_85, primals_84, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  reflection_pad2d_default_3 = primals_85 = primals_84 = None
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_90, primals_86, primals_88, primals_89, False, 0.1, 1e-05);  primals_90 = primals_86 = primals_88 = primals_89 = None
        getitem_27 = native_batch_norm_default_9[0]
        getitem_28 = native_batch_norm_default_9[1]
        getitem_29 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        new_zeros_default_27 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_28 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_29 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False);  convolution_default_9 = None
        relu__default_9 = torch.ops.aten.relu_.default(getitem_27);  getitem_27 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default_9, primals_92, primals_91, [2, 2], [1, 1], [1, 1], False, [0, 0], 1);  relu__default_9 = primals_92 = primals_91 = None
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_97, primals_93, primals_95, primals_96, False, 0.1, 1e-05);  primals_97 = primals_93 = primals_95 = primals_96 = None
        getitem_30 = native_batch_norm_default_10[0]
        getitem_31 = native_batch_norm_default_10[1]
        getitem_32 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        new_zeros_default_30 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_31 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_32 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False);  convolution_default_10 = None
        relu__default_10 = torch.ops.aten.relu_.default(getitem_30);  getitem_30 = None
        convolution_default_11 = torch.ops.aten.convolution.default(relu__default_10, primals_99, primals_98, [2, 2], [1, 1], [1, 1], False, [0, 0], 1);  relu__default_10 = primals_99 = primals_98 = None
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_104, primals_100, primals_102, primals_103, False, 0.1, 1e-05);  primals_104 = primals_100 = primals_102 = primals_103 = None
        getitem_33 = native_batch_norm_default_11[0]
        getitem_34 = native_batch_norm_default_11[1]
        getitem_35 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        new_zeros_default_33 = torch.ops.aten.new_zeros.default(convolution_default_11, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_34 = torch.ops.aten.new_zeros.default(convolution_default_11, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_35 = torch.ops.aten.new_zeros.default(convolution_default_11, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False);  convolution_default_11 = None
        relu__default_11 = torch.ops.aten.relu_.default(getitem_33);  getitem_33 = None
        cat_default = torch.ops.aten.cat.default([relu__default_2, relu__default_5], 1)
        convolution_default_12 = torch.ops.aten.convolution.default(cat_default, primals_1, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_6, primals_2, primals_4, primals_5, False, 0.1, 1e-05);  primals_2 = None
        getitem_36 = native_batch_norm_default_12[0]
        getitem_37 = native_batch_norm_default_12[1]
        getitem_38 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        new_zeros_default_36 = torch.ops.aten.new_zeros.default(convolution_default_12, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_37 = torch.ops.aten.new_zeros.default(convolution_default_12, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_38 = torch.ops.aten.new_zeros.default(convolution_default_12, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_12 = torch.ops.aten.relu_.default(getitem_36);  getitem_36 = None
        cat_default_1 = torch.ops.aten.cat.default([relu__default_2, relu__default_8], 1)
        convolution_default_13 = torch.ops.aten.convolution.default(cat_default_1, primals_13, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_18, primals_14, primals_16, primals_17, False, 0.1, 1e-05);  primals_14 = None
        getitem_39 = native_batch_norm_default_13[0]
        getitem_40 = native_batch_norm_default_13[1]
        getitem_41 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        new_zeros_default_39 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_40 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_41 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_13 = torch.ops.aten.relu_.default(getitem_39);  getitem_39 = None
        cat_default_2 = torch.ops.aten.cat.default([relu__default_2, relu__default_5], 1)
        convolution_default_14 = torch.ops.aten.convolution.default(cat_default_2, primals_7, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_12, primals_8, primals_10, primals_11, False, 0.1, 1e-05);  primals_8 = None
        getitem_42 = native_batch_norm_default_14[0]
        getitem_43 = native_batch_norm_default_14[1]
        getitem_44 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        new_zeros_default_42 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_43 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_44 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_14 = torch.ops.aten.relu_.default(getitem_42);  getitem_42 = None
        cat_default_3 = torch.ops.aten.cat.default([relu__default_12, relu__default_13, relu__default_14], 1)
        cat_default_4 = torch.ops.aten.cat.default([relu__default_2, cat_default_3], 1);  cat_default_3 = None
        convolution_default_15 = torch.ops.aten.convolution.default(cat_default_4, primals_135, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_140, primals_136, primals_138, primals_139, False, 0.1, 1e-05);  primals_136 = None
        getitem_45 = native_batch_norm_default_15[0]
        getitem_46 = native_batch_norm_default_15[1]
        getitem_47 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        new_zeros_default_45 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_46 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_47 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_15 = torch.ops.aten.relu_.default(getitem_45);  getitem_45 = None
        reflection_pad2d_default_4 = torch.ops.aten.reflection_pad2d.default(relu__default_15, [1, 1, 1, 1])
        convolution_default_16 = torch.ops.aten.convolution.default(reflection_pad2d_default_4, primals_142, primals_141, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_141 = None
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_147, primals_143, primals_145, primals_146, False, 0.1, 1e-05);  primals_143 = None
        getitem_48 = native_batch_norm_default_16[0]
        getitem_49 = native_batch_norm_default_16[1]
        getitem_50 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        new_zeros_default_48 = torch.ops.aten.new_zeros.default(convolution_default_16, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_49 = torch.ops.aten.new_zeros.default(convolution_default_16, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_50 = torch.ops.aten.new_zeros.default(convolution_default_16, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_16 = torch.ops.aten.relu_.default(getitem_48);  getitem_48 = None
        reflection_pad2d_default_5 = torch.ops.aten.reflection_pad2d.default(relu__default_16, [1, 1, 1, 1])
        convolution_default_17 = torch.ops.aten.convolution.default(reflection_pad2d_default_5, primals_149, primals_148, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_148 = None
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_154, primals_150, primals_152, primals_153, False, 0.1, 1e-05);  primals_150 = None
        getitem_51 = native_batch_norm_default_17[0]
        getitem_52 = native_batch_norm_default_17[1]
        getitem_53 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        new_zeros_default_51 = torch.ops.aten.new_zeros.default(convolution_default_17, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_52 = torch.ops.aten.new_zeros.default(convolution_default_17, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_53 = torch.ops.aten.new_zeros.default(convolution_default_17, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor = torch.ops.aten.add.Tensor(relu__default_15, getitem_51);  getitem_51 = None
        reflection_pad2d_default_6 = torch.ops.aten.reflection_pad2d.default(add_tensor, [1, 1, 1, 1])
        convolution_default_18 = torch.ops.aten.convolution.default(reflection_pad2d_default_6, primals_156, primals_155, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_155 = None
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_161, primals_157, primals_159, primals_160, False, 0.1, 1e-05);  primals_157 = None
        getitem_54 = native_batch_norm_default_18[0]
        getitem_55 = native_batch_norm_default_18[1]
        getitem_56 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        new_zeros_default_54 = torch.ops.aten.new_zeros.default(convolution_default_18, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_55 = torch.ops.aten.new_zeros.default(convolution_default_18, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_56 = torch.ops.aten.new_zeros.default(convolution_default_18, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_17 = torch.ops.aten.relu_.default(getitem_54);  getitem_54 = None
        reflection_pad2d_default_7 = torch.ops.aten.reflection_pad2d.default(relu__default_17, [1, 1, 1, 1])
        convolution_default_19 = torch.ops.aten.convolution.default(reflection_pad2d_default_7, primals_163, primals_162, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_162 = None
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_168, primals_164, primals_166, primals_167, False, 0.1, 1e-05);  primals_164 = None
        getitem_57 = native_batch_norm_default_19[0]
        getitem_58 = native_batch_norm_default_19[1]
        getitem_59 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        new_zeros_default_57 = torch.ops.aten.new_zeros.default(convolution_default_19, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_58 = torch.ops.aten.new_zeros.default(convolution_default_19, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_59 = torch.ops.aten.new_zeros.default(convolution_default_19, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_1 = torch.ops.aten.add.Tensor(add_tensor, getitem_57);  getitem_57 = None
        reflection_pad2d_default_8 = torch.ops.aten.reflection_pad2d.default(add_tensor_1, [1, 1, 1, 1])
        convolution_default_20 = torch.ops.aten.convolution.default(reflection_pad2d_default_8, primals_170, primals_169, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_169 = None
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_175, primals_171, primals_173, primals_174, False, 0.1, 1e-05);  primals_171 = None
        getitem_60 = native_batch_norm_default_20[0]
        getitem_61 = native_batch_norm_default_20[1]
        getitem_62 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        new_zeros_default_60 = torch.ops.aten.new_zeros.default(convolution_default_20, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_61 = torch.ops.aten.new_zeros.default(convolution_default_20, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_62 = torch.ops.aten.new_zeros.default(convolution_default_20, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_18 = torch.ops.aten.relu_.default(getitem_60);  getitem_60 = None
        reflection_pad2d_default_9 = torch.ops.aten.reflection_pad2d.default(relu__default_18, [1, 1, 1, 1])
        convolution_default_21 = torch.ops.aten.convolution.default(reflection_pad2d_default_9, primals_177, primals_176, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_176 = None
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_182, primals_178, primals_180, primals_181, False, 0.1, 1e-05);  primals_178 = None
        getitem_63 = native_batch_norm_default_21[0]
        getitem_64 = native_batch_norm_default_21[1]
        getitem_65 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        new_zeros_default_63 = torch.ops.aten.new_zeros.default(convolution_default_21, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_64 = torch.ops.aten.new_zeros.default(convolution_default_21, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_65 = torch.ops.aten.new_zeros.default(convolution_default_21, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_2 = torch.ops.aten.add.Tensor(add_tensor_1, getitem_63);  getitem_63 = None
        reflection_pad2d_default_10 = torch.ops.aten.reflection_pad2d.default(add_tensor_2, [1, 1, 1, 1])
        convolution_default_22 = torch.ops.aten.convolution.default(reflection_pad2d_default_10, primals_184, primals_183, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_183 = None
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_189, primals_185, primals_187, primals_188, False, 0.1, 1e-05);  primals_185 = None
        getitem_66 = native_batch_norm_default_22[0]
        getitem_67 = native_batch_norm_default_22[1]
        getitem_68 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        new_zeros_default_66 = torch.ops.aten.new_zeros.default(convolution_default_22, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_67 = torch.ops.aten.new_zeros.default(convolution_default_22, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_68 = torch.ops.aten.new_zeros.default(convolution_default_22, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_19 = torch.ops.aten.relu_.default(getitem_66);  getitem_66 = None
        reflection_pad2d_default_11 = torch.ops.aten.reflection_pad2d.default(relu__default_19, [1, 1, 1, 1])
        convolution_default_23 = torch.ops.aten.convolution.default(reflection_pad2d_default_11, primals_191, primals_190, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_190 = None
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_196, primals_192, primals_194, primals_195, False, 0.1, 1e-05);  primals_192 = None
        getitem_69 = native_batch_norm_default_23[0]
        getitem_70 = native_batch_norm_default_23[1]
        getitem_71 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        new_zeros_default_69 = torch.ops.aten.new_zeros.default(convolution_default_23, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_70 = torch.ops.aten.new_zeros.default(convolution_default_23, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_71 = torch.ops.aten.new_zeros.default(convolution_default_23, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_3 = torch.ops.aten.add.Tensor(add_tensor_2, getitem_69);  getitem_69 = None
        reflection_pad2d_default_12 = torch.ops.aten.reflection_pad2d.default(add_tensor_3, [1, 1, 1, 1])
        convolution_default_24 = torch.ops.aten.convolution.default(reflection_pad2d_default_12, primals_198, primals_197, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_197 = None
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_203, primals_199, primals_201, primals_202, False, 0.1, 1e-05);  primals_199 = None
        getitem_72 = native_batch_norm_default_24[0]
        getitem_73 = native_batch_norm_default_24[1]
        getitem_74 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        new_zeros_default_72 = torch.ops.aten.new_zeros.default(convolution_default_24, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_73 = torch.ops.aten.new_zeros.default(convolution_default_24, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_74 = torch.ops.aten.new_zeros.default(convolution_default_24, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_20 = torch.ops.aten.relu_.default(getitem_72);  getitem_72 = None
        reflection_pad2d_default_13 = torch.ops.aten.reflection_pad2d.default(relu__default_20, [1, 1, 1, 1])
        convolution_default_25 = torch.ops.aten.convolution.default(reflection_pad2d_default_13, primals_205, primals_204, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_204 = None
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_210, primals_206, primals_208, primals_209, False, 0.1, 1e-05);  primals_206 = None
        getitem_75 = native_batch_norm_default_25[0]
        getitem_76 = native_batch_norm_default_25[1]
        getitem_77 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        new_zeros_default_75 = torch.ops.aten.new_zeros.default(convolution_default_25, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_76 = torch.ops.aten.new_zeros.default(convolution_default_25, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_77 = torch.ops.aten.new_zeros.default(convolution_default_25, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_4 = torch.ops.aten.add.Tensor(add_tensor_3, getitem_75);  getitem_75 = None
        reflection_pad2d_default_14 = torch.ops.aten.reflection_pad2d.default(add_tensor_4, [1, 1, 1, 1])
        convolution_default_26 = torch.ops.aten.convolution.default(reflection_pad2d_default_14, primals_212, primals_211, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_211 = None
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_217, primals_213, primals_215, primals_216, False, 0.1, 1e-05);  primals_213 = None
        getitem_78 = native_batch_norm_default_26[0]
        getitem_79 = native_batch_norm_default_26[1]
        getitem_80 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        new_zeros_default_78 = torch.ops.aten.new_zeros.default(convolution_default_26, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_79 = torch.ops.aten.new_zeros.default(convolution_default_26, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_80 = torch.ops.aten.new_zeros.default(convolution_default_26, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_21 = torch.ops.aten.relu_.default(getitem_78);  getitem_78 = None
        reflection_pad2d_default_15 = torch.ops.aten.reflection_pad2d.default(relu__default_21, [1, 1, 1, 1])
        convolution_default_27 = torch.ops.aten.convolution.default(reflection_pad2d_default_15, primals_219, primals_218, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_218 = None
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_224, primals_220, primals_222, primals_223, False, 0.1, 1e-05);  primals_220 = None
        getitem_81 = native_batch_norm_default_27[0]
        getitem_82 = native_batch_norm_default_27[1]
        getitem_83 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        new_zeros_default_81 = torch.ops.aten.new_zeros.default(convolution_default_27, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_82 = torch.ops.aten.new_zeros.default(convolution_default_27, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_83 = torch.ops.aten.new_zeros.default(convolution_default_27, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_5 = torch.ops.aten.add.Tensor(add_tensor_4, getitem_81);  getitem_81 = None
        reflection_pad2d_default_16 = torch.ops.aten.reflection_pad2d.default(add_tensor_5, [1, 1, 1, 1])
        convolution_default_28 = torch.ops.aten.convolution.default(reflection_pad2d_default_16, primals_226, primals_225, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_225 = None
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_231, primals_227, primals_229, primals_230, False, 0.1, 1e-05);  primals_227 = None
        getitem_84 = native_batch_norm_default_28[0]
        getitem_85 = native_batch_norm_default_28[1]
        getitem_86 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        new_zeros_default_84 = torch.ops.aten.new_zeros.default(convolution_default_28, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_85 = torch.ops.aten.new_zeros.default(convolution_default_28, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_86 = torch.ops.aten.new_zeros.default(convolution_default_28, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_22 = torch.ops.aten.relu_.default(getitem_84);  getitem_84 = None
        reflection_pad2d_default_17 = torch.ops.aten.reflection_pad2d.default(relu__default_22, [1, 1, 1, 1])
        convolution_default_29 = torch.ops.aten.convolution.default(reflection_pad2d_default_17, primals_233, primals_232, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_232 = None
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_238, primals_234, primals_236, primals_237, False, 0.1, 1e-05);  primals_234 = None
        getitem_87 = native_batch_norm_default_29[0]
        getitem_88 = native_batch_norm_default_29[1]
        getitem_89 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        new_zeros_default_87 = torch.ops.aten.new_zeros.default(convolution_default_29, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_88 = torch.ops.aten.new_zeros.default(convolution_default_29, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_89 = torch.ops.aten.new_zeros.default(convolution_default_29, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_6 = torch.ops.aten.add.Tensor(add_tensor_5, getitem_87);  getitem_87 = None
        reflection_pad2d_default_18 = torch.ops.aten.reflection_pad2d.default(add_tensor_6, [1, 1, 1, 1])
        convolution_default_30 = torch.ops.aten.convolution.default(reflection_pad2d_default_18, primals_240, primals_239, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_239 = None
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_245, primals_241, primals_243, primals_244, False, 0.1, 1e-05);  primals_241 = None
        getitem_90 = native_batch_norm_default_30[0]
        getitem_91 = native_batch_norm_default_30[1]
        getitem_92 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        new_zeros_default_90 = torch.ops.aten.new_zeros.default(convolution_default_30, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_91 = torch.ops.aten.new_zeros.default(convolution_default_30, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_92 = torch.ops.aten.new_zeros.default(convolution_default_30, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_23 = torch.ops.aten.relu_.default(getitem_90);  getitem_90 = None
        reflection_pad2d_default_19 = torch.ops.aten.reflection_pad2d.default(relu__default_23, [1, 1, 1, 1])
        convolution_default_31 = torch.ops.aten.convolution.default(reflection_pad2d_default_19, primals_247, primals_246, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_246 = None
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_31, primals_252, primals_248, primals_250, primals_251, False, 0.1, 1e-05);  primals_248 = None
        getitem_93 = native_batch_norm_default_31[0]
        getitem_94 = native_batch_norm_default_31[1]
        getitem_95 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        new_zeros_default_93 = torch.ops.aten.new_zeros.default(convolution_default_31, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_94 = torch.ops.aten.new_zeros.default(convolution_default_31, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_95 = torch.ops.aten.new_zeros.default(convolution_default_31, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_7 = torch.ops.aten.add.Tensor(add_tensor_6, getitem_93);  getitem_93 = None
        reflection_pad2d_default_20 = torch.ops.aten.reflection_pad2d.default(add_tensor_7, [1, 1, 1, 1])
        convolution_default_32 = torch.ops.aten.convolution.default(reflection_pad2d_default_20, primals_254, primals_253, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_253 = None
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_259, primals_255, primals_257, primals_258, False, 0.1, 1e-05);  primals_255 = None
        getitem_96 = native_batch_norm_default_32[0]
        getitem_97 = native_batch_norm_default_32[1]
        getitem_98 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        new_zeros_default_96 = torch.ops.aten.new_zeros.default(convolution_default_32, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_97 = torch.ops.aten.new_zeros.default(convolution_default_32, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_98 = torch.ops.aten.new_zeros.default(convolution_default_32, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_24 = torch.ops.aten.relu_.default(getitem_96);  getitem_96 = None
        reflection_pad2d_default_21 = torch.ops.aten.reflection_pad2d.default(relu__default_24, [1, 1, 1, 1])
        convolution_default_33 = torch.ops.aten.convolution.default(reflection_pad2d_default_21, primals_261, primals_260, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_260 = None
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_266, primals_262, primals_264, primals_265, False, 0.1, 1e-05);  primals_262 = None
        getitem_99 = native_batch_norm_default_33[0]
        getitem_100 = native_batch_norm_default_33[1]
        getitem_101 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        new_zeros_default_99 = torch.ops.aten.new_zeros.default(convolution_default_33, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_100 = torch.ops.aten.new_zeros.default(convolution_default_33, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_101 = torch.ops.aten.new_zeros.default(convolution_default_33, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_8 = torch.ops.aten.add.Tensor(add_tensor_7, getitem_99);  getitem_99 = None
        reflection_pad2d_default_22 = torch.ops.aten.reflection_pad2d.default(add_tensor_8, [1, 1, 1, 1])
        convolution_default_34 = torch.ops.aten.convolution.default(reflection_pad2d_default_22, primals_268, primals_267, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_267 = None
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_273, primals_269, primals_271, primals_272, False, 0.1, 1e-05);  primals_269 = None
        getitem_102 = native_batch_norm_default_34[0]
        getitem_103 = native_batch_norm_default_34[1]
        getitem_104 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        new_zeros_default_102 = torch.ops.aten.new_zeros.default(convolution_default_34, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_103 = torch.ops.aten.new_zeros.default(convolution_default_34, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_104 = torch.ops.aten.new_zeros.default(convolution_default_34, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_25 = torch.ops.aten.relu_.default(getitem_102);  getitem_102 = None
        reflection_pad2d_default_23 = torch.ops.aten.reflection_pad2d.default(relu__default_25, [1, 1, 1, 1])
        convolution_default_35 = torch.ops.aten.convolution.default(reflection_pad2d_default_23, primals_275, primals_274, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_274 = None
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_280, primals_276, primals_278, primals_279, False, 0.1, 1e-05);  primals_276 = None
        getitem_105 = native_batch_norm_default_35[0]
        getitem_106 = native_batch_norm_default_35[1]
        getitem_107 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        new_zeros_default_105 = torch.ops.aten.new_zeros.default(convolution_default_35, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_106 = torch.ops.aten.new_zeros.default(convolution_default_35, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_107 = torch.ops.aten.new_zeros.default(convolution_default_35, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_9 = torch.ops.aten.add.Tensor(add_tensor_8, getitem_105);  getitem_105 = None
        upsample_bilinear2d_vec = torch.ops.aten.upsample_bilinear2d.vec(add_tensor_9, None, True, [2.0, 2.0]);  add_tensor_9 = None
        convolution_default_36 = torch.ops.aten.convolution.default(upsample_bilinear2d_vec, primals_20, primals_19, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_19 = None
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_25, primals_21, primals_23, primals_24, False, 0.1, 1e-05);  primals_21 = None
        getitem_108 = native_batch_norm_default_36[0]
        getitem_109 = native_batch_norm_default_36[1]
        getitem_110 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        new_zeros_default_108 = torch.ops.aten.new_zeros.default(convolution_default_36, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_109 = torch.ops.aten.new_zeros.default(convolution_default_36, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_110 = torch.ops.aten.new_zeros.default(convolution_default_36, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_26 = torch.ops.aten.relu_.default(getitem_108);  getitem_108 = None
        upsample_bilinear2d_vec_1 = torch.ops.aten.upsample_bilinear2d.vec(relu__default_26, None, True, [2.0, 2.0])
        convolution_default_37 = torch.ops.aten.convolution.default(upsample_bilinear2d_vec_1, primals_27, primals_26, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_26 = None
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_37, primals_32, primals_28, primals_30, primals_31, False, 0.1, 1e-05);  primals_28 = None
        getitem_111 = native_batch_norm_default_37[0]
        getitem_112 = native_batch_norm_default_37[1]
        getitem_113 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        new_zeros_default_111 = torch.ops.aten.new_zeros.default(convolution_default_37, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_112 = torch.ops.aten.new_zeros.default(convolution_default_37, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_113 = torch.ops.aten.new_zeros.default(convolution_default_37, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_27 = torch.ops.aten.relu_.default(getitem_111);  getitem_111 = None
        reflection_pad2d_default_24 = torch.ops.aten.reflection_pad2d.default(relu__default_27, [3, 3, 3, 3])
        convolution_default_38 = torch.ops.aten.convolution.default(reflection_pad2d_default_24, primals_34, primals_33, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_33 = None
        tanh_default = torch.ops.aten.tanh.default(convolution_default_38);  convolution_default_38 = None
        reflection_pad2d_default_25 = torch.ops.aten.reflection_pad2d.default(add_tensor_6, [1, 1, 1, 1])
        convolution_default_39 = torch.ops.aten.convolution.default(reflection_pad2d_default_25, primals_282, primals_281, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_281 = None
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_39, primals_287, primals_283, primals_285, primals_286, False, 0.1, 1e-05);  primals_283 = None
        getitem_114 = native_batch_norm_default_38[0]
        getitem_115 = native_batch_norm_default_38[1]
        getitem_116 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        new_zeros_default_114 = torch.ops.aten.new_zeros.default(convolution_default_39, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_115 = torch.ops.aten.new_zeros.default(convolution_default_39, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_116 = torch.ops.aten.new_zeros.default(convolution_default_39, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_28 = torch.ops.aten.relu_.default(getitem_114);  getitem_114 = None
        reflection_pad2d_default_26 = torch.ops.aten.reflection_pad2d.default(relu__default_28, [1, 1, 1, 1])
        convolution_default_40 = torch.ops.aten.convolution.default(reflection_pad2d_default_26, primals_289, primals_288, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_288 = None
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_294, primals_290, primals_292, primals_293, False, 0.1, 1e-05);  primals_290 = None
        getitem_117 = native_batch_norm_default_39[0]
        getitem_118 = native_batch_norm_default_39[1]
        getitem_119 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        new_zeros_default_117 = torch.ops.aten.new_zeros.default(convolution_default_40, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_118 = torch.ops.aten.new_zeros.default(convolution_default_40, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_119 = torch.ops.aten.new_zeros.default(convolution_default_40, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_10 = torch.ops.aten.add.Tensor(add_tensor_6, getitem_117);  getitem_117 = None
        reflection_pad2d_default_27 = torch.ops.aten.reflection_pad2d.default(add_tensor_10, [1, 1, 1, 1])
        convolution_default_41 = torch.ops.aten.convolution.default(reflection_pad2d_default_27, primals_296, primals_295, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_295 = None
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_41, primals_301, primals_297, primals_299, primals_300, False, 0.1, 1e-05);  primals_297 = None
        getitem_120 = native_batch_norm_default_40[0]
        getitem_121 = native_batch_norm_default_40[1]
        getitem_122 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        new_zeros_default_120 = torch.ops.aten.new_zeros.default(convolution_default_41, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_121 = torch.ops.aten.new_zeros.default(convolution_default_41, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_122 = torch.ops.aten.new_zeros.default(convolution_default_41, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_29 = torch.ops.aten.relu_.default(getitem_120);  getitem_120 = None
        reflection_pad2d_default_28 = torch.ops.aten.reflection_pad2d.default(relu__default_29, [1, 1, 1, 1])
        convolution_default_42 = torch.ops.aten.convolution.default(reflection_pad2d_default_28, primals_303, primals_302, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_302 = None
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_42, primals_308, primals_304, primals_306, primals_307, False, 0.1, 1e-05);  primals_304 = None
        getitem_123 = native_batch_norm_default_41[0]
        getitem_124 = native_batch_norm_default_41[1]
        getitem_125 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        new_zeros_default_123 = torch.ops.aten.new_zeros.default(convolution_default_42, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_124 = torch.ops.aten.new_zeros.default(convolution_default_42, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_125 = torch.ops.aten.new_zeros.default(convolution_default_42, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_11 = torch.ops.aten.add.Tensor(add_tensor_10, getitem_123);  getitem_123 = None
        reflection_pad2d_default_29 = torch.ops.aten.reflection_pad2d.default(add_tensor_11, [1, 1, 1, 1])
        convolution_default_43 = torch.ops.aten.convolution.default(reflection_pad2d_default_29, primals_310, primals_309, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_309 = None
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_43, primals_315, primals_311, primals_313, primals_314, False, 0.1, 1e-05);  primals_311 = None
        getitem_126 = native_batch_norm_default_42[0]
        getitem_127 = native_batch_norm_default_42[1]
        getitem_128 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        new_zeros_default_126 = torch.ops.aten.new_zeros.default(convolution_default_43, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_127 = torch.ops.aten.new_zeros.default(convolution_default_43, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_128 = torch.ops.aten.new_zeros.default(convolution_default_43, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_30 = torch.ops.aten.relu_.default(getitem_126);  getitem_126 = None
        reflection_pad2d_default_30 = torch.ops.aten.reflection_pad2d.default(relu__default_30, [1, 1, 1, 1])
        convolution_default_44 = torch.ops.aten.convolution.default(reflection_pad2d_default_30, primals_317, primals_316, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_316 = None
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_322, primals_318, primals_320, primals_321, False, 0.1, 1e-05);  primals_318 = None
        getitem_129 = native_batch_norm_default_43[0]
        getitem_130 = native_batch_norm_default_43[1]
        getitem_131 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        new_zeros_default_129 = torch.ops.aten.new_zeros.default(convolution_default_44, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_130 = torch.ops.aten.new_zeros.default(convolution_default_44, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_131 = torch.ops.aten.new_zeros.default(convolution_default_44, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_12 = torch.ops.aten.add.Tensor(add_tensor_11, getitem_129);  getitem_129 = None
        upsample_bilinear2d_vec_2 = torch.ops.aten.upsample_bilinear2d.vec(add_tensor_12, None, True, [2.0, 2.0]);  add_tensor_12 = None
        convolution_default_45 = torch.ops.aten.convolution.default(upsample_bilinear2d_vec_2, primals_36, primals_35, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_35 = None
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_45, primals_41, primals_37, primals_39, primals_40, False, 0.1, 1e-05);  primals_37 = None
        getitem_132 = native_batch_norm_default_44[0]
        getitem_133 = native_batch_norm_default_44[1]
        getitem_134 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        new_zeros_default_132 = torch.ops.aten.new_zeros.default(convolution_default_45, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_133 = torch.ops.aten.new_zeros.default(convolution_default_45, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_134 = torch.ops.aten.new_zeros.default(convolution_default_45, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_31 = torch.ops.aten.relu_.default(getitem_132);  getitem_132 = None
        cat_default_5 = torch.ops.aten.cat.default([relu__default_31, relu__default_1], 1)
        upsample_bilinear2d_vec_3 = torch.ops.aten.upsample_bilinear2d.vec(cat_default_5, None, True, [2.0, 2.0]);  cat_default_5 = None
        convolution_default_46 = torch.ops.aten.convolution.default(upsample_bilinear2d_vec_3, primals_127, primals_126, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_126 = None
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_46, primals_132, primals_128, primals_130, primals_131, False, 0.1, 1e-05);  primals_128 = None
        getitem_135 = native_batch_norm_default_45[0]
        getitem_136 = native_batch_norm_default_45[1]
        getitem_137 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        new_zeros_default_135 = torch.ops.aten.new_zeros.default(convolution_default_46, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_136 = torch.ops.aten.new_zeros.default(convolution_default_46, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_137 = torch.ops.aten.new_zeros.default(convolution_default_46, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_32 = torch.ops.aten.relu_.default(getitem_135);  getitem_135 = None
        reflection_pad2d_default_31 = torch.ops.aten.reflection_pad2d.default(relu__default_32, [3, 3, 3, 3])
        convolution_default_47 = torch.ops.aten.convolution.default(reflection_pad2d_default_31, primals_134, primals_133, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_133 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(tanh_default, tangents_1)
        is_same_size_default_1 = torch.ops.aten.is_same_size.default(convolution_default_47, tangents_2)
        convolution_backward_default = torch.ops.aten.convolution_backward.default(tangents_2, reflection_pad2d_default_31, primals_134, [3], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  tangents_2 = reflection_pad2d_default_31 = primals_134 = None
        getitem_138 = convolution_backward_default[0]
        getitem_139 = convolution_backward_default[1]
        getitem_140 = convolution_backward_default[2];  convolution_backward_default = None
        reflection_pad2d_backward_default = torch.ops.aten.reflection_pad2d_backward.default(getitem_138, relu__default_32, [3, 3, 3, 3]);  getitem_138 = None
        to_dtype = torch.ops.aten.to.dtype(reflection_pad2d_backward_default, torch.float32);  reflection_pad2d_backward_default = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default_32, torch.float32);  relu__default_32 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default_138 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_138, to_dtype);  le_scalar = new_zeros_default_138 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_2, convolution_default_46, primals_132, primals_130, primals_131, new_zeros_default_135, new_zeros_default_136, False, 1e-05, [True, True, True]);  to_dtype_2 = convolution_default_46 = primals_132 = primals_130 = primals_131 = new_zeros_default_135 = new_zeros_default_136 = None
        getitem_141 = native_batch_norm_backward_default[0]
        getitem_142 = native_batch_norm_backward_default[1]
        getitem_143 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_141, upsample_bilinear2d_vec_3, primals_127, [64], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_141 = upsample_bilinear2d_vec_3 = primals_127 = None
        getitem_144 = convolution_backward_default_1[0]
        getitem_145 = convolution_backward_default_1[1]
        getitem_146 = convolution_backward_default_1[2];  convolution_backward_default_1 = None
        upsample_bilinear2d_backward_vec = torch.ops.aten.upsample_bilinear2d_backward.vec(getitem_144, None, [3, 256, 256, 256], True, [2.0, 2.0]);  getitem_144 = None
        slice_tensor = torch.ops.aten.slice.Tensor(upsample_bilinear2d_backward_vec, 1, 0, 128)
        slice_tensor_1 = torch.ops.aten.slice.Tensor(upsample_bilinear2d_backward_vec, 1, 128, 256);  upsample_bilinear2d_backward_vec = None
        to_dtype_3 = torch.ops.aten.to.dtype(slice_tensor, torch.float32);  slice_tensor = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu__default_31, torch.float32);  relu__default_31 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_139 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_139, to_dtype_3);  le_scalar_1 = new_zeros_default_139 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_5, convolution_default_45, primals_41, primals_39, primals_40, new_zeros_default_132, new_zeros_default_133, False, 1e-05, [True, True, True]);  to_dtype_5 = convolution_default_45 = primals_41 = primals_39 = primals_40 = new_zeros_default_132 = new_zeros_default_133 = None
        getitem_147 = native_batch_norm_backward_default_1[0]
        getitem_148 = native_batch_norm_backward_default_1[1]
        getitem_149 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_147, upsample_bilinear2d_vec_2, primals_36, [128], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_147 = upsample_bilinear2d_vec_2 = primals_36 = None
        getitem_150 = convolution_backward_default_2[0]
        getitem_151 = convolution_backward_default_2[1]
        getitem_152 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        upsample_bilinear2d_backward_vec_1 = torch.ops.aten.upsample_bilinear2d_backward.vec(getitem_150, None, [3, 256, 128, 128], True, [2.0, 2.0]);  getitem_150 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(upsample_bilinear2d_backward_vec_1, convolution_default_44, primals_322, primals_320, primals_321, new_zeros_default_129, new_zeros_default_130, False, 1e-05, [True, True, True]);  convolution_default_44 = primals_322 = primals_320 = primals_321 = new_zeros_default_129 = new_zeros_default_130 = None
        getitem_153 = native_batch_norm_backward_default_2[0]
        getitem_154 = native_batch_norm_backward_default_2[1]
        getitem_155 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_153, reflection_pad2d_default_30, primals_317, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_153 = reflection_pad2d_default_30 = primals_317 = None
        getitem_156 = convolution_backward_default_3[0]
        getitem_157 = convolution_backward_default_3[1]
        getitem_158 = convolution_backward_default_3[2];  convolution_backward_default_3 = None
        reflection_pad2d_backward_default_1 = torch.ops.aten.reflection_pad2d_backward.default(getitem_156, relu__default_30, [1, 1, 1, 1]);  getitem_156 = None
        to_dtype_6 = torch.ops.aten.to.dtype(reflection_pad2d_backward_default_1, torch.float32);  reflection_pad2d_backward_default_1 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_30, torch.float32);  relu__default_30 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_140 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_140, to_dtype_6);  le_scalar_2 = new_zeros_default_140 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_8, convolution_default_43, primals_315, primals_313, primals_314, new_zeros_default_126, new_zeros_default_127, False, 1e-05, [True, True, True]);  to_dtype_8 = convolution_default_43 = primals_315 = primals_313 = primals_314 = new_zeros_default_126 = new_zeros_default_127 = None
        getitem_159 = native_batch_norm_backward_default_3[0]
        getitem_160 = native_batch_norm_backward_default_3[1]
        getitem_161 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_159, reflection_pad2d_default_29, primals_310, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_159 = reflection_pad2d_default_29 = primals_310 = None
        getitem_162 = convolution_backward_default_4[0]
        getitem_163 = convolution_backward_default_4[1]
        getitem_164 = convolution_backward_default_4[2];  convolution_backward_default_4 = None
        reflection_pad2d_backward_default_2 = torch.ops.aten.reflection_pad2d_backward.default(getitem_162, add_tensor_11, [1, 1, 1, 1]);  getitem_162 = add_tensor_11 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(upsample_bilinear2d_backward_vec_1, reflection_pad2d_backward_default_2);  upsample_bilinear2d_backward_vec_1 = reflection_pad2d_backward_default_2 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_13, convolution_default_42, primals_308, primals_306, primals_307, new_zeros_default_123, new_zeros_default_124, False, 1e-05, [True, True, True]);  convolution_default_42 = primals_308 = primals_306 = primals_307 = new_zeros_default_123 = new_zeros_default_124 = None
        getitem_165 = native_batch_norm_backward_default_4[0]
        getitem_166 = native_batch_norm_backward_default_4[1]
        getitem_167 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_165, reflection_pad2d_default_28, primals_303, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_165 = reflection_pad2d_default_28 = primals_303 = None
        getitem_168 = convolution_backward_default_5[0]
        getitem_169 = convolution_backward_default_5[1]
        getitem_170 = convolution_backward_default_5[2];  convolution_backward_default_5 = None
        reflection_pad2d_backward_default_3 = torch.ops.aten.reflection_pad2d_backward.default(getitem_168, relu__default_29, [1, 1, 1, 1]);  getitem_168 = None
        to_dtype_9 = torch.ops.aten.to.dtype(reflection_pad2d_backward_default_3, torch.float32);  reflection_pad2d_backward_default_3 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu__default_29, torch.float32);  relu__default_29 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_141 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_141, to_dtype_9);  le_scalar_3 = new_zeros_default_141 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_41, primals_301, primals_299, primals_300, new_zeros_default_120, new_zeros_default_121, False, 1e-05, [True, True, True]);  to_dtype_11 = convolution_default_41 = primals_301 = primals_299 = primals_300 = new_zeros_default_120 = new_zeros_default_121 = None
        getitem_171 = native_batch_norm_backward_default_5[0]
        getitem_172 = native_batch_norm_backward_default_5[1]
        getitem_173 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(getitem_171, reflection_pad2d_default_27, primals_296, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_171 = reflection_pad2d_default_27 = primals_296 = None
        getitem_174 = convolution_backward_default_6[0]
        getitem_175 = convolution_backward_default_6[1]
        getitem_176 = convolution_backward_default_6[2];  convolution_backward_default_6 = None
        reflection_pad2d_backward_default_4 = torch.ops.aten.reflection_pad2d_backward.default(getitem_174, add_tensor_10, [1, 1, 1, 1]);  getitem_174 = add_tensor_10 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(add_tensor_13, reflection_pad2d_backward_default_4);  add_tensor_13 = reflection_pad2d_backward_default_4 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_14, convolution_default_40, primals_294, primals_292, primals_293, new_zeros_default_117, new_zeros_default_118, False, 1e-05, [True, True, True]);  convolution_default_40 = primals_294 = primals_292 = primals_293 = new_zeros_default_117 = new_zeros_default_118 = None
        getitem_177 = native_batch_norm_backward_default_6[0]
        getitem_178 = native_batch_norm_backward_default_6[1]
        getitem_179 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(getitem_177, reflection_pad2d_default_26, primals_289, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_177 = reflection_pad2d_default_26 = primals_289 = None
        getitem_180 = convolution_backward_default_7[0]
        getitem_181 = convolution_backward_default_7[1]
        getitem_182 = convolution_backward_default_7[2];  convolution_backward_default_7 = None
        reflection_pad2d_backward_default_5 = torch.ops.aten.reflection_pad2d_backward.default(getitem_180, relu__default_28, [1, 1, 1, 1]);  getitem_180 = None
        to_dtype_12 = torch.ops.aten.to.dtype(reflection_pad2d_backward_default_5, torch.float32);  reflection_pad2d_backward_default_5 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_28, torch.float32);  relu__default_28 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_142 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_142, to_dtype_12);  le_scalar_4 = new_zeros_default_142 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_39, primals_287, primals_285, primals_286, new_zeros_default_114, new_zeros_default_115, False, 1e-05, [True, True, True]);  to_dtype_14 = convolution_default_39 = primals_287 = primals_285 = primals_286 = new_zeros_default_114 = new_zeros_default_115 = None
        getitem_183 = native_batch_norm_backward_default_7[0]
        getitem_184 = native_batch_norm_backward_default_7[1]
        getitem_185 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(getitem_183, reflection_pad2d_default_25, primals_282, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_183 = reflection_pad2d_default_25 = primals_282 = None
        getitem_186 = convolution_backward_default_8[0]
        getitem_187 = convolution_backward_default_8[1]
        getitem_188 = convolution_backward_default_8[2];  convolution_backward_default_8 = None
        reflection_pad2d_backward_default_6 = torch.ops.aten.reflection_pad2d_backward.default(getitem_186, add_tensor_6, [1, 1, 1, 1]);  getitem_186 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(add_tensor_14, reflection_pad2d_backward_default_6);  add_tensor_14 = reflection_pad2d_backward_default_6 = None
        to_dtype_15 = torch.ops.aten.to.dtype(tangents_1, torch.float32);  tangents_1 = None
        to_dtype_16 = torch.ops.aten.to.dtype(tanh_default, torch.float32)
        mul_tensor = torch.ops.aten.mul.Tensor(to_dtype_16, to_dtype_16);  to_dtype_16 = None
        rsub_scalar = torch.ops.aten.rsub.Scalar(mul_tensor, 1);  mul_tensor = None
        conj_physical_default = torch.ops.aten.conj_physical.default(rsub_scalar);  rsub_scalar = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(to_dtype_15, conj_physical_default);  to_dtype_15 = conj_physical_default = None
        to_dtype_17 = torch.ops.aten.to.dtype(mul_tensor_1, torch.float32);  mul_tensor_1 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(to_dtype_17, reflection_pad2d_default_24, primals_34, [1], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_17 = reflection_pad2d_default_24 = primals_34 = None
        getitem_189 = convolution_backward_default_9[0]
        getitem_190 = convolution_backward_default_9[1]
        getitem_191 = convolution_backward_default_9[2];  convolution_backward_default_9 = None
        reflection_pad2d_backward_default_7 = torch.ops.aten.reflection_pad2d_backward.default(getitem_189, relu__default_27, [3, 3, 3, 3]);  getitem_189 = None
        to_dtype_18 = torch.ops.aten.to.dtype(reflection_pad2d_backward_default_7, torch.float32);  reflection_pad2d_backward_default_7 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu__default_27, torch.float32);  relu__default_27 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_143 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_143, to_dtype_18);  le_scalar_5 = new_zeros_default_143 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_20, convolution_default_37, primals_32, primals_30, primals_31, new_zeros_default_111, new_zeros_default_112, False, 1e-05, [True, True, True]);  to_dtype_20 = convolution_default_37 = primals_32 = primals_30 = primals_31 = new_zeros_default_111 = new_zeros_default_112 = None
        getitem_192 = native_batch_norm_backward_default_8[0]
        getitem_193 = native_batch_norm_backward_default_8[1]
        getitem_194 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_192, upsample_bilinear2d_vec_1, primals_27, [64], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_192 = upsample_bilinear2d_vec_1 = primals_27 = None
        getitem_195 = convolution_backward_default_10[0]
        getitem_196 = convolution_backward_default_10[1]
        getitem_197 = convolution_backward_default_10[2];  convolution_backward_default_10 = None
        upsample_bilinear2d_backward_vec_2 = torch.ops.aten.upsample_bilinear2d_backward.vec(getitem_195, None, [3, 128, 256, 256], True, [2.0, 2.0]);  getitem_195 = None
        to_dtype_21 = torch.ops.aten.to.dtype(upsample_bilinear2d_backward_vec_2, torch.float32);  upsample_bilinear2d_backward_vec_2 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_26, torch.float32);  relu__default_26 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_144 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_144, to_dtype_21);  le_scalar_6 = new_zeros_default_144 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_23, convolution_default_36, primals_25, primals_23, primals_24, new_zeros_default_108, new_zeros_default_109, False, 1e-05, [True, True, True]);  to_dtype_23 = convolution_default_36 = primals_25 = primals_23 = primals_24 = new_zeros_default_108 = new_zeros_default_109 = None
        getitem_198 = native_batch_norm_backward_default_9[0]
        getitem_199 = native_batch_norm_backward_default_9[1]
        getitem_200 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_198, upsample_bilinear2d_vec, primals_20, [128], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_198 = upsample_bilinear2d_vec = primals_20 = None
        getitem_201 = convolution_backward_default_11[0]
        getitem_202 = convolution_backward_default_11[1]
        getitem_203 = convolution_backward_default_11[2];  convolution_backward_default_11 = None
        upsample_bilinear2d_backward_vec_3 = torch.ops.aten.upsample_bilinear2d_backward.vec(getitem_201, None, [3, 256, 128, 128], True, [2.0, 2.0]);  getitem_201 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(upsample_bilinear2d_backward_vec_3, convolution_default_35, primals_280, primals_278, primals_279, new_zeros_default_105, new_zeros_default_106, False, 1e-05, [True, True, True]);  convolution_default_35 = primals_280 = primals_278 = primals_279 = new_zeros_default_105 = new_zeros_default_106 = None
        getitem_204 = native_batch_norm_backward_default_10[0]
        getitem_205 = native_batch_norm_backward_default_10[1]
        getitem_206 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(getitem_204, reflection_pad2d_default_23, primals_275, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_204 = reflection_pad2d_default_23 = primals_275 = None
        getitem_207 = convolution_backward_default_12[0]
        getitem_208 = convolution_backward_default_12[1]
        getitem_209 = convolution_backward_default_12[2];  convolution_backward_default_12 = None
        reflection_pad2d_backward_default_8 = torch.ops.aten.reflection_pad2d_backward.default(getitem_207, relu__default_25, [1, 1, 1, 1]);  getitem_207 = None
        to_dtype_24 = torch.ops.aten.to.dtype(reflection_pad2d_backward_default_8, torch.float32);  reflection_pad2d_backward_default_8 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_25, torch.float32);  relu__default_25 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_145 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_145, to_dtype_24);  le_scalar_7 = new_zeros_default_145 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_34, primals_273, primals_271, primals_272, new_zeros_default_102, new_zeros_default_103, False, 1e-05, [True, True, True]);  to_dtype_26 = convolution_default_34 = primals_273 = primals_271 = primals_272 = new_zeros_default_102 = new_zeros_default_103 = None
        getitem_210 = native_batch_norm_backward_default_11[0]
        getitem_211 = native_batch_norm_backward_default_11[1]
        getitem_212 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_210, reflection_pad2d_default_22, primals_268, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_210 = reflection_pad2d_default_22 = primals_268 = None
        getitem_213 = convolution_backward_default_13[0]
        getitem_214 = convolution_backward_default_13[1]
        getitem_215 = convolution_backward_default_13[2];  convolution_backward_default_13 = None
        reflection_pad2d_backward_default_9 = torch.ops.aten.reflection_pad2d_backward.default(getitem_213, add_tensor_8, [1, 1, 1, 1]);  getitem_213 = add_tensor_8 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(upsample_bilinear2d_backward_vec_3, reflection_pad2d_backward_default_9);  upsample_bilinear2d_backward_vec_3 = reflection_pad2d_backward_default_9 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_16, convolution_default_33, primals_266, primals_264, primals_265, new_zeros_default_99, new_zeros_default_100, False, 1e-05, [True, True, True]);  convolution_default_33 = primals_266 = primals_264 = primals_265 = new_zeros_default_99 = new_zeros_default_100 = None
        getitem_216 = native_batch_norm_backward_default_12[0]
        getitem_217 = native_batch_norm_backward_default_12[1]
        getitem_218 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_216, reflection_pad2d_default_21, primals_261, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_216 = reflection_pad2d_default_21 = primals_261 = None
        getitem_219 = convolution_backward_default_14[0]
        getitem_220 = convolution_backward_default_14[1]
        getitem_221 = convolution_backward_default_14[2];  convolution_backward_default_14 = None
        reflection_pad2d_backward_default_10 = torch.ops.aten.reflection_pad2d_backward.default(getitem_219, relu__default_24, [1, 1, 1, 1]);  getitem_219 = None
        to_dtype_27 = torch.ops.aten.to.dtype(reflection_pad2d_backward_default_10, torch.float32);  reflection_pad2d_backward_default_10 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu__default_24, torch.float32);  relu__default_24 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_146 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_146, to_dtype_27);  le_scalar_8 = new_zeros_default_146 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_29, convolution_default_32, primals_259, primals_257, primals_258, new_zeros_default_96, new_zeros_default_97, False, 1e-05, [True, True, True]);  to_dtype_29 = convolution_default_32 = primals_259 = primals_257 = primals_258 = new_zeros_default_96 = new_zeros_default_97 = None
        getitem_222 = native_batch_norm_backward_default_13[0]
        getitem_223 = native_batch_norm_backward_default_13[1]
        getitem_224 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_222, reflection_pad2d_default_20, primals_254, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_222 = reflection_pad2d_default_20 = primals_254 = None
        getitem_225 = convolution_backward_default_15[0]
        getitem_226 = convolution_backward_default_15[1]
        getitem_227 = convolution_backward_default_15[2];  convolution_backward_default_15 = None
        reflection_pad2d_backward_default_11 = torch.ops.aten.reflection_pad2d_backward.default(getitem_225, add_tensor_7, [1, 1, 1, 1]);  getitem_225 = add_tensor_7 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(add_tensor_16, reflection_pad2d_backward_default_11);  add_tensor_16 = reflection_pad2d_backward_default_11 = None
        add_tensor_18 = torch.ops.aten.add.Tensor(add_tensor_15, add_tensor_17);  add_tensor_15 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_17, convolution_default_31, primals_252, primals_250, primals_251, new_zeros_default_93, new_zeros_default_94, False, 1e-05, [True, True, True]);  add_tensor_17 = convolution_default_31 = primals_252 = primals_250 = primals_251 = new_zeros_default_93 = new_zeros_default_94 = None
        getitem_228 = native_batch_norm_backward_default_14[0]
        getitem_229 = native_batch_norm_backward_default_14[1]
        getitem_230 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(getitem_228, reflection_pad2d_default_19, primals_247, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_228 = reflection_pad2d_default_19 = primals_247 = None
        getitem_231 = convolution_backward_default_16[0]
        getitem_232 = convolution_backward_default_16[1]
        getitem_233 = convolution_backward_default_16[2];  convolution_backward_default_16 = None
        reflection_pad2d_backward_default_12 = torch.ops.aten.reflection_pad2d_backward.default(getitem_231, relu__default_23, [1, 1, 1, 1]);  getitem_231 = None
        to_dtype_30 = torch.ops.aten.to.dtype(reflection_pad2d_backward_default_12, torch.float32);  reflection_pad2d_backward_default_12 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu__default_23, torch.float32);  relu__default_23 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_147 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_147, to_dtype_30);  le_scalar_9 = new_zeros_default_147 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default_30, primals_245, primals_243, primals_244, new_zeros_default_90, new_zeros_default_91, False, 1e-05, [True, True, True]);  to_dtype_32 = convolution_default_30 = primals_245 = primals_243 = primals_244 = new_zeros_default_90 = new_zeros_default_91 = None
        getitem_234 = native_batch_norm_backward_default_15[0]
        getitem_235 = native_batch_norm_backward_default_15[1]
        getitem_236 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(getitem_234, reflection_pad2d_default_18, primals_240, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_234 = reflection_pad2d_default_18 = primals_240 = None
        getitem_237 = convolution_backward_default_17[0]
        getitem_238 = convolution_backward_default_17[1]
        getitem_239 = convolution_backward_default_17[2];  convolution_backward_default_17 = None
        reflection_pad2d_backward_default_13 = torch.ops.aten.reflection_pad2d_backward.default(getitem_237, add_tensor_6, [1, 1, 1, 1]);  getitem_237 = add_tensor_6 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(add_tensor_18, reflection_pad2d_backward_default_13);  add_tensor_18 = reflection_pad2d_backward_default_13 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_19, convolution_default_29, primals_238, primals_236, primals_237, new_zeros_default_87, new_zeros_default_88, False, 1e-05, [True, True, True]);  convolution_default_29 = primals_238 = primals_236 = primals_237 = new_zeros_default_87 = new_zeros_default_88 = None
        getitem_240 = native_batch_norm_backward_default_16[0]
        getitem_241 = native_batch_norm_backward_default_16[1]
        getitem_242 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(getitem_240, reflection_pad2d_default_17, primals_233, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_240 = reflection_pad2d_default_17 = primals_233 = None
        getitem_243 = convolution_backward_default_18[0]
        getitem_244 = convolution_backward_default_18[1]
        getitem_245 = convolution_backward_default_18[2];  convolution_backward_default_18 = None
        reflection_pad2d_backward_default_14 = torch.ops.aten.reflection_pad2d_backward.default(getitem_243, relu__default_22, [1, 1, 1, 1]);  getitem_243 = None
        to_dtype_33 = torch.ops.aten.to.dtype(reflection_pad2d_backward_default_14, torch.float32);  reflection_pad2d_backward_default_14 = None
        to_dtype_34 = torch.ops.aten.to.dtype(relu__default_22, torch.float32);  relu__default_22 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        new_zeros_default_148 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_148, to_dtype_33);  le_scalar_10 = new_zeros_default_148 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_35, convolution_default_28, primals_231, primals_229, primals_230, new_zeros_default_84, new_zeros_default_85, False, 1e-05, [True, True, True]);  to_dtype_35 = convolution_default_28 = primals_231 = primals_229 = primals_230 = new_zeros_default_84 = new_zeros_default_85 = None
        getitem_246 = native_batch_norm_backward_default_17[0]
        getitem_247 = native_batch_norm_backward_default_17[1]
        getitem_248 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_246, reflection_pad2d_default_16, primals_226, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_246 = reflection_pad2d_default_16 = primals_226 = None
        getitem_249 = convolution_backward_default_19[0]
        getitem_250 = convolution_backward_default_19[1]
        getitem_251 = convolution_backward_default_19[2];  convolution_backward_default_19 = None
        reflection_pad2d_backward_default_15 = torch.ops.aten.reflection_pad2d_backward.default(getitem_249, add_tensor_5, [1, 1, 1, 1]);  getitem_249 = add_tensor_5 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(add_tensor_19, reflection_pad2d_backward_default_15);  add_tensor_19 = reflection_pad2d_backward_default_15 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_20, convolution_default_27, primals_224, primals_222, primals_223, new_zeros_default_81, new_zeros_default_82, False, 1e-05, [True, True, True]);  convolution_default_27 = primals_224 = primals_222 = primals_223 = new_zeros_default_81 = new_zeros_default_82 = None
        getitem_252 = native_batch_norm_backward_default_18[0]
        getitem_253 = native_batch_norm_backward_default_18[1]
        getitem_254 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(getitem_252, reflection_pad2d_default_15, primals_219, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_252 = reflection_pad2d_default_15 = primals_219 = None
        getitem_255 = convolution_backward_default_20[0]
        getitem_256 = convolution_backward_default_20[1]
        getitem_257 = convolution_backward_default_20[2];  convolution_backward_default_20 = None
        reflection_pad2d_backward_default_16 = torch.ops.aten.reflection_pad2d_backward.default(getitem_255, relu__default_21, [1, 1, 1, 1]);  getitem_255 = None
        to_dtype_36 = torch.ops.aten.to.dtype(reflection_pad2d_backward_default_16, torch.float32);  reflection_pad2d_backward_default_16 = None
        to_dtype_37 = torch.ops.aten.to.dtype(relu__default_21, torch.float32);  relu__default_21 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        new_zeros_default_149 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_149, to_dtype_36);  le_scalar_11 = new_zeros_default_149 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_38, convolution_default_26, primals_217, primals_215, primals_216, new_zeros_default_78, new_zeros_default_79, False, 1e-05, [True, True, True]);  to_dtype_38 = convolution_default_26 = primals_217 = primals_215 = primals_216 = new_zeros_default_78 = new_zeros_default_79 = None
        getitem_258 = native_batch_norm_backward_default_19[0]
        getitem_259 = native_batch_norm_backward_default_19[1]
        getitem_260 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(getitem_258, reflection_pad2d_default_14, primals_212, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_258 = reflection_pad2d_default_14 = primals_212 = None
        getitem_261 = convolution_backward_default_21[0]
        getitem_262 = convolution_backward_default_21[1]
        getitem_263 = convolution_backward_default_21[2];  convolution_backward_default_21 = None
        reflection_pad2d_backward_default_17 = torch.ops.aten.reflection_pad2d_backward.default(getitem_261, add_tensor_4, [1, 1, 1, 1]);  getitem_261 = add_tensor_4 = None
        add_tensor_21 = torch.ops.aten.add.Tensor(add_tensor_20, reflection_pad2d_backward_default_17);  add_tensor_20 = reflection_pad2d_backward_default_17 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_21, convolution_default_25, primals_210, primals_208, primals_209, new_zeros_default_75, new_zeros_default_76, False, 1e-05, [True, True, True]);  convolution_default_25 = primals_210 = primals_208 = primals_209 = new_zeros_default_75 = new_zeros_default_76 = None
        getitem_264 = native_batch_norm_backward_default_20[0]
        getitem_265 = native_batch_norm_backward_default_20[1]
        getitem_266 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(getitem_264, reflection_pad2d_default_13, primals_205, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_264 = reflection_pad2d_default_13 = primals_205 = None
        getitem_267 = convolution_backward_default_22[0]
        getitem_268 = convolution_backward_default_22[1]
        getitem_269 = convolution_backward_default_22[2];  convolution_backward_default_22 = None
        reflection_pad2d_backward_default_18 = torch.ops.aten.reflection_pad2d_backward.default(getitem_267, relu__default_20, [1, 1, 1, 1]);  getitem_267 = None
        to_dtype_39 = torch.ops.aten.to.dtype(reflection_pad2d_backward_default_18, torch.float32);  reflection_pad2d_backward_default_18 = None
        to_dtype_40 = torch.ops.aten.to.dtype(relu__default_20, torch.float32);  relu__default_20 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        new_zeros_default_150 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_150, to_dtype_39);  le_scalar_12 = new_zeros_default_150 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_41, convolution_default_24, primals_203, primals_201, primals_202, new_zeros_default_72, new_zeros_default_73, False, 1e-05, [True, True, True]);  to_dtype_41 = convolution_default_24 = primals_203 = primals_201 = primals_202 = new_zeros_default_72 = new_zeros_default_73 = None
        getitem_270 = native_batch_norm_backward_default_21[0]
        getitem_271 = native_batch_norm_backward_default_21[1]
        getitem_272 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(getitem_270, reflection_pad2d_default_12, primals_198, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_270 = reflection_pad2d_default_12 = primals_198 = None
        getitem_273 = convolution_backward_default_23[0]
        getitem_274 = convolution_backward_default_23[1]
        getitem_275 = convolution_backward_default_23[2];  convolution_backward_default_23 = None
        reflection_pad2d_backward_default_19 = torch.ops.aten.reflection_pad2d_backward.default(getitem_273, add_tensor_3, [1, 1, 1, 1]);  getitem_273 = add_tensor_3 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(add_tensor_21, reflection_pad2d_backward_default_19);  add_tensor_21 = reflection_pad2d_backward_default_19 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_22, convolution_default_23, primals_196, primals_194, primals_195, new_zeros_default_69, new_zeros_default_70, False, 1e-05, [True, True, True]);  convolution_default_23 = primals_196 = primals_194 = primals_195 = new_zeros_default_69 = new_zeros_default_70 = None
        getitem_276 = native_batch_norm_backward_default_22[0]
        getitem_277 = native_batch_norm_backward_default_22[1]
        getitem_278 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_276, reflection_pad2d_default_11, primals_191, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_276 = reflection_pad2d_default_11 = primals_191 = None
        getitem_279 = convolution_backward_default_24[0]
        getitem_280 = convolution_backward_default_24[1]
        getitem_281 = convolution_backward_default_24[2];  convolution_backward_default_24 = None
        reflection_pad2d_backward_default_20 = torch.ops.aten.reflection_pad2d_backward.default(getitem_279, relu__default_19, [1, 1, 1, 1]);  getitem_279 = None
        to_dtype_42 = torch.ops.aten.to.dtype(reflection_pad2d_backward_default_20, torch.float32);  reflection_pad2d_backward_default_20 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu__default_19, torch.float32);  relu__default_19 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_151 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_151, to_dtype_42);  le_scalar_13 = new_zeros_default_151 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_44, convolution_default_22, primals_189, primals_187, primals_188, new_zeros_default_66, new_zeros_default_67, False, 1e-05, [True, True, True]);  to_dtype_44 = convolution_default_22 = primals_189 = primals_187 = primals_188 = new_zeros_default_66 = new_zeros_default_67 = None
        getitem_282 = native_batch_norm_backward_default_23[0]
        getitem_283 = native_batch_norm_backward_default_23[1]
        getitem_284 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_282, reflection_pad2d_default_10, primals_184, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_282 = reflection_pad2d_default_10 = primals_184 = None
        getitem_285 = convolution_backward_default_25[0]
        getitem_286 = convolution_backward_default_25[1]
        getitem_287 = convolution_backward_default_25[2];  convolution_backward_default_25 = None
        reflection_pad2d_backward_default_21 = torch.ops.aten.reflection_pad2d_backward.default(getitem_285, add_tensor_2, [1, 1, 1, 1]);  getitem_285 = add_tensor_2 = None
        add_tensor_23 = torch.ops.aten.add.Tensor(add_tensor_22, reflection_pad2d_backward_default_21);  add_tensor_22 = reflection_pad2d_backward_default_21 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_23, convolution_default_21, primals_182, primals_180, primals_181, new_zeros_default_63, new_zeros_default_64, False, 1e-05, [True, True, True]);  convolution_default_21 = primals_182 = primals_180 = primals_181 = new_zeros_default_63 = new_zeros_default_64 = None
        getitem_288 = native_batch_norm_backward_default_24[0]
        getitem_289 = native_batch_norm_backward_default_24[1]
        getitem_290 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(getitem_288, reflection_pad2d_default_9, primals_177, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_288 = reflection_pad2d_default_9 = primals_177 = None
        getitem_291 = convolution_backward_default_26[0]
        getitem_292 = convolution_backward_default_26[1]
        getitem_293 = convolution_backward_default_26[2];  convolution_backward_default_26 = None
        reflection_pad2d_backward_default_22 = torch.ops.aten.reflection_pad2d_backward.default(getitem_291, relu__default_18, [1, 1, 1, 1]);  getitem_291 = None
        to_dtype_45 = torch.ops.aten.to.dtype(reflection_pad2d_backward_default_22, torch.float32);  reflection_pad2d_backward_default_22 = None
        to_dtype_46 = torch.ops.aten.to.dtype(relu__default_18, torch.float32);  relu__default_18 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_46, 0);  to_dtype_46 = None
        new_zeros_default_152 = torch.ops.aten.new_zeros.default(to_dtype_45, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_152, to_dtype_45);  le_scalar_14 = new_zeros_default_152 = to_dtype_45 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_47, convolution_default_20, primals_175, primals_173, primals_174, new_zeros_default_60, new_zeros_default_61, False, 1e-05, [True, True, True]);  to_dtype_47 = convolution_default_20 = primals_175 = primals_173 = primals_174 = new_zeros_default_60 = new_zeros_default_61 = None
        getitem_294 = native_batch_norm_backward_default_25[0]
        getitem_295 = native_batch_norm_backward_default_25[1]
        getitem_296 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(getitem_294, reflection_pad2d_default_8, primals_170, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_294 = reflection_pad2d_default_8 = primals_170 = None
        getitem_297 = convolution_backward_default_27[0]
        getitem_298 = convolution_backward_default_27[1]
        getitem_299 = convolution_backward_default_27[2];  convolution_backward_default_27 = None
        reflection_pad2d_backward_default_23 = torch.ops.aten.reflection_pad2d_backward.default(getitem_297, add_tensor_1, [1, 1, 1, 1]);  getitem_297 = add_tensor_1 = None
        add_tensor_24 = torch.ops.aten.add.Tensor(add_tensor_23, reflection_pad2d_backward_default_23);  add_tensor_23 = reflection_pad2d_backward_default_23 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_24, convolution_default_19, primals_168, primals_166, primals_167, new_zeros_default_57, new_zeros_default_58, False, 1e-05, [True, True, True]);  convolution_default_19 = primals_168 = primals_166 = primals_167 = new_zeros_default_57 = new_zeros_default_58 = None
        getitem_300 = native_batch_norm_backward_default_26[0]
        getitem_301 = native_batch_norm_backward_default_26[1]
        getitem_302 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(getitem_300, reflection_pad2d_default_7, primals_163, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_300 = reflection_pad2d_default_7 = primals_163 = None
        getitem_303 = convolution_backward_default_28[0]
        getitem_304 = convolution_backward_default_28[1]
        getitem_305 = convolution_backward_default_28[2];  convolution_backward_default_28 = None
        reflection_pad2d_backward_default_24 = torch.ops.aten.reflection_pad2d_backward.default(getitem_303, relu__default_17, [1, 1, 1, 1]);  getitem_303 = None
        to_dtype_48 = torch.ops.aten.to.dtype(reflection_pad2d_backward_default_24, torch.float32);  reflection_pad2d_backward_default_24 = None
        to_dtype_49 = torch.ops.aten.to.dtype(relu__default_17, torch.float32);  relu__default_17 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_49, 0);  to_dtype_49 = None
        new_zeros_default_153 = torch.ops.aten.new_zeros.default(to_dtype_48, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_153, to_dtype_48);  le_scalar_15 = new_zeros_default_153 = to_dtype_48 = None
        to_dtype_50 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_50, convolution_default_18, primals_161, primals_159, primals_160, new_zeros_default_54, new_zeros_default_55, False, 1e-05, [True, True, True]);  to_dtype_50 = convolution_default_18 = primals_161 = primals_159 = primals_160 = new_zeros_default_54 = new_zeros_default_55 = None
        getitem_306 = native_batch_norm_backward_default_27[0]
        getitem_307 = native_batch_norm_backward_default_27[1]
        getitem_308 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(getitem_306, reflection_pad2d_default_6, primals_156, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_306 = reflection_pad2d_default_6 = primals_156 = None
        getitem_309 = convolution_backward_default_29[0]
        getitem_310 = convolution_backward_default_29[1]
        getitem_311 = convolution_backward_default_29[2];  convolution_backward_default_29 = None
        reflection_pad2d_backward_default_25 = torch.ops.aten.reflection_pad2d_backward.default(getitem_309, add_tensor, [1, 1, 1, 1]);  getitem_309 = add_tensor = None
        add_tensor_25 = torch.ops.aten.add.Tensor(add_tensor_24, reflection_pad2d_backward_default_25);  add_tensor_24 = reflection_pad2d_backward_default_25 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_25, convolution_default_17, primals_154, primals_152, primals_153, new_zeros_default_51, new_zeros_default_52, False, 1e-05, [True, True, True]);  convolution_default_17 = primals_154 = primals_152 = primals_153 = new_zeros_default_51 = new_zeros_default_52 = None
        getitem_312 = native_batch_norm_backward_default_28[0]
        getitem_313 = native_batch_norm_backward_default_28[1]
        getitem_314 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_312, reflection_pad2d_default_5, primals_149, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_312 = reflection_pad2d_default_5 = primals_149 = None
        getitem_315 = convolution_backward_default_30[0]
        getitem_316 = convolution_backward_default_30[1]
        getitem_317 = convolution_backward_default_30[2];  convolution_backward_default_30 = None
        reflection_pad2d_backward_default_26 = torch.ops.aten.reflection_pad2d_backward.default(getitem_315, relu__default_16, [1, 1, 1, 1]);  getitem_315 = None
        to_dtype_51 = torch.ops.aten.to.dtype(reflection_pad2d_backward_default_26, torch.float32);  reflection_pad2d_backward_default_26 = None
        to_dtype_52 = torch.ops.aten.to.dtype(relu__default_16, torch.float32);  relu__default_16 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_52, 0);  to_dtype_52 = None
        new_zeros_default_154 = torch.ops.aten.new_zeros.default(to_dtype_51, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_154, to_dtype_51);  le_scalar_16 = new_zeros_default_154 = to_dtype_51 = None
        to_dtype_53 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_53, convolution_default_16, primals_147, primals_145, primals_146, new_zeros_default_48, new_zeros_default_49, False, 1e-05, [True, True, True]);  to_dtype_53 = convolution_default_16 = primals_147 = primals_145 = primals_146 = new_zeros_default_48 = new_zeros_default_49 = None
        getitem_318 = native_batch_norm_backward_default_29[0]
        getitem_319 = native_batch_norm_backward_default_29[1]
        getitem_320 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(getitem_318, reflection_pad2d_default_4, primals_142, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_318 = reflection_pad2d_default_4 = primals_142 = None
        getitem_321 = convolution_backward_default_31[0]
        getitem_322 = convolution_backward_default_31[1]
        getitem_323 = convolution_backward_default_31[2];  convolution_backward_default_31 = None
        reflection_pad2d_backward_default_27 = torch.ops.aten.reflection_pad2d_backward.default(getitem_321, relu__default_15, [1, 1, 1, 1]);  getitem_321 = None
        add_tensor_26 = torch.ops.aten.add.Tensor(add_tensor_25, reflection_pad2d_backward_default_27);  add_tensor_25 = reflection_pad2d_backward_default_27 = None
        to_dtype_54 = torch.ops.aten.to.dtype(add_tensor_26, torch.float32);  add_tensor_26 = None
        to_dtype_55 = torch.ops.aten.to.dtype(relu__default_15, torch.float32);  relu__default_15 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_55, 0);  to_dtype_55 = None
        new_zeros_default_155 = torch.ops.aten.new_zeros.default(to_dtype_54, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_17, new_zeros_default_155, to_dtype_54);  le_scalar_17 = new_zeros_default_155 = to_dtype_54 = None
        to_dtype_56 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_56, convolution_default_15, primals_140, primals_138, primals_139, new_zeros_default_45, new_zeros_default_46, False, 1e-05, [True, True, True]);  to_dtype_56 = convolution_default_15 = primals_140 = primals_138 = primals_139 = new_zeros_default_45 = new_zeros_default_46 = None
        getitem_324 = native_batch_norm_backward_default_30[0]
        getitem_325 = native_batch_norm_backward_default_30[1]
        getitem_326 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(getitem_324, cat_default_4, primals_135, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_324 = cat_default_4 = primals_135 = None
        getitem_327 = convolution_backward_default_32[0]
        getitem_328 = convolution_backward_default_32[1]
        getitem_329 = convolution_backward_default_32[2];  convolution_backward_default_32 = None
        slice_tensor_2 = torch.ops.aten.slice.Tensor(getitem_327, 1, 0, 256)
        slice_tensor_3 = torch.ops.aten.slice.Tensor(getitem_327, 1, 256, 448);  getitem_327 = None
        slice_tensor_4 = torch.ops.aten.slice.Tensor(slice_tensor_3, 1, 0, 64)
        slice_tensor_5 = torch.ops.aten.slice.Tensor(slice_tensor_3, 1, 64, 128)
        slice_tensor_6 = torch.ops.aten.slice.Tensor(slice_tensor_3, 1, 128, 192);  slice_tensor_3 = None
        to_dtype_57 = torch.ops.aten.to.dtype(slice_tensor_6, torch.float32);  slice_tensor_6 = None
        to_dtype_58 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_58, 0);  to_dtype_58 = None
        new_zeros_default_156 = torch.ops.aten.new_zeros.default(to_dtype_57, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_18 = torch.ops.aten.where.self(le_scalar_18, new_zeros_default_156, to_dtype_57);  le_scalar_18 = new_zeros_default_156 = to_dtype_57 = None
        to_dtype_59 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_59, convolution_default_14, primals_12, primals_10, primals_11, new_zeros_default_42, new_zeros_default_43, False, 1e-05, [True, True, True]);  to_dtype_59 = convolution_default_14 = primals_12 = primals_10 = primals_11 = new_zeros_default_42 = new_zeros_default_43 = None
        getitem_330 = native_batch_norm_backward_default_31[0]
        getitem_331 = native_batch_norm_backward_default_31[1]
        getitem_332 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(getitem_330, cat_default_2, primals_7, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_330 = cat_default_2 = primals_7 = None
        getitem_333 = convolution_backward_default_33[0]
        getitem_334 = convolution_backward_default_33[1]
        getitem_335 = convolution_backward_default_33[2];  convolution_backward_default_33 = None
        slice_tensor_7 = torch.ops.aten.slice.Tensor(getitem_333, 1, 0, 256)
        slice_tensor_8 = torch.ops.aten.slice.Tensor(getitem_333, 1, 256, 512);  getitem_333 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(slice_tensor_2, slice_tensor_7);  slice_tensor_2 = slice_tensor_7 = None
        to_dtype_60 = torch.ops.aten.to.dtype(slice_tensor_5, torch.float32);  slice_tensor_5 = None
        to_dtype_61 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_61, 0);  to_dtype_61 = None
        new_zeros_default_157 = torch.ops.aten.new_zeros.default(to_dtype_60, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_19 = torch.ops.aten.where.self(le_scalar_19, new_zeros_default_157, to_dtype_60);  le_scalar_19 = new_zeros_default_157 = to_dtype_60 = None
        to_dtype_62 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_62, convolution_default_13, primals_18, primals_16, primals_17, new_zeros_default_39, new_zeros_default_40, False, 1e-05, [True, True, True]);  to_dtype_62 = convolution_default_13 = primals_18 = primals_16 = primals_17 = new_zeros_default_39 = new_zeros_default_40 = None
        getitem_336 = native_batch_norm_backward_default_32[0]
        getitem_337 = native_batch_norm_backward_default_32[1]
        getitem_338 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(getitem_336, cat_default_1, primals_13, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_336 = cat_default_1 = primals_13 = None
        getitem_339 = convolution_backward_default_34[0]
        getitem_340 = convolution_backward_default_34[1]
        getitem_341 = convolution_backward_default_34[2];  convolution_backward_default_34 = None
        slice_tensor_9 = torch.ops.aten.slice.Tensor(getitem_339, 1, 0, 256)
        slice_tensor_10 = torch.ops.aten.slice.Tensor(getitem_339, 1, 256, 512);  getitem_339 = None
        add_tensor_28 = torch.ops.aten.add.Tensor(add_tensor_27, slice_tensor_9);  add_tensor_27 = slice_tensor_9 = None
        to_dtype_63 = torch.ops.aten.to.dtype(slice_tensor_4, torch.float32);  slice_tensor_4 = None
        to_dtype_64 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_64, 0);  to_dtype_64 = None
        new_zeros_default_158 = torch.ops.aten.new_zeros.default(to_dtype_63, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_20 = torch.ops.aten.where.self(le_scalar_20, new_zeros_default_158, to_dtype_63);  le_scalar_20 = new_zeros_default_158 = to_dtype_63 = None
        to_dtype_65 = torch.ops.aten.to.dtype(where_self_20, torch.float32);  where_self_20 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_65, convolution_default_12, primals_6, primals_4, primals_5, new_zeros_default_36, new_zeros_default_37, False, 1e-05, [True, True, True]);  to_dtype_65 = convolution_default_12 = primals_6 = primals_4 = primals_5 = new_zeros_default_36 = new_zeros_default_37 = None
        getitem_342 = native_batch_norm_backward_default_33[0]
        getitem_343 = native_batch_norm_backward_default_33[1]
        getitem_344 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_342, cat_default, primals_1, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_342 = cat_default = primals_1 = None
        getitem_345 = convolution_backward_default_35[0]
        getitem_346 = convolution_backward_default_35[1]
        getitem_347 = convolution_backward_default_35[2];  convolution_backward_default_35 = None
        slice_tensor_11 = torch.ops.aten.slice.Tensor(getitem_345, 1, 0, 256)
        slice_tensor_12 = torch.ops.aten.slice.Tensor(getitem_345, 1, 256, 512);  getitem_345 = None
        add_tensor_29 = torch.ops.aten.add.Tensor(add_tensor_28, slice_tensor_11);  add_tensor_28 = slice_tensor_11 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(slice_tensor_8, slice_tensor_12);  slice_tensor_8 = slice_tensor_12 = None
        to_dtype_66 = torch.ops.aten.to.dtype(slice_tensor_10, torch.float32);  slice_tensor_10 = None
        to_dtype_67 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_67, 0);  to_dtype_67 = None
        new_zeros_default_159 = torch.ops.aten.new_zeros.default(to_dtype_66, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_21 = torch.ops.aten.where.self(le_scalar_21, new_zeros_default_159, to_dtype_66);  le_scalar_21 = new_zeros_default_159 = to_dtype_66 = None
        to_dtype_68 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_68, convolution_default_8, primals_125, primals_123, primals_124, new_zeros_default_24, new_zeros_default_25, False, 1e-05, [True, True, True]);  to_dtype_68 = convolution_default_8 = primals_125 = primals_123 = primals_124 = new_zeros_default_24 = new_zeros_default_25 = None
        getitem_348 = native_batch_norm_backward_default_34[0]
        getitem_349 = native_batch_norm_backward_default_34[1]
        getitem_350 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(getitem_348, relu__default_7, primals_120, [256], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_348 = primals_120 = None
        getitem_351 = convolution_backward_default_36[0]
        getitem_352 = convolution_backward_default_36[1]
        getitem_353 = convolution_backward_default_36[2];  convolution_backward_default_36 = None
        to_dtype_69 = torch.ops.aten.to.dtype(getitem_351, torch.float32);  getitem_351 = None
        to_dtype_70 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_70, 0);  to_dtype_70 = None
        new_zeros_default_160 = torch.ops.aten.new_zeros.default(to_dtype_69, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_22 = torch.ops.aten.where.self(le_scalar_22, new_zeros_default_160, to_dtype_69);  le_scalar_22 = new_zeros_default_160 = to_dtype_69 = None
        to_dtype_71 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_71, convolution_default_7, primals_118, primals_116, primals_117, new_zeros_default_21, new_zeros_default_22, False, 1e-05, [True, True, True]);  to_dtype_71 = convolution_default_7 = primals_118 = primals_116 = primals_117 = new_zeros_default_21 = new_zeros_default_22 = None
        getitem_354 = native_batch_norm_backward_default_35[0]
        getitem_355 = native_batch_norm_backward_default_35[1]
        getitem_356 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(getitem_354, relu__default_6, primals_113, [128], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_354 = primals_113 = None
        getitem_357 = convolution_backward_default_37[0]
        getitem_358 = convolution_backward_default_37[1]
        getitem_359 = convolution_backward_default_37[2];  convolution_backward_default_37 = None
        to_dtype_72 = torch.ops.aten.to.dtype(getitem_357, torch.float32);  getitem_357 = None
        to_dtype_73 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_73, 0);  to_dtype_73 = None
        new_zeros_default_161 = torch.ops.aten.new_zeros.default(to_dtype_72, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(le_scalar_23, new_zeros_default_161, to_dtype_72);  le_scalar_23 = new_zeros_default_161 = to_dtype_72 = None
        to_dtype_74 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_74, convolution_default_6, primals_111, primals_109, primals_110, new_zeros_default_18, new_zeros_default_19, False, 1e-05, [True, True, True]);  to_dtype_74 = convolution_default_6 = primals_111 = primals_109 = primals_110 = new_zeros_default_18 = new_zeros_default_19 = None
        getitem_360 = native_batch_norm_backward_default_36[0]
        getitem_361 = native_batch_norm_backward_default_36[1]
        getitem_362 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(getitem_360, reflection_pad2d_default_2, primals_106, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [False, True, True]);  getitem_360 = reflection_pad2d_default_2 = primals_106 = None
        getitem_363 = convolution_backward_default_38[0]
        getitem_364 = convolution_backward_default_38[1]
        getitem_365 = convolution_backward_default_38[2];  convolution_backward_default_38 = None
        to_dtype_75 = torch.ops.aten.to.dtype(add_tensor_30, torch.float32);  add_tensor_30 = None
        to_dtype_76 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_76, 0);  to_dtype_76 = None
        new_zeros_default_162 = torch.ops.aten.new_zeros.default(to_dtype_75, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_24 = torch.ops.aten.where.self(le_scalar_24, new_zeros_default_162, to_dtype_75);  le_scalar_24 = new_zeros_default_162 = to_dtype_75 = None
        to_dtype_77 = torch.ops.aten.to.dtype(where_self_24, torch.float32);  where_self_24 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_77, convolution_default_5, primals_83, primals_81, primals_82, new_zeros_default_15, new_zeros_default_16, False, 1e-05, [True, True, True]);  to_dtype_77 = convolution_default_5 = primals_83 = primals_81 = primals_82 = new_zeros_default_15 = new_zeros_default_16 = None
        getitem_366 = native_batch_norm_backward_default_37[0]
        getitem_367 = native_batch_norm_backward_default_37[1]
        getitem_368 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(getitem_366, relu__default_4, primals_78, [256], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_366 = primals_78 = None
        getitem_369 = convolution_backward_default_39[0]
        getitem_370 = convolution_backward_default_39[1]
        getitem_371 = convolution_backward_default_39[2];  convolution_backward_default_39 = None
        to_dtype_78 = torch.ops.aten.to.dtype(getitem_369, torch.float32);  getitem_369 = None
        to_dtype_79 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_79, 0);  to_dtype_79 = None
        new_zeros_default_163 = torch.ops.aten.new_zeros.default(to_dtype_78, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_25 = torch.ops.aten.where.self(le_scalar_25, new_zeros_default_163, to_dtype_78);  le_scalar_25 = new_zeros_default_163 = to_dtype_78 = None
        to_dtype_80 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_80, convolution_default_4, primals_76, primals_74, primals_75, new_zeros_default_12, new_zeros_default_13, False, 1e-05, [True, True, True]);  to_dtype_80 = convolution_default_4 = primals_76 = primals_74 = primals_75 = new_zeros_default_12 = new_zeros_default_13 = None
        getitem_372 = native_batch_norm_backward_default_38[0]
        getitem_373 = native_batch_norm_backward_default_38[1]
        getitem_374 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(getitem_372, relu__default_3, primals_71, [128], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_372 = primals_71 = None
        getitem_375 = convolution_backward_default_40[0]
        getitem_376 = convolution_backward_default_40[1]
        getitem_377 = convolution_backward_default_40[2];  convolution_backward_default_40 = None
        to_dtype_81 = torch.ops.aten.to.dtype(getitem_375, torch.float32);  getitem_375 = None
        to_dtype_82 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_26 = torch.ops.aten.le.Scalar(to_dtype_82, 0);  to_dtype_82 = None
        new_zeros_default_164 = torch.ops.aten.new_zeros.default(to_dtype_81, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_26 = torch.ops.aten.where.self(le_scalar_26, new_zeros_default_164, to_dtype_81);  le_scalar_26 = new_zeros_default_164 = to_dtype_81 = None
        to_dtype_83 = torch.ops.aten.to.dtype(where_self_26, torch.float32);  where_self_26 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_83, convolution_default_3, primals_69, primals_67, primals_68, new_zeros_default_9, new_zeros_default_10, False, 1e-05, [True, True, True]);  to_dtype_83 = convolution_default_3 = primals_69 = primals_67 = primals_68 = new_zeros_default_9 = new_zeros_default_10 = None
        getitem_378 = native_batch_norm_backward_default_39[0]
        getitem_379 = native_batch_norm_backward_default_39[1]
        getitem_380 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(getitem_378, reflection_pad2d_default_1, primals_64, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [False, True, True]);  getitem_378 = reflection_pad2d_default_1 = primals_64 = None
        getitem_381 = convolution_backward_default_41[0]
        getitem_382 = convolution_backward_default_41[1]
        getitem_383 = convolution_backward_default_41[2];  convolution_backward_default_41 = None
        to_dtype_84 = torch.ops.aten.to.dtype(add_tensor_29, torch.float32);  add_tensor_29 = None
        to_dtype_85 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_27 = torch.ops.aten.le.Scalar(to_dtype_85, 0);  to_dtype_85 = None
        new_zeros_default_165 = torch.ops.aten.new_zeros.default(to_dtype_84, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_27 = torch.ops.aten.where.self(le_scalar_27, new_zeros_default_165, to_dtype_84);  le_scalar_27 = new_zeros_default_165 = to_dtype_84 = None
        to_dtype_86 = torch.ops.aten.to.dtype(where_self_27, torch.float32);  where_self_27 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_86, convolution_default_2, primals_62, primals_60, primals_61, new_zeros_default_6, new_zeros_default_7, False, 1e-05, [True, True, True]);  to_dtype_86 = convolution_default_2 = primals_62 = primals_60 = primals_61 = new_zeros_default_6 = new_zeros_default_7 = None
        getitem_384 = native_batch_norm_backward_default_40[0]
        getitem_385 = native_batch_norm_backward_default_40[1]
        getitem_386 = native_batch_norm_backward_default_40[2];  native_batch_norm_backward_default_40 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(getitem_384, relu__default_1, primals_57, [256], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_384 = primals_57 = None
        getitem_387 = convolution_backward_default_42[0]
        getitem_388 = convolution_backward_default_42[1]
        getitem_389 = convolution_backward_default_42[2];  convolution_backward_default_42 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(slice_tensor_1, getitem_387);  slice_tensor_1 = getitem_387 = None
        to_dtype_87 = torch.ops.aten.to.dtype(add_tensor_31, torch.float32);  add_tensor_31 = None
        to_dtype_88 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_28 = torch.ops.aten.le.Scalar(to_dtype_88, 0);  to_dtype_88 = None
        new_zeros_default_166 = torch.ops.aten.new_zeros.default(to_dtype_87, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_28 = torch.ops.aten.where.self(le_scalar_28, new_zeros_default_166, to_dtype_87);  le_scalar_28 = new_zeros_default_166 = to_dtype_87 = None
        to_dtype_89 = torch.ops.aten.to.dtype(where_self_28, torch.float32);  where_self_28 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_89, convolution_default_1, primals_55, primals_53, primals_54, new_zeros_default_3, new_zeros_default_4, False, 1e-05, [True, True, True]);  to_dtype_89 = convolution_default_1 = primals_55 = primals_53 = primals_54 = new_zeros_default_3 = new_zeros_default_4 = None
        getitem_390 = native_batch_norm_backward_default_41[0]
        getitem_391 = native_batch_norm_backward_default_41[1]
        getitem_392 = native_batch_norm_backward_default_41[2];  native_batch_norm_backward_default_41 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(getitem_390, relu__default, primals_50, [128], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_390 = primals_50 = None
        getitem_393 = convolution_backward_default_43[0]
        getitem_394 = convolution_backward_default_43[1]
        getitem_395 = convolution_backward_default_43[2];  convolution_backward_default_43 = None
        to_dtype_90 = torch.ops.aten.to.dtype(getitem_393, torch.float32);  getitem_393 = None
        to_dtype_91 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_29 = torch.ops.aten.le.Scalar(to_dtype_91, 0);  to_dtype_91 = None
        new_zeros_default_167 = torch.ops.aten.new_zeros.default(to_dtype_90, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_29 = torch.ops.aten.where.self(le_scalar_29, new_zeros_default_167, to_dtype_90);  le_scalar_29 = new_zeros_default_167 = to_dtype_90 = None
        to_dtype_92 = torch.ops.aten.to.dtype(where_self_29, torch.float32);  where_self_29 = None
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_92, convolution_default, primals_48, primals_46, primals_47, new_zeros_default, new_zeros_default_1, False, 1e-05, [True, True, True]);  to_dtype_92 = convolution_default = primals_48 = primals_46 = primals_47 = new_zeros_default = new_zeros_default_1 = None
        getitem_396 = native_batch_norm_backward_default_42[0]
        getitem_397 = native_batch_norm_backward_default_42[1]
        getitem_398 = native_batch_norm_backward_default_42[2];  native_batch_norm_backward_default_42 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(getitem_396, reflection_pad2d_default, primals_43, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [False, True, True]);  getitem_396 = reflection_pad2d_default = primals_43 = None
        getitem_399 = convolution_backward_default_44[0]
        getitem_400 = convolution_backward_default_44[1]
        getitem_401 = convolution_backward_default_44[2];  convolution_backward_default_44 = None
        return [tanh_default, convolution_default_47, getitem_346, getitem_344, None, None, None, getitem_343, getitem_334, getitem_332, None, None, None, getitem_331, getitem_340, getitem_338, None, None, None, getitem_337, getitem_203, getitem_202, getitem_200, None, None, None, getitem_199, getitem_197, getitem_196, getitem_194, None, None, None, getitem_193, getitem_191, getitem_190, getitem_152, getitem_151, getitem_149, None, None, None, getitem_148, getitem_401, getitem_400, getitem_398, None, None, None, getitem_397, getitem_395, getitem_394, getitem_392, None, None, None, getitem_391, getitem_389, getitem_388, getitem_386, None, None, None, getitem_385, getitem_383, getitem_382, getitem_380, None, None, None, getitem_379, getitem_377, getitem_376, getitem_374, None, None, None, getitem_373, getitem_371, getitem_370, getitem_368, None, None, None, getitem_367, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, getitem_365, getitem_364, getitem_362, None, None, None, getitem_361, getitem_359, getitem_358, getitem_356, None, None, None, getitem_355, getitem_353, getitem_352, getitem_350, None, None, None, getitem_349, getitem_146, getitem_145, getitem_143, None, None, None, getitem_142, getitem_140, getitem_139, getitem_328, getitem_326, None, None, None, getitem_325, getitem_323, getitem_322, getitem_320, None, None, None, getitem_319, getitem_317, getitem_316, getitem_314, None, None, None, getitem_313, getitem_311, getitem_310, getitem_308, None, None, None, getitem_307, getitem_305, getitem_304, getitem_302, None, None, None, getitem_301, getitem_299, getitem_298, getitem_296, None, None, None, getitem_295, getitem_293, getitem_292, getitem_290, None, None, None, getitem_289, getitem_287, getitem_286, getitem_284, None, None, None, getitem_283, getitem_281, getitem_280, getitem_278, None, None, None, getitem_277, getitem_275, getitem_274, getitem_272, None, None, None, getitem_271, getitem_269, getitem_268, getitem_266, None, None, None, getitem_265, getitem_263, getitem_262, getitem_260, None, None, None, getitem_259, getitem_257, getitem_256, getitem_254, None, None, None, getitem_253, getitem_251, getitem_250, getitem_248, None, None, None, getitem_247, getitem_245, getitem_244, getitem_242, None, None, None, getitem_241, getitem_239, getitem_238, getitem_236, None, None, None, getitem_235, getitem_233, getitem_232, getitem_230, None, None, None, getitem_229, getitem_227, getitem_226, getitem_224, None, None, None, getitem_223, getitem_221, getitem_220, getitem_218, None, None, None, getitem_217, getitem_215, getitem_214, getitem_212, None, None, None, getitem_211, getitem_209, getitem_208, getitem_206, None, None, None, getitem_205, getitem_188, getitem_187, getitem_185, None, None, None, getitem_184, getitem_182, getitem_181, getitem_179, None, None, None, getitem_178, getitem_176, getitem_175, getitem_173, None, None, None, getitem_172, getitem_170, getitem_169, getitem_167, None, None, None, getitem_166, getitem_164, getitem_163, getitem_161, None, None, None, getitem_160, getitem_158, getitem_157, getitem_155, None, None, None, getitem_154, None, None, None, None]
        
