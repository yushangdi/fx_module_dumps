
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/timm_efficientdet/timm_efficientdet_joint_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339, primals_340, primals_341, primals_342, primals_343, primals_344, primals_345, primals_346, primals_347, primals_348, primals_349, primals_350, primals_351, primals_352, primals_353, primals_354, primals_355, primals_356, primals_357, primals_358, primals_359, primals_360, primals_361, primals_362, primals_363, primals_364, primals_365, primals_366, primals_367, primals_368, primals_369, primals_370, primals_371, primals_372, primals_373, primals_374, primals_375, primals_376, primals_377, primals_378, primals_379, primals_380, primals_381, primals_382, primals_383, primals_384, primals_385, primals_386, primals_387, primals_388, primals_389, primals_390, primals_391, primals_392, primals_393, primals_394, primals_395, primals_396, primals_397, primals_398, primals_399, primals_400, primals_401, primals_402, primals_403, primals_404, primals_405, primals_406, primals_407, primals_408, primals_409, primals_410, primals_411, primals_412, primals_413, primals_414, primals_415, primals_416, primals_417, primals_418, primals_419, primals_420, primals_421, primals_422, primals_423, primals_424, primals_425, primals_426, primals_427, primals_428, primals_429, primals_430, primals_431, primals_432, primals_433, primals_434, primals_435, primals_436, primals_437, primals_438, primals_439, primals_440, primals_441, primals_442, primals_443, primals_444, primals_445, primals_446, primals_447, primals_448, primals_449, primals_450, primals_451, primals_452, primals_453, primals_454, primals_455, primals_456, primals_457, primals_458, primals_459, primals_460, primals_461, primals_462, primals_463, primals_464, primals_465, primals_466, primals_467, primals_468, primals_469, primals_470, primals_471, primals_472, primals_473, primals_474, primals_475, primals_476, primals_477, primals_478, primals_479, primals_480, primals_481, primals_482, primals_483, primals_484, primals_485, primals_486, primals_487, primals_488, primals_489, primals_490, primals_491, primals_492, primals_493, primals_494, primals_495, primals_496, primals_497, primals_498, primals_499, primals_500, primals_501, primals_502, primals_503, primals_504, primals_505, primals_506, primals_507, primals_508, primals_509, primals_510, primals_511, primals_512, primals_513, primals_514, primals_515, primals_516, primals_517, primals_518, primals_519, primals_520, primals_521, primals_522, primals_523, primals_524, primals_525, primals_526, primals_527, primals_528, primals_529, primals_530, primals_531, primals_532, primals_533, primals_534, primals_535, primals_536, primals_537, primals_538, primals_539, primals_540, primals_541, primals_542, primals_543, primals_544, primals_545, primals_546, primals_547, primals_548, primals_549, primals_550, primals_551, primals_552, primals_553, primals_554, primals_555, primals_556, primals_557, primals_558, primals_559, primals_560, primals_561, primals_562, primals_563, primals_564, primals_565, primals_566, primals_567, primals_568, primals_569, primals_570, primals_571, primals_572, primals_573, primals_574, primals_575, primals_576, primals_577, primals_578, primals_579, primals_580, primals_581, primals_582, primals_583, primals_584, primals_585, primals_586, primals_587, primals_588, primals_589, primals_590, primals_591, primals_592, primals_593, primals_594, primals_595, primals_596, primals_597, primals_598, primals_599, primals_600, primals_601, primals_602, primals_603, primals_604, primals_605, primals_606, primals_607, primals_608, primals_609, primals_610, primals_611, primals_612, primals_613, primals_614, primals_615, primals_616, primals_617, primals_618, primals_619, primals_620, primals_621, primals_622, primals_623, primals_624, primals_625, primals_626, primals_627, primals_628, primals_629, primals_630, primals_631, primals_632, primals_633, primals_634, primals_635, primals_636, primals_637, primals_638, primals_639, primals_640, primals_641, primals_642, primals_643, primals_644, primals_645, primals_646, primals_647, primals_648, primals_649, primals_650, primals_651, primals_652, primals_653, primals_654, primals_655, primals_656, primals_657, primals_658, primals_659, primals_660, primals_661, primals_662, primals_663, primals_664, primals_665, primals_666, primals_667, primals_668, primals_669, primals_670, primals_671, primals_672, primals_673, primals_674, primals_675, primals_676, primals_677, primals_678, primals_679, primals_680, primals_681, primals_682, primals_683, primals_684, primals_685, primals_686, primals_687, primals_688, primals_689, primals_690, primals_691, primals_692, primals_693, primals_694, primals_695, primals_696, primals_697, primals_698, primals_699, primals_700, primals_701, primals_702, primals_703, primals_704, primals_705, primals_706, primals_707, primals_708, primals_709, primals_710, primals_711, primals_712, primals_713, primals_714, primals_715, primals_716, primals_717, primals_718, primals_719, primals_720, primals_721, primals_722, primals_723, primals_724, primals_725, primals_726, primals_727, primals_728, primals_729, primals_730, primals_731, primals_732, primals_733, primals_734, primals_735, primals_736, primals_737, primals_738, primals_739, primals_740, primals_741, primals_742, primals_743, primals_744, primals_745, primals_746, primals_747, primals_748, primals_749, primals_750, primals_751, primals_752, primals_753, primals_754, primals_755, primals_756, primals_757, primals_758, primals_759, primals_760, primals_761, primals_762, primals_763, primals_764, primals_765, primals_766, primals_767, primals_768, primals_769, primals_770, primals_771, primals_772, primals_773, primals_774, primals_775, primals_776, primals_777, primals_778, primals_779, primals_780, primals_781, primals_782, primals_783, primals_784, primals_785, primals_786, primals_787, primals_788, primals_789, primals_790, primals_791, primals_792, primals_793, primals_794, primals_795, primals_796, primals_797, primals_798, primals_799, primals_800, primals_801, primals_802, primals_803, primals_804, primals_805, primals_806, primals_807, primals_808, primals_809, primals_810, primals_811, primals_812, primals_813, primals_814, primals_815, primals_816, primals_817, primals_818, primals_819, primals_820, primals_821, primals_822, primals_823, primals_824, primals_825, primals_826, primals_827, primals_828, primals_829, primals_830, primals_831, primals_832, primals_833, primals_834, primals_835, primals_836, primals_837, primals_838, primals_839, primals_840, primals_841, primals_842, primals_843, primals_844, primals_845, primals_846, primals_847, primals_848, primals_849, primals_850, primals_851, primals_852, primals_853, primals_854, primals_855, primals_856, primals_857, primals_858, primals_859, primals_860, primals_861, primals_862, primals_863, primals_864, primals_865, primals_866, primals_867, primals_868, primals_869, primals_870, primals_871, primals_872, primals_873, primals_874, primals_875, primals_876, primals_877, primals_878, primals_879, primals_880, primals_881, primals_882, primals_883, primals_884, primals_885, primals_886, primals_887, primals_888, primals_889, primals_890, primals_891, primals_892, primals_893, primals_894, primals_895, primals_896, primals_897, primals_898, primals_899, primals_900, primals_901, primals_902, primals_903, primals_904, primals_905, primals_906, primals_907, primals_908, primals_909, primals_910, primals_911, primals_912, primals_913, primals_914, primals_915, primals_916, primals_917, primals_918, primals_919, primals_920, primals_921, primals_922, primals_923, primals_924, primals_925, primals_926, primals_927, primals_928, primals_929, primals_930, primals_931, primals_932, primals_933, primals_934, primals_935, primals_936, primals_937, primals_938, primals_939, primals_940, primals_941, primals_942, primals_943, primals_944, primals_945, primals_946, primals_947, primals_948, primals_949, primals_950, primals_951, primals_952, primals_953, primals_954, primals_955, primals_956, primals_957, primals_958, primals_959, primals_960, primals_961, primals_962, primals_963, primals_964, primals_965, primals_966, primals_967, primals_968, primals_969, primals_970, primals_971, primals_972, primals_973, primals_974, primals_975, primals_976, primals_977, primals_978, primals_979, primals_980, primals_981, primals_982, primals_983, primals_984, primals_985, primals_986, primals_987, primals_988, primals_989, primals_990, primals_991, primals_992, primals_993, primals_994, primals_995, primals_996, primals_997, primals_998, primals_999, primals_1000, primals_1001, primals_1002, primals_1003, primals_1004, primals_1005, tangents_1, tangents_2, tangents_3, tangents_4):
        constant_pad_nd_default = torch.ops.aten.constant_pad_nd.default(primals_1005, [0, 1, 0, 1], 0.0);  primals_1005 = None
        convolution_default = torch.ops.aten.convolution.default(constant_pad_nd_default, primals_500, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_499, primals_495, primals_497, primals_498, False, 0.1, 0.001);  primals_495 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        new_zeros_default = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_2 = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default = torch.ops.aten.clone.default(getitem)
        silu__default = torch.ops.aten.silu_.default(getitem);  getitem = None
        convolution_default_1 = torch.ops.aten.convolution.default(silu__default, primals_11, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_5, primals_1, primals_3, primals_4, False, 0.1, 0.001);  primals_1 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_5 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_1 = torch.ops.aten.clone.default(getitem_3)
        silu__default_1 = torch.ops.aten.silu_.default(getitem_3);  getitem_3 = None
        mean_dim = torch.ops.aten.mean.dim(silu__default_1, [2, 3], True)
        convolution_default_2 = torch.ops.aten.convolution.default(mean_dim, primals_16, primals_15, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_15 = None
        clone_default_2 = torch.ops.aten.clone.default(convolution_default_2)
        silu__default_2 = torch.ops.aten.silu_.default(convolution_default_2);  convolution_default_2 = None
        convolution_default_3 = torch.ops.aten.convolution.default(silu__default_2, primals_14, primals_13, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_13 = None
        sigmoid_default = torch.ops.aten.sigmoid.default(convolution_default_3);  convolution_default_3 = None
        mul_tensor = torch.ops.aten.mul.Tensor(silu__default_1, sigmoid_default)
        convolution_default_4 = torch.ops.aten.convolution.default(mul_tensor, primals_12, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_10, primals_6, primals_8, primals_9, False, 0.1, 0.001);  primals_6 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_8 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_5 = torch.ops.aten.convolution.default(getitem_6, primals_27, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 16)
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_21, primals_17, primals_19, primals_20, False, 0.1, 0.001);  primals_17 = None
        getitem_9 = native_batch_norm_default_3[0]
        getitem_10 = native_batch_norm_default_3[1]
        getitem_11 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        new_zeros_default_9 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_10 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_11 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_3 = torch.ops.aten.clone.default(getitem_9)
        silu__default_3 = torch.ops.aten.silu_.default(getitem_9);  getitem_9 = None
        mean_dim_1 = torch.ops.aten.mean.dim(silu__default_3, [2, 3], True)
        convolution_default_6 = torch.ops.aten.convolution.default(mean_dim_1, primals_32, primals_31, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_31 = None
        clone_default_4 = torch.ops.aten.clone.default(convolution_default_6)
        silu__default_4 = torch.ops.aten.silu_.default(convolution_default_6);  convolution_default_6 = None
        convolution_default_7 = torch.ops.aten.convolution.default(silu__default_4, primals_30, primals_29, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_29 = None
        sigmoid_default_1 = torch.ops.aten.sigmoid.default(convolution_default_7);  convolution_default_7 = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(silu__default_3, sigmoid_default_1)
        convolution_default_8 = torch.ops.aten.convolution.default(mul_tensor_1, primals_28, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_26, primals_22, primals_24, primals_25, False, 0.1, 0.001);  primals_22 = None
        getitem_12 = native_batch_norm_default_4[0]
        getitem_13 = native_batch_norm_default_4[1]
        getitem_14 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        new_zeros_default_12 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_13 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_14 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor = torch.ops.aten.add_.Tensor(getitem_12, getitem_6);  getitem_12 = None
        convolution_default_9 = torch.ops.aten.convolution.default(add__tensor, primals_49, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_37, primals_33, primals_35, primals_36, False, 0.1, 0.001);  primals_33 = None
        getitem_15 = native_batch_norm_default_5[0]
        getitem_16 = native_batch_norm_default_5[1]
        getitem_17 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        new_zeros_default_15 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_16 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_17 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_5 = torch.ops.aten.clone.default(getitem_15)
        silu__default_5 = torch.ops.aten.silu_.default(getitem_15);  getitem_15 = None
        constant_pad_nd_default_1 = torch.ops.aten.constant_pad_nd.default(silu__default_5, [0, 1, 0, 1], 0.0);  silu__default_5 = None
        convolution_default_10 = torch.ops.aten.convolution.default(constant_pad_nd_default_1, primals_48, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 96)
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_42, primals_38, primals_40, primals_41, False, 0.1, 0.001);  primals_38 = None
        getitem_18 = native_batch_norm_default_6[0]
        getitem_19 = native_batch_norm_default_6[1]
        getitem_20 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        new_zeros_default_18 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_19 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_20 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_6 = torch.ops.aten.clone.default(getitem_18)
        silu__default_6 = torch.ops.aten.silu_.default(getitem_18);  getitem_18 = None
        mean_dim_2 = torch.ops.aten.mean.dim(silu__default_6, [2, 3], True)
        convolution_default_11 = torch.ops.aten.convolution.default(mean_dim_2, primals_54, primals_53, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_53 = None
        clone_default_7 = torch.ops.aten.clone.default(convolution_default_11)
        silu__default_7 = torch.ops.aten.silu_.default(convolution_default_11);  convolution_default_11 = None
        convolution_default_12 = torch.ops.aten.convolution.default(silu__default_7, primals_52, primals_51, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_51 = None
        sigmoid_default_2 = torch.ops.aten.sigmoid.default(convolution_default_12);  convolution_default_12 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(silu__default_6, sigmoid_default_2)
        convolution_default_13 = torch.ops.aten.convolution.default(mul_tensor_2, primals_50, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_47, primals_43, primals_45, primals_46, False, 0.1, 0.001);  primals_43 = None
        getitem_21 = native_batch_norm_default_7[0]
        getitem_22 = native_batch_norm_default_7[1]
        getitem_23 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        new_zeros_default_21 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_22 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_23 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_14 = torch.ops.aten.convolution.default(getitem_21, primals_71, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_59, primals_55, primals_57, primals_58, False, 0.1, 0.001);  primals_55 = None
        getitem_24 = native_batch_norm_default_8[0]
        getitem_25 = native_batch_norm_default_8[1]
        getitem_26 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        new_zeros_default_24 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_25 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_26 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_8 = torch.ops.aten.clone.default(getitem_24)
        silu__default_8 = torch.ops.aten.silu_.default(getitem_24);  getitem_24 = None
        convolution_default_15 = torch.ops.aten.convolution.default(silu__default_8, primals_70, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 144)
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_64, primals_60, primals_62, primals_63, False, 0.1, 0.001);  primals_60 = None
        getitem_27 = native_batch_norm_default_9[0]
        getitem_28 = native_batch_norm_default_9[1]
        getitem_29 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        new_zeros_default_27 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_28 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_29 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_9 = torch.ops.aten.clone.default(getitem_27)
        silu__default_9 = torch.ops.aten.silu_.default(getitem_27);  getitem_27 = None
        mean_dim_3 = torch.ops.aten.mean.dim(silu__default_9, [2, 3], True)
        convolution_default_16 = torch.ops.aten.convolution.default(mean_dim_3, primals_76, primals_75, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_75 = None
        clone_default_10 = torch.ops.aten.clone.default(convolution_default_16)
        silu__default_10 = torch.ops.aten.silu_.default(convolution_default_16);  convolution_default_16 = None
        convolution_default_17 = torch.ops.aten.convolution.default(silu__default_10, primals_74, primals_73, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_73 = None
        sigmoid_default_3 = torch.ops.aten.sigmoid.default(convolution_default_17);  convolution_default_17 = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(silu__default_9, sigmoid_default_3)
        convolution_default_18 = torch.ops.aten.convolution.default(mul_tensor_3, primals_72, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_69, primals_65, primals_67, primals_68, False, 0.1, 0.001);  primals_65 = None
        getitem_30 = native_batch_norm_default_10[0]
        getitem_31 = native_batch_norm_default_10[1]
        getitem_32 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        new_zeros_default_30 = torch.ops.aten.new_zeros.default(convolution_default_18, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_31 = torch.ops.aten.new_zeros.default(convolution_default_18, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_32 = torch.ops.aten.new_zeros.default(convolution_default_18, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_1 = torch.ops.aten.add_.Tensor(getitem_30, getitem_21);  getitem_30 = None
        convolution_default_19 = torch.ops.aten.convolution.default(add__tensor_1, primals_93, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_81, primals_77, primals_79, primals_80, False, 0.1, 0.001);  primals_77 = None
        getitem_33 = native_batch_norm_default_11[0]
        getitem_34 = native_batch_norm_default_11[1]
        getitem_35 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        new_zeros_default_33 = torch.ops.aten.new_zeros.default(convolution_default_19, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_34 = torch.ops.aten.new_zeros.default(convolution_default_19, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_35 = torch.ops.aten.new_zeros.default(convolution_default_19, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_11 = torch.ops.aten.clone.default(getitem_33)
        silu__default_11 = torch.ops.aten.silu_.default(getitem_33);  getitem_33 = None
        convolution_default_20 = torch.ops.aten.convolution.default(silu__default_11, primals_92, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 144)
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_86, primals_82, primals_84, primals_85, False, 0.1, 0.001);  primals_82 = None
        getitem_36 = native_batch_norm_default_12[0]
        getitem_37 = native_batch_norm_default_12[1]
        getitem_38 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        new_zeros_default_36 = torch.ops.aten.new_zeros.default(convolution_default_20, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_37 = torch.ops.aten.new_zeros.default(convolution_default_20, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_38 = torch.ops.aten.new_zeros.default(convolution_default_20, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_12 = torch.ops.aten.clone.default(getitem_36)
        silu__default_12 = torch.ops.aten.silu_.default(getitem_36);  getitem_36 = None
        mean_dim_4 = torch.ops.aten.mean.dim(silu__default_12, [2, 3], True)
        convolution_default_21 = torch.ops.aten.convolution.default(mean_dim_4, primals_98, primals_97, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_97 = None
        clone_default_13 = torch.ops.aten.clone.default(convolution_default_21)
        silu__default_13 = torch.ops.aten.silu_.default(convolution_default_21);  convolution_default_21 = None
        convolution_default_22 = torch.ops.aten.convolution.default(silu__default_13, primals_96, primals_95, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_95 = None
        sigmoid_default_4 = torch.ops.aten.sigmoid.default(convolution_default_22);  convolution_default_22 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(silu__default_12, sigmoid_default_4)
        convolution_default_23 = torch.ops.aten.convolution.default(mul_tensor_4, primals_94, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_91, primals_87, primals_89, primals_90, False, 0.1, 0.001);  primals_87 = None
        getitem_39 = native_batch_norm_default_13[0]
        getitem_40 = native_batch_norm_default_13[1]
        getitem_41 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        new_zeros_default_39 = torch.ops.aten.new_zeros.default(convolution_default_23, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_40 = torch.ops.aten.new_zeros.default(convolution_default_23, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_41 = torch.ops.aten.new_zeros.default(convolution_default_23, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_2 = torch.ops.aten.add_.Tensor(getitem_39, add__tensor_1);  getitem_39 = None
        convolution_default_24 = torch.ops.aten.convolution.default(add__tensor_2, primals_115, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_103, primals_99, primals_101, primals_102, False, 0.1, 0.001);  primals_99 = None
        getitem_42 = native_batch_norm_default_14[0]
        getitem_43 = native_batch_norm_default_14[1]
        getitem_44 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        new_zeros_default_42 = torch.ops.aten.new_zeros.default(convolution_default_24, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_43 = torch.ops.aten.new_zeros.default(convolution_default_24, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_44 = torch.ops.aten.new_zeros.default(convolution_default_24, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_14 = torch.ops.aten.clone.default(getitem_42)
        silu__default_14 = torch.ops.aten.silu_.default(getitem_42);  getitem_42 = None
        constant_pad_nd_default_2 = torch.ops.aten.constant_pad_nd.default(silu__default_14, [1, 2, 1, 2], 0.0);  silu__default_14 = None
        convolution_default_25 = torch.ops.aten.convolution.default(constant_pad_nd_default_2, primals_114, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 144)
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_108, primals_104, primals_106, primals_107, False, 0.1, 0.001);  primals_104 = None
        getitem_45 = native_batch_norm_default_15[0]
        getitem_46 = native_batch_norm_default_15[1]
        getitem_47 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        new_zeros_default_45 = torch.ops.aten.new_zeros.default(convolution_default_25, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_46 = torch.ops.aten.new_zeros.default(convolution_default_25, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_47 = torch.ops.aten.new_zeros.default(convolution_default_25, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_15 = torch.ops.aten.clone.default(getitem_45)
        silu__default_15 = torch.ops.aten.silu_.default(getitem_45);  getitem_45 = None
        mean_dim_5 = torch.ops.aten.mean.dim(silu__default_15, [2, 3], True)
        convolution_default_26 = torch.ops.aten.convolution.default(mean_dim_5, primals_120, primals_119, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_119 = None
        clone_default_16 = torch.ops.aten.clone.default(convolution_default_26)
        silu__default_16 = torch.ops.aten.silu_.default(convolution_default_26);  convolution_default_26 = None
        convolution_default_27 = torch.ops.aten.convolution.default(silu__default_16, primals_118, primals_117, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_117 = None
        sigmoid_default_5 = torch.ops.aten.sigmoid.default(convolution_default_27);  convolution_default_27 = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(silu__default_15, sigmoid_default_5)
        convolution_default_28 = torch.ops.aten.convolution.default(mul_tensor_5, primals_116, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_113, primals_109, primals_111, primals_112, False, 0.1, 0.001);  primals_109 = None
        getitem_48 = native_batch_norm_default_16[0]
        getitem_49 = native_batch_norm_default_16[1]
        getitem_50 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        new_zeros_default_48 = torch.ops.aten.new_zeros.default(convolution_default_28, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_49 = torch.ops.aten.new_zeros.default(convolution_default_28, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_50 = torch.ops.aten.new_zeros.default(convolution_default_28, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_29 = torch.ops.aten.convolution.default(getitem_48, primals_137, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_125, primals_121, primals_123, primals_124, False, 0.1, 0.001);  primals_121 = None
        getitem_51 = native_batch_norm_default_17[0]
        getitem_52 = native_batch_norm_default_17[1]
        getitem_53 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        new_zeros_default_51 = torch.ops.aten.new_zeros.default(convolution_default_29, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_52 = torch.ops.aten.new_zeros.default(convolution_default_29, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_53 = torch.ops.aten.new_zeros.default(convolution_default_29, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_17 = torch.ops.aten.clone.default(getitem_51)
        silu__default_17 = torch.ops.aten.silu_.default(getitem_51);  getitem_51 = None
        convolution_default_30 = torch.ops.aten.convolution.default(silu__default_17, primals_136, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 240)
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_130, primals_126, primals_128, primals_129, False, 0.1, 0.001);  primals_126 = None
        getitem_54 = native_batch_norm_default_18[0]
        getitem_55 = native_batch_norm_default_18[1]
        getitem_56 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        new_zeros_default_54 = torch.ops.aten.new_zeros.default(convolution_default_30, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_55 = torch.ops.aten.new_zeros.default(convolution_default_30, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_56 = torch.ops.aten.new_zeros.default(convolution_default_30, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_18 = torch.ops.aten.clone.default(getitem_54)
        silu__default_18 = torch.ops.aten.silu_.default(getitem_54);  getitem_54 = None
        mean_dim_6 = torch.ops.aten.mean.dim(silu__default_18, [2, 3], True)
        convolution_default_31 = torch.ops.aten.convolution.default(mean_dim_6, primals_142, primals_141, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_141 = None
        clone_default_19 = torch.ops.aten.clone.default(convolution_default_31)
        silu__default_19 = torch.ops.aten.silu_.default(convolution_default_31);  convolution_default_31 = None
        convolution_default_32 = torch.ops.aten.convolution.default(silu__default_19, primals_140, primals_139, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_139 = None
        sigmoid_default_6 = torch.ops.aten.sigmoid.default(convolution_default_32);  convolution_default_32 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(silu__default_18, sigmoid_default_6)
        convolution_default_33 = torch.ops.aten.convolution.default(mul_tensor_6, primals_138, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_135, primals_131, primals_133, primals_134, False, 0.1, 0.001);  primals_131 = None
        getitem_57 = native_batch_norm_default_19[0]
        getitem_58 = native_batch_norm_default_19[1]
        getitem_59 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        new_zeros_default_57 = torch.ops.aten.new_zeros.default(convolution_default_33, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_58 = torch.ops.aten.new_zeros.default(convolution_default_33, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_59 = torch.ops.aten.new_zeros.default(convolution_default_33, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_3 = torch.ops.aten.add_.Tensor(getitem_57, getitem_48);  getitem_57 = None
        convolution_default_34 = torch.ops.aten.convolution.default(add__tensor_3, primals_159, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_147, primals_143, primals_145, primals_146, False, 0.1, 0.001);  primals_143 = None
        getitem_60 = native_batch_norm_default_20[0]
        getitem_61 = native_batch_norm_default_20[1]
        getitem_62 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        new_zeros_default_60 = torch.ops.aten.new_zeros.default(convolution_default_34, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_61 = torch.ops.aten.new_zeros.default(convolution_default_34, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_62 = torch.ops.aten.new_zeros.default(convolution_default_34, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_20 = torch.ops.aten.clone.default(getitem_60)
        silu__default_20 = torch.ops.aten.silu_.default(getitem_60);  getitem_60 = None
        convolution_default_35 = torch.ops.aten.convolution.default(silu__default_20, primals_158, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 240)
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_152, primals_148, primals_150, primals_151, False, 0.1, 0.001);  primals_148 = None
        getitem_63 = native_batch_norm_default_21[0]
        getitem_64 = native_batch_norm_default_21[1]
        getitem_65 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        new_zeros_default_63 = torch.ops.aten.new_zeros.default(convolution_default_35, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_64 = torch.ops.aten.new_zeros.default(convolution_default_35, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_65 = torch.ops.aten.new_zeros.default(convolution_default_35, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_21 = torch.ops.aten.clone.default(getitem_63)
        silu__default_21 = torch.ops.aten.silu_.default(getitem_63);  getitem_63 = None
        mean_dim_7 = torch.ops.aten.mean.dim(silu__default_21, [2, 3], True)
        convolution_default_36 = torch.ops.aten.convolution.default(mean_dim_7, primals_164, primals_163, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_163 = None
        clone_default_22 = torch.ops.aten.clone.default(convolution_default_36)
        silu__default_22 = torch.ops.aten.silu_.default(convolution_default_36);  convolution_default_36 = None
        convolution_default_37 = torch.ops.aten.convolution.default(silu__default_22, primals_162, primals_161, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_161 = None
        sigmoid_default_7 = torch.ops.aten.sigmoid.default(convolution_default_37);  convolution_default_37 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(silu__default_21, sigmoid_default_7)
        convolution_default_38 = torch.ops.aten.convolution.default(mul_tensor_7, primals_160, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_157, primals_153, primals_155, primals_156, False, 0.1, 0.001);  primals_153 = None
        getitem_66 = native_batch_norm_default_22[0]
        getitem_67 = native_batch_norm_default_22[1]
        getitem_68 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        new_zeros_default_66 = torch.ops.aten.new_zeros.default(convolution_default_38, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_67 = torch.ops.aten.new_zeros.default(convolution_default_38, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_68 = torch.ops.aten.new_zeros.default(convolution_default_38, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_4 = torch.ops.aten.add_.Tensor(getitem_66, add__tensor_3);  getitem_66 = None
        convolution_default_39 = torch.ops.aten.convolution.default(add__tensor_4, primals_181, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_39, primals_169, primals_165, primals_167, primals_168, False, 0.1, 0.001);  primals_165 = None
        getitem_69 = native_batch_norm_default_23[0]
        getitem_70 = native_batch_norm_default_23[1]
        getitem_71 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        new_zeros_default_69 = torch.ops.aten.new_zeros.default(convolution_default_39, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_70 = torch.ops.aten.new_zeros.default(convolution_default_39, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_71 = torch.ops.aten.new_zeros.default(convolution_default_39, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_23 = torch.ops.aten.clone.default(getitem_69)
        silu__default_23 = torch.ops.aten.silu_.default(getitem_69);  getitem_69 = None
        constant_pad_nd_default_3 = torch.ops.aten.constant_pad_nd.default(silu__default_23, [0, 1, 0, 1], 0.0);  silu__default_23 = None
        convolution_default_40 = torch.ops.aten.convolution.default(constant_pad_nd_default_3, primals_180, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 240)
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_174, primals_170, primals_172, primals_173, False, 0.1, 0.001);  primals_170 = None
        getitem_72 = native_batch_norm_default_24[0]
        getitem_73 = native_batch_norm_default_24[1]
        getitem_74 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        new_zeros_default_72 = torch.ops.aten.new_zeros.default(convolution_default_40, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_73 = torch.ops.aten.new_zeros.default(convolution_default_40, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_74 = torch.ops.aten.new_zeros.default(convolution_default_40, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_24 = torch.ops.aten.clone.default(getitem_72)
        silu__default_24 = torch.ops.aten.silu_.default(getitem_72);  getitem_72 = None
        mean_dim_8 = torch.ops.aten.mean.dim(silu__default_24, [2, 3], True)
        convolution_default_41 = torch.ops.aten.convolution.default(mean_dim_8, primals_186, primals_185, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_185 = None
        clone_default_25 = torch.ops.aten.clone.default(convolution_default_41)
        silu__default_25 = torch.ops.aten.silu_.default(convolution_default_41);  convolution_default_41 = None
        convolution_default_42 = torch.ops.aten.convolution.default(silu__default_25, primals_184, primals_183, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_183 = None
        sigmoid_default_8 = torch.ops.aten.sigmoid.default(convolution_default_42);  convolution_default_42 = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(silu__default_24, sigmoid_default_8)
        convolution_default_43 = torch.ops.aten.convolution.default(mul_tensor_8, primals_182, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_43, primals_179, primals_175, primals_177, primals_178, False, 0.1, 0.001);  primals_175 = None
        getitem_75 = native_batch_norm_default_25[0]
        getitem_76 = native_batch_norm_default_25[1]
        getitem_77 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        new_zeros_default_75 = torch.ops.aten.new_zeros.default(convolution_default_43, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_76 = torch.ops.aten.new_zeros.default(convolution_default_43, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_77 = torch.ops.aten.new_zeros.default(convolution_default_43, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_44 = torch.ops.aten.convolution.default(getitem_75, primals_203, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_191, primals_187, primals_189, primals_190, False, 0.1, 0.001);  primals_187 = None
        getitem_78 = native_batch_norm_default_26[0]
        getitem_79 = native_batch_norm_default_26[1]
        getitem_80 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        new_zeros_default_78 = torch.ops.aten.new_zeros.default(convolution_default_44, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_79 = torch.ops.aten.new_zeros.default(convolution_default_44, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_80 = torch.ops.aten.new_zeros.default(convolution_default_44, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_26 = torch.ops.aten.clone.default(getitem_78)
        silu__default_26 = torch.ops.aten.silu_.default(getitem_78);  getitem_78 = None
        convolution_default_45 = torch.ops.aten.convolution.default(silu__default_26, primals_202, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 480)
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_45, primals_196, primals_192, primals_194, primals_195, False, 0.1, 0.001);  primals_192 = None
        getitem_81 = native_batch_norm_default_27[0]
        getitem_82 = native_batch_norm_default_27[1]
        getitem_83 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        new_zeros_default_81 = torch.ops.aten.new_zeros.default(convolution_default_45, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_82 = torch.ops.aten.new_zeros.default(convolution_default_45, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_83 = torch.ops.aten.new_zeros.default(convolution_default_45, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_27 = torch.ops.aten.clone.default(getitem_81)
        silu__default_27 = torch.ops.aten.silu_.default(getitem_81);  getitem_81 = None
        mean_dim_9 = torch.ops.aten.mean.dim(silu__default_27, [2, 3], True)
        convolution_default_46 = torch.ops.aten.convolution.default(mean_dim_9, primals_208, primals_207, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_207 = None
        clone_default_28 = torch.ops.aten.clone.default(convolution_default_46)
        silu__default_28 = torch.ops.aten.silu_.default(convolution_default_46);  convolution_default_46 = None
        convolution_default_47 = torch.ops.aten.convolution.default(silu__default_28, primals_206, primals_205, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_205 = None
        sigmoid_default_9 = torch.ops.aten.sigmoid.default(convolution_default_47);  convolution_default_47 = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(silu__default_27, sigmoid_default_9)
        convolution_default_48 = torch.ops.aten.convolution.default(mul_tensor_9, primals_204, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_48, primals_201, primals_197, primals_199, primals_200, False, 0.1, 0.001);  primals_197 = None
        getitem_84 = native_batch_norm_default_28[0]
        getitem_85 = native_batch_norm_default_28[1]
        getitem_86 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        new_zeros_default_84 = torch.ops.aten.new_zeros.default(convolution_default_48, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_85 = torch.ops.aten.new_zeros.default(convolution_default_48, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_86 = torch.ops.aten.new_zeros.default(convolution_default_48, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_5 = torch.ops.aten.add_.Tensor(getitem_84, getitem_75);  getitem_84 = None
        convolution_default_49 = torch.ops.aten.convolution.default(add__tensor_5, primals_225, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_49, primals_213, primals_209, primals_211, primals_212, False, 0.1, 0.001);  primals_209 = None
        getitem_87 = native_batch_norm_default_29[0]
        getitem_88 = native_batch_norm_default_29[1]
        getitem_89 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        new_zeros_default_87 = torch.ops.aten.new_zeros.default(convolution_default_49, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_88 = torch.ops.aten.new_zeros.default(convolution_default_49, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_89 = torch.ops.aten.new_zeros.default(convolution_default_49, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_29 = torch.ops.aten.clone.default(getitem_87)
        silu__default_29 = torch.ops.aten.silu_.default(getitem_87);  getitem_87 = None
        convolution_default_50 = torch.ops.aten.convolution.default(silu__default_29, primals_224, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 480)
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_50, primals_218, primals_214, primals_216, primals_217, False, 0.1, 0.001);  primals_214 = None
        getitem_90 = native_batch_norm_default_30[0]
        getitem_91 = native_batch_norm_default_30[1]
        getitem_92 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        new_zeros_default_90 = torch.ops.aten.new_zeros.default(convolution_default_50, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_91 = torch.ops.aten.new_zeros.default(convolution_default_50, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_92 = torch.ops.aten.new_zeros.default(convolution_default_50, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_30 = torch.ops.aten.clone.default(getitem_90)
        silu__default_30 = torch.ops.aten.silu_.default(getitem_90);  getitem_90 = None
        mean_dim_10 = torch.ops.aten.mean.dim(silu__default_30, [2, 3], True)
        convolution_default_51 = torch.ops.aten.convolution.default(mean_dim_10, primals_230, primals_229, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_229 = None
        clone_default_31 = torch.ops.aten.clone.default(convolution_default_51)
        silu__default_31 = torch.ops.aten.silu_.default(convolution_default_51);  convolution_default_51 = None
        convolution_default_52 = torch.ops.aten.convolution.default(silu__default_31, primals_228, primals_227, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_227 = None
        sigmoid_default_10 = torch.ops.aten.sigmoid.default(convolution_default_52);  convolution_default_52 = None
        mul_tensor_10 = torch.ops.aten.mul.Tensor(silu__default_30, sigmoid_default_10)
        convolution_default_53 = torch.ops.aten.convolution.default(mul_tensor_10, primals_226, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_53, primals_223, primals_219, primals_221, primals_222, False, 0.1, 0.001);  primals_219 = None
        getitem_93 = native_batch_norm_default_31[0]
        getitem_94 = native_batch_norm_default_31[1]
        getitem_95 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        new_zeros_default_93 = torch.ops.aten.new_zeros.default(convolution_default_53, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_94 = torch.ops.aten.new_zeros.default(convolution_default_53, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_95 = torch.ops.aten.new_zeros.default(convolution_default_53, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_6 = torch.ops.aten.add_.Tensor(getitem_93, add__tensor_5);  getitem_93 = None
        convolution_default_54 = torch.ops.aten.convolution.default(add__tensor_6, primals_247, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_54, primals_235, primals_231, primals_233, primals_234, False, 0.1, 0.001);  primals_231 = None
        getitem_96 = native_batch_norm_default_32[0]
        getitem_97 = native_batch_norm_default_32[1]
        getitem_98 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        new_zeros_default_96 = torch.ops.aten.new_zeros.default(convolution_default_54, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_97 = torch.ops.aten.new_zeros.default(convolution_default_54, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_98 = torch.ops.aten.new_zeros.default(convolution_default_54, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_32 = torch.ops.aten.clone.default(getitem_96)
        silu__default_32 = torch.ops.aten.silu_.default(getitem_96);  getitem_96 = None
        convolution_default_55 = torch.ops.aten.convolution.default(silu__default_32, primals_246, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 480)
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_55, primals_240, primals_236, primals_238, primals_239, False, 0.1, 0.001);  primals_236 = None
        getitem_99 = native_batch_norm_default_33[0]
        getitem_100 = native_batch_norm_default_33[1]
        getitem_101 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        new_zeros_default_99 = torch.ops.aten.new_zeros.default(convolution_default_55, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_100 = torch.ops.aten.new_zeros.default(convolution_default_55, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_101 = torch.ops.aten.new_zeros.default(convolution_default_55, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_33 = torch.ops.aten.clone.default(getitem_99)
        silu__default_33 = torch.ops.aten.silu_.default(getitem_99);  getitem_99 = None
        mean_dim_11 = torch.ops.aten.mean.dim(silu__default_33, [2, 3], True)
        convolution_default_56 = torch.ops.aten.convolution.default(mean_dim_11, primals_252, primals_251, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_251 = None
        clone_default_34 = torch.ops.aten.clone.default(convolution_default_56)
        silu__default_34 = torch.ops.aten.silu_.default(convolution_default_56);  convolution_default_56 = None
        convolution_default_57 = torch.ops.aten.convolution.default(silu__default_34, primals_250, primals_249, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_249 = None
        sigmoid_default_11 = torch.ops.aten.sigmoid.default(convolution_default_57);  convolution_default_57 = None
        mul_tensor_11 = torch.ops.aten.mul.Tensor(silu__default_33, sigmoid_default_11)
        convolution_default_58 = torch.ops.aten.convolution.default(mul_tensor_11, primals_248, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_58, primals_245, primals_241, primals_243, primals_244, False, 0.1, 0.001);  primals_241 = None
        getitem_102 = native_batch_norm_default_34[0]
        getitem_103 = native_batch_norm_default_34[1]
        getitem_104 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        new_zeros_default_102 = torch.ops.aten.new_zeros.default(convolution_default_58, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_103 = torch.ops.aten.new_zeros.default(convolution_default_58, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_104 = torch.ops.aten.new_zeros.default(convolution_default_58, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_7 = torch.ops.aten.add_.Tensor(getitem_102, add__tensor_6);  getitem_102 = None
        convolution_default_59 = torch.ops.aten.convolution.default(add__tensor_7, primals_269, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_59, primals_257, primals_253, primals_255, primals_256, False, 0.1, 0.001);  primals_253 = None
        getitem_105 = native_batch_norm_default_35[0]
        getitem_106 = native_batch_norm_default_35[1]
        getitem_107 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        new_zeros_default_105 = torch.ops.aten.new_zeros.default(convolution_default_59, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_106 = torch.ops.aten.new_zeros.default(convolution_default_59, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_107 = torch.ops.aten.new_zeros.default(convolution_default_59, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_35 = torch.ops.aten.clone.default(getitem_105)
        silu__default_35 = torch.ops.aten.silu_.default(getitem_105);  getitem_105 = None
        convolution_default_60 = torch.ops.aten.convolution.default(silu__default_35, primals_268, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 480)
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_60, primals_262, primals_258, primals_260, primals_261, False, 0.1, 0.001);  primals_258 = None
        getitem_108 = native_batch_norm_default_36[0]
        getitem_109 = native_batch_norm_default_36[1]
        getitem_110 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        new_zeros_default_108 = torch.ops.aten.new_zeros.default(convolution_default_60, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_109 = torch.ops.aten.new_zeros.default(convolution_default_60, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_110 = torch.ops.aten.new_zeros.default(convolution_default_60, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_36 = torch.ops.aten.clone.default(getitem_108)
        silu__default_36 = torch.ops.aten.silu_.default(getitem_108);  getitem_108 = None
        mean_dim_12 = torch.ops.aten.mean.dim(silu__default_36, [2, 3], True)
        convolution_default_61 = torch.ops.aten.convolution.default(mean_dim_12, primals_274, primals_273, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_273 = None
        clone_default_37 = torch.ops.aten.clone.default(convolution_default_61)
        silu__default_37 = torch.ops.aten.silu_.default(convolution_default_61);  convolution_default_61 = None
        convolution_default_62 = torch.ops.aten.convolution.default(silu__default_37, primals_272, primals_271, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_271 = None
        sigmoid_default_12 = torch.ops.aten.sigmoid.default(convolution_default_62);  convolution_default_62 = None
        mul_tensor_12 = torch.ops.aten.mul.Tensor(silu__default_36, sigmoid_default_12)
        convolution_default_63 = torch.ops.aten.convolution.default(mul_tensor_12, primals_270, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_63, primals_267, primals_263, primals_265, primals_266, False, 0.1, 0.001);  primals_263 = None
        getitem_111 = native_batch_norm_default_37[0]
        getitem_112 = native_batch_norm_default_37[1]
        getitem_113 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        new_zeros_default_111 = torch.ops.aten.new_zeros.default(convolution_default_63, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_112 = torch.ops.aten.new_zeros.default(convolution_default_63, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_113 = torch.ops.aten.new_zeros.default(convolution_default_63, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_64 = torch.ops.aten.convolution.default(getitem_111, primals_291, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_64, primals_279, primals_275, primals_277, primals_278, False, 0.1, 0.001);  primals_275 = None
        getitem_114 = native_batch_norm_default_38[0]
        getitem_115 = native_batch_norm_default_38[1]
        getitem_116 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        new_zeros_default_114 = torch.ops.aten.new_zeros.default(convolution_default_64, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_115 = torch.ops.aten.new_zeros.default(convolution_default_64, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_116 = torch.ops.aten.new_zeros.default(convolution_default_64, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_38 = torch.ops.aten.clone.default(getitem_114)
        silu__default_38 = torch.ops.aten.silu_.default(getitem_114);  getitem_114 = None
        convolution_default_65 = torch.ops.aten.convolution.default(silu__default_38, primals_290, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 672)
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_65, primals_284, primals_280, primals_282, primals_283, False, 0.1, 0.001);  primals_280 = None
        getitem_117 = native_batch_norm_default_39[0]
        getitem_118 = native_batch_norm_default_39[1]
        getitem_119 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        new_zeros_default_117 = torch.ops.aten.new_zeros.default(convolution_default_65, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_118 = torch.ops.aten.new_zeros.default(convolution_default_65, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_119 = torch.ops.aten.new_zeros.default(convolution_default_65, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_39 = torch.ops.aten.clone.default(getitem_117)
        silu__default_39 = torch.ops.aten.silu_.default(getitem_117);  getitem_117 = None
        mean_dim_13 = torch.ops.aten.mean.dim(silu__default_39, [2, 3], True)
        convolution_default_66 = torch.ops.aten.convolution.default(mean_dim_13, primals_296, primals_295, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_295 = None
        clone_default_40 = torch.ops.aten.clone.default(convolution_default_66)
        silu__default_40 = torch.ops.aten.silu_.default(convolution_default_66);  convolution_default_66 = None
        convolution_default_67 = torch.ops.aten.convolution.default(silu__default_40, primals_294, primals_293, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_293 = None
        sigmoid_default_13 = torch.ops.aten.sigmoid.default(convolution_default_67);  convolution_default_67 = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(silu__default_39, sigmoid_default_13)
        convolution_default_68 = torch.ops.aten.convolution.default(mul_tensor_13, primals_292, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_68, primals_289, primals_285, primals_287, primals_288, False, 0.1, 0.001);  primals_285 = None
        getitem_120 = native_batch_norm_default_40[0]
        getitem_121 = native_batch_norm_default_40[1]
        getitem_122 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        new_zeros_default_120 = torch.ops.aten.new_zeros.default(convolution_default_68, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_121 = torch.ops.aten.new_zeros.default(convolution_default_68, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_122 = torch.ops.aten.new_zeros.default(convolution_default_68, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_8 = torch.ops.aten.add_.Tensor(getitem_120, getitem_111);  getitem_120 = None
        convolution_default_69 = torch.ops.aten.convolution.default(add__tensor_8, primals_313, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_69, primals_301, primals_297, primals_299, primals_300, False, 0.1, 0.001);  primals_297 = None
        getitem_123 = native_batch_norm_default_41[0]
        getitem_124 = native_batch_norm_default_41[1]
        getitem_125 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        new_zeros_default_123 = torch.ops.aten.new_zeros.default(convolution_default_69, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_124 = torch.ops.aten.new_zeros.default(convolution_default_69, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_125 = torch.ops.aten.new_zeros.default(convolution_default_69, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_41 = torch.ops.aten.clone.default(getitem_123)
        silu__default_41 = torch.ops.aten.silu_.default(getitem_123);  getitem_123 = None
        convolution_default_70 = torch.ops.aten.convolution.default(silu__default_41, primals_312, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 672)
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_70, primals_306, primals_302, primals_304, primals_305, False, 0.1, 0.001);  primals_302 = None
        getitem_126 = native_batch_norm_default_42[0]
        getitem_127 = native_batch_norm_default_42[1]
        getitem_128 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        new_zeros_default_126 = torch.ops.aten.new_zeros.default(convolution_default_70, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_127 = torch.ops.aten.new_zeros.default(convolution_default_70, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_128 = torch.ops.aten.new_zeros.default(convolution_default_70, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_42 = torch.ops.aten.clone.default(getitem_126)
        silu__default_42 = torch.ops.aten.silu_.default(getitem_126);  getitem_126 = None
        mean_dim_14 = torch.ops.aten.mean.dim(silu__default_42, [2, 3], True)
        convolution_default_71 = torch.ops.aten.convolution.default(mean_dim_14, primals_318, primals_317, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_317 = None
        clone_default_43 = torch.ops.aten.clone.default(convolution_default_71)
        silu__default_43 = torch.ops.aten.silu_.default(convolution_default_71);  convolution_default_71 = None
        convolution_default_72 = torch.ops.aten.convolution.default(silu__default_43, primals_316, primals_315, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_315 = None
        sigmoid_default_14 = torch.ops.aten.sigmoid.default(convolution_default_72);  convolution_default_72 = None
        mul_tensor_14 = torch.ops.aten.mul.Tensor(silu__default_42, sigmoid_default_14)
        convolution_default_73 = torch.ops.aten.convolution.default(mul_tensor_14, primals_314, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_73, primals_311, primals_307, primals_309, primals_310, False, 0.1, 0.001);  primals_307 = None
        getitem_129 = native_batch_norm_default_43[0]
        getitem_130 = native_batch_norm_default_43[1]
        getitem_131 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        new_zeros_default_129 = torch.ops.aten.new_zeros.default(convolution_default_73, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_130 = torch.ops.aten.new_zeros.default(convolution_default_73, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_131 = torch.ops.aten.new_zeros.default(convolution_default_73, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_9 = torch.ops.aten.add_.Tensor(getitem_129, add__tensor_8);  getitem_129 = None
        convolution_default_74 = torch.ops.aten.convolution.default(add__tensor_9, primals_335, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_74, primals_323, primals_319, primals_321, primals_322, False, 0.1, 0.001);  primals_319 = None
        getitem_132 = native_batch_norm_default_44[0]
        getitem_133 = native_batch_norm_default_44[1]
        getitem_134 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        new_zeros_default_132 = torch.ops.aten.new_zeros.default(convolution_default_74, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_133 = torch.ops.aten.new_zeros.default(convolution_default_74, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_134 = torch.ops.aten.new_zeros.default(convolution_default_74, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_44 = torch.ops.aten.clone.default(getitem_132)
        silu__default_44 = torch.ops.aten.silu_.default(getitem_132);  getitem_132 = None
        convolution_default_75 = torch.ops.aten.convolution.default(silu__default_44, primals_334, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 672)
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_75, primals_328, primals_324, primals_326, primals_327, False, 0.1, 0.001);  primals_324 = None
        getitem_135 = native_batch_norm_default_45[0]
        getitem_136 = native_batch_norm_default_45[1]
        getitem_137 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        new_zeros_default_135 = torch.ops.aten.new_zeros.default(convolution_default_75, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_136 = torch.ops.aten.new_zeros.default(convolution_default_75, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_137 = torch.ops.aten.new_zeros.default(convolution_default_75, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_45 = torch.ops.aten.clone.default(getitem_135)
        silu__default_45 = torch.ops.aten.silu_.default(getitem_135);  getitem_135 = None
        mean_dim_15 = torch.ops.aten.mean.dim(silu__default_45, [2, 3], True)
        convolution_default_76 = torch.ops.aten.convolution.default(mean_dim_15, primals_340, primals_339, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_339 = None
        clone_default_46 = torch.ops.aten.clone.default(convolution_default_76)
        silu__default_46 = torch.ops.aten.silu_.default(convolution_default_76);  convolution_default_76 = None
        convolution_default_77 = torch.ops.aten.convolution.default(silu__default_46, primals_338, primals_337, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_337 = None
        sigmoid_default_15 = torch.ops.aten.sigmoid.default(convolution_default_77);  convolution_default_77 = None
        mul_tensor_15 = torch.ops.aten.mul.Tensor(silu__default_45, sigmoid_default_15)
        convolution_default_78 = torch.ops.aten.convolution.default(mul_tensor_15, primals_336, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(convolution_default_78, primals_333, primals_329, primals_331, primals_332, False, 0.1, 0.001);  primals_329 = None
        getitem_138 = native_batch_norm_default_46[0]
        getitem_139 = native_batch_norm_default_46[1]
        getitem_140 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        new_zeros_default_138 = torch.ops.aten.new_zeros.default(convolution_default_78, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_139 = torch.ops.aten.new_zeros.default(convolution_default_78, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_140 = torch.ops.aten.new_zeros.default(convolution_default_78, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_10 = torch.ops.aten.add_.Tensor(getitem_138, add__tensor_9);  getitem_138 = None
        convolution_default_79 = torch.ops.aten.convolution.default(add__tensor_10, primals_357, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(convolution_default_79, primals_345, primals_341, primals_343, primals_344, False, 0.1, 0.001);  primals_341 = None
        getitem_141 = native_batch_norm_default_47[0]
        getitem_142 = native_batch_norm_default_47[1]
        getitem_143 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        new_zeros_default_141 = torch.ops.aten.new_zeros.default(convolution_default_79, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_142 = torch.ops.aten.new_zeros.default(convolution_default_79, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_143 = torch.ops.aten.new_zeros.default(convolution_default_79, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_47 = torch.ops.aten.clone.default(getitem_141)
        silu__default_47 = torch.ops.aten.silu_.default(getitem_141);  getitem_141 = None
        constant_pad_nd_default_4 = torch.ops.aten.constant_pad_nd.default(silu__default_47, [1, 2, 1, 2], 0.0);  silu__default_47 = None
        convolution_default_80 = torch.ops.aten.convolution.default(constant_pad_nd_default_4, primals_356, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 672)
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_80, primals_350, primals_346, primals_348, primals_349, False, 0.1, 0.001);  primals_346 = None
        getitem_144 = native_batch_norm_default_48[0]
        getitem_145 = native_batch_norm_default_48[1]
        getitem_146 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        new_zeros_default_144 = torch.ops.aten.new_zeros.default(convolution_default_80, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_145 = torch.ops.aten.new_zeros.default(convolution_default_80, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_146 = torch.ops.aten.new_zeros.default(convolution_default_80, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_48 = torch.ops.aten.clone.default(getitem_144)
        silu__default_48 = torch.ops.aten.silu_.default(getitem_144);  getitem_144 = None
        mean_dim_16 = torch.ops.aten.mean.dim(silu__default_48, [2, 3], True)
        convolution_default_81 = torch.ops.aten.convolution.default(mean_dim_16, primals_362, primals_361, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_361 = None
        clone_default_49 = torch.ops.aten.clone.default(convolution_default_81)
        silu__default_49 = torch.ops.aten.silu_.default(convolution_default_81);  convolution_default_81 = None
        convolution_default_82 = torch.ops.aten.convolution.default(silu__default_49, primals_360, primals_359, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_359 = None
        sigmoid_default_16 = torch.ops.aten.sigmoid.default(convolution_default_82);  convolution_default_82 = None
        mul_tensor_16 = torch.ops.aten.mul.Tensor(silu__default_48, sigmoid_default_16)
        convolution_default_83 = torch.ops.aten.convolution.default(mul_tensor_16, primals_358, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(convolution_default_83, primals_355, primals_351, primals_353, primals_354, False, 0.1, 0.001);  primals_351 = None
        getitem_147 = native_batch_norm_default_49[0]
        getitem_148 = native_batch_norm_default_49[1]
        getitem_149 = native_batch_norm_default_49[2];  native_batch_norm_default_49 = None
        new_zeros_default_147 = torch.ops.aten.new_zeros.default(convolution_default_83, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_148 = torch.ops.aten.new_zeros.default(convolution_default_83, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_149 = torch.ops.aten.new_zeros.default(convolution_default_83, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_84 = torch.ops.aten.convolution.default(getitem_147, primals_379, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(convolution_default_84, primals_367, primals_363, primals_365, primals_366, False, 0.1, 0.001);  primals_363 = None
        getitem_150 = native_batch_norm_default_50[0]
        getitem_151 = native_batch_norm_default_50[1]
        getitem_152 = native_batch_norm_default_50[2];  native_batch_norm_default_50 = None
        new_zeros_default_150 = torch.ops.aten.new_zeros.default(convolution_default_84, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_151 = torch.ops.aten.new_zeros.default(convolution_default_84, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_152 = torch.ops.aten.new_zeros.default(convolution_default_84, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_50 = torch.ops.aten.clone.default(getitem_150)
        silu__default_50 = torch.ops.aten.silu_.default(getitem_150);  getitem_150 = None
        convolution_default_85 = torch.ops.aten.convolution.default(silu__default_50, primals_378, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 1152)
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(convolution_default_85, primals_372, primals_368, primals_370, primals_371, False, 0.1, 0.001);  primals_368 = None
        getitem_153 = native_batch_norm_default_51[0]
        getitem_154 = native_batch_norm_default_51[1]
        getitem_155 = native_batch_norm_default_51[2];  native_batch_norm_default_51 = None
        new_zeros_default_153 = torch.ops.aten.new_zeros.default(convolution_default_85, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_154 = torch.ops.aten.new_zeros.default(convolution_default_85, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_155 = torch.ops.aten.new_zeros.default(convolution_default_85, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_51 = torch.ops.aten.clone.default(getitem_153)
        silu__default_51 = torch.ops.aten.silu_.default(getitem_153);  getitem_153 = None
        mean_dim_17 = torch.ops.aten.mean.dim(silu__default_51, [2, 3], True)
        convolution_default_86 = torch.ops.aten.convolution.default(mean_dim_17, primals_384, primals_383, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_383 = None
        clone_default_52 = torch.ops.aten.clone.default(convolution_default_86)
        silu__default_52 = torch.ops.aten.silu_.default(convolution_default_86);  convolution_default_86 = None
        convolution_default_87 = torch.ops.aten.convolution.default(silu__default_52, primals_382, primals_381, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_381 = None
        sigmoid_default_17 = torch.ops.aten.sigmoid.default(convolution_default_87);  convolution_default_87 = None
        mul_tensor_17 = torch.ops.aten.mul.Tensor(silu__default_51, sigmoid_default_17)
        convolution_default_88 = torch.ops.aten.convolution.default(mul_tensor_17, primals_380, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(convolution_default_88, primals_377, primals_373, primals_375, primals_376, False, 0.1, 0.001);  primals_373 = None
        getitem_156 = native_batch_norm_default_52[0]
        getitem_157 = native_batch_norm_default_52[1]
        getitem_158 = native_batch_norm_default_52[2];  native_batch_norm_default_52 = None
        new_zeros_default_156 = torch.ops.aten.new_zeros.default(convolution_default_88, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_157 = torch.ops.aten.new_zeros.default(convolution_default_88, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_158 = torch.ops.aten.new_zeros.default(convolution_default_88, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_11 = torch.ops.aten.add_.Tensor(getitem_156, getitem_147);  getitem_156 = None
        convolution_default_89 = torch.ops.aten.convolution.default(add__tensor_11, primals_401, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_53 = torch.ops.aten.native_batch_norm.default(convolution_default_89, primals_389, primals_385, primals_387, primals_388, False, 0.1, 0.001);  primals_385 = None
        getitem_159 = native_batch_norm_default_53[0]
        getitem_160 = native_batch_norm_default_53[1]
        getitem_161 = native_batch_norm_default_53[2];  native_batch_norm_default_53 = None
        new_zeros_default_159 = torch.ops.aten.new_zeros.default(convolution_default_89, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_160 = torch.ops.aten.new_zeros.default(convolution_default_89, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_161 = torch.ops.aten.new_zeros.default(convolution_default_89, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_53 = torch.ops.aten.clone.default(getitem_159)
        silu__default_53 = torch.ops.aten.silu_.default(getitem_159);  getitem_159 = None
        convolution_default_90 = torch.ops.aten.convolution.default(silu__default_53, primals_400, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 1152)
        native_batch_norm_default_54 = torch.ops.aten.native_batch_norm.default(convolution_default_90, primals_394, primals_390, primals_392, primals_393, False, 0.1, 0.001);  primals_390 = None
        getitem_162 = native_batch_norm_default_54[0]
        getitem_163 = native_batch_norm_default_54[1]
        getitem_164 = native_batch_norm_default_54[2];  native_batch_norm_default_54 = None
        new_zeros_default_162 = torch.ops.aten.new_zeros.default(convolution_default_90, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_163 = torch.ops.aten.new_zeros.default(convolution_default_90, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_164 = torch.ops.aten.new_zeros.default(convolution_default_90, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_54 = torch.ops.aten.clone.default(getitem_162)
        silu__default_54 = torch.ops.aten.silu_.default(getitem_162);  getitem_162 = None
        mean_dim_18 = torch.ops.aten.mean.dim(silu__default_54, [2, 3], True)
        convolution_default_91 = torch.ops.aten.convolution.default(mean_dim_18, primals_406, primals_405, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_405 = None
        clone_default_55 = torch.ops.aten.clone.default(convolution_default_91)
        silu__default_55 = torch.ops.aten.silu_.default(convolution_default_91);  convolution_default_91 = None
        convolution_default_92 = torch.ops.aten.convolution.default(silu__default_55, primals_404, primals_403, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_403 = None
        sigmoid_default_18 = torch.ops.aten.sigmoid.default(convolution_default_92);  convolution_default_92 = None
        mul_tensor_18 = torch.ops.aten.mul.Tensor(silu__default_54, sigmoid_default_18)
        convolution_default_93 = torch.ops.aten.convolution.default(mul_tensor_18, primals_402, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_55 = torch.ops.aten.native_batch_norm.default(convolution_default_93, primals_399, primals_395, primals_397, primals_398, False, 0.1, 0.001);  primals_395 = None
        getitem_165 = native_batch_norm_default_55[0]
        getitem_166 = native_batch_norm_default_55[1]
        getitem_167 = native_batch_norm_default_55[2];  native_batch_norm_default_55 = None
        new_zeros_default_165 = torch.ops.aten.new_zeros.default(convolution_default_93, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_166 = torch.ops.aten.new_zeros.default(convolution_default_93, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_167 = torch.ops.aten.new_zeros.default(convolution_default_93, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_12 = torch.ops.aten.add_.Tensor(getitem_165, add__tensor_11);  getitem_165 = None
        convolution_default_94 = torch.ops.aten.convolution.default(add__tensor_12, primals_423, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_56 = torch.ops.aten.native_batch_norm.default(convolution_default_94, primals_411, primals_407, primals_409, primals_410, False, 0.1, 0.001);  primals_407 = None
        getitem_168 = native_batch_norm_default_56[0]
        getitem_169 = native_batch_norm_default_56[1]
        getitem_170 = native_batch_norm_default_56[2];  native_batch_norm_default_56 = None
        new_zeros_default_168 = torch.ops.aten.new_zeros.default(convolution_default_94, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_169 = torch.ops.aten.new_zeros.default(convolution_default_94, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_170 = torch.ops.aten.new_zeros.default(convolution_default_94, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_56 = torch.ops.aten.clone.default(getitem_168)
        silu__default_56 = torch.ops.aten.silu_.default(getitem_168);  getitem_168 = None
        convolution_default_95 = torch.ops.aten.convolution.default(silu__default_56, primals_422, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 1152)
        native_batch_norm_default_57 = torch.ops.aten.native_batch_norm.default(convolution_default_95, primals_416, primals_412, primals_414, primals_415, False, 0.1, 0.001);  primals_412 = None
        getitem_171 = native_batch_norm_default_57[0]
        getitem_172 = native_batch_norm_default_57[1]
        getitem_173 = native_batch_norm_default_57[2];  native_batch_norm_default_57 = None
        new_zeros_default_171 = torch.ops.aten.new_zeros.default(convolution_default_95, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_172 = torch.ops.aten.new_zeros.default(convolution_default_95, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_173 = torch.ops.aten.new_zeros.default(convolution_default_95, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_57 = torch.ops.aten.clone.default(getitem_171)
        silu__default_57 = torch.ops.aten.silu_.default(getitem_171);  getitem_171 = None
        mean_dim_19 = torch.ops.aten.mean.dim(silu__default_57, [2, 3], True)
        convolution_default_96 = torch.ops.aten.convolution.default(mean_dim_19, primals_428, primals_427, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_427 = None
        clone_default_58 = torch.ops.aten.clone.default(convolution_default_96)
        silu__default_58 = torch.ops.aten.silu_.default(convolution_default_96);  convolution_default_96 = None
        convolution_default_97 = torch.ops.aten.convolution.default(silu__default_58, primals_426, primals_425, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_425 = None
        sigmoid_default_19 = torch.ops.aten.sigmoid.default(convolution_default_97);  convolution_default_97 = None
        mul_tensor_19 = torch.ops.aten.mul.Tensor(silu__default_57, sigmoid_default_19)
        convolution_default_98 = torch.ops.aten.convolution.default(mul_tensor_19, primals_424, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_58 = torch.ops.aten.native_batch_norm.default(convolution_default_98, primals_421, primals_417, primals_419, primals_420, False, 0.1, 0.001);  primals_417 = None
        getitem_174 = native_batch_norm_default_58[0]
        getitem_175 = native_batch_norm_default_58[1]
        getitem_176 = native_batch_norm_default_58[2];  native_batch_norm_default_58 = None
        new_zeros_default_174 = torch.ops.aten.new_zeros.default(convolution_default_98, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_175 = torch.ops.aten.new_zeros.default(convolution_default_98, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_176 = torch.ops.aten.new_zeros.default(convolution_default_98, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_13 = torch.ops.aten.add_.Tensor(getitem_174, add__tensor_12);  getitem_174 = None
        convolution_default_99 = torch.ops.aten.convolution.default(add__tensor_13, primals_445, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_59 = torch.ops.aten.native_batch_norm.default(convolution_default_99, primals_433, primals_429, primals_431, primals_432, False, 0.1, 0.001);  primals_429 = None
        getitem_177 = native_batch_norm_default_59[0]
        getitem_178 = native_batch_norm_default_59[1]
        getitem_179 = native_batch_norm_default_59[2];  native_batch_norm_default_59 = None
        new_zeros_default_177 = torch.ops.aten.new_zeros.default(convolution_default_99, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_178 = torch.ops.aten.new_zeros.default(convolution_default_99, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_179 = torch.ops.aten.new_zeros.default(convolution_default_99, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_59 = torch.ops.aten.clone.default(getitem_177)
        silu__default_59 = torch.ops.aten.silu_.default(getitem_177);  getitem_177 = None
        convolution_default_100 = torch.ops.aten.convolution.default(silu__default_59, primals_444, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 1152)
        native_batch_norm_default_60 = torch.ops.aten.native_batch_norm.default(convolution_default_100, primals_438, primals_434, primals_436, primals_437, False, 0.1, 0.001);  primals_434 = None
        getitem_180 = native_batch_norm_default_60[0]
        getitem_181 = native_batch_norm_default_60[1]
        getitem_182 = native_batch_norm_default_60[2];  native_batch_norm_default_60 = None
        new_zeros_default_180 = torch.ops.aten.new_zeros.default(convolution_default_100, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_181 = torch.ops.aten.new_zeros.default(convolution_default_100, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_182 = torch.ops.aten.new_zeros.default(convolution_default_100, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_60 = torch.ops.aten.clone.default(getitem_180)
        silu__default_60 = torch.ops.aten.silu_.default(getitem_180);  getitem_180 = None
        mean_dim_20 = torch.ops.aten.mean.dim(silu__default_60, [2, 3], True)
        convolution_default_101 = torch.ops.aten.convolution.default(mean_dim_20, primals_450, primals_449, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_449 = None
        clone_default_61 = torch.ops.aten.clone.default(convolution_default_101)
        silu__default_61 = torch.ops.aten.silu_.default(convolution_default_101);  convolution_default_101 = None
        convolution_default_102 = torch.ops.aten.convolution.default(silu__default_61, primals_448, primals_447, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_447 = None
        sigmoid_default_20 = torch.ops.aten.sigmoid.default(convolution_default_102);  convolution_default_102 = None
        mul_tensor_20 = torch.ops.aten.mul.Tensor(silu__default_60, sigmoid_default_20)
        convolution_default_103 = torch.ops.aten.convolution.default(mul_tensor_20, primals_446, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_61 = torch.ops.aten.native_batch_norm.default(convolution_default_103, primals_443, primals_439, primals_441, primals_442, False, 0.1, 0.001);  primals_439 = None
        getitem_183 = native_batch_norm_default_61[0]
        getitem_184 = native_batch_norm_default_61[1]
        getitem_185 = native_batch_norm_default_61[2];  native_batch_norm_default_61 = None
        new_zeros_default_183 = torch.ops.aten.new_zeros.default(convolution_default_103, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_184 = torch.ops.aten.new_zeros.default(convolution_default_103, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_185 = torch.ops.aten.new_zeros.default(convolution_default_103, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_14 = torch.ops.aten.add_.Tensor(getitem_183, add__tensor_13);  getitem_183 = None
        convolution_default_104 = torch.ops.aten.convolution.default(add__tensor_14, primals_467, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_62 = torch.ops.aten.native_batch_norm.default(convolution_default_104, primals_455, primals_451, primals_453, primals_454, False, 0.1, 0.001);  primals_451 = None
        getitem_186 = native_batch_norm_default_62[0]
        getitem_187 = native_batch_norm_default_62[1]
        getitem_188 = native_batch_norm_default_62[2];  native_batch_norm_default_62 = None
        new_zeros_default_186 = torch.ops.aten.new_zeros.default(convolution_default_104, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_187 = torch.ops.aten.new_zeros.default(convolution_default_104, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_188 = torch.ops.aten.new_zeros.default(convolution_default_104, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_62 = torch.ops.aten.clone.default(getitem_186)
        silu__default_62 = torch.ops.aten.silu_.default(getitem_186);  getitem_186 = None
        convolution_default_105 = torch.ops.aten.convolution.default(silu__default_62, primals_466, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1152)
        native_batch_norm_default_63 = torch.ops.aten.native_batch_norm.default(convolution_default_105, primals_460, primals_456, primals_458, primals_459, False, 0.1, 0.001);  primals_456 = None
        getitem_189 = native_batch_norm_default_63[0]
        getitem_190 = native_batch_norm_default_63[1]
        getitem_191 = native_batch_norm_default_63[2];  native_batch_norm_default_63 = None
        new_zeros_default_189 = torch.ops.aten.new_zeros.default(convolution_default_105, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_190 = torch.ops.aten.new_zeros.default(convolution_default_105, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_191 = torch.ops.aten.new_zeros.default(convolution_default_105, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_63 = torch.ops.aten.clone.default(getitem_189)
        silu__default_63 = torch.ops.aten.silu_.default(getitem_189);  getitem_189 = None
        mean_dim_21 = torch.ops.aten.mean.dim(silu__default_63, [2, 3], True)
        convolution_default_106 = torch.ops.aten.convolution.default(mean_dim_21, primals_472, primals_471, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_471 = None
        clone_default_64 = torch.ops.aten.clone.default(convolution_default_106)
        silu__default_64 = torch.ops.aten.silu_.default(convolution_default_106);  convolution_default_106 = None
        convolution_default_107 = torch.ops.aten.convolution.default(silu__default_64, primals_470, primals_469, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_469 = None
        sigmoid_default_21 = torch.ops.aten.sigmoid.default(convolution_default_107);  convolution_default_107 = None
        mul_tensor_21 = torch.ops.aten.mul.Tensor(silu__default_63, sigmoid_default_21)
        convolution_default_108 = torch.ops.aten.convolution.default(mul_tensor_21, primals_468, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_64 = torch.ops.aten.native_batch_norm.default(convolution_default_108, primals_465, primals_461, primals_463, primals_464, False, 0.1, 0.001);  primals_461 = None
        getitem_192 = native_batch_norm_default_64[0]
        getitem_193 = native_batch_norm_default_64[1]
        getitem_194 = native_batch_norm_default_64[2];  native_batch_norm_default_64 = None
        new_zeros_default_192 = torch.ops.aten.new_zeros.default(convolution_default_108, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_193 = torch.ops.aten.new_zeros.default(convolution_default_108, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_194 = torch.ops.aten.new_zeros.default(convolution_default_108, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_109 = torch.ops.aten.convolution.default(getitem_192, primals_489, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_65 = torch.ops.aten.native_batch_norm.default(convolution_default_109, primals_477, primals_473, primals_475, primals_476, False, 0.1, 0.001);  primals_473 = None
        getitem_195 = native_batch_norm_default_65[0]
        getitem_196 = native_batch_norm_default_65[1]
        getitem_197 = native_batch_norm_default_65[2];  native_batch_norm_default_65 = None
        new_zeros_default_195 = torch.ops.aten.new_zeros.default(convolution_default_109, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_196 = torch.ops.aten.new_zeros.default(convolution_default_109, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_197 = torch.ops.aten.new_zeros.default(convolution_default_109, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_65 = torch.ops.aten.clone.default(getitem_195)
        silu__default_65 = torch.ops.aten.silu_.default(getitem_195);  getitem_195 = None
        convolution_default_110 = torch.ops.aten.convolution.default(silu__default_65, primals_488, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1920)
        native_batch_norm_default_66 = torch.ops.aten.native_batch_norm.default(convolution_default_110, primals_482, primals_478, primals_480, primals_481, False, 0.1, 0.001);  primals_478 = None
        getitem_198 = native_batch_norm_default_66[0]
        getitem_199 = native_batch_norm_default_66[1]
        getitem_200 = native_batch_norm_default_66[2];  native_batch_norm_default_66 = None
        new_zeros_default_198 = torch.ops.aten.new_zeros.default(convolution_default_110, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_199 = torch.ops.aten.new_zeros.default(convolution_default_110, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_200 = torch.ops.aten.new_zeros.default(convolution_default_110, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_66 = torch.ops.aten.clone.default(getitem_198)
        silu__default_66 = torch.ops.aten.silu_.default(getitem_198);  getitem_198 = None
        mean_dim_22 = torch.ops.aten.mean.dim(silu__default_66, [2, 3], True)
        convolution_default_111 = torch.ops.aten.convolution.default(mean_dim_22, primals_494, primals_493, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_493 = None
        clone_default_67 = torch.ops.aten.clone.default(convolution_default_111)
        silu__default_67 = torch.ops.aten.silu_.default(convolution_default_111);  convolution_default_111 = None
        convolution_default_112 = torch.ops.aten.convolution.default(silu__default_67, primals_492, primals_491, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_491 = None
        sigmoid_default_22 = torch.ops.aten.sigmoid.default(convolution_default_112);  convolution_default_112 = None
        mul_tensor_22 = torch.ops.aten.mul.Tensor(silu__default_66, sigmoid_default_22)
        convolution_default_113 = torch.ops.aten.convolution.default(mul_tensor_22, primals_490, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_67 = torch.ops.aten.native_batch_norm.default(convolution_default_113, primals_487, primals_483, primals_485, primals_486, False, 0.1, 0.001);  primals_483 = None
        getitem_201 = native_batch_norm_default_67[0]
        getitem_202 = native_batch_norm_default_67[1]
        getitem_203 = native_batch_norm_default_67[2];  native_batch_norm_default_67 = None
        new_zeros_default_201 = torch.ops.aten.new_zeros.default(convolution_default_113, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_202 = torch.ops.aten.new_zeros.default(convolution_default_113, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_203 = torch.ops.aten.new_zeros.default(convolution_default_113, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_15 = torch.ops.aten.add_.Tensor(getitem_201, getitem_192);  getitem_201 = None
        convolution_default_114 = torch.ops.aten.convolution.default(add__tensor_15, primals_854, primals_853, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_853 = None
        native_batch_norm_default_68 = torch.ops.aten.native_batch_norm.default(convolution_default_114, primals_852, primals_848, primals_850, primals_851, False, 0.01, 0.001);  primals_848 = None
        getitem_204 = native_batch_norm_default_68[0]
        getitem_205 = native_batch_norm_default_68[1]
        getitem_206 = native_batch_norm_default_68[2];  native_batch_norm_default_68 = None
        new_zeros_default_204 = torch.ops.aten.new_zeros.default(convolution_default_114, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_205 = torch.ops.aten.new_zeros.default(convolution_default_114, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_206 = torch.ops.aten.new_zeros.default(convolution_default_114, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        constant_pad_nd_default_5 = torch.ops.aten.constant_pad_nd.default(getitem_204, [0, 1, 0, 1], -inf);  getitem_204 = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_5, [3, 3], [2, 2])
        getitem_207 = max_pool2d_with_indices_default[0]
        getitem_208 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        constant_pad_nd_default_6 = torch.ops.aten.constant_pad_nd.default(getitem_207, [0, 1, 0, 1], -inf)
        max_pool2d_with_indices_default_1 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_6, [3, 3], [2, 2])
        getitem_209 = max_pool2d_with_indices_default_1[0]
        getitem_210 = max_pool2d_with_indices_default_1[1];  max_pool2d_with_indices_default_1 = None
        upsample_nearest2d_vec = torch.ops.aten.upsample_nearest2d.vec(getitem_209, [10, 10], None)
        relu_default = torch.ops.aten.relu.default(primals_533);  primals_533 = None
        sum_default = torch.ops.aten.sum.default(relu_default)
        select_int = torch.ops.aten.select.int(relu_default, 0, 0)
        mul_tensor_23 = torch.ops.aten.mul.Tensor(getitem_207, select_int)
        add_tensor = torch.ops.aten.add.Tensor(sum_default, 0.0001)
        div_tensor = torch.ops.aten.div.Tensor(mul_tensor_23, add_tensor)
        select_int_1 = torch.ops.aten.select.int(relu_default, 0, 1)
        mul_tensor_24 = torch.ops.aten.mul.Tensor(upsample_nearest2d_vec, select_int_1)
        add_tensor_1 = torch.ops.aten.add.Tensor(sum_default, 0.0001);  sum_default = None
        div_tensor_1 = torch.ops.aten.div.Tensor(mul_tensor_24, add_tensor_1)
        stack_default = torch.ops.aten.stack.default([div_tensor, div_tensor_1], -1);  div_tensor = div_tensor_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(stack_default, [-1]);  stack_default = None
        clone_default_68 = torch.ops.aten.clone.default(sum_dim_int_list)
        silu__default_68 = torch.ops.aten.silu_.default(sum_dim_int_list);  sum_dim_int_list = None
        convolution_default_115 = torch.ops.aten.convolution.default(silu__default_68, primals_530, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_116 = torch.ops.aten.convolution.default(convolution_default_115, primals_532, primals_531, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_531 = None
        native_batch_norm_default_69 = torch.ops.aten.native_batch_norm.default(convolution_default_116, primals_529, primals_525, primals_527, primals_528, False, 0.01, 0.001);  primals_525 = None
        getitem_211 = native_batch_norm_default_69[0]
        getitem_212 = native_batch_norm_default_69[1]
        getitem_213 = native_batch_norm_default_69[2];  native_batch_norm_default_69 = None
        new_zeros_default_207 = torch.ops.aten.new_zeros.default(convolution_default_116, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_208 = torch.ops.aten.new_zeros.default(convolution_default_116, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_209 = torch.ops.aten.new_zeros.default(convolution_default_116, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_117 = torch.ops.aten.convolution.default(add__tensor_15, primals_549, primals_548, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_548 = None
        native_batch_norm_default_70 = torch.ops.aten.native_batch_norm.default(convolution_default_117, primals_547, primals_543, primals_545, primals_546, False, 0.01, 0.001);  primals_543 = None
        getitem_214 = native_batch_norm_default_70[0]
        getitem_215 = native_batch_norm_default_70[1]
        getitem_216 = native_batch_norm_default_70[2];  native_batch_norm_default_70 = None
        new_zeros_default_210 = torch.ops.aten.new_zeros.default(convolution_default_117, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_211 = torch.ops.aten.new_zeros.default(convolution_default_117, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_212 = torch.ops.aten.new_zeros.default(convolution_default_117, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_1 = torch.ops.aten.upsample_nearest2d.vec(getitem_211, [20, 20], None)
        relu_default_1 = torch.ops.aten.relu.default(primals_542);  primals_542 = None
        sum_default_1 = torch.ops.aten.sum.default(relu_default_1)
        select_int_2 = torch.ops.aten.select.int(relu_default_1, 0, 0)
        mul_tensor_25 = torch.ops.aten.mul.Tensor(getitem_214, select_int_2)
        add_tensor_2 = torch.ops.aten.add.Tensor(sum_default_1, 0.0001)
        div_tensor_2 = torch.ops.aten.div.Tensor(mul_tensor_25, add_tensor_2)
        select_int_3 = torch.ops.aten.select.int(relu_default_1, 0, 1)
        mul_tensor_26 = torch.ops.aten.mul.Tensor(upsample_nearest2d_vec_1, select_int_3)
        add_tensor_3 = torch.ops.aten.add.Tensor(sum_default_1, 0.0001);  sum_default_1 = None
        div_tensor_3 = torch.ops.aten.div.Tensor(mul_tensor_26, add_tensor_3)
        stack_default_1 = torch.ops.aten.stack.default([div_tensor_2, div_tensor_3], -1);  div_tensor_2 = div_tensor_3 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(stack_default_1, [-1]);  stack_default_1 = None
        clone_default_69 = torch.ops.aten.clone.default(sum_dim_int_list_1)
        silu__default_69 = torch.ops.aten.silu_.default(sum_dim_int_list_1);  sum_dim_int_list_1 = None
        convolution_default_118 = torch.ops.aten.convolution.default(silu__default_69, primals_539, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_119 = torch.ops.aten.convolution.default(convolution_default_118, primals_541, primals_540, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_540 = None
        native_batch_norm_default_71 = torch.ops.aten.native_batch_norm.default(convolution_default_119, primals_538, primals_534, primals_536, primals_537, False, 0.01, 0.001);  primals_534 = None
        getitem_217 = native_batch_norm_default_71[0]
        getitem_218 = native_batch_norm_default_71[1]
        getitem_219 = native_batch_norm_default_71[2];  native_batch_norm_default_71 = None
        new_zeros_default_213 = torch.ops.aten.new_zeros.default(convolution_default_119, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_214 = torch.ops.aten.new_zeros.default(convolution_default_119, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_215 = torch.ops.aten.new_zeros.default(convolution_default_119, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_120 = torch.ops.aten.convolution.default(add__tensor_10, primals_565, primals_564, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_564 = None
        native_batch_norm_default_72 = torch.ops.aten.native_batch_norm.default(convolution_default_120, primals_563, primals_559, primals_561, primals_562, False, 0.01, 0.001);  primals_559 = None
        getitem_220 = native_batch_norm_default_72[0]
        getitem_221 = native_batch_norm_default_72[1]
        getitem_222 = native_batch_norm_default_72[2];  native_batch_norm_default_72 = None
        new_zeros_default_216 = torch.ops.aten.new_zeros.default(convolution_default_120, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_217 = torch.ops.aten.new_zeros.default(convolution_default_120, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_218 = torch.ops.aten.new_zeros.default(convolution_default_120, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_2 = torch.ops.aten.upsample_nearest2d.vec(getitem_217, [40, 40], None)
        relu_default_2 = torch.ops.aten.relu.default(primals_558);  primals_558 = None
        sum_default_2 = torch.ops.aten.sum.default(relu_default_2)
        select_int_4 = torch.ops.aten.select.int(relu_default_2, 0, 0)
        mul_tensor_27 = torch.ops.aten.mul.Tensor(getitem_220, select_int_4)
        add_tensor_4 = torch.ops.aten.add.Tensor(sum_default_2, 0.0001)
        div_tensor_4 = torch.ops.aten.div.Tensor(mul_tensor_27, add_tensor_4)
        select_int_5 = torch.ops.aten.select.int(relu_default_2, 0, 1)
        mul_tensor_28 = torch.ops.aten.mul.Tensor(upsample_nearest2d_vec_2, select_int_5)
        add_tensor_5 = torch.ops.aten.add.Tensor(sum_default_2, 0.0001);  sum_default_2 = None
        div_tensor_5 = torch.ops.aten.div.Tensor(mul_tensor_28, add_tensor_5)
        stack_default_2 = torch.ops.aten.stack.default([div_tensor_4, div_tensor_5], -1);  div_tensor_4 = div_tensor_5 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(stack_default_2, [-1]);  stack_default_2 = None
        clone_default_70 = torch.ops.aten.clone.default(sum_dim_int_list_2)
        silu__default_70 = torch.ops.aten.silu_.default(sum_dim_int_list_2);  sum_dim_int_list_2 = None
        convolution_default_121 = torch.ops.aten.convolution.default(silu__default_70, primals_555, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_122 = torch.ops.aten.convolution.default(convolution_default_121, primals_557, primals_556, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_556 = None
        native_batch_norm_default_73 = torch.ops.aten.native_batch_norm.default(convolution_default_122, primals_554, primals_550, primals_552, primals_553, False, 0.01, 0.001);  primals_550 = None
        getitem_223 = native_batch_norm_default_73[0]
        getitem_224 = native_batch_norm_default_73[1]
        getitem_225 = native_batch_norm_default_73[2];  native_batch_norm_default_73 = None
        new_zeros_default_219 = torch.ops.aten.new_zeros.default(convolution_default_122, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_220 = torch.ops.aten.new_zeros.default(convolution_default_122, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_221 = torch.ops.aten.new_zeros.default(convolution_default_122, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_123 = torch.ops.aten.convolution.default(add__tensor_4, primals_581, primals_580, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_580 = None
        native_batch_norm_default_74 = torch.ops.aten.native_batch_norm.default(convolution_default_123, primals_579, primals_575, primals_577, primals_578, False, 0.01, 0.001);  primals_575 = None
        getitem_226 = native_batch_norm_default_74[0]
        getitem_227 = native_batch_norm_default_74[1]
        getitem_228 = native_batch_norm_default_74[2];  native_batch_norm_default_74 = None
        new_zeros_default_222 = torch.ops.aten.new_zeros.default(convolution_default_123, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_223 = torch.ops.aten.new_zeros.default(convolution_default_123, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_224 = torch.ops.aten.new_zeros.default(convolution_default_123, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_3 = torch.ops.aten.upsample_nearest2d.vec(getitem_223, [80, 80], None)
        relu_default_3 = torch.ops.aten.relu.default(primals_574);  primals_574 = None
        sum_default_3 = torch.ops.aten.sum.default(relu_default_3)
        select_int_6 = torch.ops.aten.select.int(relu_default_3, 0, 0)
        mul_tensor_29 = torch.ops.aten.mul.Tensor(getitem_226, select_int_6)
        add_tensor_6 = torch.ops.aten.add.Tensor(sum_default_3, 0.0001)
        div_tensor_6 = torch.ops.aten.div.Tensor(mul_tensor_29, add_tensor_6)
        select_int_7 = torch.ops.aten.select.int(relu_default_3, 0, 1)
        mul_tensor_30 = torch.ops.aten.mul.Tensor(upsample_nearest2d_vec_3, select_int_7)
        add_tensor_7 = torch.ops.aten.add.Tensor(sum_default_3, 0.0001);  sum_default_3 = None
        div_tensor_7 = torch.ops.aten.div.Tensor(mul_tensor_30, add_tensor_7)
        stack_default_3 = torch.ops.aten.stack.default([div_tensor_6, div_tensor_7], -1);  div_tensor_6 = div_tensor_7 = None
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(stack_default_3, [-1]);  stack_default_3 = None
        clone_default_71 = torch.ops.aten.clone.default(sum_dim_int_list_3)
        silu__default_71 = torch.ops.aten.silu_.default(sum_dim_int_list_3);  sum_dim_int_list_3 = None
        convolution_default_124 = torch.ops.aten.convolution.default(silu__default_71, primals_571, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_125 = torch.ops.aten.convolution.default(convolution_default_124, primals_573, primals_572, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_572 = None
        native_batch_norm_default_75 = torch.ops.aten.native_batch_norm.default(convolution_default_125, primals_570, primals_566, primals_568, primals_569, False, 0.01, 0.001);  primals_566 = None
        getitem_229 = native_batch_norm_default_75[0]
        getitem_230 = native_batch_norm_default_75[1]
        getitem_231 = native_batch_norm_default_75[2];  native_batch_norm_default_75 = None
        new_zeros_default_225 = torch.ops.aten.new_zeros.default(convolution_default_125, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_226 = torch.ops.aten.new_zeros.default(convolution_default_125, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_227 = torch.ops.aten.new_zeros.default(convolution_default_125, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_126 = torch.ops.aten.convolution.default(add__tensor_10, primals_597, primals_596, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_596 = None
        native_batch_norm_default_76 = torch.ops.aten.native_batch_norm.default(convolution_default_126, primals_595, primals_591, primals_593, primals_594, False, 0.01, 0.001);  primals_591 = None
        getitem_232 = native_batch_norm_default_76[0]
        getitem_233 = native_batch_norm_default_76[1]
        getitem_234 = native_batch_norm_default_76[2];  native_batch_norm_default_76 = None
        new_zeros_default_228 = torch.ops.aten.new_zeros.default(convolution_default_126, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_229 = torch.ops.aten.new_zeros.default(convolution_default_126, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_230 = torch.ops.aten.new_zeros.default(convolution_default_126, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        constant_pad_nd_default_7 = torch.ops.aten.constant_pad_nd.default(getitem_229, [0, 1, 0, 1], -inf)
        max_pool2d_with_indices_default_2 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_7, [3, 3], [2, 2])
        getitem_235 = max_pool2d_with_indices_default_2[0]
        getitem_236 = max_pool2d_with_indices_default_2[1];  max_pool2d_with_indices_default_2 = None
        relu_default_4 = torch.ops.aten.relu.default(primals_590);  primals_590 = None
        sum_default_4 = torch.ops.aten.sum.default(relu_default_4)
        select_int_8 = torch.ops.aten.select.int(relu_default_4, 0, 0)
        mul_tensor_31 = torch.ops.aten.mul.Tensor(getitem_232, select_int_8)
        add_tensor_8 = torch.ops.aten.add.Tensor(sum_default_4, 0.0001)
        div_tensor_8 = torch.ops.aten.div.Tensor(mul_tensor_31, add_tensor_8)
        select_int_9 = torch.ops.aten.select.int(relu_default_4, 0, 1)
        mul_tensor_32 = torch.ops.aten.mul.Tensor(getitem_223, select_int_9)
        add_tensor_9 = torch.ops.aten.add.Tensor(sum_default_4, 0.0001)
        div_tensor_9 = torch.ops.aten.div.Tensor(mul_tensor_32, add_tensor_9)
        select_int_10 = torch.ops.aten.select.int(relu_default_4, 0, 2)
        mul_tensor_33 = torch.ops.aten.mul.Tensor(getitem_235, select_int_10)
        add_tensor_10 = torch.ops.aten.add.Tensor(sum_default_4, 0.0001);  sum_default_4 = None
        div_tensor_10 = torch.ops.aten.div.Tensor(mul_tensor_33, add_tensor_10)
        stack_default_4 = torch.ops.aten.stack.default([div_tensor_8, div_tensor_9, div_tensor_10], -1);  div_tensor_8 = div_tensor_9 = div_tensor_10 = None
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(stack_default_4, [-1]);  stack_default_4 = None
        clone_default_72 = torch.ops.aten.clone.default(sum_dim_int_list_4)
        silu__default_72 = torch.ops.aten.silu_.default(sum_dim_int_list_4);  sum_dim_int_list_4 = None
        convolution_default_127 = torch.ops.aten.convolution.default(silu__default_72, primals_587, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_128 = torch.ops.aten.convolution.default(convolution_default_127, primals_589, primals_588, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_588 = None
        native_batch_norm_default_77 = torch.ops.aten.native_batch_norm.default(convolution_default_128, primals_586, primals_582, primals_584, primals_585, False, 0.01, 0.001);  primals_582 = None
        getitem_237 = native_batch_norm_default_77[0]
        getitem_238 = native_batch_norm_default_77[1]
        getitem_239 = native_batch_norm_default_77[2];  native_batch_norm_default_77 = None
        new_zeros_default_231 = torch.ops.aten.new_zeros.default(convolution_default_128, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_232 = torch.ops.aten.new_zeros.default(convolution_default_128, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_233 = torch.ops.aten.new_zeros.default(convolution_default_128, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_129 = torch.ops.aten.convolution.default(add__tensor_15, primals_613, primals_612, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_612 = None
        native_batch_norm_default_78 = torch.ops.aten.native_batch_norm.default(convolution_default_129, primals_611, primals_607, primals_609, primals_610, False, 0.01, 0.001);  primals_607 = None
        getitem_240 = native_batch_norm_default_78[0]
        getitem_241 = native_batch_norm_default_78[1]
        getitem_242 = native_batch_norm_default_78[2];  native_batch_norm_default_78 = None
        new_zeros_default_234 = torch.ops.aten.new_zeros.default(convolution_default_129, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_235 = torch.ops.aten.new_zeros.default(convolution_default_129, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_236 = torch.ops.aten.new_zeros.default(convolution_default_129, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        constant_pad_nd_default_8 = torch.ops.aten.constant_pad_nd.default(getitem_237, [0, 1, 0, 1], -inf)
        max_pool2d_with_indices_default_3 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_8, [3, 3], [2, 2])
        getitem_243 = max_pool2d_with_indices_default_3[0]
        getitem_244 = max_pool2d_with_indices_default_3[1];  max_pool2d_with_indices_default_3 = None
        relu_default_5 = torch.ops.aten.relu.default(primals_606);  primals_606 = None
        sum_default_5 = torch.ops.aten.sum.default(relu_default_5)
        select_int_11 = torch.ops.aten.select.int(relu_default_5, 0, 0)
        mul_tensor_34 = torch.ops.aten.mul.Tensor(getitem_240, select_int_11)
        add_tensor_11 = torch.ops.aten.add.Tensor(sum_default_5, 0.0001)
        div_tensor_11 = torch.ops.aten.div.Tensor(mul_tensor_34, add_tensor_11)
        select_int_12 = torch.ops.aten.select.int(relu_default_5, 0, 1)
        mul_tensor_35 = torch.ops.aten.mul.Tensor(getitem_217, select_int_12)
        add_tensor_12 = torch.ops.aten.add.Tensor(sum_default_5, 0.0001)
        div_tensor_12 = torch.ops.aten.div.Tensor(mul_tensor_35, add_tensor_12)
        select_int_13 = torch.ops.aten.select.int(relu_default_5, 0, 2)
        mul_tensor_36 = torch.ops.aten.mul.Tensor(getitem_243, select_int_13)
        add_tensor_13 = torch.ops.aten.add.Tensor(sum_default_5, 0.0001);  sum_default_5 = None
        div_tensor_13 = torch.ops.aten.div.Tensor(mul_tensor_36, add_tensor_13)
        stack_default_5 = torch.ops.aten.stack.default([div_tensor_11, div_tensor_12, div_tensor_13], -1);  div_tensor_11 = div_tensor_12 = div_tensor_13 = None
        sum_dim_int_list_5 = torch.ops.aten.sum.dim_IntList(stack_default_5, [-1]);  stack_default_5 = None
        clone_default_73 = torch.ops.aten.clone.default(sum_dim_int_list_5)
        silu__default_73 = torch.ops.aten.silu_.default(sum_dim_int_list_5);  sum_dim_int_list_5 = None
        convolution_default_130 = torch.ops.aten.convolution.default(silu__default_73, primals_603, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_131 = torch.ops.aten.convolution.default(convolution_default_130, primals_605, primals_604, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_604 = None
        native_batch_norm_default_79 = torch.ops.aten.native_batch_norm.default(convolution_default_131, primals_602, primals_598, primals_600, primals_601, False, 0.01, 0.001);  primals_598 = None
        getitem_245 = native_batch_norm_default_79[0]
        getitem_246 = native_batch_norm_default_79[1]
        getitem_247 = native_batch_norm_default_79[2];  native_batch_norm_default_79 = None
        new_zeros_default_237 = torch.ops.aten.new_zeros.default(convolution_default_131, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_238 = torch.ops.aten.new_zeros.default(convolution_default_131, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_239 = torch.ops.aten.new_zeros.default(convolution_default_131, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        constant_pad_nd_default_9 = torch.ops.aten.constant_pad_nd.default(getitem_245, [0, 1, 0, 1], -inf)
        max_pool2d_with_indices_default_4 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_9, [3, 3], [2, 2])
        getitem_248 = max_pool2d_with_indices_default_4[0]
        getitem_249 = max_pool2d_with_indices_default_4[1];  max_pool2d_with_indices_default_4 = None
        relu_default_6 = torch.ops.aten.relu.default(primals_622);  primals_622 = None
        sum_default_6 = torch.ops.aten.sum.default(relu_default_6)
        select_int_14 = torch.ops.aten.select.int(relu_default_6, 0, 0)
        mul_tensor_37 = torch.ops.aten.mul.Tensor(getitem_207, select_int_14)
        add_tensor_14 = torch.ops.aten.add.Tensor(sum_default_6, 0.0001)
        div_tensor_14 = torch.ops.aten.div.Tensor(mul_tensor_37, add_tensor_14)
        select_int_15 = torch.ops.aten.select.int(relu_default_6, 0, 1)
        mul_tensor_38 = torch.ops.aten.mul.Tensor(getitem_211, select_int_15)
        add_tensor_15 = torch.ops.aten.add.Tensor(sum_default_6, 0.0001)
        div_tensor_15 = torch.ops.aten.div.Tensor(mul_tensor_38, add_tensor_15)
        select_int_16 = torch.ops.aten.select.int(relu_default_6, 0, 2)
        mul_tensor_39 = torch.ops.aten.mul.Tensor(getitem_248, select_int_16)
        add_tensor_16 = torch.ops.aten.add.Tensor(sum_default_6, 0.0001);  sum_default_6 = None
        div_tensor_16 = torch.ops.aten.div.Tensor(mul_tensor_39, add_tensor_16)
        stack_default_6 = torch.ops.aten.stack.default([div_tensor_14, div_tensor_15, div_tensor_16], -1);  div_tensor_14 = div_tensor_15 = div_tensor_16 = None
        sum_dim_int_list_6 = torch.ops.aten.sum.dim_IntList(stack_default_6, [-1]);  stack_default_6 = None
        clone_default_74 = torch.ops.aten.clone.default(sum_dim_int_list_6)
        silu__default_74 = torch.ops.aten.silu_.default(sum_dim_int_list_6);  sum_dim_int_list_6 = None
        convolution_default_132 = torch.ops.aten.convolution.default(silu__default_74, primals_619, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_133 = torch.ops.aten.convolution.default(convolution_default_132, primals_621, primals_620, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_620 = None
        native_batch_norm_default_80 = torch.ops.aten.native_batch_norm.default(convolution_default_133, primals_618, primals_614, primals_616, primals_617, False, 0.01, 0.001);  primals_614 = None
        getitem_250 = native_batch_norm_default_80[0]
        getitem_251 = native_batch_norm_default_80[1]
        getitem_252 = native_batch_norm_default_80[2];  native_batch_norm_default_80 = None
        new_zeros_default_240 = torch.ops.aten.new_zeros.default(convolution_default_133, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_241 = torch.ops.aten.new_zeros.default(convolution_default_133, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_242 = torch.ops.aten.new_zeros.default(convolution_default_133, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        constant_pad_nd_default_10 = torch.ops.aten.constant_pad_nd.default(getitem_250, [0, 1, 0, 1], -inf)
        max_pool2d_with_indices_default_5 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_10, [3, 3], [2, 2])
        getitem_253 = max_pool2d_with_indices_default_5[0]
        getitem_254 = max_pool2d_with_indices_default_5[1];  max_pool2d_with_indices_default_5 = None
        relu_default_7 = torch.ops.aten.relu.default(primals_631);  primals_631 = None
        sum_default_7 = torch.ops.aten.sum.default(relu_default_7)
        select_int_17 = torch.ops.aten.select.int(relu_default_7, 0, 0)
        mul_tensor_40 = torch.ops.aten.mul.Tensor(getitem_209, select_int_17)
        add_tensor_17 = torch.ops.aten.add.Tensor(sum_default_7, 0.0001)
        div_tensor_17 = torch.ops.aten.div.Tensor(mul_tensor_40, add_tensor_17)
        select_int_18 = torch.ops.aten.select.int(relu_default_7, 0, 1)
        mul_tensor_41 = torch.ops.aten.mul.Tensor(getitem_253, select_int_18)
        add_tensor_18 = torch.ops.aten.add.Tensor(sum_default_7, 0.0001);  sum_default_7 = None
        div_tensor_18 = torch.ops.aten.div.Tensor(mul_tensor_41, add_tensor_18)
        stack_default_7 = torch.ops.aten.stack.default([div_tensor_17, div_tensor_18], -1);  div_tensor_17 = div_tensor_18 = None
        sum_dim_int_list_7 = torch.ops.aten.sum.dim_IntList(stack_default_7, [-1]);  stack_default_7 = None
        clone_default_75 = torch.ops.aten.clone.default(sum_dim_int_list_7)
        silu__default_75 = torch.ops.aten.silu_.default(sum_dim_int_list_7);  sum_dim_int_list_7 = None
        convolution_default_134 = torch.ops.aten.convolution.default(silu__default_75, primals_628, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_135 = torch.ops.aten.convolution.default(convolution_default_134, primals_630, primals_629, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_629 = None
        native_batch_norm_default_81 = torch.ops.aten.native_batch_norm.default(convolution_default_135, primals_627, primals_623, primals_625, primals_626, False, 0.01, 0.001);  primals_623 = None
        getitem_255 = native_batch_norm_default_81[0]
        getitem_256 = native_batch_norm_default_81[1]
        getitem_257 = native_batch_norm_default_81[2];  native_batch_norm_default_81 = None
        new_zeros_default_243 = torch.ops.aten.new_zeros.default(convolution_default_135, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_244 = torch.ops.aten.new_zeros.default(convolution_default_135, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_245 = torch.ops.aten.new_zeros.default(convolution_default_135, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_4 = torch.ops.aten.upsample_nearest2d.vec(getitem_255, [10, 10], None)
        relu_default_8 = torch.ops.aten.relu.default(primals_640);  primals_640 = None
        sum_default_8 = torch.ops.aten.sum.default(relu_default_8)
        select_int_19 = torch.ops.aten.select.int(relu_default_8, 0, 0)
        mul_tensor_42 = torch.ops.aten.mul.Tensor(getitem_250, select_int_19)
        add_tensor_19 = torch.ops.aten.add.Tensor(sum_default_8, 0.0001)
        div_tensor_19 = torch.ops.aten.div.Tensor(mul_tensor_42, add_tensor_19)
        select_int_20 = torch.ops.aten.select.int(relu_default_8, 0, 1)
        mul_tensor_43 = torch.ops.aten.mul.Tensor(upsample_nearest2d_vec_4, select_int_20)
        add_tensor_20 = torch.ops.aten.add.Tensor(sum_default_8, 0.0001);  sum_default_8 = None
        div_tensor_20 = torch.ops.aten.div.Tensor(mul_tensor_43, add_tensor_20)
        stack_default_8 = torch.ops.aten.stack.default([div_tensor_19, div_tensor_20], -1);  div_tensor_19 = div_tensor_20 = None
        sum_dim_int_list_8 = torch.ops.aten.sum.dim_IntList(stack_default_8, [-1]);  stack_default_8 = None
        clone_default_76 = torch.ops.aten.clone.default(sum_dim_int_list_8)
        silu__default_76 = torch.ops.aten.silu_.default(sum_dim_int_list_8);  sum_dim_int_list_8 = None
        convolution_default_136 = torch.ops.aten.convolution.default(silu__default_76, primals_637, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_137 = torch.ops.aten.convolution.default(convolution_default_136, primals_639, primals_638, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_638 = None
        native_batch_norm_default_82 = torch.ops.aten.native_batch_norm.default(convolution_default_137, primals_636, primals_632, primals_634, primals_635, False, 0.01, 0.001);  primals_632 = None
        getitem_258 = native_batch_norm_default_82[0]
        getitem_259 = native_batch_norm_default_82[1]
        getitem_260 = native_batch_norm_default_82[2];  native_batch_norm_default_82 = None
        new_zeros_default_246 = torch.ops.aten.new_zeros.default(convolution_default_137, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_247 = torch.ops.aten.new_zeros.default(convolution_default_137, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_248 = torch.ops.aten.new_zeros.default(convolution_default_137, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_5 = torch.ops.aten.upsample_nearest2d.vec(getitem_258, [20, 20], None)
        relu_default_9 = torch.ops.aten.relu.default(primals_649);  primals_649 = None
        sum_default_9 = torch.ops.aten.sum.default(relu_default_9)
        select_int_21 = torch.ops.aten.select.int(relu_default_9, 0, 0)
        mul_tensor_44 = torch.ops.aten.mul.Tensor(getitem_245, select_int_21)
        add_tensor_21 = torch.ops.aten.add.Tensor(sum_default_9, 0.0001)
        div_tensor_21 = torch.ops.aten.div.Tensor(mul_tensor_44, add_tensor_21)
        select_int_22 = torch.ops.aten.select.int(relu_default_9, 0, 1)
        mul_tensor_45 = torch.ops.aten.mul.Tensor(upsample_nearest2d_vec_5, select_int_22)
        add_tensor_22 = torch.ops.aten.add.Tensor(sum_default_9, 0.0001);  sum_default_9 = None
        div_tensor_22 = torch.ops.aten.div.Tensor(mul_tensor_45, add_tensor_22)
        stack_default_9 = torch.ops.aten.stack.default([div_tensor_21, div_tensor_22], -1);  div_tensor_21 = div_tensor_22 = None
        sum_dim_int_list_9 = torch.ops.aten.sum.dim_IntList(stack_default_9, [-1]);  stack_default_9 = None
        clone_default_77 = torch.ops.aten.clone.default(sum_dim_int_list_9)
        silu__default_77 = torch.ops.aten.silu_.default(sum_dim_int_list_9);  sum_dim_int_list_9 = None
        convolution_default_138 = torch.ops.aten.convolution.default(silu__default_77, primals_646, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_139 = torch.ops.aten.convolution.default(convolution_default_138, primals_648, primals_647, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_647 = None
        native_batch_norm_default_83 = torch.ops.aten.native_batch_norm.default(convolution_default_139, primals_645, primals_641, primals_643, primals_644, False, 0.01, 0.001);  primals_641 = None
        getitem_261 = native_batch_norm_default_83[0]
        getitem_262 = native_batch_norm_default_83[1]
        getitem_263 = native_batch_norm_default_83[2];  native_batch_norm_default_83 = None
        new_zeros_default_249 = torch.ops.aten.new_zeros.default(convolution_default_139, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_250 = torch.ops.aten.new_zeros.default(convolution_default_139, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_251 = torch.ops.aten.new_zeros.default(convolution_default_139, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_6 = torch.ops.aten.upsample_nearest2d.vec(getitem_261, [40, 40], None)
        relu_default_10 = torch.ops.aten.relu.default(primals_658);  primals_658 = None
        sum_default_10 = torch.ops.aten.sum.default(relu_default_10)
        select_int_23 = torch.ops.aten.select.int(relu_default_10, 0, 0)
        mul_tensor_46 = torch.ops.aten.mul.Tensor(getitem_237, select_int_23)
        add_tensor_23 = torch.ops.aten.add.Tensor(sum_default_10, 0.0001)
        div_tensor_23 = torch.ops.aten.div.Tensor(mul_tensor_46, add_tensor_23)
        select_int_24 = torch.ops.aten.select.int(relu_default_10, 0, 1)
        mul_tensor_47 = torch.ops.aten.mul.Tensor(upsample_nearest2d_vec_6, select_int_24)
        add_tensor_24 = torch.ops.aten.add.Tensor(sum_default_10, 0.0001);  sum_default_10 = None
        div_tensor_24 = torch.ops.aten.div.Tensor(mul_tensor_47, add_tensor_24)
        stack_default_10 = torch.ops.aten.stack.default([div_tensor_23, div_tensor_24], -1);  div_tensor_23 = div_tensor_24 = None
        sum_dim_int_list_10 = torch.ops.aten.sum.dim_IntList(stack_default_10, [-1]);  stack_default_10 = None
        clone_default_78 = torch.ops.aten.clone.default(sum_dim_int_list_10)
        silu__default_78 = torch.ops.aten.silu_.default(sum_dim_int_list_10);  sum_dim_int_list_10 = None
        convolution_default_140 = torch.ops.aten.convolution.default(silu__default_78, primals_655, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_141 = torch.ops.aten.convolution.default(convolution_default_140, primals_657, primals_656, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_656 = None
        native_batch_norm_default_84 = torch.ops.aten.native_batch_norm.default(convolution_default_141, primals_654, primals_650, primals_652, primals_653, False, 0.01, 0.001);  primals_650 = None
        getitem_264 = native_batch_norm_default_84[0]
        getitem_265 = native_batch_norm_default_84[1]
        getitem_266 = native_batch_norm_default_84[2];  native_batch_norm_default_84 = None
        new_zeros_default_252 = torch.ops.aten.new_zeros.default(convolution_default_141, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_253 = torch.ops.aten.new_zeros.default(convolution_default_141, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_254 = torch.ops.aten.new_zeros.default(convolution_default_141, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_7 = torch.ops.aten.upsample_nearest2d.vec(getitem_264, [80, 80], None)
        relu_default_11 = torch.ops.aten.relu.default(primals_667);  primals_667 = None
        sum_default_11 = torch.ops.aten.sum.default(relu_default_11)
        select_int_25 = torch.ops.aten.select.int(relu_default_11, 0, 0)
        mul_tensor_48 = torch.ops.aten.mul.Tensor(getitem_229, select_int_25)
        add_tensor_25 = torch.ops.aten.add.Tensor(sum_default_11, 0.0001)
        div_tensor_25 = torch.ops.aten.div.Tensor(mul_tensor_48, add_tensor_25)
        select_int_26 = torch.ops.aten.select.int(relu_default_11, 0, 1)
        mul_tensor_49 = torch.ops.aten.mul.Tensor(upsample_nearest2d_vec_7, select_int_26)
        add_tensor_26 = torch.ops.aten.add.Tensor(sum_default_11, 0.0001);  sum_default_11 = None
        div_tensor_26 = torch.ops.aten.div.Tensor(mul_tensor_49, add_tensor_26)
        stack_default_11 = torch.ops.aten.stack.default([div_tensor_25, div_tensor_26], -1);  div_tensor_25 = div_tensor_26 = None
        sum_dim_int_list_11 = torch.ops.aten.sum.dim_IntList(stack_default_11, [-1]);  stack_default_11 = None
        clone_default_79 = torch.ops.aten.clone.default(sum_dim_int_list_11)
        silu__default_79 = torch.ops.aten.silu_.default(sum_dim_int_list_11);  sum_dim_int_list_11 = None
        convolution_default_142 = torch.ops.aten.convolution.default(silu__default_79, primals_664, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_143 = torch.ops.aten.convolution.default(convolution_default_142, primals_666, primals_665, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_665 = None
        native_batch_norm_default_85 = torch.ops.aten.native_batch_norm.default(convolution_default_143, primals_663, primals_659, primals_661, primals_662, False, 0.01, 0.001);  primals_659 = None
        getitem_267 = native_batch_norm_default_85[0]
        getitem_268 = native_batch_norm_default_85[1]
        getitem_269 = native_batch_norm_default_85[2];  native_batch_norm_default_85 = None
        new_zeros_default_255 = torch.ops.aten.new_zeros.default(convolution_default_143, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_256 = torch.ops.aten.new_zeros.default(convolution_default_143, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_257 = torch.ops.aten.new_zeros.default(convolution_default_143, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        constant_pad_nd_default_11 = torch.ops.aten.constant_pad_nd.default(getitem_267, [0, 1, 0, 1], -inf)
        max_pool2d_with_indices_default_6 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_11, [3, 3], [2, 2])
        getitem_270 = max_pool2d_with_indices_default_6[0]
        getitem_271 = max_pool2d_with_indices_default_6[1];  max_pool2d_with_indices_default_6 = None
        relu_default_12 = torch.ops.aten.relu.default(primals_676);  primals_676 = None
        sum_default_12 = torch.ops.aten.sum.default(relu_default_12)
        select_int_27 = torch.ops.aten.select.int(relu_default_12, 0, 0)
        mul_tensor_50 = torch.ops.aten.mul.Tensor(getitem_237, select_int_27)
        add_tensor_27 = torch.ops.aten.add.Tensor(sum_default_12, 0.0001)
        div_tensor_27 = torch.ops.aten.div.Tensor(mul_tensor_50, add_tensor_27)
        select_int_28 = torch.ops.aten.select.int(relu_default_12, 0, 1)
        mul_tensor_51 = torch.ops.aten.mul.Tensor(getitem_264, select_int_28)
        add_tensor_28 = torch.ops.aten.add.Tensor(sum_default_12, 0.0001)
        div_tensor_28 = torch.ops.aten.div.Tensor(mul_tensor_51, add_tensor_28)
        select_int_29 = torch.ops.aten.select.int(relu_default_12, 0, 2)
        mul_tensor_52 = torch.ops.aten.mul.Tensor(getitem_270, select_int_29)
        add_tensor_29 = torch.ops.aten.add.Tensor(sum_default_12, 0.0001);  sum_default_12 = None
        div_tensor_29 = torch.ops.aten.div.Tensor(mul_tensor_52, add_tensor_29)
        stack_default_12 = torch.ops.aten.stack.default([div_tensor_27, div_tensor_28, div_tensor_29], -1);  div_tensor_27 = div_tensor_28 = div_tensor_29 = None
        sum_dim_int_list_12 = torch.ops.aten.sum.dim_IntList(stack_default_12, [-1]);  stack_default_12 = None
        clone_default_80 = torch.ops.aten.clone.default(sum_dim_int_list_12)
        silu__default_80 = torch.ops.aten.silu_.default(sum_dim_int_list_12);  sum_dim_int_list_12 = None
        convolution_default_144 = torch.ops.aten.convolution.default(silu__default_80, primals_673, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_145 = torch.ops.aten.convolution.default(convolution_default_144, primals_675, primals_674, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_674 = None
        native_batch_norm_default_86 = torch.ops.aten.native_batch_norm.default(convolution_default_145, primals_672, primals_668, primals_670, primals_671, False, 0.01, 0.001);  primals_668 = None
        getitem_272 = native_batch_norm_default_86[0]
        getitem_273 = native_batch_norm_default_86[1]
        getitem_274 = native_batch_norm_default_86[2];  native_batch_norm_default_86 = None
        new_zeros_default_258 = torch.ops.aten.new_zeros.default(convolution_default_145, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_259 = torch.ops.aten.new_zeros.default(convolution_default_145, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_260 = torch.ops.aten.new_zeros.default(convolution_default_145, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        constant_pad_nd_default_12 = torch.ops.aten.constant_pad_nd.default(getitem_272, [0, 1, 0, 1], -inf)
        max_pool2d_with_indices_default_7 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_12, [3, 3], [2, 2])
        getitem_275 = max_pool2d_with_indices_default_7[0]
        getitem_276 = max_pool2d_with_indices_default_7[1];  max_pool2d_with_indices_default_7 = None
        relu_default_13 = torch.ops.aten.relu.default(primals_685);  primals_685 = None
        sum_default_13 = torch.ops.aten.sum.default(relu_default_13)
        select_int_30 = torch.ops.aten.select.int(relu_default_13, 0, 0)
        mul_tensor_53 = torch.ops.aten.mul.Tensor(getitem_245, select_int_30)
        add_tensor_30 = torch.ops.aten.add.Tensor(sum_default_13, 0.0001)
        div_tensor_30 = torch.ops.aten.div.Tensor(mul_tensor_53, add_tensor_30)
        select_int_31 = torch.ops.aten.select.int(relu_default_13, 0, 1)
        mul_tensor_54 = torch.ops.aten.mul.Tensor(getitem_261, select_int_31)
        add_tensor_31 = torch.ops.aten.add.Tensor(sum_default_13, 0.0001)
        div_tensor_31 = torch.ops.aten.div.Tensor(mul_tensor_54, add_tensor_31)
        select_int_32 = torch.ops.aten.select.int(relu_default_13, 0, 2)
        mul_tensor_55 = torch.ops.aten.mul.Tensor(getitem_275, select_int_32)
        add_tensor_32 = torch.ops.aten.add.Tensor(sum_default_13, 0.0001);  sum_default_13 = None
        div_tensor_32 = torch.ops.aten.div.Tensor(mul_tensor_55, add_tensor_32)
        stack_default_13 = torch.ops.aten.stack.default([div_tensor_30, div_tensor_31, div_tensor_32], -1);  div_tensor_30 = div_tensor_31 = div_tensor_32 = None
        sum_dim_int_list_13 = torch.ops.aten.sum.dim_IntList(stack_default_13, [-1]);  stack_default_13 = None
        clone_default_81 = torch.ops.aten.clone.default(sum_dim_int_list_13)
        silu__default_81 = torch.ops.aten.silu_.default(sum_dim_int_list_13);  sum_dim_int_list_13 = None
        convolution_default_146 = torch.ops.aten.convolution.default(silu__default_81, primals_682, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_147 = torch.ops.aten.convolution.default(convolution_default_146, primals_684, primals_683, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_683 = None
        native_batch_norm_default_87 = torch.ops.aten.native_batch_norm.default(convolution_default_147, primals_681, primals_677, primals_679, primals_680, False, 0.01, 0.001);  primals_677 = None
        getitem_277 = native_batch_norm_default_87[0]
        getitem_278 = native_batch_norm_default_87[1]
        getitem_279 = native_batch_norm_default_87[2];  native_batch_norm_default_87 = None
        new_zeros_default_261 = torch.ops.aten.new_zeros.default(convolution_default_147, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_262 = torch.ops.aten.new_zeros.default(convolution_default_147, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_263 = torch.ops.aten.new_zeros.default(convolution_default_147, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        constant_pad_nd_default_13 = torch.ops.aten.constant_pad_nd.default(getitem_277, [0, 1, 0, 1], -inf)
        max_pool2d_with_indices_default_8 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_13, [3, 3], [2, 2])
        getitem_280 = max_pool2d_with_indices_default_8[0]
        getitem_281 = max_pool2d_with_indices_default_8[1];  max_pool2d_with_indices_default_8 = None
        relu_default_14 = torch.ops.aten.relu.default(primals_694);  primals_694 = None
        sum_default_14 = torch.ops.aten.sum.default(relu_default_14)
        select_int_33 = torch.ops.aten.select.int(relu_default_14, 0, 0)
        mul_tensor_56 = torch.ops.aten.mul.Tensor(getitem_250, select_int_33)
        add_tensor_33 = torch.ops.aten.add.Tensor(sum_default_14, 0.0001)
        div_tensor_33 = torch.ops.aten.div.Tensor(mul_tensor_56, add_tensor_33)
        select_int_34 = torch.ops.aten.select.int(relu_default_14, 0, 1)
        mul_tensor_57 = torch.ops.aten.mul.Tensor(getitem_258, select_int_34)
        add_tensor_34 = torch.ops.aten.add.Tensor(sum_default_14, 0.0001)
        div_tensor_34 = torch.ops.aten.div.Tensor(mul_tensor_57, add_tensor_34)
        select_int_35 = torch.ops.aten.select.int(relu_default_14, 0, 2)
        mul_tensor_58 = torch.ops.aten.mul.Tensor(getitem_280, select_int_35)
        add_tensor_35 = torch.ops.aten.add.Tensor(sum_default_14, 0.0001);  sum_default_14 = None
        div_tensor_35 = torch.ops.aten.div.Tensor(mul_tensor_58, add_tensor_35)
        stack_default_14 = torch.ops.aten.stack.default([div_tensor_33, div_tensor_34, div_tensor_35], -1);  div_tensor_33 = div_tensor_34 = div_tensor_35 = None
        sum_dim_int_list_14 = torch.ops.aten.sum.dim_IntList(stack_default_14, [-1]);  stack_default_14 = None
        clone_default_82 = torch.ops.aten.clone.default(sum_dim_int_list_14)
        silu__default_82 = torch.ops.aten.silu_.default(sum_dim_int_list_14);  sum_dim_int_list_14 = None
        convolution_default_148 = torch.ops.aten.convolution.default(silu__default_82, primals_691, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_149 = torch.ops.aten.convolution.default(convolution_default_148, primals_693, primals_692, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_692 = None
        native_batch_norm_default_88 = torch.ops.aten.native_batch_norm.default(convolution_default_149, primals_690, primals_686, primals_688, primals_689, False, 0.01, 0.001);  primals_686 = None
        getitem_282 = native_batch_norm_default_88[0]
        getitem_283 = native_batch_norm_default_88[1]
        getitem_284 = native_batch_norm_default_88[2];  native_batch_norm_default_88 = None
        new_zeros_default_264 = torch.ops.aten.new_zeros.default(convolution_default_149, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_265 = torch.ops.aten.new_zeros.default(convolution_default_149, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_266 = torch.ops.aten.new_zeros.default(convolution_default_149, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        constant_pad_nd_default_14 = torch.ops.aten.constant_pad_nd.default(getitem_282, [0, 1, 0, 1], -inf)
        max_pool2d_with_indices_default_9 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_14, [3, 3], [2, 2])
        getitem_285 = max_pool2d_with_indices_default_9[0]
        getitem_286 = max_pool2d_with_indices_default_9[1];  max_pool2d_with_indices_default_9 = None
        relu_default_15 = torch.ops.aten.relu.default(primals_703);  primals_703 = None
        sum_default_15 = torch.ops.aten.sum.default(relu_default_15)
        select_int_36 = torch.ops.aten.select.int(relu_default_15, 0, 0)
        mul_tensor_59 = torch.ops.aten.mul.Tensor(getitem_255, select_int_36)
        add_tensor_36 = torch.ops.aten.add.Tensor(sum_default_15, 0.0001)
        div_tensor_36 = torch.ops.aten.div.Tensor(mul_tensor_59, add_tensor_36)
        select_int_37 = torch.ops.aten.select.int(relu_default_15, 0, 1)
        mul_tensor_60 = torch.ops.aten.mul.Tensor(getitem_285, select_int_37)
        add_tensor_37 = torch.ops.aten.add.Tensor(sum_default_15, 0.0001);  sum_default_15 = None
        div_tensor_37 = torch.ops.aten.div.Tensor(mul_tensor_60, add_tensor_37)
        stack_default_15 = torch.ops.aten.stack.default([div_tensor_36, div_tensor_37], -1);  div_tensor_36 = div_tensor_37 = None
        sum_dim_int_list_15 = torch.ops.aten.sum.dim_IntList(stack_default_15, [-1]);  stack_default_15 = None
        clone_default_83 = torch.ops.aten.clone.default(sum_dim_int_list_15)
        silu__default_83 = torch.ops.aten.silu_.default(sum_dim_int_list_15);  sum_dim_int_list_15 = None
        convolution_default_150 = torch.ops.aten.convolution.default(silu__default_83, primals_700, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_151 = torch.ops.aten.convolution.default(convolution_default_150, primals_702, primals_701, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_701 = None
        native_batch_norm_default_89 = torch.ops.aten.native_batch_norm.default(convolution_default_151, primals_699, primals_695, primals_697, primals_698, False, 0.01, 0.001);  primals_695 = None
        getitem_287 = native_batch_norm_default_89[0]
        getitem_288 = native_batch_norm_default_89[1]
        getitem_289 = native_batch_norm_default_89[2];  native_batch_norm_default_89 = None
        new_zeros_default_267 = torch.ops.aten.new_zeros.default(convolution_default_151, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_268 = torch.ops.aten.new_zeros.default(convolution_default_151, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_269 = torch.ops.aten.new_zeros.default(convolution_default_151, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_8 = torch.ops.aten.upsample_nearest2d.vec(getitem_287, [10, 10], None)
        relu_default_16 = torch.ops.aten.relu.default(primals_712);  primals_712 = None
        sum_default_16 = torch.ops.aten.sum.default(relu_default_16)
        select_int_38 = torch.ops.aten.select.int(relu_default_16, 0, 0)
        mul_tensor_61 = torch.ops.aten.mul.Tensor(getitem_282, select_int_38)
        add_tensor_38 = torch.ops.aten.add.Tensor(sum_default_16, 0.0001)
        div_tensor_38 = torch.ops.aten.div.Tensor(mul_tensor_61, add_tensor_38)
        select_int_39 = torch.ops.aten.select.int(relu_default_16, 0, 1)
        mul_tensor_62 = torch.ops.aten.mul.Tensor(upsample_nearest2d_vec_8, select_int_39)
        add_tensor_39 = torch.ops.aten.add.Tensor(sum_default_16, 0.0001);  sum_default_16 = None
        div_tensor_39 = torch.ops.aten.div.Tensor(mul_tensor_62, add_tensor_39)
        stack_default_16 = torch.ops.aten.stack.default([div_tensor_38, div_tensor_39], -1);  div_tensor_38 = div_tensor_39 = None
        sum_dim_int_list_16 = torch.ops.aten.sum.dim_IntList(stack_default_16, [-1]);  stack_default_16 = None
        clone_default_84 = torch.ops.aten.clone.default(sum_dim_int_list_16)
        silu__default_84 = torch.ops.aten.silu_.default(sum_dim_int_list_16);  sum_dim_int_list_16 = None
        convolution_default_152 = torch.ops.aten.convolution.default(silu__default_84, primals_709, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_153 = torch.ops.aten.convolution.default(convolution_default_152, primals_711, primals_710, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_710 = None
        native_batch_norm_default_90 = torch.ops.aten.native_batch_norm.default(convolution_default_153, primals_708, primals_704, primals_706, primals_707, False, 0.01, 0.001);  primals_704 = None
        getitem_290 = native_batch_norm_default_90[0]
        getitem_291 = native_batch_norm_default_90[1]
        getitem_292 = native_batch_norm_default_90[2];  native_batch_norm_default_90 = None
        new_zeros_default_270 = torch.ops.aten.new_zeros.default(convolution_default_153, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_271 = torch.ops.aten.new_zeros.default(convolution_default_153, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_272 = torch.ops.aten.new_zeros.default(convolution_default_153, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_9 = torch.ops.aten.upsample_nearest2d.vec(getitem_290, [20, 20], None)
        relu_default_17 = torch.ops.aten.relu.default(primals_721);  primals_721 = None
        sum_default_17 = torch.ops.aten.sum.default(relu_default_17)
        select_int_40 = torch.ops.aten.select.int(relu_default_17, 0, 0)
        mul_tensor_63 = torch.ops.aten.mul.Tensor(getitem_277, select_int_40)
        add_tensor_40 = torch.ops.aten.add.Tensor(sum_default_17, 0.0001)
        div_tensor_40 = torch.ops.aten.div.Tensor(mul_tensor_63, add_tensor_40)
        select_int_41 = torch.ops.aten.select.int(relu_default_17, 0, 1)
        mul_tensor_64 = torch.ops.aten.mul.Tensor(upsample_nearest2d_vec_9, select_int_41)
        add_tensor_41 = torch.ops.aten.add.Tensor(sum_default_17, 0.0001);  sum_default_17 = None
        div_tensor_41 = torch.ops.aten.div.Tensor(mul_tensor_64, add_tensor_41)
        stack_default_17 = torch.ops.aten.stack.default([div_tensor_40, div_tensor_41], -1);  div_tensor_40 = div_tensor_41 = None
        sum_dim_int_list_17 = torch.ops.aten.sum.dim_IntList(stack_default_17, [-1]);  stack_default_17 = None
        clone_default_85 = torch.ops.aten.clone.default(sum_dim_int_list_17)
        silu__default_85 = torch.ops.aten.silu_.default(sum_dim_int_list_17);  sum_dim_int_list_17 = None
        convolution_default_154 = torch.ops.aten.convolution.default(silu__default_85, primals_718, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_155 = torch.ops.aten.convolution.default(convolution_default_154, primals_720, primals_719, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_719 = None
        native_batch_norm_default_91 = torch.ops.aten.native_batch_norm.default(convolution_default_155, primals_717, primals_713, primals_715, primals_716, False, 0.01, 0.001);  primals_713 = None
        getitem_293 = native_batch_norm_default_91[0]
        getitem_294 = native_batch_norm_default_91[1]
        getitem_295 = native_batch_norm_default_91[2];  native_batch_norm_default_91 = None
        new_zeros_default_273 = torch.ops.aten.new_zeros.default(convolution_default_155, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_274 = torch.ops.aten.new_zeros.default(convolution_default_155, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_275 = torch.ops.aten.new_zeros.default(convolution_default_155, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_10 = torch.ops.aten.upsample_nearest2d.vec(getitem_293, [40, 40], None)
        relu_default_18 = torch.ops.aten.relu.default(primals_730);  primals_730 = None
        sum_default_18 = torch.ops.aten.sum.default(relu_default_18)
        select_int_42 = torch.ops.aten.select.int(relu_default_18, 0, 0)
        mul_tensor_65 = torch.ops.aten.mul.Tensor(getitem_272, select_int_42)
        add_tensor_42 = torch.ops.aten.add.Tensor(sum_default_18, 0.0001)
        div_tensor_42 = torch.ops.aten.div.Tensor(mul_tensor_65, add_tensor_42)
        select_int_43 = torch.ops.aten.select.int(relu_default_18, 0, 1)
        mul_tensor_66 = torch.ops.aten.mul.Tensor(upsample_nearest2d_vec_10, select_int_43)
        add_tensor_43 = torch.ops.aten.add.Tensor(sum_default_18, 0.0001);  sum_default_18 = None
        div_tensor_43 = torch.ops.aten.div.Tensor(mul_tensor_66, add_tensor_43)
        stack_default_18 = torch.ops.aten.stack.default([div_tensor_42, div_tensor_43], -1);  div_tensor_42 = div_tensor_43 = None
        sum_dim_int_list_18 = torch.ops.aten.sum.dim_IntList(stack_default_18, [-1]);  stack_default_18 = None
        clone_default_86 = torch.ops.aten.clone.default(sum_dim_int_list_18)
        silu__default_86 = torch.ops.aten.silu_.default(sum_dim_int_list_18);  sum_dim_int_list_18 = None
        convolution_default_156 = torch.ops.aten.convolution.default(silu__default_86, primals_727, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_157 = torch.ops.aten.convolution.default(convolution_default_156, primals_729, primals_728, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_728 = None
        native_batch_norm_default_92 = torch.ops.aten.native_batch_norm.default(convolution_default_157, primals_726, primals_722, primals_724, primals_725, False, 0.01, 0.001);  primals_722 = None
        getitem_296 = native_batch_norm_default_92[0]
        getitem_297 = native_batch_norm_default_92[1]
        getitem_298 = native_batch_norm_default_92[2];  native_batch_norm_default_92 = None
        new_zeros_default_276 = torch.ops.aten.new_zeros.default(convolution_default_157, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_277 = torch.ops.aten.new_zeros.default(convolution_default_157, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_278 = torch.ops.aten.new_zeros.default(convolution_default_157, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_11 = torch.ops.aten.upsample_nearest2d.vec(getitem_296, [80, 80], None)
        relu_default_19 = torch.ops.aten.relu.default(primals_739);  primals_739 = None
        sum_default_19 = torch.ops.aten.sum.default(relu_default_19)
        select_int_44 = torch.ops.aten.select.int(relu_default_19, 0, 0)
        mul_tensor_67 = torch.ops.aten.mul.Tensor(getitem_267, select_int_44)
        add_tensor_44 = torch.ops.aten.add.Tensor(sum_default_19, 0.0001)
        div_tensor_44 = torch.ops.aten.div.Tensor(mul_tensor_67, add_tensor_44)
        select_int_45 = torch.ops.aten.select.int(relu_default_19, 0, 1)
        mul_tensor_68 = torch.ops.aten.mul.Tensor(upsample_nearest2d_vec_11, select_int_45)
        add_tensor_45 = torch.ops.aten.add.Tensor(sum_default_19, 0.0001);  sum_default_19 = None
        div_tensor_45 = torch.ops.aten.div.Tensor(mul_tensor_68, add_tensor_45)
        stack_default_19 = torch.ops.aten.stack.default([div_tensor_44, div_tensor_45], -1);  div_tensor_44 = div_tensor_45 = None
        sum_dim_int_list_19 = torch.ops.aten.sum.dim_IntList(stack_default_19, [-1]);  stack_default_19 = None
        clone_default_87 = torch.ops.aten.clone.default(sum_dim_int_list_19)
        silu__default_87 = torch.ops.aten.silu_.default(sum_dim_int_list_19);  sum_dim_int_list_19 = None
        convolution_default_158 = torch.ops.aten.convolution.default(silu__default_87, primals_736, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_159 = torch.ops.aten.convolution.default(convolution_default_158, primals_738, primals_737, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_737 = None
        native_batch_norm_default_93 = torch.ops.aten.native_batch_norm.default(convolution_default_159, primals_735, primals_731, primals_733, primals_734, False, 0.01, 0.001);  primals_731 = None
        getitem_299 = native_batch_norm_default_93[0]
        getitem_300 = native_batch_norm_default_93[1]
        getitem_301 = native_batch_norm_default_93[2];  native_batch_norm_default_93 = None
        new_zeros_default_279 = torch.ops.aten.new_zeros.default(convolution_default_159, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_280 = torch.ops.aten.new_zeros.default(convolution_default_159, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_281 = torch.ops.aten.new_zeros.default(convolution_default_159, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        constant_pad_nd_default_15 = torch.ops.aten.constant_pad_nd.default(getitem_299, [0, 1, 0, 1], -inf)
        max_pool2d_with_indices_default_10 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_15, [3, 3], [2, 2])
        getitem_302 = max_pool2d_with_indices_default_10[0]
        getitem_303 = max_pool2d_with_indices_default_10[1];  max_pool2d_with_indices_default_10 = None
        relu_default_20 = torch.ops.aten.relu.default(primals_748);  primals_748 = None
        sum_default_20 = torch.ops.aten.sum.default(relu_default_20)
        select_int_46 = torch.ops.aten.select.int(relu_default_20, 0, 0)
        mul_tensor_69 = torch.ops.aten.mul.Tensor(getitem_272, select_int_46)
        add_tensor_46 = torch.ops.aten.add.Tensor(sum_default_20, 0.0001)
        div_tensor_46 = torch.ops.aten.div.Tensor(mul_tensor_69, add_tensor_46)
        select_int_47 = torch.ops.aten.select.int(relu_default_20, 0, 1)
        mul_tensor_70 = torch.ops.aten.mul.Tensor(getitem_296, select_int_47)
        add_tensor_47 = torch.ops.aten.add.Tensor(sum_default_20, 0.0001)
        div_tensor_47 = torch.ops.aten.div.Tensor(mul_tensor_70, add_tensor_47)
        select_int_48 = torch.ops.aten.select.int(relu_default_20, 0, 2)
        mul_tensor_71 = torch.ops.aten.mul.Tensor(getitem_302, select_int_48)
        add_tensor_48 = torch.ops.aten.add.Tensor(sum_default_20, 0.0001);  sum_default_20 = None
        div_tensor_48 = torch.ops.aten.div.Tensor(mul_tensor_71, add_tensor_48)
        stack_default_20 = torch.ops.aten.stack.default([div_tensor_46, div_tensor_47, div_tensor_48], -1);  div_tensor_46 = div_tensor_47 = div_tensor_48 = None
        sum_dim_int_list_20 = torch.ops.aten.sum.dim_IntList(stack_default_20, [-1]);  stack_default_20 = None
        clone_default_88 = torch.ops.aten.clone.default(sum_dim_int_list_20)
        silu__default_88 = torch.ops.aten.silu_.default(sum_dim_int_list_20);  sum_dim_int_list_20 = None
        convolution_default_160 = torch.ops.aten.convolution.default(silu__default_88, primals_745, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_161 = torch.ops.aten.convolution.default(convolution_default_160, primals_747, primals_746, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_746 = None
        native_batch_norm_default_94 = torch.ops.aten.native_batch_norm.default(convolution_default_161, primals_744, primals_740, primals_742, primals_743, False, 0.01, 0.001);  primals_740 = None
        getitem_304 = native_batch_norm_default_94[0]
        getitem_305 = native_batch_norm_default_94[1]
        getitem_306 = native_batch_norm_default_94[2];  native_batch_norm_default_94 = None
        new_zeros_default_282 = torch.ops.aten.new_zeros.default(convolution_default_161, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_283 = torch.ops.aten.new_zeros.default(convolution_default_161, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_284 = torch.ops.aten.new_zeros.default(convolution_default_161, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        constant_pad_nd_default_16 = torch.ops.aten.constant_pad_nd.default(getitem_304, [0, 1, 0, 1], -inf)
        max_pool2d_with_indices_default_11 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_16, [3, 3], [2, 2])
        getitem_307 = max_pool2d_with_indices_default_11[0]
        getitem_308 = max_pool2d_with_indices_default_11[1];  max_pool2d_with_indices_default_11 = None
        relu_default_21 = torch.ops.aten.relu.default(primals_757);  primals_757 = None
        sum_default_21 = torch.ops.aten.sum.default(relu_default_21)
        select_int_49 = torch.ops.aten.select.int(relu_default_21, 0, 0)
        mul_tensor_72 = torch.ops.aten.mul.Tensor(getitem_277, select_int_49)
        add_tensor_49 = torch.ops.aten.add.Tensor(sum_default_21, 0.0001)
        div_tensor_49 = torch.ops.aten.div.Tensor(mul_tensor_72, add_tensor_49)
        select_int_50 = torch.ops.aten.select.int(relu_default_21, 0, 1)
        mul_tensor_73 = torch.ops.aten.mul.Tensor(getitem_293, select_int_50)
        add_tensor_50 = torch.ops.aten.add.Tensor(sum_default_21, 0.0001)
        div_tensor_50 = torch.ops.aten.div.Tensor(mul_tensor_73, add_tensor_50)
        select_int_51 = torch.ops.aten.select.int(relu_default_21, 0, 2)
        mul_tensor_74 = torch.ops.aten.mul.Tensor(getitem_307, select_int_51)
        add_tensor_51 = torch.ops.aten.add.Tensor(sum_default_21, 0.0001);  sum_default_21 = None
        div_tensor_51 = torch.ops.aten.div.Tensor(mul_tensor_74, add_tensor_51)
        stack_default_21 = torch.ops.aten.stack.default([div_tensor_49, div_tensor_50, div_tensor_51], -1);  div_tensor_49 = div_tensor_50 = div_tensor_51 = None
        sum_dim_int_list_21 = torch.ops.aten.sum.dim_IntList(stack_default_21, [-1]);  stack_default_21 = None
        clone_default_89 = torch.ops.aten.clone.default(sum_dim_int_list_21)
        silu__default_89 = torch.ops.aten.silu_.default(sum_dim_int_list_21);  sum_dim_int_list_21 = None
        convolution_default_162 = torch.ops.aten.convolution.default(silu__default_89, primals_754, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_163 = torch.ops.aten.convolution.default(convolution_default_162, primals_756, primals_755, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_755 = None
        native_batch_norm_default_95 = torch.ops.aten.native_batch_norm.default(convolution_default_163, primals_753, primals_749, primals_751, primals_752, False, 0.01, 0.001);  primals_749 = None
        getitem_309 = native_batch_norm_default_95[0]
        getitem_310 = native_batch_norm_default_95[1]
        getitem_311 = native_batch_norm_default_95[2];  native_batch_norm_default_95 = None
        new_zeros_default_285 = torch.ops.aten.new_zeros.default(convolution_default_163, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_286 = torch.ops.aten.new_zeros.default(convolution_default_163, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_287 = torch.ops.aten.new_zeros.default(convolution_default_163, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        constant_pad_nd_default_17 = torch.ops.aten.constant_pad_nd.default(getitem_309, [0, 1, 0, 1], -inf)
        max_pool2d_with_indices_default_12 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_17, [3, 3], [2, 2])
        getitem_312 = max_pool2d_with_indices_default_12[0]
        getitem_313 = max_pool2d_with_indices_default_12[1];  max_pool2d_with_indices_default_12 = None
        relu_default_22 = torch.ops.aten.relu.default(primals_766);  primals_766 = None
        sum_default_22 = torch.ops.aten.sum.default(relu_default_22)
        select_int_52 = torch.ops.aten.select.int(relu_default_22, 0, 0)
        mul_tensor_75 = torch.ops.aten.mul.Tensor(getitem_282, select_int_52)
        add_tensor_52 = torch.ops.aten.add.Tensor(sum_default_22, 0.0001)
        div_tensor_52 = torch.ops.aten.div.Tensor(mul_tensor_75, add_tensor_52)
        select_int_53 = torch.ops.aten.select.int(relu_default_22, 0, 1)
        mul_tensor_76 = torch.ops.aten.mul.Tensor(getitem_290, select_int_53)
        add_tensor_53 = torch.ops.aten.add.Tensor(sum_default_22, 0.0001)
        div_tensor_53 = torch.ops.aten.div.Tensor(mul_tensor_76, add_tensor_53)
        select_int_54 = torch.ops.aten.select.int(relu_default_22, 0, 2)
        mul_tensor_77 = torch.ops.aten.mul.Tensor(getitem_312, select_int_54)
        add_tensor_54 = torch.ops.aten.add.Tensor(sum_default_22, 0.0001);  sum_default_22 = None
        div_tensor_54 = torch.ops.aten.div.Tensor(mul_tensor_77, add_tensor_54)
        stack_default_22 = torch.ops.aten.stack.default([div_tensor_52, div_tensor_53, div_tensor_54], -1);  div_tensor_52 = div_tensor_53 = div_tensor_54 = None
        sum_dim_int_list_22 = torch.ops.aten.sum.dim_IntList(stack_default_22, [-1]);  stack_default_22 = None
        clone_default_90 = torch.ops.aten.clone.default(sum_dim_int_list_22)
        silu__default_90 = torch.ops.aten.silu_.default(sum_dim_int_list_22);  sum_dim_int_list_22 = None
        convolution_default_164 = torch.ops.aten.convolution.default(silu__default_90, primals_763, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_165 = torch.ops.aten.convolution.default(convolution_default_164, primals_765, primals_764, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_764 = None
        native_batch_norm_default_96 = torch.ops.aten.native_batch_norm.default(convolution_default_165, primals_762, primals_758, primals_760, primals_761, False, 0.01, 0.001);  primals_758 = None
        getitem_314 = native_batch_norm_default_96[0]
        getitem_315 = native_batch_norm_default_96[1]
        getitem_316 = native_batch_norm_default_96[2];  native_batch_norm_default_96 = None
        new_zeros_default_288 = torch.ops.aten.new_zeros.default(convolution_default_165, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_289 = torch.ops.aten.new_zeros.default(convolution_default_165, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_290 = torch.ops.aten.new_zeros.default(convolution_default_165, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        constant_pad_nd_default_18 = torch.ops.aten.constant_pad_nd.default(getitem_314, [0, 1, 0, 1], -inf)
        max_pool2d_with_indices_default_13 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_18, [3, 3], [2, 2])
        getitem_317 = max_pool2d_with_indices_default_13[0]
        getitem_318 = max_pool2d_with_indices_default_13[1];  max_pool2d_with_indices_default_13 = None
        relu_default_23 = torch.ops.aten.relu.default(primals_775);  primals_775 = None
        sum_default_23 = torch.ops.aten.sum.default(relu_default_23)
        select_int_55 = torch.ops.aten.select.int(relu_default_23, 0, 0)
        mul_tensor_78 = torch.ops.aten.mul.Tensor(getitem_287, select_int_55)
        add_tensor_55 = torch.ops.aten.add.Tensor(sum_default_23, 0.0001)
        div_tensor_55 = torch.ops.aten.div.Tensor(mul_tensor_78, add_tensor_55)
        select_int_56 = torch.ops.aten.select.int(relu_default_23, 0, 1)
        mul_tensor_79 = torch.ops.aten.mul.Tensor(getitem_317, select_int_56)
        add_tensor_56 = torch.ops.aten.add.Tensor(sum_default_23, 0.0001);  sum_default_23 = None
        div_tensor_56 = torch.ops.aten.div.Tensor(mul_tensor_79, add_tensor_56)
        stack_default_23 = torch.ops.aten.stack.default([div_tensor_55, div_tensor_56], -1);  div_tensor_55 = div_tensor_56 = None
        sum_dim_int_list_23 = torch.ops.aten.sum.dim_IntList(stack_default_23, [-1]);  stack_default_23 = None
        clone_default_91 = torch.ops.aten.clone.default(sum_dim_int_list_23)
        silu__default_91 = torch.ops.aten.silu_.default(sum_dim_int_list_23);  sum_dim_int_list_23 = None
        convolution_default_166 = torch.ops.aten.convolution.default(silu__default_91, primals_772, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_167 = torch.ops.aten.convolution.default(convolution_default_166, primals_774, primals_773, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_773 = None
        native_batch_norm_default_97 = torch.ops.aten.native_batch_norm.default(convolution_default_167, primals_771, primals_767, primals_769, primals_770, False, 0.01, 0.001);  primals_767 = None
        getitem_319 = native_batch_norm_default_97[0]
        getitem_320 = native_batch_norm_default_97[1]
        getitem_321 = native_batch_norm_default_97[2];  native_batch_norm_default_97 = None
        new_zeros_default_291 = torch.ops.aten.new_zeros.default(convolution_default_167, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_292 = torch.ops.aten.new_zeros.default(convolution_default_167, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_293 = torch.ops.aten.new_zeros.default(convolution_default_167, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_12 = torch.ops.aten.upsample_nearest2d.vec(getitem_319, [10, 10], None)
        relu_default_24 = torch.ops.aten.relu.default(primals_784);  primals_784 = None
        sum_default_24 = torch.ops.aten.sum.default(relu_default_24)
        select_int_57 = torch.ops.aten.select.int(relu_default_24, 0, 0)
        mul_tensor_80 = torch.ops.aten.mul.Tensor(getitem_314, select_int_57)
        add_tensor_57 = torch.ops.aten.add.Tensor(sum_default_24, 0.0001)
        div_tensor_57 = torch.ops.aten.div.Tensor(mul_tensor_80, add_tensor_57)
        select_int_58 = torch.ops.aten.select.int(relu_default_24, 0, 1)
        mul_tensor_81 = torch.ops.aten.mul.Tensor(upsample_nearest2d_vec_12, select_int_58)
        add_tensor_58 = torch.ops.aten.add.Tensor(sum_default_24, 0.0001);  sum_default_24 = None
        div_tensor_58 = torch.ops.aten.div.Tensor(mul_tensor_81, add_tensor_58)
        stack_default_24 = torch.ops.aten.stack.default([div_tensor_57, div_tensor_58], -1);  div_tensor_57 = div_tensor_58 = None
        sum_dim_int_list_24 = torch.ops.aten.sum.dim_IntList(stack_default_24, [-1]);  stack_default_24 = None
        clone_default_92 = torch.ops.aten.clone.default(sum_dim_int_list_24)
        silu__default_92 = torch.ops.aten.silu_.default(sum_dim_int_list_24);  sum_dim_int_list_24 = None
        convolution_default_168 = torch.ops.aten.convolution.default(silu__default_92, primals_781, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_169 = torch.ops.aten.convolution.default(convolution_default_168, primals_783, primals_782, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_782 = None
        native_batch_norm_default_98 = torch.ops.aten.native_batch_norm.default(convolution_default_169, primals_780, primals_776, primals_778, primals_779, False, 0.01, 0.001);  primals_776 = None
        getitem_322 = native_batch_norm_default_98[0]
        getitem_323 = native_batch_norm_default_98[1]
        getitem_324 = native_batch_norm_default_98[2];  native_batch_norm_default_98 = None
        new_zeros_default_294 = torch.ops.aten.new_zeros.default(convolution_default_169, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_295 = torch.ops.aten.new_zeros.default(convolution_default_169, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_296 = torch.ops.aten.new_zeros.default(convolution_default_169, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_13 = torch.ops.aten.upsample_nearest2d.vec(getitem_322, [20, 20], None)
        relu_default_25 = torch.ops.aten.relu.default(primals_793);  primals_793 = None
        sum_default_25 = torch.ops.aten.sum.default(relu_default_25)
        select_int_59 = torch.ops.aten.select.int(relu_default_25, 0, 0)
        mul_tensor_82 = torch.ops.aten.mul.Tensor(getitem_309, select_int_59)
        add_tensor_59 = torch.ops.aten.add.Tensor(sum_default_25, 0.0001)
        div_tensor_59 = torch.ops.aten.div.Tensor(mul_tensor_82, add_tensor_59)
        select_int_60 = torch.ops.aten.select.int(relu_default_25, 0, 1)
        mul_tensor_83 = torch.ops.aten.mul.Tensor(upsample_nearest2d_vec_13, select_int_60)
        add_tensor_60 = torch.ops.aten.add.Tensor(sum_default_25, 0.0001);  sum_default_25 = None
        div_tensor_60 = torch.ops.aten.div.Tensor(mul_tensor_83, add_tensor_60)
        stack_default_25 = torch.ops.aten.stack.default([div_tensor_59, div_tensor_60], -1);  div_tensor_59 = div_tensor_60 = None
        sum_dim_int_list_25 = torch.ops.aten.sum.dim_IntList(stack_default_25, [-1]);  stack_default_25 = None
        clone_default_93 = torch.ops.aten.clone.default(sum_dim_int_list_25)
        silu__default_93 = torch.ops.aten.silu_.default(sum_dim_int_list_25);  sum_dim_int_list_25 = None
        convolution_default_170 = torch.ops.aten.convolution.default(silu__default_93, primals_790, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_171 = torch.ops.aten.convolution.default(convolution_default_170, primals_792, primals_791, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_791 = None
        native_batch_norm_default_99 = torch.ops.aten.native_batch_norm.default(convolution_default_171, primals_789, primals_785, primals_787, primals_788, False, 0.01, 0.001);  primals_785 = None
        getitem_325 = native_batch_norm_default_99[0]
        getitem_326 = native_batch_norm_default_99[1]
        getitem_327 = native_batch_norm_default_99[2];  native_batch_norm_default_99 = None
        new_zeros_default_297 = torch.ops.aten.new_zeros.default(convolution_default_171, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_298 = torch.ops.aten.new_zeros.default(convolution_default_171, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_299 = torch.ops.aten.new_zeros.default(convolution_default_171, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_14 = torch.ops.aten.upsample_nearest2d.vec(getitem_325, [40, 40], None)
        relu_default_26 = torch.ops.aten.relu.default(primals_802);  primals_802 = None
        sum_default_26 = torch.ops.aten.sum.default(relu_default_26)
        select_int_61 = torch.ops.aten.select.int(relu_default_26, 0, 0)
        mul_tensor_84 = torch.ops.aten.mul.Tensor(getitem_304, select_int_61)
        add_tensor_61 = torch.ops.aten.add.Tensor(sum_default_26, 0.0001)
        div_tensor_61 = torch.ops.aten.div.Tensor(mul_tensor_84, add_tensor_61)
        select_int_62 = torch.ops.aten.select.int(relu_default_26, 0, 1)
        mul_tensor_85 = torch.ops.aten.mul.Tensor(upsample_nearest2d_vec_14, select_int_62)
        add_tensor_62 = torch.ops.aten.add.Tensor(sum_default_26, 0.0001);  sum_default_26 = None
        div_tensor_62 = torch.ops.aten.div.Tensor(mul_tensor_85, add_tensor_62)
        stack_default_26 = torch.ops.aten.stack.default([div_tensor_61, div_tensor_62], -1);  div_tensor_61 = div_tensor_62 = None
        sum_dim_int_list_26 = torch.ops.aten.sum.dim_IntList(stack_default_26, [-1]);  stack_default_26 = None
        clone_default_94 = torch.ops.aten.clone.default(sum_dim_int_list_26)
        silu__default_94 = torch.ops.aten.silu_.default(sum_dim_int_list_26);  sum_dim_int_list_26 = None
        convolution_default_172 = torch.ops.aten.convolution.default(silu__default_94, primals_799, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_173 = torch.ops.aten.convolution.default(convolution_default_172, primals_801, primals_800, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_800 = None
        native_batch_norm_default_100 = torch.ops.aten.native_batch_norm.default(convolution_default_173, primals_798, primals_794, primals_796, primals_797, False, 0.01, 0.001);  primals_794 = None
        getitem_328 = native_batch_norm_default_100[0]
        getitem_329 = native_batch_norm_default_100[1]
        getitem_330 = native_batch_norm_default_100[2];  native_batch_norm_default_100 = None
        new_zeros_default_300 = torch.ops.aten.new_zeros.default(convolution_default_173, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_301 = torch.ops.aten.new_zeros.default(convolution_default_173, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_302 = torch.ops.aten.new_zeros.default(convolution_default_173, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_15 = torch.ops.aten.upsample_nearest2d.vec(getitem_328, [80, 80], None)
        relu_default_27 = torch.ops.aten.relu.default(primals_811);  primals_811 = None
        sum_default_27 = torch.ops.aten.sum.default(relu_default_27)
        select_int_63 = torch.ops.aten.select.int(relu_default_27, 0, 0)
        mul_tensor_86 = torch.ops.aten.mul.Tensor(getitem_299, select_int_63)
        add_tensor_63 = torch.ops.aten.add.Tensor(sum_default_27, 0.0001)
        div_tensor_63 = torch.ops.aten.div.Tensor(mul_tensor_86, add_tensor_63)
        select_int_64 = torch.ops.aten.select.int(relu_default_27, 0, 1)
        mul_tensor_87 = torch.ops.aten.mul.Tensor(upsample_nearest2d_vec_15, select_int_64)
        add_tensor_64 = torch.ops.aten.add.Tensor(sum_default_27, 0.0001);  sum_default_27 = None
        div_tensor_64 = torch.ops.aten.div.Tensor(mul_tensor_87, add_tensor_64)
        stack_default_27 = torch.ops.aten.stack.default([div_tensor_63, div_tensor_64], -1);  div_tensor_63 = div_tensor_64 = None
        sum_dim_int_list_27 = torch.ops.aten.sum.dim_IntList(stack_default_27, [-1]);  stack_default_27 = None
        clone_default_95 = torch.ops.aten.clone.default(sum_dim_int_list_27)
        silu__default_95 = torch.ops.aten.silu_.default(sum_dim_int_list_27);  sum_dim_int_list_27 = None
        convolution_default_174 = torch.ops.aten.convolution.default(silu__default_95, primals_808, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_175 = torch.ops.aten.convolution.default(convolution_default_174, primals_810, primals_809, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_809 = None
        native_batch_norm_default_101 = torch.ops.aten.native_batch_norm.default(convolution_default_175, primals_807, primals_803, primals_805, primals_806, False, 0.01, 0.001);  primals_803 = None
        getitem_331 = native_batch_norm_default_101[0]
        getitem_332 = native_batch_norm_default_101[1]
        getitem_333 = native_batch_norm_default_101[2];  native_batch_norm_default_101 = None
        new_zeros_default_303 = torch.ops.aten.new_zeros.default(convolution_default_175, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_304 = torch.ops.aten.new_zeros.default(convolution_default_175, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_305 = torch.ops.aten.new_zeros.default(convolution_default_175, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        constant_pad_nd_default_19 = torch.ops.aten.constant_pad_nd.default(getitem_331, [0, 1, 0, 1], -inf)
        max_pool2d_with_indices_default_14 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_19, [3, 3], [2, 2])
        getitem_334 = max_pool2d_with_indices_default_14[0]
        getitem_335 = max_pool2d_with_indices_default_14[1];  max_pool2d_with_indices_default_14 = None
        relu_default_28 = torch.ops.aten.relu.default(primals_820);  primals_820 = None
        sum_default_28 = torch.ops.aten.sum.default(relu_default_28)
        select_int_65 = torch.ops.aten.select.int(relu_default_28, 0, 0)
        mul_tensor_88 = torch.ops.aten.mul.Tensor(getitem_304, select_int_65)
        add_tensor_65 = torch.ops.aten.add.Tensor(sum_default_28, 0.0001)
        div_tensor_65 = torch.ops.aten.div.Tensor(mul_tensor_88, add_tensor_65)
        select_int_66 = torch.ops.aten.select.int(relu_default_28, 0, 1)
        mul_tensor_89 = torch.ops.aten.mul.Tensor(getitem_328, select_int_66)
        add_tensor_66 = torch.ops.aten.add.Tensor(sum_default_28, 0.0001)
        div_tensor_66 = torch.ops.aten.div.Tensor(mul_tensor_89, add_tensor_66)
        select_int_67 = torch.ops.aten.select.int(relu_default_28, 0, 2)
        mul_tensor_90 = torch.ops.aten.mul.Tensor(getitem_334, select_int_67)
        add_tensor_67 = torch.ops.aten.add.Tensor(sum_default_28, 0.0001);  sum_default_28 = None
        div_tensor_67 = torch.ops.aten.div.Tensor(mul_tensor_90, add_tensor_67)
        stack_default_28 = torch.ops.aten.stack.default([div_tensor_65, div_tensor_66, div_tensor_67], -1);  div_tensor_65 = div_tensor_66 = div_tensor_67 = None
        sum_dim_int_list_28 = torch.ops.aten.sum.dim_IntList(stack_default_28, [-1]);  stack_default_28 = None
        clone_default_96 = torch.ops.aten.clone.default(sum_dim_int_list_28)
        silu__default_96 = torch.ops.aten.silu_.default(sum_dim_int_list_28);  sum_dim_int_list_28 = None
        convolution_default_176 = torch.ops.aten.convolution.default(silu__default_96, primals_817, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_177 = torch.ops.aten.convolution.default(convolution_default_176, primals_819, primals_818, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_818 = None
        native_batch_norm_default_102 = torch.ops.aten.native_batch_norm.default(convolution_default_177, primals_816, primals_812, primals_814, primals_815, False, 0.01, 0.001);  primals_812 = None
        getitem_336 = native_batch_norm_default_102[0]
        getitem_337 = native_batch_norm_default_102[1]
        getitem_338 = native_batch_norm_default_102[2];  native_batch_norm_default_102 = None
        new_zeros_default_306 = torch.ops.aten.new_zeros.default(convolution_default_177, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_307 = torch.ops.aten.new_zeros.default(convolution_default_177, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_308 = torch.ops.aten.new_zeros.default(convolution_default_177, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        constant_pad_nd_default_20 = torch.ops.aten.constant_pad_nd.default(getitem_336, [0, 1, 0, 1], -inf)
        max_pool2d_with_indices_default_15 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_20, [3, 3], [2, 2])
        getitem_339 = max_pool2d_with_indices_default_15[0]
        getitem_340 = max_pool2d_with_indices_default_15[1];  max_pool2d_with_indices_default_15 = None
        relu_default_29 = torch.ops.aten.relu.default(primals_829);  primals_829 = None
        sum_default_29 = torch.ops.aten.sum.default(relu_default_29)
        select_int_68 = torch.ops.aten.select.int(relu_default_29, 0, 0)
        mul_tensor_91 = torch.ops.aten.mul.Tensor(getitem_309, select_int_68)
        add_tensor_68 = torch.ops.aten.add.Tensor(sum_default_29, 0.0001)
        div_tensor_68 = torch.ops.aten.div.Tensor(mul_tensor_91, add_tensor_68)
        select_int_69 = torch.ops.aten.select.int(relu_default_29, 0, 1)
        mul_tensor_92 = torch.ops.aten.mul.Tensor(getitem_325, select_int_69)
        add_tensor_69 = torch.ops.aten.add.Tensor(sum_default_29, 0.0001)
        div_tensor_69 = torch.ops.aten.div.Tensor(mul_tensor_92, add_tensor_69)
        select_int_70 = torch.ops.aten.select.int(relu_default_29, 0, 2)
        mul_tensor_93 = torch.ops.aten.mul.Tensor(getitem_339, select_int_70)
        add_tensor_70 = torch.ops.aten.add.Tensor(sum_default_29, 0.0001);  sum_default_29 = None
        div_tensor_70 = torch.ops.aten.div.Tensor(mul_tensor_93, add_tensor_70)
        stack_default_29 = torch.ops.aten.stack.default([div_tensor_68, div_tensor_69, div_tensor_70], -1);  div_tensor_68 = div_tensor_69 = div_tensor_70 = None
        sum_dim_int_list_29 = torch.ops.aten.sum.dim_IntList(stack_default_29, [-1]);  stack_default_29 = None
        clone_default_97 = torch.ops.aten.clone.default(sum_dim_int_list_29)
        silu__default_97 = torch.ops.aten.silu_.default(sum_dim_int_list_29);  sum_dim_int_list_29 = None
        convolution_default_178 = torch.ops.aten.convolution.default(silu__default_97, primals_826, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_179 = torch.ops.aten.convolution.default(convolution_default_178, primals_828, primals_827, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_827 = None
        native_batch_norm_default_103 = torch.ops.aten.native_batch_norm.default(convolution_default_179, primals_825, primals_821, primals_823, primals_824, False, 0.01, 0.001);  primals_821 = None
        getitem_341 = native_batch_norm_default_103[0]
        getitem_342 = native_batch_norm_default_103[1]
        getitem_343 = native_batch_norm_default_103[2];  native_batch_norm_default_103 = None
        new_zeros_default_309 = torch.ops.aten.new_zeros.default(convolution_default_179, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_310 = torch.ops.aten.new_zeros.default(convolution_default_179, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_311 = torch.ops.aten.new_zeros.default(convolution_default_179, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        constant_pad_nd_default_21 = torch.ops.aten.constant_pad_nd.default(getitem_341, [0, 1, 0, 1], -inf)
        max_pool2d_with_indices_default_16 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_21, [3, 3], [2, 2])
        getitem_344 = max_pool2d_with_indices_default_16[0]
        getitem_345 = max_pool2d_with_indices_default_16[1];  max_pool2d_with_indices_default_16 = None
        relu_default_30 = torch.ops.aten.relu.default(primals_838);  primals_838 = None
        sum_default_30 = torch.ops.aten.sum.default(relu_default_30)
        select_int_71 = torch.ops.aten.select.int(relu_default_30, 0, 0)
        mul_tensor_94 = torch.ops.aten.mul.Tensor(getitem_314, select_int_71)
        add_tensor_71 = torch.ops.aten.add.Tensor(sum_default_30, 0.0001)
        div_tensor_71 = torch.ops.aten.div.Tensor(mul_tensor_94, add_tensor_71)
        select_int_72 = torch.ops.aten.select.int(relu_default_30, 0, 1)
        mul_tensor_95 = torch.ops.aten.mul.Tensor(getitem_322, select_int_72)
        add_tensor_72 = torch.ops.aten.add.Tensor(sum_default_30, 0.0001)
        div_tensor_72 = torch.ops.aten.div.Tensor(mul_tensor_95, add_tensor_72)
        select_int_73 = torch.ops.aten.select.int(relu_default_30, 0, 2)
        mul_tensor_96 = torch.ops.aten.mul.Tensor(getitem_344, select_int_73)
        add_tensor_73 = torch.ops.aten.add.Tensor(sum_default_30, 0.0001);  sum_default_30 = None
        div_tensor_73 = torch.ops.aten.div.Tensor(mul_tensor_96, add_tensor_73)
        stack_default_30 = torch.ops.aten.stack.default([div_tensor_71, div_tensor_72, div_tensor_73], -1);  div_tensor_71 = div_tensor_72 = div_tensor_73 = None
        sum_dim_int_list_30 = torch.ops.aten.sum.dim_IntList(stack_default_30, [-1]);  stack_default_30 = None
        clone_default_98 = torch.ops.aten.clone.default(sum_dim_int_list_30)
        silu__default_98 = torch.ops.aten.silu_.default(sum_dim_int_list_30);  sum_dim_int_list_30 = None
        convolution_default_180 = torch.ops.aten.convolution.default(silu__default_98, primals_835, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_181 = torch.ops.aten.convolution.default(convolution_default_180, primals_837, primals_836, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_836 = None
        native_batch_norm_default_104 = torch.ops.aten.native_batch_norm.default(convolution_default_181, primals_834, primals_830, primals_832, primals_833, False, 0.01, 0.001);  primals_830 = None
        getitem_346 = native_batch_norm_default_104[0]
        getitem_347 = native_batch_norm_default_104[1]
        getitem_348 = native_batch_norm_default_104[2];  native_batch_norm_default_104 = None
        new_zeros_default_312 = torch.ops.aten.new_zeros.default(convolution_default_181, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_313 = torch.ops.aten.new_zeros.default(convolution_default_181, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_314 = torch.ops.aten.new_zeros.default(convolution_default_181, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        constant_pad_nd_default_22 = torch.ops.aten.constant_pad_nd.default(getitem_346, [0, 1, 0, 1], -inf)
        max_pool2d_with_indices_default_17 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_22, [3, 3], [2, 2])
        getitem_349 = max_pool2d_with_indices_default_17[0]
        getitem_350 = max_pool2d_with_indices_default_17[1];  max_pool2d_with_indices_default_17 = None
        relu_default_31 = torch.ops.aten.relu.default(primals_847);  primals_847 = None
        sum_default_31 = torch.ops.aten.sum.default(relu_default_31)
        select_int_74 = torch.ops.aten.select.int(relu_default_31, 0, 0)
        mul_tensor_97 = torch.ops.aten.mul.Tensor(getitem_319, select_int_74)
        add_tensor_74 = torch.ops.aten.add.Tensor(sum_default_31, 0.0001)
        div_tensor_74 = torch.ops.aten.div.Tensor(mul_tensor_97, add_tensor_74)
        select_int_75 = torch.ops.aten.select.int(relu_default_31, 0, 1)
        mul_tensor_98 = torch.ops.aten.mul.Tensor(getitem_349, select_int_75)
        add_tensor_75 = torch.ops.aten.add.Tensor(sum_default_31, 0.0001);  sum_default_31 = None
        div_tensor_75 = torch.ops.aten.div.Tensor(mul_tensor_98, add_tensor_75)
        stack_default_31 = torch.ops.aten.stack.default([div_tensor_74, div_tensor_75], -1);  div_tensor_74 = div_tensor_75 = None
        sum_dim_int_list_31 = torch.ops.aten.sum.dim_IntList(stack_default_31, [-1]);  stack_default_31 = None
        clone_default_99 = torch.ops.aten.clone.default(sum_dim_int_list_31)
        silu__default_99 = torch.ops.aten.silu_.default(sum_dim_int_list_31);  sum_dim_int_list_31 = None
        convolution_default_182 = torch.ops.aten.convolution.default(silu__default_99, primals_844, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_183 = torch.ops.aten.convolution.default(convolution_default_182, primals_846, primals_845, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_845 = None
        native_batch_norm_default_105 = torch.ops.aten.native_batch_norm.default(convolution_default_183, primals_843, primals_839, primals_841, primals_842, False, 0.01, 0.001);  primals_839 = None
        getitem_351 = native_batch_norm_default_105[0]
        getitem_352 = native_batch_norm_default_105[1]
        getitem_353 = native_batch_norm_default_105[2];  native_batch_norm_default_105 = None
        new_zeros_default_315 = torch.ops.aten.new_zeros.default(convolution_default_183, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_316 = torch.ops.aten.new_zeros.default(convolution_default_183, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_317 = torch.ops.aten.new_zeros.default(convolution_default_183, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_184 = torch.ops.aten.convolution.default(getitem_331, primals_513, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_185 = torch.ops.aten.convolution.default(convolution_default_184, primals_515, primals_514, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_106 = torch.ops.aten.native_batch_norm.default(convolution_default_185, primals_859, primals_855, primals_857, primals_858, False, 0.01, 0.001);  primals_855 = None
        getitem_354 = native_batch_norm_default_106[0]
        getitem_355 = native_batch_norm_default_106[1]
        getitem_356 = native_batch_norm_default_106[2];  native_batch_norm_default_106 = None
        new_zeros_default_318 = torch.ops.aten.new_zeros.default(convolution_default_185, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_319 = torch.ops.aten.new_zeros.default(convolution_default_185, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_320 = torch.ops.aten.new_zeros.default(convolution_default_185, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_100 = torch.ops.aten.clone.default(getitem_354)
        silu__default_100 = torch.ops.aten.silu_.default(getitem_354);  getitem_354 = None
        convolution_default_186 = torch.ops.aten.convolution.default(silu__default_100, primals_516, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_187 = torch.ops.aten.convolution.default(convolution_default_186, primals_518, primals_517, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_107 = torch.ops.aten.native_batch_norm.default(convolution_default_187, primals_864, primals_860, primals_862, primals_863, False, 0.01, 0.001);  primals_860 = None
        getitem_357 = native_batch_norm_default_107[0]
        getitem_358 = native_batch_norm_default_107[1]
        getitem_359 = native_batch_norm_default_107[2];  native_batch_norm_default_107 = None
        new_zeros_default_321 = torch.ops.aten.new_zeros.default(convolution_default_187, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_322 = torch.ops.aten.new_zeros.default(convolution_default_187, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_323 = torch.ops.aten.new_zeros.default(convolution_default_187, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_101 = torch.ops.aten.clone.default(getitem_357)
        silu__default_101 = torch.ops.aten.silu_.default(getitem_357);  getitem_357 = None
        convolution_default_188 = torch.ops.aten.convolution.default(silu__default_101, primals_519, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_189 = torch.ops.aten.convolution.default(convolution_default_188, primals_521, primals_520, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_108 = torch.ops.aten.native_batch_norm.default(convolution_default_189, primals_869, primals_865, primals_867, primals_868, False, 0.01, 0.001);  primals_865 = None
        getitem_360 = native_batch_norm_default_108[0]
        getitem_361 = native_batch_norm_default_108[1]
        getitem_362 = native_batch_norm_default_108[2];  native_batch_norm_default_108 = None
        new_zeros_default_324 = torch.ops.aten.new_zeros.default(convolution_default_189, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_325 = torch.ops.aten.new_zeros.default(convolution_default_189, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_326 = torch.ops.aten.new_zeros.default(convolution_default_189, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_102 = torch.ops.aten.clone.default(getitem_360)
        silu__default_102 = torch.ops.aten.silu_.default(getitem_360);  getitem_360 = None
        convolution_default_190 = torch.ops.aten.convolution.default(silu__default_102, primals_522, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_191 = torch.ops.aten.convolution.default(convolution_default_190, primals_524, primals_523, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_192 = torch.ops.aten.convolution.default(getitem_336, primals_513, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_193 = torch.ops.aten.convolution.default(convolution_default_192, primals_515, primals_514, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_109 = torch.ops.aten.native_batch_norm.default(convolution_default_193, primals_889, primals_885, primals_887, primals_888, False, 0.01, 0.001);  primals_885 = None
        getitem_363 = native_batch_norm_default_109[0]
        getitem_364 = native_batch_norm_default_109[1]
        getitem_365 = native_batch_norm_default_109[2];  native_batch_norm_default_109 = None
        new_zeros_default_327 = torch.ops.aten.new_zeros.default(convolution_default_193, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_328 = torch.ops.aten.new_zeros.default(convolution_default_193, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_329 = torch.ops.aten.new_zeros.default(convolution_default_193, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_103 = torch.ops.aten.clone.default(getitem_363)
        silu__default_103 = torch.ops.aten.silu_.default(getitem_363);  getitem_363 = None
        convolution_default_194 = torch.ops.aten.convolution.default(silu__default_103, primals_516, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_195 = torch.ops.aten.convolution.default(convolution_default_194, primals_518, primals_517, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_110 = torch.ops.aten.native_batch_norm.default(convolution_default_195, primals_894, primals_890, primals_892, primals_893, False, 0.01, 0.001);  primals_890 = None
        getitem_366 = native_batch_norm_default_110[0]
        getitem_367 = native_batch_norm_default_110[1]
        getitem_368 = native_batch_norm_default_110[2];  native_batch_norm_default_110 = None
        new_zeros_default_330 = torch.ops.aten.new_zeros.default(convolution_default_195, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_331 = torch.ops.aten.new_zeros.default(convolution_default_195, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_332 = torch.ops.aten.new_zeros.default(convolution_default_195, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_104 = torch.ops.aten.clone.default(getitem_366)
        silu__default_104 = torch.ops.aten.silu_.default(getitem_366);  getitem_366 = None
        convolution_default_196 = torch.ops.aten.convolution.default(silu__default_104, primals_519, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_197 = torch.ops.aten.convolution.default(convolution_default_196, primals_521, primals_520, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_111 = torch.ops.aten.native_batch_norm.default(convolution_default_197, primals_899, primals_895, primals_897, primals_898, False, 0.01, 0.001);  primals_895 = None
        getitem_369 = native_batch_norm_default_111[0]
        getitem_370 = native_batch_norm_default_111[1]
        getitem_371 = native_batch_norm_default_111[2];  native_batch_norm_default_111 = None
        new_zeros_default_333 = torch.ops.aten.new_zeros.default(convolution_default_197, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_334 = torch.ops.aten.new_zeros.default(convolution_default_197, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_335 = torch.ops.aten.new_zeros.default(convolution_default_197, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_105 = torch.ops.aten.clone.default(getitem_369)
        silu__default_105 = torch.ops.aten.silu_.default(getitem_369);  getitem_369 = None
        convolution_default_198 = torch.ops.aten.convolution.default(silu__default_105, primals_522, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_199 = torch.ops.aten.convolution.default(convolution_default_198, primals_524, primals_523, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_200 = torch.ops.aten.convolution.default(getitem_341, primals_513, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_201 = torch.ops.aten.convolution.default(convolution_default_200, primals_515, primals_514, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_112 = torch.ops.aten.native_batch_norm.default(convolution_default_201, primals_919, primals_915, primals_917, primals_918, False, 0.01, 0.001);  primals_915 = None
        getitem_372 = native_batch_norm_default_112[0]
        getitem_373 = native_batch_norm_default_112[1]
        getitem_374 = native_batch_norm_default_112[2];  native_batch_norm_default_112 = None
        new_zeros_default_336 = torch.ops.aten.new_zeros.default(convolution_default_201, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_337 = torch.ops.aten.new_zeros.default(convolution_default_201, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_338 = torch.ops.aten.new_zeros.default(convolution_default_201, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_106 = torch.ops.aten.clone.default(getitem_372)
        silu__default_106 = torch.ops.aten.silu_.default(getitem_372);  getitem_372 = None
        convolution_default_202 = torch.ops.aten.convolution.default(silu__default_106, primals_516, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_203 = torch.ops.aten.convolution.default(convolution_default_202, primals_518, primals_517, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_113 = torch.ops.aten.native_batch_norm.default(convolution_default_203, primals_924, primals_920, primals_922, primals_923, False, 0.01, 0.001);  primals_920 = None
        getitem_375 = native_batch_norm_default_113[0]
        getitem_376 = native_batch_norm_default_113[1]
        getitem_377 = native_batch_norm_default_113[2];  native_batch_norm_default_113 = None
        new_zeros_default_339 = torch.ops.aten.new_zeros.default(convolution_default_203, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_340 = torch.ops.aten.new_zeros.default(convolution_default_203, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_341 = torch.ops.aten.new_zeros.default(convolution_default_203, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_107 = torch.ops.aten.clone.default(getitem_375)
        silu__default_107 = torch.ops.aten.silu_.default(getitem_375);  getitem_375 = None
        convolution_default_204 = torch.ops.aten.convolution.default(silu__default_107, primals_519, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_205 = torch.ops.aten.convolution.default(convolution_default_204, primals_521, primals_520, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_114 = torch.ops.aten.native_batch_norm.default(convolution_default_205, primals_929, primals_925, primals_927, primals_928, False, 0.01, 0.001);  primals_925 = None
        getitem_378 = native_batch_norm_default_114[0]
        getitem_379 = native_batch_norm_default_114[1]
        getitem_380 = native_batch_norm_default_114[2];  native_batch_norm_default_114 = None
        new_zeros_default_342 = torch.ops.aten.new_zeros.default(convolution_default_205, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_343 = torch.ops.aten.new_zeros.default(convolution_default_205, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_344 = torch.ops.aten.new_zeros.default(convolution_default_205, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_108 = torch.ops.aten.clone.default(getitem_378)
        silu__default_108 = torch.ops.aten.silu_.default(getitem_378);  getitem_378 = None
        convolution_default_206 = torch.ops.aten.convolution.default(silu__default_108, primals_522, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_207 = torch.ops.aten.convolution.default(convolution_default_206, primals_524, primals_523, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_208 = torch.ops.aten.convolution.default(getitem_346, primals_513, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_209 = torch.ops.aten.convolution.default(convolution_default_208, primals_515, primals_514, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_115 = torch.ops.aten.native_batch_norm.default(convolution_default_209, primals_949, primals_945, primals_947, primals_948, False, 0.01, 0.001);  primals_945 = None
        getitem_381 = native_batch_norm_default_115[0]
        getitem_382 = native_batch_norm_default_115[1]
        getitem_383 = native_batch_norm_default_115[2];  native_batch_norm_default_115 = None
        new_zeros_default_345 = torch.ops.aten.new_zeros.default(convolution_default_209, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_346 = torch.ops.aten.new_zeros.default(convolution_default_209, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_347 = torch.ops.aten.new_zeros.default(convolution_default_209, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_109 = torch.ops.aten.clone.default(getitem_381)
        silu__default_109 = torch.ops.aten.silu_.default(getitem_381);  getitem_381 = None
        convolution_default_210 = torch.ops.aten.convolution.default(silu__default_109, primals_516, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_211 = torch.ops.aten.convolution.default(convolution_default_210, primals_518, primals_517, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_116 = torch.ops.aten.native_batch_norm.default(convolution_default_211, primals_954, primals_950, primals_952, primals_953, False, 0.01, 0.001);  primals_950 = None
        getitem_384 = native_batch_norm_default_116[0]
        getitem_385 = native_batch_norm_default_116[1]
        getitem_386 = native_batch_norm_default_116[2];  native_batch_norm_default_116 = None
        new_zeros_default_348 = torch.ops.aten.new_zeros.default(convolution_default_211, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_349 = torch.ops.aten.new_zeros.default(convolution_default_211, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_350 = torch.ops.aten.new_zeros.default(convolution_default_211, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_110 = torch.ops.aten.clone.default(getitem_384)
        silu__default_110 = torch.ops.aten.silu_.default(getitem_384);  getitem_384 = None
        convolution_default_212 = torch.ops.aten.convolution.default(silu__default_110, primals_519, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_213 = torch.ops.aten.convolution.default(convolution_default_212, primals_521, primals_520, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_117 = torch.ops.aten.native_batch_norm.default(convolution_default_213, primals_959, primals_955, primals_957, primals_958, False, 0.01, 0.001);  primals_955 = None
        getitem_387 = native_batch_norm_default_117[0]
        getitem_388 = native_batch_norm_default_117[1]
        getitem_389 = native_batch_norm_default_117[2];  native_batch_norm_default_117 = None
        new_zeros_default_351 = torch.ops.aten.new_zeros.default(convolution_default_213, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_352 = torch.ops.aten.new_zeros.default(convolution_default_213, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_353 = torch.ops.aten.new_zeros.default(convolution_default_213, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_111 = torch.ops.aten.clone.default(getitem_387)
        silu__default_111 = torch.ops.aten.silu_.default(getitem_387);  getitem_387 = None
        convolution_default_214 = torch.ops.aten.convolution.default(silu__default_111, primals_522, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_215 = torch.ops.aten.convolution.default(convolution_default_214, primals_524, primals_523, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_216 = torch.ops.aten.convolution.default(getitem_351, primals_513, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_217 = torch.ops.aten.convolution.default(convolution_default_216, primals_515, primals_514, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_514 = None
        native_batch_norm_default_118 = torch.ops.aten.native_batch_norm.default(convolution_default_217, primals_979, primals_975, primals_977, primals_978, False, 0.01, 0.001);  primals_975 = None
        getitem_390 = native_batch_norm_default_118[0]
        getitem_391 = native_batch_norm_default_118[1]
        getitem_392 = native_batch_norm_default_118[2];  native_batch_norm_default_118 = None
        new_zeros_default_354 = torch.ops.aten.new_zeros.default(convolution_default_217, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_355 = torch.ops.aten.new_zeros.default(convolution_default_217, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_356 = torch.ops.aten.new_zeros.default(convolution_default_217, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_112 = torch.ops.aten.clone.default(getitem_390)
        silu__default_112 = torch.ops.aten.silu_.default(getitem_390);  getitem_390 = None
        convolution_default_218 = torch.ops.aten.convolution.default(silu__default_112, primals_516, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_219 = torch.ops.aten.convolution.default(convolution_default_218, primals_518, primals_517, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_517 = None
        native_batch_norm_default_119 = torch.ops.aten.native_batch_norm.default(convolution_default_219, primals_984, primals_980, primals_982, primals_983, False, 0.01, 0.001);  primals_980 = None
        getitem_393 = native_batch_norm_default_119[0]
        getitem_394 = native_batch_norm_default_119[1]
        getitem_395 = native_batch_norm_default_119[2];  native_batch_norm_default_119 = None
        new_zeros_default_357 = torch.ops.aten.new_zeros.default(convolution_default_219, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_358 = torch.ops.aten.new_zeros.default(convolution_default_219, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_359 = torch.ops.aten.new_zeros.default(convolution_default_219, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_113 = torch.ops.aten.clone.default(getitem_393)
        silu__default_113 = torch.ops.aten.silu_.default(getitem_393);  getitem_393 = None
        convolution_default_220 = torch.ops.aten.convolution.default(silu__default_113, primals_519, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_221 = torch.ops.aten.convolution.default(convolution_default_220, primals_521, primals_520, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_520 = None
        native_batch_norm_default_120 = torch.ops.aten.native_batch_norm.default(convolution_default_221, primals_989, primals_985, primals_987, primals_988, False, 0.01, 0.001);  primals_985 = None
        getitem_396 = native_batch_norm_default_120[0]
        getitem_397 = native_batch_norm_default_120[1]
        getitem_398 = native_batch_norm_default_120[2];  native_batch_norm_default_120 = None
        new_zeros_default_360 = torch.ops.aten.new_zeros.default(convolution_default_221, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_361 = torch.ops.aten.new_zeros.default(convolution_default_221, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_362 = torch.ops.aten.new_zeros.default(convolution_default_221, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_114 = torch.ops.aten.clone.default(getitem_396)
        silu__default_114 = torch.ops.aten.silu_.default(getitem_396);  getitem_396 = None
        convolution_default_222 = torch.ops.aten.convolution.default(silu__default_114, primals_522, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_223 = torch.ops.aten.convolution.default(convolution_default_222, primals_524, primals_523, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_523 = None
        convolution_default_224 = torch.ops.aten.convolution.default(getitem_331, primals_501, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_225 = torch.ops.aten.convolution.default(convolution_default_224, primals_503, primals_502, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_121 = torch.ops.aten.native_batch_norm.default(convolution_default_225, primals_874, primals_870, primals_872, primals_873, False, 0.01, 0.001);  primals_870 = None
        getitem_399 = native_batch_norm_default_121[0]
        getitem_400 = native_batch_norm_default_121[1]
        getitem_401 = native_batch_norm_default_121[2];  native_batch_norm_default_121 = None
        new_zeros_default_363 = torch.ops.aten.new_zeros.default(convolution_default_225, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_364 = torch.ops.aten.new_zeros.default(convolution_default_225, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_365 = torch.ops.aten.new_zeros.default(convolution_default_225, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_115 = torch.ops.aten.clone.default(getitem_399)
        silu__default_115 = torch.ops.aten.silu_.default(getitem_399);  getitem_399 = None
        convolution_default_226 = torch.ops.aten.convolution.default(silu__default_115, primals_504, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_227 = torch.ops.aten.convolution.default(convolution_default_226, primals_506, primals_505, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_122 = torch.ops.aten.native_batch_norm.default(convolution_default_227, primals_879, primals_875, primals_877, primals_878, False, 0.01, 0.001);  primals_875 = None
        getitem_402 = native_batch_norm_default_122[0]
        getitem_403 = native_batch_norm_default_122[1]
        getitem_404 = native_batch_norm_default_122[2];  native_batch_norm_default_122 = None
        new_zeros_default_366 = torch.ops.aten.new_zeros.default(convolution_default_227, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_367 = torch.ops.aten.new_zeros.default(convolution_default_227, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_368 = torch.ops.aten.new_zeros.default(convolution_default_227, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_116 = torch.ops.aten.clone.default(getitem_402)
        silu__default_116 = torch.ops.aten.silu_.default(getitem_402);  getitem_402 = None
        convolution_default_228 = torch.ops.aten.convolution.default(silu__default_116, primals_507, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_229 = torch.ops.aten.convolution.default(convolution_default_228, primals_509, primals_508, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_123 = torch.ops.aten.native_batch_norm.default(convolution_default_229, primals_884, primals_880, primals_882, primals_883, False, 0.01, 0.001);  primals_880 = None
        getitem_405 = native_batch_norm_default_123[0]
        getitem_406 = native_batch_norm_default_123[1]
        getitem_407 = native_batch_norm_default_123[2];  native_batch_norm_default_123 = None
        new_zeros_default_369 = torch.ops.aten.new_zeros.default(convolution_default_229, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_370 = torch.ops.aten.new_zeros.default(convolution_default_229, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_371 = torch.ops.aten.new_zeros.default(convolution_default_229, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_117 = torch.ops.aten.clone.default(getitem_405)
        silu__default_117 = torch.ops.aten.silu_.default(getitem_405);  getitem_405 = None
        convolution_default_230 = torch.ops.aten.convolution.default(silu__default_117, primals_510, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_231 = torch.ops.aten.convolution.default(convolution_default_230, primals_512, primals_511, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_232 = torch.ops.aten.convolution.default(getitem_336, primals_501, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_233 = torch.ops.aten.convolution.default(convolution_default_232, primals_503, primals_502, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_124 = torch.ops.aten.native_batch_norm.default(convolution_default_233, primals_904, primals_900, primals_902, primals_903, False, 0.01, 0.001);  primals_900 = None
        getitem_408 = native_batch_norm_default_124[0]
        getitem_409 = native_batch_norm_default_124[1]
        getitem_410 = native_batch_norm_default_124[2];  native_batch_norm_default_124 = None
        new_zeros_default_372 = torch.ops.aten.new_zeros.default(convolution_default_233, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_373 = torch.ops.aten.new_zeros.default(convolution_default_233, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_374 = torch.ops.aten.new_zeros.default(convolution_default_233, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_118 = torch.ops.aten.clone.default(getitem_408)
        silu__default_118 = torch.ops.aten.silu_.default(getitem_408);  getitem_408 = None
        convolution_default_234 = torch.ops.aten.convolution.default(silu__default_118, primals_504, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_235 = torch.ops.aten.convolution.default(convolution_default_234, primals_506, primals_505, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_125 = torch.ops.aten.native_batch_norm.default(convolution_default_235, primals_909, primals_905, primals_907, primals_908, False, 0.01, 0.001);  primals_905 = None
        getitem_411 = native_batch_norm_default_125[0]
        getitem_412 = native_batch_norm_default_125[1]
        getitem_413 = native_batch_norm_default_125[2];  native_batch_norm_default_125 = None
        new_zeros_default_375 = torch.ops.aten.new_zeros.default(convolution_default_235, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_376 = torch.ops.aten.new_zeros.default(convolution_default_235, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_377 = torch.ops.aten.new_zeros.default(convolution_default_235, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_119 = torch.ops.aten.clone.default(getitem_411)
        silu__default_119 = torch.ops.aten.silu_.default(getitem_411);  getitem_411 = None
        convolution_default_236 = torch.ops.aten.convolution.default(silu__default_119, primals_507, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_237 = torch.ops.aten.convolution.default(convolution_default_236, primals_509, primals_508, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_126 = torch.ops.aten.native_batch_norm.default(convolution_default_237, primals_914, primals_910, primals_912, primals_913, False, 0.01, 0.001);  primals_910 = None
        getitem_414 = native_batch_norm_default_126[0]
        getitem_415 = native_batch_norm_default_126[1]
        getitem_416 = native_batch_norm_default_126[2];  native_batch_norm_default_126 = None
        new_zeros_default_378 = torch.ops.aten.new_zeros.default(convolution_default_237, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_379 = torch.ops.aten.new_zeros.default(convolution_default_237, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_380 = torch.ops.aten.new_zeros.default(convolution_default_237, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_120 = torch.ops.aten.clone.default(getitem_414)
        silu__default_120 = torch.ops.aten.silu_.default(getitem_414);  getitem_414 = None
        convolution_default_238 = torch.ops.aten.convolution.default(silu__default_120, primals_510, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_239 = torch.ops.aten.convolution.default(convolution_default_238, primals_512, primals_511, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_240 = torch.ops.aten.convolution.default(getitem_341, primals_501, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_241 = torch.ops.aten.convolution.default(convolution_default_240, primals_503, primals_502, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_127 = torch.ops.aten.native_batch_norm.default(convolution_default_241, primals_934, primals_930, primals_932, primals_933, False, 0.01, 0.001);  primals_930 = None
        getitem_417 = native_batch_norm_default_127[0]
        getitem_418 = native_batch_norm_default_127[1]
        getitem_419 = native_batch_norm_default_127[2];  native_batch_norm_default_127 = None
        new_zeros_default_381 = torch.ops.aten.new_zeros.default(convolution_default_241, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_382 = torch.ops.aten.new_zeros.default(convolution_default_241, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_383 = torch.ops.aten.new_zeros.default(convolution_default_241, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_121 = torch.ops.aten.clone.default(getitem_417)
        silu__default_121 = torch.ops.aten.silu_.default(getitem_417);  getitem_417 = None
        convolution_default_242 = torch.ops.aten.convolution.default(silu__default_121, primals_504, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_243 = torch.ops.aten.convolution.default(convolution_default_242, primals_506, primals_505, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_128 = torch.ops.aten.native_batch_norm.default(convolution_default_243, primals_939, primals_935, primals_937, primals_938, False, 0.01, 0.001);  primals_935 = None
        getitem_420 = native_batch_norm_default_128[0]
        getitem_421 = native_batch_norm_default_128[1]
        getitem_422 = native_batch_norm_default_128[2];  native_batch_norm_default_128 = None
        new_zeros_default_384 = torch.ops.aten.new_zeros.default(convolution_default_243, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_385 = torch.ops.aten.new_zeros.default(convolution_default_243, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_386 = torch.ops.aten.new_zeros.default(convolution_default_243, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_122 = torch.ops.aten.clone.default(getitem_420)
        silu__default_122 = torch.ops.aten.silu_.default(getitem_420);  getitem_420 = None
        convolution_default_244 = torch.ops.aten.convolution.default(silu__default_122, primals_507, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_245 = torch.ops.aten.convolution.default(convolution_default_244, primals_509, primals_508, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_129 = torch.ops.aten.native_batch_norm.default(convolution_default_245, primals_944, primals_940, primals_942, primals_943, False, 0.01, 0.001);  primals_940 = None
        getitem_423 = native_batch_norm_default_129[0]
        getitem_424 = native_batch_norm_default_129[1]
        getitem_425 = native_batch_norm_default_129[2];  native_batch_norm_default_129 = None
        new_zeros_default_387 = torch.ops.aten.new_zeros.default(convolution_default_245, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_388 = torch.ops.aten.new_zeros.default(convolution_default_245, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_389 = torch.ops.aten.new_zeros.default(convolution_default_245, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_123 = torch.ops.aten.clone.default(getitem_423)
        silu__default_123 = torch.ops.aten.silu_.default(getitem_423);  getitem_423 = None
        convolution_default_246 = torch.ops.aten.convolution.default(silu__default_123, primals_510, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_247 = torch.ops.aten.convolution.default(convolution_default_246, primals_512, primals_511, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_248 = torch.ops.aten.convolution.default(getitem_346, primals_501, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_249 = torch.ops.aten.convolution.default(convolution_default_248, primals_503, primals_502, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_130 = torch.ops.aten.native_batch_norm.default(convolution_default_249, primals_964, primals_960, primals_962, primals_963, False, 0.01, 0.001);  primals_960 = None
        getitem_426 = native_batch_norm_default_130[0]
        getitem_427 = native_batch_norm_default_130[1]
        getitem_428 = native_batch_norm_default_130[2];  native_batch_norm_default_130 = None
        new_zeros_default_390 = torch.ops.aten.new_zeros.default(convolution_default_249, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_391 = torch.ops.aten.new_zeros.default(convolution_default_249, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_392 = torch.ops.aten.new_zeros.default(convolution_default_249, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_124 = torch.ops.aten.clone.default(getitem_426)
        silu__default_124 = torch.ops.aten.silu_.default(getitem_426);  getitem_426 = None
        convolution_default_250 = torch.ops.aten.convolution.default(silu__default_124, primals_504, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_251 = torch.ops.aten.convolution.default(convolution_default_250, primals_506, primals_505, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_131 = torch.ops.aten.native_batch_norm.default(convolution_default_251, primals_969, primals_965, primals_967, primals_968, False, 0.01, 0.001);  primals_965 = None
        getitem_429 = native_batch_norm_default_131[0]
        getitem_430 = native_batch_norm_default_131[1]
        getitem_431 = native_batch_norm_default_131[2];  native_batch_norm_default_131 = None
        new_zeros_default_393 = torch.ops.aten.new_zeros.default(convolution_default_251, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_394 = torch.ops.aten.new_zeros.default(convolution_default_251, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_395 = torch.ops.aten.new_zeros.default(convolution_default_251, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_125 = torch.ops.aten.clone.default(getitem_429)
        silu__default_125 = torch.ops.aten.silu_.default(getitem_429);  getitem_429 = None
        convolution_default_252 = torch.ops.aten.convolution.default(silu__default_125, primals_507, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_253 = torch.ops.aten.convolution.default(convolution_default_252, primals_509, primals_508, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_132 = torch.ops.aten.native_batch_norm.default(convolution_default_253, primals_974, primals_970, primals_972, primals_973, False, 0.01, 0.001);  primals_970 = None
        getitem_432 = native_batch_norm_default_132[0]
        getitem_433 = native_batch_norm_default_132[1]
        getitem_434 = native_batch_norm_default_132[2];  native_batch_norm_default_132 = None
        new_zeros_default_396 = torch.ops.aten.new_zeros.default(convolution_default_253, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_397 = torch.ops.aten.new_zeros.default(convolution_default_253, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_398 = torch.ops.aten.new_zeros.default(convolution_default_253, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_126 = torch.ops.aten.clone.default(getitem_432)
        silu__default_126 = torch.ops.aten.silu_.default(getitem_432);  getitem_432 = None
        convolution_default_254 = torch.ops.aten.convolution.default(silu__default_126, primals_510, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_255 = torch.ops.aten.convolution.default(convolution_default_254, primals_512, primals_511, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_256 = torch.ops.aten.convolution.default(getitem_351, primals_501, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_257 = torch.ops.aten.convolution.default(convolution_default_256, primals_503, primals_502, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_502 = None
        native_batch_norm_default_133 = torch.ops.aten.native_batch_norm.default(convolution_default_257, primals_994, primals_990, primals_992, primals_993, False, 0.01, 0.001);  primals_990 = None
        getitem_435 = native_batch_norm_default_133[0]
        getitem_436 = native_batch_norm_default_133[1]
        getitem_437 = native_batch_norm_default_133[2];  native_batch_norm_default_133 = None
        new_zeros_default_399 = torch.ops.aten.new_zeros.default(convolution_default_257, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_400 = torch.ops.aten.new_zeros.default(convolution_default_257, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_401 = torch.ops.aten.new_zeros.default(convolution_default_257, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_127 = torch.ops.aten.clone.default(getitem_435)
        silu__default_127 = torch.ops.aten.silu_.default(getitem_435);  getitem_435 = None
        convolution_default_258 = torch.ops.aten.convolution.default(silu__default_127, primals_504, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_259 = torch.ops.aten.convolution.default(convolution_default_258, primals_506, primals_505, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_505 = None
        native_batch_norm_default_134 = torch.ops.aten.native_batch_norm.default(convolution_default_259, primals_999, primals_995, primals_997, primals_998, False, 0.01, 0.001);  primals_995 = None
        getitem_438 = native_batch_norm_default_134[0]
        getitem_439 = native_batch_norm_default_134[1]
        getitem_440 = native_batch_norm_default_134[2];  native_batch_norm_default_134 = None
        new_zeros_default_402 = torch.ops.aten.new_zeros.default(convolution_default_259, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_403 = torch.ops.aten.new_zeros.default(convolution_default_259, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_404 = torch.ops.aten.new_zeros.default(convolution_default_259, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_128 = torch.ops.aten.clone.default(getitem_438)
        silu__default_128 = torch.ops.aten.silu_.default(getitem_438);  getitem_438 = None
        convolution_default_260 = torch.ops.aten.convolution.default(silu__default_128, primals_507, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_261 = torch.ops.aten.convolution.default(convolution_default_260, primals_509, primals_508, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_508 = None
        native_batch_norm_default_135 = torch.ops.aten.native_batch_norm.default(convolution_default_261, primals_1004, primals_1000, primals_1002, primals_1003, False, 0.01, 0.001);  primals_1000 = None
        getitem_441 = native_batch_norm_default_135[0]
        getitem_442 = native_batch_norm_default_135[1]
        getitem_443 = native_batch_norm_default_135[2];  native_batch_norm_default_135 = None
        new_zeros_default_405 = torch.ops.aten.new_zeros.default(convolution_default_261, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_406 = torch.ops.aten.new_zeros.default(convolution_default_261, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_407 = torch.ops.aten.new_zeros.default(convolution_default_261, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_129 = torch.ops.aten.clone.default(getitem_441)
        silu__default_129 = torch.ops.aten.silu_.default(getitem_441);  getitem_441 = None
        convolution_default_262 = torch.ops.aten.convolution.default(silu__default_129, primals_510, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 88)
        convolution_default_263 = torch.ops.aten.convolution.default(convolution_default_262, primals_512, primals_511, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_511 = None
        permute_default = torch.ops.aten.permute.default(convolution_default_191, [0, 2, 3, 1]);  convolution_default_191 = None
        clone_default_130 = torch.ops.aten.clone.default(permute_default, memory_format = torch.contiguous_format);  permute_default = None
        _unsafe_view_default = torch.ops.aten._unsafe_view.default(clone_default_130, [1, 57600, 90]);  clone_default_130 = None
        permute_default_1 = torch.ops.aten.permute.default(convolution_default_199, [0, 2, 3, 1]);  convolution_default_199 = None
        clone_default_131 = torch.ops.aten.clone.default(permute_default_1, memory_format = torch.contiguous_format);  permute_default_1 = None
        _unsafe_view_default_1 = torch.ops.aten._unsafe_view.default(clone_default_131, [1, 14400, 90]);  clone_default_131 = None
        permute_default_2 = torch.ops.aten.permute.default(convolution_default_207, [0, 2, 3, 1]);  convolution_default_207 = None
        clone_default_132 = torch.ops.aten.clone.default(permute_default_2, memory_format = torch.contiguous_format);  permute_default_2 = None
        _unsafe_view_default_2 = torch.ops.aten._unsafe_view.default(clone_default_132, [1, 3600, 90]);  clone_default_132 = None
        permute_default_3 = torch.ops.aten.permute.default(convolution_default_215, [0, 2, 3, 1]);  convolution_default_215 = None
        clone_default_133 = torch.ops.aten.clone.default(permute_default_3, memory_format = torch.contiguous_format);  permute_default_3 = None
        _unsafe_view_default_3 = torch.ops.aten._unsafe_view.default(clone_default_133, [1, 900, 90]);  clone_default_133 = None
        permute_default_4 = torch.ops.aten.permute.default(convolution_default_223, [0, 2, 3, 1]);  convolution_default_223 = None
        clone_default_134 = torch.ops.aten.clone.default(permute_default_4, memory_format = torch.contiguous_format);  permute_default_4 = None
        _unsafe_view_default_4 = torch.ops.aten._unsafe_view.default(clone_default_134, [1, 225, 90]);  clone_default_134 = None
        cat_default = torch.ops.aten.cat.default([_unsafe_view_default, _unsafe_view_default_1, _unsafe_view_default_2, _unsafe_view_default_3, _unsafe_view_default_4], 1);  _unsafe_view_default = _unsafe_view_default_1 = _unsafe_view_default_2 = _unsafe_view_default_3 = _unsafe_view_default_4 = None
        permute_default_5 = torch.ops.aten.permute.default(convolution_default_231, [0, 2, 3, 1]);  convolution_default_231 = None
        clone_default_135 = torch.ops.aten.clone.default(permute_default_5, memory_format = torch.contiguous_format);  permute_default_5 = None
        _unsafe_view_default_5 = torch.ops.aten._unsafe_view.default(clone_default_135, [1, 57600, 4]);  clone_default_135 = None
        permute_default_6 = torch.ops.aten.permute.default(convolution_default_239, [0, 2, 3, 1]);  convolution_default_239 = None
        clone_default_136 = torch.ops.aten.clone.default(permute_default_6, memory_format = torch.contiguous_format);  permute_default_6 = None
        _unsafe_view_default_6 = torch.ops.aten._unsafe_view.default(clone_default_136, [1, 14400, 4]);  clone_default_136 = None
        permute_default_7 = torch.ops.aten.permute.default(convolution_default_247, [0, 2, 3, 1]);  convolution_default_247 = None
        clone_default_137 = torch.ops.aten.clone.default(permute_default_7, memory_format = torch.contiguous_format);  permute_default_7 = None
        _unsafe_view_default_7 = torch.ops.aten._unsafe_view.default(clone_default_137, [1, 3600, 4]);  clone_default_137 = None
        permute_default_8 = torch.ops.aten.permute.default(convolution_default_255, [0, 2, 3, 1]);  convolution_default_255 = None
        clone_default_138 = torch.ops.aten.clone.default(permute_default_8, memory_format = torch.contiguous_format);  permute_default_8 = None
        _unsafe_view_default_8 = torch.ops.aten._unsafe_view.default(clone_default_138, [1, 900, 4]);  clone_default_138 = None
        permute_default_9 = torch.ops.aten.permute.default(convolution_default_263, [0, 2, 3, 1]);  convolution_default_263 = None
        clone_default_139 = torch.ops.aten.clone.default(permute_default_9, memory_format = torch.contiguous_format);  permute_default_9 = None
        _unsafe_view_default_9 = torch.ops.aten._unsafe_view.default(clone_default_139, [1, 225, 4]);  clone_default_139 = None
        cat_default_1 = torch.ops.aten.cat.default([_unsafe_view_default_5, _unsafe_view_default_6, _unsafe_view_default_7, _unsafe_view_default_8, _unsafe_view_default_9], 1);  _unsafe_view_default_5 = _unsafe_view_default_6 = _unsafe_view_default_7 = _unsafe_view_default_8 = _unsafe_view_default_9 = None
        view_default = torch.ops.aten.view.default(cat_default, [1, 6905250])
        topk_default = torch.ops.aten.topk.default(view_default, 5000, 1);  view_default = None
        getitem_444 = topk_default[0]
        getitem_445 = topk_default[1];  topk_default = None
        floor_divide_default = torch.ops.aten.floor_divide.default(getitem_445, 90)
        remainder_scalar = torch.ops.aten.remainder.Scalar(getitem_445, 90);  getitem_445 = None
        unsqueeze_default = torch.ops.aten.unsqueeze.default(floor_divide_default, 2)
        expand_sym_int = torch.ops.aten.expand.SymInt(unsqueeze_default, [-1, -1, 4]);  unsqueeze_default = None
        gather_default = torch.ops.aten.gather.default(cat_default_1, 1, expand_sym_int);  cat_default_1 = None
        unsqueeze_default_1 = torch.ops.aten.unsqueeze.default(floor_divide_default, 2)
        expand_sym_int_1 = torch.ops.aten.expand.SymInt(unsqueeze_default_1, [-1, -1, 90]);  unsqueeze_default_1 = None
        gather_default_1 = torch.ops.aten.gather.default(cat_default, 1, expand_sym_int_1);  cat_default = None
        unsqueeze_default_2 = torch.ops.aten.unsqueeze.default(remainder_scalar, 2)
        gather_default_2 = torch.ops.aten.gather.default(gather_default_1, 2, unsqueeze_default_2);  gather_default_1 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(gather_default_2, tangents_1)
        is_same_size_default_1 = torch.ops.aten.is_same_size.default(gather_default, tangents_2)
        new_empty_default = torch.ops.aten.new_empty.default(tangents_1, [1, 5000, 90])
        zero__default = torch.ops.aten.zero_.default(new_empty_default);  new_empty_default = None
        scatter_add_default = torch.ops.aten.scatter_add.default(zero__default, 2, unsqueeze_default_2, tangents_1);  zero__default = unsqueeze_default_2 = tangents_1 = None
        new_empty_default_1 = torch.ops.aten.new_empty.default(scatter_add_default, [1, 76725, 90])
        zero__default_1 = torch.ops.aten.zero_.default(new_empty_default_1);  new_empty_default_1 = None
        scatter_add_default_1 = torch.ops.aten.scatter_add.default(zero__default_1, 1, expand_sym_int_1, scatter_add_default);  zero__default_1 = expand_sym_int_1 = scatter_add_default = None
        new_empty_default_2 = torch.ops.aten.new_empty.default(tangents_2, [1, 76725, 4])
        zero__default_2 = torch.ops.aten.zero_.default(new_empty_default_2);  new_empty_default_2 = None
        scatter_add_default_2 = torch.ops.aten.scatter_add.default(zero__default_2, 1, expand_sym_int, tangents_2);  zero__default_2 = expand_sym_int = tangents_2 = None
        slice_tensor = torch.ops.aten.slice.Tensor(scatter_add_default_2, 1, 0, 57600)
        slice_tensor_1 = torch.ops.aten.slice.Tensor(scatter_add_default_2, 1, 57600, 72000)
        slice_tensor_2 = torch.ops.aten.slice.Tensor(scatter_add_default_2, 1, 72000, 75600)
        slice_tensor_3 = torch.ops.aten.slice.Tensor(scatter_add_default_2, 1, 75600, 76500)
        slice_tensor_4 = torch.ops.aten.slice.Tensor(scatter_add_default_2, 1, 76500, 76725);  scatter_add_default_2 = None
        view_default_1 = torch.ops.aten.view.default(slice_tensor_4, [1, 5, 5, 36]);  slice_tensor_4 = None
        permute_default_10 = torch.ops.aten.permute.default(view_default_1, [0, 3, 1, 2]);  view_default_1 = None
        view_default_2 = torch.ops.aten.view.default(slice_tensor_3, [1, 10, 10, 36]);  slice_tensor_3 = None
        permute_default_11 = torch.ops.aten.permute.default(view_default_2, [0, 3, 1, 2]);  view_default_2 = None
        view_default_3 = torch.ops.aten.view.default(slice_tensor_2, [1, 20, 20, 36]);  slice_tensor_2 = None
        permute_default_12 = torch.ops.aten.permute.default(view_default_3, [0, 3, 1, 2]);  view_default_3 = None
        view_default_4 = torch.ops.aten.view.default(slice_tensor_1, [1, 40, 40, 36]);  slice_tensor_1 = None
        permute_default_13 = torch.ops.aten.permute.default(view_default_4, [0, 3, 1, 2]);  view_default_4 = None
        view_default_5 = torch.ops.aten.view.default(slice_tensor, [1, 80, 80, 36]);  slice_tensor = None
        permute_default_14 = torch.ops.aten.permute.default(view_default_5, [0, 3, 1, 2]);  view_default_5 = None
        slice_tensor_5 = torch.ops.aten.slice.Tensor(scatter_add_default_1, 1, 0, 57600)
        slice_tensor_6 = torch.ops.aten.slice.Tensor(scatter_add_default_1, 1, 57600, 72000)
        slice_tensor_7 = torch.ops.aten.slice.Tensor(scatter_add_default_1, 1, 72000, 75600)
        slice_tensor_8 = torch.ops.aten.slice.Tensor(scatter_add_default_1, 1, 75600, 76500)
        slice_tensor_9 = torch.ops.aten.slice.Tensor(scatter_add_default_1, 1, 76500, 76725);  scatter_add_default_1 = None
        view_default_6 = torch.ops.aten.view.default(slice_tensor_9, [1, 5, 5, 810]);  slice_tensor_9 = None
        permute_default_15 = torch.ops.aten.permute.default(view_default_6, [0, 3, 1, 2]);  view_default_6 = None
        view_default_7 = torch.ops.aten.view.default(slice_tensor_8, [1, 10, 10, 810]);  slice_tensor_8 = None
        permute_default_16 = torch.ops.aten.permute.default(view_default_7, [0, 3, 1, 2]);  view_default_7 = None
        view_default_8 = torch.ops.aten.view.default(slice_tensor_7, [1, 20, 20, 810]);  slice_tensor_7 = None
        permute_default_17 = torch.ops.aten.permute.default(view_default_8, [0, 3, 1, 2]);  view_default_8 = None
        view_default_9 = torch.ops.aten.view.default(slice_tensor_6, [1, 40, 40, 810]);  slice_tensor_6 = None
        permute_default_18 = torch.ops.aten.permute.default(view_default_9, [0, 3, 1, 2]);  view_default_9 = None
        view_default_10 = torch.ops.aten.view.default(slice_tensor_5, [1, 80, 80, 810]);  slice_tensor_5 = None
        permute_default_19 = torch.ops.aten.permute.default(view_default_10, [0, 3, 1, 2]);  view_default_10 = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(permute_default_10, convolution_default_262, primals_512, [36], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  permute_default_10 = convolution_default_262 = None
        getitem_446 = convolution_backward_default[0]
        getitem_447 = convolution_backward_default[1]
        getitem_448 = convolution_backward_default[2];  convolution_backward_default = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_446, silu__default_129, primals_510, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_446 = silu__default_129 = None
        getitem_449 = convolution_backward_default_1[0]
        getitem_450 = convolution_backward_default_1[1]
        getitem_451 = convolution_backward_default_1[2];  convolution_backward_default_1 = None
        to_dtype = torch.ops.aten.to.dtype(getitem_449, torch.float32);  getitem_449 = None
        to_dtype_1 = torch.ops.aten.to.dtype(clone_default_129, torch.float32);  clone_default_129 = None
        neg_default = torch.ops.aten.neg.default(to_dtype_1)
        exp_default = torch.ops.aten.exp.default(neg_default);  neg_default = None
        add_tensor_76 = torch.ops.aten.add.Tensor(exp_default, 1);  exp_default = None
        reciprocal_default = torch.ops.aten.reciprocal.default(add_tensor_76);  add_tensor_76 = None
        mul_tensor_99 = torch.ops.aten.mul.Tensor(reciprocal_default, 1);  reciprocal_default = None
        mul_tensor_100 = torch.ops.aten.mul.Tensor(to_dtype, mul_tensor_99);  to_dtype = None
        rsub_scalar = torch.ops.aten.rsub.Scalar(mul_tensor_99, 1);  mul_tensor_99 = None
        mul_tensor_101 = torch.ops.aten.mul.Tensor(to_dtype_1, rsub_scalar);  to_dtype_1 = rsub_scalar = None
        add_tensor_77 = torch.ops.aten.add.Tensor(mul_tensor_101, 1);  mul_tensor_101 = None
        mul_tensor_102 = torch.ops.aten.mul.Tensor(mul_tensor_100, add_tensor_77);  mul_tensor_100 = add_tensor_77 = None
        to_dtype_2 = torch.ops.aten.to.dtype(mul_tensor_102, torch.float32);  mul_tensor_102 = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_2, convolution_default_261, primals_1004, primals_1002, primals_1003, new_zeros_default_405, new_zeros_default_406, False, 0.001, [True, True, True]);  to_dtype_2 = convolution_default_261 = primals_1004 = primals_1002 = primals_1003 = new_zeros_default_405 = new_zeros_default_406 = None
        getitem_452 = native_batch_norm_backward_default[0]
        getitem_453 = native_batch_norm_backward_default[1]
        getitem_454 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_452, convolution_default_260, primals_509, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_452 = convolution_default_260 = None
        getitem_455 = convolution_backward_default_2[0]
        getitem_456 = convolution_backward_default_2[1]
        getitem_457 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_455, silu__default_128, primals_507, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_455 = silu__default_128 = None
        getitem_458 = convolution_backward_default_3[0]
        getitem_459 = convolution_backward_default_3[1]
        getitem_460 = convolution_backward_default_3[2];  convolution_backward_default_3 = None
        to_dtype_3 = torch.ops.aten.to.dtype(getitem_458, torch.float32);  getitem_458 = None
        to_dtype_4 = torch.ops.aten.to.dtype(clone_default_128, torch.float32);  clone_default_128 = None
        neg_default_1 = torch.ops.aten.neg.default(to_dtype_4)
        exp_default_1 = torch.ops.aten.exp.default(neg_default_1);  neg_default_1 = None
        add_tensor_78 = torch.ops.aten.add.Tensor(exp_default_1, 1);  exp_default_1 = None
        reciprocal_default_1 = torch.ops.aten.reciprocal.default(add_tensor_78);  add_tensor_78 = None
        mul_tensor_103 = torch.ops.aten.mul.Tensor(reciprocal_default_1, 1);  reciprocal_default_1 = None
        mul_tensor_104 = torch.ops.aten.mul.Tensor(to_dtype_3, mul_tensor_103);  to_dtype_3 = None
        rsub_scalar_1 = torch.ops.aten.rsub.Scalar(mul_tensor_103, 1);  mul_tensor_103 = None
        mul_tensor_105 = torch.ops.aten.mul.Tensor(to_dtype_4, rsub_scalar_1);  to_dtype_4 = rsub_scalar_1 = None
        add_tensor_79 = torch.ops.aten.add.Tensor(mul_tensor_105, 1);  mul_tensor_105 = None
        mul_tensor_106 = torch.ops.aten.mul.Tensor(mul_tensor_104, add_tensor_79);  mul_tensor_104 = add_tensor_79 = None
        to_dtype_5 = torch.ops.aten.to.dtype(mul_tensor_106, torch.float32);  mul_tensor_106 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_5, convolution_default_259, primals_999, primals_997, primals_998, new_zeros_default_402, new_zeros_default_403, False, 0.001, [True, True, True]);  to_dtype_5 = convolution_default_259 = primals_999 = primals_997 = primals_998 = new_zeros_default_402 = new_zeros_default_403 = None
        getitem_461 = native_batch_norm_backward_default_1[0]
        getitem_462 = native_batch_norm_backward_default_1[1]
        getitem_463 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_461, convolution_default_258, primals_506, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_461 = convolution_default_258 = None
        getitem_464 = convolution_backward_default_4[0]
        getitem_465 = convolution_backward_default_4[1]
        getitem_466 = convolution_backward_default_4[2];  convolution_backward_default_4 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_464, silu__default_127, primals_504, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_464 = silu__default_127 = None
        getitem_467 = convolution_backward_default_5[0]
        getitem_468 = convolution_backward_default_5[1]
        getitem_469 = convolution_backward_default_5[2];  convolution_backward_default_5 = None
        to_dtype_6 = torch.ops.aten.to.dtype(getitem_467, torch.float32);  getitem_467 = None
        to_dtype_7 = torch.ops.aten.to.dtype(clone_default_127, torch.float32);  clone_default_127 = None
        neg_default_2 = torch.ops.aten.neg.default(to_dtype_7)
        exp_default_2 = torch.ops.aten.exp.default(neg_default_2);  neg_default_2 = None
        add_tensor_80 = torch.ops.aten.add.Tensor(exp_default_2, 1);  exp_default_2 = None
        reciprocal_default_2 = torch.ops.aten.reciprocal.default(add_tensor_80);  add_tensor_80 = None
        mul_tensor_107 = torch.ops.aten.mul.Tensor(reciprocal_default_2, 1);  reciprocal_default_2 = None
        mul_tensor_108 = torch.ops.aten.mul.Tensor(to_dtype_6, mul_tensor_107);  to_dtype_6 = None
        rsub_scalar_2 = torch.ops.aten.rsub.Scalar(mul_tensor_107, 1);  mul_tensor_107 = None
        mul_tensor_109 = torch.ops.aten.mul.Tensor(to_dtype_7, rsub_scalar_2);  to_dtype_7 = rsub_scalar_2 = None
        add_tensor_81 = torch.ops.aten.add.Tensor(mul_tensor_109, 1);  mul_tensor_109 = None
        mul_tensor_110 = torch.ops.aten.mul.Tensor(mul_tensor_108, add_tensor_81);  mul_tensor_108 = add_tensor_81 = None
        to_dtype_8 = torch.ops.aten.to.dtype(mul_tensor_110, torch.float32);  mul_tensor_110 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_8, convolution_default_257, primals_994, primals_992, primals_993, new_zeros_default_399, new_zeros_default_400, False, 0.001, [True, True, True]);  to_dtype_8 = convolution_default_257 = primals_994 = primals_992 = primals_993 = new_zeros_default_399 = new_zeros_default_400 = None
        getitem_470 = native_batch_norm_backward_default_2[0]
        getitem_471 = native_batch_norm_backward_default_2[1]
        getitem_472 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(getitem_470, convolution_default_256, primals_503, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_470 = convolution_default_256 = None
        getitem_473 = convolution_backward_default_6[0]
        getitem_474 = convolution_backward_default_6[1]
        getitem_475 = convolution_backward_default_6[2];  convolution_backward_default_6 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(getitem_473, getitem_351, primals_501, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_473 = None
        getitem_476 = convolution_backward_default_7[0]
        getitem_477 = convolution_backward_default_7[1]
        getitem_478 = convolution_backward_default_7[2];  convolution_backward_default_7 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(permute_default_11, convolution_default_254, primals_512, [36], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  permute_default_11 = convolution_default_254 = None
        getitem_479 = convolution_backward_default_8[0]
        getitem_480 = convolution_backward_default_8[1]
        getitem_481 = convolution_backward_default_8[2];  convolution_backward_default_8 = None
        add_tensor_82 = torch.ops.aten.add.Tensor(getitem_447, getitem_480);  getitem_447 = getitem_480 = None
        add_tensor_83 = torch.ops.aten.add.Tensor(getitem_448, getitem_481);  getitem_448 = getitem_481 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_479, silu__default_126, primals_510, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_479 = silu__default_126 = None
        getitem_482 = convolution_backward_default_9[0]
        getitem_483 = convolution_backward_default_9[1]
        getitem_484 = convolution_backward_default_9[2];  convolution_backward_default_9 = None
        add_tensor_84 = torch.ops.aten.add.Tensor(getitem_450, getitem_483);  getitem_450 = getitem_483 = None
        to_dtype_9 = torch.ops.aten.to.dtype(getitem_482, torch.float32);  getitem_482 = None
        to_dtype_10 = torch.ops.aten.to.dtype(clone_default_126, torch.float32);  clone_default_126 = None
        neg_default_3 = torch.ops.aten.neg.default(to_dtype_10)
        exp_default_3 = torch.ops.aten.exp.default(neg_default_3);  neg_default_3 = None
        add_tensor_85 = torch.ops.aten.add.Tensor(exp_default_3, 1);  exp_default_3 = None
        reciprocal_default_3 = torch.ops.aten.reciprocal.default(add_tensor_85);  add_tensor_85 = None
        mul_tensor_111 = torch.ops.aten.mul.Tensor(reciprocal_default_3, 1);  reciprocal_default_3 = None
        mul_tensor_112 = torch.ops.aten.mul.Tensor(to_dtype_9, mul_tensor_111);  to_dtype_9 = None
        rsub_scalar_3 = torch.ops.aten.rsub.Scalar(mul_tensor_111, 1);  mul_tensor_111 = None
        mul_tensor_113 = torch.ops.aten.mul.Tensor(to_dtype_10, rsub_scalar_3);  to_dtype_10 = rsub_scalar_3 = None
        add_tensor_86 = torch.ops.aten.add.Tensor(mul_tensor_113, 1);  mul_tensor_113 = None
        mul_tensor_114 = torch.ops.aten.mul.Tensor(mul_tensor_112, add_tensor_86);  mul_tensor_112 = add_tensor_86 = None
        to_dtype_11 = torch.ops.aten.to.dtype(mul_tensor_114, torch.float32);  mul_tensor_114 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_253, primals_974, primals_972, primals_973, new_zeros_default_396, new_zeros_default_397, False, 0.001, [True, True, True]);  to_dtype_11 = convolution_default_253 = primals_974 = primals_972 = primals_973 = new_zeros_default_396 = new_zeros_default_397 = None
        getitem_485 = native_batch_norm_backward_default_3[0]
        getitem_486 = native_batch_norm_backward_default_3[1]
        getitem_487 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_485, convolution_default_252, primals_509, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_485 = convolution_default_252 = None
        getitem_488 = convolution_backward_default_10[0]
        getitem_489 = convolution_backward_default_10[1]
        getitem_490 = convolution_backward_default_10[2];  convolution_backward_default_10 = None
        add_tensor_87 = torch.ops.aten.add.Tensor(getitem_456, getitem_489);  getitem_456 = getitem_489 = None
        add_tensor_88 = torch.ops.aten.add.Tensor(getitem_457, getitem_490);  getitem_457 = getitem_490 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_488, silu__default_125, primals_507, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_488 = silu__default_125 = None
        getitem_491 = convolution_backward_default_11[0]
        getitem_492 = convolution_backward_default_11[1]
        getitem_493 = convolution_backward_default_11[2];  convolution_backward_default_11 = None
        add_tensor_89 = torch.ops.aten.add.Tensor(getitem_459, getitem_492);  getitem_459 = getitem_492 = None
        to_dtype_12 = torch.ops.aten.to.dtype(getitem_491, torch.float32);  getitem_491 = None
        to_dtype_13 = torch.ops.aten.to.dtype(clone_default_125, torch.float32);  clone_default_125 = None
        neg_default_4 = torch.ops.aten.neg.default(to_dtype_13)
        exp_default_4 = torch.ops.aten.exp.default(neg_default_4);  neg_default_4 = None
        add_tensor_90 = torch.ops.aten.add.Tensor(exp_default_4, 1);  exp_default_4 = None
        reciprocal_default_4 = torch.ops.aten.reciprocal.default(add_tensor_90);  add_tensor_90 = None
        mul_tensor_115 = torch.ops.aten.mul.Tensor(reciprocal_default_4, 1);  reciprocal_default_4 = None
        mul_tensor_116 = torch.ops.aten.mul.Tensor(to_dtype_12, mul_tensor_115);  to_dtype_12 = None
        rsub_scalar_4 = torch.ops.aten.rsub.Scalar(mul_tensor_115, 1);  mul_tensor_115 = None
        mul_tensor_117 = torch.ops.aten.mul.Tensor(to_dtype_13, rsub_scalar_4);  to_dtype_13 = rsub_scalar_4 = None
        add_tensor_91 = torch.ops.aten.add.Tensor(mul_tensor_117, 1);  mul_tensor_117 = None
        mul_tensor_118 = torch.ops.aten.mul.Tensor(mul_tensor_116, add_tensor_91);  mul_tensor_116 = add_tensor_91 = None
        to_dtype_14 = torch.ops.aten.to.dtype(mul_tensor_118, torch.float32);  mul_tensor_118 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_251, primals_969, primals_967, primals_968, new_zeros_default_393, new_zeros_default_394, False, 0.001, [True, True, True]);  to_dtype_14 = convolution_default_251 = primals_969 = primals_967 = primals_968 = new_zeros_default_393 = new_zeros_default_394 = None
        getitem_494 = native_batch_norm_backward_default_4[0]
        getitem_495 = native_batch_norm_backward_default_4[1]
        getitem_496 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(getitem_494, convolution_default_250, primals_506, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_494 = convolution_default_250 = None
        getitem_497 = convolution_backward_default_12[0]
        getitem_498 = convolution_backward_default_12[1]
        getitem_499 = convolution_backward_default_12[2];  convolution_backward_default_12 = None
        add_tensor_92 = torch.ops.aten.add.Tensor(getitem_465, getitem_498);  getitem_465 = getitem_498 = None
        add_tensor_93 = torch.ops.aten.add.Tensor(getitem_466, getitem_499);  getitem_466 = getitem_499 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_497, silu__default_124, primals_504, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_497 = silu__default_124 = None
        getitem_500 = convolution_backward_default_13[0]
        getitem_501 = convolution_backward_default_13[1]
        getitem_502 = convolution_backward_default_13[2];  convolution_backward_default_13 = None
        add_tensor_94 = torch.ops.aten.add.Tensor(getitem_468, getitem_501);  getitem_468 = getitem_501 = None
        to_dtype_15 = torch.ops.aten.to.dtype(getitem_500, torch.float32);  getitem_500 = None
        to_dtype_16 = torch.ops.aten.to.dtype(clone_default_124, torch.float32);  clone_default_124 = None
        neg_default_5 = torch.ops.aten.neg.default(to_dtype_16)
        exp_default_5 = torch.ops.aten.exp.default(neg_default_5);  neg_default_5 = None
        add_tensor_95 = torch.ops.aten.add.Tensor(exp_default_5, 1);  exp_default_5 = None
        reciprocal_default_5 = torch.ops.aten.reciprocal.default(add_tensor_95);  add_tensor_95 = None
        mul_tensor_119 = torch.ops.aten.mul.Tensor(reciprocal_default_5, 1);  reciprocal_default_5 = None
        mul_tensor_120 = torch.ops.aten.mul.Tensor(to_dtype_15, mul_tensor_119);  to_dtype_15 = None
        rsub_scalar_5 = torch.ops.aten.rsub.Scalar(mul_tensor_119, 1);  mul_tensor_119 = None
        mul_tensor_121 = torch.ops.aten.mul.Tensor(to_dtype_16, rsub_scalar_5);  to_dtype_16 = rsub_scalar_5 = None
        add_tensor_96 = torch.ops.aten.add.Tensor(mul_tensor_121, 1);  mul_tensor_121 = None
        mul_tensor_122 = torch.ops.aten.mul.Tensor(mul_tensor_120, add_tensor_96);  mul_tensor_120 = add_tensor_96 = None
        to_dtype_17 = torch.ops.aten.to.dtype(mul_tensor_122, torch.float32);  mul_tensor_122 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_17, convolution_default_249, primals_964, primals_962, primals_963, new_zeros_default_390, new_zeros_default_391, False, 0.001, [True, True, True]);  to_dtype_17 = convolution_default_249 = primals_964 = primals_962 = primals_963 = new_zeros_default_390 = new_zeros_default_391 = None
        getitem_503 = native_batch_norm_backward_default_5[0]
        getitem_504 = native_batch_norm_backward_default_5[1]
        getitem_505 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_503, convolution_default_248, primals_503, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_503 = convolution_default_248 = None
        getitem_506 = convolution_backward_default_14[0]
        getitem_507 = convolution_backward_default_14[1]
        getitem_508 = convolution_backward_default_14[2];  convolution_backward_default_14 = None
        add_tensor_97 = torch.ops.aten.add.Tensor(getitem_474, getitem_507);  getitem_474 = getitem_507 = None
        add_tensor_98 = torch.ops.aten.add.Tensor(getitem_475, getitem_508);  getitem_475 = getitem_508 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_506, getitem_346, primals_501, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_506 = None
        getitem_509 = convolution_backward_default_15[0]
        getitem_510 = convolution_backward_default_15[1]
        getitem_511 = convolution_backward_default_15[2];  convolution_backward_default_15 = None
        add_tensor_99 = torch.ops.aten.add.Tensor(getitem_477, getitem_510);  getitem_477 = getitem_510 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(permute_default_12, convolution_default_246, primals_512, [36], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  permute_default_12 = convolution_default_246 = None
        getitem_512 = convolution_backward_default_16[0]
        getitem_513 = convolution_backward_default_16[1]
        getitem_514 = convolution_backward_default_16[2];  convolution_backward_default_16 = None
        add_tensor_100 = torch.ops.aten.add.Tensor(add_tensor_82, getitem_513);  add_tensor_82 = getitem_513 = None
        add_tensor_101 = torch.ops.aten.add.Tensor(add_tensor_83, getitem_514);  add_tensor_83 = getitem_514 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(getitem_512, silu__default_123, primals_510, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_512 = silu__default_123 = None
        getitem_515 = convolution_backward_default_17[0]
        getitem_516 = convolution_backward_default_17[1]
        getitem_517 = convolution_backward_default_17[2];  convolution_backward_default_17 = None
        add_tensor_102 = torch.ops.aten.add.Tensor(add_tensor_84, getitem_516);  add_tensor_84 = getitem_516 = None
        to_dtype_18 = torch.ops.aten.to.dtype(getitem_515, torch.float32);  getitem_515 = None
        to_dtype_19 = torch.ops.aten.to.dtype(clone_default_123, torch.float32);  clone_default_123 = None
        neg_default_6 = torch.ops.aten.neg.default(to_dtype_19)
        exp_default_6 = torch.ops.aten.exp.default(neg_default_6);  neg_default_6 = None
        add_tensor_103 = torch.ops.aten.add.Tensor(exp_default_6, 1);  exp_default_6 = None
        reciprocal_default_6 = torch.ops.aten.reciprocal.default(add_tensor_103);  add_tensor_103 = None
        mul_tensor_123 = torch.ops.aten.mul.Tensor(reciprocal_default_6, 1);  reciprocal_default_6 = None
        mul_tensor_124 = torch.ops.aten.mul.Tensor(to_dtype_18, mul_tensor_123);  to_dtype_18 = None
        rsub_scalar_6 = torch.ops.aten.rsub.Scalar(mul_tensor_123, 1);  mul_tensor_123 = None
        mul_tensor_125 = torch.ops.aten.mul.Tensor(to_dtype_19, rsub_scalar_6);  to_dtype_19 = rsub_scalar_6 = None
        add_tensor_104 = torch.ops.aten.add.Tensor(mul_tensor_125, 1);  mul_tensor_125 = None
        mul_tensor_126 = torch.ops.aten.mul.Tensor(mul_tensor_124, add_tensor_104);  mul_tensor_124 = add_tensor_104 = None
        to_dtype_20 = torch.ops.aten.to.dtype(mul_tensor_126, torch.float32);  mul_tensor_126 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_20, convolution_default_245, primals_944, primals_942, primals_943, new_zeros_default_387, new_zeros_default_388, False, 0.001, [True, True, True]);  to_dtype_20 = convolution_default_245 = primals_944 = primals_942 = primals_943 = new_zeros_default_387 = new_zeros_default_388 = None
        getitem_518 = native_batch_norm_backward_default_6[0]
        getitem_519 = native_batch_norm_backward_default_6[1]
        getitem_520 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(getitem_518, convolution_default_244, primals_509, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_518 = convolution_default_244 = None
        getitem_521 = convolution_backward_default_18[0]
        getitem_522 = convolution_backward_default_18[1]
        getitem_523 = convolution_backward_default_18[2];  convolution_backward_default_18 = None
        add_tensor_105 = torch.ops.aten.add.Tensor(add_tensor_87, getitem_522);  add_tensor_87 = getitem_522 = None
        add_tensor_106 = torch.ops.aten.add.Tensor(add_tensor_88, getitem_523);  add_tensor_88 = getitem_523 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_521, silu__default_122, primals_507, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_521 = silu__default_122 = None
        getitem_524 = convolution_backward_default_19[0]
        getitem_525 = convolution_backward_default_19[1]
        getitem_526 = convolution_backward_default_19[2];  convolution_backward_default_19 = None
        add_tensor_107 = torch.ops.aten.add.Tensor(add_tensor_89, getitem_525);  add_tensor_89 = getitem_525 = None
        to_dtype_21 = torch.ops.aten.to.dtype(getitem_524, torch.float32);  getitem_524 = None
        to_dtype_22 = torch.ops.aten.to.dtype(clone_default_122, torch.float32);  clone_default_122 = None
        neg_default_7 = torch.ops.aten.neg.default(to_dtype_22)
        exp_default_7 = torch.ops.aten.exp.default(neg_default_7);  neg_default_7 = None
        add_tensor_108 = torch.ops.aten.add.Tensor(exp_default_7, 1);  exp_default_7 = None
        reciprocal_default_7 = torch.ops.aten.reciprocal.default(add_tensor_108);  add_tensor_108 = None
        mul_tensor_127 = torch.ops.aten.mul.Tensor(reciprocal_default_7, 1);  reciprocal_default_7 = None
        mul_tensor_128 = torch.ops.aten.mul.Tensor(to_dtype_21, mul_tensor_127);  to_dtype_21 = None
        rsub_scalar_7 = torch.ops.aten.rsub.Scalar(mul_tensor_127, 1);  mul_tensor_127 = None
        mul_tensor_129 = torch.ops.aten.mul.Tensor(to_dtype_22, rsub_scalar_7);  to_dtype_22 = rsub_scalar_7 = None
        add_tensor_109 = torch.ops.aten.add.Tensor(mul_tensor_129, 1);  mul_tensor_129 = None
        mul_tensor_130 = torch.ops.aten.mul.Tensor(mul_tensor_128, add_tensor_109);  mul_tensor_128 = add_tensor_109 = None
        to_dtype_23 = torch.ops.aten.to.dtype(mul_tensor_130, torch.float32);  mul_tensor_130 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_23, convolution_default_243, primals_939, primals_937, primals_938, new_zeros_default_384, new_zeros_default_385, False, 0.001, [True, True, True]);  to_dtype_23 = convolution_default_243 = primals_939 = primals_937 = primals_938 = new_zeros_default_384 = new_zeros_default_385 = None
        getitem_527 = native_batch_norm_backward_default_7[0]
        getitem_528 = native_batch_norm_backward_default_7[1]
        getitem_529 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(getitem_527, convolution_default_242, primals_506, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_527 = convolution_default_242 = None
        getitem_530 = convolution_backward_default_20[0]
        getitem_531 = convolution_backward_default_20[1]
        getitem_532 = convolution_backward_default_20[2];  convolution_backward_default_20 = None
        add_tensor_110 = torch.ops.aten.add.Tensor(add_tensor_92, getitem_531);  add_tensor_92 = getitem_531 = None
        add_tensor_111 = torch.ops.aten.add.Tensor(add_tensor_93, getitem_532);  add_tensor_93 = getitem_532 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(getitem_530, silu__default_121, primals_504, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_530 = silu__default_121 = None
        getitem_533 = convolution_backward_default_21[0]
        getitem_534 = convolution_backward_default_21[1]
        getitem_535 = convolution_backward_default_21[2];  convolution_backward_default_21 = None
        add_tensor_112 = torch.ops.aten.add.Tensor(add_tensor_94, getitem_534);  add_tensor_94 = getitem_534 = None
        to_dtype_24 = torch.ops.aten.to.dtype(getitem_533, torch.float32);  getitem_533 = None
        to_dtype_25 = torch.ops.aten.to.dtype(clone_default_121, torch.float32);  clone_default_121 = None
        neg_default_8 = torch.ops.aten.neg.default(to_dtype_25)
        exp_default_8 = torch.ops.aten.exp.default(neg_default_8);  neg_default_8 = None
        add_tensor_113 = torch.ops.aten.add.Tensor(exp_default_8, 1);  exp_default_8 = None
        reciprocal_default_8 = torch.ops.aten.reciprocal.default(add_tensor_113);  add_tensor_113 = None
        mul_tensor_131 = torch.ops.aten.mul.Tensor(reciprocal_default_8, 1);  reciprocal_default_8 = None
        mul_tensor_132 = torch.ops.aten.mul.Tensor(to_dtype_24, mul_tensor_131);  to_dtype_24 = None
        rsub_scalar_8 = torch.ops.aten.rsub.Scalar(mul_tensor_131, 1);  mul_tensor_131 = None
        mul_tensor_133 = torch.ops.aten.mul.Tensor(to_dtype_25, rsub_scalar_8);  to_dtype_25 = rsub_scalar_8 = None
        add_tensor_114 = torch.ops.aten.add.Tensor(mul_tensor_133, 1);  mul_tensor_133 = None
        mul_tensor_134 = torch.ops.aten.mul.Tensor(mul_tensor_132, add_tensor_114);  mul_tensor_132 = add_tensor_114 = None
        to_dtype_26 = torch.ops.aten.to.dtype(mul_tensor_134, torch.float32);  mul_tensor_134 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_241, primals_934, primals_932, primals_933, new_zeros_default_381, new_zeros_default_382, False, 0.001, [True, True, True]);  to_dtype_26 = convolution_default_241 = primals_934 = primals_932 = primals_933 = new_zeros_default_381 = new_zeros_default_382 = None
        getitem_536 = native_batch_norm_backward_default_8[0]
        getitem_537 = native_batch_norm_backward_default_8[1]
        getitem_538 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(getitem_536, convolution_default_240, primals_503, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_536 = convolution_default_240 = None
        getitem_539 = convolution_backward_default_22[0]
        getitem_540 = convolution_backward_default_22[1]
        getitem_541 = convolution_backward_default_22[2];  convolution_backward_default_22 = None
        add_tensor_115 = torch.ops.aten.add.Tensor(add_tensor_97, getitem_540);  add_tensor_97 = getitem_540 = None
        add_tensor_116 = torch.ops.aten.add.Tensor(add_tensor_98, getitem_541);  add_tensor_98 = getitem_541 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(getitem_539, getitem_341, primals_501, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_539 = None
        getitem_542 = convolution_backward_default_23[0]
        getitem_543 = convolution_backward_default_23[1]
        getitem_544 = convolution_backward_default_23[2];  convolution_backward_default_23 = None
        add_tensor_117 = torch.ops.aten.add.Tensor(add_tensor_99, getitem_543);  add_tensor_99 = getitem_543 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(permute_default_13, convolution_default_238, primals_512, [36], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  permute_default_13 = convolution_default_238 = None
        getitem_545 = convolution_backward_default_24[0]
        getitem_546 = convolution_backward_default_24[1]
        getitem_547 = convolution_backward_default_24[2];  convolution_backward_default_24 = None
        add_tensor_118 = torch.ops.aten.add.Tensor(add_tensor_100, getitem_546);  add_tensor_100 = getitem_546 = None
        add_tensor_119 = torch.ops.aten.add.Tensor(add_tensor_101, getitem_547);  add_tensor_101 = getitem_547 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_545, silu__default_120, primals_510, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_545 = silu__default_120 = None
        getitem_548 = convolution_backward_default_25[0]
        getitem_549 = convolution_backward_default_25[1]
        getitem_550 = convolution_backward_default_25[2];  convolution_backward_default_25 = None
        add_tensor_120 = torch.ops.aten.add.Tensor(add_tensor_102, getitem_549);  add_tensor_102 = getitem_549 = None
        to_dtype_27 = torch.ops.aten.to.dtype(getitem_548, torch.float32);  getitem_548 = None
        to_dtype_28 = torch.ops.aten.to.dtype(clone_default_120, torch.float32);  clone_default_120 = None
        neg_default_9 = torch.ops.aten.neg.default(to_dtype_28)
        exp_default_9 = torch.ops.aten.exp.default(neg_default_9);  neg_default_9 = None
        add_tensor_121 = torch.ops.aten.add.Tensor(exp_default_9, 1);  exp_default_9 = None
        reciprocal_default_9 = torch.ops.aten.reciprocal.default(add_tensor_121);  add_tensor_121 = None
        mul_tensor_135 = torch.ops.aten.mul.Tensor(reciprocal_default_9, 1);  reciprocal_default_9 = None
        mul_tensor_136 = torch.ops.aten.mul.Tensor(to_dtype_27, mul_tensor_135);  to_dtype_27 = None
        rsub_scalar_9 = torch.ops.aten.rsub.Scalar(mul_tensor_135, 1);  mul_tensor_135 = None
        mul_tensor_137 = torch.ops.aten.mul.Tensor(to_dtype_28, rsub_scalar_9);  to_dtype_28 = rsub_scalar_9 = None
        add_tensor_122 = torch.ops.aten.add.Tensor(mul_tensor_137, 1);  mul_tensor_137 = None
        mul_tensor_138 = torch.ops.aten.mul.Tensor(mul_tensor_136, add_tensor_122);  mul_tensor_136 = add_tensor_122 = None
        to_dtype_29 = torch.ops.aten.to.dtype(mul_tensor_138, torch.float32);  mul_tensor_138 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_29, convolution_default_237, primals_914, primals_912, primals_913, new_zeros_default_378, new_zeros_default_379, False, 0.001, [True, True, True]);  to_dtype_29 = convolution_default_237 = primals_914 = primals_912 = primals_913 = new_zeros_default_378 = new_zeros_default_379 = None
        getitem_551 = native_batch_norm_backward_default_9[0]
        getitem_552 = native_batch_norm_backward_default_9[1]
        getitem_553 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(getitem_551, convolution_default_236, primals_509, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_551 = convolution_default_236 = None
        getitem_554 = convolution_backward_default_26[0]
        getitem_555 = convolution_backward_default_26[1]
        getitem_556 = convolution_backward_default_26[2];  convolution_backward_default_26 = None
        add_tensor_123 = torch.ops.aten.add.Tensor(add_tensor_105, getitem_555);  add_tensor_105 = getitem_555 = None
        add_tensor_124 = torch.ops.aten.add.Tensor(add_tensor_106, getitem_556);  add_tensor_106 = getitem_556 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(getitem_554, silu__default_119, primals_507, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_554 = silu__default_119 = None
        getitem_557 = convolution_backward_default_27[0]
        getitem_558 = convolution_backward_default_27[1]
        getitem_559 = convolution_backward_default_27[2];  convolution_backward_default_27 = None
        add_tensor_125 = torch.ops.aten.add.Tensor(add_tensor_107, getitem_558);  add_tensor_107 = getitem_558 = None
        to_dtype_30 = torch.ops.aten.to.dtype(getitem_557, torch.float32);  getitem_557 = None
        to_dtype_31 = torch.ops.aten.to.dtype(clone_default_119, torch.float32);  clone_default_119 = None
        neg_default_10 = torch.ops.aten.neg.default(to_dtype_31)
        exp_default_10 = torch.ops.aten.exp.default(neg_default_10);  neg_default_10 = None
        add_tensor_126 = torch.ops.aten.add.Tensor(exp_default_10, 1);  exp_default_10 = None
        reciprocal_default_10 = torch.ops.aten.reciprocal.default(add_tensor_126);  add_tensor_126 = None
        mul_tensor_139 = torch.ops.aten.mul.Tensor(reciprocal_default_10, 1);  reciprocal_default_10 = None
        mul_tensor_140 = torch.ops.aten.mul.Tensor(to_dtype_30, mul_tensor_139);  to_dtype_30 = None
        rsub_scalar_10 = torch.ops.aten.rsub.Scalar(mul_tensor_139, 1);  mul_tensor_139 = None
        mul_tensor_141 = torch.ops.aten.mul.Tensor(to_dtype_31, rsub_scalar_10);  to_dtype_31 = rsub_scalar_10 = None
        add_tensor_127 = torch.ops.aten.add.Tensor(mul_tensor_141, 1);  mul_tensor_141 = None
        mul_tensor_142 = torch.ops.aten.mul.Tensor(mul_tensor_140, add_tensor_127);  mul_tensor_140 = add_tensor_127 = None
        to_dtype_32 = torch.ops.aten.to.dtype(mul_tensor_142, torch.float32);  mul_tensor_142 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default_235, primals_909, primals_907, primals_908, new_zeros_default_375, new_zeros_default_376, False, 0.001, [True, True, True]);  to_dtype_32 = convolution_default_235 = primals_909 = primals_907 = primals_908 = new_zeros_default_375 = new_zeros_default_376 = None
        getitem_560 = native_batch_norm_backward_default_10[0]
        getitem_561 = native_batch_norm_backward_default_10[1]
        getitem_562 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(getitem_560, convolution_default_234, primals_506, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_560 = convolution_default_234 = None
        getitem_563 = convolution_backward_default_28[0]
        getitem_564 = convolution_backward_default_28[1]
        getitem_565 = convolution_backward_default_28[2];  convolution_backward_default_28 = None
        add_tensor_128 = torch.ops.aten.add.Tensor(add_tensor_110, getitem_564);  add_tensor_110 = getitem_564 = None
        add_tensor_129 = torch.ops.aten.add.Tensor(add_tensor_111, getitem_565);  add_tensor_111 = getitem_565 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(getitem_563, silu__default_118, primals_504, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_563 = silu__default_118 = None
        getitem_566 = convolution_backward_default_29[0]
        getitem_567 = convolution_backward_default_29[1]
        getitem_568 = convolution_backward_default_29[2];  convolution_backward_default_29 = None
        add_tensor_130 = torch.ops.aten.add.Tensor(add_tensor_112, getitem_567);  add_tensor_112 = getitem_567 = None
        to_dtype_33 = torch.ops.aten.to.dtype(getitem_566, torch.float32);  getitem_566 = None
        to_dtype_34 = torch.ops.aten.to.dtype(clone_default_118, torch.float32);  clone_default_118 = None
        neg_default_11 = torch.ops.aten.neg.default(to_dtype_34)
        exp_default_11 = torch.ops.aten.exp.default(neg_default_11);  neg_default_11 = None
        add_tensor_131 = torch.ops.aten.add.Tensor(exp_default_11, 1);  exp_default_11 = None
        reciprocal_default_11 = torch.ops.aten.reciprocal.default(add_tensor_131);  add_tensor_131 = None
        mul_tensor_143 = torch.ops.aten.mul.Tensor(reciprocal_default_11, 1);  reciprocal_default_11 = None
        mul_tensor_144 = torch.ops.aten.mul.Tensor(to_dtype_33, mul_tensor_143);  to_dtype_33 = None
        rsub_scalar_11 = torch.ops.aten.rsub.Scalar(mul_tensor_143, 1);  mul_tensor_143 = None
        mul_tensor_145 = torch.ops.aten.mul.Tensor(to_dtype_34, rsub_scalar_11);  to_dtype_34 = rsub_scalar_11 = None
        add_tensor_132 = torch.ops.aten.add.Tensor(mul_tensor_145, 1);  mul_tensor_145 = None
        mul_tensor_146 = torch.ops.aten.mul.Tensor(mul_tensor_144, add_tensor_132);  mul_tensor_144 = add_tensor_132 = None
        to_dtype_35 = torch.ops.aten.to.dtype(mul_tensor_146, torch.float32);  mul_tensor_146 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_35, convolution_default_233, primals_904, primals_902, primals_903, new_zeros_default_372, new_zeros_default_373, False, 0.001, [True, True, True]);  to_dtype_35 = convolution_default_233 = primals_904 = primals_902 = primals_903 = new_zeros_default_372 = new_zeros_default_373 = None
        getitem_569 = native_batch_norm_backward_default_11[0]
        getitem_570 = native_batch_norm_backward_default_11[1]
        getitem_571 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_569, convolution_default_232, primals_503, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_569 = convolution_default_232 = None
        getitem_572 = convolution_backward_default_30[0]
        getitem_573 = convolution_backward_default_30[1]
        getitem_574 = convolution_backward_default_30[2];  convolution_backward_default_30 = None
        add_tensor_133 = torch.ops.aten.add.Tensor(add_tensor_115, getitem_573);  add_tensor_115 = getitem_573 = None
        add_tensor_134 = torch.ops.aten.add.Tensor(add_tensor_116, getitem_574);  add_tensor_116 = getitem_574 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(getitem_572, getitem_336, primals_501, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_572 = None
        getitem_575 = convolution_backward_default_31[0]
        getitem_576 = convolution_backward_default_31[1]
        getitem_577 = convolution_backward_default_31[2];  convolution_backward_default_31 = None
        add_tensor_135 = torch.ops.aten.add.Tensor(add_tensor_117, getitem_576);  add_tensor_117 = getitem_576 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(permute_default_14, convolution_default_230, primals_512, [36], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  permute_default_14 = convolution_default_230 = primals_512 = None
        getitem_578 = convolution_backward_default_32[0]
        getitem_579 = convolution_backward_default_32[1]
        getitem_580 = convolution_backward_default_32[2];  convolution_backward_default_32 = None
        add_tensor_136 = torch.ops.aten.add.Tensor(add_tensor_118, getitem_579);  add_tensor_118 = getitem_579 = None
        add_tensor_137 = torch.ops.aten.add.Tensor(add_tensor_119, getitem_580);  add_tensor_119 = getitem_580 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(getitem_578, silu__default_117, primals_510, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_578 = silu__default_117 = primals_510 = None
        getitem_581 = convolution_backward_default_33[0]
        getitem_582 = convolution_backward_default_33[1]
        getitem_583 = convolution_backward_default_33[2];  convolution_backward_default_33 = None
        add_tensor_138 = torch.ops.aten.add.Tensor(add_tensor_120, getitem_582);  add_tensor_120 = getitem_582 = None
        to_dtype_36 = torch.ops.aten.to.dtype(getitem_581, torch.float32);  getitem_581 = None
        to_dtype_37 = torch.ops.aten.to.dtype(clone_default_117, torch.float32);  clone_default_117 = None
        neg_default_12 = torch.ops.aten.neg.default(to_dtype_37)
        exp_default_12 = torch.ops.aten.exp.default(neg_default_12);  neg_default_12 = None
        add_tensor_139 = torch.ops.aten.add.Tensor(exp_default_12, 1);  exp_default_12 = None
        reciprocal_default_12 = torch.ops.aten.reciprocal.default(add_tensor_139);  add_tensor_139 = None
        mul_tensor_147 = torch.ops.aten.mul.Tensor(reciprocal_default_12, 1);  reciprocal_default_12 = None
        mul_tensor_148 = torch.ops.aten.mul.Tensor(to_dtype_36, mul_tensor_147);  to_dtype_36 = None
        rsub_scalar_12 = torch.ops.aten.rsub.Scalar(mul_tensor_147, 1);  mul_tensor_147 = None
        mul_tensor_149 = torch.ops.aten.mul.Tensor(to_dtype_37, rsub_scalar_12);  to_dtype_37 = rsub_scalar_12 = None
        add_tensor_140 = torch.ops.aten.add.Tensor(mul_tensor_149, 1);  mul_tensor_149 = None
        mul_tensor_150 = torch.ops.aten.mul.Tensor(mul_tensor_148, add_tensor_140);  mul_tensor_148 = add_tensor_140 = None
        to_dtype_38 = torch.ops.aten.to.dtype(mul_tensor_150, torch.float32);  mul_tensor_150 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_38, convolution_default_229, primals_884, primals_882, primals_883, new_zeros_default_369, new_zeros_default_370, False, 0.001, [True, True, True]);  to_dtype_38 = convolution_default_229 = primals_884 = primals_882 = primals_883 = new_zeros_default_369 = new_zeros_default_370 = None
        getitem_584 = native_batch_norm_backward_default_12[0]
        getitem_585 = native_batch_norm_backward_default_12[1]
        getitem_586 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(getitem_584, convolution_default_228, primals_509, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_584 = convolution_default_228 = primals_509 = None
        getitem_587 = convolution_backward_default_34[0]
        getitem_588 = convolution_backward_default_34[1]
        getitem_589 = convolution_backward_default_34[2];  convolution_backward_default_34 = None
        add_tensor_141 = torch.ops.aten.add.Tensor(add_tensor_123, getitem_588);  add_tensor_123 = getitem_588 = None
        add_tensor_142 = torch.ops.aten.add.Tensor(add_tensor_124, getitem_589);  add_tensor_124 = getitem_589 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_587, silu__default_116, primals_507, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_587 = silu__default_116 = primals_507 = None
        getitem_590 = convolution_backward_default_35[0]
        getitem_591 = convolution_backward_default_35[1]
        getitem_592 = convolution_backward_default_35[2];  convolution_backward_default_35 = None
        add_tensor_143 = torch.ops.aten.add.Tensor(add_tensor_125, getitem_591);  add_tensor_125 = getitem_591 = None
        to_dtype_39 = torch.ops.aten.to.dtype(getitem_590, torch.float32);  getitem_590 = None
        to_dtype_40 = torch.ops.aten.to.dtype(clone_default_116, torch.float32);  clone_default_116 = None
        neg_default_13 = torch.ops.aten.neg.default(to_dtype_40)
        exp_default_13 = torch.ops.aten.exp.default(neg_default_13);  neg_default_13 = None
        add_tensor_144 = torch.ops.aten.add.Tensor(exp_default_13, 1);  exp_default_13 = None
        reciprocal_default_13 = torch.ops.aten.reciprocal.default(add_tensor_144);  add_tensor_144 = None
        mul_tensor_151 = torch.ops.aten.mul.Tensor(reciprocal_default_13, 1);  reciprocal_default_13 = None
        mul_tensor_152 = torch.ops.aten.mul.Tensor(to_dtype_39, mul_tensor_151);  to_dtype_39 = None
        rsub_scalar_13 = torch.ops.aten.rsub.Scalar(mul_tensor_151, 1);  mul_tensor_151 = None
        mul_tensor_153 = torch.ops.aten.mul.Tensor(to_dtype_40, rsub_scalar_13);  to_dtype_40 = rsub_scalar_13 = None
        add_tensor_145 = torch.ops.aten.add.Tensor(mul_tensor_153, 1);  mul_tensor_153 = None
        mul_tensor_154 = torch.ops.aten.mul.Tensor(mul_tensor_152, add_tensor_145);  mul_tensor_152 = add_tensor_145 = None
        to_dtype_41 = torch.ops.aten.to.dtype(mul_tensor_154, torch.float32);  mul_tensor_154 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_41, convolution_default_227, primals_879, primals_877, primals_878, new_zeros_default_366, new_zeros_default_367, False, 0.001, [True, True, True]);  to_dtype_41 = convolution_default_227 = primals_879 = primals_877 = primals_878 = new_zeros_default_366 = new_zeros_default_367 = None
        getitem_593 = native_batch_norm_backward_default_13[0]
        getitem_594 = native_batch_norm_backward_default_13[1]
        getitem_595 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(getitem_593, convolution_default_226, primals_506, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_593 = convolution_default_226 = primals_506 = None
        getitem_596 = convolution_backward_default_36[0]
        getitem_597 = convolution_backward_default_36[1]
        getitem_598 = convolution_backward_default_36[2];  convolution_backward_default_36 = None
        add_tensor_146 = torch.ops.aten.add.Tensor(add_tensor_128, getitem_597);  add_tensor_128 = getitem_597 = None
        add_tensor_147 = torch.ops.aten.add.Tensor(add_tensor_129, getitem_598);  add_tensor_129 = getitem_598 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(getitem_596, silu__default_115, primals_504, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_596 = silu__default_115 = primals_504 = None
        getitem_599 = convolution_backward_default_37[0]
        getitem_600 = convolution_backward_default_37[1]
        getitem_601 = convolution_backward_default_37[2];  convolution_backward_default_37 = None
        add_tensor_148 = torch.ops.aten.add.Tensor(add_tensor_130, getitem_600);  add_tensor_130 = getitem_600 = None
        to_dtype_42 = torch.ops.aten.to.dtype(getitem_599, torch.float32);  getitem_599 = None
        to_dtype_43 = torch.ops.aten.to.dtype(clone_default_115, torch.float32);  clone_default_115 = None
        neg_default_14 = torch.ops.aten.neg.default(to_dtype_43)
        exp_default_14 = torch.ops.aten.exp.default(neg_default_14);  neg_default_14 = None
        add_tensor_149 = torch.ops.aten.add.Tensor(exp_default_14, 1);  exp_default_14 = None
        reciprocal_default_14 = torch.ops.aten.reciprocal.default(add_tensor_149);  add_tensor_149 = None
        mul_tensor_155 = torch.ops.aten.mul.Tensor(reciprocal_default_14, 1);  reciprocal_default_14 = None
        mul_tensor_156 = torch.ops.aten.mul.Tensor(to_dtype_42, mul_tensor_155);  to_dtype_42 = None
        rsub_scalar_14 = torch.ops.aten.rsub.Scalar(mul_tensor_155, 1);  mul_tensor_155 = None
        mul_tensor_157 = torch.ops.aten.mul.Tensor(to_dtype_43, rsub_scalar_14);  to_dtype_43 = rsub_scalar_14 = None
        add_tensor_150 = torch.ops.aten.add.Tensor(mul_tensor_157, 1);  mul_tensor_157 = None
        mul_tensor_158 = torch.ops.aten.mul.Tensor(mul_tensor_156, add_tensor_150);  mul_tensor_156 = add_tensor_150 = None
        to_dtype_44 = torch.ops.aten.to.dtype(mul_tensor_158, torch.float32);  mul_tensor_158 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_44, convolution_default_225, primals_874, primals_872, primals_873, new_zeros_default_363, new_zeros_default_364, False, 0.001, [True, True, True]);  to_dtype_44 = convolution_default_225 = primals_874 = primals_872 = primals_873 = new_zeros_default_363 = new_zeros_default_364 = None
        getitem_602 = native_batch_norm_backward_default_14[0]
        getitem_603 = native_batch_norm_backward_default_14[1]
        getitem_604 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(getitem_602, convolution_default_224, primals_503, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_602 = convolution_default_224 = primals_503 = None
        getitem_605 = convolution_backward_default_38[0]
        getitem_606 = convolution_backward_default_38[1]
        getitem_607 = convolution_backward_default_38[2];  convolution_backward_default_38 = None
        add_tensor_151 = torch.ops.aten.add.Tensor(add_tensor_133, getitem_606);  add_tensor_133 = getitem_606 = None
        add_tensor_152 = torch.ops.aten.add.Tensor(add_tensor_134, getitem_607);  add_tensor_134 = getitem_607 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(getitem_605, getitem_331, primals_501, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_605 = primals_501 = None
        getitem_608 = convolution_backward_default_39[0]
        getitem_609 = convolution_backward_default_39[1]
        getitem_610 = convolution_backward_default_39[2];  convolution_backward_default_39 = None
        add_tensor_153 = torch.ops.aten.add.Tensor(add_tensor_135, getitem_609);  add_tensor_135 = getitem_609 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(permute_default_15, convolution_default_222, primals_524, [810], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  permute_default_15 = convolution_default_222 = None
        getitem_611 = convolution_backward_default_40[0]
        getitem_612 = convolution_backward_default_40[1]
        getitem_613 = convolution_backward_default_40[2];  convolution_backward_default_40 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(getitem_611, silu__default_114, primals_522, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_611 = silu__default_114 = None
        getitem_614 = convolution_backward_default_41[0]
        getitem_615 = convolution_backward_default_41[1]
        getitem_616 = convolution_backward_default_41[2];  convolution_backward_default_41 = None
        to_dtype_45 = torch.ops.aten.to.dtype(getitem_614, torch.float32);  getitem_614 = None
        to_dtype_46 = torch.ops.aten.to.dtype(clone_default_114, torch.float32);  clone_default_114 = None
        neg_default_15 = torch.ops.aten.neg.default(to_dtype_46)
        exp_default_15 = torch.ops.aten.exp.default(neg_default_15);  neg_default_15 = None
        add_tensor_154 = torch.ops.aten.add.Tensor(exp_default_15, 1);  exp_default_15 = None
        reciprocal_default_15 = torch.ops.aten.reciprocal.default(add_tensor_154);  add_tensor_154 = None
        mul_tensor_159 = torch.ops.aten.mul.Tensor(reciprocal_default_15, 1);  reciprocal_default_15 = None
        mul_tensor_160 = torch.ops.aten.mul.Tensor(to_dtype_45, mul_tensor_159);  to_dtype_45 = None
        rsub_scalar_15 = torch.ops.aten.rsub.Scalar(mul_tensor_159, 1);  mul_tensor_159 = None
        mul_tensor_161 = torch.ops.aten.mul.Tensor(to_dtype_46, rsub_scalar_15);  to_dtype_46 = rsub_scalar_15 = None
        add_tensor_155 = torch.ops.aten.add.Tensor(mul_tensor_161, 1);  mul_tensor_161 = None
        mul_tensor_162 = torch.ops.aten.mul.Tensor(mul_tensor_160, add_tensor_155);  mul_tensor_160 = add_tensor_155 = None
        to_dtype_47 = torch.ops.aten.to.dtype(mul_tensor_162, torch.float32);  mul_tensor_162 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_47, convolution_default_221, primals_989, primals_987, primals_988, new_zeros_default_360, new_zeros_default_361, False, 0.001, [True, True, True]);  to_dtype_47 = convolution_default_221 = primals_989 = primals_987 = primals_988 = new_zeros_default_360 = new_zeros_default_361 = None
        getitem_617 = native_batch_norm_backward_default_15[0]
        getitem_618 = native_batch_norm_backward_default_15[1]
        getitem_619 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(getitem_617, convolution_default_220, primals_521, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_617 = convolution_default_220 = None
        getitem_620 = convolution_backward_default_42[0]
        getitem_621 = convolution_backward_default_42[1]
        getitem_622 = convolution_backward_default_42[2];  convolution_backward_default_42 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(getitem_620, silu__default_113, primals_519, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_620 = silu__default_113 = None
        getitem_623 = convolution_backward_default_43[0]
        getitem_624 = convolution_backward_default_43[1]
        getitem_625 = convolution_backward_default_43[2];  convolution_backward_default_43 = None
        to_dtype_48 = torch.ops.aten.to.dtype(getitem_623, torch.float32);  getitem_623 = None
        to_dtype_49 = torch.ops.aten.to.dtype(clone_default_113, torch.float32);  clone_default_113 = None
        neg_default_16 = torch.ops.aten.neg.default(to_dtype_49)
        exp_default_16 = torch.ops.aten.exp.default(neg_default_16);  neg_default_16 = None
        add_tensor_156 = torch.ops.aten.add.Tensor(exp_default_16, 1);  exp_default_16 = None
        reciprocal_default_16 = torch.ops.aten.reciprocal.default(add_tensor_156);  add_tensor_156 = None
        mul_tensor_163 = torch.ops.aten.mul.Tensor(reciprocal_default_16, 1);  reciprocal_default_16 = None
        mul_tensor_164 = torch.ops.aten.mul.Tensor(to_dtype_48, mul_tensor_163);  to_dtype_48 = None
        rsub_scalar_16 = torch.ops.aten.rsub.Scalar(mul_tensor_163, 1);  mul_tensor_163 = None
        mul_tensor_165 = torch.ops.aten.mul.Tensor(to_dtype_49, rsub_scalar_16);  to_dtype_49 = rsub_scalar_16 = None
        add_tensor_157 = torch.ops.aten.add.Tensor(mul_tensor_165, 1);  mul_tensor_165 = None
        mul_tensor_166 = torch.ops.aten.mul.Tensor(mul_tensor_164, add_tensor_157);  mul_tensor_164 = add_tensor_157 = None
        to_dtype_50 = torch.ops.aten.to.dtype(mul_tensor_166, torch.float32);  mul_tensor_166 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_50, convolution_default_219, primals_984, primals_982, primals_983, new_zeros_default_357, new_zeros_default_358, False, 0.001, [True, True, True]);  to_dtype_50 = convolution_default_219 = primals_984 = primals_982 = primals_983 = new_zeros_default_357 = new_zeros_default_358 = None
        getitem_626 = native_batch_norm_backward_default_16[0]
        getitem_627 = native_batch_norm_backward_default_16[1]
        getitem_628 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(getitem_626, convolution_default_218, primals_518, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_626 = convolution_default_218 = None
        getitem_629 = convolution_backward_default_44[0]
        getitem_630 = convolution_backward_default_44[1]
        getitem_631 = convolution_backward_default_44[2];  convolution_backward_default_44 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(getitem_629, silu__default_112, primals_516, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_629 = silu__default_112 = None
        getitem_632 = convolution_backward_default_45[0]
        getitem_633 = convolution_backward_default_45[1]
        getitem_634 = convolution_backward_default_45[2];  convolution_backward_default_45 = None
        to_dtype_51 = torch.ops.aten.to.dtype(getitem_632, torch.float32);  getitem_632 = None
        to_dtype_52 = torch.ops.aten.to.dtype(clone_default_112, torch.float32);  clone_default_112 = None
        neg_default_17 = torch.ops.aten.neg.default(to_dtype_52)
        exp_default_17 = torch.ops.aten.exp.default(neg_default_17);  neg_default_17 = None
        add_tensor_158 = torch.ops.aten.add.Tensor(exp_default_17, 1);  exp_default_17 = None
        reciprocal_default_17 = torch.ops.aten.reciprocal.default(add_tensor_158);  add_tensor_158 = None
        mul_tensor_167 = torch.ops.aten.mul.Tensor(reciprocal_default_17, 1);  reciprocal_default_17 = None
        mul_tensor_168 = torch.ops.aten.mul.Tensor(to_dtype_51, mul_tensor_167);  to_dtype_51 = None
        rsub_scalar_17 = torch.ops.aten.rsub.Scalar(mul_tensor_167, 1);  mul_tensor_167 = None
        mul_tensor_169 = torch.ops.aten.mul.Tensor(to_dtype_52, rsub_scalar_17);  to_dtype_52 = rsub_scalar_17 = None
        add_tensor_159 = torch.ops.aten.add.Tensor(mul_tensor_169, 1);  mul_tensor_169 = None
        mul_tensor_170 = torch.ops.aten.mul.Tensor(mul_tensor_168, add_tensor_159);  mul_tensor_168 = add_tensor_159 = None
        to_dtype_53 = torch.ops.aten.to.dtype(mul_tensor_170, torch.float32);  mul_tensor_170 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_53, convolution_default_217, primals_979, primals_977, primals_978, new_zeros_default_354, new_zeros_default_355, False, 0.001, [True, True, True]);  to_dtype_53 = convolution_default_217 = primals_979 = primals_977 = primals_978 = new_zeros_default_354 = new_zeros_default_355 = None
        getitem_635 = native_batch_norm_backward_default_17[0]
        getitem_636 = native_batch_norm_backward_default_17[1]
        getitem_637 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(getitem_635, convolution_default_216, primals_515, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_635 = convolution_default_216 = None
        getitem_638 = convolution_backward_default_46[0]
        getitem_639 = convolution_backward_default_46[1]
        getitem_640 = convolution_backward_default_46[2];  convolution_backward_default_46 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(getitem_638, getitem_351, primals_513, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_638 = getitem_351 = None
        getitem_641 = convolution_backward_default_47[0]
        getitem_642 = convolution_backward_default_47[1]
        getitem_643 = convolution_backward_default_47[2];  convolution_backward_default_47 = None
        add_tensor_160 = torch.ops.aten.add.Tensor(getitem_476, getitem_641);  getitem_476 = getitem_641 = None
        convolution_backward_default_48 = torch.ops.aten.convolution_backward.default(permute_default_16, convolution_default_214, primals_524, [810], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  permute_default_16 = convolution_default_214 = None
        getitem_644 = convolution_backward_default_48[0]
        getitem_645 = convolution_backward_default_48[1]
        getitem_646 = convolution_backward_default_48[2];  convolution_backward_default_48 = None
        add_tensor_161 = torch.ops.aten.add.Tensor(getitem_612, getitem_645);  getitem_612 = getitem_645 = None
        add_tensor_162 = torch.ops.aten.add.Tensor(getitem_613, getitem_646);  getitem_613 = getitem_646 = None
        convolution_backward_default_49 = torch.ops.aten.convolution_backward.default(getitem_644, silu__default_111, primals_522, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_644 = silu__default_111 = None
        getitem_647 = convolution_backward_default_49[0]
        getitem_648 = convolution_backward_default_49[1]
        getitem_649 = convolution_backward_default_49[2];  convolution_backward_default_49 = None
        add_tensor_163 = torch.ops.aten.add.Tensor(getitem_615, getitem_648);  getitem_615 = getitem_648 = None
        to_dtype_54 = torch.ops.aten.to.dtype(getitem_647, torch.float32);  getitem_647 = None
        to_dtype_55 = torch.ops.aten.to.dtype(clone_default_111, torch.float32);  clone_default_111 = None
        neg_default_18 = torch.ops.aten.neg.default(to_dtype_55)
        exp_default_18 = torch.ops.aten.exp.default(neg_default_18);  neg_default_18 = None
        add_tensor_164 = torch.ops.aten.add.Tensor(exp_default_18, 1);  exp_default_18 = None
        reciprocal_default_18 = torch.ops.aten.reciprocal.default(add_tensor_164);  add_tensor_164 = None
        mul_tensor_171 = torch.ops.aten.mul.Tensor(reciprocal_default_18, 1);  reciprocal_default_18 = None
        mul_tensor_172 = torch.ops.aten.mul.Tensor(to_dtype_54, mul_tensor_171);  to_dtype_54 = None
        rsub_scalar_18 = torch.ops.aten.rsub.Scalar(mul_tensor_171, 1);  mul_tensor_171 = None
        mul_tensor_173 = torch.ops.aten.mul.Tensor(to_dtype_55, rsub_scalar_18);  to_dtype_55 = rsub_scalar_18 = None
        add_tensor_165 = torch.ops.aten.add.Tensor(mul_tensor_173, 1);  mul_tensor_173 = None
        mul_tensor_174 = torch.ops.aten.mul.Tensor(mul_tensor_172, add_tensor_165);  mul_tensor_172 = add_tensor_165 = None
        to_dtype_56 = torch.ops.aten.to.dtype(mul_tensor_174, torch.float32);  mul_tensor_174 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_56, convolution_default_213, primals_959, primals_957, primals_958, new_zeros_default_351, new_zeros_default_352, False, 0.001, [True, True, True]);  to_dtype_56 = convolution_default_213 = primals_959 = primals_957 = primals_958 = new_zeros_default_351 = new_zeros_default_352 = None
        getitem_650 = native_batch_norm_backward_default_18[0]
        getitem_651 = native_batch_norm_backward_default_18[1]
        getitem_652 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_50 = torch.ops.aten.convolution_backward.default(getitem_650, convolution_default_212, primals_521, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_650 = convolution_default_212 = None
        getitem_653 = convolution_backward_default_50[0]
        getitem_654 = convolution_backward_default_50[1]
        getitem_655 = convolution_backward_default_50[2];  convolution_backward_default_50 = None
        add_tensor_166 = torch.ops.aten.add.Tensor(getitem_621, getitem_654);  getitem_621 = getitem_654 = None
        add_tensor_167 = torch.ops.aten.add.Tensor(getitem_622, getitem_655);  getitem_622 = getitem_655 = None
        convolution_backward_default_51 = torch.ops.aten.convolution_backward.default(getitem_653, silu__default_110, primals_519, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_653 = silu__default_110 = None
        getitem_656 = convolution_backward_default_51[0]
        getitem_657 = convolution_backward_default_51[1]
        getitem_658 = convolution_backward_default_51[2];  convolution_backward_default_51 = None
        add_tensor_168 = torch.ops.aten.add.Tensor(getitem_624, getitem_657);  getitem_624 = getitem_657 = None
        to_dtype_57 = torch.ops.aten.to.dtype(getitem_656, torch.float32);  getitem_656 = None
        to_dtype_58 = torch.ops.aten.to.dtype(clone_default_110, torch.float32);  clone_default_110 = None
        neg_default_19 = torch.ops.aten.neg.default(to_dtype_58)
        exp_default_19 = torch.ops.aten.exp.default(neg_default_19);  neg_default_19 = None
        add_tensor_169 = torch.ops.aten.add.Tensor(exp_default_19, 1);  exp_default_19 = None
        reciprocal_default_19 = torch.ops.aten.reciprocal.default(add_tensor_169);  add_tensor_169 = None
        mul_tensor_175 = torch.ops.aten.mul.Tensor(reciprocal_default_19, 1);  reciprocal_default_19 = None
        mul_tensor_176 = torch.ops.aten.mul.Tensor(to_dtype_57, mul_tensor_175);  to_dtype_57 = None
        rsub_scalar_19 = torch.ops.aten.rsub.Scalar(mul_tensor_175, 1);  mul_tensor_175 = None
        mul_tensor_177 = torch.ops.aten.mul.Tensor(to_dtype_58, rsub_scalar_19);  to_dtype_58 = rsub_scalar_19 = None
        add_tensor_170 = torch.ops.aten.add.Tensor(mul_tensor_177, 1);  mul_tensor_177 = None
        mul_tensor_178 = torch.ops.aten.mul.Tensor(mul_tensor_176, add_tensor_170);  mul_tensor_176 = add_tensor_170 = None
        to_dtype_59 = torch.ops.aten.to.dtype(mul_tensor_178, torch.float32);  mul_tensor_178 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_59, convolution_default_211, primals_954, primals_952, primals_953, new_zeros_default_348, new_zeros_default_349, False, 0.001, [True, True, True]);  to_dtype_59 = convolution_default_211 = primals_954 = primals_952 = primals_953 = new_zeros_default_348 = new_zeros_default_349 = None
        getitem_659 = native_batch_norm_backward_default_19[0]
        getitem_660 = native_batch_norm_backward_default_19[1]
        getitem_661 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_52 = torch.ops.aten.convolution_backward.default(getitem_659, convolution_default_210, primals_518, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_659 = convolution_default_210 = None
        getitem_662 = convolution_backward_default_52[0]
        getitem_663 = convolution_backward_default_52[1]
        getitem_664 = convolution_backward_default_52[2];  convolution_backward_default_52 = None
        add_tensor_171 = torch.ops.aten.add.Tensor(getitem_630, getitem_663);  getitem_630 = getitem_663 = None
        add_tensor_172 = torch.ops.aten.add.Tensor(getitem_631, getitem_664);  getitem_631 = getitem_664 = None
        convolution_backward_default_53 = torch.ops.aten.convolution_backward.default(getitem_662, silu__default_109, primals_516, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_662 = silu__default_109 = None
        getitem_665 = convolution_backward_default_53[0]
        getitem_666 = convolution_backward_default_53[1]
        getitem_667 = convolution_backward_default_53[2];  convolution_backward_default_53 = None
        add_tensor_173 = torch.ops.aten.add.Tensor(getitem_633, getitem_666);  getitem_633 = getitem_666 = None
        to_dtype_60 = torch.ops.aten.to.dtype(getitem_665, torch.float32);  getitem_665 = None
        to_dtype_61 = torch.ops.aten.to.dtype(clone_default_109, torch.float32);  clone_default_109 = None
        neg_default_20 = torch.ops.aten.neg.default(to_dtype_61)
        exp_default_20 = torch.ops.aten.exp.default(neg_default_20);  neg_default_20 = None
        add_tensor_174 = torch.ops.aten.add.Tensor(exp_default_20, 1);  exp_default_20 = None
        reciprocal_default_20 = torch.ops.aten.reciprocal.default(add_tensor_174);  add_tensor_174 = None
        mul_tensor_179 = torch.ops.aten.mul.Tensor(reciprocal_default_20, 1);  reciprocal_default_20 = None
        mul_tensor_180 = torch.ops.aten.mul.Tensor(to_dtype_60, mul_tensor_179);  to_dtype_60 = None
        rsub_scalar_20 = torch.ops.aten.rsub.Scalar(mul_tensor_179, 1);  mul_tensor_179 = None
        mul_tensor_181 = torch.ops.aten.mul.Tensor(to_dtype_61, rsub_scalar_20);  to_dtype_61 = rsub_scalar_20 = None
        add_tensor_175 = torch.ops.aten.add.Tensor(mul_tensor_181, 1);  mul_tensor_181 = None
        mul_tensor_182 = torch.ops.aten.mul.Tensor(mul_tensor_180, add_tensor_175);  mul_tensor_180 = add_tensor_175 = None
        to_dtype_62 = torch.ops.aten.to.dtype(mul_tensor_182, torch.float32);  mul_tensor_182 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_62, convolution_default_209, primals_949, primals_947, primals_948, new_zeros_default_345, new_zeros_default_346, False, 0.001, [True, True, True]);  to_dtype_62 = convolution_default_209 = primals_949 = primals_947 = primals_948 = new_zeros_default_345 = new_zeros_default_346 = None
        getitem_668 = native_batch_norm_backward_default_20[0]
        getitem_669 = native_batch_norm_backward_default_20[1]
        getitem_670 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_54 = torch.ops.aten.convolution_backward.default(getitem_668, convolution_default_208, primals_515, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_668 = convolution_default_208 = None
        getitem_671 = convolution_backward_default_54[0]
        getitem_672 = convolution_backward_default_54[1]
        getitem_673 = convolution_backward_default_54[2];  convolution_backward_default_54 = None
        add_tensor_176 = torch.ops.aten.add.Tensor(getitem_639, getitem_672);  getitem_639 = getitem_672 = None
        add_tensor_177 = torch.ops.aten.add.Tensor(getitem_640, getitem_673);  getitem_640 = getitem_673 = None
        convolution_backward_default_55 = torch.ops.aten.convolution_backward.default(getitem_671, getitem_346, primals_513, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_671 = getitem_346 = None
        getitem_674 = convolution_backward_default_55[0]
        getitem_675 = convolution_backward_default_55[1]
        getitem_676 = convolution_backward_default_55[2];  convolution_backward_default_55 = None
        add_tensor_178 = torch.ops.aten.add.Tensor(getitem_509, getitem_674);  getitem_509 = getitem_674 = None
        add_tensor_179 = torch.ops.aten.add.Tensor(getitem_642, getitem_675);  getitem_642 = getitem_675 = None
        convolution_backward_default_56 = torch.ops.aten.convolution_backward.default(permute_default_17, convolution_default_206, primals_524, [810], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  permute_default_17 = convolution_default_206 = None
        getitem_677 = convolution_backward_default_56[0]
        getitem_678 = convolution_backward_default_56[1]
        getitem_679 = convolution_backward_default_56[2];  convolution_backward_default_56 = None
        add_tensor_180 = torch.ops.aten.add.Tensor(add_tensor_161, getitem_678);  add_tensor_161 = getitem_678 = None
        add_tensor_181 = torch.ops.aten.add.Tensor(add_tensor_162, getitem_679);  add_tensor_162 = getitem_679 = None
        convolution_backward_default_57 = torch.ops.aten.convolution_backward.default(getitem_677, silu__default_108, primals_522, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_677 = silu__default_108 = None
        getitem_680 = convolution_backward_default_57[0]
        getitem_681 = convolution_backward_default_57[1]
        getitem_682 = convolution_backward_default_57[2];  convolution_backward_default_57 = None
        add_tensor_182 = torch.ops.aten.add.Tensor(add_tensor_163, getitem_681);  add_tensor_163 = getitem_681 = None
        to_dtype_63 = torch.ops.aten.to.dtype(getitem_680, torch.float32);  getitem_680 = None
        to_dtype_64 = torch.ops.aten.to.dtype(clone_default_108, torch.float32);  clone_default_108 = None
        neg_default_21 = torch.ops.aten.neg.default(to_dtype_64)
        exp_default_21 = torch.ops.aten.exp.default(neg_default_21);  neg_default_21 = None
        add_tensor_183 = torch.ops.aten.add.Tensor(exp_default_21, 1);  exp_default_21 = None
        reciprocal_default_21 = torch.ops.aten.reciprocal.default(add_tensor_183);  add_tensor_183 = None
        mul_tensor_183 = torch.ops.aten.mul.Tensor(reciprocal_default_21, 1);  reciprocal_default_21 = None
        mul_tensor_184 = torch.ops.aten.mul.Tensor(to_dtype_63, mul_tensor_183);  to_dtype_63 = None
        rsub_scalar_21 = torch.ops.aten.rsub.Scalar(mul_tensor_183, 1);  mul_tensor_183 = None
        mul_tensor_185 = torch.ops.aten.mul.Tensor(to_dtype_64, rsub_scalar_21);  to_dtype_64 = rsub_scalar_21 = None
        add_tensor_184 = torch.ops.aten.add.Tensor(mul_tensor_185, 1);  mul_tensor_185 = None
        mul_tensor_186 = torch.ops.aten.mul.Tensor(mul_tensor_184, add_tensor_184);  mul_tensor_184 = add_tensor_184 = None
        to_dtype_65 = torch.ops.aten.to.dtype(mul_tensor_186, torch.float32);  mul_tensor_186 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_65, convolution_default_205, primals_929, primals_927, primals_928, new_zeros_default_342, new_zeros_default_343, False, 0.001, [True, True, True]);  to_dtype_65 = convolution_default_205 = primals_929 = primals_927 = primals_928 = new_zeros_default_342 = new_zeros_default_343 = None
        getitem_683 = native_batch_norm_backward_default_21[0]
        getitem_684 = native_batch_norm_backward_default_21[1]
        getitem_685 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_58 = torch.ops.aten.convolution_backward.default(getitem_683, convolution_default_204, primals_521, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_683 = convolution_default_204 = None
        getitem_686 = convolution_backward_default_58[0]
        getitem_687 = convolution_backward_default_58[1]
        getitem_688 = convolution_backward_default_58[2];  convolution_backward_default_58 = None
        add_tensor_185 = torch.ops.aten.add.Tensor(add_tensor_166, getitem_687);  add_tensor_166 = getitem_687 = None
        add_tensor_186 = torch.ops.aten.add.Tensor(add_tensor_167, getitem_688);  add_tensor_167 = getitem_688 = None
        convolution_backward_default_59 = torch.ops.aten.convolution_backward.default(getitem_686, silu__default_107, primals_519, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_686 = silu__default_107 = None
        getitem_689 = convolution_backward_default_59[0]
        getitem_690 = convolution_backward_default_59[1]
        getitem_691 = convolution_backward_default_59[2];  convolution_backward_default_59 = None
        add_tensor_187 = torch.ops.aten.add.Tensor(add_tensor_168, getitem_690);  add_tensor_168 = getitem_690 = None
        to_dtype_66 = torch.ops.aten.to.dtype(getitem_689, torch.float32);  getitem_689 = None
        to_dtype_67 = torch.ops.aten.to.dtype(clone_default_107, torch.float32);  clone_default_107 = None
        neg_default_22 = torch.ops.aten.neg.default(to_dtype_67)
        exp_default_22 = torch.ops.aten.exp.default(neg_default_22);  neg_default_22 = None
        add_tensor_188 = torch.ops.aten.add.Tensor(exp_default_22, 1);  exp_default_22 = None
        reciprocal_default_22 = torch.ops.aten.reciprocal.default(add_tensor_188);  add_tensor_188 = None
        mul_tensor_187 = torch.ops.aten.mul.Tensor(reciprocal_default_22, 1);  reciprocal_default_22 = None
        mul_tensor_188 = torch.ops.aten.mul.Tensor(to_dtype_66, mul_tensor_187);  to_dtype_66 = None
        rsub_scalar_22 = torch.ops.aten.rsub.Scalar(mul_tensor_187, 1);  mul_tensor_187 = None
        mul_tensor_189 = torch.ops.aten.mul.Tensor(to_dtype_67, rsub_scalar_22);  to_dtype_67 = rsub_scalar_22 = None
        add_tensor_189 = torch.ops.aten.add.Tensor(mul_tensor_189, 1);  mul_tensor_189 = None
        mul_tensor_190 = torch.ops.aten.mul.Tensor(mul_tensor_188, add_tensor_189);  mul_tensor_188 = add_tensor_189 = None
        to_dtype_68 = torch.ops.aten.to.dtype(mul_tensor_190, torch.float32);  mul_tensor_190 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_68, convolution_default_203, primals_924, primals_922, primals_923, new_zeros_default_339, new_zeros_default_340, False, 0.001, [True, True, True]);  to_dtype_68 = convolution_default_203 = primals_924 = primals_922 = primals_923 = new_zeros_default_339 = new_zeros_default_340 = None
        getitem_692 = native_batch_norm_backward_default_22[0]
        getitem_693 = native_batch_norm_backward_default_22[1]
        getitem_694 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_60 = torch.ops.aten.convolution_backward.default(getitem_692, convolution_default_202, primals_518, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_692 = convolution_default_202 = None
        getitem_695 = convolution_backward_default_60[0]
        getitem_696 = convolution_backward_default_60[1]
        getitem_697 = convolution_backward_default_60[2];  convolution_backward_default_60 = None
        add_tensor_190 = torch.ops.aten.add.Tensor(add_tensor_171, getitem_696);  add_tensor_171 = getitem_696 = None
        add_tensor_191 = torch.ops.aten.add.Tensor(add_tensor_172, getitem_697);  add_tensor_172 = getitem_697 = None
        convolution_backward_default_61 = torch.ops.aten.convolution_backward.default(getitem_695, silu__default_106, primals_516, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_695 = silu__default_106 = None
        getitem_698 = convolution_backward_default_61[0]
        getitem_699 = convolution_backward_default_61[1]
        getitem_700 = convolution_backward_default_61[2];  convolution_backward_default_61 = None
        add_tensor_192 = torch.ops.aten.add.Tensor(add_tensor_173, getitem_699);  add_tensor_173 = getitem_699 = None
        to_dtype_69 = torch.ops.aten.to.dtype(getitem_698, torch.float32);  getitem_698 = None
        to_dtype_70 = torch.ops.aten.to.dtype(clone_default_106, torch.float32);  clone_default_106 = None
        neg_default_23 = torch.ops.aten.neg.default(to_dtype_70)
        exp_default_23 = torch.ops.aten.exp.default(neg_default_23);  neg_default_23 = None
        add_tensor_193 = torch.ops.aten.add.Tensor(exp_default_23, 1);  exp_default_23 = None
        reciprocal_default_23 = torch.ops.aten.reciprocal.default(add_tensor_193);  add_tensor_193 = None
        mul_tensor_191 = torch.ops.aten.mul.Tensor(reciprocal_default_23, 1);  reciprocal_default_23 = None
        mul_tensor_192 = torch.ops.aten.mul.Tensor(to_dtype_69, mul_tensor_191);  to_dtype_69 = None
        rsub_scalar_23 = torch.ops.aten.rsub.Scalar(mul_tensor_191, 1);  mul_tensor_191 = None
        mul_tensor_193 = torch.ops.aten.mul.Tensor(to_dtype_70, rsub_scalar_23);  to_dtype_70 = rsub_scalar_23 = None
        add_tensor_194 = torch.ops.aten.add.Tensor(mul_tensor_193, 1);  mul_tensor_193 = None
        mul_tensor_194 = torch.ops.aten.mul.Tensor(mul_tensor_192, add_tensor_194);  mul_tensor_192 = add_tensor_194 = None
        to_dtype_71 = torch.ops.aten.to.dtype(mul_tensor_194, torch.float32);  mul_tensor_194 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_71, convolution_default_201, primals_919, primals_917, primals_918, new_zeros_default_336, new_zeros_default_337, False, 0.001, [True, True, True]);  to_dtype_71 = convolution_default_201 = primals_919 = primals_917 = primals_918 = new_zeros_default_336 = new_zeros_default_337 = None
        getitem_701 = native_batch_norm_backward_default_23[0]
        getitem_702 = native_batch_norm_backward_default_23[1]
        getitem_703 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        convolution_backward_default_62 = torch.ops.aten.convolution_backward.default(getitem_701, convolution_default_200, primals_515, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_701 = convolution_default_200 = None
        getitem_704 = convolution_backward_default_62[0]
        getitem_705 = convolution_backward_default_62[1]
        getitem_706 = convolution_backward_default_62[2];  convolution_backward_default_62 = None
        add_tensor_195 = torch.ops.aten.add.Tensor(add_tensor_176, getitem_705);  add_tensor_176 = getitem_705 = None
        add_tensor_196 = torch.ops.aten.add.Tensor(add_tensor_177, getitem_706);  add_tensor_177 = getitem_706 = None
        convolution_backward_default_63 = torch.ops.aten.convolution_backward.default(getitem_704, getitem_341, primals_513, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_704 = getitem_341 = None
        getitem_707 = convolution_backward_default_63[0]
        getitem_708 = convolution_backward_default_63[1]
        getitem_709 = convolution_backward_default_63[2];  convolution_backward_default_63 = None
        add_tensor_197 = torch.ops.aten.add.Tensor(getitem_542, getitem_707);  getitem_542 = getitem_707 = None
        add_tensor_198 = torch.ops.aten.add.Tensor(add_tensor_179, getitem_708);  add_tensor_179 = getitem_708 = None
        convolution_backward_default_64 = torch.ops.aten.convolution_backward.default(permute_default_18, convolution_default_198, primals_524, [810], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  permute_default_18 = convolution_default_198 = None
        getitem_710 = convolution_backward_default_64[0]
        getitem_711 = convolution_backward_default_64[1]
        getitem_712 = convolution_backward_default_64[2];  convolution_backward_default_64 = None
        add_tensor_199 = torch.ops.aten.add.Tensor(add_tensor_180, getitem_711);  add_tensor_180 = getitem_711 = None
        add_tensor_200 = torch.ops.aten.add.Tensor(add_tensor_181, getitem_712);  add_tensor_181 = getitem_712 = None
        convolution_backward_default_65 = torch.ops.aten.convolution_backward.default(getitem_710, silu__default_105, primals_522, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_710 = silu__default_105 = None
        getitem_713 = convolution_backward_default_65[0]
        getitem_714 = convolution_backward_default_65[1]
        getitem_715 = convolution_backward_default_65[2];  convolution_backward_default_65 = None
        add_tensor_201 = torch.ops.aten.add.Tensor(add_tensor_182, getitem_714);  add_tensor_182 = getitem_714 = None
        to_dtype_72 = torch.ops.aten.to.dtype(getitem_713, torch.float32);  getitem_713 = None
        to_dtype_73 = torch.ops.aten.to.dtype(clone_default_105, torch.float32);  clone_default_105 = None
        neg_default_24 = torch.ops.aten.neg.default(to_dtype_73)
        exp_default_24 = torch.ops.aten.exp.default(neg_default_24);  neg_default_24 = None
        add_tensor_202 = torch.ops.aten.add.Tensor(exp_default_24, 1);  exp_default_24 = None
        reciprocal_default_24 = torch.ops.aten.reciprocal.default(add_tensor_202);  add_tensor_202 = None
        mul_tensor_195 = torch.ops.aten.mul.Tensor(reciprocal_default_24, 1);  reciprocal_default_24 = None
        mul_tensor_196 = torch.ops.aten.mul.Tensor(to_dtype_72, mul_tensor_195);  to_dtype_72 = None
        rsub_scalar_24 = torch.ops.aten.rsub.Scalar(mul_tensor_195, 1);  mul_tensor_195 = None
        mul_tensor_197 = torch.ops.aten.mul.Tensor(to_dtype_73, rsub_scalar_24);  to_dtype_73 = rsub_scalar_24 = None
        add_tensor_203 = torch.ops.aten.add.Tensor(mul_tensor_197, 1);  mul_tensor_197 = None
        mul_tensor_198 = torch.ops.aten.mul.Tensor(mul_tensor_196, add_tensor_203);  mul_tensor_196 = add_tensor_203 = None
        to_dtype_74 = torch.ops.aten.to.dtype(mul_tensor_198, torch.float32);  mul_tensor_198 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_74, convolution_default_197, primals_899, primals_897, primals_898, new_zeros_default_333, new_zeros_default_334, False, 0.001, [True, True, True]);  to_dtype_74 = convolution_default_197 = primals_899 = primals_897 = primals_898 = new_zeros_default_333 = new_zeros_default_334 = None
        getitem_716 = native_batch_norm_backward_default_24[0]
        getitem_717 = native_batch_norm_backward_default_24[1]
        getitem_718 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_66 = torch.ops.aten.convolution_backward.default(getitem_716, convolution_default_196, primals_521, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_716 = convolution_default_196 = None
        getitem_719 = convolution_backward_default_66[0]
        getitem_720 = convolution_backward_default_66[1]
        getitem_721 = convolution_backward_default_66[2];  convolution_backward_default_66 = None
        add_tensor_204 = torch.ops.aten.add.Tensor(add_tensor_185, getitem_720);  add_tensor_185 = getitem_720 = None
        add_tensor_205 = torch.ops.aten.add.Tensor(add_tensor_186, getitem_721);  add_tensor_186 = getitem_721 = None
        convolution_backward_default_67 = torch.ops.aten.convolution_backward.default(getitem_719, silu__default_104, primals_519, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_719 = silu__default_104 = None
        getitem_722 = convolution_backward_default_67[0]
        getitem_723 = convolution_backward_default_67[1]
        getitem_724 = convolution_backward_default_67[2];  convolution_backward_default_67 = None
        add_tensor_206 = torch.ops.aten.add.Tensor(add_tensor_187, getitem_723);  add_tensor_187 = getitem_723 = None
        to_dtype_75 = torch.ops.aten.to.dtype(getitem_722, torch.float32);  getitem_722 = None
        to_dtype_76 = torch.ops.aten.to.dtype(clone_default_104, torch.float32);  clone_default_104 = None
        neg_default_25 = torch.ops.aten.neg.default(to_dtype_76)
        exp_default_25 = torch.ops.aten.exp.default(neg_default_25);  neg_default_25 = None
        add_tensor_207 = torch.ops.aten.add.Tensor(exp_default_25, 1);  exp_default_25 = None
        reciprocal_default_25 = torch.ops.aten.reciprocal.default(add_tensor_207);  add_tensor_207 = None
        mul_tensor_199 = torch.ops.aten.mul.Tensor(reciprocal_default_25, 1);  reciprocal_default_25 = None
        mul_tensor_200 = torch.ops.aten.mul.Tensor(to_dtype_75, mul_tensor_199);  to_dtype_75 = None
        rsub_scalar_25 = torch.ops.aten.rsub.Scalar(mul_tensor_199, 1);  mul_tensor_199 = None
        mul_tensor_201 = torch.ops.aten.mul.Tensor(to_dtype_76, rsub_scalar_25);  to_dtype_76 = rsub_scalar_25 = None
        add_tensor_208 = torch.ops.aten.add.Tensor(mul_tensor_201, 1);  mul_tensor_201 = None
        mul_tensor_202 = torch.ops.aten.mul.Tensor(mul_tensor_200, add_tensor_208);  mul_tensor_200 = add_tensor_208 = None
        to_dtype_77 = torch.ops.aten.to.dtype(mul_tensor_202, torch.float32);  mul_tensor_202 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_77, convolution_default_195, primals_894, primals_892, primals_893, new_zeros_default_330, new_zeros_default_331, False, 0.001, [True, True, True]);  to_dtype_77 = convolution_default_195 = primals_894 = primals_892 = primals_893 = new_zeros_default_330 = new_zeros_default_331 = None
        getitem_725 = native_batch_norm_backward_default_25[0]
        getitem_726 = native_batch_norm_backward_default_25[1]
        getitem_727 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        convolution_backward_default_68 = torch.ops.aten.convolution_backward.default(getitem_725, convolution_default_194, primals_518, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_725 = convolution_default_194 = None
        getitem_728 = convolution_backward_default_68[0]
        getitem_729 = convolution_backward_default_68[1]
        getitem_730 = convolution_backward_default_68[2];  convolution_backward_default_68 = None
        add_tensor_209 = torch.ops.aten.add.Tensor(add_tensor_190, getitem_729);  add_tensor_190 = getitem_729 = None
        add_tensor_210 = torch.ops.aten.add.Tensor(add_tensor_191, getitem_730);  add_tensor_191 = getitem_730 = None
        convolution_backward_default_69 = torch.ops.aten.convolution_backward.default(getitem_728, silu__default_103, primals_516, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_728 = silu__default_103 = None
        getitem_731 = convolution_backward_default_69[0]
        getitem_732 = convolution_backward_default_69[1]
        getitem_733 = convolution_backward_default_69[2];  convolution_backward_default_69 = None
        add_tensor_211 = torch.ops.aten.add.Tensor(add_tensor_192, getitem_732);  add_tensor_192 = getitem_732 = None
        to_dtype_78 = torch.ops.aten.to.dtype(getitem_731, torch.float32);  getitem_731 = None
        to_dtype_79 = torch.ops.aten.to.dtype(clone_default_103, torch.float32);  clone_default_103 = None
        neg_default_26 = torch.ops.aten.neg.default(to_dtype_79)
        exp_default_26 = torch.ops.aten.exp.default(neg_default_26);  neg_default_26 = None
        add_tensor_212 = torch.ops.aten.add.Tensor(exp_default_26, 1);  exp_default_26 = None
        reciprocal_default_26 = torch.ops.aten.reciprocal.default(add_tensor_212);  add_tensor_212 = None
        mul_tensor_203 = torch.ops.aten.mul.Tensor(reciprocal_default_26, 1);  reciprocal_default_26 = None
        mul_tensor_204 = torch.ops.aten.mul.Tensor(to_dtype_78, mul_tensor_203);  to_dtype_78 = None
        rsub_scalar_26 = torch.ops.aten.rsub.Scalar(mul_tensor_203, 1);  mul_tensor_203 = None
        mul_tensor_205 = torch.ops.aten.mul.Tensor(to_dtype_79, rsub_scalar_26);  to_dtype_79 = rsub_scalar_26 = None
        add_tensor_213 = torch.ops.aten.add.Tensor(mul_tensor_205, 1);  mul_tensor_205 = None
        mul_tensor_206 = torch.ops.aten.mul.Tensor(mul_tensor_204, add_tensor_213);  mul_tensor_204 = add_tensor_213 = None
        to_dtype_80 = torch.ops.aten.to.dtype(mul_tensor_206, torch.float32);  mul_tensor_206 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_80, convolution_default_193, primals_889, primals_887, primals_888, new_zeros_default_327, new_zeros_default_328, False, 0.001, [True, True, True]);  to_dtype_80 = convolution_default_193 = primals_889 = primals_887 = primals_888 = new_zeros_default_327 = new_zeros_default_328 = None
        getitem_734 = native_batch_norm_backward_default_26[0]
        getitem_735 = native_batch_norm_backward_default_26[1]
        getitem_736 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_70 = torch.ops.aten.convolution_backward.default(getitem_734, convolution_default_192, primals_515, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_734 = convolution_default_192 = None
        getitem_737 = convolution_backward_default_70[0]
        getitem_738 = convolution_backward_default_70[1]
        getitem_739 = convolution_backward_default_70[2];  convolution_backward_default_70 = None
        add_tensor_214 = torch.ops.aten.add.Tensor(add_tensor_195, getitem_738);  add_tensor_195 = getitem_738 = None
        add_tensor_215 = torch.ops.aten.add.Tensor(add_tensor_196, getitem_739);  add_tensor_196 = getitem_739 = None
        convolution_backward_default_71 = torch.ops.aten.convolution_backward.default(getitem_737, getitem_336, primals_513, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_737 = getitem_336 = None
        getitem_740 = convolution_backward_default_71[0]
        getitem_741 = convolution_backward_default_71[1]
        getitem_742 = convolution_backward_default_71[2];  convolution_backward_default_71 = None
        add_tensor_216 = torch.ops.aten.add.Tensor(getitem_575, getitem_740);  getitem_575 = getitem_740 = None
        add_tensor_217 = torch.ops.aten.add.Tensor(add_tensor_198, getitem_741);  add_tensor_198 = getitem_741 = None
        convolution_backward_default_72 = torch.ops.aten.convolution_backward.default(permute_default_19, convolution_default_190, primals_524, [810], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  permute_default_19 = convolution_default_190 = primals_524 = None
        getitem_743 = convolution_backward_default_72[0]
        getitem_744 = convolution_backward_default_72[1]
        getitem_745 = convolution_backward_default_72[2];  convolution_backward_default_72 = None
        add_tensor_218 = torch.ops.aten.add.Tensor(add_tensor_199, getitem_744);  add_tensor_199 = getitem_744 = None
        add_tensor_219 = torch.ops.aten.add.Tensor(add_tensor_200, getitem_745);  add_tensor_200 = getitem_745 = None
        convolution_backward_default_73 = torch.ops.aten.convolution_backward.default(getitem_743, silu__default_102, primals_522, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_743 = silu__default_102 = primals_522 = None
        getitem_746 = convolution_backward_default_73[0]
        getitem_747 = convolution_backward_default_73[1]
        getitem_748 = convolution_backward_default_73[2];  convolution_backward_default_73 = None
        add_tensor_220 = torch.ops.aten.add.Tensor(add_tensor_201, getitem_747);  add_tensor_201 = getitem_747 = None
        to_dtype_81 = torch.ops.aten.to.dtype(getitem_746, torch.float32);  getitem_746 = None
        to_dtype_82 = torch.ops.aten.to.dtype(clone_default_102, torch.float32);  clone_default_102 = None
        neg_default_27 = torch.ops.aten.neg.default(to_dtype_82)
        exp_default_27 = torch.ops.aten.exp.default(neg_default_27);  neg_default_27 = None
        add_tensor_221 = torch.ops.aten.add.Tensor(exp_default_27, 1);  exp_default_27 = None
        reciprocal_default_27 = torch.ops.aten.reciprocal.default(add_tensor_221);  add_tensor_221 = None
        mul_tensor_207 = torch.ops.aten.mul.Tensor(reciprocal_default_27, 1);  reciprocal_default_27 = None
        mul_tensor_208 = torch.ops.aten.mul.Tensor(to_dtype_81, mul_tensor_207);  to_dtype_81 = None
        rsub_scalar_27 = torch.ops.aten.rsub.Scalar(mul_tensor_207, 1);  mul_tensor_207 = None
        mul_tensor_209 = torch.ops.aten.mul.Tensor(to_dtype_82, rsub_scalar_27);  to_dtype_82 = rsub_scalar_27 = None
        add_tensor_222 = torch.ops.aten.add.Tensor(mul_tensor_209, 1);  mul_tensor_209 = None
        mul_tensor_210 = torch.ops.aten.mul.Tensor(mul_tensor_208, add_tensor_222);  mul_tensor_208 = add_tensor_222 = None
        to_dtype_83 = torch.ops.aten.to.dtype(mul_tensor_210, torch.float32);  mul_tensor_210 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_83, convolution_default_189, primals_869, primals_867, primals_868, new_zeros_default_324, new_zeros_default_325, False, 0.001, [True, True, True]);  to_dtype_83 = convolution_default_189 = primals_869 = primals_867 = primals_868 = new_zeros_default_324 = new_zeros_default_325 = None
        getitem_749 = native_batch_norm_backward_default_27[0]
        getitem_750 = native_batch_norm_backward_default_27[1]
        getitem_751 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        convolution_backward_default_74 = torch.ops.aten.convolution_backward.default(getitem_749, convolution_default_188, primals_521, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_749 = convolution_default_188 = primals_521 = None
        getitem_752 = convolution_backward_default_74[0]
        getitem_753 = convolution_backward_default_74[1]
        getitem_754 = convolution_backward_default_74[2];  convolution_backward_default_74 = None
        add_tensor_223 = torch.ops.aten.add.Tensor(add_tensor_204, getitem_753);  add_tensor_204 = getitem_753 = None
        add_tensor_224 = torch.ops.aten.add.Tensor(add_tensor_205, getitem_754);  add_tensor_205 = getitem_754 = None
        convolution_backward_default_75 = torch.ops.aten.convolution_backward.default(getitem_752, silu__default_101, primals_519, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_752 = silu__default_101 = primals_519 = None
        getitem_755 = convolution_backward_default_75[0]
        getitem_756 = convolution_backward_default_75[1]
        getitem_757 = convolution_backward_default_75[2];  convolution_backward_default_75 = None
        add_tensor_225 = torch.ops.aten.add.Tensor(add_tensor_206, getitem_756);  add_tensor_206 = getitem_756 = None
        to_dtype_84 = torch.ops.aten.to.dtype(getitem_755, torch.float32);  getitem_755 = None
        to_dtype_85 = torch.ops.aten.to.dtype(clone_default_101, torch.float32);  clone_default_101 = None
        neg_default_28 = torch.ops.aten.neg.default(to_dtype_85)
        exp_default_28 = torch.ops.aten.exp.default(neg_default_28);  neg_default_28 = None
        add_tensor_226 = torch.ops.aten.add.Tensor(exp_default_28, 1);  exp_default_28 = None
        reciprocal_default_28 = torch.ops.aten.reciprocal.default(add_tensor_226);  add_tensor_226 = None
        mul_tensor_211 = torch.ops.aten.mul.Tensor(reciprocal_default_28, 1);  reciprocal_default_28 = None
        mul_tensor_212 = torch.ops.aten.mul.Tensor(to_dtype_84, mul_tensor_211);  to_dtype_84 = None
        rsub_scalar_28 = torch.ops.aten.rsub.Scalar(mul_tensor_211, 1);  mul_tensor_211 = None
        mul_tensor_213 = torch.ops.aten.mul.Tensor(to_dtype_85, rsub_scalar_28);  to_dtype_85 = rsub_scalar_28 = None
        add_tensor_227 = torch.ops.aten.add.Tensor(mul_tensor_213, 1);  mul_tensor_213 = None
        mul_tensor_214 = torch.ops.aten.mul.Tensor(mul_tensor_212, add_tensor_227);  mul_tensor_212 = add_tensor_227 = None
        to_dtype_86 = torch.ops.aten.to.dtype(mul_tensor_214, torch.float32);  mul_tensor_214 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_86, convolution_default_187, primals_864, primals_862, primals_863, new_zeros_default_321, new_zeros_default_322, False, 0.001, [True, True, True]);  to_dtype_86 = convolution_default_187 = primals_864 = primals_862 = primals_863 = new_zeros_default_321 = new_zeros_default_322 = None
        getitem_758 = native_batch_norm_backward_default_28[0]
        getitem_759 = native_batch_norm_backward_default_28[1]
        getitem_760 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        convolution_backward_default_76 = torch.ops.aten.convolution_backward.default(getitem_758, convolution_default_186, primals_518, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_758 = convolution_default_186 = primals_518 = None
        getitem_761 = convolution_backward_default_76[0]
        getitem_762 = convolution_backward_default_76[1]
        getitem_763 = convolution_backward_default_76[2];  convolution_backward_default_76 = None
        add_tensor_228 = torch.ops.aten.add.Tensor(add_tensor_209, getitem_762);  add_tensor_209 = getitem_762 = None
        add_tensor_229 = torch.ops.aten.add.Tensor(add_tensor_210, getitem_763);  add_tensor_210 = getitem_763 = None
        convolution_backward_default_77 = torch.ops.aten.convolution_backward.default(getitem_761, silu__default_100, primals_516, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_761 = silu__default_100 = primals_516 = None
        getitem_764 = convolution_backward_default_77[0]
        getitem_765 = convolution_backward_default_77[1]
        getitem_766 = convolution_backward_default_77[2];  convolution_backward_default_77 = None
        add_tensor_230 = torch.ops.aten.add.Tensor(add_tensor_211, getitem_765);  add_tensor_211 = getitem_765 = None
        to_dtype_87 = torch.ops.aten.to.dtype(getitem_764, torch.float32);  getitem_764 = None
        to_dtype_88 = torch.ops.aten.to.dtype(clone_default_100, torch.float32);  clone_default_100 = None
        neg_default_29 = torch.ops.aten.neg.default(to_dtype_88)
        exp_default_29 = torch.ops.aten.exp.default(neg_default_29);  neg_default_29 = None
        add_tensor_231 = torch.ops.aten.add.Tensor(exp_default_29, 1);  exp_default_29 = None
        reciprocal_default_29 = torch.ops.aten.reciprocal.default(add_tensor_231);  add_tensor_231 = None
        mul_tensor_215 = torch.ops.aten.mul.Tensor(reciprocal_default_29, 1);  reciprocal_default_29 = None
        mul_tensor_216 = torch.ops.aten.mul.Tensor(to_dtype_87, mul_tensor_215);  to_dtype_87 = None
        rsub_scalar_29 = torch.ops.aten.rsub.Scalar(mul_tensor_215, 1);  mul_tensor_215 = None
        mul_tensor_217 = torch.ops.aten.mul.Tensor(to_dtype_88, rsub_scalar_29);  to_dtype_88 = rsub_scalar_29 = None
        add_tensor_232 = torch.ops.aten.add.Tensor(mul_tensor_217, 1);  mul_tensor_217 = None
        mul_tensor_218 = torch.ops.aten.mul.Tensor(mul_tensor_216, add_tensor_232);  mul_tensor_216 = add_tensor_232 = None
        to_dtype_89 = torch.ops.aten.to.dtype(mul_tensor_218, torch.float32);  mul_tensor_218 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_89, convolution_default_185, primals_859, primals_857, primals_858, new_zeros_default_318, new_zeros_default_319, False, 0.001, [True, True, True]);  to_dtype_89 = convolution_default_185 = primals_859 = primals_857 = primals_858 = new_zeros_default_318 = new_zeros_default_319 = None
        getitem_767 = native_batch_norm_backward_default_29[0]
        getitem_768 = native_batch_norm_backward_default_29[1]
        getitem_769 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        convolution_backward_default_78 = torch.ops.aten.convolution_backward.default(getitem_767, convolution_default_184, primals_515, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_767 = convolution_default_184 = primals_515 = None
        getitem_770 = convolution_backward_default_78[0]
        getitem_771 = convolution_backward_default_78[1]
        getitem_772 = convolution_backward_default_78[2];  convolution_backward_default_78 = None
        add_tensor_233 = torch.ops.aten.add.Tensor(add_tensor_214, getitem_771);  add_tensor_214 = getitem_771 = None
        add_tensor_234 = torch.ops.aten.add.Tensor(add_tensor_215, getitem_772);  add_tensor_215 = getitem_772 = None
        convolution_backward_default_79 = torch.ops.aten.convolution_backward.default(getitem_770, getitem_331, primals_513, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_770 = getitem_331 = primals_513 = None
        getitem_773 = convolution_backward_default_79[0]
        getitem_774 = convolution_backward_default_79[1]
        getitem_775 = convolution_backward_default_79[2];  convolution_backward_default_79 = None
        add_tensor_235 = torch.ops.aten.add.Tensor(getitem_608, getitem_773);  getitem_608 = getitem_773 = None
        add_tensor_236 = torch.ops.aten.add.Tensor(add_tensor_217, getitem_774);  add_tensor_217 = getitem_774 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_160, convolution_default_183, primals_843, primals_841, primals_842, new_zeros_default_315, new_zeros_default_316, False, 0.001, [True, True, True]);  add_tensor_160 = convolution_default_183 = primals_843 = primals_841 = primals_842 = new_zeros_default_315 = new_zeros_default_316 = None
        getitem_776 = native_batch_norm_backward_default_30[0]
        getitem_777 = native_batch_norm_backward_default_30[1]
        getitem_778 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_80 = torch.ops.aten.convolution_backward.default(getitem_776, convolution_default_182, primals_846, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_776 = convolution_default_182 = primals_846 = None
        getitem_779 = convolution_backward_default_80[0]
        getitem_780 = convolution_backward_default_80[1]
        getitem_781 = convolution_backward_default_80[2];  convolution_backward_default_80 = None
        convolution_backward_default_81 = torch.ops.aten.convolution_backward.default(getitem_779, silu__default_99, primals_844, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_779 = silu__default_99 = primals_844 = None
        getitem_782 = convolution_backward_default_81[0]
        getitem_783 = convolution_backward_default_81[1]
        getitem_784 = convolution_backward_default_81[2];  convolution_backward_default_81 = None
        to_dtype_90 = torch.ops.aten.to.dtype(getitem_782, torch.float32);  getitem_782 = None
        to_dtype_91 = torch.ops.aten.to.dtype(clone_default_99, torch.float32);  clone_default_99 = None
        neg_default_30 = torch.ops.aten.neg.default(to_dtype_91)
        exp_default_30 = torch.ops.aten.exp.default(neg_default_30);  neg_default_30 = None
        add_tensor_237 = torch.ops.aten.add.Tensor(exp_default_30, 1);  exp_default_30 = None
        reciprocal_default_30 = torch.ops.aten.reciprocal.default(add_tensor_237);  add_tensor_237 = None
        mul_tensor_219 = torch.ops.aten.mul.Tensor(reciprocal_default_30, 1);  reciprocal_default_30 = None
        mul_tensor_220 = torch.ops.aten.mul.Tensor(to_dtype_90, mul_tensor_219);  to_dtype_90 = None
        rsub_scalar_30 = torch.ops.aten.rsub.Scalar(mul_tensor_219, 1);  mul_tensor_219 = None
        mul_tensor_221 = torch.ops.aten.mul.Tensor(to_dtype_91, rsub_scalar_30);  to_dtype_91 = rsub_scalar_30 = None
        add_tensor_238 = torch.ops.aten.add.Tensor(mul_tensor_221, 1);  mul_tensor_221 = None
        mul_tensor_222 = torch.ops.aten.mul.Tensor(mul_tensor_220, add_tensor_238);  mul_tensor_220 = add_tensor_238 = None
        to_dtype_92 = torch.ops.aten.to.dtype(mul_tensor_222, torch.float32);  mul_tensor_222 = None
        unsqueeze_default_3 = torch.ops.aten.unsqueeze.default(to_dtype_92, 4);  to_dtype_92 = None
        expand_default = torch.ops.aten.expand.default(unsqueeze_default_3, [1, 88, 5, 5, 2]);  unsqueeze_default_3 = None
        unbind_int = torch.ops.aten.unbind.int(expand_default, -1);  expand_default = None
        getitem_785 = unbind_int[0]
        getitem_786 = unbind_int[1];  unbind_int = None
        neg_default_31 = torch.ops.aten.neg.default(getitem_786)
        div_tensor_76 = torch.ops.aten.div.Tensor(mul_tensor_98, add_tensor_75);  mul_tensor_98 = None
        div_tensor_77 = torch.ops.aten.div.Tensor(div_tensor_76, add_tensor_75);  div_tensor_76 = None
        mul_tensor_223 = torch.ops.aten.mul.Tensor(neg_default_31, div_tensor_77);  neg_default_31 = div_tensor_77 = None
        div_tensor_78 = torch.ops.aten.div.Tensor(getitem_786, add_tensor_75);  getitem_786 = add_tensor_75 = None
        sum_default_32 = torch.ops.aten.sum.default(mul_tensor_223);  mul_tensor_223 = None
        mul_tensor_224 = torch.ops.aten.mul.Tensor(div_tensor_78, getitem_349);  getitem_349 = None
        mul_tensor_225 = torch.ops.aten.mul.Tensor(div_tensor_78, select_int_75);  div_tensor_78 = select_int_75 = None
        sum_default_33 = torch.ops.aten.sum.default(mul_tensor_224);  mul_tensor_224 = None
        select_backward_default = torch.ops.aten.select_backward.default(sum_default_33, [2], 0, 1);  sum_default_33 = None
        neg_default_32 = torch.ops.aten.neg.default(getitem_785)
        div_tensor_79 = torch.ops.aten.div.Tensor(mul_tensor_97, add_tensor_74);  mul_tensor_97 = None
        div_tensor_80 = torch.ops.aten.div.Tensor(div_tensor_79, add_tensor_74);  div_tensor_79 = None
        mul_tensor_226 = torch.ops.aten.mul.Tensor(neg_default_32, div_tensor_80);  neg_default_32 = div_tensor_80 = None
        div_tensor_81 = torch.ops.aten.div.Tensor(getitem_785, add_tensor_74);  getitem_785 = add_tensor_74 = None
        sum_default_34 = torch.ops.aten.sum.default(mul_tensor_226);  mul_tensor_226 = None
        add_tensor_239 = torch.ops.aten.add.Tensor(sum_default_32, sum_default_34);  sum_default_32 = sum_default_34 = None
        mul_tensor_227 = torch.ops.aten.mul.Tensor(div_tensor_81, getitem_319);  getitem_319 = None
        mul_tensor_228 = torch.ops.aten.mul.Tensor(div_tensor_81, select_int_74);  div_tensor_81 = select_int_74 = None
        sum_default_35 = torch.ops.aten.sum.default(mul_tensor_227);  mul_tensor_227 = None
        select_backward_default_1 = torch.ops.aten.select_backward.default(sum_default_35, [2], 0, 0);  sum_default_35 = None
        add_tensor_240 = torch.ops.aten.add.Tensor(select_backward_default, select_backward_default_1);  select_backward_default = select_backward_default_1 = None
        expand_default_1 = torch.ops.aten.expand.default(add_tensor_239, [2]);  add_tensor_239 = None
        add_tensor_241 = torch.ops.aten.add.Tensor(add_tensor_240, expand_default_1);  add_tensor_240 = expand_default_1 = None
        to_dtype_93 = torch.ops.aten.to.dtype(add_tensor_241, torch.float32);  add_tensor_241 = None
        to_dtype_94 = torch.ops.aten.to.dtype(relu_default_31, torch.float32);  relu_default_31 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_94, 0);  to_dtype_94 = None
        new_zeros_default_408 = torch.ops.aten.new_zeros.default(to_dtype_93, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_408, to_dtype_93);  le_scalar = new_zeros_default_408 = to_dtype_93 = None
        to_dtype_95 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        max_pool2d_with_indices_backward_default = torch.ops.aten.max_pool2d_with_indices_backward.default(mul_tensor_225, constant_pad_nd_default_22, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_350);  mul_tensor_225 = constant_pad_nd_default_22 = getitem_350 = None
        constant_pad_nd_default_23 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default, [0, -1, 0, -1]);  max_pool2d_with_indices_backward_default = None
        add_tensor_242 = torch.ops.aten.add.Tensor(add_tensor_178, constant_pad_nd_default_23);  add_tensor_178 = constant_pad_nd_default_23 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_242, convolution_default_181, primals_834, primals_832, primals_833, new_zeros_default_312, new_zeros_default_313, False, 0.001, [True, True, True]);  add_tensor_242 = convolution_default_181 = primals_834 = primals_832 = primals_833 = new_zeros_default_312 = new_zeros_default_313 = None
        getitem_787 = native_batch_norm_backward_default_31[0]
        getitem_788 = native_batch_norm_backward_default_31[1]
        getitem_789 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        convolution_backward_default_82 = torch.ops.aten.convolution_backward.default(getitem_787, convolution_default_180, primals_837, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_787 = convolution_default_180 = primals_837 = None
        getitem_790 = convolution_backward_default_82[0]
        getitem_791 = convolution_backward_default_82[1]
        getitem_792 = convolution_backward_default_82[2];  convolution_backward_default_82 = None
        convolution_backward_default_83 = torch.ops.aten.convolution_backward.default(getitem_790, silu__default_98, primals_835, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_790 = silu__default_98 = primals_835 = None
        getitem_793 = convolution_backward_default_83[0]
        getitem_794 = convolution_backward_default_83[1]
        getitem_795 = convolution_backward_default_83[2];  convolution_backward_default_83 = None
        to_dtype_96 = torch.ops.aten.to.dtype(getitem_793, torch.float32);  getitem_793 = None
        to_dtype_97 = torch.ops.aten.to.dtype(clone_default_98, torch.float32);  clone_default_98 = None
        neg_default_33 = torch.ops.aten.neg.default(to_dtype_97)
        exp_default_31 = torch.ops.aten.exp.default(neg_default_33);  neg_default_33 = None
        add_tensor_243 = torch.ops.aten.add.Tensor(exp_default_31, 1);  exp_default_31 = None
        reciprocal_default_31 = torch.ops.aten.reciprocal.default(add_tensor_243);  add_tensor_243 = None
        mul_tensor_229 = torch.ops.aten.mul.Tensor(reciprocal_default_31, 1);  reciprocal_default_31 = None
        mul_tensor_230 = torch.ops.aten.mul.Tensor(to_dtype_96, mul_tensor_229);  to_dtype_96 = None
        rsub_scalar_31 = torch.ops.aten.rsub.Scalar(mul_tensor_229, 1);  mul_tensor_229 = None
        mul_tensor_231 = torch.ops.aten.mul.Tensor(to_dtype_97, rsub_scalar_31);  to_dtype_97 = rsub_scalar_31 = None
        add_tensor_244 = torch.ops.aten.add.Tensor(mul_tensor_231, 1);  mul_tensor_231 = None
        mul_tensor_232 = torch.ops.aten.mul.Tensor(mul_tensor_230, add_tensor_244);  mul_tensor_230 = add_tensor_244 = None
        to_dtype_98 = torch.ops.aten.to.dtype(mul_tensor_232, torch.float32);  mul_tensor_232 = None
        unsqueeze_default_4 = torch.ops.aten.unsqueeze.default(to_dtype_98, 4);  to_dtype_98 = None
        expand_default_2 = torch.ops.aten.expand.default(unsqueeze_default_4, [1, 88, 10, 10, 3]);  unsqueeze_default_4 = None
        unbind_int_1 = torch.ops.aten.unbind.int(expand_default_2, -1);  expand_default_2 = None
        getitem_796 = unbind_int_1[0]
        getitem_797 = unbind_int_1[1]
        getitem_798 = unbind_int_1[2];  unbind_int_1 = None
        neg_default_34 = torch.ops.aten.neg.default(getitem_798)
        div_tensor_82 = torch.ops.aten.div.Tensor(mul_tensor_96, add_tensor_73);  mul_tensor_96 = None
        div_tensor_83 = torch.ops.aten.div.Tensor(div_tensor_82, add_tensor_73);  div_tensor_82 = None
        mul_tensor_233 = torch.ops.aten.mul.Tensor(neg_default_34, div_tensor_83);  neg_default_34 = div_tensor_83 = None
        div_tensor_84 = torch.ops.aten.div.Tensor(getitem_798, add_tensor_73);  getitem_798 = add_tensor_73 = None
        sum_default_36 = torch.ops.aten.sum.default(mul_tensor_233);  mul_tensor_233 = None
        mul_tensor_234 = torch.ops.aten.mul.Tensor(div_tensor_84, getitem_344);  getitem_344 = None
        mul_tensor_235 = torch.ops.aten.mul.Tensor(div_tensor_84, select_int_73);  div_tensor_84 = select_int_73 = None
        sum_default_37 = torch.ops.aten.sum.default(mul_tensor_234);  mul_tensor_234 = None
        select_backward_default_2 = torch.ops.aten.select_backward.default(sum_default_37, [3], 0, 2);  sum_default_37 = None
        neg_default_35 = torch.ops.aten.neg.default(getitem_797)
        div_tensor_85 = torch.ops.aten.div.Tensor(mul_tensor_95, add_tensor_72);  mul_tensor_95 = None
        div_tensor_86 = torch.ops.aten.div.Tensor(div_tensor_85, add_tensor_72);  div_tensor_85 = None
        mul_tensor_236 = torch.ops.aten.mul.Tensor(neg_default_35, div_tensor_86);  neg_default_35 = div_tensor_86 = None
        div_tensor_87 = torch.ops.aten.div.Tensor(getitem_797, add_tensor_72);  getitem_797 = add_tensor_72 = None
        sum_default_38 = torch.ops.aten.sum.default(mul_tensor_236);  mul_tensor_236 = None
        add_tensor_245 = torch.ops.aten.add.Tensor(sum_default_36, sum_default_38);  sum_default_36 = sum_default_38 = None
        mul_tensor_237 = torch.ops.aten.mul.Tensor(div_tensor_87, getitem_322);  getitem_322 = None
        mul_tensor_238 = torch.ops.aten.mul.Tensor(div_tensor_87, select_int_72);  div_tensor_87 = select_int_72 = None
        sum_default_39 = torch.ops.aten.sum.default(mul_tensor_237);  mul_tensor_237 = None
        select_backward_default_3 = torch.ops.aten.select_backward.default(sum_default_39, [3], 0, 1);  sum_default_39 = None
        add_tensor_246 = torch.ops.aten.add.Tensor(select_backward_default_2, select_backward_default_3);  select_backward_default_2 = select_backward_default_3 = None
        neg_default_36 = torch.ops.aten.neg.default(getitem_796)
        div_tensor_88 = torch.ops.aten.div.Tensor(mul_tensor_94, add_tensor_71);  mul_tensor_94 = None
        div_tensor_89 = torch.ops.aten.div.Tensor(div_tensor_88, add_tensor_71);  div_tensor_88 = None
        mul_tensor_239 = torch.ops.aten.mul.Tensor(neg_default_36, div_tensor_89);  neg_default_36 = div_tensor_89 = None
        div_tensor_90 = torch.ops.aten.div.Tensor(getitem_796, add_tensor_71);  getitem_796 = add_tensor_71 = None
        sum_default_40 = torch.ops.aten.sum.default(mul_tensor_239);  mul_tensor_239 = None
        add_tensor_247 = torch.ops.aten.add.Tensor(add_tensor_245, sum_default_40);  add_tensor_245 = sum_default_40 = None
        mul_tensor_240 = torch.ops.aten.mul.Tensor(div_tensor_90, getitem_314)
        mul_tensor_241 = torch.ops.aten.mul.Tensor(div_tensor_90, select_int_71);  div_tensor_90 = select_int_71 = None
        sum_default_41 = torch.ops.aten.sum.default(mul_tensor_240);  mul_tensor_240 = None
        select_backward_default_4 = torch.ops.aten.select_backward.default(sum_default_41, [3], 0, 0);  sum_default_41 = None
        add_tensor_248 = torch.ops.aten.add.Tensor(add_tensor_246, select_backward_default_4);  add_tensor_246 = select_backward_default_4 = None
        expand_default_3 = torch.ops.aten.expand.default(add_tensor_247, [3]);  add_tensor_247 = None
        add_tensor_249 = torch.ops.aten.add.Tensor(add_tensor_248, expand_default_3);  add_tensor_248 = expand_default_3 = None
        to_dtype_99 = torch.ops.aten.to.dtype(add_tensor_249, torch.float32);  add_tensor_249 = None
        to_dtype_100 = torch.ops.aten.to.dtype(relu_default_30, torch.float32);  relu_default_30 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_100, 0);  to_dtype_100 = None
        new_zeros_default_409 = torch.ops.aten.new_zeros.default(to_dtype_99, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_409, to_dtype_99);  le_scalar_1 = new_zeros_default_409 = to_dtype_99 = None
        to_dtype_101 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        max_pool2d_with_indices_backward_default_1 = torch.ops.aten.max_pool2d_with_indices_backward.default(mul_tensor_235, constant_pad_nd_default_21, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_345);  mul_tensor_235 = constant_pad_nd_default_21 = getitem_345 = None
        constant_pad_nd_default_24 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default_1, [0, -1, 0, -1]);  max_pool2d_with_indices_backward_default_1 = None
        add_tensor_250 = torch.ops.aten.add.Tensor(add_tensor_197, constant_pad_nd_default_24);  add_tensor_197 = constant_pad_nd_default_24 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_250, convolution_default_179, primals_825, primals_823, primals_824, new_zeros_default_309, new_zeros_default_310, False, 0.001, [True, True, True]);  add_tensor_250 = convolution_default_179 = primals_825 = primals_823 = primals_824 = new_zeros_default_309 = new_zeros_default_310 = None
        getitem_799 = native_batch_norm_backward_default_32[0]
        getitem_800 = native_batch_norm_backward_default_32[1]
        getitem_801 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        convolution_backward_default_84 = torch.ops.aten.convolution_backward.default(getitem_799, convolution_default_178, primals_828, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_799 = convolution_default_178 = primals_828 = None
        getitem_802 = convolution_backward_default_84[0]
        getitem_803 = convolution_backward_default_84[1]
        getitem_804 = convolution_backward_default_84[2];  convolution_backward_default_84 = None
        convolution_backward_default_85 = torch.ops.aten.convolution_backward.default(getitem_802, silu__default_97, primals_826, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_802 = silu__default_97 = primals_826 = None
        getitem_805 = convolution_backward_default_85[0]
        getitem_806 = convolution_backward_default_85[1]
        getitem_807 = convolution_backward_default_85[2];  convolution_backward_default_85 = None
        to_dtype_102 = torch.ops.aten.to.dtype(getitem_805, torch.float32);  getitem_805 = None
        to_dtype_103 = torch.ops.aten.to.dtype(clone_default_97, torch.float32);  clone_default_97 = None
        neg_default_37 = torch.ops.aten.neg.default(to_dtype_103)
        exp_default_32 = torch.ops.aten.exp.default(neg_default_37);  neg_default_37 = None
        add_tensor_251 = torch.ops.aten.add.Tensor(exp_default_32, 1);  exp_default_32 = None
        reciprocal_default_32 = torch.ops.aten.reciprocal.default(add_tensor_251);  add_tensor_251 = None
        mul_tensor_242 = torch.ops.aten.mul.Tensor(reciprocal_default_32, 1);  reciprocal_default_32 = None
        mul_tensor_243 = torch.ops.aten.mul.Tensor(to_dtype_102, mul_tensor_242);  to_dtype_102 = None
        rsub_scalar_32 = torch.ops.aten.rsub.Scalar(mul_tensor_242, 1);  mul_tensor_242 = None
        mul_tensor_244 = torch.ops.aten.mul.Tensor(to_dtype_103, rsub_scalar_32);  to_dtype_103 = rsub_scalar_32 = None
        add_tensor_252 = torch.ops.aten.add.Tensor(mul_tensor_244, 1);  mul_tensor_244 = None
        mul_tensor_245 = torch.ops.aten.mul.Tensor(mul_tensor_243, add_tensor_252);  mul_tensor_243 = add_tensor_252 = None
        to_dtype_104 = torch.ops.aten.to.dtype(mul_tensor_245, torch.float32);  mul_tensor_245 = None
        unsqueeze_default_5 = torch.ops.aten.unsqueeze.default(to_dtype_104, 4);  to_dtype_104 = None
        expand_default_4 = torch.ops.aten.expand.default(unsqueeze_default_5, [1, 88, 20, 20, 3]);  unsqueeze_default_5 = None
        unbind_int_2 = torch.ops.aten.unbind.int(expand_default_4, -1);  expand_default_4 = None
        getitem_808 = unbind_int_2[0]
        getitem_809 = unbind_int_2[1]
        getitem_810 = unbind_int_2[2];  unbind_int_2 = None
        neg_default_38 = torch.ops.aten.neg.default(getitem_810)
        div_tensor_91 = torch.ops.aten.div.Tensor(mul_tensor_93, add_tensor_70);  mul_tensor_93 = None
        div_tensor_92 = torch.ops.aten.div.Tensor(div_tensor_91, add_tensor_70);  div_tensor_91 = None
        mul_tensor_246 = torch.ops.aten.mul.Tensor(neg_default_38, div_tensor_92);  neg_default_38 = div_tensor_92 = None
        div_tensor_93 = torch.ops.aten.div.Tensor(getitem_810, add_tensor_70);  getitem_810 = add_tensor_70 = None
        sum_default_42 = torch.ops.aten.sum.default(mul_tensor_246);  mul_tensor_246 = None
        mul_tensor_247 = torch.ops.aten.mul.Tensor(div_tensor_93, getitem_339);  getitem_339 = None
        mul_tensor_248 = torch.ops.aten.mul.Tensor(div_tensor_93, select_int_70);  div_tensor_93 = select_int_70 = None
        sum_default_43 = torch.ops.aten.sum.default(mul_tensor_247);  mul_tensor_247 = None
        select_backward_default_5 = torch.ops.aten.select_backward.default(sum_default_43, [3], 0, 2);  sum_default_43 = None
        neg_default_39 = torch.ops.aten.neg.default(getitem_809)
        div_tensor_94 = torch.ops.aten.div.Tensor(mul_tensor_92, add_tensor_69);  mul_tensor_92 = None
        div_tensor_95 = torch.ops.aten.div.Tensor(div_tensor_94, add_tensor_69);  div_tensor_94 = None
        mul_tensor_249 = torch.ops.aten.mul.Tensor(neg_default_39, div_tensor_95);  neg_default_39 = div_tensor_95 = None
        div_tensor_96 = torch.ops.aten.div.Tensor(getitem_809, add_tensor_69);  getitem_809 = add_tensor_69 = None
        sum_default_44 = torch.ops.aten.sum.default(mul_tensor_249);  mul_tensor_249 = None
        add_tensor_253 = torch.ops.aten.add.Tensor(sum_default_42, sum_default_44);  sum_default_42 = sum_default_44 = None
        mul_tensor_250 = torch.ops.aten.mul.Tensor(div_tensor_96, getitem_325);  getitem_325 = None
        mul_tensor_251 = torch.ops.aten.mul.Tensor(div_tensor_96, select_int_69);  div_tensor_96 = select_int_69 = None
        sum_default_45 = torch.ops.aten.sum.default(mul_tensor_250);  mul_tensor_250 = None
        select_backward_default_6 = torch.ops.aten.select_backward.default(sum_default_45, [3], 0, 1);  sum_default_45 = None
        add_tensor_254 = torch.ops.aten.add.Tensor(select_backward_default_5, select_backward_default_6);  select_backward_default_5 = select_backward_default_6 = None
        neg_default_40 = torch.ops.aten.neg.default(getitem_808)
        div_tensor_97 = torch.ops.aten.div.Tensor(mul_tensor_91, add_tensor_68);  mul_tensor_91 = None
        div_tensor_98 = torch.ops.aten.div.Tensor(div_tensor_97, add_tensor_68);  div_tensor_97 = None
        mul_tensor_252 = torch.ops.aten.mul.Tensor(neg_default_40, div_tensor_98);  neg_default_40 = div_tensor_98 = None
        div_tensor_99 = torch.ops.aten.div.Tensor(getitem_808, add_tensor_68);  getitem_808 = add_tensor_68 = None
        sum_default_46 = torch.ops.aten.sum.default(mul_tensor_252);  mul_tensor_252 = None
        add_tensor_255 = torch.ops.aten.add.Tensor(add_tensor_253, sum_default_46);  add_tensor_253 = sum_default_46 = None
        mul_tensor_253 = torch.ops.aten.mul.Tensor(div_tensor_99, getitem_309)
        mul_tensor_254 = torch.ops.aten.mul.Tensor(div_tensor_99, select_int_68);  div_tensor_99 = select_int_68 = None
        sum_default_47 = torch.ops.aten.sum.default(mul_tensor_253);  mul_tensor_253 = None
        select_backward_default_7 = torch.ops.aten.select_backward.default(sum_default_47, [3], 0, 0);  sum_default_47 = None
        add_tensor_256 = torch.ops.aten.add.Tensor(add_tensor_254, select_backward_default_7);  add_tensor_254 = select_backward_default_7 = None
        expand_default_5 = torch.ops.aten.expand.default(add_tensor_255, [3]);  add_tensor_255 = None
        add_tensor_257 = torch.ops.aten.add.Tensor(add_tensor_256, expand_default_5);  add_tensor_256 = expand_default_5 = None
        to_dtype_105 = torch.ops.aten.to.dtype(add_tensor_257, torch.float32);  add_tensor_257 = None
        to_dtype_106 = torch.ops.aten.to.dtype(relu_default_29, torch.float32);  relu_default_29 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_106, 0);  to_dtype_106 = None
        new_zeros_default_410 = torch.ops.aten.new_zeros.default(to_dtype_105, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_410, to_dtype_105);  le_scalar_2 = new_zeros_default_410 = to_dtype_105 = None
        to_dtype_107 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        max_pool2d_with_indices_backward_default_2 = torch.ops.aten.max_pool2d_with_indices_backward.default(mul_tensor_248, constant_pad_nd_default_20, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_340);  mul_tensor_248 = constant_pad_nd_default_20 = getitem_340 = None
        constant_pad_nd_default_25 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default_2, [0, -1, 0, -1]);  max_pool2d_with_indices_backward_default_2 = None
        add_tensor_258 = torch.ops.aten.add.Tensor(add_tensor_216, constant_pad_nd_default_25);  add_tensor_216 = constant_pad_nd_default_25 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_258, convolution_default_177, primals_816, primals_814, primals_815, new_zeros_default_306, new_zeros_default_307, False, 0.001, [True, True, True]);  add_tensor_258 = convolution_default_177 = primals_816 = primals_814 = primals_815 = new_zeros_default_306 = new_zeros_default_307 = None
        getitem_811 = native_batch_norm_backward_default_33[0]
        getitem_812 = native_batch_norm_backward_default_33[1]
        getitem_813 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        convolution_backward_default_86 = torch.ops.aten.convolution_backward.default(getitem_811, convolution_default_176, primals_819, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_811 = convolution_default_176 = primals_819 = None
        getitem_814 = convolution_backward_default_86[0]
        getitem_815 = convolution_backward_default_86[1]
        getitem_816 = convolution_backward_default_86[2];  convolution_backward_default_86 = None
        convolution_backward_default_87 = torch.ops.aten.convolution_backward.default(getitem_814, silu__default_96, primals_817, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_814 = silu__default_96 = primals_817 = None
        getitem_817 = convolution_backward_default_87[0]
        getitem_818 = convolution_backward_default_87[1]
        getitem_819 = convolution_backward_default_87[2];  convolution_backward_default_87 = None
        to_dtype_108 = torch.ops.aten.to.dtype(getitem_817, torch.float32);  getitem_817 = None
        to_dtype_109 = torch.ops.aten.to.dtype(clone_default_96, torch.float32);  clone_default_96 = None
        neg_default_41 = torch.ops.aten.neg.default(to_dtype_109)
        exp_default_33 = torch.ops.aten.exp.default(neg_default_41);  neg_default_41 = None
        add_tensor_259 = torch.ops.aten.add.Tensor(exp_default_33, 1);  exp_default_33 = None
        reciprocal_default_33 = torch.ops.aten.reciprocal.default(add_tensor_259);  add_tensor_259 = None
        mul_tensor_255 = torch.ops.aten.mul.Tensor(reciprocal_default_33, 1);  reciprocal_default_33 = None
        mul_tensor_256 = torch.ops.aten.mul.Tensor(to_dtype_108, mul_tensor_255);  to_dtype_108 = None
        rsub_scalar_33 = torch.ops.aten.rsub.Scalar(mul_tensor_255, 1);  mul_tensor_255 = None
        mul_tensor_257 = torch.ops.aten.mul.Tensor(to_dtype_109, rsub_scalar_33);  to_dtype_109 = rsub_scalar_33 = None
        add_tensor_260 = torch.ops.aten.add.Tensor(mul_tensor_257, 1);  mul_tensor_257 = None
        mul_tensor_258 = torch.ops.aten.mul.Tensor(mul_tensor_256, add_tensor_260);  mul_tensor_256 = add_tensor_260 = None
        to_dtype_110 = torch.ops.aten.to.dtype(mul_tensor_258, torch.float32);  mul_tensor_258 = None
        unsqueeze_default_6 = torch.ops.aten.unsqueeze.default(to_dtype_110, 4);  to_dtype_110 = None
        expand_default_6 = torch.ops.aten.expand.default(unsqueeze_default_6, [1, 88, 40, 40, 3]);  unsqueeze_default_6 = None
        unbind_int_3 = torch.ops.aten.unbind.int(expand_default_6, -1);  expand_default_6 = None
        getitem_820 = unbind_int_3[0]
        getitem_821 = unbind_int_3[1]
        getitem_822 = unbind_int_3[2];  unbind_int_3 = None
        neg_default_42 = torch.ops.aten.neg.default(getitem_822)
        div_tensor_100 = torch.ops.aten.div.Tensor(mul_tensor_90, add_tensor_67);  mul_tensor_90 = None
        div_tensor_101 = torch.ops.aten.div.Tensor(div_tensor_100, add_tensor_67);  div_tensor_100 = None
        mul_tensor_259 = torch.ops.aten.mul.Tensor(neg_default_42, div_tensor_101);  neg_default_42 = div_tensor_101 = None
        div_tensor_102 = torch.ops.aten.div.Tensor(getitem_822, add_tensor_67);  getitem_822 = add_tensor_67 = None
        sum_default_48 = torch.ops.aten.sum.default(mul_tensor_259);  mul_tensor_259 = None
        mul_tensor_260 = torch.ops.aten.mul.Tensor(div_tensor_102, getitem_334);  getitem_334 = None
        mul_tensor_261 = torch.ops.aten.mul.Tensor(div_tensor_102, select_int_67);  div_tensor_102 = select_int_67 = None
        sum_default_49 = torch.ops.aten.sum.default(mul_tensor_260);  mul_tensor_260 = None
        select_backward_default_8 = torch.ops.aten.select_backward.default(sum_default_49, [3], 0, 2);  sum_default_49 = None
        neg_default_43 = torch.ops.aten.neg.default(getitem_821)
        div_tensor_103 = torch.ops.aten.div.Tensor(mul_tensor_89, add_tensor_66);  mul_tensor_89 = None
        div_tensor_104 = torch.ops.aten.div.Tensor(div_tensor_103, add_tensor_66);  div_tensor_103 = None
        mul_tensor_262 = torch.ops.aten.mul.Tensor(neg_default_43, div_tensor_104);  neg_default_43 = div_tensor_104 = None
        div_tensor_105 = torch.ops.aten.div.Tensor(getitem_821, add_tensor_66);  getitem_821 = add_tensor_66 = None
        sum_default_50 = torch.ops.aten.sum.default(mul_tensor_262);  mul_tensor_262 = None
        add_tensor_261 = torch.ops.aten.add.Tensor(sum_default_48, sum_default_50);  sum_default_48 = sum_default_50 = None
        mul_tensor_263 = torch.ops.aten.mul.Tensor(div_tensor_105, getitem_328);  getitem_328 = None
        mul_tensor_264 = torch.ops.aten.mul.Tensor(div_tensor_105, select_int_66);  div_tensor_105 = select_int_66 = None
        sum_default_51 = torch.ops.aten.sum.default(mul_tensor_263);  mul_tensor_263 = None
        select_backward_default_9 = torch.ops.aten.select_backward.default(sum_default_51, [3], 0, 1);  sum_default_51 = None
        add_tensor_262 = torch.ops.aten.add.Tensor(select_backward_default_8, select_backward_default_9);  select_backward_default_8 = select_backward_default_9 = None
        neg_default_44 = torch.ops.aten.neg.default(getitem_820)
        div_tensor_106 = torch.ops.aten.div.Tensor(mul_tensor_88, add_tensor_65);  mul_tensor_88 = None
        div_tensor_107 = torch.ops.aten.div.Tensor(div_tensor_106, add_tensor_65);  div_tensor_106 = None
        mul_tensor_265 = torch.ops.aten.mul.Tensor(neg_default_44, div_tensor_107);  neg_default_44 = div_tensor_107 = None
        div_tensor_108 = torch.ops.aten.div.Tensor(getitem_820, add_tensor_65);  getitem_820 = add_tensor_65 = None
        sum_default_52 = torch.ops.aten.sum.default(mul_tensor_265);  mul_tensor_265 = None
        add_tensor_263 = torch.ops.aten.add.Tensor(add_tensor_261, sum_default_52);  add_tensor_261 = sum_default_52 = None
        mul_tensor_266 = torch.ops.aten.mul.Tensor(div_tensor_108, getitem_304)
        mul_tensor_267 = torch.ops.aten.mul.Tensor(div_tensor_108, select_int_65);  div_tensor_108 = select_int_65 = None
        sum_default_53 = torch.ops.aten.sum.default(mul_tensor_266);  mul_tensor_266 = None
        select_backward_default_10 = torch.ops.aten.select_backward.default(sum_default_53, [3], 0, 0);  sum_default_53 = None
        add_tensor_264 = torch.ops.aten.add.Tensor(add_tensor_262, select_backward_default_10);  add_tensor_262 = select_backward_default_10 = None
        expand_default_7 = torch.ops.aten.expand.default(add_tensor_263, [3]);  add_tensor_263 = None
        add_tensor_265 = torch.ops.aten.add.Tensor(add_tensor_264, expand_default_7);  add_tensor_264 = expand_default_7 = None
        to_dtype_111 = torch.ops.aten.to.dtype(add_tensor_265, torch.float32);  add_tensor_265 = None
        to_dtype_112 = torch.ops.aten.to.dtype(relu_default_28, torch.float32);  relu_default_28 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_112, 0);  to_dtype_112 = None
        new_zeros_default_411 = torch.ops.aten.new_zeros.default(to_dtype_111, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_411, to_dtype_111);  le_scalar_3 = new_zeros_default_411 = to_dtype_111 = None
        to_dtype_113 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        max_pool2d_with_indices_backward_default_3 = torch.ops.aten.max_pool2d_with_indices_backward.default(mul_tensor_261, constant_pad_nd_default_19, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_335);  mul_tensor_261 = constant_pad_nd_default_19 = getitem_335 = None
        constant_pad_nd_default_26 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default_3, [0, -1, 0, -1]);  max_pool2d_with_indices_backward_default_3 = None
        add_tensor_266 = torch.ops.aten.add.Tensor(add_tensor_235, constant_pad_nd_default_26);  add_tensor_235 = constant_pad_nd_default_26 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_266, convolution_default_175, primals_807, primals_805, primals_806, new_zeros_default_303, new_zeros_default_304, False, 0.001, [True, True, True]);  add_tensor_266 = convolution_default_175 = primals_807 = primals_805 = primals_806 = new_zeros_default_303 = new_zeros_default_304 = None
        getitem_823 = native_batch_norm_backward_default_34[0]
        getitem_824 = native_batch_norm_backward_default_34[1]
        getitem_825 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        convolution_backward_default_88 = torch.ops.aten.convolution_backward.default(getitem_823, convolution_default_174, primals_810, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_823 = convolution_default_174 = primals_810 = None
        getitem_826 = convolution_backward_default_88[0]
        getitem_827 = convolution_backward_default_88[1]
        getitem_828 = convolution_backward_default_88[2];  convolution_backward_default_88 = None
        convolution_backward_default_89 = torch.ops.aten.convolution_backward.default(getitem_826, silu__default_95, primals_808, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_826 = silu__default_95 = primals_808 = None
        getitem_829 = convolution_backward_default_89[0]
        getitem_830 = convolution_backward_default_89[1]
        getitem_831 = convolution_backward_default_89[2];  convolution_backward_default_89 = None
        to_dtype_114 = torch.ops.aten.to.dtype(getitem_829, torch.float32);  getitem_829 = None
        to_dtype_115 = torch.ops.aten.to.dtype(clone_default_95, torch.float32);  clone_default_95 = None
        neg_default_45 = torch.ops.aten.neg.default(to_dtype_115)
        exp_default_34 = torch.ops.aten.exp.default(neg_default_45);  neg_default_45 = None
        add_tensor_267 = torch.ops.aten.add.Tensor(exp_default_34, 1);  exp_default_34 = None
        reciprocal_default_34 = torch.ops.aten.reciprocal.default(add_tensor_267);  add_tensor_267 = None
        mul_tensor_268 = torch.ops.aten.mul.Tensor(reciprocal_default_34, 1);  reciprocal_default_34 = None
        mul_tensor_269 = torch.ops.aten.mul.Tensor(to_dtype_114, mul_tensor_268);  to_dtype_114 = None
        rsub_scalar_34 = torch.ops.aten.rsub.Scalar(mul_tensor_268, 1);  mul_tensor_268 = None
        mul_tensor_270 = torch.ops.aten.mul.Tensor(to_dtype_115, rsub_scalar_34);  to_dtype_115 = rsub_scalar_34 = None
        add_tensor_268 = torch.ops.aten.add.Tensor(mul_tensor_270, 1);  mul_tensor_270 = None
        mul_tensor_271 = torch.ops.aten.mul.Tensor(mul_tensor_269, add_tensor_268);  mul_tensor_269 = add_tensor_268 = None
        to_dtype_116 = torch.ops.aten.to.dtype(mul_tensor_271, torch.float32);  mul_tensor_271 = None
        unsqueeze_default_7 = torch.ops.aten.unsqueeze.default(to_dtype_116, 4);  to_dtype_116 = None
        expand_default_8 = torch.ops.aten.expand.default(unsqueeze_default_7, [1, 88, 80, 80, 2]);  unsqueeze_default_7 = None
        unbind_int_4 = torch.ops.aten.unbind.int(expand_default_8, -1);  expand_default_8 = None
        getitem_832 = unbind_int_4[0]
        getitem_833 = unbind_int_4[1];  unbind_int_4 = None
        neg_default_46 = torch.ops.aten.neg.default(getitem_833)
        div_tensor_109 = torch.ops.aten.div.Tensor(mul_tensor_87, add_tensor_64);  mul_tensor_87 = None
        div_tensor_110 = torch.ops.aten.div.Tensor(div_tensor_109, add_tensor_64);  div_tensor_109 = None
        mul_tensor_272 = torch.ops.aten.mul.Tensor(neg_default_46, div_tensor_110);  neg_default_46 = div_tensor_110 = None
        div_tensor_111 = torch.ops.aten.div.Tensor(getitem_833, add_tensor_64);  getitem_833 = add_tensor_64 = None
        sum_default_54 = torch.ops.aten.sum.default(mul_tensor_272);  mul_tensor_272 = None
        mul_tensor_273 = torch.ops.aten.mul.Tensor(div_tensor_111, upsample_nearest2d_vec_15);  upsample_nearest2d_vec_15 = None
        mul_tensor_274 = torch.ops.aten.mul.Tensor(div_tensor_111, select_int_64);  div_tensor_111 = select_int_64 = None
        sum_default_55 = torch.ops.aten.sum.default(mul_tensor_273);  mul_tensor_273 = None
        select_backward_default_11 = torch.ops.aten.select_backward.default(sum_default_55, [2], 0, 1);  sum_default_55 = None
        neg_default_47 = torch.ops.aten.neg.default(getitem_832)
        div_tensor_112 = torch.ops.aten.div.Tensor(mul_tensor_86, add_tensor_63);  mul_tensor_86 = None
        div_tensor_113 = torch.ops.aten.div.Tensor(div_tensor_112, add_tensor_63);  div_tensor_112 = None
        mul_tensor_275 = torch.ops.aten.mul.Tensor(neg_default_47, div_tensor_113);  neg_default_47 = div_tensor_113 = None
        div_tensor_114 = torch.ops.aten.div.Tensor(getitem_832, add_tensor_63);  getitem_832 = add_tensor_63 = None
        sum_default_56 = torch.ops.aten.sum.default(mul_tensor_275);  mul_tensor_275 = None
        add_tensor_269 = torch.ops.aten.add.Tensor(sum_default_54, sum_default_56);  sum_default_54 = sum_default_56 = None
        mul_tensor_276 = torch.ops.aten.mul.Tensor(div_tensor_114, getitem_299);  getitem_299 = None
        mul_tensor_277 = torch.ops.aten.mul.Tensor(div_tensor_114, select_int_63);  div_tensor_114 = select_int_63 = None
        sum_default_57 = torch.ops.aten.sum.default(mul_tensor_276);  mul_tensor_276 = None
        select_backward_default_12 = torch.ops.aten.select_backward.default(sum_default_57, [2], 0, 0);  sum_default_57 = None
        add_tensor_270 = torch.ops.aten.add.Tensor(select_backward_default_11, select_backward_default_12);  select_backward_default_11 = select_backward_default_12 = None
        expand_default_9 = torch.ops.aten.expand.default(add_tensor_269, [2]);  add_tensor_269 = None
        add_tensor_271 = torch.ops.aten.add.Tensor(add_tensor_270, expand_default_9);  add_tensor_270 = expand_default_9 = None
        to_dtype_117 = torch.ops.aten.to.dtype(add_tensor_271, torch.float32);  add_tensor_271 = None
        to_dtype_118 = torch.ops.aten.to.dtype(relu_default_27, torch.float32);  relu_default_27 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_118, 0);  to_dtype_118 = None
        new_zeros_default_412 = torch.ops.aten.new_zeros.default(to_dtype_117, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_412, to_dtype_117);  le_scalar_4 = new_zeros_default_412 = to_dtype_117 = None
        to_dtype_119 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        upsample_nearest2d_backward_vec = torch.ops.aten.upsample_nearest2d_backward.vec(mul_tensor_274, [80, 80], [1, 88, 40, 40], None);  mul_tensor_274 = None
        add_tensor_272 = torch.ops.aten.add.Tensor(mul_tensor_264, upsample_nearest2d_backward_vec);  mul_tensor_264 = upsample_nearest2d_backward_vec = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_272, convolution_default_173, primals_798, primals_796, primals_797, new_zeros_default_300, new_zeros_default_301, False, 0.001, [True, True, True]);  add_tensor_272 = convolution_default_173 = primals_798 = primals_796 = primals_797 = new_zeros_default_300 = new_zeros_default_301 = None
        getitem_834 = native_batch_norm_backward_default_35[0]
        getitem_835 = native_batch_norm_backward_default_35[1]
        getitem_836 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        convolution_backward_default_90 = torch.ops.aten.convolution_backward.default(getitem_834, convolution_default_172, primals_801, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_834 = convolution_default_172 = primals_801 = None
        getitem_837 = convolution_backward_default_90[0]
        getitem_838 = convolution_backward_default_90[1]
        getitem_839 = convolution_backward_default_90[2];  convolution_backward_default_90 = None
        convolution_backward_default_91 = torch.ops.aten.convolution_backward.default(getitem_837, silu__default_94, primals_799, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_837 = silu__default_94 = primals_799 = None
        getitem_840 = convolution_backward_default_91[0]
        getitem_841 = convolution_backward_default_91[1]
        getitem_842 = convolution_backward_default_91[2];  convolution_backward_default_91 = None
        to_dtype_120 = torch.ops.aten.to.dtype(getitem_840, torch.float32);  getitem_840 = None
        to_dtype_121 = torch.ops.aten.to.dtype(clone_default_94, torch.float32);  clone_default_94 = None
        neg_default_48 = torch.ops.aten.neg.default(to_dtype_121)
        exp_default_35 = torch.ops.aten.exp.default(neg_default_48);  neg_default_48 = None
        add_tensor_273 = torch.ops.aten.add.Tensor(exp_default_35, 1);  exp_default_35 = None
        reciprocal_default_35 = torch.ops.aten.reciprocal.default(add_tensor_273);  add_tensor_273 = None
        mul_tensor_278 = torch.ops.aten.mul.Tensor(reciprocal_default_35, 1);  reciprocal_default_35 = None
        mul_tensor_279 = torch.ops.aten.mul.Tensor(to_dtype_120, mul_tensor_278);  to_dtype_120 = None
        rsub_scalar_35 = torch.ops.aten.rsub.Scalar(mul_tensor_278, 1);  mul_tensor_278 = None
        mul_tensor_280 = torch.ops.aten.mul.Tensor(to_dtype_121, rsub_scalar_35);  to_dtype_121 = rsub_scalar_35 = None
        add_tensor_274 = torch.ops.aten.add.Tensor(mul_tensor_280, 1);  mul_tensor_280 = None
        mul_tensor_281 = torch.ops.aten.mul.Tensor(mul_tensor_279, add_tensor_274);  mul_tensor_279 = add_tensor_274 = None
        to_dtype_122 = torch.ops.aten.to.dtype(mul_tensor_281, torch.float32);  mul_tensor_281 = None
        unsqueeze_default_8 = torch.ops.aten.unsqueeze.default(to_dtype_122, 4);  to_dtype_122 = None
        expand_default_10 = torch.ops.aten.expand.default(unsqueeze_default_8, [1, 88, 40, 40, 2]);  unsqueeze_default_8 = None
        unbind_int_5 = torch.ops.aten.unbind.int(expand_default_10, -1);  expand_default_10 = None
        getitem_843 = unbind_int_5[0]
        getitem_844 = unbind_int_5[1];  unbind_int_5 = None
        neg_default_49 = torch.ops.aten.neg.default(getitem_844)
        div_tensor_115 = torch.ops.aten.div.Tensor(mul_tensor_85, add_tensor_62);  mul_tensor_85 = None
        div_tensor_116 = torch.ops.aten.div.Tensor(div_tensor_115, add_tensor_62);  div_tensor_115 = None
        mul_tensor_282 = torch.ops.aten.mul.Tensor(neg_default_49, div_tensor_116);  neg_default_49 = div_tensor_116 = None
        div_tensor_117 = torch.ops.aten.div.Tensor(getitem_844, add_tensor_62);  getitem_844 = add_tensor_62 = None
        sum_default_58 = torch.ops.aten.sum.default(mul_tensor_282);  mul_tensor_282 = None
        mul_tensor_283 = torch.ops.aten.mul.Tensor(div_tensor_117, upsample_nearest2d_vec_14);  upsample_nearest2d_vec_14 = None
        mul_tensor_284 = torch.ops.aten.mul.Tensor(div_tensor_117, select_int_62);  div_tensor_117 = select_int_62 = None
        sum_default_59 = torch.ops.aten.sum.default(mul_tensor_283);  mul_tensor_283 = None
        select_backward_default_13 = torch.ops.aten.select_backward.default(sum_default_59, [2], 0, 1);  sum_default_59 = None
        neg_default_50 = torch.ops.aten.neg.default(getitem_843)
        div_tensor_118 = torch.ops.aten.div.Tensor(mul_tensor_84, add_tensor_61);  mul_tensor_84 = None
        div_tensor_119 = torch.ops.aten.div.Tensor(div_tensor_118, add_tensor_61);  div_tensor_118 = None
        mul_tensor_285 = torch.ops.aten.mul.Tensor(neg_default_50, div_tensor_119);  neg_default_50 = div_tensor_119 = None
        div_tensor_120 = torch.ops.aten.div.Tensor(getitem_843, add_tensor_61);  getitem_843 = add_tensor_61 = None
        sum_default_60 = torch.ops.aten.sum.default(mul_tensor_285);  mul_tensor_285 = None
        add_tensor_275 = torch.ops.aten.add.Tensor(sum_default_58, sum_default_60);  sum_default_58 = sum_default_60 = None
        mul_tensor_286 = torch.ops.aten.mul.Tensor(div_tensor_120, getitem_304);  getitem_304 = None
        mul_tensor_287 = torch.ops.aten.mul.Tensor(div_tensor_120, select_int_61);  div_tensor_120 = select_int_61 = None
        sum_default_61 = torch.ops.aten.sum.default(mul_tensor_286);  mul_tensor_286 = None
        add_tensor_276 = torch.ops.aten.add.Tensor(mul_tensor_267, mul_tensor_287);  mul_tensor_267 = mul_tensor_287 = None
        select_backward_default_14 = torch.ops.aten.select_backward.default(sum_default_61, [2], 0, 0);  sum_default_61 = None
        add_tensor_277 = torch.ops.aten.add.Tensor(select_backward_default_13, select_backward_default_14);  select_backward_default_13 = select_backward_default_14 = None
        expand_default_11 = torch.ops.aten.expand.default(add_tensor_275, [2]);  add_tensor_275 = None
        add_tensor_278 = torch.ops.aten.add.Tensor(add_tensor_277, expand_default_11);  add_tensor_277 = expand_default_11 = None
        to_dtype_123 = torch.ops.aten.to.dtype(add_tensor_278, torch.float32);  add_tensor_278 = None
        to_dtype_124 = torch.ops.aten.to.dtype(relu_default_26, torch.float32);  relu_default_26 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_124, 0);  to_dtype_124 = None
        new_zeros_default_413 = torch.ops.aten.new_zeros.default(to_dtype_123, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_413, to_dtype_123);  le_scalar_5 = new_zeros_default_413 = to_dtype_123 = None
        to_dtype_125 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        upsample_nearest2d_backward_vec_1 = torch.ops.aten.upsample_nearest2d_backward.vec(mul_tensor_284, [40, 40], [1, 88, 20, 20], None);  mul_tensor_284 = None
        add_tensor_279 = torch.ops.aten.add.Tensor(mul_tensor_251, upsample_nearest2d_backward_vec_1);  mul_tensor_251 = upsample_nearest2d_backward_vec_1 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_279, convolution_default_171, primals_789, primals_787, primals_788, new_zeros_default_297, new_zeros_default_298, False, 0.001, [True, True, True]);  add_tensor_279 = convolution_default_171 = primals_789 = primals_787 = primals_788 = new_zeros_default_297 = new_zeros_default_298 = None
        getitem_845 = native_batch_norm_backward_default_36[0]
        getitem_846 = native_batch_norm_backward_default_36[1]
        getitem_847 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        convolution_backward_default_92 = torch.ops.aten.convolution_backward.default(getitem_845, convolution_default_170, primals_792, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_845 = convolution_default_170 = primals_792 = None
        getitem_848 = convolution_backward_default_92[0]
        getitem_849 = convolution_backward_default_92[1]
        getitem_850 = convolution_backward_default_92[2];  convolution_backward_default_92 = None
        convolution_backward_default_93 = torch.ops.aten.convolution_backward.default(getitem_848, silu__default_93, primals_790, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_848 = silu__default_93 = primals_790 = None
        getitem_851 = convolution_backward_default_93[0]
        getitem_852 = convolution_backward_default_93[1]
        getitem_853 = convolution_backward_default_93[2];  convolution_backward_default_93 = None
        to_dtype_126 = torch.ops.aten.to.dtype(getitem_851, torch.float32);  getitem_851 = None
        to_dtype_127 = torch.ops.aten.to.dtype(clone_default_93, torch.float32);  clone_default_93 = None
        neg_default_51 = torch.ops.aten.neg.default(to_dtype_127)
        exp_default_36 = torch.ops.aten.exp.default(neg_default_51);  neg_default_51 = None
        add_tensor_280 = torch.ops.aten.add.Tensor(exp_default_36, 1);  exp_default_36 = None
        reciprocal_default_36 = torch.ops.aten.reciprocal.default(add_tensor_280);  add_tensor_280 = None
        mul_tensor_288 = torch.ops.aten.mul.Tensor(reciprocal_default_36, 1);  reciprocal_default_36 = None
        mul_tensor_289 = torch.ops.aten.mul.Tensor(to_dtype_126, mul_tensor_288);  to_dtype_126 = None
        rsub_scalar_36 = torch.ops.aten.rsub.Scalar(mul_tensor_288, 1);  mul_tensor_288 = None
        mul_tensor_290 = torch.ops.aten.mul.Tensor(to_dtype_127, rsub_scalar_36);  to_dtype_127 = rsub_scalar_36 = None
        add_tensor_281 = torch.ops.aten.add.Tensor(mul_tensor_290, 1);  mul_tensor_290 = None
        mul_tensor_291 = torch.ops.aten.mul.Tensor(mul_tensor_289, add_tensor_281);  mul_tensor_289 = add_tensor_281 = None
        to_dtype_128 = torch.ops.aten.to.dtype(mul_tensor_291, torch.float32);  mul_tensor_291 = None
        unsqueeze_default_9 = torch.ops.aten.unsqueeze.default(to_dtype_128, 4);  to_dtype_128 = None
        expand_default_12 = torch.ops.aten.expand.default(unsqueeze_default_9, [1, 88, 20, 20, 2]);  unsqueeze_default_9 = None
        unbind_int_6 = torch.ops.aten.unbind.int(expand_default_12, -1);  expand_default_12 = None
        getitem_854 = unbind_int_6[0]
        getitem_855 = unbind_int_6[1];  unbind_int_6 = None
        neg_default_52 = torch.ops.aten.neg.default(getitem_855)
        div_tensor_121 = torch.ops.aten.div.Tensor(mul_tensor_83, add_tensor_60);  mul_tensor_83 = None
        div_tensor_122 = torch.ops.aten.div.Tensor(div_tensor_121, add_tensor_60);  div_tensor_121 = None
        mul_tensor_292 = torch.ops.aten.mul.Tensor(neg_default_52, div_tensor_122);  neg_default_52 = div_tensor_122 = None
        div_tensor_123 = torch.ops.aten.div.Tensor(getitem_855, add_tensor_60);  getitem_855 = add_tensor_60 = None
        sum_default_62 = torch.ops.aten.sum.default(mul_tensor_292);  mul_tensor_292 = None
        mul_tensor_293 = torch.ops.aten.mul.Tensor(div_tensor_123, upsample_nearest2d_vec_13);  upsample_nearest2d_vec_13 = None
        mul_tensor_294 = torch.ops.aten.mul.Tensor(div_tensor_123, select_int_60);  div_tensor_123 = select_int_60 = None
        sum_default_63 = torch.ops.aten.sum.default(mul_tensor_293);  mul_tensor_293 = None
        select_backward_default_15 = torch.ops.aten.select_backward.default(sum_default_63, [2], 0, 1);  sum_default_63 = None
        neg_default_53 = torch.ops.aten.neg.default(getitem_854)
        div_tensor_124 = torch.ops.aten.div.Tensor(mul_tensor_82, add_tensor_59);  mul_tensor_82 = None
        div_tensor_125 = torch.ops.aten.div.Tensor(div_tensor_124, add_tensor_59);  div_tensor_124 = None
        mul_tensor_295 = torch.ops.aten.mul.Tensor(neg_default_53, div_tensor_125);  neg_default_53 = div_tensor_125 = None
        div_tensor_126 = torch.ops.aten.div.Tensor(getitem_854, add_tensor_59);  getitem_854 = add_tensor_59 = None
        sum_default_64 = torch.ops.aten.sum.default(mul_tensor_295);  mul_tensor_295 = None
        add_tensor_282 = torch.ops.aten.add.Tensor(sum_default_62, sum_default_64);  sum_default_62 = sum_default_64 = None
        mul_tensor_296 = torch.ops.aten.mul.Tensor(div_tensor_126, getitem_309);  getitem_309 = None
        mul_tensor_297 = torch.ops.aten.mul.Tensor(div_tensor_126, select_int_59);  div_tensor_126 = select_int_59 = None
        sum_default_65 = torch.ops.aten.sum.default(mul_tensor_296);  mul_tensor_296 = None
        add_tensor_283 = torch.ops.aten.add.Tensor(mul_tensor_254, mul_tensor_297);  mul_tensor_254 = mul_tensor_297 = None
        select_backward_default_16 = torch.ops.aten.select_backward.default(sum_default_65, [2], 0, 0);  sum_default_65 = None
        add_tensor_284 = torch.ops.aten.add.Tensor(select_backward_default_15, select_backward_default_16);  select_backward_default_15 = select_backward_default_16 = None
        expand_default_13 = torch.ops.aten.expand.default(add_tensor_282, [2]);  add_tensor_282 = None
        add_tensor_285 = torch.ops.aten.add.Tensor(add_tensor_284, expand_default_13);  add_tensor_284 = expand_default_13 = None
        to_dtype_129 = torch.ops.aten.to.dtype(add_tensor_285, torch.float32);  add_tensor_285 = None
        to_dtype_130 = torch.ops.aten.to.dtype(relu_default_25, torch.float32);  relu_default_25 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_130, 0);  to_dtype_130 = None
        new_zeros_default_414 = torch.ops.aten.new_zeros.default(to_dtype_129, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_414, to_dtype_129);  le_scalar_6 = new_zeros_default_414 = to_dtype_129 = None
        to_dtype_131 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        upsample_nearest2d_backward_vec_2 = torch.ops.aten.upsample_nearest2d_backward.vec(mul_tensor_294, [20, 20], [1, 88, 10, 10], None);  mul_tensor_294 = None
        add_tensor_286 = torch.ops.aten.add.Tensor(mul_tensor_238, upsample_nearest2d_backward_vec_2);  mul_tensor_238 = upsample_nearest2d_backward_vec_2 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_286, convolution_default_169, primals_780, primals_778, primals_779, new_zeros_default_294, new_zeros_default_295, False, 0.001, [True, True, True]);  add_tensor_286 = convolution_default_169 = primals_780 = primals_778 = primals_779 = new_zeros_default_294 = new_zeros_default_295 = None
        getitem_856 = native_batch_norm_backward_default_37[0]
        getitem_857 = native_batch_norm_backward_default_37[1]
        getitem_858 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        convolution_backward_default_94 = torch.ops.aten.convolution_backward.default(getitem_856, convolution_default_168, primals_783, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_856 = convolution_default_168 = primals_783 = None
        getitem_859 = convolution_backward_default_94[0]
        getitem_860 = convolution_backward_default_94[1]
        getitem_861 = convolution_backward_default_94[2];  convolution_backward_default_94 = None
        convolution_backward_default_95 = torch.ops.aten.convolution_backward.default(getitem_859, silu__default_92, primals_781, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_859 = silu__default_92 = primals_781 = None
        getitem_862 = convolution_backward_default_95[0]
        getitem_863 = convolution_backward_default_95[1]
        getitem_864 = convolution_backward_default_95[2];  convolution_backward_default_95 = None
        to_dtype_132 = torch.ops.aten.to.dtype(getitem_862, torch.float32);  getitem_862 = None
        to_dtype_133 = torch.ops.aten.to.dtype(clone_default_92, torch.float32);  clone_default_92 = None
        neg_default_54 = torch.ops.aten.neg.default(to_dtype_133)
        exp_default_37 = torch.ops.aten.exp.default(neg_default_54);  neg_default_54 = None
        add_tensor_287 = torch.ops.aten.add.Tensor(exp_default_37, 1);  exp_default_37 = None
        reciprocal_default_37 = torch.ops.aten.reciprocal.default(add_tensor_287);  add_tensor_287 = None
        mul_tensor_298 = torch.ops.aten.mul.Tensor(reciprocal_default_37, 1);  reciprocal_default_37 = None
        mul_tensor_299 = torch.ops.aten.mul.Tensor(to_dtype_132, mul_tensor_298);  to_dtype_132 = None
        rsub_scalar_37 = torch.ops.aten.rsub.Scalar(mul_tensor_298, 1);  mul_tensor_298 = None
        mul_tensor_300 = torch.ops.aten.mul.Tensor(to_dtype_133, rsub_scalar_37);  to_dtype_133 = rsub_scalar_37 = None
        add_tensor_288 = torch.ops.aten.add.Tensor(mul_tensor_300, 1);  mul_tensor_300 = None
        mul_tensor_301 = torch.ops.aten.mul.Tensor(mul_tensor_299, add_tensor_288);  mul_tensor_299 = add_tensor_288 = None
        to_dtype_134 = torch.ops.aten.to.dtype(mul_tensor_301, torch.float32);  mul_tensor_301 = None
        unsqueeze_default_10 = torch.ops.aten.unsqueeze.default(to_dtype_134, 4);  to_dtype_134 = None
        expand_default_14 = torch.ops.aten.expand.default(unsqueeze_default_10, [1, 88, 10, 10, 2]);  unsqueeze_default_10 = None
        unbind_int_7 = torch.ops.aten.unbind.int(expand_default_14, -1);  expand_default_14 = None
        getitem_865 = unbind_int_7[0]
        getitem_866 = unbind_int_7[1];  unbind_int_7 = None
        neg_default_55 = torch.ops.aten.neg.default(getitem_866)
        div_tensor_127 = torch.ops.aten.div.Tensor(mul_tensor_81, add_tensor_58);  mul_tensor_81 = None
        div_tensor_128 = torch.ops.aten.div.Tensor(div_tensor_127, add_tensor_58);  div_tensor_127 = None
        mul_tensor_302 = torch.ops.aten.mul.Tensor(neg_default_55, div_tensor_128);  neg_default_55 = div_tensor_128 = None
        div_tensor_129 = torch.ops.aten.div.Tensor(getitem_866, add_tensor_58);  getitem_866 = add_tensor_58 = None
        sum_default_66 = torch.ops.aten.sum.default(mul_tensor_302);  mul_tensor_302 = None
        mul_tensor_303 = torch.ops.aten.mul.Tensor(div_tensor_129, upsample_nearest2d_vec_12);  upsample_nearest2d_vec_12 = None
        mul_tensor_304 = torch.ops.aten.mul.Tensor(div_tensor_129, select_int_58);  div_tensor_129 = select_int_58 = None
        sum_default_67 = torch.ops.aten.sum.default(mul_tensor_303);  mul_tensor_303 = None
        select_backward_default_17 = torch.ops.aten.select_backward.default(sum_default_67, [2], 0, 1);  sum_default_67 = None
        neg_default_56 = torch.ops.aten.neg.default(getitem_865)
        div_tensor_130 = torch.ops.aten.div.Tensor(mul_tensor_80, add_tensor_57);  mul_tensor_80 = None
        div_tensor_131 = torch.ops.aten.div.Tensor(div_tensor_130, add_tensor_57);  div_tensor_130 = None
        mul_tensor_305 = torch.ops.aten.mul.Tensor(neg_default_56, div_tensor_131);  neg_default_56 = div_tensor_131 = None
        div_tensor_132 = torch.ops.aten.div.Tensor(getitem_865, add_tensor_57);  getitem_865 = add_tensor_57 = None
        sum_default_68 = torch.ops.aten.sum.default(mul_tensor_305);  mul_tensor_305 = None
        add_tensor_289 = torch.ops.aten.add.Tensor(sum_default_66, sum_default_68);  sum_default_66 = sum_default_68 = None
        mul_tensor_306 = torch.ops.aten.mul.Tensor(div_tensor_132, getitem_314);  getitem_314 = None
        mul_tensor_307 = torch.ops.aten.mul.Tensor(div_tensor_132, select_int_57);  div_tensor_132 = select_int_57 = None
        sum_default_69 = torch.ops.aten.sum.default(mul_tensor_306);  mul_tensor_306 = None
        add_tensor_290 = torch.ops.aten.add.Tensor(mul_tensor_241, mul_tensor_307);  mul_tensor_241 = mul_tensor_307 = None
        select_backward_default_18 = torch.ops.aten.select_backward.default(sum_default_69, [2], 0, 0);  sum_default_69 = None
        add_tensor_291 = torch.ops.aten.add.Tensor(select_backward_default_17, select_backward_default_18);  select_backward_default_17 = select_backward_default_18 = None
        expand_default_15 = torch.ops.aten.expand.default(add_tensor_289, [2]);  add_tensor_289 = None
        add_tensor_292 = torch.ops.aten.add.Tensor(add_tensor_291, expand_default_15);  add_tensor_291 = expand_default_15 = None
        to_dtype_135 = torch.ops.aten.to.dtype(add_tensor_292, torch.float32);  add_tensor_292 = None
        to_dtype_136 = torch.ops.aten.to.dtype(relu_default_24, torch.float32);  relu_default_24 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_136, 0);  to_dtype_136 = None
        new_zeros_default_415 = torch.ops.aten.new_zeros.default(to_dtype_135, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_415, to_dtype_135);  le_scalar_7 = new_zeros_default_415 = to_dtype_135 = None
        to_dtype_137 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        upsample_nearest2d_backward_vec_3 = torch.ops.aten.upsample_nearest2d_backward.vec(mul_tensor_304, [10, 10], [1, 88, 5, 5], None);  mul_tensor_304 = None
        add_tensor_293 = torch.ops.aten.add.Tensor(mul_tensor_228, upsample_nearest2d_backward_vec_3);  mul_tensor_228 = upsample_nearest2d_backward_vec_3 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_293, convolution_default_167, primals_771, primals_769, primals_770, new_zeros_default_291, new_zeros_default_292, False, 0.001, [True, True, True]);  add_tensor_293 = convolution_default_167 = primals_771 = primals_769 = primals_770 = new_zeros_default_291 = new_zeros_default_292 = None
        getitem_867 = native_batch_norm_backward_default_38[0]
        getitem_868 = native_batch_norm_backward_default_38[1]
        getitem_869 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        convolution_backward_default_96 = torch.ops.aten.convolution_backward.default(getitem_867, convolution_default_166, primals_774, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_867 = convolution_default_166 = primals_774 = None
        getitem_870 = convolution_backward_default_96[0]
        getitem_871 = convolution_backward_default_96[1]
        getitem_872 = convolution_backward_default_96[2];  convolution_backward_default_96 = None
        convolution_backward_default_97 = torch.ops.aten.convolution_backward.default(getitem_870, silu__default_91, primals_772, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_870 = silu__default_91 = primals_772 = None
        getitem_873 = convolution_backward_default_97[0]
        getitem_874 = convolution_backward_default_97[1]
        getitem_875 = convolution_backward_default_97[2];  convolution_backward_default_97 = None
        to_dtype_138 = torch.ops.aten.to.dtype(getitem_873, torch.float32);  getitem_873 = None
        to_dtype_139 = torch.ops.aten.to.dtype(clone_default_91, torch.float32);  clone_default_91 = None
        neg_default_57 = torch.ops.aten.neg.default(to_dtype_139)
        exp_default_38 = torch.ops.aten.exp.default(neg_default_57);  neg_default_57 = None
        add_tensor_294 = torch.ops.aten.add.Tensor(exp_default_38, 1);  exp_default_38 = None
        reciprocal_default_38 = torch.ops.aten.reciprocal.default(add_tensor_294);  add_tensor_294 = None
        mul_tensor_308 = torch.ops.aten.mul.Tensor(reciprocal_default_38, 1);  reciprocal_default_38 = None
        mul_tensor_309 = torch.ops.aten.mul.Tensor(to_dtype_138, mul_tensor_308);  to_dtype_138 = None
        rsub_scalar_38 = torch.ops.aten.rsub.Scalar(mul_tensor_308, 1);  mul_tensor_308 = None
        mul_tensor_310 = torch.ops.aten.mul.Tensor(to_dtype_139, rsub_scalar_38);  to_dtype_139 = rsub_scalar_38 = None
        add_tensor_295 = torch.ops.aten.add.Tensor(mul_tensor_310, 1);  mul_tensor_310 = None
        mul_tensor_311 = torch.ops.aten.mul.Tensor(mul_tensor_309, add_tensor_295);  mul_tensor_309 = add_tensor_295 = None
        to_dtype_140 = torch.ops.aten.to.dtype(mul_tensor_311, torch.float32);  mul_tensor_311 = None
        unsqueeze_default_11 = torch.ops.aten.unsqueeze.default(to_dtype_140, 4);  to_dtype_140 = None
        expand_default_16 = torch.ops.aten.expand.default(unsqueeze_default_11, [1, 88, 5, 5, 2]);  unsqueeze_default_11 = None
        unbind_int_8 = torch.ops.aten.unbind.int(expand_default_16, -1);  expand_default_16 = None
        getitem_876 = unbind_int_8[0]
        getitem_877 = unbind_int_8[1];  unbind_int_8 = None
        neg_default_58 = torch.ops.aten.neg.default(getitem_877)
        div_tensor_133 = torch.ops.aten.div.Tensor(mul_tensor_79, add_tensor_56);  mul_tensor_79 = None
        div_tensor_134 = torch.ops.aten.div.Tensor(div_tensor_133, add_tensor_56);  div_tensor_133 = None
        mul_tensor_312 = torch.ops.aten.mul.Tensor(neg_default_58, div_tensor_134);  neg_default_58 = div_tensor_134 = None
        div_tensor_135 = torch.ops.aten.div.Tensor(getitem_877, add_tensor_56);  getitem_877 = add_tensor_56 = None
        sum_default_70 = torch.ops.aten.sum.default(mul_tensor_312);  mul_tensor_312 = None
        mul_tensor_313 = torch.ops.aten.mul.Tensor(div_tensor_135, getitem_317);  getitem_317 = None
        mul_tensor_314 = torch.ops.aten.mul.Tensor(div_tensor_135, select_int_56);  div_tensor_135 = select_int_56 = None
        sum_default_71 = torch.ops.aten.sum.default(mul_tensor_313);  mul_tensor_313 = None
        select_backward_default_19 = torch.ops.aten.select_backward.default(sum_default_71, [2], 0, 1);  sum_default_71 = None
        neg_default_59 = torch.ops.aten.neg.default(getitem_876)
        div_tensor_136 = torch.ops.aten.div.Tensor(mul_tensor_78, add_tensor_55);  mul_tensor_78 = None
        div_tensor_137 = torch.ops.aten.div.Tensor(div_tensor_136, add_tensor_55);  div_tensor_136 = None
        mul_tensor_315 = torch.ops.aten.mul.Tensor(neg_default_59, div_tensor_137);  neg_default_59 = div_tensor_137 = None
        div_tensor_138 = torch.ops.aten.div.Tensor(getitem_876, add_tensor_55);  getitem_876 = add_tensor_55 = None
        sum_default_72 = torch.ops.aten.sum.default(mul_tensor_315);  mul_tensor_315 = None
        add_tensor_296 = torch.ops.aten.add.Tensor(sum_default_70, sum_default_72);  sum_default_70 = sum_default_72 = None
        mul_tensor_316 = torch.ops.aten.mul.Tensor(div_tensor_138, getitem_287);  getitem_287 = None
        mul_tensor_317 = torch.ops.aten.mul.Tensor(div_tensor_138, select_int_55);  div_tensor_138 = select_int_55 = None
        sum_default_73 = torch.ops.aten.sum.default(mul_tensor_316);  mul_tensor_316 = None
        select_backward_default_20 = torch.ops.aten.select_backward.default(sum_default_73, [2], 0, 0);  sum_default_73 = None
        add_tensor_297 = torch.ops.aten.add.Tensor(select_backward_default_19, select_backward_default_20);  select_backward_default_19 = select_backward_default_20 = None
        expand_default_17 = torch.ops.aten.expand.default(add_tensor_296, [2]);  add_tensor_296 = None
        add_tensor_298 = torch.ops.aten.add.Tensor(add_tensor_297, expand_default_17);  add_tensor_297 = expand_default_17 = None
        to_dtype_141 = torch.ops.aten.to.dtype(add_tensor_298, torch.float32);  add_tensor_298 = None
        to_dtype_142 = torch.ops.aten.to.dtype(relu_default_23, torch.float32);  relu_default_23 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_142, 0);  to_dtype_142 = None
        new_zeros_default_416 = torch.ops.aten.new_zeros.default(to_dtype_141, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_416, to_dtype_141);  le_scalar_8 = new_zeros_default_416 = to_dtype_141 = None
        to_dtype_143 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        max_pool2d_with_indices_backward_default_4 = torch.ops.aten.max_pool2d_with_indices_backward.default(mul_tensor_314, constant_pad_nd_default_18, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_318);  mul_tensor_314 = constant_pad_nd_default_18 = getitem_318 = None
        constant_pad_nd_default_27 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default_4, [0, -1, 0, -1]);  max_pool2d_with_indices_backward_default_4 = None
        add_tensor_299 = torch.ops.aten.add.Tensor(add_tensor_290, constant_pad_nd_default_27);  add_tensor_290 = constant_pad_nd_default_27 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_299, convolution_default_165, primals_762, primals_760, primals_761, new_zeros_default_288, new_zeros_default_289, False, 0.001, [True, True, True]);  add_tensor_299 = convolution_default_165 = primals_762 = primals_760 = primals_761 = new_zeros_default_288 = new_zeros_default_289 = None
        getitem_878 = native_batch_norm_backward_default_39[0]
        getitem_879 = native_batch_norm_backward_default_39[1]
        getitem_880 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        convolution_backward_default_98 = torch.ops.aten.convolution_backward.default(getitem_878, convolution_default_164, primals_765, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_878 = convolution_default_164 = primals_765 = None
        getitem_881 = convolution_backward_default_98[0]
        getitem_882 = convolution_backward_default_98[1]
        getitem_883 = convolution_backward_default_98[2];  convolution_backward_default_98 = None
        convolution_backward_default_99 = torch.ops.aten.convolution_backward.default(getitem_881, silu__default_90, primals_763, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_881 = silu__default_90 = primals_763 = None
        getitem_884 = convolution_backward_default_99[0]
        getitem_885 = convolution_backward_default_99[1]
        getitem_886 = convolution_backward_default_99[2];  convolution_backward_default_99 = None
        to_dtype_144 = torch.ops.aten.to.dtype(getitem_884, torch.float32);  getitem_884 = None
        to_dtype_145 = torch.ops.aten.to.dtype(clone_default_90, torch.float32);  clone_default_90 = None
        neg_default_60 = torch.ops.aten.neg.default(to_dtype_145)
        exp_default_39 = torch.ops.aten.exp.default(neg_default_60);  neg_default_60 = None
        add_tensor_300 = torch.ops.aten.add.Tensor(exp_default_39, 1);  exp_default_39 = None
        reciprocal_default_39 = torch.ops.aten.reciprocal.default(add_tensor_300);  add_tensor_300 = None
        mul_tensor_318 = torch.ops.aten.mul.Tensor(reciprocal_default_39, 1);  reciprocal_default_39 = None
        mul_tensor_319 = torch.ops.aten.mul.Tensor(to_dtype_144, mul_tensor_318);  to_dtype_144 = None
        rsub_scalar_39 = torch.ops.aten.rsub.Scalar(mul_tensor_318, 1);  mul_tensor_318 = None
        mul_tensor_320 = torch.ops.aten.mul.Tensor(to_dtype_145, rsub_scalar_39);  to_dtype_145 = rsub_scalar_39 = None
        add_tensor_301 = torch.ops.aten.add.Tensor(mul_tensor_320, 1);  mul_tensor_320 = None
        mul_tensor_321 = torch.ops.aten.mul.Tensor(mul_tensor_319, add_tensor_301);  mul_tensor_319 = add_tensor_301 = None
        to_dtype_146 = torch.ops.aten.to.dtype(mul_tensor_321, torch.float32);  mul_tensor_321 = None
        unsqueeze_default_12 = torch.ops.aten.unsqueeze.default(to_dtype_146, 4);  to_dtype_146 = None
        expand_default_18 = torch.ops.aten.expand.default(unsqueeze_default_12, [1, 88, 10, 10, 3]);  unsqueeze_default_12 = None
        unbind_int_9 = torch.ops.aten.unbind.int(expand_default_18, -1);  expand_default_18 = None
        getitem_887 = unbind_int_9[0]
        getitem_888 = unbind_int_9[1]
        getitem_889 = unbind_int_9[2];  unbind_int_9 = None
        neg_default_61 = torch.ops.aten.neg.default(getitem_889)
        div_tensor_139 = torch.ops.aten.div.Tensor(mul_tensor_77, add_tensor_54);  mul_tensor_77 = None
        div_tensor_140 = torch.ops.aten.div.Tensor(div_tensor_139, add_tensor_54);  div_tensor_139 = None
        mul_tensor_322 = torch.ops.aten.mul.Tensor(neg_default_61, div_tensor_140);  neg_default_61 = div_tensor_140 = None
        div_tensor_141 = torch.ops.aten.div.Tensor(getitem_889, add_tensor_54);  getitem_889 = add_tensor_54 = None
        sum_default_74 = torch.ops.aten.sum.default(mul_tensor_322);  mul_tensor_322 = None
        mul_tensor_323 = torch.ops.aten.mul.Tensor(div_tensor_141, getitem_312);  getitem_312 = None
        mul_tensor_324 = torch.ops.aten.mul.Tensor(div_tensor_141, select_int_54);  div_tensor_141 = select_int_54 = None
        sum_default_75 = torch.ops.aten.sum.default(mul_tensor_323);  mul_tensor_323 = None
        select_backward_default_21 = torch.ops.aten.select_backward.default(sum_default_75, [3], 0, 2);  sum_default_75 = None
        neg_default_62 = torch.ops.aten.neg.default(getitem_888)
        div_tensor_142 = torch.ops.aten.div.Tensor(mul_tensor_76, add_tensor_53);  mul_tensor_76 = None
        div_tensor_143 = torch.ops.aten.div.Tensor(div_tensor_142, add_tensor_53);  div_tensor_142 = None
        mul_tensor_325 = torch.ops.aten.mul.Tensor(neg_default_62, div_tensor_143);  neg_default_62 = div_tensor_143 = None
        div_tensor_144 = torch.ops.aten.div.Tensor(getitem_888, add_tensor_53);  getitem_888 = add_tensor_53 = None
        sum_default_76 = torch.ops.aten.sum.default(mul_tensor_325);  mul_tensor_325 = None
        add_tensor_302 = torch.ops.aten.add.Tensor(sum_default_74, sum_default_76);  sum_default_74 = sum_default_76 = None
        mul_tensor_326 = torch.ops.aten.mul.Tensor(div_tensor_144, getitem_290);  getitem_290 = None
        mul_tensor_327 = torch.ops.aten.mul.Tensor(div_tensor_144, select_int_53);  div_tensor_144 = select_int_53 = None
        sum_default_77 = torch.ops.aten.sum.default(mul_tensor_326);  mul_tensor_326 = None
        select_backward_default_22 = torch.ops.aten.select_backward.default(sum_default_77, [3], 0, 1);  sum_default_77 = None
        add_tensor_303 = torch.ops.aten.add.Tensor(select_backward_default_21, select_backward_default_22);  select_backward_default_21 = select_backward_default_22 = None
        neg_default_63 = torch.ops.aten.neg.default(getitem_887)
        div_tensor_145 = torch.ops.aten.div.Tensor(mul_tensor_75, add_tensor_52);  mul_tensor_75 = None
        div_tensor_146 = torch.ops.aten.div.Tensor(div_tensor_145, add_tensor_52);  div_tensor_145 = None
        mul_tensor_328 = torch.ops.aten.mul.Tensor(neg_default_63, div_tensor_146);  neg_default_63 = div_tensor_146 = None
        div_tensor_147 = torch.ops.aten.div.Tensor(getitem_887, add_tensor_52);  getitem_887 = add_tensor_52 = None
        sum_default_78 = torch.ops.aten.sum.default(mul_tensor_328);  mul_tensor_328 = None
        add_tensor_304 = torch.ops.aten.add.Tensor(add_tensor_302, sum_default_78);  add_tensor_302 = sum_default_78 = None
        mul_tensor_329 = torch.ops.aten.mul.Tensor(div_tensor_147, getitem_282)
        mul_tensor_330 = torch.ops.aten.mul.Tensor(div_tensor_147, select_int_52);  div_tensor_147 = select_int_52 = None
        sum_default_79 = torch.ops.aten.sum.default(mul_tensor_329);  mul_tensor_329 = None
        select_backward_default_23 = torch.ops.aten.select_backward.default(sum_default_79, [3], 0, 0);  sum_default_79 = None
        add_tensor_305 = torch.ops.aten.add.Tensor(add_tensor_303, select_backward_default_23);  add_tensor_303 = select_backward_default_23 = None
        expand_default_19 = torch.ops.aten.expand.default(add_tensor_304, [3]);  add_tensor_304 = None
        add_tensor_306 = torch.ops.aten.add.Tensor(add_tensor_305, expand_default_19);  add_tensor_305 = expand_default_19 = None
        to_dtype_147 = torch.ops.aten.to.dtype(add_tensor_306, torch.float32);  add_tensor_306 = None
        to_dtype_148 = torch.ops.aten.to.dtype(relu_default_22, torch.float32);  relu_default_22 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_148, 0);  to_dtype_148 = None
        new_zeros_default_417 = torch.ops.aten.new_zeros.default(to_dtype_147, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_417, to_dtype_147);  le_scalar_9 = new_zeros_default_417 = to_dtype_147 = None
        to_dtype_149 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        max_pool2d_with_indices_backward_default_5 = torch.ops.aten.max_pool2d_with_indices_backward.default(mul_tensor_324, constant_pad_nd_default_17, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_313);  mul_tensor_324 = constant_pad_nd_default_17 = getitem_313 = None
        constant_pad_nd_default_28 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default_5, [0, -1, 0, -1]);  max_pool2d_with_indices_backward_default_5 = None
        add_tensor_307 = torch.ops.aten.add.Tensor(add_tensor_283, constant_pad_nd_default_28);  add_tensor_283 = constant_pad_nd_default_28 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_307, convolution_default_163, primals_753, primals_751, primals_752, new_zeros_default_285, new_zeros_default_286, False, 0.001, [True, True, True]);  add_tensor_307 = convolution_default_163 = primals_753 = primals_751 = primals_752 = new_zeros_default_285 = new_zeros_default_286 = None
        getitem_890 = native_batch_norm_backward_default_40[0]
        getitem_891 = native_batch_norm_backward_default_40[1]
        getitem_892 = native_batch_norm_backward_default_40[2];  native_batch_norm_backward_default_40 = None
        convolution_backward_default_100 = torch.ops.aten.convolution_backward.default(getitem_890, convolution_default_162, primals_756, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_890 = convolution_default_162 = primals_756 = None
        getitem_893 = convolution_backward_default_100[0]
        getitem_894 = convolution_backward_default_100[1]
        getitem_895 = convolution_backward_default_100[2];  convolution_backward_default_100 = None
        convolution_backward_default_101 = torch.ops.aten.convolution_backward.default(getitem_893, silu__default_89, primals_754, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_893 = silu__default_89 = primals_754 = None
        getitem_896 = convolution_backward_default_101[0]
        getitem_897 = convolution_backward_default_101[1]
        getitem_898 = convolution_backward_default_101[2];  convolution_backward_default_101 = None
        to_dtype_150 = torch.ops.aten.to.dtype(getitem_896, torch.float32);  getitem_896 = None
        to_dtype_151 = torch.ops.aten.to.dtype(clone_default_89, torch.float32);  clone_default_89 = None
        neg_default_64 = torch.ops.aten.neg.default(to_dtype_151)
        exp_default_40 = torch.ops.aten.exp.default(neg_default_64);  neg_default_64 = None
        add_tensor_308 = torch.ops.aten.add.Tensor(exp_default_40, 1);  exp_default_40 = None
        reciprocal_default_40 = torch.ops.aten.reciprocal.default(add_tensor_308);  add_tensor_308 = None
        mul_tensor_331 = torch.ops.aten.mul.Tensor(reciprocal_default_40, 1);  reciprocal_default_40 = None
        mul_tensor_332 = torch.ops.aten.mul.Tensor(to_dtype_150, mul_tensor_331);  to_dtype_150 = None
        rsub_scalar_40 = torch.ops.aten.rsub.Scalar(mul_tensor_331, 1);  mul_tensor_331 = None
        mul_tensor_333 = torch.ops.aten.mul.Tensor(to_dtype_151, rsub_scalar_40);  to_dtype_151 = rsub_scalar_40 = None
        add_tensor_309 = torch.ops.aten.add.Tensor(mul_tensor_333, 1);  mul_tensor_333 = None
        mul_tensor_334 = torch.ops.aten.mul.Tensor(mul_tensor_332, add_tensor_309);  mul_tensor_332 = add_tensor_309 = None
        to_dtype_152 = torch.ops.aten.to.dtype(mul_tensor_334, torch.float32);  mul_tensor_334 = None
        unsqueeze_default_13 = torch.ops.aten.unsqueeze.default(to_dtype_152, 4);  to_dtype_152 = None
        expand_default_20 = torch.ops.aten.expand.default(unsqueeze_default_13, [1, 88, 20, 20, 3]);  unsqueeze_default_13 = None
        unbind_int_10 = torch.ops.aten.unbind.int(expand_default_20, -1);  expand_default_20 = None
        getitem_899 = unbind_int_10[0]
        getitem_900 = unbind_int_10[1]
        getitem_901 = unbind_int_10[2];  unbind_int_10 = None
        neg_default_65 = torch.ops.aten.neg.default(getitem_901)
        div_tensor_148 = torch.ops.aten.div.Tensor(mul_tensor_74, add_tensor_51);  mul_tensor_74 = None
        div_tensor_149 = torch.ops.aten.div.Tensor(div_tensor_148, add_tensor_51);  div_tensor_148 = None
        mul_tensor_335 = torch.ops.aten.mul.Tensor(neg_default_65, div_tensor_149);  neg_default_65 = div_tensor_149 = None
        div_tensor_150 = torch.ops.aten.div.Tensor(getitem_901, add_tensor_51);  getitem_901 = add_tensor_51 = None
        sum_default_80 = torch.ops.aten.sum.default(mul_tensor_335);  mul_tensor_335 = None
        mul_tensor_336 = torch.ops.aten.mul.Tensor(div_tensor_150, getitem_307);  getitem_307 = None
        mul_tensor_337 = torch.ops.aten.mul.Tensor(div_tensor_150, select_int_51);  div_tensor_150 = select_int_51 = None
        sum_default_81 = torch.ops.aten.sum.default(mul_tensor_336);  mul_tensor_336 = None
        select_backward_default_24 = torch.ops.aten.select_backward.default(sum_default_81, [3], 0, 2);  sum_default_81 = None
        neg_default_66 = torch.ops.aten.neg.default(getitem_900)
        div_tensor_151 = torch.ops.aten.div.Tensor(mul_tensor_73, add_tensor_50);  mul_tensor_73 = None
        div_tensor_152 = torch.ops.aten.div.Tensor(div_tensor_151, add_tensor_50);  div_tensor_151 = None
        mul_tensor_338 = torch.ops.aten.mul.Tensor(neg_default_66, div_tensor_152);  neg_default_66 = div_tensor_152 = None
        div_tensor_153 = torch.ops.aten.div.Tensor(getitem_900, add_tensor_50);  getitem_900 = add_tensor_50 = None
        sum_default_82 = torch.ops.aten.sum.default(mul_tensor_338);  mul_tensor_338 = None
        add_tensor_310 = torch.ops.aten.add.Tensor(sum_default_80, sum_default_82);  sum_default_80 = sum_default_82 = None
        mul_tensor_339 = torch.ops.aten.mul.Tensor(div_tensor_153, getitem_293);  getitem_293 = None
        mul_tensor_340 = torch.ops.aten.mul.Tensor(div_tensor_153, select_int_50);  div_tensor_153 = select_int_50 = None
        sum_default_83 = torch.ops.aten.sum.default(mul_tensor_339);  mul_tensor_339 = None
        select_backward_default_25 = torch.ops.aten.select_backward.default(sum_default_83, [3], 0, 1);  sum_default_83 = None
        add_tensor_311 = torch.ops.aten.add.Tensor(select_backward_default_24, select_backward_default_25);  select_backward_default_24 = select_backward_default_25 = None
        neg_default_67 = torch.ops.aten.neg.default(getitem_899)
        div_tensor_154 = torch.ops.aten.div.Tensor(mul_tensor_72, add_tensor_49);  mul_tensor_72 = None
        div_tensor_155 = torch.ops.aten.div.Tensor(div_tensor_154, add_tensor_49);  div_tensor_154 = None
        mul_tensor_341 = torch.ops.aten.mul.Tensor(neg_default_67, div_tensor_155);  neg_default_67 = div_tensor_155 = None
        div_tensor_156 = torch.ops.aten.div.Tensor(getitem_899, add_tensor_49);  getitem_899 = add_tensor_49 = None
        sum_default_84 = torch.ops.aten.sum.default(mul_tensor_341);  mul_tensor_341 = None
        add_tensor_312 = torch.ops.aten.add.Tensor(add_tensor_310, sum_default_84);  add_tensor_310 = sum_default_84 = None
        mul_tensor_342 = torch.ops.aten.mul.Tensor(div_tensor_156, getitem_277)
        mul_tensor_343 = torch.ops.aten.mul.Tensor(div_tensor_156, select_int_49);  div_tensor_156 = select_int_49 = None
        sum_default_85 = torch.ops.aten.sum.default(mul_tensor_342);  mul_tensor_342 = None
        select_backward_default_26 = torch.ops.aten.select_backward.default(sum_default_85, [3], 0, 0);  sum_default_85 = None
        add_tensor_313 = torch.ops.aten.add.Tensor(add_tensor_311, select_backward_default_26);  add_tensor_311 = select_backward_default_26 = None
        expand_default_21 = torch.ops.aten.expand.default(add_tensor_312, [3]);  add_tensor_312 = None
        add_tensor_314 = torch.ops.aten.add.Tensor(add_tensor_313, expand_default_21);  add_tensor_313 = expand_default_21 = None
        to_dtype_153 = torch.ops.aten.to.dtype(add_tensor_314, torch.float32);  add_tensor_314 = None
        to_dtype_154 = torch.ops.aten.to.dtype(relu_default_21, torch.float32);  relu_default_21 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_154, 0);  to_dtype_154 = None
        new_zeros_default_418 = torch.ops.aten.new_zeros.default(to_dtype_153, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_418, to_dtype_153);  le_scalar_10 = new_zeros_default_418 = to_dtype_153 = None
        to_dtype_155 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        max_pool2d_with_indices_backward_default_6 = torch.ops.aten.max_pool2d_with_indices_backward.default(mul_tensor_337, constant_pad_nd_default_16, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_308);  mul_tensor_337 = constant_pad_nd_default_16 = getitem_308 = None
        constant_pad_nd_default_29 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default_6, [0, -1, 0, -1]);  max_pool2d_with_indices_backward_default_6 = None
        add_tensor_315 = torch.ops.aten.add.Tensor(add_tensor_276, constant_pad_nd_default_29);  add_tensor_276 = constant_pad_nd_default_29 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_315, convolution_default_161, primals_744, primals_742, primals_743, new_zeros_default_282, new_zeros_default_283, False, 0.001, [True, True, True]);  add_tensor_315 = convolution_default_161 = primals_744 = primals_742 = primals_743 = new_zeros_default_282 = new_zeros_default_283 = None
        getitem_902 = native_batch_norm_backward_default_41[0]
        getitem_903 = native_batch_norm_backward_default_41[1]
        getitem_904 = native_batch_norm_backward_default_41[2];  native_batch_norm_backward_default_41 = None
        convolution_backward_default_102 = torch.ops.aten.convolution_backward.default(getitem_902, convolution_default_160, primals_747, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_902 = convolution_default_160 = primals_747 = None
        getitem_905 = convolution_backward_default_102[0]
        getitem_906 = convolution_backward_default_102[1]
        getitem_907 = convolution_backward_default_102[2];  convolution_backward_default_102 = None
        convolution_backward_default_103 = torch.ops.aten.convolution_backward.default(getitem_905, silu__default_88, primals_745, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_905 = silu__default_88 = primals_745 = None
        getitem_908 = convolution_backward_default_103[0]
        getitem_909 = convolution_backward_default_103[1]
        getitem_910 = convolution_backward_default_103[2];  convolution_backward_default_103 = None
        to_dtype_156 = torch.ops.aten.to.dtype(getitem_908, torch.float32);  getitem_908 = None
        to_dtype_157 = torch.ops.aten.to.dtype(clone_default_88, torch.float32);  clone_default_88 = None
        neg_default_68 = torch.ops.aten.neg.default(to_dtype_157)
        exp_default_41 = torch.ops.aten.exp.default(neg_default_68);  neg_default_68 = None
        add_tensor_316 = torch.ops.aten.add.Tensor(exp_default_41, 1);  exp_default_41 = None
        reciprocal_default_41 = torch.ops.aten.reciprocal.default(add_tensor_316);  add_tensor_316 = None
        mul_tensor_344 = torch.ops.aten.mul.Tensor(reciprocal_default_41, 1);  reciprocal_default_41 = None
        mul_tensor_345 = torch.ops.aten.mul.Tensor(to_dtype_156, mul_tensor_344);  to_dtype_156 = None
        rsub_scalar_41 = torch.ops.aten.rsub.Scalar(mul_tensor_344, 1);  mul_tensor_344 = None
        mul_tensor_346 = torch.ops.aten.mul.Tensor(to_dtype_157, rsub_scalar_41);  to_dtype_157 = rsub_scalar_41 = None
        add_tensor_317 = torch.ops.aten.add.Tensor(mul_tensor_346, 1);  mul_tensor_346 = None
        mul_tensor_347 = torch.ops.aten.mul.Tensor(mul_tensor_345, add_tensor_317);  mul_tensor_345 = add_tensor_317 = None
        to_dtype_158 = torch.ops.aten.to.dtype(mul_tensor_347, torch.float32);  mul_tensor_347 = None
        unsqueeze_default_14 = torch.ops.aten.unsqueeze.default(to_dtype_158, 4);  to_dtype_158 = None
        expand_default_22 = torch.ops.aten.expand.default(unsqueeze_default_14, [1, 88, 40, 40, 3]);  unsqueeze_default_14 = None
        unbind_int_11 = torch.ops.aten.unbind.int(expand_default_22, -1);  expand_default_22 = None
        getitem_911 = unbind_int_11[0]
        getitem_912 = unbind_int_11[1]
        getitem_913 = unbind_int_11[2];  unbind_int_11 = None
        neg_default_69 = torch.ops.aten.neg.default(getitem_913)
        div_tensor_157 = torch.ops.aten.div.Tensor(mul_tensor_71, add_tensor_48);  mul_tensor_71 = None
        div_tensor_158 = torch.ops.aten.div.Tensor(div_tensor_157, add_tensor_48);  div_tensor_157 = None
        mul_tensor_348 = torch.ops.aten.mul.Tensor(neg_default_69, div_tensor_158);  neg_default_69 = div_tensor_158 = None
        div_tensor_159 = torch.ops.aten.div.Tensor(getitem_913, add_tensor_48);  getitem_913 = add_tensor_48 = None
        sum_default_86 = torch.ops.aten.sum.default(mul_tensor_348);  mul_tensor_348 = None
        mul_tensor_349 = torch.ops.aten.mul.Tensor(div_tensor_159, getitem_302);  getitem_302 = None
        mul_tensor_350 = torch.ops.aten.mul.Tensor(div_tensor_159, select_int_48);  div_tensor_159 = select_int_48 = None
        sum_default_87 = torch.ops.aten.sum.default(mul_tensor_349);  mul_tensor_349 = None
        select_backward_default_27 = torch.ops.aten.select_backward.default(sum_default_87, [3], 0, 2);  sum_default_87 = None
        neg_default_70 = torch.ops.aten.neg.default(getitem_912)
        div_tensor_160 = torch.ops.aten.div.Tensor(mul_tensor_70, add_tensor_47);  mul_tensor_70 = None
        div_tensor_161 = torch.ops.aten.div.Tensor(div_tensor_160, add_tensor_47);  div_tensor_160 = None
        mul_tensor_351 = torch.ops.aten.mul.Tensor(neg_default_70, div_tensor_161);  neg_default_70 = div_tensor_161 = None
        div_tensor_162 = torch.ops.aten.div.Tensor(getitem_912, add_tensor_47);  getitem_912 = add_tensor_47 = None
        sum_default_88 = torch.ops.aten.sum.default(mul_tensor_351);  mul_tensor_351 = None
        add_tensor_318 = torch.ops.aten.add.Tensor(sum_default_86, sum_default_88);  sum_default_86 = sum_default_88 = None
        mul_tensor_352 = torch.ops.aten.mul.Tensor(div_tensor_162, getitem_296);  getitem_296 = None
        mul_tensor_353 = torch.ops.aten.mul.Tensor(div_tensor_162, select_int_47);  div_tensor_162 = select_int_47 = None
        sum_default_89 = torch.ops.aten.sum.default(mul_tensor_352);  mul_tensor_352 = None
        select_backward_default_28 = torch.ops.aten.select_backward.default(sum_default_89, [3], 0, 1);  sum_default_89 = None
        add_tensor_319 = torch.ops.aten.add.Tensor(select_backward_default_27, select_backward_default_28);  select_backward_default_27 = select_backward_default_28 = None
        neg_default_71 = torch.ops.aten.neg.default(getitem_911)
        div_tensor_163 = torch.ops.aten.div.Tensor(mul_tensor_69, add_tensor_46);  mul_tensor_69 = None
        div_tensor_164 = torch.ops.aten.div.Tensor(div_tensor_163, add_tensor_46);  div_tensor_163 = None
        mul_tensor_354 = torch.ops.aten.mul.Tensor(neg_default_71, div_tensor_164);  neg_default_71 = div_tensor_164 = None
        div_tensor_165 = torch.ops.aten.div.Tensor(getitem_911, add_tensor_46);  getitem_911 = add_tensor_46 = None
        sum_default_90 = torch.ops.aten.sum.default(mul_tensor_354);  mul_tensor_354 = None
        add_tensor_320 = torch.ops.aten.add.Tensor(add_tensor_318, sum_default_90);  add_tensor_318 = sum_default_90 = None
        mul_tensor_355 = torch.ops.aten.mul.Tensor(div_tensor_165, getitem_272)
        mul_tensor_356 = torch.ops.aten.mul.Tensor(div_tensor_165, select_int_46);  div_tensor_165 = select_int_46 = None
        sum_default_91 = torch.ops.aten.sum.default(mul_tensor_355);  mul_tensor_355 = None
        select_backward_default_29 = torch.ops.aten.select_backward.default(sum_default_91, [3], 0, 0);  sum_default_91 = None
        add_tensor_321 = torch.ops.aten.add.Tensor(add_tensor_319, select_backward_default_29);  add_tensor_319 = select_backward_default_29 = None
        expand_default_23 = torch.ops.aten.expand.default(add_tensor_320, [3]);  add_tensor_320 = None
        add_tensor_322 = torch.ops.aten.add.Tensor(add_tensor_321, expand_default_23);  add_tensor_321 = expand_default_23 = None
        to_dtype_159 = torch.ops.aten.to.dtype(add_tensor_322, torch.float32);  add_tensor_322 = None
        to_dtype_160 = torch.ops.aten.to.dtype(relu_default_20, torch.float32);  relu_default_20 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_160, 0);  to_dtype_160 = None
        new_zeros_default_419 = torch.ops.aten.new_zeros.default(to_dtype_159, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_419, to_dtype_159);  le_scalar_11 = new_zeros_default_419 = to_dtype_159 = None
        to_dtype_161 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        max_pool2d_with_indices_backward_default_7 = torch.ops.aten.max_pool2d_with_indices_backward.default(mul_tensor_350, constant_pad_nd_default_15, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_303);  mul_tensor_350 = constant_pad_nd_default_15 = getitem_303 = None
        constant_pad_nd_default_30 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default_7, [0, -1, 0, -1]);  max_pool2d_with_indices_backward_default_7 = None
        add_tensor_323 = torch.ops.aten.add.Tensor(mul_tensor_277, constant_pad_nd_default_30);  mul_tensor_277 = constant_pad_nd_default_30 = None
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_323, convolution_default_159, primals_735, primals_733, primals_734, new_zeros_default_279, new_zeros_default_280, False, 0.001, [True, True, True]);  add_tensor_323 = convolution_default_159 = primals_735 = primals_733 = primals_734 = new_zeros_default_279 = new_zeros_default_280 = None
        getitem_914 = native_batch_norm_backward_default_42[0]
        getitem_915 = native_batch_norm_backward_default_42[1]
        getitem_916 = native_batch_norm_backward_default_42[2];  native_batch_norm_backward_default_42 = None
        convolution_backward_default_104 = torch.ops.aten.convolution_backward.default(getitem_914, convolution_default_158, primals_738, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_914 = convolution_default_158 = primals_738 = None
        getitem_917 = convolution_backward_default_104[0]
        getitem_918 = convolution_backward_default_104[1]
        getitem_919 = convolution_backward_default_104[2];  convolution_backward_default_104 = None
        convolution_backward_default_105 = torch.ops.aten.convolution_backward.default(getitem_917, silu__default_87, primals_736, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_917 = silu__default_87 = primals_736 = None
        getitem_920 = convolution_backward_default_105[0]
        getitem_921 = convolution_backward_default_105[1]
        getitem_922 = convolution_backward_default_105[2];  convolution_backward_default_105 = None
        to_dtype_162 = torch.ops.aten.to.dtype(getitem_920, torch.float32);  getitem_920 = None
        to_dtype_163 = torch.ops.aten.to.dtype(clone_default_87, torch.float32);  clone_default_87 = None
        neg_default_72 = torch.ops.aten.neg.default(to_dtype_163)
        exp_default_42 = torch.ops.aten.exp.default(neg_default_72);  neg_default_72 = None
        add_tensor_324 = torch.ops.aten.add.Tensor(exp_default_42, 1);  exp_default_42 = None
        reciprocal_default_42 = torch.ops.aten.reciprocal.default(add_tensor_324);  add_tensor_324 = None
        mul_tensor_357 = torch.ops.aten.mul.Tensor(reciprocal_default_42, 1);  reciprocal_default_42 = None
        mul_tensor_358 = torch.ops.aten.mul.Tensor(to_dtype_162, mul_tensor_357);  to_dtype_162 = None
        rsub_scalar_42 = torch.ops.aten.rsub.Scalar(mul_tensor_357, 1);  mul_tensor_357 = None
        mul_tensor_359 = torch.ops.aten.mul.Tensor(to_dtype_163, rsub_scalar_42);  to_dtype_163 = rsub_scalar_42 = None
        add_tensor_325 = torch.ops.aten.add.Tensor(mul_tensor_359, 1);  mul_tensor_359 = None
        mul_tensor_360 = torch.ops.aten.mul.Tensor(mul_tensor_358, add_tensor_325);  mul_tensor_358 = add_tensor_325 = None
        to_dtype_164 = torch.ops.aten.to.dtype(mul_tensor_360, torch.float32);  mul_tensor_360 = None
        unsqueeze_default_15 = torch.ops.aten.unsqueeze.default(to_dtype_164, 4);  to_dtype_164 = None
        expand_default_24 = torch.ops.aten.expand.default(unsqueeze_default_15, [1, 88, 80, 80, 2]);  unsqueeze_default_15 = None
        unbind_int_12 = torch.ops.aten.unbind.int(expand_default_24, -1);  expand_default_24 = None
        getitem_923 = unbind_int_12[0]
        getitem_924 = unbind_int_12[1];  unbind_int_12 = None
        neg_default_73 = torch.ops.aten.neg.default(getitem_924)
        div_tensor_166 = torch.ops.aten.div.Tensor(mul_tensor_68, add_tensor_45);  mul_tensor_68 = None
        div_tensor_167 = torch.ops.aten.div.Tensor(div_tensor_166, add_tensor_45);  div_tensor_166 = None
        mul_tensor_361 = torch.ops.aten.mul.Tensor(neg_default_73, div_tensor_167);  neg_default_73 = div_tensor_167 = None
        div_tensor_168 = torch.ops.aten.div.Tensor(getitem_924, add_tensor_45);  getitem_924 = add_tensor_45 = None
        sum_default_92 = torch.ops.aten.sum.default(mul_tensor_361);  mul_tensor_361 = None
        mul_tensor_362 = torch.ops.aten.mul.Tensor(div_tensor_168, upsample_nearest2d_vec_11);  upsample_nearest2d_vec_11 = None
        mul_tensor_363 = torch.ops.aten.mul.Tensor(div_tensor_168, select_int_45);  div_tensor_168 = select_int_45 = None
        sum_default_93 = torch.ops.aten.sum.default(mul_tensor_362);  mul_tensor_362 = None
        select_backward_default_30 = torch.ops.aten.select_backward.default(sum_default_93, [2], 0, 1);  sum_default_93 = None
        neg_default_74 = torch.ops.aten.neg.default(getitem_923)
        div_tensor_169 = torch.ops.aten.div.Tensor(mul_tensor_67, add_tensor_44);  mul_tensor_67 = None
        div_tensor_170 = torch.ops.aten.div.Tensor(div_tensor_169, add_tensor_44);  div_tensor_169 = None
        mul_tensor_364 = torch.ops.aten.mul.Tensor(neg_default_74, div_tensor_170);  neg_default_74 = div_tensor_170 = None
        div_tensor_171 = torch.ops.aten.div.Tensor(getitem_923, add_tensor_44);  getitem_923 = add_tensor_44 = None
        sum_default_94 = torch.ops.aten.sum.default(mul_tensor_364);  mul_tensor_364 = None
        add_tensor_326 = torch.ops.aten.add.Tensor(sum_default_92, sum_default_94);  sum_default_92 = sum_default_94 = None
        mul_tensor_365 = torch.ops.aten.mul.Tensor(div_tensor_171, getitem_267);  getitem_267 = None
        mul_tensor_366 = torch.ops.aten.mul.Tensor(div_tensor_171, select_int_44);  div_tensor_171 = select_int_44 = None
        sum_default_95 = torch.ops.aten.sum.default(mul_tensor_365);  mul_tensor_365 = None
        select_backward_default_31 = torch.ops.aten.select_backward.default(sum_default_95, [2], 0, 0);  sum_default_95 = None
        add_tensor_327 = torch.ops.aten.add.Tensor(select_backward_default_30, select_backward_default_31);  select_backward_default_30 = select_backward_default_31 = None
        expand_default_25 = torch.ops.aten.expand.default(add_tensor_326, [2]);  add_tensor_326 = None
        add_tensor_328 = torch.ops.aten.add.Tensor(add_tensor_327, expand_default_25);  add_tensor_327 = expand_default_25 = None
        to_dtype_165 = torch.ops.aten.to.dtype(add_tensor_328, torch.float32);  add_tensor_328 = None
        to_dtype_166 = torch.ops.aten.to.dtype(relu_default_19, torch.float32);  relu_default_19 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_166, 0);  to_dtype_166 = None
        new_zeros_default_420 = torch.ops.aten.new_zeros.default(to_dtype_165, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_420, to_dtype_165);  le_scalar_12 = new_zeros_default_420 = to_dtype_165 = None
        to_dtype_167 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        upsample_nearest2d_backward_vec_4 = torch.ops.aten.upsample_nearest2d_backward.vec(mul_tensor_363, [80, 80], [1, 88, 40, 40], None);  mul_tensor_363 = None
        add_tensor_329 = torch.ops.aten.add.Tensor(mul_tensor_353, upsample_nearest2d_backward_vec_4);  mul_tensor_353 = upsample_nearest2d_backward_vec_4 = None
        native_batch_norm_backward_default_43 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_329, convolution_default_157, primals_726, primals_724, primals_725, new_zeros_default_276, new_zeros_default_277, False, 0.001, [True, True, True]);  add_tensor_329 = convolution_default_157 = primals_726 = primals_724 = primals_725 = new_zeros_default_276 = new_zeros_default_277 = None
        getitem_925 = native_batch_norm_backward_default_43[0]
        getitem_926 = native_batch_norm_backward_default_43[1]
        getitem_927 = native_batch_norm_backward_default_43[2];  native_batch_norm_backward_default_43 = None
        convolution_backward_default_106 = torch.ops.aten.convolution_backward.default(getitem_925, convolution_default_156, primals_729, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_925 = convolution_default_156 = primals_729 = None
        getitem_928 = convolution_backward_default_106[0]
        getitem_929 = convolution_backward_default_106[1]
        getitem_930 = convolution_backward_default_106[2];  convolution_backward_default_106 = None
        convolution_backward_default_107 = torch.ops.aten.convolution_backward.default(getitem_928, silu__default_86, primals_727, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_928 = silu__default_86 = primals_727 = None
        getitem_931 = convolution_backward_default_107[0]
        getitem_932 = convolution_backward_default_107[1]
        getitem_933 = convolution_backward_default_107[2];  convolution_backward_default_107 = None
        to_dtype_168 = torch.ops.aten.to.dtype(getitem_931, torch.float32);  getitem_931 = None
        to_dtype_169 = torch.ops.aten.to.dtype(clone_default_86, torch.float32);  clone_default_86 = None
        neg_default_75 = torch.ops.aten.neg.default(to_dtype_169)
        exp_default_43 = torch.ops.aten.exp.default(neg_default_75);  neg_default_75 = None
        add_tensor_330 = torch.ops.aten.add.Tensor(exp_default_43, 1);  exp_default_43 = None
        reciprocal_default_43 = torch.ops.aten.reciprocal.default(add_tensor_330);  add_tensor_330 = None
        mul_tensor_367 = torch.ops.aten.mul.Tensor(reciprocal_default_43, 1);  reciprocal_default_43 = None
        mul_tensor_368 = torch.ops.aten.mul.Tensor(to_dtype_168, mul_tensor_367);  to_dtype_168 = None
        rsub_scalar_43 = torch.ops.aten.rsub.Scalar(mul_tensor_367, 1);  mul_tensor_367 = None
        mul_tensor_369 = torch.ops.aten.mul.Tensor(to_dtype_169, rsub_scalar_43);  to_dtype_169 = rsub_scalar_43 = None
        add_tensor_331 = torch.ops.aten.add.Tensor(mul_tensor_369, 1);  mul_tensor_369 = None
        mul_tensor_370 = torch.ops.aten.mul.Tensor(mul_tensor_368, add_tensor_331);  mul_tensor_368 = add_tensor_331 = None
        to_dtype_170 = torch.ops.aten.to.dtype(mul_tensor_370, torch.float32);  mul_tensor_370 = None
        unsqueeze_default_16 = torch.ops.aten.unsqueeze.default(to_dtype_170, 4);  to_dtype_170 = None
        expand_default_26 = torch.ops.aten.expand.default(unsqueeze_default_16, [1, 88, 40, 40, 2]);  unsqueeze_default_16 = None
        unbind_int_13 = torch.ops.aten.unbind.int(expand_default_26, -1);  expand_default_26 = None
        getitem_934 = unbind_int_13[0]
        getitem_935 = unbind_int_13[1];  unbind_int_13 = None
        neg_default_76 = torch.ops.aten.neg.default(getitem_935)
        div_tensor_172 = torch.ops.aten.div.Tensor(mul_tensor_66, add_tensor_43);  mul_tensor_66 = None
        div_tensor_173 = torch.ops.aten.div.Tensor(div_tensor_172, add_tensor_43);  div_tensor_172 = None
        mul_tensor_371 = torch.ops.aten.mul.Tensor(neg_default_76, div_tensor_173);  neg_default_76 = div_tensor_173 = None
        div_tensor_174 = torch.ops.aten.div.Tensor(getitem_935, add_tensor_43);  getitem_935 = add_tensor_43 = None
        sum_default_96 = torch.ops.aten.sum.default(mul_tensor_371);  mul_tensor_371 = None
        mul_tensor_372 = torch.ops.aten.mul.Tensor(div_tensor_174, upsample_nearest2d_vec_10);  upsample_nearest2d_vec_10 = None
        mul_tensor_373 = torch.ops.aten.mul.Tensor(div_tensor_174, select_int_43);  div_tensor_174 = select_int_43 = None
        sum_default_97 = torch.ops.aten.sum.default(mul_tensor_372);  mul_tensor_372 = None
        select_backward_default_32 = torch.ops.aten.select_backward.default(sum_default_97, [2], 0, 1);  sum_default_97 = None
        neg_default_77 = torch.ops.aten.neg.default(getitem_934)
        div_tensor_175 = torch.ops.aten.div.Tensor(mul_tensor_65, add_tensor_42);  mul_tensor_65 = None
        div_tensor_176 = torch.ops.aten.div.Tensor(div_tensor_175, add_tensor_42);  div_tensor_175 = None
        mul_tensor_374 = torch.ops.aten.mul.Tensor(neg_default_77, div_tensor_176);  neg_default_77 = div_tensor_176 = None
        div_tensor_177 = torch.ops.aten.div.Tensor(getitem_934, add_tensor_42);  getitem_934 = add_tensor_42 = None
        sum_default_98 = torch.ops.aten.sum.default(mul_tensor_374);  mul_tensor_374 = None
        add_tensor_332 = torch.ops.aten.add.Tensor(sum_default_96, sum_default_98);  sum_default_96 = sum_default_98 = None
        mul_tensor_375 = torch.ops.aten.mul.Tensor(div_tensor_177, getitem_272);  getitem_272 = None
        mul_tensor_376 = torch.ops.aten.mul.Tensor(div_tensor_177, select_int_42);  div_tensor_177 = select_int_42 = None
        sum_default_99 = torch.ops.aten.sum.default(mul_tensor_375);  mul_tensor_375 = None
        add_tensor_333 = torch.ops.aten.add.Tensor(mul_tensor_356, mul_tensor_376);  mul_tensor_356 = mul_tensor_376 = None
        select_backward_default_33 = torch.ops.aten.select_backward.default(sum_default_99, [2], 0, 0);  sum_default_99 = None
        add_tensor_334 = torch.ops.aten.add.Tensor(select_backward_default_32, select_backward_default_33);  select_backward_default_32 = select_backward_default_33 = None
        expand_default_27 = torch.ops.aten.expand.default(add_tensor_332, [2]);  add_tensor_332 = None
        add_tensor_335 = torch.ops.aten.add.Tensor(add_tensor_334, expand_default_27);  add_tensor_334 = expand_default_27 = None
        to_dtype_171 = torch.ops.aten.to.dtype(add_tensor_335, torch.float32);  add_tensor_335 = None
        to_dtype_172 = torch.ops.aten.to.dtype(relu_default_18, torch.float32);  relu_default_18 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_172, 0);  to_dtype_172 = None
        new_zeros_default_421 = torch.ops.aten.new_zeros.default(to_dtype_171, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_421, to_dtype_171);  le_scalar_13 = new_zeros_default_421 = to_dtype_171 = None
        to_dtype_173 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        upsample_nearest2d_backward_vec_5 = torch.ops.aten.upsample_nearest2d_backward.vec(mul_tensor_373, [40, 40], [1, 88, 20, 20], None);  mul_tensor_373 = None
        add_tensor_336 = torch.ops.aten.add.Tensor(mul_tensor_340, upsample_nearest2d_backward_vec_5);  mul_tensor_340 = upsample_nearest2d_backward_vec_5 = None
        native_batch_norm_backward_default_44 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_336, convolution_default_155, primals_717, primals_715, primals_716, new_zeros_default_273, new_zeros_default_274, False, 0.001, [True, True, True]);  add_tensor_336 = convolution_default_155 = primals_717 = primals_715 = primals_716 = new_zeros_default_273 = new_zeros_default_274 = None
        getitem_936 = native_batch_norm_backward_default_44[0]
        getitem_937 = native_batch_norm_backward_default_44[1]
        getitem_938 = native_batch_norm_backward_default_44[2];  native_batch_norm_backward_default_44 = None
        convolution_backward_default_108 = torch.ops.aten.convolution_backward.default(getitem_936, convolution_default_154, primals_720, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_936 = convolution_default_154 = primals_720 = None
        getitem_939 = convolution_backward_default_108[0]
        getitem_940 = convolution_backward_default_108[1]
        getitem_941 = convolution_backward_default_108[2];  convolution_backward_default_108 = None
        convolution_backward_default_109 = torch.ops.aten.convolution_backward.default(getitem_939, silu__default_85, primals_718, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_939 = silu__default_85 = primals_718 = None
        getitem_942 = convolution_backward_default_109[0]
        getitem_943 = convolution_backward_default_109[1]
        getitem_944 = convolution_backward_default_109[2];  convolution_backward_default_109 = None
        to_dtype_174 = torch.ops.aten.to.dtype(getitem_942, torch.float32);  getitem_942 = None
        to_dtype_175 = torch.ops.aten.to.dtype(clone_default_85, torch.float32);  clone_default_85 = None
        neg_default_78 = torch.ops.aten.neg.default(to_dtype_175)
        exp_default_44 = torch.ops.aten.exp.default(neg_default_78);  neg_default_78 = None
        add_tensor_337 = torch.ops.aten.add.Tensor(exp_default_44, 1);  exp_default_44 = None
        reciprocal_default_44 = torch.ops.aten.reciprocal.default(add_tensor_337);  add_tensor_337 = None
        mul_tensor_377 = torch.ops.aten.mul.Tensor(reciprocal_default_44, 1);  reciprocal_default_44 = None
        mul_tensor_378 = torch.ops.aten.mul.Tensor(to_dtype_174, mul_tensor_377);  to_dtype_174 = None
        rsub_scalar_44 = torch.ops.aten.rsub.Scalar(mul_tensor_377, 1);  mul_tensor_377 = None
        mul_tensor_379 = torch.ops.aten.mul.Tensor(to_dtype_175, rsub_scalar_44);  to_dtype_175 = rsub_scalar_44 = None
        add_tensor_338 = torch.ops.aten.add.Tensor(mul_tensor_379, 1);  mul_tensor_379 = None
        mul_tensor_380 = torch.ops.aten.mul.Tensor(mul_tensor_378, add_tensor_338);  mul_tensor_378 = add_tensor_338 = None
        to_dtype_176 = torch.ops.aten.to.dtype(mul_tensor_380, torch.float32);  mul_tensor_380 = None
        unsqueeze_default_17 = torch.ops.aten.unsqueeze.default(to_dtype_176, 4);  to_dtype_176 = None
        expand_default_28 = torch.ops.aten.expand.default(unsqueeze_default_17, [1, 88, 20, 20, 2]);  unsqueeze_default_17 = None
        unbind_int_14 = torch.ops.aten.unbind.int(expand_default_28, -1);  expand_default_28 = None
        getitem_945 = unbind_int_14[0]
        getitem_946 = unbind_int_14[1];  unbind_int_14 = None
        neg_default_79 = torch.ops.aten.neg.default(getitem_946)
        div_tensor_178 = torch.ops.aten.div.Tensor(mul_tensor_64, add_tensor_41);  mul_tensor_64 = None
        div_tensor_179 = torch.ops.aten.div.Tensor(div_tensor_178, add_tensor_41);  div_tensor_178 = None
        mul_tensor_381 = torch.ops.aten.mul.Tensor(neg_default_79, div_tensor_179);  neg_default_79 = div_tensor_179 = None
        div_tensor_180 = torch.ops.aten.div.Tensor(getitem_946, add_tensor_41);  getitem_946 = add_tensor_41 = None
        sum_default_100 = torch.ops.aten.sum.default(mul_tensor_381);  mul_tensor_381 = None
        mul_tensor_382 = torch.ops.aten.mul.Tensor(div_tensor_180, upsample_nearest2d_vec_9);  upsample_nearest2d_vec_9 = None
        mul_tensor_383 = torch.ops.aten.mul.Tensor(div_tensor_180, select_int_41);  div_tensor_180 = select_int_41 = None
        sum_default_101 = torch.ops.aten.sum.default(mul_tensor_382);  mul_tensor_382 = None
        select_backward_default_34 = torch.ops.aten.select_backward.default(sum_default_101, [2], 0, 1);  sum_default_101 = None
        neg_default_80 = torch.ops.aten.neg.default(getitem_945)
        div_tensor_181 = torch.ops.aten.div.Tensor(mul_tensor_63, add_tensor_40);  mul_tensor_63 = None
        div_tensor_182 = torch.ops.aten.div.Tensor(div_tensor_181, add_tensor_40);  div_tensor_181 = None
        mul_tensor_384 = torch.ops.aten.mul.Tensor(neg_default_80, div_tensor_182);  neg_default_80 = div_tensor_182 = None
        div_tensor_183 = torch.ops.aten.div.Tensor(getitem_945, add_tensor_40);  getitem_945 = add_tensor_40 = None
        sum_default_102 = torch.ops.aten.sum.default(mul_tensor_384);  mul_tensor_384 = None
        add_tensor_339 = torch.ops.aten.add.Tensor(sum_default_100, sum_default_102);  sum_default_100 = sum_default_102 = None
        mul_tensor_385 = torch.ops.aten.mul.Tensor(div_tensor_183, getitem_277);  getitem_277 = None
        mul_tensor_386 = torch.ops.aten.mul.Tensor(div_tensor_183, select_int_40);  div_tensor_183 = select_int_40 = None
        sum_default_103 = torch.ops.aten.sum.default(mul_tensor_385);  mul_tensor_385 = None
        add_tensor_340 = torch.ops.aten.add.Tensor(mul_tensor_343, mul_tensor_386);  mul_tensor_343 = mul_tensor_386 = None
        select_backward_default_35 = torch.ops.aten.select_backward.default(sum_default_103, [2], 0, 0);  sum_default_103 = None
        add_tensor_341 = torch.ops.aten.add.Tensor(select_backward_default_34, select_backward_default_35);  select_backward_default_34 = select_backward_default_35 = None
        expand_default_29 = torch.ops.aten.expand.default(add_tensor_339, [2]);  add_tensor_339 = None
        add_tensor_342 = torch.ops.aten.add.Tensor(add_tensor_341, expand_default_29);  add_tensor_341 = expand_default_29 = None
        to_dtype_177 = torch.ops.aten.to.dtype(add_tensor_342, torch.float32);  add_tensor_342 = None
        to_dtype_178 = torch.ops.aten.to.dtype(relu_default_17, torch.float32);  relu_default_17 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_178, 0);  to_dtype_178 = None
        new_zeros_default_422 = torch.ops.aten.new_zeros.default(to_dtype_177, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_422, to_dtype_177);  le_scalar_14 = new_zeros_default_422 = to_dtype_177 = None
        to_dtype_179 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        upsample_nearest2d_backward_vec_6 = torch.ops.aten.upsample_nearest2d_backward.vec(mul_tensor_383, [20, 20], [1, 88, 10, 10], None);  mul_tensor_383 = None
        add_tensor_343 = torch.ops.aten.add.Tensor(mul_tensor_327, upsample_nearest2d_backward_vec_6);  mul_tensor_327 = upsample_nearest2d_backward_vec_6 = None
        native_batch_norm_backward_default_45 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_343, convolution_default_153, primals_708, primals_706, primals_707, new_zeros_default_270, new_zeros_default_271, False, 0.001, [True, True, True]);  add_tensor_343 = convolution_default_153 = primals_708 = primals_706 = primals_707 = new_zeros_default_270 = new_zeros_default_271 = None
        getitem_947 = native_batch_norm_backward_default_45[0]
        getitem_948 = native_batch_norm_backward_default_45[1]
        getitem_949 = native_batch_norm_backward_default_45[2];  native_batch_norm_backward_default_45 = None
        convolution_backward_default_110 = torch.ops.aten.convolution_backward.default(getitem_947, convolution_default_152, primals_711, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_947 = convolution_default_152 = primals_711 = None
        getitem_950 = convolution_backward_default_110[0]
        getitem_951 = convolution_backward_default_110[1]
        getitem_952 = convolution_backward_default_110[2];  convolution_backward_default_110 = None
        convolution_backward_default_111 = torch.ops.aten.convolution_backward.default(getitem_950, silu__default_84, primals_709, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_950 = silu__default_84 = primals_709 = None
        getitem_953 = convolution_backward_default_111[0]
        getitem_954 = convolution_backward_default_111[1]
        getitem_955 = convolution_backward_default_111[2];  convolution_backward_default_111 = None
        to_dtype_180 = torch.ops.aten.to.dtype(getitem_953, torch.float32);  getitem_953 = None
        to_dtype_181 = torch.ops.aten.to.dtype(clone_default_84, torch.float32);  clone_default_84 = None
        neg_default_81 = torch.ops.aten.neg.default(to_dtype_181)
        exp_default_45 = torch.ops.aten.exp.default(neg_default_81);  neg_default_81 = None
        add_tensor_344 = torch.ops.aten.add.Tensor(exp_default_45, 1);  exp_default_45 = None
        reciprocal_default_45 = torch.ops.aten.reciprocal.default(add_tensor_344);  add_tensor_344 = None
        mul_tensor_387 = torch.ops.aten.mul.Tensor(reciprocal_default_45, 1);  reciprocal_default_45 = None
        mul_tensor_388 = torch.ops.aten.mul.Tensor(to_dtype_180, mul_tensor_387);  to_dtype_180 = None
        rsub_scalar_45 = torch.ops.aten.rsub.Scalar(mul_tensor_387, 1);  mul_tensor_387 = None
        mul_tensor_389 = torch.ops.aten.mul.Tensor(to_dtype_181, rsub_scalar_45);  to_dtype_181 = rsub_scalar_45 = None
        add_tensor_345 = torch.ops.aten.add.Tensor(mul_tensor_389, 1);  mul_tensor_389 = None
        mul_tensor_390 = torch.ops.aten.mul.Tensor(mul_tensor_388, add_tensor_345);  mul_tensor_388 = add_tensor_345 = None
        to_dtype_182 = torch.ops.aten.to.dtype(mul_tensor_390, torch.float32);  mul_tensor_390 = None
        unsqueeze_default_18 = torch.ops.aten.unsqueeze.default(to_dtype_182, 4);  to_dtype_182 = None
        expand_default_30 = torch.ops.aten.expand.default(unsqueeze_default_18, [1, 88, 10, 10, 2]);  unsqueeze_default_18 = None
        unbind_int_15 = torch.ops.aten.unbind.int(expand_default_30, -1);  expand_default_30 = None
        getitem_956 = unbind_int_15[0]
        getitem_957 = unbind_int_15[1];  unbind_int_15 = None
        neg_default_82 = torch.ops.aten.neg.default(getitem_957)
        div_tensor_184 = torch.ops.aten.div.Tensor(mul_tensor_62, add_tensor_39);  mul_tensor_62 = None
        div_tensor_185 = torch.ops.aten.div.Tensor(div_tensor_184, add_tensor_39);  div_tensor_184 = None
        mul_tensor_391 = torch.ops.aten.mul.Tensor(neg_default_82, div_tensor_185);  neg_default_82 = div_tensor_185 = None
        div_tensor_186 = torch.ops.aten.div.Tensor(getitem_957, add_tensor_39);  getitem_957 = add_tensor_39 = None
        sum_default_104 = torch.ops.aten.sum.default(mul_tensor_391);  mul_tensor_391 = None
        mul_tensor_392 = torch.ops.aten.mul.Tensor(div_tensor_186, upsample_nearest2d_vec_8);  upsample_nearest2d_vec_8 = None
        mul_tensor_393 = torch.ops.aten.mul.Tensor(div_tensor_186, select_int_39);  div_tensor_186 = select_int_39 = None
        sum_default_105 = torch.ops.aten.sum.default(mul_tensor_392);  mul_tensor_392 = None
        select_backward_default_36 = torch.ops.aten.select_backward.default(sum_default_105, [2], 0, 1);  sum_default_105 = None
        neg_default_83 = torch.ops.aten.neg.default(getitem_956)
        div_tensor_187 = torch.ops.aten.div.Tensor(mul_tensor_61, add_tensor_38);  mul_tensor_61 = None
        div_tensor_188 = torch.ops.aten.div.Tensor(div_tensor_187, add_tensor_38);  div_tensor_187 = None
        mul_tensor_394 = torch.ops.aten.mul.Tensor(neg_default_83, div_tensor_188);  neg_default_83 = div_tensor_188 = None
        div_tensor_189 = torch.ops.aten.div.Tensor(getitem_956, add_tensor_38);  getitem_956 = add_tensor_38 = None
        sum_default_106 = torch.ops.aten.sum.default(mul_tensor_394);  mul_tensor_394 = None
        add_tensor_346 = torch.ops.aten.add.Tensor(sum_default_104, sum_default_106);  sum_default_104 = sum_default_106 = None
        mul_tensor_395 = torch.ops.aten.mul.Tensor(div_tensor_189, getitem_282);  getitem_282 = None
        mul_tensor_396 = torch.ops.aten.mul.Tensor(div_tensor_189, select_int_38);  div_tensor_189 = select_int_38 = None
        sum_default_107 = torch.ops.aten.sum.default(mul_tensor_395);  mul_tensor_395 = None
        add_tensor_347 = torch.ops.aten.add.Tensor(mul_tensor_330, mul_tensor_396);  mul_tensor_330 = mul_tensor_396 = None
        select_backward_default_37 = torch.ops.aten.select_backward.default(sum_default_107, [2], 0, 0);  sum_default_107 = None
        add_tensor_348 = torch.ops.aten.add.Tensor(select_backward_default_36, select_backward_default_37);  select_backward_default_36 = select_backward_default_37 = None
        expand_default_31 = torch.ops.aten.expand.default(add_tensor_346, [2]);  add_tensor_346 = None
        add_tensor_349 = torch.ops.aten.add.Tensor(add_tensor_348, expand_default_31);  add_tensor_348 = expand_default_31 = None
        to_dtype_183 = torch.ops.aten.to.dtype(add_tensor_349, torch.float32);  add_tensor_349 = None
        to_dtype_184 = torch.ops.aten.to.dtype(relu_default_16, torch.float32);  relu_default_16 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_184, 0);  to_dtype_184 = None
        new_zeros_default_423 = torch.ops.aten.new_zeros.default(to_dtype_183, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_423, to_dtype_183);  le_scalar_15 = new_zeros_default_423 = to_dtype_183 = None
        to_dtype_185 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        upsample_nearest2d_backward_vec_7 = torch.ops.aten.upsample_nearest2d_backward.vec(mul_tensor_393, [10, 10], [1, 88, 5, 5], None);  mul_tensor_393 = None
        add_tensor_350 = torch.ops.aten.add.Tensor(mul_tensor_317, upsample_nearest2d_backward_vec_7);  mul_tensor_317 = upsample_nearest2d_backward_vec_7 = None
        native_batch_norm_backward_default_46 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_350, convolution_default_151, primals_699, primals_697, primals_698, new_zeros_default_267, new_zeros_default_268, False, 0.001, [True, True, True]);  add_tensor_350 = convolution_default_151 = primals_699 = primals_697 = primals_698 = new_zeros_default_267 = new_zeros_default_268 = None
        getitem_958 = native_batch_norm_backward_default_46[0]
        getitem_959 = native_batch_norm_backward_default_46[1]
        getitem_960 = native_batch_norm_backward_default_46[2];  native_batch_norm_backward_default_46 = None
        convolution_backward_default_112 = torch.ops.aten.convolution_backward.default(getitem_958, convolution_default_150, primals_702, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_958 = convolution_default_150 = primals_702 = None
        getitem_961 = convolution_backward_default_112[0]
        getitem_962 = convolution_backward_default_112[1]
        getitem_963 = convolution_backward_default_112[2];  convolution_backward_default_112 = None
        convolution_backward_default_113 = torch.ops.aten.convolution_backward.default(getitem_961, silu__default_83, primals_700, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_961 = silu__default_83 = primals_700 = None
        getitem_964 = convolution_backward_default_113[0]
        getitem_965 = convolution_backward_default_113[1]
        getitem_966 = convolution_backward_default_113[2];  convolution_backward_default_113 = None
        to_dtype_186 = torch.ops.aten.to.dtype(getitem_964, torch.float32);  getitem_964 = None
        to_dtype_187 = torch.ops.aten.to.dtype(clone_default_83, torch.float32);  clone_default_83 = None
        neg_default_84 = torch.ops.aten.neg.default(to_dtype_187)
        exp_default_46 = torch.ops.aten.exp.default(neg_default_84);  neg_default_84 = None
        add_tensor_351 = torch.ops.aten.add.Tensor(exp_default_46, 1);  exp_default_46 = None
        reciprocal_default_46 = torch.ops.aten.reciprocal.default(add_tensor_351);  add_tensor_351 = None
        mul_tensor_397 = torch.ops.aten.mul.Tensor(reciprocal_default_46, 1);  reciprocal_default_46 = None
        mul_tensor_398 = torch.ops.aten.mul.Tensor(to_dtype_186, mul_tensor_397);  to_dtype_186 = None
        rsub_scalar_46 = torch.ops.aten.rsub.Scalar(mul_tensor_397, 1);  mul_tensor_397 = None
        mul_tensor_399 = torch.ops.aten.mul.Tensor(to_dtype_187, rsub_scalar_46);  to_dtype_187 = rsub_scalar_46 = None
        add_tensor_352 = torch.ops.aten.add.Tensor(mul_tensor_399, 1);  mul_tensor_399 = None
        mul_tensor_400 = torch.ops.aten.mul.Tensor(mul_tensor_398, add_tensor_352);  mul_tensor_398 = add_tensor_352 = None
        to_dtype_188 = torch.ops.aten.to.dtype(mul_tensor_400, torch.float32);  mul_tensor_400 = None
        unsqueeze_default_19 = torch.ops.aten.unsqueeze.default(to_dtype_188, 4);  to_dtype_188 = None
        expand_default_32 = torch.ops.aten.expand.default(unsqueeze_default_19, [1, 88, 5, 5, 2]);  unsqueeze_default_19 = None
        unbind_int_16 = torch.ops.aten.unbind.int(expand_default_32, -1);  expand_default_32 = None
        getitem_967 = unbind_int_16[0]
        getitem_968 = unbind_int_16[1];  unbind_int_16 = None
        neg_default_85 = torch.ops.aten.neg.default(getitem_968)
        div_tensor_190 = torch.ops.aten.div.Tensor(mul_tensor_60, add_tensor_37);  mul_tensor_60 = None
        div_tensor_191 = torch.ops.aten.div.Tensor(div_tensor_190, add_tensor_37);  div_tensor_190 = None
        mul_tensor_401 = torch.ops.aten.mul.Tensor(neg_default_85, div_tensor_191);  neg_default_85 = div_tensor_191 = None
        div_tensor_192 = torch.ops.aten.div.Tensor(getitem_968, add_tensor_37);  getitem_968 = add_tensor_37 = None
        sum_default_108 = torch.ops.aten.sum.default(mul_tensor_401);  mul_tensor_401 = None
        mul_tensor_402 = torch.ops.aten.mul.Tensor(div_tensor_192, getitem_285);  getitem_285 = None
        mul_tensor_403 = torch.ops.aten.mul.Tensor(div_tensor_192, select_int_37);  div_tensor_192 = select_int_37 = None
        sum_default_109 = torch.ops.aten.sum.default(mul_tensor_402);  mul_tensor_402 = None
        select_backward_default_38 = torch.ops.aten.select_backward.default(sum_default_109, [2], 0, 1);  sum_default_109 = None
        neg_default_86 = torch.ops.aten.neg.default(getitem_967)
        div_tensor_193 = torch.ops.aten.div.Tensor(mul_tensor_59, add_tensor_36);  mul_tensor_59 = None
        div_tensor_194 = torch.ops.aten.div.Tensor(div_tensor_193, add_tensor_36);  div_tensor_193 = None
        mul_tensor_404 = torch.ops.aten.mul.Tensor(neg_default_86, div_tensor_194);  neg_default_86 = div_tensor_194 = None
        div_tensor_195 = torch.ops.aten.div.Tensor(getitem_967, add_tensor_36);  getitem_967 = add_tensor_36 = None
        sum_default_110 = torch.ops.aten.sum.default(mul_tensor_404);  mul_tensor_404 = None
        add_tensor_353 = torch.ops.aten.add.Tensor(sum_default_108, sum_default_110);  sum_default_108 = sum_default_110 = None
        mul_tensor_405 = torch.ops.aten.mul.Tensor(div_tensor_195, getitem_255);  getitem_255 = None
        mul_tensor_406 = torch.ops.aten.mul.Tensor(div_tensor_195, select_int_36);  div_tensor_195 = select_int_36 = None
        sum_default_111 = torch.ops.aten.sum.default(mul_tensor_405);  mul_tensor_405 = None
        select_backward_default_39 = torch.ops.aten.select_backward.default(sum_default_111, [2], 0, 0);  sum_default_111 = None
        add_tensor_354 = torch.ops.aten.add.Tensor(select_backward_default_38, select_backward_default_39);  select_backward_default_38 = select_backward_default_39 = None
        expand_default_33 = torch.ops.aten.expand.default(add_tensor_353, [2]);  add_tensor_353 = None
        add_tensor_355 = torch.ops.aten.add.Tensor(add_tensor_354, expand_default_33);  add_tensor_354 = expand_default_33 = None
        to_dtype_189 = torch.ops.aten.to.dtype(add_tensor_355, torch.float32);  add_tensor_355 = None
        to_dtype_190 = torch.ops.aten.to.dtype(relu_default_15, torch.float32);  relu_default_15 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_190, 0);  to_dtype_190 = None
        new_zeros_default_424 = torch.ops.aten.new_zeros.default(to_dtype_189, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_424, to_dtype_189);  le_scalar_16 = new_zeros_default_424 = to_dtype_189 = None
        to_dtype_191 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        max_pool2d_with_indices_backward_default_8 = torch.ops.aten.max_pool2d_with_indices_backward.default(mul_tensor_403, constant_pad_nd_default_14, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_286);  mul_tensor_403 = constant_pad_nd_default_14 = getitem_286 = None
        constant_pad_nd_default_31 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default_8, [0, -1, 0, -1]);  max_pool2d_with_indices_backward_default_8 = None
        add_tensor_356 = torch.ops.aten.add.Tensor(add_tensor_347, constant_pad_nd_default_31);  add_tensor_347 = constant_pad_nd_default_31 = None
        native_batch_norm_backward_default_47 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_356, convolution_default_149, primals_690, primals_688, primals_689, new_zeros_default_264, new_zeros_default_265, False, 0.001, [True, True, True]);  add_tensor_356 = convolution_default_149 = primals_690 = primals_688 = primals_689 = new_zeros_default_264 = new_zeros_default_265 = None
        getitem_969 = native_batch_norm_backward_default_47[0]
        getitem_970 = native_batch_norm_backward_default_47[1]
        getitem_971 = native_batch_norm_backward_default_47[2];  native_batch_norm_backward_default_47 = None
        convolution_backward_default_114 = torch.ops.aten.convolution_backward.default(getitem_969, convolution_default_148, primals_693, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_969 = convolution_default_148 = primals_693 = None
        getitem_972 = convolution_backward_default_114[0]
        getitem_973 = convolution_backward_default_114[1]
        getitem_974 = convolution_backward_default_114[2];  convolution_backward_default_114 = None
        convolution_backward_default_115 = torch.ops.aten.convolution_backward.default(getitem_972, silu__default_82, primals_691, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_972 = silu__default_82 = primals_691 = None
        getitem_975 = convolution_backward_default_115[0]
        getitem_976 = convolution_backward_default_115[1]
        getitem_977 = convolution_backward_default_115[2];  convolution_backward_default_115 = None
        to_dtype_192 = torch.ops.aten.to.dtype(getitem_975, torch.float32);  getitem_975 = None
        to_dtype_193 = torch.ops.aten.to.dtype(clone_default_82, torch.float32);  clone_default_82 = None
        neg_default_87 = torch.ops.aten.neg.default(to_dtype_193)
        exp_default_47 = torch.ops.aten.exp.default(neg_default_87);  neg_default_87 = None
        add_tensor_357 = torch.ops.aten.add.Tensor(exp_default_47, 1);  exp_default_47 = None
        reciprocal_default_47 = torch.ops.aten.reciprocal.default(add_tensor_357);  add_tensor_357 = None
        mul_tensor_407 = torch.ops.aten.mul.Tensor(reciprocal_default_47, 1);  reciprocal_default_47 = None
        mul_tensor_408 = torch.ops.aten.mul.Tensor(to_dtype_192, mul_tensor_407);  to_dtype_192 = None
        rsub_scalar_47 = torch.ops.aten.rsub.Scalar(mul_tensor_407, 1);  mul_tensor_407 = None
        mul_tensor_409 = torch.ops.aten.mul.Tensor(to_dtype_193, rsub_scalar_47);  to_dtype_193 = rsub_scalar_47 = None
        add_tensor_358 = torch.ops.aten.add.Tensor(mul_tensor_409, 1);  mul_tensor_409 = None
        mul_tensor_410 = torch.ops.aten.mul.Tensor(mul_tensor_408, add_tensor_358);  mul_tensor_408 = add_tensor_358 = None
        to_dtype_194 = torch.ops.aten.to.dtype(mul_tensor_410, torch.float32);  mul_tensor_410 = None
        unsqueeze_default_20 = torch.ops.aten.unsqueeze.default(to_dtype_194, 4);  to_dtype_194 = None
        expand_default_34 = torch.ops.aten.expand.default(unsqueeze_default_20, [1, 88, 10, 10, 3]);  unsqueeze_default_20 = None
        unbind_int_17 = torch.ops.aten.unbind.int(expand_default_34, -1);  expand_default_34 = None
        getitem_978 = unbind_int_17[0]
        getitem_979 = unbind_int_17[1]
        getitem_980 = unbind_int_17[2];  unbind_int_17 = None
        neg_default_88 = torch.ops.aten.neg.default(getitem_980)
        div_tensor_196 = torch.ops.aten.div.Tensor(mul_tensor_58, add_tensor_35);  mul_tensor_58 = None
        div_tensor_197 = torch.ops.aten.div.Tensor(div_tensor_196, add_tensor_35);  div_tensor_196 = None
        mul_tensor_411 = torch.ops.aten.mul.Tensor(neg_default_88, div_tensor_197);  neg_default_88 = div_tensor_197 = None
        div_tensor_198 = torch.ops.aten.div.Tensor(getitem_980, add_tensor_35);  getitem_980 = add_tensor_35 = None
        sum_default_112 = torch.ops.aten.sum.default(mul_tensor_411);  mul_tensor_411 = None
        mul_tensor_412 = torch.ops.aten.mul.Tensor(div_tensor_198, getitem_280);  getitem_280 = None
        mul_tensor_413 = torch.ops.aten.mul.Tensor(div_tensor_198, select_int_35);  div_tensor_198 = select_int_35 = None
        sum_default_113 = torch.ops.aten.sum.default(mul_tensor_412);  mul_tensor_412 = None
        select_backward_default_40 = torch.ops.aten.select_backward.default(sum_default_113, [3], 0, 2);  sum_default_113 = None
        neg_default_89 = torch.ops.aten.neg.default(getitem_979)
        div_tensor_199 = torch.ops.aten.div.Tensor(mul_tensor_57, add_tensor_34);  mul_tensor_57 = None
        div_tensor_200 = torch.ops.aten.div.Tensor(div_tensor_199, add_tensor_34);  div_tensor_199 = None
        mul_tensor_414 = torch.ops.aten.mul.Tensor(neg_default_89, div_tensor_200);  neg_default_89 = div_tensor_200 = None
        div_tensor_201 = torch.ops.aten.div.Tensor(getitem_979, add_tensor_34);  getitem_979 = add_tensor_34 = None
        sum_default_114 = torch.ops.aten.sum.default(mul_tensor_414);  mul_tensor_414 = None
        add_tensor_359 = torch.ops.aten.add.Tensor(sum_default_112, sum_default_114);  sum_default_112 = sum_default_114 = None
        mul_tensor_415 = torch.ops.aten.mul.Tensor(div_tensor_201, getitem_258);  getitem_258 = None
        mul_tensor_416 = torch.ops.aten.mul.Tensor(div_tensor_201, select_int_34);  div_tensor_201 = select_int_34 = None
        sum_default_115 = torch.ops.aten.sum.default(mul_tensor_415);  mul_tensor_415 = None
        select_backward_default_41 = torch.ops.aten.select_backward.default(sum_default_115, [3], 0, 1);  sum_default_115 = None
        add_tensor_360 = torch.ops.aten.add.Tensor(select_backward_default_40, select_backward_default_41);  select_backward_default_40 = select_backward_default_41 = None
        neg_default_90 = torch.ops.aten.neg.default(getitem_978)
        div_tensor_202 = torch.ops.aten.div.Tensor(mul_tensor_56, add_tensor_33);  mul_tensor_56 = None
        div_tensor_203 = torch.ops.aten.div.Tensor(div_tensor_202, add_tensor_33);  div_tensor_202 = None
        mul_tensor_417 = torch.ops.aten.mul.Tensor(neg_default_90, div_tensor_203);  neg_default_90 = div_tensor_203 = None
        div_tensor_204 = torch.ops.aten.div.Tensor(getitem_978, add_tensor_33);  getitem_978 = add_tensor_33 = None
        sum_default_116 = torch.ops.aten.sum.default(mul_tensor_417);  mul_tensor_417 = None
        add_tensor_361 = torch.ops.aten.add.Tensor(add_tensor_359, sum_default_116);  add_tensor_359 = sum_default_116 = None
        mul_tensor_418 = torch.ops.aten.mul.Tensor(div_tensor_204, getitem_250)
        mul_tensor_419 = torch.ops.aten.mul.Tensor(div_tensor_204, select_int_33);  div_tensor_204 = select_int_33 = None
        sum_default_117 = torch.ops.aten.sum.default(mul_tensor_418);  mul_tensor_418 = None
        select_backward_default_42 = torch.ops.aten.select_backward.default(sum_default_117, [3], 0, 0);  sum_default_117 = None
        add_tensor_362 = torch.ops.aten.add.Tensor(add_tensor_360, select_backward_default_42);  add_tensor_360 = select_backward_default_42 = None
        expand_default_35 = torch.ops.aten.expand.default(add_tensor_361, [3]);  add_tensor_361 = None
        add_tensor_363 = torch.ops.aten.add.Tensor(add_tensor_362, expand_default_35);  add_tensor_362 = expand_default_35 = None
        to_dtype_195 = torch.ops.aten.to.dtype(add_tensor_363, torch.float32);  add_tensor_363 = None
        to_dtype_196 = torch.ops.aten.to.dtype(relu_default_14, torch.float32);  relu_default_14 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_196, 0);  to_dtype_196 = None
        new_zeros_default_425 = torch.ops.aten.new_zeros.default(to_dtype_195, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_17, new_zeros_default_425, to_dtype_195);  le_scalar_17 = new_zeros_default_425 = to_dtype_195 = None
        to_dtype_197 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        max_pool2d_with_indices_backward_default_9 = torch.ops.aten.max_pool2d_with_indices_backward.default(mul_tensor_413, constant_pad_nd_default_13, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_281);  mul_tensor_413 = constant_pad_nd_default_13 = getitem_281 = None
        constant_pad_nd_default_32 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default_9, [0, -1, 0, -1]);  max_pool2d_with_indices_backward_default_9 = None
        add_tensor_364 = torch.ops.aten.add.Tensor(add_tensor_340, constant_pad_nd_default_32);  add_tensor_340 = constant_pad_nd_default_32 = None
        native_batch_norm_backward_default_48 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_364, convolution_default_147, primals_681, primals_679, primals_680, new_zeros_default_261, new_zeros_default_262, False, 0.001, [True, True, True]);  add_tensor_364 = convolution_default_147 = primals_681 = primals_679 = primals_680 = new_zeros_default_261 = new_zeros_default_262 = None
        getitem_981 = native_batch_norm_backward_default_48[0]
        getitem_982 = native_batch_norm_backward_default_48[1]
        getitem_983 = native_batch_norm_backward_default_48[2];  native_batch_norm_backward_default_48 = None
        convolution_backward_default_116 = torch.ops.aten.convolution_backward.default(getitem_981, convolution_default_146, primals_684, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_981 = convolution_default_146 = primals_684 = None
        getitem_984 = convolution_backward_default_116[0]
        getitem_985 = convolution_backward_default_116[1]
        getitem_986 = convolution_backward_default_116[2];  convolution_backward_default_116 = None
        convolution_backward_default_117 = torch.ops.aten.convolution_backward.default(getitem_984, silu__default_81, primals_682, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_984 = silu__default_81 = primals_682 = None
        getitem_987 = convolution_backward_default_117[0]
        getitem_988 = convolution_backward_default_117[1]
        getitem_989 = convolution_backward_default_117[2];  convolution_backward_default_117 = None
        to_dtype_198 = torch.ops.aten.to.dtype(getitem_987, torch.float32);  getitem_987 = None
        to_dtype_199 = torch.ops.aten.to.dtype(clone_default_81, torch.float32);  clone_default_81 = None
        neg_default_91 = torch.ops.aten.neg.default(to_dtype_199)
        exp_default_48 = torch.ops.aten.exp.default(neg_default_91);  neg_default_91 = None
        add_tensor_365 = torch.ops.aten.add.Tensor(exp_default_48, 1);  exp_default_48 = None
        reciprocal_default_48 = torch.ops.aten.reciprocal.default(add_tensor_365);  add_tensor_365 = None
        mul_tensor_420 = torch.ops.aten.mul.Tensor(reciprocal_default_48, 1);  reciprocal_default_48 = None
        mul_tensor_421 = torch.ops.aten.mul.Tensor(to_dtype_198, mul_tensor_420);  to_dtype_198 = None
        rsub_scalar_48 = torch.ops.aten.rsub.Scalar(mul_tensor_420, 1);  mul_tensor_420 = None
        mul_tensor_422 = torch.ops.aten.mul.Tensor(to_dtype_199, rsub_scalar_48);  to_dtype_199 = rsub_scalar_48 = None
        add_tensor_366 = torch.ops.aten.add.Tensor(mul_tensor_422, 1);  mul_tensor_422 = None
        mul_tensor_423 = torch.ops.aten.mul.Tensor(mul_tensor_421, add_tensor_366);  mul_tensor_421 = add_tensor_366 = None
        to_dtype_200 = torch.ops.aten.to.dtype(mul_tensor_423, torch.float32);  mul_tensor_423 = None
        unsqueeze_default_21 = torch.ops.aten.unsqueeze.default(to_dtype_200, 4);  to_dtype_200 = None
        expand_default_36 = torch.ops.aten.expand.default(unsqueeze_default_21, [1, 88, 20, 20, 3]);  unsqueeze_default_21 = None
        unbind_int_18 = torch.ops.aten.unbind.int(expand_default_36, -1);  expand_default_36 = None
        getitem_990 = unbind_int_18[0]
        getitem_991 = unbind_int_18[1]
        getitem_992 = unbind_int_18[2];  unbind_int_18 = None
        neg_default_92 = torch.ops.aten.neg.default(getitem_992)
        div_tensor_205 = torch.ops.aten.div.Tensor(mul_tensor_55, add_tensor_32);  mul_tensor_55 = None
        div_tensor_206 = torch.ops.aten.div.Tensor(div_tensor_205, add_tensor_32);  div_tensor_205 = None
        mul_tensor_424 = torch.ops.aten.mul.Tensor(neg_default_92, div_tensor_206);  neg_default_92 = div_tensor_206 = None
        div_tensor_207 = torch.ops.aten.div.Tensor(getitem_992, add_tensor_32);  getitem_992 = add_tensor_32 = None
        sum_default_118 = torch.ops.aten.sum.default(mul_tensor_424);  mul_tensor_424 = None
        mul_tensor_425 = torch.ops.aten.mul.Tensor(div_tensor_207, getitem_275);  getitem_275 = None
        mul_tensor_426 = torch.ops.aten.mul.Tensor(div_tensor_207, select_int_32);  div_tensor_207 = select_int_32 = None
        sum_default_119 = torch.ops.aten.sum.default(mul_tensor_425);  mul_tensor_425 = None
        select_backward_default_43 = torch.ops.aten.select_backward.default(sum_default_119, [3], 0, 2);  sum_default_119 = None
        neg_default_93 = torch.ops.aten.neg.default(getitem_991)
        div_tensor_208 = torch.ops.aten.div.Tensor(mul_tensor_54, add_tensor_31);  mul_tensor_54 = None
        div_tensor_209 = torch.ops.aten.div.Tensor(div_tensor_208, add_tensor_31);  div_tensor_208 = None
        mul_tensor_427 = torch.ops.aten.mul.Tensor(neg_default_93, div_tensor_209);  neg_default_93 = div_tensor_209 = None
        div_tensor_210 = torch.ops.aten.div.Tensor(getitem_991, add_tensor_31);  getitem_991 = add_tensor_31 = None
        sum_default_120 = torch.ops.aten.sum.default(mul_tensor_427);  mul_tensor_427 = None
        add_tensor_367 = torch.ops.aten.add.Tensor(sum_default_118, sum_default_120);  sum_default_118 = sum_default_120 = None
        mul_tensor_428 = torch.ops.aten.mul.Tensor(div_tensor_210, getitem_261);  getitem_261 = None
        mul_tensor_429 = torch.ops.aten.mul.Tensor(div_tensor_210, select_int_31);  div_tensor_210 = select_int_31 = None
        sum_default_121 = torch.ops.aten.sum.default(mul_tensor_428);  mul_tensor_428 = None
        select_backward_default_44 = torch.ops.aten.select_backward.default(sum_default_121, [3], 0, 1);  sum_default_121 = None
        add_tensor_368 = torch.ops.aten.add.Tensor(select_backward_default_43, select_backward_default_44);  select_backward_default_43 = select_backward_default_44 = None
        neg_default_94 = torch.ops.aten.neg.default(getitem_990)
        div_tensor_211 = torch.ops.aten.div.Tensor(mul_tensor_53, add_tensor_30);  mul_tensor_53 = None
        div_tensor_212 = torch.ops.aten.div.Tensor(div_tensor_211, add_tensor_30);  div_tensor_211 = None
        mul_tensor_430 = torch.ops.aten.mul.Tensor(neg_default_94, div_tensor_212);  neg_default_94 = div_tensor_212 = None
        div_tensor_213 = torch.ops.aten.div.Tensor(getitem_990, add_tensor_30);  getitem_990 = add_tensor_30 = None
        sum_default_122 = torch.ops.aten.sum.default(mul_tensor_430);  mul_tensor_430 = None
        add_tensor_369 = torch.ops.aten.add.Tensor(add_tensor_367, sum_default_122);  add_tensor_367 = sum_default_122 = None
        mul_tensor_431 = torch.ops.aten.mul.Tensor(div_tensor_213, getitem_245)
        mul_tensor_432 = torch.ops.aten.mul.Tensor(div_tensor_213, select_int_30);  div_tensor_213 = select_int_30 = None
        sum_default_123 = torch.ops.aten.sum.default(mul_tensor_431);  mul_tensor_431 = None
        select_backward_default_45 = torch.ops.aten.select_backward.default(sum_default_123, [3], 0, 0);  sum_default_123 = None
        add_tensor_370 = torch.ops.aten.add.Tensor(add_tensor_368, select_backward_default_45);  add_tensor_368 = select_backward_default_45 = None
        expand_default_37 = torch.ops.aten.expand.default(add_tensor_369, [3]);  add_tensor_369 = None
        add_tensor_371 = torch.ops.aten.add.Tensor(add_tensor_370, expand_default_37);  add_tensor_370 = expand_default_37 = None
        to_dtype_201 = torch.ops.aten.to.dtype(add_tensor_371, torch.float32);  add_tensor_371 = None
        to_dtype_202 = torch.ops.aten.to.dtype(relu_default_13, torch.float32);  relu_default_13 = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_202, 0);  to_dtype_202 = None
        new_zeros_default_426 = torch.ops.aten.new_zeros.default(to_dtype_201, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_18 = torch.ops.aten.where.self(le_scalar_18, new_zeros_default_426, to_dtype_201);  le_scalar_18 = new_zeros_default_426 = to_dtype_201 = None
        to_dtype_203 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        max_pool2d_with_indices_backward_default_10 = torch.ops.aten.max_pool2d_with_indices_backward.default(mul_tensor_426, constant_pad_nd_default_12, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_276);  mul_tensor_426 = constant_pad_nd_default_12 = getitem_276 = None
        constant_pad_nd_default_33 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default_10, [0, -1, 0, -1]);  max_pool2d_with_indices_backward_default_10 = None
        add_tensor_372 = torch.ops.aten.add.Tensor(add_tensor_333, constant_pad_nd_default_33);  add_tensor_333 = constant_pad_nd_default_33 = None
        native_batch_norm_backward_default_49 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_372, convolution_default_145, primals_672, primals_670, primals_671, new_zeros_default_258, new_zeros_default_259, False, 0.001, [True, True, True]);  add_tensor_372 = convolution_default_145 = primals_672 = primals_670 = primals_671 = new_zeros_default_258 = new_zeros_default_259 = None
        getitem_993 = native_batch_norm_backward_default_49[0]
        getitem_994 = native_batch_norm_backward_default_49[1]
        getitem_995 = native_batch_norm_backward_default_49[2];  native_batch_norm_backward_default_49 = None
        convolution_backward_default_118 = torch.ops.aten.convolution_backward.default(getitem_993, convolution_default_144, primals_675, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_993 = convolution_default_144 = primals_675 = None
        getitem_996 = convolution_backward_default_118[0]
        getitem_997 = convolution_backward_default_118[1]
        getitem_998 = convolution_backward_default_118[2];  convolution_backward_default_118 = None
        convolution_backward_default_119 = torch.ops.aten.convolution_backward.default(getitem_996, silu__default_80, primals_673, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_996 = silu__default_80 = primals_673 = None
        getitem_999 = convolution_backward_default_119[0]
        getitem_1000 = convolution_backward_default_119[1]
        getitem_1001 = convolution_backward_default_119[2];  convolution_backward_default_119 = None
        to_dtype_204 = torch.ops.aten.to.dtype(getitem_999, torch.float32);  getitem_999 = None
        to_dtype_205 = torch.ops.aten.to.dtype(clone_default_80, torch.float32);  clone_default_80 = None
        neg_default_95 = torch.ops.aten.neg.default(to_dtype_205)
        exp_default_49 = torch.ops.aten.exp.default(neg_default_95);  neg_default_95 = None
        add_tensor_373 = torch.ops.aten.add.Tensor(exp_default_49, 1);  exp_default_49 = None
        reciprocal_default_49 = torch.ops.aten.reciprocal.default(add_tensor_373);  add_tensor_373 = None
        mul_tensor_433 = torch.ops.aten.mul.Tensor(reciprocal_default_49, 1);  reciprocal_default_49 = None
        mul_tensor_434 = torch.ops.aten.mul.Tensor(to_dtype_204, mul_tensor_433);  to_dtype_204 = None
        rsub_scalar_49 = torch.ops.aten.rsub.Scalar(mul_tensor_433, 1);  mul_tensor_433 = None
        mul_tensor_435 = torch.ops.aten.mul.Tensor(to_dtype_205, rsub_scalar_49);  to_dtype_205 = rsub_scalar_49 = None
        add_tensor_374 = torch.ops.aten.add.Tensor(mul_tensor_435, 1);  mul_tensor_435 = None
        mul_tensor_436 = torch.ops.aten.mul.Tensor(mul_tensor_434, add_tensor_374);  mul_tensor_434 = add_tensor_374 = None
        to_dtype_206 = torch.ops.aten.to.dtype(mul_tensor_436, torch.float32);  mul_tensor_436 = None
        unsqueeze_default_22 = torch.ops.aten.unsqueeze.default(to_dtype_206, 4);  to_dtype_206 = None
        expand_default_38 = torch.ops.aten.expand.default(unsqueeze_default_22, [1, 88, 40, 40, 3]);  unsqueeze_default_22 = None
        unbind_int_19 = torch.ops.aten.unbind.int(expand_default_38, -1);  expand_default_38 = None
        getitem_1002 = unbind_int_19[0]
        getitem_1003 = unbind_int_19[1]
        getitem_1004 = unbind_int_19[2];  unbind_int_19 = None
        neg_default_96 = torch.ops.aten.neg.default(getitem_1004)
        div_tensor_214 = torch.ops.aten.div.Tensor(mul_tensor_52, add_tensor_29);  mul_tensor_52 = None
        div_tensor_215 = torch.ops.aten.div.Tensor(div_tensor_214, add_tensor_29);  div_tensor_214 = None
        mul_tensor_437 = torch.ops.aten.mul.Tensor(neg_default_96, div_tensor_215);  neg_default_96 = div_tensor_215 = None
        div_tensor_216 = torch.ops.aten.div.Tensor(getitem_1004, add_tensor_29);  getitem_1004 = add_tensor_29 = None
        sum_default_124 = torch.ops.aten.sum.default(mul_tensor_437);  mul_tensor_437 = None
        mul_tensor_438 = torch.ops.aten.mul.Tensor(div_tensor_216, getitem_270);  getitem_270 = None
        mul_tensor_439 = torch.ops.aten.mul.Tensor(div_tensor_216, select_int_29);  div_tensor_216 = select_int_29 = None
        sum_default_125 = torch.ops.aten.sum.default(mul_tensor_438);  mul_tensor_438 = None
        select_backward_default_46 = torch.ops.aten.select_backward.default(sum_default_125, [3], 0, 2);  sum_default_125 = None
        neg_default_97 = torch.ops.aten.neg.default(getitem_1003)
        div_tensor_217 = torch.ops.aten.div.Tensor(mul_tensor_51, add_tensor_28);  mul_tensor_51 = None
        div_tensor_218 = torch.ops.aten.div.Tensor(div_tensor_217, add_tensor_28);  div_tensor_217 = None
        mul_tensor_440 = torch.ops.aten.mul.Tensor(neg_default_97, div_tensor_218);  neg_default_97 = div_tensor_218 = None
        div_tensor_219 = torch.ops.aten.div.Tensor(getitem_1003, add_tensor_28);  getitem_1003 = add_tensor_28 = None
        sum_default_126 = torch.ops.aten.sum.default(mul_tensor_440);  mul_tensor_440 = None
        add_tensor_375 = torch.ops.aten.add.Tensor(sum_default_124, sum_default_126);  sum_default_124 = sum_default_126 = None
        mul_tensor_441 = torch.ops.aten.mul.Tensor(div_tensor_219, getitem_264);  getitem_264 = None
        mul_tensor_442 = torch.ops.aten.mul.Tensor(div_tensor_219, select_int_28);  div_tensor_219 = select_int_28 = None
        sum_default_127 = torch.ops.aten.sum.default(mul_tensor_441);  mul_tensor_441 = None
        select_backward_default_47 = torch.ops.aten.select_backward.default(sum_default_127, [3], 0, 1);  sum_default_127 = None
        add_tensor_376 = torch.ops.aten.add.Tensor(select_backward_default_46, select_backward_default_47);  select_backward_default_46 = select_backward_default_47 = None
        neg_default_98 = torch.ops.aten.neg.default(getitem_1002)
        div_tensor_220 = torch.ops.aten.div.Tensor(mul_tensor_50, add_tensor_27);  mul_tensor_50 = None
        div_tensor_221 = torch.ops.aten.div.Tensor(div_tensor_220, add_tensor_27);  div_tensor_220 = None
        mul_tensor_443 = torch.ops.aten.mul.Tensor(neg_default_98, div_tensor_221);  neg_default_98 = div_tensor_221 = None
        div_tensor_222 = torch.ops.aten.div.Tensor(getitem_1002, add_tensor_27);  getitem_1002 = add_tensor_27 = None
        sum_default_128 = torch.ops.aten.sum.default(mul_tensor_443);  mul_tensor_443 = None
        add_tensor_377 = torch.ops.aten.add.Tensor(add_tensor_375, sum_default_128);  add_tensor_375 = sum_default_128 = None
        mul_tensor_444 = torch.ops.aten.mul.Tensor(div_tensor_222, getitem_237)
        mul_tensor_445 = torch.ops.aten.mul.Tensor(div_tensor_222, select_int_27);  div_tensor_222 = select_int_27 = None
        sum_default_129 = torch.ops.aten.sum.default(mul_tensor_444);  mul_tensor_444 = None
        select_backward_default_48 = torch.ops.aten.select_backward.default(sum_default_129, [3], 0, 0);  sum_default_129 = None
        add_tensor_378 = torch.ops.aten.add.Tensor(add_tensor_376, select_backward_default_48);  add_tensor_376 = select_backward_default_48 = None
        expand_default_39 = torch.ops.aten.expand.default(add_tensor_377, [3]);  add_tensor_377 = None
        add_tensor_379 = torch.ops.aten.add.Tensor(add_tensor_378, expand_default_39);  add_tensor_378 = expand_default_39 = None
        to_dtype_207 = torch.ops.aten.to.dtype(add_tensor_379, torch.float32);  add_tensor_379 = None
        to_dtype_208 = torch.ops.aten.to.dtype(relu_default_12, torch.float32);  relu_default_12 = None
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_208, 0);  to_dtype_208 = None
        new_zeros_default_427 = torch.ops.aten.new_zeros.default(to_dtype_207, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_19 = torch.ops.aten.where.self(le_scalar_19, new_zeros_default_427, to_dtype_207);  le_scalar_19 = new_zeros_default_427 = to_dtype_207 = None
        to_dtype_209 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        max_pool2d_with_indices_backward_default_11 = torch.ops.aten.max_pool2d_with_indices_backward.default(mul_tensor_439, constant_pad_nd_default_11, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_271);  mul_tensor_439 = constant_pad_nd_default_11 = getitem_271 = None
        constant_pad_nd_default_34 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default_11, [0, -1, 0, -1]);  max_pool2d_with_indices_backward_default_11 = None
        add_tensor_380 = torch.ops.aten.add.Tensor(mul_tensor_366, constant_pad_nd_default_34);  mul_tensor_366 = constant_pad_nd_default_34 = None
        native_batch_norm_backward_default_50 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_380, convolution_default_143, primals_663, primals_661, primals_662, new_zeros_default_255, new_zeros_default_256, False, 0.001, [True, True, True]);  add_tensor_380 = convolution_default_143 = primals_663 = primals_661 = primals_662 = new_zeros_default_255 = new_zeros_default_256 = None
        getitem_1005 = native_batch_norm_backward_default_50[0]
        getitem_1006 = native_batch_norm_backward_default_50[1]
        getitem_1007 = native_batch_norm_backward_default_50[2];  native_batch_norm_backward_default_50 = None
        convolution_backward_default_120 = torch.ops.aten.convolution_backward.default(getitem_1005, convolution_default_142, primals_666, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_1005 = convolution_default_142 = primals_666 = None
        getitem_1008 = convolution_backward_default_120[0]
        getitem_1009 = convolution_backward_default_120[1]
        getitem_1010 = convolution_backward_default_120[2];  convolution_backward_default_120 = None
        convolution_backward_default_121 = torch.ops.aten.convolution_backward.default(getitem_1008, silu__default_79, primals_664, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_1008 = silu__default_79 = primals_664 = None
        getitem_1011 = convolution_backward_default_121[0]
        getitem_1012 = convolution_backward_default_121[1]
        getitem_1013 = convolution_backward_default_121[2];  convolution_backward_default_121 = None
        to_dtype_210 = torch.ops.aten.to.dtype(getitem_1011, torch.float32);  getitem_1011 = None
        to_dtype_211 = torch.ops.aten.to.dtype(clone_default_79, torch.float32);  clone_default_79 = None
        neg_default_99 = torch.ops.aten.neg.default(to_dtype_211)
        exp_default_50 = torch.ops.aten.exp.default(neg_default_99);  neg_default_99 = None
        add_tensor_381 = torch.ops.aten.add.Tensor(exp_default_50, 1);  exp_default_50 = None
        reciprocal_default_50 = torch.ops.aten.reciprocal.default(add_tensor_381);  add_tensor_381 = None
        mul_tensor_446 = torch.ops.aten.mul.Tensor(reciprocal_default_50, 1);  reciprocal_default_50 = None
        mul_tensor_447 = torch.ops.aten.mul.Tensor(to_dtype_210, mul_tensor_446);  to_dtype_210 = None
        rsub_scalar_50 = torch.ops.aten.rsub.Scalar(mul_tensor_446, 1);  mul_tensor_446 = None
        mul_tensor_448 = torch.ops.aten.mul.Tensor(to_dtype_211, rsub_scalar_50);  to_dtype_211 = rsub_scalar_50 = None
        add_tensor_382 = torch.ops.aten.add.Tensor(mul_tensor_448, 1);  mul_tensor_448 = None
        mul_tensor_449 = torch.ops.aten.mul.Tensor(mul_tensor_447, add_tensor_382);  mul_tensor_447 = add_tensor_382 = None
        to_dtype_212 = torch.ops.aten.to.dtype(mul_tensor_449, torch.float32);  mul_tensor_449 = None
        unsqueeze_default_23 = torch.ops.aten.unsqueeze.default(to_dtype_212, 4);  to_dtype_212 = None
        expand_default_40 = torch.ops.aten.expand.default(unsqueeze_default_23, [1, 88, 80, 80, 2]);  unsqueeze_default_23 = None
        unbind_int_20 = torch.ops.aten.unbind.int(expand_default_40, -1);  expand_default_40 = None
        getitem_1014 = unbind_int_20[0]
        getitem_1015 = unbind_int_20[1];  unbind_int_20 = None
        neg_default_100 = torch.ops.aten.neg.default(getitem_1015)
        div_tensor_223 = torch.ops.aten.div.Tensor(mul_tensor_49, add_tensor_26);  mul_tensor_49 = None
        div_tensor_224 = torch.ops.aten.div.Tensor(div_tensor_223, add_tensor_26);  div_tensor_223 = None
        mul_tensor_450 = torch.ops.aten.mul.Tensor(neg_default_100, div_tensor_224);  neg_default_100 = div_tensor_224 = None
        div_tensor_225 = torch.ops.aten.div.Tensor(getitem_1015, add_tensor_26);  getitem_1015 = add_tensor_26 = None
        sum_default_130 = torch.ops.aten.sum.default(mul_tensor_450);  mul_tensor_450 = None
        mul_tensor_451 = torch.ops.aten.mul.Tensor(div_tensor_225, upsample_nearest2d_vec_7);  upsample_nearest2d_vec_7 = None
        mul_tensor_452 = torch.ops.aten.mul.Tensor(div_tensor_225, select_int_26);  div_tensor_225 = select_int_26 = None
        sum_default_131 = torch.ops.aten.sum.default(mul_tensor_451);  mul_tensor_451 = None
        select_backward_default_49 = torch.ops.aten.select_backward.default(sum_default_131, [2], 0, 1);  sum_default_131 = None
        neg_default_101 = torch.ops.aten.neg.default(getitem_1014)
        div_tensor_226 = torch.ops.aten.div.Tensor(mul_tensor_48, add_tensor_25);  mul_tensor_48 = None
        div_tensor_227 = torch.ops.aten.div.Tensor(div_tensor_226, add_tensor_25);  div_tensor_226 = None
        mul_tensor_453 = torch.ops.aten.mul.Tensor(neg_default_101, div_tensor_227);  neg_default_101 = div_tensor_227 = None
        div_tensor_228 = torch.ops.aten.div.Tensor(getitem_1014, add_tensor_25);  getitem_1014 = add_tensor_25 = None
        sum_default_132 = torch.ops.aten.sum.default(mul_tensor_453);  mul_tensor_453 = None
        add_tensor_383 = torch.ops.aten.add.Tensor(sum_default_130, sum_default_132);  sum_default_130 = sum_default_132 = None
        mul_tensor_454 = torch.ops.aten.mul.Tensor(div_tensor_228, getitem_229);  getitem_229 = None
        mul_tensor_455 = torch.ops.aten.mul.Tensor(div_tensor_228, select_int_25);  div_tensor_228 = select_int_25 = None
        sum_default_133 = torch.ops.aten.sum.default(mul_tensor_454);  mul_tensor_454 = None
        select_backward_default_50 = torch.ops.aten.select_backward.default(sum_default_133, [2], 0, 0);  sum_default_133 = None
        add_tensor_384 = torch.ops.aten.add.Tensor(select_backward_default_49, select_backward_default_50);  select_backward_default_49 = select_backward_default_50 = None
        expand_default_41 = torch.ops.aten.expand.default(add_tensor_383, [2]);  add_tensor_383 = None
        add_tensor_385 = torch.ops.aten.add.Tensor(add_tensor_384, expand_default_41);  add_tensor_384 = expand_default_41 = None
        to_dtype_213 = torch.ops.aten.to.dtype(add_tensor_385, torch.float32);  add_tensor_385 = None
        to_dtype_214 = torch.ops.aten.to.dtype(relu_default_11, torch.float32);  relu_default_11 = None
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_214, 0);  to_dtype_214 = None
        new_zeros_default_428 = torch.ops.aten.new_zeros.default(to_dtype_213, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_20 = torch.ops.aten.where.self(le_scalar_20, new_zeros_default_428, to_dtype_213);  le_scalar_20 = new_zeros_default_428 = to_dtype_213 = None
        to_dtype_215 = torch.ops.aten.to.dtype(where_self_20, torch.float32);  where_self_20 = None
        upsample_nearest2d_backward_vec_8 = torch.ops.aten.upsample_nearest2d_backward.vec(mul_tensor_452, [80, 80], [1, 88, 40, 40], None);  mul_tensor_452 = None
        add_tensor_386 = torch.ops.aten.add.Tensor(mul_tensor_442, upsample_nearest2d_backward_vec_8);  mul_tensor_442 = upsample_nearest2d_backward_vec_8 = None
        native_batch_norm_backward_default_51 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_386, convolution_default_141, primals_654, primals_652, primals_653, new_zeros_default_252, new_zeros_default_253, False, 0.001, [True, True, True]);  add_tensor_386 = convolution_default_141 = primals_654 = primals_652 = primals_653 = new_zeros_default_252 = new_zeros_default_253 = None
        getitem_1016 = native_batch_norm_backward_default_51[0]
        getitem_1017 = native_batch_norm_backward_default_51[1]
        getitem_1018 = native_batch_norm_backward_default_51[2];  native_batch_norm_backward_default_51 = None
        convolution_backward_default_122 = torch.ops.aten.convolution_backward.default(getitem_1016, convolution_default_140, primals_657, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_1016 = convolution_default_140 = primals_657 = None
        getitem_1019 = convolution_backward_default_122[0]
        getitem_1020 = convolution_backward_default_122[1]
        getitem_1021 = convolution_backward_default_122[2];  convolution_backward_default_122 = None
        convolution_backward_default_123 = torch.ops.aten.convolution_backward.default(getitem_1019, silu__default_78, primals_655, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_1019 = silu__default_78 = primals_655 = None
        getitem_1022 = convolution_backward_default_123[0]
        getitem_1023 = convolution_backward_default_123[1]
        getitem_1024 = convolution_backward_default_123[2];  convolution_backward_default_123 = None
        to_dtype_216 = torch.ops.aten.to.dtype(getitem_1022, torch.float32);  getitem_1022 = None
        to_dtype_217 = torch.ops.aten.to.dtype(clone_default_78, torch.float32);  clone_default_78 = None
        neg_default_102 = torch.ops.aten.neg.default(to_dtype_217)
        exp_default_51 = torch.ops.aten.exp.default(neg_default_102);  neg_default_102 = None
        add_tensor_387 = torch.ops.aten.add.Tensor(exp_default_51, 1);  exp_default_51 = None
        reciprocal_default_51 = torch.ops.aten.reciprocal.default(add_tensor_387);  add_tensor_387 = None
        mul_tensor_456 = torch.ops.aten.mul.Tensor(reciprocal_default_51, 1);  reciprocal_default_51 = None
        mul_tensor_457 = torch.ops.aten.mul.Tensor(to_dtype_216, mul_tensor_456);  to_dtype_216 = None
        rsub_scalar_51 = torch.ops.aten.rsub.Scalar(mul_tensor_456, 1);  mul_tensor_456 = None
        mul_tensor_458 = torch.ops.aten.mul.Tensor(to_dtype_217, rsub_scalar_51);  to_dtype_217 = rsub_scalar_51 = None
        add_tensor_388 = torch.ops.aten.add.Tensor(mul_tensor_458, 1);  mul_tensor_458 = None
        mul_tensor_459 = torch.ops.aten.mul.Tensor(mul_tensor_457, add_tensor_388);  mul_tensor_457 = add_tensor_388 = None
        to_dtype_218 = torch.ops.aten.to.dtype(mul_tensor_459, torch.float32);  mul_tensor_459 = None
        unsqueeze_default_24 = torch.ops.aten.unsqueeze.default(to_dtype_218, 4);  to_dtype_218 = None
        expand_default_42 = torch.ops.aten.expand.default(unsqueeze_default_24, [1, 88, 40, 40, 2]);  unsqueeze_default_24 = None
        unbind_int_21 = torch.ops.aten.unbind.int(expand_default_42, -1);  expand_default_42 = None
        getitem_1025 = unbind_int_21[0]
        getitem_1026 = unbind_int_21[1];  unbind_int_21 = None
        neg_default_103 = torch.ops.aten.neg.default(getitem_1026)
        div_tensor_229 = torch.ops.aten.div.Tensor(mul_tensor_47, add_tensor_24);  mul_tensor_47 = None
        div_tensor_230 = torch.ops.aten.div.Tensor(div_tensor_229, add_tensor_24);  div_tensor_229 = None
        mul_tensor_460 = torch.ops.aten.mul.Tensor(neg_default_103, div_tensor_230);  neg_default_103 = div_tensor_230 = None
        div_tensor_231 = torch.ops.aten.div.Tensor(getitem_1026, add_tensor_24);  getitem_1026 = add_tensor_24 = None
        sum_default_134 = torch.ops.aten.sum.default(mul_tensor_460);  mul_tensor_460 = None
        mul_tensor_461 = torch.ops.aten.mul.Tensor(div_tensor_231, upsample_nearest2d_vec_6);  upsample_nearest2d_vec_6 = None
        mul_tensor_462 = torch.ops.aten.mul.Tensor(div_tensor_231, select_int_24);  div_tensor_231 = select_int_24 = None
        sum_default_135 = torch.ops.aten.sum.default(mul_tensor_461);  mul_tensor_461 = None
        select_backward_default_51 = torch.ops.aten.select_backward.default(sum_default_135, [2], 0, 1);  sum_default_135 = None
        neg_default_104 = torch.ops.aten.neg.default(getitem_1025)
        div_tensor_232 = torch.ops.aten.div.Tensor(mul_tensor_46, add_tensor_23);  mul_tensor_46 = None
        div_tensor_233 = torch.ops.aten.div.Tensor(div_tensor_232, add_tensor_23);  div_tensor_232 = None
        mul_tensor_463 = torch.ops.aten.mul.Tensor(neg_default_104, div_tensor_233);  neg_default_104 = div_tensor_233 = None
        div_tensor_234 = torch.ops.aten.div.Tensor(getitem_1025, add_tensor_23);  getitem_1025 = add_tensor_23 = None
        sum_default_136 = torch.ops.aten.sum.default(mul_tensor_463);  mul_tensor_463 = None
        add_tensor_389 = torch.ops.aten.add.Tensor(sum_default_134, sum_default_136);  sum_default_134 = sum_default_136 = None
        mul_tensor_464 = torch.ops.aten.mul.Tensor(div_tensor_234, getitem_237);  getitem_237 = None
        mul_tensor_465 = torch.ops.aten.mul.Tensor(div_tensor_234, select_int_23);  div_tensor_234 = select_int_23 = None
        sum_default_137 = torch.ops.aten.sum.default(mul_tensor_464);  mul_tensor_464 = None
        add_tensor_390 = torch.ops.aten.add.Tensor(mul_tensor_445, mul_tensor_465);  mul_tensor_445 = mul_tensor_465 = None
        select_backward_default_52 = torch.ops.aten.select_backward.default(sum_default_137, [2], 0, 0);  sum_default_137 = None
        add_tensor_391 = torch.ops.aten.add.Tensor(select_backward_default_51, select_backward_default_52);  select_backward_default_51 = select_backward_default_52 = None
        expand_default_43 = torch.ops.aten.expand.default(add_tensor_389, [2]);  add_tensor_389 = None
        add_tensor_392 = torch.ops.aten.add.Tensor(add_tensor_391, expand_default_43);  add_tensor_391 = expand_default_43 = None
        to_dtype_219 = torch.ops.aten.to.dtype(add_tensor_392, torch.float32);  add_tensor_392 = None
        to_dtype_220 = torch.ops.aten.to.dtype(relu_default_10, torch.float32);  relu_default_10 = None
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_220, 0);  to_dtype_220 = None
        new_zeros_default_429 = torch.ops.aten.new_zeros.default(to_dtype_219, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_21 = torch.ops.aten.where.self(le_scalar_21, new_zeros_default_429, to_dtype_219);  le_scalar_21 = new_zeros_default_429 = to_dtype_219 = None
        to_dtype_221 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        upsample_nearest2d_backward_vec_9 = torch.ops.aten.upsample_nearest2d_backward.vec(mul_tensor_462, [40, 40], [1, 88, 20, 20], None);  mul_tensor_462 = None
        add_tensor_393 = torch.ops.aten.add.Tensor(mul_tensor_429, upsample_nearest2d_backward_vec_9);  mul_tensor_429 = upsample_nearest2d_backward_vec_9 = None
        native_batch_norm_backward_default_52 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_393, convolution_default_139, primals_645, primals_643, primals_644, new_zeros_default_249, new_zeros_default_250, False, 0.001, [True, True, True]);  add_tensor_393 = convolution_default_139 = primals_645 = primals_643 = primals_644 = new_zeros_default_249 = new_zeros_default_250 = None
        getitem_1027 = native_batch_norm_backward_default_52[0]
        getitem_1028 = native_batch_norm_backward_default_52[1]
        getitem_1029 = native_batch_norm_backward_default_52[2];  native_batch_norm_backward_default_52 = None
        convolution_backward_default_124 = torch.ops.aten.convolution_backward.default(getitem_1027, convolution_default_138, primals_648, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_1027 = convolution_default_138 = primals_648 = None
        getitem_1030 = convolution_backward_default_124[0]
        getitem_1031 = convolution_backward_default_124[1]
        getitem_1032 = convolution_backward_default_124[2];  convolution_backward_default_124 = None
        convolution_backward_default_125 = torch.ops.aten.convolution_backward.default(getitem_1030, silu__default_77, primals_646, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_1030 = silu__default_77 = primals_646 = None
        getitem_1033 = convolution_backward_default_125[0]
        getitem_1034 = convolution_backward_default_125[1]
        getitem_1035 = convolution_backward_default_125[2];  convolution_backward_default_125 = None
        to_dtype_222 = torch.ops.aten.to.dtype(getitem_1033, torch.float32);  getitem_1033 = None
        to_dtype_223 = torch.ops.aten.to.dtype(clone_default_77, torch.float32);  clone_default_77 = None
        neg_default_105 = torch.ops.aten.neg.default(to_dtype_223)
        exp_default_52 = torch.ops.aten.exp.default(neg_default_105);  neg_default_105 = None
        add_tensor_394 = torch.ops.aten.add.Tensor(exp_default_52, 1);  exp_default_52 = None
        reciprocal_default_52 = torch.ops.aten.reciprocal.default(add_tensor_394);  add_tensor_394 = None
        mul_tensor_466 = torch.ops.aten.mul.Tensor(reciprocal_default_52, 1);  reciprocal_default_52 = None
        mul_tensor_467 = torch.ops.aten.mul.Tensor(to_dtype_222, mul_tensor_466);  to_dtype_222 = None
        rsub_scalar_52 = torch.ops.aten.rsub.Scalar(mul_tensor_466, 1);  mul_tensor_466 = None
        mul_tensor_468 = torch.ops.aten.mul.Tensor(to_dtype_223, rsub_scalar_52);  to_dtype_223 = rsub_scalar_52 = None
        add_tensor_395 = torch.ops.aten.add.Tensor(mul_tensor_468, 1);  mul_tensor_468 = None
        mul_tensor_469 = torch.ops.aten.mul.Tensor(mul_tensor_467, add_tensor_395);  mul_tensor_467 = add_tensor_395 = None
        to_dtype_224 = torch.ops.aten.to.dtype(mul_tensor_469, torch.float32);  mul_tensor_469 = None
        unsqueeze_default_25 = torch.ops.aten.unsqueeze.default(to_dtype_224, 4);  to_dtype_224 = None
        expand_default_44 = torch.ops.aten.expand.default(unsqueeze_default_25, [1, 88, 20, 20, 2]);  unsqueeze_default_25 = None
        unbind_int_22 = torch.ops.aten.unbind.int(expand_default_44, -1);  expand_default_44 = None
        getitem_1036 = unbind_int_22[0]
        getitem_1037 = unbind_int_22[1];  unbind_int_22 = None
        neg_default_106 = torch.ops.aten.neg.default(getitem_1037)
        div_tensor_235 = torch.ops.aten.div.Tensor(mul_tensor_45, add_tensor_22);  mul_tensor_45 = None
        div_tensor_236 = torch.ops.aten.div.Tensor(div_tensor_235, add_tensor_22);  div_tensor_235 = None
        mul_tensor_470 = torch.ops.aten.mul.Tensor(neg_default_106, div_tensor_236);  neg_default_106 = div_tensor_236 = None
        div_tensor_237 = torch.ops.aten.div.Tensor(getitem_1037, add_tensor_22);  getitem_1037 = add_tensor_22 = None
        sum_default_138 = torch.ops.aten.sum.default(mul_tensor_470);  mul_tensor_470 = None
        mul_tensor_471 = torch.ops.aten.mul.Tensor(div_tensor_237, upsample_nearest2d_vec_5);  upsample_nearest2d_vec_5 = None
        mul_tensor_472 = torch.ops.aten.mul.Tensor(div_tensor_237, select_int_22);  div_tensor_237 = select_int_22 = None
        sum_default_139 = torch.ops.aten.sum.default(mul_tensor_471);  mul_tensor_471 = None
        select_backward_default_53 = torch.ops.aten.select_backward.default(sum_default_139, [2], 0, 1);  sum_default_139 = None
        neg_default_107 = torch.ops.aten.neg.default(getitem_1036)
        div_tensor_238 = torch.ops.aten.div.Tensor(mul_tensor_44, add_tensor_21);  mul_tensor_44 = None
        div_tensor_239 = torch.ops.aten.div.Tensor(div_tensor_238, add_tensor_21);  div_tensor_238 = None
        mul_tensor_473 = torch.ops.aten.mul.Tensor(neg_default_107, div_tensor_239);  neg_default_107 = div_tensor_239 = None
        div_tensor_240 = torch.ops.aten.div.Tensor(getitem_1036, add_tensor_21);  getitem_1036 = add_tensor_21 = None
        sum_default_140 = torch.ops.aten.sum.default(mul_tensor_473);  mul_tensor_473 = None
        add_tensor_396 = torch.ops.aten.add.Tensor(sum_default_138, sum_default_140);  sum_default_138 = sum_default_140 = None
        mul_tensor_474 = torch.ops.aten.mul.Tensor(div_tensor_240, getitem_245);  getitem_245 = None
        mul_tensor_475 = torch.ops.aten.mul.Tensor(div_tensor_240, select_int_21);  div_tensor_240 = select_int_21 = None
        sum_default_141 = torch.ops.aten.sum.default(mul_tensor_474);  mul_tensor_474 = None
        add_tensor_397 = torch.ops.aten.add.Tensor(mul_tensor_432, mul_tensor_475);  mul_tensor_432 = mul_tensor_475 = None
        select_backward_default_54 = torch.ops.aten.select_backward.default(sum_default_141, [2], 0, 0);  sum_default_141 = None
        add_tensor_398 = torch.ops.aten.add.Tensor(select_backward_default_53, select_backward_default_54);  select_backward_default_53 = select_backward_default_54 = None
        expand_default_45 = torch.ops.aten.expand.default(add_tensor_396, [2]);  add_tensor_396 = None
        add_tensor_399 = torch.ops.aten.add.Tensor(add_tensor_398, expand_default_45);  add_tensor_398 = expand_default_45 = None
        to_dtype_225 = torch.ops.aten.to.dtype(add_tensor_399, torch.float32);  add_tensor_399 = None
        to_dtype_226 = torch.ops.aten.to.dtype(relu_default_9, torch.float32);  relu_default_9 = None
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_226, 0);  to_dtype_226 = None
        new_zeros_default_430 = torch.ops.aten.new_zeros.default(to_dtype_225, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_22 = torch.ops.aten.where.self(le_scalar_22, new_zeros_default_430, to_dtype_225);  le_scalar_22 = new_zeros_default_430 = to_dtype_225 = None
        to_dtype_227 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        upsample_nearest2d_backward_vec_10 = torch.ops.aten.upsample_nearest2d_backward.vec(mul_tensor_472, [20, 20], [1, 88, 10, 10], None);  mul_tensor_472 = None
        add_tensor_400 = torch.ops.aten.add.Tensor(mul_tensor_416, upsample_nearest2d_backward_vec_10);  mul_tensor_416 = upsample_nearest2d_backward_vec_10 = None
        native_batch_norm_backward_default_53 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_400, convolution_default_137, primals_636, primals_634, primals_635, new_zeros_default_246, new_zeros_default_247, False, 0.001, [True, True, True]);  add_tensor_400 = convolution_default_137 = primals_636 = primals_634 = primals_635 = new_zeros_default_246 = new_zeros_default_247 = None
        getitem_1038 = native_batch_norm_backward_default_53[0]
        getitem_1039 = native_batch_norm_backward_default_53[1]
        getitem_1040 = native_batch_norm_backward_default_53[2];  native_batch_norm_backward_default_53 = None
        convolution_backward_default_126 = torch.ops.aten.convolution_backward.default(getitem_1038, convolution_default_136, primals_639, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_1038 = convolution_default_136 = primals_639 = None
        getitem_1041 = convolution_backward_default_126[0]
        getitem_1042 = convolution_backward_default_126[1]
        getitem_1043 = convolution_backward_default_126[2];  convolution_backward_default_126 = None
        convolution_backward_default_127 = torch.ops.aten.convolution_backward.default(getitem_1041, silu__default_76, primals_637, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_1041 = silu__default_76 = primals_637 = None
        getitem_1044 = convolution_backward_default_127[0]
        getitem_1045 = convolution_backward_default_127[1]
        getitem_1046 = convolution_backward_default_127[2];  convolution_backward_default_127 = None
        to_dtype_228 = torch.ops.aten.to.dtype(getitem_1044, torch.float32);  getitem_1044 = None
        to_dtype_229 = torch.ops.aten.to.dtype(clone_default_76, torch.float32);  clone_default_76 = None
        neg_default_108 = torch.ops.aten.neg.default(to_dtype_229)
        exp_default_53 = torch.ops.aten.exp.default(neg_default_108);  neg_default_108 = None
        add_tensor_401 = torch.ops.aten.add.Tensor(exp_default_53, 1);  exp_default_53 = None
        reciprocal_default_53 = torch.ops.aten.reciprocal.default(add_tensor_401);  add_tensor_401 = None
        mul_tensor_476 = torch.ops.aten.mul.Tensor(reciprocal_default_53, 1);  reciprocal_default_53 = None
        mul_tensor_477 = torch.ops.aten.mul.Tensor(to_dtype_228, mul_tensor_476);  to_dtype_228 = None
        rsub_scalar_53 = torch.ops.aten.rsub.Scalar(mul_tensor_476, 1);  mul_tensor_476 = None
        mul_tensor_478 = torch.ops.aten.mul.Tensor(to_dtype_229, rsub_scalar_53);  to_dtype_229 = rsub_scalar_53 = None
        add_tensor_402 = torch.ops.aten.add.Tensor(mul_tensor_478, 1);  mul_tensor_478 = None
        mul_tensor_479 = torch.ops.aten.mul.Tensor(mul_tensor_477, add_tensor_402);  mul_tensor_477 = add_tensor_402 = None
        to_dtype_230 = torch.ops.aten.to.dtype(mul_tensor_479, torch.float32);  mul_tensor_479 = None
        unsqueeze_default_26 = torch.ops.aten.unsqueeze.default(to_dtype_230, 4);  to_dtype_230 = None
        expand_default_46 = torch.ops.aten.expand.default(unsqueeze_default_26, [1, 88, 10, 10, 2]);  unsqueeze_default_26 = None
        unbind_int_23 = torch.ops.aten.unbind.int(expand_default_46, -1);  expand_default_46 = None
        getitem_1047 = unbind_int_23[0]
        getitem_1048 = unbind_int_23[1];  unbind_int_23 = None
        neg_default_109 = torch.ops.aten.neg.default(getitem_1048)
        div_tensor_241 = torch.ops.aten.div.Tensor(mul_tensor_43, add_tensor_20);  mul_tensor_43 = None
        div_tensor_242 = torch.ops.aten.div.Tensor(div_tensor_241, add_tensor_20);  div_tensor_241 = None
        mul_tensor_480 = torch.ops.aten.mul.Tensor(neg_default_109, div_tensor_242);  neg_default_109 = div_tensor_242 = None
        div_tensor_243 = torch.ops.aten.div.Tensor(getitem_1048, add_tensor_20);  getitem_1048 = add_tensor_20 = None
        sum_default_142 = torch.ops.aten.sum.default(mul_tensor_480);  mul_tensor_480 = None
        mul_tensor_481 = torch.ops.aten.mul.Tensor(div_tensor_243, upsample_nearest2d_vec_4);  upsample_nearest2d_vec_4 = None
        mul_tensor_482 = torch.ops.aten.mul.Tensor(div_tensor_243, select_int_20);  div_tensor_243 = select_int_20 = None
        sum_default_143 = torch.ops.aten.sum.default(mul_tensor_481);  mul_tensor_481 = None
        select_backward_default_55 = torch.ops.aten.select_backward.default(sum_default_143, [2], 0, 1);  sum_default_143 = None
        neg_default_110 = torch.ops.aten.neg.default(getitem_1047)
        div_tensor_244 = torch.ops.aten.div.Tensor(mul_tensor_42, add_tensor_19);  mul_tensor_42 = None
        div_tensor_245 = torch.ops.aten.div.Tensor(div_tensor_244, add_tensor_19);  div_tensor_244 = None
        mul_tensor_483 = torch.ops.aten.mul.Tensor(neg_default_110, div_tensor_245);  neg_default_110 = div_tensor_245 = None
        div_tensor_246 = torch.ops.aten.div.Tensor(getitem_1047, add_tensor_19);  getitem_1047 = add_tensor_19 = None
        sum_default_144 = torch.ops.aten.sum.default(mul_tensor_483);  mul_tensor_483 = None
        add_tensor_403 = torch.ops.aten.add.Tensor(sum_default_142, sum_default_144);  sum_default_142 = sum_default_144 = None
        mul_tensor_484 = torch.ops.aten.mul.Tensor(div_tensor_246, getitem_250);  getitem_250 = None
        mul_tensor_485 = torch.ops.aten.mul.Tensor(div_tensor_246, select_int_19);  div_tensor_246 = select_int_19 = None
        sum_default_145 = torch.ops.aten.sum.default(mul_tensor_484);  mul_tensor_484 = None
        add_tensor_404 = torch.ops.aten.add.Tensor(mul_tensor_419, mul_tensor_485);  mul_tensor_419 = mul_tensor_485 = None
        select_backward_default_56 = torch.ops.aten.select_backward.default(sum_default_145, [2], 0, 0);  sum_default_145 = None
        add_tensor_405 = torch.ops.aten.add.Tensor(select_backward_default_55, select_backward_default_56);  select_backward_default_55 = select_backward_default_56 = None
        expand_default_47 = torch.ops.aten.expand.default(add_tensor_403, [2]);  add_tensor_403 = None
        add_tensor_406 = torch.ops.aten.add.Tensor(add_tensor_405, expand_default_47);  add_tensor_405 = expand_default_47 = None
        to_dtype_231 = torch.ops.aten.to.dtype(add_tensor_406, torch.float32);  add_tensor_406 = None
        to_dtype_232 = torch.ops.aten.to.dtype(relu_default_8, torch.float32);  relu_default_8 = None
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_232, 0);  to_dtype_232 = None
        new_zeros_default_431 = torch.ops.aten.new_zeros.default(to_dtype_231, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(le_scalar_23, new_zeros_default_431, to_dtype_231);  le_scalar_23 = new_zeros_default_431 = to_dtype_231 = None
        to_dtype_233 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        upsample_nearest2d_backward_vec_11 = torch.ops.aten.upsample_nearest2d_backward.vec(mul_tensor_482, [10, 10], [1, 88, 5, 5], None);  mul_tensor_482 = None
        add_tensor_407 = torch.ops.aten.add.Tensor(mul_tensor_406, upsample_nearest2d_backward_vec_11);  mul_tensor_406 = upsample_nearest2d_backward_vec_11 = None
        native_batch_norm_backward_default_54 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_407, convolution_default_135, primals_627, primals_625, primals_626, new_zeros_default_243, new_zeros_default_244, False, 0.001, [True, True, True]);  add_tensor_407 = convolution_default_135 = primals_627 = primals_625 = primals_626 = new_zeros_default_243 = new_zeros_default_244 = None
        getitem_1049 = native_batch_norm_backward_default_54[0]
        getitem_1050 = native_batch_norm_backward_default_54[1]
        getitem_1051 = native_batch_norm_backward_default_54[2];  native_batch_norm_backward_default_54 = None
        convolution_backward_default_128 = torch.ops.aten.convolution_backward.default(getitem_1049, convolution_default_134, primals_630, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_1049 = convolution_default_134 = primals_630 = None
        getitem_1052 = convolution_backward_default_128[0]
        getitem_1053 = convolution_backward_default_128[1]
        getitem_1054 = convolution_backward_default_128[2];  convolution_backward_default_128 = None
        convolution_backward_default_129 = torch.ops.aten.convolution_backward.default(getitem_1052, silu__default_75, primals_628, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_1052 = silu__default_75 = primals_628 = None
        getitem_1055 = convolution_backward_default_129[0]
        getitem_1056 = convolution_backward_default_129[1]
        getitem_1057 = convolution_backward_default_129[2];  convolution_backward_default_129 = None
        to_dtype_234 = torch.ops.aten.to.dtype(getitem_1055, torch.float32);  getitem_1055 = None
        to_dtype_235 = torch.ops.aten.to.dtype(clone_default_75, torch.float32);  clone_default_75 = None
        neg_default_111 = torch.ops.aten.neg.default(to_dtype_235)
        exp_default_54 = torch.ops.aten.exp.default(neg_default_111);  neg_default_111 = None
        add_tensor_408 = torch.ops.aten.add.Tensor(exp_default_54, 1);  exp_default_54 = None
        reciprocal_default_54 = torch.ops.aten.reciprocal.default(add_tensor_408);  add_tensor_408 = None
        mul_tensor_486 = torch.ops.aten.mul.Tensor(reciprocal_default_54, 1);  reciprocal_default_54 = None
        mul_tensor_487 = torch.ops.aten.mul.Tensor(to_dtype_234, mul_tensor_486);  to_dtype_234 = None
        rsub_scalar_54 = torch.ops.aten.rsub.Scalar(mul_tensor_486, 1);  mul_tensor_486 = None
        mul_tensor_488 = torch.ops.aten.mul.Tensor(to_dtype_235, rsub_scalar_54);  to_dtype_235 = rsub_scalar_54 = None
        add_tensor_409 = torch.ops.aten.add.Tensor(mul_tensor_488, 1);  mul_tensor_488 = None
        mul_tensor_489 = torch.ops.aten.mul.Tensor(mul_tensor_487, add_tensor_409);  mul_tensor_487 = add_tensor_409 = None
        to_dtype_236 = torch.ops.aten.to.dtype(mul_tensor_489, torch.float32);  mul_tensor_489 = None
        unsqueeze_default_27 = torch.ops.aten.unsqueeze.default(to_dtype_236, 4);  to_dtype_236 = None
        expand_default_48 = torch.ops.aten.expand.default(unsqueeze_default_27, [1, 88, 5, 5, 2]);  unsqueeze_default_27 = None
        unbind_int_24 = torch.ops.aten.unbind.int(expand_default_48, -1);  expand_default_48 = None
        getitem_1058 = unbind_int_24[0]
        getitem_1059 = unbind_int_24[1];  unbind_int_24 = None
        neg_default_112 = torch.ops.aten.neg.default(getitem_1059)
        div_tensor_247 = torch.ops.aten.div.Tensor(mul_tensor_41, add_tensor_18);  mul_tensor_41 = None
        div_tensor_248 = torch.ops.aten.div.Tensor(div_tensor_247, add_tensor_18);  div_tensor_247 = None
        mul_tensor_490 = torch.ops.aten.mul.Tensor(neg_default_112, div_tensor_248);  neg_default_112 = div_tensor_248 = None
        div_tensor_249 = torch.ops.aten.div.Tensor(getitem_1059, add_tensor_18);  getitem_1059 = add_tensor_18 = None
        sum_default_146 = torch.ops.aten.sum.default(mul_tensor_490);  mul_tensor_490 = None
        mul_tensor_491 = torch.ops.aten.mul.Tensor(div_tensor_249, getitem_253);  getitem_253 = None
        mul_tensor_492 = torch.ops.aten.mul.Tensor(div_tensor_249, select_int_18);  div_tensor_249 = select_int_18 = None
        sum_default_147 = torch.ops.aten.sum.default(mul_tensor_491);  mul_tensor_491 = None
        select_backward_default_57 = torch.ops.aten.select_backward.default(sum_default_147, [2], 0, 1);  sum_default_147 = None
        neg_default_113 = torch.ops.aten.neg.default(getitem_1058)
        div_tensor_250 = torch.ops.aten.div.Tensor(mul_tensor_40, add_tensor_17);  mul_tensor_40 = None
        div_tensor_251 = torch.ops.aten.div.Tensor(div_tensor_250, add_tensor_17);  div_tensor_250 = None
        mul_tensor_493 = torch.ops.aten.mul.Tensor(neg_default_113, div_tensor_251);  neg_default_113 = div_tensor_251 = None
        div_tensor_252 = torch.ops.aten.div.Tensor(getitem_1058, add_tensor_17);  getitem_1058 = add_tensor_17 = None
        sum_default_148 = torch.ops.aten.sum.default(mul_tensor_493);  mul_tensor_493 = None
        add_tensor_410 = torch.ops.aten.add.Tensor(sum_default_146, sum_default_148);  sum_default_146 = sum_default_148 = None
        mul_tensor_494 = torch.ops.aten.mul.Tensor(div_tensor_252, getitem_209);  getitem_209 = None
        mul_tensor_495 = torch.ops.aten.mul.Tensor(div_tensor_252, select_int_17);  div_tensor_252 = select_int_17 = None
        sum_default_149 = torch.ops.aten.sum.default(mul_tensor_494);  mul_tensor_494 = None
        select_backward_default_58 = torch.ops.aten.select_backward.default(sum_default_149, [2], 0, 0);  sum_default_149 = None
        add_tensor_411 = torch.ops.aten.add.Tensor(select_backward_default_57, select_backward_default_58);  select_backward_default_57 = select_backward_default_58 = None
        expand_default_49 = torch.ops.aten.expand.default(add_tensor_410, [2]);  add_tensor_410 = None
        add_tensor_412 = torch.ops.aten.add.Tensor(add_tensor_411, expand_default_49);  add_tensor_411 = expand_default_49 = None
        to_dtype_237 = torch.ops.aten.to.dtype(add_tensor_412, torch.float32);  add_tensor_412 = None
        to_dtype_238 = torch.ops.aten.to.dtype(relu_default_7, torch.float32);  relu_default_7 = None
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_238, 0);  to_dtype_238 = None
        new_zeros_default_432 = torch.ops.aten.new_zeros.default(to_dtype_237, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_24 = torch.ops.aten.where.self(le_scalar_24, new_zeros_default_432, to_dtype_237);  le_scalar_24 = new_zeros_default_432 = to_dtype_237 = None
        to_dtype_239 = torch.ops.aten.to.dtype(where_self_24, torch.float32);  where_self_24 = None
        max_pool2d_with_indices_backward_default_12 = torch.ops.aten.max_pool2d_with_indices_backward.default(mul_tensor_492, constant_pad_nd_default_10, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_254);  mul_tensor_492 = constant_pad_nd_default_10 = getitem_254 = None
        constant_pad_nd_default_35 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default_12, [0, -1, 0, -1]);  max_pool2d_with_indices_backward_default_12 = None
        add_tensor_413 = torch.ops.aten.add.Tensor(add_tensor_404, constant_pad_nd_default_35);  add_tensor_404 = constant_pad_nd_default_35 = None
        native_batch_norm_backward_default_55 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_413, convolution_default_133, primals_618, primals_616, primals_617, new_zeros_default_240, new_zeros_default_241, False, 0.001, [True, True, True]);  add_tensor_413 = convolution_default_133 = primals_618 = primals_616 = primals_617 = new_zeros_default_240 = new_zeros_default_241 = None
        getitem_1060 = native_batch_norm_backward_default_55[0]
        getitem_1061 = native_batch_norm_backward_default_55[1]
        getitem_1062 = native_batch_norm_backward_default_55[2];  native_batch_norm_backward_default_55 = None
        convolution_backward_default_130 = torch.ops.aten.convolution_backward.default(getitem_1060, convolution_default_132, primals_621, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_1060 = convolution_default_132 = primals_621 = None
        getitem_1063 = convolution_backward_default_130[0]
        getitem_1064 = convolution_backward_default_130[1]
        getitem_1065 = convolution_backward_default_130[2];  convolution_backward_default_130 = None
        convolution_backward_default_131 = torch.ops.aten.convolution_backward.default(getitem_1063, silu__default_74, primals_619, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_1063 = silu__default_74 = primals_619 = None
        getitem_1066 = convolution_backward_default_131[0]
        getitem_1067 = convolution_backward_default_131[1]
        getitem_1068 = convolution_backward_default_131[2];  convolution_backward_default_131 = None
        to_dtype_240 = torch.ops.aten.to.dtype(getitem_1066, torch.float32);  getitem_1066 = None
        to_dtype_241 = torch.ops.aten.to.dtype(clone_default_74, torch.float32);  clone_default_74 = None
        neg_default_114 = torch.ops.aten.neg.default(to_dtype_241)
        exp_default_55 = torch.ops.aten.exp.default(neg_default_114);  neg_default_114 = None
        add_tensor_414 = torch.ops.aten.add.Tensor(exp_default_55, 1);  exp_default_55 = None
        reciprocal_default_55 = torch.ops.aten.reciprocal.default(add_tensor_414);  add_tensor_414 = None
        mul_tensor_496 = torch.ops.aten.mul.Tensor(reciprocal_default_55, 1);  reciprocal_default_55 = None
        mul_tensor_497 = torch.ops.aten.mul.Tensor(to_dtype_240, mul_tensor_496);  to_dtype_240 = None
        rsub_scalar_55 = torch.ops.aten.rsub.Scalar(mul_tensor_496, 1);  mul_tensor_496 = None
        mul_tensor_498 = torch.ops.aten.mul.Tensor(to_dtype_241, rsub_scalar_55);  to_dtype_241 = rsub_scalar_55 = None
        add_tensor_415 = torch.ops.aten.add.Tensor(mul_tensor_498, 1);  mul_tensor_498 = None
        mul_tensor_499 = torch.ops.aten.mul.Tensor(mul_tensor_497, add_tensor_415);  mul_tensor_497 = add_tensor_415 = None
        to_dtype_242 = torch.ops.aten.to.dtype(mul_tensor_499, torch.float32);  mul_tensor_499 = None
        unsqueeze_default_28 = torch.ops.aten.unsqueeze.default(to_dtype_242, 4);  to_dtype_242 = None
        expand_default_50 = torch.ops.aten.expand.default(unsqueeze_default_28, [1, 88, 10, 10, 3]);  unsqueeze_default_28 = None
        unbind_int_25 = torch.ops.aten.unbind.int(expand_default_50, -1);  expand_default_50 = None
        getitem_1069 = unbind_int_25[0]
        getitem_1070 = unbind_int_25[1]
        getitem_1071 = unbind_int_25[2];  unbind_int_25 = None
        neg_default_115 = torch.ops.aten.neg.default(getitem_1071)
        div_tensor_253 = torch.ops.aten.div.Tensor(mul_tensor_39, add_tensor_16);  mul_tensor_39 = None
        div_tensor_254 = torch.ops.aten.div.Tensor(div_tensor_253, add_tensor_16);  div_tensor_253 = None
        mul_tensor_500 = torch.ops.aten.mul.Tensor(neg_default_115, div_tensor_254);  neg_default_115 = div_tensor_254 = None
        div_tensor_255 = torch.ops.aten.div.Tensor(getitem_1071, add_tensor_16);  getitem_1071 = add_tensor_16 = None
        sum_default_150 = torch.ops.aten.sum.default(mul_tensor_500);  mul_tensor_500 = None
        mul_tensor_501 = torch.ops.aten.mul.Tensor(div_tensor_255, getitem_248);  getitem_248 = None
        mul_tensor_502 = torch.ops.aten.mul.Tensor(div_tensor_255, select_int_16);  div_tensor_255 = select_int_16 = None
        sum_default_151 = torch.ops.aten.sum.default(mul_tensor_501);  mul_tensor_501 = None
        select_backward_default_59 = torch.ops.aten.select_backward.default(sum_default_151, [3], 0, 2);  sum_default_151 = None
        neg_default_116 = torch.ops.aten.neg.default(getitem_1070)
        div_tensor_256 = torch.ops.aten.div.Tensor(mul_tensor_38, add_tensor_15);  mul_tensor_38 = None
        div_tensor_257 = torch.ops.aten.div.Tensor(div_tensor_256, add_tensor_15);  div_tensor_256 = None
        mul_tensor_503 = torch.ops.aten.mul.Tensor(neg_default_116, div_tensor_257);  neg_default_116 = div_tensor_257 = None
        div_tensor_258 = torch.ops.aten.div.Tensor(getitem_1070, add_tensor_15);  getitem_1070 = add_tensor_15 = None
        sum_default_152 = torch.ops.aten.sum.default(mul_tensor_503);  mul_tensor_503 = None
        add_tensor_416 = torch.ops.aten.add.Tensor(sum_default_150, sum_default_152);  sum_default_150 = sum_default_152 = None
        mul_tensor_504 = torch.ops.aten.mul.Tensor(div_tensor_258, getitem_211);  getitem_211 = None
        mul_tensor_505 = torch.ops.aten.mul.Tensor(div_tensor_258, select_int_15);  div_tensor_258 = select_int_15 = None
        sum_default_153 = torch.ops.aten.sum.default(mul_tensor_504);  mul_tensor_504 = None
        select_backward_default_60 = torch.ops.aten.select_backward.default(sum_default_153, [3], 0, 1);  sum_default_153 = None
        add_tensor_417 = torch.ops.aten.add.Tensor(select_backward_default_59, select_backward_default_60);  select_backward_default_59 = select_backward_default_60 = None
        neg_default_117 = torch.ops.aten.neg.default(getitem_1069)
        div_tensor_259 = torch.ops.aten.div.Tensor(mul_tensor_37, add_tensor_14);  mul_tensor_37 = None
        div_tensor_260 = torch.ops.aten.div.Tensor(div_tensor_259, add_tensor_14);  div_tensor_259 = None
        mul_tensor_506 = torch.ops.aten.mul.Tensor(neg_default_117, div_tensor_260);  neg_default_117 = div_tensor_260 = None
        div_tensor_261 = torch.ops.aten.div.Tensor(getitem_1069, add_tensor_14);  getitem_1069 = add_tensor_14 = None
        sum_default_154 = torch.ops.aten.sum.default(mul_tensor_506);  mul_tensor_506 = None
        add_tensor_418 = torch.ops.aten.add.Tensor(add_tensor_416, sum_default_154);  add_tensor_416 = sum_default_154 = None
        mul_tensor_507 = torch.ops.aten.mul.Tensor(div_tensor_261, getitem_207)
        mul_tensor_508 = torch.ops.aten.mul.Tensor(div_tensor_261, select_int_14);  div_tensor_261 = select_int_14 = None
        sum_default_155 = torch.ops.aten.sum.default(mul_tensor_507);  mul_tensor_507 = None
        select_backward_default_61 = torch.ops.aten.select_backward.default(sum_default_155, [3], 0, 0);  sum_default_155 = None
        add_tensor_419 = torch.ops.aten.add.Tensor(add_tensor_417, select_backward_default_61);  add_tensor_417 = select_backward_default_61 = None
        expand_default_51 = torch.ops.aten.expand.default(add_tensor_418, [3]);  add_tensor_418 = None
        add_tensor_420 = torch.ops.aten.add.Tensor(add_tensor_419, expand_default_51);  add_tensor_419 = expand_default_51 = None
        to_dtype_243 = torch.ops.aten.to.dtype(add_tensor_420, torch.float32);  add_tensor_420 = None
        to_dtype_244 = torch.ops.aten.to.dtype(relu_default_6, torch.float32);  relu_default_6 = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_244, 0);  to_dtype_244 = None
        new_zeros_default_433 = torch.ops.aten.new_zeros.default(to_dtype_243, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_25 = torch.ops.aten.where.self(le_scalar_25, new_zeros_default_433, to_dtype_243);  le_scalar_25 = new_zeros_default_433 = to_dtype_243 = None
        to_dtype_245 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        max_pool2d_with_indices_backward_default_13 = torch.ops.aten.max_pool2d_with_indices_backward.default(mul_tensor_502, constant_pad_nd_default_9, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_249);  mul_tensor_502 = constant_pad_nd_default_9 = getitem_249 = None
        constant_pad_nd_default_36 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default_13, [0, -1, 0, -1]);  max_pool2d_with_indices_backward_default_13 = None
        add_tensor_421 = torch.ops.aten.add.Tensor(add_tensor_397, constant_pad_nd_default_36);  add_tensor_397 = constant_pad_nd_default_36 = None
        native_batch_norm_backward_default_56 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_421, convolution_default_131, primals_602, primals_600, primals_601, new_zeros_default_237, new_zeros_default_238, False, 0.001, [True, True, True]);  add_tensor_421 = convolution_default_131 = primals_602 = primals_600 = primals_601 = new_zeros_default_237 = new_zeros_default_238 = None
        getitem_1072 = native_batch_norm_backward_default_56[0]
        getitem_1073 = native_batch_norm_backward_default_56[1]
        getitem_1074 = native_batch_norm_backward_default_56[2];  native_batch_norm_backward_default_56 = None
        convolution_backward_default_132 = torch.ops.aten.convolution_backward.default(getitem_1072, convolution_default_130, primals_605, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_1072 = convolution_default_130 = primals_605 = None
        getitem_1075 = convolution_backward_default_132[0]
        getitem_1076 = convolution_backward_default_132[1]
        getitem_1077 = convolution_backward_default_132[2];  convolution_backward_default_132 = None
        convolution_backward_default_133 = torch.ops.aten.convolution_backward.default(getitem_1075, silu__default_73, primals_603, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_1075 = silu__default_73 = primals_603 = None
        getitem_1078 = convolution_backward_default_133[0]
        getitem_1079 = convolution_backward_default_133[1]
        getitem_1080 = convolution_backward_default_133[2];  convolution_backward_default_133 = None
        to_dtype_246 = torch.ops.aten.to.dtype(getitem_1078, torch.float32);  getitem_1078 = None
        to_dtype_247 = torch.ops.aten.to.dtype(clone_default_73, torch.float32);  clone_default_73 = None
        neg_default_118 = torch.ops.aten.neg.default(to_dtype_247)
        exp_default_56 = torch.ops.aten.exp.default(neg_default_118);  neg_default_118 = None
        add_tensor_422 = torch.ops.aten.add.Tensor(exp_default_56, 1);  exp_default_56 = None
        reciprocal_default_56 = torch.ops.aten.reciprocal.default(add_tensor_422);  add_tensor_422 = None
        mul_tensor_509 = torch.ops.aten.mul.Tensor(reciprocal_default_56, 1);  reciprocal_default_56 = None
        mul_tensor_510 = torch.ops.aten.mul.Tensor(to_dtype_246, mul_tensor_509);  to_dtype_246 = None
        rsub_scalar_56 = torch.ops.aten.rsub.Scalar(mul_tensor_509, 1);  mul_tensor_509 = None
        mul_tensor_511 = torch.ops.aten.mul.Tensor(to_dtype_247, rsub_scalar_56);  to_dtype_247 = rsub_scalar_56 = None
        add_tensor_423 = torch.ops.aten.add.Tensor(mul_tensor_511, 1);  mul_tensor_511 = None
        mul_tensor_512 = torch.ops.aten.mul.Tensor(mul_tensor_510, add_tensor_423);  mul_tensor_510 = add_tensor_423 = None
        to_dtype_248 = torch.ops.aten.to.dtype(mul_tensor_512, torch.float32);  mul_tensor_512 = None
        unsqueeze_default_29 = torch.ops.aten.unsqueeze.default(to_dtype_248, 4);  to_dtype_248 = None
        expand_default_52 = torch.ops.aten.expand.default(unsqueeze_default_29, [1, 88, 20, 20, 3]);  unsqueeze_default_29 = None
        unbind_int_26 = torch.ops.aten.unbind.int(expand_default_52, -1);  expand_default_52 = None
        getitem_1081 = unbind_int_26[0]
        getitem_1082 = unbind_int_26[1]
        getitem_1083 = unbind_int_26[2];  unbind_int_26 = None
        neg_default_119 = torch.ops.aten.neg.default(getitem_1083)
        div_tensor_262 = torch.ops.aten.div.Tensor(mul_tensor_36, add_tensor_13);  mul_tensor_36 = None
        div_tensor_263 = torch.ops.aten.div.Tensor(div_tensor_262, add_tensor_13);  div_tensor_262 = None
        mul_tensor_513 = torch.ops.aten.mul.Tensor(neg_default_119, div_tensor_263);  neg_default_119 = div_tensor_263 = None
        div_tensor_264 = torch.ops.aten.div.Tensor(getitem_1083, add_tensor_13);  getitem_1083 = add_tensor_13 = None
        sum_default_156 = torch.ops.aten.sum.default(mul_tensor_513);  mul_tensor_513 = None
        mul_tensor_514 = torch.ops.aten.mul.Tensor(div_tensor_264, getitem_243);  getitem_243 = None
        mul_tensor_515 = torch.ops.aten.mul.Tensor(div_tensor_264, select_int_13);  div_tensor_264 = select_int_13 = None
        sum_default_157 = torch.ops.aten.sum.default(mul_tensor_514);  mul_tensor_514 = None
        select_backward_default_62 = torch.ops.aten.select_backward.default(sum_default_157, [3], 0, 2);  sum_default_157 = None
        neg_default_120 = torch.ops.aten.neg.default(getitem_1082)
        div_tensor_265 = torch.ops.aten.div.Tensor(mul_tensor_35, add_tensor_12);  mul_tensor_35 = None
        div_tensor_266 = torch.ops.aten.div.Tensor(div_tensor_265, add_tensor_12);  div_tensor_265 = None
        mul_tensor_516 = torch.ops.aten.mul.Tensor(neg_default_120, div_tensor_266);  neg_default_120 = div_tensor_266 = None
        div_tensor_267 = torch.ops.aten.div.Tensor(getitem_1082, add_tensor_12);  getitem_1082 = add_tensor_12 = None
        sum_default_158 = torch.ops.aten.sum.default(mul_tensor_516);  mul_tensor_516 = None
        add_tensor_424 = torch.ops.aten.add.Tensor(sum_default_156, sum_default_158);  sum_default_156 = sum_default_158 = None
        mul_tensor_517 = torch.ops.aten.mul.Tensor(div_tensor_267, getitem_217);  getitem_217 = None
        mul_tensor_518 = torch.ops.aten.mul.Tensor(div_tensor_267, select_int_12);  div_tensor_267 = select_int_12 = None
        sum_default_159 = torch.ops.aten.sum.default(mul_tensor_517);  mul_tensor_517 = None
        select_backward_default_63 = torch.ops.aten.select_backward.default(sum_default_159, [3], 0, 1);  sum_default_159 = None
        add_tensor_425 = torch.ops.aten.add.Tensor(select_backward_default_62, select_backward_default_63);  select_backward_default_62 = select_backward_default_63 = None
        neg_default_121 = torch.ops.aten.neg.default(getitem_1081)
        div_tensor_268 = torch.ops.aten.div.Tensor(mul_tensor_34, add_tensor_11);  mul_tensor_34 = None
        div_tensor_269 = torch.ops.aten.div.Tensor(div_tensor_268, add_tensor_11);  div_tensor_268 = None
        mul_tensor_519 = torch.ops.aten.mul.Tensor(neg_default_121, div_tensor_269);  neg_default_121 = div_tensor_269 = None
        div_tensor_270 = torch.ops.aten.div.Tensor(getitem_1081, add_tensor_11);  getitem_1081 = add_tensor_11 = None
        sum_default_160 = torch.ops.aten.sum.default(mul_tensor_519);  mul_tensor_519 = None
        add_tensor_426 = torch.ops.aten.add.Tensor(add_tensor_424, sum_default_160);  add_tensor_424 = sum_default_160 = None
        mul_tensor_520 = torch.ops.aten.mul.Tensor(div_tensor_270, getitem_240);  getitem_240 = None
        mul_tensor_521 = torch.ops.aten.mul.Tensor(div_tensor_270, select_int_11);  div_tensor_270 = select_int_11 = None
        sum_default_161 = torch.ops.aten.sum.default(mul_tensor_520);  mul_tensor_520 = None
        select_backward_default_64 = torch.ops.aten.select_backward.default(sum_default_161, [3], 0, 0);  sum_default_161 = None
        add_tensor_427 = torch.ops.aten.add.Tensor(add_tensor_425, select_backward_default_64);  add_tensor_425 = select_backward_default_64 = None
        expand_default_53 = torch.ops.aten.expand.default(add_tensor_426, [3]);  add_tensor_426 = None
        add_tensor_428 = torch.ops.aten.add.Tensor(add_tensor_427, expand_default_53);  add_tensor_427 = expand_default_53 = None
        to_dtype_249 = torch.ops.aten.to.dtype(add_tensor_428, torch.float32);  add_tensor_428 = None
        to_dtype_250 = torch.ops.aten.to.dtype(relu_default_5, torch.float32);  relu_default_5 = None
        le_scalar_26 = torch.ops.aten.le.Scalar(to_dtype_250, 0);  to_dtype_250 = None
        new_zeros_default_434 = torch.ops.aten.new_zeros.default(to_dtype_249, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_26 = torch.ops.aten.where.self(le_scalar_26, new_zeros_default_434, to_dtype_249);  le_scalar_26 = new_zeros_default_434 = to_dtype_249 = None
        to_dtype_251 = torch.ops.aten.to.dtype(where_self_26, torch.float32);  where_self_26 = None
        max_pool2d_with_indices_backward_default_14 = torch.ops.aten.max_pool2d_with_indices_backward.default(mul_tensor_515, constant_pad_nd_default_8, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_244);  mul_tensor_515 = constant_pad_nd_default_8 = getitem_244 = None
        constant_pad_nd_default_37 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default_14, [0, -1, 0, -1]);  max_pool2d_with_indices_backward_default_14 = None
        add_tensor_429 = torch.ops.aten.add.Tensor(add_tensor_390, constant_pad_nd_default_37);  add_tensor_390 = constant_pad_nd_default_37 = None
        native_batch_norm_backward_default_57 = torch.ops.aten.native_batch_norm_backward.default(mul_tensor_521, convolution_default_129, primals_611, primals_609, primals_610, new_zeros_default_234, new_zeros_default_235, False, 0.001, [True, True, True]);  mul_tensor_521 = convolution_default_129 = primals_611 = primals_609 = primals_610 = new_zeros_default_234 = new_zeros_default_235 = None
        getitem_1084 = native_batch_norm_backward_default_57[0]
        getitem_1085 = native_batch_norm_backward_default_57[1]
        getitem_1086 = native_batch_norm_backward_default_57[2];  native_batch_norm_backward_default_57 = None
        convolution_backward_default_134 = torch.ops.aten.convolution_backward.default(getitem_1084, add__tensor_15, primals_613, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_1084 = primals_613 = None
        getitem_1087 = convolution_backward_default_134[0]
        getitem_1088 = convolution_backward_default_134[1]
        getitem_1089 = convolution_backward_default_134[2];  convolution_backward_default_134 = None
        native_batch_norm_backward_default_58 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_429, convolution_default_128, primals_586, primals_584, primals_585, new_zeros_default_231, new_zeros_default_232, False, 0.001, [True, True, True]);  add_tensor_429 = convolution_default_128 = primals_586 = primals_584 = primals_585 = new_zeros_default_231 = new_zeros_default_232 = None
        getitem_1090 = native_batch_norm_backward_default_58[0]
        getitem_1091 = native_batch_norm_backward_default_58[1]
        getitem_1092 = native_batch_norm_backward_default_58[2];  native_batch_norm_backward_default_58 = None
        convolution_backward_default_135 = torch.ops.aten.convolution_backward.default(getitem_1090, convolution_default_127, primals_589, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_1090 = convolution_default_127 = primals_589 = None
        getitem_1093 = convolution_backward_default_135[0]
        getitem_1094 = convolution_backward_default_135[1]
        getitem_1095 = convolution_backward_default_135[2];  convolution_backward_default_135 = None
        convolution_backward_default_136 = torch.ops.aten.convolution_backward.default(getitem_1093, silu__default_72, primals_587, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_1093 = silu__default_72 = primals_587 = None
        getitem_1096 = convolution_backward_default_136[0]
        getitem_1097 = convolution_backward_default_136[1]
        getitem_1098 = convolution_backward_default_136[2];  convolution_backward_default_136 = None
        to_dtype_252 = torch.ops.aten.to.dtype(getitem_1096, torch.float32);  getitem_1096 = None
        to_dtype_253 = torch.ops.aten.to.dtype(clone_default_72, torch.float32);  clone_default_72 = None
        neg_default_122 = torch.ops.aten.neg.default(to_dtype_253)
        exp_default_57 = torch.ops.aten.exp.default(neg_default_122);  neg_default_122 = None
        add_tensor_430 = torch.ops.aten.add.Tensor(exp_default_57, 1);  exp_default_57 = None
        reciprocal_default_57 = torch.ops.aten.reciprocal.default(add_tensor_430);  add_tensor_430 = None
        mul_tensor_522 = torch.ops.aten.mul.Tensor(reciprocal_default_57, 1);  reciprocal_default_57 = None
        mul_tensor_523 = torch.ops.aten.mul.Tensor(to_dtype_252, mul_tensor_522);  to_dtype_252 = None
        rsub_scalar_57 = torch.ops.aten.rsub.Scalar(mul_tensor_522, 1);  mul_tensor_522 = None
        mul_tensor_524 = torch.ops.aten.mul.Tensor(to_dtype_253, rsub_scalar_57);  to_dtype_253 = rsub_scalar_57 = None
        add_tensor_431 = torch.ops.aten.add.Tensor(mul_tensor_524, 1);  mul_tensor_524 = None
        mul_tensor_525 = torch.ops.aten.mul.Tensor(mul_tensor_523, add_tensor_431);  mul_tensor_523 = add_tensor_431 = None
        to_dtype_254 = torch.ops.aten.to.dtype(mul_tensor_525, torch.float32);  mul_tensor_525 = None
        unsqueeze_default_30 = torch.ops.aten.unsqueeze.default(to_dtype_254, 4);  to_dtype_254 = None
        expand_default_54 = torch.ops.aten.expand.default(unsqueeze_default_30, [1, 88, 40, 40, 3]);  unsqueeze_default_30 = None
        unbind_int_27 = torch.ops.aten.unbind.int(expand_default_54, -1);  expand_default_54 = None
        getitem_1099 = unbind_int_27[0]
        getitem_1100 = unbind_int_27[1]
        getitem_1101 = unbind_int_27[2];  unbind_int_27 = None
        neg_default_123 = torch.ops.aten.neg.default(getitem_1101)
        div_tensor_271 = torch.ops.aten.div.Tensor(mul_tensor_33, add_tensor_10);  mul_tensor_33 = None
        div_tensor_272 = torch.ops.aten.div.Tensor(div_tensor_271, add_tensor_10);  div_tensor_271 = None
        mul_tensor_526 = torch.ops.aten.mul.Tensor(neg_default_123, div_tensor_272);  neg_default_123 = div_tensor_272 = None
        div_tensor_273 = torch.ops.aten.div.Tensor(getitem_1101, add_tensor_10);  getitem_1101 = add_tensor_10 = None
        sum_default_162 = torch.ops.aten.sum.default(mul_tensor_526);  mul_tensor_526 = None
        mul_tensor_527 = torch.ops.aten.mul.Tensor(div_tensor_273, getitem_235);  getitem_235 = None
        mul_tensor_528 = torch.ops.aten.mul.Tensor(div_tensor_273, select_int_10);  div_tensor_273 = select_int_10 = None
        sum_default_163 = torch.ops.aten.sum.default(mul_tensor_527);  mul_tensor_527 = None
        select_backward_default_65 = torch.ops.aten.select_backward.default(sum_default_163, [3], 0, 2);  sum_default_163 = None
        neg_default_124 = torch.ops.aten.neg.default(getitem_1100)
        div_tensor_274 = torch.ops.aten.div.Tensor(mul_tensor_32, add_tensor_9);  mul_tensor_32 = None
        div_tensor_275 = torch.ops.aten.div.Tensor(div_tensor_274, add_tensor_9);  div_tensor_274 = None
        mul_tensor_529 = torch.ops.aten.mul.Tensor(neg_default_124, div_tensor_275);  neg_default_124 = div_tensor_275 = None
        div_tensor_276 = torch.ops.aten.div.Tensor(getitem_1100, add_tensor_9);  getitem_1100 = add_tensor_9 = None
        sum_default_164 = torch.ops.aten.sum.default(mul_tensor_529);  mul_tensor_529 = None
        add_tensor_432 = torch.ops.aten.add.Tensor(sum_default_162, sum_default_164);  sum_default_162 = sum_default_164 = None
        mul_tensor_530 = torch.ops.aten.mul.Tensor(div_tensor_276, getitem_223);  getitem_223 = None
        mul_tensor_531 = torch.ops.aten.mul.Tensor(div_tensor_276, select_int_9);  div_tensor_276 = select_int_9 = None
        sum_default_165 = torch.ops.aten.sum.default(mul_tensor_530);  mul_tensor_530 = None
        select_backward_default_66 = torch.ops.aten.select_backward.default(sum_default_165, [3], 0, 1);  sum_default_165 = None
        add_tensor_433 = torch.ops.aten.add.Tensor(select_backward_default_65, select_backward_default_66);  select_backward_default_65 = select_backward_default_66 = None
        neg_default_125 = torch.ops.aten.neg.default(getitem_1099)
        div_tensor_277 = torch.ops.aten.div.Tensor(mul_tensor_31, add_tensor_8);  mul_tensor_31 = None
        div_tensor_278 = torch.ops.aten.div.Tensor(div_tensor_277, add_tensor_8);  div_tensor_277 = None
        mul_tensor_532 = torch.ops.aten.mul.Tensor(neg_default_125, div_tensor_278);  neg_default_125 = div_tensor_278 = None
        div_tensor_279 = torch.ops.aten.div.Tensor(getitem_1099, add_tensor_8);  getitem_1099 = add_tensor_8 = None
        sum_default_166 = torch.ops.aten.sum.default(mul_tensor_532);  mul_tensor_532 = None
        add_tensor_434 = torch.ops.aten.add.Tensor(add_tensor_432, sum_default_166);  add_tensor_432 = sum_default_166 = None
        mul_tensor_533 = torch.ops.aten.mul.Tensor(div_tensor_279, getitem_232);  getitem_232 = None
        mul_tensor_534 = torch.ops.aten.mul.Tensor(div_tensor_279, select_int_8);  div_tensor_279 = select_int_8 = None
        sum_default_167 = torch.ops.aten.sum.default(mul_tensor_533);  mul_tensor_533 = None
        select_backward_default_67 = torch.ops.aten.select_backward.default(sum_default_167, [3], 0, 0);  sum_default_167 = None
        add_tensor_435 = torch.ops.aten.add.Tensor(add_tensor_433, select_backward_default_67);  add_tensor_433 = select_backward_default_67 = None
        expand_default_55 = torch.ops.aten.expand.default(add_tensor_434, [3]);  add_tensor_434 = None
        add_tensor_436 = torch.ops.aten.add.Tensor(add_tensor_435, expand_default_55);  add_tensor_435 = expand_default_55 = None
        to_dtype_255 = torch.ops.aten.to.dtype(add_tensor_436, torch.float32);  add_tensor_436 = None
        to_dtype_256 = torch.ops.aten.to.dtype(relu_default_4, torch.float32);  relu_default_4 = None
        le_scalar_27 = torch.ops.aten.le.Scalar(to_dtype_256, 0);  to_dtype_256 = None
        new_zeros_default_435 = torch.ops.aten.new_zeros.default(to_dtype_255, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_27 = torch.ops.aten.where.self(le_scalar_27, new_zeros_default_435, to_dtype_255);  le_scalar_27 = new_zeros_default_435 = to_dtype_255 = None
        to_dtype_257 = torch.ops.aten.to.dtype(where_self_27, torch.float32);  where_self_27 = None
        max_pool2d_with_indices_backward_default_15 = torch.ops.aten.max_pool2d_with_indices_backward.default(mul_tensor_528, constant_pad_nd_default_7, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_236);  mul_tensor_528 = constant_pad_nd_default_7 = getitem_236 = None
        constant_pad_nd_default_38 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default_15, [0, -1, 0, -1]);  max_pool2d_with_indices_backward_default_15 = None
        add_tensor_437 = torch.ops.aten.add.Tensor(mul_tensor_455, constant_pad_nd_default_38);  mul_tensor_455 = constant_pad_nd_default_38 = None
        native_batch_norm_backward_default_59 = torch.ops.aten.native_batch_norm_backward.default(mul_tensor_534, convolution_default_126, primals_595, primals_593, primals_594, new_zeros_default_228, new_zeros_default_229, False, 0.001, [True, True, True]);  mul_tensor_534 = convolution_default_126 = primals_595 = primals_593 = primals_594 = new_zeros_default_228 = new_zeros_default_229 = None
        getitem_1102 = native_batch_norm_backward_default_59[0]
        getitem_1103 = native_batch_norm_backward_default_59[1]
        getitem_1104 = native_batch_norm_backward_default_59[2];  native_batch_norm_backward_default_59 = None
        convolution_backward_default_137 = torch.ops.aten.convolution_backward.default(getitem_1102, add__tensor_10, primals_597, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_1102 = primals_597 = None
        getitem_1105 = convolution_backward_default_137[0]
        getitem_1106 = convolution_backward_default_137[1]
        getitem_1107 = convolution_backward_default_137[2];  convolution_backward_default_137 = None
        native_batch_norm_backward_default_60 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_437, convolution_default_125, primals_570, primals_568, primals_569, new_zeros_default_225, new_zeros_default_226, False, 0.001, [True, True, True]);  add_tensor_437 = convolution_default_125 = primals_570 = primals_568 = primals_569 = new_zeros_default_225 = new_zeros_default_226 = None
        getitem_1108 = native_batch_norm_backward_default_60[0]
        getitem_1109 = native_batch_norm_backward_default_60[1]
        getitem_1110 = native_batch_norm_backward_default_60[2];  native_batch_norm_backward_default_60 = None
        convolution_backward_default_138 = torch.ops.aten.convolution_backward.default(getitem_1108, convolution_default_124, primals_573, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_1108 = convolution_default_124 = primals_573 = None
        getitem_1111 = convolution_backward_default_138[0]
        getitem_1112 = convolution_backward_default_138[1]
        getitem_1113 = convolution_backward_default_138[2];  convolution_backward_default_138 = None
        convolution_backward_default_139 = torch.ops.aten.convolution_backward.default(getitem_1111, silu__default_71, primals_571, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_1111 = silu__default_71 = primals_571 = None
        getitem_1114 = convolution_backward_default_139[0]
        getitem_1115 = convolution_backward_default_139[1]
        getitem_1116 = convolution_backward_default_139[2];  convolution_backward_default_139 = None
        to_dtype_258 = torch.ops.aten.to.dtype(getitem_1114, torch.float32);  getitem_1114 = None
        to_dtype_259 = torch.ops.aten.to.dtype(clone_default_71, torch.float32);  clone_default_71 = None
        neg_default_126 = torch.ops.aten.neg.default(to_dtype_259)
        exp_default_58 = torch.ops.aten.exp.default(neg_default_126);  neg_default_126 = None
        add_tensor_438 = torch.ops.aten.add.Tensor(exp_default_58, 1);  exp_default_58 = None
        reciprocal_default_58 = torch.ops.aten.reciprocal.default(add_tensor_438);  add_tensor_438 = None
        mul_tensor_535 = torch.ops.aten.mul.Tensor(reciprocal_default_58, 1);  reciprocal_default_58 = None
        mul_tensor_536 = torch.ops.aten.mul.Tensor(to_dtype_258, mul_tensor_535);  to_dtype_258 = None
        rsub_scalar_58 = torch.ops.aten.rsub.Scalar(mul_tensor_535, 1);  mul_tensor_535 = None
        mul_tensor_537 = torch.ops.aten.mul.Tensor(to_dtype_259, rsub_scalar_58);  to_dtype_259 = rsub_scalar_58 = None
        add_tensor_439 = torch.ops.aten.add.Tensor(mul_tensor_537, 1);  mul_tensor_537 = None
        mul_tensor_538 = torch.ops.aten.mul.Tensor(mul_tensor_536, add_tensor_439);  mul_tensor_536 = add_tensor_439 = None
        to_dtype_260 = torch.ops.aten.to.dtype(mul_tensor_538, torch.float32);  mul_tensor_538 = None
        unsqueeze_default_31 = torch.ops.aten.unsqueeze.default(to_dtype_260, 4);  to_dtype_260 = None
        expand_default_56 = torch.ops.aten.expand.default(unsqueeze_default_31, [1, 88, 80, 80, 2]);  unsqueeze_default_31 = None
        unbind_int_28 = torch.ops.aten.unbind.int(expand_default_56, -1);  expand_default_56 = None
        getitem_1117 = unbind_int_28[0]
        getitem_1118 = unbind_int_28[1];  unbind_int_28 = None
        neg_default_127 = torch.ops.aten.neg.default(getitem_1118)
        div_tensor_280 = torch.ops.aten.div.Tensor(mul_tensor_30, add_tensor_7);  mul_tensor_30 = None
        div_tensor_281 = torch.ops.aten.div.Tensor(div_tensor_280, add_tensor_7);  div_tensor_280 = None
        mul_tensor_539 = torch.ops.aten.mul.Tensor(neg_default_127, div_tensor_281);  neg_default_127 = div_tensor_281 = None
        div_tensor_282 = torch.ops.aten.div.Tensor(getitem_1118, add_tensor_7);  getitem_1118 = add_tensor_7 = None
        sum_default_168 = torch.ops.aten.sum.default(mul_tensor_539);  mul_tensor_539 = None
        mul_tensor_540 = torch.ops.aten.mul.Tensor(div_tensor_282, upsample_nearest2d_vec_3);  upsample_nearest2d_vec_3 = None
        mul_tensor_541 = torch.ops.aten.mul.Tensor(div_tensor_282, select_int_7);  div_tensor_282 = select_int_7 = None
        sum_default_169 = torch.ops.aten.sum.default(mul_tensor_540);  mul_tensor_540 = None
        select_backward_default_68 = torch.ops.aten.select_backward.default(sum_default_169, [2], 0, 1);  sum_default_169 = None
        neg_default_128 = torch.ops.aten.neg.default(getitem_1117)
        div_tensor_283 = torch.ops.aten.div.Tensor(mul_tensor_29, add_tensor_6);  mul_tensor_29 = None
        div_tensor_284 = torch.ops.aten.div.Tensor(div_tensor_283, add_tensor_6);  div_tensor_283 = None
        mul_tensor_542 = torch.ops.aten.mul.Tensor(neg_default_128, div_tensor_284);  neg_default_128 = div_tensor_284 = None
        div_tensor_285 = torch.ops.aten.div.Tensor(getitem_1117, add_tensor_6);  getitem_1117 = add_tensor_6 = None
        sum_default_170 = torch.ops.aten.sum.default(mul_tensor_542);  mul_tensor_542 = None
        add_tensor_440 = torch.ops.aten.add.Tensor(sum_default_168, sum_default_170);  sum_default_168 = sum_default_170 = None
        mul_tensor_543 = torch.ops.aten.mul.Tensor(div_tensor_285, getitem_226);  getitem_226 = None
        mul_tensor_544 = torch.ops.aten.mul.Tensor(div_tensor_285, select_int_6);  div_tensor_285 = select_int_6 = None
        sum_default_171 = torch.ops.aten.sum.default(mul_tensor_543);  mul_tensor_543 = None
        select_backward_default_69 = torch.ops.aten.select_backward.default(sum_default_171, [2], 0, 0);  sum_default_171 = None
        add_tensor_441 = torch.ops.aten.add.Tensor(select_backward_default_68, select_backward_default_69);  select_backward_default_68 = select_backward_default_69 = None
        expand_default_57 = torch.ops.aten.expand.default(add_tensor_440, [2]);  add_tensor_440 = None
        add_tensor_442 = torch.ops.aten.add.Tensor(add_tensor_441, expand_default_57);  add_tensor_441 = expand_default_57 = None
        to_dtype_261 = torch.ops.aten.to.dtype(add_tensor_442, torch.float32);  add_tensor_442 = None
        to_dtype_262 = torch.ops.aten.to.dtype(relu_default_3, torch.float32);  relu_default_3 = None
        le_scalar_28 = torch.ops.aten.le.Scalar(to_dtype_262, 0);  to_dtype_262 = None
        new_zeros_default_436 = torch.ops.aten.new_zeros.default(to_dtype_261, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_28 = torch.ops.aten.where.self(le_scalar_28, new_zeros_default_436, to_dtype_261);  le_scalar_28 = new_zeros_default_436 = to_dtype_261 = None
        to_dtype_263 = torch.ops.aten.to.dtype(where_self_28, torch.float32);  where_self_28 = None
        upsample_nearest2d_backward_vec_12 = torch.ops.aten.upsample_nearest2d_backward.vec(mul_tensor_541, [80, 80], [1, 88, 40, 40], None);  mul_tensor_541 = None
        add_tensor_443 = torch.ops.aten.add.Tensor(mul_tensor_531, upsample_nearest2d_backward_vec_12);  mul_tensor_531 = upsample_nearest2d_backward_vec_12 = None
        native_batch_norm_backward_default_61 = torch.ops.aten.native_batch_norm_backward.default(mul_tensor_544, convolution_default_123, primals_579, primals_577, primals_578, new_zeros_default_222, new_zeros_default_223, False, 0.001, [True, True, True]);  mul_tensor_544 = convolution_default_123 = primals_579 = primals_577 = primals_578 = new_zeros_default_222 = new_zeros_default_223 = None
        getitem_1119 = native_batch_norm_backward_default_61[0]
        getitem_1120 = native_batch_norm_backward_default_61[1]
        getitem_1121 = native_batch_norm_backward_default_61[2];  native_batch_norm_backward_default_61 = None
        convolution_backward_default_140 = torch.ops.aten.convolution_backward.default(getitem_1119, add__tensor_4, primals_581, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_1119 = primals_581 = None
        getitem_1122 = convolution_backward_default_140[0]
        getitem_1123 = convolution_backward_default_140[1]
        getitem_1124 = convolution_backward_default_140[2];  convolution_backward_default_140 = None
        native_batch_norm_backward_default_62 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_443, convolution_default_122, primals_554, primals_552, primals_553, new_zeros_default_219, new_zeros_default_220, False, 0.001, [True, True, True]);  add_tensor_443 = convolution_default_122 = primals_554 = primals_552 = primals_553 = new_zeros_default_219 = new_zeros_default_220 = None
        getitem_1125 = native_batch_norm_backward_default_62[0]
        getitem_1126 = native_batch_norm_backward_default_62[1]
        getitem_1127 = native_batch_norm_backward_default_62[2];  native_batch_norm_backward_default_62 = None
        convolution_backward_default_141 = torch.ops.aten.convolution_backward.default(getitem_1125, convolution_default_121, primals_557, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_1125 = convolution_default_121 = primals_557 = None
        getitem_1128 = convolution_backward_default_141[0]
        getitem_1129 = convolution_backward_default_141[1]
        getitem_1130 = convolution_backward_default_141[2];  convolution_backward_default_141 = None
        convolution_backward_default_142 = torch.ops.aten.convolution_backward.default(getitem_1128, silu__default_70, primals_555, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_1128 = silu__default_70 = primals_555 = None
        getitem_1131 = convolution_backward_default_142[0]
        getitem_1132 = convolution_backward_default_142[1]
        getitem_1133 = convolution_backward_default_142[2];  convolution_backward_default_142 = None
        to_dtype_264 = torch.ops.aten.to.dtype(getitem_1131, torch.float32);  getitem_1131 = None
        to_dtype_265 = torch.ops.aten.to.dtype(clone_default_70, torch.float32);  clone_default_70 = None
        neg_default_129 = torch.ops.aten.neg.default(to_dtype_265)
        exp_default_59 = torch.ops.aten.exp.default(neg_default_129);  neg_default_129 = None
        add_tensor_444 = torch.ops.aten.add.Tensor(exp_default_59, 1);  exp_default_59 = None
        reciprocal_default_59 = torch.ops.aten.reciprocal.default(add_tensor_444);  add_tensor_444 = None
        mul_tensor_545 = torch.ops.aten.mul.Tensor(reciprocal_default_59, 1);  reciprocal_default_59 = None
        mul_tensor_546 = torch.ops.aten.mul.Tensor(to_dtype_264, mul_tensor_545);  to_dtype_264 = None
        rsub_scalar_59 = torch.ops.aten.rsub.Scalar(mul_tensor_545, 1);  mul_tensor_545 = None
        mul_tensor_547 = torch.ops.aten.mul.Tensor(to_dtype_265, rsub_scalar_59);  to_dtype_265 = rsub_scalar_59 = None
        add_tensor_445 = torch.ops.aten.add.Tensor(mul_tensor_547, 1);  mul_tensor_547 = None
        mul_tensor_548 = torch.ops.aten.mul.Tensor(mul_tensor_546, add_tensor_445);  mul_tensor_546 = add_tensor_445 = None
        to_dtype_266 = torch.ops.aten.to.dtype(mul_tensor_548, torch.float32);  mul_tensor_548 = None
        unsqueeze_default_32 = torch.ops.aten.unsqueeze.default(to_dtype_266, 4);  to_dtype_266 = None
        expand_default_58 = torch.ops.aten.expand.default(unsqueeze_default_32, [1, 88, 40, 40, 2]);  unsqueeze_default_32 = None
        unbind_int_29 = torch.ops.aten.unbind.int(expand_default_58, -1);  expand_default_58 = None
        getitem_1134 = unbind_int_29[0]
        getitem_1135 = unbind_int_29[1];  unbind_int_29 = None
        neg_default_130 = torch.ops.aten.neg.default(getitem_1135)
        div_tensor_286 = torch.ops.aten.div.Tensor(mul_tensor_28, add_tensor_5);  mul_tensor_28 = None
        div_tensor_287 = torch.ops.aten.div.Tensor(div_tensor_286, add_tensor_5);  div_tensor_286 = None
        mul_tensor_549 = torch.ops.aten.mul.Tensor(neg_default_130, div_tensor_287);  neg_default_130 = div_tensor_287 = None
        div_tensor_288 = torch.ops.aten.div.Tensor(getitem_1135, add_tensor_5);  getitem_1135 = add_tensor_5 = None
        sum_default_172 = torch.ops.aten.sum.default(mul_tensor_549);  mul_tensor_549 = None
        mul_tensor_550 = torch.ops.aten.mul.Tensor(div_tensor_288, upsample_nearest2d_vec_2);  upsample_nearest2d_vec_2 = None
        mul_tensor_551 = torch.ops.aten.mul.Tensor(div_tensor_288, select_int_5);  div_tensor_288 = select_int_5 = None
        sum_default_173 = torch.ops.aten.sum.default(mul_tensor_550);  mul_tensor_550 = None
        select_backward_default_70 = torch.ops.aten.select_backward.default(sum_default_173, [2], 0, 1);  sum_default_173 = None
        neg_default_131 = torch.ops.aten.neg.default(getitem_1134)
        div_tensor_289 = torch.ops.aten.div.Tensor(mul_tensor_27, add_tensor_4);  mul_tensor_27 = None
        div_tensor_290 = torch.ops.aten.div.Tensor(div_tensor_289, add_tensor_4);  div_tensor_289 = None
        mul_tensor_552 = torch.ops.aten.mul.Tensor(neg_default_131, div_tensor_290);  neg_default_131 = div_tensor_290 = None
        div_tensor_291 = torch.ops.aten.div.Tensor(getitem_1134, add_tensor_4);  getitem_1134 = add_tensor_4 = None
        sum_default_174 = torch.ops.aten.sum.default(mul_tensor_552);  mul_tensor_552 = None
        add_tensor_446 = torch.ops.aten.add.Tensor(sum_default_172, sum_default_174);  sum_default_172 = sum_default_174 = None
        mul_tensor_553 = torch.ops.aten.mul.Tensor(div_tensor_291, getitem_220);  getitem_220 = None
        mul_tensor_554 = torch.ops.aten.mul.Tensor(div_tensor_291, select_int_4);  div_tensor_291 = select_int_4 = None
        sum_default_175 = torch.ops.aten.sum.default(mul_tensor_553);  mul_tensor_553 = None
        select_backward_default_71 = torch.ops.aten.select_backward.default(sum_default_175, [2], 0, 0);  sum_default_175 = None
        add_tensor_447 = torch.ops.aten.add.Tensor(select_backward_default_70, select_backward_default_71);  select_backward_default_70 = select_backward_default_71 = None
        expand_default_59 = torch.ops.aten.expand.default(add_tensor_446, [2]);  add_tensor_446 = None
        add_tensor_448 = torch.ops.aten.add.Tensor(add_tensor_447, expand_default_59);  add_tensor_447 = expand_default_59 = None
        to_dtype_267 = torch.ops.aten.to.dtype(add_tensor_448, torch.float32);  add_tensor_448 = None
        to_dtype_268 = torch.ops.aten.to.dtype(relu_default_2, torch.float32);  relu_default_2 = None
        le_scalar_29 = torch.ops.aten.le.Scalar(to_dtype_268, 0);  to_dtype_268 = None
        new_zeros_default_437 = torch.ops.aten.new_zeros.default(to_dtype_267, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_29 = torch.ops.aten.where.self(le_scalar_29, new_zeros_default_437, to_dtype_267);  le_scalar_29 = new_zeros_default_437 = to_dtype_267 = None
        to_dtype_269 = torch.ops.aten.to.dtype(where_self_29, torch.float32);  where_self_29 = None
        upsample_nearest2d_backward_vec_13 = torch.ops.aten.upsample_nearest2d_backward.vec(mul_tensor_551, [40, 40], [1, 88, 20, 20], None);  mul_tensor_551 = None
        add_tensor_449 = torch.ops.aten.add.Tensor(mul_tensor_518, upsample_nearest2d_backward_vec_13);  mul_tensor_518 = upsample_nearest2d_backward_vec_13 = None
        native_batch_norm_backward_default_63 = torch.ops.aten.native_batch_norm_backward.default(mul_tensor_554, convolution_default_120, primals_563, primals_561, primals_562, new_zeros_default_216, new_zeros_default_217, False, 0.001, [True, True, True]);  mul_tensor_554 = convolution_default_120 = primals_563 = primals_561 = primals_562 = new_zeros_default_216 = new_zeros_default_217 = None
        getitem_1136 = native_batch_norm_backward_default_63[0]
        getitem_1137 = native_batch_norm_backward_default_63[1]
        getitem_1138 = native_batch_norm_backward_default_63[2];  native_batch_norm_backward_default_63 = None
        convolution_backward_default_143 = torch.ops.aten.convolution_backward.default(getitem_1136, add__tensor_10, primals_565, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_1136 = primals_565 = None
        getitem_1139 = convolution_backward_default_143[0]
        getitem_1140 = convolution_backward_default_143[1]
        getitem_1141 = convolution_backward_default_143[2];  convolution_backward_default_143 = None
        add_tensor_450 = torch.ops.aten.add.Tensor(getitem_1105, getitem_1139);  getitem_1105 = getitem_1139 = None
        native_batch_norm_backward_default_64 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_449, convolution_default_119, primals_538, primals_536, primals_537, new_zeros_default_213, new_zeros_default_214, False, 0.001, [True, True, True]);  add_tensor_449 = convolution_default_119 = primals_538 = primals_536 = primals_537 = new_zeros_default_213 = new_zeros_default_214 = None
        getitem_1142 = native_batch_norm_backward_default_64[0]
        getitem_1143 = native_batch_norm_backward_default_64[1]
        getitem_1144 = native_batch_norm_backward_default_64[2];  native_batch_norm_backward_default_64 = None
        convolution_backward_default_144 = torch.ops.aten.convolution_backward.default(getitem_1142, convolution_default_118, primals_541, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_1142 = convolution_default_118 = primals_541 = None
        getitem_1145 = convolution_backward_default_144[0]
        getitem_1146 = convolution_backward_default_144[1]
        getitem_1147 = convolution_backward_default_144[2];  convolution_backward_default_144 = None
        convolution_backward_default_145 = torch.ops.aten.convolution_backward.default(getitem_1145, silu__default_69, primals_539, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_1145 = silu__default_69 = primals_539 = None
        getitem_1148 = convolution_backward_default_145[0]
        getitem_1149 = convolution_backward_default_145[1]
        getitem_1150 = convolution_backward_default_145[2];  convolution_backward_default_145 = None
        to_dtype_270 = torch.ops.aten.to.dtype(getitem_1148, torch.float32);  getitem_1148 = None
        to_dtype_271 = torch.ops.aten.to.dtype(clone_default_69, torch.float32);  clone_default_69 = None
        neg_default_132 = torch.ops.aten.neg.default(to_dtype_271)
        exp_default_60 = torch.ops.aten.exp.default(neg_default_132);  neg_default_132 = None
        add_tensor_451 = torch.ops.aten.add.Tensor(exp_default_60, 1);  exp_default_60 = None
        reciprocal_default_60 = torch.ops.aten.reciprocal.default(add_tensor_451);  add_tensor_451 = None
        mul_tensor_555 = torch.ops.aten.mul.Tensor(reciprocal_default_60, 1);  reciprocal_default_60 = None
        mul_tensor_556 = torch.ops.aten.mul.Tensor(to_dtype_270, mul_tensor_555);  to_dtype_270 = None
        rsub_scalar_60 = torch.ops.aten.rsub.Scalar(mul_tensor_555, 1);  mul_tensor_555 = None
        mul_tensor_557 = torch.ops.aten.mul.Tensor(to_dtype_271, rsub_scalar_60);  to_dtype_271 = rsub_scalar_60 = None
        add_tensor_452 = torch.ops.aten.add.Tensor(mul_tensor_557, 1);  mul_tensor_557 = None
        mul_tensor_558 = torch.ops.aten.mul.Tensor(mul_tensor_556, add_tensor_452);  mul_tensor_556 = add_tensor_452 = None
        to_dtype_272 = torch.ops.aten.to.dtype(mul_tensor_558, torch.float32);  mul_tensor_558 = None
        unsqueeze_default_33 = torch.ops.aten.unsqueeze.default(to_dtype_272, 4);  to_dtype_272 = None
        expand_default_60 = torch.ops.aten.expand.default(unsqueeze_default_33, [1, 88, 20, 20, 2]);  unsqueeze_default_33 = None
        unbind_int_30 = torch.ops.aten.unbind.int(expand_default_60, -1);  expand_default_60 = None
        getitem_1151 = unbind_int_30[0]
        getitem_1152 = unbind_int_30[1];  unbind_int_30 = None
        neg_default_133 = torch.ops.aten.neg.default(getitem_1152)
        div_tensor_292 = torch.ops.aten.div.Tensor(mul_tensor_26, add_tensor_3);  mul_tensor_26 = None
        div_tensor_293 = torch.ops.aten.div.Tensor(div_tensor_292, add_tensor_3);  div_tensor_292 = None
        mul_tensor_559 = torch.ops.aten.mul.Tensor(neg_default_133, div_tensor_293);  neg_default_133 = div_tensor_293 = None
        div_tensor_294 = torch.ops.aten.div.Tensor(getitem_1152, add_tensor_3);  getitem_1152 = add_tensor_3 = None
        sum_default_176 = torch.ops.aten.sum.default(mul_tensor_559);  mul_tensor_559 = None
        mul_tensor_560 = torch.ops.aten.mul.Tensor(div_tensor_294, upsample_nearest2d_vec_1);  upsample_nearest2d_vec_1 = None
        mul_tensor_561 = torch.ops.aten.mul.Tensor(div_tensor_294, select_int_3);  div_tensor_294 = select_int_3 = None
        sum_default_177 = torch.ops.aten.sum.default(mul_tensor_560);  mul_tensor_560 = None
        select_backward_default_72 = torch.ops.aten.select_backward.default(sum_default_177, [2], 0, 1);  sum_default_177 = None
        neg_default_134 = torch.ops.aten.neg.default(getitem_1151)
        div_tensor_295 = torch.ops.aten.div.Tensor(mul_tensor_25, add_tensor_2);  mul_tensor_25 = None
        div_tensor_296 = torch.ops.aten.div.Tensor(div_tensor_295, add_tensor_2);  div_tensor_295 = None
        mul_tensor_562 = torch.ops.aten.mul.Tensor(neg_default_134, div_tensor_296);  neg_default_134 = div_tensor_296 = None
        div_tensor_297 = torch.ops.aten.div.Tensor(getitem_1151, add_tensor_2);  getitem_1151 = add_tensor_2 = None
        sum_default_178 = torch.ops.aten.sum.default(mul_tensor_562);  mul_tensor_562 = None
        add_tensor_453 = torch.ops.aten.add.Tensor(sum_default_176, sum_default_178);  sum_default_176 = sum_default_178 = None
        mul_tensor_563 = torch.ops.aten.mul.Tensor(div_tensor_297, getitem_214);  getitem_214 = None
        mul_tensor_564 = torch.ops.aten.mul.Tensor(div_tensor_297, select_int_2);  div_tensor_297 = select_int_2 = None
        sum_default_179 = torch.ops.aten.sum.default(mul_tensor_563);  mul_tensor_563 = None
        select_backward_default_73 = torch.ops.aten.select_backward.default(sum_default_179, [2], 0, 0);  sum_default_179 = None
        add_tensor_454 = torch.ops.aten.add.Tensor(select_backward_default_72, select_backward_default_73);  select_backward_default_72 = select_backward_default_73 = None
        expand_default_61 = torch.ops.aten.expand.default(add_tensor_453, [2]);  add_tensor_453 = None
        add_tensor_455 = torch.ops.aten.add.Tensor(add_tensor_454, expand_default_61);  add_tensor_454 = expand_default_61 = None
        to_dtype_273 = torch.ops.aten.to.dtype(add_tensor_455, torch.float32);  add_tensor_455 = None
        to_dtype_274 = torch.ops.aten.to.dtype(relu_default_1, torch.float32);  relu_default_1 = None
        le_scalar_30 = torch.ops.aten.le.Scalar(to_dtype_274, 0);  to_dtype_274 = None
        new_zeros_default_438 = torch.ops.aten.new_zeros.default(to_dtype_273, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_30 = torch.ops.aten.where.self(le_scalar_30, new_zeros_default_438, to_dtype_273);  le_scalar_30 = new_zeros_default_438 = to_dtype_273 = None
        to_dtype_275 = torch.ops.aten.to.dtype(where_self_30, torch.float32);  where_self_30 = None
        upsample_nearest2d_backward_vec_14 = torch.ops.aten.upsample_nearest2d_backward.vec(mul_tensor_561, [20, 20], [1, 88, 10, 10], None);  mul_tensor_561 = None
        add_tensor_456 = torch.ops.aten.add.Tensor(mul_tensor_505, upsample_nearest2d_backward_vec_14);  mul_tensor_505 = upsample_nearest2d_backward_vec_14 = None
        native_batch_norm_backward_default_65 = torch.ops.aten.native_batch_norm_backward.default(mul_tensor_564, convolution_default_117, primals_547, primals_545, primals_546, new_zeros_default_210, new_zeros_default_211, False, 0.001, [True, True, True]);  mul_tensor_564 = convolution_default_117 = primals_547 = primals_545 = primals_546 = new_zeros_default_210 = new_zeros_default_211 = None
        getitem_1153 = native_batch_norm_backward_default_65[0]
        getitem_1154 = native_batch_norm_backward_default_65[1]
        getitem_1155 = native_batch_norm_backward_default_65[2];  native_batch_norm_backward_default_65 = None
        convolution_backward_default_146 = torch.ops.aten.convolution_backward.default(getitem_1153, add__tensor_15, primals_549, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_1153 = primals_549 = None
        getitem_1156 = convolution_backward_default_146[0]
        getitem_1157 = convolution_backward_default_146[1]
        getitem_1158 = convolution_backward_default_146[2];  convolution_backward_default_146 = None
        add_tensor_457 = torch.ops.aten.add.Tensor(getitem_1087, getitem_1156);  getitem_1087 = getitem_1156 = None
        native_batch_norm_backward_default_66 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_456, convolution_default_116, primals_529, primals_527, primals_528, new_zeros_default_207, new_zeros_default_208, False, 0.001, [True, True, True]);  add_tensor_456 = convolution_default_116 = primals_529 = primals_527 = primals_528 = new_zeros_default_207 = new_zeros_default_208 = None
        getitem_1159 = native_batch_norm_backward_default_66[0]
        getitem_1160 = native_batch_norm_backward_default_66[1]
        getitem_1161 = native_batch_norm_backward_default_66[2];  native_batch_norm_backward_default_66 = None
        convolution_backward_default_147 = torch.ops.aten.convolution_backward.default(getitem_1159, convolution_default_115, primals_532, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_1159 = convolution_default_115 = primals_532 = None
        getitem_1162 = convolution_backward_default_147[0]
        getitem_1163 = convolution_backward_default_147[1]
        getitem_1164 = convolution_backward_default_147[2];  convolution_backward_default_147 = None
        convolution_backward_default_148 = torch.ops.aten.convolution_backward.default(getitem_1162, silu__default_68, primals_530, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 88, [True, True, False]);  getitem_1162 = silu__default_68 = primals_530 = None
        getitem_1165 = convolution_backward_default_148[0]
        getitem_1166 = convolution_backward_default_148[1]
        getitem_1167 = convolution_backward_default_148[2];  convolution_backward_default_148 = None
        to_dtype_276 = torch.ops.aten.to.dtype(getitem_1165, torch.float32);  getitem_1165 = None
        to_dtype_277 = torch.ops.aten.to.dtype(clone_default_68, torch.float32);  clone_default_68 = None
        neg_default_135 = torch.ops.aten.neg.default(to_dtype_277)
        exp_default_61 = torch.ops.aten.exp.default(neg_default_135);  neg_default_135 = None
        add_tensor_458 = torch.ops.aten.add.Tensor(exp_default_61, 1);  exp_default_61 = None
        reciprocal_default_61 = torch.ops.aten.reciprocal.default(add_tensor_458);  add_tensor_458 = None
        mul_tensor_565 = torch.ops.aten.mul.Tensor(reciprocal_default_61, 1);  reciprocal_default_61 = None
        mul_tensor_566 = torch.ops.aten.mul.Tensor(to_dtype_276, mul_tensor_565);  to_dtype_276 = None
        rsub_scalar_61 = torch.ops.aten.rsub.Scalar(mul_tensor_565, 1);  mul_tensor_565 = None
        mul_tensor_567 = torch.ops.aten.mul.Tensor(to_dtype_277, rsub_scalar_61);  to_dtype_277 = rsub_scalar_61 = None
        add_tensor_459 = torch.ops.aten.add.Tensor(mul_tensor_567, 1);  mul_tensor_567 = None
        mul_tensor_568 = torch.ops.aten.mul.Tensor(mul_tensor_566, add_tensor_459);  mul_tensor_566 = add_tensor_459 = None
        to_dtype_278 = torch.ops.aten.to.dtype(mul_tensor_568, torch.float32);  mul_tensor_568 = None
        unsqueeze_default_34 = torch.ops.aten.unsqueeze.default(to_dtype_278, 4);  to_dtype_278 = None
        expand_default_62 = torch.ops.aten.expand.default(unsqueeze_default_34, [1, 88, 10, 10, 2]);  unsqueeze_default_34 = None
        unbind_int_31 = torch.ops.aten.unbind.int(expand_default_62, -1);  expand_default_62 = None
        getitem_1168 = unbind_int_31[0]
        getitem_1169 = unbind_int_31[1];  unbind_int_31 = None
        neg_default_136 = torch.ops.aten.neg.default(getitem_1169)
        div_tensor_298 = torch.ops.aten.div.Tensor(mul_tensor_24, add_tensor_1);  mul_tensor_24 = None
        div_tensor_299 = torch.ops.aten.div.Tensor(div_tensor_298, add_tensor_1);  div_tensor_298 = None
        mul_tensor_569 = torch.ops.aten.mul.Tensor(neg_default_136, div_tensor_299);  neg_default_136 = div_tensor_299 = None
        div_tensor_300 = torch.ops.aten.div.Tensor(getitem_1169, add_tensor_1);  getitem_1169 = add_tensor_1 = None
        sum_default_180 = torch.ops.aten.sum.default(mul_tensor_569);  mul_tensor_569 = None
        mul_tensor_570 = torch.ops.aten.mul.Tensor(div_tensor_300, upsample_nearest2d_vec);  upsample_nearest2d_vec = None
        mul_tensor_571 = torch.ops.aten.mul.Tensor(div_tensor_300, select_int_1);  div_tensor_300 = select_int_1 = None
        sum_default_181 = torch.ops.aten.sum.default(mul_tensor_570);  mul_tensor_570 = None
        select_backward_default_74 = torch.ops.aten.select_backward.default(sum_default_181, [2], 0, 1);  sum_default_181 = None
        neg_default_137 = torch.ops.aten.neg.default(getitem_1168)
        div_tensor_301 = torch.ops.aten.div.Tensor(mul_tensor_23, add_tensor);  mul_tensor_23 = None
        div_tensor_302 = torch.ops.aten.div.Tensor(div_tensor_301, add_tensor);  div_tensor_301 = None
        mul_tensor_572 = torch.ops.aten.mul.Tensor(neg_default_137, div_tensor_302);  neg_default_137 = div_tensor_302 = None
        div_tensor_303 = torch.ops.aten.div.Tensor(getitem_1168, add_tensor);  getitem_1168 = add_tensor = None
        sum_default_182 = torch.ops.aten.sum.default(mul_tensor_572);  mul_tensor_572 = None
        add_tensor_460 = torch.ops.aten.add.Tensor(sum_default_180, sum_default_182);  sum_default_180 = sum_default_182 = None
        mul_tensor_573 = torch.ops.aten.mul.Tensor(div_tensor_303, getitem_207);  getitem_207 = None
        mul_tensor_574 = torch.ops.aten.mul.Tensor(div_tensor_303, select_int);  div_tensor_303 = select_int = None
        sum_default_183 = torch.ops.aten.sum.default(mul_tensor_573);  mul_tensor_573 = None
        add_tensor_461 = torch.ops.aten.add.Tensor(mul_tensor_508, mul_tensor_574);  mul_tensor_508 = mul_tensor_574 = None
        select_backward_default_75 = torch.ops.aten.select_backward.default(sum_default_183, [2], 0, 0);  sum_default_183 = None
        add_tensor_462 = torch.ops.aten.add.Tensor(select_backward_default_74, select_backward_default_75);  select_backward_default_74 = select_backward_default_75 = None
        expand_default_63 = torch.ops.aten.expand.default(add_tensor_460, [2]);  add_tensor_460 = None
        add_tensor_463 = torch.ops.aten.add.Tensor(add_tensor_462, expand_default_63);  add_tensor_462 = expand_default_63 = None
        to_dtype_279 = torch.ops.aten.to.dtype(add_tensor_463, torch.float32);  add_tensor_463 = None
        to_dtype_280 = torch.ops.aten.to.dtype(relu_default, torch.float32);  relu_default = None
        le_scalar_31 = torch.ops.aten.le.Scalar(to_dtype_280, 0);  to_dtype_280 = None
        new_zeros_default_439 = torch.ops.aten.new_zeros.default(to_dtype_279, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_31 = torch.ops.aten.where.self(le_scalar_31, new_zeros_default_439, to_dtype_279);  le_scalar_31 = new_zeros_default_439 = to_dtype_279 = None
        to_dtype_281 = torch.ops.aten.to.dtype(where_self_31, torch.float32);  where_self_31 = None
        upsample_nearest2d_backward_vec_15 = torch.ops.aten.upsample_nearest2d_backward.vec(mul_tensor_571, [10, 10], [1, 88, 5, 5], None);  mul_tensor_571 = None
        add_tensor_464 = torch.ops.aten.add.Tensor(mul_tensor_495, upsample_nearest2d_backward_vec_15);  mul_tensor_495 = upsample_nearest2d_backward_vec_15 = None
        max_pool2d_with_indices_backward_default_16 = torch.ops.aten.max_pool2d_with_indices_backward.default(add_tensor_464, constant_pad_nd_default_6, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_210);  add_tensor_464 = constant_pad_nd_default_6 = getitem_210 = None
        constant_pad_nd_default_39 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default_16, [0, -1, 0, -1]);  max_pool2d_with_indices_backward_default_16 = None
        add_tensor_465 = torch.ops.aten.add.Tensor(add_tensor_461, constant_pad_nd_default_39);  add_tensor_461 = constant_pad_nd_default_39 = None
        max_pool2d_with_indices_backward_default_17 = torch.ops.aten.max_pool2d_with_indices_backward.default(add_tensor_465, constant_pad_nd_default_5, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_208);  add_tensor_465 = constant_pad_nd_default_5 = getitem_208 = None
        constant_pad_nd_default_40 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default_17, [0, -1, 0, -1]);  max_pool2d_with_indices_backward_default_17 = None
        native_batch_norm_backward_default_67 = torch.ops.aten.native_batch_norm_backward.default(constant_pad_nd_default_40, convolution_default_114, primals_852, primals_850, primals_851, new_zeros_default_204, new_zeros_default_205, False, 0.001, [True, True, True]);  constant_pad_nd_default_40 = convolution_default_114 = primals_852 = primals_850 = primals_851 = new_zeros_default_204 = new_zeros_default_205 = None
        getitem_1170 = native_batch_norm_backward_default_67[0]
        getitem_1171 = native_batch_norm_backward_default_67[1]
        getitem_1172 = native_batch_norm_backward_default_67[2];  native_batch_norm_backward_default_67 = None
        convolution_backward_default_149 = torch.ops.aten.convolution_backward.default(getitem_1170, add__tensor_15, primals_854, [88], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_1170 = add__tensor_15 = primals_854 = None
        getitem_1173 = convolution_backward_default_149[0]
        getitem_1174 = convolution_backward_default_149[1]
        getitem_1175 = convolution_backward_default_149[2];  convolution_backward_default_149 = None
        add_tensor_466 = torch.ops.aten.add.Tensor(add_tensor_457, getitem_1173);  add_tensor_457 = getitem_1173 = None
        native_batch_norm_backward_default_68 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_466, convolution_default_113, primals_487, primals_485, primals_486, new_zeros_default_201, new_zeros_default_202, False, 0.001, [True, True, True]);  convolution_default_113 = primals_487 = primals_485 = primals_486 = new_zeros_default_201 = new_zeros_default_202 = None
        getitem_1176 = native_batch_norm_backward_default_68[0]
        getitem_1177 = native_batch_norm_backward_default_68[1]
        getitem_1178 = native_batch_norm_backward_default_68[2];  native_batch_norm_backward_default_68 = None
        convolution_backward_default_150 = torch.ops.aten.convolution_backward.default(getitem_1176, mul_tensor_22, primals_490, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1176 = mul_tensor_22 = primals_490 = None
        getitem_1179 = convolution_backward_default_150[0]
        getitem_1180 = convolution_backward_default_150[1]
        getitem_1181 = convolution_backward_default_150[2];  convolution_backward_default_150 = None
        mul_tensor_575 = torch.ops.aten.mul.Tensor(getitem_1179, silu__default_66);  silu__default_66 = None
        mul_tensor_576 = torch.ops.aten.mul.Tensor(getitem_1179, sigmoid_default_22);  getitem_1179 = None
        sum_dim_int_list_32 = torch.ops.aten.sum.dim_IntList(mul_tensor_575, [2, 3], True);  mul_tensor_575 = None
        to_dtype_282 = torch.ops.aten.to.dtype(sum_dim_int_list_32, torch.float32);  sum_dim_int_list_32 = None
        to_dtype_283 = torch.ops.aten.to.dtype(sigmoid_default_22, torch.float32);  sigmoid_default_22 = None
        rsub_scalar_62 = torch.ops.aten.rsub.Scalar(to_dtype_283, 1)
        mul_tensor_577 = torch.ops.aten.mul.Tensor(to_dtype_283, rsub_scalar_62);  to_dtype_283 = rsub_scalar_62 = None
        conj_physical_default = torch.ops.aten.conj_physical.default(mul_tensor_577);  mul_tensor_577 = None
        mul_tensor_578 = torch.ops.aten.mul.Tensor(to_dtype_282, conj_physical_default);  to_dtype_282 = conj_physical_default = None
        to_dtype_284 = torch.ops.aten.to.dtype(mul_tensor_578, torch.float32);  mul_tensor_578 = None
        convolution_backward_default_151 = torch.ops.aten.convolution_backward.default(to_dtype_284, silu__default_67, primals_492, [1920], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_284 = silu__default_67 = primals_492 = None
        getitem_1182 = convolution_backward_default_151[0]
        getitem_1183 = convolution_backward_default_151[1]
        getitem_1184 = convolution_backward_default_151[2];  convolution_backward_default_151 = None
        to_dtype_285 = torch.ops.aten.to.dtype(getitem_1182, torch.float32);  getitem_1182 = None
        to_dtype_286 = torch.ops.aten.to.dtype(clone_default_67, torch.float32);  clone_default_67 = None
        neg_default_138 = torch.ops.aten.neg.default(to_dtype_286)
        exp_default_62 = torch.ops.aten.exp.default(neg_default_138);  neg_default_138 = None
        add_tensor_467 = torch.ops.aten.add.Tensor(exp_default_62, 1);  exp_default_62 = None
        reciprocal_default_62 = torch.ops.aten.reciprocal.default(add_tensor_467);  add_tensor_467 = None
        mul_tensor_579 = torch.ops.aten.mul.Tensor(reciprocal_default_62, 1);  reciprocal_default_62 = None
        mul_tensor_580 = torch.ops.aten.mul.Tensor(to_dtype_285, mul_tensor_579);  to_dtype_285 = None
        rsub_scalar_63 = torch.ops.aten.rsub.Scalar(mul_tensor_579, 1);  mul_tensor_579 = None
        mul_tensor_581 = torch.ops.aten.mul.Tensor(to_dtype_286, rsub_scalar_63);  to_dtype_286 = rsub_scalar_63 = None
        add_tensor_468 = torch.ops.aten.add.Tensor(mul_tensor_581, 1);  mul_tensor_581 = None
        mul_tensor_582 = torch.ops.aten.mul.Tensor(mul_tensor_580, add_tensor_468);  mul_tensor_580 = add_tensor_468 = None
        to_dtype_287 = torch.ops.aten.to.dtype(mul_tensor_582, torch.float32);  mul_tensor_582 = None
        convolution_backward_default_152 = torch.ops.aten.convolution_backward.default(to_dtype_287, mean_dim_22, primals_494, [80], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_287 = mean_dim_22 = primals_494 = None
        getitem_1185 = convolution_backward_default_152[0]
        getitem_1186 = convolution_backward_default_152[1]
        getitem_1187 = convolution_backward_default_152[2];  convolution_backward_default_152 = None
        expand_default_64 = torch.ops.aten.expand.default(getitem_1185, [1, 1920, 20, 20]);  getitem_1185 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default_64, 400);  expand_default_64 = None
        add_tensor_469 = torch.ops.aten.add.Tensor(mul_tensor_576, div_scalar);  mul_tensor_576 = div_scalar = None
        to_dtype_288 = torch.ops.aten.to.dtype(add_tensor_469, torch.float32);  add_tensor_469 = None
        to_dtype_289 = torch.ops.aten.to.dtype(clone_default_66, torch.float32);  clone_default_66 = None
        neg_default_139 = torch.ops.aten.neg.default(to_dtype_289)
        exp_default_63 = torch.ops.aten.exp.default(neg_default_139);  neg_default_139 = None
        add_tensor_470 = torch.ops.aten.add.Tensor(exp_default_63, 1);  exp_default_63 = None
        reciprocal_default_63 = torch.ops.aten.reciprocal.default(add_tensor_470);  add_tensor_470 = None
        mul_tensor_583 = torch.ops.aten.mul.Tensor(reciprocal_default_63, 1);  reciprocal_default_63 = None
        mul_tensor_584 = torch.ops.aten.mul.Tensor(to_dtype_288, mul_tensor_583);  to_dtype_288 = None
        rsub_scalar_64 = torch.ops.aten.rsub.Scalar(mul_tensor_583, 1);  mul_tensor_583 = None
        mul_tensor_585 = torch.ops.aten.mul.Tensor(to_dtype_289, rsub_scalar_64);  to_dtype_289 = rsub_scalar_64 = None
        add_tensor_471 = torch.ops.aten.add.Tensor(mul_tensor_585, 1);  mul_tensor_585 = None
        mul_tensor_586 = torch.ops.aten.mul.Tensor(mul_tensor_584, add_tensor_471);  mul_tensor_584 = add_tensor_471 = None
        to_dtype_290 = torch.ops.aten.to.dtype(mul_tensor_586, torch.float32);  mul_tensor_586 = None
        native_batch_norm_backward_default_69 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_290, convolution_default_110, primals_482, primals_480, primals_481, new_zeros_default_198, new_zeros_default_199, False, 0.001, [True, True, True]);  to_dtype_290 = convolution_default_110 = primals_482 = primals_480 = primals_481 = new_zeros_default_198 = new_zeros_default_199 = None
        getitem_1188 = native_batch_norm_backward_default_69[0]
        getitem_1189 = native_batch_norm_backward_default_69[1]
        getitem_1190 = native_batch_norm_backward_default_69[2];  native_batch_norm_backward_default_69 = None
        convolution_backward_default_153 = torch.ops.aten.convolution_backward.default(getitem_1188, silu__default_65, primals_488, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1920, [True, True, False]);  getitem_1188 = silu__default_65 = primals_488 = None
        getitem_1191 = convolution_backward_default_153[0]
        getitem_1192 = convolution_backward_default_153[1]
        getitem_1193 = convolution_backward_default_153[2];  convolution_backward_default_153 = None
        to_dtype_291 = torch.ops.aten.to.dtype(getitem_1191, torch.float32);  getitem_1191 = None
        to_dtype_292 = torch.ops.aten.to.dtype(clone_default_65, torch.float32);  clone_default_65 = None
        neg_default_140 = torch.ops.aten.neg.default(to_dtype_292)
        exp_default_64 = torch.ops.aten.exp.default(neg_default_140);  neg_default_140 = None
        add_tensor_472 = torch.ops.aten.add.Tensor(exp_default_64, 1);  exp_default_64 = None
        reciprocal_default_64 = torch.ops.aten.reciprocal.default(add_tensor_472);  add_tensor_472 = None
        mul_tensor_587 = torch.ops.aten.mul.Tensor(reciprocal_default_64, 1);  reciprocal_default_64 = None
        mul_tensor_588 = torch.ops.aten.mul.Tensor(to_dtype_291, mul_tensor_587);  to_dtype_291 = None
        rsub_scalar_65 = torch.ops.aten.rsub.Scalar(mul_tensor_587, 1);  mul_tensor_587 = None
        mul_tensor_589 = torch.ops.aten.mul.Tensor(to_dtype_292, rsub_scalar_65);  to_dtype_292 = rsub_scalar_65 = None
        add_tensor_473 = torch.ops.aten.add.Tensor(mul_tensor_589, 1);  mul_tensor_589 = None
        mul_tensor_590 = torch.ops.aten.mul.Tensor(mul_tensor_588, add_tensor_473);  mul_tensor_588 = add_tensor_473 = None
        to_dtype_293 = torch.ops.aten.to.dtype(mul_tensor_590, torch.float32);  mul_tensor_590 = None
        native_batch_norm_backward_default_70 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_293, convolution_default_109, primals_477, primals_475, primals_476, new_zeros_default_195, new_zeros_default_196, False, 0.001, [True, True, True]);  to_dtype_293 = convolution_default_109 = primals_477 = primals_475 = primals_476 = new_zeros_default_195 = new_zeros_default_196 = None
        getitem_1194 = native_batch_norm_backward_default_70[0]
        getitem_1195 = native_batch_norm_backward_default_70[1]
        getitem_1196 = native_batch_norm_backward_default_70[2];  native_batch_norm_backward_default_70 = None
        convolution_backward_default_154 = torch.ops.aten.convolution_backward.default(getitem_1194, getitem_192, primals_489, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1194 = getitem_192 = primals_489 = None
        getitem_1197 = convolution_backward_default_154[0]
        getitem_1198 = convolution_backward_default_154[1]
        getitem_1199 = convolution_backward_default_154[2];  convolution_backward_default_154 = None
        add_tensor_474 = torch.ops.aten.add.Tensor(add_tensor_466, getitem_1197);  add_tensor_466 = getitem_1197 = None
        native_batch_norm_backward_default_71 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_474, convolution_default_108, primals_465, primals_463, primals_464, new_zeros_default_192, new_zeros_default_193, False, 0.001, [True, True, True]);  add_tensor_474 = convolution_default_108 = primals_465 = primals_463 = primals_464 = new_zeros_default_192 = new_zeros_default_193 = None
        getitem_1200 = native_batch_norm_backward_default_71[0]
        getitem_1201 = native_batch_norm_backward_default_71[1]
        getitem_1202 = native_batch_norm_backward_default_71[2];  native_batch_norm_backward_default_71 = None
        convolution_backward_default_155 = torch.ops.aten.convolution_backward.default(getitem_1200, mul_tensor_21, primals_468, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1200 = mul_tensor_21 = primals_468 = None
        getitem_1203 = convolution_backward_default_155[0]
        getitem_1204 = convolution_backward_default_155[1]
        getitem_1205 = convolution_backward_default_155[2];  convolution_backward_default_155 = None
        mul_tensor_591 = torch.ops.aten.mul.Tensor(getitem_1203, silu__default_63);  silu__default_63 = None
        mul_tensor_592 = torch.ops.aten.mul.Tensor(getitem_1203, sigmoid_default_21);  getitem_1203 = None
        sum_dim_int_list_33 = torch.ops.aten.sum.dim_IntList(mul_tensor_591, [2, 3], True);  mul_tensor_591 = None
        to_dtype_294 = torch.ops.aten.to.dtype(sum_dim_int_list_33, torch.float32);  sum_dim_int_list_33 = None
        to_dtype_295 = torch.ops.aten.to.dtype(sigmoid_default_21, torch.float32);  sigmoid_default_21 = None
        rsub_scalar_66 = torch.ops.aten.rsub.Scalar(to_dtype_295, 1)
        mul_tensor_593 = torch.ops.aten.mul.Tensor(to_dtype_295, rsub_scalar_66);  to_dtype_295 = rsub_scalar_66 = None
        conj_physical_default_1 = torch.ops.aten.conj_physical.default(mul_tensor_593);  mul_tensor_593 = None
        mul_tensor_594 = torch.ops.aten.mul.Tensor(to_dtype_294, conj_physical_default_1);  to_dtype_294 = conj_physical_default_1 = None
        to_dtype_296 = torch.ops.aten.to.dtype(mul_tensor_594, torch.float32);  mul_tensor_594 = None
        convolution_backward_default_156 = torch.ops.aten.convolution_backward.default(to_dtype_296, silu__default_64, primals_470, [1152], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_296 = silu__default_64 = primals_470 = None
        getitem_1206 = convolution_backward_default_156[0]
        getitem_1207 = convolution_backward_default_156[1]
        getitem_1208 = convolution_backward_default_156[2];  convolution_backward_default_156 = None
        to_dtype_297 = torch.ops.aten.to.dtype(getitem_1206, torch.float32);  getitem_1206 = None
        to_dtype_298 = torch.ops.aten.to.dtype(clone_default_64, torch.float32);  clone_default_64 = None
        neg_default_141 = torch.ops.aten.neg.default(to_dtype_298)
        exp_default_65 = torch.ops.aten.exp.default(neg_default_141);  neg_default_141 = None
        add_tensor_475 = torch.ops.aten.add.Tensor(exp_default_65, 1);  exp_default_65 = None
        reciprocal_default_65 = torch.ops.aten.reciprocal.default(add_tensor_475);  add_tensor_475 = None
        mul_tensor_595 = torch.ops.aten.mul.Tensor(reciprocal_default_65, 1);  reciprocal_default_65 = None
        mul_tensor_596 = torch.ops.aten.mul.Tensor(to_dtype_297, mul_tensor_595);  to_dtype_297 = None
        rsub_scalar_67 = torch.ops.aten.rsub.Scalar(mul_tensor_595, 1);  mul_tensor_595 = None
        mul_tensor_597 = torch.ops.aten.mul.Tensor(to_dtype_298, rsub_scalar_67);  to_dtype_298 = rsub_scalar_67 = None
        add_tensor_476 = torch.ops.aten.add.Tensor(mul_tensor_597, 1);  mul_tensor_597 = None
        mul_tensor_598 = torch.ops.aten.mul.Tensor(mul_tensor_596, add_tensor_476);  mul_tensor_596 = add_tensor_476 = None
        to_dtype_299 = torch.ops.aten.to.dtype(mul_tensor_598, torch.float32);  mul_tensor_598 = None
        convolution_backward_default_157 = torch.ops.aten.convolution_backward.default(to_dtype_299, mean_dim_21, primals_472, [48], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_299 = mean_dim_21 = primals_472 = None
        getitem_1209 = convolution_backward_default_157[0]
        getitem_1210 = convolution_backward_default_157[1]
        getitem_1211 = convolution_backward_default_157[2];  convolution_backward_default_157 = None
        expand_default_65 = torch.ops.aten.expand.default(getitem_1209, [1, 1152, 20, 20]);  getitem_1209 = None
        div_scalar_1 = torch.ops.aten.div.Scalar(expand_default_65, 400);  expand_default_65 = None
        add_tensor_477 = torch.ops.aten.add.Tensor(mul_tensor_592, div_scalar_1);  mul_tensor_592 = div_scalar_1 = None
        to_dtype_300 = torch.ops.aten.to.dtype(add_tensor_477, torch.float32);  add_tensor_477 = None
        to_dtype_301 = torch.ops.aten.to.dtype(clone_default_63, torch.float32);  clone_default_63 = None
        neg_default_142 = torch.ops.aten.neg.default(to_dtype_301)
        exp_default_66 = torch.ops.aten.exp.default(neg_default_142);  neg_default_142 = None
        add_tensor_478 = torch.ops.aten.add.Tensor(exp_default_66, 1);  exp_default_66 = None
        reciprocal_default_66 = torch.ops.aten.reciprocal.default(add_tensor_478);  add_tensor_478 = None
        mul_tensor_599 = torch.ops.aten.mul.Tensor(reciprocal_default_66, 1);  reciprocal_default_66 = None
        mul_tensor_600 = torch.ops.aten.mul.Tensor(to_dtype_300, mul_tensor_599);  to_dtype_300 = None
        rsub_scalar_68 = torch.ops.aten.rsub.Scalar(mul_tensor_599, 1);  mul_tensor_599 = None
        mul_tensor_601 = torch.ops.aten.mul.Tensor(to_dtype_301, rsub_scalar_68);  to_dtype_301 = rsub_scalar_68 = None
        add_tensor_479 = torch.ops.aten.add.Tensor(mul_tensor_601, 1);  mul_tensor_601 = None
        mul_tensor_602 = torch.ops.aten.mul.Tensor(mul_tensor_600, add_tensor_479);  mul_tensor_600 = add_tensor_479 = None
        to_dtype_302 = torch.ops.aten.to.dtype(mul_tensor_602, torch.float32);  mul_tensor_602 = None
        native_batch_norm_backward_default_72 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_302, convolution_default_105, primals_460, primals_458, primals_459, new_zeros_default_189, new_zeros_default_190, False, 0.001, [True, True, True]);  to_dtype_302 = convolution_default_105 = primals_460 = primals_458 = primals_459 = new_zeros_default_189 = new_zeros_default_190 = None
        getitem_1212 = native_batch_norm_backward_default_72[0]
        getitem_1213 = native_batch_norm_backward_default_72[1]
        getitem_1214 = native_batch_norm_backward_default_72[2];  native_batch_norm_backward_default_72 = None
        convolution_backward_default_158 = torch.ops.aten.convolution_backward.default(getitem_1212, silu__default_62, primals_466, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1152, [True, True, False]);  getitem_1212 = silu__default_62 = primals_466 = None
        getitem_1215 = convolution_backward_default_158[0]
        getitem_1216 = convolution_backward_default_158[1]
        getitem_1217 = convolution_backward_default_158[2];  convolution_backward_default_158 = None
        to_dtype_303 = torch.ops.aten.to.dtype(getitem_1215, torch.float32);  getitem_1215 = None
        to_dtype_304 = torch.ops.aten.to.dtype(clone_default_62, torch.float32);  clone_default_62 = None
        neg_default_143 = torch.ops.aten.neg.default(to_dtype_304)
        exp_default_67 = torch.ops.aten.exp.default(neg_default_143);  neg_default_143 = None
        add_tensor_480 = torch.ops.aten.add.Tensor(exp_default_67, 1);  exp_default_67 = None
        reciprocal_default_67 = torch.ops.aten.reciprocal.default(add_tensor_480);  add_tensor_480 = None
        mul_tensor_603 = torch.ops.aten.mul.Tensor(reciprocal_default_67, 1);  reciprocal_default_67 = None
        mul_tensor_604 = torch.ops.aten.mul.Tensor(to_dtype_303, mul_tensor_603);  to_dtype_303 = None
        rsub_scalar_69 = torch.ops.aten.rsub.Scalar(mul_tensor_603, 1);  mul_tensor_603 = None
        mul_tensor_605 = torch.ops.aten.mul.Tensor(to_dtype_304, rsub_scalar_69);  to_dtype_304 = rsub_scalar_69 = None
        add_tensor_481 = torch.ops.aten.add.Tensor(mul_tensor_605, 1);  mul_tensor_605 = None
        mul_tensor_606 = torch.ops.aten.mul.Tensor(mul_tensor_604, add_tensor_481);  mul_tensor_604 = add_tensor_481 = None
        to_dtype_305 = torch.ops.aten.to.dtype(mul_tensor_606, torch.float32);  mul_tensor_606 = None
        native_batch_norm_backward_default_73 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_305, convolution_default_104, primals_455, primals_453, primals_454, new_zeros_default_186, new_zeros_default_187, False, 0.001, [True, True, True]);  to_dtype_305 = convolution_default_104 = primals_455 = primals_453 = primals_454 = new_zeros_default_186 = new_zeros_default_187 = None
        getitem_1218 = native_batch_norm_backward_default_73[0]
        getitem_1219 = native_batch_norm_backward_default_73[1]
        getitem_1220 = native_batch_norm_backward_default_73[2];  native_batch_norm_backward_default_73 = None
        convolution_backward_default_159 = torch.ops.aten.convolution_backward.default(getitem_1218, add__tensor_14, primals_467, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1218 = add__tensor_14 = primals_467 = None
        getitem_1221 = convolution_backward_default_159[0]
        getitem_1222 = convolution_backward_default_159[1]
        getitem_1223 = convolution_backward_default_159[2];  convolution_backward_default_159 = None
        native_batch_norm_backward_default_74 = torch.ops.aten.native_batch_norm_backward.default(getitem_1221, convolution_default_103, primals_443, primals_441, primals_442, new_zeros_default_183, new_zeros_default_184, False, 0.001, [True, True, True]);  convolution_default_103 = primals_443 = primals_441 = primals_442 = new_zeros_default_183 = new_zeros_default_184 = None
        getitem_1224 = native_batch_norm_backward_default_74[0]
        getitem_1225 = native_batch_norm_backward_default_74[1]
        getitem_1226 = native_batch_norm_backward_default_74[2];  native_batch_norm_backward_default_74 = None
        convolution_backward_default_160 = torch.ops.aten.convolution_backward.default(getitem_1224, mul_tensor_20, primals_446, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1224 = mul_tensor_20 = primals_446 = None
        getitem_1227 = convolution_backward_default_160[0]
        getitem_1228 = convolution_backward_default_160[1]
        getitem_1229 = convolution_backward_default_160[2];  convolution_backward_default_160 = None
        mul_tensor_607 = torch.ops.aten.mul.Tensor(getitem_1227, silu__default_60);  silu__default_60 = None
        mul_tensor_608 = torch.ops.aten.mul.Tensor(getitem_1227, sigmoid_default_20);  getitem_1227 = None
        sum_dim_int_list_34 = torch.ops.aten.sum.dim_IntList(mul_tensor_607, [2, 3], True);  mul_tensor_607 = None
        to_dtype_306 = torch.ops.aten.to.dtype(sum_dim_int_list_34, torch.float32);  sum_dim_int_list_34 = None
        to_dtype_307 = torch.ops.aten.to.dtype(sigmoid_default_20, torch.float32);  sigmoid_default_20 = None
        rsub_scalar_70 = torch.ops.aten.rsub.Scalar(to_dtype_307, 1)
        mul_tensor_609 = torch.ops.aten.mul.Tensor(to_dtype_307, rsub_scalar_70);  to_dtype_307 = rsub_scalar_70 = None
        conj_physical_default_2 = torch.ops.aten.conj_physical.default(mul_tensor_609);  mul_tensor_609 = None
        mul_tensor_610 = torch.ops.aten.mul.Tensor(to_dtype_306, conj_physical_default_2);  to_dtype_306 = conj_physical_default_2 = None
        to_dtype_308 = torch.ops.aten.to.dtype(mul_tensor_610, torch.float32);  mul_tensor_610 = None
        convolution_backward_default_161 = torch.ops.aten.convolution_backward.default(to_dtype_308, silu__default_61, primals_448, [1152], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_308 = silu__default_61 = primals_448 = None
        getitem_1230 = convolution_backward_default_161[0]
        getitem_1231 = convolution_backward_default_161[1]
        getitem_1232 = convolution_backward_default_161[2];  convolution_backward_default_161 = None
        to_dtype_309 = torch.ops.aten.to.dtype(getitem_1230, torch.float32);  getitem_1230 = None
        to_dtype_310 = torch.ops.aten.to.dtype(clone_default_61, torch.float32);  clone_default_61 = None
        neg_default_144 = torch.ops.aten.neg.default(to_dtype_310)
        exp_default_68 = torch.ops.aten.exp.default(neg_default_144);  neg_default_144 = None
        add_tensor_482 = torch.ops.aten.add.Tensor(exp_default_68, 1);  exp_default_68 = None
        reciprocal_default_68 = torch.ops.aten.reciprocal.default(add_tensor_482);  add_tensor_482 = None
        mul_tensor_611 = torch.ops.aten.mul.Tensor(reciprocal_default_68, 1);  reciprocal_default_68 = None
        mul_tensor_612 = torch.ops.aten.mul.Tensor(to_dtype_309, mul_tensor_611);  to_dtype_309 = None
        rsub_scalar_71 = torch.ops.aten.rsub.Scalar(mul_tensor_611, 1);  mul_tensor_611 = None
        mul_tensor_613 = torch.ops.aten.mul.Tensor(to_dtype_310, rsub_scalar_71);  to_dtype_310 = rsub_scalar_71 = None
        add_tensor_483 = torch.ops.aten.add.Tensor(mul_tensor_613, 1);  mul_tensor_613 = None
        mul_tensor_614 = torch.ops.aten.mul.Tensor(mul_tensor_612, add_tensor_483);  mul_tensor_612 = add_tensor_483 = None
        to_dtype_311 = torch.ops.aten.to.dtype(mul_tensor_614, torch.float32);  mul_tensor_614 = None
        convolution_backward_default_162 = torch.ops.aten.convolution_backward.default(to_dtype_311, mean_dim_20, primals_450, [48], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_311 = mean_dim_20 = primals_450 = None
        getitem_1233 = convolution_backward_default_162[0]
        getitem_1234 = convolution_backward_default_162[1]
        getitem_1235 = convolution_backward_default_162[2];  convolution_backward_default_162 = None
        expand_default_66 = torch.ops.aten.expand.default(getitem_1233, [1, 1152, 20, 20]);  getitem_1233 = None
        div_scalar_2 = torch.ops.aten.div.Scalar(expand_default_66, 400);  expand_default_66 = None
        add_tensor_484 = torch.ops.aten.add.Tensor(mul_tensor_608, div_scalar_2);  mul_tensor_608 = div_scalar_2 = None
        to_dtype_312 = torch.ops.aten.to.dtype(add_tensor_484, torch.float32);  add_tensor_484 = None
        to_dtype_313 = torch.ops.aten.to.dtype(clone_default_60, torch.float32);  clone_default_60 = None
        neg_default_145 = torch.ops.aten.neg.default(to_dtype_313)
        exp_default_69 = torch.ops.aten.exp.default(neg_default_145);  neg_default_145 = None
        add_tensor_485 = torch.ops.aten.add.Tensor(exp_default_69, 1);  exp_default_69 = None
        reciprocal_default_69 = torch.ops.aten.reciprocal.default(add_tensor_485);  add_tensor_485 = None
        mul_tensor_615 = torch.ops.aten.mul.Tensor(reciprocal_default_69, 1);  reciprocal_default_69 = None
        mul_tensor_616 = torch.ops.aten.mul.Tensor(to_dtype_312, mul_tensor_615);  to_dtype_312 = None
        rsub_scalar_72 = torch.ops.aten.rsub.Scalar(mul_tensor_615, 1);  mul_tensor_615 = None
        mul_tensor_617 = torch.ops.aten.mul.Tensor(to_dtype_313, rsub_scalar_72);  to_dtype_313 = rsub_scalar_72 = None
        add_tensor_486 = torch.ops.aten.add.Tensor(mul_tensor_617, 1);  mul_tensor_617 = None
        mul_tensor_618 = torch.ops.aten.mul.Tensor(mul_tensor_616, add_tensor_486);  mul_tensor_616 = add_tensor_486 = None
        to_dtype_314 = torch.ops.aten.to.dtype(mul_tensor_618, torch.float32);  mul_tensor_618 = None
        native_batch_norm_backward_default_75 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_314, convolution_default_100, primals_438, primals_436, primals_437, new_zeros_default_180, new_zeros_default_181, False, 0.001, [True, True, True]);  to_dtype_314 = convolution_default_100 = primals_438 = primals_436 = primals_437 = new_zeros_default_180 = new_zeros_default_181 = None
        getitem_1236 = native_batch_norm_backward_default_75[0]
        getitem_1237 = native_batch_norm_backward_default_75[1]
        getitem_1238 = native_batch_norm_backward_default_75[2];  native_batch_norm_backward_default_75 = None
        convolution_backward_default_163 = torch.ops.aten.convolution_backward.default(getitem_1236, silu__default_59, primals_444, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 1152, [True, True, False]);  getitem_1236 = silu__default_59 = primals_444 = None
        getitem_1239 = convolution_backward_default_163[0]
        getitem_1240 = convolution_backward_default_163[1]
        getitem_1241 = convolution_backward_default_163[2];  convolution_backward_default_163 = None
        to_dtype_315 = torch.ops.aten.to.dtype(getitem_1239, torch.float32);  getitem_1239 = None
        to_dtype_316 = torch.ops.aten.to.dtype(clone_default_59, torch.float32);  clone_default_59 = None
        neg_default_146 = torch.ops.aten.neg.default(to_dtype_316)
        exp_default_70 = torch.ops.aten.exp.default(neg_default_146);  neg_default_146 = None
        add_tensor_487 = torch.ops.aten.add.Tensor(exp_default_70, 1);  exp_default_70 = None
        reciprocal_default_70 = torch.ops.aten.reciprocal.default(add_tensor_487);  add_tensor_487 = None
        mul_tensor_619 = torch.ops.aten.mul.Tensor(reciprocal_default_70, 1);  reciprocal_default_70 = None
        mul_tensor_620 = torch.ops.aten.mul.Tensor(to_dtype_315, mul_tensor_619);  to_dtype_315 = None
        rsub_scalar_73 = torch.ops.aten.rsub.Scalar(mul_tensor_619, 1);  mul_tensor_619 = None
        mul_tensor_621 = torch.ops.aten.mul.Tensor(to_dtype_316, rsub_scalar_73);  to_dtype_316 = rsub_scalar_73 = None
        add_tensor_488 = torch.ops.aten.add.Tensor(mul_tensor_621, 1);  mul_tensor_621 = None
        mul_tensor_622 = torch.ops.aten.mul.Tensor(mul_tensor_620, add_tensor_488);  mul_tensor_620 = add_tensor_488 = None
        to_dtype_317 = torch.ops.aten.to.dtype(mul_tensor_622, torch.float32);  mul_tensor_622 = None
        native_batch_norm_backward_default_76 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_317, convolution_default_99, primals_433, primals_431, primals_432, new_zeros_default_177, new_zeros_default_178, False, 0.001, [True, True, True]);  to_dtype_317 = convolution_default_99 = primals_433 = primals_431 = primals_432 = new_zeros_default_177 = new_zeros_default_178 = None
        getitem_1242 = native_batch_norm_backward_default_76[0]
        getitem_1243 = native_batch_norm_backward_default_76[1]
        getitem_1244 = native_batch_norm_backward_default_76[2];  native_batch_norm_backward_default_76 = None
        convolution_backward_default_164 = torch.ops.aten.convolution_backward.default(getitem_1242, add__tensor_13, primals_445, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1242 = add__tensor_13 = primals_445 = None
        getitem_1245 = convolution_backward_default_164[0]
        getitem_1246 = convolution_backward_default_164[1]
        getitem_1247 = convolution_backward_default_164[2];  convolution_backward_default_164 = None
        add_tensor_489 = torch.ops.aten.add.Tensor(getitem_1221, getitem_1245);  getitem_1221 = getitem_1245 = None
        native_batch_norm_backward_default_77 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_489, convolution_default_98, primals_421, primals_419, primals_420, new_zeros_default_174, new_zeros_default_175, False, 0.001, [True, True, True]);  convolution_default_98 = primals_421 = primals_419 = primals_420 = new_zeros_default_174 = new_zeros_default_175 = None
        getitem_1248 = native_batch_norm_backward_default_77[0]
        getitem_1249 = native_batch_norm_backward_default_77[1]
        getitem_1250 = native_batch_norm_backward_default_77[2];  native_batch_norm_backward_default_77 = None
        convolution_backward_default_165 = torch.ops.aten.convolution_backward.default(getitem_1248, mul_tensor_19, primals_424, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1248 = mul_tensor_19 = primals_424 = None
        getitem_1251 = convolution_backward_default_165[0]
        getitem_1252 = convolution_backward_default_165[1]
        getitem_1253 = convolution_backward_default_165[2];  convolution_backward_default_165 = None
        mul_tensor_623 = torch.ops.aten.mul.Tensor(getitem_1251, silu__default_57);  silu__default_57 = None
        mul_tensor_624 = torch.ops.aten.mul.Tensor(getitem_1251, sigmoid_default_19);  getitem_1251 = None
        sum_dim_int_list_35 = torch.ops.aten.sum.dim_IntList(mul_tensor_623, [2, 3], True);  mul_tensor_623 = None
        to_dtype_318 = torch.ops.aten.to.dtype(sum_dim_int_list_35, torch.float32);  sum_dim_int_list_35 = None
        to_dtype_319 = torch.ops.aten.to.dtype(sigmoid_default_19, torch.float32);  sigmoid_default_19 = None
        rsub_scalar_74 = torch.ops.aten.rsub.Scalar(to_dtype_319, 1)
        mul_tensor_625 = torch.ops.aten.mul.Tensor(to_dtype_319, rsub_scalar_74);  to_dtype_319 = rsub_scalar_74 = None
        conj_physical_default_3 = torch.ops.aten.conj_physical.default(mul_tensor_625);  mul_tensor_625 = None
        mul_tensor_626 = torch.ops.aten.mul.Tensor(to_dtype_318, conj_physical_default_3);  to_dtype_318 = conj_physical_default_3 = None
        to_dtype_320 = torch.ops.aten.to.dtype(mul_tensor_626, torch.float32);  mul_tensor_626 = None
        convolution_backward_default_166 = torch.ops.aten.convolution_backward.default(to_dtype_320, silu__default_58, primals_426, [1152], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_320 = silu__default_58 = primals_426 = None
        getitem_1254 = convolution_backward_default_166[0]
        getitem_1255 = convolution_backward_default_166[1]
        getitem_1256 = convolution_backward_default_166[2];  convolution_backward_default_166 = None
        to_dtype_321 = torch.ops.aten.to.dtype(getitem_1254, torch.float32);  getitem_1254 = None
        to_dtype_322 = torch.ops.aten.to.dtype(clone_default_58, torch.float32);  clone_default_58 = None
        neg_default_147 = torch.ops.aten.neg.default(to_dtype_322)
        exp_default_71 = torch.ops.aten.exp.default(neg_default_147);  neg_default_147 = None
        add_tensor_490 = torch.ops.aten.add.Tensor(exp_default_71, 1);  exp_default_71 = None
        reciprocal_default_71 = torch.ops.aten.reciprocal.default(add_tensor_490);  add_tensor_490 = None
        mul_tensor_627 = torch.ops.aten.mul.Tensor(reciprocal_default_71, 1);  reciprocal_default_71 = None
        mul_tensor_628 = torch.ops.aten.mul.Tensor(to_dtype_321, mul_tensor_627);  to_dtype_321 = None
        rsub_scalar_75 = torch.ops.aten.rsub.Scalar(mul_tensor_627, 1);  mul_tensor_627 = None
        mul_tensor_629 = torch.ops.aten.mul.Tensor(to_dtype_322, rsub_scalar_75);  to_dtype_322 = rsub_scalar_75 = None
        add_tensor_491 = torch.ops.aten.add.Tensor(mul_tensor_629, 1);  mul_tensor_629 = None
        mul_tensor_630 = torch.ops.aten.mul.Tensor(mul_tensor_628, add_tensor_491);  mul_tensor_628 = add_tensor_491 = None
        to_dtype_323 = torch.ops.aten.to.dtype(mul_tensor_630, torch.float32);  mul_tensor_630 = None
        convolution_backward_default_167 = torch.ops.aten.convolution_backward.default(to_dtype_323, mean_dim_19, primals_428, [48], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_323 = mean_dim_19 = primals_428 = None
        getitem_1257 = convolution_backward_default_167[0]
        getitem_1258 = convolution_backward_default_167[1]
        getitem_1259 = convolution_backward_default_167[2];  convolution_backward_default_167 = None
        expand_default_67 = torch.ops.aten.expand.default(getitem_1257, [1, 1152, 20, 20]);  getitem_1257 = None
        div_scalar_3 = torch.ops.aten.div.Scalar(expand_default_67, 400);  expand_default_67 = None
        add_tensor_492 = torch.ops.aten.add.Tensor(mul_tensor_624, div_scalar_3);  mul_tensor_624 = div_scalar_3 = None
        to_dtype_324 = torch.ops.aten.to.dtype(add_tensor_492, torch.float32);  add_tensor_492 = None
        to_dtype_325 = torch.ops.aten.to.dtype(clone_default_57, torch.float32);  clone_default_57 = None
        neg_default_148 = torch.ops.aten.neg.default(to_dtype_325)
        exp_default_72 = torch.ops.aten.exp.default(neg_default_148);  neg_default_148 = None
        add_tensor_493 = torch.ops.aten.add.Tensor(exp_default_72, 1);  exp_default_72 = None
        reciprocal_default_72 = torch.ops.aten.reciprocal.default(add_tensor_493);  add_tensor_493 = None
        mul_tensor_631 = torch.ops.aten.mul.Tensor(reciprocal_default_72, 1);  reciprocal_default_72 = None
        mul_tensor_632 = torch.ops.aten.mul.Tensor(to_dtype_324, mul_tensor_631);  to_dtype_324 = None
        rsub_scalar_76 = torch.ops.aten.rsub.Scalar(mul_tensor_631, 1);  mul_tensor_631 = None
        mul_tensor_633 = torch.ops.aten.mul.Tensor(to_dtype_325, rsub_scalar_76);  to_dtype_325 = rsub_scalar_76 = None
        add_tensor_494 = torch.ops.aten.add.Tensor(mul_tensor_633, 1);  mul_tensor_633 = None
        mul_tensor_634 = torch.ops.aten.mul.Tensor(mul_tensor_632, add_tensor_494);  mul_tensor_632 = add_tensor_494 = None
        to_dtype_326 = torch.ops.aten.to.dtype(mul_tensor_634, torch.float32);  mul_tensor_634 = None
        native_batch_norm_backward_default_78 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_326, convolution_default_95, primals_416, primals_414, primals_415, new_zeros_default_171, new_zeros_default_172, False, 0.001, [True, True, True]);  to_dtype_326 = convolution_default_95 = primals_416 = primals_414 = primals_415 = new_zeros_default_171 = new_zeros_default_172 = None
        getitem_1260 = native_batch_norm_backward_default_78[0]
        getitem_1261 = native_batch_norm_backward_default_78[1]
        getitem_1262 = native_batch_norm_backward_default_78[2];  native_batch_norm_backward_default_78 = None
        convolution_backward_default_168 = torch.ops.aten.convolution_backward.default(getitem_1260, silu__default_56, primals_422, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 1152, [True, True, False]);  getitem_1260 = silu__default_56 = primals_422 = None
        getitem_1263 = convolution_backward_default_168[0]
        getitem_1264 = convolution_backward_default_168[1]
        getitem_1265 = convolution_backward_default_168[2];  convolution_backward_default_168 = None
        to_dtype_327 = torch.ops.aten.to.dtype(getitem_1263, torch.float32);  getitem_1263 = None
        to_dtype_328 = torch.ops.aten.to.dtype(clone_default_56, torch.float32);  clone_default_56 = None
        neg_default_149 = torch.ops.aten.neg.default(to_dtype_328)
        exp_default_73 = torch.ops.aten.exp.default(neg_default_149);  neg_default_149 = None
        add_tensor_495 = torch.ops.aten.add.Tensor(exp_default_73, 1);  exp_default_73 = None
        reciprocal_default_73 = torch.ops.aten.reciprocal.default(add_tensor_495);  add_tensor_495 = None
        mul_tensor_635 = torch.ops.aten.mul.Tensor(reciprocal_default_73, 1);  reciprocal_default_73 = None
        mul_tensor_636 = torch.ops.aten.mul.Tensor(to_dtype_327, mul_tensor_635);  to_dtype_327 = None
        rsub_scalar_77 = torch.ops.aten.rsub.Scalar(mul_tensor_635, 1);  mul_tensor_635 = None
        mul_tensor_637 = torch.ops.aten.mul.Tensor(to_dtype_328, rsub_scalar_77);  to_dtype_328 = rsub_scalar_77 = None
        add_tensor_496 = torch.ops.aten.add.Tensor(mul_tensor_637, 1);  mul_tensor_637 = None
        mul_tensor_638 = torch.ops.aten.mul.Tensor(mul_tensor_636, add_tensor_496);  mul_tensor_636 = add_tensor_496 = None
        to_dtype_329 = torch.ops.aten.to.dtype(mul_tensor_638, torch.float32);  mul_tensor_638 = None
        native_batch_norm_backward_default_79 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_329, convolution_default_94, primals_411, primals_409, primals_410, new_zeros_default_168, new_zeros_default_169, False, 0.001, [True, True, True]);  to_dtype_329 = convolution_default_94 = primals_411 = primals_409 = primals_410 = new_zeros_default_168 = new_zeros_default_169 = None
        getitem_1266 = native_batch_norm_backward_default_79[0]
        getitem_1267 = native_batch_norm_backward_default_79[1]
        getitem_1268 = native_batch_norm_backward_default_79[2];  native_batch_norm_backward_default_79 = None
        convolution_backward_default_169 = torch.ops.aten.convolution_backward.default(getitem_1266, add__tensor_12, primals_423, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1266 = add__tensor_12 = primals_423 = None
        getitem_1269 = convolution_backward_default_169[0]
        getitem_1270 = convolution_backward_default_169[1]
        getitem_1271 = convolution_backward_default_169[2];  convolution_backward_default_169 = None
        add_tensor_497 = torch.ops.aten.add.Tensor(add_tensor_489, getitem_1269);  add_tensor_489 = getitem_1269 = None
        native_batch_norm_backward_default_80 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_497, convolution_default_93, primals_399, primals_397, primals_398, new_zeros_default_165, new_zeros_default_166, False, 0.001, [True, True, True]);  convolution_default_93 = primals_399 = primals_397 = primals_398 = new_zeros_default_165 = new_zeros_default_166 = None
        getitem_1272 = native_batch_norm_backward_default_80[0]
        getitem_1273 = native_batch_norm_backward_default_80[1]
        getitem_1274 = native_batch_norm_backward_default_80[2];  native_batch_norm_backward_default_80 = None
        convolution_backward_default_170 = torch.ops.aten.convolution_backward.default(getitem_1272, mul_tensor_18, primals_402, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1272 = mul_tensor_18 = primals_402 = None
        getitem_1275 = convolution_backward_default_170[0]
        getitem_1276 = convolution_backward_default_170[1]
        getitem_1277 = convolution_backward_default_170[2];  convolution_backward_default_170 = None
        mul_tensor_639 = torch.ops.aten.mul.Tensor(getitem_1275, silu__default_54);  silu__default_54 = None
        mul_tensor_640 = torch.ops.aten.mul.Tensor(getitem_1275, sigmoid_default_18);  getitem_1275 = None
        sum_dim_int_list_36 = torch.ops.aten.sum.dim_IntList(mul_tensor_639, [2, 3], True);  mul_tensor_639 = None
        to_dtype_330 = torch.ops.aten.to.dtype(sum_dim_int_list_36, torch.float32);  sum_dim_int_list_36 = None
        to_dtype_331 = torch.ops.aten.to.dtype(sigmoid_default_18, torch.float32);  sigmoid_default_18 = None
        rsub_scalar_78 = torch.ops.aten.rsub.Scalar(to_dtype_331, 1)
        mul_tensor_641 = torch.ops.aten.mul.Tensor(to_dtype_331, rsub_scalar_78);  to_dtype_331 = rsub_scalar_78 = None
        conj_physical_default_4 = torch.ops.aten.conj_physical.default(mul_tensor_641);  mul_tensor_641 = None
        mul_tensor_642 = torch.ops.aten.mul.Tensor(to_dtype_330, conj_physical_default_4);  to_dtype_330 = conj_physical_default_4 = None
        to_dtype_332 = torch.ops.aten.to.dtype(mul_tensor_642, torch.float32);  mul_tensor_642 = None
        convolution_backward_default_171 = torch.ops.aten.convolution_backward.default(to_dtype_332, silu__default_55, primals_404, [1152], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_332 = silu__default_55 = primals_404 = None
        getitem_1278 = convolution_backward_default_171[0]
        getitem_1279 = convolution_backward_default_171[1]
        getitem_1280 = convolution_backward_default_171[2];  convolution_backward_default_171 = None
        to_dtype_333 = torch.ops.aten.to.dtype(getitem_1278, torch.float32);  getitem_1278 = None
        to_dtype_334 = torch.ops.aten.to.dtype(clone_default_55, torch.float32);  clone_default_55 = None
        neg_default_150 = torch.ops.aten.neg.default(to_dtype_334)
        exp_default_74 = torch.ops.aten.exp.default(neg_default_150);  neg_default_150 = None
        add_tensor_498 = torch.ops.aten.add.Tensor(exp_default_74, 1);  exp_default_74 = None
        reciprocal_default_74 = torch.ops.aten.reciprocal.default(add_tensor_498);  add_tensor_498 = None
        mul_tensor_643 = torch.ops.aten.mul.Tensor(reciprocal_default_74, 1);  reciprocal_default_74 = None
        mul_tensor_644 = torch.ops.aten.mul.Tensor(to_dtype_333, mul_tensor_643);  to_dtype_333 = None
        rsub_scalar_79 = torch.ops.aten.rsub.Scalar(mul_tensor_643, 1);  mul_tensor_643 = None
        mul_tensor_645 = torch.ops.aten.mul.Tensor(to_dtype_334, rsub_scalar_79);  to_dtype_334 = rsub_scalar_79 = None
        add_tensor_499 = torch.ops.aten.add.Tensor(mul_tensor_645, 1);  mul_tensor_645 = None
        mul_tensor_646 = torch.ops.aten.mul.Tensor(mul_tensor_644, add_tensor_499);  mul_tensor_644 = add_tensor_499 = None
        to_dtype_335 = torch.ops.aten.to.dtype(mul_tensor_646, torch.float32);  mul_tensor_646 = None
        convolution_backward_default_172 = torch.ops.aten.convolution_backward.default(to_dtype_335, mean_dim_18, primals_406, [48], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_335 = mean_dim_18 = primals_406 = None
        getitem_1281 = convolution_backward_default_172[0]
        getitem_1282 = convolution_backward_default_172[1]
        getitem_1283 = convolution_backward_default_172[2];  convolution_backward_default_172 = None
        expand_default_68 = torch.ops.aten.expand.default(getitem_1281, [1, 1152, 20, 20]);  getitem_1281 = None
        div_scalar_4 = torch.ops.aten.div.Scalar(expand_default_68, 400);  expand_default_68 = None
        add_tensor_500 = torch.ops.aten.add.Tensor(mul_tensor_640, div_scalar_4);  mul_tensor_640 = div_scalar_4 = None
        to_dtype_336 = torch.ops.aten.to.dtype(add_tensor_500, torch.float32);  add_tensor_500 = None
        to_dtype_337 = torch.ops.aten.to.dtype(clone_default_54, torch.float32);  clone_default_54 = None
        neg_default_151 = torch.ops.aten.neg.default(to_dtype_337)
        exp_default_75 = torch.ops.aten.exp.default(neg_default_151);  neg_default_151 = None
        add_tensor_501 = torch.ops.aten.add.Tensor(exp_default_75, 1);  exp_default_75 = None
        reciprocal_default_75 = torch.ops.aten.reciprocal.default(add_tensor_501);  add_tensor_501 = None
        mul_tensor_647 = torch.ops.aten.mul.Tensor(reciprocal_default_75, 1);  reciprocal_default_75 = None
        mul_tensor_648 = torch.ops.aten.mul.Tensor(to_dtype_336, mul_tensor_647);  to_dtype_336 = None
        rsub_scalar_80 = torch.ops.aten.rsub.Scalar(mul_tensor_647, 1);  mul_tensor_647 = None
        mul_tensor_649 = torch.ops.aten.mul.Tensor(to_dtype_337, rsub_scalar_80);  to_dtype_337 = rsub_scalar_80 = None
        add_tensor_502 = torch.ops.aten.add.Tensor(mul_tensor_649, 1);  mul_tensor_649 = None
        mul_tensor_650 = torch.ops.aten.mul.Tensor(mul_tensor_648, add_tensor_502);  mul_tensor_648 = add_tensor_502 = None
        to_dtype_338 = torch.ops.aten.to.dtype(mul_tensor_650, torch.float32);  mul_tensor_650 = None
        native_batch_norm_backward_default_81 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_338, convolution_default_90, primals_394, primals_392, primals_393, new_zeros_default_162, new_zeros_default_163, False, 0.001, [True, True, True]);  to_dtype_338 = convolution_default_90 = primals_394 = primals_392 = primals_393 = new_zeros_default_162 = new_zeros_default_163 = None
        getitem_1284 = native_batch_norm_backward_default_81[0]
        getitem_1285 = native_batch_norm_backward_default_81[1]
        getitem_1286 = native_batch_norm_backward_default_81[2];  native_batch_norm_backward_default_81 = None
        convolution_backward_default_173 = torch.ops.aten.convolution_backward.default(getitem_1284, silu__default_53, primals_400, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 1152, [True, True, False]);  getitem_1284 = silu__default_53 = primals_400 = None
        getitem_1287 = convolution_backward_default_173[0]
        getitem_1288 = convolution_backward_default_173[1]
        getitem_1289 = convolution_backward_default_173[2];  convolution_backward_default_173 = None
        to_dtype_339 = torch.ops.aten.to.dtype(getitem_1287, torch.float32);  getitem_1287 = None
        to_dtype_340 = torch.ops.aten.to.dtype(clone_default_53, torch.float32);  clone_default_53 = None
        neg_default_152 = torch.ops.aten.neg.default(to_dtype_340)
        exp_default_76 = torch.ops.aten.exp.default(neg_default_152);  neg_default_152 = None
        add_tensor_503 = torch.ops.aten.add.Tensor(exp_default_76, 1);  exp_default_76 = None
        reciprocal_default_76 = torch.ops.aten.reciprocal.default(add_tensor_503);  add_tensor_503 = None
        mul_tensor_651 = torch.ops.aten.mul.Tensor(reciprocal_default_76, 1);  reciprocal_default_76 = None
        mul_tensor_652 = torch.ops.aten.mul.Tensor(to_dtype_339, mul_tensor_651);  to_dtype_339 = None
        rsub_scalar_81 = torch.ops.aten.rsub.Scalar(mul_tensor_651, 1);  mul_tensor_651 = None
        mul_tensor_653 = torch.ops.aten.mul.Tensor(to_dtype_340, rsub_scalar_81);  to_dtype_340 = rsub_scalar_81 = None
        add_tensor_504 = torch.ops.aten.add.Tensor(mul_tensor_653, 1);  mul_tensor_653 = None
        mul_tensor_654 = torch.ops.aten.mul.Tensor(mul_tensor_652, add_tensor_504);  mul_tensor_652 = add_tensor_504 = None
        to_dtype_341 = torch.ops.aten.to.dtype(mul_tensor_654, torch.float32);  mul_tensor_654 = None
        native_batch_norm_backward_default_82 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_341, convolution_default_89, primals_389, primals_387, primals_388, new_zeros_default_159, new_zeros_default_160, False, 0.001, [True, True, True]);  to_dtype_341 = convolution_default_89 = primals_389 = primals_387 = primals_388 = new_zeros_default_159 = new_zeros_default_160 = None
        getitem_1290 = native_batch_norm_backward_default_82[0]
        getitem_1291 = native_batch_norm_backward_default_82[1]
        getitem_1292 = native_batch_norm_backward_default_82[2];  native_batch_norm_backward_default_82 = None
        convolution_backward_default_174 = torch.ops.aten.convolution_backward.default(getitem_1290, add__tensor_11, primals_401, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1290 = add__tensor_11 = primals_401 = None
        getitem_1293 = convolution_backward_default_174[0]
        getitem_1294 = convolution_backward_default_174[1]
        getitem_1295 = convolution_backward_default_174[2];  convolution_backward_default_174 = None
        add_tensor_505 = torch.ops.aten.add.Tensor(add_tensor_497, getitem_1293);  add_tensor_497 = getitem_1293 = None
        native_batch_norm_backward_default_83 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_505, convolution_default_88, primals_377, primals_375, primals_376, new_zeros_default_156, new_zeros_default_157, False, 0.001, [True, True, True]);  convolution_default_88 = primals_377 = primals_375 = primals_376 = new_zeros_default_156 = new_zeros_default_157 = None
        getitem_1296 = native_batch_norm_backward_default_83[0]
        getitem_1297 = native_batch_norm_backward_default_83[1]
        getitem_1298 = native_batch_norm_backward_default_83[2];  native_batch_norm_backward_default_83 = None
        convolution_backward_default_175 = torch.ops.aten.convolution_backward.default(getitem_1296, mul_tensor_17, primals_380, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1296 = mul_tensor_17 = primals_380 = None
        getitem_1299 = convolution_backward_default_175[0]
        getitem_1300 = convolution_backward_default_175[1]
        getitem_1301 = convolution_backward_default_175[2];  convolution_backward_default_175 = None
        mul_tensor_655 = torch.ops.aten.mul.Tensor(getitem_1299, silu__default_51);  silu__default_51 = None
        mul_tensor_656 = torch.ops.aten.mul.Tensor(getitem_1299, sigmoid_default_17);  getitem_1299 = None
        sum_dim_int_list_37 = torch.ops.aten.sum.dim_IntList(mul_tensor_655, [2, 3], True);  mul_tensor_655 = None
        to_dtype_342 = torch.ops.aten.to.dtype(sum_dim_int_list_37, torch.float32);  sum_dim_int_list_37 = None
        to_dtype_343 = torch.ops.aten.to.dtype(sigmoid_default_17, torch.float32);  sigmoid_default_17 = None
        rsub_scalar_82 = torch.ops.aten.rsub.Scalar(to_dtype_343, 1)
        mul_tensor_657 = torch.ops.aten.mul.Tensor(to_dtype_343, rsub_scalar_82);  to_dtype_343 = rsub_scalar_82 = None
        conj_physical_default_5 = torch.ops.aten.conj_physical.default(mul_tensor_657);  mul_tensor_657 = None
        mul_tensor_658 = torch.ops.aten.mul.Tensor(to_dtype_342, conj_physical_default_5);  to_dtype_342 = conj_physical_default_5 = None
        to_dtype_344 = torch.ops.aten.to.dtype(mul_tensor_658, torch.float32);  mul_tensor_658 = None
        convolution_backward_default_176 = torch.ops.aten.convolution_backward.default(to_dtype_344, silu__default_52, primals_382, [1152], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_344 = silu__default_52 = primals_382 = None
        getitem_1302 = convolution_backward_default_176[0]
        getitem_1303 = convolution_backward_default_176[1]
        getitem_1304 = convolution_backward_default_176[2];  convolution_backward_default_176 = None
        to_dtype_345 = torch.ops.aten.to.dtype(getitem_1302, torch.float32);  getitem_1302 = None
        to_dtype_346 = torch.ops.aten.to.dtype(clone_default_52, torch.float32);  clone_default_52 = None
        neg_default_153 = torch.ops.aten.neg.default(to_dtype_346)
        exp_default_77 = torch.ops.aten.exp.default(neg_default_153);  neg_default_153 = None
        add_tensor_506 = torch.ops.aten.add.Tensor(exp_default_77, 1);  exp_default_77 = None
        reciprocal_default_77 = torch.ops.aten.reciprocal.default(add_tensor_506);  add_tensor_506 = None
        mul_tensor_659 = torch.ops.aten.mul.Tensor(reciprocal_default_77, 1);  reciprocal_default_77 = None
        mul_tensor_660 = torch.ops.aten.mul.Tensor(to_dtype_345, mul_tensor_659);  to_dtype_345 = None
        rsub_scalar_83 = torch.ops.aten.rsub.Scalar(mul_tensor_659, 1);  mul_tensor_659 = None
        mul_tensor_661 = torch.ops.aten.mul.Tensor(to_dtype_346, rsub_scalar_83);  to_dtype_346 = rsub_scalar_83 = None
        add_tensor_507 = torch.ops.aten.add.Tensor(mul_tensor_661, 1);  mul_tensor_661 = None
        mul_tensor_662 = torch.ops.aten.mul.Tensor(mul_tensor_660, add_tensor_507);  mul_tensor_660 = add_tensor_507 = None
        to_dtype_347 = torch.ops.aten.to.dtype(mul_tensor_662, torch.float32);  mul_tensor_662 = None
        convolution_backward_default_177 = torch.ops.aten.convolution_backward.default(to_dtype_347, mean_dim_17, primals_384, [48], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_347 = mean_dim_17 = primals_384 = None
        getitem_1305 = convolution_backward_default_177[0]
        getitem_1306 = convolution_backward_default_177[1]
        getitem_1307 = convolution_backward_default_177[2];  convolution_backward_default_177 = None
        expand_default_69 = torch.ops.aten.expand.default(getitem_1305, [1, 1152, 20, 20]);  getitem_1305 = None
        div_scalar_5 = torch.ops.aten.div.Scalar(expand_default_69, 400);  expand_default_69 = None
        add_tensor_508 = torch.ops.aten.add.Tensor(mul_tensor_656, div_scalar_5);  mul_tensor_656 = div_scalar_5 = None
        to_dtype_348 = torch.ops.aten.to.dtype(add_tensor_508, torch.float32);  add_tensor_508 = None
        to_dtype_349 = torch.ops.aten.to.dtype(clone_default_51, torch.float32);  clone_default_51 = None
        neg_default_154 = torch.ops.aten.neg.default(to_dtype_349)
        exp_default_78 = torch.ops.aten.exp.default(neg_default_154);  neg_default_154 = None
        add_tensor_509 = torch.ops.aten.add.Tensor(exp_default_78, 1);  exp_default_78 = None
        reciprocal_default_78 = torch.ops.aten.reciprocal.default(add_tensor_509);  add_tensor_509 = None
        mul_tensor_663 = torch.ops.aten.mul.Tensor(reciprocal_default_78, 1);  reciprocal_default_78 = None
        mul_tensor_664 = torch.ops.aten.mul.Tensor(to_dtype_348, mul_tensor_663);  to_dtype_348 = None
        rsub_scalar_84 = torch.ops.aten.rsub.Scalar(mul_tensor_663, 1);  mul_tensor_663 = None
        mul_tensor_665 = torch.ops.aten.mul.Tensor(to_dtype_349, rsub_scalar_84);  to_dtype_349 = rsub_scalar_84 = None
        add_tensor_510 = torch.ops.aten.add.Tensor(mul_tensor_665, 1);  mul_tensor_665 = None
        mul_tensor_666 = torch.ops.aten.mul.Tensor(mul_tensor_664, add_tensor_510);  mul_tensor_664 = add_tensor_510 = None
        to_dtype_350 = torch.ops.aten.to.dtype(mul_tensor_666, torch.float32);  mul_tensor_666 = None
        native_batch_norm_backward_default_84 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_350, convolution_default_85, primals_372, primals_370, primals_371, new_zeros_default_153, new_zeros_default_154, False, 0.001, [True, True, True]);  to_dtype_350 = convolution_default_85 = primals_372 = primals_370 = primals_371 = new_zeros_default_153 = new_zeros_default_154 = None
        getitem_1308 = native_batch_norm_backward_default_84[0]
        getitem_1309 = native_batch_norm_backward_default_84[1]
        getitem_1310 = native_batch_norm_backward_default_84[2];  native_batch_norm_backward_default_84 = None
        convolution_backward_default_178 = torch.ops.aten.convolution_backward.default(getitem_1308, silu__default_50, primals_378, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 1152, [True, True, False]);  getitem_1308 = silu__default_50 = primals_378 = None
        getitem_1311 = convolution_backward_default_178[0]
        getitem_1312 = convolution_backward_default_178[1]
        getitem_1313 = convolution_backward_default_178[2];  convolution_backward_default_178 = None
        to_dtype_351 = torch.ops.aten.to.dtype(getitem_1311, torch.float32);  getitem_1311 = None
        to_dtype_352 = torch.ops.aten.to.dtype(clone_default_50, torch.float32);  clone_default_50 = None
        neg_default_155 = torch.ops.aten.neg.default(to_dtype_352)
        exp_default_79 = torch.ops.aten.exp.default(neg_default_155);  neg_default_155 = None
        add_tensor_511 = torch.ops.aten.add.Tensor(exp_default_79, 1);  exp_default_79 = None
        reciprocal_default_79 = torch.ops.aten.reciprocal.default(add_tensor_511);  add_tensor_511 = None
        mul_tensor_667 = torch.ops.aten.mul.Tensor(reciprocal_default_79, 1);  reciprocal_default_79 = None
        mul_tensor_668 = torch.ops.aten.mul.Tensor(to_dtype_351, mul_tensor_667);  to_dtype_351 = None
        rsub_scalar_85 = torch.ops.aten.rsub.Scalar(mul_tensor_667, 1);  mul_tensor_667 = None
        mul_tensor_669 = torch.ops.aten.mul.Tensor(to_dtype_352, rsub_scalar_85);  to_dtype_352 = rsub_scalar_85 = None
        add_tensor_512 = torch.ops.aten.add.Tensor(mul_tensor_669, 1);  mul_tensor_669 = None
        mul_tensor_670 = torch.ops.aten.mul.Tensor(mul_tensor_668, add_tensor_512);  mul_tensor_668 = add_tensor_512 = None
        to_dtype_353 = torch.ops.aten.to.dtype(mul_tensor_670, torch.float32);  mul_tensor_670 = None
        native_batch_norm_backward_default_85 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_353, convolution_default_84, primals_367, primals_365, primals_366, new_zeros_default_150, new_zeros_default_151, False, 0.001, [True, True, True]);  to_dtype_353 = convolution_default_84 = primals_367 = primals_365 = primals_366 = new_zeros_default_150 = new_zeros_default_151 = None
        getitem_1314 = native_batch_norm_backward_default_85[0]
        getitem_1315 = native_batch_norm_backward_default_85[1]
        getitem_1316 = native_batch_norm_backward_default_85[2];  native_batch_norm_backward_default_85 = None
        convolution_backward_default_179 = torch.ops.aten.convolution_backward.default(getitem_1314, getitem_147, primals_379, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1314 = getitem_147 = primals_379 = None
        getitem_1317 = convolution_backward_default_179[0]
        getitem_1318 = convolution_backward_default_179[1]
        getitem_1319 = convolution_backward_default_179[2];  convolution_backward_default_179 = None
        add_tensor_513 = torch.ops.aten.add.Tensor(add_tensor_505, getitem_1317);  add_tensor_505 = getitem_1317 = None
        native_batch_norm_backward_default_86 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_513, convolution_default_83, primals_355, primals_353, primals_354, new_zeros_default_147, new_zeros_default_148, False, 0.001, [True, True, True]);  add_tensor_513 = convolution_default_83 = primals_355 = primals_353 = primals_354 = new_zeros_default_147 = new_zeros_default_148 = None
        getitem_1320 = native_batch_norm_backward_default_86[0]
        getitem_1321 = native_batch_norm_backward_default_86[1]
        getitem_1322 = native_batch_norm_backward_default_86[2];  native_batch_norm_backward_default_86 = None
        convolution_backward_default_180 = torch.ops.aten.convolution_backward.default(getitem_1320, mul_tensor_16, primals_358, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1320 = mul_tensor_16 = primals_358 = None
        getitem_1323 = convolution_backward_default_180[0]
        getitem_1324 = convolution_backward_default_180[1]
        getitem_1325 = convolution_backward_default_180[2];  convolution_backward_default_180 = None
        mul_tensor_671 = torch.ops.aten.mul.Tensor(getitem_1323, silu__default_48);  silu__default_48 = None
        mul_tensor_672 = torch.ops.aten.mul.Tensor(getitem_1323, sigmoid_default_16);  getitem_1323 = None
        sum_dim_int_list_38 = torch.ops.aten.sum.dim_IntList(mul_tensor_671, [2, 3], True);  mul_tensor_671 = None
        to_dtype_354 = torch.ops.aten.to.dtype(sum_dim_int_list_38, torch.float32);  sum_dim_int_list_38 = None
        to_dtype_355 = torch.ops.aten.to.dtype(sigmoid_default_16, torch.float32);  sigmoid_default_16 = None
        rsub_scalar_86 = torch.ops.aten.rsub.Scalar(to_dtype_355, 1)
        mul_tensor_673 = torch.ops.aten.mul.Tensor(to_dtype_355, rsub_scalar_86);  to_dtype_355 = rsub_scalar_86 = None
        conj_physical_default_6 = torch.ops.aten.conj_physical.default(mul_tensor_673);  mul_tensor_673 = None
        mul_tensor_674 = torch.ops.aten.mul.Tensor(to_dtype_354, conj_physical_default_6);  to_dtype_354 = conj_physical_default_6 = None
        to_dtype_356 = torch.ops.aten.to.dtype(mul_tensor_674, torch.float32);  mul_tensor_674 = None
        convolution_backward_default_181 = torch.ops.aten.convolution_backward.default(to_dtype_356, silu__default_49, primals_360, [672], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_356 = silu__default_49 = primals_360 = None
        getitem_1326 = convolution_backward_default_181[0]
        getitem_1327 = convolution_backward_default_181[1]
        getitem_1328 = convolution_backward_default_181[2];  convolution_backward_default_181 = None
        to_dtype_357 = torch.ops.aten.to.dtype(getitem_1326, torch.float32);  getitem_1326 = None
        to_dtype_358 = torch.ops.aten.to.dtype(clone_default_49, torch.float32);  clone_default_49 = None
        neg_default_156 = torch.ops.aten.neg.default(to_dtype_358)
        exp_default_80 = torch.ops.aten.exp.default(neg_default_156);  neg_default_156 = None
        add_tensor_514 = torch.ops.aten.add.Tensor(exp_default_80, 1);  exp_default_80 = None
        reciprocal_default_80 = torch.ops.aten.reciprocal.default(add_tensor_514);  add_tensor_514 = None
        mul_tensor_675 = torch.ops.aten.mul.Tensor(reciprocal_default_80, 1);  reciprocal_default_80 = None
        mul_tensor_676 = torch.ops.aten.mul.Tensor(to_dtype_357, mul_tensor_675);  to_dtype_357 = None
        rsub_scalar_87 = torch.ops.aten.rsub.Scalar(mul_tensor_675, 1);  mul_tensor_675 = None
        mul_tensor_677 = torch.ops.aten.mul.Tensor(to_dtype_358, rsub_scalar_87);  to_dtype_358 = rsub_scalar_87 = None
        add_tensor_515 = torch.ops.aten.add.Tensor(mul_tensor_677, 1);  mul_tensor_677 = None
        mul_tensor_678 = torch.ops.aten.mul.Tensor(mul_tensor_676, add_tensor_515);  mul_tensor_676 = add_tensor_515 = None
        to_dtype_359 = torch.ops.aten.to.dtype(mul_tensor_678, torch.float32);  mul_tensor_678 = None
        convolution_backward_default_182 = torch.ops.aten.convolution_backward.default(to_dtype_359, mean_dim_16, primals_362, [28], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_359 = mean_dim_16 = primals_362 = None
        getitem_1329 = convolution_backward_default_182[0]
        getitem_1330 = convolution_backward_default_182[1]
        getitem_1331 = convolution_backward_default_182[2];  convolution_backward_default_182 = None
        expand_default_70 = torch.ops.aten.expand.default(getitem_1329, [1, 672, 20, 20]);  getitem_1329 = None
        div_scalar_6 = torch.ops.aten.div.Scalar(expand_default_70, 400);  expand_default_70 = None
        add_tensor_516 = torch.ops.aten.add.Tensor(mul_tensor_672, div_scalar_6);  mul_tensor_672 = div_scalar_6 = None
        to_dtype_360 = torch.ops.aten.to.dtype(add_tensor_516, torch.float32);  add_tensor_516 = None
        to_dtype_361 = torch.ops.aten.to.dtype(clone_default_48, torch.float32);  clone_default_48 = None
        neg_default_157 = torch.ops.aten.neg.default(to_dtype_361)
        exp_default_81 = torch.ops.aten.exp.default(neg_default_157);  neg_default_157 = None
        add_tensor_517 = torch.ops.aten.add.Tensor(exp_default_81, 1);  exp_default_81 = None
        reciprocal_default_81 = torch.ops.aten.reciprocal.default(add_tensor_517);  add_tensor_517 = None
        mul_tensor_679 = torch.ops.aten.mul.Tensor(reciprocal_default_81, 1);  reciprocal_default_81 = None
        mul_tensor_680 = torch.ops.aten.mul.Tensor(to_dtype_360, mul_tensor_679);  to_dtype_360 = None
        rsub_scalar_88 = torch.ops.aten.rsub.Scalar(mul_tensor_679, 1);  mul_tensor_679 = None
        mul_tensor_681 = torch.ops.aten.mul.Tensor(to_dtype_361, rsub_scalar_88);  to_dtype_361 = rsub_scalar_88 = None
        add_tensor_518 = torch.ops.aten.add.Tensor(mul_tensor_681, 1);  mul_tensor_681 = None
        mul_tensor_682 = torch.ops.aten.mul.Tensor(mul_tensor_680, add_tensor_518);  mul_tensor_680 = add_tensor_518 = None
        to_dtype_362 = torch.ops.aten.to.dtype(mul_tensor_682, torch.float32);  mul_tensor_682 = None
        native_batch_norm_backward_default_87 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_362, convolution_default_80, primals_350, primals_348, primals_349, new_zeros_default_144, new_zeros_default_145, False, 0.001, [True, True, True]);  to_dtype_362 = convolution_default_80 = primals_350 = primals_348 = primals_349 = new_zeros_default_144 = new_zeros_default_145 = None
        getitem_1332 = native_batch_norm_backward_default_87[0]
        getitem_1333 = native_batch_norm_backward_default_87[1]
        getitem_1334 = native_batch_norm_backward_default_87[2];  native_batch_norm_backward_default_87 = None
        convolution_backward_default_183 = torch.ops.aten.convolution_backward.default(getitem_1332, constant_pad_nd_default_4, primals_356, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1332 = constant_pad_nd_default_4 = primals_356 = None
        getitem_1335 = convolution_backward_default_183[0]
        getitem_1336 = convolution_backward_default_183[1]
        getitem_1337 = convolution_backward_default_183[2];  convolution_backward_default_183 = None
        constant_pad_nd_default_41 = torch.ops.aten.constant_pad_nd.default(getitem_1335, [-1, -2, -1, -2]);  getitem_1335 = None
        to_dtype_363 = torch.ops.aten.to.dtype(constant_pad_nd_default_41, torch.float32);  constant_pad_nd_default_41 = None
        to_dtype_364 = torch.ops.aten.to.dtype(clone_default_47, torch.float32);  clone_default_47 = None
        neg_default_158 = torch.ops.aten.neg.default(to_dtype_364)
        exp_default_82 = torch.ops.aten.exp.default(neg_default_158);  neg_default_158 = None
        add_tensor_519 = torch.ops.aten.add.Tensor(exp_default_82, 1);  exp_default_82 = None
        reciprocal_default_82 = torch.ops.aten.reciprocal.default(add_tensor_519);  add_tensor_519 = None
        mul_tensor_683 = torch.ops.aten.mul.Tensor(reciprocal_default_82, 1);  reciprocal_default_82 = None
        mul_tensor_684 = torch.ops.aten.mul.Tensor(to_dtype_363, mul_tensor_683);  to_dtype_363 = None
        rsub_scalar_89 = torch.ops.aten.rsub.Scalar(mul_tensor_683, 1);  mul_tensor_683 = None
        mul_tensor_685 = torch.ops.aten.mul.Tensor(to_dtype_364, rsub_scalar_89);  to_dtype_364 = rsub_scalar_89 = None
        add_tensor_520 = torch.ops.aten.add.Tensor(mul_tensor_685, 1);  mul_tensor_685 = None
        mul_tensor_686 = torch.ops.aten.mul.Tensor(mul_tensor_684, add_tensor_520);  mul_tensor_684 = add_tensor_520 = None
        to_dtype_365 = torch.ops.aten.to.dtype(mul_tensor_686, torch.float32);  mul_tensor_686 = None
        native_batch_norm_backward_default_88 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_365, convolution_default_79, primals_345, primals_343, primals_344, new_zeros_default_141, new_zeros_default_142, False, 0.001, [True, True, True]);  to_dtype_365 = convolution_default_79 = primals_345 = primals_343 = primals_344 = new_zeros_default_141 = new_zeros_default_142 = None
        getitem_1338 = native_batch_norm_backward_default_88[0]
        getitem_1339 = native_batch_norm_backward_default_88[1]
        getitem_1340 = native_batch_norm_backward_default_88[2];  native_batch_norm_backward_default_88 = None
        convolution_backward_default_184 = torch.ops.aten.convolution_backward.default(getitem_1338, add__tensor_10, primals_357, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1338 = add__tensor_10 = primals_357 = None
        getitem_1341 = convolution_backward_default_184[0]
        getitem_1342 = convolution_backward_default_184[1]
        getitem_1343 = convolution_backward_default_184[2];  convolution_backward_default_184 = None
        add_tensor_521 = torch.ops.aten.add.Tensor(add_tensor_450, getitem_1341);  add_tensor_450 = getitem_1341 = None
        native_batch_norm_backward_default_89 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_521, convolution_default_78, primals_333, primals_331, primals_332, new_zeros_default_138, new_zeros_default_139, False, 0.001, [True, True, True]);  convolution_default_78 = primals_333 = primals_331 = primals_332 = new_zeros_default_138 = new_zeros_default_139 = None
        getitem_1344 = native_batch_norm_backward_default_89[0]
        getitem_1345 = native_batch_norm_backward_default_89[1]
        getitem_1346 = native_batch_norm_backward_default_89[2];  native_batch_norm_backward_default_89 = None
        convolution_backward_default_185 = torch.ops.aten.convolution_backward.default(getitem_1344, mul_tensor_15, primals_336, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1344 = mul_tensor_15 = primals_336 = None
        getitem_1347 = convolution_backward_default_185[0]
        getitem_1348 = convolution_backward_default_185[1]
        getitem_1349 = convolution_backward_default_185[2];  convolution_backward_default_185 = None
        mul_tensor_687 = torch.ops.aten.mul.Tensor(getitem_1347, silu__default_45);  silu__default_45 = None
        mul_tensor_688 = torch.ops.aten.mul.Tensor(getitem_1347, sigmoid_default_15);  getitem_1347 = None
        sum_dim_int_list_39 = torch.ops.aten.sum.dim_IntList(mul_tensor_687, [2, 3], True);  mul_tensor_687 = None
        to_dtype_366 = torch.ops.aten.to.dtype(sum_dim_int_list_39, torch.float32);  sum_dim_int_list_39 = None
        to_dtype_367 = torch.ops.aten.to.dtype(sigmoid_default_15, torch.float32);  sigmoid_default_15 = None
        rsub_scalar_90 = torch.ops.aten.rsub.Scalar(to_dtype_367, 1)
        mul_tensor_689 = torch.ops.aten.mul.Tensor(to_dtype_367, rsub_scalar_90);  to_dtype_367 = rsub_scalar_90 = None
        conj_physical_default_7 = torch.ops.aten.conj_physical.default(mul_tensor_689);  mul_tensor_689 = None
        mul_tensor_690 = torch.ops.aten.mul.Tensor(to_dtype_366, conj_physical_default_7);  to_dtype_366 = conj_physical_default_7 = None
        to_dtype_368 = torch.ops.aten.to.dtype(mul_tensor_690, torch.float32);  mul_tensor_690 = None
        convolution_backward_default_186 = torch.ops.aten.convolution_backward.default(to_dtype_368, silu__default_46, primals_338, [672], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_368 = silu__default_46 = primals_338 = None
        getitem_1350 = convolution_backward_default_186[0]
        getitem_1351 = convolution_backward_default_186[1]
        getitem_1352 = convolution_backward_default_186[2];  convolution_backward_default_186 = None
        to_dtype_369 = torch.ops.aten.to.dtype(getitem_1350, torch.float32);  getitem_1350 = None
        to_dtype_370 = torch.ops.aten.to.dtype(clone_default_46, torch.float32);  clone_default_46 = None
        neg_default_159 = torch.ops.aten.neg.default(to_dtype_370)
        exp_default_83 = torch.ops.aten.exp.default(neg_default_159);  neg_default_159 = None
        add_tensor_522 = torch.ops.aten.add.Tensor(exp_default_83, 1);  exp_default_83 = None
        reciprocal_default_83 = torch.ops.aten.reciprocal.default(add_tensor_522);  add_tensor_522 = None
        mul_tensor_691 = torch.ops.aten.mul.Tensor(reciprocal_default_83, 1);  reciprocal_default_83 = None
        mul_tensor_692 = torch.ops.aten.mul.Tensor(to_dtype_369, mul_tensor_691);  to_dtype_369 = None
        rsub_scalar_91 = torch.ops.aten.rsub.Scalar(mul_tensor_691, 1);  mul_tensor_691 = None
        mul_tensor_693 = torch.ops.aten.mul.Tensor(to_dtype_370, rsub_scalar_91);  to_dtype_370 = rsub_scalar_91 = None
        add_tensor_523 = torch.ops.aten.add.Tensor(mul_tensor_693, 1);  mul_tensor_693 = None
        mul_tensor_694 = torch.ops.aten.mul.Tensor(mul_tensor_692, add_tensor_523);  mul_tensor_692 = add_tensor_523 = None
        to_dtype_371 = torch.ops.aten.to.dtype(mul_tensor_694, torch.float32);  mul_tensor_694 = None
        convolution_backward_default_187 = torch.ops.aten.convolution_backward.default(to_dtype_371, mean_dim_15, primals_340, [28], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_371 = mean_dim_15 = primals_340 = None
        getitem_1353 = convolution_backward_default_187[0]
        getitem_1354 = convolution_backward_default_187[1]
        getitem_1355 = convolution_backward_default_187[2];  convolution_backward_default_187 = None
        expand_default_71 = torch.ops.aten.expand.default(getitem_1353, [1, 672, 40, 40]);  getitem_1353 = None
        div_scalar_7 = torch.ops.aten.div.Scalar(expand_default_71, 1600);  expand_default_71 = None
        add_tensor_524 = torch.ops.aten.add.Tensor(mul_tensor_688, div_scalar_7);  mul_tensor_688 = div_scalar_7 = None
        to_dtype_372 = torch.ops.aten.to.dtype(add_tensor_524, torch.float32);  add_tensor_524 = None
        to_dtype_373 = torch.ops.aten.to.dtype(clone_default_45, torch.float32);  clone_default_45 = None
        neg_default_160 = torch.ops.aten.neg.default(to_dtype_373)
        exp_default_84 = torch.ops.aten.exp.default(neg_default_160);  neg_default_160 = None
        add_tensor_525 = torch.ops.aten.add.Tensor(exp_default_84, 1);  exp_default_84 = None
        reciprocal_default_84 = torch.ops.aten.reciprocal.default(add_tensor_525);  add_tensor_525 = None
        mul_tensor_695 = torch.ops.aten.mul.Tensor(reciprocal_default_84, 1);  reciprocal_default_84 = None
        mul_tensor_696 = torch.ops.aten.mul.Tensor(to_dtype_372, mul_tensor_695);  to_dtype_372 = None
        rsub_scalar_92 = torch.ops.aten.rsub.Scalar(mul_tensor_695, 1);  mul_tensor_695 = None
        mul_tensor_697 = torch.ops.aten.mul.Tensor(to_dtype_373, rsub_scalar_92);  to_dtype_373 = rsub_scalar_92 = None
        add_tensor_526 = torch.ops.aten.add.Tensor(mul_tensor_697, 1);  mul_tensor_697 = None
        mul_tensor_698 = torch.ops.aten.mul.Tensor(mul_tensor_696, add_tensor_526);  mul_tensor_696 = add_tensor_526 = None
        to_dtype_374 = torch.ops.aten.to.dtype(mul_tensor_698, torch.float32);  mul_tensor_698 = None
        native_batch_norm_backward_default_90 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_374, convolution_default_75, primals_328, primals_326, primals_327, new_zeros_default_135, new_zeros_default_136, False, 0.001, [True, True, True]);  to_dtype_374 = convolution_default_75 = primals_328 = primals_326 = primals_327 = new_zeros_default_135 = new_zeros_default_136 = None
        getitem_1356 = native_batch_norm_backward_default_90[0]
        getitem_1357 = native_batch_norm_backward_default_90[1]
        getitem_1358 = native_batch_norm_backward_default_90[2];  native_batch_norm_backward_default_90 = None
        convolution_backward_default_188 = torch.ops.aten.convolution_backward.default(getitem_1356, silu__default_44, primals_334, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1356 = silu__default_44 = primals_334 = None
        getitem_1359 = convolution_backward_default_188[0]
        getitem_1360 = convolution_backward_default_188[1]
        getitem_1361 = convolution_backward_default_188[2];  convolution_backward_default_188 = None
        to_dtype_375 = torch.ops.aten.to.dtype(getitem_1359, torch.float32);  getitem_1359 = None
        to_dtype_376 = torch.ops.aten.to.dtype(clone_default_44, torch.float32);  clone_default_44 = None
        neg_default_161 = torch.ops.aten.neg.default(to_dtype_376)
        exp_default_85 = torch.ops.aten.exp.default(neg_default_161);  neg_default_161 = None
        add_tensor_527 = torch.ops.aten.add.Tensor(exp_default_85, 1);  exp_default_85 = None
        reciprocal_default_85 = torch.ops.aten.reciprocal.default(add_tensor_527);  add_tensor_527 = None
        mul_tensor_699 = torch.ops.aten.mul.Tensor(reciprocal_default_85, 1);  reciprocal_default_85 = None
        mul_tensor_700 = torch.ops.aten.mul.Tensor(to_dtype_375, mul_tensor_699);  to_dtype_375 = None
        rsub_scalar_93 = torch.ops.aten.rsub.Scalar(mul_tensor_699, 1);  mul_tensor_699 = None
        mul_tensor_701 = torch.ops.aten.mul.Tensor(to_dtype_376, rsub_scalar_93);  to_dtype_376 = rsub_scalar_93 = None
        add_tensor_528 = torch.ops.aten.add.Tensor(mul_tensor_701, 1);  mul_tensor_701 = None
        mul_tensor_702 = torch.ops.aten.mul.Tensor(mul_tensor_700, add_tensor_528);  mul_tensor_700 = add_tensor_528 = None
        to_dtype_377 = torch.ops.aten.to.dtype(mul_tensor_702, torch.float32);  mul_tensor_702 = None
        native_batch_norm_backward_default_91 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_377, convolution_default_74, primals_323, primals_321, primals_322, new_zeros_default_132, new_zeros_default_133, False, 0.001, [True, True, True]);  to_dtype_377 = convolution_default_74 = primals_323 = primals_321 = primals_322 = new_zeros_default_132 = new_zeros_default_133 = None
        getitem_1362 = native_batch_norm_backward_default_91[0]
        getitem_1363 = native_batch_norm_backward_default_91[1]
        getitem_1364 = native_batch_norm_backward_default_91[2];  native_batch_norm_backward_default_91 = None
        convolution_backward_default_189 = torch.ops.aten.convolution_backward.default(getitem_1362, add__tensor_9, primals_335, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1362 = add__tensor_9 = primals_335 = None
        getitem_1365 = convolution_backward_default_189[0]
        getitem_1366 = convolution_backward_default_189[1]
        getitem_1367 = convolution_backward_default_189[2];  convolution_backward_default_189 = None
        add_tensor_529 = torch.ops.aten.add.Tensor(add_tensor_521, getitem_1365);  add_tensor_521 = getitem_1365 = None
        native_batch_norm_backward_default_92 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_529, convolution_default_73, primals_311, primals_309, primals_310, new_zeros_default_129, new_zeros_default_130, False, 0.001, [True, True, True]);  convolution_default_73 = primals_311 = primals_309 = primals_310 = new_zeros_default_129 = new_zeros_default_130 = None
        getitem_1368 = native_batch_norm_backward_default_92[0]
        getitem_1369 = native_batch_norm_backward_default_92[1]
        getitem_1370 = native_batch_norm_backward_default_92[2];  native_batch_norm_backward_default_92 = None
        convolution_backward_default_190 = torch.ops.aten.convolution_backward.default(getitem_1368, mul_tensor_14, primals_314, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1368 = mul_tensor_14 = primals_314 = None
        getitem_1371 = convolution_backward_default_190[0]
        getitem_1372 = convolution_backward_default_190[1]
        getitem_1373 = convolution_backward_default_190[2];  convolution_backward_default_190 = None
        mul_tensor_703 = torch.ops.aten.mul.Tensor(getitem_1371, silu__default_42);  silu__default_42 = None
        mul_tensor_704 = torch.ops.aten.mul.Tensor(getitem_1371, sigmoid_default_14);  getitem_1371 = None
        sum_dim_int_list_40 = torch.ops.aten.sum.dim_IntList(mul_tensor_703, [2, 3], True);  mul_tensor_703 = None
        to_dtype_378 = torch.ops.aten.to.dtype(sum_dim_int_list_40, torch.float32);  sum_dim_int_list_40 = None
        to_dtype_379 = torch.ops.aten.to.dtype(sigmoid_default_14, torch.float32);  sigmoid_default_14 = None
        rsub_scalar_94 = torch.ops.aten.rsub.Scalar(to_dtype_379, 1)
        mul_tensor_705 = torch.ops.aten.mul.Tensor(to_dtype_379, rsub_scalar_94);  to_dtype_379 = rsub_scalar_94 = None
        conj_physical_default_8 = torch.ops.aten.conj_physical.default(mul_tensor_705);  mul_tensor_705 = None
        mul_tensor_706 = torch.ops.aten.mul.Tensor(to_dtype_378, conj_physical_default_8);  to_dtype_378 = conj_physical_default_8 = None
        to_dtype_380 = torch.ops.aten.to.dtype(mul_tensor_706, torch.float32);  mul_tensor_706 = None
        convolution_backward_default_191 = torch.ops.aten.convolution_backward.default(to_dtype_380, silu__default_43, primals_316, [672], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_380 = silu__default_43 = primals_316 = None
        getitem_1374 = convolution_backward_default_191[0]
        getitem_1375 = convolution_backward_default_191[1]
        getitem_1376 = convolution_backward_default_191[2];  convolution_backward_default_191 = None
        to_dtype_381 = torch.ops.aten.to.dtype(getitem_1374, torch.float32);  getitem_1374 = None
        to_dtype_382 = torch.ops.aten.to.dtype(clone_default_43, torch.float32);  clone_default_43 = None
        neg_default_162 = torch.ops.aten.neg.default(to_dtype_382)
        exp_default_86 = torch.ops.aten.exp.default(neg_default_162);  neg_default_162 = None
        add_tensor_530 = torch.ops.aten.add.Tensor(exp_default_86, 1);  exp_default_86 = None
        reciprocal_default_86 = torch.ops.aten.reciprocal.default(add_tensor_530);  add_tensor_530 = None
        mul_tensor_707 = torch.ops.aten.mul.Tensor(reciprocal_default_86, 1);  reciprocal_default_86 = None
        mul_tensor_708 = torch.ops.aten.mul.Tensor(to_dtype_381, mul_tensor_707);  to_dtype_381 = None
        rsub_scalar_95 = torch.ops.aten.rsub.Scalar(mul_tensor_707, 1);  mul_tensor_707 = None
        mul_tensor_709 = torch.ops.aten.mul.Tensor(to_dtype_382, rsub_scalar_95);  to_dtype_382 = rsub_scalar_95 = None
        add_tensor_531 = torch.ops.aten.add.Tensor(mul_tensor_709, 1);  mul_tensor_709 = None
        mul_tensor_710 = torch.ops.aten.mul.Tensor(mul_tensor_708, add_tensor_531);  mul_tensor_708 = add_tensor_531 = None
        to_dtype_383 = torch.ops.aten.to.dtype(mul_tensor_710, torch.float32);  mul_tensor_710 = None
        convolution_backward_default_192 = torch.ops.aten.convolution_backward.default(to_dtype_383, mean_dim_14, primals_318, [28], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_383 = mean_dim_14 = primals_318 = None
        getitem_1377 = convolution_backward_default_192[0]
        getitem_1378 = convolution_backward_default_192[1]
        getitem_1379 = convolution_backward_default_192[2];  convolution_backward_default_192 = None
        expand_default_72 = torch.ops.aten.expand.default(getitem_1377, [1, 672, 40, 40]);  getitem_1377 = None
        div_scalar_8 = torch.ops.aten.div.Scalar(expand_default_72, 1600);  expand_default_72 = None
        add_tensor_532 = torch.ops.aten.add.Tensor(mul_tensor_704, div_scalar_8);  mul_tensor_704 = div_scalar_8 = None
        to_dtype_384 = torch.ops.aten.to.dtype(add_tensor_532, torch.float32);  add_tensor_532 = None
        to_dtype_385 = torch.ops.aten.to.dtype(clone_default_42, torch.float32);  clone_default_42 = None
        neg_default_163 = torch.ops.aten.neg.default(to_dtype_385)
        exp_default_87 = torch.ops.aten.exp.default(neg_default_163);  neg_default_163 = None
        add_tensor_533 = torch.ops.aten.add.Tensor(exp_default_87, 1);  exp_default_87 = None
        reciprocal_default_87 = torch.ops.aten.reciprocal.default(add_tensor_533);  add_tensor_533 = None
        mul_tensor_711 = torch.ops.aten.mul.Tensor(reciprocal_default_87, 1);  reciprocal_default_87 = None
        mul_tensor_712 = torch.ops.aten.mul.Tensor(to_dtype_384, mul_tensor_711);  to_dtype_384 = None
        rsub_scalar_96 = torch.ops.aten.rsub.Scalar(mul_tensor_711, 1);  mul_tensor_711 = None
        mul_tensor_713 = torch.ops.aten.mul.Tensor(to_dtype_385, rsub_scalar_96);  to_dtype_385 = rsub_scalar_96 = None
        add_tensor_534 = torch.ops.aten.add.Tensor(mul_tensor_713, 1);  mul_tensor_713 = None
        mul_tensor_714 = torch.ops.aten.mul.Tensor(mul_tensor_712, add_tensor_534);  mul_tensor_712 = add_tensor_534 = None
        to_dtype_386 = torch.ops.aten.to.dtype(mul_tensor_714, torch.float32);  mul_tensor_714 = None
        native_batch_norm_backward_default_93 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_386, convolution_default_70, primals_306, primals_304, primals_305, new_zeros_default_126, new_zeros_default_127, False, 0.001, [True, True, True]);  to_dtype_386 = convolution_default_70 = primals_306 = primals_304 = primals_305 = new_zeros_default_126 = new_zeros_default_127 = None
        getitem_1380 = native_batch_norm_backward_default_93[0]
        getitem_1381 = native_batch_norm_backward_default_93[1]
        getitem_1382 = native_batch_norm_backward_default_93[2];  native_batch_norm_backward_default_93 = None
        convolution_backward_default_193 = torch.ops.aten.convolution_backward.default(getitem_1380, silu__default_41, primals_312, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1380 = silu__default_41 = primals_312 = None
        getitem_1383 = convolution_backward_default_193[0]
        getitem_1384 = convolution_backward_default_193[1]
        getitem_1385 = convolution_backward_default_193[2];  convolution_backward_default_193 = None
        to_dtype_387 = torch.ops.aten.to.dtype(getitem_1383, torch.float32);  getitem_1383 = None
        to_dtype_388 = torch.ops.aten.to.dtype(clone_default_41, torch.float32);  clone_default_41 = None
        neg_default_164 = torch.ops.aten.neg.default(to_dtype_388)
        exp_default_88 = torch.ops.aten.exp.default(neg_default_164);  neg_default_164 = None
        add_tensor_535 = torch.ops.aten.add.Tensor(exp_default_88, 1);  exp_default_88 = None
        reciprocal_default_88 = torch.ops.aten.reciprocal.default(add_tensor_535);  add_tensor_535 = None
        mul_tensor_715 = torch.ops.aten.mul.Tensor(reciprocal_default_88, 1);  reciprocal_default_88 = None
        mul_tensor_716 = torch.ops.aten.mul.Tensor(to_dtype_387, mul_tensor_715);  to_dtype_387 = None
        rsub_scalar_97 = torch.ops.aten.rsub.Scalar(mul_tensor_715, 1);  mul_tensor_715 = None
        mul_tensor_717 = torch.ops.aten.mul.Tensor(to_dtype_388, rsub_scalar_97);  to_dtype_388 = rsub_scalar_97 = None
        add_tensor_536 = torch.ops.aten.add.Tensor(mul_tensor_717, 1);  mul_tensor_717 = None
        mul_tensor_718 = torch.ops.aten.mul.Tensor(mul_tensor_716, add_tensor_536);  mul_tensor_716 = add_tensor_536 = None
        to_dtype_389 = torch.ops.aten.to.dtype(mul_tensor_718, torch.float32);  mul_tensor_718 = None
        native_batch_norm_backward_default_94 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_389, convolution_default_69, primals_301, primals_299, primals_300, new_zeros_default_123, new_zeros_default_124, False, 0.001, [True, True, True]);  to_dtype_389 = convolution_default_69 = primals_301 = primals_299 = primals_300 = new_zeros_default_123 = new_zeros_default_124 = None
        getitem_1386 = native_batch_norm_backward_default_94[0]
        getitem_1387 = native_batch_norm_backward_default_94[1]
        getitem_1388 = native_batch_norm_backward_default_94[2];  native_batch_norm_backward_default_94 = None
        convolution_backward_default_194 = torch.ops.aten.convolution_backward.default(getitem_1386, add__tensor_8, primals_313, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1386 = add__tensor_8 = primals_313 = None
        getitem_1389 = convolution_backward_default_194[0]
        getitem_1390 = convolution_backward_default_194[1]
        getitem_1391 = convolution_backward_default_194[2];  convolution_backward_default_194 = None
        add_tensor_537 = torch.ops.aten.add.Tensor(add_tensor_529, getitem_1389);  add_tensor_529 = getitem_1389 = None
        native_batch_norm_backward_default_95 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_537, convolution_default_68, primals_289, primals_287, primals_288, new_zeros_default_120, new_zeros_default_121, False, 0.001, [True, True, True]);  convolution_default_68 = primals_289 = primals_287 = primals_288 = new_zeros_default_120 = new_zeros_default_121 = None
        getitem_1392 = native_batch_norm_backward_default_95[0]
        getitem_1393 = native_batch_norm_backward_default_95[1]
        getitem_1394 = native_batch_norm_backward_default_95[2];  native_batch_norm_backward_default_95 = None
        convolution_backward_default_195 = torch.ops.aten.convolution_backward.default(getitem_1392, mul_tensor_13, primals_292, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1392 = mul_tensor_13 = primals_292 = None
        getitem_1395 = convolution_backward_default_195[0]
        getitem_1396 = convolution_backward_default_195[1]
        getitem_1397 = convolution_backward_default_195[2];  convolution_backward_default_195 = None
        mul_tensor_719 = torch.ops.aten.mul.Tensor(getitem_1395, silu__default_39);  silu__default_39 = None
        mul_tensor_720 = torch.ops.aten.mul.Tensor(getitem_1395, sigmoid_default_13);  getitem_1395 = None
        sum_dim_int_list_41 = torch.ops.aten.sum.dim_IntList(mul_tensor_719, [2, 3], True);  mul_tensor_719 = None
        to_dtype_390 = torch.ops.aten.to.dtype(sum_dim_int_list_41, torch.float32);  sum_dim_int_list_41 = None
        to_dtype_391 = torch.ops.aten.to.dtype(sigmoid_default_13, torch.float32);  sigmoid_default_13 = None
        rsub_scalar_98 = torch.ops.aten.rsub.Scalar(to_dtype_391, 1)
        mul_tensor_721 = torch.ops.aten.mul.Tensor(to_dtype_391, rsub_scalar_98);  to_dtype_391 = rsub_scalar_98 = None
        conj_physical_default_9 = torch.ops.aten.conj_physical.default(mul_tensor_721);  mul_tensor_721 = None
        mul_tensor_722 = torch.ops.aten.mul.Tensor(to_dtype_390, conj_physical_default_9);  to_dtype_390 = conj_physical_default_9 = None
        to_dtype_392 = torch.ops.aten.to.dtype(mul_tensor_722, torch.float32);  mul_tensor_722 = None
        convolution_backward_default_196 = torch.ops.aten.convolution_backward.default(to_dtype_392, silu__default_40, primals_294, [672], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_392 = silu__default_40 = primals_294 = None
        getitem_1398 = convolution_backward_default_196[0]
        getitem_1399 = convolution_backward_default_196[1]
        getitem_1400 = convolution_backward_default_196[2];  convolution_backward_default_196 = None
        to_dtype_393 = torch.ops.aten.to.dtype(getitem_1398, torch.float32);  getitem_1398 = None
        to_dtype_394 = torch.ops.aten.to.dtype(clone_default_40, torch.float32);  clone_default_40 = None
        neg_default_165 = torch.ops.aten.neg.default(to_dtype_394)
        exp_default_89 = torch.ops.aten.exp.default(neg_default_165);  neg_default_165 = None
        add_tensor_538 = torch.ops.aten.add.Tensor(exp_default_89, 1);  exp_default_89 = None
        reciprocal_default_89 = torch.ops.aten.reciprocal.default(add_tensor_538);  add_tensor_538 = None
        mul_tensor_723 = torch.ops.aten.mul.Tensor(reciprocal_default_89, 1);  reciprocal_default_89 = None
        mul_tensor_724 = torch.ops.aten.mul.Tensor(to_dtype_393, mul_tensor_723);  to_dtype_393 = None
        rsub_scalar_99 = torch.ops.aten.rsub.Scalar(mul_tensor_723, 1);  mul_tensor_723 = None
        mul_tensor_725 = torch.ops.aten.mul.Tensor(to_dtype_394, rsub_scalar_99);  to_dtype_394 = rsub_scalar_99 = None
        add_tensor_539 = torch.ops.aten.add.Tensor(mul_tensor_725, 1);  mul_tensor_725 = None
        mul_tensor_726 = torch.ops.aten.mul.Tensor(mul_tensor_724, add_tensor_539);  mul_tensor_724 = add_tensor_539 = None
        to_dtype_395 = torch.ops.aten.to.dtype(mul_tensor_726, torch.float32);  mul_tensor_726 = None
        convolution_backward_default_197 = torch.ops.aten.convolution_backward.default(to_dtype_395, mean_dim_13, primals_296, [28], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_395 = mean_dim_13 = primals_296 = None
        getitem_1401 = convolution_backward_default_197[0]
        getitem_1402 = convolution_backward_default_197[1]
        getitem_1403 = convolution_backward_default_197[2];  convolution_backward_default_197 = None
        expand_default_73 = torch.ops.aten.expand.default(getitem_1401, [1, 672, 40, 40]);  getitem_1401 = None
        div_scalar_9 = torch.ops.aten.div.Scalar(expand_default_73, 1600);  expand_default_73 = None
        add_tensor_540 = torch.ops.aten.add.Tensor(mul_tensor_720, div_scalar_9);  mul_tensor_720 = div_scalar_9 = None
        to_dtype_396 = torch.ops.aten.to.dtype(add_tensor_540, torch.float32);  add_tensor_540 = None
        to_dtype_397 = torch.ops.aten.to.dtype(clone_default_39, torch.float32);  clone_default_39 = None
        neg_default_166 = torch.ops.aten.neg.default(to_dtype_397)
        exp_default_90 = torch.ops.aten.exp.default(neg_default_166);  neg_default_166 = None
        add_tensor_541 = torch.ops.aten.add.Tensor(exp_default_90, 1);  exp_default_90 = None
        reciprocal_default_90 = torch.ops.aten.reciprocal.default(add_tensor_541);  add_tensor_541 = None
        mul_tensor_727 = torch.ops.aten.mul.Tensor(reciprocal_default_90, 1);  reciprocal_default_90 = None
        mul_tensor_728 = torch.ops.aten.mul.Tensor(to_dtype_396, mul_tensor_727);  to_dtype_396 = None
        rsub_scalar_100 = torch.ops.aten.rsub.Scalar(mul_tensor_727, 1);  mul_tensor_727 = None
        mul_tensor_729 = torch.ops.aten.mul.Tensor(to_dtype_397, rsub_scalar_100);  to_dtype_397 = rsub_scalar_100 = None
        add_tensor_542 = torch.ops.aten.add.Tensor(mul_tensor_729, 1);  mul_tensor_729 = None
        mul_tensor_730 = torch.ops.aten.mul.Tensor(mul_tensor_728, add_tensor_542);  mul_tensor_728 = add_tensor_542 = None
        to_dtype_398 = torch.ops.aten.to.dtype(mul_tensor_730, torch.float32);  mul_tensor_730 = None
        native_batch_norm_backward_default_96 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_398, convolution_default_65, primals_284, primals_282, primals_283, new_zeros_default_117, new_zeros_default_118, False, 0.001, [True, True, True]);  to_dtype_398 = convolution_default_65 = primals_284 = primals_282 = primals_283 = new_zeros_default_117 = new_zeros_default_118 = None
        getitem_1404 = native_batch_norm_backward_default_96[0]
        getitem_1405 = native_batch_norm_backward_default_96[1]
        getitem_1406 = native_batch_norm_backward_default_96[2];  native_batch_norm_backward_default_96 = None
        convolution_backward_default_198 = torch.ops.aten.convolution_backward.default(getitem_1404, silu__default_38, primals_290, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1404 = silu__default_38 = primals_290 = None
        getitem_1407 = convolution_backward_default_198[0]
        getitem_1408 = convolution_backward_default_198[1]
        getitem_1409 = convolution_backward_default_198[2];  convolution_backward_default_198 = None
        to_dtype_399 = torch.ops.aten.to.dtype(getitem_1407, torch.float32);  getitem_1407 = None
        to_dtype_400 = torch.ops.aten.to.dtype(clone_default_38, torch.float32);  clone_default_38 = None
        neg_default_167 = torch.ops.aten.neg.default(to_dtype_400)
        exp_default_91 = torch.ops.aten.exp.default(neg_default_167);  neg_default_167 = None
        add_tensor_543 = torch.ops.aten.add.Tensor(exp_default_91, 1);  exp_default_91 = None
        reciprocal_default_91 = torch.ops.aten.reciprocal.default(add_tensor_543);  add_tensor_543 = None
        mul_tensor_731 = torch.ops.aten.mul.Tensor(reciprocal_default_91, 1);  reciprocal_default_91 = None
        mul_tensor_732 = torch.ops.aten.mul.Tensor(to_dtype_399, mul_tensor_731);  to_dtype_399 = None
        rsub_scalar_101 = torch.ops.aten.rsub.Scalar(mul_tensor_731, 1);  mul_tensor_731 = None
        mul_tensor_733 = torch.ops.aten.mul.Tensor(to_dtype_400, rsub_scalar_101);  to_dtype_400 = rsub_scalar_101 = None
        add_tensor_544 = torch.ops.aten.add.Tensor(mul_tensor_733, 1);  mul_tensor_733 = None
        mul_tensor_734 = torch.ops.aten.mul.Tensor(mul_tensor_732, add_tensor_544);  mul_tensor_732 = add_tensor_544 = None
        to_dtype_401 = torch.ops.aten.to.dtype(mul_tensor_734, torch.float32);  mul_tensor_734 = None
        native_batch_norm_backward_default_97 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_401, convolution_default_64, primals_279, primals_277, primals_278, new_zeros_default_114, new_zeros_default_115, False, 0.001, [True, True, True]);  to_dtype_401 = convolution_default_64 = primals_279 = primals_277 = primals_278 = new_zeros_default_114 = new_zeros_default_115 = None
        getitem_1410 = native_batch_norm_backward_default_97[0]
        getitem_1411 = native_batch_norm_backward_default_97[1]
        getitem_1412 = native_batch_norm_backward_default_97[2];  native_batch_norm_backward_default_97 = None
        convolution_backward_default_199 = torch.ops.aten.convolution_backward.default(getitem_1410, getitem_111, primals_291, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1410 = getitem_111 = primals_291 = None
        getitem_1413 = convolution_backward_default_199[0]
        getitem_1414 = convolution_backward_default_199[1]
        getitem_1415 = convolution_backward_default_199[2];  convolution_backward_default_199 = None
        add_tensor_545 = torch.ops.aten.add.Tensor(add_tensor_537, getitem_1413);  add_tensor_537 = getitem_1413 = None
        native_batch_norm_backward_default_98 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_545, convolution_default_63, primals_267, primals_265, primals_266, new_zeros_default_111, new_zeros_default_112, False, 0.001, [True, True, True]);  add_tensor_545 = convolution_default_63 = primals_267 = primals_265 = primals_266 = new_zeros_default_111 = new_zeros_default_112 = None
        getitem_1416 = native_batch_norm_backward_default_98[0]
        getitem_1417 = native_batch_norm_backward_default_98[1]
        getitem_1418 = native_batch_norm_backward_default_98[2];  native_batch_norm_backward_default_98 = None
        convolution_backward_default_200 = torch.ops.aten.convolution_backward.default(getitem_1416, mul_tensor_12, primals_270, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1416 = mul_tensor_12 = primals_270 = None
        getitem_1419 = convolution_backward_default_200[0]
        getitem_1420 = convolution_backward_default_200[1]
        getitem_1421 = convolution_backward_default_200[2];  convolution_backward_default_200 = None
        mul_tensor_735 = torch.ops.aten.mul.Tensor(getitem_1419, silu__default_36);  silu__default_36 = None
        mul_tensor_736 = torch.ops.aten.mul.Tensor(getitem_1419, sigmoid_default_12);  getitem_1419 = None
        sum_dim_int_list_42 = torch.ops.aten.sum.dim_IntList(mul_tensor_735, [2, 3], True);  mul_tensor_735 = None
        to_dtype_402 = torch.ops.aten.to.dtype(sum_dim_int_list_42, torch.float32);  sum_dim_int_list_42 = None
        to_dtype_403 = torch.ops.aten.to.dtype(sigmoid_default_12, torch.float32);  sigmoid_default_12 = None
        rsub_scalar_102 = torch.ops.aten.rsub.Scalar(to_dtype_403, 1)
        mul_tensor_737 = torch.ops.aten.mul.Tensor(to_dtype_403, rsub_scalar_102);  to_dtype_403 = rsub_scalar_102 = None
        conj_physical_default_10 = torch.ops.aten.conj_physical.default(mul_tensor_737);  mul_tensor_737 = None
        mul_tensor_738 = torch.ops.aten.mul.Tensor(to_dtype_402, conj_physical_default_10);  to_dtype_402 = conj_physical_default_10 = None
        to_dtype_404 = torch.ops.aten.to.dtype(mul_tensor_738, torch.float32);  mul_tensor_738 = None
        convolution_backward_default_201 = torch.ops.aten.convolution_backward.default(to_dtype_404, silu__default_37, primals_272, [480], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_404 = silu__default_37 = primals_272 = None
        getitem_1422 = convolution_backward_default_201[0]
        getitem_1423 = convolution_backward_default_201[1]
        getitem_1424 = convolution_backward_default_201[2];  convolution_backward_default_201 = None
        to_dtype_405 = torch.ops.aten.to.dtype(getitem_1422, torch.float32);  getitem_1422 = None
        to_dtype_406 = torch.ops.aten.to.dtype(clone_default_37, torch.float32);  clone_default_37 = None
        neg_default_168 = torch.ops.aten.neg.default(to_dtype_406)
        exp_default_92 = torch.ops.aten.exp.default(neg_default_168);  neg_default_168 = None
        add_tensor_546 = torch.ops.aten.add.Tensor(exp_default_92, 1);  exp_default_92 = None
        reciprocal_default_92 = torch.ops.aten.reciprocal.default(add_tensor_546);  add_tensor_546 = None
        mul_tensor_739 = torch.ops.aten.mul.Tensor(reciprocal_default_92, 1);  reciprocal_default_92 = None
        mul_tensor_740 = torch.ops.aten.mul.Tensor(to_dtype_405, mul_tensor_739);  to_dtype_405 = None
        rsub_scalar_103 = torch.ops.aten.rsub.Scalar(mul_tensor_739, 1);  mul_tensor_739 = None
        mul_tensor_741 = torch.ops.aten.mul.Tensor(to_dtype_406, rsub_scalar_103);  to_dtype_406 = rsub_scalar_103 = None
        add_tensor_547 = torch.ops.aten.add.Tensor(mul_tensor_741, 1);  mul_tensor_741 = None
        mul_tensor_742 = torch.ops.aten.mul.Tensor(mul_tensor_740, add_tensor_547);  mul_tensor_740 = add_tensor_547 = None
        to_dtype_407 = torch.ops.aten.to.dtype(mul_tensor_742, torch.float32);  mul_tensor_742 = None
        convolution_backward_default_202 = torch.ops.aten.convolution_backward.default(to_dtype_407, mean_dim_12, primals_274, [20], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_407 = mean_dim_12 = primals_274 = None
        getitem_1425 = convolution_backward_default_202[0]
        getitem_1426 = convolution_backward_default_202[1]
        getitem_1427 = convolution_backward_default_202[2];  convolution_backward_default_202 = None
        expand_default_74 = torch.ops.aten.expand.default(getitem_1425, [1, 480, 40, 40]);  getitem_1425 = None
        div_scalar_10 = torch.ops.aten.div.Scalar(expand_default_74, 1600);  expand_default_74 = None
        add_tensor_548 = torch.ops.aten.add.Tensor(mul_tensor_736, div_scalar_10);  mul_tensor_736 = div_scalar_10 = None
        to_dtype_408 = torch.ops.aten.to.dtype(add_tensor_548, torch.float32);  add_tensor_548 = None
        to_dtype_409 = torch.ops.aten.to.dtype(clone_default_36, torch.float32);  clone_default_36 = None
        neg_default_169 = torch.ops.aten.neg.default(to_dtype_409)
        exp_default_93 = torch.ops.aten.exp.default(neg_default_169);  neg_default_169 = None
        add_tensor_549 = torch.ops.aten.add.Tensor(exp_default_93, 1);  exp_default_93 = None
        reciprocal_default_93 = torch.ops.aten.reciprocal.default(add_tensor_549);  add_tensor_549 = None
        mul_tensor_743 = torch.ops.aten.mul.Tensor(reciprocal_default_93, 1);  reciprocal_default_93 = None
        mul_tensor_744 = torch.ops.aten.mul.Tensor(to_dtype_408, mul_tensor_743);  to_dtype_408 = None
        rsub_scalar_104 = torch.ops.aten.rsub.Scalar(mul_tensor_743, 1);  mul_tensor_743 = None
        mul_tensor_745 = torch.ops.aten.mul.Tensor(to_dtype_409, rsub_scalar_104);  to_dtype_409 = rsub_scalar_104 = None
        add_tensor_550 = torch.ops.aten.add.Tensor(mul_tensor_745, 1);  mul_tensor_745 = None
        mul_tensor_746 = torch.ops.aten.mul.Tensor(mul_tensor_744, add_tensor_550);  mul_tensor_744 = add_tensor_550 = None
        to_dtype_410 = torch.ops.aten.to.dtype(mul_tensor_746, torch.float32);  mul_tensor_746 = None
        native_batch_norm_backward_default_99 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_410, convolution_default_60, primals_262, primals_260, primals_261, new_zeros_default_108, new_zeros_default_109, False, 0.001, [True, True, True]);  to_dtype_410 = convolution_default_60 = primals_262 = primals_260 = primals_261 = new_zeros_default_108 = new_zeros_default_109 = None
        getitem_1428 = native_batch_norm_backward_default_99[0]
        getitem_1429 = native_batch_norm_backward_default_99[1]
        getitem_1430 = native_batch_norm_backward_default_99[2];  native_batch_norm_backward_default_99 = None
        convolution_backward_default_203 = torch.ops.aten.convolution_backward.default(getitem_1428, silu__default_35, primals_268, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 480, [True, True, False]);  getitem_1428 = silu__default_35 = primals_268 = None
        getitem_1431 = convolution_backward_default_203[0]
        getitem_1432 = convolution_backward_default_203[1]
        getitem_1433 = convolution_backward_default_203[2];  convolution_backward_default_203 = None
        to_dtype_411 = torch.ops.aten.to.dtype(getitem_1431, torch.float32);  getitem_1431 = None
        to_dtype_412 = torch.ops.aten.to.dtype(clone_default_35, torch.float32);  clone_default_35 = None
        neg_default_170 = torch.ops.aten.neg.default(to_dtype_412)
        exp_default_94 = torch.ops.aten.exp.default(neg_default_170);  neg_default_170 = None
        add_tensor_551 = torch.ops.aten.add.Tensor(exp_default_94, 1);  exp_default_94 = None
        reciprocal_default_94 = torch.ops.aten.reciprocal.default(add_tensor_551);  add_tensor_551 = None
        mul_tensor_747 = torch.ops.aten.mul.Tensor(reciprocal_default_94, 1);  reciprocal_default_94 = None
        mul_tensor_748 = torch.ops.aten.mul.Tensor(to_dtype_411, mul_tensor_747);  to_dtype_411 = None
        rsub_scalar_105 = torch.ops.aten.rsub.Scalar(mul_tensor_747, 1);  mul_tensor_747 = None
        mul_tensor_749 = torch.ops.aten.mul.Tensor(to_dtype_412, rsub_scalar_105);  to_dtype_412 = rsub_scalar_105 = None
        add_tensor_552 = torch.ops.aten.add.Tensor(mul_tensor_749, 1);  mul_tensor_749 = None
        mul_tensor_750 = torch.ops.aten.mul.Tensor(mul_tensor_748, add_tensor_552);  mul_tensor_748 = add_tensor_552 = None
        to_dtype_413 = torch.ops.aten.to.dtype(mul_tensor_750, torch.float32);  mul_tensor_750 = None
        native_batch_norm_backward_default_100 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_413, convolution_default_59, primals_257, primals_255, primals_256, new_zeros_default_105, new_zeros_default_106, False, 0.001, [True, True, True]);  to_dtype_413 = convolution_default_59 = primals_257 = primals_255 = primals_256 = new_zeros_default_105 = new_zeros_default_106 = None
        getitem_1434 = native_batch_norm_backward_default_100[0]
        getitem_1435 = native_batch_norm_backward_default_100[1]
        getitem_1436 = native_batch_norm_backward_default_100[2];  native_batch_norm_backward_default_100 = None
        convolution_backward_default_204 = torch.ops.aten.convolution_backward.default(getitem_1434, add__tensor_7, primals_269, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1434 = add__tensor_7 = primals_269 = None
        getitem_1437 = convolution_backward_default_204[0]
        getitem_1438 = convolution_backward_default_204[1]
        getitem_1439 = convolution_backward_default_204[2];  convolution_backward_default_204 = None
        native_batch_norm_backward_default_101 = torch.ops.aten.native_batch_norm_backward.default(getitem_1437, convolution_default_58, primals_245, primals_243, primals_244, new_zeros_default_102, new_zeros_default_103, False, 0.001, [True, True, True]);  convolution_default_58 = primals_245 = primals_243 = primals_244 = new_zeros_default_102 = new_zeros_default_103 = None
        getitem_1440 = native_batch_norm_backward_default_101[0]
        getitem_1441 = native_batch_norm_backward_default_101[1]
        getitem_1442 = native_batch_norm_backward_default_101[2];  native_batch_norm_backward_default_101 = None
        convolution_backward_default_205 = torch.ops.aten.convolution_backward.default(getitem_1440, mul_tensor_11, primals_248, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1440 = mul_tensor_11 = primals_248 = None
        getitem_1443 = convolution_backward_default_205[0]
        getitem_1444 = convolution_backward_default_205[1]
        getitem_1445 = convolution_backward_default_205[2];  convolution_backward_default_205 = None
        mul_tensor_751 = torch.ops.aten.mul.Tensor(getitem_1443, silu__default_33);  silu__default_33 = None
        mul_tensor_752 = torch.ops.aten.mul.Tensor(getitem_1443, sigmoid_default_11);  getitem_1443 = None
        sum_dim_int_list_43 = torch.ops.aten.sum.dim_IntList(mul_tensor_751, [2, 3], True);  mul_tensor_751 = None
        to_dtype_414 = torch.ops.aten.to.dtype(sum_dim_int_list_43, torch.float32);  sum_dim_int_list_43 = None
        to_dtype_415 = torch.ops.aten.to.dtype(sigmoid_default_11, torch.float32);  sigmoid_default_11 = None
        rsub_scalar_106 = torch.ops.aten.rsub.Scalar(to_dtype_415, 1)
        mul_tensor_753 = torch.ops.aten.mul.Tensor(to_dtype_415, rsub_scalar_106);  to_dtype_415 = rsub_scalar_106 = None
        conj_physical_default_11 = torch.ops.aten.conj_physical.default(mul_tensor_753);  mul_tensor_753 = None
        mul_tensor_754 = torch.ops.aten.mul.Tensor(to_dtype_414, conj_physical_default_11);  to_dtype_414 = conj_physical_default_11 = None
        to_dtype_416 = torch.ops.aten.to.dtype(mul_tensor_754, torch.float32);  mul_tensor_754 = None
        convolution_backward_default_206 = torch.ops.aten.convolution_backward.default(to_dtype_416, silu__default_34, primals_250, [480], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_416 = silu__default_34 = primals_250 = None
        getitem_1446 = convolution_backward_default_206[0]
        getitem_1447 = convolution_backward_default_206[1]
        getitem_1448 = convolution_backward_default_206[2];  convolution_backward_default_206 = None
        to_dtype_417 = torch.ops.aten.to.dtype(getitem_1446, torch.float32);  getitem_1446 = None
        to_dtype_418 = torch.ops.aten.to.dtype(clone_default_34, torch.float32);  clone_default_34 = None
        neg_default_171 = torch.ops.aten.neg.default(to_dtype_418)
        exp_default_95 = torch.ops.aten.exp.default(neg_default_171);  neg_default_171 = None
        add_tensor_553 = torch.ops.aten.add.Tensor(exp_default_95, 1);  exp_default_95 = None
        reciprocal_default_95 = torch.ops.aten.reciprocal.default(add_tensor_553);  add_tensor_553 = None
        mul_tensor_755 = torch.ops.aten.mul.Tensor(reciprocal_default_95, 1);  reciprocal_default_95 = None
        mul_tensor_756 = torch.ops.aten.mul.Tensor(to_dtype_417, mul_tensor_755);  to_dtype_417 = None
        rsub_scalar_107 = torch.ops.aten.rsub.Scalar(mul_tensor_755, 1);  mul_tensor_755 = None
        mul_tensor_757 = torch.ops.aten.mul.Tensor(to_dtype_418, rsub_scalar_107);  to_dtype_418 = rsub_scalar_107 = None
        add_tensor_554 = torch.ops.aten.add.Tensor(mul_tensor_757, 1);  mul_tensor_757 = None
        mul_tensor_758 = torch.ops.aten.mul.Tensor(mul_tensor_756, add_tensor_554);  mul_tensor_756 = add_tensor_554 = None
        to_dtype_419 = torch.ops.aten.to.dtype(mul_tensor_758, torch.float32);  mul_tensor_758 = None
        convolution_backward_default_207 = torch.ops.aten.convolution_backward.default(to_dtype_419, mean_dim_11, primals_252, [20], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_419 = mean_dim_11 = primals_252 = None
        getitem_1449 = convolution_backward_default_207[0]
        getitem_1450 = convolution_backward_default_207[1]
        getitem_1451 = convolution_backward_default_207[2];  convolution_backward_default_207 = None
        expand_default_75 = torch.ops.aten.expand.default(getitem_1449, [1, 480, 40, 40]);  getitem_1449 = None
        div_scalar_11 = torch.ops.aten.div.Scalar(expand_default_75, 1600);  expand_default_75 = None
        add_tensor_555 = torch.ops.aten.add.Tensor(mul_tensor_752, div_scalar_11);  mul_tensor_752 = div_scalar_11 = None
        to_dtype_420 = torch.ops.aten.to.dtype(add_tensor_555, torch.float32);  add_tensor_555 = None
        to_dtype_421 = torch.ops.aten.to.dtype(clone_default_33, torch.float32);  clone_default_33 = None
        neg_default_172 = torch.ops.aten.neg.default(to_dtype_421)
        exp_default_96 = torch.ops.aten.exp.default(neg_default_172);  neg_default_172 = None
        add_tensor_556 = torch.ops.aten.add.Tensor(exp_default_96, 1);  exp_default_96 = None
        reciprocal_default_96 = torch.ops.aten.reciprocal.default(add_tensor_556);  add_tensor_556 = None
        mul_tensor_759 = torch.ops.aten.mul.Tensor(reciprocal_default_96, 1);  reciprocal_default_96 = None
        mul_tensor_760 = torch.ops.aten.mul.Tensor(to_dtype_420, mul_tensor_759);  to_dtype_420 = None
        rsub_scalar_108 = torch.ops.aten.rsub.Scalar(mul_tensor_759, 1);  mul_tensor_759 = None
        mul_tensor_761 = torch.ops.aten.mul.Tensor(to_dtype_421, rsub_scalar_108);  to_dtype_421 = rsub_scalar_108 = None
        add_tensor_557 = torch.ops.aten.add.Tensor(mul_tensor_761, 1);  mul_tensor_761 = None
        mul_tensor_762 = torch.ops.aten.mul.Tensor(mul_tensor_760, add_tensor_557);  mul_tensor_760 = add_tensor_557 = None
        to_dtype_422 = torch.ops.aten.to.dtype(mul_tensor_762, torch.float32);  mul_tensor_762 = None
        native_batch_norm_backward_default_102 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_422, convolution_default_55, primals_240, primals_238, primals_239, new_zeros_default_99, new_zeros_default_100, False, 0.001, [True, True, True]);  to_dtype_422 = convolution_default_55 = primals_240 = primals_238 = primals_239 = new_zeros_default_99 = new_zeros_default_100 = None
        getitem_1452 = native_batch_norm_backward_default_102[0]
        getitem_1453 = native_batch_norm_backward_default_102[1]
        getitem_1454 = native_batch_norm_backward_default_102[2];  native_batch_norm_backward_default_102 = None
        convolution_backward_default_208 = torch.ops.aten.convolution_backward.default(getitem_1452, silu__default_32, primals_246, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 480, [True, True, False]);  getitem_1452 = silu__default_32 = primals_246 = None
        getitem_1455 = convolution_backward_default_208[0]
        getitem_1456 = convolution_backward_default_208[1]
        getitem_1457 = convolution_backward_default_208[2];  convolution_backward_default_208 = None
        to_dtype_423 = torch.ops.aten.to.dtype(getitem_1455, torch.float32);  getitem_1455 = None
        to_dtype_424 = torch.ops.aten.to.dtype(clone_default_32, torch.float32);  clone_default_32 = None
        neg_default_173 = torch.ops.aten.neg.default(to_dtype_424)
        exp_default_97 = torch.ops.aten.exp.default(neg_default_173);  neg_default_173 = None
        add_tensor_558 = torch.ops.aten.add.Tensor(exp_default_97, 1);  exp_default_97 = None
        reciprocal_default_97 = torch.ops.aten.reciprocal.default(add_tensor_558);  add_tensor_558 = None
        mul_tensor_763 = torch.ops.aten.mul.Tensor(reciprocal_default_97, 1);  reciprocal_default_97 = None
        mul_tensor_764 = torch.ops.aten.mul.Tensor(to_dtype_423, mul_tensor_763);  to_dtype_423 = None
        rsub_scalar_109 = torch.ops.aten.rsub.Scalar(mul_tensor_763, 1);  mul_tensor_763 = None
        mul_tensor_765 = torch.ops.aten.mul.Tensor(to_dtype_424, rsub_scalar_109);  to_dtype_424 = rsub_scalar_109 = None
        add_tensor_559 = torch.ops.aten.add.Tensor(mul_tensor_765, 1);  mul_tensor_765 = None
        mul_tensor_766 = torch.ops.aten.mul.Tensor(mul_tensor_764, add_tensor_559);  mul_tensor_764 = add_tensor_559 = None
        to_dtype_425 = torch.ops.aten.to.dtype(mul_tensor_766, torch.float32);  mul_tensor_766 = None
        native_batch_norm_backward_default_103 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_425, convolution_default_54, primals_235, primals_233, primals_234, new_zeros_default_96, new_zeros_default_97, False, 0.001, [True, True, True]);  to_dtype_425 = convolution_default_54 = primals_235 = primals_233 = primals_234 = new_zeros_default_96 = new_zeros_default_97 = None
        getitem_1458 = native_batch_norm_backward_default_103[0]
        getitem_1459 = native_batch_norm_backward_default_103[1]
        getitem_1460 = native_batch_norm_backward_default_103[2];  native_batch_norm_backward_default_103 = None
        convolution_backward_default_209 = torch.ops.aten.convolution_backward.default(getitem_1458, add__tensor_6, primals_247, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1458 = add__tensor_6 = primals_247 = None
        getitem_1461 = convolution_backward_default_209[0]
        getitem_1462 = convolution_backward_default_209[1]
        getitem_1463 = convolution_backward_default_209[2];  convolution_backward_default_209 = None
        add_tensor_560 = torch.ops.aten.add.Tensor(getitem_1437, getitem_1461);  getitem_1437 = getitem_1461 = None
        native_batch_norm_backward_default_104 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_560, convolution_default_53, primals_223, primals_221, primals_222, new_zeros_default_93, new_zeros_default_94, False, 0.001, [True, True, True]);  convolution_default_53 = primals_223 = primals_221 = primals_222 = new_zeros_default_93 = new_zeros_default_94 = None
        getitem_1464 = native_batch_norm_backward_default_104[0]
        getitem_1465 = native_batch_norm_backward_default_104[1]
        getitem_1466 = native_batch_norm_backward_default_104[2];  native_batch_norm_backward_default_104 = None
        convolution_backward_default_210 = torch.ops.aten.convolution_backward.default(getitem_1464, mul_tensor_10, primals_226, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1464 = mul_tensor_10 = primals_226 = None
        getitem_1467 = convolution_backward_default_210[0]
        getitem_1468 = convolution_backward_default_210[1]
        getitem_1469 = convolution_backward_default_210[2];  convolution_backward_default_210 = None
        mul_tensor_767 = torch.ops.aten.mul.Tensor(getitem_1467, silu__default_30);  silu__default_30 = None
        mul_tensor_768 = torch.ops.aten.mul.Tensor(getitem_1467, sigmoid_default_10);  getitem_1467 = None
        sum_dim_int_list_44 = torch.ops.aten.sum.dim_IntList(mul_tensor_767, [2, 3], True);  mul_tensor_767 = None
        to_dtype_426 = torch.ops.aten.to.dtype(sum_dim_int_list_44, torch.float32);  sum_dim_int_list_44 = None
        to_dtype_427 = torch.ops.aten.to.dtype(sigmoid_default_10, torch.float32);  sigmoid_default_10 = None
        rsub_scalar_110 = torch.ops.aten.rsub.Scalar(to_dtype_427, 1)
        mul_tensor_769 = torch.ops.aten.mul.Tensor(to_dtype_427, rsub_scalar_110);  to_dtype_427 = rsub_scalar_110 = None
        conj_physical_default_12 = torch.ops.aten.conj_physical.default(mul_tensor_769);  mul_tensor_769 = None
        mul_tensor_770 = torch.ops.aten.mul.Tensor(to_dtype_426, conj_physical_default_12);  to_dtype_426 = conj_physical_default_12 = None
        to_dtype_428 = torch.ops.aten.to.dtype(mul_tensor_770, torch.float32);  mul_tensor_770 = None
        convolution_backward_default_211 = torch.ops.aten.convolution_backward.default(to_dtype_428, silu__default_31, primals_228, [480], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_428 = silu__default_31 = primals_228 = None
        getitem_1470 = convolution_backward_default_211[0]
        getitem_1471 = convolution_backward_default_211[1]
        getitem_1472 = convolution_backward_default_211[2];  convolution_backward_default_211 = None
        to_dtype_429 = torch.ops.aten.to.dtype(getitem_1470, torch.float32);  getitem_1470 = None
        to_dtype_430 = torch.ops.aten.to.dtype(clone_default_31, torch.float32);  clone_default_31 = None
        neg_default_174 = torch.ops.aten.neg.default(to_dtype_430)
        exp_default_98 = torch.ops.aten.exp.default(neg_default_174);  neg_default_174 = None
        add_tensor_561 = torch.ops.aten.add.Tensor(exp_default_98, 1);  exp_default_98 = None
        reciprocal_default_98 = torch.ops.aten.reciprocal.default(add_tensor_561);  add_tensor_561 = None
        mul_tensor_771 = torch.ops.aten.mul.Tensor(reciprocal_default_98, 1);  reciprocal_default_98 = None
        mul_tensor_772 = torch.ops.aten.mul.Tensor(to_dtype_429, mul_tensor_771);  to_dtype_429 = None
        rsub_scalar_111 = torch.ops.aten.rsub.Scalar(mul_tensor_771, 1);  mul_tensor_771 = None
        mul_tensor_773 = torch.ops.aten.mul.Tensor(to_dtype_430, rsub_scalar_111);  to_dtype_430 = rsub_scalar_111 = None
        add_tensor_562 = torch.ops.aten.add.Tensor(mul_tensor_773, 1);  mul_tensor_773 = None
        mul_tensor_774 = torch.ops.aten.mul.Tensor(mul_tensor_772, add_tensor_562);  mul_tensor_772 = add_tensor_562 = None
        to_dtype_431 = torch.ops.aten.to.dtype(mul_tensor_774, torch.float32);  mul_tensor_774 = None
        convolution_backward_default_212 = torch.ops.aten.convolution_backward.default(to_dtype_431, mean_dim_10, primals_230, [20], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_431 = mean_dim_10 = primals_230 = None
        getitem_1473 = convolution_backward_default_212[0]
        getitem_1474 = convolution_backward_default_212[1]
        getitem_1475 = convolution_backward_default_212[2];  convolution_backward_default_212 = None
        expand_default_76 = torch.ops.aten.expand.default(getitem_1473, [1, 480, 40, 40]);  getitem_1473 = None
        div_scalar_12 = torch.ops.aten.div.Scalar(expand_default_76, 1600);  expand_default_76 = None
        add_tensor_563 = torch.ops.aten.add.Tensor(mul_tensor_768, div_scalar_12);  mul_tensor_768 = div_scalar_12 = None
        to_dtype_432 = torch.ops.aten.to.dtype(add_tensor_563, torch.float32);  add_tensor_563 = None
        to_dtype_433 = torch.ops.aten.to.dtype(clone_default_30, torch.float32);  clone_default_30 = None
        neg_default_175 = torch.ops.aten.neg.default(to_dtype_433)
        exp_default_99 = torch.ops.aten.exp.default(neg_default_175);  neg_default_175 = None
        add_tensor_564 = torch.ops.aten.add.Tensor(exp_default_99, 1);  exp_default_99 = None
        reciprocal_default_99 = torch.ops.aten.reciprocal.default(add_tensor_564);  add_tensor_564 = None
        mul_tensor_775 = torch.ops.aten.mul.Tensor(reciprocal_default_99, 1);  reciprocal_default_99 = None
        mul_tensor_776 = torch.ops.aten.mul.Tensor(to_dtype_432, mul_tensor_775);  to_dtype_432 = None
        rsub_scalar_112 = torch.ops.aten.rsub.Scalar(mul_tensor_775, 1);  mul_tensor_775 = None
        mul_tensor_777 = torch.ops.aten.mul.Tensor(to_dtype_433, rsub_scalar_112);  to_dtype_433 = rsub_scalar_112 = None
        add_tensor_565 = torch.ops.aten.add.Tensor(mul_tensor_777, 1);  mul_tensor_777 = None
        mul_tensor_778 = torch.ops.aten.mul.Tensor(mul_tensor_776, add_tensor_565);  mul_tensor_776 = add_tensor_565 = None
        to_dtype_434 = torch.ops.aten.to.dtype(mul_tensor_778, torch.float32);  mul_tensor_778 = None
        native_batch_norm_backward_default_105 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_434, convolution_default_50, primals_218, primals_216, primals_217, new_zeros_default_90, new_zeros_default_91, False, 0.001, [True, True, True]);  to_dtype_434 = convolution_default_50 = primals_218 = primals_216 = primals_217 = new_zeros_default_90 = new_zeros_default_91 = None
        getitem_1476 = native_batch_norm_backward_default_105[0]
        getitem_1477 = native_batch_norm_backward_default_105[1]
        getitem_1478 = native_batch_norm_backward_default_105[2];  native_batch_norm_backward_default_105 = None
        convolution_backward_default_213 = torch.ops.aten.convolution_backward.default(getitem_1476, silu__default_29, primals_224, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 480, [True, True, False]);  getitem_1476 = silu__default_29 = primals_224 = None
        getitem_1479 = convolution_backward_default_213[0]
        getitem_1480 = convolution_backward_default_213[1]
        getitem_1481 = convolution_backward_default_213[2];  convolution_backward_default_213 = None
        to_dtype_435 = torch.ops.aten.to.dtype(getitem_1479, torch.float32);  getitem_1479 = None
        to_dtype_436 = torch.ops.aten.to.dtype(clone_default_29, torch.float32);  clone_default_29 = None
        neg_default_176 = torch.ops.aten.neg.default(to_dtype_436)
        exp_default_100 = torch.ops.aten.exp.default(neg_default_176);  neg_default_176 = None
        add_tensor_566 = torch.ops.aten.add.Tensor(exp_default_100, 1);  exp_default_100 = None
        reciprocal_default_100 = torch.ops.aten.reciprocal.default(add_tensor_566);  add_tensor_566 = None
        mul_tensor_779 = torch.ops.aten.mul.Tensor(reciprocal_default_100, 1);  reciprocal_default_100 = None
        mul_tensor_780 = torch.ops.aten.mul.Tensor(to_dtype_435, mul_tensor_779);  to_dtype_435 = None
        rsub_scalar_113 = torch.ops.aten.rsub.Scalar(mul_tensor_779, 1);  mul_tensor_779 = None
        mul_tensor_781 = torch.ops.aten.mul.Tensor(to_dtype_436, rsub_scalar_113);  to_dtype_436 = rsub_scalar_113 = None
        add_tensor_567 = torch.ops.aten.add.Tensor(mul_tensor_781, 1);  mul_tensor_781 = None
        mul_tensor_782 = torch.ops.aten.mul.Tensor(mul_tensor_780, add_tensor_567);  mul_tensor_780 = add_tensor_567 = None
        to_dtype_437 = torch.ops.aten.to.dtype(mul_tensor_782, torch.float32);  mul_tensor_782 = None
        native_batch_norm_backward_default_106 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_437, convolution_default_49, primals_213, primals_211, primals_212, new_zeros_default_87, new_zeros_default_88, False, 0.001, [True, True, True]);  to_dtype_437 = convolution_default_49 = primals_213 = primals_211 = primals_212 = new_zeros_default_87 = new_zeros_default_88 = None
        getitem_1482 = native_batch_norm_backward_default_106[0]
        getitem_1483 = native_batch_norm_backward_default_106[1]
        getitem_1484 = native_batch_norm_backward_default_106[2];  native_batch_norm_backward_default_106 = None
        convolution_backward_default_214 = torch.ops.aten.convolution_backward.default(getitem_1482, add__tensor_5, primals_225, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1482 = add__tensor_5 = primals_225 = None
        getitem_1485 = convolution_backward_default_214[0]
        getitem_1486 = convolution_backward_default_214[1]
        getitem_1487 = convolution_backward_default_214[2];  convolution_backward_default_214 = None
        add_tensor_568 = torch.ops.aten.add.Tensor(add_tensor_560, getitem_1485);  add_tensor_560 = getitem_1485 = None
        native_batch_norm_backward_default_107 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_568, convolution_default_48, primals_201, primals_199, primals_200, new_zeros_default_84, new_zeros_default_85, False, 0.001, [True, True, True]);  convolution_default_48 = primals_201 = primals_199 = primals_200 = new_zeros_default_84 = new_zeros_default_85 = None
        getitem_1488 = native_batch_norm_backward_default_107[0]
        getitem_1489 = native_batch_norm_backward_default_107[1]
        getitem_1490 = native_batch_norm_backward_default_107[2];  native_batch_norm_backward_default_107 = None
        convolution_backward_default_215 = torch.ops.aten.convolution_backward.default(getitem_1488, mul_tensor_9, primals_204, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1488 = mul_tensor_9 = primals_204 = None
        getitem_1491 = convolution_backward_default_215[0]
        getitem_1492 = convolution_backward_default_215[1]
        getitem_1493 = convolution_backward_default_215[2];  convolution_backward_default_215 = None
        mul_tensor_783 = torch.ops.aten.mul.Tensor(getitem_1491, silu__default_27);  silu__default_27 = None
        mul_tensor_784 = torch.ops.aten.mul.Tensor(getitem_1491, sigmoid_default_9);  getitem_1491 = None
        sum_dim_int_list_45 = torch.ops.aten.sum.dim_IntList(mul_tensor_783, [2, 3], True);  mul_tensor_783 = None
        to_dtype_438 = torch.ops.aten.to.dtype(sum_dim_int_list_45, torch.float32);  sum_dim_int_list_45 = None
        to_dtype_439 = torch.ops.aten.to.dtype(sigmoid_default_9, torch.float32);  sigmoid_default_9 = None
        rsub_scalar_114 = torch.ops.aten.rsub.Scalar(to_dtype_439, 1)
        mul_tensor_785 = torch.ops.aten.mul.Tensor(to_dtype_439, rsub_scalar_114);  to_dtype_439 = rsub_scalar_114 = None
        conj_physical_default_13 = torch.ops.aten.conj_physical.default(mul_tensor_785);  mul_tensor_785 = None
        mul_tensor_786 = torch.ops.aten.mul.Tensor(to_dtype_438, conj_physical_default_13);  to_dtype_438 = conj_physical_default_13 = None
        to_dtype_440 = torch.ops.aten.to.dtype(mul_tensor_786, torch.float32);  mul_tensor_786 = None
        convolution_backward_default_216 = torch.ops.aten.convolution_backward.default(to_dtype_440, silu__default_28, primals_206, [480], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_440 = silu__default_28 = primals_206 = None
        getitem_1494 = convolution_backward_default_216[0]
        getitem_1495 = convolution_backward_default_216[1]
        getitem_1496 = convolution_backward_default_216[2];  convolution_backward_default_216 = None
        to_dtype_441 = torch.ops.aten.to.dtype(getitem_1494, torch.float32);  getitem_1494 = None
        to_dtype_442 = torch.ops.aten.to.dtype(clone_default_28, torch.float32);  clone_default_28 = None
        neg_default_177 = torch.ops.aten.neg.default(to_dtype_442)
        exp_default_101 = torch.ops.aten.exp.default(neg_default_177);  neg_default_177 = None
        add_tensor_569 = torch.ops.aten.add.Tensor(exp_default_101, 1);  exp_default_101 = None
        reciprocal_default_101 = torch.ops.aten.reciprocal.default(add_tensor_569);  add_tensor_569 = None
        mul_tensor_787 = torch.ops.aten.mul.Tensor(reciprocal_default_101, 1);  reciprocal_default_101 = None
        mul_tensor_788 = torch.ops.aten.mul.Tensor(to_dtype_441, mul_tensor_787);  to_dtype_441 = None
        rsub_scalar_115 = torch.ops.aten.rsub.Scalar(mul_tensor_787, 1);  mul_tensor_787 = None
        mul_tensor_789 = torch.ops.aten.mul.Tensor(to_dtype_442, rsub_scalar_115);  to_dtype_442 = rsub_scalar_115 = None
        add_tensor_570 = torch.ops.aten.add.Tensor(mul_tensor_789, 1);  mul_tensor_789 = None
        mul_tensor_790 = torch.ops.aten.mul.Tensor(mul_tensor_788, add_tensor_570);  mul_tensor_788 = add_tensor_570 = None
        to_dtype_443 = torch.ops.aten.to.dtype(mul_tensor_790, torch.float32);  mul_tensor_790 = None
        convolution_backward_default_217 = torch.ops.aten.convolution_backward.default(to_dtype_443, mean_dim_9, primals_208, [20], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_443 = mean_dim_9 = primals_208 = None
        getitem_1497 = convolution_backward_default_217[0]
        getitem_1498 = convolution_backward_default_217[1]
        getitem_1499 = convolution_backward_default_217[2];  convolution_backward_default_217 = None
        expand_default_77 = torch.ops.aten.expand.default(getitem_1497, [1, 480, 40, 40]);  getitem_1497 = None
        div_scalar_13 = torch.ops.aten.div.Scalar(expand_default_77, 1600);  expand_default_77 = None
        add_tensor_571 = torch.ops.aten.add.Tensor(mul_tensor_784, div_scalar_13);  mul_tensor_784 = div_scalar_13 = None
        to_dtype_444 = torch.ops.aten.to.dtype(add_tensor_571, torch.float32);  add_tensor_571 = None
        to_dtype_445 = torch.ops.aten.to.dtype(clone_default_27, torch.float32);  clone_default_27 = None
        neg_default_178 = torch.ops.aten.neg.default(to_dtype_445)
        exp_default_102 = torch.ops.aten.exp.default(neg_default_178);  neg_default_178 = None
        add_tensor_572 = torch.ops.aten.add.Tensor(exp_default_102, 1);  exp_default_102 = None
        reciprocal_default_102 = torch.ops.aten.reciprocal.default(add_tensor_572);  add_tensor_572 = None
        mul_tensor_791 = torch.ops.aten.mul.Tensor(reciprocal_default_102, 1);  reciprocal_default_102 = None
        mul_tensor_792 = torch.ops.aten.mul.Tensor(to_dtype_444, mul_tensor_791);  to_dtype_444 = None
        rsub_scalar_116 = torch.ops.aten.rsub.Scalar(mul_tensor_791, 1);  mul_tensor_791 = None
        mul_tensor_793 = torch.ops.aten.mul.Tensor(to_dtype_445, rsub_scalar_116);  to_dtype_445 = rsub_scalar_116 = None
        add_tensor_573 = torch.ops.aten.add.Tensor(mul_tensor_793, 1);  mul_tensor_793 = None
        mul_tensor_794 = torch.ops.aten.mul.Tensor(mul_tensor_792, add_tensor_573);  mul_tensor_792 = add_tensor_573 = None
        to_dtype_446 = torch.ops.aten.to.dtype(mul_tensor_794, torch.float32);  mul_tensor_794 = None
        native_batch_norm_backward_default_108 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_446, convolution_default_45, primals_196, primals_194, primals_195, new_zeros_default_81, new_zeros_default_82, False, 0.001, [True, True, True]);  to_dtype_446 = convolution_default_45 = primals_196 = primals_194 = primals_195 = new_zeros_default_81 = new_zeros_default_82 = None
        getitem_1500 = native_batch_norm_backward_default_108[0]
        getitem_1501 = native_batch_norm_backward_default_108[1]
        getitem_1502 = native_batch_norm_backward_default_108[2];  native_batch_norm_backward_default_108 = None
        convolution_backward_default_218 = torch.ops.aten.convolution_backward.default(getitem_1500, silu__default_26, primals_202, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 480, [True, True, False]);  getitem_1500 = silu__default_26 = primals_202 = None
        getitem_1503 = convolution_backward_default_218[0]
        getitem_1504 = convolution_backward_default_218[1]
        getitem_1505 = convolution_backward_default_218[2];  convolution_backward_default_218 = None
        to_dtype_447 = torch.ops.aten.to.dtype(getitem_1503, torch.float32);  getitem_1503 = None
        to_dtype_448 = torch.ops.aten.to.dtype(clone_default_26, torch.float32);  clone_default_26 = None
        neg_default_179 = torch.ops.aten.neg.default(to_dtype_448)
        exp_default_103 = torch.ops.aten.exp.default(neg_default_179);  neg_default_179 = None
        add_tensor_574 = torch.ops.aten.add.Tensor(exp_default_103, 1);  exp_default_103 = None
        reciprocal_default_103 = torch.ops.aten.reciprocal.default(add_tensor_574);  add_tensor_574 = None
        mul_tensor_795 = torch.ops.aten.mul.Tensor(reciprocal_default_103, 1);  reciprocal_default_103 = None
        mul_tensor_796 = torch.ops.aten.mul.Tensor(to_dtype_447, mul_tensor_795);  to_dtype_447 = None
        rsub_scalar_117 = torch.ops.aten.rsub.Scalar(mul_tensor_795, 1);  mul_tensor_795 = None
        mul_tensor_797 = torch.ops.aten.mul.Tensor(to_dtype_448, rsub_scalar_117);  to_dtype_448 = rsub_scalar_117 = None
        add_tensor_575 = torch.ops.aten.add.Tensor(mul_tensor_797, 1);  mul_tensor_797 = None
        mul_tensor_798 = torch.ops.aten.mul.Tensor(mul_tensor_796, add_tensor_575);  mul_tensor_796 = add_tensor_575 = None
        to_dtype_449 = torch.ops.aten.to.dtype(mul_tensor_798, torch.float32);  mul_tensor_798 = None
        native_batch_norm_backward_default_109 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_449, convolution_default_44, primals_191, primals_189, primals_190, new_zeros_default_78, new_zeros_default_79, False, 0.001, [True, True, True]);  to_dtype_449 = convolution_default_44 = primals_191 = primals_189 = primals_190 = new_zeros_default_78 = new_zeros_default_79 = None
        getitem_1506 = native_batch_norm_backward_default_109[0]
        getitem_1507 = native_batch_norm_backward_default_109[1]
        getitem_1508 = native_batch_norm_backward_default_109[2];  native_batch_norm_backward_default_109 = None
        convolution_backward_default_219 = torch.ops.aten.convolution_backward.default(getitem_1506, getitem_75, primals_203, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1506 = getitem_75 = primals_203 = None
        getitem_1509 = convolution_backward_default_219[0]
        getitem_1510 = convolution_backward_default_219[1]
        getitem_1511 = convolution_backward_default_219[2];  convolution_backward_default_219 = None
        add_tensor_576 = torch.ops.aten.add.Tensor(add_tensor_568, getitem_1509);  add_tensor_568 = getitem_1509 = None
        native_batch_norm_backward_default_110 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_576, convolution_default_43, primals_179, primals_177, primals_178, new_zeros_default_75, new_zeros_default_76, False, 0.001, [True, True, True]);  add_tensor_576 = convolution_default_43 = primals_179 = primals_177 = primals_178 = new_zeros_default_75 = new_zeros_default_76 = None
        getitem_1512 = native_batch_norm_backward_default_110[0]
        getitem_1513 = native_batch_norm_backward_default_110[1]
        getitem_1514 = native_batch_norm_backward_default_110[2];  native_batch_norm_backward_default_110 = None
        convolution_backward_default_220 = torch.ops.aten.convolution_backward.default(getitem_1512, mul_tensor_8, primals_182, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1512 = mul_tensor_8 = primals_182 = None
        getitem_1515 = convolution_backward_default_220[0]
        getitem_1516 = convolution_backward_default_220[1]
        getitem_1517 = convolution_backward_default_220[2];  convolution_backward_default_220 = None
        mul_tensor_799 = torch.ops.aten.mul.Tensor(getitem_1515, silu__default_24);  silu__default_24 = None
        mul_tensor_800 = torch.ops.aten.mul.Tensor(getitem_1515, sigmoid_default_8);  getitem_1515 = None
        sum_dim_int_list_46 = torch.ops.aten.sum.dim_IntList(mul_tensor_799, [2, 3], True);  mul_tensor_799 = None
        to_dtype_450 = torch.ops.aten.to.dtype(sum_dim_int_list_46, torch.float32);  sum_dim_int_list_46 = None
        to_dtype_451 = torch.ops.aten.to.dtype(sigmoid_default_8, torch.float32);  sigmoid_default_8 = None
        rsub_scalar_118 = torch.ops.aten.rsub.Scalar(to_dtype_451, 1)
        mul_tensor_801 = torch.ops.aten.mul.Tensor(to_dtype_451, rsub_scalar_118);  to_dtype_451 = rsub_scalar_118 = None
        conj_physical_default_14 = torch.ops.aten.conj_physical.default(mul_tensor_801);  mul_tensor_801 = None
        mul_tensor_802 = torch.ops.aten.mul.Tensor(to_dtype_450, conj_physical_default_14);  to_dtype_450 = conj_physical_default_14 = None
        to_dtype_452 = torch.ops.aten.to.dtype(mul_tensor_802, torch.float32);  mul_tensor_802 = None
        convolution_backward_default_221 = torch.ops.aten.convolution_backward.default(to_dtype_452, silu__default_25, primals_184, [240], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_452 = silu__default_25 = primals_184 = None
        getitem_1518 = convolution_backward_default_221[0]
        getitem_1519 = convolution_backward_default_221[1]
        getitem_1520 = convolution_backward_default_221[2];  convolution_backward_default_221 = None
        to_dtype_453 = torch.ops.aten.to.dtype(getitem_1518, torch.float32);  getitem_1518 = None
        to_dtype_454 = torch.ops.aten.to.dtype(clone_default_25, torch.float32);  clone_default_25 = None
        neg_default_180 = torch.ops.aten.neg.default(to_dtype_454)
        exp_default_104 = torch.ops.aten.exp.default(neg_default_180);  neg_default_180 = None
        add_tensor_577 = torch.ops.aten.add.Tensor(exp_default_104, 1);  exp_default_104 = None
        reciprocal_default_104 = torch.ops.aten.reciprocal.default(add_tensor_577);  add_tensor_577 = None
        mul_tensor_803 = torch.ops.aten.mul.Tensor(reciprocal_default_104, 1);  reciprocal_default_104 = None
        mul_tensor_804 = torch.ops.aten.mul.Tensor(to_dtype_453, mul_tensor_803);  to_dtype_453 = None
        rsub_scalar_119 = torch.ops.aten.rsub.Scalar(mul_tensor_803, 1);  mul_tensor_803 = None
        mul_tensor_805 = torch.ops.aten.mul.Tensor(to_dtype_454, rsub_scalar_119);  to_dtype_454 = rsub_scalar_119 = None
        add_tensor_578 = torch.ops.aten.add.Tensor(mul_tensor_805, 1);  mul_tensor_805 = None
        mul_tensor_806 = torch.ops.aten.mul.Tensor(mul_tensor_804, add_tensor_578);  mul_tensor_804 = add_tensor_578 = None
        to_dtype_455 = torch.ops.aten.to.dtype(mul_tensor_806, torch.float32);  mul_tensor_806 = None
        convolution_backward_default_222 = torch.ops.aten.convolution_backward.default(to_dtype_455, mean_dim_8, primals_186, [10], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_455 = mean_dim_8 = primals_186 = None
        getitem_1521 = convolution_backward_default_222[0]
        getitem_1522 = convolution_backward_default_222[1]
        getitem_1523 = convolution_backward_default_222[2];  convolution_backward_default_222 = None
        expand_default_78 = torch.ops.aten.expand.default(getitem_1521, [1, 240, 40, 40]);  getitem_1521 = None
        div_scalar_14 = torch.ops.aten.div.Scalar(expand_default_78, 1600);  expand_default_78 = None
        add_tensor_579 = torch.ops.aten.add.Tensor(mul_tensor_800, div_scalar_14);  mul_tensor_800 = div_scalar_14 = None
        to_dtype_456 = torch.ops.aten.to.dtype(add_tensor_579, torch.float32);  add_tensor_579 = None
        to_dtype_457 = torch.ops.aten.to.dtype(clone_default_24, torch.float32);  clone_default_24 = None
        neg_default_181 = torch.ops.aten.neg.default(to_dtype_457)
        exp_default_105 = torch.ops.aten.exp.default(neg_default_181);  neg_default_181 = None
        add_tensor_580 = torch.ops.aten.add.Tensor(exp_default_105, 1);  exp_default_105 = None
        reciprocal_default_105 = torch.ops.aten.reciprocal.default(add_tensor_580);  add_tensor_580 = None
        mul_tensor_807 = torch.ops.aten.mul.Tensor(reciprocal_default_105, 1);  reciprocal_default_105 = None
        mul_tensor_808 = torch.ops.aten.mul.Tensor(to_dtype_456, mul_tensor_807);  to_dtype_456 = None
        rsub_scalar_120 = torch.ops.aten.rsub.Scalar(mul_tensor_807, 1);  mul_tensor_807 = None
        mul_tensor_809 = torch.ops.aten.mul.Tensor(to_dtype_457, rsub_scalar_120);  to_dtype_457 = rsub_scalar_120 = None
        add_tensor_581 = torch.ops.aten.add.Tensor(mul_tensor_809, 1);  mul_tensor_809 = None
        mul_tensor_810 = torch.ops.aten.mul.Tensor(mul_tensor_808, add_tensor_581);  mul_tensor_808 = add_tensor_581 = None
        to_dtype_458 = torch.ops.aten.to.dtype(mul_tensor_810, torch.float32);  mul_tensor_810 = None
        native_batch_norm_backward_default_111 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_458, convolution_default_40, primals_174, primals_172, primals_173, new_zeros_default_72, new_zeros_default_73, False, 0.001, [True, True, True]);  to_dtype_458 = convolution_default_40 = primals_174 = primals_172 = primals_173 = new_zeros_default_72 = new_zeros_default_73 = None
        getitem_1524 = native_batch_norm_backward_default_111[0]
        getitem_1525 = native_batch_norm_backward_default_111[1]
        getitem_1526 = native_batch_norm_backward_default_111[2];  native_batch_norm_backward_default_111 = None
        convolution_backward_default_223 = torch.ops.aten.convolution_backward.default(getitem_1524, constant_pad_nd_default_3, primals_180, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 240, [True, True, False]);  getitem_1524 = constant_pad_nd_default_3 = primals_180 = None
        getitem_1527 = convolution_backward_default_223[0]
        getitem_1528 = convolution_backward_default_223[1]
        getitem_1529 = convolution_backward_default_223[2];  convolution_backward_default_223 = None
        constant_pad_nd_default_42 = torch.ops.aten.constant_pad_nd.default(getitem_1527, [0, -1, 0, -1]);  getitem_1527 = None
        to_dtype_459 = torch.ops.aten.to.dtype(constant_pad_nd_default_42, torch.float32);  constant_pad_nd_default_42 = None
        to_dtype_460 = torch.ops.aten.to.dtype(clone_default_23, torch.float32);  clone_default_23 = None
        neg_default_182 = torch.ops.aten.neg.default(to_dtype_460)
        exp_default_106 = torch.ops.aten.exp.default(neg_default_182);  neg_default_182 = None
        add_tensor_582 = torch.ops.aten.add.Tensor(exp_default_106, 1);  exp_default_106 = None
        reciprocal_default_106 = torch.ops.aten.reciprocal.default(add_tensor_582);  add_tensor_582 = None
        mul_tensor_811 = torch.ops.aten.mul.Tensor(reciprocal_default_106, 1);  reciprocal_default_106 = None
        mul_tensor_812 = torch.ops.aten.mul.Tensor(to_dtype_459, mul_tensor_811);  to_dtype_459 = None
        rsub_scalar_121 = torch.ops.aten.rsub.Scalar(mul_tensor_811, 1);  mul_tensor_811 = None
        mul_tensor_813 = torch.ops.aten.mul.Tensor(to_dtype_460, rsub_scalar_121);  to_dtype_460 = rsub_scalar_121 = None
        add_tensor_583 = torch.ops.aten.add.Tensor(mul_tensor_813, 1);  mul_tensor_813 = None
        mul_tensor_814 = torch.ops.aten.mul.Tensor(mul_tensor_812, add_tensor_583);  mul_tensor_812 = add_tensor_583 = None
        to_dtype_461 = torch.ops.aten.to.dtype(mul_tensor_814, torch.float32);  mul_tensor_814 = None
        native_batch_norm_backward_default_112 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_461, convolution_default_39, primals_169, primals_167, primals_168, new_zeros_default_69, new_zeros_default_70, False, 0.001, [True, True, True]);  to_dtype_461 = convolution_default_39 = primals_169 = primals_167 = primals_168 = new_zeros_default_69 = new_zeros_default_70 = None
        getitem_1530 = native_batch_norm_backward_default_112[0]
        getitem_1531 = native_batch_norm_backward_default_112[1]
        getitem_1532 = native_batch_norm_backward_default_112[2];  native_batch_norm_backward_default_112 = None
        convolution_backward_default_224 = torch.ops.aten.convolution_backward.default(getitem_1530, add__tensor_4, primals_181, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1530 = add__tensor_4 = primals_181 = None
        getitem_1533 = convolution_backward_default_224[0]
        getitem_1534 = convolution_backward_default_224[1]
        getitem_1535 = convolution_backward_default_224[2];  convolution_backward_default_224 = None
        add_tensor_584 = torch.ops.aten.add.Tensor(getitem_1122, getitem_1533);  getitem_1122 = getitem_1533 = None
        native_batch_norm_backward_default_113 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_584, convolution_default_38, primals_157, primals_155, primals_156, new_zeros_default_66, new_zeros_default_67, False, 0.001, [True, True, True]);  convolution_default_38 = primals_157 = primals_155 = primals_156 = new_zeros_default_66 = new_zeros_default_67 = None
        getitem_1536 = native_batch_norm_backward_default_113[0]
        getitem_1537 = native_batch_norm_backward_default_113[1]
        getitem_1538 = native_batch_norm_backward_default_113[2];  native_batch_norm_backward_default_113 = None
        convolution_backward_default_225 = torch.ops.aten.convolution_backward.default(getitem_1536, mul_tensor_7, primals_160, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1536 = mul_tensor_7 = primals_160 = None
        getitem_1539 = convolution_backward_default_225[0]
        getitem_1540 = convolution_backward_default_225[1]
        getitem_1541 = convolution_backward_default_225[2];  convolution_backward_default_225 = None
        mul_tensor_815 = torch.ops.aten.mul.Tensor(getitem_1539, silu__default_21);  silu__default_21 = None
        mul_tensor_816 = torch.ops.aten.mul.Tensor(getitem_1539, sigmoid_default_7);  getitem_1539 = None
        sum_dim_int_list_47 = torch.ops.aten.sum.dim_IntList(mul_tensor_815, [2, 3], True);  mul_tensor_815 = None
        to_dtype_462 = torch.ops.aten.to.dtype(sum_dim_int_list_47, torch.float32);  sum_dim_int_list_47 = None
        to_dtype_463 = torch.ops.aten.to.dtype(sigmoid_default_7, torch.float32);  sigmoid_default_7 = None
        rsub_scalar_122 = torch.ops.aten.rsub.Scalar(to_dtype_463, 1)
        mul_tensor_817 = torch.ops.aten.mul.Tensor(to_dtype_463, rsub_scalar_122);  to_dtype_463 = rsub_scalar_122 = None
        conj_physical_default_15 = torch.ops.aten.conj_physical.default(mul_tensor_817);  mul_tensor_817 = None
        mul_tensor_818 = torch.ops.aten.mul.Tensor(to_dtype_462, conj_physical_default_15);  to_dtype_462 = conj_physical_default_15 = None
        to_dtype_464 = torch.ops.aten.to.dtype(mul_tensor_818, torch.float32);  mul_tensor_818 = None
        convolution_backward_default_226 = torch.ops.aten.convolution_backward.default(to_dtype_464, silu__default_22, primals_162, [240], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_464 = silu__default_22 = primals_162 = None
        getitem_1542 = convolution_backward_default_226[0]
        getitem_1543 = convolution_backward_default_226[1]
        getitem_1544 = convolution_backward_default_226[2];  convolution_backward_default_226 = None
        to_dtype_465 = torch.ops.aten.to.dtype(getitem_1542, torch.float32);  getitem_1542 = None
        to_dtype_466 = torch.ops.aten.to.dtype(clone_default_22, torch.float32);  clone_default_22 = None
        neg_default_183 = torch.ops.aten.neg.default(to_dtype_466)
        exp_default_107 = torch.ops.aten.exp.default(neg_default_183);  neg_default_183 = None
        add_tensor_585 = torch.ops.aten.add.Tensor(exp_default_107, 1);  exp_default_107 = None
        reciprocal_default_107 = torch.ops.aten.reciprocal.default(add_tensor_585);  add_tensor_585 = None
        mul_tensor_819 = torch.ops.aten.mul.Tensor(reciprocal_default_107, 1);  reciprocal_default_107 = None
        mul_tensor_820 = torch.ops.aten.mul.Tensor(to_dtype_465, mul_tensor_819);  to_dtype_465 = None
        rsub_scalar_123 = torch.ops.aten.rsub.Scalar(mul_tensor_819, 1);  mul_tensor_819 = None
        mul_tensor_821 = torch.ops.aten.mul.Tensor(to_dtype_466, rsub_scalar_123);  to_dtype_466 = rsub_scalar_123 = None
        add_tensor_586 = torch.ops.aten.add.Tensor(mul_tensor_821, 1);  mul_tensor_821 = None
        mul_tensor_822 = torch.ops.aten.mul.Tensor(mul_tensor_820, add_tensor_586);  mul_tensor_820 = add_tensor_586 = None
        to_dtype_467 = torch.ops.aten.to.dtype(mul_tensor_822, torch.float32);  mul_tensor_822 = None
        convolution_backward_default_227 = torch.ops.aten.convolution_backward.default(to_dtype_467, mean_dim_7, primals_164, [10], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_467 = mean_dim_7 = primals_164 = None
        getitem_1545 = convolution_backward_default_227[0]
        getitem_1546 = convolution_backward_default_227[1]
        getitem_1547 = convolution_backward_default_227[2];  convolution_backward_default_227 = None
        expand_default_79 = torch.ops.aten.expand.default(getitem_1545, [1, 240, 80, 80]);  getitem_1545 = None
        div_scalar_15 = torch.ops.aten.div.Scalar(expand_default_79, 6400);  expand_default_79 = None
        add_tensor_587 = torch.ops.aten.add.Tensor(mul_tensor_816, div_scalar_15);  mul_tensor_816 = div_scalar_15 = None
        to_dtype_468 = torch.ops.aten.to.dtype(add_tensor_587, torch.float32);  add_tensor_587 = None
        to_dtype_469 = torch.ops.aten.to.dtype(clone_default_21, torch.float32);  clone_default_21 = None
        neg_default_184 = torch.ops.aten.neg.default(to_dtype_469)
        exp_default_108 = torch.ops.aten.exp.default(neg_default_184);  neg_default_184 = None
        add_tensor_588 = torch.ops.aten.add.Tensor(exp_default_108, 1);  exp_default_108 = None
        reciprocal_default_108 = torch.ops.aten.reciprocal.default(add_tensor_588);  add_tensor_588 = None
        mul_tensor_823 = torch.ops.aten.mul.Tensor(reciprocal_default_108, 1);  reciprocal_default_108 = None
        mul_tensor_824 = torch.ops.aten.mul.Tensor(to_dtype_468, mul_tensor_823);  to_dtype_468 = None
        rsub_scalar_124 = torch.ops.aten.rsub.Scalar(mul_tensor_823, 1);  mul_tensor_823 = None
        mul_tensor_825 = torch.ops.aten.mul.Tensor(to_dtype_469, rsub_scalar_124);  to_dtype_469 = rsub_scalar_124 = None
        add_tensor_589 = torch.ops.aten.add.Tensor(mul_tensor_825, 1);  mul_tensor_825 = None
        mul_tensor_826 = torch.ops.aten.mul.Tensor(mul_tensor_824, add_tensor_589);  mul_tensor_824 = add_tensor_589 = None
        to_dtype_470 = torch.ops.aten.to.dtype(mul_tensor_826, torch.float32);  mul_tensor_826 = None
        native_batch_norm_backward_default_114 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_470, convolution_default_35, primals_152, primals_150, primals_151, new_zeros_default_63, new_zeros_default_64, False, 0.001, [True, True, True]);  to_dtype_470 = convolution_default_35 = primals_152 = primals_150 = primals_151 = new_zeros_default_63 = new_zeros_default_64 = None
        getitem_1548 = native_batch_norm_backward_default_114[0]
        getitem_1549 = native_batch_norm_backward_default_114[1]
        getitem_1550 = native_batch_norm_backward_default_114[2];  native_batch_norm_backward_default_114 = None
        convolution_backward_default_228 = torch.ops.aten.convolution_backward.default(getitem_1548, silu__default_20, primals_158, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 240, [True, True, False]);  getitem_1548 = silu__default_20 = primals_158 = None
        getitem_1551 = convolution_backward_default_228[0]
        getitem_1552 = convolution_backward_default_228[1]
        getitem_1553 = convolution_backward_default_228[2];  convolution_backward_default_228 = None
        to_dtype_471 = torch.ops.aten.to.dtype(getitem_1551, torch.float32);  getitem_1551 = None
        to_dtype_472 = torch.ops.aten.to.dtype(clone_default_20, torch.float32);  clone_default_20 = None
        neg_default_185 = torch.ops.aten.neg.default(to_dtype_472)
        exp_default_109 = torch.ops.aten.exp.default(neg_default_185);  neg_default_185 = None
        add_tensor_590 = torch.ops.aten.add.Tensor(exp_default_109, 1);  exp_default_109 = None
        reciprocal_default_109 = torch.ops.aten.reciprocal.default(add_tensor_590);  add_tensor_590 = None
        mul_tensor_827 = torch.ops.aten.mul.Tensor(reciprocal_default_109, 1);  reciprocal_default_109 = None
        mul_tensor_828 = torch.ops.aten.mul.Tensor(to_dtype_471, mul_tensor_827);  to_dtype_471 = None
        rsub_scalar_125 = torch.ops.aten.rsub.Scalar(mul_tensor_827, 1);  mul_tensor_827 = None
        mul_tensor_829 = torch.ops.aten.mul.Tensor(to_dtype_472, rsub_scalar_125);  to_dtype_472 = rsub_scalar_125 = None
        add_tensor_591 = torch.ops.aten.add.Tensor(mul_tensor_829, 1);  mul_tensor_829 = None
        mul_tensor_830 = torch.ops.aten.mul.Tensor(mul_tensor_828, add_tensor_591);  mul_tensor_828 = add_tensor_591 = None
        to_dtype_473 = torch.ops.aten.to.dtype(mul_tensor_830, torch.float32);  mul_tensor_830 = None
        native_batch_norm_backward_default_115 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_473, convolution_default_34, primals_147, primals_145, primals_146, new_zeros_default_60, new_zeros_default_61, False, 0.001, [True, True, True]);  to_dtype_473 = convolution_default_34 = primals_147 = primals_145 = primals_146 = new_zeros_default_60 = new_zeros_default_61 = None
        getitem_1554 = native_batch_norm_backward_default_115[0]
        getitem_1555 = native_batch_norm_backward_default_115[1]
        getitem_1556 = native_batch_norm_backward_default_115[2];  native_batch_norm_backward_default_115 = None
        convolution_backward_default_229 = torch.ops.aten.convolution_backward.default(getitem_1554, add__tensor_3, primals_159, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1554 = add__tensor_3 = primals_159 = None
        getitem_1557 = convolution_backward_default_229[0]
        getitem_1558 = convolution_backward_default_229[1]
        getitem_1559 = convolution_backward_default_229[2];  convolution_backward_default_229 = None
        add_tensor_592 = torch.ops.aten.add.Tensor(add_tensor_584, getitem_1557);  add_tensor_584 = getitem_1557 = None
        native_batch_norm_backward_default_116 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_592, convolution_default_33, primals_135, primals_133, primals_134, new_zeros_default_57, new_zeros_default_58, False, 0.001, [True, True, True]);  convolution_default_33 = primals_135 = primals_133 = primals_134 = new_zeros_default_57 = new_zeros_default_58 = None
        getitem_1560 = native_batch_norm_backward_default_116[0]
        getitem_1561 = native_batch_norm_backward_default_116[1]
        getitem_1562 = native_batch_norm_backward_default_116[2];  native_batch_norm_backward_default_116 = None
        convolution_backward_default_230 = torch.ops.aten.convolution_backward.default(getitem_1560, mul_tensor_6, primals_138, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1560 = mul_tensor_6 = primals_138 = None
        getitem_1563 = convolution_backward_default_230[0]
        getitem_1564 = convolution_backward_default_230[1]
        getitem_1565 = convolution_backward_default_230[2];  convolution_backward_default_230 = None
        mul_tensor_831 = torch.ops.aten.mul.Tensor(getitem_1563, silu__default_18);  silu__default_18 = None
        mul_tensor_832 = torch.ops.aten.mul.Tensor(getitem_1563, sigmoid_default_6);  getitem_1563 = None
        sum_dim_int_list_48 = torch.ops.aten.sum.dim_IntList(mul_tensor_831, [2, 3], True);  mul_tensor_831 = None
        to_dtype_474 = torch.ops.aten.to.dtype(sum_dim_int_list_48, torch.float32);  sum_dim_int_list_48 = None
        to_dtype_475 = torch.ops.aten.to.dtype(sigmoid_default_6, torch.float32);  sigmoid_default_6 = None
        rsub_scalar_126 = torch.ops.aten.rsub.Scalar(to_dtype_475, 1)
        mul_tensor_833 = torch.ops.aten.mul.Tensor(to_dtype_475, rsub_scalar_126);  to_dtype_475 = rsub_scalar_126 = None
        conj_physical_default_16 = torch.ops.aten.conj_physical.default(mul_tensor_833);  mul_tensor_833 = None
        mul_tensor_834 = torch.ops.aten.mul.Tensor(to_dtype_474, conj_physical_default_16);  to_dtype_474 = conj_physical_default_16 = None
        to_dtype_476 = torch.ops.aten.to.dtype(mul_tensor_834, torch.float32);  mul_tensor_834 = None
        convolution_backward_default_231 = torch.ops.aten.convolution_backward.default(to_dtype_476, silu__default_19, primals_140, [240], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_476 = silu__default_19 = primals_140 = None
        getitem_1566 = convolution_backward_default_231[0]
        getitem_1567 = convolution_backward_default_231[1]
        getitem_1568 = convolution_backward_default_231[2];  convolution_backward_default_231 = None
        to_dtype_477 = torch.ops.aten.to.dtype(getitem_1566, torch.float32);  getitem_1566 = None
        to_dtype_478 = torch.ops.aten.to.dtype(clone_default_19, torch.float32);  clone_default_19 = None
        neg_default_186 = torch.ops.aten.neg.default(to_dtype_478)
        exp_default_110 = torch.ops.aten.exp.default(neg_default_186);  neg_default_186 = None
        add_tensor_593 = torch.ops.aten.add.Tensor(exp_default_110, 1);  exp_default_110 = None
        reciprocal_default_110 = torch.ops.aten.reciprocal.default(add_tensor_593);  add_tensor_593 = None
        mul_tensor_835 = torch.ops.aten.mul.Tensor(reciprocal_default_110, 1);  reciprocal_default_110 = None
        mul_tensor_836 = torch.ops.aten.mul.Tensor(to_dtype_477, mul_tensor_835);  to_dtype_477 = None
        rsub_scalar_127 = torch.ops.aten.rsub.Scalar(mul_tensor_835, 1);  mul_tensor_835 = None
        mul_tensor_837 = torch.ops.aten.mul.Tensor(to_dtype_478, rsub_scalar_127);  to_dtype_478 = rsub_scalar_127 = None
        add_tensor_594 = torch.ops.aten.add.Tensor(mul_tensor_837, 1);  mul_tensor_837 = None
        mul_tensor_838 = torch.ops.aten.mul.Tensor(mul_tensor_836, add_tensor_594);  mul_tensor_836 = add_tensor_594 = None
        to_dtype_479 = torch.ops.aten.to.dtype(mul_tensor_838, torch.float32);  mul_tensor_838 = None
        convolution_backward_default_232 = torch.ops.aten.convolution_backward.default(to_dtype_479, mean_dim_6, primals_142, [10], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_479 = mean_dim_6 = primals_142 = None
        getitem_1569 = convolution_backward_default_232[0]
        getitem_1570 = convolution_backward_default_232[1]
        getitem_1571 = convolution_backward_default_232[2];  convolution_backward_default_232 = None
        expand_default_80 = torch.ops.aten.expand.default(getitem_1569, [1, 240, 80, 80]);  getitem_1569 = None
        div_scalar_16 = torch.ops.aten.div.Scalar(expand_default_80, 6400);  expand_default_80 = None
        add_tensor_595 = torch.ops.aten.add.Tensor(mul_tensor_832, div_scalar_16);  mul_tensor_832 = div_scalar_16 = None
        to_dtype_480 = torch.ops.aten.to.dtype(add_tensor_595, torch.float32);  add_tensor_595 = None
        to_dtype_481 = torch.ops.aten.to.dtype(clone_default_18, torch.float32);  clone_default_18 = None
        neg_default_187 = torch.ops.aten.neg.default(to_dtype_481)
        exp_default_111 = torch.ops.aten.exp.default(neg_default_187);  neg_default_187 = None
        add_tensor_596 = torch.ops.aten.add.Tensor(exp_default_111, 1);  exp_default_111 = None
        reciprocal_default_111 = torch.ops.aten.reciprocal.default(add_tensor_596);  add_tensor_596 = None
        mul_tensor_839 = torch.ops.aten.mul.Tensor(reciprocal_default_111, 1);  reciprocal_default_111 = None
        mul_tensor_840 = torch.ops.aten.mul.Tensor(to_dtype_480, mul_tensor_839);  to_dtype_480 = None
        rsub_scalar_128 = torch.ops.aten.rsub.Scalar(mul_tensor_839, 1);  mul_tensor_839 = None
        mul_tensor_841 = torch.ops.aten.mul.Tensor(to_dtype_481, rsub_scalar_128);  to_dtype_481 = rsub_scalar_128 = None
        add_tensor_597 = torch.ops.aten.add.Tensor(mul_tensor_841, 1);  mul_tensor_841 = None
        mul_tensor_842 = torch.ops.aten.mul.Tensor(mul_tensor_840, add_tensor_597);  mul_tensor_840 = add_tensor_597 = None
        to_dtype_482 = torch.ops.aten.to.dtype(mul_tensor_842, torch.float32);  mul_tensor_842 = None
        native_batch_norm_backward_default_117 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_482, convolution_default_30, primals_130, primals_128, primals_129, new_zeros_default_54, new_zeros_default_55, False, 0.001, [True, True, True]);  to_dtype_482 = convolution_default_30 = primals_130 = primals_128 = primals_129 = new_zeros_default_54 = new_zeros_default_55 = None
        getitem_1572 = native_batch_norm_backward_default_117[0]
        getitem_1573 = native_batch_norm_backward_default_117[1]
        getitem_1574 = native_batch_norm_backward_default_117[2];  native_batch_norm_backward_default_117 = None
        convolution_backward_default_233 = torch.ops.aten.convolution_backward.default(getitem_1572, silu__default_17, primals_136, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 240, [True, True, False]);  getitem_1572 = silu__default_17 = primals_136 = None
        getitem_1575 = convolution_backward_default_233[0]
        getitem_1576 = convolution_backward_default_233[1]
        getitem_1577 = convolution_backward_default_233[2];  convolution_backward_default_233 = None
        to_dtype_483 = torch.ops.aten.to.dtype(getitem_1575, torch.float32);  getitem_1575 = None
        to_dtype_484 = torch.ops.aten.to.dtype(clone_default_17, torch.float32);  clone_default_17 = None
        neg_default_188 = torch.ops.aten.neg.default(to_dtype_484)
        exp_default_112 = torch.ops.aten.exp.default(neg_default_188);  neg_default_188 = None
        add_tensor_598 = torch.ops.aten.add.Tensor(exp_default_112, 1);  exp_default_112 = None
        reciprocal_default_112 = torch.ops.aten.reciprocal.default(add_tensor_598);  add_tensor_598 = None
        mul_tensor_843 = torch.ops.aten.mul.Tensor(reciprocal_default_112, 1);  reciprocal_default_112 = None
        mul_tensor_844 = torch.ops.aten.mul.Tensor(to_dtype_483, mul_tensor_843);  to_dtype_483 = None
        rsub_scalar_129 = torch.ops.aten.rsub.Scalar(mul_tensor_843, 1);  mul_tensor_843 = None
        mul_tensor_845 = torch.ops.aten.mul.Tensor(to_dtype_484, rsub_scalar_129);  to_dtype_484 = rsub_scalar_129 = None
        add_tensor_599 = torch.ops.aten.add.Tensor(mul_tensor_845, 1);  mul_tensor_845 = None
        mul_tensor_846 = torch.ops.aten.mul.Tensor(mul_tensor_844, add_tensor_599);  mul_tensor_844 = add_tensor_599 = None
        to_dtype_485 = torch.ops.aten.to.dtype(mul_tensor_846, torch.float32);  mul_tensor_846 = None
        native_batch_norm_backward_default_118 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_485, convolution_default_29, primals_125, primals_123, primals_124, new_zeros_default_51, new_zeros_default_52, False, 0.001, [True, True, True]);  to_dtype_485 = convolution_default_29 = primals_125 = primals_123 = primals_124 = new_zeros_default_51 = new_zeros_default_52 = None
        getitem_1578 = native_batch_norm_backward_default_118[0]
        getitem_1579 = native_batch_norm_backward_default_118[1]
        getitem_1580 = native_batch_norm_backward_default_118[2];  native_batch_norm_backward_default_118 = None
        convolution_backward_default_234 = torch.ops.aten.convolution_backward.default(getitem_1578, getitem_48, primals_137, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1578 = getitem_48 = primals_137 = None
        getitem_1581 = convolution_backward_default_234[0]
        getitem_1582 = convolution_backward_default_234[1]
        getitem_1583 = convolution_backward_default_234[2];  convolution_backward_default_234 = None
        add_tensor_600 = torch.ops.aten.add.Tensor(add_tensor_592, getitem_1581);  add_tensor_592 = getitem_1581 = None
        native_batch_norm_backward_default_119 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_600, convolution_default_28, primals_113, primals_111, primals_112, new_zeros_default_48, new_zeros_default_49, False, 0.001, [True, True, True]);  add_tensor_600 = convolution_default_28 = primals_113 = primals_111 = primals_112 = new_zeros_default_48 = new_zeros_default_49 = None
        getitem_1584 = native_batch_norm_backward_default_119[0]
        getitem_1585 = native_batch_norm_backward_default_119[1]
        getitem_1586 = native_batch_norm_backward_default_119[2];  native_batch_norm_backward_default_119 = None
        convolution_backward_default_235 = torch.ops.aten.convolution_backward.default(getitem_1584, mul_tensor_5, primals_116, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1584 = mul_tensor_5 = primals_116 = None
        getitem_1587 = convolution_backward_default_235[0]
        getitem_1588 = convolution_backward_default_235[1]
        getitem_1589 = convolution_backward_default_235[2];  convolution_backward_default_235 = None
        mul_tensor_847 = torch.ops.aten.mul.Tensor(getitem_1587, silu__default_15);  silu__default_15 = None
        mul_tensor_848 = torch.ops.aten.mul.Tensor(getitem_1587, sigmoid_default_5);  getitem_1587 = None
        sum_dim_int_list_49 = torch.ops.aten.sum.dim_IntList(mul_tensor_847, [2, 3], True);  mul_tensor_847 = None
        to_dtype_486 = torch.ops.aten.to.dtype(sum_dim_int_list_49, torch.float32);  sum_dim_int_list_49 = None
        to_dtype_487 = torch.ops.aten.to.dtype(sigmoid_default_5, torch.float32);  sigmoid_default_5 = None
        rsub_scalar_130 = torch.ops.aten.rsub.Scalar(to_dtype_487, 1)
        mul_tensor_849 = torch.ops.aten.mul.Tensor(to_dtype_487, rsub_scalar_130);  to_dtype_487 = rsub_scalar_130 = None
        conj_physical_default_17 = torch.ops.aten.conj_physical.default(mul_tensor_849);  mul_tensor_849 = None
        mul_tensor_850 = torch.ops.aten.mul.Tensor(to_dtype_486, conj_physical_default_17);  to_dtype_486 = conj_physical_default_17 = None
        to_dtype_488 = torch.ops.aten.to.dtype(mul_tensor_850, torch.float32);  mul_tensor_850 = None
        convolution_backward_default_236 = torch.ops.aten.convolution_backward.default(to_dtype_488, silu__default_16, primals_118, [144], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_488 = silu__default_16 = primals_118 = None
        getitem_1590 = convolution_backward_default_236[0]
        getitem_1591 = convolution_backward_default_236[1]
        getitem_1592 = convolution_backward_default_236[2];  convolution_backward_default_236 = None
        to_dtype_489 = torch.ops.aten.to.dtype(getitem_1590, torch.float32);  getitem_1590 = None
        to_dtype_490 = torch.ops.aten.to.dtype(clone_default_16, torch.float32);  clone_default_16 = None
        neg_default_189 = torch.ops.aten.neg.default(to_dtype_490)
        exp_default_113 = torch.ops.aten.exp.default(neg_default_189);  neg_default_189 = None
        add_tensor_601 = torch.ops.aten.add.Tensor(exp_default_113, 1);  exp_default_113 = None
        reciprocal_default_113 = torch.ops.aten.reciprocal.default(add_tensor_601);  add_tensor_601 = None
        mul_tensor_851 = torch.ops.aten.mul.Tensor(reciprocal_default_113, 1);  reciprocal_default_113 = None
        mul_tensor_852 = torch.ops.aten.mul.Tensor(to_dtype_489, mul_tensor_851);  to_dtype_489 = None
        rsub_scalar_131 = torch.ops.aten.rsub.Scalar(mul_tensor_851, 1);  mul_tensor_851 = None
        mul_tensor_853 = torch.ops.aten.mul.Tensor(to_dtype_490, rsub_scalar_131);  to_dtype_490 = rsub_scalar_131 = None
        add_tensor_602 = torch.ops.aten.add.Tensor(mul_tensor_853, 1);  mul_tensor_853 = None
        mul_tensor_854 = torch.ops.aten.mul.Tensor(mul_tensor_852, add_tensor_602);  mul_tensor_852 = add_tensor_602 = None
        to_dtype_491 = torch.ops.aten.to.dtype(mul_tensor_854, torch.float32);  mul_tensor_854 = None
        convolution_backward_default_237 = torch.ops.aten.convolution_backward.default(to_dtype_491, mean_dim_5, primals_120, [6], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_491 = mean_dim_5 = primals_120 = None
        getitem_1593 = convolution_backward_default_237[0]
        getitem_1594 = convolution_backward_default_237[1]
        getitem_1595 = convolution_backward_default_237[2];  convolution_backward_default_237 = None
        expand_default_81 = torch.ops.aten.expand.default(getitem_1593, [1, 144, 80, 80]);  getitem_1593 = None
        div_scalar_17 = torch.ops.aten.div.Scalar(expand_default_81, 6400);  expand_default_81 = None
        add_tensor_603 = torch.ops.aten.add.Tensor(mul_tensor_848, div_scalar_17);  mul_tensor_848 = div_scalar_17 = None
        to_dtype_492 = torch.ops.aten.to.dtype(add_tensor_603, torch.float32);  add_tensor_603 = None
        to_dtype_493 = torch.ops.aten.to.dtype(clone_default_15, torch.float32);  clone_default_15 = None
        neg_default_190 = torch.ops.aten.neg.default(to_dtype_493)
        exp_default_114 = torch.ops.aten.exp.default(neg_default_190);  neg_default_190 = None
        add_tensor_604 = torch.ops.aten.add.Tensor(exp_default_114, 1);  exp_default_114 = None
        reciprocal_default_114 = torch.ops.aten.reciprocal.default(add_tensor_604);  add_tensor_604 = None
        mul_tensor_855 = torch.ops.aten.mul.Tensor(reciprocal_default_114, 1);  reciprocal_default_114 = None
        mul_tensor_856 = torch.ops.aten.mul.Tensor(to_dtype_492, mul_tensor_855);  to_dtype_492 = None
        rsub_scalar_132 = torch.ops.aten.rsub.Scalar(mul_tensor_855, 1);  mul_tensor_855 = None
        mul_tensor_857 = torch.ops.aten.mul.Tensor(to_dtype_493, rsub_scalar_132);  to_dtype_493 = rsub_scalar_132 = None
        add_tensor_605 = torch.ops.aten.add.Tensor(mul_tensor_857, 1);  mul_tensor_857 = None
        mul_tensor_858 = torch.ops.aten.mul.Tensor(mul_tensor_856, add_tensor_605);  mul_tensor_856 = add_tensor_605 = None
        to_dtype_494 = torch.ops.aten.to.dtype(mul_tensor_858, torch.float32);  mul_tensor_858 = None
        native_batch_norm_backward_default_120 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_494, convolution_default_25, primals_108, primals_106, primals_107, new_zeros_default_45, new_zeros_default_46, False, 0.001, [True, True, True]);  to_dtype_494 = convolution_default_25 = primals_108 = primals_106 = primals_107 = new_zeros_default_45 = new_zeros_default_46 = None
        getitem_1596 = native_batch_norm_backward_default_120[0]
        getitem_1597 = native_batch_norm_backward_default_120[1]
        getitem_1598 = native_batch_norm_backward_default_120[2];  native_batch_norm_backward_default_120 = None
        convolution_backward_default_238 = torch.ops.aten.convolution_backward.default(getitem_1596, constant_pad_nd_default_2, primals_114, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 144, [True, True, False]);  getitem_1596 = constant_pad_nd_default_2 = primals_114 = None
        getitem_1599 = convolution_backward_default_238[0]
        getitem_1600 = convolution_backward_default_238[1]
        getitem_1601 = convolution_backward_default_238[2];  convolution_backward_default_238 = None
        constant_pad_nd_default_43 = torch.ops.aten.constant_pad_nd.default(getitem_1599, [-1, -2, -1, -2]);  getitem_1599 = None
        to_dtype_495 = torch.ops.aten.to.dtype(constant_pad_nd_default_43, torch.float32);  constant_pad_nd_default_43 = None
        to_dtype_496 = torch.ops.aten.to.dtype(clone_default_14, torch.float32);  clone_default_14 = None
        neg_default_191 = torch.ops.aten.neg.default(to_dtype_496)
        exp_default_115 = torch.ops.aten.exp.default(neg_default_191);  neg_default_191 = None
        add_tensor_606 = torch.ops.aten.add.Tensor(exp_default_115, 1);  exp_default_115 = None
        reciprocal_default_115 = torch.ops.aten.reciprocal.default(add_tensor_606);  add_tensor_606 = None
        mul_tensor_859 = torch.ops.aten.mul.Tensor(reciprocal_default_115, 1);  reciprocal_default_115 = None
        mul_tensor_860 = torch.ops.aten.mul.Tensor(to_dtype_495, mul_tensor_859);  to_dtype_495 = None
        rsub_scalar_133 = torch.ops.aten.rsub.Scalar(mul_tensor_859, 1);  mul_tensor_859 = None
        mul_tensor_861 = torch.ops.aten.mul.Tensor(to_dtype_496, rsub_scalar_133);  to_dtype_496 = rsub_scalar_133 = None
        add_tensor_607 = torch.ops.aten.add.Tensor(mul_tensor_861, 1);  mul_tensor_861 = None
        mul_tensor_862 = torch.ops.aten.mul.Tensor(mul_tensor_860, add_tensor_607);  mul_tensor_860 = add_tensor_607 = None
        to_dtype_497 = torch.ops.aten.to.dtype(mul_tensor_862, torch.float32);  mul_tensor_862 = None
        native_batch_norm_backward_default_121 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_497, convolution_default_24, primals_103, primals_101, primals_102, new_zeros_default_42, new_zeros_default_43, False, 0.001, [True, True, True]);  to_dtype_497 = convolution_default_24 = primals_103 = primals_101 = primals_102 = new_zeros_default_42 = new_zeros_default_43 = None
        getitem_1602 = native_batch_norm_backward_default_121[0]
        getitem_1603 = native_batch_norm_backward_default_121[1]
        getitem_1604 = native_batch_norm_backward_default_121[2];  native_batch_norm_backward_default_121 = None
        convolution_backward_default_239 = torch.ops.aten.convolution_backward.default(getitem_1602, add__tensor_2, primals_115, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1602 = add__tensor_2 = primals_115 = None
        getitem_1605 = convolution_backward_default_239[0]
        getitem_1606 = convolution_backward_default_239[1]
        getitem_1607 = convolution_backward_default_239[2];  convolution_backward_default_239 = None
        native_batch_norm_backward_default_122 = torch.ops.aten.native_batch_norm_backward.default(getitem_1605, convolution_default_23, primals_91, primals_89, primals_90, new_zeros_default_39, new_zeros_default_40, False, 0.001, [True, True, True]);  convolution_default_23 = primals_91 = primals_89 = primals_90 = new_zeros_default_39 = new_zeros_default_40 = None
        getitem_1608 = native_batch_norm_backward_default_122[0]
        getitem_1609 = native_batch_norm_backward_default_122[1]
        getitem_1610 = native_batch_norm_backward_default_122[2];  native_batch_norm_backward_default_122 = None
        convolution_backward_default_240 = torch.ops.aten.convolution_backward.default(getitem_1608, mul_tensor_4, primals_94, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1608 = mul_tensor_4 = primals_94 = None
        getitem_1611 = convolution_backward_default_240[0]
        getitem_1612 = convolution_backward_default_240[1]
        getitem_1613 = convolution_backward_default_240[2];  convolution_backward_default_240 = None
        mul_tensor_863 = torch.ops.aten.mul.Tensor(getitem_1611, silu__default_12);  silu__default_12 = None
        mul_tensor_864 = torch.ops.aten.mul.Tensor(getitem_1611, sigmoid_default_4);  getitem_1611 = None
        sum_dim_int_list_50 = torch.ops.aten.sum.dim_IntList(mul_tensor_863, [2, 3], True);  mul_tensor_863 = None
        to_dtype_498 = torch.ops.aten.to.dtype(sum_dim_int_list_50, torch.float32);  sum_dim_int_list_50 = None
        to_dtype_499 = torch.ops.aten.to.dtype(sigmoid_default_4, torch.float32);  sigmoid_default_4 = None
        rsub_scalar_134 = torch.ops.aten.rsub.Scalar(to_dtype_499, 1)
        mul_tensor_865 = torch.ops.aten.mul.Tensor(to_dtype_499, rsub_scalar_134);  to_dtype_499 = rsub_scalar_134 = None
        conj_physical_default_18 = torch.ops.aten.conj_physical.default(mul_tensor_865);  mul_tensor_865 = None
        mul_tensor_866 = torch.ops.aten.mul.Tensor(to_dtype_498, conj_physical_default_18);  to_dtype_498 = conj_physical_default_18 = None
        to_dtype_500 = torch.ops.aten.to.dtype(mul_tensor_866, torch.float32);  mul_tensor_866 = None
        convolution_backward_default_241 = torch.ops.aten.convolution_backward.default(to_dtype_500, silu__default_13, primals_96, [144], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_500 = silu__default_13 = primals_96 = None
        getitem_1614 = convolution_backward_default_241[0]
        getitem_1615 = convolution_backward_default_241[1]
        getitem_1616 = convolution_backward_default_241[2];  convolution_backward_default_241 = None
        to_dtype_501 = torch.ops.aten.to.dtype(getitem_1614, torch.float32);  getitem_1614 = None
        to_dtype_502 = torch.ops.aten.to.dtype(clone_default_13, torch.float32);  clone_default_13 = None
        neg_default_192 = torch.ops.aten.neg.default(to_dtype_502)
        exp_default_116 = torch.ops.aten.exp.default(neg_default_192);  neg_default_192 = None
        add_tensor_608 = torch.ops.aten.add.Tensor(exp_default_116, 1);  exp_default_116 = None
        reciprocal_default_116 = torch.ops.aten.reciprocal.default(add_tensor_608);  add_tensor_608 = None
        mul_tensor_867 = torch.ops.aten.mul.Tensor(reciprocal_default_116, 1);  reciprocal_default_116 = None
        mul_tensor_868 = torch.ops.aten.mul.Tensor(to_dtype_501, mul_tensor_867);  to_dtype_501 = None
        rsub_scalar_135 = torch.ops.aten.rsub.Scalar(mul_tensor_867, 1);  mul_tensor_867 = None
        mul_tensor_869 = torch.ops.aten.mul.Tensor(to_dtype_502, rsub_scalar_135);  to_dtype_502 = rsub_scalar_135 = None
        add_tensor_609 = torch.ops.aten.add.Tensor(mul_tensor_869, 1);  mul_tensor_869 = None
        mul_tensor_870 = torch.ops.aten.mul.Tensor(mul_tensor_868, add_tensor_609);  mul_tensor_868 = add_tensor_609 = None
        to_dtype_503 = torch.ops.aten.to.dtype(mul_tensor_870, torch.float32);  mul_tensor_870 = None
        convolution_backward_default_242 = torch.ops.aten.convolution_backward.default(to_dtype_503, mean_dim_4, primals_98, [6], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_503 = mean_dim_4 = primals_98 = None
        getitem_1617 = convolution_backward_default_242[0]
        getitem_1618 = convolution_backward_default_242[1]
        getitem_1619 = convolution_backward_default_242[2];  convolution_backward_default_242 = None
        expand_default_82 = torch.ops.aten.expand.default(getitem_1617, [1, 144, 160, 160]);  getitem_1617 = None
        div_scalar_18 = torch.ops.aten.div.Scalar(expand_default_82, 25600);  expand_default_82 = None
        add_tensor_610 = torch.ops.aten.add.Tensor(mul_tensor_864, div_scalar_18);  mul_tensor_864 = div_scalar_18 = None
        to_dtype_504 = torch.ops.aten.to.dtype(add_tensor_610, torch.float32);  add_tensor_610 = None
        to_dtype_505 = torch.ops.aten.to.dtype(clone_default_12, torch.float32);  clone_default_12 = None
        neg_default_193 = torch.ops.aten.neg.default(to_dtype_505)
        exp_default_117 = torch.ops.aten.exp.default(neg_default_193);  neg_default_193 = None
        add_tensor_611 = torch.ops.aten.add.Tensor(exp_default_117, 1);  exp_default_117 = None
        reciprocal_default_117 = torch.ops.aten.reciprocal.default(add_tensor_611);  add_tensor_611 = None
        mul_tensor_871 = torch.ops.aten.mul.Tensor(reciprocal_default_117, 1);  reciprocal_default_117 = None
        mul_tensor_872 = torch.ops.aten.mul.Tensor(to_dtype_504, mul_tensor_871);  to_dtype_504 = None
        rsub_scalar_136 = torch.ops.aten.rsub.Scalar(mul_tensor_871, 1);  mul_tensor_871 = None
        mul_tensor_873 = torch.ops.aten.mul.Tensor(to_dtype_505, rsub_scalar_136);  to_dtype_505 = rsub_scalar_136 = None
        add_tensor_612 = torch.ops.aten.add.Tensor(mul_tensor_873, 1);  mul_tensor_873 = None
        mul_tensor_874 = torch.ops.aten.mul.Tensor(mul_tensor_872, add_tensor_612);  mul_tensor_872 = add_tensor_612 = None
        to_dtype_506 = torch.ops.aten.to.dtype(mul_tensor_874, torch.float32);  mul_tensor_874 = None
        native_batch_norm_backward_default_123 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_506, convolution_default_20, primals_86, primals_84, primals_85, new_zeros_default_36, new_zeros_default_37, False, 0.001, [True, True, True]);  to_dtype_506 = convolution_default_20 = primals_86 = primals_84 = primals_85 = new_zeros_default_36 = new_zeros_default_37 = None
        getitem_1620 = native_batch_norm_backward_default_123[0]
        getitem_1621 = native_batch_norm_backward_default_123[1]
        getitem_1622 = native_batch_norm_backward_default_123[2];  native_batch_norm_backward_default_123 = None
        convolution_backward_default_243 = torch.ops.aten.convolution_backward.default(getitem_1620, silu__default_11, primals_92, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 144, [True, True, False]);  getitem_1620 = silu__default_11 = primals_92 = None
        getitem_1623 = convolution_backward_default_243[0]
        getitem_1624 = convolution_backward_default_243[1]
        getitem_1625 = convolution_backward_default_243[2];  convolution_backward_default_243 = None
        to_dtype_507 = torch.ops.aten.to.dtype(getitem_1623, torch.float32);  getitem_1623 = None
        to_dtype_508 = torch.ops.aten.to.dtype(clone_default_11, torch.float32);  clone_default_11 = None
        neg_default_194 = torch.ops.aten.neg.default(to_dtype_508)
        exp_default_118 = torch.ops.aten.exp.default(neg_default_194);  neg_default_194 = None
        add_tensor_613 = torch.ops.aten.add.Tensor(exp_default_118, 1);  exp_default_118 = None
        reciprocal_default_118 = torch.ops.aten.reciprocal.default(add_tensor_613);  add_tensor_613 = None
        mul_tensor_875 = torch.ops.aten.mul.Tensor(reciprocal_default_118, 1);  reciprocal_default_118 = None
        mul_tensor_876 = torch.ops.aten.mul.Tensor(to_dtype_507, mul_tensor_875);  to_dtype_507 = None
        rsub_scalar_137 = torch.ops.aten.rsub.Scalar(mul_tensor_875, 1);  mul_tensor_875 = None
        mul_tensor_877 = torch.ops.aten.mul.Tensor(to_dtype_508, rsub_scalar_137);  to_dtype_508 = rsub_scalar_137 = None
        add_tensor_614 = torch.ops.aten.add.Tensor(mul_tensor_877, 1);  mul_tensor_877 = None
        mul_tensor_878 = torch.ops.aten.mul.Tensor(mul_tensor_876, add_tensor_614);  mul_tensor_876 = add_tensor_614 = None
        to_dtype_509 = torch.ops.aten.to.dtype(mul_tensor_878, torch.float32);  mul_tensor_878 = None
        native_batch_norm_backward_default_124 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_509, convolution_default_19, primals_81, primals_79, primals_80, new_zeros_default_33, new_zeros_default_34, False, 0.001, [True, True, True]);  to_dtype_509 = convolution_default_19 = primals_81 = primals_79 = primals_80 = new_zeros_default_33 = new_zeros_default_34 = None
        getitem_1626 = native_batch_norm_backward_default_124[0]
        getitem_1627 = native_batch_norm_backward_default_124[1]
        getitem_1628 = native_batch_norm_backward_default_124[2];  native_batch_norm_backward_default_124 = None
        convolution_backward_default_244 = torch.ops.aten.convolution_backward.default(getitem_1626, add__tensor_1, primals_93, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1626 = add__tensor_1 = primals_93 = None
        getitem_1629 = convolution_backward_default_244[0]
        getitem_1630 = convolution_backward_default_244[1]
        getitem_1631 = convolution_backward_default_244[2];  convolution_backward_default_244 = None
        add_tensor_615 = torch.ops.aten.add.Tensor(getitem_1605, getitem_1629);  getitem_1605 = getitem_1629 = None
        native_batch_norm_backward_default_125 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_615, convolution_default_18, primals_69, primals_67, primals_68, new_zeros_default_30, new_zeros_default_31, False, 0.001, [True, True, True]);  convolution_default_18 = primals_69 = primals_67 = primals_68 = new_zeros_default_30 = new_zeros_default_31 = None
        getitem_1632 = native_batch_norm_backward_default_125[0]
        getitem_1633 = native_batch_norm_backward_default_125[1]
        getitem_1634 = native_batch_norm_backward_default_125[2];  native_batch_norm_backward_default_125 = None
        convolution_backward_default_245 = torch.ops.aten.convolution_backward.default(getitem_1632, mul_tensor_3, primals_72, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1632 = mul_tensor_3 = primals_72 = None
        getitem_1635 = convolution_backward_default_245[0]
        getitem_1636 = convolution_backward_default_245[1]
        getitem_1637 = convolution_backward_default_245[2];  convolution_backward_default_245 = None
        mul_tensor_879 = torch.ops.aten.mul.Tensor(getitem_1635, silu__default_9);  silu__default_9 = None
        mul_tensor_880 = torch.ops.aten.mul.Tensor(getitem_1635, sigmoid_default_3);  getitem_1635 = None
        sum_dim_int_list_51 = torch.ops.aten.sum.dim_IntList(mul_tensor_879, [2, 3], True);  mul_tensor_879 = None
        to_dtype_510 = torch.ops.aten.to.dtype(sum_dim_int_list_51, torch.float32);  sum_dim_int_list_51 = None
        to_dtype_511 = torch.ops.aten.to.dtype(sigmoid_default_3, torch.float32);  sigmoid_default_3 = None
        rsub_scalar_138 = torch.ops.aten.rsub.Scalar(to_dtype_511, 1)
        mul_tensor_881 = torch.ops.aten.mul.Tensor(to_dtype_511, rsub_scalar_138);  to_dtype_511 = rsub_scalar_138 = None
        conj_physical_default_19 = torch.ops.aten.conj_physical.default(mul_tensor_881);  mul_tensor_881 = None
        mul_tensor_882 = torch.ops.aten.mul.Tensor(to_dtype_510, conj_physical_default_19);  to_dtype_510 = conj_physical_default_19 = None
        to_dtype_512 = torch.ops.aten.to.dtype(mul_tensor_882, torch.float32);  mul_tensor_882 = None
        convolution_backward_default_246 = torch.ops.aten.convolution_backward.default(to_dtype_512, silu__default_10, primals_74, [144], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_512 = silu__default_10 = primals_74 = None
        getitem_1638 = convolution_backward_default_246[0]
        getitem_1639 = convolution_backward_default_246[1]
        getitem_1640 = convolution_backward_default_246[2];  convolution_backward_default_246 = None
        to_dtype_513 = torch.ops.aten.to.dtype(getitem_1638, torch.float32);  getitem_1638 = None
        to_dtype_514 = torch.ops.aten.to.dtype(clone_default_10, torch.float32);  clone_default_10 = None
        neg_default_195 = torch.ops.aten.neg.default(to_dtype_514)
        exp_default_119 = torch.ops.aten.exp.default(neg_default_195);  neg_default_195 = None
        add_tensor_616 = torch.ops.aten.add.Tensor(exp_default_119, 1);  exp_default_119 = None
        reciprocal_default_119 = torch.ops.aten.reciprocal.default(add_tensor_616);  add_tensor_616 = None
        mul_tensor_883 = torch.ops.aten.mul.Tensor(reciprocal_default_119, 1);  reciprocal_default_119 = None
        mul_tensor_884 = torch.ops.aten.mul.Tensor(to_dtype_513, mul_tensor_883);  to_dtype_513 = None
        rsub_scalar_139 = torch.ops.aten.rsub.Scalar(mul_tensor_883, 1);  mul_tensor_883 = None
        mul_tensor_885 = torch.ops.aten.mul.Tensor(to_dtype_514, rsub_scalar_139);  to_dtype_514 = rsub_scalar_139 = None
        add_tensor_617 = torch.ops.aten.add.Tensor(mul_tensor_885, 1);  mul_tensor_885 = None
        mul_tensor_886 = torch.ops.aten.mul.Tensor(mul_tensor_884, add_tensor_617);  mul_tensor_884 = add_tensor_617 = None
        to_dtype_515 = torch.ops.aten.to.dtype(mul_tensor_886, torch.float32);  mul_tensor_886 = None
        convolution_backward_default_247 = torch.ops.aten.convolution_backward.default(to_dtype_515, mean_dim_3, primals_76, [6], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_515 = mean_dim_3 = primals_76 = None
        getitem_1641 = convolution_backward_default_247[0]
        getitem_1642 = convolution_backward_default_247[1]
        getitem_1643 = convolution_backward_default_247[2];  convolution_backward_default_247 = None
        expand_default_83 = torch.ops.aten.expand.default(getitem_1641, [1, 144, 160, 160]);  getitem_1641 = None
        div_scalar_19 = torch.ops.aten.div.Scalar(expand_default_83, 25600);  expand_default_83 = None
        add_tensor_618 = torch.ops.aten.add.Tensor(mul_tensor_880, div_scalar_19);  mul_tensor_880 = div_scalar_19 = None
        to_dtype_516 = torch.ops.aten.to.dtype(add_tensor_618, torch.float32);  add_tensor_618 = None
        to_dtype_517 = torch.ops.aten.to.dtype(clone_default_9, torch.float32);  clone_default_9 = None
        neg_default_196 = torch.ops.aten.neg.default(to_dtype_517)
        exp_default_120 = torch.ops.aten.exp.default(neg_default_196);  neg_default_196 = None
        add_tensor_619 = torch.ops.aten.add.Tensor(exp_default_120, 1);  exp_default_120 = None
        reciprocal_default_120 = torch.ops.aten.reciprocal.default(add_tensor_619);  add_tensor_619 = None
        mul_tensor_887 = torch.ops.aten.mul.Tensor(reciprocal_default_120, 1);  reciprocal_default_120 = None
        mul_tensor_888 = torch.ops.aten.mul.Tensor(to_dtype_516, mul_tensor_887);  to_dtype_516 = None
        rsub_scalar_140 = torch.ops.aten.rsub.Scalar(mul_tensor_887, 1);  mul_tensor_887 = None
        mul_tensor_889 = torch.ops.aten.mul.Tensor(to_dtype_517, rsub_scalar_140);  to_dtype_517 = rsub_scalar_140 = None
        add_tensor_620 = torch.ops.aten.add.Tensor(mul_tensor_889, 1);  mul_tensor_889 = None
        mul_tensor_890 = torch.ops.aten.mul.Tensor(mul_tensor_888, add_tensor_620);  mul_tensor_888 = add_tensor_620 = None
        to_dtype_518 = torch.ops.aten.to.dtype(mul_tensor_890, torch.float32);  mul_tensor_890 = None
        native_batch_norm_backward_default_126 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_518, convolution_default_15, primals_64, primals_62, primals_63, new_zeros_default_27, new_zeros_default_28, False, 0.001, [True, True, True]);  to_dtype_518 = convolution_default_15 = primals_64 = primals_62 = primals_63 = new_zeros_default_27 = new_zeros_default_28 = None
        getitem_1644 = native_batch_norm_backward_default_126[0]
        getitem_1645 = native_batch_norm_backward_default_126[1]
        getitem_1646 = native_batch_norm_backward_default_126[2];  native_batch_norm_backward_default_126 = None
        convolution_backward_default_248 = torch.ops.aten.convolution_backward.default(getitem_1644, silu__default_8, primals_70, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 144, [True, True, False]);  getitem_1644 = silu__default_8 = primals_70 = None
        getitem_1647 = convolution_backward_default_248[0]
        getitem_1648 = convolution_backward_default_248[1]
        getitem_1649 = convolution_backward_default_248[2];  convolution_backward_default_248 = None
        to_dtype_519 = torch.ops.aten.to.dtype(getitem_1647, torch.float32);  getitem_1647 = None
        to_dtype_520 = torch.ops.aten.to.dtype(clone_default_8, torch.float32);  clone_default_8 = None
        neg_default_197 = torch.ops.aten.neg.default(to_dtype_520)
        exp_default_121 = torch.ops.aten.exp.default(neg_default_197);  neg_default_197 = None
        add_tensor_621 = torch.ops.aten.add.Tensor(exp_default_121, 1);  exp_default_121 = None
        reciprocal_default_121 = torch.ops.aten.reciprocal.default(add_tensor_621);  add_tensor_621 = None
        mul_tensor_891 = torch.ops.aten.mul.Tensor(reciprocal_default_121, 1);  reciprocal_default_121 = None
        mul_tensor_892 = torch.ops.aten.mul.Tensor(to_dtype_519, mul_tensor_891);  to_dtype_519 = None
        rsub_scalar_141 = torch.ops.aten.rsub.Scalar(mul_tensor_891, 1);  mul_tensor_891 = None
        mul_tensor_893 = torch.ops.aten.mul.Tensor(to_dtype_520, rsub_scalar_141);  to_dtype_520 = rsub_scalar_141 = None
        add_tensor_622 = torch.ops.aten.add.Tensor(mul_tensor_893, 1);  mul_tensor_893 = None
        mul_tensor_894 = torch.ops.aten.mul.Tensor(mul_tensor_892, add_tensor_622);  mul_tensor_892 = add_tensor_622 = None
        to_dtype_521 = torch.ops.aten.to.dtype(mul_tensor_894, torch.float32);  mul_tensor_894 = None
        native_batch_norm_backward_default_127 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_521, convolution_default_14, primals_59, primals_57, primals_58, new_zeros_default_24, new_zeros_default_25, False, 0.001, [True, True, True]);  to_dtype_521 = convolution_default_14 = primals_59 = primals_57 = primals_58 = new_zeros_default_24 = new_zeros_default_25 = None
        getitem_1650 = native_batch_norm_backward_default_127[0]
        getitem_1651 = native_batch_norm_backward_default_127[1]
        getitem_1652 = native_batch_norm_backward_default_127[2];  native_batch_norm_backward_default_127 = None
        convolution_backward_default_249 = torch.ops.aten.convolution_backward.default(getitem_1650, getitem_21, primals_71, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1650 = getitem_21 = primals_71 = None
        getitem_1653 = convolution_backward_default_249[0]
        getitem_1654 = convolution_backward_default_249[1]
        getitem_1655 = convolution_backward_default_249[2];  convolution_backward_default_249 = None
        add_tensor_623 = torch.ops.aten.add.Tensor(add_tensor_615, getitem_1653);  add_tensor_615 = getitem_1653 = None
        native_batch_norm_backward_default_128 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_623, convolution_default_13, primals_47, primals_45, primals_46, new_zeros_default_21, new_zeros_default_22, False, 0.001, [True, True, True]);  add_tensor_623 = convolution_default_13 = primals_47 = primals_45 = primals_46 = new_zeros_default_21 = new_zeros_default_22 = None
        getitem_1656 = native_batch_norm_backward_default_128[0]
        getitem_1657 = native_batch_norm_backward_default_128[1]
        getitem_1658 = native_batch_norm_backward_default_128[2];  native_batch_norm_backward_default_128 = None
        convolution_backward_default_250 = torch.ops.aten.convolution_backward.default(getitem_1656, mul_tensor_2, primals_50, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1656 = mul_tensor_2 = primals_50 = None
        getitem_1659 = convolution_backward_default_250[0]
        getitem_1660 = convolution_backward_default_250[1]
        getitem_1661 = convolution_backward_default_250[2];  convolution_backward_default_250 = None
        mul_tensor_895 = torch.ops.aten.mul.Tensor(getitem_1659, silu__default_6);  silu__default_6 = None
        mul_tensor_896 = torch.ops.aten.mul.Tensor(getitem_1659, sigmoid_default_2);  getitem_1659 = None
        sum_dim_int_list_52 = torch.ops.aten.sum.dim_IntList(mul_tensor_895, [2, 3], True);  mul_tensor_895 = None
        to_dtype_522 = torch.ops.aten.to.dtype(sum_dim_int_list_52, torch.float32);  sum_dim_int_list_52 = None
        to_dtype_523 = torch.ops.aten.to.dtype(sigmoid_default_2, torch.float32);  sigmoid_default_2 = None
        rsub_scalar_142 = torch.ops.aten.rsub.Scalar(to_dtype_523, 1)
        mul_tensor_897 = torch.ops.aten.mul.Tensor(to_dtype_523, rsub_scalar_142);  to_dtype_523 = rsub_scalar_142 = None
        conj_physical_default_20 = torch.ops.aten.conj_physical.default(mul_tensor_897);  mul_tensor_897 = None
        mul_tensor_898 = torch.ops.aten.mul.Tensor(to_dtype_522, conj_physical_default_20);  to_dtype_522 = conj_physical_default_20 = None
        to_dtype_524 = torch.ops.aten.to.dtype(mul_tensor_898, torch.float32);  mul_tensor_898 = None
        convolution_backward_default_251 = torch.ops.aten.convolution_backward.default(to_dtype_524, silu__default_7, primals_52, [96], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_524 = silu__default_7 = primals_52 = None
        getitem_1662 = convolution_backward_default_251[0]
        getitem_1663 = convolution_backward_default_251[1]
        getitem_1664 = convolution_backward_default_251[2];  convolution_backward_default_251 = None
        to_dtype_525 = torch.ops.aten.to.dtype(getitem_1662, torch.float32);  getitem_1662 = None
        to_dtype_526 = torch.ops.aten.to.dtype(clone_default_7, torch.float32);  clone_default_7 = None
        neg_default_198 = torch.ops.aten.neg.default(to_dtype_526)
        exp_default_122 = torch.ops.aten.exp.default(neg_default_198);  neg_default_198 = None
        add_tensor_624 = torch.ops.aten.add.Tensor(exp_default_122, 1);  exp_default_122 = None
        reciprocal_default_122 = torch.ops.aten.reciprocal.default(add_tensor_624);  add_tensor_624 = None
        mul_tensor_899 = torch.ops.aten.mul.Tensor(reciprocal_default_122, 1);  reciprocal_default_122 = None
        mul_tensor_900 = torch.ops.aten.mul.Tensor(to_dtype_525, mul_tensor_899);  to_dtype_525 = None
        rsub_scalar_143 = torch.ops.aten.rsub.Scalar(mul_tensor_899, 1);  mul_tensor_899 = None
        mul_tensor_901 = torch.ops.aten.mul.Tensor(to_dtype_526, rsub_scalar_143);  to_dtype_526 = rsub_scalar_143 = None
        add_tensor_625 = torch.ops.aten.add.Tensor(mul_tensor_901, 1);  mul_tensor_901 = None
        mul_tensor_902 = torch.ops.aten.mul.Tensor(mul_tensor_900, add_tensor_625);  mul_tensor_900 = add_tensor_625 = None
        to_dtype_527 = torch.ops.aten.to.dtype(mul_tensor_902, torch.float32);  mul_tensor_902 = None
        convolution_backward_default_252 = torch.ops.aten.convolution_backward.default(to_dtype_527, mean_dim_2, primals_54, [4], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_527 = mean_dim_2 = primals_54 = None
        getitem_1665 = convolution_backward_default_252[0]
        getitem_1666 = convolution_backward_default_252[1]
        getitem_1667 = convolution_backward_default_252[2];  convolution_backward_default_252 = None
        expand_default_84 = torch.ops.aten.expand.default(getitem_1665, [1, 96, 160, 160]);  getitem_1665 = None
        div_scalar_20 = torch.ops.aten.div.Scalar(expand_default_84, 25600);  expand_default_84 = None
        add_tensor_626 = torch.ops.aten.add.Tensor(mul_tensor_896, div_scalar_20);  mul_tensor_896 = div_scalar_20 = None
        to_dtype_528 = torch.ops.aten.to.dtype(add_tensor_626, torch.float32);  add_tensor_626 = None
        to_dtype_529 = torch.ops.aten.to.dtype(clone_default_6, torch.float32);  clone_default_6 = None
        neg_default_199 = torch.ops.aten.neg.default(to_dtype_529)
        exp_default_123 = torch.ops.aten.exp.default(neg_default_199);  neg_default_199 = None
        add_tensor_627 = torch.ops.aten.add.Tensor(exp_default_123, 1);  exp_default_123 = None
        reciprocal_default_123 = torch.ops.aten.reciprocal.default(add_tensor_627);  add_tensor_627 = None
        mul_tensor_903 = torch.ops.aten.mul.Tensor(reciprocal_default_123, 1);  reciprocal_default_123 = None
        mul_tensor_904 = torch.ops.aten.mul.Tensor(to_dtype_528, mul_tensor_903);  to_dtype_528 = None
        rsub_scalar_144 = torch.ops.aten.rsub.Scalar(mul_tensor_903, 1);  mul_tensor_903 = None
        mul_tensor_905 = torch.ops.aten.mul.Tensor(to_dtype_529, rsub_scalar_144);  to_dtype_529 = rsub_scalar_144 = None
        add_tensor_628 = torch.ops.aten.add.Tensor(mul_tensor_905, 1);  mul_tensor_905 = None
        mul_tensor_906 = torch.ops.aten.mul.Tensor(mul_tensor_904, add_tensor_628);  mul_tensor_904 = add_tensor_628 = None
        to_dtype_530 = torch.ops.aten.to.dtype(mul_tensor_906, torch.float32);  mul_tensor_906 = None
        native_batch_norm_backward_default_129 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_530, convolution_default_10, primals_42, primals_40, primals_41, new_zeros_default_18, new_zeros_default_19, False, 0.001, [True, True, True]);  to_dtype_530 = convolution_default_10 = primals_42 = primals_40 = primals_41 = new_zeros_default_18 = new_zeros_default_19 = None
        getitem_1668 = native_batch_norm_backward_default_129[0]
        getitem_1669 = native_batch_norm_backward_default_129[1]
        getitem_1670 = native_batch_norm_backward_default_129[2];  native_batch_norm_backward_default_129 = None
        convolution_backward_default_253 = torch.ops.aten.convolution_backward.default(getitem_1668, constant_pad_nd_default_1, primals_48, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 96, [True, True, False]);  getitem_1668 = constant_pad_nd_default_1 = primals_48 = None
        getitem_1671 = convolution_backward_default_253[0]
        getitem_1672 = convolution_backward_default_253[1]
        getitem_1673 = convolution_backward_default_253[2];  convolution_backward_default_253 = None
        constant_pad_nd_default_44 = torch.ops.aten.constant_pad_nd.default(getitem_1671, [0, -1, 0, -1]);  getitem_1671 = None
        to_dtype_531 = torch.ops.aten.to.dtype(constant_pad_nd_default_44, torch.float32);  constant_pad_nd_default_44 = None
        to_dtype_532 = torch.ops.aten.to.dtype(clone_default_5, torch.float32);  clone_default_5 = None
        neg_default_200 = torch.ops.aten.neg.default(to_dtype_532)
        exp_default_124 = torch.ops.aten.exp.default(neg_default_200);  neg_default_200 = None
        add_tensor_629 = torch.ops.aten.add.Tensor(exp_default_124, 1);  exp_default_124 = None
        reciprocal_default_124 = torch.ops.aten.reciprocal.default(add_tensor_629);  add_tensor_629 = None
        mul_tensor_907 = torch.ops.aten.mul.Tensor(reciprocal_default_124, 1);  reciprocal_default_124 = None
        mul_tensor_908 = torch.ops.aten.mul.Tensor(to_dtype_531, mul_tensor_907);  to_dtype_531 = None
        rsub_scalar_145 = torch.ops.aten.rsub.Scalar(mul_tensor_907, 1);  mul_tensor_907 = None
        mul_tensor_909 = torch.ops.aten.mul.Tensor(to_dtype_532, rsub_scalar_145);  to_dtype_532 = rsub_scalar_145 = None
        add_tensor_630 = torch.ops.aten.add.Tensor(mul_tensor_909, 1);  mul_tensor_909 = None
        mul_tensor_910 = torch.ops.aten.mul.Tensor(mul_tensor_908, add_tensor_630);  mul_tensor_908 = add_tensor_630 = None
        to_dtype_533 = torch.ops.aten.to.dtype(mul_tensor_910, torch.float32);  mul_tensor_910 = None
        native_batch_norm_backward_default_130 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_533, convolution_default_9, primals_37, primals_35, primals_36, new_zeros_default_15, new_zeros_default_16, False, 0.001, [True, True, True]);  to_dtype_533 = convolution_default_9 = primals_37 = primals_35 = primals_36 = new_zeros_default_15 = new_zeros_default_16 = None
        getitem_1674 = native_batch_norm_backward_default_130[0]
        getitem_1675 = native_batch_norm_backward_default_130[1]
        getitem_1676 = native_batch_norm_backward_default_130[2];  native_batch_norm_backward_default_130 = None
        convolution_backward_default_254 = torch.ops.aten.convolution_backward.default(getitem_1674, add__tensor, primals_49, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1674 = add__tensor = primals_49 = None
        getitem_1677 = convolution_backward_default_254[0]
        getitem_1678 = convolution_backward_default_254[1]
        getitem_1679 = convolution_backward_default_254[2];  convolution_backward_default_254 = None
        native_batch_norm_backward_default_131 = torch.ops.aten.native_batch_norm_backward.default(getitem_1677, convolution_default_8, primals_26, primals_24, primals_25, new_zeros_default_12, new_zeros_default_13, False, 0.001, [True, True, True]);  convolution_default_8 = primals_26 = primals_24 = primals_25 = new_zeros_default_12 = new_zeros_default_13 = None
        getitem_1680 = native_batch_norm_backward_default_131[0]
        getitem_1681 = native_batch_norm_backward_default_131[1]
        getitem_1682 = native_batch_norm_backward_default_131[2];  native_batch_norm_backward_default_131 = None
        convolution_backward_default_255 = torch.ops.aten.convolution_backward.default(getitem_1680, mul_tensor_1, primals_28, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1680 = mul_tensor_1 = primals_28 = None
        getitem_1683 = convolution_backward_default_255[0]
        getitem_1684 = convolution_backward_default_255[1]
        getitem_1685 = convolution_backward_default_255[2];  convolution_backward_default_255 = None
        mul_tensor_911 = torch.ops.aten.mul.Tensor(getitem_1683, silu__default_3);  silu__default_3 = None
        mul_tensor_912 = torch.ops.aten.mul.Tensor(getitem_1683, sigmoid_default_1);  getitem_1683 = None
        sum_dim_int_list_53 = torch.ops.aten.sum.dim_IntList(mul_tensor_911, [2, 3], True);  mul_tensor_911 = None
        to_dtype_534 = torch.ops.aten.to.dtype(sum_dim_int_list_53, torch.float32);  sum_dim_int_list_53 = None
        to_dtype_535 = torch.ops.aten.to.dtype(sigmoid_default_1, torch.float32);  sigmoid_default_1 = None
        rsub_scalar_146 = torch.ops.aten.rsub.Scalar(to_dtype_535, 1)
        mul_tensor_913 = torch.ops.aten.mul.Tensor(to_dtype_535, rsub_scalar_146);  to_dtype_535 = rsub_scalar_146 = None
        conj_physical_default_21 = torch.ops.aten.conj_physical.default(mul_tensor_913);  mul_tensor_913 = None
        mul_tensor_914 = torch.ops.aten.mul.Tensor(to_dtype_534, conj_physical_default_21);  to_dtype_534 = conj_physical_default_21 = None
        to_dtype_536 = torch.ops.aten.to.dtype(mul_tensor_914, torch.float32);  mul_tensor_914 = None
        convolution_backward_default_256 = torch.ops.aten.convolution_backward.default(to_dtype_536, silu__default_4, primals_30, [16], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_536 = silu__default_4 = primals_30 = None
        getitem_1686 = convolution_backward_default_256[0]
        getitem_1687 = convolution_backward_default_256[1]
        getitem_1688 = convolution_backward_default_256[2];  convolution_backward_default_256 = None
        to_dtype_537 = torch.ops.aten.to.dtype(getitem_1686, torch.float32);  getitem_1686 = None
        to_dtype_538 = torch.ops.aten.to.dtype(clone_default_4, torch.float32);  clone_default_4 = None
        neg_default_201 = torch.ops.aten.neg.default(to_dtype_538)
        exp_default_125 = torch.ops.aten.exp.default(neg_default_201);  neg_default_201 = None
        add_tensor_631 = torch.ops.aten.add.Tensor(exp_default_125, 1);  exp_default_125 = None
        reciprocal_default_125 = torch.ops.aten.reciprocal.default(add_tensor_631);  add_tensor_631 = None
        mul_tensor_915 = torch.ops.aten.mul.Tensor(reciprocal_default_125, 1);  reciprocal_default_125 = None
        mul_tensor_916 = torch.ops.aten.mul.Tensor(to_dtype_537, mul_tensor_915);  to_dtype_537 = None
        rsub_scalar_147 = torch.ops.aten.rsub.Scalar(mul_tensor_915, 1);  mul_tensor_915 = None
        mul_tensor_917 = torch.ops.aten.mul.Tensor(to_dtype_538, rsub_scalar_147);  to_dtype_538 = rsub_scalar_147 = None
        add_tensor_632 = torch.ops.aten.add.Tensor(mul_tensor_917, 1);  mul_tensor_917 = None
        mul_tensor_918 = torch.ops.aten.mul.Tensor(mul_tensor_916, add_tensor_632);  mul_tensor_916 = add_tensor_632 = None
        to_dtype_539 = torch.ops.aten.to.dtype(mul_tensor_918, torch.float32);  mul_tensor_918 = None
        convolution_backward_default_257 = torch.ops.aten.convolution_backward.default(to_dtype_539, mean_dim_1, primals_32, [4], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_539 = mean_dim_1 = primals_32 = None
        getitem_1689 = convolution_backward_default_257[0]
        getitem_1690 = convolution_backward_default_257[1]
        getitem_1691 = convolution_backward_default_257[2];  convolution_backward_default_257 = None
        expand_default_85 = torch.ops.aten.expand.default(getitem_1689, [1, 16, 320, 320]);  getitem_1689 = None
        div_scalar_21 = torch.ops.aten.div.Scalar(expand_default_85, 102400);  expand_default_85 = None
        add_tensor_633 = torch.ops.aten.add.Tensor(mul_tensor_912, div_scalar_21);  mul_tensor_912 = div_scalar_21 = None
        to_dtype_540 = torch.ops.aten.to.dtype(add_tensor_633, torch.float32);  add_tensor_633 = None
        to_dtype_541 = torch.ops.aten.to.dtype(clone_default_3, torch.float32);  clone_default_3 = None
        neg_default_202 = torch.ops.aten.neg.default(to_dtype_541)
        exp_default_126 = torch.ops.aten.exp.default(neg_default_202);  neg_default_202 = None
        add_tensor_634 = torch.ops.aten.add.Tensor(exp_default_126, 1);  exp_default_126 = None
        reciprocal_default_126 = torch.ops.aten.reciprocal.default(add_tensor_634);  add_tensor_634 = None
        mul_tensor_919 = torch.ops.aten.mul.Tensor(reciprocal_default_126, 1);  reciprocal_default_126 = None
        mul_tensor_920 = torch.ops.aten.mul.Tensor(to_dtype_540, mul_tensor_919);  to_dtype_540 = None
        rsub_scalar_148 = torch.ops.aten.rsub.Scalar(mul_tensor_919, 1);  mul_tensor_919 = None
        mul_tensor_921 = torch.ops.aten.mul.Tensor(to_dtype_541, rsub_scalar_148);  to_dtype_541 = rsub_scalar_148 = None
        add_tensor_635 = torch.ops.aten.add.Tensor(mul_tensor_921, 1);  mul_tensor_921 = None
        mul_tensor_922 = torch.ops.aten.mul.Tensor(mul_tensor_920, add_tensor_635);  mul_tensor_920 = add_tensor_635 = None
        to_dtype_542 = torch.ops.aten.to.dtype(mul_tensor_922, torch.float32);  mul_tensor_922 = None
        native_batch_norm_backward_default_132 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_542, convolution_default_5, primals_21, primals_19, primals_20, new_zeros_default_9, new_zeros_default_10, False, 0.001, [True, True, True]);  to_dtype_542 = convolution_default_5 = primals_21 = primals_19 = primals_20 = new_zeros_default_9 = new_zeros_default_10 = None
        getitem_1692 = native_batch_norm_backward_default_132[0]
        getitem_1693 = native_batch_norm_backward_default_132[1]
        getitem_1694 = native_batch_norm_backward_default_132[2];  native_batch_norm_backward_default_132 = None
        convolution_backward_default_258 = torch.ops.aten.convolution_backward.default(getitem_1692, getitem_6, primals_27, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 16, [True, True, False]);  getitem_1692 = getitem_6 = primals_27 = None
        getitem_1695 = convolution_backward_default_258[0]
        getitem_1696 = convolution_backward_default_258[1]
        getitem_1697 = convolution_backward_default_258[2];  convolution_backward_default_258 = None
        add_tensor_636 = torch.ops.aten.add.Tensor(getitem_1677, getitem_1695);  getitem_1677 = getitem_1695 = None
        native_batch_norm_backward_default_133 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_636, convolution_default_4, primals_10, primals_8, primals_9, new_zeros_default_6, new_zeros_default_7, False, 0.001, [True, True, True]);  add_tensor_636 = convolution_default_4 = primals_10 = primals_8 = primals_9 = new_zeros_default_6 = new_zeros_default_7 = None
        getitem_1698 = native_batch_norm_backward_default_133[0]
        getitem_1699 = native_batch_norm_backward_default_133[1]
        getitem_1700 = native_batch_norm_backward_default_133[2];  native_batch_norm_backward_default_133 = None
        convolution_backward_default_259 = torch.ops.aten.convolution_backward.default(getitem_1698, mul_tensor, primals_12, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1698 = mul_tensor = primals_12 = None
        getitem_1701 = convolution_backward_default_259[0]
        getitem_1702 = convolution_backward_default_259[1]
        getitem_1703 = convolution_backward_default_259[2];  convolution_backward_default_259 = None
        mul_tensor_923 = torch.ops.aten.mul.Tensor(getitem_1701, silu__default_1);  silu__default_1 = None
        mul_tensor_924 = torch.ops.aten.mul.Tensor(getitem_1701, sigmoid_default);  getitem_1701 = None
        sum_dim_int_list_54 = torch.ops.aten.sum.dim_IntList(mul_tensor_923, [2, 3], True);  mul_tensor_923 = None
        to_dtype_543 = torch.ops.aten.to.dtype(sum_dim_int_list_54, torch.float32);  sum_dim_int_list_54 = None
        to_dtype_544 = torch.ops.aten.to.dtype(sigmoid_default, torch.float32);  sigmoid_default = None
        rsub_scalar_149 = torch.ops.aten.rsub.Scalar(to_dtype_544, 1)
        mul_tensor_925 = torch.ops.aten.mul.Tensor(to_dtype_544, rsub_scalar_149);  to_dtype_544 = rsub_scalar_149 = None
        conj_physical_default_22 = torch.ops.aten.conj_physical.default(mul_tensor_925);  mul_tensor_925 = None
        mul_tensor_926 = torch.ops.aten.mul.Tensor(to_dtype_543, conj_physical_default_22);  to_dtype_543 = conj_physical_default_22 = None
        to_dtype_545 = torch.ops.aten.to.dtype(mul_tensor_926, torch.float32);  mul_tensor_926 = None
        convolution_backward_default_260 = torch.ops.aten.convolution_backward.default(to_dtype_545, silu__default_2, primals_14, [32], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_545 = silu__default_2 = primals_14 = None
        getitem_1704 = convolution_backward_default_260[0]
        getitem_1705 = convolution_backward_default_260[1]
        getitem_1706 = convolution_backward_default_260[2];  convolution_backward_default_260 = None
        to_dtype_546 = torch.ops.aten.to.dtype(getitem_1704, torch.float32);  getitem_1704 = None
        to_dtype_547 = torch.ops.aten.to.dtype(clone_default_2, torch.float32);  clone_default_2 = None
        neg_default_203 = torch.ops.aten.neg.default(to_dtype_547)
        exp_default_127 = torch.ops.aten.exp.default(neg_default_203);  neg_default_203 = None
        add_tensor_637 = torch.ops.aten.add.Tensor(exp_default_127, 1);  exp_default_127 = None
        reciprocal_default_127 = torch.ops.aten.reciprocal.default(add_tensor_637);  add_tensor_637 = None
        mul_tensor_927 = torch.ops.aten.mul.Tensor(reciprocal_default_127, 1);  reciprocal_default_127 = None
        mul_tensor_928 = torch.ops.aten.mul.Tensor(to_dtype_546, mul_tensor_927);  to_dtype_546 = None
        rsub_scalar_150 = torch.ops.aten.rsub.Scalar(mul_tensor_927, 1);  mul_tensor_927 = None
        mul_tensor_929 = torch.ops.aten.mul.Tensor(to_dtype_547, rsub_scalar_150);  to_dtype_547 = rsub_scalar_150 = None
        add_tensor_638 = torch.ops.aten.add.Tensor(mul_tensor_929, 1);  mul_tensor_929 = None
        mul_tensor_930 = torch.ops.aten.mul.Tensor(mul_tensor_928, add_tensor_638);  mul_tensor_928 = add_tensor_638 = None
        to_dtype_548 = torch.ops.aten.to.dtype(mul_tensor_930, torch.float32);  mul_tensor_930 = None
        convolution_backward_default_261 = torch.ops.aten.convolution_backward.default(to_dtype_548, mean_dim, primals_16, [8], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_548 = mean_dim = primals_16 = None
        getitem_1707 = convolution_backward_default_261[0]
        getitem_1708 = convolution_backward_default_261[1]
        getitem_1709 = convolution_backward_default_261[2];  convolution_backward_default_261 = None
        expand_default_86 = torch.ops.aten.expand.default(getitem_1707, [1, 32, 320, 320]);  getitem_1707 = None
        div_scalar_22 = torch.ops.aten.div.Scalar(expand_default_86, 102400);  expand_default_86 = None
        add_tensor_639 = torch.ops.aten.add.Tensor(mul_tensor_924, div_scalar_22);  mul_tensor_924 = div_scalar_22 = None
        to_dtype_549 = torch.ops.aten.to.dtype(add_tensor_639, torch.float32);  add_tensor_639 = None
        to_dtype_550 = torch.ops.aten.to.dtype(clone_default_1, torch.float32);  clone_default_1 = None
        neg_default_204 = torch.ops.aten.neg.default(to_dtype_550)
        exp_default_128 = torch.ops.aten.exp.default(neg_default_204);  neg_default_204 = None
        add_tensor_640 = torch.ops.aten.add.Tensor(exp_default_128, 1);  exp_default_128 = None
        reciprocal_default_128 = torch.ops.aten.reciprocal.default(add_tensor_640);  add_tensor_640 = None
        mul_tensor_931 = torch.ops.aten.mul.Tensor(reciprocal_default_128, 1);  reciprocal_default_128 = None
        mul_tensor_932 = torch.ops.aten.mul.Tensor(to_dtype_549, mul_tensor_931);  to_dtype_549 = None
        rsub_scalar_151 = torch.ops.aten.rsub.Scalar(mul_tensor_931, 1);  mul_tensor_931 = None
        mul_tensor_933 = torch.ops.aten.mul.Tensor(to_dtype_550, rsub_scalar_151);  to_dtype_550 = rsub_scalar_151 = None
        add_tensor_641 = torch.ops.aten.add.Tensor(mul_tensor_933, 1);  mul_tensor_933 = None
        mul_tensor_934 = torch.ops.aten.mul.Tensor(mul_tensor_932, add_tensor_641);  mul_tensor_932 = add_tensor_641 = None
        to_dtype_551 = torch.ops.aten.to.dtype(mul_tensor_934, torch.float32);  mul_tensor_934 = None
        native_batch_norm_backward_default_134 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_551, convolution_default_1, primals_5, primals_3, primals_4, new_zeros_default_3, new_zeros_default_4, False, 0.001, [True, True, True]);  to_dtype_551 = convolution_default_1 = primals_5 = primals_3 = primals_4 = new_zeros_default_3 = new_zeros_default_4 = None
        getitem_1710 = native_batch_norm_backward_default_134[0]
        getitem_1711 = native_batch_norm_backward_default_134[1]
        getitem_1712 = native_batch_norm_backward_default_134[2];  native_batch_norm_backward_default_134 = None
        convolution_backward_default_262 = torch.ops.aten.convolution_backward.default(getitem_1710, silu__default, primals_11, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 32, [True, True, False]);  getitem_1710 = silu__default = primals_11 = None
        getitem_1713 = convolution_backward_default_262[0]
        getitem_1714 = convolution_backward_default_262[1]
        getitem_1715 = convolution_backward_default_262[2];  convolution_backward_default_262 = None
        to_dtype_552 = torch.ops.aten.to.dtype(getitem_1713, torch.float32);  getitem_1713 = None
        to_dtype_553 = torch.ops.aten.to.dtype(clone_default, torch.float32);  clone_default = None
        neg_default_205 = torch.ops.aten.neg.default(to_dtype_553)
        exp_default_129 = torch.ops.aten.exp.default(neg_default_205);  neg_default_205 = None
        add_tensor_642 = torch.ops.aten.add.Tensor(exp_default_129, 1);  exp_default_129 = None
        reciprocal_default_129 = torch.ops.aten.reciprocal.default(add_tensor_642);  add_tensor_642 = None
        mul_tensor_935 = torch.ops.aten.mul.Tensor(reciprocal_default_129, 1);  reciprocal_default_129 = None
        mul_tensor_936 = torch.ops.aten.mul.Tensor(to_dtype_552, mul_tensor_935);  to_dtype_552 = None
        rsub_scalar_152 = torch.ops.aten.rsub.Scalar(mul_tensor_935, 1);  mul_tensor_935 = None
        mul_tensor_937 = torch.ops.aten.mul.Tensor(to_dtype_553, rsub_scalar_152);  to_dtype_553 = rsub_scalar_152 = None
        add_tensor_643 = torch.ops.aten.add.Tensor(mul_tensor_937, 1);  mul_tensor_937 = None
        mul_tensor_938 = torch.ops.aten.mul.Tensor(mul_tensor_936, add_tensor_643);  mul_tensor_936 = add_tensor_643 = None
        to_dtype_554 = torch.ops.aten.to.dtype(mul_tensor_938, torch.float32);  mul_tensor_938 = None
        native_batch_norm_backward_default_135 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_554, convolution_default, primals_499, primals_497, primals_498, new_zeros_default, new_zeros_default_1, False, 0.001, [True, True, True]);  to_dtype_554 = convolution_default = primals_499 = primals_497 = primals_498 = new_zeros_default = new_zeros_default_1 = None
        getitem_1716 = native_batch_norm_backward_default_135[0]
        getitem_1717 = native_batch_norm_backward_default_135[1]
        getitem_1718 = native_batch_norm_backward_default_135[2];  native_batch_norm_backward_default_135 = None
        convolution_backward_default_263 = torch.ops.aten.convolution_backward.default(getitem_1716, constant_pad_nd_default, primals_500, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_1716 = constant_pad_nd_default = primals_500 = None
        getitem_1719 = convolution_backward_default_263[0]
        getitem_1720 = convolution_backward_default_263[1]
        getitem_1721 = convolution_backward_default_263[2];  convolution_backward_default_263 = None
        return [gather_default_2, gather_default, floor_divide_default, remainder_scalar, getitem_1712, None, None, None, getitem_1711, getitem_1700, None, None, None, getitem_1699, getitem_1714, getitem_1702, getitem_1706, getitem_1705, getitem_1709, getitem_1708, getitem_1694, None, None, None, getitem_1693, getitem_1682, None, None, None, getitem_1681, getitem_1696, getitem_1684, getitem_1688, getitem_1687, getitem_1691, getitem_1690, getitem_1676, None, None, None, getitem_1675, getitem_1670, None, None, None, getitem_1669, getitem_1658, None, None, None, getitem_1657, getitem_1672, getitem_1678, getitem_1660, getitem_1664, getitem_1663, getitem_1667, getitem_1666, getitem_1652, None, None, None, getitem_1651, getitem_1646, None, None, None, getitem_1645, getitem_1634, None, None, None, getitem_1633, getitem_1648, getitem_1654, getitem_1636, getitem_1640, getitem_1639, getitem_1643, getitem_1642, getitem_1628, None, None, None, getitem_1627, getitem_1622, None, None, None, getitem_1621, getitem_1610, None, None, None, getitem_1609, getitem_1624, getitem_1630, getitem_1612, getitem_1616, getitem_1615, getitem_1619, getitem_1618, getitem_1604, None, None, None, getitem_1603, getitem_1598, None, None, None, getitem_1597, getitem_1586, None, None, None, getitem_1585, getitem_1600, getitem_1606, getitem_1588, getitem_1592, getitem_1591, getitem_1595, getitem_1594, getitem_1580, None, None, None, getitem_1579, getitem_1574, None, None, None, getitem_1573, getitem_1562, None, None, None, getitem_1561, getitem_1576, getitem_1582, getitem_1564, getitem_1568, getitem_1567, getitem_1571, getitem_1570, getitem_1556, None, None, None, getitem_1555, getitem_1550, None, None, None, getitem_1549, getitem_1538, None, None, None, getitem_1537, getitem_1552, getitem_1558, getitem_1540, getitem_1544, getitem_1543, getitem_1547, getitem_1546, getitem_1532, None, None, None, getitem_1531, getitem_1526, None, None, None, getitem_1525, getitem_1514, None, None, None, getitem_1513, getitem_1528, getitem_1534, getitem_1516, getitem_1520, getitem_1519, getitem_1523, getitem_1522, getitem_1508, None, None, None, getitem_1507, getitem_1502, None, None, None, getitem_1501, getitem_1490, None, None, None, getitem_1489, getitem_1504, getitem_1510, getitem_1492, getitem_1496, getitem_1495, getitem_1499, getitem_1498, getitem_1484, None, None, None, getitem_1483, getitem_1478, None, None, None, getitem_1477, getitem_1466, None, None, None, getitem_1465, getitem_1480, getitem_1486, getitem_1468, getitem_1472, getitem_1471, getitem_1475, getitem_1474, getitem_1460, None, None, None, getitem_1459, getitem_1454, None, None, None, getitem_1453, getitem_1442, None, None, None, getitem_1441, getitem_1456, getitem_1462, getitem_1444, getitem_1448, getitem_1447, getitem_1451, getitem_1450, getitem_1436, None, None, None, getitem_1435, getitem_1430, None, None, None, getitem_1429, getitem_1418, None, None, None, getitem_1417, getitem_1432, getitem_1438, getitem_1420, getitem_1424, getitem_1423, getitem_1427, getitem_1426, getitem_1412, None, None, None, getitem_1411, getitem_1406, None, None, None, getitem_1405, getitem_1394, None, None, None, getitem_1393, getitem_1408, getitem_1414, getitem_1396, getitem_1400, getitem_1399, getitem_1403, getitem_1402, getitem_1388, None, None, None, getitem_1387, getitem_1382, None, None, None, getitem_1381, getitem_1370, None, None, None, getitem_1369, getitem_1384, getitem_1390, getitem_1372, getitem_1376, getitem_1375, getitem_1379, getitem_1378, getitem_1364, None, None, None, getitem_1363, getitem_1358, None, None, None, getitem_1357, getitem_1346, None, None, None, getitem_1345, getitem_1360, getitem_1366, getitem_1348, getitem_1352, getitem_1351, getitem_1355, getitem_1354, getitem_1340, None, None, None, getitem_1339, getitem_1334, None, None, None, getitem_1333, getitem_1322, None, None, None, getitem_1321, getitem_1336, getitem_1342, getitem_1324, getitem_1328, getitem_1327, getitem_1331, getitem_1330, getitem_1316, None, None, None, getitem_1315, getitem_1310, None, None, None, getitem_1309, getitem_1298, None, None, None, getitem_1297, getitem_1312, getitem_1318, getitem_1300, getitem_1304, getitem_1303, getitem_1307, getitem_1306, getitem_1292, None, None, None, getitem_1291, getitem_1286, None, None, None, getitem_1285, getitem_1274, None, None, None, getitem_1273, getitem_1288, getitem_1294, getitem_1276, getitem_1280, getitem_1279, getitem_1283, getitem_1282, getitem_1268, None, None, None, getitem_1267, getitem_1262, None, None, None, getitem_1261, getitem_1250, None, None, None, getitem_1249, getitem_1264, getitem_1270, getitem_1252, getitem_1256, getitem_1255, getitem_1259, getitem_1258, getitem_1244, None, None, None, getitem_1243, getitem_1238, None, None, None, getitem_1237, getitem_1226, None, None, None, getitem_1225, getitem_1240, getitem_1246, getitem_1228, getitem_1232, getitem_1231, getitem_1235, getitem_1234, getitem_1220, None, None, None, getitem_1219, getitem_1214, None, None, None, getitem_1213, getitem_1202, None, None, None, getitem_1201, getitem_1216, getitem_1222, getitem_1204, getitem_1208, getitem_1207, getitem_1211, getitem_1210, getitem_1196, None, None, None, getitem_1195, getitem_1190, None, None, None, getitem_1189, getitem_1178, None, None, None, getitem_1177, getitem_1192, getitem_1198, getitem_1180, getitem_1184, getitem_1183, getitem_1187, getitem_1186, getitem_1718, None, None, None, getitem_1717, getitem_1720, add_tensor_153, add_tensor_152, add_tensor_151, add_tensor_148, add_tensor_147, add_tensor_146, add_tensor_143, add_tensor_142, add_tensor_141, add_tensor_138, add_tensor_137, add_tensor_136, add_tensor_236, add_tensor_234, add_tensor_233, add_tensor_230, add_tensor_229, add_tensor_228, add_tensor_225, add_tensor_224, add_tensor_223, add_tensor_220, add_tensor_219, add_tensor_218, getitem_1161, None, None, None, getitem_1160, getitem_1166, getitem_1164, getitem_1163, to_dtype_281, getitem_1144, None, None, None, getitem_1143, getitem_1149, getitem_1147, getitem_1146, to_dtype_275, getitem_1155, None, None, None, getitem_1154, getitem_1158, getitem_1157, getitem_1127, None, None, None, getitem_1126, getitem_1132, getitem_1130, getitem_1129, to_dtype_269, getitem_1138, None, None, None, getitem_1137, getitem_1141, getitem_1140, getitem_1110, None, None, None, getitem_1109, getitem_1115, getitem_1113, getitem_1112, to_dtype_263, getitem_1121, None, None, None, getitem_1120, getitem_1124, getitem_1123, getitem_1092, None, None, None, getitem_1091, getitem_1097, getitem_1095, getitem_1094, to_dtype_257, getitem_1104, None, None, None, getitem_1103, getitem_1107, getitem_1106, getitem_1074, None, None, None, getitem_1073, getitem_1079, getitem_1077, getitem_1076, to_dtype_251, getitem_1086, None, None, None, getitem_1085, getitem_1089, getitem_1088, getitem_1062, None, None, None, getitem_1061, getitem_1067, getitem_1065, getitem_1064, to_dtype_245, getitem_1051, None, None, None, getitem_1050, getitem_1056, getitem_1054, getitem_1053, to_dtype_239, getitem_1040, None, None, None, getitem_1039, getitem_1045, getitem_1043, getitem_1042, to_dtype_233, getitem_1029, None, None, None, getitem_1028, getitem_1034, getitem_1032, getitem_1031, to_dtype_227, getitem_1018, None, None, None, getitem_1017, getitem_1023, getitem_1021, getitem_1020, to_dtype_221, getitem_1007, None, None, None, getitem_1006, getitem_1012, getitem_1010, getitem_1009, to_dtype_215, getitem_995, None, None, None, getitem_994, getitem_1000, getitem_998, getitem_997, to_dtype_209, getitem_983, None, None, None, getitem_982, getitem_988, getitem_986, getitem_985, to_dtype_203, getitem_971, None, None, None, getitem_970, getitem_976, getitem_974, getitem_973, to_dtype_197, getitem_960, None, None, None, getitem_959, getitem_965, getitem_963, getitem_962, to_dtype_191, getitem_949, None, None, None, getitem_948, getitem_954, getitem_952, getitem_951, to_dtype_185, getitem_938, None, None, None, getitem_937, getitem_943, getitem_941, getitem_940, to_dtype_179, getitem_927, None, None, None, getitem_926, getitem_932, getitem_930, getitem_929, to_dtype_173, getitem_916, None, None, None, getitem_915, getitem_921, getitem_919, getitem_918, to_dtype_167, getitem_904, None, None, None, getitem_903, getitem_909, getitem_907, getitem_906, to_dtype_161, getitem_892, None, None, None, getitem_891, getitem_897, getitem_895, getitem_894, to_dtype_155, getitem_880, None, None, None, getitem_879, getitem_885, getitem_883, getitem_882, to_dtype_149, getitem_869, None, None, None, getitem_868, getitem_874, getitem_872, getitem_871, to_dtype_143, getitem_858, None, None, None, getitem_857, getitem_863, getitem_861, getitem_860, to_dtype_137, getitem_847, None, None, None, getitem_846, getitem_852, getitem_850, getitem_849, to_dtype_131, getitem_836, None, None, None, getitem_835, getitem_841, getitem_839, getitem_838, to_dtype_125, getitem_825, None, None, None, getitem_824, getitem_830, getitem_828, getitem_827, to_dtype_119, getitem_813, None, None, None, getitem_812, getitem_818, getitem_816, getitem_815, to_dtype_113, getitem_801, None, None, None, getitem_800, getitem_806, getitem_804, getitem_803, to_dtype_107, getitem_789, None, None, None, getitem_788, getitem_794, getitem_792, getitem_791, to_dtype_101, getitem_778, None, None, None, getitem_777, getitem_783, getitem_781, getitem_780, to_dtype_95, getitem_1172, None, None, None, getitem_1171, getitem_1175, getitem_1174, getitem_769, None, None, None, getitem_768, getitem_760, None, None, None, getitem_759, getitem_751, None, None, None, getitem_750, getitem_604, None, None, None, getitem_603, getitem_595, None, None, None, getitem_594, getitem_586, None, None, None, getitem_585, getitem_736, None, None, None, getitem_735, getitem_727, None, None, None, getitem_726, getitem_718, None, None, None, getitem_717, getitem_571, None, None, None, getitem_570, getitem_562, None, None, None, getitem_561, getitem_553, None, None, None, getitem_552, getitem_703, None, None, None, getitem_702, getitem_694, None, None, None, getitem_693, getitem_685, None, None, None, getitem_684, getitem_538, None, None, None, getitem_537, getitem_529, None, None, None, getitem_528, getitem_520, None, None, None, getitem_519, getitem_670, None, None, None, getitem_669, getitem_661, None, None, None, getitem_660, getitem_652, None, None, None, getitem_651, getitem_505, None, None, None, getitem_504, getitem_496, None, None, None, getitem_495, getitem_487, None, None, None, getitem_486, getitem_637, None, None, None, getitem_636, getitem_628, None, None, None, getitem_627, getitem_619, None, None, None, getitem_618, getitem_472, None, None, None, getitem_471, getitem_463, None, None, None, getitem_462, getitem_454, None, None, None, getitem_453, None]
        
