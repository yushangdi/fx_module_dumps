
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/mobilenet_v3_large/mobilenet_v3_large_backward_0/state_dict.pt'))

    
    
    def forward(self, getitem_54, primals_218, convolution_default_18, convolution_default_24, primals_219, primals_220, primals_221, mul_tensor_1, to_dtype_3, primals_235, convolution_default_9, primals_224, convolution_default_19, primals_225, relu__default_5, add__tensor_2, primals_226, convolution_default_10, primals_228, primals_230, hardswish__default_1, primals_231, convolution_default_1, convolution_default, relu__default_6, primals_234, convolution_default_25, mean_dim, relu__default_9, convolution_default_20, primals_236, primals_237, getitem_57, primals_280, primals_281, primals_110, primals_111, convolution_default_51, primals_175, primals_282, getitem_117, primals_116, primals_283, primals_162, primals_298, primals_163, primals_114, primals_292, primals_286, primals_293, primals_101, primals_117, primals_287, primals_294, primals_166, primals_108, primals_288, primals_115, primals_289, hardswish__default_15, primals_174, primals_301, primals_168, primals_173, primals_104, primals_105, convolution_default_52, primals_106, primals_300, primals_172, primals_160, getitem_120, primals_305, primals_167, primals_295, mean_dim_6, primals_161, primals_304, primals_169, primals_299, getitem, primals_100, primals_191, hardswish__default_8, primals_179, primals_184, primals_181, convolution_default_36, primals_186, primals_193, primals_196, primals_192, primals_178, primals_185, getitem_90, convolution_default_37, primals_180, primals_187, primals_190, primals_48, primals_155, relu__default_1, primals_42, primals_149, primals_313, convolution_default_4, primals_148, convolution_default_57, primals_45, primals_151, primals_51, primals_150, primals_49, primals_50, hardswish__default_17, getitem_129, primals_154, t_default, getitem_126, primals_144, view_default, primals_55, primals_54, relu__default_2, convolution_default_5, primals_57, addmm_default, mean_dim_7, primals_156, primals_40, primals_44, primals_39, getitem_15, hardswish__default_20, primals_143, hardswish__default_18, primals_142, primals_38, t_default_1, primals_56, primals_145, primals_157, convolution_default_6, getitem_81, convolution_default_33, convolution_default_12, hardswish__default_3, relu__default_3, convolution_default_30, relu_default, relu__default_4, convolution_default_13, hardswish__default_4, getitem_66, mul_tensor, convolution_default_7, to_dtype_1, add__tensor_1, hardswish__default_7, convolution_default_29, add__tensor_4, convolution_default_14, getitem_33, convolution_default_34, add__tensor_6, convolution_default_35, convolution_default_8, getitem_84, primals_259, relu__default_7, hardswish__default_9, primals_98, hardswish__default, convolution_default_15, primals_262, primals_263, primals_94, primals_264, primals_92, primals_265, relu__default, convolution_default_42, mean_dim_3, primals_84, primals_95, primals_93, primals_89, primals_268, hardswish__default_10, primals_269, convolution_default_2, getitem_93, primals_270, relu__default_8, primals_99, primals_271, primals_88, add__tensor, convolution_default_17, primals_79, primals_274, convolution_default_3, primals_275, mean_dim_1, primals_276, relu_default_3, primals_277, convolution_default_39, primals_83, primals_86, primals_82, relu_default_1, mul_tensor_3, getitem_102, convolution_default_59, primals_312, primals_35, primals_21, primals_240, mean_dim_5, primals_306, primals_15, relu_default_7, primals_32, primals_22, primals_241, primals_311, convolution_default_31, hardswish__default_14, primals_242, mean_dim_4, primals_247, primals_243, hardswish__default_12, hardswish__default_5, primals_8, primals_310, getitem_75, convolution_default_49, mul_tensor_7, primals_20, primals_307, to_dtype_15, primals_246, getitem_72, convolution_default_61, relu_default_5, primals_28, primals_5, primals_248, primals_10, add__tensor_5, primals_29, primals_34, primals_23, primals_250, convolution_default_60, add__tensor_9, convolution_default_44, convolution_default_50, primals_9, getitem_135, primals_252, relu_default_4, primals_27, primals_257, primals_253, primals_11, convolution_default_45, add__tensor_7, to_dtype_11, primals_26, hardswish__default_6, mul_tensor_5, primals_16, mul_tensor_4, getitem_114, primals_17, primals_256, primals_14, primals_33, primals_258, convolution_default_32, to_dtype_9, primals_122, getitem_108, primals_60, primals_138, getitem_96, relu__default_10, mean_dim_2, convolution_default_46, hardswish__default_16, primals_76, primals_204, primals_137, to_dtype_7, primals_67, convolution_default_40, primals_66, convolution_default_26, primals_136, primals_203, hardswish__default_2, primals_120, primals_202, convolution_default_54, convolution_default_41, primals_73, relu_default_6, primals_121, getitem_60, primals_133, convolution_default_27, convolution_default_56, primals_132, primals_206, primals_212, primals_139, primals_208, getitem_63, mul_tensor_6, convolution_default_55, primals_130, getitem_99, to_dtype_13, primals_70, primals_128, primals_71, primals_62, convolution_default_22, primals_127, primals_197, hardswish__default_13, primals_209, primals_199, primals_78, relu_default_2, primals_215, primals_77, add__tensor_8, primals_126, primals_214, convolution_default_23, primals_64, primals_213, add__tensor_3, hardswish__default_11, convolution_default_28, mul_tensor_2, convolution_default_47, primals_72, primals_198, primals_61, primals_123, getitem_111, to_dtype_5, tangents_1):
        new_zeros_default = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        clone_default = torch.ops.aten.clone.default(getitem);  getitem = None
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_9 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_10 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_12 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_13 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_15 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_16 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_18 = torch.ops.aten.new_zeros.default(convolution_default_6, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_19 = torch.ops.aten.new_zeros.default(convolution_default_6, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_21 = torch.ops.aten.new_zeros.default(convolution_default_7, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_22 = torch.ops.aten.new_zeros.default(convolution_default_7, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_24 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_25 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_27 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_28 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_30 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_31 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_33 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_34 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_36 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_37 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_39 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_40 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_42 = torch.ops.aten.new_zeros.default(convolution_default_18, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_43 = torch.ops.aten.new_zeros.default(convolution_default_18, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_45 = torch.ops.aten.new_zeros.default(convolution_default_19, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_46 = torch.ops.aten.new_zeros.default(convolution_default_19, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_48 = torch.ops.aten.new_zeros.default(convolution_default_20, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_49 = torch.ops.aten.new_zeros.default(convolution_default_20, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_51 = torch.ops.aten.new_zeros.default(convolution_default_23, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_52 = torch.ops.aten.new_zeros.default(convolution_default_23, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_54 = torch.ops.aten.new_zeros.default(convolution_default_24, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_55 = torch.ops.aten.new_zeros.default(convolution_default_24, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        clone_default_1 = torch.ops.aten.clone.default(getitem_54);  getitem_54 = None
        new_zeros_default_57 = torch.ops.aten.new_zeros.default(convolution_default_25, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_58 = torch.ops.aten.new_zeros.default(convolution_default_25, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        clone_default_2 = torch.ops.aten.clone.default(getitem_57);  getitem_57 = None
        new_zeros_default_60 = torch.ops.aten.new_zeros.default(convolution_default_26, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_61 = torch.ops.aten.new_zeros.default(convolution_default_26, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_63 = torch.ops.aten.new_zeros.default(convolution_default_27, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_64 = torch.ops.aten.new_zeros.default(convolution_default_27, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        clone_default_3 = torch.ops.aten.clone.default(getitem_63);  getitem_63 = None
        new_zeros_default_66 = torch.ops.aten.new_zeros.default(convolution_default_28, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_67 = torch.ops.aten.new_zeros.default(convolution_default_28, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        clone_default_4 = torch.ops.aten.clone.default(getitem_66);  getitem_66 = None
        new_zeros_default_69 = torch.ops.aten.new_zeros.default(convolution_default_29, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_70 = torch.ops.aten.new_zeros.default(convolution_default_29, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_72 = torch.ops.aten.new_zeros.default(convolution_default_30, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_73 = torch.ops.aten.new_zeros.default(convolution_default_30, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        clone_default_5 = torch.ops.aten.clone.default(getitem_72);  getitem_72 = None
        new_zeros_default_75 = torch.ops.aten.new_zeros.default(convolution_default_31, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_76 = torch.ops.aten.new_zeros.default(convolution_default_31, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        clone_default_6 = torch.ops.aten.clone.default(getitem_75);  getitem_75 = None
        new_zeros_default_78 = torch.ops.aten.new_zeros.default(convolution_default_32, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_79 = torch.ops.aten.new_zeros.default(convolution_default_32, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_81 = torch.ops.aten.new_zeros.default(convolution_default_33, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_82 = torch.ops.aten.new_zeros.default(convolution_default_33, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        clone_default_7 = torch.ops.aten.clone.default(getitem_81);  getitem_81 = None
        new_zeros_default_84 = torch.ops.aten.new_zeros.default(convolution_default_34, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_85 = torch.ops.aten.new_zeros.default(convolution_default_34, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        clone_default_8 = torch.ops.aten.clone.default(getitem_84);  getitem_84 = None
        new_zeros_default_87 = torch.ops.aten.new_zeros.default(convolution_default_35, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_88 = torch.ops.aten.new_zeros.default(convolution_default_35, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_90 = torch.ops.aten.new_zeros.default(convolution_default_36, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_91 = torch.ops.aten.new_zeros.default(convolution_default_36, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        clone_default_9 = torch.ops.aten.clone.default(getitem_90);  getitem_90 = None
        new_zeros_default_93 = torch.ops.aten.new_zeros.default(convolution_default_37, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_94 = torch.ops.aten.new_zeros.default(convolution_default_37, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        clone_default_10 = torch.ops.aten.clone.default(getitem_93);  getitem_93 = None
        new_zeros_default_96 = torch.ops.aten.new_zeros.default(convolution_default_40, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_97 = torch.ops.aten.new_zeros.default(convolution_default_40, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_99 = torch.ops.aten.new_zeros.default(convolution_default_41, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_100 = torch.ops.aten.new_zeros.default(convolution_default_41, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        clone_default_11 = torch.ops.aten.clone.default(getitem_99);  getitem_99 = None
        new_zeros_default_102 = torch.ops.aten.new_zeros.default(convolution_default_42, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_103 = torch.ops.aten.new_zeros.default(convolution_default_42, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        clone_default_12 = torch.ops.aten.clone.default(getitem_102);  getitem_102 = None
        new_zeros_default_105 = torch.ops.aten.new_zeros.default(convolution_default_45, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_106 = torch.ops.aten.new_zeros.default(convolution_default_45, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_108 = torch.ops.aten.new_zeros.default(convolution_default_46, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_109 = torch.ops.aten.new_zeros.default(convolution_default_46, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        clone_default_13 = torch.ops.aten.clone.default(getitem_108);  getitem_108 = None
        new_zeros_default_111 = torch.ops.aten.new_zeros.default(convolution_default_47, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_112 = torch.ops.aten.new_zeros.default(convolution_default_47, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        clone_default_14 = torch.ops.aten.clone.default(getitem_111);  getitem_111 = None
        new_zeros_default_114 = torch.ops.aten.new_zeros.default(convolution_default_50, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_115 = torch.ops.aten.new_zeros.default(convolution_default_50, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_117 = torch.ops.aten.new_zeros.default(convolution_default_51, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_118 = torch.ops.aten.new_zeros.default(convolution_default_51, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        clone_default_15 = torch.ops.aten.clone.default(getitem_117);  getitem_117 = None
        new_zeros_default_120 = torch.ops.aten.new_zeros.default(convolution_default_52, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_121 = torch.ops.aten.new_zeros.default(convolution_default_52, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        clone_default_16 = torch.ops.aten.clone.default(getitem_120);  getitem_120 = None
        new_zeros_default_123 = torch.ops.aten.new_zeros.default(convolution_default_55, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_124 = torch.ops.aten.new_zeros.default(convolution_default_55, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_126 = torch.ops.aten.new_zeros.default(convolution_default_56, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_127 = torch.ops.aten.new_zeros.default(convolution_default_56, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        clone_default_17 = torch.ops.aten.clone.default(getitem_126);  getitem_126 = None
        new_zeros_default_129 = torch.ops.aten.new_zeros.default(convolution_default_57, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_130 = torch.ops.aten.new_zeros.default(convolution_default_57, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        clone_default_18 = torch.ops.aten.clone.default(getitem_129);  getitem_129 = None
        new_zeros_default_132 = torch.ops.aten.new_zeros.default(convolution_default_60, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_133 = torch.ops.aten.new_zeros.default(convolution_default_60, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_135 = torch.ops.aten.new_zeros.default(convolution_default_61, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_136 = torch.ops.aten.new_zeros.default(convolution_default_61, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        clone_default_19 = torch.ops.aten.clone.default(getitem_135);  getitem_135 = None
        clone_default_20 = torch.ops.aten.clone.default(addmm_default);  addmm_default = None
        t_default_2 = torch.ops.aten.t.default(t_default_1);  t_default_1 = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_2);  t_default_2 = None
        t_default_3 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_3, hardswish__default_20);  t_default_3 = hardswish__default_20 = None
        t_default_4 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_1 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_5 = torch.ops.aten.t.default(t_default_4);  t_default_4 = None
        to_dtype_16 = torch.ops.aten.to.dtype(mm_default, torch.float32);  mm_default = None
        to_dtype_17 = torch.ops.aten.to.dtype(clone_default_20, torch.float32);  clone_default_20 = None
        lt_scalar = torch.ops.aten.lt.Scalar(to_dtype_17, -3)
        new_zeros_default_138 = torch.ops.aten.new_zeros.default(to_dtype_16, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_17, 3)
        div_tensor_8 = torch.ops.aten.div.Tensor(to_dtype_17, 3);  to_dtype_17 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(div_tensor_8, 0.5);  div_tensor_8 = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(to_dtype_16, add_tensor_8);  add_tensor_8 = None
        where_self = torch.ops.aten.where.self(le_scalar, mul_tensor_8, to_dtype_16);  le_scalar = mul_tensor_8 = to_dtype_16 = None
        where_self_1 = torch.ops.aten.where.self(lt_scalar, new_zeros_default_138, where_self);  lt_scalar = new_zeros_default_138 = where_self = None
        to_dtype_18 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        t_default_6 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default_2 = torch.ops.aten.mm.default(to_dtype_18, t_default_6);  t_default_6 = None
        t_default_7 = torch.ops.aten.t.default(to_dtype_18)
        mm_default_3 = torch.ops.aten.mm.default(t_default_7, view_default);  t_default_7 = view_default = None
        t_default_8 = torch.ops.aten.t.default(mm_default_3);  mm_default_3 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(to_dtype_18, [0], True);  to_dtype_18 = None
        view_default_2 = torch.ops.aten.view.default(sum_dim_int_list_1, [1280]);  sum_dim_int_list_1 = None
        t_default_9 = torch.ops.aten.t.default(t_default_8);  t_default_8 = None
        view_default_3 = torch.ops.aten.view.default(mm_default_2, [32, 960, 1, 1]);  mm_default_2 = None
        expand_default = torch.ops.aten.expand.default(view_default_3, [32, 960, 7, 7]);  view_default_3 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 49);  expand_default = None
        to_dtype_19 = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_20 = torch.ops.aten.to.dtype(clone_default_19, torch.float32);  clone_default_19 = None
        lt_scalar_1 = torch.ops.aten.lt.Scalar(to_dtype_20, -3)
        new_zeros_default_139 = torch.ops.aten.new_zeros.default(to_dtype_19, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_20, 3)
        div_tensor_9 = torch.ops.aten.div.Tensor(to_dtype_20, 3);  to_dtype_20 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(div_tensor_9, 0.5);  div_tensor_9 = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(to_dtype_19, add_tensor_9);  add_tensor_9 = None
        where_self_2 = torch.ops.aten.where.self(le_scalar_1, mul_tensor_9, to_dtype_19);  le_scalar_1 = mul_tensor_9 = to_dtype_19 = None
        where_self_3 = torch.ops.aten.where.self(lt_scalar_1, new_zeros_default_139, where_self_2);  lt_scalar_1 = new_zeros_default_139 = where_self_2 = None
        to_dtype_21 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_21, convolution_default_61, primals_144, primals_142, primals_143, new_zeros_default_135, new_zeros_default_136, False, 0.001, [True, True, True]);  to_dtype_21 = convolution_default_61 = primals_144 = primals_142 = primals_143 = new_zeros_default_135 = new_zeros_default_136 = None
        getitem_138 = native_batch_norm_backward_default[0]
        getitem_139 = native_batch_norm_backward_default[1]
        getitem_140 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(getitem_138, add__tensor_9, primals_139, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_138 = add__tensor_9 = primals_139 = None
        getitem_141 = convolution_backward_default[0]
        getitem_142 = convolution_backward_default[1];  convolution_backward_default = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(getitem_141, convolution_default_60, primals_138, primals_136, primals_137, new_zeros_default_132, new_zeros_default_133, False, 0.001, [True, True, True]);  convolution_default_60 = primals_138 = primals_136 = primals_137 = new_zeros_default_132 = new_zeros_default_133 = None
        getitem_144 = native_batch_norm_backward_default_1[0]
        getitem_145 = native_batch_norm_backward_default_1[1]
        getitem_146 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_144, mul_tensor_7, primals_133, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_144 = mul_tensor_7 = primals_133 = None
        getitem_147 = convolution_backward_default_1[0]
        getitem_148 = convolution_backward_default_1[1];  convolution_backward_default_1 = None
        mul_tensor_10 = torch.ops.aten.mul.Tensor(getitem_147, to_dtype_15);  to_dtype_15 = None
        mul_tensor_11 = torch.ops.aten.mul.Tensor(getitem_147, hardswish__default_18);  getitem_147 = hardswish__default_18 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(mul_tensor_11, [2, 3], True);  mul_tensor_11 = None
        to_dtype_22 = torch.ops.aten.to.dtype(sum_dim_int_list_2, torch.float32);  sum_dim_int_list_2 = None
        to_dtype_23 = torch.ops.aten.to.dtype(convolution_default_59, torch.float32);  convolution_default_59 = None
        gt_scalar = torch.ops.aten.gt.Scalar(to_dtype_23, -3.0)
        lt_scalar_2 = torch.ops.aten.lt.Scalar(to_dtype_23, 3.0);  to_dtype_23 = None
        __and___tensor = torch.ops.aten.__and__.Tensor(gt_scalar, lt_scalar_2);  gt_scalar = lt_scalar_2 = None
        mul_tensor_12 = torch.ops.aten.mul.Tensor(to_dtype_22, 0.16666666666666666)
        new_zeros_default_140 = torch.ops.aten.new_zeros.default(to_dtype_22, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False);  to_dtype_22 = None
        where_self_4 = torch.ops.aten.where.self(__and___tensor, mul_tensor_12, new_zeros_default_140);  __and___tensor = mul_tensor_12 = new_zeros_default_140 = None
        to_dtype_24 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(to_dtype_24, relu_default_7, primals_132, [960], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_24 = primals_132 = None
        getitem_150 = convolution_backward_default_2[0]
        getitem_151 = convolution_backward_default_2[1]
        getitem_152 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        to_dtype_25 = torch.ops.aten.to.dtype(getitem_150, torch.float32);  getitem_150 = None
        to_dtype_26 = torch.ops.aten.to.dtype(relu_default_7, torch.float32);  relu_default_7 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_26, 0);  to_dtype_26 = None
        new_zeros_default_141 = torch.ops.aten.new_zeros.default(to_dtype_25, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_141, to_dtype_25);  le_scalar_2 = new_zeros_default_141 = to_dtype_25 = None
        to_dtype_27 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(to_dtype_27, mean_dim_7, primals_130, [240], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_27 = mean_dim_7 = primals_130 = None
        getitem_153 = convolution_backward_default_3[0]
        getitem_154 = convolution_backward_default_3[1]
        getitem_155 = convolution_backward_default_3[2];  convolution_backward_default_3 = None
        expand_default_1 = torch.ops.aten.expand.default(getitem_153, [32, 960, 7, 7]);  getitem_153 = None
        div_scalar_1 = torch.ops.aten.div.Scalar(expand_default_1, 49);  expand_default_1 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(mul_tensor_10, div_scalar_1);  mul_tensor_10 = div_scalar_1 = None
        to_dtype_28 = torch.ops.aten.to.dtype(add_tensor_10, torch.float32);  add_tensor_10 = None
        to_dtype_29 = torch.ops.aten.to.dtype(clone_default_18, torch.float32);  clone_default_18 = None
        lt_scalar_3 = torch.ops.aten.lt.Scalar(to_dtype_29, -3)
        new_zeros_default_142 = torch.ops.aten.new_zeros.default(to_dtype_28, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_29, 3)
        div_tensor_10 = torch.ops.aten.div.Tensor(to_dtype_29, 3);  to_dtype_29 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(div_tensor_10, 0.5);  div_tensor_10 = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(to_dtype_28, add_tensor_11);  add_tensor_11 = None
        where_self_6 = torch.ops.aten.where.self(le_scalar_3, mul_tensor_13, to_dtype_28);  le_scalar_3 = mul_tensor_13 = to_dtype_28 = None
        where_self_7 = torch.ops.aten.where.self(lt_scalar_3, new_zeros_default_142, where_self_6);  lt_scalar_3 = new_zeros_default_142 = where_self_6 = None
        to_dtype_30 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_30, convolution_default_57, primals_128, primals_126, primals_127, new_zeros_default_129, new_zeros_default_130, False, 0.001, [True, True, True]);  to_dtype_30 = convolution_default_57 = primals_128 = primals_126 = primals_127 = new_zeros_default_129 = new_zeros_default_130 = None
        getitem_156 = native_batch_norm_backward_default_2[0]
        getitem_157 = native_batch_norm_backward_default_2[1]
        getitem_158 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_156, hardswish__default_17, primals_123, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 960, [True, True, False]);  getitem_156 = hardswish__default_17 = primals_123 = None
        getitem_159 = convolution_backward_default_4[0]
        getitem_160 = convolution_backward_default_4[1];  convolution_backward_default_4 = None
        to_dtype_31 = torch.ops.aten.to.dtype(getitem_159, torch.float32);  getitem_159 = None
        to_dtype_32 = torch.ops.aten.to.dtype(clone_default_17, torch.float32);  clone_default_17 = None
        lt_scalar_4 = torch.ops.aten.lt.Scalar(to_dtype_32, -3)
        new_zeros_default_143 = torch.ops.aten.new_zeros.default(to_dtype_31, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_32, 3)
        div_tensor_11 = torch.ops.aten.div.Tensor(to_dtype_32, 3);  to_dtype_32 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(div_tensor_11, 0.5);  div_tensor_11 = None
        mul_tensor_14 = torch.ops.aten.mul.Tensor(to_dtype_31, add_tensor_12);  add_tensor_12 = None
        where_self_8 = torch.ops.aten.where.self(le_scalar_4, mul_tensor_14, to_dtype_31);  le_scalar_4 = mul_tensor_14 = to_dtype_31 = None
        where_self_9 = torch.ops.aten.where.self(lt_scalar_4, new_zeros_default_143, where_self_8);  lt_scalar_4 = new_zeros_default_143 = where_self_8 = None
        to_dtype_33 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_33, convolution_default_56, primals_122, primals_120, primals_121, new_zeros_default_126, new_zeros_default_127, False, 0.001, [True, True, True]);  to_dtype_33 = convolution_default_56 = primals_122 = primals_120 = primals_121 = new_zeros_default_126 = new_zeros_default_127 = None
        getitem_162 = native_batch_norm_backward_default_3[0]
        getitem_163 = native_batch_norm_backward_default_3[1]
        getitem_164 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_162, add__tensor_8, primals_117, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_162 = add__tensor_8 = primals_117 = None
        getitem_165 = convolution_backward_default_5[0]
        getitem_166 = convolution_backward_default_5[1];  convolution_backward_default_5 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(getitem_141, getitem_165);  getitem_141 = getitem_165 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_13, convolution_default_55, primals_116, primals_114, primals_115, new_zeros_default_123, new_zeros_default_124, False, 0.001, [True, True, True]);  convolution_default_55 = primals_116 = primals_114 = primals_115 = new_zeros_default_123 = new_zeros_default_124 = None
        getitem_168 = native_batch_norm_backward_default_4[0]
        getitem_169 = native_batch_norm_backward_default_4[1]
        getitem_170 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(getitem_168, mul_tensor_6, primals_111, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_168 = mul_tensor_6 = primals_111 = None
        getitem_171 = convolution_backward_default_6[0]
        getitem_172 = convolution_backward_default_6[1];  convolution_backward_default_6 = None
        mul_tensor_15 = torch.ops.aten.mul.Tensor(getitem_171, to_dtype_13);  to_dtype_13 = None
        mul_tensor_16 = torch.ops.aten.mul.Tensor(getitem_171, hardswish__default_16);  getitem_171 = hardswish__default_16 = None
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(mul_tensor_16, [2, 3], True);  mul_tensor_16 = None
        to_dtype_34 = torch.ops.aten.to.dtype(sum_dim_int_list_3, torch.float32);  sum_dim_int_list_3 = None
        to_dtype_35 = torch.ops.aten.to.dtype(convolution_default_54, torch.float32);  convolution_default_54 = None
        gt_scalar_1 = torch.ops.aten.gt.Scalar(to_dtype_35, -3.0)
        lt_scalar_5 = torch.ops.aten.lt.Scalar(to_dtype_35, 3.0);  to_dtype_35 = None
        __and___tensor_1 = torch.ops.aten.__and__.Tensor(gt_scalar_1, lt_scalar_5);  gt_scalar_1 = lt_scalar_5 = None
        mul_tensor_17 = torch.ops.aten.mul.Tensor(to_dtype_34, 0.16666666666666666)
        new_zeros_default_144 = torch.ops.aten.new_zeros.default(to_dtype_34, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False);  to_dtype_34 = None
        where_self_10 = torch.ops.aten.where.self(__and___tensor_1, mul_tensor_17, new_zeros_default_144);  __and___tensor_1 = mul_tensor_17 = new_zeros_default_144 = None
        to_dtype_36 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(to_dtype_36, relu_default_6, primals_110, [960], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_36 = primals_110 = None
        getitem_174 = convolution_backward_default_7[0]
        getitem_175 = convolution_backward_default_7[1]
        getitem_176 = convolution_backward_default_7[2];  convolution_backward_default_7 = None
        to_dtype_37 = torch.ops.aten.to.dtype(getitem_174, torch.float32);  getitem_174 = None
        to_dtype_38 = torch.ops.aten.to.dtype(relu_default_6, torch.float32);  relu_default_6 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_38, 0);  to_dtype_38 = None
        new_zeros_default_145 = torch.ops.aten.new_zeros.default(to_dtype_37, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_145, to_dtype_37);  le_scalar_5 = new_zeros_default_145 = to_dtype_37 = None
        to_dtype_39 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(to_dtype_39, mean_dim_6, primals_108, [240], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_39 = mean_dim_6 = primals_108 = None
        getitem_177 = convolution_backward_default_8[0]
        getitem_178 = convolution_backward_default_8[1]
        getitem_179 = convolution_backward_default_8[2];  convolution_backward_default_8 = None
        expand_default_2 = torch.ops.aten.expand.default(getitem_177, [32, 960, 7, 7]);  getitem_177 = None
        div_scalar_2 = torch.ops.aten.div.Scalar(expand_default_2, 49);  expand_default_2 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(mul_tensor_15, div_scalar_2);  mul_tensor_15 = div_scalar_2 = None
        to_dtype_40 = torch.ops.aten.to.dtype(add_tensor_14, torch.float32);  add_tensor_14 = None
        to_dtype_41 = torch.ops.aten.to.dtype(clone_default_16, torch.float32);  clone_default_16 = None
        lt_scalar_6 = torch.ops.aten.lt.Scalar(to_dtype_41, -3)
        new_zeros_default_146 = torch.ops.aten.new_zeros.default(to_dtype_40, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_41, 3)
        div_tensor_12 = torch.ops.aten.div.Tensor(to_dtype_41, 3);  to_dtype_41 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(div_tensor_12, 0.5);  div_tensor_12 = None
        mul_tensor_18 = torch.ops.aten.mul.Tensor(to_dtype_40, add_tensor_15);  add_tensor_15 = None
        where_self_12 = torch.ops.aten.where.self(le_scalar_6, mul_tensor_18, to_dtype_40);  le_scalar_6 = mul_tensor_18 = to_dtype_40 = None
        where_self_13 = torch.ops.aten.where.self(lt_scalar_6, new_zeros_default_146, where_self_12);  lt_scalar_6 = new_zeros_default_146 = where_self_12 = None
        to_dtype_42 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_42, convolution_default_52, primals_106, primals_104, primals_105, new_zeros_default_120, new_zeros_default_121, False, 0.001, [True, True, True]);  to_dtype_42 = convolution_default_52 = primals_106 = primals_104 = primals_105 = new_zeros_default_120 = new_zeros_default_121 = None
        getitem_180 = native_batch_norm_backward_default_5[0]
        getitem_181 = native_batch_norm_backward_default_5[1]
        getitem_182 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_180, hardswish__default_15, primals_101, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 960, [True, True, False]);  getitem_180 = hardswish__default_15 = primals_101 = None
        getitem_183 = convolution_backward_default_9[0]
        getitem_184 = convolution_backward_default_9[1];  convolution_backward_default_9 = None
        to_dtype_43 = torch.ops.aten.to.dtype(getitem_183, torch.float32);  getitem_183 = None
        to_dtype_44 = torch.ops.aten.to.dtype(clone_default_15, torch.float32);  clone_default_15 = None
        lt_scalar_7 = torch.ops.aten.lt.Scalar(to_dtype_44, -3)
        new_zeros_default_147 = torch.ops.aten.new_zeros.default(to_dtype_43, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_44, 3)
        div_tensor_13 = torch.ops.aten.div.Tensor(to_dtype_44, 3);  to_dtype_44 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(div_tensor_13, 0.5);  div_tensor_13 = None
        mul_tensor_19 = torch.ops.aten.mul.Tensor(to_dtype_43, add_tensor_16);  add_tensor_16 = None
        where_self_14 = torch.ops.aten.where.self(le_scalar_7, mul_tensor_19, to_dtype_43);  le_scalar_7 = mul_tensor_19 = to_dtype_43 = None
        where_self_15 = torch.ops.aten.where.self(lt_scalar_7, new_zeros_default_147, where_self_14);  lt_scalar_7 = new_zeros_default_147 = where_self_14 = None
        to_dtype_45 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_45, convolution_default_51, primals_100, primals_98, primals_99, new_zeros_default_117, new_zeros_default_118, False, 0.001, [True, True, True]);  to_dtype_45 = convolution_default_51 = primals_100 = primals_98 = primals_99 = new_zeros_default_117 = new_zeros_default_118 = None
        getitem_186 = native_batch_norm_backward_default_6[0]
        getitem_187 = native_batch_norm_backward_default_6[1]
        getitem_188 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_186, getitem_114, primals_95, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_186 = getitem_114 = primals_95 = None
        getitem_189 = convolution_backward_default_10[0]
        getitem_190 = convolution_backward_default_10[1];  convolution_backward_default_10 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(add_tensor_13, getitem_189);  add_tensor_13 = getitem_189 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_17, convolution_default_50, primals_94, primals_92, primals_93, new_zeros_default_114, new_zeros_default_115, False, 0.001, [True, True, True]);  add_tensor_17 = convolution_default_50 = primals_94 = primals_92 = primals_93 = new_zeros_default_114 = new_zeros_default_115 = None
        getitem_192 = native_batch_norm_backward_default_7[0]
        getitem_193 = native_batch_norm_backward_default_7[1]
        getitem_194 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_192, mul_tensor_5, primals_89, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_192 = mul_tensor_5 = primals_89 = None
        getitem_195 = convolution_backward_default_11[0]
        getitem_196 = convolution_backward_default_11[1];  convolution_backward_default_11 = None
        mul_tensor_20 = torch.ops.aten.mul.Tensor(getitem_195, to_dtype_11);  to_dtype_11 = None
        mul_tensor_21 = torch.ops.aten.mul.Tensor(getitem_195, hardswish__default_14);  getitem_195 = hardswish__default_14 = None
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(mul_tensor_21, [2, 3], True);  mul_tensor_21 = None
        to_dtype_46 = torch.ops.aten.to.dtype(sum_dim_int_list_4, torch.float32);  sum_dim_int_list_4 = None
        to_dtype_47 = torch.ops.aten.to.dtype(convolution_default_49, torch.float32);  convolution_default_49 = None
        gt_scalar_2 = torch.ops.aten.gt.Scalar(to_dtype_47, -3.0)
        lt_scalar_8 = torch.ops.aten.lt.Scalar(to_dtype_47, 3.0);  to_dtype_47 = None
        __and___tensor_2 = torch.ops.aten.__and__.Tensor(gt_scalar_2, lt_scalar_8);  gt_scalar_2 = lt_scalar_8 = None
        mul_tensor_22 = torch.ops.aten.mul.Tensor(to_dtype_46, 0.16666666666666666)
        new_zeros_default_148 = torch.ops.aten.new_zeros.default(to_dtype_46, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False);  to_dtype_46 = None
        where_self_16 = torch.ops.aten.where.self(__and___tensor_2, mul_tensor_22, new_zeros_default_148);  __and___tensor_2 = mul_tensor_22 = new_zeros_default_148 = None
        to_dtype_48 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(to_dtype_48, relu_default_5, primals_88, [672], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_48 = primals_88 = None
        getitem_198 = convolution_backward_default_12[0]
        getitem_199 = convolution_backward_default_12[1]
        getitem_200 = convolution_backward_default_12[2];  convolution_backward_default_12 = None
        to_dtype_49 = torch.ops.aten.to.dtype(getitem_198, torch.float32);  getitem_198 = None
        to_dtype_50 = torch.ops.aten.to.dtype(relu_default_5, torch.float32);  relu_default_5 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_50, 0);  to_dtype_50 = None
        new_zeros_default_149 = torch.ops.aten.new_zeros.default(to_dtype_49, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_149, to_dtype_49);  le_scalar_8 = new_zeros_default_149 = to_dtype_49 = None
        to_dtype_51 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(to_dtype_51, mean_dim_5, primals_86, [168], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_51 = mean_dim_5 = primals_86 = None
        getitem_201 = convolution_backward_default_13[0]
        getitem_202 = convolution_backward_default_13[1]
        getitem_203 = convolution_backward_default_13[2];  convolution_backward_default_13 = None
        expand_default_3 = torch.ops.aten.expand.default(getitem_201, [32, 672, 7, 7]);  getitem_201 = None
        div_scalar_3 = torch.ops.aten.div.Scalar(expand_default_3, 49);  expand_default_3 = None
        add_tensor_18 = torch.ops.aten.add.Tensor(mul_tensor_20, div_scalar_3);  mul_tensor_20 = div_scalar_3 = None
        to_dtype_52 = torch.ops.aten.to.dtype(add_tensor_18, torch.float32);  add_tensor_18 = None
        to_dtype_53 = torch.ops.aten.to.dtype(clone_default_14, torch.float32);  clone_default_14 = None
        lt_scalar_9 = torch.ops.aten.lt.Scalar(to_dtype_53, -3)
        new_zeros_default_150 = torch.ops.aten.new_zeros.default(to_dtype_52, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_53, 3)
        div_tensor_14 = torch.ops.aten.div.Tensor(to_dtype_53, 3);  to_dtype_53 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(div_tensor_14, 0.5);  div_tensor_14 = None
        mul_tensor_23 = torch.ops.aten.mul.Tensor(to_dtype_52, add_tensor_19);  add_tensor_19 = None
        where_self_18 = torch.ops.aten.where.self(le_scalar_9, mul_tensor_23, to_dtype_52);  le_scalar_9 = mul_tensor_23 = to_dtype_52 = None
        where_self_19 = torch.ops.aten.where.self(lt_scalar_9, new_zeros_default_150, where_self_18);  lt_scalar_9 = new_zeros_default_150 = where_self_18 = None
        to_dtype_54 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_54, convolution_default_47, primals_84, primals_82, primals_83, new_zeros_default_111, new_zeros_default_112, False, 0.001, [True, True, True]);  to_dtype_54 = convolution_default_47 = primals_84 = primals_82 = primals_83 = new_zeros_default_111 = new_zeros_default_112 = None
        getitem_204 = native_batch_norm_backward_default_8[0]
        getitem_205 = native_batch_norm_backward_default_8[1]
        getitem_206 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_204, hardswish__default_13, primals_79, [0], [2, 2], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_204 = hardswish__default_13 = primals_79 = None
        getitem_207 = convolution_backward_default_14[0]
        getitem_208 = convolution_backward_default_14[1];  convolution_backward_default_14 = None
        to_dtype_55 = torch.ops.aten.to.dtype(getitem_207, torch.float32);  getitem_207 = None
        to_dtype_56 = torch.ops.aten.to.dtype(clone_default_13, torch.float32);  clone_default_13 = None
        lt_scalar_10 = torch.ops.aten.lt.Scalar(to_dtype_56, -3)
        new_zeros_default_151 = torch.ops.aten.new_zeros.default(to_dtype_55, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_56, 3)
        div_tensor_15 = torch.ops.aten.div.Tensor(to_dtype_56, 3);  to_dtype_56 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(div_tensor_15, 0.5);  div_tensor_15 = None
        mul_tensor_24 = torch.ops.aten.mul.Tensor(to_dtype_55, add_tensor_20);  add_tensor_20 = None
        where_self_20 = torch.ops.aten.where.self(le_scalar_10, mul_tensor_24, to_dtype_55);  le_scalar_10 = mul_tensor_24 = to_dtype_55 = None
        where_self_21 = torch.ops.aten.where.self(lt_scalar_10, new_zeros_default_151, where_self_20);  lt_scalar_10 = new_zeros_default_151 = where_self_20 = None
        to_dtype_57 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_57, convolution_default_46, primals_78, primals_76, primals_77, new_zeros_default_108, new_zeros_default_109, False, 0.001, [True, True, True]);  to_dtype_57 = convolution_default_46 = primals_78 = primals_76 = primals_77 = new_zeros_default_108 = new_zeros_default_109 = None
        getitem_210 = native_batch_norm_backward_default_9[0]
        getitem_211 = native_batch_norm_backward_default_9[1]
        getitem_212 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_210, add__tensor_7, primals_73, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_210 = add__tensor_7 = primals_73 = None
        getitem_213 = convolution_backward_default_15[0]
        getitem_214 = convolution_backward_default_15[1];  convolution_backward_default_15 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(getitem_213, convolution_default_45, primals_72, primals_70, primals_71, new_zeros_default_105, new_zeros_default_106, False, 0.001, [True, True, True]);  convolution_default_45 = primals_72 = primals_70 = primals_71 = new_zeros_default_105 = new_zeros_default_106 = None
        getitem_216 = native_batch_norm_backward_default_10[0]
        getitem_217 = native_batch_norm_backward_default_10[1]
        getitem_218 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(getitem_216, mul_tensor_4, primals_67, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_216 = mul_tensor_4 = primals_67 = None
        getitem_219 = convolution_backward_default_16[0]
        getitem_220 = convolution_backward_default_16[1];  convolution_backward_default_16 = None
        mul_tensor_25 = torch.ops.aten.mul.Tensor(getitem_219, to_dtype_9);  to_dtype_9 = None
        mul_tensor_26 = torch.ops.aten.mul.Tensor(getitem_219, hardswish__default_12);  getitem_219 = hardswish__default_12 = None
        sum_dim_int_list_5 = torch.ops.aten.sum.dim_IntList(mul_tensor_26, [2, 3], True);  mul_tensor_26 = None
        to_dtype_58 = torch.ops.aten.to.dtype(sum_dim_int_list_5, torch.float32);  sum_dim_int_list_5 = None
        to_dtype_59 = torch.ops.aten.to.dtype(convolution_default_44, torch.float32);  convolution_default_44 = None
        gt_scalar_3 = torch.ops.aten.gt.Scalar(to_dtype_59, -3.0)
        lt_scalar_11 = torch.ops.aten.lt.Scalar(to_dtype_59, 3.0);  to_dtype_59 = None
        __and___tensor_3 = torch.ops.aten.__and__.Tensor(gt_scalar_3, lt_scalar_11);  gt_scalar_3 = lt_scalar_11 = None
        mul_tensor_27 = torch.ops.aten.mul.Tensor(to_dtype_58, 0.16666666666666666)
        new_zeros_default_152 = torch.ops.aten.new_zeros.default(to_dtype_58, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False);  to_dtype_58 = None
        where_self_22 = torch.ops.aten.where.self(__and___tensor_3, mul_tensor_27, new_zeros_default_152);  __and___tensor_3 = mul_tensor_27 = new_zeros_default_152 = None
        to_dtype_60 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(to_dtype_60, relu_default_4, primals_66, [672], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_60 = primals_66 = None
        getitem_222 = convolution_backward_default_17[0]
        getitem_223 = convolution_backward_default_17[1]
        getitem_224 = convolution_backward_default_17[2];  convolution_backward_default_17 = None
        to_dtype_61 = torch.ops.aten.to.dtype(getitem_222, torch.float32);  getitem_222 = None
        to_dtype_62 = torch.ops.aten.to.dtype(relu_default_4, torch.float32);  relu_default_4 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_62, 0);  to_dtype_62 = None
        new_zeros_default_153 = torch.ops.aten.new_zeros.default(to_dtype_61, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_153, to_dtype_61);  le_scalar_11 = new_zeros_default_153 = to_dtype_61 = None
        to_dtype_63 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(to_dtype_63, mean_dim_4, primals_64, [168], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_63 = mean_dim_4 = primals_64 = None
        getitem_225 = convolution_backward_default_18[0]
        getitem_226 = convolution_backward_default_18[1]
        getitem_227 = convolution_backward_default_18[2];  convolution_backward_default_18 = None
        expand_default_4 = torch.ops.aten.expand.default(getitem_225, [32, 672, 14, 14]);  getitem_225 = None
        div_scalar_4 = torch.ops.aten.div.Scalar(expand_default_4, 196);  expand_default_4 = None
        add_tensor_21 = torch.ops.aten.add.Tensor(mul_tensor_25, div_scalar_4);  mul_tensor_25 = div_scalar_4 = None
        to_dtype_64 = torch.ops.aten.to.dtype(add_tensor_21, torch.float32);  add_tensor_21 = None
        to_dtype_65 = torch.ops.aten.to.dtype(clone_default_12, torch.float32);  clone_default_12 = None
        lt_scalar_12 = torch.ops.aten.lt.Scalar(to_dtype_65, -3)
        new_zeros_default_154 = torch.ops.aten.new_zeros.default(to_dtype_64, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_65, 3)
        div_tensor_16 = torch.ops.aten.div.Tensor(to_dtype_65, 3);  to_dtype_65 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(div_tensor_16, 0.5);  div_tensor_16 = None
        mul_tensor_28 = torch.ops.aten.mul.Tensor(to_dtype_64, add_tensor_22);  add_tensor_22 = None
        where_self_24 = torch.ops.aten.where.self(le_scalar_12, mul_tensor_28, to_dtype_64);  le_scalar_12 = mul_tensor_28 = to_dtype_64 = None
        where_self_25 = torch.ops.aten.where.self(lt_scalar_12, new_zeros_default_154, where_self_24);  lt_scalar_12 = new_zeros_default_154 = where_self_24 = None
        to_dtype_66 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_66, convolution_default_42, primals_62, primals_60, primals_61, new_zeros_default_102, new_zeros_default_103, False, 0.001, [True, True, True]);  to_dtype_66 = convolution_default_42 = primals_62 = primals_60 = primals_61 = new_zeros_default_102 = new_zeros_default_103 = None
        getitem_228 = native_batch_norm_backward_default_11[0]
        getitem_229 = native_batch_norm_backward_default_11[1]
        getitem_230 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_228, hardswish__default_11, primals_57, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_228 = hardswish__default_11 = primals_57 = None
        getitem_231 = convolution_backward_default_19[0]
        getitem_232 = convolution_backward_default_19[1];  convolution_backward_default_19 = None
        to_dtype_67 = torch.ops.aten.to.dtype(getitem_231, torch.float32);  getitem_231 = None
        to_dtype_68 = torch.ops.aten.to.dtype(clone_default_11, torch.float32);  clone_default_11 = None
        lt_scalar_13 = torch.ops.aten.lt.Scalar(to_dtype_68, -3)
        new_zeros_default_155 = torch.ops.aten.new_zeros.default(to_dtype_67, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_68, 3)
        div_tensor_17 = torch.ops.aten.div.Tensor(to_dtype_68, 3);  to_dtype_68 = None
        add_tensor_23 = torch.ops.aten.add.Tensor(div_tensor_17, 0.5);  div_tensor_17 = None
        mul_tensor_29 = torch.ops.aten.mul.Tensor(to_dtype_67, add_tensor_23);  add_tensor_23 = None
        where_self_26 = torch.ops.aten.where.self(le_scalar_13, mul_tensor_29, to_dtype_67);  le_scalar_13 = mul_tensor_29 = to_dtype_67 = None
        where_self_27 = torch.ops.aten.where.self(lt_scalar_13, new_zeros_default_155, where_self_26);  lt_scalar_13 = new_zeros_default_155 = where_self_26 = None
        to_dtype_69 = torch.ops.aten.to.dtype(where_self_27, torch.float32);  where_self_27 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_69, convolution_default_41, primals_56, primals_54, primals_55, new_zeros_default_99, new_zeros_default_100, False, 0.001, [True, True, True]);  to_dtype_69 = convolution_default_41 = primals_56 = primals_54 = primals_55 = new_zeros_default_99 = new_zeros_default_100 = None
        getitem_234 = native_batch_norm_backward_default_12[0]
        getitem_235 = native_batch_norm_backward_default_12[1]
        getitem_236 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(getitem_234, getitem_96, primals_51, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_234 = getitem_96 = primals_51 = None
        getitem_237 = convolution_backward_default_20[0]
        getitem_238 = convolution_backward_default_20[1];  convolution_backward_default_20 = None
        add_tensor_24 = torch.ops.aten.add.Tensor(getitem_213, getitem_237);  getitem_213 = getitem_237 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_24, convolution_default_40, primals_50, primals_48, primals_49, new_zeros_default_96, new_zeros_default_97, False, 0.001, [True, True, True]);  add_tensor_24 = convolution_default_40 = primals_50 = primals_48 = primals_49 = new_zeros_default_96 = new_zeros_default_97 = None
        getitem_240 = native_batch_norm_backward_default_13[0]
        getitem_241 = native_batch_norm_backward_default_13[1]
        getitem_242 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(getitem_240, mul_tensor_3, primals_45, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_240 = mul_tensor_3 = primals_45 = None
        getitem_243 = convolution_backward_default_21[0]
        getitem_244 = convolution_backward_default_21[1];  convolution_backward_default_21 = None
        mul_tensor_30 = torch.ops.aten.mul.Tensor(getitem_243, to_dtype_7);  to_dtype_7 = None
        mul_tensor_31 = torch.ops.aten.mul.Tensor(getitem_243, hardswish__default_10);  getitem_243 = hardswish__default_10 = None
        sum_dim_int_list_6 = torch.ops.aten.sum.dim_IntList(mul_tensor_31, [2, 3], True);  mul_tensor_31 = None
        to_dtype_70 = torch.ops.aten.to.dtype(sum_dim_int_list_6, torch.float32);  sum_dim_int_list_6 = None
        to_dtype_71 = torch.ops.aten.to.dtype(convolution_default_39, torch.float32);  convolution_default_39 = None
        gt_scalar_4 = torch.ops.aten.gt.Scalar(to_dtype_71, -3.0)
        lt_scalar_14 = torch.ops.aten.lt.Scalar(to_dtype_71, 3.0);  to_dtype_71 = None
        __and___tensor_4 = torch.ops.aten.__and__.Tensor(gt_scalar_4, lt_scalar_14);  gt_scalar_4 = lt_scalar_14 = None
        mul_tensor_32 = torch.ops.aten.mul.Tensor(to_dtype_70, 0.16666666666666666)
        new_zeros_default_156 = torch.ops.aten.new_zeros.default(to_dtype_70, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False);  to_dtype_70 = None
        where_self_28 = torch.ops.aten.where.self(__and___tensor_4, mul_tensor_32, new_zeros_default_156);  __and___tensor_4 = mul_tensor_32 = new_zeros_default_156 = None
        to_dtype_72 = torch.ops.aten.to.dtype(where_self_28, torch.float32);  where_self_28 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(to_dtype_72, relu_default_3, primals_44, [480], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_72 = primals_44 = None
        getitem_246 = convolution_backward_default_22[0]
        getitem_247 = convolution_backward_default_22[1]
        getitem_248 = convolution_backward_default_22[2];  convolution_backward_default_22 = None
        to_dtype_73 = torch.ops.aten.to.dtype(getitem_246, torch.float32);  getitem_246 = None
        to_dtype_74 = torch.ops.aten.to.dtype(relu_default_3, torch.float32);  relu_default_3 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_74, 0);  to_dtype_74 = None
        new_zeros_default_157 = torch.ops.aten.new_zeros.default(to_dtype_73, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_29 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_157, to_dtype_73);  le_scalar_14 = new_zeros_default_157 = to_dtype_73 = None
        to_dtype_75 = torch.ops.aten.to.dtype(where_self_29, torch.float32);  where_self_29 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(to_dtype_75, mean_dim_3, primals_42, [120], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_75 = mean_dim_3 = primals_42 = None
        getitem_249 = convolution_backward_default_23[0]
        getitem_250 = convolution_backward_default_23[1]
        getitem_251 = convolution_backward_default_23[2];  convolution_backward_default_23 = None
        expand_default_5 = torch.ops.aten.expand.default(getitem_249, [32, 480, 14, 14]);  getitem_249 = None
        div_scalar_5 = torch.ops.aten.div.Scalar(expand_default_5, 196);  expand_default_5 = None
        add_tensor_25 = torch.ops.aten.add.Tensor(mul_tensor_30, div_scalar_5);  mul_tensor_30 = div_scalar_5 = None
        to_dtype_76 = torch.ops.aten.to.dtype(add_tensor_25, torch.float32);  add_tensor_25 = None
        to_dtype_77 = torch.ops.aten.to.dtype(clone_default_10, torch.float32);  clone_default_10 = None
        lt_scalar_15 = torch.ops.aten.lt.Scalar(to_dtype_77, -3)
        new_zeros_default_158 = torch.ops.aten.new_zeros.default(to_dtype_76, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_77, 3)
        div_tensor_18 = torch.ops.aten.div.Tensor(to_dtype_77, 3);  to_dtype_77 = None
        add_tensor_26 = torch.ops.aten.add.Tensor(div_tensor_18, 0.5);  div_tensor_18 = None
        mul_tensor_33 = torch.ops.aten.mul.Tensor(to_dtype_76, add_tensor_26);  add_tensor_26 = None
        where_self_30 = torch.ops.aten.where.self(le_scalar_15, mul_tensor_33, to_dtype_76);  le_scalar_15 = mul_tensor_33 = to_dtype_76 = None
        where_self_31 = torch.ops.aten.where.self(lt_scalar_15, new_zeros_default_158, where_self_30);  lt_scalar_15 = new_zeros_default_158 = where_self_30 = None
        to_dtype_78 = torch.ops.aten.to.dtype(where_self_31, torch.float32);  where_self_31 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_78, convolution_default_37, primals_40, primals_38, primals_39, new_zeros_default_93, new_zeros_default_94, False, 0.001, [True, True, True]);  to_dtype_78 = convolution_default_37 = primals_40 = primals_38 = primals_39 = new_zeros_default_93 = new_zeros_default_94 = None
        getitem_252 = native_batch_norm_backward_default_14[0]
        getitem_253 = native_batch_norm_backward_default_14[1]
        getitem_254 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_252, hardswish__default_9, primals_35, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 480, [True, True, False]);  getitem_252 = hardswish__default_9 = primals_35 = None
        getitem_255 = convolution_backward_default_24[0]
        getitem_256 = convolution_backward_default_24[1];  convolution_backward_default_24 = None
        to_dtype_79 = torch.ops.aten.to.dtype(getitem_255, torch.float32);  getitem_255 = None
        to_dtype_80 = torch.ops.aten.to.dtype(clone_default_9, torch.float32);  clone_default_9 = None
        lt_scalar_16 = torch.ops.aten.lt.Scalar(to_dtype_80, -3)
        new_zeros_default_159 = torch.ops.aten.new_zeros.default(to_dtype_79, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_80, 3)
        div_tensor_19 = torch.ops.aten.div.Tensor(to_dtype_80, 3);  to_dtype_80 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(div_tensor_19, 0.5);  div_tensor_19 = None
        mul_tensor_34 = torch.ops.aten.mul.Tensor(to_dtype_79, add_tensor_27);  add_tensor_27 = None
        where_self_32 = torch.ops.aten.where.self(le_scalar_16, mul_tensor_34, to_dtype_79);  le_scalar_16 = mul_tensor_34 = to_dtype_79 = None
        where_self_33 = torch.ops.aten.where.self(lt_scalar_16, new_zeros_default_159, where_self_32);  lt_scalar_16 = new_zeros_default_159 = where_self_32 = None
        to_dtype_81 = torch.ops.aten.to.dtype(where_self_33, torch.float32);  where_self_33 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_81, convolution_default_36, primals_34, primals_32, primals_33, new_zeros_default_90, new_zeros_default_91, False, 0.001, [True, True, True]);  to_dtype_81 = convolution_default_36 = primals_34 = primals_32 = primals_33 = new_zeros_default_90 = new_zeros_default_91 = None
        getitem_258 = native_batch_norm_backward_default_15[0]
        getitem_259 = native_batch_norm_backward_default_15[1]
        getitem_260 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_258, add__tensor_6, primals_29, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_258 = add__tensor_6 = primals_29 = None
        getitem_261 = convolution_backward_default_25[0]
        getitem_262 = convolution_backward_default_25[1];  convolution_backward_default_25 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(getitem_261, convolution_default_35, primals_28, primals_26, primals_27, new_zeros_default_87, new_zeros_default_88, False, 0.001, [True, True, True]);  convolution_default_35 = primals_28 = primals_26 = primals_27 = new_zeros_default_87 = new_zeros_default_88 = None
        getitem_264 = native_batch_norm_backward_default_16[0]
        getitem_265 = native_batch_norm_backward_default_16[1]
        getitem_266 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(getitem_264, hardswish__default_8, primals_23, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_264 = hardswish__default_8 = primals_23 = None
        getitem_267 = convolution_backward_default_26[0]
        getitem_268 = convolution_backward_default_26[1];  convolution_backward_default_26 = None
        to_dtype_82 = torch.ops.aten.to.dtype(getitem_267, torch.float32);  getitem_267 = None
        to_dtype_83 = torch.ops.aten.to.dtype(clone_default_8, torch.float32);  clone_default_8 = None
        lt_scalar_17 = torch.ops.aten.lt.Scalar(to_dtype_83, -3)
        new_zeros_default_160 = torch.ops.aten.new_zeros.default(to_dtype_82, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_83, 3)
        div_tensor_20 = torch.ops.aten.div.Tensor(to_dtype_83, 3);  to_dtype_83 = None
        add_tensor_28 = torch.ops.aten.add.Tensor(div_tensor_20, 0.5);  div_tensor_20 = None
        mul_tensor_35 = torch.ops.aten.mul.Tensor(to_dtype_82, add_tensor_28);  add_tensor_28 = None
        where_self_34 = torch.ops.aten.where.self(le_scalar_17, mul_tensor_35, to_dtype_82);  le_scalar_17 = mul_tensor_35 = to_dtype_82 = None
        where_self_35 = torch.ops.aten.where.self(lt_scalar_17, new_zeros_default_160, where_self_34);  lt_scalar_17 = new_zeros_default_160 = where_self_34 = None
        to_dtype_84 = torch.ops.aten.to.dtype(where_self_35, torch.float32);  where_self_35 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_84, convolution_default_34, primals_22, primals_20, primals_21, new_zeros_default_84, new_zeros_default_85, False, 0.001, [True, True, True]);  to_dtype_84 = convolution_default_34 = primals_22 = primals_20 = primals_21 = new_zeros_default_84 = new_zeros_default_85 = None
        getitem_270 = native_batch_norm_backward_default_17[0]
        getitem_271 = native_batch_norm_backward_default_17[1]
        getitem_272 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(getitem_270, hardswish__default_7, primals_17, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 184, [True, True, False]);  getitem_270 = hardswish__default_7 = primals_17 = None
        getitem_273 = convolution_backward_default_27[0]
        getitem_274 = convolution_backward_default_27[1];  convolution_backward_default_27 = None
        to_dtype_85 = torch.ops.aten.to.dtype(getitem_273, torch.float32);  getitem_273 = None
        to_dtype_86 = torch.ops.aten.to.dtype(clone_default_7, torch.float32);  clone_default_7 = None
        lt_scalar_18 = torch.ops.aten.lt.Scalar(to_dtype_86, -3)
        new_zeros_default_161 = torch.ops.aten.new_zeros.default(to_dtype_85, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_86, 3)
        div_tensor_21 = torch.ops.aten.div.Tensor(to_dtype_86, 3);  to_dtype_86 = None
        add_tensor_29 = torch.ops.aten.add.Tensor(div_tensor_21, 0.5);  div_tensor_21 = None
        mul_tensor_36 = torch.ops.aten.mul.Tensor(to_dtype_85, add_tensor_29);  add_tensor_29 = None
        where_self_36 = torch.ops.aten.where.self(le_scalar_18, mul_tensor_36, to_dtype_85);  le_scalar_18 = mul_tensor_36 = to_dtype_85 = None
        where_self_37 = torch.ops.aten.where.self(lt_scalar_18, new_zeros_default_161, where_self_36);  lt_scalar_18 = new_zeros_default_161 = where_self_36 = None
        to_dtype_87 = torch.ops.aten.to.dtype(where_self_37, torch.float32);  where_self_37 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_87, convolution_default_33, primals_16, primals_14, primals_15, new_zeros_default_81, new_zeros_default_82, False, 0.001, [True, True, True]);  to_dtype_87 = convolution_default_33 = primals_16 = primals_14 = primals_15 = new_zeros_default_81 = new_zeros_default_82 = None
        getitem_276 = native_batch_norm_backward_default_18[0]
        getitem_277 = native_batch_norm_backward_default_18[1]
        getitem_278 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(getitem_276, add__tensor_5, primals_11, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_276 = add__tensor_5 = primals_11 = None
        getitem_279 = convolution_backward_default_28[0]
        getitem_280 = convolution_backward_default_28[1];  convolution_backward_default_28 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(getitem_261, getitem_279);  getitem_261 = getitem_279 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_30, convolution_default_32, primals_312, primals_310, primals_311, new_zeros_default_78, new_zeros_default_79, False, 0.001, [True, True, True]);  convolution_default_32 = primals_312 = primals_310 = primals_311 = new_zeros_default_78 = new_zeros_default_79 = None
        getitem_282 = native_batch_norm_backward_default_19[0]
        getitem_283 = native_batch_norm_backward_default_19[1]
        getitem_284 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(getitem_282, hardswish__default_6, primals_307, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_282 = hardswish__default_6 = primals_307 = None
        getitem_285 = convolution_backward_default_29[0]
        getitem_286 = convolution_backward_default_29[1];  convolution_backward_default_29 = None
        to_dtype_88 = torch.ops.aten.to.dtype(getitem_285, torch.float32);  getitem_285 = None
        to_dtype_89 = torch.ops.aten.to.dtype(clone_default_6, torch.float32);  clone_default_6 = None
        lt_scalar_19 = torch.ops.aten.lt.Scalar(to_dtype_89, -3)
        new_zeros_default_162 = torch.ops.aten.new_zeros.default(to_dtype_88, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_89, 3)
        div_tensor_22 = torch.ops.aten.div.Tensor(to_dtype_89, 3);  to_dtype_89 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(div_tensor_22, 0.5);  div_tensor_22 = None
        mul_tensor_37 = torch.ops.aten.mul.Tensor(to_dtype_88, add_tensor_31);  add_tensor_31 = None
        where_self_38 = torch.ops.aten.where.self(le_scalar_19, mul_tensor_37, to_dtype_88);  le_scalar_19 = mul_tensor_37 = to_dtype_88 = None
        where_self_39 = torch.ops.aten.where.self(lt_scalar_19, new_zeros_default_162, where_self_38);  lt_scalar_19 = new_zeros_default_162 = where_self_38 = None
        to_dtype_90 = torch.ops.aten.to.dtype(where_self_39, torch.float32);  where_self_39 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_90, convolution_default_31, primals_306, primals_304, primals_305, new_zeros_default_75, new_zeros_default_76, False, 0.001, [True, True, True]);  to_dtype_90 = convolution_default_31 = primals_306 = primals_304 = primals_305 = new_zeros_default_75 = new_zeros_default_76 = None
        getitem_288 = native_batch_norm_backward_default_20[0]
        getitem_289 = native_batch_norm_backward_default_20[1]
        getitem_290 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_288, hardswish__default_5, primals_301, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 184, [True, True, False]);  getitem_288 = hardswish__default_5 = primals_301 = None
        getitem_291 = convolution_backward_default_30[0]
        getitem_292 = convolution_backward_default_30[1];  convolution_backward_default_30 = None
        to_dtype_91 = torch.ops.aten.to.dtype(getitem_291, torch.float32);  getitem_291 = None
        to_dtype_92 = torch.ops.aten.to.dtype(clone_default_5, torch.float32);  clone_default_5 = None
        lt_scalar_20 = torch.ops.aten.lt.Scalar(to_dtype_92, -3)
        new_zeros_default_163 = torch.ops.aten.new_zeros.default(to_dtype_91, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_92, 3)
        div_tensor_23 = torch.ops.aten.div.Tensor(to_dtype_92, 3);  to_dtype_92 = None
        add_tensor_32 = torch.ops.aten.add.Tensor(div_tensor_23, 0.5);  div_tensor_23 = None
        mul_tensor_38 = torch.ops.aten.mul.Tensor(to_dtype_91, add_tensor_32);  add_tensor_32 = None
        where_self_40 = torch.ops.aten.where.self(le_scalar_20, mul_tensor_38, to_dtype_91);  le_scalar_20 = mul_tensor_38 = to_dtype_91 = None
        where_self_41 = torch.ops.aten.where.self(lt_scalar_20, new_zeros_default_163, where_self_40);  lt_scalar_20 = new_zeros_default_163 = where_self_40 = None
        to_dtype_93 = torch.ops.aten.to.dtype(where_self_41, torch.float32);  where_self_41 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_93, convolution_default_30, primals_300, primals_298, primals_299, new_zeros_default_72, new_zeros_default_73, False, 0.001, [True, True, True]);  to_dtype_93 = convolution_default_30 = primals_300 = primals_298 = primals_299 = new_zeros_default_72 = new_zeros_default_73 = None
        getitem_294 = native_batch_norm_backward_default_21[0]
        getitem_295 = native_batch_norm_backward_default_21[1]
        getitem_296 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(getitem_294, add__tensor_4, primals_295, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_294 = add__tensor_4 = primals_295 = None
        getitem_297 = convolution_backward_default_31[0]
        getitem_298 = convolution_backward_default_31[1];  convolution_backward_default_31 = None
        add_tensor_33 = torch.ops.aten.add.Tensor(add_tensor_30, getitem_297);  add_tensor_30 = getitem_297 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_33, convolution_default_29, primals_294, primals_292, primals_293, new_zeros_default_69, new_zeros_default_70, False, 0.001, [True, True, True]);  convolution_default_29 = primals_294 = primals_292 = primals_293 = new_zeros_default_69 = new_zeros_default_70 = None
        getitem_300 = native_batch_norm_backward_default_22[0]
        getitem_301 = native_batch_norm_backward_default_22[1]
        getitem_302 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(getitem_300, hardswish__default_4, primals_289, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_300 = hardswish__default_4 = primals_289 = None
        getitem_303 = convolution_backward_default_32[0]
        getitem_304 = convolution_backward_default_32[1];  convolution_backward_default_32 = None
        to_dtype_94 = torch.ops.aten.to.dtype(getitem_303, torch.float32);  getitem_303 = None
        to_dtype_95 = torch.ops.aten.to.dtype(clone_default_4, torch.float32);  clone_default_4 = None
        lt_scalar_21 = torch.ops.aten.lt.Scalar(to_dtype_95, -3)
        new_zeros_default_164 = torch.ops.aten.new_zeros.default(to_dtype_94, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_95, 3)
        div_tensor_24 = torch.ops.aten.div.Tensor(to_dtype_95, 3);  to_dtype_95 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(div_tensor_24, 0.5);  div_tensor_24 = None
        mul_tensor_39 = torch.ops.aten.mul.Tensor(to_dtype_94, add_tensor_34);  add_tensor_34 = None
        where_self_42 = torch.ops.aten.where.self(le_scalar_21, mul_tensor_39, to_dtype_94);  le_scalar_21 = mul_tensor_39 = to_dtype_94 = None
        where_self_43 = torch.ops.aten.where.self(lt_scalar_21, new_zeros_default_164, where_self_42);  lt_scalar_21 = new_zeros_default_164 = where_self_42 = None
        to_dtype_96 = torch.ops.aten.to.dtype(where_self_43, torch.float32);  where_self_43 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_96, convolution_default_28, primals_288, primals_286, primals_287, new_zeros_default_66, new_zeros_default_67, False, 0.001, [True, True, True]);  to_dtype_96 = convolution_default_28 = primals_288 = primals_286 = primals_287 = new_zeros_default_66 = new_zeros_default_67 = None
        getitem_306 = native_batch_norm_backward_default_23[0]
        getitem_307 = native_batch_norm_backward_default_23[1]
        getitem_308 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(getitem_306, hardswish__default_3, primals_283, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 200, [True, True, False]);  getitem_306 = hardswish__default_3 = primals_283 = None
        getitem_309 = convolution_backward_default_33[0]
        getitem_310 = convolution_backward_default_33[1];  convolution_backward_default_33 = None
        to_dtype_97 = torch.ops.aten.to.dtype(getitem_309, torch.float32);  getitem_309 = None
        to_dtype_98 = torch.ops.aten.to.dtype(clone_default_3, torch.float32);  clone_default_3 = None
        lt_scalar_22 = torch.ops.aten.lt.Scalar(to_dtype_98, -3)
        new_zeros_default_165 = torch.ops.aten.new_zeros.default(to_dtype_97, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_98, 3)
        div_tensor_25 = torch.ops.aten.div.Tensor(to_dtype_98, 3);  to_dtype_98 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(div_tensor_25, 0.5);  div_tensor_25 = None
        mul_tensor_40 = torch.ops.aten.mul.Tensor(to_dtype_97, add_tensor_35);  add_tensor_35 = None
        where_self_44 = torch.ops.aten.where.self(le_scalar_22, mul_tensor_40, to_dtype_97);  le_scalar_22 = mul_tensor_40 = to_dtype_97 = None
        where_self_45 = torch.ops.aten.where.self(lt_scalar_22, new_zeros_default_165, where_self_44);  lt_scalar_22 = new_zeros_default_165 = where_self_44 = None
        to_dtype_99 = torch.ops.aten.to.dtype(where_self_45, torch.float32);  where_self_45 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_99, convolution_default_27, primals_282, primals_280, primals_281, new_zeros_default_63, new_zeros_default_64, False, 0.001, [True, True, True]);  to_dtype_99 = convolution_default_27 = primals_282 = primals_280 = primals_281 = new_zeros_default_63 = new_zeros_default_64 = None
        getitem_312 = native_batch_norm_backward_default_24[0]
        getitem_313 = native_batch_norm_backward_default_24[1]
        getitem_314 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(getitem_312, getitem_60, primals_277, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_312 = getitem_60 = primals_277 = None
        getitem_315 = convolution_backward_default_34[0]
        getitem_316 = convolution_backward_default_34[1];  convolution_backward_default_34 = None
        add_tensor_36 = torch.ops.aten.add.Tensor(add_tensor_33, getitem_315);  add_tensor_33 = getitem_315 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_36, convolution_default_26, primals_276, primals_274, primals_275, new_zeros_default_60, new_zeros_default_61, False, 0.001, [True, True, True]);  add_tensor_36 = convolution_default_26 = primals_276 = primals_274 = primals_275 = new_zeros_default_60 = new_zeros_default_61 = None
        getitem_318 = native_batch_norm_backward_default_25[0]
        getitem_319 = native_batch_norm_backward_default_25[1]
        getitem_320 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_318, hardswish__default_2, primals_271, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_318 = hardswish__default_2 = primals_271 = None
        getitem_321 = convolution_backward_default_35[0]
        getitem_322 = convolution_backward_default_35[1];  convolution_backward_default_35 = None
        to_dtype_100 = torch.ops.aten.to.dtype(getitem_321, torch.float32);  getitem_321 = None
        to_dtype_101 = torch.ops.aten.to.dtype(clone_default_2, torch.float32);  clone_default_2 = None
        lt_scalar_23 = torch.ops.aten.lt.Scalar(to_dtype_101, -3)
        new_zeros_default_166 = torch.ops.aten.new_zeros.default(to_dtype_100, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_101, 3)
        div_tensor_26 = torch.ops.aten.div.Tensor(to_dtype_101, 3);  to_dtype_101 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(div_tensor_26, 0.5);  div_tensor_26 = None
        mul_tensor_41 = torch.ops.aten.mul.Tensor(to_dtype_100, add_tensor_37);  add_tensor_37 = None
        where_self_46 = torch.ops.aten.where.self(le_scalar_23, mul_tensor_41, to_dtype_100);  le_scalar_23 = mul_tensor_41 = to_dtype_100 = None
        where_self_47 = torch.ops.aten.where.self(lt_scalar_23, new_zeros_default_166, where_self_46);  lt_scalar_23 = new_zeros_default_166 = where_self_46 = None
        to_dtype_102 = torch.ops.aten.to.dtype(where_self_47, torch.float32);  where_self_47 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_102, convolution_default_25, primals_270, primals_268, primals_269, new_zeros_default_57, new_zeros_default_58, False, 0.001, [True, True, True]);  to_dtype_102 = convolution_default_25 = primals_270 = primals_268 = primals_269 = new_zeros_default_57 = new_zeros_default_58 = None
        getitem_324 = native_batch_norm_backward_default_26[0]
        getitem_325 = native_batch_norm_backward_default_26[1]
        getitem_326 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(getitem_324, hardswish__default_1, primals_265, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 240, [True, True, False]);  getitem_324 = hardswish__default_1 = primals_265 = None
        getitem_327 = convolution_backward_default_36[0]
        getitem_328 = convolution_backward_default_36[1];  convolution_backward_default_36 = None
        to_dtype_103 = torch.ops.aten.to.dtype(getitem_327, torch.float32);  getitem_327 = None
        to_dtype_104 = torch.ops.aten.to.dtype(clone_default_1, torch.float32);  clone_default_1 = None
        lt_scalar_24 = torch.ops.aten.lt.Scalar(to_dtype_104, -3)
        new_zeros_default_167 = torch.ops.aten.new_zeros.default(to_dtype_103, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_104, 3)
        div_tensor_27 = torch.ops.aten.div.Tensor(to_dtype_104, 3);  to_dtype_104 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(div_tensor_27, 0.5);  div_tensor_27 = None
        mul_tensor_42 = torch.ops.aten.mul.Tensor(to_dtype_103, add_tensor_38);  add_tensor_38 = None
        where_self_48 = torch.ops.aten.where.self(le_scalar_24, mul_tensor_42, to_dtype_103);  le_scalar_24 = mul_tensor_42 = to_dtype_103 = None
        where_self_49 = torch.ops.aten.where.self(lt_scalar_24, new_zeros_default_167, where_self_48);  lt_scalar_24 = new_zeros_default_167 = where_self_48 = None
        to_dtype_105 = torch.ops.aten.to.dtype(where_self_49, torch.float32);  where_self_49 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_105, convolution_default_24, primals_264, primals_262, primals_263, new_zeros_default_54, new_zeros_default_55, False, 0.001, [True, True, True]);  to_dtype_105 = convolution_default_24 = primals_264 = primals_262 = primals_263 = new_zeros_default_54 = new_zeros_default_55 = None
        getitem_330 = native_batch_norm_backward_default_27[0]
        getitem_331 = native_batch_norm_backward_default_27[1]
        getitem_332 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(getitem_330, add__tensor_3, primals_259, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_330 = add__tensor_3 = primals_259 = None
        getitem_333 = convolution_backward_default_37[0]
        getitem_334 = convolution_backward_default_37[1];  convolution_backward_default_37 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(getitem_333, convolution_default_23, primals_258, primals_256, primals_257, new_zeros_default_51, new_zeros_default_52, False, 0.001, [True, True, True]);  convolution_default_23 = primals_258 = primals_256 = primals_257 = new_zeros_default_51 = new_zeros_default_52 = None
        getitem_336 = native_batch_norm_backward_default_28[0]
        getitem_337 = native_batch_norm_backward_default_28[1]
        getitem_338 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(getitem_336, mul_tensor_2, primals_253, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_336 = mul_tensor_2 = primals_253 = None
        getitem_339 = convolution_backward_default_38[0]
        getitem_340 = convolution_backward_default_38[1];  convolution_backward_default_38 = None
        mul_tensor_43 = torch.ops.aten.mul.Tensor(getitem_339, to_dtype_5);  to_dtype_5 = None
        mul_tensor_44 = torch.ops.aten.mul.Tensor(getitem_339, relu__default_10);  getitem_339 = None
        sum_dim_int_list_7 = torch.ops.aten.sum.dim_IntList(mul_tensor_44, [2, 3], True);  mul_tensor_44 = None
        to_dtype_106 = torch.ops.aten.to.dtype(sum_dim_int_list_7, torch.float32);  sum_dim_int_list_7 = None
        to_dtype_107 = torch.ops.aten.to.dtype(convolution_default_22, torch.float32);  convolution_default_22 = None
        gt_scalar_5 = torch.ops.aten.gt.Scalar(to_dtype_107, -3.0)
        lt_scalar_25 = torch.ops.aten.lt.Scalar(to_dtype_107, 3.0);  to_dtype_107 = None
        __and___tensor_5 = torch.ops.aten.__and__.Tensor(gt_scalar_5, lt_scalar_25);  gt_scalar_5 = lt_scalar_25 = None
        mul_tensor_45 = torch.ops.aten.mul.Tensor(to_dtype_106, 0.16666666666666666)
        new_zeros_default_168 = torch.ops.aten.new_zeros.default(to_dtype_106, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False);  to_dtype_106 = None
        where_self_50 = torch.ops.aten.where.self(__and___tensor_5, mul_tensor_45, new_zeros_default_168);  __and___tensor_5 = mul_tensor_45 = new_zeros_default_168 = None
        to_dtype_108 = torch.ops.aten.to.dtype(where_self_50, torch.float32);  where_self_50 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(to_dtype_108, relu_default_2, primals_252, [120], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_108 = primals_252 = None
        getitem_342 = convolution_backward_default_39[0]
        getitem_343 = convolution_backward_default_39[1]
        getitem_344 = convolution_backward_default_39[2];  convolution_backward_default_39 = None
        to_dtype_109 = torch.ops.aten.to.dtype(getitem_342, torch.float32);  getitem_342 = None
        to_dtype_110 = torch.ops.aten.to.dtype(relu_default_2, torch.float32);  relu_default_2 = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_110, 0);  to_dtype_110 = None
        new_zeros_default_169 = torch.ops.aten.new_zeros.default(to_dtype_109, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_51 = torch.ops.aten.where.self(le_scalar_25, new_zeros_default_169, to_dtype_109);  le_scalar_25 = new_zeros_default_169 = to_dtype_109 = None
        to_dtype_111 = torch.ops.aten.to.dtype(where_self_51, torch.float32);  where_self_51 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(to_dtype_111, mean_dim_2, primals_250, [32], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_111 = mean_dim_2 = primals_250 = None
        getitem_345 = convolution_backward_default_40[0]
        getitem_346 = convolution_backward_default_40[1]
        getitem_347 = convolution_backward_default_40[2];  convolution_backward_default_40 = None
        expand_default_6 = torch.ops.aten.expand.default(getitem_345, [32, 120, 28, 28]);  getitem_345 = None
        div_scalar_6 = torch.ops.aten.div.Scalar(expand_default_6, 784);  expand_default_6 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(mul_tensor_43, div_scalar_6);  mul_tensor_43 = div_scalar_6 = None
        to_dtype_112 = torch.ops.aten.to.dtype(add_tensor_39, torch.float32);  add_tensor_39 = None
        to_dtype_113 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_26 = torch.ops.aten.le.Scalar(to_dtype_113, 0);  to_dtype_113 = None
        new_zeros_default_170 = torch.ops.aten.new_zeros.default(to_dtype_112, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_52 = torch.ops.aten.where.self(le_scalar_26, new_zeros_default_170, to_dtype_112);  le_scalar_26 = new_zeros_default_170 = to_dtype_112 = None
        to_dtype_114 = torch.ops.aten.to.dtype(where_self_52, torch.float32);  where_self_52 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_114, convolution_default_20, primals_248, primals_246, primals_247, new_zeros_default_48, new_zeros_default_49, False, 0.001, [True, True, True]);  to_dtype_114 = convolution_default_20 = primals_248 = primals_246 = primals_247 = new_zeros_default_48 = new_zeros_default_49 = None
        getitem_348 = native_batch_norm_backward_default_29[0]
        getitem_349 = native_batch_norm_backward_default_29[1]
        getitem_350 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(getitem_348, relu__default_9, primals_243, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 120, [True, True, False]);  getitem_348 = primals_243 = None
        getitem_351 = convolution_backward_default_41[0]
        getitem_352 = convolution_backward_default_41[1];  convolution_backward_default_41 = None
        to_dtype_115 = torch.ops.aten.to.dtype(getitem_351, torch.float32);  getitem_351 = None
        to_dtype_116 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_27 = torch.ops.aten.le.Scalar(to_dtype_116, 0);  to_dtype_116 = None
        new_zeros_default_171 = torch.ops.aten.new_zeros.default(to_dtype_115, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_53 = torch.ops.aten.where.self(le_scalar_27, new_zeros_default_171, to_dtype_115);  le_scalar_27 = new_zeros_default_171 = to_dtype_115 = None
        to_dtype_117 = torch.ops.aten.to.dtype(where_self_53, torch.float32);  where_self_53 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_117, convolution_default_19, primals_242, primals_240, primals_241, new_zeros_default_45, new_zeros_default_46, False, 0.001, [True, True, True]);  to_dtype_117 = convolution_default_19 = primals_242 = primals_240 = primals_241 = new_zeros_default_45 = new_zeros_default_46 = None
        getitem_354 = native_batch_norm_backward_default_30[0]
        getitem_355 = native_batch_norm_backward_default_30[1]
        getitem_356 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(getitem_354, add__tensor_2, primals_237, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_354 = add__tensor_2 = primals_237 = None
        getitem_357 = convolution_backward_default_42[0]
        getitem_358 = convolution_backward_default_42[1];  convolution_backward_default_42 = None
        add_tensor_40 = torch.ops.aten.add.Tensor(getitem_333, getitem_357);  getitem_333 = getitem_357 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_40, convolution_default_18, primals_236, primals_234, primals_235, new_zeros_default_42, new_zeros_default_43, False, 0.001, [True, True, True]);  convolution_default_18 = primals_236 = primals_234 = primals_235 = new_zeros_default_42 = new_zeros_default_43 = None
        getitem_360 = native_batch_norm_backward_default_31[0]
        getitem_361 = native_batch_norm_backward_default_31[1]
        getitem_362 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(getitem_360, mul_tensor_1, primals_231, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_360 = mul_tensor_1 = primals_231 = None
        getitem_363 = convolution_backward_default_43[0]
        getitem_364 = convolution_backward_default_43[1];  convolution_backward_default_43 = None
        mul_tensor_46 = torch.ops.aten.mul.Tensor(getitem_363, to_dtype_3);  to_dtype_3 = None
        mul_tensor_47 = torch.ops.aten.mul.Tensor(getitem_363, relu__default_8);  getitem_363 = None
        sum_dim_int_list_8 = torch.ops.aten.sum.dim_IntList(mul_tensor_47, [2, 3], True);  mul_tensor_47 = None
        to_dtype_118 = torch.ops.aten.to.dtype(sum_dim_int_list_8, torch.float32);  sum_dim_int_list_8 = None
        to_dtype_119 = torch.ops.aten.to.dtype(convolution_default_17, torch.float32);  convolution_default_17 = None
        gt_scalar_6 = torch.ops.aten.gt.Scalar(to_dtype_119, -3.0)
        lt_scalar_26 = torch.ops.aten.lt.Scalar(to_dtype_119, 3.0);  to_dtype_119 = None
        __and___tensor_6 = torch.ops.aten.__and__.Tensor(gt_scalar_6, lt_scalar_26);  gt_scalar_6 = lt_scalar_26 = None
        mul_tensor_48 = torch.ops.aten.mul.Tensor(to_dtype_118, 0.16666666666666666)
        new_zeros_default_172 = torch.ops.aten.new_zeros.default(to_dtype_118, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False);  to_dtype_118 = None
        where_self_54 = torch.ops.aten.where.self(__and___tensor_6, mul_tensor_48, new_zeros_default_172);  __and___tensor_6 = mul_tensor_48 = new_zeros_default_172 = None
        to_dtype_120 = torch.ops.aten.to.dtype(where_self_54, torch.float32);  where_self_54 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(to_dtype_120, relu_default_1, primals_230, [120], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_120 = primals_230 = None
        getitem_366 = convolution_backward_default_44[0]
        getitem_367 = convolution_backward_default_44[1]
        getitem_368 = convolution_backward_default_44[2];  convolution_backward_default_44 = None
        to_dtype_121 = torch.ops.aten.to.dtype(getitem_366, torch.float32);  getitem_366 = None
        to_dtype_122 = torch.ops.aten.to.dtype(relu_default_1, torch.float32);  relu_default_1 = None
        le_scalar_28 = torch.ops.aten.le.Scalar(to_dtype_122, 0);  to_dtype_122 = None
        new_zeros_default_173 = torch.ops.aten.new_zeros.default(to_dtype_121, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_55 = torch.ops.aten.where.self(le_scalar_28, new_zeros_default_173, to_dtype_121);  le_scalar_28 = new_zeros_default_173 = to_dtype_121 = None
        to_dtype_123 = torch.ops.aten.to.dtype(where_self_55, torch.float32);  where_self_55 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(to_dtype_123, mean_dim_1, primals_228, [32], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_123 = mean_dim_1 = primals_228 = None
        getitem_369 = convolution_backward_default_45[0]
        getitem_370 = convolution_backward_default_45[1]
        getitem_371 = convolution_backward_default_45[2];  convolution_backward_default_45 = None
        expand_default_7 = torch.ops.aten.expand.default(getitem_369, [32, 120, 28, 28]);  getitem_369 = None
        div_scalar_7 = torch.ops.aten.div.Scalar(expand_default_7, 784);  expand_default_7 = None
        add_tensor_41 = torch.ops.aten.add.Tensor(mul_tensor_46, div_scalar_7);  mul_tensor_46 = div_scalar_7 = None
        to_dtype_124 = torch.ops.aten.to.dtype(add_tensor_41, torch.float32);  add_tensor_41 = None
        to_dtype_125 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_29 = torch.ops.aten.le.Scalar(to_dtype_125, 0);  to_dtype_125 = None
        new_zeros_default_174 = torch.ops.aten.new_zeros.default(to_dtype_124, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_56 = torch.ops.aten.where.self(le_scalar_29, new_zeros_default_174, to_dtype_124);  le_scalar_29 = new_zeros_default_174 = to_dtype_124 = None
        to_dtype_126 = torch.ops.aten.to.dtype(where_self_56, torch.float32);  where_self_56 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_126, convolution_default_15, primals_226, primals_224, primals_225, new_zeros_default_39, new_zeros_default_40, False, 0.001, [True, True, True]);  to_dtype_126 = convolution_default_15 = primals_226 = primals_224 = primals_225 = new_zeros_default_39 = new_zeros_default_40 = None
        getitem_372 = native_batch_norm_backward_default_32[0]
        getitem_373 = native_batch_norm_backward_default_32[1]
        getitem_374 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(getitem_372, relu__default_7, primals_221, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 120, [True, True, False]);  getitem_372 = primals_221 = None
        getitem_375 = convolution_backward_default_46[0]
        getitem_376 = convolution_backward_default_46[1];  convolution_backward_default_46 = None
        to_dtype_127 = torch.ops.aten.to.dtype(getitem_375, torch.float32);  getitem_375 = None
        to_dtype_128 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_30 = torch.ops.aten.le.Scalar(to_dtype_128, 0);  to_dtype_128 = None
        new_zeros_default_175 = torch.ops.aten.new_zeros.default(to_dtype_127, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_57 = torch.ops.aten.where.self(le_scalar_30, new_zeros_default_175, to_dtype_127);  le_scalar_30 = new_zeros_default_175 = to_dtype_127 = None
        to_dtype_129 = torch.ops.aten.to.dtype(where_self_57, torch.float32);  where_self_57 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_129, convolution_default_14, primals_220, primals_218, primals_219, new_zeros_default_36, new_zeros_default_37, False, 0.001, [True, True, True]);  to_dtype_129 = convolution_default_14 = primals_220 = primals_218 = primals_219 = new_zeros_default_36 = new_zeros_default_37 = None
        getitem_378 = native_batch_norm_backward_default_33[0]
        getitem_379 = native_batch_norm_backward_default_33[1]
        getitem_380 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(getitem_378, getitem_33, primals_215, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_378 = getitem_33 = primals_215 = None
        getitem_381 = convolution_backward_default_47[0]
        getitem_382 = convolution_backward_default_47[1];  convolution_backward_default_47 = None
        add_tensor_42 = torch.ops.aten.add.Tensor(add_tensor_40, getitem_381);  add_tensor_40 = getitem_381 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_42, convolution_default_13, primals_214, primals_212, primals_213, new_zeros_default_33, new_zeros_default_34, False, 0.001, [True, True, True]);  add_tensor_42 = convolution_default_13 = primals_214 = primals_212 = primals_213 = new_zeros_default_33 = new_zeros_default_34 = None
        getitem_384 = native_batch_norm_backward_default_34[0]
        getitem_385 = native_batch_norm_backward_default_34[1]
        getitem_386 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        convolution_backward_default_48 = torch.ops.aten.convolution_backward.default(getitem_384, mul_tensor, primals_209, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_384 = mul_tensor = primals_209 = None
        getitem_387 = convolution_backward_default_48[0]
        getitem_388 = convolution_backward_default_48[1];  convolution_backward_default_48 = None
        mul_tensor_49 = torch.ops.aten.mul.Tensor(getitem_387, to_dtype_1);  to_dtype_1 = None
        mul_tensor_50 = torch.ops.aten.mul.Tensor(getitem_387, relu__default_6);  getitem_387 = None
        sum_dim_int_list_9 = torch.ops.aten.sum.dim_IntList(mul_tensor_50, [2, 3], True);  mul_tensor_50 = None
        to_dtype_130 = torch.ops.aten.to.dtype(sum_dim_int_list_9, torch.float32);  sum_dim_int_list_9 = None
        to_dtype_131 = torch.ops.aten.to.dtype(convolution_default_12, torch.float32);  convolution_default_12 = None
        gt_scalar_7 = torch.ops.aten.gt.Scalar(to_dtype_131, -3.0)
        lt_scalar_27 = torch.ops.aten.lt.Scalar(to_dtype_131, 3.0);  to_dtype_131 = None
        __and___tensor_7 = torch.ops.aten.__and__.Tensor(gt_scalar_7, lt_scalar_27);  gt_scalar_7 = lt_scalar_27 = None
        mul_tensor_51 = torch.ops.aten.mul.Tensor(to_dtype_130, 0.16666666666666666)
        new_zeros_default_176 = torch.ops.aten.new_zeros.default(to_dtype_130, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False);  to_dtype_130 = None
        where_self_58 = torch.ops.aten.where.self(__and___tensor_7, mul_tensor_51, new_zeros_default_176);  __and___tensor_7 = mul_tensor_51 = new_zeros_default_176 = None
        to_dtype_132 = torch.ops.aten.to.dtype(where_self_58, torch.float32);  where_self_58 = None
        convolution_backward_default_49 = torch.ops.aten.convolution_backward.default(to_dtype_132, relu_default, primals_208, [72], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_132 = primals_208 = None
        getitem_390 = convolution_backward_default_49[0]
        getitem_391 = convolution_backward_default_49[1]
        getitem_392 = convolution_backward_default_49[2];  convolution_backward_default_49 = None
        to_dtype_133 = torch.ops.aten.to.dtype(getitem_390, torch.float32);  getitem_390 = None
        to_dtype_134 = torch.ops.aten.to.dtype(relu_default, torch.float32);  relu_default = None
        le_scalar_31 = torch.ops.aten.le.Scalar(to_dtype_134, 0);  to_dtype_134 = None
        new_zeros_default_177 = torch.ops.aten.new_zeros.default(to_dtype_133, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_59 = torch.ops.aten.where.self(le_scalar_31, new_zeros_default_177, to_dtype_133);  le_scalar_31 = new_zeros_default_177 = to_dtype_133 = None
        to_dtype_135 = torch.ops.aten.to.dtype(where_self_59, torch.float32);  where_self_59 = None
        convolution_backward_default_50 = torch.ops.aten.convolution_backward.default(to_dtype_135, mean_dim, primals_206, [24], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_135 = mean_dim = primals_206 = None
        getitem_393 = convolution_backward_default_50[0]
        getitem_394 = convolution_backward_default_50[1]
        getitem_395 = convolution_backward_default_50[2];  convolution_backward_default_50 = None
        expand_default_8 = torch.ops.aten.expand.default(getitem_393, [32, 72, 28, 28]);  getitem_393 = None
        div_scalar_8 = torch.ops.aten.div.Scalar(expand_default_8, 784);  expand_default_8 = None
        add_tensor_43 = torch.ops.aten.add.Tensor(mul_tensor_49, div_scalar_8);  mul_tensor_49 = div_scalar_8 = None
        to_dtype_136 = torch.ops.aten.to.dtype(add_tensor_43, torch.float32);  add_tensor_43 = None
        to_dtype_137 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_32 = torch.ops.aten.le.Scalar(to_dtype_137, 0);  to_dtype_137 = None
        new_zeros_default_178 = torch.ops.aten.new_zeros.default(to_dtype_136, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_60 = torch.ops.aten.where.self(le_scalar_32, new_zeros_default_178, to_dtype_136);  le_scalar_32 = new_zeros_default_178 = to_dtype_136 = None
        to_dtype_138 = torch.ops.aten.to.dtype(where_self_60, torch.float32);  where_self_60 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_138, convolution_default_10, primals_204, primals_202, primals_203, new_zeros_default_30, new_zeros_default_31, False, 0.001, [True, True, True]);  to_dtype_138 = convolution_default_10 = primals_204 = primals_202 = primals_203 = new_zeros_default_30 = new_zeros_default_31 = None
        getitem_396 = native_batch_norm_backward_default_35[0]
        getitem_397 = native_batch_norm_backward_default_35[1]
        getitem_398 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        convolution_backward_default_51 = torch.ops.aten.convolution_backward.default(getitem_396, relu__default_5, primals_199, [0], [2, 2], [2, 2], [1, 1], False, [0, 0], 72, [True, True, False]);  getitem_396 = primals_199 = None
        getitem_399 = convolution_backward_default_51[0]
        getitem_400 = convolution_backward_default_51[1];  convolution_backward_default_51 = None
        to_dtype_139 = torch.ops.aten.to.dtype(getitem_399, torch.float32);  getitem_399 = None
        to_dtype_140 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_33 = torch.ops.aten.le.Scalar(to_dtype_140, 0);  to_dtype_140 = None
        new_zeros_default_179 = torch.ops.aten.new_zeros.default(to_dtype_139, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_61 = torch.ops.aten.where.self(le_scalar_33, new_zeros_default_179, to_dtype_139);  le_scalar_33 = new_zeros_default_179 = to_dtype_139 = None
        to_dtype_141 = torch.ops.aten.to.dtype(where_self_61, torch.float32);  where_self_61 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_141, convolution_default_9, primals_198, primals_196, primals_197, new_zeros_default_27, new_zeros_default_28, False, 0.001, [True, True, True]);  to_dtype_141 = convolution_default_9 = primals_198 = primals_196 = primals_197 = new_zeros_default_27 = new_zeros_default_28 = None
        getitem_402 = native_batch_norm_backward_default_36[0]
        getitem_403 = native_batch_norm_backward_default_36[1]
        getitem_404 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        convolution_backward_default_52 = torch.ops.aten.convolution_backward.default(getitem_402, add__tensor_1, primals_193, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_402 = add__tensor_1 = primals_193 = None
        getitem_405 = convolution_backward_default_52[0]
        getitem_406 = convolution_backward_default_52[1];  convolution_backward_default_52 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(getitem_405, convolution_default_8, primals_192, primals_190, primals_191, new_zeros_default_24, new_zeros_default_25, False, 0.001, [True, True, True]);  convolution_default_8 = primals_192 = primals_190 = primals_191 = new_zeros_default_24 = new_zeros_default_25 = None
        getitem_408 = native_batch_norm_backward_default_37[0]
        getitem_409 = native_batch_norm_backward_default_37[1]
        getitem_410 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        convolution_backward_default_53 = torch.ops.aten.convolution_backward.default(getitem_408, relu__default_4, primals_187, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_408 = primals_187 = None
        getitem_411 = convolution_backward_default_53[0]
        getitem_412 = convolution_backward_default_53[1];  convolution_backward_default_53 = None
        to_dtype_142 = torch.ops.aten.to.dtype(getitem_411, torch.float32);  getitem_411 = None
        to_dtype_143 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_34 = torch.ops.aten.le.Scalar(to_dtype_143, 0);  to_dtype_143 = None
        new_zeros_default_180 = torch.ops.aten.new_zeros.default(to_dtype_142, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_62 = torch.ops.aten.where.self(le_scalar_34, new_zeros_default_180, to_dtype_142);  le_scalar_34 = new_zeros_default_180 = to_dtype_142 = None
        to_dtype_144 = torch.ops.aten.to.dtype(where_self_62, torch.float32);  where_self_62 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_144, convolution_default_7, primals_186, primals_184, primals_185, new_zeros_default_21, new_zeros_default_22, False, 0.001, [True, True, True]);  to_dtype_144 = convolution_default_7 = primals_186 = primals_184 = primals_185 = new_zeros_default_21 = new_zeros_default_22 = None
        getitem_414 = native_batch_norm_backward_default_38[0]
        getitem_415 = native_batch_norm_backward_default_38[1]
        getitem_416 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        convolution_backward_default_54 = torch.ops.aten.convolution_backward.default(getitem_414, relu__default_3, primals_181, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 72, [True, True, False]);  getitem_414 = primals_181 = None
        getitem_417 = convolution_backward_default_54[0]
        getitem_418 = convolution_backward_default_54[1];  convolution_backward_default_54 = None
        to_dtype_145 = torch.ops.aten.to.dtype(getitem_417, torch.float32);  getitem_417 = None
        to_dtype_146 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_35 = torch.ops.aten.le.Scalar(to_dtype_146, 0);  to_dtype_146 = None
        new_zeros_default_181 = torch.ops.aten.new_zeros.default(to_dtype_145, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_63 = torch.ops.aten.where.self(le_scalar_35, new_zeros_default_181, to_dtype_145);  le_scalar_35 = new_zeros_default_181 = to_dtype_145 = None
        to_dtype_147 = torch.ops.aten.to.dtype(where_self_63, torch.float32);  where_self_63 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_147, convolution_default_6, primals_180, primals_178, primals_179, new_zeros_default_18, new_zeros_default_19, False, 0.001, [True, True, True]);  to_dtype_147 = convolution_default_6 = primals_180 = primals_178 = primals_179 = new_zeros_default_18 = new_zeros_default_19 = None
        getitem_420 = native_batch_norm_backward_default_39[0]
        getitem_421 = native_batch_norm_backward_default_39[1]
        getitem_422 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        convolution_backward_default_55 = torch.ops.aten.convolution_backward.default(getitem_420, getitem_15, primals_175, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_420 = getitem_15 = primals_175 = None
        getitem_423 = convolution_backward_default_55[0]
        getitem_424 = convolution_backward_default_55[1];  convolution_backward_default_55 = None
        add_tensor_44 = torch.ops.aten.add.Tensor(getitem_405, getitem_423);  getitem_405 = getitem_423 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_44, convolution_default_5, primals_174, primals_172, primals_173, new_zeros_default_15, new_zeros_default_16, False, 0.001, [True, True, True]);  add_tensor_44 = convolution_default_5 = primals_174 = primals_172 = primals_173 = new_zeros_default_15 = new_zeros_default_16 = None
        getitem_426 = native_batch_norm_backward_default_40[0]
        getitem_427 = native_batch_norm_backward_default_40[1]
        getitem_428 = native_batch_norm_backward_default_40[2];  native_batch_norm_backward_default_40 = None
        convolution_backward_default_56 = torch.ops.aten.convolution_backward.default(getitem_426, relu__default_2, primals_169, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_426 = primals_169 = None
        getitem_429 = convolution_backward_default_56[0]
        getitem_430 = convolution_backward_default_56[1];  convolution_backward_default_56 = None
        to_dtype_148 = torch.ops.aten.to.dtype(getitem_429, torch.float32);  getitem_429 = None
        to_dtype_149 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_36 = torch.ops.aten.le.Scalar(to_dtype_149, 0);  to_dtype_149 = None
        new_zeros_default_182 = torch.ops.aten.new_zeros.default(to_dtype_148, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_64 = torch.ops.aten.where.self(le_scalar_36, new_zeros_default_182, to_dtype_148);  le_scalar_36 = new_zeros_default_182 = to_dtype_148 = None
        to_dtype_150 = torch.ops.aten.to.dtype(where_self_64, torch.float32);  where_self_64 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_150, convolution_default_4, primals_168, primals_166, primals_167, new_zeros_default_12, new_zeros_default_13, False, 0.001, [True, True, True]);  to_dtype_150 = convolution_default_4 = primals_168 = primals_166 = primals_167 = new_zeros_default_12 = new_zeros_default_13 = None
        getitem_432 = native_batch_norm_backward_default_41[0]
        getitem_433 = native_batch_norm_backward_default_41[1]
        getitem_434 = native_batch_norm_backward_default_41[2];  native_batch_norm_backward_default_41 = None
        convolution_backward_default_57 = torch.ops.aten.convolution_backward.default(getitem_432, relu__default_1, primals_163, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 64, [True, True, False]);  getitem_432 = primals_163 = None
        getitem_435 = convolution_backward_default_57[0]
        getitem_436 = convolution_backward_default_57[1];  convolution_backward_default_57 = None
        to_dtype_151 = torch.ops.aten.to.dtype(getitem_435, torch.float32);  getitem_435 = None
        to_dtype_152 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_37 = torch.ops.aten.le.Scalar(to_dtype_152, 0);  to_dtype_152 = None
        new_zeros_default_183 = torch.ops.aten.new_zeros.default(to_dtype_151, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_65 = torch.ops.aten.where.self(le_scalar_37, new_zeros_default_183, to_dtype_151);  le_scalar_37 = new_zeros_default_183 = to_dtype_151 = None
        to_dtype_153 = torch.ops.aten.to.dtype(where_self_65, torch.float32);  where_self_65 = None
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_153, convolution_default_3, primals_162, primals_160, primals_161, new_zeros_default_9, new_zeros_default_10, False, 0.001, [True, True, True]);  to_dtype_153 = convolution_default_3 = primals_162 = primals_160 = primals_161 = new_zeros_default_9 = new_zeros_default_10 = None
        getitem_438 = native_batch_norm_backward_default_42[0]
        getitem_439 = native_batch_norm_backward_default_42[1]
        getitem_440 = native_batch_norm_backward_default_42[2];  native_batch_norm_backward_default_42 = None
        convolution_backward_default_58 = torch.ops.aten.convolution_backward.default(getitem_438, add__tensor, primals_157, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_438 = add__tensor = primals_157 = None
        getitem_441 = convolution_backward_default_58[0]
        getitem_442 = convolution_backward_default_58[1];  convolution_backward_default_58 = None
        native_batch_norm_backward_default_43 = torch.ops.aten.native_batch_norm_backward.default(getitem_441, convolution_default_2, primals_156, primals_154, primals_155, new_zeros_default_6, new_zeros_default_7, False, 0.001, [True, True, True]);  convolution_default_2 = primals_156 = primals_154 = primals_155 = new_zeros_default_6 = new_zeros_default_7 = None
        getitem_444 = native_batch_norm_backward_default_43[0]
        getitem_445 = native_batch_norm_backward_default_43[1]
        getitem_446 = native_batch_norm_backward_default_43[2];  native_batch_norm_backward_default_43 = None
        convolution_backward_default_59 = torch.ops.aten.convolution_backward.default(getitem_444, relu__default, primals_151, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_444 = primals_151 = None
        getitem_447 = convolution_backward_default_59[0]
        getitem_448 = convolution_backward_default_59[1];  convolution_backward_default_59 = None
        to_dtype_154 = torch.ops.aten.to.dtype(getitem_447, torch.float32);  getitem_447 = None
        to_dtype_155 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_38 = torch.ops.aten.le.Scalar(to_dtype_155, 0);  to_dtype_155 = None
        new_zeros_default_184 = torch.ops.aten.new_zeros.default(to_dtype_154, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_66 = torch.ops.aten.where.self(le_scalar_38, new_zeros_default_184, to_dtype_154);  le_scalar_38 = new_zeros_default_184 = to_dtype_154 = None
        to_dtype_156 = torch.ops.aten.to.dtype(where_self_66, torch.float32);  where_self_66 = None
        native_batch_norm_backward_default_44 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_156, convolution_default_1, primals_150, primals_148, primals_149, new_zeros_default_3, new_zeros_default_4, False, 0.001, [True, True, True]);  to_dtype_156 = convolution_default_1 = primals_150 = primals_148 = primals_149 = new_zeros_default_3 = new_zeros_default_4 = None
        getitem_450 = native_batch_norm_backward_default_44[0]
        getitem_451 = native_batch_norm_backward_default_44[1]
        getitem_452 = native_batch_norm_backward_default_44[2];  native_batch_norm_backward_default_44 = None
        convolution_backward_default_60 = torch.ops.aten.convolution_backward.default(getitem_450, hardswish__default, primals_145, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 16, [True, True, False]);  getitem_450 = hardswish__default = primals_145 = None
        getitem_453 = convolution_backward_default_60[0]
        getitem_454 = convolution_backward_default_60[1];  convolution_backward_default_60 = None
        add_tensor_45 = torch.ops.aten.add.Tensor(getitem_441, getitem_453);  getitem_441 = getitem_453 = None
        to_dtype_157 = torch.ops.aten.to.dtype(add_tensor_45, torch.float32);  add_tensor_45 = None
        to_dtype_158 = torch.ops.aten.to.dtype(clone_default, torch.float32);  clone_default = None
        lt_scalar_28 = torch.ops.aten.lt.Scalar(to_dtype_158, -3)
        new_zeros_default_185 = torch.ops.aten.new_zeros.default(to_dtype_157, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_39 = torch.ops.aten.le.Scalar(to_dtype_158, 3)
        div_tensor_28 = torch.ops.aten.div.Tensor(to_dtype_158, 3);  to_dtype_158 = None
        add_tensor_46 = torch.ops.aten.add.Tensor(div_tensor_28, 0.5);  div_tensor_28 = None
        mul_tensor_52 = torch.ops.aten.mul.Tensor(to_dtype_157, add_tensor_46);  add_tensor_46 = None
        where_self_67 = torch.ops.aten.where.self(le_scalar_39, mul_tensor_52, to_dtype_157);  le_scalar_39 = mul_tensor_52 = to_dtype_157 = None
        where_self_68 = torch.ops.aten.where.self(lt_scalar_28, new_zeros_default_185, where_self_67);  lt_scalar_28 = new_zeros_default_185 = where_self_67 = None
        to_dtype_159 = torch.ops.aten.to.dtype(where_self_68, torch.float32);  where_self_68 = None
        native_batch_norm_backward_default_45 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_159, convolution_default, primals_10, primals_8, primals_9, new_zeros_default, new_zeros_default_1, False, 0.001, [True, True, True]);  to_dtype_159 = convolution_default = primals_10 = primals_8 = primals_9 = new_zeros_default = new_zeros_default_1 = None
        getitem_456 = native_batch_norm_backward_default_45[0]
        getitem_457 = native_batch_norm_backward_default_45[1]
        getitem_458 = native_batch_norm_backward_default_45[2];  native_batch_norm_backward_default_45 = None
        convolution_backward_default_61 = torch.ops.aten.convolution_backward.default(getitem_456, primals_313, primals_5, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_456 = primals_313 = primals_5 = None
        getitem_460 = convolution_backward_default_61[1];  convolution_backward_default_61 = None
        return [view_default_2, t_default_9, view_default_1, t_default_5, getitem_460, getitem_458, None, None, None, getitem_457, getitem_280, getitem_278, None, None, None, getitem_277, getitem_274, getitem_272, None, None, None, getitem_271, getitem_268, getitem_266, None, None, None, getitem_265, getitem_262, getitem_260, None, None, None, getitem_259, getitem_256, getitem_254, None, None, None, getitem_253, getitem_251, getitem_250, getitem_248, getitem_247, getitem_244, getitem_242, None, None, None, getitem_241, getitem_238, getitem_236, None, None, None, getitem_235, getitem_232, getitem_230, None, None, None, getitem_229, getitem_227, getitem_226, getitem_224, getitem_223, getitem_220, getitem_218, None, None, None, getitem_217, getitem_214, getitem_212, None, None, None, getitem_211, getitem_208, getitem_206, None, None, None, getitem_205, getitem_203, getitem_202, getitem_200, getitem_199, getitem_196, getitem_194, None, None, None, getitem_193, getitem_190, getitem_188, None, None, None, getitem_187, getitem_184, getitem_182, None, None, None, getitem_181, getitem_179, getitem_178, getitem_176, getitem_175, getitem_172, getitem_170, None, None, None, getitem_169, getitem_166, getitem_164, None, None, None, getitem_163, getitem_160, getitem_158, None, None, None, getitem_157, getitem_155, getitem_154, getitem_152, getitem_151, getitem_148, getitem_146, None, None, None, getitem_145, getitem_142, getitem_140, None, None, None, getitem_139, getitem_454, getitem_452, None, None, None, getitem_451, getitem_448, getitem_446, None, None, None, getitem_445, getitem_442, getitem_440, None, None, None, getitem_439, getitem_436, getitem_434, None, None, None, getitem_433, getitem_430, getitem_428, None, None, None, getitem_427, getitem_424, getitem_422, None, None, None, getitem_421, getitem_418, getitem_416, None, None, None, getitem_415, getitem_412, getitem_410, None, None, None, getitem_409, getitem_406, getitem_404, None, None, None, getitem_403, getitem_400, getitem_398, None, None, None, getitem_397, getitem_395, getitem_394, getitem_392, getitem_391, getitem_388, getitem_386, None, None, None, getitem_385, getitem_382, getitem_380, None, None, None, getitem_379, getitem_376, getitem_374, None, None, None, getitem_373, getitem_371, getitem_370, getitem_368, getitem_367, getitem_364, getitem_362, None, None, None, getitem_361, getitem_358, getitem_356, None, None, None, getitem_355, getitem_352, getitem_350, None, None, None, getitem_349, getitem_347, getitem_346, getitem_344, getitem_343, getitem_340, getitem_338, None, None, None, getitem_337, getitem_334, getitem_332, None, None, None, getitem_331, getitem_328, getitem_326, None, None, None, getitem_325, getitem_322, getitem_320, None, None, None, getitem_319, getitem_316, getitem_314, None, None, None, getitem_313, getitem_310, getitem_308, None, None, None, getitem_307, getitem_304, getitem_302, None, None, None, getitem_301, getitem_298, getitem_296, None, None, None, getitem_295, getitem_292, getitem_290, None, None, None, getitem_289, getitem_286, getitem_284, None, None, None, getitem_283, None]
        
