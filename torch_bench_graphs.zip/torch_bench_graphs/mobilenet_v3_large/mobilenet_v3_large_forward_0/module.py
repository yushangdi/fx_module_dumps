
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/mobilenet_v3_large/mobilenet_v3_large_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313):
        convolution_default = torch.ops.aten.convolution.default(primals_313, primals_5, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_10, primals_6, primals_8, primals_9, False, 0.01, 0.001);  primals_6 = None
        getitem = native_batch_norm_default[0];  native_batch_norm_default = None
        hardswish__default = torch.ops.aten.hardswish_.default(getitem)
        convolution_default_1 = torch.ops.aten.convolution.default(hardswish__default, primals_145, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 16)
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_150, primals_146, primals_148, primals_149, False, 0.01, 0.001);  primals_146 = None
        getitem_3 = native_batch_norm_default_1[0];  native_batch_norm_default_1 = None
        relu__default = torch.ops.aten.relu_.default(getitem_3);  getitem_3 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default, primals_151, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_156, primals_152, primals_154, primals_155, False, 0.01, 0.001);  primals_152 = None
        getitem_6 = native_batch_norm_default_2[0];  native_batch_norm_default_2 = None
        add__tensor = torch.ops.aten.add_.Tensor(getitem_6, hardswish__default);  getitem_6 = None
        convolution_default_3 = torch.ops.aten.convolution.default(add__tensor, primals_157, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_162, primals_158, primals_160, primals_161, False, 0.01, 0.001);  primals_158 = None
        getitem_9 = native_batch_norm_default_3[0];  native_batch_norm_default_3 = None
        relu__default_1 = torch.ops.aten.relu_.default(getitem_9);  getitem_9 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu__default_1, primals_163, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_168, primals_164, primals_166, primals_167, False, 0.01, 0.001);  primals_164 = None
        getitem_12 = native_batch_norm_default_4[0];  native_batch_norm_default_4 = None
        relu__default_2 = torch.ops.aten.relu_.default(getitem_12);  getitem_12 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_2, primals_169, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_174, primals_170, primals_172, primals_173, False, 0.01, 0.001);  primals_170 = None
        getitem_15 = native_batch_norm_default_5[0];  native_batch_norm_default_5 = None
        convolution_default_6 = torch.ops.aten.convolution.default(getitem_15, primals_175, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_180, primals_176, primals_178, primals_179, False, 0.01, 0.001);  primals_176 = None
        getitem_18 = native_batch_norm_default_6[0];  native_batch_norm_default_6 = None
        relu__default_3 = torch.ops.aten.relu_.default(getitem_18);  getitem_18 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_3, primals_181, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 72)
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_186, primals_182, primals_184, primals_185, False, 0.01, 0.001);  primals_182 = None
        getitem_21 = native_batch_norm_default_7[0];  native_batch_norm_default_7 = None
        relu__default_4 = torch.ops.aten.relu_.default(getitem_21);  getitem_21 = None
        convolution_default_8 = torch.ops.aten.convolution.default(relu__default_4, primals_187, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_192, primals_188, primals_190, primals_191, False, 0.01, 0.001);  primals_188 = None
        getitem_24 = native_batch_norm_default_8[0];  native_batch_norm_default_8 = None
        add__tensor_1 = torch.ops.aten.add_.Tensor(getitem_24, getitem_15);  getitem_24 = None
        convolution_default_9 = torch.ops.aten.convolution.default(add__tensor_1, primals_193, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_198, primals_194, primals_196, primals_197, False, 0.01, 0.001);  primals_194 = None
        getitem_27 = native_batch_norm_default_9[0];  native_batch_norm_default_9 = None
        relu__default_5 = torch.ops.aten.relu_.default(getitem_27);  getitem_27 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default_5, primals_199, None, [2, 2], [2, 2], [1, 1], False, [0, 0], 72)
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_204, primals_200, primals_202, primals_203, False, 0.01, 0.001);  primals_200 = None
        getitem_30 = native_batch_norm_default_10[0];  native_batch_norm_default_10 = None
        relu__default_6 = torch.ops.aten.relu_.default(getitem_30);  getitem_30 = None
        mean_dim = torch.ops.aten.mean.dim(relu__default_6, [-1, -2], True)
        convolution_default_11 = torch.ops.aten.convolution.default(mean_dim, primals_206, primals_205, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_205 = None
        relu_default = torch.ops.aten.relu.default(convolution_default_11);  convolution_default_11 = None
        convolution_default_12 = torch.ops.aten.convolution.default(relu_default, primals_208, primals_207, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_207 = None
        to_dtype = torch.ops.aten.to.dtype(convolution_default_12, torch.float32)
        add_tensor = torch.ops.aten.add.Tensor(to_dtype, 3);  to_dtype = None
        clamp_default = torch.ops.aten.clamp.default(add_tensor, 0);  add_tensor = None
        clamp_default_1 = torch.ops.aten.clamp.default(clamp_default, None, 6);  clamp_default = None
        div_tensor = torch.ops.aten.div.Tensor(clamp_default_1, 6);  clamp_default_1 = None
        to_dtype_1 = torch.ops.aten.to.dtype(div_tensor, torch.float32);  div_tensor = None
        mul_tensor = torch.ops.aten.mul.Tensor(to_dtype_1, relu__default_6)
        convolution_default_13 = torch.ops.aten.convolution.default(mul_tensor, primals_209, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_214, primals_210, primals_212, primals_213, False, 0.01, 0.001);  primals_210 = None
        getitem_33 = native_batch_norm_default_11[0];  native_batch_norm_default_11 = None
        convolution_default_14 = torch.ops.aten.convolution.default(getitem_33, primals_215, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_220, primals_216, primals_218, primals_219, False, 0.01, 0.001);  primals_216 = None
        getitem_36 = native_batch_norm_default_12[0];  native_batch_norm_default_12 = None
        relu__default_7 = torch.ops.aten.relu_.default(getitem_36);  getitem_36 = None
        convolution_default_15 = torch.ops.aten.convolution.default(relu__default_7, primals_221, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 120)
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_226, primals_222, primals_224, primals_225, False, 0.01, 0.001);  primals_222 = None
        getitem_39 = native_batch_norm_default_13[0];  native_batch_norm_default_13 = None
        relu__default_8 = torch.ops.aten.relu_.default(getitem_39);  getitem_39 = None
        mean_dim_1 = torch.ops.aten.mean.dim(relu__default_8, [-1, -2], True)
        convolution_default_16 = torch.ops.aten.convolution.default(mean_dim_1, primals_228, primals_227, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_227 = None
        relu_default_1 = torch.ops.aten.relu.default(convolution_default_16);  convolution_default_16 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu_default_1, primals_230, primals_229, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_229 = None
        to_dtype_2 = torch.ops.aten.to.dtype(convolution_default_17, torch.float32)
        add_tensor_1 = torch.ops.aten.add.Tensor(to_dtype_2, 3);  to_dtype_2 = None
        clamp_default_2 = torch.ops.aten.clamp.default(add_tensor_1, 0);  add_tensor_1 = None
        clamp_default_3 = torch.ops.aten.clamp.default(clamp_default_2, None, 6);  clamp_default_2 = None
        div_tensor_1 = torch.ops.aten.div.Tensor(clamp_default_3, 6);  clamp_default_3 = None
        to_dtype_3 = torch.ops.aten.to.dtype(div_tensor_1, torch.float32);  div_tensor_1 = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(to_dtype_3, relu__default_8)
        convolution_default_18 = torch.ops.aten.convolution.default(mul_tensor_1, primals_231, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_236, primals_232, primals_234, primals_235, False, 0.01, 0.001);  primals_232 = None
        getitem_42 = native_batch_norm_default_14[0];  native_batch_norm_default_14 = None
        add__tensor_2 = torch.ops.aten.add_.Tensor(getitem_42, getitem_33);  getitem_42 = None
        convolution_default_19 = torch.ops.aten.convolution.default(add__tensor_2, primals_237, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_242, primals_238, primals_240, primals_241, False, 0.01, 0.001);  primals_238 = None
        getitem_45 = native_batch_norm_default_15[0];  native_batch_norm_default_15 = None
        relu__default_9 = torch.ops.aten.relu_.default(getitem_45);  getitem_45 = None
        convolution_default_20 = torch.ops.aten.convolution.default(relu__default_9, primals_243, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 120)
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_248, primals_244, primals_246, primals_247, False, 0.01, 0.001);  primals_244 = None
        getitem_48 = native_batch_norm_default_16[0];  native_batch_norm_default_16 = None
        relu__default_10 = torch.ops.aten.relu_.default(getitem_48);  getitem_48 = None
        mean_dim_2 = torch.ops.aten.mean.dim(relu__default_10, [-1, -2], True)
        convolution_default_21 = torch.ops.aten.convolution.default(mean_dim_2, primals_250, primals_249, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_249 = None
        relu_default_2 = torch.ops.aten.relu.default(convolution_default_21);  convolution_default_21 = None
        convolution_default_22 = torch.ops.aten.convolution.default(relu_default_2, primals_252, primals_251, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_251 = None
        to_dtype_4 = torch.ops.aten.to.dtype(convolution_default_22, torch.float32)
        add_tensor_2 = torch.ops.aten.add.Tensor(to_dtype_4, 3);  to_dtype_4 = None
        clamp_default_4 = torch.ops.aten.clamp.default(add_tensor_2, 0);  add_tensor_2 = None
        clamp_default_5 = torch.ops.aten.clamp.default(clamp_default_4, None, 6);  clamp_default_4 = None
        div_tensor_2 = torch.ops.aten.div.Tensor(clamp_default_5, 6);  clamp_default_5 = None
        to_dtype_5 = torch.ops.aten.to.dtype(div_tensor_2, torch.float32);  div_tensor_2 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(to_dtype_5, relu__default_10)
        convolution_default_23 = torch.ops.aten.convolution.default(mul_tensor_2, primals_253, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_258, primals_254, primals_256, primals_257, False, 0.01, 0.001);  primals_254 = None
        getitem_51 = native_batch_norm_default_17[0];  native_batch_norm_default_17 = None
        add__tensor_3 = torch.ops.aten.add_.Tensor(getitem_51, add__tensor_2);  getitem_51 = None
        convolution_default_24 = torch.ops.aten.convolution.default(add__tensor_3, primals_259, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_264, primals_260, primals_262, primals_263, False, 0.01, 0.001);  primals_260 = None
        getitem_54 = native_batch_norm_default_18[0];  native_batch_norm_default_18 = None
        hardswish__default_1 = torch.ops.aten.hardswish_.default(getitem_54)
        convolution_default_25 = torch.ops.aten.convolution.default(hardswish__default_1, primals_265, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 240)
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_270, primals_266, primals_268, primals_269, False, 0.01, 0.001);  primals_266 = None
        getitem_57 = native_batch_norm_default_19[0];  native_batch_norm_default_19 = None
        hardswish__default_2 = torch.ops.aten.hardswish_.default(getitem_57)
        convolution_default_26 = torch.ops.aten.convolution.default(hardswish__default_2, primals_271, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_276, primals_272, primals_274, primals_275, False, 0.01, 0.001);  primals_272 = None
        getitem_60 = native_batch_norm_default_20[0];  native_batch_norm_default_20 = None
        convolution_default_27 = torch.ops.aten.convolution.default(getitem_60, primals_277, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_282, primals_278, primals_280, primals_281, False, 0.01, 0.001);  primals_278 = None
        getitem_63 = native_batch_norm_default_21[0];  native_batch_norm_default_21 = None
        hardswish__default_3 = torch.ops.aten.hardswish_.default(getitem_63)
        convolution_default_28 = torch.ops.aten.convolution.default(hardswish__default_3, primals_283, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 200)
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_288, primals_284, primals_286, primals_287, False, 0.01, 0.001);  primals_284 = None
        getitem_66 = native_batch_norm_default_22[0];  native_batch_norm_default_22 = None
        hardswish__default_4 = torch.ops.aten.hardswish_.default(getitem_66)
        convolution_default_29 = torch.ops.aten.convolution.default(hardswish__default_4, primals_289, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_294, primals_290, primals_292, primals_293, False, 0.01, 0.001);  primals_290 = None
        getitem_69 = native_batch_norm_default_23[0];  native_batch_norm_default_23 = None
        add__tensor_4 = torch.ops.aten.add_.Tensor(getitem_69, getitem_60);  getitem_69 = None
        convolution_default_30 = torch.ops.aten.convolution.default(add__tensor_4, primals_295, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_300, primals_296, primals_298, primals_299, False, 0.01, 0.001);  primals_296 = None
        getitem_72 = native_batch_norm_default_24[0];  native_batch_norm_default_24 = None
        hardswish__default_5 = torch.ops.aten.hardswish_.default(getitem_72)
        convolution_default_31 = torch.ops.aten.convolution.default(hardswish__default_5, primals_301, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 184)
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_31, primals_306, primals_302, primals_304, primals_305, False, 0.01, 0.001);  primals_302 = None
        getitem_75 = native_batch_norm_default_25[0];  native_batch_norm_default_25 = None
        hardswish__default_6 = torch.ops.aten.hardswish_.default(getitem_75)
        convolution_default_32 = torch.ops.aten.convolution.default(hardswish__default_6, primals_307, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_312, primals_308, primals_310, primals_311, False, 0.01, 0.001);  primals_308 = None
        getitem_78 = native_batch_norm_default_26[0];  native_batch_norm_default_26 = None
        add__tensor_5 = torch.ops.aten.add_.Tensor(getitem_78, add__tensor_4);  getitem_78 = None
        convolution_default_33 = torch.ops.aten.convolution.default(add__tensor_5, primals_11, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_16, primals_12, primals_14, primals_15, False, 0.01, 0.001);  primals_12 = None
        getitem_81 = native_batch_norm_default_27[0];  native_batch_norm_default_27 = None
        hardswish__default_7 = torch.ops.aten.hardswish_.default(getitem_81)
        convolution_default_34 = torch.ops.aten.convolution.default(hardswish__default_7, primals_17, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 184)
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_22, primals_18, primals_20, primals_21, False, 0.01, 0.001);  primals_18 = None
        getitem_84 = native_batch_norm_default_28[0];  native_batch_norm_default_28 = None
        hardswish__default_8 = torch.ops.aten.hardswish_.default(getitem_84)
        convolution_default_35 = torch.ops.aten.convolution.default(hardswish__default_8, primals_23, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_28, primals_24, primals_26, primals_27, False, 0.01, 0.001);  primals_24 = None
        getitem_87 = native_batch_norm_default_29[0];  native_batch_norm_default_29 = None
        add__tensor_6 = torch.ops.aten.add_.Tensor(getitem_87, add__tensor_5);  getitem_87 = None
        convolution_default_36 = torch.ops.aten.convolution.default(add__tensor_6, primals_29, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_34, primals_30, primals_32, primals_33, False, 0.01, 0.001);  primals_30 = None
        getitem_90 = native_batch_norm_default_30[0];  native_batch_norm_default_30 = None
        hardswish__default_9 = torch.ops.aten.hardswish_.default(getitem_90)
        convolution_default_37 = torch.ops.aten.convolution.default(hardswish__default_9, primals_35, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 480)
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_37, primals_40, primals_36, primals_38, primals_39, False, 0.01, 0.001);  primals_36 = None
        getitem_93 = native_batch_norm_default_31[0];  native_batch_norm_default_31 = None
        hardswish__default_10 = torch.ops.aten.hardswish_.default(getitem_93)
        mean_dim_3 = torch.ops.aten.mean.dim(hardswish__default_10, [-1, -2], True)
        convolution_default_38 = torch.ops.aten.convolution.default(mean_dim_3, primals_42, primals_41, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_41 = None
        relu_default_3 = torch.ops.aten.relu.default(convolution_default_38);  convolution_default_38 = None
        convolution_default_39 = torch.ops.aten.convolution.default(relu_default_3, primals_44, primals_43, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_43 = None
        to_dtype_6 = torch.ops.aten.to.dtype(convolution_default_39, torch.float32)
        add_tensor_3 = torch.ops.aten.add.Tensor(to_dtype_6, 3);  to_dtype_6 = None
        clamp_default_6 = torch.ops.aten.clamp.default(add_tensor_3, 0);  add_tensor_3 = None
        clamp_default_7 = torch.ops.aten.clamp.default(clamp_default_6, None, 6);  clamp_default_6 = None
        div_tensor_3 = torch.ops.aten.div.Tensor(clamp_default_7, 6);  clamp_default_7 = None
        to_dtype_7 = torch.ops.aten.to.dtype(div_tensor_3, torch.float32);  div_tensor_3 = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(to_dtype_7, hardswish__default_10)
        convolution_default_40 = torch.ops.aten.convolution.default(mul_tensor_3, primals_45, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_50, primals_46, primals_48, primals_49, False, 0.01, 0.001);  primals_46 = None
        getitem_96 = native_batch_norm_default_32[0];  native_batch_norm_default_32 = None
        convolution_default_41 = torch.ops.aten.convolution.default(getitem_96, primals_51, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_41, primals_56, primals_52, primals_54, primals_55, False, 0.01, 0.001);  primals_52 = None
        getitem_99 = native_batch_norm_default_33[0];  native_batch_norm_default_33 = None
        hardswish__default_11 = torch.ops.aten.hardswish_.default(getitem_99)
        convolution_default_42 = torch.ops.aten.convolution.default(hardswish__default_11, primals_57, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_42, primals_62, primals_58, primals_60, primals_61, False, 0.01, 0.001);  primals_58 = None
        getitem_102 = native_batch_norm_default_34[0];  native_batch_norm_default_34 = None
        hardswish__default_12 = torch.ops.aten.hardswish_.default(getitem_102)
        mean_dim_4 = torch.ops.aten.mean.dim(hardswish__default_12, [-1, -2], True)
        convolution_default_43 = torch.ops.aten.convolution.default(mean_dim_4, primals_64, primals_63, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_63 = None
        relu_default_4 = torch.ops.aten.relu.default(convolution_default_43);  convolution_default_43 = None
        convolution_default_44 = torch.ops.aten.convolution.default(relu_default_4, primals_66, primals_65, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_65 = None
        to_dtype_8 = torch.ops.aten.to.dtype(convolution_default_44, torch.float32)
        add_tensor_4 = torch.ops.aten.add.Tensor(to_dtype_8, 3);  to_dtype_8 = None
        clamp_default_8 = torch.ops.aten.clamp.default(add_tensor_4, 0);  add_tensor_4 = None
        clamp_default_9 = torch.ops.aten.clamp.default(clamp_default_8, None, 6);  clamp_default_8 = None
        div_tensor_4 = torch.ops.aten.div.Tensor(clamp_default_9, 6);  clamp_default_9 = None
        to_dtype_9 = torch.ops.aten.to.dtype(div_tensor_4, torch.float32);  div_tensor_4 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(to_dtype_9, hardswish__default_12)
        convolution_default_45 = torch.ops.aten.convolution.default(mul_tensor_4, primals_67, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_45, primals_72, primals_68, primals_70, primals_71, False, 0.01, 0.001);  primals_68 = None
        getitem_105 = native_batch_norm_default_35[0];  native_batch_norm_default_35 = None
        add__tensor_7 = torch.ops.aten.add_.Tensor(getitem_105, getitem_96);  getitem_105 = None
        convolution_default_46 = torch.ops.aten.convolution.default(add__tensor_7, primals_73, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_46, primals_78, primals_74, primals_76, primals_77, False, 0.01, 0.001);  primals_74 = None
        getitem_108 = native_batch_norm_default_36[0];  native_batch_norm_default_36 = None
        hardswish__default_13 = torch.ops.aten.hardswish_.default(getitem_108)
        convolution_default_47 = torch.ops.aten.convolution.default(hardswish__default_13, primals_79, None, [2, 2], [2, 2], [1, 1], False, [0, 0], 672)
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_47, primals_84, primals_80, primals_82, primals_83, False, 0.01, 0.001);  primals_80 = None
        getitem_111 = native_batch_norm_default_37[0];  native_batch_norm_default_37 = None
        hardswish__default_14 = torch.ops.aten.hardswish_.default(getitem_111)
        mean_dim_5 = torch.ops.aten.mean.dim(hardswish__default_14, [-1, -2], True)
        convolution_default_48 = torch.ops.aten.convolution.default(mean_dim_5, primals_86, primals_85, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_85 = None
        relu_default_5 = torch.ops.aten.relu.default(convolution_default_48);  convolution_default_48 = None
        convolution_default_49 = torch.ops.aten.convolution.default(relu_default_5, primals_88, primals_87, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_87 = None
        to_dtype_10 = torch.ops.aten.to.dtype(convolution_default_49, torch.float32)
        add_tensor_5 = torch.ops.aten.add.Tensor(to_dtype_10, 3);  to_dtype_10 = None
        clamp_default_10 = torch.ops.aten.clamp.default(add_tensor_5, 0);  add_tensor_5 = None
        clamp_default_11 = torch.ops.aten.clamp.default(clamp_default_10, None, 6);  clamp_default_10 = None
        div_tensor_5 = torch.ops.aten.div.Tensor(clamp_default_11, 6);  clamp_default_11 = None
        to_dtype_11 = torch.ops.aten.to.dtype(div_tensor_5, torch.float32);  div_tensor_5 = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(to_dtype_11, hardswish__default_14)
        convolution_default_50 = torch.ops.aten.convolution.default(mul_tensor_5, primals_89, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_50, primals_94, primals_90, primals_92, primals_93, False, 0.01, 0.001);  primals_90 = None
        getitem_114 = native_batch_norm_default_38[0];  native_batch_norm_default_38 = None
        convolution_default_51 = torch.ops.aten.convolution.default(getitem_114, primals_95, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_51, primals_100, primals_96, primals_98, primals_99, False, 0.01, 0.001);  primals_96 = None
        getitem_117 = native_batch_norm_default_39[0];  native_batch_norm_default_39 = None
        hardswish__default_15 = torch.ops.aten.hardswish_.default(getitem_117)
        convolution_default_52 = torch.ops.aten.convolution.default(hardswish__default_15, primals_101, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 960)
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_52, primals_106, primals_102, primals_104, primals_105, False, 0.01, 0.001);  primals_102 = None
        getitem_120 = native_batch_norm_default_40[0];  native_batch_norm_default_40 = None
        hardswish__default_16 = torch.ops.aten.hardswish_.default(getitem_120)
        mean_dim_6 = torch.ops.aten.mean.dim(hardswish__default_16, [-1, -2], True)
        convolution_default_53 = torch.ops.aten.convolution.default(mean_dim_6, primals_108, primals_107, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_107 = None
        relu_default_6 = torch.ops.aten.relu.default(convolution_default_53);  convolution_default_53 = None
        convolution_default_54 = torch.ops.aten.convolution.default(relu_default_6, primals_110, primals_109, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_109 = None
        to_dtype_12 = torch.ops.aten.to.dtype(convolution_default_54, torch.float32)
        add_tensor_6 = torch.ops.aten.add.Tensor(to_dtype_12, 3);  to_dtype_12 = None
        clamp_default_12 = torch.ops.aten.clamp.default(add_tensor_6, 0);  add_tensor_6 = None
        clamp_default_13 = torch.ops.aten.clamp.default(clamp_default_12, None, 6);  clamp_default_12 = None
        div_tensor_6 = torch.ops.aten.div.Tensor(clamp_default_13, 6);  clamp_default_13 = None
        to_dtype_13 = torch.ops.aten.to.dtype(div_tensor_6, torch.float32);  div_tensor_6 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(to_dtype_13, hardswish__default_16)
        convolution_default_55 = torch.ops.aten.convolution.default(mul_tensor_6, primals_111, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_55, primals_116, primals_112, primals_114, primals_115, False, 0.01, 0.001);  primals_112 = None
        getitem_123 = native_batch_norm_default_41[0];  native_batch_norm_default_41 = None
        add__tensor_8 = torch.ops.aten.add_.Tensor(getitem_123, getitem_114);  getitem_123 = None
        convolution_default_56 = torch.ops.aten.convolution.default(add__tensor_8, primals_117, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_56, primals_122, primals_118, primals_120, primals_121, False, 0.01, 0.001);  primals_118 = None
        getitem_126 = native_batch_norm_default_42[0];  native_batch_norm_default_42 = None
        hardswish__default_17 = torch.ops.aten.hardswish_.default(getitem_126)
        convolution_default_57 = torch.ops.aten.convolution.default(hardswish__default_17, primals_123, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 960)
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_57, primals_128, primals_124, primals_126, primals_127, False, 0.01, 0.001);  primals_124 = None
        getitem_129 = native_batch_norm_default_43[0];  native_batch_norm_default_43 = None
        hardswish__default_18 = torch.ops.aten.hardswish_.default(getitem_129)
        mean_dim_7 = torch.ops.aten.mean.dim(hardswish__default_18, [-1, -2], True)
        convolution_default_58 = torch.ops.aten.convolution.default(mean_dim_7, primals_130, primals_129, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_129 = None
        relu_default_7 = torch.ops.aten.relu.default(convolution_default_58);  convolution_default_58 = None
        convolution_default_59 = torch.ops.aten.convolution.default(relu_default_7, primals_132, primals_131, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_131 = None
        to_dtype_14 = torch.ops.aten.to.dtype(convolution_default_59, torch.float32)
        add_tensor_7 = torch.ops.aten.add.Tensor(to_dtype_14, 3);  to_dtype_14 = None
        clamp_default_14 = torch.ops.aten.clamp.default(add_tensor_7, 0);  add_tensor_7 = None
        clamp_default_15 = torch.ops.aten.clamp.default(clamp_default_14, None, 6);  clamp_default_14 = None
        div_tensor_7 = torch.ops.aten.div.Tensor(clamp_default_15, 6);  clamp_default_15 = None
        to_dtype_15 = torch.ops.aten.to.dtype(div_tensor_7, torch.float32);  div_tensor_7 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(to_dtype_15, hardswish__default_18)
        convolution_default_60 = torch.ops.aten.convolution.default(mul_tensor_7, primals_133, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_60, primals_138, primals_134, primals_136, primals_137, False, 0.01, 0.001);  primals_134 = None
        getitem_132 = native_batch_norm_default_44[0];  native_batch_norm_default_44 = None
        add__tensor_9 = torch.ops.aten.add_.Tensor(getitem_132, add__tensor_8);  getitem_132 = None
        convolution_default_61 = torch.ops.aten.convolution.default(add__tensor_9, primals_139, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_61, primals_144, primals_140, primals_142, primals_143, False, 0.01, 0.001);  primals_140 = None
        getitem_135 = native_batch_norm_default_45[0];  native_batch_norm_default_45 = None
        hardswish__default_19 = torch.ops.aten.hardswish_.default(getitem_135)
        mean_dim_8 = torch.ops.aten.mean.dim(hardswish__default_19, [-1, -2], True);  hardswish__default_19 = None
        view_default = torch.ops.aten.view.default(mean_dim_8, [32, 960]);  mean_dim_8 = None
        t_default = torch.ops.aten.t.default(primals_2);  primals_2 = None
        addmm_default = torch.ops.aten.addmm.default(primals_1, view_default, t_default);  primals_1 = None
        hardswish__default_20 = torch.ops.aten.hardswish_.default(addmm_default)
        t_default_1 = torch.ops.aten.t.default(primals_4);  primals_4 = None
        addmm_default_1 = torch.ops.aten.addmm.default(primals_3, hardswish__default_20, t_default_1);  primals_3 = None
        return [addmm_default_1, getitem_54, primals_218, convolution_default_18, convolution_default_24, primals_219, primals_220, primals_221, mul_tensor_1, to_dtype_3, primals_235, convolution_default_9, primals_224, convolution_default_19, primals_225, relu__default_5, add__tensor_2, primals_226, convolution_default_10, primals_228, primals_230, hardswish__default_1, primals_231, convolution_default_1, convolution_default, relu__default_6, primals_234, convolution_default_25, mean_dim, relu__default_9, convolution_default_20, primals_236, primals_237, getitem_57, primals_280, primals_281, primals_110, primals_111, convolution_default_51, primals_175, primals_282, getitem_117, primals_116, primals_283, primals_162, primals_298, primals_163, primals_114, primals_292, primals_286, primals_293, primals_101, primals_117, primals_287, primals_294, primals_166, primals_108, primals_288, primals_115, primals_289, hardswish__default_15, primals_174, primals_301, primals_168, primals_173, primals_104, primals_105, convolution_default_52, primals_106, primals_300, primals_172, primals_160, getitem_120, primals_305, primals_167, primals_295, mean_dim_6, primals_161, primals_304, primals_169, primals_299, getitem, primals_100, primals_191, hardswish__default_8, primals_179, primals_184, primals_181, convolution_default_36, primals_186, primals_193, primals_196, primals_192, primals_178, primals_185, getitem_90, convolution_default_37, primals_180, primals_187, primals_190, primals_48, primals_155, relu__default_1, primals_42, primals_149, primals_313, convolution_default_4, primals_148, convolution_default_57, primals_45, primals_151, primals_51, primals_150, primals_49, primals_50, hardswish__default_17, getitem_129, primals_154, t_default, getitem_126, primals_144, view_default, primals_55, primals_54, relu__default_2, convolution_default_5, primals_57, addmm_default, mean_dim_7, primals_156, primals_40, primals_44, primals_39, getitem_15, hardswish__default_20, primals_143, hardswish__default_18, primals_142, primals_38, t_default_1, primals_56, primals_145, primals_157, convolution_default_6, getitem_81, convolution_default_33, convolution_default_12, hardswish__default_3, relu__default_3, convolution_default_30, relu_default, relu__default_4, convolution_default_13, hardswish__default_4, getitem_66, mul_tensor, convolution_default_7, to_dtype_1, add__tensor_1, hardswish__default_7, convolution_default_29, add__tensor_4, convolution_default_14, getitem_33, convolution_default_34, add__tensor_6, convolution_default_35, convolution_default_8, getitem_84, primals_259, relu__default_7, hardswish__default_9, primals_98, hardswish__default, convolution_default_15, primals_262, primals_263, primals_94, primals_264, primals_92, primals_265, relu__default, convolution_default_42, mean_dim_3, primals_84, primals_95, primals_93, primals_89, primals_268, hardswish__default_10, primals_269, convolution_default_2, getitem_93, primals_270, relu__default_8, primals_99, primals_271, primals_88, add__tensor, convolution_default_17, primals_79, primals_274, convolution_default_3, primals_275, mean_dim_1, primals_276, relu_default_3, primals_277, convolution_default_39, primals_83, primals_86, primals_82, relu_default_1, mul_tensor_3, getitem_102, convolution_default_59, primals_312, primals_35, primals_21, primals_240, mean_dim_5, primals_306, primals_15, relu_default_7, primals_32, primals_22, primals_241, primals_311, convolution_default_31, hardswish__default_14, primals_242, mean_dim_4, primals_247, primals_243, hardswish__default_12, hardswish__default_5, primals_8, primals_310, getitem_75, convolution_default_49, mul_tensor_7, primals_20, primals_307, to_dtype_15, primals_246, getitem_72, convolution_default_61, relu_default_5, primals_28, primals_5, primals_248, primals_10, add__tensor_5, primals_29, primals_34, primals_23, primals_250, convolution_default_60, add__tensor_9, convolution_default_44, convolution_default_50, primals_9, getitem_135, primals_252, relu_default_4, primals_27, primals_257, primals_253, primals_11, convolution_default_45, add__tensor_7, to_dtype_11, primals_26, hardswish__default_6, mul_tensor_5, primals_16, mul_tensor_4, getitem_114, primals_17, primals_256, primals_14, primals_33, primals_258, convolution_default_32, to_dtype_9, primals_122, getitem_108, primals_60, primals_138, getitem_96, relu__default_10, mean_dim_2, convolution_default_46, hardswish__default_16, primals_76, primals_204, primals_137, to_dtype_7, primals_67, convolution_default_40, primals_66, convolution_default_26, primals_136, primals_203, hardswish__default_2, primals_120, primals_202, convolution_default_54, convolution_default_41, primals_73, relu_default_6, primals_121, getitem_60, primals_133, convolution_default_27, convolution_default_56, primals_132, primals_206, primals_212, primals_139, primals_208, getitem_63, mul_tensor_6, convolution_default_55, primals_130, getitem_99, to_dtype_13, primals_70, primals_128, primals_71, primals_62, convolution_default_22, primals_127, primals_197, hardswish__default_13, primals_209, primals_199, primals_78, relu_default_2, primals_215, primals_77, add__tensor_8, primals_126, primals_214, convolution_default_23, primals_64, primals_213, add__tensor_3, hardswish__default_11, convolution_default_28, mul_tensor_2, convolution_default_47, primals_72, primals_198, primals_61, primals_123, getitem_111, to_dtype_5]
        
