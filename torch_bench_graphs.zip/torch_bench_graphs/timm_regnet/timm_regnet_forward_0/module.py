
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/timm_regnet/timm_regnet_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339, primals_340, primals_341, primals_342, primals_343, primals_344, primals_345, primals_346, primals_347, primals_348, primals_349, primals_350, primals_351, primals_352, primals_353, primals_354, primals_355, primals_356, primals_357, primals_358, primals_359, primals_360, primals_361, primals_362, primals_363, primals_364, primals_365, primals_366, primals_367, primals_368, primals_369, primals_370, primals_371, primals_372, primals_373, primals_374, primals_375, primals_376, primals_377, primals_378, primals_379, primals_380, primals_381, primals_382, primals_383, primals_384, primals_385, primals_386, primals_387, primals_388, primals_389):
        convolution_default = torch.ops.aten.convolution.default(primals_389, primals_388, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_387, primals_384, primals_385, primals_386, False, 0.1, 1e-05);  primals_384 = None
        getitem = native_batch_norm_default[0];  native_batch_norm_default = None
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default, primals_7, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_6, primals_3, primals_4, primals_5, False, 0.1, 1e-05);  primals_3 = None
        getitem_3 = native_batch_norm_default_1[0];  native_batch_norm_default_1 = None
        relu__default_1 = torch.ops.aten.relu_.default(getitem_3);  getitem_3 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_12, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_11, primals_8, primals_9, primals_10, False, 0.1, 1e-05);  primals_8 = None
        getitem_6 = native_batch_norm_default_2[0];  native_batch_norm_default_2 = None
        relu__default_2 = torch.ops.aten.relu_.default(getitem_6);  getitem_6 = None
        mean_dim = torch.ops.aten.mean.dim(relu__default_2, [2, 3], True)
        convolution_default_3 = torch.ops.aten.convolution.default(mean_dim, primals_24, primals_23, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_23 = None
        relu__default_3 = torch.ops.aten.relu_.default(convolution_default_3);  convolution_default_3 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu__default_3, primals_26, primals_25, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_25 = None
        sigmoid_default = torch.ops.aten.sigmoid.default(convolution_default_4);  convolution_default_4 = None
        mul_tensor = torch.ops.aten.mul.Tensor(relu__default_2, sigmoid_default)
        convolution_default_5 = torch.ops.aten.convolution.default(mul_tensor, primals_17, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_16, primals_13, primals_14, primals_15, False, 0.1, 1e-05);  primals_13 = None
        getitem_9 = native_batch_norm_default_3[0];  native_batch_norm_default_3 = None
        convolution_default_6 = torch.ops.aten.convolution.default(relu__default, primals_22, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_21, primals_18, primals_19, primals_20, False, 0.1, 1e-05);  primals_18 = None
        getitem_12 = native_batch_norm_default_4[0];  native_batch_norm_default_4 = None
        add__tensor = torch.ops.aten.add_.Tensor(getitem_9, getitem_12);  getitem_9 = getitem_12 = None
        relu__default_4 = torch.ops.aten.relu_.default(add__tensor);  add__tensor = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_4, primals_31, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_30, primals_27, primals_28, primals_29, False, 0.1, 1e-05);  primals_27 = None
        getitem_15 = native_batch_norm_default_5[0];  native_batch_norm_default_5 = None
        relu__default_5 = torch.ops.aten.relu_.default(getitem_15);  getitem_15 = None
        convolution_default_8 = torch.ops.aten.convolution.default(relu__default_5, primals_36, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_35, primals_32, primals_33, primals_34, False, 0.1, 1e-05);  primals_32 = None
        getitem_18 = native_batch_norm_default_6[0];  native_batch_norm_default_6 = None
        relu__default_6 = torch.ops.aten.relu_.default(getitem_18);  getitem_18 = None
        mean_dim_1 = torch.ops.aten.mean.dim(relu__default_6, [2, 3], True)
        convolution_default_9 = torch.ops.aten.convolution.default(mean_dim_1, primals_43, primals_42, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_42 = None
        relu__default_7 = torch.ops.aten.relu_.default(convolution_default_9);  convolution_default_9 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default_7, primals_45, primals_44, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_44 = None
        sigmoid_default_1 = torch.ops.aten.sigmoid.default(convolution_default_10);  convolution_default_10 = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(relu__default_6, sigmoid_default_1)
        convolution_default_11 = torch.ops.aten.convolution.default(mul_tensor_1, primals_41, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_40, primals_37, primals_38, primals_39, False, 0.1, 1e-05);  primals_37 = None
        getitem_21 = native_batch_norm_default_7[0];  native_batch_norm_default_7 = None
        add__tensor_1 = torch.ops.aten.add_.Tensor(getitem_21, relu__default_4);  getitem_21 = None
        relu__default_8 = torch.ops.aten.relu_.default(add__tensor_1);  add__tensor_1 = None
        convolution_default_12 = torch.ops.aten.convolution.default(relu__default_8, primals_50, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_49, primals_46, primals_47, primals_48, False, 0.1, 1e-05);  primals_46 = None
        getitem_24 = native_batch_norm_default_8[0];  native_batch_norm_default_8 = None
        relu__default_9 = torch.ops.aten.relu_.default(getitem_24);  getitem_24 = None
        convolution_default_13 = torch.ops.aten.convolution.default(relu__default_9, primals_55, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 4)
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_54, primals_51, primals_52, primals_53, False, 0.1, 1e-05);  primals_51 = None
        getitem_27 = native_batch_norm_default_9[0];  native_batch_norm_default_9 = None
        relu__default_10 = torch.ops.aten.relu_.default(getitem_27);  getitem_27 = None
        mean_dim_2 = torch.ops.aten.mean.dim(relu__default_10, [2, 3], True)
        convolution_default_14 = torch.ops.aten.convolution.default(mean_dim_2, primals_67, primals_66, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_66 = None
        relu__default_11 = torch.ops.aten.relu_.default(convolution_default_14);  convolution_default_14 = None
        convolution_default_15 = torch.ops.aten.convolution.default(relu__default_11, primals_69, primals_68, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_68 = None
        sigmoid_default_2 = torch.ops.aten.sigmoid.default(convolution_default_15);  convolution_default_15 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(relu__default_10, sigmoid_default_2)
        convolution_default_16 = torch.ops.aten.convolution.default(mul_tensor_2, primals_60, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_59, primals_56, primals_57, primals_58, False, 0.1, 1e-05);  primals_56 = None
        getitem_30 = native_batch_norm_default_10[0];  native_batch_norm_default_10 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu__default_8, primals_65, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_64, primals_61, primals_62, primals_63, False, 0.1, 1e-05);  primals_61 = None
        getitem_33 = native_batch_norm_default_11[0];  native_batch_norm_default_11 = None
        add__tensor_2 = torch.ops.aten.add_.Tensor(getitem_30, getitem_33);  getitem_30 = getitem_33 = None
        relu__default_12 = torch.ops.aten.relu_.default(add__tensor_2);  add__tensor_2 = None
        convolution_default_18 = torch.ops.aten.convolution.default(relu__default_12, primals_74, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_73, primals_70, primals_71, primals_72, False, 0.1, 1e-05);  primals_70 = None
        getitem_36 = native_batch_norm_default_12[0];  native_batch_norm_default_12 = None
        relu__default_13 = torch.ops.aten.relu_.default(getitem_36);  getitem_36 = None
        convolution_default_19 = torch.ops.aten.convolution.default(relu__default_13, primals_79, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 4)
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_78, primals_75, primals_76, primals_77, False, 0.1, 1e-05);  primals_75 = None
        getitem_39 = native_batch_norm_default_13[0];  native_batch_norm_default_13 = None
        relu__default_14 = torch.ops.aten.relu_.default(getitem_39);  getitem_39 = None
        mean_dim_3 = torch.ops.aten.mean.dim(relu__default_14, [2, 3], True)
        convolution_default_20 = torch.ops.aten.convolution.default(mean_dim_3, primals_86, primals_85, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_85 = None
        relu__default_15 = torch.ops.aten.relu_.default(convolution_default_20);  convolution_default_20 = None
        convolution_default_21 = torch.ops.aten.convolution.default(relu__default_15, primals_88, primals_87, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_87 = None
        sigmoid_default_3 = torch.ops.aten.sigmoid.default(convolution_default_21);  convolution_default_21 = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(relu__default_14, sigmoid_default_3)
        convolution_default_22 = torch.ops.aten.convolution.default(mul_tensor_3, primals_84, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_83, primals_80, primals_81, primals_82, False, 0.1, 1e-05);  primals_80 = None
        getitem_42 = native_batch_norm_default_14[0];  native_batch_norm_default_14 = None
        add__tensor_3 = torch.ops.aten.add_.Tensor(getitem_42, relu__default_12);  getitem_42 = None
        relu__default_16 = torch.ops.aten.relu_.default(add__tensor_3);  add__tensor_3 = None
        convolution_default_23 = torch.ops.aten.convolution.default(relu__default_16, primals_93, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_92, primals_89, primals_90, primals_91, False, 0.1, 1e-05);  primals_89 = None
        getitem_45 = native_batch_norm_default_15[0];  native_batch_norm_default_15 = None
        relu__default_17 = torch.ops.aten.relu_.default(getitem_45);  getitem_45 = None
        convolution_default_24 = torch.ops.aten.convolution.default(relu__default_17, primals_98, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 4)
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_97, primals_94, primals_95, primals_96, False, 0.1, 1e-05);  primals_94 = None
        getitem_48 = native_batch_norm_default_16[0];  native_batch_norm_default_16 = None
        relu__default_18 = torch.ops.aten.relu_.default(getitem_48);  getitem_48 = None
        mean_dim_4 = torch.ops.aten.mean.dim(relu__default_18, [2, 3], True)
        convolution_default_25 = torch.ops.aten.convolution.default(mean_dim_4, primals_105, primals_104, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_104 = None
        relu__default_19 = torch.ops.aten.relu_.default(convolution_default_25);  convolution_default_25 = None
        convolution_default_26 = torch.ops.aten.convolution.default(relu__default_19, primals_107, primals_106, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_106 = None
        sigmoid_default_4 = torch.ops.aten.sigmoid.default(convolution_default_26);  convolution_default_26 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(relu__default_18, sigmoid_default_4)
        convolution_default_27 = torch.ops.aten.convolution.default(mul_tensor_4, primals_103, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_102, primals_99, primals_100, primals_101, False, 0.1, 1e-05);  primals_99 = None
        getitem_51 = native_batch_norm_default_17[0];  native_batch_norm_default_17 = None
        add__tensor_4 = torch.ops.aten.add_.Tensor(getitem_51, relu__default_16);  getitem_51 = None
        relu__default_20 = torch.ops.aten.relu_.default(add__tensor_4);  add__tensor_4 = None
        convolution_default_28 = torch.ops.aten.convolution.default(relu__default_20, primals_112, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_111, primals_108, primals_109, primals_110, False, 0.1, 1e-05);  primals_108 = None
        getitem_54 = native_batch_norm_default_18[0];  native_batch_norm_default_18 = None
        relu__default_21 = torch.ops.aten.relu_.default(getitem_54);  getitem_54 = None
        convolution_default_29 = torch.ops.aten.convolution.default(relu__default_21, primals_117, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 4)
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_116, primals_113, primals_114, primals_115, False, 0.1, 1e-05);  primals_113 = None
        getitem_57 = native_batch_norm_default_19[0];  native_batch_norm_default_19 = None
        relu__default_22 = torch.ops.aten.relu_.default(getitem_57);  getitem_57 = None
        mean_dim_5 = torch.ops.aten.mean.dim(relu__default_22, [2, 3], True)
        convolution_default_30 = torch.ops.aten.convolution.default(mean_dim_5, primals_124, primals_123, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_123 = None
        relu__default_23 = torch.ops.aten.relu_.default(convolution_default_30);  convolution_default_30 = None
        convolution_default_31 = torch.ops.aten.convolution.default(relu__default_23, primals_126, primals_125, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_125 = None
        sigmoid_default_5 = torch.ops.aten.sigmoid.default(convolution_default_31);  convolution_default_31 = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(relu__default_22, sigmoid_default_5)
        convolution_default_32 = torch.ops.aten.convolution.default(mul_tensor_5, primals_122, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_121, primals_118, primals_119, primals_120, False, 0.1, 1e-05);  primals_118 = None
        getitem_60 = native_batch_norm_default_20[0];  native_batch_norm_default_20 = None
        add__tensor_5 = torch.ops.aten.add_.Tensor(getitem_60, relu__default_20);  getitem_60 = None
        relu__default_24 = torch.ops.aten.relu_.default(add__tensor_5);  add__tensor_5 = None
        convolution_default_33 = torch.ops.aten.convolution.default(relu__default_24, primals_131, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_130, primals_127, primals_128, primals_129, False, 0.1, 1e-05);  primals_127 = None
        getitem_63 = native_batch_norm_default_21[0];  native_batch_norm_default_21 = None
        relu__default_25 = torch.ops.aten.relu_.default(getitem_63);  getitem_63 = None
        convolution_default_34 = torch.ops.aten.convolution.default(relu__default_25, primals_136, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 4)
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_135, primals_132, primals_133, primals_134, False, 0.1, 1e-05);  primals_132 = None
        getitem_66 = native_batch_norm_default_22[0];  native_batch_norm_default_22 = None
        relu__default_26 = torch.ops.aten.relu_.default(getitem_66);  getitem_66 = None
        mean_dim_6 = torch.ops.aten.mean.dim(relu__default_26, [2, 3], True)
        convolution_default_35 = torch.ops.aten.convolution.default(mean_dim_6, primals_143, primals_142, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_142 = None
        relu__default_27 = torch.ops.aten.relu_.default(convolution_default_35);  convolution_default_35 = None
        convolution_default_36 = torch.ops.aten.convolution.default(relu__default_27, primals_145, primals_144, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_144 = None
        sigmoid_default_6 = torch.ops.aten.sigmoid.default(convolution_default_36);  convolution_default_36 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(relu__default_26, sigmoid_default_6)
        convolution_default_37 = torch.ops.aten.convolution.default(mul_tensor_6, primals_141, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_37, primals_140, primals_137, primals_138, primals_139, False, 0.1, 1e-05);  primals_137 = None
        getitem_69 = native_batch_norm_default_23[0];  native_batch_norm_default_23 = None
        add__tensor_6 = torch.ops.aten.add_.Tensor(getitem_69, relu__default_24);  getitem_69 = None
        relu__default_28 = torch.ops.aten.relu_.default(add__tensor_6);  add__tensor_6 = None
        convolution_default_38 = torch.ops.aten.convolution.default(relu__default_28, primals_188, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_187, primals_184, primals_185, primals_186, False, 0.1, 1e-05);  primals_184 = None
        getitem_72 = native_batch_norm_default_24[0];  native_batch_norm_default_24 = None
        relu__default_29 = torch.ops.aten.relu_.default(getitem_72);  getitem_72 = None
        convolution_default_39 = torch.ops.aten.convolution.default(relu__default_29, primals_193, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 8)
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_39, primals_192, primals_189, primals_190, primals_191, False, 0.1, 1e-05);  primals_189 = None
        getitem_75 = native_batch_norm_default_25[0];  native_batch_norm_default_25 = None
        relu__default_30 = torch.ops.aten.relu_.default(getitem_75);  getitem_75 = None
        mean_dim_7 = torch.ops.aten.mean.dim(relu__default_30, [2, 3], True)
        convolution_default_40 = torch.ops.aten.convolution.default(mean_dim_7, primals_205, primals_204, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_204 = None
        relu__default_31 = torch.ops.aten.relu_.default(convolution_default_40);  convolution_default_40 = None
        convolution_default_41 = torch.ops.aten.convolution.default(relu__default_31, primals_207, primals_206, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_206 = None
        sigmoid_default_7 = torch.ops.aten.sigmoid.default(convolution_default_41);  convolution_default_41 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(relu__default_30, sigmoid_default_7)
        convolution_default_42 = torch.ops.aten.convolution.default(mul_tensor_7, primals_198, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_42, primals_197, primals_194, primals_195, primals_196, False, 0.1, 1e-05);  primals_194 = None
        getitem_78 = native_batch_norm_default_26[0];  native_batch_norm_default_26 = None
        convolution_default_43 = torch.ops.aten.convolution.default(relu__default_28, primals_203, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_43, primals_202, primals_199, primals_200, primals_201, False, 0.1, 1e-05);  primals_199 = None
        getitem_81 = native_batch_norm_default_27[0];  native_batch_norm_default_27 = None
        add__tensor_7 = torch.ops.aten.add_.Tensor(getitem_78, getitem_81);  getitem_78 = getitem_81 = None
        relu__default_32 = torch.ops.aten.relu_.default(add__tensor_7);  add__tensor_7 = None
        convolution_default_44 = torch.ops.aten.convolution.default(relu__default_32, primals_212, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_211, primals_208, primals_209, primals_210, False, 0.1, 1e-05);  primals_208 = None
        getitem_84 = native_batch_norm_default_28[0];  native_batch_norm_default_28 = None
        relu__default_33 = torch.ops.aten.relu_.default(getitem_84);  getitem_84 = None
        convolution_default_45 = torch.ops.aten.convolution.default(relu__default_33, primals_217, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 8)
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_45, primals_216, primals_213, primals_214, primals_215, False, 0.1, 1e-05);  primals_213 = None
        getitem_87 = native_batch_norm_default_29[0];  native_batch_norm_default_29 = None
        relu__default_34 = torch.ops.aten.relu_.default(getitem_87);  getitem_87 = None
        mean_dim_8 = torch.ops.aten.mean.dim(relu__default_34, [2, 3], True)
        convolution_default_46 = torch.ops.aten.convolution.default(mean_dim_8, primals_224, primals_223, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_223 = None
        relu__default_35 = torch.ops.aten.relu_.default(convolution_default_46);  convolution_default_46 = None
        convolution_default_47 = torch.ops.aten.convolution.default(relu__default_35, primals_226, primals_225, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_225 = None
        sigmoid_default_8 = torch.ops.aten.sigmoid.default(convolution_default_47);  convolution_default_47 = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(relu__default_34, sigmoid_default_8)
        convolution_default_48 = torch.ops.aten.convolution.default(mul_tensor_8, primals_222, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_48, primals_221, primals_218, primals_219, primals_220, False, 0.1, 1e-05);  primals_218 = None
        getitem_90 = native_batch_norm_default_30[0];  native_batch_norm_default_30 = None
        add__tensor_8 = torch.ops.aten.add_.Tensor(getitem_90, relu__default_32);  getitem_90 = None
        relu__default_36 = torch.ops.aten.relu_.default(add__tensor_8);  add__tensor_8 = None
        convolution_default_49 = torch.ops.aten.convolution.default(relu__default_36, primals_231, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_49, primals_230, primals_227, primals_228, primals_229, False, 0.1, 1e-05);  primals_227 = None
        getitem_93 = native_batch_norm_default_31[0];  native_batch_norm_default_31 = None
        relu__default_37 = torch.ops.aten.relu_.default(getitem_93);  getitem_93 = None
        convolution_default_50 = torch.ops.aten.convolution.default(relu__default_37, primals_236, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 8)
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_50, primals_235, primals_232, primals_233, primals_234, False, 0.1, 1e-05);  primals_232 = None
        getitem_96 = native_batch_norm_default_32[0];  native_batch_norm_default_32 = None
        relu__default_38 = torch.ops.aten.relu_.default(getitem_96);  getitem_96 = None
        mean_dim_9 = torch.ops.aten.mean.dim(relu__default_38, [2, 3], True)
        convolution_default_51 = torch.ops.aten.convolution.default(mean_dim_9, primals_243, primals_242, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_242 = None
        relu__default_39 = torch.ops.aten.relu_.default(convolution_default_51);  convolution_default_51 = None
        convolution_default_52 = torch.ops.aten.convolution.default(relu__default_39, primals_245, primals_244, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_244 = None
        sigmoid_default_9 = torch.ops.aten.sigmoid.default(convolution_default_52);  convolution_default_52 = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(relu__default_38, sigmoid_default_9)
        convolution_default_53 = torch.ops.aten.convolution.default(mul_tensor_9, primals_241, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_53, primals_240, primals_237, primals_238, primals_239, False, 0.1, 1e-05);  primals_237 = None
        getitem_99 = native_batch_norm_default_33[0];  native_batch_norm_default_33 = None
        add__tensor_9 = torch.ops.aten.add_.Tensor(getitem_99, relu__default_36);  getitem_99 = None
        relu__default_40 = torch.ops.aten.relu_.default(add__tensor_9);  add__tensor_9 = None
        convolution_default_54 = torch.ops.aten.convolution.default(relu__default_40, primals_250, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_54, primals_249, primals_246, primals_247, primals_248, False, 0.1, 1e-05);  primals_246 = None
        getitem_102 = native_batch_norm_default_34[0];  native_batch_norm_default_34 = None
        relu__default_41 = torch.ops.aten.relu_.default(getitem_102);  getitem_102 = None
        convolution_default_55 = torch.ops.aten.convolution.default(relu__default_41, primals_255, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 8)
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_55, primals_254, primals_251, primals_252, primals_253, False, 0.1, 1e-05);  primals_251 = None
        getitem_105 = native_batch_norm_default_35[0];  native_batch_norm_default_35 = None
        relu__default_42 = torch.ops.aten.relu_.default(getitem_105);  getitem_105 = None
        mean_dim_10 = torch.ops.aten.mean.dim(relu__default_42, [2, 3], True)
        convolution_default_56 = torch.ops.aten.convolution.default(mean_dim_10, primals_262, primals_261, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_261 = None
        relu__default_43 = torch.ops.aten.relu_.default(convolution_default_56);  convolution_default_56 = None
        convolution_default_57 = torch.ops.aten.convolution.default(relu__default_43, primals_264, primals_263, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_263 = None
        sigmoid_default_10 = torch.ops.aten.sigmoid.default(convolution_default_57);  convolution_default_57 = None
        mul_tensor_10 = torch.ops.aten.mul.Tensor(relu__default_42, sigmoid_default_10)
        convolution_default_58 = torch.ops.aten.convolution.default(mul_tensor_10, primals_260, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_58, primals_259, primals_256, primals_257, primals_258, False, 0.1, 1e-05);  primals_256 = None
        getitem_108 = native_batch_norm_default_36[0];  native_batch_norm_default_36 = None
        add__tensor_10 = torch.ops.aten.add_.Tensor(getitem_108, relu__default_40);  getitem_108 = None
        relu__default_44 = torch.ops.aten.relu_.default(add__tensor_10);  add__tensor_10 = None
        convolution_default_59 = torch.ops.aten.convolution.default(relu__default_44, primals_269, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_59, primals_268, primals_265, primals_266, primals_267, False, 0.1, 1e-05);  primals_265 = None
        getitem_111 = native_batch_norm_default_37[0];  native_batch_norm_default_37 = None
        relu__default_45 = torch.ops.aten.relu_.default(getitem_111);  getitem_111 = None
        convolution_default_60 = torch.ops.aten.convolution.default(relu__default_45, primals_274, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 8)
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_60, primals_273, primals_270, primals_271, primals_272, False, 0.1, 1e-05);  primals_270 = None
        getitem_114 = native_batch_norm_default_38[0];  native_batch_norm_default_38 = None
        relu__default_46 = torch.ops.aten.relu_.default(getitem_114);  getitem_114 = None
        mean_dim_11 = torch.ops.aten.mean.dim(relu__default_46, [2, 3], True)
        convolution_default_61 = torch.ops.aten.convolution.default(mean_dim_11, primals_281, primals_280, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_280 = None
        relu__default_47 = torch.ops.aten.relu_.default(convolution_default_61);  convolution_default_61 = None
        convolution_default_62 = torch.ops.aten.convolution.default(relu__default_47, primals_283, primals_282, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_282 = None
        sigmoid_default_11 = torch.ops.aten.sigmoid.default(convolution_default_62);  convolution_default_62 = None
        mul_tensor_11 = torch.ops.aten.mul.Tensor(relu__default_46, sigmoid_default_11)
        convolution_default_63 = torch.ops.aten.convolution.default(mul_tensor_11, primals_279, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_63, primals_278, primals_275, primals_276, primals_277, False, 0.1, 1e-05);  primals_275 = None
        getitem_117 = native_batch_norm_default_39[0];  native_batch_norm_default_39 = None
        add__tensor_11 = torch.ops.aten.add_.Tensor(getitem_117, relu__default_44);  getitem_117 = None
        relu__default_48 = torch.ops.aten.relu_.default(add__tensor_11);  add__tensor_11 = None
        convolution_default_64 = torch.ops.aten.convolution.default(relu__default_48, primals_288, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_64, primals_287, primals_284, primals_285, primals_286, False, 0.1, 1e-05);  primals_284 = None
        getitem_120 = native_batch_norm_default_40[0];  native_batch_norm_default_40 = None
        relu__default_49 = torch.ops.aten.relu_.default(getitem_120);  getitem_120 = None
        convolution_default_65 = torch.ops.aten.convolution.default(relu__default_49, primals_293, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 8)
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_65, primals_292, primals_289, primals_290, primals_291, False, 0.1, 1e-05);  primals_289 = None
        getitem_123 = native_batch_norm_default_41[0];  native_batch_norm_default_41 = None
        relu__default_50 = torch.ops.aten.relu_.default(getitem_123);  getitem_123 = None
        mean_dim_12 = torch.ops.aten.mean.dim(relu__default_50, [2, 3], True)
        convolution_default_66 = torch.ops.aten.convolution.default(mean_dim_12, primals_300, primals_299, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_299 = None
        relu__default_51 = torch.ops.aten.relu_.default(convolution_default_66);  convolution_default_66 = None
        convolution_default_67 = torch.ops.aten.convolution.default(relu__default_51, primals_302, primals_301, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_301 = None
        sigmoid_default_12 = torch.ops.aten.sigmoid.default(convolution_default_67);  convolution_default_67 = None
        mul_tensor_12 = torch.ops.aten.mul.Tensor(relu__default_50, sigmoid_default_12)
        convolution_default_68 = torch.ops.aten.convolution.default(mul_tensor_12, primals_298, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_68, primals_297, primals_294, primals_295, primals_296, False, 0.1, 1e-05);  primals_294 = None
        getitem_126 = native_batch_norm_default_42[0];  native_batch_norm_default_42 = None
        add__tensor_12 = torch.ops.aten.add_.Tensor(getitem_126, relu__default_48);  getitem_126 = None
        relu__default_52 = torch.ops.aten.relu_.default(add__tensor_12);  add__tensor_12 = None
        convolution_default_69 = torch.ops.aten.convolution.default(relu__default_52, primals_307, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_69, primals_306, primals_303, primals_304, primals_305, False, 0.1, 1e-05);  primals_303 = None
        getitem_129 = native_batch_norm_default_43[0];  native_batch_norm_default_43 = None
        relu__default_53 = torch.ops.aten.relu_.default(getitem_129);  getitem_129 = None
        convolution_default_70 = torch.ops.aten.convolution.default(relu__default_53, primals_312, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 8)
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_70, primals_311, primals_308, primals_309, primals_310, False, 0.1, 1e-05);  primals_308 = None
        getitem_132 = native_batch_norm_default_44[0];  native_batch_norm_default_44 = None
        relu__default_54 = torch.ops.aten.relu_.default(getitem_132);  getitem_132 = None
        mean_dim_13 = torch.ops.aten.mean.dim(relu__default_54, [2, 3], True)
        convolution_default_71 = torch.ops.aten.convolution.default(mean_dim_13, primals_319, primals_318, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_318 = None
        relu__default_55 = torch.ops.aten.relu_.default(convolution_default_71);  convolution_default_71 = None
        convolution_default_72 = torch.ops.aten.convolution.default(relu__default_55, primals_321, primals_320, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_320 = None
        sigmoid_default_13 = torch.ops.aten.sigmoid.default(convolution_default_72);  convolution_default_72 = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(relu__default_54, sigmoid_default_13)
        convolution_default_73 = torch.ops.aten.convolution.default(mul_tensor_13, primals_317, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_73, primals_316, primals_313, primals_314, primals_315, False, 0.1, 1e-05);  primals_313 = None
        getitem_135 = native_batch_norm_default_45[0];  native_batch_norm_default_45 = None
        add__tensor_13 = torch.ops.aten.add_.Tensor(getitem_135, relu__default_52);  getitem_135 = None
        relu__default_56 = torch.ops.aten.relu_.default(add__tensor_13);  add__tensor_13 = None
        convolution_default_74 = torch.ops.aten.convolution.default(relu__default_56, primals_326, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(convolution_default_74, primals_325, primals_322, primals_323, primals_324, False, 0.1, 1e-05);  primals_322 = None
        getitem_138 = native_batch_norm_default_46[0];  native_batch_norm_default_46 = None
        relu__default_57 = torch.ops.aten.relu_.default(getitem_138);  getitem_138 = None
        convolution_default_75 = torch.ops.aten.convolution.default(relu__default_57, primals_331, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 8)
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(convolution_default_75, primals_330, primals_327, primals_328, primals_329, False, 0.1, 1e-05);  primals_327 = None
        getitem_141 = native_batch_norm_default_47[0];  native_batch_norm_default_47 = None
        relu__default_58 = torch.ops.aten.relu_.default(getitem_141);  getitem_141 = None
        mean_dim_14 = torch.ops.aten.mean.dim(relu__default_58, [2, 3], True)
        convolution_default_76 = torch.ops.aten.convolution.default(mean_dim_14, primals_338, primals_337, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_337 = None
        relu__default_59 = torch.ops.aten.relu_.default(convolution_default_76);  convolution_default_76 = None
        convolution_default_77 = torch.ops.aten.convolution.default(relu__default_59, primals_340, primals_339, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_339 = None
        sigmoid_default_14 = torch.ops.aten.sigmoid.default(convolution_default_77);  convolution_default_77 = None
        mul_tensor_14 = torch.ops.aten.mul.Tensor(relu__default_58, sigmoid_default_14)
        convolution_default_78 = torch.ops.aten.convolution.default(mul_tensor_14, primals_336, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_78, primals_335, primals_332, primals_333, primals_334, False, 0.1, 1e-05);  primals_332 = None
        getitem_144 = native_batch_norm_default_48[0];  native_batch_norm_default_48 = None
        add__tensor_14 = torch.ops.aten.add_.Tensor(getitem_144, relu__default_56);  getitem_144 = None
        relu__default_60 = torch.ops.aten.relu_.default(add__tensor_14);  add__tensor_14 = None
        convolution_default_79 = torch.ops.aten.convolution.default(relu__default_60, primals_345, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(convolution_default_79, primals_344, primals_341, primals_342, primals_343, False, 0.1, 1e-05);  primals_341 = None
        getitem_147 = native_batch_norm_default_49[0];  native_batch_norm_default_49 = None
        relu__default_61 = torch.ops.aten.relu_.default(getitem_147);  getitem_147 = None
        convolution_default_80 = torch.ops.aten.convolution.default(relu__default_61, primals_350, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 8)
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(convolution_default_80, primals_349, primals_346, primals_347, primals_348, False, 0.1, 1e-05);  primals_346 = None
        getitem_150 = native_batch_norm_default_50[0];  native_batch_norm_default_50 = None
        relu__default_62 = torch.ops.aten.relu_.default(getitem_150);  getitem_150 = None
        mean_dim_15 = torch.ops.aten.mean.dim(relu__default_62, [2, 3], True)
        convolution_default_81 = torch.ops.aten.convolution.default(mean_dim_15, primals_357, primals_356, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_356 = None
        relu__default_63 = torch.ops.aten.relu_.default(convolution_default_81);  convolution_default_81 = None
        convolution_default_82 = torch.ops.aten.convolution.default(relu__default_63, primals_359, primals_358, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_358 = None
        sigmoid_default_15 = torch.ops.aten.sigmoid.default(convolution_default_82);  convolution_default_82 = None
        mul_tensor_15 = torch.ops.aten.mul.Tensor(relu__default_62, sigmoid_default_15)
        convolution_default_83 = torch.ops.aten.convolution.default(mul_tensor_15, primals_355, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(convolution_default_83, primals_354, primals_351, primals_352, primals_353, False, 0.1, 1e-05);  primals_351 = None
        getitem_153 = native_batch_norm_default_51[0];  native_batch_norm_default_51 = None
        add__tensor_15 = torch.ops.aten.add_.Tensor(getitem_153, relu__default_60);  getitem_153 = None
        relu__default_64 = torch.ops.aten.relu_.default(add__tensor_15);  add__tensor_15 = None
        convolution_default_84 = torch.ops.aten.convolution.default(relu__default_64, primals_150, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(convolution_default_84, primals_149, primals_146, primals_147, primals_148, False, 0.1, 1e-05);  primals_146 = None
        getitem_156 = native_batch_norm_default_52[0];  native_batch_norm_default_52 = None
        relu__default_65 = torch.ops.aten.relu_.default(getitem_156);  getitem_156 = None
        convolution_default_85 = torch.ops.aten.convolution.default(relu__default_65, primals_155, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 8)
        native_batch_norm_default_53 = torch.ops.aten.native_batch_norm.default(convolution_default_85, primals_154, primals_151, primals_152, primals_153, False, 0.1, 1e-05);  primals_151 = None
        getitem_159 = native_batch_norm_default_53[0];  native_batch_norm_default_53 = None
        relu__default_66 = torch.ops.aten.relu_.default(getitem_159);  getitem_159 = None
        mean_dim_16 = torch.ops.aten.mean.dim(relu__default_66, [2, 3], True)
        convolution_default_86 = torch.ops.aten.convolution.default(mean_dim_16, primals_162, primals_161, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_161 = None
        relu__default_67 = torch.ops.aten.relu_.default(convolution_default_86);  convolution_default_86 = None
        convolution_default_87 = torch.ops.aten.convolution.default(relu__default_67, primals_164, primals_163, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_163 = None
        sigmoid_default_16 = torch.ops.aten.sigmoid.default(convolution_default_87);  convolution_default_87 = None
        mul_tensor_16 = torch.ops.aten.mul.Tensor(relu__default_66, sigmoid_default_16)
        convolution_default_88 = torch.ops.aten.convolution.default(mul_tensor_16, primals_160, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_54 = torch.ops.aten.native_batch_norm.default(convolution_default_88, primals_159, primals_156, primals_157, primals_158, False, 0.1, 1e-05);  primals_156 = None
        getitem_162 = native_batch_norm_default_54[0];  native_batch_norm_default_54 = None
        add__tensor_16 = torch.ops.aten.add_.Tensor(getitem_162, relu__default_64);  getitem_162 = None
        relu__default_68 = torch.ops.aten.relu_.default(add__tensor_16);  add__tensor_16 = None
        convolution_default_89 = torch.ops.aten.convolution.default(relu__default_68, primals_169, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_55 = torch.ops.aten.native_batch_norm.default(convolution_default_89, primals_168, primals_165, primals_166, primals_167, False, 0.1, 1e-05);  primals_165 = None
        getitem_165 = native_batch_norm_default_55[0];  native_batch_norm_default_55 = None
        relu__default_69 = torch.ops.aten.relu_.default(getitem_165);  getitem_165 = None
        convolution_default_90 = torch.ops.aten.convolution.default(relu__default_69, primals_174, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 8)
        native_batch_norm_default_56 = torch.ops.aten.native_batch_norm.default(convolution_default_90, primals_173, primals_170, primals_171, primals_172, False, 0.1, 1e-05);  primals_170 = None
        getitem_168 = native_batch_norm_default_56[0];  native_batch_norm_default_56 = None
        relu__default_70 = torch.ops.aten.relu_.default(getitem_168);  getitem_168 = None
        mean_dim_17 = torch.ops.aten.mean.dim(relu__default_70, [2, 3], True)
        convolution_default_91 = torch.ops.aten.convolution.default(mean_dim_17, primals_181, primals_180, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_180 = None
        relu__default_71 = torch.ops.aten.relu_.default(convolution_default_91);  convolution_default_91 = None
        convolution_default_92 = torch.ops.aten.convolution.default(relu__default_71, primals_183, primals_182, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_182 = None
        sigmoid_default_17 = torch.ops.aten.sigmoid.default(convolution_default_92);  convolution_default_92 = None
        mul_tensor_17 = torch.ops.aten.mul.Tensor(relu__default_70, sigmoid_default_17)
        convolution_default_93 = torch.ops.aten.convolution.default(mul_tensor_17, primals_179, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_57 = torch.ops.aten.native_batch_norm.default(convolution_default_93, primals_178, primals_175, primals_176, primals_177, False, 0.1, 1e-05);  primals_175 = None
        getitem_171 = native_batch_norm_default_57[0];  native_batch_norm_default_57 = None
        add__tensor_17 = torch.ops.aten.add_.Tensor(getitem_171, relu__default_68);  getitem_171 = None
        relu__default_72 = torch.ops.aten.relu_.default(add__tensor_17);  add__tensor_17 = None
        convolution_default_94 = torch.ops.aten.convolution.default(relu__default_72, primals_364, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_58 = torch.ops.aten.native_batch_norm.default(convolution_default_94, primals_363, primals_360, primals_361, primals_362, False, 0.1, 1e-05);  primals_360 = None
        getitem_174 = native_batch_norm_default_58[0];  native_batch_norm_default_58 = None
        relu__default_73 = torch.ops.aten.relu_.default(getitem_174);  getitem_174 = None
        convolution_default_95 = torch.ops.aten.convolution.default(relu__default_73, primals_369, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 20)
        native_batch_norm_default_59 = torch.ops.aten.native_batch_norm.default(convolution_default_95, primals_368, primals_365, primals_366, primals_367, False, 0.1, 1e-05);  primals_365 = None
        getitem_177 = native_batch_norm_default_59[0];  native_batch_norm_default_59 = None
        relu__default_74 = torch.ops.aten.relu_.default(getitem_177);  getitem_177 = None
        mean_dim_18 = torch.ops.aten.mean.dim(relu__default_74, [2, 3], True)
        convolution_default_96 = torch.ops.aten.convolution.default(mean_dim_18, primals_381, primals_380, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_380 = None
        relu__default_75 = torch.ops.aten.relu_.default(convolution_default_96);  convolution_default_96 = None
        convolution_default_97 = torch.ops.aten.convolution.default(relu__default_75, primals_383, primals_382, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_382 = None
        sigmoid_default_18 = torch.ops.aten.sigmoid.default(convolution_default_97);  convolution_default_97 = None
        mul_tensor_18 = torch.ops.aten.mul.Tensor(relu__default_74, sigmoid_default_18)
        convolution_default_98 = torch.ops.aten.convolution.default(mul_tensor_18, primals_374, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_60 = torch.ops.aten.native_batch_norm.default(convolution_default_98, primals_373, primals_370, primals_371, primals_372, False, 0.1, 1e-05);  primals_370 = None
        getitem_180 = native_batch_norm_default_60[0];  native_batch_norm_default_60 = None
        convolution_default_99 = torch.ops.aten.convolution.default(relu__default_72, primals_379, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_61 = torch.ops.aten.native_batch_norm.default(convolution_default_99, primals_378, primals_375, primals_376, primals_377, False, 0.1, 1e-05);  primals_375 = None
        getitem_183 = native_batch_norm_default_61[0];  native_batch_norm_default_61 = None
        add__tensor_18 = torch.ops.aten.add_.Tensor(getitem_180, getitem_183);  getitem_180 = getitem_183 = None
        relu__default_76 = torch.ops.aten.relu_.default(add__tensor_18);  add__tensor_18 = None
        mean_dim_19 = torch.ops.aten.mean.dim(relu__default_76, [-1, -2], True)
        view_default = torch.ops.aten.view.default(mean_dim_19, [32, 2240]);  mean_dim_19 = None
        t_default = torch.ops.aten.t.default(primals_2);  primals_2 = None
        addmm_default = torch.ops.aten.addmm.default(primals_1, view_default, t_default);  primals_1 = None
        return [addmm_default, primals_176, primals_211, primals_268, primals_300, primals_183, primals_212, primals_273, primals_169, primals_187, primals_271, relu__default_11, primals_269, primals_171, primals_217, primals_264, sigmoid_default_2, primals_302, primals_214, primals_272, primals_266, relu__default_10, primals_174, primals_167, primals_181, primals_177, mean_dim_2, primals_215, primals_267, primals_221, primals_185, primals_186, convolution_default_16, primals_216, primals_168, primals_179, primals_173, primals_172, primals_220, primals_222, primals_209, mul_tensor_2, primals_166, primals_210, primals_219, primals_178, primals_319, relu__default_14, primals_20, relu__default_15, primals_17, primals_315, sigmoid_default_18, convolution_default_70, mul_tensor_12, convolution_default_98, convolution_default_69, primals_22, primals_309, relu__default_57, relu__default_53, mean_dim_14, primals_307, mul_tensor_3, mean_dim_16, primals_278, relu__default_66, convolution_default_75, convolution_default_99, relu__default_58, primals_276, primals_11, sigmoid_default_3, convolution_default_68, primals_16, primals_14, relu__default_59, primals_312, relu__default_75, primals_317, primals_19, primals_305, primals_15, primals_316, convolution_default_84, mul_tensor_18, convolution_default, primals_310, relu__default_52, primals_12, relu__default_76, relu__default_64, primals_4, primals_262, primals_314, primals_260, primals_21, primals_306, sigmoid_default_12, relu__default_65, primals_24, primals_304, convolution_default_85, mean_dim_3, primals_10, primals_311, primals_381, primals_354, primals_160, mul_tensor_8, primals_148, primals_159, primals_344, convolution_default_59, primals_7, primals_357, primals_158, primals_345, sigmoid_default_8, primals_386, sigmoid_default_6, relu__default_35, primals_162, relu__default_28, convolution_default_37, primals_139, primals_355, primals_379, primals_353, primals_385, relu__default_46, primals_157, relu__default_27, primals_149, primals_349, primals_378, relu__default_44, primals_350, primals_140, convolution_default_60, primals_348, primals_155, primals_352, primals_134, primals_154, primals_152, primals_389, mul_tensor_6, primals_150, primals_141, mean_dim_11, relu__default_45, convolution_default_38, relu__default_34, primals_135, primals_147, primals_136, primals_143, primals_388, relu__default_33, primals_153, mean_dim_8, primals_145, primals_383, primals_138, primals_347, primals_164, primals_342, convolution_default_44, primals_343, primals_387, relu__default_32, primals_374, primals_64, primals_362, relu__default_26, primals_109, primals_98, primals_372, primals_193, convolution_default_74, relu__default_63, primals_67, primals_277, primals_59, primals_377, sigmoid_default_15, primals_103, mean_dim_6, primals_65, primals_105, primals_361, convolution_default_73, primals_102, relu__default_21, primals_255, primals_101, primals_57, relu__default_20, relu__default_24, primals_73, primals_115, primals_198, primals_364, relu__default_69, primals_367, primals_116, primals_117, primals_200, primals_257, convolution_default_28, primals_71, primals_100, primals_359, mul_tensor_15, primals_201, primals_9, primals_191, primals_252, primals_254, relu__default_70, relu__default_56, convolution_default_90, primals_111, convolution_default_34, primals_72, primals_114, primals_62, primals_376, primals_188, primals_249, relu__default_62, primals_202, primals_373, primals_205, convolution_default_83, primals_58, primals_203, primals_60, primals_368, primals_248, t_default, primals_363, convolution_default_29, primals_207, mean_dim_17, primals_196, primals_371, primals_110, primals_195, primals_107, primals_197, primals_253, relu__default_25, primals_74, mean_dim_5, mean_dim_15, primals_250, primals_69, primals_369, primals_112, primals_366, primals_192, primals_247, view_default, primals_190, primals_63, convolution_default_33, primals_47, sigmoid_default_7, relu__default_41, primals_91, mul_tensor_14, relu__default_60, primals_298, sigmoid_default_14, primals_336, primals_243, primals_333, primals_95, sigmoid_default_10, primals_295, primals_297, primals_52, relu__default_73, primals_279, primals_50, primals_334, convolution_default_79, primals_293, primals_286, mul_tensor_7, relu__default_40, relu__default_61, primals_296, primals_281, primals_335, primals_331, convolution_default_80, primals_45, primals_323, primals_338, primals_340, primals_292, primals_324, convolution_default_54, primals_53, convolution_default_78, convolution_default_42, convolution_default_95, primals_285, primals_321, primals_55, convolution_default_43, primals_325, relu__default_31, mul_tensor_10, relu__default_43, primals_96, primals_49, relu__default_74, primals_287, primals_48, primals_329, relu__default_39, primals_92, primals_90, primals_326, convolution_default_55, primals_283, primals_54, mean_dim_18, convolution_default_58, primals_93, primals_328, relu__default_42, primals_88, primals_330, primals_97, mean_dim_10, convolution_default_1, convolution_default_50, relu__default_71, primals_81, convolution_default_2, mul_tensor_11, relu__default_50, relu__default_2, primals_77, relu__default_19, convolution_default_27, primals_79, mul_tensor_1, relu__default_51, convolution_default_94, relu__default_1, relu__default_18, primals_76, relu__default, sigmoid_default_17, mean_dim_1, convolution_default_48, convolution_default_64, mean_dim_12, mean_dim_7, relu__default_49, relu__default_3, relu__default_37, relu__default_48, mul_tensor_17, relu__default_72, sigmoid_default_4, convolution_default_39, primals_84, convolution_default_63, convolution_default_49, primals_83, convolution_default_11, convolution_default_65, mean_dim, relu__default_6, relu__default_36, relu__default_7, sigmoid_default_11, sigmoid_default, mul_tensor_4, sigmoid_default_1, relu__default_29, mul_tensor, convolution_default_5, primals_82, primals_86, primals_78, relu__default_47, mean_dim_4, relu__default_30, convolution_default_93, primals_33, convolution_default_45, primals_236, relu__default_17, primals_29, primals_226, convolution_default_88, convolution_default_24, primals_228, primals_229, primals_274, primals_40, sigmoid_default_16, primals_26, convolution_default_89, convolution_default_22, primals_30, primals_231, primals_233, primals_39, mul_tensor_16, primals_43, primals_234, primals_36, relu__default_67, primals_235, primals_38, primals_41, primals_239, primals_238, relu__default_68, primals_28, primals_241, primals_35, convolution_default_23, primals_240, primals_224, primals_31, primals_230, relu__default_16, primals_34, convolution_default_13, primals_130, convolution_default_7, primals_290, relu__default_54, primals_245, sigmoid_default_13, primals_133, convolution_default_32, sigmoid_default_9, primals_6, convolution_default_6, mul_tensor_9, primals_126, primals_119, convolution_default_8, primals_128, relu__default_55, primals_288, mul_tensor_5, primals_259, sigmoid_default_5, convolution_default_53, primals_291, relu__default_13, primals_258, convolution_default_12, relu__default_5, relu__default_9, relu__default_8, relu__default_12, relu__default_22, primals_131, convolution_default_17, primals_124, relu__default_4, primals_121, convolution_default_18, relu__default_38, primals_129, mul_tensor_13, relu__default_23, primals_5, mean_dim_9, mean_dim_13, convolution_default_19, primals_120, primals_122]
        
