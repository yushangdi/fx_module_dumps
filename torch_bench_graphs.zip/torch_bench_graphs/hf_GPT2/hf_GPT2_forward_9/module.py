
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/hf_GPT2/hf_GPT2_forward_9/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15):
        native_layer_norm_default = torch.ops.aten.native_layer_norm.default(primals_15, [768], primals_8, primals_7, 1e-05)
        getitem = native_layer_norm_default[0]
        getitem_1 = native_layer_norm_default[1]
        getitem_2 = native_layer_norm_default[2];  native_layer_norm_default = None
        view_default = torch.ops.aten.view.default(getitem, [-1, 768]);  getitem = None
        addmm_default = torch.ops.aten.addmm.default(primals_2, view_default, primals_3);  primals_2 = None
        view_default_1 = torch.ops.aten.view.default(addmm_default, [4, 512, 2304]);  addmm_default = None
        split_tensor = torch.ops.aten.split.Tensor(view_default_1, 768, 2);  view_default_1 = None
        getitem_3 = split_tensor[0]
        getitem_4 = split_tensor[1]
        getitem_5 = split_tensor[2];  split_tensor = None
        view_default_2 = torch.ops.aten.view.default(getitem_3, [4, 512, 12, 64]);  getitem_3 = None
        permute_default = torch.ops.aten.permute.default(view_default_2, [0, 2, 1, 3]);  view_default_2 = None
        view_default_3 = torch.ops.aten.view.default(getitem_4, [4, 512, 12, 64]);  getitem_4 = None
        permute_default_1 = torch.ops.aten.permute.default(view_default_3, [0, 2, 1, 3]);  view_default_3 = None
        view_default_4 = torch.ops.aten.view.default(getitem_5, [4, 512, 12, 64]);  getitem_5 = None
        permute_default_2 = torch.ops.aten.permute.default(view_default_4, [0, 2, 1, 3]);  view_default_4 = None
        transpose_int = torch.ops.aten.transpose.int(permute_default_1, -1, -2)
        expand_default = torch.ops.aten.expand.default(permute_default, [4, 12, 512, 64]);  permute_default = None
        clone_default = torch.ops.aten.clone.default(expand_default, memory_format = torch.contiguous_format);  expand_default = None
        _unsafe_view_default = torch.ops.aten._unsafe_view.default(clone_default, [48, 512, 64]);  clone_default = None
        expand_default_1 = torch.ops.aten.expand.default(transpose_int, [4, 12, 64, 512]);  transpose_int = None
        clone_default_1 = torch.ops.aten.clone.default(expand_default_1, memory_format = torch.contiguous_format);  expand_default_1 = None
        _unsafe_view_default_1 = torch.ops.aten._unsafe_view.default(clone_default_1, [48, 64, 512]);  clone_default_1 = None
        bmm_default = torch.ops.aten.bmm.default(_unsafe_view_default, _unsafe_view_default_1)
        _unsafe_view_default_2 = torch.ops.aten._unsafe_view.default(bmm_default, [4, 12, 512, 512]);  bmm_default = None
        div_tensor = torch.ops.aten.div.Tensor(_unsafe_view_default_2, 8.0);  _unsafe_view_default_2 = None
        slice_tensor = torch.ops.aten.slice.Tensor(primals_1, 0, 0, 9223372036854775807);  primals_1 = None
        slice_tensor_1 = torch.ops.aten.slice.Tensor(slice_tensor, 1, 0, 9223372036854775807);  slice_tensor = None
        slice_tensor_2 = torch.ops.aten.slice.Tensor(slice_tensor_1, 2, 0, 512);  slice_tensor_1 = None
        slice_tensor_3 = torch.ops.aten.slice.Tensor(slice_tensor_2, 3, 0, 512);  slice_tensor_2 = None
        _to_copy_default = torch.ops.aten._to_copy.default(slice_tensor_3, dtype = torch.bool);  slice_tensor_3 = None
        where_self = torch.ops.aten.where.self(_to_copy_default, div_tensor, primals_6);  div_tensor = primals_6 = None
        _softmax_default = torch.ops.aten._softmax.default(where_self, -1, False);  where_self = None
        expand_default_2 = torch.ops.aten.expand.default(_softmax_default, [4, 12, 512, 512])
        view_default_5 = torch.ops.aten.view.default(expand_default_2, [48, 512, 512]);  expand_default_2 = None
        expand_default_3 = torch.ops.aten.expand.default(permute_default_2, [4, 12, 512, 64])
        clone_default_2 = torch.ops.aten.clone.default(expand_default_3, memory_format = torch.contiguous_format);  expand_default_3 = None
        _unsafe_view_default_3 = torch.ops.aten._unsafe_view.default(clone_default_2, [48, 512, 64]);  clone_default_2 = None
        bmm_default_1 = torch.ops.aten.bmm.default(view_default_5, _unsafe_view_default_3)
        _unsafe_view_default_4 = torch.ops.aten._unsafe_view.default(bmm_default_1, [4, 12, 512, 64]);  bmm_default_1 = None
        permute_default_3 = torch.ops.aten.permute.default(_unsafe_view_default_4, [0, 2, 1, 3]);  _unsafe_view_default_4 = None
        clone_default_3 = torch.ops.aten.clone.default(permute_default_3, memory_format = torch.contiguous_format);  permute_default_3 = None
        view_default_6 = torch.ops.aten.view.default(clone_default_3, [4, 512, 768]);  clone_default_3 = None
        view_default_7 = torch.ops.aten.view.default(view_default_6, [-1, 768]);  view_default_6 = None
        addmm_default_1 = torch.ops.aten.addmm.default(primals_4, view_default_7, primals_5);  primals_4 = None
        view_default_8 = torch.ops.aten.view.default(addmm_default_1, [4, 512, 768]);  addmm_default_1 = None
        add_tensor = torch.ops.aten.add.Tensor(view_default_8, primals_15);  view_default_8 = None
        native_layer_norm_default_1 = torch.ops.aten.native_layer_norm.default(add_tensor, [768], primals_10, primals_9, 1e-05)
        getitem_6 = native_layer_norm_default_1[0]
        getitem_7 = native_layer_norm_default_1[1]
        getitem_8 = native_layer_norm_default_1[2];  native_layer_norm_default_1 = None
        view_default_9 = torch.ops.aten.view.default(getitem_6, [-1, 768]);  getitem_6 = None
        addmm_default_2 = torch.ops.aten.addmm.default(primals_11, view_default_9, primals_12);  primals_11 = None
        view_default_10 = torch.ops.aten.view.default(addmm_default_2, [4, 512, 3072]);  addmm_default_2 = None
        mul_tensor = torch.ops.aten.mul.Tensor(view_default_10, 0.5)
        pow_tensor_scalar = torch.ops.aten.pow.Tensor_Scalar(view_default_10, 3.0)
        mul_tensor_1 = torch.ops.aten.mul.Tensor(pow_tensor_scalar, 0.044715);  pow_tensor_scalar = None
        add_tensor_1 = torch.ops.aten.add.Tensor(view_default_10, mul_tensor_1);  mul_tensor_1 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(add_tensor_1, 0.7978845608028654);  add_tensor_1 = None
        tanh_default = torch.ops.aten.tanh.default(mul_tensor_2);  mul_tensor_2 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(tanh_default, 1.0)
        mul_tensor_3 = torch.ops.aten.mul.Tensor(mul_tensor, add_tensor_2)
        view_default_11 = torch.ops.aten.view.default(mul_tensor_3, [-1, 3072]);  mul_tensor_3 = None
        addmm_default_3 = torch.ops.aten.addmm.default(primals_13, view_default_11, primals_14);  primals_13 = None
        view_default_12 = torch.ops.aten.view.default(addmm_default_3, [4, 512, 768]);  addmm_default_3 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(add_tensor, view_default_12);  view_default_12 = None
        return [add_tensor_3, permute_default_1, permute_default_2, primals_14, primals_3, getitem_1, mul_tensor, _unsafe_view_default, _unsafe_view_default_1, view_default_10, primals_15, getitem_2, _to_copy_default, _softmax_default, primals_9, view_default_5, view_default_7, primals_10, view_default_9, add_tensor, primals_8, _unsafe_view_default_3, primals_12, primals_7, getitem_7, tanh_default, view_default, primals_5, add_tensor_2, view_default_11, getitem_8]
        
