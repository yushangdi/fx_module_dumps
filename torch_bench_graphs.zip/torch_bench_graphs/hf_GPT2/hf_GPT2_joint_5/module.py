
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/hf_GPT2/hf_GPT2_joint_5/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, tangents_1, tangents_2, tangents_3):
        native_layer_norm_default = torch.ops.aten.native_layer_norm.default(primals_15, [768], primals_8, primals_7, 1e-05)
        getitem = native_layer_norm_default[0]
        getitem_1 = native_layer_norm_default[1]
        getitem_2 = native_layer_norm_default[2];  native_layer_norm_default = None
        view_default = torch.ops.aten.view.default(getitem, [-1, 768]);  getitem = None
        addmm_default = torch.ops.aten.addmm.default(primals_2, view_default, primals_3);  primals_2 = None
        view_default_1 = torch.ops.aten.view.default(addmm_default, [4, 512, 2304]);  addmm_default = None
        split_tensor = torch.ops.aten.split.Tensor(view_default_1, 768, 2);  view_default_1 = None
        getitem_3 = split_tensor[0]
        getitem_4 = split_tensor[1]
        getitem_5 = split_tensor[2];  split_tensor = None
        view_default_2 = torch.ops.aten.view.default(getitem_3, [4, 512, 12, 64]);  getitem_3 = None
        permute_default = torch.ops.aten.permute.default(view_default_2, [0, 2, 1, 3]);  view_default_2 = None
        view_default_3 = torch.ops.aten.view.default(getitem_4, [4, 512, 12, 64]);  getitem_4 = None
        permute_default_1 = torch.ops.aten.permute.default(view_default_3, [0, 2, 1, 3]);  view_default_3 = None
        view_default_4 = torch.ops.aten.view.default(getitem_5, [4, 512, 12, 64]);  getitem_5 = None
        permute_default_2 = torch.ops.aten.permute.default(view_default_4, [0, 2, 1, 3]);  view_default_4 = None
        transpose_int = torch.ops.aten.transpose.int(permute_default_1, -1, -2)
        expand_default = torch.ops.aten.expand.default(permute_default, [4, 12, 512, 64]);  permute_default = None
        clone_default = torch.ops.aten.clone.default(expand_default, memory_format = torch.contiguous_format);  expand_default = None
        _unsafe_view_default = torch.ops.aten._unsafe_view.default(clone_default, [48, 512, 64]);  clone_default = None
        expand_default_1 = torch.ops.aten.expand.default(transpose_int, [4, 12, 64, 512]);  transpose_int = None
        clone_default_1 = torch.ops.aten.clone.default(expand_default_1, memory_format = torch.contiguous_format);  expand_default_1 = None
        _unsafe_view_default_1 = torch.ops.aten._unsafe_view.default(clone_default_1, [48, 64, 512]);  clone_default_1 = None
        bmm_default = torch.ops.aten.bmm.default(_unsafe_view_default, _unsafe_view_default_1)
        _unsafe_view_default_2 = torch.ops.aten._unsafe_view.default(bmm_default, [4, 12, 512, 512]);  bmm_default = None
        div_tensor = torch.ops.aten.div.Tensor(_unsafe_view_default_2, 8.0);  _unsafe_view_default_2 = None
        slice_tensor = torch.ops.aten.slice.Tensor(primals_1, 0, 0, 9223372036854775807);  primals_1 = None
        slice_tensor_1 = torch.ops.aten.slice.Tensor(slice_tensor, 1, 0, 9223372036854775807);  slice_tensor = None
        slice_tensor_2 = torch.ops.aten.slice.Tensor(slice_tensor_1, 2, 0, 512);  slice_tensor_1 = None
        slice_tensor_3 = torch.ops.aten.slice.Tensor(slice_tensor_2, 3, 0, 512);  slice_tensor_2 = None
        _to_copy_default = torch.ops.aten._to_copy.default(slice_tensor_3, dtype = torch.bool);  slice_tensor_3 = None
        where_self = torch.ops.aten.where.self(_to_copy_default, div_tensor, primals_6);  div_tensor = primals_6 = None
        _softmax_default = torch.ops.aten._softmax.default(where_self, -1, False);  where_self = None
        expand_default_2 = torch.ops.aten.expand.default(_softmax_default, [4, 12, 512, 512])
        view_default_5 = torch.ops.aten.view.default(expand_default_2, [48, 512, 512]);  expand_default_2 = None
        expand_default_3 = torch.ops.aten.expand.default(permute_default_2, [4, 12, 512, 64])
        clone_default_2 = torch.ops.aten.clone.default(expand_default_3, memory_format = torch.contiguous_format);  expand_default_3 = None
        _unsafe_view_default_3 = torch.ops.aten._unsafe_view.default(clone_default_2, [48, 512, 64]);  clone_default_2 = None
        bmm_default_1 = torch.ops.aten.bmm.default(view_default_5, _unsafe_view_default_3)
        _unsafe_view_default_4 = torch.ops.aten._unsafe_view.default(bmm_default_1, [4, 12, 512, 64]);  bmm_default_1 = None
        permute_default_3 = torch.ops.aten.permute.default(_unsafe_view_default_4, [0, 2, 1, 3]);  _unsafe_view_default_4 = None
        clone_default_3 = torch.ops.aten.clone.default(permute_default_3, memory_format = torch.contiguous_format);  permute_default_3 = None
        view_default_6 = torch.ops.aten.view.default(clone_default_3, [4, 512, 768]);  clone_default_3 = None
        view_default_7 = torch.ops.aten.view.default(view_default_6, [-1, 768]);  view_default_6 = None
        addmm_default_1 = torch.ops.aten.addmm.default(primals_4, view_default_7, primals_5);  primals_4 = None
        view_default_8 = torch.ops.aten.view.default(addmm_default_1, [4, 512, 768]);  addmm_default_1 = None
        add_tensor = torch.ops.aten.add.Tensor(view_default_8, primals_15);  view_default_8 = None
        native_layer_norm_default_1 = torch.ops.aten.native_layer_norm.default(add_tensor, [768], primals_10, primals_9, 1e-05)
        getitem_6 = native_layer_norm_default_1[0]
        getitem_7 = native_layer_norm_default_1[1]
        getitem_8 = native_layer_norm_default_1[2];  native_layer_norm_default_1 = None
        view_default_9 = torch.ops.aten.view.default(getitem_6, [-1, 768]);  getitem_6 = None
        addmm_default_2 = torch.ops.aten.addmm.default(primals_11, view_default_9, primals_12);  primals_11 = None
        view_default_10 = torch.ops.aten.view.default(addmm_default_2, [4, 512, 3072]);  addmm_default_2 = None
        mul_tensor = torch.ops.aten.mul.Tensor(view_default_10, 0.5)
        pow_tensor_scalar = torch.ops.aten.pow.Tensor_Scalar(view_default_10, 3.0)
        mul_tensor_1 = torch.ops.aten.mul.Tensor(pow_tensor_scalar, 0.044715);  pow_tensor_scalar = None
        add_tensor_1 = torch.ops.aten.add.Tensor(view_default_10, mul_tensor_1);  mul_tensor_1 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(add_tensor_1, 0.7978845608028654);  add_tensor_1 = None
        tanh_default = torch.ops.aten.tanh.default(mul_tensor_2);  mul_tensor_2 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(tanh_default, 1.0)
        mul_tensor_3 = torch.ops.aten.mul.Tensor(mul_tensor, add_tensor_2)
        view_default_11 = torch.ops.aten.view.default(mul_tensor_3, [-1, 3072]);  mul_tensor_3 = None
        addmm_default_3 = torch.ops.aten.addmm.default(primals_13, view_default_11, primals_14);  primals_13 = None
        view_default_12 = torch.ops.aten.view.default(addmm_default_3, [4, 512, 768]);  addmm_default_3 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(add_tensor, view_default_12);  view_default_12 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(add_tensor_3, tangents_1)
        is_same_size_default_1 = torch.ops.aten.is_same_size.default(permute_default_1, tangents_2)
        is_same_size_default_2 = torch.ops.aten.is_same_size.default(permute_default_2, tangents_3)
        view_default_13 = torch.ops.aten.view.default(tangents_1, [2048, 768])
        t_default = torch.ops.aten.t.default(primals_14);  primals_14 = None
        mm_default = torch.ops.aten.mm.default(view_default_13, t_default);  t_default = None
        t_default_1 = torch.ops.aten.t.default(view_default_11);  view_default_11 = None
        mm_default_1 = torch.ops.aten.mm.default(t_default_1, view_default_13);  t_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(view_default_13, [0], True);  view_default_13 = None
        view_default_14 = torch.ops.aten.view.default(sum_dim_int_list, [768]);  sum_dim_int_list = None
        view_default_15 = torch.ops.aten.view.default(mm_default, [4, 512, 3072]);  mm_default = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(view_default_15, mul_tensor);  mul_tensor = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(view_default_15, add_tensor_2);  view_default_15 = add_tensor_2 = None
        to_dtype = torch.ops.aten.to.dtype(mul_tensor_4, torch.float32);  mul_tensor_4 = None
        to_dtype_1 = torch.ops.aten.to.dtype(tanh_default, torch.float32);  tanh_default = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(to_dtype_1, to_dtype_1);  to_dtype_1 = None
        rsub_scalar = torch.ops.aten.rsub.Scalar(mul_tensor_6, 1);  mul_tensor_6 = None
        conj_physical_default = torch.ops.aten.conj_physical.default(rsub_scalar);  rsub_scalar = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(to_dtype, conj_physical_default);  to_dtype = conj_physical_default = None
        to_dtype_2 = torch.ops.aten.to.dtype(mul_tensor_7, torch.float32);  mul_tensor_7 = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(to_dtype_2, 0.7978845608028654);  to_dtype_2 = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(mul_tensor_8, 0.044715)
        pow_tensor_scalar_1 = torch.ops.aten.pow.Tensor_Scalar(view_default_10, 2.0);  view_default_10 = None
        mul_scalar = torch.ops.aten.mul.Scalar(pow_tensor_scalar_1, 3.0);  pow_tensor_scalar_1 = None
        mul_tensor_10 = torch.ops.aten.mul.Tensor(mul_tensor_9, mul_scalar);  mul_tensor_9 = mul_scalar = None
        add_tensor_4 = torch.ops.aten.add.Tensor(mul_tensor_8, mul_tensor_10);  mul_tensor_8 = mul_tensor_10 = None
        mul_tensor_11 = torch.ops.aten.mul.Tensor(mul_tensor_5, 0.5);  mul_tensor_5 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(add_tensor_4, mul_tensor_11);  add_tensor_4 = mul_tensor_11 = None
        view_default_16 = torch.ops.aten.view.default(add_tensor_5, [2048, 3072]);  add_tensor_5 = None
        t_default_2 = torch.ops.aten.t.default(primals_12);  primals_12 = None
        mm_default_2 = torch.ops.aten.mm.default(view_default_16, t_default_2);  t_default_2 = None
        t_default_3 = torch.ops.aten.t.default(view_default_9);  view_default_9 = None
        mm_default_3 = torch.ops.aten.mm.default(t_default_3, view_default_16);  t_default_3 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(view_default_16, [0], True);  view_default_16 = None
        view_default_17 = torch.ops.aten.view.default(sum_dim_int_list_1, [3072]);  sum_dim_int_list_1 = None
        view_default_18 = torch.ops.aten.view.default(mm_default_2, [4, 512, 768]);  mm_default_2 = None
        native_layer_norm_backward_default = torch.ops.aten.native_layer_norm_backward.default(view_default_18, add_tensor, [768], getitem_7, getitem_8, primals_10, primals_9, [True, True, True]);  view_default_18 = add_tensor = getitem_7 = getitem_8 = primals_10 = primals_9 = None
        getitem_9 = native_layer_norm_backward_default[0]
        getitem_10 = native_layer_norm_backward_default[1]
        getitem_11 = native_layer_norm_backward_default[2];  native_layer_norm_backward_default = None
        add_tensor_6 = torch.ops.aten.add.Tensor(tangents_1, getitem_9);  tangents_1 = getitem_9 = None
        view_default_19 = torch.ops.aten.view.default(add_tensor_6, [2048, 768])
        t_default_4 = torch.ops.aten.t.default(primals_5);  primals_5 = None
        mm_default_4 = torch.ops.aten.mm.default(view_default_19, t_default_4);  t_default_4 = None
        t_default_5 = torch.ops.aten.t.default(view_default_7);  view_default_7 = None
        mm_default_5 = torch.ops.aten.mm.default(t_default_5, view_default_19);  t_default_5 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(view_default_19, [0], True);  view_default_19 = None
        view_default_20 = torch.ops.aten.view.default(sum_dim_int_list_2, [768]);  sum_dim_int_list_2 = None
        view_default_21 = torch.ops.aten.view.default(mm_default_4, [4, 512, 768]);  mm_default_4 = None
        view_default_22 = torch.ops.aten.view.default(view_default_21, [4, 512, 12, 64]);  view_default_21 = None
        permute_default_4 = torch.ops.aten.permute.default(view_default_22, [0, 2, 1, 3]);  view_default_22 = None
        clone_default_4 = torch.ops.aten.clone.default(permute_default_4, memory_format = torch.contiguous_format);  permute_default_4 = None
        _unsafe_view_default_5 = torch.ops.aten._unsafe_view.default(clone_default_4, [48, 512, 64]);  clone_default_4 = None
        transpose_int_1 = torch.ops.aten.transpose.int(view_default_5, 1, 2);  view_default_5 = None
        bmm_default_2 = torch.ops.aten.bmm.default(transpose_int_1, _unsafe_view_default_5);  transpose_int_1 = None
        transpose_int_2 = torch.ops.aten.transpose.int(_unsafe_view_default_3, 1, 2);  _unsafe_view_default_3 = None
        bmm_default_3 = torch.ops.aten.bmm.default(_unsafe_view_default_5, transpose_int_2);  _unsafe_view_default_5 = transpose_int_2 = None
        view_default_23 = torch.ops.aten.view.default(bmm_default_2, [4, 12, 512, 64]);  bmm_default_2 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(tangents_3, view_default_23);  tangents_3 = view_default_23 = None
        view_default_24 = torch.ops.aten.view.default(bmm_default_3, [4, 12, 512, 512]);  bmm_default_3 = None
        _softmax_backward_data_default = torch.ops.aten._softmax_backward_data.default(view_default_24, _softmax_default, -1, torch.float32);  view_default_24 = _softmax_default = None
        empty_like_default = torch.ops.aten.empty_like.default(_softmax_backward_data_default)
        zero__default = torch.ops.aten.zero_.default(empty_like_default);  empty_like_default = None
        where_self_1 = torch.ops.aten.where.self(_to_copy_default, _softmax_backward_data_default, zero__default);  _to_copy_default = _softmax_backward_data_default = zero__default = None
        div_tensor_1 = torch.ops.aten.div.Tensor(where_self_1, 8.0);  where_self_1 = None
        view_default_25 = torch.ops.aten.view.default(div_tensor_1, [48, 512, 512]);  div_tensor_1 = None
        transpose_int_3 = torch.ops.aten.transpose.int(_unsafe_view_default, 1, 2);  _unsafe_view_default = None
        bmm_default_4 = torch.ops.aten.bmm.default(transpose_int_3, view_default_25);  transpose_int_3 = None
        transpose_int_4 = torch.ops.aten.transpose.int(_unsafe_view_default_1, 1, 2);  _unsafe_view_default_1 = None
        bmm_default_5 = torch.ops.aten.bmm.default(view_default_25, transpose_int_4);  view_default_25 = transpose_int_4 = None
        view_default_26 = torch.ops.aten.view.default(bmm_default_4, [4, 12, 64, 512]);  bmm_default_4 = None
        view_default_27 = torch.ops.aten.view.default(bmm_default_5, [4, 12, 512, 64]);  bmm_default_5 = None
        transpose_int_5 = torch.ops.aten.transpose.int(view_default_26, -1, -2);  view_default_26 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(tangents_2, transpose_int_5);  tangents_2 = transpose_int_5 = None
        permute_default_5 = torch.ops.aten.permute.default(add_tensor_7, [0, 2, 1, 3]);  add_tensor_7 = None
        clone_default_5 = torch.ops.aten.clone.default(permute_default_5, memory_format = torch.contiguous_format);  permute_default_5 = None
        _unsafe_view_default_6 = torch.ops.aten._unsafe_view.default(clone_default_5, [4, 512, 768]);  clone_default_5 = None
        permute_default_6 = torch.ops.aten.permute.default(add_tensor_8, [0, 2, 1, 3]);  add_tensor_8 = None
        clone_default_6 = torch.ops.aten.clone.default(permute_default_6, memory_format = torch.contiguous_format);  permute_default_6 = None
        _unsafe_view_default_7 = torch.ops.aten._unsafe_view.default(clone_default_6, [4, 512, 768]);  clone_default_6 = None
        permute_default_7 = torch.ops.aten.permute.default(view_default_27, [0, 2, 1, 3]);  view_default_27 = None
        clone_default_7 = torch.ops.aten.clone.default(permute_default_7, memory_format = torch.contiguous_format);  permute_default_7 = None
        _unsafe_view_default_8 = torch.ops.aten._unsafe_view.default(clone_default_7, [4, 512, 768]);  clone_default_7 = None
        cat_default = torch.ops.aten.cat.default([_unsafe_view_default_8, _unsafe_view_default_7, _unsafe_view_default_6], 2);  _unsafe_view_default_8 = _unsafe_view_default_7 = _unsafe_view_default_6 = None
        view_default_28 = torch.ops.aten.view.default(cat_default, [2048, 2304]);  cat_default = None
        t_default_6 = torch.ops.aten.t.default(primals_3);  primals_3 = None
        mm_default_6 = torch.ops.aten.mm.default(view_default_28, t_default_6);  t_default_6 = None
        t_default_7 = torch.ops.aten.t.default(view_default);  view_default = None
        mm_default_7 = torch.ops.aten.mm.default(t_default_7, view_default_28);  t_default_7 = None
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(view_default_28, [0], True);  view_default_28 = None
        view_default_29 = torch.ops.aten.view.default(sum_dim_int_list_3, [2304]);  sum_dim_int_list_3 = None
        view_default_30 = torch.ops.aten.view.default(mm_default_6, [4, 512, 768]);  mm_default_6 = None
        native_layer_norm_backward_default_1 = torch.ops.aten.native_layer_norm_backward.default(view_default_30, primals_15, [768], getitem_1, getitem_2, primals_8, primals_7, [True, True, True]);  view_default_30 = primals_15 = getitem_1 = getitem_2 = primals_8 = primals_7 = None
        getitem_12 = native_layer_norm_backward_default_1[0]
        getitem_13 = native_layer_norm_backward_default_1[1]
        getitem_14 = native_layer_norm_backward_default_1[2];  native_layer_norm_backward_default_1 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(add_tensor_6, getitem_12);  add_tensor_6 = getitem_12 = None
        return [add_tensor_3, permute_default_1, permute_default_2, None, view_default_29, mm_default_7, view_default_20, mm_default_5, None, getitem_14, getitem_13, getitem_11, getitem_10, view_default_17, mm_default_3, view_default_14, mm_default_1, add_tensor_9]
        
