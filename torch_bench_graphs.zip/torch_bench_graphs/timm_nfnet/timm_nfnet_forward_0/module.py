
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/timm_nfnet/timm_nfnet_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234):
        constant_pad_nd_default = torch.ops.aten.constant_pad_nd.default(primals_234, [0, 1, 0, 1], 0.0);  primals_234 = None
        view_default = torch.ops.aten.view.default(primals_224, [1, 16, -1]);  primals_224 = None
        mul_tensor = torch.ops.aten.mul.Tensor(primals_223, 0.19245008972987526);  primals_223 = None
        view_default_1 = torch.ops.aten.view.default(mul_tensor, [-1]);  mul_tensor = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(view_default, view_default_1, None, None, None, True, 0.0, 1e-05)
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        view_default_2 = torch.ops.aten.view.default(getitem, [16, 3, 3, 3]);  getitem = None
        convolution_default = torch.ops.aten.convolution.default(constant_pad_nd_default, view_default_2, primals_222, [2, 2], [0, 0], [1, 1], False, [0, 0], 1);  primals_222 = None
        gelu_default = torch.ops.aten.gelu.default(convolution_default)
        mul__tensor = torch.ops.aten.mul_.Tensor(gelu_default, 1.7015043497085571);  gelu_default = None
        view_default_3 = torch.ops.aten.view.default(primals_227, [1, 32, -1]);  primals_227 = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(primals_226, 0.08333333333333333);  primals_226 = None
        view_default_4 = torch.ops.aten.view.default(mul_tensor_1, [-1]);  mul_tensor_1 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(view_default_3, view_default_4, None, None, None, True, 0.0, 1e-05)
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        view_default_5 = torch.ops.aten.view.default(getitem_3, [32, 16, 3, 3]);  getitem_3 = None
        convolution_default_1 = torch.ops.aten.convolution.default(mul__tensor, view_default_5, primals_225, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_225 = None
        gelu_default_1 = torch.ops.aten.gelu.default(convolution_default_1)
        mul__tensor_1 = torch.ops.aten.mul_.Tensor(gelu_default_1, 1.7015043497085571);  gelu_default_1 = None
        view_default_6 = torch.ops.aten.view.default(primals_230, [1, 64, -1]);  primals_230 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(primals_229, 0.05892556509887896);  primals_229 = None
        view_default_7 = torch.ops.aten.view.default(mul_tensor_2, [-1]);  mul_tensor_2 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(view_default_6, view_default_7, None, None, None, True, 0.0, 1e-05)
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        view_default_8 = torch.ops.aten.view.default(getitem_6, [64, 32, 3, 3]);  getitem_6 = None
        convolution_default_2 = torch.ops.aten.convolution.default(mul__tensor_1, view_default_8, primals_228, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_228 = None
        gelu_default_2 = torch.ops.aten.gelu.default(convolution_default_2)
        mul__tensor_2 = torch.ops.aten.mul_.Tensor(gelu_default_2, 1.7015043497085571);  gelu_default_2 = None
        constant_pad_nd_default_1 = torch.ops.aten.constant_pad_nd.default(mul__tensor_2, [0, 1, 0, 1], 0.0);  mul__tensor_2 = None
        view_default_9 = torch.ops.aten.view.default(primals_233, [1, 128, -1]);  primals_233 = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(primals_232, 0.041666666666666664);  primals_232 = None
        view_default_10 = torch.ops.aten.view.default(mul_tensor_3, [-1]);  mul_tensor_3 = None
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(view_default_9, view_default_10, None, None, None, True, 0.0, 1e-05)
        getitem_9 = native_batch_norm_default_3[0]
        getitem_10 = native_batch_norm_default_3[1]
        getitem_11 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        view_default_11 = torch.ops.aten.view.default(getitem_9, [128, 64, 3, 3]);  getitem_9 = None
        convolution_default_3 = torch.ops.aten.convolution.default(constant_pad_nd_default_1, view_default_11, primals_231, [2, 2], [0, 0], [1, 1], False, [0, 0], 1);  primals_231 = None
        gelu_default_3 = torch.ops.aten.gelu.default(convolution_default_3)
        mul__tensor_3 = torch.ops.aten.mul_.Tensor(gelu_default_3, 1.7015043497085571);  gelu_default_3 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(mul__tensor_3, 1.0);  mul__tensor_3 = None
        view_default_12 = torch.ops.aten.view.default(primals_24, [1, 256, -1]);  primals_24 = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(primals_23, 0.08838834764831845);  primals_23 = None
        view_default_13 = torch.ops.aten.view.default(mul_tensor_5, [-1]);  mul_tensor_5 = None
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(view_default_12, view_default_13, None, None, None, True, 0.0, 1e-05)
        getitem_12 = native_batch_norm_default_4[0]
        getitem_13 = native_batch_norm_default_4[1]
        getitem_14 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        view_default_14 = torch.ops.aten.view.default(getitem_12, [256, 128, 1, 1]);  getitem_12 = None
        convolution_default_4 = torch.ops.aten.convolution.default(mul_tensor_4, view_default_14, primals_22, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_22 = None
        view_default_15 = torch.ops.aten.view.default(primals_12, [1, 128, -1]);  primals_12 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(primals_11, 0.08838834764831845);  primals_11 = None
        view_default_16 = torch.ops.aten.view.default(mul_tensor_6, [-1]);  mul_tensor_6 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(view_default_15, view_default_16, None, None, None, True, 0.0, 1e-05)
        getitem_15 = native_batch_norm_default_5[0]
        getitem_16 = native_batch_norm_default_5[1]
        getitem_17 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        view_default_17 = torch.ops.aten.view.default(getitem_15, [128, 128, 1, 1]);  getitem_15 = None
        convolution_default_5 = torch.ops.aten.convolution.default(mul_tensor_4, view_default_17, primals_10, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_10 = None
        gelu_default_4 = torch.ops.aten.gelu.default(convolution_default_5)
        mul__tensor_4 = torch.ops.aten.mul_.Tensor(gelu_default_4, 1.7015043497085571);  gelu_default_4 = None
        view_default_18 = torch.ops.aten.view.default(primals_15, [1, 128, -1]);  primals_15 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(primals_14, 0.02946278254943948);  primals_14 = None
        view_default_19 = torch.ops.aten.view.default(mul_tensor_7, [-1]);  mul_tensor_7 = None
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(view_default_18, view_default_19, None, None, None, True, 0.0, 1e-05)
        getitem_18 = native_batch_norm_default_6[0]
        getitem_19 = native_batch_norm_default_6[1]
        getitem_20 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        view_default_20 = torch.ops.aten.view.default(getitem_18, [128, 128, 3, 3]);  getitem_18 = None
        convolution_default_6 = torch.ops.aten.convolution.default(mul__tensor_4, view_default_20, primals_13, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_13 = None
        gelu_default_5 = torch.ops.aten.gelu.default(convolution_default_6)
        mul__tensor_5 = torch.ops.aten.mul_.Tensor(gelu_default_5, 1.7015043497085571);  gelu_default_5 = None
        view_default_21 = torch.ops.aten.view.default(primals_18, [1, 128, -1]);  primals_18 = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(primals_17, 0.02946278254943948);  primals_17 = None
        view_default_22 = torch.ops.aten.view.default(mul_tensor_8, [-1]);  mul_tensor_8 = None
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(view_default_21, view_default_22, None, None, None, True, 0.0, 1e-05)
        getitem_21 = native_batch_norm_default_7[0]
        getitem_22 = native_batch_norm_default_7[1]
        getitem_23 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        view_default_23 = torch.ops.aten.view.default(getitem_21, [128, 128, 3, 3]);  getitem_21 = None
        convolution_default_7 = torch.ops.aten.convolution.default(mul__tensor_5, view_default_23, primals_16, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_16 = None
        gelu_default_6 = torch.ops.aten.gelu.default(convolution_default_7)
        mul__tensor_6 = torch.ops.aten.mul_.Tensor(gelu_default_6, 1.7015043497085571);  gelu_default_6 = None
        view_default_24 = torch.ops.aten.view.default(primals_21, [1, 256, -1]);  primals_21 = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(primals_20, 0.08838834764831845);  primals_20 = None
        view_default_25 = torch.ops.aten.view.default(mul_tensor_9, [-1]);  mul_tensor_9 = None
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(view_default_24, view_default_25, None, None, None, True, 0.0, 1e-05)
        getitem_24 = native_batch_norm_default_8[0]
        getitem_25 = native_batch_norm_default_8[1]
        getitem_26 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        view_default_26 = torch.ops.aten.view.default(getitem_24, [256, 128, 1, 1]);  getitem_24 = None
        convolution_default_8 = torch.ops.aten.convolution.default(mul__tensor_6, view_default_26, primals_19, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_19 = None
        mean_dim = torch.ops.aten.mean.dim(convolution_default_8, [2, 3], True)
        convolution_default_9 = torch.ops.aten.convolution.default(mean_dim, primals_7, primals_6, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_6 = None
        relu__default = torch.ops.aten.relu_.default(convolution_default_9);  convolution_default_9 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default, primals_9, primals_8, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_8 = None
        sigmoid_default = torch.ops.aten.sigmoid.default(convolution_default_10);  convolution_default_10 = None
        mul_tensor_10 = torch.ops.aten.mul.Tensor(convolution_default_8, sigmoid_default)
        mul_tensor_11 = torch.ops.aten.mul.Tensor(mul_tensor_10, 2.0);  mul_tensor_10 = None
        mul__tensor_7 = torch.ops.aten.mul_.Tensor(mul_tensor_11, primals_25)
        mul_tensor_12 = torch.ops.aten.mul.Tensor(mul__tensor_7, 0.2);  mul__tensor_7 = None
        add_tensor = torch.ops.aten.add.Tensor(mul_tensor_12, convolution_default_4);  mul_tensor_12 = convolution_default_4 = None
        gelu_default_7 = torch.ops.aten.gelu.default(add_tensor)
        mul__tensor_8 = torch.ops.aten.mul_.Tensor(gelu_default_7, 1.7015043497085571);  gelu_default_7 = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(mul__tensor_8, 0.9805806756909201);  mul__tensor_8 = None
        avg_pool2d_default = torch.ops.aten.avg_pool2d.default(mul_tensor_13, [2, 2], [2, 2], [0, 0], True, False)
        view_default_27 = torch.ops.aten.view.default(primals_44, [1, 512, -1]);  primals_44 = None
        mul_tensor_14 = torch.ops.aten.mul.Tensor(primals_43, 0.0625);  primals_43 = None
        view_default_28 = torch.ops.aten.view.default(mul_tensor_14, [-1]);  mul_tensor_14 = None
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(view_default_27, view_default_28, None, None, None, True, 0.0, 1e-05)
        getitem_27 = native_batch_norm_default_9[0]
        getitem_28 = native_batch_norm_default_9[1]
        getitem_29 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        view_default_29 = torch.ops.aten.view.default(getitem_27, [512, 256, 1, 1]);  getitem_27 = None
        convolution_default_11 = torch.ops.aten.convolution.default(avg_pool2d_default, view_default_29, primals_42, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_42 = None
        view_default_30 = torch.ops.aten.view.default(primals_32, [1, 256, -1]);  primals_32 = None
        mul_tensor_15 = torch.ops.aten.mul.Tensor(primals_31, 0.0625);  primals_31 = None
        view_default_31 = torch.ops.aten.view.default(mul_tensor_15, [-1]);  mul_tensor_15 = None
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(view_default_30, view_default_31, None, None, None, True, 0.0, 1e-05)
        getitem_30 = native_batch_norm_default_10[0]
        getitem_31 = native_batch_norm_default_10[1]
        getitem_32 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        view_default_32 = torch.ops.aten.view.default(getitem_30, [256, 256, 1, 1]);  getitem_30 = None
        convolution_default_12 = torch.ops.aten.convolution.default(mul_tensor_13, view_default_32, primals_30, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_30 = None
        gelu_default_8 = torch.ops.aten.gelu.default(convolution_default_12)
        mul__tensor_9 = torch.ops.aten.mul_.Tensor(gelu_default_8, 1.7015043497085571);  gelu_default_8 = None
        constant_pad_nd_default_2 = torch.ops.aten.constant_pad_nd.default(mul__tensor_9, [0, 1, 0, 1], 0.0);  mul__tensor_9 = None
        view_default_33 = torch.ops.aten.view.default(primals_35, [1, 256, -1]);  primals_35 = None
        mul_tensor_16 = torch.ops.aten.mul.Tensor(primals_34, 0.02946278254943948);  primals_34 = None
        view_default_34 = torch.ops.aten.view.default(mul_tensor_16, [-1]);  mul_tensor_16 = None
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(view_default_33, view_default_34, None, None, None, True, 0.0, 1e-05)
        getitem_33 = native_batch_norm_default_11[0]
        getitem_34 = native_batch_norm_default_11[1]
        getitem_35 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        view_default_35 = torch.ops.aten.view.default(getitem_33, [256, 128, 3, 3]);  getitem_33 = None
        convolution_default_13 = torch.ops.aten.convolution.default(constant_pad_nd_default_2, view_default_35, primals_33, [2, 2], [0, 0], [1, 1], False, [0, 0], 2);  primals_33 = None
        gelu_default_9 = torch.ops.aten.gelu.default(convolution_default_13)
        mul__tensor_10 = torch.ops.aten.mul_.Tensor(gelu_default_9, 1.7015043497085571);  gelu_default_9 = None
        view_default_36 = torch.ops.aten.view.default(primals_38, [1, 256, -1]);  primals_38 = None
        mul_tensor_17 = torch.ops.aten.mul.Tensor(primals_37, 0.02946278254943948);  primals_37 = None
        view_default_37 = torch.ops.aten.view.default(mul_tensor_17, [-1]);  mul_tensor_17 = None
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(view_default_36, view_default_37, None, None, None, True, 0.0, 1e-05)
        getitem_36 = native_batch_norm_default_12[0]
        getitem_37 = native_batch_norm_default_12[1]
        getitem_38 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        view_default_38 = torch.ops.aten.view.default(getitem_36, [256, 128, 3, 3]);  getitem_36 = None
        convolution_default_14 = torch.ops.aten.convolution.default(mul__tensor_10, view_default_38, primals_36, [1, 1], [1, 1], [1, 1], False, [0, 0], 2);  primals_36 = None
        gelu_default_10 = torch.ops.aten.gelu.default(convolution_default_14)
        mul__tensor_11 = torch.ops.aten.mul_.Tensor(gelu_default_10, 1.7015043497085571);  gelu_default_10 = None
        view_default_39 = torch.ops.aten.view.default(primals_41, [1, 512, -1]);  primals_41 = None
        mul_tensor_18 = torch.ops.aten.mul.Tensor(primals_40, 0.0625);  primals_40 = None
        view_default_40 = torch.ops.aten.view.default(mul_tensor_18, [-1]);  mul_tensor_18 = None
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(view_default_39, view_default_40, None, None, None, True, 0.0, 1e-05)
        getitem_39 = native_batch_norm_default_13[0]
        getitem_40 = native_batch_norm_default_13[1]
        getitem_41 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        view_default_41 = torch.ops.aten.view.default(getitem_39, [512, 256, 1, 1]);  getitem_39 = None
        convolution_default_15 = torch.ops.aten.convolution.default(mul__tensor_11, view_default_41, primals_39, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_39 = None
        mean_dim_1 = torch.ops.aten.mean.dim(convolution_default_15, [2, 3], True)
        convolution_default_16 = torch.ops.aten.convolution.default(mean_dim_1, primals_27, primals_26, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_26 = None
        relu__default_1 = torch.ops.aten.relu_.default(convolution_default_16);  convolution_default_16 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu__default_1, primals_29, primals_28, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_28 = None
        sigmoid_default_1 = torch.ops.aten.sigmoid.default(convolution_default_17);  convolution_default_17 = None
        mul_tensor_19 = torch.ops.aten.mul.Tensor(convolution_default_15, sigmoid_default_1)
        mul_tensor_20 = torch.ops.aten.mul.Tensor(mul_tensor_19, 2.0);  mul_tensor_19 = None
        mul__tensor_12 = torch.ops.aten.mul_.Tensor(mul_tensor_20, primals_45)
        mul_tensor_21 = torch.ops.aten.mul.Tensor(mul__tensor_12, 0.2);  mul__tensor_12 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(mul_tensor_21, convolution_default_11);  mul_tensor_21 = convolution_default_11 = None
        gelu_default_11 = torch.ops.aten.gelu.default(add_tensor_1)
        mul__tensor_13 = torch.ops.aten.mul_.Tensor(gelu_default_11, 1.7015043497085571);  gelu_default_11 = None
        mul_tensor_22 = torch.ops.aten.mul.Tensor(mul__tensor_13, 0.9805806756909201);  mul__tensor_13 = None
        view_default_42 = torch.ops.aten.view.default(primals_52, [1, 256, -1]);  primals_52 = None
        mul_tensor_23 = torch.ops.aten.mul.Tensor(primals_51, 0.04419417382415922);  primals_51 = None
        view_default_43 = torch.ops.aten.view.default(mul_tensor_23, [-1]);  mul_tensor_23 = None
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(view_default_42, view_default_43, None, None, None, True, 0.0, 1e-05)
        getitem_42 = native_batch_norm_default_14[0]
        getitem_43 = native_batch_norm_default_14[1]
        getitem_44 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        view_default_44 = torch.ops.aten.view.default(getitem_42, [256, 512, 1, 1]);  getitem_42 = None
        convolution_default_18 = torch.ops.aten.convolution.default(mul_tensor_22, view_default_44, primals_50, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_50 = None
        gelu_default_12 = torch.ops.aten.gelu.default(convolution_default_18)
        mul__tensor_14 = torch.ops.aten.mul_.Tensor(gelu_default_12, 1.7015043497085571);  gelu_default_12 = None
        view_default_45 = torch.ops.aten.view.default(primals_55, [1, 256, -1]);  primals_55 = None
        mul_tensor_24 = torch.ops.aten.mul.Tensor(primals_54, 0.02946278254943948);  primals_54 = None
        view_default_46 = torch.ops.aten.view.default(mul_tensor_24, [-1]);  mul_tensor_24 = None
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(view_default_45, view_default_46, None, None, None, True, 0.0, 1e-05)
        getitem_45 = native_batch_norm_default_15[0]
        getitem_46 = native_batch_norm_default_15[1]
        getitem_47 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        view_default_47 = torch.ops.aten.view.default(getitem_45, [256, 128, 3, 3]);  getitem_45 = None
        convolution_default_19 = torch.ops.aten.convolution.default(mul__tensor_14, view_default_47, primals_53, [1, 1], [1, 1], [1, 1], False, [0, 0], 2);  primals_53 = None
        gelu_default_13 = torch.ops.aten.gelu.default(convolution_default_19)
        mul__tensor_15 = torch.ops.aten.mul_.Tensor(gelu_default_13, 1.7015043497085571);  gelu_default_13 = None
        view_default_48 = torch.ops.aten.view.default(primals_58, [1, 256, -1]);  primals_58 = None
        mul_tensor_25 = torch.ops.aten.mul.Tensor(primals_57, 0.02946278254943948);  primals_57 = None
        view_default_49 = torch.ops.aten.view.default(mul_tensor_25, [-1]);  mul_tensor_25 = None
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(view_default_48, view_default_49, None, None, None, True, 0.0, 1e-05)
        getitem_48 = native_batch_norm_default_16[0]
        getitem_49 = native_batch_norm_default_16[1]
        getitem_50 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        view_default_50 = torch.ops.aten.view.default(getitem_48, [256, 128, 3, 3]);  getitem_48 = None
        convolution_default_20 = torch.ops.aten.convolution.default(mul__tensor_15, view_default_50, primals_56, [1, 1], [1, 1], [1, 1], False, [0, 0], 2);  primals_56 = None
        gelu_default_14 = torch.ops.aten.gelu.default(convolution_default_20)
        mul__tensor_16 = torch.ops.aten.mul_.Tensor(gelu_default_14, 1.7015043497085571);  gelu_default_14 = None
        view_default_51 = torch.ops.aten.view.default(primals_61, [1, 512, -1]);  primals_61 = None
        mul_tensor_26 = torch.ops.aten.mul.Tensor(primals_60, 0.0625);  primals_60 = None
        view_default_52 = torch.ops.aten.view.default(mul_tensor_26, [-1]);  mul_tensor_26 = None
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(view_default_51, view_default_52, None, None, None, True, 0.0, 1e-05)
        getitem_51 = native_batch_norm_default_17[0]
        getitem_52 = native_batch_norm_default_17[1]
        getitem_53 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        view_default_53 = torch.ops.aten.view.default(getitem_51, [512, 256, 1, 1]);  getitem_51 = None
        convolution_default_21 = torch.ops.aten.convolution.default(mul__tensor_16, view_default_53, primals_59, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_59 = None
        mean_dim_2 = torch.ops.aten.mean.dim(convolution_default_21, [2, 3], True)
        convolution_default_22 = torch.ops.aten.convolution.default(mean_dim_2, primals_47, primals_46, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_46 = None
        relu__default_2 = torch.ops.aten.relu_.default(convolution_default_22);  convolution_default_22 = None
        convolution_default_23 = torch.ops.aten.convolution.default(relu__default_2, primals_49, primals_48, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_48 = None
        sigmoid_default_2 = torch.ops.aten.sigmoid.default(convolution_default_23);  convolution_default_23 = None
        mul_tensor_27 = torch.ops.aten.mul.Tensor(convolution_default_21, sigmoid_default_2)
        mul_tensor_28 = torch.ops.aten.mul.Tensor(mul_tensor_27, 2.0);  mul_tensor_27 = None
        mul__tensor_17 = torch.ops.aten.mul_.Tensor(mul_tensor_28, primals_62)
        mul_tensor_29 = torch.ops.aten.mul.Tensor(mul__tensor_17, 0.2);  mul__tensor_17 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(mul_tensor_29, add_tensor_1);  mul_tensor_29 = None
        gelu_default_15 = torch.ops.aten.gelu.default(add_tensor_2)
        mul__tensor_18 = torch.ops.aten.mul_.Tensor(gelu_default_15, 1.7015043497085571);  gelu_default_15 = None
        mul_tensor_30 = torch.ops.aten.mul.Tensor(mul__tensor_18, 0.9622504486493761);  mul__tensor_18 = None
        avg_pool2d_default_1 = torch.ops.aten.avg_pool2d.default(mul_tensor_30, [2, 2], [2, 2], [0, 0], True, False)
        view_default_54 = torch.ops.aten.view.default(primals_81, [1, 1536, -1]);  primals_81 = None
        mul_tensor_31 = torch.ops.aten.mul.Tensor(primals_80, 0.04419417382415922);  primals_80 = None
        view_default_55 = torch.ops.aten.view.default(mul_tensor_31, [-1]);  mul_tensor_31 = None
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(view_default_54, view_default_55, None, None, None, True, 0.0, 1e-05)
        getitem_54 = native_batch_norm_default_18[0]
        getitem_55 = native_batch_norm_default_18[1]
        getitem_56 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        view_default_56 = torch.ops.aten.view.default(getitem_54, [1536, 512, 1, 1]);  getitem_54 = None
        convolution_default_24 = torch.ops.aten.convolution.default(avg_pool2d_default_1, view_default_56, primals_79, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_79 = None
        view_default_57 = torch.ops.aten.view.default(primals_69, [1, 768, -1]);  primals_69 = None
        mul_tensor_32 = torch.ops.aten.mul.Tensor(primals_68, 0.04419417382415922);  primals_68 = None
        view_default_58 = torch.ops.aten.view.default(mul_tensor_32, [-1]);  mul_tensor_32 = None
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(view_default_57, view_default_58, None, None, None, True, 0.0, 1e-05)
        getitem_57 = native_batch_norm_default_19[0]
        getitem_58 = native_batch_norm_default_19[1]
        getitem_59 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        view_default_59 = torch.ops.aten.view.default(getitem_57, [768, 512, 1, 1]);  getitem_57 = None
        convolution_default_25 = torch.ops.aten.convolution.default(mul_tensor_30, view_default_59, primals_67, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_67 = None
        gelu_default_16 = torch.ops.aten.gelu.default(convolution_default_25)
        mul__tensor_19 = torch.ops.aten.mul_.Tensor(gelu_default_16, 1.7015043497085571);  gelu_default_16 = None
        constant_pad_nd_default_3 = torch.ops.aten.constant_pad_nd.default(mul__tensor_19, [0, 1, 0, 1], 0.0);  mul__tensor_19 = None
        view_default_60 = torch.ops.aten.view.default(primals_72, [1, 768, -1]);  primals_72 = None
        mul_tensor_33 = torch.ops.aten.mul.Tensor(primals_71, 0.02946278254943948);  primals_71 = None
        view_default_61 = torch.ops.aten.view.default(mul_tensor_33, [-1]);  mul_tensor_33 = None
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(view_default_60, view_default_61, None, None, None, True, 0.0, 1e-05)
        getitem_60 = native_batch_norm_default_20[0]
        getitem_61 = native_batch_norm_default_20[1]
        getitem_62 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        view_default_62 = torch.ops.aten.view.default(getitem_60, [768, 128, 3, 3]);  getitem_60 = None
        convolution_default_26 = torch.ops.aten.convolution.default(constant_pad_nd_default_3, view_default_62, primals_70, [2, 2], [0, 0], [1, 1], False, [0, 0], 6);  primals_70 = None
        gelu_default_17 = torch.ops.aten.gelu.default(convolution_default_26)
        mul__tensor_20 = torch.ops.aten.mul_.Tensor(gelu_default_17, 1.7015043497085571);  gelu_default_17 = None
        view_default_63 = torch.ops.aten.view.default(primals_75, [1, 768, -1]);  primals_75 = None
        mul_tensor_34 = torch.ops.aten.mul.Tensor(primals_74, 0.02946278254943948);  primals_74 = None
        view_default_64 = torch.ops.aten.view.default(mul_tensor_34, [-1]);  mul_tensor_34 = None
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(view_default_63, view_default_64, None, None, None, True, 0.0, 1e-05)
        getitem_63 = native_batch_norm_default_21[0]
        getitem_64 = native_batch_norm_default_21[1]
        getitem_65 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        view_default_65 = torch.ops.aten.view.default(getitem_63, [768, 128, 3, 3]);  getitem_63 = None
        convolution_default_27 = torch.ops.aten.convolution.default(mul__tensor_20, view_default_65, primals_73, [1, 1], [1, 1], [1, 1], False, [0, 0], 6);  primals_73 = None
        gelu_default_18 = torch.ops.aten.gelu.default(convolution_default_27)
        mul__tensor_21 = torch.ops.aten.mul_.Tensor(gelu_default_18, 1.7015043497085571);  gelu_default_18 = None
        view_default_66 = torch.ops.aten.view.default(primals_78, [1, 1536, -1]);  primals_78 = None
        mul_tensor_35 = torch.ops.aten.mul.Tensor(primals_77, 0.03608439182435161);  primals_77 = None
        view_default_67 = torch.ops.aten.view.default(mul_tensor_35, [-1]);  mul_tensor_35 = None
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(view_default_66, view_default_67, None, None, None, True, 0.0, 1e-05)
        getitem_66 = native_batch_norm_default_22[0]
        getitem_67 = native_batch_norm_default_22[1]
        getitem_68 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        view_default_68 = torch.ops.aten.view.default(getitem_66, [1536, 768, 1, 1]);  getitem_66 = None
        convolution_default_28 = torch.ops.aten.convolution.default(mul__tensor_21, view_default_68, primals_76, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_76 = None
        mean_dim_3 = torch.ops.aten.mean.dim(convolution_default_28, [2, 3], True)
        convolution_default_29 = torch.ops.aten.convolution.default(mean_dim_3, primals_64, primals_63, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_63 = None
        relu__default_3 = torch.ops.aten.relu_.default(convolution_default_29);  convolution_default_29 = None
        convolution_default_30 = torch.ops.aten.convolution.default(relu__default_3, primals_66, primals_65, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_65 = None
        sigmoid_default_3 = torch.ops.aten.sigmoid.default(convolution_default_30);  convolution_default_30 = None
        mul_tensor_36 = torch.ops.aten.mul.Tensor(convolution_default_28, sigmoid_default_3)
        mul_tensor_37 = torch.ops.aten.mul.Tensor(mul_tensor_36, 2.0);  mul_tensor_36 = None
        mul__tensor_22 = torch.ops.aten.mul_.Tensor(mul_tensor_37, primals_82)
        mul_tensor_38 = torch.ops.aten.mul.Tensor(mul__tensor_22, 0.2);  mul__tensor_22 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(mul_tensor_38, convolution_default_24);  mul_tensor_38 = convolution_default_24 = None
        gelu_default_19 = torch.ops.aten.gelu.default(add_tensor_3)
        mul__tensor_23 = torch.ops.aten.mul_.Tensor(gelu_default_19, 1.7015043497085571);  gelu_default_19 = None
        mul_tensor_39 = torch.ops.aten.mul.Tensor(mul__tensor_23, 0.9805806756909201);  mul__tensor_23 = None
        view_default_69 = torch.ops.aten.view.default(primals_89, [1, 768, -1]);  primals_89 = None
        mul_tensor_40 = torch.ops.aten.mul.Tensor(primals_88, 0.02551551815399144);  primals_88 = None
        view_default_70 = torch.ops.aten.view.default(mul_tensor_40, [-1]);  mul_tensor_40 = None
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(view_default_69, view_default_70, None, None, None, True, 0.0, 1e-05)
        getitem_69 = native_batch_norm_default_23[0]
        getitem_70 = native_batch_norm_default_23[1]
        getitem_71 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        view_default_71 = torch.ops.aten.view.default(getitem_69, [768, 1536, 1, 1]);  getitem_69 = None
        convolution_default_31 = torch.ops.aten.convolution.default(mul_tensor_39, view_default_71, primals_87, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_87 = None
        gelu_default_20 = torch.ops.aten.gelu.default(convolution_default_31)
        mul__tensor_24 = torch.ops.aten.mul_.Tensor(gelu_default_20, 1.7015043497085571);  gelu_default_20 = None
        view_default_72 = torch.ops.aten.view.default(primals_92, [1, 768, -1]);  primals_92 = None
        mul_tensor_41 = torch.ops.aten.mul.Tensor(primals_91, 0.02946278254943948);  primals_91 = None
        view_default_73 = torch.ops.aten.view.default(mul_tensor_41, [-1]);  mul_tensor_41 = None
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(view_default_72, view_default_73, None, None, None, True, 0.0, 1e-05)
        getitem_72 = native_batch_norm_default_24[0]
        getitem_73 = native_batch_norm_default_24[1]
        getitem_74 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        view_default_74 = torch.ops.aten.view.default(getitem_72, [768, 128, 3, 3]);  getitem_72 = None
        convolution_default_32 = torch.ops.aten.convolution.default(mul__tensor_24, view_default_74, primals_90, [1, 1], [1, 1], [1, 1], False, [0, 0], 6);  primals_90 = None
        gelu_default_21 = torch.ops.aten.gelu.default(convolution_default_32)
        mul__tensor_25 = torch.ops.aten.mul_.Tensor(gelu_default_21, 1.7015043497085571);  gelu_default_21 = None
        view_default_75 = torch.ops.aten.view.default(primals_95, [1, 768, -1]);  primals_95 = None
        mul_tensor_42 = torch.ops.aten.mul.Tensor(primals_94, 0.02946278254943948);  primals_94 = None
        view_default_76 = torch.ops.aten.view.default(mul_tensor_42, [-1]);  mul_tensor_42 = None
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(view_default_75, view_default_76, None, None, None, True, 0.0, 1e-05)
        getitem_75 = native_batch_norm_default_25[0]
        getitem_76 = native_batch_norm_default_25[1]
        getitem_77 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        view_default_77 = torch.ops.aten.view.default(getitem_75, [768, 128, 3, 3]);  getitem_75 = None
        convolution_default_33 = torch.ops.aten.convolution.default(mul__tensor_25, view_default_77, primals_93, [1, 1], [1, 1], [1, 1], False, [0, 0], 6);  primals_93 = None
        gelu_default_22 = torch.ops.aten.gelu.default(convolution_default_33)
        mul__tensor_26 = torch.ops.aten.mul_.Tensor(gelu_default_22, 1.7015043497085571);  gelu_default_22 = None
        view_default_78 = torch.ops.aten.view.default(primals_98, [1, 1536, -1]);  primals_98 = None
        mul_tensor_43 = torch.ops.aten.mul.Tensor(primals_97, 0.03608439182435161);  primals_97 = None
        view_default_79 = torch.ops.aten.view.default(mul_tensor_43, [-1]);  mul_tensor_43 = None
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(view_default_78, view_default_79, None, None, None, True, 0.0, 1e-05)
        getitem_78 = native_batch_norm_default_26[0]
        getitem_79 = native_batch_norm_default_26[1]
        getitem_80 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        view_default_80 = torch.ops.aten.view.default(getitem_78, [1536, 768, 1, 1]);  getitem_78 = None
        convolution_default_34 = torch.ops.aten.convolution.default(mul__tensor_26, view_default_80, primals_96, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_96 = None
        mean_dim_4 = torch.ops.aten.mean.dim(convolution_default_34, [2, 3], True)
        convolution_default_35 = torch.ops.aten.convolution.default(mean_dim_4, primals_84, primals_83, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_83 = None
        relu__default_4 = torch.ops.aten.relu_.default(convolution_default_35);  convolution_default_35 = None
        convolution_default_36 = torch.ops.aten.convolution.default(relu__default_4, primals_86, primals_85, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_85 = None
        sigmoid_default_4 = torch.ops.aten.sigmoid.default(convolution_default_36);  convolution_default_36 = None
        mul_tensor_44 = torch.ops.aten.mul.Tensor(convolution_default_34, sigmoid_default_4)
        mul_tensor_45 = torch.ops.aten.mul.Tensor(mul_tensor_44, 2.0);  mul_tensor_44 = None
        mul__tensor_27 = torch.ops.aten.mul_.Tensor(mul_tensor_45, primals_99)
        mul_tensor_46 = torch.ops.aten.mul.Tensor(mul__tensor_27, 0.2);  mul__tensor_27 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(mul_tensor_46, add_tensor_3);  mul_tensor_46 = None
        gelu_default_23 = torch.ops.aten.gelu.default(add_tensor_4)
        mul__tensor_28 = torch.ops.aten.mul_.Tensor(gelu_default_23, 1.7015043497085571);  gelu_default_23 = None
        mul_tensor_47 = torch.ops.aten.mul.Tensor(mul__tensor_28, 0.9622504486493761);  mul__tensor_28 = None
        view_default_81 = torch.ops.aten.view.default(primals_106, [1, 768, -1]);  primals_106 = None
        mul_tensor_48 = torch.ops.aten.mul.Tensor(primals_105, 0.02551551815399144);  primals_105 = None
        view_default_82 = torch.ops.aten.view.default(mul_tensor_48, [-1]);  mul_tensor_48 = None
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(view_default_81, view_default_82, None, None, None, True, 0.0, 1e-05)
        getitem_81 = native_batch_norm_default_27[0]
        getitem_82 = native_batch_norm_default_27[1]
        getitem_83 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        view_default_83 = torch.ops.aten.view.default(getitem_81, [768, 1536, 1, 1]);  getitem_81 = None
        convolution_default_37 = torch.ops.aten.convolution.default(mul_tensor_47, view_default_83, primals_104, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_104 = None
        gelu_default_24 = torch.ops.aten.gelu.default(convolution_default_37)
        mul__tensor_29 = torch.ops.aten.mul_.Tensor(gelu_default_24, 1.7015043497085571);  gelu_default_24 = None
        view_default_84 = torch.ops.aten.view.default(primals_109, [1, 768, -1]);  primals_109 = None
        mul_tensor_49 = torch.ops.aten.mul.Tensor(primals_108, 0.02946278254943948);  primals_108 = None
        view_default_85 = torch.ops.aten.view.default(mul_tensor_49, [-1]);  mul_tensor_49 = None
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(view_default_84, view_default_85, None, None, None, True, 0.0, 1e-05)
        getitem_84 = native_batch_norm_default_28[0]
        getitem_85 = native_batch_norm_default_28[1]
        getitem_86 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        view_default_86 = torch.ops.aten.view.default(getitem_84, [768, 128, 3, 3]);  getitem_84 = None
        convolution_default_38 = torch.ops.aten.convolution.default(mul__tensor_29, view_default_86, primals_107, [1, 1], [1, 1], [1, 1], False, [0, 0], 6);  primals_107 = None
        gelu_default_25 = torch.ops.aten.gelu.default(convolution_default_38)
        mul__tensor_30 = torch.ops.aten.mul_.Tensor(gelu_default_25, 1.7015043497085571);  gelu_default_25 = None
        view_default_87 = torch.ops.aten.view.default(primals_112, [1, 768, -1]);  primals_112 = None
        mul_tensor_50 = torch.ops.aten.mul.Tensor(primals_111, 0.02946278254943948);  primals_111 = None
        view_default_88 = torch.ops.aten.view.default(mul_tensor_50, [-1]);  mul_tensor_50 = None
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(view_default_87, view_default_88, None, None, None, True, 0.0, 1e-05)
        getitem_87 = native_batch_norm_default_29[0]
        getitem_88 = native_batch_norm_default_29[1]
        getitem_89 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        view_default_89 = torch.ops.aten.view.default(getitem_87, [768, 128, 3, 3]);  getitem_87 = None
        convolution_default_39 = torch.ops.aten.convolution.default(mul__tensor_30, view_default_89, primals_110, [1, 1], [1, 1], [1, 1], False, [0, 0], 6);  primals_110 = None
        gelu_default_26 = torch.ops.aten.gelu.default(convolution_default_39)
        mul__tensor_31 = torch.ops.aten.mul_.Tensor(gelu_default_26, 1.7015043497085571);  gelu_default_26 = None
        view_default_90 = torch.ops.aten.view.default(primals_115, [1, 1536, -1]);  primals_115 = None
        mul_tensor_51 = torch.ops.aten.mul.Tensor(primals_114, 0.03608439182435161);  primals_114 = None
        view_default_91 = torch.ops.aten.view.default(mul_tensor_51, [-1]);  mul_tensor_51 = None
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(view_default_90, view_default_91, None, None, None, True, 0.0, 1e-05)
        getitem_90 = native_batch_norm_default_30[0]
        getitem_91 = native_batch_norm_default_30[1]
        getitem_92 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        view_default_92 = torch.ops.aten.view.default(getitem_90, [1536, 768, 1, 1]);  getitem_90 = None
        convolution_default_40 = torch.ops.aten.convolution.default(mul__tensor_31, view_default_92, primals_113, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_113 = None
        mean_dim_5 = torch.ops.aten.mean.dim(convolution_default_40, [2, 3], True)
        convolution_default_41 = torch.ops.aten.convolution.default(mean_dim_5, primals_101, primals_100, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_100 = None
        relu__default_5 = torch.ops.aten.relu_.default(convolution_default_41);  convolution_default_41 = None
        convolution_default_42 = torch.ops.aten.convolution.default(relu__default_5, primals_103, primals_102, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_102 = None
        sigmoid_default_5 = torch.ops.aten.sigmoid.default(convolution_default_42);  convolution_default_42 = None
        mul_tensor_52 = torch.ops.aten.mul.Tensor(convolution_default_40, sigmoid_default_5)
        mul_tensor_53 = torch.ops.aten.mul.Tensor(mul_tensor_52, 2.0);  mul_tensor_52 = None
        mul__tensor_32 = torch.ops.aten.mul_.Tensor(mul_tensor_53, primals_116)
        mul_tensor_54 = torch.ops.aten.mul.Tensor(mul__tensor_32, 0.2);  mul__tensor_32 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(mul_tensor_54, add_tensor_4);  mul_tensor_54 = None
        gelu_default_27 = torch.ops.aten.gelu.default(add_tensor_5)
        mul__tensor_33 = torch.ops.aten.mul_.Tensor(gelu_default_27, 1.7015043497085571);  gelu_default_27 = None
        mul_tensor_55 = torch.ops.aten.mul.Tensor(mul__tensor_33, 0.9449111825230679);  mul__tensor_33 = None
        view_default_93 = torch.ops.aten.view.default(primals_123, [1, 768, -1]);  primals_123 = None
        mul_tensor_56 = torch.ops.aten.mul.Tensor(primals_122, 0.02551551815399144);  primals_122 = None
        view_default_94 = torch.ops.aten.view.default(mul_tensor_56, [-1]);  mul_tensor_56 = None
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(view_default_93, view_default_94, None, None, None, True, 0.0, 1e-05)
        getitem_93 = native_batch_norm_default_31[0]
        getitem_94 = native_batch_norm_default_31[1]
        getitem_95 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        view_default_95 = torch.ops.aten.view.default(getitem_93, [768, 1536, 1, 1]);  getitem_93 = None
        convolution_default_43 = torch.ops.aten.convolution.default(mul_tensor_55, view_default_95, primals_121, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_121 = None
        gelu_default_28 = torch.ops.aten.gelu.default(convolution_default_43)
        mul__tensor_34 = torch.ops.aten.mul_.Tensor(gelu_default_28, 1.7015043497085571);  gelu_default_28 = None
        view_default_96 = torch.ops.aten.view.default(primals_126, [1, 768, -1]);  primals_126 = None
        mul_tensor_57 = torch.ops.aten.mul.Tensor(primals_125, 0.02946278254943948);  primals_125 = None
        view_default_97 = torch.ops.aten.view.default(mul_tensor_57, [-1]);  mul_tensor_57 = None
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(view_default_96, view_default_97, None, None, None, True, 0.0, 1e-05)
        getitem_96 = native_batch_norm_default_32[0]
        getitem_97 = native_batch_norm_default_32[1]
        getitem_98 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        view_default_98 = torch.ops.aten.view.default(getitem_96, [768, 128, 3, 3]);  getitem_96 = None
        convolution_default_44 = torch.ops.aten.convolution.default(mul__tensor_34, view_default_98, primals_124, [1, 1], [1, 1], [1, 1], False, [0, 0], 6);  primals_124 = None
        gelu_default_29 = torch.ops.aten.gelu.default(convolution_default_44)
        mul__tensor_35 = torch.ops.aten.mul_.Tensor(gelu_default_29, 1.7015043497085571);  gelu_default_29 = None
        view_default_99 = torch.ops.aten.view.default(primals_129, [1, 768, -1]);  primals_129 = None
        mul_tensor_58 = torch.ops.aten.mul.Tensor(primals_128, 0.02946278254943948);  primals_128 = None
        view_default_100 = torch.ops.aten.view.default(mul_tensor_58, [-1]);  mul_tensor_58 = None
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(view_default_99, view_default_100, None, None, None, True, 0.0, 1e-05)
        getitem_99 = native_batch_norm_default_33[0]
        getitem_100 = native_batch_norm_default_33[1]
        getitem_101 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        view_default_101 = torch.ops.aten.view.default(getitem_99, [768, 128, 3, 3]);  getitem_99 = None
        convolution_default_45 = torch.ops.aten.convolution.default(mul__tensor_35, view_default_101, primals_127, [1, 1], [1, 1], [1, 1], False, [0, 0], 6);  primals_127 = None
        gelu_default_30 = torch.ops.aten.gelu.default(convolution_default_45)
        mul__tensor_36 = torch.ops.aten.mul_.Tensor(gelu_default_30, 1.7015043497085571);  gelu_default_30 = None
        view_default_102 = torch.ops.aten.view.default(primals_132, [1, 1536, -1]);  primals_132 = None
        mul_tensor_59 = torch.ops.aten.mul.Tensor(primals_131, 0.03608439182435161);  primals_131 = None
        view_default_103 = torch.ops.aten.view.default(mul_tensor_59, [-1]);  mul_tensor_59 = None
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(view_default_102, view_default_103, None, None, None, True, 0.0, 1e-05)
        getitem_102 = native_batch_norm_default_34[0]
        getitem_103 = native_batch_norm_default_34[1]
        getitem_104 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        view_default_104 = torch.ops.aten.view.default(getitem_102, [1536, 768, 1, 1]);  getitem_102 = None
        convolution_default_46 = torch.ops.aten.convolution.default(mul__tensor_36, view_default_104, primals_130, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_130 = None
        mean_dim_6 = torch.ops.aten.mean.dim(convolution_default_46, [2, 3], True)
        convolution_default_47 = torch.ops.aten.convolution.default(mean_dim_6, primals_118, primals_117, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_117 = None
        relu__default_6 = torch.ops.aten.relu_.default(convolution_default_47);  convolution_default_47 = None
        convolution_default_48 = torch.ops.aten.convolution.default(relu__default_6, primals_120, primals_119, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_119 = None
        sigmoid_default_6 = torch.ops.aten.sigmoid.default(convolution_default_48);  convolution_default_48 = None
        mul_tensor_60 = torch.ops.aten.mul.Tensor(convolution_default_46, sigmoid_default_6)
        mul_tensor_61 = torch.ops.aten.mul.Tensor(mul_tensor_60, 2.0);  mul_tensor_60 = None
        mul__tensor_37 = torch.ops.aten.mul_.Tensor(mul_tensor_61, primals_133)
        mul_tensor_62 = torch.ops.aten.mul.Tensor(mul__tensor_37, 0.2);  mul__tensor_37 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(mul_tensor_62, add_tensor_5);  mul_tensor_62 = None
        gelu_default_31 = torch.ops.aten.gelu.default(add_tensor_6)
        mul__tensor_38 = torch.ops.aten.mul_.Tensor(gelu_default_31, 1.7015043497085571);  gelu_default_31 = None
        mul_tensor_63 = torch.ops.aten.mul.Tensor(mul__tensor_38, 0.9284766908852592);  mul__tensor_38 = None
        view_default_105 = torch.ops.aten.view.default(primals_140, [1, 768, -1]);  primals_140 = None
        mul_tensor_64 = torch.ops.aten.mul.Tensor(primals_139, 0.02551551815399144);  primals_139 = None
        view_default_106 = torch.ops.aten.view.default(mul_tensor_64, [-1]);  mul_tensor_64 = None
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(view_default_105, view_default_106, None, None, None, True, 0.0, 1e-05)
        getitem_105 = native_batch_norm_default_35[0]
        getitem_106 = native_batch_norm_default_35[1]
        getitem_107 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        view_default_107 = torch.ops.aten.view.default(getitem_105, [768, 1536, 1, 1]);  getitem_105 = None
        convolution_default_49 = torch.ops.aten.convolution.default(mul_tensor_63, view_default_107, primals_138, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_138 = None
        gelu_default_32 = torch.ops.aten.gelu.default(convolution_default_49)
        mul__tensor_39 = torch.ops.aten.mul_.Tensor(gelu_default_32, 1.7015043497085571);  gelu_default_32 = None
        view_default_108 = torch.ops.aten.view.default(primals_143, [1, 768, -1]);  primals_143 = None
        mul_tensor_65 = torch.ops.aten.mul.Tensor(primals_142, 0.02946278254943948);  primals_142 = None
        view_default_109 = torch.ops.aten.view.default(mul_tensor_65, [-1]);  mul_tensor_65 = None
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(view_default_108, view_default_109, None, None, None, True, 0.0, 1e-05)
        getitem_108 = native_batch_norm_default_36[0]
        getitem_109 = native_batch_norm_default_36[1]
        getitem_110 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        view_default_110 = torch.ops.aten.view.default(getitem_108, [768, 128, 3, 3]);  getitem_108 = None
        convolution_default_50 = torch.ops.aten.convolution.default(mul__tensor_39, view_default_110, primals_141, [1, 1], [1, 1], [1, 1], False, [0, 0], 6);  primals_141 = None
        gelu_default_33 = torch.ops.aten.gelu.default(convolution_default_50)
        mul__tensor_40 = torch.ops.aten.mul_.Tensor(gelu_default_33, 1.7015043497085571);  gelu_default_33 = None
        view_default_111 = torch.ops.aten.view.default(primals_146, [1, 768, -1]);  primals_146 = None
        mul_tensor_66 = torch.ops.aten.mul.Tensor(primals_145, 0.02946278254943948);  primals_145 = None
        view_default_112 = torch.ops.aten.view.default(mul_tensor_66, [-1]);  mul_tensor_66 = None
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(view_default_111, view_default_112, None, None, None, True, 0.0, 1e-05)
        getitem_111 = native_batch_norm_default_37[0]
        getitem_112 = native_batch_norm_default_37[1]
        getitem_113 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        view_default_113 = torch.ops.aten.view.default(getitem_111, [768, 128, 3, 3]);  getitem_111 = None
        convolution_default_51 = torch.ops.aten.convolution.default(mul__tensor_40, view_default_113, primals_144, [1, 1], [1, 1], [1, 1], False, [0, 0], 6);  primals_144 = None
        gelu_default_34 = torch.ops.aten.gelu.default(convolution_default_51)
        mul__tensor_41 = torch.ops.aten.mul_.Tensor(gelu_default_34, 1.7015043497085571);  gelu_default_34 = None
        view_default_114 = torch.ops.aten.view.default(primals_149, [1, 1536, -1]);  primals_149 = None
        mul_tensor_67 = torch.ops.aten.mul.Tensor(primals_148, 0.03608439182435161);  primals_148 = None
        view_default_115 = torch.ops.aten.view.default(mul_tensor_67, [-1]);  mul_tensor_67 = None
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(view_default_114, view_default_115, None, None, None, True, 0.0, 1e-05)
        getitem_114 = native_batch_norm_default_38[0]
        getitem_115 = native_batch_norm_default_38[1]
        getitem_116 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        view_default_116 = torch.ops.aten.view.default(getitem_114, [1536, 768, 1, 1]);  getitem_114 = None
        convolution_default_52 = torch.ops.aten.convolution.default(mul__tensor_41, view_default_116, primals_147, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_147 = None
        mean_dim_7 = torch.ops.aten.mean.dim(convolution_default_52, [2, 3], True)
        convolution_default_53 = torch.ops.aten.convolution.default(mean_dim_7, primals_135, primals_134, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_134 = None
        relu__default_7 = torch.ops.aten.relu_.default(convolution_default_53);  convolution_default_53 = None
        convolution_default_54 = torch.ops.aten.convolution.default(relu__default_7, primals_137, primals_136, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_136 = None
        sigmoid_default_7 = torch.ops.aten.sigmoid.default(convolution_default_54);  convolution_default_54 = None
        mul_tensor_68 = torch.ops.aten.mul.Tensor(convolution_default_52, sigmoid_default_7)
        mul_tensor_69 = torch.ops.aten.mul.Tensor(mul_tensor_68, 2.0);  mul_tensor_68 = None
        mul__tensor_42 = torch.ops.aten.mul_.Tensor(mul_tensor_69, primals_150)
        mul_tensor_70 = torch.ops.aten.mul.Tensor(mul__tensor_42, 0.2);  mul__tensor_42 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(mul_tensor_70, add_tensor_6);  mul_tensor_70 = None
        gelu_default_35 = torch.ops.aten.gelu.default(add_tensor_7)
        mul__tensor_43 = torch.ops.aten.mul_.Tensor(gelu_default_35, 1.7015043497085571);  gelu_default_35 = None
        mul_tensor_71 = torch.ops.aten.mul.Tensor(mul__tensor_43, 0.9128709291752768);  mul__tensor_43 = None
        view_default_117 = torch.ops.aten.view.default(primals_157, [1, 768, -1]);  primals_157 = None
        mul_tensor_72 = torch.ops.aten.mul.Tensor(primals_156, 0.02551551815399144);  primals_156 = None
        view_default_118 = torch.ops.aten.view.default(mul_tensor_72, [-1]);  mul_tensor_72 = None
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(view_default_117, view_default_118, None, None, None, True, 0.0, 1e-05)
        getitem_117 = native_batch_norm_default_39[0]
        getitem_118 = native_batch_norm_default_39[1]
        getitem_119 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        view_default_119 = torch.ops.aten.view.default(getitem_117, [768, 1536, 1, 1]);  getitem_117 = None
        convolution_default_55 = torch.ops.aten.convolution.default(mul_tensor_71, view_default_119, primals_155, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_155 = None
        gelu_default_36 = torch.ops.aten.gelu.default(convolution_default_55)
        mul__tensor_44 = torch.ops.aten.mul_.Tensor(gelu_default_36, 1.7015043497085571);  gelu_default_36 = None
        view_default_120 = torch.ops.aten.view.default(primals_160, [1, 768, -1]);  primals_160 = None
        mul_tensor_73 = torch.ops.aten.mul.Tensor(primals_159, 0.02946278254943948);  primals_159 = None
        view_default_121 = torch.ops.aten.view.default(mul_tensor_73, [-1]);  mul_tensor_73 = None
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(view_default_120, view_default_121, None, None, None, True, 0.0, 1e-05)
        getitem_120 = native_batch_norm_default_40[0]
        getitem_121 = native_batch_norm_default_40[1]
        getitem_122 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        view_default_122 = torch.ops.aten.view.default(getitem_120, [768, 128, 3, 3]);  getitem_120 = None
        convolution_default_56 = torch.ops.aten.convolution.default(mul__tensor_44, view_default_122, primals_158, [1, 1], [1, 1], [1, 1], False, [0, 0], 6);  primals_158 = None
        gelu_default_37 = torch.ops.aten.gelu.default(convolution_default_56)
        mul__tensor_45 = torch.ops.aten.mul_.Tensor(gelu_default_37, 1.7015043497085571);  gelu_default_37 = None
        view_default_123 = torch.ops.aten.view.default(primals_163, [1, 768, -1]);  primals_163 = None
        mul_tensor_74 = torch.ops.aten.mul.Tensor(primals_162, 0.02946278254943948);  primals_162 = None
        view_default_124 = torch.ops.aten.view.default(mul_tensor_74, [-1]);  mul_tensor_74 = None
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(view_default_123, view_default_124, None, None, None, True, 0.0, 1e-05)
        getitem_123 = native_batch_norm_default_41[0]
        getitem_124 = native_batch_norm_default_41[1]
        getitem_125 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        view_default_125 = torch.ops.aten.view.default(getitem_123, [768, 128, 3, 3]);  getitem_123 = None
        convolution_default_57 = torch.ops.aten.convolution.default(mul__tensor_45, view_default_125, primals_161, [1, 1], [1, 1], [1, 1], False, [0, 0], 6);  primals_161 = None
        gelu_default_38 = torch.ops.aten.gelu.default(convolution_default_57)
        mul__tensor_46 = torch.ops.aten.mul_.Tensor(gelu_default_38, 1.7015043497085571);  gelu_default_38 = None
        view_default_126 = torch.ops.aten.view.default(primals_166, [1, 1536, -1]);  primals_166 = None
        mul_tensor_75 = torch.ops.aten.mul.Tensor(primals_165, 0.03608439182435161);  primals_165 = None
        view_default_127 = torch.ops.aten.view.default(mul_tensor_75, [-1]);  mul_tensor_75 = None
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(view_default_126, view_default_127, None, None, None, True, 0.0, 1e-05)
        getitem_126 = native_batch_norm_default_42[0]
        getitem_127 = native_batch_norm_default_42[1]
        getitem_128 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        view_default_128 = torch.ops.aten.view.default(getitem_126, [1536, 768, 1, 1]);  getitem_126 = None
        convolution_default_58 = torch.ops.aten.convolution.default(mul__tensor_46, view_default_128, primals_164, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_164 = None
        mean_dim_8 = torch.ops.aten.mean.dim(convolution_default_58, [2, 3], True)
        convolution_default_59 = torch.ops.aten.convolution.default(mean_dim_8, primals_152, primals_151, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_151 = None
        relu__default_8 = torch.ops.aten.relu_.default(convolution_default_59);  convolution_default_59 = None
        convolution_default_60 = torch.ops.aten.convolution.default(relu__default_8, primals_154, primals_153, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_153 = None
        sigmoid_default_8 = torch.ops.aten.sigmoid.default(convolution_default_60);  convolution_default_60 = None
        mul_tensor_76 = torch.ops.aten.mul.Tensor(convolution_default_58, sigmoid_default_8)
        mul_tensor_77 = torch.ops.aten.mul.Tensor(mul_tensor_76, 2.0);  mul_tensor_76 = None
        mul__tensor_47 = torch.ops.aten.mul_.Tensor(mul_tensor_77, primals_167)
        mul_tensor_78 = torch.ops.aten.mul.Tensor(mul__tensor_47, 0.2);  mul__tensor_47 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(mul_tensor_78, add_tensor_7);  mul_tensor_78 = None
        gelu_default_39 = torch.ops.aten.gelu.default(add_tensor_8)
        mul__tensor_48 = torch.ops.aten.mul_.Tensor(gelu_default_39, 1.7015043497085571);  gelu_default_39 = None
        mul_tensor_79 = torch.ops.aten.mul.Tensor(mul__tensor_48, 0.8980265101338745);  mul__tensor_48 = None
        avg_pool2d_default_2 = torch.ops.aten.avg_pool2d.default(mul_tensor_79, [2, 2], [2, 2], [0, 0], True, False)
        view_default_129 = torch.ops.aten.view.default(primals_186, [1, 1536, -1]);  primals_186 = None
        mul_tensor_80 = torch.ops.aten.mul.Tensor(primals_185, 0.02551551815399144);  primals_185 = None
        view_default_130 = torch.ops.aten.view.default(mul_tensor_80, [-1]);  mul_tensor_80 = None
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(view_default_129, view_default_130, None, None, None, True, 0.0, 1e-05)
        getitem_129 = native_batch_norm_default_43[0]
        getitem_130 = native_batch_norm_default_43[1]
        getitem_131 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        view_default_131 = torch.ops.aten.view.default(getitem_129, [1536, 1536, 1, 1]);  getitem_129 = None
        convolution_default_61 = torch.ops.aten.convolution.default(avg_pool2d_default_2, view_default_131, primals_184, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_184 = None
        view_default_132 = torch.ops.aten.view.default(primals_174, [1, 768, -1]);  primals_174 = None
        mul_tensor_81 = torch.ops.aten.mul.Tensor(primals_173, 0.02551551815399144);  primals_173 = None
        view_default_133 = torch.ops.aten.view.default(mul_tensor_81, [-1]);  mul_tensor_81 = None
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(view_default_132, view_default_133, None, None, None, True, 0.0, 1e-05)
        getitem_132 = native_batch_norm_default_44[0]
        getitem_133 = native_batch_norm_default_44[1]
        getitem_134 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        view_default_134 = torch.ops.aten.view.default(getitem_132, [768, 1536, 1, 1]);  getitem_132 = None
        convolution_default_62 = torch.ops.aten.convolution.default(mul_tensor_79, view_default_134, primals_172, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_172 = None
        gelu_default_40 = torch.ops.aten.gelu.default(convolution_default_62)
        mul__tensor_49 = torch.ops.aten.mul_.Tensor(gelu_default_40, 1.7015043497085571);  gelu_default_40 = None
        constant_pad_nd_default_4 = torch.ops.aten.constant_pad_nd.default(mul__tensor_49, [0, 1, 0, 1], 0.0);  mul__tensor_49 = None
        view_default_135 = torch.ops.aten.view.default(primals_177, [1, 768, -1]);  primals_177 = None
        mul_tensor_82 = torch.ops.aten.mul.Tensor(primals_176, 0.02946278254943948);  primals_176 = None
        view_default_136 = torch.ops.aten.view.default(mul_tensor_82, [-1]);  mul_tensor_82 = None
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(view_default_135, view_default_136, None, None, None, True, 0.0, 1e-05)
        getitem_135 = native_batch_norm_default_45[0]
        getitem_136 = native_batch_norm_default_45[1]
        getitem_137 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        view_default_137 = torch.ops.aten.view.default(getitem_135, [768, 128, 3, 3]);  getitem_135 = None
        convolution_default_63 = torch.ops.aten.convolution.default(constant_pad_nd_default_4, view_default_137, primals_175, [2, 2], [0, 0], [1, 1], False, [0, 0], 6);  primals_175 = None
        gelu_default_41 = torch.ops.aten.gelu.default(convolution_default_63)
        mul__tensor_50 = torch.ops.aten.mul_.Tensor(gelu_default_41, 1.7015043497085571);  gelu_default_41 = None
        view_default_138 = torch.ops.aten.view.default(primals_180, [1, 768, -1]);  primals_180 = None
        mul_tensor_83 = torch.ops.aten.mul.Tensor(primals_179, 0.02946278254943948);  primals_179 = None
        view_default_139 = torch.ops.aten.view.default(mul_tensor_83, [-1]);  mul_tensor_83 = None
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(view_default_138, view_default_139, None, None, None, True, 0.0, 1e-05)
        getitem_138 = native_batch_norm_default_46[0]
        getitem_139 = native_batch_norm_default_46[1]
        getitem_140 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        view_default_140 = torch.ops.aten.view.default(getitem_138, [768, 128, 3, 3]);  getitem_138 = None
        convolution_default_64 = torch.ops.aten.convolution.default(mul__tensor_50, view_default_140, primals_178, [1, 1], [1, 1], [1, 1], False, [0, 0], 6);  primals_178 = None
        gelu_default_42 = torch.ops.aten.gelu.default(convolution_default_64)
        mul__tensor_51 = torch.ops.aten.mul_.Tensor(gelu_default_42, 1.7015043497085571);  gelu_default_42 = None
        view_default_141 = torch.ops.aten.view.default(primals_183, [1, 1536, -1]);  primals_183 = None
        mul_tensor_84 = torch.ops.aten.mul.Tensor(primals_182, 0.03608439182435161);  primals_182 = None
        view_default_142 = torch.ops.aten.view.default(mul_tensor_84, [-1]);  mul_tensor_84 = None
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(view_default_141, view_default_142, None, None, None, True, 0.0, 1e-05)
        getitem_141 = native_batch_norm_default_47[0]
        getitem_142 = native_batch_norm_default_47[1]
        getitem_143 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        view_default_143 = torch.ops.aten.view.default(getitem_141, [1536, 768, 1, 1]);  getitem_141 = None
        convolution_default_65 = torch.ops.aten.convolution.default(mul__tensor_51, view_default_143, primals_181, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_181 = None
        mean_dim_9 = torch.ops.aten.mean.dim(convolution_default_65, [2, 3], True)
        convolution_default_66 = torch.ops.aten.convolution.default(mean_dim_9, primals_169, primals_168, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_168 = None
        relu__default_9 = torch.ops.aten.relu_.default(convolution_default_66);  convolution_default_66 = None
        convolution_default_67 = torch.ops.aten.convolution.default(relu__default_9, primals_171, primals_170, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_170 = None
        sigmoid_default_9 = torch.ops.aten.sigmoid.default(convolution_default_67);  convolution_default_67 = None
        mul_tensor_85 = torch.ops.aten.mul.Tensor(convolution_default_65, sigmoid_default_9)
        mul_tensor_86 = torch.ops.aten.mul.Tensor(mul_tensor_85, 2.0);  mul_tensor_85 = None
        mul__tensor_52 = torch.ops.aten.mul_.Tensor(mul_tensor_86, primals_187)
        mul_tensor_87 = torch.ops.aten.mul.Tensor(mul__tensor_52, 0.2);  mul__tensor_52 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(mul_tensor_87, convolution_default_61);  mul_tensor_87 = convolution_default_61 = None
        gelu_default_43 = torch.ops.aten.gelu.default(add_tensor_9)
        mul__tensor_53 = torch.ops.aten.mul_.Tensor(gelu_default_43, 1.7015043497085571);  gelu_default_43 = None
        mul_tensor_88 = torch.ops.aten.mul.Tensor(mul__tensor_53, 0.9805806756909201);  mul__tensor_53 = None
        view_default_144 = torch.ops.aten.view.default(primals_194, [1, 768, -1]);  primals_194 = None
        mul_tensor_89 = torch.ops.aten.mul.Tensor(primals_193, 0.02551551815399144);  primals_193 = None
        view_default_145 = torch.ops.aten.view.default(mul_tensor_89, [-1]);  mul_tensor_89 = None
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(view_default_144, view_default_145, None, None, None, True, 0.0, 1e-05)
        getitem_144 = native_batch_norm_default_48[0]
        getitem_145 = native_batch_norm_default_48[1]
        getitem_146 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        view_default_146 = torch.ops.aten.view.default(getitem_144, [768, 1536, 1, 1]);  getitem_144 = None
        convolution_default_68 = torch.ops.aten.convolution.default(mul_tensor_88, view_default_146, primals_192, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_192 = None
        gelu_default_44 = torch.ops.aten.gelu.default(convolution_default_68)
        mul__tensor_54 = torch.ops.aten.mul_.Tensor(gelu_default_44, 1.7015043497085571);  gelu_default_44 = None
        view_default_147 = torch.ops.aten.view.default(primals_197, [1, 768, -1]);  primals_197 = None
        mul_tensor_90 = torch.ops.aten.mul.Tensor(primals_196, 0.02946278254943948);  primals_196 = None
        view_default_148 = torch.ops.aten.view.default(mul_tensor_90, [-1]);  mul_tensor_90 = None
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(view_default_147, view_default_148, None, None, None, True, 0.0, 1e-05)
        getitem_147 = native_batch_norm_default_49[0]
        getitem_148 = native_batch_norm_default_49[1]
        getitem_149 = native_batch_norm_default_49[2];  native_batch_norm_default_49 = None
        view_default_149 = torch.ops.aten.view.default(getitem_147, [768, 128, 3, 3]);  getitem_147 = None
        convolution_default_69 = torch.ops.aten.convolution.default(mul__tensor_54, view_default_149, primals_195, [1, 1], [1, 1], [1, 1], False, [0, 0], 6);  primals_195 = None
        gelu_default_45 = torch.ops.aten.gelu.default(convolution_default_69)
        mul__tensor_55 = torch.ops.aten.mul_.Tensor(gelu_default_45, 1.7015043497085571);  gelu_default_45 = None
        view_default_150 = torch.ops.aten.view.default(primals_200, [1, 768, -1]);  primals_200 = None
        mul_tensor_91 = torch.ops.aten.mul.Tensor(primals_199, 0.02946278254943948);  primals_199 = None
        view_default_151 = torch.ops.aten.view.default(mul_tensor_91, [-1]);  mul_tensor_91 = None
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(view_default_150, view_default_151, None, None, None, True, 0.0, 1e-05)
        getitem_150 = native_batch_norm_default_50[0]
        getitem_151 = native_batch_norm_default_50[1]
        getitem_152 = native_batch_norm_default_50[2];  native_batch_norm_default_50 = None
        view_default_152 = torch.ops.aten.view.default(getitem_150, [768, 128, 3, 3]);  getitem_150 = None
        convolution_default_70 = torch.ops.aten.convolution.default(mul__tensor_55, view_default_152, primals_198, [1, 1], [1, 1], [1, 1], False, [0, 0], 6);  primals_198 = None
        gelu_default_46 = torch.ops.aten.gelu.default(convolution_default_70)
        mul__tensor_56 = torch.ops.aten.mul_.Tensor(gelu_default_46, 1.7015043497085571);  gelu_default_46 = None
        view_default_153 = torch.ops.aten.view.default(primals_203, [1, 1536, -1]);  primals_203 = None
        mul_tensor_92 = torch.ops.aten.mul.Tensor(primals_202, 0.03608439182435161);  primals_202 = None
        view_default_154 = torch.ops.aten.view.default(mul_tensor_92, [-1]);  mul_tensor_92 = None
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(view_default_153, view_default_154, None, None, None, True, 0.0, 1e-05)
        getitem_153 = native_batch_norm_default_51[0]
        getitem_154 = native_batch_norm_default_51[1]
        getitem_155 = native_batch_norm_default_51[2];  native_batch_norm_default_51 = None
        view_default_155 = torch.ops.aten.view.default(getitem_153, [1536, 768, 1, 1]);  getitem_153 = None
        convolution_default_71 = torch.ops.aten.convolution.default(mul__tensor_56, view_default_155, primals_201, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_201 = None
        mean_dim_10 = torch.ops.aten.mean.dim(convolution_default_71, [2, 3], True)
        convolution_default_72 = torch.ops.aten.convolution.default(mean_dim_10, primals_189, primals_188, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_188 = None
        relu__default_10 = torch.ops.aten.relu_.default(convolution_default_72);  convolution_default_72 = None
        convolution_default_73 = torch.ops.aten.convolution.default(relu__default_10, primals_191, primals_190, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_190 = None
        sigmoid_default_10 = torch.ops.aten.sigmoid.default(convolution_default_73);  convolution_default_73 = None
        mul_tensor_93 = torch.ops.aten.mul.Tensor(convolution_default_71, sigmoid_default_10)
        mul_tensor_94 = torch.ops.aten.mul.Tensor(mul_tensor_93, 2.0);  mul_tensor_93 = None
        mul__tensor_57 = torch.ops.aten.mul_.Tensor(mul_tensor_94, primals_204)
        mul_tensor_95 = torch.ops.aten.mul.Tensor(mul__tensor_57, 0.2);  mul__tensor_57 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(mul_tensor_95, add_tensor_9);  mul_tensor_95 = None
        gelu_default_47 = torch.ops.aten.gelu.default(add_tensor_10)
        mul__tensor_58 = torch.ops.aten.mul_.Tensor(gelu_default_47, 1.7015043497085571);  gelu_default_47 = None
        mul_tensor_96 = torch.ops.aten.mul.Tensor(mul__tensor_58, 0.9622504486493761);  mul__tensor_58 = None
        view_default_156 = torch.ops.aten.view.default(primals_211, [1, 768, -1]);  primals_211 = None
        mul_tensor_97 = torch.ops.aten.mul.Tensor(primals_210, 0.02551551815399144);  primals_210 = None
        view_default_157 = torch.ops.aten.view.default(mul_tensor_97, [-1]);  mul_tensor_97 = None
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(view_default_156, view_default_157, None, None, None, True, 0.0, 1e-05)
        getitem_156 = native_batch_norm_default_52[0]
        getitem_157 = native_batch_norm_default_52[1]
        getitem_158 = native_batch_norm_default_52[2];  native_batch_norm_default_52 = None
        view_default_158 = torch.ops.aten.view.default(getitem_156, [768, 1536, 1, 1]);  getitem_156 = None
        convolution_default_74 = torch.ops.aten.convolution.default(mul_tensor_96, view_default_158, primals_209, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_209 = None
        gelu_default_48 = torch.ops.aten.gelu.default(convolution_default_74)
        mul__tensor_59 = torch.ops.aten.mul_.Tensor(gelu_default_48, 1.7015043497085571);  gelu_default_48 = None
        view_default_159 = torch.ops.aten.view.default(primals_214, [1, 768, -1]);  primals_214 = None
        mul_tensor_98 = torch.ops.aten.mul.Tensor(primals_213, 0.02946278254943948);  primals_213 = None
        view_default_160 = torch.ops.aten.view.default(mul_tensor_98, [-1]);  mul_tensor_98 = None
        native_batch_norm_default_53 = torch.ops.aten.native_batch_norm.default(view_default_159, view_default_160, None, None, None, True, 0.0, 1e-05)
        getitem_159 = native_batch_norm_default_53[0]
        getitem_160 = native_batch_norm_default_53[1]
        getitem_161 = native_batch_norm_default_53[2];  native_batch_norm_default_53 = None
        view_default_161 = torch.ops.aten.view.default(getitem_159, [768, 128, 3, 3]);  getitem_159 = None
        convolution_default_75 = torch.ops.aten.convolution.default(mul__tensor_59, view_default_161, primals_212, [1, 1], [1, 1], [1, 1], False, [0, 0], 6);  primals_212 = None
        gelu_default_49 = torch.ops.aten.gelu.default(convolution_default_75)
        mul__tensor_60 = torch.ops.aten.mul_.Tensor(gelu_default_49, 1.7015043497085571);  gelu_default_49 = None
        view_default_162 = torch.ops.aten.view.default(primals_217, [1, 768, -1]);  primals_217 = None
        mul_tensor_99 = torch.ops.aten.mul.Tensor(primals_216, 0.02946278254943948);  primals_216 = None
        view_default_163 = torch.ops.aten.view.default(mul_tensor_99, [-1]);  mul_tensor_99 = None
        native_batch_norm_default_54 = torch.ops.aten.native_batch_norm.default(view_default_162, view_default_163, None, None, None, True, 0.0, 1e-05)
        getitem_162 = native_batch_norm_default_54[0]
        getitem_163 = native_batch_norm_default_54[1]
        getitem_164 = native_batch_norm_default_54[2];  native_batch_norm_default_54 = None
        view_default_164 = torch.ops.aten.view.default(getitem_162, [768, 128, 3, 3]);  getitem_162 = None
        convolution_default_76 = torch.ops.aten.convolution.default(mul__tensor_60, view_default_164, primals_215, [1, 1], [1, 1], [1, 1], False, [0, 0], 6);  primals_215 = None
        gelu_default_50 = torch.ops.aten.gelu.default(convolution_default_76)
        mul__tensor_61 = torch.ops.aten.mul_.Tensor(gelu_default_50, 1.7015043497085571);  gelu_default_50 = None
        view_default_165 = torch.ops.aten.view.default(primals_220, [1, 1536, -1]);  primals_220 = None
        mul_tensor_100 = torch.ops.aten.mul.Tensor(primals_219, 0.03608439182435161);  primals_219 = None
        view_default_166 = torch.ops.aten.view.default(mul_tensor_100, [-1]);  mul_tensor_100 = None
        native_batch_norm_default_55 = torch.ops.aten.native_batch_norm.default(view_default_165, view_default_166, None, None, None, True, 0.0, 1e-05)
        getitem_165 = native_batch_norm_default_55[0]
        getitem_166 = native_batch_norm_default_55[1]
        getitem_167 = native_batch_norm_default_55[2];  native_batch_norm_default_55 = None
        view_default_167 = torch.ops.aten.view.default(getitem_165, [1536, 768, 1, 1]);  getitem_165 = None
        convolution_default_77 = torch.ops.aten.convolution.default(mul__tensor_61, view_default_167, primals_218, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_218 = None
        mean_dim_11 = torch.ops.aten.mean.dim(convolution_default_77, [2, 3], True)
        convolution_default_78 = torch.ops.aten.convolution.default(mean_dim_11, primals_206, primals_205, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_205 = None
        relu__default_11 = torch.ops.aten.relu_.default(convolution_default_78);  convolution_default_78 = None
        convolution_default_79 = torch.ops.aten.convolution.default(relu__default_11, primals_208, primals_207, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_207 = None
        sigmoid_default_11 = torch.ops.aten.sigmoid.default(convolution_default_79);  convolution_default_79 = None
        mul_tensor_101 = torch.ops.aten.mul.Tensor(convolution_default_77, sigmoid_default_11)
        mul_tensor_102 = torch.ops.aten.mul.Tensor(mul_tensor_101, 2.0);  mul_tensor_101 = None
        mul__tensor_62 = torch.ops.aten.mul_.Tensor(mul_tensor_102, primals_221)
        mul_tensor_103 = torch.ops.aten.mul.Tensor(mul__tensor_62, 0.2);  mul__tensor_62 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(mul_tensor_103, add_tensor_10);  mul_tensor_103 = None
        view_default_168 = torch.ops.aten.view.default(primals_3, [1, 3072, -1]);  primals_3 = None
        mul_tensor_104 = torch.ops.aten.mul.Tensor(primals_2, 0.02551551815399144);  primals_2 = None
        view_default_169 = torch.ops.aten.view.default(mul_tensor_104, [-1]);  mul_tensor_104 = None
        native_batch_norm_default_56 = torch.ops.aten.native_batch_norm.default(view_default_168, view_default_169, None, None, None, True, 0.0, 1e-05)
        getitem_168 = native_batch_norm_default_56[0]
        getitem_169 = native_batch_norm_default_56[1]
        getitem_170 = native_batch_norm_default_56[2];  native_batch_norm_default_56 = None
        view_default_170 = torch.ops.aten.view.default(getitem_168, [3072, 1536, 1, 1]);  getitem_168 = None
        convolution_default_80 = torch.ops.aten.convolution.default(add_tensor_11, view_default_170, primals_1, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1 = None
        gelu_default_51 = torch.ops.aten.gelu.default(convolution_default_80)
        mul__tensor_63 = torch.ops.aten.mul_.Tensor(gelu_default_51, 1.7015043497085571);  gelu_default_51 = None
        mean_dim_12 = torch.ops.aten.mean.dim(mul__tensor_63, [-1, -2], True);  mul__tensor_63 = None
        view_default_171 = torch.ops.aten.view.default(mean_dim_12, [128, 3072]);  mean_dim_12 = None
        t_default = torch.ops.aten.t.default(primals_5);  primals_5 = None
        addmm_default = torch.ops.aten.addmm.default(primals_4, view_default_171, t_default);  primals_4 = None
        return [addmm_default, view_default_84, view_default_83, constant_pad_nd_default_2, getitem_82, convolution_default_38, convolution_default_37, getitem_125, getitem_32, view_default_33, view_default_86, mean_dim_11, view_default_125, getitem_124, view_default_127, view_default_85, mul__tensor_46, view_default_32, view_default_124, view_default_126, getitem_83, convolution_default_12, view_default_82, mul__tensor_29, view_default_171, getitem_31, convolution_default_57, view_default_18, convolution_default_44, view_default_26, view_default_19, getitem_16, getitem_35, view_default_97, view_default_25, getitem_53, view_default_76, getitem_133, mul__tensor_16, getitem_98, getitem_110, view_default_57, convolution_default_21, view_default_112, view_default_134, getitem_25, getitem_116, getitem_113, convolution_default_5, convolution_default_50, mean_dim_7, view_default_136, mul__tensor_10, getitem_97, getitem_56, convolution_default_52, sigmoid_default_7, convolution_default_13, view_default_52, view_default_96, mul__tensor_6, view_default_36, view_default_17, view_default_111, view_default_116, view_default_113, view_default_58, view_default_15, getitem_17, getitem_52, convolution_default_51, getitem_26, view_default_55, mul__tensor_34, view_default_34, view_default_56, getitem_134, view_default_37, view_default_115, getitem_55, view_default_99, constant_pad_nd_default_4, mean_dim, relu__default_2, view_default_16, mul_tensor_86, mul__tensor_40, mul__tensor_35, view_default_53, convolution_default_6, view_default_98, mul__tensor_4, getitem_34, relu__default_7, mean_dim_2, view_default_135, convolution_default_8, view_default_129, view_default_114, view_default_27, getitem_112, view_default_20, mul__tensor_41, view_default_24, getitem_109, getitem_115, convolution_default_62, getitem_19, view_default_35, mul__tensor_1, getitem_10, view_default_142, convolution_default_3, view_default_141, view_default_11, sigmoid_default_9, convolution_default_2, getitem_149, constant_pad_nd_default_1, mul_tensor_4, getitem_58, convolution_default_65, view_default_147, mul__tensor_55, mul_tensor_88, view_default_145, view_default_12, convolution_default_25, view_default_9, relu__default_9, getitem_146, getitem_7, getitem_142, convolution_default_69, view_default_7, primals_45, getitem_148, view_default_8, primals_221, view_default_59, mean_dim_9, view_default_14, getitem_14, getitem_5, getitem_11, mul__tensor_54, primals_49, convolution_default_68, view_default_10, view_default_143, getitem_8, view_default_146, view_default_148, view_default_6, view_default_150, view_default_13, constant_pad_nd_default_3, add_tensor_9, getitem_143, view_default_149, getitem_59, getitem_145, view_default_151, view_default_152, view_default_60, primals_47, getitem_13, relu__default_5, add_tensor_7, getitem_86, view_default_117, convolution_default_58, mul_tensor_28, view_default_92, getitem_101, getitem_37, getitem_91, convolution_default_55, relu__default_8, sigmoid_default_1, getitem_100, relu__default_3, view_default_100, primals_152, view_default_91, convolution_default_46, mul__tensor_50, mul__tensor_30, view_default_104, getitem_38, view_default_87, getitem_89, primals_187, getitem_92, view_default_103, convolution_default_14, getitem_85, mul__tensor_36, mean_dim_1, convolution_default_45, mul_tensor_71, primals_191, mul_tensor_30, primals_189, convolution_default_34, view_default_54, convolution_default_39, getitem_68, getitem_119, getitem_128, getitem_40, getitem_80, mean_dim_5, view_default_41, view_default_90, convolution_default_40, getitem_118, getitem_79, primals_137, mean_dim_4, view_default_119, primals_150, mul_tensor_79, view_default_118, mean_dim_8, getitem_88, view_default_39, getitem_167, view_default_88, mul_tensor_77, mul__tensor_11, getitem_41, avg_pool2d_default_2, primals_154, getitem_67, mul__tensor_31, view_default_137, convolution_default_15, view_default_38, view_default_101, mean_dim_3, primals_133, relu__default_1, primals_135, avg_pool2d_default_1, view_default_102, sigmoid_default_2, sigmoid_default_8, add_tensor_2, sigmoid_default_3, view_default_40, mul_tensor_37, view_default_89, getitem_127, view_default_42, getitem_64, getitem_155, convolution_default_76, primals_86, view_default_50, view_default_162, getitem_170, view_default_48, view_default_154, view_default_153, mul__tensor_21, getitem_43, relu__default_10, primals_7, getitem_49, getitem_154, view_default_155, view_default_21, convolution_default_70, mul_tensor_96, view_default_156, getitem_169, getitem_23, sigmoid_default_10, primals_208, convolution_default_28, getitem_151, getitem_65, primals_64, getitem_20, add_tensor_10, view_default_23, view_default_44, add_tensor_1, view_default_68, view_default_163, mean_dim_10, mul_tensor_20, getitem_50, view_default_164, convolution_default_20, primals_204, t_default, mul__tensor_5, convolution_default_7, primals_84, avg_pool2d_default, mul__tensor_15, convolution_default_18, getitem_152, view_default_49, view_default_22, view_default_170, primals_66, mul_tensor_22, view_default_43, view_default_51, convolution_default_80, primals_62, primals_82, view_default_67, getitem_22, convolution_default_71, primals_9, constant_pad_nd_default, mul__tensor_61, mul_tensor_94, primals_206, view_default_66, view_default_2, view_default_107, view_default_71, view_default_69, view_default_61, primals_99, getitem_106, primals_101, primals_103, view_default_62, primals_167, view_default_108, primals_171, convolution_default_31, view_default_1, view_default_110, getitem_71, getitem_107, add_tensor_3, view_default_109, view_default, convolution_default_49, primals_169, view_default_70, view_default_106, convolution_default, getitem_70, mul__tensor_39, sigmoid_default, mul_tensor_13, primals_25, view_default_3, getitem_163, view_default_169, mul_tensor_55, getitem_104, getitem_95, view_default_128, primals_118, view_default_94, relu__default_11, add_tensor_11, view_default_4, add_tensor, mul_tensor_102, getitem_94, mean_dim_6, relu__default, getitem_76, mul_tensor_11, mul_tensor_47, getitem_4, primals_27, convolution_default_33, mul_tensor_69, getitem_77, view_default_168, getitem_2, relu__default_4, view_default_80, mul_tensor_61, sigmoid_default_11, view_default_95, convolution_default_43, add_tensor_6, sigmoid_default_5, view_default_78, mul__tensor, view_default_5, mul_tensor_53, view_default_79, mul_tensor_45, view_default_93, sigmoid_default_6, view_default_81, primals_116, sigmoid_default_4, convolution_default_1, getitem_1, primals_120, mul__tensor_26, view_default_77, relu__default_6, mul_tensor_63, getitem_103, primals_29, add_tensor_4, add_tensor_5, view_default_105, view_default_121, getitem_44, getitem_62, view_default_159, view_default_75, view_default_166, getitem_29, convolution_default_75, view_default_139, view_default_157, mul__tensor_51, getitem_61, getitem_164, mul__tensor_25, mul__tensor_60, view_default_31, view_default_120, getitem_122, convolution_default_77, view_default_144, view_default_123, view_default_45, getitem_157, view_default_30, view_default_130, getitem_139, view_default_74, convolution_default_19, view_default_132, getitem_140, view_default_140, getitem_161, view_default_131, convolution_default_32, getitem_137, mul__tensor_56, mul__tensor_14, getitem_130, convolution_default_74, getitem_158, view_default_28, view_default_65, view_default_73, add_tensor_8, view_default_167, getitem_47, view_default_138, mul__tensor_44, getitem_131, getitem_46, convolution_default_63, convolution_default_64, view_default_47, mul__tensor_59, convolution_default_27, getitem_73, view_default_158, getitem_160, getitem_74, view_default_161, view_default_64, mul_tensor_39, mul__tensor_45, view_default_165, convolution_default_56, mul__tensor_24, view_default_29, view_default_133, getitem_136, getitem_166, view_default_72, getitem_121, view_default_160, view_default_122, mul__tensor_20, getitem_28, view_default_46, view_default_63, convolution_default_26]
        
