
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/timm_nfnet/timm_nfnet_joint_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, tangents_1):
        constant_pad_nd_default = torch.ops.aten.constant_pad_nd.default(primals_234, [0, 1, 0, 1], 0.0);  primals_234 = None
        view_default = torch.ops.aten.view.default(primals_224, [1, 16, -1]);  primals_224 = None
        mul_tensor = torch.ops.aten.mul.Tensor(primals_223, 0.19245008972987526);  primals_223 = None
        view_default_1 = torch.ops.aten.view.default(mul_tensor, [-1]);  mul_tensor = None
        empty = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(view_default, view_default_1, None, None, None, True, 0.0, 1e-05)
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        view_default_2 = torch.ops.aten.view.default(getitem, [16, 3, 3, 3]);  getitem = None
        convolution_default = torch.ops.aten.convolution.default(constant_pad_nd_default, view_default_2, primals_222, [2, 2], [0, 0], [1, 1], False, [0, 0], 1);  primals_222 = None
        gelu_default = torch.ops.aten.gelu.default(convolution_default)
        mul__tensor = torch.ops.aten.mul_.Tensor(gelu_default, 1.7015043497085571);  gelu_default = None
        view_default_3 = torch.ops.aten.view.default(primals_227, [1, 32, -1]);  primals_227 = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(primals_226, 0.08333333333333333);  primals_226 = None
        view_default_4 = torch.ops.aten.view.default(mul_tensor_1, [-1]);  mul_tensor_1 = None
        empty_1 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(view_default_3, view_default_4, None, None, None, True, 0.0, 1e-05)
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        view_default_5 = torch.ops.aten.view.default(getitem_3, [32, 16, 3, 3]);  getitem_3 = None
        convolution_default_1 = torch.ops.aten.convolution.default(mul__tensor, view_default_5, primals_225, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_225 = None
        gelu_default_1 = torch.ops.aten.gelu.default(convolution_default_1)
        mul__tensor_1 = torch.ops.aten.mul_.Tensor(gelu_default_1, 1.7015043497085571);  gelu_default_1 = None
        view_default_6 = torch.ops.aten.view.default(primals_230, [1, 64, -1]);  primals_230 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(primals_229, 0.05892556509887896);  primals_229 = None
        view_default_7 = torch.ops.aten.view.default(mul_tensor_2, [-1]);  mul_tensor_2 = None
        empty_2 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(view_default_6, view_default_7, None, None, None, True, 0.0, 1e-05)
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        view_default_8 = torch.ops.aten.view.default(getitem_6, [64, 32, 3, 3]);  getitem_6 = None
        convolution_default_2 = torch.ops.aten.convolution.default(mul__tensor_1, view_default_8, primals_228, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_228 = None
        gelu_default_2 = torch.ops.aten.gelu.default(convolution_default_2)
        mul__tensor_2 = torch.ops.aten.mul_.Tensor(gelu_default_2, 1.7015043497085571);  gelu_default_2 = None
        constant_pad_nd_default_1 = torch.ops.aten.constant_pad_nd.default(mul__tensor_2, [0, 1, 0, 1], 0.0);  mul__tensor_2 = None
        view_default_9 = torch.ops.aten.view.default(primals_233, [1, 128, -1]);  primals_233 = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(primals_232, 0.041666666666666664);  primals_232 = None
        view_default_10 = torch.ops.aten.view.default(mul_tensor_3, [-1]);  mul_tensor_3 = None
        empty_3 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(view_default_9, view_default_10, None, None, None, True, 0.0, 1e-05)
        getitem_9 = native_batch_norm_default_3[0]
        getitem_10 = native_batch_norm_default_3[1]
        getitem_11 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        view_default_11 = torch.ops.aten.view.default(getitem_9, [128, 64, 3, 3]);  getitem_9 = None
        convolution_default_3 = torch.ops.aten.convolution.default(constant_pad_nd_default_1, view_default_11, primals_231, [2, 2], [0, 0], [1, 1], False, [0, 0], 1);  primals_231 = None
        gelu_default_3 = torch.ops.aten.gelu.default(convolution_default_3)
        mul__tensor_3 = torch.ops.aten.mul_.Tensor(gelu_default_3, 1.7015043497085571);  gelu_default_3 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(mul__tensor_3, 1.0);  mul__tensor_3 = None
        view_default_12 = torch.ops.aten.view.default(primals_24, [1, 256, -1]);  primals_24 = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(primals_23, 0.08838834764831845);  primals_23 = None
        view_default_13 = torch.ops.aten.view.default(mul_tensor_5, [-1]);  mul_tensor_5 = None
        empty_4 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(view_default_12, view_default_13, None, None, None, True, 0.0, 1e-05)
        getitem_12 = native_batch_norm_default_4[0]
        getitem_13 = native_batch_norm_default_4[1]
        getitem_14 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        view_default_14 = torch.ops.aten.view.default(getitem_12, [256, 128, 1, 1]);  getitem_12 = None
        convolution_default_4 = torch.ops.aten.convolution.default(mul_tensor_4, view_default_14, primals_22, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_22 = None
        view_default_15 = torch.ops.aten.view.default(primals_12, [1, 128, -1]);  primals_12 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(primals_11, 0.08838834764831845);  primals_11 = None
        view_default_16 = torch.ops.aten.view.default(mul_tensor_6, [-1]);  mul_tensor_6 = None
        empty_5 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(view_default_15, view_default_16, None, None, None, True, 0.0, 1e-05)
        getitem_15 = native_batch_norm_default_5[0]
        getitem_16 = native_batch_norm_default_5[1]
        getitem_17 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        view_default_17 = torch.ops.aten.view.default(getitem_15, [128, 128, 1, 1]);  getitem_15 = None
        convolution_default_5 = torch.ops.aten.convolution.default(mul_tensor_4, view_default_17, primals_10, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_10 = None
        gelu_default_4 = torch.ops.aten.gelu.default(convolution_default_5)
        mul__tensor_4 = torch.ops.aten.mul_.Tensor(gelu_default_4, 1.7015043497085571);  gelu_default_4 = None
        view_default_18 = torch.ops.aten.view.default(primals_15, [1, 128, -1]);  primals_15 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(primals_14, 0.02946278254943948);  primals_14 = None
        view_default_19 = torch.ops.aten.view.default(mul_tensor_7, [-1]);  mul_tensor_7 = None
        empty_6 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(view_default_18, view_default_19, None, None, None, True, 0.0, 1e-05)
        getitem_18 = native_batch_norm_default_6[0]
        getitem_19 = native_batch_norm_default_6[1]
        getitem_20 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        view_default_20 = torch.ops.aten.view.default(getitem_18, [128, 128, 3, 3]);  getitem_18 = None
        convolution_default_6 = torch.ops.aten.convolution.default(mul__tensor_4, view_default_20, primals_13, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_13 = None
        gelu_default_5 = torch.ops.aten.gelu.default(convolution_default_6)
        mul__tensor_5 = torch.ops.aten.mul_.Tensor(gelu_default_5, 1.7015043497085571);  gelu_default_5 = None
        view_default_21 = torch.ops.aten.view.default(primals_18, [1, 128, -1]);  primals_18 = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(primals_17, 0.02946278254943948);  primals_17 = None
        view_default_22 = torch.ops.aten.view.default(mul_tensor_8, [-1]);  mul_tensor_8 = None
        empty_7 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(view_default_21, view_default_22, None, None, None, True, 0.0, 1e-05)
        getitem_21 = native_batch_norm_default_7[0]
        getitem_22 = native_batch_norm_default_7[1]
        getitem_23 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        view_default_23 = torch.ops.aten.view.default(getitem_21, [128, 128, 3, 3]);  getitem_21 = None
        convolution_default_7 = torch.ops.aten.convolution.default(mul__tensor_5, view_default_23, primals_16, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_16 = None
        gelu_default_6 = torch.ops.aten.gelu.default(convolution_default_7)
        mul__tensor_6 = torch.ops.aten.mul_.Tensor(gelu_default_6, 1.7015043497085571);  gelu_default_6 = None
        view_default_24 = torch.ops.aten.view.default(primals_21, [1, 256, -1]);  primals_21 = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(primals_20, 0.08838834764831845);  primals_20 = None
        view_default_25 = torch.ops.aten.view.default(mul_tensor_9, [-1]);  mul_tensor_9 = None
        empty_8 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(view_default_24, view_default_25, None, None, None, True, 0.0, 1e-05)
        getitem_24 = native_batch_norm_default_8[0]
        getitem_25 = native_batch_norm_default_8[1]
        getitem_26 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        view_default_26 = torch.ops.aten.view.default(getitem_24, [256, 128, 1, 1]);  getitem_24 = None
        convolution_default_8 = torch.ops.aten.convolution.default(mul__tensor_6, view_default_26, primals_19, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_19 = None
        mean_dim = torch.ops.aten.mean.dim(convolution_default_8, [2, 3], True)
        convolution_default_9 = torch.ops.aten.convolution.default(mean_dim, primals_7, primals_6, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_6 = None
        relu__default = torch.ops.aten.relu_.default(convolution_default_9);  convolution_default_9 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default, primals_9, primals_8, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_8 = None
        sigmoid_default = torch.ops.aten.sigmoid.default(convolution_default_10);  convolution_default_10 = None
        mul_tensor_10 = torch.ops.aten.mul.Tensor(convolution_default_8, sigmoid_default)
        mul_tensor_11 = torch.ops.aten.mul.Tensor(mul_tensor_10, 2.0);  mul_tensor_10 = None
        clone_default = torch.ops.aten.clone.default(mul_tensor_11)
        mul__tensor_7 = torch.ops.aten.mul_.Tensor(mul_tensor_11, primals_25);  mul_tensor_11 = None
        mul_tensor_12 = torch.ops.aten.mul.Tensor(mul__tensor_7, 0.2);  mul__tensor_7 = None
        add_tensor = torch.ops.aten.add.Tensor(mul_tensor_12, convolution_default_4);  mul_tensor_12 = convolution_default_4 = None
        gelu_default_7 = torch.ops.aten.gelu.default(add_tensor)
        mul__tensor_8 = torch.ops.aten.mul_.Tensor(gelu_default_7, 1.7015043497085571);  gelu_default_7 = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(mul__tensor_8, 0.9805806756909201);  mul__tensor_8 = None
        avg_pool2d_default = torch.ops.aten.avg_pool2d.default(mul_tensor_13, [2, 2], [2, 2], [0, 0], True, False)
        view_default_27 = torch.ops.aten.view.default(primals_44, [1, 512, -1]);  primals_44 = None
        mul_tensor_14 = torch.ops.aten.mul.Tensor(primals_43, 0.0625);  primals_43 = None
        view_default_28 = torch.ops.aten.view.default(mul_tensor_14, [-1]);  mul_tensor_14 = None
        empty_9 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(view_default_27, view_default_28, None, None, None, True, 0.0, 1e-05)
        getitem_27 = native_batch_norm_default_9[0]
        getitem_28 = native_batch_norm_default_9[1]
        getitem_29 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        view_default_29 = torch.ops.aten.view.default(getitem_27, [512, 256, 1, 1]);  getitem_27 = None
        convolution_default_11 = torch.ops.aten.convolution.default(avg_pool2d_default, view_default_29, primals_42, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_42 = None
        view_default_30 = torch.ops.aten.view.default(primals_32, [1, 256, -1]);  primals_32 = None
        mul_tensor_15 = torch.ops.aten.mul.Tensor(primals_31, 0.0625);  primals_31 = None
        view_default_31 = torch.ops.aten.view.default(mul_tensor_15, [-1]);  mul_tensor_15 = None
        empty_10 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(view_default_30, view_default_31, None, None, None, True, 0.0, 1e-05)
        getitem_30 = native_batch_norm_default_10[0]
        getitem_31 = native_batch_norm_default_10[1]
        getitem_32 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        view_default_32 = torch.ops.aten.view.default(getitem_30, [256, 256, 1, 1]);  getitem_30 = None
        convolution_default_12 = torch.ops.aten.convolution.default(mul_tensor_13, view_default_32, primals_30, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_30 = None
        gelu_default_8 = torch.ops.aten.gelu.default(convolution_default_12)
        mul__tensor_9 = torch.ops.aten.mul_.Tensor(gelu_default_8, 1.7015043497085571);  gelu_default_8 = None
        constant_pad_nd_default_2 = torch.ops.aten.constant_pad_nd.default(mul__tensor_9, [0, 1, 0, 1], 0.0);  mul__tensor_9 = None
        view_default_33 = torch.ops.aten.view.default(primals_35, [1, 256, -1]);  primals_35 = None
        mul_tensor_16 = torch.ops.aten.mul.Tensor(primals_34, 0.02946278254943948);  primals_34 = None
        view_default_34 = torch.ops.aten.view.default(mul_tensor_16, [-1]);  mul_tensor_16 = None
        empty_11 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(view_default_33, view_default_34, None, None, None, True, 0.0, 1e-05)
        getitem_33 = native_batch_norm_default_11[0]
        getitem_34 = native_batch_norm_default_11[1]
        getitem_35 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        view_default_35 = torch.ops.aten.view.default(getitem_33, [256, 128, 3, 3]);  getitem_33 = None
        convolution_default_13 = torch.ops.aten.convolution.default(constant_pad_nd_default_2, view_default_35, primals_33, [2, 2], [0, 0], [1, 1], False, [0, 0], 2);  primals_33 = None
        gelu_default_9 = torch.ops.aten.gelu.default(convolution_default_13)
        mul__tensor_10 = torch.ops.aten.mul_.Tensor(gelu_default_9, 1.7015043497085571);  gelu_default_9 = None
        view_default_36 = torch.ops.aten.view.default(primals_38, [1, 256, -1]);  primals_38 = None
        mul_tensor_17 = torch.ops.aten.mul.Tensor(primals_37, 0.02946278254943948);  primals_37 = None
        view_default_37 = torch.ops.aten.view.default(mul_tensor_17, [-1]);  mul_tensor_17 = None
        empty_12 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(view_default_36, view_default_37, None, None, None, True, 0.0, 1e-05)
        getitem_36 = native_batch_norm_default_12[0]
        getitem_37 = native_batch_norm_default_12[1]
        getitem_38 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        view_default_38 = torch.ops.aten.view.default(getitem_36, [256, 128, 3, 3]);  getitem_36 = None
        convolution_default_14 = torch.ops.aten.convolution.default(mul__tensor_10, view_default_38, primals_36, [1, 1], [1, 1], [1, 1], False, [0, 0], 2);  primals_36 = None
        gelu_default_10 = torch.ops.aten.gelu.default(convolution_default_14)
        mul__tensor_11 = torch.ops.aten.mul_.Tensor(gelu_default_10, 1.7015043497085571);  gelu_default_10 = None
        view_default_39 = torch.ops.aten.view.default(primals_41, [1, 512, -1]);  primals_41 = None
        mul_tensor_18 = torch.ops.aten.mul.Tensor(primals_40, 0.0625);  primals_40 = None
        view_default_40 = torch.ops.aten.view.default(mul_tensor_18, [-1]);  mul_tensor_18 = None
        empty_13 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(view_default_39, view_default_40, None, None, None, True, 0.0, 1e-05)
        getitem_39 = native_batch_norm_default_13[0]
        getitem_40 = native_batch_norm_default_13[1]
        getitem_41 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        view_default_41 = torch.ops.aten.view.default(getitem_39, [512, 256, 1, 1]);  getitem_39 = None
        convolution_default_15 = torch.ops.aten.convolution.default(mul__tensor_11, view_default_41, primals_39, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_39 = None
        mean_dim_1 = torch.ops.aten.mean.dim(convolution_default_15, [2, 3], True)
        convolution_default_16 = torch.ops.aten.convolution.default(mean_dim_1, primals_27, primals_26, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_26 = None
        relu__default_1 = torch.ops.aten.relu_.default(convolution_default_16);  convolution_default_16 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu__default_1, primals_29, primals_28, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_28 = None
        sigmoid_default_1 = torch.ops.aten.sigmoid.default(convolution_default_17);  convolution_default_17 = None
        mul_tensor_19 = torch.ops.aten.mul.Tensor(convolution_default_15, sigmoid_default_1)
        mul_tensor_20 = torch.ops.aten.mul.Tensor(mul_tensor_19, 2.0);  mul_tensor_19 = None
        clone_default_1 = torch.ops.aten.clone.default(mul_tensor_20)
        mul__tensor_12 = torch.ops.aten.mul_.Tensor(mul_tensor_20, primals_45);  mul_tensor_20 = None
        mul_tensor_21 = torch.ops.aten.mul.Tensor(mul__tensor_12, 0.2);  mul__tensor_12 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(mul_tensor_21, convolution_default_11);  mul_tensor_21 = convolution_default_11 = None
        gelu_default_11 = torch.ops.aten.gelu.default(add_tensor_1)
        mul__tensor_13 = torch.ops.aten.mul_.Tensor(gelu_default_11, 1.7015043497085571);  gelu_default_11 = None
        mul_tensor_22 = torch.ops.aten.mul.Tensor(mul__tensor_13, 0.9805806756909201);  mul__tensor_13 = None
        view_default_42 = torch.ops.aten.view.default(primals_52, [1, 256, -1]);  primals_52 = None
        mul_tensor_23 = torch.ops.aten.mul.Tensor(primals_51, 0.04419417382415922);  primals_51 = None
        view_default_43 = torch.ops.aten.view.default(mul_tensor_23, [-1]);  mul_tensor_23 = None
        empty_14 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(view_default_42, view_default_43, None, None, None, True, 0.0, 1e-05)
        getitem_42 = native_batch_norm_default_14[0]
        getitem_43 = native_batch_norm_default_14[1]
        getitem_44 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        view_default_44 = torch.ops.aten.view.default(getitem_42, [256, 512, 1, 1]);  getitem_42 = None
        convolution_default_18 = torch.ops.aten.convolution.default(mul_tensor_22, view_default_44, primals_50, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_50 = None
        gelu_default_12 = torch.ops.aten.gelu.default(convolution_default_18)
        mul__tensor_14 = torch.ops.aten.mul_.Tensor(gelu_default_12, 1.7015043497085571);  gelu_default_12 = None
        view_default_45 = torch.ops.aten.view.default(primals_55, [1, 256, -1]);  primals_55 = None
        mul_tensor_24 = torch.ops.aten.mul.Tensor(primals_54, 0.02946278254943948);  primals_54 = None
        view_default_46 = torch.ops.aten.view.default(mul_tensor_24, [-1]);  mul_tensor_24 = None
        empty_15 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(view_default_45, view_default_46, None, None, None, True, 0.0, 1e-05)
        getitem_45 = native_batch_norm_default_15[0]
        getitem_46 = native_batch_norm_default_15[1]
        getitem_47 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        view_default_47 = torch.ops.aten.view.default(getitem_45, [256, 128, 3, 3]);  getitem_45 = None
        convolution_default_19 = torch.ops.aten.convolution.default(mul__tensor_14, view_default_47, primals_53, [1, 1], [1, 1], [1, 1], False, [0, 0], 2);  primals_53 = None
        gelu_default_13 = torch.ops.aten.gelu.default(convolution_default_19)
        mul__tensor_15 = torch.ops.aten.mul_.Tensor(gelu_default_13, 1.7015043497085571);  gelu_default_13 = None
        view_default_48 = torch.ops.aten.view.default(primals_58, [1, 256, -1]);  primals_58 = None
        mul_tensor_25 = torch.ops.aten.mul.Tensor(primals_57, 0.02946278254943948);  primals_57 = None
        view_default_49 = torch.ops.aten.view.default(mul_tensor_25, [-1]);  mul_tensor_25 = None
        empty_16 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(view_default_48, view_default_49, None, None, None, True, 0.0, 1e-05)
        getitem_48 = native_batch_norm_default_16[0]
        getitem_49 = native_batch_norm_default_16[1]
        getitem_50 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        view_default_50 = torch.ops.aten.view.default(getitem_48, [256, 128, 3, 3]);  getitem_48 = None
        convolution_default_20 = torch.ops.aten.convolution.default(mul__tensor_15, view_default_50, primals_56, [1, 1], [1, 1], [1, 1], False, [0, 0], 2);  primals_56 = None
        gelu_default_14 = torch.ops.aten.gelu.default(convolution_default_20)
        mul__tensor_16 = torch.ops.aten.mul_.Tensor(gelu_default_14, 1.7015043497085571);  gelu_default_14 = None
        view_default_51 = torch.ops.aten.view.default(primals_61, [1, 512, -1]);  primals_61 = None
        mul_tensor_26 = torch.ops.aten.mul.Tensor(primals_60, 0.0625);  primals_60 = None
        view_default_52 = torch.ops.aten.view.default(mul_tensor_26, [-1]);  mul_tensor_26 = None
        empty_17 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(view_default_51, view_default_52, None, None, None, True, 0.0, 1e-05)
        getitem_51 = native_batch_norm_default_17[0]
        getitem_52 = native_batch_norm_default_17[1]
        getitem_53 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        view_default_53 = torch.ops.aten.view.default(getitem_51, [512, 256, 1, 1]);  getitem_51 = None
        convolution_default_21 = torch.ops.aten.convolution.default(mul__tensor_16, view_default_53, primals_59, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_59 = None
        mean_dim_2 = torch.ops.aten.mean.dim(convolution_default_21, [2, 3], True)
        convolution_default_22 = torch.ops.aten.convolution.default(mean_dim_2, primals_47, primals_46, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_46 = None
        relu__default_2 = torch.ops.aten.relu_.default(convolution_default_22);  convolution_default_22 = None
        convolution_default_23 = torch.ops.aten.convolution.default(relu__default_2, primals_49, primals_48, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_48 = None
        sigmoid_default_2 = torch.ops.aten.sigmoid.default(convolution_default_23);  convolution_default_23 = None
        mul_tensor_27 = torch.ops.aten.mul.Tensor(convolution_default_21, sigmoid_default_2)
        mul_tensor_28 = torch.ops.aten.mul.Tensor(mul_tensor_27, 2.0);  mul_tensor_27 = None
        clone_default_2 = torch.ops.aten.clone.default(mul_tensor_28)
        mul__tensor_17 = torch.ops.aten.mul_.Tensor(mul_tensor_28, primals_62);  mul_tensor_28 = None
        mul_tensor_29 = torch.ops.aten.mul.Tensor(mul__tensor_17, 0.2);  mul__tensor_17 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(mul_tensor_29, add_tensor_1);  mul_tensor_29 = None
        gelu_default_15 = torch.ops.aten.gelu.default(add_tensor_2)
        mul__tensor_18 = torch.ops.aten.mul_.Tensor(gelu_default_15, 1.7015043497085571);  gelu_default_15 = None
        mul_tensor_30 = torch.ops.aten.mul.Tensor(mul__tensor_18, 0.9622504486493761);  mul__tensor_18 = None
        avg_pool2d_default_1 = torch.ops.aten.avg_pool2d.default(mul_tensor_30, [2, 2], [2, 2], [0, 0], True, False)
        view_default_54 = torch.ops.aten.view.default(primals_81, [1, 1536, -1]);  primals_81 = None
        mul_tensor_31 = torch.ops.aten.mul.Tensor(primals_80, 0.04419417382415922);  primals_80 = None
        view_default_55 = torch.ops.aten.view.default(mul_tensor_31, [-1]);  mul_tensor_31 = None
        empty_18 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(view_default_54, view_default_55, None, None, None, True, 0.0, 1e-05)
        getitem_54 = native_batch_norm_default_18[0]
        getitem_55 = native_batch_norm_default_18[1]
        getitem_56 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        view_default_56 = torch.ops.aten.view.default(getitem_54, [1536, 512, 1, 1]);  getitem_54 = None
        convolution_default_24 = torch.ops.aten.convolution.default(avg_pool2d_default_1, view_default_56, primals_79, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_79 = None
        view_default_57 = torch.ops.aten.view.default(primals_69, [1, 768, -1]);  primals_69 = None
        mul_tensor_32 = torch.ops.aten.mul.Tensor(primals_68, 0.04419417382415922);  primals_68 = None
        view_default_58 = torch.ops.aten.view.default(mul_tensor_32, [-1]);  mul_tensor_32 = None
        empty_19 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(view_default_57, view_default_58, None, None, None, True, 0.0, 1e-05)
        getitem_57 = native_batch_norm_default_19[0]
        getitem_58 = native_batch_norm_default_19[1]
        getitem_59 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        view_default_59 = torch.ops.aten.view.default(getitem_57, [768, 512, 1, 1]);  getitem_57 = None
        convolution_default_25 = torch.ops.aten.convolution.default(mul_tensor_30, view_default_59, primals_67, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_67 = None
        gelu_default_16 = torch.ops.aten.gelu.default(convolution_default_25)
        mul__tensor_19 = torch.ops.aten.mul_.Tensor(gelu_default_16, 1.7015043497085571);  gelu_default_16 = None
        constant_pad_nd_default_3 = torch.ops.aten.constant_pad_nd.default(mul__tensor_19, [0, 1, 0, 1], 0.0);  mul__tensor_19 = None
        view_default_60 = torch.ops.aten.view.default(primals_72, [1, 768, -1]);  primals_72 = None
        mul_tensor_33 = torch.ops.aten.mul.Tensor(primals_71, 0.02946278254943948);  primals_71 = None
        view_default_61 = torch.ops.aten.view.default(mul_tensor_33, [-1]);  mul_tensor_33 = None
        empty_20 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(view_default_60, view_default_61, None, None, None, True, 0.0, 1e-05)
        getitem_60 = native_batch_norm_default_20[0]
        getitem_61 = native_batch_norm_default_20[1]
        getitem_62 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        view_default_62 = torch.ops.aten.view.default(getitem_60, [768, 128, 3, 3]);  getitem_60 = None
        convolution_default_26 = torch.ops.aten.convolution.default(constant_pad_nd_default_3, view_default_62, primals_70, [2, 2], [0, 0], [1, 1], False, [0, 0], 6);  primals_70 = None
        gelu_default_17 = torch.ops.aten.gelu.default(convolution_default_26)
        mul__tensor_20 = torch.ops.aten.mul_.Tensor(gelu_default_17, 1.7015043497085571);  gelu_default_17 = None
        view_default_63 = torch.ops.aten.view.default(primals_75, [1, 768, -1]);  primals_75 = None
        mul_tensor_34 = torch.ops.aten.mul.Tensor(primals_74, 0.02946278254943948);  primals_74 = None
        view_default_64 = torch.ops.aten.view.default(mul_tensor_34, [-1]);  mul_tensor_34 = None
        empty_21 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(view_default_63, view_default_64, None, None, None, True, 0.0, 1e-05)
        getitem_63 = native_batch_norm_default_21[0]
        getitem_64 = native_batch_norm_default_21[1]
        getitem_65 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        view_default_65 = torch.ops.aten.view.default(getitem_63, [768, 128, 3, 3]);  getitem_63 = None
        convolution_default_27 = torch.ops.aten.convolution.default(mul__tensor_20, view_default_65, primals_73, [1, 1], [1, 1], [1, 1], False, [0, 0], 6);  primals_73 = None
        gelu_default_18 = torch.ops.aten.gelu.default(convolution_default_27)
        mul__tensor_21 = torch.ops.aten.mul_.Tensor(gelu_default_18, 1.7015043497085571);  gelu_default_18 = None
        view_default_66 = torch.ops.aten.view.default(primals_78, [1, 1536, -1]);  primals_78 = None
        mul_tensor_35 = torch.ops.aten.mul.Tensor(primals_77, 0.03608439182435161);  primals_77 = None
        view_default_67 = torch.ops.aten.view.default(mul_tensor_35, [-1]);  mul_tensor_35 = None
        empty_22 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(view_default_66, view_default_67, None, None, None, True, 0.0, 1e-05)
        getitem_66 = native_batch_norm_default_22[0]
        getitem_67 = native_batch_norm_default_22[1]
        getitem_68 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        view_default_68 = torch.ops.aten.view.default(getitem_66, [1536, 768, 1, 1]);  getitem_66 = None
        convolution_default_28 = torch.ops.aten.convolution.default(mul__tensor_21, view_default_68, primals_76, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_76 = None
        mean_dim_3 = torch.ops.aten.mean.dim(convolution_default_28, [2, 3], True)
        convolution_default_29 = torch.ops.aten.convolution.default(mean_dim_3, primals_64, primals_63, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_63 = None
        relu__default_3 = torch.ops.aten.relu_.default(convolution_default_29);  convolution_default_29 = None
        convolution_default_30 = torch.ops.aten.convolution.default(relu__default_3, primals_66, primals_65, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_65 = None
        sigmoid_default_3 = torch.ops.aten.sigmoid.default(convolution_default_30);  convolution_default_30 = None
        mul_tensor_36 = torch.ops.aten.mul.Tensor(convolution_default_28, sigmoid_default_3)
        mul_tensor_37 = torch.ops.aten.mul.Tensor(mul_tensor_36, 2.0);  mul_tensor_36 = None
        clone_default_3 = torch.ops.aten.clone.default(mul_tensor_37)
        mul__tensor_22 = torch.ops.aten.mul_.Tensor(mul_tensor_37, primals_82);  mul_tensor_37 = None
        mul_tensor_38 = torch.ops.aten.mul.Tensor(mul__tensor_22, 0.2);  mul__tensor_22 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(mul_tensor_38, convolution_default_24);  mul_tensor_38 = convolution_default_24 = None
        gelu_default_19 = torch.ops.aten.gelu.default(add_tensor_3)
        mul__tensor_23 = torch.ops.aten.mul_.Tensor(gelu_default_19, 1.7015043497085571);  gelu_default_19 = None
        mul_tensor_39 = torch.ops.aten.mul.Tensor(mul__tensor_23, 0.9805806756909201);  mul__tensor_23 = None
        view_default_69 = torch.ops.aten.view.default(primals_89, [1, 768, -1]);  primals_89 = None
        mul_tensor_40 = torch.ops.aten.mul.Tensor(primals_88, 0.02551551815399144);  primals_88 = None
        view_default_70 = torch.ops.aten.view.default(mul_tensor_40, [-1]);  mul_tensor_40 = None
        empty_23 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(view_default_69, view_default_70, None, None, None, True, 0.0, 1e-05)
        getitem_69 = native_batch_norm_default_23[0]
        getitem_70 = native_batch_norm_default_23[1]
        getitem_71 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        view_default_71 = torch.ops.aten.view.default(getitem_69, [768, 1536, 1, 1]);  getitem_69 = None
        convolution_default_31 = torch.ops.aten.convolution.default(mul_tensor_39, view_default_71, primals_87, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_87 = None
        gelu_default_20 = torch.ops.aten.gelu.default(convolution_default_31)
        mul__tensor_24 = torch.ops.aten.mul_.Tensor(gelu_default_20, 1.7015043497085571);  gelu_default_20 = None
        view_default_72 = torch.ops.aten.view.default(primals_92, [1, 768, -1]);  primals_92 = None
        mul_tensor_41 = torch.ops.aten.mul.Tensor(primals_91, 0.02946278254943948);  primals_91 = None
        view_default_73 = torch.ops.aten.view.default(mul_tensor_41, [-1]);  mul_tensor_41 = None
        empty_24 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(view_default_72, view_default_73, None, None, None, True, 0.0, 1e-05)
        getitem_72 = native_batch_norm_default_24[0]
        getitem_73 = native_batch_norm_default_24[1]
        getitem_74 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        view_default_74 = torch.ops.aten.view.default(getitem_72, [768, 128, 3, 3]);  getitem_72 = None
        convolution_default_32 = torch.ops.aten.convolution.default(mul__tensor_24, view_default_74, primals_90, [1, 1], [1, 1], [1, 1], False, [0, 0], 6);  primals_90 = None
        gelu_default_21 = torch.ops.aten.gelu.default(convolution_default_32)
        mul__tensor_25 = torch.ops.aten.mul_.Tensor(gelu_default_21, 1.7015043497085571);  gelu_default_21 = None
        view_default_75 = torch.ops.aten.view.default(primals_95, [1, 768, -1]);  primals_95 = None
        mul_tensor_42 = torch.ops.aten.mul.Tensor(primals_94, 0.02946278254943948);  primals_94 = None
        view_default_76 = torch.ops.aten.view.default(mul_tensor_42, [-1]);  mul_tensor_42 = None
        empty_25 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(view_default_75, view_default_76, None, None, None, True, 0.0, 1e-05)
        getitem_75 = native_batch_norm_default_25[0]
        getitem_76 = native_batch_norm_default_25[1]
        getitem_77 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        view_default_77 = torch.ops.aten.view.default(getitem_75, [768, 128, 3, 3]);  getitem_75 = None
        convolution_default_33 = torch.ops.aten.convolution.default(mul__tensor_25, view_default_77, primals_93, [1, 1], [1, 1], [1, 1], False, [0, 0], 6);  primals_93 = None
        gelu_default_22 = torch.ops.aten.gelu.default(convolution_default_33)
        mul__tensor_26 = torch.ops.aten.mul_.Tensor(gelu_default_22, 1.7015043497085571);  gelu_default_22 = None
        view_default_78 = torch.ops.aten.view.default(primals_98, [1, 1536, -1]);  primals_98 = None
        mul_tensor_43 = torch.ops.aten.mul.Tensor(primals_97, 0.03608439182435161);  primals_97 = None
        view_default_79 = torch.ops.aten.view.default(mul_tensor_43, [-1]);  mul_tensor_43 = None
        empty_26 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(view_default_78, view_default_79, None, None, None, True, 0.0, 1e-05)
        getitem_78 = native_batch_norm_default_26[0]
        getitem_79 = native_batch_norm_default_26[1]
        getitem_80 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        view_default_80 = torch.ops.aten.view.default(getitem_78, [1536, 768, 1, 1]);  getitem_78 = None
        convolution_default_34 = torch.ops.aten.convolution.default(mul__tensor_26, view_default_80, primals_96, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_96 = None
        mean_dim_4 = torch.ops.aten.mean.dim(convolution_default_34, [2, 3], True)
        convolution_default_35 = torch.ops.aten.convolution.default(mean_dim_4, primals_84, primals_83, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_83 = None
        relu__default_4 = torch.ops.aten.relu_.default(convolution_default_35);  convolution_default_35 = None
        convolution_default_36 = torch.ops.aten.convolution.default(relu__default_4, primals_86, primals_85, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_85 = None
        sigmoid_default_4 = torch.ops.aten.sigmoid.default(convolution_default_36);  convolution_default_36 = None
        mul_tensor_44 = torch.ops.aten.mul.Tensor(convolution_default_34, sigmoid_default_4)
        mul_tensor_45 = torch.ops.aten.mul.Tensor(mul_tensor_44, 2.0);  mul_tensor_44 = None
        clone_default_4 = torch.ops.aten.clone.default(mul_tensor_45)
        mul__tensor_27 = torch.ops.aten.mul_.Tensor(mul_tensor_45, primals_99);  mul_tensor_45 = None
        mul_tensor_46 = torch.ops.aten.mul.Tensor(mul__tensor_27, 0.2);  mul__tensor_27 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(mul_tensor_46, add_tensor_3);  mul_tensor_46 = None
        gelu_default_23 = torch.ops.aten.gelu.default(add_tensor_4)
        mul__tensor_28 = torch.ops.aten.mul_.Tensor(gelu_default_23, 1.7015043497085571);  gelu_default_23 = None
        mul_tensor_47 = torch.ops.aten.mul.Tensor(mul__tensor_28, 0.9622504486493761);  mul__tensor_28 = None
        view_default_81 = torch.ops.aten.view.default(primals_106, [1, 768, -1]);  primals_106 = None
        mul_tensor_48 = torch.ops.aten.mul.Tensor(primals_105, 0.02551551815399144);  primals_105 = None
        view_default_82 = torch.ops.aten.view.default(mul_tensor_48, [-1]);  mul_tensor_48 = None
        empty_27 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(view_default_81, view_default_82, None, None, None, True, 0.0, 1e-05)
        getitem_81 = native_batch_norm_default_27[0]
        getitem_82 = native_batch_norm_default_27[1]
        getitem_83 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        view_default_83 = torch.ops.aten.view.default(getitem_81, [768, 1536, 1, 1]);  getitem_81 = None
        convolution_default_37 = torch.ops.aten.convolution.default(mul_tensor_47, view_default_83, primals_104, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_104 = None
        gelu_default_24 = torch.ops.aten.gelu.default(convolution_default_37)
        mul__tensor_29 = torch.ops.aten.mul_.Tensor(gelu_default_24, 1.7015043497085571);  gelu_default_24 = None
        view_default_84 = torch.ops.aten.view.default(primals_109, [1, 768, -1]);  primals_109 = None
        mul_tensor_49 = torch.ops.aten.mul.Tensor(primals_108, 0.02946278254943948);  primals_108 = None
        view_default_85 = torch.ops.aten.view.default(mul_tensor_49, [-1]);  mul_tensor_49 = None
        empty_28 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(view_default_84, view_default_85, None, None, None, True, 0.0, 1e-05)
        getitem_84 = native_batch_norm_default_28[0]
        getitem_85 = native_batch_norm_default_28[1]
        getitem_86 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        view_default_86 = torch.ops.aten.view.default(getitem_84, [768, 128, 3, 3]);  getitem_84 = None
        convolution_default_38 = torch.ops.aten.convolution.default(mul__tensor_29, view_default_86, primals_107, [1, 1], [1, 1], [1, 1], False, [0, 0], 6);  primals_107 = None
        gelu_default_25 = torch.ops.aten.gelu.default(convolution_default_38)
        mul__tensor_30 = torch.ops.aten.mul_.Tensor(gelu_default_25, 1.7015043497085571);  gelu_default_25 = None
        view_default_87 = torch.ops.aten.view.default(primals_112, [1, 768, -1]);  primals_112 = None
        mul_tensor_50 = torch.ops.aten.mul.Tensor(primals_111, 0.02946278254943948);  primals_111 = None
        view_default_88 = torch.ops.aten.view.default(mul_tensor_50, [-1]);  mul_tensor_50 = None
        empty_29 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(view_default_87, view_default_88, None, None, None, True, 0.0, 1e-05)
        getitem_87 = native_batch_norm_default_29[0]
        getitem_88 = native_batch_norm_default_29[1]
        getitem_89 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        view_default_89 = torch.ops.aten.view.default(getitem_87, [768, 128, 3, 3]);  getitem_87 = None
        convolution_default_39 = torch.ops.aten.convolution.default(mul__tensor_30, view_default_89, primals_110, [1, 1], [1, 1], [1, 1], False, [0, 0], 6);  primals_110 = None
        gelu_default_26 = torch.ops.aten.gelu.default(convolution_default_39)
        mul__tensor_31 = torch.ops.aten.mul_.Tensor(gelu_default_26, 1.7015043497085571);  gelu_default_26 = None
        view_default_90 = torch.ops.aten.view.default(primals_115, [1, 1536, -1]);  primals_115 = None
        mul_tensor_51 = torch.ops.aten.mul.Tensor(primals_114, 0.03608439182435161);  primals_114 = None
        view_default_91 = torch.ops.aten.view.default(mul_tensor_51, [-1]);  mul_tensor_51 = None
        empty_30 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(view_default_90, view_default_91, None, None, None, True, 0.0, 1e-05)
        getitem_90 = native_batch_norm_default_30[0]
        getitem_91 = native_batch_norm_default_30[1]
        getitem_92 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        view_default_92 = torch.ops.aten.view.default(getitem_90, [1536, 768, 1, 1]);  getitem_90 = None
        convolution_default_40 = torch.ops.aten.convolution.default(mul__tensor_31, view_default_92, primals_113, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_113 = None
        mean_dim_5 = torch.ops.aten.mean.dim(convolution_default_40, [2, 3], True)
        convolution_default_41 = torch.ops.aten.convolution.default(mean_dim_5, primals_101, primals_100, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_100 = None
        relu__default_5 = torch.ops.aten.relu_.default(convolution_default_41);  convolution_default_41 = None
        convolution_default_42 = torch.ops.aten.convolution.default(relu__default_5, primals_103, primals_102, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_102 = None
        sigmoid_default_5 = torch.ops.aten.sigmoid.default(convolution_default_42);  convolution_default_42 = None
        mul_tensor_52 = torch.ops.aten.mul.Tensor(convolution_default_40, sigmoid_default_5)
        mul_tensor_53 = torch.ops.aten.mul.Tensor(mul_tensor_52, 2.0);  mul_tensor_52 = None
        clone_default_5 = torch.ops.aten.clone.default(mul_tensor_53)
        mul__tensor_32 = torch.ops.aten.mul_.Tensor(mul_tensor_53, primals_116);  mul_tensor_53 = None
        mul_tensor_54 = torch.ops.aten.mul.Tensor(mul__tensor_32, 0.2);  mul__tensor_32 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(mul_tensor_54, add_tensor_4);  mul_tensor_54 = None
        gelu_default_27 = torch.ops.aten.gelu.default(add_tensor_5)
        mul__tensor_33 = torch.ops.aten.mul_.Tensor(gelu_default_27, 1.7015043497085571);  gelu_default_27 = None
        mul_tensor_55 = torch.ops.aten.mul.Tensor(mul__tensor_33, 0.9449111825230679);  mul__tensor_33 = None
        view_default_93 = torch.ops.aten.view.default(primals_123, [1, 768, -1]);  primals_123 = None
        mul_tensor_56 = torch.ops.aten.mul.Tensor(primals_122, 0.02551551815399144);  primals_122 = None
        view_default_94 = torch.ops.aten.view.default(mul_tensor_56, [-1]);  mul_tensor_56 = None
        empty_31 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(view_default_93, view_default_94, None, None, None, True, 0.0, 1e-05)
        getitem_93 = native_batch_norm_default_31[0]
        getitem_94 = native_batch_norm_default_31[1]
        getitem_95 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        view_default_95 = torch.ops.aten.view.default(getitem_93, [768, 1536, 1, 1]);  getitem_93 = None
        convolution_default_43 = torch.ops.aten.convolution.default(mul_tensor_55, view_default_95, primals_121, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_121 = None
        gelu_default_28 = torch.ops.aten.gelu.default(convolution_default_43)
        mul__tensor_34 = torch.ops.aten.mul_.Tensor(gelu_default_28, 1.7015043497085571);  gelu_default_28 = None
        view_default_96 = torch.ops.aten.view.default(primals_126, [1, 768, -1]);  primals_126 = None
        mul_tensor_57 = torch.ops.aten.mul.Tensor(primals_125, 0.02946278254943948);  primals_125 = None
        view_default_97 = torch.ops.aten.view.default(mul_tensor_57, [-1]);  mul_tensor_57 = None
        empty_32 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(view_default_96, view_default_97, None, None, None, True, 0.0, 1e-05)
        getitem_96 = native_batch_norm_default_32[0]
        getitem_97 = native_batch_norm_default_32[1]
        getitem_98 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        view_default_98 = torch.ops.aten.view.default(getitem_96, [768, 128, 3, 3]);  getitem_96 = None
        convolution_default_44 = torch.ops.aten.convolution.default(mul__tensor_34, view_default_98, primals_124, [1, 1], [1, 1], [1, 1], False, [0, 0], 6);  primals_124 = None
        gelu_default_29 = torch.ops.aten.gelu.default(convolution_default_44)
        mul__tensor_35 = torch.ops.aten.mul_.Tensor(gelu_default_29, 1.7015043497085571);  gelu_default_29 = None
        view_default_99 = torch.ops.aten.view.default(primals_129, [1, 768, -1]);  primals_129 = None
        mul_tensor_58 = torch.ops.aten.mul.Tensor(primals_128, 0.02946278254943948);  primals_128 = None
        view_default_100 = torch.ops.aten.view.default(mul_tensor_58, [-1]);  mul_tensor_58 = None
        empty_33 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(view_default_99, view_default_100, None, None, None, True, 0.0, 1e-05)
        getitem_99 = native_batch_norm_default_33[0]
        getitem_100 = native_batch_norm_default_33[1]
        getitem_101 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        view_default_101 = torch.ops.aten.view.default(getitem_99, [768, 128, 3, 3]);  getitem_99 = None
        convolution_default_45 = torch.ops.aten.convolution.default(mul__tensor_35, view_default_101, primals_127, [1, 1], [1, 1], [1, 1], False, [0, 0], 6);  primals_127 = None
        gelu_default_30 = torch.ops.aten.gelu.default(convolution_default_45)
        mul__tensor_36 = torch.ops.aten.mul_.Tensor(gelu_default_30, 1.7015043497085571);  gelu_default_30 = None
        view_default_102 = torch.ops.aten.view.default(primals_132, [1, 1536, -1]);  primals_132 = None
        mul_tensor_59 = torch.ops.aten.mul.Tensor(primals_131, 0.03608439182435161);  primals_131 = None
        view_default_103 = torch.ops.aten.view.default(mul_tensor_59, [-1]);  mul_tensor_59 = None
        empty_34 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(view_default_102, view_default_103, None, None, None, True, 0.0, 1e-05)
        getitem_102 = native_batch_norm_default_34[0]
        getitem_103 = native_batch_norm_default_34[1]
        getitem_104 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        view_default_104 = torch.ops.aten.view.default(getitem_102, [1536, 768, 1, 1]);  getitem_102 = None
        convolution_default_46 = torch.ops.aten.convolution.default(mul__tensor_36, view_default_104, primals_130, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_130 = None
        mean_dim_6 = torch.ops.aten.mean.dim(convolution_default_46, [2, 3], True)
        convolution_default_47 = torch.ops.aten.convolution.default(mean_dim_6, primals_118, primals_117, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_117 = None
        relu__default_6 = torch.ops.aten.relu_.default(convolution_default_47);  convolution_default_47 = None
        convolution_default_48 = torch.ops.aten.convolution.default(relu__default_6, primals_120, primals_119, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_119 = None
        sigmoid_default_6 = torch.ops.aten.sigmoid.default(convolution_default_48);  convolution_default_48 = None
        mul_tensor_60 = torch.ops.aten.mul.Tensor(convolution_default_46, sigmoid_default_6)
        mul_tensor_61 = torch.ops.aten.mul.Tensor(mul_tensor_60, 2.0);  mul_tensor_60 = None
        clone_default_6 = torch.ops.aten.clone.default(mul_tensor_61)
        mul__tensor_37 = torch.ops.aten.mul_.Tensor(mul_tensor_61, primals_133);  mul_tensor_61 = None
        mul_tensor_62 = torch.ops.aten.mul.Tensor(mul__tensor_37, 0.2);  mul__tensor_37 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(mul_tensor_62, add_tensor_5);  mul_tensor_62 = None
        gelu_default_31 = torch.ops.aten.gelu.default(add_tensor_6)
        mul__tensor_38 = torch.ops.aten.mul_.Tensor(gelu_default_31, 1.7015043497085571);  gelu_default_31 = None
        mul_tensor_63 = torch.ops.aten.mul.Tensor(mul__tensor_38, 0.9284766908852592);  mul__tensor_38 = None
        view_default_105 = torch.ops.aten.view.default(primals_140, [1, 768, -1]);  primals_140 = None
        mul_tensor_64 = torch.ops.aten.mul.Tensor(primals_139, 0.02551551815399144);  primals_139 = None
        view_default_106 = torch.ops.aten.view.default(mul_tensor_64, [-1]);  mul_tensor_64 = None
        empty_35 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(view_default_105, view_default_106, None, None, None, True, 0.0, 1e-05)
        getitem_105 = native_batch_norm_default_35[0]
        getitem_106 = native_batch_norm_default_35[1]
        getitem_107 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        view_default_107 = torch.ops.aten.view.default(getitem_105, [768, 1536, 1, 1]);  getitem_105 = None
        convolution_default_49 = torch.ops.aten.convolution.default(mul_tensor_63, view_default_107, primals_138, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_138 = None
        gelu_default_32 = torch.ops.aten.gelu.default(convolution_default_49)
        mul__tensor_39 = torch.ops.aten.mul_.Tensor(gelu_default_32, 1.7015043497085571);  gelu_default_32 = None
        view_default_108 = torch.ops.aten.view.default(primals_143, [1, 768, -1]);  primals_143 = None
        mul_tensor_65 = torch.ops.aten.mul.Tensor(primals_142, 0.02946278254943948);  primals_142 = None
        view_default_109 = torch.ops.aten.view.default(mul_tensor_65, [-1]);  mul_tensor_65 = None
        empty_36 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(view_default_108, view_default_109, None, None, None, True, 0.0, 1e-05)
        getitem_108 = native_batch_norm_default_36[0]
        getitem_109 = native_batch_norm_default_36[1]
        getitem_110 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        view_default_110 = torch.ops.aten.view.default(getitem_108, [768, 128, 3, 3]);  getitem_108 = None
        convolution_default_50 = torch.ops.aten.convolution.default(mul__tensor_39, view_default_110, primals_141, [1, 1], [1, 1], [1, 1], False, [0, 0], 6);  primals_141 = None
        gelu_default_33 = torch.ops.aten.gelu.default(convolution_default_50)
        mul__tensor_40 = torch.ops.aten.mul_.Tensor(gelu_default_33, 1.7015043497085571);  gelu_default_33 = None
        view_default_111 = torch.ops.aten.view.default(primals_146, [1, 768, -1]);  primals_146 = None
        mul_tensor_66 = torch.ops.aten.mul.Tensor(primals_145, 0.02946278254943948);  primals_145 = None
        view_default_112 = torch.ops.aten.view.default(mul_tensor_66, [-1]);  mul_tensor_66 = None
        empty_37 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(view_default_111, view_default_112, None, None, None, True, 0.0, 1e-05)
        getitem_111 = native_batch_norm_default_37[0]
        getitem_112 = native_batch_norm_default_37[1]
        getitem_113 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        view_default_113 = torch.ops.aten.view.default(getitem_111, [768, 128, 3, 3]);  getitem_111 = None
        convolution_default_51 = torch.ops.aten.convolution.default(mul__tensor_40, view_default_113, primals_144, [1, 1], [1, 1], [1, 1], False, [0, 0], 6);  primals_144 = None
        gelu_default_34 = torch.ops.aten.gelu.default(convolution_default_51)
        mul__tensor_41 = torch.ops.aten.mul_.Tensor(gelu_default_34, 1.7015043497085571);  gelu_default_34 = None
        view_default_114 = torch.ops.aten.view.default(primals_149, [1, 1536, -1]);  primals_149 = None
        mul_tensor_67 = torch.ops.aten.mul.Tensor(primals_148, 0.03608439182435161);  primals_148 = None
        view_default_115 = torch.ops.aten.view.default(mul_tensor_67, [-1]);  mul_tensor_67 = None
        empty_38 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(view_default_114, view_default_115, None, None, None, True, 0.0, 1e-05)
        getitem_114 = native_batch_norm_default_38[0]
        getitem_115 = native_batch_norm_default_38[1]
        getitem_116 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        view_default_116 = torch.ops.aten.view.default(getitem_114, [1536, 768, 1, 1]);  getitem_114 = None
        convolution_default_52 = torch.ops.aten.convolution.default(mul__tensor_41, view_default_116, primals_147, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_147 = None
        mean_dim_7 = torch.ops.aten.mean.dim(convolution_default_52, [2, 3], True)
        convolution_default_53 = torch.ops.aten.convolution.default(mean_dim_7, primals_135, primals_134, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_134 = None
        relu__default_7 = torch.ops.aten.relu_.default(convolution_default_53);  convolution_default_53 = None
        convolution_default_54 = torch.ops.aten.convolution.default(relu__default_7, primals_137, primals_136, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_136 = None
        sigmoid_default_7 = torch.ops.aten.sigmoid.default(convolution_default_54);  convolution_default_54 = None
        mul_tensor_68 = torch.ops.aten.mul.Tensor(convolution_default_52, sigmoid_default_7)
        mul_tensor_69 = torch.ops.aten.mul.Tensor(mul_tensor_68, 2.0);  mul_tensor_68 = None
        clone_default_7 = torch.ops.aten.clone.default(mul_tensor_69)
        mul__tensor_42 = torch.ops.aten.mul_.Tensor(mul_tensor_69, primals_150);  mul_tensor_69 = None
        mul_tensor_70 = torch.ops.aten.mul.Tensor(mul__tensor_42, 0.2);  mul__tensor_42 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(mul_tensor_70, add_tensor_6);  mul_tensor_70 = None
        gelu_default_35 = torch.ops.aten.gelu.default(add_tensor_7)
        mul__tensor_43 = torch.ops.aten.mul_.Tensor(gelu_default_35, 1.7015043497085571);  gelu_default_35 = None
        mul_tensor_71 = torch.ops.aten.mul.Tensor(mul__tensor_43, 0.9128709291752768);  mul__tensor_43 = None
        view_default_117 = torch.ops.aten.view.default(primals_157, [1, 768, -1]);  primals_157 = None
        mul_tensor_72 = torch.ops.aten.mul.Tensor(primals_156, 0.02551551815399144);  primals_156 = None
        view_default_118 = torch.ops.aten.view.default(mul_tensor_72, [-1]);  mul_tensor_72 = None
        empty_39 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(view_default_117, view_default_118, None, None, None, True, 0.0, 1e-05)
        getitem_117 = native_batch_norm_default_39[0]
        getitem_118 = native_batch_norm_default_39[1]
        getitem_119 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        view_default_119 = torch.ops.aten.view.default(getitem_117, [768, 1536, 1, 1]);  getitem_117 = None
        convolution_default_55 = torch.ops.aten.convolution.default(mul_tensor_71, view_default_119, primals_155, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_155 = None
        gelu_default_36 = torch.ops.aten.gelu.default(convolution_default_55)
        mul__tensor_44 = torch.ops.aten.mul_.Tensor(gelu_default_36, 1.7015043497085571);  gelu_default_36 = None
        view_default_120 = torch.ops.aten.view.default(primals_160, [1, 768, -1]);  primals_160 = None
        mul_tensor_73 = torch.ops.aten.mul.Tensor(primals_159, 0.02946278254943948);  primals_159 = None
        view_default_121 = torch.ops.aten.view.default(mul_tensor_73, [-1]);  mul_tensor_73 = None
        empty_40 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(view_default_120, view_default_121, None, None, None, True, 0.0, 1e-05)
        getitem_120 = native_batch_norm_default_40[0]
        getitem_121 = native_batch_norm_default_40[1]
        getitem_122 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        view_default_122 = torch.ops.aten.view.default(getitem_120, [768, 128, 3, 3]);  getitem_120 = None
        convolution_default_56 = torch.ops.aten.convolution.default(mul__tensor_44, view_default_122, primals_158, [1, 1], [1, 1], [1, 1], False, [0, 0], 6);  primals_158 = None
        gelu_default_37 = torch.ops.aten.gelu.default(convolution_default_56)
        mul__tensor_45 = torch.ops.aten.mul_.Tensor(gelu_default_37, 1.7015043497085571);  gelu_default_37 = None
        view_default_123 = torch.ops.aten.view.default(primals_163, [1, 768, -1]);  primals_163 = None
        mul_tensor_74 = torch.ops.aten.mul.Tensor(primals_162, 0.02946278254943948);  primals_162 = None
        view_default_124 = torch.ops.aten.view.default(mul_tensor_74, [-1]);  mul_tensor_74 = None
        empty_41 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(view_default_123, view_default_124, None, None, None, True, 0.0, 1e-05)
        getitem_123 = native_batch_norm_default_41[0]
        getitem_124 = native_batch_norm_default_41[1]
        getitem_125 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        view_default_125 = torch.ops.aten.view.default(getitem_123, [768, 128, 3, 3]);  getitem_123 = None
        convolution_default_57 = torch.ops.aten.convolution.default(mul__tensor_45, view_default_125, primals_161, [1, 1], [1, 1], [1, 1], False, [0, 0], 6);  primals_161 = None
        gelu_default_38 = torch.ops.aten.gelu.default(convolution_default_57)
        mul__tensor_46 = torch.ops.aten.mul_.Tensor(gelu_default_38, 1.7015043497085571);  gelu_default_38 = None
        view_default_126 = torch.ops.aten.view.default(primals_166, [1, 1536, -1]);  primals_166 = None
        mul_tensor_75 = torch.ops.aten.mul.Tensor(primals_165, 0.03608439182435161);  primals_165 = None
        view_default_127 = torch.ops.aten.view.default(mul_tensor_75, [-1]);  mul_tensor_75 = None
        empty_42 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(view_default_126, view_default_127, None, None, None, True, 0.0, 1e-05)
        getitem_126 = native_batch_norm_default_42[0]
        getitem_127 = native_batch_norm_default_42[1]
        getitem_128 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        view_default_128 = torch.ops.aten.view.default(getitem_126, [1536, 768, 1, 1]);  getitem_126 = None
        convolution_default_58 = torch.ops.aten.convolution.default(mul__tensor_46, view_default_128, primals_164, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_164 = None
        mean_dim_8 = torch.ops.aten.mean.dim(convolution_default_58, [2, 3], True)
        convolution_default_59 = torch.ops.aten.convolution.default(mean_dim_8, primals_152, primals_151, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_151 = None
        relu__default_8 = torch.ops.aten.relu_.default(convolution_default_59);  convolution_default_59 = None
        convolution_default_60 = torch.ops.aten.convolution.default(relu__default_8, primals_154, primals_153, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_153 = None
        sigmoid_default_8 = torch.ops.aten.sigmoid.default(convolution_default_60);  convolution_default_60 = None
        mul_tensor_76 = torch.ops.aten.mul.Tensor(convolution_default_58, sigmoid_default_8)
        mul_tensor_77 = torch.ops.aten.mul.Tensor(mul_tensor_76, 2.0);  mul_tensor_76 = None
        clone_default_8 = torch.ops.aten.clone.default(mul_tensor_77)
        mul__tensor_47 = torch.ops.aten.mul_.Tensor(mul_tensor_77, primals_167);  mul_tensor_77 = None
        mul_tensor_78 = torch.ops.aten.mul.Tensor(mul__tensor_47, 0.2);  mul__tensor_47 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(mul_tensor_78, add_tensor_7);  mul_tensor_78 = None
        gelu_default_39 = torch.ops.aten.gelu.default(add_tensor_8)
        mul__tensor_48 = torch.ops.aten.mul_.Tensor(gelu_default_39, 1.7015043497085571);  gelu_default_39 = None
        mul_tensor_79 = torch.ops.aten.mul.Tensor(mul__tensor_48, 0.8980265101338745);  mul__tensor_48 = None
        avg_pool2d_default_2 = torch.ops.aten.avg_pool2d.default(mul_tensor_79, [2, 2], [2, 2], [0, 0], True, False)
        view_default_129 = torch.ops.aten.view.default(primals_186, [1, 1536, -1]);  primals_186 = None
        mul_tensor_80 = torch.ops.aten.mul.Tensor(primals_185, 0.02551551815399144);  primals_185 = None
        view_default_130 = torch.ops.aten.view.default(mul_tensor_80, [-1]);  mul_tensor_80 = None
        empty_43 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(view_default_129, view_default_130, None, None, None, True, 0.0, 1e-05)
        getitem_129 = native_batch_norm_default_43[0]
        getitem_130 = native_batch_norm_default_43[1]
        getitem_131 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        view_default_131 = torch.ops.aten.view.default(getitem_129, [1536, 1536, 1, 1]);  getitem_129 = None
        convolution_default_61 = torch.ops.aten.convolution.default(avg_pool2d_default_2, view_default_131, primals_184, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_184 = None
        view_default_132 = torch.ops.aten.view.default(primals_174, [1, 768, -1]);  primals_174 = None
        mul_tensor_81 = torch.ops.aten.mul.Tensor(primals_173, 0.02551551815399144);  primals_173 = None
        view_default_133 = torch.ops.aten.view.default(mul_tensor_81, [-1]);  mul_tensor_81 = None
        empty_44 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(view_default_132, view_default_133, None, None, None, True, 0.0, 1e-05)
        getitem_132 = native_batch_norm_default_44[0]
        getitem_133 = native_batch_norm_default_44[1]
        getitem_134 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        view_default_134 = torch.ops.aten.view.default(getitem_132, [768, 1536, 1, 1]);  getitem_132 = None
        convolution_default_62 = torch.ops.aten.convolution.default(mul_tensor_79, view_default_134, primals_172, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_172 = None
        gelu_default_40 = torch.ops.aten.gelu.default(convolution_default_62)
        mul__tensor_49 = torch.ops.aten.mul_.Tensor(gelu_default_40, 1.7015043497085571);  gelu_default_40 = None
        constant_pad_nd_default_4 = torch.ops.aten.constant_pad_nd.default(mul__tensor_49, [0, 1, 0, 1], 0.0);  mul__tensor_49 = None
        view_default_135 = torch.ops.aten.view.default(primals_177, [1, 768, -1]);  primals_177 = None
        mul_tensor_82 = torch.ops.aten.mul.Tensor(primals_176, 0.02946278254943948);  primals_176 = None
        view_default_136 = torch.ops.aten.view.default(mul_tensor_82, [-1]);  mul_tensor_82 = None
        empty_45 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(view_default_135, view_default_136, None, None, None, True, 0.0, 1e-05)
        getitem_135 = native_batch_norm_default_45[0]
        getitem_136 = native_batch_norm_default_45[1]
        getitem_137 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        view_default_137 = torch.ops.aten.view.default(getitem_135, [768, 128, 3, 3]);  getitem_135 = None
        convolution_default_63 = torch.ops.aten.convolution.default(constant_pad_nd_default_4, view_default_137, primals_175, [2, 2], [0, 0], [1, 1], False, [0, 0], 6);  primals_175 = None
        gelu_default_41 = torch.ops.aten.gelu.default(convolution_default_63)
        mul__tensor_50 = torch.ops.aten.mul_.Tensor(gelu_default_41, 1.7015043497085571);  gelu_default_41 = None
        view_default_138 = torch.ops.aten.view.default(primals_180, [1, 768, -1]);  primals_180 = None
        mul_tensor_83 = torch.ops.aten.mul.Tensor(primals_179, 0.02946278254943948);  primals_179 = None
        view_default_139 = torch.ops.aten.view.default(mul_tensor_83, [-1]);  mul_tensor_83 = None
        empty_46 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(view_default_138, view_default_139, None, None, None, True, 0.0, 1e-05)
        getitem_138 = native_batch_norm_default_46[0]
        getitem_139 = native_batch_norm_default_46[1]
        getitem_140 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        view_default_140 = torch.ops.aten.view.default(getitem_138, [768, 128, 3, 3]);  getitem_138 = None
        convolution_default_64 = torch.ops.aten.convolution.default(mul__tensor_50, view_default_140, primals_178, [1, 1], [1, 1], [1, 1], False, [0, 0], 6);  primals_178 = None
        gelu_default_42 = torch.ops.aten.gelu.default(convolution_default_64)
        mul__tensor_51 = torch.ops.aten.mul_.Tensor(gelu_default_42, 1.7015043497085571);  gelu_default_42 = None
        view_default_141 = torch.ops.aten.view.default(primals_183, [1, 1536, -1]);  primals_183 = None
        mul_tensor_84 = torch.ops.aten.mul.Tensor(primals_182, 0.03608439182435161);  primals_182 = None
        view_default_142 = torch.ops.aten.view.default(mul_tensor_84, [-1]);  mul_tensor_84 = None
        empty_47 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(view_default_141, view_default_142, None, None, None, True, 0.0, 1e-05)
        getitem_141 = native_batch_norm_default_47[0]
        getitem_142 = native_batch_norm_default_47[1]
        getitem_143 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        view_default_143 = torch.ops.aten.view.default(getitem_141, [1536, 768, 1, 1]);  getitem_141 = None
        convolution_default_65 = torch.ops.aten.convolution.default(mul__tensor_51, view_default_143, primals_181, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_181 = None
        mean_dim_9 = torch.ops.aten.mean.dim(convolution_default_65, [2, 3], True)
        convolution_default_66 = torch.ops.aten.convolution.default(mean_dim_9, primals_169, primals_168, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_168 = None
        relu__default_9 = torch.ops.aten.relu_.default(convolution_default_66);  convolution_default_66 = None
        convolution_default_67 = torch.ops.aten.convolution.default(relu__default_9, primals_171, primals_170, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_170 = None
        sigmoid_default_9 = torch.ops.aten.sigmoid.default(convolution_default_67);  convolution_default_67 = None
        mul_tensor_85 = torch.ops.aten.mul.Tensor(convolution_default_65, sigmoid_default_9)
        mul_tensor_86 = torch.ops.aten.mul.Tensor(mul_tensor_85, 2.0);  mul_tensor_85 = None
        clone_default_9 = torch.ops.aten.clone.default(mul_tensor_86)
        mul__tensor_52 = torch.ops.aten.mul_.Tensor(mul_tensor_86, primals_187);  mul_tensor_86 = None
        mul_tensor_87 = torch.ops.aten.mul.Tensor(mul__tensor_52, 0.2);  mul__tensor_52 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(mul_tensor_87, convolution_default_61);  mul_tensor_87 = convolution_default_61 = None
        gelu_default_43 = torch.ops.aten.gelu.default(add_tensor_9)
        mul__tensor_53 = torch.ops.aten.mul_.Tensor(gelu_default_43, 1.7015043497085571);  gelu_default_43 = None
        mul_tensor_88 = torch.ops.aten.mul.Tensor(mul__tensor_53, 0.9805806756909201);  mul__tensor_53 = None
        view_default_144 = torch.ops.aten.view.default(primals_194, [1, 768, -1]);  primals_194 = None
        mul_tensor_89 = torch.ops.aten.mul.Tensor(primals_193, 0.02551551815399144);  primals_193 = None
        view_default_145 = torch.ops.aten.view.default(mul_tensor_89, [-1]);  mul_tensor_89 = None
        empty_48 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(view_default_144, view_default_145, None, None, None, True, 0.0, 1e-05)
        getitem_144 = native_batch_norm_default_48[0]
        getitem_145 = native_batch_norm_default_48[1]
        getitem_146 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        view_default_146 = torch.ops.aten.view.default(getitem_144, [768, 1536, 1, 1]);  getitem_144 = None
        convolution_default_68 = torch.ops.aten.convolution.default(mul_tensor_88, view_default_146, primals_192, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_192 = None
        gelu_default_44 = torch.ops.aten.gelu.default(convolution_default_68)
        mul__tensor_54 = torch.ops.aten.mul_.Tensor(gelu_default_44, 1.7015043497085571);  gelu_default_44 = None
        view_default_147 = torch.ops.aten.view.default(primals_197, [1, 768, -1]);  primals_197 = None
        mul_tensor_90 = torch.ops.aten.mul.Tensor(primals_196, 0.02946278254943948);  primals_196 = None
        view_default_148 = torch.ops.aten.view.default(mul_tensor_90, [-1]);  mul_tensor_90 = None
        empty_49 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(view_default_147, view_default_148, None, None, None, True, 0.0, 1e-05)
        getitem_147 = native_batch_norm_default_49[0]
        getitem_148 = native_batch_norm_default_49[1]
        getitem_149 = native_batch_norm_default_49[2];  native_batch_norm_default_49 = None
        view_default_149 = torch.ops.aten.view.default(getitem_147, [768, 128, 3, 3]);  getitem_147 = None
        convolution_default_69 = torch.ops.aten.convolution.default(mul__tensor_54, view_default_149, primals_195, [1, 1], [1, 1], [1, 1], False, [0, 0], 6);  primals_195 = None
        gelu_default_45 = torch.ops.aten.gelu.default(convolution_default_69)
        mul__tensor_55 = torch.ops.aten.mul_.Tensor(gelu_default_45, 1.7015043497085571);  gelu_default_45 = None
        view_default_150 = torch.ops.aten.view.default(primals_200, [1, 768, -1]);  primals_200 = None
        mul_tensor_91 = torch.ops.aten.mul.Tensor(primals_199, 0.02946278254943948);  primals_199 = None
        view_default_151 = torch.ops.aten.view.default(mul_tensor_91, [-1]);  mul_tensor_91 = None
        empty_50 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(view_default_150, view_default_151, None, None, None, True, 0.0, 1e-05)
        getitem_150 = native_batch_norm_default_50[0]
        getitem_151 = native_batch_norm_default_50[1]
        getitem_152 = native_batch_norm_default_50[2];  native_batch_norm_default_50 = None
        view_default_152 = torch.ops.aten.view.default(getitem_150, [768, 128, 3, 3]);  getitem_150 = None
        convolution_default_70 = torch.ops.aten.convolution.default(mul__tensor_55, view_default_152, primals_198, [1, 1], [1, 1], [1, 1], False, [0, 0], 6);  primals_198 = None
        gelu_default_46 = torch.ops.aten.gelu.default(convolution_default_70)
        mul__tensor_56 = torch.ops.aten.mul_.Tensor(gelu_default_46, 1.7015043497085571);  gelu_default_46 = None
        view_default_153 = torch.ops.aten.view.default(primals_203, [1, 1536, -1]);  primals_203 = None
        mul_tensor_92 = torch.ops.aten.mul.Tensor(primals_202, 0.03608439182435161);  primals_202 = None
        view_default_154 = torch.ops.aten.view.default(mul_tensor_92, [-1]);  mul_tensor_92 = None
        empty_51 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(view_default_153, view_default_154, None, None, None, True, 0.0, 1e-05)
        getitem_153 = native_batch_norm_default_51[0]
        getitem_154 = native_batch_norm_default_51[1]
        getitem_155 = native_batch_norm_default_51[2];  native_batch_norm_default_51 = None
        view_default_155 = torch.ops.aten.view.default(getitem_153, [1536, 768, 1, 1]);  getitem_153 = None
        convolution_default_71 = torch.ops.aten.convolution.default(mul__tensor_56, view_default_155, primals_201, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_201 = None
        mean_dim_10 = torch.ops.aten.mean.dim(convolution_default_71, [2, 3], True)
        convolution_default_72 = torch.ops.aten.convolution.default(mean_dim_10, primals_189, primals_188, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_188 = None
        relu__default_10 = torch.ops.aten.relu_.default(convolution_default_72);  convolution_default_72 = None
        convolution_default_73 = torch.ops.aten.convolution.default(relu__default_10, primals_191, primals_190, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_190 = None
        sigmoid_default_10 = torch.ops.aten.sigmoid.default(convolution_default_73);  convolution_default_73 = None
        mul_tensor_93 = torch.ops.aten.mul.Tensor(convolution_default_71, sigmoid_default_10)
        mul_tensor_94 = torch.ops.aten.mul.Tensor(mul_tensor_93, 2.0);  mul_tensor_93 = None
        clone_default_10 = torch.ops.aten.clone.default(mul_tensor_94)
        mul__tensor_57 = torch.ops.aten.mul_.Tensor(mul_tensor_94, primals_204);  mul_tensor_94 = None
        mul_tensor_95 = torch.ops.aten.mul.Tensor(mul__tensor_57, 0.2);  mul__tensor_57 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(mul_tensor_95, add_tensor_9);  mul_tensor_95 = None
        gelu_default_47 = torch.ops.aten.gelu.default(add_tensor_10)
        mul__tensor_58 = torch.ops.aten.mul_.Tensor(gelu_default_47, 1.7015043497085571);  gelu_default_47 = None
        mul_tensor_96 = torch.ops.aten.mul.Tensor(mul__tensor_58, 0.9622504486493761);  mul__tensor_58 = None
        view_default_156 = torch.ops.aten.view.default(primals_211, [1, 768, -1]);  primals_211 = None
        mul_tensor_97 = torch.ops.aten.mul.Tensor(primals_210, 0.02551551815399144);  primals_210 = None
        view_default_157 = torch.ops.aten.view.default(mul_tensor_97, [-1]);  mul_tensor_97 = None
        empty_52 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(view_default_156, view_default_157, None, None, None, True, 0.0, 1e-05)
        getitem_156 = native_batch_norm_default_52[0]
        getitem_157 = native_batch_norm_default_52[1]
        getitem_158 = native_batch_norm_default_52[2];  native_batch_norm_default_52 = None
        view_default_158 = torch.ops.aten.view.default(getitem_156, [768, 1536, 1, 1]);  getitem_156 = None
        convolution_default_74 = torch.ops.aten.convolution.default(mul_tensor_96, view_default_158, primals_209, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_209 = None
        gelu_default_48 = torch.ops.aten.gelu.default(convolution_default_74)
        mul__tensor_59 = torch.ops.aten.mul_.Tensor(gelu_default_48, 1.7015043497085571);  gelu_default_48 = None
        view_default_159 = torch.ops.aten.view.default(primals_214, [1, 768, -1]);  primals_214 = None
        mul_tensor_98 = torch.ops.aten.mul.Tensor(primals_213, 0.02946278254943948);  primals_213 = None
        view_default_160 = torch.ops.aten.view.default(mul_tensor_98, [-1]);  mul_tensor_98 = None
        empty_53 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_53 = torch.ops.aten.native_batch_norm.default(view_default_159, view_default_160, None, None, None, True, 0.0, 1e-05)
        getitem_159 = native_batch_norm_default_53[0]
        getitem_160 = native_batch_norm_default_53[1]
        getitem_161 = native_batch_norm_default_53[2];  native_batch_norm_default_53 = None
        view_default_161 = torch.ops.aten.view.default(getitem_159, [768, 128, 3, 3]);  getitem_159 = None
        convolution_default_75 = torch.ops.aten.convolution.default(mul__tensor_59, view_default_161, primals_212, [1, 1], [1, 1], [1, 1], False, [0, 0], 6);  primals_212 = None
        gelu_default_49 = torch.ops.aten.gelu.default(convolution_default_75)
        mul__tensor_60 = torch.ops.aten.mul_.Tensor(gelu_default_49, 1.7015043497085571);  gelu_default_49 = None
        view_default_162 = torch.ops.aten.view.default(primals_217, [1, 768, -1]);  primals_217 = None
        mul_tensor_99 = torch.ops.aten.mul.Tensor(primals_216, 0.02946278254943948);  primals_216 = None
        view_default_163 = torch.ops.aten.view.default(mul_tensor_99, [-1]);  mul_tensor_99 = None
        empty_54 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_54 = torch.ops.aten.native_batch_norm.default(view_default_162, view_default_163, None, None, None, True, 0.0, 1e-05)
        getitem_162 = native_batch_norm_default_54[0]
        getitem_163 = native_batch_norm_default_54[1]
        getitem_164 = native_batch_norm_default_54[2];  native_batch_norm_default_54 = None
        view_default_164 = torch.ops.aten.view.default(getitem_162, [768, 128, 3, 3]);  getitem_162 = None
        convolution_default_76 = torch.ops.aten.convolution.default(mul__tensor_60, view_default_164, primals_215, [1, 1], [1, 1], [1, 1], False, [0, 0], 6);  primals_215 = None
        gelu_default_50 = torch.ops.aten.gelu.default(convolution_default_76)
        mul__tensor_61 = torch.ops.aten.mul_.Tensor(gelu_default_50, 1.7015043497085571);  gelu_default_50 = None
        view_default_165 = torch.ops.aten.view.default(primals_220, [1, 1536, -1]);  primals_220 = None
        mul_tensor_100 = torch.ops.aten.mul.Tensor(primals_219, 0.03608439182435161);  primals_219 = None
        view_default_166 = torch.ops.aten.view.default(mul_tensor_100, [-1]);  mul_tensor_100 = None
        empty_55 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_55 = torch.ops.aten.native_batch_norm.default(view_default_165, view_default_166, None, None, None, True, 0.0, 1e-05)
        getitem_165 = native_batch_norm_default_55[0]
        getitem_166 = native_batch_norm_default_55[1]
        getitem_167 = native_batch_norm_default_55[2];  native_batch_norm_default_55 = None
        view_default_167 = torch.ops.aten.view.default(getitem_165, [1536, 768, 1, 1]);  getitem_165 = None
        convolution_default_77 = torch.ops.aten.convolution.default(mul__tensor_61, view_default_167, primals_218, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_218 = None
        mean_dim_11 = torch.ops.aten.mean.dim(convolution_default_77, [2, 3], True)
        convolution_default_78 = torch.ops.aten.convolution.default(mean_dim_11, primals_206, primals_205, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_205 = None
        relu__default_11 = torch.ops.aten.relu_.default(convolution_default_78);  convolution_default_78 = None
        convolution_default_79 = torch.ops.aten.convolution.default(relu__default_11, primals_208, primals_207, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_207 = None
        sigmoid_default_11 = torch.ops.aten.sigmoid.default(convolution_default_79);  convolution_default_79 = None
        mul_tensor_101 = torch.ops.aten.mul.Tensor(convolution_default_77, sigmoid_default_11)
        mul_tensor_102 = torch.ops.aten.mul.Tensor(mul_tensor_101, 2.0);  mul_tensor_101 = None
        clone_default_11 = torch.ops.aten.clone.default(mul_tensor_102)
        mul__tensor_62 = torch.ops.aten.mul_.Tensor(mul_tensor_102, primals_221);  mul_tensor_102 = None
        mul_tensor_103 = torch.ops.aten.mul.Tensor(mul__tensor_62, 0.2);  mul__tensor_62 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(mul_tensor_103, add_tensor_10);  mul_tensor_103 = None
        view_default_168 = torch.ops.aten.view.default(primals_3, [1, 3072, -1]);  primals_3 = None
        mul_tensor_104 = torch.ops.aten.mul.Tensor(primals_2, 0.02551551815399144);  primals_2 = None
        view_default_169 = torch.ops.aten.view.default(mul_tensor_104, [-1]);  mul_tensor_104 = None
        empty_56 = torch.ops.aten.empty.memory_format([0], dtype = torch.uint8, layout = torch.strided, device = device(type='cuda', index=0))
        native_batch_norm_default_56 = torch.ops.aten.native_batch_norm.default(view_default_168, view_default_169, None, None, None, True, 0.0, 1e-05)
        getitem_168 = native_batch_norm_default_56[0]
        getitem_169 = native_batch_norm_default_56[1]
        getitem_170 = native_batch_norm_default_56[2];  native_batch_norm_default_56 = None
        view_default_170 = torch.ops.aten.view.default(getitem_168, [3072, 1536, 1, 1]);  getitem_168 = None
        convolution_default_80 = torch.ops.aten.convolution.default(add_tensor_11, view_default_170, primals_1, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1 = None
        gelu_default_51 = torch.ops.aten.gelu.default(convolution_default_80)
        mul__tensor_63 = torch.ops.aten.mul_.Tensor(gelu_default_51, 1.7015043497085571);  gelu_default_51 = None
        mean_dim_12 = torch.ops.aten.mean.dim(mul__tensor_63, [-1, -2], True);  mul__tensor_63 = None
        view_default_171 = torch.ops.aten.view.default(mean_dim_12, [128, 3072]);  mean_dim_12 = None
        t_default = torch.ops.aten.t.default(primals_5);  primals_5 = None
        addmm_default = torch.ops.aten.addmm.default(primals_4, view_default_171, t_default);  primals_4 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(addmm_default, tangents_1)
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, view_default_171);  t_default_2 = view_default_171 = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_172 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        view_default_173 = torch.ops.aten.view.default(mm_default, [128, 3072, 1, 1]);  mm_default = None
        expand_default = torch.ops.aten.expand.default(view_default_173, [128, 3072, 6, 6]);  view_default_173 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 36);  expand_default = None
        mul_tensor_105 = torch.ops.aten.mul.Tensor(div_scalar, 1.7015043497085571);  div_scalar = None
        to_dtype = torch.ops.aten.to.dtype(mul_tensor_105, torch.float32);  mul_tensor_105 = None
        to_dtype_1 = torch.ops.aten.to.dtype(convolution_default_80, torch.float32);  convolution_default_80 = None
        mul_tensor_106 = torch.ops.aten.mul.Tensor(to_dtype_1, 0.7071067811865476)
        erf_default = torch.ops.aten.erf.default(mul_tensor_106);  mul_tensor_106 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(erf_default, 1);  erf_default = None
        mul_tensor_107 = torch.ops.aten.mul.Tensor(add_tensor_12, 0.5);  add_tensor_12 = None
        mul_tensor_108 = torch.ops.aten.mul.Tensor(to_dtype_1, to_dtype_1)
        mul_tensor_109 = torch.ops.aten.mul.Tensor(mul_tensor_108, -0.5);  mul_tensor_108 = None
        exp_default = torch.ops.aten.exp.default(mul_tensor_109);  mul_tensor_109 = None
        mul_tensor_110 = torch.ops.aten.mul.Tensor(exp_default, 0.3989422804014327);  exp_default = None
        mul_tensor_111 = torch.ops.aten.mul.Tensor(to_dtype_1, mul_tensor_110);  to_dtype_1 = mul_tensor_110 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(mul_tensor_107, mul_tensor_111);  mul_tensor_107 = mul_tensor_111 = None
        mul_tensor_112 = torch.ops.aten.mul.Tensor(to_dtype, add_tensor_13);  to_dtype = add_tensor_13 = None
        to_dtype_2 = torch.ops.aten.to.dtype(mul_tensor_112, torch.float32);  mul_tensor_112 = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(to_dtype_2, add_tensor_11, view_default_170, [3072], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_2 = add_tensor_11 = view_default_170 = None
        getitem_171 = convolution_backward_default[0]
        getitem_172 = convolution_backward_default[1]
        getitem_173 = convolution_backward_default[2];  convolution_backward_default = None
        view_default_174 = torch.ops.aten.view.default(getitem_172, [1, 3072, 1536]);  getitem_172 = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(view_default_174, view_default_168, view_default_169, None, None, getitem_169, getitem_170, True, 1e-05, [True, True, False]);  view_default_174 = view_default_168 = view_default_169 = getitem_169 = getitem_170 = None
        getitem_174 = native_batch_norm_backward_default[0]
        getitem_175 = native_batch_norm_backward_default[1]
        getitem_176 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        view_default_175 = torch.ops.aten.view.default(getitem_175, [3072, 1, 1, 1]);  getitem_175 = None
        mul_tensor_113 = torch.ops.aten.mul.Tensor(view_default_175, 0.02551551815399144);  view_default_175 = None
        view_default_176 = torch.ops.aten.view.default(getitem_174, [3072, 1536, 1, 1]);  getitem_174 = None
        mul_tensor_114 = torch.ops.aten.mul.Tensor(getitem_171, 0.2)
        mul_tensor_115 = torch.ops.aten.mul.Tensor(mul_tensor_114, clone_default_11);  clone_default_11 = None
        mul_tensor_116 = torch.ops.aten.mul.Tensor(mul_tensor_114, primals_221);  mul_tensor_114 = primals_221 = None
        sum_default = torch.ops.aten.sum.default(mul_tensor_115);  mul_tensor_115 = None
        mul_tensor_117 = torch.ops.aten.mul.Tensor(mul_tensor_116, 2.0);  mul_tensor_116 = None
        mul_tensor_118 = torch.ops.aten.mul.Tensor(mul_tensor_117, convolution_default_77);  convolution_default_77 = None
        mul_tensor_119 = torch.ops.aten.mul.Tensor(mul_tensor_117, sigmoid_default_11);  mul_tensor_117 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(mul_tensor_118, [2, 3], True);  mul_tensor_118 = None
        to_dtype_3 = torch.ops.aten.to.dtype(sum_dim_int_list_1, torch.float32);  sum_dim_int_list_1 = None
        to_dtype_4 = torch.ops.aten.to.dtype(sigmoid_default_11, torch.float32);  sigmoid_default_11 = None
        rsub_scalar = torch.ops.aten.rsub.Scalar(to_dtype_4, 1)
        mul_tensor_120 = torch.ops.aten.mul.Tensor(to_dtype_4, rsub_scalar);  to_dtype_4 = rsub_scalar = None
        conj_physical_default = torch.ops.aten.conj_physical.default(mul_tensor_120);  mul_tensor_120 = None
        mul_tensor_121 = torch.ops.aten.mul.Tensor(to_dtype_3, conj_physical_default);  to_dtype_3 = conj_physical_default = None
        to_dtype_5 = torch.ops.aten.to.dtype(mul_tensor_121, torch.float32);  mul_tensor_121 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(to_dtype_5, relu__default_11, primals_208, [1536], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_5 = primals_208 = None
        getitem_177 = convolution_backward_default_1[0]
        getitem_178 = convolution_backward_default_1[1]
        getitem_179 = convolution_backward_default_1[2];  convolution_backward_default_1 = None
        to_dtype_6 = torch.ops.aten.to.dtype(getitem_177, torch.float32);  getitem_177 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default, to_dtype_6);  le_scalar = new_zeros_default = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(to_dtype_8, mean_dim_11, primals_206, [768], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_8 = mean_dim_11 = primals_206 = None
        getitem_180 = convolution_backward_default_2[0]
        getitem_181 = convolution_backward_default_2[1]
        getitem_182 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        expand_default_1 = torch.ops.aten.expand.default(getitem_180, [128, 1536, 6, 6]);  getitem_180 = None
        div_scalar_1 = torch.ops.aten.div.Scalar(expand_default_1, 36);  expand_default_1 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(mul_tensor_119, div_scalar_1);  mul_tensor_119 = div_scalar_1 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(add_tensor_14, mul__tensor_61, view_default_167, [1536], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  add_tensor_14 = mul__tensor_61 = view_default_167 = None
        getitem_183 = convolution_backward_default_3[0]
        getitem_184 = convolution_backward_default_3[1]
        getitem_185 = convolution_backward_default_3[2];  convolution_backward_default_3 = None
        view_default_177 = torch.ops.aten.view.default(getitem_184, [1, 1536, 768]);  getitem_184 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(view_default_177, view_default_165, view_default_166, None, None, getitem_166, getitem_167, True, 1e-05, [True, True, False]);  view_default_177 = view_default_165 = view_default_166 = getitem_166 = getitem_167 = None
        getitem_186 = native_batch_norm_backward_default_1[0]
        getitem_187 = native_batch_norm_backward_default_1[1]
        getitem_188 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        view_default_178 = torch.ops.aten.view.default(getitem_187, [1536, 1, 1, 1]);  getitem_187 = None
        mul_tensor_122 = torch.ops.aten.mul.Tensor(view_default_178, 0.03608439182435161);  view_default_178 = None
        view_default_179 = torch.ops.aten.view.default(getitem_186, [1536, 768, 1, 1]);  getitem_186 = None
        mul_tensor_123 = torch.ops.aten.mul.Tensor(getitem_183, 1.7015043497085571);  getitem_183 = None
        to_dtype_9 = torch.ops.aten.to.dtype(mul_tensor_123, torch.float32);  mul_tensor_123 = None
        to_dtype_10 = torch.ops.aten.to.dtype(convolution_default_76, torch.float32);  convolution_default_76 = None
        mul_tensor_124 = torch.ops.aten.mul.Tensor(to_dtype_10, 0.7071067811865476)
        erf_default_1 = torch.ops.aten.erf.default(mul_tensor_124);  mul_tensor_124 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(erf_default_1, 1);  erf_default_1 = None
        mul_tensor_125 = torch.ops.aten.mul.Tensor(add_tensor_15, 0.5);  add_tensor_15 = None
        mul_tensor_126 = torch.ops.aten.mul.Tensor(to_dtype_10, to_dtype_10)
        mul_tensor_127 = torch.ops.aten.mul.Tensor(mul_tensor_126, -0.5);  mul_tensor_126 = None
        exp_default_1 = torch.ops.aten.exp.default(mul_tensor_127);  mul_tensor_127 = None
        mul_tensor_128 = torch.ops.aten.mul.Tensor(exp_default_1, 0.3989422804014327);  exp_default_1 = None
        mul_tensor_129 = torch.ops.aten.mul.Tensor(to_dtype_10, mul_tensor_128);  to_dtype_10 = mul_tensor_128 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(mul_tensor_125, mul_tensor_129);  mul_tensor_125 = mul_tensor_129 = None
        mul_tensor_130 = torch.ops.aten.mul.Tensor(to_dtype_9, add_tensor_16);  to_dtype_9 = add_tensor_16 = None
        to_dtype_11 = torch.ops.aten.to.dtype(mul_tensor_130, torch.float32);  mul_tensor_130 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(to_dtype_11, mul__tensor_60, view_default_164, [768], [1, 1], [1, 1], [1, 1], False, [0, 0], 6, [True, True, True]);  to_dtype_11 = mul__tensor_60 = view_default_164 = None
        getitem_189 = convolution_backward_default_4[0]
        getitem_190 = convolution_backward_default_4[1]
        getitem_191 = convolution_backward_default_4[2];  convolution_backward_default_4 = None
        view_default_180 = torch.ops.aten.view.default(getitem_190, [1, 768, 1152]);  getitem_190 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(view_default_180, view_default_162, view_default_163, None, None, getitem_163, getitem_164, True, 1e-05, [True, True, False]);  view_default_180 = view_default_162 = view_default_163 = getitem_163 = getitem_164 = None
        getitem_192 = native_batch_norm_backward_default_2[0]
        getitem_193 = native_batch_norm_backward_default_2[1]
        getitem_194 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        view_default_181 = torch.ops.aten.view.default(getitem_193, [768, 1, 1, 1]);  getitem_193 = None
        mul_tensor_131 = torch.ops.aten.mul.Tensor(view_default_181, 0.02946278254943948);  view_default_181 = None
        view_default_182 = torch.ops.aten.view.default(getitem_192, [768, 128, 3, 3]);  getitem_192 = None
        mul_tensor_132 = torch.ops.aten.mul.Tensor(getitem_189, 1.7015043497085571);  getitem_189 = None
        to_dtype_12 = torch.ops.aten.to.dtype(mul_tensor_132, torch.float32);  mul_tensor_132 = None
        to_dtype_13 = torch.ops.aten.to.dtype(convolution_default_75, torch.float32);  convolution_default_75 = None
        mul_tensor_133 = torch.ops.aten.mul.Tensor(to_dtype_13, 0.7071067811865476)
        erf_default_2 = torch.ops.aten.erf.default(mul_tensor_133);  mul_tensor_133 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(erf_default_2, 1);  erf_default_2 = None
        mul_tensor_134 = torch.ops.aten.mul.Tensor(add_tensor_17, 0.5);  add_tensor_17 = None
        mul_tensor_135 = torch.ops.aten.mul.Tensor(to_dtype_13, to_dtype_13)
        mul_tensor_136 = torch.ops.aten.mul.Tensor(mul_tensor_135, -0.5);  mul_tensor_135 = None
        exp_default_2 = torch.ops.aten.exp.default(mul_tensor_136);  mul_tensor_136 = None
        mul_tensor_137 = torch.ops.aten.mul.Tensor(exp_default_2, 0.3989422804014327);  exp_default_2 = None
        mul_tensor_138 = torch.ops.aten.mul.Tensor(to_dtype_13, mul_tensor_137);  to_dtype_13 = mul_tensor_137 = None
        add_tensor_18 = torch.ops.aten.add.Tensor(mul_tensor_134, mul_tensor_138);  mul_tensor_134 = mul_tensor_138 = None
        mul_tensor_139 = torch.ops.aten.mul.Tensor(to_dtype_12, add_tensor_18);  to_dtype_12 = add_tensor_18 = None
        to_dtype_14 = torch.ops.aten.to.dtype(mul_tensor_139, torch.float32);  mul_tensor_139 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(to_dtype_14, mul__tensor_59, view_default_161, [768], [1, 1], [1, 1], [1, 1], False, [0, 0], 6, [True, True, True]);  to_dtype_14 = mul__tensor_59 = view_default_161 = None
        getitem_195 = convolution_backward_default_5[0]
        getitem_196 = convolution_backward_default_5[1]
        getitem_197 = convolution_backward_default_5[2];  convolution_backward_default_5 = None
        view_default_183 = torch.ops.aten.view.default(getitem_196, [1, 768, 1152]);  getitem_196 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(view_default_183, view_default_159, view_default_160, None, None, getitem_160, getitem_161, True, 1e-05, [True, True, False]);  view_default_183 = view_default_159 = view_default_160 = getitem_160 = getitem_161 = None
        getitem_198 = native_batch_norm_backward_default_3[0]
        getitem_199 = native_batch_norm_backward_default_3[1]
        getitem_200 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        view_default_184 = torch.ops.aten.view.default(getitem_199, [768, 1, 1, 1]);  getitem_199 = None
        mul_tensor_140 = torch.ops.aten.mul.Tensor(view_default_184, 0.02946278254943948);  view_default_184 = None
        view_default_185 = torch.ops.aten.view.default(getitem_198, [768, 128, 3, 3]);  getitem_198 = None
        mul_tensor_141 = torch.ops.aten.mul.Tensor(getitem_195, 1.7015043497085571);  getitem_195 = None
        to_dtype_15 = torch.ops.aten.to.dtype(mul_tensor_141, torch.float32);  mul_tensor_141 = None
        to_dtype_16 = torch.ops.aten.to.dtype(convolution_default_74, torch.float32);  convolution_default_74 = None
        mul_tensor_142 = torch.ops.aten.mul.Tensor(to_dtype_16, 0.7071067811865476)
        erf_default_3 = torch.ops.aten.erf.default(mul_tensor_142);  mul_tensor_142 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(erf_default_3, 1);  erf_default_3 = None
        mul_tensor_143 = torch.ops.aten.mul.Tensor(add_tensor_19, 0.5);  add_tensor_19 = None
        mul_tensor_144 = torch.ops.aten.mul.Tensor(to_dtype_16, to_dtype_16)
        mul_tensor_145 = torch.ops.aten.mul.Tensor(mul_tensor_144, -0.5);  mul_tensor_144 = None
        exp_default_3 = torch.ops.aten.exp.default(mul_tensor_145);  mul_tensor_145 = None
        mul_tensor_146 = torch.ops.aten.mul.Tensor(exp_default_3, 0.3989422804014327);  exp_default_3 = None
        mul_tensor_147 = torch.ops.aten.mul.Tensor(to_dtype_16, mul_tensor_146);  to_dtype_16 = mul_tensor_146 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(mul_tensor_143, mul_tensor_147);  mul_tensor_143 = mul_tensor_147 = None
        mul_tensor_148 = torch.ops.aten.mul.Tensor(to_dtype_15, add_tensor_20);  to_dtype_15 = add_tensor_20 = None
        to_dtype_17 = torch.ops.aten.to.dtype(mul_tensor_148, torch.float32);  mul_tensor_148 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(to_dtype_17, mul_tensor_96, view_default_158, [768], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_17 = mul_tensor_96 = view_default_158 = None
        getitem_201 = convolution_backward_default_6[0]
        getitem_202 = convolution_backward_default_6[1]
        getitem_203 = convolution_backward_default_6[2];  convolution_backward_default_6 = None
        view_default_186 = torch.ops.aten.view.default(getitem_202, [1, 768, 1536]);  getitem_202 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(view_default_186, view_default_156, view_default_157, None, None, getitem_157, getitem_158, True, 1e-05, [True, True, False]);  view_default_186 = view_default_156 = view_default_157 = getitem_157 = getitem_158 = None
        getitem_204 = native_batch_norm_backward_default_4[0]
        getitem_205 = native_batch_norm_backward_default_4[1]
        getitem_206 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        view_default_187 = torch.ops.aten.view.default(getitem_205, [768, 1, 1, 1]);  getitem_205 = None
        mul_tensor_149 = torch.ops.aten.mul.Tensor(view_default_187, 0.02551551815399144);  view_default_187 = None
        view_default_188 = torch.ops.aten.view.default(getitem_204, [768, 1536, 1, 1]);  getitem_204 = None
        mul_tensor_150 = torch.ops.aten.mul.Tensor(getitem_201, 0.9622504486493761);  getitem_201 = None
        mul_tensor_151 = torch.ops.aten.mul.Tensor(mul_tensor_150, 1.7015043497085571);  mul_tensor_150 = None
        to_dtype_18 = torch.ops.aten.to.dtype(mul_tensor_151, torch.float32);  mul_tensor_151 = None
        to_dtype_19 = torch.ops.aten.to.dtype(add_tensor_10, torch.float32);  add_tensor_10 = None
        mul_tensor_152 = torch.ops.aten.mul.Tensor(to_dtype_19, 0.7071067811865476)
        erf_default_4 = torch.ops.aten.erf.default(mul_tensor_152);  mul_tensor_152 = None
        add_tensor_21 = torch.ops.aten.add.Tensor(erf_default_4, 1);  erf_default_4 = None
        mul_tensor_153 = torch.ops.aten.mul.Tensor(add_tensor_21, 0.5);  add_tensor_21 = None
        mul_tensor_154 = torch.ops.aten.mul.Tensor(to_dtype_19, to_dtype_19)
        mul_tensor_155 = torch.ops.aten.mul.Tensor(mul_tensor_154, -0.5);  mul_tensor_154 = None
        exp_default_4 = torch.ops.aten.exp.default(mul_tensor_155);  mul_tensor_155 = None
        mul_tensor_156 = torch.ops.aten.mul.Tensor(exp_default_4, 0.3989422804014327);  exp_default_4 = None
        mul_tensor_157 = torch.ops.aten.mul.Tensor(to_dtype_19, mul_tensor_156);  to_dtype_19 = mul_tensor_156 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(mul_tensor_153, mul_tensor_157);  mul_tensor_153 = mul_tensor_157 = None
        mul_tensor_158 = torch.ops.aten.mul.Tensor(to_dtype_18, add_tensor_22);  to_dtype_18 = add_tensor_22 = None
        to_dtype_20 = torch.ops.aten.to.dtype(mul_tensor_158, torch.float32);  mul_tensor_158 = None
        add_tensor_23 = torch.ops.aten.add.Tensor(getitem_171, to_dtype_20);  getitem_171 = to_dtype_20 = None
        mul_tensor_159 = torch.ops.aten.mul.Tensor(add_tensor_23, 0.2)
        mul_tensor_160 = torch.ops.aten.mul.Tensor(mul_tensor_159, clone_default_10);  clone_default_10 = None
        mul_tensor_161 = torch.ops.aten.mul.Tensor(mul_tensor_159, primals_204);  mul_tensor_159 = primals_204 = None
        sum_default_1 = torch.ops.aten.sum.default(mul_tensor_160);  mul_tensor_160 = None
        mul_tensor_162 = torch.ops.aten.mul.Tensor(mul_tensor_161, 2.0);  mul_tensor_161 = None
        mul_tensor_163 = torch.ops.aten.mul.Tensor(mul_tensor_162, convolution_default_71);  convolution_default_71 = None
        mul_tensor_164 = torch.ops.aten.mul.Tensor(mul_tensor_162, sigmoid_default_10);  mul_tensor_162 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(mul_tensor_163, [2, 3], True);  mul_tensor_163 = None
        to_dtype_21 = torch.ops.aten.to.dtype(sum_dim_int_list_2, torch.float32);  sum_dim_int_list_2 = None
        to_dtype_22 = torch.ops.aten.to.dtype(sigmoid_default_10, torch.float32);  sigmoid_default_10 = None
        rsub_scalar_1 = torch.ops.aten.rsub.Scalar(to_dtype_22, 1)
        mul_tensor_165 = torch.ops.aten.mul.Tensor(to_dtype_22, rsub_scalar_1);  to_dtype_22 = rsub_scalar_1 = None
        conj_physical_default_1 = torch.ops.aten.conj_physical.default(mul_tensor_165);  mul_tensor_165 = None
        mul_tensor_166 = torch.ops.aten.mul.Tensor(to_dtype_21, conj_physical_default_1);  to_dtype_21 = conj_physical_default_1 = None
        to_dtype_23 = torch.ops.aten.to.dtype(mul_tensor_166, torch.float32);  mul_tensor_166 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(to_dtype_23, relu__default_10, primals_191, [1536], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_23 = primals_191 = None
        getitem_207 = convolution_backward_default_7[0]
        getitem_208 = convolution_backward_default_7[1]
        getitem_209 = convolution_backward_default_7[2];  convolution_backward_default_7 = None
        to_dtype_24 = torch.ops.aten.to.dtype(getitem_207, torch.float32);  getitem_207 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_1, to_dtype_24);  le_scalar_1 = new_zeros_default_1 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(to_dtype_26, mean_dim_10, primals_189, [768], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_26 = mean_dim_10 = primals_189 = None
        getitem_210 = convolution_backward_default_8[0]
        getitem_211 = convolution_backward_default_8[1]
        getitem_212 = convolution_backward_default_8[2];  convolution_backward_default_8 = None
        expand_default_2 = torch.ops.aten.expand.default(getitem_210, [128, 1536, 6, 6]);  getitem_210 = None
        div_scalar_2 = torch.ops.aten.div.Scalar(expand_default_2, 36);  expand_default_2 = None
        add_tensor_24 = torch.ops.aten.add.Tensor(mul_tensor_164, div_scalar_2);  mul_tensor_164 = div_scalar_2 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(add_tensor_24, mul__tensor_56, view_default_155, [1536], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  add_tensor_24 = mul__tensor_56 = view_default_155 = None
        getitem_213 = convolution_backward_default_9[0]
        getitem_214 = convolution_backward_default_9[1]
        getitem_215 = convolution_backward_default_9[2];  convolution_backward_default_9 = None
        view_default_189 = torch.ops.aten.view.default(getitem_214, [1, 1536, 768]);  getitem_214 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(view_default_189, view_default_153, view_default_154, None, None, getitem_154, getitem_155, True, 1e-05, [True, True, False]);  view_default_189 = view_default_153 = view_default_154 = getitem_154 = getitem_155 = None
        getitem_216 = native_batch_norm_backward_default_5[0]
        getitem_217 = native_batch_norm_backward_default_5[1]
        getitem_218 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        view_default_190 = torch.ops.aten.view.default(getitem_217, [1536, 1, 1, 1]);  getitem_217 = None
        mul_tensor_167 = torch.ops.aten.mul.Tensor(view_default_190, 0.03608439182435161);  view_default_190 = None
        view_default_191 = torch.ops.aten.view.default(getitem_216, [1536, 768, 1, 1]);  getitem_216 = None
        mul_tensor_168 = torch.ops.aten.mul.Tensor(getitem_213, 1.7015043497085571);  getitem_213 = None
        to_dtype_27 = torch.ops.aten.to.dtype(mul_tensor_168, torch.float32);  mul_tensor_168 = None
        to_dtype_28 = torch.ops.aten.to.dtype(convolution_default_70, torch.float32);  convolution_default_70 = None
        mul_tensor_169 = torch.ops.aten.mul.Tensor(to_dtype_28, 0.7071067811865476)
        erf_default_5 = torch.ops.aten.erf.default(mul_tensor_169);  mul_tensor_169 = None
        add_tensor_25 = torch.ops.aten.add.Tensor(erf_default_5, 1);  erf_default_5 = None
        mul_tensor_170 = torch.ops.aten.mul.Tensor(add_tensor_25, 0.5);  add_tensor_25 = None
        mul_tensor_171 = torch.ops.aten.mul.Tensor(to_dtype_28, to_dtype_28)
        mul_tensor_172 = torch.ops.aten.mul.Tensor(mul_tensor_171, -0.5);  mul_tensor_171 = None
        exp_default_5 = torch.ops.aten.exp.default(mul_tensor_172);  mul_tensor_172 = None
        mul_tensor_173 = torch.ops.aten.mul.Tensor(exp_default_5, 0.3989422804014327);  exp_default_5 = None
        mul_tensor_174 = torch.ops.aten.mul.Tensor(to_dtype_28, mul_tensor_173);  to_dtype_28 = mul_tensor_173 = None
        add_tensor_26 = torch.ops.aten.add.Tensor(mul_tensor_170, mul_tensor_174);  mul_tensor_170 = mul_tensor_174 = None
        mul_tensor_175 = torch.ops.aten.mul.Tensor(to_dtype_27, add_tensor_26);  to_dtype_27 = add_tensor_26 = None
        to_dtype_29 = torch.ops.aten.to.dtype(mul_tensor_175, torch.float32);  mul_tensor_175 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(to_dtype_29, mul__tensor_55, view_default_152, [768], [1, 1], [1, 1], [1, 1], False, [0, 0], 6, [True, True, True]);  to_dtype_29 = mul__tensor_55 = view_default_152 = None
        getitem_219 = convolution_backward_default_10[0]
        getitem_220 = convolution_backward_default_10[1]
        getitem_221 = convolution_backward_default_10[2];  convolution_backward_default_10 = None
        view_default_192 = torch.ops.aten.view.default(getitem_220, [1, 768, 1152]);  getitem_220 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(view_default_192, view_default_150, view_default_151, None, None, getitem_151, getitem_152, True, 1e-05, [True, True, False]);  view_default_192 = view_default_150 = view_default_151 = getitem_151 = getitem_152 = None
        getitem_222 = native_batch_norm_backward_default_6[0]
        getitem_223 = native_batch_norm_backward_default_6[1]
        getitem_224 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        view_default_193 = torch.ops.aten.view.default(getitem_223, [768, 1, 1, 1]);  getitem_223 = None
        mul_tensor_176 = torch.ops.aten.mul.Tensor(view_default_193, 0.02946278254943948);  view_default_193 = None
        view_default_194 = torch.ops.aten.view.default(getitem_222, [768, 128, 3, 3]);  getitem_222 = None
        mul_tensor_177 = torch.ops.aten.mul.Tensor(getitem_219, 1.7015043497085571);  getitem_219 = None
        to_dtype_30 = torch.ops.aten.to.dtype(mul_tensor_177, torch.float32);  mul_tensor_177 = None
        to_dtype_31 = torch.ops.aten.to.dtype(convolution_default_69, torch.float32);  convolution_default_69 = None
        mul_tensor_178 = torch.ops.aten.mul.Tensor(to_dtype_31, 0.7071067811865476)
        erf_default_6 = torch.ops.aten.erf.default(mul_tensor_178);  mul_tensor_178 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(erf_default_6, 1);  erf_default_6 = None
        mul_tensor_179 = torch.ops.aten.mul.Tensor(add_tensor_27, 0.5);  add_tensor_27 = None
        mul_tensor_180 = torch.ops.aten.mul.Tensor(to_dtype_31, to_dtype_31)
        mul_tensor_181 = torch.ops.aten.mul.Tensor(mul_tensor_180, -0.5);  mul_tensor_180 = None
        exp_default_6 = torch.ops.aten.exp.default(mul_tensor_181);  mul_tensor_181 = None
        mul_tensor_182 = torch.ops.aten.mul.Tensor(exp_default_6, 0.3989422804014327);  exp_default_6 = None
        mul_tensor_183 = torch.ops.aten.mul.Tensor(to_dtype_31, mul_tensor_182);  to_dtype_31 = mul_tensor_182 = None
        add_tensor_28 = torch.ops.aten.add.Tensor(mul_tensor_179, mul_tensor_183);  mul_tensor_179 = mul_tensor_183 = None
        mul_tensor_184 = torch.ops.aten.mul.Tensor(to_dtype_30, add_tensor_28);  to_dtype_30 = add_tensor_28 = None
        to_dtype_32 = torch.ops.aten.to.dtype(mul_tensor_184, torch.float32);  mul_tensor_184 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(to_dtype_32, mul__tensor_54, view_default_149, [768], [1, 1], [1, 1], [1, 1], False, [0, 0], 6, [True, True, True]);  to_dtype_32 = mul__tensor_54 = view_default_149 = None
        getitem_225 = convolution_backward_default_11[0]
        getitem_226 = convolution_backward_default_11[1]
        getitem_227 = convolution_backward_default_11[2];  convolution_backward_default_11 = None
        view_default_195 = torch.ops.aten.view.default(getitem_226, [1, 768, 1152]);  getitem_226 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(view_default_195, view_default_147, view_default_148, None, None, getitem_148, getitem_149, True, 1e-05, [True, True, False]);  view_default_195 = view_default_147 = view_default_148 = getitem_148 = getitem_149 = None
        getitem_228 = native_batch_norm_backward_default_7[0]
        getitem_229 = native_batch_norm_backward_default_7[1]
        getitem_230 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        view_default_196 = torch.ops.aten.view.default(getitem_229, [768, 1, 1, 1]);  getitem_229 = None
        mul_tensor_185 = torch.ops.aten.mul.Tensor(view_default_196, 0.02946278254943948);  view_default_196 = None
        view_default_197 = torch.ops.aten.view.default(getitem_228, [768, 128, 3, 3]);  getitem_228 = None
        mul_tensor_186 = torch.ops.aten.mul.Tensor(getitem_225, 1.7015043497085571);  getitem_225 = None
        to_dtype_33 = torch.ops.aten.to.dtype(mul_tensor_186, torch.float32);  mul_tensor_186 = None
        to_dtype_34 = torch.ops.aten.to.dtype(convolution_default_68, torch.float32);  convolution_default_68 = None
        mul_tensor_187 = torch.ops.aten.mul.Tensor(to_dtype_34, 0.7071067811865476)
        erf_default_7 = torch.ops.aten.erf.default(mul_tensor_187);  mul_tensor_187 = None
        add_tensor_29 = torch.ops.aten.add.Tensor(erf_default_7, 1);  erf_default_7 = None
        mul_tensor_188 = torch.ops.aten.mul.Tensor(add_tensor_29, 0.5);  add_tensor_29 = None
        mul_tensor_189 = torch.ops.aten.mul.Tensor(to_dtype_34, to_dtype_34)
        mul_tensor_190 = torch.ops.aten.mul.Tensor(mul_tensor_189, -0.5);  mul_tensor_189 = None
        exp_default_7 = torch.ops.aten.exp.default(mul_tensor_190);  mul_tensor_190 = None
        mul_tensor_191 = torch.ops.aten.mul.Tensor(exp_default_7, 0.3989422804014327);  exp_default_7 = None
        mul_tensor_192 = torch.ops.aten.mul.Tensor(to_dtype_34, mul_tensor_191);  to_dtype_34 = mul_tensor_191 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(mul_tensor_188, mul_tensor_192);  mul_tensor_188 = mul_tensor_192 = None
        mul_tensor_193 = torch.ops.aten.mul.Tensor(to_dtype_33, add_tensor_30);  to_dtype_33 = add_tensor_30 = None
        to_dtype_35 = torch.ops.aten.to.dtype(mul_tensor_193, torch.float32);  mul_tensor_193 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(to_dtype_35, mul_tensor_88, view_default_146, [768], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_35 = mul_tensor_88 = view_default_146 = None
        getitem_231 = convolution_backward_default_12[0]
        getitem_232 = convolution_backward_default_12[1]
        getitem_233 = convolution_backward_default_12[2];  convolution_backward_default_12 = None
        view_default_198 = torch.ops.aten.view.default(getitem_232, [1, 768, 1536]);  getitem_232 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(view_default_198, view_default_144, view_default_145, None, None, getitem_145, getitem_146, True, 1e-05, [True, True, False]);  view_default_198 = view_default_144 = view_default_145 = getitem_145 = getitem_146 = None
        getitem_234 = native_batch_norm_backward_default_8[0]
        getitem_235 = native_batch_norm_backward_default_8[1]
        getitem_236 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        view_default_199 = torch.ops.aten.view.default(getitem_235, [768, 1, 1, 1]);  getitem_235 = None
        mul_tensor_194 = torch.ops.aten.mul.Tensor(view_default_199, 0.02551551815399144);  view_default_199 = None
        view_default_200 = torch.ops.aten.view.default(getitem_234, [768, 1536, 1, 1]);  getitem_234 = None
        mul_tensor_195 = torch.ops.aten.mul.Tensor(getitem_231, 0.9805806756909201);  getitem_231 = None
        mul_tensor_196 = torch.ops.aten.mul.Tensor(mul_tensor_195, 1.7015043497085571);  mul_tensor_195 = None
        to_dtype_36 = torch.ops.aten.to.dtype(mul_tensor_196, torch.float32);  mul_tensor_196 = None
        to_dtype_37 = torch.ops.aten.to.dtype(add_tensor_9, torch.float32);  add_tensor_9 = None
        mul_tensor_197 = torch.ops.aten.mul.Tensor(to_dtype_37, 0.7071067811865476)
        erf_default_8 = torch.ops.aten.erf.default(mul_tensor_197);  mul_tensor_197 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(erf_default_8, 1);  erf_default_8 = None
        mul_tensor_198 = torch.ops.aten.mul.Tensor(add_tensor_31, 0.5);  add_tensor_31 = None
        mul_tensor_199 = torch.ops.aten.mul.Tensor(to_dtype_37, to_dtype_37)
        mul_tensor_200 = torch.ops.aten.mul.Tensor(mul_tensor_199, -0.5);  mul_tensor_199 = None
        exp_default_8 = torch.ops.aten.exp.default(mul_tensor_200);  mul_tensor_200 = None
        mul_tensor_201 = torch.ops.aten.mul.Tensor(exp_default_8, 0.3989422804014327);  exp_default_8 = None
        mul_tensor_202 = torch.ops.aten.mul.Tensor(to_dtype_37, mul_tensor_201);  to_dtype_37 = mul_tensor_201 = None
        add_tensor_32 = torch.ops.aten.add.Tensor(mul_tensor_198, mul_tensor_202);  mul_tensor_198 = mul_tensor_202 = None
        mul_tensor_203 = torch.ops.aten.mul.Tensor(to_dtype_36, add_tensor_32);  to_dtype_36 = add_tensor_32 = None
        to_dtype_38 = torch.ops.aten.to.dtype(mul_tensor_203, torch.float32);  mul_tensor_203 = None
        add_tensor_33 = torch.ops.aten.add.Tensor(add_tensor_23, to_dtype_38);  add_tensor_23 = to_dtype_38 = None
        mul_tensor_204 = torch.ops.aten.mul.Tensor(add_tensor_33, 0.2)
        mul_tensor_205 = torch.ops.aten.mul.Tensor(mul_tensor_204, clone_default_9);  clone_default_9 = None
        mul_tensor_206 = torch.ops.aten.mul.Tensor(mul_tensor_204, primals_187);  mul_tensor_204 = primals_187 = None
        sum_default_2 = torch.ops.aten.sum.default(mul_tensor_205);  mul_tensor_205 = None
        mul_tensor_207 = torch.ops.aten.mul.Tensor(mul_tensor_206, 2.0);  mul_tensor_206 = None
        mul_tensor_208 = torch.ops.aten.mul.Tensor(mul_tensor_207, convolution_default_65);  convolution_default_65 = None
        mul_tensor_209 = torch.ops.aten.mul.Tensor(mul_tensor_207, sigmoid_default_9);  mul_tensor_207 = None
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(mul_tensor_208, [2, 3], True);  mul_tensor_208 = None
        to_dtype_39 = torch.ops.aten.to.dtype(sum_dim_int_list_3, torch.float32);  sum_dim_int_list_3 = None
        to_dtype_40 = torch.ops.aten.to.dtype(sigmoid_default_9, torch.float32);  sigmoid_default_9 = None
        rsub_scalar_2 = torch.ops.aten.rsub.Scalar(to_dtype_40, 1)
        mul_tensor_210 = torch.ops.aten.mul.Tensor(to_dtype_40, rsub_scalar_2);  to_dtype_40 = rsub_scalar_2 = None
        conj_physical_default_2 = torch.ops.aten.conj_physical.default(mul_tensor_210);  mul_tensor_210 = None
        mul_tensor_211 = torch.ops.aten.mul.Tensor(to_dtype_39, conj_physical_default_2);  to_dtype_39 = conj_physical_default_2 = None
        to_dtype_41 = torch.ops.aten.to.dtype(mul_tensor_211, torch.float32);  mul_tensor_211 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(to_dtype_41, relu__default_9, primals_171, [1536], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_41 = primals_171 = None
        getitem_237 = convolution_backward_default_13[0]
        getitem_238 = convolution_backward_default_13[1]
        getitem_239 = convolution_backward_default_13[2];  convolution_backward_default_13 = None
        to_dtype_42 = torch.ops.aten.to.dtype(getitem_237, torch.float32);  getitem_237 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_2 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_2, to_dtype_42);  le_scalar_2 = new_zeros_default_2 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(to_dtype_44, mean_dim_9, primals_169, [768], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_44 = mean_dim_9 = primals_169 = None
        getitem_240 = convolution_backward_default_14[0]
        getitem_241 = convolution_backward_default_14[1]
        getitem_242 = convolution_backward_default_14[2];  convolution_backward_default_14 = None
        expand_default_3 = torch.ops.aten.expand.default(getitem_240, [128, 1536, 6, 6]);  getitem_240 = None
        div_scalar_3 = torch.ops.aten.div.Scalar(expand_default_3, 36);  expand_default_3 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(mul_tensor_209, div_scalar_3);  mul_tensor_209 = div_scalar_3 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(add_tensor_34, mul__tensor_51, view_default_143, [1536], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  add_tensor_34 = mul__tensor_51 = view_default_143 = None
        getitem_243 = convolution_backward_default_15[0]
        getitem_244 = convolution_backward_default_15[1]
        getitem_245 = convolution_backward_default_15[2];  convolution_backward_default_15 = None
        view_default_201 = torch.ops.aten.view.default(getitem_244, [1, 1536, 768]);  getitem_244 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(view_default_201, view_default_141, view_default_142, None, None, getitem_142, getitem_143, True, 1e-05, [True, True, False]);  view_default_201 = view_default_141 = view_default_142 = getitem_142 = getitem_143 = None
        getitem_246 = native_batch_norm_backward_default_9[0]
        getitem_247 = native_batch_norm_backward_default_9[1]
        getitem_248 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        view_default_202 = torch.ops.aten.view.default(getitem_247, [1536, 1, 1, 1]);  getitem_247 = None
        mul_tensor_212 = torch.ops.aten.mul.Tensor(view_default_202, 0.03608439182435161);  view_default_202 = None
        view_default_203 = torch.ops.aten.view.default(getitem_246, [1536, 768, 1, 1]);  getitem_246 = None
        mul_tensor_213 = torch.ops.aten.mul.Tensor(getitem_243, 1.7015043497085571);  getitem_243 = None
        to_dtype_45 = torch.ops.aten.to.dtype(mul_tensor_213, torch.float32);  mul_tensor_213 = None
        to_dtype_46 = torch.ops.aten.to.dtype(convolution_default_64, torch.float32);  convolution_default_64 = None
        mul_tensor_214 = torch.ops.aten.mul.Tensor(to_dtype_46, 0.7071067811865476)
        erf_default_9 = torch.ops.aten.erf.default(mul_tensor_214);  mul_tensor_214 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(erf_default_9, 1);  erf_default_9 = None
        mul_tensor_215 = torch.ops.aten.mul.Tensor(add_tensor_35, 0.5);  add_tensor_35 = None
        mul_tensor_216 = torch.ops.aten.mul.Tensor(to_dtype_46, to_dtype_46)
        mul_tensor_217 = torch.ops.aten.mul.Tensor(mul_tensor_216, -0.5);  mul_tensor_216 = None
        exp_default_9 = torch.ops.aten.exp.default(mul_tensor_217);  mul_tensor_217 = None
        mul_tensor_218 = torch.ops.aten.mul.Tensor(exp_default_9, 0.3989422804014327);  exp_default_9 = None
        mul_tensor_219 = torch.ops.aten.mul.Tensor(to_dtype_46, mul_tensor_218);  to_dtype_46 = mul_tensor_218 = None
        add_tensor_36 = torch.ops.aten.add.Tensor(mul_tensor_215, mul_tensor_219);  mul_tensor_215 = mul_tensor_219 = None
        mul_tensor_220 = torch.ops.aten.mul.Tensor(to_dtype_45, add_tensor_36);  to_dtype_45 = add_tensor_36 = None
        to_dtype_47 = torch.ops.aten.to.dtype(mul_tensor_220, torch.float32);  mul_tensor_220 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(to_dtype_47, mul__tensor_50, view_default_140, [768], [1, 1], [1, 1], [1, 1], False, [0, 0], 6, [True, True, True]);  to_dtype_47 = mul__tensor_50 = view_default_140 = None
        getitem_249 = convolution_backward_default_16[0]
        getitem_250 = convolution_backward_default_16[1]
        getitem_251 = convolution_backward_default_16[2];  convolution_backward_default_16 = None
        view_default_204 = torch.ops.aten.view.default(getitem_250, [1, 768, 1152]);  getitem_250 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(view_default_204, view_default_138, view_default_139, None, None, getitem_139, getitem_140, True, 1e-05, [True, True, False]);  view_default_204 = view_default_138 = view_default_139 = getitem_139 = getitem_140 = None
        getitem_252 = native_batch_norm_backward_default_10[0]
        getitem_253 = native_batch_norm_backward_default_10[1]
        getitem_254 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        view_default_205 = torch.ops.aten.view.default(getitem_253, [768, 1, 1, 1]);  getitem_253 = None
        mul_tensor_221 = torch.ops.aten.mul.Tensor(view_default_205, 0.02946278254943948);  view_default_205 = None
        view_default_206 = torch.ops.aten.view.default(getitem_252, [768, 128, 3, 3]);  getitem_252 = None
        mul_tensor_222 = torch.ops.aten.mul.Tensor(getitem_249, 1.7015043497085571);  getitem_249 = None
        to_dtype_48 = torch.ops.aten.to.dtype(mul_tensor_222, torch.float32);  mul_tensor_222 = None
        to_dtype_49 = torch.ops.aten.to.dtype(convolution_default_63, torch.float32);  convolution_default_63 = None
        mul_tensor_223 = torch.ops.aten.mul.Tensor(to_dtype_49, 0.7071067811865476)
        erf_default_10 = torch.ops.aten.erf.default(mul_tensor_223);  mul_tensor_223 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(erf_default_10, 1);  erf_default_10 = None
        mul_tensor_224 = torch.ops.aten.mul.Tensor(add_tensor_37, 0.5);  add_tensor_37 = None
        mul_tensor_225 = torch.ops.aten.mul.Tensor(to_dtype_49, to_dtype_49)
        mul_tensor_226 = torch.ops.aten.mul.Tensor(mul_tensor_225, -0.5);  mul_tensor_225 = None
        exp_default_10 = torch.ops.aten.exp.default(mul_tensor_226);  mul_tensor_226 = None
        mul_tensor_227 = torch.ops.aten.mul.Tensor(exp_default_10, 0.3989422804014327);  exp_default_10 = None
        mul_tensor_228 = torch.ops.aten.mul.Tensor(to_dtype_49, mul_tensor_227);  to_dtype_49 = mul_tensor_227 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(mul_tensor_224, mul_tensor_228);  mul_tensor_224 = mul_tensor_228 = None
        mul_tensor_229 = torch.ops.aten.mul.Tensor(to_dtype_48, add_tensor_38);  to_dtype_48 = add_tensor_38 = None
        to_dtype_50 = torch.ops.aten.to.dtype(mul_tensor_229, torch.float32);  mul_tensor_229 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(to_dtype_50, constant_pad_nd_default_4, view_default_137, [768], [2, 2], [0, 0], [1, 1], False, [0, 0], 6, [True, True, True]);  to_dtype_50 = constant_pad_nd_default_4 = view_default_137 = None
        getitem_255 = convolution_backward_default_17[0]
        getitem_256 = convolution_backward_default_17[1]
        getitem_257 = convolution_backward_default_17[2];  convolution_backward_default_17 = None
        view_default_207 = torch.ops.aten.view.default(getitem_256, [1, 768, 1152]);  getitem_256 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(view_default_207, view_default_135, view_default_136, None, None, getitem_136, getitem_137, True, 1e-05, [True, True, False]);  view_default_207 = view_default_135 = view_default_136 = getitem_136 = getitem_137 = None
        getitem_258 = native_batch_norm_backward_default_11[0]
        getitem_259 = native_batch_norm_backward_default_11[1]
        getitem_260 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        view_default_208 = torch.ops.aten.view.default(getitem_259, [768, 1, 1, 1]);  getitem_259 = None
        mul_tensor_230 = torch.ops.aten.mul.Tensor(view_default_208, 0.02946278254943948);  view_default_208 = None
        view_default_209 = torch.ops.aten.view.default(getitem_258, [768, 128, 3, 3]);  getitem_258 = None
        constant_pad_nd_default_5 = torch.ops.aten.constant_pad_nd.default(getitem_255, [0, -1, 0, -1]);  getitem_255 = None
        mul_tensor_231 = torch.ops.aten.mul.Tensor(constant_pad_nd_default_5, 1.7015043497085571);  constant_pad_nd_default_5 = None
        to_dtype_51 = torch.ops.aten.to.dtype(mul_tensor_231, torch.float32);  mul_tensor_231 = None
        to_dtype_52 = torch.ops.aten.to.dtype(convolution_default_62, torch.float32);  convolution_default_62 = None
        mul_tensor_232 = torch.ops.aten.mul.Tensor(to_dtype_52, 0.7071067811865476)
        erf_default_11 = torch.ops.aten.erf.default(mul_tensor_232);  mul_tensor_232 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(erf_default_11, 1);  erf_default_11 = None
        mul_tensor_233 = torch.ops.aten.mul.Tensor(add_tensor_39, 0.5);  add_tensor_39 = None
        mul_tensor_234 = torch.ops.aten.mul.Tensor(to_dtype_52, to_dtype_52)
        mul_tensor_235 = torch.ops.aten.mul.Tensor(mul_tensor_234, -0.5);  mul_tensor_234 = None
        exp_default_11 = torch.ops.aten.exp.default(mul_tensor_235);  mul_tensor_235 = None
        mul_tensor_236 = torch.ops.aten.mul.Tensor(exp_default_11, 0.3989422804014327);  exp_default_11 = None
        mul_tensor_237 = torch.ops.aten.mul.Tensor(to_dtype_52, mul_tensor_236);  to_dtype_52 = mul_tensor_236 = None
        add_tensor_40 = torch.ops.aten.add.Tensor(mul_tensor_233, mul_tensor_237);  mul_tensor_233 = mul_tensor_237 = None
        mul_tensor_238 = torch.ops.aten.mul.Tensor(to_dtype_51, add_tensor_40);  to_dtype_51 = add_tensor_40 = None
        to_dtype_53 = torch.ops.aten.to.dtype(mul_tensor_238, torch.float32);  mul_tensor_238 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(to_dtype_53, mul_tensor_79, view_default_134, [768], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_53 = view_default_134 = None
        getitem_261 = convolution_backward_default_18[0]
        getitem_262 = convolution_backward_default_18[1]
        getitem_263 = convolution_backward_default_18[2];  convolution_backward_default_18 = None
        view_default_210 = torch.ops.aten.view.default(getitem_262, [1, 768, 1536]);  getitem_262 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(view_default_210, view_default_132, view_default_133, None, None, getitem_133, getitem_134, True, 1e-05, [True, True, False]);  view_default_210 = view_default_132 = view_default_133 = getitem_133 = getitem_134 = None
        getitem_264 = native_batch_norm_backward_default_12[0]
        getitem_265 = native_batch_norm_backward_default_12[1]
        getitem_266 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        view_default_211 = torch.ops.aten.view.default(getitem_265, [768, 1, 1, 1]);  getitem_265 = None
        mul_tensor_239 = torch.ops.aten.mul.Tensor(view_default_211, 0.02551551815399144);  view_default_211 = None
        view_default_212 = torch.ops.aten.view.default(getitem_264, [768, 1536, 1, 1]);  getitem_264 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(add_tensor_33, avg_pool2d_default_2, view_default_131, [1536], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  add_tensor_33 = avg_pool2d_default_2 = view_default_131 = None
        getitem_267 = convolution_backward_default_19[0]
        getitem_268 = convolution_backward_default_19[1]
        getitem_269 = convolution_backward_default_19[2];  convolution_backward_default_19 = None
        view_default_213 = torch.ops.aten.view.default(getitem_268, [1, 1536, 1536]);  getitem_268 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(view_default_213, view_default_129, view_default_130, None, None, getitem_130, getitem_131, True, 1e-05, [True, True, False]);  view_default_213 = view_default_129 = view_default_130 = getitem_130 = getitem_131 = None
        getitem_270 = native_batch_norm_backward_default_13[0]
        getitem_271 = native_batch_norm_backward_default_13[1]
        getitem_272 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        view_default_214 = torch.ops.aten.view.default(getitem_271, [1536, 1, 1, 1]);  getitem_271 = None
        mul_tensor_240 = torch.ops.aten.mul.Tensor(view_default_214, 0.02551551815399144);  view_default_214 = None
        view_default_215 = torch.ops.aten.view.default(getitem_270, [1536, 1536, 1, 1]);  getitem_270 = None
        avg_pool2d_backward_default = torch.ops.aten.avg_pool2d_backward.default(getitem_267, mul_tensor_79, [2, 2], [2, 2], [0, 0], True, False, None);  getitem_267 = mul_tensor_79 = None
        add_tensor_41 = torch.ops.aten.add.Tensor(getitem_261, avg_pool2d_backward_default);  getitem_261 = avg_pool2d_backward_default = None
        mul_tensor_241 = torch.ops.aten.mul.Tensor(add_tensor_41, 0.8980265101338745);  add_tensor_41 = None
        mul_tensor_242 = torch.ops.aten.mul.Tensor(mul_tensor_241, 1.7015043497085571);  mul_tensor_241 = None
        to_dtype_54 = torch.ops.aten.to.dtype(mul_tensor_242, torch.float32);  mul_tensor_242 = None
        to_dtype_55 = torch.ops.aten.to.dtype(add_tensor_8, torch.float32);  add_tensor_8 = None
        mul_tensor_243 = torch.ops.aten.mul.Tensor(to_dtype_55, 0.7071067811865476)
        erf_default_12 = torch.ops.aten.erf.default(mul_tensor_243);  mul_tensor_243 = None
        add_tensor_42 = torch.ops.aten.add.Tensor(erf_default_12, 1);  erf_default_12 = None
        mul_tensor_244 = torch.ops.aten.mul.Tensor(add_tensor_42, 0.5);  add_tensor_42 = None
        mul_tensor_245 = torch.ops.aten.mul.Tensor(to_dtype_55, to_dtype_55)
        mul_tensor_246 = torch.ops.aten.mul.Tensor(mul_tensor_245, -0.5);  mul_tensor_245 = None
        exp_default_12 = torch.ops.aten.exp.default(mul_tensor_246);  mul_tensor_246 = None
        mul_tensor_247 = torch.ops.aten.mul.Tensor(exp_default_12, 0.3989422804014327);  exp_default_12 = None
        mul_tensor_248 = torch.ops.aten.mul.Tensor(to_dtype_55, mul_tensor_247);  to_dtype_55 = mul_tensor_247 = None
        add_tensor_43 = torch.ops.aten.add.Tensor(mul_tensor_244, mul_tensor_248);  mul_tensor_244 = mul_tensor_248 = None
        mul_tensor_249 = torch.ops.aten.mul.Tensor(to_dtype_54, add_tensor_43);  to_dtype_54 = add_tensor_43 = None
        to_dtype_56 = torch.ops.aten.to.dtype(mul_tensor_249, torch.float32);  mul_tensor_249 = None
        mul_tensor_250 = torch.ops.aten.mul.Tensor(to_dtype_56, 0.2)
        mul_tensor_251 = torch.ops.aten.mul.Tensor(mul_tensor_250, clone_default_8);  clone_default_8 = None
        mul_tensor_252 = torch.ops.aten.mul.Tensor(mul_tensor_250, primals_167);  mul_tensor_250 = primals_167 = None
        sum_default_3 = torch.ops.aten.sum.default(mul_tensor_251);  mul_tensor_251 = None
        mul_tensor_253 = torch.ops.aten.mul.Tensor(mul_tensor_252, 2.0);  mul_tensor_252 = None
        mul_tensor_254 = torch.ops.aten.mul.Tensor(mul_tensor_253, convolution_default_58);  convolution_default_58 = None
        mul_tensor_255 = torch.ops.aten.mul.Tensor(mul_tensor_253, sigmoid_default_8);  mul_tensor_253 = None
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(mul_tensor_254, [2, 3], True);  mul_tensor_254 = None
        to_dtype_57 = torch.ops.aten.to.dtype(sum_dim_int_list_4, torch.float32);  sum_dim_int_list_4 = None
        to_dtype_58 = torch.ops.aten.to.dtype(sigmoid_default_8, torch.float32);  sigmoid_default_8 = None
        rsub_scalar_3 = torch.ops.aten.rsub.Scalar(to_dtype_58, 1)
        mul_tensor_256 = torch.ops.aten.mul.Tensor(to_dtype_58, rsub_scalar_3);  to_dtype_58 = rsub_scalar_3 = None
        conj_physical_default_3 = torch.ops.aten.conj_physical.default(mul_tensor_256);  mul_tensor_256 = None
        mul_tensor_257 = torch.ops.aten.mul.Tensor(to_dtype_57, conj_physical_default_3);  to_dtype_57 = conj_physical_default_3 = None
        to_dtype_59 = torch.ops.aten.to.dtype(mul_tensor_257, torch.float32);  mul_tensor_257 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(to_dtype_59, relu__default_8, primals_154, [1536], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_59 = primals_154 = None
        getitem_273 = convolution_backward_default_20[0]
        getitem_274 = convolution_backward_default_20[1]
        getitem_275 = convolution_backward_default_20[2];  convolution_backward_default_20 = None
        to_dtype_60 = torch.ops.aten.to.dtype(getitem_273, torch.float32);  getitem_273 = None
        to_dtype_61 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_61, 0);  to_dtype_61 = None
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(to_dtype_60, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_3, to_dtype_60);  le_scalar_3 = new_zeros_default_3 = to_dtype_60 = None
        to_dtype_62 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(to_dtype_62, mean_dim_8, primals_152, [768], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_62 = mean_dim_8 = primals_152 = None
        getitem_276 = convolution_backward_default_21[0]
        getitem_277 = convolution_backward_default_21[1]
        getitem_278 = convolution_backward_default_21[2];  convolution_backward_default_21 = None
        expand_default_4 = torch.ops.aten.expand.default(getitem_276, [128, 1536, 12, 12]);  getitem_276 = None
        div_scalar_4 = torch.ops.aten.div.Scalar(expand_default_4, 144);  expand_default_4 = None
        add_tensor_44 = torch.ops.aten.add.Tensor(mul_tensor_255, div_scalar_4);  mul_tensor_255 = div_scalar_4 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(add_tensor_44, mul__tensor_46, view_default_128, [1536], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  add_tensor_44 = mul__tensor_46 = view_default_128 = None
        getitem_279 = convolution_backward_default_22[0]
        getitem_280 = convolution_backward_default_22[1]
        getitem_281 = convolution_backward_default_22[2];  convolution_backward_default_22 = None
        view_default_216 = torch.ops.aten.view.default(getitem_280, [1, 1536, 768]);  getitem_280 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(view_default_216, view_default_126, view_default_127, None, None, getitem_127, getitem_128, True, 1e-05, [True, True, False]);  view_default_216 = view_default_126 = view_default_127 = getitem_127 = getitem_128 = None
        getitem_282 = native_batch_norm_backward_default_14[0]
        getitem_283 = native_batch_norm_backward_default_14[1]
        getitem_284 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        view_default_217 = torch.ops.aten.view.default(getitem_283, [1536, 1, 1, 1]);  getitem_283 = None
        mul_tensor_258 = torch.ops.aten.mul.Tensor(view_default_217, 0.03608439182435161);  view_default_217 = None
        view_default_218 = torch.ops.aten.view.default(getitem_282, [1536, 768, 1, 1]);  getitem_282 = None
        mul_tensor_259 = torch.ops.aten.mul.Tensor(getitem_279, 1.7015043497085571);  getitem_279 = None
        to_dtype_63 = torch.ops.aten.to.dtype(mul_tensor_259, torch.float32);  mul_tensor_259 = None
        to_dtype_64 = torch.ops.aten.to.dtype(convolution_default_57, torch.float32);  convolution_default_57 = None
        mul_tensor_260 = torch.ops.aten.mul.Tensor(to_dtype_64, 0.7071067811865476)
        erf_default_13 = torch.ops.aten.erf.default(mul_tensor_260);  mul_tensor_260 = None
        add_tensor_45 = torch.ops.aten.add.Tensor(erf_default_13, 1);  erf_default_13 = None
        mul_tensor_261 = torch.ops.aten.mul.Tensor(add_tensor_45, 0.5);  add_tensor_45 = None
        mul_tensor_262 = torch.ops.aten.mul.Tensor(to_dtype_64, to_dtype_64)
        mul_tensor_263 = torch.ops.aten.mul.Tensor(mul_tensor_262, -0.5);  mul_tensor_262 = None
        exp_default_13 = torch.ops.aten.exp.default(mul_tensor_263);  mul_tensor_263 = None
        mul_tensor_264 = torch.ops.aten.mul.Tensor(exp_default_13, 0.3989422804014327);  exp_default_13 = None
        mul_tensor_265 = torch.ops.aten.mul.Tensor(to_dtype_64, mul_tensor_264);  to_dtype_64 = mul_tensor_264 = None
        add_tensor_46 = torch.ops.aten.add.Tensor(mul_tensor_261, mul_tensor_265);  mul_tensor_261 = mul_tensor_265 = None
        mul_tensor_266 = torch.ops.aten.mul.Tensor(to_dtype_63, add_tensor_46);  to_dtype_63 = add_tensor_46 = None
        to_dtype_65 = torch.ops.aten.to.dtype(mul_tensor_266, torch.float32);  mul_tensor_266 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(to_dtype_65, mul__tensor_45, view_default_125, [768], [1, 1], [1, 1], [1, 1], False, [0, 0], 6, [True, True, True]);  to_dtype_65 = mul__tensor_45 = view_default_125 = None
        getitem_285 = convolution_backward_default_23[0]
        getitem_286 = convolution_backward_default_23[1]
        getitem_287 = convolution_backward_default_23[2];  convolution_backward_default_23 = None
        view_default_219 = torch.ops.aten.view.default(getitem_286, [1, 768, 1152]);  getitem_286 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(view_default_219, view_default_123, view_default_124, None, None, getitem_124, getitem_125, True, 1e-05, [True, True, False]);  view_default_219 = view_default_123 = view_default_124 = getitem_124 = getitem_125 = None
        getitem_288 = native_batch_norm_backward_default_15[0]
        getitem_289 = native_batch_norm_backward_default_15[1]
        getitem_290 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        view_default_220 = torch.ops.aten.view.default(getitem_289, [768, 1, 1, 1]);  getitem_289 = None
        mul_tensor_267 = torch.ops.aten.mul.Tensor(view_default_220, 0.02946278254943948);  view_default_220 = None
        view_default_221 = torch.ops.aten.view.default(getitem_288, [768, 128, 3, 3]);  getitem_288 = None
        mul_tensor_268 = torch.ops.aten.mul.Tensor(getitem_285, 1.7015043497085571);  getitem_285 = None
        to_dtype_66 = torch.ops.aten.to.dtype(mul_tensor_268, torch.float32);  mul_tensor_268 = None
        to_dtype_67 = torch.ops.aten.to.dtype(convolution_default_56, torch.float32);  convolution_default_56 = None
        mul_tensor_269 = torch.ops.aten.mul.Tensor(to_dtype_67, 0.7071067811865476)
        erf_default_14 = torch.ops.aten.erf.default(mul_tensor_269);  mul_tensor_269 = None
        add_tensor_47 = torch.ops.aten.add.Tensor(erf_default_14, 1);  erf_default_14 = None
        mul_tensor_270 = torch.ops.aten.mul.Tensor(add_tensor_47, 0.5);  add_tensor_47 = None
        mul_tensor_271 = torch.ops.aten.mul.Tensor(to_dtype_67, to_dtype_67)
        mul_tensor_272 = torch.ops.aten.mul.Tensor(mul_tensor_271, -0.5);  mul_tensor_271 = None
        exp_default_14 = torch.ops.aten.exp.default(mul_tensor_272);  mul_tensor_272 = None
        mul_tensor_273 = torch.ops.aten.mul.Tensor(exp_default_14, 0.3989422804014327);  exp_default_14 = None
        mul_tensor_274 = torch.ops.aten.mul.Tensor(to_dtype_67, mul_tensor_273);  to_dtype_67 = mul_tensor_273 = None
        add_tensor_48 = torch.ops.aten.add.Tensor(mul_tensor_270, mul_tensor_274);  mul_tensor_270 = mul_tensor_274 = None
        mul_tensor_275 = torch.ops.aten.mul.Tensor(to_dtype_66, add_tensor_48);  to_dtype_66 = add_tensor_48 = None
        to_dtype_68 = torch.ops.aten.to.dtype(mul_tensor_275, torch.float32);  mul_tensor_275 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(to_dtype_68, mul__tensor_44, view_default_122, [768], [1, 1], [1, 1], [1, 1], False, [0, 0], 6, [True, True, True]);  to_dtype_68 = mul__tensor_44 = view_default_122 = None
        getitem_291 = convolution_backward_default_24[0]
        getitem_292 = convolution_backward_default_24[1]
        getitem_293 = convolution_backward_default_24[2];  convolution_backward_default_24 = None
        view_default_222 = torch.ops.aten.view.default(getitem_292, [1, 768, 1152]);  getitem_292 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(view_default_222, view_default_120, view_default_121, None, None, getitem_121, getitem_122, True, 1e-05, [True, True, False]);  view_default_222 = view_default_120 = view_default_121 = getitem_121 = getitem_122 = None
        getitem_294 = native_batch_norm_backward_default_16[0]
        getitem_295 = native_batch_norm_backward_default_16[1]
        getitem_296 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        view_default_223 = torch.ops.aten.view.default(getitem_295, [768, 1, 1, 1]);  getitem_295 = None
        mul_tensor_276 = torch.ops.aten.mul.Tensor(view_default_223, 0.02946278254943948);  view_default_223 = None
        view_default_224 = torch.ops.aten.view.default(getitem_294, [768, 128, 3, 3]);  getitem_294 = None
        mul_tensor_277 = torch.ops.aten.mul.Tensor(getitem_291, 1.7015043497085571);  getitem_291 = None
        to_dtype_69 = torch.ops.aten.to.dtype(mul_tensor_277, torch.float32);  mul_tensor_277 = None
        to_dtype_70 = torch.ops.aten.to.dtype(convolution_default_55, torch.float32);  convolution_default_55 = None
        mul_tensor_278 = torch.ops.aten.mul.Tensor(to_dtype_70, 0.7071067811865476)
        erf_default_15 = torch.ops.aten.erf.default(mul_tensor_278);  mul_tensor_278 = None
        add_tensor_49 = torch.ops.aten.add.Tensor(erf_default_15, 1);  erf_default_15 = None
        mul_tensor_279 = torch.ops.aten.mul.Tensor(add_tensor_49, 0.5);  add_tensor_49 = None
        mul_tensor_280 = torch.ops.aten.mul.Tensor(to_dtype_70, to_dtype_70)
        mul_tensor_281 = torch.ops.aten.mul.Tensor(mul_tensor_280, -0.5);  mul_tensor_280 = None
        exp_default_15 = torch.ops.aten.exp.default(mul_tensor_281);  mul_tensor_281 = None
        mul_tensor_282 = torch.ops.aten.mul.Tensor(exp_default_15, 0.3989422804014327);  exp_default_15 = None
        mul_tensor_283 = torch.ops.aten.mul.Tensor(to_dtype_70, mul_tensor_282);  to_dtype_70 = mul_tensor_282 = None
        add_tensor_50 = torch.ops.aten.add.Tensor(mul_tensor_279, mul_tensor_283);  mul_tensor_279 = mul_tensor_283 = None
        mul_tensor_284 = torch.ops.aten.mul.Tensor(to_dtype_69, add_tensor_50);  to_dtype_69 = add_tensor_50 = None
        to_dtype_71 = torch.ops.aten.to.dtype(mul_tensor_284, torch.float32);  mul_tensor_284 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(to_dtype_71, mul_tensor_71, view_default_119, [768], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_71 = mul_tensor_71 = view_default_119 = None
        getitem_297 = convolution_backward_default_25[0]
        getitem_298 = convolution_backward_default_25[1]
        getitem_299 = convolution_backward_default_25[2];  convolution_backward_default_25 = None
        view_default_225 = torch.ops.aten.view.default(getitem_298, [1, 768, 1536]);  getitem_298 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(view_default_225, view_default_117, view_default_118, None, None, getitem_118, getitem_119, True, 1e-05, [True, True, False]);  view_default_225 = view_default_117 = view_default_118 = getitem_118 = getitem_119 = None
        getitem_300 = native_batch_norm_backward_default_17[0]
        getitem_301 = native_batch_norm_backward_default_17[1]
        getitem_302 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        view_default_226 = torch.ops.aten.view.default(getitem_301, [768, 1, 1, 1]);  getitem_301 = None
        mul_tensor_285 = torch.ops.aten.mul.Tensor(view_default_226, 0.02551551815399144);  view_default_226 = None
        view_default_227 = torch.ops.aten.view.default(getitem_300, [768, 1536, 1, 1]);  getitem_300 = None
        mul_tensor_286 = torch.ops.aten.mul.Tensor(getitem_297, 0.9128709291752768);  getitem_297 = None
        mul_tensor_287 = torch.ops.aten.mul.Tensor(mul_tensor_286, 1.7015043497085571);  mul_tensor_286 = None
        to_dtype_72 = torch.ops.aten.to.dtype(mul_tensor_287, torch.float32);  mul_tensor_287 = None
        to_dtype_73 = torch.ops.aten.to.dtype(add_tensor_7, torch.float32);  add_tensor_7 = None
        mul_tensor_288 = torch.ops.aten.mul.Tensor(to_dtype_73, 0.7071067811865476)
        erf_default_16 = torch.ops.aten.erf.default(mul_tensor_288);  mul_tensor_288 = None
        add_tensor_51 = torch.ops.aten.add.Tensor(erf_default_16, 1);  erf_default_16 = None
        mul_tensor_289 = torch.ops.aten.mul.Tensor(add_tensor_51, 0.5);  add_tensor_51 = None
        mul_tensor_290 = torch.ops.aten.mul.Tensor(to_dtype_73, to_dtype_73)
        mul_tensor_291 = torch.ops.aten.mul.Tensor(mul_tensor_290, -0.5);  mul_tensor_290 = None
        exp_default_16 = torch.ops.aten.exp.default(mul_tensor_291);  mul_tensor_291 = None
        mul_tensor_292 = torch.ops.aten.mul.Tensor(exp_default_16, 0.3989422804014327);  exp_default_16 = None
        mul_tensor_293 = torch.ops.aten.mul.Tensor(to_dtype_73, mul_tensor_292);  to_dtype_73 = mul_tensor_292 = None
        add_tensor_52 = torch.ops.aten.add.Tensor(mul_tensor_289, mul_tensor_293);  mul_tensor_289 = mul_tensor_293 = None
        mul_tensor_294 = torch.ops.aten.mul.Tensor(to_dtype_72, add_tensor_52);  to_dtype_72 = add_tensor_52 = None
        to_dtype_74 = torch.ops.aten.to.dtype(mul_tensor_294, torch.float32);  mul_tensor_294 = None
        add_tensor_53 = torch.ops.aten.add.Tensor(to_dtype_56, to_dtype_74);  to_dtype_56 = to_dtype_74 = None
        mul_tensor_295 = torch.ops.aten.mul.Tensor(add_tensor_53, 0.2)
        mul_tensor_296 = torch.ops.aten.mul.Tensor(mul_tensor_295, clone_default_7);  clone_default_7 = None
        mul_tensor_297 = torch.ops.aten.mul.Tensor(mul_tensor_295, primals_150);  mul_tensor_295 = primals_150 = None
        sum_default_4 = torch.ops.aten.sum.default(mul_tensor_296);  mul_tensor_296 = None
        mul_tensor_298 = torch.ops.aten.mul.Tensor(mul_tensor_297, 2.0);  mul_tensor_297 = None
        mul_tensor_299 = torch.ops.aten.mul.Tensor(mul_tensor_298, convolution_default_52);  convolution_default_52 = None
        mul_tensor_300 = torch.ops.aten.mul.Tensor(mul_tensor_298, sigmoid_default_7);  mul_tensor_298 = None
        sum_dim_int_list_5 = torch.ops.aten.sum.dim_IntList(mul_tensor_299, [2, 3], True);  mul_tensor_299 = None
        to_dtype_75 = torch.ops.aten.to.dtype(sum_dim_int_list_5, torch.float32);  sum_dim_int_list_5 = None
        to_dtype_76 = torch.ops.aten.to.dtype(sigmoid_default_7, torch.float32);  sigmoid_default_7 = None
        rsub_scalar_4 = torch.ops.aten.rsub.Scalar(to_dtype_76, 1)
        mul_tensor_301 = torch.ops.aten.mul.Tensor(to_dtype_76, rsub_scalar_4);  to_dtype_76 = rsub_scalar_4 = None
        conj_physical_default_4 = torch.ops.aten.conj_physical.default(mul_tensor_301);  mul_tensor_301 = None
        mul_tensor_302 = torch.ops.aten.mul.Tensor(to_dtype_75, conj_physical_default_4);  to_dtype_75 = conj_physical_default_4 = None
        to_dtype_77 = torch.ops.aten.to.dtype(mul_tensor_302, torch.float32);  mul_tensor_302 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(to_dtype_77, relu__default_7, primals_137, [1536], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_77 = primals_137 = None
        getitem_303 = convolution_backward_default_26[0]
        getitem_304 = convolution_backward_default_26[1]
        getitem_305 = convolution_backward_default_26[2];  convolution_backward_default_26 = None
        to_dtype_78 = torch.ops.aten.to.dtype(getitem_303, torch.float32);  getitem_303 = None
        to_dtype_79 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_79, 0);  to_dtype_79 = None
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(to_dtype_78, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_4, to_dtype_78);  le_scalar_4 = new_zeros_default_4 = to_dtype_78 = None
        to_dtype_80 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(to_dtype_80, mean_dim_7, primals_135, [768], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_80 = mean_dim_7 = primals_135 = None
        getitem_306 = convolution_backward_default_27[0]
        getitem_307 = convolution_backward_default_27[1]
        getitem_308 = convolution_backward_default_27[2];  convolution_backward_default_27 = None
        expand_default_5 = torch.ops.aten.expand.default(getitem_306, [128, 1536, 12, 12]);  getitem_306 = None
        div_scalar_5 = torch.ops.aten.div.Scalar(expand_default_5, 144);  expand_default_5 = None
        add_tensor_54 = torch.ops.aten.add.Tensor(mul_tensor_300, div_scalar_5);  mul_tensor_300 = div_scalar_5 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(add_tensor_54, mul__tensor_41, view_default_116, [1536], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  add_tensor_54 = mul__tensor_41 = view_default_116 = None
        getitem_309 = convolution_backward_default_28[0]
        getitem_310 = convolution_backward_default_28[1]
        getitem_311 = convolution_backward_default_28[2];  convolution_backward_default_28 = None
        view_default_228 = torch.ops.aten.view.default(getitem_310, [1, 1536, 768]);  getitem_310 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(view_default_228, view_default_114, view_default_115, None, None, getitem_115, getitem_116, True, 1e-05, [True, True, False]);  view_default_228 = view_default_114 = view_default_115 = getitem_115 = getitem_116 = None
        getitem_312 = native_batch_norm_backward_default_18[0]
        getitem_313 = native_batch_norm_backward_default_18[1]
        getitem_314 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        view_default_229 = torch.ops.aten.view.default(getitem_313, [1536, 1, 1, 1]);  getitem_313 = None
        mul_tensor_303 = torch.ops.aten.mul.Tensor(view_default_229, 0.03608439182435161);  view_default_229 = None
        view_default_230 = torch.ops.aten.view.default(getitem_312, [1536, 768, 1, 1]);  getitem_312 = None
        mul_tensor_304 = torch.ops.aten.mul.Tensor(getitem_309, 1.7015043497085571);  getitem_309 = None
        to_dtype_81 = torch.ops.aten.to.dtype(mul_tensor_304, torch.float32);  mul_tensor_304 = None
        to_dtype_82 = torch.ops.aten.to.dtype(convolution_default_51, torch.float32);  convolution_default_51 = None
        mul_tensor_305 = torch.ops.aten.mul.Tensor(to_dtype_82, 0.7071067811865476)
        erf_default_17 = torch.ops.aten.erf.default(mul_tensor_305);  mul_tensor_305 = None
        add_tensor_55 = torch.ops.aten.add.Tensor(erf_default_17, 1);  erf_default_17 = None
        mul_tensor_306 = torch.ops.aten.mul.Tensor(add_tensor_55, 0.5);  add_tensor_55 = None
        mul_tensor_307 = torch.ops.aten.mul.Tensor(to_dtype_82, to_dtype_82)
        mul_tensor_308 = torch.ops.aten.mul.Tensor(mul_tensor_307, -0.5);  mul_tensor_307 = None
        exp_default_17 = torch.ops.aten.exp.default(mul_tensor_308);  mul_tensor_308 = None
        mul_tensor_309 = torch.ops.aten.mul.Tensor(exp_default_17, 0.3989422804014327);  exp_default_17 = None
        mul_tensor_310 = torch.ops.aten.mul.Tensor(to_dtype_82, mul_tensor_309);  to_dtype_82 = mul_tensor_309 = None
        add_tensor_56 = torch.ops.aten.add.Tensor(mul_tensor_306, mul_tensor_310);  mul_tensor_306 = mul_tensor_310 = None
        mul_tensor_311 = torch.ops.aten.mul.Tensor(to_dtype_81, add_tensor_56);  to_dtype_81 = add_tensor_56 = None
        to_dtype_83 = torch.ops.aten.to.dtype(mul_tensor_311, torch.float32);  mul_tensor_311 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(to_dtype_83, mul__tensor_40, view_default_113, [768], [1, 1], [1, 1], [1, 1], False, [0, 0], 6, [True, True, True]);  to_dtype_83 = mul__tensor_40 = view_default_113 = None
        getitem_315 = convolution_backward_default_29[0]
        getitem_316 = convolution_backward_default_29[1]
        getitem_317 = convolution_backward_default_29[2];  convolution_backward_default_29 = None
        view_default_231 = torch.ops.aten.view.default(getitem_316, [1, 768, 1152]);  getitem_316 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(view_default_231, view_default_111, view_default_112, None, None, getitem_112, getitem_113, True, 1e-05, [True, True, False]);  view_default_231 = view_default_111 = view_default_112 = getitem_112 = getitem_113 = None
        getitem_318 = native_batch_norm_backward_default_19[0]
        getitem_319 = native_batch_norm_backward_default_19[1]
        getitem_320 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        view_default_232 = torch.ops.aten.view.default(getitem_319, [768, 1, 1, 1]);  getitem_319 = None
        mul_tensor_312 = torch.ops.aten.mul.Tensor(view_default_232, 0.02946278254943948);  view_default_232 = None
        view_default_233 = torch.ops.aten.view.default(getitem_318, [768, 128, 3, 3]);  getitem_318 = None
        mul_tensor_313 = torch.ops.aten.mul.Tensor(getitem_315, 1.7015043497085571);  getitem_315 = None
        to_dtype_84 = torch.ops.aten.to.dtype(mul_tensor_313, torch.float32);  mul_tensor_313 = None
        to_dtype_85 = torch.ops.aten.to.dtype(convolution_default_50, torch.float32);  convolution_default_50 = None
        mul_tensor_314 = torch.ops.aten.mul.Tensor(to_dtype_85, 0.7071067811865476)
        erf_default_18 = torch.ops.aten.erf.default(mul_tensor_314);  mul_tensor_314 = None
        add_tensor_57 = torch.ops.aten.add.Tensor(erf_default_18, 1);  erf_default_18 = None
        mul_tensor_315 = torch.ops.aten.mul.Tensor(add_tensor_57, 0.5);  add_tensor_57 = None
        mul_tensor_316 = torch.ops.aten.mul.Tensor(to_dtype_85, to_dtype_85)
        mul_tensor_317 = torch.ops.aten.mul.Tensor(mul_tensor_316, -0.5);  mul_tensor_316 = None
        exp_default_18 = torch.ops.aten.exp.default(mul_tensor_317);  mul_tensor_317 = None
        mul_tensor_318 = torch.ops.aten.mul.Tensor(exp_default_18, 0.3989422804014327);  exp_default_18 = None
        mul_tensor_319 = torch.ops.aten.mul.Tensor(to_dtype_85, mul_tensor_318);  to_dtype_85 = mul_tensor_318 = None
        add_tensor_58 = torch.ops.aten.add.Tensor(mul_tensor_315, mul_tensor_319);  mul_tensor_315 = mul_tensor_319 = None
        mul_tensor_320 = torch.ops.aten.mul.Tensor(to_dtype_84, add_tensor_58);  to_dtype_84 = add_tensor_58 = None
        to_dtype_86 = torch.ops.aten.to.dtype(mul_tensor_320, torch.float32);  mul_tensor_320 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(to_dtype_86, mul__tensor_39, view_default_110, [768], [1, 1], [1, 1], [1, 1], False, [0, 0], 6, [True, True, True]);  to_dtype_86 = mul__tensor_39 = view_default_110 = None
        getitem_321 = convolution_backward_default_30[0]
        getitem_322 = convolution_backward_default_30[1]
        getitem_323 = convolution_backward_default_30[2];  convolution_backward_default_30 = None
        view_default_234 = torch.ops.aten.view.default(getitem_322, [1, 768, 1152]);  getitem_322 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(view_default_234, view_default_108, view_default_109, None, None, getitem_109, getitem_110, True, 1e-05, [True, True, False]);  view_default_234 = view_default_108 = view_default_109 = getitem_109 = getitem_110 = None
        getitem_324 = native_batch_norm_backward_default_20[0]
        getitem_325 = native_batch_norm_backward_default_20[1]
        getitem_326 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        view_default_235 = torch.ops.aten.view.default(getitem_325, [768, 1, 1, 1]);  getitem_325 = None
        mul_tensor_321 = torch.ops.aten.mul.Tensor(view_default_235, 0.02946278254943948);  view_default_235 = None
        view_default_236 = torch.ops.aten.view.default(getitem_324, [768, 128, 3, 3]);  getitem_324 = None
        mul_tensor_322 = torch.ops.aten.mul.Tensor(getitem_321, 1.7015043497085571);  getitem_321 = None
        to_dtype_87 = torch.ops.aten.to.dtype(mul_tensor_322, torch.float32);  mul_tensor_322 = None
        to_dtype_88 = torch.ops.aten.to.dtype(convolution_default_49, torch.float32);  convolution_default_49 = None
        mul_tensor_323 = torch.ops.aten.mul.Tensor(to_dtype_88, 0.7071067811865476)
        erf_default_19 = torch.ops.aten.erf.default(mul_tensor_323);  mul_tensor_323 = None
        add_tensor_59 = torch.ops.aten.add.Tensor(erf_default_19, 1);  erf_default_19 = None
        mul_tensor_324 = torch.ops.aten.mul.Tensor(add_tensor_59, 0.5);  add_tensor_59 = None
        mul_tensor_325 = torch.ops.aten.mul.Tensor(to_dtype_88, to_dtype_88)
        mul_tensor_326 = torch.ops.aten.mul.Tensor(mul_tensor_325, -0.5);  mul_tensor_325 = None
        exp_default_19 = torch.ops.aten.exp.default(mul_tensor_326);  mul_tensor_326 = None
        mul_tensor_327 = torch.ops.aten.mul.Tensor(exp_default_19, 0.3989422804014327);  exp_default_19 = None
        mul_tensor_328 = torch.ops.aten.mul.Tensor(to_dtype_88, mul_tensor_327);  to_dtype_88 = mul_tensor_327 = None
        add_tensor_60 = torch.ops.aten.add.Tensor(mul_tensor_324, mul_tensor_328);  mul_tensor_324 = mul_tensor_328 = None
        mul_tensor_329 = torch.ops.aten.mul.Tensor(to_dtype_87, add_tensor_60);  to_dtype_87 = add_tensor_60 = None
        to_dtype_89 = torch.ops.aten.to.dtype(mul_tensor_329, torch.float32);  mul_tensor_329 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(to_dtype_89, mul_tensor_63, view_default_107, [768], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_89 = mul_tensor_63 = view_default_107 = None
        getitem_327 = convolution_backward_default_31[0]
        getitem_328 = convolution_backward_default_31[1]
        getitem_329 = convolution_backward_default_31[2];  convolution_backward_default_31 = None
        view_default_237 = torch.ops.aten.view.default(getitem_328, [1, 768, 1536]);  getitem_328 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(view_default_237, view_default_105, view_default_106, None, None, getitem_106, getitem_107, True, 1e-05, [True, True, False]);  view_default_237 = view_default_105 = view_default_106 = getitem_106 = getitem_107 = None
        getitem_330 = native_batch_norm_backward_default_21[0]
        getitem_331 = native_batch_norm_backward_default_21[1]
        getitem_332 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        view_default_238 = torch.ops.aten.view.default(getitem_331, [768, 1, 1, 1]);  getitem_331 = None
        mul_tensor_330 = torch.ops.aten.mul.Tensor(view_default_238, 0.02551551815399144);  view_default_238 = None
        view_default_239 = torch.ops.aten.view.default(getitem_330, [768, 1536, 1, 1]);  getitem_330 = None
        mul_tensor_331 = torch.ops.aten.mul.Tensor(getitem_327, 0.9284766908852592);  getitem_327 = None
        mul_tensor_332 = torch.ops.aten.mul.Tensor(mul_tensor_331, 1.7015043497085571);  mul_tensor_331 = None
        to_dtype_90 = torch.ops.aten.to.dtype(mul_tensor_332, torch.float32);  mul_tensor_332 = None
        to_dtype_91 = torch.ops.aten.to.dtype(add_tensor_6, torch.float32);  add_tensor_6 = None
        mul_tensor_333 = torch.ops.aten.mul.Tensor(to_dtype_91, 0.7071067811865476)
        erf_default_20 = torch.ops.aten.erf.default(mul_tensor_333);  mul_tensor_333 = None
        add_tensor_61 = torch.ops.aten.add.Tensor(erf_default_20, 1);  erf_default_20 = None
        mul_tensor_334 = torch.ops.aten.mul.Tensor(add_tensor_61, 0.5);  add_tensor_61 = None
        mul_tensor_335 = torch.ops.aten.mul.Tensor(to_dtype_91, to_dtype_91)
        mul_tensor_336 = torch.ops.aten.mul.Tensor(mul_tensor_335, -0.5);  mul_tensor_335 = None
        exp_default_20 = torch.ops.aten.exp.default(mul_tensor_336);  mul_tensor_336 = None
        mul_tensor_337 = torch.ops.aten.mul.Tensor(exp_default_20, 0.3989422804014327);  exp_default_20 = None
        mul_tensor_338 = torch.ops.aten.mul.Tensor(to_dtype_91, mul_tensor_337);  to_dtype_91 = mul_tensor_337 = None
        add_tensor_62 = torch.ops.aten.add.Tensor(mul_tensor_334, mul_tensor_338);  mul_tensor_334 = mul_tensor_338 = None
        mul_tensor_339 = torch.ops.aten.mul.Tensor(to_dtype_90, add_tensor_62);  to_dtype_90 = add_tensor_62 = None
        to_dtype_92 = torch.ops.aten.to.dtype(mul_tensor_339, torch.float32);  mul_tensor_339 = None
        add_tensor_63 = torch.ops.aten.add.Tensor(add_tensor_53, to_dtype_92);  add_tensor_53 = to_dtype_92 = None
        mul_tensor_340 = torch.ops.aten.mul.Tensor(add_tensor_63, 0.2)
        mul_tensor_341 = torch.ops.aten.mul.Tensor(mul_tensor_340, clone_default_6);  clone_default_6 = None
        mul_tensor_342 = torch.ops.aten.mul.Tensor(mul_tensor_340, primals_133);  mul_tensor_340 = primals_133 = None
        sum_default_5 = torch.ops.aten.sum.default(mul_tensor_341);  mul_tensor_341 = None
        mul_tensor_343 = torch.ops.aten.mul.Tensor(mul_tensor_342, 2.0);  mul_tensor_342 = None
        mul_tensor_344 = torch.ops.aten.mul.Tensor(mul_tensor_343, convolution_default_46);  convolution_default_46 = None
        mul_tensor_345 = torch.ops.aten.mul.Tensor(mul_tensor_343, sigmoid_default_6);  mul_tensor_343 = None
        sum_dim_int_list_6 = torch.ops.aten.sum.dim_IntList(mul_tensor_344, [2, 3], True);  mul_tensor_344 = None
        to_dtype_93 = torch.ops.aten.to.dtype(sum_dim_int_list_6, torch.float32);  sum_dim_int_list_6 = None
        to_dtype_94 = torch.ops.aten.to.dtype(sigmoid_default_6, torch.float32);  sigmoid_default_6 = None
        rsub_scalar_5 = torch.ops.aten.rsub.Scalar(to_dtype_94, 1)
        mul_tensor_346 = torch.ops.aten.mul.Tensor(to_dtype_94, rsub_scalar_5);  to_dtype_94 = rsub_scalar_5 = None
        conj_physical_default_5 = torch.ops.aten.conj_physical.default(mul_tensor_346);  mul_tensor_346 = None
        mul_tensor_347 = torch.ops.aten.mul.Tensor(to_dtype_93, conj_physical_default_5);  to_dtype_93 = conj_physical_default_5 = None
        to_dtype_95 = torch.ops.aten.to.dtype(mul_tensor_347, torch.float32);  mul_tensor_347 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(to_dtype_95, relu__default_6, primals_120, [1536], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_95 = primals_120 = None
        getitem_333 = convolution_backward_default_32[0]
        getitem_334 = convolution_backward_default_32[1]
        getitem_335 = convolution_backward_default_32[2];  convolution_backward_default_32 = None
        to_dtype_96 = torch.ops.aten.to.dtype(getitem_333, torch.float32);  getitem_333 = None
        to_dtype_97 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_97, 0);  to_dtype_97 = None
        new_zeros_default_5 = torch.ops.aten.new_zeros.default(to_dtype_96, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_5, to_dtype_96);  le_scalar_5 = new_zeros_default_5 = to_dtype_96 = None
        to_dtype_98 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(to_dtype_98, mean_dim_6, primals_118, [768], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_98 = mean_dim_6 = primals_118 = None
        getitem_336 = convolution_backward_default_33[0]
        getitem_337 = convolution_backward_default_33[1]
        getitem_338 = convolution_backward_default_33[2];  convolution_backward_default_33 = None
        expand_default_6 = torch.ops.aten.expand.default(getitem_336, [128, 1536, 12, 12]);  getitem_336 = None
        div_scalar_6 = torch.ops.aten.div.Scalar(expand_default_6, 144);  expand_default_6 = None
        add_tensor_64 = torch.ops.aten.add.Tensor(mul_tensor_345, div_scalar_6);  mul_tensor_345 = div_scalar_6 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(add_tensor_64, mul__tensor_36, view_default_104, [1536], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  add_tensor_64 = mul__tensor_36 = view_default_104 = None
        getitem_339 = convolution_backward_default_34[0]
        getitem_340 = convolution_backward_default_34[1]
        getitem_341 = convolution_backward_default_34[2];  convolution_backward_default_34 = None
        view_default_240 = torch.ops.aten.view.default(getitem_340, [1, 1536, 768]);  getitem_340 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(view_default_240, view_default_102, view_default_103, None, None, getitem_103, getitem_104, True, 1e-05, [True, True, False]);  view_default_240 = view_default_102 = view_default_103 = getitem_103 = getitem_104 = None
        getitem_342 = native_batch_norm_backward_default_22[0]
        getitem_343 = native_batch_norm_backward_default_22[1]
        getitem_344 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        view_default_241 = torch.ops.aten.view.default(getitem_343, [1536, 1, 1, 1]);  getitem_343 = None
        mul_tensor_348 = torch.ops.aten.mul.Tensor(view_default_241, 0.03608439182435161);  view_default_241 = None
        view_default_242 = torch.ops.aten.view.default(getitem_342, [1536, 768, 1, 1]);  getitem_342 = None
        mul_tensor_349 = torch.ops.aten.mul.Tensor(getitem_339, 1.7015043497085571);  getitem_339 = None
        to_dtype_99 = torch.ops.aten.to.dtype(mul_tensor_349, torch.float32);  mul_tensor_349 = None
        to_dtype_100 = torch.ops.aten.to.dtype(convolution_default_45, torch.float32);  convolution_default_45 = None
        mul_tensor_350 = torch.ops.aten.mul.Tensor(to_dtype_100, 0.7071067811865476)
        erf_default_21 = torch.ops.aten.erf.default(mul_tensor_350);  mul_tensor_350 = None
        add_tensor_65 = torch.ops.aten.add.Tensor(erf_default_21, 1);  erf_default_21 = None
        mul_tensor_351 = torch.ops.aten.mul.Tensor(add_tensor_65, 0.5);  add_tensor_65 = None
        mul_tensor_352 = torch.ops.aten.mul.Tensor(to_dtype_100, to_dtype_100)
        mul_tensor_353 = torch.ops.aten.mul.Tensor(mul_tensor_352, -0.5);  mul_tensor_352 = None
        exp_default_21 = torch.ops.aten.exp.default(mul_tensor_353);  mul_tensor_353 = None
        mul_tensor_354 = torch.ops.aten.mul.Tensor(exp_default_21, 0.3989422804014327);  exp_default_21 = None
        mul_tensor_355 = torch.ops.aten.mul.Tensor(to_dtype_100, mul_tensor_354);  to_dtype_100 = mul_tensor_354 = None
        add_tensor_66 = torch.ops.aten.add.Tensor(mul_tensor_351, mul_tensor_355);  mul_tensor_351 = mul_tensor_355 = None
        mul_tensor_356 = torch.ops.aten.mul.Tensor(to_dtype_99, add_tensor_66);  to_dtype_99 = add_tensor_66 = None
        to_dtype_101 = torch.ops.aten.to.dtype(mul_tensor_356, torch.float32);  mul_tensor_356 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(to_dtype_101, mul__tensor_35, view_default_101, [768], [1, 1], [1, 1], [1, 1], False, [0, 0], 6, [True, True, True]);  to_dtype_101 = mul__tensor_35 = view_default_101 = None
        getitem_345 = convolution_backward_default_35[0]
        getitem_346 = convolution_backward_default_35[1]
        getitem_347 = convolution_backward_default_35[2];  convolution_backward_default_35 = None
        view_default_243 = torch.ops.aten.view.default(getitem_346, [1, 768, 1152]);  getitem_346 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(view_default_243, view_default_99, view_default_100, None, None, getitem_100, getitem_101, True, 1e-05, [True, True, False]);  view_default_243 = view_default_99 = view_default_100 = getitem_100 = getitem_101 = None
        getitem_348 = native_batch_norm_backward_default_23[0]
        getitem_349 = native_batch_norm_backward_default_23[1]
        getitem_350 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        view_default_244 = torch.ops.aten.view.default(getitem_349, [768, 1, 1, 1]);  getitem_349 = None
        mul_tensor_357 = torch.ops.aten.mul.Tensor(view_default_244, 0.02946278254943948);  view_default_244 = None
        view_default_245 = torch.ops.aten.view.default(getitem_348, [768, 128, 3, 3]);  getitem_348 = None
        mul_tensor_358 = torch.ops.aten.mul.Tensor(getitem_345, 1.7015043497085571);  getitem_345 = None
        to_dtype_102 = torch.ops.aten.to.dtype(mul_tensor_358, torch.float32);  mul_tensor_358 = None
        to_dtype_103 = torch.ops.aten.to.dtype(convolution_default_44, torch.float32);  convolution_default_44 = None
        mul_tensor_359 = torch.ops.aten.mul.Tensor(to_dtype_103, 0.7071067811865476)
        erf_default_22 = torch.ops.aten.erf.default(mul_tensor_359);  mul_tensor_359 = None
        add_tensor_67 = torch.ops.aten.add.Tensor(erf_default_22, 1);  erf_default_22 = None
        mul_tensor_360 = torch.ops.aten.mul.Tensor(add_tensor_67, 0.5);  add_tensor_67 = None
        mul_tensor_361 = torch.ops.aten.mul.Tensor(to_dtype_103, to_dtype_103)
        mul_tensor_362 = torch.ops.aten.mul.Tensor(mul_tensor_361, -0.5);  mul_tensor_361 = None
        exp_default_22 = torch.ops.aten.exp.default(mul_tensor_362);  mul_tensor_362 = None
        mul_tensor_363 = torch.ops.aten.mul.Tensor(exp_default_22, 0.3989422804014327);  exp_default_22 = None
        mul_tensor_364 = torch.ops.aten.mul.Tensor(to_dtype_103, mul_tensor_363);  to_dtype_103 = mul_tensor_363 = None
        add_tensor_68 = torch.ops.aten.add.Tensor(mul_tensor_360, mul_tensor_364);  mul_tensor_360 = mul_tensor_364 = None
        mul_tensor_365 = torch.ops.aten.mul.Tensor(to_dtype_102, add_tensor_68);  to_dtype_102 = add_tensor_68 = None
        to_dtype_104 = torch.ops.aten.to.dtype(mul_tensor_365, torch.float32);  mul_tensor_365 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(to_dtype_104, mul__tensor_34, view_default_98, [768], [1, 1], [1, 1], [1, 1], False, [0, 0], 6, [True, True, True]);  to_dtype_104 = mul__tensor_34 = view_default_98 = None
        getitem_351 = convolution_backward_default_36[0]
        getitem_352 = convolution_backward_default_36[1]
        getitem_353 = convolution_backward_default_36[2];  convolution_backward_default_36 = None
        view_default_246 = torch.ops.aten.view.default(getitem_352, [1, 768, 1152]);  getitem_352 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(view_default_246, view_default_96, view_default_97, None, None, getitem_97, getitem_98, True, 1e-05, [True, True, False]);  view_default_246 = view_default_96 = view_default_97 = getitem_97 = getitem_98 = None
        getitem_354 = native_batch_norm_backward_default_24[0]
        getitem_355 = native_batch_norm_backward_default_24[1]
        getitem_356 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        view_default_247 = torch.ops.aten.view.default(getitem_355, [768, 1, 1, 1]);  getitem_355 = None
        mul_tensor_366 = torch.ops.aten.mul.Tensor(view_default_247, 0.02946278254943948);  view_default_247 = None
        view_default_248 = torch.ops.aten.view.default(getitem_354, [768, 128, 3, 3]);  getitem_354 = None
        mul_tensor_367 = torch.ops.aten.mul.Tensor(getitem_351, 1.7015043497085571);  getitem_351 = None
        to_dtype_105 = torch.ops.aten.to.dtype(mul_tensor_367, torch.float32);  mul_tensor_367 = None
        to_dtype_106 = torch.ops.aten.to.dtype(convolution_default_43, torch.float32);  convolution_default_43 = None
        mul_tensor_368 = torch.ops.aten.mul.Tensor(to_dtype_106, 0.7071067811865476)
        erf_default_23 = torch.ops.aten.erf.default(mul_tensor_368);  mul_tensor_368 = None
        add_tensor_69 = torch.ops.aten.add.Tensor(erf_default_23, 1);  erf_default_23 = None
        mul_tensor_369 = torch.ops.aten.mul.Tensor(add_tensor_69, 0.5);  add_tensor_69 = None
        mul_tensor_370 = torch.ops.aten.mul.Tensor(to_dtype_106, to_dtype_106)
        mul_tensor_371 = torch.ops.aten.mul.Tensor(mul_tensor_370, -0.5);  mul_tensor_370 = None
        exp_default_23 = torch.ops.aten.exp.default(mul_tensor_371);  mul_tensor_371 = None
        mul_tensor_372 = torch.ops.aten.mul.Tensor(exp_default_23, 0.3989422804014327);  exp_default_23 = None
        mul_tensor_373 = torch.ops.aten.mul.Tensor(to_dtype_106, mul_tensor_372);  to_dtype_106 = mul_tensor_372 = None
        add_tensor_70 = torch.ops.aten.add.Tensor(mul_tensor_369, mul_tensor_373);  mul_tensor_369 = mul_tensor_373 = None
        mul_tensor_374 = torch.ops.aten.mul.Tensor(to_dtype_105, add_tensor_70);  to_dtype_105 = add_tensor_70 = None
        to_dtype_107 = torch.ops.aten.to.dtype(mul_tensor_374, torch.float32);  mul_tensor_374 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(to_dtype_107, mul_tensor_55, view_default_95, [768], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_107 = mul_tensor_55 = view_default_95 = None
        getitem_357 = convolution_backward_default_37[0]
        getitem_358 = convolution_backward_default_37[1]
        getitem_359 = convolution_backward_default_37[2];  convolution_backward_default_37 = None
        view_default_249 = torch.ops.aten.view.default(getitem_358, [1, 768, 1536]);  getitem_358 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(view_default_249, view_default_93, view_default_94, None, None, getitem_94, getitem_95, True, 1e-05, [True, True, False]);  view_default_249 = view_default_93 = view_default_94 = getitem_94 = getitem_95 = None
        getitem_360 = native_batch_norm_backward_default_25[0]
        getitem_361 = native_batch_norm_backward_default_25[1]
        getitem_362 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        view_default_250 = torch.ops.aten.view.default(getitem_361, [768, 1, 1, 1]);  getitem_361 = None
        mul_tensor_375 = torch.ops.aten.mul.Tensor(view_default_250, 0.02551551815399144);  view_default_250 = None
        view_default_251 = torch.ops.aten.view.default(getitem_360, [768, 1536, 1, 1]);  getitem_360 = None
        mul_tensor_376 = torch.ops.aten.mul.Tensor(getitem_357, 0.9449111825230679);  getitem_357 = None
        mul_tensor_377 = torch.ops.aten.mul.Tensor(mul_tensor_376, 1.7015043497085571);  mul_tensor_376 = None
        to_dtype_108 = torch.ops.aten.to.dtype(mul_tensor_377, torch.float32);  mul_tensor_377 = None
        to_dtype_109 = torch.ops.aten.to.dtype(add_tensor_5, torch.float32);  add_tensor_5 = None
        mul_tensor_378 = torch.ops.aten.mul.Tensor(to_dtype_109, 0.7071067811865476)
        erf_default_24 = torch.ops.aten.erf.default(mul_tensor_378);  mul_tensor_378 = None
        add_tensor_71 = torch.ops.aten.add.Tensor(erf_default_24, 1);  erf_default_24 = None
        mul_tensor_379 = torch.ops.aten.mul.Tensor(add_tensor_71, 0.5);  add_tensor_71 = None
        mul_tensor_380 = torch.ops.aten.mul.Tensor(to_dtype_109, to_dtype_109)
        mul_tensor_381 = torch.ops.aten.mul.Tensor(mul_tensor_380, -0.5);  mul_tensor_380 = None
        exp_default_24 = torch.ops.aten.exp.default(mul_tensor_381);  mul_tensor_381 = None
        mul_tensor_382 = torch.ops.aten.mul.Tensor(exp_default_24, 0.3989422804014327);  exp_default_24 = None
        mul_tensor_383 = torch.ops.aten.mul.Tensor(to_dtype_109, mul_tensor_382);  to_dtype_109 = mul_tensor_382 = None
        add_tensor_72 = torch.ops.aten.add.Tensor(mul_tensor_379, mul_tensor_383);  mul_tensor_379 = mul_tensor_383 = None
        mul_tensor_384 = torch.ops.aten.mul.Tensor(to_dtype_108, add_tensor_72);  to_dtype_108 = add_tensor_72 = None
        to_dtype_110 = torch.ops.aten.to.dtype(mul_tensor_384, torch.float32);  mul_tensor_384 = None
        add_tensor_73 = torch.ops.aten.add.Tensor(add_tensor_63, to_dtype_110);  add_tensor_63 = to_dtype_110 = None
        mul_tensor_385 = torch.ops.aten.mul.Tensor(add_tensor_73, 0.2)
        mul_tensor_386 = torch.ops.aten.mul.Tensor(mul_tensor_385, clone_default_5);  clone_default_5 = None
        mul_tensor_387 = torch.ops.aten.mul.Tensor(mul_tensor_385, primals_116);  mul_tensor_385 = primals_116 = None
        sum_default_6 = torch.ops.aten.sum.default(mul_tensor_386);  mul_tensor_386 = None
        mul_tensor_388 = torch.ops.aten.mul.Tensor(mul_tensor_387, 2.0);  mul_tensor_387 = None
        mul_tensor_389 = torch.ops.aten.mul.Tensor(mul_tensor_388, convolution_default_40);  convolution_default_40 = None
        mul_tensor_390 = torch.ops.aten.mul.Tensor(mul_tensor_388, sigmoid_default_5);  mul_tensor_388 = None
        sum_dim_int_list_7 = torch.ops.aten.sum.dim_IntList(mul_tensor_389, [2, 3], True);  mul_tensor_389 = None
        to_dtype_111 = torch.ops.aten.to.dtype(sum_dim_int_list_7, torch.float32);  sum_dim_int_list_7 = None
        to_dtype_112 = torch.ops.aten.to.dtype(sigmoid_default_5, torch.float32);  sigmoid_default_5 = None
        rsub_scalar_6 = torch.ops.aten.rsub.Scalar(to_dtype_112, 1)
        mul_tensor_391 = torch.ops.aten.mul.Tensor(to_dtype_112, rsub_scalar_6);  to_dtype_112 = rsub_scalar_6 = None
        conj_physical_default_6 = torch.ops.aten.conj_physical.default(mul_tensor_391);  mul_tensor_391 = None
        mul_tensor_392 = torch.ops.aten.mul.Tensor(to_dtype_111, conj_physical_default_6);  to_dtype_111 = conj_physical_default_6 = None
        to_dtype_113 = torch.ops.aten.to.dtype(mul_tensor_392, torch.float32);  mul_tensor_392 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(to_dtype_113, relu__default_5, primals_103, [1536], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_113 = primals_103 = None
        getitem_363 = convolution_backward_default_38[0]
        getitem_364 = convolution_backward_default_38[1]
        getitem_365 = convolution_backward_default_38[2];  convolution_backward_default_38 = None
        to_dtype_114 = torch.ops.aten.to.dtype(getitem_363, torch.float32);  getitem_363 = None
        to_dtype_115 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_115, 0);  to_dtype_115 = None
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(to_dtype_114, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_6, to_dtype_114);  le_scalar_6 = new_zeros_default_6 = to_dtype_114 = None
        to_dtype_116 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(to_dtype_116, mean_dim_5, primals_101, [768], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_116 = mean_dim_5 = primals_101 = None
        getitem_366 = convolution_backward_default_39[0]
        getitem_367 = convolution_backward_default_39[1]
        getitem_368 = convolution_backward_default_39[2];  convolution_backward_default_39 = None
        expand_default_7 = torch.ops.aten.expand.default(getitem_366, [128, 1536, 12, 12]);  getitem_366 = None
        div_scalar_7 = torch.ops.aten.div.Scalar(expand_default_7, 144);  expand_default_7 = None
        add_tensor_74 = torch.ops.aten.add.Tensor(mul_tensor_390, div_scalar_7);  mul_tensor_390 = div_scalar_7 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(add_tensor_74, mul__tensor_31, view_default_92, [1536], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  add_tensor_74 = mul__tensor_31 = view_default_92 = None
        getitem_369 = convolution_backward_default_40[0]
        getitem_370 = convolution_backward_default_40[1]
        getitem_371 = convolution_backward_default_40[2];  convolution_backward_default_40 = None
        view_default_252 = torch.ops.aten.view.default(getitem_370, [1, 1536, 768]);  getitem_370 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(view_default_252, view_default_90, view_default_91, None, None, getitem_91, getitem_92, True, 1e-05, [True, True, False]);  view_default_252 = view_default_90 = view_default_91 = getitem_91 = getitem_92 = None
        getitem_372 = native_batch_norm_backward_default_26[0]
        getitem_373 = native_batch_norm_backward_default_26[1]
        getitem_374 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        view_default_253 = torch.ops.aten.view.default(getitem_373, [1536, 1, 1, 1]);  getitem_373 = None
        mul_tensor_393 = torch.ops.aten.mul.Tensor(view_default_253, 0.03608439182435161);  view_default_253 = None
        view_default_254 = torch.ops.aten.view.default(getitem_372, [1536, 768, 1, 1]);  getitem_372 = None
        mul_tensor_394 = torch.ops.aten.mul.Tensor(getitem_369, 1.7015043497085571);  getitem_369 = None
        to_dtype_117 = torch.ops.aten.to.dtype(mul_tensor_394, torch.float32);  mul_tensor_394 = None
        to_dtype_118 = torch.ops.aten.to.dtype(convolution_default_39, torch.float32);  convolution_default_39 = None
        mul_tensor_395 = torch.ops.aten.mul.Tensor(to_dtype_118, 0.7071067811865476)
        erf_default_25 = torch.ops.aten.erf.default(mul_tensor_395);  mul_tensor_395 = None
        add_tensor_75 = torch.ops.aten.add.Tensor(erf_default_25, 1);  erf_default_25 = None
        mul_tensor_396 = torch.ops.aten.mul.Tensor(add_tensor_75, 0.5);  add_tensor_75 = None
        mul_tensor_397 = torch.ops.aten.mul.Tensor(to_dtype_118, to_dtype_118)
        mul_tensor_398 = torch.ops.aten.mul.Tensor(mul_tensor_397, -0.5);  mul_tensor_397 = None
        exp_default_25 = torch.ops.aten.exp.default(mul_tensor_398);  mul_tensor_398 = None
        mul_tensor_399 = torch.ops.aten.mul.Tensor(exp_default_25, 0.3989422804014327);  exp_default_25 = None
        mul_tensor_400 = torch.ops.aten.mul.Tensor(to_dtype_118, mul_tensor_399);  to_dtype_118 = mul_tensor_399 = None
        add_tensor_76 = torch.ops.aten.add.Tensor(mul_tensor_396, mul_tensor_400);  mul_tensor_396 = mul_tensor_400 = None
        mul_tensor_401 = torch.ops.aten.mul.Tensor(to_dtype_117, add_tensor_76);  to_dtype_117 = add_tensor_76 = None
        to_dtype_119 = torch.ops.aten.to.dtype(mul_tensor_401, torch.float32);  mul_tensor_401 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(to_dtype_119, mul__tensor_30, view_default_89, [768], [1, 1], [1, 1], [1, 1], False, [0, 0], 6, [True, True, True]);  to_dtype_119 = mul__tensor_30 = view_default_89 = None
        getitem_375 = convolution_backward_default_41[0]
        getitem_376 = convolution_backward_default_41[1]
        getitem_377 = convolution_backward_default_41[2];  convolution_backward_default_41 = None
        view_default_255 = torch.ops.aten.view.default(getitem_376, [1, 768, 1152]);  getitem_376 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(view_default_255, view_default_87, view_default_88, None, None, getitem_88, getitem_89, True, 1e-05, [True, True, False]);  view_default_255 = view_default_87 = view_default_88 = getitem_88 = getitem_89 = None
        getitem_378 = native_batch_norm_backward_default_27[0]
        getitem_379 = native_batch_norm_backward_default_27[1]
        getitem_380 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        view_default_256 = torch.ops.aten.view.default(getitem_379, [768, 1, 1, 1]);  getitem_379 = None
        mul_tensor_402 = torch.ops.aten.mul.Tensor(view_default_256, 0.02946278254943948);  view_default_256 = None
        view_default_257 = torch.ops.aten.view.default(getitem_378, [768, 128, 3, 3]);  getitem_378 = None
        mul_tensor_403 = torch.ops.aten.mul.Tensor(getitem_375, 1.7015043497085571);  getitem_375 = None
        to_dtype_120 = torch.ops.aten.to.dtype(mul_tensor_403, torch.float32);  mul_tensor_403 = None
        to_dtype_121 = torch.ops.aten.to.dtype(convolution_default_38, torch.float32);  convolution_default_38 = None
        mul_tensor_404 = torch.ops.aten.mul.Tensor(to_dtype_121, 0.7071067811865476)
        erf_default_26 = torch.ops.aten.erf.default(mul_tensor_404);  mul_tensor_404 = None
        add_tensor_77 = torch.ops.aten.add.Tensor(erf_default_26, 1);  erf_default_26 = None
        mul_tensor_405 = torch.ops.aten.mul.Tensor(add_tensor_77, 0.5);  add_tensor_77 = None
        mul_tensor_406 = torch.ops.aten.mul.Tensor(to_dtype_121, to_dtype_121)
        mul_tensor_407 = torch.ops.aten.mul.Tensor(mul_tensor_406, -0.5);  mul_tensor_406 = None
        exp_default_26 = torch.ops.aten.exp.default(mul_tensor_407);  mul_tensor_407 = None
        mul_tensor_408 = torch.ops.aten.mul.Tensor(exp_default_26, 0.3989422804014327);  exp_default_26 = None
        mul_tensor_409 = torch.ops.aten.mul.Tensor(to_dtype_121, mul_tensor_408);  to_dtype_121 = mul_tensor_408 = None
        add_tensor_78 = torch.ops.aten.add.Tensor(mul_tensor_405, mul_tensor_409);  mul_tensor_405 = mul_tensor_409 = None
        mul_tensor_410 = torch.ops.aten.mul.Tensor(to_dtype_120, add_tensor_78);  to_dtype_120 = add_tensor_78 = None
        to_dtype_122 = torch.ops.aten.to.dtype(mul_tensor_410, torch.float32);  mul_tensor_410 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(to_dtype_122, mul__tensor_29, view_default_86, [768], [1, 1], [1, 1], [1, 1], False, [0, 0], 6, [True, True, True]);  to_dtype_122 = mul__tensor_29 = view_default_86 = None
        getitem_381 = convolution_backward_default_42[0]
        getitem_382 = convolution_backward_default_42[1]
        getitem_383 = convolution_backward_default_42[2];  convolution_backward_default_42 = None
        view_default_258 = torch.ops.aten.view.default(getitem_382, [1, 768, 1152]);  getitem_382 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(view_default_258, view_default_84, view_default_85, None, None, getitem_85, getitem_86, True, 1e-05, [True, True, False]);  view_default_258 = view_default_84 = view_default_85 = getitem_85 = getitem_86 = None
        getitem_384 = native_batch_norm_backward_default_28[0]
        getitem_385 = native_batch_norm_backward_default_28[1]
        getitem_386 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        view_default_259 = torch.ops.aten.view.default(getitem_385, [768, 1, 1, 1]);  getitem_385 = None
        mul_tensor_411 = torch.ops.aten.mul.Tensor(view_default_259, 0.02946278254943948);  view_default_259 = None
        view_default_260 = torch.ops.aten.view.default(getitem_384, [768, 128, 3, 3]);  getitem_384 = None
        mul_tensor_412 = torch.ops.aten.mul.Tensor(getitem_381, 1.7015043497085571);  getitem_381 = None
        to_dtype_123 = torch.ops.aten.to.dtype(mul_tensor_412, torch.float32);  mul_tensor_412 = None
        to_dtype_124 = torch.ops.aten.to.dtype(convolution_default_37, torch.float32);  convolution_default_37 = None
        mul_tensor_413 = torch.ops.aten.mul.Tensor(to_dtype_124, 0.7071067811865476)
        erf_default_27 = torch.ops.aten.erf.default(mul_tensor_413);  mul_tensor_413 = None
        add_tensor_79 = torch.ops.aten.add.Tensor(erf_default_27, 1);  erf_default_27 = None
        mul_tensor_414 = torch.ops.aten.mul.Tensor(add_tensor_79, 0.5);  add_tensor_79 = None
        mul_tensor_415 = torch.ops.aten.mul.Tensor(to_dtype_124, to_dtype_124)
        mul_tensor_416 = torch.ops.aten.mul.Tensor(mul_tensor_415, -0.5);  mul_tensor_415 = None
        exp_default_27 = torch.ops.aten.exp.default(mul_tensor_416);  mul_tensor_416 = None
        mul_tensor_417 = torch.ops.aten.mul.Tensor(exp_default_27, 0.3989422804014327);  exp_default_27 = None
        mul_tensor_418 = torch.ops.aten.mul.Tensor(to_dtype_124, mul_tensor_417);  to_dtype_124 = mul_tensor_417 = None
        add_tensor_80 = torch.ops.aten.add.Tensor(mul_tensor_414, mul_tensor_418);  mul_tensor_414 = mul_tensor_418 = None
        mul_tensor_419 = torch.ops.aten.mul.Tensor(to_dtype_123, add_tensor_80);  to_dtype_123 = add_tensor_80 = None
        to_dtype_125 = torch.ops.aten.to.dtype(mul_tensor_419, torch.float32);  mul_tensor_419 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(to_dtype_125, mul_tensor_47, view_default_83, [768], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_125 = mul_tensor_47 = view_default_83 = None
        getitem_387 = convolution_backward_default_43[0]
        getitem_388 = convolution_backward_default_43[1]
        getitem_389 = convolution_backward_default_43[2];  convolution_backward_default_43 = None
        view_default_261 = torch.ops.aten.view.default(getitem_388, [1, 768, 1536]);  getitem_388 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(view_default_261, view_default_81, view_default_82, None, None, getitem_82, getitem_83, True, 1e-05, [True, True, False]);  view_default_261 = view_default_81 = view_default_82 = getitem_82 = getitem_83 = None
        getitem_390 = native_batch_norm_backward_default_29[0]
        getitem_391 = native_batch_norm_backward_default_29[1]
        getitem_392 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        view_default_262 = torch.ops.aten.view.default(getitem_391, [768, 1, 1, 1]);  getitem_391 = None
        mul_tensor_420 = torch.ops.aten.mul.Tensor(view_default_262, 0.02551551815399144);  view_default_262 = None
        view_default_263 = torch.ops.aten.view.default(getitem_390, [768, 1536, 1, 1]);  getitem_390 = None
        mul_tensor_421 = torch.ops.aten.mul.Tensor(getitem_387, 0.9622504486493761);  getitem_387 = None
        mul_tensor_422 = torch.ops.aten.mul.Tensor(mul_tensor_421, 1.7015043497085571);  mul_tensor_421 = None
        to_dtype_126 = torch.ops.aten.to.dtype(mul_tensor_422, torch.float32);  mul_tensor_422 = None
        to_dtype_127 = torch.ops.aten.to.dtype(add_tensor_4, torch.float32);  add_tensor_4 = None
        mul_tensor_423 = torch.ops.aten.mul.Tensor(to_dtype_127, 0.7071067811865476)
        erf_default_28 = torch.ops.aten.erf.default(mul_tensor_423);  mul_tensor_423 = None
        add_tensor_81 = torch.ops.aten.add.Tensor(erf_default_28, 1);  erf_default_28 = None
        mul_tensor_424 = torch.ops.aten.mul.Tensor(add_tensor_81, 0.5);  add_tensor_81 = None
        mul_tensor_425 = torch.ops.aten.mul.Tensor(to_dtype_127, to_dtype_127)
        mul_tensor_426 = torch.ops.aten.mul.Tensor(mul_tensor_425, -0.5);  mul_tensor_425 = None
        exp_default_28 = torch.ops.aten.exp.default(mul_tensor_426);  mul_tensor_426 = None
        mul_tensor_427 = torch.ops.aten.mul.Tensor(exp_default_28, 0.3989422804014327);  exp_default_28 = None
        mul_tensor_428 = torch.ops.aten.mul.Tensor(to_dtype_127, mul_tensor_427);  to_dtype_127 = mul_tensor_427 = None
        add_tensor_82 = torch.ops.aten.add.Tensor(mul_tensor_424, mul_tensor_428);  mul_tensor_424 = mul_tensor_428 = None
        mul_tensor_429 = torch.ops.aten.mul.Tensor(to_dtype_126, add_tensor_82);  to_dtype_126 = add_tensor_82 = None
        to_dtype_128 = torch.ops.aten.to.dtype(mul_tensor_429, torch.float32);  mul_tensor_429 = None
        add_tensor_83 = torch.ops.aten.add.Tensor(add_tensor_73, to_dtype_128);  add_tensor_73 = to_dtype_128 = None
        mul_tensor_430 = torch.ops.aten.mul.Tensor(add_tensor_83, 0.2)
        mul_tensor_431 = torch.ops.aten.mul.Tensor(mul_tensor_430, clone_default_4);  clone_default_4 = None
        mul_tensor_432 = torch.ops.aten.mul.Tensor(mul_tensor_430, primals_99);  mul_tensor_430 = primals_99 = None
        sum_default_7 = torch.ops.aten.sum.default(mul_tensor_431);  mul_tensor_431 = None
        mul_tensor_433 = torch.ops.aten.mul.Tensor(mul_tensor_432, 2.0);  mul_tensor_432 = None
        mul_tensor_434 = torch.ops.aten.mul.Tensor(mul_tensor_433, convolution_default_34);  convolution_default_34 = None
        mul_tensor_435 = torch.ops.aten.mul.Tensor(mul_tensor_433, sigmoid_default_4);  mul_tensor_433 = None
        sum_dim_int_list_8 = torch.ops.aten.sum.dim_IntList(mul_tensor_434, [2, 3], True);  mul_tensor_434 = None
        to_dtype_129 = torch.ops.aten.to.dtype(sum_dim_int_list_8, torch.float32);  sum_dim_int_list_8 = None
        to_dtype_130 = torch.ops.aten.to.dtype(sigmoid_default_4, torch.float32);  sigmoid_default_4 = None
        rsub_scalar_7 = torch.ops.aten.rsub.Scalar(to_dtype_130, 1)
        mul_tensor_436 = torch.ops.aten.mul.Tensor(to_dtype_130, rsub_scalar_7);  to_dtype_130 = rsub_scalar_7 = None
        conj_physical_default_7 = torch.ops.aten.conj_physical.default(mul_tensor_436);  mul_tensor_436 = None
        mul_tensor_437 = torch.ops.aten.mul.Tensor(to_dtype_129, conj_physical_default_7);  to_dtype_129 = conj_physical_default_7 = None
        to_dtype_131 = torch.ops.aten.to.dtype(mul_tensor_437, torch.float32);  mul_tensor_437 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(to_dtype_131, relu__default_4, primals_86, [1536], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_131 = primals_86 = None
        getitem_393 = convolution_backward_default_44[0]
        getitem_394 = convolution_backward_default_44[1]
        getitem_395 = convolution_backward_default_44[2];  convolution_backward_default_44 = None
        to_dtype_132 = torch.ops.aten.to.dtype(getitem_393, torch.float32);  getitem_393 = None
        to_dtype_133 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_133, 0);  to_dtype_133 = None
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(to_dtype_132, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_7, to_dtype_132);  le_scalar_7 = new_zeros_default_7 = to_dtype_132 = None
        to_dtype_134 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(to_dtype_134, mean_dim_4, primals_84, [768], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_134 = mean_dim_4 = primals_84 = None
        getitem_396 = convolution_backward_default_45[0]
        getitem_397 = convolution_backward_default_45[1]
        getitem_398 = convolution_backward_default_45[2];  convolution_backward_default_45 = None
        expand_default_8 = torch.ops.aten.expand.default(getitem_396, [128, 1536, 12, 12]);  getitem_396 = None
        div_scalar_8 = torch.ops.aten.div.Scalar(expand_default_8, 144);  expand_default_8 = None
        add_tensor_84 = torch.ops.aten.add.Tensor(mul_tensor_435, div_scalar_8);  mul_tensor_435 = div_scalar_8 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(add_tensor_84, mul__tensor_26, view_default_80, [1536], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  add_tensor_84 = mul__tensor_26 = view_default_80 = None
        getitem_399 = convolution_backward_default_46[0]
        getitem_400 = convolution_backward_default_46[1]
        getitem_401 = convolution_backward_default_46[2];  convolution_backward_default_46 = None
        view_default_264 = torch.ops.aten.view.default(getitem_400, [1, 1536, 768]);  getitem_400 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(view_default_264, view_default_78, view_default_79, None, None, getitem_79, getitem_80, True, 1e-05, [True, True, False]);  view_default_264 = view_default_78 = view_default_79 = getitem_79 = getitem_80 = None
        getitem_402 = native_batch_norm_backward_default_30[0]
        getitem_403 = native_batch_norm_backward_default_30[1]
        getitem_404 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        view_default_265 = torch.ops.aten.view.default(getitem_403, [1536, 1, 1, 1]);  getitem_403 = None
        mul_tensor_438 = torch.ops.aten.mul.Tensor(view_default_265, 0.03608439182435161);  view_default_265 = None
        view_default_266 = torch.ops.aten.view.default(getitem_402, [1536, 768, 1, 1]);  getitem_402 = None
        mul_tensor_439 = torch.ops.aten.mul.Tensor(getitem_399, 1.7015043497085571);  getitem_399 = None
        to_dtype_135 = torch.ops.aten.to.dtype(mul_tensor_439, torch.float32);  mul_tensor_439 = None
        to_dtype_136 = torch.ops.aten.to.dtype(convolution_default_33, torch.float32);  convolution_default_33 = None
        mul_tensor_440 = torch.ops.aten.mul.Tensor(to_dtype_136, 0.7071067811865476)
        erf_default_29 = torch.ops.aten.erf.default(mul_tensor_440);  mul_tensor_440 = None
        add_tensor_85 = torch.ops.aten.add.Tensor(erf_default_29, 1);  erf_default_29 = None
        mul_tensor_441 = torch.ops.aten.mul.Tensor(add_tensor_85, 0.5);  add_tensor_85 = None
        mul_tensor_442 = torch.ops.aten.mul.Tensor(to_dtype_136, to_dtype_136)
        mul_tensor_443 = torch.ops.aten.mul.Tensor(mul_tensor_442, -0.5);  mul_tensor_442 = None
        exp_default_29 = torch.ops.aten.exp.default(mul_tensor_443);  mul_tensor_443 = None
        mul_tensor_444 = torch.ops.aten.mul.Tensor(exp_default_29, 0.3989422804014327);  exp_default_29 = None
        mul_tensor_445 = torch.ops.aten.mul.Tensor(to_dtype_136, mul_tensor_444);  to_dtype_136 = mul_tensor_444 = None
        add_tensor_86 = torch.ops.aten.add.Tensor(mul_tensor_441, mul_tensor_445);  mul_tensor_441 = mul_tensor_445 = None
        mul_tensor_446 = torch.ops.aten.mul.Tensor(to_dtype_135, add_tensor_86);  to_dtype_135 = add_tensor_86 = None
        to_dtype_137 = torch.ops.aten.to.dtype(mul_tensor_446, torch.float32);  mul_tensor_446 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(to_dtype_137, mul__tensor_25, view_default_77, [768], [1, 1], [1, 1], [1, 1], False, [0, 0], 6, [True, True, True]);  to_dtype_137 = mul__tensor_25 = view_default_77 = None
        getitem_405 = convolution_backward_default_47[0]
        getitem_406 = convolution_backward_default_47[1]
        getitem_407 = convolution_backward_default_47[2];  convolution_backward_default_47 = None
        view_default_267 = torch.ops.aten.view.default(getitem_406, [1, 768, 1152]);  getitem_406 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(view_default_267, view_default_75, view_default_76, None, None, getitem_76, getitem_77, True, 1e-05, [True, True, False]);  view_default_267 = view_default_75 = view_default_76 = getitem_76 = getitem_77 = None
        getitem_408 = native_batch_norm_backward_default_31[0]
        getitem_409 = native_batch_norm_backward_default_31[1]
        getitem_410 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        view_default_268 = torch.ops.aten.view.default(getitem_409, [768, 1, 1, 1]);  getitem_409 = None
        mul_tensor_447 = torch.ops.aten.mul.Tensor(view_default_268, 0.02946278254943948);  view_default_268 = None
        view_default_269 = torch.ops.aten.view.default(getitem_408, [768, 128, 3, 3]);  getitem_408 = None
        mul_tensor_448 = torch.ops.aten.mul.Tensor(getitem_405, 1.7015043497085571);  getitem_405 = None
        to_dtype_138 = torch.ops.aten.to.dtype(mul_tensor_448, torch.float32);  mul_tensor_448 = None
        to_dtype_139 = torch.ops.aten.to.dtype(convolution_default_32, torch.float32);  convolution_default_32 = None
        mul_tensor_449 = torch.ops.aten.mul.Tensor(to_dtype_139, 0.7071067811865476)
        erf_default_30 = torch.ops.aten.erf.default(mul_tensor_449);  mul_tensor_449 = None
        add_tensor_87 = torch.ops.aten.add.Tensor(erf_default_30, 1);  erf_default_30 = None
        mul_tensor_450 = torch.ops.aten.mul.Tensor(add_tensor_87, 0.5);  add_tensor_87 = None
        mul_tensor_451 = torch.ops.aten.mul.Tensor(to_dtype_139, to_dtype_139)
        mul_tensor_452 = torch.ops.aten.mul.Tensor(mul_tensor_451, -0.5);  mul_tensor_451 = None
        exp_default_30 = torch.ops.aten.exp.default(mul_tensor_452);  mul_tensor_452 = None
        mul_tensor_453 = torch.ops.aten.mul.Tensor(exp_default_30, 0.3989422804014327);  exp_default_30 = None
        mul_tensor_454 = torch.ops.aten.mul.Tensor(to_dtype_139, mul_tensor_453);  to_dtype_139 = mul_tensor_453 = None
        add_tensor_88 = torch.ops.aten.add.Tensor(mul_tensor_450, mul_tensor_454);  mul_tensor_450 = mul_tensor_454 = None
        mul_tensor_455 = torch.ops.aten.mul.Tensor(to_dtype_138, add_tensor_88);  to_dtype_138 = add_tensor_88 = None
        to_dtype_140 = torch.ops.aten.to.dtype(mul_tensor_455, torch.float32);  mul_tensor_455 = None
        convolution_backward_default_48 = torch.ops.aten.convolution_backward.default(to_dtype_140, mul__tensor_24, view_default_74, [768], [1, 1], [1, 1], [1, 1], False, [0, 0], 6, [True, True, True]);  to_dtype_140 = mul__tensor_24 = view_default_74 = None
        getitem_411 = convolution_backward_default_48[0]
        getitem_412 = convolution_backward_default_48[1]
        getitem_413 = convolution_backward_default_48[2];  convolution_backward_default_48 = None
        view_default_270 = torch.ops.aten.view.default(getitem_412, [1, 768, 1152]);  getitem_412 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(view_default_270, view_default_72, view_default_73, None, None, getitem_73, getitem_74, True, 1e-05, [True, True, False]);  view_default_270 = view_default_72 = view_default_73 = getitem_73 = getitem_74 = None
        getitem_414 = native_batch_norm_backward_default_32[0]
        getitem_415 = native_batch_norm_backward_default_32[1]
        getitem_416 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        view_default_271 = torch.ops.aten.view.default(getitem_415, [768, 1, 1, 1]);  getitem_415 = None
        mul_tensor_456 = torch.ops.aten.mul.Tensor(view_default_271, 0.02946278254943948);  view_default_271 = None
        view_default_272 = torch.ops.aten.view.default(getitem_414, [768, 128, 3, 3]);  getitem_414 = None
        mul_tensor_457 = torch.ops.aten.mul.Tensor(getitem_411, 1.7015043497085571);  getitem_411 = None
        to_dtype_141 = torch.ops.aten.to.dtype(mul_tensor_457, torch.float32);  mul_tensor_457 = None
        to_dtype_142 = torch.ops.aten.to.dtype(convolution_default_31, torch.float32);  convolution_default_31 = None
        mul_tensor_458 = torch.ops.aten.mul.Tensor(to_dtype_142, 0.7071067811865476)
        erf_default_31 = torch.ops.aten.erf.default(mul_tensor_458);  mul_tensor_458 = None
        add_tensor_89 = torch.ops.aten.add.Tensor(erf_default_31, 1);  erf_default_31 = None
        mul_tensor_459 = torch.ops.aten.mul.Tensor(add_tensor_89, 0.5);  add_tensor_89 = None
        mul_tensor_460 = torch.ops.aten.mul.Tensor(to_dtype_142, to_dtype_142)
        mul_tensor_461 = torch.ops.aten.mul.Tensor(mul_tensor_460, -0.5);  mul_tensor_460 = None
        exp_default_31 = torch.ops.aten.exp.default(mul_tensor_461);  mul_tensor_461 = None
        mul_tensor_462 = torch.ops.aten.mul.Tensor(exp_default_31, 0.3989422804014327);  exp_default_31 = None
        mul_tensor_463 = torch.ops.aten.mul.Tensor(to_dtype_142, mul_tensor_462);  to_dtype_142 = mul_tensor_462 = None
        add_tensor_90 = torch.ops.aten.add.Tensor(mul_tensor_459, mul_tensor_463);  mul_tensor_459 = mul_tensor_463 = None
        mul_tensor_464 = torch.ops.aten.mul.Tensor(to_dtype_141, add_tensor_90);  to_dtype_141 = add_tensor_90 = None
        to_dtype_143 = torch.ops.aten.to.dtype(mul_tensor_464, torch.float32);  mul_tensor_464 = None
        convolution_backward_default_49 = torch.ops.aten.convolution_backward.default(to_dtype_143, mul_tensor_39, view_default_71, [768], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_143 = mul_tensor_39 = view_default_71 = None
        getitem_417 = convolution_backward_default_49[0]
        getitem_418 = convolution_backward_default_49[1]
        getitem_419 = convolution_backward_default_49[2];  convolution_backward_default_49 = None
        view_default_273 = torch.ops.aten.view.default(getitem_418, [1, 768, 1536]);  getitem_418 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(view_default_273, view_default_69, view_default_70, None, None, getitem_70, getitem_71, True, 1e-05, [True, True, False]);  view_default_273 = view_default_69 = view_default_70 = getitem_70 = getitem_71 = None
        getitem_420 = native_batch_norm_backward_default_33[0]
        getitem_421 = native_batch_norm_backward_default_33[1]
        getitem_422 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        view_default_274 = torch.ops.aten.view.default(getitem_421, [768, 1, 1, 1]);  getitem_421 = None
        mul_tensor_465 = torch.ops.aten.mul.Tensor(view_default_274, 0.02551551815399144);  view_default_274 = None
        view_default_275 = torch.ops.aten.view.default(getitem_420, [768, 1536, 1, 1]);  getitem_420 = None
        mul_tensor_466 = torch.ops.aten.mul.Tensor(getitem_417, 0.9805806756909201);  getitem_417 = None
        mul_tensor_467 = torch.ops.aten.mul.Tensor(mul_tensor_466, 1.7015043497085571);  mul_tensor_466 = None
        to_dtype_144 = torch.ops.aten.to.dtype(mul_tensor_467, torch.float32);  mul_tensor_467 = None
        to_dtype_145 = torch.ops.aten.to.dtype(add_tensor_3, torch.float32);  add_tensor_3 = None
        mul_tensor_468 = torch.ops.aten.mul.Tensor(to_dtype_145, 0.7071067811865476)
        erf_default_32 = torch.ops.aten.erf.default(mul_tensor_468);  mul_tensor_468 = None
        add_tensor_91 = torch.ops.aten.add.Tensor(erf_default_32, 1);  erf_default_32 = None
        mul_tensor_469 = torch.ops.aten.mul.Tensor(add_tensor_91, 0.5);  add_tensor_91 = None
        mul_tensor_470 = torch.ops.aten.mul.Tensor(to_dtype_145, to_dtype_145)
        mul_tensor_471 = torch.ops.aten.mul.Tensor(mul_tensor_470, -0.5);  mul_tensor_470 = None
        exp_default_32 = torch.ops.aten.exp.default(mul_tensor_471);  mul_tensor_471 = None
        mul_tensor_472 = torch.ops.aten.mul.Tensor(exp_default_32, 0.3989422804014327);  exp_default_32 = None
        mul_tensor_473 = torch.ops.aten.mul.Tensor(to_dtype_145, mul_tensor_472);  to_dtype_145 = mul_tensor_472 = None
        add_tensor_92 = torch.ops.aten.add.Tensor(mul_tensor_469, mul_tensor_473);  mul_tensor_469 = mul_tensor_473 = None
        mul_tensor_474 = torch.ops.aten.mul.Tensor(to_dtype_144, add_tensor_92);  to_dtype_144 = add_tensor_92 = None
        to_dtype_146 = torch.ops.aten.to.dtype(mul_tensor_474, torch.float32);  mul_tensor_474 = None
        add_tensor_93 = torch.ops.aten.add.Tensor(add_tensor_83, to_dtype_146);  add_tensor_83 = to_dtype_146 = None
        mul_tensor_475 = torch.ops.aten.mul.Tensor(add_tensor_93, 0.2)
        mul_tensor_476 = torch.ops.aten.mul.Tensor(mul_tensor_475, clone_default_3);  clone_default_3 = None
        mul_tensor_477 = torch.ops.aten.mul.Tensor(mul_tensor_475, primals_82);  mul_tensor_475 = primals_82 = None
        sum_default_8 = torch.ops.aten.sum.default(mul_tensor_476);  mul_tensor_476 = None
        mul_tensor_478 = torch.ops.aten.mul.Tensor(mul_tensor_477, 2.0);  mul_tensor_477 = None
        mul_tensor_479 = torch.ops.aten.mul.Tensor(mul_tensor_478, convolution_default_28);  convolution_default_28 = None
        mul_tensor_480 = torch.ops.aten.mul.Tensor(mul_tensor_478, sigmoid_default_3);  mul_tensor_478 = None
        sum_dim_int_list_9 = torch.ops.aten.sum.dim_IntList(mul_tensor_479, [2, 3], True);  mul_tensor_479 = None
        to_dtype_147 = torch.ops.aten.to.dtype(sum_dim_int_list_9, torch.float32);  sum_dim_int_list_9 = None
        to_dtype_148 = torch.ops.aten.to.dtype(sigmoid_default_3, torch.float32);  sigmoid_default_3 = None
        rsub_scalar_8 = torch.ops.aten.rsub.Scalar(to_dtype_148, 1)
        mul_tensor_481 = torch.ops.aten.mul.Tensor(to_dtype_148, rsub_scalar_8);  to_dtype_148 = rsub_scalar_8 = None
        conj_physical_default_8 = torch.ops.aten.conj_physical.default(mul_tensor_481);  mul_tensor_481 = None
        mul_tensor_482 = torch.ops.aten.mul.Tensor(to_dtype_147, conj_physical_default_8);  to_dtype_147 = conj_physical_default_8 = None
        to_dtype_149 = torch.ops.aten.to.dtype(mul_tensor_482, torch.float32);  mul_tensor_482 = None
        convolution_backward_default_50 = torch.ops.aten.convolution_backward.default(to_dtype_149, relu__default_3, primals_66, [1536], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_149 = primals_66 = None
        getitem_423 = convolution_backward_default_50[0]
        getitem_424 = convolution_backward_default_50[1]
        getitem_425 = convolution_backward_default_50[2];  convolution_backward_default_50 = None
        to_dtype_150 = torch.ops.aten.to.dtype(getitem_423, torch.float32);  getitem_423 = None
        to_dtype_151 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_151, 0);  to_dtype_151 = None
        new_zeros_default_8 = torch.ops.aten.new_zeros.default(to_dtype_150, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_8, to_dtype_150);  le_scalar_8 = new_zeros_default_8 = to_dtype_150 = None
        to_dtype_152 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        convolution_backward_default_51 = torch.ops.aten.convolution_backward.default(to_dtype_152, mean_dim_3, primals_64, [768], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_152 = mean_dim_3 = primals_64 = None
        getitem_426 = convolution_backward_default_51[0]
        getitem_427 = convolution_backward_default_51[1]
        getitem_428 = convolution_backward_default_51[2];  convolution_backward_default_51 = None
        expand_default_9 = torch.ops.aten.expand.default(getitem_426, [128, 1536, 12, 12]);  getitem_426 = None
        div_scalar_9 = torch.ops.aten.div.Scalar(expand_default_9, 144);  expand_default_9 = None
        add_tensor_94 = torch.ops.aten.add.Tensor(mul_tensor_480, div_scalar_9);  mul_tensor_480 = div_scalar_9 = None
        convolution_backward_default_52 = torch.ops.aten.convolution_backward.default(add_tensor_94, mul__tensor_21, view_default_68, [1536], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  add_tensor_94 = mul__tensor_21 = view_default_68 = None
        getitem_429 = convolution_backward_default_52[0]
        getitem_430 = convolution_backward_default_52[1]
        getitem_431 = convolution_backward_default_52[2];  convolution_backward_default_52 = None
        view_default_276 = torch.ops.aten.view.default(getitem_430, [1, 1536, 768]);  getitem_430 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(view_default_276, view_default_66, view_default_67, None, None, getitem_67, getitem_68, True, 1e-05, [True, True, False]);  view_default_276 = view_default_66 = view_default_67 = getitem_67 = getitem_68 = None
        getitem_432 = native_batch_norm_backward_default_34[0]
        getitem_433 = native_batch_norm_backward_default_34[1]
        getitem_434 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        view_default_277 = torch.ops.aten.view.default(getitem_433, [1536, 1, 1, 1]);  getitem_433 = None
        mul_tensor_483 = torch.ops.aten.mul.Tensor(view_default_277, 0.03608439182435161);  view_default_277 = None
        view_default_278 = torch.ops.aten.view.default(getitem_432, [1536, 768, 1, 1]);  getitem_432 = None
        mul_tensor_484 = torch.ops.aten.mul.Tensor(getitem_429, 1.7015043497085571);  getitem_429 = None
        to_dtype_153 = torch.ops.aten.to.dtype(mul_tensor_484, torch.float32);  mul_tensor_484 = None
        to_dtype_154 = torch.ops.aten.to.dtype(convolution_default_27, torch.float32);  convolution_default_27 = None
        mul_tensor_485 = torch.ops.aten.mul.Tensor(to_dtype_154, 0.7071067811865476)
        erf_default_33 = torch.ops.aten.erf.default(mul_tensor_485);  mul_tensor_485 = None
        add_tensor_95 = torch.ops.aten.add.Tensor(erf_default_33, 1);  erf_default_33 = None
        mul_tensor_486 = torch.ops.aten.mul.Tensor(add_tensor_95, 0.5);  add_tensor_95 = None
        mul_tensor_487 = torch.ops.aten.mul.Tensor(to_dtype_154, to_dtype_154)
        mul_tensor_488 = torch.ops.aten.mul.Tensor(mul_tensor_487, -0.5);  mul_tensor_487 = None
        exp_default_33 = torch.ops.aten.exp.default(mul_tensor_488);  mul_tensor_488 = None
        mul_tensor_489 = torch.ops.aten.mul.Tensor(exp_default_33, 0.3989422804014327);  exp_default_33 = None
        mul_tensor_490 = torch.ops.aten.mul.Tensor(to_dtype_154, mul_tensor_489);  to_dtype_154 = mul_tensor_489 = None
        add_tensor_96 = torch.ops.aten.add.Tensor(mul_tensor_486, mul_tensor_490);  mul_tensor_486 = mul_tensor_490 = None
        mul_tensor_491 = torch.ops.aten.mul.Tensor(to_dtype_153, add_tensor_96);  to_dtype_153 = add_tensor_96 = None
        to_dtype_155 = torch.ops.aten.to.dtype(mul_tensor_491, torch.float32);  mul_tensor_491 = None
        convolution_backward_default_53 = torch.ops.aten.convolution_backward.default(to_dtype_155, mul__tensor_20, view_default_65, [768], [1, 1], [1, 1], [1, 1], False, [0, 0], 6, [True, True, True]);  to_dtype_155 = mul__tensor_20 = view_default_65 = None
        getitem_435 = convolution_backward_default_53[0]
        getitem_436 = convolution_backward_default_53[1]
        getitem_437 = convolution_backward_default_53[2];  convolution_backward_default_53 = None
        view_default_279 = torch.ops.aten.view.default(getitem_436, [1, 768, 1152]);  getitem_436 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(view_default_279, view_default_63, view_default_64, None, None, getitem_64, getitem_65, True, 1e-05, [True, True, False]);  view_default_279 = view_default_63 = view_default_64 = getitem_64 = getitem_65 = None
        getitem_438 = native_batch_norm_backward_default_35[0]
        getitem_439 = native_batch_norm_backward_default_35[1]
        getitem_440 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        view_default_280 = torch.ops.aten.view.default(getitem_439, [768, 1, 1, 1]);  getitem_439 = None
        mul_tensor_492 = torch.ops.aten.mul.Tensor(view_default_280, 0.02946278254943948);  view_default_280 = None
        view_default_281 = torch.ops.aten.view.default(getitem_438, [768, 128, 3, 3]);  getitem_438 = None
        mul_tensor_493 = torch.ops.aten.mul.Tensor(getitem_435, 1.7015043497085571);  getitem_435 = None
        to_dtype_156 = torch.ops.aten.to.dtype(mul_tensor_493, torch.float32);  mul_tensor_493 = None
        to_dtype_157 = torch.ops.aten.to.dtype(convolution_default_26, torch.float32);  convolution_default_26 = None
        mul_tensor_494 = torch.ops.aten.mul.Tensor(to_dtype_157, 0.7071067811865476)
        erf_default_34 = torch.ops.aten.erf.default(mul_tensor_494);  mul_tensor_494 = None
        add_tensor_97 = torch.ops.aten.add.Tensor(erf_default_34, 1);  erf_default_34 = None
        mul_tensor_495 = torch.ops.aten.mul.Tensor(add_tensor_97, 0.5);  add_tensor_97 = None
        mul_tensor_496 = torch.ops.aten.mul.Tensor(to_dtype_157, to_dtype_157)
        mul_tensor_497 = torch.ops.aten.mul.Tensor(mul_tensor_496, -0.5);  mul_tensor_496 = None
        exp_default_34 = torch.ops.aten.exp.default(mul_tensor_497);  mul_tensor_497 = None
        mul_tensor_498 = torch.ops.aten.mul.Tensor(exp_default_34, 0.3989422804014327);  exp_default_34 = None
        mul_tensor_499 = torch.ops.aten.mul.Tensor(to_dtype_157, mul_tensor_498);  to_dtype_157 = mul_tensor_498 = None
        add_tensor_98 = torch.ops.aten.add.Tensor(mul_tensor_495, mul_tensor_499);  mul_tensor_495 = mul_tensor_499 = None
        mul_tensor_500 = torch.ops.aten.mul.Tensor(to_dtype_156, add_tensor_98);  to_dtype_156 = add_tensor_98 = None
        to_dtype_158 = torch.ops.aten.to.dtype(mul_tensor_500, torch.float32);  mul_tensor_500 = None
        convolution_backward_default_54 = torch.ops.aten.convolution_backward.default(to_dtype_158, constant_pad_nd_default_3, view_default_62, [768], [2, 2], [0, 0], [1, 1], False, [0, 0], 6, [True, True, True]);  to_dtype_158 = constant_pad_nd_default_3 = view_default_62 = None
        getitem_441 = convolution_backward_default_54[0]
        getitem_442 = convolution_backward_default_54[1]
        getitem_443 = convolution_backward_default_54[2];  convolution_backward_default_54 = None
        view_default_282 = torch.ops.aten.view.default(getitem_442, [1, 768, 1152]);  getitem_442 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(view_default_282, view_default_60, view_default_61, None, None, getitem_61, getitem_62, True, 1e-05, [True, True, False]);  view_default_282 = view_default_60 = view_default_61 = getitem_61 = getitem_62 = None
        getitem_444 = native_batch_norm_backward_default_36[0]
        getitem_445 = native_batch_norm_backward_default_36[1]
        getitem_446 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        view_default_283 = torch.ops.aten.view.default(getitem_445, [768, 1, 1, 1]);  getitem_445 = None
        mul_tensor_501 = torch.ops.aten.mul.Tensor(view_default_283, 0.02946278254943948);  view_default_283 = None
        view_default_284 = torch.ops.aten.view.default(getitem_444, [768, 128, 3, 3]);  getitem_444 = None
        constant_pad_nd_default_6 = torch.ops.aten.constant_pad_nd.default(getitem_441, [0, -1, 0, -1]);  getitem_441 = None
        mul_tensor_502 = torch.ops.aten.mul.Tensor(constant_pad_nd_default_6, 1.7015043497085571);  constant_pad_nd_default_6 = None
        to_dtype_159 = torch.ops.aten.to.dtype(mul_tensor_502, torch.float32);  mul_tensor_502 = None
        to_dtype_160 = torch.ops.aten.to.dtype(convolution_default_25, torch.float32);  convolution_default_25 = None
        mul_tensor_503 = torch.ops.aten.mul.Tensor(to_dtype_160, 0.7071067811865476)
        erf_default_35 = torch.ops.aten.erf.default(mul_tensor_503);  mul_tensor_503 = None
        add_tensor_99 = torch.ops.aten.add.Tensor(erf_default_35, 1);  erf_default_35 = None
        mul_tensor_504 = torch.ops.aten.mul.Tensor(add_tensor_99, 0.5);  add_tensor_99 = None
        mul_tensor_505 = torch.ops.aten.mul.Tensor(to_dtype_160, to_dtype_160)
        mul_tensor_506 = torch.ops.aten.mul.Tensor(mul_tensor_505, -0.5);  mul_tensor_505 = None
        exp_default_35 = torch.ops.aten.exp.default(mul_tensor_506);  mul_tensor_506 = None
        mul_tensor_507 = torch.ops.aten.mul.Tensor(exp_default_35, 0.3989422804014327);  exp_default_35 = None
        mul_tensor_508 = torch.ops.aten.mul.Tensor(to_dtype_160, mul_tensor_507);  to_dtype_160 = mul_tensor_507 = None
        add_tensor_100 = torch.ops.aten.add.Tensor(mul_tensor_504, mul_tensor_508);  mul_tensor_504 = mul_tensor_508 = None
        mul_tensor_509 = torch.ops.aten.mul.Tensor(to_dtype_159, add_tensor_100);  to_dtype_159 = add_tensor_100 = None
        to_dtype_161 = torch.ops.aten.to.dtype(mul_tensor_509, torch.float32);  mul_tensor_509 = None
        convolution_backward_default_55 = torch.ops.aten.convolution_backward.default(to_dtype_161, mul_tensor_30, view_default_59, [768], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_161 = view_default_59 = None
        getitem_447 = convolution_backward_default_55[0]
        getitem_448 = convolution_backward_default_55[1]
        getitem_449 = convolution_backward_default_55[2];  convolution_backward_default_55 = None
        view_default_285 = torch.ops.aten.view.default(getitem_448, [1, 768, 512]);  getitem_448 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(view_default_285, view_default_57, view_default_58, None, None, getitem_58, getitem_59, True, 1e-05, [True, True, False]);  view_default_285 = view_default_57 = view_default_58 = getitem_58 = getitem_59 = None
        getitem_450 = native_batch_norm_backward_default_37[0]
        getitem_451 = native_batch_norm_backward_default_37[1]
        getitem_452 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        view_default_286 = torch.ops.aten.view.default(getitem_451, [768, 1, 1, 1]);  getitem_451 = None
        mul_tensor_510 = torch.ops.aten.mul.Tensor(view_default_286, 0.04419417382415922);  view_default_286 = None
        view_default_287 = torch.ops.aten.view.default(getitem_450, [768, 512, 1, 1]);  getitem_450 = None
        convolution_backward_default_56 = torch.ops.aten.convolution_backward.default(add_tensor_93, avg_pool2d_default_1, view_default_56, [1536], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  add_tensor_93 = avg_pool2d_default_1 = view_default_56 = None
        getitem_453 = convolution_backward_default_56[0]
        getitem_454 = convolution_backward_default_56[1]
        getitem_455 = convolution_backward_default_56[2];  convolution_backward_default_56 = None
        view_default_288 = torch.ops.aten.view.default(getitem_454, [1, 1536, 512]);  getitem_454 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(view_default_288, view_default_54, view_default_55, None, None, getitem_55, getitem_56, True, 1e-05, [True, True, False]);  view_default_288 = view_default_54 = view_default_55 = getitem_55 = getitem_56 = None
        getitem_456 = native_batch_norm_backward_default_38[0]
        getitem_457 = native_batch_norm_backward_default_38[1]
        getitem_458 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        view_default_289 = torch.ops.aten.view.default(getitem_457, [1536, 1, 1, 1]);  getitem_457 = None
        mul_tensor_511 = torch.ops.aten.mul.Tensor(view_default_289, 0.04419417382415922);  view_default_289 = None
        view_default_290 = torch.ops.aten.view.default(getitem_456, [1536, 512, 1, 1]);  getitem_456 = None
        avg_pool2d_backward_default_1 = torch.ops.aten.avg_pool2d_backward.default(getitem_453, mul_tensor_30, [2, 2], [2, 2], [0, 0], True, False, None);  getitem_453 = mul_tensor_30 = None
        add_tensor_101 = torch.ops.aten.add.Tensor(getitem_447, avg_pool2d_backward_default_1);  getitem_447 = avg_pool2d_backward_default_1 = None
        mul_tensor_512 = torch.ops.aten.mul.Tensor(add_tensor_101, 0.9622504486493761);  add_tensor_101 = None
        mul_tensor_513 = torch.ops.aten.mul.Tensor(mul_tensor_512, 1.7015043497085571);  mul_tensor_512 = None
        to_dtype_162 = torch.ops.aten.to.dtype(mul_tensor_513, torch.float32);  mul_tensor_513 = None
        to_dtype_163 = torch.ops.aten.to.dtype(add_tensor_2, torch.float32);  add_tensor_2 = None
        mul_tensor_514 = torch.ops.aten.mul.Tensor(to_dtype_163, 0.7071067811865476)
        erf_default_36 = torch.ops.aten.erf.default(mul_tensor_514);  mul_tensor_514 = None
        add_tensor_102 = torch.ops.aten.add.Tensor(erf_default_36, 1);  erf_default_36 = None
        mul_tensor_515 = torch.ops.aten.mul.Tensor(add_tensor_102, 0.5);  add_tensor_102 = None
        mul_tensor_516 = torch.ops.aten.mul.Tensor(to_dtype_163, to_dtype_163)
        mul_tensor_517 = torch.ops.aten.mul.Tensor(mul_tensor_516, -0.5);  mul_tensor_516 = None
        exp_default_36 = torch.ops.aten.exp.default(mul_tensor_517);  mul_tensor_517 = None
        mul_tensor_518 = torch.ops.aten.mul.Tensor(exp_default_36, 0.3989422804014327);  exp_default_36 = None
        mul_tensor_519 = torch.ops.aten.mul.Tensor(to_dtype_163, mul_tensor_518);  to_dtype_163 = mul_tensor_518 = None
        add_tensor_103 = torch.ops.aten.add.Tensor(mul_tensor_515, mul_tensor_519);  mul_tensor_515 = mul_tensor_519 = None
        mul_tensor_520 = torch.ops.aten.mul.Tensor(to_dtype_162, add_tensor_103);  to_dtype_162 = add_tensor_103 = None
        to_dtype_164 = torch.ops.aten.to.dtype(mul_tensor_520, torch.float32);  mul_tensor_520 = None
        mul_tensor_521 = torch.ops.aten.mul.Tensor(to_dtype_164, 0.2)
        mul_tensor_522 = torch.ops.aten.mul.Tensor(mul_tensor_521, clone_default_2);  clone_default_2 = None
        mul_tensor_523 = torch.ops.aten.mul.Tensor(mul_tensor_521, primals_62);  mul_tensor_521 = primals_62 = None
        sum_default_9 = torch.ops.aten.sum.default(mul_tensor_522);  mul_tensor_522 = None
        mul_tensor_524 = torch.ops.aten.mul.Tensor(mul_tensor_523, 2.0);  mul_tensor_523 = None
        mul_tensor_525 = torch.ops.aten.mul.Tensor(mul_tensor_524, convolution_default_21);  convolution_default_21 = None
        mul_tensor_526 = torch.ops.aten.mul.Tensor(mul_tensor_524, sigmoid_default_2);  mul_tensor_524 = None
        sum_dim_int_list_10 = torch.ops.aten.sum.dim_IntList(mul_tensor_525, [2, 3], True);  mul_tensor_525 = None
        to_dtype_165 = torch.ops.aten.to.dtype(sum_dim_int_list_10, torch.float32);  sum_dim_int_list_10 = None
        to_dtype_166 = torch.ops.aten.to.dtype(sigmoid_default_2, torch.float32);  sigmoid_default_2 = None
        rsub_scalar_9 = torch.ops.aten.rsub.Scalar(to_dtype_166, 1)
        mul_tensor_527 = torch.ops.aten.mul.Tensor(to_dtype_166, rsub_scalar_9);  to_dtype_166 = rsub_scalar_9 = None
        conj_physical_default_9 = torch.ops.aten.conj_physical.default(mul_tensor_527);  mul_tensor_527 = None
        mul_tensor_528 = torch.ops.aten.mul.Tensor(to_dtype_165, conj_physical_default_9);  to_dtype_165 = conj_physical_default_9 = None
        to_dtype_167 = torch.ops.aten.to.dtype(mul_tensor_528, torch.float32);  mul_tensor_528 = None
        convolution_backward_default_57 = torch.ops.aten.convolution_backward.default(to_dtype_167, relu__default_2, primals_49, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_167 = primals_49 = None
        getitem_459 = convolution_backward_default_57[0]
        getitem_460 = convolution_backward_default_57[1]
        getitem_461 = convolution_backward_default_57[2];  convolution_backward_default_57 = None
        to_dtype_168 = torch.ops.aten.to.dtype(getitem_459, torch.float32);  getitem_459 = None
        to_dtype_169 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_169, 0);  to_dtype_169 = None
        new_zeros_default_9 = torch.ops.aten.new_zeros.default(to_dtype_168, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_9, to_dtype_168);  le_scalar_9 = new_zeros_default_9 = to_dtype_168 = None
        to_dtype_170 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        convolution_backward_default_58 = torch.ops.aten.convolution_backward.default(to_dtype_170, mean_dim_2, primals_47, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_170 = mean_dim_2 = primals_47 = None
        getitem_462 = convolution_backward_default_58[0]
        getitem_463 = convolution_backward_default_58[1]
        getitem_464 = convolution_backward_default_58[2];  convolution_backward_default_58 = None
        expand_default_10 = torch.ops.aten.expand.default(getitem_462, [128, 512, 24, 24]);  getitem_462 = None
        div_scalar_10 = torch.ops.aten.div.Scalar(expand_default_10, 576);  expand_default_10 = None
        add_tensor_104 = torch.ops.aten.add.Tensor(mul_tensor_526, div_scalar_10);  mul_tensor_526 = div_scalar_10 = None
        convolution_backward_default_59 = torch.ops.aten.convolution_backward.default(add_tensor_104, mul__tensor_16, view_default_53, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  add_tensor_104 = mul__tensor_16 = view_default_53 = None
        getitem_465 = convolution_backward_default_59[0]
        getitem_466 = convolution_backward_default_59[1]
        getitem_467 = convolution_backward_default_59[2];  convolution_backward_default_59 = None
        view_default_291 = torch.ops.aten.view.default(getitem_466, [1, 512, 256]);  getitem_466 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(view_default_291, view_default_51, view_default_52, None, None, getitem_52, getitem_53, True, 1e-05, [True, True, False]);  view_default_291 = view_default_51 = view_default_52 = getitem_52 = getitem_53 = None
        getitem_468 = native_batch_norm_backward_default_39[0]
        getitem_469 = native_batch_norm_backward_default_39[1]
        getitem_470 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        view_default_292 = torch.ops.aten.view.default(getitem_469, [512, 1, 1, 1]);  getitem_469 = None
        mul_tensor_529 = torch.ops.aten.mul.Tensor(view_default_292, 0.0625);  view_default_292 = None
        view_default_293 = torch.ops.aten.view.default(getitem_468, [512, 256, 1, 1]);  getitem_468 = None
        mul_tensor_530 = torch.ops.aten.mul.Tensor(getitem_465, 1.7015043497085571);  getitem_465 = None
        to_dtype_171 = torch.ops.aten.to.dtype(mul_tensor_530, torch.float32);  mul_tensor_530 = None
        to_dtype_172 = torch.ops.aten.to.dtype(convolution_default_20, torch.float32);  convolution_default_20 = None
        mul_tensor_531 = torch.ops.aten.mul.Tensor(to_dtype_172, 0.7071067811865476)
        erf_default_37 = torch.ops.aten.erf.default(mul_tensor_531);  mul_tensor_531 = None
        add_tensor_105 = torch.ops.aten.add.Tensor(erf_default_37, 1);  erf_default_37 = None
        mul_tensor_532 = torch.ops.aten.mul.Tensor(add_tensor_105, 0.5);  add_tensor_105 = None
        mul_tensor_533 = torch.ops.aten.mul.Tensor(to_dtype_172, to_dtype_172)
        mul_tensor_534 = torch.ops.aten.mul.Tensor(mul_tensor_533, -0.5);  mul_tensor_533 = None
        exp_default_37 = torch.ops.aten.exp.default(mul_tensor_534);  mul_tensor_534 = None
        mul_tensor_535 = torch.ops.aten.mul.Tensor(exp_default_37, 0.3989422804014327);  exp_default_37 = None
        mul_tensor_536 = torch.ops.aten.mul.Tensor(to_dtype_172, mul_tensor_535);  to_dtype_172 = mul_tensor_535 = None
        add_tensor_106 = torch.ops.aten.add.Tensor(mul_tensor_532, mul_tensor_536);  mul_tensor_532 = mul_tensor_536 = None
        mul_tensor_537 = torch.ops.aten.mul.Tensor(to_dtype_171, add_tensor_106);  to_dtype_171 = add_tensor_106 = None
        to_dtype_173 = torch.ops.aten.to.dtype(mul_tensor_537, torch.float32);  mul_tensor_537 = None
        convolution_backward_default_60 = torch.ops.aten.convolution_backward.default(to_dtype_173, mul__tensor_15, view_default_50, [256], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, True]);  to_dtype_173 = mul__tensor_15 = view_default_50 = None
        getitem_471 = convolution_backward_default_60[0]
        getitem_472 = convolution_backward_default_60[1]
        getitem_473 = convolution_backward_default_60[2];  convolution_backward_default_60 = None
        view_default_294 = torch.ops.aten.view.default(getitem_472, [1, 256, 1152]);  getitem_472 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(view_default_294, view_default_48, view_default_49, None, None, getitem_49, getitem_50, True, 1e-05, [True, True, False]);  view_default_294 = view_default_48 = view_default_49 = getitem_49 = getitem_50 = None
        getitem_474 = native_batch_norm_backward_default_40[0]
        getitem_475 = native_batch_norm_backward_default_40[1]
        getitem_476 = native_batch_norm_backward_default_40[2];  native_batch_norm_backward_default_40 = None
        view_default_295 = torch.ops.aten.view.default(getitem_475, [256, 1, 1, 1]);  getitem_475 = None
        mul_tensor_538 = torch.ops.aten.mul.Tensor(view_default_295, 0.02946278254943948);  view_default_295 = None
        view_default_296 = torch.ops.aten.view.default(getitem_474, [256, 128, 3, 3]);  getitem_474 = None
        mul_tensor_539 = torch.ops.aten.mul.Tensor(getitem_471, 1.7015043497085571);  getitem_471 = None
        to_dtype_174 = torch.ops.aten.to.dtype(mul_tensor_539, torch.float32);  mul_tensor_539 = None
        to_dtype_175 = torch.ops.aten.to.dtype(convolution_default_19, torch.float32);  convolution_default_19 = None
        mul_tensor_540 = torch.ops.aten.mul.Tensor(to_dtype_175, 0.7071067811865476)
        erf_default_38 = torch.ops.aten.erf.default(mul_tensor_540);  mul_tensor_540 = None
        add_tensor_107 = torch.ops.aten.add.Tensor(erf_default_38, 1);  erf_default_38 = None
        mul_tensor_541 = torch.ops.aten.mul.Tensor(add_tensor_107, 0.5);  add_tensor_107 = None
        mul_tensor_542 = torch.ops.aten.mul.Tensor(to_dtype_175, to_dtype_175)
        mul_tensor_543 = torch.ops.aten.mul.Tensor(mul_tensor_542, -0.5);  mul_tensor_542 = None
        exp_default_38 = torch.ops.aten.exp.default(mul_tensor_543);  mul_tensor_543 = None
        mul_tensor_544 = torch.ops.aten.mul.Tensor(exp_default_38, 0.3989422804014327);  exp_default_38 = None
        mul_tensor_545 = torch.ops.aten.mul.Tensor(to_dtype_175, mul_tensor_544);  to_dtype_175 = mul_tensor_544 = None
        add_tensor_108 = torch.ops.aten.add.Tensor(mul_tensor_541, mul_tensor_545);  mul_tensor_541 = mul_tensor_545 = None
        mul_tensor_546 = torch.ops.aten.mul.Tensor(to_dtype_174, add_tensor_108);  to_dtype_174 = add_tensor_108 = None
        to_dtype_176 = torch.ops.aten.to.dtype(mul_tensor_546, torch.float32);  mul_tensor_546 = None
        convolution_backward_default_61 = torch.ops.aten.convolution_backward.default(to_dtype_176, mul__tensor_14, view_default_47, [256], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, True]);  to_dtype_176 = mul__tensor_14 = view_default_47 = None
        getitem_477 = convolution_backward_default_61[0]
        getitem_478 = convolution_backward_default_61[1]
        getitem_479 = convolution_backward_default_61[2];  convolution_backward_default_61 = None
        view_default_297 = torch.ops.aten.view.default(getitem_478, [1, 256, 1152]);  getitem_478 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(view_default_297, view_default_45, view_default_46, None, None, getitem_46, getitem_47, True, 1e-05, [True, True, False]);  view_default_297 = view_default_45 = view_default_46 = getitem_46 = getitem_47 = None
        getitem_480 = native_batch_norm_backward_default_41[0]
        getitem_481 = native_batch_norm_backward_default_41[1]
        getitem_482 = native_batch_norm_backward_default_41[2];  native_batch_norm_backward_default_41 = None
        view_default_298 = torch.ops.aten.view.default(getitem_481, [256, 1, 1, 1]);  getitem_481 = None
        mul_tensor_547 = torch.ops.aten.mul.Tensor(view_default_298, 0.02946278254943948);  view_default_298 = None
        view_default_299 = torch.ops.aten.view.default(getitem_480, [256, 128, 3, 3]);  getitem_480 = None
        mul_tensor_548 = torch.ops.aten.mul.Tensor(getitem_477, 1.7015043497085571);  getitem_477 = None
        to_dtype_177 = torch.ops.aten.to.dtype(mul_tensor_548, torch.float32);  mul_tensor_548 = None
        to_dtype_178 = torch.ops.aten.to.dtype(convolution_default_18, torch.float32);  convolution_default_18 = None
        mul_tensor_549 = torch.ops.aten.mul.Tensor(to_dtype_178, 0.7071067811865476)
        erf_default_39 = torch.ops.aten.erf.default(mul_tensor_549);  mul_tensor_549 = None
        add_tensor_109 = torch.ops.aten.add.Tensor(erf_default_39, 1);  erf_default_39 = None
        mul_tensor_550 = torch.ops.aten.mul.Tensor(add_tensor_109, 0.5);  add_tensor_109 = None
        mul_tensor_551 = torch.ops.aten.mul.Tensor(to_dtype_178, to_dtype_178)
        mul_tensor_552 = torch.ops.aten.mul.Tensor(mul_tensor_551, -0.5);  mul_tensor_551 = None
        exp_default_39 = torch.ops.aten.exp.default(mul_tensor_552);  mul_tensor_552 = None
        mul_tensor_553 = torch.ops.aten.mul.Tensor(exp_default_39, 0.3989422804014327);  exp_default_39 = None
        mul_tensor_554 = torch.ops.aten.mul.Tensor(to_dtype_178, mul_tensor_553);  to_dtype_178 = mul_tensor_553 = None
        add_tensor_110 = torch.ops.aten.add.Tensor(mul_tensor_550, mul_tensor_554);  mul_tensor_550 = mul_tensor_554 = None
        mul_tensor_555 = torch.ops.aten.mul.Tensor(to_dtype_177, add_tensor_110);  to_dtype_177 = add_tensor_110 = None
        to_dtype_179 = torch.ops.aten.to.dtype(mul_tensor_555, torch.float32);  mul_tensor_555 = None
        convolution_backward_default_62 = torch.ops.aten.convolution_backward.default(to_dtype_179, mul_tensor_22, view_default_44, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_179 = mul_tensor_22 = view_default_44 = None
        getitem_483 = convolution_backward_default_62[0]
        getitem_484 = convolution_backward_default_62[1]
        getitem_485 = convolution_backward_default_62[2];  convolution_backward_default_62 = None
        view_default_300 = torch.ops.aten.view.default(getitem_484, [1, 256, 512]);  getitem_484 = None
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(view_default_300, view_default_42, view_default_43, None, None, getitem_43, getitem_44, True, 1e-05, [True, True, False]);  view_default_300 = view_default_42 = view_default_43 = getitem_43 = getitem_44 = None
        getitem_486 = native_batch_norm_backward_default_42[0]
        getitem_487 = native_batch_norm_backward_default_42[1]
        getitem_488 = native_batch_norm_backward_default_42[2];  native_batch_norm_backward_default_42 = None
        view_default_301 = torch.ops.aten.view.default(getitem_487, [256, 1, 1, 1]);  getitem_487 = None
        mul_tensor_556 = torch.ops.aten.mul.Tensor(view_default_301, 0.04419417382415922);  view_default_301 = None
        view_default_302 = torch.ops.aten.view.default(getitem_486, [256, 512, 1, 1]);  getitem_486 = None
        mul_tensor_557 = torch.ops.aten.mul.Tensor(getitem_483, 0.9805806756909201);  getitem_483 = None
        mul_tensor_558 = torch.ops.aten.mul.Tensor(mul_tensor_557, 1.7015043497085571);  mul_tensor_557 = None
        to_dtype_180 = torch.ops.aten.to.dtype(mul_tensor_558, torch.float32);  mul_tensor_558 = None
        to_dtype_181 = torch.ops.aten.to.dtype(add_tensor_1, torch.float32);  add_tensor_1 = None
        mul_tensor_559 = torch.ops.aten.mul.Tensor(to_dtype_181, 0.7071067811865476)
        erf_default_40 = torch.ops.aten.erf.default(mul_tensor_559);  mul_tensor_559 = None
        add_tensor_111 = torch.ops.aten.add.Tensor(erf_default_40, 1);  erf_default_40 = None
        mul_tensor_560 = torch.ops.aten.mul.Tensor(add_tensor_111, 0.5);  add_tensor_111 = None
        mul_tensor_561 = torch.ops.aten.mul.Tensor(to_dtype_181, to_dtype_181)
        mul_tensor_562 = torch.ops.aten.mul.Tensor(mul_tensor_561, -0.5);  mul_tensor_561 = None
        exp_default_40 = torch.ops.aten.exp.default(mul_tensor_562);  mul_tensor_562 = None
        mul_tensor_563 = torch.ops.aten.mul.Tensor(exp_default_40, 0.3989422804014327);  exp_default_40 = None
        mul_tensor_564 = torch.ops.aten.mul.Tensor(to_dtype_181, mul_tensor_563);  to_dtype_181 = mul_tensor_563 = None
        add_tensor_112 = torch.ops.aten.add.Tensor(mul_tensor_560, mul_tensor_564);  mul_tensor_560 = mul_tensor_564 = None
        mul_tensor_565 = torch.ops.aten.mul.Tensor(to_dtype_180, add_tensor_112);  to_dtype_180 = add_tensor_112 = None
        to_dtype_182 = torch.ops.aten.to.dtype(mul_tensor_565, torch.float32);  mul_tensor_565 = None
        add_tensor_113 = torch.ops.aten.add.Tensor(to_dtype_164, to_dtype_182);  to_dtype_164 = to_dtype_182 = None
        mul_tensor_566 = torch.ops.aten.mul.Tensor(add_tensor_113, 0.2)
        mul_tensor_567 = torch.ops.aten.mul.Tensor(mul_tensor_566, clone_default_1);  clone_default_1 = None
        mul_tensor_568 = torch.ops.aten.mul.Tensor(mul_tensor_566, primals_45);  mul_tensor_566 = primals_45 = None
        sum_default_10 = torch.ops.aten.sum.default(mul_tensor_567);  mul_tensor_567 = None
        mul_tensor_569 = torch.ops.aten.mul.Tensor(mul_tensor_568, 2.0);  mul_tensor_568 = None
        mul_tensor_570 = torch.ops.aten.mul.Tensor(mul_tensor_569, convolution_default_15);  convolution_default_15 = None
        mul_tensor_571 = torch.ops.aten.mul.Tensor(mul_tensor_569, sigmoid_default_1);  mul_tensor_569 = None
        sum_dim_int_list_11 = torch.ops.aten.sum.dim_IntList(mul_tensor_570, [2, 3], True);  mul_tensor_570 = None
        to_dtype_183 = torch.ops.aten.to.dtype(sum_dim_int_list_11, torch.float32);  sum_dim_int_list_11 = None
        to_dtype_184 = torch.ops.aten.to.dtype(sigmoid_default_1, torch.float32);  sigmoid_default_1 = None
        rsub_scalar_10 = torch.ops.aten.rsub.Scalar(to_dtype_184, 1)
        mul_tensor_572 = torch.ops.aten.mul.Tensor(to_dtype_184, rsub_scalar_10);  to_dtype_184 = rsub_scalar_10 = None
        conj_physical_default_10 = torch.ops.aten.conj_physical.default(mul_tensor_572);  mul_tensor_572 = None
        mul_tensor_573 = torch.ops.aten.mul.Tensor(to_dtype_183, conj_physical_default_10);  to_dtype_183 = conj_physical_default_10 = None
        to_dtype_185 = torch.ops.aten.to.dtype(mul_tensor_573, torch.float32);  mul_tensor_573 = None
        convolution_backward_default_63 = torch.ops.aten.convolution_backward.default(to_dtype_185, relu__default_1, primals_29, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_185 = primals_29 = None
        getitem_489 = convolution_backward_default_63[0]
        getitem_490 = convolution_backward_default_63[1]
        getitem_491 = convolution_backward_default_63[2];  convolution_backward_default_63 = None
        to_dtype_186 = torch.ops.aten.to.dtype(getitem_489, torch.float32);  getitem_489 = None
        to_dtype_187 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_187, 0);  to_dtype_187 = None
        new_zeros_default_10 = torch.ops.aten.new_zeros.default(to_dtype_186, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_10, to_dtype_186);  le_scalar_10 = new_zeros_default_10 = to_dtype_186 = None
        to_dtype_188 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        convolution_backward_default_64 = torch.ops.aten.convolution_backward.default(to_dtype_188, mean_dim_1, primals_27, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_188 = mean_dim_1 = primals_27 = None
        getitem_492 = convolution_backward_default_64[0]
        getitem_493 = convolution_backward_default_64[1]
        getitem_494 = convolution_backward_default_64[2];  convolution_backward_default_64 = None
        expand_default_11 = torch.ops.aten.expand.default(getitem_492, [128, 512, 24, 24]);  getitem_492 = None
        div_scalar_11 = torch.ops.aten.div.Scalar(expand_default_11, 576);  expand_default_11 = None
        add_tensor_114 = torch.ops.aten.add.Tensor(mul_tensor_571, div_scalar_11);  mul_tensor_571 = div_scalar_11 = None
        convolution_backward_default_65 = torch.ops.aten.convolution_backward.default(add_tensor_114, mul__tensor_11, view_default_41, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  add_tensor_114 = mul__tensor_11 = view_default_41 = None
        getitem_495 = convolution_backward_default_65[0]
        getitem_496 = convolution_backward_default_65[1]
        getitem_497 = convolution_backward_default_65[2];  convolution_backward_default_65 = None
        view_default_303 = torch.ops.aten.view.default(getitem_496, [1, 512, 256]);  getitem_496 = None
        native_batch_norm_backward_default_43 = torch.ops.aten.native_batch_norm_backward.default(view_default_303, view_default_39, view_default_40, None, None, getitem_40, getitem_41, True, 1e-05, [True, True, False]);  view_default_303 = view_default_39 = view_default_40 = getitem_40 = getitem_41 = None
        getitem_498 = native_batch_norm_backward_default_43[0]
        getitem_499 = native_batch_norm_backward_default_43[1]
        getitem_500 = native_batch_norm_backward_default_43[2];  native_batch_norm_backward_default_43 = None
        view_default_304 = torch.ops.aten.view.default(getitem_499, [512, 1, 1, 1]);  getitem_499 = None
        mul_tensor_574 = torch.ops.aten.mul.Tensor(view_default_304, 0.0625);  view_default_304 = None
        view_default_305 = torch.ops.aten.view.default(getitem_498, [512, 256, 1, 1]);  getitem_498 = None
        mul_tensor_575 = torch.ops.aten.mul.Tensor(getitem_495, 1.7015043497085571);  getitem_495 = None
        to_dtype_189 = torch.ops.aten.to.dtype(mul_tensor_575, torch.float32);  mul_tensor_575 = None
        to_dtype_190 = torch.ops.aten.to.dtype(convolution_default_14, torch.float32);  convolution_default_14 = None
        mul_tensor_576 = torch.ops.aten.mul.Tensor(to_dtype_190, 0.7071067811865476)
        erf_default_41 = torch.ops.aten.erf.default(mul_tensor_576);  mul_tensor_576 = None
        add_tensor_115 = torch.ops.aten.add.Tensor(erf_default_41, 1);  erf_default_41 = None
        mul_tensor_577 = torch.ops.aten.mul.Tensor(add_tensor_115, 0.5);  add_tensor_115 = None
        mul_tensor_578 = torch.ops.aten.mul.Tensor(to_dtype_190, to_dtype_190)
        mul_tensor_579 = torch.ops.aten.mul.Tensor(mul_tensor_578, -0.5);  mul_tensor_578 = None
        exp_default_41 = torch.ops.aten.exp.default(mul_tensor_579);  mul_tensor_579 = None
        mul_tensor_580 = torch.ops.aten.mul.Tensor(exp_default_41, 0.3989422804014327);  exp_default_41 = None
        mul_tensor_581 = torch.ops.aten.mul.Tensor(to_dtype_190, mul_tensor_580);  to_dtype_190 = mul_tensor_580 = None
        add_tensor_116 = torch.ops.aten.add.Tensor(mul_tensor_577, mul_tensor_581);  mul_tensor_577 = mul_tensor_581 = None
        mul_tensor_582 = torch.ops.aten.mul.Tensor(to_dtype_189, add_tensor_116);  to_dtype_189 = add_tensor_116 = None
        to_dtype_191 = torch.ops.aten.to.dtype(mul_tensor_582, torch.float32);  mul_tensor_582 = None
        convolution_backward_default_66 = torch.ops.aten.convolution_backward.default(to_dtype_191, mul__tensor_10, view_default_38, [256], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, True]);  to_dtype_191 = mul__tensor_10 = view_default_38 = None
        getitem_501 = convolution_backward_default_66[0]
        getitem_502 = convolution_backward_default_66[1]
        getitem_503 = convolution_backward_default_66[2];  convolution_backward_default_66 = None
        view_default_306 = torch.ops.aten.view.default(getitem_502, [1, 256, 1152]);  getitem_502 = None
        native_batch_norm_backward_default_44 = torch.ops.aten.native_batch_norm_backward.default(view_default_306, view_default_36, view_default_37, None, None, getitem_37, getitem_38, True, 1e-05, [True, True, False]);  view_default_306 = view_default_36 = view_default_37 = getitem_37 = getitem_38 = None
        getitem_504 = native_batch_norm_backward_default_44[0]
        getitem_505 = native_batch_norm_backward_default_44[1]
        getitem_506 = native_batch_norm_backward_default_44[2];  native_batch_norm_backward_default_44 = None
        view_default_307 = torch.ops.aten.view.default(getitem_505, [256, 1, 1, 1]);  getitem_505 = None
        mul_tensor_583 = torch.ops.aten.mul.Tensor(view_default_307, 0.02946278254943948);  view_default_307 = None
        view_default_308 = torch.ops.aten.view.default(getitem_504, [256, 128, 3, 3]);  getitem_504 = None
        mul_tensor_584 = torch.ops.aten.mul.Tensor(getitem_501, 1.7015043497085571);  getitem_501 = None
        to_dtype_192 = torch.ops.aten.to.dtype(mul_tensor_584, torch.float32);  mul_tensor_584 = None
        to_dtype_193 = torch.ops.aten.to.dtype(convolution_default_13, torch.float32);  convolution_default_13 = None
        mul_tensor_585 = torch.ops.aten.mul.Tensor(to_dtype_193, 0.7071067811865476)
        erf_default_42 = torch.ops.aten.erf.default(mul_tensor_585);  mul_tensor_585 = None
        add_tensor_117 = torch.ops.aten.add.Tensor(erf_default_42, 1);  erf_default_42 = None
        mul_tensor_586 = torch.ops.aten.mul.Tensor(add_tensor_117, 0.5);  add_tensor_117 = None
        mul_tensor_587 = torch.ops.aten.mul.Tensor(to_dtype_193, to_dtype_193)
        mul_tensor_588 = torch.ops.aten.mul.Tensor(mul_tensor_587, -0.5);  mul_tensor_587 = None
        exp_default_42 = torch.ops.aten.exp.default(mul_tensor_588);  mul_tensor_588 = None
        mul_tensor_589 = torch.ops.aten.mul.Tensor(exp_default_42, 0.3989422804014327);  exp_default_42 = None
        mul_tensor_590 = torch.ops.aten.mul.Tensor(to_dtype_193, mul_tensor_589);  to_dtype_193 = mul_tensor_589 = None
        add_tensor_118 = torch.ops.aten.add.Tensor(mul_tensor_586, mul_tensor_590);  mul_tensor_586 = mul_tensor_590 = None
        mul_tensor_591 = torch.ops.aten.mul.Tensor(to_dtype_192, add_tensor_118);  to_dtype_192 = add_tensor_118 = None
        to_dtype_194 = torch.ops.aten.to.dtype(mul_tensor_591, torch.float32);  mul_tensor_591 = None
        convolution_backward_default_67 = torch.ops.aten.convolution_backward.default(to_dtype_194, constant_pad_nd_default_2, view_default_35, [256], [2, 2], [0, 0], [1, 1], False, [0, 0], 2, [True, True, True]);  to_dtype_194 = constant_pad_nd_default_2 = view_default_35 = None
        getitem_507 = convolution_backward_default_67[0]
        getitem_508 = convolution_backward_default_67[1]
        getitem_509 = convolution_backward_default_67[2];  convolution_backward_default_67 = None
        view_default_309 = torch.ops.aten.view.default(getitem_508, [1, 256, 1152]);  getitem_508 = None
        native_batch_norm_backward_default_45 = torch.ops.aten.native_batch_norm_backward.default(view_default_309, view_default_33, view_default_34, None, None, getitem_34, getitem_35, True, 1e-05, [True, True, False]);  view_default_309 = view_default_33 = view_default_34 = getitem_34 = getitem_35 = None
        getitem_510 = native_batch_norm_backward_default_45[0]
        getitem_511 = native_batch_norm_backward_default_45[1]
        getitem_512 = native_batch_norm_backward_default_45[2];  native_batch_norm_backward_default_45 = None
        view_default_310 = torch.ops.aten.view.default(getitem_511, [256, 1, 1, 1]);  getitem_511 = None
        mul_tensor_592 = torch.ops.aten.mul.Tensor(view_default_310, 0.02946278254943948);  view_default_310 = None
        view_default_311 = torch.ops.aten.view.default(getitem_510, [256, 128, 3, 3]);  getitem_510 = None
        constant_pad_nd_default_7 = torch.ops.aten.constant_pad_nd.default(getitem_507, [0, -1, 0, -1]);  getitem_507 = None
        mul_tensor_593 = torch.ops.aten.mul.Tensor(constant_pad_nd_default_7, 1.7015043497085571);  constant_pad_nd_default_7 = None
        to_dtype_195 = torch.ops.aten.to.dtype(mul_tensor_593, torch.float32);  mul_tensor_593 = None
        to_dtype_196 = torch.ops.aten.to.dtype(convolution_default_12, torch.float32);  convolution_default_12 = None
        mul_tensor_594 = torch.ops.aten.mul.Tensor(to_dtype_196, 0.7071067811865476)
        erf_default_43 = torch.ops.aten.erf.default(mul_tensor_594);  mul_tensor_594 = None
        add_tensor_119 = torch.ops.aten.add.Tensor(erf_default_43, 1);  erf_default_43 = None
        mul_tensor_595 = torch.ops.aten.mul.Tensor(add_tensor_119, 0.5);  add_tensor_119 = None
        mul_tensor_596 = torch.ops.aten.mul.Tensor(to_dtype_196, to_dtype_196)
        mul_tensor_597 = torch.ops.aten.mul.Tensor(mul_tensor_596, -0.5);  mul_tensor_596 = None
        exp_default_43 = torch.ops.aten.exp.default(mul_tensor_597);  mul_tensor_597 = None
        mul_tensor_598 = torch.ops.aten.mul.Tensor(exp_default_43, 0.3989422804014327);  exp_default_43 = None
        mul_tensor_599 = torch.ops.aten.mul.Tensor(to_dtype_196, mul_tensor_598);  to_dtype_196 = mul_tensor_598 = None
        add_tensor_120 = torch.ops.aten.add.Tensor(mul_tensor_595, mul_tensor_599);  mul_tensor_595 = mul_tensor_599 = None
        mul_tensor_600 = torch.ops.aten.mul.Tensor(to_dtype_195, add_tensor_120);  to_dtype_195 = add_tensor_120 = None
        to_dtype_197 = torch.ops.aten.to.dtype(mul_tensor_600, torch.float32);  mul_tensor_600 = None
        convolution_backward_default_68 = torch.ops.aten.convolution_backward.default(to_dtype_197, mul_tensor_13, view_default_32, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_197 = view_default_32 = None
        getitem_513 = convolution_backward_default_68[0]
        getitem_514 = convolution_backward_default_68[1]
        getitem_515 = convolution_backward_default_68[2];  convolution_backward_default_68 = None
        view_default_312 = torch.ops.aten.view.default(getitem_514, [1, 256, 256]);  getitem_514 = None
        native_batch_norm_backward_default_46 = torch.ops.aten.native_batch_norm_backward.default(view_default_312, view_default_30, view_default_31, None, None, getitem_31, getitem_32, True, 1e-05, [True, True, False]);  view_default_312 = view_default_30 = view_default_31 = getitem_31 = getitem_32 = None
        getitem_516 = native_batch_norm_backward_default_46[0]
        getitem_517 = native_batch_norm_backward_default_46[1]
        getitem_518 = native_batch_norm_backward_default_46[2];  native_batch_norm_backward_default_46 = None
        view_default_313 = torch.ops.aten.view.default(getitem_517, [256, 1, 1, 1]);  getitem_517 = None
        mul_tensor_601 = torch.ops.aten.mul.Tensor(view_default_313, 0.0625);  view_default_313 = None
        view_default_314 = torch.ops.aten.view.default(getitem_516, [256, 256, 1, 1]);  getitem_516 = None
        convolution_backward_default_69 = torch.ops.aten.convolution_backward.default(add_tensor_113, avg_pool2d_default, view_default_29, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  add_tensor_113 = avg_pool2d_default = view_default_29 = None
        getitem_519 = convolution_backward_default_69[0]
        getitem_520 = convolution_backward_default_69[1]
        getitem_521 = convolution_backward_default_69[2];  convolution_backward_default_69 = None
        view_default_315 = torch.ops.aten.view.default(getitem_520, [1, 512, 256]);  getitem_520 = None
        native_batch_norm_backward_default_47 = torch.ops.aten.native_batch_norm_backward.default(view_default_315, view_default_27, view_default_28, None, None, getitem_28, getitem_29, True, 1e-05, [True, True, False]);  view_default_315 = view_default_27 = view_default_28 = getitem_28 = getitem_29 = None
        getitem_522 = native_batch_norm_backward_default_47[0]
        getitem_523 = native_batch_norm_backward_default_47[1]
        getitem_524 = native_batch_norm_backward_default_47[2];  native_batch_norm_backward_default_47 = None
        view_default_316 = torch.ops.aten.view.default(getitem_523, [512, 1, 1, 1]);  getitem_523 = None
        mul_tensor_602 = torch.ops.aten.mul.Tensor(view_default_316, 0.0625);  view_default_316 = None
        view_default_317 = torch.ops.aten.view.default(getitem_522, [512, 256, 1, 1]);  getitem_522 = None
        avg_pool2d_backward_default_2 = torch.ops.aten.avg_pool2d_backward.default(getitem_519, mul_tensor_13, [2, 2], [2, 2], [0, 0], True, False, None);  getitem_519 = mul_tensor_13 = None
        add_tensor_121 = torch.ops.aten.add.Tensor(getitem_513, avg_pool2d_backward_default_2);  getitem_513 = avg_pool2d_backward_default_2 = None
        mul_tensor_603 = torch.ops.aten.mul.Tensor(add_tensor_121, 0.9805806756909201);  add_tensor_121 = None
        mul_tensor_604 = torch.ops.aten.mul.Tensor(mul_tensor_603, 1.7015043497085571);  mul_tensor_603 = None
        to_dtype_198 = torch.ops.aten.to.dtype(mul_tensor_604, torch.float32);  mul_tensor_604 = None
        to_dtype_199 = torch.ops.aten.to.dtype(add_tensor, torch.float32);  add_tensor = None
        mul_tensor_605 = torch.ops.aten.mul.Tensor(to_dtype_199, 0.7071067811865476)
        erf_default_44 = torch.ops.aten.erf.default(mul_tensor_605);  mul_tensor_605 = None
        add_tensor_122 = torch.ops.aten.add.Tensor(erf_default_44, 1);  erf_default_44 = None
        mul_tensor_606 = torch.ops.aten.mul.Tensor(add_tensor_122, 0.5);  add_tensor_122 = None
        mul_tensor_607 = torch.ops.aten.mul.Tensor(to_dtype_199, to_dtype_199)
        mul_tensor_608 = torch.ops.aten.mul.Tensor(mul_tensor_607, -0.5);  mul_tensor_607 = None
        exp_default_44 = torch.ops.aten.exp.default(mul_tensor_608);  mul_tensor_608 = None
        mul_tensor_609 = torch.ops.aten.mul.Tensor(exp_default_44, 0.3989422804014327);  exp_default_44 = None
        mul_tensor_610 = torch.ops.aten.mul.Tensor(to_dtype_199, mul_tensor_609);  to_dtype_199 = mul_tensor_609 = None
        add_tensor_123 = torch.ops.aten.add.Tensor(mul_tensor_606, mul_tensor_610);  mul_tensor_606 = mul_tensor_610 = None
        mul_tensor_611 = torch.ops.aten.mul.Tensor(to_dtype_198, add_tensor_123);  to_dtype_198 = add_tensor_123 = None
        to_dtype_200 = torch.ops.aten.to.dtype(mul_tensor_611, torch.float32);  mul_tensor_611 = None
        mul_tensor_612 = torch.ops.aten.mul.Tensor(to_dtype_200, 0.2)
        mul_tensor_613 = torch.ops.aten.mul.Tensor(mul_tensor_612, clone_default);  clone_default = None
        mul_tensor_614 = torch.ops.aten.mul.Tensor(mul_tensor_612, primals_25);  mul_tensor_612 = primals_25 = None
        sum_default_11 = torch.ops.aten.sum.default(mul_tensor_613);  mul_tensor_613 = None
        mul_tensor_615 = torch.ops.aten.mul.Tensor(mul_tensor_614, 2.0);  mul_tensor_614 = None
        mul_tensor_616 = torch.ops.aten.mul.Tensor(mul_tensor_615, convolution_default_8);  convolution_default_8 = None
        mul_tensor_617 = torch.ops.aten.mul.Tensor(mul_tensor_615, sigmoid_default);  mul_tensor_615 = None
        sum_dim_int_list_12 = torch.ops.aten.sum.dim_IntList(mul_tensor_616, [2, 3], True);  mul_tensor_616 = None
        to_dtype_201 = torch.ops.aten.to.dtype(sum_dim_int_list_12, torch.float32);  sum_dim_int_list_12 = None
        to_dtype_202 = torch.ops.aten.to.dtype(sigmoid_default, torch.float32);  sigmoid_default = None
        rsub_scalar_11 = torch.ops.aten.rsub.Scalar(to_dtype_202, 1)
        mul_tensor_618 = torch.ops.aten.mul.Tensor(to_dtype_202, rsub_scalar_11);  to_dtype_202 = rsub_scalar_11 = None
        conj_physical_default_11 = torch.ops.aten.conj_physical.default(mul_tensor_618);  mul_tensor_618 = None
        mul_tensor_619 = torch.ops.aten.mul.Tensor(to_dtype_201, conj_physical_default_11);  to_dtype_201 = conj_physical_default_11 = None
        to_dtype_203 = torch.ops.aten.to.dtype(mul_tensor_619, torch.float32);  mul_tensor_619 = None
        convolution_backward_default_70 = torch.ops.aten.convolution_backward.default(to_dtype_203, relu__default, primals_9, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_203 = primals_9 = None
        getitem_525 = convolution_backward_default_70[0]
        getitem_526 = convolution_backward_default_70[1]
        getitem_527 = convolution_backward_default_70[2];  convolution_backward_default_70 = None
        to_dtype_204 = torch.ops.aten.to.dtype(getitem_525, torch.float32);  getitem_525 = None
        to_dtype_205 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_205, 0);  to_dtype_205 = None
        new_zeros_default_11 = torch.ops.aten.new_zeros.default(to_dtype_204, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_11, to_dtype_204);  le_scalar_11 = new_zeros_default_11 = to_dtype_204 = None
        to_dtype_206 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        convolution_backward_default_71 = torch.ops.aten.convolution_backward.default(to_dtype_206, mean_dim, primals_7, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_206 = mean_dim = primals_7 = None
        getitem_528 = convolution_backward_default_71[0]
        getitem_529 = convolution_backward_default_71[1]
        getitem_530 = convolution_backward_default_71[2];  convolution_backward_default_71 = None
        expand_default_12 = torch.ops.aten.expand.default(getitem_528, [128, 256, 48, 48]);  getitem_528 = None
        div_scalar_12 = torch.ops.aten.div.Scalar(expand_default_12, 2304);  expand_default_12 = None
        add_tensor_124 = torch.ops.aten.add.Tensor(mul_tensor_617, div_scalar_12);  mul_tensor_617 = div_scalar_12 = None
        convolution_backward_default_72 = torch.ops.aten.convolution_backward.default(add_tensor_124, mul__tensor_6, view_default_26, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  add_tensor_124 = mul__tensor_6 = view_default_26 = None
        getitem_531 = convolution_backward_default_72[0]
        getitem_532 = convolution_backward_default_72[1]
        getitem_533 = convolution_backward_default_72[2];  convolution_backward_default_72 = None
        view_default_318 = torch.ops.aten.view.default(getitem_532, [1, 256, 128]);  getitem_532 = None
        native_batch_norm_backward_default_48 = torch.ops.aten.native_batch_norm_backward.default(view_default_318, view_default_24, view_default_25, None, None, getitem_25, getitem_26, True, 1e-05, [True, True, False]);  view_default_318 = view_default_24 = view_default_25 = getitem_25 = getitem_26 = None
        getitem_534 = native_batch_norm_backward_default_48[0]
        getitem_535 = native_batch_norm_backward_default_48[1]
        getitem_536 = native_batch_norm_backward_default_48[2];  native_batch_norm_backward_default_48 = None
        view_default_319 = torch.ops.aten.view.default(getitem_535, [256, 1, 1, 1]);  getitem_535 = None
        mul_tensor_620 = torch.ops.aten.mul.Tensor(view_default_319, 0.08838834764831845);  view_default_319 = None
        view_default_320 = torch.ops.aten.view.default(getitem_534, [256, 128, 1, 1]);  getitem_534 = None
        mul_tensor_621 = torch.ops.aten.mul.Tensor(getitem_531, 1.7015043497085571);  getitem_531 = None
        to_dtype_207 = torch.ops.aten.to.dtype(mul_tensor_621, torch.float32);  mul_tensor_621 = None
        to_dtype_208 = torch.ops.aten.to.dtype(convolution_default_7, torch.float32);  convolution_default_7 = None
        mul_tensor_622 = torch.ops.aten.mul.Tensor(to_dtype_208, 0.7071067811865476)
        erf_default_45 = torch.ops.aten.erf.default(mul_tensor_622);  mul_tensor_622 = None
        add_tensor_125 = torch.ops.aten.add.Tensor(erf_default_45, 1);  erf_default_45 = None
        mul_tensor_623 = torch.ops.aten.mul.Tensor(add_tensor_125, 0.5);  add_tensor_125 = None
        mul_tensor_624 = torch.ops.aten.mul.Tensor(to_dtype_208, to_dtype_208)
        mul_tensor_625 = torch.ops.aten.mul.Tensor(mul_tensor_624, -0.5);  mul_tensor_624 = None
        exp_default_45 = torch.ops.aten.exp.default(mul_tensor_625);  mul_tensor_625 = None
        mul_tensor_626 = torch.ops.aten.mul.Tensor(exp_default_45, 0.3989422804014327);  exp_default_45 = None
        mul_tensor_627 = torch.ops.aten.mul.Tensor(to_dtype_208, mul_tensor_626);  to_dtype_208 = mul_tensor_626 = None
        add_tensor_126 = torch.ops.aten.add.Tensor(mul_tensor_623, mul_tensor_627);  mul_tensor_623 = mul_tensor_627 = None
        mul_tensor_628 = torch.ops.aten.mul.Tensor(to_dtype_207, add_tensor_126);  to_dtype_207 = add_tensor_126 = None
        to_dtype_209 = torch.ops.aten.to.dtype(mul_tensor_628, torch.float32);  mul_tensor_628 = None
        convolution_backward_default_73 = torch.ops.aten.convolution_backward.default(to_dtype_209, mul__tensor_5, view_default_23, [128], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_209 = mul__tensor_5 = view_default_23 = None
        getitem_537 = convolution_backward_default_73[0]
        getitem_538 = convolution_backward_default_73[1]
        getitem_539 = convolution_backward_default_73[2];  convolution_backward_default_73 = None
        view_default_321 = torch.ops.aten.view.default(getitem_538, [1, 128, 1152]);  getitem_538 = None
        native_batch_norm_backward_default_49 = torch.ops.aten.native_batch_norm_backward.default(view_default_321, view_default_21, view_default_22, None, None, getitem_22, getitem_23, True, 1e-05, [True, True, False]);  view_default_321 = view_default_21 = view_default_22 = getitem_22 = getitem_23 = None
        getitem_540 = native_batch_norm_backward_default_49[0]
        getitem_541 = native_batch_norm_backward_default_49[1]
        getitem_542 = native_batch_norm_backward_default_49[2];  native_batch_norm_backward_default_49 = None
        view_default_322 = torch.ops.aten.view.default(getitem_541, [128, 1, 1, 1]);  getitem_541 = None
        mul_tensor_629 = torch.ops.aten.mul.Tensor(view_default_322, 0.02946278254943948);  view_default_322 = None
        view_default_323 = torch.ops.aten.view.default(getitem_540, [128, 128, 3, 3]);  getitem_540 = None
        mul_tensor_630 = torch.ops.aten.mul.Tensor(getitem_537, 1.7015043497085571);  getitem_537 = None
        to_dtype_210 = torch.ops.aten.to.dtype(mul_tensor_630, torch.float32);  mul_tensor_630 = None
        to_dtype_211 = torch.ops.aten.to.dtype(convolution_default_6, torch.float32);  convolution_default_6 = None
        mul_tensor_631 = torch.ops.aten.mul.Tensor(to_dtype_211, 0.7071067811865476)
        erf_default_46 = torch.ops.aten.erf.default(mul_tensor_631);  mul_tensor_631 = None
        add_tensor_127 = torch.ops.aten.add.Tensor(erf_default_46, 1);  erf_default_46 = None
        mul_tensor_632 = torch.ops.aten.mul.Tensor(add_tensor_127, 0.5);  add_tensor_127 = None
        mul_tensor_633 = torch.ops.aten.mul.Tensor(to_dtype_211, to_dtype_211)
        mul_tensor_634 = torch.ops.aten.mul.Tensor(mul_tensor_633, -0.5);  mul_tensor_633 = None
        exp_default_46 = torch.ops.aten.exp.default(mul_tensor_634);  mul_tensor_634 = None
        mul_tensor_635 = torch.ops.aten.mul.Tensor(exp_default_46, 0.3989422804014327);  exp_default_46 = None
        mul_tensor_636 = torch.ops.aten.mul.Tensor(to_dtype_211, mul_tensor_635);  to_dtype_211 = mul_tensor_635 = None
        add_tensor_128 = torch.ops.aten.add.Tensor(mul_tensor_632, mul_tensor_636);  mul_tensor_632 = mul_tensor_636 = None
        mul_tensor_637 = torch.ops.aten.mul.Tensor(to_dtype_210, add_tensor_128);  to_dtype_210 = add_tensor_128 = None
        to_dtype_212 = torch.ops.aten.to.dtype(mul_tensor_637, torch.float32);  mul_tensor_637 = None
        convolution_backward_default_74 = torch.ops.aten.convolution_backward.default(to_dtype_212, mul__tensor_4, view_default_20, [128], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_212 = mul__tensor_4 = view_default_20 = None
        getitem_543 = convolution_backward_default_74[0]
        getitem_544 = convolution_backward_default_74[1]
        getitem_545 = convolution_backward_default_74[2];  convolution_backward_default_74 = None
        view_default_324 = torch.ops.aten.view.default(getitem_544, [1, 128, 1152]);  getitem_544 = None
        native_batch_norm_backward_default_50 = torch.ops.aten.native_batch_norm_backward.default(view_default_324, view_default_18, view_default_19, None, None, getitem_19, getitem_20, True, 1e-05, [True, True, False]);  view_default_324 = view_default_18 = view_default_19 = getitem_19 = getitem_20 = None
        getitem_546 = native_batch_norm_backward_default_50[0]
        getitem_547 = native_batch_norm_backward_default_50[1]
        getitem_548 = native_batch_norm_backward_default_50[2];  native_batch_norm_backward_default_50 = None
        view_default_325 = torch.ops.aten.view.default(getitem_547, [128, 1, 1, 1]);  getitem_547 = None
        mul_tensor_638 = torch.ops.aten.mul.Tensor(view_default_325, 0.02946278254943948);  view_default_325 = None
        view_default_326 = torch.ops.aten.view.default(getitem_546, [128, 128, 3, 3]);  getitem_546 = None
        mul_tensor_639 = torch.ops.aten.mul.Tensor(getitem_543, 1.7015043497085571);  getitem_543 = None
        to_dtype_213 = torch.ops.aten.to.dtype(mul_tensor_639, torch.float32);  mul_tensor_639 = None
        to_dtype_214 = torch.ops.aten.to.dtype(convolution_default_5, torch.float32);  convolution_default_5 = None
        mul_tensor_640 = torch.ops.aten.mul.Tensor(to_dtype_214, 0.7071067811865476)
        erf_default_47 = torch.ops.aten.erf.default(mul_tensor_640);  mul_tensor_640 = None
        add_tensor_129 = torch.ops.aten.add.Tensor(erf_default_47, 1);  erf_default_47 = None
        mul_tensor_641 = torch.ops.aten.mul.Tensor(add_tensor_129, 0.5);  add_tensor_129 = None
        mul_tensor_642 = torch.ops.aten.mul.Tensor(to_dtype_214, to_dtype_214)
        mul_tensor_643 = torch.ops.aten.mul.Tensor(mul_tensor_642, -0.5);  mul_tensor_642 = None
        exp_default_47 = torch.ops.aten.exp.default(mul_tensor_643);  mul_tensor_643 = None
        mul_tensor_644 = torch.ops.aten.mul.Tensor(exp_default_47, 0.3989422804014327);  exp_default_47 = None
        mul_tensor_645 = torch.ops.aten.mul.Tensor(to_dtype_214, mul_tensor_644);  to_dtype_214 = mul_tensor_644 = None
        add_tensor_130 = torch.ops.aten.add.Tensor(mul_tensor_641, mul_tensor_645);  mul_tensor_641 = mul_tensor_645 = None
        mul_tensor_646 = torch.ops.aten.mul.Tensor(to_dtype_213, add_tensor_130);  to_dtype_213 = add_tensor_130 = None
        to_dtype_215 = torch.ops.aten.to.dtype(mul_tensor_646, torch.float32);  mul_tensor_646 = None
        convolution_backward_default_75 = torch.ops.aten.convolution_backward.default(to_dtype_215, mul_tensor_4, view_default_17, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_215 = view_default_17 = None
        getitem_549 = convolution_backward_default_75[0]
        getitem_550 = convolution_backward_default_75[1]
        getitem_551 = convolution_backward_default_75[2];  convolution_backward_default_75 = None
        view_default_327 = torch.ops.aten.view.default(getitem_550, [1, 128, 128]);  getitem_550 = None
        native_batch_norm_backward_default_51 = torch.ops.aten.native_batch_norm_backward.default(view_default_327, view_default_15, view_default_16, None, None, getitem_16, getitem_17, True, 1e-05, [True, True, False]);  view_default_327 = view_default_15 = view_default_16 = getitem_16 = getitem_17 = None
        getitem_552 = native_batch_norm_backward_default_51[0]
        getitem_553 = native_batch_norm_backward_default_51[1]
        getitem_554 = native_batch_norm_backward_default_51[2];  native_batch_norm_backward_default_51 = None
        view_default_328 = torch.ops.aten.view.default(getitem_553, [128, 1, 1, 1]);  getitem_553 = None
        mul_tensor_647 = torch.ops.aten.mul.Tensor(view_default_328, 0.08838834764831845);  view_default_328 = None
        view_default_329 = torch.ops.aten.view.default(getitem_552, [128, 128, 1, 1]);  getitem_552 = None
        convolution_backward_default_76 = torch.ops.aten.convolution_backward.default(to_dtype_200, mul_tensor_4, view_default_14, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_200 = mul_tensor_4 = view_default_14 = None
        getitem_555 = convolution_backward_default_76[0]
        getitem_556 = convolution_backward_default_76[1]
        getitem_557 = convolution_backward_default_76[2];  convolution_backward_default_76 = None
        add_tensor_131 = torch.ops.aten.add.Tensor(getitem_549, getitem_555);  getitem_549 = getitem_555 = None
        view_default_330 = torch.ops.aten.view.default(getitem_556, [1, 256, 128]);  getitem_556 = None
        native_batch_norm_backward_default_52 = torch.ops.aten.native_batch_norm_backward.default(view_default_330, view_default_12, view_default_13, None, None, getitem_13, getitem_14, True, 1e-05, [True, True, False]);  view_default_330 = view_default_12 = view_default_13 = getitem_13 = getitem_14 = None
        getitem_558 = native_batch_norm_backward_default_52[0]
        getitem_559 = native_batch_norm_backward_default_52[1]
        getitem_560 = native_batch_norm_backward_default_52[2];  native_batch_norm_backward_default_52 = None
        view_default_331 = torch.ops.aten.view.default(getitem_559, [256, 1, 1, 1]);  getitem_559 = None
        mul_tensor_648 = torch.ops.aten.mul.Tensor(view_default_331, 0.08838834764831845);  view_default_331 = None
        view_default_332 = torch.ops.aten.view.default(getitem_558, [256, 128, 1, 1]);  getitem_558 = None
        mul_tensor_649 = torch.ops.aten.mul.Tensor(add_tensor_131, 1.0);  add_tensor_131 = None
        mul_tensor_650 = torch.ops.aten.mul.Tensor(mul_tensor_649, 1.7015043497085571);  mul_tensor_649 = None
        to_dtype_216 = torch.ops.aten.to.dtype(mul_tensor_650, torch.float32);  mul_tensor_650 = None
        to_dtype_217 = torch.ops.aten.to.dtype(convolution_default_3, torch.float32);  convolution_default_3 = None
        mul_tensor_651 = torch.ops.aten.mul.Tensor(to_dtype_217, 0.7071067811865476)
        erf_default_48 = torch.ops.aten.erf.default(mul_tensor_651);  mul_tensor_651 = None
        add_tensor_132 = torch.ops.aten.add.Tensor(erf_default_48, 1);  erf_default_48 = None
        mul_tensor_652 = torch.ops.aten.mul.Tensor(add_tensor_132, 0.5);  add_tensor_132 = None
        mul_tensor_653 = torch.ops.aten.mul.Tensor(to_dtype_217, to_dtype_217)
        mul_tensor_654 = torch.ops.aten.mul.Tensor(mul_tensor_653, -0.5);  mul_tensor_653 = None
        exp_default_48 = torch.ops.aten.exp.default(mul_tensor_654);  mul_tensor_654 = None
        mul_tensor_655 = torch.ops.aten.mul.Tensor(exp_default_48, 0.3989422804014327);  exp_default_48 = None
        mul_tensor_656 = torch.ops.aten.mul.Tensor(to_dtype_217, mul_tensor_655);  to_dtype_217 = mul_tensor_655 = None
        add_tensor_133 = torch.ops.aten.add.Tensor(mul_tensor_652, mul_tensor_656);  mul_tensor_652 = mul_tensor_656 = None
        mul_tensor_657 = torch.ops.aten.mul.Tensor(to_dtype_216, add_tensor_133);  to_dtype_216 = add_tensor_133 = None
        to_dtype_218 = torch.ops.aten.to.dtype(mul_tensor_657, torch.float32);  mul_tensor_657 = None
        convolution_backward_default_77 = torch.ops.aten.convolution_backward.default(to_dtype_218, constant_pad_nd_default_1, view_default_11, [128], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_218 = constant_pad_nd_default_1 = view_default_11 = None
        getitem_561 = convolution_backward_default_77[0]
        getitem_562 = convolution_backward_default_77[1]
        getitem_563 = convolution_backward_default_77[2];  convolution_backward_default_77 = None
        view_default_333 = torch.ops.aten.view.default(getitem_562, [1, 128, 576]);  getitem_562 = None
        native_batch_norm_backward_default_53 = torch.ops.aten.native_batch_norm_backward.default(view_default_333, view_default_9, view_default_10, None, None, getitem_10, getitem_11, True, 1e-05, [True, True, False]);  view_default_333 = view_default_9 = view_default_10 = getitem_10 = getitem_11 = None
        getitem_564 = native_batch_norm_backward_default_53[0]
        getitem_565 = native_batch_norm_backward_default_53[1]
        getitem_566 = native_batch_norm_backward_default_53[2];  native_batch_norm_backward_default_53 = None
        view_default_334 = torch.ops.aten.view.default(getitem_565, [128, 1, 1, 1]);  getitem_565 = None
        mul_tensor_658 = torch.ops.aten.mul.Tensor(view_default_334, 0.041666666666666664);  view_default_334 = None
        view_default_335 = torch.ops.aten.view.default(getitem_564, [128, 64, 3, 3]);  getitem_564 = None
        constant_pad_nd_default_8 = torch.ops.aten.constant_pad_nd.default(getitem_561, [0, -1, 0, -1]);  getitem_561 = None
        mul_tensor_659 = torch.ops.aten.mul.Tensor(constant_pad_nd_default_8, 1.7015043497085571);  constant_pad_nd_default_8 = None
        to_dtype_219 = torch.ops.aten.to.dtype(mul_tensor_659, torch.float32);  mul_tensor_659 = None
        to_dtype_220 = torch.ops.aten.to.dtype(convolution_default_2, torch.float32);  convolution_default_2 = None
        mul_tensor_660 = torch.ops.aten.mul.Tensor(to_dtype_220, 0.7071067811865476)
        erf_default_49 = torch.ops.aten.erf.default(mul_tensor_660);  mul_tensor_660 = None
        add_tensor_134 = torch.ops.aten.add.Tensor(erf_default_49, 1);  erf_default_49 = None
        mul_tensor_661 = torch.ops.aten.mul.Tensor(add_tensor_134, 0.5);  add_tensor_134 = None
        mul_tensor_662 = torch.ops.aten.mul.Tensor(to_dtype_220, to_dtype_220)
        mul_tensor_663 = torch.ops.aten.mul.Tensor(mul_tensor_662, -0.5);  mul_tensor_662 = None
        exp_default_49 = torch.ops.aten.exp.default(mul_tensor_663);  mul_tensor_663 = None
        mul_tensor_664 = torch.ops.aten.mul.Tensor(exp_default_49, 0.3989422804014327);  exp_default_49 = None
        mul_tensor_665 = torch.ops.aten.mul.Tensor(to_dtype_220, mul_tensor_664);  to_dtype_220 = mul_tensor_664 = None
        add_tensor_135 = torch.ops.aten.add.Tensor(mul_tensor_661, mul_tensor_665);  mul_tensor_661 = mul_tensor_665 = None
        mul_tensor_666 = torch.ops.aten.mul.Tensor(to_dtype_219, add_tensor_135);  to_dtype_219 = add_tensor_135 = None
        to_dtype_221 = torch.ops.aten.to.dtype(mul_tensor_666, torch.float32);  mul_tensor_666 = None
        convolution_backward_default_78 = torch.ops.aten.convolution_backward.default(to_dtype_221, mul__tensor_1, view_default_8, [64], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_221 = mul__tensor_1 = view_default_8 = None
        getitem_567 = convolution_backward_default_78[0]
        getitem_568 = convolution_backward_default_78[1]
        getitem_569 = convolution_backward_default_78[2];  convolution_backward_default_78 = None
        view_default_336 = torch.ops.aten.view.default(getitem_568, [1, 64, 288]);  getitem_568 = None
        native_batch_norm_backward_default_54 = torch.ops.aten.native_batch_norm_backward.default(view_default_336, view_default_6, view_default_7, None, None, getitem_7, getitem_8, True, 1e-05, [True, True, False]);  view_default_336 = view_default_6 = view_default_7 = getitem_7 = getitem_8 = None
        getitem_570 = native_batch_norm_backward_default_54[0]
        getitem_571 = native_batch_norm_backward_default_54[1]
        getitem_572 = native_batch_norm_backward_default_54[2];  native_batch_norm_backward_default_54 = None
        view_default_337 = torch.ops.aten.view.default(getitem_571, [64, 1, 1, 1]);  getitem_571 = None
        mul_tensor_667 = torch.ops.aten.mul.Tensor(view_default_337, 0.05892556509887896);  view_default_337 = None
        view_default_338 = torch.ops.aten.view.default(getitem_570, [64, 32, 3, 3]);  getitem_570 = None
        mul_tensor_668 = torch.ops.aten.mul.Tensor(getitem_567, 1.7015043497085571);  getitem_567 = None
        to_dtype_222 = torch.ops.aten.to.dtype(mul_tensor_668, torch.float32);  mul_tensor_668 = None
        to_dtype_223 = torch.ops.aten.to.dtype(convolution_default_1, torch.float32);  convolution_default_1 = None
        mul_tensor_669 = torch.ops.aten.mul.Tensor(to_dtype_223, 0.7071067811865476)
        erf_default_50 = torch.ops.aten.erf.default(mul_tensor_669);  mul_tensor_669 = None
        add_tensor_136 = torch.ops.aten.add.Tensor(erf_default_50, 1);  erf_default_50 = None
        mul_tensor_670 = torch.ops.aten.mul.Tensor(add_tensor_136, 0.5);  add_tensor_136 = None
        mul_tensor_671 = torch.ops.aten.mul.Tensor(to_dtype_223, to_dtype_223)
        mul_tensor_672 = torch.ops.aten.mul.Tensor(mul_tensor_671, -0.5);  mul_tensor_671 = None
        exp_default_50 = torch.ops.aten.exp.default(mul_tensor_672);  mul_tensor_672 = None
        mul_tensor_673 = torch.ops.aten.mul.Tensor(exp_default_50, 0.3989422804014327);  exp_default_50 = None
        mul_tensor_674 = torch.ops.aten.mul.Tensor(to_dtype_223, mul_tensor_673);  to_dtype_223 = mul_tensor_673 = None
        add_tensor_137 = torch.ops.aten.add.Tensor(mul_tensor_670, mul_tensor_674);  mul_tensor_670 = mul_tensor_674 = None
        mul_tensor_675 = torch.ops.aten.mul.Tensor(to_dtype_222, add_tensor_137);  to_dtype_222 = add_tensor_137 = None
        to_dtype_224 = torch.ops.aten.to.dtype(mul_tensor_675, torch.float32);  mul_tensor_675 = None
        convolution_backward_default_79 = torch.ops.aten.convolution_backward.default(to_dtype_224, mul__tensor, view_default_5, [32], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_224 = mul__tensor = view_default_5 = None
        getitem_573 = convolution_backward_default_79[0]
        getitem_574 = convolution_backward_default_79[1]
        getitem_575 = convolution_backward_default_79[2];  convolution_backward_default_79 = None
        view_default_339 = torch.ops.aten.view.default(getitem_574, [1, 32, 144]);  getitem_574 = None
        native_batch_norm_backward_default_55 = torch.ops.aten.native_batch_norm_backward.default(view_default_339, view_default_3, view_default_4, None, None, getitem_4, getitem_5, True, 1e-05, [True, True, False]);  view_default_339 = view_default_3 = view_default_4 = getitem_4 = getitem_5 = None
        getitem_576 = native_batch_norm_backward_default_55[0]
        getitem_577 = native_batch_norm_backward_default_55[1]
        getitem_578 = native_batch_norm_backward_default_55[2];  native_batch_norm_backward_default_55 = None
        view_default_340 = torch.ops.aten.view.default(getitem_577, [32, 1, 1, 1]);  getitem_577 = None
        mul_tensor_676 = torch.ops.aten.mul.Tensor(view_default_340, 0.08333333333333333);  view_default_340 = None
        view_default_341 = torch.ops.aten.view.default(getitem_576, [32, 16, 3, 3]);  getitem_576 = None
        mul_tensor_677 = torch.ops.aten.mul.Tensor(getitem_573, 1.7015043497085571);  getitem_573 = None
        to_dtype_225 = torch.ops.aten.to.dtype(mul_tensor_677, torch.float32);  mul_tensor_677 = None
        to_dtype_226 = torch.ops.aten.to.dtype(convolution_default, torch.float32);  convolution_default = None
        mul_tensor_678 = torch.ops.aten.mul.Tensor(to_dtype_226, 0.7071067811865476)
        erf_default_51 = torch.ops.aten.erf.default(mul_tensor_678);  mul_tensor_678 = None
        add_tensor_138 = torch.ops.aten.add.Tensor(erf_default_51, 1);  erf_default_51 = None
        mul_tensor_679 = torch.ops.aten.mul.Tensor(add_tensor_138, 0.5);  add_tensor_138 = None
        mul_tensor_680 = torch.ops.aten.mul.Tensor(to_dtype_226, to_dtype_226)
        mul_tensor_681 = torch.ops.aten.mul.Tensor(mul_tensor_680, -0.5);  mul_tensor_680 = None
        exp_default_51 = torch.ops.aten.exp.default(mul_tensor_681);  mul_tensor_681 = None
        mul_tensor_682 = torch.ops.aten.mul.Tensor(exp_default_51, 0.3989422804014327);  exp_default_51 = None
        mul_tensor_683 = torch.ops.aten.mul.Tensor(to_dtype_226, mul_tensor_682);  to_dtype_226 = mul_tensor_682 = None
        add_tensor_139 = torch.ops.aten.add.Tensor(mul_tensor_679, mul_tensor_683);  mul_tensor_679 = mul_tensor_683 = None
        mul_tensor_684 = torch.ops.aten.mul.Tensor(to_dtype_225, add_tensor_139);  to_dtype_225 = add_tensor_139 = None
        to_dtype_227 = torch.ops.aten.to.dtype(mul_tensor_684, torch.float32);  mul_tensor_684 = None
        convolution_backward_default_80 = torch.ops.aten.convolution_backward.default(to_dtype_227, constant_pad_nd_default, view_default_2, [16], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [False, True, True]);  to_dtype_227 = constant_pad_nd_default = view_default_2 = None
        getitem_579 = convolution_backward_default_80[0]
        getitem_580 = convolution_backward_default_80[1]
        getitem_581 = convolution_backward_default_80[2];  convolution_backward_default_80 = None
        view_default_342 = torch.ops.aten.view.default(getitem_580, [1, 16, 27]);  getitem_580 = None
        native_batch_norm_backward_default_56 = torch.ops.aten.native_batch_norm_backward.default(view_default_342, view_default, view_default_1, None, None, getitem_1, getitem_2, True, 1e-05, [True, True, False]);  view_default_342 = view_default = view_default_1 = getitem_1 = getitem_2 = None
        getitem_582 = native_batch_norm_backward_default_56[0]
        getitem_583 = native_batch_norm_backward_default_56[1]
        getitem_584 = native_batch_norm_backward_default_56[2];  native_batch_norm_backward_default_56 = None
        view_default_343 = torch.ops.aten.view.default(getitem_583, [16, 1, 1, 1]);  getitem_583 = None
        mul_tensor_685 = torch.ops.aten.mul.Tensor(view_default_343, 0.19245008972987526);  view_default_343 = None
        view_default_344 = torch.ops.aten.view.default(getitem_582, [16, 3, 3, 3]);  getitem_582 = None
        return [addmm_default, getitem_173, mul_tensor_113, view_default_176, view_default_172, t_default_4, getitem_530, getitem_529, getitem_527, getitem_526, getitem_551, mul_tensor_647, view_default_329, getitem_545, mul_tensor_638, view_default_326, getitem_539, mul_tensor_629, view_default_323, getitem_533, mul_tensor_620, view_default_320, getitem_557, mul_tensor_648, view_default_332, sum_default_11, getitem_494, getitem_493, getitem_491, getitem_490, getitem_515, mul_tensor_601, view_default_314, getitem_509, mul_tensor_592, view_default_311, getitem_503, mul_tensor_583, view_default_308, getitem_497, mul_tensor_574, view_default_305, getitem_521, mul_tensor_602, view_default_317, sum_default_10, getitem_464, getitem_463, getitem_461, getitem_460, getitem_485, mul_tensor_556, view_default_302, getitem_479, mul_tensor_547, view_default_299, getitem_473, mul_tensor_538, view_default_296, getitem_467, mul_tensor_529, view_default_293, sum_default_9, getitem_428, getitem_427, getitem_425, getitem_424, getitem_449, mul_tensor_510, view_default_287, getitem_443, mul_tensor_501, view_default_284, getitem_437, mul_tensor_492, view_default_281, getitem_431, mul_tensor_483, view_default_278, getitem_455, mul_tensor_511, view_default_290, sum_default_8, getitem_398, getitem_397, getitem_395, getitem_394, getitem_419, mul_tensor_465, view_default_275, getitem_413, mul_tensor_456, view_default_272, getitem_407, mul_tensor_447, view_default_269, getitem_401, mul_tensor_438, view_default_266, sum_default_7, getitem_368, getitem_367, getitem_365, getitem_364, getitem_389, mul_tensor_420, view_default_263, getitem_383, mul_tensor_411, view_default_260, getitem_377, mul_tensor_402, view_default_257, getitem_371, mul_tensor_393, view_default_254, sum_default_6, getitem_338, getitem_337, getitem_335, getitem_334, getitem_359, mul_tensor_375, view_default_251, getitem_353, mul_tensor_366, view_default_248, getitem_347, mul_tensor_357, view_default_245, getitem_341, mul_tensor_348, view_default_242, sum_default_5, getitem_308, getitem_307, getitem_305, getitem_304, getitem_329, mul_tensor_330, view_default_239, getitem_323, mul_tensor_321, view_default_236, getitem_317, mul_tensor_312, view_default_233, getitem_311, mul_tensor_303, view_default_230, sum_default_4, getitem_278, getitem_277, getitem_275, getitem_274, getitem_299, mul_tensor_285, view_default_227, getitem_293, mul_tensor_276, view_default_224, getitem_287, mul_tensor_267, view_default_221, getitem_281, mul_tensor_258, view_default_218, sum_default_3, getitem_242, getitem_241, getitem_239, getitem_238, getitem_263, mul_tensor_239, view_default_212, getitem_257, mul_tensor_230, view_default_209, getitem_251, mul_tensor_221, view_default_206, getitem_245, mul_tensor_212, view_default_203, getitem_269, mul_tensor_240, view_default_215, sum_default_2, getitem_212, getitem_211, getitem_209, getitem_208, getitem_233, mul_tensor_194, view_default_200, getitem_227, mul_tensor_185, view_default_197, getitem_221, mul_tensor_176, view_default_194, getitem_215, mul_tensor_167, view_default_191, sum_default_1, getitem_182, getitem_181, getitem_179, getitem_178, getitem_203, mul_tensor_149, view_default_188, getitem_197, mul_tensor_140, view_default_185, getitem_191, mul_tensor_131, view_default_182, getitem_185, mul_tensor_122, view_default_179, sum_default, getitem_581, mul_tensor_685, view_default_344, getitem_575, mul_tensor_676, view_default_341, getitem_569, mul_tensor_667, view_default_338, getitem_563, mul_tensor_658, view_default_335, None]
        
