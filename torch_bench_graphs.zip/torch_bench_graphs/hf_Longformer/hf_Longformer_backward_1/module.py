
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/hf_Longformer/hf_Longformer_backward_1/state_dict.pt'))

    
    
    def forward(self, tangents_1, tangents_2, tangents_3):
        return [None]
        
