
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/hf_Longformer/hf_Longformer_joint_1/state_dict.pt'))

    
    
    def forward(self, primals_1, tangents_1, tangents_2, tangents_3):
        lt_scalar = torch.ops.aten.lt.Scalar(primals_1, 0)
        gt_scalar = torch.ops.aten.gt.Scalar(primals_1, 0);  primals_1 = None
        view_default = torch.ops.aten.view.default(gt_scalar, [2048])
        any_default = torch.ops.aten.any.default(view_default);  view_default = None
        return [any_default, lt_scalar, gt_scalar, None]
        
