
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/hf_Longformer/hf_Longformer_backward_2/state_dict.pt'))

    
    
    def forward(self, unsqueeze_default_81, t_default_39, primals_29, unsqueeze_default_95, primals_30, add_tensor_70, _unsafe_view_default_154, _unsafe_view_default_152, t_default_69, getitem_67, view_default_328, getitem_68, t_default_70, _unsafe_view_default_41, _unsafe_view_default_39, _unsafe_view_default_124, t_default_18, t_default_19, t_default_56, t_default_20, _unsafe_view_default_43, _unsafe_view_default_119, add_tensor_65, primals_45, primals_46, view_default_305, t_default_5, primals_34, view_default_306, t_default_65, add_tensor_5, view_default_26, t_default_64, primals_33, getitem_44, primals_114, t_default_46, primals_93, view_default_221, primals_94, getitem_43, primals_113, _unsafe_view_default_102, getitem_52, _unsafe_view_default_22, add_tensor_46, add_tensor_10, t_default_9, view_default_164, view_default_48, view_default_216, primals_190, t_default_58, add_tensor_59, getitem_55, _unsafe_view_default_128, primals_189, view_default_278, t_default_62, t_default_59, _unsafe_view_default_134, view_default_277, getitem_56, getitem_59, t_default_60, t_default_53, getitem_53, _unsafe_view_default_130, t_default_61, add_tensor_53, _unsafe_view_default_33, getitem_58, primals_141, _softmax_default_3, view_default_250, _unsafe_view_default_132, primals_157, primals_126, _unsafe_view_default_145, getitem_64, getitem_65, t_default_68, _unsafe_view_default_117, t_default_54, t_default_55, t_default_67, _unsafe_view_default_143, t_default_66, _unsafe_view_default_32, _softmax_default_11, t_default_48, view_default_222, view_default_109, add_tensor_47, _unsafe_view_default_150, t_default_47, getitem_47, unsqueeze_default_165, getitem_46, _unsafe_view_default_137, t_default_23, view_default_332, _unsafe_view_default_136, _unsafe_view_default_35, _unsafe_view_default_6, unsqueeze_default_151, t_default_15, primals_78, unsqueeze_default_39, view_default_188, add_tensor_16, _unsafe_view_default_7, add_tensor_40, primals_77, view_default_76, view_default_25, getitem_40, getitem_41, _softmax_default_8, getitem_1, t_default_42, _softmax_default_9, unsqueeze_default_137, getitem_2, t_default_41, t_default_4, _unsafe_view_default_13, primals_173, primals_174, primals_177, getitem_5, getitem_4, primals_178, t_default_6, _unsafe_view_default_4, _softmax_default, _softmax_default_7, t_default_2, primals_129, _unsafe_view_default_82, primals_158, add_tensor_64, primals_130, getitem_8, _unsafe_view_default_24, t_default_63, getitem_62, t_default_10, _unsafe_view_default_139, _unsafe_view_default_141, view_default_304, view_default_300, view_default_249, view_default_53, _unsafe_view_default_72, getitem_61, getitem_7, add_tensor_58, view_default_276, t_default_57, view_default_272, _unsafe_view_default_126, unsqueeze_default_25, view_default_52, _softmax_default_1, view_default_333, getitem_11, _unsafe_view_default_26, getitem_10, t_default_13, view_default_334, t_default_71, t_default_12, add_tensor_52, getitem_70, getitem_71, add_tensor_71, primals_81, primals_109, primals_82, primals_97, view_default_244, primals_110, primals_98, _unsafe_view_default_28, getitem_23, view_default_165, t_default_26, t_default_35, _unsafe_view_default_93, t_default_34, _unsafe_view_default_110, getitem_32, _unsafe_view_default_147, _unsafe_view_default_54, _unsafe_view_default_52, t_default_37, _unsafe_view_default_149, t_default_44, t_default_24, getitem_22, t_default_36, unsqueeze_default_67, getitem_35, _unsafe_view_default_80, t_default_33, _softmax_default_4, getitem_34, add_tensor_34, t_default_38, _softmax_default_10, view_default_138, _unsafe_view_default_78, _unsafe_view_default_76, _unsafe_view_default_74, view_default_160, getitem_31, getitem_20, primals_125, view_default_192, _unsafe_view_default_87, getitem_37, t_default_40, getitem_38, t_default_22, view_default_193, t_default_25, _unsafe_view_default_89, view_default_194, add_tensor_41, _unsafe_view_default_100, _unsafe_view_default_106, t_default_14, t_default_45, view_default_248, t_default_49, _unsafe_view_default_104, _unsafe_view_default_30, _unsafe_view_default_108, _unsafe_view_default_2, primals_13, primals_1, _unsafe_view_default_45, _unsafe_view_default_123, _unsafe_view_default_46, primals_2, primals_17, primals_14, _unsafe_view_default_111, primals_65, add_tensor_23, primals_66, _unsafe_view_default_48, t_default_3, _unsafe_view_default_50, _unsafe_view_default_11, add_tensor_22, primals_49, view_default_24, primals_50, _unsafe_view_default_9, primals_62, _unsafe_view_default_85, _unsafe_view_default_56, primals_61, primals_161, primals_162, getitem_19, getitem_13, view_default_108, view_default_220, getitem_16, t_default, view_default_110, _softmax_default_6, unsqueeze_default_109, t_default_21, t_default_1, unsqueeze_default_53, view_default_104, _unsafe_view_default_121, getitem_17, _unsafe_view_default_95, _unsafe_view_default_37, view_default_82, t_default_17, add_tensor_17, view_default_81, getitem_14, _unsafe_view_default, t_default_16, t_default_50, _softmax_default_2, t_default_7, _unsafe_view_default_15, view_default_80, t_default_8, _unsafe_view_default_17, primals_18, getitem_50, unsqueeze_default_11, _unsafe_view_default_115, getitem_49, add_tensor_4, _softmax_default_5, t_default_52, _unsafe_view_default_113, view_default_20, t_default_51, add_tensor_11, t_default_11, view_default_54, primals_142, _unsafe_view_default_84, primals_146, primals_145, unsqueeze_default_123, _unsafe_view_default_65, _unsafe_view_default_19, _unsafe_view_default_20, view_default_166, _unsafe_view_default_98, _unsafe_view_default_69, t_default_29, _unsafe_view_default_97, _unsafe_view_default_71, t_default_31, t_default_28, getitem_28, getitem_29, view_default_137, t_default_30, getitem_26, add_tensor_35, add_tensor_29, add_tensor_28, _unsafe_view_default_67, view_default_136, t_default_27, _unsafe_view_default_61, _unsafe_view_default_91, getitem_25, _unsafe_view_default_59, t_default_32, _unsafe_view_default_63, t_default_43, view_default_132, _unsafe_view_default_58, tangents_1):
        native_layer_norm_backward_default = torch.ops.aten.native_layer_norm_backward.default(tangents_1, add_tensor_71, [768], getitem_70, getitem_71, primals_46, primals_45, [True, True, True]);  tangents_1 = add_tensor_71 = getitem_70 = getitem_71 = primals_46 = primals_45 = None
        getitem_72 = native_layer_norm_backward_default[0]
        getitem_73 = native_layer_norm_backward_default[1]
        getitem_74 = native_layer_norm_backward_default[2];  native_layer_norm_backward_default = None
        view_default_336 = torch.ops.aten.view.default(getitem_72, [2048, 768])
        t_default_72 = torch.ops.aten.t.default(t_default_71);  t_default_71 = None
        mm_default_48 = torch.ops.aten.mm.default(view_default_336, t_default_72);  t_default_72 = None
        t_default_73 = torch.ops.aten.t.default(view_default_336)
        mm_default_49 = torch.ops.aten.mm.default(t_default_73, view_default_334);  t_default_73 = view_default_334 = None
        t_default_74 = torch.ops.aten.t.default(mm_default_49);  mm_default_49 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(view_default_336, [0], True);  view_default_336 = None
        view_default_337 = torch.ops.aten.view.default(sum_dim_int_list, [768]);  sum_dim_int_list = None
        t_default_75 = torch.ops.aten.t.default(t_default_74);  t_default_74 = None
        view_default_338 = torch.ops.aten.view.default(mm_default_48, [2, 1024, 3072]);  mm_default_48 = None
        to_dtype = torch.ops.aten.to.dtype(view_default_338, torch.float32);  view_default_338 = None
        to_dtype_1 = torch.ops.aten.to.dtype(view_default_333, torch.float32);  view_default_333 = None
        mul_tensor_12 = torch.ops.aten.mul.Tensor(to_dtype_1, 0.7071067811865476)
        erf_default = torch.ops.aten.erf.default(mul_tensor_12);  mul_tensor_12 = None
        add_tensor_72 = torch.ops.aten.add.Tensor(erf_default, 1);  erf_default = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(add_tensor_72, 0.5);  add_tensor_72 = None
        mul_tensor_14 = torch.ops.aten.mul.Tensor(to_dtype_1, to_dtype_1)
        mul_tensor_15 = torch.ops.aten.mul.Tensor(mul_tensor_14, -0.5);  mul_tensor_14 = None
        exp_default = torch.ops.aten.exp.default(mul_tensor_15);  mul_tensor_15 = None
        mul_tensor_16 = torch.ops.aten.mul.Tensor(exp_default, 0.3989422804014327);  exp_default = None
        mul_tensor_17 = torch.ops.aten.mul.Tensor(to_dtype_1, mul_tensor_16);  to_dtype_1 = mul_tensor_16 = None
        add_tensor_73 = torch.ops.aten.add.Tensor(mul_tensor_13, mul_tensor_17);  mul_tensor_13 = mul_tensor_17 = None
        mul_tensor_18 = torch.ops.aten.mul.Tensor(to_dtype, add_tensor_73);  to_dtype = add_tensor_73 = None
        to_dtype_2 = torch.ops.aten.to.dtype(mul_tensor_18, torch.float32);  mul_tensor_18 = None
        view_default_339 = torch.ops.aten.view.default(to_dtype_2, [2048, 3072]);  to_dtype_2 = None
        t_default_76 = torch.ops.aten.t.default(t_default_70);  t_default_70 = None
        mm_default_50 = torch.ops.aten.mm.default(view_default_339, t_default_76);  t_default_76 = None
        t_default_77 = torch.ops.aten.t.default(view_default_339)
        mm_default_51 = torch.ops.aten.mm.default(t_default_77, view_default_332);  t_default_77 = view_default_332 = None
        t_default_78 = torch.ops.aten.t.default(mm_default_51);  mm_default_51 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(view_default_339, [0], True);  view_default_339 = None
        view_default_340 = torch.ops.aten.view.default(sum_dim_int_list_1, [3072]);  sum_dim_int_list_1 = None
        t_default_79 = torch.ops.aten.t.default(t_default_78);  t_default_78 = None
        view_default_341 = torch.ops.aten.view.default(mm_default_50, [2, 1024, 768]);  mm_default_50 = None
        add_tensor_74 = torch.ops.aten.add.Tensor(getitem_72, view_default_341);  getitem_72 = view_default_341 = None
        native_layer_norm_backward_default_1 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_74, add_tensor_70, [768], getitem_67, getitem_68, primals_34, primals_33, [True, True, True]);  add_tensor_74 = add_tensor_70 = getitem_67 = getitem_68 = primals_34 = primals_33 = None
        getitem_75 = native_layer_norm_backward_default_1[0]
        getitem_76 = native_layer_norm_backward_default_1[1]
        getitem_77 = native_layer_norm_backward_default_1[2];  native_layer_norm_backward_default_1 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(getitem_75, [0, 1], True)
        view_default_342 = torch.ops.aten.view.default(sum_dim_int_list_2, [768]);  sum_dim_int_list_2 = None
        view_default_343 = torch.ops.aten.view.default(getitem_75, [2048, 768])
        t_default_80 = torch.ops.aten.t.default(view_default_343)
        mm_default_52 = torch.ops.aten.mm.default(t_default_80, _unsafe_view_default_154);  t_default_80 = _unsafe_view_default_154 = None
        t_default_81 = torch.ops.aten.t.default(mm_default_52);  mm_default_52 = None
        t_default_82 = torch.ops.aten.t.default(t_default_69);  t_default_69 = None
        mm_default_53 = torch.ops.aten.mm.default(view_default_343, t_default_82);  view_default_343 = t_default_82 = None
        view_default_344 = torch.ops.aten.view.default(mm_default_53, [2, 1024, 768]);  mm_default_53 = None
        t_default_83 = torch.ops.aten.t.default(t_default_81);  t_default_81 = None
        transpose_int_180 = torch.ops.aten.transpose.int(view_default_344, 0, 1);  view_default_344 = None
        view_default_345 = torch.ops.aten.view.default(transpose_int_180, [1024, 2, 12, 64]);  transpose_int_180 = None
        transpose_int_181 = torch.ops.aten.transpose.int(view_default_345, 0, 1);  view_default_345 = None
        transpose_int_182 = torch.ops.aten.transpose.int(transpose_int_181, 1, 2);  transpose_int_181 = None
        clone_default_108 = torch.ops.aten.clone.default(transpose_int_182, memory_format = torch.contiguous_format);  transpose_int_182 = None
        _unsafe_view_default_156 = torch.ops.aten._unsafe_view.default(clone_default_108, [24, 4, 256, 64]);  clone_default_108 = None
        view_default_346 = torch.ops.aten.view.default(_unsafe_view_default_156, [24, 4, 256, 64, 1]);  _unsafe_view_default_156 = None
        permute_default_144 = torch.ops.aten.permute.default(view_default_346, [0, 1, 2, 4, 3]);  view_default_346 = None
        view_default_347 = torch.ops.aten.view.default(permute_default_144, [96, 256, 64]);  permute_default_144 = None
        transpose_int_183 = torch.ops.aten.transpose.int(view_default_328, 1, 2);  view_default_328 = None
        bmm_default_24 = torch.ops.aten.bmm.default(transpose_int_183, view_default_347);  transpose_int_183 = None
        transpose_int_184 = torch.ops.aten.transpose.int(_unsafe_view_default_152, 1, 2);  _unsafe_view_default_152 = None
        bmm_default_25 = torch.ops.aten.bmm.default(view_default_347, transpose_int_184);  view_default_347 = transpose_int_184 = None
        view_default_348 = torch.ops.aten.view.default(bmm_default_24, [24, 4, 768, 64, 1]);  bmm_default_24 = None
        permute_default_145 = torch.ops.aten.permute.default(view_default_348, [0, 1, 4, 3, 2]);  view_default_348 = None
        view_default_349 = torch.ops.aten.view.default(bmm_default_25, [24, 4, 256, 768, 1]);  bmm_default_25 = None
        permute_default_146 = torch.ops.aten.permute.default(view_default_349, [0, 1, 2, 4, 3]);  view_default_349 = None
        permute_default_147 = torch.ops.aten.permute.default(permute_default_145, [0, 1, 4, 3, 2]);  permute_default_145 = None
        squeeze_dim_24 = torch.ops.aten.squeeze.dim(permute_default_147, -1);  permute_default_147 = None
        permute_default_148 = torch.ops.aten.permute.default(permute_default_146, [0, 1, 2, 4, 3]);  permute_default_146 = None
        squeeze_dim_25 = torch.ops.aten.squeeze.dim(permute_default_148, -1);  permute_default_148 = None
        slice_backward_default = torch.ops.aten.slice_backward.default(squeeze_dim_25, [24, 4, 256, 769], 3, 0, -1, 1);  squeeze_dim_25 = None
        slice_backward_default_1 = torch.ops.aten.slice_backward.default(slice_backward_default, [24, 4, 256, 769], 2, 0, 9223372036854775807, 1);  slice_backward_default = None
        slice_backward_default_2 = torch.ops.aten.slice_backward.default(slice_backward_default_1, [24, 4, 256, 769], 1, 0, 9223372036854775807, 1);  slice_backward_default_1 = None
        slice_backward_default_3 = torch.ops.aten.slice_backward.default(slice_backward_default_2, [24, 4, 256, 769], 0, 0, 9223372036854775807, 1);  slice_backward_default_2 = None
        view_default_350 = torch.ops.aten.view.default(slice_backward_default_3, [24, 4, 196864]);  slice_backward_default_3 = None
        slice_backward_default_4 = torch.ops.aten.slice_backward.default(view_default_350, [24, 4, 197120], 2, 0, -256, 1);  view_default_350 = None
        slice_backward_default_5 = torch.ops.aten.slice_backward.default(slice_backward_default_4, [24, 4, 197120], 1, 0, 9223372036854775807, 1);  slice_backward_default_4 = None
        slice_backward_default_6 = torch.ops.aten.slice_backward.default(slice_backward_default_5, [24, 4, 197120], 0, 0, 9223372036854775807, 1);  slice_backward_default_5 = None
        view_default_351 = torch.ops.aten.view.default(slice_backward_default_6, [24, 4, 256, 770]);  slice_backward_default_6 = None
        constant_pad_nd_default_48 = torch.ops.aten.constant_pad_nd.default(view_default_351, [0, -257]);  view_default_351 = None
        new_empty_default_60 = torch.ops.aten.new_empty.default(squeeze_dim_24, [2359296])
        zero__default = torch.ops.aten.zero_.default(new_empty_default_60);  new_empty_default_60 = None
        arange = torch.ops.aten.arange.start(0, 2359296, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_60 = torch.ops.aten.as_strided.default(arange, [24, 4, 768, 64], [98304, 16384, 64, 1], 0);  arange = None
        clone_default_109 = torch.ops.aten.clone.default(as_strided_default_60, memory_format = torch.contiguous_format);  as_strided_default_60 = None
        _unsafe_view_default_157 = torch.ops.aten._unsafe_view.default(clone_default_109, [4718592]);  clone_default_109 = None
        view_default_352 = torch.ops.aten.view.default(squeeze_dim_24, [4718592]);  squeeze_dim_24 = None
        index_add__default = torch.ops.aten.index_add_.default(zero__default, 0, _unsafe_view_default_157, view_default_352);  zero__default = _unsafe_view_default_157 = view_default_352 = None
        as_strided_default_61 = torch.ops.aten.as_strided.default(index_add__default, [24, 1536, 64], [98304, 64, 1], 0);  index_add__default = None
        constant_pad_nd_default_49 = torch.ops.aten.constant_pad_nd.default(as_strided_default_61, [0, 0, -256, -256]);  as_strided_default_61 = None
        view_default_353 = torch.ops.aten.view.default(constant_pad_nd_default_49, [2, 12, 1024, 64]);  constant_pad_nd_default_49 = None
        transpose_int_185 = torch.ops.aten.transpose.int(view_default_353, 1, 2);  view_default_353 = None
        view_default_354 = torch.ops.aten.view.default(constant_pad_nd_default_48, [2, 12, 1024, 513]);  constant_pad_nd_default_48 = None
        transpose_int_186 = torch.ops.aten.transpose.int(view_default_354, 1, 2);  view_default_354 = None
        transpose_int_187 = torch.ops.aten.transpose.int(transpose_int_185, 0, 1);  transpose_int_185 = None
        clone_default_110 = torch.ops.aten.clone.default(transpose_int_187, memory_format = torch.contiguous_format);  transpose_int_187 = None
        _unsafe_view_default_158 = torch.ops.aten._unsafe_view.default(clone_default_110, [1024, 2, 768]);  clone_default_110 = None
        where_scalar_self_24 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_165, 0.0, transpose_int_186);  unsqueeze_default_165 = transpose_int_186 = None
        _softmax_backward_data_default = torch.ops.aten._softmax_backward_data.default(where_scalar_self_24, _softmax_default_11, -1, torch.float32);  where_scalar_self_24 = _softmax_default_11 = None
        new_empty_default_61 = torch.ops.aten.new_empty.default(_softmax_backward_data_default, [12607488]);  _softmax_backward_data_default = None
        zero__default_1 = torch.ops.aten.zero_.default(new_empty_default_61);  new_empty_default_61 = None
        as_strided_default_63 = torch.ops.aten.as_strided.default(zero__default_1, [24, 4, 256, 513], [525312, 131328, 513, 1], 0);  zero__default_1 = None
        new_empty_strided_default = torch.ops.aten.new_empty_strided.default(as_strided_default_63, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_97 = torch.ops.aten.copy_.default(new_empty_strided_default, as_strided_default_63);  new_empty_strided_default = as_strided_default_63 = None
        new_empty_strided_default_1 = torch.ops.aten.new_empty_strided.default(copy__default_97, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_99 = torch.ops.aten.copy_.default(new_empty_strided_default_1, copy__default_97);  new_empty_strided_default_1 = copy__default_97 = None
        new_empty_strided_default_2 = torch.ops.aten.new_empty_strided.default(copy__default_99, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_101 = torch.ops.aten.copy_.default(new_empty_strided_default_2, copy__default_99);  new_empty_strided_default_2 = copy__default_99 = None
        new_empty_strided_default_3 = torch.ops.aten.new_empty_strided.default(copy__default_101, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_103 = torch.ops.aten.copy_.default(new_empty_strided_default_3, copy__default_101);  new_empty_strided_default_3 = copy__default_101 = None
        as_strided_default_67 = torch.ops.aten.as_strided.default(copy__default_103, [24, 255, 255], [525312, 513, 1], 514)
        clone_default_114 = torch.ops.aten.clone.default(as_strided_default_67, memory_format = torch.contiguous_format);  as_strided_default_67 = None
        slice_backward_default_7 = torch.ops.aten.slice_backward.default(clone_default_114, [24, 255, 513], 2, -255, 9223372036854775807, 1);  clone_default_114 = None
        slice_backward_default_8 = torch.ops.aten.slice_backward.default(slice_backward_default_7, [24, 512, 513], 1, 0, 255, 1);  slice_backward_default_7 = None
        select_backward_default = torch.ops.aten.select_backward.default(slice_backward_default_8, [24, 3, 512, 513], 1, 0);  slice_backward_default_8 = None
        slice_backward_default_9 = torch.ops.aten.slice_backward.default(select_backward_default, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default = None
        new_empty_strided_default_4 = torch.ops.aten.new_empty_strided.default(copy__default_103, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_105 = torch.ops.aten.copy_.default(new_empty_strided_default_4, copy__default_103);  new_empty_strided_default_4 = copy__default_103 = None
        as_strided_default_68 = torch.ops.aten.as_strided.default(copy__default_105, [24, 3, 256, 256], [525312, 131328, 513, 1], 131328)
        clone_default_115 = torch.ops.aten.clone.default(as_strided_default_68, memory_format = torch.contiguous_format);  as_strided_default_68 = None
        slice_backward_default_10 = torch.ops.aten.slice_backward.default(clone_default_115, [24, 3, 256, 513], 3, 257, 9223372036854775807, 1);  clone_default_115 = None
        slice_backward_default_11 = torch.ops.aten.slice_backward.default(slice_backward_default_10, [24, 3, 512, 513], 2, -257, -1, 1);  slice_backward_default_10 = None
        slice_backward_default_12 = torch.ops.aten.slice_backward.default(slice_backward_default_11, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_11 = None
        slice_backward_default_13 = torch.ops.aten.slice_backward.default(slice_backward_default_12, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_12 = None
        add_tensor_75 = torch.ops.aten.add.Tensor(slice_backward_default_9, slice_backward_default_13);  slice_backward_default_9 = slice_backward_default_13 = None
        new_empty_strided_default_5 = torch.ops.aten.new_empty_strided.default(copy__default_105, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_107 = torch.ops.aten.copy_.default(new_empty_strided_default_5, copy__default_105);  new_empty_strided_default_5 = copy__default_105 = None
        as_strided_default_69 = torch.ops.aten.as_strided.default(copy__default_107, [24, 256, 257], [525312, 513, 1], 394240)
        clone_default_116 = torch.ops.aten.clone.default(as_strided_default_69, memory_format = torch.contiguous_format);  as_strided_default_69 = None
        slice_backward_default_14 = torch.ops.aten.slice_backward.default(clone_default_116, [24, 256, 513], 2, 0, 257, 1);  clone_default_116 = None
        slice_backward_default_15 = torch.ops.aten.slice_backward.default(slice_backward_default_14, [24, 512, 513], 1, 256, 9223372036854775807, 1);  slice_backward_default_14 = None
        select_backward_default_1 = torch.ops.aten.select_backward.default(slice_backward_default_15, [24, 3, 512, 513], 1, -1);  slice_backward_default_15 = None
        slice_backward_default_16 = torch.ops.aten.slice_backward.default(select_backward_default_1, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_1 = None
        add_tensor_76 = torch.ops.aten.add.Tensor(add_tensor_75, slice_backward_default_16);  add_tensor_75 = slice_backward_default_16 = None
        new_empty_strided_default_6 = torch.ops.aten.new_empty_strided.default(copy__default_107, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_109 = torch.ops.aten.copy_.default(new_empty_strided_default_6, copy__default_107);  new_empty_strided_default_6 = copy__default_107 = None
        as_strided_default_70 = torch.ops.aten.as_strided.default(copy__default_109, [24, 3, 256, 257], [525312, 131328, 513, 1], 256);  copy__default_109 = None
        clone_default_117 = torch.ops.aten.clone.default(as_strided_default_70, memory_format = torch.contiguous_format);  as_strided_default_70 = None
        slice_backward_default_17 = torch.ops.aten.slice_backward.default(clone_default_117, [24, 3, 256, 513], 3, 0, 257, 1);  clone_default_117 = None
        slice_backward_default_18 = torch.ops.aten.slice_backward.default(slice_backward_default_17, [24, 3, 512, 513], 2, 0, 256, 1);  slice_backward_default_17 = None
        slice_backward_default_19 = torch.ops.aten.slice_backward.default(slice_backward_default_18, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_18 = None
        slice_backward_default_20 = torch.ops.aten.slice_backward.default(slice_backward_default_19, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_19 = None
        add_tensor_77 = torch.ops.aten.add.Tensor(add_tensor_76, slice_backward_default_20);  add_tensor_76 = slice_backward_default_20 = None
        view_default_355 = torch.ops.aten.view.default(add_tensor_77, [24, 3, 513, 512]);  add_tensor_77 = None
        constant_pad_nd_default_50 = torch.ops.aten.constant_pad_nd.default(view_default_355, [0, 0, 0, -1]);  view_default_355 = None
        view_default_356 = torch.ops.aten.view.default(constant_pad_nd_default_50, [24, 3, 512, 512, 1]);  constant_pad_nd_default_50 = None
        permute_default_149 = torch.ops.aten.permute.default(view_default_356, [0, 1, 2, 4, 3]);  view_default_356 = None
        view_default_357 = torch.ops.aten.view.default(permute_default_149, [72, 512, 512]);  permute_default_149 = None
        transpose_int_188 = torch.ops.aten.transpose.int(_unsafe_view_default_149, 1, 2);  _unsafe_view_default_149 = None
        bmm_default_26 = torch.ops.aten.bmm.default(transpose_int_188, view_default_357);  transpose_int_188 = None
        transpose_int_189 = torch.ops.aten.transpose.int(_unsafe_view_default_150, 1, 2);  _unsafe_view_default_150 = None
        bmm_default_27 = torch.ops.aten.bmm.default(view_default_357, transpose_int_189);  view_default_357 = transpose_int_189 = None
        view_default_358 = torch.ops.aten.view.default(bmm_default_26, [24, 3, 64, 512, 1]);  bmm_default_26 = None
        permute_default_150 = torch.ops.aten.permute.default(view_default_358, [0, 1, 4, 3, 2]);  view_default_358 = None
        view_default_359 = torch.ops.aten.view.default(bmm_default_27, [24, 3, 512, 64, 1]);  bmm_default_27 = None
        permute_default_151 = torch.ops.aten.permute.default(view_default_359, [0, 1, 2, 4, 3]);  view_default_359 = None
        permute_default_152 = torch.ops.aten.permute.default(permute_default_150, [0, 1, 3, 4, 2]);  permute_default_150 = None
        squeeze_dim_26 = torch.ops.aten.squeeze.dim(permute_default_152, -1);  permute_default_152 = None
        permute_default_153 = torch.ops.aten.permute.default(permute_default_151, [0, 1, 2, 4, 3]);  permute_default_151 = None
        squeeze_dim_27 = torch.ops.aten.squeeze.dim(permute_default_153, -1);  permute_default_153 = None
        new_empty_default_62 = torch.ops.aten.new_empty.default(squeeze_dim_26, [1572864])
        zero__default_5 = torch.ops.aten.zero_.default(new_empty_default_62);  new_empty_default_62 = None
        arange_1 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_71 = torch.ops.aten.as_strided.default(arange_1, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_1 = None
        clone_default_118 = torch.ops.aten.clone.default(as_strided_default_71, memory_format = torch.contiguous_format);  as_strided_default_71 = None
        _unsafe_view_default_159 = torch.ops.aten._unsafe_view.default(clone_default_118, [2359296]);  clone_default_118 = None
        clone_default_119 = torch.ops.aten.clone.default(squeeze_dim_26, memory_format = torch.contiguous_format);  squeeze_dim_26 = None
        _unsafe_view_default_160 = torch.ops.aten._unsafe_view.default(clone_default_119, [2359296]);  clone_default_119 = None
        index_add__default_1 = torch.ops.aten.index_add_.default(zero__default_5, 0, _unsafe_view_default_159, _unsafe_view_default_160);  zero__default_5 = _unsafe_view_default_159 = _unsafe_view_default_160 = None
        as_strided_default_72 = torch.ops.aten.as_strided.default(index_add__default_1, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_1 = None
        view_default_360 = torch.ops.aten.view.default(as_strided_default_72, [24, 1024, 64]);  as_strided_default_72 = None
        new_empty_default_63 = torch.ops.aten.new_empty.default(squeeze_dim_27, [1572864])
        zero__default_6 = torch.ops.aten.zero_.default(new_empty_default_63);  new_empty_default_63 = None
        arange_2 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_73 = torch.ops.aten.as_strided.default(arange_2, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_2 = None
        clone_default_120 = torch.ops.aten.clone.default(as_strided_default_73, memory_format = torch.contiguous_format);  as_strided_default_73 = None
        _unsafe_view_default_161 = torch.ops.aten._unsafe_view.default(clone_default_120, [2359296]);  clone_default_120 = None
        view_default_361 = torch.ops.aten.view.default(squeeze_dim_27, [2359296]);  squeeze_dim_27 = None
        index_add__default_2 = torch.ops.aten.index_add_.default(zero__default_6, 0, _unsafe_view_default_161, view_default_361);  zero__default_6 = _unsafe_view_default_161 = view_default_361 = None
        as_strided_default_74 = torch.ops.aten.as_strided.default(index_add__default_2, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_2 = None
        view_default_362 = torch.ops.aten.view.default(as_strided_default_74, [24, 1024, 64]);  as_strided_default_74 = None
        view_default_363 = torch.ops.aten.view.default(view_default_360, [2, 12, 1024, 64]);  view_default_360 = None
        transpose_int_190 = torch.ops.aten.transpose.int(view_default_363, 1, 2);  view_default_363 = None
        view_default_364 = torch.ops.aten.view.default(view_default_362, [2, 12, 1024, 64]);  view_default_362 = None
        transpose_int_191 = torch.ops.aten.transpose.int(view_default_364, 1, 2);  view_default_364 = None
        transpose_int_192 = torch.ops.aten.transpose.int(transpose_int_190, 0, 1);  transpose_int_190 = None
        view_default_365 = torch.ops.aten.view.default(transpose_int_192, [1024, 2, 768]);  transpose_int_192 = None
        transpose_int_193 = torch.ops.aten.transpose.int(transpose_int_191, 0, 1);  transpose_int_191 = None
        view_default_366 = torch.ops.aten.view.default(transpose_int_193, [1024, 2, 768]);  transpose_int_193 = None
        div_tensor = torch.ops.aten.div.Tensor(view_default_366, 8.0);  view_default_366 = None
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_158, [0, 1], True)
        view_default_367 = torch.ops.aten.view.default(sum_dim_int_list_3, [768]);  sum_dim_int_list_3 = None
        view_default_368 = torch.ops.aten.view.default(_unsafe_view_default_158, [2048, 768]);  _unsafe_view_default_158 = None
        t_default_84 = torch.ops.aten.t.default(view_default_368)
        mm_default_54 = torch.ops.aten.mm.default(t_default_84, _unsafe_view_default_147);  t_default_84 = _unsafe_view_default_147 = None
        t_default_85 = torch.ops.aten.t.default(mm_default_54);  mm_default_54 = None
        t_default_86 = torch.ops.aten.t.default(t_default_68);  t_default_68 = None
        mm_default_55 = torch.ops.aten.mm.default(view_default_368, t_default_86);  view_default_368 = t_default_86 = None
        view_default_369 = torch.ops.aten.view.default(mm_default_55, [1024, 2, 768]);  mm_default_55 = None
        t_default_87 = torch.ops.aten.t.default(t_default_85);  t_default_85 = None
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(view_default_365, [0, 1], True)
        view_default_370 = torch.ops.aten.view.default(sum_dim_int_list_4, [768]);  sum_dim_int_list_4 = None
        view_default_371 = torch.ops.aten.view.default(view_default_365, [2048, 768]);  view_default_365 = None
        t_default_88 = torch.ops.aten.t.default(view_default_371)
        mm_default_56 = torch.ops.aten.mm.default(t_default_88, _unsafe_view_default_145);  t_default_88 = _unsafe_view_default_145 = None
        t_default_89 = torch.ops.aten.t.default(mm_default_56);  mm_default_56 = None
        t_default_90 = torch.ops.aten.t.default(t_default_67);  t_default_67 = None
        mm_default_57 = torch.ops.aten.mm.default(view_default_371, t_default_90);  view_default_371 = t_default_90 = None
        view_default_372 = torch.ops.aten.view.default(mm_default_57, [1024, 2, 768]);  mm_default_57 = None
        add_tensor_78 = torch.ops.aten.add.Tensor(view_default_369, view_default_372);  view_default_369 = view_default_372 = None
        t_default_91 = torch.ops.aten.t.default(t_default_89);  t_default_89 = None
        sum_dim_int_list_5 = torch.ops.aten.sum.dim_IntList(div_tensor, [0, 1], True)
        view_default_373 = torch.ops.aten.view.default(sum_dim_int_list_5, [768]);  sum_dim_int_list_5 = None
        view_default_374 = torch.ops.aten.view.default(div_tensor, [2048, 768]);  div_tensor = None
        t_default_92 = torch.ops.aten.t.default(view_default_374)
        mm_default_58 = torch.ops.aten.mm.default(t_default_92, _unsafe_view_default_143);  t_default_92 = _unsafe_view_default_143 = None
        t_default_93 = torch.ops.aten.t.default(mm_default_58);  mm_default_58 = None
        t_default_94 = torch.ops.aten.t.default(t_default_66);  t_default_66 = None
        mm_default_59 = torch.ops.aten.mm.default(view_default_374, t_default_94);  view_default_374 = t_default_94 = None
        view_default_375 = torch.ops.aten.view.default(mm_default_59, [1024, 2, 768]);  mm_default_59 = None
        add_tensor_79 = torch.ops.aten.add.Tensor(add_tensor_78, view_default_375);  add_tensor_78 = view_default_375 = None
        t_default_95 = torch.ops.aten.t.default(t_default_93);  t_default_93 = None
        transpose_int_194 = torch.ops.aten.transpose.int(add_tensor_79, 0, 1);  add_tensor_79 = None
        add_tensor_80 = torch.ops.aten.add.Tensor(getitem_75, transpose_int_194);  getitem_75 = transpose_int_194 = None
        native_layer_norm_backward_default_2 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_80, add_tensor_65, [768], getitem_64, getitem_65, primals_30, primals_29, [True, True, True]);  add_tensor_80 = add_tensor_65 = getitem_64 = getitem_65 = primals_30 = primals_29 = None
        getitem_78 = native_layer_norm_backward_default_2[0]
        getitem_79 = native_layer_norm_backward_default_2[1]
        getitem_80 = native_layer_norm_backward_default_2[2];  native_layer_norm_backward_default_2 = None
        view_default_376 = torch.ops.aten.view.default(getitem_78, [2048, 768])
        t_default_96 = torch.ops.aten.t.default(t_default_65);  t_default_65 = None
        mm_default_60 = torch.ops.aten.mm.default(view_default_376, t_default_96);  t_default_96 = None
        t_default_97 = torch.ops.aten.t.default(view_default_376)
        mm_default_61 = torch.ops.aten.mm.default(t_default_97, view_default_306);  t_default_97 = view_default_306 = None
        t_default_98 = torch.ops.aten.t.default(mm_default_61);  mm_default_61 = None
        sum_dim_int_list_6 = torch.ops.aten.sum.dim_IntList(view_default_376, [0], True);  view_default_376 = None
        view_default_377 = torch.ops.aten.view.default(sum_dim_int_list_6, [768]);  sum_dim_int_list_6 = None
        t_default_99 = torch.ops.aten.t.default(t_default_98);  t_default_98 = None
        view_default_378 = torch.ops.aten.view.default(mm_default_60, [2, 1024, 3072]);  mm_default_60 = None
        to_dtype_3 = torch.ops.aten.to.dtype(view_default_378, torch.float32);  view_default_378 = None
        to_dtype_4 = torch.ops.aten.to.dtype(view_default_305, torch.float32);  view_default_305 = None
        mul_tensor_19 = torch.ops.aten.mul.Tensor(to_dtype_4, 0.7071067811865476)
        erf_default_1 = torch.ops.aten.erf.default(mul_tensor_19);  mul_tensor_19 = None
        add_tensor_81 = torch.ops.aten.add.Tensor(erf_default_1, 1);  erf_default_1 = None
        mul_tensor_20 = torch.ops.aten.mul.Tensor(add_tensor_81, 0.5);  add_tensor_81 = None
        mul_tensor_21 = torch.ops.aten.mul.Tensor(to_dtype_4, to_dtype_4)
        mul_tensor_22 = torch.ops.aten.mul.Tensor(mul_tensor_21, -0.5);  mul_tensor_21 = None
        exp_default_1 = torch.ops.aten.exp.default(mul_tensor_22);  mul_tensor_22 = None
        mul_tensor_23 = torch.ops.aten.mul.Tensor(exp_default_1, 0.3989422804014327);  exp_default_1 = None
        mul_tensor_24 = torch.ops.aten.mul.Tensor(to_dtype_4, mul_tensor_23);  to_dtype_4 = mul_tensor_23 = None
        add_tensor_82 = torch.ops.aten.add.Tensor(mul_tensor_20, mul_tensor_24);  mul_tensor_20 = mul_tensor_24 = None
        mul_tensor_25 = torch.ops.aten.mul.Tensor(to_dtype_3, add_tensor_82);  to_dtype_3 = add_tensor_82 = None
        to_dtype_5 = torch.ops.aten.to.dtype(mul_tensor_25, torch.float32);  mul_tensor_25 = None
        view_default_379 = torch.ops.aten.view.default(to_dtype_5, [2048, 3072]);  to_dtype_5 = None
        t_default_100 = torch.ops.aten.t.default(t_default_64);  t_default_64 = None
        mm_default_62 = torch.ops.aten.mm.default(view_default_379, t_default_100);  t_default_100 = None
        t_default_101 = torch.ops.aten.t.default(view_default_379)
        mm_default_63 = torch.ops.aten.mm.default(t_default_101, view_default_304);  t_default_101 = view_default_304 = None
        t_default_102 = torch.ops.aten.t.default(mm_default_63);  mm_default_63 = None
        sum_dim_int_list_7 = torch.ops.aten.sum.dim_IntList(view_default_379, [0], True);  view_default_379 = None
        view_default_380 = torch.ops.aten.view.default(sum_dim_int_list_7, [3072]);  sum_dim_int_list_7 = None
        t_default_103 = torch.ops.aten.t.default(t_default_102);  t_default_102 = None
        view_default_381 = torch.ops.aten.view.default(mm_default_62, [2, 1024, 768]);  mm_default_62 = None
        add_tensor_83 = torch.ops.aten.add.Tensor(getitem_78, view_default_381);  getitem_78 = view_default_381 = None
        native_layer_norm_backward_default_3 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_83, add_tensor_64, [768], getitem_61, getitem_62, primals_18, primals_17, [True, True, True]);  add_tensor_83 = add_tensor_64 = getitem_61 = getitem_62 = primals_18 = primals_17 = None
        getitem_81 = native_layer_norm_backward_default_3[0]
        getitem_82 = native_layer_norm_backward_default_3[1]
        getitem_83 = native_layer_norm_backward_default_3[2];  native_layer_norm_backward_default_3 = None
        sum_dim_int_list_8 = torch.ops.aten.sum.dim_IntList(getitem_81, [0, 1], True)
        view_default_382 = torch.ops.aten.view.default(sum_dim_int_list_8, [768]);  sum_dim_int_list_8 = None
        view_default_383 = torch.ops.aten.view.default(getitem_81, [2048, 768])
        t_default_104 = torch.ops.aten.t.default(view_default_383)
        mm_default_64 = torch.ops.aten.mm.default(t_default_104, _unsafe_view_default_141);  t_default_104 = _unsafe_view_default_141 = None
        t_default_105 = torch.ops.aten.t.default(mm_default_64);  mm_default_64 = None
        t_default_106 = torch.ops.aten.t.default(t_default_63);  t_default_63 = None
        mm_default_65 = torch.ops.aten.mm.default(view_default_383, t_default_106);  view_default_383 = t_default_106 = None
        view_default_384 = torch.ops.aten.view.default(mm_default_65, [2, 1024, 768]);  mm_default_65 = None
        t_default_107 = torch.ops.aten.t.default(t_default_105);  t_default_105 = None
        transpose_int_195 = torch.ops.aten.transpose.int(view_default_384, 0, 1);  view_default_384 = None
        view_default_385 = torch.ops.aten.view.default(transpose_int_195, [1024, 2, 12, 64]);  transpose_int_195 = None
        transpose_int_196 = torch.ops.aten.transpose.int(view_default_385, 0, 1);  view_default_385 = None
        transpose_int_197 = torch.ops.aten.transpose.int(transpose_int_196, 1, 2);  transpose_int_196 = None
        clone_default_121 = torch.ops.aten.clone.default(transpose_int_197, memory_format = torch.contiguous_format);  transpose_int_197 = None
        _unsafe_view_default_162 = torch.ops.aten._unsafe_view.default(clone_default_121, [24, 4, 256, 64]);  clone_default_121 = None
        view_default_386 = torch.ops.aten.view.default(_unsafe_view_default_162, [24, 4, 256, 64, 1]);  _unsafe_view_default_162 = None
        permute_default_154 = torch.ops.aten.permute.default(view_default_386, [0, 1, 2, 4, 3]);  view_default_386 = None
        view_default_387 = torch.ops.aten.view.default(permute_default_154, [96, 256, 64]);  permute_default_154 = None
        transpose_int_198 = torch.ops.aten.transpose.int(view_default_300, 1, 2);  view_default_300 = None
        bmm_default_28 = torch.ops.aten.bmm.default(transpose_int_198, view_default_387);  transpose_int_198 = None
        transpose_int_199 = torch.ops.aten.transpose.int(_unsafe_view_default_139, 1, 2);  _unsafe_view_default_139 = None
        bmm_default_29 = torch.ops.aten.bmm.default(view_default_387, transpose_int_199);  view_default_387 = transpose_int_199 = None
        view_default_388 = torch.ops.aten.view.default(bmm_default_28, [24, 4, 768, 64, 1]);  bmm_default_28 = None
        permute_default_155 = torch.ops.aten.permute.default(view_default_388, [0, 1, 4, 3, 2]);  view_default_388 = None
        view_default_389 = torch.ops.aten.view.default(bmm_default_29, [24, 4, 256, 768, 1]);  bmm_default_29 = None
        permute_default_156 = torch.ops.aten.permute.default(view_default_389, [0, 1, 2, 4, 3]);  view_default_389 = None
        permute_default_157 = torch.ops.aten.permute.default(permute_default_155, [0, 1, 4, 3, 2]);  permute_default_155 = None
        squeeze_dim_28 = torch.ops.aten.squeeze.dim(permute_default_157, -1);  permute_default_157 = None
        permute_default_158 = torch.ops.aten.permute.default(permute_default_156, [0, 1, 2, 4, 3]);  permute_default_156 = None
        squeeze_dim_29 = torch.ops.aten.squeeze.dim(permute_default_158, -1);  permute_default_158 = None
        slice_backward_default_21 = torch.ops.aten.slice_backward.default(squeeze_dim_29, [24, 4, 256, 769], 3, 0, -1, 1);  squeeze_dim_29 = None
        slice_backward_default_22 = torch.ops.aten.slice_backward.default(slice_backward_default_21, [24, 4, 256, 769], 2, 0, 9223372036854775807, 1);  slice_backward_default_21 = None
        slice_backward_default_23 = torch.ops.aten.slice_backward.default(slice_backward_default_22, [24, 4, 256, 769], 1, 0, 9223372036854775807, 1);  slice_backward_default_22 = None
        slice_backward_default_24 = torch.ops.aten.slice_backward.default(slice_backward_default_23, [24, 4, 256, 769], 0, 0, 9223372036854775807, 1);  slice_backward_default_23 = None
        view_default_390 = torch.ops.aten.view.default(slice_backward_default_24, [24, 4, 196864]);  slice_backward_default_24 = None
        slice_backward_default_25 = torch.ops.aten.slice_backward.default(view_default_390, [24, 4, 197120], 2, 0, -256, 1);  view_default_390 = None
        slice_backward_default_26 = torch.ops.aten.slice_backward.default(slice_backward_default_25, [24, 4, 197120], 1, 0, 9223372036854775807, 1);  slice_backward_default_25 = None
        slice_backward_default_27 = torch.ops.aten.slice_backward.default(slice_backward_default_26, [24, 4, 197120], 0, 0, 9223372036854775807, 1);  slice_backward_default_26 = None
        view_default_391 = torch.ops.aten.view.default(slice_backward_default_27, [24, 4, 256, 770]);  slice_backward_default_27 = None
        constant_pad_nd_default_51 = torch.ops.aten.constant_pad_nd.default(view_default_391, [0, -257]);  view_default_391 = None
        new_empty_default_64 = torch.ops.aten.new_empty.default(squeeze_dim_28, [2359296])
        zero__default_7 = torch.ops.aten.zero_.default(new_empty_default_64);  new_empty_default_64 = None
        arange_3 = torch.ops.aten.arange.start(0, 2359296, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_75 = torch.ops.aten.as_strided.default(arange_3, [24, 4, 768, 64], [98304, 16384, 64, 1], 0);  arange_3 = None
        clone_default_122 = torch.ops.aten.clone.default(as_strided_default_75, memory_format = torch.contiguous_format);  as_strided_default_75 = None
        _unsafe_view_default_163 = torch.ops.aten._unsafe_view.default(clone_default_122, [4718592]);  clone_default_122 = None
        view_default_392 = torch.ops.aten.view.default(squeeze_dim_28, [4718592]);  squeeze_dim_28 = None
        index_add__default_3 = torch.ops.aten.index_add_.default(zero__default_7, 0, _unsafe_view_default_163, view_default_392);  zero__default_7 = _unsafe_view_default_163 = view_default_392 = None
        as_strided_default_76 = torch.ops.aten.as_strided.default(index_add__default_3, [24, 1536, 64], [98304, 64, 1], 0);  index_add__default_3 = None
        constant_pad_nd_default_52 = torch.ops.aten.constant_pad_nd.default(as_strided_default_76, [0, 0, -256, -256]);  as_strided_default_76 = None
        view_default_393 = torch.ops.aten.view.default(constant_pad_nd_default_52, [2, 12, 1024, 64]);  constant_pad_nd_default_52 = None
        transpose_int_200 = torch.ops.aten.transpose.int(view_default_393, 1, 2);  view_default_393 = None
        view_default_394 = torch.ops.aten.view.default(constant_pad_nd_default_51, [2, 12, 1024, 513]);  constant_pad_nd_default_51 = None
        transpose_int_201 = torch.ops.aten.transpose.int(view_default_394, 1, 2);  view_default_394 = None
        transpose_int_202 = torch.ops.aten.transpose.int(transpose_int_200, 0, 1);  transpose_int_200 = None
        clone_default_123 = torch.ops.aten.clone.default(transpose_int_202, memory_format = torch.contiguous_format);  transpose_int_202 = None
        _unsafe_view_default_164 = torch.ops.aten._unsafe_view.default(clone_default_123, [1024, 2, 768]);  clone_default_123 = None
        where_scalar_self_27 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_151, 0.0, transpose_int_201);  unsqueeze_default_151 = transpose_int_201 = None
        _softmax_backward_data_default_1 = torch.ops.aten._softmax_backward_data.default(where_scalar_self_27, _softmax_default_10, -1, torch.float32);  where_scalar_self_27 = _softmax_default_10 = None
        new_empty_default_65 = torch.ops.aten.new_empty.default(_softmax_backward_data_default_1, [12607488]);  _softmax_backward_data_default_1 = None
        zero__default_8 = torch.ops.aten.zero_.default(new_empty_default_65);  new_empty_default_65 = None
        as_strided_default_78 = torch.ops.aten.as_strided.default(zero__default_8, [24, 4, 256, 513], [525312, 131328, 513, 1], 0);  zero__default_8 = None
        new_empty_strided_default_7 = torch.ops.aten.new_empty_strided.default(as_strided_default_78, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_111 = torch.ops.aten.copy_.default(new_empty_strided_default_7, as_strided_default_78);  new_empty_strided_default_7 = as_strided_default_78 = None
        new_empty_strided_default_8 = torch.ops.aten.new_empty_strided.default(copy__default_111, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_113 = torch.ops.aten.copy_.default(new_empty_strided_default_8, copy__default_111);  new_empty_strided_default_8 = copy__default_111 = None
        new_empty_strided_default_9 = torch.ops.aten.new_empty_strided.default(copy__default_113, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_115 = torch.ops.aten.copy_.default(new_empty_strided_default_9, copy__default_113);  new_empty_strided_default_9 = copy__default_113 = None
        new_empty_strided_default_10 = torch.ops.aten.new_empty_strided.default(copy__default_115, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_117 = torch.ops.aten.copy_.default(new_empty_strided_default_10, copy__default_115);  new_empty_strided_default_10 = copy__default_115 = None
        as_strided_default_82 = torch.ops.aten.as_strided.default(copy__default_117, [24, 255, 255], [525312, 513, 1], 514)
        clone_default_127 = torch.ops.aten.clone.default(as_strided_default_82, memory_format = torch.contiguous_format);  as_strided_default_82 = None
        slice_backward_default_28 = torch.ops.aten.slice_backward.default(clone_default_127, [24, 255, 513], 2, -255, 9223372036854775807, 1);  clone_default_127 = None
        slice_backward_default_29 = torch.ops.aten.slice_backward.default(slice_backward_default_28, [24, 512, 513], 1, 0, 255, 1);  slice_backward_default_28 = None
        select_backward_default_2 = torch.ops.aten.select_backward.default(slice_backward_default_29, [24, 3, 512, 513], 1, 0);  slice_backward_default_29 = None
        slice_backward_default_30 = torch.ops.aten.slice_backward.default(select_backward_default_2, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_2 = None
        new_empty_strided_default_11 = torch.ops.aten.new_empty_strided.default(copy__default_117, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_119 = torch.ops.aten.copy_.default(new_empty_strided_default_11, copy__default_117);  new_empty_strided_default_11 = copy__default_117 = None
        as_strided_default_83 = torch.ops.aten.as_strided.default(copy__default_119, [24, 3, 256, 256], [525312, 131328, 513, 1], 131328)
        clone_default_128 = torch.ops.aten.clone.default(as_strided_default_83, memory_format = torch.contiguous_format);  as_strided_default_83 = None
        slice_backward_default_31 = torch.ops.aten.slice_backward.default(clone_default_128, [24, 3, 256, 513], 3, 257, 9223372036854775807, 1);  clone_default_128 = None
        slice_backward_default_32 = torch.ops.aten.slice_backward.default(slice_backward_default_31, [24, 3, 512, 513], 2, -257, -1, 1);  slice_backward_default_31 = None
        slice_backward_default_33 = torch.ops.aten.slice_backward.default(slice_backward_default_32, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_32 = None
        slice_backward_default_34 = torch.ops.aten.slice_backward.default(slice_backward_default_33, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_33 = None
        add_tensor_84 = torch.ops.aten.add.Tensor(slice_backward_default_30, slice_backward_default_34);  slice_backward_default_30 = slice_backward_default_34 = None
        new_empty_strided_default_12 = torch.ops.aten.new_empty_strided.default(copy__default_119, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_121 = torch.ops.aten.copy_.default(new_empty_strided_default_12, copy__default_119);  new_empty_strided_default_12 = copy__default_119 = None
        as_strided_default_84 = torch.ops.aten.as_strided.default(copy__default_121, [24, 256, 257], [525312, 513, 1], 394240)
        clone_default_129 = torch.ops.aten.clone.default(as_strided_default_84, memory_format = torch.contiguous_format);  as_strided_default_84 = None
        slice_backward_default_35 = torch.ops.aten.slice_backward.default(clone_default_129, [24, 256, 513], 2, 0, 257, 1);  clone_default_129 = None
        slice_backward_default_36 = torch.ops.aten.slice_backward.default(slice_backward_default_35, [24, 512, 513], 1, 256, 9223372036854775807, 1);  slice_backward_default_35 = None
        select_backward_default_3 = torch.ops.aten.select_backward.default(slice_backward_default_36, [24, 3, 512, 513], 1, -1);  slice_backward_default_36 = None
        slice_backward_default_37 = torch.ops.aten.slice_backward.default(select_backward_default_3, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_3 = None
        add_tensor_85 = torch.ops.aten.add.Tensor(add_tensor_84, slice_backward_default_37);  add_tensor_84 = slice_backward_default_37 = None
        new_empty_strided_default_13 = torch.ops.aten.new_empty_strided.default(copy__default_121, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_123 = torch.ops.aten.copy_.default(new_empty_strided_default_13, copy__default_121);  new_empty_strided_default_13 = copy__default_121 = None
        as_strided_default_85 = torch.ops.aten.as_strided.default(copy__default_123, [24, 3, 256, 257], [525312, 131328, 513, 1], 256);  copy__default_123 = None
        clone_default_130 = torch.ops.aten.clone.default(as_strided_default_85, memory_format = torch.contiguous_format);  as_strided_default_85 = None
        slice_backward_default_38 = torch.ops.aten.slice_backward.default(clone_default_130, [24, 3, 256, 513], 3, 0, 257, 1);  clone_default_130 = None
        slice_backward_default_39 = torch.ops.aten.slice_backward.default(slice_backward_default_38, [24, 3, 512, 513], 2, 0, 256, 1);  slice_backward_default_38 = None
        slice_backward_default_40 = torch.ops.aten.slice_backward.default(slice_backward_default_39, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_39 = None
        slice_backward_default_41 = torch.ops.aten.slice_backward.default(slice_backward_default_40, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_40 = None
        add_tensor_86 = torch.ops.aten.add.Tensor(add_tensor_85, slice_backward_default_41);  add_tensor_85 = slice_backward_default_41 = None
        view_default_395 = torch.ops.aten.view.default(add_tensor_86, [24, 3, 513, 512]);  add_tensor_86 = None
        constant_pad_nd_default_53 = torch.ops.aten.constant_pad_nd.default(view_default_395, [0, 0, 0, -1]);  view_default_395 = None
        view_default_396 = torch.ops.aten.view.default(constant_pad_nd_default_53, [24, 3, 512, 512, 1]);  constant_pad_nd_default_53 = None
        permute_default_159 = torch.ops.aten.permute.default(view_default_396, [0, 1, 2, 4, 3]);  view_default_396 = None
        view_default_397 = torch.ops.aten.view.default(permute_default_159, [72, 512, 512]);  permute_default_159 = None
        transpose_int_203 = torch.ops.aten.transpose.int(_unsafe_view_default_136, 1, 2);  _unsafe_view_default_136 = None
        bmm_default_30 = torch.ops.aten.bmm.default(transpose_int_203, view_default_397);  transpose_int_203 = None
        transpose_int_204 = torch.ops.aten.transpose.int(_unsafe_view_default_137, 1, 2);  _unsafe_view_default_137 = None
        bmm_default_31 = torch.ops.aten.bmm.default(view_default_397, transpose_int_204);  view_default_397 = transpose_int_204 = None
        view_default_398 = torch.ops.aten.view.default(bmm_default_30, [24, 3, 64, 512, 1]);  bmm_default_30 = None
        permute_default_160 = torch.ops.aten.permute.default(view_default_398, [0, 1, 4, 3, 2]);  view_default_398 = None
        view_default_399 = torch.ops.aten.view.default(bmm_default_31, [24, 3, 512, 64, 1]);  bmm_default_31 = None
        permute_default_161 = torch.ops.aten.permute.default(view_default_399, [0, 1, 2, 4, 3]);  view_default_399 = None
        permute_default_162 = torch.ops.aten.permute.default(permute_default_160, [0, 1, 3, 4, 2]);  permute_default_160 = None
        squeeze_dim_30 = torch.ops.aten.squeeze.dim(permute_default_162, -1);  permute_default_162 = None
        permute_default_163 = torch.ops.aten.permute.default(permute_default_161, [0, 1, 2, 4, 3]);  permute_default_161 = None
        squeeze_dim_31 = torch.ops.aten.squeeze.dim(permute_default_163, -1);  permute_default_163 = None
        new_empty_default_66 = torch.ops.aten.new_empty.default(squeeze_dim_30, [1572864])
        zero__default_12 = torch.ops.aten.zero_.default(new_empty_default_66);  new_empty_default_66 = None
        arange_4 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_86 = torch.ops.aten.as_strided.default(arange_4, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_4 = None
        clone_default_131 = torch.ops.aten.clone.default(as_strided_default_86, memory_format = torch.contiguous_format);  as_strided_default_86 = None
        _unsafe_view_default_165 = torch.ops.aten._unsafe_view.default(clone_default_131, [2359296]);  clone_default_131 = None
        clone_default_132 = torch.ops.aten.clone.default(squeeze_dim_30, memory_format = torch.contiguous_format);  squeeze_dim_30 = None
        _unsafe_view_default_166 = torch.ops.aten._unsafe_view.default(clone_default_132, [2359296]);  clone_default_132 = None
        index_add__default_4 = torch.ops.aten.index_add_.default(zero__default_12, 0, _unsafe_view_default_165, _unsafe_view_default_166);  zero__default_12 = _unsafe_view_default_165 = _unsafe_view_default_166 = None
        as_strided_default_87 = torch.ops.aten.as_strided.default(index_add__default_4, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_4 = None
        view_default_400 = torch.ops.aten.view.default(as_strided_default_87, [24, 1024, 64]);  as_strided_default_87 = None
        new_empty_default_67 = torch.ops.aten.new_empty.default(squeeze_dim_31, [1572864])
        zero__default_13 = torch.ops.aten.zero_.default(new_empty_default_67);  new_empty_default_67 = None
        arange_5 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_88 = torch.ops.aten.as_strided.default(arange_5, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_5 = None
        clone_default_133 = torch.ops.aten.clone.default(as_strided_default_88, memory_format = torch.contiguous_format);  as_strided_default_88 = None
        _unsafe_view_default_167 = torch.ops.aten._unsafe_view.default(clone_default_133, [2359296]);  clone_default_133 = None
        view_default_401 = torch.ops.aten.view.default(squeeze_dim_31, [2359296]);  squeeze_dim_31 = None
        index_add__default_5 = torch.ops.aten.index_add_.default(zero__default_13, 0, _unsafe_view_default_167, view_default_401);  zero__default_13 = _unsafe_view_default_167 = view_default_401 = None
        as_strided_default_89 = torch.ops.aten.as_strided.default(index_add__default_5, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_5 = None
        view_default_402 = torch.ops.aten.view.default(as_strided_default_89, [24, 1024, 64]);  as_strided_default_89 = None
        view_default_403 = torch.ops.aten.view.default(view_default_400, [2, 12, 1024, 64]);  view_default_400 = None
        transpose_int_205 = torch.ops.aten.transpose.int(view_default_403, 1, 2);  view_default_403 = None
        view_default_404 = torch.ops.aten.view.default(view_default_402, [2, 12, 1024, 64]);  view_default_402 = None
        transpose_int_206 = torch.ops.aten.transpose.int(view_default_404, 1, 2);  view_default_404 = None
        transpose_int_207 = torch.ops.aten.transpose.int(transpose_int_205, 0, 1);  transpose_int_205 = None
        view_default_405 = torch.ops.aten.view.default(transpose_int_207, [1024, 2, 768]);  transpose_int_207 = None
        transpose_int_208 = torch.ops.aten.transpose.int(transpose_int_206, 0, 1);  transpose_int_206 = None
        view_default_406 = torch.ops.aten.view.default(transpose_int_208, [1024, 2, 768]);  transpose_int_208 = None
        div_tensor_1 = torch.ops.aten.div.Tensor(view_default_406, 8.0);  view_default_406 = None
        sum_dim_int_list_9 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_164, [0, 1], True)
        view_default_407 = torch.ops.aten.view.default(sum_dim_int_list_9, [768]);  sum_dim_int_list_9 = None
        view_default_408 = torch.ops.aten.view.default(_unsafe_view_default_164, [2048, 768]);  _unsafe_view_default_164 = None
        t_default_108 = torch.ops.aten.t.default(view_default_408)
        mm_default_66 = torch.ops.aten.mm.default(t_default_108, _unsafe_view_default_134);  t_default_108 = _unsafe_view_default_134 = None
        t_default_109 = torch.ops.aten.t.default(mm_default_66);  mm_default_66 = None
        t_default_110 = torch.ops.aten.t.default(t_default_62);  t_default_62 = None
        mm_default_67 = torch.ops.aten.mm.default(view_default_408, t_default_110);  view_default_408 = t_default_110 = None
        view_default_409 = torch.ops.aten.view.default(mm_default_67, [1024, 2, 768]);  mm_default_67 = None
        t_default_111 = torch.ops.aten.t.default(t_default_109);  t_default_109 = None
        sum_dim_int_list_10 = torch.ops.aten.sum.dim_IntList(view_default_405, [0, 1], True)
        view_default_410 = torch.ops.aten.view.default(sum_dim_int_list_10, [768]);  sum_dim_int_list_10 = None
        view_default_411 = torch.ops.aten.view.default(view_default_405, [2048, 768]);  view_default_405 = None
        t_default_112 = torch.ops.aten.t.default(view_default_411)
        mm_default_68 = torch.ops.aten.mm.default(t_default_112, _unsafe_view_default_132);  t_default_112 = _unsafe_view_default_132 = None
        t_default_113 = torch.ops.aten.t.default(mm_default_68);  mm_default_68 = None
        t_default_114 = torch.ops.aten.t.default(t_default_61);  t_default_61 = None
        mm_default_69 = torch.ops.aten.mm.default(view_default_411, t_default_114);  view_default_411 = t_default_114 = None
        view_default_412 = torch.ops.aten.view.default(mm_default_69, [1024, 2, 768]);  mm_default_69 = None
        add_tensor_87 = torch.ops.aten.add.Tensor(view_default_409, view_default_412);  view_default_409 = view_default_412 = None
        t_default_115 = torch.ops.aten.t.default(t_default_113);  t_default_113 = None
        sum_dim_int_list_11 = torch.ops.aten.sum.dim_IntList(div_tensor_1, [0, 1], True)
        view_default_413 = torch.ops.aten.view.default(sum_dim_int_list_11, [768]);  sum_dim_int_list_11 = None
        view_default_414 = torch.ops.aten.view.default(div_tensor_1, [2048, 768]);  div_tensor_1 = None
        t_default_116 = torch.ops.aten.t.default(view_default_414)
        mm_default_70 = torch.ops.aten.mm.default(t_default_116, _unsafe_view_default_130);  t_default_116 = _unsafe_view_default_130 = None
        t_default_117 = torch.ops.aten.t.default(mm_default_70);  mm_default_70 = None
        t_default_118 = torch.ops.aten.t.default(t_default_60);  t_default_60 = None
        mm_default_71 = torch.ops.aten.mm.default(view_default_414, t_default_118);  view_default_414 = t_default_118 = None
        view_default_415 = torch.ops.aten.view.default(mm_default_71, [1024, 2, 768]);  mm_default_71 = None
        add_tensor_88 = torch.ops.aten.add.Tensor(add_tensor_87, view_default_415);  add_tensor_87 = view_default_415 = None
        t_default_119 = torch.ops.aten.t.default(t_default_117);  t_default_117 = None
        transpose_int_209 = torch.ops.aten.transpose.int(add_tensor_88, 0, 1);  add_tensor_88 = None
        add_tensor_89 = torch.ops.aten.add.Tensor(getitem_81, transpose_int_209);  getitem_81 = transpose_int_209 = None
        native_layer_norm_backward_default_4 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_89, add_tensor_59, [768], getitem_58, getitem_59, primals_190, primals_189, [True, True, True]);  add_tensor_89 = add_tensor_59 = getitem_58 = getitem_59 = primals_190 = primals_189 = None
        getitem_84 = native_layer_norm_backward_default_4[0]
        getitem_85 = native_layer_norm_backward_default_4[1]
        getitem_86 = native_layer_norm_backward_default_4[2];  native_layer_norm_backward_default_4 = None
        view_default_416 = torch.ops.aten.view.default(getitem_84, [2048, 768])
        t_default_120 = torch.ops.aten.t.default(t_default_59);  t_default_59 = None
        mm_default_72 = torch.ops.aten.mm.default(view_default_416, t_default_120);  t_default_120 = None
        t_default_121 = torch.ops.aten.t.default(view_default_416)
        mm_default_73 = torch.ops.aten.mm.default(t_default_121, view_default_278);  t_default_121 = view_default_278 = None
        t_default_122 = torch.ops.aten.t.default(mm_default_73);  mm_default_73 = None
        sum_dim_int_list_12 = torch.ops.aten.sum.dim_IntList(view_default_416, [0], True);  view_default_416 = None
        view_default_417 = torch.ops.aten.view.default(sum_dim_int_list_12, [768]);  sum_dim_int_list_12 = None
        t_default_123 = torch.ops.aten.t.default(t_default_122);  t_default_122 = None
        view_default_418 = torch.ops.aten.view.default(mm_default_72, [2, 1024, 3072]);  mm_default_72 = None
        to_dtype_6 = torch.ops.aten.to.dtype(view_default_418, torch.float32);  view_default_418 = None
        to_dtype_7 = torch.ops.aten.to.dtype(view_default_277, torch.float32);  view_default_277 = None
        mul_tensor_26 = torch.ops.aten.mul.Tensor(to_dtype_7, 0.7071067811865476)
        erf_default_2 = torch.ops.aten.erf.default(mul_tensor_26);  mul_tensor_26 = None
        add_tensor_90 = torch.ops.aten.add.Tensor(erf_default_2, 1);  erf_default_2 = None
        mul_tensor_27 = torch.ops.aten.mul.Tensor(add_tensor_90, 0.5);  add_tensor_90 = None
        mul_tensor_28 = torch.ops.aten.mul.Tensor(to_dtype_7, to_dtype_7)
        mul_tensor_29 = torch.ops.aten.mul.Tensor(mul_tensor_28, -0.5);  mul_tensor_28 = None
        exp_default_2 = torch.ops.aten.exp.default(mul_tensor_29);  mul_tensor_29 = None
        mul_tensor_30 = torch.ops.aten.mul.Tensor(exp_default_2, 0.3989422804014327);  exp_default_2 = None
        mul_tensor_31 = torch.ops.aten.mul.Tensor(to_dtype_7, mul_tensor_30);  to_dtype_7 = mul_tensor_30 = None
        add_tensor_91 = torch.ops.aten.add.Tensor(mul_tensor_27, mul_tensor_31);  mul_tensor_27 = mul_tensor_31 = None
        mul_tensor_32 = torch.ops.aten.mul.Tensor(to_dtype_6, add_tensor_91);  to_dtype_6 = add_tensor_91 = None
        to_dtype_8 = torch.ops.aten.to.dtype(mul_tensor_32, torch.float32);  mul_tensor_32 = None
        view_default_419 = torch.ops.aten.view.default(to_dtype_8, [2048, 3072]);  to_dtype_8 = None
        t_default_124 = torch.ops.aten.t.default(t_default_58);  t_default_58 = None
        mm_default_74 = torch.ops.aten.mm.default(view_default_419, t_default_124);  t_default_124 = None
        t_default_125 = torch.ops.aten.t.default(view_default_419)
        mm_default_75 = torch.ops.aten.mm.default(t_default_125, view_default_276);  t_default_125 = view_default_276 = None
        t_default_126 = torch.ops.aten.t.default(mm_default_75);  mm_default_75 = None
        sum_dim_int_list_13 = torch.ops.aten.sum.dim_IntList(view_default_419, [0], True);  view_default_419 = None
        view_default_420 = torch.ops.aten.view.default(sum_dim_int_list_13, [3072]);  sum_dim_int_list_13 = None
        t_default_127 = torch.ops.aten.t.default(t_default_126);  t_default_126 = None
        view_default_421 = torch.ops.aten.view.default(mm_default_74, [2, 1024, 768]);  mm_default_74 = None
        add_tensor_92 = torch.ops.aten.add.Tensor(getitem_84, view_default_421);  getitem_84 = view_default_421 = None
        native_layer_norm_backward_default_5 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_92, add_tensor_58, [768], getitem_55, getitem_56, primals_178, primals_177, [True, True, True]);  add_tensor_92 = add_tensor_58 = getitem_55 = getitem_56 = primals_178 = primals_177 = None
        getitem_87 = native_layer_norm_backward_default_5[0]
        getitem_88 = native_layer_norm_backward_default_5[1]
        getitem_89 = native_layer_norm_backward_default_5[2];  native_layer_norm_backward_default_5 = None
        sum_dim_int_list_14 = torch.ops.aten.sum.dim_IntList(getitem_87, [0, 1], True)
        view_default_422 = torch.ops.aten.view.default(sum_dim_int_list_14, [768]);  sum_dim_int_list_14 = None
        view_default_423 = torch.ops.aten.view.default(getitem_87, [2048, 768])
        t_default_128 = torch.ops.aten.t.default(view_default_423)
        mm_default_76 = torch.ops.aten.mm.default(t_default_128, _unsafe_view_default_128);  t_default_128 = _unsafe_view_default_128 = None
        t_default_129 = torch.ops.aten.t.default(mm_default_76);  mm_default_76 = None
        t_default_130 = torch.ops.aten.t.default(t_default_57);  t_default_57 = None
        mm_default_77 = torch.ops.aten.mm.default(view_default_423, t_default_130);  view_default_423 = t_default_130 = None
        view_default_424 = torch.ops.aten.view.default(mm_default_77, [2, 1024, 768]);  mm_default_77 = None
        t_default_131 = torch.ops.aten.t.default(t_default_129);  t_default_129 = None
        transpose_int_210 = torch.ops.aten.transpose.int(view_default_424, 0, 1);  view_default_424 = None
        view_default_425 = torch.ops.aten.view.default(transpose_int_210, [1024, 2, 12, 64]);  transpose_int_210 = None
        transpose_int_211 = torch.ops.aten.transpose.int(view_default_425, 0, 1);  view_default_425 = None
        transpose_int_212 = torch.ops.aten.transpose.int(transpose_int_211, 1, 2);  transpose_int_211 = None
        clone_default_134 = torch.ops.aten.clone.default(transpose_int_212, memory_format = torch.contiguous_format);  transpose_int_212 = None
        _unsafe_view_default_168 = torch.ops.aten._unsafe_view.default(clone_default_134, [24, 4, 256, 64]);  clone_default_134 = None
        view_default_426 = torch.ops.aten.view.default(_unsafe_view_default_168, [24, 4, 256, 64, 1]);  _unsafe_view_default_168 = None
        permute_default_164 = torch.ops.aten.permute.default(view_default_426, [0, 1, 2, 4, 3]);  view_default_426 = None
        view_default_427 = torch.ops.aten.view.default(permute_default_164, [96, 256, 64]);  permute_default_164 = None
        transpose_int_213 = torch.ops.aten.transpose.int(view_default_272, 1, 2);  view_default_272 = None
        bmm_default_32 = torch.ops.aten.bmm.default(transpose_int_213, view_default_427);  transpose_int_213 = None
        transpose_int_214 = torch.ops.aten.transpose.int(_unsafe_view_default_126, 1, 2);  _unsafe_view_default_126 = None
        bmm_default_33 = torch.ops.aten.bmm.default(view_default_427, transpose_int_214);  view_default_427 = transpose_int_214 = None
        view_default_428 = torch.ops.aten.view.default(bmm_default_32, [24, 4, 768, 64, 1]);  bmm_default_32 = None
        permute_default_165 = torch.ops.aten.permute.default(view_default_428, [0, 1, 4, 3, 2]);  view_default_428 = None
        view_default_429 = torch.ops.aten.view.default(bmm_default_33, [24, 4, 256, 768, 1]);  bmm_default_33 = None
        permute_default_166 = torch.ops.aten.permute.default(view_default_429, [0, 1, 2, 4, 3]);  view_default_429 = None
        permute_default_167 = torch.ops.aten.permute.default(permute_default_165, [0, 1, 4, 3, 2]);  permute_default_165 = None
        squeeze_dim_32 = torch.ops.aten.squeeze.dim(permute_default_167, -1);  permute_default_167 = None
        permute_default_168 = torch.ops.aten.permute.default(permute_default_166, [0, 1, 2, 4, 3]);  permute_default_166 = None
        squeeze_dim_33 = torch.ops.aten.squeeze.dim(permute_default_168, -1);  permute_default_168 = None
        slice_backward_default_42 = torch.ops.aten.slice_backward.default(squeeze_dim_33, [24, 4, 256, 769], 3, 0, -1, 1);  squeeze_dim_33 = None
        slice_backward_default_43 = torch.ops.aten.slice_backward.default(slice_backward_default_42, [24, 4, 256, 769], 2, 0, 9223372036854775807, 1);  slice_backward_default_42 = None
        slice_backward_default_44 = torch.ops.aten.slice_backward.default(slice_backward_default_43, [24, 4, 256, 769], 1, 0, 9223372036854775807, 1);  slice_backward_default_43 = None
        slice_backward_default_45 = torch.ops.aten.slice_backward.default(slice_backward_default_44, [24, 4, 256, 769], 0, 0, 9223372036854775807, 1);  slice_backward_default_44 = None
        view_default_430 = torch.ops.aten.view.default(slice_backward_default_45, [24, 4, 196864]);  slice_backward_default_45 = None
        slice_backward_default_46 = torch.ops.aten.slice_backward.default(view_default_430, [24, 4, 197120], 2, 0, -256, 1);  view_default_430 = None
        slice_backward_default_47 = torch.ops.aten.slice_backward.default(slice_backward_default_46, [24, 4, 197120], 1, 0, 9223372036854775807, 1);  slice_backward_default_46 = None
        slice_backward_default_48 = torch.ops.aten.slice_backward.default(slice_backward_default_47, [24, 4, 197120], 0, 0, 9223372036854775807, 1);  slice_backward_default_47 = None
        view_default_431 = torch.ops.aten.view.default(slice_backward_default_48, [24, 4, 256, 770]);  slice_backward_default_48 = None
        constant_pad_nd_default_54 = torch.ops.aten.constant_pad_nd.default(view_default_431, [0, -257]);  view_default_431 = None
        new_empty_default_68 = torch.ops.aten.new_empty.default(squeeze_dim_32, [2359296])
        zero__default_14 = torch.ops.aten.zero_.default(new_empty_default_68);  new_empty_default_68 = None
        arange_6 = torch.ops.aten.arange.start(0, 2359296, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_90 = torch.ops.aten.as_strided.default(arange_6, [24, 4, 768, 64], [98304, 16384, 64, 1], 0);  arange_6 = None
        clone_default_135 = torch.ops.aten.clone.default(as_strided_default_90, memory_format = torch.contiguous_format);  as_strided_default_90 = None
        _unsafe_view_default_169 = torch.ops.aten._unsafe_view.default(clone_default_135, [4718592]);  clone_default_135 = None
        view_default_432 = torch.ops.aten.view.default(squeeze_dim_32, [4718592]);  squeeze_dim_32 = None
        index_add__default_6 = torch.ops.aten.index_add_.default(zero__default_14, 0, _unsafe_view_default_169, view_default_432);  zero__default_14 = _unsafe_view_default_169 = view_default_432 = None
        as_strided_default_91 = torch.ops.aten.as_strided.default(index_add__default_6, [24, 1536, 64], [98304, 64, 1], 0);  index_add__default_6 = None
        constant_pad_nd_default_55 = torch.ops.aten.constant_pad_nd.default(as_strided_default_91, [0, 0, -256, -256]);  as_strided_default_91 = None
        view_default_433 = torch.ops.aten.view.default(constant_pad_nd_default_55, [2, 12, 1024, 64]);  constant_pad_nd_default_55 = None
        transpose_int_215 = torch.ops.aten.transpose.int(view_default_433, 1, 2);  view_default_433 = None
        view_default_434 = torch.ops.aten.view.default(constant_pad_nd_default_54, [2, 12, 1024, 513]);  constant_pad_nd_default_54 = None
        transpose_int_216 = torch.ops.aten.transpose.int(view_default_434, 1, 2);  view_default_434 = None
        transpose_int_217 = torch.ops.aten.transpose.int(transpose_int_215, 0, 1);  transpose_int_215 = None
        clone_default_136 = torch.ops.aten.clone.default(transpose_int_217, memory_format = torch.contiguous_format);  transpose_int_217 = None
        _unsafe_view_default_170 = torch.ops.aten._unsafe_view.default(clone_default_136, [1024, 2, 768]);  clone_default_136 = None
        where_scalar_self_30 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_137, 0.0, transpose_int_216);  unsqueeze_default_137 = transpose_int_216 = None
        _softmax_backward_data_default_2 = torch.ops.aten._softmax_backward_data.default(where_scalar_self_30, _softmax_default_9, -1, torch.float32);  where_scalar_self_30 = _softmax_default_9 = None
        new_empty_default_69 = torch.ops.aten.new_empty.default(_softmax_backward_data_default_2, [12607488]);  _softmax_backward_data_default_2 = None
        zero__default_15 = torch.ops.aten.zero_.default(new_empty_default_69);  new_empty_default_69 = None
        as_strided_default_93 = torch.ops.aten.as_strided.default(zero__default_15, [24, 4, 256, 513], [525312, 131328, 513, 1], 0);  zero__default_15 = None
        new_empty_strided_default_14 = torch.ops.aten.new_empty_strided.default(as_strided_default_93, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_125 = torch.ops.aten.copy_.default(new_empty_strided_default_14, as_strided_default_93);  new_empty_strided_default_14 = as_strided_default_93 = None
        new_empty_strided_default_15 = torch.ops.aten.new_empty_strided.default(copy__default_125, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_127 = torch.ops.aten.copy_.default(new_empty_strided_default_15, copy__default_125);  new_empty_strided_default_15 = copy__default_125 = None
        new_empty_strided_default_16 = torch.ops.aten.new_empty_strided.default(copy__default_127, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_129 = torch.ops.aten.copy_.default(new_empty_strided_default_16, copy__default_127);  new_empty_strided_default_16 = copy__default_127 = None
        new_empty_strided_default_17 = torch.ops.aten.new_empty_strided.default(copy__default_129, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_131 = torch.ops.aten.copy_.default(new_empty_strided_default_17, copy__default_129);  new_empty_strided_default_17 = copy__default_129 = None
        as_strided_default_97 = torch.ops.aten.as_strided.default(copy__default_131, [24, 255, 255], [525312, 513, 1], 514)
        clone_default_140 = torch.ops.aten.clone.default(as_strided_default_97, memory_format = torch.contiguous_format);  as_strided_default_97 = None
        slice_backward_default_49 = torch.ops.aten.slice_backward.default(clone_default_140, [24, 255, 513], 2, -255, 9223372036854775807, 1);  clone_default_140 = None
        slice_backward_default_50 = torch.ops.aten.slice_backward.default(slice_backward_default_49, [24, 512, 513], 1, 0, 255, 1);  slice_backward_default_49 = None
        select_backward_default_4 = torch.ops.aten.select_backward.default(slice_backward_default_50, [24, 3, 512, 513], 1, 0);  slice_backward_default_50 = None
        slice_backward_default_51 = torch.ops.aten.slice_backward.default(select_backward_default_4, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_4 = None
        new_empty_strided_default_18 = torch.ops.aten.new_empty_strided.default(copy__default_131, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_133 = torch.ops.aten.copy_.default(new_empty_strided_default_18, copy__default_131);  new_empty_strided_default_18 = copy__default_131 = None
        as_strided_default_98 = torch.ops.aten.as_strided.default(copy__default_133, [24, 3, 256, 256], [525312, 131328, 513, 1], 131328)
        clone_default_141 = torch.ops.aten.clone.default(as_strided_default_98, memory_format = torch.contiguous_format);  as_strided_default_98 = None
        slice_backward_default_52 = torch.ops.aten.slice_backward.default(clone_default_141, [24, 3, 256, 513], 3, 257, 9223372036854775807, 1);  clone_default_141 = None
        slice_backward_default_53 = torch.ops.aten.slice_backward.default(slice_backward_default_52, [24, 3, 512, 513], 2, -257, -1, 1);  slice_backward_default_52 = None
        slice_backward_default_54 = torch.ops.aten.slice_backward.default(slice_backward_default_53, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_53 = None
        slice_backward_default_55 = torch.ops.aten.slice_backward.default(slice_backward_default_54, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_54 = None
        add_tensor_93 = torch.ops.aten.add.Tensor(slice_backward_default_51, slice_backward_default_55);  slice_backward_default_51 = slice_backward_default_55 = None
        new_empty_strided_default_19 = torch.ops.aten.new_empty_strided.default(copy__default_133, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_135 = torch.ops.aten.copy_.default(new_empty_strided_default_19, copy__default_133);  new_empty_strided_default_19 = copy__default_133 = None
        as_strided_default_99 = torch.ops.aten.as_strided.default(copy__default_135, [24, 256, 257], [525312, 513, 1], 394240)
        clone_default_142 = torch.ops.aten.clone.default(as_strided_default_99, memory_format = torch.contiguous_format);  as_strided_default_99 = None
        slice_backward_default_56 = torch.ops.aten.slice_backward.default(clone_default_142, [24, 256, 513], 2, 0, 257, 1);  clone_default_142 = None
        slice_backward_default_57 = torch.ops.aten.slice_backward.default(slice_backward_default_56, [24, 512, 513], 1, 256, 9223372036854775807, 1);  slice_backward_default_56 = None
        select_backward_default_5 = torch.ops.aten.select_backward.default(slice_backward_default_57, [24, 3, 512, 513], 1, -1);  slice_backward_default_57 = None
        slice_backward_default_58 = torch.ops.aten.slice_backward.default(select_backward_default_5, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_5 = None
        add_tensor_94 = torch.ops.aten.add.Tensor(add_tensor_93, slice_backward_default_58);  add_tensor_93 = slice_backward_default_58 = None
        new_empty_strided_default_20 = torch.ops.aten.new_empty_strided.default(copy__default_135, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_137 = torch.ops.aten.copy_.default(new_empty_strided_default_20, copy__default_135);  new_empty_strided_default_20 = copy__default_135 = None
        as_strided_default_100 = torch.ops.aten.as_strided.default(copy__default_137, [24, 3, 256, 257], [525312, 131328, 513, 1], 256);  copy__default_137 = None
        clone_default_143 = torch.ops.aten.clone.default(as_strided_default_100, memory_format = torch.contiguous_format);  as_strided_default_100 = None
        slice_backward_default_59 = torch.ops.aten.slice_backward.default(clone_default_143, [24, 3, 256, 513], 3, 0, 257, 1);  clone_default_143 = None
        slice_backward_default_60 = torch.ops.aten.slice_backward.default(slice_backward_default_59, [24, 3, 512, 513], 2, 0, 256, 1);  slice_backward_default_59 = None
        slice_backward_default_61 = torch.ops.aten.slice_backward.default(slice_backward_default_60, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_60 = None
        slice_backward_default_62 = torch.ops.aten.slice_backward.default(slice_backward_default_61, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_61 = None
        add_tensor_95 = torch.ops.aten.add.Tensor(add_tensor_94, slice_backward_default_62);  add_tensor_94 = slice_backward_default_62 = None
        view_default_435 = torch.ops.aten.view.default(add_tensor_95, [24, 3, 513, 512]);  add_tensor_95 = None
        constant_pad_nd_default_56 = torch.ops.aten.constant_pad_nd.default(view_default_435, [0, 0, 0, -1]);  view_default_435 = None
        view_default_436 = torch.ops.aten.view.default(constant_pad_nd_default_56, [24, 3, 512, 512, 1]);  constant_pad_nd_default_56 = None
        permute_default_169 = torch.ops.aten.permute.default(view_default_436, [0, 1, 2, 4, 3]);  view_default_436 = None
        view_default_437 = torch.ops.aten.view.default(permute_default_169, [72, 512, 512]);  permute_default_169 = None
        transpose_int_218 = torch.ops.aten.transpose.int(_unsafe_view_default_123, 1, 2);  _unsafe_view_default_123 = None
        bmm_default_34 = torch.ops.aten.bmm.default(transpose_int_218, view_default_437);  transpose_int_218 = None
        transpose_int_219 = torch.ops.aten.transpose.int(_unsafe_view_default_124, 1, 2);  _unsafe_view_default_124 = None
        bmm_default_35 = torch.ops.aten.bmm.default(view_default_437, transpose_int_219);  view_default_437 = transpose_int_219 = None
        view_default_438 = torch.ops.aten.view.default(bmm_default_34, [24, 3, 64, 512, 1]);  bmm_default_34 = None
        permute_default_170 = torch.ops.aten.permute.default(view_default_438, [0, 1, 4, 3, 2]);  view_default_438 = None
        view_default_439 = torch.ops.aten.view.default(bmm_default_35, [24, 3, 512, 64, 1]);  bmm_default_35 = None
        permute_default_171 = torch.ops.aten.permute.default(view_default_439, [0, 1, 2, 4, 3]);  view_default_439 = None
        permute_default_172 = torch.ops.aten.permute.default(permute_default_170, [0, 1, 3, 4, 2]);  permute_default_170 = None
        squeeze_dim_34 = torch.ops.aten.squeeze.dim(permute_default_172, -1);  permute_default_172 = None
        permute_default_173 = torch.ops.aten.permute.default(permute_default_171, [0, 1, 2, 4, 3]);  permute_default_171 = None
        squeeze_dim_35 = torch.ops.aten.squeeze.dim(permute_default_173, -1);  permute_default_173 = None
        new_empty_default_70 = torch.ops.aten.new_empty.default(squeeze_dim_34, [1572864])
        zero__default_19 = torch.ops.aten.zero_.default(new_empty_default_70);  new_empty_default_70 = None
        arange_7 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_101 = torch.ops.aten.as_strided.default(arange_7, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_7 = None
        clone_default_144 = torch.ops.aten.clone.default(as_strided_default_101, memory_format = torch.contiguous_format);  as_strided_default_101 = None
        _unsafe_view_default_171 = torch.ops.aten._unsafe_view.default(clone_default_144, [2359296]);  clone_default_144 = None
        clone_default_145 = torch.ops.aten.clone.default(squeeze_dim_34, memory_format = torch.contiguous_format);  squeeze_dim_34 = None
        _unsafe_view_default_172 = torch.ops.aten._unsafe_view.default(clone_default_145, [2359296]);  clone_default_145 = None
        index_add__default_7 = torch.ops.aten.index_add_.default(zero__default_19, 0, _unsafe_view_default_171, _unsafe_view_default_172);  zero__default_19 = _unsafe_view_default_171 = _unsafe_view_default_172 = None
        as_strided_default_102 = torch.ops.aten.as_strided.default(index_add__default_7, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_7 = None
        view_default_440 = torch.ops.aten.view.default(as_strided_default_102, [24, 1024, 64]);  as_strided_default_102 = None
        new_empty_default_71 = torch.ops.aten.new_empty.default(squeeze_dim_35, [1572864])
        zero__default_20 = torch.ops.aten.zero_.default(new_empty_default_71);  new_empty_default_71 = None
        arange_8 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_103 = torch.ops.aten.as_strided.default(arange_8, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_8 = None
        clone_default_146 = torch.ops.aten.clone.default(as_strided_default_103, memory_format = torch.contiguous_format);  as_strided_default_103 = None
        _unsafe_view_default_173 = torch.ops.aten._unsafe_view.default(clone_default_146, [2359296]);  clone_default_146 = None
        view_default_441 = torch.ops.aten.view.default(squeeze_dim_35, [2359296]);  squeeze_dim_35 = None
        index_add__default_8 = torch.ops.aten.index_add_.default(zero__default_20, 0, _unsafe_view_default_173, view_default_441);  zero__default_20 = _unsafe_view_default_173 = view_default_441 = None
        as_strided_default_104 = torch.ops.aten.as_strided.default(index_add__default_8, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_8 = None
        view_default_442 = torch.ops.aten.view.default(as_strided_default_104, [24, 1024, 64]);  as_strided_default_104 = None
        view_default_443 = torch.ops.aten.view.default(view_default_440, [2, 12, 1024, 64]);  view_default_440 = None
        transpose_int_220 = torch.ops.aten.transpose.int(view_default_443, 1, 2);  view_default_443 = None
        view_default_444 = torch.ops.aten.view.default(view_default_442, [2, 12, 1024, 64]);  view_default_442 = None
        transpose_int_221 = torch.ops.aten.transpose.int(view_default_444, 1, 2);  view_default_444 = None
        transpose_int_222 = torch.ops.aten.transpose.int(transpose_int_220, 0, 1);  transpose_int_220 = None
        view_default_445 = torch.ops.aten.view.default(transpose_int_222, [1024, 2, 768]);  transpose_int_222 = None
        transpose_int_223 = torch.ops.aten.transpose.int(transpose_int_221, 0, 1);  transpose_int_221 = None
        view_default_446 = torch.ops.aten.view.default(transpose_int_223, [1024, 2, 768]);  transpose_int_223 = None
        div_tensor_2 = torch.ops.aten.div.Tensor(view_default_446, 8.0);  view_default_446 = None
        sum_dim_int_list_15 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_170, [0, 1], True)
        view_default_447 = torch.ops.aten.view.default(sum_dim_int_list_15, [768]);  sum_dim_int_list_15 = None
        view_default_448 = torch.ops.aten.view.default(_unsafe_view_default_170, [2048, 768]);  _unsafe_view_default_170 = None
        t_default_132 = torch.ops.aten.t.default(view_default_448)
        mm_default_78 = torch.ops.aten.mm.default(t_default_132, _unsafe_view_default_121);  t_default_132 = _unsafe_view_default_121 = None
        t_default_133 = torch.ops.aten.t.default(mm_default_78);  mm_default_78 = None
        t_default_134 = torch.ops.aten.t.default(t_default_56);  t_default_56 = None
        mm_default_79 = torch.ops.aten.mm.default(view_default_448, t_default_134);  view_default_448 = t_default_134 = None
        view_default_449 = torch.ops.aten.view.default(mm_default_79, [1024, 2, 768]);  mm_default_79 = None
        t_default_135 = torch.ops.aten.t.default(t_default_133);  t_default_133 = None
        sum_dim_int_list_16 = torch.ops.aten.sum.dim_IntList(view_default_445, [0, 1], True)
        view_default_450 = torch.ops.aten.view.default(sum_dim_int_list_16, [768]);  sum_dim_int_list_16 = None
        view_default_451 = torch.ops.aten.view.default(view_default_445, [2048, 768]);  view_default_445 = None
        t_default_136 = torch.ops.aten.t.default(view_default_451)
        mm_default_80 = torch.ops.aten.mm.default(t_default_136, _unsafe_view_default_119);  t_default_136 = _unsafe_view_default_119 = None
        t_default_137 = torch.ops.aten.t.default(mm_default_80);  mm_default_80 = None
        t_default_138 = torch.ops.aten.t.default(t_default_55);  t_default_55 = None
        mm_default_81 = torch.ops.aten.mm.default(view_default_451, t_default_138);  view_default_451 = t_default_138 = None
        view_default_452 = torch.ops.aten.view.default(mm_default_81, [1024, 2, 768]);  mm_default_81 = None
        add_tensor_96 = torch.ops.aten.add.Tensor(view_default_449, view_default_452);  view_default_449 = view_default_452 = None
        t_default_139 = torch.ops.aten.t.default(t_default_137);  t_default_137 = None
        sum_dim_int_list_17 = torch.ops.aten.sum.dim_IntList(div_tensor_2, [0, 1], True)
        view_default_453 = torch.ops.aten.view.default(sum_dim_int_list_17, [768]);  sum_dim_int_list_17 = None
        view_default_454 = torch.ops.aten.view.default(div_tensor_2, [2048, 768]);  div_tensor_2 = None
        t_default_140 = torch.ops.aten.t.default(view_default_454)
        mm_default_82 = torch.ops.aten.mm.default(t_default_140, _unsafe_view_default_117);  t_default_140 = _unsafe_view_default_117 = None
        t_default_141 = torch.ops.aten.t.default(mm_default_82);  mm_default_82 = None
        t_default_142 = torch.ops.aten.t.default(t_default_54);  t_default_54 = None
        mm_default_83 = torch.ops.aten.mm.default(view_default_454, t_default_142);  view_default_454 = t_default_142 = None
        view_default_455 = torch.ops.aten.view.default(mm_default_83, [1024, 2, 768]);  mm_default_83 = None
        add_tensor_97 = torch.ops.aten.add.Tensor(add_tensor_96, view_default_455);  add_tensor_96 = view_default_455 = None
        t_default_143 = torch.ops.aten.t.default(t_default_141);  t_default_141 = None
        transpose_int_224 = torch.ops.aten.transpose.int(add_tensor_97, 0, 1);  add_tensor_97 = None
        add_tensor_98 = torch.ops.aten.add.Tensor(getitem_87, transpose_int_224);  getitem_87 = transpose_int_224 = None
        native_layer_norm_backward_default_6 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_98, add_tensor_53, [768], getitem_52, getitem_53, primals_174, primals_173, [True, True, True]);  add_tensor_98 = add_tensor_53 = getitem_52 = getitem_53 = primals_174 = primals_173 = None
        getitem_90 = native_layer_norm_backward_default_6[0]
        getitem_91 = native_layer_norm_backward_default_6[1]
        getitem_92 = native_layer_norm_backward_default_6[2];  native_layer_norm_backward_default_6 = None
        view_default_456 = torch.ops.aten.view.default(getitem_90, [2048, 768])
        t_default_144 = torch.ops.aten.t.default(t_default_53);  t_default_53 = None
        mm_default_84 = torch.ops.aten.mm.default(view_default_456, t_default_144);  t_default_144 = None
        t_default_145 = torch.ops.aten.t.default(view_default_456)
        mm_default_85 = torch.ops.aten.mm.default(t_default_145, view_default_250);  t_default_145 = view_default_250 = None
        t_default_146 = torch.ops.aten.t.default(mm_default_85);  mm_default_85 = None
        sum_dim_int_list_18 = torch.ops.aten.sum.dim_IntList(view_default_456, [0], True);  view_default_456 = None
        view_default_457 = torch.ops.aten.view.default(sum_dim_int_list_18, [768]);  sum_dim_int_list_18 = None
        t_default_147 = torch.ops.aten.t.default(t_default_146);  t_default_146 = None
        view_default_458 = torch.ops.aten.view.default(mm_default_84, [2, 1024, 3072]);  mm_default_84 = None
        to_dtype_9 = torch.ops.aten.to.dtype(view_default_458, torch.float32);  view_default_458 = None
        to_dtype_10 = torch.ops.aten.to.dtype(view_default_249, torch.float32);  view_default_249 = None
        mul_tensor_33 = torch.ops.aten.mul.Tensor(to_dtype_10, 0.7071067811865476)
        erf_default_3 = torch.ops.aten.erf.default(mul_tensor_33);  mul_tensor_33 = None
        add_tensor_99 = torch.ops.aten.add.Tensor(erf_default_3, 1);  erf_default_3 = None
        mul_tensor_34 = torch.ops.aten.mul.Tensor(add_tensor_99, 0.5);  add_tensor_99 = None
        mul_tensor_35 = torch.ops.aten.mul.Tensor(to_dtype_10, to_dtype_10)
        mul_tensor_36 = torch.ops.aten.mul.Tensor(mul_tensor_35, -0.5);  mul_tensor_35 = None
        exp_default_3 = torch.ops.aten.exp.default(mul_tensor_36);  mul_tensor_36 = None
        mul_tensor_37 = torch.ops.aten.mul.Tensor(exp_default_3, 0.3989422804014327);  exp_default_3 = None
        mul_tensor_38 = torch.ops.aten.mul.Tensor(to_dtype_10, mul_tensor_37);  to_dtype_10 = mul_tensor_37 = None
        add_tensor_100 = torch.ops.aten.add.Tensor(mul_tensor_34, mul_tensor_38);  mul_tensor_34 = mul_tensor_38 = None
        mul_tensor_39 = torch.ops.aten.mul.Tensor(to_dtype_9, add_tensor_100);  to_dtype_9 = add_tensor_100 = None
        to_dtype_11 = torch.ops.aten.to.dtype(mul_tensor_39, torch.float32);  mul_tensor_39 = None
        view_default_459 = torch.ops.aten.view.default(to_dtype_11, [2048, 3072]);  to_dtype_11 = None
        t_default_148 = torch.ops.aten.t.default(t_default_52);  t_default_52 = None
        mm_default_86 = torch.ops.aten.mm.default(view_default_459, t_default_148);  t_default_148 = None
        t_default_149 = torch.ops.aten.t.default(view_default_459)
        mm_default_87 = torch.ops.aten.mm.default(t_default_149, view_default_248);  t_default_149 = view_default_248 = None
        t_default_150 = torch.ops.aten.t.default(mm_default_87);  mm_default_87 = None
        sum_dim_int_list_19 = torch.ops.aten.sum.dim_IntList(view_default_459, [0], True);  view_default_459 = None
        view_default_460 = torch.ops.aten.view.default(sum_dim_int_list_19, [3072]);  sum_dim_int_list_19 = None
        t_default_151 = torch.ops.aten.t.default(t_default_150);  t_default_150 = None
        view_default_461 = torch.ops.aten.view.default(mm_default_86, [2, 1024, 768]);  mm_default_86 = None
        add_tensor_101 = torch.ops.aten.add.Tensor(getitem_90, view_default_461);  getitem_90 = view_default_461 = None
        native_layer_norm_backward_default_7 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_101, add_tensor_52, [768], getitem_49, getitem_50, primals_162, primals_161, [True, True, True]);  add_tensor_101 = add_tensor_52 = getitem_49 = getitem_50 = primals_162 = primals_161 = None
        getitem_93 = native_layer_norm_backward_default_7[0]
        getitem_94 = native_layer_norm_backward_default_7[1]
        getitem_95 = native_layer_norm_backward_default_7[2];  native_layer_norm_backward_default_7 = None
        sum_dim_int_list_20 = torch.ops.aten.sum.dim_IntList(getitem_93, [0, 1], True)
        view_default_462 = torch.ops.aten.view.default(sum_dim_int_list_20, [768]);  sum_dim_int_list_20 = None
        view_default_463 = torch.ops.aten.view.default(getitem_93, [2048, 768])
        t_default_152 = torch.ops.aten.t.default(view_default_463)
        mm_default_88 = torch.ops.aten.mm.default(t_default_152, _unsafe_view_default_115);  t_default_152 = _unsafe_view_default_115 = None
        t_default_153 = torch.ops.aten.t.default(mm_default_88);  mm_default_88 = None
        t_default_154 = torch.ops.aten.t.default(t_default_51);  t_default_51 = None
        mm_default_89 = torch.ops.aten.mm.default(view_default_463, t_default_154);  view_default_463 = t_default_154 = None
        view_default_464 = torch.ops.aten.view.default(mm_default_89, [2, 1024, 768]);  mm_default_89 = None
        t_default_155 = torch.ops.aten.t.default(t_default_153);  t_default_153 = None
        transpose_int_225 = torch.ops.aten.transpose.int(view_default_464, 0, 1);  view_default_464 = None
        view_default_465 = torch.ops.aten.view.default(transpose_int_225, [1024, 2, 12, 64]);  transpose_int_225 = None
        transpose_int_226 = torch.ops.aten.transpose.int(view_default_465, 0, 1);  view_default_465 = None
        transpose_int_227 = torch.ops.aten.transpose.int(transpose_int_226, 1, 2);  transpose_int_226 = None
        clone_default_147 = torch.ops.aten.clone.default(transpose_int_227, memory_format = torch.contiguous_format);  transpose_int_227 = None
        _unsafe_view_default_174 = torch.ops.aten._unsafe_view.default(clone_default_147, [24, 4, 256, 64]);  clone_default_147 = None
        view_default_466 = torch.ops.aten.view.default(_unsafe_view_default_174, [24, 4, 256, 64, 1]);  _unsafe_view_default_174 = None
        permute_default_174 = torch.ops.aten.permute.default(view_default_466, [0, 1, 2, 4, 3]);  view_default_466 = None
        view_default_467 = torch.ops.aten.view.default(permute_default_174, [96, 256, 64]);  permute_default_174 = None
        transpose_int_228 = torch.ops.aten.transpose.int(view_default_244, 1, 2);  view_default_244 = None
        bmm_default_36 = torch.ops.aten.bmm.default(transpose_int_228, view_default_467);  transpose_int_228 = None
        transpose_int_229 = torch.ops.aten.transpose.int(_unsafe_view_default_113, 1, 2);  _unsafe_view_default_113 = None
        bmm_default_37 = torch.ops.aten.bmm.default(view_default_467, transpose_int_229);  view_default_467 = transpose_int_229 = None
        view_default_468 = torch.ops.aten.view.default(bmm_default_36, [24, 4, 768, 64, 1]);  bmm_default_36 = None
        permute_default_175 = torch.ops.aten.permute.default(view_default_468, [0, 1, 4, 3, 2]);  view_default_468 = None
        view_default_469 = torch.ops.aten.view.default(bmm_default_37, [24, 4, 256, 768, 1]);  bmm_default_37 = None
        permute_default_176 = torch.ops.aten.permute.default(view_default_469, [0, 1, 2, 4, 3]);  view_default_469 = None
        permute_default_177 = torch.ops.aten.permute.default(permute_default_175, [0, 1, 4, 3, 2]);  permute_default_175 = None
        squeeze_dim_36 = torch.ops.aten.squeeze.dim(permute_default_177, -1);  permute_default_177 = None
        permute_default_178 = torch.ops.aten.permute.default(permute_default_176, [0, 1, 2, 4, 3]);  permute_default_176 = None
        squeeze_dim_37 = torch.ops.aten.squeeze.dim(permute_default_178, -1);  permute_default_178 = None
        slice_backward_default_63 = torch.ops.aten.slice_backward.default(squeeze_dim_37, [24, 4, 256, 769], 3, 0, -1, 1);  squeeze_dim_37 = None
        slice_backward_default_64 = torch.ops.aten.slice_backward.default(slice_backward_default_63, [24, 4, 256, 769], 2, 0, 9223372036854775807, 1);  slice_backward_default_63 = None
        slice_backward_default_65 = torch.ops.aten.slice_backward.default(slice_backward_default_64, [24, 4, 256, 769], 1, 0, 9223372036854775807, 1);  slice_backward_default_64 = None
        slice_backward_default_66 = torch.ops.aten.slice_backward.default(slice_backward_default_65, [24, 4, 256, 769], 0, 0, 9223372036854775807, 1);  slice_backward_default_65 = None
        view_default_470 = torch.ops.aten.view.default(slice_backward_default_66, [24, 4, 196864]);  slice_backward_default_66 = None
        slice_backward_default_67 = torch.ops.aten.slice_backward.default(view_default_470, [24, 4, 197120], 2, 0, -256, 1);  view_default_470 = None
        slice_backward_default_68 = torch.ops.aten.slice_backward.default(slice_backward_default_67, [24, 4, 197120], 1, 0, 9223372036854775807, 1);  slice_backward_default_67 = None
        slice_backward_default_69 = torch.ops.aten.slice_backward.default(slice_backward_default_68, [24, 4, 197120], 0, 0, 9223372036854775807, 1);  slice_backward_default_68 = None
        view_default_471 = torch.ops.aten.view.default(slice_backward_default_69, [24, 4, 256, 770]);  slice_backward_default_69 = None
        constant_pad_nd_default_57 = torch.ops.aten.constant_pad_nd.default(view_default_471, [0, -257]);  view_default_471 = None
        new_empty_default_72 = torch.ops.aten.new_empty.default(squeeze_dim_36, [2359296])
        zero__default_21 = torch.ops.aten.zero_.default(new_empty_default_72);  new_empty_default_72 = None
        arange_9 = torch.ops.aten.arange.start(0, 2359296, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_105 = torch.ops.aten.as_strided.default(arange_9, [24, 4, 768, 64], [98304, 16384, 64, 1], 0);  arange_9 = None
        clone_default_148 = torch.ops.aten.clone.default(as_strided_default_105, memory_format = torch.contiguous_format);  as_strided_default_105 = None
        _unsafe_view_default_175 = torch.ops.aten._unsafe_view.default(clone_default_148, [4718592]);  clone_default_148 = None
        view_default_472 = torch.ops.aten.view.default(squeeze_dim_36, [4718592]);  squeeze_dim_36 = None
        index_add__default_9 = torch.ops.aten.index_add_.default(zero__default_21, 0, _unsafe_view_default_175, view_default_472);  zero__default_21 = _unsafe_view_default_175 = view_default_472 = None
        as_strided_default_106 = torch.ops.aten.as_strided.default(index_add__default_9, [24, 1536, 64], [98304, 64, 1], 0);  index_add__default_9 = None
        constant_pad_nd_default_58 = torch.ops.aten.constant_pad_nd.default(as_strided_default_106, [0, 0, -256, -256]);  as_strided_default_106 = None
        view_default_473 = torch.ops.aten.view.default(constant_pad_nd_default_58, [2, 12, 1024, 64]);  constant_pad_nd_default_58 = None
        transpose_int_230 = torch.ops.aten.transpose.int(view_default_473, 1, 2);  view_default_473 = None
        view_default_474 = torch.ops.aten.view.default(constant_pad_nd_default_57, [2, 12, 1024, 513]);  constant_pad_nd_default_57 = None
        transpose_int_231 = torch.ops.aten.transpose.int(view_default_474, 1, 2);  view_default_474 = None
        transpose_int_232 = torch.ops.aten.transpose.int(transpose_int_230, 0, 1);  transpose_int_230 = None
        clone_default_149 = torch.ops.aten.clone.default(transpose_int_232, memory_format = torch.contiguous_format);  transpose_int_232 = None
        _unsafe_view_default_176 = torch.ops.aten._unsafe_view.default(clone_default_149, [1024, 2, 768]);  clone_default_149 = None
        where_scalar_self_33 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_123, 0.0, transpose_int_231);  unsqueeze_default_123 = transpose_int_231 = None
        _softmax_backward_data_default_3 = torch.ops.aten._softmax_backward_data.default(where_scalar_self_33, _softmax_default_8, -1, torch.float32);  where_scalar_self_33 = _softmax_default_8 = None
        new_empty_default_73 = torch.ops.aten.new_empty.default(_softmax_backward_data_default_3, [12607488]);  _softmax_backward_data_default_3 = None
        zero__default_22 = torch.ops.aten.zero_.default(new_empty_default_73);  new_empty_default_73 = None
        as_strided_default_108 = torch.ops.aten.as_strided.default(zero__default_22, [24, 4, 256, 513], [525312, 131328, 513, 1], 0);  zero__default_22 = None
        new_empty_strided_default_21 = torch.ops.aten.new_empty_strided.default(as_strided_default_108, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_139 = torch.ops.aten.copy_.default(new_empty_strided_default_21, as_strided_default_108);  new_empty_strided_default_21 = as_strided_default_108 = None
        new_empty_strided_default_22 = torch.ops.aten.new_empty_strided.default(copy__default_139, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_141 = torch.ops.aten.copy_.default(new_empty_strided_default_22, copy__default_139);  new_empty_strided_default_22 = copy__default_139 = None
        new_empty_strided_default_23 = torch.ops.aten.new_empty_strided.default(copy__default_141, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_143 = torch.ops.aten.copy_.default(new_empty_strided_default_23, copy__default_141);  new_empty_strided_default_23 = copy__default_141 = None
        new_empty_strided_default_24 = torch.ops.aten.new_empty_strided.default(copy__default_143, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_145 = torch.ops.aten.copy_.default(new_empty_strided_default_24, copy__default_143);  new_empty_strided_default_24 = copy__default_143 = None
        as_strided_default_112 = torch.ops.aten.as_strided.default(copy__default_145, [24, 255, 255], [525312, 513, 1], 514)
        clone_default_153 = torch.ops.aten.clone.default(as_strided_default_112, memory_format = torch.contiguous_format);  as_strided_default_112 = None
        slice_backward_default_70 = torch.ops.aten.slice_backward.default(clone_default_153, [24, 255, 513], 2, -255, 9223372036854775807, 1);  clone_default_153 = None
        slice_backward_default_71 = torch.ops.aten.slice_backward.default(slice_backward_default_70, [24, 512, 513], 1, 0, 255, 1);  slice_backward_default_70 = None
        select_backward_default_6 = torch.ops.aten.select_backward.default(slice_backward_default_71, [24, 3, 512, 513], 1, 0);  slice_backward_default_71 = None
        slice_backward_default_72 = torch.ops.aten.slice_backward.default(select_backward_default_6, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_6 = None
        new_empty_strided_default_25 = torch.ops.aten.new_empty_strided.default(copy__default_145, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_147 = torch.ops.aten.copy_.default(new_empty_strided_default_25, copy__default_145);  new_empty_strided_default_25 = copy__default_145 = None
        as_strided_default_113 = torch.ops.aten.as_strided.default(copy__default_147, [24, 3, 256, 256], [525312, 131328, 513, 1], 131328)
        clone_default_154 = torch.ops.aten.clone.default(as_strided_default_113, memory_format = torch.contiguous_format);  as_strided_default_113 = None
        slice_backward_default_73 = torch.ops.aten.slice_backward.default(clone_default_154, [24, 3, 256, 513], 3, 257, 9223372036854775807, 1);  clone_default_154 = None
        slice_backward_default_74 = torch.ops.aten.slice_backward.default(slice_backward_default_73, [24, 3, 512, 513], 2, -257, -1, 1);  slice_backward_default_73 = None
        slice_backward_default_75 = torch.ops.aten.slice_backward.default(slice_backward_default_74, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_74 = None
        slice_backward_default_76 = torch.ops.aten.slice_backward.default(slice_backward_default_75, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_75 = None
        add_tensor_102 = torch.ops.aten.add.Tensor(slice_backward_default_72, slice_backward_default_76);  slice_backward_default_72 = slice_backward_default_76 = None
        new_empty_strided_default_26 = torch.ops.aten.new_empty_strided.default(copy__default_147, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_149 = torch.ops.aten.copy_.default(new_empty_strided_default_26, copy__default_147);  new_empty_strided_default_26 = copy__default_147 = None
        as_strided_default_114 = torch.ops.aten.as_strided.default(copy__default_149, [24, 256, 257], [525312, 513, 1], 394240)
        clone_default_155 = torch.ops.aten.clone.default(as_strided_default_114, memory_format = torch.contiguous_format);  as_strided_default_114 = None
        slice_backward_default_77 = torch.ops.aten.slice_backward.default(clone_default_155, [24, 256, 513], 2, 0, 257, 1);  clone_default_155 = None
        slice_backward_default_78 = torch.ops.aten.slice_backward.default(slice_backward_default_77, [24, 512, 513], 1, 256, 9223372036854775807, 1);  slice_backward_default_77 = None
        select_backward_default_7 = torch.ops.aten.select_backward.default(slice_backward_default_78, [24, 3, 512, 513], 1, -1);  slice_backward_default_78 = None
        slice_backward_default_79 = torch.ops.aten.slice_backward.default(select_backward_default_7, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_7 = None
        add_tensor_103 = torch.ops.aten.add.Tensor(add_tensor_102, slice_backward_default_79);  add_tensor_102 = slice_backward_default_79 = None
        new_empty_strided_default_27 = torch.ops.aten.new_empty_strided.default(copy__default_149, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_151 = torch.ops.aten.copy_.default(new_empty_strided_default_27, copy__default_149);  new_empty_strided_default_27 = copy__default_149 = None
        as_strided_default_115 = torch.ops.aten.as_strided.default(copy__default_151, [24, 3, 256, 257], [525312, 131328, 513, 1], 256);  copy__default_151 = None
        clone_default_156 = torch.ops.aten.clone.default(as_strided_default_115, memory_format = torch.contiguous_format);  as_strided_default_115 = None
        slice_backward_default_80 = torch.ops.aten.slice_backward.default(clone_default_156, [24, 3, 256, 513], 3, 0, 257, 1);  clone_default_156 = None
        slice_backward_default_81 = torch.ops.aten.slice_backward.default(slice_backward_default_80, [24, 3, 512, 513], 2, 0, 256, 1);  slice_backward_default_80 = None
        slice_backward_default_82 = torch.ops.aten.slice_backward.default(slice_backward_default_81, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_81 = None
        slice_backward_default_83 = torch.ops.aten.slice_backward.default(slice_backward_default_82, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_82 = None
        add_tensor_104 = torch.ops.aten.add.Tensor(add_tensor_103, slice_backward_default_83);  add_tensor_103 = slice_backward_default_83 = None
        view_default_475 = torch.ops.aten.view.default(add_tensor_104, [24, 3, 513, 512]);  add_tensor_104 = None
        constant_pad_nd_default_59 = torch.ops.aten.constant_pad_nd.default(view_default_475, [0, 0, 0, -1]);  view_default_475 = None
        view_default_476 = torch.ops.aten.view.default(constant_pad_nd_default_59, [24, 3, 512, 512, 1]);  constant_pad_nd_default_59 = None
        permute_default_179 = torch.ops.aten.permute.default(view_default_476, [0, 1, 2, 4, 3]);  view_default_476 = None
        view_default_477 = torch.ops.aten.view.default(permute_default_179, [72, 512, 512]);  permute_default_179 = None
        transpose_int_233 = torch.ops.aten.transpose.int(_unsafe_view_default_110, 1, 2);  _unsafe_view_default_110 = None
        bmm_default_38 = torch.ops.aten.bmm.default(transpose_int_233, view_default_477);  transpose_int_233 = None
        transpose_int_234 = torch.ops.aten.transpose.int(_unsafe_view_default_111, 1, 2);  _unsafe_view_default_111 = None
        bmm_default_39 = torch.ops.aten.bmm.default(view_default_477, transpose_int_234);  view_default_477 = transpose_int_234 = None
        view_default_478 = torch.ops.aten.view.default(bmm_default_38, [24, 3, 64, 512, 1]);  bmm_default_38 = None
        permute_default_180 = torch.ops.aten.permute.default(view_default_478, [0, 1, 4, 3, 2]);  view_default_478 = None
        view_default_479 = torch.ops.aten.view.default(bmm_default_39, [24, 3, 512, 64, 1]);  bmm_default_39 = None
        permute_default_181 = torch.ops.aten.permute.default(view_default_479, [0, 1, 2, 4, 3]);  view_default_479 = None
        permute_default_182 = torch.ops.aten.permute.default(permute_default_180, [0, 1, 3, 4, 2]);  permute_default_180 = None
        squeeze_dim_38 = torch.ops.aten.squeeze.dim(permute_default_182, -1);  permute_default_182 = None
        permute_default_183 = torch.ops.aten.permute.default(permute_default_181, [0, 1, 2, 4, 3]);  permute_default_181 = None
        squeeze_dim_39 = torch.ops.aten.squeeze.dim(permute_default_183, -1);  permute_default_183 = None
        new_empty_default_74 = torch.ops.aten.new_empty.default(squeeze_dim_38, [1572864])
        zero__default_26 = torch.ops.aten.zero_.default(new_empty_default_74);  new_empty_default_74 = None
        arange_10 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_116 = torch.ops.aten.as_strided.default(arange_10, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_10 = None
        clone_default_157 = torch.ops.aten.clone.default(as_strided_default_116, memory_format = torch.contiguous_format);  as_strided_default_116 = None
        _unsafe_view_default_177 = torch.ops.aten._unsafe_view.default(clone_default_157, [2359296]);  clone_default_157 = None
        clone_default_158 = torch.ops.aten.clone.default(squeeze_dim_38, memory_format = torch.contiguous_format);  squeeze_dim_38 = None
        _unsafe_view_default_178 = torch.ops.aten._unsafe_view.default(clone_default_158, [2359296]);  clone_default_158 = None
        index_add__default_10 = torch.ops.aten.index_add_.default(zero__default_26, 0, _unsafe_view_default_177, _unsafe_view_default_178);  zero__default_26 = _unsafe_view_default_177 = _unsafe_view_default_178 = None
        as_strided_default_117 = torch.ops.aten.as_strided.default(index_add__default_10, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_10 = None
        view_default_480 = torch.ops.aten.view.default(as_strided_default_117, [24, 1024, 64]);  as_strided_default_117 = None
        new_empty_default_75 = torch.ops.aten.new_empty.default(squeeze_dim_39, [1572864])
        zero__default_27 = torch.ops.aten.zero_.default(new_empty_default_75);  new_empty_default_75 = None
        arange_11 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_118 = torch.ops.aten.as_strided.default(arange_11, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_11 = None
        clone_default_159 = torch.ops.aten.clone.default(as_strided_default_118, memory_format = torch.contiguous_format);  as_strided_default_118 = None
        _unsafe_view_default_179 = torch.ops.aten._unsafe_view.default(clone_default_159, [2359296]);  clone_default_159 = None
        view_default_481 = torch.ops.aten.view.default(squeeze_dim_39, [2359296]);  squeeze_dim_39 = None
        index_add__default_11 = torch.ops.aten.index_add_.default(zero__default_27, 0, _unsafe_view_default_179, view_default_481);  zero__default_27 = _unsafe_view_default_179 = view_default_481 = None
        as_strided_default_119 = torch.ops.aten.as_strided.default(index_add__default_11, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_11 = None
        view_default_482 = torch.ops.aten.view.default(as_strided_default_119, [24, 1024, 64]);  as_strided_default_119 = None
        view_default_483 = torch.ops.aten.view.default(view_default_480, [2, 12, 1024, 64]);  view_default_480 = None
        transpose_int_235 = torch.ops.aten.transpose.int(view_default_483, 1, 2);  view_default_483 = None
        view_default_484 = torch.ops.aten.view.default(view_default_482, [2, 12, 1024, 64]);  view_default_482 = None
        transpose_int_236 = torch.ops.aten.transpose.int(view_default_484, 1, 2);  view_default_484 = None
        transpose_int_237 = torch.ops.aten.transpose.int(transpose_int_235, 0, 1);  transpose_int_235 = None
        view_default_485 = torch.ops.aten.view.default(transpose_int_237, [1024, 2, 768]);  transpose_int_237 = None
        transpose_int_238 = torch.ops.aten.transpose.int(transpose_int_236, 0, 1);  transpose_int_236 = None
        view_default_486 = torch.ops.aten.view.default(transpose_int_238, [1024, 2, 768]);  transpose_int_238 = None
        div_tensor_3 = torch.ops.aten.div.Tensor(view_default_486, 8.0);  view_default_486 = None
        sum_dim_int_list_21 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_176, [0, 1], True)
        view_default_487 = torch.ops.aten.view.default(sum_dim_int_list_21, [768]);  sum_dim_int_list_21 = None
        view_default_488 = torch.ops.aten.view.default(_unsafe_view_default_176, [2048, 768]);  _unsafe_view_default_176 = None
        t_default_156 = torch.ops.aten.t.default(view_default_488)
        mm_default_90 = torch.ops.aten.mm.default(t_default_156, _unsafe_view_default_108);  t_default_156 = _unsafe_view_default_108 = None
        t_default_157 = torch.ops.aten.t.default(mm_default_90);  mm_default_90 = None
        t_default_158 = torch.ops.aten.t.default(t_default_50);  t_default_50 = None
        mm_default_91 = torch.ops.aten.mm.default(view_default_488, t_default_158);  view_default_488 = t_default_158 = None
        view_default_489 = torch.ops.aten.view.default(mm_default_91, [1024, 2, 768]);  mm_default_91 = None
        t_default_159 = torch.ops.aten.t.default(t_default_157);  t_default_157 = None
        sum_dim_int_list_22 = torch.ops.aten.sum.dim_IntList(view_default_485, [0, 1], True)
        view_default_490 = torch.ops.aten.view.default(sum_dim_int_list_22, [768]);  sum_dim_int_list_22 = None
        view_default_491 = torch.ops.aten.view.default(view_default_485, [2048, 768]);  view_default_485 = None
        t_default_160 = torch.ops.aten.t.default(view_default_491)
        mm_default_92 = torch.ops.aten.mm.default(t_default_160, _unsafe_view_default_106);  t_default_160 = _unsafe_view_default_106 = None
        t_default_161 = torch.ops.aten.t.default(mm_default_92);  mm_default_92 = None
        t_default_162 = torch.ops.aten.t.default(t_default_49);  t_default_49 = None
        mm_default_93 = torch.ops.aten.mm.default(view_default_491, t_default_162);  view_default_491 = t_default_162 = None
        view_default_492 = torch.ops.aten.view.default(mm_default_93, [1024, 2, 768]);  mm_default_93 = None
        add_tensor_105 = torch.ops.aten.add.Tensor(view_default_489, view_default_492);  view_default_489 = view_default_492 = None
        t_default_163 = torch.ops.aten.t.default(t_default_161);  t_default_161 = None
        sum_dim_int_list_23 = torch.ops.aten.sum.dim_IntList(div_tensor_3, [0, 1], True)
        view_default_493 = torch.ops.aten.view.default(sum_dim_int_list_23, [768]);  sum_dim_int_list_23 = None
        view_default_494 = torch.ops.aten.view.default(div_tensor_3, [2048, 768]);  div_tensor_3 = None
        t_default_164 = torch.ops.aten.t.default(view_default_494)
        mm_default_94 = torch.ops.aten.mm.default(t_default_164, _unsafe_view_default_104);  t_default_164 = _unsafe_view_default_104 = None
        t_default_165 = torch.ops.aten.t.default(mm_default_94);  mm_default_94 = None
        t_default_166 = torch.ops.aten.t.default(t_default_48);  t_default_48 = None
        mm_default_95 = torch.ops.aten.mm.default(view_default_494, t_default_166);  view_default_494 = t_default_166 = None
        view_default_495 = torch.ops.aten.view.default(mm_default_95, [1024, 2, 768]);  mm_default_95 = None
        add_tensor_106 = torch.ops.aten.add.Tensor(add_tensor_105, view_default_495);  add_tensor_105 = view_default_495 = None
        t_default_167 = torch.ops.aten.t.default(t_default_165);  t_default_165 = None
        transpose_int_239 = torch.ops.aten.transpose.int(add_tensor_106, 0, 1);  add_tensor_106 = None
        add_tensor_107 = torch.ops.aten.add.Tensor(getitem_93, transpose_int_239);  getitem_93 = transpose_int_239 = None
        native_layer_norm_backward_default_8 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_107, add_tensor_47, [768], getitem_46, getitem_47, primals_158, primals_157, [True, True, True]);  add_tensor_107 = add_tensor_47 = getitem_46 = getitem_47 = primals_158 = primals_157 = None
        getitem_96 = native_layer_norm_backward_default_8[0]
        getitem_97 = native_layer_norm_backward_default_8[1]
        getitem_98 = native_layer_norm_backward_default_8[2];  native_layer_norm_backward_default_8 = None
        view_default_496 = torch.ops.aten.view.default(getitem_96, [2048, 768])
        t_default_168 = torch.ops.aten.t.default(t_default_47);  t_default_47 = None
        mm_default_96 = torch.ops.aten.mm.default(view_default_496, t_default_168);  t_default_168 = None
        t_default_169 = torch.ops.aten.t.default(view_default_496)
        mm_default_97 = torch.ops.aten.mm.default(t_default_169, view_default_222);  t_default_169 = view_default_222 = None
        t_default_170 = torch.ops.aten.t.default(mm_default_97);  mm_default_97 = None
        sum_dim_int_list_24 = torch.ops.aten.sum.dim_IntList(view_default_496, [0], True);  view_default_496 = None
        view_default_497 = torch.ops.aten.view.default(sum_dim_int_list_24, [768]);  sum_dim_int_list_24 = None
        t_default_171 = torch.ops.aten.t.default(t_default_170);  t_default_170 = None
        view_default_498 = torch.ops.aten.view.default(mm_default_96, [2, 1024, 3072]);  mm_default_96 = None
        to_dtype_12 = torch.ops.aten.to.dtype(view_default_498, torch.float32);  view_default_498 = None
        to_dtype_13 = torch.ops.aten.to.dtype(view_default_221, torch.float32);  view_default_221 = None
        mul_tensor_40 = torch.ops.aten.mul.Tensor(to_dtype_13, 0.7071067811865476)
        erf_default_4 = torch.ops.aten.erf.default(mul_tensor_40);  mul_tensor_40 = None
        add_tensor_108 = torch.ops.aten.add.Tensor(erf_default_4, 1);  erf_default_4 = None
        mul_tensor_41 = torch.ops.aten.mul.Tensor(add_tensor_108, 0.5);  add_tensor_108 = None
        mul_tensor_42 = torch.ops.aten.mul.Tensor(to_dtype_13, to_dtype_13)
        mul_tensor_43 = torch.ops.aten.mul.Tensor(mul_tensor_42, -0.5);  mul_tensor_42 = None
        exp_default_4 = torch.ops.aten.exp.default(mul_tensor_43);  mul_tensor_43 = None
        mul_tensor_44 = torch.ops.aten.mul.Tensor(exp_default_4, 0.3989422804014327);  exp_default_4 = None
        mul_tensor_45 = torch.ops.aten.mul.Tensor(to_dtype_13, mul_tensor_44);  to_dtype_13 = mul_tensor_44 = None
        add_tensor_109 = torch.ops.aten.add.Tensor(mul_tensor_41, mul_tensor_45);  mul_tensor_41 = mul_tensor_45 = None
        mul_tensor_46 = torch.ops.aten.mul.Tensor(to_dtype_12, add_tensor_109);  to_dtype_12 = add_tensor_109 = None
        to_dtype_14 = torch.ops.aten.to.dtype(mul_tensor_46, torch.float32);  mul_tensor_46 = None
        view_default_499 = torch.ops.aten.view.default(to_dtype_14, [2048, 3072]);  to_dtype_14 = None
        t_default_172 = torch.ops.aten.t.default(t_default_46);  t_default_46 = None
        mm_default_98 = torch.ops.aten.mm.default(view_default_499, t_default_172);  t_default_172 = None
        t_default_173 = torch.ops.aten.t.default(view_default_499)
        mm_default_99 = torch.ops.aten.mm.default(t_default_173, view_default_220);  t_default_173 = view_default_220 = None
        t_default_174 = torch.ops.aten.t.default(mm_default_99);  mm_default_99 = None
        sum_dim_int_list_25 = torch.ops.aten.sum.dim_IntList(view_default_499, [0], True);  view_default_499 = None
        view_default_500 = torch.ops.aten.view.default(sum_dim_int_list_25, [3072]);  sum_dim_int_list_25 = None
        t_default_175 = torch.ops.aten.t.default(t_default_174);  t_default_174 = None
        view_default_501 = torch.ops.aten.view.default(mm_default_98, [2, 1024, 768]);  mm_default_98 = None
        add_tensor_110 = torch.ops.aten.add.Tensor(getitem_96, view_default_501);  getitem_96 = view_default_501 = None
        native_layer_norm_backward_default_9 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_110, add_tensor_46, [768], getitem_43, getitem_44, primals_146, primals_145, [True, True, True]);  add_tensor_110 = add_tensor_46 = getitem_43 = getitem_44 = primals_146 = primals_145 = None
        getitem_99 = native_layer_norm_backward_default_9[0]
        getitem_100 = native_layer_norm_backward_default_9[1]
        getitem_101 = native_layer_norm_backward_default_9[2];  native_layer_norm_backward_default_9 = None
        sum_dim_int_list_26 = torch.ops.aten.sum.dim_IntList(getitem_99, [0, 1], True)
        view_default_502 = torch.ops.aten.view.default(sum_dim_int_list_26, [768]);  sum_dim_int_list_26 = None
        view_default_503 = torch.ops.aten.view.default(getitem_99, [2048, 768])
        t_default_176 = torch.ops.aten.t.default(view_default_503)
        mm_default_100 = torch.ops.aten.mm.default(t_default_176, _unsafe_view_default_102);  t_default_176 = _unsafe_view_default_102 = None
        t_default_177 = torch.ops.aten.t.default(mm_default_100);  mm_default_100 = None
        t_default_178 = torch.ops.aten.t.default(t_default_45);  t_default_45 = None
        mm_default_101 = torch.ops.aten.mm.default(view_default_503, t_default_178);  view_default_503 = t_default_178 = None
        view_default_504 = torch.ops.aten.view.default(mm_default_101, [2, 1024, 768]);  mm_default_101 = None
        t_default_179 = torch.ops.aten.t.default(t_default_177);  t_default_177 = None
        transpose_int_240 = torch.ops.aten.transpose.int(view_default_504, 0, 1);  view_default_504 = None
        view_default_505 = torch.ops.aten.view.default(transpose_int_240, [1024, 2, 12, 64]);  transpose_int_240 = None
        transpose_int_241 = torch.ops.aten.transpose.int(view_default_505, 0, 1);  view_default_505 = None
        transpose_int_242 = torch.ops.aten.transpose.int(transpose_int_241, 1, 2);  transpose_int_241 = None
        clone_default_160 = torch.ops.aten.clone.default(transpose_int_242, memory_format = torch.contiguous_format);  transpose_int_242 = None
        _unsafe_view_default_180 = torch.ops.aten._unsafe_view.default(clone_default_160, [24, 4, 256, 64]);  clone_default_160 = None
        view_default_506 = torch.ops.aten.view.default(_unsafe_view_default_180, [24, 4, 256, 64, 1]);  _unsafe_view_default_180 = None
        permute_default_184 = torch.ops.aten.permute.default(view_default_506, [0, 1, 2, 4, 3]);  view_default_506 = None
        view_default_507 = torch.ops.aten.view.default(permute_default_184, [96, 256, 64]);  permute_default_184 = None
        transpose_int_243 = torch.ops.aten.transpose.int(view_default_216, 1, 2);  view_default_216 = None
        bmm_default_40 = torch.ops.aten.bmm.default(transpose_int_243, view_default_507);  transpose_int_243 = None
        transpose_int_244 = torch.ops.aten.transpose.int(_unsafe_view_default_100, 1, 2);  _unsafe_view_default_100 = None
        bmm_default_41 = torch.ops.aten.bmm.default(view_default_507, transpose_int_244);  view_default_507 = transpose_int_244 = None
        view_default_508 = torch.ops.aten.view.default(bmm_default_40, [24, 4, 768, 64, 1]);  bmm_default_40 = None
        permute_default_185 = torch.ops.aten.permute.default(view_default_508, [0, 1, 4, 3, 2]);  view_default_508 = None
        view_default_509 = torch.ops.aten.view.default(bmm_default_41, [24, 4, 256, 768, 1]);  bmm_default_41 = None
        permute_default_186 = torch.ops.aten.permute.default(view_default_509, [0, 1, 2, 4, 3]);  view_default_509 = None
        permute_default_187 = torch.ops.aten.permute.default(permute_default_185, [0, 1, 4, 3, 2]);  permute_default_185 = None
        squeeze_dim_40 = torch.ops.aten.squeeze.dim(permute_default_187, -1);  permute_default_187 = None
        permute_default_188 = torch.ops.aten.permute.default(permute_default_186, [0, 1, 2, 4, 3]);  permute_default_186 = None
        squeeze_dim_41 = torch.ops.aten.squeeze.dim(permute_default_188, -1);  permute_default_188 = None
        slice_backward_default_84 = torch.ops.aten.slice_backward.default(squeeze_dim_41, [24, 4, 256, 769], 3, 0, -1, 1);  squeeze_dim_41 = None
        slice_backward_default_85 = torch.ops.aten.slice_backward.default(slice_backward_default_84, [24, 4, 256, 769], 2, 0, 9223372036854775807, 1);  slice_backward_default_84 = None
        slice_backward_default_86 = torch.ops.aten.slice_backward.default(slice_backward_default_85, [24, 4, 256, 769], 1, 0, 9223372036854775807, 1);  slice_backward_default_85 = None
        slice_backward_default_87 = torch.ops.aten.slice_backward.default(slice_backward_default_86, [24, 4, 256, 769], 0, 0, 9223372036854775807, 1);  slice_backward_default_86 = None
        view_default_510 = torch.ops.aten.view.default(slice_backward_default_87, [24, 4, 196864]);  slice_backward_default_87 = None
        slice_backward_default_88 = torch.ops.aten.slice_backward.default(view_default_510, [24, 4, 197120], 2, 0, -256, 1);  view_default_510 = None
        slice_backward_default_89 = torch.ops.aten.slice_backward.default(slice_backward_default_88, [24, 4, 197120], 1, 0, 9223372036854775807, 1);  slice_backward_default_88 = None
        slice_backward_default_90 = torch.ops.aten.slice_backward.default(slice_backward_default_89, [24, 4, 197120], 0, 0, 9223372036854775807, 1);  slice_backward_default_89 = None
        view_default_511 = torch.ops.aten.view.default(slice_backward_default_90, [24, 4, 256, 770]);  slice_backward_default_90 = None
        constant_pad_nd_default_60 = torch.ops.aten.constant_pad_nd.default(view_default_511, [0, -257]);  view_default_511 = None
        new_empty_default_76 = torch.ops.aten.new_empty.default(squeeze_dim_40, [2359296])
        zero__default_28 = torch.ops.aten.zero_.default(new_empty_default_76);  new_empty_default_76 = None
        arange_12 = torch.ops.aten.arange.start(0, 2359296, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_120 = torch.ops.aten.as_strided.default(arange_12, [24, 4, 768, 64], [98304, 16384, 64, 1], 0);  arange_12 = None
        clone_default_161 = torch.ops.aten.clone.default(as_strided_default_120, memory_format = torch.contiguous_format);  as_strided_default_120 = None
        _unsafe_view_default_181 = torch.ops.aten._unsafe_view.default(clone_default_161, [4718592]);  clone_default_161 = None
        view_default_512 = torch.ops.aten.view.default(squeeze_dim_40, [4718592]);  squeeze_dim_40 = None
        index_add__default_12 = torch.ops.aten.index_add_.default(zero__default_28, 0, _unsafe_view_default_181, view_default_512);  zero__default_28 = _unsafe_view_default_181 = view_default_512 = None
        as_strided_default_121 = torch.ops.aten.as_strided.default(index_add__default_12, [24, 1536, 64], [98304, 64, 1], 0);  index_add__default_12 = None
        constant_pad_nd_default_61 = torch.ops.aten.constant_pad_nd.default(as_strided_default_121, [0, 0, -256, -256]);  as_strided_default_121 = None
        view_default_513 = torch.ops.aten.view.default(constant_pad_nd_default_61, [2, 12, 1024, 64]);  constant_pad_nd_default_61 = None
        transpose_int_245 = torch.ops.aten.transpose.int(view_default_513, 1, 2);  view_default_513 = None
        view_default_514 = torch.ops.aten.view.default(constant_pad_nd_default_60, [2, 12, 1024, 513]);  constant_pad_nd_default_60 = None
        transpose_int_246 = torch.ops.aten.transpose.int(view_default_514, 1, 2);  view_default_514 = None
        transpose_int_247 = torch.ops.aten.transpose.int(transpose_int_245, 0, 1);  transpose_int_245 = None
        clone_default_162 = torch.ops.aten.clone.default(transpose_int_247, memory_format = torch.contiguous_format);  transpose_int_247 = None
        _unsafe_view_default_182 = torch.ops.aten._unsafe_view.default(clone_default_162, [1024, 2, 768]);  clone_default_162 = None
        where_scalar_self_36 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_109, 0.0, transpose_int_246);  unsqueeze_default_109 = transpose_int_246 = None
        _softmax_backward_data_default_4 = torch.ops.aten._softmax_backward_data.default(where_scalar_self_36, _softmax_default_7, -1, torch.float32);  where_scalar_self_36 = _softmax_default_7 = None
        new_empty_default_77 = torch.ops.aten.new_empty.default(_softmax_backward_data_default_4, [12607488]);  _softmax_backward_data_default_4 = None
        zero__default_29 = torch.ops.aten.zero_.default(new_empty_default_77);  new_empty_default_77 = None
        as_strided_default_123 = torch.ops.aten.as_strided.default(zero__default_29, [24, 4, 256, 513], [525312, 131328, 513, 1], 0);  zero__default_29 = None
        new_empty_strided_default_28 = torch.ops.aten.new_empty_strided.default(as_strided_default_123, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_153 = torch.ops.aten.copy_.default(new_empty_strided_default_28, as_strided_default_123);  new_empty_strided_default_28 = as_strided_default_123 = None
        new_empty_strided_default_29 = torch.ops.aten.new_empty_strided.default(copy__default_153, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_155 = torch.ops.aten.copy_.default(new_empty_strided_default_29, copy__default_153);  new_empty_strided_default_29 = copy__default_153 = None
        new_empty_strided_default_30 = torch.ops.aten.new_empty_strided.default(copy__default_155, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_157 = torch.ops.aten.copy_.default(new_empty_strided_default_30, copy__default_155);  new_empty_strided_default_30 = copy__default_155 = None
        new_empty_strided_default_31 = torch.ops.aten.new_empty_strided.default(copy__default_157, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_159 = torch.ops.aten.copy_.default(new_empty_strided_default_31, copy__default_157);  new_empty_strided_default_31 = copy__default_157 = None
        as_strided_default_127 = torch.ops.aten.as_strided.default(copy__default_159, [24, 255, 255], [525312, 513, 1], 514)
        clone_default_166 = torch.ops.aten.clone.default(as_strided_default_127, memory_format = torch.contiguous_format);  as_strided_default_127 = None
        slice_backward_default_91 = torch.ops.aten.slice_backward.default(clone_default_166, [24, 255, 513], 2, -255, 9223372036854775807, 1);  clone_default_166 = None
        slice_backward_default_92 = torch.ops.aten.slice_backward.default(slice_backward_default_91, [24, 512, 513], 1, 0, 255, 1);  slice_backward_default_91 = None
        select_backward_default_8 = torch.ops.aten.select_backward.default(slice_backward_default_92, [24, 3, 512, 513], 1, 0);  slice_backward_default_92 = None
        slice_backward_default_93 = torch.ops.aten.slice_backward.default(select_backward_default_8, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_8 = None
        new_empty_strided_default_32 = torch.ops.aten.new_empty_strided.default(copy__default_159, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_161 = torch.ops.aten.copy_.default(new_empty_strided_default_32, copy__default_159);  new_empty_strided_default_32 = copy__default_159 = None
        as_strided_default_128 = torch.ops.aten.as_strided.default(copy__default_161, [24, 3, 256, 256], [525312, 131328, 513, 1], 131328)
        clone_default_167 = torch.ops.aten.clone.default(as_strided_default_128, memory_format = torch.contiguous_format);  as_strided_default_128 = None
        slice_backward_default_94 = torch.ops.aten.slice_backward.default(clone_default_167, [24, 3, 256, 513], 3, 257, 9223372036854775807, 1);  clone_default_167 = None
        slice_backward_default_95 = torch.ops.aten.slice_backward.default(slice_backward_default_94, [24, 3, 512, 513], 2, -257, -1, 1);  slice_backward_default_94 = None
        slice_backward_default_96 = torch.ops.aten.slice_backward.default(slice_backward_default_95, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_95 = None
        slice_backward_default_97 = torch.ops.aten.slice_backward.default(slice_backward_default_96, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_96 = None
        add_tensor_111 = torch.ops.aten.add.Tensor(slice_backward_default_93, slice_backward_default_97);  slice_backward_default_93 = slice_backward_default_97 = None
        new_empty_strided_default_33 = torch.ops.aten.new_empty_strided.default(copy__default_161, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_163 = torch.ops.aten.copy_.default(new_empty_strided_default_33, copy__default_161);  new_empty_strided_default_33 = copy__default_161 = None
        as_strided_default_129 = torch.ops.aten.as_strided.default(copy__default_163, [24, 256, 257], [525312, 513, 1], 394240)
        clone_default_168 = torch.ops.aten.clone.default(as_strided_default_129, memory_format = torch.contiguous_format);  as_strided_default_129 = None
        slice_backward_default_98 = torch.ops.aten.slice_backward.default(clone_default_168, [24, 256, 513], 2, 0, 257, 1);  clone_default_168 = None
        slice_backward_default_99 = torch.ops.aten.slice_backward.default(slice_backward_default_98, [24, 512, 513], 1, 256, 9223372036854775807, 1);  slice_backward_default_98 = None
        select_backward_default_9 = torch.ops.aten.select_backward.default(slice_backward_default_99, [24, 3, 512, 513], 1, -1);  slice_backward_default_99 = None
        slice_backward_default_100 = torch.ops.aten.slice_backward.default(select_backward_default_9, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_9 = None
        add_tensor_112 = torch.ops.aten.add.Tensor(add_tensor_111, slice_backward_default_100);  add_tensor_111 = slice_backward_default_100 = None
        new_empty_strided_default_34 = torch.ops.aten.new_empty_strided.default(copy__default_163, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_165 = torch.ops.aten.copy_.default(new_empty_strided_default_34, copy__default_163);  new_empty_strided_default_34 = copy__default_163 = None
        as_strided_default_130 = torch.ops.aten.as_strided.default(copy__default_165, [24, 3, 256, 257], [525312, 131328, 513, 1], 256);  copy__default_165 = None
        clone_default_169 = torch.ops.aten.clone.default(as_strided_default_130, memory_format = torch.contiguous_format);  as_strided_default_130 = None
        slice_backward_default_101 = torch.ops.aten.slice_backward.default(clone_default_169, [24, 3, 256, 513], 3, 0, 257, 1);  clone_default_169 = None
        slice_backward_default_102 = torch.ops.aten.slice_backward.default(slice_backward_default_101, [24, 3, 512, 513], 2, 0, 256, 1);  slice_backward_default_101 = None
        slice_backward_default_103 = torch.ops.aten.slice_backward.default(slice_backward_default_102, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_102 = None
        slice_backward_default_104 = torch.ops.aten.slice_backward.default(slice_backward_default_103, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_103 = None
        add_tensor_113 = torch.ops.aten.add.Tensor(add_tensor_112, slice_backward_default_104);  add_tensor_112 = slice_backward_default_104 = None
        view_default_515 = torch.ops.aten.view.default(add_tensor_113, [24, 3, 513, 512]);  add_tensor_113 = None
        constant_pad_nd_default_62 = torch.ops.aten.constant_pad_nd.default(view_default_515, [0, 0, 0, -1]);  view_default_515 = None
        view_default_516 = torch.ops.aten.view.default(constant_pad_nd_default_62, [24, 3, 512, 512, 1]);  constant_pad_nd_default_62 = None
        permute_default_189 = torch.ops.aten.permute.default(view_default_516, [0, 1, 2, 4, 3]);  view_default_516 = None
        view_default_517 = torch.ops.aten.view.default(permute_default_189, [72, 512, 512]);  permute_default_189 = None
        transpose_int_248 = torch.ops.aten.transpose.int(_unsafe_view_default_97, 1, 2);  _unsafe_view_default_97 = None
        bmm_default_42 = torch.ops.aten.bmm.default(transpose_int_248, view_default_517);  transpose_int_248 = None
        transpose_int_249 = torch.ops.aten.transpose.int(_unsafe_view_default_98, 1, 2);  _unsafe_view_default_98 = None
        bmm_default_43 = torch.ops.aten.bmm.default(view_default_517, transpose_int_249);  view_default_517 = transpose_int_249 = None
        view_default_518 = torch.ops.aten.view.default(bmm_default_42, [24, 3, 64, 512, 1]);  bmm_default_42 = None
        permute_default_190 = torch.ops.aten.permute.default(view_default_518, [0, 1, 4, 3, 2]);  view_default_518 = None
        view_default_519 = torch.ops.aten.view.default(bmm_default_43, [24, 3, 512, 64, 1]);  bmm_default_43 = None
        permute_default_191 = torch.ops.aten.permute.default(view_default_519, [0, 1, 2, 4, 3]);  view_default_519 = None
        permute_default_192 = torch.ops.aten.permute.default(permute_default_190, [0, 1, 3, 4, 2]);  permute_default_190 = None
        squeeze_dim_42 = torch.ops.aten.squeeze.dim(permute_default_192, -1);  permute_default_192 = None
        permute_default_193 = torch.ops.aten.permute.default(permute_default_191, [0, 1, 2, 4, 3]);  permute_default_191 = None
        squeeze_dim_43 = torch.ops.aten.squeeze.dim(permute_default_193, -1);  permute_default_193 = None
        new_empty_default_78 = torch.ops.aten.new_empty.default(squeeze_dim_42, [1572864])
        zero__default_33 = torch.ops.aten.zero_.default(new_empty_default_78);  new_empty_default_78 = None
        arange_13 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_131 = torch.ops.aten.as_strided.default(arange_13, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_13 = None
        clone_default_170 = torch.ops.aten.clone.default(as_strided_default_131, memory_format = torch.contiguous_format);  as_strided_default_131 = None
        _unsafe_view_default_183 = torch.ops.aten._unsafe_view.default(clone_default_170, [2359296]);  clone_default_170 = None
        clone_default_171 = torch.ops.aten.clone.default(squeeze_dim_42, memory_format = torch.contiguous_format);  squeeze_dim_42 = None
        _unsafe_view_default_184 = torch.ops.aten._unsafe_view.default(clone_default_171, [2359296]);  clone_default_171 = None
        index_add__default_13 = torch.ops.aten.index_add_.default(zero__default_33, 0, _unsafe_view_default_183, _unsafe_view_default_184);  zero__default_33 = _unsafe_view_default_183 = _unsafe_view_default_184 = None
        as_strided_default_132 = torch.ops.aten.as_strided.default(index_add__default_13, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_13 = None
        view_default_520 = torch.ops.aten.view.default(as_strided_default_132, [24, 1024, 64]);  as_strided_default_132 = None
        new_empty_default_79 = torch.ops.aten.new_empty.default(squeeze_dim_43, [1572864])
        zero__default_34 = torch.ops.aten.zero_.default(new_empty_default_79);  new_empty_default_79 = None
        arange_14 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_133 = torch.ops.aten.as_strided.default(arange_14, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_14 = None
        clone_default_172 = torch.ops.aten.clone.default(as_strided_default_133, memory_format = torch.contiguous_format);  as_strided_default_133 = None
        _unsafe_view_default_185 = torch.ops.aten._unsafe_view.default(clone_default_172, [2359296]);  clone_default_172 = None
        view_default_521 = torch.ops.aten.view.default(squeeze_dim_43, [2359296]);  squeeze_dim_43 = None
        index_add__default_14 = torch.ops.aten.index_add_.default(zero__default_34, 0, _unsafe_view_default_185, view_default_521);  zero__default_34 = _unsafe_view_default_185 = view_default_521 = None
        as_strided_default_134 = torch.ops.aten.as_strided.default(index_add__default_14, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_14 = None
        view_default_522 = torch.ops.aten.view.default(as_strided_default_134, [24, 1024, 64]);  as_strided_default_134 = None
        view_default_523 = torch.ops.aten.view.default(view_default_520, [2, 12, 1024, 64]);  view_default_520 = None
        transpose_int_250 = torch.ops.aten.transpose.int(view_default_523, 1, 2);  view_default_523 = None
        view_default_524 = torch.ops.aten.view.default(view_default_522, [2, 12, 1024, 64]);  view_default_522 = None
        transpose_int_251 = torch.ops.aten.transpose.int(view_default_524, 1, 2);  view_default_524 = None
        transpose_int_252 = torch.ops.aten.transpose.int(transpose_int_250, 0, 1);  transpose_int_250 = None
        view_default_525 = torch.ops.aten.view.default(transpose_int_252, [1024, 2, 768]);  transpose_int_252 = None
        transpose_int_253 = torch.ops.aten.transpose.int(transpose_int_251, 0, 1);  transpose_int_251 = None
        view_default_526 = torch.ops.aten.view.default(transpose_int_253, [1024, 2, 768]);  transpose_int_253 = None
        div_tensor_4 = torch.ops.aten.div.Tensor(view_default_526, 8.0);  view_default_526 = None
        sum_dim_int_list_27 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_182, [0, 1], True)
        view_default_527 = torch.ops.aten.view.default(sum_dim_int_list_27, [768]);  sum_dim_int_list_27 = None
        view_default_528 = torch.ops.aten.view.default(_unsafe_view_default_182, [2048, 768]);  _unsafe_view_default_182 = None
        t_default_180 = torch.ops.aten.t.default(view_default_528)
        mm_default_102 = torch.ops.aten.mm.default(t_default_180, _unsafe_view_default_95);  t_default_180 = _unsafe_view_default_95 = None
        t_default_181 = torch.ops.aten.t.default(mm_default_102);  mm_default_102 = None
        t_default_182 = torch.ops.aten.t.default(t_default_44);  t_default_44 = None
        mm_default_103 = torch.ops.aten.mm.default(view_default_528, t_default_182);  view_default_528 = t_default_182 = None
        view_default_529 = torch.ops.aten.view.default(mm_default_103, [1024, 2, 768]);  mm_default_103 = None
        t_default_183 = torch.ops.aten.t.default(t_default_181);  t_default_181 = None
        sum_dim_int_list_28 = torch.ops.aten.sum.dim_IntList(view_default_525, [0, 1], True)
        view_default_530 = torch.ops.aten.view.default(sum_dim_int_list_28, [768]);  sum_dim_int_list_28 = None
        view_default_531 = torch.ops.aten.view.default(view_default_525, [2048, 768]);  view_default_525 = None
        t_default_184 = torch.ops.aten.t.default(view_default_531)
        mm_default_104 = torch.ops.aten.mm.default(t_default_184, _unsafe_view_default_93);  t_default_184 = _unsafe_view_default_93 = None
        t_default_185 = torch.ops.aten.t.default(mm_default_104);  mm_default_104 = None
        t_default_186 = torch.ops.aten.t.default(t_default_43);  t_default_43 = None
        mm_default_105 = torch.ops.aten.mm.default(view_default_531, t_default_186);  view_default_531 = t_default_186 = None
        view_default_532 = torch.ops.aten.view.default(mm_default_105, [1024, 2, 768]);  mm_default_105 = None
        add_tensor_114 = torch.ops.aten.add.Tensor(view_default_529, view_default_532);  view_default_529 = view_default_532 = None
        t_default_187 = torch.ops.aten.t.default(t_default_185);  t_default_185 = None
        sum_dim_int_list_29 = torch.ops.aten.sum.dim_IntList(div_tensor_4, [0, 1], True)
        view_default_533 = torch.ops.aten.view.default(sum_dim_int_list_29, [768]);  sum_dim_int_list_29 = None
        view_default_534 = torch.ops.aten.view.default(div_tensor_4, [2048, 768]);  div_tensor_4 = None
        t_default_188 = torch.ops.aten.t.default(view_default_534)
        mm_default_106 = torch.ops.aten.mm.default(t_default_188, _unsafe_view_default_91);  t_default_188 = _unsafe_view_default_91 = None
        t_default_189 = torch.ops.aten.t.default(mm_default_106);  mm_default_106 = None
        t_default_190 = torch.ops.aten.t.default(t_default_42);  t_default_42 = None
        mm_default_107 = torch.ops.aten.mm.default(view_default_534, t_default_190);  view_default_534 = t_default_190 = None
        view_default_535 = torch.ops.aten.view.default(mm_default_107, [1024, 2, 768]);  mm_default_107 = None
        add_tensor_115 = torch.ops.aten.add.Tensor(add_tensor_114, view_default_535);  add_tensor_114 = view_default_535 = None
        t_default_191 = torch.ops.aten.t.default(t_default_189);  t_default_189 = None
        transpose_int_254 = torch.ops.aten.transpose.int(add_tensor_115, 0, 1);  add_tensor_115 = None
        add_tensor_116 = torch.ops.aten.add.Tensor(getitem_99, transpose_int_254);  getitem_99 = transpose_int_254 = None
        native_layer_norm_backward_default_10 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_116, add_tensor_41, [768], getitem_40, getitem_41, primals_142, primals_141, [True, True, True]);  add_tensor_116 = add_tensor_41 = getitem_40 = getitem_41 = primals_142 = primals_141 = None
        getitem_102 = native_layer_norm_backward_default_10[0]
        getitem_103 = native_layer_norm_backward_default_10[1]
        getitem_104 = native_layer_norm_backward_default_10[2];  native_layer_norm_backward_default_10 = None
        view_default_536 = torch.ops.aten.view.default(getitem_102, [2048, 768])
        t_default_192 = torch.ops.aten.t.default(t_default_41);  t_default_41 = None
        mm_default_108 = torch.ops.aten.mm.default(view_default_536, t_default_192);  t_default_192 = None
        t_default_193 = torch.ops.aten.t.default(view_default_536)
        mm_default_109 = torch.ops.aten.mm.default(t_default_193, view_default_194);  t_default_193 = view_default_194 = None
        t_default_194 = torch.ops.aten.t.default(mm_default_109);  mm_default_109 = None
        sum_dim_int_list_30 = torch.ops.aten.sum.dim_IntList(view_default_536, [0], True);  view_default_536 = None
        view_default_537 = torch.ops.aten.view.default(sum_dim_int_list_30, [768]);  sum_dim_int_list_30 = None
        t_default_195 = torch.ops.aten.t.default(t_default_194);  t_default_194 = None
        view_default_538 = torch.ops.aten.view.default(mm_default_108, [2, 1024, 3072]);  mm_default_108 = None
        to_dtype_15 = torch.ops.aten.to.dtype(view_default_538, torch.float32);  view_default_538 = None
        to_dtype_16 = torch.ops.aten.to.dtype(view_default_193, torch.float32);  view_default_193 = None
        mul_tensor_47 = torch.ops.aten.mul.Tensor(to_dtype_16, 0.7071067811865476)
        erf_default_5 = torch.ops.aten.erf.default(mul_tensor_47);  mul_tensor_47 = None
        add_tensor_117 = torch.ops.aten.add.Tensor(erf_default_5, 1);  erf_default_5 = None
        mul_tensor_48 = torch.ops.aten.mul.Tensor(add_tensor_117, 0.5);  add_tensor_117 = None
        mul_tensor_49 = torch.ops.aten.mul.Tensor(to_dtype_16, to_dtype_16)
        mul_tensor_50 = torch.ops.aten.mul.Tensor(mul_tensor_49, -0.5);  mul_tensor_49 = None
        exp_default_5 = torch.ops.aten.exp.default(mul_tensor_50);  mul_tensor_50 = None
        mul_tensor_51 = torch.ops.aten.mul.Tensor(exp_default_5, 0.3989422804014327);  exp_default_5 = None
        mul_tensor_52 = torch.ops.aten.mul.Tensor(to_dtype_16, mul_tensor_51);  to_dtype_16 = mul_tensor_51 = None
        add_tensor_118 = torch.ops.aten.add.Tensor(mul_tensor_48, mul_tensor_52);  mul_tensor_48 = mul_tensor_52 = None
        mul_tensor_53 = torch.ops.aten.mul.Tensor(to_dtype_15, add_tensor_118);  to_dtype_15 = add_tensor_118 = None
        to_dtype_17 = torch.ops.aten.to.dtype(mul_tensor_53, torch.float32);  mul_tensor_53 = None
        view_default_539 = torch.ops.aten.view.default(to_dtype_17, [2048, 3072]);  to_dtype_17 = None
        t_default_196 = torch.ops.aten.t.default(t_default_40);  t_default_40 = None
        mm_default_110 = torch.ops.aten.mm.default(view_default_539, t_default_196);  t_default_196 = None
        t_default_197 = torch.ops.aten.t.default(view_default_539)
        mm_default_111 = torch.ops.aten.mm.default(t_default_197, view_default_192);  t_default_197 = view_default_192 = None
        t_default_198 = torch.ops.aten.t.default(mm_default_111);  mm_default_111 = None
        sum_dim_int_list_31 = torch.ops.aten.sum.dim_IntList(view_default_539, [0], True);  view_default_539 = None
        view_default_540 = torch.ops.aten.view.default(sum_dim_int_list_31, [3072]);  sum_dim_int_list_31 = None
        t_default_199 = torch.ops.aten.t.default(t_default_198);  t_default_198 = None
        view_default_541 = torch.ops.aten.view.default(mm_default_110, [2, 1024, 768]);  mm_default_110 = None
        add_tensor_119 = torch.ops.aten.add.Tensor(getitem_102, view_default_541);  getitem_102 = view_default_541 = None
        native_layer_norm_backward_default_11 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_119, add_tensor_40, [768], getitem_37, getitem_38, primals_130, primals_129, [True, True, True]);  add_tensor_119 = add_tensor_40 = getitem_37 = getitem_38 = primals_130 = primals_129 = None
        getitem_105 = native_layer_norm_backward_default_11[0]
        getitem_106 = native_layer_norm_backward_default_11[1]
        getitem_107 = native_layer_norm_backward_default_11[2];  native_layer_norm_backward_default_11 = None
        sum_dim_int_list_32 = torch.ops.aten.sum.dim_IntList(getitem_105, [0, 1], True)
        view_default_542 = torch.ops.aten.view.default(sum_dim_int_list_32, [768]);  sum_dim_int_list_32 = None
        view_default_543 = torch.ops.aten.view.default(getitem_105, [2048, 768])
        t_default_200 = torch.ops.aten.t.default(view_default_543)
        mm_default_112 = torch.ops.aten.mm.default(t_default_200, _unsafe_view_default_89);  t_default_200 = _unsafe_view_default_89 = None
        t_default_201 = torch.ops.aten.t.default(mm_default_112);  mm_default_112 = None
        t_default_202 = torch.ops.aten.t.default(t_default_39);  t_default_39 = None
        mm_default_113 = torch.ops.aten.mm.default(view_default_543, t_default_202);  view_default_543 = t_default_202 = None
        view_default_544 = torch.ops.aten.view.default(mm_default_113, [2, 1024, 768]);  mm_default_113 = None
        t_default_203 = torch.ops.aten.t.default(t_default_201);  t_default_201 = None
        transpose_int_255 = torch.ops.aten.transpose.int(view_default_544, 0, 1);  view_default_544 = None
        view_default_545 = torch.ops.aten.view.default(transpose_int_255, [1024, 2, 12, 64]);  transpose_int_255 = None
        transpose_int_256 = torch.ops.aten.transpose.int(view_default_545, 0, 1);  view_default_545 = None
        transpose_int_257 = torch.ops.aten.transpose.int(transpose_int_256, 1, 2);  transpose_int_256 = None
        clone_default_173 = torch.ops.aten.clone.default(transpose_int_257, memory_format = torch.contiguous_format);  transpose_int_257 = None
        _unsafe_view_default_186 = torch.ops.aten._unsafe_view.default(clone_default_173, [24, 4, 256, 64]);  clone_default_173 = None
        view_default_546 = torch.ops.aten.view.default(_unsafe_view_default_186, [24, 4, 256, 64, 1]);  _unsafe_view_default_186 = None
        permute_default_194 = torch.ops.aten.permute.default(view_default_546, [0, 1, 2, 4, 3]);  view_default_546 = None
        view_default_547 = torch.ops.aten.view.default(permute_default_194, [96, 256, 64]);  permute_default_194 = None
        transpose_int_258 = torch.ops.aten.transpose.int(view_default_188, 1, 2);  view_default_188 = None
        bmm_default_44 = torch.ops.aten.bmm.default(transpose_int_258, view_default_547);  transpose_int_258 = None
        transpose_int_259 = torch.ops.aten.transpose.int(_unsafe_view_default_87, 1, 2);  _unsafe_view_default_87 = None
        bmm_default_45 = torch.ops.aten.bmm.default(view_default_547, transpose_int_259);  view_default_547 = transpose_int_259 = None
        view_default_548 = torch.ops.aten.view.default(bmm_default_44, [24, 4, 768, 64, 1]);  bmm_default_44 = None
        permute_default_195 = torch.ops.aten.permute.default(view_default_548, [0, 1, 4, 3, 2]);  view_default_548 = None
        view_default_549 = torch.ops.aten.view.default(bmm_default_45, [24, 4, 256, 768, 1]);  bmm_default_45 = None
        permute_default_196 = torch.ops.aten.permute.default(view_default_549, [0, 1, 2, 4, 3]);  view_default_549 = None
        permute_default_197 = torch.ops.aten.permute.default(permute_default_195, [0, 1, 4, 3, 2]);  permute_default_195 = None
        squeeze_dim_44 = torch.ops.aten.squeeze.dim(permute_default_197, -1);  permute_default_197 = None
        permute_default_198 = torch.ops.aten.permute.default(permute_default_196, [0, 1, 2, 4, 3]);  permute_default_196 = None
        squeeze_dim_45 = torch.ops.aten.squeeze.dim(permute_default_198, -1);  permute_default_198 = None
        slice_backward_default_105 = torch.ops.aten.slice_backward.default(squeeze_dim_45, [24, 4, 256, 769], 3, 0, -1, 1);  squeeze_dim_45 = None
        slice_backward_default_106 = torch.ops.aten.slice_backward.default(slice_backward_default_105, [24, 4, 256, 769], 2, 0, 9223372036854775807, 1);  slice_backward_default_105 = None
        slice_backward_default_107 = torch.ops.aten.slice_backward.default(slice_backward_default_106, [24, 4, 256, 769], 1, 0, 9223372036854775807, 1);  slice_backward_default_106 = None
        slice_backward_default_108 = torch.ops.aten.slice_backward.default(slice_backward_default_107, [24, 4, 256, 769], 0, 0, 9223372036854775807, 1);  slice_backward_default_107 = None
        view_default_550 = torch.ops.aten.view.default(slice_backward_default_108, [24, 4, 196864]);  slice_backward_default_108 = None
        slice_backward_default_109 = torch.ops.aten.slice_backward.default(view_default_550, [24, 4, 197120], 2, 0, -256, 1);  view_default_550 = None
        slice_backward_default_110 = torch.ops.aten.slice_backward.default(slice_backward_default_109, [24, 4, 197120], 1, 0, 9223372036854775807, 1);  slice_backward_default_109 = None
        slice_backward_default_111 = torch.ops.aten.slice_backward.default(slice_backward_default_110, [24, 4, 197120], 0, 0, 9223372036854775807, 1);  slice_backward_default_110 = None
        view_default_551 = torch.ops.aten.view.default(slice_backward_default_111, [24, 4, 256, 770]);  slice_backward_default_111 = None
        constant_pad_nd_default_63 = torch.ops.aten.constant_pad_nd.default(view_default_551, [0, -257]);  view_default_551 = None
        new_empty_default_80 = torch.ops.aten.new_empty.default(squeeze_dim_44, [2359296])
        zero__default_35 = torch.ops.aten.zero_.default(new_empty_default_80);  new_empty_default_80 = None
        arange_15 = torch.ops.aten.arange.start(0, 2359296, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_135 = torch.ops.aten.as_strided.default(arange_15, [24, 4, 768, 64], [98304, 16384, 64, 1], 0);  arange_15 = None
        clone_default_174 = torch.ops.aten.clone.default(as_strided_default_135, memory_format = torch.contiguous_format);  as_strided_default_135 = None
        _unsafe_view_default_187 = torch.ops.aten._unsafe_view.default(clone_default_174, [4718592]);  clone_default_174 = None
        view_default_552 = torch.ops.aten.view.default(squeeze_dim_44, [4718592]);  squeeze_dim_44 = None
        index_add__default_15 = torch.ops.aten.index_add_.default(zero__default_35, 0, _unsafe_view_default_187, view_default_552);  zero__default_35 = _unsafe_view_default_187 = view_default_552 = None
        as_strided_default_136 = torch.ops.aten.as_strided.default(index_add__default_15, [24, 1536, 64], [98304, 64, 1], 0);  index_add__default_15 = None
        constant_pad_nd_default_64 = torch.ops.aten.constant_pad_nd.default(as_strided_default_136, [0, 0, -256, -256]);  as_strided_default_136 = None
        view_default_553 = torch.ops.aten.view.default(constant_pad_nd_default_64, [2, 12, 1024, 64]);  constant_pad_nd_default_64 = None
        transpose_int_260 = torch.ops.aten.transpose.int(view_default_553, 1, 2);  view_default_553 = None
        view_default_554 = torch.ops.aten.view.default(constant_pad_nd_default_63, [2, 12, 1024, 513]);  constant_pad_nd_default_63 = None
        transpose_int_261 = torch.ops.aten.transpose.int(view_default_554, 1, 2);  view_default_554 = None
        transpose_int_262 = torch.ops.aten.transpose.int(transpose_int_260, 0, 1);  transpose_int_260 = None
        clone_default_175 = torch.ops.aten.clone.default(transpose_int_262, memory_format = torch.contiguous_format);  transpose_int_262 = None
        _unsafe_view_default_188 = torch.ops.aten._unsafe_view.default(clone_default_175, [1024, 2, 768]);  clone_default_175 = None
        where_scalar_self_39 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_95, 0.0, transpose_int_261);  unsqueeze_default_95 = transpose_int_261 = None
        _softmax_backward_data_default_5 = torch.ops.aten._softmax_backward_data.default(where_scalar_self_39, _softmax_default_6, -1, torch.float32);  where_scalar_self_39 = _softmax_default_6 = None
        new_empty_default_81 = torch.ops.aten.new_empty.default(_softmax_backward_data_default_5, [12607488]);  _softmax_backward_data_default_5 = None
        zero__default_36 = torch.ops.aten.zero_.default(new_empty_default_81);  new_empty_default_81 = None
        as_strided_default_138 = torch.ops.aten.as_strided.default(zero__default_36, [24, 4, 256, 513], [525312, 131328, 513, 1], 0);  zero__default_36 = None
        new_empty_strided_default_35 = torch.ops.aten.new_empty_strided.default(as_strided_default_138, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_167 = torch.ops.aten.copy_.default(new_empty_strided_default_35, as_strided_default_138);  new_empty_strided_default_35 = as_strided_default_138 = None
        new_empty_strided_default_36 = torch.ops.aten.new_empty_strided.default(copy__default_167, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_169 = torch.ops.aten.copy_.default(new_empty_strided_default_36, copy__default_167);  new_empty_strided_default_36 = copy__default_167 = None
        new_empty_strided_default_37 = torch.ops.aten.new_empty_strided.default(copy__default_169, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_171 = torch.ops.aten.copy_.default(new_empty_strided_default_37, copy__default_169);  new_empty_strided_default_37 = copy__default_169 = None
        new_empty_strided_default_38 = torch.ops.aten.new_empty_strided.default(copy__default_171, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_173 = torch.ops.aten.copy_.default(new_empty_strided_default_38, copy__default_171);  new_empty_strided_default_38 = copy__default_171 = None
        as_strided_default_142 = torch.ops.aten.as_strided.default(copy__default_173, [24, 255, 255], [525312, 513, 1], 514)
        clone_default_179 = torch.ops.aten.clone.default(as_strided_default_142, memory_format = torch.contiguous_format);  as_strided_default_142 = None
        slice_backward_default_112 = torch.ops.aten.slice_backward.default(clone_default_179, [24, 255, 513], 2, -255, 9223372036854775807, 1);  clone_default_179 = None
        slice_backward_default_113 = torch.ops.aten.slice_backward.default(slice_backward_default_112, [24, 512, 513], 1, 0, 255, 1);  slice_backward_default_112 = None
        select_backward_default_10 = torch.ops.aten.select_backward.default(slice_backward_default_113, [24, 3, 512, 513], 1, 0);  slice_backward_default_113 = None
        slice_backward_default_114 = torch.ops.aten.slice_backward.default(select_backward_default_10, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_10 = None
        new_empty_strided_default_39 = torch.ops.aten.new_empty_strided.default(copy__default_173, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_175 = torch.ops.aten.copy_.default(new_empty_strided_default_39, copy__default_173);  new_empty_strided_default_39 = copy__default_173 = None
        as_strided_default_143 = torch.ops.aten.as_strided.default(copy__default_175, [24, 3, 256, 256], [525312, 131328, 513, 1], 131328)
        clone_default_180 = torch.ops.aten.clone.default(as_strided_default_143, memory_format = torch.contiguous_format);  as_strided_default_143 = None
        slice_backward_default_115 = torch.ops.aten.slice_backward.default(clone_default_180, [24, 3, 256, 513], 3, 257, 9223372036854775807, 1);  clone_default_180 = None
        slice_backward_default_116 = torch.ops.aten.slice_backward.default(slice_backward_default_115, [24, 3, 512, 513], 2, -257, -1, 1);  slice_backward_default_115 = None
        slice_backward_default_117 = torch.ops.aten.slice_backward.default(slice_backward_default_116, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_116 = None
        slice_backward_default_118 = torch.ops.aten.slice_backward.default(slice_backward_default_117, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_117 = None
        add_tensor_120 = torch.ops.aten.add.Tensor(slice_backward_default_114, slice_backward_default_118);  slice_backward_default_114 = slice_backward_default_118 = None
        new_empty_strided_default_40 = torch.ops.aten.new_empty_strided.default(copy__default_175, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_177 = torch.ops.aten.copy_.default(new_empty_strided_default_40, copy__default_175);  new_empty_strided_default_40 = copy__default_175 = None
        as_strided_default_144 = torch.ops.aten.as_strided.default(copy__default_177, [24, 256, 257], [525312, 513, 1], 394240)
        clone_default_181 = torch.ops.aten.clone.default(as_strided_default_144, memory_format = torch.contiguous_format);  as_strided_default_144 = None
        slice_backward_default_119 = torch.ops.aten.slice_backward.default(clone_default_181, [24, 256, 513], 2, 0, 257, 1);  clone_default_181 = None
        slice_backward_default_120 = torch.ops.aten.slice_backward.default(slice_backward_default_119, [24, 512, 513], 1, 256, 9223372036854775807, 1);  slice_backward_default_119 = None
        select_backward_default_11 = torch.ops.aten.select_backward.default(slice_backward_default_120, [24, 3, 512, 513], 1, -1);  slice_backward_default_120 = None
        slice_backward_default_121 = torch.ops.aten.slice_backward.default(select_backward_default_11, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_11 = None
        add_tensor_121 = torch.ops.aten.add.Tensor(add_tensor_120, slice_backward_default_121);  add_tensor_120 = slice_backward_default_121 = None
        new_empty_strided_default_41 = torch.ops.aten.new_empty_strided.default(copy__default_177, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_179 = torch.ops.aten.copy_.default(new_empty_strided_default_41, copy__default_177);  new_empty_strided_default_41 = copy__default_177 = None
        as_strided_default_145 = torch.ops.aten.as_strided.default(copy__default_179, [24, 3, 256, 257], [525312, 131328, 513, 1], 256);  copy__default_179 = None
        clone_default_182 = torch.ops.aten.clone.default(as_strided_default_145, memory_format = torch.contiguous_format);  as_strided_default_145 = None
        slice_backward_default_122 = torch.ops.aten.slice_backward.default(clone_default_182, [24, 3, 256, 513], 3, 0, 257, 1);  clone_default_182 = None
        slice_backward_default_123 = torch.ops.aten.slice_backward.default(slice_backward_default_122, [24, 3, 512, 513], 2, 0, 256, 1);  slice_backward_default_122 = None
        slice_backward_default_124 = torch.ops.aten.slice_backward.default(slice_backward_default_123, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_123 = None
        slice_backward_default_125 = torch.ops.aten.slice_backward.default(slice_backward_default_124, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_124 = None
        add_tensor_122 = torch.ops.aten.add.Tensor(add_tensor_121, slice_backward_default_125);  add_tensor_121 = slice_backward_default_125 = None
        view_default_555 = torch.ops.aten.view.default(add_tensor_122, [24, 3, 513, 512]);  add_tensor_122 = None
        constant_pad_nd_default_65 = torch.ops.aten.constant_pad_nd.default(view_default_555, [0, 0, 0, -1]);  view_default_555 = None
        view_default_556 = torch.ops.aten.view.default(constant_pad_nd_default_65, [24, 3, 512, 512, 1]);  constant_pad_nd_default_65 = None
        permute_default_199 = torch.ops.aten.permute.default(view_default_556, [0, 1, 2, 4, 3]);  view_default_556 = None
        view_default_557 = torch.ops.aten.view.default(permute_default_199, [72, 512, 512]);  permute_default_199 = None
        transpose_int_263 = torch.ops.aten.transpose.int(_unsafe_view_default_84, 1, 2);  _unsafe_view_default_84 = None
        bmm_default_46 = torch.ops.aten.bmm.default(transpose_int_263, view_default_557);  transpose_int_263 = None
        transpose_int_264 = torch.ops.aten.transpose.int(_unsafe_view_default_85, 1, 2);  _unsafe_view_default_85 = None
        bmm_default_47 = torch.ops.aten.bmm.default(view_default_557, transpose_int_264);  view_default_557 = transpose_int_264 = None
        view_default_558 = torch.ops.aten.view.default(bmm_default_46, [24, 3, 64, 512, 1]);  bmm_default_46 = None
        permute_default_200 = torch.ops.aten.permute.default(view_default_558, [0, 1, 4, 3, 2]);  view_default_558 = None
        view_default_559 = torch.ops.aten.view.default(bmm_default_47, [24, 3, 512, 64, 1]);  bmm_default_47 = None
        permute_default_201 = torch.ops.aten.permute.default(view_default_559, [0, 1, 2, 4, 3]);  view_default_559 = None
        permute_default_202 = torch.ops.aten.permute.default(permute_default_200, [0, 1, 3, 4, 2]);  permute_default_200 = None
        squeeze_dim_46 = torch.ops.aten.squeeze.dim(permute_default_202, -1);  permute_default_202 = None
        permute_default_203 = torch.ops.aten.permute.default(permute_default_201, [0, 1, 2, 4, 3]);  permute_default_201 = None
        squeeze_dim_47 = torch.ops.aten.squeeze.dim(permute_default_203, -1);  permute_default_203 = None
        new_empty_default_82 = torch.ops.aten.new_empty.default(squeeze_dim_46, [1572864])
        zero__default_40 = torch.ops.aten.zero_.default(new_empty_default_82);  new_empty_default_82 = None
        arange_16 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_146 = torch.ops.aten.as_strided.default(arange_16, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_16 = None
        clone_default_183 = torch.ops.aten.clone.default(as_strided_default_146, memory_format = torch.contiguous_format);  as_strided_default_146 = None
        _unsafe_view_default_189 = torch.ops.aten._unsafe_view.default(clone_default_183, [2359296]);  clone_default_183 = None
        clone_default_184 = torch.ops.aten.clone.default(squeeze_dim_46, memory_format = torch.contiguous_format);  squeeze_dim_46 = None
        _unsafe_view_default_190 = torch.ops.aten._unsafe_view.default(clone_default_184, [2359296]);  clone_default_184 = None
        index_add__default_16 = torch.ops.aten.index_add_.default(zero__default_40, 0, _unsafe_view_default_189, _unsafe_view_default_190);  zero__default_40 = _unsafe_view_default_189 = _unsafe_view_default_190 = None
        as_strided_default_147 = torch.ops.aten.as_strided.default(index_add__default_16, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_16 = None
        view_default_560 = torch.ops.aten.view.default(as_strided_default_147, [24, 1024, 64]);  as_strided_default_147 = None
        new_empty_default_83 = torch.ops.aten.new_empty.default(squeeze_dim_47, [1572864])
        zero__default_41 = torch.ops.aten.zero_.default(new_empty_default_83);  new_empty_default_83 = None
        arange_17 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_148 = torch.ops.aten.as_strided.default(arange_17, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_17 = None
        clone_default_185 = torch.ops.aten.clone.default(as_strided_default_148, memory_format = torch.contiguous_format);  as_strided_default_148 = None
        _unsafe_view_default_191 = torch.ops.aten._unsafe_view.default(clone_default_185, [2359296]);  clone_default_185 = None
        view_default_561 = torch.ops.aten.view.default(squeeze_dim_47, [2359296]);  squeeze_dim_47 = None
        index_add__default_17 = torch.ops.aten.index_add_.default(zero__default_41, 0, _unsafe_view_default_191, view_default_561);  zero__default_41 = _unsafe_view_default_191 = view_default_561 = None
        as_strided_default_149 = torch.ops.aten.as_strided.default(index_add__default_17, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_17 = None
        view_default_562 = torch.ops.aten.view.default(as_strided_default_149, [24, 1024, 64]);  as_strided_default_149 = None
        view_default_563 = torch.ops.aten.view.default(view_default_560, [2, 12, 1024, 64]);  view_default_560 = None
        transpose_int_265 = torch.ops.aten.transpose.int(view_default_563, 1, 2);  view_default_563 = None
        view_default_564 = torch.ops.aten.view.default(view_default_562, [2, 12, 1024, 64]);  view_default_562 = None
        transpose_int_266 = torch.ops.aten.transpose.int(view_default_564, 1, 2);  view_default_564 = None
        transpose_int_267 = torch.ops.aten.transpose.int(transpose_int_265, 0, 1);  transpose_int_265 = None
        view_default_565 = torch.ops.aten.view.default(transpose_int_267, [1024, 2, 768]);  transpose_int_267 = None
        transpose_int_268 = torch.ops.aten.transpose.int(transpose_int_266, 0, 1);  transpose_int_266 = None
        view_default_566 = torch.ops.aten.view.default(transpose_int_268, [1024, 2, 768]);  transpose_int_268 = None
        div_tensor_5 = torch.ops.aten.div.Tensor(view_default_566, 8.0);  view_default_566 = None
        sum_dim_int_list_33 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_188, [0, 1], True)
        view_default_567 = torch.ops.aten.view.default(sum_dim_int_list_33, [768]);  sum_dim_int_list_33 = None
        view_default_568 = torch.ops.aten.view.default(_unsafe_view_default_188, [2048, 768]);  _unsafe_view_default_188 = None
        t_default_204 = torch.ops.aten.t.default(view_default_568)
        mm_default_114 = torch.ops.aten.mm.default(t_default_204, _unsafe_view_default_82);  t_default_204 = _unsafe_view_default_82 = None
        t_default_205 = torch.ops.aten.t.default(mm_default_114);  mm_default_114 = None
        t_default_206 = torch.ops.aten.t.default(t_default_38);  t_default_38 = None
        mm_default_115 = torch.ops.aten.mm.default(view_default_568, t_default_206);  view_default_568 = t_default_206 = None
        view_default_569 = torch.ops.aten.view.default(mm_default_115, [1024, 2, 768]);  mm_default_115 = None
        t_default_207 = torch.ops.aten.t.default(t_default_205);  t_default_205 = None
        sum_dim_int_list_34 = torch.ops.aten.sum.dim_IntList(view_default_565, [0, 1], True)
        view_default_570 = torch.ops.aten.view.default(sum_dim_int_list_34, [768]);  sum_dim_int_list_34 = None
        view_default_571 = torch.ops.aten.view.default(view_default_565, [2048, 768]);  view_default_565 = None
        t_default_208 = torch.ops.aten.t.default(view_default_571)
        mm_default_116 = torch.ops.aten.mm.default(t_default_208, _unsafe_view_default_80);  t_default_208 = _unsafe_view_default_80 = None
        t_default_209 = torch.ops.aten.t.default(mm_default_116);  mm_default_116 = None
        t_default_210 = torch.ops.aten.t.default(t_default_37);  t_default_37 = None
        mm_default_117 = torch.ops.aten.mm.default(view_default_571, t_default_210);  view_default_571 = t_default_210 = None
        view_default_572 = torch.ops.aten.view.default(mm_default_117, [1024, 2, 768]);  mm_default_117 = None
        add_tensor_123 = torch.ops.aten.add.Tensor(view_default_569, view_default_572);  view_default_569 = view_default_572 = None
        t_default_211 = torch.ops.aten.t.default(t_default_209);  t_default_209 = None
        sum_dim_int_list_35 = torch.ops.aten.sum.dim_IntList(div_tensor_5, [0, 1], True)
        view_default_573 = torch.ops.aten.view.default(sum_dim_int_list_35, [768]);  sum_dim_int_list_35 = None
        view_default_574 = torch.ops.aten.view.default(div_tensor_5, [2048, 768]);  div_tensor_5 = None
        t_default_212 = torch.ops.aten.t.default(view_default_574)
        mm_default_118 = torch.ops.aten.mm.default(t_default_212, _unsafe_view_default_78);  t_default_212 = _unsafe_view_default_78 = None
        t_default_213 = torch.ops.aten.t.default(mm_default_118);  mm_default_118 = None
        t_default_214 = torch.ops.aten.t.default(t_default_36);  t_default_36 = None
        mm_default_119 = torch.ops.aten.mm.default(view_default_574, t_default_214);  view_default_574 = t_default_214 = None
        view_default_575 = torch.ops.aten.view.default(mm_default_119, [1024, 2, 768]);  mm_default_119 = None
        add_tensor_124 = torch.ops.aten.add.Tensor(add_tensor_123, view_default_575);  add_tensor_123 = view_default_575 = None
        t_default_215 = torch.ops.aten.t.default(t_default_213);  t_default_213 = None
        transpose_int_269 = torch.ops.aten.transpose.int(add_tensor_124, 0, 1);  add_tensor_124 = None
        add_tensor_125 = torch.ops.aten.add.Tensor(getitem_105, transpose_int_269);  getitem_105 = transpose_int_269 = None
        native_layer_norm_backward_default_12 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_125, add_tensor_35, [768], getitem_34, getitem_35, primals_126, primals_125, [True, True, True]);  add_tensor_125 = add_tensor_35 = getitem_34 = getitem_35 = primals_126 = primals_125 = None
        getitem_108 = native_layer_norm_backward_default_12[0]
        getitem_109 = native_layer_norm_backward_default_12[1]
        getitem_110 = native_layer_norm_backward_default_12[2];  native_layer_norm_backward_default_12 = None
        view_default_576 = torch.ops.aten.view.default(getitem_108, [2048, 768])
        t_default_216 = torch.ops.aten.t.default(t_default_35);  t_default_35 = None
        mm_default_120 = torch.ops.aten.mm.default(view_default_576, t_default_216);  t_default_216 = None
        t_default_217 = torch.ops.aten.t.default(view_default_576)
        mm_default_121 = torch.ops.aten.mm.default(t_default_217, view_default_166);  t_default_217 = view_default_166 = None
        t_default_218 = torch.ops.aten.t.default(mm_default_121);  mm_default_121 = None
        sum_dim_int_list_36 = torch.ops.aten.sum.dim_IntList(view_default_576, [0], True);  view_default_576 = None
        view_default_577 = torch.ops.aten.view.default(sum_dim_int_list_36, [768]);  sum_dim_int_list_36 = None
        t_default_219 = torch.ops.aten.t.default(t_default_218);  t_default_218 = None
        view_default_578 = torch.ops.aten.view.default(mm_default_120, [2, 1024, 3072]);  mm_default_120 = None
        to_dtype_18 = torch.ops.aten.to.dtype(view_default_578, torch.float32);  view_default_578 = None
        to_dtype_19 = torch.ops.aten.to.dtype(view_default_165, torch.float32);  view_default_165 = None
        mul_tensor_54 = torch.ops.aten.mul.Tensor(to_dtype_19, 0.7071067811865476)
        erf_default_6 = torch.ops.aten.erf.default(mul_tensor_54);  mul_tensor_54 = None
        add_tensor_126 = torch.ops.aten.add.Tensor(erf_default_6, 1);  erf_default_6 = None
        mul_tensor_55 = torch.ops.aten.mul.Tensor(add_tensor_126, 0.5);  add_tensor_126 = None
        mul_tensor_56 = torch.ops.aten.mul.Tensor(to_dtype_19, to_dtype_19)
        mul_tensor_57 = torch.ops.aten.mul.Tensor(mul_tensor_56, -0.5);  mul_tensor_56 = None
        exp_default_6 = torch.ops.aten.exp.default(mul_tensor_57);  mul_tensor_57 = None
        mul_tensor_58 = torch.ops.aten.mul.Tensor(exp_default_6, 0.3989422804014327);  exp_default_6 = None
        mul_tensor_59 = torch.ops.aten.mul.Tensor(to_dtype_19, mul_tensor_58);  to_dtype_19 = mul_tensor_58 = None
        add_tensor_127 = torch.ops.aten.add.Tensor(mul_tensor_55, mul_tensor_59);  mul_tensor_55 = mul_tensor_59 = None
        mul_tensor_60 = torch.ops.aten.mul.Tensor(to_dtype_18, add_tensor_127);  to_dtype_18 = add_tensor_127 = None
        to_dtype_20 = torch.ops.aten.to.dtype(mul_tensor_60, torch.float32);  mul_tensor_60 = None
        view_default_579 = torch.ops.aten.view.default(to_dtype_20, [2048, 3072]);  to_dtype_20 = None
        t_default_220 = torch.ops.aten.t.default(t_default_34);  t_default_34 = None
        mm_default_122 = torch.ops.aten.mm.default(view_default_579, t_default_220);  t_default_220 = None
        t_default_221 = torch.ops.aten.t.default(view_default_579)
        mm_default_123 = torch.ops.aten.mm.default(t_default_221, view_default_164);  t_default_221 = view_default_164 = None
        t_default_222 = torch.ops.aten.t.default(mm_default_123);  mm_default_123 = None
        sum_dim_int_list_37 = torch.ops.aten.sum.dim_IntList(view_default_579, [0], True);  view_default_579 = None
        view_default_580 = torch.ops.aten.view.default(sum_dim_int_list_37, [3072]);  sum_dim_int_list_37 = None
        t_default_223 = torch.ops.aten.t.default(t_default_222);  t_default_222 = None
        view_default_581 = torch.ops.aten.view.default(mm_default_122, [2, 1024, 768]);  mm_default_122 = None
        add_tensor_128 = torch.ops.aten.add.Tensor(getitem_108, view_default_581);  getitem_108 = view_default_581 = None
        native_layer_norm_backward_default_13 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_128, add_tensor_34, [768], getitem_31, getitem_32, primals_114, primals_113, [True, True, True]);  add_tensor_128 = add_tensor_34 = getitem_31 = getitem_32 = primals_114 = primals_113 = None
        getitem_111 = native_layer_norm_backward_default_13[0]
        getitem_112 = native_layer_norm_backward_default_13[1]
        getitem_113 = native_layer_norm_backward_default_13[2];  native_layer_norm_backward_default_13 = None
        sum_dim_int_list_38 = torch.ops.aten.sum.dim_IntList(getitem_111, [0, 1], True)
        view_default_582 = torch.ops.aten.view.default(sum_dim_int_list_38, [768]);  sum_dim_int_list_38 = None
        view_default_583 = torch.ops.aten.view.default(getitem_111, [2048, 768])
        t_default_224 = torch.ops.aten.t.default(view_default_583)
        mm_default_124 = torch.ops.aten.mm.default(t_default_224, _unsafe_view_default_76);  t_default_224 = _unsafe_view_default_76 = None
        t_default_225 = torch.ops.aten.t.default(mm_default_124);  mm_default_124 = None
        t_default_226 = torch.ops.aten.t.default(t_default_33);  t_default_33 = None
        mm_default_125 = torch.ops.aten.mm.default(view_default_583, t_default_226);  view_default_583 = t_default_226 = None
        view_default_584 = torch.ops.aten.view.default(mm_default_125, [2, 1024, 768]);  mm_default_125 = None
        t_default_227 = torch.ops.aten.t.default(t_default_225);  t_default_225 = None
        transpose_int_270 = torch.ops.aten.transpose.int(view_default_584, 0, 1);  view_default_584 = None
        view_default_585 = torch.ops.aten.view.default(transpose_int_270, [1024, 2, 12, 64]);  transpose_int_270 = None
        transpose_int_271 = torch.ops.aten.transpose.int(view_default_585, 0, 1);  view_default_585 = None
        transpose_int_272 = torch.ops.aten.transpose.int(transpose_int_271, 1, 2);  transpose_int_271 = None
        clone_default_186 = torch.ops.aten.clone.default(transpose_int_272, memory_format = torch.contiguous_format);  transpose_int_272 = None
        _unsafe_view_default_192 = torch.ops.aten._unsafe_view.default(clone_default_186, [24, 4, 256, 64]);  clone_default_186 = None
        view_default_586 = torch.ops.aten.view.default(_unsafe_view_default_192, [24, 4, 256, 64, 1]);  _unsafe_view_default_192 = None
        permute_default_204 = torch.ops.aten.permute.default(view_default_586, [0, 1, 2, 4, 3]);  view_default_586 = None
        view_default_587 = torch.ops.aten.view.default(permute_default_204, [96, 256, 64]);  permute_default_204 = None
        transpose_int_273 = torch.ops.aten.transpose.int(view_default_160, 1, 2);  view_default_160 = None
        bmm_default_48 = torch.ops.aten.bmm.default(transpose_int_273, view_default_587);  transpose_int_273 = None
        transpose_int_274 = torch.ops.aten.transpose.int(_unsafe_view_default_74, 1, 2);  _unsafe_view_default_74 = None
        bmm_default_49 = torch.ops.aten.bmm.default(view_default_587, transpose_int_274);  view_default_587 = transpose_int_274 = None
        view_default_588 = torch.ops.aten.view.default(bmm_default_48, [24, 4, 768, 64, 1]);  bmm_default_48 = None
        permute_default_205 = torch.ops.aten.permute.default(view_default_588, [0, 1, 4, 3, 2]);  view_default_588 = None
        view_default_589 = torch.ops.aten.view.default(bmm_default_49, [24, 4, 256, 768, 1]);  bmm_default_49 = None
        permute_default_206 = torch.ops.aten.permute.default(view_default_589, [0, 1, 2, 4, 3]);  view_default_589 = None
        permute_default_207 = torch.ops.aten.permute.default(permute_default_205, [0, 1, 4, 3, 2]);  permute_default_205 = None
        squeeze_dim_48 = torch.ops.aten.squeeze.dim(permute_default_207, -1);  permute_default_207 = None
        permute_default_208 = torch.ops.aten.permute.default(permute_default_206, [0, 1, 2, 4, 3]);  permute_default_206 = None
        squeeze_dim_49 = torch.ops.aten.squeeze.dim(permute_default_208, -1);  permute_default_208 = None
        slice_backward_default_126 = torch.ops.aten.slice_backward.default(squeeze_dim_49, [24, 4, 256, 769], 3, 0, -1, 1);  squeeze_dim_49 = None
        slice_backward_default_127 = torch.ops.aten.slice_backward.default(slice_backward_default_126, [24, 4, 256, 769], 2, 0, 9223372036854775807, 1);  slice_backward_default_126 = None
        slice_backward_default_128 = torch.ops.aten.slice_backward.default(slice_backward_default_127, [24, 4, 256, 769], 1, 0, 9223372036854775807, 1);  slice_backward_default_127 = None
        slice_backward_default_129 = torch.ops.aten.slice_backward.default(slice_backward_default_128, [24, 4, 256, 769], 0, 0, 9223372036854775807, 1);  slice_backward_default_128 = None
        view_default_590 = torch.ops.aten.view.default(slice_backward_default_129, [24, 4, 196864]);  slice_backward_default_129 = None
        slice_backward_default_130 = torch.ops.aten.slice_backward.default(view_default_590, [24, 4, 197120], 2, 0, -256, 1);  view_default_590 = None
        slice_backward_default_131 = torch.ops.aten.slice_backward.default(slice_backward_default_130, [24, 4, 197120], 1, 0, 9223372036854775807, 1);  slice_backward_default_130 = None
        slice_backward_default_132 = torch.ops.aten.slice_backward.default(slice_backward_default_131, [24, 4, 197120], 0, 0, 9223372036854775807, 1);  slice_backward_default_131 = None
        view_default_591 = torch.ops.aten.view.default(slice_backward_default_132, [24, 4, 256, 770]);  slice_backward_default_132 = None
        constant_pad_nd_default_66 = torch.ops.aten.constant_pad_nd.default(view_default_591, [0, -257]);  view_default_591 = None
        new_empty_default_84 = torch.ops.aten.new_empty.default(squeeze_dim_48, [2359296])
        zero__default_42 = torch.ops.aten.zero_.default(new_empty_default_84);  new_empty_default_84 = None
        arange_18 = torch.ops.aten.arange.start(0, 2359296, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_150 = torch.ops.aten.as_strided.default(arange_18, [24, 4, 768, 64], [98304, 16384, 64, 1], 0);  arange_18 = None
        clone_default_187 = torch.ops.aten.clone.default(as_strided_default_150, memory_format = torch.contiguous_format);  as_strided_default_150 = None
        _unsafe_view_default_193 = torch.ops.aten._unsafe_view.default(clone_default_187, [4718592]);  clone_default_187 = None
        view_default_592 = torch.ops.aten.view.default(squeeze_dim_48, [4718592]);  squeeze_dim_48 = None
        index_add__default_18 = torch.ops.aten.index_add_.default(zero__default_42, 0, _unsafe_view_default_193, view_default_592);  zero__default_42 = _unsafe_view_default_193 = view_default_592 = None
        as_strided_default_151 = torch.ops.aten.as_strided.default(index_add__default_18, [24, 1536, 64], [98304, 64, 1], 0);  index_add__default_18 = None
        constant_pad_nd_default_67 = torch.ops.aten.constant_pad_nd.default(as_strided_default_151, [0, 0, -256, -256]);  as_strided_default_151 = None
        view_default_593 = torch.ops.aten.view.default(constant_pad_nd_default_67, [2, 12, 1024, 64]);  constant_pad_nd_default_67 = None
        transpose_int_275 = torch.ops.aten.transpose.int(view_default_593, 1, 2);  view_default_593 = None
        view_default_594 = torch.ops.aten.view.default(constant_pad_nd_default_66, [2, 12, 1024, 513]);  constant_pad_nd_default_66 = None
        transpose_int_276 = torch.ops.aten.transpose.int(view_default_594, 1, 2);  view_default_594 = None
        transpose_int_277 = torch.ops.aten.transpose.int(transpose_int_275, 0, 1);  transpose_int_275 = None
        clone_default_188 = torch.ops.aten.clone.default(transpose_int_277, memory_format = torch.contiguous_format);  transpose_int_277 = None
        _unsafe_view_default_194 = torch.ops.aten._unsafe_view.default(clone_default_188, [1024, 2, 768]);  clone_default_188 = None
        where_scalar_self_42 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_81, 0.0, transpose_int_276);  unsqueeze_default_81 = transpose_int_276 = None
        _softmax_backward_data_default_6 = torch.ops.aten._softmax_backward_data.default(where_scalar_self_42, _softmax_default_5, -1, torch.float32);  where_scalar_self_42 = _softmax_default_5 = None
        new_empty_default_85 = torch.ops.aten.new_empty.default(_softmax_backward_data_default_6, [12607488]);  _softmax_backward_data_default_6 = None
        zero__default_43 = torch.ops.aten.zero_.default(new_empty_default_85);  new_empty_default_85 = None
        as_strided_default_153 = torch.ops.aten.as_strided.default(zero__default_43, [24, 4, 256, 513], [525312, 131328, 513, 1], 0);  zero__default_43 = None
        new_empty_strided_default_42 = torch.ops.aten.new_empty_strided.default(as_strided_default_153, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_181 = torch.ops.aten.copy_.default(new_empty_strided_default_42, as_strided_default_153);  new_empty_strided_default_42 = as_strided_default_153 = None
        new_empty_strided_default_43 = torch.ops.aten.new_empty_strided.default(copy__default_181, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_183 = torch.ops.aten.copy_.default(new_empty_strided_default_43, copy__default_181);  new_empty_strided_default_43 = copy__default_181 = None
        new_empty_strided_default_44 = torch.ops.aten.new_empty_strided.default(copy__default_183, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_185 = torch.ops.aten.copy_.default(new_empty_strided_default_44, copy__default_183);  new_empty_strided_default_44 = copy__default_183 = None
        new_empty_strided_default_45 = torch.ops.aten.new_empty_strided.default(copy__default_185, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_187 = torch.ops.aten.copy_.default(new_empty_strided_default_45, copy__default_185);  new_empty_strided_default_45 = copy__default_185 = None
        as_strided_default_157 = torch.ops.aten.as_strided.default(copy__default_187, [24, 255, 255], [525312, 513, 1], 514)
        clone_default_192 = torch.ops.aten.clone.default(as_strided_default_157, memory_format = torch.contiguous_format);  as_strided_default_157 = None
        slice_backward_default_133 = torch.ops.aten.slice_backward.default(clone_default_192, [24, 255, 513], 2, -255, 9223372036854775807, 1);  clone_default_192 = None
        slice_backward_default_134 = torch.ops.aten.slice_backward.default(slice_backward_default_133, [24, 512, 513], 1, 0, 255, 1);  slice_backward_default_133 = None
        select_backward_default_12 = torch.ops.aten.select_backward.default(slice_backward_default_134, [24, 3, 512, 513], 1, 0);  slice_backward_default_134 = None
        slice_backward_default_135 = torch.ops.aten.slice_backward.default(select_backward_default_12, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_12 = None
        new_empty_strided_default_46 = torch.ops.aten.new_empty_strided.default(copy__default_187, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_189 = torch.ops.aten.copy_.default(new_empty_strided_default_46, copy__default_187);  new_empty_strided_default_46 = copy__default_187 = None
        as_strided_default_158 = torch.ops.aten.as_strided.default(copy__default_189, [24, 3, 256, 256], [525312, 131328, 513, 1], 131328)
        clone_default_193 = torch.ops.aten.clone.default(as_strided_default_158, memory_format = torch.contiguous_format);  as_strided_default_158 = None
        slice_backward_default_136 = torch.ops.aten.slice_backward.default(clone_default_193, [24, 3, 256, 513], 3, 257, 9223372036854775807, 1);  clone_default_193 = None
        slice_backward_default_137 = torch.ops.aten.slice_backward.default(slice_backward_default_136, [24, 3, 512, 513], 2, -257, -1, 1);  slice_backward_default_136 = None
        slice_backward_default_138 = torch.ops.aten.slice_backward.default(slice_backward_default_137, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_137 = None
        slice_backward_default_139 = torch.ops.aten.slice_backward.default(slice_backward_default_138, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_138 = None
        add_tensor_129 = torch.ops.aten.add.Tensor(slice_backward_default_135, slice_backward_default_139);  slice_backward_default_135 = slice_backward_default_139 = None
        new_empty_strided_default_47 = torch.ops.aten.new_empty_strided.default(copy__default_189, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_191 = torch.ops.aten.copy_.default(new_empty_strided_default_47, copy__default_189);  new_empty_strided_default_47 = copy__default_189 = None
        as_strided_default_159 = torch.ops.aten.as_strided.default(copy__default_191, [24, 256, 257], [525312, 513, 1], 394240)
        clone_default_194 = torch.ops.aten.clone.default(as_strided_default_159, memory_format = torch.contiguous_format);  as_strided_default_159 = None
        slice_backward_default_140 = torch.ops.aten.slice_backward.default(clone_default_194, [24, 256, 513], 2, 0, 257, 1);  clone_default_194 = None
        slice_backward_default_141 = torch.ops.aten.slice_backward.default(slice_backward_default_140, [24, 512, 513], 1, 256, 9223372036854775807, 1);  slice_backward_default_140 = None
        select_backward_default_13 = torch.ops.aten.select_backward.default(slice_backward_default_141, [24, 3, 512, 513], 1, -1);  slice_backward_default_141 = None
        slice_backward_default_142 = torch.ops.aten.slice_backward.default(select_backward_default_13, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_13 = None
        add_tensor_130 = torch.ops.aten.add.Tensor(add_tensor_129, slice_backward_default_142);  add_tensor_129 = slice_backward_default_142 = None
        new_empty_strided_default_48 = torch.ops.aten.new_empty_strided.default(copy__default_191, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_193 = torch.ops.aten.copy_.default(new_empty_strided_default_48, copy__default_191);  new_empty_strided_default_48 = copy__default_191 = None
        as_strided_default_160 = torch.ops.aten.as_strided.default(copy__default_193, [24, 3, 256, 257], [525312, 131328, 513, 1], 256);  copy__default_193 = None
        clone_default_195 = torch.ops.aten.clone.default(as_strided_default_160, memory_format = torch.contiguous_format);  as_strided_default_160 = None
        slice_backward_default_143 = torch.ops.aten.slice_backward.default(clone_default_195, [24, 3, 256, 513], 3, 0, 257, 1);  clone_default_195 = None
        slice_backward_default_144 = torch.ops.aten.slice_backward.default(slice_backward_default_143, [24, 3, 512, 513], 2, 0, 256, 1);  slice_backward_default_143 = None
        slice_backward_default_145 = torch.ops.aten.slice_backward.default(slice_backward_default_144, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_144 = None
        slice_backward_default_146 = torch.ops.aten.slice_backward.default(slice_backward_default_145, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_145 = None
        add_tensor_131 = torch.ops.aten.add.Tensor(add_tensor_130, slice_backward_default_146);  add_tensor_130 = slice_backward_default_146 = None
        view_default_595 = torch.ops.aten.view.default(add_tensor_131, [24, 3, 513, 512]);  add_tensor_131 = None
        constant_pad_nd_default_68 = torch.ops.aten.constant_pad_nd.default(view_default_595, [0, 0, 0, -1]);  view_default_595 = None
        view_default_596 = torch.ops.aten.view.default(constant_pad_nd_default_68, [24, 3, 512, 512, 1]);  constant_pad_nd_default_68 = None
        permute_default_209 = torch.ops.aten.permute.default(view_default_596, [0, 1, 2, 4, 3]);  view_default_596 = None
        view_default_597 = torch.ops.aten.view.default(permute_default_209, [72, 512, 512]);  permute_default_209 = None
        transpose_int_278 = torch.ops.aten.transpose.int(_unsafe_view_default_71, 1, 2);  _unsafe_view_default_71 = None
        bmm_default_50 = torch.ops.aten.bmm.default(transpose_int_278, view_default_597);  transpose_int_278 = None
        transpose_int_279 = torch.ops.aten.transpose.int(_unsafe_view_default_72, 1, 2);  _unsafe_view_default_72 = None
        bmm_default_51 = torch.ops.aten.bmm.default(view_default_597, transpose_int_279);  view_default_597 = transpose_int_279 = None
        view_default_598 = torch.ops.aten.view.default(bmm_default_50, [24, 3, 64, 512, 1]);  bmm_default_50 = None
        permute_default_210 = torch.ops.aten.permute.default(view_default_598, [0, 1, 4, 3, 2]);  view_default_598 = None
        view_default_599 = torch.ops.aten.view.default(bmm_default_51, [24, 3, 512, 64, 1]);  bmm_default_51 = None
        permute_default_211 = torch.ops.aten.permute.default(view_default_599, [0, 1, 2, 4, 3]);  view_default_599 = None
        permute_default_212 = torch.ops.aten.permute.default(permute_default_210, [0, 1, 3, 4, 2]);  permute_default_210 = None
        squeeze_dim_50 = torch.ops.aten.squeeze.dim(permute_default_212, -1);  permute_default_212 = None
        permute_default_213 = torch.ops.aten.permute.default(permute_default_211, [0, 1, 2, 4, 3]);  permute_default_211 = None
        squeeze_dim_51 = torch.ops.aten.squeeze.dim(permute_default_213, -1);  permute_default_213 = None
        new_empty_default_86 = torch.ops.aten.new_empty.default(squeeze_dim_50, [1572864])
        zero__default_47 = torch.ops.aten.zero_.default(new_empty_default_86);  new_empty_default_86 = None
        arange_19 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_161 = torch.ops.aten.as_strided.default(arange_19, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_19 = None
        clone_default_196 = torch.ops.aten.clone.default(as_strided_default_161, memory_format = torch.contiguous_format);  as_strided_default_161 = None
        _unsafe_view_default_195 = torch.ops.aten._unsafe_view.default(clone_default_196, [2359296]);  clone_default_196 = None
        clone_default_197 = torch.ops.aten.clone.default(squeeze_dim_50, memory_format = torch.contiguous_format);  squeeze_dim_50 = None
        _unsafe_view_default_196 = torch.ops.aten._unsafe_view.default(clone_default_197, [2359296]);  clone_default_197 = None
        index_add__default_19 = torch.ops.aten.index_add_.default(zero__default_47, 0, _unsafe_view_default_195, _unsafe_view_default_196);  zero__default_47 = _unsafe_view_default_195 = _unsafe_view_default_196 = None
        as_strided_default_162 = torch.ops.aten.as_strided.default(index_add__default_19, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_19 = None
        view_default_600 = torch.ops.aten.view.default(as_strided_default_162, [24, 1024, 64]);  as_strided_default_162 = None
        new_empty_default_87 = torch.ops.aten.new_empty.default(squeeze_dim_51, [1572864])
        zero__default_48 = torch.ops.aten.zero_.default(new_empty_default_87);  new_empty_default_87 = None
        arange_20 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_163 = torch.ops.aten.as_strided.default(arange_20, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_20 = None
        clone_default_198 = torch.ops.aten.clone.default(as_strided_default_163, memory_format = torch.contiguous_format);  as_strided_default_163 = None
        _unsafe_view_default_197 = torch.ops.aten._unsafe_view.default(clone_default_198, [2359296]);  clone_default_198 = None
        view_default_601 = torch.ops.aten.view.default(squeeze_dim_51, [2359296]);  squeeze_dim_51 = None
        index_add__default_20 = torch.ops.aten.index_add_.default(zero__default_48, 0, _unsafe_view_default_197, view_default_601);  zero__default_48 = _unsafe_view_default_197 = view_default_601 = None
        as_strided_default_164 = torch.ops.aten.as_strided.default(index_add__default_20, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_20 = None
        view_default_602 = torch.ops.aten.view.default(as_strided_default_164, [24, 1024, 64]);  as_strided_default_164 = None
        view_default_603 = torch.ops.aten.view.default(view_default_600, [2, 12, 1024, 64]);  view_default_600 = None
        transpose_int_280 = torch.ops.aten.transpose.int(view_default_603, 1, 2);  view_default_603 = None
        view_default_604 = torch.ops.aten.view.default(view_default_602, [2, 12, 1024, 64]);  view_default_602 = None
        transpose_int_281 = torch.ops.aten.transpose.int(view_default_604, 1, 2);  view_default_604 = None
        transpose_int_282 = torch.ops.aten.transpose.int(transpose_int_280, 0, 1);  transpose_int_280 = None
        view_default_605 = torch.ops.aten.view.default(transpose_int_282, [1024, 2, 768]);  transpose_int_282 = None
        transpose_int_283 = torch.ops.aten.transpose.int(transpose_int_281, 0, 1);  transpose_int_281 = None
        view_default_606 = torch.ops.aten.view.default(transpose_int_283, [1024, 2, 768]);  transpose_int_283 = None
        div_tensor_6 = torch.ops.aten.div.Tensor(view_default_606, 8.0);  view_default_606 = None
        sum_dim_int_list_39 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_194, [0, 1], True)
        view_default_607 = torch.ops.aten.view.default(sum_dim_int_list_39, [768]);  sum_dim_int_list_39 = None
        view_default_608 = torch.ops.aten.view.default(_unsafe_view_default_194, [2048, 768]);  _unsafe_view_default_194 = None
        t_default_228 = torch.ops.aten.t.default(view_default_608)
        mm_default_126 = torch.ops.aten.mm.default(t_default_228, _unsafe_view_default_69);  t_default_228 = _unsafe_view_default_69 = None
        t_default_229 = torch.ops.aten.t.default(mm_default_126);  mm_default_126 = None
        t_default_230 = torch.ops.aten.t.default(t_default_32);  t_default_32 = None
        mm_default_127 = torch.ops.aten.mm.default(view_default_608, t_default_230);  view_default_608 = t_default_230 = None
        view_default_609 = torch.ops.aten.view.default(mm_default_127, [1024, 2, 768]);  mm_default_127 = None
        t_default_231 = torch.ops.aten.t.default(t_default_229);  t_default_229 = None
        sum_dim_int_list_40 = torch.ops.aten.sum.dim_IntList(view_default_605, [0, 1], True)
        view_default_610 = torch.ops.aten.view.default(sum_dim_int_list_40, [768]);  sum_dim_int_list_40 = None
        view_default_611 = torch.ops.aten.view.default(view_default_605, [2048, 768]);  view_default_605 = None
        t_default_232 = torch.ops.aten.t.default(view_default_611)
        mm_default_128 = torch.ops.aten.mm.default(t_default_232, _unsafe_view_default_67);  t_default_232 = _unsafe_view_default_67 = None
        t_default_233 = torch.ops.aten.t.default(mm_default_128);  mm_default_128 = None
        t_default_234 = torch.ops.aten.t.default(t_default_31);  t_default_31 = None
        mm_default_129 = torch.ops.aten.mm.default(view_default_611, t_default_234);  view_default_611 = t_default_234 = None
        view_default_612 = torch.ops.aten.view.default(mm_default_129, [1024, 2, 768]);  mm_default_129 = None
        add_tensor_132 = torch.ops.aten.add.Tensor(view_default_609, view_default_612);  view_default_609 = view_default_612 = None
        t_default_235 = torch.ops.aten.t.default(t_default_233);  t_default_233 = None
        sum_dim_int_list_41 = torch.ops.aten.sum.dim_IntList(div_tensor_6, [0, 1], True)
        view_default_613 = torch.ops.aten.view.default(sum_dim_int_list_41, [768]);  sum_dim_int_list_41 = None
        view_default_614 = torch.ops.aten.view.default(div_tensor_6, [2048, 768]);  div_tensor_6 = None
        t_default_236 = torch.ops.aten.t.default(view_default_614)
        mm_default_130 = torch.ops.aten.mm.default(t_default_236, _unsafe_view_default_65);  t_default_236 = _unsafe_view_default_65 = None
        t_default_237 = torch.ops.aten.t.default(mm_default_130);  mm_default_130 = None
        t_default_238 = torch.ops.aten.t.default(t_default_30);  t_default_30 = None
        mm_default_131 = torch.ops.aten.mm.default(view_default_614, t_default_238);  view_default_614 = t_default_238 = None
        view_default_615 = torch.ops.aten.view.default(mm_default_131, [1024, 2, 768]);  mm_default_131 = None
        add_tensor_133 = torch.ops.aten.add.Tensor(add_tensor_132, view_default_615);  add_tensor_132 = view_default_615 = None
        t_default_239 = torch.ops.aten.t.default(t_default_237);  t_default_237 = None
        transpose_int_284 = torch.ops.aten.transpose.int(add_tensor_133, 0, 1);  add_tensor_133 = None
        add_tensor_134 = torch.ops.aten.add.Tensor(getitem_111, transpose_int_284);  getitem_111 = transpose_int_284 = None
        native_layer_norm_backward_default_14 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_134, add_tensor_29, [768], getitem_28, getitem_29, primals_110, primals_109, [True, True, True]);  add_tensor_134 = add_tensor_29 = getitem_28 = getitem_29 = primals_110 = primals_109 = None
        getitem_114 = native_layer_norm_backward_default_14[0]
        getitem_115 = native_layer_norm_backward_default_14[1]
        getitem_116 = native_layer_norm_backward_default_14[2];  native_layer_norm_backward_default_14 = None
        view_default_616 = torch.ops.aten.view.default(getitem_114, [2048, 768])
        t_default_240 = torch.ops.aten.t.default(t_default_29);  t_default_29 = None
        mm_default_132 = torch.ops.aten.mm.default(view_default_616, t_default_240);  t_default_240 = None
        t_default_241 = torch.ops.aten.t.default(view_default_616)
        mm_default_133 = torch.ops.aten.mm.default(t_default_241, view_default_138);  t_default_241 = view_default_138 = None
        t_default_242 = torch.ops.aten.t.default(mm_default_133);  mm_default_133 = None
        sum_dim_int_list_42 = torch.ops.aten.sum.dim_IntList(view_default_616, [0], True);  view_default_616 = None
        view_default_617 = torch.ops.aten.view.default(sum_dim_int_list_42, [768]);  sum_dim_int_list_42 = None
        t_default_243 = torch.ops.aten.t.default(t_default_242);  t_default_242 = None
        view_default_618 = torch.ops.aten.view.default(mm_default_132, [2, 1024, 3072]);  mm_default_132 = None
        to_dtype_21 = torch.ops.aten.to.dtype(view_default_618, torch.float32);  view_default_618 = None
        to_dtype_22 = torch.ops.aten.to.dtype(view_default_137, torch.float32);  view_default_137 = None
        mul_tensor_61 = torch.ops.aten.mul.Tensor(to_dtype_22, 0.7071067811865476)
        erf_default_7 = torch.ops.aten.erf.default(mul_tensor_61);  mul_tensor_61 = None
        add_tensor_135 = torch.ops.aten.add.Tensor(erf_default_7, 1);  erf_default_7 = None
        mul_tensor_62 = torch.ops.aten.mul.Tensor(add_tensor_135, 0.5);  add_tensor_135 = None
        mul_tensor_63 = torch.ops.aten.mul.Tensor(to_dtype_22, to_dtype_22)
        mul_tensor_64 = torch.ops.aten.mul.Tensor(mul_tensor_63, -0.5);  mul_tensor_63 = None
        exp_default_7 = torch.ops.aten.exp.default(mul_tensor_64);  mul_tensor_64 = None
        mul_tensor_65 = torch.ops.aten.mul.Tensor(exp_default_7, 0.3989422804014327);  exp_default_7 = None
        mul_tensor_66 = torch.ops.aten.mul.Tensor(to_dtype_22, mul_tensor_65);  to_dtype_22 = mul_tensor_65 = None
        add_tensor_136 = torch.ops.aten.add.Tensor(mul_tensor_62, mul_tensor_66);  mul_tensor_62 = mul_tensor_66 = None
        mul_tensor_67 = torch.ops.aten.mul.Tensor(to_dtype_21, add_tensor_136);  to_dtype_21 = add_tensor_136 = None
        to_dtype_23 = torch.ops.aten.to.dtype(mul_tensor_67, torch.float32);  mul_tensor_67 = None
        view_default_619 = torch.ops.aten.view.default(to_dtype_23, [2048, 3072]);  to_dtype_23 = None
        t_default_244 = torch.ops.aten.t.default(t_default_28);  t_default_28 = None
        mm_default_134 = torch.ops.aten.mm.default(view_default_619, t_default_244);  t_default_244 = None
        t_default_245 = torch.ops.aten.t.default(view_default_619)
        mm_default_135 = torch.ops.aten.mm.default(t_default_245, view_default_136);  t_default_245 = view_default_136 = None
        t_default_246 = torch.ops.aten.t.default(mm_default_135);  mm_default_135 = None
        sum_dim_int_list_43 = torch.ops.aten.sum.dim_IntList(view_default_619, [0], True);  view_default_619 = None
        view_default_620 = torch.ops.aten.view.default(sum_dim_int_list_43, [3072]);  sum_dim_int_list_43 = None
        t_default_247 = torch.ops.aten.t.default(t_default_246);  t_default_246 = None
        view_default_621 = torch.ops.aten.view.default(mm_default_134, [2, 1024, 768]);  mm_default_134 = None
        add_tensor_137 = torch.ops.aten.add.Tensor(getitem_114, view_default_621);  getitem_114 = view_default_621 = None
        native_layer_norm_backward_default_15 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_137, add_tensor_28, [768], getitem_25, getitem_26, primals_98, primals_97, [True, True, True]);  add_tensor_137 = add_tensor_28 = getitem_25 = getitem_26 = primals_98 = primals_97 = None
        getitem_117 = native_layer_norm_backward_default_15[0]
        getitem_118 = native_layer_norm_backward_default_15[1]
        getitem_119 = native_layer_norm_backward_default_15[2];  native_layer_norm_backward_default_15 = None
        sum_dim_int_list_44 = torch.ops.aten.sum.dim_IntList(getitem_117, [0, 1], True)
        view_default_622 = torch.ops.aten.view.default(sum_dim_int_list_44, [768]);  sum_dim_int_list_44 = None
        view_default_623 = torch.ops.aten.view.default(getitem_117, [2048, 768])
        t_default_248 = torch.ops.aten.t.default(view_default_623)
        mm_default_136 = torch.ops.aten.mm.default(t_default_248, _unsafe_view_default_63);  t_default_248 = _unsafe_view_default_63 = None
        t_default_249 = torch.ops.aten.t.default(mm_default_136);  mm_default_136 = None
        t_default_250 = torch.ops.aten.t.default(t_default_27);  t_default_27 = None
        mm_default_137 = torch.ops.aten.mm.default(view_default_623, t_default_250);  view_default_623 = t_default_250 = None
        view_default_624 = torch.ops.aten.view.default(mm_default_137, [2, 1024, 768]);  mm_default_137 = None
        t_default_251 = torch.ops.aten.t.default(t_default_249);  t_default_249 = None
        transpose_int_285 = torch.ops.aten.transpose.int(view_default_624, 0, 1);  view_default_624 = None
        view_default_625 = torch.ops.aten.view.default(transpose_int_285, [1024, 2, 12, 64]);  transpose_int_285 = None
        transpose_int_286 = torch.ops.aten.transpose.int(view_default_625, 0, 1);  view_default_625 = None
        transpose_int_287 = torch.ops.aten.transpose.int(transpose_int_286, 1, 2);  transpose_int_286 = None
        clone_default_199 = torch.ops.aten.clone.default(transpose_int_287, memory_format = torch.contiguous_format);  transpose_int_287 = None
        _unsafe_view_default_198 = torch.ops.aten._unsafe_view.default(clone_default_199, [24, 4, 256, 64]);  clone_default_199 = None
        view_default_626 = torch.ops.aten.view.default(_unsafe_view_default_198, [24, 4, 256, 64, 1]);  _unsafe_view_default_198 = None
        permute_default_214 = torch.ops.aten.permute.default(view_default_626, [0, 1, 2, 4, 3]);  view_default_626 = None
        view_default_627 = torch.ops.aten.view.default(permute_default_214, [96, 256, 64]);  permute_default_214 = None
        transpose_int_288 = torch.ops.aten.transpose.int(view_default_132, 1, 2);  view_default_132 = None
        bmm_default_52 = torch.ops.aten.bmm.default(transpose_int_288, view_default_627);  transpose_int_288 = None
        transpose_int_289 = torch.ops.aten.transpose.int(_unsafe_view_default_61, 1, 2);  _unsafe_view_default_61 = None
        bmm_default_53 = torch.ops.aten.bmm.default(view_default_627, transpose_int_289);  view_default_627 = transpose_int_289 = None
        view_default_628 = torch.ops.aten.view.default(bmm_default_52, [24, 4, 768, 64, 1]);  bmm_default_52 = None
        permute_default_215 = torch.ops.aten.permute.default(view_default_628, [0, 1, 4, 3, 2]);  view_default_628 = None
        view_default_629 = torch.ops.aten.view.default(bmm_default_53, [24, 4, 256, 768, 1]);  bmm_default_53 = None
        permute_default_216 = torch.ops.aten.permute.default(view_default_629, [0, 1, 2, 4, 3]);  view_default_629 = None
        permute_default_217 = torch.ops.aten.permute.default(permute_default_215, [0, 1, 4, 3, 2]);  permute_default_215 = None
        squeeze_dim_52 = torch.ops.aten.squeeze.dim(permute_default_217, -1);  permute_default_217 = None
        permute_default_218 = torch.ops.aten.permute.default(permute_default_216, [0, 1, 2, 4, 3]);  permute_default_216 = None
        squeeze_dim_53 = torch.ops.aten.squeeze.dim(permute_default_218, -1);  permute_default_218 = None
        slice_backward_default_147 = torch.ops.aten.slice_backward.default(squeeze_dim_53, [24, 4, 256, 769], 3, 0, -1, 1);  squeeze_dim_53 = None
        slice_backward_default_148 = torch.ops.aten.slice_backward.default(slice_backward_default_147, [24, 4, 256, 769], 2, 0, 9223372036854775807, 1);  slice_backward_default_147 = None
        slice_backward_default_149 = torch.ops.aten.slice_backward.default(slice_backward_default_148, [24, 4, 256, 769], 1, 0, 9223372036854775807, 1);  slice_backward_default_148 = None
        slice_backward_default_150 = torch.ops.aten.slice_backward.default(slice_backward_default_149, [24, 4, 256, 769], 0, 0, 9223372036854775807, 1);  slice_backward_default_149 = None
        view_default_630 = torch.ops.aten.view.default(slice_backward_default_150, [24, 4, 196864]);  slice_backward_default_150 = None
        slice_backward_default_151 = torch.ops.aten.slice_backward.default(view_default_630, [24, 4, 197120], 2, 0, -256, 1);  view_default_630 = None
        slice_backward_default_152 = torch.ops.aten.slice_backward.default(slice_backward_default_151, [24, 4, 197120], 1, 0, 9223372036854775807, 1);  slice_backward_default_151 = None
        slice_backward_default_153 = torch.ops.aten.slice_backward.default(slice_backward_default_152, [24, 4, 197120], 0, 0, 9223372036854775807, 1);  slice_backward_default_152 = None
        view_default_631 = torch.ops.aten.view.default(slice_backward_default_153, [24, 4, 256, 770]);  slice_backward_default_153 = None
        constant_pad_nd_default_69 = torch.ops.aten.constant_pad_nd.default(view_default_631, [0, -257]);  view_default_631 = None
        new_empty_default_88 = torch.ops.aten.new_empty.default(squeeze_dim_52, [2359296])
        zero__default_49 = torch.ops.aten.zero_.default(new_empty_default_88);  new_empty_default_88 = None
        arange_21 = torch.ops.aten.arange.start(0, 2359296, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_165 = torch.ops.aten.as_strided.default(arange_21, [24, 4, 768, 64], [98304, 16384, 64, 1], 0);  arange_21 = None
        clone_default_200 = torch.ops.aten.clone.default(as_strided_default_165, memory_format = torch.contiguous_format);  as_strided_default_165 = None
        _unsafe_view_default_199 = torch.ops.aten._unsafe_view.default(clone_default_200, [4718592]);  clone_default_200 = None
        view_default_632 = torch.ops.aten.view.default(squeeze_dim_52, [4718592]);  squeeze_dim_52 = None
        index_add__default_21 = torch.ops.aten.index_add_.default(zero__default_49, 0, _unsafe_view_default_199, view_default_632);  zero__default_49 = _unsafe_view_default_199 = view_default_632 = None
        as_strided_default_166 = torch.ops.aten.as_strided.default(index_add__default_21, [24, 1536, 64], [98304, 64, 1], 0);  index_add__default_21 = None
        constant_pad_nd_default_70 = torch.ops.aten.constant_pad_nd.default(as_strided_default_166, [0, 0, -256, -256]);  as_strided_default_166 = None
        view_default_633 = torch.ops.aten.view.default(constant_pad_nd_default_70, [2, 12, 1024, 64]);  constant_pad_nd_default_70 = None
        transpose_int_290 = torch.ops.aten.transpose.int(view_default_633, 1, 2);  view_default_633 = None
        view_default_634 = torch.ops.aten.view.default(constant_pad_nd_default_69, [2, 12, 1024, 513]);  constant_pad_nd_default_69 = None
        transpose_int_291 = torch.ops.aten.transpose.int(view_default_634, 1, 2);  view_default_634 = None
        transpose_int_292 = torch.ops.aten.transpose.int(transpose_int_290, 0, 1);  transpose_int_290 = None
        clone_default_201 = torch.ops.aten.clone.default(transpose_int_292, memory_format = torch.contiguous_format);  transpose_int_292 = None
        _unsafe_view_default_200 = torch.ops.aten._unsafe_view.default(clone_default_201, [1024, 2, 768]);  clone_default_201 = None
        where_scalar_self_45 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_67, 0.0, transpose_int_291);  unsqueeze_default_67 = transpose_int_291 = None
        _softmax_backward_data_default_7 = torch.ops.aten._softmax_backward_data.default(where_scalar_self_45, _softmax_default_4, -1, torch.float32);  where_scalar_self_45 = _softmax_default_4 = None
        new_empty_default_89 = torch.ops.aten.new_empty.default(_softmax_backward_data_default_7, [12607488]);  _softmax_backward_data_default_7 = None
        zero__default_50 = torch.ops.aten.zero_.default(new_empty_default_89);  new_empty_default_89 = None
        as_strided_default_168 = torch.ops.aten.as_strided.default(zero__default_50, [24, 4, 256, 513], [525312, 131328, 513, 1], 0);  zero__default_50 = None
        new_empty_strided_default_49 = torch.ops.aten.new_empty_strided.default(as_strided_default_168, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_195 = torch.ops.aten.copy_.default(new_empty_strided_default_49, as_strided_default_168);  new_empty_strided_default_49 = as_strided_default_168 = None
        new_empty_strided_default_50 = torch.ops.aten.new_empty_strided.default(copy__default_195, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_197 = torch.ops.aten.copy_.default(new_empty_strided_default_50, copy__default_195);  new_empty_strided_default_50 = copy__default_195 = None
        new_empty_strided_default_51 = torch.ops.aten.new_empty_strided.default(copy__default_197, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_199 = torch.ops.aten.copy_.default(new_empty_strided_default_51, copy__default_197);  new_empty_strided_default_51 = copy__default_197 = None
        new_empty_strided_default_52 = torch.ops.aten.new_empty_strided.default(copy__default_199, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_201 = torch.ops.aten.copy_.default(new_empty_strided_default_52, copy__default_199);  new_empty_strided_default_52 = copy__default_199 = None
        as_strided_default_172 = torch.ops.aten.as_strided.default(copy__default_201, [24, 255, 255], [525312, 513, 1], 514)
        clone_default_205 = torch.ops.aten.clone.default(as_strided_default_172, memory_format = torch.contiguous_format);  as_strided_default_172 = None
        slice_backward_default_154 = torch.ops.aten.slice_backward.default(clone_default_205, [24, 255, 513], 2, -255, 9223372036854775807, 1);  clone_default_205 = None
        slice_backward_default_155 = torch.ops.aten.slice_backward.default(slice_backward_default_154, [24, 512, 513], 1, 0, 255, 1);  slice_backward_default_154 = None
        select_backward_default_14 = torch.ops.aten.select_backward.default(slice_backward_default_155, [24, 3, 512, 513], 1, 0);  slice_backward_default_155 = None
        slice_backward_default_156 = torch.ops.aten.slice_backward.default(select_backward_default_14, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_14 = None
        new_empty_strided_default_53 = torch.ops.aten.new_empty_strided.default(copy__default_201, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_203 = torch.ops.aten.copy_.default(new_empty_strided_default_53, copy__default_201);  new_empty_strided_default_53 = copy__default_201 = None
        as_strided_default_173 = torch.ops.aten.as_strided.default(copy__default_203, [24, 3, 256, 256], [525312, 131328, 513, 1], 131328)
        clone_default_206 = torch.ops.aten.clone.default(as_strided_default_173, memory_format = torch.contiguous_format);  as_strided_default_173 = None
        slice_backward_default_157 = torch.ops.aten.slice_backward.default(clone_default_206, [24, 3, 256, 513], 3, 257, 9223372036854775807, 1);  clone_default_206 = None
        slice_backward_default_158 = torch.ops.aten.slice_backward.default(slice_backward_default_157, [24, 3, 512, 513], 2, -257, -1, 1);  slice_backward_default_157 = None
        slice_backward_default_159 = torch.ops.aten.slice_backward.default(slice_backward_default_158, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_158 = None
        slice_backward_default_160 = torch.ops.aten.slice_backward.default(slice_backward_default_159, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_159 = None
        add_tensor_138 = torch.ops.aten.add.Tensor(slice_backward_default_156, slice_backward_default_160);  slice_backward_default_156 = slice_backward_default_160 = None
        new_empty_strided_default_54 = torch.ops.aten.new_empty_strided.default(copy__default_203, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_205 = torch.ops.aten.copy_.default(new_empty_strided_default_54, copy__default_203);  new_empty_strided_default_54 = copy__default_203 = None
        as_strided_default_174 = torch.ops.aten.as_strided.default(copy__default_205, [24, 256, 257], [525312, 513, 1], 394240)
        clone_default_207 = torch.ops.aten.clone.default(as_strided_default_174, memory_format = torch.contiguous_format);  as_strided_default_174 = None
        slice_backward_default_161 = torch.ops.aten.slice_backward.default(clone_default_207, [24, 256, 513], 2, 0, 257, 1);  clone_default_207 = None
        slice_backward_default_162 = torch.ops.aten.slice_backward.default(slice_backward_default_161, [24, 512, 513], 1, 256, 9223372036854775807, 1);  slice_backward_default_161 = None
        select_backward_default_15 = torch.ops.aten.select_backward.default(slice_backward_default_162, [24, 3, 512, 513], 1, -1);  slice_backward_default_162 = None
        slice_backward_default_163 = torch.ops.aten.slice_backward.default(select_backward_default_15, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_15 = None
        add_tensor_139 = torch.ops.aten.add.Tensor(add_tensor_138, slice_backward_default_163);  add_tensor_138 = slice_backward_default_163 = None
        new_empty_strided_default_55 = torch.ops.aten.new_empty_strided.default(copy__default_205, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_207 = torch.ops.aten.copy_.default(new_empty_strided_default_55, copy__default_205);  new_empty_strided_default_55 = copy__default_205 = None
        as_strided_default_175 = torch.ops.aten.as_strided.default(copy__default_207, [24, 3, 256, 257], [525312, 131328, 513, 1], 256);  copy__default_207 = None
        clone_default_208 = torch.ops.aten.clone.default(as_strided_default_175, memory_format = torch.contiguous_format);  as_strided_default_175 = None
        slice_backward_default_164 = torch.ops.aten.slice_backward.default(clone_default_208, [24, 3, 256, 513], 3, 0, 257, 1);  clone_default_208 = None
        slice_backward_default_165 = torch.ops.aten.slice_backward.default(slice_backward_default_164, [24, 3, 512, 513], 2, 0, 256, 1);  slice_backward_default_164 = None
        slice_backward_default_166 = torch.ops.aten.slice_backward.default(slice_backward_default_165, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_165 = None
        slice_backward_default_167 = torch.ops.aten.slice_backward.default(slice_backward_default_166, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_166 = None
        add_tensor_140 = torch.ops.aten.add.Tensor(add_tensor_139, slice_backward_default_167);  add_tensor_139 = slice_backward_default_167 = None
        view_default_635 = torch.ops.aten.view.default(add_tensor_140, [24, 3, 513, 512]);  add_tensor_140 = None
        constant_pad_nd_default_71 = torch.ops.aten.constant_pad_nd.default(view_default_635, [0, 0, 0, -1]);  view_default_635 = None
        view_default_636 = torch.ops.aten.view.default(constant_pad_nd_default_71, [24, 3, 512, 512, 1]);  constant_pad_nd_default_71 = None
        permute_default_219 = torch.ops.aten.permute.default(view_default_636, [0, 1, 2, 4, 3]);  view_default_636 = None
        view_default_637 = torch.ops.aten.view.default(permute_default_219, [72, 512, 512]);  permute_default_219 = None
        transpose_int_293 = torch.ops.aten.transpose.int(_unsafe_view_default_58, 1, 2);  _unsafe_view_default_58 = None
        bmm_default_54 = torch.ops.aten.bmm.default(transpose_int_293, view_default_637);  transpose_int_293 = None
        transpose_int_294 = torch.ops.aten.transpose.int(_unsafe_view_default_59, 1, 2);  _unsafe_view_default_59 = None
        bmm_default_55 = torch.ops.aten.bmm.default(view_default_637, transpose_int_294);  view_default_637 = transpose_int_294 = None
        view_default_638 = torch.ops.aten.view.default(bmm_default_54, [24, 3, 64, 512, 1]);  bmm_default_54 = None
        permute_default_220 = torch.ops.aten.permute.default(view_default_638, [0, 1, 4, 3, 2]);  view_default_638 = None
        view_default_639 = torch.ops.aten.view.default(bmm_default_55, [24, 3, 512, 64, 1]);  bmm_default_55 = None
        permute_default_221 = torch.ops.aten.permute.default(view_default_639, [0, 1, 2, 4, 3]);  view_default_639 = None
        permute_default_222 = torch.ops.aten.permute.default(permute_default_220, [0, 1, 3, 4, 2]);  permute_default_220 = None
        squeeze_dim_54 = torch.ops.aten.squeeze.dim(permute_default_222, -1);  permute_default_222 = None
        permute_default_223 = torch.ops.aten.permute.default(permute_default_221, [0, 1, 2, 4, 3]);  permute_default_221 = None
        squeeze_dim_55 = torch.ops.aten.squeeze.dim(permute_default_223, -1);  permute_default_223 = None
        new_empty_default_90 = torch.ops.aten.new_empty.default(squeeze_dim_54, [1572864])
        zero__default_54 = torch.ops.aten.zero_.default(new_empty_default_90);  new_empty_default_90 = None
        arange_22 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_176 = torch.ops.aten.as_strided.default(arange_22, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_22 = None
        clone_default_209 = torch.ops.aten.clone.default(as_strided_default_176, memory_format = torch.contiguous_format);  as_strided_default_176 = None
        _unsafe_view_default_201 = torch.ops.aten._unsafe_view.default(clone_default_209, [2359296]);  clone_default_209 = None
        clone_default_210 = torch.ops.aten.clone.default(squeeze_dim_54, memory_format = torch.contiguous_format);  squeeze_dim_54 = None
        _unsafe_view_default_202 = torch.ops.aten._unsafe_view.default(clone_default_210, [2359296]);  clone_default_210 = None
        index_add__default_22 = torch.ops.aten.index_add_.default(zero__default_54, 0, _unsafe_view_default_201, _unsafe_view_default_202);  zero__default_54 = _unsafe_view_default_201 = _unsafe_view_default_202 = None
        as_strided_default_177 = torch.ops.aten.as_strided.default(index_add__default_22, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_22 = None
        view_default_640 = torch.ops.aten.view.default(as_strided_default_177, [24, 1024, 64]);  as_strided_default_177 = None
        new_empty_default_91 = torch.ops.aten.new_empty.default(squeeze_dim_55, [1572864])
        zero__default_55 = torch.ops.aten.zero_.default(new_empty_default_91);  new_empty_default_91 = None
        arange_23 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_178 = torch.ops.aten.as_strided.default(arange_23, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_23 = None
        clone_default_211 = torch.ops.aten.clone.default(as_strided_default_178, memory_format = torch.contiguous_format);  as_strided_default_178 = None
        _unsafe_view_default_203 = torch.ops.aten._unsafe_view.default(clone_default_211, [2359296]);  clone_default_211 = None
        view_default_641 = torch.ops.aten.view.default(squeeze_dim_55, [2359296]);  squeeze_dim_55 = None
        index_add__default_23 = torch.ops.aten.index_add_.default(zero__default_55, 0, _unsafe_view_default_203, view_default_641);  zero__default_55 = _unsafe_view_default_203 = view_default_641 = None
        as_strided_default_179 = torch.ops.aten.as_strided.default(index_add__default_23, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_23 = None
        view_default_642 = torch.ops.aten.view.default(as_strided_default_179, [24, 1024, 64]);  as_strided_default_179 = None
        view_default_643 = torch.ops.aten.view.default(view_default_640, [2, 12, 1024, 64]);  view_default_640 = None
        transpose_int_295 = torch.ops.aten.transpose.int(view_default_643, 1, 2);  view_default_643 = None
        view_default_644 = torch.ops.aten.view.default(view_default_642, [2, 12, 1024, 64]);  view_default_642 = None
        transpose_int_296 = torch.ops.aten.transpose.int(view_default_644, 1, 2);  view_default_644 = None
        transpose_int_297 = torch.ops.aten.transpose.int(transpose_int_295, 0, 1);  transpose_int_295 = None
        view_default_645 = torch.ops.aten.view.default(transpose_int_297, [1024, 2, 768]);  transpose_int_297 = None
        transpose_int_298 = torch.ops.aten.transpose.int(transpose_int_296, 0, 1);  transpose_int_296 = None
        view_default_646 = torch.ops.aten.view.default(transpose_int_298, [1024, 2, 768]);  transpose_int_298 = None
        div_tensor_7 = torch.ops.aten.div.Tensor(view_default_646, 8.0);  view_default_646 = None
        sum_dim_int_list_45 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_200, [0, 1], True)
        view_default_647 = torch.ops.aten.view.default(sum_dim_int_list_45, [768]);  sum_dim_int_list_45 = None
        view_default_648 = torch.ops.aten.view.default(_unsafe_view_default_200, [2048, 768]);  _unsafe_view_default_200 = None
        t_default_252 = torch.ops.aten.t.default(view_default_648)
        mm_default_138 = torch.ops.aten.mm.default(t_default_252, _unsafe_view_default_56);  t_default_252 = _unsafe_view_default_56 = None
        t_default_253 = torch.ops.aten.t.default(mm_default_138);  mm_default_138 = None
        t_default_254 = torch.ops.aten.t.default(t_default_26);  t_default_26 = None
        mm_default_139 = torch.ops.aten.mm.default(view_default_648, t_default_254);  view_default_648 = t_default_254 = None
        view_default_649 = torch.ops.aten.view.default(mm_default_139, [1024, 2, 768]);  mm_default_139 = None
        t_default_255 = torch.ops.aten.t.default(t_default_253);  t_default_253 = None
        sum_dim_int_list_46 = torch.ops.aten.sum.dim_IntList(view_default_645, [0, 1], True)
        view_default_650 = torch.ops.aten.view.default(sum_dim_int_list_46, [768]);  sum_dim_int_list_46 = None
        view_default_651 = torch.ops.aten.view.default(view_default_645, [2048, 768]);  view_default_645 = None
        t_default_256 = torch.ops.aten.t.default(view_default_651)
        mm_default_140 = torch.ops.aten.mm.default(t_default_256, _unsafe_view_default_54);  t_default_256 = _unsafe_view_default_54 = None
        t_default_257 = torch.ops.aten.t.default(mm_default_140);  mm_default_140 = None
        t_default_258 = torch.ops.aten.t.default(t_default_25);  t_default_25 = None
        mm_default_141 = torch.ops.aten.mm.default(view_default_651, t_default_258);  view_default_651 = t_default_258 = None
        view_default_652 = torch.ops.aten.view.default(mm_default_141, [1024, 2, 768]);  mm_default_141 = None
        add_tensor_141 = torch.ops.aten.add.Tensor(view_default_649, view_default_652);  view_default_649 = view_default_652 = None
        t_default_259 = torch.ops.aten.t.default(t_default_257);  t_default_257 = None
        sum_dim_int_list_47 = torch.ops.aten.sum.dim_IntList(div_tensor_7, [0, 1], True)
        view_default_653 = torch.ops.aten.view.default(sum_dim_int_list_47, [768]);  sum_dim_int_list_47 = None
        view_default_654 = torch.ops.aten.view.default(div_tensor_7, [2048, 768]);  div_tensor_7 = None
        t_default_260 = torch.ops.aten.t.default(view_default_654)
        mm_default_142 = torch.ops.aten.mm.default(t_default_260, _unsafe_view_default_52);  t_default_260 = _unsafe_view_default_52 = None
        t_default_261 = torch.ops.aten.t.default(mm_default_142);  mm_default_142 = None
        t_default_262 = torch.ops.aten.t.default(t_default_24);  t_default_24 = None
        mm_default_143 = torch.ops.aten.mm.default(view_default_654, t_default_262);  view_default_654 = t_default_262 = None
        view_default_655 = torch.ops.aten.view.default(mm_default_143, [1024, 2, 768]);  mm_default_143 = None
        add_tensor_142 = torch.ops.aten.add.Tensor(add_tensor_141, view_default_655);  add_tensor_141 = view_default_655 = None
        t_default_263 = torch.ops.aten.t.default(t_default_261);  t_default_261 = None
        transpose_int_299 = torch.ops.aten.transpose.int(add_tensor_142, 0, 1);  add_tensor_142 = None
        add_tensor_143 = torch.ops.aten.add.Tensor(getitem_117, transpose_int_299);  getitem_117 = transpose_int_299 = None
        native_layer_norm_backward_default_16 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_143, add_tensor_23, [768], getitem_22, getitem_23, primals_94, primals_93, [True, True, True]);  add_tensor_143 = add_tensor_23 = getitem_22 = getitem_23 = primals_94 = primals_93 = None
        getitem_120 = native_layer_norm_backward_default_16[0]
        getitem_121 = native_layer_norm_backward_default_16[1]
        getitem_122 = native_layer_norm_backward_default_16[2];  native_layer_norm_backward_default_16 = None
        view_default_656 = torch.ops.aten.view.default(getitem_120, [2048, 768])
        t_default_264 = torch.ops.aten.t.default(t_default_23);  t_default_23 = None
        mm_default_144 = torch.ops.aten.mm.default(view_default_656, t_default_264);  t_default_264 = None
        t_default_265 = torch.ops.aten.t.default(view_default_656)
        mm_default_145 = torch.ops.aten.mm.default(t_default_265, view_default_110);  t_default_265 = view_default_110 = None
        t_default_266 = torch.ops.aten.t.default(mm_default_145);  mm_default_145 = None
        sum_dim_int_list_48 = torch.ops.aten.sum.dim_IntList(view_default_656, [0], True);  view_default_656 = None
        view_default_657 = torch.ops.aten.view.default(sum_dim_int_list_48, [768]);  sum_dim_int_list_48 = None
        t_default_267 = torch.ops.aten.t.default(t_default_266);  t_default_266 = None
        view_default_658 = torch.ops.aten.view.default(mm_default_144, [2, 1024, 3072]);  mm_default_144 = None
        to_dtype_24 = torch.ops.aten.to.dtype(view_default_658, torch.float32);  view_default_658 = None
        to_dtype_25 = torch.ops.aten.to.dtype(view_default_109, torch.float32);  view_default_109 = None
        mul_tensor_68 = torch.ops.aten.mul.Tensor(to_dtype_25, 0.7071067811865476)
        erf_default_8 = torch.ops.aten.erf.default(mul_tensor_68);  mul_tensor_68 = None
        add_tensor_144 = torch.ops.aten.add.Tensor(erf_default_8, 1);  erf_default_8 = None
        mul_tensor_69 = torch.ops.aten.mul.Tensor(add_tensor_144, 0.5);  add_tensor_144 = None
        mul_tensor_70 = torch.ops.aten.mul.Tensor(to_dtype_25, to_dtype_25)
        mul_tensor_71 = torch.ops.aten.mul.Tensor(mul_tensor_70, -0.5);  mul_tensor_70 = None
        exp_default_8 = torch.ops.aten.exp.default(mul_tensor_71);  mul_tensor_71 = None
        mul_tensor_72 = torch.ops.aten.mul.Tensor(exp_default_8, 0.3989422804014327);  exp_default_8 = None
        mul_tensor_73 = torch.ops.aten.mul.Tensor(to_dtype_25, mul_tensor_72);  to_dtype_25 = mul_tensor_72 = None
        add_tensor_145 = torch.ops.aten.add.Tensor(mul_tensor_69, mul_tensor_73);  mul_tensor_69 = mul_tensor_73 = None
        mul_tensor_74 = torch.ops.aten.mul.Tensor(to_dtype_24, add_tensor_145);  to_dtype_24 = add_tensor_145 = None
        to_dtype_26 = torch.ops.aten.to.dtype(mul_tensor_74, torch.float32);  mul_tensor_74 = None
        view_default_659 = torch.ops.aten.view.default(to_dtype_26, [2048, 3072]);  to_dtype_26 = None
        t_default_268 = torch.ops.aten.t.default(t_default_22);  t_default_22 = None
        mm_default_146 = torch.ops.aten.mm.default(view_default_659, t_default_268);  t_default_268 = None
        t_default_269 = torch.ops.aten.t.default(view_default_659)
        mm_default_147 = torch.ops.aten.mm.default(t_default_269, view_default_108);  t_default_269 = view_default_108 = None
        t_default_270 = torch.ops.aten.t.default(mm_default_147);  mm_default_147 = None
        sum_dim_int_list_49 = torch.ops.aten.sum.dim_IntList(view_default_659, [0], True);  view_default_659 = None
        view_default_660 = torch.ops.aten.view.default(sum_dim_int_list_49, [3072]);  sum_dim_int_list_49 = None
        t_default_271 = torch.ops.aten.t.default(t_default_270);  t_default_270 = None
        view_default_661 = torch.ops.aten.view.default(mm_default_146, [2, 1024, 768]);  mm_default_146 = None
        add_tensor_146 = torch.ops.aten.add.Tensor(getitem_120, view_default_661);  getitem_120 = view_default_661 = None
        native_layer_norm_backward_default_17 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_146, add_tensor_22, [768], getitem_19, getitem_20, primals_82, primals_81, [True, True, True]);  add_tensor_146 = add_tensor_22 = getitem_19 = getitem_20 = primals_82 = primals_81 = None
        getitem_123 = native_layer_norm_backward_default_17[0]
        getitem_124 = native_layer_norm_backward_default_17[1]
        getitem_125 = native_layer_norm_backward_default_17[2];  native_layer_norm_backward_default_17 = None
        sum_dim_int_list_50 = torch.ops.aten.sum.dim_IntList(getitem_123, [0, 1], True)
        view_default_662 = torch.ops.aten.view.default(sum_dim_int_list_50, [768]);  sum_dim_int_list_50 = None
        view_default_663 = torch.ops.aten.view.default(getitem_123, [2048, 768])
        t_default_272 = torch.ops.aten.t.default(view_default_663)
        mm_default_148 = torch.ops.aten.mm.default(t_default_272, _unsafe_view_default_50);  t_default_272 = _unsafe_view_default_50 = None
        t_default_273 = torch.ops.aten.t.default(mm_default_148);  mm_default_148 = None
        t_default_274 = torch.ops.aten.t.default(t_default_21);  t_default_21 = None
        mm_default_149 = torch.ops.aten.mm.default(view_default_663, t_default_274);  view_default_663 = t_default_274 = None
        view_default_664 = torch.ops.aten.view.default(mm_default_149, [2, 1024, 768]);  mm_default_149 = None
        t_default_275 = torch.ops.aten.t.default(t_default_273);  t_default_273 = None
        transpose_int_300 = torch.ops.aten.transpose.int(view_default_664, 0, 1);  view_default_664 = None
        view_default_665 = torch.ops.aten.view.default(transpose_int_300, [1024, 2, 12, 64]);  transpose_int_300 = None
        transpose_int_301 = torch.ops.aten.transpose.int(view_default_665, 0, 1);  view_default_665 = None
        transpose_int_302 = torch.ops.aten.transpose.int(transpose_int_301, 1, 2);  transpose_int_301 = None
        clone_default_212 = torch.ops.aten.clone.default(transpose_int_302, memory_format = torch.contiguous_format);  transpose_int_302 = None
        _unsafe_view_default_204 = torch.ops.aten._unsafe_view.default(clone_default_212, [24, 4, 256, 64]);  clone_default_212 = None
        view_default_666 = torch.ops.aten.view.default(_unsafe_view_default_204, [24, 4, 256, 64, 1]);  _unsafe_view_default_204 = None
        permute_default_224 = torch.ops.aten.permute.default(view_default_666, [0, 1, 2, 4, 3]);  view_default_666 = None
        view_default_667 = torch.ops.aten.view.default(permute_default_224, [96, 256, 64]);  permute_default_224 = None
        transpose_int_303 = torch.ops.aten.transpose.int(view_default_104, 1, 2);  view_default_104 = None
        bmm_default_56 = torch.ops.aten.bmm.default(transpose_int_303, view_default_667);  transpose_int_303 = None
        transpose_int_304 = torch.ops.aten.transpose.int(_unsafe_view_default_48, 1, 2);  _unsafe_view_default_48 = None
        bmm_default_57 = torch.ops.aten.bmm.default(view_default_667, transpose_int_304);  view_default_667 = transpose_int_304 = None
        view_default_668 = torch.ops.aten.view.default(bmm_default_56, [24, 4, 768, 64, 1]);  bmm_default_56 = None
        permute_default_225 = torch.ops.aten.permute.default(view_default_668, [0, 1, 4, 3, 2]);  view_default_668 = None
        view_default_669 = torch.ops.aten.view.default(bmm_default_57, [24, 4, 256, 768, 1]);  bmm_default_57 = None
        permute_default_226 = torch.ops.aten.permute.default(view_default_669, [0, 1, 2, 4, 3]);  view_default_669 = None
        permute_default_227 = torch.ops.aten.permute.default(permute_default_225, [0, 1, 4, 3, 2]);  permute_default_225 = None
        squeeze_dim_56 = torch.ops.aten.squeeze.dim(permute_default_227, -1);  permute_default_227 = None
        permute_default_228 = torch.ops.aten.permute.default(permute_default_226, [0, 1, 2, 4, 3]);  permute_default_226 = None
        squeeze_dim_57 = torch.ops.aten.squeeze.dim(permute_default_228, -1);  permute_default_228 = None
        slice_backward_default_168 = torch.ops.aten.slice_backward.default(squeeze_dim_57, [24, 4, 256, 769], 3, 0, -1, 1);  squeeze_dim_57 = None
        slice_backward_default_169 = torch.ops.aten.slice_backward.default(slice_backward_default_168, [24, 4, 256, 769], 2, 0, 9223372036854775807, 1);  slice_backward_default_168 = None
        slice_backward_default_170 = torch.ops.aten.slice_backward.default(slice_backward_default_169, [24, 4, 256, 769], 1, 0, 9223372036854775807, 1);  slice_backward_default_169 = None
        slice_backward_default_171 = torch.ops.aten.slice_backward.default(slice_backward_default_170, [24, 4, 256, 769], 0, 0, 9223372036854775807, 1);  slice_backward_default_170 = None
        view_default_670 = torch.ops.aten.view.default(slice_backward_default_171, [24, 4, 196864]);  slice_backward_default_171 = None
        slice_backward_default_172 = torch.ops.aten.slice_backward.default(view_default_670, [24, 4, 197120], 2, 0, -256, 1);  view_default_670 = None
        slice_backward_default_173 = torch.ops.aten.slice_backward.default(slice_backward_default_172, [24, 4, 197120], 1, 0, 9223372036854775807, 1);  slice_backward_default_172 = None
        slice_backward_default_174 = torch.ops.aten.slice_backward.default(slice_backward_default_173, [24, 4, 197120], 0, 0, 9223372036854775807, 1);  slice_backward_default_173 = None
        view_default_671 = torch.ops.aten.view.default(slice_backward_default_174, [24, 4, 256, 770]);  slice_backward_default_174 = None
        constant_pad_nd_default_72 = torch.ops.aten.constant_pad_nd.default(view_default_671, [0, -257]);  view_default_671 = None
        new_empty_default_92 = torch.ops.aten.new_empty.default(squeeze_dim_56, [2359296])
        zero__default_56 = torch.ops.aten.zero_.default(new_empty_default_92);  new_empty_default_92 = None
        arange_24 = torch.ops.aten.arange.start(0, 2359296, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_180 = torch.ops.aten.as_strided.default(arange_24, [24, 4, 768, 64], [98304, 16384, 64, 1], 0);  arange_24 = None
        clone_default_213 = torch.ops.aten.clone.default(as_strided_default_180, memory_format = torch.contiguous_format);  as_strided_default_180 = None
        _unsafe_view_default_205 = torch.ops.aten._unsafe_view.default(clone_default_213, [4718592]);  clone_default_213 = None
        view_default_672 = torch.ops.aten.view.default(squeeze_dim_56, [4718592]);  squeeze_dim_56 = None
        index_add__default_24 = torch.ops.aten.index_add_.default(zero__default_56, 0, _unsafe_view_default_205, view_default_672);  zero__default_56 = _unsafe_view_default_205 = view_default_672 = None
        as_strided_default_181 = torch.ops.aten.as_strided.default(index_add__default_24, [24, 1536, 64], [98304, 64, 1], 0);  index_add__default_24 = None
        constant_pad_nd_default_73 = torch.ops.aten.constant_pad_nd.default(as_strided_default_181, [0, 0, -256, -256]);  as_strided_default_181 = None
        view_default_673 = torch.ops.aten.view.default(constant_pad_nd_default_73, [2, 12, 1024, 64]);  constant_pad_nd_default_73 = None
        transpose_int_305 = torch.ops.aten.transpose.int(view_default_673, 1, 2);  view_default_673 = None
        view_default_674 = torch.ops.aten.view.default(constant_pad_nd_default_72, [2, 12, 1024, 513]);  constant_pad_nd_default_72 = None
        transpose_int_306 = torch.ops.aten.transpose.int(view_default_674, 1, 2);  view_default_674 = None
        transpose_int_307 = torch.ops.aten.transpose.int(transpose_int_305, 0, 1);  transpose_int_305 = None
        clone_default_214 = torch.ops.aten.clone.default(transpose_int_307, memory_format = torch.contiguous_format);  transpose_int_307 = None
        _unsafe_view_default_206 = torch.ops.aten._unsafe_view.default(clone_default_214, [1024, 2, 768]);  clone_default_214 = None
        where_scalar_self_48 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_53, 0.0, transpose_int_306);  unsqueeze_default_53 = transpose_int_306 = None
        _softmax_backward_data_default_8 = torch.ops.aten._softmax_backward_data.default(where_scalar_self_48, _softmax_default_3, -1, torch.float32);  where_scalar_self_48 = _softmax_default_3 = None
        new_empty_default_93 = torch.ops.aten.new_empty.default(_softmax_backward_data_default_8, [12607488]);  _softmax_backward_data_default_8 = None
        zero__default_57 = torch.ops.aten.zero_.default(new_empty_default_93);  new_empty_default_93 = None
        as_strided_default_183 = torch.ops.aten.as_strided.default(zero__default_57, [24, 4, 256, 513], [525312, 131328, 513, 1], 0);  zero__default_57 = None
        new_empty_strided_default_56 = torch.ops.aten.new_empty_strided.default(as_strided_default_183, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_209 = torch.ops.aten.copy_.default(new_empty_strided_default_56, as_strided_default_183);  new_empty_strided_default_56 = as_strided_default_183 = None
        new_empty_strided_default_57 = torch.ops.aten.new_empty_strided.default(copy__default_209, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_211 = torch.ops.aten.copy_.default(new_empty_strided_default_57, copy__default_209);  new_empty_strided_default_57 = copy__default_209 = None
        new_empty_strided_default_58 = torch.ops.aten.new_empty_strided.default(copy__default_211, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_213 = torch.ops.aten.copy_.default(new_empty_strided_default_58, copy__default_211);  new_empty_strided_default_58 = copy__default_211 = None
        new_empty_strided_default_59 = torch.ops.aten.new_empty_strided.default(copy__default_213, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_215 = torch.ops.aten.copy_.default(new_empty_strided_default_59, copy__default_213);  new_empty_strided_default_59 = copy__default_213 = None
        as_strided_default_187 = torch.ops.aten.as_strided.default(copy__default_215, [24, 255, 255], [525312, 513, 1], 514)
        clone_default_218 = torch.ops.aten.clone.default(as_strided_default_187, memory_format = torch.contiguous_format);  as_strided_default_187 = None
        slice_backward_default_175 = torch.ops.aten.slice_backward.default(clone_default_218, [24, 255, 513], 2, -255, 9223372036854775807, 1);  clone_default_218 = None
        slice_backward_default_176 = torch.ops.aten.slice_backward.default(slice_backward_default_175, [24, 512, 513], 1, 0, 255, 1);  slice_backward_default_175 = None
        select_backward_default_16 = torch.ops.aten.select_backward.default(slice_backward_default_176, [24, 3, 512, 513], 1, 0);  slice_backward_default_176 = None
        slice_backward_default_177 = torch.ops.aten.slice_backward.default(select_backward_default_16, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_16 = None
        new_empty_strided_default_60 = torch.ops.aten.new_empty_strided.default(copy__default_215, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_217 = torch.ops.aten.copy_.default(new_empty_strided_default_60, copy__default_215);  new_empty_strided_default_60 = copy__default_215 = None
        as_strided_default_188 = torch.ops.aten.as_strided.default(copy__default_217, [24, 3, 256, 256], [525312, 131328, 513, 1], 131328)
        clone_default_219 = torch.ops.aten.clone.default(as_strided_default_188, memory_format = torch.contiguous_format);  as_strided_default_188 = None
        slice_backward_default_178 = torch.ops.aten.slice_backward.default(clone_default_219, [24, 3, 256, 513], 3, 257, 9223372036854775807, 1);  clone_default_219 = None
        slice_backward_default_179 = torch.ops.aten.slice_backward.default(slice_backward_default_178, [24, 3, 512, 513], 2, -257, -1, 1);  slice_backward_default_178 = None
        slice_backward_default_180 = torch.ops.aten.slice_backward.default(slice_backward_default_179, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_179 = None
        slice_backward_default_181 = torch.ops.aten.slice_backward.default(slice_backward_default_180, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_180 = None
        add_tensor_147 = torch.ops.aten.add.Tensor(slice_backward_default_177, slice_backward_default_181);  slice_backward_default_177 = slice_backward_default_181 = None
        new_empty_strided_default_61 = torch.ops.aten.new_empty_strided.default(copy__default_217, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_219 = torch.ops.aten.copy_.default(new_empty_strided_default_61, copy__default_217);  new_empty_strided_default_61 = copy__default_217 = None
        as_strided_default_189 = torch.ops.aten.as_strided.default(copy__default_219, [24, 256, 257], [525312, 513, 1], 394240)
        clone_default_220 = torch.ops.aten.clone.default(as_strided_default_189, memory_format = torch.contiguous_format);  as_strided_default_189 = None
        slice_backward_default_182 = torch.ops.aten.slice_backward.default(clone_default_220, [24, 256, 513], 2, 0, 257, 1);  clone_default_220 = None
        slice_backward_default_183 = torch.ops.aten.slice_backward.default(slice_backward_default_182, [24, 512, 513], 1, 256, 9223372036854775807, 1);  slice_backward_default_182 = None
        select_backward_default_17 = torch.ops.aten.select_backward.default(slice_backward_default_183, [24, 3, 512, 513], 1, -1);  slice_backward_default_183 = None
        slice_backward_default_184 = torch.ops.aten.slice_backward.default(select_backward_default_17, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_17 = None
        add_tensor_148 = torch.ops.aten.add.Tensor(add_tensor_147, slice_backward_default_184);  add_tensor_147 = slice_backward_default_184 = None
        new_empty_strided_default_62 = torch.ops.aten.new_empty_strided.default(copy__default_219, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_221 = torch.ops.aten.copy_.default(new_empty_strided_default_62, copy__default_219);  new_empty_strided_default_62 = copy__default_219 = None
        as_strided_default_190 = torch.ops.aten.as_strided.default(copy__default_221, [24, 3, 256, 257], [525312, 131328, 513, 1], 256);  copy__default_221 = None
        clone_default_221 = torch.ops.aten.clone.default(as_strided_default_190, memory_format = torch.contiguous_format);  as_strided_default_190 = None
        slice_backward_default_185 = torch.ops.aten.slice_backward.default(clone_default_221, [24, 3, 256, 513], 3, 0, 257, 1);  clone_default_221 = None
        slice_backward_default_186 = torch.ops.aten.slice_backward.default(slice_backward_default_185, [24, 3, 512, 513], 2, 0, 256, 1);  slice_backward_default_185 = None
        slice_backward_default_187 = torch.ops.aten.slice_backward.default(slice_backward_default_186, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_186 = None
        slice_backward_default_188 = torch.ops.aten.slice_backward.default(slice_backward_default_187, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_187 = None
        add_tensor_149 = torch.ops.aten.add.Tensor(add_tensor_148, slice_backward_default_188);  add_tensor_148 = slice_backward_default_188 = None
        view_default_675 = torch.ops.aten.view.default(add_tensor_149, [24, 3, 513, 512]);  add_tensor_149 = None
        constant_pad_nd_default_74 = torch.ops.aten.constant_pad_nd.default(view_default_675, [0, 0, 0, -1]);  view_default_675 = None
        view_default_676 = torch.ops.aten.view.default(constant_pad_nd_default_74, [24, 3, 512, 512, 1]);  constant_pad_nd_default_74 = None
        permute_default_229 = torch.ops.aten.permute.default(view_default_676, [0, 1, 2, 4, 3]);  view_default_676 = None
        view_default_677 = torch.ops.aten.view.default(permute_default_229, [72, 512, 512]);  permute_default_229 = None
        transpose_int_308 = torch.ops.aten.transpose.int(_unsafe_view_default_45, 1, 2);  _unsafe_view_default_45 = None
        bmm_default_58 = torch.ops.aten.bmm.default(transpose_int_308, view_default_677);  transpose_int_308 = None
        transpose_int_309 = torch.ops.aten.transpose.int(_unsafe_view_default_46, 1, 2);  _unsafe_view_default_46 = None
        bmm_default_59 = torch.ops.aten.bmm.default(view_default_677, transpose_int_309);  view_default_677 = transpose_int_309 = None
        view_default_678 = torch.ops.aten.view.default(bmm_default_58, [24, 3, 64, 512, 1]);  bmm_default_58 = None
        permute_default_230 = torch.ops.aten.permute.default(view_default_678, [0, 1, 4, 3, 2]);  view_default_678 = None
        view_default_679 = torch.ops.aten.view.default(bmm_default_59, [24, 3, 512, 64, 1]);  bmm_default_59 = None
        permute_default_231 = torch.ops.aten.permute.default(view_default_679, [0, 1, 2, 4, 3]);  view_default_679 = None
        permute_default_232 = torch.ops.aten.permute.default(permute_default_230, [0, 1, 3, 4, 2]);  permute_default_230 = None
        squeeze_dim_58 = torch.ops.aten.squeeze.dim(permute_default_232, -1);  permute_default_232 = None
        permute_default_233 = torch.ops.aten.permute.default(permute_default_231, [0, 1, 2, 4, 3]);  permute_default_231 = None
        squeeze_dim_59 = torch.ops.aten.squeeze.dim(permute_default_233, -1);  permute_default_233 = None
        new_empty_default_94 = torch.ops.aten.new_empty.default(squeeze_dim_58, [1572864])
        zero__default_61 = torch.ops.aten.zero_.default(new_empty_default_94);  new_empty_default_94 = None
        arange_25 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_191 = torch.ops.aten.as_strided.default(arange_25, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_25 = None
        clone_default_222 = torch.ops.aten.clone.default(as_strided_default_191, memory_format = torch.contiguous_format);  as_strided_default_191 = None
        _unsafe_view_default_207 = torch.ops.aten._unsafe_view.default(clone_default_222, [2359296]);  clone_default_222 = None
        clone_default_223 = torch.ops.aten.clone.default(squeeze_dim_58, memory_format = torch.contiguous_format);  squeeze_dim_58 = None
        _unsafe_view_default_208 = torch.ops.aten._unsafe_view.default(clone_default_223, [2359296]);  clone_default_223 = None
        index_add__default_25 = torch.ops.aten.index_add_.default(zero__default_61, 0, _unsafe_view_default_207, _unsafe_view_default_208);  zero__default_61 = _unsafe_view_default_207 = _unsafe_view_default_208 = None
        as_strided_default_192 = torch.ops.aten.as_strided.default(index_add__default_25, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_25 = None
        view_default_680 = torch.ops.aten.view.default(as_strided_default_192, [24, 1024, 64]);  as_strided_default_192 = None
        new_empty_default_95 = torch.ops.aten.new_empty.default(squeeze_dim_59, [1572864])
        zero__default_62 = torch.ops.aten.zero_.default(new_empty_default_95);  new_empty_default_95 = None
        arange_26 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_193 = torch.ops.aten.as_strided.default(arange_26, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_26 = None
        clone_default_224 = torch.ops.aten.clone.default(as_strided_default_193, memory_format = torch.contiguous_format);  as_strided_default_193 = None
        _unsafe_view_default_209 = torch.ops.aten._unsafe_view.default(clone_default_224, [2359296]);  clone_default_224 = None
        view_default_681 = torch.ops.aten.view.default(squeeze_dim_59, [2359296]);  squeeze_dim_59 = None
        index_add__default_26 = torch.ops.aten.index_add_.default(zero__default_62, 0, _unsafe_view_default_209, view_default_681);  zero__default_62 = _unsafe_view_default_209 = view_default_681 = None
        as_strided_default_194 = torch.ops.aten.as_strided.default(index_add__default_26, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_26 = None
        view_default_682 = torch.ops.aten.view.default(as_strided_default_194, [24, 1024, 64]);  as_strided_default_194 = None
        view_default_683 = torch.ops.aten.view.default(view_default_680, [2, 12, 1024, 64]);  view_default_680 = None
        transpose_int_310 = torch.ops.aten.transpose.int(view_default_683, 1, 2);  view_default_683 = None
        view_default_684 = torch.ops.aten.view.default(view_default_682, [2, 12, 1024, 64]);  view_default_682 = None
        transpose_int_311 = torch.ops.aten.transpose.int(view_default_684, 1, 2);  view_default_684 = None
        transpose_int_312 = torch.ops.aten.transpose.int(transpose_int_310, 0, 1);  transpose_int_310 = None
        view_default_685 = torch.ops.aten.view.default(transpose_int_312, [1024, 2, 768]);  transpose_int_312 = None
        transpose_int_313 = torch.ops.aten.transpose.int(transpose_int_311, 0, 1);  transpose_int_311 = None
        view_default_686 = torch.ops.aten.view.default(transpose_int_313, [1024, 2, 768]);  transpose_int_313 = None
        div_tensor_8 = torch.ops.aten.div.Tensor(view_default_686, 8.0);  view_default_686 = None
        sum_dim_int_list_51 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_206, [0, 1], True)
        view_default_687 = torch.ops.aten.view.default(sum_dim_int_list_51, [768]);  sum_dim_int_list_51 = None
        view_default_688 = torch.ops.aten.view.default(_unsafe_view_default_206, [2048, 768]);  _unsafe_view_default_206 = None
        t_default_276 = torch.ops.aten.t.default(view_default_688)
        mm_default_150 = torch.ops.aten.mm.default(t_default_276, _unsafe_view_default_43);  t_default_276 = _unsafe_view_default_43 = None
        t_default_277 = torch.ops.aten.t.default(mm_default_150);  mm_default_150 = None
        t_default_278 = torch.ops.aten.t.default(t_default_20);  t_default_20 = None
        mm_default_151 = torch.ops.aten.mm.default(view_default_688, t_default_278);  view_default_688 = t_default_278 = None
        view_default_689 = torch.ops.aten.view.default(mm_default_151, [1024, 2, 768]);  mm_default_151 = None
        t_default_279 = torch.ops.aten.t.default(t_default_277);  t_default_277 = None
        sum_dim_int_list_52 = torch.ops.aten.sum.dim_IntList(view_default_685, [0, 1], True)
        view_default_690 = torch.ops.aten.view.default(sum_dim_int_list_52, [768]);  sum_dim_int_list_52 = None
        view_default_691 = torch.ops.aten.view.default(view_default_685, [2048, 768]);  view_default_685 = None
        t_default_280 = torch.ops.aten.t.default(view_default_691)
        mm_default_152 = torch.ops.aten.mm.default(t_default_280, _unsafe_view_default_41);  t_default_280 = _unsafe_view_default_41 = None
        t_default_281 = torch.ops.aten.t.default(mm_default_152);  mm_default_152 = None
        t_default_282 = torch.ops.aten.t.default(t_default_19);  t_default_19 = None
        mm_default_153 = torch.ops.aten.mm.default(view_default_691, t_default_282);  view_default_691 = t_default_282 = None
        view_default_692 = torch.ops.aten.view.default(mm_default_153, [1024, 2, 768]);  mm_default_153 = None
        add_tensor_150 = torch.ops.aten.add.Tensor(view_default_689, view_default_692);  view_default_689 = view_default_692 = None
        t_default_283 = torch.ops.aten.t.default(t_default_281);  t_default_281 = None
        sum_dim_int_list_53 = torch.ops.aten.sum.dim_IntList(div_tensor_8, [0, 1], True)
        view_default_693 = torch.ops.aten.view.default(sum_dim_int_list_53, [768]);  sum_dim_int_list_53 = None
        view_default_694 = torch.ops.aten.view.default(div_tensor_8, [2048, 768]);  div_tensor_8 = None
        t_default_284 = torch.ops.aten.t.default(view_default_694)
        mm_default_154 = torch.ops.aten.mm.default(t_default_284, _unsafe_view_default_39);  t_default_284 = _unsafe_view_default_39 = None
        t_default_285 = torch.ops.aten.t.default(mm_default_154);  mm_default_154 = None
        t_default_286 = torch.ops.aten.t.default(t_default_18);  t_default_18 = None
        mm_default_155 = torch.ops.aten.mm.default(view_default_694, t_default_286);  view_default_694 = t_default_286 = None
        view_default_695 = torch.ops.aten.view.default(mm_default_155, [1024, 2, 768]);  mm_default_155 = None
        add_tensor_151 = torch.ops.aten.add.Tensor(add_tensor_150, view_default_695);  add_tensor_150 = view_default_695 = None
        t_default_287 = torch.ops.aten.t.default(t_default_285);  t_default_285 = None
        transpose_int_314 = torch.ops.aten.transpose.int(add_tensor_151, 0, 1);  add_tensor_151 = None
        add_tensor_152 = torch.ops.aten.add.Tensor(getitem_123, transpose_int_314);  getitem_123 = transpose_int_314 = None
        native_layer_norm_backward_default_18 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_152, add_tensor_17, [768], getitem_16, getitem_17, primals_78, primals_77, [True, True, True]);  add_tensor_152 = add_tensor_17 = getitem_16 = getitem_17 = primals_78 = primals_77 = None
        getitem_126 = native_layer_norm_backward_default_18[0]
        getitem_127 = native_layer_norm_backward_default_18[1]
        getitem_128 = native_layer_norm_backward_default_18[2];  native_layer_norm_backward_default_18 = None
        view_default_696 = torch.ops.aten.view.default(getitem_126, [2048, 768])
        t_default_288 = torch.ops.aten.t.default(t_default_17);  t_default_17 = None
        mm_default_156 = torch.ops.aten.mm.default(view_default_696, t_default_288);  t_default_288 = None
        t_default_289 = torch.ops.aten.t.default(view_default_696)
        mm_default_157 = torch.ops.aten.mm.default(t_default_289, view_default_82);  t_default_289 = view_default_82 = None
        t_default_290 = torch.ops.aten.t.default(mm_default_157);  mm_default_157 = None
        sum_dim_int_list_54 = torch.ops.aten.sum.dim_IntList(view_default_696, [0], True);  view_default_696 = None
        view_default_697 = torch.ops.aten.view.default(sum_dim_int_list_54, [768]);  sum_dim_int_list_54 = None
        t_default_291 = torch.ops.aten.t.default(t_default_290);  t_default_290 = None
        view_default_698 = torch.ops.aten.view.default(mm_default_156, [2, 1024, 3072]);  mm_default_156 = None
        to_dtype_27 = torch.ops.aten.to.dtype(view_default_698, torch.float32);  view_default_698 = None
        to_dtype_28 = torch.ops.aten.to.dtype(view_default_81, torch.float32);  view_default_81 = None
        mul_tensor_75 = torch.ops.aten.mul.Tensor(to_dtype_28, 0.7071067811865476)
        erf_default_9 = torch.ops.aten.erf.default(mul_tensor_75);  mul_tensor_75 = None
        add_tensor_153 = torch.ops.aten.add.Tensor(erf_default_9, 1);  erf_default_9 = None
        mul_tensor_76 = torch.ops.aten.mul.Tensor(add_tensor_153, 0.5);  add_tensor_153 = None
        mul_tensor_77 = torch.ops.aten.mul.Tensor(to_dtype_28, to_dtype_28)
        mul_tensor_78 = torch.ops.aten.mul.Tensor(mul_tensor_77, -0.5);  mul_tensor_77 = None
        exp_default_9 = torch.ops.aten.exp.default(mul_tensor_78);  mul_tensor_78 = None
        mul_tensor_79 = torch.ops.aten.mul.Tensor(exp_default_9, 0.3989422804014327);  exp_default_9 = None
        mul_tensor_80 = torch.ops.aten.mul.Tensor(to_dtype_28, mul_tensor_79);  to_dtype_28 = mul_tensor_79 = None
        add_tensor_154 = torch.ops.aten.add.Tensor(mul_tensor_76, mul_tensor_80);  mul_tensor_76 = mul_tensor_80 = None
        mul_tensor_81 = torch.ops.aten.mul.Tensor(to_dtype_27, add_tensor_154);  to_dtype_27 = add_tensor_154 = None
        to_dtype_29 = torch.ops.aten.to.dtype(mul_tensor_81, torch.float32);  mul_tensor_81 = None
        view_default_699 = torch.ops.aten.view.default(to_dtype_29, [2048, 3072]);  to_dtype_29 = None
        t_default_292 = torch.ops.aten.t.default(t_default_16);  t_default_16 = None
        mm_default_158 = torch.ops.aten.mm.default(view_default_699, t_default_292);  t_default_292 = None
        t_default_293 = torch.ops.aten.t.default(view_default_699)
        mm_default_159 = torch.ops.aten.mm.default(t_default_293, view_default_80);  t_default_293 = view_default_80 = None
        t_default_294 = torch.ops.aten.t.default(mm_default_159);  mm_default_159 = None
        sum_dim_int_list_55 = torch.ops.aten.sum.dim_IntList(view_default_699, [0], True);  view_default_699 = None
        view_default_700 = torch.ops.aten.view.default(sum_dim_int_list_55, [3072]);  sum_dim_int_list_55 = None
        t_default_295 = torch.ops.aten.t.default(t_default_294);  t_default_294 = None
        view_default_701 = torch.ops.aten.view.default(mm_default_158, [2, 1024, 768]);  mm_default_158 = None
        add_tensor_155 = torch.ops.aten.add.Tensor(getitem_126, view_default_701);  getitem_126 = view_default_701 = None
        native_layer_norm_backward_default_19 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_155, add_tensor_16, [768], getitem_13, getitem_14, primals_66, primals_65, [True, True, True]);  add_tensor_155 = add_tensor_16 = getitem_13 = getitem_14 = primals_66 = primals_65 = None
        getitem_129 = native_layer_norm_backward_default_19[0]
        getitem_130 = native_layer_norm_backward_default_19[1]
        getitem_131 = native_layer_norm_backward_default_19[2];  native_layer_norm_backward_default_19 = None
        sum_dim_int_list_56 = torch.ops.aten.sum.dim_IntList(getitem_129, [0, 1], True)
        view_default_702 = torch.ops.aten.view.default(sum_dim_int_list_56, [768]);  sum_dim_int_list_56 = None
        view_default_703 = torch.ops.aten.view.default(getitem_129, [2048, 768])
        t_default_296 = torch.ops.aten.t.default(view_default_703)
        mm_default_160 = torch.ops.aten.mm.default(t_default_296, _unsafe_view_default_37);  t_default_296 = _unsafe_view_default_37 = None
        t_default_297 = torch.ops.aten.t.default(mm_default_160);  mm_default_160 = None
        t_default_298 = torch.ops.aten.t.default(t_default_15);  t_default_15 = None
        mm_default_161 = torch.ops.aten.mm.default(view_default_703, t_default_298);  view_default_703 = t_default_298 = None
        view_default_704 = torch.ops.aten.view.default(mm_default_161, [2, 1024, 768]);  mm_default_161 = None
        t_default_299 = torch.ops.aten.t.default(t_default_297);  t_default_297 = None
        transpose_int_315 = torch.ops.aten.transpose.int(view_default_704, 0, 1);  view_default_704 = None
        view_default_705 = torch.ops.aten.view.default(transpose_int_315, [1024, 2, 12, 64]);  transpose_int_315 = None
        transpose_int_316 = torch.ops.aten.transpose.int(view_default_705, 0, 1);  view_default_705 = None
        transpose_int_317 = torch.ops.aten.transpose.int(transpose_int_316, 1, 2);  transpose_int_316 = None
        clone_default_225 = torch.ops.aten.clone.default(transpose_int_317, memory_format = torch.contiguous_format);  transpose_int_317 = None
        _unsafe_view_default_210 = torch.ops.aten._unsafe_view.default(clone_default_225, [24, 4, 256, 64]);  clone_default_225 = None
        view_default_706 = torch.ops.aten.view.default(_unsafe_view_default_210, [24, 4, 256, 64, 1]);  _unsafe_view_default_210 = None
        permute_default_234 = torch.ops.aten.permute.default(view_default_706, [0, 1, 2, 4, 3]);  view_default_706 = None
        view_default_707 = torch.ops.aten.view.default(permute_default_234, [96, 256, 64]);  permute_default_234 = None
        transpose_int_318 = torch.ops.aten.transpose.int(view_default_76, 1, 2);  view_default_76 = None
        bmm_default_60 = torch.ops.aten.bmm.default(transpose_int_318, view_default_707);  transpose_int_318 = None
        transpose_int_319 = torch.ops.aten.transpose.int(_unsafe_view_default_35, 1, 2);  _unsafe_view_default_35 = None
        bmm_default_61 = torch.ops.aten.bmm.default(view_default_707, transpose_int_319);  view_default_707 = transpose_int_319 = None
        view_default_708 = torch.ops.aten.view.default(bmm_default_60, [24, 4, 768, 64, 1]);  bmm_default_60 = None
        permute_default_235 = torch.ops.aten.permute.default(view_default_708, [0, 1, 4, 3, 2]);  view_default_708 = None
        view_default_709 = torch.ops.aten.view.default(bmm_default_61, [24, 4, 256, 768, 1]);  bmm_default_61 = None
        permute_default_236 = torch.ops.aten.permute.default(view_default_709, [0, 1, 2, 4, 3]);  view_default_709 = None
        permute_default_237 = torch.ops.aten.permute.default(permute_default_235, [0, 1, 4, 3, 2]);  permute_default_235 = None
        squeeze_dim_60 = torch.ops.aten.squeeze.dim(permute_default_237, -1);  permute_default_237 = None
        permute_default_238 = torch.ops.aten.permute.default(permute_default_236, [0, 1, 2, 4, 3]);  permute_default_236 = None
        squeeze_dim_61 = torch.ops.aten.squeeze.dim(permute_default_238, -1);  permute_default_238 = None
        slice_backward_default_189 = torch.ops.aten.slice_backward.default(squeeze_dim_61, [24, 4, 256, 769], 3, 0, -1, 1);  squeeze_dim_61 = None
        slice_backward_default_190 = torch.ops.aten.slice_backward.default(slice_backward_default_189, [24, 4, 256, 769], 2, 0, 9223372036854775807, 1);  slice_backward_default_189 = None
        slice_backward_default_191 = torch.ops.aten.slice_backward.default(slice_backward_default_190, [24, 4, 256, 769], 1, 0, 9223372036854775807, 1);  slice_backward_default_190 = None
        slice_backward_default_192 = torch.ops.aten.slice_backward.default(slice_backward_default_191, [24, 4, 256, 769], 0, 0, 9223372036854775807, 1);  slice_backward_default_191 = None
        view_default_710 = torch.ops.aten.view.default(slice_backward_default_192, [24, 4, 196864]);  slice_backward_default_192 = None
        slice_backward_default_193 = torch.ops.aten.slice_backward.default(view_default_710, [24, 4, 197120], 2, 0, -256, 1);  view_default_710 = None
        slice_backward_default_194 = torch.ops.aten.slice_backward.default(slice_backward_default_193, [24, 4, 197120], 1, 0, 9223372036854775807, 1);  slice_backward_default_193 = None
        slice_backward_default_195 = torch.ops.aten.slice_backward.default(slice_backward_default_194, [24, 4, 197120], 0, 0, 9223372036854775807, 1);  slice_backward_default_194 = None
        view_default_711 = torch.ops.aten.view.default(slice_backward_default_195, [24, 4, 256, 770]);  slice_backward_default_195 = None
        constant_pad_nd_default_75 = torch.ops.aten.constant_pad_nd.default(view_default_711, [0, -257]);  view_default_711 = None
        new_empty_default_96 = torch.ops.aten.new_empty.default(squeeze_dim_60, [2359296])
        zero__default_63 = torch.ops.aten.zero_.default(new_empty_default_96);  new_empty_default_96 = None
        arange_27 = torch.ops.aten.arange.start(0, 2359296, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_195 = torch.ops.aten.as_strided.default(arange_27, [24, 4, 768, 64], [98304, 16384, 64, 1], 0);  arange_27 = None
        clone_default_226 = torch.ops.aten.clone.default(as_strided_default_195, memory_format = torch.contiguous_format);  as_strided_default_195 = None
        _unsafe_view_default_211 = torch.ops.aten._unsafe_view.default(clone_default_226, [4718592]);  clone_default_226 = None
        view_default_712 = torch.ops.aten.view.default(squeeze_dim_60, [4718592]);  squeeze_dim_60 = None
        index_add__default_27 = torch.ops.aten.index_add_.default(zero__default_63, 0, _unsafe_view_default_211, view_default_712);  zero__default_63 = _unsafe_view_default_211 = view_default_712 = None
        as_strided_default_196 = torch.ops.aten.as_strided.default(index_add__default_27, [24, 1536, 64], [98304, 64, 1], 0);  index_add__default_27 = None
        constant_pad_nd_default_76 = torch.ops.aten.constant_pad_nd.default(as_strided_default_196, [0, 0, -256, -256]);  as_strided_default_196 = None
        view_default_713 = torch.ops.aten.view.default(constant_pad_nd_default_76, [2, 12, 1024, 64]);  constant_pad_nd_default_76 = None
        transpose_int_320 = torch.ops.aten.transpose.int(view_default_713, 1, 2);  view_default_713 = None
        view_default_714 = torch.ops.aten.view.default(constant_pad_nd_default_75, [2, 12, 1024, 513]);  constant_pad_nd_default_75 = None
        transpose_int_321 = torch.ops.aten.transpose.int(view_default_714, 1, 2);  view_default_714 = None
        transpose_int_322 = torch.ops.aten.transpose.int(transpose_int_320, 0, 1);  transpose_int_320 = None
        clone_default_227 = torch.ops.aten.clone.default(transpose_int_322, memory_format = torch.contiguous_format);  transpose_int_322 = None
        _unsafe_view_default_212 = torch.ops.aten._unsafe_view.default(clone_default_227, [1024, 2, 768]);  clone_default_227 = None
        where_scalar_self_51 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_39, 0.0, transpose_int_321);  unsqueeze_default_39 = transpose_int_321 = None
        _softmax_backward_data_default_9 = torch.ops.aten._softmax_backward_data.default(where_scalar_self_51, _softmax_default_2, -1, torch.float32);  where_scalar_self_51 = _softmax_default_2 = None
        new_empty_default_97 = torch.ops.aten.new_empty.default(_softmax_backward_data_default_9, [12607488]);  _softmax_backward_data_default_9 = None
        zero__default_64 = torch.ops.aten.zero_.default(new_empty_default_97);  new_empty_default_97 = None
        as_strided_default_198 = torch.ops.aten.as_strided.default(zero__default_64, [24, 4, 256, 513], [525312, 131328, 513, 1], 0);  zero__default_64 = None
        new_empty_strided_default_63 = torch.ops.aten.new_empty_strided.default(as_strided_default_198, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_223 = torch.ops.aten.copy_.default(new_empty_strided_default_63, as_strided_default_198);  new_empty_strided_default_63 = as_strided_default_198 = None
        new_empty_strided_default_64 = torch.ops.aten.new_empty_strided.default(copy__default_223, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_225 = torch.ops.aten.copy_.default(new_empty_strided_default_64, copy__default_223);  new_empty_strided_default_64 = copy__default_223 = None
        new_empty_strided_default_65 = torch.ops.aten.new_empty_strided.default(copy__default_225, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_227 = torch.ops.aten.copy_.default(new_empty_strided_default_65, copy__default_225);  new_empty_strided_default_65 = copy__default_225 = None
        new_empty_strided_default_66 = torch.ops.aten.new_empty_strided.default(copy__default_227, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_229 = torch.ops.aten.copy_.default(new_empty_strided_default_66, copy__default_227);  new_empty_strided_default_66 = copy__default_227 = None
        as_strided_default_202 = torch.ops.aten.as_strided.default(copy__default_229, [24, 255, 255], [525312, 513, 1], 514)
        clone_default_231 = torch.ops.aten.clone.default(as_strided_default_202, memory_format = torch.contiguous_format);  as_strided_default_202 = None
        slice_backward_default_196 = torch.ops.aten.slice_backward.default(clone_default_231, [24, 255, 513], 2, -255, 9223372036854775807, 1);  clone_default_231 = None
        slice_backward_default_197 = torch.ops.aten.slice_backward.default(slice_backward_default_196, [24, 512, 513], 1, 0, 255, 1);  slice_backward_default_196 = None
        select_backward_default_18 = torch.ops.aten.select_backward.default(slice_backward_default_197, [24, 3, 512, 513], 1, 0);  slice_backward_default_197 = None
        slice_backward_default_198 = torch.ops.aten.slice_backward.default(select_backward_default_18, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_18 = None
        new_empty_strided_default_67 = torch.ops.aten.new_empty_strided.default(copy__default_229, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_231 = torch.ops.aten.copy_.default(new_empty_strided_default_67, copy__default_229);  new_empty_strided_default_67 = copy__default_229 = None
        as_strided_default_203 = torch.ops.aten.as_strided.default(copy__default_231, [24, 3, 256, 256], [525312, 131328, 513, 1], 131328)
        clone_default_232 = torch.ops.aten.clone.default(as_strided_default_203, memory_format = torch.contiguous_format);  as_strided_default_203 = None
        slice_backward_default_199 = torch.ops.aten.slice_backward.default(clone_default_232, [24, 3, 256, 513], 3, 257, 9223372036854775807, 1);  clone_default_232 = None
        slice_backward_default_200 = torch.ops.aten.slice_backward.default(slice_backward_default_199, [24, 3, 512, 513], 2, -257, -1, 1);  slice_backward_default_199 = None
        slice_backward_default_201 = torch.ops.aten.slice_backward.default(slice_backward_default_200, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_200 = None
        slice_backward_default_202 = torch.ops.aten.slice_backward.default(slice_backward_default_201, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_201 = None
        add_tensor_156 = torch.ops.aten.add.Tensor(slice_backward_default_198, slice_backward_default_202);  slice_backward_default_198 = slice_backward_default_202 = None
        new_empty_strided_default_68 = torch.ops.aten.new_empty_strided.default(copy__default_231, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_233 = torch.ops.aten.copy_.default(new_empty_strided_default_68, copy__default_231);  new_empty_strided_default_68 = copy__default_231 = None
        as_strided_default_204 = torch.ops.aten.as_strided.default(copy__default_233, [24, 256, 257], [525312, 513, 1], 394240)
        clone_default_233 = torch.ops.aten.clone.default(as_strided_default_204, memory_format = torch.contiguous_format);  as_strided_default_204 = None
        slice_backward_default_203 = torch.ops.aten.slice_backward.default(clone_default_233, [24, 256, 513], 2, 0, 257, 1);  clone_default_233 = None
        slice_backward_default_204 = torch.ops.aten.slice_backward.default(slice_backward_default_203, [24, 512, 513], 1, 256, 9223372036854775807, 1);  slice_backward_default_203 = None
        select_backward_default_19 = torch.ops.aten.select_backward.default(slice_backward_default_204, [24, 3, 512, 513], 1, -1);  slice_backward_default_204 = None
        slice_backward_default_205 = torch.ops.aten.slice_backward.default(select_backward_default_19, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_19 = None
        add_tensor_157 = torch.ops.aten.add.Tensor(add_tensor_156, slice_backward_default_205);  add_tensor_156 = slice_backward_default_205 = None
        new_empty_strided_default_69 = torch.ops.aten.new_empty_strided.default(copy__default_233, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_235 = torch.ops.aten.copy_.default(new_empty_strided_default_69, copy__default_233);  new_empty_strided_default_69 = copy__default_233 = None
        as_strided_default_205 = torch.ops.aten.as_strided.default(copy__default_235, [24, 3, 256, 257], [525312, 131328, 513, 1], 256);  copy__default_235 = None
        clone_default_234 = torch.ops.aten.clone.default(as_strided_default_205, memory_format = torch.contiguous_format);  as_strided_default_205 = None
        slice_backward_default_206 = torch.ops.aten.slice_backward.default(clone_default_234, [24, 3, 256, 513], 3, 0, 257, 1);  clone_default_234 = None
        slice_backward_default_207 = torch.ops.aten.slice_backward.default(slice_backward_default_206, [24, 3, 512, 513], 2, 0, 256, 1);  slice_backward_default_206 = None
        slice_backward_default_208 = torch.ops.aten.slice_backward.default(slice_backward_default_207, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_207 = None
        slice_backward_default_209 = torch.ops.aten.slice_backward.default(slice_backward_default_208, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_208 = None
        add_tensor_158 = torch.ops.aten.add.Tensor(add_tensor_157, slice_backward_default_209);  add_tensor_157 = slice_backward_default_209 = None
        view_default_715 = torch.ops.aten.view.default(add_tensor_158, [24, 3, 513, 512]);  add_tensor_158 = None
        constant_pad_nd_default_77 = torch.ops.aten.constant_pad_nd.default(view_default_715, [0, 0, 0, -1]);  view_default_715 = None
        view_default_716 = torch.ops.aten.view.default(constant_pad_nd_default_77, [24, 3, 512, 512, 1]);  constant_pad_nd_default_77 = None
        permute_default_239 = torch.ops.aten.permute.default(view_default_716, [0, 1, 2, 4, 3]);  view_default_716 = None
        view_default_717 = torch.ops.aten.view.default(permute_default_239, [72, 512, 512]);  permute_default_239 = None
        transpose_int_323 = torch.ops.aten.transpose.int(_unsafe_view_default_32, 1, 2);  _unsafe_view_default_32 = None
        bmm_default_62 = torch.ops.aten.bmm.default(transpose_int_323, view_default_717);  transpose_int_323 = None
        transpose_int_324 = torch.ops.aten.transpose.int(_unsafe_view_default_33, 1, 2);  _unsafe_view_default_33 = None
        bmm_default_63 = torch.ops.aten.bmm.default(view_default_717, transpose_int_324);  view_default_717 = transpose_int_324 = None
        view_default_718 = torch.ops.aten.view.default(bmm_default_62, [24, 3, 64, 512, 1]);  bmm_default_62 = None
        permute_default_240 = torch.ops.aten.permute.default(view_default_718, [0, 1, 4, 3, 2]);  view_default_718 = None
        view_default_719 = torch.ops.aten.view.default(bmm_default_63, [24, 3, 512, 64, 1]);  bmm_default_63 = None
        permute_default_241 = torch.ops.aten.permute.default(view_default_719, [0, 1, 2, 4, 3]);  view_default_719 = None
        permute_default_242 = torch.ops.aten.permute.default(permute_default_240, [0, 1, 3, 4, 2]);  permute_default_240 = None
        squeeze_dim_62 = torch.ops.aten.squeeze.dim(permute_default_242, -1);  permute_default_242 = None
        permute_default_243 = torch.ops.aten.permute.default(permute_default_241, [0, 1, 2, 4, 3]);  permute_default_241 = None
        squeeze_dim_63 = torch.ops.aten.squeeze.dim(permute_default_243, -1);  permute_default_243 = None
        new_empty_default_98 = torch.ops.aten.new_empty.default(squeeze_dim_62, [1572864])
        zero__default_68 = torch.ops.aten.zero_.default(new_empty_default_98);  new_empty_default_98 = None
        arange_28 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_206 = torch.ops.aten.as_strided.default(arange_28, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_28 = None
        clone_default_235 = torch.ops.aten.clone.default(as_strided_default_206, memory_format = torch.contiguous_format);  as_strided_default_206 = None
        _unsafe_view_default_213 = torch.ops.aten._unsafe_view.default(clone_default_235, [2359296]);  clone_default_235 = None
        clone_default_236 = torch.ops.aten.clone.default(squeeze_dim_62, memory_format = torch.contiguous_format);  squeeze_dim_62 = None
        _unsafe_view_default_214 = torch.ops.aten._unsafe_view.default(clone_default_236, [2359296]);  clone_default_236 = None
        index_add__default_28 = torch.ops.aten.index_add_.default(zero__default_68, 0, _unsafe_view_default_213, _unsafe_view_default_214);  zero__default_68 = _unsafe_view_default_213 = _unsafe_view_default_214 = None
        as_strided_default_207 = torch.ops.aten.as_strided.default(index_add__default_28, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_28 = None
        view_default_720 = torch.ops.aten.view.default(as_strided_default_207, [24, 1024, 64]);  as_strided_default_207 = None
        new_empty_default_99 = torch.ops.aten.new_empty.default(squeeze_dim_63, [1572864])
        zero__default_69 = torch.ops.aten.zero_.default(new_empty_default_99);  new_empty_default_99 = None
        arange_29 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_208 = torch.ops.aten.as_strided.default(arange_29, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_29 = None
        clone_default_237 = torch.ops.aten.clone.default(as_strided_default_208, memory_format = torch.contiguous_format);  as_strided_default_208 = None
        _unsafe_view_default_215 = torch.ops.aten._unsafe_view.default(clone_default_237, [2359296]);  clone_default_237 = None
        view_default_721 = torch.ops.aten.view.default(squeeze_dim_63, [2359296]);  squeeze_dim_63 = None
        index_add__default_29 = torch.ops.aten.index_add_.default(zero__default_69, 0, _unsafe_view_default_215, view_default_721);  zero__default_69 = _unsafe_view_default_215 = view_default_721 = None
        as_strided_default_209 = torch.ops.aten.as_strided.default(index_add__default_29, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_29 = None
        view_default_722 = torch.ops.aten.view.default(as_strided_default_209, [24, 1024, 64]);  as_strided_default_209 = None
        view_default_723 = torch.ops.aten.view.default(view_default_720, [2, 12, 1024, 64]);  view_default_720 = None
        transpose_int_325 = torch.ops.aten.transpose.int(view_default_723, 1, 2);  view_default_723 = None
        view_default_724 = torch.ops.aten.view.default(view_default_722, [2, 12, 1024, 64]);  view_default_722 = None
        transpose_int_326 = torch.ops.aten.transpose.int(view_default_724, 1, 2);  view_default_724 = None
        transpose_int_327 = torch.ops.aten.transpose.int(transpose_int_325, 0, 1);  transpose_int_325 = None
        view_default_725 = torch.ops.aten.view.default(transpose_int_327, [1024, 2, 768]);  transpose_int_327 = None
        transpose_int_328 = torch.ops.aten.transpose.int(transpose_int_326, 0, 1);  transpose_int_326 = None
        view_default_726 = torch.ops.aten.view.default(transpose_int_328, [1024, 2, 768]);  transpose_int_328 = None
        div_tensor_9 = torch.ops.aten.div.Tensor(view_default_726, 8.0);  view_default_726 = None
        sum_dim_int_list_57 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_212, [0, 1], True)
        view_default_727 = torch.ops.aten.view.default(sum_dim_int_list_57, [768]);  sum_dim_int_list_57 = None
        view_default_728 = torch.ops.aten.view.default(_unsafe_view_default_212, [2048, 768]);  _unsafe_view_default_212 = None
        t_default_300 = torch.ops.aten.t.default(view_default_728)
        mm_default_162 = torch.ops.aten.mm.default(t_default_300, _unsafe_view_default_30);  t_default_300 = _unsafe_view_default_30 = None
        t_default_301 = torch.ops.aten.t.default(mm_default_162);  mm_default_162 = None
        t_default_302 = torch.ops.aten.t.default(t_default_14);  t_default_14 = None
        mm_default_163 = torch.ops.aten.mm.default(view_default_728, t_default_302);  view_default_728 = t_default_302 = None
        view_default_729 = torch.ops.aten.view.default(mm_default_163, [1024, 2, 768]);  mm_default_163 = None
        t_default_303 = torch.ops.aten.t.default(t_default_301);  t_default_301 = None
        sum_dim_int_list_58 = torch.ops.aten.sum.dim_IntList(view_default_725, [0, 1], True)
        view_default_730 = torch.ops.aten.view.default(sum_dim_int_list_58, [768]);  sum_dim_int_list_58 = None
        view_default_731 = torch.ops.aten.view.default(view_default_725, [2048, 768]);  view_default_725 = None
        t_default_304 = torch.ops.aten.t.default(view_default_731)
        mm_default_164 = torch.ops.aten.mm.default(t_default_304, _unsafe_view_default_28);  t_default_304 = _unsafe_view_default_28 = None
        t_default_305 = torch.ops.aten.t.default(mm_default_164);  mm_default_164 = None
        t_default_306 = torch.ops.aten.t.default(t_default_13);  t_default_13 = None
        mm_default_165 = torch.ops.aten.mm.default(view_default_731, t_default_306);  view_default_731 = t_default_306 = None
        view_default_732 = torch.ops.aten.view.default(mm_default_165, [1024, 2, 768]);  mm_default_165 = None
        add_tensor_159 = torch.ops.aten.add.Tensor(view_default_729, view_default_732);  view_default_729 = view_default_732 = None
        t_default_307 = torch.ops.aten.t.default(t_default_305);  t_default_305 = None
        sum_dim_int_list_59 = torch.ops.aten.sum.dim_IntList(div_tensor_9, [0, 1], True)
        view_default_733 = torch.ops.aten.view.default(sum_dim_int_list_59, [768]);  sum_dim_int_list_59 = None
        view_default_734 = torch.ops.aten.view.default(div_tensor_9, [2048, 768]);  div_tensor_9 = None
        t_default_308 = torch.ops.aten.t.default(view_default_734)
        mm_default_166 = torch.ops.aten.mm.default(t_default_308, _unsafe_view_default_26);  t_default_308 = _unsafe_view_default_26 = None
        t_default_309 = torch.ops.aten.t.default(mm_default_166);  mm_default_166 = None
        t_default_310 = torch.ops.aten.t.default(t_default_12);  t_default_12 = None
        mm_default_167 = torch.ops.aten.mm.default(view_default_734, t_default_310);  view_default_734 = t_default_310 = None
        view_default_735 = torch.ops.aten.view.default(mm_default_167, [1024, 2, 768]);  mm_default_167 = None
        add_tensor_160 = torch.ops.aten.add.Tensor(add_tensor_159, view_default_735);  add_tensor_159 = view_default_735 = None
        t_default_311 = torch.ops.aten.t.default(t_default_309);  t_default_309 = None
        transpose_int_329 = torch.ops.aten.transpose.int(add_tensor_160, 0, 1);  add_tensor_160 = None
        add_tensor_161 = torch.ops.aten.add.Tensor(getitem_129, transpose_int_329);  getitem_129 = transpose_int_329 = None
        native_layer_norm_backward_default_20 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_161, add_tensor_11, [768], getitem_10, getitem_11, primals_62, primals_61, [True, True, True]);  add_tensor_161 = add_tensor_11 = getitem_10 = getitem_11 = primals_62 = primals_61 = None
        getitem_132 = native_layer_norm_backward_default_20[0]
        getitem_133 = native_layer_norm_backward_default_20[1]
        getitem_134 = native_layer_norm_backward_default_20[2];  native_layer_norm_backward_default_20 = None
        view_default_736 = torch.ops.aten.view.default(getitem_132, [2048, 768])
        t_default_312 = torch.ops.aten.t.default(t_default_11);  t_default_11 = None
        mm_default_168 = torch.ops.aten.mm.default(view_default_736, t_default_312);  t_default_312 = None
        t_default_313 = torch.ops.aten.t.default(view_default_736)
        mm_default_169 = torch.ops.aten.mm.default(t_default_313, view_default_54);  t_default_313 = view_default_54 = None
        t_default_314 = torch.ops.aten.t.default(mm_default_169);  mm_default_169 = None
        sum_dim_int_list_60 = torch.ops.aten.sum.dim_IntList(view_default_736, [0], True);  view_default_736 = None
        view_default_737 = torch.ops.aten.view.default(sum_dim_int_list_60, [768]);  sum_dim_int_list_60 = None
        t_default_315 = torch.ops.aten.t.default(t_default_314);  t_default_314 = None
        view_default_738 = torch.ops.aten.view.default(mm_default_168, [2, 1024, 3072]);  mm_default_168 = None
        to_dtype_30 = torch.ops.aten.to.dtype(view_default_738, torch.float32);  view_default_738 = None
        to_dtype_31 = torch.ops.aten.to.dtype(view_default_53, torch.float32);  view_default_53 = None
        mul_tensor_82 = torch.ops.aten.mul.Tensor(to_dtype_31, 0.7071067811865476)
        erf_default_10 = torch.ops.aten.erf.default(mul_tensor_82);  mul_tensor_82 = None
        add_tensor_162 = torch.ops.aten.add.Tensor(erf_default_10, 1);  erf_default_10 = None
        mul_tensor_83 = torch.ops.aten.mul.Tensor(add_tensor_162, 0.5);  add_tensor_162 = None
        mul_tensor_84 = torch.ops.aten.mul.Tensor(to_dtype_31, to_dtype_31)
        mul_tensor_85 = torch.ops.aten.mul.Tensor(mul_tensor_84, -0.5);  mul_tensor_84 = None
        exp_default_10 = torch.ops.aten.exp.default(mul_tensor_85);  mul_tensor_85 = None
        mul_tensor_86 = torch.ops.aten.mul.Tensor(exp_default_10, 0.3989422804014327);  exp_default_10 = None
        mul_tensor_87 = torch.ops.aten.mul.Tensor(to_dtype_31, mul_tensor_86);  to_dtype_31 = mul_tensor_86 = None
        add_tensor_163 = torch.ops.aten.add.Tensor(mul_tensor_83, mul_tensor_87);  mul_tensor_83 = mul_tensor_87 = None
        mul_tensor_88 = torch.ops.aten.mul.Tensor(to_dtype_30, add_tensor_163);  to_dtype_30 = add_tensor_163 = None
        to_dtype_32 = torch.ops.aten.to.dtype(mul_tensor_88, torch.float32);  mul_tensor_88 = None
        view_default_739 = torch.ops.aten.view.default(to_dtype_32, [2048, 3072]);  to_dtype_32 = None
        t_default_316 = torch.ops.aten.t.default(t_default_10);  t_default_10 = None
        mm_default_170 = torch.ops.aten.mm.default(view_default_739, t_default_316);  t_default_316 = None
        t_default_317 = torch.ops.aten.t.default(view_default_739)
        mm_default_171 = torch.ops.aten.mm.default(t_default_317, view_default_52);  t_default_317 = view_default_52 = None
        t_default_318 = torch.ops.aten.t.default(mm_default_171);  mm_default_171 = None
        sum_dim_int_list_61 = torch.ops.aten.sum.dim_IntList(view_default_739, [0], True);  view_default_739 = None
        view_default_740 = torch.ops.aten.view.default(sum_dim_int_list_61, [3072]);  sum_dim_int_list_61 = None
        t_default_319 = torch.ops.aten.t.default(t_default_318);  t_default_318 = None
        view_default_741 = torch.ops.aten.view.default(mm_default_170, [2, 1024, 768]);  mm_default_170 = None
        add_tensor_164 = torch.ops.aten.add.Tensor(getitem_132, view_default_741);  getitem_132 = view_default_741 = None
        native_layer_norm_backward_default_21 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_164, add_tensor_10, [768], getitem_7, getitem_8, primals_50, primals_49, [True, True, True]);  add_tensor_164 = add_tensor_10 = getitem_7 = getitem_8 = primals_50 = primals_49 = None
        getitem_135 = native_layer_norm_backward_default_21[0]
        getitem_136 = native_layer_norm_backward_default_21[1]
        getitem_137 = native_layer_norm_backward_default_21[2];  native_layer_norm_backward_default_21 = None
        sum_dim_int_list_62 = torch.ops.aten.sum.dim_IntList(getitem_135, [0, 1], True)
        view_default_742 = torch.ops.aten.view.default(sum_dim_int_list_62, [768]);  sum_dim_int_list_62 = None
        view_default_743 = torch.ops.aten.view.default(getitem_135, [2048, 768])
        t_default_320 = torch.ops.aten.t.default(view_default_743)
        mm_default_172 = torch.ops.aten.mm.default(t_default_320, _unsafe_view_default_24);  t_default_320 = _unsafe_view_default_24 = None
        t_default_321 = torch.ops.aten.t.default(mm_default_172);  mm_default_172 = None
        t_default_322 = torch.ops.aten.t.default(t_default_9);  t_default_9 = None
        mm_default_173 = torch.ops.aten.mm.default(view_default_743, t_default_322);  view_default_743 = t_default_322 = None
        view_default_744 = torch.ops.aten.view.default(mm_default_173, [2, 1024, 768]);  mm_default_173 = None
        t_default_323 = torch.ops.aten.t.default(t_default_321);  t_default_321 = None
        transpose_int_330 = torch.ops.aten.transpose.int(view_default_744, 0, 1);  view_default_744 = None
        view_default_745 = torch.ops.aten.view.default(transpose_int_330, [1024, 2, 12, 64]);  transpose_int_330 = None
        transpose_int_331 = torch.ops.aten.transpose.int(view_default_745, 0, 1);  view_default_745 = None
        transpose_int_332 = torch.ops.aten.transpose.int(transpose_int_331, 1, 2);  transpose_int_331 = None
        clone_default_238 = torch.ops.aten.clone.default(transpose_int_332, memory_format = torch.contiguous_format);  transpose_int_332 = None
        _unsafe_view_default_216 = torch.ops.aten._unsafe_view.default(clone_default_238, [24, 4, 256, 64]);  clone_default_238 = None
        view_default_746 = torch.ops.aten.view.default(_unsafe_view_default_216, [24, 4, 256, 64, 1]);  _unsafe_view_default_216 = None
        permute_default_244 = torch.ops.aten.permute.default(view_default_746, [0, 1, 2, 4, 3]);  view_default_746 = None
        view_default_747 = torch.ops.aten.view.default(permute_default_244, [96, 256, 64]);  permute_default_244 = None
        transpose_int_333 = torch.ops.aten.transpose.int(view_default_48, 1, 2);  view_default_48 = None
        bmm_default_64 = torch.ops.aten.bmm.default(transpose_int_333, view_default_747);  transpose_int_333 = None
        transpose_int_334 = torch.ops.aten.transpose.int(_unsafe_view_default_22, 1, 2);  _unsafe_view_default_22 = None
        bmm_default_65 = torch.ops.aten.bmm.default(view_default_747, transpose_int_334);  view_default_747 = transpose_int_334 = None
        view_default_748 = torch.ops.aten.view.default(bmm_default_64, [24, 4, 768, 64, 1]);  bmm_default_64 = None
        permute_default_245 = torch.ops.aten.permute.default(view_default_748, [0, 1, 4, 3, 2]);  view_default_748 = None
        view_default_749 = torch.ops.aten.view.default(bmm_default_65, [24, 4, 256, 768, 1]);  bmm_default_65 = None
        permute_default_246 = torch.ops.aten.permute.default(view_default_749, [0, 1, 2, 4, 3]);  view_default_749 = None
        permute_default_247 = torch.ops.aten.permute.default(permute_default_245, [0, 1, 4, 3, 2]);  permute_default_245 = None
        squeeze_dim_64 = torch.ops.aten.squeeze.dim(permute_default_247, -1);  permute_default_247 = None
        permute_default_248 = torch.ops.aten.permute.default(permute_default_246, [0, 1, 2, 4, 3]);  permute_default_246 = None
        squeeze_dim_65 = torch.ops.aten.squeeze.dim(permute_default_248, -1);  permute_default_248 = None
        slice_backward_default_210 = torch.ops.aten.slice_backward.default(squeeze_dim_65, [24, 4, 256, 769], 3, 0, -1, 1);  squeeze_dim_65 = None
        slice_backward_default_211 = torch.ops.aten.slice_backward.default(slice_backward_default_210, [24, 4, 256, 769], 2, 0, 9223372036854775807, 1);  slice_backward_default_210 = None
        slice_backward_default_212 = torch.ops.aten.slice_backward.default(slice_backward_default_211, [24, 4, 256, 769], 1, 0, 9223372036854775807, 1);  slice_backward_default_211 = None
        slice_backward_default_213 = torch.ops.aten.slice_backward.default(slice_backward_default_212, [24, 4, 256, 769], 0, 0, 9223372036854775807, 1);  slice_backward_default_212 = None
        view_default_750 = torch.ops.aten.view.default(slice_backward_default_213, [24, 4, 196864]);  slice_backward_default_213 = None
        slice_backward_default_214 = torch.ops.aten.slice_backward.default(view_default_750, [24, 4, 197120], 2, 0, -256, 1);  view_default_750 = None
        slice_backward_default_215 = torch.ops.aten.slice_backward.default(slice_backward_default_214, [24, 4, 197120], 1, 0, 9223372036854775807, 1);  slice_backward_default_214 = None
        slice_backward_default_216 = torch.ops.aten.slice_backward.default(slice_backward_default_215, [24, 4, 197120], 0, 0, 9223372036854775807, 1);  slice_backward_default_215 = None
        view_default_751 = torch.ops.aten.view.default(slice_backward_default_216, [24, 4, 256, 770]);  slice_backward_default_216 = None
        constant_pad_nd_default_78 = torch.ops.aten.constant_pad_nd.default(view_default_751, [0, -257]);  view_default_751 = None
        new_empty_default_100 = torch.ops.aten.new_empty.default(squeeze_dim_64, [2359296])
        zero__default_70 = torch.ops.aten.zero_.default(new_empty_default_100);  new_empty_default_100 = None
        arange_30 = torch.ops.aten.arange.start(0, 2359296, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_210 = torch.ops.aten.as_strided.default(arange_30, [24, 4, 768, 64], [98304, 16384, 64, 1], 0);  arange_30 = None
        clone_default_239 = torch.ops.aten.clone.default(as_strided_default_210, memory_format = torch.contiguous_format);  as_strided_default_210 = None
        _unsafe_view_default_217 = torch.ops.aten._unsafe_view.default(clone_default_239, [4718592]);  clone_default_239 = None
        view_default_752 = torch.ops.aten.view.default(squeeze_dim_64, [4718592]);  squeeze_dim_64 = None
        index_add__default_30 = torch.ops.aten.index_add_.default(zero__default_70, 0, _unsafe_view_default_217, view_default_752);  zero__default_70 = _unsafe_view_default_217 = view_default_752 = None
        as_strided_default_211 = torch.ops.aten.as_strided.default(index_add__default_30, [24, 1536, 64], [98304, 64, 1], 0);  index_add__default_30 = None
        constant_pad_nd_default_79 = torch.ops.aten.constant_pad_nd.default(as_strided_default_211, [0, 0, -256, -256]);  as_strided_default_211 = None
        view_default_753 = torch.ops.aten.view.default(constant_pad_nd_default_79, [2, 12, 1024, 64]);  constant_pad_nd_default_79 = None
        transpose_int_335 = torch.ops.aten.transpose.int(view_default_753, 1, 2);  view_default_753 = None
        view_default_754 = torch.ops.aten.view.default(constant_pad_nd_default_78, [2, 12, 1024, 513]);  constant_pad_nd_default_78 = None
        transpose_int_336 = torch.ops.aten.transpose.int(view_default_754, 1, 2);  view_default_754 = None
        transpose_int_337 = torch.ops.aten.transpose.int(transpose_int_335, 0, 1);  transpose_int_335 = None
        clone_default_240 = torch.ops.aten.clone.default(transpose_int_337, memory_format = torch.contiguous_format);  transpose_int_337 = None
        _unsafe_view_default_218 = torch.ops.aten._unsafe_view.default(clone_default_240, [1024, 2, 768]);  clone_default_240 = None
        where_scalar_self_54 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_25, 0.0, transpose_int_336);  unsqueeze_default_25 = transpose_int_336 = None
        _softmax_backward_data_default_10 = torch.ops.aten._softmax_backward_data.default(where_scalar_self_54, _softmax_default_1, -1, torch.float32);  where_scalar_self_54 = _softmax_default_1 = None
        new_empty_default_101 = torch.ops.aten.new_empty.default(_softmax_backward_data_default_10, [12607488]);  _softmax_backward_data_default_10 = None
        zero__default_71 = torch.ops.aten.zero_.default(new_empty_default_101);  new_empty_default_101 = None
        as_strided_default_213 = torch.ops.aten.as_strided.default(zero__default_71, [24, 4, 256, 513], [525312, 131328, 513, 1], 0);  zero__default_71 = None
        new_empty_strided_default_70 = torch.ops.aten.new_empty_strided.default(as_strided_default_213, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_237 = torch.ops.aten.copy_.default(new_empty_strided_default_70, as_strided_default_213);  new_empty_strided_default_70 = as_strided_default_213 = None
        new_empty_strided_default_71 = torch.ops.aten.new_empty_strided.default(copy__default_237, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_239 = torch.ops.aten.copy_.default(new_empty_strided_default_71, copy__default_237);  new_empty_strided_default_71 = copy__default_237 = None
        new_empty_strided_default_72 = torch.ops.aten.new_empty_strided.default(copy__default_239, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_241 = torch.ops.aten.copy_.default(new_empty_strided_default_72, copy__default_239);  new_empty_strided_default_72 = copy__default_239 = None
        new_empty_strided_default_73 = torch.ops.aten.new_empty_strided.default(copy__default_241, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_243 = torch.ops.aten.copy_.default(new_empty_strided_default_73, copy__default_241);  new_empty_strided_default_73 = copy__default_241 = None
        as_strided_default_217 = torch.ops.aten.as_strided.default(copy__default_243, [24, 255, 255], [525312, 513, 1], 514)
        clone_default_244 = torch.ops.aten.clone.default(as_strided_default_217, memory_format = torch.contiguous_format);  as_strided_default_217 = None
        slice_backward_default_217 = torch.ops.aten.slice_backward.default(clone_default_244, [24, 255, 513], 2, -255, 9223372036854775807, 1);  clone_default_244 = None
        slice_backward_default_218 = torch.ops.aten.slice_backward.default(slice_backward_default_217, [24, 512, 513], 1, 0, 255, 1);  slice_backward_default_217 = None
        select_backward_default_20 = torch.ops.aten.select_backward.default(slice_backward_default_218, [24, 3, 512, 513], 1, 0);  slice_backward_default_218 = None
        slice_backward_default_219 = torch.ops.aten.slice_backward.default(select_backward_default_20, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_20 = None
        new_empty_strided_default_74 = torch.ops.aten.new_empty_strided.default(copy__default_243, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_245 = torch.ops.aten.copy_.default(new_empty_strided_default_74, copy__default_243);  new_empty_strided_default_74 = copy__default_243 = None
        as_strided_default_218 = torch.ops.aten.as_strided.default(copy__default_245, [24, 3, 256, 256], [525312, 131328, 513, 1], 131328)
        clone_default_245 = torch.ops.aten.clone.default(as_strided_default_218, memory_format = torch.contiguous_format);  as_strided_default_218 = None
        slice_backward_default_220 = torch.ops.aten.slice_backward.default(clone_default_245, [24, 3, 256, 513], 3, 257, 9223372036854775807, 1);  clone_default_245 = None
        slice_backward_default_221 = torch.ops.aten.slice_backward.default(slice_backward_default_220, [24, 3, 512, 513], 2, -257, -1, 1);  slice_backward_default_220 = None
        slice_backward_default_222 = torch.ops.aten.slice_backward.default(slice_backward_default_221, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_221 = None
        slice_backward_default_223 = torch.ops.aten.slice_backward.default(slice_backward_default_222, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_222 = None
        add_tensor_165 = torch.ops.aten.add.Tensor(slice_backward_default_219, slice_backward_default_223);  slice_backward_default_219 = slice_backward_default_223 = None
        new_empty_strided_default_75 = torch.ops.aten.new_empty_strided.default(copy__default_245, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_247 = torch.ops.aten.copy_.default(new_empty_strided_default_75, copy__default_245);  new_empty_strided_default_75 = copy__default_245 = None
        as_strided_default_219 = torch.ops.aten.as_strided.default(copy__default_247, [24, 256, 257], [525312, 513, 1], 394240)
        clone_default_246 = torch.ops.aten.clone.default(as_strided_default_219, memory_format = torch.contiguous_format);  as_strided_default_219 = None
        slice_backward_default_224 = torch.ops.aten.slice_backward.default(clone_default_246, [24, 256, 513], 2, 0, 257, 1);  clone_default_246 = None
        slice_backward_default_225 = torch.ops.aten.slice_backward.default(slice_backward_default_224, [24, 512, 513], 1, 256, 9223372036854775807, 1);  slice_backward_default_224 = None
        select_backward_default_21 = torch.ops.aten.select_backward.default(slice_backward_default_225, [24, 3, 512, 513], 1, -1);  slice_backward_default_225 = None
        slice_backward_default_226 = torch.ops.aten.slice_backward.default(select_backward_default_21, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_21 = None
        add_tensor_166 = torch.ops.aten.add.Tensor(add_tensor_165, slice_backward_default_226);  add_tensor_165 = slice_backward_default_226 = None
        new_empty_strided_default_76 = torch.ops.aten.new_empty_strided.default(copy__default_247, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_249 = torch.ops.aten.copy_.default(new_empty_strided_default_76, copy__default_247);  new_empty_strided_default_76 = copy__default_247 = None
        as_strided_default_220 = torch.ops.aten.as_strided.default(copy__default_249, [24, 3, 256, 257], [525312, 131328, 513, 1], 256);  copy__default_249 = None
        clone_default_247 = torch.ops.aten.clone.default(as_strided_default_220, memory_format = torch.contiguous_format);  as_strided_default_220 = None
        slice_backward_default_227 = torch.ops.aten.slice_backward.default(clone_default_247, [24, 3, 256, 513], 3, 0, 257, 1);  clone_default_247 = None
        slice_backward_default_228 = torch.ops.aten.slice_backward.default(slice_backward_default_227, [24, 3, 512, 513], 2, 0, 256, 1);  slice_backward_default_227 = None
        slice_backward_default_229 = torch.ops.aten.slice_backward.default(slice_backward_default_228, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_228 = None
        slice_backward_default_230 = torch.ops.aten.slice_backward.default(slice_backward_default_229, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_229 = None
        add_tensor_167 = torch.ops.aten.add.Tensor(add_tensor_166, slice_backward_default_230);  add_tensor_166 = slice_backward_default_230 = None
        view_default_755 = torch.ops.aten.view.default(add_tensor_167, [24, 3, 513, 512]);  add_tensor_167 = None
        constant_pad_nd_default_80 = torch.ops.aten.constant_pad_nd.default(view_default_755, [0, 0, 0, -1]);  view_default_755 = None
        view_default_756 = torch.ops.aten.view.default(constant_pad_nd_default_80, [24, 3, 512, 512, 1]);  constant_pad_nd_default_80 = None
        permute_default_249 = torch.ops.aten.permute.default(view_default_756, [0, 1, 2, 4, 3]);  view_default_756 = None
        view_default_757 = torch.ops.aten.view.default(permute_default_249, [72, 512, 512]);  permute_default_249 = None
        transpose_int_338 = torch.ops.aten.transpose.int(_unsafe_view_default_19, 1, 2);  _unsafe_view_default_19 = None
        bmm_default_66 = torch.ops.aten.bmm.default(transpose_int_338, view_default_757);  transpose_int_338 = None
        transpose_int_339 = torch.ops.aten.transpose.int(_unsafe_view_default_20, 1, 2);  _unsafe_view_default_20 = None
        bmm_default_67 = torch.ops.aten.bmm.default(view_default_757, transpose_int_339);  view_default_757 = transpose_int_339 = None
        view_default_758 = torch.ops.aten.view.default(bmm_default_66, [24, 3, 64, 512, 1]);  bmm_default_66 = None
        permute_default_250 = torch.ops.aten.permute.default(view_default_758, [0, 1, 4, 3, 2]);  view_default_758 = None
        view_default_759 = torch.ops.aten.view.default(bmm_default_67, [24, 3, 512, 64, 1]);  bmm_default_67 = None
        permute_default_251 = torch.ops.aten.permute.default(view_default_759, [0, 1, 2, 4, 3]);  view_default_759 = None
        permute_default_252 = torch.ops.aten.permute.default(permute_default_250, [0, 1, 3, 4, 2]);  permute_default_250 = None
        squeeze_dim_66 = torch.ops.aten.squeeze.dim(permute_default_252, -1);  permute_default_252 = None
        permute_default_253 = torch.ops.aten.permute.default(permute_default_251, [0, 1, 2, 4, 3]);  permute_default_251 = None
        squeeze_dim_67 = torch.ops.aten.squeeze.dim(permute_default_253, -1);  permute_default_253 = None
        new_empty_default_102 = torch.ops.aten.new_empty.default(squeeze_dim_66, [1572864])
        zero__default_75 = torch.ops.aten.zero_.default(new_empty_default_102);  new_empty_default_102 = None
        arange_31 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_221 = torch.ops.aten.as_strided.default(arange_31, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_31 = None
        clone_default_248 = torch.ops.aten.clone.default(as_strided_default_221, memory_format = torch.contiguous_format);  as_strided_default_221 = None
        _unsafe_view_default_219 = torch.ops.aten._unsafe_view.default(clone_default_248, [2359296]);  clone_default_248 = None
        clone_default_249 = torch.ops.aten.clone.default(squeeze_dim_66, memory_format = torch.contiguous_format);  squeeze_dim_66 = None
        _unsafe_view_default_220 = torch.ops.aten._unsafe_view.default(clone_default_249, [2359296]);  clone_default_249 = None
        index_add__default_31 = torch.ops.aten.index_add_.default(zero__default_75, 0, _unsafe_view_default_219, _unsafe_view_default_220);  zero__default_75 = _unsafe_view_default_219 = _unsafe_view_default_220 = None
        as_strided_default_222 = torch.ops.aten.as_strided.default(index_add__default_31, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_31 = None
        view_default_760 = torch.ops.aten.view.default(as_strided_default_222, [24, 1024, 64]);  as_strided_default_222 = None
        new_empty_default_103 = torch.ops.aten.new_empty.default(squeeze_dim_67, [1572864])
        zero__default_76 = torch.ops.aten.zero_.default(new_empty_default_103);  new_empty_default_103 = None
        arange_32 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_223 = torch.ops.aten.as_strided.default(arange_32, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_32 = None
        clone_default_250 = torch.ops.aten.clone.default(as_strided_default_223, memory_format = torch.contiguous_format);  as_strided_default_223 = None
        _unsafe_view_default_221 = torch.ops.aten._unsafe_view.default(clone_default_250, [2359296]);  clone_default_250 = None
        view_default_761 = torch.ops.aten.view.default(squeeze_dim_67, [2359296]);  squeeze_dim_67 = None
        index_add__default_32 = torch.ops.aten.index_add_.default(zero__default_76, 0, _unsafe_view_default_221, view_default_761);  zero__default_76 = _unsafe_view_default_221 = view_default_761 = None
        as_strided_default_224 = torch.ops.aten.as_strided.default(index_add__default_32, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_32 = None
        view_default_762 = torch.ops.aten.view.default(as_strided_default_224, [24, 1024, 64]);  as_strided_default_224 = None
        view_default_763 = torch.ops.aten.view.default(view_default_760, [2, 12, 1024, 64]);  view_default_760 = None
        transpose_int_340 = torch.ops.aten.transpose.int(view_default_763, 1, 2);  view_default_763 = None
        view_default_764 = torch.ops.aten.view.default(view_default_762, [2, 12, 1024, 64]);  view_default_762 = None
        transpose_int_341 = torch.ops.aten.transpose.int(view_default_764, 1, 2);  view_default_764 = None
        transpose_int_342 = torch.ops.aten.transpose.int(transpose_int_340, 0, 1);  transpose_int_340 = None
        view_default_765 = torch.ops.aten.view.default(transpose_int_342, [1024, 2, 768]);  transpose_int_342 = None
        transpose_int_343 = torch.ops.aten.transpose.int(transpose_int_341, 0, 1);  transpose_int_341 = None
        view_default_766 = torch.ops.aten.view.default(transpose_int_343, [1024, 2, 768]);  transpose_int_343 = None
        div_tensor_10 = torch.ops.aten.div.Tensor(view_default_766, 8.0);  view_default_766 = None
        sum_dim_int_list_63 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_218, [0, 1], True)
        view_default_767 = torch.ops.aten.view.default(sum_dim_int_list_63, [768]);  sum_dim_int_list_63 = None
        view_default_768 = torch.ops.aten.view.default(_unsafe_view_default_218, [2048, 768]);  _unsafe_view_default_218 = None
        t_default_324 = torch.ops.aten.t.default(view_default_768)
        mm_default_174 = torch.ops.aten.mm.default(t_default_324, _unsafe_view_default_17);  t_default_324 = _unsafe_view_default_17 = None
        t_default_325 = torch.ops.aten.t.default(mm_default_174);  mm_default_174 = None
        t_default_326 = torch.ops.aten.t.default(t_default_8);  t_default_8 = None
        mm_default_175 = torch.ops.aten.mm.default(view_default_768, t_default_326);  view_default_768 = t_default_326 = None
        view_default_769 = torch.ops.aten.view.default(mm_default_175, [1024, 2, 768]);  mm_default_175 = None
        t_default_327 = torch.ops.aten.t.default(t_default_325);  t_default_325 = None
        sum_dim_int_list_64 = torch.ops.aten.sum.dim_IntList(view_default_765, [0, 1], True)
        view_default_770 = torch.ops.aten.view.default(sum_dim_int_list_64, [768]);  sum_dim_int_list_64 = None
        view_default_771 = torch.ops.aten.view.default(view_default_765, [2048, 768]);  view_default_765 = None
        t_default_328 = torch.ops.aten.t.default(view_default_771)
        mm_default_176 = torch.ops.aten.mm.default(t_default_328, _unsafe_view_default_15);  t_default_328 = _unsafe_view_default_15 = None
        t_default_329 = torch.ops.aten.t.default(mm_default_176);  mm_default_176 = None
        t_default_330 = torch.ops.aten.t.default(t_default_7);  t_default_7 = None
        mm_default_177 = torch.ops.aten.mm.default(view_default_771, t_default_330);  view_default_771 = t_default_330 = None
        view_default_772 = torch.ops.aten.view.default(mm_default_177, [1024, 2, 768]);  mm_default_177 = None
        add_tensor_168 = torch.ops.aten.add.Tensor(view_default_769, view_default_772);  view_default_769 = view_default_772 = None
        t_default_331 = torch.ops.aten.t.default(t_default_329);  t_default_329 = None
        sum_dim_int_list_65 = torch.ops.aten.sum.dim_IntList(div_tensor_10, [0, 1], True)
        view_default_773 = torch.ops.aten.view.default(sum_dim_int_list_65, [768]);  sum_dim_int_list_65 = None
        view_default_774 = torch.ops.aten.view.default(div_tensor_10, [2048, 768]);  div_tensor_10 = None
        t_default_332 = torch.ops.aten.t.default(view_default_774)
        mm_default_178 = torch.ops.aten.mm.default(t_default_332, _unsafe_view_default_13);  t_default_332 = _unsafe_view_default_13 = None
        t_default_333 = torch.ops.aten.t.default(mm_default_178);  mm_default_178 = None
        t_default_334 = torch.ops.aten.t.default(t_default_6);  t_default_6 = None
        mm_default_179 = torch.ops.aten.mm.default(view_default_774, t_default_334);  view_default_774 = t_default_334 = None
        view_default_775 = torch.ops.aten.view.default(mm_default_179, [1024, 2, 768]);  mm_default_179 = None
        add_tensor_169 = torch.ops.aten.add.Tensor(add_tensor_168, view_default_775);  add_tensor_168 = view_default_775 = None
        t_default_335 = torch.ops.aten.t.default(t_default_333);  t_default_333 = None
        transpose_int_344 = torch.ops.aten.transpose.int(add_tensor_169, 0, 1);  add_tensor_169 = None
        add_tensor_170 = torch.ops.aten.add.Tensor(getitem_135, transpose_int_344);  getitem_135 = transpose_int_344 = None
        native_layer_norm_backward_default_22 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_170, add_tensor_5, [768], getitem_4, getitem_5, primals_14, primals_13, [True, True, True]);  add_tensor_170 = add_tensor_5 = getitem_4 = getitem_5 = primals_14 = primals_13 = None
        getitem_138 = native_layer_norm_backward_default_22[0]
        getitem_139 = native_layer_norm_backward_default_22[1]
        getitem_140 = native_layer_norm_backward_default_22[2];  native_layer_norm_backward_default_22 = None
        view_default_776 = torch.ops.aten.view.default(getitem_138, [2048, 768])
        t_default_336 = torch.ops.aten.t.default(t_default_5);  t_default_5 = None
        mm_default_180 = torch.ops.aten.mm.default(view_default_776, t_default_336);  t_default_336 = None
        t_default_337 = torch.ops.aten.t.default(view_default_776)
        mm_default_181 = torch.ops.aten.mm.default(t_default_337, view_default_26);  t_default_337 = view_default_26 = None
        t_default_338 = torch.ops.aten.t.default(mm_default_181);  mm_default_181 = None
        sum_dim_int_list_66 = torch.ops.aten.sum.dim_IntList(view_default_776, [0], True);  view_default_776 = None
        view_default_777 = torch.ops.aten.view.default(sum_dim_int_list_66, [768]);  sum_dim_int_list_66 = None
        t_default_339 = torch.ops.aten.t.default(t_default_338);  t_default_338 = None
        view_default_778 = torch.ops.aten.view.default(mm_default_180, [2, 1024, 3072]);  mm_default_180 = None
        to_dtype_33 = torch.ops.aten.to.dtype(view_default_778, torch.float32);  view_default_778 = None
        to_dtype_34 = torch.ops.aten.to.dtype(view_default_25, torch.float32);  view_default_25 = None
        mul_tensor_89 = torch.ops.aten.mul.Tensor(to_dtype_34, 0.7071067811865476)
        erf_default_11 = torch.ops.aten.erf.default(mul_tensor_89);  mul_tensor_89 = None
        add_tensor_171 = torch.ops.aten.add.Tensor(erf_default_11, 1);  erf_default_11 = None
        mul_tensor_90 = torch.ops.aten.mul.Tensor(add_tensor_171, 0.5);  add_tensor_171 = None
        mul_tensor_91 = torch.ops.aten.mul.Tensor(to_dtype_34, to_dtype_34)
        mul_tensor_92 = torch.ops.aten.mul.Tensor(mul_tensor_91, -0.5);  mul_tensor_91 = None
        exp_default_11 = torch.ops.aten.exp.default(mul_tensor_92);  mul_tensor_92 = None
        mul_tensor_93 = torch.ops.aten.mul.Tensor(exp_default_11, 0.3989422804014327);  exp_default_11 = None
        mul_tensor_94 = torch.ops.aten.mul.Tensor(to_dtype_34, mul_tensor_93);  to_dtype_34 = mul_tensor_93 = None
        add_tensor_172 = torch.ops.aten.add.Tensor(mul_tensor_90, mul_tensor_94);  mul_tensor_90 = mul_tensor_94 = None
        mul_tensor_95 = torch.ops.aten.mul.Tensor(to_dtype_33, add_tensor_172);  to_dtype_33 = add_tensor_172 = None
        to_dtype_35 = torch.ops.aten.to.dtype(mul_tensor_95, torch.float32);  mul_tensor_95 = None
        view_default_779 = torch.ops.aten.view.default(to_dtype_35, [2048, 3072]);  to_dtype_35 = None
        t_default_340 = torch.ops.aten.t.default(t_default_4);  t_default_4 = None
        mm_default_182 = torch.ops.aten.mm.default(view_default_779, t_default_340);  t_default_340 = None
        t_default_341 = torch.ops.aten.t.default(view_default_779)
        mm_default_183 = torch.ops.aten.mm.default(t_default_341, view_default_24);  t_default_341 = view_default_24 = None
        t_default_342 = torch.ops.aten.t.default(mm_default_183);  mm_default_183 = None
        sum_dim_int_list_67 = torch.ops.aten.sum.dim_IntList(view_default_779, [0], True);  view_default_779 = None
        view_default_780 = torch.ops.aten.view.default(sum_dim_int_list_67, [3072]);  sum_dim_int_list_67 = None
        t_default_343 = torch.ops.aten.t.default(t_default_342);  t_default_342 = None
        view_default_781 = torch.ops.aten.view.default(mm_default_182, [2, 1024, 768]);  mm_default_182 = None
        add_tensor_173 = torch.ops.aten.add.Tensor(getitem_138, view_default_781);  getitem_138 = view_default_781 = None
        native_layer_norm_backward_default_23 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_173, add_tensor_4, [768], getitem_1, getitem_2, primals_2, primals_1, [True, True, True]);  add_tensor_173 = add_tensor_4 = getitem_1 = getitem_2 = primals_2 = primals_1 = None
        getitem_141 = native_layer_norm_backward_default_23[0]
        getitem_142 = native_layer_norm_backward_default_23[1]
        getitem_143 = native_layer_norm_backward_default_23[2];  native_layer_norm_backward_default_23 = None
        sum_dim_int_list_68 = torch.ops.aten.sum.dim_IntList(getitem_141, [0, 1], True)
        view_default_782 = torch.ops.aten.view.default(sum_dim_int_list_68, [768]);  sum_dim_int_list_68 = None
        view_default_783 = torch.ops.aten.view.default(getitem_141, [2048, 768])
        t_default_344 = torch.ops.aten.t.default(view_default_783)
        mm_default_184 = torch.ops.aten.mm.default(t_default_344, _unsafe_view_default_11);  t_default_344 = _unsafe_view_default_11 = None
        t_default_345 = torch.ops.aten.t.default(mm_default_184);  mm_default_184 = None
        t_default_346 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        mm_default_185 = torch.ops.aten.mm.default(view_default_783, t_default_346);  view_default_783 = t_default_346 = None
        view_default_784 = torch.ops.aten.view.default(mm_default_185, [2, 1024, 768]);  mm_default_185 = None
        t_default_347 = torch.ops.aten.t.default(t_default_345);  t_default_345 = None
        transpose_int_345 = torch.ops.aten.transpose.int(view_default_784, 0, 1);  view_default_784 = None
        view_default_785 = torch.ops.aten.view.default(transpose_int_345, [1024, 2, 12, 64]);  transpose_int_345 = None
        transpose_int_346 = torch.ops.aten.transpose.int(view_default_785, 0, 1);  view_default_785 = None
        transpose_int_347 = torch.ops.aten.transpose.int(transpose_int_346, 1, 2);  transpose_int_346 = None
        clone_default_251 = torch.ops.aten.clone.default(transpose_int_347, memory_format = torch.contiguous_format);  transpose_int_347 = None
        _unsafe_view_default_222 = torch.ops.aten._unsafe_view.default(clone_default_251, [24, 4, 256, 64]);  clone_default_251 = None
        view_default_786 = torch.ops.aten.view.default(_unsafe_view_default_222, [24, 4, 256, 64, 1]);  _unsafe_view_default_222 = None
        permute_default_254 = torch.ops.aten.permute.default(view_default_786, [0, 1, 2, 4, 3]);  view_default_786 = None
        view_default_787 = torch.ops.aten.view.default(permute_default_254, [96, 256, 64]);  permute_default_254 = None
        transpose_int_348 = torch.ops.aten.transpose.int(view_default_20, 1, 2);  view_default_20 = None
        bmm_default_68 = torch.ops.aten.bmm.default(transpose_int_348, view_default_787);  transpose_int_348 = None
        transpose_int_349 = torch.ops.aten.transpose.int(_unsafe_view_default_9, 1, 2);  _unsafe_view_default_9 = None
        bmm_default_69 = torch.ops.aten.bmm.default(view_default_787, transpose_int_349);  view_default_787 = transpose_int_349 = None
        view_default_788 = torch.ops.aten.view.default(bmm_default_68, [24, 4, 768, 64, 1]);  bmm_default_68 = None
        permute_default_255 = torch.ops.aten.permute.default(view_default_788, [0, 1, 4, 3, 2]);  view_default_788 = None
        view_default_789 = torch.ops.aten.view.default(bmm_default_69, [24, 4, 256, 768, 1]);  bmm_default_69 = None
        permute_default_256 = torch.ops.aten.permute.default(view_default_789, [0, 1, 2, 4, 3]);  view_default_789 = None
        permute_default_257 = torch.ops.aten.permute.default(permute_default_255, [0, 1, 4, 3, 2]);  permute_default_255 = None
        squeeze_dim_68 = torch.ops.aten.squeeze.dim(permute_default_257, -1);  permute_default_257 = None
        permute_default_258 = torch.ops.aten.permute.default(permute_default_256, [0, 1, 2, 4, 3]);  permute_default_256 = None
        squeeze_dim_69 = torch.ops.aten.squeeze.dim(permute_default_258, -1);  permute_default_258 = None
        slice_backward_default_231 = torch.ops.aten.slice_backward.default(squeeze_dim_69, [24, 4, 256, 769], 3, 0, -1, 1);  squeeze_dim_69 = None
        slice_backward_default_232 = torch.ops.aten.slice_backward.default(slice_backward_default_231, [24, 4, 256, 769], 2, 0, 9223372036854775807, 1);  slice_backward_default_231 = None
        slice_backward_default_233 = torch.ops.aten.slice_backward.default(slice_backward_default_232, [24, 4, 256, 769], 1, 0, 9223372036854775807, 1);  slice_backward_default_232 = None
        slice_backward_default_234 = torch.ops.aten.slice_backward.default(slice_backward_default_233, [24, 4, 256, 769], 0, 0, 9223372036854775807, 1);  slice_backward_default_233 = None
        view_default_790 = torch.ops.aten.view.default(slice_backward_default_234, [24, 4, 196864]);  slice_backward_default_234 = None
        slice_backward_default_235 = torch.ops.aten.slice_backward.default(view_default_790, [24, 4, 197120], 2, 0, -256, 1);  view_default_790 = None
        slice_backward_default_236 = torch.ops.aten.slice_backward.default(slice_backward_default_235, [24, 4, 197120], 1, 0, 9223372036854775807, 1);  slice_backward_default_235 = None
        slice_backward_default_237 = torch.ops.aten.slice_backward.default(slice_backward_default_236, [24, 4, 197120], 0, 0, 9223372036854775807, 1);  slice_backward_default_236 = None
        view_default_791 = torch.ops.aten.view.default(slice_backward_default_237, [24, 4, 256, 770]);  slice_backward_default_237 = None
        constant_pad_nd_default_81 = torch.ops.aten.constant_pad_nd.default(view_default_791, [0, -257]);  view_default_791 = None
        new_empty_default_104 = torch.ops.aten.new_empty.default(squeeze_dim_68, [2359296])
        zero__default_77 = torch.ops.aten.zero_.default(new_empty_default_104);  new_empty_default_104 = None
        arange_33 = torch.ops.aten.arange.start(0, 2359296, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_225 = torch.ops.aten.as_strided.default(arange_33, [24, 4, 768, 64], [98304, 16384, 64, 1], 0);  arange_33 = None
        clone_default_252 = torch.ops.aten.clone.default(as_strided_default_225, memory_format = torch.contiguous_format);  as_strided_default_225 = None
        _unsafe_view_default_223 = torch.ops.aten._unsafe_view.default(clone_default_252, [4718592]);  clone_default_252 = None
        view_default_792 = torch.ops.aten.view.default(squeeze_dim_68, [4718592]);  squeeze_dim_68 = None
        index_add__default_33 = torch.ops.aten.index_add_.default(zero__default_77, 0, _unsafe_view_default_223, view_default_792);  zero__default_77 = _unsafe_view_default_223 = view_default_792 = None
        as_strided_default_226 = torch.ops.aten.as_strided.default(index_add__default_33, [24, 1536, 64], [98304, 64, 1], 0);  index_add__default_33 = None
        constant_pad_nd_default_82 = torch.ops.aten.constant_pad_nd.default(as_strided_default_226, [0, 0, -256, -256]);  as_strided_default_226 = None
        view_default_793 = torch.ops.aten.view.default(constant_pad_nd_default_82, [2, 12, 1024, 64]);  constant_pad_nd_default_82 = None
        transpose_int_350 = torch.ops.aten.transpose.int(view_default_793, 1, 2);  view_default_793 = None
        view_default_794 = torch.ops.aten.view.default(constant_pad_nd_default_81, [2, 12, 1024, 513]);  constant_pad_nd_default_81 = None
        transpose_int_351 = torch.ops.aten.transpose.int(view_default_794, 1, 2);  view_default_794 = None
        transpose_int_352 = torch.ops.aten.transpose.int(transpose_int_350, 0, 1);  transpose_int_350 = None
        clone_default_253 = torch.ops.aten.clone.default(transpose_int_352, memory_format = torch.contiguous_format);  transpose_int_352 = None
        _unsafe_view_default_224 = torch.ops.aten._unsafe_view.default(clone_default_253, [1024, 2, 768]);  clone_default_253 = None
        where_scalar_self_57 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_11, 0.0, transpose_int_351);  unsqueeze_default_11 = transpose_int_351 = None
        _softmax_backward_data_default_11 = torch.ops.aten._softmax_backward_data.default(where_scalar_self_57, _softmax_default, -1, torch.float32);  where_scalar_self_57 = _softmax_default = None
        new_empty_default_105 = torch.ops.aten.new_empty.default(_softmax_backward_data_default_11, [12607488]);  _softmax_backward_data_default_11 = None
        zero__default_78 = torch.ops.aten.zero_.default(new_empty_default_105);  new_empty_default_105 = None
        as_strided_default_228 = torch.ops.aten.as_strided.default(zero__default_78, [24, 4, 256, 513], [525312, 131328, 513, 1], 0);  zero__default_78 = None
        new_empty_strided_default_77 = torch.ops.aten.new_empty_strided.default(as_strided_default_228, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_251 = torch.ops.aten.copy_.default(new_empty_strided_default_77, as_strided_default_228);  new_empty_strided_default_77 = as_strided_default_228 = None
        new_empty_strided_default_78 = torch.ops.aten.new_empty_strided.default(copy__default_251, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_253 = torch.ops.aten.copy_.default(new_empty_strided_default_78, copy__default_251);  new_empty_strided_default_78 = copy__default_251 = None
        new_empty_strided_default_79 = torch.ops.aten.new_empty_strided.default(copy__default_253, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_255 = torch.ops.aten.copy_.default(new_empty_strided_default_79, copy__default_253);  new_empty_strided_default_79 = copy__default_253 = None
        new_empty_strided_default_80 = torch.ops.aten.new_empty_strided.default(copy__default_255, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_257 = torch.ops.aten.copy_.default(new_empty_strided_default_80, copy__default_255);  new_empty_strided_default_80 = copy__default_255 = None
        as_strided_default_232 = torch.ops.aten.as_strided.default(copy__default_257, [24, 255, 255], [525312, 513, 1], 514)
        clone_default_257 = torch.ops.aten.clone.default(as_strided_default_232, memory_format = torch.contiguous_format);  as_strided_default_232 = None
        slice_backward_default_238 = torch.ops.aten.slice_backward.default(clone_default_257, [24, 255, 513], 2, -255, 9223372036854775807, 1);  clone_default_257 = None
        slice_backward_default_239 = torch.ops.aten.slice_backward.default(slice_backward_default_238, [24, 512, 513], 1, 0, 255, 1);  slice_backward_default_238 = None
        select_backward_default_22 = torch.ops.aten.select_backward.default(slice_backward_default_239, [24, 3, 512, 513], 1, 0);  slice_backward_default_239 = None
        slice_backward_default_240 = torch.ops.aten.slice_backward.default(select_backward_default_22, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_22 = None
        new_empty_strided_default_81 = torch.ops.aten.new_empty_strided.default(copy__default_257, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_259 = torch.ops.aten.copy_.default(new_empty_strided_default_81, copy__default_257);  new_empty_strided_default_81 = copy__default_257 = None
        as_strided_default_233 = torch.ops.aten.as_strided.default(copy__default_259, [24, 3, 256, 256], [525312, 131328, 513, 1], 131328)
        clone_default_258 = torch.ops.aten.clone.default(as_strided_default_233, memory_format = torch.contiguous_format);  as_strided_default_233 = None
        slice_backward_default_241 = torch.ops.aten.slice_backward.default(clone_default_258, [24, 3, 256, 513], 3, 257, 9223372036854775807, 1);  clone_default_258 = None
        slice_backward_default_242 = torch.ops.aten.slice_backward.default(slice_backward_default_241, [24, 3, 512, 513], 2, -257, -1, 1);  slice_backward_default_241 = None
        slice_backward_default_243 = torch.ops.aten.slice_backward.default(slice_backward_default_242, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_242 = None
        slice_backward_default_244 = torch.ops.aten.slice_backward.default(slice_backward_default_243, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_243 = None
        add_tensor_174 = torch.ops.aten.add.Tensor(slice_backward_default_240, slice_backward_default_244);  slice_backward_default_240 = slice_backward_default_244 = None
        new_empty_strided_default_82 = torch.ops.aten.new_empty_strided.default(copy__default_259, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_261 = torch.ops.aten.copy_.default(new_empty_strided_default_82, copy__default_259);  new_empty_strided_default_82 = copy__default_259 = None
        as_strided_default_234 = torch.ops.aten.as_strided.default(copy__default_261, [24, 256, 257], [525312, 513, 1], 394240)
        clone_default_259 = torch.ops.aten.clone.default(as_strided_default_234, memory_format = torch.contiguous_format);  as_strided_default_234 = None
        slice_backward_default_245 = torch.ops.aten.slice_backward.default(clone_default_259, [24, 256, 513], 2, 0, 257, 1);  clone_default_259 = None
        slice_backward_default_246 = torch.ops.aten.slice_backward.default(slice_backward_default_245, [24, 512, 513], 1, 256, 9223372036854775807, 1);  slice_backward_default_245 = None
        select_backward_default_23 = torch.ops.aten.select_backward.default(slice_backward_default_246, [24, 3, 512, 513], 1, -1);  slice_backward_default_246 = None
        slice_backward_default_247 = torch.ops.aten.slice_backward.default(select_backward_default_23, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_23 = None
        add_tensor_175 = torch.ops.aten.add.Tensor(add_tensor_174, slice_backward_default_247);  add_tensor_174 = slice_backward_default_247 = None
        new_empty_strided_default_83 = torch.ops.aten.new_empty_strided.default(copy__default_261, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_263 = torch.ops.aten.copy_.default(new_empty_strided_default_83, copy__default_261);  new_empty_strided_default_83 = copy__default_261 = None
        as_strided_default_235 = torch.ops.aten.as_strided.default(copy__default_263, [24, 3, 256, 257], [525312, 131328, 513, 1], 256);  copy__default_263 = None
        clone_default_260 = torch.ops.aten.clone.default(as_strided_default_235, memory_format = torch.contiguous_format);  as_strided_default_235 = None
        slice_backward_default_248 = torch.ops.aten.slice_backward.default(clone_default_260, [24, 3, 256, 513], 3, 0, 257, 1);  clone_default_260 = None
        slice_backward_default_249 = torch.ops.aten.slice_backward.default(slice_backward_default_248, [24, 3, 512, 513], 2, 0, 256, 1);  slice_backward_default_248 = None
        slice_backward_default_250 = torch.ops.aten.slice_backward.default(slice_backward_default_249, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_249 = None
        slice_backward_default_251 = torch.ops.aten.slice_backward.default(slice_backward_default_250, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_250 = None
        add_tensor_176 = torch.ops.aten.add.Tensor(add_tensor_175, slice_backward_default_251);  add_tensor_175 = slice_backward_default_251 = None
        view_default_795 = torch.ops.aten.view.default(add_tensor_176, [24, 3, 513, 512]);  add_tensor_176 = None
        constant_pad_nd_default_83 = torch.ops.aten.constant_pad_nd.default(view_default_795, [0, 0, 0, -1]);  view_default_795 = None
        view_default_796 = torch.ops.aten.view.default(constant_pad_nd_default_83, [24, 3, 512, 512, 1]);  constant_pad_nd_default_83 = None
        permute_default_259 = torch.ops.aten.permute.default(view_default_796, [0, 1, 2, 4, 3]);  view_default_796 = None
        view_default_797 = torch.ops.aten.view.default(permute_default_259, [72, 512, 512]);  permute_default_259 = None
        transpose_int_353 = torch.ops.aten.transpose.int(_unsafe_view_default_6, 1, 2);  _unsafe_view_default_6 = None
        bmm_default_70 = torch.ops.aten.bmm.default(transpose_int_353, view_default_797);  transpose_int_353 = None
        transpose_int_354 = torch.ops.aten.transpose.int(_unsafe_view_default_7, 1, 2);  _unsafe_view_default_7 = None
        bmm_default_71 = torch.ops.aten.bmm.default(view_default_797, transpose_int_354);  view_default_797 = transpose_int_354 = None
        view_default_798 = torch.ops.aten.view.default(bmm_default_70, [24, 3, 64, 512, 1]);  bmm_default_70 = None
        permute_default_260 = torch.ops.aten.permute.default(view_default_798, [0, 1, 4, 3, 2]);  view_default_798 = None
        view_default_799 = torch.ops.aten.view.default(bmm_default_71, [24, 3, 512, 64, 1]);  bmm_default_71 = None
        permute_default_261 = torch.ops.aten.permute.default(view_default_799, [0, 1, 2, 4, 3]);  view_default_799 = None
        permute_default_262 = torch.ops.aten.permute.default(permute_default_260, [0, 1, 3, 4, 2]);  permute_default_260 = None
        squeeze_dim_70 = torch.ops.aten.squeeze.dim(permute_default_262, -1);  permute_default_262 = None
        permute_default_263 = torch.ops.aten.permute.default(permute_default_261, [0, 1, 2, 4, 3]);  permute_default_261 = None
        squeeze_dim_71 = torch.ops.aten.squeeze.dim(permute_default_263, -1);  permute_default_263 = None
        new_empty_default_106 = torch.ops.aten.new_empty.default(squeeze_dim_70, [1572864])
        zero__default_82 = torch.ops.aten.zero_.default(new_empty_default_106);  new_empty_default_106 = None
        arange_34 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_236 = torch.ops.aten.as_strided.default(arange_34, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_34 = None
        clone_default_261 = torch.ops.aten.clone.default(as_strided_default_236, memory_format = torch.contiguous_format);  as_strided_default_236 = None
        _unsafe_view_default_225 = torch.ops.aten._unsafe_view.default(clone_default_261, [2359296]);  clone_default_261 = None
        clone_default_262 = torch.ops.aten.clone.default(squeeze_dim_70, memory_format = torch.contiguous_format);  squeeze_dim_70 = None
        _unsafe_view_default_226 = torch.ops.aten._unsafe_view.default(clone_default_262, [2359296]);  clone_default_262 = None
        index_add__default_34 = torch.ops.aten.index_add_.default(zero__default_82, 0, _unsafe_view_default_225, _unsafe_view_default_226);  zero__default_82 = _unsafe_view_default_225 = _unsafe_view_default_226 = None
        as_strided_default_237 = torch.ops.aten.as_strided.default(index_add__default_34, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_34 = None
        view_default_800 = torch.ops.aten.view.default(as_strided_default_237, [24, 1024, 64]);  as_strided_default_237 = None
        new_empty_default_107 = torch.ops.aten.new_empty.default(squeeze_dim_71, [1572864])
        zero__default_83 = torch.ops.aten.zero_.default(new_empty_default_107);  new_empty_default_107 = None
        arange_35 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_238 = torch.ops.aten.as_strided.default(arange_35, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_35 = None
        clone_default_263 = torch.ops.aten.clone.default(as_strided_default_238, memory_format = torch.contiguous_format);  as_strided_default_238 = None
        _unsafe_view_default_227 = torch.ops.aten._unsafe_view.default(clone_default_263, [2359296]);  clone_default_263 = None
        view_default_801 = torch.ops.aten.view.default(squeeze_dim_71, [2359296]);  squeeze_dim_71 = None
        index_add__default_35 = torch.ops.aten.index_add_.default(zero__default_83, 0, _unsafe_view_default_227, view_default_801);  zero__default_83 = _unsafe_view_default_227 = view_default_801 = None
        as_strided_default_239 = torch.ops.aten.as_strided.default(index_add__default_35, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_35 = None
        view_default_802 = torch.ops.aten.view.default(as_strided_default_239, [24, 1024, 64]);  as_strided_default_239 = None
        view_default_803 = torch.ops.aten.view.default(view_default_800, [2, 12, 1024, 64]);  view_default_800 = None
        transpose_int_355 = torch.ops.aten.transpose.int(view_default_803, 1, 2);  view_default_803 = None
        view_default_804 = torch.ops.aten.view.default(view_default_802, [2, 12, 1024, 64]);  view_default_802 = None
        transpose_int_356 = torch.ops.aten.transpose.int(view_default_804, 1, 2);  view_default_804 = None
        transpose_int_357 = torch.ops.aten.transpose.int(transpose_int_355, 0, 1);  transpose_int_355 = None
        view_default_805 = torch.ops.aten.view.default(transpose_int_357, [1024, 2, 768]);  transpose_int_357 = None
        transpose_int_358 = torch.ops.aten.transpose.int(transpose_int_356, 0, 1);  transpose_int_356 = None
        view_default_806 = torch.ops.aten.view.default(transpose_int_358, [1024, 2, 768]);  transpose_int_358 = None
        div_tensor_11 = torch.ops.aten.div.Tensor(view_default_806, 8.0);  view_default_806 = None
        sum_dim_int_list_69 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_224, [0, 1], True)
        view_default_807 = torch.ops.aten.view.default(sum_dim_int_list_69, [768]);  sum_dim_int_list_69 = None
        view_default_808 = torch.ops.aten.view.default(_unsafe_view_default_224, [2048, 768]);  _unsafe_view_default_224 = None
        t_default_348 = torch.ops.aten.t.default(view_default_808)
        mm_default_186 = torch.ops.aten.mm.default(t_default_348, _unsafe_view_default_4);  t_default_348 = _unsafe_view_default_4 = None
        t_default_349 = torch.ops.aten.t.default(mm_default_186);  mm_default_186 = None
        t_default_350 = torch.ops.aten.t.default(t_default_2);  t_default_2 = None
        mm_default_187 = torch.ops.aten.mm.default(view_default_808, t_default_350);  view_default_808 = t_default_350 = None
        view_default_809 = torch.ops.aten.view.default(mm_default_187, [1024, 2, 768]);  mm_default_187 = None
        t_default_351 = torch.ops.aten.t.default(t_default_349);  t_default_349 = None
        sum_dim_int_list_70 = torch.ops.aten.sum.dim_IntList(view_default_805, [0, 1], True)
        view_default_810 = torch.ops.aten.view.default(sum_dim_int_list_70, [768]);  sum_dim_int_list_70 = None
        view_default_811 = torch.ops.aten.view.default(view_default_805, [2048, 768]);  view_default_805 = None
        t_default_352 = torch.ops.aten.t.default(view_default_811)
        mm_default_188 = torch.ops.aten.mm.default(t_default_352, _unsafe_view_default_2);  t_default_352 = _unsafe_view_default_2 = None
        t_default_353 = torch.ops.aten.t.default(mm_default_188);  mm_default_188 = None
        t_default_354 = torch.ops.aten.t.default(t_default_1);  t_default_1 = None
        mm_default_189 = torch.ops.aten.mm.default(view_default_811, t_default_354);  view_default_811 = t_default_354 = None
        view_default_812 = torch.ops.aten.view.default(mm_default_189, [1024, 2, 768]);  mm_default_189 = None
        add_tensor_177 = torch.ops.aten.add.Tensor(view_default_809, view_default_812);  view_default_809 = view_default_812 = None
        t_default_355 = torch.ops.aten.t.default(t_default_353);  t_default_353 = None
        sum_dim_int_list_71 = torch.ops.aten.sum.dim_IntList(div_tensor_11, [0, 1], True)
        view_default_813 = torch.ops.aten.view.default(sum_dim_int_list_71, [768]);  sum_dim_int_list_71 = None
        view_default_814 = torch.ops.aten.view.default(div_tensor_11, [2048, 768]);  div_tensor_11 = None
        t_default_356 = torch.ops.aten.t.default(view_default_814)
        mm_default_190 = torch.ops.aten.mm.default(t_default_356, _unsafe_view_default);  t_default_356 = _unsafe_view_default = None
        t_default_357 = torch.ops.aten.t.default(mm_default_190);  mm_default_190 = None
        t_default_358 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default_191 = torch.ops.aten.mm.default(view_default_814, t_default_358);  view_default_814 = t_default_358 = None
        view_default_815 = torch.ops.aten.view.default(mm_default_191, [1024, 2, 768]);  mm_default_191 = None
        add_tensor_178 = torch.ops.aten.add.Tensor(add_tensor_177, view_default_815);  add_tensor_177 = view_default_815 = None
        t_default_359 = torch.ops.aten.t.default(t_default_357);  t_default_357 = None
        transpose_int_359 = torch.ops.aten.transpose.int(add_tensor_178, 0, 1);  add_tensor_178 = None
        add_tensor_179 = torch.ops.aten.add.Tensor(getitem_141, transpose_int_359);  getitem_141 = transpose_int_359 = None
        return [getitem_143, getitem_142, view_default_782, t_default_347, view_default_810, t_default_355, view_default_813, t_default_359, view_default_807, t_default_351, view_default_780, t_default_343, getitem_140, getitem_139, view_default_777, t_default_339, getitem_83, getitem_82, view_default_382, t_default_107, view_default_410, t_default_115, view_default_413, t_default_119, view_default_407, t_default_111, view_default_380, t_default_103, getitem_80, getitem_79, view_default_377, t_default_99, getitem_77, getitem_76, view_default_342, t_default_83, view_default_370, t_default_91, view_default_373, t_default_95, view_default_367, t_default_87, view_default_340, t_default_79, getitem_74, getitem_73, view_default_337, t_default_75, getitem_137, getitem_136, view_default_742, t_default_323, view_default_770, t_default_331, view_default_773, t_default_335, view_default_767, t_default_327, view_default_740, t_default_319, getitem_134, getitem_133, view_default_737, t_default_315, getitem_131, getitem_130, view_default_702, t_default_299, view_default_730, t_default_307, view_default_733, t_default_311, view_default_727, t_default_303, view_default_700, t_default_295, getitem_128, getitem_127, view_default_697, t_default_291, getitem_125, getitem_124, view_default_662, t_default_275, view_default_690, t_default_283, view_default_693, t_default_287, view_default_687, t_default_279, view_default_660, t_default_271, getitem_122, getitem_121, view_default_657, t_default_267, getitem_119, getitem_118, view_default_622, t_default_251, view_default_650, t_default_259, view_default_653, t_default_263, view_default_647, t_default_255, view_default_620, t_default_247, getitem_116, getitem_115, view_default_617, t_default_243, getitem_113, getitem_112, view_default_582, t_default_227, view_default_610, t_default_235, view_default_613, t_default_239, view_default_607, t_default_231, view_default_580, t_default_223, getitem_110, getitem_109, view_default_577, t_default_219, getitem_107, getitem_106, view_default_542, t_default_203, view_default_570, t_default_211, view_default_573, t_default_215, view_default_567, t_default_207, view_default_540, t_default_199, getitem_104, getitem_103, view_default_537, t_default_195, getitem_101, getitem_100, view_default_502, t_default_179, view_default_530, t_default_187, view_default_533, t_default_191, view_default_527, t_default_183, view_default_500, t_default_175, getitem_98, getitem_97, view_default_497, t_default_171, getitem_95, getitem_94, view_default_462, t_default_155, view_default_490, t_default_163, view_default_493, t_default_167, view_default_487, t_default_159, view_default_460, t_default_151, getitem_92, getitem_91, view_default_457, t_default_147, getitem_89, getitem_88, view_default_422, t_default_131, view_default_450, t_default_139, view_default_453, t_default_143, view_default_447, t_default_135, view_default_420, t_default_127, getitem_86, getitem_85, view_default_417, t_default_123, add_tensor_179, None, None]
        
