
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/hf_Longformer/hf_Longformer_joint_2/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, tangents_1):
        transpose_int = torch.ops.aten.transpose.int(primals_193, 0, 1)
        t_default = torch.ops.aten.t.default(primals_8);  primals_8 = None
        clone_default = torch.ops.aten.clone.default(transpose_int, memory_format = torch.contiguous_format)
        _unsafe_view_default = torch.ops.aten._unsafe_view.default(clone_default, [2048, 768]);  clone_default = None
        mm_default = torch.ops.aten.mm.default(_unsafe_view_default, t_default)
        _unsafe_view_default_1 = torch.ops.aten._unsafe_view.default(mm_default, [1024, 2, 768]);  mm_default = None
        add_tensor = torch.ops.aten.add.Tensor(_unsafe_view_default_1, primals_7);  _unsafe_view_default_1 = primals_7 = None
        t_default_1 = torch.ops.aten.t.default(primals_6);  primals_6 = None
        clone_default_1 = torch.ops.aten.clone.default(transpose_int, memory_format = torch.contiguous_format)
        _unsafe_view_default_2 = torch.ops.aten._unsafe_view.default(clone_default_1, [2048, 768]);  clone_default_1 = None
        mm_default_1 = torch.ops.aten.mm.default(_unsafe_view_default_2, t_default_1)
        _unsafe_view_default_3 = torch.ops.aten._unsafe_view.default(mm_default_1, [1024, 2, 768]);  mm_default_1 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(_unsafe_view_default_3, primals_5);  _unsafe_view_default_3 = primals_5 = None
        t_default_2 = torch.ops.aten.t.default(primals_10);  primals_10 = None
        clone_default_2 = torch.ops.aten.clone.default(transpose_int, memory_format = torch.contiguous_format);  transpose_int = None
        _unsafe_view_default_4 = torch.ops.aten._unsafe_view.default(clone_default_2, [2048, 768]);  clone_default_2 = None
        mm_default_2 = torch.ops.aten.mm.default(_unsafe_view_default_4, t_default_2)
        _unsafe_view_default_5 = torch.ops.aten._unsafe_view.default(mm_default_2, [1024, 2, 768]);  mm_default_2 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(_unsafe_view_default_5, primals_9);  _unsafe_view_default_5 = primals_9 = None
        div__tensor = torch.ops.aten.div_.Tensor(add_tensor, 8.0);  add_tensor = None
        view_default = torch.ops.aten.view.default(div__tensor, [1024, 2, 12, 64]);  div__tensor = None
        transpose_int_1 = torch.ops.aten.transpose.int(view_default, 0, 1);  view_default = None
        view_default_1 = torch.ops.aten.view.default(add_tensor_1, [1024, 2, 12, 64]);  add_tensor_1 = None
        transpose_int_2 = torch.ops.aten.transpose.int(view_default_1, 0, 1);  view_default_1 = None
        transpose_int_3 = torch.ops.aten.transpose.int(transpose_int_1, 1, 2);  transpose_int_1 = None
        view_default_2 = torch.ops.aten.view.default(transpose_int_3, [24, 1024, 64]);  transpose_int_3 = None
        transpose_int_4 = torch.ops.aten.transpose.int(transpose_int_2, 1, 2);  transpose_int_2 = None
        view_default_3 = torch.ops.aten.view.default(transpose_int_4, [24, 1024, 64]);  transpose_int_4 = None
        view_default_4 = torch.ops.aten.view.default(view_default_2, [24, 2, 512, 64]);  view_default_2 = None
        as_strided_default = torch.ops.aten.as_strided.default(view_default_4, [24, 3, 512, 64], [64, 393216, 1536, 1]);  view_default_4 = None
        view_default_5 = torch.ops.aten.view.default(view_default_3, [24, 2, 512, 64]);  view_default_3 = None
        as_strided_default_1 = torch.ops.aten.as_strided.default(view_default_5, [24, 3, 512, 64], [64, 393216, 1536, 1]);  view_default_5 = None
        unsqueeze_default = torch.ops.aten.unsqueeze.default(as_strided_default, -1);  as_strided_default = None
        permute_default = torch.ops.aten.permute.default(unsqueeze_default, [0, 1, 2, 4, 3]);  unsqueeze_default = None
        unsqueeze_default_1 = torch.ops.aten.unsqueeze.default(as_strided_default_1, -1);  as_strided_default_1 = None
        permute_default_1 = torch.ops.aten.permute.default(unsqueeze_default_1, [0, 1, 4, 2, 3]);  unsqueeze_default_1 = None
        permute_default_2 = torch.ops.aten.permute.default(permute_default, [0, 1, 2, 4, 3]);  permute_default = None
        clone_default_3 = torch.ops.aten.clone.default(permute_default_2, memory_format = torch.contiguous_format);  permute_default_2 = None
        _unsafe_view_default_6 = torch.ops.aten._unsafe_view.default(clone_default_3, [72, 512, 64]);  clone_default_3 = None
        permute_default_3 = torch.ops.aten.permute.default(permute_default_1, [0, 1, 4, 3, 2]);  permute_default_1 = None
        clone_default_4 = torch.ops.aten.clone.default(permute_default_3, memory_format = torch.contiguous_format);  permute_default_3 = None
        _unsafe_view_default_7 = torch.ops.aten._unsafe_view.default(clone_default_4, [72, 64, 512]);  clone_default_4 = None
        bmm_default = torch.ops.aten.bmm.default(_unsafe_view_default_6, _unsafe_view_default_7)
        view_default_6 = torch.ops.aten.view.default(bmm_default, [24, 3, 512, 1, 512]);  bmm_default = None
        permute_default_4 = torch.ops.aten.permute.default(view_default_6, [0, 1, 2, 4, 3]);  view_default_6 = None
        view_default_7 = torch.ops.aten.view.default(permute_default_4, [24, 3, 512, 512]);  permute_default_4 = None
        constant_pad_nd_default = torch.ops.aten.constant_pad_nd.default(view_default_7, [0, 0, 0, 1], 0.0);  view_default_7 = None
        view_default_8 = torch.ops.aten.view.default(constant_pad_nd_default, [24, 3, 512, 513]);  constant_pad_nd_default = None
        new_empty_default = torch.ops.aten.new_empty.default(view_default_8, [24, 4, 256, 513], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        slice_tensor = torch.ops.aten.slice.Tensor(view_default_8, 0, 0, 9223372036854775807)
        slice_tensor_1 = torch.ops.aten.slice.Tensor(slice_tensor, 1, 0, 9223372036854775807);  slice_tensor = None
        slice_tensor_2 = torch.ops.aten.slice.Tensor(slice_tensor_1, 2, 0, 256);  slice_tensor_1 = None
        slice_tensor_3 = torch.ops.aten.slice.Tensor(slice_tensor_2, 3, 0, 257);  slice_tensor_2 = None
        slice_tensor_4 = torch.ops.aten.slice.Tensor(new_empty_default, 0, 0, 9223372036854775807)
        slice_tensor_5 = torch.ops.aten.slice.Tensor(slice_tensor_4, 1, 0, -1);  slice_tensor_4 = None
        slice_tensor_6 = torch.ops.aten.slice.Tensor(slice_tensor_5, 2, 0, 9223372036854775807);  slice_tensor_5 = None
        slice_tensor_7 = torch.ops.aten.slice.Tensor(slice_tensor_6, 3, 256, 9223372036854775807);  slice_tensor_6 = None
        copy__default = torch.ops.aten.copy_.default(slice_tensor_7, slice_tensor_3);  slice_tensor_7 = slice_tensor_3 = None
        slice_tensor_8 = torch.ops.aten.slice.Tensor(view_default_8, 0, 0, 9223372036854775807)
        select_int = torch.ops.aten.select.int(slice_tensor_8, 1, -1);  slice_tensor_8 = None
        slice_tensor_9 = torch.ops.aten.slice.Tensor(select_int, 1, 256, 9223372036854775807);  select_int = None
        slice_tensor_10 = torch.ops.aten.slice.Tensor(slice_tensor_9, 2, 0, 257);  slice_tensor_9 = None
        slice_tensor_11 = torch.ops.aten.slice.Tensor(new_empty_default, 0, 0, 9223372036854775807)
        select_int_1 = torch.ops.aten.select.int(slice_tensor_11, 1, -1);  slice_tensor_11 = None
        slice_tensor_12 = torch.ops.aten.slice.Tensor(select_int_1, 1, 0, 9223372036854775807);  select_int_1 = None
        slice_tensor_13 = torch.ops.aten.slice.Tensor(slice_tensor_12, 2, 256, 9223372036854775807);  slice_tensor_12 = None
        copy__default_1 = torch.ops.aten.copy_.default(slice_tensor_13, slice_tensor_10);  slice_tensor_13 = slice_tensor_10 = None
        slice_tensor_14 = torch.ops.aten.slice.Tensor(view_default_8, 0, 0, 9223372036854775807)
        slice_tensor_15 = torch.ops.aten.slice.Tensor(slice_tensor_14, 1, 0, 9223372036854775807);  slice_tensor_14 = None
        slice_tensor_16 = torch.ops.aten.slice.Tensor(slice_tensor_15, 2, -257, -1);  slice_tensor_15 = None
        slice_tensor_17 = torch.ops.aten.slice.Tensor(slice_tensor_16, 3, 257, 9223372036854775807);  slice_tensor_16 = None
        slice_tensor_18 = torch.ops.aten.slice.Tensor(new_empty_default, 0, 0, 9223372036854775807)
        slice_tensor_19 = torch.ops.aten.slice.Tensor(slice_tensor_18, 1, 1, 9223372036854775807);  slice_tensor_18 = None
        slice_tensor_20 = torch.ops.aten.slice.Tensor(slice_tensor_19, 2, 0, 9223372036854775807);  slice_tensor_19 = None
        slice_tensor_21 = torch.ops.aten.slice.Tensor(slice_tensor_20, 3, 0, 256);  slice_tensor_20 = None
        copy__default_2 = torch.ops.aten.copy_.default(slice_tensor_21, slice_tensor_17);  slice_tensor_21 = slice_tensor_17 = None
        slice_tensor_22 = torch.ops.aten.slice.Tensor(view_default_8, 0, 0, 9223372036854775807);  view_default_8 = None
        select_int_2 = torch.ops.aten.select.int(slice_tensor_22, 1, 0);  slice_tensor_22 = None
        slice_tensor_23 = torch.ops.aten.slice.Tensor(select_int_2, 1, 0, 255);  select_int_2 = None
        slice_tensor_24 = torch.ops.aten.slice.Tensor(slice_tensor_23, 2, -255, 9223372036854775807);  slice_tensor_23 = None
        slice_tensor_25 = torch.ops.aten.slice.Tensor(new_empty_default, 0, 0, 9223372036854775807)
        select_int_3 = torch.ops.aten.select.int(slice_tensor_25, 1, 0);  slice_tensor_25 = None
        slice_tensor_26 = torch.ops.aten.slice.Tensor(select_int_3, 1, 1, 256);  select_int_3 = None
        slice_tensor_27 = torch.ops.aten.slice.Tensor(slice_tensor_26, 2, 1, 256);  slice_tensor_26 = None
        copy__default_3 = torch.ops.aten.copy_.default(slice_tensor_27, slice_tensor_24);  slice_tensor_27 = slice_tensor_24 = None
        view_default_9 = torch.ops.aten.view.default(new_empty_default, [2, 12, 1024, 513]);  new_empty_default = None
        transpose_int_5 = torch.ops.aten.transpose.int(view_default_9, 2, 1);  view_default_9 = None
        new_empty_default_1 = torch.ops.aten.new_empty.default(transpose_int_5, [256, 257], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        fill__scalar = torch.ops.aten.fill_.Scalar(new_empty_default_1, 1.0);  new_empty_default_1 = None
        tril_default = torch.ops.aten.tril.default(fill__scalar);  fill__scalar = None
        flip_default = torch.ops.aten.flip.default(tril_default, [0]);  tril_default = None
        unsqueeze_default_2 = torch.ops.aten.unsqueeze.default(flip_default, 0);  flip_default = None
        slice_tensor_28 = torch.ops.aten.slice.Tensor(unsqueeze_default_2, 1, 0, 9223372036854775807);  unsqueeze_default_2 = None
        unsqueeze_default_3 = torch.ops.aten.unsqueeze.default(slice_tensor_28, 2);  slice_tensor_28 = None
        slice_tensor_29 = torch.ops.aten.slice.Tensor(unsqueeze_default_3, 3, 0, 9223372036854775807);  unsqueeze_default_3 = None
        flip_default_1 = torch.ops.aten.flip.default(slice_tensor_29, [1, 3])
        slice_tensor_30 = torch.ops.aten.slice.Tensor(transpose_int_5, 0, 0, 9223372036854775807)
        slice_tensor_31 = torch.ops.aten.slice.Tensor(slice_tensor_30, 1, 0, 256);  slice_tensor_30 = None
        slice_tensor_32 = torch.ops.aten.slice.Tensor(slice_tensor_31, 2, 0, 9223372036854775807);  slice_tensor_31 = None
        slice_tensor_33 = torch.ops.aten.slice.Tensor(slice_tensor_32, 3, 0, 257);  slice_tensor_32 = None
        expand_sym_int = torch.ops.aten.expand.SymInt(slice_tensor_29, [2, 256, 12, 257]);  slice_tensor_29 = None
        eq_scalar = torch.ops.aten.eq.Scalar(expand_sym_int, 1);  expand_sym_int = None
        masked_fill__scalar = torch.ops.aten.masked_fill_.Scalar(slice_tensor_33, eq_scalar, -inf);  slice_tensor_33 = None
        slice_tensor_34 = torch.ops.aten.slice.Tensor(transpose_int_5, 0, 0, 9223372036854775807)
        slice_tensor_35 = torch.ops.aten.slice.Tensor(slice_tensor_34, 1, -256, 9223372036854775807);  slice_tensor_34 = None
        slice_tensor_36 = torch.ops.aten.slice.Tensor(slice_tensor_35, 2, 0, 9223372036854775807);  slice_tensor_35 = None
        slice_tensor_37 = torch.ops.aten.slice.Tensor(slice_tensor_36, 3, -257, 9223372036854775807);  slice_tensor_36 = None
        expand_sym_int_1 = torch.ops.aten.expand.SymInt(flip_default_1, [2, 256, 12, 257]);  flip_default_1 = None
        eq_scalar_1 = torch.ops.aten.eq.Scalar(expand_sym_int_1, 1);  expand_sym_int_1 = None
        masked_fill__scalar_1 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_37, eq_scalar_1, -inf);  slice_tensor_37 = None
        ne_scalar = torch.ops.aten.ne.Scalar(primals_194, 0)
        slice_tensor_38 = torch.ops.aten.slice.Tensor(ne_scalar, 0, 0, 9223372036854775807);  ne_scalar = None
        slice_tensor_39 = torch.ops.aten.slice.Tensor(slice_tensor_38, 1, 0, 9223372036854775807);  slice_tensor_38 = None
        unsqueeze_default_4 = torch.ops.aten.unsqueeze.default(slice_tensor_39, 2);  slice_tensor_39 = None
        unsqueeze_default_5 = torch.ops.aten.unsqueeze.default(unsqueeze_default_4, 3);  unsqueeze_default_4 = None
        _to_copy_default = torch.ops.aten._to_copy.default(unsqueeze_default_5, device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided)
        where_scalar_self = torch.ops.aten.where.ScalarSelf(unsqueeze_default_5, -10000.0, _to_copy_default);  unsqueeze_default_5 = _to_copy_default = None
        new_empty_default_2 = torch.ops.aten.new_empty.default(where_scalar_self, [2, 1024, 1, 1], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        fill__scalar_1 = torch.ops.aten.fill_.Scalar(new_empty_default_2, 1.0);  new_empty_default_2 = None
        transpose_int_6 = torch.ops.aten.transpose.int(fill__scalar_1, 1, 2);  fill__scalar_1 = None
        view_default_10 = torch.ops.aten.view.default(transpose_int_6, [2, 1024, 1]);  transpose_int_6 = None
        transpose_int_7 = torch.ops.aten.transpose.int(where_scalar_self, 1, 2);  where_scalar_self = None
        view_default_11 = torch.ops.aten.view.default(transpose_int_7, [2, 1024, 1]);  transpose_int_7 = None
        view_default_12 = torch.ops.aten.view.default(view_default_10, [2, 2, 512, 1]);  view_default_10 = None
        as_strided_default_2 = torch.ops.aten.as_strided.default(view_default_12, [2, 3, 512, 1], [1024, 256, 1, 1]);  view_default_12 = None
        view_default_13 = torch.ops.aten.view.default(view_default_11, [2, 2, 512, 1]);  view_default_11 = None
        as_strided_default_3 = torch.ops.aten.as_strided.default(view_default_13, [2, 3, 512, 1], [1024, 256, 1, 1]);  view_default_13 = None
        unsqueeze_default_6 = torch.ops.aten.unsqueeze.default(as_strided_default_2, -1);  as_strided_default_2 = None
        permute_default_5 = torch.ops.aten.permute.default(unsqueeze_default_6, [0, 1, 2, 4, 3]);  unsqueeze_default_6 = None
        unsqueeze_default_7 = torch.ops.aten.unsqueeze.default(as_strided_default_3, -1);  as_strided_default_3 = None
        permute_default_6 = torch.ops.aten.permute.default(unsqueeze_default_7, [0, 1, 4, 2, 3]);  unsqueeze_default_7 = None
        squeeze_dim = torch.ops.aten.squeeze.dim(permute_default_5, 4);  permute_default_5 = None
        squeeze_dim_1 = torch.ops.aten.squeeze.dim(permute_default_6, 4);  permute_default_6 = None
        mul_tensor = torch.ops.aten.mul.Tensor(squeeze_dim, squeeze_dim_1);  squeeze_dim = squeeze_dim_1 = None
        constant_pad_nd_default_1 = torch.ops.aten.constant_pad_nd.default(mul_tensor, [0, 0, 0, 1], 0.0);  mul_tensor = None
        view_default_14 = torch.ops.aten.view.default(constant_pad_nd_default_1, [2, 3, 512, 513]);  constant_pad_nd_default_1 = None
        new_empty_default_3 = torch.ops.aten.new_empty.default(view_default_14, [2, 4, 256, 513], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        slice_tensor_40 = torch.ops.aten.slice.Tensor(view_default_14, 0, 0, 9223372036854775807)
        slice_tensor_41 = torch.ops.aten.slice.Tensor(slice_tensor_40, 1, 0, 9223372036854775807);  slice_tensor_40 = None
        slice_tensor_42 = torch.ops.aten.slice.Tensor(slice_tensor_41, 2, 0, 256);  slice_tensor_41 = None
        slice_tensor_43 = torch.ops.aten.slice.Tensor(slice_tensor_42, 3, 0, 257);  slice_tensor_42 = None
        slice_tensor_44 = torch.ops.aten.slice.Tensor(new_empty_default_3, 0, 0, 9223372036854775807)
        slice_tensor_45 = torch.ops.aten.slice.Tensor(slice_tensor_44, 1, 0, -1);  slice_tensor_44 = None
        slice_tensor_46 = torch.ops.aten.slice.Tensor(slice_tensor_45, 2, 0, 9223372036854775807);  slice_tensor_45 = None
        slice_tensor_47 = torch.ops.aten.slice.Tensor(slice_tensor_46, 3, 256, 9223372036854775807);  slice_tensor_46 = None
        copy__default_4 = torch.ops.aten.copy_.default(slice_tensor_47, slice_tensor_43);  slice_tensor_47 = slice_tensor_43 = None
        slice_tensor_48 = torch.ops.aten.slice.Tensor(view_default_14, 0, 0, 9223372036854775807)
        select_int_4 = torch.ops.aten.select.int(slice_tensor_48, 1, -1);  slice_tensor_48 = None
        slice_tensor_49 = torch.ops.aten.slice.Tensor(select_int_4, 1, 256, 9223372036854775807);  select_int_4 = None
        slice_tensor_50 = torch.ops.aten.slice.Tensor(slice_tensor_49, 2, 0, 257);  slice_tensor_49 = None
        slice_tensor_51 = torch.ops.aten.slice.Tensor(new_empty_default_3, 0, 0, 9223372036854775807)
        select_int_5 = torch.ops.aten.select.int(slice_tensor_51, 1, -1);  slice_tensor_51 = None
        slice_tensor_52 = torch.ops.aten.slice.Tensor(select_int_5, 1, 0, 9223372036854775807);  select_int_5 = None
        slice_tensor_53 = torch.ops.aten.slice.Tensor(slice_tensor_52, 2, 256, 9223372036854775807);  slice_tensor_52 = None
        copy__default_5 = torch.ops.aten.copy_.default(slice_tensor_53, slice_tensor_50);  slice_tensor_53 = slice_tensor_50 = None
        slice_tensor_54 = torch.ops.aten.slice.Tensor(view_default_14, 0, 0, 9223372036854775807)
        slice_tensor_55 = torch.ops.aten.slice.Tensor(slice_tensor_54, 1, 0, 9223372036854775807);  slice_tensor_54 = None
        slice_tensor_56 = torch.ops.aten.slice.Tensor(slice_tensor_55, 2, -257, -1);  slice_tensor_55 = None
        slice_tensor_57 = torch.ops.aten.slice.Tensor(slice_tensor_56, 3, 257, 9223372036854775807);  slice_tensor_56 = None
        slice_tensor_58 = torch.ops.aten.slice.Tensor(new_empty_default_3, 0, 0, 9223372036854775807)
        slice_tensor_59 = torch.ops.aten.slice.Tensor(slice_tensor_58, 1, 1, 9223372036854775807);  slice_tensor_58 = None
        slice_tensor_60 = torch.ops.aten.slice.Tensor(slice_tensor_59, 2, 0, 9223372036854775807);  slice_tensor_59 = None
        slice_tensor_61 = torch.ops.aten.slice.Tensor(slice_tensor_60, 3, 0, 256);  slice_tensor_60 = None
        copy__default_6 = torch.ops.aten.copy_.default(slice_tensor_61, slice_tensor_57);  slice_tensor_61 = slice_tensor_57 = None
        slice_tensor_62 = torch.ops.aten.slice.Tensor(view_default_14, 0, 0, 9223372036854775807);  view_default_14 = None
        select_int_6 = torch.ops.aten.select.int(slice_tensor_62, 1, 0);  slice_tensor_62 = None
        slice_tensor_63 = torch.ops.aten.slice.Tensor(select_int_6, 1, 0, 255);  select_int_6 = None
        slice_tensor_64 = torch.ops.aten.slice.Tensor(slice_tensor_63, 2, -255, 9223372036854775807);  slice_tensor_63 = None
        slice_tensor_65 = torch.ops.aten.slice.Tensor(new_empty_default_3, 0, 0, 9223372036854775807)
        select_int_7 = torch.ops.aten.select.int(slice_tensor_65, 1, 0);  slice_tensor_65 = None
        slice_tensor_66 = torch.ops.aten.slice.Tensor(select_int_7, 1, 1, 256);  select_int_7 = None
        slice_tensor_67 = torch.ops.aten.slice.Tensor(slice_tensor_66, 2, 1, 256);  slice_tensor_66 = None
        copy__default_7 = torch.ops.aten.copy_.default(slice_tensor_67, slice_tensor_64);  slice_tensor_67 = slice_tensor_64 = None
        view_default_15 = torch.ops.aten.view.default(new_empty_default_3, [2, 1, 1024, 513]);  new_empty_default_3 = None
        transpose_int_8 = torch.ops.aten.transpose.int(view_default_15, 2, 1);  view_default_15 = None
        new_empty_default_4 = torch.ops.aten.new_empty.default(transpose_int_8, [256, 257], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        fill__scalar_2 = torch.ops.aten.fill_.Scalar(new_empty_default_4, 1.0);  new_empty_default_4 = None
        tril_default_1 = torch.ops.aten.tril.default(fill__scalar_2);  fill__scalar_2 = None
        flip_default_2 = torch.ops.aten.flip.default(tril_default_1, [0]);  tril_default_1 = None
        unsqueeze_default_8 = torch.ops.aten.unsqueeze.default(flip_default_2, 0);  flip_default_2 = None
        slice_tensor_68 = torch.ops.aten.slice.Tensor(unsqueeze_default_8, 1, 0, 9223372036854775807);  unsqueeze_default_8 = None
        unsqueeze_default_9 = torch.ops.aten.unsqueeze.default(slice_tensor_68, 2);  slice_tensor_68 = None
        slice_tensor_69 = torch.ops.aten.slice.Tensor(unsqueeze_default_9, 3, 0, 9223372036854775807);  unsqueeze_default_9 = None
        flip_default_3 = torch.ops.aten.flip.default(slice_tensor_69, [1, 3])
        slice_tensor_70 = torch.ops.aten.slice.Tensor(transpose_int_8, 0, 0, 9223372036854775807)
        slice_tensor_71 = torch.ops.aten.slice.Tensor(slice_tensor_70, 1, 0, 256);  slice_tensor_70 = None
        slice_tensor_72 = torch.ops.aten.slice.Tensor(slice_tensor_71, 2, 0, 9223372036854775807);  slice_tensor_71 = None
        slice_tensor_73 = torch.ops.aten.slice.Tensor(slice_tensor_72, 3, 0, 257);  slice_tensor_72 = None
        expand_sym_int_2 = torch.ops.aten.expand.SymInt(slice_tensor_69, [2, 256, 1, 257]);  slice_tensor_69 = None
        eq_scalar_2 = torch.ops.aten.eq.Scalar(expand_sym_int_2, 1);  expand_sym_int_2 = None
        masked_fill__scalar_2 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_73, eq_scalar_2, -inf);  slice_tensor_73 = eq_scalar_2 = None
        slice_tensor_74 = torch.ops.aten.slice.Tensor(transpose_int_8, 0, 0, 9223372036854775807)
        slice_tensor_75 = torch.ops.aten.slice.Tensor(slice_tensor_74, 1, -256, 9223372036854775807);  slice_tensor_74 = None
        slice_tensor_76 = torch.ops.aten.slice.Tensor(slice_tensor_75, 2, 0, 9223372036854775807);  slice_tensor_75 = None
        slice_tensor_77 = torch.ops.aten.slice.Tensor(slice_tensor_76, 3, -257, 9223372036854775807);  slice_tensor_76 = None
        expand_sym_int_3 = torch.ops.aten.expand.SymInt(flip_default_3, [2, 256, 1, 257]);  flip_default_3 = None
        eq_scalar_3 = torch.ops.aten.eq.Scalar(expand_sym_int_3, 1);  expand_sym_int_3 = None
        masked_fill__scalar_3 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_77, eq_scalar_3, -inf);  slice_tensor_77 = eq_scalar_3 = None
        add__tensor = torch.ops.aten.add_.Tensor(transpose_int_5, transpose_int_8);  transpose_int_5 = transpose_int_8 = None
        _softmax_default = torch.ops.aten._softmax.default(add__tensor, -1, False);  add__tensor = None
        slice_tensor_78 = torch.ops.aten.slice.Tensor(primals_195, 0, 0, 9223372036854775807)
        slice_tensor_79 = torch.ops.aten.slice.Tensor(slice_tensor_78, 1, 0, 9223372036854775807);  slice_tensor_78 = None
        unsqueeze_default_10 = torch.ops.aten.unsqueeze.default(slice_tensor_79, 2);  slice_tensor_79 = None
        unsqueeze_default_11 = torch.ops.aten.unsqueeze.default(unsqueeze_default_10, 3);  unsqueeze_default_10 = None
        where_scalar_self_1 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_11, 0.0, _softmax_default)
        view_default_16 = torch.ops.aten.view.default(add_tensor_2, [1024, 2, 12, 64]);  add_tensor_2 = None
        transpose_int_9 = torch.ops.aten.transpose.int(view_default_16, 0, 1);  view_default_16 = None
        transpose_int_10 = torch.ops.aten.transpose.int(where_scalar_self_1, 1, 2);  where_scalar_self_1 = None
        clone_default_5 = torch.ops.aten.clone.default(transpose_int_10, memory_format = torch.contiguous_format);  transpose_int_10 = None
        _unsafe_view_default_8 = torch.ops.aten._unsafe_view.default(clone_default_5, [24, 4, 256, 513]);  clone_default_5 = None
        transpose_int_11 = torch.ops.aten.transpose.int(transpose_int_9, 1, 2);  transpose_int_9 = None
        view_default_17 = torch.ops.aten.view.default(transpose_int_11, [24, 1024, 64]);  transpose_int_11 = None
        constant_pad_nd_default_2 = torch.ops.aten.constant_pad_nd.default(view_default_17, [0, 0, 256, 256], -1.0);  view_default_17 = None
        as_strided_default_4 = torch.ops.aten.as_strided.default(constant_pad_nd_default_2, [24, 4, 768, 64], [98304, 16384, 64, 1]);  constant_pad_nd_default_2 = None
        constant_pad_nd_default_3 = torch.ops.aten.constant_pad_nd.default(_unsafe_view_default_8, [0, 257], 0.0);  _unsafe_view_default_8 = None
        view_default_18 = torch.ops.aten.view.default(constant_pad_nd_default_3, [24, 4, -1]);  constant_pad_nd_default_3 = None
        slice_tensor_80 = torch.ops.aten.slice.Tensor(view_default_18, 0, 0, 9223372036854775807);  view_default_18 = None
        slice_tensor_81 = torch.ops.aten.slice.Tensor(slice_tensor_80, 1, 0, 9223372036854775807);  slice_tensor_80 = None
        slice_tensor_82 = torch.ops.aten.slice.Tensor(slice_tensor_81, 2, 0, -256);  slice_tensor_81 = None
        view_default_19 = torch.ops.aten.view.default(slice_tensor_82, [24, 4, 256, 769]);  slice_tensor_82 = None
        slice_tensor_83 = torch.ops.aten.slice.Tensor(view_default_19, 0, 0, 9223372036854775807);  view_default_19 = None
        slice_tensor_84 = torch.ops.aten.slice.Tensor(slice_tensor_83, 1, 0, 9223372036854775807);  slice_tensor_83 = None
        slice_tensor_85 = torch.ops.aten.slice.Tensor(slice_tensor_84, 2, 0, 9223372036854775807);  slice_tensor_84 = None
        slice_tensor_86 = torch.ops.aten.slice.Tensor(slice_tensor_85, 3, 0, -1);  slice_tensor_85 = None
        unsqueeze_default_12 = torch.ops.aten.unsqueeze.default(slice_tensor_86, -1);  slice_tensor_86 = None
        permute_default_7 = torch.ops.aten.permute.default(unsqueeze_default_12, [0, 1, 2, 4, 3]);  unsqueeze_default_12 = None
        unsqueeze_default_13 = torch.ops.aten.unsqueeze.default(as_strided_default_4, -1);  as_strided_default_4 = None
        permute_default_8 = torch.ops.aten.permute.default(unsqueeze_default_13, [0, 1, 4, 3, 2]);  unsqueeze_default_13 = None
        permute_default_9 = torch.ops.aten.permute.default(permute_default_7, [0, 1, 2, 4, 3]);  permute_default_7 = None
        view_default_20 = torch.ops.aten.view.default(permute_default_9, [96, 256, 768]);  permute_default_9 = None
        permute_default_10 = torch.ops.aten.permute.default(permute_default_8, [0, 1, 4, 3, 2]);  permute_default_8 = None
        clone_default_6 = torch.ops.aten.clone.default(permute_default_10, memory_format = torch.contiguous_format);  permute_default_10 = None
        _unsafe_view_default_9 = torch.ops.aten._unsafe_view.default(clone_default_6, [96, 768, 64]);  clone_default_6 = None
        bmm_default_1 = torch.ops.aten.bmm.default(view_default_20, _unsafe_view_default_9)
        view_default_21 = torch.ops.aten.view.default(bmm_default_1, [24, 4, 256, 1, 64]);  bmm_default_1 = None
        permute_default_11 = torch.ops.aten.permute.default(view_default_21, [0, 1, 2, 4, 3]);  view_default_21 = None
        view_default_22 = torch.ops.aten.view.default(permute_default_11, [24, 4, 256, 64]);  permute_default_11 = None
        view_default_23 = torch.ops.aten.view.default(view_default_22, [2, 12, 1024, 64]);  view_default_22 = None
        transpose_int_12 = torch.ops.aten.transpose.int(view_default_23, 1, 2);  view_default_23 = None
        transpose_int_13 = torch.ops.aten.transpose.int(transpose_int_12, 0, 1);  transpose_int_12 = None
        clone_default_7 = torch.ops.aten.clone.default(transpose_int_13, memory_format = torch.contiguous_format);  transpose_int_13 = None
        _unsafe_view_default_10 = torch.ops.aten._unsafe_view.default(clone_default_7, [1024, 2, 768]);  clone_default_7 = None
        transpose_int_14 = torch.ops.aten.transpose.int(_unsafe_view_default_10, 0, 1);  _unsafe_view_default_10 = None
        t_default_3 = torch.ops.aten.t.default(primals_4);  primals_4 = None
        clone_default_8 = torch.ops.aten.clone.default(transpose_int_14, memory_format = torch.contiguous_format);  transpose_int_14 = None
        _unsafe_view_default_11 = torch.ops.aten._unsafe_view.default(clone_default_8, [2048, 768]);  clone_default_8 = None
        mm_default_3 = torch.ops.aten.mm.default(_unsafe_view_default_11, t_default_3)
        _unsafe_view_default_12 = torch.ops.aten._unsafe_view.default(mm_default_3, [2, 1024, 768]);  mm_default_3 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(_unsafe_view_default_12, primals_3);  _unsafe_view_default_12 = primals_3 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(add_tensor_3, primals_193);  add_tensor_3 = primals_193 = None
        native_layer_norm_default = torch.ops.aten.native_layer_norm.default(add_tensor_4, [768], primals_2, primals_1, 1e-05)
        getitem = native_layer_norm_default[0]
        getitem_1 = native_layer_norm_default[1]
        getitem_2 = native_layer_norm_default[2];  native_layer_norm_default = None
        view_default_24 = torch.ops.aten.view.default(getitem, [2048, 768])
        t_default_4 = torch.ops.aten.t.default(primals_12);  primals_12 = None
        addmm_default = torch.ops.aten.addmm.default(primals_11, view_default_24, t_default_4);  primals_11 = None
        view_default_25 = torch.ops.aten.view.default(addmm_default, [2, 1024, 3072]);  addmm_default = None
        gelu_default = torch.ops.aten.gelu.default(view_default_25)
        view_default_26 = torch.ops.aten.view.default(gelu_default, [2048, 3072]);  gelu_default = None
        t_default_5 = torch.ops.aten.t.default(primals_16);  primals_16 = None
        addmm_default_1 = torch.ops.aten.addmm.default(primals_15, view_default_26, t_default_5);  primals_15 = None
        view_default_27 = torch.ops.aten.view.default(addmm_default_1, [2, 1024, 768]);  addmm_default_1 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(view_default_27, getitem);  view_default_27 = getitem = None
        native_layer_norm_default_1 = torch.ops.aten.native_layer_norm.default(add_tensor_5, [768], primals_14, primals_13, 1e-05)
        getitem_3 = native_layer_norm_default_1[0]
        getitem_4 = native_layer_norm_default_1[1]
        getitem_5 = native_layer_norm_default_1[2];  native_layer_norm_default_1 = None
        transpose_int_15 = torch.ops.aten.transpose.int(getitem_3, 0, 1)
        t_default_6 = torch.ops.aten.t.default(primals_56);  primals_56 = None
        clone_default_9 = torch.ops.aten.clone.default(transpose_int_15, memory_format = torch.contiguous_format)
        _unsafe_view_default_13 = torch.ops.aten._unsafe_view.default(clone_default_9, [2048, 768]);  clone_default_9 = None
        mm_default_4 = torch.ops.aten.mm.default(_unsafe_view_default_13, t_default_6)
        _unsafe_view_default_14 = torch.ops.aten._unsafe_view.default(mm_default_4, [1024, 2, 768]);  mm_default_4 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(_unsafe_view_default_14, primals_55);  _unsafe_view_default_14 = primals_55 = None
        t_default_7 = torch.ops.aten.t.default(primals_54);  primals_54 = None
        clone_default_10 = torch.ops.aten.clone.default(transpose_int_15, memory_format = torch.contiguous_format)
        _unsafe_view_default_15 = torch.ops.aten._unsafe_view.default(clone_default_10, [2048, 768]);  clone_default_10 = None
        mm_default_5 = torch.ops.aten.mm.default(_unsafe_view_default_15, t_default_7)
        _unsafe_view_default_16 = torch.ops.aten._unsafe_view.default(mm_default_5, [1024, 2, 768]);  mm_default_5 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(_unsafe_view_default_16, primals_53);  _unsafe_view_default_16 = primals_53 = None
        t_default_8 = torch.ops.aten.t.default(primals_58);  primals_58 = None
        clone_default_11 = torch.ops.aten.clone.default(transpose_int_15, memory_format = torch.contiguous_format);  transpose_int_15 = None
        _unsafe_view_default_17 = torch.ops.aten._unsafe_view.default(clone_default_11, [2048, 768]);  clone_default_11 = None
        mm_default_6 = torch.ops.aten.mm.default(_unsafe_view_default_17, t_default_8)
        _unsafe_view_default_18 = torch.ops.aten._unsafe_view.default(mm_default_6, [1024, 2, 768]);  mm_default_6 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(_unsafe_view_default_18, primals_57);  _unsafe_view_default_18 = primals_57 = None
        div__tensor_1 = torch.ops.aten.div_.Tensor(add_tensor_6, 8.0);  add_tensor_6 = None
        view_default_28 = torch.ops.aten.view.default(div__tensor_1, [1024, 2, 12, 64]);  div__tensor_1 = None
        transpose_int_16 = torch.ops.aten.transpose.int(view_default_28, 0, 1);  view_default_28 = None
        view_default_29 = torch.ops.aten.view.default(add_tensor_7, [1024, 2, 12, 64]);  add_tensor_7 = None
        transpose_int_17 = torch.ops.aten.transpose.int(view_default_29, 0, 1);  view_default_29 = None
        transpose_int_18 = torch.ops.aten.transpose.int(transpose_int_16, 1, 2);  transpose_int_16 = None
        view_default_30 = torch.ops.aten.view.default(transpose_int_18, [24, 1024, 64]);  transpose_int_18 = None
        transpose_int_19 = torch.ops.aten.transpose.int(transpose_int_17, 1, 2);  transpose_int_17 = None
        view_default_31 = torch.ops.aten.view.default(transpose_int_19, [24, 1024, 64]);  transpose_int_19 = None
        view_default_32 = torch.ops.aten.view.default(view_default_30, [24, 2, 512, 64]);  view_default_30 = None
        as_strided_default_5 = torch.ops.aten.as_strided.default(view_default_32, [24, 3, 512, 64], [64, 393216, 1536, 1]);  view_default_32 = None
        view_default_33 = torch.ops.aten.view.default(view_default_31, [24, 2, 512, 64]);  view_default_31 = None
        as_strided_default_6 = torch.ops.aten.as_strided.default(view_default_33, [24, 3, 512, 64], [64, 393216, 1536, 1]);  view_default_33 = None
        unsqueeze_default_14 = torch.ops.aten.unsqueeze.default(as_strided_default_5, -1);  as_strided_default_5 = None
        permute_default_12 = torch.ops.aten.permute.default(unsqueeze_default_14, [0, 1, 2, 4, 3]);  unsqueeze_default_14 = None
        unsqueeze_default_15 = torch.ops.aten.unsqueeze.default(as_strided_default_6, -1);  as_strided_default_6 = None
        permute_default_13 = torch.ops.aten.permute.default(unsqueeze_default_15, [0, 1, 4, 2, 3]);  unsqueeze_default_15 = None
        permute_default_14 = torch.ops.aten.permute.default(permute_default_12, [0, 1, 2, 4, 3]);  permute_default_12 = None
        clone_default_12 = torch.ops.aten.clone.default(permute_default_14, memory_format = torch.contiguous_format);  permute_default_14 = None
        _unsafe_view_default_19 = torch.ops.aten._unsafe_view.default(clone_default_12, [72, 512, 64]);  clone_default_12 = None
        permute_default_15 = torch.ops.aten.permute.default(permute_default_13, [0, 1, 4, 3, 2]);  permute_default_13 = None
        clone_default_13 = torch.ops.aten.clone.default(permute_default_15, memory_format = torch.contiguous_format);  permute_default_15 = None
        _unsafe_view_default_20 = torch.ops.aten._unsafe_view.default(clone_default_13, [72, 64, 512]);  clone_default_13 = None
        bmm_default_2 = torch.ops.aten.bmm.default(_unsafe_view_default_19, _unsafe_view_default_20)
        view_default_34 = torch.ops.aten.view.default(bmm_default_2, [24, 3, 512, 1, 512]);  bmm_default_2 = None
        permute_default_16 = torch.ops.aten.permute.default(view_default_34, [0, 1, 2, 4, 3]);  view_default_34 = None
        view_default_35 = torch.ops.aten.view.default(permute_default_16, [24, 3, 512, 512]);  permute_default_16 = None
        constant_pad_nd_default_4 = torch.ops.aten.constant_pad_nd.default(view_default_35, [0, 0, 0, 1], 0.0);  view_default_35 = None
        view_default_36 = torch.ops.aten.view.default(constant_pad_nd_default_4, [24, 3, 512, 513]);  constant_pad_nd_default_4 = None
        new_empty_default_5 = torch.ops.aten.new_empty.default(view_default_36, [24, 4, 256, 513], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        slice_tensor_87 = torch.ops.aten.slice.Tensor(view_default_36, 0, 0, 9223372036854775807)
        slice_tensor_88 = torch.ops.aten.slice.Tensor(slice_tensor_87, 1, 0, 9223372036854775807);  slice_tensor_87 = None
        slice_tensor_89 = torch.ops.aten.slice.Tensor(slice_tensor_88, 2, 0, 256);  slice_tensor_88 = None
        slice_tensor_90 = torch.ops.aten.slice.Tensor(slice_tensor_89, 3, 0, 257);  slice_tensor_89 = None
        slice_tensor_91 = torch.ops.aten.slice.Tensor(new_empty_default_5, 0, 0, 9223372036854775807)
        slice_tensor_92 = torch.ops.aten.slice.Tensor(slice_tensor_91, 1, 0, -1);  slice_tensor_91 = None
        slice_tensor_93 = torch.ops.aten.slice.Tensor(slice_tensor_92, 2, 0, 9223372036854775807);  slice_tensor_92 = None
        slice_tensor_94 = torch.ops.aten.slice.Tensor(slice_tensor_93, 3, 256, 9223372036854775807);  slice_tensor_93 = None
        copy__default_8 = torch.ops.aten.copy_.default(slice_tensor_94, slice_tensor_90);  slice_tensor_94 = slice_tensor_90 = None
        slice_tensor_95 = torch.ops.aten.slice.Tensor(view_default_36, 0, 0, 9223372036854775807)
        select_int_8 = torch.ops.aten.select.int(slice_tensor_95, 1, -1);  slice_tensor_95 = None
        slice_tensor_96 = torch.ops.aten.slice.Tensor(select_int_8, 1, 256, 9223372036854775807);  select_int_8 = None
        slice_tensor_97 = torch.ops.aten.slice.Tensor(slice_tensor_96, 2, 0, 257);  slice_tensor_96 = None
        slice_tensor_98 = torch.ops.aten.slice.Tensor(new_empty_default_5, 0, 0, 9223372036854775807)
        select_int_9 = torch.ops.aten.select.int(slice_tensor_98, 1, -1);  slice_tensor_98 = None
        slice_tensor_99 = torch.ops.aten.slice.Tensor(select_int_9, 1, 0, 9223372036854775807);  select_int_9 = None
        slice_tensor_100 = torch.ops.aten.slice.Tensor(slice_tensor_99, 2, 256, 9223372036854775807);  slice_tensor_99 = None
        copy__default_9 = torch.ops.aten.copy_.default(slice_tensor_100, slice_tensor_97);  slice_tensor_100 = slice_tensor_97 = None
        slice_tensor_101 = torch.ops.aten.slice.Tensor(view_default_36, 0, 0, 9223372036854775807)
        slice_tensor_102 = torch.ops.aten.slice.Tensor(slice_tensor_101, 1, 0, 9223372036854775807);  slice_tensor_101 = None
        slice_tensor_103 = torch.ops.aten.slice.Tensor(slice_tensor_102, 2, -257, -1);  slice_tensor_102 = None
        slice_tensor_104 = torch.ops.aten.slice.Tensor(slice_tensor_103, 3, 257, 9223372036854775807);  slice_tensor_103 = None
        slice_tensor_105 = torch.ops.aten.slice.Tensor(new_empty_default_5, 0, 0, 9223372036854775807)
        slice_tensor_106 = torch.ops.aten.slice.Tensor(slice_tensor_105, 1, 1, 9223372036854775807);  slice_tensor_105 = None
        slice_tensor_107 = torch.ops.aten.slice.Tensor(slice_tensor_106, 2, 0, 9223372036854775807);  slice_tensor_106 = None
        slice_tensor_108 = torch.ops.aten.slice.Tensor(slice_tensor_107, 3, 0, 256);  slice_tensor_107 = None
        copy__default_10 = torch.ops.aten.copy_.default(slice_tensor_108, slice_tensor_104);  slice_tensor_108 = slice_tensor_104 = None
        slice_tensor_109 = torch.ops.aten.slice.Tensor(view_default_36, 0, 0, 9223372036854775807);  view_default_36 = None
        select_int_10 = torch.ops.aten.select.int(slice_tensor_109, 1, 0);  slice_tensor_109 = None
        slice_tensor_110 = torch.ops.aten.slice.Tensor(select_int_10, 1, 0, 255);  select_int_10 = None
        slice_tensor_111 = torch.ops.aten.slice.Tensor(slice_tensor_110, 2, -255, 9223372036854775807);  slice_tensor_110 = None
        slice_tensor_112 = torch.ops.aten.slice.Tensor(new_empty_default_5, 0, 0, 9223372036854775807)
        select_int_11 = torch.ops.aten.select.int(slice_tensor_112, 1, 0);  slice_tensor_112 = None
        slice_tensor_113 = torch.ops.aten.slice.Tensor(select_int_11, 1, 1, 256);  select_int_11 = None
        slice_tensor_114 = torch.ops.aten.slice.Tensor(slice_tensor_113, 2, 1, 256);  slice_tensor_113 = None
        copy__default_11 = torch.ops.aten.copy_.default(slice_tensor_114, slice_tensor_111);  slice_tensor_114 = slice_tensor_111 = None
        view_default_37 = torch.ops.aten.view.default(new_empty_default_5, [2, 12, 1024, 513]);  new_empty_default_5 = None
        transpose_int_20 = torch.ops.aten.transpose.int(view_default_37, 2, 1);  view_default_37 = None
        new_empty_default_6 = torch.ops.aten.new_empty.default(transpose_int_20, [256, 257], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        fill__scalar_3 = torch.ops.aten.fill_.Scalar(new_empty_default_6, 1.0);  new_empty_default_6 = None
        tril_default_2 = torch.ops.aten.tril.default(fill__scalar_3);  fill__scalar_3 = None
        flip_default_4 = torch.ops.aten.flip.default(tril_default_2, [0]);  tril_default_2 = None
        unsqueeze_default_16 = torch.ops.aten.unsqueeze.default(flip_default_4, 0);  flip_default_4 = None
        slice_tensor_115 = torch.ops.aten.slice.Tensor(unsqueeze_default_16, 1, 0, 9223372036854775807);  unsqueeze_default_16 = None
        unsqueeze_default_17 = torch.ops.aten.unsqueeze.default(slice_tensor_115, 2);  slice_tensor_115 = None
        slice_tensor_116 = torch.ops.aten.slice.Tensor(unsqueeze_default_17, 3, 0, 9223372036854775807);  unsqueeze_default_17 = None
        flip_default_5 = torch.ops.aten.flip.default(slice_tensor_116, [1, 3])
        slice_tensor_117 = torch.ops.aten.slice.Tensor(transpose_int_20, 0, 0, 9223372036854775807)
        slice_tensor_118 = torch.ops.aten.slice.Tensor(slice_tensor_117, 1, 0, 256);  slice_tensor_117 = None
        slice_tensor_119 = torch.ops.aten.slice.Tensor(slice_tensor_118, 2, 0, 9223372036854775807);  slice_tensor_118 = None
        slice_tensor_120 = torch.ops.aten.slice.Tensor(slice_tensor_119, 3, 0, 257);  slice_tensor_119 = None
        expand_sym_int_4 = torch.ops.aten.expand.SymInt(slice_tensor_116, [2, 256, 12, 257]);  slice_tensor_116 = None
        eq_scalar_4 = torch.ops.aten.eq.Scalar(expand_sym_int_4, 1);  expand_sym_int_4 = None
        masked_fill__scalar_4 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_120, eq_scalar_4, -inf);  slice_tensor_120 = None
        slice_tensor_121 = torch.ops.aten.slice.Tensor(transpose_int_20, 0, 0, 9223372036854775807)
        slice_tensor_122 = torch.ops.aten.slice.Tensor(slice_tensor_121, 1, -256, 9223372036854775807);  slice_tensor_121 = None
        slice_tensor_123 = torch.ops.aten.slice.Tensor(slice_tensor_122, 2, 0, 9223372036854775807);  slice_tensor_122 = None
        slice_tensor_124 = torch.ops.aten.slice.Tensor(slice_tensor_123, 3, -257, 9223372036854775807);  slice_tensor_123 = None
        expand_sym_int_5 = torch.ops.aten.expand.SymInt(flip_default_5, [2, 256, 12, 257]);  flip_default_5 = None
        eq_scalar_5 = torch.ops.aten.eq.Scalar(expand_sym_int_5, 1);  expand_sym_int_5 = None
        masked_fill__scalar_5 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_124, eq_scalar_5, -inf);  slice_tensor_124 = None
        ne_scalar_1 = torch.ops.aten.ne.Scalar(primals_194, 0)
        slice_tensor_125 = torch.ops.aten.slice.Tensor(ne_scalar_1, 0, 0, 9223372036854775807);  ne_scalar_1 = None
        slice_tensor_126 = torch.ops.aten.slice.Tensor(slice_tensor_125, 1, 0, 9223372036854775807);  slice_tensor_125 = None
        unsqueeze_default_18 = torch.ops.aten.unsqueeze.default(slice_tensor_126, 2);  slice_tensor_126 = None
        unsqueeze_default_19 = torch.ops.aten.unsqueeze.default(unsqueeze_default_18, 3);  unsqueeze_default_18 = None
        _to_copy_default_1 = torch.ops.aten._to_copy.default(unsqueeze_default_19, device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided)
        where_scalar_self_2 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_19, -10000.0, _to_copy_default_1);  unsqueeze_default_19 = _to_copy_default_1 = None
        new_empty_default_7 = torch.ops.aten.new_empty.default(where_scalar_self_2, [2, 1024, 1, 1], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        fill__scalar_4 = torch.ops.aten.fill_.Scalar(new_empty_default_7, 1.0);  new_empty_default_7 = None
        transpose_int_21 = torch.ops.aten.transpose.int(fill__scalar_4, 1, 2);  fill__scalar_4 = None
        view_default_38 = torch.ops.aten.view.default(transpose_int_21, [2, 1024, 1]);  transpose_int_21 = None
        transpose_int_22 = torch.ops.aten.transpose.int(where_scalar_self_2, 1, 2);  where_scalar_self_2 = None
        view_default_39 = torch.ops.aten.view.default(transpose_int_22, [2, 1024, 1]);  transpose_int_22 = None
        view_default_40 = torch.ops.aten.view.default(view_default_38, [2, 2, 512, 1]);  view_default_38 = None
        as_strided_default_7 = torch.ops.aten.as_strided.default(view_default_40, [2, 3, 512, 1], [1024, 256, 1, 1]);  view_default_40 = None
        view_default_41 = torch.ops.aten.view.default(view_default_39, [2, 2, 512, 1]);  view_default_39 = None
        as_strided_default_8 = torch.ops.aten.as_strided.default(view_default_41, [2, 3, 512, 1], [1024, 256, 1, 1]);  view_default_41 = None
        unsqueeze_default_20 = torch.ops.aten.unsqueeze.default(as_strided_default_7, -1);  as_strided_default_7 = None
        permute_default_17 = torch.ops.aten.permute.default(unsqueeze_default_20, [0, 1, 2, 4, 3]);  unsqueeze_default_20 = None
        unsqueeze_default_21 = torch.ops.aten.unsqueeze.default(as_strided_default_8, -1);  as_strided_default_8 = None
        permute_default_18 = torch.ops.aten.permute.default(unsqueeze_default_21, [0, 1, 4, 2, 3]);  unsqueeze_default_21 = None
        squeeze_dim_2 = torch.ops.aten.squeeze.dim(permute_default_17, 4);  permute_default_17 = None
        squeeze_dim_3 = torch.ops.aten.squeeze.dim(permute_default_18, 4);  permute_default_18 = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(squeeze_dim_2, squeeze_dim_3);  squeeze_dim_2 = squeeze_dim_3 = None
        constant_pad_nd_default_5 = torch.ops.aten.constant_pad_nd.default(mul_tensor_1, [0, 0, 0, 1], 0.0);  mul_tensor_1 = None
        view_default_42 = torch.ops.aten.view.default(constant_pad_nd_default_5, [2, 3, 512, 513]);  constant_pad_nd_default_5 = None
        new_empty_default_8 = torch.ops.aten.new_empty.default(view_default_42, [2, 4, 256, 513], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        slice_tensor_127 = torch.ops.aten.slice.Tensor(view_default_42, 0, 0, 9223372036854775807)
        slice_tensor_128 = torch.ops.aten.slice.Tensor(slice_tensor_127, 1, 0, 9223372036854775807);  slice_tensor_127 = None
        slice_tensor_129 = torch.ops.aten.slice.Tensor(slice_tensor_128, 2, 0, 256);  slice_tensor_128 = None
        slice_tensor_130 = torch.ops.aten.slice.Tensor(slice_tensor_129, 3, 0, 257);  slice_tensor_129 = None
        slice_tensor_131 = torch.ops.aten.slice.Tensor(new_empty_default_8, 0, 0, 9223372036854775807)
        slice_tensor_132 = torch.ops.aten.slice.Tensor(slice_tensor_131, 1, 0, -1);  slice_tensor_131 = None
        slice_tensor_133 = torch.ops.aten.slice.Tensor(slice_tensor_132, 2, 0, 9223372036854775807);  slice_tensor_132 = None
        slice_tensor_134 = torch.ops.aten.slice.Tensor(slice_tensor_133, 3, 256, 9223372036854775807);  slice_tensor_133 = None
        copy__default_12 = torch.ops.aten.copy_.default(slice_tensor_134, slice_tensor_130);  slice_tensor_134 = slice_tensor_130 = None
        slice_tensor_135 = torch.ops.aten.slice.Tensor(view_default_42, 0, 0, 9223372036854775807)
        select_int_12 = torch.ops.aten.select.int(slice_tensor_135, 1, -1);  slice_tensor_135 = None
        slice_tensor_136 = torch.ops.aten.slice.Tensor(select_int_12, 1, 256, 9223372036854775807);  select_int_12 = None
        slice_tensor_137 = torch.ops.aten.slice.Tensor(slice_tensor_136, 2, 0, 257);  slice_tensor_136 = None
        slice_tensor_138 = torch.ops.aten.slice.Tensor(new_empty_default_8, 0, 0, 9223372036854775807)
        select_int_13 = torch.ops.aten.select.int(slice_tensor_138, 1, -1);  slice_tensor_138 = None
        slice_tensor_139 = torch.ops.aten.slice.Tensor(select_int_13, 1, 0, 9223372036854775807);  select_int_13 = None
        slice_tensor_140 = torch.ops.aten.slice.Tensor(slice_tensor_139, 2, 256, 9223372036854775807);  slice_tensor_139 = None
        copy__default_13 = torch.ops.aten.copy_.default(slice_tensor_140, slice_tensor_137);  slice_tensor_140 = slice_tensor_137 = None
        slice_tensor_141 = torch.ops.aten.slice.Tensor(view_default_42, 0, 0, 9223372036854775807)
        slice_tensor_142 = torch.ops.aten.slice.Tensor(slice_tensor_141, 1, 0, 9223372036854775807);  slice_tensor_141 = None
        slice_tensor_143 = torch.ops.aten.slice.Tensor(slice_tensor_142, 2, -257, -1);  slice_tensor_142 = None
        slice_tensor_144 = torch.ops.aten.slice.Tensor(slice_tensor_143, 3, 257, 9223372036854775807);  slice_tensor_143 = None
        slice_tensor_145 = torch.ops.aten.slice.Tensor(new_empty_default_8, 0, 0, 9223372036854775807)
        slice_tensor_146 = torch.ops.aten.slice.Tensor(slice_tensor_145, 1, 1, 9223372036854775807);  slice_tensor_145 = None
        slice_tensor_147 = torch.ops.aten.slice.Tensor(slice_tensor_146, 2, 0, 9223372036854775807);  slice_tensor_146 = None
        slice_tensor_148 = torch.ops.aten.slice.Tensor(slice_tensor_147, 3, 0, 256);  slice_tensor_147 = None
        copy__default_14 = torch.ops.aten.copy_.default(slice_tensor_148, slice_tensor_144);  slice_tensor_148 = slice_tensor_144 = None
        slice_tensor_149 = torch.ops.aten.slice.Tensor(view_default_42, 0, 0, 9223372036854775807);  view_default_42 = None
        select_int_14 = torch.ops.aten.select.int(slice_tensor_149, 1, 0);  slice_tensor_149 = None
        slice_tensor_150 = torch.ops.aten.slice.Tensor(select_int_14, 1, 0, 255);  select_int_14 = None
        slice_tensor_151 = torch.ops.aten.slice.Tensor(slice_tensor_150, 2, -255, 9223372036854775807);  slice_tensor_150 = None
        slice_tensor_152 = torch.ops.aten.slice.Tensor(new_empty_default_8, 0, 0, 9223372036854775807)
        select_int_15 = torch.ops.aten.select.int(slice_tensor_152, 1, 0);  slice_tensor_152 = None
        slice_tensor_153 = torch.ops.aten.slice.Tensor(select_int_15, 1, 1, 256);  select_int_15 = None
        slice_tensor_154 = torch.ops.aten.slice.Tensor(slice_tensor_153, 2, 1, 256);  slice_tensor_153 = None
        copy__default_15 = torch.ops.aten.copy_.default(slice_tensor_154, slice_tensor_151);  slice_tensor_154 = slice_tensor_151 = None
        view_default_43 = torch.ops.aten.view.default(new_empty_default_8, [2, 1, 1024, 513]);  new_empty_default_8 = None
        transpose_int_23 = torch.ops.aten.transpose.int(view_default_43, 2, 1);  view_default_43 = None
        new_empty_default_9 = torch.ops.aten.new_empty.default(transpose_int_23, [256, 257], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        fill__scalar_5 = torch.ops.aten.fill_.Scalar(new_empty_default_9, 1.0);  new_empty_default_9 = None
        tril_default_3 = torch.ops.aten.tril.default(fill__scalar_5);  fill__scalar_5 = None
        flip_default_6 = torch.ops.aten.flip.default(tril_default_3, [0]);  tril_default_3 = None
        unsqueeze_default_22 = torch.ops.aten.unsqueeze.default(flip_default_6, 0);  flip_default_6 = None
        slice_tensor_155 = torch.ops.aten.slice.Tensor(unsqueeze_default_22, 1, 0, 9223372036854775807);  unsqueeze_default_22 = None
        unsqueeze_default_23 = torch.ops.aten.unsqueeze.default(slice_tensor_155, 2);  slice_tensor_155 = None
        slice_tensor_156 = torch.ops.aten.slice.Tensor(unsqueeze_default_23, 3, 0, 9223372036854775807);  unsqueeze_default_23 = None
        flip_default_7 = torch.ops.aten.flip.default(slice_tensor_156, [1, 3])
        slice_tensor_157 = torch.ops.aten.slice.Tensor(transpose_int_23, 0, 0, 9223372036854775807)
        slice_tensor_158 = torch.ops.aten.slice.Tensor(slice_tensor_157, 1, 0, 256);  slice_tensor_157 = None
        slice_tensor_159 = torch.ops.aten.slice.Tensor(slice_tensor_158, 2, 0, 9223372036854775807);  slice_tensor_158 = None
        slice_tensor_160 = torch.ops.aten.slice.Tensor(slice_tensor_159, 3, 0, 257);  slice_tensor_159 = None
        expand_sym_int_6 = torch.ops.aten.expand.SymInt(slice_tensor_156, [2, 256, 1, 257]);  slice_tensor_156 = None
        eq_scalar_6 = torch.ops.aten.eq.Scalar(expand_sym_int_6, 1);  expand_sym_int_6 = None
        masked_fill__scalar_6 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_160, eq_scalar_6, -inf);  slice_tensor_160 = eq_scalar_6 = None
        slice_tensor_161 = torch.ops.aten.slice.Tensor(transpose_int_23, 0, 0, 9223372036854775807)
        slice_tensor_162 = torch.ops.aten.slice.Tensor(slice_tensor_161, 1, -256, 9223372036854775807);  slice_tensor_161 = None
        slice_tensor_163 = torch.ops.aten.slice.Tensor(slice_tensor_162, 2, 0, 9223372036854775807);  slice_tensor_162 = None
        slice_tensor_164 = torch.ops.aten.slice.Tensor(slice_tensor_163, 3, -257, 9223372036854775807);  slice_tensor_163 = None
        expand_sym_int_7 = torch.ops.aten.expand.SymInt(flip_default_7, [2, 256, 1, 257]);  flip_default_7 = None
        eq_scalar_7 = torch.ops.aten.eq.Scalar(expand_sym_int_7, 1);  expand_sym_int_7 = None
        masked_fill__scalar_7 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_164, eq_scalar_7, -inf);  slice_tensor_164 = eq_scalar_7 = None
        add__tensor_1 = torch.ops.aten.add_.Tensor(transpose_int_20, transpose_int_23);  transpose_int_20 = transpose_int_23 = None
        _softmax_default_1 = torch.ops.aten._softmax.default(add__tensor_1, -1, False);  add__tensor_1 = None
        slice_tensor_165 = torch.ops.aten.slice.Tensor(primals_195, 0, 0, 9223372036854775807)
        slice_tensor_166 = torch.ops.aten.slice.Tensor(slice_tensor_165, 1, 0, 9223372036854775807);  slice_tensor_165 = None
        unsqueeze_default_24 = torch.ops.aten.unsqueeze.default(slice_tensor_166, 2);  slice_tensor_166 = None
        unsqueeze_default_25 = torch.ops.aten.unsqueeze.default(unsqueeze_default_24, 3);  unsqueeze_default_24 = None
        where_scalar_self_3 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_25, 0.0, _softmax_default_1)
        view_default_44 = torch.ops.aten.view.default(add_tensor_8, [1024, 2, 12, 64]);  add_tensor_8 = None
        transpose_int_24 = torch.ops.aten.transpose.int(view_default_44, 0, 1);  view_default_44 = None
        transpose_int_25 = torch.ops.aten.transpose.int(where_scalar_self_3, 1, 2);  where_scalar_self_3 = None
        clone_default_14 = torch.ops.aten.clone.default(transpose_int_25, memory_format = torch.contiguous_format);  transpose_int_25 = None
        _unsafe_view_default_21 = torch.ops.aten._unsafe_view.default(clone_default_14, [24, 4, 256, 513]);  clone_default_14 = None
        transpose_int_26 = torch.ops.aten.transpose.int(transpose_int_24, 1, 2);  transpose_int_24 = None
        view_default_45 = torch.ops.aten.view.default(transpose_int_26, [24, 1024, 64]);  transpose_int_26 = None
        constant_pad_nd_default_6 = torch.ops.aten.constant_pad_nd.default(view_default_45, [0, 0, 256, 256], -1.0);  view_default_45 = None
        as_strided_default_9 = torch.ops.aten.as_strided.default(constant_pad_nd_default_6, [24, 4, 768, 64], [98304, 16384, 64, 1]);  constant_pad_nd_default_6 = None
        constant_pad_nd_default_7 = torch.ops.aten.constant_pad_nd.default(_unsafe_view_default_21, [0, 257], 0.0);  _unsafe_view_default_21 = None
        view_default_46 = torch.ops.aten.view.default(constant_pad_nd_default_7, [24, 4, -1]);  constant_pad_nd_default_7 = None
        slice_tensor_167 = torch.ops.aten.slice.Tensor(view_default_46, 0, 0, 9223372036854775807);  view_default_46 = None
        slice_tensor_168 = torch.ops.aten.slice.Tensor(slice_tensor_167, 1, 0, 9223372036854775807);  slice_tensor_167 = None
        slice_tensor_169 = torch.ops.aten.slice.Tensor(slice_tensor_168, 2, 0, -256);  slice_tensor_168 = None
        view_default_47 = torch.ops.aten.view.default(slice_tensor_169, [24, 4, 256, 769]);  slice_tensor_169 = None
        slice_tensor_170 = torch.ops.aten.slice.Tensor(view_default_47, 0, 0, 9223372036854775807);  view_default_47 = None
        slice_tensor_171 = torch.ops.aten.slice.Tensor(slice_tensor_170, 1, 0, 9223372036854775807);  slice_tensor_170 = None
        slice_tensor_172 = torch.ops.aten.slice.Tensor(slice_tensor_171, 2, 0, 9223372036854775807);  slice_tensor_171 = None
        slice_tensor_173 = torch.ops.aten.slice.Tensor(slice_tensor_172, 3, 0, -1);  slice_tensor_172 = None
        unsqueeze_default_26 = torch.ops.aten.unsqueeze.default(slice_tensor_173, -1);  slice_tensor_173 = None
        permute_default_19 = torch.ops.aten.permute.default(unsqueeze_default_26, [0, 1, 2, 4, 3]);  unsqueeze_default_26 = None
        unsqueeze_default_27 = torch.ops.aten.unsqueeze.default(as_strided_default_9, -1);  as_strided_default_9 = None
        permute_default_20 = torch.ops.aten.permute.default(unsqueeze_default_27, [0, 1, 4, 3, 2]);  unsqueeze_default_27 = None
        permute_default_21 = torch.ops.aten.permute.default(permute_default_19, [0, 1, 2, 4, 3]);  permute_default_19 = None
        view_default_48 = torch.ops.aten.view.default(permute_default_21, [96, 256, 768]);  permute_default_21 = None
        permute_default_22 = torch.ops.aten.permute.default(permute_default_20, [0, 1, 4, 3, 2]);  permute_default_20 = None
        clone_default_15 = torch.ops.aten.clone.default(permute_default_22, memory_format = torch.contiguous_format);  permute_default_22 = None
        _unsafe_view_default_22 = torch.ops.aten._unsafe_view.default(clone_default_15, [96, 768, 64]);  clone_default_15 = None
        bmm_default_3 = torch.ops.aten.bmm.default(view_default_48, _unsafe_view_default_22)
        view_default_49 = torch.ops.aten.view.default(bmm_default_3, [24, 4, 256, 1, 64]);  bmm_default_3 = None
        permute_default_23 = torch.ops.aten.permute.default(view_default_49, [0, 1, 2, 4, 3]);  view_default_49 = None
        view_default_50 = torch.ops.aten.view.default(permute_default_23, [24, 4, 256, 64]);  permute_default_23 = None
        view_default_51 = torch.ops.aten.view.default(view_default_50, [2, 12, 1024, 64]);  view_default_50 = None
        transpose_int_27 = torch.ops.aten.transpose.int(view_default_51, 1, 2);  view_default_51 = None
        transpose_int_28 = torch.ops.aten.transpose.int(transpose_int_27, 0, 1);  transpose_int_27 = None
        clone_default_16 = torch.ops.aten.clone.default(transpose_int_28, memory_format = torch.contiguous_format);  transpose_int_28 = None
        _unsafe_view_default_23 = torch.ops.aten._unsafe_view.default(clone_default_16, [1024, 2, 768]);  clone_default_16 = None
        transpose_int_29 = torch.ops.aten.transpose.int(_unsafe_view_default_23, 0, 1);  _unsafe_view_default_23 = None
        t_default_9 = torch.ops.aten.t.default(primals_52);  primals_52 = None
        clone_default_17 = torch.ops.aten.clone.default(transpose_int_29, memory_format = torch.contiguous_format);  transpose_int_29 = None
        _unsafe_view_default_24 = torch.ops.aten._unsafe_view.default(clone_default_17, [2048, 768]);  clone_default_17 = None
        mm_default_7 = torch.ops.aten.mm.default(_unsafe_view_default_24, t_default_9)
        _unsafe_view_default_25 = torch.ops.aten._unsafe_view.default(mm_default_7, [2, 1024, 768]);  mm_default_7 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(_unsafe_view_default_25, primals_51);  _unsafe_view_default_25 = primals_51 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(add_tensor_9, getitem_3);  add_tensor_9 = getitem_3 = None
        native_layer_norm_default_2 = torch.ops.aten.native_layer_norm.default(add_tensor_10, [768], primals_50, primals_49, 1e-05)
        getitem_6 = native_layer_norm_default_2[0]
        getitem_7 = native_layer_norm_default_2[1]
        getitem_8 = native_layer_norm_default_2[2];  native_layer_norm_default_2 = None
        view_default_52 = torch.ops.aten.view.default(getitem_6, [2048, 768])
        t_default_10 = torch.ops.aten.t.default(primals_60);  primals_60 = None
        addmm_default_2 = torch.ops.aten.addmm.default(primals_59, view_default_52, t_default_10);  primals_59 = None
        view_default_53 = torch.ops.aten.view.default(addmm_default_2, [2, 1024, 3072]);  addmm_default_2 = None
        gelu_default_1 = torch.ops.aten.gelu.default(view_default_53)
        view_default_54 = torch.ops.aten.view.default(gelu_default_1, [2048, 3072]);  gelu_default_1 = None
        t_default_11 = torch.ops.aten.t.default(primals_64);  primals_64 = None
        addmm_default_3 = torch.ops.aten.addmm.default(primals_63, view_default_54, t_default_11);  primals_63 = None
        view_default_55 = torch.ops.aten.view.default(addmm_default_3, [2, 1024, 768]);  addmm_default_3 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(view_default_55, getitem_6);  view_default_55 = getitem_6 = None
        native_layer_norm_default_3 = torch.ops.aten.native_layer_norm.default(add_tensor_11, [768], primals_62, primals_61, 1e-05)
        getitem_9 = native_layer_norm_default_3[0]
        getitem_10 = native_layer_norm_default_3[1]
        getitem_11 = native_layer_norm_default_3[2];  native_layer_norm_default_3 = None
        transpose_int_30 = torch.ops.aten.transpose.int(getitem_9, 0, 1)
        t_default_12 = torch.ops.aten.t.default(primals_72);  primals_72 = None
        clone_default_18 = torch.ops.aten.clone.default(transpose_int_30, memory_format = torch.contiguous_format)
        _unsafe_view_default_26 = torch.ops.aten._unsafe_view.default(clone_default_18, [2048, 768]);  clone_default_18 = None
        mm_default_8 = torch.ops.aten.mm.default(_unsafe_view_default_26, t_default_12)
        _unsafe_view_default_27 = torch.ops.aten._unsafe_view.default(mm_default_8, [1024, 2, 768]);  mm_default_8 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(_unsafe_view_default_27, primals_71);  _unsafe_view_default_27 = primals_71 = None
        t_default_13 = torch.ops.aten.t.default(primals_70);  primals_70 = None
        clone_default_19 = torch.ops.aten.clone.default(transpose_int_30, memory_format = torch.contiguous_format)
        _unsafe_view_default_28 = torch.ops.aten._unsafe_view.default(clone_default_19, [2048, 768]);  clone_default_19 = None
        mm_default_9 = torch.ops.aten.mm.default(_unsafe_view_default_28, t_default_13)
        _unsafe_view_default_29 = torch.ops.aten._unsafe_view.default(mm_default_9, [1024, 2, 768]);  mm_default_9 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(_unsafe_view_default_29, primals_69);  _unsafe_view_default_29 = primals_69 = None
        t_default_14 = torch.ops.aten.t.default(primals_74);  primals_74 = None
        clone_default_20 = torch.ops.aten.clone.default(transpose_int_30, memory_format = torch.contiguous_format);  transpose_int_30 = None
        _unsafe_view_default_30 = torch.ops.aten._unsafe_view.default(clone_default_20, [2048, 768]);  clone_default_20 = None
        mm_default_10 = torch.ops.aten.mm.default(_unsafe_view_default_30, t_default_14)
        _unsafe_view_default_31 = torch.ops.aten._unsafe_view.default(mm_default_10, [1024, 2, 768]);  mm_default_10 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(_unsafe_view_default_31, primals_73);  _unsafe_view_default_31 = primals_73 = None
        div__tensor_2 = torch.ops.aten.div_.Tensor(add_tensor_12, 8.0);  add_tensor_12 = None
        view_default_56 = torch.ops.aten.view.default(div__tensor_2, [1024, 2, 12, 64]);  div__tensor_2 = None
        transpose_int_31 = torch.ops.aten.transpose.int(view_default_56, 0, 1);  view_default_56 = None
        view_default_57 = torch.ops.aten.view.default(add_tensor_13, [1024, 2, 12, 64]);  add_tensor_13 = None
        transpose_int_32 = torch.ops.aten.transpose.int(view_default_57, 0, 1);  view_default_57 = None
        transpose_int_33 = torch.ops.aten.transpose.int(transpose_int_31, 1, 2);  transpose_int_31 = None
        view_default_58 = torch.ops.aten.view.default(transpose_int_33, [24, 1024, 64]);  transpose_int_33 = None
        transpose_int_34 = torch.ops.aten.transpose.int(transpose_int_32, 1, 2);  transpose_int_32 = None
        view_default_59 = torch.ops.aten.view.default(transpose_int_34, [24, 1024, 64]);  transpose_int_34 = None
        view_default_60 = torch.ops.aten.view.default(view_default_58, [24, 2, 512, 64]);  view_default_58 = None
        as_strided_default_10 = torch.ops.aten.as_strided.default(view_default_60, [24, 3, 512, 64], [64, 393216, 1536, 1]);  view_default_60 = None
        view_default_61 = torch.ops.aten.view.default(view_default_59, [24, 2, 512, 64]);  view_default_59 = None
        as_strided_default_11 = torch.ops.aten.as_strided.default(view_default_61, [24, 3, 512, 64], [64, 393216, 1536, 1]);  view_default_61 = None
        unsqueeze_default_28 = torch.ops.aten.unsqueeze.default(as_strided_default_10, -1);  as_strided_default_10 = None
        permute_default_24 = torch.ops.aten.permute.default(unsqueeze_default_28, [0, 1, 2, 4, 3]);  unsqueeze_default_28 = None
        unsqueeze_default_29 = torch.ops.aten.unsqueeze.default(as_strided_default_11, -1);  as_strided_default_11 = None
        permute_default_25 = torch.ops.aten.permute.default(unsqueeze_default_29, [0, 1, 4, 2, 3]);  unsqueeze_default_29 = None
        permute_default_26 = torch.ops.aten.permute.default(permute_default_24, [0, 1, 2, 4, 3]);  permute_default_24 = None
        clone_default_21 = torch.ops.aten.clone.default(permute_default_26, memory_format = torch.contiguous_format);  permute_default_26 = None
        _unsafe_view_default_32 = torch.ops.aten._unsafe_view.default(clone_default_21, [72, 512, 64]);  clone_default_21 = None
        permute_default_27 = torch.ops.aten.permute.default(permute_default_25, [0, 1, 4, 3, 2]);  permute_default_25 = None
        clone_default_22 = torch.ops.aten.clone.default(permute_default_27, memory_format = torch.contiguous_format);  permute_default_27 = None
        _unsafe_view_default_33 = torch.ops.aten._unsafe_view.default(clone_default_22, [72, 64, 512]);  clone_default_22 = None
        bmm_default_4 = torch.ops.aten.bmm.default(_unsafe_view_default_32, _unsafe_view_default_33)
        view_default_62 = torch.ops.aten.view.default(bmm_default_4, [24, 3, 512, 1, 512]);  bmm_default_4 = None
        permute_default_28 = torch.ops.aten.permute.default(view_default_62, [0, 1, 2, 4, 3]);  view_default_62 = None
        view_default_63 = torch.ops.aten.view.default(permute_default_28, [24, 3, 512, 512]);  permute_default_28 = None
        constant_pad_nd_default_8 = torch.ops.aten.constant_pad_nd.default(view_default_63, [0, 0, 0, 1], 0.0);  view_default_63 = None
        view_default_64 = torch.ops.aten.view.default(constant_pad_nd_default_8, [24, 3, 512, 513]);  constant_pad_nd_default_8 = None
        new_empty_default_10 = torch.ops.aten.new_empty.default(view_default_64, [24, 4, 256, 513], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        slice_tensor_174 = torch.ops.aten.slice.Tensor(view_default_64, 0, 0, 9223372036854775807)
        slice_tensor_175 = torch.ops.aten.slice.Tensor(slice_tensor_174, 1, 0, 9223372036854775807);  slice_tensor_174 = None
        slice_tensor_176 = torch.ops.aten.slice.Tensor(slice_tensor_175, 2, 0, 256);  slice_tensor_175 = None
        slice_tensor_177 = torch.ops.aten.slice.Tensor(slice_tensor_176, 3, 0, 257);  slice_tensor_176 = None
        slice_tensor_178 = torch.ops.aten.slice.Tensor(new_empty_default_10, 0, 0, 9223372036854775807)
        slice_tensor_179 = torch.ops.aten.slice.Tensor(slice_tensor_178, 1, 0, -1);  slice_tensor_178 = None
        slice_tensor_180 = torch.ops.aten.slice.Tensor(slice_tensor_179, 2, 0, 9223372036854775807);  slice_tensor_179 = None
        slice_tensor_181 = torch.ops.aten.slice.Tensor(slice_tensor_180, 3, 256, 9223372036854775807);  slice_tensor_180 = None
        copy__default_16 = torch.ops.aten.copy_.default(slice_tensor_181, slice_tensor_177);  slice_tensor_181 = slice_tensor_177 = None
        slice_tensor_182 = torch.ops.aten.slice.Tensor(view_default_64, 0, 0, 9223372036854775807)
        select_int_16 = torch.ops.aten.select.int(slice_tensor_182, 1, -1);  slice_tensor_182 = None
        slice_tensor_183 = torch.ops.aten.slice.Tensor(select_int_16, 1, 256, 9223372036854775807);  select_int_16 = None
        slice_tensor_184 = torch.ops.aten.slice.Tensor(slice_tensor_183, 2, 0, 257);  slice_tensor_183 = None
        slice_tensor_185 = torch.ops.aten.slice.Tensor(new_empty_default_10, 0, 0, 9223372036854775807)
        select_int_17 = torch.ops.aten.select.int(slice_tensor_185, 1, -1);  slice_tensor_185 = None
        slice_tensor_186 = torch.ops.aten.slice.Tensor(select_int_17, 1, 0, 9223372036854775807);  select_int_17 = None
        slice_tensor_187 = torch.ops.aten.slice.Tensor(slice_tensor_186, 2, 256, 9223372036854775807);  slice_tensor_186 = None
        copy__default_17 = torch.ops.aten.copy_.default(slice_tensor_187, slice_tensor_184);  slice_tensor_187 = slice_tensor_184 = None
        slice_tensor_188 = torch.ops.aten.slice.Tensor(view_default_64, 0, 0, 9223372036854775807)
        slice_tensor_189 = torch.ops.aten.slice.Tensor(slice_tensor_188, 1, 0, 9223372036854775807);  slice_tensor_188 = None
        slice_tensor_190 = torch.ops.aten.slice.Tensor(slice_tensor_189, 2, -257, -1);  slice_tensor_189 = None
        slice_tensor_191 = torch.ops.aten.slice.Tensor(slice_tensor_190, 3, 257, 9223372036854775807);  slice_tensor_190 = None
        slice_tensor_192 = torch.ops.aten.slice.Tensor(new_empty_default_10, 0, 0, 9223372036854775807)
        slice_tensor_193 = torch.ops.aten.slice.Tensor(slice_tensor_192, 1, 1, 9223372036854775807);  slice_tensor_192 = None
        slice_tensor_194 = torch.ops.aten.slice.Tensor(slice_tensor_193, 2, 0, 9223372036854775807);  slice_tensor_193 = None
        slice_tensor_195 = torch.ops.aten.slice.Tensor(slice_tensor_194, 3, 0, 256);  slice_tensor_194 = None
        copy__default_18 = torch.ops.aten.copy_.default(slice_tensor_195, slice_tensor_191);  slice_tensor_195 = slice_tensor_191 = None
        slice_tensor_196 = torch.ops.aten.slice.Tensor(view_default_64, 0, 0, 9223372036854775807);  view_default_64 = None
        select_int_18 = torch.ops.aten.select.int(slice_tensor_196, 1, 0);  slice_tensor_196 = None
        slice_tensor_197 = torch.ops.aten.slice.Tensor(select_int_18, 1, 0, 255);  select_int_18 = None
        slice_tensor_198 = torch.ops.aten.slice.Tensor(slice_tensor_197, 2, -255, 9223372036854775807);  slice_tensor_197 = None
        slice_tensor_199 = torch.ops.aten.slice.Tensor(new_empty_default_10, 0, 0, 9223372036854775807)
        select_int_19 = torch.ops.aten.select.int(slice_tensor_199, 1, 0);  slice_tensor_199 = None
        slice_tensor_200 = torch.ops.aten.slice.Tensor(select_int_19, 1, 1, 256);  select_int_19 = None
        slice_tensor_201 = torch.ops.aten.slice.Tensor(slice_tensor_200, 2, 1, 256);  slice_tensor_200 = None
        copy__default_19 = torch.ops.aten.copy_.default(slice_tensor_201, slice_tensor_198);  slice_tensor_201 = slice_tensor_198 = None
        view_default_65 = torch.ops.aten.view.default(new_empty_default_10, [2, 12, 1024, 513]);  new_empty_default_10 = None
        transpose_int_35 = torch.ops.aten.transpose.int(view_default_65, 2, 1);  view_default_65 = None
        new_empty_default_11 = torch.ops.aten.new_empty.default(transpose_int_35, [256, 257], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        fill__scalar_6 = torch.ops.aten.fill_.Scalar(new_empty_default_11, 1.0);  new_empty_default_11 = None
        tril_default_4 = torch.ops.aten.tril.default(fill__scalar_6);  fill__scalar_6 = None
        flip_default_8 = torch.ops.aten.flip.default(tril_default_4, [0]);  tril_default_4 = None
        unsqueeze_default_30 = torch.ops.aten.unsqueeze.default(flip_default_8, 0);  flip_default_8 = None
        slice_tensor_202 = torch.ops.aten.slice.Tensor(unsqueeze_default_30, 1, 0, 9223372036854775807);  unsqueeze_default_30 = None
        unsqueeze_default_31 = torch.ops.aten.unsqueeze.default(slice_tensor_202, 2);  slice_tensor_202 = None
        slice_tensor_203 = torch.ops.aten.slice.Tensor(unsqueeze_default_31, 3, 0, 9223372036854775807);  unsqueeze_default_31 = None
        flip_default_9 = torch.ops.aten.flip.default(slice_tensor_203, [1, 3])
        slice_tensor_204 = torch.ops.aten.slice.Tensor(transpose_int_35, 0, 0, 9223372036854775807)
        slice_tensor_205 = torch.ops.aten.slice.Tensor(slice_tensor_204, 1, 0, 256);  slice_tensor_204 = None
        slice_tensor_206 = torch.ops.aten.slice.Tensor(slice_tensor_205, 2, 0, 9223372036854775807);  slice_tensor_205 = None
        slice_tensor_207 = torch.ops.aten.slice.Tensor(slice_tensor_206, 3, 0, 257);  slice_tensor_206 = None
        expand_sym_int_8 = torch.ops.aten.expand.SymInt(slice_tensor_203, [2, 256, 12, 257]);  slice_tensor_203 = None
        eq_scalar_8 = torch.ops.aten.eq.Scalar(expand_sym_int_8, 1);  expand_sym_int_8 = None
        masked_fill__scalar_8 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_207, eq_scalar_8, -inf);  slice_tensor_207 = None
        slice_tensor_208 = torch.ops.aten.slice.Tensor(transpose_int_35, 0, 0, 9223372036854775807)
        slice_tensor_209 = torch.ops.aten.slice.Tensor(slice_tensor_208, 1, -256, 9223372036854775807);  slice_tensor_208 = None
        slice_tensor_210 = torch.ops.aten.slice.Tensor(slice_tensor_209, 2, 0, 9223372036854775807);  slice_tensor_209 = None
        slice_tensor_211 = torch.ops.aten.slice.Tensor(slice_tensor_210, 3, -257, 9223372036854775807);  slice_tensor_210 = None
        expand_sym_int_9 = torch.ops.aten.expand.SymInt(flip_default_9, [2, 256, 12, 257]);  flip_default_9 = None
        eq_scalar_9 = torch.ops.aten.eq.Scalar(expand_sym_int_9, 1);  expand_sym_int_9 = None
        masked_fill__scalar_9 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_211, eq_scalar_9, -inf);  slice_tensor_211 = None
        ne_scalar_2 = torch.ops.aten.ne.Scalar(primals_194, 0)
        slice_tensor_212 = torch.ops.aten.slice.Tensor(ne_scalar_2, 0, 0, 9223372036854775807);  ne_scalar_2 = None
        slice_tensor_213 = torch.ops.aten.slice.Tensor(slice_tensor_212, 1, 0, 9223372036854775807);  slice_tensor_212 = None
        unsqueeze_default_32 = torch.ops.aten.unsqueeze.default(slice_tensor_213, 2);  slice_tensor_213 = None
        unsqueeze_default_33 = torch.ops.aten.unsqueeze.default(unsqueeze_default_32, 3);  unsqueeze_default_32 = None
        _to_copy_default_2 = torch.ops.aten._to_copy.default(unsqueeze_default_33, device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided)
        where_scalar_self_4 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_33, -10000.0, _to_copy_default_2);  unsqueeze_default_33 = _to_copy_default_2 = None
        new_empty_default_12 = torch.ops.aten.new_empty.default(where_scalar_self_4, [2, 1024, 1, 1], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        fill__scalar_7 = torch.ops.aten.fill_.Scalar(new_empty_default_12, 1.0);  new_empty_default_12 = None
        transpose_int_36 = torch.ops.aten.transpose.int(fill__scalar_7, 1, 2);  fill__scalar_7 = None
        view_default_66 = torch.ops.aten.view.default(transpose_int_36, [2, 1024, 1]);  transpose_int_36 = None
        transpose_int_37 = torch.ops.aten.transpose.int(where_scalar_self_4, 1, 2);  where_scalar_self_4 = None
        view_default_67 = torch.ops.aten.view.default(transpose_int_37, [2, 1024, 1]);  transpose_int_37 = None
        view_default_68 = torch.ops.aten.view.default(view_default_66, [2, 2, 512, 1]);  view_default_66 = None
        as_strided_default_12 = torch.ops.aten.as_strided.default(view_default_68, [2, 3, 512, 1], [1024, 256, 1, 1]);  view_default_68 = None
        view_default_69 = torch.ops.aten.view.default(view_default_67, [2, 2, 512, 1]);  view_default_67 = None
        as_strided_default_13 = torch.ops.aten.as_strided.default(view_default_69, [2, 3, 512, 1], [1024, 256, 1, 1]);  view_default_69 = None
        unsqueeze_default_34 = torch.ops.aten.unsqueeze.default(as_strided_default_12, -1);  as_strided_default_12 = None
        permute_default_29 = torch.ops.aten.permute.default(unsqueeze_default_34, [0, 1, 2, 4, 3]);  unsqueeze_default_34 = None
        unsqueeze_default_35 = torch.ops.aten.unsqueeze.default(as_strided_default_13, -1);  as_strided_default_13 = None
        permute_default_30 = torch.ops.aten.permute.default(unsqueeze_default_35, [0, 1, 4, 2, 3]);  unsqueeze_default_35 = None
        squeeze_dim_4 = torch.ops.aten.squeeze.dim(permute_default_29, 4);  permute_default_29 = None
        squeeze_dim_5 = torch.ops.aten.squeeze.dim(permute_default_30, 4);  permute_default_30 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(squeeze_dim_4, squeeze_dim_5);  squeeze_dim_4 = squeeze_dim_5 = None
        constant_pad_nd_default_9 = torch.ops.aten.constant_pad_nd.default(mul_tensor_2, [0, 0, 0, 1], 0.0);  mul_tensor_2 = None
        view_default_70 = torch.ops.aten.view.default(constant_pad_nd_default_9, [2, 3, 512, 513]);  constant_pad_nd_default_9 = None
        new_empty_default_13 = torch.ops.aten.new_empty.default(view_default_70, [2, 4, 256, 513], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        slice_tensor_214 = torch.ops.aten.slice.Tensor(view_default_70, 0, 0, 9223372036854775807)
        slice_tensor_215 = torch.ops.aten.slice.Tensor(slice_tensor_214, 1, 0, 9223372036854775807);  slice_tensor_214 = None
        slice_tensor_216 = torch.ops.aten.slice.Tensor(slice_tensor_215, 2, 0, 256);  slice_tensor_215 = None
        slice_tensor_217 = torch.ops.aten.slice.Tensor(slice_tensor_216, 3, 0, 257);  slice_tensor_216 = None
        slice_tensor_218 = torch.ops.aten.slice.Tensor(new_empty_default_13, 0, 0, 9223372036854775807)
        slice_tensor_219 = torch.ops.aten.slice.Tensor(slice_tensor_218, 1, 0, -1);  slice_tensor_218 = None
        slice_tensor_220 = torch.ops.aten.slice.Tensor(slice_tensor_219, 2, 0, 9223372036854775807);  slice_tensor_219 = None
        slice_tensor_221 = torch.ops.aten.slice.Tensor(slice_tensor_220, 3, 256, 9223372036854775807);  slice_tensor_220 = None
        copy__default_20 = torch.ops.aten.copy_.default(slice_tensor_221, slice_tensor_217);  slice_tensor_221 = slice_tensor_217 = None
        slice_tensor_222 = torch.ops.aten.slice.Tensor(view_default_70, 0, 0, 9223372036854775807)
        select_int_20 = torch.ops.aten.select.int(slice_tensor_222, 1, -1);  slice_tensor_222 = None
        slice_tensor_223 = torch.ops.aten.slice.Tensor(select_int_20, 1, 256, 9223372036854775807);  select_int_20 = None
        slice_tensor_224 = torch.ops.aten.slice.Tensor(slice_tensor_223, 2, 0, 257);  slice_tensor_223 = None
        slice_tensor_225 = torch.ops.aten.slice.Tensor(new_empty_default_13, 0, 0, 9223372036854775807)
        select_int_21 = torch.ops.aten.select.int(slice_tensor_225, 1, -1);  slice_tensor_225 = None
        slice_tensor_226 = torch.ops.aten.slice.Tensor(select_int_21, 1, 0, 9223372036854775807);  select_int_21 = None
        slice_tensor_227 = torch.ops.aten.slice.Tensor(slice_tensor_226, 2, 256, 9223372036854775807);  slice_tensor_226 = None
        copy__default_21 = torch.ops.aten.copy_.default(slice_tensor_227, slice_tensor_224);  slice_tensor_227 = slice_tensor_224 = None
        slice_tensor_228 = torch.ops.aten.slice.Tensor(view_default_70, 0, 0, 9223372036854775807)
        slice_tensor_229 = torch.ops.aten.slice.Tensor(slice_tensor_228, 1, 0, 9223372036854775807);  slice_tensor_228 = None
        slice_tensor_230 = torch.ops.aten.slice.Tensor(slice_tensor_229, 2, -257, -1);  slice_tensor_229 = None
        slice_tensor_231 = torch.ops.aten.slice.Tensor(slice_tensor_230, 3, 257, 9223372036854775807);  slice_tensor_230 = None
        slice_tensor_232 = torch.ops.aten.slice.Tensor(new_empty_default_13, 0, 0, 9223372036854775807)
        slice_tensor_233 = torch.ops.aten.slice.Tensor(slice_tensor_232, 1, 1, 9223372036854775807);  slice_tensor_232 = None
        slice_tensor_234 = torch.ops.aten.slice.Tensor(slice_tensor_233, 2, 0, 9223372036854775807);  slice_tensor_233 = None
        slice_tensor_235 = torch.ops.aten.slice.Tensor(slice_tensor_234, 3, 0, 256);  slice_tensor_234 = None
        copy__default_22 = torch.ops.aten.copy_.default(slice_tensor_235, slice_tensor_231);  slice_tensor_235 = slice_tensor_231 = None
        slice_tensor_236 = torch.ops.aten.slice.Tensor(view_default_70, 0, 0, 9223372036854775807);  view_default_70 = None
        select_int_22 = torch.ops.aten.select.int(slice_tensor_236, 1, 0);  slice_tensor_236 = None
        slice_tensor_237 = torch.ops.aten.slice.Tensor(select_int_22, 1, 0, 255);  select_int_22 = None
        slice_tensor_238 = torch.ops.aten.slice.Tensor(slice_tensor_237, 2, -255, 9223372036854775807);  slice_tensor_237 = None
        slice_tensor_239 = torch.ops.aten.slice.Tensor(new_empty_default_13, 0, 0, 9223372036854775807)
        select_int_23 = torch.ops.aten.select.int(slice_tensor_239, 1, 0);  slice_tensor_239 = None
        slice_tensor_240 = torch.ops.aten.slice.Tensor(select_int_23, 1, 1, 256);  select_int_23 = None
        slice_tensor_241 = torch.ops.aten.slice.Tensor(slice_tensor_240, 2, 1, 256);  slice_tensor_240 = None
        copy__default_23 = torch.ops.aten.copy_.default(slice_tensor_241, slice_tensor_238);  slice_tensor_241 = slice_tensor_238 = None
        view_default_71 = torch.ops.aten.view.default(new_empty_default_13, [2, 1, 1024, 513]);  new_empty_default_13 = None
        transpose_int_38 = torch.ops.aten.transpose.int(view_default_71, 2, 1);  view_default_71 = None
        new_empty_default_14 = torch.ops.aten.new_empty.default(transpose_int_38, [256, 257], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        fill__scalar_8 = torch.ops.aten.fill_.Scalar(new_empty_default_14, 1.0);  new_empty_default_14 = None
        tril_default_5 = torch.ops.aten.tril.default(fill__scalar_8);  fill__scalar_8 = None
        flip_default_10 = torch.ops.aten.flip.default(tril_default_5, [0]);  tril_default_5 = None
        unsqueeze_default_36 = torch.ops.aten.unsqueeze.default(flip_default_10, 0);  flip_default_10 = None
        slice_tensor_242 = torch.ops.aten.slice.Tensor(unsqueeze_default_36, 1, 0, 9223372036854775807);  unsqueeze_default_36 = None
        unsqueeze_default_37 = torch.ops.aten.unsqueeze.default(slice_tensor_242, 2);  slice_tensor_242 = None
        slice_tensor_243 = torch.ops.aten.slice.Tensor(unsqueeze_default_37, 3, 0, 9223372036854775807);  unsqueeze_default_37 = None
        flip_default_11 = torch.ops.aten.flip.default(slice_tensor_243, [1, 3])
        slice_tensor_244 = torch.ops.aten.slice.Tensor(transpose_int_38, 0, 0, 9223372036854775807)
        slice_tensor_245 = torch.ops.aten.slice.Tensor(slice_tensor_244, 1, 0, 256);  slice_tensor_244 = None
        slice_tensor_246 = torch.ops.aten.slice.Tensor(slice_tensor_245, 2, 0, 9223372036854775807);  slice_tensor_245 = None
        slice_tensor_247 = torch.ops.aten.slice.Tensor(slice_tensor_246, 3, 0, 257);  slice_tensor_246 = None
        expand_sym_int_10 = torch.ops.aten.expand.SymInt(slice_tensor_243, [2, 256, 1, 257]);  slice_tensor_243 = None
        eq_scalar_10 = torch.ops.aten.eq.Scalar(expand_sym_int_10, 1);  expand_sym_int_10 = None
        masked_fill__scalar_10 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_247, eq_scalar_10, -inf);  slice_tensor_247 = eq_scalar_10 = None
        slice_tensor_248 = torch.ops.aten.slice.Tensor(transpose_int_38, 0, 0, 9223372036854775807)
        slice_tensor_249 = torch.ops.aten.slice.Tensor(slice_tensor_248, 1, -256, 9223372036854775807);  slice_tensor_248 = None
        slice_tensor_250 = torch.ops.aten.slice.Tensor(slice_tensor_249, 2, 0, 9223372036854775807);  slice_tensor_249 = None
        slice_tensor_251 = torch.ops.aten.slice.Tensor(slice_tensor_250, 3, -257, 9223372036854775807);  slice_tensor_250 = None
        expand_sym_int_11 = torch.ops.aten.expand.SymInt(flip_default_11, [2, 256, 1, 257]);  flip_default_11 = None
        eq_scalar_11 = torch.ops.aten.eq.Scalar(expand_sym_int_11, 1);  expand_sym_int_11 = None
        masked_fill__scalar_11 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_251, eq_scalar_11, -inf);  slice_tensor_251 = eq_scalar_11 = None
        add__tensor_2 = torch.ops.aten.add_.Tensor(transpose_int_35, transpose_int_38);  transpose_int_35 = transpose_int_38 = None
        _softmax_default_2 = torch.ops.aten._softmax.default(add__tensor_2, -1, False);  add__tensor_2 = None
        slice_tensor_252 = torch.ops.aten.slice.Tensor(primals_195, 0, 0, 9223372036854775807)
        slice_tensor_253 = torch.ops.aten.slice.Tensor(slice_tensor_252, 1, 0, 9223372036854775807);  slice_tensor_252 = None
        unsqueeze_default_38 = torch.ops.aten.unsqueeze.default(slice_tensor_253, 2);  slice_tensor_253 = None
        unsqueeze_default_39 = torch.ops.aten.unsqueeze.default(unsqueeze_default_38, 3);  unsqueeze_default_38 = None
        where_scalar_self_5 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_39, 0.0, _softmax_default_2)
        view_default_72 = torch.ops.aten.view.default(add_tensor_14, [1024, 2, 12, 64]);  add_tensor_14 = None
        transpose_int_39 = torch.ops.aten.transpose.int(view_default_72, 0, 1);  view_default_72 = None
        transpose_int_40 = torch.ops.aten.transpose.int(where_scalar_self_5, 1, 2);  where_scalar_self_5 = None
        clone_default_23 = torch.ops.aten.clone.default(transpose_int_40, memory_format = torch.contiguous_format);  transpose_int_40 = None
        _unsafe_view_default_34 = torch.ops.aten._unsafe_view.default(clone_default_23, [24, 4, 256, 513]);  clone_default_23 = None
        transpose_int_41 = torch.ops.aten.transpose.int(transpose_int_39, 1, 2);  transpose_int_39 = None
        view_default_73 = torch.ops.aten.view.default(transpose_int_41, [24, 1024, 64]);  transpose_int_41 = None
        constant_pad_nd_default_10 = torch.ops.aten.constant_pad_nd.default(view_default_73, [0, 0, 256, 256], -1.0);  view_default_73 = None
        as_strided_default_14 = torch.ops.aten.as_strided.default(constant_pad_nd_default_10, [24, 4, 768, 64], [98304, 16384, 64, 1]);  constant_pad_nd_default_10 = None
        constant_pad_nd_default_11 = torch.ops.aten.constant_pad_nd.default(_unsafe_view_default_34, [0, 257], 0.0);  _unsafe_view_default_34 = None
        view_default_74 = torch.ops.aten.view.default(constant_pad_nd_default_11, [24, 4, -1]);  constant_pad_nd_default_11 = None
        slice_tensor_254 = torch.ops.aten.slice.Tensor(view_default_74, 0, 0, 9223372036854775807);  view_default_74 = None
        slice_tensor_255 = torch.ops.aten.slice.Tensor(slice_tensor_254, 1, 0, 9223372036854775807);  slice_tensor_254 = None
        slice_tensor_256 = torch.ops.aten.slice.Tensor(slice_tensor_255, 2, 0, -256);  slice_tensor_255 = None
        view_default_75 = torch.ops.aten.view.default(slice_tensor_256, [24, 4, 256, 769]);  slice_tensor_256 = None
        slice_tensor_257 = torch.ops.aten.slice.Tensor(view_default_75, 0, 0, 9223372036854775807);  view_default_75 = None
        slice_tensor_258 = torch.ops.aten.slice.Tensor(slice_tensor_257, 1, 0, 9223372036854775807);  slice_tensor_257 = None
        slice_tensor_259 = torch.ops.aten.slice.Tensor(slice_tensor_258, 2, 0, 9223372036854775807);  slice_tensor_258 = None
        slice_tensor_260 = torch.ops.aten.slice.Tensor(slice_tensor_259, 3, 0, -1);  slice_tensor_259 = None
        unsqueeze_default_40 = torch.ops.aten.unsqueeze.default(slice_tensor_260, -1);  slice_tensor_260 = None
        permute_default_31 = torch.ops.aten.permute.default(unsqueeze_default_40, [0, 1, 2, 4, 3]);  unsqueeze_default_40 = None
        unsqueeze_default_41 = torch.ops.aten.unsqueeze.default(as_strided_default_14, -1);  as_strided_default_14 = None
        permute_default_32 = torch.ops.aten.permute.default(unsqueeze_default_41, [0, 1, 4, 3, 2]);  unsqueeze_default_41 = None
        permute_default_33 = torch.ops.aten.permute.default(permute_default_31, [0, 1, 2, 4, 3]);  permute_default_31 = None
        view_default_76 = torch.ops.aten.view.default(permute_default_33, [96, 256, 768]);  permute_default_33 = None
        permute_default_34 = torch.ops.aten.permute.default(permute_default_32, [0, 1, 4, 3, 2]);  permute_default_32 = None
        clone_default_24 = torch.ops.aten.clone.default(permute_default_34, memory_format = torch.contiguous_format);  permute_default_34 = None
        _unsafe_view_default_35 = torch.ops.aten._unsafe_view.default(clone_default_24, [96, 768, 64]);  clone_default_24 = None
        bmm_default_5 = torch.ops.aten.bmm.default(view_default_76, _unsafe_view_default_35)
        view_default_77 = torch.ops.aten.view.default(bmm_default_5, [24, 4, 256, 1, 64]);  bmm_default_5 = None
        permute_default_35 = torch.ops.aten.permute.default(view_default_77, [0, 1, 2, 4, 3]);  view_default_77 = None
        view_default_78 = torch.ops.aten.view.default(permute_default_35, [24, 4, 256, 64]);  permute_default_35 = None
        view_default_79 = torch.ops.aten.view.default(view_default_78, [2, 12, 1024, 64]);  view_default_78 = None
        transpose_int_42 = torch.ops.aten.transpose.int(view_default_79, 1, 2);  view_default_79 = None
        transpose_int_43 = torch.ops.aten.transpose.int(transpose_int_42, 0, 1);  transpose_int_42 = None
        clone_default_25 = torch.ops.aten.clone.default(transpose_int_43, memory_format = torch.contiguous_format);  transpose_int_43 = None
        _unsafe_view_default_36 = torch.ops.aten._unsafe_view.default(clone_default_25, [1024, 2, 768]);  clone_default_25 = None
        transpose_int_44 = torch.ops.aten.transpose.int(_unsafe_view_default_36, 0, 1);  _unsafe_view_default_36 = None
        t_default_15 = torch.ops.aten.t.default(primals_68);  primals_68 = None
        clone_default_26 = torch.ops.aten.clone.default(transpose_int_44, memory_format = torch.contiguous_format);  transpose_int_44 = None
        _unsafe_view_default_37 = torch.ops.aten._unsafe_view.default(clone_default_26, [2048, 768]);  clone_default_26 = None
        mm_default_11 = torch.ops.aten.mm.default(_unsafe_view_default_37, t_default_15)
        _unsafe_view_default_38 = torch.ops.aten._unsafe_view.default(mm_default_11, [2, 1024, 768]);  mm_default_11 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(_unsafe_view_default_38, primals_67);  _unsafe_view_default_38 = primals_67 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(add_tensor_15, getitem_9);  add_tensor_15 = getitem_9 = None
        native_layer_norm_default_4 = torch.ops.aten.native_layer_norm.default(add_tensor_16, [768], primals_66, primals_65, 1e-05)
        getitem_12 = native_layer_norm_default_4[0]
        getitem_13 = native_layer_norm_default_4[1]
        getitem_14 = native_layer_norm_default_4[2];  native_layer_norm_default_4 = None
        view_default_80 = torch.ops.aten.view.default(getitem_12, [2048, 768])
        t_default_16 = torch.ops.aten.t.default(primals_76);  primals_76 = None
        addmm_default_4 = torch.ops.aten.addmm.default(primals_75, view_default_80, t_default_16);  primals_75 = None
        view_default_81 = torch.ops.aten.view.default(addmm_default_4, [2, 1024, 3072]);  addmm_default_4 = None
        gelu_default_2 = torch.ops.aten.gelu.default(view_default_81)
        view_default_82 = torch.ops.aten.view.default(gelu_default_2, [2048, 3072]);  gelu_default_2 = None
        t_default_17 = torch.ops.aten.t.default(primals_80);  primals_80 = None
        addmm_default_5 = torch.ops.aten.addmm.default(primals_79, view_default_82, t_default_17);  primals_79 = None
        view_default_83 = torch.ops.aten.view.default(addmm_default_5, [2, 1024, 768]);  addmm_default_5 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(view_default_83, getitem_12);  view_default_83 = getitem_12 = None
        native_layer_norm_default_5 = torch.ops.aten.native_layer_norm.default(add_tensor_17, [768], primals_78, primals_77, 1e-05)
        getitem_15 = native_layer_norm_default_5[0]
        getitem_16 = native_layer_norm_default_5[1]
        getitem_17 = native_layer_norm_default_5[2];  native_layer_norm_default_5 = None
        transpose_int_45 = torch.ops.aten.transpose.int(getitem_15, 0, 1)
        t_default_18 = torch.ops.aten.t.default(primals_88);  primals_88 = None
        clone_default_27 = torch.ops.aten.clone.default(transpose_int_45, memory_format = torch.contiguous_format)
        _unsafe_view_default_39 = torch.ops.aten._unsafe_view.default(clone_default_27, [2048, 768]);  clone_default_27 = None
        mm_default_12 = torch.ops.aten.mm.default(_unsafe_view_default_39, t_default_18)
        _unsafe_view_default_40 = torch.ops.aten._unsafe_view.default(mm_default_12, [1024, 2, 768]);  mm_default_12 = None
        add_tensor_18 = torch.ops.aten.add.Tensor(_unsafe_view_default_40, primals_87);  _unsafe_view_default_40 = primals_87 = None
        t_default_19 = torch.ops.aten.t.default(primals_86);  primals_86 = None
        clone_default_28 = torch.ops.aten.clone.default(transpose_int_45, memory_format = torch.contiguous_format)
        _unsafe_view_default_41 = torch.ops.aten._unsafe_view.default(clone_default_28, [2048, 768]);  clone_default_28 = None
        mm_default_13 = torch.ops.aten.mm.default(_unsafe_view_default_41, t_default_19)
        _unsafe_view_default_42 = torch.ops.aten._unsafe_view.default(mm_default_13, [1024, 2, 768]);  mm_default_13 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(_unsafe_view_default_42, primals_85);  _unsafe_view_default_42 = primals_85 = None
        t_default_20 = torch.ops.aten.t.default(primals_90);  primals_90 = None
        clone_default_29 = torch.ops.aten.clone.default(transpose_int_45, memory_format = torch.contiguous_format);  transpose_int_45 = None
        _unsafe_view_default_43 = torch.ops.aten._unsafe_view.default(clone_default_29, [2048, 768]);  clone_default_29 = None
        mm_default_14 = torch.ops.aten.mm.default(_unsafe_view_default_43, t_default_20)
        _unsafe_view_default_44 = torch.ops.aten._unsafe_view.default(mm_default_14, [1024, 2, 768]);  mm_default_14 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(_unsafe_view_default_44, primals_89);  _unsafe_view_default_44 = primals_89 = None
        div__tensor_3 = torch.ops.aten.div_.Tensor(add_tensor_18, 8.0);  add_tensor_18 = None
        view_default_84 = torch.ops.aten.view.default(div__tensor_3, [1024, 2, 12, 64]);  div__tensor_3 = None
        transpose_int_46 = torch.ops.aten.transpose.int(view_default_84, 0, 1);  view_default_84 = None
        view_default_85 = torch.ops.aten.view.default(add_tensor_19, [1024, 2, 12, 64]);  add_tensor_19 = None
        transpose_int_47 = torch.ops.aten.transpose.int(view_default_85, 0, 1);  view_default_85 = None
        transpose_int_48 = torch.ops.aten.transpose.int(transpose_int_46, 1, 2);  transpose_int_46 = None
        view_default_86 = torch.ops.aten.view.default(transpose_int_48, [24, 1024, 64]);  transpose_int_48 = None
        transpose_int_49 = torch.ops.aten.transpose.int(transpose_int_47, 1, 2);  transpose_int_47 = None
        view_default_87 = torch.ops.aten.view.default(transpose_int_49, [24, 1024, 64]);  transpose_int_49 = None
        view_default_88 = torch.ops.aten.view.default(view_default_86, [24, 2, 512, 64]);  view_default_86 = None
        as_strided_default_15 = torch.ops.aten.as_strided.default(view_default_88, [24, 3, 512, 64], [64, 393216, 1536, 1]);  view_default_88 = None
        view_default_89 = torch.ops.aten.view.default(view_default_87, [24, 2, 512, 64]);  view_default_87 = None
        as_strided_default_16 = torch.ops.aten.as_strided.default(view_default_89, [24, 3, 512, 64], [64, 393216, 1536, 1]);  view_default_89 = None
        unsqueeze_default_42 = torch.ops.aten.unsqueeze.default(as_strided_default_15, -1);  as_strided_default_15 = None
        permute_default_36 = torch.ops.aten.permute.default(unsqueeze_default_42, [0, 1, 2, 4, 3]);  unsqueeze_default_42 = None
        unsqueeze_default_43 = torch.ops.aten.unsqueeze.default(as_strided_default_16, -1);  as_strided_default_16 = None
        permute_default_37 = torch.ops.aten.permute.default(unsqueeze_default_43, [0, 1, 4, 2, 3]);  unsqueeze_default_43 = None
        permute_default_38 = torch.ops.aten.permute.default(permute_default_36, [0, 1, 2, 4, 3]);  permute_default_36 = None
        clone_default_30 = torch.ops.aten.clone.default(permute_default_38, memory_format = torch.contiguous_format);  permute_default_38 = None
        _unsafe_view_default_45 = torch.ops.aten._unsafe_view.default(clone_default_30, [72, 512, 64]);  clone_default_30 = None
        permute_default_39 = torch.ops.aten.permute.default(permute_default_37, [0, 1, 4, 3, 2]);  permute_default_37 = None
        clone_default_31 = torch.ops.aten.clone.default(permute_default_39, memory_format = torch.contiguous_format);  permute_default_39 = None
        _unsafe_view_default_46 = torch.ops.aten._unsafe_view.default(clone_default_31, [72, 64, 512]);  clone_default_31 = None
        bmm_default_6 = torch.ops.aten.bmm.default(_unsafe_view_default_45, _unsafe_view_default_46)
        view_default_90 = torch.ops.aten.view.default(bmm_default_6, [24, 3, 512, 1, 512]);  bmm_default_6 = None
        permute_default_40 = torch.ops.aten.permute.default(view_default_90, [0, 1, 2, 4, 3]);  view_default_90 = None
        view_default_91 = torch.ops.aten.view.default(permute_default_40, [24, 3, 512, 512]);  permute_default_40 = None
        constant_pad_nd_default_12 = torch.ops.aten.constant_pad_nd.default(view_default_91, [0, 0, 0, 1], 0.0);  view_default_91 = None
        view_default_92 = torch.ops.aten.view.default(constant_pad_nd_default_12, [24, 3, 512, 513]);  constant_pad_nd_default_12 = None
        new_empty_default_15 = torch.ops.aten.new_empty.default(view_default_92, [24, 4, 256, 513], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        slice_tensor_261 = torch.ops.aten.slice.Tensor(view_default_92, 0, 0, 9223372036854775807)
        slice_tensor_262 = torch.ops.aten.slice.Tensor(slice_tensor_261, 1, 0, 9223372036854775807);  slice_tensor_261 = None
        slice_tensor_263 = torch.ops.aten.slice.Tensor(slice_tensor_262, 2, 0, 256);  slice_tensor_262 = None
        slice_tensor_264 = torch.ops.aten.slice.Tensor(slice_tensor_263, 3, 0, 257);  slice_tensor_263 = None
        slice_tensor_265 = torch.ops.aten.slice.Tensor(new_empty_default_15, 0, 0, 9223372036854775807)
        slice_tensor_266 = torch.ops.aten.slice.Tensor(slice_tensor_265, 1, 0, -1);  slice_tensor_265 = None
        slice_tensor_267 = torch.ops.aten.slice.Tensor(slice_tensor_266, 2, 0, 9223372036854775807);  slice_tensor_266 = None
        slice_tensor_268 = torch.ops.aten.slice.Tensor(slice_tensor_267, 3, 256, 9223372036854775807);  slice_tensor_267 = None
        copy__default_24 = torch.ops.aten.copy_.default(slice_tensor_268, slice_tensor_264);  slice_tensor_268 = slice_tensor_264 = None
        slice_tensor_269 = torch.ops.aten.slice.Tensor(view_default_92, 0, 0, 9223372036854775807)
        select_int_24 = torch.ops.aten.select.int(slice_tensor_269, 1, -1);  slice_tensor_269 = None
        slice_tensor_270 = torch.ops.aten.slice.Tensor(select_int_24, 1, 256, 9223372036854775807);  select_int_24 = None
        slice_tensor_271 = torch.ops.aten.slice.Tensor(slice_tensor_270, 2, 0, 257);  slice_tensor_270 = None
        slice_tensor_272 = torch.ops.aten.slice.Tensor(new_empty_default_15, 0, 0, 9223372036854775807)
        select_int_25 = torch.ops.aten.select.int(slice_tensor_272, 1, -1);  slice_tensor_272 = None
        slice_tensor_273 = torch.ops.aten.slice.Tensor(select_int_25, 1, 0, 9223372036854775807);  select_int_25 = None
        slice_tensor_274 = torch.ops.aten.slice.Tensor(slice_tensor_273, 2, 256, 9223372036854775807);  slice_tensor_273 = None
        copy__default_25 = torch.ops.aten.copy_.default(slice_tensor_274, slice_tensor_271);  slice_tensor_274 = slice_tensor_271 = None
        slice_tensor_275 = torch.ops.aten.slice.Tensor(view_default_92, 0, 0, 9223372036854775807)
        slice_tensor_276 = torch.ops.aten.slice.Tensor(slice_tensor_275, 1, 0, 9223372036854775807);  slice_tensor_275 = None
        slice_tensor_277 = torch.ops.aten.slice.Tensor(slice_tensor_276, 2, -257, -1);  slice_tensor_276 = None
        slice_tensor_278 = torch.ops.aten.slice.Tensor(slice_tensor_277, 3, 257, 9223372036854775807);  slice_tensor_277 = None
        slice_tensor_279 = torch.ops.aten.slice.Tensor(new_empty_default_15, 0, 0, 9223372036854775807)
        slice_tensor_280 = torch.ops.aten.slice.Tensor(slice_tensor_279, 1, 1, 9223372036854775807);  slice_tensor_279 = None
        slice_tensor_281 = torch.ops.aten.slice.Tensor(slice_tensor_280, 2, 0, 9223372036854775807);  slice_tensor_280 = None
        slice_tensor_282 = torch.ops.aten.slice.Tensor(slice_tensor_281, 3, 0, 256);  slice_tensor_281 = None
        copy__default_26 = torch.ops.aten.copy_.default(slice_tensor_282, slice_tensor_278);  slice_tensor_282 = slice_tensor_278 = None
        slice_tensor_283 = torch.ops.aten.slice.Tensor(view_default_92, 0, 0, 9223372036854775807);  view_default_92 = None
        select_int_26 = torch.ops.aten.select.int(slice_tensor_283, 1, 0);  slice_tensor_283 = None
        slice_tensor_284 = torch.ops.aten.slice.Tensor(select_int_26, 1, 0, 255);  select_int_26 = None
        slice_tensor_285 = torch.ops.aten.slice.Tensor(slice_tensor_284, 2, -255, 9223372036854775807);  slice_tensor_284 = None
        slice_tensor_286 = torch.ops.aten.slice.Tensor(new_empty_default_15, 0, 0, 9223372036854775807)
        select_int_27 = torch.ops.aten.select.int(slice_tensor_286, 1, 0);  slice_tensor_286 = None
        slice_tensor_287 = torch.ops.aten.slice.Tensor(select_int_27, 1, 1, 256);  select_int_27 = None
        slice_tensor_288 = torch.ops.aten.slice.Tensor(slice_tensor_287, 2, 1, 256);  slice_tensor_287 = None
        copy__default_27 = torch.ops.aten.copy_.default(slice_tensor_288, slice_tensor_285);  slice_tensor_288 = slice_tensor_285 = None
        view_default_93 = torch.ops.aten.view.default(new_empty_default_15, [2, 12, 1024, 513]);  new_empty_default_15 = None
        transpose_int_50 = torch.ops.aten.transpose.int(view_default_93, 2, 1);  view_default_93 = None
        new_empty_default_16 = torch.ops.aten.new_empty.default(transpose_int_50, [256, 257], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        fill__scalar_9 = torch.ops.aten.fill_.Scalar(new_empty_default_16, 1.0);  new_empty_default_16 = None
        tril_default_6 = torch.ops.aten.tril.default(fill__scalar_9);  fill__scalar_9 = None
        flip_default_12 = torch.ops.aten.flip.default(tril_default_6, [0]);  tril_default_6 = None
        unsqueeze_default_44 = torch.ops.aten.unsqueeze.default(flip_default_12, 0);  flip_default_12 = None
        slice_tensor_289 = torch.ops.aten.slice.Tensor(unsqueeze_default_44, 1, 0, 9223372036854775807);  unsqueeze_default_44 = None
        unsqueeze_default_45 = torch.ops.aten.unsqueeze.default(slice_tensor_289, 2);  slice_tensor_289 = None
        slice_tensor_290 = torch.ops.aten.slice.Tensor(unsqueeze_default_45, 3, 0, 9223372036854775807);  unsqueeze_default_45 = None
        flip_default_13 = torch.ops.aten.flip.default(slice_tensor_290, [1, 3])
        slice_tensor_291 = torch.ops.aten.slice.Tensor(transpose_int_50, 0, 0, 9223372036854775807)
        slice_tensor_292 = torch.ops.aten.slice.Tensor(slice_tensor_291, 1, 0, 256);  slice_tensor_291 = None
        slice_tensor_293 = torch.ops.aten.slice.Tensor(slice_tensor_292, 2, 0, 9223372036854775807);  slice_tensor_292 = None
        slice_tensor_294 = torch.ops.aten.slice.Tensor(slice_tensor_293, 3, 0, 257);  slice_tensor_293 = None
        expand_sym_int_12 = torch.ops.aten.expand.SymInt(slice_tensor_290, [2, 256, 12, 257]);  slice_tensor_290 = None
        eq_scalar_12 = torch.ops.aten.eq.Scalar(expand_sym_int_12, 1);  expand_sym_int_12 = None
        masked_fill__scalar_12 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_294, eq_scalar_12, -inf);  slice_tensor_294 = None
        slice_tensor_295 = torch.ops.aten.slice.Tensor(transpose_int_50, 0, 0, 9223372036854775807)
        slice_tensor_296 = torch.ops.aten.slice.Tensor(slice_tensor_295, 1, -256, 9223372036854775807);  slice_tensor_295 = None
        slice_tensor_297 = torch.ops.aten.slice.Tensor(slice_tensor_296, 2, 0, 9223372036854775807);  slice_tensor_296 = None
        slice_tensor_298 = torch.ops.aten.slice.Tensor(slice_tensor_297, 3, -257, 9223372036854775807);  slice_tensor_297 = None
        expand_sym_int_13 = torch.ops.aten.expand.SymInt(flip_default_13, [2, 256, 12, 257]);  flip_default_13 = None
        eq_scalar_13 = torch.ops.aten.eq.Scalar(expand_sym_int_13, 1);  expand_sym_int_13 = None
        masked_fill__scalar_13 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_298, eq_scalar_13, -inf);  slice_tensor_298 = None
        ne_scalar_3 = torch.ops.aten.ne.Scalar(primals_194, 0)
        slice_tensor_299 = torch.ops.aten.slice.Tensor(ne_scalar_3, 0, 0, 9223372036854775807);  ne_scalar_3 = None
        slice_tensor_300 = torch.ops.aten.slice.Tensor(slice_tensor_299, 1, 0, 9223372036854775807);  slice_tensor_299 = None
        unsqueeze_default_46 = torch.ops.aten.unsqueeze.default(slice_tensor_300, 2);  slice_tensor_300 = None
        unsqueeze_default_47 = torch.ops.aten.unsqueeze.default(unsqueeze_default_46, 3);  unsqueeze_default_46 = None
        _to_copy_default_3 = torch.ops.aten._to_copy.default(unsqueeze_default_47, device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided)
        where_scalar_self_6 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_47, -10000.0, _to_copy_default_3);  unsqueeze_default_47 = _to_copy_default_3 = None
        new_empty_default_17 = torch.ops.aten.new_empty.default(where_scalar_self_6, [2, 1024, 1, 1], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        fill__scalar_10 = torch.ops.aten.fill_.Scalar(new_empty_default_17, 1.0);  new_empty_default_17 = None
        transpose_int_51 = torch.ops.aten.transpose.int(fill__scalar_10, 1, 2);  fill__scalar_10 = None
        view_default_94 = torch.ops.aten.view.default(transpose_int_51, [2, 1024, 1]);  transpose_int_51 = None
        transpose_int_52 = torch.ops.aten.transpose.int(where_scalar_self_6, 1, 2);  where_scalar_self_6 = None
        view_default_95 = torch.ops.aten.view.default(transpose_int_52, [2, 1024, 1]);  transpose_int_52 = None
        view_default_96 = torch.ops.aten.view.default(view_default_94, [2, 2, 512, 1]);  view_default_94 = None
        as_strided_default_17 = torch.ops.aten.as_strided.default(view_default_96, [2, 3, 512, 1], [1024, 256, 1, 1]);  view_default_96 = None
        view_default_97 = torch.ops.aten.view.default(view_default_95, [2, 2, 512, 1]);  view_default_95 = None
        as_strided_default_18 = torch.ops.aten.as_strided.default(view_default_97, [2, 3, 512, 1], [1024, 256, 1, 1]);  view_default_97 = None
        unsqueeze_default_48 = torch.ops.aten.unsqueeze.default(as_strided_default_17, -1);  as_strided_default_17 = None
        permute_default_41 = torch.ops.aten.permute.default(unsqueeze_default_48, [0, 1, 2, 4, 3]);  unsqueeze_default_48 = None
        unsqueeze_default_49 = torch.ops.aten.unsqueeze.default(as_strided_default_18, -1);  as_strided_default_18 = None
        permute_default_42 = torch.ops.aten.permute.default(unsqueeze_default_49, [0, 1, 4, 2, 3]);  unsqueeze_default_49 = None
        squeeze_dim_6 = torch.ops.aten.squeeze.dim(permute_default_41, 4);  permute_default_41 = None
        squeeze_dim_7 = torch.ops.aten.squeeze.dim(permute_default_42, 4);  permute_default_42 = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(squeeze_dim_6, squeeze_dim_7);  squeeze_dim_6 = squeeze_dim_7 = None
        constant_pad_nd_default_13 = torch.ops.aten.constant_pad_nd.default(mul_tensor_3, [0, 0, 0, 1], 0.0);  mul_tensor_3 = None
        view_default_98 = torch.ops.aten.view.default(constant_pad_nd_default_13, [2, 3, 512, 513]);  constant_pad_nd_default_13 = None
        new_empty_default_18 = torch.ops.aten.new_empty.default(view_default_98, [2, 4, 256, 513], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        slice_tensor_301 = torch.ops.aten.slice.Tensor(view_default_98, 0, 0, 9223372036854775807)
        slice_tensor_302 = torch.ops.aten.slice.Tensor(slice_tensor_301, 1, 0, 9223372036854775807);  slice_tensor_301 = None
        slice_tensor_303 = torch.ops.aten.slice.Tensor(slice_tensor_302, 2, 0, 256);  slice_tensor_302 = None
        slice_tensor_304 = torch.ops.aten.slice.Tensor(slice_tensor_303, 3, 0, 257);  slice_tensor_303 = None
        slice_tensor_305 = torch.ops.aten.slice.Tensor(new_empty_default_18, 0, 0, 9223372036854775807)
        slice_tensor_306 = torch.ops.aten.slice.Tensor(slice_tensor_305, 1, 0, -1);  slice_tensor_305 = None
        slice_tensor_307 = torch.ops.aten.slice.Tensor(slice_tensor_306, 2, 0, 9223372036854775807);  slice_tensor_306 = None
        slice_tensor_308 = torch.ops.aten.slice.Tensor(slice_tensor_307, 3, 256, 9223372036854775807);  slice_tensor_307 = None
        copy__default_28 = torch.ops.aten.copy_.default(slice_tensor_308, slice_tensor_304);  slice_tensor_308 = slice_tensor_304 = None
        slice_tensor_309 = torch.ops.aten.slice.Tensor(view_default_98, 0, 0, 9223372036854775807)
        select_int_28 = torch.ops.aten.select.int(slice_tensor_309, 1, -1);  slice_tensor_309 = None
        slice_tensor_310 = torch.ops.aten.slice.Tensor(select_int_28, 1, 256, 9223372036854775807);  select_int_28 = None
        slice_tensor_311 = torch.ops.aten.slice.Tensor(slice_tensor_310, 2, 0, 257);  slice_tensor_310 = None
        slice_tensor_312 = torch.ops.aten.slice.Tensor(new_empty_default_18, 0, 0, 9223372036854775807)
        select_int_29 = torch.ops.aten.select.int(slice_tensor_312, 1, -1);  slice_tensor_312 = None
        slice_tensor_313 = torch.ops.aten.slice.Tensor(select_int_29, 1, 0, 9223372036854775807);  select_int_29 = None
        slice_tensor_314 = torch.ops.aten.slice.Tensor(slice_tensor_313, 2, 256, 9223372036854775807);  slice_tensor_313 = None
        copy__default_29 = torch.ops.aten.copy_.default(slice_tensor_314, slice_tensor_311);  slice_tensor_314 = slice_tensor_311 = None
        slice_tensor_315 = torch.ops.aten.slice.Tensor(view_default_98, 0, 0, 9223372036854775807)
        slice_tensor_316 = torch.ops.aten.slice.Tensor(slice_tensor_315, 1, 0, 9223372036854775807);  slice_tensor_315 = None
        slice_tensor_317 = torch.ops.aten.slice.Tensor(slice_tensor_316, 2, -257, -1);  slice_tensor_316 = None
        slice_tensor_318 = torch.ops.aten.slice.Tensor(slice_tensor_317, 3, 257, 9223372036854775807);  slice_tensor_317 = None
        slice_tensor_319 = torch.ops.aten.slice.Tensor(new_empty_default_18, 0, 0, 9223372036854775807)
        slice_tensor_320 = torch.ops.aten.slice.Tensor(slice_tensor_319, 1, 1, 9223372036854775807);  slice_tensor_319 = None
        slice_tensor_321 = torch.ops.aten.slice.Tensor(slice_tensor_320, 2, 0, 9223372036854775807);  slice_tensor_320 = None
        slice_tensor_322 = torch.ops.aten.slice.Tensor(slice_tensor_321, 3, 0, 256);  slice_tensor_321 = None
        copy__default_30 = torch.ops.aten.copy_.default(slice_tensor_322, slice_tensor_318);  slice_tensor_322 = slice_tensor_318 = None
        slice_tensor_323 = torch.ops.aten.slice.Tensor(view_default_98, 0, 0, 9223372036854775807);  view_default_98 = None
        select_int_30 = torch.ops.aten.select.int(slice_tensor_323, 1, 0);  slice_tensor_323 = None
        slice_tensor_324 = torch.ops.aten.slice.Tensor(select_int_30, 1, 0, 255);  select_int_30 = None
        slice_tensor_325 = torch.ops.aten.slice.Tensor(slice_tensor_324, 2, -255, 9223372036854775807);  slice_tensor_324 = None
        slice_tensor_326 = torch.ops.aten.slice.Tensor(new_empty_default_18, 0, 0, 9223372036854775807)
        select_int_31 = torch.ops.aten.select.int(slice_tensor_326, 1, 0);  slice_tensor_326 = None
        slice_tensor_327 = torch.ops.aten.slice.Tensor(select_int_31, 1, 1, 256);  select_int_31 = None
        slice_tensor_328 = torch.ops.aten.slice.Tensor(slice_tensor_327, 2, 1, 256);  slice_tensor_327 = None
        copy__default_31 = torch.ops.aten.copy_.default(slice_tensor_328, slice_tensor_325);  slice_tensor_328 = slice_tensor_325 = None
        view_default_99 = torch.ops.aten.view.default(new_empty_default_18, [2, 1, 1024, 513]);  new_empty_default_18 = None
        transpose_int_53 = torch.ops.aten.transpose.int(view_default_99, 2, 1);  view_default_99 = None
        new_empty_default_19 = torch.ops.aten.new_empty.default(transpose_int_53, [256, 257], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        fill__scalar_11 = torch.ops.aten.fill_.Scalar(new_empty_default_19, 1.0);  new_empty_default_19 = None
        tril_default_7 = torch.ops.aten.tril.default(fill__scalar_11);  fill__scalar_11 = None
        flip_default_14 = torch.ops.aten.flip.default(tril_default_7, [0]);  tril_default_7 = None
        unsqueeze_default_50 = torch.ops.aten.unsqueeze.default(flip_default_14, 0);  flip_default_14 = None
        slice_tensor_329 = torch.ops.aten.slice.Tensor(unsqueeze_default_50, 1, 0, 9223372036854775807);  unsqueeze_default_50 = None
        unsqueeze_default_51 = torch.ops.aten.unsqueeze.default(slice_tensor_329, 2);  slice_tensor_329 = None
        slice_tensor_330 = torch.ops.aten.slice.Tensor(unsqueeze_default_51, 3, 0, 9223372036854775807);  unsqueeze_default_51 = None
        flip_default_15 = torch.ops.aten.flip.default(slice_tensor_330, [1, 3])
        slice_tensor_331 = torch.ops.aten.slice.Tensor(transpose_int_53, 0, 0, 9223372036854775807)
        slice_tensor_332 = torch.ops.aten.slice.Tensor(slice_tensor_331, 1, 0, 256);  slice_tensor_331 = None
        slice_tensor_333 = torch.ops.aten.slice.Tensor(slice_tensor_332, 2, 0, 9223372036854775807);  slice_tensor_332 = None
        slice_tensor_334 = torch.ops.aten.slice.Tensor(slice_tensor_333, 3, 0, 257);  slice_tensor_333 = None
        expand_sym_int_14 = torch.ops.aten.expand.SymInt(slice_tensor_330, [2, 256, 1, 257]);  slice_tensor_330 = None
        eq_scalar_14 = torch.ops.aten.eq.Scalar(expand_sym_int_14, 1);  expand_sym_int_14 = None
        masked_fill__scalar_14 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_334, eq_scalar_14, -inf);  slice_tensor_334 = eq_scalar_14 = None
        slice_tensor_335 = torch.ops.aten.slice.Tensor(transpose_int_53, 0, 0, 9223372036854775807)
        slice_tensor_336 = torch.ops.aten.slice.Tensor(slice_tensor_335, 1, -256, 9223372036854775807);  slice_tensor_335 = None
        slice_tensor_337 = torch.ops.aten.slice.Tensor(slice_tensor_336, 2, 0, 9223372036854775807);  slice_tensor_336 = None
        slice_tensor_338 = torch.ops.aten.slice.Tensor(slice_tensor_337, 3, -257, 9223372036854775807);  slice_tensor_337 = None
        expand_sym_int_15 = torch.ops.aten.expand.SymInt(flip_default_15, [2, 256, 1, 257]);  flip_default_15 = None
        eq_scalar_15 = torch.ops.aten.eq.Scalar(expand_sym_int_15, 1);  expand_sym_int_15 = None
        masked_fill__scalar_15 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_338, eq_scalar_15, -inf);  slice_tensor_338 = eq_scalar_15 = None
        add__tensor_3 = torch.ops.aten.add_.Tensor(transpose_int_50, transpose_int_53);  transpose_int_50 = transpose_int_53 = None
        _softmax_default_3 = torch.ops.aten._softmax.default(add__tensor_3, -1, False);  add__tensor_3 = None
        slice_tensor_339 = torch.ops.aten.slice.Tensor(primals_195, 0, 0, 9223372036854775807)
        slice_tensor_340 = torch.ops.aten.slice.Tensor(slice_tensor_339, 1, 0, 9223372036854775807);  slice_tensor_339 = None
        unsqueeze_default_52 = torch.ops.aten.unsqueeze.default(slice_tensor_340, 2);  slice_tensor_340 = None
        unsqueeze_default_53 = torch.ops.aten.unsqueeze.default(unsqueeze_default_52, 3);  unsqueeze_default_52 = None
        where_scalar_self_7 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_53, 0.0, _softmax_default_3)
        view_default_100 = torch.ops.aten.view.default(add_tensor_20, [1024, 2, 12, 64]);  add_tensor_20 = None
        transpose_int_54 = torch.ops.aten.transpose.int(view_default_100, 0, 1);  view_default_100 = None
        transpose_int_55 = torch.ops.aten.transpose.int(where_scalar_self_7, 1, 2);  where_scalar_self_7 = None
        clone_default_32 = torch.ops.aten.clone.default(transpose_int_55, memory_format = torch.contiguous_format);  transpose_int_55 = None
        _unsafe_view_default_47 = torch.ops.aten._unsafe_view.default(clone_default_32, [24, 4, 256, 513]);  clone_default_32 = None
        transpose_int_56 = torch.ops.aten.transpose.int(transpose_int_54, 1, 2);  transpose_int_54 = None
        view_default_101 = torch.ops.aten.view.default(transpose_int_56, [24, 1024, 64]);  transpose_int_56 = None
        constant_pad_nd_default_14 = torch.ops.aten.constant_pad_nd.default(view_default_101, [0, 0, 256, 256], -1.0);  view_default_101 = None
        as_strided_default_19 = torch.ops.aten.as_strided.default(constant_pad_nd_default_14, [24, 4, 768, 64], [98304, 16384, 64, 1]);  constant_pad_nd_default_14 = None
        constant_pad_nd_default_15 = torch.ops.aten.constant_pad_nd.default(_unsafe_view_default_47, [0, 257], 0.0);  _unsafe_view_default_47 = None
        view_default_102 = torch.ops.aten.view.default(constant_pad_nd_default_15, [24, 4, -1]);  constant_pad_nd_default_15 = None
        slice_tensor_341 = torch.ops.aten.slice.Tensor(view_default_102, 0, 0, 9223372036854775807);  view_default_102 = None
        slice_tensor_342 = torch.ops.aten.slice.Tensor(slice_tensor_341, 1, 0, 9223372036854775807);  slice_tensor_341 = None
        slice_tensor_343 = torch.ops.aten.slice.Tensor(slice_tensor_342, 2, 0, -256);  slice_tensor_342 = None
        view_default_103 = torch.ops.aten.view.default(slice_tensor_343, [24, 4, 256, 769]);  slice_tensor_343 = None
        slice_tensor_344 = torch.ops.aten.slice.Tensor(view_default_103, 0, 0, 9223372036854775807);  view_default_103 = None
        slice_tensor_345 = torch.ops.aten.slice.Tensor(slice_tensor_344, 1, 0, 9223372036854775807);  slice_tensor_344 = None
        slice_tensor_346 = torch.ops.aten.slice.Tensor(slice_tensor_345, 2, 0, 9223372036854775807);  slice_tensor_345 = None
        slice_tensor_347 = torch.ops.aten.slice.Tensor(slice_tensor_346, 3, 0, -1);  slice_tensor_346 = None
        unsqueeze_default_54 = torch.ops.aten.unsqueeze.default(slice_tensor_347, -1);  slice_tensor_347 = None
        permute_default_43 = torch.ops.aten.permute.default(unsqueeze_default_54, [0, 1, 2, 4, 3]);  unsqueeze_default_54 = None
        unsqueeze_default_55 = torch.ops.aten.unsqueeze.default(as_strided_default_19, -1);  as_strided_default_19 = None
        permute_default_44 = torch.ops.aten.permute.default(unsqueeze_default_55, [0, 1, 4, 3, 2]);  unsqueeze_default_55 = None
        permute_default_45 = torch.ops.aten.permute.default(permute_default_43, [0, 1, 2, 4, 3]);  permute_default_43 = None
        view_default_104 = torch.ops.aten.view.default(permute_default_45, [96, 256, 768]);  permute_default_45 = None
        permute_default_46 = torch.ops.aten.permute.default(permute_default_44, [0, 1, 4, 3, 2]);  permute_default_44 = None
        clone_default_33 = torch.ops.aten.clone.default(permute_default_46, memory_format = torch.contiguous_format);  permute_default_46 = None
        _unsafe_view_default_48 = torch.ops.aten._unsafe_view.default(clone_default_33, [96, 768, 64]);  clone_default_33 = None
        bmm_default_7 = torch.ops.aten.bmm.default(view_default_104, _unsafe_view_default_48)
        view_default_105 = torch.ops.aten.view.default(bmm_default_7, [24, 4, 256, 1, 64]);  bmm_default_7 = None
        permute_default_47 = torch.ops.aten.permute.default(view_default_105, [0, 1, 2, 4, 3]);  view_default_105 = None
        view_default_106 = torch.ops.aten.view.default(permute_default_47, [24, 4, 256, 64]);  permute_default_47 = None
        view_default_107 = torch.ops.aten.view.default(view_default_106, [2, 12, 1024, 64]);  view_default_106 = None
        transpose_int_57 = torch.ops.aten.transpose.int(view_default_107, 1, 2);  view_default_107 = None
        transpose_int_58 = torch.ops.aten.transpose.int(transpose_int_57, 0, 1);  transpose_int_57 = None
        clone_default_34 = torch.ops.aten.clone.default(transpose_int_58, memory_format = torch.contiguous_format);  transpose_int_58 = None
        _unsafe_view_default_49 = torch.ops.aten._unsafe_view.default(clone_default_34, [1024, 2, 768]);  clone_default_34 = None
        transpose_int_59 = torch.ops.aten.transpose.int(_unsafe_view_default_49, 0, 1);  _unsafe_view_default_49 = None
        t_default_21 = torch.ops.aten.t.default(primals_84);  primals_84 = None
        clone_default_35 = torch.ops.aten.clone.default(transpose_int_59, memory_format = torch.contiguous_format);  transpose_int_59 = None
        _unsafe_view_default_50 = torch.ops.aten._unsafe_view.default(clone_default_35, [2048, 768]);  clone_default_35 = None
        mm_default_15 = torch.ops.aten.mm.default(_unsafe_view_default_50, t_default_21)
        _unsafe_view_default_51 = torch.ops.aten._unsafe_view.default(mm_default_15, [2, 1024, 768]);  mm_default_15 = None
        add_tensor_21 = torch.ops.aten.add.Tensor(_unsafe_view_default_51, primals_83);  _unsafe_view_default_51 = primals_83 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(add_tensor_21, getitem_15);  add_tensor_21 = getitem_15 = None
        native_layer_norm_default_6 = torch.ops.aten.native_layer_norm.default(add_tensor_22, [768], primals_82, primals_81, 1e-05)
        getitem_18 = native_layer_norm_default_6[0]
        getitem_19 = native_layer_norm_default_6[1]
        getitem_20 = native_layer_norm_default_6[2];  native_layer_norm_default_6 = None
        view_default_108 = torch.ops.aten.view.default(getitem_18, [2048, 768])
        t_default_22 = torch.ops.aten.t.default(primals_92);  primals_92 = None
        addmm_default_6 = torch.ops.aten.addmm.default(primals_91, view_default_108, t_default_22);  primals_91 = None
        view_default_109 = torch.ops.aten.view.default(addmm_default_6, [2, 1024, 3072]);  addmm_default_6 = None
        gelu_default_3 = torch.ops.aten.gelu.default(view_default_109)
        view_default_110 = torch.ops.aten.view.default(gelu_default_3, [2048, 3072]);  gelu_default_3 = None
        t_default_23 = torch.ops.aten.t.default(primals_96);  primals_96 = None
        addmm_default_7 = torch.ops.aten.addmm.default(primals_95, view_default_110, t_default_23);  primals_95 = None
        view_default_111 = torch.ops.aten.view.default(addmm_default_7, [2, 1024, 768]);  addmm_default_7 = None
        add_tensor_23 = torch.ops.aten.add.Tensor(view_default_111, getitem_18);  view_default_111 = getitem_18 = None
        native_layer_norm_default_7 = torch.ops.aten.native_layer_norm.default(add_tensor_23, [768], primals_94, primals_93, 1e-05)
        getitem_21 = native_layer_norm_default_7[0]
        getitem_22 = native_layer_norm_default_7[1]
        getitem_23 = native_layer_norm_default_7[2];  native_layer_norm_default_7 = None
        transpose_int_60 = torch.ops.aten.transpose.int(getitem_21, 0, 1)
        t_default_24 = torch.ops.aten.t.default(primals_104);  primals_104 = None
        clone_default_36 = torch.ops.aten.clone.default(transpose_int_60, memory_format = torch.contiguous_format)
        _unsafe_view_default_52 = torch.ops.aten._unsafe_view.default(clone_default_36, [2048, 768]);  clone_default_36 = None
        mm_default_16 = torch.ops.aten.mm.default(_unsafe_view_default_52, t_default_24)
        _unsafe_view_default_53 = torch.ops.aten._unsafe_view.default(mm_default_16, [1024, 2, 768]);  mm_default_16 = None
        add_tensor_24 = torch.ops.aten.add.Tensor(_unsafe_view_default_53, primals_103);  _unsafe_view_default_53 = primals_103 = None
        t_default_25 = torch.ops.aten.t.default(primals_102);  primals_102 = None
        clone_default_37 = torch.ops.aten.clone.default(transpose_int_60, memory_format = torch.contiguous_format)
        _unsafe_view_default_54 = torch.ops.aten._unsafe_view.default(clone_default_37, [2048, 768]);  clone_default_37 = None
        mm_default_17 = torch.ops.aten.mm.default(_unsafe_view_default_54, t_default_25)
        _unsafe_view_default_55 = torch.ops.aten._unsafe_view.default(mm_default_17, [1024, 2, 768]);  mm_default_17 = None
        add_tensor_25 = torch.ops.aten.add.Tensor(_unsafe_view_default_55, primals_101);  _unsafe_view_default_55 = primals_101 = None
        t_default_26 = torch.ops.aten.t.default(primals_106);  primals_106 = None
        clone_default_38 = torch.ops.aten.clone.default(transpose_int_60, memory_format = torch.contiguous_format);  transpose_int_60 = None
        _unsafe_view_default_56 = torch.ops.aten._unsafe_view.default(clone_default_38, [2048, 768]);  clone_default_38 = None
        mm_default_18 = torch.ops.aten.mm.default(_unsafe_view_default_56, t_default_26)
        _unsafe_view_default_57 = torch.ops.aten._unsafe_view.default(mm_default_18, [1024, 2, 768]);  mm_default_18 = None
        add_tensor_26 = torch.ops.aten.add.Tensor(_unsafe_view_default_57, primals_105);  _unsafe_view_default_57 = primals_105 = None
        div__tensor_4 = torch.ops.aten.div_.Tensor(add_tensor_24, 8.0);  add_tensor_24 = None
        view_default_112 = torch.ops.aten.view.default(div__tensor_4, [1024, 2, 12, 64]);  div__tensor_4 = None
        transpose_int_61 = torch.ops.aten.transpose.int(view_default_112, 0, 1);  view_default_112 = None
        view_default_113 = torch.ops.aten.view.default(add_tensor_25, [1024, 2, 12, 64]);  add_tensor_25 = None
        transpose_int_62 = torch.ops.aten.transpose.int(view_default_113, 0, 1);  view_default_113 = None
        transpose_int_63 = torch.ops.aten.transpose.int(transpose_int_61, 1, 2);  transpose_int_61 = None
        view_default_114 = torch.ops.aten.view.default(transpose_int_63, [24, 1024, 64]);  transpose_int_63 = None
        transpose_int_64 = torch.ops.aten.transpose.int(transpose_int_62, 1, 2);  transpose_int_62 = None
        view_default_115 = torch.ops.aten.view.default(transpose_int_64, [24, 1024, 64]);  transpose_int_64 = None
        view_default_116 = torch.ops.aten.view.default(view_default_114, [24, 2, 512, 64]);  view_default_114 = None
        as_strided_default_20 = torch.ops.aten.as_strided.default(view_default_116, [24, 3, 512, 64], [64, 393216, 1536, 1]);  view_default_116 = None
        view_default_117 = torch.ops.aten.view.default(view_default_115, [24, 2, 512, 64]);  view_default_115 = None
        as_strided_default_21 = torch.ops.aten.as_strided.default(view_default_117, [24, 3, 512, 64], [64, 393216, 1536, 1]);  view_default_117 = None
        unsqueeze_default_56 = torch.ops.aten.unsqueeze.default(as_strided_default_20, -1);  as_strided_default_20 = None
        permute_default_48 = torch.ops.aten.permute.default(unsqueeze_default_56, [0, 1, 2, 4, 3]);  unsqueeze_default_56 = None
        unsqueeze_default_57 = torch.ops.aten.unsqueeze.default(as_strided_default_21, -1);  as_strided_default_21 = None
        permute_default_49 = torch.ops.aten.permute.default(unsqueeze_default_57, [0, 1, 4, 2, 3]);  unsqueeze_default_57 = None
        permute_default_50 = torch.ops.aten.permute.default(permute_default_48, [0, 1, 2, 4, 3]);  permute_default_48 = None
        clone_default_39 = torch.ops.aten.clone.default(permute_default_50, memory_format = torch.contiguous_format);  permute_default_50 = None
        _unsafe_view_default_58 = torch.ops.aten._unsafe_view.default(clone_default_39, [72, 512, 64]);  clone_default_39 = None
        permute_default_51 = torch.ops.aten.permute.default(permute_default_49, [0, 1, 4, 3, 2]);  permute_default_49 = None
        clone_default_40 = torch.ops.aten.clone.default(permute_default_51, memory_format = torch.contiguous_format);  permute_default_51 = None
        _unsafe_view_default_59 = torch.ops.aten._unsafe_view.default(clone_default_40, [72, 64, 512]);  clone_default_40 = None
        bmm_default_8 = torch.ops.aten.bmm.default(_unsafe_view_default_58, _unsafe_view_default_59)
        view_default_118 = torch.ops.aten.view.default(bmm_default_8, [24, 3, 512, 1, 512]);  bmm_default_8 = None
        permute_default_52 = torch.ops.aten.permute.default(view_default_118, [0, 1, 2, 4, 3]);  view_default_118 = None
        view_default_119 = torch.ops.aten.view.default(permute_default_52, [24, 3, 512, 512]);  permute_default_52 = None
        constant_pad_nd_default_16 = torch.ops.aten.constant_pad_nd.default(view_default_119, [0, 0, 0, 1], 0.0);  view_default_119 = None
        view_default_120 = torch.ops.aten.view.default(constant_pad_nd_default_16, [24, 3, 512, 513]);  constant_pad_nd_default_16 = None
        new_empty_default_20 = torch.ops.aten.new_empty.default(view_default_120, [24, 4, 256, 513], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        slice_tensor_348 = torch.ops.aten.slice.Tensor(view_default_120, 0, 0, 9223372036854775807)
        slice_tensor_349 = torch.ops.aten.slice.Tensor(slice_tensor_348, 1, 0, 9223372036854775807);  slice_tensor_348 = None
        slice_tensor_350 = torch.ops.aten.slice.Tensor(slice_tensor_349, 2, 0, 256);  slice_tensor_349 = None
        slice_tensor_351 = torch.ops.aten.slice.Tensor(slice_tensor_350, 3, 0, 257);  slice_tensor_350 = None
        slice_tensor_352 = torch.ops.aten.slice.Tensor(new_empty_default_20, 0, 0, 9223372036854775807)
        slice_tensor_353 = torch.ops.aten.slice.Tensor(slice_tensor_352, 1, 0, -1);  slice_tensor_352 = None
        slice_tensor_354 = torch.ops.aten.slice.Tensor(slice_tensor_353, 2, 0, 9223372036854775807);  slice_tensor_353 = None
        slice_tensor_355 = torch.ops.aten.slice.Tensor(slice_tensor_354, 3, 256, 9223372036854775807);  slice_tensor_354 = None
        copy__default_32 = torch.ops.aten.copy_.default(slice_tensor_355, slice_tensor_351);  slice_tensor_355 = slice_tensor_351 = None
        slice_tensor_356 = torch.ops.aten.slice.Tensor(view_default_120, 0, 0, 9223372036854775807)
        select_int_32 = torch.ops.aten.select.int(slice_tensor_356, 1, -1);  slice_tensor_356 = None
        slice_tensor_357 = torch.ops.aten.slice.Tensor(select_int_32, 1, 256, 9223372036854775807);  select_int_32 = None
        slice_tensor_358 = torch.ops.aten.slice.Tensor(slice_tensor_357, 2, 0, 257);  slice_tensor_357 = None
        slice_tensor_359 = torch.ops.aten.slice.Tensor(new_empty_default_20, 0, 0, 9223372036854775807)
        select_int_33 = torch.ops.aten.select.int(slice_tensor_359, 1, -1);  slice_tensor_359 = None
        slice_tensor_360 = torch.ops.aten.slice.Tensor(select_int_33, 1, 0, 9223372036854775807);  select_int_33 = None
        slice_tensor_361 = torch.ops.aten.slice.Tensor(slice_tensor_360, 2, 256, 9223372036854775807);  slice_tensor_360 = None
        copy__default_33 = torch.ops.aten.copy_.default(slice_tensor_361, slice_tensor_358);  slice_tensor_361 = slice_tensor_358 = None
        slice_tensor_362 = torch.ops.aten.slice.Tensor(view_default_120, 0, 0, 9223372036854775807)
        slice_tensor_363 = torch.ops.aten.slice.Tensor(slice_tensor_362, 1, 0, 9223372036854775807);  slice_tensor_362 = None
        slice_tensor_364 = torch.ops.aten.slice.Tensor(slice_tensor_363, 2, -257, -1);  slice_tensor_363 = None
        slice_tensor_365 = torch.ops.aten.slice.Tensor(slice_tensor_364, 3, 257, 9223372036854775807);  slice_tensor_364 = None
        slice_tensor_366 = torch.ops.aten.slice.Tensor(new_empty_default_20, 0, 0, 9223372036854775807)
        slice_tensor_367 = torch.ops.aten.slice.Tensor(slice_tensor_366, 1, 1, 9223372036854775807);  slice_tensor_366 = None
        slice_tensor_368 = torch.ops.aten.slice.Tensor(slice_tensor_367, 2, 0, 9223372036854775807);  slice_tensor_367 = None
        slice_tensor_369 = torch.ops.aten.slice.Tensor(slice_tensor_368, 3, 0, 256);  slice_tensor_368 = None
        copy__default_34 = torch.ops.aten.copy_.default(slice_tensor_369, slice_tensor_365);  slice_tensor_369 = slice_tensor_365 = None
        slice_tensor_370 = torch.ops.aten.slice.Tensor(view_default_120, 0, 0, 9223372036854775807);  view_default_120 = None
        select_int_34 = torch.ops.aten.select.int(slice_tensor_370, 1, 0);  slice_tensor_370 = None
        slice_tensor_371 = torch.ops.aten.slice.Tensor(select_int_34, 1, 0, 255);  select_int_34 = None
        slice_tensor_372 = torch.ops.aten.slice.Tensor(slice_tensor_371, 2, -255, 9223372036854775807);  slice_tensor_371 = None
        slice_tensor_373 = torch.ops.aten.slice.Tensor(new_empty_default_20, 0, 0, 9223372036854775807)
        select_int_35 = torch.ops.aten.select.int(slice_tensor_373, 1, 0);  slice_tensor_373 = None
        slice_tensor_374 = torch.ops.aten.slice.Tensor(select_int_35, 1, 1, 256);  select_int_35 = None
        slice_tensor_375 = torch.ops.aten.slice.Tensor(slice_tensor_374, 2, 1, 256);  slice_tensor_374 = None
        copy__default_35 = torch.ops.aten.copy_.default(slice_tensor_375, slice_tensor_372);  slice_tensor_375 = slice_tensor_372 = None
        view_default_121 = torch.ops.aten.view.default(new_empty_default_20, [2, 12, 1024, 513]);  new_empty_default_20 = None
        transpose_int_65 = torch.ops.aten.transpose.int(view_default_121, 2, 1);  view_default_121 = None
        new_empty_default_21 = torch.ops.aten.new_empty.default(transpose_int_65, [256, 257], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        fill__scalar_12 = torch.ops.aten.fill_.Scalar(new_empty_default_21, 1.0);  new_empty_default_21 = None
        tril_default_8 = torch.ops.aten.tril.default(fill__scalar_12);  fill__scalar_12 = None
        flip_default_16 = torch.ops.aten.flip.default(tril_default_8, [0]);  tril_default_8 = None
        unsqueeze_default_58 = torch.ops.aten.unsqueeze.default(flip_default_16, 0);  flip_default_16 = None
        slice_tensor_376 = torch.ops.aten.slice.Tensor(unsqueeze_default_58, 1, 0, 9223372036854775807);  unsqueeze_default_58 = None
        unsqueeze_default_59 = torch.ops.aten.unsqueeze.default(slice_tensor_376, 2);  slice_tensor_376 = None
        slice_tensor_377 = torch.ops.aten.slice.Tensor(unsqueeze_default_59, 3, 0, 9223372036854775807);  unsqueeze_default_59 = None
        flip_default_17 = torch.ops.aten.flip.default(slice_tensor_377, [1, 3])
        slice_tensor_378 = torch.ops.aten.slice.Tensor(transpose_int_65, 0, 0, 9223372036854775807)
        slice_tensor_379 = torch.ops.aten.slice.Tensor(slice_tensor_378, 1, 0, 256);  slice_tensor_378 = None
        slice_tensor_380 = torch.ops.aten.slice.Tensor(slice_tensor_379, 2, 0, 9223372036854775807);  slice_tensor_379 = None
        slice_tensor_381 = torch.ops.aten.slice.Tensor(slice_tensor_380, 3, 0, 257);  slice_tensor_380 = None
        expand_sym_int_16 = torch.ops.aten.expand.SymInt(slice_tensor_377, [2, 256, 12, 257]);  slice_tensor_377 = None
        eq_scalar_16 = torch.ops.aten.eq.Scalar(expand_sym_int_16, 1);  expand_sym_int_16 = None
        masked_fill__scalar_16 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_381, eq_scalar_16, -inf);  slice_tensor_381 = None
        slice_tensor_382 = torch.ops.aten.slice.Tensor(transpose_int_65, 0, 0, 9223372036854775807)
        slice_tensor_383 = torch.ops.aten.slice.Tensor(slice_tensor_382, 1, -256, 9223372036854775807);  slice_tensor_382 = None
        slice_tensor_384 = torch.ops.aten.slice.Tensor(slice_tensor_383, 2, 0, 9223372036854775807);  slice_tensor_383 = None
        slice_tensor_385 = torch.ops.aten.slice.Tensor(slice_tensor_384, 3, -257, 9223372036854775807);  slice_tensor_384 = None
        expand_sym_int_17 = torch.ops.aten.expand.SymInt(flip_default_17, [2, 256, 12, 257]);  flip_default_17 = None
        eq_scalar_17 = torch.ops.aten.eq.Scalar(expand_sym_int_17, 1);  expand_sym_int_17 = None
        masked_fill__scalar_17 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_385, eq_scalar_17, -inf);  slice_tensor_385 = None
        ne_scalar_4 = torch.ops.aten.ne.Scalar(primals_194, 0)
        slice_tensor_386 = torch.ops.aten.slice.Tensor(ne_scalar_4, 0, 0, 9223372036854775807);  ne_scalar_4 = None
        slice_tensor_387 = torch.ops.aten.slice.Tensor(slice_tensor_386, 1, 0, 9223372036854775807);  slice_tensor_386 = None
        unsqueeze_default_60 = torch.ops.aten.unsqueeze.default(slice_tensor_387, 2);  slice_tensor_387 = None
        unsqueeze_default_61 = torch.ops.aten.unsqueeze.default(unsqueeze_default_60, 3);  unsqueeze_default_60 = None
        _to_copy_default_4 = torch.ops.aten._to_copy.default(unsqueeze_default_61, device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided)
        where_scalar_self_8 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_61, -10000.0, _to_copy_default_4);  unsqueeze_default_61 = _to_copy_default_4 = None
        new_empty_default_22 = torch.ops.aten.new_empty.default(where_scalar_self_8, [2, 1024, 1, 1], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        fill__scalar_13 = torch.ops.aten.fill_.Scalar(new_empty_default_22, 1.0);  new_empty_default_22 = None
        transpose_int_66 = torch.ops.aten.transpose.int(fill__scalar_13, 1, 2);  fill__scalar_13 = None
        view_default_122 = torch.ops.aten.view.default(transpose_int_66, [2, 1024, 1]);  transpose_int_66 = None
        transpose_int_67 = torch.ops.aten.transpose.int(where_scalar_self_8, 1, 2);  where_scalar_self_8 = None
        view_default_123 = torch.ops.aten.view.default(transpose_int_67, [2, 1024, 1]);  transpose_int_67 = None
        view_default_124 = torch.ops.aten.view.default(view_default_122, [2, 2, 512, 1]);  view_default_122 = None
        as_strided_default_22 = torch.ops.aten.as_strided.default(view_default_124, [2, 3, 512, 1], [1024, 256, 1, 1]);  view_default_124 = None
        view_default_125 = torch.ops.aten.view.default(view_default_123, [2, 2, 512, 1]);  view_default_123 = None
        as_strided_default_23 = torch.ops.aten.as_strided.default(view_default_125, [2, 3, 512, 1], [1024, 256, 1, 1]);  view_default_125 = None
        unsqueeze_default_62 = torch.ops.aten.unsqueeze.default(as_strided_default_22, -1);  as_strided_default_22 = None
        permute_default_53 = torch.ops.aten.permute.default(unsqueeze_default_62, [0, 1, 2, 4, 3]);  unsqueeze_default_62 = None
        unsqueeze_default_63 = torch.ops.aten.unsqueeze.default(as_strided_default_23, -1);  as_strided_default_23 = None
        permute_default_54 = torch.ops.aten.permute.default(unsqueeze_default_63, [0, 1, 4, 2, 3]);  unsqueeze_default_63 = None
        squeeze_dim_8 = torch.ops.aten.squeeze.dim(permute_default_53, 4);  permute_default_53 = None
        squeeze_dim_9 = torch.ops.aten.squeeze.dim(permute_default_54, 4);  permute_default_54 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(squeeze_dim_8, squeeze_dim_9);  squeeze_dim_8 = squeeze_dim_9 = None
        constant_pad_nd_default_17 = torch.ops.aten.constant_pad_nd.default(mul_tensor_4, [0, 0, 0, 1], 0.0);  mul_tensor_4 = None
        view_default_126 = torch.ops.aten.view.default(constant_pad_nd_default_17, [2, 3, 512, 513]);  constant_pad_nd_default_17 = None
        new_empty_default_23 = torch.ops.aten.new_empty.default(view_default_126, [2, 4, 256, 513], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        slice_tensor_388 = torch.ops.aten.slice.Tensor(view_default_126, 0, 0, 9223372036854775807)
        slice_tensor_389 = torch.ops.aten.slice.Tensor(slice_tensor_388, 1, 0, 9223372036854775807);  slice_tensor_388 = None
        slice_tensor_390 = torch.ops.aten.slice.Tensor(slice_tensor_389, 2, 0, 256);  slice_tensor_389 = None
        slice_tensor_391 = torch.ops.aten.slice.Tensor(slice_tensor_390, 3, 0, 257);  slice_tensor_390 = None
        slice_tensor_392 = torch.ops.aten.slice.Tensor(new_empty_default_23, 0, 0, 9223372036854775807)
        slice_tensor_393 = torch.ops.aten.slice.Tensor(slice_tensor_392, 1, 0, -1);  slice_tensor_392 = None
        slice_tensor_394 = torch.ops.aten.slice.Tensor(slice_tensor_393, 2, 0, 9223372036854775807);  slice_tensor_393 = None
        slice_tensor_395 = torch.ops.aten.slice.Tensor(slice_tensor_394, 3, 256, 9223372036854775807);  slice_tensor_394 = None
        copy__default_36 = torch.ops.aten.copy_.default(slice_tensor_395, slice_tensor_391);  slice_tensor_395 = slice_tensor_391 = None
        slice_tensor_396 = torch.ops.aten.slice.Tensor(view_default_126, 0, 0, 9223372036854775807)
        select_int_36 = torch.ops.aten.select.int(slice_tensor_396, 1, -1);  slice_tensor_396 = None
        slice_tensor_397 = torch.ops.aten.slice.Tensor(select_int_36, 1, 256, 9223372036854775807);  select_int_36 = None
        slice_tensor_398 = torch.ops.aten.slice.Tensor(slice_tensor_397, 2, 0, 257);  slice_tensor_397 = None
        slice_tensor_399 = torch.ops.aten.slice.Tensor(new_empty_default_23, 0, 0, 9223372036854775807)
        select_int_37 = torch.ops.aten.select.int(slice_tensor_399, 1, -1);  slice_tensor_399 = None
        slice_tensor_400 = torch.ops.aten.slice.Tensor(select_int_37, 1, 0, 9223372036854775807);  select_int_37 = None
        slice_tensor_401 = torch.ops.aten.slice.Tensor(slice_tensor_400, 2, 256, 9223372036854775807);  slice_tensor_400 = None
        copy__default_37 = torch.ops.aten.copy_.default(slice_tensor_401, slice_tensor_398);  slice_tensor_401 = slice_tensor_398 = None
        slice_tensor_402 = torch.ops.aten.slice.Tensor(view_default_126, 0, 0, 9223372036854775807)
        slice_tensor_403 = torch.ops.aten.slice.Tensor(slice_tensor_402, 1, 0, 9223372036854775807);  slice_tensor_402 = None
        slice_tensor_404 = torch.ops.aten.slice.Tensor(slice_tensor_403, 2, -257, -1);  slice_tensor_403 = None
        slice_tensor_405 = torch.ops.aten.slice.Tensor(slice_tensor_404, 3, 257, 9223372036854775807);  slice_tensor_404 = None
        slice_tensor_406 = torch.ops.aten.slice.Tensor(new_empty_default_23, 0, 0, 9223372036854775807)
        slice_tensor_407 = torch.ops.aten.slice.Tensor(slice_tensor_406, 1, 1, 9223372036854775807);  slice_tensor_406 = None
        slice_tensor_408 = torch.ops.aten.slice.Tensor(slice_tensor_407, 2, 0, 9223372036854775807);  slice_tensor_407 = None
        slice_tensor_409 = torch.ops.aten.slice.Tensor(slice_tensor_408, 3, 0, 256);  slice_tensor_408 = None
        copy__default_38 = torch.ops.aten.copy_.default(slice_tensor_409, slice_tensor_405);  slice_tensor_409 = slice_tensor_405 = None
        slice_tensor_410 = torch.ops.aten.slice.Tensor(view_default_126, 0, 0, 9223372036854775807);  view_default_126 = None
        select_int_38 = torch.ops.aten.select.int(slice_tensor_410, 1, 0);  slice_tensor_410 = None
        slice_tensor_411 = torch.ops.aten.slice.Tensor(select_int_38, 1, 0, 255);  select_int_38 = None
        slice_tensor_412 = torch.ops.aten.slice.Tensor(slice_tensor_411, 2, -255, 9223372036854775807);  slice_tensor_411 = None
        slice_tensor_413 = torch.ops.aten.slice.Tensor(new_empty_default_23, 0, 0, 9223372036854775807)
        select_int_39 = torch.ops.aten.select.int(slice_tensor_413, 1, 0);  slice_tensor_413 = None
        slice_tensor_414 = torch.ops.aten.slice.Tensor(select_int_39, 1, 1, 256);  select_int_39 = None
        slice_tensor_415 = torch.ops.aten.slice.Tensor(slice_tensor_414, 2, 1, 256);  slice_tensor_414 = None
        copy__default_39 = torch.ops.aten.copy_.default(slice_tensor_415, slice_tensor_412);  slice_tensor_415 = slice_tensor_412 = None
        view_default_127 = torch.ops.aten.view.default(new_empty_default_23, [2, 1, 1024, 513]);  new_empty_default_23 = None
        transpose_int_68 = torch.ops.aten.transpose.int(view_default_127, 2, 1);  view_default_127 = None
        new_empty_default_24 = torch.ops.aten.new_empty.default(transpose_int_68, [256, 257], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        fill__scalar_14 = torch.ops.aten.fill_.Scalar(new_empty_default_24, 1.0);  new_empty_default_24 = None
        tril_default_9 = torch.ops.aten.tril.default(fill__scalar_14);  fill__scalar_14 = None
        flip_default_18 = torch.ops.aten.flip.default(tril_default_9, [0]);  tril_default_9 = None
        unsqueeze_default_64 = torch.ops.aten.unsqueeze.default(flip_default_18, 0);  flip_default_18 = None
        slice_tensor_416 = torch.ops.aten.slice.Tensor(unsqueeze_default_64, 1, 0, 9223372036854775807);  unsqueeze_default_64 = None
        unsqueeze_default_65 = torch.ops.aten.unsqueeze.default(slice_tensor_416, 2);  slice_tensor_416 = None
        slice_tensor_417 = torch.ops.aten.slice.Tensor(unsqueeze_default_65, 3, 0, 9223372036854775807);  unsqueeze_default_65 = None
        flip_default_19 = torch.ops.aten.flip.default(slice_tensor_417, [1, 3])
        slice_tensor_418 = torch.ops.aten.slice.Tensor(transpose_int_68, 0, 0, 9223372036854775807)
        slice_tensor_419 = torch.ops.aten.slice.Tensor(slice_tensor_418, 1, 0, 256);  slice_tensor_418 = None
        slice_tensor_420 = torch.ops.aten.slice.Tensor(slice_tensor_419, 2, 0, 9223372036854775807);  slice_tensor_419 = None
        slice_tensor_421 = torch.ops.aten.slice.Tensor(slice_tensor_420, 3, 0, 257);  slice_tensor_420 = None
        expand_sym_int_18 = torch.ops.aten.expand.SymInt(slice_tensor_417, [2, 256, 1, 257]);  slice_tensor_417 = None
        eq_scalar_18 = torch.ops.aten.eq.Scalar(expand_sym_int_18, 1);  expand_sym_int_18 = None
        masked_fill__scalar_18 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_421, eq_scalar_18, -inf);  slice_tensor_421 = eq_scalar_18 = None
        slice_tensor_422 = torch.ops.aten.slice.Tensor(transpose_int_68, 0, 0, 9223372036854775807)
        slice_tensor_423 = torch.ops.aten.slice.Tensor(slice_tensor_422, 1, -256, 9223372036854775807);  slice_tensor_422 = None
        slice_tensor_424 = torch.ops.aten.slice.Tensor(slice_tensor_423, 2, 0, 9223372036854775807);  slice_tensor_423 = None
        slice_tensor_425 = torch.ops.aten.slice.Tensor(slice_tensor_424, 3, -257, 9223372036854775807);  slice_tensor_424 = None
        expand_sym_int_19 = torch.ops.aten.expand.SymInt(flip_default_19, [2, 256, 1, 257]);  flip_default_19 = None
        eq_scalar_19 = torch.ops.aten.eq.Scalar(expand_sym_int_19, 1);  expand_sym_int_19 = None
        masked_fill__scalar_19 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_425, eq_scalar_19, -inf);  slice_tensor_425 = eq_scalar_19 = None
        add__tensor_4 = torch.ops.aten.add_.Tensor(transpose_int_65, transpose_int_68);  transpose_int_65 = transpose_int_68 = None
        _softmax_default_4 = torch.ops.aten._softmax.default(add__tensor_4, -1, False);  add__tensor_4 = None
        slice_tensor_426 = torch.ops.aten.slice.Tensor(primals_195, 0, 0, 9223372036854775807)
        slice_tensor_427 = torch.ops.aten.slice.Tensor(slice_tensor_426, 1, 0, 9223372036854775807);  slice_tensor_426 = None
        unsqueeze_default_66 = torch.ops.aten.unsqueeze.default(slice_tensor_427, 2);  slice_tensor_427 = None
        unsqueeze_default_67 = torch.ops.aten.unsqueeze.default(unsqueeze_default_66, 3);  unsqueeze_default_66 = None
        where_scalar_self_9 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_67, 0.0, _softmax_default_4)
        view_default_128 = torch.ops.aten.view.default(add_tensor_26, [1024, 2, 12, 64]);  add_tensor_26 = None
        transpose_int_69 = torch.ops.aten.transpose.int(view_default_128, 0, 1);  view_default_128 = None
        transpose_int_70 = torch.ops.aten.transpose.int(where_scalar_self_9, 1, 2);  where_scalar_self_9 = None
        clone_default_41 = torch.ops.aten.clone.default(transpose_int_70, memory_format = torch.contiguous_format);  transpose_int_70 = None
        _unsafe_view_default_60 = torch.ops.aten._unsafe_view.default(clone_default_41, [24, 4, 256, 513]);  clone_default_41 = None
        transpose_int_71 = torch.ops.aten.transpose.int(transpose_int_69, 1, 2);  transpose_int_69 = None
        view_default_129 = torch.ops.aten.view.default(transpose_int_71, [24, 1024, 64]);  transpose_int_71 = None
        constant_pad_nd_default_18 = torch.ops.aten.constant_pad_nd.default(view_default_129, [0, 0, 256, 256], -1.0);  view_default_129 = None
        as_strided_default_24 = torch.ops.aten.as_strided.default(constant_pad_nd_default_18, [24, 4, 768, 64], [98304, 16384, 64, 1]);  constant_pad_nd_default_18 = None
        constant_pad_nd_default_19 = torch.ops.aten.constant_pad_nd.default(_unsafe_view_default_60, [0, 257], 0.0);  _unsafe_view_default_60 = None
        view_default_130 = torch.ops.aten.view.default(constant_pad_nd_default_19, [24, 4, -1]);  constant_pad_nd_default_19 = None
        slice_tensor_428 = torch.ops.aten.slice.Tensor(view_default_130, 0, 0, 9223372036854775807);  view_default_130 = None
        slice_tensor_429 = torch.ops.aten.slice.Tensor(slice_tensor_428, 1, 0, 9223372036854775807);  slice_tensor_428 = None
        slice_tensor_430 = torch.ops.aten.slice.Tensor(slice_tensor_429, 2, 0, -256);  slice_tensor_429 = None
        view_default_131 = torch.ops.aten.view.default(slice_tensor_430, [24, 4, 256, 769]);  slice_tensor_430 = None
        slice_tensor_431 = torch.ops.aten.slice.Tensor(view_default_131, 0, 0, 9223372036854775807);  view_default_131 = None
        slice_tensor_432 = torch.ops.aten.slice.Tensor(slice_tensor_431, 1, 0, 9223372036854775807);  slice_tensor_431 = None
        slice_tensor_433 = torch.ops.aten.slice.Tensor(slice_tensor_432, 2, 0, 9223372036854775807);  slice_tensor_432 = None
        slice_tensor_434 = torch.ops.aten.slice.Tensor(slice_tensor_433, 3, 0, -1);  slice_tensor_433 = None
        unsqueeze_default_68 = torch.ops.aten.unsqueeze.default(slice_tensor_434, -1);  slice_tensor_434 = None
        permute_default_55 = torch.ops.aten.permute.default(unsqueeze_default_68, [0, 1, 2, 4, 3]);  unsqueeze_default_68 = None
        unsqueeze_default_69 = torch.ops.aten.unsqueeze.default(as_strided_default_24, -1);  as_strided_default_24 = None
        permute_default_56 = torch.ops.aten.permute.default(unsqueeze_default_69, [0, 1, 4, 3, 2]);  unsqueeze_default_69 = None
        permute_default_57 = torch.ops.aten.permute.default(permute_default_55, [0, 1, 2, 4, 3]);  permute_default_55 = None
        view_default_132 = torch.ops.aten.view.default(permute_default_57, [96, 256, 768]);  permute_default_57 = None
        permute_default_58 = torch.ops.aten.permute.default(permute_default_56, [0, 1, 4, 3, 2]);  permute_default_56 = None
        clone_default_42 = torch.ops.aten.clone.default(permute_default_58, memory_format = torch.contiguous_format);  permute_default_58 = None
        _unsafe_view_default_61 = torch.ops.aten._unsafe_view.default(clone_default_42, [96, 768, 64]);  clone_default_42 = None
        bmm_default_9 = torch.ops.aten.bmm.default(view_default_132, _unsafe_view_default_61)
        view_default_133 = torch.ops.aten.view.default(bmm_default_9, [24, 4, 256, 1, 64]);  bmm_default_9 = None
        permute_default_59 = torch.ops.aten.permute.default(view_default_133, [0, 1, 2, 4, 3]);  view_default_133 = None
        view_default_134 = torch.ops.aten.view.default(permute_default_59, [24, 4, 256, 64]);  permute_default_59 = None
        view_default_135 = torch.ops.aten.view.default(view_default_134, [2, 12, 1024, 64]);  view_default_134 = None
        transpose_int_72 = torch.ops.aten.transpose.int(view_default_135, 1, 2);  view_default_135 = None
        transpose_int_73 = torch.ops.aten.transpose.int(transpose_int_72, 0, 1);  transpose_int_72 = None
        clone_default_43 = torch.ops.aten.clone.default(transpose_int_73, memory_format = torch.contiguous_format);  transpose_int_73 = None
        _unsafe_view_default_62 = torch.ops.aten._unsafe_view.default(clone_default_43, [1024, 2, 768]);  clone_default_43 = None
        transpose_int_74 = torch.ops.aten.transpose.int(_unsafe_view_default_62, 0, 1);  _unsafe_view_default_62 = None
        t_default_27 = torch.ops.aten.t.default(primals_100);  primals_100 = None
        clone_default_44 = torch.ops.aten.clone.default(transpose_int_74, memory_format = torch.contiguous_format);  transpose_int_74 = None
        _unsafe_view_default_63 = torch.ops.aten._unsafe_view.default(clone_default_44, [2048, 768]);  clone_default_44 = None
        mm_default_19 = torch.ops.aten.mm.default(_unsafe_view_default_63, t_default_27)
        _unsafe_view_default_64 = torch.ops.aten._unsafe_view.default(mm_default_19, [2, 1024, 768]);  mm_default_19 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(_unsafe_view_default_64, primals_99);  _unsafe_view_default_64 = primals_99 = None
        add_tensor_28 = torch.ops.aten.add.Tensor(add_tensor_27, getitem_21);  add_tensor_27 = getitem_21 = None
        native_layer_norm_default_8 = torch.ops.aten.native_layer_norm.default(add_tensor_28, [768], primals_98, primals_97, 1e-05)
        getitem_24 = native_layer_norm_default_8[0]
        getitem_25 = native_layer_norm_default_8[1]
        getitem_26 = native_layer_norm_default_8[2];  native_layer_norm_default_8 = None
        view_default_136 = torch.ops.aten.view.default(getitem_24, [2048, 768])
        t_default_28 = torch.ops.aten.t.default(primals_108);  primals_108 = None
        addmm_default_8 = torch.ops.aten.addmm.default(primals_107, view_default_136, t_default_28);  primals_107 = None
        view_default_137 = torch.ops.aten.view.default(addmm_default_8, [2, 1024, 3072]);  addmm_default_8 = None
        gelu_default_4 = torch.ops.aten.gelu.default(view_default_137)
        view_default_138 = torch.ops.aten.view.default(gelu_default_4, [2048, 3072]);  gelu_default_4 = None
        t_default_29 = torch.ops.aten.t.default(primals_112);  primals_112 = None
        addmm_default_9 = torch.ops.aten.addmm.default(primals_111, view_default_138, t_default_29);  primals_111 = None
        view_default_139 = torch.ops.aten.view.default(addmm_default_9, [2, 1024, 768]);  addmm_default_9 = None
        add_tensor_29 = torch.ops.aten.add.Tensor(view_default_139, getitem_24);  view_default_139 = getitem_24 = None
        native_layer_norm_default_9 = torch.ops.aten.native_layer_norm.default(add_tensor_29, [768], primals_110, primals_109, 1e-05)
        getitem_27 = native_layer_norm_default_9[0]
        getitem_28 = native_layer_norm_default_9[1]
        getitem_29 = native_layer_norm_default_9[2];  native_layer_norm_default_9 = None
        transpose_int_75 = torch.ops.aten.transpose.int(getitem_27, 0, 1)
        t_default_30 = torch.ops.aten.t.default(primals_120);  primals_120 = None
        clone_default_45 = torch.ops.aten.clone.default(transpose_int_75, memory_format = torch.contiguous_format)
        _unsafe_view_default_65 = torch.ops.aten._unsafe_view.default(clone_default_45, [2048, 768]);  clone_default_45 = None
        mm_default_20 = torch.ops.aten.mm.default(_unsafe_view_default_65, t_default_30)
        _unsafe_view_default_66 = torch.ops.aten._unsafe_view.default(mm_default_20, [1024, 2, 768]);  mm_default_20 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(_unsafe_view_default_66, primals_119);  _unsafe_view_default_66 = primals_119 = None
        t_default_31 = torch.ops.aten.t.default(primals_118);  primals_118 = None
        clone_default_46 = torch.ops.aten.clone.default(transpose_int_75, memory_format = torch.contiguous_format)
        _unsafe_view_default_67 = torch.ops.aten._unsafe_view.default(clone_default_46, [2048, 768]);  clone_default_46 = None
        mm_default_21 = torch.ops.aten.mm.default(_unsafe_view_default_67, t_default_31)
        _unsafe_view_default_68 = torch.ops.aten._unsafe_view.default(mm_default_21, [1024, 2, 768]);  mm_default_21 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(_unsafe_view_default_68, primals_117);  _unsafe_view_default_68 = primals_117 = None
        t_default_32 = torch.ops.aten.t.default(primals_122);  primals_122 = None
        clone_default_47 = torch.ops.aten.clone.default(transpose_int_75, memory_format = torch.contiguous_format);  transpose_int_75 = None
        _unsafe_view_default_69 = torch.ops.aten._unsafe_view.default(clone_default_47, [2048, 768]);  clone_default_47 = None
        mm_default_22 = torch.ops.aten.mm.default(_unsafe_view_default_69, t_default_32)
        _unsafe_view_default_70 = torch.ops.aten._unsafe_view.default(mm_default_22, [1024, 2, 768]);  mm_default_22 = None
        add_tensor_32 = torch.ops.aten.add.Tensor(_unsafe_view_default_70, primals_121);  _unsafe_view_default_70 = primals_121 = None
        div__tensor_5 = torch.ops.aten.div_.Tensor(add_tensor_30, 8.0);  add_tensor_30 = None
        view_default_140 = torch.ops.aten.view.default(div__tensor_5, [1024, 2, 12, 64]);  div__tensor_5 = None
        transpose_int_76 = torch.ops.aten.transpose.int(view_default_140, 0, 1);  view_default_140 = None
        view_default_141 = torch.ops.aten.view.default(add_tensor_31, [1024, 2, 12, 64]);  add_tensor_31 = None
        transpose_int_77 = torch.ops.aten.transpose.int(view_default_141, 0, 1);  view_default_141 = None
        transpose_int_78 = torch.ops.aten.transpose.int(transpose_int_76, 1, 2);  transpose_int_76 = None
        view_default_142 = torch.ops.aten.view.default(transpose_int_78, [24, 1024, 64]);  transpose_int_78 = None
        transpose_int_79 = torch.ops.aten.transpose.int(transpose_int_77, 1, 2);  transpose_int_77 = None
        view_default_143 = torch.ops.aten.view.default(transpose_int_79, [24, 1024, 64]);  transpose_int_79 = None
        view_default_144 = torch.ops.aten.view.default(view_default_142, [24, 2, 512, 64]);  view_default_142 = None
        as_strided_default_25 = torch.ops.aten.as_strided.default(view_default_144, [24, 3, 512, 64], [64, 393216, 1536, 1]);  view_default_144 = None
        view_default_145 = torch.ops.aten.view.default(view_default_143, [24, 2, 512, 64]);  view_default_143 = None
        as_strided_default_26 = torch.ops.aten.as_strided.default(view_default_145, [24, 3, 512, 64], [64, 393216, 1536, 1]);  view_default_145 = None
        unsqueeze_default_70 = torch.ops.aten.unsqueeze.default(as_strided_default_25, -1);  as_strided_default_25 = None
        permute_default_60 = torch.ops.aten.permute.default(unsqueeze_default_70, [0, 1, 2, 4, 3]);  unsqueeze_default_70 = None
        unsqueeze_default_71 = torch.ops.aten.unsqueeze.default(as_strided_default_26, -1);  as_strided_default_26 = None
        permute_default_61 = torch.ops.aten.permute.default(unsqueeze_default_71, [0, 1, 4, 2, 3]);  unsqueeze_default_71 = None
        permute_default_62 = torch.ops.aten.permute.default(permute_default_60, [0, 1, 2, 4, 3]);  permute_default_60 = None
        clone_default_48 = torch.ops.aten.clone.default(permute_default_62, memory_format = torch.contiguous_format);  permute_default_62 = None
        _unsafe_view_default_71 = torch.ops.aten._unsafe_view.default(clone_default_48, [72, 512, 64]);  clone_default_48 = None
        permute_default_63 = torch.ops.aten.permute.default(permute_default_61, [0, 1, 4, 3, 2]);  permute_default_61 = None
        clone_default_49 = torch.ops.aten.clone.default(permute_default_63, memory_format = torch.contiguous_format);  permute_default_63 = None
        _unsafe_view_default_72 = torch.ops.aten._unsafe_view.default(clone_default_49, [72, 64, 512]);  clone_default_49 = None
        bmm_default_10 = torch.ops.aten.bmm.default(_unsafe_view_default_71, _unsafe_view_default_72)
        view_default_146 = torch.ops.aten.view.default(bmm_default_10, [24, 3, 512, 1, 512]);  bmm_default_10 = None
        permute_default_64 = torch.ops.aten.permute.default(view_default_146, [0, 1, 2, 4, 3]);  view_default_146 = None
        view_default_147 = torch.ops.aten.view.default(permute_default_64, [24, 3, 512, 512]);  permute_default_64 = None
        constant_pad_nd_default_20 = torch.ops.aten.constant_pad_nd.default(view_default_147, [0, 0, 0, 1], 0.0);  view_default_147 = None
        view_default_148 = torch.ops.aten.view.default(constant_pad_nd_default_20, [24, 3, 512, 513]);  constant_pad_nd_default_20 = None
        new_empty_default_25 = torch.ops.aten.new_empty.default(view_default_148, [24, 4, 256, 513], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        slice_tensor_435 = torch.ops.aten.slice.Tensor(view_default_148, 0, 0, 9223372036854775807)
        slice_tensor_436 = torch.ops.aten.slice.Tensor(slice_tensor_435, 1, 0, 9223372036854775807);  slice_tensor_435 = None
        slice_tensor_437 = torch.ops.aten.slice.Tensor(slice_tensor_436, 2, 0, 256);  slice_tensor_436 = None
        slice_tensor_438 = torch.ops.aten.slice.Tensor(slice_tensor_437, 3, 0, 257);  slice_tensor_437 = None
        slice_tensor_439 = torch.ops.aten.slice.Tensor(new_empty_default_25, 0, 0, 9223372036854775807)
        slice_tensor_440 = torch.ops.aten.slice.Tensor(slice_tensor_439, 1, 0, -1);  slice_tensor_439 = None
        slice_tensor_441 = torch.ops.aten.slice.Tensor(slice_tensor_440, 2, 0, 9223372036854775807);  slice_tensor_440 = None
        slice_tensor_442 = torch.ops.aten.slice.Tensor(slice_tensor_441, 3, 256, 9223372036854775807);  slice_tensor_441 = None
        copy__default_40 = torch.ops.aten.copy_.default(slice_tensor_442, slice_tensor_438);  slice_tensor_442 = slice_tensor_438 = None
        slice_tensor_443 = torch.ops.aten.slice.Tensor(view_default_148, 0, 0, 9223372036854775807)
        select_int_40 = torch.ops.aten.select.int(slice_tensor_443, 1, -1);  slice_tensor_443 = None
        slice_tensor_444 = torch.ops.aten.slice.Tensor(select_int_40, 1, 256, 9223372036854775807);  select_int_40 = None
        slice_tensor_445 = torch.ops.aten.slice.Tensor(slice_tensor_444, 2, 0, 257);  slice_tensor_444 = None
        slice_tensor_446 = torch.ops.aten.slice.Tensor(new_empty_default_25, 0, 0, 9223372036854775807)
        select_int_41 = torch.ops.aten.select.int(slice_tensor_446, 1, -1);  slice_tensor_446 = None
        slice_tensor_447 = torch.ops.aten.slice.Tensor(select_int_41, 1, 0, 9223372036854775807);  select_int_41 = None
        slice_tensor_448 = torch.ops.aten.slice.Tensor(slice_tensor_447, 2, 256, 9223372036854775807);  slice_tensor_447 = None
        copy__default_41 = torch.ops.aten.copy_.default(slice_tensor_448, slice_tensor_445);  slice_tensor_448 = slice_tensor_445 = None
        slice_tensor_449 = torch.ops.aten.slice.Tensor(view_default_148, 0, 0, 9223372036854775807)
        slice_tensor_450 = torch.ops.aten.slice.Tensor(slice_tensor_449, 1, 0, 9223372036854775807);  slice_tensor_449 = None
        slice_tensor_451 = torch.ops.aten.slice.Tensor(slice_tensor_450, 2, -257, -1);  slice_tensor_450 = None
        slice_tensor_452 = torch.ops.aten.slice.Tensor(slice_tensor_451, 3, 257, 9223372036854775807);  slice_tensor_451 = None
        slice_tensor_453 = torch.ops.aten.slice.Tensor(new_empty_default_25, 0, 0, 9223372036854775807)
        slice_tensor_454 = torch.ops.aten.slice.Tensor(slice_tensor_453, 1, 1, 9223372036854775807);  slice_tensor_453 = None
        slice_tensor_455 = torch.ops.aten.slice.Tensor(slice_tensor_454, 2, 0, 9223372036854775807);  slice_tensor_454 = None
        slice_tensor_456 = torch.ops.aten.slice.Tensor(slice_tensor_455, 3, 0, 256);  slice_tensor_455 = None
        copy__default_42 = torch.ops.aten.copy_.default(slice_tensor_456, slice_tensor_452);  slice_tensor_456 = slice_tensor_452 = None
        slice_tensor_457 = torch.ops.aten.slice.Tensor(view_default_148, 0, 0, 9223372036854775807);  view_default_148 = None
        select_int_42 = torch.ops.aten.select.int(slice_tensor_457, 1, 0);  slice_tensor_457 = None
        slice_tensor_458 = torch.ops.aten.slice.Tensor(select_int_42, 1, 0, 255);  select_int_42 = None
        slice_tensor_459 = torch.ops.aten.slice.Tensor(slice_tensor_458, 2, -255, 9223372036854775807);  slice_tensor_458 = None
        slice_tensor_460 = torch.ops.aten.slice.Tensor(new_empty_default_25, 0, 0, 9223372036854775807)
        select_int_43 = torch.ops.aten.select.int(slice_tensor_460, 1, 0);  slice_tensor_460 = None
        slice_tensor_461 = torch.ops.aten.slice.Tensor(select_int_43, 1, 1, 256);  select_int_43 = None
        slice_tensor_462 = torch.ops.aten.slice.Tensor(slice_tensor_461, 2, 1, 256);  slice_tensor_461 = None
        copy__default_43 = torch.ops.aten.copy_.default(slice_tensor_462, slice_tensor_459);  slice_tensor_462 = slice_tensor_459 = None
        view_default_149 = torch.ops.aten.view.default(new_empty_default_25, [2, 12, 1024, 513]);  new_empty_default_25 = None
        transpose_int_80 = torch.ops.aten.transpose.int(view_default_149, 2, 1);  view_default_149 = None
        new_empty_default_26 = torch.ops.aten.new_empty.default(transpose_int_80, [256, 257], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        fill__scalar_15 = torch.ops.aten.fill_.Scalar(new_empty_default_26, 1.0);  new_empty_default_26 = None
        tril_default_10 = torch.ops.aten.tril.default(fill__scalar_15);  fill__scalar_15 = None
        flip_default_20 = torch.ops.aten.flip.default(tril_default_10, [0]);  tril_default_10 = None
        unsqueeze_default_72 = torch.ops.aten.unsqueeze.default(flip_default_20, 0);  flip_default_20 = None
        slice_tensor_463 = torch.ops.aten.slice.Tensor(unsqueeze_default_72, 1, 0, 9223372036854775807);  unsqueeze_default_72 = None
        unsqueeze_default_73 = torch.ops.aten.unsqueeze.default(slice_tensor_463, 2);  slice_tensor_463 = None
        slice_tensor_464 = torch.ops.aten.slice.Tensor(unsqueeze_default_73, 3, 0, 9223372036854775807);  unsqueeze_default_73 = None
        flip_default_21 = torch.ops.aten.flip.default(slice_tensor_464, [1, 3])
        slice_tensor_465 = torch.ops.aten.slice.Tensor(transpose_int_80, 0, 0, 9223372036854775807)
        slice_tensor_466 = torch.ops.aten.slice.Tensor(slice_tensor_465, 1, 0, 256);  slice_tensor_465 = None
        slice_tensor_467 = torch.ops.aten.slice.Tensor(slice_tensor_466, 2, 0, 9223372036854775807);  slice_tensor_466 = None
        slice_tensor_468 = torch.ops.aten.slice.Tensor(slice_tensor_467, 3, 0, 257);  slice_tensor_467 = None
        expand_sym_int_20 = torch.ops.aten.expand.SymInt(slice_tensor_464, [2, 256, 12, 257]);  slice_tensor_464 = None
        eq_scalar_20 = torch.ops.aten.eq.Scalar(expand_sym_int_20, 1);  expand_sym_int_20 = None
        masked_fill__scalar_20 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_468, eq_scalar_20, -inf);  slice_tensor_468 = None
        slice_tensor_469 = torch.ops.aten.slice.Tensor(transpose_int_80, 0, 0, 9223372036854775807)
        slice_tensor_470 = torch.ops.aten.slice.Tensor(slice_tensor_469, 1, -256, 9223372036854775807);  slice_tensor_469 = None
        slice_tensor_471 = torch.ops.aten.slice.Tensor(slice_tensor_470, 2, 0, 9223372036854775807);  slice_tensor_470 = None
        slice_tensor_472 = torch.ops.aten.slice.Tensor(slice_tensor_471, 3, -257, 9223372036854775807);  slice_tensor_471 = None
        expand_sym_int_21 = torch.ops.aten.expand.SymInt(flip_default_21, [2, 256, 12, 257]);  flip_default_21 = None
        eq_scalar_21 = torch.ops.aten.eq.Scalar(expand_sym_int_21, 1);  expand_sym_int_21 = None
        masked_fill__scalar_21 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_472, eq_scalar_21, -inf);  slice_tensor_472 = None
        ne_scalar_5 = torch.ops.aten.ne.Scalar(primals_194, 0)
        slice_tensor_473 = torch.ops.aten.slice.Tensor(ne_scalar_5, 0, 0, 9223372036854775807);  ne_scalar_5 = None
        slice_tensor_474 = torch.ops.aten.slice.Tensor(slice_tensor_473, 1, 0, 9223372036854775807);  slice_tensor_473 = None
        unsqueeze_default_74 = torch.ops.aten.unsqueeze.default(slice_tensor_474, 2);  slice_tensor_474 = None
        unsqueeze_default_75 = torch.ops.aten.unsqueeze.default(unsqueeze_default_74, 3);  unsqueeze_default_74 = None
        _to_copy_default_5 = torch.ops.aten._to_copy.default(unsqueeze_default_75, device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided)
        where_scalar_self_10 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_75, -10000.0, _to_copy_default_5);  unsqueeze_default_75 = _to_copy_default_5 = None
        new_empty_default_27 = torch.ops.aten.new_empty.default(where_scalar_self_10, [2, 1024, 1, 1], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        fill__scalar_16 = torch.ops.aten.fill_.Scalar(new_empty_default_27, 1.0);  new_empty_default_27 = None
        transpose_int_81 = torch.ops.aten.transpose.int(fill__scalar_16, 1, 2);  fill__scalar_16 = None
        view_default_150 = torch.ops.aten.view.default(transpose_int_81, [2, 1024, 1]);  transpose_int_81 = None
        transpose_int_82 = torch.ops.aten.transpose.int(where_scalar_self_10, 1, 2);  where_scalar_self_10 = None
        view_default_151 = torch.ops.aten.view.default(transpose_int_82, [2, 1024, 1]);  transpose_int_82 = None
        view_default_152 = torch.ops.aten.view.default(view_default_150, [2, 2, 512, 1]);  view_default_150 = None
        as_strided_default_27 = torch.ops.aten.as_strided.default(view_default_152, [2, 3, 512, 1], [1024, 256, 1, 1]);  view_default_152 = None
        view_default_153 = torch.ops.aten.view.default(view_default_151, [2, 2, 512, 1]);  view_default_151 = None
        as_strided_default_28 = torch.ops.aten.as_strided.default(view_default_153, [2, 3, 512, 1], [1024, 256, 1, 1]);  view_default_153 = None
        unsqueeze_default_76 = torch.ops.aten.unsqueeze.default(as_strided_default_27, -1);  as_strided_default_27 = None
        permute_default_65 = torch.ops.aten.permute.default(unsqueeze_default_76, [0, 1, 2, 4, 3]);  unsqueeze_default_76 = None
        unsqueeze_default_77 = torch.ops.aten.unsqueeze.default(as_strided_default_28, -1);  as_strided_default_28 = None
        permute_default_66 = torch.ops.aten.permute.default(unsqueeze_default_77, [0, 1, 4, 2, 3]);  unsqueeze_default_77 = None
        squeeze_dim_10 = torch.ops.aten.squeeze.dim(permute_default_65, 4);  permute_default_65 = None
        squeeze_dim_11 = torch.ops.aten.squeeze.dim(permute_default_66, 4);  permute_default_66 = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(squeeze_dim_10, squeeze_dim_11);  squeeze_dim_10 = squeeze_dim_11 = None
        constant_pad_nd_default_21 = torch.ops.aten.constant_pad_nd.default(mul_tensor_5, [0, 0, 0, 1], 0.0);  mul_tensor_5 = None
        view_default_154 = torch.ops.aten.view.default(constant_pad_nd_default_21, [2, 3, 512, 513]);  constant_pad_nd_default_21 = None
        new_empty_default_28 = torch.ops.aten.new_empty.default(view_default_154, [2, 4, 256, 513], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        slice_tensor_475 = torch.ops.aten.slice.Tensor(view_default_154, 0, 0, 9223372036854775807)
        slice_tensor_476 = torch.ops.aten.slice.Tensor(slice_tensor_475, 1, 0, 9223372036854775807);  slice_tensor_475 = None
        slice_tensor_477 = torch.ops.aten.slice.Tensor(slice_tensor_476, 2, 0, 256);  slice_tensor_476 = None
        slice_tensor_478 = torch.ops.aten.slice.Tensor(slice_tensor_477, 3, 0, 257);  slice_tensor_477 = None
        slice_tensor_479 = torch.ops.aten.slice.Tensor(new_empty_default_28, 0, 0, 9223372036854775807)
        slice_tensor_480 = torch.ops.aten.slice.Tensor(slice_tensor_479, 1, 0, -1);  slice_tensor_479 = None
        slice_tensor_481 = torch.ops.aten.slice.Tensor(slice_tensor_480, 2, 0, 9223372036854775807);  slice_tensor_480 = None
        slice_tensor_482 = torch.ops.aten.slice.Tensor(slice_tensor_481, 3, 256, 9223372036854775807);  slice_tensor_481 = None
        copy__default_44 = torch.ops.aten.copy_.default(slice_tensor_482, slice_tensor_478);  slice_tensor_482 = slice_tensor_478 = None
        slice_tensor_483 = torch.ops.aten.slice.Tensor(view_default_154, 0, 0, 9223372036854775807)
        select_int_44 = torch.ops.aten.select.int(slice_tensor_483, 1, -1);  slice_tensor_483 = None
        slice_tensor_484 = torch.ops.aten.slice.Tensor(select_int_44, 1, 256, 9223372036854775807);  select_int_44 = None
        slice_tensor_485 = torch.ops.aten.slice.Tensor(slice_tensor_484, 2, 0, 257);  slice_tensor_484 = None
        slice_tensor_486 = torch.ops.aten.slice.Tensor(new_empty_default_28, 0, 0, 9223372036854775807)
        select_int_45 = torch.ops.aten.select.int(slice_tensor_486, 1, -1);  slice_tensor_486 = None
        slice_tensor_487 = torch.ops.aten.slice.Tensor(select_int_45, 1, 0, 9223372036854775807);  select_int_45 = None
        slice_tensor_488 = torch.ops.aten.slice.Tensor(slice_tensor_487, 2, 256, 9223372036854775807);  slice_tensor_487 = None
        copy__default_45 = torch.ops.aten.copy_.default(slice_tensor_488, slice_tensor_485);  slice_tensor_488 = slice_tensor_485 = None
        slice_tensor_489 = torch.ops.aten.slice.Tensor(view_default_154, 0, 0, 9223372036854775807)
        slice_tensor_490 = torch.ops.aten.slice.Tensor(slice_tensor_489, 1, 0, 9223372036854775807);  slice_tensor_489 = None
        slice_tensor_491 = torch.ops.aten.slice.Tensor(slice_tensor_490, 2, -257, -1);  slice_tensor_490 = None
        slice_tensor_492 = torch.ops.aten.slice.Tensor(slice_tensor_491, 3, 257, 9223372036854775807);  slice_tensor_491 = None
        slice_tensor_493 = torch.ops.aten.slice.Tensor(new_empty_default_28, 0, 0, 9223372036854775807)
        slice_tensor_494 = torch.ops.aten.slice.Tensor(slice_tensor_493, 1, 1, 9223372036854775807);  slice_tensor_493 = None
        slice_tensor_495 = torch.ops.aten.slice.Tensor(slice_tensor_494, 2, 0, 9223372036854775807);  slice_tensor_494 = None
        slice_tensor_496 = torch.ops.aten.slice.Tensor(slice_tensor_495, 3, 0, 256);  slice_tensor_495 = None
        copy__default_46 = torch.ops.aten.copy_.default(slice_tensor_496, slice_tensor_492);  slice_tensor_496 = slice_tensor_492 = None
        slice_tensor_497 = torch.ops.aten.slice.Tensor(view_default_154, 0, 0, 9223372036854775807);  view_default_154 = None
        select_int_46 = torch.ops.aten.select.int(slice_tensor_497, 1, 0);  slice_tensor_497 = None
        slice_tensor_498 = torch.ops.aten.slice.Tensor(select_int_46, 1, 0, 255);  select_int_46 = None
        slice_tensor_499 = torch.ops.aten.slice.Tensor(slice_tensor_498, 2, -255, 9223372036854775807);  slice_tensor_498 = None
        slice_tensor_500 = torch.ops.aten.slice.Tensor(new_empty_default_28, 0, 0, 9223372036854775807)
        select_int_47 = torch.ops.aten.select.int(slice_tensor_500, 1, 0);  slice_tensor_500 = None
        slice_tensor_501 = torch.ops.aten.slice.Tensor(select_int_47, 1, 1, 256);  select_int_47 = None
        slice_tensor_502 = torch.ops.aten.slice.Tensor(slice_tensor_501, 2, 1, 256);  slice_tensor_501 = None
        copy__default_47 = torch.ops.aten.copy_.default(slice_tensor_502, slice_tensor_499);  slice_tensor_502 = slice_tensor_499 = None
        view_default_155 = torch.ops.aten.view.default(new_empty_default_28, [2, 1, 1024, 513]);  new_empty_default_28 = None
        transpose_int_83 = torch.ops.aten.transpose.int(view_default_155, 2, 1);  view_default_155 = None
        new_empty_default_29 = torch.ops.aten.new_empty.default(transpose_int_83, [256, 257], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        fill__scalar_17 = torch.ops.aten.fill_.Scalar(new_empty_default_29, 1.0);  new_empty_default_29 = None
        tril_default_11 = torch.ops.aten.tril.default(fill__scalar_17);  fill__scalar_17 = None
        flip_default_22 = torch.ops.aten.flip.default(tril_default_11, [0]);  tril_default_11 = None
        unsqueeze_default_78 = torch.ops.aten.unsqueeze.default(flip_default_22, 0);  flip_default_22 = None
        slice_tensor_503 = torch.ops.aten.slice.Tensor(unsqueeze_default_78, 1, 0, 9223372036854775807);  unsqueeze_default_78 = None
        unsqueeze_default_79 = torch.ops.aten.unsqueeze.default(slice_tensor_503, 2);  slice_tensor_503 = None
        slice_tensor_504 = torch.ops.aten.slice.Tensor(unsqueeze_default_79, 3, 0, 9223372036854775807);  unsqueeze_default_79 = None
        flip_default_23 = torch.ops.aten.flip.default(slice_tensor_504, [1, 3])
        slice_tensor_505 = torch.ops.aten.slice.Tensor(transpose_int_83, 0, 0, 9223372036854775807)
        slice_tensor_506 = torch.ops.aten.slice.Tensor(slice_tensor_505, 1, 0, 256);  slice_tensor_505 = None
        slice_tensor_507 = torch.ops.aten.slice.Tensor(slice_tensor_506, 2, 0, 9223372036854775807);  slice_tensor_506 = None
        slice_tensor_508 = torch.ops.aten.slice.Tensor(slice_tensor_507, 3, 0, 257);  slice_tensor_507 = None
        expand_sym_int_22 = torch.ops.aten.expand.SymInt(slice_tensor_504, [2, 256, 1, 257]);  slice_tensor_504 = None
        eq_scalar_22 = torch.ops.aten.eq.Scalar(expand_sym_int_22, 1);  expand_sym_int_22 = None
        masked_fill__scalar_22 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_508, eq_scalar_22, -inf);  slice_tensor_508 = eq_scalar_22 = None
        slice_tensor_509 = torch.ops.aten.slice.Tensor(transpose_int_83, 0, 0, 9223372036854775807)
        slice_tensor_510 = torch.ops.aten.slice.Tensor(slice_tensor_509, 1, -256, 9223372036854775807);  slice_tensor_509 = None
        slice_tensor_511 = torch.ops.aten.slice.Tensor(slice_tensor_510, 2, 0, 9223372036854775807);  slice_tensor_510 = None
        slice_tensor_512 = torch.ops.aten.slice.Tensor(slice_tensor_511, 3, -257, 9223372036854775807);  slice_tensor_511 = None
        expand_sym_int_23 = torch.ops.aten.expand.SymInt(flip_default_23, [2, 256, 1, 257]);  flip_default_23 = None
        eq_scalar_23 = torch.ops.aten.eq.Scalar(expand_sym_int_23, 1);  expand_sym_int_23 = None
        masked_fill__scalar_23 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_512, eq_scalar_23, -inf);  slice_tensor_512 = eq_scalar_23 = None
        add__tensor_5 = torch.ops.aten.add_.Tensor(transpose_int_80, transpose_int_83);  transpose_int_80 = transpose_int_83 = None
        _softmax_default_5 = torch.ops.aten._softmax.default(add__tensor_5, -1, False);  add__tensor_5 = None
        slice_tensor_513 = torch.ops.aten.slice.Tensor(primals_195, 0, 0, 9223372036854775807)
        slice_tensor_514 = torch.ops.aten.slice.Tensor(slice_tensor_513, 1, 0, 9223372036854775807);  slice_tensor_513 = None
        unsqueeze_default_80 = torch.ops.aten.unsqueeze.default(slice_tensor_514, 2);  slice_tensor_514 = None
        unsqueeze_default_81 = torch.ops.aten.unsqueeze.default(unsqueeze_default_80, 3);  unsqueeze_default_80 = None
        where_scalar_self_11 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_81, 0.0, _softmax_default_5)
        view_default_156 = torch.ops.aten.view.default(add_tensor_32, [1024, 2, 12, 64]);  add_tensor_32 = None
        transpose_int_84 = torch.ops.aten.transpose.int(view_default_156, 0, 1);  view_default_156 = None
        transpose_int_85 = torch.ops.aten.transpose.int(where_scalar_self_11, 1, 2);  where_scalar_self_11 = None
        clone_default_50 = torch.ops.aten.clone.default(transpose_int_85, memory_format = torch.contiguous_format);  transpose_int_85 = None
        _unsafe_view_default_73 = torch.ops.aten._unsafe_view.default(clone_default_50, [24, 4, 256, 513]);  clone_default_50 = None
        transpose_int_86 = torch.ops.aten.transpose.int(transpose_int_84, 1, 2);  transpose_int_84 = None
        view_default_157 = torch.ops.aten.view.default(transpose_int_86, [24, 1024, 64]);  transpose_int_86 = None
        constant_pad_nd_default_22 = torch.ops.aten.constant_pad_nd.default(view_default_157, [0, 0, 256, 256], -1.0);  view_default_157 = None
        as_strided_default_29 = torch.ops.aten.as_strided.default(constant_pad_nd_default_22, [24, 4, 768, 64], [98304, 16384, 64, 1]);  constant_pad_nd_default_22 = None
        constant_pad_nd_default_23 = torch.ops.aten.constant_pad_nd.default(_unsafe_view_default_73, [0, 257], 0.0);  _unsafe_view_default_73 = None
        view_default_158 = torch.ops.aten.view.default(constant_pad_nd_default_23, [24, 4, -1]);  constant_pad_nd_default_23 = None
        slice_tensor_515 = torch.ops.aten.slice.Tensor(view_default_158, 0, 0, 9223372036854775807);  view_default_158 = None
        slice_tensor_516 = torch.ops.aten.slice.Tensor(slice_tensor_515, 1, 0, 9223372036854775807);  slice_tensor_515 = None
        slice_tensor_517 = torch.ops.aten.slice.Tensor(slice_tensor_516, 2, 0, -256);  slice_tensor_516 = None
        view_default_159 = torch.ops.aten.view.default(slice_tensor_517, [24, 4, 256, 769]);  slice_tensor_517 = None
        slice_tensor_518 = torch.ops.aten.slice.Tensor(view_default_159, 0, 0, 9223372036854775807);  view_default_159 = None
        slice_tensor_519 = torch.ops.aten.slice.Tensor(slice_tensor_518, 1, 0, 9223372036854775807);  slice_tensor_518 = None
        slice_tensor_520 = torch.ops.aten.slice.Tensor(slice_tensor_519, 2, 0, 9223372036854775807);  slice_tensor_519 = None
        slice_tensor_521 = torch.ops.aten.slice.Tensor(slice_tensor_520, 3, 0, -1);  slice_tensor_520 = None
        unsqueeze_default_82 = torch.ops.aten.unsqueeze.default(slice_tensor_521, -1);  slice_tensor_521 = None
        permute_default_67 = torch.ops.aten.permute.default(unsqueeze_default_82, [0, 1, 2, 4, 3]);  unsqueeze_default_82 = None
        unsqueeze_default_83 = torch.ops.aten.unsqueeze.default(as_strided_default_29, -1);  as_strided_default_29 = None
        permute_default_68 = torch.ops.aten.permute.default(unsqueeze_default_83, [0, 1, 4, 3, 2]);  unsqueeze_default_83 = None
        permute_default_69 = torch.ops.aten.permute.default(permute_default_67, [0, 1, 2, 4, 3]);  permute_default_67 = None
        view_default_160 = torch.ops.aten.view.default(permute_default_69, [96, 256, 768]);  permute_default_69 = None
        permute_default_70 = torch.ops.aten.permute.default(permute_default_68, [0, 1, 4, 3, 2]);  permute_default_68 = None
        clone_default_51 = torch.ops.aten.clone.default(permute_default_70, memory_format = torch.contiguous_format);  permute_default_70 = None
        _unsafe_view_default_74 = torch.ops.aten._unsafe_view.default(clone_default_51, [96, 768, 64]);  clone_default_51 = None
        bmm_default_11 = torch.ops.aten.bmm.default(view_default_160, _unsafe_view_default_74)
        view_default_161 = torch.ops.aten.view.default(bmm_default_11, [24, 4, 256, 1, 64]);  bmm_default_11 = None
        permute_default_71 = torch.ops.aten.permute.default(view_default_161, [0, 1, 2, 4, 3]);  view_default_161 = None
        view_default_162 = torch.ops.aten.view.default(permute_default_71, [24, 4, 256, 64]);  permute_default_71 = None
        view_default_163 = torch.ops.aten.view.default(view_default_162, [2, 12, 1024, 64]);  view_default_162 = None
        transpose_int_87 = torch.ops.aten.transpose.int(view_default_163, 1, 2);  view_default_163 = None
        transpose_int_88 = torch.ops.aten.transpose.int(transpose_int_87, 0, 1);  transpose_int_87 = None
        clone_default_52 = torch.ops.aten.clone.default(transpose_int_88, memory_format = torch.contiguous_format);  transpose_int_88 = None
        _unsafe_view_default_75 = torch.ops.aten._unsafe_view.default(clone_default_52, [1024, 2, 768]);  clone_default_52 = None
        transpose_int_89 = torch.ops.aten.transpose.int(_unsafe_view_default_75, 0, 1);  _unsafe_view_default_75 = None
        t_default_33 = torch.ops.aten.t.default(primals_116);  primals_116 = None
        clone_default_53 = torch.ops.aten.clone.default(transpose_int_89, memory_format = torch.contiguous_format);  transpose_int_89 = None
        _unsafe_view_default_76 = torch.ops.aten._unsafe_view.default(clone_default_53, [2048, 768]);  clone_default_53 = None
        mm_default_23 = torch.ops.aten.mm.default(_unsafe_view_default_76, t_default_33)
        _unsafe_view_default_77 = torch.ops.aten._unsafe_view.default(mm_default_23, [2, 1024, 768]);  mm_default_23 = None
        add_tensor_33 = torch.ops.aten.add.Tensor(_unsafe_view_default_77, primals_115);  _unsafe_view_default_77 = primals_115 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(add_tensor_33, getitem_27);  add_tensor_33 = getitem_27 = None
        native_layer_norm_default_10 = torch.ops.aten.native_layer_norm.default(add_tensor_34, [768], primals_114, primals_113, 1e-05)
        getitem_30 = native_layer_norm_default_10[0]
        getitem_31 = native_layer_norm_default_10[1]
        getitem_32 = native_layer_norm_default_10[2];  native_layer_norm_default_10 = None
        view_default_164 = torch.ops.aten.view.default(getitem_30, [2048, 768])
        t_default_34 = torch.ops.aten.t.default(primals_124);  primals_124 = None
        addmm_default_10 = torch.ops.aten.addmm.default(primals_123, view_default_164, t_default_34);  primals_123 = None
        view_default_165 = torch.ops.aten.view.default(addmm_default_10, [2, 1024, 3072]);  addmm_default_10 = None
        gelu_default_5 = torch.ops.aten.gelu.default(view_default_165)
        view_default_166 = torch.ops.aten.view.default(gelu_default_5, [2048, 3072]);  gelu_default_5 = None
        t_default_35 = torch.ops.aten.t.default(primals_128);  primals_128 = None
        addmm_default_11 = torch.ops.aten.addmm.default(primals_127, view_default_166, t_default_35);  primals_127 = None
        view_default_167 = torch.ops.aten.view.default(addmm_default_11, [2, 1024, 768]);  addmm_default_11 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(view_default_167, getitem_30);  view_default_167 = getitem_30 = None
        native_layer_norm_default_11 = torch.ops.aten.native_layer_norm.default(add_tensor_35, [768], primals_126, primals_125, 1e-05)
        getitem_33 = native_layer_norm_default_11[0]
        getitem_34 = native_layer_norm_default_11[1]
        getitem_35 = native_layer_norm_default_11[2];  native_layer_norm_default_11 = None
        transpose_int_90 = torch.ops.aten.transpose.int(getitem_33, 0, 1)
        t_default_36 = torch.ops.aten.t.default(primals_136);  primals_136 = None
        clone_default_54 = torch.ops.aten.clone.default(transpose_int_90, memory_format = torch.contiguous_format)
        _unsafe_view_default_78 = torch.ops.aten._unsafe_view.default(clone_default_54, [2048, 768]);  clone_default_54 = None
        mm_default_24 = torch.ops.aten.mm.default(_unsafe_view_default_78, t_default_36)
        _unsafe_view_default_79 = torch.ops.aten._unsafe_view.default(mm_default_24, [1024, 2, 768]);  mm_default_24 = None
        add_tensor_36 = torch.ops.aten.add.Tensor(_unsafe_view_default_79, primals_135);  _unsafe_view_default_79 = primals_135 = None
        t_default_37 = torch.ops.aten.t.default(primals_134);  primals_134 = None
        clone_default_55 = torch.ops.aten.clone.default(transpose_int_90, memory_format = torch.contiguous_format)
        _unsafe_view_default_80 = torch.ops.aten._unsafe_view.default(clone_default_55, [2048, 768]);  clone_default_55 = None
        mm_default_25 = torch.ops.aten.mm.default(_unsafe_view_default_80, t_default_37)
        _unsafe_view_default_81 = torch.ops.aten._unsafe_view.default(mm_default_25, [1024, 2, 768]);  mm_default_25 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(_unsafe_view_default_81, primals_133);  _unsafe_view_default_81 = primals_133 = None
        t_default_38 = torch.ops.aten.t.default(primals_138);  primals_138 = None
        clone_default_56 = torch.ops.aten.clone.default(transpose_int_90, memory_format = torch.contiguous_format);  transpose_int_90 = None
        _unsafe_view_default_82 = torch.ops.aten._unsafe_view.default(clone_default_56, [2048, 768]);  clone_default_56 = None
        mm_default_26 = torch.ops.aten.mm.default(_unsafe_view_default_82, t_default_38)
        _unsafe_view_default_83 = torch.ops.aten._unsafe_view.default(mm_default_26, [1024, 2, 768]);  mm_default_26 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(_unsafe_view_default_83, primals_137);  _unsafe_view_default_83 = primals_137 = None
        div__tensor_6 = torch.ops.aten.div_.Tensor(add_tensor_36, 8.0);  add_tensor_36 = None
        view_default_168 = torch.ops.aten.view.default(div__tensor_6, [1024, 2, 12, 64]);  div__tensor_6 = None
        transpose_int_91 = torch.ops.aten.transpose.int(view_default_168, 0, 1);  view_default_168 = None
        view_default_169 = torch.ops.aten.view.default(add_tensor_37, [1024, 2, 12, 64]);  add_tensor_37 = None
        transpose_int_92 = torch.ops.aten.transpose.int(view_default_169, 0, 1);  view_default_169 = None
        transpose_int_93 = torch.ops.aten.transpose.int(transpose_int_91, 1, 2);  transpose_int_91 = None
        view_default_170 = torch.ops.aten.view.default(transpose_int_93, [24, 1024, 64]);  transpose_int_93 = None
        transpose_int_94 = torch.ops.aten.transpose.int(transpose_int_92, 1, 2);  transpose_int_92 = None
        view_default_171 = torch.ops.aten.view.default(transpose_int_94, [24, 1024, 64]);  transpose_int_94 = None
        view_default_172 = torch.ops.aten.view.default(view_default_170, [24, 2, 512, 64]);  view_default_170 = None
        as_strided_default_30 = torch.ops.aten.as_strided.default(view_default_172, [24, 3, 512, 64], [64, 393216, 1536, 1]);  view_default_172 = None
        view_default_173 = torch.ops.aten.view.default(view_default_171, [24, 2, 512, 64]);  view_default_171 = None
        as_strided_default_31 = torch.ops.aten.as_strided.default(view_default_173, [24, 3, 512, 64], [64, 393216, 1536, 1]);  view_default_173 = None
        unsqueeze_default_84 = torch.ops.aten.unsqueeze.default(as_strided_default_30, -1);  as_strided_default_30 = None
        permute_default_72 = torch.ops.aten.permute.default(unsqueeze_default_84, [0, 1, 2, 4, 3]);  unsqueeze_default_84 = None
        unsqueeze_default_85 = torch.ops.aten.unsqueeze.default(as_strided_default_31, -1);  as_strided_default_31 = None
        permute_default_73 = torch.ops.aten.permute.default(unsqueeze_default_85, [0, 1, 4, 2, 3]);  unsqueeze_default_85 = None
        permute_default_74 = torch.ops.aten.permute.default(permute_default_72, [0, 1, 2, 4, 3]);  permute_default_72 = None
        clone_default_57 = torch.ops.aten.clone.default(permute_default_74, memory_format = torch.contiguous_format);  permute_default_74 = None
        _unsafe_view_default_84 = torch.ops.aten._unsafe_view.default(clone_default_57, [72, 512, 64]);  clone_default_57 = None
        permute_default_75 = torch.ops.aten.permute.default(permute_default_73, [0, 1, 4, 3, 2]);  permute_default_73 = None
        clone_default_58 = torch.ops.aten.clone.default(permute_default_75, memory_format = torch.contiguous_format);  permute_default_75 = None
        _unsafe_view_default_85 = torch.ops.aten._unsafe_view.default(clone_default_58, [72, 64, 512]);  clone_default_58 = None
        bmm_default_12 = torch.ops.aten.bmm.default(_unsafe_view_default_84, _unsafe_view_default_85)
        view_default_174 = torch.ops.aten.view.default(bmm_default_12, [24, 3, 512, 1, 512]);  bmm_default_12 = None
        permute_default_76 = torch.ops.aten.permute.default(view_default_174, [0, 1, 2, 4, 3]);  view_default_174 = None
        view_default_175 = torch.ops.aten.view.default(permute_default_76, [24, 3, 512, 512]);  permute_default_76 = None
        constant_pad_nd_default_24 = torch.ops.aten.constant_pad_nd.default(view_default_175, [0, 0, 0, 1], 0.0);  view_default_175 = None
        view_default_176 = torch.ops.aten.view.default(constant_pad_nd_default_24, [24, 3, 512, 513]);  constant_pad_nd_default_24 = None
        new_empty_default_30 = torch.ops.aten.new_empty.default(view_default_176, [24, 4, 256, 513], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        slice_tensor_522 = torch.ops.aten.slice.Tensor(view_default_176, 0, 0, 9223372036854775807)
        slice_tensor_523 = torch.ops.aten.slice.Tensor(slice_tensor_522, 1, 0, 9223372036854775807);  slice_tensor_522 = None
        slice_tensor_524 = torch.ops.aten.slice.Tensor(slice_tensor_523, 2, 0, 256);  slice_tensor_523 = None
        slice_tensor_525 = torch.ops.aten.slice.Tensor(slice_tensor_524, 3, 0, 257);  slice_tensor_524 = None
        slice_tensor_526 = torch.ops.aten.slice.Tensor(new_empty_default_30, 0, 0, 9223372036854775807)
        slice_tensor_527 = torch.ops.aten.slice.Tensor(slice_tensor_526, 1, 0, -1);  slice_tensor_526 = None
        slice_tensor_528 = torch.ops.aten.slice.Tensor(slice_tensor_527, 2, 0, 9223372036854775807);  slice_tensor_527 = None
        slice_tensor_529 = torch.ops.aten.slice.Tensor(slice_tensor_528, 3, 256, 9223372036854775807);  slice_tensor_528 = None
        copy__default_48 = torch.ops.aten.copy_.default(slice_tensor_529, slice_tensor_525);  slice_tensor_529 = slice_tensor_525 = None
        slice_tensor_530 = torch.ops.aten.slice.Tensor(view_default_176, 0, 0, 9223372036854775807)
        select_int_48 = torch.ops.aten.select.int(slice_tensor_530, 1, -1);  slice_tensor_530 = None
        slice_tensor_531 = torch.ops.aten.slice.Tensor(select_int_48, 1, 256, 9223372036854775807);  select_int_48 = None
        slice_tensor_532 = torch.ops.aten.slice.Tensor(slice_tensor_531, 2, 0, 257);  slice_tensor_531 = None
        slice_tensor_533 = torch.ops.aten.slice.Tensor(new_empty_default_30, 0, 0, 9223372036854775807)
        select_int_49 = torch.ops.aten.select.int(slice_tensor_533, 1, -1);  slice_tensor_533 = None
        slice_tensor_534 = torch.ops.aten.slice.Tensor(select_int_49, 1, 0, 9223372036854775807);  select_int_49 = None
        slice_tensor_535 = torch.ops.aten.slice.Tensor(slice_tensor_534, 2, 256, 9223372036854775807);  slice_tensor_534 = None
        copy__default_49 = torch.ops.aten.copy_.default(slice_tensor_535, slice_tensor_532);  slice_tensor_535 = slice_tensor_532 = None
        slice_tensor_536 = torch.ops.aten.slice.Tensor(view_default_176, 0, 0, 9223372036854775807)
        slice_tensor_537 = torch.ops.aten.slice.Tensor(slice_tensor_536, 1, 0, 9223372036854775807);  slice_tensor_536 = None
        slice_tensor_538 = torch.ops.aten.slice.Tensor(slice_tensor_537, 2, -257, -1);  slice_tensor_537 = None
        slice_tensor_539 = torch.ops.aten.slice.Tensor(slice_tensor_538, 3, 257, 9223372036854775807);  slice_tensor_538 = None
        slice_tensor_540 = torch.ops.aten.slice.Tensor(new_empty_default_30, 0, 0, 9223372036854775807)
        slice_tensor_541 = torch.ops.aten.slice.Tensor(slice_tensor_540, 1, 1, 9223372036854775807);  slice_tensor_540 = None
        slice_tensor_542 = torch.ops.aten.slice.Tensor(slice_tensor_541, 2, 0, 9223372036854775807);  slice_tensor_541 = None
        slice_tensor_543 = torch.ops.aten.slice.Tensor(slice_tensor_542, 3, 0, 256);  slice_tensor_542 = None
        copy__default_50 = torch.ops.aten.copy_.default(slice_tensor_543, slice_tensor_539);  slice_tensor_543 = slice_tensor_539 = None
        slice_tensor_544 = torch.ops.aten.slice.Tensor(view_default_176, 0, 0, 9223372036854775807);  view_default_176 = None
        select_int_50 = torch.ops.aten.select.int(slice_tensor_544, 1, 0);  slice_tensor_544 = None
        slice_tensor_545 = torch.ops.aten.slice.Tensor(select_int_50, 1, 0, 255);  select_int_50 = None
        slice_tensor_546 = torch.ops.aten.slice.Tensor(slice_tensor_545, 2, -255, 9223372036854775807);  slice_tensor_545 = None
        slice_tensor_547 = torch.ops.aten.slice.Tensor(new_empty_default_30, 0, 0, 9223372036854775807)
        select_int_51 = torch.ops.aten.select.int(slice_tensor_547, 1, 0);  slice_tensor_547 = None
        slice_tensor_548 = torch.ops.aten.slice.Tensor(select_int_51, 1, 1, 256);  select_int_51 = None
        slice_tensor_549 = torch.ops.aten.slice.Tensor(slice_tensor_548, 2, 1, 256);  slice_tensor_548 = None
        copy__default_51 = torch.ops.aten.copy_.default(slice_tensor_549, slice_tensor_546);  slice_tensor_549 = slice_tensor_546 = None
        view_default_177 = torch.ops.aten.view.default(new_empty_default_30, [2, 12, 1024, 513]);  new_empty_default_30 = None
        transpose_int_95 = torch.ops.aten.transpose.int(view_default_177, 2, 1);  view_default_177 = None
        new_empty_default_31 = torch.ops.aten.new_empty.default(transpose_int_95, [256, 257], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        fill__scalar_18 = torch.ops.aten.fill_.Scalar(new_empty_default_31, 1.0);  new_empty_default_31 = None
        tril_default_12 = torch.ops.aten.tril.default(fill__scalar_18);  fill__scalar_18 = None
        flip_default_24 = torch.ops.aten.flip.default(tril_default_12, [0]);  tril_default_12 = None
        unsqueeze_default_86 = torch.ops.aten.unsqueeze.default(flip_default_24, 0);  flip_default_24 = None
        slice_tensor_550 = torch.ops.aten.slice.Tensor(unsqueeze_default_86, 1, 0, 9223372036854775807);  unsqueeze_default_86 = None
        unsqueeze_default_87 = torch.ops.aten.unsqueeze.default(slice_tensor_550, 2);  slice_tensor_550 = None
        slice_tensor_551 = torch.ops.aten.slice.Tensor(unsqueeze_default_87, 3, 0, 9223372036854775807);  unsqueeze_default_87 = None
        flip_default_25 = torch.ops.aten.flip.default(slice_tensor_551, [1, 3])
        slice_tensor_552 = torch.ops.aten.slice.Tensor(transpose_int_95, 0, 0, 9223372036854775807)
        slice_tensor_553 = torch.ops.aten.slice.Tensor(slice_tensor_552, 1, 0, 256);  slice_tensor_552 = None
        slice_tensor_554 = torch.ops.aten.slice.Tensor(slice_tensor_553, 2, 0, 9223372036854775807);  slice_tensor_553 = None
        slice_tensor_555 = torch.ops.aten.slice.Tensor(slice_tensor_554, 3, 0, 257);  slice_tensor_554 = None
        expand_sym_int_24 = torch.ops.aten.expand.SymInt(slice_tensor_551, [2, 256, 12, 257]);  slice_tensor_551 = None
        eq_scalar_24 = torch.ops.aten.eq.Scalar(expand_sym_int_24, 1);  expand_sym_int_24 = None
        masked_fill__scalar_24 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_555, eq_scalar_24, -inf);  slice_tensor_555 = None
        slice_tensor_556 = torch.ops.aten.slice.Tensor(transpose_int_95, 0, 0, 9223372036854775807)
        slice_tensor_557 = torch.ops.aten.slice.Tensor(slice_tensor_556, 1, -256, 9223372036854775807);  slice_tensor_556 = None
        slice_tensor_558 = torch.ops.aten.slice.Tensor(slice_tensor_557, 2, 0, 9223372036854775807);  slice_tensor_557 = None
        slice_tensor_559 = torch.ops.aten.slice.Tensor(slice_tensor_558, 3, -257, 9223372036854775807);  slice_tensor_558 = None
        expand_sym_int_25 = torch.ops.aten.expand.SymInt(flip_default_25, [2, 256, 12, 257]);  flip_default_25 = None
        eq_scalar_25 = torch.ops.aten.eq.Scalar(expand_sym_int_25, 1);  expand_sym_int_25 = None
        masked_fill__scalar_25 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_559, eq_scalar_25, -inf);  slice_tensor_559 = None
        ne_scalar_6 = torch.ops.aten.ne.Scalar(primals_194, 0)
        slice_tensor_560 = torch.ops.aten.slice.Tensor(ne_scalar_6, 0, 0, 9223372036854775807);  ne_scalar_6 = None
        slice_tensor_561 = torch.ops.aten.slice.Tensor(slice_tensor_560, 1, 0, 9223372036854775807);  slice_tensor_560 = None
        unsqueeze_default_88 = torch.ops.aten.unsqueeze.default(slice_tensor_561, 2);  slice_tensor_561 = None
        unsqueeze_default_89 = torch.ops.aten.unsqueeze.default(unsqueeze_default_88, 3);  unsqueeze_default_88 = None
        _to_copy_default_6 = torch.ops.aten._to_copy.default(unsqueeze_default_89, device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided)
        where_scalar_self_12 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_89, -10000.0, _to_copy_default_6);  unsqueeze_default_89 = _to_copy_default_6 = None
        new_empty_default_32 = torch.ops.aten.new_empty.default(where_scalar_self_12, [2, 1024, 1, 1], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        fill__scalar_19 = torch.ops.aten.fill_.Scalar(new_empty_default_32, 1.0);  new_empty_default_32 = None
        transpose_int_96 = torch.ops.aten.transpose.int(fill__scalar_19, 1, 2);  fill__scalar_19 = None
        view_default_178 = torch.ops.aten.view.default(transpose_int_96, [2, 1024, 1]);  transpose_int_96 = None
        transpose_int_97 = torch.ops.aten.transpose.int(where_scalar_self_12, 1, 2);  where_scalar_self_12 = None
        view_default_179 = torch.ops.aten.view.default(transpose_int_97, [2, 1024, 1]);  transpose_int_97 = None
        view_default_180 = torch.ops.aten.view.default(view_default_178, [2, 2, 512, 1]);  view_default_178 = None
        as_strided_default_32 = torch.ops.aten.as_strided.default(view_default_180, [2, 3, 512, 1], [1024, 256, 1, 1]);  view_default_180 = None
        view_default_181 = torch.ops.aten.view.default(view_default_179, [2, 2, 512, 1]);  view_default_179 = None
        as_strided_default_33 = torch.ops.aten.as_strided.default(view_default_181, [2, 3, 512, 1], [1024, 256, 1, 1]);  view_default_181 = None
        unsqueeze_default_90 = torch.ops.aten.unsqueeze.default(as_strided_default_32, -1);  as_strided_default_32 = None
        permute_default_77 = torch.ops.aten.permute.default(unsqueeze_default_90, [0, 1, 2, 4, 3]);  unsqueeze_default_90 = None
        unsqueeze_default_91 = torch.ops.aten.unsqueeze.default(as_strided_default_33, -1);  as_strided_default_33 = None
        permute_default_78 = torch.ops.aten.permute.default(unsqueeze_default_91, [0, 1, 4, 2, 3]);  unsqueeze_default_91 = None
        squeeze_dim_12 = torch.ops.aten.squeeze.dim(permute_default_77, 4);  permute_default_77 = None
        squeeze_dim_13 = torch.ops.aten.squeeze.dim(permute_default_78, 4);  permute_default_78 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(squeeze_dim_12, squeeze_dim_13);  squeeze_dim_12 = squeeze_dim_13 = None
        constant_pad_nd_default_25 = torch.ops.aten.constant_pad_nd.default(mul_tensor_6, [0, 0, 0, 1], 0.0);  mul_tensor_6 = None
        view_default_182 = torch.ops.aten.view.default(constant_pad_nd_default_25, [2, 3, 512, 513]);  constant_pad_nd_default_25 = None
        new_empty_default_33 = torch.ops.aten.new_empty.default(view_default_182, [2, 4, 256, 513], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        slice_tensor_562 = torch.ops.aten.slice.Tensor(view_default_182, 0, 0, 9223372036854775807)
        slice_tensor_563 = torch.ops.aten.slice.Tensor(slice_tensor_562, 1, 0, 9223372036854775807);  slice_tensor_562 = None
        slice_tensor_564 = torch.ops.aten.slice.Tensor(slice_tensor_563, 2, 0, 256);  slice_tensor_563 = None
        slice_tensor_565 = torch.ops.aten.slice.Tensor(slice_tensor_564, 3, 0, 257);  slice_tensor_564 = None
        slice_tensor_566 = torch.ops.aten.slice.Tensor(new_empty_default_33, 0, 0, 9223372036854775807)
        slice_tensor_567 = torch.ops.aten.slice.Tensor(slice_tensor_566, 1, 0, -1);  slice_tensor_566 = None
        slice_tensor_568 = torch.ops.aten.slice.Tensor(slice_tensor_567, 2, 0, 9223372036854775807);  slice_tensor_567 = None
        slice_tensor_569 = torch.ops.aten.slice.Tensor(slice_tensor_568, 3, 256, 9223372036854775807);  slice_tensor_568 = None
        copy__default_52 = torch.ops.aten.copy_.default(slice_tensor_569, slice_tensor_565);  slice_tensor_569 = slice_tensor_565 = None
        slice_tensor_570 = torch.ops.aten.slice.Tensor(view_default_182, 0, 0, 9223372036854775807)
        select_int_52 = torch.ops.aten.select.int(slice_tensor_570, 1, -1);  slice_tensor_570 = None
        slice_tensor_571 = torch.ops.aten.slice.Tensor(select_int_52, 1, 256, 9223372036854775807);  select_int_52 = None
        slice_tensor_572 = torch.ops.aten.slice.Tensor(slice_tensor_571, 2, 0, 257);  slice_tensor_571 = None
        slice_tensor_573 = torch.ops.aten.slice.Tensor(new_empty_default_33, 0, 0, 9223372036854775807)
        select_int_53 = torch.ops.aten.select.int(slice_tensor_573, 1, -1);  slice_tensor_573 = None
        slice_tensor_574 = torch.ops.aten.slice.Tensor(select_int_53, 1, 0, 9223372036854775807);  select_int_53 = None
        slice_tensor_575 = torch.ops.aten.slice.Tensor(slice_tensor_574, 2, 256, 9223372036854775807);  slice_tensor_574 = None
        copy__default_53 = torch.ops.aten.copy_.default(slice_tensor_575, slice_tensor_572);  slice_tensor_575 = slice_tensor_572 = None
        slice_tensor_576 = torch.ops.aten.slice.Tensor(view_default_182, 0, 0, 9223372036854775807)
        slice_tensor_577 = torch.ops.aten.slice.Tensor(slice_tensor_576, 1, 0, 9223372036854775807);  slice_tensor_576 = None
        slice_tensor_578 = torch.ops.aten.slice.Tensor(slice_tensor_577, 2, -257, -1);  slice_tensor_577 = None
        slice_tensor_579 = torch.ops.aten.slice.Tensor(slice_tensor_578, 3, 257, 9223372036854775807);  slice_tensor_578 = None
        slice_tensor_580 = torch.ops.aten.slice.Tensor(new_empty_default_33, 0, 0, 9223372036854775807)
        slice_tensor_581 = torch.ops.aten.slice.Tensor(slice_tensor_580, 1, 1, 9223372036854775807);  slice_tensor_580 = None
        slice_tensor_582 = torch.ops.aten.slice.Tensor(slice_tensor_581, 2, 0, 9223372036854775807);  slice_tensor_581 = None
        slice_tensor_583 = torch.ops.aten.slice.Tensor(slice_tensor_582, 3, 0, 256);  slice_tensor_582 = None
        copy__default_54 = torch.ops.aten.copy_.default(slice_tensor_583, slice_tensor_579);  slice_tensor_583 = slice_tensor_579 = None
        slice_tensor_584 = torch.ops.aten.slice.Tensor(view_default_182, 0, 0, 9223372036854775807);  view_default_182 = None
        select_int_54 = torch.ops.aten.select.int(slice_tensor_584, 1, 0);  slice_tensor_584 = None
        slice_tensor_585 = torch.ops.aten.slice.Tensor(select_int_54, 1, 0, 255);  select_int_54 = None
        slice_tensor_586 = torch.ops.aten.slice.Tensor(slice_tensor_585, 2, -255, 9223372036854775807);  slice_tensor_585 = None
        slice_tensor_587 = torch.ops.aten.slice.Tensor(new_empty_default_33, 0, 0, 9223372036854775807)
        select_int_55 = torch.ops.aten.select.int(slice_tensor_587, 1, 0);  slice_tensor_587 = None
        slice_tensor_588 = torch.ops.aten.slice.Tensor(select_int_55, 1, 1, 256);  select_int_55 = None
        slice_tensor_589 = torch.ops.aten.slice.Tensor(slice_tensor_588, 2, 1, 256);  slice_tensor_588 = None
        copy__default_55 = torch.ops.aten.copy_.default(slice_tensor_589, slice_tensor_586);  slice_tensor_589 = slice_tensor_586 = None
        view_default_183 = torch.ops.aten.view.default(new_empty_default_33, [2, 1, 1024, 513]);  new_empty_default_33 = None
        transpose_int_98 = torch.ops.aten.transpose.int(view_default_183, 2, 1);  view_default_183 = None
        new_empty_default_34 = torch.ops.aten.new_empty.default(transpose_int_98, [256, 257], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        fill__scalar_20 = torch.ops.aten.fill_.Scalar(new_empty_default_34, 1.0);  new_empty_default_34 = None
        tril_default_13 = torch.ops.aten.tril.default(fill__scalar_20);  fill__scalar_20 = None
        flip_default_26 = torch.ops.aten.flip.default(tril_default_13, [0]);  tril_default_13 = None
        unsqueeze_default_92 = torch.ops.aten.unsqueeze.default(flip_default_26, 0);  flip_default_26 = None
        slice_tensor_590 = torch.ops.aten.slice.Tensor(unsqueeze_default_92, 1, 0, 9223372036854775807);  unsqueeze_default_92 = None
        unsqueeze_default_93 = torch.ops.aten.unsqueeze.default(slice_tensor_590, 2);  slice_tensor_590 = None
        slice_tensor_591 = torch.ops.aten.slice.Tensor(unsqueeze_default_93, 3, 0, 9223372036854775807);  unsqueeze_default_93 = None
        flip_default_27 = torch.ops.aten.flip.default(slice_tensor_591, [1, 3])
        slice_tensor_592 = torch.ops.aten.slice.Tensor(transpose_int_98, 0, 0, 9223372036854775807)
        slice_tensor_593 = torch.ops.aten.slice.Tensor(slice_tensor_592, 1, 0, 256);  slice_tensor_592 = None
        slice_tensor_594 = torch.ops.aten.slice.Tensor(slice_tensor_593, 2, 0, 9223372036854775807);  slice_tensor_593 = None
        slice_tensor_595 = torch.ops.aten.slice.Tensor(slice_tensor_594, 3, 0, 257);  slice_tensor_594 = None
        expand_sym_int_26 = torch.ops.aten.expand.SymInt(slice_tensor_591, [2, 256, 1, 257]);  slice_tensor_591 = None
        eq_scalar_26 = torch.ops.aten.eq.Scalar(expand_sym_int_26, 1);  expand_sym_int_26 = None
        masked_fill__scalar_26 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_595, eq_scalar_26, -inf);  slice_tensor_595 = eq_scalar_26 = None
        slice_tensor_596 = torch.ops.aten.slice.Tensor(transpose_int_98, 0, 0, 9223372036854775807)
        slice_tensor_597 = torch.ops.aten.slice.Tensor(slice_tensor_596, 1, -256, 9223372036854775807);  slice_tensor_596 = None
        slice_tensor_598 = torch.ops.aten.slice.Tensor(slice_tensor_597, 2, 0, 9223372036854775807);  slice_tensor_597 = None
        slice_tensor_599 = torch.ops.aten.slice.Tensor(slice_tensor_598, 3, -257, 9223372036854775807);  slice_tensor_598 = None
        expand_sym_int_27 = torch.ops.aten.expand.SymInt(flip_default_27, [2, 256, 1, 257]);  flip_default_27 = None
        eq_scalar_27 = torch.ops.aten.eq.Scalar(expand_sym_int_27, 1);  expand_sym_int_27 = None
        masked_fill__scalar_27 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_599, eq_scalar_27, -inf);  slice_tensor_599 = eq_scalar_27 = None
        add__tensor_6 = torch.ops.aten.add_.Tensor(transpose_int_95, transpose_int_98);  transpose_int_95 = transpose_int_98 = None
        _softmax_default_6 = torch.ops.aten._softmax.default(add__tensor_6, -1, False);  add__tensor_6 = None
        slice_tensor_600 = torch.ops.aten.slice.Tensor(primals_195, 0, 0, 9223372036854775807)
        slice_tensor_601 = torch.ops.aten.slice.Tensor(slice_tensor_600, 1, 0, 9223372036854775807);  slice_tensor_600 = None
        unsqueeze_default_94 = torch.ops.aten.unsqueeze.default(slice_tensor_601, 2);  slice_tensor_601 = None
        unsqueeze_default_95 = torch.ops.aten.unsqueeze.default(unsqueeze_default_94, 3);  unsqueeze_default_94 = None
        where_scalar_self_13 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_95, 0.0, _softmax_default_6)
        view_default_184 = torch.ops.aten.view.default(add_tensor_38, [1024, 2, 12, 64]);  add_tensor_38 = None
        transpose_int_99 = torch.ops.aten.transpose.int(view_default_184, 0, 1);  view_default_184 = None
        transpose_int_100 = torch.ops.aten.transpose.int(where_scalar_self_13, 1, 2);  where_scalar_self_13 = None
        clone_default_59 = torch.ops.aten.clone.default(transpose_int_100, memory_format = torch.contiguous_format);  transpose_int_100 = None
        _unsafe_view_default_86 = torch.ops.aten._unsafe_view.default(clone_default_59, [24, 4, 256, 513]);  clone_default_59 = None
        transpose_int_101 = torch.ops.aten.transpose.int(transpose_int_99, 1, 2);  transpose_int_99 = None
        view_default_185 = torch.ops.aten.view.default(transpose_int_101, [24, 1024, 64]);  transpose_int_101 = None
        constant_pad_nd_default_26 = torch.ops.aten.constant_pad_nd.default(view_default_185, [0, 0, 256, 256], -1.0);  view_default_185 = None
        as_strided_default_34 = torch.ops.aten.as_strided.default(constant_pad_nd_default_26, [24, 4, 768, 64], [98304, 16384, 64, 1]);  constant_pad_nd_default_26 = None
        constant_pad_nd_default_27 = torch.ops.aten.constant_pad_nd.default(_unsafe_view_default_86, [0, 257], 0.0);  _unsafe_view_default_86 = None
        view_default_186 = torch.ops.aten.view.default(constant_pad_nd_default_27, [24, 4, -1]);  constant_pad_nd_default_27 = None
        slice_tensor_602 = torch.ops.aten.slice.Tensor(view_default_186, 0, 0, 9223372036854775807);  view_default_186 = None
        slice_tensor_603 = torch.ops.aten.slice.Tensor(slice_tensor_602, 1, 0, 9223372036854775807);  slice_tensor_602 = None
        slice_tensor_604 = torch.ops.aten.slice.Tensor(slice_tensor_603, 2, 0, -256);  slice_tensor_603 = None
        view_default_187 = torch.ops.aten.view.default(slice_tensor_604, [24, 4, 256, 769]);  slice_tensor_604 = None
        slice_tensor_605 = torch.ops.aten.slice.Tensor(view_default_187, 0, 0, 9223372036854775807);  view_default_187 = None
        slice_tensor_606 = torch.ops.aten.slice.Tensor(slice_tensor_605, 1, 0, 9223372036854775807);  slice_tensor_605 = None
        slice_tensor_607 = torch.ops.aten.slice.Tensor(slice_tensor_606, 2, 0, 9223372036854775807);  slice_tensor_606 = None
        slice_tensor_608 = torch.ops.aten.slice.Tensor(slice_tensor_607, 3, 0, -1);  slice_tensor_607 = None
        unsqueeze_default_96 = torch.ops.aten.unsqueeze.default(slice_tensor_608, -1);  slice_tensor_608 = None
        permute_default_79 = torch.ops.aten.permute.default(unsqueeze_default_96, [0, 1, 2, 4, 3]);  unsqueeze_default_96 = None
        unsqueeze_default_97 = torch.ops.aten.unsqueeze.default(as_strided_default_34, -1);  as_strided_default_34 = None
        permute_default_80 = torch.ops.aten.permute.default(unsqueeze_default_97, [0, 1, 4, 3, 2]);  unsqueeze_default_97 = None
        permute_default_81 = torch.ops.aten.permute.default(permute_default_79, [0, 1, 2, 4, 3]);  permute_default_79 = None
        view_default_188 = torch.ops.aten.view.default(permute_default_81, [96, 256, 768]);  permute_default_81 = None
        permute_default_82 = torch.ops.aten.permute.default(permute_default_80, [0, 1, 4, 3, 2]);  permute_default_80 = None
        clone_default_60 = torch.ops.aten.clone.default(permute_default_82, memory_format = torch.contiguous_format);  permute_default_82 = None
        _unsafe_view_default_87 = torch.ops.aten._unsafe_view.default(clone_default_60, [96, 768, 64]);  clone_default_60 = None
        bmm_default_13 = torch.ops.aten.bmm.default(view_default_188, _unsafe_view_default_87)
        view_default_189 = torch.ops.aten.view.default(bmm_default_13, [24, 4, 256, 1, 64]);  bmm_default_13 = None
        permute_default_83 = torch.ops.aten.permute.default(view_default_189, [0, 1, 2, 4, 3]);  view_default_189 = None
        view_default_190 = torch.ops.aten.view.default(permute_default_83, [24, 4, 256, 64]);  permute_default_83 = None
        view_default_191 = torch.ops.aten.view.default(view_default_190, [2, 12, 1024, 64]);  view_default_190 = None
        transpose_int_102 = torch.ops.aten.transpose.int(view_default_191, 1, 2);  view_default_191 = None
        transpose_int_103 = torch.ops.aten.transpose.int(transpose_int_102, 0, 1);  transpose_int_102 = None
        clone_default_61 = torch.ops.aten.clone.default(transpose_int_103, memory_format = torch.contiguous_format);  transpose_int_103 = None
        _unsafe_view_default_88 = torch.ops.aten._unsafe_view.default(clone_default_61, [1024, 2, 768]);  clone_default_61 = None
        transpose_int_104 = torch.ops.aten.transpose.int(_unsafe_view_default_88, 0, 1);  _unsafe_view_default_88 = None
        t_default_39 = torch.ops.aten.t.default(primals_132);  primals_132 = None
        clone_default_62 = torch.ops.aten.clone.default(transpose_int_104, memory_format = torch.contiguous_format);  transpose_int_104 = None
        _unsafe_view_default_89 = torch.ops.aten._unsafe_view.default(clone_default_62, [2048, 768]);  clone_default_62 = None
        mm_default_27 = torch.ops.aten.mm.default(_unsafe_view_default_89, t_default_39)
        _unsafe_view_default_90 = torch.ops.aten._unsafe_view.default(mm_default_27, [2, 1024, 768]);  mm_default_27 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(_unsafe_view_default_90, primals_131);  _unsafe_view_default_90 = primals_131 = None
        add_tensor_40 = torch.ops.aten.add.Tensor(add_tensor_39, getitem_33);  add_tensor_39 = getitem_33 = None
        native_layer_norm_default_12 = torch.ops.aten.native_layer_norm.default(add_tensor_40, [768], primals_130, primals_129, 1e-05)
        getitem_36 = native_layer_norm_default_12[0]
        getitem_37 = native_layer_norm_default_12[1]
        getitem_38 = native_layer_norm_default_12[2];  native_layer_norm_default_12 = None
        view_default_192 = torch.ops.aten.view.default(getitem_36, [2048, 768])
        t_default_40 = torch.ops.aten.t.default(primals_140);  primals_140 = None
        addmm_default_12 = torch.ops.aten.addmm.default(primals_139, view_default_192, t_default_40);  primals_139 = None
        view_default_193 = torch.ops.aten.view.default(addmm_default_12, [2, 1024, 3072]);  addmm_default_12 = None
        gelu_default_6 = torch.ops.aten.gelu.default(view_default_193)
        view_default_194 = torch.ops.aten.view.default(gelu_default_6, [2048, 3072]);  gelu_default_6 = None
        t_default_41 = torch.ops.aten.t.default(primals_144);  primals_144 = None
        addmm_default_13 = torch.ops.aten.addmm.default(primals_143, view_default_194, t_default_41);  primals_143 = None
        view_default_195 = torch.ops.aten.view.default(addmm_default_13, [2, 1024, 768]);  addmm_default_13 = None
        add_tensor_41 = torch.ops.aten.add.Tensor(view_default_195, getitem_36);  view_default_195 = getitem_36 = None
        native_layer_norm_default_13 = torch.ops.aten.native_layer_norm.default(add_tensor_41, [768], primals_142, primals_141, 1e-05)
        getitem_39 = native_layer_norm_default_13[0]
        getitem_40 = native_layer_norm_default_13[1]
        getitem_41 = native_layer_norm_default_13[2];  native_layer_norm_default_13 = None
        transpose_int_105 = torch.ops.aten.transpose.int(getitem_39, 0, 1)
        t_default_42 = torch.ops.aten.t.default(primals_152);  primals_152 = None
        clone_default_63 = torch.ops.aten.clone.default(transpose_int_105, memory_format = torch.contiguous_format)
        _unsafe_view_default_91 = torch.ops.aten._unsafe_view.default(clone_default_63, [2048, 768]);  clone_default_63 = None
        mm_default_28 = torch.ops.aten.mm.default(_unsafe_view_default_91, t_default_42)
        _unsafe_view_default_92 = torch.ops.aten._unsafe_view.default(mm_default_28, [1024, 2, 768]);  mm_default_28 = None
        add_tensor_42 = torch.ops.aten.add.Tensor(_unsafe_view_default_92, primals_151);  _unsafe_view_default_92 = primals_151 = None
        t_default_43 = torch.ops.aten.t.default(primals_150);  primals_150 = None
        clone_default_64 = torch.ops.aten.clone.default(transpose_int_105, memory_format = torch.contiguous_format)
        _unsafe_view_default_93 = torch.ops.aten._unsafe_view.default(clone_default_64, [2048, 768]);  clone_default_64 = None
        mm_default_29 = torch.ops.aten.mm.default(_unsafe_view_default_93, t_default_43)
        _unsafe_view_default_94 = torch.ops.aten._unsafe_view.default(mm_default_29, [1024, 2, 768]);  mm_default_29 = None
        add_tensor_43 = torch.ops.aten.add.Tensor(_unsafe_view_default_94, primals_149);  _unsafe_view_default_94 = primals_149 = None
        t_default_44 = torch.ops.aten.t.default(primals_154);  primals_154 = None
        clone_default_65 = torch.ops.aten.clone.default(transpose_int_105, memory_format = torch.contiguous_format);  transpose_int_105 = None
        _unsafe_view_default_95 = torch.ops.aten._unsafe_view.default(clone_default_65, [2048, 768]);  clone_default_65 = None
        mm_default_30 = torch.ops.aten.mm.default(_unsafe_view_default_95, t_default_44)
        _unsafe_view_default_96 = torch.ops.aten._unsafe_view.default(mm_default_30, [1024, 2, 768]);  mm_default_30 = None
        add_tensor_44 = torch.ops.aten.add.Tensor(_unsafe_view_default_96, primals_153);  _unsafe_view_default_96 = primals_153 = None
        div__tensor_7 = torch.ops.aten.div_.Tensor(add_tensor_42, 8.0);  add_tensor_42 = None
        view_default_196 = torch.ops.aten.view.default(div__tensor_7, [1024, 2, 12, 64]);  div__tensor_7 = None
        transpose_int_106 = torch.ops.aten.transpose.int(view_default_196, 0, 1);  view_default_196 = None
        view_default_197 = torch.ops.aten.view.default(add_tensor_43, [1024, 2, 12, 64]);  add_tensor_43 = None
        transpose_int_107 = torch.ops.aten.transpose.int(view_default_197, 0, 1);  view_default_197 = None
        transpose_int_108 = torch.ops.aten.transpose.int(transpose_int_106, 1, 2);  transpose_int_106 = None
        view_default_198 = torch.ops.aten.view.default(transpose_int_108, [24, 1024, 64]);  transpose_int_108 = None
        transpose_int_109 = torch.ops.aten.transpose.int(transpose_int_107, 1, 2);  transpose_int_107 = None
        view_default_199 = torch.ops.aten.view.default(transpose_int_109, [24, 1024, 64]);  transpose_int_109 = None
        view_default_200 = torch.ops.aten.view.default(view_default_198, [24, 2, 512, 64]);  view_default_198 = None
        as_strided_default_35 = torch.ops.aten.as_strided.default(view_default_200, [24, 3, 512, 64], [64, 393216, 1536, 1]);  view_default_200 = None
        view_default_201 = torch.ops.aten.view.default(view_default_199, [24, 2, 512, 64]);  view_default_199 = None
        as_strided_default_36 = torch.ops.aten.as_strided.default(view_default_201, [24, 3, 512, 64], [64, 393216, 1536, 1]);  view_default_201 = None
        unsqueeze_default_98 = torch.ops.aten.unsqueeze.default(as_strided_default_35, -1);  as_strided_default_35 = None
        permute_default_84 = torch.ops.aten.permute.default(unsqueeze_default_98, [0, 1, 2, 4, 3]);  unsqueeze_default_98 = None
        unsqueeze_default_99 = torch.ops.aten.unsqueeze.default(as_strided_default_36, -1);  as_strided_default_36 = None
        permute_default_85 = torch.ops.aten.permute.default(unsqueeze_default_99, [0, 1, 4, 2, 3]);  unsqueeze_default_99 = None
        permute_default_86 = torch.ops.aten.permute.default(permute_default_84, [0, 1, 2, 4, 3]);  permute_default_84 = None
        clone_default_66 = torch.ops.aten.clone.default(permute_default_86, memory_format = torch.contiguous_format);  permute_default_86 = None
        _unsafe_view_default_97 = torch.ops.aten._unsafe_view.default(clone_default_66, [72, 512, 64]);  clone_default_66 = None
        permute_default_87 = torch.ops.aten.permute.default(permute_default_85, [0, 1, 4, 3, 2]);  permute_default_85 = None
        clone_default_67 = torch.ops.aten.clone.default(permute_default_87, memory_format = torch.contiguous_format);  permute_default_87 = None
        _unsafe_view_default_98 = torch.ops.aten._unsafe_view.default(clone_default_67, [72, 64, 512]);  clone_default_67 = None
        bmm_default_14 = torch.ops.aten.bmm.default(_unsafe_view_default_97, _unsafe_view_default_98)
        view_default_202 = torch.ops.aten.view.default(bmm_default_14, [24, 3, 512, 1, 512]);  bmm_default_14 = None
        permute_default_88 = torch.ops.aten.permute.default(view_default_202, [0, 1, 2, 4, 3]);  view_default_202 = None
        view_default_203 = torch.ops.aten.view.default(permute_default_88, [24, 3, 512, 512]);  permute_default_88 = None
        constant_pad_nd_default_28 = torch.ops.aten.constant_pad_nd.default(view_default_203, [0, 0, 0, 1], 0.0);  view_default_203 = None
        view_default_204 = torch.ops.aten.view.default(constant_pad_nd_default_28, [24, 3, 512, 513]);  constant_pad_nd_default_28 = None
        new_empty_default_35 = torch.ops.aten.new_empty.default(view_default_204, [24, 4, 256, 513], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        slice_tensor_609 = torch.ops.aten.slice.Tensor(view_default_204, 0, 0, 9223372036854775807)
        slice_tensor_610 = torch.ops.aten.slice.Tensor(slice_tensor_609, 1, 0, 9223372036854775807);  slice_tensor_609 = None
        slice_tensor_611 = torch.ops.aten.slice.Tensor(slice_tensor_610, 2, 0, 256);  slice_tensor_610 = None
        slice_tensor_612 = torch.ops.aten.slice.Tensor(slice_tensor_611, 3, 0, 257);  slice_tensor_611 = None
        slice_tensor_613 = torch.ops.aten.slice.Tensor(new_empty_default_35, 0, 0, 9223372036854775807)
        slice_tensor_614 = torch.ops.aten.slice.Tensor(slice_tensor_613, 1, 0, -1);  slice_tensor_613 = None
        slice_tensor_615 = torch.ops.aten.slice.Tensor(slice_tensor_614, 2, 0, 9223372036854775807);  slice_tensor_614 = None
        slice_tensor_616 = torch.ops.aten.slice.Tensor(slice_tensor_615, 3, 256, 9223372036854775807);  slice_tensor_615 = None
        copy__default_56 = torch.ops.aten.copy_.default(slice_tensor_616, slice_tensor_612);  slice_tensor_616 = slice_tensor_612 = None
        slice_tensor_617 = torch.ops.aten.slice.Tensor(view_default_204, 0, 0, 9223372036854775807)
        select_int_56 = torch.ops.aten.select.int(slice_tensor_617, 1, -1);  slice_tensor_617 = None
        slice_tensor_618 = torch.ops.aten.slice.Tensor(select_int_56, 1, 256, 9223372036854775807);  select_int_56 = None
        slice_tensor_619 = torch.ops.aten.slice.Tensor(slice_tensor_618, 2, 0, 257);  slice_tensor_618 = None
        slice_tensor_620 = torch.ops.aten.slice.Tensor(new_empty_default_35, 0, 0, 9223372036854775807)
        select_int_57 = torch.ops.aten.select.int(slice_tensor_620, 1, -1);  slice_tensor_620 = None
        slice_tensor_621 = torch.ops.aten.slice.Tensor(select_int_57, 1, 0, 9223372036854775807);  select_int_57 = None
        slice_tensor_622 = torch.ops.aten.slice.Tensor(slice_tensor_621, 2, 256, 9223372036854775807);  slice_tensor_621 = None
        copy__default_57 = torch.ops.aten.copy_.default(slice_tensor_622, slice_tensor_619);  slice_tensor_622 = slice_tensor_619 = None
        slice_tensor_623 = torch.ops.aten.slice.Tensor(view_default_204, 0, 0, 9223372036854775807)
        slice_tensor_624 = torch.ops.aten.slice.Tensor(slice_tensor_623, 1, 0, 9223372036854775807);  slice_tensor_623 = None
        slice_tensor_625 = torch.ops.aten.slice.Tensor(slice_tensor_624, 2, -257, -1);  slice_tensor_624 = None
        slice_tensor_626 = torch.ops.aten.slice.Tensor(slice_tensor_625, 3, 257, 9223372036854775807);  slice_tensor_625 = None
        slice_tensor_627 = torch.ops.aten.slice.Tensor(new_empty_default_35, 0, 0, 9223372036854775807)
        slice_tensor_628 = torch.ops.aten.slice.Tensor(slice_tensor_627, 1, 1, 9223372036854775807);  slice_tensor_627 = None
        slice_tensor_629 = torch.ops.aten.slice.Tensor(slice_tensor_628, 2, 0, 9223372036854775807);  slice_tensor_628 = None
        slice_tensor_630 = torch.ops.aten.slice.Tensor(slice_tensor_629, 3, 0, 256);  slice_tensor_629 = None
        copy__default_58 = torch.ops.aten.copy_.default(slice_tensor_630, slice_tensor_626);  slice_tensor_630 = slice_tensor_626 = None
        slice_tensor_631 = torch.ops.aten.slice.Tensor(view_default_204, 0, 0, 9223372036854775807);  view_default_204 = None
        select_int_58 = torch.ops.aten.select.int(slice_tensor_631, 1, 0);  slice_tensor_631 = None
        slice_tensor_632 = torch.ops.aten.slice.Tensor(select_int_58, 1, 0, 255);  select_int_58 = None
        slice_tensor_633 = torch.ops.aten.slice.Tensor(slice_tensor_632, 2, -255, 9223372036854775807);  slice_tensor_632 = None
        slice_tensor_634 = torch.ops.aten.slice.Tensor(new_empty_default_35, 0, 0, 9223372036854775807)
        select_int_59 = torch.ops.aten.select.int(slice_tensor_634, 1, 0);  slice_tensor_634 = None
        slice_tensor_635 = torch.ops.aten.slice.Tensor(select_int_59, 1, 1, 256);  select_int_59 = None
        slice_tensor_636 = torch.ops.aten.slice.Tensor(slice_tensor_635, 2, 1, 256);  slice_tensor_635 = None
        copy__default_59 = torch.ops.aten.copy_.default(slice_tensor_636, slice_tensor_633);  slice_tensor_636 = slice_tensor_633 = None
        view_default_205 = torch.ops.aten.view.default(new_empty_default_35, [2, 12, 1024, 513]);  new_empty_default_35 = None
        transpose_int_110 = torch.ops.aten.transpose.int(view_default_205, 2, 1);  view_default_205 = None
        new_empty_default_36 = torch.ops.aten.new_empty.default(transpose_int_110, [256, 257], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        fill__scalar_21 = torch.ops.aten.fill_.Scalar(new_empty_default_36, 1.0);  new_empty_default_36 = None
        tril_default_14 = torch.ops.aten.tril.default(fill__scalar_21);  fill__scalar_21 = None
        flip_default_28 = torch.ops.aten.flip.default(tril_default_14, [0]);  tril_default_14 = None
        unsqueeze_default_100 = torch.ops.aten.unsqueeze.default(flip_default_28, 0);  flip_default_28 = None
        slice_tensor_637 = torch.ops.aten.slice.Tensor(unsqueeze_default_100, 1, 0, 9223372036854775807);  unsqueeze_default_100 = None
        unsqueeze_default_101 = torch.ops.aten.unsqueeze.default(slice_tensor_637, 2);  slice_tensor_637 = None
        slice_tensor_638 = torch.ops.aten.slice.Tensor(unsqueeze_default_101, 3, 0, 9223372036854775807);  unsqueeze_default_101 = None
        flip_default_29 = torch.ops.aten.flip.default(slice_tensor_638, [1, 3])
        slice_tensor_639 = torch.ops.aten.slice.Tensor(transpose_int_110, 0, 0, 9223372036854775807)
        slice_tensor_640 = torch.ops.aten.slice.Tensor(slice_tensor_639, 1, 0, 256);  slice_tensor_639 = None
        slice_tensor_641 = torch.ops.aten.slice.Tensor(slice_tensor_640, 2, 0, 9223372036854775807);  slice_tensor_640 = None
        slice_tensor_642 = torch.ops.aten.slice.Tensor(slice_tensor_641, 3, 0, 257);  slice_tensor_641 = None
        expand_sym_int_28 = torch.ops.aten.expand.SymInt(slice_tensor_638, [2, 256, 12, 257]);  slice_tensor_638 = None
        eq_scalar_28 = torch.ops.aten.eq.Scalar(expand_sym_int_28, 1);  expand_sym_int_28 = None
        masked_fill__scalar_28 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_642, eq_scalar_28, -inf);  slice_tensor_642 = None
        slice_tensor_643 = torch.ops.aten.slice.Tensor(transpose_int_110, 0, 0, 9223372036854775807)
        slice_tensor_644 = torch.ops.aten.slice.Tensor(slice_tensor_643, 1, -256, 9223372036854775807);  slice_tensor_643 = None
        slice_tensor_645 = torch.ops.aten.slice.Tensor(slice_tensor_644, 2, 0, 9223372036854775807);  slice_tensor_644 = None
        slice_tensor_646 = torch.ops.aten.slice.Tensor(slice_tensor_645, 3, -257, 9223372036854775807);  slice_tensor_645 = None
        expand_sym_int_29 = torch.ops.aten.expand.SymInt(flip_default_29, [2, 256, 12, 257]);  flip_default_29 = None
        eq_scalar_29 = torch.ops.aten.eq.Scalar(expand_sym_int_29, 1);  expand_sym_int_29 = None
        masked_fill__scalar_29 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_646, eq_scalar_29, -inf);  slice_tensor_646 = None
        ne_scalar_7 = torch.ops.aten.ne.Scalar(primals_194, 0)
        slice_tensor_647 = torch.ops.aten.slice.Tensor(ne_scalar_7, 0, 0, 9223372036854775807);  ne_scalar_7 = None
        slice_tensor_648 = torch.ops.aten.slice.Tensor(slice_tensor_647, 1, 0, 9223372036854775807);  slice_tensor_647 = None
        unsqueeze_default_102 = torch.ops.aten.unsqueeze.default(slice_tensor_648, 2);  slice_tensor_648 = None
        unsqueeze_default_103 = torch.ops.aten.unsqueeze.default(unsqueeze_default_102, 3);  unsqueeze_default_102 = None
        _to_copy_default_7 = torch.ops.aten._to_copy.default(unsqueeze_default_103, device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided)
        where_scalar_self_14 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_103, -10000.0, _to_copy_default_7);  unsqueeze_default_103 = _to_copy_default_7 = None
        new_empty_default_37 = torch.ops.aten.new_empty.default(where_scalar_self_14, [2, 1024, 1, 1], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        fill__scalar_22 = torch.ops.aten.fill_.Scalar(new_empty_default_37, 1.0);  new_empty_default_37 = None
        transpose_int_111 = torch.ops.aten.transpose.int(fill__scalar_22, 1, 2);  fill__scalar_22 = None
        view_default_206 = torch.ops.aten.view.default(transpose_int_111, [2, 1024, 1]);  transpose_int_111 = None
        transpose_int_112 = torch.ops.aten.transpose.int(where_scalar_self_14, 1, 2);  where_scalar_self_14 = None
        view_default_207 = torch.ops.aten.view.default(transpose_int_112, [2, 1024, 1]);  transpose_int_112 = None
        view_default_208 = torch.ops.aten.view.default(view_default_206, [2, 2, 512, 1]);  view_default_206 = None
        as_strided_default_37 = torch.ops.aten.as_strided.default(view_default_208, [2, 3, 512, 1], [1024, 256, 1, 1]);  view_default_208 = None
        view_default_209 = torch.ops.aten.view.default(view_default_207, [2, 2, 512, 1]);  view_default_207 = None
        as_strided_default_38 = torch.ops.aten.as_strided.default(view_default_209, [2, 3, 512, 1], [1024, 256, 1, 1]);  view_default_209 = None
        unsqueeze_default_104 = torch.ops.aten.unsqueeze.default(as_strided_default_37, -1);  as_strided_default_37 = None
        permute_default_89 = torch.ops.aten.permute.default(unsqueeze_default_104, [0, 1, 2, 4, 3]);  unsqueeze_default_104 = None
        unsqueeze_default_105 = torch.ops.aten.unsqueeze.default(as_strided_default_38, -1);  as_strided_default_38 = None
        permute_default_90 = torch.ops.aten.permute.default(unsqueeze_default_105, [0, 1, 4, 2, 3]);  unsqueeze_default_105 = None
        squeeze_dim_14 = torch.ops.aten.squeeze.dim(permute_default_89, 4);  permute_default_89 = None
        squeeze_dim_15 = torch.ops.aten.squeeze.dim(permute_default_90, 4);  permute_default_90 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(squeeze_dim_14, squeeze_dim_15);  squeeze_dim_14 = squeeze_dim_15 = None
        constant_pad_nd_default_29 = torch.ops.aten.constant_pad_nd.default(mul_tensor_7, [0, 0, 0, 1], 0.0);  mul_tensor_7 = None
        view_default_210 = torch.ops.aten.view.default(constant_pad_nd_default_29, [2, 3, 512, 513]);  constant_pad_nd_default_29 = None
        new_empty_default_38 = torch.ops.aten.new_empty.default(view_default_210, [2, 4, 256, 513], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        slice_tensor_649 = torch.ops.aten.slice.Tensor(view_default_210, 0, 0, 9223372036854775807)
        slice_tensor_650 = torch.ops.aten.slice.Tensor(slice_tensor_649, 1, 0, 9223372036854775807);  slice_tensor_649 = None
        slice_tensor_651 = torch.ops.aten.slice.Tensor(slice_tensor_650, 2, 0, 256);  slice_tensor_650 = None
        slice_tensor_652 = torch.ops.aten.slice.Tensor(slice_tensor_651, 3, 0, 257);  slice_tensor_651 = None
        slice_tensor_653 = torch.ops.aten.slice.Tensor(new_empty_default_38, 0, 0, 9223372036854775807)
        slice_tensor_654 = torch.ops.aten.slice.Tensor(slice_tensor_653, 1, 0, -1);  slice_tensor_653 = None
        slice_tensor_655 = torch.ops.aten.slice.Tensor(slice_tensor_654, 2, 0, 9223372036854775807);  slice_tensor_654 = None
        slice_tensor_656 = torch.ops.aten.slice.Tensor(slice_tensor_655, 3, 256, 9223372036854775807);  slice_tensor_655 = None
        copy__default_60 = torch.ops.aten.copy_.default(slice_tensor_656, slice_tensor_652);  slice_tensor_656 = slice_tensor_652 = None
        slice_tensor_657 = torch.ops.aten.slice.Tensor(view_default_210, 0, 0, 9223372036854775807)
        select_int_60 = torch.ops.aten.select.int(slice_tensor_657, 1, -1);  slice_tensor_657 = None
        slice_tensor_658 = torch.ops.aten.slice.Tensor(select_int_60, 1, 256, 9223372036854775807);  select_int_60 = None
        slice_tensor_659 = torch.ops.aten.slice.Tensor(slice_tensor_658, 2, 0, 257);  slice_tensor_658 = None
        slice_tensor_660 = torch.ops.aten.slice.Tensor(new_empty_default_38, 0, 0, 9223372036854775807)
        select_int_61 = torch.ops.aten.select.int(slice_tensor_660, 1, -1);  slice_tensor_660 = None
        slice_tensor_661 = torch.ops.aten.slice.Tensor(select_int_61, 1, 0, 9223372036854775807);  select_int_61 = None
        slice_tensor_662 = torch.ops.aten.slice.Tensor(slice_tensor_661, 2, 256, 9223372036854775807);  slice_tensor_661 = None
        copy__default_61 = torch.ops.aten.copy_.default(slice_tensor_662, slice_tensor_659);  slice_tensor_662 = slice_tensor_659 = None
        slice_tensor_663 = torch.ops.aten.slice.Tensor(view_default_210, 0, 0, 9223372036854775807)
        slice_tensor_664 = torch.ops.aten.slice.Tensor(slice_tensor_663, 1, 0, 9223372036854775807);  slice_tensor_663 = None
        slice_tensor_665 = torch.ops.aten.slice.Tensor(slice_tensor_664, 2, -257, -1);  slice_tensor_664 = None
        slice_tensor_666 = torch.ops.aten.slice.Tensor(slice_tensor_665, 3, 257, 9223372036854775807);  slice_tensor_665 = None
        slice_tensor_667 = torch.ops.aten.slice.Tensor(new_empty_default_38, 0, 0, 9223372036854775807)
        slice_tensor_668 = torch.ops.aten.slice.Tensor(slice_tensor_667, 1, 1, 9223372036854775807);  slice_tensor_667 = None
        slice_tensor_669 = torch.ops.aten.slice.Tensor(slice_tensor_668, 2, 0, 9223372036854775807);  slice_tensor_668 = None
        slice_tensor_670 = torch.ops.aten.slice.Tensor(slice_tensor_669, 3, 0, 256);  slice_tensor_669 = None
        copy__default_62 = torch.ops.aten.copy_.default(slice_tensor_670, slice_tensor_666);  slice_tensor_670 = slice_tensor_666 = None
        slice_tensor_671 = torch.ops.aten.slice.Tensor(view_default_210, 0, 0, 9223372036854775807);  view_default_210 = None
        select_int_62 = torch.ops.aten.select.int(slice_tensor_671, 1, 0);  slice_tensor_671 = None
        slice_tensor_672 = torch.ops.aten.slice.Tensor(select_int_62, 1, 0, 255);  select_int_62 = None
        slice_tensor_673 = torch.ops.aten.slice.Tensor(slice_tensor_672, 2, -255, 9223372036854775807);  slice_tensor_672 = None
        slice_tensor_674 = torch.ops.aten.slice.Tensor(new_empty_default_38, 0, 0, 9223372036854775807)
        select_int_63 = torch.ops.aten.select.int(slice_tensor_674, 1, 0);  slice_tensor_674 = None
        slice_tensor_675 = torch.ops.aten.slice.Tensor(select_int_63, 1, 1, 256);  select_int_63 = None
        slice_tensor_676 = torch.ops.aten.slice.Tensor(slice_tensor_675, 2, 1, 256);  slice_tensor_675 = None
        copy__default_63 = torch.ops.aten.copy_.default(slice_tensor_676, slice_tensor_673);  slice_tensor_676 = slice_tensor_673 = None
        view_default_211 = torch.ops.aten.view.default(new_empty_default_38, [2, 1, 1024, 513]);  new_empty_default_38 = None
        transpose_int_113 = torch.ops.aten.transpose.int(view_default_211, 2, 1);  view_default_211 = None
        new_empty_default_39 = torch.ops.aten.new_empty.default(transpose_int_113, [256, 257], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        fill__scalar_23 = torch.ops.aten.fill_.Scalar(new_empty_default_39, 1.0);  new_empty_default_39 = None
        tril_default_15 = torch.ops.aten.tril.default(fill__scalar_23);  fill__scalar_23 = None
        flip_default_30 = torch.ops.aten.flip.default(tril_default_15, [0]);  tril_default_15 = None
        unsqueeze_default_106 = torch.ops.aten.unsqueeze.default(flip_default_30, 0);  flip_default_30 = None
        slice_tensor_677 = torch.ops.aten.slice.Tensor(unsqueeze_default_106, 1, 0, 9223372036854775807);  unsqueeze_default_106 = None
        unsqueeze_default_107 = torch.ops.aten.unsqueeze.default(slice_tensor_677, 2);  slice_tensor_677 = None
        slice_tensor_678 = torch.ops.aten.slice.Tensor(unsqueeze_default_107, 3, 0, 9223372036854775807);  unsqueeze_default_107 = None
        flip_default_31 = torch.ops.aten.flip.default(slice_tensor_678, [1, 3])
        slice_tensor_679 = torch.ops.aten.slice.Tensor(transpose_int_113, 0, 0, 9223372036854775807)
        slice_tensor_680 = torch.ops.aten.slice.Tensor(slice_tensor_679, 1, 0, 256);  slice_tensor_679 = None
        slice_tensor_681 = torch.ops.aten.slice.Tensor(slice_tensor_680, 2, 0, 9223372036854775807);  slice_tensor_680 = None
        slice_tensor_682 = torch.ops.aten.slice.Tensor(slice_tensor_681, 3, 0, 257);  slice_tensor_681 = None
        expand_sym_int_30 = torch.ops.aten.expand.SymInt(slice_tensor_678, [2, 256, 1, 257]);  slice_tensor_678 = None
        eq_scalar_30 = torch.ops.aten.eq.Scalar(expand_sym_int_30, 1);  expand_sym_int_30 = None
        masked_fill__scalar_30 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_682, eq_scalar_30, -inf);  slice_tensor_682 = eq_scalar_30 = None
        slice_tensor_683 = torch.ops.aten.slice.Tensor(transpose_int_113, 0, 0, 9223372036854775807)
        slice_tensor_684 = torch.ops.aten.slice.Tensor(slice_tensor_683, 1, -256, 9223372036854775807);  slice_tensor_683 = None
        slice_tensor_685 = torch.ops.aten.slice.Tensor(slice_tensor_684, 2, 0, 9223372036854775807);  slice_tensor_684 = None
        slice_tensor_686 = torch.ops.aten.slice.Tensor(slice_tensor_685, 3, -257, 9223372036854775807);  slice_tensor_685 = None
        expand_sym_int_31 = torch.ops.aten.expand.SymInt(flip_default_31, [2, 256, 1, 257]);  flip_default_31 = None
        eq_scalar_31 = torch.ops.aten.eq.Scalar(expand_sym_int_31, 1);  expand_sym_int_31 = None
        masked_fill__scalar_31 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_686, eq_scalar_31, -inf);  slice_tensor_686 = eq_scalar_31 = None
        add__tensor_7 = torch.ops.aten.add_.Tensor(transpose_int_110, transpose_int_113);  transpose_int_110 = transpose_int_113 = None
        _softmax_default_7 = torch.ops.aten._softmax.default(add__tensor_7, -1, False);  add__tensor_7 = None
        slice_tensor_687 = torch.ops.aten.slice.Tensor(primals_195, 0, 0, 9223372036854775807)
        slice_tensor_688 = torch.ops.aten.slice.Tensor(slice_tensor_687, 1, 0, 9223372036854775807);  slice_tensor_687 = None
        unsqueeze_default_108 = torch.ops.aten.unsqueeze.default(slice_tensor_688, 2);  slice_tensor_688 = None
        unsqueeze_default_109 = torch.ops.aten.unsqueeze.default(unsqueeze_default_108, 3);  unsqueeze_default_108 = None
        where_scalar_self_15 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_109, 0.0, _softmax_default_7)
        view_default_212 = torch.ops.aten.view.default(add_tensor_44, [1024, 2, 12, 64]);  add_tensor_44 = None
        transpose_int_114 = torch.ops.aten.transpose.int(view_default_212, 0, 1);  view_default_212 = None
        transpose_int_115 = torch.ops.aten.transpose.int(where_scalar_self_15, 1, 2);  where_scalar_self_15 = None
        clone_default_68 = torch.ops.aten.clone.default(transpose_int_115, memory_format = torch.contiguous_format);  transpose_int_115 = None
        _unsafe_view_default_99 = torch.ops.aten._unsafe_view.default(clone_default_68, [24, 4, 256, 513]);  clone_default_68 = None
        transpose_int_116 = torch.ops.aten.transpose.int(transpose_int_114, 1, 2);  transpose_int_114 = None
        view_default_213 = torch.ops.aten.view.default(transpose_int_116, [24, 1024, 64]);  transpose_int_116 = None
        constant_pad_nd_default_30 = torch.ops.aten.constant_pad_nd.default(view_default_213, [0, 0, 256, 256], -1.0);  view_default_213 = None
        as_strided_default_39 = torch.ops.aten.as_strided.default(constant_pad_nd_default_30, [24, 4, 768, 64], [98304, 16384, 64, 1]);  constant_pad_nd_default_30 = None
        constant_pad_nd_default_31 = torch.ops.aten.constant_pad_nd.default(_unsafe_view_default_99, [0, 257], 0.0);  _unsafe_view_default_99 = None
        view_default_214 = torch.ops.aten.view.default(constant_pad_nd_default_31, [24, 4, -1]);  constant_pad_nd_default_31 = None
        slice_tensor_689 = torch.ops.aten.slice.Tensor(view_default_214, 0, 0, 9223372036854775807);  view_default_214 = None
        slice_tensor_690 = torch.ops.aten.slice.Tensor(slice_tensor_689, 1, 0, 9223372036854775807);  slice_tensor_689 = None
        slice_tensor_691 = torch.ops.aten.slice.Tensor(slice_tensor_690, 2, 0, -256);  slice_tensor_690 = None
        view_default_215 = torch.ops.aten.view.default(slice_tensor_691, [24, 4, 256, 769]);  slice_tensor_691 = None
        slice_tensor_692 = torch.ops.aten.slice.Tensor(view_default_215, 0, 0, 9223372036854775807);  view_default_215 = None
        slice_tensor_693 = torch.ops.aten.slice.Tensor(slice_tensor_692, 1, 0, 9223372036854775807);  slice_tensor_692 = None
        slice_tensor_694 = torch.ops.aten.slice.Tensor(slice_tensor_693, 2, 0, 9223372036854775807);  slice_tensor_693 = None
        slice_tensor_695 = torch.ops.aten.slice.Tensor(slice_tensor_694, 3, 0, -1);  slice_tensor_694 = None
        unsqueeze_default_110 = torch.ops.aten.unsqueeze.default(slice_tensor_695, -1);  slice_tensor_695 = None
        permute_default_91 = torch.ops.aten.permute.default(unsqueeze_default_110, [0, 1, 2, 4, 3]);  unsqueeze_default_110 = None
        unsqueeze_default_111 = torch.ops.aten.unsqueeze.default(as_strided_default_39, -1);  as_strided_default_39 = None
        permute_default_92 = torch.ops.aten.permute.default(unsqueeze_default_111, [0, 1, 4, 3, 2]);  unsqueeze_default_111 = None
        permute_default_93 = torch.ops.aten.permute.default(permute_default_91, [0, 1, 2, 4, 3]);  permute_default_91 = None
        view_default_216 = torch.ops.aten.view.default(permute_default_93, [96, 256, 768]);  permute_default_93 = None
        permute_default_94 = torch.ops.aten.permute.default(permute_default_92, [0, 1, 4, 3, 2]);  permute_default_92 = None
        clone_default_69 = torch.ops.aten.clone.default(permute_default_94, memory_format = torch.contiguous_format);  permute_default_94 = None
        _unsafe_view_default_100 = torch.ops.aten._unsafe_view.default(clone_default_69, [96, 768, 64]);  clone_default_69 = None
        bmm_default_15 = torch.ops.aten.bmm.default(view_default_216, _unsafe_view_default_100)
        view_default_217 = torch.ops.aten.view.default(bmm_default_15, [24, 4, 256, 1, 64]);  bmm_default_15 = None
        permute_default_95 = torch.ops.aten.permute.default(view_default_217, [0, 1, 2, 4, 3]);  view_default_217 = None
        view_default_218 = torch.ops.aten.view.default(permute_default_95, [24, 4, 256, 64]);  permute_default_95 = None
        view_default_219 = torch.ops.aten.view.default(view_default_218, [2, 12, 1024, 64]);  view_default_218 = None
        transpose_int_117 = torch.ops.aten.transpose.int(view_default_219, 1, 2);  view_default_219 = None
        transpose_int_118 = torch.ops.aten.transpose.int(transpose_int_117, 0, 1);  transpose_int_117 = None
        clone_default_70 = torch.ops.aten.clone.default(transpose_int_118, memory_format = torch.contiguous_format);  transpose_int_118 = None
        _unsafe_view_default_101 = torch.ops.aten._unsafe_view.default(clone_default_70, [1024, 2, 768]);  clone_default_70 = None
        transpose_int_119 = torch.ops.aten.transpose.int(_unsafe_view_default_101, 0, 1);  _unsafe_view_default_101 = None
        t_default_45 = torch.ops.aten.t.default(primals_148);  primals_148 = None
        clone_default_71 = torch.ops.aten.clone.default(transpose_int_119, memory_format = torch.contiguous_format);  transpose_int_119 = None
        _unsafe_view_default_102 = torch.ops.aten._unsafe_view.default(clone_default_71, [2048, 768]);  clone_default_71 = None
        mm_default_31 = torch.ops.aten.mm.default(_unsafe_view_default_102, t_default_45)
        _unsafe_view_default_103 = torch.ops.aten._unsafe_view.default(mm_default_31, [2, 1024, 768]);  mm_default_31 = None
        add_tensor_45 = torch.ops.aten.add.Tensor(_unsafe_view_default_103, primals_147);  _unsafe_view_default_103 = primals_147 = None
        add_tensor_46 = torch.ops.aten.add.Tensor(add_tensor_45, getitem_39);  add_tensor_45 = getitem_39 = None
        native_layer_norm_default_14 = torch.ops.aten.native_layer_norm.default(add_tensor_46, [768], primals_146, primals_145, 1e-05)
        getitem_42 = native_layer_norm_default_14[0]
        getitem_43 = native_layer_norm_default_14[1]
        getitem_44 = native_layer_norm_default_14[2];  native_layer_norm_default_14 = None
        view_default_220 = torch.ops.aten.view.default(getitem_42, [2048, 768])
        t_default_46 = torch.ops.aten.t.default(primals_156);  primals_156 = None
        addmm_default_14 = torch.ops.aten.addmm.default(primals_155, view_default_220, t_default_46);  primals_155 = None
        view_default_221 = torch.ops.aten.view.default(addmm_default_14, [2, 1024, 3072]);  addmm_default_14 = None
        gelu_default_7 = torch.ops.aten.gelu.default(view_default_221)
        view_default_222 = torch.ops.aten.view.default(gelu_default_7, [2048, 3072]);  gelu_default_7 = None
        t_default_47 = torch.ops.aten.t.default(primals_160);  primals_160 = None
        addmm_default_15 = torch.ops.aten.addmm.default(primals_159, view_default_222, t_default_47);  primals_159 = None
        view_default_223 = torch.ops.aten.view.default(addmm_default_15, [2, 1024, 768]);  addmm_default_15 = None
        add_tensor_47 = torch.ops.aten.add.Tensor(view_default_223, getitem_42);  view_default_223 = getitem_42 = None
        native_layer_norm_default_15 = torch.ops.aten.native_layer_norm.default(add_tensor_47, [768], primals_158, primals_157, 1e-05)
        getitem_45 = native_layer_norm_default_15[0]
        getitem_46 = native_layer_norm_default_15[1]
        getitem_47 = native_layer_norm_default_15[2];  native_layer_norm_default_15 = None
        transpose_int_120 = torch.ops.aten.transpose.int(getitem_45, 0, 1)
        t_default_48 = torch.ops.aten.t.default(primals_168);  primals_168 = None
        clone_default_72 = torch.ops.aten.clone.default(transpose_int_120, memory_format = torch.contiguous_format)
        _unsafe_view_default_104 = torch.ops.aten._unsafe_view.default(clone_default_72, [2048, 768]);  clone_default_72 = None
        mm_default_32 = torch.ops.aten.mm.default(_unsafe_view_default_104, t_default_48)
        _unsafe_view_default_105 = torch.ops.aten._unsafe_view.default(mm_default_32, [1024, 2, 768]);  mm_default_32 = None
        add_tensor_48 = torch.ops.aten.add.Tensor(_unsafe_view_default_105, primals_167);  _unsafe_view_default_105 = primals_167 = None
        t_default_49 = torch.ops.aten.t.default(primals_166);  primals_166 = None
        clone_default_73 = torch.ops.aten.clone.default(transpose_int_120, memory_format = torch.contiguous_format)
        _unsafe_view_default_106 = torch.ops.aten._unsafe_view.default(clone_default_73, [2048, 768]);  clone_default_73 = None
        mm_default_33 = torch.ops.aten.mm.default(_unsafe_view_default_106, t_default_49)
        _unsafe_view_default_107 = torch.ops.aten._unsafe_view.default(mm_default_33, [1024, 2, 768]);  mm_default_33 = None
        add_tensor_49 = torch.ops.aten.add.Tensor(_unsafe_view_default_107, primals_165);  _unsafe_view_default_107 = primals_165 = None
        t_default_50 = torch.ops.aten.t.default(primals_170);  primals_170 = None
        clone_default_74 = torch.ops.aten.clone.default(transpose_int_120, memory_format = torch.contiguous_format);  transpose_int_120 = None
        _unsafe_view_default_108 = torch.ops.aten._unsafe_view.default(clone_default_74, [2048, 768]);  clone_default_74 = None
        mm_default_34 = torch.ops.aten.mm.default(_unsafe_view_default_108, t_default_50)
        _unsafe_view_default_109 = torch.ops.aten._unsafe_view.default(mm_default_34, [1024, 2, 768]);  mm_default_34 = None
        add_tensor_50 = torch.ops.aten.add.Tensor(_unsafe_view_default_109, primals_169);  _unsafe_view_default_109 = primals_169 = None
        div__tensor_8 = torch.ops.aten.div_.Tensor(add_tensor_48, 8.0);  add_tensor_48 = None
        view_default_224 = torch.ops.aten.view.default(div__tensor_8, [1024, 2, 12, 64]);  div__tensor_8 = None
        transpose_int_121 = torch.ops.aten.transpose.int(view_default_224, 0, 1);  view_default_224 = None
        view_default_225 = torch.ops.aten.view.default(add_tensor_49, [1024, 2, 12, 64]);  add_tensor_49 = None
        transpose_int_122 = torch.ops.aten.transpose.int(view_default_225, 0, 1);  view_default_225 = None
        transpose_int_123 = torch.ops.aten.transpose.int(transpose_int_121, 1, 2);  transpose_int_121 = None
        view_default_226 = torch.ops.aten.view.default(transpose_int_123, [24, 1024, 64]);  transpose_int_123 = None
        transpose_int_124 = torch.ops.aten.transpose.int(transpose_int_122, 1, 2);  transpose_int_122 = None
        view_default_227 = torch.ops.aten.view.default(transpose_int_124, [24, 1024, 64]);  transpose_int_124 = None
        view_default_228 = torch.ops.aten.view.default(view_default_226, [24, 2, 512, 64]);  view_default_226 = None
        as_strided_default_40 = torch.ops.aten.as_strided.default(view_default_228, [24, 3, 512, 64], [64, 393216, 1536, 1]);  view_default_228 = None
        view_default_229 = torch.ops.aten.view.default(view_default_227, [24, 2, 512, 64]);  view_default_227 = None
        as_strided_default_41 = torch.ops.aten.as_strided.default(view_default_229, [24, 3, 512, 64], [64, 393216, 1536, 1]);  view_default_229 = None
        unsqueeze_default_112 = torch.ops.aten.unsqueeze.default(as_strided_default_40, -1);  as_strided_default_40 = None
        permute_default_96 = torch.ops.aten.permute.default(unsqueeze_default_112, [0, 1, 2, 4, 3]);  unsqueeze_default_112 = None
        unsqueeze_default_113 = torch.ops.aten.unsqueeze.default(as_strided_default_41, -1);  as_strided_default_41 = None
        permute_default_97 = torch.ops.aten.permute.default(unsqueeze_default_113, [0, 1, 4, 2, 3]);  unsqueeze_default_113 = None
        permute_default_98 = torch.ops.aten.permute.default(permute_default_96, [0, 1, 2, 4, 3]);  permute_default_96 = None
        clone_default_75 = torch.ops.aten.clone.default(permute_default_98, memory_format = torch.contiguous_format);  permute_default_98 = None
        _unsafe_view_default_110 = torch.ops.aten._unsafe_view.default(clone_default_75, [72, 512, 64]);  clone_default_75 = None
        permute_default_99 = torch.ops.aten.permute.default(permute_default_97, [0, 1, 4, 3, 2]);  permute_default_97 = None
        clone_default_76 = torch.ops.aten.clone.default(permute_default_99, memory_format = torch.contiguous_format);  permute_default_99 = None
        _unsafe_view_default_111 = torch.ops.aten._unsafe_view.default(clone_default_76, [72, 64, 512]);  clone_default_76 = None
        bmm_default_16 = torch.ops.aten.bmm.default(_unsafe_view_default_110, _unsafe_view_default_111)
        view_default_230 = torch.ops.aten.view.default(bmm_default_16, [24, 3, 512, 1, 512]);  bmm_default_16 = None
        permute_default_100 = torch.ops.aten.permute.default(view_default_230, [0, 1, 2, 4, 3]);  view_default_230 = None
        view_default_231 = torch.ops.aten.view.default(permute_default_100, [24, 3, 512, 512]);  permute_default_100 = None
        constant_pad_nd_default_32 = torch.ops.aten.constant_pad_nd.default(view_default_231, [0, 0, 0, 1], 0.0);  view_default_231 = None
        view_default_232 = torch.ops.aten.view.default(constant_pad_nd_default_32, [24, 3, 512, 513]);  constant_pad_nd_default_32 = None
        new_empty_default_40 = torch.ops.aten.new_empty.default(view_default_232, [24, 4, 256, 513], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        slice_tensor_696 = torch.ops.aten.slice.Tensor(view_default_232, 0, 0, 9223372036854775807)
        slice_tensor_697 = torch.ops.aten.slice.Tensor(slice_tensor_696, 1, 0, 9223372036854775807);  slice_tensor_696 = None
        slice_tensor_698 = torch.ops.aten.slice.Tensor(slice_tensor_697, 2, 0, 256);  slice_tensor_697 = None
        slice_tensor_699 = torch.ops.aten.slice.Tensor(slice_tensor_698, 3, 0, 257);  slice_tensor_698 = None
        slice_tensor_700 = torch.ops.aten.slice.Tensor(new_empty_default_40, 0, 0, 9223372036854775807)
        slice_tensor_701 = torch.ops.aten.slice.Tensor(slice_tensor_700, 1, 0, -1);  slice_tensor_700 = None
        slice_tensor_702 = torch.ops.aten.slice.Tensor(slice_tensor_701, 2, 0, 9223372036854775807);  slice_tensor_701 = None
        slice_tensor_703 = torch.ops.aten.slice.Tensor(slice_tensor_702, 3, 256, 9223372036854775807);  slice_tensor_702 = None
        copy__default_64 = torch.ops.aten.copy_.default(slice_tensor_703, slice_tensor_699);  slice_tensor_703 = slice_tensor_699 = None
        slice_tensor_704 = torch.ops.aten.slice.Tensor(view_default_232, 0, 0, 9223372036854775807)
        select_int_64 = torch.ops.aten.select.int(slice_tensor_704, 1, -1);  slice_tensor_704 = None
        slice_tensor_705 = torch.ops.aten.slice.Tensor(select_int_64, 1, 256, 9223372036854775807);  select_int_64 = None
        slice_tensor_706 = torch.ops.aten.slice.Tensor(slice_tensor_705, 2, 0, 257);  slice_tensor_705 = None
        slice_tensor_707 = torch.ops.aten.slice.Tensor(new_empty_default_40, 0, 0, 9223372036854775807)
        select_int_65 = torch.ops.aten.select.int(slice_tensor_707, 1, -1);  slice_tensor_707 = None
        slice_tensor_708 = torch.ops.aten.slice.Tensor(select_int_65, 1, 0, 9223372036854775807);  select_int_65 = None
        slice_tensor_709 = torch.ops.aten.slice.Tensor(slice_tensor_708, 2, 256, 9223372036854775807);  slice_tensor_708 = None
        copy__default_65 = torch.ops.aten.copy_.default(slice_tensor_709, slice_tensor_706);  slice_tensor_709 = slice_tensor_706 = None
        slice_tensor_710 = torch.ops.aten.slice.Tensor(view_default_232, 0, 0, 9223372036854775807)
        slice_tensor_711 = torch.ops.aten.slice.Tensor(slice_tensor_710, 1, 0, 9223372036854775807);  slice_tensor_710 = None
        slice_tensor_712 = torch.ops.aten.slice.Tensor(slice_tensor_711, 2, -257, -1);  slice_tensor_711 = None
        slice_tensor_713 = torch.ops.aten.slice.Tensor(slice_tensor_712, 3, 257, 9223372036854775807);  slice_tensor_712 = None
        slice_tensor_714 = torch.ops.aten.slice.Tensor(new_empty_default_40, 0, 0, 9223372036854775807)
        slice_tensor_715 = torch.ops.aten.slice.Tensor(slice_tensor_714, 1, 1, 9223372036854775807);  slice_tensor_714 = None
        slice_tensor_716 = torch.ops.aten.slice.Tensor(slice_tensor_715, 2, 0, 9223372036854775807);  slice_tensor_715 = None
        slice_tensor_717 = torch.ops.aten.slice.Tensor(slice_tensor_716, 3, 0, 256);  slice_tensor_716 = None
        copy__default_66 = torch.ops.aten.copy_.default(slice_tensor_717, slice_tensor_713);  slice_tensor_717 = slice_tensor_713 = None
        slice_tensor_718 = torch.ops.aten.slice.Tensor(view_default_232, 0, 0, 9223372036854775807);  view_default_232 = None
        select_int_66 = torch.ops.aten.select.int(slice_tensor_718, 1, 0);  slice_tensor_718 = None
        slice_tensor_719 = torch.ops.aten.slice.Tensor(select_int_66, 1, 0, 255);  select_int_66 = None
        slice_tensor_720 = torch.ops.aten.slice.Tensor(slice_tensor_719, 2, -255, 9223372036854775807);  slice_tensor_719 = None
        slice_tensor_721 = torch.ops.aten.slice.Tensor(new_empty_default_40, 0, 0, 9223372036854775807)
        select_int_67 = torch.ops.aten.select.int(slice_tensor_721, 1, 0);  slice_tensor_721 = None
        slice_tensor_722 = torch.ops.aten.slice.Tensor(select_int_67, 1, 1, 256);  select_int_67 = None
        slice_tensor_723 = torch.ops.aten.slice.Tensor(slice_tensor_722, 2, 1, 256);  slice_tensor_722 = None
        copy__default_67 = torch.ops.aten.copy_.default(slice_tensor_723, slice_tensor_720);  slice_tensor_723 = slice_tensor_720 = None
        view_default_233 = torch.ops.aten.view.default(new_empty_default_40, [2, 12, 1024, 513]);  new_empty_default_40 = None
        transpose_int_125 = torch.ops.aten.transpose.int(view_default_233, 2, 1);  view_default_233 = None
        new_empty_default_41 = torch.ops.aten.new_empty.default(transpose_int_125, [256, 257], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        fill__scalar_24 = torch.ops.aten.fill_.Scalar(new_empty_default_41, 1.0);  new_empty_default_41 = None
        tril_default_16 = torch.ops.aten.tril.default(fill__scalar_24);  fill__scalar_24 = None
        flip_default_32 = torch.ops.aten.flip.default(tril_default_16, [0]);  tril_default_16 = None
        unsqueeze_default_114 = torch.ops.aten.unsqueeze.default(flip_default_32, 0);  flip_default_32 = None
        slice_tensor_724 = torch.ops.aten.slice.Tensor(unsqueeze_default_114, 1, 0, 9223372036854775807);  unsqueeze_default_114 = None
        unsqueeze_default_115 = torch.ops.aten.unsqueeze.default(slice_tensor_724, 2);  slice_tensor_724 = None
        slice_tensor_725 = torch.ops.aten.slice.Tensor(unsqueeze_default_115, 3, 0, 9223372036854775807);  unsqueeze_default_115 = None
        flip_default_33 = torch.ops.aten.flip.default(slice_tensor_725, [1, 3])
        slice_tensor_726 = torch.ops.aten.slice.Tensor(transpose_int_125, 0, 0, 9223372036854775807)
        slice_tensor_727 = torch.ops.aten.slice.Tensor(slice_tensor_726, 1, 0, 256);  slice_tensor_726 = None
        slice_tensor_728 = torch.ops.aten.slice.Tensor(slice_tensor_727, 2, 0, 9223372036854775807);  slice_tensor_727 = None
        slice_tensor_729 = torch.ops.aten.slice.Tensor(slice_tensor_728, 3, 0, 257);  slice_tensor_728 = None
        expand_sym_int_32 = torch.ops.aten.expand.SymInt(slice_tensor_725, [2, 256, 12, 257]);  slice_tensor_725 = None
        eq_scalar_32 = torch.ops.aten.eq.Scalar(expand_sym_int_32, 1);  expand_sym_int_32 = None
        masked_fill__scalar_32 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_729, eq_scalar_32, -inf);  slice_tensor_729 = None
        slice_tensor_730 = torch.ops.aten.slice.Tensor(transpose_int_125, 0, 0, 9223372036854775807)
        slice_tensor_731 = torch.ops.aten.slice.Tensor(slice_tensor_730, 1, -256, 9223372036854775807);  slice_tensor_730 = None
        slice_tensor_732 = torch.ops.aten.slice.Tensor(slice_tensor_731, 2, 0, 9223372036854775807);  slice_tensor_731 = None
        slice_tensor_733 = torch.ops.aten.slice.Tensor(slice_tensor_732, 3, -257, 9223372036854775807);  slice_tensor_732 = None
        expand_sym_int_33 = torch.ops.aten.expand.SymInt(flip_default_33, [2, 256, 12, 257]);  flip_default_33 = None
        eq_scalar_33 = torch.ops.aten.eq.Scalar(expand_sym_int_33, 1);  expand_sym_int_33 = None
        masked_fill__scalar_33 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_733, eq_scalar_33, -inf);  slice_tensor_733 = None
        ne_scalar_8 = torch.ops.aten.ne.Scalar(primals_194, 0)
        slice_tensor_734 = torch.ops.aten.slice.Tensor(ne_scalar_8, 0, 0, 9223372036854775807);  ne_scalar_8 = None
        slice_tensor_735 = torch.ops.aten.slice.Tensor(slice_tensor_734, 1, 0, 9223372036854775807);  slice_tensor_734 = None
        unsqueeze_default_116 = torch.ops.aten.unsqueeze.default(slice_tensor_735, 2);  slice_tensor_735 = None
        unsqueeze_default_117 = torch.ops.aten.unsqueeze.default(unsqueeze_default_116, 3);  unsqueeze_default_116 = None
        _to_copy_default_8 = torch.ops.aten._to_copy.default(unsqueeze_default_117, device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided)
        where_scalar_self_16 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_117, -10000.0, _to_copy_default_8);  unsqueeze_default_117 = _to_copy_default_8 = None
        new_empty_default_42 = torch.ops.aten.new_empty.default(where_scalar_self_16, [2, 1024, 1, 1], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        fill__scalar_25 = torch.ops.aten.fill_.Scalar(new_empty_default_42, 1.0);  new_empty_default_42 = None
        transpose_int_126 = torch.ops.aten.transpose.int(fill__scalar_25, 1, 2);  fill__scalar_25 = None
        view_default_234 = torch.ops.aten.view.default(transpose_int_126, [2, 1024, 1]);  transpose_int_126 = None
        transpose_int_127 = torch.ops.aten.transpose.int(where_scalar_self_16, 1, 2);  where_scalar_self_16 = None
        view_default_235 = torch.ops.aten.view.default(transpose_int_127, [2, 1024, 1]);  transpose_int_127 = None
        view_default_236 = torch.ops.aten.view.default(view_default_234, [2, 2, 512, 1]);  view_default_234 = None
        as_strided_default_42 = torch.ops.aten.as_strided.default(view_default_236, [2, 3, 512, 1], [1024, 256, 1, 1]);  view_default_236 = None
        view_default_237 = torch.ops.aten.view.default(view_default_235, [2, 2, 512, 1]);  view_default_235 = None
        as_strided_default_43 = torch.ops.aten.as_strided.default(view_default_237, [2, 3, 512, 1], [1024, 256, 1, 1]);  view_default_237 = None
        unsqueeze_default_118 = torch.ops.aten.unsqueeze.default(as_strided_default_42, -1);  as_strided_default_42 = None
        permute_default_101 = torch.ops.aten.permute.default(unsqueeze_default_118, [0, 1, 2, 4, 3]);  unsqueeze_default_118 = None
        unsqueeze_default_119 = torch.ops.aten.unsqueeze.default(as_strided_default_43, -1);  as_strided_default_43 = None
        permute_default_102 = torch.ops.aten.permute.default(unsqueeze_default_119, [0, 1, 4, 2, 3]);  unsqueeze_default_119 = None
        squeeze_dim_16 = torch.ops.aten.squeeze.dim(permute_default_101, 4);  permute_default_101 = None
        squeeze_dim_17 = torch.ops.aten.squeeze.dim(permute_default_102, 4);  permute_default_102 = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(squeeze_dim_16, squeeze_dim_17);  squeeze_dim_16 = squeeze_dim_17 = None
        constant_pad_nd_default_33 = torch.ops.aten.constant_pad_nd.default(mul_tensor_8, [0, 0, 0, 1], 0.0);  mul_tensor_8 = None
        view_default_238 = torch.ops.aten.view.default(constant_pad_nd_default_33, [2, 3, 512, 513]);  constant_pad_nd_default_33 = None
        new_empty_default_43 = torch.ops.aten.new_empty.default(view_default_238, [2, 4, 256, 513], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        slice_tensor_736 = torch.ops.aten.slice.Tensor(view_default_238, 0, 0, 9223372036854775807)
        slice_tensor_737 = torch.ops.aten.slice.Tensor(slice_tensor_736, 1, 0, 9223372036854775807);  slice_tensor_736 = None
        slice_tensor_738 = torch.ops.aten.slice.Tensor(slice_tensor_737, 2, 0, 256);  slice_tensor_737 = None
        slice_tensor_739 = torch.ops.aten.slice.Tensor(slice_tensor_738, 3, 0, 257);  slice_tensor_738 = None
        slice_tensor_740 = torch.ops.aten.slice.Tensor(new_empty_default_43, 0, 0, 9223372036854775807)
        slice_tensor_741 = torch.ops.aten.slice.Tensor(slice_tensor_740, 1, 0, -1);  slice_tensor_740 = None
        slice_tensor_742 = torch.ops.aten.slice.Tensor(slice_tensor_741, 2, 0, 9223372036854775807);  slice_tensor_741 = None
        slice_tensor_743 = torch.ops.aten.slice.Tensor(slice_tensor_742, 3, 256, 9223372036854775807);  slice_tensor_742 = None
        copy__default_68 = torch.ops.aten.copy_.default(slice_tensor_743, slice_tensor_739);  slice_tensor_743 = slice_tensor_739 = None
        slice_tensor_744 = torch.ops.aten.slice.Tensor(view_default_238, 0, 0, 9223372036854775807)
        select_int_68 = torch.ops.aten.select.int(slice_tensor_744, 1, -1);  slice_tensor_744 = None
        slice_tensor_745 = torch.ops.aten.slice.Tensor(select_int_68, 1, 256, 9223372036854775807);  select_int_68 = None
        slice_tensor_746 = torch.ops.aten.slice.Tensor(slice_tensor_745, 2, 0, 257);  slice_tensor_745 = None
        slice_tensor_747 = torch.ops.aten.slice.Tensor(new_empty_default_43, 0, 0, 9223372036854775807)
        select_int_69 = torch.ops.aten.select.int(slice_tensor_747, 1, -1);  slice_tensor_747 = None
        slice_tensor_748 = torch.ops.aten.slice.Tensor(select_int_69, 1, 0, 9223372036854775807);  select_int_69 = None
        slice_tensor_749 = torch.ops.aten.slice.Tensor(slice_tensor_748, 2, 256, 9223372036854775807);  slice_tensor_748 = None
        copy__default_69 = torch.ops.aten.copy_.default(slice_tensor_749, slice_tensor_746);  slice_tensor_749 = slice_tensor_746 = None
        slice_tensor_750 = torch.ops.aten.slice.Tensor(view_default_238, 0, 0, 9223372036854775807)
        slice_tensor_751 = torch.ops.aten.slice.Tensor(slice_tensor_750, 1, 0, 9223372036854775807);  slice_tensor_750 = None
        slice_tensor_752 = torch.ops.aten.slice.Tensor(slice_tensor_751, 2, -257, -1);  slice_tensor_751 = None
        slice_tensor_753 = torch.ops.aten.slice.Tensor(slice_tensor_752, 3, 257, 9223372036854775807);  slice_tensor_752 = None
        slice_tensor_754 = torch.ops.aten.slice.Tensor(new_empty_default_43, 0, 0, 9223372036854775807)
        slice_tensor_755 = torch.ops.aten.slice.Tensor(slice_tensor_754, 1, 1, 9223372036854775807);  slice_tensor_754 = None
        slice_tensor_756 = torch.ops.aten.slice.Tensor(slice_tensor_755, 2, 0, 9223372036854775807);  slice_tensor_755 = None
        slice_tensor_757 = torch.ops.aten.slice.Tensor(slice_tensor_756, 3, 0, 256);  slice_tensor_756 = None
        copy__default_70 = torch.ops.aten.copy_.default(slice_tensor_757, slice_tensor_753);  slice_tensor_757 = slice_tensor_753 = None
        slice_tensor_758 = torch.ops.aten.slice.Tensor(view_default_238, 0, 0, 9223372036854775807);  view_default_238 = None
        select_int_70 = torch.ops.aten.select.int(slice_tensor_758, 1, 0);  slice_tensor_758 = None
        slice_tensor_759 = torch.ops.aten.slice.Tensor(select_int_70, 1, 0, 255);  select_int_70 = None
        slice_tensor_760 = torch.ops.aten.slice.Tensor(slice_tensor_759, 2, -255, 9223372036854775807);  slice_tensor_759 = None
        slice_tensor_761 = torch.ops.aten.slice.Tensor(new_empty_default_43, 0, 0, 9223372036854775807)
        select_int_71 = torch.ops.aten.select.int(slice_tensor_761, 1, 0);  slice_tensor_761 = None
        slice_tensor_762 = torch.ops.aten.slice.Tensor(select_int_71, 1, 1, 256);  select_int_71 = None
        slice_tensor_763 = torch.ops.aten.slice.Tensor(slice_tensor_762, 2, 1, 256);  slice_tensor_762 = None
        copy__default_71 = torch.ops.aten.copy_.default(slice_tensor_763, slice_tensor_760);  slice_tensor_763 = slice_tensor_760 = None
        view_default_239 = torch.ops.aten.view.default(new_empty_default_43, [2, 1, 1024, 513]);  new_empty_default_43 = None
        transpose_int_128 = torch.ops.aten.transpose.int(view_default_239, 2, 1);  view_default_239 = None
        new_empty_default_44 = torch.ops.aten.new_empty.default(transpose_int_128, [256, 257], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        fill__scalar_26 = torch.ops.aten.fill_.Scalar(new_empty_default_44, 1.0);  new_empty_default_44 = None
        tril_default_17 = torch.ops.aten.tril.default(fill__scalar_26);  fill__scalar_26 = None
        flip_default_34 = torch.ops.aten.flip.default(tril_default_17, [0]);  tril_default_17 = None
        unsqueeze_default_120 = torch.ops.aten.unsqueeze.default(flip_default_34, 0);  flip_default_34 = None
        slice_tensor_764 = torch.ops.aten.slice.Tensor(unsqueeze_default_120, 1, 0, 9223372036854775807);  unsqueeze_default_120 = None
        unsqueeze_default_121 = torch.ops.aten.unsqueeze.default(slice_tensor_764, 2);  slice_tensor_764 = None
        slice_tensor_765 = torch.ops.aten.slice.Tensor(unsqueeze_default_121, 3, 0, 9223372036854775807);  unsqueeze_default_121 = None
        flip_default_35 = torch.ops.aten.flip.default(slice_tensor_765, [1, 3])
        slice_tensor_766 = torch.ops.aten.slice.Tensor(transpose_int_128, 0, 0, 9223372036854775807)
        slice_tensor_767 = torch.ops.aten.slice.Tensor(slice_tensor_766, 1, 0, 256);  slice_tensor_766 = None
        slice_tensor_768 = torch.ops.aten.slice.Tensor(slice_tensor_767, 2, 0, 9223372036854775807);  slice_tensor_767 = None
        slice_tensor_769 = torch.ops.aten.slice.Tensor(slice_tensor_768, 3, 0, 257);  slice_tensor_768 = None
        expand_sym_int_34 = torch.ops.aten.expand.SymInt(slice_tensor_765, [2, 256, 1, 257]);  slice_tensor_765 = None
        eq_scalar_34 = torch.ops.aten.eq.Scalar(expand_sym_int_34, 1);  expand_sym_int_34 = None
        masked_fill__scalar_34 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_769, eq_scalar_34, -inf);  slice_tensor_769 = eq_scalar_34 = None
        slice_tensor_770 = torch.ops.aten.slice.Tensor(transpose_int_128, 0, 0, 9223372036854775807)
        slice_tensor_771 = torch.ops.aten.slice.Tensor(slice_tensor_770, 1, -256, 9223372036854775807);  slice_tensor_770 = None
        slice_tensor_772 = torch.ops.aten.slice.Tensor(slice_tensor_771, 2, 0, 9223372036854775807);  slice_tensor_771 = None
        slice_tensor_773 = torch.ops.aten.slice.Tensor(slice_tensor_772, 3, -257, 9223372036854775807);  slice_tensor_772 = None
        expand_sym_int_35 = torch.ops.aten.expand.SymInt(flip_default_35, [2, 256, 1, 257]);  flip_default_35 = None
        eq_scalar_35 = torch.ops.aten.eq.Scalar(expand_sym_int_35, 1);  expand_sym_int_35 = None
        masked_fill__scalar_35 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_773, eq_scalar_35, -inf);  slice_tensor_773 = eq_scalar_35 = None
        add__tensor_8 = torch.ops.aten.add_.Tensor(transpose_int_125, transpose_int_128);  transpose_int_125 = transpose_int_128 = None
        _softmax_default_8 = torch.ops.aten._softmax.default(add__tensor_8, -1, False);  add__tensor_8 = None
        slice_tensor_774 = torch.ops.aten.slice.Tensor(primals_195, 0, 0, 9223372036854775807)
        slice_tensor_775 = torch.ops.aten.slice.Tensor(slice_tensor_774, 1, 0, 9223372036854775807);  slice_tensor_774 = None
        unsqueeze_default_122 = torch.ops.aten.unsqueeze.default(slice_tensor_775, 2);  slice_tensor_775 = None
        unsqueeze_default_123 = torch.ops.aten.unsqueeze.default(unsqueeze_default_122, 3);  unsqueeze_default_122 = None
        where_scalar_self_17 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_123, 0.0, _softmax_default_8)
        view_default_240 = torch.ops.aten.view.default(add_tensor_50, [1024, 2, 12, 64]);  add_tensor_50 = None
        transpose_int_129 = torch.ops.aten.transpose.int(view_default_240, 0, 1);  view_default_240 = None
        transpose_int_130 = torch.ops.aten.transpose.int(where_scalar_self_17, 1, 2);  where_scalar_self_17 = None
        clone_default_77 = torch.ops.aten.clone.default(transpose_int_130, memory_format = torch.contiguous_format);  transpose_int_130 = None
        _unsafe_view_default_112 = torch.ops.aten._unsafe_view.default(clone_default_77, [24, 4, 256, 513]);  clone_default_77 = None
        transpose_int_131 = torch.ops.aten.transpose.int(transpose_int_129, 1, 2);  transpose_int_129 = None
        view_default_241 = torch.ops.aten.view.default(transpose_int_131, [24, 1024, 64]);  transpose_int_131 = None
        constant_pad_nd_default_34 = torch.ops.aten.constant_pad_nd.default(view_default_241, [0, 0, 256, 256], -1.0);  view_default_241 = None
        as_strided_default_44 = torch.ops.aten.as_strided.default(constant_pad_nd_default_34, [24, 4, 768, 64], [98304, 16384, 64, 1]);  constant_pad_nd_default_34 = None
        constant_pad_nd_default_35 = torch.ops.aten.constant_pad_nd.default(_unsafe_view_default_112, [0, 257], 0.0);  _unsafe_view_default_112 = None
        view_default_242 = torch.ops.aten.view.default(constant_pad_nd_default_35, [24, 4, -1]);  constant_pad_nd_default_35 = None
        slice_tensor_776 = torch.ops.aten.slice.Tensor(view_default_242, 0, 0, 9223372036854775807);  view_default_242 = None
        slice_tensor_777 = torch.ops.aten.slice.Tensor(slice_tensor_776, 1, 0, 9223372036854775807);  slice_tensor_776 = None
        slice_tensor_778 = torch.ops.aten.slice.Tensor(slice_tensor_777, 2, 0, -256);  slice_tensor_777 = None
        view_default_243 = torch.ops.aten.view.default(slice_tensor_778, [24, 4, 256, 769]);  slice_tensor_778 = None
        slice_tensor_779 = torch.ops.aten.slice.Tensor(view_default_243, 0, 0, 9223372036854775807);  view_default_243 = None
        slice_tensor_780 = torch.ops.aten.slice.Tensor(slice_tensor_779, 1, 0, 9223372036854775807);  slice_tensor_779 = None
        slice_tensor_781 = torch.ops.aten.slice.Tensor(slice_tensor_780, 2, 0, 9223372036854775807);  slice_tensor_780 = None
        slice_tensor_782 = torch.ops.aten.slice.Tensor(slice_tensor_781, 3, 0, -1);  slice_tensor_781 = None
        unsqueeze_default_124 = torch.ops.aten.unsqueeze.default(slice_tensor_782, -1);  slice_tensor_782 = None
        permute_default_103 = torch.ops.aten.permute.default(unsqueeze_default_124, [0, 1, 2, 4, 3]);  unsqueeze_default_124 = None
        unsqueeze_default_125 = torch.ops.aten.unsqueeze.default(as_strided_default_44, -1);  as_strided_default_44 = None
        permute_default_104 = torch.ops.aten.permute.default(unsqueeze_default_125, [0, 1, 4, 3, 2]);  unsqueeze_default_125 = None
        permute_default_105 = torch.ops.aten.permute.default(permute_default_103, [0, 1, 2, 4, 3]);  permute_default_103 = None
        view_default_244 = torch.ops.aten.view.default(permute_default_105, [96, 256, 768]);  permute_default_105 = None
        permute_default_106 = torch.ops.aten.permute.default(permute_default_104, [0, 1, 4, 3, 2]);  permute_default_104 = None
        clone_default_78 = torch.ops.aten.clone.default(permute_default_106, memory_format = torch.contiguous_format);  permute_default_106 = None
        _unsafe_view_default_113 = torch.ops.aten._unsafe_view.default(clone_default_78, [96, 768, 64]);  clone_default_78 = None
        bmm_default_17 = torch.ops.aten.bmm.default(view_default_244, _unsafe_view_default_113)
        view_default_245 = torch.ops.aten.view.default(bmm_default_17, [24, 4, 256, 1, 64]);  bmm_default_17 = None
        permute_default_107 = torch.ops.aten.permute.default(view_default_245, [0, 1, 2, 4, 3]);  view_default_245 = None
        view_default_246 = torch.ops.aten.view.default(permute_default_107, [24, 4, 256, 64]);  permute_default_107 = None
        view_default_247 = torch.ops.aten.view.default(view_default_246, [2, 12, 1024, 64]);  view_default_246 = None
        transpose_int_132 = torch.ops.aten.transpose.int(view_default_247, 1, 2);  view_default_247 = None
        transpose_int_133 = torch.ops.aten.transpose.int(transpose_int_132, 0, 1);  transpose_int_132 = None
        clone_default_79 = torch.ops.aten.clone.default(transpose_int_133, memory_format = torch.contiguous_format);  transpose_int_133 = None
        _unsafe_view_default_114 = torch.ops.aten._unsafe_view.default(clone_default_79, [1024, 2, 768]);  clone_default_79 = None
        transpose_int_134 = torch.ops.aten.transpose.int(_unsafe_view_default_114, 0, 1);  _unsafe_view_default_114 = None
        t_default_51 = torch.ops.aten.t.default(primals_164);  primals_164 = None
        clone_default_80 = torch.ops.aten.clone.default(transpose_int_134, memory_format = torch.contiguous_format);  transpose_int_134 = None
        _unsafe_view_default_115 = torch.ops.aten._unsafe_view.default(clone_default_80, [2048, 768]);  clone_default_80 = None
        mm_default_35 = torch.ops.aten.mm.default(_unsafe_view_default_115, t_default_51)
        _unsafe_view_default_116 = torch.ops.aten._unsafe_view.default(mm_default_35, [2, 1024, 768]);  mm_default_35 = None
        add_tensor_51 = torch.ops.aten.add.Tensor(_unsafe_view_default_116, primals_163);  _unsafe_view_default_116 = primals_163 = None
        add_tensor_52 = torch.ops.aten.add.Tensor(add_tensor_51, getitem_45);  add_tensor_51 = getitem_45 = None
        native_layer_norm_default_16 = torch.ops.aten.native_layer_norm.default(add_tensor_52, [768], primals_162, primals_161, 1e-05)
        getitem_48 = native_layer_norm_default_16[0]
        getitem_49 = native_layer_norm_default_16[1]
        getitem_50 = native_layer_norm_default_16[2];  native_layer_norm_default_16 = None
        view_default_248 = torch.ops.aten.view.default(getitem_48, [2048, 768])
        t_default_52 = torch.ops.aten.t.default(primals_172);  primals_172 = None
        addmm_default_16 = torch.ops.aten.addmm.default(primals_171, view_default_248, t_default_52);  primals_171 = None
        view_default_249 = torch.ops.aten.view.default(addmm_default_16, [2, 1024, 3072]);  addmm_default_16 = None
        gelu_default_8 = torch.ops.aten.gelu.default(view_default_249)
        view_default_250 = torch.ops.aten.view.default(gelu_default_8, [2048, 3072]);  gelu_default_8 = None
        t_default_53 = torch.ops.aten.t.default(primals_176);  primals_176 = None
        addmm_default_17 = torch.ops.aten.addmm.default(primals_175, view_default_250, t_default_53);  primals_175 = None
        view_default_251 = torch.ops.aten.view.default(addmm_default_17, [2, 1024, 768]);  addmm_default_17 = None
        add_tensor_53 = torch.ops.aten.add.Tensor(view_default_251, getitem_48);  view_default_251 = getitem_48 = None
        native_layer_norm_default_17 = torch.ops.aten.native_layer_norm.default(add_tensor_53, [768], primals_174, primals_173, 1e-05)
        getitem_51 = native_layer_norm_default_17[0]
        getitem_52 = native_layer_norm_default_17[1]
        getitem_53 = native_layer_norm_default_17[2];  native_layer_norm_default_17 = None
        transpose_int_135 = torch.ops.aten.transpose.int(getitem_51, 0, 1)
        t_default_54 = torch.ops.aten.t.default(primals_184);  primals_184 = None
        clone_default_81 = torch.ops.aten.clone.default(transpose_int_135, memory_format = torch.contiguous_format)
        _unsafe_view_default_117 = torch.ops.aten._unsafe_view.default(clone_default_81, [2048, 768]);  clone_default_81 = None
        mm_default_36 = torch.ops.aten.mm.default(_unsafe_view_default_117, t_default_54)
        _unsafe_view_default_118 = torch.ops.aten._unsafe_view.default(mm_default_36, [1024, 2, 768]);  mm_default_36 = None
        add_tensor_54 = torch.ops.aten.add.Tensor(_unsafe_view_default_118, primals_183);  _unsafe_view_default_118 = primals_183 = None
        t_default_55 = torch.ops.aten.t.default(primals_182);  primals_182 = None
        clone_default_82 = torch.ops.aten.clone.default(transpose_int_135, memory_format = torch.contiguous_format)
        _unsafe_view_default_119 = torch.ops.aten._unsafe_view.default(clone_default_82, [2048, 768]);  clone_default_82 = None
        mm_default_37 = torch.ops.aten.mm.default(_unsafe_view_default_119, t_default_55)
        _unsafe_view_default_120 = torch.ops.aten._unsafe_view.default(mm_default_37, [1024, 2, 768]);  mm_default_37 = None
        add_tensor_55 = torch.ops.aten.add.Tensor(_unsafe_view_default_120, primals_181);  _unsafe_view_default_120 = primals_181 = None
        t_default_56 = torch.ops.aten.t.default(primals_186);  primals_186 = None
        clone_default_83 = torch.ops.aten.clone.default(transpose_int_135, memory_format = torch.contiguous_format);  transpose_int_135 = None
        _unsafe_view_default_121 = torch.ops.aten._unsafe_view.default(clone_default_83, [2048, 768]);  clone_default_83 = None
        mm_default_38 = torch.ops.aten.mm.default(_unsafe_view_default_121, t_default_56)
        _unsafe_view_default_122 = torch.ops.aten._unsafe_view.default(mm_default_38, [1024, 2, 768]);  mm_default_38 = None
        add_tensor_56 = torch.ops.aten.add.Tensor(_unsafe_view_default_122, primals_185);  _unsafe_view_default_122 = primals_185 = None
        div__tensor_9 = torch.ops.aten.div_.Tensor(add_tensor_54, 8.0);  add_tensor_54 = None
        view_default_252 = torch.ops.aten.view.default(div__tensor_9, [1024, 2, 12, 64]);  div__tensor_9 = None
        transpose_int_136 = torch.ops.aten.transpose.int(view_default_252, 0, 1);  view_default_252 = None
        view_default_253 = torch.ops.aten.view.default(add_tensor_55, [1024, 2, 12, 64]);  add_tensor_55 = None
        transpose_int_137 = torch.ops.aten.transpose.int(view_default_253, 0, 1);  view_default_253 = None
        transpose_int_138 = torch.ops.aten.transpose.int(transpose_int_136, 1, 2);  transpose_int_136 = None
        view_default_254 = torch.ops.aten.view.default(transpose_int_138, [24, 1024, 64]);  transpose_int_138 = None
        transpose_int_139 = torch.ops.aten.transpose.int(transpose_int_137, 1, 2);  transpose_int_137 = None
        view_default_255 = torch.ops.aten.view.default(transpose_int_139, [24, 1024, 64]);  transpose_int_139 = None
        view_default_256 = torch.ops.aten.view.default(view_default_254, [24, 2, 512, 64]);  view_default_254 = None
        as_strided_default_45 = torch.ops.aten.as_strided.default(view_default_256, [24, 3, 512, 64], [64, 393216, 1536, 1]);  view_default_256 = None
        view_default_257 = torch.ops.aten.view.default(view_default_255, [24, 2, 512, 64]);  view_default_255 = None
        as_strided_default_46 = torch.ops.aten.as_strided.default(view_default_257, [24, 3, 512, 64], [64, 393216, 1536, 1]);  view_default_257 = None
        unsqueeze_default_126 = torch.ops.aten.unsqueeze.default(as_strided_default_45, -1);  as_strided_default_45 = None
        permute_default_108 = torch.ops.aten.permute.default(unsqueeze_default_126, [0, 1, 2, 4, 3]);  unsqueeze_default_126 = None
        unsqueeze_default_127 = torch.ops.aten.unsqueeze.default(as_strided_default_46, -1);  as_strided_default_46 = None
        permute_default_109 = torch.ops.aten.permute.default(unsqueeze_default_127, [0, 1, 4, 2, 3]);  unsqueeze_default_127 = None
        permute_default_110 = torch.ops.aten.permute.default(permute_default_108, [0, 1, 2, 4, 3]);  permute_default_108 = None
        clone_default_84 = torch.ops.aten.clone.default(permute_default_110, memory_format = torch.contiguous_format);  permute_default_110 = None
        _unsafe_view_default_123 = torch.ops.aten._unsafe_view.default(clone_default_84, [72, 512, 64]);  clone_default_84 = None
        permute_default_111 = torch.ops.aten.permute.default(permute_default_109, [0, 1, 4, 3, 2]);  permute_default_109 = None
        clone_default_85 = torch.ops.aten.clone.default(permute_default_111, memory_format = torch.contiguous_format);  permute_default_111 = None
        _unsafe_view_default_124 = torch.ops.aten._unsafe_view.default(clone_default_85, [72, 64, 512]);  clone_default_85 = None
        bmm_default_18 = torch.ops.aten.bmm.default(_unsafe_view_default_123, _unsafe_view_default_124)
        view_default_258 = torch.ops.aten.view.default(bmm_default_18, [24, 3, 512, 1, 512]);  bmm_default_18 = None
        permute_default_112 = torch.ops.aten.permute.default(view_default_258, [0, 1, 2, 4, 3]);  view_default_258 = None
        view_default_259 = torch.ops.aten.view.default(permute_default_112, [24, 3, 512, 512]);  permute_default_112 = None
        constant_pad_nd_default_36 = torch.ops.aten.constant_pad_nd.default(view_default_259, [0, 0, 0, 1], 0.0);  view_default_259 = None
        view_default_260 = torch.ops.aten.view.default(constant_pad_nd_default_36, [24, 3, 512, 513]);  constant_pad_nd_default_36 = None
        new_empty_default_45 = torch.ops.aten.new_empty.default(view_default_260, [24, 4, 256, 513], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        slice_tensor_783 = torch.ops.aten.slice.Tensor(view_default_260, 0, 0, 9223372036854775807)
        slice_tensor_784 = torch.ops.aten.slice.Tensor(slice_tensor_783, 1, 0, 9223372036854775807);  slice_tensor_783 = None
        slice_tensor_785 = torch.ops.aten.slice.Tensor(slice_tensor_784, 2, 0, 256);  slice_tensor_784 = None
        slice_tensor_786 = torch.ops.aten.slice.Tensor(slice_tensor_785, 3, 0, 257);  slice_tensor_785 = None
        slice_tensor_787 = torch.ops.aten.slice.Tensor(new_empty_default_45, 0, 0, 9223372036854775807)
        slice_tensor_788 = torch.ops.aten.slice.Tensor(slice_tensor_787, 1, 0, -1);  slice_tensor_787 = None
        slice_tensor_789 = torch.ops.aten.slice.Tensor(slice_tensor_788, 2, 0, 9223372036854775807);  slice_tensor_788 = None
        slice_tensor_790 = torch.ops.aten.slice.Tensor(slice_tensor_789, 3, 256, 9223372036854775807);  slice_tensor_789 = None
        copy__default_72 = torch.ops.aten.copy_.default(slice_tensor_790, slice_tensor_786);  slice_tensor_790 = slice_tensor_786 = None
        slice_tensor_791 = torch.ops.aten.slice.Tensor(view_default_260, 0, 0, 9223372036854775807)
        select_int_72 = torch.ops.aten.select.int(slice_tensor_791, 1, -1);  slice_tensor_791 = None
        slice_tensor_792 = torch.ops.aten.slice.Tensor(select_int_72, 1, 256, 9223372036854775807);  select_int_72 = None
        slice_tensor_793 = torch.ops.aten.slice.Tensor(slice_tensor_792, 2, 0, 257);  slice_tensor_792 = None
        slice_tensor_794 = torch.ops.aten.slice.Tensor(new_empty_default_45, 0, 0, 9223372036854775807)
        select_int_73 = torch.ops.aten.select.int(slice_tensor_794, 1, -1);  slice_tensor_794 = None
        slice_tensor_795 = torch.ops.aten.slice.Tensor(select_int_73, 1, 0, 9223372036854775807);  select_int_73 = None
        slice_tensor_796 = torch.ops.aten.slice.Tensor(slice_tensor_795, 2, 256, 9223372036854775807);  slice_tensor_795 = None
        copy__default_73 = torch.ops.aten.copy_.default(slice_tensor_796, slice_tensor_793);  slice_tensor_796 = slice_tensor_793 = None
        slice_tensor_797 = torch.ops.aten.slice.Tensor(view_default_260, 0, 0, 9223372036854775807)
        slice_tensor_798 = torch.ops.aten.slice.Tensor(slice_tensor_797, 1, 0, 9223372036854775807);  slice_tensor_797 = None
        slice_tensor_799 = torch.ops.aten.slice.Tensor(slice_tensor_798, 2, -257, -1);  slice_tensor_798 = None
        slice_tensor_800 = torch.ops.aten.slice.Tensor(slice_tensor_799, 3, 257, 9223372036854775807);  slice_tensor_799 = None
        slice_tensor_801 = torch.ops.aten.slice.Tensor(new_empty_default_45, 0, 0, 9223372036854775807)
        slice_tensor_802 = torch.ops.aten.slice.Tensor(slice_tensor_801, 1, 1, 9223372036854775807);  slice_tensor_801 = None
        slice_tensor_803 = torch.ops.aten.slice.Tensor(slice_tensor_802, 2, 0, 9223372036854775807);  slice_tensor_802 = None
        slice_tensor_804 = torch.ops.aten.slice.Tensor(slice_tensor_803, 3, 0, 256);  slice_tensor_803 = None
        copy__default_74 = torch.ops.aten.copy_.default(slice_tensor_804, slice_tensor_800);  slice_tensor_804 = slice_tensor_800 = None
        slice_tensor_805 = torch.ops.aten.slice.Tensor(view_default_260, 0, 0, 9223372036854775807);  view_default_260 = None
        select_int_74 = torch.ops.aten.select.int(slice_tensor_805, 1, 0);  slice_tensor_805 = None
        slice_tensor_806 = torch.ops.aten.slice.Tensor(select_int_74, 1, 0, 255);  select_int_74 = None
        slice_tensor_807 = torch.ops.aten.slice.Tensor(slice_tensor_806, 2, -255, 9223372036854775807);  slice_tensor_806 = None
        slice_tensor_808 = torch.ops.aten.slice.Tensor(new_empty_default_45, 0, 0, 9223372036854775807)
        select_int_75 = torch.ops.aten.select.int(slice_tensor_808, 1, 0);  slice_tensor_808 = None
        slice_tensor_809 = torch.ops.aten.slice.Tensor(select_int_75, 1, 1, 256);  select_int_75 = None
        slice_tensor_810 = torch.ops.aten.slice.Tensor(slice_tensor_809, 2, 1, 256);  slice_tensor_809 = None
        copy__default_75 = torch.ops.aten.copy_.default(slice_tensor_810, slice_tensor_807);  slice_tensor_810 = slice_tensor_807 = None
        view_default_261 = torch.ops.aten.view.default(new_empty_default_45, [2, 12, 1024, 513]);  new_empty_default_45 = None
        transpose_int_140 = torch.ops.aten.transpose.int(view_default_261, 2, 1);  view_default_261 = None
        new_empty_default_46 = torch.ops.aten.new_empty.default(transpose_int_140, [256, 257], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        fill__scalar_27 = torch.ops.aten.fill_.Scalar(new_empty_default_46, 1.0);  new_empty_default_46 = None
        tril_default_18 = torch.ops.aten.tril.default(fill__scalar_27);  fill__scalar_27 = None
        flip_default_36 = torch.ops.aten.flip.default(tril_default_18, [0]);  tril_default_18 = None
        unsqueeze_default_128 = torch.ops.aten.unsqueeze.default(flip_default_36, 0);  flip_default_36 = None
        slice_tensor_811 = torch.ops.aten.slice.Tensor(unsqueeze_default_128, 1, 0, 9223372036854775807);  unsqueeze_default_128 = None
        unsqueeze_default_129 = torch.ops.aten.unsqueeze.default(slice_tensor_811, 2);  slice_tensor_811 = None
        slice_tensor_812 = torch.ops.aten.slice.Tensor(unsqueeze_default_129, 3, 0, 9223372036854775807);  unsqueeze_default_129 = None
        flip_default_37 = torch.ops.aten.flip.default(slice_tensor_812, [1, 3])
        slice_tensor_813 = torch.ops.aten.slice.Tensor(transpose_int_140, 0, 0, 9223372036854775807)
        slice_tensor_814 = torch.ops.aten.slice.Tensor(slice_tensor_813, 1, 0, 256);  slice_tensor_813 = None
        slice_tensor_815 = torch.ops.aten.slice.Tensor(slice_tensor_814, 2, 0, 9223372036854775807);  slice_tensor_814 = None
        slice_tensor_816 = torch.ops.aten.slice.Tensor(slice_tensor_815, 3, 0, 257);  slice_tensor_815 = None
        expand_sym_int_36 = torch.ops.aten.expand.SymInt(slice_tensor_812, [2, 256, 12, 257]);  slice_tensor_812 = None
        eq_scalar_36 = torch.ops.aten.eq.Scalar(expand_sym_int_36, 1);  expand_sym_int_36 = None
        masked_fill__scalar_36 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_816, eq_scalar_36, -inf);  slice_tensor_816 = None
        slice_tensor_817 = torch.ops.aten.slice.Tensor(transpose_int_140, 0, 0, 9223372036854775807)
        slice_tensor_818 = torch.ops.aten.slice.Tensor(slice_tensor_817, 1, -256, 9223372036854775807);  slice_tensor_817 = None
        slice_tensor_819 = torch.ops.aten.slice.Tensor(slice_tensor_818, 2, 0, 9223372036854775807);  slice_tensor_818 = None
        slice_tensor_820 = torch.ops.aten.slice.Tensor(slice_tensor_819, 3, -257, 9223372036854775807);  slice_tensor_819 = None
        expand_sym_int_37 = torch.ops.aten.expand.SymInt(flip_default_37, [2, 256, 12, 257]);  flip_default_37 = None
        eq_scalar_37 = torch.ops.aten.eq.Scalar(expand_sym_int_37, 1);  expand_sym_int_37 = None
        masked_fill__scalar_37 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_820, eq_scalar_37, -inf);  slice_tensor_820 = None
        ne_scalar_9 = torch.ops.aten.ne.Scalar(primals_194, 0)
        slice_tensor_821 = torch.ops.aten.slice.Tensor(ne_scalar_9, 0, 0, 9223372036854775807);  ne_scalar_9 = None
        slice_tensor_822 = torch.ops.aten.slice.Tensor(slice_tensor_821, 1, 0, 9223372036854775807);  slice_tensor_821 = None
        unsqueeze_default_130 = torch.ops.aten.unsqueeze.default(slice_tensor_822, 2);  slice_tensor_822 = None
        unsqueeze_default_131 = torch.ops.aten.unsqueeze.default(unsqueeze_default_130, 3);  unsqueeze_default_130 = None
        _to_copy_default_9 = torch.ops.aten._to_copy.default(unsqueeze_default_131, device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided)
        where_scalar_self_18 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_131, -10000.0, _to_copy_default_9);  unsqueeze_default_131 = _to_copy_default_9 = None
        new_empty_default_47 = torch.ops.aten.new_empty.default(where_scalar_self_18, [2, 1024, 1, 1], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        fill__scalar_28 = torch.ops.aten.fill_.Scalar(new_empty_default_47, 1.0);  new_empty_default_47 = None
        transpose_int_141 = torch.ops.aten.transpose.int(fill__scalar_28, 1, 2);  fill__scalar_28 = None
        view_default_262 = torch.ops.aten.view.default(transpose_int_141, [2, 1024, 1]);  transpose_int_141 = None
        transpose_int_142 = torch.ops.aten.transpose.int(where_scalar_self_18, 1, 2);  where_scalar_self_18 = None
        view_default_263 = torch.ops.aten.view.default(transpose_int_142, [2, 1024, 1]);  transpose_int_142 = None
        view_default_264 = torch.ops.aten.view.default(view_default_262, [2, 2, 512, 1]);  view_default_262 = None
        as_strided_default_47 = torch.ops.aten.as_strided.default(view_default_264, [2, 3, 512, 1], [1024, 256, 1, 1]);  view_default_264 = None
        view_default_265 = torch.ops.aten.view.default(view_default_263, [2, 2, 512, 1]);  view_default_263 = None
        as_strided_default_48 = torch.ops.aten.as_strided.default(view_default_265, [2, 3, 512, 1], [1024, 256, 1, 1]);  view_default_265 = None
        unsqueeze_default_132 = torch.ops.aten.unsqueeze.default(as_strided_default_47, -1);  as_strided_default_47 = None
        permute_default_113 = torch.ops.aten.permute.default(unsqueeze_default_132, [0, 1, 2, 4, 3]);  unsqueeze_default_132 = None
        unsqueeze_default_133 = torch.ops.aten.unsqueeze.default(as_strided_default_48, -1);  as_strided_default_48 = None
        permute_default_114 = torch.ops.aten.permute.default(unsqueeze_default_133, [0, 1, 4, 2, 3]);  unsqueeze_default_133 = None
        squeeze_dim_18 = torch.ops.aten.squeeze.dim(permute_default_113, 4);  permute_default_113 = None
        squeeze_dim_19 = torch.ops.aten.squeeze.dim(permute_default_114, 4);  permute_default_114 = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(squeeze_dim_18, squeeze_dim_19);  squeeze_dim_18 = squeeze_dim_19 = None
        constant_pad_nd_default_37 = torch.ops.aten.constant_pad_nd.default(mul_tensor_9, [0, 0, 0, 1], 0.0);  mul_tensor_9 = None
        view_default_266 = torch.ops.aten.view.default(constant_pad_nd_default_37, [2, 3, 512, 513]);  constant_pad_nd_default_37 = None
        new_empty_default_48 = torch.ops.aten.new_empty.default(view_default_266, [2, 4, 256, 513], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        slice_tensor_823 = torch.ops.aten.slice.Tensor(view_default_266, 0, 0, 9223372036854775807)
        slice_tensor_824 = torch.ops.aten.slice.Tensor(slice_tensor_823, 1, 0, 9223372036854775807);  slice_tensor_823 = None
        slice_tensor_825 = torch.ops.aten.slice.Tensor(slice_tensor_824, 2, 0, 256);  slice_tensor_824 = None
        slice_tensor_826 = torch.ops.aten.slice.Tensor(slice_tensor_825, 3, 0, 257);  slice_tensor_825 = None
        slice_tensor_827 = torch.ops.aten.slice.Tensor(new_empty_default_48, 0, 0, 9223372036854775807)
        slice_tensor_828 = torch.ops.aten.slice.Tensor(slice_tensor_827, 1, 0, -1);  slice_tensor_827 = None
        slice_tensor_829 = torch.ops.aten.slice.Tensor(slice_tensor_828, 2, 0, 9223372036854775807);  slice_tensor_828 = None
        slice_tensor_830 = torch.ops.aten.slice.Tensor(slice_tensor_829, 3, 256, 9223372036854775807);  slice_tensor_829 = None
        copy__default_76 = torch.ops.aten.copy_.default(slice_tensor_830, slice_tensor_826);  slice_tensor_830 = slice_tensor_826 = None
        slice_tensor_831 = torch.ops.aten.slice.Tensor(view_default_266, 0, 0, 9223372036854775807)
        select_int_76 = torch.ops.aten.select.int(slice_tensor_831, 1, -1);  slice_tensor_831 = None
        slice_tensor_832 = torch.ops.aten.slice.Tensor(select_int_76, 1, 256, 9223372036854775807);  select_int_76 = None
        slice_tensor_833 = torch.ops.aten.slice.Tensor(slice_tensor_832, 2, 0, 257);  slice_tensor_832 = None
        slice_tensor_834 = torch.ops.aten.slice.Tensor(new_empty_default_48, 0, 0, 9223372036854775807)
        select_int_77 = torch.ops.aten.select.int(slice_tensor_834, 1, -1);  slice_tensor_834 = None
        slice_tensor_835 = torch.ops.aten.slice.Tensor(select_int_77, 1, 0, 9223372036854775807);  select_int_77 = None
        slice_tensor_836 = torch.ops.aten.slice.Tensor(slice_tensor_835, 2, 256, 9223372036854775807);  slice_tensor_835 = None
        copy__default_77 = torch.ops.aten.copy_.default(slice_tensor_836, slice_tensor_833);  slice_tensor_836 = slice_tensor_833 = None
        slice_tensor_837 = torch.ops.aten.slice.Tensor(view_default_266, 0, 0, 9223372036854775807)
        slice_tensor_838 = torch.ops.aten.slice.Tensor(slice_tensor_837, 1, 0, 9223372036854775807);  slice_tensor_837 = None
        slice_tensor_839 = torch.ops.aten.slice.Tensor(slice_tensor_838, 2, -257, -1);  slice_tensor_838 = None
        slice_tensor_840 = torch.ops.aten.slice.Tensor(slice_tensor_839, 3, 257, 9223372036854775807);  slice_tensor_839 = None
        slice_tensor_841 = torch.ops.aten.slice.Tensor(new_empty_default_48, 0, 0, 9223372036854775807)
        slice_tensor_842 = torch.ops.aten.slice.Tensor(slice_tensor_841, 1, 1, 9223372036854775807);  slice_tensor_841 = None
        slice_tensor_843 = torch.ops.aten.slice.Tensor(slice_tensor_842, 2, 0, 9223372036854775807);  slice_tensor_842 = None
        slice_tensor_844 = torch.ops.aten.slice.Tensor(slice_tensor_843, 3, 0, 256);  slice_tensor_843 = None
        copy__default_78 = torch.ops.aten.copy_.default(slice_tensor_844, slice_tensor_840);  slice_tensor_844 = slice_tensor_840 = None
        slice_tensor_845 = torch.ops.aten.slice.Tensor(view_default_266, 0, 0, 9223372036854775807);  view_default_266 = None
        select_int_78 = torch.ops.aten.select.int(slice_tensor_845, 1, 0);  slice_tensor_845 = None
        slice_tensor_846 = torch.ops.aten.slice.Tensor(select_int_78, 1, 0, 255);  select_int_78 = None
        slice_tensor_847 = torch.ops.aten.slice.Tensor(slice_tensor_846, 2, -255, 9223372036854775807);  slice_tensor_846 = None
        slice_tensor_848 = torch.ops.aten.slice.Tensor(new_empty_default_48, 0, 0, 9223372036854775807)
        select_int_79 = torch.ops.aten.select.int(slice_tensor_848, 1, 0);  slice_tensor_848 = None
        slice_tensor_849 = torch.ops.aten.slice.Tensor(select_int_79, 1, 1, 256);  select_int_79 = None
        slice_tensor_850 = torch.ops.aten.slice.Tensor(slice_tensor_849, 2, 1, 256);  slice_tensor_849 = None
        copy__default_79 = torch.ops.aten.copy_.default(slice_tensor_850, slice_tensor_847);  slice_tensor_850 = slice_tensor_847 = None
        view_default_267 = torch.ops.aten.view.default(new_empty_default_48, [2, 1, 1024, 513]);  new_empty_default_48 = None
        transpose_int_143 = torch.ops.aten.transpose.int(view_default_267, 2, 1);  view_default_267 = None
        new_empty_default_49 = torch.ops.aten.new_empty.default(transpose_int_143, [256, 257], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        fill__scalar_29 = torch.ops.aten.fill_.Scalar(new_empty_default_49, 1.0);  new_empty_default_49 = None
        tril_default_19 = torch.ops.aten.tril.default(fill__scalar_29);  fill__scalar_29 = None
        flip_default_38 = torch.ops.aten.flip.default(tril_default_19, [0]);  tril_default_19 = None
        unsqueeze_default_134 = torch.ops.aten.unsqueeze.default(flip_default_38, 0);  flip_default_38 = None
        slice_tensor_851 = torch.ops.aten.slice.Tensor(unsqueeze_default_134, 1, 0, 9223372036854775807);  unsqueeze_default_134 = None
        unsqueeze_default_135 = torch.ops.aten.unsqueeze.default(slice_tensor_851, 2);  slice_tensor_851 = None
        slice_tensor_852 = torch.ops.aten.slice.Tensor(unsqueeze_default_135, 3, 0, 9223372036854775807);  unsqueeze_default_135 = None
        flip_default_39 = torch.ops.aten.flip.default(slice_tensor_852, [1, 3])
        slice_tensor_853 = torch.ops.aten.slice.Tensor(transpose_int_143, 0, 0, 9223372036854775807)
        slice_tensor_854 = torch.ops.aten.slice.Tensor(slice_tensor_853, 1, 0, 256);  slice_tensor_853 = None
        slice_tensor_855 = torch.ops.aten.slice.Tensor(slice_tensor_854, 2, 0, 9223372036854775807);  slice_tensor_854 = None
        slice_tensor_856 = torch.ops.aten.slice.Tensor(slice_tensor_855, 3, 0, 257);  slice_tensor_855 = None
        expand_sym_int_38 = torch.ops.aten.expand.SymInt(slice_tensor_852, [2, 256, 1, 257]);  slice_tensor_852 = None
        eq_scalar_38 = torch.ops.aten.eq.Scalar(expand_sym_int_38, 1);  expand_sym_int_38 = None
        masked_fill__scalar_38 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_856, eq_scalar_38, -inf);  slice_tensor_856 = eq_scalar_38 = None
        slice_tensor_857 = torch.ops.aten.slice.Tensor(transpose_int_143, 0, 0, 9223372036854775807)
        slice_tensor_858 = torch.ops.aten.slice.Tensor(slice_tensor_857, 1, -256, 9223372036854775807);  slice_tensor_857 = None
        slice_tensor_859 = torch.ops.aten.slice.Tensor(slice_tensor_858, 2, 0, 9223372036854775807);  slice_tensor_858 = None
        slice_tensor_860 = torch.ops.aten.slice.Tensor(slice_tensor_859, 3, -257, 9223372036854775807);  slice_tensor_859 = None
        expand_sym_int_39 = torch.ops.aten.expand.SymInt(flip_default_39, [2, 256, 1, 257]);  flip_default_39 = None
        eq_scalar_39 = torch.ops.aten.eq.Scalar(expand_sym_int_39, 1);  expand_sym_int_39 = None
        masked_fill__scalar_39 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_860, eq_scalar_39, -inf);  slice_tensor_860 = eq_scalar_39 = None
        add__tensor_9 = torch.ops.aten.add_.Tensor(transpose_int_140, transpose_int_143);  transpose_int_140 = transpose_int_143 = None
        _softmax_default_9 = torch.ops.aten._softmax.default(add__tensor_9, -1, False);  add__tensor_9 = None
        slice_tensor_861 = torch.ops.aten.slice.Tensor(primals_195, 0, 0, 9223372036854775807)
        slice_tensor_862 = torch.ops.aten.slice.Tensor(slice_tensor_861, 1, 0, 9223372036854775807);  slice_tensor_861 = None
        unsqueeze_default_136 = torch.ops.aten.unsqueeze.default(slice_tensor_862, 2);  slice_tensor_862 = None
        unsqueeze_default_137 = torch.ops.aten.unsqueeze.default(unsqueeze_default_136, 3);  unsqueeze_default_136 = None
        where_scalar_self_19 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_137, 0.0, _softmax_default_9)
        view_default_268 = torch.ops.aten.view.default(add_tensor_56, [1024, 2, 12, 64]);  add_tensor_56 = None
        transpose_int_144 = torch.ops.aten.transpose.int(view_default_268, 0, 1);  view_default_268 = None
        transpose_int_145 = torch.ops.aten.transpose.int(where_scalar_self_19, 1, 2);  where_scalar_self_19 = None
        clone_default_86 = torch.ops.aten.clone.default(transpose_int_145, memory_format = torch.contiguous_format);  transpose_int_145 = None
        _unsafe_view_default_125 = torch.ops.aten._unsafe_view.default(clone_default_86, [24, 4, 256, 513]);  clone_default_86 = None
        transpose_int_146 = torch.ops.aten.transpose.int(transpose_int_144, 1, 2);  transpose_int_144 = None
        view_default_269 = torch.ops.aten.view.default(transpose_int_146, [24, 1024, 64]);  transpose_int_146 = None
        constant_pad_nd_default_38 = torch.ops.aten.constant_pad_nd.default(view_default_269, [0, 0, 256, 256], -1.0);  view_default_269 = None
        as_strided_default_49 = torch.ops.aten.as_strided.default(constant_pad_nd_default_38, [24, 4, 768, 64], [98304, 16384, 64, 1]);  constant_pad_nd_default_38 = None
        constant_pad_nd_default_39 = torch.ops.aten.constant_pad_nd.default(_unsafe_view_default_125, [0, 257], 0.0);  _unsafe_view_default_125 = None
        view_default_270 = torch.ops.aten.view.default(constant_pad_nd_default_39, [24, 4, -1]);  constant_pad_nd_default_39 = None
        slice_tensor_863 = torch.ops.aten.slice.Tensor(view_default_270, 0, 0, 9223372036854775807);  view_default_270 = None
        slice_tensor_864 = torch.ops.aten.slice.Tensor(slice_tensor_863, 1, 0, 9223372036854775807);  slice_tensor_863 = None
        slice_tensor_865 = torch.ops.aten.slice.Tensor(slice_tensor_864, 2, 0, -256);  slice_tensor_864 = None
        view_default_271 = torch.ops.aten.view.default(slice_tensor_865, [24, 4, 256, 769]);  slice_tensor_865 = None
        slice_tensor_866 = torch.ops.aten.slice.Tensor(view_default_271, 0, 0, 9223372036854775807);  view_default_271 = None
        slice_tensor_867 = torch.ops.aten.slice.Tensor(slice_tensor_866, 1, 0, 9223372036854775807);  slice_tensor_866 = None
        slice_tensor_868 = torch.ops.aten.slice.Tensor(slice_tensor_867, 2, 0, 9223372036854775807);  slice_tensor_867 = None
        slice_tensor_869 = torch.ops.aten.slice.Tensor(slice_tensor_868, 3, 0, -1);  slice_tensor_868 = None
        unsqueeze_default_138 = torch.ops.aten.unsqueeze.default(slice_tensor_869, -1);  slice_tensor_869 = None
        permute_default_115 = torch.ops.aten.permute.default(unsqueeze_default_138, [0, 1, 2, 4, 3]);  unsqueeze_default_138 = None
        unsqueeze_default_139 = torch.ops.aten.unsqueeze.default(as_strided_default_49, -1);  as_strided_default_49 = None
        permute_default_116 = torch.ops.aten.permute.default(unsqueeze_default_139, [0, 1, 4, 3, 2]);  unsqueeze_default_139 = None
        permute_default_117 = torch.ops.aten.permute.default(permute_default_115, [0, 1, 2, 4, 3]);  permute_default_115 = None
        view_default_272 = torch.ops.aten.view.default(permute_default_117, [96, 256, 768]);  permute_default_117 = None
        permute_default_118 = torch.ops.aten.permute.default(permute_default_116, [0, 1, 4, 3, 2]);  permute_default_116 = None
        clone_default_87 = torch.ops.aten.clone.default(permute_default_118, memory_format = torch.contiguous_format);  permute_default_118 = None
        _unsafe_view_default_126 = torch.ops.aten._unsafe_view.default(clone_default_87, [96, 768, 64]);  clone_default_87 = None
        bmm_default_19 = torch.ops.aten.bmm.default(view_default_272, _unsafe_view_default_126)
        view_default_273 = torch.ops.aten.view.default(bmm_default_19, [24, 4, 256, 1, 64]);  bmm_default_19 = None
        permute_default_119 = torch.ops.aten.permute.default(view_default_273, [0, 1, 2, 4, 3]);  view_default_273 = None
        view_default_274 = torch.ops.aten.view.default(permute_default_119, [24, 4, 256, 64]);  permute_default_119 = None
        view_default_275 = torch.ops.aten.view.default(view_default_274, [2, 12, 1024, 64]);  view_default_274 = None
        transpose_int_147 = torch.ops.aten.transpose.int(view_default_275, 1, 2);  view_default_275 = None
        transpose_int_148 = torch.ops.aten.transpose.int(transpose_int_147, 0, 1);  transpose_int_147 = None
        clone_default_88 = torch.ops.aten.clone.default(transpose_int_148, memory_format = torch.contiguous_format);  transpose_int_148 = None
        _unsafe_view_default_127 = torch.ops.aten._unsafe_view.default(clone_default_88, [1024, 2, 768]);  clone_default_88 = None
        transpose_int_149 = torch.ops.aten.transpose.int(_unsafe_view_default_127, 0, 1);  _unsafe_view_default_127 = None
        t_default_57 = torch.ops.aten.t.default(primals_180);  primals_180 = None
        clone_default_89 = torch.ops.aten.clone.default(transpose_int_149, memory_format = torch.contiguous_format);  transpose_int_149 = None
        _unsafe_view_default_128 = torch.ops.aten._unsafe_view.default(clone_default_89, [2048, 768]);  clone_default_89 = None
        mm_default_39 = torch.ops.aten.mm.default(_unsafe_view_default_128, t_default_57)
        _unsafe_view_default_129 = torch.ops.aten._unsafe_view.default(mm_default_39, [2, 1024, 768]);  mm_default_39 = None
        add_tensor_57 = torch.ops.aten.add.Tensor(_unsafe_view_default_129, primals_179);  _unsafe_view_default_129 = primals_179 = None
        add_tensor_58 = torch.ops.aten.add.Tensor(add_tensor_57, getitem_51);  add_tensor_57 = getitem_51 = None
        native_layer_norm_default_18 = torch.ops.aten.native_layer_norm.default(add_tensor_58, [768], primals_178, primals_177, 1e-05)
        getitem_54 = native_layer_norm_default_18[0]
        getitem_55 = native_layer_norm_default_18[1]
        getitem_56 = native_layer_norm_default_18[2];  native_layer_norm_default_18 = None
        view_default_276 = torch.ops.aten.view.default(getitem_54, [2048, 768])
        t_default_58 = torch.ops.aten.t.default(primals_188);  primals_188 = None
        addmm_default_18 = torch.ops.aten.addmm.default(primals_187, view_default_276, t_default_58);  primals_187 = None
        view_default_277 = torch.ops.aten.view.default(addmm_default_18, [2, 1024, 3072]);  addmm_default_18 = None
        gelu_default_9 = torch.ops.aten.gelu.default(view_default_277)
        view_default_278 = torch.ops.aten.view.default(gelu_default_9, [2048, 3072]);  gelu_default_9 = None
        t_default_59 = torch.ops.aten.t.default(primals_192);  primals_192 = None
        addmm_default_19 = torch.ops.aten.addmm.default(primals_191, view_default_278, t_default_59);  primals_191 = None
        view_default_279 = torch.ops.aten.view.default(addmm_default_19, [2, 1024, 768]);  addmm_default_19 = None
        add_tensor_59 = torch.ops.aten.add.Tensor(view_default_279, getitem_54);  view_default_279 = getitem_54 = None
        native_layer_norm_default_19 = torch.ops.aten.native_layer_norm.default(add_tensor_59, [768], primals_190, primals_189, 1e-05)
        getitem_57 = native_layer_norm_default_19[0]
        getitem_58 = native_layer_norm_default_19[1]
        getitem_59 = native_layer_norm_default_19[2];  native_layer_norm_default_19 = None
        transpose_int_150 = torch.ops.aten.transpose.int(getitem_57, 0, 1)
        t_default_60 = torch.ops.aten.t.default(primals_24);  primals_24 = None
        clone_default_90 = torch.ops.aten.clone.default(transpose_int_150, memory_format = torch.contiguous_format)
        _unsafe_view_default_130 = torch.ops.aten._unsafe_view.default(clone_default_90, [2048, 768]);  clone_default_90 = None
        mm_default_40 = torch.ops.aten.mm.default(_unsafe_view_default_130, t_default_60)
        _unsafe_view_default_131 = torch.ops.aten._unsafe_view.default(mm_default_40, [1024, 2, 768]);  mm_default_40 = None
        add_tensor_60 = torch.ops.aten.add.Tensor(_unsafe_view_default_131, primals_23);  _unsafe_view_default_131 = primals_23 = None
        t_default_61 = torch.ops.aten.t.default(primals_22);  primals_22 = None
        clone_default_91 = torch.ops.aten.clone.default(transpose_int_150, memory_format = torch.contiguous_format)
        _unsafe_view_default_132 = torch.ops.aten._unsafe_view.default(clone_default_91, [2048, 768]);  clone_default_91 = None
        mm_default_41 = torch.ops.aten.mm.default(_unsafe_view_default_132, t_default_61)
        _unsafe_view_default_133 = torch.ops.aten._unsafe_view.default(mm_default_41, [1024, 2, 768]);  mm_default_41 = None
        add_tensor_61 = torch.ops.aten.add.Tensor(_unsafe_view_default_133, primals_21);  _unsafe_view_default_133 = primals_21 = None
        t_default_62 = torch.ops.aten.t.default(primals_26);  primals_26 = None
        clone_default_92 = torch.ops.aten.clone.default(transpose_int_150, memory_format = torch.contiguous_format);  transpose_int_150 = None
        _unsafe_view_default_134 = torch.ops.aten._unsafe_view.default(clone_default_92, [2048, 768]);  clone_default_92 = None
        mm_default_42 = torch.ops.aten.mm.default(_unsafe_view_default_134, t_default_62)
        _unsafe_view_default_135 = torch.ops.aten._unsafe_view.default(mm_default_42, [1024, 2, 768]);  mm_default_42 = None
        add_tensor_62 = torch.ops.aten.add.Tensor(_unsafe_view_default_135, primals_25);  _unsafe_view_default_135 = primals_25 = None
        div__tensor_10 = torch.ops.aten.div_.Tensor(add_tensor_60, 8.0);  add_tensor_60 = None
        view_default_280 = torch.ops.aten.view.default(div__tensor_10, [1024, 2, 12, 64]);  div__tensor_10 = None
        transpose_int_151 = torch.ops.aten.transpose.int(view_default_280, 0, 1);  view_default_280 = None
        view_default_281 = torch.ops.aten.view.default(add_tensor_61, [1024, 2, 12, 64]);  add_tensor_61 = None
        transpose_int_152 = torch.ops.aten.transpose.int(view_default_281, 0, 1);  view_default_281 = None
        transpose_int_153 = torch.ops.aten.transpose.int(transpose_int_151, 1, 2);  transpose_int_151 = None
        view_default_282 = torch.ops.aten.view.default(transpose_int_153, [24, 1024, 64]);  transpose_int_153 = None
        transpose_int_154 = torch.ops.aten.transpose.int(transpose_int_152, 1, 2);  transpose_int_152 = None
        view_default_283 = torch.ops.aten.view.default(transpose_int_154, [24, 1024, 64]);  transpose_int_154 = None
        view_default_284 = torch.ops.aten.view.default(view_default_282, [24, 2, 512, 64]);  view_default_282 = None
        as_strided_default_50 = torch.ops.aten.as_strided.default(view_default_284, [24, 3, 512, 64], [64, 393216, 1536, 1]);  view_default_284 = None
        view_default_285 = torch.ops.aten.view.default(view_default_283, [24, 2, 512, 64]);  view_default_283 = None
        as_strided_default_51 = torch.ops.aten.as_strided.default(view_default_285, [24, 3, 512, 64], [64, 393216, 1536, 1]);  view_default_285 = None
        unsqueeze_default_140 = torch.ops.aten.unsqueeze.default(as_strided_default_50, -1);  as_strided_default_50 = None
        permute_default_120 = torch.ops.aten.permute.default(unsqueeze_default_140, [0, 1, 2, 4, 3]);  unsqueeze_default_140 = None
        unsqueeze_default_141 = torch.ops.aten.unsqueeze.default(as_strided_default_51, -1);  as_strided_default_51 = None
        permute_default_121 = torch.ops.aten.permute.default(unsqueeze_default_141, [0, 1, 4, 2, 3]);  unsqueeze_default_141 = None
        permute_default_122 = torch.ops.aten.permute.default(permute_default_120, [0, 1, 2, 4, 3]);  permute_default_120 = None
        clone_default_93 = torch.ops.aten.clone.default(permute_default_122, memory_format = torch.contiguous_format);  permute_default_122 = None
        _unsafe_view_default_136 = torch.ops.aten._unsafe_view.default(clone_default_93, [72, 512, 64]);  clone_default_93 = None
        permute_default_123 = torch.ops.aten.permute.default(permute_default_121, [0, 1, 4, 3, 2]);  permute_default_121 = None
        clone_default_94 = torch.ops.aten.clone.default(permute_default_123, memory_format = torch.contiguous_format);  permute_default_123 = None
        _unsafe_view_default_137 = torch.ops.aten._unsafe_view.default(clone_default_94, [72, 64, 512]);  clone_default_94 = None
        bmm_default_20 = torch.ops.aten.bmm.default(_unsafe_view_default_136, _unsafe_view_default_137)
        view_default_286 = torch.ops.aten.view.default(bmm_default_20, [24, 3, 512, 1, 512]);  bmm_default_20 = None
        permute_default_124 = torch.ops.aten.permute.default(view_default_286, [0, 1, 2, 4, 3]);  view_default_286 = None
        view_default_287 = torch.ops.aten.view.default(permute_default_124, [24, 3, 512, 512]);  permute_default_124 = None
        constant_pad_nd_default_40 = torch.ops.aten.constant_pad_nd.default(view_default_287, [0, 0, 0, 1], 0.0);  view_default_287 = None
        view_default_288 = torch.ops.aten.view.default(constant_pad_nd_default_40, [24, 3, 512, 513]);  constant_pad_nd_default_40 = None
        new_empty_default_50 = torch.ops.aten.new_empty.default(view_default_288, [24, 4, 256, 513], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        slice_tensor_870 = torch.ops.aten.slice.Tensor(view_default_288, 0, 0, 9223372036854775807)
        slice_tensor_871 = torch.ops.aten.slice.Tensor(slice_tensor_870, 1, 0, 9223372036854775807);  slice_tensor_870 = None
        slice_tensor_872 = torch.ops.aten.slice.Tensor(slice_tensor_871, 2, 0, 256);  slice_tensor_871 = None
        slice_tensor_873 = torch.ops.aten.slice.Tensor(slice_tensor_872, 3, 0, 257);  slice_tensor_872 = None
        slice_tensor_874 = torch.ops.aten.slice.Tensor(new_empty_default_50, 0, 0, 9223372036854775807)
        slice_tensor_875 = torch.ops.aten.slice.Tensor(slice_tensor_874, 1, 0, -1);  slice_tensor_874 = None
        slice_tensor_876 = torch.ops.aten.slice.Tensor(slice_tensor_875, 2, 0, 9223372036854775807);  slice_tensor_875 = None
        slice_tensor_877 = torch.ops.aten.slice.Tensor(slice_tensor_876, 3, 256, 9223372036854775807);  slice_tensor_876 = None
        copy__default_80 = torch.ops.aten.copy_.default(slice_tensor_877, slice_tensor_873);  slice_tensor_877 = slice_tensor_873 = None
        slice_tensor_878 = torch.ops.aten.slice.Tensor(view_default_288, 0, 0, 9223372036854775807)
        select_int_80 = torch.ops.aten.select.int(slice_tensor_878, 1, -1);  slice_tensor_878 = None
        slice_tensor_879 = torch.ops.aten.slice.Tensor(select_int_80, 1, 256, 9223372036854775807);  select_int_80 = None
        slice_tensor_880 = torch.ops.aten.slice.Tensor(slice_tensor_879, 2, 0, 257);  slice_tensor_879 = None
        slice_tensor_881 = torch.ops.aten.slice.Tensor(new_empty_default_50, 0, 0, 9223372036854775807)
        select_int_81 = torch.ops.aten.select.int(slice_tensor_881, 1, -1);  slice_tensor_881 = None
        slice_tensor_882 = torch.ops.aten.slice.Tensor(select_int_81, 1, 0, 9223372036854775807);  select_int_81 = None
        slice_tensor_883 = torch.ops.aten.slice.Tensor(slice_tensor_882, 2, 256, 9223372036854775807);  slice_tensor_882 = None
        copy__default_81 = torch.ops.aten.copy_.default(slice_tensor_883, slice_tensor_880);  slice_tensor_883 = slice_tensor_880 = None
        slice_tensor_884 = torch.ops.aten.slice.Tensor(view_default_288, 0, 0, 9223372036854775807)
        slice_tensor_885 = torch.ops.aten.slice.Tensor(slice_tensor_884, 1, 0, 9223372036854775807);  slice_tensor_884 = None
        slice_tensor_886 = torch.ops.aten.slice.Tensor(slice_tensor_885, 2, -257, -1);  slice_tensor_885 = None
        slice_tensor_887 = torch.ops.aten.slice.Tensor(slice_tensor_886, 3, 257, 9223372036854775807);  slice_tensor_886 = None
        slice_tensor_888 = torch.ops.aten.slice.Tensor(new_empty_default_50, 0, 0, 9223372036854775807)
        slice_tensor_889 = torch.ops.aten.slice.Tensor(slice_tensor_888, 1, 1, 9223372036854775807);  slice_tensor_888 = None
        slice_tensor_890 = torch.ops.aten.slice.Tensor(slice_tensor_889, 2, 0, 9223372036854775807);  slice_tensor_889 = None
        slice_tensor_891 = torch.ops.aten.slice.Tensor(slice_tensor_890, 3, 0, 256);  slice_tensor_890 = None
        copy__default_82 = torch.ops.aten.copy_.default(slice_tensor_891, slice_tensor_887);  slice_tensor_891 = slice_tensor_887 = None
        slice_tensor_892 = torch.ops.aten.slice.Tensor(view_default_288, 0, 0, 9223372036854775807);  view_default_288 = None
        select_int_82 = torch.ops.aten.select.int(slice_tensor_892, 1, 0);  slice_tensor_892 = None
        slice_tensor_893 = torch.ops.aten.slice.Tensor(select_int_82, 1, 0, 255);  select_int_82 = None
        slice_tensor_894 = torch.ops.aten.slice.Tensor(slice_tensor_893, 2, -255, 9223372036854775807);  slice_tensor_893 = None
        slice_tensor_895 = torch.ops.aten.slice.Tensor(new_empty_default_50, 0, 0, 9223372036854775807)
        select_int_83 = torch.ops.aten.select.int(slice_tensor_895, 1, 0);  slice_tensor_895 = None
        slice_tensor_896 = torch.ops.aten.slice.Tensor(select_int_83, 1, 1, 256);  select_int_83 = None
        slice_tensor_897 = torch.ops.aten.slice.Tensor(slice_tensor_896, 2, 1, 256);  slice_tensor_896 = None
        copy__default_83 = torch.ops.aten.copy_.default(slice_tensor_897, slice_tensor_894);  slice_tensor_897 = slice_tensor_894 = None
        view_default_289 = torch.ops.aten.view.default(new_empty_default_50, [2, 12, 1024, 513]);  new_empty_default_50 = None
        transpose_int_155 = torch.ops.aten.transpose.int(view_default_289, 2, 1);  view_default_289 = None
        new_empty_default_51 = torch.ops.aten.new_empty.default(transpose_int_155, [256, 257], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        fill__scalar_30 = torch.ops.aten.fill_.Scalar(new_empty_default_51, 1.0);  new_empty_default_51 = None
        tril_default_20 = torch.ops.aten.tril.default(fill__scalar_30);  fill__scalar_30 = None
        flip_default_40 = torch.ops.aten.flip.default(tril_default_20, [0]);  tril_default_20 = None
        unsqueeze_default_142 = torch.ops.aten.unsqueeze.default(flip_default_40, 0);  flip_default_40 = None
        slice_tensor_898 = torch.ops.aten.slice.Tensor(unsqueeze_default_142, 1, 0, 9223372036854775807);  unsqueeze_default_142 = None
        unsqueeze_default_143 = torch.ops.aten.unsqueeze.default(slice_tensor_898, 2);  slice_tensor_898 = None
        slice_tensor_899 = torch.ops.aten.slice.Tensor(unsqueeze_default_143, 3, 0, 9223372036854775807);  unsqueeze_default_143 = None
        flip_default_41 = torch.ops.aten.flip.default(slice_tensor_899, [1, 3])
        slice_tensor_900 = torch.ops.aten.slice.Tensor(transpose_int_155, 0, 0, 9223372036854775807)
        slice_tensor_901 = torch.ops.aten.slice.Tensor(slice_tensor_900, 1, 0, 256);  slice_tensor_900 = None
        slice_tensor_902 = torch.ops.aten.slice.Tensor(slice_tensor_901, 2, 0, 9223372036854775807);  slice_tensor_901 = None
        slice_tensor_903 = torch.ops.aten.slice.Tensor(slice_tensor_902, 3, 0, 257);  slice_tensor_902 = None
        expand_sym_int_40 = torch.ops.aten.expand.SymInt(slice_tensor_899, [2, 256, 12, 257]);  slice_tensor_899 = None
        eq_scalar_40 = torch.ops.aten.eq.Scalar(expand_sym_int_40, 1);  expand_sym_int_40 = None
        masked_fill__scalar_40 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_903, eq_scalar_40, -inf);  slice_tensor_903 = None
        slice_tensor_904 = torch.ops.aten.slice.Tensor(transpose_int_155, 0, 0, 9223372036854775807)
        slice_tensor_905 = torch.ops.aten.slice.Tensor(slice_tensor_904, 1, -256, 9223372036854775807);  slice_tensor_904 = None
        slice_tensor_906 = torch.ops.aten.slice.Tensor(slice_tensor_905, 2, 0, 9223372036854775807);  slice_tensor_905 = None
        slice_tensor_907 = torch.ops.aten.slice.Tensor(slice_tensor_906, 3, -257, 9223372036854775807);  slice_tensor_906 = None
        expand_sym_int_41 = torch.ops.aten.expand.SymInt(flip_default_41, [2, 256, 12, 257]);  flip_default_41 = None
        eq_scalar_41 = torch.ops.aten.eq.Scalar(expand_sym_int_41, 1);  expand_sym_int_41 = None
        masked_fill__scalar_41 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_907, eq_scalar_41, -inf);  slice_tensor_907 = None
        ne_scalar_10 = torch.ops.aten.ne.Scalar(primals_194, 0)
        slice_tensor_908 = torch.ops.aten.slice.Tensor(ne_scalar_10, 0, 0, 9223372036854775807);  ne_scalar_10 = None
        slice_tensor_909 = torch.ops.aten.slice.Tensor(slice_tensor_908, 1, 0, 9223372036854775807);  slice_tensor_908 = None
        unsqueeze_default_144 = torch.ops.aten.unsqueeze.default(slice_tensor_909, 2);  slice_tensor_909 = None
        unsqueeze_default_145 = torch.ops.aten.unsqueeze.default(unsqueeze_default_144, 3);  unsqueeze_default_144 = None
        _to_copy_default_10 = torch.ops.aten._to_copy.default(unsqueeze_default_145, device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided)
        where_scalar_self_20 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_145, -10000.0, _to_copy_default_10);  unsqueeze_default_145 = _to_copy_default_10 = None
        new_empty_default_52 = torch.ops.aten.new_empty.default(where_scalar_self_20, [2, 1024, 1, 1], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        fill__scalar_31 = torch.ops.aten.fill_.Scalar(new_empty_default_52, 1.0);  new_empty_default_52 = None
        transpose_int_156 = torch.ops.aten.transpose.int(fill__scalar_31, 1, 2);  fill__scalar_31 = None
        view_default_290 = torch.ops.aten.view.default(transpose_int_156, [2, 1024, 1]);  transpose_int_156 = None
        transpose_int_157 = torch.ops.aten.transpose.int(where_scalar_self_20, 1, 2);  where_scalar_self_20 = None
        view_default_291 = torch.ops.aten.view.default(transpose_int_157, [2, 1024, 1]);  transpose_int_157 = None
        view_default_292 = torch.ops.aten.view.default(view_default_290, [2, 2, 512, 1]);  view_default_290 = None
        as_strided_default_52 = torch.ops.aten.as_strided.default(view_default_292, [2, 3, 512, 1], [1024, 256, 1, 1]);  view_default_292 = None
        view_default_293 = torch.ops.aten.view.default(view_default_291, [2, 2, 512, 1]);  view_default_291 = None
        as_strided_default_53 = torch.ops.aten.as_strided.default(view_default_293, [2, 3, 512, 1], [1024, 256, 1, 1]);  view_default_293 = None
        unsqueeze_default_146 = torch.ops.aten.unsqueeze.default(as_strided_default_52, -1);  as_strided_default_52 = None
        permute_default_125 = torch.ops.aten.permute.default(unsqueeze_default_146, [0, 1, 2, 4, 3]);  unsqueeze_default_146 = None
        unsqueeze_default_147 = torch.ops.aten.unsqueeze.default(as_strided_default_53, -1);  as_strided_default_53 = None
        permute_default_126 = torch.ops.aten.permute.default(unsqueeze_default_147, [0, 1, 4, 2, 3]);  unsqueeze_default_147 = None
        squeeze_dim_20 = torch.ops.aten.squeeze.dim(permute_default_125, 4);  permute_default_125 = None
        squeeze_dim_21 = torch.ops.aten.squeeze.dim(permute_default_126, 4);  permute_default_126 = None
        mul_tensor_10 = torch.ops.aten.mul.Tensor(squeeze_dim_20, squeeze_dim_21);  squeeze_dim_20 = squeeze_dim_21 = None
        constant_pad_nd_default_41 = torch.ops.aten.constant_pad_nd.default(mul_tensor_10, [0, 0, 0, 1], 0.0);  mul_tensor_10 = None
        view_default_294 = torch.ops.aten.view.default(constant_pad_nd_default_41, [2, 3, 512, 513]);  constant_pad_nd_default_41 = None
        new_empty_default_53 = torch.ops.aten.new_empty.default(view_default_294, [2, 4, 256, 513], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        slice_tensor_910 = torch.ops.aten.slice.Tensor(view_default_294, 0, 0, 9223372036854775807)
        slice_tensor_911 = torch.ops.aten.slice.Tensor(slice_tensor_910, 1, 0, 9223372036854775807);  slice_tensor_910 = None
        slice_tensor_912 = torch.ops.aten.slice.Tensor(slice_tensor_911, 2, 0, 256);  slice_tensor_911 = None
        slice_tensor_913 = torch.ops.aten.slice.Tensor(slice_tensor_912, 3, 0, 257);  slice_tensor_912 = None
        slice_tensor_914 = torch.ops.aten.slice.Tensor(new_empty_default_53, 0, 0, 9223372036854775807)
        slice_tensor_915 = torch.ops.aten.slice.Tensor(slice_tensor_914, 1, 0, -1);  slice_tensor_914 = None
        slice_tensor_916 = torch.ops.aten.slice.Tensor(slice_tensor_915, 2, 0, 9223372036854775807);  slice_tensor_915 = None
        slice_tensor_917 = torch.ops.aten.slice.Tensor(slice_tensor_916, 3, 256, 9223372036854775807);  slice_tensor_916 = None
        copy__default_84 = torch.ops.aten.copy_.default(slice_tensor_917, slice_tensor_913);  slice_tensor_917 = slice_tensor_913 = None
        slice_tensor_918 = torch.ops.aten.slice.Tensor(view_default_294, 0, 0, 9223372036854775807)
        select_int_84 = torch.ops.aten.select.int(slice_tensor_918, 1, -1);  slice_tensor_918 = None
        slice_tensor_919 = torch.ops.aten.slice.Tensor(select_int_84, 1, 256, 9223372036854775807);  select_int_84 = None
        slice_tensor_920 = torch.ops.aten.slice.Tensor(slice_tensor_919, 2, 0, 257);  slice_tensor_919 = None
        slice_tensor_921 = torch.ops.aten.slice.Tensor(new_empty_default_53, 0, 0, 9223372036854775807)
        select_int_85 = torch.ops.aten.select.int(slice_tensor_921, 1, -1);  slice_tensor_921 = None
        slice_tensor_922 = torch.ops.aten.slice.Tensor(select_int_85, 1, 0, 9223372036854775807);  select_int_85 = None
        slice_tensor_923 = torch.ops.aten.slice.Tensor(slice_tensor_922, 2, 256, 9223372036854775807);  slice_tensor_922 = None
        copy__default_85 = torch.ops.aten.copy_.default(slice_tensor_923, slice_tensor_920);  slice_tensor_923 = slice_tensor_920 = None
        slice_tensor_924 = torch.ops.aten.slice.Tensor(view_default_294, 0, 0, 9223372036854775807)
        slice_tensor_925 = torch.ops.aten.slice.Tensor(slice_tensor_924, 1, 0, 9223372036854775807);  slice_tensor_924 = None
        slice_tensor_926 = torch.ops.aten.slice.Tensor(slice_tensor_925, 2, -257, -1);  slice_tensor_925 = None
        slice_tensor_927 = torch.ops.aten.slice.Tensor(slice_tensor_926, 3, 257, 9223372036854775807);  slice_tensor_926 = None
        slice_tensor_928 = torch.ops.aten.slice.Tensor(new_empty_default_53, 0, 0, 9223372036854775807)
        slice_tensor_929 = torch.ops.aten.slice.Tensor(slice_tensor_928, 1, 1, 9223372036854775807);  slice_tensor_928 = None
        slice_tensor_930 = torch.ops.aten.slice.Tensor(slice_tensor_929, 2, 0, 9223372036854775807);  slice_tensor_929 = None
        slice_tensor_931 = torch.ops.aten.slice.Tensor(slice_tensor_930, 3, 0, 256);  slice_tensor_930 = None
        copy__default_86 = torch.ops.aten.copy_.default(slice_tensor_931, slice_tensor_927);  slice_tensor_931 = slice_tensor_927 = None
        slice_tensor_932 = torch.ops.aten.slice.Tensor(view_default_294, 0, 0, 9223372036854775807);  view_default_294 = None
        select_int_86 = torch.ops.aten.select.int(slice_tensor_932, 1, 0);  slice_tensor_932 = None
        slice_tensor_933 = torch.ops.aten.slice.Tensor(select_int_86, 1, 0, 255);  select_int_86 = None
        slice_tensor_934 = torch.ops.aten.slice.Tensor(slice_tensor_933, 2, -255, 9223372036854775807);  slice_tensor_933 = None
        slice_tensor_935 = torch.ops.aten.slice.Tensor(new_empty_default_53, 0, 0, 9223372036854775807)
        select_int_87 = torch.ops.aten.select.int(slice_tensor_935, 1, 0);  slice_tensor_935 = None
        slice_tensor_936 = torch.ops.aten.slice.Tensor(select_int_87, 1, 1, 256);  select_int_87 = None
        slice_tensor_937 = torch.ops.aten.slice.Tensor(slice_tensor_936, 2, 1, 256);  slice_tensor_936 = None
        copy__default_87 = torch.ops.aten.copy_.default(slice_tensor_937, slice_tensor_934);  slice_tensor_937 = slice_tensor_934 = None
        view_default_295 = torch.ops.aten.view.default(new_empty_default_53, [2, 1, 1024, 513]);  new_empty_default_53 = None
        transpose_int_158 = torch.ops.aten.transpose.int(view_default_295, 2, 1);  view_default_295 = None
        new_empty_default_54 = torch.ops.aten.new_empty.default(transpose_int_158, [256, 257], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        fill__scalar_32 = torch.ops.aten.fill_.Scalar(new_empty_default_54, 1.0);  new_empty_default_54 = None
        tril_default_21 = torch.ops.aten.tril.default(fill__scalar_32);  fill__scalar_32 = None
        flip_default_42 = torch.ops.aten.flip.default(tril_default_21, [0]);  tril_default_21 = None
        unsqueeze_default_148 = torch.ops.aten.unsqueeze.default(flip_default_42, 0);  flip_default_42 = None
        slice_tensor_938 = torch.ops.aten.slice.Tensor(unsqueeze_default_148, 1, 0, 9223372036854775807);  unsqueeze_default_148 = None
        unsqueeze_default_149 = torch.ops.aten.unsqueeze.default(slice_tensor_938, 2);  slice_tensor_938 = None
        slice_tensor_939 = torch.ops.aten.slice.Tensor(unsqueeze_default_149, 3, 0, 9223372036854775807);  unsqueeze_default_149 = None
        flip_default_43 = torch.ops.aten.flip.default(slice_tensor_939, [1, 3])
        slice_tensor_940 = torch.ops.aten.slice.Tensor(transpose_int_158, 0, 0, 9223372036854775807)
        slice_tensor_941 = torch.ops.aten.slice.Tensor(slice_tensor_940, 1, 0, 256);  slice_tensor_940 = None
        slice_tensor_942 = torch.ops.aten.slice.Tensor(slice_tensor_941, 2, 0, 9223372036854775807);  slice_tensor_941 = None
        slice_tensor_943 = torch.ops.aten.slice.Tensor(slice_tensor_942, 3, 0, 257);  slice_tensor_942 = None
        expand_sym_int_42 = torch.ops.aten.expand.SymInt(slice_tensor_939, [2, 256, 1, 257]);  slice_tensor_939 = None
        eq_scalar_42 = torch.ops.aten.eq.Scalar(expand_sym_int_42, 1);  expand_sym_int_42 = None
        masked_fill__scalar_42 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_943, eq_scalar_42, -inf);  slice_tensor_943 = eq_scalar_42 = None
        slice_tensor_944 = torch.ops.aten.slice.Tensor(transpose_int_158, 0, 0, 9223372036854775807)
        slice_tensor_945 = torch.ops.aten.slice.Tensor(slice_tensor_944, 1, -256, 9223372036854775807);  slice_tensor_944 = None
        slice_tensor_946 = torch.ops.aten.slice.Tensor(slice_tensor_945, 2, 0, 9223372036854775807);  slice_tensor_945 = None
        slice_tensor_947 = torch.ops.aten.slice.Tensor(slice_tensor_946, 3, -257, 9223372036854775807);  slice_tensor_946 = None
        expand_sym_int_43 = torch.ops.aten.expand.SymInt(flip_default_43, [2, 256, 1, 257]);  flip_default_43 = None
        eq_scalar_43 = torch.ops.aten.eq.Scalar(expand_sym_int_43, 1);  expand_sym_int_43 = None
        masked_fill__scalar_43 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_947, eq_scalar_43, -inf);  slice_tensor_947 = eq_scalar_43 = None
        add__tensor_10 = torch.ops.aten.add_.Tensor(transpose_int_155, transpose_int_158);  transpose_int_155 = transpose_int_158 = None
        _softmax_default_10 = torch.ops.aten._softmax.default(add__tensor_10, -1, False);  add__tensor_10 = None
        slice_tensor_948 = torch.ops.aten.slice.Tensor(primals_195, 0, 0, 9223372036854775807)
        slice_tensor_949 = torch.ops.aten.slice.Tensor(slice_tensor_948, 1, 0, 9223372036854775807);  slice_tensor_948 = None
        unsqueeze_default_150 = torch.ops.aten.unsqueeze.default(slice_tensor_949, 2);  slice_tensor_949 = None
        unsqueeze_default_151 = torch.ops.aten.unsqueeze.default(unsqueeze_default_150, 3);  unsqueeze_default_150 = None
        where_scalar_self_21 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_151, 0.0, _softmax_default_10)
        view_default_296 = torch.ops.aten.view.default(add_tensor_62, [1024, 2, 12, 64]);  add_tensor_62 = None
        transpose_int_159 = torch.ops.aten.transpose.int(view_default_296, 0, 1);  view_default_296 = None
        transpose_int_160 = torch.ops.aten.transpose.int(where_scalar_self_21, 1, 2);  where_scalar_self_21 = None
        clone_default_95 = torch.ops.aten.clone.default(transpose_int_160, memory_format = torch.contiguous_format);  transpose_int_160 = None
        _unsafe_view_default_138 = torch.ops.aten._unsafe_view.default(clone_default_95, [24, 4, 256, 513]);  clone_default_95 = None
        transpose_int_161 = torch.ops.aten.transpose.int(transpose_int_159, 1, 2);  transpose_int_159 = None
        view_default_297 = torch.ops.aten.view.default(transpose_int_161, [24, 1024, 64]);  transpose_int_161 = None
        constant_pad_nd_default_42 = torch.ops.aten.constant_pad_nd.default(view_default_297, [0, 0, 256, 256], -1.0);  view_default_297 = None
        as_strided_default_54 = torch.ops.aten.as_strided.default(constant_pad_nd_default_42, [24, 4, 768, 64], [98304, 16384, 64, 1]);  constant_pad_nd_default_42 = None
        constant_pad_nd_default_43 = torch.ops.aten.constant_pad_nd.default(_unsafe_view_default_138, [0, 257], 0.0);  _unsafe_view_default_138 = None
        view_default_298 = torch.ops.aten.view.default(constant_pad_nd_default_43, [24, 4, -1]);  constant_pad_nd_default_43 = None
        slice_tensor_950 = torch.ops.aten.slice.Tensor(view_default_298, 0, 0, 9223372036854775807);  view_default_298 = None
        slice_tensor_951 = torch.ops.aten.slice.Tensor(slice_tensor_950, 1, 0, 9223372036854775807);  slice_tensor_950 = None
        slice_tensor_952 = torch.ops.aten.slice.Tensor(slice_tensor_951, 2, 0, -256);  slice_tensor_951 = None
        view_default_299 = torch.ops.aten.view.default(slice_tensor_952, [24, 4, 256, 769]);  slice_tensor_952 = None
        slice_tensor_953 = torch.ops.aten.slice.Tensor(view_default_299, 0, 0, 9223372036854775807);  view_default_299 = None
        slice_tensor_954 = torch.ops.aten.slice.Tensor(slice_tensor_953, 1, 0, 9223372036854775807);  slice_tensor_953 = None
        slice_tensor_955 = torch.ops.aten.slice.Tensor(slice_tensor_954, 2, 0, 9223372036854775807);  slice_tensor_954 = None
        slice_tensor_956 = torch.ops.aten.slice.Tensor(slice_tensor_955, 3, 0, -1);  slice_tensor_955 = None
        unsqueeze_default_152 = torch.ops.aten.unsqueeze.default(slice_tensor_956, -1);  slice_tensor_956 = None
        permute_default_127 = torch.ops.aten.permute.default(unsqueeze_default_152, [0, 1, 2, 4, 3]);  unsqueeze_default_152 = None
        unsqueeze_default_153 = torch.ops.aten.unsqueeze.default(as_strided_default_54, -1);  as_strided_default_54 = None
        permute_default_128 = torch.ops.aten.permute.default(unsqueeze_default_153, [0, 1, 4, 3, 2]);  unsqueeze_default_153 = None
        permute_default_129 = torch.ops.aten.permute.default(permute_default_127, [0, 1, 2, 4, 3]);  permute_default_127 = None
        view_default_300 = torch.ops.aten.view.default(permute_default_129, [96, 256, 768]);  permute_default_129 = None
        permute_default_130 = torch.ops.aten.permute.default(permute_default_128, [0, 1, 4, 3, 2]);  permute_default_128 = None
        clone_default_96 = torch.ops.aten.clone.default(permute_default_130, memory_format = torch.contiguous_format);  permute_default_130 = None
        _unsafe_view_default_139 = torch.ops.aten._unsafe_view.default(clone_default_96, [96, 768, 64]);  clone_default_96 = None
        bmm_default_21 = torch.ops.aten.bmm.default(view_default_300, _unsafe_view_default_139)
        view_default_301 = torch.ops.aten.view.default(bmm_default_21, [24, 4, 256, 1, 64]);  bmm_default_21 = None
        permute_default_131 = torch.ops.aten.permute.default(view_default_301, [0, 1, 2, 4, 3]);  view_default_301 = None
        view_default_302 = torch.ops.aten.view.default(permute_default_131, [24, 4, 256, 64]);  permute_default_131 = None
        view_default_303 = torch.ops.aten.view.default(view_default_302, [2, 12, 1024, 64]);  view_default_302 = None
        transpose_int_162 = torch.ops.aten.transpose.int(view_default_303, 1, 2);  view_default_303 = None
        transpose_int_163 = torch.ops.aten.transpose.int(transpose_int_162, 0, 1);  transpose_int_162 = None
        clone_default_97 = torch.ops.aten.clone.default(transpose_int_163, memory_format = torch.contiguous_format);  transpose_int_163 = None
        _unsafe_view_default_140 = torch.ops.aten._unsafe_view.default(clone_default_97, [1024, 2, 768]);  clone_default_97 = None
        transpose_int_164 = torch.ops.aten.transpose.int(_unsafe_view_default_140, 0, 1);  _unsafe_view_default_140 = None
        t_default_63 = torch.ops.aten.t.default(primals_20);  primals_20 = None
        clone_default_98 = torch.ops.aten.clone.default(transpose_int_164, memory_format = torch.contiguous_format);  transpose_int_164 = None
        _unsafe_view_default_141 = torch.ops.aten._unsafe_view.default(clone_default_98, [2048, 768]);  clone_default_98 = None
        mm_default_43 = torch.ops.aten.mm.default(_unsafe_view_default_141, t_default_63)
        _unsafe_view_default_142 = torch.ops.aten._unsafe_view.default(mm_default_43, [2, 1024, 768]);  mm_default_43 = None
        add_tensor_63 = torch.ops.aten.add.Tensor(_unsafe_view_default_142, primals_19);  _unsafe_view_default_142 = primals_19 = None
        add_tensor_64 = torch.ops.aten.add.Tensor(add_tensor_63, getitem_57);  add_tensor_63 = getitem_57 = None
        native_layer_norm_default_20 = torch.ops.aten.native_layer_norm.default(add_tensor_64, [768], primals_18, primals_17, 1e-05)
        getitem_60 = native_layer_norm_default_20[0]
        getitem_61 = native_layer_norm_default_20[1]
        getitem_62 = native_layer_norm_default_20[2];  native_layer_norm_default_20 = None
        view_default_304 = torch.ops.aten.view.default(getitem_60, [2048, 768])
        t_default_64 = torch.ops.aten.t.default(primals_28);  primals_28 = None
        addmm_default_20 = torch.ops.aten.addmm.default(primals_27, view_default_304, t_default_64);  primals_27 = None
        view_default_305 = torch.ops.aten.view.default(addmm_default_20, [2, 1024, 3072]);  addmm_default_20 = None
        gelu_default_10 = torch.ops.aten.gelu.default(view_default_305)
        view_default_306 = torch.ops.aten.view.default(gelu_default_10, [2048, 3072]);  gelu_default_10 = None
        t_default_65 = torch.ops.aten.t.default(primals_32);  primals_32 = None
        addmm_default_21 = torch.ops.aten.addmm.default(primals_31, view_default_306, t_default_65);  primals_31 = None
        view_default_307 = torch.ops.aten.view.default(addmm_default_21, [2, 1024, 768]);  addmm_default_21 = None
        add_tensor_65 = torch.ops.aten.add.Tensor(view_default_307, getitem_60);  view_default_307 = getitem_60 = None
        native_layer_norm_default_21 = torch.ops.aten.native_layer_norm.default(add_tensor_65, [768], primals_30, primals_29, 1e-05)
        getitem_63 = native_layer_norm_default_21[0]
        getitem_64 = native_layer_norm_default_21[1]
        getitem_65 = native_layer_norm_default_21[2];  native_layer_norm_default_21 = None
        transpose_int_165 = torch.ops.aten.transpose.int(getitem_63, 0, 1)
        t_default_66 = torch.ops.aten.t.default(primals_40);  primals_40 = None
        clone_default_99 = torch.ops.aten.clone.default(transpose_int_165, memory_format = torch.contiguous_format)
        _unsafe_view_default_143 = torch.ops.aten._unsafe_view.default(clone_default_99, [2048, 768]);  clone_default_99 = None
        mm_default_44 = torch.ops.aten.mm.default(_unsafe_view_default_143, t_default_66)
        _unsafe_view_default_144 = torch.ops.aten._unsafe_view.default(mm_default_44, [1024, 2, 768]);  mm_default_44 = None
        add_tensor_66 = torch.ops.aten.add.Tensor(_unsafe_view_default_144, primals_39);  _unsafe_view_default_144 = primals_39 = None
        t_default_67 = torch.ops.aten.t.default(primals_38);  primals_38 = None
        clone_default_100 = torch.ops.aten.clone.default(transpose_int_165, memory_format = torch.contiguous_format)
        _unsafe_view_default_145 = torch.ops.aten._unsafe_view.default(clone_default_100, [2048, 768]);  clone_default_100 = None
        mm_default_45 = torch.ops.aten.mm.default(_unsafe_view_default_145, t_default_67)
        _unsafe_view_default_146 = torch.ops.aten._unsafe_view.default(mm_default_45, [1024, 2, 768]);  mm_default_45 = None
        add_tensor_67 = torch.ops.aten.add.Tensor(_unsafe_view_default_146, primals_37);  _unsafe_view_default_146 = primals_37 = None
        t_default_68 = torch.ops.aten.t.default(primals_42);  primals_42 = None
        clone_default_101 = torch.ops.aten.clone.default(transpose_int_165, memory_format = torch.contiguous_format);  transpose_int_165 = None
        _unsafe_view_default_147 = torch.ops.aten._unsafe_view.default(clone_default_101, [2048, 768]);  clone_default_101 = None
        mm_default_46 = torch.ops.aten.mm.default(_unsafe_view_default_147, t_default_68)
        _unsafe_view_default_148 = torch.ops.aten._unsafe_view.default(mm_default_46, [1024, 2, 768]);  mm_default_46 = None
        add_tensor_68 = torch.ops.aten.add.Tensor(_unsafe_view_default_148, primals_41);  _unsafe_view_default_148 = primals_41 = None
        div__tensor_11 = torch.ops.aten.div_.Tensor(add_tensor_66, 8.0);  add_tensor_66 = None
        view_default_308 = torch.ops.aten.view.default(div__tensor_11, [1024, 2, 12, 64]);  div__tensor_11 = None
        transpose_int_166 = torch.ops.aten.transpose.int(view_default_308, 0, 1);  view_default_308 = None
        view_default_309 = torch.ops.aten.view.default(add_tensor_67, [1024, 2, 12, 64]);  add_tensor_67 = None
        transpose_int_167 = torch.ops.aten.transpose.int(view_default_309, 0, 1);  view_default_309 = None
        transpose_int_168 = torch.ops.aten.transpose.int(transpose_int_166, 1, 2);  transpose_int_166 = None
        view_default_310 = torch.ops.aten.view.default(transpose_int_168, [24, 1024, 64]);  transpose_int_168 = None
        transpose_int_169 = torch.ops.aten.transpose.int(transpose_int_167, 1, 2);  transpose_int_167 = None
        view_default_311 = torch.ops.aten.view.default(transpose_int_169, [24, 1024, 64]);  transpose_int_169 = None
        view_default_312 = torch.ops.aten.view.default(view_default_310, [24, 2, 512, 64]);  view_default_310 = None
        as_strided_default_55 = torch.ops.aten.as_strided.default(view_default_312, [24, 3, 512, 64], [64, 393216, 1536, 1]);  view_default_312 = None
        view_default_313 = torch.ops.aten.view.default(view_default_311, [24, 2, 512, 64]);  view_default_311 = None
        as_strided_default_56 = torch.ops.aten.as_strided.default(view_default_313, [24, 3, 512, 64], [64, 393216, 1536, 1]);  view_default_313 = None
        unsqueeze_default_154 = torch.ops.aten.unsqueeze.default(as_strided_default_55, -1);  as_strided_default_55 = None
        permute_default_132 = torch.ops.aten.permute.default(unsqueeze_default_154, [0, 1, 2, 4, 3]);  unsqueeze_default_154 = None
        unsqueeze_default_155 = torch.ops.aten.unsqueeze.default(as_strided_default_56, -1);  as_strided_default_56 = None
        permute_default_133 = torch.ops.aten.permute.default(unsqueeze_default_155, [0, 1, 4, 2, 3]);  unsqueeze_default_155 = None
        permute_default_134 = torch.ops.aten.permute.default(permute_default_132, [0, 1, 2, 4, 3]);  permute_default_132 = None
        clone_default_102 = torch.ops.aten.clone.default(permute_default_134, memory_format = torch.contiguous_format);  permute_default_134 = None
        _unsafe_view_default_149 = torch.ops.aten._unsafe_view.default(clone_default_102, [72, 512, 64]);  clone_default_102 = None
        permute_default_135 = torch.ops.aten.permute.default(permute_default_133, [0, 1, 4, 3, 2]);  permute_default_133 = None
        clone_default_103 = torch.ops.aten.clone.default(permute_default_135, memory_format = torch.contiguous_format);  permute_default_135 = None
        _unsafe_view_default_150 = torch.ops.aten._unsafe_view.default(clone_default_103, [72, 64, 512]);  clone_default_103 = None
        bmm_default_22 = torch.ops.aten.bmm.default(_unsafe_view_default_149, _unsafe_view_default_150)
        view_default_314 = torch.ops.aten.view.default(bmm_default_22, [24, 3, 512, 1, 512]);  bmm_default_22 = None
        permute_default_136 = torch.ops.aten.permute.default(view_default_314, [0, 1, 2, 4, 3]);  view_default_314 = None
        view_default_315 = torch.ops.aten.view.default(permute_default_136, [24, 3, 512, 512]);  permute_default_136 = None
        constant_pad_nd_default_44 = torch.ops.aten.constant_pad_nd.default(view_default_315, [0, 0, 0, 1], 0.0);  view_default_315 = None
        view_default_316 = torch.ops.aten.view.default(constant_pad_nd_default_44, [24, 3, 512, 513]);  constant_pad_nd_default_44 = None
        new_empty_default_55 = torch.ops.aten.new_empty.default(view_default_316, [24, 4, 256, 513], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        slice_tensor_957 = torch.ops.aten.slice.Tensor(view_default_316, 0, 0, 9223372036854775807)
        slice_tensor_958 = torch.ops.aten.slice.Tensor(slice_tensor_957, 1, 0, 9223372036854775807);  slice_tensor_957 = None
        slice_tensor_959 = torch.ops.aten.slice.Tensor(slice_tensor_958, 2, 0, 256);  slice_tensor_958 = None
        slice_tensor_960 = torch.ops.aten.slice.Tensor(slice_tensor_959, 3, 0, 257);  slice_tensor_959 = None
        slice_tensor_961 = torch.ops.aten.slice.Tensor(new_empty_default_55, 0, 0, 9223372036854775807)
        slice_tensor_962 = torch.ops.aten.slice.Tensor(slice_tensor_961, 1, 0, -1);  slice_tensor_961 = None
        slice_tensor_963 = torch.ops.aten.slice.Tensor(slice_tensor_962, 2, 0, 9223372036854775807);  slice_tensor_962 = None
        slice_tensor_964 = torch.ops.aten.slice.Tensor(slice_tensor_963, 3, 256, 9223372036854775807);  slice_tensor_963 = None
        copy__default_88 = torch.ops.aten.copy_.default(slice_tensor_964, slice_tensor_960);  slice_tensor_964 = slice_tensor_960 = None
        slice_tensor_965 = torch.ops.aten.slice.Tensor(view_default_316, 0, 0, 9223372036854775807)
        select_int_88 = torch.ops.aten.select.int(slice_tensor_965, 1, -1);  slice_tensor_965 = None
        slice_tensor_966 = torch.ops.aten.slice.Tensor(select_int_88, 1, 256, 9223372036854775807);  select_int_88 = None
        slice_tensor_967 = torch.ops.aten.slice.Tensor(slice_tensor_966, 2, 0, 257);  slice_tensor_966 = None
        slice_tensor_968 = torch.ops.aten.slice.Tensor(new_empty_default_55, 0, 0, 9223372036854775807)
        select_int_89 = torch.ops.aten.select.int(slice_tensor_968, 1, -1);  slice_tensor_968 = None
        slice_tensor_969 = torch.ops.aten.slice.Tensor(select_int_89, 1, 0, 9223372036854775807);  select_int_89 = None
        slice_tensor_970 = torch.ops.aten.slice.Tensor(slice_tensor_969, 2, 256, 9223372036854775807);  slice_tensor_969 = None
        copy__default_89 = torch.ops.aten.copy_.default(slice_tensor_970, slice_tensor_967);  slice_tensor_970 = slice_tensor_967 = None
        slice_tensor_971 = torch.ops.aten.slice.Tensor(view_default_316, 0, 0, 9223372036854775807)
        slice_tensor_972 = torch.ops.aten.slice.Tensor(slice_tensor_971, 1, 0, 9223372036854775807);  slice_tensor_971 = None
        slice_tensor_973 = torch.ops.aten.slice.Tensor(slice_tensor_972, 2, -257, -1);  slice_tensor_972 = None
        slice_tensor_974 = torch.ops.aten.slice.Tensor(slice_tensor_973, 3, 257, 9223372036854775807);  slice_tensor_973 = None
        slice_tensor_975 = torch.ops.aten.slice.Tensor(new_empty_default_55, 0, 0, 9223372036854775807)
        slice_tensor_976 = torch.ops.aten.slice.Tensor(slice_tensor_975, 1, 1, 9223372036854775807);  slice_tensor_975 = None
        slice_tensor_977 = torch.ops.aten.slice.Tensor(slice_tensor_976, 2, 0, 9223372036854775807);  slice_tensor_976 = None
        slice_tensor_978 = torch.ops.aten.slice.Tensor(slice_tensor_977, 3, 0, 256);  slice_tensor_977 = None
        copy__default_90 = torch.ops.aten.copy_.default(slice_tensor_978, slice_tensor_974);  slice_tensor_978 = slice_tensor_974 = None
        slice_tensor_979 = torch.ops.aten.slice.Tensor(view_default_316, 0, 0, 9223372036854775807);  view_default_316 = None
        select_int_90 = torch.ops.aten.select.int(slice_tensor_979, 1, 0);  slice_tensor_979 = None
        slice_tensor_980 = torch.ops.aten.slice.Tensor(select_int_90, 1, 0, 255);  select_int_90 = None
        slice_tensor_981 = torch.ops.aten.slice.Tensor(slice_tensor_980, 2, -255, 9223372036854775807);  slice_tensor_980 = None
        slice_tensor_982 = torch.ops.aten.slice.Tensor(new_empty_default_55, 0, 0, 9223372036854775807)
        select_int_91 = torch.ops.aten.select.int(slice_tensor_982, 1, 0);  slice_tensor_982 = None
        slice_tensor_983 = torch.ops.aten.slice.Tensor(select_int_91, 1, 1, 256);  select_int_91 = None
        slice_tensor_984 = torch.ops.aten.slice.Tensor(slice_tensor_983, 2, 1, 256);  slice_tensor_983 = None
        copy__default_91 = torch.ops.aten.copy_.default(slice_tensor_984, slice_tensor_981);  slice_tensor_984 = slice_tensor_981 = None
        view_default_317 = torch.ops.aten.view.default(new_empty_default_55, [2, 12, 1024, 513]);  new_empty_default_55 = None
        transpose_int_170 = torch.ops.aten.transpose.int(view_default_317, 2, 1);  view_default_317 = None
        new_empty_default_56 = torch.ops.aten.new_empty.default(transpose_int_170, [256, 257], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        fill__scalar_33 = torch.ops.aten.fill_.Scalar(new_empty_default_56, 1.0);  new_empty_default_56 = None
        tril_default_22 = torch.ops.aten.tril.default(fill__scalar_33);  fill__scalar_33 = None
        flip_default_44 = torch.ops.aten.flip.default(tril_default_22, [0]);  tril_default_22 = None
        unsqueeze_default_156 = torch.ops.aten.unsqueeze.default(flip_default_44, 0);  flip_default_44 = None
        slice_tensor_985 = torch.ops.aten.slice.Tensor(unsqueeze_default_156, 1, 0, 9223372036854775807);  unsqueeze_default_156 = None
        unsqueeze_default_157 = torch.ops.aten.unsqueeze.default(slice_tensor_985, 2);  slice_tensor_985 = None
        slice_tensor_986 = torch.ops.aten.slice.Tensor(unsqueeze_default_157, 3, 0, 9223372036854775807);  unsqueeze_default_157 = None
        flip_default_45 = torch.ops.aten.flip.default(slice_tensor_986, [1, 3])
        slice_tensor_987 = torch.ops.aten.slice.Tensor(transpose_int_170, 0, 0, 9223372036854775807)
        slice_tensor_988 = torch.ops.aten.slice.Tensor(slice_tensor_987, 1, 0, 256);  slice_tensor_987 = None
        slice_tensor_989 = torch.ops.aten.slice.Tensor(slice_tensor_988, 2, 0, 9223372036854775807);  slice_tensor_988 = None
        slice_tensor_990 = torch.ops.aten.slice.Tensor(slice_tensor_989, 3, 0, 257);  slice_tensor_989 = None
        expand_sym_int_44 = torch.ops.aten.expand.SymInt(slice_tensor_986, [2, 256, 12, 257]);  slice_tensor_986 = None
        eq_scalar_44 = torch.ops.aten.eq.Scalar(expand_sym_int_44, 1);  expand_sym_int_44 = None
        masked_fill__scalar_44 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_990, eq_scalar_44, -inf);  slice_tensor_990 = None
        slice_tensor_991 = torch.ops.aten.slice.Tensor(transpose_int_170, 0, 0, 9223372036854775807)
        slice_tensor_992 = torch.ops.aten.slice.Tensor(slice_tensor_991, 1, -256, 9223372036854775807);  slice_tensor_991 = None
        slice_tensor_993 = torch.ops.aten.slice.Tensor(slice_tensor_992, 2, 0, 9223372036854775807);  slice_tensor_992 = None
        slice_tensor_994 = torch.ops.aten.slice.Tensor(slice_tensor_993, 3, -257, 9223372036854775807);  slice_tensor_993 = None
        expand_sym_int_45 = torch.ops.aten.expand.SymInt(flip_default_45, [2, 256, 12, 257]);  flip_default_45 = None
        eq_scalar_45 = torch.ops.aten.eq.Scalar(expand_sym_int_45, 1);  expand_sym_int_45 = None
        masked_fill__scalar_45 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_994, eq_scalar_45, -inf);  slice_tensor_994 = None
        ne_scalar_11 = torch.ops.aten.ne.Scalar(primals_194, 0);  primals_194 = None
        slice_tensor_995 = torch.ops.aten.slice.Tensor(ne_scalar_11, 0, 0, 9223372036854775807);  ne_scalar_11 = None
        slice_tensor_996 = torch.ops.aten.slice.Tensor(slice_tensor_995, 1, 0, 9223372036854775807);  slice_tensor_995 = None
        unsqueeze_default_158 = torch.ops.aten.unsqueeze.default(slice_tensor_996, 2);  slice_tensor_996 = None
        unsqueeze_default_159 = torch.ops.aten.unsqueeze.default(unsqueeze_default_158, 3);  unsqueeze_default_158 = None
        _to_copy_default_11 = torch.ops.aten._to_copy.default(unsqueeze_default_159, device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided)
        where_scalar_self_22 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_159, -10000.0, _to_copy_default_11);  unsqueeze_default_159 = _to_copy_default_11 = None
        new_empty_default_57 = torch.ops.aten.new_empty.default(where_scalar_self_22, [2, 1024, 1, 1], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        fill__scalar_34 = torch.ops.aten.fill_.Scalar(new_empty_default_57, 1.0);  new_empty_default_57 = None
        transpose_int_171 = torch.ops.aten.transpose.int(fill__scalar_34, 1, 2);  fill__scalar_34 = None
        view_default_318 = torch.ops.aten.view.default(transpose_int_171, [2, 1024, 1]);  transpose_int_171 = None
        transpose_int_172 = torch.ops.aten.transpose.int(where_scalar_self_22, 1, 2);  where_scalar_self_22 = None
        view_default_319 = torch.ops.aten.view.default(transpose_int_172, [2, 1024, 1]);  transpose_int_172 = None
        view_default_320 = torch.ops.aten.view.default(view_default_318, [2, 2, 512, 1]);  view_default_318 = None
        as_strided_default_57 = torch.ops.aten.as_strided.default(view_default_320, [2, 3, 512, 1], [1024, 256, 1, 1]);  view_default_320 = None
        view_default_321 = torch.ops.aten.view.default(view_default_319, [2, 2, 512, 1]);  view_default_319 = None
        as_strided_default_58 = torch.ops.aten.as_strided.default(view_default_321, [2, 3, 512, 1], [1024, 256, 1, 1]);  view_default_321 = None
        unsqueeze_default_160 = torch.ops.aten.unsqueeze.default(as_strided_default_57, -1);  as_strided_default_57 = None
        permute_default_137 = torch.ops.aten.permute.default(unsqueeze_default_160, [0, 1, 2, 4, 3]);  unsqueeze_default_160 = None
        unsqueeze_default_161 = torch.ops.aten.unsqueeze.default(as_strided_default_58, -1);  as_strided_default_58 = None
        permute_default_138 = torch.ops.aten.permute.default(unsqueeze_default_161, [0, 1, 4, 2, 3]);  unsqueeze_default_161 = None
        squeeze_dim_22 = torch.ops.aten.squeeze.dim(permute_default_137, 4);  permute_default_137 = None
        squeeze_dim_23 = torch.ops.aten.squeeze.dim(permute_default_138, 4);  permute_default_138 = None
        mul_tensor_11 = torch.ops.aten.mul.Tensor(squeeze_dim_22, squeeze_dim_23);  squeeze_dim_22 = squeeze_dim_23 = None
        constant_pad_nd_default_45 = torch.ops.aten.constant_pad_nd.default(mul_tensor_11, [0, 0, 0, 1], 0.0);  mul_tensor_11 = None
        view_default_322 = torch.ops.aten.view.default(constant_pad_nd_default_45, [2, 3, 512, 513]);  constant_pad_nd_default_45 = None
        new_empty_default_58 = torch.ops.aten.new_empty.default(view_default_322, [2, 4, 256, 513], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        slice_tensor_997 = torch.ops.aten.slice.Tensor(view_default_322, 0, 0, 9223372036854775807)
        slice_tensor_998 = torch.ops.aten.slice.Tensor(slice_tensor_997, 1, 0, 9223372036854775807);  slice_tensor_997 = None
        slice_tensor_999 = torch.ops.aten.slice.Tensor(slice_tensor_998, 2, 0, 256);  slice_tensor_998 = None
        slice_tensor_1000 = torch.ops.aten.slice.Tensor(slice_tensor_999, 3, 0, 257);  slice_tensor_999 = None
        slice_tensor_1001 = torch.ops.aten.slice.Tensor(new_empty_default_58, 0, 0, 9223372036854775807)
        slice_tensor_1002 = torch.ops.aten.slice.Tensor(slice_tensor_1001, 1, 0, -1);  slice_tensor_1001 = None
        slice_tensor_1003 = torch.ops.aten.slice.Tensor(slice_tensor_1002, 2, 0, 9223372036854775807);  slice_tensor_1002 = None
        slice_tensor_1004 = torch.ops.aten.slice.Tensor(slice_tensor_1003, 3, 256, 9223372036854775807);  slice_tensor_1003 = None
        copy__default_92 = torch.ops.aten.copy_.default(slice_tensor_1004, slice_tensor_1000);  slice_tensor_1004 = slice_tensor_1000 = None
        slice_tensor_1005 = torch.ops.aten.slice.Tensor(view_default_322, 0, 0, 9223372036854775807)
        select_int_92 = torch.ops.aten.select.int(slice_tensor_1005, 1, -1);  slice_tensor_1005 = None
        slice_tensor_1006 = torch.ops.aten.slice.Tensor(select_int_92, 1, 256, 9223372036854775807);  select_int_92 = None
        slice_tensor_1007 = torch.ops.aten.slice.Tensor(slice_tensor_1006, 2, 0, 257);  slice_tensor_1006 = None
        slice_tensor_1008 = torch.ops.aten.slice.Tensor(new_empty_default_58, 0, 0, 9223372036854775807)
        select_int_93 = torch.ops.aten.select.int(slice_tensor_1008, 1, -1);  slice_tensor_1008 = None
        slice_tensor_1009 = torch.ops.aten.slice.Tensor(select_int_93, 1, 0, 9223372036854775807);  select_int_93 = None
        slice_tensor_1010 = torch.ops.aten.slice.Tensor(slice_tensor_1009, 2, 256, 9223372036854775807);  slice_tensor_1009 = None
        copy__default_93 = torch.ops.aten.copy_.default(slice_tensor_1010, slice_tensor_1007);  slice_tensor_1010 = slice_tensor_1007 = None
        slice_tensor_1011 = torch.ops.aten.slice.Tensor(view_default_322, 0, 0, 9223372036854775807)
        slice_tensor_1012 = torch.ops.aten.slice.Tensor(slice_tensor_1011, 1, 0, 9223372036854775807);  slice_tensor_1011 = None
        slice_tensor_1013 = torch.ops.aten.slice.Tensor(slice_tensor_1012, 2, -257, -1);  slice_tensor_1012 = None
        slice_tensor_1014 = torch.ops.aten.slice.Tensor(slice_tensor_1013, 3, 257, 9223372036854775807);  slice_tensor_1013 = None
        slice_tensor_1015 = torch.ops.aten.slice.Tensor(new_empty_default_58, 0, 0, 9223372036854775807)
        slice_tensor_1016 = torch.ops.aten.slice.Tensor(slice_tensor_1015, 1, 1, 9223372036854775807);  slice_tensor_1015 = None
        slice_tensor_1017 = torch.ops.aten.slice.Tensor(slice_tensor_1016, 2, 0, 9223372036854775807);  slice_tensor_1016 = None
        slice_tensor_1018 = torch.ops.aten.slice.Tensor(slice_tensor_1017, 3, 0, 256);  slice_tensor_1017 = None
        copy__default_94 = torch.ops.aten.copy_.default(slice_tensor_1018, slice_tensor_1014);  slice_tensor_1018 = slice_tensor_1014 = None
        slice_tensor_1019 = torch.ops.aten.slice.Tensor(view_default_322, 0, 0, 9223372036854775807);  view_default_322 = None
        select_int_94 = torch.ops.aten.select.int(slice_tensor_1019, 1, 0);  slice_tensor_1019 = None
        slice_tensor_1020 = torch.ops.aten.slice.Tensor(select_int_94, 1, 0, 255);  select_int_94 = None
        slice_tensor_1021 = torch.ops.aten.slice.Tensor(slice_tensor_1020, 2, -255, 9223372036854775807);  slice_tensor_1020 = None
        slice_tensor_1022 = torch.ops.aten.slice.Tensor(new_empty_default_58, 0, 0, 9223372036854775807)
        select_int_95 = torch.ops.aten.select.int(slice_tensor_1022, 1, 0);  slice_tensor_1022 = None
        slice_tensor_1023 = torch.ops.aten.slice.Tensor(select_int_95, 1, 1, 256);  select_int_95 = None
        slice_tensor_1024 = torch.ops.aten.slice.Tensor(slice_tensor_1023, 2, 1, 256);  slice_tensor_1023 = None
        copy__default_95 = torch.ops.aten.copy_.default(slice_tensor_1024, slice_tensor_1021);  slice_tensor_1024 = slice_tensor_1021 = None
        view_default_323 = torch.ops.aten.view.default(new_empty_default_58, [2, 1, 1024, 513]);  new_empty_default_58 = None
        transpose_int_173 = torch.ops.aten.transpose.int(view_default_323, 2, 1);  view_default_323 = None
        new_empty_default_59 = torch.ops.aten.new_empty.default(transpose_int_173, [256, 257], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        fill__scalar_35 = torch.ops.aten.fill_.Scalar(new_empty_default_59, 1.0);  new_empty_default_59 = None
        tril_default_23 = torch.ops.aten.tril.default(fill__scalar_35);  fill__scalar_35 = None
        flip_default_46 = torch.ops.aten.flip.default(tril_default_23, [0]);  tril_default_23 = None
        unsqueeze_default_162 = torch.ops.aten.unsqueeze.default(flip_default_46, 0);  flip_default_46 = None
        slice_tensor_1025 = torch.ops.aten.slice.Tensor(unsqueeze_default_162, 1, 0, 9223372036854775807);  unsqueeze_default_162 = None
        unsqueeze_default_163 = torch.ops.aten.unsqueeze.default(slice_tensor_1025, 2);  slice_tensor_1025 = None
        slice_tensor_1026 = torch.ops.aten.slice.Tensor(unsqueeze_default_163, 3, 0, 9223372036854775807);  unsqueeze_default_163 = None
        flip_default_47 = torch.ops.aten.flip.default(slice_tensor_1026, [1, 3])
        slice_tensor_1027 = torch.ops.aten.slice.Tensor(transpose_int_173, 0, 0, 9223372036854775807)
        slice_tensor_1028 = torch.ops.aten.slice.Tensor(slice_tensor_1027, 1, 0, 256);  slice_tensor_1027 = None
        slice_tensor_1029 = torch.ops.aten.slice.Tensor(slice_tensor_1028, 2, 0, 9223372036854775807);  slice_tensor_1028 = None
        slice_tensor_1030 = torch.ops.aten.slice.Tensor(slice_tensor_1029, 3, 0, 257);  slice_tensor_1029 = None
        expand_sym_int_46 = torch.ops.aten.expand.SymInt(slice_tensor_1026, [2, 256, 1, 257]);  slice_tensor_1026 = None
        eq_scalar_46 = torch.ops.aten.eq.Scalar(expand_sym_int_46, 1);  expand_sym_int_46 = None
        masked_fill__scalar_46 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_1030, eq_scalar_46, -inf);  slice_tensor_1030 = eq_scalar_46 = None
        slice_tensor_1031 = torch.ops.aten.slice.Tensor(transpose_int_173, 0, 0, 9223372036854775807)
        slice_tensor_1032 = torch.ops.aten.slice.Tensor(slice_tensor_1031, 1, -256, 9223372036854775807);  slice_tensor_1031 = None
        slice_tensor_1033 = torch.ops.aten.slice.Tensor(slice_tensor_1032, 2, 0, 9223372036854775807);  slice_tensor_1032 = None
        slice_tensor_1034 = torch.ops.aten.slice.Tensor(slice_tensor_1033, 3, -257, 9223372036854775807);  slice_tensor_1033 = None
        expand_sym_int_47 = torch.ops.aten.expand.SymInt(flip_default_47, [2, 256, 1, 257]);  flip_default_47 = None
        eq_scalar_47 = torch.ops.aten.eq.Scalar(expand_sym_int_47, 1);  expand_sym_int_47 = None
        masked_fill__scalar_47 = torch.ops.aten.masked_fill_.Scalar(slice_tensor_1034, eq_scalar_47, -inf);  slice_tensor_1034 = eq_scalar_47 = None
        add__tensor_11 = torch.ops.aten.add_.Tensor(transpose_int_170, transpose_int_173);  transpose_int_170 = transpose_int_173 = None
        _softmax_default_11 = torch.ops.aten._softmax.default(add__tensor_11, -1, False);  add__tensor_11 = None
        slice_tensor_1035 = torch.ops.aten.slice.Tensor(primals_195, 0, 0, 9223372036854775807);  primals_195 = None
        slice_tensor_1036 = torch.ops.aten.slice.Tensor(slice_tensor_1035, 1, 0, 9223372036854775807);  slice_tensor_1035 = None
        unsqueeze_default_164 = torch.ops.aten.unsqueeze.default(slice_tensor_1036, 2);  slice_tensor_1036 = None
        unsqueeze_default_165 = torch.ops.aten.unsqueeze.default(unsqueeze_default_164, 3);  unsqueeze_default_164 = None
        where_scalar_self_23 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_165, 0.0, _softmax_default_11)
        view_default_324 = torch.ops.aten.view.default(add_tensor_68, [1024, 2, 12, 64]);  add_tensor_68 = None
        transpose_int_174 = torch.ops.aten.transpose.int(view_default_324, 0, 1);  view_default_324 = None
        transpose_int_175 = torch.ops.aten.transpose.int(where_scalar_self_23, 1, 2);  where_scalar_self_23 = None
        clone_default_104 = torch.ops.aten.clone.default(transpose_int_175, memory_format = torch.contiguous_format);  transpose_int_175 = None
        _unsafe_view_default_151 = torch.ops.aten._unsafe_view.default(clone_default_104, [24, 4, 256, 513]);  clone_default_104 = None
        transpose_int_176 = torch.ops.aten.transpose.int(transpose_int_174, 1, 2);  transpose_int_174 = None
        view_default_325 = torch.ops.aten.view.default(transpose_int_176, [24, 1024, 64]);  transpose_int_176 = None
        constant_pad_nd_default_46 = torch.ops.aten.constant_pad_nd.default(view_default_325, [0, 0, 256, 256], -1.0);  view_default_325 = None
        as_strided_default_59 = torch.ops.aten.as_strided.default(constant_pad_nd_default_46, [24, 4, 768, 64], [98304, 16384, 64, 1]);  constant_pad_nd_default_46 = None
        constant_pad_nd_default_47 = torch.ops.aten.constant_pad_nd.default(_unsafe_view_default_151, [0, 257], 0.0);  _unsafe_view_default_151 = None
        view_default_326 = torch.ops.aten.view.default(constant_pad_nd_default_47, [24, 4, -1]);  constant_pad_nd_default_47 = None
        slice_tensor_1037 = torch.ops.aten.slice.Tensor(view_default_326, 0, 0, 9223372036854775807);  view_default_326 = None
        slice_tensor_1038 = torch.ops.aten.slice.Tensor(slice_tensor_1037, 1, 0, 9223372036854775807);  slice_tensor_1037 = None
        slice_tensor_1039 = torch.ops.aten.slice.Tensor(slice_tensor_1038, 2, 0, -256);  slice_tensor_1038 = None
        view_default_327 = torch.ops.aten.view.default(slice_tensor_1039, [24, 4, 256, 769]);  slice_tensor_1039 = None
        slice_tensor_1040 = torch.ops.aten.slice.Tensor(view_default_327, 0, 0, 9223372036854775807);  view_default_327 = None
        slice_tensor_1041 = torch.ops.aten.slice.Tensor(slice_tensor_1040, 1, 0, 9223372036854775807);  slice_tensor_1040 = None
        slice_tensor_1042 = torch.ops.aten.slice.Tensor(slice_tensor_1041, 2, 0, 9223372036854775807);  slice_tensor_1041 = None
        slice_tensor_1043 = torch.ops.aten.slice.Tensor(slice_tensor_1042, 3, 0, -1);  slice_tensor_1042 = None
        unsqueeze_default_166 = torch.ops.aten.unsqueeze.default(slice_tensor_1043, -1);  slice_tensor_1043 = None
        permute_default_139 = torch.ops.aten.permute.default(unsqueeze_default_166, [0, 1, 2, 4, 3]);  unsqueeze_default_166 = None
        unsqueeze_default_167 = torch.ops.aten.unsqueeze.default(as_strided_default_59, -1);  as_strided_default_59 = None
        permute_default_140 = torch.ops.aten.permute.default(unsqueeze_default_167, [0, 1, 4, 3, 2]);  unsqueeze_default_167 = None
        permute_default_141 = torch.ops.aten.permute.default(permute_default_139, [0, 1, 2, 4, 3]);  permute_default_139 = None
        view_default_328 = torch.ops.aten.view.default(permute_default_141, [96, 256, 768]);  permute_default_141 = None
        permute_default_142 = torch.ops.aten.permute.default(permute_default_140, [0, 1, 4, 3, 2]);  permute_default_140 = None
        clone_default_105 = torch.ops.aten.clone.default(permute_default_142, memory_format = torch.contiguous_format);  permute_default_142 = None
        _unsafe_view_default_152 = torch.ops.aten._unsafe_view.default(clone_default_105, [96, 768, 64]);  clone_default_105 = None
        bmm_default_23 = torch.ops.aten.bmm.default(view_default_328, _unsafe_view_default_152)
        view_default_329 = torch.ops.aten.view.default(bmm_default_23, [24, 4, 256, 1, 64]);  bmm_default_23 = None
        permute_default_143 = torch.ops.aten.permute.default(view_default_329, [0, 1, 2, 4, 3]);  view_default_329 = None
        view_default_330 = torch.ops.aten.view.default(permute_default_143, [24, 4, 256, 64]);  permute_default_143 = None
        view_default_331 = torch.ops.aten.view.default(view_default_330, [2, 12, 1024, 64]);  view_default_330 = None
        transpose_int_177 = torch.ops.aten.transpose.int(view_default_331, 1, 2);  view_default_331 = None
        transpose_int_178 = torch.ops.aten.transpose.int(transpose_int_177, 0, 1);  transpose_int_177 = None
        clone_default_106 = torch.ops.aten.clone.default(transpose_int_178, memory_format = torch.contiguous_format);  transpose_int_178 = None
        _unsafe_view_default_153 = torch.ops.aten._unsafe_view.default(clone_default_106, [1024, 2, 768]);  clone_default_106 = None
        transpose_int_179 = torch.ops.aten.transpose.int(_unsafe_view_default_153, 0, 1);  _unsafe_view_default_153 = None
        t_default_69 = torch.ops.aten.t.default(primals_36);  primals_36 = None
        clone_default_107 = torch.ops.aten.clone.default(transpose_int_179, memory_format = torch.contiguous_format);  transpose_int_179 = None
        _unsafe_view_default_154 = torch.ops.aten._unsafe_view.default(clone_default_107, [2048, 768]);  clone_default_107 = None
        mm_default_47 = torch.ops.aten.mm.default(_unsafe_view_default_154, t_default_69)
        _unsafe_view_default_155 = torch.ops.aten._unsafe_view.default(mm_default_47, [2, 1024, 768]);  mm_default_47 = None
        add_tensor_69 = torch.ops.aten.add.Tensor(_unsafe_view_default_155, primals_35);  _unsafe_view_default_155 = primals_35 = None
        add_tensor_70 = torch.ops.aten.add.Tensor(add_tensor_69, getitem_63);  add_tensor_69 = getitem_63 = None
        native_layer_norm_default_22 = torch.ops.aten.native_layer_norm.default(add_tensor_70, [768], primals_34, primals_33, 1e-05)
        getitem_66 = native_layer_norm_default_22[0]
        getitem_67 = native_layer_norm_default_22[1]
        getitem_68 = native_layer_norm_default_22[2];  native_layer_norm_default_22 = None
        view_default_332 = torch.ops.aten.view.default(getitem_66, [2048, 768])
        t_default_70 = torch.ops.aten.t.default(primals_44);  primals_44 = None
        addmm_default_22 = torch.ops.aten.addmm.default(primals_43, view_default_332, t_default_70);  primals_43 = None
        view_default_333 = torch.ops.aten.view.default(addmm_default_22, [2, 1024, 3072]);  addmm_default_22 = None
        gelu_default_11 = torch.ops.aten.gelu.default(view_default_333)
        view_default_334 = torch.ops.aten.view.default(gelu_default_11, [2048, 3072]);  gelu_default_11 = None
        t_default_71 = torch.ops.aten.t.default(primals_48);  primals_48 = None
        addmm_default_23 = torch.ops.aten.addmm.default(primals_47, view_default_334, t_default_71);  primals_47 = None
        view_default_335 = torch.ops.aten.view.default(addmm_default_23, [2, 1024, 768]);  addmm_default_23 = None
        add_tensor_71 = torch.ops.aten.add.Tensor(view_default_335, getitem_66);  view_default_335 = getitem_66 = None
        native_layer_norm_default_23 = torch.ops.aten.native_layer_norm.default(add_tensor_71, [768], primals_46, primals_45, 1e-05)
        getitem_69 = native_layer_norm_default_23[0]
        getitem_70 = native_layer_norm_default_23[1]
        getitem_71 = native_layer_norm_default_23[2];  native_layer_norm_default_23 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(getitem_69, tangents_1)
        native_layer_norm_backward_default = torch.ops.aten.native_layer_norm_backward.default(tangents_1, add_tensor_71, [768], getitem_70, getitem_71, primals_46, primals_45, [True, True, True]);  tangents_1 = add_tensor_71 = getitem_70 = getitem_71 = primals_46 = primals_45 = None
        getitem_72 = native_layer_norm_backward_default[0]
        getitem_73 = native_layer_norm_backward_default[1]
        getitem_74 = native_layer_norm_backward_default[2];  native_layer_norm_backward_default = None
        view_default_336 = torch.ops.aten.view.default(getitem_72, [2048, 768])
        t_default_72 = torch.ops.aten.t.default(t_default_71);  t_default_71 = None
        mm_default_48 = torch.ops.aten.mm.default(view_default_336, t_default_72);  t_default_72 = None
        t_default_73 = torch.ops.aten.t.default(view_default_336)
        mm_default_49 = torch.ops.aten.mm.default(t_default_73, view_default_334);  t_default_73 = view_default_334 = None
        t_default_74 = torch.ops.aten.t.default(mm_default_49);  mm_default_49 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(view_default_336, [0], True);  view_default_336 = None
        view_default_337 = torch.ops.aten.view.default(sum_dim_int_list, [768]);  sum_dim_int_list = None
        t_default_75 = torch.ops.aten.t.default(t_default_74);  t_default_74 = None
        view_default_338 = torch.ops.aten.view.default(mm_default_48, [2, 1024, 3072]);  mm_default_48 = None
        to_dtype = torch.ops.aten.to.dtype(view_default_338, torch.float32);  view_default_338 = None
        to_dtype_1 = torch.ops.aten.to.dtype(view_default_333, torch.float32);  view_default_333 = None
        mul_tensor_12 = torch.ops.aten.mul.Tensor(to_dtype_1, 0.7071067811865476)
        erf_default = torch.ops.aten.erf.default(mul_tensor_12);  mul_tensor_12 = None
        add_tensor_72 = torch.ops.aten.add.Tensor(erf_default, 1);  erf_default = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(add_tensor_72, 0.5);  add_tensor_72 = None
        mul_tensor_14 = torch.ops.aten.mul.Tensor(to_dtype_1, to_dtype_1)
        mul_tensor_15 = torch.ops.aten.mul.Tensor(mul_tensor_14, -0.5);  mul_tensor_14 = None
        exp_default = torch.ops.aten.exp.default(mul_tensor_15);  mul_tensor_15 = None
        mul_tensor_16 = torch.ops.aten.mul.Tensor(exp_default, 0.3989422804014327);  exp_default = None
        mul_tensor_17 = torch.ops.aten.mul.Tensor(to_dtype_1, mul_tensor_16);  to_dtype_1 = mul_tensor_16 = None
        add_tensor_73 = torch.ops.aten.add.Tensor(mul_tensor_13, mul_tensor_17);  mul_tensor_13 = mul_tensor_17 = None
        mul_tensor_18 = torch.ops.aten.mul.Tensor(to_dtype, add_tensor_73);  to_dtype = add_tensor_73 = None
        to_dtype_2 = torch.ops.aten.to.dtype(mul_tensor_18, torch.float32);  mul_tensor_18 = None
        view_default_339 = torch.ops.aten.view.default(to_dtype_2, [2048, 3072]);  to_dtype_2 = None
        t_default_76 = torch.ops.aten.t.default(t_default_70);  t_default_70 = None
        mm_default_50 = torch.ops.aten.mm.default(view_default_339, t_default_76);  t_default_76 = None
        t_default_77 = torch.ops.aten.t.default(view_default_339)
        mm_default_51 = torch.ops.aten.mm.default(t_default_77, view_default_332);  t_default_77 = view_default_332 = None
        t_default_78 = torch.ops.aten.t.default(mm_default_51);  mm_default_51 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(view_default_339, [0], True);  view_default_339 = None
        view_default_340 = torch.ops.aten.view.default(sum_dim_int_list_1, [3072]);  sum_dim_int_list_1 = None
        t_default_79 = torch.ops.aten.t.default(t_default_78);  t_default_78 = None
        view_default_341 = torch.ops.aten.view.default(mm_default_50, [2, 1024, 768]);  mm_default_50 = None
        add_tensor_74 = torch.ops.aten.add.Tensor(getitem_72, view_default_341);  getitem_72 = view_default_341 = None
        native_layer_norm_backward_default_1 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_74, add_tensor_70, [768], getitem_67, getitem_68, primals_34, primals_33, [True, True, True]);  add_tensor_74 = add_tensor_70 = getitem_67 = getitem_68 = primals_34 = primals_33 = None
        getitem_75 = native_layer_norm_backward_default_1[0]
        getitem_76 = native_layer_norm_backward_default_1[1]
        getitem_77 = native_layer_norm_backward_default_1[2];  native_layer_norm_backward_default_1 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(getitem_75, [0, 1], True)
        view_default_342 = torch.ops.aten.view.default(sum_dim_int_list_2, [768]);  sum_dim_int_list_2 = None
        view_default_343 = torch.ops.aten.view.default(getitem_75, [2048, 768])
        t_default_80 = torch.ops.aten.t.default(view_default_343)
        mm_default_52 = torch.ops.aten.mm.default(t_default_80, _unsafe_view_default_154);  t_default_80 = _unsafe_view_default_154 = None
        t_default_81 = torch.ops.aten.t.default(mm_default_52);  mm_default_52 = None
        t_default_82 = torch.ops.aten.t.default(t_default_69);  t_default_69 = None
        mm_default_53 = torch.ops.aten.mm.default(view_default_343, t_default_82);  view_default_343 = t_default_82 = None
        view_default_344 = torch.ops.aten.view.default(mm_default_53, [2, 1024, 768]);  mm_default_53 = None
        t_default_83 = torch.ops.aten.t.default(t_default_81);  t_default_81 = None
        transpose_int_180 = torch.ops.aten.transpose.int(view_default_344, 0, 1);  view_default_344 = None
        view_default_345 = torch.ops.aten.view.default(transpose_int_180, [1024, 2, 12, 64]);  transpose_int_180 = None
        transpose_int_181 = torch.ops.aten.transpose.int(view_default_345, 0, 1);  view_default_345 = None
        transpose_int_182 = torch.ops.aten.transpose.int(transpose_int_181, 1, 2);  transpose_int_181 = None
        clone_default_108 = torch.ops.aten.clone.default(transpose_int_182, memory_format = torch.contiguous_format);  transpose_int_182 = None
        _unsafe_view_default_156 = torch.ops.aten._unsafe_view.default(clone_default_108, [24, 4, 256, 64]);  clone_default_108 = None
        view_default_346 = torch.ops.aten.view.default(_unsafe_view_default_156, [24, 4, 256, 64, 1]);  _unsafe_view_default_156 = None
        permute_default_144 = torch.ops.aten.permute.default(view_default_346, [0, 1, 2, 4, 3]);  view_default_346 = None
        view_default_347 = torch.ops.aten.view.default(permute_default_144, [96, 256, 64]);  permute_default_144 = None
        transpose_int_183 = torch.ops.aten.transpose.int(view_default_328, 1, 2);  view_default_328 = None
        bmm_default_24 = torch.ops.aten.bmm.default(transpose_int_183, view_default_347);  transpose_int_183 = None
        transpose_int_184 = torch.ops.aten.transpose.int(_unsafe_view_default_152, 1, 2);  _unsafe_view_default_152 = None
        bmm_default_25 = torch.ops.aten.bmm.default(view_default_347, transpose_int_184);  view_default_347 = transpose_int_184 = None
        view_default_348 = torch.ops.aten.view.default(bmm_default_24, [24, 4, 768, 64, 1]);  bmm_default_24 = None
        permute_default_145 = torch.ops.aten.permute.default(view_default_348, [0, 1, 4, 3, 2]);  view_default_348 = None
        view_default_349 = torch.ops.aten.view.default(bmm_default_25, [24, 4, 256, 768, 1]);  bmm_default_25 = None
        permute_default_146 = torch.ops.aten.permute.default(view_default_349, [0, 1, 2, 4, 3]);  view_default_349 = None
        permute_default_147 = torch.ops.aten.permute.default(permute_default_145, [0, 1, 4, 3, 2]);  permute_default_145 = None
        squeeze_dim_24 = torch.ops.aten.squeeze.dim(permute_default_147, -1);  permute_default_147 = None
        permute_default_148 = torch.ops.aten.permute.default(permute_default_146, [0, 1, 2, 4, 3]);  permute_default_146 = None
        squeeze_dim_25 = torch.ops.aten.squeeze.dim(permute_default_148, -1);  permute_default_148 = None
        slice_backward_default = torch.ops.aten.slice_backward.default(squeeze_dim_25, [24, 4, 256, 769], 3, 0, -1, 1);  squeeze_dim_25 = None
        slice_backward_default_1 = torch.ops.aten.slice_backward.default(slice_backward_default, [24, 4, 256, 769], 2, 0, 9223372036854775807, 1);  slice_backward_default = None
        slice_backward_default_2 = torch.ops.aten.slice_backward.default(slice_backward_default_1, [24, 4, 256, 769], 1, 0, 9223372036854775807, 1);  slice_backward_default_1 = None
        slice_backward_default_3 = torch.ops.aten.slice_backward.default(slice_backward_default_2, [24, 4, 256, 769], 0, 0, 9223372036854775807, 1);  slice_backward_default_2 = None
        view_default_350 = torch.ops.aten.view.default(slice_backward_default_3, [24, 4, 196864]);  slice_backward_default_3 = None
        slice_backward_default_4 = torch.ops.aten.slice_backward.default(view_default_350, [24, 4, 197120], 2, 0, -256, 1);  view_default_350 = None
        slice_backward_default_5 = torch.ops.aten.slice_backward.default(slice_backward_default_4, [24, 4, 197120], 1, 0, 9223372036854775807, 1);  slice_backward_default_4 = None
        slice_backward_default_6 = torch.ops.aten.slice_backward.default(slice_backward_default_5, [24, 4, 197120], 0, 0, 9223372036854775807, 1);  slice_backward_default_5 = None
        view_default_351 = torch.ops.aten.view.default(slice_backward_default_6, [24, 4, 256, 770]);  slice_backward_default_6 = None
        constant_pad_nd_default_48 = torch.ops.aten.constant_pad_nd.default(view_default_351, [0, -257]);  view_default_351 = None
        new_empty_default_60 = torch.ops.aten.new_empty.default(squeeze_dim_24, [2359296])
        zero__default = torch.ops.aten.zero_.default(new_empty_default_60);  new_empty_default_60 = None
        arange = torch.ops.aten.arange.start(0, 2359296, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_60 = torch.ops.aten.as_strided.default(arange, [24, 4, 768, 64], [98304, 16384, 64, 1], 0);  arange = None
        clone_default_109 = torch.ops.aten.clone.default(as_strided_default_60, memory_format = torch.contiguous_format);  as_strided_default_60 = None
        _unsafe_view_default_157 = torch.ops.aten._unsafe_view.default(clone_default_109, [4718592]);  clone_default_109 = None
        view_default_352 = torch.ops.aten.view.default(squeeze_dim_24, [4718592]);  squeeze_dim_24 = None
        index_add__default = torch.ops.aten.index_add_.default(zero__default, 0, _unsafe_view_default_157, view_default_352);  zero__default = _unsafe_view_default_157 = view_default_352 = None
        as_strided_default_61 = torch.ops.aten.as_strided.default(index_add__default, [24, 1536, 64], [98304, 64, 1], 0);  index_add__default = None
        constant_pad_nd_default_49 = torch.ops.aten.constant_pad_nd.default(as_strided_default_61, [0, 0, -256, -256]);  as_strided_default_61 = None
        view_default_353 = torch.ops.aten.view.default(constant_pad_nd_default_49, [2, 12, 1024, 64]);  constant_pad_nd_default_49 = None
        transpose_int_185 = torch.ops.aten.transpose.int(view_default_353, 1, 2);  view_default_353 = None
        view_default_354 = torch.ops.aten.view.default(constant_pad_nd_default_48, [2, 12, 1024, 513]);  constant_pad_nd_default_48 = None
        transpose_int_186 = torch.ops.aten.transpose.int(view_default_354, 1, 2);  view_default_354 = None
        transpose_int_187 = torch.ops.aten.transpose.int(transpose_int_185, 0, 1);  transpose_int_185 = None
        clone_default_110 = torch.ops.aten.clone.default(transpose_int_187, memory_format = torch.contiguous_format);  transpose_int_187 = None
        _unsafe_view_default_158 = torch.ops.aten._unsafe_view.default(clone_default_110, [1024, 2, 768]);  clone_default_110 = None
        where_scalar_self_24 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_165, 0.0, transpose_int_186);  unsqueeze_default_165 = transpose_int_186 = None
        _softmax_backward_data_default = torch.ops.aten._softmax_backward_data.default(where_scalar_self_24, _softmax_default_11, -1, torch.float32);  where_scalar_self_24 = _softmax_default_11 = None
        new_empty_default_61 = torch.ops.aten.new_empty.default(_softmax_backward_data_default, [12607488])
        zero__default_1 = torch.ops.aten.zero_.default(new_empty_default_61);  new_empty_default_61 = None
        as_strided_default_62 = torch.ops.aten.as_strided.default(zero__default_1, [2, 1024, 12, 513], [6303744, 513, 525312, 1], 0)
        copy__default_96 = torch.ops.aten.copy_.default(as_strided_default_62, _softmax_backward_data_default);  as_strided_default_62 = _softmax_backward_data_default = None
        as_strided_default_63 = torch.ops.aten.as_strided.default(zero__default_1, [24, 4, 256, 513], [525312, 131328, 513, 1], 0);  zero__default_1 = None
        new_empty_strided_default = torch.ops.aten.new_empty_strided.default(as_strided_default_63, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_97 = torch.ops.aten.copy_.default(new_empty_strided_default, as_strided_default_63);  new_empty_strided_default = as_strided_default_63 = None
        as_strided_default_64 = torch.ops.aten.as_strided.default(copy__default_97, [2, 1024, 12, 513], [6303744, 513, 525312, 1], 0)
        clone_default_111 = torch.ops.aten.clone.default(as_strided_default_64, memory_format = torch.contiguous_format)
        copy__default_98 = torch.ops.aten.copy_.default(as_strided_default_64, clone_default_111);  as_strided_default_64 = clone_default_111 = None
        new_empty_strided_default_1 = torch.ops.aten.new_empty_strided.default(copy__default_97, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_99 = torch.ops.aten.copy_.default(new_empty_strided_default_1, copy__default_97);  new_empty_strided_default_1 = copy__default_97 = None
        as_strided_default_65 = torch.ops.aten.as_strided.default(copy__default_99, [2, 256, 12, 257], [6303744, 513, 525312, 1], 394240)
        clone_default_112 = torch.ops.aten.clone.default(as_strided_default_65, memory_format = torch.contiguous_format)
        where_scalar_self_25 = torch.ops.aten.where.ScalarSelf(eq_scalar_45, 0.0, clone_default_112);  eq_scalar_45 = clone_default_112 = None
        copy__default_100 = torch.ops.aten.copy_.default(as_strided_default_65, where_scalar_self_25);  as_strided_default_65 = where_scalar_self_25 = None
        new_empty_strided_default_2 = torch.ops.aten.new_empty_strided.default(copy__default_99, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_101 = torch.ops.aten.copy_.default(new_empty_strided_default_2, copy__default_99);  new_empty_strided_default_2 = copy__default_99 = None
        as_strided_default_66 = torch.ops.aten.as_strided.default(copy__default_101, [2, 256, 12, 257], [6303744, 513, 525312, 1], 0)
        clone_default_113 = torch.ops.aten.clone.default(as_strided_default_66, memory_format = torch.contiguous_format)
        where_scalar_self_26 = torch.ops.aten.where.ScalarSelf(eq_scalar_44, 0.0, clone_default_113);  eq_scalar_44 = clone_default_113 = None
        copy__default_102 = torch.ops.aten.copy_.default(as_strided_default_66, where_scalar_self_26);  as_strided_default_66 = where_scalar_self_26 = None
        new_empty_strided_default_3 = torch.ops.aten.new_empty_strided.default(copy__default_101, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_103 = torch.ops.aten.copy_.default(new_empty_strided_default_3, copy__default_101);  new_empty_strided_default_3 = copy__default_101 = None
        as_strided_default_67 = torch.ops.aten.as_strided.default(copy__default_103, [24, 255, 255], [525312, 513, 1], 514)
        clone_default_114 = torch.ops.aten.clone.default(as_strided_default_67, memory_format = torch.contiguous_format)
        empty_like_default = torch.ops.aten.empty_like.default(clone_default_114, memory_format = torch.contiguous_format)
        zero__default_2 = torch.ops.aten.zero_.default(empty_like_default);  empty_like_default = None
        copy__default_104 = torch.ops.aten.copy_.default(as_strided_default_67, zero__default_2);  as_strided_default_67 = zero__default_2 = None
        slice_backward_default_7 = torch.ops.aten.slice_backward.default(clone_default_114, [24, 255, 513], 2, -255, 9223372036854775807, 1);  clone_default_114 = None
        slice_backward_default_8 = torch.ops.aten.slice_backward.default(slice_backward_default_7, [24, 512, 513], 1, 0, 255, 1);  slice_backward_default_7 = None
        select_backward_default = torch.ops.aten.select_backward.default(slice_backward_default_8, [24, 3, 512, 513], 1, 0);  slice_backward_default_8 = None
        slice_backward_default_9 = torch.ops.aten.slice_backward.default(select_backward_default, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default = None
        new_empty_strided_default_4 = torch.ops.aten.new_empty_strided.default(copy__default_103, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_105 = torch.ops.aten.copy_.default(new_empty_strided_default_4, copy__default_103);  new_empty_strided_default_4 = copy__default_103 = None
        as_strided_default_68 = torch.ops.aten.as_strided.default(copy__default_105, [24, 3, 256, 256], [525312, 131328, 513, 1], 131328)
        clone_default_115 = torch.ops.aten.clone.default(as_strided_default_68, memory_format = torch.contiguous_format)
        empty_like_default_1 = torch.ops.aten.empty_like.default(clone_default_115, memory_format = torch.contiguous_format)
        zero__default_3 = torch.ops.aten.zero_.default(empty_like_default_1);  empty_like_default_1 = None
        copy__default_106 = torch.ops.aten.copy_.default(as_strided_default_68, zero__default_3);  as_strided_default_68 = zero__default_3 = None
        slice_backward_default_10 = torch.ops.aten.slice_backward.default(clone_default_115, [24, 3, 256, 513], 3, 257, 9223372036854775807, 1);  clone_default_115 = None
        slice_backward_default_11 = torch.ops.aten.slice_backward.default(slice_backward_default_10, [24, 3, 512, 513], 2, -257, -1, 1);  slice_backward_default_10 = None
        slice_backward_default_12 = torch.ops.aten.slice_backward.default(slice_backward_default_11, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_11 = None
        slice_backward_default_13 = torch.ops.aten.slice_backward.default(slice_backward_default_12, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_12 = None
        add_tensor_75 = torch.ops.aten.add.Tensor(slice_backward_default_9, slice_backward_default_13);  slice_backward_default_9 = slice_backward_default_13 = None
        new_empty_strided_default_5 = torch.ops.aten.new_empty_strided.default(copy__default_105, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_107 = torch.ops.aten.copy_.default(new_empty_strided_default_5, copy__default_105);  new_empty_strided_default_5 = copy__default_105 = None
        as_strided_default_69 = torch.ops.aten.as_strided.default(copy__default_107, [24, 256, 257], [525312, 513, 1], 394240)
        clone_default_116 = torch.ops.aten.clone.default(as_strided_default_69, memory_format = torch.contiguous_format)
        empty_like_default_2 = torch.ops.aten.empty_like.default(clone_default_116, memory_format = torch.contiguous_format)
        zero__default_4 = torch.ops.aten.zero_.default(empty_like_default_2);  empty_like_default_2 = None
        copy__default_108 = torch.ops.aten.copy_.default(as_strided_default_69, zero__default_4);  as_strided_default_69 = zero__default_4 = None
        slice_backward_default_14 = torch.ops.aten.slice_backward.default(clone_default_116, [24, 256, 513], 2, 0, 257, 1);  clone_default_116 = None
        slice_backward_default_15 = torch.ops.aten.slice_backward.default(slice_backward_default_14, [24, 512, 513], 1, 256, 9223372036854775807, 1);  slice_backward_default_14 = None
        select_backward_default_1 = torch.ops.aten.select_backward.default(slice_backward_default_15, [24, 3, 512, 513], 1, -1);  slice_backward_default_15 = None
        slice_backward_default_16 = torch.ops.aten.slice_backward.default(select_backward_default_1, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_1 = None
        add_tensor_76 = torch.ops.aten.add.Tensor(add_tensor_75, slice_backward_default_16);  add_tensor_75 = slice_backward_default_16 = None
        new_empty_strided_default_6 = torch.ops.aten.new_empty_strided.default(copy__default_107, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_109 = torch.ops.aten.copy_.default(new_empty_strided_default_6, copy__default_107);  new_empty_strided_default_6 = copy__default_107 = None
        as_strided_default_70 = torch.ops.aten.as_strided.default(copy__default_109, [24, 3, 256, 257], [525312, 131328, 513, 1], 256);  copy__default_109 = None
        clone_default_117 = torch.ops.aten.clone.default(as_strided_default_70, memory_format = torch.contiguous_format);  as_strided_default_70 = None
        slice_backward_default_17 = torch.ops.aten.slice_backward.default(clone_default_117, [24, 3, 256, 513], 3, 0, 257, 1);  clone_default_117 = None
        slice_backward_default_18 = torch.ops.aten.slice_backward.default(slice_backward_default_17, [24, 3, 512, 513], 2, 0, 256, 1);  slice_backward_default_17 = None
        slice_backward_default_19 = torch.ops.aten.slice_backward.default(slice_backward_default_18, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_18 = None
        slice_backward_default_20 = torch.ops.aten.slice_backward.default(slice_backward_default_19, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_19 = None
        add_tensor_77 = torch.ops.aten.add.Tensor(add_tensor_76, slice_backward_default_20);  add_tensor_76 = slice_backward_default_20 = None
        view_default_355 = torch.ops.aten.view.default(add_tensor_77, [24, 3, 513, 512]);  add_tensor_77 = None
        constant_pad_nd_default_50 = torch.ops.aten.constant_pad_nd.default(view_default_355, [0, 0, 0, -1]);  view_default_355 = None
        view_default_356 = torch.ops.aten.view.default(constant_pad_nd_default_50, [24, 3, 512, 512, 1]);  constant_pad_nd_default_50 = None
        permute_default_149 = torch.ops.aten.permute.default(view_default_356, [0, 1, 2, 4, 3]);  view_default_356 = None
        view_default_357 = torch.ops.aten.view.default(permute_default_149, [72, 512, 512]);  permute_default_149 = None
        transpose_int_188 = torch.ops.aten.transpose.int(_unsafe_view_default_149, 1, 2);  _unsafe_view_default_149 = None
        bmm_default_26 = torch.ops.aten.bmm.default(transpose_int_188, view_default_357);  transpose_int_188 = None
        transpose_int_189 = torch.ops.aten.transpose.int(_unsafe_view_default_150, 1, 2);  _unsafe_view_default_150 = None
        bmm_default_27 = torch.ops.aten.bmm.default(view_default_357, transpose_int_189);  view_default_357 = transpose_int_189 = None
        view_default_358 = torch.ops.aten.view.default(bmm_default_26, [24, 3, 64, 512, 1]);  bmm_default_26 = None
        permute_default_150 = torch.ops.aten.permute.default(view_default_358, [0, 1, 4, 3, 2]);  view_default_358 = None
        view_default_359 = torch.ops.aten.view.default(bmm_default_27, [24, 3, 512, 64, 1]);  bmm_default_27 = None
        permute_default_151 = torch.ops.aten.permute.default(view_default_359, [0, 1, 2, 4, 3]);  view_default_359 = None
        permute_default_152 = torch.ops.aten.permute.default(permute_default_150, [0, 1, 3, 4, 2]);  permute_default_150 = None
        squeeze_dim_26 = torch.ops.aten.squeeze.dim(permute_default_152, -1);  permute_default_152 = None
        permute_default_153 = torch.ops.aten.permute.default(permute_default_151, [0, 1, 2, 4, 3]);  permute_default_151 = None
        squeeze_dim_27 = torch.ops.aten.squeeze.dim(permute_default_153, -1);  permute_default_153 = None
        new_empty_default_62 = torch.ops.aten.new_empty.default(squeeze_dim_26, [1572864])
        zero__default_5 = torch.ops.aten.zero_.default(new_empty_default_62);  new_empty_default_62 = None
        arange_1 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_71 = torch.ops.aten.as_strided.default(arange_1, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_1 = None
        clone_default_118 = torch.ops.aten.clone.default(as_strided_default_71, memory_format = torch.contiguous_format);  as_strided_default_71 = None
        _unsafe_view_default_159 = torch.ops.aten._unsafe_view.default(clone_default_118, [2359296]);  clone_default_118 = None
        clone_default_119 = torch.ops.aten.clone.default(squeeze_dim_26, memory_format = torch.contiguous_format);  squeeze_dim_26 = None
        _unsafe_view_default_160 = torch.ops.aten._unsafe_view.default(clone_default_119, [2359296]);  clone_default_119 = None
        index_add__default_1 = torch.ops.aten.index_add_.default(zero__default_5, 0, _unsafe_view_default_159, _unsafe_view_default_160);  zero__default_5 = _unsafe_view_default_159 = _unsafe_view_default_160 = None
        as_strided_default_72 = torch.ops.aten.as_strided.default(index_add__default_1, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_1 = None
        view_default_360 = torch.ops.aten.view.default(as_strided_default_72, [24, 1024, 64]);  as_strided_default_72 = None
        new_empty_default_63 = torch.ops.aten.new_empty.default(squeeze_dim_27, [1572864])
        zero__default_6 = torch.ops.aten.zero_.default(new_empty_default_63);  new_empty_default_63 = None
        arange_2 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_73 = torch.ops.aten.as_strided.default(arange_2, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_2 = None
        clone_default_120 = torch.ops.aten.clone.default(as_strided_default_73, memory_format = torch.contiguous_format);  as_strided_default_73 = None
        _unsafe_view_default_161 = torch.ops.aten._unsafe_view.default(clone_default_120, [2359296]);  clone_default_120 = None
        view_default_361 = torch.ops.aten.view.default(squeeze_dim_27, [2359296]);  squeeze_dim_27 = None
        index_add__default_2 = torch.ops.aten.index_add_.default(zero__default_6, 0, _unsafe_view_default_161, view_default_361);  zero__default_6 = _unsafe_view_default_161 = view_default_361 = None
        as_strided_default_74 = torch.ops.aten.as_strided.default(index_add__default_2, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_2 = None
        view_default_362 = torch.ops.aten.view.default(as_strided_default_74, [24, 1024, 64]);  as_strided_default_74 = None
        view_default_363 = torch.ops.aten.view.default(view_default_360, [2, 12, 1024, 64]);  view_default_360 = None
        transpose_int_190 = torch.ops.aten.transpose.int(view_default_363, 1, 2);  view_default_363 = None
        view_default_364 = torch.ops.aten.view.default(view_default_362, [2, 12, 1024, 64]);  view_default_362 = None
        transpose_int_191 = torch.ops.aten.transpose.int(view_default_364, 1, 2);  view_default_364 = None
        transpose_int_192 = torch.ops.aten.transpose.int(transpose_int_190, 0, 1);  transpose_int_190 = None
        view_default_365 = torch.ops.aten.view.default(transpose_int_192, [1024, 2, 768]);  transpose_int_192 = None
        transpose_int_193 = torch.ops.aten.transpose.int(transpose_int_191, 0, 1);  transpose_int_191 = None
        view_default_366 = torch.ops.aten.view.default(transpose_int_193, [1024, 2, 768]);  transpose_int_193 = None
        div_tensor = torch.ops.aten.div.Tensor(view_default_366, 8.0);  view_default_366 = None
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_158, [0, 1], True)
        view_default_367 = torch.ops.aten.view.default(sum_dim_int_list_3, [768]);  sum_dim_int_list_3 = None
        view_default_368 = torch.ops.aten.view.default(_unsafe_view_default_158, [2048, 768]);  _unsafe_view_default_158 = None
        t_default_84 = torch.ops.aten.t.default(view_default_368)
        mm_default_54 = torch.ops.aten.mm.default(t_default_84, _unsafe_view_default_147);  t_default_84 = _unsafe_view_default_147 = None
        t_default_85 = torch.ops.aten.t.default(mm_default_54);  mm_default_54 = None
        t_default_86 = torch.ops.aten.t.default(t_default_68);  t_default_68 = None
        mm_default_55 = torch.ops.aten.mm.default(view_default_368, t_default_86);  view_default_368 = t_default_86 = None
        view_default_369 = torch.ops.aten.view.default(mm_default_55, [1024, 2, 768]);  mm_default_55 = None
        t_default_87 = torch.ops.aten.t.default(t_default_85);  t_default_85 = None
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(view_default_365, [0, 1], True)
        view_default_370 = torch.ops.aten.view.default(sum_dim_int_list_4, [768]);  sum_dim_int_list_4 = None
        view_default_371 = torch.ops.aten.view.default(view_default_365, [2048, 768]);  view_default_365 = None
        t_default_88 = torch.ops.aten.t.default(view_default_371)
        mm_default_56 = torch.ops.aten.mm.default(t_default_88, _unsafe_view_default_145);  t_default_88 = _unsafe_view_default_145 = None
        t_default_89 = torch.ops.aten.t.default(mm_default_56);  mm_default_56 = None
        t_default_90 = torch.ops.aten.t.default(t_default_67);  t_default_67 = None
        mm_default_57 = torch.ops.aten.mm.default(view_default_371, t_default_90);  view_default_371 = t_default_90 = None
        view_default_372 = torch.ops.aten.view.default(mm_default_57, [1024, 2, 768]);  mm_default_57 = None
        add_tensor_78 = torch.ops.aten.add.Tensor(view_default_369, view_default_372);  view_default_369 = view_default_372 = None
        t_default_91 = torch.ops.aten.t.default(t_default_89);  t_default_89 = None
        sum_dim_int_list_5 = torch.ops.aten.sum.dim_IntList(div_tensor, [0, 1], True)
        view_default_373 = torch.ops.aten.view.default(sum_dim_int_list_5, [768]);  sum_dim_int_list_5 = None
        view_default_374 = torch.ops.aten.view.default(div_tensor, [2048, 768]);  div_tensor = None
        t_default_92 = torch.ops.aten.t.default(view_default_374)
        mm_default_58 = torch.ops.aten.mm.default(t_default_92, _unsafe_view_default_143);  t_default_92 = _unsafe_view_default_143 = None
        t_default_93 = torch.ops.aten.t.default(mm_default_58);  mm_default_58 = None
        t_default_94 = torch.ops.aten.t.default(t_default_66);  t_default_66 = None
        mm_default_59 = torch.ops.aten.mm.default(view_default_374, t_default_94);  view_default_374 = t_default_94 = None
        view_default_375 = torch.ops.aten.view.default(mm_default_59, [1024, 2, 768]);  mm_default_59 = None
        add_tensor_79 = torch.ops.aten.add.Tensor(add_tensor_78, view_default_375);  add_tensor_78 = view_default_375 = None
        t_default_95 = torch.ops.aten.t.default(t_default_93);  t_default_93 = None
        transpose_int_194 = torch.ops.aten.transpose.int(add_tensor_79, 0, 1);  add_tensor_79 = None
        add_tensor_80 = torch.ops.aten.add.Tensor(getitem_75, transpose_int_194);  getitem_75 = transpose_int_194 = None
        native_layer_norm_backward_default_2 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_80, add_tensor_65, [768], getitem_64, getitem_65, primals_30, primals_29, [True, True, True]);  add_tensor_80 = add_tensor_65 = getitem_64 = getitem_65 = primals_30 = primals_29 = None
        getitem_78 = native_layer_norm_backward_default_2[0]
        getitem_79 = native_layer_norm_backward_default_2[1]
        getitem_80 = native_layer_norm_backward_default_2[2];  native_layer_norm_backward_default_2 = None
        view_default_376 = torch.ops.aten.view.default(getitem_78, [2048, 768])
        t_default_96 = torch.ops.aten.t.default(t_default_65);  t_default_65 = None
        mm_default_60 = torch.ops.aten.mm.default(view_default_376, t_default_96);  t_default_96 = None
        t_default_97 = torch.ops.aten.t.default(view_default_376)
        mm_default_61 = torch.ops.aten.mm.default(t_default_97, view_default_306);  t_default_97 = view_default_306 = None
        t_default_98 = torch.ops.aten.t.default(mm_default_61);  mm_default_61 = None
        sum_dim_int_list_6 = torch.ops.aten.sum.dim_IntList(view_default_376, [0], True);  view_default_376 = None
        view_default_377 = torch.ops.aten.view.default(sum_dim_int_list_6, [768]);  sum_dim_int_list_6 = None
        t_default_99 = torch.ops.aten.t.default(t_default_98);  t_default_98 = None
        view_default_378 = torch.ops.aten.view.default(mm_default_60, [2, 1024, 3072]);  mm_default_60 = None
        to_dtype_3 = torch.ops.aten.to.dtype(view_default_378, torch.float32);  view_default_378 = None
        to_dtype_4 = torch.ops.aten.to.dtype(view_default_305, torch.float32);  view_default_305 = None
        mul_tensor_19 = torch.ops.aten.mul.Tensor(to_dtype_4, 0.7071067811865476)
        erf_default_1 = torch.ops.aten.erf.default(mul_tensor_19);  mul_tensor_19 = None
        add_tensor_81 = torch.ops.aten.add.Tensor(erf_default_1, 1);  erf_default_1 = None
        mul_tensor_20 = torch.ops.aten.mul.Tensor(add_tensor_81, 0.5);  add_tensor_81 = None
        mul_tensor_21 = torch.ops.aten.mul.Tensor(to_dtype_4, to_dtype_4)
        mul_tensor_22 = torch.ops.aten.mul.Tensor(mul_tensor_21, -0.5);  mul_tensor_21 = None
        exp_default_1 = torch.ops.aten.exp.default(mul_tensor_22);  mul_tensor_22 = None
        mul_tensor_23 = torch.ops.aten.mul.Tensor(exp_default_1, 0.3989422804014327);  exp_default_1 = None
        mul_tensor_24 = torch.ops.aten.mul.Tensor(to_dtype_4, mul_tensor_23);  to_dtype_4 = mul_tensor_23 = None
        add_tensor_82 = torch.ops.aten.add.Tensor(mul_tensor_20, mul_tensor_24);  mul_tensor_20 = mul_tensor_24 = None
        mul_tensor_25 = torch.ops.aten.mul.Tensor(to_dtype_3, add_tensor_82);  to_dtype_3 = add_tensor_82 = None
        to_dtype_5 = torch.ops.aten.to.dtype(mul_tensor_25, torch.float32);  mul_tensor_25 = None
        view_default_379 = torch.ops.aten.view.default(to_dtype_5, [2048, 3072]);  to_dtype_5 = None
        t_default_100 = torch.ops.aten.t.default(t_default_64);  t_default_64 = None
        mm_default_62 = torch.ops.aten.mm.default(view_default_379, t_default_100);  t_default_100 = None
        t_default_101 = torch.ops.aten.t.default(view_default_379)
        mm_default_63 = torch.ops.aten.mm.default(t_default_101, view_default_304);  t_default_101 = view_default_304 = None
        t_default_102 = torch.ops.aten.t.default(mm_default_63);  mm_default_63 = None
        sum_dim_int_list_7 = torch.ops.aten.sum.dim_IntList(view_default_379, [0], True);  view_default_379 = None
        view_default_380 = torch.ops.aten.view.default(sum_dim_int_list_7, [3072]);  sum_dim_int_list_7 = None
        t_default_103 = torch.ops.aten.t.default(t_default_102);  t_default_102 = None
        view_default_381 = torch.ops.aten.view.default(mm_default_62, [2, 1024, 768]);  mm_default_62 = None
        add_tensor_83 = torch.ops.aten.add.Tensor(getitem_78, view_default_381);  getitem_78 = view_default_381 = None
        native_layer_norm_backward_default_3 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_83, add_tensor_64, [768], getitem_61, getitem_62, primals_18, primals_17, [True, True, True]);  add_tensor_83 = add_tensor_64 = getitem_61 = getitem_62 = primals_18 = primals_17 = None
        getitem_81 = native_layer_norm_backward_default_3[0]
        getitem_82 = native_layer_norm_backward_default_3[1]
        getitem_83 = native_layer_norm_backward_default_3[2];  native_layer_norm_backward_default_3 = None
        sum_dim_int_list_8 = torch.ops.aten.sum.dim_IntList(getitem_81, [0, 1], True)
        view_default_382 = torch.ops.aten.view.default(sum_dim_int_list_8, [768]);  sum_dim_int_list_8 = None
        view_default_383 = torch.ops.aten.view.default(getitem_81, [2048, 768])
        t_default_104 = torch.ops.aten.t.default(view_default_383)
        mm_default_64 = torch.ops.aten.mm.default(t_default_104, _unsafe_view_default_141);  t_default_104 = _unsafe_view_default_141 = None
        t_default_105 = torch.ops.aten.t.default(mm_default_64);  mm_default_64 = None
        t_default_106 = torch.ops.aten.t.default(t_default_63);  t_default_63 = None
        mm_default_65 = torch.ops.aten.mm.default(view_default_383, t_default_106);  view_default_383 = t_default_106 = None
        view_default_384 = torch.ops.aten.view.default(mm_default_65, [2, 1024, 768]);  mm_default_65 = None
        t_default_107 = torch.ops.aten.t.default(t_default_105);  t_default_105 = None
        transpose_int_195 = torch.ops.aten.transpose.int(view_default_384, 0, 1);  view_default_384 = None
        view_default_385 = torch.ops.aten.view.default(transpose_int_195, [1024, 2, 12, 64]);  transpose_int_195 = None
        transpose_int_196 = torch.ops.aten.transpose.int(view_default_385, 0, 1);  view_default_385 = None
        transpose_int_197 = torch.ops.aten.transpose.int(transpose_int_196, 1, 2);  transpose_int_196 = None
        clone_default_121 = torch.ops.aten.clone.default(transpose_int_197, memory_format = torch.contiguous_format);  transpose_int_197 = None
        _unsafe_view_default_162 = torch.ops.aten._unsafe_view.default(clone_default_121, [24, 4, 256, 64]);  clone_default_121 = None
        view_default_386 = torch.ops.aten.view.default(_unsafe_view_default_162, [24, 4, 256, 64, 1]);  _unsafe_view_default_162 = None
        permute_default_154 = torch.ops.aten.permute.default(view_default_386, [0, 1, 2, 4, 3]);  view_default_386 = None
        view_default_387 = torch.ops.aten.view.default(permute_default_154, [96, 256, 64]);  permute_default_154 = None
        transpose_int_198 = torch.ops.aten.transpose.int(view_default_300, 1, 2);  view_default_300 = None
        bmm_default_28 = torch.ops.aten.bmm.default(transpose_int_198, view_default_387);  transpose_int_198 = None
        transpose_int_199 = torch.ops.aten.transpose.int(_unsafe_view_default_139, 1, 2);  _unsafe_view_default_139 = None
        bmm_default_29 = torch.ops.aten.bmm.default(view_default_387, transpose_int_199);  view_default_387 = transpose_int_199 = None
        view_default_388 = torch.ops.aten.view.default(bmm_default_28, [24, 4, 768, 64, 1]);  bmm_default_28 = None
        permute_default_155 = torch.ops.aten.permute.default(view_default_388, [0, 1, 4, 3, 2]);  view_default_388 = None
        view_default_389 = torch.ops.aten.view.default(bmm_default_29, [24, 4, 256, 768, 1]);  bmm_default_29 = None
        permute_default_156 = torch.ops.aten.permute.default(view_default_389, [0, 1, 2, 4, 3]);  view_default_389 = None
        permute_default_157 = torch.ops.aten.permute.default(permute_default_155, [0, 1, 4, 3, 2]);  permute_default_155 = None
        squeeze_dim_28 = torch.ops.aten.squeeze.dim(permute_default_157, -1);  permute_default_157 = None
        permute_default_158 = torch.ops.aten.permute.default(permute_default_156, [0, 1, 2, 4, 3]);  permute_default_156 = None
        squeeze_dim_29 = torch.ops.aten.squeeze.dim(permute_default_158, -1);  permute_default_158 = None
        slice_backward_default_21 = torch.ops.aten.slice_backward.default(squeeze_dim_29, [24, 4, 256, 769], 3, 0, -1, 1);  squeeze_dim_29 = None
        slice_backward_default_22 = torch.ops.aten.slice_backward.default(slice_backward_default_21, [24, 4, 256, 769], 2, 0, 9223372036854775807, 1);  slice_backward_default_21 = None
        slice_backward_default_23 = torch.ops.aten.slice_backward.default(slice_backward_default_22, [24, 4, 256, 769], 1, 0, 9223372036854775807, 1);  slice_backward_default_22 = None
        slice_backward_default_24 = torch.ops.aten.slice_backward.default(slice_backward_default_23, [24, 4, 256, 769], 0, 0, 9223372036854775807, 1);  slice_backward_default_23 = None
        view_default_390 = torch.ops.aten.view.default(slice_backward_default_24, [24, 4, 196864]);  slice_backward_default_24 = None
        slice_backward_default_25 = torch.ops.aten.slice_backward.default(view_default_390, [24, 4, 197120], 2, 0, -256, 1);  view_default_390 = None
        slice_backward_default_26 = torch.ops.aten.slice_backward.default(slice_backward_default_25, [24, 4, 197120], 1, 0, 9223372036854775807, 1);  slice_backward_default_25 = None
        slice_backward_default_27 = torch.ops.aten.slice_backward.default(slice_backward_default_26, [24, 4, 197120], 0, 0, 9223372036854775807, 1);  slice_backward_default_26 = None
        view_default_391 = torch.ops.aten.view.default(slice_backward_default_27, [24, 4, 256, 770]);  slice_backward_default_27 = None
        constant_pad_nd_default_51 = torch.ops.aten.constant_pad_nd.default(view_default_391, [0, -257]);  view_default_391 = None
        new_empty_default_64 = torch.ops.aten.new_empty.default(squeeze_dim_28, [2359296])
        zero__default_7 = torch.ops.aten.zero_.default(new_empty_default_64);  new_empty_default_64 = None
        arange_3 = torch.ops.aten.arange.start(0, 2359296, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_75 = torch.ops.aten.as_strided.default(arange_3, [24, 4, 768, 64], [98304, 16384, 64, 1], 0);  arange_3 = None
        clone_default_122 = torch.ops.aten.clone.default(as_strided_default_75, memory_format = torch.contiguous_format);  as_strided_default_75 = None
        _unsafe_view_default_163 = torch.ops.aten._unsafe_view.default(clone_default_122, [4718592]);  clone_default_122 = None
        view_default_392 = torch.ops.aten.view.default(squeeze_dim_28, [4718592]);  squeeze_dim_28 = None
        index_add__default_3 = torch.ops.aten.index_add_.default(zero__default_7, 0, _unsafe_view_default_163, view_default_392);  zero__default_7 = _unsafe_view_default_163 = view_default_392 = None
        as_strided_default_76 = torch.ops.aten.as_strided.default(index_add__default_3, [24, 1536, 64], [98304, 64, 1], 0);  index_add__default_3 = None
        constant_pad_nd_default_52 = torch.ops.aten.constant_pad_nd.default(as_strided_default_76, [0, 0, -256, -256]);  as_strided_default_76 = None
        view_default_393 = torch.ops.aten.view.default(constant_pad_nd_default_52, [2, 12, 1024, 64]);  constant_pad_nd_default_52 = None
        transpose_int_200 = torch.ops.aten.transpose.int(view_default_393, 1, 2);  view_default_393 = None
        view_default_394 = torch.ops.aten.view.default(constant_pad_nd_default_51, [2, 12, 1024, 513]);  constant_pad_nd_default_51 = None
        transpose_int_201 = torch.ops.aten.transpose.int(view_default_394, 1, 2);  view_default_394 = None
        transpose_int_202 = torch.ops.aten.transpose.int(transpose_int_200, 0, 1);  transpose_int_200 = None
        clone_default_123 = torch.ops.aten.clone.default(transpose_int_202, memory_format = torch.contiguous_format);  transpose_int_202 = None
        _unsafe_view_default_164 = torch.ops.aten._unsafe_view.default(clone_default_123, [1024, 2, 768]);  clone_default_123 = None
        where_scalar_self_27 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_151, 0.0, transpose_int_201);  unsqueeze_default_151 = transpose_int_201 = None
        _softmax_backward_data_default_1 = torch.ops.aten._softmax_backward_data.default(where_scalar_self_27, _softmax_default_10, -1, torch.float32);  where_scalar_self_27 = _softmax_default_10 = None
        new_empty_default_65 = torch.ops.aten.new_empty.default(_softmax_backward_data_default_1, [12607488])
        zero__default_8 = torch.ops.aten.zero_.default(new_empty_default_65);  new_empty_default_65 = None
        as_strided_default_77 = torch.ops.aten.as_strided.default(zero__default_8, [2, 1024, 12, 513], [6303744, 513, 525312, 1], 0)
        copy__default_110 = torch.ops.aten.copy_.default(as_strided_default_77, _softmax_backward_data_default_1);  as_strided_default_77 = _softmax_backward_data_default_1 = None
        as_strided_default_78 = torch.ops.aten.as_strided.default(zero__default_8, [24, 4, 256, 513], [525312, 131328, 513, 1], 0);  zero__default_8 = None
        new_empty_strided_default_7 = torch.ops.aten.new_empty_strided.default(as_strided_default_78, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_111 = torch.ops.aten.copy_.default(new_empty_strided_default_7, as_strided_default_78);  new_empty_strided_default_7 = as_strided_default_78 = None
        as_strided_default_79 = torch.ops.aten.as_strided.default(copy__default_111, [2, 1024, 12, 513], [6303744, 513, 525312, 1], 0)
        clone_default_124 = torch.ops.aten.clone.default(as_strided_default_79, memory_format = torch.contiguous_format)
        copy__default_112 = torch.ops.aten.copy_.default(as_strided_default_79, clone_default_124);  as_strided_default_79 = clone_default_124 = None
        new_empty_strided_default_8 = torch.ops.aten.new_empty_strided.default(copy__default_111, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_113 = torch.ops.aten.copy_.default(new_empty_strided_default_8, copy__default_111);  new_empty_strided_default_8 = copy__default_111 = None
        as_strided_default_80 = torch.ops.aten.as_strided.default(copy__default_113, [2, 256, 12, 257], [6303744, 513, 525312, 1], 394240)
        clone_default_125 = torch.ops.aten.clone.default(as_strided_default_80, memory_format = torch.contiguous_format)
        where_scalar_self_28 = torch.ops.aten.where.ScalarSelf(eq_scalar_41, 0.0, clone_default_125);  eq_scalar_41 = clone_default_125 = None
        copy__default_114 = torch.ops.aten.copy_.default(as_strided_default_80, where_scalar_self_28);  as_strided_default_80 = where_scalar_self_28 = None
        new_empty_strided_default_9 = torch.ops.aten.new_empty_strided.default(copy__default_113, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_115 = torch.ops.aten.copy_.default(new_empty_strided_default_9, copy__default_113);  new_empty_strided_default_9 = copy__default_113 = None
        as_strided_default_81 = torch.ops.aten.as_strided.default(copy__default_115, [2, 256, 12, 257], [6303744, 513, 525312, 1], 0)
        clone_default_126 = torch.ops.aten.clone.default(as_strided_default_81, memory_format = torch.contiguous_format)
        where_scalar_self_29 = torch.ops.aten.where.ScalarSelf(eq_scalar_40, 0.0, clone_default_126);  eq_scalar_40 = clone_default_126 = None
        copy__default_116 = torch.ops.aten.copy_.default(as_strided_default_81, where_scalar_self_29);  as_strided_default_81 = where_scalar_self_29 = None
        new_empty_strided_default_10 = torch.ops.aten.new_empty_strided.default(copy__default_115, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_117 = torch.ops.aten.copy_.default(new_empty_strided_default_10, copy__default_115);  new_empty_strided_default_10 = copy__default_115 = None
        as_strided_default_82 = torch.ops.aten.as_strided.default(copy__default_117, [24, 255, 255], [525312, 513, 1], 514)
        clone_default_127 = torch.ops.aten.clone.default(as_strided_default_82, memory_format = torch.contiguous_format)
        empty_like_default_3 = torch.ops.aten.empty_like.default(clone_default_127, memory_format = torch.contiguous_format)
        zero__default_9 = torch.ops.aten.zero_.default(empty_like_default_3);  empty_like_default_3 = None
        copy__default_118 = torch.ops.aten.copy_.default(as_strided_default_82, zero__default_9);  as_strided_default_82 = zero__default_9 = None
        slice_backward_default_28 = torch.ops.aten.slice_backward.default(clone_default_127, [24, 255, 513], 2, -255, 9223372036854775807, 1);  clone_default_127 = None
        slice_backward_default_29 = torch.ops.aten.slice_backward.default(slice_backward_default_28, [24, 512, 513], 1, 0, 255, 1);  slice_backward_default_28 = None
        select_backward_default_2 = torch.ops.aten.select_backward.default(slice_backward_default_29, [24, 3, 512, 513], 1, 0);  slice_backward_default_29 = None
        slice_backward_default_30 = torch.ops.aten.slice_backward.default(select_backward_default_2, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_2 = None
        new_empty_strided_default_11 = torch.ops.aten.new_empty_strided.default(copy__default_117, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_119 = torch.ops.aten.copy_.default(new_empty_strided_default_11, copy__default_117);  new_empty_strided_default_11 = copy__default_117 = None
        as_strided_default_83 = torch.ops.aten.as_strided.default(copy__default_119, [24, 3, 256, 256], [525312, 131328, 513, 1], 131328)
        clone_default_128 = torch.ops.aten.clone.default(as_strided_default_83, memory_format = torch.contiguous_format)
        empty_like_default_4 = torch.ops.aten.empty_like.default(clone_default_128, memory_format = torch.contiguous_format)
        zero__default_10 = torch.ops.aten.zero_.default(empty_like_default_4);  empty_like_default_4 = None
        copy__default_120 = torch.ops.aten.copy_.default(as_strided_default_83, zero__default_10);  as_strided_default_83 = zero__default_10 = None
        slice_backward_default_31 = torch.ops.aten.slice_backward.default(clone_default_128, [24, 3, 256, 513], 3, 257, 9223372036854775807, 1);  clone_default_128 = None
        slice_backward_default_32 = torch.ops.aten.slice_backward.default(slice_backward_default_31, [24, 3, 512, 513], 2, -257, -1, 1);  slice_backward_default_31 = None
        slice_backward_default_33 = torch.ops.aten.slice_backward.default(slice_backward_default_32, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_32 = None
        slice_backward_default_34 = torch.ops.aten.slice_backward.default(slice_backward_default_33, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_33 = None
        add_tensor_84 = torch.ops.aten.add.Tensor(slice_backward_default_30, slice_backward_default_34);  slice_backward_default_30 = slice_backward_default_34 = None
        new_empty_strided_default_12 = torch.ops.aten.new_empty_strided.default(copy__default_119, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_121 = torch.ops.aten.copy_.default(new_empty_strided_default_12, copy__default_119);  new_empty_strided_default_12 = copy__default_119 = None
        as_strided_default_84 = torch.ops.aten.as_strided.default(copy__default_121, [24, 256, 257], [525312, 513, 1], 394240)
        clone_default_129 = torch.ops.aten.clone.default(as_strided_default_84, memory_format = torch.contiguous_format)
        empty_like_default_5 = torch.ops.aten.empty_like.default(clone_default_129, memory_format = torch.contiguous_format)
        zero__default_11 = torch.ops.aten.zero_.default(empty_like_default_5);  empty_like_default_5 = None
        copy__default_122 = torch.ops.aten.copy_.default(as_strided_default_84, zero__default_11);  as_strided_default_84 = zero__default_11 = None
        slice_backward_default_35 = torch.ops.aten.slice_backward.default(clone_default_129, [24, 256, 513], 2, 0, 257, 1);  clone_default_129 = None
        slice_backward_default_36 = torch.ops.aten.slice_backward.default(slice_backward_default_35, [24, 512, 513], 1, 256, 9223372036854775807, 1);  slice_backward_default_35 = None
        select_backward_default_3 = torch.ops.aten.select_backward.default(slice_backward_default_36, [24, 3, 512, 513], 1, -1);  slice_backward_default_36 = None
        slice_backward_default_37 = torch.ops.aten.slice_backward.default(select_backward_default_3, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_3 = None
        add_tensor_85 = torch.ops.aten.add.Tensor(add_tensor_84, slice_backward_default_37);  add_tensor_84 = slice_backward_default_37 = None
        new_empty_strided_default_13 = torch.ops.aten.new_empty_strided.default(copy__default_121, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_123 = torch.ops.aten.copy_.default(new_empty_strided_default_13, copy__default_121);  new_empty_strided_default_13 = copy__default_121 = None
        as_strided_default_85 = torch.ops.aten.as_strided.default(copy__default_123, [24, 3, 256, 257], [525312, 131328, 513, 1], 256);  copy__default_123 = None
        clone_default_130 = torch.ops.aten.clone.default(as_strided_default_85, memory_format = torch.contiguous_format);  as_strided_default_85 = None
        slice_backward_default_38 = torch.ops.aten.slice_backward.default(clone_default_130, [24, 3, 256, 513], 3, 0, 257, 1);  clone_default_130 = None
        slice_backward_default_39 = torch.ops.aten.slice_backward.default(slice_backward_default_38, [24, 3, 512, 513], 2, 0, 256, 1);  slice_backward_default_38 = None
        slice_backward_default_40 = torch.ops.aten.slice_backward.default(slice_backward_default_39, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_39 = None
        slice_backward_default_41 = torch.ops.aten.slice_backward.default(slice_backward_default_40, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_40 = None
        add_tensor_86 = torch.ops.aten.add.Tensor(add_tensor_85, slice_backward_default_41);  add_tensor_85 = slice_backward_default_41 = None
        view_default_395 = torch.ops.aten.view.default(add_tensor_86, [24, 3, 513, 512]);  add_tensor_86 = None
        constant_pad_nd_default_53 = torch.ops.aten.constant_pad_nd.default(view_default_395, [0, 0, 0, -1]);  view_default_395 = None
        view_default_396 = torch.ops.aten.view.default(constant_pad_nd_default_53, [24, 3, 512, 512, 1]);  constant_pad_nd_default_53 = None
        permute_default_159 = torch.ops.aten.permute.default(view_default_396, [0, 1, 2, 4, 3]);  view_default_396 = None
        view_default_397 = torch.ops.aten.view.default(permute_default_159, [72, 512, 512]);  permute_default_159 = None
        transpose_int_203 = torch.ops.aten.transpose.int(_unsafe_view_default_136, 1, 2);  _unsafe_view_default_136 = None
        bmm_default_30 = torch.ops.aten.bmm.default(transpose_int_203, view_default_397);  transpose_int_203 = None
        transpose_int_204 = torch.ops.aten.transpose.int(_unsafe_view_default_137, 1, 2);  _unsafe_view_default_137 = None
        bmm_default_31 = torch.ops.aten.bmm.default(view_default_397, transpose_int_204);  view_default_397 = transpose_int_204 = None
        view_default_398 = torch.ops.aten.view.default(bmm_default_30, [24, 3, 64, 512, 1]);  bmm_default_30 = None
        permute_default_160 = torch.ops.aten.permute.default(view_default_398, [0, 1, 4, 3, 2]);  view_default_398 = None
        view_default_399 = torch.ops.aten.view.default(bmm_default_31, [24, 3, 512, 64, 1]);  bmm_default_31 = None
        permute_default_161 = torch.ops.aten.permute.default(view_default_399, [0, 1, 2, 4, 3]);  view_default_399 = None
        permute_default_162 = torch.ops.aten.permute.default(permute_default_160, [0, 1, 3, 4, 2]);  permute_default_160 = None
        squeeze_dim_30 = torch.ops.aten.squeeze.dim(permute_default_162, -1);  permute_default_162 = None
        permute_default_163 = torch.ops.aten.permute.default(permute_default_161, [0, 1, 2, 4, 3]);  permute_default_161 = None
        squeeze_dim_31 = torch.ops.aten.squeeze.dim(permute_default_163, -1);  permute_default_163 = None
        new_empty_default_66 = torch.ops.aten.new_empty.default(squeeze_dim_30, [1572864])
        zero__default_12 = torch.ops.aten.zero_.default(new_empty_default_66);  new_empty_default_66 = None
        arange_4 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_86 = torch.ops.aten.as_strided.default(arange_4, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_4 = None
        clone_default_131 = torch.ops.aten.clone.default(as_strided_default_86, memory_format = torch.contiguous_format);  as_strided_default_86 = None
        _unsafe_view_default_165 = torch.ops.aten._unsafe_view.default(clone_default_131, [2359296]);  clone_default_131 = None
        clone_default_132 = torch.ops.aten.clone.default(squeeze_dim_30, memory_format = torch.contiguous_format);  squeeze_dim_30 = None
        _unsafe_view_default_166 = torch.ops.aten._unsafe_view.default(clone_default_132, [2359296]);  clone_default_132 = None
        index_add__default_4 = torch.ops.aten.index_add_.default(zero__default_12, 0, _unsafe_view_default_165, _unsafe_view_default_166);  zero__default_12 = _unsafe_view_default_165 = _unsafe_view_default_166 = None
        as_strided_default_87 = torch.ops.aten.as_strided.default(index_add__default_4, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_4 = None
        view_default_400 = torch.ops.aten.view.default(as_strided_default_87, [24, 1024, 64]);  as_strided_default_87 = None
        new_empty_default_67 = torch.ops.aten.new_empty.default(squeeze_dim_31, [1572864])
        zero__default_13 = torch.ops.aten.zero_.default(new_empty_default_67);  new_empty_default_67 = None
        arange_5 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_88 = torch.ops.aten.as_strided.default(arange_5, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_5 = None
        clone_default_133 = torch.ops.aten.clone.default(as_strided_default_88, memory_format = torch.contiguous_format);  as_strided_default_88 = None
        _unsafe_view_default_167 = torch.ops.aten._unsafe_view.default(clone_default_133, [2359296]);  clone_default_133 = None
        view_default_401 = torch.ops.aten.view.default(squeeze_dim_31, [2359296]);  squeeze_dim_31 = None
        index_add__default_5 = torch.ops.aten.index_add_.default(zero__default_13, 0, _unsafe_view_default_167, view_default_401);  zero__default_13 = _unsafe_view_default_167 = view_default_401 = None
        as_strided_default_89 = torch.ops.aten.as_strided.default(index_add__default_5, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_5 = None
        view_default_402 = torch.ops.aten.view.default(as_strided_default_89, [24, 1024, 64]);  as_strided_default_89 = None
        view_default_403 = torch.ops.aten.view.default(view_default_400, [2, 12, 1024, 64]);  view_default_400 = None
        transpose_int_205 = torch.ops.aten.transpose.int(view_default_403, 1, 2);  view_default_403 = None
        view_default_404 = torch.ops.aten.view.default(view_default_402, [2, 12, 1024, 64]);  view_default_402 = None
        transpose_int_206 = torch.ops.aten.transpose.int(view_default_404, 1, 2);  view_default_404 = None
        transpose_int_207 = torch.ops.aten.transpose.int(transpose_int_205, 0, 1);  transpose_int_205 = None
        view_default_405 = torch.ops.aten.view.default(transpose_int_207, [1024, 2, 768]);  transpose_int_207 = None
        transpose_int_208 = torch.ops.aten.transpose.int(transpose_int_206, 0, 1);  transpose_int_206 = None
        view_default_406 = torch.ops.aten.view.default(transpose_int_208, [1024, 2, 768]);  transpose_int_208 = None
        div_tensor_1 = torch.ops.aten.div.Tensor(view_default_406, 8.0);  view_default_406 = None
        sum_dim_int_list_9 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_164, [0, 1], True)
        view_default_407 = torch.ops.aten.view.default(sum_dim_int_list_9, [768]);  sum_dim_int_list_9 = None
        view_default_408 = torch.ops.aten.view.default(_unsafe_view_default_164, [2048, 768]);  _unsafe_view_default_164 = None
        t_default_108 = torch.ops.aten.t.default(view_default_408)
        mm_default_66 = torch.ops.aten.mm.default(t_default_108, _unsafe_view_default_134);  t_default_108 = _unsafe_view_default_134 = None
        t_default_109 = torch.ops.aten.t.default(mm_default_66);  mm_default_66 = None
        t_default_110 = torch.ops.aten.t.default(t_default_62);  t_default_62 = None
        mm_default_67 = torch.ops.aten.mm.default(view_default_408, t_default_110);  view_default_408 = t_default_110 = None
        view_default_409 = torch.ops.aten.view.default(mm_default_67, [1024, 2, 768]);  mm_default_67 = None
        t_default_111 = torch.ops.aten.t.default(t_default_109);  t_default_109 = None
        sum_dim_int_list_10 = torch.ops.aten.sum.dim_IntList(view_default_405, [0, 1], True)
        view_default_410 = torch.ops.aten.view.default(sum_dim_int_list_10, [768]);  sum_dim_int_list_10 = None
        view_default_411 = torch.ops.aten.view.default(view_default_405, [2048, 768]);  view_default_405 = None
        t_default_112 = torch.ops.aten.t.default(view_default_411)
        mm_default_68 = torch.ops.aten.mm.default(t_default_112, _unsafe_view_default_132);  t_default_112 = _unsafe_view_default_132 = None
        t_default_113 = torch.ops.aten.t.default(mm_default_68);  mm_default_68 = None
        t_default_114 = torch.ops.aten.t.default(t_default_61);  t_default_61 = None
        mm_default_69 = torch.ops.aten.mm.default(view_default_411, t_default_114);  view_default_411 = t_default_114 = None
        view_default_412 = torch.ops.aten.view.default(mm_default_69, [1024, 2, 768]);  mm_default_69 = None
        add_tensor_87 = torch.ops.aten.add.Tensor(view_default_409, view_default_412);  view_default_409 = view_default_412 = None
        t_default_115 = torch.ops.aten.t.default(t_default_113);  t_default_113 = None
        sum_dim_int_list_11 = torch.ops.aten.sum.dim_IntList(div_tensor_1, [0, 1], True)
        view_default_413 = torch.ops.aten.view.default(sum_dim_int_list_11, [768]);  sum_dim_int_list_11 = None
        view_default_414 = torch.ops.aten.view.default(div_tensor_1, [2048, 768]);  div_tensor_1 = None
        t_default_116 = torch.ops.aten.t.default(view_default_414)
        mm_default_70 = torch.ops.aten.mm.default(t_default_116, _unsafe_view_default_130);  t_default_116 = _unsafe_view_default_130 = None
        t_default_117 = torch.ops.aten.t.default(mm_default_70);  mm_default_70 = None
        t_default_118 = torch.ops.aten.t.default(t_default_60);  t_default_60 = None
        mm_default_71 = torch.ops.aten.mm.default(view_default_414, t_default_118);  view_default_414 = t_default_118 = None
        view_default_415 = torch.ops.aten.view.default(mm_default_71, [1024, 2, 768]);  mm_default_71 = None
        add_tensor_88 = torch.ops.aten.add.Tensor(add_tensor_87, view_default_415);  add_tensor_87 = view_default_415 = None
        t_default_119 = torch.ops.aten.t.default(t_default_117);  t_default_117 = None
        transpose_int_209 = torch.ops.aten.transpose.int(add_tensor_88, 0, 1);  add_tensor_88 = None
        add_tensor_89 = torch.ops.aten.add.Tensor(getitem_81, transpose_int_209);  getitem_81 = transpose_int_209 = None
        native_layer_norm_backward_default_4 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_89, add_tensor_59, [768], getitem_58, getitem_59, primals_190, primals_189, [True, True, True]);  add_tensor_89 = add_tensor_59 = getitem_58 = getitem_59 = primals_190 = primals_189 = None
        getitem_84 = native_layer_norm_backward_default_4[0]
        getitem_85 = native_layer_norm_backward_default_4[1]
        getitem_86 = native_layer_norm_backward_default_4[2];  native_layer_norm_backward_default_4 = None
        view_default_416 = torch.ops.aten.view.default(getitem_84, [2048, 768])
        t_default_120 = torch.ops.aten.t.default(t_default_59);  t_default_59 = None
        mm_default_72 = torch.ops.aten.mm.default(view_default_416, t_default_120);  t_default_120 = None
        t_default_121 = torch.ops.aten.t.default(view_default_416)
        mm_default_73 = torch.ops.aten.mm.default(t_default_121, view_default_278);  t_default_121 = view_default_278 = None
        t_default_122 = torch.ops.aten.t.default(mm_default_73);  mm_default_73 = None
        sum_dim_int_list_12 = torch.ops.aten.sum.dim_IntList(view_default_416, [0], True);  view_default_416 = None
        view_default_417 = torch.ops.aten.view.default(sum_dim_int_list_12, [768]);  sum_dim_int_list_12 = None
        t_default_123 = torch.ops.aten.t.default(t_default_122);  t_default_122 = None
        view_default_418 = torch.ops.aten.view.default(mm_default_72, [2, 1024, 3072]);  mm_default_72 = None
        to_dtype_6 = torch.ops.aten.to.dtype(view_default_418, torch.float32);  view_default_418 = None
        to_dtype_7 = torch.ops.aten.to.dtype(view_default_277, torch.float32);  view_default_277 = None
        mul_tensor_26 = torch.ops.aten.mul.Tensor(to_dtype_7, 0.7071067811865476)
        erf_default_2 = torch.ops.aten.erf.default(mul_tensor_26);  mul_tensor_26 = None
        add_tensor_90 = torch.ops.aten.add.Tensor(erf_default_2, 1);  erf_default_2 = None
        mul_tensor_27 = torch.ops.aten.mul.Tensor(add_tensor_90, 0.5);  add_tensor_90 = None
        mul_tensor_28 = torch.ops.aten.mul.Tensor(to_dtype_7, to_dtype_7)
        mul_tensor_29 = torch.ops.aten.mul.Tensor(mul_tensor_28, -0.5);  mul_tensor_28 = None
        exp_default_2 = torch.ops.aten.exp.default(mul_tensor_29);  mul_tensor_29 = None
        mul_tensor_30 = torch.ops.aten.mul.Tensor(exp_default_2, 0.3989422804014327);  exp_default_2 = None
        mul_tensor_31 = torch.ops.aten.mul.Tensor(to_dtype_7, mul_tensor_30);  to_dtype_7 = mul_tensor_30 = None
        add_tensor_91 = torch.ops.aten.add.Tensor(mul_tensor_27, mul_tensor_31);  mul_tensor_27 = mul_tensor_31 = None
        mul_tensor_32 = torch.ops.aten.mul.Tensor(to_dtype_6, add_tensor_91);  to_dtype_6 = add_tensor_91 = None
        to_dtype_8 = torch.ops.aten.to.dtype(mul_tensor_32, torch.float32);  mul_tensor_32 = None
        view_default_419 = torch.ops.aten.view.default(to_dtype_8, [2048, 3072]);  to_dtype_8 = None
        t_default_124 = torch.ops.aten.t.default(t_default_58);  t_default_58 = None
        mm_default_74 = torch.ops.aten.mm.default(view_default_419, t_default_124);  t_default_124 = None
        t_default_125 = torch.ops.aten.t.default(view_default_419)
        mm_default_75 = torch.ops.aten.mm.default(t_default_125, view_default_276);  t_default_125 = view_default_276 = None
        t_default_126 = torch.ops.aten.t.default(mm_default_75);  mm_default_75 = None
        sum_dim_int_list_13 = torch.ops.aten.sum.dim_IntList(view_default_419, [0], True);  view_default_419 = None
        view_default_420 = torch.ops.aten.view.default(sum_dim_int_list_13, [3072]);  sum_dim_int_list_13 = None
        t_default_127 = torch.ops.aten.t.default(t_default_126);  t_default_126 = None
        view_default_421 = torch.ops.aten.view.default(mm_default_74, [2, 1024, 768]);  mm_default_74 = None
        add_tensor_92 = torch.ops.aten.add.Tensor(getitem_84, view_default_421);  getitem_84 = view_default_421 = None
        native_layer_norm_backward_default_5 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_92, add_tensor_58, [768], getitem_55, getitem_56, primals_178, primals_177, [True, True, True]);  add_tensor_92 = add_tensor_58 = getitem_55 = getitem_56 = primals_178 = primals_177 = None
        getitem_87 = native_layer_norm_backward_default_5[0]
        getitem_88 = native_layer_norm_backward_default_5[1]
        getitem_89 = native_layer_norm_backward_default_5[2];  native_layer_norm_backward_default_5 = None
        sum_dim_int_list_14 = torch.ops.aten.sum.dim_IntList(getitem_87, [0, 1], True)
        view_default_422 = torch.ops.aten.view.default(sum_dim_int_list_14, [768]);  sum_dim_int_list_14 = None
        view_default_423 = torch.ops.aten.view.default(getitem_87, [2048, 768])
        t_default_128 = torch.ops.aten.t.default(view_default_423)
        mm_default_76 = torch.ops.aten.mm.default(t_default_128, _unsafe_view_default_128);  t_default_128 = _unsafe_view_default_128 = None
        t_default_129 = torch.ops.aten.t.default(mm_default_76);  mm_default_76 = None
        t_default_130 = torch.ops.aten.t.default(t_default_57);  t_default_57 = None
        mm_default_77 = torch.ops.aten.mm.default(view_default_423, t_default_130);  view_default_423 = t_default_130 = None
        view_default_424 = torch.ops.aten.view.default(mm_default_77, [2, 1024, 768]);  mm_default_77 = None
        t_default_131 = torch.ops.aten.t.default(t_default_129);  t_default_129 = None
        transpose_int_210 = torch.ops.aten.transpose.int(view_default_424, 0, 1);  view_default_424 = None
        view_default_425 = torch.ops.aten.view.default(transpose_int_210, [1024, 2, 12, 64]);  transpose_int_210 = None
        transpose_int_211 = torch.ops.aten.transpose.int(view_default_425, 0, 1);  view_default_425 = None
        transpose_int_212 = torch.ops.aten.transpose.int(transpose_int_211, 1, 2);  transpose_int_211 = None
        clone_default_134 = torch.ops.aten.clone.default(transpose_int_212, memory_format = torch.contiguous_format);  transpose_int_212 = None
        _unsafe_view_default_168 = torch.ops.aten._unsafe_view.default(clone_default_134, [24, 4, 256, 64]);  clone_default_134 = None
        view_default_426 = torch.ops.aten.view.default(_unsafe_view_default_168, [24, 4, 256, 64, 1]);  _unsafe_view_default_168 = None
        permute_default_164 = torch.ops.aten.permute.default(view_default_426, [0, 1, 2, 4, 3]);  view_default_426 = None
        view_default_427 = torch.ops.aten.view.default(permute_default_164, [96, 256, 64]);  permute_default_164 = None
        transpose_int_213 = torch.ops.aten.transpose.int(view_default_272, 1, 2);  view_default_272 = None
        bmm_default_32 = torch.ops.aten.bmm.default(transpose_int_213, view_default_427);  transpose_int_213 = None
        transpose_int_214 = torch.ops.aten.transpose.int(_unsafe_view_default_126, 1, 2);  _unsafe_view_default_126 = None
        bmm_default_33 = torch.ops.aten.bmm.default(view_default_427, transpose_int_214);  view_default_427 = transpose_int_214 = None
        view_default_428 = torch.ops.aten.view.default(bmm_default_32, [24, 4, 768, 64, 1]);  bmm_default_32 = None
        permute_default_165 = torch.ops.aten.permute.default(view_default_428, [0, 1, 4, 3, 2]);  view_default_428 = None
        view_default_429 = torch.ops.aten.view.default(bmm_default_33, [24, 4, 256, 768, 1]);  bmm_default_33 = None
        permute_default_166 = torch.ops.aten.permute.default(view_default_429, [0, 1, 2, 4, 3]);  view_default_429 = None
        permute_default_167 = torch.ops.aten.permute.default(permute_default_165, [0, 1, 4, 3, 2]);  permute_default_165 = None
        squeeze_dim_32 = torch.ops.aten.squeeze.dim(permute_default_167, -1);  permute_default_167 = None
        permute_default_168 = torch.ops.aten.permute.default(permute_default_166, [0, 1, 2, 4, 3]);  permute_default_166 = None
        squeeze_dim_33 = torch.ops.aten.squeeze.dim(permute_default_168, -1);  permute_default_168 = None
        slice_backward_default_42 = torch.ops.aten.slice_backward.default(squeeze_dim_33, [24, 4, 256, 769], 3, 0, -1, 1);  squeeze_dim_33 = None
        slice_backward_default_43 = torch.ops.aten.slice_backward.default(slice_backward_default_42, [24, 4, 256, 769], 2, 0, 9223372036854775807, 1);  slice_backward_default_42 = None
        slice_backward_default_44 = torch.ops.aten.slice_backward.default(slice_backward_default_43, [24, 4, 256, 769], 1, 0, 9223372036854775807, 1);  slice_backward_default_43 = None
        slice_backward_default_45 = torch.ops.aten.slice_backward.default(slice_backward_default_44, [24, 4, 256, 769], 0, 0, 9223372036854775807, 1);  slice_backward_default_44 = None
        view_default_430 = torch.ops.aten.view.default(slice_backward_default_45, [24, 4, 196864]);  slice_backward_default_45 = None
        slice_backward_default_46 = torch.ops.aten.slice_backward.default(view_default_430, [24, 4, 197120], 2, 0, -256, 1);  view_default_430 = None
        slice_backward_default_47 = torch.ops.aten.slice_backward.default(slice_backward_default_46, [24, 4, 197120], 1, 0, 9223372036854775807, 1);  slice_backward_default_46 = None
        slice_backward_default_48 = torch.ops.aten.slice_backward.default(slice_backward_default_47, [24, 4, 197120], 0, 0, 9223372036854775807, 1);  slice_backward_default_47 = None
        view_default_431 = torch.ops.aten.view.default(slice_backward_default_48, [24, 4, 256, 770]);  slice_backward_default_48 = None
        constant_pad_nd_default_54 = torch.ops.aten.constant_pad_nd.default(view_default_431, [0, -257]);  view_default_431 = None
        new_empty_default_68 = torch.ops.aten.new_empty.default(squeeze_dim_32, [2359296])
        zero__default_14 = torch.ops.aten.zero_.default(new_empty_default_68);  new_empty_default_68 = None
        arange_6 = torch.ops.aten.arange.start(0, 2359296, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_90 = torch.ops.aten.as_strided.default(arange_6, [24, 4, 768, 64], [98304, 16384, 64, 1], 0);  arange_6 = None
        clone_default_135 = torch.ops.aten.clone.default(as_strided_default_90, memory_format = torch.contiguous_format);  as_strided_default_90 = None
        _unsafe_view_default_169 = torch.ops.aten._unsafe_view.default(clone_default_135, [4718592]);  clone_default_135 = None
        view_default_432 = torch.ops.aten.view.default(squeeze_dim_32, [4718592]);  squeeze_dim_32 = None
        index_add__default_6 = torch.ops.aten.index_add_.default(zero__default_14, 0, _unsafe_view_default_169, view_default_432);  zero__default_14 = _unsafe_view_default_169 = view_default_432 = None
        as_strided_default_91 = torch.ops.aten.as_strided.default(index_add__default_6, [24, 1536, 64], [98304, 64, 1], 0);  index_add__default_6 = None
        constant_pad_nd_default_55 = torch.ops.aten.constant_pad_nd.default(as_strided_default_91, [0, 0, -256, -256]);  as_strided_default_91 = None
        view_default_433 = torch.ops.aten.view.default(constant_pad_nd_default_55, [2, 12, 1024, 64]);  constant_pad_nd_default_55 = None
        transpose_int_215 = torch.ops.aten.transpose.int(view_default_433, 1, 2);  view_default_433 = None
        view_default_434 = torch.ops.aten.view.default(constant_pad_nd_default_54, [2, 12, 1024, 513]);  constant_pad_nd_default_54 = None
        transpose_int_216 = torch.ops.aten.transpose.int(view_default_434, 1, 2);  view_default_434 = None
        transpose_int_217 = torch.ops.aten.transpose.int(transpose_int_215, 0, 1);  transpose_int_215 = None
        clone_default_136 = torch.ops.aten.clone.default(transpose_int_217, memory_format = torch.contiguous_format);  transpose_int_217 = None
        _unsafe_view_default_170 = torch.ops.aten._unsafe_view.default(clone_default_136, [1024, 2, 768]);  clone_default_136 = None
        where_scalar_self_30 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_137, 0.0, transpose_int_216);  unsqueeze_default_137 = transpose_int_216 = None
        _softmax_backward_data_default_2 = torch.ops.aten._softmax_backward_data.default(where_scalar_self_30, _softmax_default_9, -1, torch.float32);  where_scalar_self_30 = _softmax_default_9 = None
        new_empty_default_69 = torch.ops.aten.new_empty.default(_softmax_backward_data_default_2, [12607488])
        zero__default_15 = torch.ops.aten.zero_.default(new_empty_default_69);  new_empty_default_69 = None
        as_strided_default_92 = torch.ops.aten.as_strided.default(zero__default_15, [2, 1024, 12, 513], [6303744, 513, 525312, 1], 0)
        copy__default_124 = torch.ops.aten.copy_.default(as_strided_default_92, _softmax_backward_data_default_2);  as_strided_default_92 = _softmax_backward_data_default_2 = None
        as_strided_default_93 = torch.ops.aten.as_strided.default(zero__default_15, [24, 4, 256, 513], [525312, 131328, 513, 1], 0);  zero__default_15 = None
        new_empty_strided_default_14 = torch.ops.aten.new_empty_strided.default(as_strided_default_93, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_125 = torch.ops.aten.copy_.default(new_empty_strided_default_14, as_strided_default_93);  new_empty_strided_default_14 = as_strided_default_93 = None
        as_strided_default_94 = torch.ops.aten.as_strided.default(copy__default_125, [2, 1024, 12, 513], [6303744, 513, 525312, 1], 0)
        clone_default_137 = torch.ops.aten.clone.default(as_strided_default_94, memory_format = torch.contiguous_format)
        copy__default_126 = torch.ops.aten.copy_.default(as_strided_default_94, clone_default_137);  as_strided_default_94 = clone_default_137 = None
        new_empty_strided_default_15 = torch.ops.aten.new_empty_strided.default(copy__default_125, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_127 = torch.ops.aten.copy_.default(new_empty_strided_default_15, copy__default_125);  new_empty_strided_default_15 = copy__default_125 = None
        as_strided_default_95 = torch.ops.aten.as_strided.default(copy__default_127, [2, 256, 12, 257], [6303744, 513, 525312, 1], 394240)
        clone_default_138 = torch.ops.aten.clone.default(as_strided_default_95, memory_format = torch.contiguous_format)
        where_scalar_self_31 = torch.ops.aten.where.ScalarSelf(eq_scalar_37, 0.0, clone_default_138);  eq_scalar_37 = clone_default_138 = None
        copy__default_128 = torch.ops.aten.copy_.default(as_strided_default_95, where_scalar_self_31);  as_strided_default_95 = where_scalar_self_31 = None
        new_empty_strided_default_16 = torch.ops.aten.new_empty_strided.default(copy__default_127, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_129 = torch.ops.aten.copy_.default(new_empty_strided_default_16, copy__default_127);  new_empty_strided_default_16 = copy__default_127 = None
        as_strided_default_96 = torch.ops.aten.as_strided.default(copy__default_129, [2, 256, 12, 257], [6303744, 513, 525312, 1], 0)
        clone_default_139 = torch.ops.aten.clone.default(as_strided_default_96, memory_format = torch.contiguous_format)
        where_scalar_self_32 = torch.ops.aten.where.ScalarSelf(eq_scalar_36, 0.0, clone_default_139);  eq_scalar_36 = clone_default_139 = None
        copy__default_130 = torch.ops.aten.copy_.default(as_strided_default_96, where_scalar_self_32);  as_strided_default_96 = where_scalar_self_32 = None
        new_empty_strided_default_17 = torch.ops.aten.new_empty_strided.default(copy__default_129, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_131 = torch.ops.aten.copy_.default(new_empty_strided_default_17, copy__default_129);  new_empty_strided_default_17 = copy__default_129 = None
        as_strided_default_97 = torch.ops.aten.as_strided.default(copy__default_131, [24, 255, 255], [525312, 513, 1], 514)
        clone_default_140 = torch.ops.aten.clone.default(as_strided_default_97, memory_format = torch.contiguous_format)
        empty_like_default_6 = torch.ops.aten.empty_like.default(clone_default_140, memory_format = torch.contiguous_format)
        zero__default_16 = torch.ops.aten.zero_.default(empty_like_default_6);  empty_like_default_6 = None
        copy__default_132 = torch.ops.aten.copy_.default(as_strided_default_97, zero__default_16);  as_strided_default_97 = zero__default_16 = None
        slice_backward_default_49 = torch.ops.aten.slice_backward.default(clone_default_140, [24, 255, 513], 2, -255, 9223372036854775807, 1);  clone_default_140 = None
        slice_backward_default_50 = torch.ops.aten.slice_backward.default(slice_backward_default_49, [24, 512, 513], 1, 0, 255, 1);  slice_backward_default_49 = None
        select_backward_default_4 = torch.ops.aten.select_backward.default(slice_backward_default_50, [24, 3, 512, 513], 1, 0);  slice_backward_default_50 = None
        slice_backward_default_51 = torch.ops.aten.slice_backward.default(select_backward_default_4, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_4 = None
        new_empty_strided_default_18 = torch.ops.aten.new_empty_strided.default(copy__default_131, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_133 = torch.ops.aten.copy_.default(new_empty_strided_default_18, copy__default_131);  new_empty_strided_default_18 = copy__default_131 = None
        as_strided_default_98 = torch.ops.aten.as_strided.default(copy__default_133, [24, 3, 256, 256], [525312, 131328, 513, 1], 131328)
        clone_default_141 = torch.ops.aten.clone.default(as_strided_default_98, memory_format = torch.contiguous_format)
        empty_like_default_7 = torch.ops.aten.empty_like.default(clone_default_141, memory_format = torch.contiguous_format)
        zero__default_17 = torch.ops.aten.zero_.default(empty_like_default_7);  empty_like_default_7 = None
        copy__default_134 = torch.ops.aten.copy_.default(as_strided_default_98, zero__default_17);  as_strided_default_98 = zero__default_17 = None
        slice_backward_default_52 = torch.ops.aten.slice_backward.default(clone_default_141, [24, 3, 256, 513], 3, 257, 9223372036854775807, 1);  clone_default_141 = None
        slice_backward_default_53 = torch.ops.aten.slice_backward.default(slice_backward_default_52, [24, 3, 512, 513], 2, -257, -1, 1);  slice_backward_default_52 = None
        slice_backward_default_54 = torch.ops.aten.slice_backward.default(slice_backward_default_53, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_53 = None
        slice_backward_default_55 = torch.ops.aten.slice_backward.default(slice_backward_default_54, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_54 = None
        add_tensor_93 = torch.ops.aten.add.Tensor(slice_backward_default_51, slice_backward_default_55);  slice_backward_default_51 = slice_backward_default_55 = None
        new_empty_strided_default_19 = torch.ops.aten.new_empty_strided.default(copy__default_133, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_135 = torch.ops.aten.copy_.default(new_empty_strided_default_19, copy__default_133);  new_empty_strided_default_19 = copy__default_133 = None
        as_strided_default_99 = torch.ops.aten.as_strided.default(copy__default_135, [24, 256, 257], [525312, 513, 1], 394240)
        clone_default_142 = torch.ops.aten.clone.default(as_strided_default_99, memory_format = torch.contiguous_format)
        empty_like_default_8 = torch.ops.aten.empty_like.default(clone_default_142, memory_format = torch.contiguous_format)
        zero__default_18 = torch.ops.aten.zero_.default(empty_like_default_8);  empty_like_default_8 = None
        copy__default_136 = torch.ops.aten.copy_.default(as_strided_default_99, zero__default_18);  as_strided_default_99 = zero__default_18 = None
        slice_backward_default_56 = torch.ops.aten.slice_backward.default(clone_default_142, [24, 256, 513], 2, 0, 257, 1);  clone_default_142 = None
        slice_backward_default_57 = torch.ops.aten.slice_backward.default(slice_backward_default_56, [24, 512, 513], 1, 256, 9223372036854775807, 1);  slice_backward_default_56 = None
        select_backward_default_5 = torch.ops.aten.select_backward.default(slice_backward_default_57, [24, 3, 512, 513], 1, -1);  slice_backward_default_57 = None
        slice_backward_default_58 = torch.ops.aten.slice_backward.default(select_backward_default_5, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_5 = None
        add_tensor_94 = torch.ops.aten.add.Tensor(add_tensor_93, slice_backward_default_58);  add_tensor_93 = slice_backward_default_58 = None
        new_empty_strided_default_20 = torch.ops.aten.new_empty_strided.default(copy__default_135, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_137 = torch.ops.aten.copy_.default(new_empty_strided_default_20, copy__default_135);  new_empty_strided_default_20 = copy__default_135 = None
        as_strided_default_100 = torch.ops.aten.as_strided.default(copy__default_137, [24, 3, 256, 257], [525312, 131328, 513, 1], 256);  copy__default_137 = None
        clone_default_143 = torch.ops.aten.clone.default(as_strided_default_100, memory_format = torch.contiguous_format);  as_strided_default_100 = None
        slice_backward_default_59 = torch.ops.aten.slice_backward.default(clone_default_143, [24, 3, 256, 513], 3, 0, 257, 1);  clone_default_143 = None
        slice_backward_default_60 = torch.ops.aten.slice_backward.default(slice_backward_default_59, [24, 3, 512, 513], 2, 0, 256, 1);  slice_backward_default_59 = None
        slice_backward_default_61 = torch.ops.aten.slice_backward.default(slice_backward_default_60, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_60 = None
        slice_backward_default_62 = torch.ops.aten.slice_backward.default(slice_backward_default_61, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_61 = None
        add_tensor_95 = torch.ops.aten.add.Tensor(add_tensor_94, slice_backward_default_62);  add_tensor_94 = slice_backward_default_62 = None
        view_default_435 = torch.ops.aten.view.default(add_tensor_95, [24, 3, 513, 512]);  add_tensor_95 = None
        constant_pad_nd_default_56 = torch.ops.aten.constant_pad_nd.default(view_default_435, [0, 0, 0, -1]);  view_default_435 = None
        view_default_436 = torch.ops.aten.view.default(constant_pad_nd_default_56, [24, 3, 512, 512, 1]);  constant_pad_nd_default_56 = None
        permute_default_169 = torch.ops.aten.permute.default(view_default_436, [0, 1, 2, 4, 3]);  view_default_436 = None
        view_default_437 = torch.ops.aten.view.default(permute_default_169, [72, 512, 512]);  permute_default_169 = None
        transpose_int_218 = torch.ops.aten.transpose.int(_unsafe_view_default_123, 1, 2);  _unsafe_view_default_123 = None
        bmm_default_34 = torch.ops.aten.bmm.default(transpose_int_218, view_default_437);  transpose_int_218 = None
        transpose_int_219 = torch.ops.aten.transpose.int(_unsafe_view_default_124, 1, 2);  _unsafe_view_default_124 = None
        bmm_default_35 = torch.ops.aten.bmm.default(view_default_437, transpose_int_219);  view_default_437 = transpose_int_219 = None
        view_default_438 = torch.ops.aten.view.default(bmm_default_34, [24, 3, 64, 512, 1]);  bmm_default_34 = None
        permute_default_170 = torch.ops.aten.permute.default(view_default_438, [0, 1, 4, 3, 2]);  view_default_438 = None
        view_default_439 = torch.ops.aten.view.default(bmm_default_35, [24, 3, 512, 64, 1]);  bmm_default_35 = None
        permute_default_171 = torch.ops.aten.permute.default(view_default_439, [0, 1, 2, 4, 3]);  view_default_439 = None
        permute_default_172 = torch.ops.aten.permute.default(permute_default_170, [0, 1, 3, 4, 2]);  permute_default_170 = None
        squeeze_dim_34 = torch.ops.aten.squeeze.dim(permute_default_172, -1);  permute_default_172 = None
        permute_default_173 = torch.ops.aten.permute.default(permute_default_171, [0, 1, 2, 4, 3]);  permute_default_171 = None
        squeeze_dim_35 = torch.ops.aten.squeeze.dim(permute_default_173, -1);  permute_default_173 = None
        new_empty_default_70 = torch.ops.aten.new_empty.default(squeeze_dim_34, [1572864])
        zero__default_19 = torch.ops.aten.zero_.default(new_empty_default_70);  new_empty_default_70 = None
        arange_7 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_101 = torch.ops.aten.as_strided.default(arange_7, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_7 = None
        clone_default_144 = torch.ops.aten.clone.default(as_strided_default_101, memory_format = torch.contiguous_format);  as_strided_default_101 = None
        _unsafe_view_default_171 = torch.ops.aten._unsafe_view.default(clone_default_144, [2359296]);  clone_default_144 = None
        clone_default_145 = torch.ops.aten.clone.default(squeeze_dim_34, memory_format = torch.contiguous_format);  squeeze_dim_34 = None
        _unsafe_view_default_172 = torch.ops.aten._unsafe_view.default(clone_default_145, [2359296]);  clone_default_145 = None
        index_add__default_7 = torch.ops.aten.index_add_.default(zero__default_19, 0, _unsafe_view_default_171, _unsafe_view_default_172);  zero__default_19 = _unsafe_view_default_171 = _unsafe_view_default_172 = None
        as_strided_default_102 = torch.ops.aten.as_strided.default(index_add__default_7, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_7 = None
        view_default_440 = torch.ops.aten.view.default(as_strided_default_102, [24, 1024, 64]);  as_strided_default_102 = None
        new_empty_default_71 = torch.ops.aten.new_empty.default(squeeze_dim_35, [1572864])
        zero__default_20 = torch.ops.aten.zero_.default(new_empty_default_71);  new_empty_default_71 = None
        arange_8 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_103 = torch.ops.aten.as_strided.default(arange_8, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_8 = None
        clone_default_146 = torch.ops.aten.clone.default(as_strided_default_103, memory_format = torch.contiguous_format);  as_strided_default_103 = None
        _unsafe_view_default_173 = torch.ops.aten._unsafe_view.default(clone_default_146, [2359296]);  clone_default_146 = None
        view_default_441 = torch.ops.aten.view.default(squeeze_dim_35, [2359296]);  squeeze_dim_35 = None
        index_add__default_8 = torch.ops.aten.index_add_.default(zero__default_20, 0, _unsafe_view_default_173, view_default_441);  zero__default_20 = _unsafe_view_default_173 = view_default_441 = None
        as_strided_default_104 = torch.ops.aten.as_strided.default(index_add__default_8, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_8 = None
        view_default_442 = torch.ops.aten.view.default(as_strided_default_104, [24, 1024, 64]);  as_strided_default_104 = None
        view_default_443 = torch.ops.aten.view.default(view_default_440, [2, 12, 1024, 64]);  view_default_440 = None
        transpose_int_220 = torch.ops.aten.transpose.int(view_default_443, 1, 2);  view_default_443 = None
        view_default_444 = torch.ops.aten.view.default(view_default_442, [2, 12, 1024, 64]);  view_default_442 = None
        transpose_int_221 = torch.ops.aten.transpose.int(view_default_444, 1, 2);  view_default_444 = None
        transpose_int_222 = torch.ops.aten.transpose.int(transpose_int_220, 0, 1);  transpose_int_220 = None
        view_default_445 = torch.ops.aten.view.default(transpose_int_222, [1024, 2, 768]);  transpose_int_222 = None
        transpose_int_223 = torch.ops.aten.transpose.int(transpose_int_221, 0, 1);  transpose_int_221 = None
        view_default_446 = torch.ops.aten.view.default(transpose_int_223, [1024, 2, 768]);  transpose_int_223 = None
        div_tensor_2 = torch.ops.aten.div.Tensor(view_default_446, 8.0);  view_default_446 = None
        sum_dim_int_list_15 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_170, [0, 1], True)
        view_default_447 = torch.ops.aten.view.default(sum_dim_int_list_15, [768]);  sum_dim_int_list_15 = None
        view_default_448 = torch.ops.aten.view.default(_unsafe_view_default_170, [2048, 768]);  _unsafe_view_default_170 = None
        t_default_132 = torch.ops.aten.t.default(view_default_448)
        mm_default_78 = torch.ops.aten.mm.default(t_default_132, _unsafe_view_default_121);  t_default_132 = _unsafe_view_default_121 = None
        t_default_133 = torch.ops.aten.t.default(mm_default_78);  mm_default_78 = None
        t_default_134 = torch.ops.aten.t.default(t_default_56);  t_default_56 = None
        mm_default_79 = torch.ops.aten.mm.default(view_default_448, t_default_134);  view_default_448 = t_default_134 = None
        view_default_449 = torch.ops.aten.view.default(mm_default_79, [1024, 2, 768]);  mm_default_79 = None
        t_default_135 = torch.ops.aten.t.default(t_default_133);  t_default_133 = None
        sum_dim_int_list_16 = torch.ops.aten.sum.dim_IntList(view_default_445, [0, 1], True)
        view_default_450 = torch.ops.aten.view.default(sum_dim_int_list_16, [768]);  sum_dim_int_list_16 = None
        view_default_451 = torch.ops.aten.view.default(view_default_445, [2048, 768]);  view_default_445 = None
        t_default_136 = torch.ops.aten.t.default(view_default_451)
        mm_default_80 = torch.ops.aten.mm.default(t_default_136, _unsafe_view_default_119);  t_default_136 = _unsafe_view_default_119 = None
        t_default_137 = torch.ops.aten.t.default(mm_default_80);  mm_default_80 = None
        t_default_138 = torch.ops.aten.t.default(t_default_55);  t_default_55 = None
        mm_default_81 = torch.ops.aten.mm.default(view_default_451, t_default_138);  view_default_451 = t_default_138 = None
        view_default_452 = torch.ops.aten.view.default(mm_default_81, [1024, 2, 768]);  mm_default_81 = None
        add_tensor_96 = torch.ops.aten.add.Tensor(view_default_449, view_default_452);  view_default_449 = view_default_452 = None
        t_default_139 = torch.ops.aten.t.default(t_default_137);  t_default_137 = None
        sum_dim_int_list_17 = torch.ops.aten.sum.dim_IntList(div_tensor_2, [0, 1], True)
        view_default_453 = torch.ops.aten.view.default(sum_dim_int_list_17, [768]);  sum_dim_int_list_17 = None
        view_default_454 = torch.ops.aten.view.default(div_tensor_2, [2048, 768]);  div_tensor_2 = None
        t_default_140 = torch.ops.aten.t.default(view_default_454)
        mm_default_82 = torch.ops.aten.mm.default(t_default_140, _unsafe_view_default_117);  t_default_140 = _unsafe_view_default_117 = None
        t_default_141 = torch.ops.aten.t.default(mm_default_82);  mm_default_82 = None
        t_default_142 = torch.ops.aten.t.default(t_default_54);  t_default_54 = None
        mm_default_83 = torch.ops.aten.mm.default(view_default_454, t_default_142);  view_default_454 = t_default_142 = None
        view_default_455 = torch.ops.aten.view.default(mm_default_83, [1024, 2, 768]);  mm_default_83 = None
        add_tensor_97 = torch.ops.aten.add.Tensor(add_tensor_96, view_default_455);  add_tensor_96 = view_default_455 = None
        t_default_143 = torch.ops.aten.t.default(t_default_141);  t_default_141 = None
        transpose_int_224 = torch.ops.aten.transpose.int(add_tensor_97, 0, 1);  add_tensor_97 = None
        add_tensor_98 = torch.ops.aten.add.Tensor(getitem_87, transpose_int_224);  getitem_87 = transpose_int_224 = None
        native_layer_norm_backward_default_6 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_98, add_tensor_53, [768], getitem_52, getitem_53, primals_174, primals_173, [True, True, True]);  add_tensor_98 = add_tensor_53 = getitem_52 = getitem_53 = primals_174 = primals_173 = None
        getitem_90 = native_layer_norm_backward_default_6[0]
        getitem_91 = native_layer_norm_backward_default_6[1]
        getitem_92 = native_layer_norm_backward_default_6[2];  native_layer_norm_backward_default_6 = None
        view_default_456 = torch.ops.aten.view.default(getitem_90, [2048, 768])
        t_default_144 = torch.ops.aten.t.default(t_default_53);  t_default_53 = None
        mm_default_84 = torch.ops.aten.mm.default(view_default_456, t_default_144);  t_default_144 = None
        t_default_145 = torch.ops.aten.t.default(view_default_456)
        mm_default_85 = torch.ops.aten.mm.default(t_default_145, view_default_250);  t_default_145 = view_default_250 = None
        t_default_146 = torch.ops.aten.t.default(mm_default_85);  mm_default_85 = None
        sum_dim_int_list_18 = torch.ops.aten.sum.dim_IntList(view_default_456, [0], True);  view_default_456 = None
        view_default_457 = torch.ops.aten.view.default(sum_dim_int_list_18, [768]);  sum_dim_int_list_18 = None
        t_default_147 = torch.ops.aten.t.default(t_default_146);  t_default_146 = None
        view_default_458 = torch.ops.aten.view.default(mm_default_84, [2, 1024, 3072]);  mm_default_84 = None
        to_dtype_9 = torch.ops.aten.to.dtype(view_default_458, torch.float32);  view_default_458 = None
        to_dtype_10 = torch.ops.aten.to.dtype(view_default_249, torch.float32);  view_default_249 = None
        mul_tensor_33 = torch.ops.aten.mul.Tensor(to_dtype_10, 0.7071067811865476)
        erf_default_3 = torch.ops.aten.erf.default(mul_tensor_33);  mul_tensor_33 = None
        add_tensor_99 = torch.ops.aten.add.Tensor(erf_default_3, 1);  erf_default_3 = None
        mul_tensor_34 = torch.ops.aten.mul.Tensor(add_tensor_99, 0.5);  add_tensor_99 = None
        mul_tensor_35 = torch.ops.aten.mul.Tensor(to_dtype_10, to_dtype_10)
        mul_tensor_36 = torch.ops.aten.mul.Tensor(mul_tensor_35, -0.5);  mul_tensor_35 = None
        exp_default_3 = torch.ops.aten.exp.default(mul_tensor_36);  mul_tensor_36 = None
        mul_tensor_37 = torch.ops.aten.mul.Tensor(exp_default_3, 0.3989422804014327);  exp_default_3 = None
        mul_tensor_38 = torch.ops.aten.mul.Tensor(to_dtype_10, mul_tensor_37);  to_dtype_10 = mul_tensor_37 = None
        add_tensor_100 = torch.ops.aten.add.Tensor(mul_tensor_34, mul_tensor_38);  mul_tensor_34 = mul_tensor_38 = None
        mul_tensor_39 = torch.ops.aten.mul.Tensor(to_dtype_9, add_tensor_100);  to_dtype_9 = add_tensor_100 = None
        to_dtype_11 = torch.ops.aten.to.dtype(mul_tensor_39, torch.float32);  mul_tensor_39 = None
        view_default_459 = torch.ops.aten.view.default(to_dtype_11, [2048, 3072]);  to_dtype_11 = None
        t_default_148 = torch.ops.aten.t.default(t_default_52);  t_default_52 = None
        mm_default_86 = torch.ops.aten.mm.default(view_default_459, t_default_148);  t_default_148 = None
        t_default_149 = torch.ops.aten.t.default(view_default_459)
        mm_default_87 = torch.ops.aten.mm.default(t_default_149, view_default_248);  t_default_149 = view_default_248 = None
        t_default_150 = torch.ops.aten.t.default(mm_default_87);  mm_default_87 = None
        sum_dim_int_list_19 = torch.ops.aten.sum.dim_IntList(view_default_459, [0], True);  view_default_459 = None
        view_default_460 = torch.ops.aten.view.default(sum_dim_int_list_19, [3072]);  sum_dim_int_list_19 = None
        t_default_151 = torch.ops.aten.t.default(t_default_150);  t_default_150 = None
        view_default_461 = torch.ops.aten.view.default(mm_default_86, [2, 1024, 768]);  mm_default_86 = None
        add_tensor_101 = torch.ops.aten.add.Tensor(getitem_90, view_default_461);  getitem_90 = view_default_461 = None
        native_layer_norm_backward_default_7 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_101, add_tensor_52, [768], getitem_49, getitem_50, primals_162, primals_161, [True, True, True]);  add_tensor_101 = add_tensor_52 = getitem_49 = getitem_50 = primals_162 = primals_161 = None
        getitem_93 = native_layer_norm_backward_default_7[0]
        getitem_94 = native_layer_norm_backward_default_7[1]
        getitem_95 = native_layer_norm_backward_default_7[2];  native_layer_norm_backward_default_7 = None
        sum_dim_int_list_20 = torch.ops.aten.sum.dim_IntList(getitem_93, [0, 1], True)
        view_default_462 = torch.ops.aten.view.default(sum_dim_int_list_20, [768]);  sum_dim_int_list_20 = None
        view_default_463 = torch.ops.aten.view.default(getitem_93, [2048, 768])
        t_default_152 = torch.ops.aten.t.default(view_default_463)
        mm_default_88 = torch.ops.aten.mm.default(t_default_152, _unsafe_view_default_115);  t_default_152 = _unsafe_view_default_115 = None
        t_default_153 = torch.ops.aten.t.default(mm_default_88);  mm_default_88 = None
        t_default_154 = torch.ops.aten.t.default(t_default_51);  t_default_51 = None
        mm_default_89 = torch.ops.aten.mm.default(view_default_463, t_default_154);  view_default_463 = t_default_154 = None
        view_default_464 = torch.ops.aten.view.default(mm_default_89, [2, 1024, 768]);  mm_default_89 = None
        t_default_155 = torch.ops.aten.t.default(t_default_153);  t_default_153 = None
        transpose_int_225 = torch.ops.aten.transpose.int(view_default_464, 0, 1);  view_default_464 = None
        view_default_465 = torch.ops.aten.view.default(transpose_int_225, [1024, 2, 12, 64]);  transpose_int_225 = None
        transpose_int_226 = torch.ops.aten.transpose.int(view_default_465, 0, 1);  view_default_465 = None
        transpose_int_227 = torch.ops.aten.transpose.int(transpose_int_226, 1, 2);  transpose_int_226 = None
        clone_default_147 = torch.ops.aten.clone.default(transpose_int_227, memory_format = torch.contiguous_format);  transpose_int_227 = None
        _unsafe_view_default_174 = torch.ops.aten._unsafe_view.default(clone_default_147, [24, 4, 256, 64]);  clone_default_147 = None
        view_default_466 = torch.ops.aten.view.default(_unsafe_view_default_174, [24, 4, 256, 64, 1]);  _unsafe_view_default_174 = None
        permute_default_174 = torch.ops.aten.permute.default(view_default_466, [0, 1, 2, 4, 3]);  view_default_466 = None
        view_default_467 = torch.ops.aten.view.default(permute_default_174, [96, 256, 64]);  permute_default_174 = None
        transpose_int_228 = torch.ops.aten.transpose.int(view_default_244, 1, 2);  view_default_244 = None
        bmm_default_36 = torch.ops.aten.bmm.default(transpose_int_228, view_default_467);  transpose_int_228 = None
        transpose_int_229 = torch.ops.aten.transpose.int(_unsafe_view_default_113, 1, 2);  _unsafe_view_default_113 = None
        bmm_default_37 = torch.ops.aten.bmm.default(view_default_467, transpose_int_229);  view_default_467 = transpose_int_229 = None
        view_default_468 = torch.ops.aten.view.default(bmm_default_36, [24, 4, 768, 64, 1]);  bmm_default_36 = None
        permute_default_175 = torch.ops.aten.permute.default(view_default_468, [0, 1, 4, 3, 2]);  view_default_468 = None
        view_default_469 = torch.ops.aten.view.default(bmm_default_37, [24, 4, 256, 768, 1]);  bmm_default_37 = None
        permute_default_176 = torch.ops.aten.permute.default(view_default_469, [0, 1, 2, 4, 3]);  view_default_469 = None
        permute_default_177 = torch.ops.aten.permute.default(permute_default_175, [0, 1, 4, 3, 2]);  permute_default_175 = None
        squeeze_dim_36 = torch.ops.aten.squeeze.dim(permute_default_177, -1);  permute_default_177 = None
        permute_default_178 = torch.ops.aten.permute.default(permute_default_176, [0, 1, 2, 4, 3]);  permute_default_176 = None
        squeeze_dim_37 = torch.ops.aten.squeeze.dim(permute_default_178, -1);  permute_default_178 = None
        slice_backward_default_63 = torch.ops.aten.slice_backward.default(squeeze_dim_37, [24, 4, 256, 769], 3, 0, -1, 1);  squeeze_dim_37 = None
        slice_backward_default_64 = torch.ops.aten.slice_backward.default(slice_backward_default_63, [24, 4, 256, 769], 2, 0, 9223372036854775807, 1);  slice_backward_default_63 = None
        slice_backward_default_65 = torch.ops.aten.slice_backward.default(slice_backward_default_64, [24, 4, 256, 769], 1, 0, 9223372036854775807, 1);  slice_backward_default_64 = None
        slice_backward_default_66 = torch.ops.aten.slice_backward.default(slice_backward_default_65, [24, 4, 256, 769], 0, 0, 9223372036854775807, 1);  slice_backward_default_65 = None
        view_default_470 = torch.ops.aten.view.default(slice_backward_default_66, [24, 4, 196864]);  slice_backward_default_66 = None
        slice_backward_default_67 = torch.ops.aten.slice_backward.default(view_default_470, [24, 4, 197120], 2, 0, -256, 1);  view_default_470 = None
        slice_backward_default_68 = torch.ops.aten.slice_backward.default(slice_backward_default_67, [24, 4, 197120], 1, 0, 9223372036854775807, 1);  slice_backward_default_67 = None
        slice_backward_default_69 = torch.ops.aten.slice_backward.default(slice_backward_default_68, [24, 4, 197120], 0, 0, 9223372036854775807, 1);  slice_backward_default_68 = None
        view_default_471 = torch.ops.aten.view.default(slice_backward_default_69, [24, 4, 256, 770]);  slice_backward_default_69 = None
        constant_pad_nd_default_57 = torch.ops.aten.constant_pad_nd.default(view_default_471, [0, -257]);  view_default_471 = None
        new_empty_default_72 = torch.ops.aten.new_empty.default(squeeze_dim_36, [2359296])
        zero__default_21 = torch.ops.aten.zero_.default(new_empty_default_72);  new_empty_default_72 = None
        arange_9 = torch.ops.aten.arange.start(0, 2359296, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_105 = torch.ops.aten.as_strided.default(arange_9, [24, 4, 768, 64], [98304, 16384, 64, 1], 0);  arange_9 = None
        clone_default_148 = torch.ops.aten.clone.default(as_strided_default_105, memory_format = torch.contiguous_format);  as_strided_default_105 = None
        _unsafe_view_default_175 = torch.ops.aten._unsafe_view.default(clone_default_148, [4718592]);  clone_default_148 = None
        view_default_472 = torch.ops.aten.view.default(squeeze_dim_36, [4718592]);  squeeze_dim_36 = None
        index_add__default_9 = torch.ops.aten.index_add_.default(zero__default_21, 0, _unsafe_view_default_175, view_default_472);  zero__default_21 = _unsafe_view_default_175 = view_default_472 = None
        as_strided_default_106 = torch.ops.aten.as_strided.default(index_add__default_9, [24, 1536, 64], [98304, 64, 1], 0);  index_add__default_9 = None
        constant_pad_nd_default_58 = torch.ops.aten.constant_pad_nd.default(as_strided_default_106, [0, 0, -256, -256]);  as_strided_default_106 = None
        view_default_473 = torch.ops.aten.view.default(constant_pad_nd_default_58, [2, 12, 1024, 64]);  constant_pad_nd_default_58 = None
        transpose_int_230 = torch.ops.aten.transpose.int(view_default_473, 1, 2);  view_default_473 = None
        view_default_474 = torch.ops.aten.view.default(constant_pad_nd_default_57, [2, 12, 1024, 513]);  constant_pad_nd_default_57 = None
        transpose_int_231 = torch.ops.aten.transpose.int(view_default_474, 1, 2);  view_default_474 = None
        transpose_int_232 = torch.ops.aten.transpose.int(transpose_int_230, 0, 1);  transpose_int_230 = None
        clone_default_149 = torch.ops.aten.clone.default(transpose_int_232, memory_format = torch.contiguous_format);  transpose_int_232 = None
        _unsafe_view_default_176 = torch.ops.aten._unsafe_view.default(clone_default_149, [1024, 2, 768]);  clone_default_149 = None
        where_scalar_self_33 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_123, 0.0, transpose_int_231);  unsqueeze_default_123 = transpose_int_231 = None
        _softmax_backward_data_default_3 = torch.ops.aten._softmax_backward_data.default(where_scalar_self_33, _softmax_default_8, -1, torch.float32);  where_scalar_self_33 = _softmax_default_8 = None
        new_empty_default_73 = torch.ops.aten.new_empty.default(_softmax_backward_data_default_3, [12607488])
        zero__default_22 = torch.ops.aten.zero_.default(new_empty_default_73);  new_empty_default_73 = None
        as_strided_default_107 = torch.ops.aten.as_strided.default(zero__default_22, [2, 1024, 12, 513], [6303744, 513, 525312, 1], 0)
        copy__default_138 = torch.ops.aten.copy_.default(as_strided_default_107, _softmax_backward_data_default_3);  as_strided_default_107 = _softmax_backward_data_default_3 = None
        as_strided_default_108 = torch.ops.aten.as_strided.default(zero__default_22, [24, 4, 256, 513], [525312, 131328, 513, 1], 0);  zero__default_22 = None
        new_empty_strided_default_21 = torch.ops.aten.new_empty_strided.default(as_strided_default_108, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_139 = torch.ops.aten.copy_.default(new_empty_strided_default_21, as_strided_default_108);  new_empty_strided_default_21 = as_strided_default_108 = None
        as_strided_default_109 = torch.ops.aten.as_strided.default(copy__default_139, [2, 1024, 12, 513], [6303744, 513, 525312, 1], 0)
        clone_default_150 = torch.ops.aten.clone.default(as_strided_default_109, memory_format = torch.contiguous_format)
        copy__default_140 = torch.ops.aten.copy_.default(as_strided_default_109, clone_default_150);  as_strided_default_109 = clone_default_150 = None
        new_empty_strided_default_22 = torch.ops.aten.new_empty_strided.default(copy__default_139, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_141 = torch.ops.aten.copy_.default(new_empty_strided_default_22, copy__default_139);  new_empty_strided_default_22 = copy__default_139 = None
        as_strided_default_110 = torch.ops.aten.as_strided.default(copy__default_141, [2, 256, 12, 257], [6303744, 513, 525312, 1], 394240)
        clone_default_151 = torch.ops.aten.clone.default(as_strided_default_110, memory_format = torch.contiguous_format)
        where_scalar_self_34 = torch.ops.aten.where.ScalarSelf(eq_scalar_33, 0.0, clone_default_151);  eq_scalar_33 = clone_default_151 = None
        copy__default_142 = torch.ops.aten.copy_.default(as_strided_default_110, where_scalar_self_34);  as_strided_default_110 = where_scalar_self_34 = None
        new_empty_strided_default_23 = torch.ops.aten.new_empty_strided.default(copy__default_141, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_143 = torch.ops.aten.copy_.default(new_empty_strided_default_23, copy__default_141);  new_empty_strided_default_23 = copy__default_141 = None
        as_strided_default_111 = torch.ops.aten.as_strided.default(copy__default_143, [2, 256, 12, 257], [6303744, 513, 525312, 1], 0)
        clone_default_152 = torch.ops.aten.clone.default(as_strided_default_111, memory_format = torch.contiguous_format)
        where_scalar_self_35 = torch.ops.aten.where.ScalarSelf(eq_scalar_32, 0.0, clone_default_152);  eq_scalar_32 = clone_default_152 = None
        copy__default_144 = torch.ops.aten.copy_.default(as_strided_default_111, where_scalar_self_35);  as_strided_default_111 = where_scalar_self_35 = None
        new_empty_strided_default_24 = torch.ops.aten.new_empty_strided.default(copy__default_143, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_145 = torch.ops.aten.copy_.default(new_empty_strided_default_24, copy__default_143);  new_empty_strided_default_24 = copy__default_143 = None
        as_strided_default_112 = torch.ops.aten.as_strided.default(copy__default_145, [24, 255, 255], [525312, 513, 1], 514)
        clone_default_153 = torch.ops.aten.clone.default(as_strided_default_112, memory_format = torch.contiguous_format)
        empty_like_default_9 = torch.ops.aten.empty_like.default(clone_default_153, memory_format = torch.contiguous_format)
        zero__default_23 = torch.ops.aten.zero_.default(empty_like_default_9);  empty_like_default_9 = None
        copy__default_146 = torch.ops.aten.copy_.default(as_strided_default_112, zero__default_23);  as_strided_default_112 = zero__default_23 = None
        slice_backward_default_70 = torch.ops.aten.slice_backward.default(clone_default_153, [24, 255, 513], 2, -255, 9223372036854775807, 1);  clone_default_153 = None
        slice_backward_default_71 = torch.ops.aten.slice_backward.default(slice_backward_default_70, [24, 512, 513], 1, 0, 255, 1);  slice_backward_default_70 = None
        select_backward_default_6 = torch.ops.aten.select_backward.default(slice_backward_default_71, [24, 3, 512, 513], 1, 0);  slice_backward_default_71 = None
        slice_backward_default_72 = torch.ops.aten.slice_backward.default(select_backward_default_6, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_6 = None
        new_empty_strided_default_25 = torch.ops.aten.new_empty_strided.default(copy__default_145, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_147 = torch.ops.aten.copy_.default(new_empty_strided_default_25, copy__default_145);  new_empty_strided_default_25 = copy__default_145 = None
        as_strided_default_113 = torch.ops.aten.as_strided.default(copy__default_147, [24, 3, 256, 256], [525312, 131328, 513, 1], 131328)
        clone_default_154 = torch.ops.aten.clone.default(as_strided_default_113, memory_format = torch.contiguous_format)
        empty_like_default_10 = torch.ops.aten.empty_like.default(clone_default_154, memory_format = torch.contiguous_format)
        zero__default_24 = torch.ops.aten.zero_.default(empty_like_default_10);  empty_like_default_10 = None
        copy__default_148 = torch.ops.aten.copy_.default(as_strided_default_113, zero__default_24);  as_strided_default_113 = zero__default_24 = None
        slice_backward_default_73 = torch.ops.aten.slice_backward.default(clone_default_154, [24, 3, 256, 513], 3, 257, 9223372036854775807, 1);  clone_default_154 = None
        slice_backward_default_74 = torch.ops.aten.slice_backward.default(slice_backward_default_73, [24, 3, 512, 513], 2, -257, -1, 1);  slice_backward_default_73 = None
        slice_backward_default_75 = torch.ops.aten.slice_backward.default(slice_backward_default_74, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_74 = None
        slice_backward_default_76 = torch.ops.aten.slice_backward.default(slice_backward_default_75, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_75 = None
        add_tensor_102 = torch.ops.aten.add.Tensor(slice_backward_default_72, slice_backward_default_76);  slice_backward_default_72 = slice_backward_default_76 = None
        new_empty_strided_default_26 = torch.ops.aten.new_empty_strided.default(copy__default_147, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_149 = torch.ops.aten.copy_.default(new_empty_strided_default_26, copy__default_147);  new_empty_strided_default_26 = copy__default_147 = None
        as_strided_default_114 = torch.ops.aten.as_strided.default(copy__default_149, [24, 256, 257], [525312, 513, 1], 394240)
        clone_default_155 = torch.ops.aten.clone.default(as_strided_default_114, memory_format = torch.contiguous_format)
        empty_like_default_11 = torch.ops.aten.empty_like.default(clone_default_155, memory_format = torch.contiguous_format)
        zero__default_25 = torch.ops.aten.zero_.default(empty_like_default_11);  empty_like_default_11 = None
        copy__default_150 = torch.ops.aten.copy_.default(as_strided_default_114, zero__default_25);  as_strided_default_114 = zero__default_25 = None
        slice_backward_default_77 = torch.ops.aten.slice_backward.default(clone_default_155, [24, 256, 513], 2, 0, 257, 1);  clone_default_155 = None
        slice_backward_default_78 = torch.ops.aten.slice_backward.default(slice_backward_default_77, [24, 512, 513], 1, 256, 9223372036854775807, 1);  slice_backward_default_77 = None
        select_backward_default_7 = torch.ops.aten.select_backward.default(slice_backward_default_78, [24, 3, 512, 513], 1, -1);  slice_backward_default_78 = None
        slice_backward_default_79 = torch.ops.aten.slice_backward.default(select_backward_default_7, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_7 = None
        add_tensor_103 = torch.ops.aten.add.Tensor(add_tensor_102, slice_backward_default_79);  add_tensor_102 = slice_backward_default_79 = None
        new_empty_strided_default_27 = torch.ops.aten.new_empty_strided.default(copy__default_149, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_151 = torch.ops.aten.copy_.default(new_empty_strided_default_27, copy__default_149);  new_empty_strided_default_27 = copy__default_149 = None
        as_strided_default_115 = torch.ops.aten.as_strided.default(copy__default_151, [24, 3, 256, 257], [525312, 131328, 513, 1], 256);  copy__default_151 = None
        clone_default_156 = torch.ops.aten.clone.default(as_strided_default_115, memory_format = torch.contiguous_format);  as_strided_default_115 = None
        slice_backward_default_80 = torch.ops.aten.slice_backward.default(clone_default_156, [24, 3, 256, 513], 3, 0, 257, 1);  clone_default_156 = None
        slice_backward_default_81 = torch.ops.aten.slice_backward.default(slice_backward_default_80, [24, 3, 512, 513], 2, 0, 256, 1);  slice_backward_default_80 = None
        slice_backward_default_82 = torch.ops.aten.slice_backward.default(slice_backward_default_81, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_81 = None
        slice_backward_default_83 = torch.ops.aten.slice_backward.default(slice_backward_default_82, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_82 = None
        add_tensor_104 = torch.ops.aten.add.Tensor(add_tensor_103, slice_backward_default_83);  add_tensor_103 = slice_backward_default_83 = None
        view_default_475 = torch.ops.aten.view.default(add_tensor_104, [24, 3, 513, 512]);  add_tensor_104 = None
        constant_pad_nd_default_59 = torch.ops.aten.constant_pad_nd.default(view_default_475, [0, 0, 0, -1]);  view_default_475 = None
        view_default_476 = torch.ops.aten.view.default(constant_pad_nd_default_59, [24, 3, 512, 512, 1]);  constant_pad_nd_default_59 = None
        permute_default_179 = torch.ops.aten.permute.default(view_default_476, [0, 1, 2, 4, 3]);  view_default_476 = None
        view_default_477 = torch.ops.aten.view.default(permute_default_179, [72, 512, 512]);  permute_default_179 = None
        transpose_int_233 = torch.ops.aten.transpose.int(_unsafe_view_default_110, 1, 2);  _unsafe_view_default_110 = None
        bmm_default_38 = torch.ops.aten.bmm.default(transpose_int_233, view_default_477);  transpose_int_233 = None
        transpose_int_234 = torch.ops.aten.transpose.int(_unsafe_view_default_111, 1, 2);  _unsafe_view_default_111 = None
        bmm_default_39 = torch.ops.aten.bmm.default(view_default_477, transpose_int_234);  view_default_477 = transpose_int_234 = None
        view_default_478 = torch.ops.aten.view.default(bmm_default_38, [24, 3, 64, 512, 1]);  bmm_default_38 = None
        permute_default_180 = torch.ops.aten.permute.default(view_default_478, [0, 1, 4, 3, 2]);  view_default_478 = None
        view_default_479 = torch.ops.aten.view.default(bmm_default_39, [24, 3, 512, 64, 1]);  bmm_default_39 = None
        permute_default_181 = torch.ops.aten.permute.default(view_default_479, [0, 1, 2, 4, 3]);  view_default_479 = None
        permute_default_182 = torch.ops.aten.permute.default(permute_default_180, [0, 1, 3, 4, 2]);  permute_default_180 = None
        squeeze_dim_38 = torch.ops.aten.squeeze.dim(permute_default_182, -1);  permute_default_182 = None
        permute_default_183 = torch.ops.aten.permute.default(permute_default_181, [0, 1, 2, 4, 3]);  permute_default_181 = None
        squeeze_dim_39 = torch.ops.aten.squeeze.dim(permute_default_183, -1);  permute_default_183 = None
        new_empty_default_74 = torch.ops.aten.new_empty.default(squeeze_dim_38, [1572864])
        zero__default_26 = torch.ops.aten.zero_.default(new_empty_default_74);  new_empty_default_74 = None
        arange_10 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_116 = torch.ops.aten.as_strided.default(arange_10, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_10 = None
        clone_default_157 = torch.ops.aten.clone.default(as_strided_default_116, memory_format = torch.contiguous_format);  as_strided_default_116 = None
        _unsafe_view_default_177 = torch.ops.aten._unsafe_view.default(clone_default_157, [2359296]);  clone_default_157 = None
        clone_default_158 = torch.ops.aten.clone.default(squeeze_dim_38, memory_format = torch.contiguous_format);  squeeze_dim_38 = None
        _unsafe_view_default_178 = torch.ops.aten._unsafe_view.default(clone_default_158, [2359296]);  clone_default_158 = None
        index_add__default_10 = torch.ops.aten.index_add_.default(zero__default_26, 0, _unsafe_view_default_177, _unsafe_view_default_178);  zero__default_26 = _unsafe_view_default_177 = _unsafe_view_default_178 = None
        as_strided_default_117 = torch.ops.aten.as_strided.default(index_add__default_10, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_10 = None
        view_default_480 = torch.ops.aten.view.default(as_strided_default_117, [24, 1024, 64]);  as_strided_default_117 = None
        new_empty_default_75 = torch.ops.aten.new_empty.default(squeeze_dim_39, [1572864])
        zero__default_27 = torch.ops.aten.zero_.default(new_empty_default_75);  new_empty_default_75 = None
        arange_11 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_118 = torch.ops.aten.as_strided.default(arange_11, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_11 = None
        clone_default_159 = torch.ops.aten.clone.default(as_strided_default_118, memory_format = torch.contiguous_format);  as_strided_default_118 = None
        _unsafe_view_default_179 = torch.ops.aten._unsafe_view.default(clone_default_159, [2359296]);  clone_default_159 = None
        view_default_481 = torch.ops.aten.view.default(squeeze_dim_39, [2359296]);  squeeze_dim_39 = None
        index_add__default_11 = torch.ops.aten.index_add_.default(zero__default_27, 0, _unsafe_view_default_179, view_default_481);  zero__default_27 = _unsafe_view_default_179 = view_default_481 = None
        as_strided_default_119 = torch.ops.aten.as_strided.default(index_add__default_11, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_11 = None
        view_default_482 = torch.ops.aten.view.default(as_strided_default_119, [24, 1024, 64]);  as_strided_default_119 = None
        view_default_483 = torch.ops.aten.view.default(view_default_480, [2, 12, 1024, 64]);  view_default_480 = None
        transpose_int_235 = torch.ops.aten.transpose.int(view_default_483, 1, 2);  view_default_483 = None
        view_default_484 = torch.ops.aten.view.default(view_default_482, [2, 12, 1024, 64]);  view_default_482 = None
        transpose_int_236 = torch.ops.aten.transpose.int(view_default_484, 1, 2);  view_default_484 = None
        transpose_int_237 = torch.ops.aten.transpose.int(transpose_int_235, 0, 1);  transpose_int_235 = None
        view_default_485 = torch.ops.aten.view.default(transpose_int_237, [1024, 2, 768]);  transpose_int_237 = None
        transpose_int_238 = torch.ops.aten.transpose.int(transpose_int_236, 0, 1);  transpose_int_236 = None
        view_default_486 = torch.ops.aten.view.default(transpose_int_238, [1024, 2, 768]);  transpose_int_238 = None
        div_tensor_3 = torch.ops.aten.div.Tensor(view_default_486, 8.0);  view_default_486 = None
        sum_dim_int_list_21 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_176, [0, 1], True)
        view_default_487 = torch.ops.aten.view.default(sum_dim_int_list_21, [768]);  sum_dim_int_list_21 = None
        view_default_488 = torch.ops.aten.view.default(_unsafe_view_default_176, [2048, 768]);  _unsafe_view_default_176 = None
        t_default_156 = torch.ops.aten.t.default(view_default_488)
        mm_default_90 = torch.ops.aten.mm.default(t_default_156, _unsafe_view_default_108);  t_default_156 = _unsafe_view_default_108 = None
        t_default_157 = torch.ops.aten.t.default(mm_default_90);  mm_default_90 = None
        t_default_158 = torch.ops.aten.t.default(t_default_50);  t_default_50 = None
        mm_default_91 = torch.ops.aten.mm.default(view_default_488, t_default_158);  view_default_488 = t_default_158 = None
        view_default_489 = torch.ops.aten.view.default(mm_default_91, [1024, 2, 768]);  mm_default_91 = None
        t_default_159 = torch.ops.aten.t.default(t_default_157);  t_default_157 = None
        sum_dim_int_list_22 = torch.ops.aten.sum.dim_IntList(view_default_485, [0, 1], True)
        view_default_490 = torch.ops.aten.view.default(sum_dim_int_list_22, [768]);  sum_dim_int_list_22 = None
        view_default_491 = torch.ops.aten.view.default(view_default_485, [2048, 768]);  view_default_485 = None
        t_default_160 = torch.ops.aten.t.default(view_default_491)
        mm_default_92 = torch.ops.aten.mm.default(t_default_160, _unsafe_view_default_106);  t_default_160 = _unsafe_view_default_106 = None
        t_default_161 = torch.ops.aten.t.default(mm_default_92);  mm_default_92 = None
        t_default_162 = torch.ops.aten.t.default(t_default_49);  t_default_49 = None
        mm_default_93 = torch.ops.aten.mm.default(view_default_491, t_default_162);  view_default_491 = t_default_162 = None
        view_default_492 = torch.ops.aten.view.default(mm_default_93, [1024, 2, 768]);  mm_default_93 = None
        add_tensor_105 = torch.ops.aten.add.Tensor(view_default_489, view_default_492);  view_default_489 = view_default_492 = None
        t_default_163 = torch.ops.aten.t.default(t_default_161);  t_default_161 = None
        sum_dim_int_list_23 = torch.ops.aten.sum.dim_IntList(div_tensor_3, [0, 1], True)
        view_default_493 = torch.ops.aten.view.default(sum_dim_int_list_23, [768]);  sum_dim_int_list_23 = None
        view_default_494 = torch.ops.aten.view.default(div_tensor_3, [2048, 768]);  div_tensor_3 = None
        t_default_164 = torch.ops.aten.t.default(view_default_494)
        mm_default_94 = torch.ops.aten.mm.default(t_default_164, _unsafe_view_default_104);  t_default_164 = _unsafe_view_default_104 = None
        t_default_165 = torch.ops.aten.t.default(mm_default_94);  mm_default_94 = None
        t_default_166 = torch.ops.aten.t.default(t_default_48);  t_default_48 = None
        mm_default_95 = torch.ops.aten.mm.default(view_default_494, t_default_166);  view_default_494 = t_default_166 = None
        view_default_495 = torch.ops.aten.view.default(mm_default_95, [1024, 2, 768]);  mm_default_95 = None
        add_tensor_106 = torch.ops.aten.add.Tensor(add_tensor_105, view_default_495);  add_tensor_105 = view_default_495 = None
        t_default_167 = torch.ops.aten.t.default(t_default_165);  t_default_165 = None
        transpose_int_239 = torch.ops.aten.transpose.int(add_tensor_106, 0, 1);  add_tensor_106 = None
        add_tensor_107 = torch.ops.aten.add.Tensor(getitem_93, transpose_int_239);  getitem_93 = transpose_int_239 = None
        native_layer_norm_backward_default_8 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_107, add_tensor_47, [768], getitem_46, getitem_47, primals_158, primals_157, [True, True, True]);  add_tensor_107 = add_tensor_47 = getitem_46 = getitem_47 = primals_158 = primals_157 = None
        getitem_96 = native_layer_norm_backward_default_8[0]
        getitem_97 = native_layer_norm_backward_default_8[1]
        getitem_98 = native_layer_norm_backward_default_8[2];  native_layer_norm_backward_default_8 = None
        view_default_496 = torch.ops.aten.view.default(getitem_96, [2048, 768])
        t_default_168 = torch.ops.aten.t.default(t_default_47);  t_default_47 = None
        mm_default_96 = torch.ops.aten.mm.default(view_default_496, t_default_168);  t_default_168 = None
        t_default_169 = torch.ops.aten.t.default(view_default_496)
        mm_default_97 = torch.ops.aten.mm.default(t_default_169, view_default_222);  t_default_169 = view_default_222 = None
        t_default_170 = torch.ops.aten.t.default(mm_default_97);  mm_default_97 = None
        sum_dim_int_list_24 = torch.ops.aten.sum.dim_IntList(view_default_496, [0], True);  view_default_496 = None
        view_default_497 = torch.ops.aten.view.default(sum_dim_int_list_24, [768]);  sum_dim_int_list_24 = None
        t_default_171 = torch.ops.aten.t.default(t_default_170);  t_default_170 = None
        view_default_498 = torch.ops.aten.view.default(mm_default_96, [2, 1024, 3072]);  mm_default_96 = None
        to_dtype_12 = torch.ops.aten.to.dtype(view_default_498, torch.float32);  view_default_498 = None
        to_dtype_13 = torch.ops.aten.to.dtype(view_default_221, torch.float32);  view_default_221 = None
        mul_tensor_40 = torch.ops.aten.mul.Tensor(to_dtype_13, 0.7071067811865476)
        erf_default_4 = torch.ops.aten.erf.default(mul_tensor_40);  mul_tensor_40 = None
        add_tensor_108 = torch.ops.aten.add.Tensor(erf_default_4, 1);  erf_default_4 = None
        mul_tensor_41 = torch.ops.aten.mul.Tensor(add_tensor_108, 0.5);  add_tensor_108 = None
        mul_tensor_42 = torch.ops.aten.mul.Tensor(to_dtype_13, to_dtype_13)
        mul_tensor_43 = torch.ops.aten.mul.Tensor(mul_tensor_42, -0.5);  mul_tensor_42 = None
        exp_default_4 = torch.ops.aten.exp.default(mul_tensor_43);  mul_tensor_43 = None
        mul_tensor_44 = torch.ops.aten.mul.Tensor(exp_default_4, 0.3989422804014327);  exp_default_4 = None
        mul_tensor_45 = torch.ops.aten.mul.Tensor(to_dtype_13, mul_tensor_44);  to_dtype_13 = mul_tensor_44 = None
        add_tensor_109 = torch.ops.aten.add.Tensor(mul_tensor_41, mul_tensor_45);  mul_tensor_41 = mul_tensor_45 = None
        mul_tensor_46 = torch.ops.aten.mul.Tensor(to_dtype_12, add_tensor_109);  to_dtype_12 = add_tensor_109 = None
        to_dtype_14 = torch.ops.aten.to.dtype(mul_tensor_46, torch.float32);  mul_tensor_46 = None
        view_default_499 = torch.ops.aten.view.default(to_dtype_14, [2048, 3072]);  to_dtype_14 = None
        t_default_172 = torch.ops.aten.t.default(t_default_46);  t_default_46 = None
        mm_default_98 = torch.ops.aten.mm.default(view_default_499, t_default_172);  t_default_172 = None
        t_default_173 = torch.ops.aten.t.default(view_default_499)
        mm_default_99 = torch.ops.aten.mm.default(t_default_173, view_default_220);  t_default_173 = view_default_220 = None
        t_default_174 = torch.ops.aten.t.default(mm_default_99);  mm_default_99 = None
        sum_dim_int_list_25 = torch.ops.aten.sum.dim_IntList(view_default_499, [0], True);  view_default_499 = None
        view_default_500 = torch.ops.aten.view.default(sum_dim_int_list_25, [3072]);  sum_dim_int_list_25 = None
        t_default_175 = torch.ops.aten.t.default(t_default_174);  t_default_174 = None
        view_default_501 = torch.ops.aten.view.default(mm_default_98, [2, 1024, 768]);  mm_default_98 = None
        add_tensor_110 = torch.ops.aten.add.Tensor(getitem_96, view_default_501);  getitem_96 = view_default_501 = None
        native_layer_norm_backward_default_9 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_110, add_tensor_46, [768], getitem_43, getitem_44, primals_146, primals_145, [True, True, True]);  add_tensor_110 = add_tensor_46 = getitem_43 = getitem_44 = primals_146 = primals_145 = None
        getitem_99 = native_layer_norm_backward_default_9[0]
        getitem_100 = native_layer_norm_backward_default_9[1]
        getitem_101 = native_layer_norm_backward_default_9[2];  native_layer_norm_backward_default_9 = None
        sum_dim_int_list_26 = torch.ops.aten.sum.dim_IntList(getitem_99, [0, 1], True)
        view_default_502 = torch.ops.aten.view.default(sum_dim_int_list_26, [768]);  sum_dim_int_list_26 = None
        view_default_503 = torch.ops.aten.view.default(getitem_99, [2048, 768])
        t_default_176 = torch.ops.aten.t.default(view_default_503)
        mm_default_100 = torch.ops.aten.mm.default(t_default_176, _unsafe_view_default_102);  t_default_176 = _unsafe_view_default_102 = None
        t_default_177 = torch.ops.aten.t.default(mm_default_100);  mm_default_100 = None
        t_default_178 = torch.ops.aten.t.default(t_default_45);  t_default_45 = None
        mm_default_101 = torch.ops.aten.mm.default(view_default_503, t_default_178);  view_default_503 = t_default_178 = None
        view_default_504 = torch.ops.aten.view.default(mm_default_101, [2, 1024, 768]);  mm_default_101 = None
        t_default_179 = torch.ops.aten.t.default(t_default_177);  t_default_177 = None
        transpose_int_240 = torch.ops.aten.transpose.int(view_default_504, 0, 1);  view_default_504 = None
        view_default_505 = torch.ops.aten.view.default(transpose_int_240, [1024, 2, 12, 64]);  transpose_int_240 = None
        transpose_int_241 = torch.ops.aten.transpose.int(view_default_505, 0, 1);  view_default_505 = None
        transpose_int_242 = torch.ops.aten.transpose.int(transpose_int_241, 1, 2);  transpose_int_241 = None
        clone_default_160 = torch.ops.aten.clone.default(transpose_int_242, memory_format = torch.contiguous_format);  transpose_int_242 = None
        _unsafe_view_default_180 = torch.ops.aten._unsafe_view.default(clone_default_160, [24, 4, 256, 64]);  clone_default_160 = None
        view_default_506 = torch.ops.aten.view.default(_unsafe_view_default_180, [24, 4, 256, 64, 1]);  _unsafe_view_default_180 = None
        permute_default_184 = torch.ops.aten.permute.default(view_default_506, [0, 1, 2, 4, 3]);  view_default_506 = None
        view_default_507 = torch.ops.aten.view.default(permute_default_184, [96, 256, 64]);  permute_default_184 = None
        transpose_int_243 = torch.ops.aten.transpose.int(view_default_216, 1, 2);  view_default_216 = None
        bmm_default_40 = torch.ops.aten.bmm.default(transpose_int_243, view_default_507);  transpose_int_243 = None
        transpose_int_244 = torch.ops.aten.transpose.int(_unsafe_view_default_100, 1, 2);  _unsafe_view_default_100 = None
        bmm_default_41 = torch.ops.aten.bmm.default(view_default_507, transpose_int_244);  view_default_507 = transpose_int_244 = None
        view_default_508 = torch.ops.aten.view.default(bmm_default_40, [24, 4, 768, 64, 1]);  bmm_default_40 = None
        permute_default_185 = torch.ops.aten.permute.default(view_default_508, [0, 1, 4, 3, 2]);  view_default_508 = None
        view_default_509 = torch.ops.aten.view.default(bmm_default_41, [24, 4, 256, 768, 1]);  bmm_default_41 = None
        permute_default_186 = torch.ops.aten.permute.default(view_default_509, [0, 1, 2, 4, 3]);  view_default_509 = None
        permute_default_187 = torch.ops.aten.permute.default(permute_default_185, [0, 1, 4, 3, 2]);  permute_default_185 = None
        squeeze_dim_40 = torch.ops.aten.squeeze.dim(permute_default_187, -1);  permute_default_187 = None
        permute_default_188 = torch.ops.aten.permute.default(permute_default_186, [0, 1, 2, 4, 3]);  permute_default_186 = None
        squeeze_dim_41 = torch.ops.aten.squeeze.dim(permute_default_188, -1);  permute_default_188 = None
        slice_backward_default_84 = torch.ops.aten.slice_backward.default(squeeze_dim_41, [24, 4, 256, 769], 3, 0, -1, 1);  squeeze_dim_41 = None
        slice_backward_default_85 = torch.ops.aten.slice_backward.default(slice_backward_default_84, [24, 4, 256, 769], 2, 0, 9223372036854775807, 1);  slice_backward_default_84 = None
        slice_backward_default_86 = torch.ops.aten.slice_backward.default(slice_backward_default_85, [24, 4, 256, 769], 1, 0, 9223372036854775807, 1);  slice_backward_default_85 = None
        slice_backward_default_87 = torch.ops.aten.slice_backward.default(slice_backward_default_86, [24, 4, 256, 769], 0, 0, 9223372036854775807, 1);  slice_backward_default_86 = None
        view_default_510 = torch.ops.aten.view.default(slice_backward_default_87, [24, 4, 196864]);  slice_backward_default_87 = None
        slice_backward_default_88 = torch.ops.aten.slice_backward.default(view_default_510, [24, 4, 197120], 2, 0, -256, 1);  view_default_510 = None
        slice_backward_default_89 = torch.ops.aten.slice_backward.default(slice_backward_default_88, [24, 4, 197120], 1, 0, 9223372036854775807, 1);  slice_backward_default_88 = None
        slice_backward_default_90 = torch.ops.aten.slice_backward.default(slice_backward_default_89, [24, 4, 197120], 0, 0, 9223372036854775807, 1);  slice_backward_default_89 = None
        view_default_511 = torch.ops.aten.view.default(slice_backward_default_90, [24, 4, 256, 770]);  slice_backward_default_90 = None
        constant_pad_nd_default_60 = torch.ops.aten.constant_pad_nd.default(view_default_511, [0, -257]);  view_default_511 = None
        new_empty_default_76 = torch.ops.aten.new_empty.default(squeeze_dim_40, [2359296])
        zero__default_28 = torch.ops.aten.zero_.default(new_empty_default_76);  new_empty_default_76 = None
        arange_12 = torch.ops.aten.arange.start(0, 2359296, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_120 = torch.ops.aten.as_strided.default(arange_12, [24, 4, 768, 64], [98304, 16384, 64, 1], 0);  arange_12 = None
        clone_default_161 = torch.ops.aten.clone.default(as_strided_default_120, memory_format = torch.contiguous_format);  as_strided_default_120 = None
        _unsafe_view_default_181 = torch.ops.aten._unsafe_view.default(clone_default_161, [4718592]);  clone_default_161 = None
        view_default_512 = torch.ops.aten.view.default(squeeze_dim_40, [4718592]);  squeeze_dim_40 = None
        index_add__default_12 = torch.ops.aten.index_add_.default(zero__default_28, 0, _unsafe_view_default_181, view_default_512);  zero__default_28 = _unsafe_view_default_181 = view_default_512 = None
        as_strided_default_121 = torch.ops.aten.as_strided.default(index_add__default_12, [24, 1536, 64], [98304, 64, 1], 0);  index_add__default_12 = None
        constant_pad_nd_default_61 = torch.ops.aten.constant_pad_nd.default(as_strided_default_121, [0, 0, -256, -256]);  as_strided_default_121 = None
        view_default_513 = torch.ops.aten.view.default(constant_pad_nd_default_61, [2, 12, 1024, 64]);  constant_pad_nd_default_61 = None
        transpose_int_245 = torch.ops.aten.transpose.int(view_default_513, 1, 2);  view_default_513 = None
        view_default_514 = torch.ops.aten.view.default(constant_pad_nd_default_60, [2, 12, 1024, 513]);  constant_pad_nd_default_60 = None
        transpose_int_246 = torch.ops.aten.transpose.int(view_default_514, 1, 2);  view_default_514 = None
        transpose_int_247 = torch.ops.aten.transpose.int(transpose_int_245, 0, 1);  transpose_int_245 = None
        clone_default_162 = torch.ops.aten.clone.default(transpose_int_247, memory_format = torch.contiguous_format);  transpose_int_247 = None
        _unsafe_view_default_182 = torch.ops.aten._unsafe_view.default(clone_default_162, [1024, 2, 768]);  clone_default_162 = None
        where_scalar_self_36 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_109, 0.0, transpose_int_246);  unsqueeze_default_109 = transpose_int_246 = None
        _softmax_backward_data_default_4 = torch.ops.aten._softmax_backward_data.default(where_scalar_self_36, _softmax_default_7, -1, torch.float32);  where_scalar_self_36 = _softmax_default_7 = None
        new_empty_default_77 = torch.ops.aten.new_empty.default(_softmax_backward_data_default_4, [12607488])
        zero__default_29 = torch.ops.aten.zero_.default(new_empty_default_77);  new_empty_default_77 = None
        as_strided_default_122 = torch.ops.aten.as_strided.default(zero__default_29, [2, 1024, 12, 513], [6303744, 513, 525312, 1], 0)
        copy__default_152 = torch.ops.aten.copy_.default(as_strided_default_122, _softmax_backward_data_default_4);  as_strided_default_122 = _softmax_backward_data_default_4 = None
        as_strided_default_123 = torch.ops.aten.as_strided.default(zero__default_29, [24, 4, 256, 513], [525312, 131328, 513, 1], 0);  zero__default_29 = None
        new_empty_strided_default_28 = torch.ops.aten.new_empty_strided.default(as_strided_default_123, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_153 = torch.ops.aten.copy_.default(new_empty_strided_default_28, as_strided_default_123);  new_empty_strided_default_28 = as_strided_default_123 = None
        as_strided_default_124 = torch.ops.aten.as_strided.default(copy__default_153, [2, 1024, 12, 513], [6303744, 513, 525312, 1], 0)
        clone_default_163 = torch.ops.aten.clone.default(as_strided_default_124, memory_format = torch.contiguous_format)
        copy__default_154 = torch.ops.aten.copy_.default(as_strided_default_124, clone_default_163);  as_strided_default_124 = clone_default_163 = None
        new_empty_strided_default_29 = torch.ops.aten.new_empty_strided.default(copy__default_153, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_155 = torch.ops.aten.copy_.default(new_empty_strided_default_29, copy__default_153);  new_empty_strided_default_29 = copy__default_153 = None
        as_strided_default_125 = torch.ops.aten.as_strided.default(copy__default_155, [2, 256, 12, 257], [6303744, 513, 525312, 1], 394240)
        clone_default_164 = torch.ops.aten.clone.default(as_strided_default_125, memory_format = torch.contiguous_format)
        where_scalar_self_37 = torch.ops.aten.where.ScalarSelf(eq_scalar_29, 0.0, clone_default_164);  eq_scalar_29 = clone_default_164 = None
        copy__default_156 = torch.ops.aten.copy_.default(as_strided_default_125, where_scalar_self_37);  as_strided_default_125 = where_scalar_self_37 = None
        new_empty_strided_default_30 = torch.ops.aten.new_empty_strided.default(copy__default_155, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_157 = torch.ops.aten.copy_.default(new_empty_strided_default_30, copy__default_155);  new_empty_strided_default_30 = copy__default_155 = None
        as_strided_default_126 = torch.ops.aten.as_strided.default(copy__default_157, [2, 256, 12, 257], [6303744, 513, 525312, 1], 0)
        clone_default_165 = torch.ops.aten.clone.default(as_strided_default_126, memory_format = torch.contiguous_format)
        where_scalar_self_38 = torch.ops.aten.where.ScalarSelf(eq_scalar_28, 0.0, clone_default_165);  eq_scalar_28 = clone_default_165 = None
        copy__default_158 = torch.ops.aten.copy_.default(as_strided_default_126, where_scalar_self_38);  as_strided_default_126 = where_scalar_self_38 = None
        new_empty_strided_default_31 = torch.ops.aten.new_empty_strided.default(copy__default_157, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_159 = torch.ops.aten.copy_.default(new_empty_strided_default_31, copy__default_157);  new_empty_strided_default_31 = copy__default_157 = None
        as_strided_default_127 = torch.ops.aten.as_strided.default(copy__default_159, [24, 255, 255], [525312, 513, 1], 514)
        clone_default_166 = torch.ops.aten.clone.default(as_strided_default_127, memory_format = torch.contiguous_format)
        empty_like_default_12 = torch.ops.aten.empty_like.default(clone_default_166, memory_format = torch.contiguous_format)
        zero__default_30 = torch.ops.aten.zero_.default(empty_like_default_12);  empty_like_default_12 = None
        copy__default_160 = torch.ops.aten.copy_.default(as_strided_default_127, zero__default_30);  as_strided_default_127 = zero__default_30 = None
        slice_backward_default_91 = torch.ops.aten.slice_backward.default(clone_default_166, [24, 255, 513], 2, -255, 9223372036854775807, 1);  clone_default_166 = None
        slice_backward_default_92 = torch.ops.aten.slice_backward.default(slice_backward_default_91, [24, 512, 513], 1, 0, 255, 1);  slice_backward_default_91 = None
        select_backward_default_8 = torch.ops.aten.select_backward.default(slice_backward_default_92, [24, 3, 512, 513], 1, 0);  slice_backward_default_92 = None
        slice_backward_default_93 = torch.ops.aten.slice_backward.default(select_backward_default_8, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_8 = None
        new_empty_strided_default_32 = torch.ops.aten.new_empty_strided.default(copy__default_159, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_161 = torch.ops.aten.copy_.default(new_empty_strided_default_32, copy__default_159);  new_empty_strided_default_32 = copy__default_159 = None
        as_strided_default_128 = torch.ops.aten.as_strided.default(copy__default_161, [24, 3, 256, 256], [525312, 131328, 513, 1], 131328)
        clone_default_167 = torch.ops.aten.clone.default(as_strided_default_128, memory_format = torch.contiguous_format)
        empty_like_default_13 = torch.ops.aten.empty_like.default(clone_default_167, memory_format = torch.contiguous_format)
        zero__default_31 = torch.ops.aten.zero_.default(empty_like_default_13);  empty_like_default_13 = None
        copy__default_162 = torch.ops.aten.copy_.default(as_strided_default_128, zero__default_31);  as_strided_default_128 = zero__default_31 = None
        slice_backward_default_94 = torch.ops.aten.slice_backward.default(clone_default_167, [24, 3, 256, 513], 3, 257, 9223372036854775807, 1);  clone_default_167 = None
        slice_backward_default_95 = torch.ops.aten.slice_backward.default(slice_backward_default_94, [24, 3, 512, 513], 2, -257, -1, 1);  slice_backward_default_94 = None
        slice_backward_default_96 = torch.ops.aten.slice_backward.default(slice_backward_default_95, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_95 = None
        slice_backward_default_97 = torch.ops.aten.slice_backward.default(slice_backward_default_96, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_96 = None
        add_tensor_111 = torch.ops.aten.add.Tensor(slice_backward_default_93, slice_backward_default_97);  slice_backward_default_93 = slice_backward_default_97 = None
        new_empty_strided_default_33 = torch.ops.aten.new_empty_strided.default(copy__default_161, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_163 = torch.ops.aten.copy_.default(new_empty_strided_default_33, copy__default_161);  new_empty_strided_default_33 = copy__default_161 = None
        as_strided_default_129 = torch.ops.aten.as_strided.default(copy__default_163, [24, 256, 257], [525312, 513, 1], 394240)
        clone_default_168 = torch.ops.aten.clone.default(as_strided_default_129, memory_format = torch.contiguous_format)
        empty_like_default_14 = torch.ops.aten.empty_like.default(clone_default_168, memory_format = torch.contiguous_format)
        zero__default_32 = torch.ops.aten.zero_.default(empty_like_default_14);  empty_like_default_14 = None
        copy__default_164 = torch.ops.aten.copy_.default(as_strided_default_129, zero__default_32);  as_strided_default_129 = zero__default_32 = None
        slice_backward_default_98 = torch.ops.aten.slice_backward.default(clone_default_168, [24, 256, 513], 2, 0, 257, 1);  clone_default_168 = None
        slice_backward_default_99 = torch.ops.aten.slice_backward.default(slice_backward_default_98, [24, 512, 513], 1, 256, 9223372036854775807, 1);  slice_backward_default_98 = None
        select_backward_default_9 = torch.ops.aten.select_backward.default(slice_backward_default_99, [24, 3, 512, 513], 1, -1);  slice_backward_default_99 = None
        slice_backward_default_100 = torch.ops.aten.slice_backward.default(select_backward_default_9, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_9 = None
        add_tensor_112 = torch.ops.aten.add.Tensor(add_tensor_111, slice_backward_default_100);  add_tensor_111 = slice_backward_default_100 = None
        new_empty_strided_default_34 = torch.ops.aten.new_empty_strided.default(copy__default_163, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_165 = torch.ops.aten.copy_.default(new_empty_strided_default_34, copy__default_163);  new_empty_strided_default_34 = copy__default_163 = None
        as_strided_default_130 = torch.ops.aten.as_strided.default(copy__default_165, [24, 3, 256, 257], [525312, 131328, 513, 1], 256);  copy__default_165 = None
        clone_default_169 = torch.ops.aten.clone.default(as_strided_default_130, memory_format = torch.contiguous_format);  as_strided_default_130 = None
        slice_backward_default_101 = torch.ops.aten.slice_backward.default(clone_default_169, [24, 3, 256, 513], 3, 0, 257, 1);  clone_default_169 = None
        slice_backward_default_102 = torch.ops.aten.slice_backward.default(slice_backward_default_101, [24, 3, 512, 513], 2, 0, 256, 1);  slice_backward_default_101 = None
        slice_backward_default_103 = torch.ops.aten.slice_backward.default(slice_backward_default_102, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_102 = None
        slice_backward_default_104 = torch.ops.aten.slice_backward.default(slice_backward_default_103, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_103 = None
        add_tensor_113 = torch.ops.aten.add.Tensor(add_tensor_112, slice_backward_default_104);  add_tensor_112 = slice_backward_default_104 = None
        view_default_515 = torch.ops.aten.view.default(add_tensor_113, [24, 3, 513, 512]);  add_tensor_113 = None
        constant_pad_nd_default_62 = torch.ops.aten.constant_pad_nd.default(view_default_515, [0, 0, 0, -1]);  view_default_515 = None
        view_default_516 = torch.ops.aten.view.default(constant_pad_nd_default_62, [24, 3, 512, 512, 1]);  constant_pad_nd_default_62 = None
        permute_default_189 = torch.ops.aten.permute.default(view_default_516, [0, 1, 2, 4, 3]);  view_default_516 = None
        view_default_517 = torch.ops.aten.view.default(permute_default_189, [72, 512, 512]);  permute_default_189 = None
        transpose_int_248 = torch.ops.aten.transpose.int(_unsafe_view_default_97, 1, 2);  _unsafe_view_default_97 = None
        bmm_default_42 = torch.ops.aten.bmm.default(transpose_int_248, view_default_517);  transpose_int_248 = None
        transpose_int_249 = torch.ops.aten.transpose.int(_unsafe_view_default_98, 1, 2);  _unsafe_view_default_98 = None
        bmm_default_43 = torch.ops.aten.bmm.default(view_default_517, transpose_int_249);  view_default_517 = transpose_int_249 = None
        view_default_518 = torch.ops.aten.view.default(bmm_default_42, [24, 3, 64, 512, 1]);  bmm_default_42 = None
        permute_default_190 = torch.ops.aten.permute.default(view_default_518, [0, 1, 4, 3, 2]);  view_default_518 = None
        view_default_519 = torch.ops.aten.view.default(bmm_default_43, [24, 3, 512, 64, 1]);  bmm_default_43 = None
        permute_default_191 = torch.ops.aten.permute.default(view_default_519, [0, 1, 2, 4, 3]);  view_default_519 = None
        permute_default_192 = torch.ops.aten.permute.default(permute_default_190, [0, 1, 3, 4, 2]);  permute_default_190 = None
        squeeze_dim_42 = torch.ops.aten.squeeze.dim(permute_default_192, -1);  permute_default_192 = None
        permute_default_193 = torch.ops.aten.permute.default(permute_default_191, [0, 1, 2, 4, 3]);  permute_default_191 = None
        squeeze_dim_43 = torch.ops.aten.squeeze.dim(permute_default_193, -1);  permute_default_193 = None
        new_empty_default_78 = torch.ops.aten.new_empty.default(squeeze_dim_42, [1572864])
        zero__default_33 = torch.ops.aten.zero_.default(new_empty_default_78);  new_empty_default_78 = None
        arange_13 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_131 = torch.ops.aten.as_strided.default(arange_13, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_13 = None
        clone_default_170 = torch.ops.aten.clone.default(as_strided_default_131, memory_format = torch.contiguous_format);  as_strided_default_131 = None
        _unsafe_view_default_183 = torch.ops.aten._unsafe_view.default(clone_default_170, [2359296]);  clone_default_170 = None
        clone_default_171 = torch.ops.aten.clone.default(squeeze_dim_42, memory_format = torch.contiguous_format);  squeeze_dim_42 = None
        _unsafe_view_default_184 = torch.ops.aten._unsafe_view.default(clone_default_171, [2359296]);  clone_default_171 = None
        index_add__default_13 = torch.ops.aten.index_add_.default(zero__default_33, 0, _unsafe_view_default_183, _unsafe_view_default_184);  zero__default_33 = _unsafe_view_default_183 = _unsafe_view_default_184 = None
        as_strided_default_132 = torch.ops.aten.as_strided.default(index_add__default_13, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_13 = None
        view_default_520 = torch.ops.aten.view.default(as_strided_default_132, [24, 1024, 64]);  as_strided_default_132 = None
        new_empty_default_79 = torch.ops.aten.new_empty.default(squeeze_dim_43, [1572864])
        zero__default_34 = torch.ops.aten.zero_.default(new_empty_default_79);  new_empty_default_79 = None
        arange_14 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_133 = torch.ops.aten.as_strided.default(arange_14, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_14 = None
        clone_default_172 = torch.ops.aten.clone.default(as_strided_default_133, memory_format = torch.contiguous_format);  as_strided_default_133 = None
        _unsafe_view_default_185 = torch.ops.aten._unsafe_view.default(clone_default_172, [2359296]);  clone_default_172 = None
        view_default_521 = torch.ops.aten.view.default(squeeze_dim_43, [2359296]);  squeeze_dim_43 = None
        index_add__default_14 = torch.ops.aten.index_add_.default(zero__default_34, 0, _unsafe_view_default_185, view_default_521);  zero__default_34 = _unsafe_view_default_185 = view_default_521 = None
        as_strided_default_134 = torch.ops.aten.as_strided.default(index_add__default_14, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_14 = None
        view_default_522 = torch.ops.aten.view.default(as_strided_default_134, [24, 1024, 64]);  as_strided_default_134 = None
        view_default_523 = torch.ops.aten.view.default(view_default_520, [2, 12, 1024, 64]);  view_default_520 = None
        transpose_int_250 = torch.ops.aten.transpose.int(view_default_523, 1, 2);  view_default_523 = None
        view_default_524 = torch.ops.aten.view.default(view_default_522, [2, 12, 1024, 64]);  view_default_522 = None
        transpose_int_251 = torch.ops.aten.transpose.int(view_default_524, 1, 2);  view_default_524 = None
        transpose_int_252 = torch.ops.aten.transpose.int(transpose_int_250, 0, 1);  transpose_int_250 = None
        view_default_525 = torch.ops.aten.view.default(transpose_int_252, [1024, 2, 768]);  transpose_int_252 = None
        transpose_int_253 = torch.ops.aten.transpose.int(transpose_int_251, 0, 1);  transpose_int_251 = None
        view_default_526 = torch.ops.aten.view.default(transpose_int_253, [1024, 2, 768]);  transpose_int_253 = None
        div_tensor_4 = torch.ops.aten.div.Tensor(view_default_526, 8.0);  view_default_526 = None
        sum_dim_int_list_27 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_182, [0, 1], True)
        view_default_527 = torch.ops.aten.view.default(sum_dim_int_list_27, [768]);  sum_dim_int_list_27 = None
        view_default_528 = torch.ops.aten.view.default(_unsafe_view_default_182, [2048, 768]);  _unsafe_view_default_182 = None
        t_default_180 = torch.ops.aten.t.default(view_default_528)
        mm_default_102 = torch.ops.aten.mm.default(t_default_180, _unsafe_view_default_95);  t_default_180 = _unsafe_view_default_95 = None
        t_default_181 = torch.ops.aten.t.default(mm_default_102);  mm_default_102 = None
        t_default_182 = torch.ops.aten.t.default(t_default_44);  t_default_44 = None
        mm_default_103 = torch.ops.aten.mm.default(view_default_528, t_default_182);  view_default_528 = t_default_182 = None
        view_default_529 = torch.ops.aten.view.default(mm_default_103, [1024, 2, 768]);  mm_default_103 = None
        t_default_183 = torch.ops.aten.t.default(t_default_181);  t_default_181 = None
        sum_dim_int_list_28 = torch.ops.aten.sum.dim_IntList(view_default_525, [0, 1], True)
        view_default_530 = torch.ops.aten.view.default(sum_dim_int_list_28, [768]);  sum_dim_int_list_28 = None
        view_default_531 = torch.ops.aten.view.default(view_default_525, [2048, 768]);  view_default_525 = None
        t_default_184 = torch.ops.aten.t.default(view_default_531)
        mm_default_104 = torch.ops.aten.mm.default(t_default_184, _unsafe_view_default_93);  t_default_184 = _unsafe_view_default_93 = None
        t_default_185 = torch.ops.aten.t.default(mm_default_104);  mm_default_104 = None
        t_default_186 = torch.ops.aten.t.default(t_default_43);  t_default_43 = None
        mm_default_105 = torch.ops.aten.mm.default(view_default_531, t_default_186);  view_default_531 = t_default_186 = None
        view_default_532 = torch.ops.aten.view.default(mm_default_105, [1024, 2, 768]);  mm_default_105 = None
        add_tensor_114 = torch.ops.aten.add.Tensor(view_default_529, view_default_532);  view_default_529 = view_default_532 = None
        t_default_187 = torch.ops.aten.t.default(t_default_185);  t_default_185 = None
        sum_dim_int_list_29 = torch.ops.aten.sum.dim_IntList(div_tensor_4, [0, 1], True)
        view_default_533 = torch.ops.aten.view.default(sum_dim_int_list_29, [768]);  sum_dim_int_list_29 = None
        view_default_534 = torch.ops.aten.view.default(div_tensor_4, [2048, 768]);  div_tensor_4 = None
        t_default_188 = torch.ops.aten.t.default(view_default_534)
        mm_default_106 = torch.ops.aten.mm.default(t_default_188, _unsafe_view_default_91);  t_default_188 = _unsafe_view_default_91 = None
        t_default_189 = torch.ops.aten.t.default(mm_default_106);  mm_default_106 = None
        t_default_190 = torch.ops.aten.t.default(t_default_42);  t_default_42 = None
        mm_default_107 = torch.ops.aten.mm.default(view_default_534, t_default_190);  view_default_534 = t_default_190 = None
        view_default_535 = torch.ops.aten.view.default(mm_default_107, [1024, 2, 768]);  mm_default_107 = None
        add_tensor_115 = torch.ops.aten.add.Tensor(add_tensor_114, view_default_535);  add_tensor_114 = view_default_535 = None
        t_default_191 = torch.ops.aten.t.default(t_default_189);  t_default_189 = None
        transpose_int_254 = torch.ops.aten.transpose.int(add_tensor_115, 0, 1);  add_tensor_115 = None
        add_tensor_116 = torch.ops.aten.add.Tensor(getitem_99, transpose_int_254);  getitem_99 = transpose_int_254 = None
        native_layer_norm_backward_default_10 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_116, add_tensor_41, [768], getitem_40, getitem_41, primals_142, primals_141, [True, True, True]);  add_tensor_116 = add_tensor_41 = getitem_40 = getitem_41 = primals_142 = primals_141 = None
        getitem_102 = native_layer_norm_backward_default_10[0]
        getitem_103 = native_layer_norm_backward_default_10[1]
        getitem_104 = native_layer_norm_backward_default_10[2];  native_layer_norm_backward_default_10 = None
        view_default_536 = torch.ops.aten.view.default(getitem_102, [2048, 768])
        t_default_192 = torch.ops.aten.t.default(t_default_41);  t_default_41 = None
        mm_default_108 = torch.ops.aten.mm.default(view_default_536, t_default_192);  t_default_192 = None
        t_default_193 = torch.ops.aten.t.default(view_default_536)
        mm_default_109 = torch.ops.aten.mm.default(t_default_193, view_default_194);  t_default_193 = view_default_194 = None
        t_default_194 = torch.ops.aten.t.default(mm_default_109);  mm_default_109 = None
        sum_dim_int_list_30 = torch.ops.aten.sum.dim_IntList(view_default_536, [0], True);  view_default_536 = None
        view_default_537 = torch.ops.aten.view.default(sum_dim_int_list_30, [768]);  sum_dim_int_list_30 = None
        t_default_195 = torch.ops.aten.t.default(t_default_194);  t_default_194 = None
        view_default_538 = torch.ops.aten.view.default(mm_default_108, [2, 1024, 3072]);  mm_default_108 = None
        to_dtype_15 = torch.ops.aten.to.dtype(view_default_538, torch.float32);  view_default_538 = None
        to_dtype_16 = torch.ops.aten.to.dtype(view_default_193, torch.float32);  view_default_193 = None
        mul_tensor_47 = torch.ops.aten.mul.Tensor(to_dtype_16, 0.7071067811865476)
        erf_default_5 = torch.ops.aten.erf.default(mul_tensor_47);  mul_tensor_47 = None
        add_tensor_117 = torch.ops.aten.add.Tensor(erf_default_5, 1);  erf_default_5 = None
        mul_tensor_48 = torch.ops.aten.mul.Tensor(add_tensor_117, 0.5);  add_tensor_117 = None
        mul_tensor_49 = torch.ops.aten.mul.Tensor(to_dtype_16, to_dtype_16)
        mul_tensor_50 = torch.ops.aten.mul.Tensor(mul_tensor_49, -0.5);  mul_tensor_49 = None
        exp_default_5 = torch.ops.aten.exp.default(mul_tensor_50);  mul_tensor_50 = None
        mul_tensor_51 = torch.ops.aten.mul.Tensor(exp_default_5, 0.3989422804014327);  exp_default_5 = None
        mul_tensor_52 = torch.ops.aten.mul.Tensor(to_dtype_16, mul_tensor_51);  to_dtype_16 = mul_tensor_51 = None
        add_tensor_118 = torch.ops.aten.add.Tensor(mul_tensor_48, mul_tensor_52);  mul_tensor_48 = mul_tensor_52 = None
        mul_tensor_53 = torch.ops.aten.mul.Tensor(to_dtype_15, add_tensor_118);  to_dtype_15 = add_tensor_118 = None
        to_dtype_17 = torch.ops.aten.to.dtype(mul_tensor_53, torch.float32);  mul_tensor_53 = None
        view_default_539 = torch.ops.aten.view.default(to_dtype_17, [2048, 3072]);  to_dtype_17 = None
        t_default_196 = torch.ops.aten.t.default(t_default_40);  t_default_40 = None
        mm_default_110 = torch.ops.aten.mm.default(view_default_539, t_default_196);  t_default_196 = None
        t_default_197 = torch.ops.aten.t.default(view_default_539)
        mm_default_111 = torch.ops.aten.mm.default(t_default_197, view_default_192);  t_default_197 = view_default_192 = None
        t_default_198 = torch.ops.aten.t.default(mm_default_111);  mm_default_111 = None
        sum_dim_int_list_31 = torch.ops.aten.sum.dim_IntList(view_default_539, [0], True);  view_default_539 = None
        view_default_540 = torch.ops.aten.view.default(sum_dim_int_list_31, [3072]);  sum_dim_int_list_31 = None
        t_default_199 = torch.ops.aten.t.default(t_default_198);  t_default_198 = None
        view_default_541 = torch.ops.aten.view.default(mm_default_110, [2, 1024, 768]);  mm_default_110 = None
        add_tensor_119 = torch.ops.aten.add.Tensor(getitem_102, view_default_541);  getitem_102 = view_default_541 = None
        native_layer_norm_backward_default_11 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_119, add_tensor_40, [768], getitem_37, getitem_38, primals_130, primals_129, [True, True, True]);  add_tensor_119 = add_tensor_40 = getitem_37 = getitem_38 = primals_130 = primals_129 = None
        getitem_105 = native_layer_norm_backward_default_11[0]
        getitem_106 = native_layer_norm_backward_default_11[1]
        getitem_107 = native_layer_norm_backward_default_11[2];  native_layer_norm_backward_default_11 = None
        sum_dim_int_list_32 = torch.ops.aten.sum.dim_IntList(getitem_105, [0, 1], True)
        view_default_542 = torch.ops.aten.view.default(sum_dim_int_list_32, [768]);  sum_dim_int_list_32 = None
        view_default_543 = torch.ops.aten.view.default(getitem_105, [2048, 768])
        t_default_200 = torch.ops.aten.t.default(view_default_543)
        mm_default_112 = torch.ops.aten.mm.default(t_default_200, _unsafe_view_default_89);  t_default_200 = _unsafe_view_default_89 = None
        t_default_201 = torch.ops.aten.t.default(mm_default_112);  mm_default_112 = None
        t_default_202 = torch.ops.aten.t.default(t_default_39);  t_default_39 = None
        mm_default_113 = torch.ops.aten.mm.default(view_default_543, t_default_202);  view_default_543 = t_default_202 = None
        view_default_544 = torch.ops.aten.view.default(mm_default_113, [2, 1024, 768]);  mm_default_113 = None
        t_default_203 = torch.ops.aten.t.default(t_default_201);  t_default_201 = None
        transpose_int_255 = torch.ops.aten.transpose.int(view_default_544, 0, 1);  view_default_544 = None
        view_default_545 = torch.ops.aten.view.default(transpose_int_255, [1024, 2, 12, 64]);  transpose_int_255 = None
        transpose_int_256 = torch.ops.aten.transpose.int(view_default_545, 0, 1);  view_default_545 = None
        transpose_int_257 = torch.ops.aten.transpose.int(transpose_int_256, 1, 2);  transpose_int_256 = None
        clone_default_173 = torch.ops.aten.clone.default(transpose_int_257, memory_format = torch.contiguous_format);  transpose_int_257 = None
        _unsafe_view_default_186 = torch.ops.aten._unsafe_view.default(clone_default_173, [24, 4, 256, 64]);  clone_default_173 = None
        view_default_546 = torch.ops.aten.view.default(_unsafe_view_default_186, [24, 4, 256, 64, 1]);  _unsafe_view_default_186 = None
        permute_default_194 = torch.ops.aten.permute.default(view_default_546, [0, 1, 2, 4, 3]);  view_default_546 = None
        view_default_547 = torch.ops.aten.view.default(permute_default_194, [96, 256, 64]);  permute_default_194 = None
        transpose_int_258 = torch.ops.aten.transpose.int(view_default_188, 1, 2);  view_default_188 = None
        bmm_default_44 = torch.ops.aten.bmm.default(transpose_int_258, view_default_547);  transpose_int_258 = None
        transpose_int_259 = torch.ops.aten.transpose.int(_unsafe_view_default_87, 1, 2);  _unsafe_view_default_87 = None
        bmm_default_45 = torch.ops.aten.bmm.default(view_default_547, transpose_int_259);  view_default_547 = transpose_int_259 = None
        view_default_548 = torch.ops.aten.view.default(bmm_default_44, [24, 4, 768, 64, 1]);  bmm_default_44 = None
        permute_default_195 = torch.ops.aten.permute.default(view_default_548, [0, 1, 4, 3, 2]);  view_default_548 = None
        view_default_549 = torch.ops.aten.view.default(bmm_default_45, [24, 4, 256, 768, 1]);  bmm_default_45 = None
        permute_default_196 = torch.ops.aten.permute.default(view_default_549, [0, 1, 2, 4, 3]);  view_default_549 = None
        permute_default_197 = torch.ops.aten.permute.default(permute_default_195, [0, 1, 4, 3, 2]);  permute_default_195 = None
        squeeze_dim_44 = torch.ops.aten.squeeze.dim(permute_default_197, -1);  permute_default_197 = None
        permute_default_198 = torch.ops.aten.permute.default(permute_default_196, [0, 1, 2, 4, 3]);  permute_default_196 = None
        squeeze_dim_45 = torch.ops.aten.squeeze.dim(permute_default_198, -1);  permute_default_198 = None
        slice_backward_default_105 = torch.ops.aten.slice_backward.default(squeeze_dim_45, [24, 4, 256, 769], 3, 0, -1, 1);  squeeze_dim_45 = None
        slice_backward_default_106 = torch.ops.aten.slice_backward.default(slice_backward_default_105, [24, 4, 256, 769], 2, 0, 9223372036854775807, 1);  slice_backward_default_105 = None
        slice_backward_default_107 = torch.ops.aten.slice_backward.default(slice_backward_default_106, [24, 4, 256, 769], 1, 0, 9223372036854775807, 1);  slice_backward_default_106 = None
        slice_backward_default_108 = torch.ops.aten.slice_backward.default(slice_backward_default_107, [24, 4, 256, 769], 0, 0, 9223372036854775807, 1);  slice_backward_default_107 = None
        view_default_550 = torch.ops.aten.view.default(slice_backward_default_108, [24, 4, 196864]);  slice_backward_default_108 = None
        slice_backward_default_109 = torch.ops.aten.slice_backward.default(view_default_550, [24, 4, 197120], 2, 0, -256, 1);  view_default_550 = None
        slice_backward_default_110 = torch.ops.aten.slice_backward.default(slice_backward_default_109, [24, 4, 197120], 1, 0, 9223372036854775807, 1);  slice_backward_default_109 = None
        slice_backward_default_111 = torch.ops.aten.slice_backward.default(slice_backward_default_110, [24, 4, 197120], 0, 0, 9223372036854775807, 1);  slice_backward_default_110 = None
        view_default_551 = torch.ops.aten.view.default(slice_backward_default_111, [24, 4, 256, 770]);  slice_backward_default_111 = None
        constant_pad_nd_default_63 = torch.ops.aten.constant_pad_nd.default(view_default_551, [0, -257]);  view_default_551 = None
        new_empty_default_80 = torch.ops.aten.new_empty.default(squeeze_dim_44, [2359296])
        zero__default_35 = torch.ops.aten.zero_.default(new_empty_default_80);  new_empty_default_80 = None
        arange_15 = torch.ops.aten.arange.start(0, 2359296, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_135 = torch.ops.aten.as_strided.default(arange_15, [24, 4, 768, 64], [98304, 16384, 64, 1], 0);  arange_15 = None
        clone_default_174 = torch.ops.aten.clone.default(as_strided_default_135, memory_format = torch.contiguous_format);  as_strided_default_135 = None
        _unsafe_view_default_187 = torch.ops.aten._unsafe_view.default(clone_default_174, [4718592]);  clone_default_174 = None
        view_default_552 = torch.ops.aten.view.default(squeeze_dim_44, [4718592]);  squeeze_dim_44 = None
        index_add__default_15 = torch.ops.aten.index_add_.default(zero__default_35, 0, _unsafe_view_default_187, view_default_552);  zero__default_35 = _unsafe_view_default_187 = view_default_552 = None
        as_strided_default_136 = torch.ops.aten.as_strided.default(index_add__default_15, [24, 1536, 64], [98304, 64, 1], 0);  index_add__default_15 = None
        constant_pad_nd_default_64 = torch.ops.aten.constant_pad_nd.default(as_strided_default_136, [0, 0, -256, -256]);  as_strided_default_136 = None
        view_default_553 = torch.ops.aten.view.default(constant_pad_nd_default_64, [2, 12, 1024, 64]);  constant_pad_nd_default_64 = None
        transpose_int_260 = torch.ops.aten.transpose.int(view_default_553, 1, 2);  view_default_553 = None
        view_default_554 = torch.ops.aten.view.default(constant_pad_nd_default_63, [2, 12, 1024, 513]);  constant_pad_nd_default_63 = None
        transpose_int_261 = torch.ops.aten.transpose.int(view_default_554, 1, 2);  view_default_554 = None
        transpose_int_262 = torch.ops.aten.transpose.int(transpose_int_260, 0, 1);  transpose_int_260 = None
        clone_default_175 = torch.ops.aten.clone.default(transpose_int_262, memory_format = torch.contiguous_format);  transpose_int_262 = None
        _unsafe_view_default_188 = torch.ops.aten._unsafe_view.default(clone_default_175, [1024, 2, 768]);  clone_default_175 = None
        where_scalar_self_39 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_95, 0.0, transpose_int_261);  unsqueeze_default_95 = transpose_int_261 = None
        _softmax_backward_data_default_5 = torch.ops.aten._softmax_backward_data.default(where_scalar_self_39, _softmax_default_6, -1, torch.float32);  where_scalar_self_39 = _softmax_default_6 = None
        new_empty_default_81 = torch.ops.aten.new_empty.default(_softmax_backward_data_default_5, [12607488])
        zero__default_36 = torch.ops.aten.zero_.default(new_empty_default_81);  new_empty_default_81 = None
        as_strided_default_137 = torch.ops.aten.as_strided.default(zero__default_36, [2, 1024, 12, 513], [6303744, 513, 525312, 1], 0)
        copy__default_166 = torch.ops.aten.copy_.default(as_strided_default_137, _softmax_backward_data_default_5);  as_strided_default_137 = _softmax_backward_data_default_5 = None
        as_strided_default_138 = torch.ops.aten.as_strided.default(zero__default_36, [24, 4, 256, 513], [525312, 131328, 513, 1], 0);  zero__default_36 = None
        new_empty_strided_default_35 = torch.ops.aten.new_empty_strided.default(as_strided_default_138, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_167 = torch.ops.aten.copy_.default(new_empty_strided_default_35, as_strided_default_138);  new_empty_strided_default_35 = as_strided_default_138 = None
        as_strided_default_139 = torch.ops.aten.as_strided.default(copy__default_167, [2, 1024, 12, 513], [6303744, 513, 525312, 1], 0)
        clone_default_176 = torch.ops.aten.clone.default(as_strided_default_139, memory_format = torch.contiguous_format)
        copy__default_168 = torch.ops.aten.copy_.default(as_strided_default_139, clone_default_176);  as_strided_default_139 = clone_default_176 = None
        new_empty_strided_default_36 = torch.ops.aten.new_empty_strided.default(copy__default_167, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_169 = torch.ops.aten.copy_.default(new_empty_strided_default_36, copy__default_167);  new_empty_strided_default_36 = copy__default_167 = None
        as_strided_default_140 = torch.ops.aten.as_strided.default(copy__default_169, [2, 256, 12, 257], [6303744, 513, 525312, 1], 394240)
        clone_default_177 = torch.ops.aten.clone.default(as_strided_default_140, memory_format = torch.contiguous_format)
        where_scalar_self_40 = torch.ops.aten.where.ScalarSelf(eq_scalar_25, 0.0, clone_default_177);  eq_scalar_25 = clone_default_177 = None
        copy__default_170 = torch.ops.aten.copy_.default(as_strided_default_140, where_scalar_self_40);  as_strided_default_140 = where_scalar_self_40 = None
        new_empty_strided_default_37 = torch.ops.aten.new_empty_strided.default(copy__default_169, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_171 = torch.ops.aten.copy_.default(new_empty_strided_default_37, copy__default_169);  new_empty_strided_default_37 = copy__default_169 = None
        as_strided_default_141 = torch.ops.aten.as_strided.default(copy__default_171, [2, 256, 12, 257], [6303744, 513, 525312, 1], 0)
        clone_default_178 = torch.ops.aten.clone.default(as_strided_default_141, memory_format = torch.contiguous_format)
        where_scalar_self_41 = torch.ops.aten.where.ScalarSelf(eq_scalar_24, 0.0, clone_default_178);  eq_scalar_24 = clone_default_178 = None
        copy__default_172 = torch.ops.aten.copy_.default(as_strided_default_141, where_scalar_self_41);  as_strided_default_141 = where_scalar_self_41 = None
        new_empty_strided_default_38 = torch.ops.aten.new_empty_strided.default(copy__default_171, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_173 = torch.ops.aten.copy_.default(new_empty_strided_default_38, copy__default_171);  new_empty_strided_default_38 = copy__default_171 = None
        as_strided_default_142 = torch.ops.aten.as_strided.default(copy__default_173, [24, 255, 255], [525312, 513, 1], 514)
        clone_default_179 = torch.ops.aten.clone.default(as_strided_default_142, memory_format = torch.contiguous_format)
        empty_like_default_15 = torch.ops.aten.empty_like.default(clone_default_179, memory_format = torch.contiguous_format)
        zero__default_37 = torch.ops.aten.zero_.default(empty_like_default_15);  empty_like_default_15 = None
        copy__default_174 = torch.ops.aten.copy_.default(as_strided_default_142, zero__default_37);  as_strided_default_142 = zero__default_37 = None
        slice_backward_default_112 = torch.ops.aten.slice_backward.default(clone_default_179, [24, 255, 513], 2, -255, 9223372036854775807, 1);  clone_default_179 = None
        slice_backward_default_113 = torch.ops.aten.slice_backward.default(slice_backward_default_112, [24, 512, 513], 1, 0, 255, 1);  slice_backward_default_112 = None
        select_backward_default_10 = torch.ops.aten.select_backward.default(slice_backward_default_113, [24, 3, 512, 513], 1, 0);  slice_backward_default_113 = None
        slice_backward_default_114 = torch.ops.aten.slice_backward.default(select_backward_default_10, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_10 = None
        new_empty_strided_default_39 = torch.ops.aten.new_empty_strided.default(copy__default_173, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_175 = torch.ops.aten.copy_.default(new_empty_strided_default_39, copy__default_173);  new_empty_strided_default_39 = copy__default_173 = None
        as_strided_default_143 = torch.ops.aten.as_strided.default(copy__default_175, [24, 3, 256, 256], [525312, 131328, 513, 1], 131328)
        clone_default_180 = torch.ops.aten.clone.default(as_strided_default_143, memory_format = torch.contiguous_format)
        empty_like_default_16 = torch.ops.aten.empty_like.default(clone_default_180, memory_format = torch.contiguous_format)
        zero__default_38 = torch.ops.aten.zero_.default(empty_like_default_16);  empty_like_default_16 = None
        copy__default_176 = torch.ops.aten.copy_.default(as_strided_default_143, zero__default_38);  as_strided_default_143 = zero__default_38 = None
        slice_backward_default_115 = torch.ops.aten.slice_backward.default(clone_default_180, [24, 3, 256, 513], 3, 257, 9223372036854775807, 1);  clone_default_180 = None
        slice_backward_default_116 = torch.ops.aten.slice_backward.default(slice_backward_default_115, [24, 3, 512, 513], 2, -257, -1, 1);  slice_backward_default_115 = None
        slice_backward_default_117 = torch.ops.aten.slice_backward.default(slice_backward_default_116, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_116 = None
        slice_backward_default_118 = torch.ops.aten.slice_backward.default(slice_backward_default_117, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_117 = None
        add_tensor_120 = torch.ops.aten.add.Tensor(slice_backward_default_114, slice_backward_default_118);  slice_backward_default_114 = slice_backward_default_118 = None
        new_empty_strided_default_40 = torch.ops.aten.new_empty_strided.default(copy__default_175, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_177 = torch.ops.aten.copy_.default(new_empty_strided_default_40, copy__default_175);  new_empty_strided_default_40 = copy__default_175 = None
        as_strided_default_144 = torch.ops.aten.as_strided.default(copy__default_177, [24, 256, 257], [525312, 513, 1], 394240)
        clone_default_181 = torch.ops.aten.clone.default(as_strided_default_144, memory_format = torch.contiguous_format)
        empty_like_default_17 = torch.ops.aten.empty_like.default(clone_default_181, memory_format = torch.contiguous_format)
        zero__default_39 = torch.ops.aten.zero_.default(empty_like_default_17);  empty_like_default_17 = None
        copy__default_178 = torch.ops.aten.copy_.default(as_strided_default_144, zero__default_39);  as_strided_default_144 = zero__default_39 = None
        slice_backward_default_119 = torch.ops.aten.slice_backward.default(clone_default_181, [24, 256, 513], 2, 0, 257, 1);  clone_default_181 = None
        slice_backward_default_120 = torch.ops.aten.slice_backward.default(slice_backward_default_119, [24, 512, 513], 1, 256, 9223372036854775807, 1);  slice_backward_default_119 = None
        select_backward_default_11 = torch.ops.aten.select_backward.default(slice_backward_default_120, [24, 3, 512, 513], 1, -1);  slice_backward_default_120 = None
        slice_backward_default_121 = torch.ops.aten.slice_backward.default(select_backward_default_11, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_11 = None
        add_tensor_121 = torch.ops.aten.add.Tensor(add_tensor_120, slice_backward_default_121);  add_tensor_120 = slice_backward_default_121 = None
        new_empty_strided_default_41 = torch.ops.aten.new_empty_strided.default(copy__default_177, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_179 = torch.ops.aten.copy_.default(new_empty_strided_default_41, copy__default_177);  new_empty_strided_default_41 = copy__default_177 = None
        as_strided_default_145 = torch.ops.aten.as_strided.default(copy__default_179, [24, 3, 256, 257], [525312, 131328, 513, 1], 256);  copy__default_179 = None
        clone_default_182 = torch.ops.aten.clone.default(as_strided_default_145, memory_format = torch.contiguous_format);  as_strided_default_145 = None
        slice_backward_default_122 = torch.ops.aten.slice_backward.default(clone_default_182, [24, 3, 256, 513], 3, 0, 257, 1);  clone_default_182 = None
        slice_backward_default_123 = torch.ops.aten.slice_backward.default(slice_backward_default_122, [24, 3, 512, 513], 2, 0, 256, 1);  slice_backward_default_122 = None
        slice_backward_default_124 = torch.ops.aten.slice_backward.default(slice_backward_default_123, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_123 = None
        slice_backward_default_125 = torch.ops.aten.slice_backward.default(slice_backward_default_124, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_124 = None
        add_tensor_122 = torch.ops.aten.add.Tensor(add_tensor_121, slice_backward_default_125);  add_tensor_121 = slice_backward_default_125 = None
        view_default_555 = torch.ops.aten.view.default(add_tensor_122, [24, 3, 513, 512]);  add_tensor_122 = None
        constant_pad_nd_default_65 = torch.ops.aten.constant_pad_nd.default(view_default_555, [0, 0, 0, -1]);  view_default_555 = None
        view_default_556 = torch.ops.aten.view.default(constant_pad_nd_default_65, [24, 3, 512, 512, 1]);  constant_pad_nd_default_65 = None
        permute_default_199 = torch.ops.aten.permute.default(view_default_556, [0, 1, 2, 4, 3]);  view_default_556 = None
        view_default_557 = torch.ops.aten.view.default(permute_default_199, [72, 512, 512]);  permute_default_199 = None
        transpose_int_263 = torch.ops.aten.transpose.int(_unsafe_view_default_84, 1, 2);  _unsafe_view_default_84 = None
        bmm_default_46 = torch.ops.aten.bmm.default(transpose_int_263, view_default_557);  transpose_int_263 = None
        transpose_int_264 = torch.ops.aten.transpose.int(_unsafe_view_default_85, 1, 2);  _unsafe_view_default_85 = None
        bmm_default_47 = torch.ops.aten.bmm.default(view_default_557, transpose_int_264);  view_default_557 = transpose_int_264 = None
        view_default_558 = torch.ops.aten.view.default(bmm_default_46, [24, 3, 64, 512, 1]);  bmm_default_46 = None
        permute_default_200 = torch.ops.aten.permute.default(view_default_558, [0, 1, 4, 3, 2]);  view_default_558 = None
        view_default_559 = torch.ops.aten.view.default(bmm_default_47, [24, 3, 512, 64, 1]);  bmm_default_47 = None
        permute_default_201 = torch.ops.aten.permute.default(view_default_559, [0, 1, 2, 4, 3]);  view_default_559 = None
        permute_default_202 = torch.ops.aten.permute.default(permute_default_200, [0, 1, 3, 4, 2]);  permute_default_200 = None
        squeeze_dim_46 = torch.ops.aten.squeeze.dim(permute_default_202, -1);  permute_default_202 = None
        permute_default_203 = torch.ops.aten.permute.default(permute_default_201, [0, 1, 2, 4, 3]);  permute_default_201 = None
        squeeze_dim_47 = torch.ops.aten.squeeze.dim(permute_default_203, -1);  permute_default_203 = None
        new_empty_default_82 = torch.ops.aten.new_empty.default(squeeze_dim_46, [1572864])
        zero__default_40 = torch.ops.aten.zero_.default(new_empty_default_82);  new_empty_default_82 = None
        arange_16 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_146 = torch.ops.aten.as_strided.default(arange_16, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_16 = None
        clone_default_183 = torch.ops.aten.clone.default(as_strided_default_146, memory_format = torch.contiguous_format);  as_strided_default_146 = None
        _unsafe_view_default_189 = torch.ops.aten._unsafe_view.default(clone_default_183, [2359296]);  clone_default_183 = None
        clone_default_184 = torch.ops.aten.clone.default(squeeze_dim_46, memory_format = torch.contiguous_format);  squeeze_dim_46 = None
        _unsafe_view_default_190 = torch.ops.aten._unsafe_view.default(clone_default_184, [2359296]);  clone_default_184 = None
        index_add__default_16 = torch.ops.aten.index_add_.default(zero__default_40, 0, _unsafe_view_default_189, _unsafe_view_default_190);  zero__default_40 = _unsafe_view_default_189 = _unsafe_view_default_190 = None
        as_strided_default_147 = torch.ops.aten.as_strided.default(index_add__default_16, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_16 = None
        view_default_560 = torch.ops.aten.view.default(as_strided_default_147, [24, 1024, 64]);  as_strided_default_147 = None
        new_empty_default_83 = torch.ops.aten.new_empty.default(squeeze_dim_47, [1572864])
        zero__default_41 = torch.ops.aten.zero_.default(new_empty_default_83);  new_empty_default_83 = None
        arange_17 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_148 = torch.ops.aten.as_strided.default(arange_17, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_17 = None
        clone_default_185 = torch.ops.aten.clone.default(as_strided_default_148, memory_format = torch.contiguous_format);  as_strided_default_148 = None
        _unsafe_view_default_191 = torch.ops.aten._unsafe_view.default(clone_default_185, [2359296]);  clone_default_185 = None
        view_default_561 = torch.ops.aten.view.default(squeeze_dim_47, [2359296]);  squeeze_dim_47 = None
        index_add__default_17 = torch.ops.aten.index_add_.default(zero__default_41, 0, _unsafe_view_default_191, view_default_561);  zero__default_41 = _unsafe_view_default_191 = view_default_561 = None
        as_strided_default_149 = torch.ops.aten.as_strided.default(index_add__default_17, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_17 = None
        view_default_562 = torch.ops.aten.view.default(as_strided_default_149, [24, 1024, 64]);  as_strided_default_149 = None
        view_default_563 = torch.ops.aten.view.default(view_default_560, [2, 12, 1024, 64]);  view_default_560 = None
        transpose_int_265 = torch.ops.aten.transpose.int(view_default_563, 1, 2);  view_default_563 = None
        view_default_564 = torch.ops.aten.view.default(view_default_562, [2, 12, 1024, 64]);  view_default_562 = None
        transpose_int_266 = torch.ops.aten.transpose.int(view_default_564, 1, 2);  view_default_564 = None
        transpose_int_267 = torch.ops.aten.transpose.int(transpose_int_265, 0, 1);  transpose_int_265 = None
        view_default_565 = torch.ops.aten.view.default(transpose_int_267, [1024, 2, 768]);  transpose_int_267 = None
        transpose_int_268 = torch.ops.aten.transpose.int(transpose_int_266, 0, 1);  transpose_int_266 = None
        view_default_566 = torch.ops.aten.view.default(transpose_int_268, [1024, 2, 768]);  transpose_int_268 = None
        div_tensor_5 = torch.ops.aten.div.Tensor(view_default_566, 8.0);  view_default_566 = None
        sum_dim_int_list_33 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_188, [0, 1], True)
        view_default_567 = torch.ops.aten.view.default(sum_dim_int_list_33, [768]);  sum_dim_int_list_33 = None
        view_default_568 = torch.ops.aten.view.default(_unsafe_view_default_188, [2048, 768]);  _unsafe_view_default_188 = None
        t_default_204 = torch.ops.aten.t.default(view_default_568)
        mm_default_114 = torch.ops.aten.mm.default(t_default_204, _unsafe_view_default_82);  t_default_204 = _unsafe_view_default_82 = None
        t_default_205 = torch.ops.aten.t.default(mm_default_114);  mm_default_114 = None
        t_default_206 = torch.ops.aten.t.default(t_default_38);  t_default_38 = None
        mm_default_115 = torch.ops.aten.mm.default(view_default_568, t_default_206);  view_default_568 = t_default_206 = None
        view_default_569 = torch.ops.aten.view.default(mm_default_115, [1024, 2, 768]);  mm_default_115 = None
        t_default_207 = torch.ops.aten.t.default(t_default_205);  t_default_205 = None
        sum_dim_int_list_34 = torch.ops.aten.sum.dim_IntList(view_default_565, [0, 1], True)
        view_default_570 = torch.ops.aten.view.default(sum_dim_int_list_34, [768]);  sum_dim_int_list_34 = None
        view_default_571 = torch.ops.aten.view.default(view_default_565, [2048, 768]);  view_default_565 = None
        t_default_208 = torch.ops.aten.t.default(view_default_571)
        mm_default_116 = torch.ops.aten.mm.default(t_default_208, _unsafe_view_default_80);  t_default_208 = _unsafe_view_default_80 = None
        t_default_209 = torch.ops.aten.t.default(mm_default_116);  mm_default_116 = None
        t_default_210 = torch.ops.aten.t.default(t_default_37);  t_default_37 = None
        mm_default_117 = torch.ops.aten.mm.default(view_default_571, t_default_210);  view_default_571 = t_default_210 = None
        view_default_572 = torch.ops.aten.view.default(mm_default_117, [1024, 2, 768]);  mm_default_117 = None
        add_tensor_123 = torch.ops.aten.add.Tensor(view_default_569, view_default_572);  view_default_569 = view_default_572 = None
        t_default_211 = torch.ops.aten.t.default(t_default_209);  t_default_209 = None
        sum_dim_int_list_35 = torch.ops.aten.sum.dim_IntList(div_tensor_5, [0, 1], True)
        view_default_573 = torch.ops.aten.view.default(sum_dim_int_list_35, [768]);  sum_dim_int_list_35 = None
        view_default_574 = torch.ops.aten.view.default(div_tensor_5, [2048, 768]);  div_tensor_5 = None
        t_default_212 = torch.ops.aten.t.default(view_default_574)
        mm_default_118 = torch.ops.aten.mm.default(t_default_212, _unsafe_view_default_78);  t_default_212 = _unsafe_view_default_78 = None
        t_default_213 = torch.ops.aten.t.default(mm_default_118);  mm_default_118 = None
        t_default_214 = torch.ops.aten.t.default(t_default_36);  t_default_36 = None
        mm_default_119 = torch.ops.aten.mm.default(view_default_574, t_default_214);  view_default_574 = t_default_214 = None
        view_default_575 = torch.ops.aten.view.default(mm_default_119, [1024, 2, 768]);  mm_default_119 = None
        add_tensor_124 = torch.ops.aten.add.Tensor(add_tensor_123, view_default_575);  add_tensor_123 = view_default_575 = None
        t_default_215 = torch.ops.aten.t.default(t_default_213);  t_default_213 = None
        transpose_int_269 = torch.ops.aten.transpose.int(add_tensor_124, 0, 1);  add_tensor_124 = None
        add_tensor_125 = torch.ops.aten.add.Tensor(getitem_105, transpose_int_269);  getitem_105 = transpose_int_269 = None
        native_layer_norm_backward_default_12 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_125, add_tensor_35, [768], getitem_34, getitem_35, primals_126, primals_125, [True, True, True]);  add_tensor_125 = add_tensor_35 = getitem_34 = getitem_35 = primals_126 = primals_125 = None
        getitem_108 = native_layer_norm_backward_default_12[0]
        getitem_109 = native_layer_norm_backward_default_12[1]
        getitem_110 = native_layer_norm_backward_default_12[2];  native_layer_norm_backward_default_12 = None
        view_default_576 = torch.ops.aten.view.default(getitem_108, [2048, 768])
        t_default_216 = torch.ops.aten.t.default(t_default_35);  t_default_35 = None
        mm_default_120 = torch.ops.aten.mm.default(view_default_576, t_default_216);  t_default_216 = None
        t_default_217 = torch.ops.aten.t.default(view_default_576)
        mm_default_121 = torch.ops.aten.mm.default(t_default_217, view_default_166);  t_default_217 = view_default_166 = None
        t_default_218 = torch.ops.aten.t.default(mm_default_121);  mm_default_121 = None
        sum_dim_int_list_36 = torch.ops.aten.sum.dim_IntList(view_default_576, [0], True);  view_default_576 = None
        view_default_577 = torch.ops.aten.view.default(sum_dim_int_list_36, [768]);  sum_dim_int_list_36 = None
        t_default_219 = torch.ops.aten.t.default(t_default_218);  t_default_218 = None
        view_default_578 = torch.ops.aten.view.default(mm_default_120, [2, 1024, 3072]);  mm_default_120 = None
        to_dtype_18 = torch.ops.aten.to.dtype(view_default_578, torch.float32);  view_default_578 = None
        to_dtype_19 = torch.ops.aten.to.dtype(view_default_165, torch.float32);  view_default_165 = None
        mul_tensor_54 = torch.ops.aten.mul.Tensor(to_dtype_19, 0.7071067811865476)
        erf_default_6 = torch.ops.aten.erf.default(mul_tensor_54);  mul_tensor_54 = None
        add_tensor_126 = torch.ops.aten.add.Tensor(erf_default_6, 1);  erf_default_6 = None
        mul_tensor_55 = torch.ops.aten.mul.Tensor(add_tensor_126, 0.5);  add_tensor_126 = None
        mul_tensor_56 = torch.ops.aten.mul.Tensor(to_dtype_19, to_dtype_19)
        mul_tensor_57 = torch.ops.aten.mul.Tensor(mul_tensor_56, -0.5);  mul_tensor_56 = None
        exp_default_6 = torch.ops.aten.exp.default(mul_tensor_57);  mul_tensor_57 = None
        mul_tensor_58 = torch.ops.aten.mul.Tensor(exp_default_6, 0.3989422804014327);  exp_default_6 = None
        mul_tensor_59 = torch.ops.aten.mul.Tensor(to_dtype_19, mul_tensor_58);  to_dtype_19 = mul_tensor_58 = None
        add_tensor_127 = torch.ops.aten.add.Tensor(mul_tensor_55, mul_tensor_59);  mul_tensor_55 = mul_tensor_59 = None
        mul_tensor_60 = torch.ops.aten.mul.Tensor(to_dtype_18, add_tensor_127);  to_dtype_18 = add_tensor_127 = None
        to_dtype_20 = torch.ops.aten.to.dtype(mul_tensor_60, torch.float32);  mul_tensor_60 = None
        view_default_579 = torch.ops.aten.view.default(to_dtype_20, [2048, 3072]);  to_dtype_20 = None
        t_default_220 = torch.ops.aten.t.default(t_default_34);  t_default_34 = None
        mm_default_122 = torch.ops.aten.mm.default(view_default_579, t_default_220);  t_default_220 = None
        t_default_221 = torch.ops.aten.t.default(view_default_579)
        mm_default_123 = torch.ops.aten.mm.default(t_default_221, view_default_164);  t_default_221 = view_default_164 = None
        t_default_222 = torch.ops.aten.t.default(mm_default_123);  mm_default_123 = None
        sum_dim_int_list_37 = torch.ops.aten.sum.dim_IntList(view_default_579, [0], True);  view_default_579 = None
        view_default_580 = torch.ops.aten.view.default(sum_dim_int_list_37, [3072]);  sum_dim_int_list_37 = None
        t_default_223 = torch.ops.aten.t.default(t_default_222);  t_default_222 = None
        view_default_581 = torch.ops.aten.view.default(mm_default_122, [2, 1024, 768]);  mm_default_122 = None
        add_tensor_128 = torch.ops.aten.add.Tensor(getitem_108, view_default_581);  getitem_108 = view_default_581 = None
        native_layer_norm_backward_default_13 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_128, add_tensor_34, [768], getitem_31, getitem_32, primals_114, primals_113, [True, True, True]);  add_tensor_128 = add_tensor_34 = getitem_31 = getitem_32 = primals_114 = primals_113 = None
        getitem_111 = native_layer_norm_backward_default_13[0]
        getitem_112 = native_layer_norm_backward_default_13[1]
        getitem_113 = native_layer_norm_backward_default_13[2];  native_layer_norm_backward_default_13 = None
        sum_dim_int_list_38 = torch.ops.aten.sum.dim_IntList(getitem_111, [0, 1], True)
        view_default_582 = torch.ops.aten.view.default(sum_dim_int_list_38, [768]);  sum_dim_int_list_38 = None
        view_default_583 = torch.ops.aten.view.default(getitem_111, [2048, 768])
        t_default_224 = torch.ops.aten.t.default(view_default_583)
        mm_default_124 = torch.ops.aten.mm.default(t_default_224, _unsafe_view_default_76);  t_default_224 = _unsafe_view_default_76 = None
        t_default_225 = torch.ops.aten.t.default(mm_default_124);  mm_default_124 = None
        t_default_226 = torch.ops.aten.t.default(t_default_33);  t_default_33 = None
        mm_default_125 = torch.ops.aten.mm.default(view_default_583, t_default_226);  view_default_583 = t_default_226 = None
        view_default_584 = torch.ops.aten.view.default(mm_default_125, [2, 1024, 768]);  mm_default_125 = None
        t_default_227 = torch.ops.aten.t.default(t_default_225);  t_default_225 = None
        transpose_int_270 = torch.ops.aten.transpose.int(view_default_584, 0, 1);  view_default_584 = None
        view_default_585 = torch.ops.aten.view.default(transpose_int_270, [1024, 2, 12, 64]);  transpose_int_270 = None
        transpose_int_271 = torch.ops.aten.transpose.int(view_default_585, 0, 1);  view_default_585 = None
        transpose_int_272 = torch.ops.aten.transpose.int(transpose_int_271, 1, 2);  transpose_int_271 = None
        clone_default_186 = torch.ops.aten.clone.default(transpose_int_272, memory_format = torch.contiguous_format);  transpose_int_272 = None
        _unsafe_view_default_192 = torch.ops.aten._unsafe_view.default(clone_default_186, [24, 4, 256, 64]);  clone_default_186 = None
        view_default_586 = torch.ops.aten.view.default(_unsafe_view_default_192, [24, 4, 256, 64, 1]);  _unsafe_view_default_192 = None
        permute_default_204 = torch.ops.aten.permute.default(view_default_586, [0, 1, 2, 4, 3]);  view_default_586 = None
        view_default_587 = torch.ops.aten.view.default(permute_default_204, [96, 256, 64]);  permute_default_204 = None
        transpose_int_273 = torch.ops.aten.transpose.int(view_default_160, 1, 2);  view_default_160 = None
        bmm_default_48 = torch.ops.aten.bmm.default(transpose_int_273, view_default_587);  transpose_int_273 = None
        transpose_int_274 = torch.ops.aten.transpose.int(_unsafe_view_default_74, 1, 2);  _unsafe_view_default_74 = None
        bmm_default_49 = torch.ops.aten.bmm.default(view_default_587, transpose_int_274);  view_default_587 = transpose_int_274 = None
        view_default_588 = torch.ops.aten.view.default(bmm_default_48, [24, 4, 768, 64, 1]);  bmm_default_48 = None
        permute_default_205 = torch.ops.aten.permute.default(view_default_588, [0, 1, 4, 3, 2]);  view_default_588 = None
        view_default_589 = torch.ops.aten.view.default(bmm_default_49, [24, 4, 256, 768, 1]);  bmm_default_49 = None
        permute_default_206 = torch.ops.aten.permute.default(view_default_589, [0, 1, 2, 4, 3]);  view_default_589 = None
        permute_default_207 = torch.ops.aten.permute.default(permute_default_205, [0, 1, 4, 3, 2]);  permute_default_205 = None
        squeeze_dim_48 = torch.ops.aten.squeeze.dim(permute_default_207, -1);  permute_default_207 = None
        permute_default_208 = torch.ops.aten.permute.default(permute_default_206, [0, 1, 2, 4, 3]);  permute_default_206 = None
        squeeze_dim_49 = torch.ops.aten.squeeze.dim(permute_default_208, -1);  permute_default_208 = None
        slice_backward_default_126 = torch.ops.aten.slice_backward.default(squeeze_dim_49, [24, 4, 256, 769], 3, 0, -1, 1);  squeeze_dim_49 = None
        slice_backward_default_127 = torch.ops.aten.slice_backward.default(slice_backward_default_126, [24, 4, 256, 769], 2, 0, 9223372036854775807, 1);  slice_backward_default_126 = None
        slice_backward_default_128 = torch.ops.aten.slice_backward.default(slice_backward_default_127, [24, 4, 256, 769], 1, 0, 9223372036854775807, 1);  slice_backward_default_127 = None
        slice_backward_default_129 = torch.ops.aten.slice_backward.default(slice_backward_default_128, [24, 4, 256, 769], 0, 0, 9223372036854775807, 1);  slice_backward_default_128 = None
        view_default_590 = torch.ops.aten.view.default(slice_backward_default_129, [24, 4, 196864]);  slice_backward_default_129 = None
        slice_backward_default_130 = torch.ops.aten.slice_backward.default(view_default_590, [24, 4, 197120], 2, 0, -256, 1);  view_default_590 = None
        slice_backward_default_131 = torch.ops.aten.slice_backward.default(slice_backward_default_130, [24, 4, 197120], 1, 0, 9223372036854775807, 1);  slice_backward_default_130 = None
        slice_backward_default_132 = torch.ops.aten.slice_backward.default(slice_backward_default_131, [24, 4, 197120], 0, 0, 9223372036854775807, 1);  slice_backward_default_131 = None
        view_default_591 = torch.ops.aten.view.default(slice_backward_default_132, [24, 4, 256, 770]);  slice_backward_default_132 = None
        constant_pad_nd_default_66 = torch.ops.aten.constant_pad_nd.default(view_default_591, [0, -257]);  view_default_591 = None
        new_empty_default_84 = torch.ops.aten.new_empty.default(squeeze_dim_48, [2359296])
        zero__default_42 = torch.ops.aten.zero_.default(new_empty_default_84);  new_empty_default_84 = None
        arange_18 = torch.ops.aten.arange.start(0, 2359296, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_150 = torch.ops.aten.as_strided.default(arange_18, [24, 4, 768, 64], [98304, 16384, 64, 1], 0);  arange_18 = None
        clone_default_187 = torch.ops.aten.clone.default(as_strided_default_150, memory_format = torch.contiguous_format);  as_strided_default_150 = None
        _unsafe_view_default_193 = torch.ops.aten._unsafe_view.default(clone_default_187, [4718592]);  clone_default_187 = None
        view_default_592 = torch.ops.aten.view.default(squeeze_dim_48, [4718592]);  squeeze_dim_48 = None
        index_add__default_18 = torch.ops.aten.index_add_.default(zero__default_42, 0, _unsafe_view_default_193, view_default_592);  zero__default_42 = _unsafe_view_default_193 = view_default_592 = None
        as_strided_default_151 = torch.ops.aten.as_strided.default(index_add__default_18, [24, 1536, 64], [98304, 64, 1], 0);  index_add__default_18 = None
        constant_pad_nd_default_67 = torch.ops.aten.constant_pad_nd.default(as_strided_default_151, [0, 0, -256, -256]);  as_strided_default_151 = None
        view_default_593 = torch.ops.aten.view.default(constant_pad_nd_default_67, [2, 12, 1024, 64]);  constant_pad_nd_default_67 = None
        transpose_int_275 = torch.ops.aten.transpose.int(view_default_593, 1, 2);  view_default_593 = None
        view_default_594 = torch.ops.aten.view.default(constant_pad_nd_default_66, [2, 12, 1024, 513]);  constant_pad_nd_default_66 = None
        transpose_int_276 = torch.ops.aten.transpose.int(view_default_594, 1, 2);  view_default_594 = None
        transpose_int_277 = torch.ops.aten.transpose.int(transpose_int_275, 0, 1);  transpose_int_275 = None
        clone_default_188 = torch.ops.aten.clone.default(transpose_int_277, memory_format = torch.contiguous_format);  transpose_int_277 = None
        _unsafe_view_default_194 = torch.ops.aten._unsafe_view.default(clone_default_188, [1024, 2, 768]);  clone_default_188 = None
        where_scalar_self_42 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_81, 0.0, transpose_int_276);  unsqueeze_default_81 = transpose_int_276 = None
        _softmax_backward_data_default_6 = torch.ops.aten._softmax_backward_data.default(where_scalar_self_42, _softmax_default_5, -1, torch.float32);  where_scalar_self_42 = _softmax_default_5 = None
        new_empty_default_85 = torch.ops.aten.new_empty.default(_softmax_backward_data_default_6, [12607488])
        zero__default_43 = torch.ops.aten.zero_.default(new_empty_default_85);  new_empty_default_85 = None
        as_strided_default_152 = torch.ops.aten.as_strided.default(zero__default_43, [2, 1024, 12, 513], [6303744, 513, 525312, 1], 0)
        copy__default_180 = torch.ops.aten.copy_.default(as_strided_default_152, _softmax_backward_data_default_6);  as_strided_default_152 = _softmax_backward_data_default_6 = None
        as_strided_default_153 = torch.ops.aten.as_strided.default(zero__default_43, [24, 4, 256, 513], [525312, 131328, 513, 1], 0);  zero__default_43 = None
        new_empty_strided_default_42 = torch.ops.aten.new_empty_strided.default(as_strided_default_153, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_181 = torch.ops.aten.copy_.default(new_empty_strided_default_42, as_strided_default_153);  new_empty_strided_default_42 = as_strided_default_153 = None
        as_strided_default_154 = torch.ops.aten.as_strided.default(copy__default_181, [2, 1024, 12, 513], [6303744, 513, 525312, 1], 0)
        clone_default_189 = torch.ops.aten.clone.default(as_strided_default_154, memory_format = torch.contiguous_format)
        copy__default_182 = torch.ops.aten.copy_.default(as_strided_default_154, clone_default_189);  as_strided_default_154 = clone_default_189 = None
        new_empty_strided_default_43 = torch.ops.aten.new_empty_strided.default(copy__default_181, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_183 = torch.ops.aten.copy_.default(new_empty_strided_default_43, copy__default_181);  new_empty_strided_default_43 = copy__default_181 = None
        as_strided_default_155 = torch.ops.aten.as_strided.default(copy__default_183, [2, 256, 12, 257], [6303744, 513, 525312, 1], 394240)
        clone_default_190 = torch.ops.aten.clone.default(as_strided_default_155, memory_format = torch.contiguous_format)
        where_scalar_self_43 = torch.ops.aten.where.ScalarSelf(eq_scalar_21, 0.0, clone_default_190);  eq_scalar_21 = clone_default_190 = None
        copy__default_184 = torch.ops.aten.copy_.default(as_strided_default_155, where_scalar_self_43);  as_strided_default_155 = where_scalar_self_43 = None
        new_empty_strided_default_44 = torch.ops.aten.new_empty_strided.default(copy__default_183, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_185 = torch.ops.aten.copy_.default(new_empty_strided_default_44, copy__default_183);  new_empty_strided_default_44 = copy__default_183 = None
        as_strided_default_156 = torch.ops.aten.as_strided.default(copy__default_185, [2, 256, 12, 257], [6303744, 513, 525312, 1], 0)
        clone_default_191 = torch.ops.aten.clone.default(as_strided_default_156, memory_format = torch.contiguous_format)
        where_scalar_self_44 = torch.ops.aten.where.ScalarSelf(eq_scalar_20, 0.0, clone_default_191);  eq_scalar_20 = clone_default_191 = None
        copy__default_186 = torch.ops.aten.copy_.default(as_strided_default_156, where_scalar_self_44);  as_strided_default_156 = where_scalar_self_44 = None
        new_empty_strided_default_45 = torch.ops.aten.new_empty_strided.default(copy__default_185, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_187 = torch.ops.aten.copy_.default(new_empty_strided_default_45, copy__default_185);  new_empty_strided_default_45 = copy__default_185 = None
        as_strided_default_157 = torch.ops.aten.as_strided.default(copy__default_187, [24, 255, 255], [525312, 513, 1], 514)
        clone_default_192 = torch.ops.aten.clone.default(as_strided_default_157, memory_format = torch.contiguous_format)
        empty_like_default_18 = torch.ops.aten.empty_like.default(clone_default_192, memory_format = torch.contiguous_format)
        zero__default_44 = torch.ops.aten.zero_.default(empty_like_default_18);  empty_like_default_18 = None
        copy__default_188 = torch.ops.aten.copy_.default(as_strided_default_157, zero__default_44);  as_strided_default_157 = zero__default_44 = None
        slice_backward_default_133 = torch.ops.aten.slice_backward.default(clone_default_192, [24, 255, 513], 2, -255, 9223372036854775807, 1);  clone_default_192 = None
        slice_backward_default_134 = torch.ops.aten.slice_backward.default(slice_backward_default_133, [24, 512, 513], 1, 0, 255, 1);  slice_backward_default_133 = None
        select_backward_default_12 = torch.ops.aten.select_backward.default(slice_backward_default_134, [24, 3, 512, 513], 1, 0);  slice_backward_default_134 = None
        slice_backward_default_135 = torch.ops.aten.slice_backward.default(select_backward_default_12, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_12 = None
        new_empty_strided_default_46 = torch.ops.aten.new_empty_strided.default(copy__default_187, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_189 = torch.ops.aten.copy_.default(new_empty_strided_default_46, copy__default_187);  new_empty_strided_default_46 = copy__default_187 = None
        as_strided_default_158 = torch.ops.aten.as_strided.default(copy__default_189, [24, 3, 256, 256], [525312, 131328, 513, 1], 131328)
        clone_default_193 = torch.ops.aten.clone.default(as_strided_default_158, memory_format = torch.contiguous_format)
        empty_like_default_19 = torch.ops.aten.empty_like.default(clone_default_193, memory_format = torch.contiguous_format)
        zero__default_45 = torch.ops.aten.zero_.default(empty_like_default_19);  empty_like_default_19 = None
        copy__default_190 = torch.ops.aten.copy_.default(as_strided_default_158, zero__default_45);  as_strided_default_158 = zero__default_45 = None
        slice_backward_default_136 = torch.ops.aten.slice_backward.default(clone_default_193, [24, 3, 256, 513], 3, 257, 9223372036854775807, 1);  clone_default_193 = None
        slice_backward_default_137 = torch.ops.aten.slice_backward.default(slice_backward_default_136, [24, 3, 512, 513], 2, -257, -1, 1);  slice_backward_default_136 = None
        slice_backward_default_138 = torch.ops.aten.slice_backward.default(slice_backward_default_137, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_137 = None
        slice_backward_default_139 = torch.ops.aten.slice_backward.default(slice_backward_default_138, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_138 = None
        add_tensor_129 = torch.ops.aten.add.Tensor(slice_backward_default_135, slice_backward_default_139);  slice_backward_default_135 = slice_backward_default_139 = None
        new_empty_strided_default_47 = torch.ops.aten.new_empty_strided.default(copy__default_189, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_191 = torch.ops.aten.copy_.default(new_empty_strided_default_47, copy__default_189);  new_empty_strided_default_47 = copy__default_189 = None
        as_strided_default_159 = torch.ops.aten.as_strided.default(copy__default_191, [24, 256, 257], [525312, 513, 1], 394240)
        clone_default_194 = torch.ops.aten.clone.default(as_strided_default_159, memory_format = torch.contiguous_format)
        empty_like_default_20 = torch.ops.aten.empty_like.default(clone_default_194, memory_format = torch.contiguous_format)
        zero__default_46 = torch.ops.aten.zero_.default(empty_like_default_20);  empty_like_default_20 = None
        copy__default_192 = torch.ops.aten.copy_.default(as_strided_default_159, zero__default_46);  as_strided_default_159 = zero__default_46 = None
        slice_backward_default_140 = torch.ops.aten.slice_backward.default(clone_default_194, [24, 256, 513], 2, 0, 257, 1);  clone_default_194 = None
        slice_backward_default_141 = torch.ops.aten.slice_backward.default(slice_backward_default_140, [24, 512, 513], 1, 256, 9223372036854775807, 1);  slice_backward_default_140 = None
        select_backward_default_13 = torch.ops.aten.select_backward.default(slice_backward_default_141, [24, 3, 512, 513], 1, -1);  slice_backward_default_141 = None
        slice_backward_default_142 = torch.ops.aten.slice_backward.default(select_backward_default_13, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_13 = None
        add_tensor_130 = torch.ops.aten.add.Tensor(add_tensor_129, slice_backward_default_142);  add_tensor_129 = slice_backward_default_142 = None
        new_empty_strided_default_48 = torch.ops.aten.new_empty_strided.default(copy__default_191, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_193 = torch.ops.aten.copy_.default(new_empty_strided_default_48, copy__default_191);  new_empty_strided_default_48 = copy__default_191 = None
        as_strided_default_160 = torch.ops.aten.as_strided.default(copy__default_193, [24, 3, 256, 257], [525312, 131328, 513, 1], 256);  copy__default_193 = None
        clone_default_195 = torch.ops.aten.clone.default(as_strided_default_160, memory_format = torch.contiguous_format);  as_strided_default_160 = None
        slice_backward_default_143 = torch.ops.aten.slice_backward.default(clone_default_195, [24, 3, 256, 513], 3, 0, 257, 1);  clone_default_195 = None
        slice_backward_default_144 = torch.ops.aten.slice_backward.default(slice_backward_default_143, [24, 3, 512, 513], 2, 0, 256, 1);  slice_backward_default_143 = None
        slice_backward_default_145 = torch.ops.aten.slice_backward.default(slice_backward_default_144, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_144 = None
        slice_backward_default_146 = torch.ops.aten.slice_backward.default(slice_backward_default_145, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_145 = None
        add_tensor_131 = torch.ops.aten.add.Tensor(add_tensor_130, slice_backward_default_146);  add_tensor_130 = slice_backward_default_146 = None
        view_default_595 = torch.ops.aten.view.default(add_tensor_131, [24, 3, 513, 512]);  add_tensor_131 = None
        constant_pad_nd_default_68 = torch.ops.aten.constant_pad_nd.default(view_default_595, [0, 0, 0, -1]);  view_default_595 = None
        view_default_596 = torch.ops.aten.view.default(constant_pad_nd_default_68, [24, 3, 512, 512, 1]);  constant_pad_nd_default_68 = None
        permute_default_209 = torch.ops.aten.permute.default(view_default_596, [0, 1, 2, 4, 3]);  view_default_596 = None
        view_default_597 = torch.ops.aten.view.default(permute_default_209, [72, 512, 512]);  permute_default_209 = None
        transpose_int_278 = torch.ops.aten.transpose.int(_unsafe_view_default_71, 1, 2);  _unsafe_view_default_71 = None
        bmm_default_50 = torch.ops.aten.bmm.default(transpose_int_278, view_default_597);  transpose_int_278 = None
        transpose_int_279 = torch.ops.aten.transpose.int(_unsafe_view_default_72, 1, 2);  _unsafe_view_default_72 = None
        bmm_default_51 = torch.ops.aten.bmm.default(view_default_597, transpose_int_279);  view_default_597 = transpose_int_279 = None
        view_default_598 = torch.ops.aten.view.default(bmm_default_50, [24, 3, 64, 512, 1]);  bmm_default_50 = None
        permute_default_210 = torch.ops.aten.permute.default(view_default_598, [0, 1, 4, 3, 2]);  view_default_598 = None
        view_default_599 = torch.ops.aten.view.default(bmm_default_51, [24, 3, 512, 64, 1]);  bmm_default_51 = None
        permute_default_211 = torch.ops.aten.permute.default(view_default_599, [0, 1, 2, 4, 3]);  view_default_599 = None
        permute_default_212 = torch.ops.aten.permute.default(permute_default_210, [0, 1, 3, 4, 2]);  permute_default_210 = None
        squeeze_dim_50 = torch.ops.aten.squeeze.dim(permute_default_212, -1);  permute_default_212 = None
        permute_default_213 = torch.ops.aten.permute.default(permute_default_211, [0, 1, 2, 4, 3]);  permute_default_211 = None
        squeeze_dim_51 = torch.ops.aten.squeeze.dim(permute_default_213, -1);  permute_default_213 = None
        new_empty_default_86 = torch.ops.aten.new_empty.default(squeeze_dim_50, [1572864])
        zero__default_47 = torch.ops.aten.zero_.default(new_empty_default_86);  new_empty_default_86 = None
        arange_19 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_161 = torch.ops.aten.as_strided.default(arange_19, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_19 = None
        clone_default_196 = torch.ops.aten.clone.default(as_strided_default_161, memory_format = torch.contiguous_format);  as_strided_default_161 = None
        _unsafe_view_default_195 = torch.ops.aten._unsafe_view.default(clone_default_196, [2359296]);  clone_default_196 = None
        clone_default_197 = torch.ops.aten.clone.default(squeeze_dim_50, memory_format = torch.contiguous_format);  squeeze_dim_50 = None
        _unsafe_view_default_196 = torch.ops.aten._unsafe_view.default(clone_default_197, [2359296]);  clone_default_197 = None
        index_add__default_19 = torch.ops.aten.index_add_.default(zero__default_47, 0, _unsafe_view_default_195, _unsafe_view_default_196);  zero__default_47 = _unsafe_view_default_195 = _unsafe_view_default_196 = None
        as_strided_default_162 = torch.ops.aten.as_strided.default(index_add__default_19, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_19 = None
        view_default_600 = torch.ops.aten.view.default(as_strided_default_162, [24, 1024, 64]);  as_strided_default_162 = None
        new_empty_default_87 = torch.ops.aten.new_empty.default(squeeze_dim_51, [1572864])
        zero__default_48 = torch.ops.aten.zero_.default(new_empty_default_87);  new_empty_default_87 = None
        arange_20 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_163 = torch.ops.aten.as_strided.default(arange_20, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_20 = None
        clone_default_198 = torch.ops.aten.clone.default(as_strided_default_163, memory_format = torch.contiguous_format);  as_strided_default_163 = None
        _unsafe_view_default_197 = torch.ops.aten._unsafe_view.default(clone_default_198, [2359296]);  clone_default_198 = None
        view_default_601 = torch.ops.aten.view.default(squeeze_dim_51, [2359296]);  squeeze_dim_51 = None
        index_add__default_20 = torch.ops.aten.index_add_.default(zero__default_48, 0, _unsafe_view_default_197, view_default_601);  zero__default_48 = _unsafe_view_default_197 = view_default_601 = None
        as_strided_default_164 = torch.ops.aten.as_strided.default(index_add__default_20, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_20 = None
        view_default_602 = torch.ops.aten.view.default(as_strided_default_164, [24, 1024, 64]);  as_strided_default_164 = None
        view_default_603 = torch.ops.aten.view.default(view_default_600, [2, 12, 1024, 64]);  view_default_600 = None
        transpose_int_280 = torch.ops.aten.transpose.int(view_default_603, 1, 2);  view_default_603 = None
        view_default_604 = torch.ops.aten.view.default(view_default_602, [2, 12, 1024, 64]);  view_default_602 = None
        transpose_int_281 = torch.ops.aten.transpose.int(view_default_604, 1, 2);  view_default_604 = None
        transpose_int_282 = torch.ops.aten.transpose.int(transpose_int_280, 0, 1);  transpose_int_280 = None
        view_default_605 = torch.ops.aten.view.default(transpose_int_282, [1024, 2, 768]);  transpose_int_282 = None
        transpose_int_283 = torch.ops.aten.transpose.int(transpose_int_281, 0, 1);  transpose_int_281 = None
        view_default_606 = torch.ops.aten.view.default(transpose_int_283, [1024, 2, 768]);  transpose_int_283 = None
        div_tensor_6 = torch.ops.aten.div.Tensor(view_default_606, 8.0);  view_default_606 = None
        sum_dim_int_list_39 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_194, [0, 1], True)
        view_default_607 = torch.ops.aten.view.default(sum_dim_int_list_39, [768]);  sum_dim_int_list_39 = None
        view_default_608 = torch.ops.aten.view.default(_unsafe_view_default_194, [2048, 768]);  _unsafe_view_default_194 = None
        t_default_228 = torch.ops.aten.t.default(view_default_608)
        mm_default_126 = torch.ops.aten.mm.default(t_default_228, _unsafe_view_default_69);  t_default_228 = _unsafe_view_default_69 = None
        t_default_229 = torch.ops.aten.t.default(mm_default_126);  mm_default_126 = None
        t_default_230 = torch.ops.aten.t.default(t_default_32);  t_default_32 = None
        mm_default_127 = torch.ops.aten.mm.default(view_default_608, t_default_230);  view_default_608 = t_default_230 = None
        view_default_609 = torch.ops.aten.view.default(mm_default_127, [1024, 2, 768]);  mm_default_127 = None
        t_default_231 = torch.ops.aten.t.default(t_default_229);  t_default_229 = None
        sum_dim_int_list_40 = torch.ops.aten.sum.dim_IntList(view_default_605, [0, 1], True)
        view_default_610 = torch.ops.aten.view.default(sum_dim_int_list_40, [768]);  sum_dim_int_list_40 = None
        view_default_611 = torch.ops.aten.view.default(view_default_605, [2048, 768]);  view_default_605 = None
        t_default_232 = torch.ops.aten.t.default(view_default_611)
        mm_default_128 = torch.ops.aten.mm.default(t_default_232, _unsafe_view_default_67);  t_default_232 = _unsafe_view_default_67 = None
        t_default_233 = torch.ops.aten.t.default(mm_default_128);  mm_default_128 = None
        t_default_234 = torch.ops.aten.t.default(t_default_31);  t_default_31 = None
        mm_default_129 = torch.ops.aten.mm.default(view_default_611, t_default_234);  view_default_611 = t_default_234 = None
        view_default_612 = torch.ops.aten.view.default(mm_default_129, [1024, 2, 768]);  mm_default_129 = None
        add_tensor_132 = torch.ops.aten.add.Tensor(view_default_609, view_default_612);  view_default_609 = view_default_612 = None
        t_default_235 = torch.ops.aten.t.default(t_default_233);  t_default_233 = None
        sum_dim_int_list_41 = torch.ops.aten.sum.dim_IntList(div_tensor_6, [0, 1], True)
        view_default_613 = torch.ops.aten.view.default(sum_dim_int_list_41, [768]);  sum_dim_int_list_41 = None
        view_default_614 = torch.ops.aten.view.default(div_tensor_6, [2048, 768]);  div_tensor_6 = None
        t_default_236 = torch.ops.aten.t.default(view_default_614)
        mm_default_130 = torch.ops.aten.mm.default(t_default_236, _unsafe_view_default_65);  t_default_236 = _unsafe_view_default_65 = None
        t_default_237 = torch.ops.aten.t.default(mm_default_130);  mm_default_130 = None
        t_default_238 = torch.ops.aten.t.default(t_default_30);  t_default_30 = None
        mm_default_131 = torch.ops.aten.mm.default(view_default_614, t_default_238);  view_default_614 = t_default_238 = None
        view_default_615 = torch.ops.aten.view.default(mm_default_131, [1024, 2, 768]);  mm_default_131 = None
        add_tensor_133 = torch.ops.aten.add.Tensor(add_tensor_132, view_default_615);  add_tensor_132 = view_default_615 = None
        t_default_239 = torch.ops.aten.t.default(t_default_237);  t_default_237 = None
        transpose_int_284 = torch.ops.aten.transpose.int(add_tensor_133, 0, 1);  add_tensor_133 = None
        add_tensor_134 = torch.ops.aten.add.Tensor(getitem_111, transpose_int_284);  getitem_111 = transpose_int_284 = None
        native_layer_norm_backward_default_14 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_134, add_tensor_29, [768], getitem_28, getitem_29, primals_110, primals_109, [True, True, True]);  add_tensor_134 = add_tensor_29 = getitem_28 = getitem_29 = primals_110 = primals_109 = None
        getitem_114 = native_layer_norm_backward_default_14[0]
        getitem_115 = native_layer_norm_backward_default_14[1]
        getitem_116 = native_layer_norm_backward_default_14[2];  native_layer_norm_backward_default_14 = None
        view_default_616 = torch.ops.aten.view.default(getitem_114, [2048, 768])
        t_default_240 = torch.ops.aten.t.default(t_default_29);  t_default_29 = None
        mm_default_132 = torch.ops.aten.mm.default(view_default_616, t_default_240);  t_default_240 = None
        t_default_241 = torch.ops.aten.t.default(view_default_616)
        mm_default_133 = torch.ops.aten.mm.default(t_default_241, view_default_138);  t_default_241 = view_default_138 = None
        t_default_242 = torch.ops.aten.t.default(mm_default_133);  mm_default_133 = None
        sum_dim_int_list_42 = torch.ops.aten.sum.dim_IntList(view_default_616, [0], True);  view_default_616 = None
        view_default_617 = torch.ops.aten.view.default(sum_dim_int_list_42, [768]);  sum_dim_int_list_42 = None
        t_default_243 = torch.ops.aten.t.default(t_default_242);  t_default_242 = None
        view_default_618 = torch.ops.aten.view.default(mm_default_132, [2, 1024, 3072]);  mm_default_132 = None
        to_dtype_21 = torch.ops.aten.to.dtype(view_default_618, torch.float32);  view_default_618 = None
        to_dtype_22 = torch.ops.aten.to.dtype(view_default_137, torch.float32);  view_default_137 = None
        mul_tensor_61 = torch.ops.aten.mul.Tensor(to_dtype_22, 0.7071067811865476)
        erf_default_7 = torch.ops.aten.erf.default(mul_tensor_61);  mul_tensor_61 = None
        add_tensor_135 = torch.ops.aten.add.Tensor(erf_default_7, 1);  erf_default_7 = None
        mul_tensor_62 = torch.ops.aten.mul.Tensor(add_tensor_135, 0.5);  add_tensor_135 = None
        mul_tensor_63 = torch.ops.aten.mul.Tensor(to_dtype_22, to_dtype_22)
        mul_tensor_64 = torch.ops.aten.mul.Tensor(mul_tensor_63, -0.5);  mul_tensor_63 = None
        exp_default_7 = torch.ops.aten.exp.default(mul_tensor_64);  mul_tensor_64 = None
        mul_tensor_65 = torch.ops.aten.mul.Tensor(exp_default_7, 0.3989422804014327);  exp_default_7 = None
        mul_tensor_66 = torch.ops.aten.mul.Tensor(to_dtype_22, mul_tensor_65);  to_dtype_22 = mul_tensor_65 = None
        add_tensor_136 = torch.ops.aten.add.Tensor(mul_tensor_62, mul_tensor_66);  mul_tensor_62 = mul_tensor_66 = None
        mul_tensor_67 = torch.ops.aten.mul.Tensor(to_dtype_21, add_tensor_136);  to_dtype_21 = add_tensor_136 = None
        to_dtype_23 = torch.ops.aten.to.dtype(mul_tensor_67, torch.float32);  mul_tensor_67 = None
        view_default_619 = torch.ops.aten.view.default(to_dtype_23, [2048, 3072]);  to_dtype_23 = None
        t_default_244 = torch.ops.aten.t.default(t_default_28);  t_default_28 = None
        mm_default_134 = torch.ops.aten.mm.default(view_default_619, t_default_244);  t_default_244 = None
        t_default_245 = torch.ops.aten.t.default(view_default_619)
        mm_default_135 = torch.ops.aten.mm.default(t_default_245, view_default_136);  t_default_245 = view_default_136 = None
        t_default_246 = torch.ops.aten.t.default(mm_default_135);  mm_default_135 = None
        sum_dim_int_list_43 = torch.ops.aten.sum.dim_IntList(view_default_619, [0], True);  view_default_619 = None
        view_default_620 = torch.ops.aten.view.default(sum_dim_int_list_43, [3072]);  sum_dim_int_list_43 = None
        t_default_247 = torch.ops.aten.t.default(t_default_246);  t_default_246 = None
        view_default_621 = torch.ops.aten.view.default(mm_default_134, [2, 1024, 768]);  mm_default_134 = None
        add_tensor_137 = torch.ops.aten.add.Tensor(getitem_114, view_default_621);  getitem_114 = view_default_621 = None
        native_layer_norm_backward_default_15 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_137, add_tensor_28, [768], getitem_25, getitem_26, primals_98, primals_97, [True, True, True]);  add_tensor_137 = add_tensor_28 = getitem_25 = getitem_26 = primals_98 = primals_97 = None
        getitem_117 = native_layer_norm_backward_default_15[0]
        getitem_118 = native_layer_norm_backward_default_15[1]
        getitem_119 = native_layer_norm_backward_default_15[2];  native_layer_norm_backward_default_15 = None
        sum_dim_int_list_44 = torch.ops.aten.sum.dim_IntList(getitem_117, [0, 1], True)
        view_default_622 = torch.ops.aten.view.default(sum_dim_int_list_44, [768]);  sum_dim_int_list_44 = None
        view_default_623 = torch.ops.aten.view.default(getitem_117, [2048, 768])
        t_default_248 = torch.ops.aten.t.default(view_default_623)
        mm_default_136 = torch.ops.aten.mm.default(t_default_248, _unsafe_view_default_63);  t_default_248 = _unsafe_view_default_63 = None
        t_default_249 = torch.ops.aten.t.default(mm_default_136);  mm_default_136 = None
        t_default_250 = torch.ops.aten.t.default(t_default_27);  t_default_27 = None
        mm_default_137 = torch.ops.aten.mm.default(view_default_623, t_default_250);  view_default_623 = t_default_250 = None
        view_default_624 = torch.ops.aten.view.default(mm_default_137, [2, 1024, 768]);  mm_default_137 = None
        t_default_251 = torch.ops.aten.t.default(t_default_249);  t_default_249 = None
        transpose_int_285 = torch.ops.aten.transpose.int(view_default_624, 0, 1);  view_default_624 = None
        view_default_625 = torch.ops.aten.view.default(transpose_int_285, [1024, 2, 12, 64]);  transpose_int_285 = None
        transpose_int_286 = torch.ops.aten.transpose.int(view_default_625, 0, 1);  view_default_625 = None
        transpose_int_287 = torch.ops.aten.transpose.int(transpose_int_286, 1, 2);  transpose_int_286 = None
        clone_default_199 = torch.ops.aten.clone.default(transpose_int_287, memory_format = torch.contiguous_format);  transpose_int_287 = None
        _unsafe_view_default_198 = torch.ops.aten._unsafe_view.default(clone_default_199, [24, 4, 256, 64]);  clone_default_199 = None
        view_default_626 = torch.ops.aten.view.default(_unsafe_view_default_198, [24, 4, 256, 64, 1]);  _unsafe_view_default_198 = None
        permute_default_214 = torch.ops.aten.permute.default(view_default_626, [0, 1, 2, 4, 3]);  view_default_626 = None
        view_default_627 = torch.ops.aten.view.default(permute_default_214, [96, 256, 64]);  permute_default_214 = None
        transpose_int_288 = torch.ops.aten.transpose.int(view_default_132, 1, 2);  view_default_132 = None
        bmm_default_52 = torch.ops.aten.bmm.default(transpose_int_288, view_default_627);  transpose_int_288 = None
        transpose_int_289 = torch.ops.aten.transpose.int(_unsafe_view_default_61, 1, 2);  _unsafe_view_default_61 = None
        bmm_default_53 = torch.ops.aten.bmm.default(view_default_627, transpose_int_289);  view_default_627 = transpose_int_289 = None
        view_default_628 = torch.ops.aten.view.default(bmm_default_52, [24, 4, 768, 64, 1]);  bmm_default_52 = None
        permute_default_215 = torch.ops.aten.permute.default(view_default_628, [0, 1, 4, 3, 2]);  view_default_628 = None
        view_default_629 = torch.ops.aten.view.default(bmm_default_53, [24, 4, 256, 768, 1]);  bmm_default_53 = None
        permute_default_216 = torch.ops.aten.permute.default(view_default_629, [0, 1, 2, 4, 3]);  view_default_629 = None
        permute_default_217 = torch.ops.aten.permute.default(permute_default_215, [0, 1, 4, 3, 2]);  permute_default_215 = None
        squeeze_dim_52 = torch.ops.aten.squeeze.dim(permute_default_217, -1);  permute_default_217 = None
        permute_default_218 = torch.ops.aten.permute.default(permute_default_216, [0, 1, 2, 4, 3]);  permute_default_216 = None
        squeeze_dim_53 = torch.ops.aten.squeeze.dim(permute_default_218, -1);  permute_default_218 = None
        slice_backward_default_147 = torch.ops.aten.slice_backward.default(squeeze_dim_53, [24, 4, 256, 769], 3, 0, -1, 1);  squeeze_dim_53 = None
        slice_backward_default_148 = torch.ops.aten.slice_backward.default(slice_backward_default_147, [24, 4, 256, 769], 2, 0, 9223372036854775807, 1);  slice_backward_default_147 = None
        slice_backward_default_149 = torch.ops.aten.slice_backward.default(slice_backward_default_148, [24, 4, 256, 769], 1, 0, 9223372036854775807, 1);  slice_backward_default_148 = None
        slice_backward_default_150 = torch.ops.aten.slice_backward.default(slice_backward_default_149, [24, 4, 256, 769], 0, 0, 9223372036854775807, 1);  slice_backward_default_149 = None
        view_default_630 = torch.ops.aten.view.default(slice_backward_default_150, [24, 4, 196864]);  slice_backward_default_150 = None
        slice_backward_default_151 = torch.ops.aten.slice_backward.default(view_default_630, [24, 4, 197120], 2, 0, -256, 1);  view_default_630 = None
        slice_backward_default_152 = torch.ops.aten.slice_backward.default(slice_backward_default_151, [24, 4, 197120], 1, 0, 9223372036854775807, 1);  slice_backward_default_151 = None
        slice_backward_default_153 = torch.ops.aten.slice_backward.default(slice_backward_default_152, [24, 4, 197120], 0, 0, 9223372036854775807, 1);  slice_backward_default_152 = None
        view_default_631 = torch.ops.aten.view.default(slice_backward_default_153, [24, 4, 256, 770]);  slice_backward_default_153 = None
        constant_pad_nd_default_69 = torch.ops.aten.constant_pad_nd.default(view_default_631, [0, -257]);  view_default_631 = None
        new_empty_default_88 = torch.ops.aten.new_empty.default(squeeze_dim_52, [2359296])
        zero__default_49 = torch.ops.aten.zero_.default(new_empty_default_88);  new_empty_default_88 = None
        arange_21 = torch.ops.aten.arange.start(0, 2359296, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_165 = torch.ops.aten.as_strided.default(arange_21, [24, 4, 768, 64], [98304, 16384, 64, 1], 0);  arange_21 = None
        clone_default_200 = torch.ops.aten.clone.default(as_strided_default_165, memory_format = torch.contiguous_format);  as_strided_default_165 = None
        _unsafe_view_default_199 = torch.ops.aten._unsafe_view.default(clone_default_200, [4718592]);  clone_default_200 = None
        view_default_632 = torch.ops.aten.view.default(squeeze_dim_52, [4718592]);  squeeze_dim_52 = None
        index_add__default_21 = torch.ops.aten.index_add_.default(zero__default_49, 0, _unsafe_view_default_199, view_default_632);  zero__default_49 = _unsafe_view_default_199 = view_default_632 = None
        as_strided_default_166 = torch.ops.aten.as_strided.default(index_add__default_21, [24, 1536, 64], [98304, 64, 1], 0);  index_add__default_21 = None
        constant_pad_nd_default_70 = torch.ops.aten.constant_pad_nd.default(as_strided_default_166, [0, 0, -256, -256]);  as_strided_default_166 = None
        view_default_633 = torch.ops.aten.view.default(constant_pad_nd_default_70, [2, 12, 1024, 64]);  constant_pad_nd_default_70 = None
        transpose_int_290 = torch.ops.aten.transpose.int(view_default_633, 1, 2);  view_default_633 = None
        view_default_634 = torch.ops.aten.view.default(constant_pad_nd_default_69, [2, 12, 1024, 513]);  constant_pad_nd_default_69 = None
        transpose_int_291 = torch.ops.aten.transpose.int(view_default_634, 1, 2);  view_default_634 = None
        transpose_int_292 = torch.ops.aten.transpose.int(transpose_int_290, 0, 1);  transpose_int_290 = None
        clone_default_201 = torch.ops.aten.clone.default(transpose_int_292, memory_format = torch.contiguous_format);  transpose_int_292 = None
        _unsafe_view_default_200 = torch.ops.aten._unsafe_view.default(clone_default_201, [1024, 2, 768]);  clone_default_201 = None
        where_scalar_self_45 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_67, 0.0, transpose_int_291);  unsqueeze_default_67 = transpose_int_291 = None
        _softmax_backward_data_default_7 = torch.ops.aten._softmax_backward_data.default(where_scalar_self_45, _softmax_default_4, -1, torch.float32);  where_scalar_self_45 = _softmax_default_4 = None
        new_empty_default_89 = torch.ops.aten.new_empty.default(_softmax_backward_data_default_7, [12607488])
        zero__default_50 = torch.ops.aten.zero_.default(new_empty_default_89);  new_empty_default_89 = None
        as_strided_default_167 = torch.ops.aten.as_strided.default(zero__default_50, [2, 1024, 12, 513], [6303744, 513, 525312, 1], 0)
        copy__default_194 = torch.ops.aten.copy_.default(as_strided_default_167, _softmax_backward_data_default_7);  as_strided_default_167 = _softmax_backward_data_default_7 = None
        as_strided_default_168 = torch.ops.aten.as_strided.default(zero__default_50, [24, 4, 256, 513], [525312, 131328, 513, 1], 0);  zero__default_50 = None
        new_empty_strided_default_49 = torch.ops.aten.new_empty_strided.default(as_strided_default_168, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_195 = torch.ops.aten.copy_.default(new_empty_strided_default_49, as_strided_default_168);  new_empty_strided_default_49 = as_strided_default_168 = None
        as_strided_default_169 = torch.ops.aten.as_strided.default(copy__default_195, [2, 1024, 12, 513], [6303744, 513, 525312, 1], 0)
        clone_default_202 = torch.ops.aten.clone.default(as_strided_default_169, memory_format = torch.contiguous_format)
        copy__default_196 = torch.ops.aten.copy_.default(as_strided_default_169, clone_default_202);  as_strided_default_169 = clone_default_202 = None
        new_empty_strided_default_50 = torch.ops.aten.new_empty_strided.default(copy__default_195, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_197 = torch.ops.aten.copy_.default(new_empty_strided_default_50, copy__default_195);  new_empty_strided_default_50 = copy__default_195 = None
        as_strided_default_170 = torch.ops.aten.as_strided.default(copy__default_197, [2, 256, 12, 257], [6303744, 513, 525312, 1], 394240)
        clone_default_203 = torch.ops.aten.clone.default(as_strided_default_170, memory_format = torch.contiguous_format)
        where_scalar_self_46 = torch.ops.aten.where.ScalarSelf(eq_scalar_17, 0.0, clone_default_203);  eq_scalar_17 = clone_default_203 = None
        copy__default_198 = torch.ops.aten.copy_.default(as_strided_default_170, where_scalar_self_46);  as_strided_default_170 = where_scalar_self_46 = None
        new_empty_strided_default_51 = torch.ops.aten.new_empty_strided.default(copy__default_197, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_199 = torch.ops.aten.copy_.default(new_empty_strided_default_51, copy__default_197);  new_empty_strided_default_51 = copy__default_197 = None
        as_strided_default_171 = torch.ops.aten.as_strided.default(copy__default_199, [2, 256, 12, 257], [6303744, 513, 525312, 1], 0)
        clone_default_204 = torch.ops.aten.clone.default(as_strided_default_171, memory_format = torch.contiguous_format)
        where_scalar_self_47 = torch.ops.aten.where.ScalarSelf(eq_scalar_16, 0.0, clone_default_204);  eq_scalar_16 = clone_default_204 = None
        copy__default_200 = torch.ops.aten.copy_.default(as_strided_default_171, where_scalar_self_47);  as_strided_default_171 = where_scalar_self_47 = None
        new_empty_strided_default_52 = torch.ops.aten.new_empty_strided.default(copy__default_199, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_201 = torch.ops.aten.copy_.default(new_empty_strided_default_52, copy__default_199);  new_empty_strided_default_52 = copy__default_199 = None
        as_strided_default_172 = torch.ops.aten.as_strided.default(copy__default_201, [24, 255, 255], [525312, 513, 1], 514)
        clone_default_205 = torch.ops.aten.clone.default(as_strided_default_172, memory_format = torch.contiguous_format)
        empty_like_default_21 = torch.ops.aten.empty_like.default(clone_default_205, memory_format = torch.contiguous_format)
        zero__default_51 = torch.ops.aten.zero_.default(empty_like_default_21);  empty_like_default_21 = None
        copy__default_202 = torch.ops.aten.copy_.default(as_strided_default_172, zero__default_51);  as_strided_default_172 = zero__default_51 = None
        slice_backward_default_154 = torch.ops.aten.slice_backward.default(clone_default_205, [24, 255, 513], 2, -255, 9223372036854775807, 1);  clone_default_205 = None
        slice_backward_default_155 = torch.ops.aten.slice_backward.default(slice_backward_default_154, [24, 512, 513], 1, 0, 255, 1);  slice_backward_default_154 = None
        select_backward_default_14 = torch.ops.aten.select_backward.default(slice_backward_default_155, [24, 3, 512, 513], 1, 0);  slice_backward_default_155 = None
        slice_backward_default_156 = torch.ops.aten.slice_backward.default(select_backward_default_14, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_14 = None
        new_empty_strided_default_53 = torch.ops.aten.new_empty_strided.default(copy__default_201, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_203 = torch.ops.aten.copy_.default(new_empty_strided_default_53, copy__default_201);  new_empty_strided_default_53 = copy__default_201 = None
        as_strided_default_173 = torch.ops.aten.as_strided.default(copy__default_203, [24, 3, 256, 256], [525312, 131328, 513, 1], 131328)
        clone_default_206 = torch.ops.aten.clone.default(as_strided_default_173, memory_format = torch.contiguous_format)
        empty_like_default_22 = torch.ops.aten.empty_like.default(clone_default_206, memory_format = torch.contiguous_format)
        zero__default_52 = torch.ops.aten.zero_.default(empty_like_default_22);  empty_like_default_22 = None
        copy__default_204 = torch.ops.aten.copy_.default(as_strided_default_173, zero__default_52);  as_strided_default_173 = zero__default_52 = None
        slice_backward_default_157 = torch.ops.aten.slice_backward.default(clone_default_206, [24, 3, 256, 513], 3, 257, 9223372036854775807, 1);  clone_default_206 = None
        slice_backward_default_158 = torch.ops.aten.slice_backward.default(slice_backward_default_157, [24, 3, 512, 513], 2, -257, -1, 1);  slice_backward_default_157 = None
        slice_backward_default_159 = torch.ops.aten.slice_backward.default(slice_backward_default_158, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_158 = None
        slice_backward_default_160 = torch.ops.aten.slice_backward.default(slice_backward_default_159, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_159 = None
        add_tensor_138 = torch.ops.aten.add.Tensor(slice_backward_default_156, slice_backward_default_160);  slice_backward_default_156 = slice_backward_default_160 = None
        new_empty_strided_default_54 = torch.ops.aten.new_empty_strided.default(copy__default_203, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_205 = torch.ops.aten.copy_.default(new_empty_strided_default_54, copy__default_203);  new_empty_strided_default_54 = copy__default_203 = None
        as_strided_default_174 = torch.ops.aten.as_strided.default(copy__default_205, [24, 256, 257], [525312, 513, 1], 394240)
        clone_default_207 = torch.ops.aten.clone.default(as_strided_default_174, memory_format = torch.contiguous_format)
        empty_like_default_23 = torch.ops.aten.empty_like.default(clone_default_207, memory_format = torch.contiguous_format)
        zero__default_53 = torch.ops.aten.zero_.default(empty_like_default_23);  empty_like_default_23 = None
        copy__default_206 = torch.ops.aten.copy_.default(as_strided_default_174, zero__default_53);  as_strided_default_174 = zero__default_53 = None
        slice_backward_default_161 = torch.ops.aten.slice_backward.default(clone_default_207, [24, 256, 513], 2, 0, 257, 1);  clone_default_207 = None
        slice_backward_default_162 = torch.ops.aten.slice_backward.default(slice_backward_default_161, [24, 512, 513], 1, 256, 9223372036854775807, 1);  slice_backward_default_161 = None
        select_backward_default_15 = torch.ops.aten.select_backward.default(slice_backward_default_162, [24, 3, 512, 513], 1, -1);  slice_backward_default_162 = None
        slice_backward_default_163 = torch.ops.aten.slice_backward.default(select_backward_default_15, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_15 = None
        add_tensor_139 = torch.ops.aten.add.Tensor(add_tensor_138, slice_backward_default_163);  add_tensor_138 = slice_backward_default_163 = None
        new_empty_strided_default_55 = torch.ops.aten.new_empty_strided.default(copy__default_205, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_207 = torch.ops.aten.copy_.default(new_empty_strided_default_55, copy__default_205);  new_empty_strided_default_55 = copy__default_205 = None
        as_strided_default_175 = torch.ops.aten.as_strided.default(copy__default_207, [24, 3, 256, 257], [525312, 131328, 513, 1], 256);  copy__default_207 = None
        clone_default_208 = torch.ops.aten.clone.default(as_strided_default_175, memory_format = torch.contiguous_format);  as_strided_default_175 = None
        slice_backward_default_164 = torch.ops.aten.slice_backward.default(clone_default_208, [24, 3, 256, 513], 3, 0, 257, 1);  clone_default_208 = None
        slice_backward_default_165 = torch.ops.aten.slice_backward.default(slice_backward_default_164, [24, 3, 512, 513], 2, 0, 256, 1);  slice_backward_default_164 = None
        slice_backward_default_166 = torch.ops.aten.slice_backward.default(slice_backward_default_165, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_165 = None
        slice_backward_default_167 = torch.ops.aten.slice_backward.default(slice_backward_default_166, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_166 = None
        add_tensor_140 = torch.ops.aten.add.Tensor(add_tensor_139, slice_backward_default_167);  add_tensor_139 = slice_backward_default_167 = None
        view_default_635 = torch.ops.aten.view.default(add_tensor_140, [24, 3, 513, 512]);  add_tensor_140 = None
        constant_pad_nd_default_71 = torch.ops.aten.constant_pad_nd.default(view_default_635, [0, 0, 0, -1]);  view_default_635 = None
        view_default_636 = torch.ops.aten.view.default(constant_pad_nd_default_71, [24, 3, 512, 512, 1]);  constant_pad_nd_default_71 = None
        permute_default_219 = torch.ops.aten.permute.default(view_default_636, [0, 1, 2, 4, 3]);  view_default_636 = None
        view_default_637 = torch.ops.aten.view.default(permute_default_219, [72, 512, 512]);  permute_default_219 = None
        transpose_int_293 = torch.ops.aten.transpose.int(_unsafe_view_default_58, 1, 2);  _unsafe_view_default_58 = None
        bmm_default_54 = torch.ops.aten.bmm.default(transpose_int_293, view_default_637);  transpose_int_293 = None
        transpose_int_294 = torch.ops.aten.transpose.int(_unsafe_view_default_59, 1, 2);  _unsafe_view_default_59 = None
        bmm_default_55 = torch.ops.aten.bmm.default(view_default_637, transpose_int_294);  view_default_637 = transpose_int_294 = None
        view_default_638 = torch.ops.aten.view.default(bmm_default_54, [24, 3, 64, 512, 1]);  bmm_default_54 = None
        permute_default_220 = torch.ops.aten.permute.default(view_default_638, [0, 1, 4, 3, 2]);  view_default_638 = None
        view_default_639 = torch.ops.aten.view.default(bmm_default_55, [24, 3, 512, 64, 1]);  bmm_default_55 = None
        permute_default_221 = torch.ops.aten.permute.default(view_default_639, [0, 1, 2, 4, 3]);  view_default_639 = None
        permute_default_222 = torch.ops.aten.permute.default(permute_default_220, [0, 1, 3, 4, 2]);  permute_default_220 = None
        squeeze_dim_54 = torch.ops.aten.squeeze.dim(permute_default_222, -1);  permute_default_222 = None
        permute_default_223 = torch.ops.aten.permute.default(permute_default_221, [0, 1, 2, 4, 3]);  permute_default_221 = None
        squeeze_dim_55 = torch.ops.aten.squeeze.dim(permute_default_223, -1);  permute_default_223 = None
        new_empty_default_90 = torch.ops.aten.new_empty.default(squeeze_dim_54, [1572864])
        zero__default_54 = torch.ops.aten.zero_.default(new_empty_default_90);  new_empty_default_90 = None
        arange_22 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_176 = torch.ops.aten.as_strided.default(arange_22, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_22 = None
        clone_default_209 = torch.ops.aten.clone.default(as_strided_default_176, memory_format = torch.contiguous_format);  as_strided_default_176 = None
        _unsafe_view_default_201 = torch.ops.aten._unsafe_view.default(clone_default_209, [2359296]);  clone_default_209 = None
        clone_default_210 = torch.ops.aten.clone.default(squeeze_dim_54, memory_format = torch.contiguous_format);  squeeze_dim_54 = None
        _unsafe_view_default_202 = torch.ops.aten._unsafe_view.default(clone_default_210, [2359296]);  clone_default_210 = None
        index_add__default_22 = torch.ops.aten.index_add_.default(zero__default_54, 0, _unsafe_view_default_201, _unsafe_view_default_202);  zero__default_54 = _unsafe_view_default_201 = _unsafe_view_default_202 = None
        as_strided_default_177 = torch.ops.aten.as_strided.default(index_add__default_22, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_22 = None
        view_default_640 = torch.ops.aten.view.default(as_strided_default_177, [24, 1024, 64]);  as_strided_default_177 = None
        new_empty_default_91 = torch.ops.aten.new_empty.default(squeeze_dim_55, [1572864])
        zero__default_55 = torch.ops.aten.zero_.default(new_empty_default_91);  new_empty_default_91 = None
        arange_23 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_178 = torch.ops.aten.as_strided.default(arange_23, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_23 = None
        clone_default_211 = torch.ops.aten.clone.default(as_strided_default_178, memory_format = torch.contiguous_format);  as_strided_default_178 = None
        _unsafe_view_default_203 = torch.ops.aten._unsafe_view.default(clone_default_211, [2359296]);  clone_default_211 = None
        view_default_641 = torch.ops.aten.view.default(squeeze_dim_55, [2359296]);  squeeze_dim_55 = None
        index_add__default_23 = torch.ops.aten.index_add_.default(zero__default_55, 0, _unsafe_view_default_203, view_default_641);  zero__default_55 = _unsafe_view_default_203 = view_default_641 = None
        as_strided_default_179 = torch.ops.aten.as_strided.default(index_add__default_23, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_23 = None
        view_default_642 = torch.ops.aten.view.default(as_strided_default_179, [24, 1024, 64]);  as_strided_default_179 = None
        view_default_643 = torch.ops.aten.view.default(view_default_640, [2, 12, 1024, 64]);  view_default_640 = None
        transpose_int_295 = torch.ops.aten.transpose.int(view_default_643, 1, 2);  view_default_643 = None
        view_default_644 = torch.ops.aten.view.default(view_default_642, [2, 12, 1024, 64]);  view_default_642 = None
        transpose_int_296 = torch.ops.aten.transpose.int(view_default_644, 1, 2);  view_default_644 = None
        transpose_int_297 = torch.ops.aten.transpose.int(transpose_int_295, 0, 1);  transpose_int_295 = None
        view_default_645 = torch.ops.aten.view.default(transpose_int_297, [1024, 2, 768]);  transpose_int_297 = None
        transpose_int_298 = torch.ops.aten.transpose.int(transpose_int_296, 0, 1);  transpose_int_296 = None
        view_default_646 = torch.ops.aten.view.default(transpose_int_298, [1024, 2, 768]);  transpose_int_298 = None
        div_tensor_7 = torch.ops.aten.div.Tensor(view_default_646, 8.0);  view_default_646 = None
        sum_dim_int_list_45 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_200, [0, 1], True)
        view_default_647 = torch.ops.aten.view.default(sum_dim_int_list_45, [768]);  sum_dim_int_list_45 = None
        view_default_648 = torch.ops.aten.view.default(_unsafe_view_default_200, [2048, 768]);  _unsafe_view_default_200 = None
        t_default_252 = torch.ops.aten.t.default(view_default_648)
        mm_default_138 = torch.ops.aten.mm.default(t_default_252, _unsafe_view_default_56);  t_default_252 = _unsafe_view_default_56 = None
        t_default_253 = torch.ops.aten.t.default(mm_default_138);  mm_default_138 = None
        t_default_254 = torch.ops.aten.t.default(t_default_26);  t_default_26 = None
        mm_default_139 = torch.ops.aten.mm.default(view_default_648, t_default_254);  view_default_648 = t_default_254 = None
        view_default_649 = torch.ops.aten.view.default(mm_default_139, [1024, 2, 768]);  mm_default_139 = None
        t_default_255 = torch.ops.aten.t.default(t_default_253);  t_default_253 = None
        sum_dim_int_list_46 = torch.ops.aten.sum.dim_IntList(view_default_645, [0, 1], True)
        view_default_650 = torch.ops.aten.view.default(sum_dim_int_list_46, [768]);  sum_dim_int_list_46 = None
        view_default_651 = torch.ops.aten.view.default(view_default_645, [2048, 768]);  view_default_645 = None
        t_default_256 = torch.ops.aten.t.default(view_default_651)
        mm_default_140 = torch.ops.aten.mm.default(t_default_256, _unsafe_view_default_54);  t_default_256 = _unsafe_view_default_54 = None
        t_default_257 = torch.ops.aten.t.default(mm_default_140);  mm_default_140 = None
        t_default_258 = torch.ops.aten.t.default(t_default_25);  t_default_25 = None
        mm_default_141 = torch.ops.aten.mm.default(view_default_651, t_default_258);  view_default_651 = t_default_258 = None
        view_default_652 = torch.ops.aten.view.default(mm_default_141, [1024, 2, 768]);  mm_default_141 = None
        add_tensor_141 = torch.ops.aten.add.Tensor(view_default_649, view_default_652);  view_default_649 = view_default_652 = None
        t_default_259 = torch.ops.aten.t.default(t_default_257);  t_default_257 = None
        sum_dim_int_list_47 = torch.ops.aten.sum.dim_IntList(div_tensor_7, [0, 1], True)
        view_default_653 = torch.ops.aten.view.default(sum_dim_int_list_47, [768]);  sum_dim_int_list_47 = None
        view_default_654 = torch.ops.aten.view.default(div_tensor_7, [2048, 768]);  div_tensor_7 = None
        t_default_260 = torch.ops.aten.t.default(view_default_654)
        mm_default_142 = torch.ops.aten.mm.default(t_default_260, _unsafe_view_default_52);  t_default_260 = _unsafe_view_default_52 = None
        t_default_261 = torch.ops.aten.t.default(mm_default_142);  mm_default_142 = None
        t_default_262 = torch.ops.aten.t.default(t_default_24);  t_default_24 = None
        mm_default_143 = torch.ops.aten.mm.default(view_default_654, t_default_262);  view_default_654 = t_default_262 = None
        view_default_655 = torch.ops.aten.view.default(mm_default_143, [1024, 2, 768]);  mm_default_143 = None
        add_tensor_142 = torch.ops.aten.add.Tensor(add_tensor_141, view_default_655);  add_tensor_141 = view_default_655 = None
        t_default_263 = torch.ops.aten.t.default(t_default_261);  t_default_261 = None
        transpose_int_299 = torch.ops.aten.transpose.int(add_tensor_142, 0, 1);  add_tensor_142 = None
        add_tensor_143 = torch.ops.aten.add.Tensor(getitem_117, transpose_int_299);  getitem_117 = transpose_int_299 = None
        native_layer_norm_backward_default_16 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_143, add_tensor_23, [768], getitem_22, getitem_23, primals_94, primals_93, [True, True, True]);  add_tensor_143 = add_tensor_23 = getitem_22 = getitem_23 = primals_94 = primals_93 = None
        getitem_120 = native_layer_norm_backward_default_16[0]
        getitem_121 = native_layer_norm_backward_default_16[1]
        getitem_122 = native_layer_norm_backward_default_16[2];  native_layer_norm_backward_default_16 = None
        view_default_656 = torch.ops.aten.view.default(getitem_120, [2048, 768])
        t_default_264 = torch.ops.aten.t.default(t_default_23);  t_default_23 = None
        mm_default_144 = torch.ops.aten.mm.default(view_default_656, t_default_264);  t_default_264 = None
        t_default_265 = torch.ops.aten.t.default(view_default_656)
        mm_default_145 = torch.ops.aten.mm.default(t_default_265, view_default_110);  t_default_265 = view_default_110 = None
        t_default_266 = torch.ops.aten.t.default(mm_default_145);  mm_default_145 = None
        sum_dim_int_list_48 = torch.ops.aten.sum.dim_IntList(view_default_656, [0], True);  view_default_656 = None
        view_default_657 = torch.ops.aten.view.default(sum_dim_int_list_48, [768]);  sum_dim_int_list_48 = None
        t_default_267 = torch.ops.aten.t.default(t_default_266);  t_default_266 = None
        view_default_658 = torch.ops.aten.view.default(mm_default_144, [2, 1024, 3072]);  mm_default_144 = None
        to_dtype_24 = torch.ops.aten.to.dtype(view_default_658, torch.float32);  view_default_658 = None
        to_dtype_25 = torch.ops.aten.to.dtype(view_default_109, torch.float32);  view_default_109 = None
        mul_tensor_68 = torch.ops.aten.mul.Tensor(to_dtype_25, 0.7071067811865476)
        erf_default_8 = torch.ops.aten.erf.default(mul_tensor_68);  mul_tensor_68 = None
        add_tensor_144 = torch.ops.aten.add.Tensor(erf_default_8, 1);  erf_default_8 = None
        mul_tensor_69 = torch.ops.aten.mul.Tensor(add_tensor_144, 0.5);  add_tensor_144 = None
        mul_tensor_70 = torch.ops.aten.mul.Tensor(to_dtype_25, to_dtype_25)
        mul_tensor_71 = torch.ops.aten.mul.Tensor(mul_tensor_70, -0.5);  mul_tensor_70 = None
        exp_default_8 = torch.ops.aten.exp.default(mul_tensor_71);  mul_tensor_71 = None
        mul_tensor_72 = torch.ops.aten.mul.Tensor(exp_default_8, 0.3989422804014327);  exp_default_8 = None
        mul_tensor_73 = torch.ops.aten.mul.Tensor(to_dtype_25, mul_tensor_72);  to_dtype_25 = mul_tensor_72 = None
        add_tensor_145 = torch.ops.aten.add.Tensor(mul_tensor_69, mul_tensor_73);  mul_tensor_69 = mul_tensor_73 = None
        mul_tensor_74 = torch.ops.aten.mul.Tensor(to_dtype_24, add_tensor_145);  to_dtype_24 = add_tensor_145 = None
        to_dtype_26 = torch.ops.aten.to.dtype(mul_tensor_74, torch.float32);  mul_tensor_74 = None
        view_default_659 = torch.ops.aten.view.default(to_dtype_26, [2048, 3072]);  to_dtype_26 = None
        t_default_268 = torch.ops.aten.t.default(t_default_22);  t_default_22 = None
        mm_default_146 = torch.ops.aten.mm.default(view_default_659, t_default_268);  t_default_268 = None
        t_default_269 = torch.ops.aten.t.default(view_default_659)
        mm_default_147 = torch.ops.aten.mm.default(t_default_269, view_default_108);  t_default_269 = view_default_108 = None
        t_default_270 = torch.ops.aten.t.default(mm_default_147);  mm_default_147 = None
        sum_dim_int_list_49 = torch.ops.aten.sum.dim_IntList(view_default_659, [0], True);  view_default_659 = None
        view_default_660 = torch.ops.aten.view.default(sum_dim_int_list_49, [3072]);  sum_dim_int_list_49 = None
        t_default_271 = torch.ops.aten.t.default(t_default_270);  t_default_270 = None
        view_default_661 = torch.ops.aten.view.default(mm_default_146, [2, 1024, 768]);  mm_default_146 = None
        add_tensor_146 = torch.ops.aten.add.Tensor(getitem_120, view_default_661);  getitem_120 = view_default_661 = None
        native_layer_norm_backward_default_17 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_146, add_tensor_22, [768], getitem_19, getitem_20, primals_82, primals_81, [True, True, True]);  add_tensor_146 = add_tensor_22 = getitem_19 = getitem_20 = primals_82 = primals_81 = None
        getitem_123 = native_layer_norm_backward_default_17[0]
        getitem_124 = native_layer_norm_backward_default_17[1]
        getitem_125 = native_layer_norm_backward_default_17[2];  native_layer_norm_backward_default_17 = None
        sum_dim_int_list_50 = torch.ops.aten.sum.dim_IntList(getitem_123, [0, 1], True)
        view_default_662 = torch.ops.aten.view.default(sum_dim_int_list_50, [768]);  sum_dim_int_list_50 = None
        view_default_663 = torch.ops.aten.view.default(getitem_123, [2048, 768])
        t_default_272 = torch.ops.aten.t.default(view_default_663)
        mm_default_148 = torch.ops.aten.mm.default(t_default_272, _unsafe_view_default_50);  t_default_272 = _unsafe_view_default_50 = None
        t_default_273 = torch.ops.aten.t.default(mm_default_148);  mm_default_148 = None
        t_default_274 = torch.ops.aten.t.default(t_default_21);  t_default_21 = None
        mm_default_149 = torch.ops.aten.mm.default(view_default_663, t_default_274);  view_default_663 = t_default_274 = None
        view_default_664 = torch.ops.aten.view.default(mm_default_149, [2, 1024, 768]);  mm_default_149 = None
        t_default_275 = torch.ops.aten.t.default(t_default_273);  t_default_273 = None
        transpose_int_300 = torch.ops.aten.transpose.int(view_default_664, 0, 1);  view_default_664 = None
        view_default_665 = torch.ops.aten.view.default(transpose_int_300, [1024, 2, 12, 64]);  transpose_int_300 = None
        transpose_int_301 = torch.ops.aten.transpose.int(view_default_665, 0, 1);  view_default_665 = None
        transpose_int_302 = torch.ops.aten.transpose.int(transpose_int_301, 1, 2);  transpose_int_301 = None
        clone_default_212 = torch.ops.aten.clone.default(transpose_int_302, memory_format = torch.contiguous_format);  transpose_int_302 = None
        _unsafe_view_default_204 = torch.ops.aten._unsafe_view.default(clone_default_212, [24, 4, 256, 64]);  clone_default_212 = None
        view_default_666 = torch.ops.aten.view.default(_unsafe_view_default_204, [24, 4, 256, 64, 1]);  _unsafe_view_default_204 = None
        permute_default_224 = torch.ops.aten.permute.default(view_default_666, [0, 1, 2, 4, 3]);  view_default_666 = None
        view_default_667 = torch.ops.aten.view.default(permute_default_224, [96, 256, 64]);  permute_default_224 = None
        transpose_int_303 = torch.ops.aten.transpose.int(view_default_104, 1, 2);  view_default_104 = None
        bmm_default_56 = torch.ops.aten.bmm.default(transpose_int_303, view_default_667);  transpose_int_303 = None
        transpose_int_304 = torch.ops.aten.transpose.int(_unsafe_view_default_48, 1, 2);  _unsafe_view_default_48 = None
        bmm_default_57 = torch.ops.aten.bmm.default(view_default_667, transpose_int_304);  view_default_667 = transpose_int_304 = None
        view_default_668 = torch.ops.aten.view.default(bmm_default_56, [24, 4, 768, 64, 1]);  bmm_default_56 = None
        permute_default_225 = torch.ops.aten.permute.default(view_default_668, [0, 1, 4, 3, 2]);  view_default_668 = None
        view_default_669 = torch.ops.aten.view.default(bmm_default_57, [24, 4, 256, 768, 1]);  bmm_default_57 = None
        permute_default_226 = torch.ops.aten.permute.default(view_default_669, [0, 1, 2, 4, 3]);  view_default_669 = None
        permute_default_227 = torch.ops.aten.permute.default(permute_default_225, [0, 1, 4, 3, 2]);  permute_default_225 = None
        squeeze_dim_56 = torch.ops.aten.squeeze.dim(permute_default_227, -1);  permute_default_227 = None
        permute_default_228 = torch.ops.aten.permute.default(permute_default_226, [0, 1, 2, 4, 3]);  permute_default_226 = None
        squeeze_dim_57 = torch.ops.aten.squeeze.dim(permute_default_228, -1);  permute_default_228 = None
        slice_backward_default_168 = torch.ops.aten.slice_backward.default(squeeze_dim_57, [24, 4, 256, 769], 3, 0, -1, 1);  squeeze_dim_57 = None
        slice_backward_default_169 = torch.ops.aten.slice_backward.default(slice_backward_default_168, [24, 4, 256, 769], 2, 0, 9223372036854775807, 1);  slice_backward_default_168 = None
        slice_backward_default_170 = torch.ops.aten.slice_backward.default(slice_backward_default_169, [24, 4, 256, 769], 1, 0, 9223372036854775807, 1);  slice_backward_default_169 = None
        slice_backward_default_171 = torch.ops.aten.slice_backward.default(slice_backward_default_170, [24, 4, 256, 769], 0, 0, 9223372036854775807, 1);  slice_backward_default_170 = None
        view_default_670 = torch.ops.aten.view.default(slice_backward_default_171, [24, 4, 196864]);  slice_backward_default_171 = None
        slice_backward_default_172 = torch.ops.aten.slice_backward.default(view_default_670, [24, 4, 197120], 2, 0, -256, 1);  view_default_670 = None
        slice_backward_default_173 = torch.ops.aten.slice_backward.default(slice_backward_default_172, [24, 4, 197120], 1, 0, 9223372036854775807, 1);  slice_backward_default_172 = None
        slice_backward_default_174 = torch.ops.aten.slice_backward.default(slice_backward_default_173, [24, 4, 197120], 0, 0, 9223372036854775807, 1);  slice_backward_default_173 = None
        view_default_671 = torch.ops.aten.view.default(slice_backward_default_174, [24, 4, 256, 770]);  slice_backward_default_174 = None
        constant_pad_nd_default_72 = torch.ops.aten.constant_pad_nd.default(view_default_671, [0, -257]);  view_default_671 = None
        new_empty_default_92 = torch.ops.aten.new_empty.default(squeeze_dim_56, [2359296])
        zero__default_56 = torch.ops.aten.zero_.default(new_empty_default_92);  new_empty_default_92 = None
        arange_24 = torch.ops.aten.arange.start(0, 2359296, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_180 = torch.ops.aten.as_strided.default(arange_24, [24, 4, 768, 64], [98304, 16384, 64, 1], 0);  arange_24 = None
        clone_default_213 = torch.ops.aten.clone.default(as_strided_default_180, memory_format = torch.contiguous_format);  as_strided_default_180 = None
        _unsafe_view_default_205 = torch.ops.aten._unsafe_view.default(clone_default_213, [4718592]);  clone_default_213 = None
        view_default_672 = torch.ops.aten.view.default(squeeze_dim_56, [4718592]);  squeeze_dim_56 = None
        index_add__default_24 = torch.ops.aten.index_add_.default(zero__default_56, 0, _unsafe_view_default_205, view_default_672);  zero__default_56 = _unsafe_view_default_205 = view_default_672 = None
        as_strided_default_181 = torch.ops.aten.as_strided.default(index_add__default_24, [24, 1536, 64], [98304, 64, 1], 0);  index_add__default_24 = None
        constant_pad_nd_default_73 = torch.ops.aten.constant_pad_nd.default(as_strided_default_181, [0, 0, -256, -256]);  as_strided_default_181 = None
        view_default_673 = torch.ops.aten.view.default(constant_pad_nd_default_73, [2, 12, 1024, 64]);  constant_pad_nd_default_73 = None
        transpose_int_305 = torch.ops.aten.transpose.int(view_default_673, 1, 2);  view_default_673 = None
        view_default_674 = torch.ops.aten.view.default(constant_pad_nd_default_72, [2, 12, 1024, 513]);  constant_pad_nd_default_72 = None
        transpose_int_306 = torch.ops.aten.transpose.int(view_default_674, 1, 2);  view_default_674 = None
        transpose_int_307 = torch.ops.aten.transpose.int(transpose_int_305, 0, 1);  transpose_int_305 = None
        clone_default_214 = torch.ops.aten.clone.default(transpose_int_307, memory_format = torch.contiguous_format);  transpose_int_307 = None
        _unsafe_view_default_206 = torch.ops.aten._unsafe_view.default(clone_default_214, [1024, 2, 768]);  clone_default_214 = None
        where_scalar_self_48 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_53, 0.0, transpose_int_306);  unsqueeze_default_53 = transpose_int_306 = None
        _softmax_backward_data_default_8 = torch.ops.aten._softmax_backward_data.default(where_scalar_self_48, _softmax_default_3, -1, torch.float32);  where_scalar_self_48 = _softmax_default_3 = None
        new_empty_default_93 = torch.ops.aten.new_empty.default(_softmax_backward_data_default_8, [12607488])
        zero__default_57 = torch.ops.aten.zero_.default(new_empty_default_93);  new_empty_default_93 = None
        as_strided_default_182 = torch.ops.aten.as_strided.default(zero__default_57, [2, 1024, 12, 513], [6303744, 513, 525312, 1], 0)
        copy__default_208 = torch.ops.aten.copy_.default(as_strided_default_182, _softmax_backward_data_default_8);  as_strided_default_182 = _softmax_backward_data_default_8 = None
        as_strided_default_183 = torch.ops.aten.as_strided.default(zero__default_57, [24, 4, 256, 513], [525312, 131328, 513, 1], 0);  zero__default_57 = None
        new_empty_strided_default_56 = torch.ops.aten.new_empty_strided.default(as_strided_default_183, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_209 = torch.ops.aten.copy_.default(new_empty_strided_default_56, as_strided_default_183);  new_empty_strided_default_56 = as_strided_default_183 = None
        as_strided_default_184 = torch.ops.aten.as_strided.default(copy__default_209, [2, 1024, 12, 513], [6303744, 513, 525312, 1], 0)
        clone_default_215 = torch.ops.aten.clone.default(as_strided_default_184, memory_format = torch.contiguous_format)
        copy__default_210 = torch.ops.aten.copy_.default(as_strided_default_184, clone_default_215);  as_strided_default_184 = clone_default_215 = None
        new_empty_strided_default_57 = torch.ops.aten.new_empty_strided.default(copy__default_209, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_211 = torch.ops.aten.copy_.default(new_empty_strided_default_57, copy__default_209);  new_empty_strided_default_57 = copy__default_209 = None
        as_strided_default_185 = torch.ops.aten.as_strided.default(copy__default_211, [2, 256, 12, 257], [6303744, 513, 525312, 1], 394240)
        clone_default_216 = torch.ops.aten.clone.default(as_strided_default_185, memory_format = torch.contiguous_format)
        where_scalar_self_49 = torch.ops.aten.where.ScalarSelf(eq_scalar_13, 0.0, clone_default_216);  eq_scalar_13 = clone_default_216 = None
        copy__default_212 = torch.ops.aten.copy_.default(as_strided_default_185, where_scalar_self_49);  as_strided_default_185 = where_scalar_self_49 = None
        new_empty_strided_default_58 = torch.ops.aten.new_empty_strided.default(copy__default_211, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_213 = torch.ops.aten.copy_.default(new_empty_strided_default_58, copy__default_211);  new_empty_strided_default_58 = copy__default_211 = None
        as_strided_default_186 = torch.ops.aten.as_strided.default(copy__default_213, [2, 256, 12, 257], [6303744, 513, 525312, 1], 0)
        clone_default_217 = torch.ops.aten.clone.default(as_strided_default_186, memory_format = torch.contiguous_format)
        where_scalar_self_50 = torch.ops.aten.where.ScalarSelf(eq_scalar_12, 0.0, clone_default_217);  eq_scalar_12 = clone_default_217 = None
        copy__default_214 = torch.ops.aten.copy_.default(as_strided_default_186, where_scalar_self_50);  as_strided_default_186 = where_scalar_self_50 = None
        new_empty_strided_default_59 = torch.ops.aten.new_empty_strided.default(copy__default_213, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_215 = torch.ops.aten.copy_.default(new_empty_strided_default_59, copy__default_213);  new_empty_strided_default_59 = copy__default_213 = None
        as_strided_default_187 = torch.ops.aten.as_strided.default(copy__default_215, [24, 255, 255], [525312, 513, 1], 514)
        clone_default_218 = torch.ops.aten.clone.default(as_strided_default_187, memory_format = torch.contiguous_format)
        empty_like_default_24 = torch.ops.aten.empty_like.default(clone_default_218, memory_format = torch.contiguous_format)
        zero__default_58 = torch.ops.aten.zero_.default(empty_like_default_24);  empty_like_default_24 = None
        copy__default_216 = torch.ops.aten.copy_.default(as_strided_default_187, zero__default_58);  as_strided_default_187 = zero__default_58 = None
        slice_backward_default_175 = torch.ops.aten.slice_backward.default(clone_default_218, [24, 255, 513], 2, -255, 9223372036854775807, 1);  clone_default_218 = None
        slice_backward_default_176 = torch.ops.aten.slice_backward.default(slice_backward_default_175, [24, 512, 513], 1, 0, 255, 1);  slice_backward_default_175 = None
        select_backward_default_16 = torch.ops.aten.select_backward.default(slice_backward_default_176, [24, 3, 512, 513], 1, 0);  slice_backward_default_176 = None
        slice_backward_default_177 = torch.ops.aten.slice_backward.default(select_backward_default_16, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_16 = None
        new_empty_strided_default_60 = torch.ops.aten.new_empty_strided.default(copy__default_215, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_217 = torch.ops.aten.copy_.default(new_empty_strided_default_60, copy__default_215);  new_empty_strided_default_60 = copy__default_215 = None
        as_strided_default_188 = torch.ops.aten.as_strided.default(copy__default_217, [24, 3, 256, 256], [525312, 131328, 513, 1], 131328)
        clone_default_219 = torch.ops.aten.clone.default(as_strided_default_188, memory_format = torch.contiguous_format)
        empty_like_default_25 = torch.ops.aten.empty_like.default(clone_default_219, memory_format = torch.contiguous_format)
        zero__default_59 = torch.ops.aten.zero_.default(empty_like_default_25);  empty_like_default_25 = None
        copy__default_218 = torch.ops.aten.copy_.default(as_strided_default_188, zero__default_59);  as_strided_default_188 = zero__default_59 = None
        slice_backward_default_178 = torch.ops.aten.slice_backward.default(clone_default_219, [24, 3, 256, 513], 3, 257, 9223372036854775807, 1);  clone_default_219 = None
        slice_backward_default_179 = torch.ops.aten.slice_backward.default(slice_backward_default_178, [24, 3, 512, 513], 2, -257, -1, 1);  slice_backward_default_178 = None
        slice_backward_default_180 = torch.ops.aten.slice_backward.default(slice_backward_default_179, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_179 = None
        slice_backward_default_181 = torch.ops.aten.slice_backward.default(slice_backward_default_180, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_180 = None
        add_tensor_147 = torch.ops.aten.add.Tensor(slice_backward_default_177, slice_backward_default_181);  slice_backward_default_177 = slice_backward_default_181 = None
        new_empty_strided_default_61 = torch.ops.aten.new_empty_strided.default(copy__default_217, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_219 = torch.ops.aten.copy_.default(new_empty_strided_default_61, copy__default_217);  new_empty_strided_default_61 = copy__default_217 = None
        as_strided_default_189 = torch.ops.aten.as_strided.default(copy__default_219, [24, 256, 257], [525312, 513, 1], 394240)
        clone_default_220 = torch.ops.aten.clone.default(as_strided_default_189, memory_format = torch.contiguous_format)
        empty_like_default_26 = torch.ops.aten.empty_like.default(clone_default_220, memory_format = torch.contiguous_format)
        zero__default_60 = torch.ops.aten.zero_.default(empty_like_default_26);  empty_like_default_26 = None
        copy__default_220 = torch.ops.aten.copy_.default(as_strided_default_189, zero__default_60);  as_strided_default_189 = zero__default_60 = None
        slice_backward_default_182 = torch.ops.aten.slice_backward.default(clone_default_220, [24, 256, 513], 2, 0, 257, 1);  clone_default_220 = None
        slice_backward_default_183 = torch.ops.aten.slice_backward.default(slice_backward_default_182, [24, 512, 513], 1, 256, 9223372036854775807, 1);  slice_backward_default_182 = None
        select_backward_default_17 = torch.ops.aten.select_backward.default(slice_backward_default_183, [24, 3, 512, 513], 1, -1);  slice_backward_default_183 = None
        slice_backward_default_184 = torch.ops.aten.slice_backward.default(select_backward_default_17, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_17 = None
        add_tensor_148 = torch.ops.aten.add.Tensor(add_tensor_147, slice_backward_default_184);  add_tensor_147 = slice_backward_default_184 = None
        new_empty_strided_default_62 = torch.ops.aten.new_empty_strided.default(copy__default_219, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_221 = torch.ops.aten.copy_.default(new_empty_strided_default_62, copy__default_219);  new_empty_strided_default_62 = copy__default_219 = None
        as_strided_default_190 = torch.ops.aten.as_strided.default(copy__default_221, [24, 3, 256, 257], [525312, 131328, 513, 1], 256);  copy__default_221 = None
        clone_default_221 = torch.ops.aten.clone.default(as_strided_default_190, memory_format = torch.contiguous_format);  as_strided_default_190 = None
        slice_backward_default_185 = torch.ops.aten.slice_backward.default(clone_default_221, [24, 3, 256, 513], 3, 0, 257, 1);  clone_default_221 = None
        slice_backward_default_186 = torch.ops.aten.slice_backward.default(slice_backward_default_185, [24, 3, 512, 513], 2, 0, 256, 1);  slice_backward_default_185 = None
        slice_backward_default_187 = torch.ops.aten.slice_backward.default(slice_backward_default_186, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_186 = None
        slice_backward_default_188 = torch.ops.aten.slice_backward.default(slice_backward_default_187, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_187 = None
        add_tensor_149 = torch.ops.aten.add.Tensor(add_tensor_148, slice_backward_default_188);  add_tensor_148 = slice_backward_default_188 = None
        view_default_675 = torch.ops.aten.view.default(add_tensor_149, [24, 3, 513, 512]);  add_tensor_149 = None
        constant_pad_nd_default_74 = torch.ops.aten.constant_pad_nd.default(view_default_675, [0, 0, 0, -1]);  view_default_675 = None
        view_default_676 = torch.ops.aten.view.default(constant_pad_nd_default_74, [24, 3, 512, 512, 1]);  constant_pad_nd_default_74 = None
        permute_default_229 = torch.ops.aten.permute.default(view_default_676, [0, 1, 2, 4, 3]);  view_default_676 = None
        view_default_677 = torch.ops.aten.view.default(permute_default_229, [72, 512, 512]);  permute_default_229 = None
        transpose_int_308 = torch.ops.aten.transpose.int(_unsafe_view_default_45, 1, 2);  _unsafe_view_default_45 = None
        bmm_default_58 = torch.ops.aten.bmm.default(transpose_int_308, view_default_677);  transpose_int_308 = None
        transpose_int_309 = torch.ops.aten.transpose.int(_unsafe_view_default_46, 1, 2);  _unsafe_view_default_46 = None
        bmm_default_59 = torch.ops.aten.bmm.default(view_default_677, transpose_int_309);  view_default_677 = transpose_int_309 = None
        view_default_678 = torch.ops.aten.view.default(bmm_default_58, [24, 3, 64, 512, 1]);  bmm_default_58 = None
        permute_default_230 = torch.ops.aten.permute.default(view_default_678, [0, 1, 4, 3, 2]);  view_default_678 = None
        view_default_679 = torch.ops.aten.view.default(bmm_default_59, [24, 3, 512, 64, 1]);  bmm_default_59 = None
        permute_default_231 = torch.ops.aten.permute.default(view_default_679, [0, 1, 2, 4, 3]);  view_default_679 = None
        permute_default_232 = torch.ops.aten.permute.default(permute_default_230, [0, 1, 3, 4, 2]);  permute_default_230 = None
        squeeze_dim_58 = torch.ops.aten.squeeze.dim(permute_default_232, -1);  permute_default_232 = None
        permute_default_233 = torch.ops.aten.permute.default(permute_default_231, [0, 1, 2, 4, 3]);  permute_default_231 = None
        squeeze_dim_59 = torch.ops.aten.squeeze.dim(permute_default_233, -1);  permute_default_233 = None
        new_empty_default_94 = torch.ops.aten.new_empty.default(squeeze_dim_58, [1572864])
        zero__default_61 = torch.ops.aten.zero_.default(new_empty_default_94);  new_empty_default_94 = None
        arange_25 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_191 = torch.ops.aten.as_strided.default(arange_25, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_25 = None
        clone_default_222 = torch.ops.aten.clone.default(as_strided_default_191, memory_format = torch.contiguous_format);  as_strided_default_191 = None
        _unsafe_view_default_207 = torch.ops.aten._unsafe_view.default(clone_default_222, [2359296]);  clone_default_222 = None
        clone_default_223 = torch.ops.aten.clone.default(squeeze_dim_58, memory_format = torch.contiguous_format);  squeeze_dim_58 = None
        _unsafe_view_default_208 = torch.ops.aten._unsafe_view.default(clone_default_223, [2359296]);  clone_default_223 = None
        index_add__default_25 = torch.ops.aten.index_add_.default(zero__default_61, 0, _unsafe_view_default_207, _unsafe_view_default_208);  zero__default_61 = _unsafe_view_default_207 = _unsafe_view_default_208 = None
        as_strided_default_192 = torch.ops.aten.as_strided.default(index_add__default_25, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_25 = None
        view_default_680 = torch.ops.aten.view.default(as_strided_default_192, [24, 1024, 64]);  as_strided_default_192 = None
        new_empty_default_95 = torch.ops.aten.new_empty.default(squeeze_dim_59, [1572864])
        zero__default_62 = torch.ops.aten.zero_.default(new_empty_default_95);  new_empty_default_95 = None
        arange_26 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_193 = torch.ops.aten.as_strided.default(arange_26, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_26 = None
        clone_default_224 = torch.ops.aten.clone.default(as_strided_default_193, memory_format = torch.contiguous_format);  as_strided_default_193 = None
        _unsafe_view_default_209 = torch.ops.aten._unsafe_view.default(clone_default_224, [2359296]);  clone_default_224 = None
        view_default_681 = torch.ops.aten.view.default(squeeze_dim_59, [2359296]);  squeeze_dim_59 = None
        index_add__default_26 = torch.ops.aten.index_add_.default(zero__default_62, 0, _unsafe_view_default_209, view_default_681);  zero__default_62 = _unsafe_view_default_209 = view_default_681 = None
        as_strided_default_194 = torch.ops.aten.as_strided.default(index_add__default_26, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_26 = None
        view_default_682 = torch.ops.aten.view.default(as_strided_default_194, [24, 1024, 64]);  as_strided_default_194 = None
        view_default_683 = torch.ops.aten.view.default(view_default_680, [2, 12, 1024, 64]);  view_default_680 = None
        transpose_int_310 = torch.ops.aten.transpose.int(view_default_683, 1, 2);  view_default_683 = None
        view_default_684 = torch.ops.aten.view.default(view_default_682, [2, 12, 1024, 64]);  view_default_682 = None
        transpose_int_311 = torch.ops.aten.transpose.int(view_default_684, 1, 2);  view_default_684 = None
        transpose_int_312 = torch.ops.aten.transpose.int(transpose_int_310, 0, 1);  transpose_int_310 = None
        view_default_685 = torch.ops.aten.view.default(transpose_int_312, [1024, 2, 768]);  transpose_int_312 = None
        transpose_int_313 = torch.ops.aten.transpose.int(transpose_int_311, 0, 1);  transpose_int_311 = None
        view_default_686 = torch.ops.aten.view.default(transpose_int_313, [1024, 2, 768]);  transpose_int_313 = None
        div_tensor_8 = torch.ops.aten.div.Tensor(view_default_686, 8.0);  view_default_686 = None
        sum_dim_int_list_51 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_206, [0, 1], True)
        view_default_687 = torch.ops.aten.view.default(sum_dim_int_list_51, [768]);  sum_dim_int_list_51 = None
        view_default_688 = torch.ops.aten.view.default(_unsafe_view_default_206, [2048, 768]);  _unsafe_view_default_206 = None
        t_default_276 = torch.ops.aten.t.default(view_default_688)
        mm_default_150 = torch.ops.aten.mm.default(t_default_276, _unsafe_view_default_43);  t_default_276 = _unsafe_view_default_43 = None
        t_default_277 = torch.ops.aten.t.default(mm_default_150);  mm_default_150 = None
        t_default_278 = torch.ops.aten.t.default(t_default_20);  t_default_20 = None
        mm_default_151 = torch.ops.aten.mm.default(view_default_688, t_default_278);  view_default_688 = t_default_278 = None
        view_default_689 = torch.ops.aten.view.default(mm_default_151, [1024, 2, 768]);  mm_default_151 = None
        t_default_279 = torch.ops.aten.t.default(t_default_277);  t_default_277 = None
        sum_dim_int_list_52 = torch.ops.aten.sum.dim_IntList(view_default_685, [0, 1], True)
        view_default_690 = torch.ops.aten.view.default(sum_dim_int_list_52, [768]);  sum_dim_int_list_52 = None
        view_default_691 = torch.ops.aten.view.default(view_default_685, [2048, 768]);  view_default_685 = None
        t_default_280 = torch.ops.aten.t.default(view_default_691)
        mm_default_152 = torch.ops.aten.mm.default(t_default_280, _unsafe_view_default_41);  t_default_280 = _unsafe_view_default_41 = None
        t_default_281 = torch.ops.aten.t.default(mm_default_152);  mm_default_152 = None
        t_default_282 = torch.ops.aten.t.default(t_default_19);  t_default_19 = None
        mm_default_153 = torch.ops.aten.mm.default(view_default_691, t_default_282);  view_default_691 = t_default_282 = None
        view_default_692 = torch.ops.aten.view.default(mm_default_153, [1024, 2, 768]);  mm_default_153 = None
        add_tensor_150 = torch.ops.aten.add.Tensor(view_default_689, view_default_692);  view_default_689 = view_default_692 = None
        t_default_283 = torch.ops.aten.t.default(t_default_281);  t_default_281 = None
        sum_dim_int_list_53 = torch.ops.aten.sum.dim_IntList(div_tensor_8, [0, 1], True)
        view_default_693 = torch.ops.aten.view.default(sum_dim_int_list_53, [768]);  sum_dim_int_list_53 = None
        view_default_694 = torch.ops.aten.view.default(div_tensor_8, [2048, 768]);  div_tensor_8 = None
        t_default_284 = torch.ops.aten.t.default(view_default_694)
        mm_default_154 = torch.ops.aten.mm.default(t_default_284, _unsafe_view_default_39);  t_default_284 = _unsafe_view_default_39 = None
        t_default_285 = torch.ops.aten.t.default(mm_default_154);  mm_default_154 = None
        t_default_286 = torch.ops.aten.t.default(t_default_18);  t_default_18 = None
        mm_default_155 = torch.ops.aten.mm.default(view_default_694, t_default_286);  view_default_694 = t_default_286 = None
        view_default_695 = torch.ops.aten.view.default(mm_default_155, [1024, 2, 768]);  mm_default_155 = None
        add_tensor_151 = torch.ops.aten.add.Tensor(add_tensor_150, view_default_695);  add_tensor_150 = view_default_695 = None
        t_default_287 = torch.ops.aten.t.default(t_default_285);  t_default_285 = None
        transpose_int_314 = torch.ops.aten.transpose.int(add_tensor_151, 0, 1);  add_tensor_151 = None
        add_tensor_152 = torch.ops.aten.add.Tensor(getitem_123, transpose_int_314);  getitem_123 = transpose_int_314 = None
        native_layer_norm_backward_default_18 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_152, add_tensor_17, [768], getitem_16, getitem_17, primals_78, primals_77, [True, True, True]);  add_tensor_152 = add_tensor_17 = getitem_16 = getitem_17 = primals_78 = primals_77 = None
        getitem_126 = native_layer_norm_backward_default_18[0]
        getitem_127 = native_layer_norm_backward_default_18[1]
        getitem_128 = native_layer_norm_backward_default_18[2];  native_layer_norm_backward_default_18 = None
        view_default_696 = torch.ops.aten.view.default(getitem_126, [2048, 768])
        t_default_288 = torch.ops.aten.t.default(t_default_17);  t_default_17 = None
        mm_default_156 = torch.ops.aten.mm.default(view_default_696, t_default_288);  t_default_288 = None
        t_default_289 = torch.ops.aten.t.default(view_default_696)
        mm_default_157 = torch.ops.aten.mm.default(t_default_289, view_default_82);  t_default_289 = view_default_82 = None
        t_default_290 = torch.ops.aten.t.default(mm_default_157);  mm_default_157 = None
        sum_dim_int_list_54 = torch.ops.aten.sum.dim_IntList(view_default_696, [0], True);  view_default_696 = None
        view_default_697 = torch.ops.aten.view.default(sum_dim_int_list_54, [768]);  sum_dim_int_list_54 = None
        t_default_291 = torch.ops.aten.t.default(t_default_290);  t_default_290 = None
        view_default_698 = torch.ops.aten.view.default(mm_default_156, [2, 1024, 3072]);  mm_default_156 = None
        to_dtype_27 = torch.ops.aten.to.dtype(view_default_698, torch.float32);  view_default_698 = None
        to_dtype_28 = torch.ops.aten.to.dtype(view_default_81, torch.float32);  view_default_81 = None
        mul_tensor_75 = torch.ops.aten.mul.Tensor(to_dtype_28, 0.7071067811865476)
        erf_default_9 = torch.ops.aten.erf.default(mul_tensor_75);  mul_tensor_75 = None
        add_tensor_153 = torch.ops.aten.add.Tensor(erf_default_9, 1);  erf_default_9 = None
        mul_tensor_76 = torch.ops.aten.mul.Tensor(add_tensor_153, 0.5);  add_tensor_153 = None
        mul_tensor_77 = torch.ops.aten.mul.Tensor(to_dtype_28, to_dtype_28)
        mul_tensor_78 = torch.ops.aten.mul.Tensor(mul_tensor_77, -0.5);  mul_tensor_77 = None
        exp_default_9 = torch.ops.aten.exp.default(mul_tensor_78);  mul_tensor_78 = None
        mul_tensor_79 = torch.ops.aten.mul.Tensor(exp_default_9, 0.3989422804014327);  exp_default_9 = None
        mul_tensor_80 = torch.ops.aten.mul.Tensor(to_dtype_28, mul_tensor_79);  to_dtype_28 = mul_tensor_79 = None
        add_tensor_154 = torch.ops.aten.add.Tensor(mul_tensor_76, mul_tensor_80);  mul_tensor_76 = mul_tensor_80 = None
        mul_tensor_81 = torch.ops.aten.mul.Tensor(to_dtype_27, add_tensor_154);  to_dtype_27 = add_tensor_154 = None
        to_dtype_29 = torch.ops.aten.to.dtype(mul_tensor_81, torch.float32);  mul_tensor_81 = None
        view_default_699 = torch.ops.aten.view.default(to_dtype_29, [2048, 3072]);  to_dtype_29 = None
        t_default_292 = torch.ops.aten.t.default(t_default_16);  t_default_16 = None
        mm_default_158 = torch.ops.aten.mm.default(view_default_699, t_default_292);  t_default_292 = None
        t_default_293 = torch.ops.aten.t.default(view_default_699)
        mm_default_159 = torch.ops.aten.mm.default(t_default_293, view_default_80);  t_default_293 = view_default_80 = None
        t_default_294 = torch.ops.aten.t.default(mm_default_159);  mm_default_159 = None
        sum_dim_int_list_55 = torch.ops.aten.sum.dim_IntList(view_default_699, [0], True);  view_default_699 = None
        view_default_700 = torch.ops.aten.view.default(sum_dim_int_list_55, [3072]);  sum_dim_int_list_55 = None
        t_default_295 = torch.ops.aten.t.default(t_default_294);  t_default_294 = None
        view_default_701 = torch.ops.aten.view.default(mm_default_158, [2, 1024, 768]);  mm_default_158 = None
        add_tensor_155 = torch.ops.aten.add.Tensor(getitem_126, view_default_701);  getitem_126 = view_default_701 = None
        native_layer_norm_backward_default_19 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_155, add_tensor_16, [768], getitem_13, getitem_14, primals_66, primals_65, [True, True, True]);  add_tensor_155 = add_tensor_16 = getitem_13 = getitem_14 = primals_66 = primals_65 = None
        getitem_129 = native_layer_norm_backward_default_19[0]
        getitem_130 = native_layer_norm_backward_default_19[1]
        getitem_131 = native_layer_norm_backward_default_19[2];  native_layer_norm_backward_default_19 = None
        sum_dim_int_list_56 = torch.ops.aten.sum.dim_IntList(getitem_129, [0, 1], True)
        view_default_702 = torch.ops.aten.view.default(sum_dim_int_list_56, [768]);  sum_dim_int_list_56 = None
        view_default_703 = torch.ops.aten.view.default(getitem_129, [2048, 768])
        t_default_296 = torch.ops.aten.t.default(view_default_703)
        mm_default_160 = torch.ops.aten.mm.default(t_default_296, _unsafe_view_default_37);  t_default_296 = _unsafe_view_default_37 = None
        t_default_297 = torch.ops.aten.t.default(mm_default_160);  mm_default_160 = None
        t_default_298 = torch.ops.aten.t.default(t_default_15);  t_default_15 = None
        mm_default_161 = torch.ops.aten.mm.default(view_default_703, t_default_298);  view_default_703 = t_default_298 = None
        view_default_704 = torch.ops.aten.view.default(mm_default_161, [2, 1024, 768]);  mm_default_161 = None
        t_default_299 = torch.ops.aten.t.default(t_default_297);  t_default_297 = None
        transpose_int_315 = torch.ops.aten.transpose.int(view_default_704, 0, 1);  view_default_704 = None
        view_default_705 = torch.ops.aten.view.default(transpose_int_315, [1024, 2, 12, 64]);  transpose_int_315 = None
        transpose_int_316 = torch.ops.aten.transpose.int(view_default_705, 0, 1);  view_default_705 = None
        transpose_int_317 = torch.ops.aten.transpose.int(transpose_int_316, 1, 2);  transpose_int_316 = None
        clone_default_225 = torch.ops.aten.clone.default(transpose_int_317, memory_format = torch.contiguous_format);  transpose_int_317 = None
        _unsafe_view_default_210 = torch.ops.aten._unsafe_view.default(clone_default_225, [24, 4, 256, 64]);  clone_default_225 = None
        view_default_706 = torch.ops.aten.view.default(_unsafe_view_default_210, [24, 4, 256, 64, 1]);  _unsafe_view_default_210 = None
        permute_default_234 = torch.ops.aten.permute.default(view_default_706, [0, 1, 2, 4, 3]);  view_default_706 = None
        view_default_707 = torch.ops.aten.view.default(permute_default_234, [96, 256, 64]);  permute_default_234 = None
        transpose_int_318 = torch.ops.aten.transpose.int(view_default_76, 1, 2);  view_default_76 = None
        bmm_default_60 = torch.ops.aten.bmm.default(transpose_int_318, view_default_707);  transpose_int_318 = None
        transpose_int_319 = torch.ops.aten.transpose.int(_unsafe_view_default_35, 1, 2);  _unsafe_view_default_35 = None
        bmm_default_61 = torch.ops.aten.bmm.default(view_default_707, transpose_int_319);  view_default_707 = transpose_int_319 = None
        view_default_708 = torch.ops.aten.view.default(bmm_default_60, [24, 4, 768, 64, 1]);  bmm_default_60 = None
        permute_default_235 = torch.ops.aten.permute.default(view_default_708, [0, 1, 4, 3, 2]);  view_default_708 = None
        view_default_709 = torch.ops.aten.view.default(bmm_default_61, [24, 4, 256, 768, 1]);  bmm_default_61 = None
        permute_default_236 = torch.ops.aten.permute.default(view_default_709, [0, 1, 2, 4, 3]);  view_default_709 = None
        permute_default_237 = torch.ops.aten.permute.default(permute_default_235, [0, 1, 4, 3, 2]);  permute_default_235 = None
        squeeze_dim_60 = torch.ops.aten.squeeze.dim(permute_default_237, -1);  permute_default_237 = None
        permute_default_238 = torch.ops.aten.permute.default(permute_default_236, [0, 1, 2, 4, 3]);  permute_default_236 = None
        squeeze_dim_61 = torch.ops.aten.squeeze.dim(permute_default_238, -1);  permute_default_238 = None
        slice_backward_default_189 = torch.ops.aten.slice_backward.default(squeeze_dim_61, [24, 4, 256, 769], 3, 0, -1, 1);  squeeze_dim_61 = None
        slice_backward_default_190 = torch.ops.aten.slice_backward.default(slice_backward_default_189, [24, 4, 256, 769], 2, 0, 9223372036854775807, 1);  slice_backward_default_189 = None
        slice_backward_default_191 = torch.ops.aten.slice_backward.default(slice_backward_default_190, [24, 4, 256, 769], 1, 0, 9223372036854775807, 1);  slice_backward_default_190 = None
        slice_backward_default_192 = torch.ops.aten.slice_backward.default(slice_backward_default_191, [24, 4, 256, 769], 0, 0, 9223372036854775807, 1);  slice_backward_default_191 = None
        view_default_710 = torch.ops.aten.view.default(slice_backward_default_192, [24, 4, 196864]);  slice_backward_default_192 = None
        slice_backward_default_193 = torch.ops.aten.slice_backward.default(view_default_710, [24, 4, 197120], 2, 0, -256, 1);  view_default_710 = None
        slice_backward_default_194 = torch.ops.aten.slice_backward.default(slice_backward_default_193, [24, 4, 197120], 1, 0, 9223372036854775807, 1);  slice_backward_default_193 = None
        slice_backward_default_195 = torch.ops.aten.slice_backward.default(slice_backward_default_194, [24, 4, 197120], 0, 0, 9223372036854775807, 1);  slice_backward_default_194 = None
        view_default_711 = torch.ops.aten.view.default(slice_backward_default_195, [24, 4, 256, 770]);  slice_backward_default_195 = None
        constant_pad_nd_default_75 = torch.ops.aten.constant_pad_nd.default(view_default_711, [0, -257]);  view_default_711 = None
        new_empty_default_96 = torch.ops.aten.new_empty.default(squeeze_dim_60, [2359296])
        zero__default_63 = torch.ops.aten.zero_.default(new_empty_default_96);  new_empty_default_96 = None
        arange_27 = torch.ops.aten.arange.start(0, 2359296, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_195 = torch.ops.aten.as_strided.default(arange_27, [24, 4, 768, 64], [98304, 16384, 64, 1], 0);  arange_27 = None
        clone_default_226 = torch.ops.aten.clone.default(as_strided_default_195, memory_format = torch.contiguous_format);  as_strided_default_195 = None
        _unsafe_view_default_211 = torch.ops.aten._unsafe_view.default(clone_default_226, [4718592]);  clone_default_226 = None
        view_default_712 = torch.ops.aten.view.default(squeeze_dim_60, [4718592]);  squeeze_dim_60 = None
        index_add__default_27 = torch.ops.aten.index_add_.default(zero__default_63, 0, _unsafe_view_default_211, view_default_712);  zero__default_63 = _unsafe_view_default_211 = view_default_712 = None
        as_strided_default_196 = torch.ops.aten.as_strided.default(index_add__default_27, [24, 1536, 64], [98304, 64, 1], 0);  index_add__default_27 = None
        constant_pad_nd_default_76 = torch.ops.aten.constant_pad_nd.default(as_strided_default_196, [0, 0, -256, -256]);  as_strided_default_196 = None
        view_default_713 = torch.ops.aten.view.default(constant_pad_nd_default_76, [2, 12, 1024, 64]);  constant_pad_nd_default_76 = None
        transpose_int_320 = torch.ops.aten.transpose.int(view_default_713, 1, 2);  view_default_713 = None
        view_default_714 = torch.ops.aten.view.default(constant_pad_nd_default_75, [2, 12, 1024, 513]);  constant_pad_nd_default_75 = None
        transpose_int_321 = torch.ops.aten.transpose.int(view_default_714, 1, 2);  view_default_714 = None
        transpose_int_322 = torch.ops.aten.transpose.int(transpose_int_320, 0, 1);  transpose_int_320 = None
        clone_default_227 = torch.ops.aten.clone.default(transpose_int_322, memory_format = torch.contiguous_format);  transpose_int_322 = None
        _unsafe_view_default_212 = torch.ops.aten._unsafe_view.default(clone_default_227, [1024, 2, 768]);  clone_default_227 = None
        where_scalar_self_51 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_39, 0.0, transpose_int_321);  unsqueeze_default_39 = transpose_int_321 = None
        _softmax_backward_data_default_9 = torch.ops.aten._softmax_backward_data.default(where_scalar_self_51, _softmax_default_2, -1, torch.float32);  where_scalar_self_51 = _softmax_default_2 = None
        new_empty_default_97 = torch.ops.aten.new_empty.default(_softmax_backward_data_default_9, [12607488])
        zero__default_64 = torch.ops.aten.zero_.default(new_empty_default_97);  new_empty_default_97 = None
        as_strided_default_197 = torch.ops.aten.as_strided.default(zero__default_64, [2, 1024, 12, 513], [6303744, 513, 525312, 1], 0)
        copy__default_222 = torch.ops.aten.copy_.default(as_strided_default_197, _softmax_backward_data_default_9);  as_strided_default_197 = _softmax_backward_data_default_9 = None
        as_strided_default_198 = torch.ops.aten.as_strided.default(zero__default_64, [24, 4, 256, 513], [525312, 131328, 513, 1], 0);  zero__default_64 = None
        new_empty_strided_default_63 = torch.ops.aten.new_empty_strided.default(as_strided_default_198, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_223 = torch.ops.aten.copy_.default(new_empty_strided_default_63, as_strided_default_198);  new_empty_strided_default_63 = as_strided_default_198 = None
        as_strided_default_199 = torch.ops.aten.as_strided.default(copy__default_223, [2, 1024, 12, 513], [6303744, 513, 525312, 1], 0)
        clone_default_228 = torch.ops.aten.clone.default(as_strided_default_199, memory_format = torch.contiguous_format)
        copy__default_224 = torch.ops.aten.copy_.default(as_strided_default_199, clone_default_228);  as_strided_default_199 = clone_default_228 = None
        new_empty_strided_default_64 = torch.ops.aten.new_empty_strided.default(copy__default_223, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_225 = torch.ops.aten.copy_.default(new_empty_strided_default_64, copy__default_223);  new_empty_strided_default_64 = copy__default_223 = None
        as_strided_default_200 = torch.ops.aten.as_strided.default(copy__default_225, [2, 256, 12, 257], [6303744, 513, 525312, 1], 394240)
        clone_default_229 = torch.ops.aten.clone.default(as_strided_default_200, memory_format = torch.contiguous_format)
        where_scalar_self_52 = torch.ops.aten.where.ScalarSelf(eq_scalar_9, 0.0, clone_default_229);  eq_scalar_9 = clone_default_229 = None
        copy__default_226 = torch.ops.aten.copy_.default(as_strided_default_200, where_scalar_self_52);  as_strided_default_200 = where_scalar_self_52 = None
        new_empty_strided_default_65 = torch.ops.aten.new_empty_strided.default(copy__default_225, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_227 = torch.ops.aten.copy_.default(new_empty_strided_default_65, copy__default_225);  new_empty_strided_default_65 = copy__default_225 = None
        as_strided_default_201 = torch.ops.aten.as_strided.default(copy__default_227, [2, 256, 12, 257], [6303744, 513, 525312, 1], 0)
        clone_default_230 = torch.ops.aten.clone.default(as_strided_default_201, memory_format = torch.contiguous_format)
        where_scalar_self_53 = torch.ops.aten.where.ScalarSelf(eq_scalar_8, 0.0, clone_default_230);  eq_scalar_8 = clone_default_230 = None
        copy__default_228 = torch.ops.aten.copy_.default(as_strided_default_201, where_scalar_self_53);  as_strided_default_201 = where_scalar_self_53 = None
        new_empty_strided_default_66 = torch.ops.aten.new_empty_strided.default(copy__default_227, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_229 = torch.ops.aten.copy_.default(new_empty_strided_default_66, copy__default_227);  new_empty_strided_default_66 = copy__default_227 = None
        as_strided_default_202 = torch.ops.aten.as_strided.default(copy__default_229, [24, 255, 255], [525312, 513, 1], 514)
        clone_default_231 = torch.ops.aten.clone.default(as_strided_default_202, memory_format = torch.contiguous_format)
        empty_like_default_27 = torch.ops.aten.empty_like.default(clone_default_231, memory_format = torch.contiguous_format)
        zero__default_65 = torch.ops.aten.zero_.default(empty_like_default_27);  empty_like_default_27 = None
        copy__default_230 = torch.ops.aten.copy_.default(as_strided_default_202, zero__default_65);  as_strided_default_202 = zero__default_65 = None
        slice_backward_default_196 = torch.ops.aten.slice_backward.default(clone_default_231, [24, 255, 513], 2, -255, 9223372036854775807, 1);  clone_default_231 = None
        slice_backward_default_197 = torch.ops.aten.slice_backward.default(slice_backward_default_196, [24, 512, 513], 1, 0, 255, 1);  slice_backward_default_196 = None
        select_backward_default_18 = torch.ops.aten.select_backward.default(slice_backward_default_197, [24, 3, 512, 513], 1, 0);  slice_backward_default_197 = None
        slice_backward_default_198 = torch.ops.aten.slice_backward.default(select_backward_default_18, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_18 = None
        new_empty_strided_default_67 = torch.ops.aten.new_empty_strided.default(copy__default_229, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_231 = torch.ops.aten.copy_.default(new_empty_strided_default_67, copy__default_229);  new_empty_strided_default_67 = copy__default_229 = None
        as_strided_default_203 = torch.ops.aten.as_strided.default(copy__default_231, [24, 3, 256, 256], [525312, 131328, 513, 1], 131328)
        clone_default_232 = torch.ops.aten.clone.default(as_strided_default_203, memory_format = torch.contiguous_format)
        empty_like_default_28 = torch.ops.aten.empty_like.default(clone_default_232, memory_format = torch.contiguous_format)
        zero__default_66 = torch.ops.aten.zero_.default(empty_like_default_28);  empty_like_default_28 = None
        copy__default_232 = torch.ops.aten.copy_.default(as_strided_default_203, zero__default_66);  as_strided_default_203 = zero__default_66 = None
        slice_backward_default_199 = torch.ops.aten.slice_backward.default(clone_default_232, [24, 3, 256, 513], 3, 257, 9223372036854775807, 1);  clone_default_232 = None
        slice_backward_default_200 = torch.ops.aten.slice_backward.default(slice_backward_default_199, [24, 3, 512, 513], 2, -257, -1, 1);  slice_backward_default_199 = None
        slice_backward_default_201 = torch.ops.aten.slice_backward.default(slice_backward_default_200, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_200 = None
        slice_backward_default_202 = torch.ops.aten.slice_backward.default(slice_backward_default_201, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_201 = None
        add_tensor_156 = torch.ops.aten.add.Tensor(slice_backward_default_198, slice_backward_default_202);  slice_backward_default_198 = slice_backward_default_202 = None
        new_empty_strided_default_68 = torch.ops.aten.new_empty_strided.default(copy__default_231, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_233 = torch.ops.aten.copy_.default(new_empty_strided_default_68, copy__default_231);  new_empty_strided_default_68 = copy__default_231 = None
        as_strided_default_204 = torch.ops.aten.as_strided.default(copy__default_233, [24, 256, 257], [525312, 513, 1], 394240)
        clone_default_233 = torch.ops.aten.clone.default(as_strided_default_204, memory_format = torch.contiguous_format)
        empty_like_default_29 = torch.ops.aten.empty_like.default(clone_default_233, memory_format = torch.contiguous_format)
        zero__default_67 = torch.ops.aten.zero_.default(empty_like_default_29);  empty_like_default_29 = None
        copy__default_234 = torch.ops.aten.copy_.default(as_strided_default_204, zero__default_67);  as_strided_default_204 = zero__default_67 = None
        slice_backward_default_203 = torch.ops.aten.slice_backward.default(clone_default_233, [24, 256, 513], 2, 0, 257, 1);  clone_default_233 = None
        slice_backward_default_204 = torch.ops.aten.slice_backward.default(slice_backward_default_203, [24, 512, 513], 1, 256, 9223372036854775807, 1);  slice_backward_default_203 = None
        select_backward_default_19 = torch.ops.aten.select_backward.default(slice_backward_default_204, [24, 3, 512, 513], 1, -1);  slice_backward_default_204 = None
        slice_backward_default_205 = torch.ops.aten.slice_backward.default(select_backward_default_19, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_19 = None
        add_tensor_157 = torch.ops.aten.add.Tensor(add_tensor_156, slice_backward_default_205);  add_tensor_156 = slice_backward_default_205 = None
        new_empty_strided_default_69 = torch.ops.aten.new_empty_strided.default(copy__default_233, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_235 = torch.ops.aten.copy_.default(new_empty_strided_default_69, copy__default_233);  new_empty_strided_default_69 = copy__default_233 = None
        as_strided_default_205 = torch.ops.aten.as_strided.default(copy__default_235, [24, 3, 256, 257], [525312, 131328, 513, 1], 256);  copy__default_235 = None
        clone_default_234 = torch.ops.aten.clone.default(as_strided_default_205, memory_format = torch.contiguous_format);  as_strided_default_205 = None
        slice_backward_default_206 = torch.ops.aten.slice_backward.default(clone_default_234, [24, 3, 256, 513], 3, 0, 257, 1);  clone_default_234 = None
        slice_backward_default_207 = torch.ops.aten.slice_backward.default(slice_backward_default_206, [24, 3, 512, 513], 2, 0, 256, 1);  slice_backward_default_206 = None
        slice_backward_default_208 = torch.ops.aten.slice_backward.default(slice_backward_default_207, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_207 = None
        slice_backward_default_209 = torch.ops.aten.slice_backward.default(slice_backward_default_208, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_208 = None
        add_tensor_158 = torch.ops.aten.add.Tensor(add_tensor_157, slice_backward_default_209);  add_tensor_157 = slice_backward_default_209 = None
        view_default_715 = torch.ops.aten.view.default(add_tensor_158, [24, 3, 513, 512]);  add_tensor_158 = None
        constant_pad_nd_default_77 = torch.ops.aten.constant_pad_nd.default(view_default_715, [0, 0, 0, -1]);  view_default_715 = None
        view_default_716 = torch.ops.aten.view.default(constant_pad_nd_default_77, [24, 3, 512, 512, 1]);  constant_pad_nd_default_77 = None
        permute_default_239 = torch.ops.aten.permute.default(view_default_716, [0, 1, 2, 4, 3]);  view_default_716 = None
        view_default_717 = torch.ops.aten.view.default(permute_default_239, [72, 512, 512]);  permute_default_239 = None
        transpose_int_323 = torch.ops.aten.transpose.int(_unsafe_view_default_32, 1, 2);  _unsafe_view_default_32 = None
        bmm_default_62 = torch.ops.aten.bmm.default(transpose_int_323, view_default_717);  transpose_int_323 = None
        transpose_int_324 = torch.ops.aten.transpose.int(_unsafe_view_default_33, 1, 2);  _unsafe_view_default_33 = None
        bmm_default_63 = torch.ops.aten.bmm.default(view_default_717, transpose_int_324);  view_default_717 = transpose_int_324 = None
        view_default_718 = torch.ops.aten.view.default(bmm_default_62, [24, 3, 64, 512, 1]);  bmm_default_62 = None
        permute_default_240 = torch.ops.aten.permute.default(view_default_718, [0, 1, 4, 3, 2]);  view_default_718 = None
        view_default_719 = torch.ops.aten.view.default(bmm_default_63, [24, 3, 512, 64, 1]);  bmm_default_63 = None
        permute_default_241 = torch.ops.aten.permute.default(view_default_719, [0, 1, 2, 4, 3]);  view_default_719 = None
        permute_default_242 = torch.ops.aten.permute.default(permute_default_240, [0, 1, 3, 4, 2]);  permute_default_240 = None
        squeeze_dim_62 = torch.ops.aten.squeeze.dim(permute_default_242, -1);  permute_default_242 = None
        permute_default_243 = torch.ops.aten.permute.default(permute_default_241, [0, 1, 2, 4, 3]);  permute_default_241 = None
        squeeze_dim_63 = torch.ops.aten.squeeze.dim(permute_default_243, -1);  permute_default_243 = None
        new_empty_default_98 = torch.ops.aten.new_empty.default(squeeze_dim_62, [1572864])
        zero__default_68 = torch.ops.aten.zero_.default(new_empty_default_98);  new_empty_default_98 = None
        arange_28 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_206 = torch.ops.aten.as_strided.default(arange_28, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_28 = None
        clone_default_235 = torch.ops.aten.clone.default(as_strided_default_206, memory_format = torch.contiguous_format);  as_strided_default_206 = None
        _unsafe_view_default_213 = torch.ops.aten._unsafe_view.default(clone_default_235, [2359296]);  clone_default_235 = None
        clone_default_236 = torch.ops.aten.clone.default(squeeze_dim_62, memory_format = torch.contiguous_format);  squeeze_dim_62 = None
        _unsafe_view_default_214 = torch.ops.aten._unsafe_view.default(clone_default_236, [2359296]);  clone_default_236 = None
        index_add__default_28 = torch.ops.aten.index_add_.default(zero__default_68, 0, _unsafe_view_default_213, _unsafe_view_default_214);  zero__default_68 = _unsafe_view_default_213 = _unsafe_view_default_214 = None
        as_strided_default_207 = torch.ops.aten.as_strided.default(index_add__default_28, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_28 = None
        view_default_720 = torch.ops.aten.view.default(as_strided_default_207, [24, 1024, 64]);  as_strided_default_207 = None
        new_empty_default_99 = torch.ops.aten.new_empty.default(squeeze_dim_63, [1572864])
        zero__default_69 = torch.ops.aten.zero_.default(new_empty_default_99);  new_empty_default_99 = None
        arange_29 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_208 = torch.ops.aten.as_strided.default(arange_29, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_29 = None
        clone_default_237 = torch.ops.aten.clone.default(as_strided_default_208, memory_format = torch.contiguous_format);  as_strided_default_208 = None
        _unsafe_view_default_215 = torch.ops.aten._unsafe_view.default(clone_default_237, [2359296]);  clone_default_237 = None
        view_default_721 = torch.ops.aten.view.default(squeeze_dim_63, [2359296]);  squeeze_dim_63 = None
        index_add__default_29 = torch.ops.aten.index_add_.default(zero__default_69, 0, _unsafe_view_default_215, view_default_721);  zero__default_69 = _unsafe_view_default_215 = view_default_721 = None
        as_strided_default_209 = torch.ops.aten.as_strided.default(index_add__default_29, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_29 = None
        view_default_722 = torch.ops.aten.view.default(as_strided_default_209, [24, 1024, 64]);  as_strided_default_209 = None
        view_default_723 = torch.ops.aten.view.default(view_default_720, [2, 12, 1024, 64]);  view_default_720 = None
        transpose_int_325 = torch.ops.aten.transpose.int(view_default_723, 1, 2);  view_default_723 = None
        view_default_724 = torch.ops.aten.view.default(view_default_722, [2, 12, 1024, 64]);  view_default_722 = None
        transpose_int_326 = torch.ops.aten.transpose.int(view_default_724, 1, 2);  view_default_724 = None
        transpose_int_327 = torch.ops.aten.transpose.int(transpose_int_325, 0, 1);  transpose_int_325 = None
        view_default_725 = torch.ops.aten.view.default(transpose_int_327, [1024, 2, 768]);  transpose_int_327 = None
        transpose_int_328 = torch.ops.aten.transpose.int(transpose_int_326, 0, 1);  transpose_int_326 = None
        view_default_726 = torch.ops.aten.view.default(transpose_int_328, [1024, 2, 768]);  transpose_int_328 = None
        div_tensor_9 = torch.ops.aten.div.Tensor(view_default_726, 8.0);  view_default_726 = None
        sum_dim_int_list_57 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_212, [0, 1], True)
        view_default_727 = torch.ops.aten.view.default(sum_dim_int_list_57, [768]);  sum_dim_int_list_57 = None
        view_default_728 = torch.ops.aten.view.default(_unsafe_view_default_212, [2048, 768]);  _unsafe_view_default_212 = None
        t_default_300 = torch.ops.aten.t.default(view_default_728)
        mm_default_162 = torch.ops.aten.mm.default(t_default_300, _unsafe_view_default_30);  t_default_300 = _unsafe_view_default_30 = None
        t_default_301 = torch.ops.aten.t.default(mm_default_162);  mm_default_162 = None
        t_default_302 = torch.ops.aten.t.default(t_default_14);  t_default_14 = None
        mm_default_163 = torch.ops.aten.mm.default(view_default_728, t_default_302);  view_default_728 = t_default_302 = None
        view_default_729 = torch.ops.aten.view.default(mm_default_163, [1024, 2, 768]);  mm_default_163 = None
        t_default_303 = torch.ops.aten.t.default(t_default_301);  t_default_301 = None
        sum_dim_int_list_58 = torch.ops.aten.sum.dim_IntList(view_default_725, [0, 1], True)
        view_default_730 = torch.ops.aten.view.default(sum_dim_int_list_58, [768]);  sum_dim_int_list_58 = None
        view_default_731 = torch.ops.aten.view.default(view_default_725, [2048, 768]);  view_default_725 = None
        t_default_304 = torch.ops.aten.t.default(view_default_731)
        mm_default_164 = torch.ops.aten.mm.default(t_default_304, _unsafe_view_default_28);  t_default_304 = _unsafe_view_default_28 = None
        t_default_305 = torch.ops.aten.t.default(mm_default_164);  mm_default_164 = None
        t_default_306 = torch.ops.aten.t.default(t_default_13);  t_default_13 = None
        mm_default_165 = torch.ops.aten.mm.default(view_default_731, t_default_306);  view_default_731 = t_default_306 = None
        view_default_732 = torch.ops.aten.view.default(mm_default_165, [1024, 2, 768]);  mm_default_165 = None
        add_tensor_159 = torch.ops.aten.add.Tensor(view_default_729, view_default_732);  view_default_729 = view_default_732 = None
        t_default_307 = torch.ops.aten.t.default(t_default_305);  t_default_305 = None
        sum_dim_int_list_59 = torch.ops.aten.sum.dim_IntList(div_tensor_9, [0, 1], True)
        view_default_733 = torch.ops.aten.view.default(sum_dim_int_list_59, [768]);  sum_dim_int_list_59 = None
        view_default_734 = torch.ops.aten.view.default(div_tensor_9, [2048, 768]);  div_tensor_9 = None
        t_default_308 = torch.ops.aten.t.default(view_default_734)
        mm_default_166 = torch.ops.aten.mm.default(t_default_308, _unsafe_view_default_26);  t_default_308 = _unsafe_view_default_26 = None
        t_default_309 = torch.ops.aten.t.default(mm_default_166);  mm_default_166 = None
        t_default_310 = torch.ops.aten.t.default(t_default_12);  t_default_12 = None
        mm_default_167 = torch.ops.aten.mm.default(view_default_734, t_default_310);  view_default_734 = t_default_310 = None
        view_default_735 = torch.ops.aten.view.default(mm_default_167, [1024, 2, 768]);  mm_default_167 = None
        add_tensor_160 = torch.ops.aten.add.Tensor(add_tensor_159, view_default_735);  add_tensor_159 = view_default_735 = None
        t_default_311 = torch.ops.aten.t.default(t_default_309);  t_default_309 = None
        transpose_int_329 = torch.ops.aten.transpose.int(add_tensor_160, 0, 1);  add_tensor_160 = None
        add_tensor_161 = torch.ops.aten.add.Tensor(getitem_129, transpose_int_329);  getitem_129 = transpose_int_329 = None
        native_layer_norm_backward_default_20 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_161, add_tensor_11, [768], getitem_10, getitem_11, primals_62, primals_61, [True, True, True]);  add_tensor_161 = add_tensor_11 = getitem_10 = getitem_11 = primals_62 = primals_61 = None
        getitem_132 = native_layer_norm_backward_default_20[0]
        getitem_133 = native_layer_norm_backward_default_20[1]
        getitem_134 = native_layer_norm_backward_default_20[2];  native_layer_norm_backward_default_20 = None
        view_default_736 = torch.ops.aten.view.default(getitem_132, [2048, 768])
        t_default_312 = torch.ops.aten.t.default(t_default_11);  t_default_11 = None
        mm_default_168 = torch.ops.aten.mm.default(view_default_736, t_default_312);  t_default_312 = None
        t_default_313 = torch.ops.aten.t.default(view_default_736)
        mm_default_169 = torch.ops.aten.mm.default(t_default_313, view_default_54);  t_default_313 = view_default_54 = None
        t_default_314 = torch.ops.aten.t.default(mm_default_169);  mm_default_169 = None
        sum_dim_int_list_60 = torch.ops.aten.sum.dim_IntList(view_default_736, [0], True);  view_default_736 = None
        view_default_737 = torch.ops.aten.view.default(sum_dim_int_list_60, [768]);  sum_dim_int_list_60 = None
        t_default_315 = torch.ops.aten.t.default(t_default_314);  t_default_314 = None
        view_default_738 = torch.ops.aten.view.default(mm_default_168, [2, 1024, 3072]);  mm_default_168 = None
        to_dtype_30 = torch.ops.aten.to.dtype(view_default_738, torch.float32);  view_default_738 = None
        to_dtype_31 = torch.ops.aten.to.dtype(view_default_53, torch.float32);  view_default_53 = None
        mul_tensor_82 = torch.ops.aten.mul.Tensor(to_dtype_31, 0.7071067811865476)
        erf_default_10 = torch.ops.aten.erf.default(mul_tensor_82);  mul_tensor_82 = None
        add_tensor_162 = torch.ops.aten.add.Tensor(erf_default_10, 1);  erf_default_10 = None
        mul_tensor_83 = torch.ops.aten.mul.Tensor(add_tensor_162, 0.5);  add_tensor_162 = None
        mul_tensor_84 = torch.ops.aten.mul.Tensor(to_dtype_31, to_dtype_31)
        mul_tensor_85 = torch.ops.aten.mul.Tensor(mul_tensor_84, -0.5);  mul_tensor_84 = None
        exp_default_10 = torch.ops.aten.exp.default(mul_tensor_85);  mul_tensor_85 = None
        mul_tensor_86 = torch.ops.aten.mul.Tensor(exp_default_10, 0.3989422804014327);  exp_default_10 = None
        mul_tensor_87 = torch.ops.aten.mul.Tensor(to_dtype_31, mul_tensor_86);  to_dtype_31 = mul_tensor_86 = None
        add_tensor_163 = torch.ops.aten.add.Tensor(mul_tensor_83, mul_tensor_87);  mul_tensor_83 = mul_tensor_87 = None
        mul_tensor_88 = torch.ops.aten.mul.Tensor(to_dtype_30, add_tensor_163);  to_dtype_30 = add_tensor_163 = None
        to_dtype_32 = torch.ops.aten.to.dtype(mul_tensor_88, torch.float32);  mul_tensor_88 = None
        view_default_739 = torch.ops.aten.view.default(to_dtype_32, [2048, 3072]);  to_dtype_32 = None
        t_default_316 = torch.ops.aten.t.default(t_default_10);  t_default_10 = None
        mm_default_170 = torch.ops.aten.mm.default(view_default_739, t_default_316);  t_default_316 = None
        t_default_317 = torch.ops.aten.t.default(view_default_739)
        mm_default_171 = torch.ops.aten.mm.default(t_default_317, view_default_52);  t_default_317 = view_default_52 = None
        t_default_318 = torch.ops.aten.t.default(mm_default_171);  mm_default_171 = None
        sum_dim_int_list_61 = torch.ops.aten.sum.dim_IntList(view_default_739, [0], True);  view_default_739 = None
        view_default_740 = torch.ops.aten.view.default(sum_dim_int_list_61, [3072]);  sum_dim_int_list_61 = None
        t_default_319 = torch.ops.aten.t.default(t_default_318);  t_default_318 = None
        view_default_741 = torch.ops.aten.view.default(mm_default_170, [2, 1024, 768]);  mm_default_170 = None
        add_tensor_164 = torch.ops.aten.add.Tensor(getitem_132, view_default_741);  getitem_132 = view_default_741 = None
        native_layer_norm_backward_default_21 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_164, add_tensor_10, [768], getitem_7, getitem_8, primals_50, primals_49, [True, True, True]);  add_tensor_164 = add_tensor_10 = getitem_7 = getitem_8 = primals_50 = primals_49 = None
        getitem_135 = native_layer_norm_backward_default_21[0]
        getitem_136 = native_layer_norm_backward_default_21[1]
        getitem_137 = native_layer_norm_backward_default_21[2];  native_layer_norm_backward_default_21 = None
        sum_dim_int_list_62 = torch.ops.aten.sum.dim_IntList(getitem_135, [0, 1], True)
        view_default_742 = torch.ops.aten.view.default(sum_dim_int_list_62, [768]);  sum_dim_int_list_62 = None
        view_default_743 = torch.ops.aten.view.default(getitem_135, [2048, 768])
        t_default_320 = torch.ops.aten.t.default(view_default_743)
        mm_default_172 = torch.ops.aten.mm.default(t_default_320, _unsafe_view_default_24);  t_default_320 = _unsafe_view_default_24 = None
        t_default_321 = torch.ops.aten.t.default(mm_default_172);  mm_default_172 = None
        t_default_322 = torch.ops.aten.t.default(t_default_9);  t_default_9 = None
        mm_default_173 = torch.ops.aten.mm.default(view_default_743, t_default_322);  view_default_743 = t_default_322 = None
        view_default_744 = torch.ops.aten.view.default(mm_default_173, [2, 1024, 768]);  mm_default_173 = None
        t_default_323 = torch.ops.aten.t.default(t_default_321);  t_default_321 = None
        transpose_int_330 = torch.ops.aten.transpose.int(view_default_744, 0, 1);  view_default_744 = None
        view_default_745 = torch.ops.aten.view.default(transpose_int_330, [1024, 2, 12, 64]);  transpose_int_330 = None
        transpose_int_331 = torch.ops.aten.transpose.int(view_default_745, 0, 1);  view_default_745 = None
        transpose_int_332 = torch.ops.aten.transpose.int(transpose_int_331, 1, 2);  transpose_int_331 = None
        clone_default_238 = torch.ops.aten.clone.default(transpose_int_332, memory_format = torch.contiguous_format);  transpose_int_332 = None
        _unsafe_view_default_216 = torch.ops.aten._unsafe_view.default(clone_default_238, [24, 4, 256, 64]);  clone_default_238 = None
        view_default_746 = torch.ops.aten.view.default(_unsafe_view_default_216, [24, 4, 256, 64, 1]);  _unsafe_view_default_216 = None
        permute_default_244 = torch.ops.aten.permute.default(view_default_746, [0, 1, 2, 4, 3]);  view_default_746 = None
        view_default_747 = torch.ops.aten.view.default(permute_default_244, [96, 256, 64]);  permute_default_244 = None
        transpose_int_333 = torch.ops.aten.transpose.int(view_default_48, 1, 2);  view_default_48 = None
        bmm_default_64 = torch.ops.aten.bmm.default(transpose_int_333, view_default_747);  transpose_int_333 = None
        transpose_int_334 = torch.ops.aten.transpose.int(_unsafe_view_default_22, 1, 2);  _unsafe_view_default_22 = None
        bmm_default_65 = torch.ops.aten.bmm.default(view_default_747, transpose_int_334);  view_default_747 = transpose_int_334 = None
        view_default_748 = torch.ops.aten.view.default(bmm_default_64, [24, 4, 768, 64, 1]);  bmm_default_64 = None
        permute_default_245 = torch.ops.aten.permute.default(view_default_748, [0, 1, 4, 3, 2]);  view_default_748 = None
        view_default_749 = torch.ops.aten.view.default(bmm_default_65, [24, 4, 256, 768, 1]);  bmm_default_65 = None
        permute_default_246 = torch.ops.aten.permute.default(view_default_749, [0, 1, 2, 4, 3]);  view_default_749 = None
        permute_default_247 = torch.ops.aten.permute.default(permute_default_245, [0, 1, 4, 3, 2]);  permute_default_245 = None
        squeeze_dim_64 = torch.ops.aten.squeeze.dim(permute_default_247, -1);  permute_default_247 = None
        permute_default_248 = torch.ops.aten.permute.default(permute_default_246, [0, 1, 2, 4, 3]);  permute_default_246 = None
        squeeze_dim_65 = torch.ops.aten.squeeze.dim(permute_default_248, -1);  permute_default_248 = None
        slice_backward_default_210 = torch.ops.aten.slice_backward.default(squeeze_dim_65, [24, 4, 256, 769], 3, 0, -1, 1);  squeeze_dim_65 = None
        slice_backward_default_211 = torch.ops.aten.slice_backward.default(slice_backward_default_210, [24, 4, 256, 769], 2, 0, 9223372036854775807, 1);  slice_backward_default_210 = None
        slice_backward_default_212 = torch.ops.aten.slice_backward.default(slice_backward_default_211, [24, 4, 256, 769], 1, 0, 9223372036854775807, 1);  slice_backward_default_211 = None
        slice_backward_default_213 = torch.ops.aten.slice_backward.default(slice_backward_default_212, [24, 4, 256, 769], 0, 0, 9223372036854775807, 1);  slice_backward_default_212 = None
        view_default_750 = torch.ops.aten.view.default(slice_backward_default_213, [24, 4, 196864]);  slice_backward_default_213 = None
        slice_backward_default_214 = torch.ops.aten.slice_backward.default(view_default_750, [24, 4, 197120], 2, 0, -256, 1);  view_default_750 = None
        slice_backward_default_215 = torch.ops.aten.slice_backward.default(slice_backward_default_214, [24, 4, 197120], 1, 0, 9223372036854775807, 1);  slice_backward_default_214 = None
        slice_backward_default_216 = torch.ops.aten.slice_backward.default(slice_backward_default_215, [24, 4, 197120], 0, 0, 9223372036854775807, 1);  slice_backward_default_215 = None
        view_default_751 = torch.ops.aten.view.default(slice_backward_default_216, [24, 4, 256, 770]);  slice_backward_default_216 = None
        constant_pad_nd_default_78 = torch.ops.aten.constant_pad_nd.default(view_default_751, [0, -257]);  view_default_751 = None
        new_empty_default_100 = torch.ops.aten.new_empty.default(squeeze_dim_64, [2359296])
        zero__default_70 = torch.ops.aten.zero_.default(new_empty_default_100);  new_empty_default_100 = None
        arange_30 = torch.ops.aten.arange.start(0, 2359296, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_210 = torch.ops.aten.as_strided.default(arange_30, [24, 4, 768, 64], [98304, 16384, 64, 1], 0);  arange_30 = None
        clone_default_239 = torch.ops.aten.clone.default(as_strided_default_210, memory_format = torch.contiguous_format);  as_strided_default_210 = None
        _unsafe_view_default_217 = torch.ops.aten._unsafe_view.default(clone_default_239, [4718592]);  clone_default_239 = None
        view_default_752 = torch.ops.aten.view.default(squeeze_dim_64, [4718592]);  squeeze_dim_64 = None
        index_add__default_30 = torch.ops.aten.index_add_.default(zero__default_70, 0, _unsafe_view_default_217, view_default_752);  zero__default_70 = _unsafe_view_default_217 = view_default_752 = None
        as_strided_default_211 = torch.ops.aten.as_strided.default(index_add__default_30, [24, 1536, 64], [98304, 64, 1], 0);  index_add__default_30 = None
        constant_pad_nd_default_79 = torch.ops.aten.constant_pad_nd.default(as_strided_default_211, [0, 0, -256, -256]);  as_strided_default_211 = None
        view_default_753 = torch.ops.aten.view.default(constant_pad_nd_default_79, [2, 12, 1024, 64]);  constant_pad_nd_default_79 = None
        transpose_int_335 = torch.ops.aten.transpose.int(view_default_753, 1, 2);  view_default_753 = None
        view_default_754 = torch.ops.aten.view.default(constant_pad_nd_default_78, [2, 12, 1024, 513]);  constant_pad_nd_default_78 = None
        transpose_int_336 = torch.ops.aten.transpose.int(view_default_754, 1, 2);  view_default_754 = None
        transpose_int_337 = torch.ops.aten.transpose.int(transpose_int_335, 0, 1);  transpose_int_335 = None
        clone_default_240 = torch.ops.aten.clone.default(transpose_int_337, memory_format = torch.contiguous_format);  transpose_int_337 = None
        _unsafe_view_default_218 = torch.ops.aten._unsafe_view.default(clone_default_240, [1024, 2, 768]);  clone_default_240 = None
        where_scalar_self_54 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_25, 0.0, transpose_int_336);  unsqueeze_default_25 = transpose_int_336 = None
        _softmax_backward_data_default_10 = torch.ops.aten._softmax_backward_data.default(where_scalar_self_54, _softmax_default_1, -1, torch.float32);  where_scalar_self_54 = _softmax_default_1 = None
        new_empty_default_101 = torch.ops.aten.new_empty.default(_softmax_backward_data_default_10, [12607488])
        zero__default_71 = torch.ops.aten.zero_.default(new_empty_default_101);  new_empty_default_101 = None
        as_strided_default_212 = torch.ops.aten.as_strided.default(zero__default_71, [2, 1024, 12, 513], [6303744, 513, 525312, 1], 0)
        copy__default_236 = torch.ops.aten.copy_.default(as_strided_default_212, _softmax_backward_data_default_10);  as_strided_default_212 = _softmax_backward_data_default_10 = None
        as_strided_default_213 = torch.ops.aten.as_strided.default(zero__default_71, [24, 4, 256, 513], [525312, 131328, 513, 1], 0);  zero__default_71 = None
        new_empty_strided_default_70 = torch.ops.aten.new_empty_strided.default(as_strided_default_213, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_237 = torch.ops.aten.copy_.default(new_empty_strided_default_70, as_strided_default_213);  new_empty_strided_default_70 = as_strided_default_213 = None
        as_strided_default_214 = torch.ops.aten.as_strided.default(copy__default_237, [2, 1024, 12, 513], [6303744, 513, 525312, 1], 0)
        clone_default_241 = torch.ops.aten.clone.default(as_strided_default_214, memory_format = torch.contiguous_format)
        copy__default_238 = torch.ops.aten.copy_.default(as_strided_default_214, clone_default_241);  as_strided_default_214 = clone_default_241 = None
        new_empty_strided_default_71 = torch.ops.aten.new_empty_strided.default(copy__default_237, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_239 = torch.ops.aten.copy_.default(new_empty_strided_default_71, copy__default_237);  new_empty_strided_default_71 = copy__default_237 = None
        as_strided_default_215 = torch.ops.aten.as_strided.default(copy__default_239, [2, 256, 12, 257], [6303744, 513, 525312, 1], 394240)
        clone_default_242 = torch.ops.aten.clone.default(as_strided_default_215, memory_format = torch.contiguous_format)
        where_scalar_self_55 = torch.ops.aten.where.ScalarSelf(eq_scalar_5, 0.0, clone_default_242);  eq_scalar_5 = clone_default_242 = None
        copy__default_240 = torch.ops.aten.copy_.default(as_strided_default_215, where_scalar_self_55);  as_strided_default_215 = where_scalar_self_55 = None
        new_empty_strided_default_72 = torch.ops.aten.new_empty_strided.default(copy__default_239, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_241 = torch.ops.aten.copy_.default(new_empty_strided_default_72, copy__default_239);  new_empty_strided_default_72 = copy__default_239 = None
        as_strided_default_216 = torch.ops.aten.as_strided.default(copy__default_241, [2, 256, 12, 257], [6303744, 513, 525312, 1], 0)
        clone_default_243 = torch.ops.aten.clone.default(as_strided_default_216, memory_format = torch.contiguous_format)
        where_scalar_self_56 = torch.ops.aten.where.ScalarSelf(eq_scalar_4, 0.0, clone_default_243);  eq_scalar_4 = clone_default_243 = None
        copy__default_242 = torch.ops.aten.copy_.default(as_strided_default_216, where_scalar_self_56);  as_strided_default_216 = where_scalar_self_56 = None
        new_empty_strided_default_73 = torch.ops.aten.new_empty_strided.default(copy__default_241, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_243 = torch.ops.aten.copy_.default(new_empty_strided_default_73, copy__default_241);  new_empty_strided_default_73 = copy__default_241 = None
        as_strided_default_217 = torch.ops.aten.as_strided.default(copy__default_243, [24, 255, 255], [525312, 513, 1], 514)
        clone_default_244 = torch.ops.aten.clone.default(as_strided_default_217, memory_format = torch.contiguous_format)
        empty_like_default_30 = torch.ops.aten.empty_like.default(clone_default_244, memory_format = torch.contiguous_format)
        zero__default_72 = torch.ops.aten.zero_.default(empty_like_default_30);  empty_like_default_30 = None
        copy__default_244 = torch.ops.aten.copy_.default(as_strided_default_217, zero__default_72);  as_strided_default_217 = zero__default_72 = None
        slice_backward_default_217 = torch.ops.aten.slice_backward.default(clone_default_244, [24, 255, 513], 2, -255, 9223372036854775807, 1);  clone_default_244 = None
        slice_backward_default_218 = torch.ops.aten.slice_backward.default(slice_backward_default_217, [24, 512, 513], 1, 0, 255, 1);  slice_backward_default_217 = None
        select_backward_default_20 = torch.ops.aten.select_backward.default(slice_backward_default_218, [24, 3, 512, 513], 1, 0);  slice_backward_default_218 = None
        slice_backward_default_219 = torch.ops.aten.slice_backward.default(select_backward_default_20, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_20 = None
        new_empty_strided_default_74 = torch.ops.aten.new_empty_strided.default(copy__default_243, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_245 = torch.ops.aten.copy_.default(new_empty_strided_default_74, copy__default_243);  new_empty_strided_default_74 = copy__default_243 = None
        as_strided_default_218 = torch.ops.aten.as_strided.default(copy__default_245, [24, 3, 256, 256], [525312, 131328, 513, 1], 131328)
        clone_default_245 = torch.ops.aten.clone.default(as_strided_default_218, memory_format = torch.contiguous_format)
        empty_like_default_31 = torch.ops.aten.empty_like.default(clone_default_245, memory_format = torch.contiguous_format)
        zero__default_73 = torch.ops.aten.zero_.default(empty_like_default_31);  empty_like_default_31 = None
        copy__default_246 = torch.ops.aten.copy_.default(as_strided_default_218, zero__default_73);  as_strided_default_218 = zero__default_73 = None
        slice_backward_default_220 = torch.ops.aten.slice_backward.default(clone_default_245, [24, 3, 256, 513], 3, 257, 9223372036854775807, 1);  clone_default_245 = None
        slice_backward_default_221 = torch.ops.aten.slice_backward.default(slice_backward_default_220, [24, 3, 512, 513], 2, -257, -1, 1);  slice_backward_default_220 = None
        slice_backward_default_222 = torch.ops.aten.slice_backward.default(slice_backward_default_221, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_221 = None
        slice_backward_default_223 = torch.ops.aten.slice_backward.default(slice_backward_default_222, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_222 = None
        add_tensor_165 = torch.ops.aten.add.Tensor(slice_backward_default_219, slice_backward_default_223);  slice_backward_default_219 = slice_backward_default_223 = None
        new_empty_strided_default_75 = torch.ops.aten.new_empty_strided.default(copy__default_245, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_247 = torch.ops.aten.copy_.default(new_empty_strided_default_75, copy__default_245);  new_empty_strided_default_75 = copy__default_245 = None
        as_strided_default_219 = torch.ops.aten.as_strided.default(copy__default_247, [24, 256, 257], [525312, 513, 1], 394240)
        clone_default_246 = torch.ops.aten.clone.default(as_strided_default_219, memory_format = torch.contiguous_format)
        empty_like_default_32 = torch.ops.aten.empty_like.default(clone_default_246, memory_format = torch.contiguous_format)
        zero__default_74 = torch.ops.aten.zero_.default(empty_like_default_32);  empty_like_default_32 = None
        copy__default_248 = torch.ops.aten.copy_.default(as_strided_default_219, zero__default_74);  as_strided_default_219 = zero__default_74 = None
        slice_backward_default_224 = torch.ops.aten.slice_backward.default(clone_default_246, [24, 256, 513], 2, 0, 257, 1);  clone_default_246 = None
        slice_backward_default_225 = torch.ops.aten.slice_backward.default(slice_backward_default_224, [24, 512, 513], 1, 256, 9223372036854775807, 1);  slice_backward_default_224 = None
        select_backward_default_21 = torch.ops.aten.select_backward.default(slice_backward_default_225, [24, 3, 512, 513], 1, -1);  slice_backward_default_225 = None
        slice_backward_default_226 = torch.ops.aten.slice_backward.default(select_backward_default_21, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_21 = None
        add_tensor_166 = torch.ops.aten.add.Tensor(add_tensor_165, slice_backward_default_226);  add_tensor_165 = slice_backward_default_226 = None
        new_empty_strided_default_76 = torch.ops.aten.new_empty_strided.default(copy__default_247, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_249 = torch.ops.aten.copy_.default(new_empty_strided_default_76, copy__default_247);  new_empty_strided_default_76 = copy__default_247 = None
        as_strided_default_220 = torch.ops.aten.as_strided.default(copy__default_249, [24, 3, 256, 257], [525312, 131328, 513, 1], 256);  copy__default_249 = None
        clone_default_247 = torch.ops.aten.clone.default(as_strided_default_220, memory_format = torch.contiguous_format);  as_strided_default_220 = None
        slice_backward_default_227 = torch.ops.aten.slice_backward.default(clone_default_247, [24, 3, 256, 513], 3, 0, 257, 1);  clone_default_247 = None
        slice_backward_default_228 = torch.ops.aten.slice_backward.default(slice_backward_default_227, [24, 3, 512, 513], 2, 0, 256, 1);  slice_backward_default_227 = None
        slice_backward_default_229 = torch.ops.aten.slice_backward.default(slice_backward_default_228, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_228 = None
        slice_backward_default_230 = torch.ops.aten.slice_backward.default(slice_backward_default_229, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_229 = None
        add_tensor_167 = torch.ops.aten.add.Tensor(add_tensor_166, slice_backward_default_230);  add_tensor_166 = slice_backward_default_230 = None
        view_default_755 = torch.ops.aten.view.default(add_tensor_167, [24, 3, 513, 512]);  add_tensor_167 = None
        constant_pad_nd_default_80 = torch.ops.aten.constant_pad_nd.default(view_default_755, [0, 0, 0, -1]);  view_default_755 = None
        view_default_756 = torch.ops.aten.view.default(constant_pad_nd_default_80, [24, 3, 512, 512, 1]);  constant_pad_nd_default_80 = None
        permute_default_249 = torch.ops.aten.permute.default(view_default_756, [0, 1, 2, 4, 3]);  view_default_756 = None
        view_default_757 = torch.ops.aten.view.default(permute_default_249, [72, 512, 512]);  permute_default_249 = None
        transpose_int_338 = torch.ops.aten.transpose.int(_unsafe_view_default_19, 1, 2);  _unsafe_view_default_19 = None
        bmm_default_66 = torch.ops.aten.bmm.default(transpose_int_338, view_default_757);  transpose_int_338 = None
        transpose_int_339 = torch.ops.aten.transpose.int(_unsafe_view_default_20, 1, 2);  _unsafe_view_default_20 = None
        bmm_default_67 = torch.ops.aten.bmm.default(view_default_757, transpose_int_339);  view_default_757 = transpose_int_339 = None
        view_default_758 = torch.ops.aten.view.default(bmm_default_66, [24, 3, 64, 512, 1]);  bmm_default_66 = None
        permute_default_250 = torch.ops.aten.permute.default(view_default_758, [0, 1, 4, 3, 2]);  view_default_758 = None
        view_default_759 = torch.ops.aten.view.default(bmm_default_67, [24, 3, 512, 64, 1]);  bmm_default_67 = None
        permute_default_251 = torch.ops.aten.permute.default(view_default_759, [0, 1, 2, 4, 3]);  view_default_759 = None
        permute_default_252 = torch.ops.aten.permute.default(permute_default_250, [0, 1, 3, 4, 2]);  permute_default_250 = None
        squeeze_dim_66 = torch.ops.aten.squeeze.dim(permute_default_252, -1);  permute_default_252 = None
        permute_default_253 = torch.ops.aten.permute.default(permute_default_251, [0, 1, 2, 4, 3]);  permute_default_251 = None
        squeeze_dim_67 = torch.ops.aten.squeeze.dim(permute_default_253, -1);  permute_default_253 = None
        new_empty_default_102 = torch.ops.aten.new_empty.default(squeeze_dim_66, [1572864])
        zero__default_75 = torch.ops.aten.zero_.default(new_empty_default_102);  new_empty_default_102 = None
        arange_31 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_221 = torch.ops.aten.as_strided.default(arange_31, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_31 = None
        clone_default_248 = torch.ops.aten.clone.default(as_strided_default_221, memory_format = torch.contiguous_format);  as_strided_default_221 = None
        _unsafe_view_default_219 = torch.ops.aten._unsafe_view.default(clone_default_248, [2359296]);  clone_default_248 = None
        clone_default_249 = torch.ops.aten.clone.default(squeeze_dim_66, memory_format = torch.contiguous_format);  squeeze_dim_66 = None
        _unsafe_view_default_220 = torch.ops.aten._unsafe_view.default(clone_default_249, [2359296]);  clone_default_249 = None
        index_add__default_31 = torch.ops.aten.index_add_.default(zero__default_75, 0, _unsafe_view_default_219, _unsafe_view_default_220);  zero__default_75 = _unsafe_view_default_219 = _unsafe_view_default_220 = None
        as_strided_default_222 = torch.ops.aten.as_strided.default(index_add__default_31, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_31 = None
        view_default_760 = torch.ops.aten.view.default(as_strided_default_222, [24, 1024, 64]);  as_strided_default_222 = None
        new_empty_default_103 = torch.ops.aten.new_empty.default(squeeze_dim_67, [1572864])
        zero__default_76 = torch.ops.aten.zero_.default(new_empty_default_103);  new_empty_default_103 = None
        arange_32 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_223 = torch.ops.aten.as_strided.default(arange_32, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_32 = None
        clone_default_250 = torch.ops.aten.clone.default(as_strided_default_223, memory_format = torch.contiguous_format);  as_strided_default_223 = None
        _unsafe_view_default_221 = torch.ops.aten._unsafe_view.default(clone_default_250, [2359296]);  clone_default_250 = None
        view_default_761 = torch.ops.aten.view.default(squeeze_dim_67, [2359296]);  squeeze_dim_67 = None
        index_add__default_32 = torch.ops.aten.index_add_.default(zero__default_76, 0, _unsafe_view_default_221, view_default_761);  zero__default_76 = _unsafe_view_default_221 = view_default_761 = None
        as_strided_default_224 = torch.ops.aten.as_strided.default(index_add__default_32, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_32 = None
        view_default_762 = torch.ops.aten.view.default(as_strided_default_224, [24, 1024, 64]);  as_strided_default_224 = None
        view_default_763 = torch.ops.aten.view.default(view_default_760, [2, 12, 1024, 64]);  view_default_760 = None
        transpose_int_340 = torch.ops.aten.transpose.int(view_default_763, 1, 2);  view_default_763 = None
        view_default_764 = torch.ops.aten.view.default(view_default_762, [2, 12, 1024, 64]);  view_default_762 = None
        transpose_int_341 = torch.ops.aten.transpose.int(view_default_764, 1, 2);  view_default_764 = None
        transpose_int_342 = torch.ops.aten.transpose.int(transpose_int_340, 0, 1);  transpose_int_340 = None
        view_default_765 = torch.ops.aten.view.default(transpose_int_342, [1024, 2, 768]);  transpose_int_342 = None
        transpose_int_343 = torch.ops.aten.transpose.int(transpose_int_341, 0, 1);  transpose_int_341 = None
        view_default_766 = torch.ops.aten.view.default(transpose_int_343, [1024, 2, 768]);  transpose_int_343 = None
        div_tensor_10 = torch.ops.aten.div.Tensor(view_default_766, 8.0);  view_default_766 = None
        sum_dim_int_list_63 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_218, [0, 1], True)
        view_default_767 = torch.ops.aten.view.default(sum_dim_int_list_63, [768]);  sum_dim_int_list_63 = None
        view_default_768 = torch.ops.aten.view.default(_unsafe_view_default_218, [2048, 768]);  _unsafe_view_default_218 = None
        t_default_324 = torch.ops.aten.t.default(view_default_768)
        mm_default_174 = torch.ops.aten.mm.default(t_default_324, _unsafe_view_default_17);  t_default_324 = _unsafe_view_default_17 = None
        t_default_325 = torch.ops.aten.t.default(mm_default_174);  mm_default_174 = None
        t_default_326 = torch.ops.aten.t.default(t_default_8);  t_default_8 = None
        mm_default_175 = torch.ops.aten.mm.default(view_default_768, t_default_326);  view_default_768 = t_default_326 = None
        view_default_769 = torch.ops.aten.view.default(mm_default_175, [1024, 2, 768]);  mm_default_175 = None
        t_default_327 = torch.ops.aten.t.default(t_default_325);  t_default_325 = None
        sum_dim_int_list_64 = torch.ops.aten.sum.dim_IntList(view_default_765, [0, 1], True)
        view_default_770 = torch.ops.aten.view.default(sum_dim_int_list_64, [768]);  sum_dim_int_list_64 = None
        view_default_771 = torch.ops.aten.view.default(view_default_765, [2048, 768]);  view_default_765 = None
        t_default_328 = torch.ops.aten.t.default(view_default_771)
        mm_default_176 = torch.ops.aten.mm.default(t_default_328, _unsafe_view_default_15);  t_default_328 = _unsafe_view_default_15 = None
        t_default_329 = torch.ops.aten.t.default(mm_default_176);  mm_default_176 = None
        t_default_330 = torch.ops.aten.t.default(t_default_7);  t_default_7 = None
        mm_default_177 = torch.ops.aten.mm.default(view_default_771, t_default_330);  view_default_771 = t_default_330 = None
        view_default_772 = torch.ops.aten.view.default(mm_default_177, [1024, 2, 768]);  mm_default_177 = None
        add_tensor_168 = torch.ops.aten.add.Tensor(view_default_769, view_default_772);  view_default_769 = view_default_772 = None
        t_default_331 = torch.ops.aten.t.default(t_default_329);  t_default_329 = None
        sum_dim_int_list_65 = torch.ops.aten.sum.dim_IntList(div_tensor_10, [0, 1], True)
        view_default_773 = torch.ops.aten.view.default(sum_dim_int_list_65, [768]);  sum_dim_int_list_65 = None
        view_default_774 = torch.ops.aten.view.default(div_tensor_10, [2048, 768]);  div_tensor_10 = None
        t_default_332 = torch.ops.aten.t.default(view_default_774)
        mm_default_178 = torch.ops.aten.mm.default(t_default_332, _unsafe_view_default_13);  t_default_332 = _unsafe_view_default_13 = None
        t_default_333 = torch.ops.aten.t.default(mm_default_178);  mm_default_178 = None
        t_default_334 = torch.ops.aten.t.default(t_default_6);  t_default_6 = None
        mm_default_179 = torch.ops.aten.mm.default(view_default_774, t_default_334);  view_default_774 = t_default_334 = None
        view_default_775 = torch.ops.aten.view.default(mm_default_179, [1024, 2, 768]);  mm_default_179 = None
        add_tensor_169 = torch.ops.aten.add.Tensor(add_tensor_168, view_default_775);  add_tensor_168 = view_default_775 = None
        t_default_335 = torch.ops.aten.t.default(t_default_333);  t_default_333 = None
        transpose_int_344 = torch.ops.aten.transpose.int(add_tensor_169, 0, 1);  add_tensor_169 = None
        add_tensor_170 = torch.ops.aten.add.Tensor(getitem_135, transpose_int_344);  getitem_135 = transpose_int_344 = None
        native_layer_norm_backward_default_22 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_170, add_tensor_5, [768], getitem_4, getitem_5, primals_14, primals_13, [True, True, True]);  add_tensor_170 = add_tensor_5 = getitem_4 = getitem_5 = primals_14 = primals_13 = None
        getitem_138 = native_layer_norm_backward_default_22[0]
        getitem_139 = native_layer_norm_backward_default_22[1]
        getitem_140 = native_layer_norm_backward_default_22[2];  native_layer_norm_backward_default_22 = None
        view_default_776 = torch.ops.aten.view.default(getitem_138, [2048, 768])
        t_default_336 = torch.ops.aten.t.default(t_default_5);  t_default_5 = None
        mm_default_180 = torch.ops.aten.mm.default(view_default_776, t_default_336);  t_default_336 = None
        t_default_337 = torch.ops.aten.t.default(view_default_776)
        mm_default_181 = torch.ops.aten.mm.default(t_default_337, view_default_26);  t_default_337 = view_default_26 = None
        t_default_338 = torch.ops.aten.t.default(mm_default_181);  mm_default_181 = None
        sum_dim_int_list_66 = torch.ops.aten.sum.dim_IntList(view_default_776, [0], True);  view_default_776 = None
        view_default_777 = torch.ops.aten.view.default(sum_dim_int_list_66, [768]);  sum_dim_int_list_66 = None
        t_default_339 = torch.ops.aten.t.default(t_default_338);  t_default_338 = None
        view_default_778 = torch.ops.aten.view.default(mm_default_180, [2, 1024, 3072]);  mm_default_180 = None
        to_dtype_33 = torch.ops.aten.to.dtype(view_default_778, torch.float32);  view_default_778 = None
        to_dtype_34 = torch.ops.aten.to.dtype(view_default_25, torch.float32);  view_default_25 = None
        mul_tensor_89 = torch.ops.aten.mul.Tensor(to_dtype_34, 0.7071067811865476)
        erf_default_11 = torch.ops.aten.erf.default(mul_tensor_89);  mul_tensor_89 = None
        add_tensor_171 = torch.ops.aten.add.Tensor(erf_default_11, 1);  erf_default_11 = None
        mul_tensor_90 = torch.ops.aten.mul.Tensor(add_tensor_171, 0.5);  add_tensor_171 = None
        mul_tensor_91 = torch.ops.aten.mul.Tensor(to_dtype_34, to_dtype_34)
        mul_tensor_92 = torch.ops.aten.mul.Tensor(mul_tensor_91, -0.5);  mul_tensor_91 = None
        exp_default_11 = torch.ops.aten.exp.default(mul_tensor_92);  mul_tensor_92 = None
        mul_tensor_93 = torch.ops.aten.mul.Tensor(exp_default_11, 0.3989422804014327);  exp_default_11 = None
        mul_tensor_94 = torch.ops.aten.mul.Tensor(to_dtype_34, mul_tensor_93);  to_dtype_34 = mul_tensor_93 = None
        add_tensor_172 = torch.ops.aten.add.Tensor(mul_tensor_90, mul_tensor_94);  mul_tensor_90 = mul_tensor_94 = None
        mul_tensor_95 = torch.ops.aten.mul.Tensor(to_dtype_33, add_tensor_172);  to_dtype_33 = add_tensor_172 = None
        to_dtype_35 = torch.ops.aten.to.dtype(mul_tensor_95, torch.float32);  mul_tensor_95 = None
        view_default_779 = torch.ops.aten.view.default(to_dtype_35, [2048, 3072]);  to_dtype_35 = None
        t_default_340 = torch.ops.aten.t.default(t_default_4);  t_default_4 = None
        mm_default_182 = torch.ops.aten.mm.default(view_default_779, t_default_340);  t_default_340 = None
        t_default_341 = torch.ops.aten.t.default(view_default_779)
        mm_default_183 = torch.ops.aten.mm.default(t_default_341, view_default_24);  t_default_341 = view_default_24 = None
        t_default_342 = torch.ops.aten.t.default(mm_default_183);  mm_default_183 = None
        sum_dim_int_list_67 = torch.ops.aten.sum.dim_IntList(view_default_779, [0], True);  view_default_779 = None
        view_default_780 = torch.ops.aten.view.default(sum_dim_int_list_67, [3072]);  sum_dim_int_list_67 = None
        t_default_343 = torch.ops.aten.t.default(t_default_342);  t_default_342 = None
        view_default_781 = torch.ops.aten.view.default(mm_default_182, [2, 1024, 768]);  mm_default_182 = None
        add_tensor_173 = torch.ops.aten.add.Tensor(getitem_138, view_default_781);  getitem_138 = view_default_781 = None
        native_layer_norm_backward_default_23 = torch.ops.aten.native_layer_norm_backward.default(add_tensor_173, add_tensor_4, [768], getitem_1, getitem_2, primals_2, primals_1, [True, True, True]);  add_tensor_173 = add_tensor_4 = getitem_1 = getitem_2 = primals_2 = primals_1 = None
        getitem_141 = native_layer_norm_backward_default_23[0]
        getitem_142 = native_layer_norm_backward_default_23[1]
        getitem_143 = native_layer_norm_backward_default_23[2];  native_layer_norm_backward_default_23 = None
        sum_dim_int_list_68 = torch.ops.aten.sum.dim_IntList(getitem_141, [0, 1], True)
        view_default_782 = torch.ops.aten.view.default(sum_dim_int_list_68, [768]);  sum_dim_int_list_68 = None
        view_default_783 = torch.ops.aten.view.default(getitem_141, [2048, 768])
        t_default_344 = torch.ops.aten.t.default(view_default_783)
        mm_default_184 = torch.ops.aten.mm.default(t_default_344, _unsafe_view_default_11);  t_default_344 = _unsafe_view_default_11 = None
        t_default_345 = torch.ops.aten.t.default(mm_default_184);  mm_default_184 = None
        t_default_346 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        mm_default_185 = torch.ops.aten.mm.default(view_default_783, t_default_346);  view_default_783 = t_default_346 = None
        view_default_784 = torch.ops.aten.view.default(mm_default_185, [2, 1024, 768]);  mm_default_185 = None
        t_default_347 = torch.ops.aten.t.default(t_default_345);  t_default_345 = None
        transpose_int_345 = torch.ops.aten.transpose.int(view_default_784, 0, 1);  view_default_784 = None
        view_default_785 = torch.ops.aten.view.default(transpose_int_345, [1024, 2, 12, 64]);  transpose_int_345 = None
        transpose_int_346 = torch.ops.aten.transpose.int(view_default_785, 0, 1);  view_default_785 = None
        transpose_int_347 = torch.ops.aten.transpose.int(transpose_int_346, 1, 2);  transpose_int_346 = None
        clone_default_251 = torch.ops.aten.clone.default(transpose_int_347, memory_format = torch.contiguous_format);  transpose_int_347 = None
        _unsafe_view_default_222 = torch.ops.aten._unsafe_view.default(clone_default_251, [24, 4, 256, 64]);  clone_default_251 = None
        view_default_786 = torch.ops.aten.view.default(_unsafe_view_default_222, [24, 4, 256, 64, 1]);  _unsafe_view_default_222 = None
        permute_default_254 = torch.ops.aten.permute.default(view_default_786, [0, 1, 2, 4, 3]);  view_default_786 = None
        view_default_787 = torch.ops.aten.view.default(permute_default_254, [96, 256, 64]);  permute_default_254 = None
        transpose_int_348 = torch.ops.aten.transpose.int(view_default_20, 1, 2);  view_default_20 = None
        bmm_default_68 = torch.ops.aten.bmm.default(transpose_int_348, view_default_787);  transpose_int_348 = None
        transpose_int_349 = torch.ops.aten.transpose.int(_unsafe_view_default_9, 1, 2);  _unsafe_view_default_9 = None
        bmm_default_69 = torch.ops.aten.bmm.default(view_default_787, transpose_int_349);  view_default_787 = transpose_int_349 = None
        view_default_788 = torch.ops.aten.view.default(bmm_default_68, [24, 4, 768, 64, 1]);  bmm_default_68 = None
        permute_default_255 = torch.ops.aten.permute.default(view_default_788, [0, 1, 4, 3, 2]);  view_default_788 = None
        view_default_789 = torch.ops.aten.view.default(bmm_default_69, [24, 4, 256, 768, 1]);  bmm_default_69 = None
        permute_default_256 = torch.ops.aten.permute.default(view_default_789, [0, 1, 2, 4, 3]);  view_default_789 = None
        permute_default_257 = torch.ops.aten.permute.default(permute_default_255, [0, 1, 4, 3, 2]);  permute_default_255 = None
        squeeze_dim_68 = torch.ops.aten.squeeze.dim(permute_default_257, -1);  permute_default_257 = None
        permute_default_258 = torch.ops.aten.permute.default(permute_default_256, [0, 1, 2, 4, 3]);  permute_default_256 = None
        squeeze_dim_69 = torch.ops.aten.squeeze.dim(permute_default_258, -1);  permute_default_258 = None
        slice_backward_default_231 = torch.ops.aten.slice_backward.default(squeeze_dim_69, [24, 4, 256, 769], 3, 0, -1, 1);  squeeze_dim_69 = None
        slice_backward_default_232 = torch.ops.aten.slice_backward.default(slice_backward_default_231, [24, 4, 256, 769], 2, 0, 9223372036854775807, 1);  slice_backward_default_231 = None
        slice_backward_default_233 = torch.ops.aten.slice_backward.default(slice_backward_default_232, [24, 4, 256, 769], 1, 0, 9223372036854775807, 1);  slice_backward_default_232 = None
        slice_backward_default_234 = torch.ops.aten.slice_backward.default(slice_backward_default_233, [24, 4, 256, 769], 0, 0, 9223372036854775807, 1);  slice_backward_default_233 = None
        view_default_790 = torch.ops.aten.view.default(slice_backward_default_234, [24, 4, 196864]);  slice_backward_default_234 = None
        slice_backward_default_235 = torch.ops.aten.slice_backward.default(view_default_790, [24, 4, 197120], 2, 0, -256, 1);  view_default_790 = None
        slice_backward_default_236 = torch.ops.aten.slice_backward.default(slice_backward_default_235, [24, 4, 197120], 1, 0, 9223372036854775807, 1);  slice_backward_default_235 = None
        slice_backward_default_237 = torch.ops.aten.slice_backward.default(slice_backward_default_236, [24, 4, 197120], 0, 0, 9223372036854775807, 1);  slice_backward_default_236 = None
        view_default_791 = torch.ops.aten.view.default(slice_backward_default_237, [24, 4, 256, 770]);  slice_backward_default_237 = None
        constant_pad_nd_default_81 = torch.ops.aten.constant_pad_nd.default(view_default_791, [0, -257]);  view_default_791 = None
        new_empty_default_104 = torch.ops.aten.new_empty.default(squeeze_dim_68, [2359296])
        zero__default_77 = torch.ops.aten.zero_.default(new_empty_default_104);  new_empty_default_104 = None
        arange_33 = torch.ops.aten.arange.start(0, 2359296, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_225 = torch.ops.aten.as_strided.default(arange_33, [24, 4, 768, 64], [98304, 16384, 64, 1], 0);  arange_33 = None
        clone_default_252 = torch.ops.aten.clone.default(as_strided_default_225, memory_format = torch.contiguous_format);  as_strided_default_225 = None
        _unsafe_view_default_223 = torch.ops.aten._unsafe_view.default(clone_default_252, [4718592]);  clone_default_252 = None
        view_default_792 = torch.ops.aten.view.default(squeeze_dim_68, [4718592]);  squeeze_dim_68 = None
        index_add__default_33 = torch.ops.aten.index_add_.default(zero__default_77, 0, _unsafe_view_default_223, view_default_792);  zero__default_77 = _unsafe_view_default_223 = view_default_792 = None
        as_strided_default_226 = torch.ops.aten.as_strided.default(index_add__default_33, [24, 1536, 64], [98304, 64, 1], 0);  index_add__default_33 = None
        constant_pad_nd_default_82 = torch.ops.aten.constant_pad_nd.default(as_strided_default_226, [0, 0, -256, -256]);  as_strided_default_226 = None
        view_default_793 = torch.ops.aten.view.default(constant_pad_nd_default_82, [2, 12, 1024, 64]);  constant_pad_nd_default_82 = None
        transpose_int_350 = torch.ops.aten.transpose.int(view_default_793, 1, 2);  view_default_793 = None
        view_default_794 = torch.ops.aten.view.default(constant_pad_nd_default_81, [2, 12, 1024, 513]);  constant_pad_nd_default_81 = None
        transpose_int_351 = torch.ops.aten.transpose.int(view_default_794, 1, 2);  view_default_794 = None
        transpose_int_352 = torch.ops.aten.transpose.int(transpose_int_350, 0, 1);  transpose_int_350 = None
        clone_default_253 = torch.ops.aten.clone.default(transpose_int_352, memory_format = torch.contiguous_format);  transpose_int_352 = None
        _unsafe_view_default_224 = torch.ops.aten._unsafe_view.default(clone_default_253, [1024, 2, 768]);  clone_default_253 = None
        where_scalar_self_57 = torch.ops.aten.where.ScalarSelf(unsqueeze_default_11, 0.0, transpose_int_351);  unsqueeze_default_11 = transpose_int_351 = None
        _softmax_backward_data_default_11 = torch.ops.aten._softmax_backward_data.default(where_scalar_self_57, _softmax_default, -1, torch.float32);  where_scalar_self_57 = _softmax_default = None
        new_empty_default_105 = torch.ops.aten.new_empty.default(_softmax_backward_data_default_11, [12607488])
        zero__default_78 = torch.ops.aten.zero_.default(new_empty_default_105);  new_empty_default_105 = None
        as_strided_default_227 = torch.ops.aten.as_strided.default(zero__default_78, [2, 1024, 12, 513], [6303744, 513, 525312, 1], 0)
        copy__default_250 = torch.ops.aten.copy_.default(as_strided_default_227, _softmax_backward_data_default_11);  as_strided_default_227 = _softmax_backward_data_default_11 = None
        as_strided_default_228 = torch.ops.aten.as_strided.default(zero__default_78, [24, 4, 256, 513], [525312, 131328, 513, 1], 0);  zero__default_78 = None
        new_empty_strided_default_77 = torch.ops.aten.new_empty_strided.default(as_strided_default_228, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_251 = torch.ops.aten.copy_.default(new_empty_strided_default_77, as_strided_default_228);  new_empty_strided_default_77 = as_strided_default_228 = None
        as_strided_default_229 = torch.ops.aten.as_strided.default(copy__default_251, [2, 1024, 12, 513], [6303744, 513, 525312, 1], 0)
        clone_default_254 = torch.ops.aten.clone.default(as_strided_default_229, memory_format = torch.contiguous_format)
        copy__default_252 = torch.ops.aten.copy_.default(as_strided_default_229, clone_default_254);  as_strided_default_229 = clone_default_254 = None
        new_empty_strided_default_78 = torch.ops.aten.new_empty_strided.default(copy__default_251, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_253 = torch.ops.aten.copy_.default(new_empty_strided_default_78, copy__default_251);  new_empty_strided_default_78 = copy__default_251 = None
        as_strided_default_230 = torch.ops.aten.as_strided.default(copy__default_253, [2, 256, 12, 257], [6303744, 513, 525312, 1], 394240)
        clone_default_255 = torch.ops.aten.clone.default(as_strided_default_230, memory_format = torch.contiguous_format)
        where_scalar_self_58 = torch.ops.aten.where.ScalarSelf(eq_scalar_1, 0.0, clone_default_255);  eq_scalar_1 = clone_default_255 = None
        copy__default_254 = torch.ops.aten.copy_.default(as_strided_default_230, where_scalar_self_58);  as_strided_default_230 = where_scalar_self_58 = None
        new_empty_strided_default_79 = torch.ops.aten.new_empty_strided.default(copy__default_253, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_255 = torch.ops.aten.copy_.default(new_empty_strided_default_79, copy__default_253);  new_empty_strided_default_79 = copy__default_253 = None
        as_strided_default_231 = torch.ops.aten.as_strided.default(copy__default_255, [2, 256, 12, 257], [6303744, 513, 525312, 1], 0)
        clone_default_256 = torch.ops.aten.clone.default(as_strided_default_231, memory_format = torch.contiguous_format)
        where_scalar_self_59 = torch.ops.aten.where.ScalarSelf(eq_scalar, 0.0, clone_default_256);  eq_scalar = clone_default_256 = None
        copy__default_256 = torch.ops.aten.copy_.default(as_strided_default_231, where_scalar_self_59);  as_strided_default_231 = where_scalar_self_59 = None
        new_empty_strided_default_80 = torch.ops.aten.new_empty_strided.default(copy__default_255, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_257 = torch.ops.aten.copy_.default(new_empty_strided_default_80, copy__default_255);  new_empty_strided_default_80 = copy__default_255 = None
        as_strided_default_232 = torch.ops.aten.as_strided.default(copy__default_257, [24, 255, 255], [525312, 513, 1], 514)
        clone_default_257 = torch.ops.aten.clone.default(as_strided_default_232, memory_format = torch.contiguous_format)
        empty_like_default_33 = torch.ops.aten.empty_like.default(clone_default_257, memory_format = torch.contiguous_format)
        zero__default_79 = torch.ops.aten.zero_.default(empty_like_default_33);  empty_like_default_33 = None
        copy__default_258 = torch.ops.aten.copy_.default(as_strided_default_232, zero__default_79);  as_strided_default_232 = zero__default_79 = None
        slice_backward_default_238 = torch.ops.aten.slice_backward.default(clone_default_257, [24, 255, 513], 2, -255, 9223372036854775807, 1);  clone_default_257 = None
        slice_backward_default_239 = torch.ops.aten.slice_backward.default(slice_backward_default_238, [24, 512, 513], 1, 0, 255, 1);  slice_backward_default_238 = None
        select_backward_default_22 = torch.ops.aten.select_backward.default(slice_backward_default_239, [24, 3, 512, 513], 1, 0);  slice_backward_default_239 = None
        slice_backward_default_240 = torch.ops.aten.slice_backward.default(select_backward_default_22, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_22 = None
        new_empty_strided_default_81 = torch.ops.aten.new_empty_strided.default(copy__default_257, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_259 = torch.ops.aten.copy_.default(new_empty_strided_default_81, copy__default_257);  new_empty_strided_default_81 = copy__default_257 = None
        as_strided_default_233 = torch.ops.aten.as_strided.default(copy__default_259, [24, 3, 256, 256], [525312, 131328, 513, 1], 131328)
        clone_default_258 = torch.ops.aten.clone.default(as_strided_default_233, memory_format = torch.contiguous_format)
        empty_like_default_34 = torch.ops.aten.empty_like.default(clone_default_258, memory_format = torch.contiguous_format)
        zero__default_80 = torch.ops.aten.zero_.default(empty_like_default_34);  empty_like_default_34 = None
        copy__default_260 = torch.ops.aten.copy_.default(as_strided_default_233, zero__default_80);  as_strided_default_233 = zero__default_80 = None
        slice_backward_default_241 = torch.ops.aten.slice_backward.default(clone_default_258, [24, 3, 256, 513], 3, 257, 9223372036854775807, 1);  clone_default_258 = None
        slice_backward_default_242 = torch.ops.aten.slice_backward.default(slice_backward_default_241, [24, 3, 512, 513], 2, -257, -1, 1);  slice_backward_default_241 = None
        slice_backward_default_243 = torch.ops.aten.slice_backward.default(slice_backward_default_242, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_242 = None
        slice_backward_default_244 = torch.ops.aten.slice_backward.default(slice_backward_default_243, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_243 = None
        add_tensor_174 = torch.ops.aten.add.Tensor(slice_backward_default_240, slice_backward_default_244);  slice_backward_default_240 = slice_backward_default_244 = None
        new_empty_strided_default_82 = torch.ops.aten.new_empty_strided.default(copy__default_259, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_261 = torch.ops.aten.copy_.default(new_empty_strided_default_82, copy__default_259);  new_empty_strided_default_82 = copy__default_259 = None
        as_strided_default_234 = torch.ops.aten.as_strided.default(copy__default_261, [24, 256, 257], [525312, 513, 1], 394240)
        clone_default_259 = torch.ops.aten.clone.default(as_strided_default_234, memory_format = torch.contiguous_format)
        empty_like_default_35 = torch.ops.aten.empty_like.default(clone_default_259, memory_format = torch.contiguous_format)
        zero__default_81 = torch.ops.aten.zero_.default(empty_like_default_35);  empty_like_default_35 = None
        copy__default_262 = torch.ops.aten.copy_.default(as_strided_default_234, zero__default_81);  as_strided_default_234 = zero__default_81 = None
        slice_backward_default_245 = torch.ops.aten.slice_backward.default(clone_default_259, [24, 256, 513], 2, 0, 257, 1);  clone_default_259 = None
        slice_backward_default_246 = torch.ops.aten.slice_backward.default(slice_backward_default_245, [24, 512, 513], 1, 256, 9223372036854775807, 1);  slice_backward_default_245 = None
        select_backward_default_23 = torch.ops.aten.select_backward.default(slice_backward_default_246, [24, 3, 512, 513], 1, -1);  slice_backward_default_246 = None
        slice_backward_default_247 = torch.ops.aten.slice_backward.default(select_backward_default_23, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  select_backward_default_23 = None
        add_tensor_175 = torch.ops.aten.add.Tensor(add_tensor_174, slice_backward_default_247);  add_tensor_174 = slice_backward_default_247 = None
        new_empty_strided_default_83 = torch.ops.aten.new_empty_strided.default(copy__default_261, [24, 4, 256, 513], [525312, 131328, 513, 1])
        copy__default_263 = torch.ops.aten.copy_.default(new_empty_strided_default_83, copy__default_261);  new_empty_strided_default_83 = copy__default_261 = None
        as_strided_default_235 = torch.ops.aten.as_strided.default(copy__default_263, [24, 3, 256, 257], [525312, 131328, 513, 1], 256);  copy__default_263 = None
        clone_default_260 = torch.ops.aten.clone.default(as_strided_default_235, memory_format = torch.contiguous_format);  as_strided_default_235 = None
        slice_backward_default_248 = torch.ops.aten.slice_backward.default(clone_default_260, [24, 3, 256, 513], 3, 0, 257, 1);  clone_default_260 = None
        slice_backward_default_249 = torch.ops.aten.slice_backward.default(slice_backward_default_248, [24, 3, 512, 513], 2, 0, 256, 1);  slice_backward_default_248 = None
        slice_backward_default_250 = torch.ops.aten.slice_backward.default(slice_backward_default_249, [24, 3, 512, 513], 1, 0, 9223372036854775807, 1);  slice_backward_default_249 = None
        slice_backward_default_251 = torch.ops.aten.slice_backward.default(slice_backward_default_250, [24, 3, 512, 513], 0, 0, 9223372036854775807, 1);  slice_backward_default_250 = None
        add_tensor_176 = torch.ops.aten.add.Tensor(add_tensor_175, slice_backward_default_251);  add_tensor_175 = slice_backward_default_251 = None
        view_default_795 = torch.ops.aten.view.default(add_tensor_176, [24, 3, 513, 512]);  add_tensor_176 = None
        constant_pad_nd_default_83 = torch.ops.aten.constant_pad_nd.default(view_default_795, [0, 0, 0, -1]);  view_default_795 = None
        view_default_796 = torch.ops.aten.view.default(constant_pad_nd_default_83, [24, 3, 512, 512, 1]);  constant_pad_nd_default_83 = None
        permute_default_259 = torch.ops.aten.permute.default(view_default_796, [0, 1, 2, 4, 3]);  view_default_796 = None
        view_default_797 = torch.ops.aten.view.default(permute_default_259, [72, 512, 512]);  permute_default_259 = None
        transpose_int_353 = torch.ops.aten.transpose.int(_unsafe_view_default_6, 1, 2);  _unsafe_view_default_6 = None
        bmm_default_70 = torch.ops.aten.bmm.default(transpose_int_353, view_default_797);  transpose_int_353 = None
        transpose_int_354 = torch.ops.aten.transpose.int(_unsafe_view_default_7, 1, 2);  _unsafe_view_default_7 = None
        bmm_default_71 = torch.ops.aten.bmm.default(view_default_797, transpose_int_354);  view_default_797 = transpose_int_354 = None
        view_default_798 = torch.ops.aten.view.default(bmm_default_70, [24, 3, 64, 512, 1]);  bmm_default_70 = None
        permute_default_260 = torch.ops.aten.permute.default(view_default_798, [0, 1, 4, 3, 2]);  view_default_798 = None
        view_default_799 = torch.ops.aten.view.default(bmm_default_71, [24, 3, 512, 64, 1]);  bmm_default_71 = None
        permute_default_261 = torch.ops.aten.permute.default(view_default_799, [0, 1, 2, 4, 3]);  view_default_799 = None
        permute_default_262 = torch.ops.aten.permute.default(permute_default_260, [0, 1, 3, 4, 2]);  permute_default_260 = None
        squeeze_dim_70 = torch.ops.aten.squeeze.dim(permute_default_262, -1);  permute_default_262 = None
        permute_default_263 = torch.ops.aten.permute.default(permute_default_261, [0, 1, 2, 4, 3]);  permute_default_261 = None
        squeeze_dim_71 = torch.ops.aten.squeeze.dim(permute_default_263, -1);  permute_default_263 = None
        new_empty_default_106 = torch.ops.aten.new_empty.default(squeeze_dim_70, [1572864])
        zero__default_82 = torch.ops.aten.zero_.default(new_empty_default_106);  new_empty_default_106 = None
        arange_34 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_236 = torch.ops.aten.as_strided.default(arange_34, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_34 = None
        clone_default_261 = torch.ops.aten.clone.default(as_strided_default_236, memory_format = torch.contiguous_format);  as_strided_default_236 = None
        _unsafe_view_default_225 = torch.ops.aten._unsafe_view.default(clone_default_261, [2359296]);  clone_default_261 = None
        clone_default_262 = torch.ops.aten.clone.default(squeeze_dim_70, memory_format = torch.contiguous_format);  squeeze_dim_70 = None
        _unsafe_view_default_226 = torch.ops.aten._unsafe_view.default(clone_default_262, [2359296]);  clone_default_262 = None
        index_add__default_34 = torch.ops.aten.index_add_.default(zero__default_82, 0, _unsafe_view_default_225, _unsafe_view_default_226);  zero__default_82 = _unsafe_view_default_225 = _unsafe_view_default_226 = None
        as_strided_default_237 = torch.ops.aten.as_strided.default(index_add__default_34, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_34 = None
        view_default_800 = torch.ops.aten.view.default(as_strided_default_237, [24, 1024, 64]);  as_strided_default_237 = None
        new_empty_default_107 = torch.ops.aten.new_empty.default(squeeze_dim_71, [1572864])
        zero__default_83 = torch.ops.aten.zero_.default(new_empty_default_107);  new_empty_default_107 = None
        arange_35 = torch.ops.aten.arange.start(0, 1572864, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0))
        as_strided_default_238 = torch.ops.aten.as_strided.default(arange_35, [24, 3, 512, 64], [64, 393216, 1536, 1], 0);  arange_35 = None
        clone_default_263 = torch.ops.aten.clone.default(as_strided_default_238, memory_format = torch.contiguous_format);  as_strided_default_238 = None
        _unsafe_view_default_227 = torch.ops.aten._unsafe_view.default(clone_default_263, [2359296]);  clone_default_263 = None
        view_default_801 = torch.ops.aten.view.default(squeeze_dim_71, [2359296]);  squeeze_dim_71 = None
        index_add__default_35 = torch.ops.aten.index_add_.default(zero__default_83, 0, _unsafe_view_default_227, view_default_801);  zero__default_83 = _unsafe_view_default_227 = view_default_801 = None
        as_strided_default_239 = torch.ops.aten.as_strided.default(index_add__default_35, [24, 2, 512, 64], [64, 786432, 1536, 1], 0);  index_add__default_35 = None
        view_default_802 = torch.ops.aten.view.default(as_strided_default_239, [24, 1024, 64]);  as_strided_default_239 = None
        view_default_803 = torch.ops.aten.view.default(view_default_800, [2, 12, 1024, 64]);  view_default_800 = None
        transpose_int_355 = torch.ops.aten.transpose.int(view_default_803, 1, 2);  view_default_803 = None
        view_default_804 = torch.ops.aten.view.default(view_default_802, [2, 12, 1024, 64]);  view_default_802 = None
        transpose_int_356 = torch.ops.aten.transpose.int(view_default_804, 1, 2);  view_default_804 = None
        transpose_int_357 = torch.ops.aten.transpose.int(transpose_int_355, 0, 1);  transpose_int_355 = None
        view_default_805 = torch.ops.aten.view.default(transpose_int_357, [1024, 2, 768]);  transpose_int_357 = None
        transpose_int_358 = torch.ops.aten.transpose.int(transpose_int_356, 0, 1);  transpose_int_356 = None
        view_default_806 = torch.ops.aten.view.default(transpose_int_358, [1024, 2, 768]);  transpose_int_358 = None
        div_tensor_11 = torch.ops.aten.div.Tensor(view_default_806, 8.0);  view_default_806 = None
        sum_dim_int_list_69 = torch.ops.aten.sum.dim_IntList(_unsafe_view_default_224, [0, 1], True)
        view_default_807 = torch.ops.aten.view.default(sum_dim_int_list_69, [768]);  sum_dim_int_list_69 = None
        view_default_808 = torch.ops.aten.view.default(_unsafe_view_default_224, [2048, 768]);  _unsafe_view_default_224 = None
        t_default_348 = torch.ops.aten.t.default(view_default_808)
        mm_default_186 = torch.ops.aten.mm.default(t_default_348, _unsafe_view_default_4);  t_default_348 = _unsafe_view_default_4 = None
        t_default_349 = torch.ops.aten.t.default(mm_default_186);  mm_default_186 = None
        t_default_350 = torch.ops.aten.t.default(t_default_2);  t_default_2 = None
        mm_default_187 = torch.ops.aten.mm.default(view_default_808, t_default_350);  view_default_808 = t_default_350 = None
        view_default_809 = torch.ops.aten.view.default(mm_default_187, [1024, 2, 768]);  mm_default_187 = None
        t_default_351 = torch.ops.aten.t.default(t_default_349);  t_default_349 = None
        sum_dim_int_list_70 = torch.ops.aten.sum.dim_IntList(view_default_805, [0, 1], True)
        view_default_810 = torch.ops.aten.view.default(sum_dim_int_list_70, [768]);  sum_dim_int_list_70 = None
        view_default_811 = torch.ops.aten.view.default(view_default_805, [2048, 768]);  view_default_805 = None
        t_default_352 = torch.ops.aten.t.default(view_default_811)
        mm_default_188 = torch.ops.aten.mm.default(t_default_352, _unsafe_view_default_2);  t_default_352 = _unsafe_view_default_2 = None
        t_default_353 = torch.ops.aten.t.default(mm_default_188);  mm_default_188 = None
        t_default_354 = torch.ops.aten.t.default(t_default_1);  t_default_1 = None
        mm_default_189 = torch.ops.aten.mm.default(view_default_811, t_default_354);  view_default_811 = t_default_354 = None
        view_default_812 = torch.ops.aten.view.default(mm_default_189, [1024, 2, 768]);  mm_default_189 = None
        add_tensor_177 = torch.ops.aten.add.Tensor(view_default_809, view_default_812);  view_default_809 = view_default_812 = None
        t_default_355 = torch.ops.aten.t.default(t_default_353);  t_default_353 = None
        sum_dim_int_list_71 = torch.ops.aten.sum.dim_IntList(div_tensor_11, [0, 1], True)
        view_default_813 = torch.ops.aten.view.default(sum_dim_int_list_71, [768]);  sum_dim_int_list_71 = None
        view_default_814 = torch.ops.aten.view.default(div_tensor_11, [2048, 768]);  div_tensor_11 = None
        t_default_356 = torch.ops.aten.t.default(view_default_814)
        mm_default_190 = torch.ops.aten.mm.default(t_default_356, _unsafe_view_default);  t_default_356 = _unsafe_view_default = None
        t_default_357 = torch.ops.aten.t.default(mm_default_190);  mm_default_190 = None
        t_default_358 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default_191 = torch.ops.aten.mm.default(view_default_814, t_default_358);  view_default_814 = t_default_358 = None
        view_default_815 = torch.ops.aten.view.default(mm_default_191, [1024, 2, 768]);  mm_default_191 = None
        add_tensor_178 = torch.ops.aten.add.Tensor(add_tensor_177, view_default_815);  add_tensor_177 = view_default_815 = None
        t_default_359 = torch.ops.aten.t.default(t_default_357);  t_default_357 = None
        transpose_int_359 = torch.ops.aten.transpose.int(add_tensor_178, 0, 1);  add_tensor_178 = None
        add_tensor_179 = torch.ops.aten.add.Tensor(getitem_141, transpose_int_359);  getitem_141 = transpose_int_359 = None
        return [getitem_69, getitem_143, getitem_142, view_default_782, t_default_347, view_default_810, t_default_355, view_default_813, t_default_359, view_default_807, t_default_351, view_default_780, t_default_343, getitem_140, getitem_139, view_default_777, t_default_339, getitem_83, getitem_82, view_default_382, t_default_107, view_default_410, t_default_115, view_default_413, t_default_119, view_default_407, t_default_111, view_default_380, t_default_103, getitem_80, getitem_79, view_default_377, t_default_99, getitem_77, getitem_76, view_default_342, t_default_83, view_default_370, t_default_91, view_default_373, t_default_95, view_default_367, t_default_87, view_default_340, t_default_79, getitem_74, getitem_73, view_default_337, t_default_75, getitem_137, getitem_136, view_default_742, t_default_323, view_default_770, t_default_331, view_default_773, t_default_335, view_default_767, t_default_327, view_default_740, t_default_319, getitem_134, getitem_133, view_default_737, t_default_315, getitem_131, getitem_130, view_default_702, t_default_299, view_default_730, t_default_307, view_default_733, t_default_311, view_default_727, t_default_303, view_default_700, t_default_295, getitem_128, getitem_127, view_default_697, t_default_291, getitem_125, getitem_124, view_default_662, t_default_275, view_default_690, t_default_283, view_default_693, t_default_287, view_default_687, t_default_279, view_default_660, t_default_271, getitem_122, getitem_121, view_default_657, t_default_267, getitem_119, getitem_118, view_default_622, t_default_251, view_default_650, t_default_259, view_default_653, t_default_263, view_default_647, t_default_255, view_default_620, t_default_247, getitem_116, getitem_115, view_default_617, t_default_243, getitem_113, getitem_112, view_default_582, t_default_227, view_default_610, t_default_235, view_default_613, t_default_239, view_default_607, t_default_231, view_default_580, t_default_223, getitem_110, getitem_109, view_default_577, t_default_219, getitem_107, getitem_106, view_default_542, t_default_203, view_default_570, t_default_211, view_default_573, t_default_215, view_default_567, t_default_207, view_default_540, t_default_199, getitem_104, getitem_103, view_default_537, t_default_195, getitem_101, getitem_100, view_default_502, t_default_179, view_default_530, t_default_187, view_default_533, t_default_191, view_default_527, t_default_183, view_default_500, t_default_175, getitem_98, getitem_97, view_default_497, t_default_171, getitem_95, getitem_94, view_default_462, t_default_155, view_default_490, t_default_163, view_default_493, t_default_167, view_default_487, t_default_159, view_default_460, t_default_151, getitem_92, getitem_91, view_default_457, t_default_147, getitem_89, getitem_88, view_default_422, t_default_131, view_default_450, t_default_139, view_default_453, t_default_143, view_default_447, t_default_135, view_default_420, t_default_127, getitem_86, getitem_85, view_default_417, t_default_123, add_tensor_179, None, None]
        
