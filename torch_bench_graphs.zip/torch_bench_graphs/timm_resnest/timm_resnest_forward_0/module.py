
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/timm_resnest/timm_resnest_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153):
        convolution_default = torch.ops.aten.convolution.default(primals_153, primals_6, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_11, primals_7, primals_9, primals_10, False, 0.1, 1e-05);  primals_7 = None
        getitem = native_batch_norm_default[0];  native_batch_norm_default = None
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default, primals_12, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_17, primals_13, primals_15, primals_16, False, 0.1, 1e-05);  primals_13 = None
        getitem_3 = native_batch_norm_default_1[0];  native_batch_norm_default_1 = None
        relu__default_1 = torch.ops.aten.relu_.default(getitem_3);  getitem_3 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_18, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_5, primals_1, primals_3, primals_4, False, 0.1, 1e-05);  primals_1 = None
        getitem_6 = native_batch_norm_default_2[0];  native_batch_norm_default_2 = None
        relu__default_2 = torch.ops.aten.relu_.default(getitem_6);  getitem_6 = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu__default_2, [3, 3], [2, 2], [1, 1])
        getitem_9 = max_pool2d_with_indices_default[0]
        getitem_10 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_3 = torch.ops.aten.convolution.default(getitem_9, primals_31, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_25, primals_21, primals_23, primals_24, False, 0.1, 1e-05);  primals_21 = None
        getitem_11 = native_batch_norm_default_3[0];  native_batch_norm_default_3 = None
        relu__default_3 = torch.ops.aten.relu_.default(getitem_11);  getitem_11 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu__default_3, primals_42, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_36, primals_32, primals_34, primals_35, False, 0.1, 1e-05);  primals_32 = None
        getitem_14 = native_batch_norm_default_4[0];  native_batch_norm_default_4 = None
        relu__default_4 = torch.ops.aten.relu_.default(getitem_14);  getitem_14 = None
        view_default = torch.ops.aten.view.default(relu__default_4, [32, 2, 64, 56, 56])
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(view_default, [1])
        mean_dim = torch.ops.aten.mean.dim(sum_dim_int_list, [2, 3], True);  sum_dim_int_list = None
        convolution_default_5 = torch.ops.aten.convolution.default(mean_dim, primals_44, primals_43, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_43 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_41, primals_37, primals_39, primals_40, False, 0.1, 1e-05);  primals_37 = None
        getitem_17 = native_batch_norm_default_5[0];  native_batch_norm_default_5 = None
        relu__default_5 = torch.ops.aten.relu_.default(getitem_17);  getitem_17 = None
        convolution_default_6 = torch.ops.aten.convolution.default(relu__default_5, primals_46, primals_45, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_45 = None
        view_default_1 = torch.ops.aten.view.default(convolution_default_6, [32, 1, 2, -1]);  convolution_default_6 = None
        transpose_int = torch.ops.aten.transpose.int(view_default_1, 1, 2);  view_default_1 = None
        _softmax_default = torch.ops.aten._softmax.default(transpose_int, 1, False);  transpose_int = None
        view_default_2 = torch.ops.aten.view.default(_softmax_default, [32, 128])
        view_default_3 = torch.ops.aten.view.default(view_default_2, [32, -1, 1, 1]);  view_default_2 = None
        view_default_4 = torch.ops.aten.view.default(view_default_3, [32, 2, 64, 1, 1]);  view_default_3 = None
        mul_tensor = torch.ops.aten.mul.Tensor(view_default, view_default_4)
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(mul_tensor, [1]);  mul_tensor = None
        convolution_default_7 = torch.ops.aten.convolution.default(sum_dim_int_list_1, primals_47, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_30, primals_26, primals_28, primals_29, False, 0.1, 1e-05);  primals_26 = None
        getitem_20 = native_batch_norm_default_6[0];  native_batch_norm_default_6 = None
        convolution_default_8 = torch.ops.aten.convolution.default(getitem_9, primals_48, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_53, primals_49, primals_51, primals_52, False, 0.1, 1e-05);  primals_49 = None
        getitem_23 = native_batch_norm_default_7[0];  native_batch_norm_default_7 = None
        add__tensor = torch.ops.aten.add_.Tensor(getitem_20, getitem_23);  getitem_20 = getitem_23 = None
        relu__default_6 = torch.ops.aten.relu_.default(add__tensor);  add__tensor = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_6, primals_64, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_58, primals_54, primals_56, primals_57, False, 0.1, 1e-05);  primals_54 = None
        getitem_26 = native_batch_norm_default_8[0];  native_batch_norm_default_8 = None
        relu__default_7 = torch.ops.aten.relu_.default(getitem_26);  getitem_26 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default_7, primals_75, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_69, primals_65, primals_67, primals_68, False, 0.1, 1e-05);  primals_65 = None
        getitem_29 = native_batch_norm_default_9[0];  native_batch_norm_default_9 = None
        relu__default_8 = torch.ops.aten.relu_.default(getitem_29);  getitem_29 = None
        view_default_5 = torch.ops.aten.view.default(relu__default_8, [32, 2, 128, 56, 56])
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(view_default_5, [1])
        mean_dim_1 = torch.ops.aten.mean.dim(sum_dim_int_list_2, [2, 3], True);  sum_dim_int_list_2 = None
        convolution_default_11 = torch.ops.aten.convolution.default(mean_dim_1, primals_77, primals_76, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_76 = None
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_74, primals_70, primals_72, primals_73, False, 0.1, 1e-05);  primals_70 = None
        getitem_32 = native_batch_norm_default_10[0];  native_batch_norm_default_10 = None
        relu__default_9 = torch.ops.aten.relu_.default(getitem_32);  getitem_32 = None
        convolution_default_12 = torch.ops.aten.convolution.default(relu__default_9, primals_79, primals_78, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_78 = None
        view_default_6 = torch.ops.aten.view.default(convolution_default_12, [32, 1, 2, -1]);  convolution_default_12 = None
        transpose_int_1 = torch.ops.aten.transpose.int(view_default_6, 1, 2);  view_default_6 = None
        _softmax_default_1 = torch.ops.aten._softmax.default(transpose_int_1, 1, False);  transpose_int_1 = None
        view_default_7 = torch.ops.aten.view.default(_softmax_default_1, [32, 256])
        view_default_8 = torch.ops.aten.view.default(view_default_7, [32, -1, 1, 1]);  view_default_7 = None
        view_default_9 = torch.ops.aten.view.default(view_default_8, [32, 2, 128, 1, 1]);  view_default_8 = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(view_default_5, view_default_9)
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(mul_tensor_1, [1]);  mul_tensor_1 = None
        avg_pool2d_default = torch.ops.aten.avg_pool2d.default(sum_dim_int_list_3, [3, 3], [2, 2], [1, 1])
        convolution_default_13 = torch.ops.aten.convolution.default(avg_pool2d_default, primals_80, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_63, primals_59, primals_61, primals_62, False, 0.1, 1e-05);  primals_59 = None
        getitem_35 = native_batch_norm_default_11[0];  native_batch_norm_default_11 = None
        avg_pool2d_default_1 = torch.ops.aten.avg_pool2d.default(relu__default_6, [2, 2], [2, 2], [0, 0], True, False)
        convolution_default_14 = torch.ops.aten.convolution.default(avg_pool2d_default_1, primals_81, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_86, primals_82, primals_84, primals_85, False, 0.1, 1e-05);  primals_82 = None
        getitem_38 = native_batch_norm_default_12[0];  native_batch_norm_default_12 = None
        add__tensor_1 = torch.ops.aten.add_.Tensor(getitem_35, getitem_38);  getitem_35 = getitem_38 = None
        relu__default_10 = torch.ops.aten.relu_.default(add__tensor_1);  add__tensor_1 = None
        convolution_default_15 = torch.ops.aten.convolution.default(relu__default_10, primals_97, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_91, primals_87, primals_89, primals_90, False, 0.1, 1e-05);  primals_87 = None
        getitem_41 = native_batch_norm_default_13[0];  native_batch_norm_default_13 = None
        relu__default_11 = torch.ops.aten.relu_.default(getitem_41);  getitem_41 = None
        convolution_default_16 = torch.ops.aten.convolution.default(relu__default_11, primals_108, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_102, primals_98, primals_100, primals_101, False, 0.1, 1e-05);  primals_98 = None
        getitem_44 = native_batch_norm_default_14[0];  native_batch_norm_default_14 = None
        relu__default_12 = torch.ops.aten.relu_.default(getitem_44);  getitem_44 = None
        view_default_10 = torch.ops.aten.view.default(relu__default_12, [32, 2, 256, 28, 28])
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(view_default_10, [1])
        mean_dim_2 = torch.ops.aten.mean.dim(sum_dim_int_list_4, [2, 3], True);  sum_dim_int_list_4 = None
        convolution_default_17 = torch.ops.aten.convolution.default(mean_dim_2, primals_110, primals_109, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_109 = None
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_107, primals_103, primals_105, primals_106, False, 0.1, 1e-05);  primals_103 = None
        getitem_47 = native_batch_norm_default_15[0];  native_batch_norm_default_15 = None
        relu__default_13 = torch.ops.aten.relu_.default(getitem_47);  getitem_47 = None
        convolution_default_18 = torch.ops.aten.convolution.default(relu__default_13, primals_112, primals_111, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_111 = None
        view_default_11 = torch.ops.aten.view.default(convolution_default_18, [32, 1, 2, -1]);  convolution_default_18 = None
        transpose_int_2 = torch.ops.aten.transpose.int(view_default_11, 1, 2);  view_default_11 = None
        _softmax_default_2 = torch.ops.aten._softmax.default(transpose_int_2, 1, False);  transpose_int_2 = None
        view_default_12 = torch.ops.aten.view.default(_softmax_default_2, [32, 512])
        view_default_13 = torch.ops.aten.view.default(view_default_12, [32, -1, 1, 1]);  view_default_12 = None
        view_default_14 = torch.ops.aten.view.default(view_default_13, [32, 2, 256, 1, 1]);  view_default_13 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(view_default_10, view_default_14)
        sum_dim_int_list_5 = torch.ops.aten.sum.dim_IntList(mul_tensor_2, [1]);  mul_tensor_2 = None
        avg_pool2d_default_2 = torch.ops.aten.avg_pool2d.default(sum_dim_int_list_5, [3, 3], [2, 2], [1, 1])
        convolution_default_19 = torch.ops.aten.convolution.default(avg_pool2d_default_2, primals_113, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_96, primals_92, primals_94, primals_95, False, 0.1, 1e-05);  primals_92 = None
        getitem_50 = native_batch_norm_default_16[0];  native_batch_norm_default_16 = None
        avg_pool2d_default_3 = torch.ops.aten.avg_pool2d.default(relu__default_10, [2, 2], [2, 2], [0, 0], True, False)
        convolution_default_20 = torch.ops.aten.convolution.default(avg_pool2d_default_3, primals_114, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_119, primals_115, primals_117, primals_118, False, 0.1, 1e-05);  primals_115 = None
        getitem_53 = native_batch_norm_default_17[0];  native_batch_norm_default_17 = None
        add__tensor_2 = torch.ops.aten.add_.Tensor(getitem_50, getitem_53);  getitem_50 = getitem_53 = None
        relu__default_14 = torch.ops.aten.relu_.default(add__tensor_2);  add__tensor_2 = None
        convolution_default_21 = torch.ops.aten.convolution.default(relu__default_14, primals_130, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_124, primals_120, primals_122, primals_123, False, 0.1, 1e-05);  primals_120 = None
        getitem_56 = native_batch_norm_default_18[0];  native_batch_norm_default_18 = None
        relu__default_15 = torch.ops.aten.relu_.default(getitem_56);  getitem_56 = None
        convolution_default_22 = torch.ops.aten.convolution.default(relu__default_15, primals_141, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_135, primals_131, primals_133, primals_134, False, 0.1, 1e-05);  primals_131 = None
        getitem_59 = native_batch_norm_default_19[0];  native_batch_norm_default_19 = None
        relu__default_16 = torch.ops.aten.relu_.default(getitem_59);  getitem_59 = None
        view_default_15 = torch.ops.aten.view.default(relu__default_16, [32, 2, 512, 14, 14])
        sum_dim_int_list_6 = torch.ops.aten.sum.dim_IntList(view_default_15, [1])
        mean_dim_3 = torch.ops.aten.mean.dim(sum_dim_int_list_6, [2, 3], True);  sum_dim_int_list_6 = None
        convolution_default_23 = torch.ops.aten.convolution.default(mean_dim_3, primals_143, primals_142, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_142 = None
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_140, primals_136, primals_138, primals_139, False, 0.1, 1e-05);  primals_136 = None
        getitem_62 = native_batch_norm_default_20[0];  native_batch_norm_default_20 = None
        relu__default_17 = torch.ops.aten.relu_.default(getitem_62);  getitem_62 = None
        convolution_default_24 = torch.ops.aten.convolution.default(relu__default_17, primals_145, primals_144, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_144 = None
        view_default_16 = torch.ops.aten.view.default(convolution_default_24, [32, 1, 2, -1]);  convolution_default_24 = None
        transpose_int_3 = torch.ops.aten.transpose.int(view_default_16, 1, 2);  view_default_16 = None
        _softmax_default_3 = torch.ops.aten._softmax.default(transpose_int_3, 1, False);  transpose_int_3 = None
        view_default_17 = torch.ops.aten.view.default(_softmax_default_3, [32, 1024])
        view_default_18 = torch.ops.aten.view.default(view_default_17, [32, -1, 1, 1]);  view_default_17 = None
        view_default_19 = torch.ops.aten.view.default(view_default_18, [32, 2, 512, 1, 1]);  view_default_18 = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(view_default_15, view_default_19)
        sum_dim_int_list_7 = torch.ops.aten.sum.dim_IntList(mul_tensor_3, [1]);  mul_tensor_3 = None
        avg_pool2d_default_4 = torch.ops.aten.avg_pool2d.default(sum_dim_int_list_7, [3, 3], [2, 2], [1, 1])
        convolution_default_25 = torch.ops.aten.convolution.default(avg_pool2d_default_4, primals_146, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_129, primals_125, primals_127, primals_128, False, 0.1, 1e-05);  primals_125 = None
        getitem_65 = native_batch_norm_default_21[0];  native_batch_norm_default_21 = None
        avg_pool2d_default_5 = torch.ops.aten.avg_pool2d.default(relu__default_14, [2, 2], [2, 2], [0, 0], True, False)
        convolution_default_26 = torch.ops.aten.convolution.default(avg_pool2d_default_5, primals_147, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_152, primals_148, primals_150, primals_151, False, 0.1, 1e-05);  primals_148 = None
        getitem_68 = native_batch_norm_default_22[0];  native_batch_norm_default_22 = None
        add__tensor_3 = torch.ops.aten.add_.Tensor(getitem_65, getitem_68);  getitem_65 = getitem_68 = None
        relu__default_18 = torch.ops.aten.relu_.default(add__tensor_3);  add__tensor_3 = None
        mean_dim_4 = torch.ops.aten.mean.dim(relu__default_18, [-1, -2], True)
        view_default_20 = torch.ops.aten.view.default(mean_dim_4, [32, 2048]);  mean_dim_4 = None
        t_default = torch.ops.aten.t.default(primals_20);  primals_20 = None
        addmm_default = torch.ops.aten.addmm.default(primals_19, view_default_20, t_default);  primals_19 = None
        return [addmm_default, primals_68, relu__default_18, primals_124, avg_pool2d_default_5, primals_84, avg_pool2d_default_4, sum_dim_int_list_7, primals_133, convolution_default_25, primals_96, primals_89, _softmax_default_3, primals_95, primals_74, primals_94, primals_80, view_default_19, primals_128, convolution_default_26, primals_90, primals_69, primals_72, primals_73, primals_135, primals_129, primals_23, primals_130, primals_81, primals_91, primals_138, primals_139, primals_79, primals_75, primals_127, primals_134, primals_77, primals_67, primals_97, primals_140, relu__default, convolution_default_1, primals_112, relu__default_6, primals_113, convolution_default_8, relu__default_1, primals_108, convolution_default_2, primals_114, convolution_default_9, relu__default_7, convolution_default_10, primals_11, relu__default_16, primals_10, convolution_default, primals_18, primals_9, primals_48, primals_46, primals_52, primals_56, primals_41, primals_51, primals_86, primals_64, primals_61, primals_17, primals_12, primals_39, primals_57, convolution_default_23, primals_53, relu__default_17, primals_40, primals_16, mean_dim_3, primals_28, view_default_15, primals_42, primals_63, primals_29, primals_30, primals_62, primals_47, primals_31, primals_44, primals_58, primals_85, primals_15, primals_107, relu__default_2, convolution_default_15, relu__default_11, getitem_9, convolution_default_3, relu__default_3, relu__default_12, getitem_10, convolution_default_16, convolution_default_4, convolution_default_17, primals_106, relu__default_4, avg_pool2d_default_3, convolution_default_20, relu__default_14, sum_dim_int_list_3, avg_pool2d_default, convolution_default_22, convolution_default_13, primals_34, primals_35, _softmax_default_1, view_default_9, primals_36, avg_pool2d_default_1, relu__default_15, convolution_default_21, relu__default_10, convolution_default_14, relu__default_5, primals_141, primals_143, primals_153, primals_145, view_default_20, primals_118, t_default, convolution_default_5, primals_147, primals_119, mean_dim, primals_117, view_default, primals_152, primals_122, primals_123, primals_151, primals_146, primals_110, _softmax_default, view_default_4, primals_150, convolution_default_7, primals_24, sum_dim_int_list_1, primals_102, primals_100, primals_5, primals_101, primals_25, primals_6, primals_4, primals_3, primals_105, relu__default_8, relu__default_13, _softmax_default_2, mean_dim_2, view_default_10, relu__default_9, convolution_default_11, mean_dim_1, convolution_default_19, sum_dim_int_list_5, view_default_5, view_default_14, avg_pool2d_default_2]
        
