
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/timm_resnest/timm_resnest_backward_0/state_dict.pt'))

    
    
    def forward(self, primals_68, relu__default_18, primals_124, avg_pool2d_default_5, primals_84, avg_pool2d_default_4, sum_dim_int_list_7, primals_133, convolution_default_25, primals_96, primals_89, _softmax_default_3, primals_95, primals_74, primals_94, primals_80, view_default_19, primals_128, convolution_default_26, primals_90, primals_69, primals_72, primals_73, primals_135, primals_129, primals_23, primals_130, primals_81, primals_91, primals_138, primals_139, primals_79, primals_75, primals_127, primals_134, primals_77, primals_67, primals_97, primals_140, relu__default, convolution_default_1, primals_112, relu__default_6, primals_113, convolution_default_8, relu__default_1, primals_108, convolution_default_2, primals_114, convolution_default_9, relu__default_7, convolution_default_10, primals_11, relu__default_16, primals_10, convolution_default, primals_18, primals_9, primals_48, primals_46, primals_52, primals_56, primals_41, primals_51, primals_86, primals_64, primals_61, primals_17, primals_12, primals_39, primals_57, convolution_default_23, primals_53, relu__default_17, primals_40, primals_16, mean_dim_3, primals_28, view_default_15, primals_42, primals_63, primals_29, primals_30, primals_62, primals_47, primals_31, primals_44, primals_58, primals_85, primals_15, primals_107, relu__default_2, convolution_default_15, relu__default_11, getitem_9, convolution_default_3, relu__default_3, relu__default_12, getitem_10, convolution_default_16, convolution_default_4, convolution_default_17, primals_106, relu__default_4, avg_pool2d_default_3, convolution_default_20, relu__default_14, sum_dim_int_list_3, avg_pool2d_default, convolution_default_22, convolution_default_13, primals_34, primals_35, _softmax_default_1, view_default_9, primals_36, avg_pool2d_default_1, relu__default_15, convolution_default_21, relu__default_10, convolution_default_14, relu__default_5, primals_141, primals_143, primals_153, primals_145, view_default_20, primals_118, t_default, convolution_default_5, primals_147, primals_119, mean_dim, primals_117, view_default, primals_152, primals_122, primals_123, primals_151, primals_146, primals_110, _softmax_default, view_default_4, primals_150, convolution_default_7, primals_24, sum_dim_int_list_1, primals_102, primals_100, primals_5, primals_101, primals_25, primals_6, primals_4, primals_3, primals_105, relu__default_8, relu__default_13, _softmax_default_2, mean_dim_2, view_default_10, relu__default_9, convolution_default_11, mean_dim_1, convolution_default_19, sum_dim_int_list_5, view_default_5, view_default_14, avg_pool2d_default_2, tangents_1):
        new_zeros_default = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_9 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_10 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_12 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_13 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_15 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_16 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_18 = torch.ops.aten.new_zeros.default(convolution_default_7, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_19 = torch.ops.aten.new_zeros.default(convolution_default_7, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_21 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_22 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_24 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_25 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_27 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_28 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_30 = torch.ops.aten.new_zeros.default(convolution_default_11, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_31 = torch.ops.aten.new_zeros.default(convolution_default_11, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_33 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_34 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_36 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_37 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_39 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_40 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_42 = torch.ops.aten.new_zeros.default(convolution_default_16, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_43 = torch.ops.aten.new_zeros.default(convolution_default_16, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_45 = torch.ops.aten.new_zeros.default(convolution_default_17, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_46 = torch.ops.aten.new_zeros.default(convolution_default_17, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_48 = torch.ops.aten.new_zeros.default(convolution_default_19, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_49 = torch.ops.aten.new_zeros.default(convolution_default_19, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_51 = torch.ops.aten.new_zeros.default(convolution_default_20, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_52 = torch.ops.aten.new_zeros.default(convolution_default_20, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_54 = torch.ops.aten.new_zeros.default(convolution_default_21, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_55 = torch.ops.aten.new_zeros.default(convolution_default_21, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_57 = torch.ops.aten.new_zeros.default(convolution_default_22, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_58 = torch.ops.aten.new_zeros.default(convolution_default_22, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_60 = torch.ops.aten.new_zeros.default(convolution_default_23, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_61 = torch.ops.aten.new_zeros.default(convolution_default_23, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_63 = torch.ops.aten.new_zeros.default(convolution_default_25, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_64 = torch.ops.aten.new_zeros.default(convolution_default_25, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_66 = torch.ops.aten.new_zeros.default(convolution_default_26, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_67 = torch.ops.aten.new_zeros.default(convolution_default_26, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, view_default_20);  t_default_2 = view_default_20 = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list_8 = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_21 = torch.ops.aten.view.default(sum_dim_int_list_8, [1000]);  sum_dim_int_list_8 = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        view_default_22 = torch.ops.aten.view.default(mm_default, [32, 2048, 1, 1]);  mm_default = None
        expand_default = torch.ops.aten.expand.default(view_default_22, [32, 2048, 7, 7]);  view_default_22 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 49);  expand_default = None
        to_dtype = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default_18, torch.float32);  relu__default_18 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default_69 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_69, to_dtype);  le_scalar = new_zeros_default_69 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_2, convolution_default_26, primals_152, primals_150, primals_151, new_zeros_default_66, new_zeros_default_67, False, 1e-05, [True, True, True]);  convolution_default_26 = primals_152 = primals_150 = primals_151 = new_zeros_default_66 = new_zeros_default_67 = None
        getitem_71 = native_batch_norm_backward_default[0]
        getitem_72 = native_batch_norm_backward_default[1]
        getitem_73 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(getitem_71, avg_pool2d_default_5, primals_147, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_71 = avg_pool2d_default_5 = primals_147 = None
        getitem_74 = convolution_backward_default[0]
        getitem_75 = convolution_backward_default[1];  convolution_backward_default = None
        avg_pool2d_backward_default = torch.ops.aten.avg_pool2d_backward.default(getitem_74, relu__default_14, [2, 2], [2, 2], [0, 0], True, False, None);  getitem_74 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_2, convolution_default_25, primals_129, primals_127, primals_128, new_zeros_default_63, new_zeros_default_64, False, 1e-05, [True, True, True]);  to_dtype_2 = convolution_default_25 = primals_129 = primals_127 = primals_128 = new_zeros_default_63 = new_zeros_default_64 = None
        getitem_77 = native_batch_norm_backward_default_1[0]
        getitem_78 = native_batch_norm_backward_default_1[1]
        getitem_79 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_77, avg_pool2d_default_4, primals_146, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_77 = avg_pool2d_default_4 = primals_146 = None
        getitem_80 = convolution_backward_default_1[0]
        getitem_81 = convolution_backward_default_1[1];  convolution_backward_default_1 = None
        avg_pool2d_backward_default_1 = torch.ops.aten.avg_pool2d_backward.default(getitem_80, sum_dim_int_list_7, [3, 3], [2, 2], [1, 1], False, True, None);  getitem_80 = sum_dim_int_list_7 = None
        unsqueeze_default = torch.ops.aten.unsqueeze.default(avg_pool2d_backward_default_1, 1);  avg_pool2d_backward_default_1 = None
        expand_default_1 = torch.ops.aten.expand.default(unsqueeze_default, [32, 2, 512, 14, 14]);  unsqueeze_default = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(expand_default_1, view_default_15);  view_default_15 = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(expand_default_1, view_default_19);  expand_default_1 = view_default_19 = None
        sum_dim_int_list_9 = torch.ops.aten.sum.dim_IntList(mul_tensor_4, [3, 4], True);  mul_tensor_4 = None
        view_default_23 = torch.ops.aten.view.default(sum_dim_int_list_9, [32, 1024, 1, 1]);  sum_dim_int_list_9 = None
        view_default_24 = torch.ops.aten.view.default(view_default_23, [32, 1024]);  view_default_23 = None
        view_default_25 = torch.ops.aten.view.default(view_default_24, [32, 2, 1, 512]);  view_default_24 = None
        _softmax_backward_data_default = torch.ops.aten._softmax_backward_data.default(view_default_25, _softmax_default_3, 1, torch.float32);  view_default_25 = _softmax_default_3 = None
        transpose_int_4 = torch.ops.aten.transpose.int(_softmax_backward_data_default, 1, 2);  _softmax_backward_data_default = None
        view_default_26 = torch.ops.aten.view.default(transpose_int_4, [32, 1024, 1, 1]);  transpose_int_4 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(view_default_26, relu__default_17, primals_145, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_26 = primals_145 = None
        getitem_83 = convolution_backward_default_2[0]
        getitem_84 = convolution_backward_default_2[1]
        getitem_85 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        to_dtype_3 = torch.ops.aten.to.dtype(getitem_83, torch.float32);  getitem_83 = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu__default_17, torch.float32);  relu__default_17 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_70 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_70, to_dtype_3);  le_scalar_1 = new_zeros_default_70 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_5, convolution_default_23, primals_140, primals_138, primals_139, new_zeros_default_60, new_zeros_default_61, False, 1e-05, [True, True, True]);  to_dtype_5 = convolution_default_23 = primals_140 = primals_138 = primals_139 = new_zeros_default_60 = new_zeros_default_61 = None
        getitem_86 = native_batch_norm_backward_default_2[0]
        getitem_87 = native_batch_norm_backward_default_2[1]
        getitem_88 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_86, mean_dim_3, primals_143, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_86 = mean_dim_3 = primals_143 = None
        getitem_89 = convolution_backward_default_3[0]
        getitem_90 = convolution_backward_default_3[1]
        getitem_91 = convolution_backward_default_3[2];  convolution_backward_default_3 = None
        expand_default_2 = torch.ops.aten.expand.default(getitem_89, [32, 512, 14, 14]);  getitem_89 = None
        div_scalar_1 = torch.ops.aten.div.Scalar(expand_default_2, 196);  expand_default_2 = None
        unsqueeze_default_1 = torch.ops.aten.unsqueeze.default(div_scalar_1, 1);  div_scalar_1 = None
        expand_default_3 = torch.ops.aten.expand.default(unsqueeze_default_1, [32, 2, 512, 14, 14]);  unsqueeze_default_1 = None
        add_tensor = torch.ops.aten.add.Tensor(mul_tensor_5, expand_default_3);  mul_tensor_5 = expand_default_3 = None
        view_default_27 = torch.ops.aten.view.default(add_tensor, [32, 1024, 14, 14]);  add_tensor = None
        to_dtype_6 = torch.ops.aten.to.dtype(view_default_27, torch.float32);  view_default_27 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_16, torch.float32);  relu__default_16 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_71 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_71, to_dtype_6);  le_scalar_2 = new_zeros_default_71 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_8, convolution_default_22, primals_135, primals_133, primals_134, new_zeros_default_57, new_zeros_default_58, False, 1e-05, [True, True, True]);  to_dtype_8 = convolution_default_22 = primals_135 = primals_133 = primals_134 = new_zeros_default_57 = new_zeros_default_58 = None
        getitem_92 = native_batch_norm_backward_default_3[0]
        getitem_93 = native_batch_norm_backward_default_3[1]
        getitem_94 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_92, relu__default_15, primals_141, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_92 = primals_141 = None
        getitem_95 = convolution_backward_default_4[0]
        getitem_96 = convolution_backward_default_4[1];  convolution_backward_default_4 = None
        to_dtype_9 = torch.ops.aten.to.dtype(getitem_95, torch.float32);  getitem_95 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu__default_15, torch.float32);  relu__default_15 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_72 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_72, to_dtype_9);  le_scalar_3 = new_zeros_default_72 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_21, primals_124, primals_122, primals_123, new_zeros_default_54, new_zeros_default_55, False, 1e-05, [True, True, True]);  to_dtype_11 = convolution_default_21 = primals_124 = primals_122 = primals_123 = new_zeros_default_54 = new_zeros_default_55 = None
        getitem_98 = native_batch_norm_backward_default_4[0]
        getitem_99 = native_batch_norm_backward_default_4[1]
        getitem_100 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_98, relu__default_14, primals_130, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_98 = primals_130 = None
        getitem_101 = convolution_backward_default_5[0]
        getitem_102 = convolution_backward_default_5[1];  convolution_backward_default_5 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default, getitem_101);  avg_pool2d_backward_default = getitem_101 = None
        to_dtype_12 = torch.ops.aten.to.dtype(add_tensor_1, torch.float32);  add_tensor_1 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_73 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_73, to_dtype_12);  le_scalar_4 = new_zeros_default_73 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_20, primals_119, primals_117, primals_118, new_zeros_default_51, new_zeros_default_52, False, 1e-05, [True, True, True]);  convolution_default_20 = primals_119 = primals_117 = primals_118 = new_zeros_default_51 = new_zeros_default_52 = None
        getitem_104 = native_batch_norm_backward_default_5[0]
        getitem_105 = native_batch_norm_backward_default_5[1]
        getitem_106 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(getitem_104, avg_pool2d_default_3, primals_114, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_104 = avg_pool2d_default_3 = primals_114 = None
        getitem_107 = convolution_backward_default_6[0]
        getitem_108 = convolution_backward_default_6[1];  convolution_backward_default_6 = None
        avg_pool2d_backward_default_2 = torch.ops.aten.avg_pool2d_backward.default(getitem_107, relu__default_10, [2, 2], [2, 2], [0, 0], True, False, None);  getitem_107 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_19, primals_96, primals_94, primals_95, new_zeros_default_48, new_zeros_default_49, False, 1e-05, [True, True, True]);  to_dtype_14 = convolution_default_19 = primals_96 = primals_94 = primals_95 = new_zeros_default_48 = new_zeros_default_49 = None
        getitem_110 = native_batch_norm_backward_default_6[0]
        getitem_111 = native_batch_norm_backward_default_6[1]
        getitem_112 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(getitem_110, avg_pool2d_default_2, primals_113, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_110 = avg_pool2d_default_2 = primals_113 = None
        getitem_113 = convolution_backward_default_7[0]
        getitem_114 = convolution_backward_default_7[1];  convolution_backward_default_7 = None
        avg_pool2d_backward_default_3 = torch.ops.aten.avg_pool2d_backward.default(getitem_113, sum_dim_int_list_5, [3, 3], [2, 2], [1, 1], False, True, None);  getitem_113 = sum_dim_int_list_5 = None
        unsqueeze_default_2 = torch.ops.aten.unsqueeze.default(avg_pool2d_backward_default_3, 1);  avg_pool2d_backward_default_3 = None
        expand_default_4 = torch.ops.aten.expand.default(unsqueeze_default_2, [32, 2, 256, 28, 28]);  unsqueeze_default_2 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(expand_default_4, view_default_10);  view_default_10 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(expand_default_4, view_default_14);  expand_default_4 = view_default_14 = None
        sum_dim_int_list_10 = torch.ops.aten.sum.dim_IntList(mul_tensor_6, [3, 4], True);  mul_tensor_6 = None
        view_default_28 = torch.ops.aten.view.default(sum_dim_int_list_10, [32, 512, 1, 1]);  sum_dim_int_list_10 = None
        view_default_29 = torch.ops.aten.view.default(view_default_28, [32, 512]);  view_default_28 = None
        view_default_30 = torch.ops.aten.view.default(view_default_29, [32, 2, 1, 256]);  view_default_29 = None
        _softmax_backward_data_default_1 = torch.ops.aten._softmax_backward_data.default(view_default_30, _softmax_default_2, 1, torch.float32);  view_default_30 = _softmax_default_2 = None
        transpose_int_5 = torch.ops.aten.transpose.int(_softmax_backward_data_default_1, 1, 2);  _softmax_backward_data_default_1 = None
        view_default_31 = torch.ops.aten.view.default(transpose_int_5, [32, 512, 1, 1]);  transpose_int_5 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(view_default_31, relu__default_13, primals_112, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_31 = primals_112 = None
        getitem_116 = convolution_backward_default_8[0]
        getitem_117 = convolution_backward_default_8[1]
        getitem_118 = convolution_backward_default_8[2];  convolution_backward_default_8 = None
        to_dtype_15 = torch.ops.aten.to.dtype(getitem_116, torch.float32);  getitem_116 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_74 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_74, to_dtype_15);  le_scalar_5 = new_zeros_default_74 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_17, convolution_default_17, primals_107, primals_105, primals_106, new_zeros_default_45, new_zeros_default_46, False, 1e-05, [True, True, True]);  to_dtype_17 = convolution_default_17 = primals_107 = primals_105 = primals_106 = new_zeros_default_45 = new_zeros_default_46 = None
        getitem_119 = native_batch_norm_backward_default_7[0]
        getitem_120 = native_batch_norm_backward_default_7[1]
        getitem_121 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_119, mean_dim_2, primals_110, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_119 = mean_dim_2 = primals_110 = None
        getitem_122 = convolution_backward_default_9[0]
        getitem_123 = convolution_backward_default_9[1]
        getitem_124 = convolution_backward_default_9[2];  convolution_backward_default_9 = None
        expand_default_5 = torch.ops.aten.expand.default(getitem_122, [32, 256, 28, 28]);  getitem_122 = None
        div_scalar_2 = torch.ops.aten.div.Scalar(expand_default_5, 784);  expand_default_5 = None
        unsqueeze_default_3 = torch.ops.aten.unsqueeze.default(div_scalar_2, 1);  div_scalar_2 = None
        expand_default_6 = torch.ops.aten.expand.default(unsqueeze_default_3, [32, 2, 256, 28, 28]);  unsqueeze_default_3 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(mul_tensor_7, expand_default_6);  mul_tensor_7 = expand_default_6 = None
        view_default_32 = torch.ops.aten.view.default(add_tensor_2, [32, 512, 28, 28]);  add_tensor_2 = None
        to_dtype_18 = torch.ops.aten.to.dtype(view_default_32, torch.float32);  view_default_32 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_75 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_75, to_dtype_18);  le_scalar_6 = new_zeros_default_75 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_20, convolution_default_16, primals_102, primals_100, primals_101, new_zeros_default_42, new_zeros_default_43, False, 1e-05, [True, True, True]);  to_dtype_20 = convolution_default_16 = primals_102 = primals_100 = primals_101 = new_zeros_default_42 = new_zeros_default_43 = None
        getitem_125 = native_batch_norm_backward_default_8[0]
        getitem_126 = native_batch_norm_backward_default_8[1]
        getitem_127 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_125, relu__default_11, primals_108, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_125 = primals_108 = None
        getitem_128 = convolution_backward_default_10[0]
        getitem_129 = convolution_backward_default_10[1];  convolution_backward_default_10 = None
        to_dtype_21 = torch.ops.aten.to.dtype(getitem_128, torch.float32);  getitem_128 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_76 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_76, to_dtype_21);  le_scalar_7 = new_zeros_default_76 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_23, convolution_default_15, primals_91, primals_89, primals_90, new_zeros_default_39, new_zeros_default_40, False, 1e-05, [True, True, True]);  to_dtype_23 = convolution_default_15 = primals_91 = primals_89 = primals_90 = new_zeros_default_39 = new_zeros_default_40 = None
        getitem_131 = native_batch_norm_backward_default_9[0]
        getitem_132 = native_batch_norm_backward_default_9[1]
        getitem_133 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_131, relu__default_10, primals_97, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_131 = primals_97 = None
        getitem_134 = convolution_backward_default_11[0]
        getitem_135 = convolution_backward_default_11[1];  convolution_backward_default_11 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default_2, getitem_134);  avg_pool2d_backward_default_2 = getitem_134 = None
        to_dtype_24 = torch.ops.aten.to.dtype(add_tensor_3, torch.float32);  add_tensor_3 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_77 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_77, to_dtype_24);  le_scalar_8 = new_zeros_default_77 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_14, primals_86, primals_84, primals_85, new_zeros_default_36, new_zeros_default_37, False, 1e-05, [True, True, True]);  convolution_default_14 = primals_86 = primals_84 = primals_85 = new_zeros_default_36 = new_zeros_default_37 = None
        getitem_137 = native_batch_norm_backward_default_10[0]
        getitem_138 = native_batch_norm_backward_default_10[1]
        getitem_139 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(getitem_137, avg_pool2d_default_1, primals_81, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_137 = avg_pool2d_default_1 = primals_81 = None
        getitem_140 = convolution_backward_default_12[0]
        getitem_141 = convolution_backward_default_12[1];  convolution_backward_default_12 = None
        avg_pool2d_backward_default_4 = torch.ops.aten.avg_pool2d_backward.default(getitem_140, relu__default_6, [2, 2], [2, 2], [0, 0], True, False, None);  getitem_140 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_13, primals_63, primals_61, primals_62, new_zeros_default_33, new_zeros_default_34, False, 1e-05, [True, True, True]);  to_dtype_26 = convolution_default_13 = primals_63 = primals_61 = primals_62 = new_zeros_default_33 = new_zeros_default_34 = None
        getitem_143 = native_batch_norm_backward_default_11[0]
        getitem_144 = native_batch_norm_backward_default_11[1]
        getitem_145 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_143, avg_pool2d_default, primals_80, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_143 = avg_pool2d_default = primals_80 = None
        getitem_146 = convolution_backward_default_13[0]
        getitem_147 = convolution_backward_default_13[1];  convolution_backward_default_13 = None
        avg_pool2d_backward_default_5 = torch.ops.aten.avg_pool2d_backward.default(getitem_146, sum_dim_int_list_3, [3, 3], [2, 2], [1, 1], False, True, None);  getitem_146 = sum_dim_int_list_3 = None
        unsqueeze_default_4 = torch.ops.aten.unsqueeze.default(avg_pool2d_backward_default_5, 1);  avg_pool2d_backward_default_5 = None
        expand_default_7 = torch.ops.aten.expand.default(unsqueeze_default_4, [32, 2, 128, 56, 56]);  unsqueeze_default_4 = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(expand_default_7, view_default_5);  view_default_5 = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(expand_default_7, view_default_9);  expand_default_7 = view_default_9 = None
        sum_dim_int_list_11 = torch.ops.aten.sum.dim_IntList(mul_tensor_8, [3, 4], True);  mul_tensor_8 = None
        view_default_33 = torch.ops.aten.view.default(sum_dim_int_list_11, [32, 256, 1, 1]);  sum_dim_int_list_11 = None
        view_default_34 = torch.ops.aten.view.default(view_default_33, [32, 256]);  view_default_33 = None
        view_default_35 = torch.ops.aten.view.default(view_default_34, [32, 2, 1, 128]);  view_default_34 = None
        _softmax_backward_data_default_2 = torch.ops.aten._softmax_backward_data.default(view_default_35, _softmax_default_1, 1, torch.float32);  view_default_35 = _softmax_default_1 = None
        transpose_int_6 = torch.ops.aten.transpose.int(_softmax_backward_data_default_2, 1, 2);  _softmax_backward_data_default_2 = None
        view_default_36 = torch.ops.aten.view.default(transpose_int_6, [32, 256, 1, 1]);  transpose_int_6 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(view_default_36, relu__default_9, primals_79, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_36 = primals_79 = None
        getitem_149 = convolution_backward_default_14[0]
        getitem_150 = convolution_backward_default_14[1]
        getitem_151 = convolution_backward_default_14[2];  convolution_backward_default_14 = None
        to_dtype_27 = torch.ops.aten.to.dtype(getitem_149, torch.float32);  getitem_149 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_78 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_78, to_dtype_27);  le_scalar_9 = new_zeros_default_78 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_29, convolution_default_11, primals_74, primals_72, primals_73, new_zeros_default_30, new_zeros_default_31, False, 1e-05, [True, True, True]);  to_dtype_29 = convolution_default_11 = primals_74 = primals_72 = primals_73 = new_zeros_default_30 = new_zeros_default_31 = None
        getitem_152 = native_batch_norm_backward_default_12[0]
        getitem_153 = native_batch_norm_backward_default_12[1]
        getitem_154 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_152, mean_dim_1, primals_77, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_152 = mean_dim_1 = primals_77 = None
        getitem_155 = convolution_backward_default_15[0]
        getitem_156 = convolution_backward_default_15[1]
        getitem_157 = convolution_backward_default_15[2];  convolution_backward_default_15 = None
        expand_default_8 = torch.ops.aten.expand.default(getitem_155, [32, 128, 56, 56]);  getitem_155 = None
        div_scalar_3 = torch.ops.aten.div.Scalar(expand_default_8, 3136);  expand_default_8 = None
        unsqueeze_default_5 = torch.ops.aten.unsqueeze.default(div_scalar_3, 1);  div_scalar_3 = None
        expand_default_9 = torch.ops.aten.expand.default(unsqueeze_default_5, [32, 2, 128, 56, 56]);  unsqueeze_default_5 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(mul_tensor_9, expand_default_9);  mul_tensor_9 = expand_default_9 = None
        view_default_37 = torch.ops.aten.view.default(add_tensor_4, [32, 256, 56, 56]);  add_tensor_4 = None
        to_dtype_30 = torch.ops.aten.to.dtype(view_default_37, torch.float32);  view_default_37 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_79 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_79, to_dtype_30);  le_scalar_10 = new_zeros_default_79 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default_10, primals_69, primals_67, primals_68, new_zeros_default_27, new_zeros_default_28, False, 1e-05, [True, True, True]);  to_dtype_32 = convolution_default_10 = primals_69 = primals_67 = primals_68 = new_zeros_default_27 = new_zeros_default_28 = None
        getitem_158 = native_batch_norm_backward_default_13[0]
        getitem_159 = native_batch_norm_backward_default_13[1]
        getitem_160 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(getitem_158, relu__default_7, primals_75, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_158 = primals_75 = None
        getitem_161 = convolution_backward_default_16[0]
        getitem_162 = convolution_backward_default_16[1];  convolution_backward_default_16 = None
        to_dtype_33 = torch.ops.aten.to.dtype(getitem_161, torch.float32);  getitem_161 = None
        to_dtype_34 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        new_zeros_default_80 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_80, to_dtype_33);  le_scalar_11 = new_zeros_default_80 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_35, convolution_default_9, primals_58, primals_56, primals_57, new_zeros_default_24, new_zeros_default_25, False, 1e-05, [True, True, True]);  to_dtype_35 = convolution_default_9 = primals_58 = primals_56 = primals_57 = new_zeros_default_24 = new_zeros_default_25 = None
        getitem_164 = native_batch_norm_backward_default_14[0]
        getitem_165 = native_batch_norm_backward_default_14[1]
        getitem_166 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(getitem_164, relu__default_6, primals_64, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_164 = primals_64 = None
        getitem_167 = convolution_backward_default_17[0]
        getitem_168 = convolution_backward_default_17[1];  convolution_backward_default_17 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default_4, getitem_167);  avg_pool2d_backward_default_4 = getitem_167 = None
        to_dtype_36 = torch.ops.aten.to.dtype(add_tensor_5, torch.float32);  add_tensor_5 = None
        to_dtype_37 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        new_zeros_default_81 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_81, to_dtype_36);  le_scalar_12 = new_zeros_default_81 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_38, convolution_default_8, primals_53, primals_51, primals_52, new_zeros_default_21, new_zeros_default_22, False, 1e-05, [True, True, True]);  convolution_default_8 = primals_53 = primals_51 = primals_52 = new_zeros_default_21 = new_zeros_default_22 = None
        getitem_170 = native_batch_norm_backward_default_15[0]
        getitem_171 = native_batch_norm_backward_default_15[1]
        getitem_172 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(getitem_170, getitem_9, primals_48, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_170 = primals_48 = None
        getitem_173 = convolution_backward_default_18[0]
        getitem_174 = convolution_backward_default_18[1];  convolution_backward_default_18 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_38, convolution_default_7, primals_30, primals_28, primals_29, new_zeros_default_18, new_zeros_default_19, False, 1e-05, [True, True, True]);  to_dtype_38 = convolution_default_7 = primals_30 = primals_28 = primals_29 = new_zeros_default_18 = new_zeros_default_19 = None
        getitem_176 = native_batch_norm_backward_default_16[0]
        getitem_177 = native_batch_norm_backward_default_16[1]
        getitem_178 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_176, sum_dim_int_list_1, primals_47, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_176 = sum_dim_int_list_1 = primals_47 = None
        getitem_179 = convolution_backward_default_19[0]
        getitem_180 = convolution_backward_default_19[1];  convolution_backward_default_19 = None
        unsqueeze_default_6 = torch.ops.aten.unsqueeze.default(getitem_179, 1);  getitem_179 = None
        expand_default_10 = torch.ops.aten.expand.default(unsqueeze_default_6, [32, 2, 64, 56, 56]);  unsqueeze_default_6 = None
        mul_tensor_10 = torch.ops.aten.mul.Tensor(expand_default_10, view_default);  view_default = None
        mul_tensor_11 = torch.ops.aten.mul.Tensor(expand_default_10, view_default_4);  expand_default_10 = view_default_4 = None
        sum_dim_int_list_12 = torch.ops.aten.sum.dim_IntList(mul_tensor_10, [3, 4], True);  mul_tensor_10 = None
        view_default_38 = torch.ops.aten.view.default(sum_dim_int_list_12, [32, 128, 1, 1]);  sum_dim_int_list_12 = None
        view_default_39 = torch.ops.aten.view.default(view_default_38, [32, 128]);  view_default_38 = None
        view_default_40 = torch.ops.aten.view.default(view_default_39, [32, 2, 1, 64]);  view_default_39 = None
        _softmax_backward_data_default_3 = torch.ops.aten._softmax_backward_data.default(view_default_40, _softmax_default, 1, torch.float32);  view_default_40 = _softmax_default = None
        transpose_int_7 = torch.ops.aten.transpose.int(_softmax_backward_data_default_3, 1, 2);  _softmax_backward_data_default_3 = None
        view_default_41 = torch.ops.aten.view.default(transpose_int_7, [32, 128, 1, 1]);  transpose_int_7 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(view_default_41, relu__default_5, primals_46, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_41 = primals_46 = None
        getitem_182 = convolution_backward_default_20[0]
        getitem_183 = convolution_backward_default_20[1]
        getitem_184 = convolution_backward_default_20[2];  convolution_backward_default_20 = None
        to_dtype_39 = torch.ops.aten.to.dtype(getitem_182, torch.float32);  getitem_182 = None
        to_dtype_40 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        new_zeros_default_82 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_82, to_dtype_39);  le_scalar_13 = new_zeros_default_82 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_41, convolution_default_5, primals_41, primals_39, primals_40, new_zeros_default_15, new_zeros_default_16, False, 1e-05, [True, True, True]);  to_dtype_41 = convolution_default_5 = primals_41 = primals_39 = primals_40 = new_zeros_default_15 = new_zeros_default_16 = None
        getitem_185 = native_batch_norm_backward_default_17[0]
        getitem_186 = native_batch_norm_backward_default_17[1]
        getitem_187 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(getitem_185, mean_dim, primals_44, [32], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_185 = mean_dim = primals_44 = None
        getitem_188 = convolution_backward_default_21[0]
        getitem_189 = convolution_backward_default_21[1]
        getitem_190 = convolution_backward_default_21[2];  convolution_backward_default_21 = None
        expand_default_11 = torch.ops.aten.expand.default(getitem_188, [32, 64, 56, 56]);  getitem_188 = None
        div_scalar_4 = torch.ops.aten.div.Scalar(expand_default_11, 3136);  expand_default_11 = None
        unsqueeze_default_7 = torch.ops.aten.unsqueeze.default(div_scalar_4, 1);  div_scalar_4 = None
        expand_default_12 = torch.ops.aten.expand.default(unsqueeze_default_7, [32, 2, 64, 56, 56]);  unsqueeze_default_7 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(mul_tensor_11, expand_default_12);  mul_tensor_11 = expand_default_12 = None
        view_default_42 = torch.ops.aten.view.default(add_tensor_6, [32, 128, 56, 56]);  add_tensor_6 = None
        to_dtype_42 = torch.ops.aten.to.dtype(view_default_42, torch.float32);  view_default_42 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_83 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_83, to_dtype_42);  le_scalar_14 = new_zeros_default_83 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_44, convolution_default_4, primals_36, primals_34, primals_35, new_zeros_default_12, new_zeros_default_13, False, 1e-05, [True, True, True]);  to_dtype_44 = convolution_default_4 = primals_36 = primals_34 = primals_35 = new_zeros_default_12 = new_zeros_default_13 = None
        getitem_191 = native_batch_norm_backward_default_18[0]
        getitem_192 = native_batch_norm_backward_default_18[1]
        getitem_193 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(getitem_191, relu__default_3, primals_42, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_191 = primals_42 = None
        getitem_194 = convolution_backward_default_22[0]
        getitem_195 = convolution_backward_default_22[1];  convolution_backward_default_22 = None
        to_dtype_45 = torch.ops.aten.to.dtype(getitem_194, torch.float32);  getitem_194 = None
        to_dtype_46 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_46, 0);  to_dtype_46 = None
        new_zeros_default_84 = torch.ops.aten.new_zeros.default(to_dtype_45, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_84, to_dtype_45);  le_scalar_15 = new_zeros_default_84 = to_dtype_45 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_47, convolution_default_3, primals_25, primals_23, primals_24, new_zeros_default_9, new_zeros_default_10, False, 1e-05, [True, True, True]);  to_dtype_47 = convolution_default_3 = primals_25 = primals_23 = primals_24 = new_zeros_default_9 = new_zeros_default_10 = None
        getitem_197 = native_batch_norm_backward_default_19[0]
        getitem_198 = native_batch_norm_backward_default_19[1]
        getitem_199 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(getitem_197, getitem_9, primals_31, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_197 = getitem_9 = primals_31 = None
        getitem_200 = convolution_backward_default_23[0]
        getitem_201 = convolution_backward_default_23[1];  convolution_backward_default_23 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(getitem_173, getitem_200);  getitem_173 = getitem_200 = None
        max_pool2d_with_indices_backward_default = torch.ops.aten.max_pool2d_with_indices_backward.default(add_tensor_7, relu__default_2, [3, 3], [2, 2], [1, 1], [1, 1], False, getitem_10);  add_tensor_7 = getitem_10 = None
        to_dtype_48 = torch.ops.aten.to.dtype(max_pool2d_with_indices_backward_default, torch.float32);  max_pool2d_with_indices_backward_default = None
        to_dtype_49 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_49, 0);  to_dtype_49 = None
        new_zeros_default_85 = torch.ops.aten.new_zeros.default(to_dtype_48, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_85, to_dtype_48);  le_scalar_16 = new_zeros_default_85 = to_dtype_48 = None
        to_dtype_50 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_50, convolution_default_2, primals_5, primals_3, primals_4, new_zeros_default_6, new_zeros_default_7, False, 1e-05, [True, True, True]);  to_dtype_50 = convolution_default_2 = primals_5 = primals_3 = primals_4 = new_zeros_default_6 = new_zeros_default_7 = None
        getitem_203 = native_batch_norm_backward_default_20[0]
        getitem_204 = native_batch_norm_backward_default_20[1]
        getitem_205 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_203, relu__default_1, primals_18, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_203 = primals_18 = None
        getitem_206 = convolution_backward_default_24[0]
        getitem_207 = convolution_backward_default_24[1];  convolution_backward_default_24 = None
        to_dtype_51 = torch.ops.aten.to.dtype(getitem_206, torch.float32);  getitem_206 = None
        to_dtype_52 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_52, 0);  to_dtype_52 = None
        new_zeros_default_86 = torch.ops.aten.new_zeros.default(to_dtype_51, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_17, new_zeros_default_86, to_dtype_51);  le_scalar_17 = new_zeros_default_86 = to_dtype_51 = None
        to_dtype_53 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_53, convolution_default_1, primals_17, primals_15, primals_16, new_zeros_default_3, new_zeros_default_4, False, 1e-05, [True, True, True]);  to_dtype_53 = convolution_default_1 = primals_17 = primals_15 = primals_16 = new_zeros_default_3 = new_zeros_default_4 = None
        getitem_209 = native_batch_norm_backward_default_21[0]
        getitem_210 = native_batch_norm_backward_default_21[1]
        getitem_211 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_209, relu__default, primals_12, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_209 = primals_12 = None
        getitem_212 = convolution_backward_default_25[0]
        getitem_213 = convolution_backward_default_25[1];  convolution_backward_default_25 = None
        to_dtype_54 = torch.ops.aten.to.dtype(getitem_212, torch.float32);  getitem_212 = None
        to_dtype_55 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_55, 0);  to_dtype_55 = None
        new_zeros_default_87 = torch.ops.aten.new_zeros.default(to_dtype_54, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_18 = torch.ops.aten.where.self(le_scalar_18, new_zeros_default_87, to_dtype_54);  le_scalar_18 = new_zeros_default_87 = to_dtype_54 = None
        to_dtype_56 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_56, convolution_default, primals_11, primals_9, primals_10, new_zeros_default, new_zeros_default_1, False, 1e-05, [True, True, True]);  to_dtype_56 = convolution_default = primals_11 = primals_9 = primals_10 = new_zeros_default = new_zeros_default_1 = None
        getitem_215 = native_batch_norm_backward_default_22[0]
        getitem_216 = native_batch_norm_backward_default_22[1]
        getitem_217 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(getitem_215, primals_153, primals_6, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_215 = primals_153 = primals_6 = None
        getitem_219 = convolution_backward_default_26[1];  convolution_backward_default_26 = None
        return [getitem_205, None, None, None, getitem_204, getitem_219, getitem_217, None, None, None, getitem_216, getitem_213, getitem_211, None, None, None, getitem_210, getitem_207, view_default_21, t_default_4, getitem_199, None, None, None, getitem_198, getitem_178, None, None, None, getitem_177, getitem_201, getitem_193, None, None, None, getitem_192, getitem_187, None, None, None, getitem_186, getitem_195, getitem_190, getitem_189, getitem_184, getitem_183, getitem_180, getitem_174, getitem_172, None, None, None, getitem_171, getitem_166, None, None, None, getitem_165, getitem_145, None, None, None, getitem_144, getitem_168, getitem_160, None, None, None, getitem_159, getitem_154, None, None, None, getitem_153, getitem_162, getitem_157, getitem_156, getitem_151, getitem_150, getitem_147, getitem_141, getitem_139, None, None, None, getitem_138, getitem_133, None, None, None, getitem_132, getitem_112, None, None, None, getitem_111, getitem_135, getitem_127, None, None, None, getitem_126, getitem_121, None, None, None, getitem_120, getitem_129, getitem_124, getitem_123, getitem_118, getitem_117, getitem_114, getitem_108, getitem_106, None, None, None, getitem_105, getitem_100, None, None, None, getitem_99, getitem_79, None, None, None, getitem_78, getitem_102, getitem_94, None, None, None, getitem_93, getitem_88, None, None, None, getitem_87, getitem_96, getitem_91, getitem_90, getitem_85, getitem_84, getitem_81, getitem_75, getitem_73, None, None, None, getitem_72, None]
        
