
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/vgg16/vgg16_joint_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, tangents_1):
        convolution_default = torch.ops.aten.convolution.default(primals_33, primals_8, primals_7, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_7 = None
        relu__default = torch.ops.aten.relu_.default(convolution_default);  convolution_default = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default, primals_20, primals_19, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_19 = None
        relu__default_1 = torch.ops.aten.relu_.default(convolution_default_1);  convolution_default_1 = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu__default_1, [2, 2], [2, 2])
        getitem = max_pool2d_with_indices_default[0]
        getitem_1 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_2 = torch.ops.aten.convolution.default(getitem, primals_30, primals_29, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_29 = None
        relu__default_2 = torch.ops.aten.relu_.default(convolution_default_2);  convolution_default_2 = None
        convolution_default_3 = torch.ops.aten.convolution.default(relu__default_2, primals_32, primals_31, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_31 = None
        relu__default_3 = torch.ops.aten.relu_.default(convolution_default_3);  convolution_default_3 = None
        max_pool2d_with_indices_default_1 = torch.ops.aten.max_pool2d_with_indices.default(relu__default_3, [2, 2], [2, 2])
        getitem_2 = max_pool2d_with_indices_default_1[0]
        getitem_3 = max_pool2d_with_indices_default_1[1];  max_pool2d_with_indices_default_1 = None
        convolution_default_4 = torch.ops.aten.convolution.default(getitem_2, primals_10, primals_9, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_9 = None
        relu__default_4 = torch.ops.aten.relu_.default(convolution_default_4);  convolution_default_4 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_4, primals_12, primals_11, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_11 = None
        relu__default_5 = torch.ops.aten.relu_.default(convolution_default_5);  convolution_default_5 = None
        convolution_default_6 = torch.ops.aten.convolution.default(relu__default_5, primals_14, primals_13, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_13 = None
        relu__default_6 = torch.ops.aten.relu_.default(convolution_default_6);  convolution_default_6 = None
        max_pool2d_with_indices_default_2 = torch.ops.aten.max_pool2d_with_indices.default(relu__default_6, [2, 2], [2, 2])
        getitem_4 = max_pool2d_with_indices_default_2[0]
        getitem_5 = max_pool2d_with_indices_default_2[1];  max_pool2d_with_indices_default_2 = None
        convolution_default_7 = torch.ops.aten.convolution.default(getitem_4, primals_16, primals_15, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_15 = None
        relu__default_7 = torch.ops.aten.relu_.default(convolution_default_7);  convolution_default_7 = None
        convolution_default_8 = torch.ops.aten.convolution.default(relu__default_7, primals_18, primals_17, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_17 = None
        relu__default_8 = torch.ops.aten.relu_.default(convolution_default_8);  convolution_default_8 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_8, primals_22, primals_21, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_21 = None
        relu__default_9 = torch.ops.aten.relu_.default(convolution_default_9);  convolution_default_9 = None
        max_pool2d_with_indices_default_3 = torch.ops.aten.max_pool2d_with_indices.default(relu__default_9, [2, 2], [2, 2])
        getitem_6 = max_pool2d_with_indices_default_3[0]
        getitem_7 = max_pool2d_with_indices_default_3[1];  max_pool2d_with_indices_default_3 = None
        convolution_default_10 = torch.ops.aten.convolution.default(getitem_6, primals_24, primals_23, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_23 = None
        relu__default_10 = torch.ops.aten.relu_.default(convolution_default_10);  convolution_default_10 = None
        convolution_default_11 = torch.ops.aten.convolution.default(relu__default_10, primals_26, primals_25, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_25 = None
        relu__default_11 = torch.ops.aten.relu_.default(convolution_default_11);  convolution_default_11 = None
        convolution_default_12 = torch.ops.aten.convolution.default(relu__default_11, primals_28, primals_27, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_27 = None
        relu__default_12 = torch.ops.aten.relu_.default(convolution_default_12);  convolution_default_12 = None
        max_pool2d_with_indices_default_4 = torch.ops.aten.max_pool2d_with_indices.default(relu__default_12, [2, 2], [2, 2])
        getitem_8 = max_pool2d_with_indices_default_4[0]
        getitem_9 = max_pool2d_with_indices_default_4[1];  max_pool2d_with_indices_default_4 = None
        _adaptive_avg_pool2d_default = torch.ops.aten._adaptive_avg_pool2d.default(getitem_8, [7, 7])
        view_default = torch.ops.aten.view.default(_adaptive_avg_pool2d_default, [64, 25088]);  _adaptive_avg_pool2d_default = None
        t_default = torch.ops.aten.t.default(primals_2);  primals_2 = None
        addmm_default = torch.ops.aten.addmm.default(primals_1, view_default, t_default);  primals_1 = None
        relu__default_13 = torch.ops.aten.relu_.default(addmm_default);  addmm_default = None
        t_default_1 = torch.ops.aten.t.default(primals_4);  primals_4 = None
        addmm_default_1 = torch.ops.aten.addmm.default(primals_3, relu__default_13, t_default_1);  primals_3 = None
        relu__default_14 = torch.ops.aten.relu_.default(addmm_default_1);  addmm_default_1 = None
        t_default_2 = torch.ops.aten.t.default(primals_6);  primals_6 = None
        addmm_default_2 = torch.ops.aten.addmm.default(primals_5, relu__default_14, t_default_2);  primals_5 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(addmm_default_2, tangents_1)
        t_default_3 = torch.ops.aten.t.default(t_default_2);  t_default_2 = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_3);  t_default_3 = None
        t_default_4 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_4, relu__default_14);  t_default_4 = None
        t_default_5 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_1 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_6 = torch.ops.aten.t.default(t_default_5);  t_default_5 = None
        to_dtype = torch.ops.aten.to.dtype(mm_default, torch.float32);  mm_default = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default, to_dtype);  le_scalar = new_zeros_default = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        t_default_7 = torch.ops.aten.t.default(t_default_1);  t_default_1 = None
        mm_default_2 = torch.ops.aten.mm.default(to_dtype_2, t_default_7);  t_default_7 = None
        t_default_8 = torch.ops.aten.t.default(to_dtype_2)
        mm_default_3 = torch.ops.aten.mm.default(t_default_8, relu__default_13);  t_default_8 = None
        t_default_9 = torch.ops.aten.t.default(mm_default_3);  mm_default_3 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(to_dtype_2, [0], True);  to_dtype_2 = None
        view_default_2 = torch.ops.aten.view.default(sum_dim_int_list_1, [4096]);  sum_dim_int_list_1 = None
        t_default_10 = torch.ops.aten.t.default(t_default_9);  t_default_9 = None
        to_dtype_3 = torch.ops.aten.to.dtype(mm_default_2, torch.float32);  mm_default_2 = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_1, to_dtype_3);  le_scalar_1 = new_zeros_default_1 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        t_default_11 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default_4 = torch.ops.aten.mm.default(to_dtype_5, t_default_11);  t_default_11 = None
        t_default_12 = torch.ops.aten.t.default(to_dtype_5)
        mm_default_5 = torch.ops.aten.mm.default(t_default_12, view_default);  t_default_12 = view_default = None
        t_default_13 = torch.ops.aten.t.default(mm_default_5);  mm_default_5 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(to_dtype_5, [0], True);  to_dtype_5 = None
        view_default_3 = torch.ops.aten.view.default(sum_dim_int_list_2, [4096]);  sum_dim_int_list_2 = None
        t_default_14 = torch.ops.aten.t.default(t_default_13);  t_default_13 = None
        view_default_4 = torch.ops.aten.view.default(mm_default_4, [64, 512, 7, 7]);  mm_default_4 = None
        _adaptive_avg_pool2d_backward_default = torch.ops.aten._adaptive_avg_pool2d_backward.default(view_default_4, getitem_8);  view_default_4 = getitem_8 = None
        max_pool2d_with_indices_backward_default = torch.ops.aten.max_pool2d_with_indices_backward.default(_adaptive_avg_pool2d_backward_default, relu__default_12, [2, 2], [2, 2], [0, 0], [1, 1], False, getitem_9);  _adaptive_avg_pool2d_backward_default = getitem_9 = None
        to_dtype_6 = torch.ops.aten.to.dtype(max_pool2d_with_indices_backward_default, torch.float32);  max_pool2d_with_indices_backward_default = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_2 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_2, to_dtype_6);  le_scalar_2 = new_zeros_default_2 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(to_dtype_8, relu__default_11, primals_28, [512], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_8 = primals_28 = None
        getitem_10 = convolution_backward_default[0]
        getitem_11 = convolution_backward_default[1]
        getitem_12 = convolution_backward_default[2];  convolution_backward_default = None
        to_dtype_9 = torch.ops.aten.to.dtype(getitem_10, torch.float32);  getitem_10 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_3, to_dtype_9);  le_scalar_3 = new_zeros_default_3 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(to_dtype_11, relu__default_10, primals_26, [512], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_11 = primals_26 = None
        getitem_13 = convolution_backward_default_1[0]
        getitem_14 = convolution_backward_default_1[1]
        getitem_15 = convolution_backward_default_1[2];  convolution_backward_default_1 = None
        to_dtype_12 = torch.ops.aten.to.dtype(getitem_13, torch.float32);  getitem_13 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_4, to_dtype_12);  le_scalar_4 = new_zeros_default_4 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(to_dtype_14, getitem_6, primals_24, [512], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_14 = getitem_6 = primals_24 = None
        getitem_16 = convolution_backward_default_2[0]
        getitem_17 = convolution_backward_default_2[1]
        getitem_18 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        max_pool2d_with_indices_backward_default_1 = torch.ops.aten.max_pool2d_with_indices_backward.default(getitem_16, relu__default_9, [2, 2], [2, 2], [0, 0], [1, 1], False, getitem_7);  getitem_16 = getitem_7 = None
        to_dtype_15 = torch.ops.aten.to.dtype(max_pool2d_with_indices_backward_default_1, torch.float32);  max_pool2d_with_indices_backward_default_1 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_5 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_5, to_dtype_15);  le_scalar_5 = new_zeros_default_5 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(to_dtype_17, relu__default_8, primals_22, [512], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_17 = primals_22 = None
        getitem_19 = convolution_backward_default_3[0]
        getitem_20 = convolution_backward_default_3[1]
        getitem_21 = convolution_backward_default_3[2];  convolution_backward_default_3 = None
        to_dtype_18 = torch.ops.aten.to.dtype(getitem_19, torch.float32);  getitem_19 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_6, to_dtype_18);  le_scalar_6 = new_zeros_default_6 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(to_dtype_20, relu__default_7, primals_18, [512], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_20 = primals_18 = None
        getitem_22 = convolution_backward_default_4[0]
        getitem_23 = convolution_backward_default_4[1]
        getitem_24 = convolution_backward_default_4[2];  convolution_backward_default_4 = None
        to_dtype_21 = torch.ops.aten.to.dtype(getitem_22, torch.float32);  getitem_22 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_7, to_dtype_21);  le_scalar_7 = new_zeros_default_7 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(to_dtype_23, getitem_4, primals_16, [512], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_23 = getitem_4 = primals_16 = None
        getitem_25 = convolution_backward_default_5[0]
        getitem_26 = convolution_backward_default_5[1]
        getitem_27 = convolution_backward_default_5[2];  convolution_backward_default_5 = None
        max_pool2d_with_indices_backward_default_2 = torch.ops.aten.max_pool2d_with_indices_backward.default(getitem_25, relu__default_6, [2, 2], [2, 2], [0, 0], [1, 1], False, getitem_5);  getitem_25 = getitem_5 = None
        to_dtype_24 = torch.ops.aten.to.dtype(max_pool2d_with_indices_backward_default_2, torch.float32);  max_pool2d_with_indices_backward_default_2 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_8 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_8, to_dtype_24);  le_scalar_8 = new_zeros_default_8 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(to_dtype_26, relu__default_5, primals_14, [256], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_26 = primals_14 = None
        getitem_28 = convolution_backward_default_6[0]
        getitem_29 = convolution_backward_default_6[1]
        getitem_30 = convolution_backward_default_6[2];  convolution_backward_default_6 = None
        to_dtype_27 = torch.ops.aten.to.dtype(getitem_28, torch.float32);  getitem_28 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_9 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_9, to_dtype_27);  le_scalar_9 = new_zeros_default_9 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(to_dtype_29, relu__default_4, primals_12, [256], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_29 = primals_12 = None
        getitem_31 = convolution_backward_default_7[0]
        getitem_32 = convolution_backward_default_7[1]
        getitem_33 = convolution_backward_default_7[2];  convolution_backward_default_7 = None
        to_dtype_30 = torch.ops.aten.to.dtype(getitem_31, torch.float32);  getitem_31 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_10 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_10, to_dtype_30);  le_scalar_10 = new_zeros_default_10 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(to_dtype_32, getitem_2, primals_10, [256], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_32 = getitem_2 = primals_10 = None
        getitem_34 = convolution_backward_default_8[0]
        getitem_35 = convolution_backward_default_8[1]
        getitem_36 = convolution_backward_default_8[2];  convolution_backward_default_8 = None
        max_pool2d_with_indices_backward_default_3 = torch.ops.aten.max_pool2d_with_indices_backward.default(getitem_34, relu__default_3, [2, 2], [2, 2], [0, 0], [1, 1], False, getitem_3);  getitem_34 = getitem_3 = None
        to_dtype_33 = torch.ops.aten.to.dtype(max_pool2d_with_indices_backward_default_3, torch.float32);  max_pool2d_with_indices_backward_default_3 = None
        to_dtype_34 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        new_zeros_default_11 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_11, to_dtype_33);  le_scalar_11 = new_zeros_default_11 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(to_dtype_35, relu__default_2, primals_32, [128], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_35 = primals_32 = None
        getitem_37 = convolution_backward_default_9[0]
        getitem_38 = convolution_backward_default_9[1]
        getitem_39 = convolution_backward_default_9[2];  convolution_backward_default_9 = None
        to_dtype_36 = torch.ops.aten.to.dtype(getitem_37, torch.float32);  getitem_37 = None
        to_dtype_37 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        new_zeros_default_12 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_12, to_dtype_36);  le_scalar_12 = new_zeros_default_12 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(to_dtype_38, getitem, primals_30, [128], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_38 = getitem = primals_30 = None
        getitem_40 = convolution_backward_default_10[0]
        getitem_41 = convolution_backward_default_10[1]
        getitem_42 = convolution_backward_default_10[2];  convolution_backward_default_10 = None
        max_pool2d_with_indices_backward_default_4 = torch.ops.aten.max_pool2d_with_indices_backward.default(getitem_40, relu__default_1, [2, 2], [2, 2], [0, 0], [1, 1], False, getitem_1);  getitem_40 = getitem_1 = None
        to_dtype_39 = torch.ops.aten.to.dtype(max_pool2d_with_indices_backward_default_4, torch.float32);  max_pool2d_with_indices_backward_default_4 = None
        to_dtype_40 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        new_zeros_default_13 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_13, to_dtype_39);  le_scalar_13 = new_zeros_default_13 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(to_dtype_41, relu__default, primals_20, [64], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_41 = primals_20 = None
        getitem_43 = convolution_backward_default_11[0]
        getitem_44 = convolution_backward_default_11[1]
        getitem_45 = convolution_backward_default_11[2];  convolution_backward_default_11 = None
        to_dtype_42 = torch.ops.aten.to.dtype(getitem_43, torch.float32);  getitem_43 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_14 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_14, to_dtype_42);  le_scalar_14 = new_zeros_default_14 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(to_dtype_44, primals_33, primals_8, [64], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [False, True, True]);  to_dtype_44 = primals_33 = primals_8 = None
        getitem_46 = convolution_backward_default_12[0]
        getitem_47 = convolution_backward_default_12[1]
        getitem_48 = convolution_backward_default_12[2];  convolution_backward_default_12 = None
        return [addmm_default_2, view_default_3, t_default_14, view_default_2, t_default_10, view_default_1, t_default_6, getitem_48, getitem_47, getitem_36, getitem_35, getitem_33, getitem_32, getitem_30, getitem_29, getitem_27, getitem_26, getitem_24, getitem_23, getitem_45, getitem_44, getitem_21, getitem_20, getitem_18, getitem_17, getitem_15, getitem_14, getitem_12, getitem_11, getitem_42, getitem_41, getitem_39, getitem_38, None]
        
