
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/vgg16/vgg16_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33):
        convolution_default = torch.ops.aten.convolution.default(primals_33, primals_8, primals_7, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_7 = None
        relu__default = torch.ops.aten.relu_.default(convolution_default);  convolution_default = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default, primals_20, primals_19, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_19 = None
        relu__default_1 = torch.ops.aten.relu_.default(convolution_default_1);  convolution_default_1 = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu__default_1, [2, 2], [2, 2])
        getitem = max_pool2d_with_indices_default[0]
        getitem_1 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_2 = torch.ops.aten.convolution.default(getitem, primals_30, primals_29, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_29 = None
        relu__default_2 = torch.ops.aten.relu_.default(convolution_default_2);  convolution_default_2 = None
        convolution_default_3 = torch.ops.aten.convolution.default(relu__default_2, primals_32, primals_31, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_31 = None
        relu__default_3 = torch.ops.aten.relu_.default(convolution_default_3);  convolution_default_3 = None
        max_pool2d_with_indices_default_1 = torch.ops.aten.max_pool2d_with_indices.default(relu__default_3, [2, 2], [2, 2])
        getitem_2 = max_pool2d_with_indices_default_1[0]
        getitem_3 = max_pool2d_with_indices_default_1[1];  max_pool2d_with_indices_default_1 = None
        convolution_default_4 = torch.ops.aten.convolution.default(getitem_2, primals_10, primals_9, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_9 = None
        relu__default_4 = torch.ops.aten.relu_.default(convolution_default_4);  convolution_default_4 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_4, primals_12, primals_11, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_11 = None
        relu__default_5 = torch.ops.aten.relu_.default(convolution_default_5);  convolution_default_5 = None
        convolution_default_6 = torch.ops.aten.convolution.default(relu__default_5, primals_14, primals_13, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_13 = None
        relu__default_6 = torch.ops.aten.relu_.default(convolution_default_6);  convolution_default_6 = None
        max_pool2d_with_indices_default_2 = torch.ops.aten.max_pool2d_with_indices.default(relu__default_6, [2, 2], [2, 2])
        getitem_4 = max_pool2d_with_indices_default_2[0]
        getitem_5 = max_pool2d_with_indices_default_2[1];  max_pool2d_with_indices_default_2 = None
        convolution_default_7 = torch.ops.aten.convolution.default(getitem_4, primals_16, primals_15, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_15 = None
        relu__default_7 = torch.ops.aten.relu_.default(convolution_default_7);  convolution_default_7 = None
        convolution_default_8 = torch.ops.aten.convolution.default(relu__default_7, primals_18, primals_17, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_17 = None
        relu__default_8 = torch.ops.aten.relu_.default(convolution_default_8);  convolution_default_8 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_8, primals_22, primals_21, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_21 = None
        relu__default_9 = torch.ops.aten.relu_.default(convolution_default_9);  convolution_default_9 = None
        max_pool2d_with_indices_default_3 = torch.ops.aten.max_pool2d_with_indices.default(relu__default_9, [2, 2], [2, 2])
        getitem_6 = max_pool2d_with_indices_default_3[0]
        getitem_7 = max_pool2d_with_indices_default_3[1];  max_pool2d_with_indices_default_3 = None
        convolution_default_10 = torch.ops.aten.convolution.default(getitem_6, primals_24, primals_23, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_23 = None
        relu__default_10 = torch.ops.aten.relu_.default(convolution_default_10);  convolution_default_10 = None
        convolution_default_11 = torch.ops.aten.convolution.default(relu__default_10, primals_26, primals_25, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_25 = None
        relu__default_11 = torch.ops.aten.relu_.default(convolution_default_11);  convolution_default_11 = None
        convolution_default_12 = torch.ops.aten.convolution.default(relu__default_11, primals_28, primals_27, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_27 = None
        relu__default_12 = torch.ops.aten.relu_.default(convolution_default_12);  convolution_default_12 = None
        max_pool2d_with_indices_default_4 = torch.ops.aten.max_pool2d_with_indices.default(relu__default_12, [2, 2], [2, 2])
        getitem_8 = max_pool2d_with_indices_default_4[0]
        getitem_9 = max_pool2d_with_indices_default_4[1];  max_pool2d_with_indices_default_4 = None
        _adaptive_avg_pool2d_default = torch.ops.aten._adaptive_avg_pool2d.default(getitem_8, [7, 7])
        view_default = torch.ops.aten.view.default(_adaptive_avg_pool2d_default, [64, 25088]);  _adaptive_avg_pool2d_default = None
        t_default = torch.ops.aten.t.default(primals_2);  primals_2 = None
        addmm_default = torch.ops.aten.addmm.default(primals_1, view_default, t_default);  primals_1 = None
        relu__default_13 = torch.ops.aten.relu_.default(addmm_default);  addmm_default = None
        t_default_1 = torch.ops.aten.t.default(primals_4);  primals_4 = None
        addmm_default_1 = torch.ops.aten.addmm.default(primals_3, relu__default_13, t_default_1);  primals_3 = None
        relu__default_14 = torch.ops.aten.relu_.default(addmm_default_1);  addmm_default_1 = None
        t_default_2 = torch.ops.aten.t.default(primals_6);  primals_6 = None
        addmm_default_2 = torch.ops.aten.addmm.default(primals_5, relu__default_14, t_default_2);  primals_5 = None
        return [addmm_default_2, relu__default_14, t_default_2, relu__default, relu__default_1, getitem_1, getitem, getitem_5, relu__default_2, relu__default_11, getitem_4, relu__default_3, relu__default_12, primals_8, relu__default_7, primals_10, primals_24, relu__default_8, primals_12, getitem_3, getitem_9, getitem_8, getitem_2, primals_32, primals_14, view_default, primals_16, primals_30, t_default, relu__default_4, primals_28, primals_33, getitem_7, relu__default_9, primals_18, getitem_6, relu__default_5, primals_20, relu__default_13, primals_26, primals_22, t_default_1, relu__default_10, relu__default_6]
        
