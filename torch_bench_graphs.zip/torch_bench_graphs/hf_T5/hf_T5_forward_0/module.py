
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/hf_T5/hf_T5_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11):
        pow_tensor_scalar = torch.ops.aten.pow.Tensor_Scalar(primals_10, 2)
        mean_dim = torch.ops.aten.mean.dim(pow_tensor_scalar, [-1], True);  pow_tensor_scalar = None
        add_tensor = torch.ops.aten.add.Tensor(mean_dim, 1e-06);  mean_dim = None
        rsqrt_default = torch.ops.aten.rsqrt.default(add_tensor);  add_tensor = None
        mul_tensor = torch.ops.aten.mul.Tensor(primals_10, rsqrt_default)
        mul_tensor_1 = torch.ops.aten.mul.Tensor(primals_6, mul_tensor)
        t_default = torch.ops.aten.t.default(primals_3);  primals_3 = None
        view_default = torch.ops.aten.view.default(mul_tensor_1, [8192, 512])
        mm_default = torch.ops.aten.mm.default(view_default, t_default)
        _unsafe_view_default = torch.ops.aten._unsafe_view.default(mm_default, [8, 1024, 512]);  mm_default = None
        view_default_1 = torch.ops.aten.view.default(_unsafe_view_default, [8, -1, 8, 64]);  _unsafe_view_default = None
        transpose_int = torch.ops.aten.transpose.int(view_default_1, 1, 2);  view_default_1 = None
        t_default_1 = torch.ops.aten.t.default(primals_1);  primals_1 = None
        view_default_2 = torch.ops.aten.view.default(mul_tensor_1, [8192, 512])
        mm_default_1 = torch.ops.aten.mm.default(view_default_2, t_default_1)
        _unsafe_view_default_1 = torch.ops.aten._unsafe_view.default(mm_default_1, [8, 1024, 512]);  mm_default_1 = None
        view_default_3 = torch.ops.aten.view.default(_unsafe_view_default_1, [8, -1, 8, 64]);  _unsafe_view_default_1 = None
        transpose_int_1 = torch.ops.aten.transpose.int(view_default_3, 1, 2);  view_default_3 = None
        t_default_2 = torch.ops.aten.t.default(primals_5);  primals_5 = None
        view_default_4 = torch.ops.aten.view.default(mul_tensor_1, [8192, 512]);  mul_tensor_1 = None
        mm_default_2 = torch.ops.aten.mm.default(view_default_4, t_default_2)
        _unsafe_view_default_2 = torch.ops.aten._unsafe_view.default(mm_default_2, [8, 1024, 512]);  mm_default_2 = None
        view_default_5 = torch.ops.aten.view.default(_unsafe_view_default_2, [8, -1, 8, 64]);  _unsafe_view_default_2 = None
        transpose_int_2 = torch.ops.aten.transpose.int(view_default_5, 1, 2);  view_default_5 = None
        transpose_int_3 = torch.ops.aten.transpose.int(transpose_int_1, 3, 2);  transpose_int_1 = None
        expand_default = torch.ops.aten.expand.default(transpose_int, [8, 8, 1024, 64]);  transpose_int = None
        clone_default = torch.ops.aten.clone.default(expand_default, memory_format = torch.contiguous_format);  expand_default = None
        _unsafe_view_default_3 = torch.ops.aten._unsafe_view.default(clone_default, [64, 1024, 64]);  clone_default = None
        expand_default_1 = torch.ops.aten.expand.default(transpose_int_3, [8, 8, 64, 1024]);  transpose_int_3 = None
        clone_default_1 = torch.ops.aten.clone.default(expand_default_1, memory_format = torch.contiguous_format);  expand_default_1 = None
        _unsafe_view_default_4 = torch.ops.aten._unsafe_view.default(clone_default_1, [64, 64, 1024]);  clone_default_1 = None
        bmm_default = torch.ops.aten.bmm.default(_unsafe_view_default_3, _unsafe_view_default_4)
        _unsafe_view_default_5 = torch.ops.aten._unsafe_view.default(bmm_default, [8, 8, 1024, 1024]);  bmm_default = None
        arange = torch.ops.aten.arange.default(1024, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        slice_tensor = torch.ops.aten.slice.Tensor(arange, 0, 0, 9223372036854775807);  arange = None
        unsqueeze_default = torch.ops.aten.unsqueeze.default(slice_tensor, 1);  slice_tensor = None
        arange_1 = torch.ops.aten.arange.default(1024, dtype = torch.int64, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)
        unsqueeze_default_1 = torch.ops.aten.unsqueeze.default(arange_1, 0);  arange_1 = None
        slice_tensor_1 = torch.ops.aten.slice.Tensor(unsqueeze_default_1, 1, 0, 9223372036854775807);  unsqueeze_default_1 = None
        sub_tensor = torch.ops.aten.sub.Tensor(slice_tensor_1, unsqueeze_default);  slice_tensor_1 = unsqueeze_default = None
        gt_scalar = torch.ops.aten.gt.Scalar(sub_tensor, 0)
        _to_copy_default = torch.ops.aten._to_copy.default(gt_scalar, dtype = torch.int64);  gt_scalar = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(_to_copy_default, 16);  _to_copy_default = None
        add_tensor_1 = torch.ops.aten.add.Tensor(mul_tensor_2, 0);  mul_tensor_2 = None
        abs_default = torch.ops.aten.abs.default(sub_tensor);  sub_tensor = None
        lt_scalar = torch.ops.aten.lt.Scalar(abs_default, 8)
        _to_copy_default_1 = torch.ops.aten._to_copy.default(abs_default, dtype = torch.float32)
        div_tensor = torch.ops.aten.div.Tensor(_to_copy_default_1, 8);  _to_copy_default_1 = None
        log_default = torch.ops.aten.log.default(div_tensor);  div_tensor = None
        div_tensor_1 = torch.ops.aten.div.Tensor(log_default, 2.772588722239781);  log_default = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(div_tensor_1, 8);  div_tensor_1 = None
        _to_copy_default_2 = torch.ops.aten._to_copy.default(mul_tensor_3, dtype = torch.int64);  mul_tensor_3 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(_to_copy_default_2, 8);  _to_copy_default_2 = None
        full_like_default = torch.ops.aten.full_like.default(add_tensor_2, 15, device = device(type='cuda', index=0), dtype = torch.int64, layout = torch.strided, pin_memory = False)
        minimum_default = torch.ops.aten.minimum.default(add_tensor_2, full_like_default);  add_tensor_2 = full_like_default = None
        where_self = torch.ops.aten.where.self(lt_scalar, abs_default, minimum_default);  lt_scalar = abs_default = minimum_default = None
        add__tensor = torch.ops.aten.add_.Tensor(add_tensor_1, where_self);  add_tensor_1 = where_self = None
        embedding_default = torch.ops.aten.embedding.default(primals_4, add__tensor);  primals_4 = None
        permute_default = torch.ops.aten.permute.default(embedding_default, [2, 0, 1]);  embedding_default = None
        unsqueeze_default_2 = torch.ops.aten.unsqueeze.default(permute_default, 0);  permute_default = None
        add_tensor_3 = torch.ops.aten.add.Tensor(unsqueeze_default_2, primals_11);  unsqueeze_default_2 = primals_11 = None
        add__tensor_1 = torch.ops.aten.add_.Tensor(_unsafe_view_default_5, add_tensor_3);  _unsafe_view_default_5 = None
        _softmax_default = torch.ops.aten._softmax.default(add__tensor_1, -1, False);  add__tensor_1 = None
        expand_default_2 = torch.ops.aten.expand.default(_softmax_default, [8, 8, 1024, 1024])
        view_default_6 = torch.ops.aten.view.default(expand_default_2, [64, 1024, 1024]);  expand_default_2 = None
        expand_default_3 = torch.ops.aten.expand.default(transpose_int_2, [8, 8, 1024, 64]);  transpose_int_2 = None
        clone_default_2 = torch.ops.aten.clone.default(expand_default_3, memory_format = torch.contiguous_format);  expand_default_3 = None
        _unsafe_view_default_6 = torch.ops.aten._unsafe_view.default(clone_default_2, [64, 1024, 64]);  clone_default_2 = None
        bmm_default_1 = torch.ops.aten.bmm.default(view_default_6, _unsafe_view_default_6)
        _unsafe_view_default_7 = torch.ops.aten._unsafe_view.default(bmm_default_1, [8, 8, 1024, 64]);  bmm_default_1 = None
        transpose_int_4 = torch.ops.aten.transpose.int(_unsafe_view_default_7, 1, 2);  _unsafe_view_default_7 = None
        clone_default_3 = torch.ops.aten.clone.default(transpose_int_4, memory_format = torch.contiguous_format);  transpose_int_4 = None
        view_default_7 = torch.ops.aten.view.default(clone_default_3, [8, -1, 512]);  clone_default_3 = None
        t_default_3 = torch.ops.aten.t.default(primals_2);  primals_2 = None
        view_default_8 = torch.ops.aten.view.default(view_default_7, [8192, 512]);  view_default_7 = None
        mm_default_3 = torch.ops.aten.mm.default(view_default_8, t_default_3)
        _unsafe_view_default_8 = torch.ops.aten._unsafe_view.default(mm_default_3, [8, 1024, 512]);  mm_default_3 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(primals_10, _unsafe_view_default_8);  _unsafe_view_default_8 = None
        pow_tensor_scalar_1 = torch.ops.aten.pow.Tensor_Scalar(add_tensor_4, 2)
        mean_dim_1 = torch.ops.aten.mean.dim(pow_tensor_scalar_1, [-1], True);  pow_tensor_scalar_1 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(mean_dim_1, 1e-06);  mean_dim_1 = None
        rsqrt_default_1 = torch.ops.aten.rsqrt.default(add_tensor_5);  add_tensor_5 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(add_tensor_4, rsqrt_default_1)
        mul_tensor_5 = torch.ops.aten.mul.Tensor(primals_9, mul_tensor_4)
        t_default_4 = torch.ops.aten.t.default(primals_7);  primals_7 = None
        view_default_9 = torch.ops.aten.view.default(mul_tensor_5, [8192, 512]);  mul_tensor_5 = None
        mm_default_4 = torch.ops.aten.mm.default(view_default_9, t_default_4)
        _unsafe_view_default_9 = torch.ops.aten._unsafe_view.default(mm_default_4, [8, 1024, 2048]);  mm_default_4 = None
        relu_default = torch.ops.aten.relu.default(_unsafe_view_default_9);  _unsafe_view_default_9 = None
        t_default_5 = torch.ops.aten.t.default(primals_8);  primals_8 = None
        view_default_10 = torch.ops.aten.view.default(relu_default, [8192, 2048])
        mm_default_5 = torch.ops.aten.mm.default(view_default_10, t_default_5)
        _unsafe_view_default_10 = torch.ops.aten._unsafe_view.default(mm_default_5, [8, 1024, 512]);  mm_default_5 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(add_tensor_4, _unsafe_view_default_10);  _unsafe_view_default_10 = None
        return [add_tensor_6, add_tensor_3, rsqrt_default, _unsafe_view_default_4, view_default, add_tensor_4, t_default_1, view_default_2, mul_tensor, t_default, t_default_3, primals_6, _unsafe_view_default_6, view_default_8, t_default_2, rsqrt_default_1, _unsafe_view_default_3, view_default_6, primals_10, primals_9, mul_tensor_4, view_default_4, t_default_4, view_default_9, add__tensor, _softmax_default, t_default_5, relu_default, view_default_10]
        
