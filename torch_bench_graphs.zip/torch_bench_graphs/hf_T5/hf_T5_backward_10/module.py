
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/hf_T5/hf_T5_backward_10/state_dict.pt'))

    
    
    def forward(self, rsqrt_default_2, view_default_9, mul_tensor_4, rsqrt_default, t_default_8, t_default_4, _softmax_default, view_default_18, t_default, t_default_5, t_default_9, mul_tensor_2, view_default_19, view_default, rsqrt_default_1, mul_tensor, view_default_8, t_default_1, relu_default, t_default_3, view_default_4, view_default_11, primals_10, add_tensor_1, _unsafe_view_default_6, _unsafe_view_default_3, _unsafe_view_default_13, _softmax_default_1, add_tensor_3, view_default_2, view_default_15, view_default_13, primals_14, _unsafe_view_default_4, view_default_17, primals_5, t_default_6, _unsafe_view_default_12, primals_13, _unsafe_view_default_15, t_default_7, view_default_6, t_default_2, tangents_1, tangents_2, tangents_3, tangents_4, tangents_5):
        view_default_20 = torch.ops.aten.view.default(tangents_1, [8192, 512])
        t_default_10 = torch.ops.aten.t.default(view_default_20)
        mm_default_10 = torch.ops.aten.mm.default(t_default_10, view_default_19);  t_default_10 = view_default_19 = None
        t_default_11 = torch.ops.aten.t.default(mm_default_10);  mm_default_10 = None
        t_default_12 = torch.ops.aten.t.default(t_default_9);  t_default_9 = None
        mm_default_11 = torch.ops.aten.mm.default(view_default_20, t_default_12);  view_default_20 = t_default_12 = None
        view_default_21 = torch.ops.aten.view.default(mm_default_11, [8, 1024, 2048]);  mm_default_11 = None
        t_default_13 = torch.ops.aten.t.default(t_default_11);  t_default_11 = None
        to_dtype = torch.ops.aten.to.dtype(view_default_21, torch.float32);  view_default_21 = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu_default, torch.float32);  relu_default = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default, to_dtype);  le_scalar = new_zeros_default = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        view_default_22 = torch.ops.aten.view.default(to_dtype_2, [8192, 2048]);  to_dtype_2 = None
        t_default_14 = torch.ops.aten.t.default(view_default_22)
        mm_default_12 = torch.ops.aten.mm.default(t_default_14, view_default_18);  t_default_14 = view_default_18 = None
        t_default_15 = torch.ops.aten.t.default(mm_default_12);  mm_default_12 = None
        t_default_16 = torch.ops.aten.t.default(t_default_8);  t_default_8 = None
        mm_default_13 = torch.ops.aten.mm.default(view_default_22, t_default_16);  view_default_22 = t_default_16 = None
        view_default_23 = torch.ops.aten.view.default(mm_default_13, [8, 1024, 512]);  mm_default_13 = None
        t_default_17 = torch.ops.aten.t.default(t_default_15);  t_default_15 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(view_default_23, primals_13);  primals_13 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(view_default_23, mul_tensor_4);  view_default_23 = mul_tensor_4 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(mul_tensor_7, [0, 1], True);  mul_tensor_7 = None
        view_default_24 = torch.ops.aten.view.default(sum_dim_int_list, [512]);  sum_dim_int_list = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(mul_tensor_6, add_tensor_3)
        mul_tensor_9 = torch.ops.aten.mul.Tensor(mul_tensor_6, rsqrt_default_2);  mul_tensor_6 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(mul_tensor_8, [2], True);  mul_tensor_8 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(tangents_1, mul_tensor_9);  tangents_1 = mul_tensor_9 = None
        mul_scalar = torch.ops.aten.mul.Scalar(sum_dim_int_list_1, -0.5);  sum_dim_int_list_1 = None
        pow_tensor_scalar_3 = torch.ops.aten.pow.Tensor_Scalar(rsqrt_default_2, 3);  rsqrt_default_2 = None
        mul_tensor_10 = torch.ops.aten.mul.Tensor(mul_scalar, pow_tensor_scalar_3);  mul_scalar = pow_tensor_scalar_3 = None
        expand_default_8 = torch.ops.aten.expand.default(mul_tensor_10, [8, 1024, 512]);  mul_tensor_10 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default_8, 512);  expand_default_8 = None
        pow_tensor_scalar_4 = torch.ops.aten.pow.Tensor_Scalar(add_tensor_3, 1.0);  add_tensor_3 = None
        mul_scalar_1 = torch.ops.aten.mul.Scalar(pow_tensor_scalar_4, 2.0);  pow_tensor_scalar_4 = None
        mul_tensor_11 = torch.ops.aten.mul.Tensor(div_scalar, mul_scalar_1);  div_scalar = mul_scalar_1 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(add_tensor_6, mul_tensor_11);  add_tensor_6 = mul_tensor_11 = None
        view_default_25 = torch.ops.aten.view.default(add_tensor_7, [8192, 512])
        t_default_18 = torch.ops.aten.t.default(view_default_25)
        mm_default_14 = torch.ops.aten.mm.default(t_default_18, view_default_17);  t_default_18 = view_default_17 = None
        t_default_19 = torch.ops.aten.t.default(mm_default_14);  mm_default_14 = None
        t_default_20 = torch.ops.aten.t.default(t_default_7);  t_default_7 = None
        mm_default_15 = torch.ops.aten.mm.default(view_default_25, t_default_20);  view_default_25 = t_default_20 = None
        view_default_26 = torch.ops.aten.view.default(mm_default_15, [8, 1024, 512]);  mm_default_15 = None
        t_default_21 = torch.ops.aten.t.default(t_default_19);  t_default_19 = None
        view_default_27 = torch.ops.aten.view.default(view_default_26, [8, 1024, 8, 64]);  view_default_26 = None
        transpose_int_10 = torch.ops.aten.transpose.int(view_default_27, 1, 2);  view_default_27 = None
        clone_default_8 = torch.ops.aten.clone.default(transpose_int_10, memory_format = torch.contiguous_format);  transpose_int_10 = None
        _unsafe_view_default_20 = torch.ops.aten._unsafe_view.default(clone_default_8, [64, 1024, 64]);  clone_default_8 = None
        transpose_int_11 = torch.ops.aten.transpose.int(view_default_15, 1, 2);  view_default_15 = None
        bmm_default_4 = torch.ops.aten.bmm.default(transpose_int_11, _unsafe_view_default_20);  transpose_int_11 = None
        transpose_int_12 = torch.ops.aten.transpose.int(_unsafe_view_default_15, 1, 2);  _unsafe_view_default_15 = None
        bmm_default_5 = torch.ops.aten.bmm.default(_unsafe_view_default_20, transpose_int_12);  _unsafe_view_default_20 = transpose_int_12 = None
        view_default_28 = torch.ops.aten.view.default(bmm_default_4, [8, 8, 1024, 64]);  bmm_default_4 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(tangents_5, view_default_28);  tangents_5 = view_default_28 = None
        view_default_29 = torch.ops.aten.view.default(bmm_default_5, [8, 8, 1024, 1024]);  bmm_default_5 = None
        _softmax_backward_data_default = torch.ops.aten._softmax_backward_data.default(view_default_29, _softmax_default_1, -1, torch.float32);  view_default_29 = _softmax_default_1 = None
        view_default_30 = torch.ops.aten.view.default(_softmax_backward_data_default, [64, 1024, 1024])
        transpose_int_13 = torch.ops.aten.transpose.int(_unsafe_view_default_12, 1, 2);  _unsafe_view_default_12 = None
        bmm_default_6 = torch.ops.aten.bmm.default(transpose_int_13, view_default_30);  transpose_int_13 = None
        transpose_int_14 = torch.ops.aten.transpose.int(_unsafe_view_default_13, 1, 2);  _unsafe_view_default_13 = None
        bmm_default_7 = torch.ops.aten.bmm.default(view_default_30, transpose_int_14);  view_default_30 = transpose_int_14 = None
        view_default_31 = torch.ops.aten.view.default(bmm_default_6, [8, 8, 64, 1024]);  bmm_default_6 = None
        view_default_32 = torch.ops.aten.view.default(bmm_default_7, [8, 8, 1024, 64]);  bmm_default_7 = None
        transpose_int_15 = torch.ops.aten.transpose.int(view_default_31, 3, 2);  view_default_31 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(tangents_4, transpose_int_15);  tangents_4 = transpose_int_15 = None
        transpose_int_16 = torch.ops.aten.transpose.int(add_tensor_8, 1, 2);  add_tensor_8 = None
        clone_default_9 = torch.ops.aten.clone.default(transpose_int_16, memory_format = torch.contiguous_format);  transpose_int_16 = None
        _unsafe_view_default_21 = torch.ops.aten._unsafe_view.default(clone_default_9, [8, 1024, 512]);  clone_default_9 = None
        view_default_33 = torch.ops.aten.view.default(_unsafe_view_default_21, [8192, 512]);  _unsafe_view_default_21 = None
        t_default_22 = torch.ops.aten.t.default(view_default_33)
        mm_default_16 = torch.ops.aten.mm.default(t_default_22, view_default_13);  t_default_22 = view_default_13 = None
        t_default_23 = torch.ops.aten.t.default(mm_default_16);  mm_default_16 = None
        t_default_24 = torch.ops.aten.t.default(t_default_6);  t_default_6 = None
        mm_default_17 = torch.ops.aten.mm.default(view_default_33, t_default_24);  view_default_33 = t_default_24 = None
        view_default_34 = torch.ops.aten.view.default(mm_default_17, [8, 1024, 512]);  mm_default_17 = None
        t_default_25 = torch.ops.aten.t.default(t_default_23);  t_default_23 = None
        transpose_int_17 = torch.ops.aten.transpose.int(add_tensor_9, 1, 2);  add_tensor_9 = None
        clone_default_10 = torch.ops.aten.clone.default(transpose_int_17, memory_format = torch.contiguous_format);  transpose_int_17 = None
        _unsafe_view_default_22 = torch.ops.aten._unsafe_view.default(clone_default_10, [8, 1024, 512]);  clone_default_10 = None
        view_default_35 = torch.ops.aten.view.default(_unsafe_view_default_22, [8192, 512]);  _unsafe_view_default_22 = None
        t_default_26 = torch.ops.aten.t.default(view_default_35)
        mm_default_18 = torch.ops.aten.mm.default(t_default_26, view_default_11);  t_default_26 = view_default_11 = None
        t_default_27 = torch.ops.aten.t.default(mm_default_18);  mm_default_18 = None
        t_default_28 = torch.ops.aten.t.default(t_default_5);  t_default_5 = None
        mm_default_19 = torch.ops.aten.mm.default(view_default_35, t_default_28);  view_default_35 = t_default_28 = None
        view_default_36 = torch.ops.aten.view.default(mm_default_19, [8, 1024, 512]);  mm_default_19 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(view_default_34, view_default_36);  view_default_34 = view_default_36 = None
        t_default_29 = torch.ops.aten.t.default(t_default_27);  t_default_27 = None
        transpose_int_18 = torch.ops.aten.transpose.int(view_default_32, 1, 2);  view_default_32 = None
        clone_default_11 = torch.ops.aten.clone.default(transpose_int_18, memory_format = torch.contiguous_format);  transpose_int_18 = None
        _unsafe_view_default_23 = torch.ops.aten._unsafe_view.default(clone_default_11, [8, 1024, 512]);  clone_default_11 = None
        view_default_37 = torch.ops.aten.view.default(_unsafe_view_default_23, [8192, 512]);  _unsafe_view_default_23 = None
        t_default_30 = torch.ops.aten.t.default(view_default_37)
        mm_default_20 = torch.ops.aten.mm.default(t_default_30, view_default_9);  t_default_30 = view_default_9 = None
        t_default_31 = torch.ops.aten.t.default(mm_default_20);  mm_default_20 = None
        t_default_32 = torch.ops.aten.t.default(t_default_4);  t_default_4 = None
        mm_default_21 = torch.ops.aten.mm.default(view_default_37, t_default_32);  view_default_37 = t_default_32 = None
        view_default_38 = torch.ops.aten.view.default(mm_default_21, [8, 1024, 512]);  mm_default_21 = None
        t_default_33 = torch.ops.aten.t.default(t_default_31);  t_default_31 = None
        mul_tensor_12 = torch.ops.aten.mul.Tensor(view_default_38, primals_10);  primals_10 = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(view_default_38, mul_tensor_2);  view_default_38 = mul_tensor_2 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(mul_tensor_13, [0, 1], True);  mul_tensor_13 = None
        view_default_39 = torch.ops.aten.view.default(sum_dim_int_list_2, [512]);  sum_dim_int_list_2 = None
        mul_tensor_14 = torch.ops.aten.mul.Tensor(mul_tensor_12, add_tensor_1)
        mul_tensor_15 = torch.ops.aten.mul.Tensor(mul_tensor_12, rsqrt_default_1);  mul_tensor_12 = None
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(mul_tensor_14, [2], True);  mul_tensor_14 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(add_tensor_7, mul_tensor_15);  add_tensor_7 = mul_tensor_15 = None
        mul_scalar_2 = torch.ops.aten.mul.Scalar(sum_dim_int_list_3, -0.5);  sum_dim_int_list_3 = None
        pow_tensor_scalar_5 = torch.ops.aten.pow.Tensor_Scalar(rsqrt_default_1, 3);  rsqrt_default_1 = None
        mul_tensor_16 = torch.ops.aten.mul.Tensor(mul_scalar_2, pow_tensor_scalar_5);  mul_scalar_2 = pow_tensor_scalar_5 = None
        expand_default_9 = torch.ops.aten.expand.default(mul_tensor_16, [8, 1024, 512]);  mul_tensor_16 = None
        div_scalar_1 = torch.ops.aten.div.Scalar(expand_default_9, 512);  expand_default_9 = None
        pow_tensor_scalar_6 = torch.ops.aten.pow.Tensor_Scalar(add_tensor_1, 1.0);  add_tensor_1 = None
        mul_scalar_3 = torch.ops.aten.mul.Scalar(pow_tensor_scalar_6, 2.0);  pow_tensor_scalar_6 = None
        mul_tensor_17 = torch.ops.aten.mul.Tensor(div_scalar_1, mul_scalar_3);  div_scalar_1 = mul_scalar_3 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(add_tensor_11, mul_tensor_17);  add_tensor_11 = mul_tensor_17 = None
        view_default_40 = torch.ops.aten.view.default(add_tensor_12, [8192, 512])
        t_default_34 = torch.ops.aten.t.default(view_default_40)
        mm_default_22 = torch.ops.aten.mm.default(t_default_34, view_default_8);  t_default_34 = view_default_8 = None
        t_default_35 = torch.ops.aten.t.default(mm_default_22);  mm_default_22 = None
        t_default_36 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        mm_default_23 = torch.ops.aten.mm.default(view_default_40, t_default_36);  view_default_40 = t_default_36 = None
        view_default_41 = torch.ops.aten.view.default(mm_default_23, [8, 1024, 512]);  mm_default_23 = None
        t_default_37 = torch.ops.aten.t.default(t_default_35);  t_default_35 = None
        view_default_42 = torch.ops.aten.view.default(view_default_41, [8, 1024, 8, 64]);  view_default_41 = None
        transpose_int_19 = torch.ops.aten.transpose.int(view_default_42, 1, 2);  view_default_42 = None
        clone_default_12 = torch.ops.aten.clone.default(transpose_int_19, memory_format = torch.contiguous_format);  transpose_int_19 = None
        _unsafe_view_default_24 = torch.ops.aten._unsafe_view.default(clone_default_12, [64, 1024, 64]);  clone_default_12 = None
        transpose_int_20 = torch.ops.aten.transpose.int(view_default_6, 1, 2);  view_default_6 = None
        bmm_default_8 = torch.ops.aten.bmm.default(transpose_int_20, _unsafe_view_default_24);  transpose_int_20 = None
        transpose_int_21 = torch.ops.aten.transpose.int(_unsafe_view_default_6, 1, 2);  _unsafe_view_default_6 = None
        bmm_default_9 = torch.ops.aten.bmm.default(_unsafe_view_default_24, transpose_int_21);  _unsafe_view_default_24 = transpose_int_21 = None
        view_default_43 = torch.ops.aten.view.default(bmm_default_8, [8, 8, 1024, 64]);  bmm_default_8 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(tangents_3, view_default_43);  tangents_3 = view_default_43 = None
        view_default_44 = torch.ops.aten.view.default(bmm_default_9, [8, 8, 1024, 1024]);  bmm_default_9 = None
        _softmax_backward_data_default_1 = torch.ops.aten._softmax_backward_data.default(view_default_44, _softmax_default, -1, torch.float32);  view_default_44 = _softmax_default = None
        view_default_45 = torch.ops.aten.view.default(_softmax_backward_data_default_1, [64, 1024, 1024])
        transpose_int_22 = torch.ops.aten.transpose.int(_unsafe_view_default_3, 1, 2);  _unsafe_view_default_3 = None
        bmm_default_10 = torch.ops.aten.bmm.default(transpose_int_22, view_default_45);  transpose_int_22 = None
        transpose_int_23 = torch.ops.aten.transpose.int(_unsafe_view_default_4, 1, 2);  _unsafe_view_default_4 = None
        bmm_default_11 = torch.ops.aten.bmm.default(view_default_45, transpose_int_23);  view_default_45 = transpose_int_23 = None
        view_default_46 = torch.ops.aten.view.default(bmm_default_10, [8, 8, 64, 1024]);  bmm_default_10 = None
        view_default_47 = torch.ops.aten.view.default(bmm_default_11, [8, 8, 1024, 64]);  bmm_default_11 = None
        transpose_int_24 = torch.ops.aten.transpose.int(view_default_46, 3, 2);  view_default_46 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(tangents_2, transpose_int_24);  tangents_2 = transpose_int_24 = None
        transpose_int_25 = torch.ops.aten.transpose.int(add_tensor_13, 1, 2);  add_tensor_13 = None
        clone_default_13 = torch.ops.aten.clone.default(transpose_int_25, memory_format = torch.contiguous_format);  transpose_int_25 = None
        _unsafe_view_default_25 = torch.ops.aten._unsafe_view.default(clone_default_13, [8, 1024, 512]);  clone_default_13 = None
        view_default_48 = torch.ops.aten.view.default(_unsafe_view_default_25, [8192, 512]);  _unsafe_view_default_25 = None
        t_default_38 = torch.ops.aten.t.default(view_default_48)
        mm_default_24 = torch.ops.aten.mm.default(t_default_38, view_default_4);  t_default_38 = view_default_4 = None
        t_default_39 = torch.ops.aten.t.default(mm_default_24);  mm_default_24 = None
        t_default_40 = torch.ops.aten.t.default(t_default_2);  t_default_2 = None
        mm_default_25 = torch.ops.aten.mm.default(view_default_48, t_default_40);  view_default_48 = t_default_40 = None
        view_default_49 = torch.ops.aten.view.default(mm_default_25, [8, 1024, 512]);  mm_default_25 = None
        t_default_41 = torch.ops.aten.t.default(t_default_39);  t_default_39 = None
        transpose_int_26 = torch.ops.aten.transpose.int(add_tensor_14, 1, 2);  add_tensor_14 = None
        clone_default_14 = torch.ops.aten.clone.default(transpose_int_26, memory_format = torch.contiguous_format);  transpose_int_26 = None
        _unsafe_view_default_26 = torch.ops.aten._unsafe_view.default(clone_default_14, [8, 1024, 512]);  clone_default_14 = None
        view_default_50 = torch.ops.aten.view.default(_unsafe_view_default_26, [8192, 512]);  _unsafe_view_default_26 = None
        t_default_42 = torch.ops.aten.t.default(view_default_50)
        mm_default_26 = torch.ops.aten.mm.default(t_default_42, view_default_2);  t_default_42 = view_default_2 = None
        t_default_43 = torch.ops.aten.t.default(mm_default_26);  mm_default_26 = None
        t_default_44 = torch.ops.aten.t.default(t_default_1);  t_default_1 = None
        mm_default_27 = torch.ops.aten.mm.default(view_default_50, t_default_44);  view_default_50 = t_default_44 = None
        view_default_51 = torch.ops.aten.view.default(mm_default_27, [8, 1024, 512]);  mm_default_27 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(view_default_49, view_default_51);  view_default_49 = view_default_51 = None
        t_default_45 = torch.ops.aten.t.default(t_default_43);  t_default_43 = None
        transpose_int_27 = torch.ops.aten.transpose.int(view_default_47, 1, 2);  view_default_47 = None
        clone_default_15 = torch.ops.aten.clone.default(transpose_int_27, memory_format = torch.contiguous_format);  transpose_int_27 = None
        _unsafe_view_default_27 = torch.ops.aten._unsafe_view.default(clone_default_15, [8, 1024, 512]);  clone_default_15 = None
        view_default_52 = torch.ops.aten.view.default(_unsafe_view_default_27, [8192, 512]);  _unsafe_view_default_27 = None
        t_default_46 = torch.ops.aten.t.default(view_default_52)
        mm_default_28 = torch.ops.aten.mm.default(t_default_46, view_default);  t_default_46 = view_default = None
        t_default_47 = torch.ops.aten.t.default(mm_default_28);  mm_default_28 = None
        t_default_48 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default_29 = torch.ops.aten.mm.default(view_default_52, t_default_48);  view_default_52 = t_default_48 = None
        view_default_53 = torch.ops.aten.view.default(mm_default_29, [8, 1024, 512]);  mm_default_29 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(add_tensor_15, view_default_53);  add_tensor_15 = view_default_53 = None
        t_default_49 = torch.ops.aten.t.default(t_default_47);  t_default_47 = None
        mul_tensor_18 = torch.ops.aten.mul.Tensor(add_tensor_16, primals_5);  primals_5 = None
        mul_tensor_19 = torch.ops.aten.mul.Tensor(add_tensor_16, mul_tensor);  add_tensor_16 = mul_tensor = None
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(mul_tensor_19, [0, 1], True);  mul_tensor_19 = None
        view_default_54 = torch.ops.aten.view.default(sum_dim_int_list_4, [512]);  sum_dim_int_list_4 = None
        mul_tensor_20 = torch.ops.aten.mul.Tensor(mul_tensor_18, primals_14)
        mul_tensor_21 = torch.ops.aten.mul.Tensor(mul_tensor_18, rsqrt_default);  mul_tensor_18 = None
        sum_dim_int_list_5 = torch.ops.aten.sum.dim_IntList(mul_tensor_20, [2], True);  mul_tensor_20 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(add_tensor_12, mul_tensor_21);  add_tensor_12 = mul_tensor_21 = None
        mul_scalar_4 = torch.ops.aten.mul.Scalar(sum_dim_int_list_5, -0.5);  sum_dim_int_list_5 = None
        pow_tensor_scalar_7 = torch.ops.aten.pow.Tensor_Scalar(rsqrt_default, 3);  rsqrt_default = None
        mul_tensor_22 = torch.ops.aten.mul.Tensor(mul_scalar_4, pow_tensor_scalar_7);  mul_scalar_4 = pow_tensor_scalar_7 = None
        expand_default_10 = torch.ops.aten.expand.default(mul_tensor_22, [8, 1024, 512]);  mul_tensor_22 = None
        div_scalar_2 = torch.ops.aten.div.Scalar(expand_default_10, 512);  expand_default_10 = None
        pow_tensor_scalar_8 = torch.ops.aten.pow.Tensor_Scalar(primals_14, 1.0);  primals_14 = None
        mul_scalar_5 = torch.ops.aten.mul.Scalar(pow_tensor_scalar_8, 2.0);  pow_tensor_scalar_8 = None
        mul_tensor_23 = torch.ops.aten.mul.Tensor(div_scalar_2, mul_scalar_5);  div_scalar_2 = mul_scalar_5 = None
        add_tensor_18 = torch.ops.aten.add.Tensor(add_tensor_17, mul_tensor_23);  add_tensor_17 = mul_tensor_23 = None
        return [t_default_45, t_default_37, t_default_49, t_default_41, view_default_54, t_default_29, t_default_21, t_default_33, t_default_25, view_default_39, t_default_17, t_default_13, view_default_24, add_tensor_18, _softmax_backward_data_default_1, add_tensor_10, _softmax_backward_data_default]
        
