
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/hf_T5/hf_T5_backward_6/state_dict.pt'))

    
    
    def forward(self, rsqrt_default, primals_1, mul_tensor, primals_2, tangents_1):
        mul_tensor_2 = torch.ops.aten.mul.Tensor(tangents_1, primals_1);  primals_1 = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(tangents_1, mul_tensor);  tangents_1 = mul_tensor = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(mul_tensor_3, [0, 1], True);  mul_tensor_3 = None
        view_default = torch.ops.aten.view.default(sum_dim_int_list, [512]);  sum_dim_int_list = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(mul_tensor_2, primals_2)
        mul_tensor_5 = torch.ops.aten.mul.Tensor(mul_tensor_2, rsqrt_default);  mul_tensor_2 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(mul_tensor_4, [2], True);  mul_tensor_4 = None
        mul_scalar = torch.ops.aten.mul.Scalar(sum_dim_int_list_1, -0.5);  sum_dim_int_list_1 = None
        pow_tensor_scalar_1 = torch.ops.aten.pow.Tensor_Scalar(rsqrt_default, 3);  rsqrt_default = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(mul_scalar, pow_tensor_scalar_1);  mul_scalar = pow_tensor_scalar_1 = None
        expand_default = torch.ops.aten.expand.default(mul_tensor_6, [8, 1024, 512]);  mul_tensor_6 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 512);  expand_default = None
        pow_tensor_scalar_2 = torch.ops.aten.pow.Tensor_Scalar(primals_2, 1.0);  primals_2 = None
        mul_scalar_1 = torch.ops.aten.mul.Scalar(pow_tensor_scalar_2, 2.0);  pow_tensor_scalar_2 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(div_scalar, mul_scalar_1);  div_scalar = mul_scalar_1 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(mul_tensor_5, mul_tensor_7);  mul_tensor_5 = mul_tensor_7 = None
        return [view_default, add_tensor_1]
        
