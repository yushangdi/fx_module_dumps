
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/hf_T5/hf_T5_forward_9/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17):
        pow_tensor_scalar = torch.ops.aten.pow.Tensor_Scalar(primals_14, 2)
        mean_dim = torch.ops.aten.mean.dim(pow_tensor_scalar, [-1], True);  pow_tensor_scalar = None
        add_tensor = torch.ops.aten.add.Tensor(mean_dim, 1e-06);  mean_dim = None
        rsqrt_default = torch.ops.aten.rsqrt.default(add_tensor);  add_tensor = None
        mul_tensor = torch.ops.aten.mul.Tensor(primals_14, rsqrt_default)
        mul_tensor_1 = torch.ops.aten.mul.Tensor(primals_5, mul_tensor)
        t_default = torch.ops.aten.t.default(primals_3);  primals_3 = None
        view_default = torch.ops.aten.view.default(mul_tensor_1, [8192, 512])
        mm_default = torch.ops.aten.mm.default(view_default, t_default)
        _unsafe_view_default = torch.ops.aten._unsafe_view.default(mm_default, [8, 1024, 512]);  mm_default = None
        view_default_1 = torch.ops.aten.view.default(_unsafe_view_default, [8, -1, 8, 64]);  _unsafe_view_default = None
        transpose_int = torch.ops.aten.transpose.int(view_default_1, 1, 2);  view_default_1 = None
        t_default_1 = torch.ops.aten.t.default(primals_1);  primals_1 = None
        view_default_2 = torch.ops.aten.view.default(mul_tensor_1, [8192, 512])
        mm_default_1 = torch.ops.aten.mm.default(view_default_2, t_default_1)
        _unsafe_view_default_1 = torch.ops.aten._unsafe_view.default(mm_default_1, [8, 1024, 512]);  mm_default_1 = None
        view_default_3 = torch.ops.aten.view.default(_unsafe_view_default_1, [8, -1, 8, 64]);  _unsafe_view_default_1 = None
        transpose_int_1 = torch.ops.aten.transpose.int(view_default_3, 1, 2);  view_default_3 = None
        t_default_2 = torch.ops.aten.t.default(primals_4);  primals_4 = None
        view_default_4 = torch.ops.aten.view.default(mul_tensor_1, [8192, 512]);  mul_tensor_1 = None
        mm_default_2 = torch.ops.aten.mm.default(view_default_4, t_default_2)
        _unsafe_view_default_2 = torch.ops.aten._unsafe_view.default(mm_default_2, [8, 1024, 512]);  mm_default_2 = None
        view_default_5 = torch.ops.aten.view.default(_unsafe_view_default_2, [8, -1, 8, 64]);  _unsafe_view_default_2 = None
        transpose_int_2 = torch.ops.aten.transpose.int(view_default_5, 1, 2);  view_default_5 = None
        transpose_int_3 = torch.ops.aten.transpose.int(transpose_int_1, 3, 2)
        expand_default = torch.ops.aten.expand.default(transpose_int, [8, 8, 1024, 64]);  transpose_int = None
        clone_default = torch.ops.aten.clone.default(expand_default, memory_format = torch.contiguous_format);  expand_default = None
        _unsafe_view_default_3 = torch.ops.aten._unsafe_view.default(clone_default, [64, 1024, 64]);  clone_default = None
        expand_default_1 = torch.ops.aten.expand.default(transpose_int_3, [8, 8, 64, 1024]);  transpose_int_3 = None
        clone_default_1 = torch.ops.aten.clone.default(expand_default_1, memory_format = torch.contiguous_format);  expand_default_1 = None
        _unsafe_view_default_4 = torch.ops.aten._unsafe_view.default(clone_default_1, [64, 64, 1024]);  clone_default_1 = None
        bmm_default = torch.ops.aten.bmm.default(_unsafe_view_default_3, _unsafe_view_default_4)
        _unsafe_view_default_5 = torch.ops.aten._unsafe_view.default(bmm_default, [8, 8, 1024, 1024]);  bmm_default = None
        add__tensor = torch.ops.aten.add_.Tensor(_unsafe_view_default_5, primals_15);  _unsafe_view_default_5 = primals_15 = None
        _softmax_default = torch.ops.aten._softmax.default(add__tensor, -1, False);  add__tensor = None
        expand_default_2 = torch.ops.aten.expand.default(_softmax_default, [8, 8, 1024, 1024])
        view_default_6 = torch.ops.aten.view.default(expand_default_2, [64, 1024, 1024]);  expand_default_2 = None
        expand_default_3 = torch.ops.aten.expand.default(transpose_int_2, [8, 8, 1024, 64])
        clone_default_2 = torch.ops.aten.clone.default(expand_default_3, memory_format = torch.contiguous_format);  expand_default_3 = None
        _unsafe_view_default_6 = torch.ops.aten._unsafe_view.default(clone_default_2, [64, 1024, 64]);  clone_default_2 = None
        bmm_default_1 = torch.ops.aten.bmm.default(view_default_6, _unsafe_view_default_6)
        _unsafe_view_default_7 = torch.ops.aten._unsafe_view.default(bmm_default_1, [8, 8, 1024, 64]);  bmm_default_1 = None
        transpose_int_4 = torch.ops.aten.transpose.int(_unsafe_view_default_7, 1, 2);  _unsafe_view_default_7 = None
        clone_default_3 = torch.ops.aten.clone.default(transpose_int_4, memory_format = torch.contiguous_format);  transpose_int_4 = None
        view_default_7 = torch.ops.aten.view.default(clone_default_3, [8, -1, 512]);  clone_default_3 = None
        t_default_3 = torch.ops.aten.t.default(primals_2);  primals_2 = None
        view_default_8 = torch.ops.aten.view.default(view_default_7, [8192, 512]);  view_default_7 = None
        mm_default_3 = torch.ops.aten.mm.default(view_default_8, t_default_3)
        _unsafe_view_default_8 = torch.ops.aten._unsafe_view.default(mm_default_3, [8, 1024, 512]);  mm_default_3 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(primals_14, _unsafe_view_default_8);  _unsafe_view_default_8 = None
        pow_tensor_scalar_1 = torch.ops.aten.pow.Tensor_Scalar(add_tensor_1, 2)
        mean_dim_1 = torch.ops.aten.mean.dim(pow_tensor_scalar_1, [-1], True);  pow_tensor_scalar_1 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(mean_dim_1, 1e-06);  mean_dim_1 = None
        rsqrt_default_1 = torch.ops.aten.rsqrt.default(add_tensor_2);  add_tensor_2 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(add_tensor_1, rsqrt_default_1)
        mul_tensor_3 = torch.ops.aten.mul.Tensor(primals_10, mul_tensor_2)
        t_default_4 = torch.ops.aten.t.default(primals_8);  primals_8 = None
        view_default_9 = torch.ops.aten.view.default(mul_tensor_3, [8192, 512]);  mul_tensor_3 = None
        mm_default_4 = torch.ops.aten.mm.default(view_default_9, t_default_4)
        _unsafe_view_default_9 = torch.ops.aten._unsafe_view.default(mm_default_4, [8, 1024, 512]);  mm_default_4 = None
        view_default_10 = torch.ops.aten.view.default(_unsafe_view_default_9, [8, -1, 8, 64]);  _unsafe_view_default_9 = None
        transpose_int_5 = torch.ops.aten.transpose.int(view_default_10, 1, 2);  view_default_10 = None
        t_default_5 = torch.ops.aten.t.default(primals_6);  primals_6 = None
        view_default_11 = torch.ops.aten.view.default(primals_16, [8192, 512])
        mm_default_5 = torch.ops.aten.mm.default(view_default_11, t_default_5)
        _unsafe_view_default_10 = torch.ops.aten._unsafe_view.default(mm_default_5, [8, 1024, 512]);  mm_default_5 = None
        view_default_12 = torch.ops.aten.view.default(_unsafe_view_default_10, [8, -1, 8, 64]);  _unsafe_view_default_10 = None
        transpose_int_6 = torch.ops.aten.transpose.int(view_default_12, 1, 2);  view_default_12 = None
        t_default_6 = torch.ops.aten.t.default(primals_9);  primals_9 = None
        view_default_13 = torch.ops.aten.view.default(primals_16, [8192, 512]);  primals_16 = None
        mm_default_6 = torch.ops.aten.mm.default(view_default_13, t_default_6)
        _unsafe_view_default_11 = torch.ops.aten._unsafe_view.default(mm_default_6, [8, 1024, 512]);  mm_default_6 = None
        view_default_14 = torch.ops.aten.view.default(_unsafe_view_default_11, [8, -1, 8, 64]);  _unsafe_view_default_11 = None
        transpose_int_7 = torch.ops.aten.transpose.int(view_default_14, 1, 2);  view_default_14 = None
        transpose_int_8 = torch.ops.aten.transpose.int(transpose_int_6, 3, 2)
        expand_default_4 = torch.ops.aten.expand.default(transpose_int_5, [8, 8, 1024, 64]);  transpose_int_5 = None
        clone_default_4 = torch.ops.aten.clone.default(expand_default_4, memory_format = torch.contiguous_format);  expand_default_4 = None
        _unsafe_view_default_12 = torch.ops.aten._unsafe_view.default(clone_default_4, [64, 1024, 64]);  clone_default_4 = None
        expand_default_5 = torch.ops.aten.expand.default(transpose_int_8, [8, 8, 64, 1024]);  transpose_int_8 = None
        clone_default_5 = torch.ops.aten.clone.default(expand_default_5, memory_format = torch.contiguous_format);  expand_default_5 = None
        _unsafe_view_default_13 = torch.ops.aten._unsafe_view.default(clone_default_5, [64, 64, 1024]);  clone_default_5 = None
        bmm_default_2 = torch.ops.aten.bmm.default(_unsafe_view_default_12, _unsafe_view_default_13)
        _unsafe_view_default_14 = torch.ops.aten._unsafe_view.default(bmm_default_2, [8, 8, 1024, 1024]);  bmm_default_2 = None
        add__tensor_1 = torch.ops.aten.add_.Tensor(_unsafe_view_default_14, primals_17);  _unsafe_view_default_14 = primals_17 = None
        _softmax_default_1 = torch.ops.aten._softmax.default(add__tensor_1, -1, False);  add__tensor_1 = None
        expand_default_6 = torch.ops.aten.expand.default(_softmax_default_1, [8, 8, 1024, 1024])
        view_default_15 = torch.ops.aten.view.default(expand_default_6, [64, 1024, 1024]);  expand_default_6 = None
        expand_default_7 = torch.ops.aten.expand.default(transpose_int_7, [8, 8, 1024, 64])
        clone_default_6 = torch.ops.aten.clone.default(expand_default_7, memory_format = torch.contiguous_format);  expand_default_7 = None
        _unsafe_view_default_15 = torch.ops.aten._unsafe_view.default(clone_default_6, [64, 1024, 64]);  clone_default_6 = None
        bmm_default_3 = torch.ops.aten.bmm.default(view_default_15, _unsafe_view_default_15)
        _unsafe_view_default_16 = torch.ops.aten._unsafe_view.default(bmm_default_3, [8, 8, 1024, 64]);  bmm_default_3 = None
        transpose_int_9 = torch.ops.aten.transpose.int(_unsafe_view_default_16, 1, 2);  _unsafe_view_default_16 = None
        clone_default_7 = torch.ops.aten.clone.default(transpose_int_9, memory_format = torch.contiguous_format);  transpose_int_9 = None
        view_default_16 = torch.ops.aten.view.default(clone_default_7, [8, -1, 512]);  clone_default_7 = None
        t_default_7 = torch.ops.aten.t.default(primals_7);  primals_7 = None
        view_default_17 = torch.ops.aten.view.default(view_default_16, [8192, 512]);  view_default_16 = None
        mm_default_7 = torch.ops.aten.mm.default(view_default_17, t_default_7)
        _unsafe_view_default_17 = torch.ops.aten._unsafe_view.default(mm_default_7, [8, 1024, 512]);  mm_default_7 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(add_tensor_1, _unsafe_view_default_17);  _unsafe_view_default_17 = None
        pow_tensor_scalar_2 = torch.ops.aten.pow.Tensor_Scalar(add_tensor_3, 2)
        mean_dim_2 = torch.ops.aten.mean.dim(pow_tensor_scalar_2, [-1], True);  pow_tensor_scalar_2 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(mean_dim_2, 1e-06);  mean_dim_2 = None
        rsqrt_default_2 = torch.ops.aten.rsqrt.default(add_tensor_4);  add_tensor_4 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(add_tensor_3, rsqrt_default_2)
        mul_tensor_5 = torch.ops.aten.mul.Tensor(primals_13, mul_tensor_4)
        t_default_8 = torch.ops.aten.t.default(primals_11);  primals_11 = None
        view_default_18 = torch.ops.aten.view.default(mul_tensor_5, [8192, 512]);  mul_tensor_5 = None
        mm_default_8 = torch.ops.aten.mm.default(view_default_18, t_default_8)
        _unsafe_view_default_18 = torch.ops.aten._unsafe_view.default(mm_default_8, [8, 1024, 2048]);  mm_default_8 = None
        relu_default = torch.ops.aten.relu.default(_unsafe_view_default_18);  _unsafe_view_default_18 = None
        t_default_9 = torch.ops.aten.t.default(primals_12);  primals_12 = None
        view_default_19 = torch.ops.aten.view.default(relu_default, [8192, 2048])
        mm_default_9 = torch.ops.aten.mm.default(view_default_19, t_default_9)
        _unsafe_view_default_19 = torch.ops.aten._unsafe_view.default(mm_default_9, [8, 1024, 512]);  mm_default_9 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(add_tensor_3, _unsafe_view_default_19);  _unsafe_view_default_19 = None
        return [add_tensor_5, transpose_int_1, transpose_int_2, transpose_int_6, transpose_int_7, view_default, view_default_9, t_default_6, view_default_17, t_default_5, rsqrt_default_2, t_default_4, relu_default, mul_tensor_2, t_default_7, mul_tensor_4, add_tensor_3, add_tensor_1, view_default_15, view_default_11, view_default_8, t_default_8, rsqrt_default_1, view_default_13, view_default_18, _unsafe_view_default_12, _softmax_default_1, t_default_3, view_default_19, t_default_9, mul_tensor, primals_10, _unsafe_view_default_4, primals_13, _softmax_default, primals_14, view_default_2, _unsafe_view_default_13, _unsafe_view_default_6, rsqrt_default, t_default_2, t_default_1, view_default_6, _unsafe_view_default_3, primals_5, t_default, _unsafe_view_default_15, view_default_4]
        
