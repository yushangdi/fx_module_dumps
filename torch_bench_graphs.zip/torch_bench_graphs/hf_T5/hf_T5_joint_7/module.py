
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/hf_T5/hf_T5_joint_7/state_dict.pt'))

    
    
    def forward(self, primals_1, tangents_1):
        slice_tensor = torch.ops.aten.slice.Tensor(primals_1, 0, 0, 9223372036854775807);  primals_1 = None
        unsqueeze_default = torch.ops.aten.unsqueeze.default(slice_tensor, 1);  slice_tensor = None
        unsqueeze_default_1 = torch.ops.aten.unsqueeze.default(unsqueeze_default, 2);  unsqueeze_default = None
        slice_tensor_1 = torch.ops.aten.slice.Tensor(unsqueeze_default_1, 3, 0, 9223372036854775807);  unsqueeze_default_1 = None
        _to_copy_default = torch.ops.aten._to_copy.default(slice_tensor_1, dtype = torch.float32);  slice_tensor_1 = None
        rsub_scalar = torch.ops.aten.rsub.Scalar(_to_copy_default, 1.0);  _to_copy_default = None
        mul_tensor = torch.ops.aten.mul.Tensor(rsub_scalar, -1000000000.0);  rsub_scalar = None
        return [mul_tensor, None]
        
