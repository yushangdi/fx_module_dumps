
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/squeezenet1_1/squeezenet1_1_backward_0/state_dict.pt'))

    
    
    def forward(self, primals_42, primals_46, relu__default_23, primals_44, relu__default_13, relu__default_24, relu__default_14, cat_default_7, relu__default_15, primals_53, primals_22, cat_default_4, relu__default_25, primals_26, primals_10, primals_48, primals_30, relu__default_16, primals_24, primals_28, relu__default_17, primals_40, primals_16, getitem_1, cat_default_1, getitem, relu__default_9, relu__default_18, relu__default, relu__default_5, primals_8, primals_6, primals_34, cat_default_2, primals_12, primals_20, cat_default_5, primals_36, primals_52, relu__default_6, relu__default_19, relu__default_4, relu__default_10, relu__default_20, getitem_3, relu__default_1, relu__default_11, primals_4, cat_default_6, primals_18, primals_50, getitem_2, getitem_5, relu__default_2, primals_2, cat_default_3, primals_14, relu__default_12, relu__default_21, relu__default_3, relu__default_7, cat_default, relu__default_22, primals_32, primals_38, getitem_4, relu__default_8, tangents_1):
        view_default_1 = torch.ops.aten.view.default(tangents_1, [32, 1000, 1, 1]);  tangents_1 = None
        expand_default = torch.ops.aten.expand.default(view_default_1, [32, 1000, 13, 13]);  view_default_1 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 169);  expand_default = None
        to_dtype = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default_25, torch.float32);  relu__default_25 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default, to_dtype);  le_scalar = new_zeros_default = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(to_dtype_2, cat_default_7, primals_2, [1000], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_2 = cat_default_7 = primals_2 = None
        getitem_6 = convolution_backward_default[0]
        getitem_7 = convolution_backward_default[1]
        getitem_8 = convolution_backward_default[2];  convolution_backward_default = None
        slice_tensor = torch.ops.aten.slice.Tensor(getitem_6, 1, 0, 256)
        slice_tensor_1 = torch.ops.aten.slice.Tensor(getitem_6, 1, 256, 512);  getitem_6 = None
        to_dtype_3 = torch.ops.aten.to.dtype(slice_tensor_1, torch.float32);  slice_tensor_1 = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu__default_24, torch.float32);  relu__default_24 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_1, to_dtype_3);  le_scalar_1 = new_zeros_default_1 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(to_dtype_5, relu__default_22, primals_20, [256], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_5 = primals_20 = None
        getitem_9 = convolution_backward_default_1[0]
        getitem_10 = convolution_backward_default_1[1]
        getitem_11 = convolution_backward_default_1[2];  convolution_backward_default_1 = None
        to_dtype_6 = torch.ops.aten.to.dtype(slice_tensor, torch.float32);  slice_tensor = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_23, torch.float32);  relu__default_23 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_2 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_2, to_dtype_6);  le_scalar_2 = new_zeros_default_2 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(to_dtype_8, relu__default_22, primals_18, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_8 = primals_18 = None
        getitem_12 = convolution_backward_default_2[0]
        getitem_13 = convolution_backward_default_2[1]
        getitem_14 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        add_tensor = torch.ops.aten.add.Tensor(getitem_9, getitem_12);  getitem_9 = getitem_12 = None
        to_dtype_9 = torch.ops.aten.to.dtype(add_tensor, torch.float32);  add_tensor = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu__default_22, torch.float32);  relu__default_22 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_3, to_dtype_9);  le_scalar_3 = new_zeros_default_3 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(to_dtype_11, cat_default_6, primals_22, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_11 = cat_default_6 = primals_22 = None
        getitem_15 = convolution_backward_default_3[0]
        getitem_16 = convolution_backward_default_3[1]
        getitem_17 = convolution_backward_default_3[2];  convolution_backward_default_3 = None
        slice_tensor_2 = torch.ops.aten.slice.Tensor(getitem_15, 1, 0, 256)
        slice_tensor_3 = torch.ops.aten.slice.Tensor(getitem_15, 1, 256, 512);  getitem_15 = None
        to_dtype_12 = torch.ops.aten.to.dtype(slice_tensor_3, torch.float32);  slice_tensor_3 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_21, torch.float32);  relu__default_21 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_4, to_dtype_12);  le_scalar_4 = new_zeros_default_4 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(to_dtype_14, relu__default_19, primals_14, [256], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_14 = primals_14 = None
        getitem_18 = convolution_backward_default_4[0]
        getitem_19 = convolution_backward_default_4[1]
        getitem_20 = convolution_backward_default_4[2];  convolution_backward_default_4 = None
        to_dtype_15 = torch.ops.aten.to.dtype(slice_tensor_2, torch.float32);  slice_tensor_2 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu__default_20, torch.float32);  relu__default_20 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_5 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_5, to_dtype_15);  le_scalar_5 = new_zeros_default_5 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(to_dtype_17, relu__default_19, primals_12, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_17 = primals_12 = None
        getitem_21 = convolution_backward_default_5[0]
        getitem_22 = convolution_backward_default_5[1]
        getitem_23 = convolution_backward_default_5[2];  convolution_backward_default_5 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(getitem_18, getitem_21);  getitem_18 = getitem_21 = None
        to_dtype_18 = torch.ops.aten.to.dtype(add_tensor_1, torch.float32);  add_tensor_1 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu__default_19, torch.float32);  relu__default_19 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_6, to_dtype_18);  le_scalar_6 = new_zeros_default_6 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(to_dtype_20, cat_default_5, primals_16, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_20 = cat_default_5 = primals_16 = None
        getitem_24 = convolution_backward_default_6[0]
        getitem_25 = convolution_backward_default_6[1]
        getitem_26 = convolution_backward_default_6[2];  convolution_backward_default_6 = None
        slice_tensor_4 = torch.ops.aten.slice.Tensor(getitem_24, 1, 0, 192)
        slice_tensor_5 = torch.ops.aten.slice.Tensor(getitem_24, 1, 192, 384);  getitem_24 = None
        to_dtype_21 = torch.ops.aten.to.dtype(slice_tensor_5, torch.float32);  slice_tensor_5 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_18, torch.float32);  relu__default_18 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_7, to_dtype_21);  le_scalar_7 = new_zeros_default_7 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(to_dtype_23, relu__default_16, primals_8, [192], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_23 = primals_8 = None
        getitem_27 = convolution_backward_default_7[0]
        getitem_28 = convolution_backward_default_7[1]
        getitem_29 = convolution_backward_default_7[2];  convolution_backward_default_7 = None
        to_dtype_24 = torch.ops.aten.to.dtype(slice_tensor_4, torch.float32);  slice_tensor_4 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_17, torch.float32);  relu__default_17 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_8 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_8, to_dtype_24);  le_scalar_8 = new_zeros_default_8 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(to_dtype_26, relu__default_16, primals_6, [192], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_26 = primals_6 = None
        getitem_30 = convolution_backward_default_8[0]
        getitem_31 = convolution_backward_default_8[1]
        getitem_32 = convolution_backward_default_8[2];  convolution_backward_default_8 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(getitem_27, getitem_30);  getitem_27 = getitem_30 = None
        to_dtype_27 = torch.ops.aten.to.dtype(add_tensor_2, torch.float32);  add_tensor_2 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu__default_16, torch.float32);  relu__default_16 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_9 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_9, to_dtype_27);  le_scalar_9 = new_zeros_default_9 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(to_dtype_29, cat_default_4, primals_10, [48], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_29 = cat_default_4 = primals_10 = None
        getitem_33 = convolution_backward_default_9[0]
        getitem_34 = convolution_backward_default_9[1]
        getitem_35 = convolution_backward_default_9[2];  convolution_backward_default_9 = None
        slice_tensor_6 = torch.ops.aten.slice.Tensor(getitem_33, 1, 0, 192)
        slice_tensor_7 = torch.ops.aten.slice.Tensor(getitem_33, 1, 192, 384);  getitem_33 = None
        to_dtype_30 = torch.ops.aten.to.dtype(slice_tensor_7, torch.float32);  slice_tensor_7 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu__default_15, torch.float32);  relu__default_15 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_10 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_10, to_dtype_30);  le_scalar_10 = new_zeros_default_10 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(to_dtype_32, relu__default_13, primals_50, [192], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_32 = primals_50 = None
        getitem_36 = convolution_backward_default_10[0]
        getitem_37 = convolution_backward_default_10[1]
        getitem_38 = convolution_backward_default_10[2];  convolution_backward_default_10 = None
        to_dtype_33 = torch.ops.aten.to.dtype(slice_tensor_6, torch.float32);  slice_tensor_6 = None
        to_dtype_34 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        new_zeros_default_11 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_11, to_dtype_33);  le_scalar_11 = new_zeros_default_11 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(to_dtype_35, relu__default_13, primals_48, [192], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_35 = primals_48 = None
        getitem_39 = convolution_backward_default_11[0]
        getitem_40 = convolution_backward_default_11[1]
        getitem_41 = convolution_backward_default_11[2];  convolution_backward_default_11 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(getitem_36, getitem_39);  getitem_36 = getitem_39 = None
        to_dtype_36 = torch.ops.aten.to.dtype(add_tensor_3, torch.float32);  add_tensor_3 = None
        to_dtype_37 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        new_zeros_default_12 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_12, to_dtype_36);  le_scalar_12 = new_zeros_default_12 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(to_dtype_38, getitem_4, primals_52, [48], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_38 = getitem_4 = primals_52 = None
        getitem_42 = convolution_backward_default_12[0]
        getitem_43 = convolution_backward_default_12[1]
        getitem_44 = convolution_backward_default_12[2];  convolution_backward_default_12 = None
        max_pool2d_with_indices_backward_default = torch.ops.aten.max_pool2d_with_indices_backward.default(getitem_42, cat_default_3, [3, 3], [2, 2], [0, 0], [1, 1], True, getitem_5);  getitem_42 = cat_default_3 = getitem_5 = None
        slice_tensor_8 = torch.ops.aten.slice.Tensor(max_pool2d_with_indices_backward_default, 1, 0, 128)
        slice_tensor_9 = torch.ops.aten.slice.Tensor(max_pool2d_with_indices_backward_default, 1, 128, 256);  max_pool2d_with_indices_backward_default = None
        to_dtype_39 = torch.ops.aten.to.dtype(slice_tensor_9, torch.float32);  slice_tensor_9 = None
        to_dtype_40 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        new_zeros_default_13 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_13, to_dtype_39);  le_scalar_13 = new_zeros_default_13 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(to_dtype_41, relu__default_10, primals_44, [128], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_41 = primals_44 = None
        getitem_45 = convolution_backward_default_13[0]
        getitem_46 = convolution_backward_default_13[1]
        getitem_47 = convolution_backward_default_13[2];  convolution_backward_default_13 = None
        to_dtype_42 = torch.ops.aten.to.dtype(slice_tensor_8, torch.float32);  slice_tensor_8 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_14 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_14, to_dtype_42);  le_scalar_14 = new_zeros_default_14 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(to_dtype_44, relu__default_10, primals_42, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_44 = primals_42 = None
        getitem_48 = convolution_backward_default_14[0]
        getitem_49 = convolution_backward_default_14[1]
        getitem_50 = convolution_backward_default_14[2];  convolution_backward_default_14 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(getitem_45, getitem_48);  getitem_45 = getitem_48 = None
        to_dtype_45 = torch.ops.aten.to.dtype(add_tensor_4, torch.float32);  add_tensor_4 = None
        to_dtype_46 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_46, 0);  to_dtype_46 = None
        new_zeros_default_15 = torch.ops.aten.new_zeros.default(to_dtype_45, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_15, to_dtype_45);  le_scalar_15 = new_zeros_default_15 = to_dtype_45 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(to_dtype_47, cat_default_2, primals_46, [32], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_47 = cat_default_2 = primals_46 = None
        getitem_51 = convolution_backward_default_15[0]
        getitem_52 = convolution_backward_default_15[1]
        getitem_53 = convolution_backward_default_15[2];  convolution_backward_default_15 = None
        slice_tensor_10 = torch.ops.aten.slice.Tensor(getitem_51, 1, 0, 128)
        slice_tensor_11 = torch.ops.aten.slice.Tensor(getitem_51, 1, 128, 256);  getitem_51 = None
        to_dtype_48 = torch.ops.aten.to.dtype(slice_tensor_11, torch.float32);  slice_tensor_11 = None
        to_dtype_49 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_49, 0);  to_dtype_49 = None
        new_zeros_default_16 = torch.ops.aten.new_zeros.default(to_dtype_48, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_16, to_dtype_48);  le_scalar_16 = new_zeros_default_16 = to_dtype_48 = None
        to_dtype_50 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(to_dtype_50, relu__default_7, primals_38, [128], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_50 = primals_38 = None
        getitem_54 = convolution_backward_default_16[0]
        getitem_55 = convolution_backward_default_16[1]
        getitem_56 = convolution_backward_default_16[2];  convolution_backward_default_16 = None
        to_dtype_51 = torch.ops.aten.to.dtype(slice_tensor_10, torch.float32);  slice_tensor_10 = None
        to_dtype_52 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_52, 0);  to_dtype_52 = None
        new_zeros_default_17 = torch.ops.aten.new_zeros.default(to_dtype_51, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_17, new_zeros_default_17, to_dtype_51);  le_scalar_17 = new_zeros_default_17 = to_dtype_51 = None
        to_dtype_53 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(to_dtype_53, relu__default_7, primals_36, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_53 = primals_36 = None
        getitem_57 = convolution_backward_default_17[0]
        getitem_58 = convolution_backward_default_17[1]
        getitem_59 = convolution_backward_default_17[2];  convolution_backward_default_17 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(getitem_54, getitem_57);  getitem_54 = getitem_57 = None
        to_dtype_54 = torch.ops.aten.to.dtype(add_tensor_5, torch.float32);  add_tensor_5 = None
        to_dtype_55 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_55, 0);  to_dtype_55 = None
        new_zeros_default_18 = torch.ops.aten.new_zeros.default(to_dtype_54, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_18 = torch.ops.aten.where.self(le_scalar_18, new_zeros_default_18, to_dtype_54);  le_scalar_18 = new_zeros_default_18 = to_dtype_54 = None
        to_dtype_56 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(to_dtype_56, getitem_2, primals_40, [32], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_56 = getitem_2 = primals_40 = None
        getitem_60 = convolution_backward_default_18[0]
        getitem_61 = convolution_backward_default_18[1]
        getitem_62 = convolution_backward_default_18[2];  convolution_backward_default_18 = None
        max_pool2d_with_indices_backward_default_1 = torch.ops.aten.max_pool2d_with_indices_backward.default(getitem_60, cat_default_1, [3, 3], [2, 2], [0, 0], [1, 1], True, getitem_3);  getitem_60 = cat_default_1 = getitem_3 = None
        slice_tensor_12 = torch.ops.aten.slice.Tensor(max_pool2d_with_indices_backward_default_1, 1, 0, 64)
        slice_tensor_13 = torch.ops.aten.slice.Tensor(max_pool2d_with_indices_backward_default_1, 1, 64, 128);  max_pool2d_with_indices_backward_default_1 = None
        to_dtype_57 = torch.ops.aten.to.dtype(slice_tensor_13, torch.float32);  slice_tensor_13 = None
        to_dtype_58 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_58, 0);  to_dtype_58 = None
        new_zeros_default_19 = torch.ops.aten.new_zeros.default(to_dtype_57, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_19 = torch.ops.aten.where.self(le_scalar_19, new_zeros_default_19, to_dtype_57);  le_scalar_19 = new_zeros_default_19 = to_dtype_57 = None
        to_dtype_59 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(to_dtype_59, relu__default_4, primals_32, [64], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_59 = primals_32 = None
        getitem_63 = convolution_backward_default_19[0]
        getitem_64 = convolution_backward_default_19[1]
        getitem_65 = convolution_backward_default_19[2];  convolution_backward_default_19 = None
        to_dtype_60 = torch.ops.aten.to.dtype(slice_tensor_12, torch.float32);  slice_tensor_12 = None
        to_dtype_61 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_61, 0);  to_dtype_61 = None
        new_zeros_default_20 = torch.ops.aten.new_zeros.default(to_dtype_60, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_20 = torch.ops.aten.where.self(le_scalar_20, new_zeros_default_20, to_dtype_60);  le_scalar_20 = new_zeros_default_20 = to_dtype_60 = None
        to_dtype_62 = torch.ops.aten.to.dtype(where_self_20, torch.float32);  where_self_20 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(to_dtype_62, relu__default_4, primals_30, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_62 = primals_30 = None
        getitem_66 = convolution_backward_default_20[0]
        getitem_67 = convolution_backward_default_20[1]
        getitem_68 = convolution_backward_default_20[2];  convolution_backward_default_20 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(getitem_63, getitem_66);  getitem_63 = getitem_66 = None
        to_dtype_63 = torch.ops.aten.to.dtype(add_tensor_6, torch.float32);  add_tensor_6 = None
        to_dtype_64 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_64, 0);  to_dtype_64 = None
        new_zeros_default_21 = torch.ops.aten.new_zeros.default(to_dtype_63, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_21 = torch.ops.aten.where.self(le_scalar_21, new_zeros_default_21, to_dtype_63);  le_scalar_21 = new_zeros_default_21 = to_dtype_63 = None
        to_dtype_65 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(to_dtype_65, cat_default, primals_34, [16], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_65 = cat_default = primals_34 = None
        getitem_69 = convolution_backward_default_21[0]
        getitem_70 = convolution_backward_default_21[1]
        getitem_71 = convolution_backward_default_21[2];  convolution_backward_default_21 = None
        slice_tensor_14 = torch.ops.aten.slice.Tensor(getitem_69, 1, 0, 64)
        slice_tensor_15 = torch.ops.aten.slice.Tensor(getitem_69, 1, 64, 128);  getitem_69 = None
        to_dtype_66 = torch.ops.aten.to.dtype(slice_tensor_15, torch.float32);  slice_tensor_15 = None
        to_dtype_67 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_67, 0);  to_dtype_67 = None
        new_zeros_default_22 = torch.ops.aten.new_zeros.default(to_dtype_66, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_22 = torch.ops.aten.where.self(le_scalar_22, new_zeros_default_22, to_dtype_66);  le_scalar_22 = new_zeros_default_22 = to_dtype_66 = None
        to_dtype_68 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(to_dtype_68, relu__default_1, primals_26, [64], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_68 = primals_26 = None
        getitem_72 = convolution_backward_default_22[0]
        getitem_73 = convolution_backward_default_22[1]
        getitem_74 = convolution_backward_default_22[2];  convolution_backward_default_22 = None
        to_dtype_69 = torch.ops.aten.to.dtype(slice_tensor_14, torch.float32);  slice_tensor_14 = None
        to_dtype_70 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_70, 0);  to_dtype_70 = None
        new_zeros_default_23 = torch.ops.aten.new_zeros.default(to_dtype_69, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(le_scalar_23, new_zeros_default_23, to_dtype_69);  le_scalar_23 = new_zeros_default_23 = to_dtype_69 = None
        to_dtype_71 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(to_dtype_71, relu__default_1, primals_24, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_71 = primals_24 = None
        getitem_75 = convolution_backward_default_23[0]
        getitem_76 = convolution_backward_default_23[1]
        getitem_77 = convolution_backward_default_23[2];  convolution_backward_default_23 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(getitem_72, getitem_75);  getitem_72 = getitem_75 = None
        to_dtype_72 = torch.ops.aten.to.dtype(add_tensor_7, torch.float32);  add_tensor_7 = None
        to_dtype_73 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_73, 0);  to_dtype_73 = None
        new_zeros_default_24 = torch.ops.aten.new_zeros.default(to_dtype_72, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_24 = torch.ops.aten.where.self(le_scalar_24, new_zeros_default_24, to_dtype_72);  le_scalar_24 = new_zeros_default_24 = to_dtype_72 = None
        to_dtype_74 = torch.ops.aten.to.dtype(where_self_24, torch.float32);  where_self_24 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(to_dtype_74, getitem, primals_28, [16], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_74 = getitem = primals_28 = None
        getitem_78 = convolution_backward_default_24[0]
        getitem_79 = convolution_backward_default_24[1]
        getitem_80 = convolution_backward_default_24[2];  convolution_backward_default_24 = None
        max_pool2d_with_indices_backward_default_2 = torch.ops.aten.max_pool2d_with_indices_backward.default(getitem_78, relu__default, [3, 3], [2, 2], [0, 0], [1, 1], True, getitem_1);  getitem_78 = getitem_1 = None
        to_dtype_75 = torch.ops.aten.to.dtype(max_pool2d_with_indices_backward_default_2, torch.float32);  max_pool2d_with_indices_backward_default_2 = None
        to_dtype_76 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_76, 0);  to_dtype_76 = None
        new_zeros_default_25 = torch.ops.aten.new_zeros.default(to_dtype_75, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_25 = torch.ops.aten.where.self(le_scalar_25, new_zeros_default_25, to_dtype_75);  le_scalar_25 = new_zeros_default_25 = to_dtype_75 = None
        to_dtype_77 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(to_dtype_77, primals_53, primals_4, [64], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [False, True, True]);  to_dtype_77 = primals_53 = primals_4 = None
        getitem_82 = convolution_backward_default_25[1]
        getitem_83 = convolution_backward_default_25[2];  convolution_backward_default_25 = None
        return [getitem_8, getitem_7, getitem_83, getitem_82, getitem_32, getitem_31, getitem_29, getitem_28, getitem_35, getitem_34, getitem_23, getitem_22, getitem_20, getitem_19, getitem_26, getitem_25, getitem_14, getitem_13, getitem_11, getitem_10, getitem_17, getitem_16, getitem_77, getitem_76, getitem_74, getitem_73, getitem_80, getitem_79, getitem_68, getitem_67, getitem_65, getitem_64, getitem_71, getitem_70, getitem_59, getitem_58, getitem_56, getitem_55, getitem_62, getitem_61, getitem_50, getitem_49, getitem_47, getitem_46, getitem_53, getitem_52, getitem_41, getitem_40, getitem_38, getitem_37, getitem_44, getitem_43, None]
        
