
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/squeezenet1_1/squeezenet1_1_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53):
        convolution_default = torch.ops.aten.convolution.default(primals_53, primals_4, primals_3, [2, 2], [0, 0], [1, 1], False, [0, 0], 1);  primals_3 = None
        relu__default = torch.ops.aten.relu_.default(convolution_default);  convolution_default = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu__default, [3, 3], [2, 2], [0, 0], [1, 1], True)
        getitem = max_pool2d_with_indices_default[0]
        getitem_1 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_1 = torch.ops.aten.convolution.default(getitem, primals_28, primals_27, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_27 = None
        relu__default_1 = torch.ops.aten.relu_.default(convolution_default_1);  convolution_default_1 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_24, primals_23, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_23 = None
        relu__default_2 = torch.ops.aten.relu_.default(convolution_default_2);  convolution_default_2 = None
        convolution_default_3 = torch.ops.aten.convolution.default(relu__default_1, primals_26, primals_25, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_25 = None
        relu__default_3 = torch.ops.aten.relu_.default(convolution_default_3);  convolution_default_3 = None
        cat_default = torch.ops.aten.cat.default([relu__default_2, relu__default_3], 1)
        convolution_default_4 = torch.ops.aten.convolution.default(cat_default, primals_34, primals_33, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_33 = None
        relu__default_4 = torch.ops.aten.relu_.default(convolution_default_4);  convolution_default_4 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_4, primals_30, primals_29, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_29 = None
        relu__default_5 = torch.ops.aten.relu_.default(convolution_default_5);  convolution_default_5 = None
        convolution_default_6 = torch.ops.aten.convolution.default(relu__default_4, primals_32, primals_31, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_31 = None
        relu__default_6 = torch.ops.aten.relu_.default(convolution_default_6);  convolution_default_6 = None
        cat_default_1 = torch.ops.aten.cat.default([relu__default_5, relu__default_6], 1)
        max_pool2d_with_indices_default_1 = torch.ops.aten.max_pool2d_with_indices.default(cat_default_1, [3, 3], [2, 2], [0, 0], [1, 1], True)
        getitem_2 = max_pool2d_with_indices_default_1[0]
        getitem_3 = max_pool2d_with_indices_default_1[1];  max_pool2d_with_indices_default_1 = None
        convolution_default_7 = torch.ops.aten.convolution.default(getitem_2, primals_40, primals_39, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_39 = None
        relu__default_7 = torch.ops.aten.relu_.default(convolution_default_7);  convolution_default_7 = None
        convolution_default_8 = torch.ops.aten.convolution.default(relu__default_7, primals_36, primals_35, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_35 = None
        relu__default_8 = torch.ops.aten.relu_.default(convolution_default_8);  convolution_default_8 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_7, primals_38, primals_37, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_37 = None
        relu__default_9 = torch.ops.aten.relu_.default(convolution_default_9);  convolution_default_9 = None
        cat_default_2 = torch.ops.aten.cat.default([relu__default_8, relu__default_9], 1)
        convolution_default_10 = torch.ops.aten.convolution.default(cat_default_2, primals_46, primals_45, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_45 = None
        relu__default_10 = torch.ops.aten.relu_.default(convolution_default_10);  convolution_default_10 = None
        convolution_default_11 = torch.ops.aten.convolution.default(relu__default_10, primals_42, primals_41, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_41 = None
        relu__default_11 = torch.ops.aten.relu_.default(convolution_default_11);  convolution_default_11 = None
        convolution_default_12 = torch.ops.aten.convolution.default(relu__default_10, primals_44, primals_43, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_43 = None
        relu__default_12 = torch.ops.aten.relu_.default(convolution_default_12);  convolution_default_12 = None
        cat_default_3 = torch.ops.aten.cat.default([relu__default_11, relu__default_12], 1)
        max_pool2d_with_indices_default_2 = torch.ops.aten.max_pool2d_with_indices.default(cat_default_3, [3, 3], [2, 2], [0, 0], [1, 1], True)
        getitem_4 = max_pool2d_with_indices_default_2[0]
        getitem_5 = max_pool2d_with_indices_default_2[1];  max_pool2d_with_indices_default_2 = None
        convolution_default_13 = torch.ops.aten.convolution.default(getitem_4, primals_52, primals_51, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_51 = None
        relu__default_13 = torch.ops.aten.relu_.default(convolution_default_13);  convolution_default_13 = None
        convolution_default_14 = torch.ops.aten.convolution.default(relu__default_13, primals_48, primals_47, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_47 = None
        relu__default_14 = torch.ops.aten.relu_.default(convolution_default_14);  convolution_default_14 = None
        convolution_default_15 = torch.ops.aten.convolution.default(relu__default_13, primals_50, primals_49, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_49 = None
        relu__default_15 = torch.ops.aten.relu_.default(convolution_default_15);  convolution_default_15 = None
        cat_default_4 = torch.ops.aten.cat.default([relu__default_14, relu__default_15], 1)
        convolution_default_16 = torch.ops.aten.convolution.default(cat_default_4, primals_10, primals_9, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_9 = None
        relu__default_16 = torch.ops.aten.relu_.default(convolution_default_16);  convolution_default_16 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu__default_16, primals_6, primals_5, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_5 = None
        relu__default_17 = torch.ops.aten.relu_.default(convolution_default_17);  convolution_default_17 = None
        convolution_default_18 = torch.ops.aten.convolution.default(relu__default_16, primals_8, primals_7, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_7 = None
        relu__default_18 = torch.ops.aten.relu_.default(convolution_default_18);  convolution_default_18 = None
        cat_default_5 = torch.ops.aten.cat.default([relu__default_17, relu__default_18], 1)
        convolution_default_19 = torch.ops.aten.convolution.default(cat_default_5, primals_16, primals_15, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_15 = None
        relu__default_19 = torch.ops.aten.relu_.default(convolution_default_19);  convolution_default_19 = None
        convolution_default_20 = torch.ops.aten.convolution.default(relu__default_19, primals_12, primals_11, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_11 = None
        relu__default_20 = torch.ops.aten.relu_.default(convolution_default_20);  convolution_default_20 = None
        convolution_default_21 = torch.ops.aten.convolution.default(relu__default_19, primals_14, primals_13, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_13 = None
        relu__default_21 = torch.ops.aten.relu_.default(convolution_default_21);  convolution_default_21 = None
        cat_default_6 = torch.ops.aten.cat.default([relu__default_20, relu__default_21], 1)
        convolution_default_22 = torch.ops.aten.convolution.default(cat_default_6, primals_22, primals_21, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_21 = None
        relu__default_22 = torch.ops.aten.relu_.default(convolution_default_22);  convolution_default_22 = None
        convolution_default_23 = torch.ops.aten.convolution.default(relu__default_22, primals_18, primals_17, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_17 = None
        relu__default_23 = torch.ops.aten.relu_.default(convolution_default_23);  convolution_default_23 = None
        convolution_default_24 = torch.ops.aten.convolution.default(relu__default_22, primals_20, primals_19, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_19 = None
        relu__default_24 = torch.ops.aten.relu_.default(convolution_default_24);  convolution_default_24 = None
        cat_default_7 = torch.ops.aten.cat.default([relu__default_23, relu__default_24], 1)
        convolution_default_25 = torch.ops.aten.convolution.default(cat_default_7, primals_2, primals_1, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1 = None
        relu__default_25 = torch.ops.aten.relu_.default(convolution_default_25);  convolution_default_25 = None
        mean_dim = torch.ops.aten.mean.dim(relu__default_25, [-1, -2], True)
        view_default = torch.ops.aten.view.default(mean_dim, [32, 1000]);  mean_dim = None
        return [view_default, primals_42, primals_46, relu__default_23, primals_44, relu__default_13, relu__default_24, relu__default_14, cat_default_7, relu__default_15, primals_53, primals_22, cat_default_4, relu__default_25, primals_26, primals_10, primals_48, primals_30, relu__default_16, primals_24, primals_28, relu__default_17, primals_40, primals_16, getitem_1, cat_default_1, getitem, relu__default_9, relu__default_18, relu__default, relu__default_5, primals_8, primals_6, primals_34, cat_default_2, primals_12, primals_20, cat_default_5, primals_36, primals_52, relu__default_6, relu__default_19, relu__default_4, relu__default_10, relu__default_20, getitem_3, relu__default_1, relu__default_11, primals_4, cat_default_6, primals_18, primals_50, getitem_2, getitem_5, relu__default_2, primals_2, cat_default_3, primals_14, relu__default_12, relu__default_21, relu__default_3, relu__default_7, cat_default, relu__default_22, primals_32, primals_38, getitem_4, relu__default_8]
        
