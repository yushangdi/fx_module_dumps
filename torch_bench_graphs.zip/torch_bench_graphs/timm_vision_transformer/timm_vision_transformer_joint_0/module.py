
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/timm_vision_transformer/timm_vision_transformer_joint_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, tangents_1):
        convolution_default = torch.ops.aten.convolution.default(primals_153, primals_151, primals_150, [16, 16], [0, 0], [1, 1], False, [0, 0], 1);  primals_150 = None
        view_default = torch.ops.aten.view.default(convolution_default, [8, 384, 196]);  convolution_default = None
        transpose_int = torch.ops.aten.transpose.int(view_default, 1, 2);  view_default = None
        expand_sym_int = torch.ops.aten.expand.SymInt(primals_145, [8, -1, -1]);  primals_145 = None
        cat_default = torch.ops.aten.cat.default([expand_sym_int, transpose_int], 1);  expand_sym_int = transpose_int = None
        add_tensor = torch.ops.aten.add.Tensor(cat_default, primals_152);  cat_default = primals_152 = None
        native_layer_norm_default = torch.ops.aten.native_layer_norm.default(add_tensor, [384], primals_10, primals_9, 1e-06)
        getitem = native_layer_norm_default[0]
        getitem_1 = native_layer_norm_default[1]
        getitem_2 = native_layer_norm_default[2];  native_layer_norm_default = None
        view_default_1 = torch.ops.aten.view.default(getitem, [1576, 384]);  getitem = None
        t_default = torch.ops.aten.t.default(primals_4);  primals_4 = None
        addmm_default = torch.ops.aten.addmm.default(primals_3, view_default_1, t_default);  primals_3 = None
        view_default_2 = torch.ops.aten.view.default(addmm_default, [8, 197, 1152]);  addmm_default = None
        view_default_3 = torch.ops.aten.view.default(view_default_2, [8, 197, 3, 6, 64]);  view_default_2 = None
        permute_default = torch.ops.aten.permute.default(view_default_3, [2, 0, 3, 1, 4]);  view_default_3 = None
        select_int = torch.ops.aten.select.int(permute_default, 0, 0)
        select_int_1 = torch.ops.aten.select.int(permute_default, 0, 1)
        select_int_2 = torch.ops.aten.select.int(permute_default, 0, 2);  permute_default = None
        transpose_int_1 = torch.ops.aten.transpose.int(select_int_1, -2, -1);  select_int_1 = None
        expand_default = torch.ops.aten.expand.default(select_int, [8, 6, 197, 64]);  select_int = None
        clone_default = torch.ops.aten.clone.default(expand_default, memory_format = torch.contiguous_format);  expand_default = None
        _unsafe_view_default = torch.ops.aten._unsafe_view.default(clone_default, [48, 197, 64]);  clone_default = None
        expand_default_1 = torch.ops.aten.expand.default(transpose_int_1, [8, 6, 64, 197]);  transpose_int_1 = None
        clone_default_1 = torch.ops.aten.clone.default(expand_default_1, memory_format = torch.contiguous_format);  expand_default_1 = None
        _unsafe_view_default_1 = torch.ops.aten._unsafe_view.default(clone_default_1, [48, 64, 197]);  clone_default_1 = None
        bmm_default = torch.ops.aten.bmm.default(_unsafe_view_default, _unsafe_view_default_1)
        _unsafe_view_default_2 = torch.ops.aten._unsafe_view.default(bmm_default, [8, 6, 197, 197]);  bmm_default = None
        mul_tensor = torch.ops.aten.mul.Tensor(_unsafe_view_default_2, 0.125);  _unsafe_view_default_2 = None
        _softmax_default = torch.ops.aten._softmax.default(mul_tensor, -1, False);  mul_tensor = None
        expand_default_2 = torch.ops.aten.expand.default(_softmax_default, [8, 6, 197, 197])
        view_default_4 = torch.ops.aten.view.default(expand_default_2, [48, 197, 197]);  expand_default_2 = None
        expand_default_3 = torch.ops.aten.expand.default(select_int_2, [8, 6, 197, 64]);  select_int_2 = None
        clone_default_2 = torch.ops.aten.clone.default(expand_default_3, memory_format = torch.contiguous_format);  expand_default_3 = None
        _unsafe_view_default_3 = torch.ops.aten._unsafe_view.default(clone_default_2, [48, 197, 64]);  clone_default_2 = None
        bmm_default_1 = torch.ops.aten.bmm.default(view_default_4, _unsafe_view_default_3)
        _unsafe_view_default_4 = torch.ops.aten._unsafe_view.default(bmm_default_1, [8, 6, 197, 64]);  bmm_default_1 = None
        transpose_int_2 = torch.ops.aten.transpose.int(_unsafe_view_default_4, 1, 2);  _unsafe_view_default_4 = None
        clone_default_3 = torch.ops.aten.clone.default(transpose_int_2, memory_format = torch.contiguous_format);  transpose_int_2 = None
        _unsafe_view_default_5 = torch.ops.aten._unsafe_view.default(clone_default_3, [8, 197, 384]);  clone_default_3 = None
        view_default_5 = torch.ops.aten.view.default(_unsafe_view_default_5, [1576, 384]);  _unsafe_view_default_5 = None
        t_default_1 = torch.ops.aten.t.default(primals_2);  primals_2 = None
        addmm_default_1 = torch.ops.aten.addmm.default(primals_1, view_default_5, t_default_1);  primals_1 = None
        view_default_6 = torch.ops.aten.view.default(addmm_default_1, [8, 197, 384]);  addmm_default_1 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(add_tensor, view_default_6);  view_default_6 = None
        native_layer_norm_default_1 = torch.ops.aten.native_layer_norm.default(add_tensor_1, [384], primals_12, primals_11, 1e-06)
        getitem_3 = native_layer_norm_default_1[0]
        getitem_4 = native_layer_norm_default_1[1]
        getitem_5 = native_layer_norm_default_1[2];  native_layer_norm_default_1 = None
        view_default_7 = torch.ops.aten.view.default(getitem_3, [1576, 384]);  getitem_3 = None
        t_default_2 = torch.ops.aten.t.default(primals_6);  primals_6 = None
        addmm_default_2 = torch.ops.aten.addmm.default(primals_5, view_default_7, t_default_2);  primals_5 = None
        view_default_8 = torch.ops.aten.view.default(addmm_default_2, [8, 197, 1536]);  addmm_default_2 = None
        gelu_default = torch.ops.aten.gelu.default(view_default_8)
        view_default_9 = torch.ops.aten.view.default(gelu_default, [1576, 1536]);  gelu_default = None
        t_default_3 = torch.ops.aten.t.default(primals_8);  primals_8 = None
        addmm_default_3 = torch.ops.aten.addmm.default(primals_7, view_default_9, t_default_3);  primals_7 = None
        view_default_10 = torch.ops.aten.view.default(addmm_default_3, [8, 197, 384]);  addmm_default_3 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(add_tensor_1, view_default_10);  view_default_10 = None
        native_layer_norm_default_2 = torch.ops.aten.native_layer_norm.default(add_tensor_2, [384], primals_46, primals_45, 1e-06)
        getitem_6 = native_layer_norm_default_2[0]
        getitem_7 = native_layer_norm_default_2[1]
        getitem_8 = native_layer_norm_default_2[2];  native_layer_norm_default_2 = None
        view_default_11 = torch.ops.aten.view.default(getitem_6, [1576, 384]);  getitem_6 = None
        t_default_4 = torch.ops.aten.t.default(primals_40);  primals_40 = None
        addmm_default_4 = torch.ops.aten.addmm.default(primals_39, view_default_11, t_default_4);  primals_39 = None
        view_default_12 = torch.ops.aten.view.default(addmm_default_4, [8, 197, 1152]);  addmm_default_4 = None
        view_default_13 = torch.ops.aten.view.default(view_default_12, [8, 197, 3, 6, 64]);  view_default_12 = None
        permute_default_1 = torch.ops.aten.permute.default(view_default_13, [2, 0, 3, 1, 4]);  view_default_13 = None
        select_int_3 = torch.ops.aten.select.int(permute_default_1, 0, 0)
        select_int_4 = torch.ops.aten.select.int(permute_default_1, 0, 1)
        select_int_5 = torch.ops.aten.select.int(permute_default_1, 0, 2);  permute_default_1 = None
        transpose_int_3 = torch.ops.aten.transpose.int(select_int_4, -2, -1);  select_int_4 = None
        expand_default_4 = torch.ops.aten.expand.default(select_int_3, [8, 6, 197, 64]);  select_int_3 = None
        clone_default_4 = torch.ops.aten.clone.default(expand_default_4, memory_format = torch.contiguous_format);  expand_default_4 = None
        _unsafe_view_default_6 = torch.ops.aten._unsafe_view.default(clone_default_4, [48, 197, 64]);  clone_default_4 = None
        expand_default_5 = torch.ops.aten.expand.default(transpose_int_3, [8, 6, 64, 197]);  transpose_int_3 = None
        clone_default_5 = torch.ops.aten.clone.default(expand_default_5, memory_format = torch.contiguous_format);  expand_default_5 = None
        _unsafe_view_default_7 = torch.ops.aten._unsafe_view.default(clone_default_5, [48, 64, 197]);  clone_default_5 = None
        bmm_default_2 = torch.ops.aten.bmm.default(_unsafe_view_default_6, _unsafe_view_default_7)
        _unsafe_view_default_8 = torch.ops.aten._unsafe_view.default(bmm_default_2, [8, 6, 197, 197]);  bmm_default_2 = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(_unsafe_view_default_8, 0.125);  _unsafe_view_default_8 = None
        _softmax_default_1 = torch.ops.aten._softmax.default(mul_tensor_1, -1, False);  mul_tensor_1 = None
        expand_default_6 = torch.ops.aten.expand.default(_softmax_default_1, [8, 6, 197, 197])
        view_default_14 = torch.ops.aten.view.default(expand_default_6, [48, 197, 197]);  expand_default_6 = None
        expand_default_7 = torch.ops.aten.expand.default(select_int_5, [8, 6, 197, 64]);  select_int_5 = None
        clone_default_6 = torch.ops.aten.clone.default(expand_default_7, memory_format = torch.contiguous_format);  expand_default_7 = None
        _unsafe_view_default_9 = torch.ops.aten._unsafe_view.default(clone_default_6, [48, 197, 64]);  clone_default_6 = None
        bmm_default_3 = torch.ops.aten.bmm.default(view_default_14, _unsafe_view_default_9)
        _unsafe_view_default_10 = torch.ops.aten._unsafe_view.default(bmm_default_3, [8, 6, 197, 64]);  bmm_default_3 = None
        transpose_int_4 = torch.ops.aten.transpose.int(_unsafe_view_default_10, 1, 2);  _unsafe_view_default_10 = None
        clone_default_7 = torch.ops.aten.clone.default(transpose_int_4, memory_format = torch.contiguous_format);  transpose_int_4 = None
        _unsafe_view_default_11 = torch.ops.aten._unsafe_view.default(clone_default_7, [8, 197, 384]);  clone_default_7 = None
        view_default_15 = torch.ops.aten.view.default(_unsafe_view_default_11, [1576, 384]);  _unsafe_view_default_11 = None
        t_default_5 = torch.ops.aten.t.default(primals_38);  primals_38 = None
        addmm_default_5 = torch.ops.aten.addmm.default(primals_37, view_default_15, t_default_5);  primals_37 = None
        view_default_16 = torch.ops.aten.view.default(addmm_default_5, [8, 197, 384]);  addmm_default_5 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(add_tensor_2, view_default_16);  view_default_16 = None
        native_layer_norm_default_3 = torch.ops.aten.native_layer_norm.default(add_tensor_3, [384], primals_48, primals_47, 1e-06)
        getitem_9 = native_layer_norm_default_3[0]
        getitem_10 = native_layer_norm_default_3[1]
        getitem_11 = native_layer_norm_default_3[2];  native_layer_norm_default_3 = None
        view_default_17 = torch.ops.aten.view.default(getitem_9, [1576, 384]);  getitem_9 = None
        t_default_6 = torch.ops.aten.t.default(primals_42);  primals_42 = None
        addmm_default_6 = torch.ops.aten.addmm.default(primals_41, view_default_17, t_default_6);  primals_41 = None
        view_default_18 = torch.ops.aten.view.default(addmm_default_6, [8, 197, 1536]);  addmm_default_6 = None
        gelu_default_1 = torch.ops.aten.gelu.default(view_default_18)
        view_default_19 = torch.ops.aten.view.default(gelu_default_1, [1576, 1536]);  gelu_default_1 = None
        t_default_7 = torch.ops.aten.t.default(primals_44);  primals_44 = None
        addmm_default_7 = torch.ops.aten.addmm.default(primals_43, view_default_19, t_default_7);  primals_43 = None
        view_default_20 = torch.ops.aten.view.default(addmm_default_7, [8, 197, 384]);  addmm_default_7 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(add_tensor_3, view_default_20);  view_default_20 = None
        native_layer_norm_default_4 = torch.ops.aten.native_layer_norm.default(add_tensor_4, [384], primals_58, primals_57, 1e-06)
        getitem_12 = native_layer_norm_default_4[0]
        getitem_13 = native_layer_norm_default_4[1]
        getitem_14 = native_layer_norm_default_4[2];  native_layer_norm_default_4 = None
        view_default_21 = torch.ops.aten.view.default(getitem_12, [1576, 384]);  getitem_12 = None
        t_default_8 = torch.ops.aten.t.default(primals_52);  primals_52 = None
        addmm_default_8 = torch.ops.aten.addmm.default(primals_51, view_default_21, t_default_8);  primals_51 = None
        view_default_22 = torch.ops.aten.view.default(addmm_default_8, [8, 197, 1152]);  addmm_default_8 = None
        view_default_23 = torch.ops.aten.view.default(view_default_22, [8, 197, 3, 6, 64]);  view_default_22 = None
        permute_default_2 = torch.ops.aten.permute.default(view_default_23, [2, 0, 3, 1, 4]);  view_default_23 = None
        select_int_6 = torch.ops.aten.select.int(permute_default_2, 0, 0)
        select_int_7 = torch.ops.aten.select.int(permute_default_2, 0, 1)
        select_int_8 = torch.ops.aten.select.int(permute_default_2, 0, 2);  permute_default_2 = None
        transpose_int_5 = torch.ops.aten.transpose.int(select_int_7, -2, -1);  select_int_7 = None
        expand_default_8 = torch.ops.aten.expand.default(select_int_6, [8, 6, 197, 64]);  select_int_6 = None
        clone_default_8 = torch.ops.aten.clone.default(expand_default_8, memory_format = torch.contiguous_format);  expand_default_8 = None
        _unsafe_view_default_12 = torch.ops.aten._unsafe_view.default(clone_default_8, [48, 197, 64]);  clone_default_8 = None
        expand_default_9 = torch.ops.aten.expand.default(transpose_int_5, [8, 6, 64, 197]);  transpose_int_5 = None
        clone_default_9 = torch.ops.aten.clone.default(expand_default_9, memory_format = torch.contiguous_format);  expand_default_9 = None
        _unsafe_view_default_13 = torch.ops.aten._unsafe_view.default(clone_default_9, [48, 64, 197]);  clone_default_9 = None
        bmm_default_4 = torch.ops.aten.bmm.default(_unsafe_view_default_12, _unsafe_view_default_13)
        _unsafe_view_default_14 = torch.ops.aten._unsafe_view.default(bmm_default_4, [8, 6, 197, 197]);  bmm_default_4 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(_unsafe_view_default_14, 0.125);  _unsafe_view_default_14 = None
        _softmax_default_2 = torch.ops.aten._softmax.default(mul_tensor_2, -1, False);  mul_tensor_2 = None
        expand_default_10 = torch.ops.aten.expand.default(_softmax_default_2, [8, 6, 197, 197])
        view_default_24 = torch.ops.aten.view.default(expand_default_10, [48, 197, 197]);  expand_default_10 = None
        expand_default_11 = torch.ops.aten.expand.default(select_int_8, [8, 6, 197, 64]);  select_int_8 = None
        clone_default_10 = torch.ops.aten.clone.default(expand_default_11, memory_format = torch.contiguous_format);  expand_default_11 = None
        _unsafe_view_default_15 = torch.ops.aten._unsafe_view.default(clone_default_10, [48, 197, 64]);  clone_default_10 = None
        bmm_default_5 = torch.ops.aten.bmm.default(view_default_24, _unsafe_view_default_15)
        _unsafe_view_default_16 = torch.ops.aten._unsafe_view.default(bmm_default_5, [8, 6, 197, 64]);  bmm_default_5 = None
        transpose_int_6 = torch.ops.aten.transpose.int(_unsafe_view_default_16, 1, 2);  _unsafe_view_default_16 = None
        clone_default_11 = torch.ops.aten.clone.default(transpose_int_6, memory_format = torch.contiguous_format);  transpose_int_6 = None
        _unsafe_view_default_17 = torch.ops.aten._unsafe_view.default(clone_default_11, [8, 197, 384]);  clone_default_11 = None
        view_default_25 = torch.ops.aten.view.default(_unsafe_view_default_17, [1576, 384]);  _unsafe_view_default_17 = None
        t_default_9 = torch.ops.aten.t.default(primals_50);  primals_50 = None
        addmm_default_9 = torch.ops.aten.addmm.default(primals_49, view_default_25, t_default_9);  primals_49 = None
        view_default_26 = torch.ops.aten.view.default(addmm_default_9, [8, 197, 384]);  addmm_default_9 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(add_tensor_4, view_default_26);  view_default_26 = None
        native_layer_norm_default_5 = torch.ops.aten.native_layer_norm.default(add_tensor_5, [384], primals_60, primals_59, 1e-06)
        getitem_15 = native_layer_norm_default_5[0]
        getitem_16 = native_layer_norm_default_5[1]
        getitem_17 = native_layer_norm_default_5[2];  native_layer_norm_default_5 = None
        view_default_27 = torch.ops.aten.view.default(getitem_15, [1576, 384]);  getitem_15 = None
        t_default_10 = torch.ops.aten.t.default(primals_54);  primals_54 = None
        addmm_default_10 = torch.ops.aten.addmm.default(primals_53, view_default_27, t_default_10);  primals_53 = None
        view_default_28 = torch.ops.aten.view.default(addmm_default_10, [8, 197, 1536]);  addmm_default_10 = None
        gelu_default_2 = torch.ops.aten.gelu.default(view_default_28)
        view_default_29 = torch.ops.aten.view.default(gelu_default_2, [1576, 1536]);  gelu_default_2 = None
        t_default_11 = torch.ops.aten.t.default(primals_56);  primals_56 = None
        addmm_default_11 = torch.ops.aten.addmm.default(primals_55, view_default_29, t_default_11);  primals_55 = None
        view_default_30 = torch.ops.aten.view.default(addmm_default_11, [8, 197, 384]);  addmm_default_11 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(add_tensor_5, view_default_30);  view_default_30 = None
        native_layer_norm_default_6 = torch.ops.aten.native_layer_norm.default(add_tensor_6, [384], primals_70, primals_69, 1e-06)
        getitem_18 = native_layer_norm_default_6[0]
        getitem_19 = native_layer_norm_default_6[1]
        getitem_20 = native_layer_norm_default_6[2];  native_layer_norm_default_6 = None
        view_default_31 = torch.ops.aten.view.default(getitem_18, [1576, 384]);  getitem_18 = None
        t_default_12 = torch.ops.aten.t.default(primals_64);  primals_64 = None
        addmm_default_12 = torch.ops.aten.addmm.default(primals_63, view_default_31, t_default_12);  primals_63 = None
        view_default_32 = torch.ops.aten.view.default(addmm_default_12, [8, 197, 1152]);  addmm_default_12 = None
        view_default_33 = torch.ops.aten.view.default(view_default_32, [8, 197, 3, 6, 64]);  view_default_32 = None
        permute_default_3 = torch.ops.aten.permute.default(view_default_33, [2, 0, 3, 1, 4]);  view_default_33 = None
        select_int_9 = torch.ops.aten.select.int(permute_default_3, 0, 0)
        select_int_10 = torch.ops.aten.select.int(permute_default_3, 0, 1)
        select_int_11 = torch.ops.aten.select.int(permute_default_3, 0, 2);  permute_default_3 = None
        transpose_int_7 = torch.ops.aten.transpose.int(select_int_10, -2, -1);  select_int_10 = None
        expand_default_12 = torch.ops.aten.expand.default(select_int_9, [8, 6, 197, 64]);  select_int_9 = None
        clone_default_12 = torch.ops.aten.clone.default(expand_default_12, memory_format = torch.contiguous_format);  expand_default_12 = None
        _unsafe_view_default_18 = torch.ops.aten._unsafe_view.default(clone_default_12, [48, 197, 64]);  clone_default_12 = None
        expand_default_13 = torch.ops.aten.expand.default(transpose_int_7, [8, 6, 64, 197]);  transpose_int_7 = None
        clone_default_13 = torch.ops.aten.clone.default(expand_default_13, memory_format = torch.contiguous_format);  expand_default_13 = None
        _unsafe_view_default_19 = torch.ops.aten._unsafe_view.default(clone_default_13, [48, 64, 197]);  clone_default_13 = None
        bmm_default_6 = torch.ops.aten.bmm.default(_unsafe_view_default_18, _unsafe_view_default_19)
        _unsafe_view_default_20 = torch.ops.aten._unsafe_view.default(bmm_default_6, [8, 6, 197, 197]);  bmm_default_6 = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(_unsafe_view_default_20, 0.125);  _unsafe_view_default_20 = None
        _softmax_default_3 = torch.ops.aten._softmax.default(mul_tensor_3, -1, False);  mul_tensor_3 = None
        expand_default_14 = torch.ops.aten.expand.default(_softmax_default_3, [8, 6, 197, 197])
        view_default_34 = torch.ops.aten.view.default(expand_default_14, [48, 197, 197]);  expand_default_14 = None
        expand_default_15 = torch.ops.aten.expand.default(select_int_11, [8, 6, 197, 64]);  select_int_11 = None
        clone_default_14 = torch.ops.aten.clone.default(expand_default_15, memory_format = torch.contiguous_format);  expand_default_15 = None
        _unsafe_view_default_21 = torch.ops.aten._unsafe_view.default(clone_default_14, [48, 197, 64]);  clone_default_14 = None
        bmm_default_7 = torch.ops.aten.bmm.default(view_default_34, _unsafe_view_default_21)
        _unsafe_view_default_22 = torch.ops.aten._unsafe_view.default(bmm_default_7, [8, 6, 197, 64]);  bmm_default_7 = None
        transpose_int_8 = torch.ops.aten.transpose.int(_unsafe_view_default_22, 1, 2);  _unsafe_view_default_22 = None
        clone_default_15 = torch.ops.aten.clone.default(transpose_int_8, memory_format = torch.contiguous_format);  transpose_int_8 = None
        _unsafe_view_default_23 = torch.ops.aten._unsafe_view.default(clone_default_15, [8, 197, 384]);  clone_default_15 = None
        view_default_35 = torch.ops.aten.view.default(_unsafe_view_default_23, [1576, 384]);  _unsafe_view_default_23 = None
        t_default_13 = torch.ops.aten.t.default(primals_62);  primals_62 = None
        addmm_default_13 = torch.ops.aten.addmm.default(primals_61, view_default_35, t_default_13);  primals_61 = None
        view_default_36 = torch.ops.aten.view.default(addmm_default_13, [8, 197, 384]);  addmm_default_13 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(add_tensor_6, view_default_36);  view_default_36 = None
        native_layer_norm_default_7 = torch.ops.aten.native_layer_norm.default(add_tensor_7, [384], primals_72, primals_71, 1e-06)
        getitem_21 = native_layer_norm_default_7[0]
        getitem_22 = native_layer_norm_default_7[1]
        getitem_23 = native_layer_norm_default_7[2];  native_layer_norm_default_7 = None
        view_default_37 = torch.ops.aten.view.default(getitem_21, [1576, 384]);  getitem_21 = None
        t_default_14 = torch.ops.aten.t.default(primals_66);  primals_66 = None
        addmm_default_14 = torch.ops.aten.addmm.default(primals_65, view_default_37, t_default_14);  primals_65 = None
        view_default_38 = torch.ops.aten.view.default(addmm_default_14, [8, 197, 1536]);  addmm_default_14 = None
        gelu_default_3 = torch.ops.aten.gelu.default(view_default_38)
        view_default_39 = torch.ops.aten.view.default(gelu_default_3, [1576, 1536]);  gelu_default_3 = None
        t_default_15 = torch.ops.aten.t.default(primals_68);  primals_68 = None
        addmm_default_15 = torch.ops.aten.addmm.default(primals_67, view_default_39, t_default_15);  primals_67 = None
        view_default_40 = torch.ops.aten.view.default(addmm_default_15, [8, 197, 384]);  addmm_default_15 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(add_tensor_7, view_default_40);  view_default_40 = None
        native_layer_norm_default_8 = torch.ops.aten.native_layer_norm.default(add_tensor_8, [384], primals_82, primals_81, 1e-06)
        getitem_24 = native_layer_norm_default_8[0]
        getitem_25 = native_layer_norm_default_8[1]
        getitem_26 = native_layer_norm_default_8[2];  native_layer_norm_default_8 = None
        view_default_41 = torch.ops.aten.view.default(getitem_24, [1576, 384]);  getitem_24 = None
        t_default_16 = torch.ops.aten.t.default(primals_76);  primals_76 = None
        addmm_default_16 = torch.ops.aten.addmm.default(primals_75, view_default_41, t_default_16);  primals_75 = None
        view_default_42 = torch.ops.aten.view.default(addmm_default_16, [8, 197, 1152]);  addmm_default_16 = None
        view_default_43 = torch.ops.aten.view.default(view_default_42, [8, 197, 3, 6, 64]);  view_default_42 = None
        permute_default_4 = torch.ops.aten.permute.default(view_default_43, [2, 0, 3, 1, 4]);  view_default_43 = None
        select_int_12 = torch.ops.aten.select.int(permute_default_4, 0, 0)
        select_int_13 = torch.ops.aten.select.int(permute_default_4, 0, 1)
        select_int_14 = torch.ops.aten.select.int(permute_default_4, 0, 2);  permute_default_4 = None
        transpose_int_9 = torch.ops.aten.transpose.int(select_int_13, -2, -1);  select_int_13 = None
        expand_default_16 = torch.ops.aten.expand.default(select_int_12, [8, 6, 197, 64]);  select_int_12 = None
        clone_default_16 = torch.ops.aten.clone.default(expand_default_16, memory_format = torch.contiguous_format);  expand_default_16 = None
        _unsafe_view_default_24 = torch.ops.aten._unsafe_view.default(clone_default_16, [48, 197, 64]);  clone_default_16 = None
        expand_default_17 = torch.ops.aten.expand.default(transpose_int_9, [8, 6, 64, 197]);  transpose_int_9 = None
        clone_default_17 = torch.ops.aten.clone.default(expand_default_17, memory_format = torch.contiguous_format);  expand_default_17 = None
        _unsafe_view_default_25 = torch.ops.aten._unsafe_view.default(clone_default_17, [48, 64, 197]);  clone_default_17 = None
        bmm_default_8 = torch.ops.aten.bmm.default(_unsafe_view_default_24, _unsafe_view_default_25)
        _unsafe_view_default_26 = torch.ops.aten._unsafe_view.default(bmm_default_8, [8, 6, 197, 197]);  bmm_default_8 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(_unsafe_view_default_26, 0.125);  _unsafe_view_default_26 = None
        _softmax_default_4 = torch.ops.aten._softmax.default(mul_tensor_4, -1, False);  mul_tensor_4 = None
        expand_default_18 = torch.ops.aten.expand.default(_softmax_default_4, [8, 6, 197, 197])
        view_default_44 = torch.ops.aten.view.default(expand_default_18, [48, 197, 197]);  expand_default_18 = None
        expand_default_19 = torch.ops.aten.expand.default(select_int_14, [8, 6, 197, 64]);  select_int_14 = None
        clone_default_18 = torch.ops.aten.clone.default(expand_default_19, memory_format = torch.contiguous_format);  expand_default_19 = None
        _unsafe_view_default_27 = torch.ops.aten._unsafe_view.default(clone_default_18, [48, 197, 64]);  clone_default_18 = None
        bmm_default_9 = torch.ops.aten.bmm.default(view_default_44, _unsafe_view_default_27)
        _unsafe_view_default_28 = torch.ops.aten._unsafe_view.default(bmm_default_9, [8, 6, 197, 64]);  bmm_default_9 = None
        transpose_int_10 = torch.ops.aten.transpose.int(_unsafe_view_default_28, 1, 2);  _unsafe_view_default_28 = None
        clone_default_19 = torch.ops.aten.clone.default(transpose_int_10, memory_format = torch.contiguous_format);  transpose_int_10 = None
        _unsafe_view_default_29 = torch.ops.aten._unsafe_view.default(clone_default_19, [8, 197, 384]);  clone_default_19 = None
        view_default_45 = torch.ops.aten.view.default(_unsafe_view_default_29, [1576, 384]);  _unsafe_view_default_29 = None
        t_default_17 = torch.ops.aten.t.default(primals_74);  primals_74 = None
        addmm_default_17 = torch.ops.aten.addmm.default(primals_73, view_default_45, t_default_17);  primals_73 = None
        view_default_46 = torch.ops.aten.view.default(addmm_default_17, [8, 197, 384]);  addmm_default_17 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(add_tensor_8, view_default_46);  view_default_46 = None
        native_layer_norm_default_9 = torch.ops.aten.native_layer_norm.default(add_tensor_9, [384], primals_84, primals_83, 1e-06)
        getitem_27 = native_layer_norm_default_9[0]
        getitem_28 = native_layer_norm_default_9[1]
        getitem_29 = native_layer_norm_default_9[2];  native_layer_norm_default_9 = None
        view_default_47 = torch.ops.aten.view.default(getitem_27, [1576, 384]);  getitem_27 = None
        t_default_18 = torch.ops.aten.t.default(primals_78);  primals_78 = None
        addmm_default_18 = torch.ops.aten.addmm.default(primals_77, view_default_47, t_default_18);  primals_77 = None
        view_default_48 = torch.ops.aten.view.default(addmm_default_18, [8, 197, 1536]);  addmm_default_18 = None
        gelu_default_4 = torch.ops.aten.gelu.default(view_default_48)
        view_default_49 = torch.ops.aten.view.default(gelu_default_4, [1576, 1536]);  gelu_default_4 = None
        t_default_19 = torch.ops.aten.t.default(primals_80);  primals_80 = None
        addmm_default_19 = torch.ops.aten.addmm.default(primals_79, view_default_49, t_default_19);  primals_79 = None
        view_default_50 = torch.ops.aten.view.default(addmm_default_19, [8, 197, 384]);  addmm_default_19 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(add_tensor_9, view_default_50);  view_default_50 = None
        native_layer_norm_default_10 = torch.ops.aten.native_layer_norm.default(add_tensor_10, [384], primals_94, primals_93, 1e-06)
        getitem_30 = native_layer_norm_default_10[0]
        getitem_31 = native_layer_norm_default_10[1]
        getitem_32 = native_layer_norm_default_10[2];  native_layer_norm_default_10 = None
        view_default_51 = torch.ops.aten.view.default(getitem_30, [1576, 384]);  getitem_30 = None
        t_default_20 = torch.ops.aten.t.default(primals_88);  primals_88 = None
        addmm_default_20 = torch.ops.aten.addmm.default(primals_87, view_default_51, t_default_20);  primals_87 = None
        view_default_52 = torch.ops.aten.view.default(addmm_default_20, [8, 197, 1152]);  addmm_default_20 = None
        view_default_53 = torch.ops.aten.view.default(view_default_52, [8, 197, 3, 6, 64]);  view_default_52 = None
        permute_default_5 = torch.ops.aten.permute.default(view_default_53, [2, 0, 3, 1, 4]);  view_default_53 = None
        select_int_15 = torch.ops.aten.select.int(permute_default_5, 0, 0)
        select_int_16 = torch.ops.aten.select.int(permute_default_5, 0, 1)
        select_int_17 = torch.ops.aten.select.int(permute_default_5, 0, 2);  permute_default_5 = None
        transpose_int_11 = torch.ops.aten.transpose.int(select_int_16, -2, -1);  select_int_16 = None
        expand_default_20 = torch.ops.aten.expand.default(select_int_15, [8, 6, 197, 64]);  select_int_15 = None
        clone_default_20 = torch.ops.aten.clone.default(expand_default_20, memory_format = torch.contiguous_format);  expand_default_20 = None
        _unsafe_view_default_30 = torch.ops.aten._unsafe_view.default(clone_default_20, [48, 197, 64]);  clone_default_20 = None
        expand_default_21 = torch.ops.aten.expand.default(transpose_int_11, [8, 6, 64, 197]);  transpose_int_11 = None
        clone_default_21 = torch.ops.aten.clone.default(expand_default_21, memory_format = torch.contiguous_format);  expand_default_21 = None
        _unsafe_view_default_31 = torch.ops.aten._unsafe_view.default(clone_default_21, [48, 64, 197]);  clone_default_21 = None
        bmm_default_10 = torch.ops.aten.bmm.default(_unsafe_view_default_30, _unsafe_view_default_31)
        _unsafe_view_default_32 = torch.ops.aten._unsafe_view.default(bmm_default_10, [8, 6, 197, 197]);  bmm_default_10 = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(_unsafe_view_default_32, 0.125);  _unsafe_view_default_32 = None
        _softmax_default_5 = torch.ops.aten._softmax.default(mul_tensor_5, -1, False);  mul_tensor_5 = None
        expand_default_22 = torch.ops.aten.expand.default(_softmax_default_5, [8, 6, 197, 197])
        view_default_54 = torch.ops.aten.view.default(expand_default_22, [48, 197, 197]);  expand_default_22 = None
        expand_default_23 = torch.ops.aten.expand.default(select_int_17, [8, 6, 197, 64]);  select_int_17 = None
        clone_default_22 = torch.ops.aten.clone.default(expand_default_23, memory_format = torch.contiguous_format);  expand_default_23 = None
        _unsafe_view_default_33 = torch.ops.aten._unsafe_view.default(clone_default_22, [48, 197, 64]);  clone_default_22 = None
        bmm_default_11 = torch.ops.aten.bmm.default(view_default_54, _unsafe_view_default_33)
        _unsafe_view_default_34 = torch.ops.aten._unsafe_view.default(bmm_default_11, [8, 6, 197, 64]);  bmm_default_11 = None
        transpose_int_12 = torch.ops.aten.transpose.int(_unsafe_view_default_34, 1, 2);  _unsafe_view_default_34 = None
        clone_default_23 = torch.ops.aten.clone.default(transpose_int_12, memory_format = torch.contiguous_format);  transpose_int_12 = None
        _unsafe_view_default_35 = torch.ops.aten._unsafe_view.default(clone_default_23, [8, 197, 384]);  clone_default_23 = None
        view_default_55 = torch.ops.aten.view.default(_unsafe_view_default_35, [1576, 384]);  _unsafe_view_default_35 = None
        t_default_21 = torch.ops.aten.t.default(primals_86);  primals_86 = None
        addmm_default_21 = torch.ops.aten.addmm.default(primals_85, view_default_55, t_default_21);  primals_85 = None
        view_default_56 = torch.ops.aten.view.default(addmm_default_21, [8, 197, 384]);  addmm_default_21 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(add_tensor_10, view_default_56);  view_default_56 = None
        native_layer_norm_default_11 = torch.ops.aten.native_layer_norm.default(add_tensor_11, [384], primals_96, primals_95, 1e-06)
        getitem_33 = native_layer_norm_default_11[0]
        getitem_34 = native_layer_norm_default_11[1]
        getitem_35 = native_layer_norm_default_11[2];  native_layer_norm_default_11 = None
        view_default_57 = torch.ops.aten.view.default(getitem_33, [1576, 384]);  getitem_33 = None
        t_default_22 = torch.ops.aten.t.default(primals_90);  primals_90 = None
        addmm_default_22 = torch.ops.aten.addmm.default(primals_89, view_default_57, t_default_22);  primals_89 = None
        view_default_58 = torch.ops.aten.view.default(addmm_default_22, [8, 197, 1536]);  addmm_default_22 = None
        gelu_default_5 = torch.ops.aten.gelu.default(view_default_58)
        view_default_59 = torch.ops.aten.view.default(gelu_default_5, [1576, 1536]);  gelu_default_5 = None
        t_default_23 = torch.ops.aten.t.default(primals_92);  primals_92 = None
        addmm_default_23 = torch.ops.aten.addmm.default(primals_91, view_default_59, t_default_23);  primals_91 = None
        view_default_60 = torch.ops.aten.view.default(addmm_default_23, [8, 197, 384]);  addmm_default_23 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(add_tensor_11, view_default_60);  view_default_60 = None
        native_layer_norm_default_12 = torch.ops.aten.native_layer_norm.default(add_tensor_12, [384], primals_106, primals_105, 1e-06)
        getitem_36 = native_layer_norm_default_12[0]
        getitem_37 = native_layer_norm_default_12[1]
        getitem_38 = native_layer_norm_default_12[2];  native_layer_norm_default_12 = None
        view_default_61 = torch.ops.aten.view.default(getitem_36, [1576, 384]);  getitem_36 = None
        t_default_24 = torch.ops.aten.t.default(primals_100);  primals_100 = None
        addmm_default_24 = torch.ops.aten.addmm.default(primals_99, view_default_61, t_default_24);  primals_99 = None
        view_default_62 = torch.ops.aten.view.default(addmm_default_24, [8, 197, 1152]);  addmm_default_24 = None
        view_default_63 = torch.ops.aten.view.default(view_default_62, [8, 197, 3, 6, 64]);  view_default_62 = None
        permute_default_6 = torch.ops.aten.permute.default(view_default_63, [2, 0, 3, 1, 4]);  view_default_63 = None
        select_int_18 = torch.ops.aten.select.int(permute_default_6, 0, 0)
        select_int_19 = torch.ops.aten.select.int(permute_default_6, 0, 1)
        select_int_20 = torch.ops.aten.select.int(permute_default_6, 0, 2);  permute_default_6 = None
        transpose_int_13 = torch.ops.aten.transpose.int(select_int_19, -2, -1);  select_int_19 = None
        expand_default_24 = torch.ops.aten.expand.default(select_int_18, [8, 6, 197, 64]);  select_int_18 = None
        clone_default_24 = torch.ops.aten.clone.default(expand_default_24, memory_format = torch.contiguous_format);  expand_default_24 = None
        _unsafe_view_default_36 = torch.ops.aten._unsafe_view.default(clone_default_24, [48, 197, 64]);  clone_default_24 = None
        expand_default_25 = torch.ops.aten.expand.default(transpose_int_13, [8, 6, 64, 197]);  transpose_int_13 = None
        clone_default_25 = torch.ops.aten.clone.default(expand_default_25, memory_format = torch.contiguous_format);  expand_default_25 = None
        _unsafe_view_default_37 = torch.ops.aten._unsafe_view.default(clone_default_25, [48, 64, 197]);  clone_default_25 = None
        bmm_default_12 = torch.ops.aten.bmm.default(_unsafe_view_default_36, _unsafe_view_default_37)
        _unsafe_view_default_38 = torch.ops.aten._unsafe_view.default(bmm_default_12, [8, 6, 197, 197]);  bmm_default_12 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(_unsafe_view_default_38, 0.125);  _unsafe_view_default_38 = None
        _softmax_default_6 = torch.ops.aten._softmax.default(mul_tensor_6, -1, False);  mul_tensor_6 = None
        expand_default_26 = torch.ops.aten.expand.default(_softmax_default_6, [8, 6, 197, 197])
        view_default_64 = torch.ops.aten.view.default(expand_default_26, [48, 197, 197]);  expand_default_26 = None
        expand_default_27 = torch.ops.aten.expand.default(select_int_20, [8, 6, 197, 64]);  select_int_20 = None
        clone_default_26 = torch.ops.aten.clone.default(expand_default_27, memory_format = torch.contiguous_format);  expand_default_27 = None
        _unsafe_view_default_39 = torch.ops.aten._unsafe_view.default(clone_default_26, [48, 197, 64]);  clone_default_26 = None
        bmm_default_13 = torch.ops.aten.bmm.default(view_default_64, _unsafe_view_default_39)
        _unsafe_view_default_40 = torch.ops.aten._unsafe_view.default(bmm_default_13, [8, 6, 197, 64]);  bmm_default_13 = None
        transpose_int_14 = torch.ops.aten.transpose.int(_unsafe_view_default_40, 1, 2);  _unsafe_view_default_40 = None
        clone_default_27 = torch.ops.aten.clone.default(transpose_int_14, memory_format = torch.contiguous_format);  transpose_int_14 = None
        _unsafe_view_default_41 = torch.ops.aten._unsafe_view.default(clone_default_27, [8, 197, 384]);  clone_default_27 = None
        view_default_65 = torch.ops.aten.view.default(_unsafe_view_default_41, [1576, 384]);  _unsafe_view_default_41 = None
        t_default_25 = torch.ops.aten.t.default(primals_98);  primals_98 = None
        addmm_default_25 = torch.ops.aten.addmm.default(primals_97, view_default_65, t_default_25);  primals_97 = None
        view_default_66 = torch.ops.aten.view.default(addmm_default_25, [8, 197, 384]);  addmm_default_25 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(add_tensor_12, view_default_66);  view_default_66 = None
        native_layer_norm_default_13 = torch.ops.aten.native_layer_norm.default(add_tensor_13, [384], primals_108, primals_107, 1e-06)
        getitem_39 = native_layer_norm_default_13[0]
        getitem_40 = native_layer_norm_default_13[1]
        getitem_41 = native_layer_norm_default_13[2];  native_layer_norm_default_13 = None
        view_default_67 = torch.ops.aten.view.default(getitem_39, [1576, 384]);  getitem_39 = None
        t_default_26 = torch.ops.aten.t.default(primals_102);  primals_102 = None
        addmm_default_26 = torch.ops.aten.addmm.default(primals_101, view_default_67, t_default_26);  primals_101 = None
        view_default_68 = torch.ops.aten.view.default(addmm_default_26, [8, 197, 1536]);  addmm_default_26 = None
        gelu_default_6 = torch.ops.aten.gelu.default(view_default_68)
        view_default_69 = torch.ops.aten.view.default(gelu_default_6, [1576, 1536]);  gelu_default_6 = None
        t_default_27 = torch.ops.aten.t.default(primals_104);  primals_104 = None
        addmm_default_27 = torch.ops.aten.addmm.default(primals_103, view_default_69, t_default_27);  primals_103 = None
        view_default_70 = torch.ops.aten.view.default(addmm_default_27, [8, 197, 384]);  addmm_default_27 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(add_tensor_13, view_default_70);  view_default_70 = None
        native_layer_norm_default_14 = torch.ops.aten.native_layer_norm.default(add_tensor_14, [384], primals_118, primals_117, 1e-06)
        getitem_42 = native_layer_norm_default_14[0]
        getitem_43 = native_layer_norm_default_14[1]
        getitem_44 = native_layer_norm_default_14[2];  native_layer_norm_default_14 = None
        view_default_71 = torch.ops.aten.view.default(getitem_42, [1576, 384]);  getitem_42 = None
        t_default_28 = torch.ops.aten.t.default(primals_112);  primals_112 = None
        addmm_default_28 = torch.ops.aten.addmm.default(primals_111, view_default_71, t_default_28);  primals_111 = None
        view_default_72 = torch.ops.aten.view.default(addmm_default_28, [8, 197, 1152]);  addmm_default_28 = None
        view_default_73 = torch.ops.aten.view.default(view_default_72, [8, 197, 3, 6, 64]);  view_default_72 = None
        permute_default_7 = torch.ops.aten.permute.default(view_default_73, [2, 0, 3, 1, 4]);  view_default_73 = None
        select_int_21 = torch.ops.aten.select.int(permute_default_7, 0, 0)
        select_int_22 = torch.ops.aten.select.int(permute_default_7, 0, 1)
        select_int_23 = torch.ops.aten.select.int(permute_default_7, 0, 2);  permute_default_7 = None
        transpose_int_15 = torch.ops.aten.transpose.int(select_int_22, -2, -1);  select_int_22 = None
        expand_default_28 = torch.ops.aten.expand.default(select_int_21, [8, 6, 197, 64]);  select_int_21 = None
        clone_default_28 = torch.ops.aten.clone.default(expand_default_28, memory_format = torch.contiguous_format);  expand_default_28 = None
        _unsafe_view_default_42 = torch.ops.aten._unsafe_view.default(clone_default_28, [48, 197, 64]);  clone_default_28 = None
        expand_default_29 = torch.ops.aten.expand.default(transpose_int_15, [8, 6, 64, 197]);  transpose_int_15 = None
        clone_default_29 = torch.ops.aten.clone.default(expand_default_29, memory_format = torch.contiguous_format);  expand_default_29 = None
        _unsafe_view_default_43 = torch.ops.aten._unsafe_view.default(clone_default_29, [48, 64, 197]);  clone_default_29 = None
        bmm_default_14 = torch.ops.aten.bmm.default(_unsafe_view_default_42, _unsafe_view_default_43)
        _unsafe_view_default_44 = torch.ops.aten._unsafe_view.default(bmm_default_14, [8, 6, 197, 197]);  bmm_default_14 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(_unsafe_view_default_44, 0.125);  _unsafe_view_default_44 = None
        _softmax_default_7 = torch.ops.aten._softmax.default(mul_tensor_7, -1, False);  mul_tensor_7 = None
        expand_default_30 = torch.ops.aten.expand.default(_softmax_default_7, [8, 6, 197, 197])
        view_default_74 = torch.ops.aten.view.default(expand_default_30, [48, 197, 197]);  expand_default_30 = None
        expand_default_31 = torch.ops.aten.expand.default(select_int_23, [8, 6, 197, 64]);  select_int_23 = None
        clone_default_30 = torch.ops.aten.clone.default(expand_default_31, memory_format = torch.contiguous_format);  expand_default_31 = None
        _unsafe_view_default_45 = torch.ops.aten._unsafe_view.default(clone_default_30, [48, 197, 64]);  clone_default_30 = None
        bmm_default_15 = torch.ops.aten.bmm.default(view_default_74, _unsafe_view_default_45)
        _unsafe_view_default_46 = torch.ops.aten._unsafe_view.default(bmm_default_15, [8, 6, 197, 64]);  bmm_default_15 = None
        transpose_int_16 = torch.ops.aten.transpose.int(_unsafe_view_default_46, 1, 2);  _unsafe_view_default_46 = None
        clone_default_31 = torch.ops.aten.clone.default(transpose_int_16, memory_format = torch.contiguous_format);  transpose_int_16 = None
        _unsafe_view_default_47 = torch.ops.aten._unsafe_view.default(clone_default_31, [8, 197, 384]);  clone_default_31 = None
        view_default_75 = torch.ops.aten.view.default(_unsafe_view_default_47, [1576, 384]);  _unsafe_view_default_47 = None
        t_default_29 = torch.ops.aten.t.default(primals_110);  primals_110 = None
        addmm_default_29 = torch.ops.aten.addmm.default(primals_109, view_default_75, t_default_29);  primals_109 = None
        view_default_76 = torch.ops.aten.view.default(addmm_default_29, [8, 197, 384]);  addmm_default_29 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(add_tensor_14, view_default_76);  view_default_76 = None
        native_layer_norm_default_15 = torch.ops.aten.native_layer_norm.default(add_tensor_15, [384], primals_120, primals_119, 1e-06)
        getitem_45 = native_layer_norm_default_15[0]
        getitem_46 = native_layer_norm_default_15[1]
        getitem_47 = native_layer_norm_default_15[2];  native_layer_norm_default_15 = None
        view_default_77 = torch.ops.aten.view.default(getitem_45, [1576, 384]);  getitem_45 = None
        t_default_30 = torch.ops.aten.t.default(primals_114);  primals_114 = None
        addmm_default_30 = torch.ops.aten.addmm.default(primals_113, view_default_77, t_default_30);  primals_113 = None
        view_default_78 = torch.ops.aten.view.default(addmm_default_30, [8, 197, 1536]);  addmm_default_30 = None
        gelu_default_7 = torch.ops.aten.gelu.default(view_default_78)
        view_default_79 = torch.ops.aten.view.default(gelu_default_7, [1576, 1536]);  gelu_default_7 = None
        t_default_31 = torch.ops.aten.t.default(primals_116);  primals_116 = None
        addmm_default_31 = torch.ops.aten.addmm.default(primals_115, view_default_79, t_default_31);  primals_115 = None
        view_default_80 = torch.ops.aten.view.default(addmm_default_31, [8, 197, 384]);  addmm_default_31 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(add_tensor_15, view_default_80);  view_default_80 = None
        native_layer_norm_default_16 = torch.ops.aten.native_layer_norm.default(add_tensor_16, [384], primals_130, primals_129, 1e-06)
        getitem_48 = native_layer_norm_default_16[0]
        getitem_49 = native_layer_norm_default_16[1]
        getitem_50 = native_layer_norm_default_16[2];  native_layer_norm_default_16 = None
        view_default_81 = torch.ops.aten.view.default(getitem_48, [1576, 384]);  getitem_48 = None
        t_default_32 = torch.ops.aten.t.default(primals_124);  primals_124 = None
        addmm_default_32 = torch.ops.aten.addmm.default(primals_123, view_default_81, t_default_32);  primals_123 = None
        view_default_82 = torch.ops.aten.view.default(addmm_default_32, [8, 197, 1152]);  addmm_default_32 = None
        view_default_83 = torch.ops.aten.view.default(view_default_82, [8, 197, 3, 6, 64]);  view_default_82 = None
        permute_default_8 = torch.ops.aten.permute.default(view_default_83, [2, 0, 3, 1, 4]);  view_default_83 = None
        select_int_24 = torch.ops.aten.select.int(permute_default_8, 0, 0)
        select_int_25 = torch.ops.aten.select.int(permute_default_8, 0, 1)
        select_int_26 = torch.ops.aten.select.int(permute_default_8, 0, 2);  permute_default_8 = None
        transpose_int_17 = torch.ops.aten.transpose.int(select_int_25, -2, -1);  select_int_25 = None
        expand_default_32 = torch.ops.aten.expand.default(select_int_24, [8, 6, 197, 64]);  select_int_24 = None
        clone_default_32 = torch.ops.aten.clone.default(expand_default_32, memory_format = torch.contiguous_format);  expand_default_32 = None
        _unsafe_view_default_48 = torch.ops.aten._unsafe_view.default(clone_default_32, [48, 197, 64]);  clone_default_32 = None
        expand_default_33 = torch.ops.aten.expand.default(transpose_int_17, [8, 6, 64, 197]);  transpose_int_17 = None
        clone_default_33 = torch.ops.aten.clone.default(expand_default_33, memory_format = torch.contiguous_format);  expand_default_33 = None
        _unsafe_view_default_49 = torch.ops.aten._unsafe_view.default(clone_default_33, [48, 64, 197]);  clone_default_33 = None
        bmm_default_16 = torch.ops.aten.bmm.default(_unsafe_view_default_48, _unsafe_view_default_49)
        _unsafe_view_default_50 = torch.ops.aten._unsafe_view.default(bmm_default_16, [8, 6, 197, 197]);  bmm_default_16 = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(_unsafe_view_default_50, 0.125);  _unsafe_view_default_50 = None
        _softmax_default_8 = torch.ops.aten._softmax.default(mul_tensor_8, -1, False);  mul_tensor_8 = None
        expand_default_34 = torch.ops.aten.expand.default(_softmax_default_8, [8, 6, 197, 197])
        view_default_84 = torch.ops.aten.view.default(expand_default_34, [48, 197, 197]);  expand_default_34 = None
        expand_default_35 = torch.ops.aten.expand.default(select_int_26, [8, 6, 197, 64]);  select_int_26 = None
        clone_default_34 = torch.ops.aten.clone.default(expand_default_35, memory_format = torch.contiguous_format);  expand_default_35 = None
        _unsafe_view_default_51 = torch.ops.aten._unsafe_view.default(clone_default_34, [48, 197, 64]);  clone_default_34 = None
        bmm_default_17 = torch.ops.aten.bmm.default(view_default_84, _unsafe_view_default_51)
        _unsafe_view_default_52 = torch.ops.aten._unsafe_view.default(bmm_default_17, [8, 6, 197, 64]);  bmm_default_17 = None
        transpose_int_18 = torch.ops.aten.transpose.int(_unsafe_view_default_52, 1, 2);  _unsafe_view_default_52 = None
        clone_default_35 = torch.ops.aten.clone.default(transpose_int_18, memory_format = torch.contiguous_format);  transpose_int_18 = None
        _unsafe_view_default_53 = torch.ops.aten._unsafe_view.default(clone_default_35, [8, 197, 384]);  clone_default_35 = None
        view_default_85 = torch.ops.aten.view.default(_unsafe_view_default_53, [1576, 384]);  _unsafe_view_default_53 = None
        t_default_33 = torch.ops.aten.t.default(primals_122);  primals_122 = None
        addmm_default_33 = torch.ops.aten.addmm.default(primals_121, view_default_85, t_default_33);  primals_121 = None
        view_default_86 = torch.ops.aten.view.default(addmm_default_33, [8, 197, 384]);  addmm_default_33 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(add_tensor_16, view_default_86);  view_default_86 = None
        native_layer_norm_default_17 = torch.ops.aten.native_layer_norm.default(add_tensor_17, [384], primals_132, primals_131, 1e-06)
        getitem_51 = native_layer_norm_default_17[0]
        getitem_52 = native_layer_norm_default_17[1]
        getitem_53 = native_layer_norm_default_17[2];  native_layer_norm_default_17 = None
        view_default_87 = torch.ops.aten.view.default(getitem_51, [1576, 384]);  getitem_51 = None
        t_default_34 = torch.ops.aten.t.default(primals_126);  primals_126 = None
        addmm_default_34 = torch.ops.aten.addmm.default(primals_125, view_default_87, t_default_34);  primals_125 = None
        view_default_88 = torch.ops.aten.view.default(addmm_default_34, [8, 197, 1536]);  addmm_default_34 = None
        gelu_default_8 = torch.ops.aten.gelu.default(view_default_88)
        view_default_89 = torch.ops.aten.view.default(gelu_default_8, [1576, 1536]);  gelu_default_8 = None
        t_default_35 = torch.ops.aten.t.default(primals_128);  primals_128 = None
        addmm_default_35 = torch.ops.aten.addmm.default(primals_127, view_default_89, t_default_35);  primals_127 = None
        view_default_90 = torch.ops.aten.view.default(addmm_default_35, [8, 197, 384]);  addmm_default_35 = None
        add_tensor_18 = torch.ops.aten.add.Tensor(add_tensor_17, view_default_90);  view_default_90 = None
        native_layer_norm_default_18 = torch.ops.aten.native_layer_norm.default(add_tensor_18, [384], primals_142, primals_141, 1e-06)
        getitem_54 = native_layer_norm_default_18[0]
        getitem_55 = native_layer_norm_default_18[1]
        getitem_56 = native_layer_norm_default_18[2];  native_layer_norm_default_18 = None
        view_default_91 = torch.ops.aten.view.default(getitem_54, [1576, 384]);  getitem_54 = None
        t_default_36 = torch.ops.aten.t.default(primals_136);  primals_136 = None
        addmm_default_36 = torch.ops.aten.addmm.default(primals_135, view_default_91, t_default_36);  primals_135 = None
        view_default_92 = torch.ops.aten.view.default(addmm_default_36, [8, 197, 1152]);  addmm_default_36 = None
        view_default_93 = torch.ops.aten.view.default(view_default_92, [8, 197, 3, 6, 64]);  view_default_92 = None
        permute_default_9 = torch.ops.aten.permute.default(view_default_93, [2, 0, 3, 1, 4]);  view_default_93 = None
        select_int_27 = torch.ops.aten.select.int(permute_default_9, 0, 0)
        select_int_28 = torch.ops.aten.select.int(permute_default_9, 0, 1)
        select_int_29 = torch.ops.aten.select.int(permute_default_9, 0, 2);  permute_default_9 = None
        transpose_int_19 = torch.ops.aten.transpose.int(select_int_28, -2, -1);  select_int_28 = None
        expand_default_36 = torch.ops.aten.expand.default(select_int_27, [8, 6, 197, 64]);  select_int_27 = None
        clone_default_36 = torch.ops.aten.clone.default(expand_default_36, memory_format = torch.contiguous_format);  expand_default_36 = None
        _unsafe_view_default_54 = torch.ops.aten._unsafe_view.default(clone_default_36, [48, 197, 64]);  clone_default_36 = None
        expand_default_37 = torch.ops.aten.expand.default(transpose_int_19, [8, 6, 64, 197]);  transpose_int_19 = None
        clone_default_37 = torch.ops.aten.clone.default(expand_default_37, memory_format = torch.contiguous_format);  expand_default_37 = None
        _unsafe_view_default_55 = torch.ops.aten._unsafe_view.default(clone_default_37, [48, 64, 197]);  clone_default_37 = None
        bmm_default_18 = torch.ops.aten.bmm.default(_unsafe_view_default_54, _unsafe_view_default_55)
        _unsafe_view_default_56 = torch.ops.aten._unsafe_view.default(bmm_default_18, [8, 6, 197, 197]);  bmm_default_18 = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(_unsafe_view_default_56, 0.125);  _unsafe_view_default_56 = None
        _softmax_default_9 = torch.ops.aten._softmax.default(mul_tensor_9, -1, False);  mul_tensor_9 = None
        expand_default_38 = torch.ops.aten.expand.default(_softmax_default_9, [8, 6, 197, 197])
        view_default_94 = torch.ops.aten.view.default(expand_default_38, [48, 197, 197]);  expand_default_38 = None
        expand_default_39 = torch.ops.aten.expand.default(select_int_29, [8, 6, 197, 64]);  select_int_29 = None
        clone_default_38 = torch.ops.aten.clone.default(expand_default_39, memory_format = torch.contiguous_format);  expand_default_39 = None
        _unsafe_view_default_57 = torch.ops.aten._unsafe_view.default(clone_default_38, [48, 197, 64]);  clone_default_38 = None
        bmm_default_19 = torch.ops.aten.bmm.default(view_default_94, _unsafe_view_default_57)
        _unsafe_view_default_58 = torch.ops.aten._unsafe_view.default(bmm_default_19, [8, 6, 197, 64]);  bmm_default_19 = None
        transpose_int_20 = torch.ops.aten.transpose.int(_unsafe_view_default_58, 1, 2);  _unsafe_view_default_58 = None
        clone_default_39 = torch.ops.aten.clone.default(transpose_int_20, memory_format = torch.contiguous_format);  transpose_int_20 = None
        _unsafe_view_default_59 = torch.ops.aten._unsafe_view.default(clone_default_39, [8, 197, 384]);  clone_default_39 = None
        view_default_95 = torch.ops.aten.view.default(_unsafe_view_default_59, [1576, 384]);  _unsafe_view_default_59 = None
        t_default_37 = torch.ops.aten.t.default(primals_134);  primals_134 = None
        addmm_default_37 = torch.ops.aten.addmm.default(primals_133, view_default_95, t_default_37);  primals_133 = None
        view_default_96 = torch.ops.aten.view.default(addmm_default_37, [8, 197, 384]);  addmm_default_37 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(add_tensor_18, view_default_96);  view_default_96 = None
        native_layer_norm_default_19 = torch.ops.aten.native_layer_norm.default(add_tensor_19, [384], primals_144, primals_143, 1e-06)
        getitem_57 = native_layer_norm_default_19[0]
        getitem_58 = native_layer_norm_default_19[1]
        getitem_59 = native_layer_norm_default_19[2];  native_layer_norm_default_19 = None
        view_default_97 = torch.ops.aten.view.default(getitem_57, [1576, 384]);  getitem_57 = None
        t_default_38 = torch.ops.aten.t.default(primals_138);  primals_138 = None
        addmm_default_38 = torch.ops.aten.addmm.default(primals_137, view_default_97, t_default_38);  primals_137 = None
        view_default_98 = torch.ops.aten.view.default(addmm_default_38, [8, 197, 1536]);  addmm_default_38 = None
        gelu_default_9 = torch.ops.aten.gelu.default(view_default_98)
        view_default_99 = torch.ops.aten.view.default(gelu_default_9, [1576, 1536]);  gelu_default_9 = None
        t_default_39 = torch.ops.aten.t.default(primals_140);  primals_140 = None
        addmm_default_39 = torch.ops.aten.addmm.default(primals_139, view_default_99, t_default_39);  primals_139 = None
        view_default_100 = torch.ops.aten.view.default(addmm_default_39, [8, 197, 384]);  addmm_default_39 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(add_tensor_19, view_default_100);  view_default_100 = None
        native_layer_norm_default_20 = torch.ops.aten.native_layer_norm.default(add_tensor_20, [384], primals_22, primals_21, 1e-06)
        getitem_60 = native_layer_norm_default_20[0]
        getitem_61 = native_layer_norm_default_20[1]
        getitem_62 = native_layer_norm_default_20[2];  native_layer_norm_default_20 = None
        view_default_101 = torch.ops.aten.view.default(getitem_60, [1576, 384]);  getitem_60 = None
        t_default_40 = torch.ops.aten.t.default(primals_16);  primals_16 = None
        addmm_default_40 = torch.ops.aten.addmm.default(primals_15, view_default_101, t_default_40);  primals_15 = None
        view_default_102 = torch.ops.aten.view.default(addmm_default_40, [8, 197, 1152]);  addmm_default_40 = None
        view_default_103 = torch.ops.aten.view.default(view_default_102, [8, 197, 3, 6, 64]);  view_default_102 = None
        permute_default_10 = torch.ops.aten.permute.default(view_default_103, [2, 0, 3, 1, 4]);  view_default_103 = None
        select_int_30 = torch.ops.aten.select.int(permute_default_10, 0, 0)
        select_int_31 = torch.ops.aten.select.int(permute_default_10, 0, 1)
        select_int_32 = torch.ops.aten.select.int(permute_default_10, 0, 2);  permute_default_10 = None
        transpose_int_21 = torch.ops.aten.transpose.int(select_int_31, -2, -1);  select_int_31 = None
        expand_default_40 = torch.ops.aten.expand.default(select_int_30, [8, 6, 197, 64]);  select_int_30 = None
        clone_default_40 = torch.ops.aten.clone.default(expand_default_40, memory_format = torch.contiguous_format);  expand_default_40 = None
        _unsafe_view_default_60 = torch.ops.aten._unsafe_view.default(clone_default_40, [48, 197, 64]);  clone_default_40 = None
        expand_default_41 = torch.ops.aten.expand.default(transpose_int_21, [8, 6, 64, 197]);  transpose_int_21 = None
        clone_default_41 = torch.ops.aten.clone.default(expand_default_41, memory_format = torch.contiguous_format);  expand_default_41 = None
        _unsafe_view_default_61 = torch.ops.aten._unsafe_view.default(clone_default_41, [48, 64, 197]);  clone_default_41 = None
        bmm_default_20 = torch.ops.aten.bmm.default(_unsafe_view_default_60, _unsafe_view_default_61)
        _unsafe_view_default_62 = torch.ops.aten._unsafe_view.default(bmm_default_20, [8, 6, 197, 197]);  bmm_default_20 = None
        mul_tensor_10 = torch.ops.aten.mul.Tensor(_unsafe_view_default_62, 0.125);  _unsafe_view_default_62 = None
        _softmax_default_10 = torch.ops.aten._softmax.default(mul_tensor_10, -1, False);  mul_tensor_10 = None
        expand_default_42 = torch.ops.aten.expand.default(_softmax_default_10, [8, 6, 197, 197])
        view_default_104 = torch.ops.aten.view.default(expand_default_42, [48, 197, 197]);  expand_default_42 = None
        expand_default_43 = torch.ops.aten.expand.default(select_int_32, [8, 6, 197, 64]);  select_int_32 = None
        clone_default_42 = torch.ops.aten.clone.default(expand_default_43, memory_format = torch.contiguous_format);  expand_default_43 = None
        _unsafe_view_default_63 = torch.ops.aten._unsafe_view.default(clone_default_42, [48, 197, 64]);  clone_default_42 = None
        bmm_default_21 = torch.ops.aten.bmm.default(view_default_104, _unsafe_view_default_63)
        _unsafe_view_default_64 = torch.ops.aten._unsafe_view.default(bmm_default_21, [8, 6, 197, 64]);  bmm_default_21 = None
        transpose_int_22 = torch.ops.aten.transpose.int(_unsafe_view_default_64, 1, 2);  _unsafe_view_default_64 = None
        clone_default_43 = torch.ops.aten.clone.default(transpose_int_22, memory_format = torch.contiguous_format);  transpose_int_22 = None
        _unsafe_view_default_65 = torch.ops.aten._unsafe_view.default(clone_default_43, [8, 197, 384]);  clone_default_43 = None
        view_default_105 = torch.ops.aten.view.default(_unsafe_view_default_65, [1576, 384]);  _unsafe_view_default_65 = None
        t_default_41 = torch.ops.aten.t.default(primals_14);  primals_14 = None
        addmm_default_41 = torch.ops.aten.addmm.default(primals_13, view_default_105, t_default_41);  primals_13 = None
        view_default_106 = torch.ops.aten.view.default(addmm_default_41, [8, 197, 384]);  addmm_default_41 = None
        add_tensor_21 = torch.ops.aten.add.Tensor(add_tensor_20, view_default_106);  view_default_106 = None
        native_layer_norm_default_21 = torch.ops.aten.native_layer_norm.default(add_tensor_21, [384], primals_24, primals_23, 1e-06)
        getitem_63 = native_layer_norm_default_21[0]
        getitem_64 = native_layer_norm_default_21[1]
        getitem_65 = native_layer_norm_default_21[2];  native_layer_norm_default_21 = None
        view_default_107 = torch.ops.aten.view.default(getitem_63, [1576, 384]);  getitem_63 = None
        t_default_42 = torch.ops.aten.t.default(primals_18);  primals_18 = None
        addmm_default_42 = torch.ops.aten.addmm.default(primals_17, view_default_107, t_default_42);  primals_17 = None
        view_default_108 = torch.ops.aten.view.default(addmm_default_42, [8, 197, 1536]);  addmm_default_42 = None
        gelu_default_10 = torch.ops.aten.gelu.default(view_default_108)
        view_default_109 = torch.ops.aten.view.default(gelu_default_10, [1576, 1536]);  gelu_default_10 = None
        t_default_43 = torch.ops.aten.t.default(primals_20);  primals_20 = None
        addmm_default_43 = torch.ops.aten.addmm.default(primals_19, view_default_109, t_default_43);  primals_19 = None
        view_default_110 = torch.ops.aten.view.default(addmm_default_43, [8, 197, 384]);  addmm_default_43 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(add_tensor_21, view_default_110);  view_default_110 = None
        native_layer_norm_default_22 = torch.ops.aten.native_layer_norm.default(add_tensor_22, [384], primals_34, primals_33, 1e-06)
        getitem_66 = native_layer_norm_default_22[0]
        getitem_67 = native_layer_norm_default_22[1]
        getitem_68 = native_layer_norm_default_22[2];  native_layer_norm_default_22 = None
        view_default_111 = torch.ops.aten.view.default(getitem_66, [1576, 384]);  getitem_66 = None
        t_default_44 = torch.ops.aten.t.default(primals_28);  primals_28 = None
        addmm_default_44 = torch.ops.aten.addmm.default(primals_27, view_default_111, t_default_44);  primals_27 = None
        view_default_112 = torch.ops.aten.view.default(addmm_default_44, [8, 197, 1152]);  addmm_default_44 = None
        view_default_113 = torch.ops.aten.view.default(view_default_112, [8, 197, 3, 6, 64]);  view_default_112 = None
        permute_default_11 = torch.ops.aten.permute.default(view_default_113, [2, 0, 3, 1, 4]);  view_default_113 = None
        select_int_33 = torch.ops.aten.select.int(permute_default_11, 0, 0)
        select_int_34 = torch.ops.aten.select.int(permute_default_11, 0, 1)
        select_int_35 = torch.ops.aten.select.int(permute_default_11, 0, 2);  permute_default_11 = None
        transpose_int_23 = torch.ops.aten.transpose.int(select_int_34, -2, -1);  select_int_34 = None
        expand_default_44 = torch.ops.aten.expand.default(select_int_33, [8, 6, 197, 64]);  select_int_33 = None
        clone_default_44 = torch.ops.aten.clone.default(expand_default_44, memory_format = torch.contiguous_format);  expand_default_44 = None
        _unsafe_view_default_66 = torch.ops.aten._unsafe_view.default(clone_default_44, [48, 197, 64]);  clone_default_44 = None
        expand_default_45 = torch.ops.aten.expand.default(transpose_int_23, [8, 6, 64, 197]);  transpose_int_23 = None
        clone_default_45 = torch.ops.aten.clone.default(expand_default_45, memory_format = torch.contiguous_format);  expand_default_45 = None
        _unsafe_view_default_67 = torch.ops.aten._unsafe_view.default(clone_default_45, [48, 64, 197]);  clone_default_45 = None
        bmm_default_22 = torch.ops.aten.bmm.default(_unsafe_view_default_66, _unsafe_view_default_67)
        _unsafe_view_default_68 = torch.ops.aten._unsafe_view.default(bmm_default_22, [8, 6, 197, 197]);  bmm_default_22 = None
        mul_tensor_11 = torch.ops.aten.mul.Tensor(_unsafe_view_default_68, 0.125);  _unsafe_view_default_68 = None
        _softmax_default_11 = torch.ops.aten._softmax.default(mul_tensor_11, -1, False);  mul_tensor_11 = None
        expand_default_46 = torch.ops.aten.expand.default(_softmax_default_11, [8, 6, 197, 197])
        view_default_114 = torch.ops.aten.view.default(expand_default_46, [48, 197, 197]);  expand_default_46 = None
        expand_default_47 = torch.ops.aten.expand.default(select_int_35, [8, 6, 197, 64]);  select_int_35 = None
        clone_default_46 = torch.ops.aten.clone.default(expand_default_47, memory_format = torch.contiguous_format);  expand_default_47 = None
        _unsafe_view_default_69 = torch.ops.aten._unsafe_view.default(clone_default_46, [48, 197, 64]);  clone_default_46 = None
        bmm_default_23 = torch.ops.aten.bmm.default(view_default_114, _unsafe_view_default_69)
        _unsafe_view_default_70 = torch.ops.aten._unsafe_view.default(bmm_default_23, [8, 6, 197, 64]);  bmm_default_23 = None
        transpose_int_24 = torch.ops.aten.transpose.int(_unsafe_view_default_70, 1, 2);  _unsafe_view_default_70 = None
        clone_default_47 = torch.ops.aten.clone.default(transpose_int_24, memory_format = torch.contiguous_format);  transpose_int_24 = None
        _unsafe_view_default_71 = torch.ops.aten._unsafe_view.default(clone_default_47, [8, 197, 384]);  clone_default_47 = None
        view_default_115 = torch.ops.aten.view.default(_unsafe_view_default_71, [1576, 384]);  _unsafe_view_default_71 = None
        t_default_45 = torch.ops.aten.t.default(primals_26);  primals_26 = None
        addmm_default_45 = torch.ops.aten.addmm.default(primals_25, view_default_115, t_default_45);  primals_25 = None
        view_default_116 = torch.ops.aten.view.default(addmm_default_45, [8, 197, 384]);  addmm_default_45 = None
        add_tensor_23 = torch.ops.aten.add.Tensor(add_tensor_22, view_default_116);  view_default_116 = None
        native_layer_norm_default_23 = torch.ops.aten.native_layer_norm.default(add_tensor_23, [384], primals_36, primals_35, 1e-06)
        getitem_69 = native_layer_norm_default_23[0]
        getitem_70 = native_layer_norm_default_23[1]
        getitem_71 = native_layer_norm_default_23[2];  native_layer_norm_default_23 = None
        view_default_117 = torch.ops.aten.view.default(getitem_69, [1576, 384]);  getitem_69 = None
        t_default_46 = torch.ops.aten.t.default(primals_30);  primals_30 = None
        addmm_default_46 = torch.ops.aten.addmm.default(primals_29, view_default_117, t_default_46);  primals_29 = None
        view_default_118 = torch.ops.aten.view.default(addmm_default_46, [8, 197, 1536]);  addmm_default_46 = None
        gelu_default_11 = torch.ops.aten.gelu.default(view_default_118)
        view_default_119 = torch.ops.aten.view.default(gelu_default_11, [1576, 1536]);  gelu_default_11 = None
        t_default_47 = torch.ops.aten.t.default(primals_32);  primals_32 = None
        addmm_default_47 = torch.ops.aten.addmm.default(primals_31, view_default_119, t_default_47);  primals_31 = None
        view_default_120 = torch.ops.aten.view.default(addmm_default_47, [8, 197, 384]);  addmm_default_47 = None
        add_tensor_24 = torch.ops.aten.add.Tensor(add_tensor_23, view_default_120);  view_default_120 = None
        native_layer_norm_default_24 = torch.ops.aten.native_layer_norm.default(add_tensor_24, [384], primals_149, primals_148, 1e-06)
        getitem_72 = native_layer_norm_default_24[0]
        getitem_73 = native_layer_norm_default_24[1]
        getitem_74 = native_layer_norm_default_24[2];  native_layer_norm_default_24 = None
        slice_tensor = torch.ops.aten.slice.Tensor(getitem_72, 0, 0, 9223372036854775807);  getitem_72 = None
        select_int_36 = torch.ops.aten.select.int(slice_tensor, 1, 0);  slice_tensor = None
        t_default_48 = torch.ops.aten.t.default(primals_147);  primals_147 = None
        addmm_default_48 = torch.ops.aten.addmm.default(primals_146, select_int_36, t_default_48);  primals_146 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(addmm_default_48, tangents_1)
        t_default_49 = torch.ops.aten.t.default(t_default_48);  t_default_48 = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_49);  t_default_49 = None
        t_default_50 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_50, select_int_36);  t_default_50 = select_int_36 = None
        t_default_51 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_121 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_52 = torch.ops.aten.t.default(t_default_51);  t_default_51 = None
        select_backward_default = torch.ops.aten.select_backward.default(mm_default, [8, 197, 384], 1, 0);  mm_default = None
        slice_backward_default = torch.ops.aten.slice_backward.default(select_backward_default, [8, 197, 384], 0, 0, 9223372036854775807, 1);  select_backward_default = None
        native_layer_norm_backward_default = torch.ops.aten.native_layer_norm_backward.default(slice_backward_default, add_tensor_24, [384], getitem_73, getitem_74, primals_149, primals_148, [True, True, True]);  slice_backward_default = add_tensor_24 = getitem_73 = getitem_74 = primals_149 = primals_148 = None
        getitem_75 = native_layer_norm_backward_default[0]
        getitem_76 = native_layer_norm_backward_default[1]
        getitem_77 = native_layer_norm_backward_default[2];  native_layer_norm_backward_default = None
        view_default_122 = torch.ops.aten.view.default(getitem_75, [1576, 384])
        t_default_53 = torch.ops.aten.t.default(t_default_47);  t_default_47 = None
        mm_default_2 = torch.ops.aten.mm.default(view_default_122, t_default_53);  t_default_53 = None
        t_default_54 = torch.ops.aten.t.default(view_default_122)
        mm_default_3 = torch.ops.aten.mm.default(t_default_54, view_default_119);  t_default_54 = view_default_119 = None
        t_default_55 = torch.ops.aten.t.default(mm_default_3);  mm_default_3 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(view_default_122, [0], True);  view_default_122 = None
        view_default_123 = torch.ops.aten.view.default(sum_dim_int_list_1, [384]);  sum_dim_int_list_1 = None
        t_default_56 = torch.ops.aten.t.default(t_default_55);  t_default_55 = None
        view_default_124 = torch.ops.aten.view.default(mm_default_2, [8, 197, 1536]);  mm_default_2 = None
        to_dtype = torch.ops.aten.to.dtype(view_default_124, torch.float32);  view_default_124 = None
        to_dtype_1 = torch.ops.aten.to.dtype(view_default_118, torch.float32);  view_default_118 = None
        mul_tensor_12 = torch.ops.aten.mul.Tensor(to_dtype_1, 0.7071067811865476)
        erf_default = torch.ops.aten.erf.default(mul_tensor_12);  mul_tensor_12 = None
        add_tensor_25 = torch.ops.aten.add.Tensor(erf_default, 1);  erf_default = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(add_tensor_25, 0.5);  add_tensor_25 = None
        mul_tensor_14 = torch.ops.aten.mul.Tensor(to_dtype_1, to_dtype_1)
        mul_tensor_15 = torch.ops.aten.mul.Tensor(mul_tensor_14, -0.5);  mul_tensor_14 = None
        exp_default = torch.ops.aten.exp.default(mul_tensor_15);  mul_tensor_15 = None
        mul_tensor_16 = torch.ops.aten.mul.Tensor(exp_default, 0.3989422804014327);  exp_default = None
        mul_tensor_17 = torch.ops.aten.mul.Tensor(to_dtype_1, mul_tensor_16);  to_dtype_1 = mul_tensor_16 = None
        add_tensor_26 = torch.ops.aten.add.Tensor(mul_tensor_13, mul_tensor_17);  mul_tensor_13 = mul_tensor_17 = None
        mul_tensor_18 = torch.ops.aten.mul.Tensor(to_dtype, add_tensor_26);  to_dtype = add_tensor_26 = None
        to_dtype_2 = torch.ops.aten.to.dtype(mul_tensor_18, torch.float32);  mul_tensor_18 = None
        view_default_125 = torch.ops.aten.view.default(to_dtype_2, [1576, 1536]);  to_dtype_2 = None
        t_default_57 = torch.ops.aten.t.default(t_default_46);  t_default_46 = None
        mm_default_4 = torch.ops.aten.mm.default(view_default_125, t_default_57);  t_default_57 = None
        t_default_58 = torch.ops.aten.t.default(view_default_125)
        mm_default_5 = torch.ops.aten.mm.default(t_default_58, view_default_117);  t_default_58 = view_default_117 = None
        t_default_59 = torch.ops.aten.t.default(mm_default_5);  mm_default_5 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(view_default_125, [0], True);  view_default_125 = None
        view_default_126 = torch.ops.aten.view.default(sum_dim_int_list_2, [1536]);  sum_dim_int_list_2 = None
        t_default_60 = torch.ops.aten.t.default(t_default_59);  t_default_59 = None
        view_default_127 = torch.ops.aten.view.default(mm_default_4, [8, 197, 384]);  mm_default_4 = None
        native_layer_norm_backward_default_1 = torch.ops.aten.native_layer_norm_backward.default(view_default_127, add_tensor_23, [384], getitem_70, getitem_71, primals_36, primals_35, [True, True, True]);  view_default_127 = add_tensor_23 = getitem_70 = getitem_71 = primals_36 = primals_35 = None
        getitem_78 = native_layer_norm_backward_default_1[0]
        getitem_79 = native_layer_norm_backward_default_1[1]
        getitem_80 = native_layer_norm_backward_default_1[2];  native_layer_norm_backward_default_1 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(getitem_75, getitem_78);  getitem_75 = getitem_78 = None
        view_default_128 = torch.ops.aten.view.default(add_tensor_27, [1576, 384])
        t_default_61 = torch.ops.aten.t.default(t_default_45);  t_default_45 = None
        mm_default_6 = torch.ops.aten.mm.default(view_default_128, t_default_61);  t_default_61 = None
        t_default_62 = torch.ops.aten.t.default(view_default_128)
        mm_default_7 = torch.ops.aten.mm.default(t_default_62, view_default_115);  t_default_62 = view_default_115 = None
        t_default_63 = torch.ops.aten.t.default(mm_default_7);  mm_default_7 = None
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(view_default_128, [0], True);  view_default_128 = None
        view_default_129 = torch.ops.aten.view.default(sum_dim_int_list_3, [384]);  sum_dim_int_list_3 = None
        t_default_64 = torch.ops.aten.t.default(t_default_63);  t_default_63 = None
        view_default_130 = torch.ops.aten.view.default(mm_default_6, [8, 197, 384]);  mm_default_6 = None
        view_default_131 = torch.ops.aten.view.default(view_default_130, [8, 197, 6, 64]);  view_default_130 = None
        transpose_int_25 = torch.ops.aten.transpose.int(view_default_131, 1, 2);  view_default_131 = None
        clone_default_48 = torch.ops.aten.clone.default(transpose_int_25, memory_format = torch.contiguous_format);  transpose_int_25 = None
        _unsafe_view_default_72 = torch.ops.aten._unsafe_view.default(clone_default_48, [48, 197, 64]);  clone_default_48 = None
        transpose_int_26 = torch.ops.aten.transpose.int(view_default_114, 1, 2);  view_default_114 = None
        bmm_default_24 = torch.ops.aten.bmm.default(transpose_int_26, _unsafe_view_default_72);  transpose_int_26 = None
        transpose_int_27 = torch.ops.aten.transpose.int(_unsafe_view_default_69, 1, 2);  _unsafe_view_default_69 = None
        bmm_default_25 = torch.ops.aten.bmm.default(_unsafe_view_default_72, transpose_int_27);  _unsafe_view_default_72 = transpose_int_27 = None
        view_default_132 = torch.ops.aten.view.default(bmm_default_24, [8, 6, 197, 64]);  bmm_default_24 = None
        view_default_133 = torch.ops.aten.view.default(bmm_default_25, [8, 6, 197, 197]);  bmm_default_25 = None
        _softmax_backward_data_default = torch.ops.aten._softmax_backward_data.default(view_default_133, _softmax_default_11, -1, torch.float32);  view_default_133 = _softmax_default_11 = None
        mul_tensor_19 = torch.ops.aten.mul.Tensor(_softmax_backward_data_default, 0.125);  _softmax_backward_data_default = None
        view_default_134 = torch.ops.aten.view.default(mul_tensor_19, [48, 197, 197]);  mul_tensor_19 = None
        transpose_int_28 = torch.ops.aten.transpose.int(_unsafe_view_default_66, 1, 2);  _unsafe_view_default_66 = None
        bmm_default_26 = torch.ops.aten.bmm.default(transpose_int_28, view_default_134);  transpose_int_28 = None
        transpose_int_29 = torch.ops.aten.transpose.int(_unsafe_view_default_67, 1, 2);  _unsafe_view_default_67 = None
        bmm_default_27 = torch.ops.aten.bmm.default(view_default_134, transpose_int_29);  view_default_134 = transpose_int_29 = None
        view_default_135 = torch.ops.aten.view.default(bmm_default_26, [8, 6, 64, 197]);  bmm_default_26 = None
        view_default_136 = torch.ops.aten.view.default(bmm_default_27, [8, 6, 197, 64]);  bmm_default_27 = None
        transpose_int_30 = torch.ops.aten.transpose.int(view_default_135, -2, -1);  view_default_135 = None
        select_backward_default_1 = torch.ops.aten.select_backward.default(view_default_132, [3, 8, 6, 197, 64], 0, 2);  view_default_132 = None
        select_backward_default_2 = torch.ops.aten.select_backward.default(transpose_int_30, [3, 8, 6, 197, 64], 0, 1);  transpose_int_30 = None
        add_tensor_28 = torch.ops.aten.add.Tensor(select_backward_default_1, select_backward_default_2);  select_backward_default_1 = select_backward_default_2 = None
        select_backward_default_3 = torch.ops.aten.select_backward.default(view_default_136, [3, 8, 6, 197, 64], 0, 0);  view_default_136 = None
        add_tensor_29 = torch.ops.aten.add.Tensor(add_tensor_28, select_backward_default_3);  add_tensor_28 = select_backward_default_3 = None
        permute_default_12 = torch.ops.aten.permute.default(add_tensor_29, [1, 3, 0, 2, 4]);  add_tensor_29 = None
        clone_default_49 = torch.ops.aten.clone.default(permute_default_12, memory_format = torch.contiguous_format);  permute_default_12 = None
        _unsafe_view_default_73 = torch.ops.aten._unsafe_view.default(clone_default_49, [8, 197, 1152]);  clone_default_49 = None
        view_default_137 = torch.ops.aten.view.default(_unsafe_view_default_73, [1576, 1152]);  _unsafe_view_default_73 = None
        t_default_65 = torch.ops.aten.t.default(t_default_44);  t_default_44 = None
        mm_default_8 = torch.ops.aten.mm.default(view_default_137, t_default_65);  t_default_65 = None
        t_default_66 = torch.ops.aten.t.default(view_default_137)
        mm_default_9 = torch.ops.aten.mm.default(t_default_66, view_default_111);  t_default_66 = view_default_111 = None
        t_default_67 = torch.ops.aten.t.default(mm_default_9);  mm_default_9 = None
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(view_default_137, [0], True);  view_default_137 = None
        view_default_138 = torch.ops.aten.view.default(sum_dim_int_list_4, [1152]);  sum_dim_int_list_4 = None
        t_default_68 = torch.ops.aten.t.default(t_default_67);  t_default_67 = None
        view_default_139 = torch.ops.aten.view.default(mm_default_8, [8, 197, 384]);  mm_default_8 = None
        native_layer_norm_backward_default_2 = torch.ops.aten.native_layer_norm_backward.default(view_default_139, add_tensor_22, [384], getitem_67, getitem_68, primals_34, primals_33, [True, True, True]);  view_default_139 = add_tensor_22 = getitem_67 = getitem_68 = primals_34 = primals_33 = None
        getitem_81 = native_layer_norm_backward_default_2[0]
        getitem_82 = native_layer_norm_backward_default_2[1]
        getitem_83 = native_layer_norm_backward_default_2[2];  native_layer_norm_backward_default_2 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(add_tensor_27, getitem_81);  add_tensor_27 = getitem_81 = None
        view_default_140 = torch.ops.aten.view.default(add_tensor_30, [1576, 384])
        t_default_69 = torch.ops.aten.t.default(t_default_43);  t_default_43 = None
        mm_default_10 = torch.ops.aten.mm.default(view_default_140, t_default_69);  t_default_69 = None
        t_default_70 = torch.ops.aten.t.default(view_default_140)
        mm_default_11 = torch.ops.aten.mm.default(t_default_70, view_default_109);  t_default_70 = view_default_109 = None
        t_default_71 = torch.ops.aten.t.default(mm_default_11);  mm_default_11 = None
        sum_dim_int_list_5 = torch.ops.aten.sum.dim_IntList(view_default_140, [0], True);  view_default_140 = None
        view_default_141 = torch.ops.aten.view.default(sum_dim_int_list_5, [384]);  sum_dim_int_list_5 = None
        t_default_72 = torch.ops.aten.t.default(t_default_71);  t_default_71 = None
        view_default_142 = torch.ops.aten.view.default(mm_default_10, [8, 197, 1536]);  mm_default_10 = None
        to_dtype_3 = torch.ops.aten.to.dtype(view_default_142, torch.float32);  view_default_142 = None
        to_dtype_4 = torch.ops.aten.to.dtype(view_default_108, torch.float32);  view_default_108 = None
        mul_tensor_20 = torch.ops.aten.mul.Tensor(to_dtype_4, 0.7071067811865476)
        erf_default_1 = torch.ops.aten.erf.default(mul_tensor_20);  mul_tensor_20 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(erf_default_1, 1);  erf_default_1 = None
        mul_tensor_21 = torch.ops.aten.mul.Tensor(add_tensor_31, 0.5);  add_tensor_31 = None
        mul_tensor_22 = torch.ops.aten.mul.Tensor(to_dtype_4, to_dtype_4)
        mul_tensor_23 = torch.ops.aten.mul.Tensor(mul_tensor_22, -0.5);  mul_tensor_22 = None
        exp_default_1 = torch.ops.aten.exp.default(mul_tensor_23);  mul_tensor_23 = None
        mul_tensor_24 = torch.ops.aten.mul.Tensor(exp_default_1, 0.3989422804014327);  exp_default_1 = None
        mul_tensor_25 = torch.ops.aten.mul.Tensor(to_dtype_4, mul_tensor_24);  to_dtype_4 = mul_tensor_24 = None
        add_tensor_32 = torch.ops.aten.add.Tensor(mul_tensor_21, mul_tensor_25);  mul_tensor_21 = mul_tensor_25 = None
        mul_tensor_26 = torch.ops.aten.mul.Tensor(to_dtype_3, add_tensor_32);  to_dtype_3 = add_tensor_32 = None
        to_dtype_5 = torch.ops.aten.to.dtype(mul_tensor_26, torch.float32);  mul_tensor_26 = None
        view_default_143 = torch.ops.aten.view.default(to_dtype_5, [1576, 1536]);  to_dtype_5 = None
        t_default_73 = torch.ops.aten.t.default(t_default_42);  t_default_42 = None
        mm_default_12 = torch.ops.aten.mm.default(view_default_143, t_default_73);  t_default_73 = None
        t_default_74 = torch.ops.aten.t.default(view_default_143)
        mm_default_13 = torch.ops.aten.mm.default(t_default_74, view_default_107);  t_default_74 = view_default_107 = None
        t_default_75 = torch.ops.aten.t.default(mm_default_13);  mm_default_13 = None
        sum_dim_int_list_6 = torch.ops.aten.sum.dim_IntList(view_default_143, [0], True);  view_default_143 = None
        view_default_144 = torch.ops.aten.view.default(sum_dim_int_list_6, [1536]);  sum_dim_int_list_6 = None
        t_default_76 = torch.ops.aten.t.default(t_default_75);  t_default_75 = None
        view_default_145 = torch.ops.aten.view.default(mm_default_12, [8, 197, 384]);  mm_default_12 = None
        native_layer_norm_backward_default_3 = torch.ops.aten.native_layer_norm_backward.default(view_default_145, add_tensor_21, [384], getitem_64, getitem_65, primals_24, primals_23, [True, True, True]);  view_default_145 = add_tensor_21 = getitem_64 = getitem_65 = primals_24 = primals_23 = None
        getitem_84 = native_layer_norm_backward_default_3[0]
        getitem_85 = native_layer_norm_backward_default_3[1]
        getitem_86 = native_layer_norm_backward_default_3[2];  native_layer_norm_backward_default_3 = None
        add_tensor_33 = torch.ops.aten.add.Tensor(add_tensor_30, getitem_84);  add_tensor_30 = getitem_84 = None
        view_default_146 = torch.ops.aten.view.default(add_tensor_33, [1576, 384])
        t_default_77 = torch.ops.aten.t.default(t_default_41);  t_default_41 = None
        mm_default_14 = torch.ops.aten.mm.default(view_default_146, t_default_77);  t_default_77 = None
        t_default_78 = torch.ops.aten.t.default(view_default_146)
        mm_default_15 = torch.ops.aten.mm.default(t_default_78, view_default_105);  t_default_78 = view_default_105 = None
        t_default_79 = torch.ops.aten.t.default(mm_default_15);  mm_default_15 = None
        sum_dim_int_list_7 = torch.ops.aten.sum.dim_IntList(view_default_146, [0], True);  view_default_146 = None
        view_default_147 = torch.ops.aten.view.default(sum_dim_int_list_7, [384]);  sum_dim_int_list_7 = None
        t_default_80 = torch.ops.aten.t.default(t_default_79);  t_default_79 = None
        view_default_148 = torch.ops.aten.view.default(mm_default_14, [8, 197, 384]);  mm_default_14 = None
        view_default_149 = torch.ops.aten.view.default(view_default_148, [8, 197, 6, 64]);  view_default_148 = None
        transpose_int_31 = torch.ops.aten.transpose.int(view_default_149, 1, 2);  view_default_149 = None
        clone_default_50 = torch.ops.aten.clone.default(transpose_int_31, memory_format = torch.contiguous_format);  transpose_int_31 = None
        _unsafe_view_default_74 = torch.ops.aten._unsafe_view.default(clone_default_50, [48, 197, 64]);  clone_default_50 = None
        transpose_int_32 = torch.ops.aten.transpose.int(view_default_104, 1, 2);  view_default_104 = None
        bmm_default_28 = torch.ops.aten.bmm.default(transpose_int_32, _unsafe_view_default_74);  transpose_int_32 = None
        transpose_int_33 = torch.ops.aten.transpose.int(_unsafe_view_default_63, 1, 2);  _unsafe_view_default_63 = None
        bmm_default_29 = torch.ops.aten.bmm.default(_unsafe_view_default_74, transpose_int_33);  _unsafe_view_default_74 = transpose_int_33 = None
        view_default_150 = torch.ops.aten.view.default(bmm_default_28, [8, 6, 197, 64]);  bmm_default_28 = None
        view_default_151 = torch.ops.aten.view.default(bmm_default_29, [8, 6, 197, 197]);  bmm_default_29 = None
        _softmax_backward_data_default_1 = torch.ops.aten._softmax_backward_data.default(view_default_151, _softmax_default_10, -1, torch.float32);  view_default_151 = _softmax_default_10 = None
        mul_tensor_27 = torch.ops.aten.mul.Tensor(_softmax_backward_data_default_1, 0.125);  _softmax_backward_data_default_1 = None
        view_default_152 = torch.ops.aten.view.default(mul_tensor_27, [48, 197, 197]);  mul_tensor_27 = None
        transpose_int_34 = torch.ops.aten.transpose.int(_unsafe_view_default_60, 1, 2);  _unsafe_view_default_60 = None
        bmm_default_30 = torch.ops.aten.bmm.default(transpose_int_34, view_default_152);  transpose_int_34 = None
        transpose_int_35 = torch.ops.aten.transpose.int(_unsafe_view_default_61, 1, 2);  _unsafe_view_default_61 = None
        bmm_default_31 = torch.ops.aten.bmm.default(view_default_152, transpose_int_35);  view_default_152 = transpose_int_35 = None
        view_default_153 = torch.ops.aten.view.default(bmm_default_30, [8, 6, 64, 197]);  bmm_default_30 = None
        view_default_154 = torch.ops.aten.view.default(bmm_default_31, [8, 6, 197, 64]);  bmm_default_31 = None
        transpose_int_36 = torch.ops.aten.transpose.int(view_default_153, -2, -1);  view_default_153 = None
        select_backward_default_4 = torch.ops.aten.select_backward.default(view_default_150, [3, 8, 6, 197, 64], 0, 2);  view_default_150 = None
        select_backward_default_5 = torch.ops.aten.select_backward.default(transpose_int_36, [3, 8, 6, 197, 64], 0, 1);  transpose_int_36 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(select_backward_default_4, select_backward_default_5);  select_backward_default_4 = select_backward_default_5 = None
        select_backward_default_6 = torch.ops.aten.select_backward.default(view_default_154, [3, 8, 6, 197, 64], 0, 0);  view_default_154 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(add_tensor_34, select_backward_default_6);  add_tensor_34 = select_backward_default_6 = None
        permute_default_13 = torch.ops.aten.permute.default(add_tensor_35, [1, 3, 0, 2, 4]);  add_tensor_35 = None
        clone_default_51 = torch.ops.aten.clone.default(permute_default_13, memory_format = torch.contiguous_format);  permute_default_13 = None
        _unsafe_view_default_75 = torch.ops.aten._unsafe_view.default(clone_default_51, [8, 197, 1152]);  clone_default_51 = None
        view_default_155 = torch.ops.aten.view.default(_unsafe_view_default_75, [1576, 1152]);  _unsafe_view_default_75 = None
        t_default_81 = torch.ops.aten.t.default(t_default_40);  t_default_40 = None
        mm_default_16 = torch.ops.aten.mm.default(view_default_155, t_default_81);  t_default_81 = None
        t_default_82 = torch.ops.aten.t.default(view_default_155)
        mm_default_17 = torch.ops.aten.mm.default(t_default_82, view_default_101);  t_default_82 = view_default_101 = None
        t_default_83 = torch.ops.aten.t.default(mm_default_17);  mm_default_17 = None
        sum_dim_int_list_8 = torch.ops.aten.sum.dim_IntList(view_default_155, [0], True);  view_default_155 = None
        view_default_156 = torch.ops.aten.view.default(sum_dim_int_list_8, [1152]);  sum_dim_int_list_8 = None
        t_default_84 = torch.ops.aten.t.default(t_default_83);  t_default_83 = None
        view_default_157 = torch.ops.aten.view.default(mm_default_16, [8, 197, 384]);  mm_default_16 = None
        native_layer_norm_backward_default_4 = torch.ops.aten.native_layer_norm_backward.default(view_default_157, add_tensor_20, [384], getitem_61, getitem_62, primals_22, primals_21, [True, True, True]);  view_default_157 = add_tensor_20 = getitem_61 = getitem_62 = primals_22 = primals_21 = None
        getitem_87 = native_layer_norm_backward_default_4[0]
        getitem_88 = native_layer_norm_backward_default_4[1]
        getitem_89 = native_layer_norm_backward_default_4[2];  native_layer_norm_backward_default_4 = None
        add_tensor_36 = torch.ops.aten.add.Tensor(add_tensor_33, getitem_87);  add_tensor_33 = getitem_87 = None
        view_default_158 = torch.ops.aten.view.default(add_tensor_36, [1576, 384])
        t_default_85 = torch.ops.aten.t.default(t_default_39);  t_default_39 = None
        mm_default_18 = torch.ops.aten.mm.default(view_default_158, t_default_85);  t_default_85 = None
        t_default_86 = torch.ops.aten.t.default(view_default_158)
        mm_default_19 = torch.ops.aten.mm.default(t_default_86, view_default_99);  t_default_86 = view_default_99 = None
        t_default_87 = torch.ops.aten.t.default(mm_default_19);  mm_default_19 = None
        sum_dim_int_list_9 = torch.ops.aten.sum.dim_IntList(view_default_158, [0], True);  view_default_158 = None
        view_default_159 = torch.ops.aten.view.default(sum_dim_int_list_9, [384]);  sum_dim_int_list_9 = None
        t_default_88 = torch.ops.aten.t.default(t_default_87);  t_default_87 = None
        view_default_160 = torch.ops.aten.view.default(mm_default_18, [8, 197, 1536]);  mm_default_18 = None
        to_dtype_6 = torch.ops.aten.to.dtype(view_default_160, torch.float32);  view_default_160 = None
        to_dtype_7 = torch.ops.aten.to.dtype(view_default_98, torch.float32);  view_default_98 = None
        mul_tensor_28 = torch.ops.aten.mul.Tensor(to_dtype_7, 0.7071067811865476)
        erf_default_2 = torch.ops.aten.erf.default(mul_tensor_28);  mul_tensor_28 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(erf_default_2, 1);  erf_default_2 = None
        mul_tensor_29 = torch.ops.aten.mul.Tensor(add_tensor_37, 0.5);  add_tensor_37 = None
        mul_tensor_30 = torch.ops.aten.mul.Tensor(to_dtype_7, to_dtype_7)
        mul_tensor_31 = torch.ops.aten.mul.Tensor(mul_tensor_30, -0.5);  mul_tensor_30 = None
        exp_default_2 = torch.ops.aten.exp.default(mul_tensor_31);  mul_tensor_31 = None
        mul_tensor_32 = torch.ops.aten.mul.Tensor(exp_default_2, 0.3989422804014327);  exp_default_2 = None
        mul_tensor_33 = torch.ops.aten.mul.Tensor(to_dtype_7, mul_tensor_32);  to_dtype_7 = mul_tensor_32 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(mul_tensor_29, mul_tensor_33);  mul_tensor_29 = mul_tensor_33 = None
        mul_tensor_34 = torch.ops.aten.mul.Tensor(to_dtype_6, add_tensor_38);  to_dtype_6 = add_tensor_38 = None
        to_dtype_8 = torch.ops.aten.to.dtype(mul_tensor_34, torch.float32);  mul_tensor_34 = None
        view_default_161 = torch.ops.aten.view.default(to_dtype_8, [1576, 1536]);  to_dtype_8 = None
        t_default_89 = torch.ops.aten.t.default(t_default_38);  t_default_38 = None
        mm_default_20 = torch.ops.aten.mm.default(view_default_161, t_default_89);  t_default_89 = None
        t_default_90 = torch.ops.aten.t.default(view_default_161)
        mm_default_21 = torch.ops.aten.mm.default(t_default_90, view_default_97);  t_default_90 = view_default_97 = None
        t_default_91 = torch.ops.aten.t.default(mm_default_21);  mm_default_21 = None
        sum_dim_int_list_10 = torch.ops.aten.sum.dim_IntList(view_default_161, [0], True);  view_default_161 = None
        view_default_162 = torch.ops.aten.view.default(sum_dim_int_list_10, [1536]);  sum_dim_int_list_10 = None
        t_default_92 = torch.ops.aten.t.default(t_default_91);  t_default_91 = None
        view_default_163 = torch.ops.aten.view.default(mm_default_20, [8, 197, 384]);  mm_default_20 = None
        native_layer_norm_backward_default_5 = torch.ops.aten.native_layer_norm_backward.default(view_default_163, add_tensor_19, [384], getitem_58, getitem_59, primals_144, primals_143, [True, True, True]);  view_default_163 = add_tensor_19 = getitem_58 = getitem_59 = primals_144 = primals_143 = None
        getitem_90 = native_layer_norm_backward_default_5[0]
        getitem_91 = native_layer_norm_backward_default_5[1]
        getitem_92 = native_layer_norm_backward_default_5[2];  native_layer_norm_backward_default_5 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(add_tensor_36, getitem_90);  add_tensor_36 = getitem_90 = None
        view_default_164 = torch.ops.aten.view.default(add_tensor_39, [1576, 384])
        t_default_93 = torch.ops.aten.t.default(t_default_37);  t_default_37 = None
        mm_default_22 = torch.ops.aten.mm.default(view_default_164, t_default_93);  t_default_93 = None
        t_default_94 = torch.ops.aten.t.default(view_default_164)
        mm_default_23 = torch.ops.aten.mm.default(t_default_94, view_default_95);  t_default_94 = view_default_95 = None
        t_default_95 = torch.ops.aten.t.default(mm_default_23);  mm_default_23 = None
        sum_dim_int_list_11 = torch.ops.aten.sum.dim_IntList(view_default_164, [0], True);  view_default_164 = None
        view_default_165 = torch.ops.aten.view.default(sum_dim_int_list_11, [384]);  sum_dim_int_list_11 = None
        t_default_96 = torch.ops.aten.t.default(t_default_95);  t_default_95 = None
        view_default_166 = torch.ops.aten.view.default(mm_default_22, [8, 197, 384]);  mm_default_22 = None
        view_default_167 = torch.ops.aten.view.default(view_default_166, [8, 197, 6, 64]);  view_default_166 = None
        transpose_int_37 = torch.ops.aten.transpose.int(view_default_167, 1, 2);  view_default_167 = None
        clone_default_52 = torch.ops.aten.clone.default(transpose_int_37, memory_format = torch.contiguous_format);  transpose_int_37 = None
        _unsafe_view_default_76 = torch.ops.aten._unsafe_view.default(clone_default_52, [48, 197, 64]);  clone_default_52 = None
        transpose_int_38 = torch.ops.aten.transpose.int(view_default_94, 1, 2);  view_default_94 = None
        bmm_default_32 = torch.ops.aten.bmm.default(transpose_int_38, _unsafe_view_default_76);  transpose_int_38 = None
        transpose_int_39 = torch.ops.aten.transpose.int(_unsafe_view_default_57, 1, 2);  _unsafe_view_default_57 = None
        bmm_default_33 = torch.ops.aten.bmm.default(_unsafe_view_default_76, transpose_int_39);  _unsafe_view_default_76 = transpose_int_39 = None
        view_default_168 = torch.ops.aten.view.default(bmm_default_32, [8, 6, 197, 64]);  bmm_default_32 = None
        view_default_169 = torch.ops.aten.view.default(bmm_default_33, [8, 6, 197, 197]);  bmm_default_33 = None
        _softmax_backward_data_default_2 = torch.ops.aten._softmax_backward_data.default(view_default_169, _softmax_default_9, -1, torch.float32);  view_default_169 = _softmax_default_9 = None
        mul_tensor_35 = torch.ops.aten.mul.Tensor(_softmax_backward_data_default_2, 0.125);  _softmax_backward_data_default_2 = None
        view_default_170 = torch.ops.aten.view.default(mul_tensor_35, [48, 197, 197]);  mul_tensor_35 = None
        transpose_int_40 = torch.ops.aten.transpose.int(_unsafe_view_default_54, 1, 2);  _unsafe_view_default_54 = None
        bmm_default_34 = torch.ops.aten.bmm.default(transpose_int_40, view_default_170);  transpose_int_40 = None
        transpose_int_41 = torch.ops.aten.transpose.int(_unsafe_view_default_55, 1, 2);  _unsafe_view_default_55 = None
        bmm_default_35 = torch.ops.aten.bmm.default(view_default_170, transpose_int_41);  view_default_170 = transpose_int_41 = None
        view_default_171 = torch.ops.aten.view.default(bmm_default_34, [8, 6, 64, 197]);  bmm_default_34 = None
        view_default_172 = torch.ops.aten.view.default(bmm_default_35, [8, 6, 197, 64]);  bmm_default_35 = None
        transpose_int_42 = torch.ops.aten.transpose.int(view_default_171, -2, -1);  view_default_171 = None
        select_backward_default_7 = torch.ops.aten.select_backward.default(view_default_168, [3, 8, 6, 197, 64], 0, 2);  view_default_168 = None
        select_backward_default_8 = torch.ops.aten.select_backward.default(transpose_int_42, [3, 8, 6, 197, 64], 0, 1);  transpose_int_42 = None
        add_tensor_40 = torch.ops.aten.add.Tensor(select_backward_default_7, select_backward_default_8);  select_backward_default_7 = select_backward_default_8 = None
        select_backward_default_9 = torch.ops.aten.select_backward.default(view_default_172, [3, 8, 6, 197, 64], 0, 0);  view_default_172 = None
        add_tensor_41 = torch.ops.aten.add.Tensor(add_tensor_40, select_backward_default_9);  add_tensor_40 = select_backward_default_9 = None
        permute_default_14 = torch.ops.aten.permute.default(add_tensor_41, [1, 3, 0, 2, 4]);  add_tensor_41 = None
        clone_default_53 = torch.ops.aten.clone.default(permute_default_14, memory_format = torch.contiguous_format);  permute_default_14 = None
        _unsafe_view_default_77 = torch.ops.aten._unsafe_view.default(clone_default_53, [8, 197, 1152]);  clone_default_53 = None
        view_default_173 = torch.ops.aten.view.default(_unsafe_view_default_77, [1576, 1152]);  _unsafe_view_default_77 = None
        t_default_97 = torch.ops.aten.t.default(t_default_36);  t_default_36 = None
        mm_default_24 = torch.ops.aten.mm.default(view_default_173, t_default_97);  t_default_97 = None
        t_default_98 = torch.ops.aten.t.default(view_default_173)
        mm_default_25 = torch.ops.aten.mm.default(t_default_98, view_default_91);  t_default_98 = view_default_91 = None
        t_default_99 = torch.ops.aten.t.default(mm_default_25);  mm_default_25 = None
        sum_dim_int_list_12 = torch.ops.aten.sum.dim_IntList(view_default_173, [0], True);  view_default_173 = None
        view_default_174 = torch.ops.aten.view.default(sum_dim_int_list_12, [1152]);  sum_dim_int_list_12 = None
        t_default_100 = torch.ops.aten.t.default(t_default_99);  t_default_99 = None
        view_default_175 = torch.ops.aten.view.default(mm_default_24, [8, 197, 384]);  mm_default_24 = None
        native_layer_norm_backward_default_6 = torch.ops.aten.native_layer_norm_backward.default(view_default_175, add_tensor_18, [384], getitem_55, getitem_56, primals_142, primals_141, [True, True, True]);  view_default_175 = add_tensor_18 = getitem_55 = getitem_56 = primals_142 = primals_141 = None
        getitem_93 = native_layer_norm_backward_default_6[0]
        getitem_94 = native_layer_norm_backward_default_6[1]
        getitem_95 = native_layer_norm_backward_default_6[2];  native_layer_norm_backward_default_6 = None
        add_tensor_42 = torch.ops.aten.add.Tensor(add_tensor_39, getitem_93);  add_tensor_39 = getitem_93 = None
        view_default_176 = torch.ops.aten.view.default(add_tensor_42, [1576, 384])
        t_default_101 = torch.ops.aten.t.default(t_default_35);  t_default_35 = None
        mm_default_26 = torch.ops.aten.mm.default(view_default_176, t_default_101);  t_default_101 = None
        t_default_102 = torch.ops.aten.t.default(view_default_176)
        mm_default_27 = torch.ops.aten.mm.default(t_default_102, view_default_89);  t_default_102 = view_default_89 = None
        t_default_103 = torch.ops.aten.t.default(mm_default_27);  mm_default_27 = None
        sum_dim_int_list_13 = torch.ops.aten.sum.dim_IntList(view_default_176, [0], True);  view_default_176 = None
        view_default_177 = torch.ops.aten.view.default(sum_dim_int_list_13, [384]);  sum_dim_int_list_13 = None
        t_default_104 = torch.ops.aten.t.default(t_default_103);  t_default_103 = None
        view_default_178 = torch.ops.aten.view.default(mm_default_26, [8, 197, 1536]);  mm_default_26 = None
        to_dtype_9 = torch.ops.aten.to.dtype(view_default_178, torch.float32);  view_default_178 = None
        to_dtype_10 = torch.ops.aten.to.dtype(view_default_88, torch.float32);  view_default_88 = None
        mul_tensor_36 = torch.ops.aten.mul.Tensor(to_dtype_10, 0.7071067811865476)
        erf_default_3 = torch.ops.aten.erf.default(mul_tensor_36);  mul_tensor_36 = None
        add_tensor_43 = torch.ops.aten.add.Tensor(erf_default_3, 1);  erf_default_3 = None
        mul_tensor_37 = torch.ops.aten.mul.Tensor(add_tensor_43, 0.5);  add_tensor_43 = None
        mul_tensor_38 = torch.ops.aten.mul.Tensor(to_dtype_10, to_dtype_10)
        mul_tensor_39 = torch.ops.aten.mul.Tensor(mul_tensor_38, -0.5);  mul_tensor_38 = None
        exp_default_3 = torch.ops.aten.exp.default(mul_tensor_39);  mul_tensor_39 = None
        mul_tensor_40 = torch.ops.aten.mul.Tensor(exp_default_3, 0.3989422804014327);  exp_default_3 = None
        mul_tensor_41 = torch.ops.aten.mul.Tensor(to_dtype_10, mul_tensor_40);  to_dtype_10 = mul_tensor_40 = None
        add_tensor_44 = torch.ops.aten.add.Tensor(mul_tensor_37, mul_tensor_41);  mul_tensor_37 = mul_tensor_41 = None
        mul_tensor_42 = torch.ops.aten.mul.Tensor(to_dtype_9, add_tensor_44);  to_dtype_9 = add_tensor_44 = None
        to_dtype_11 = torch.ops.aten.to.dtype(mul_tensor_42, torch.float32);  mul_tensor_42 = None
        view_default_179 = torch.ops.aten.view.default(to_dtype_11, [1576, 1536]);  to_dtype_11 = None
        t_default_105 = torch.ops.aten.t.default(t_default_34);  t_default_34 = None
        mm_default_28 = torch.ops.aten.mm.default(view_default_179, t_default_105);  t_default_105 = None
        t_default_106 = torch.ops.aten.t.default(view_default_179)
        mm_default_29 = torch.ops.aten.mm.default(t_default_106, view_default_87);  t_default_106 = view_default_87 = None
        t_default_107 = torch.ops.aten.t.default(mm_default_29);  mm_default_29 = None
        sum_dim_int_list_14 = torch.ops.aten.sum.dim_IntList(view_default_179, [0], True);  view_default_179 = None
        view_default_180 = torch.ops.aten.view.default(sum_dim_int_list_14, [1536]);  sum_dim_int_list_14 = None
        t_default_108 = torch.ops.aten.t.default(t_default_107);  t_default_107 = None
        view_default_181 = torch.ops.aten.view.default(mm_default_28, [8, 197, 384]);  mm_default_28 = None
        native_layer_norm_backward_default_7 = torch.ops.aten.native_layer_norm_backward.default(view_default_181, add_tensor_17, [384], getitem_52, getitem_53, primals_132, primals_131, [True, True, True]);  view_default_181 = add_tensor_17 = getitem_52 = getitem_53 = primals_132 = primals_131 = None
        getitem_96 = native_layer_norm_backward_default_7[0]
        getitem_97 = native_layer_norm_backward_default_7[1]
        getitem_98 = native_layer_norm_backward_default_7[2];  native_layer_norm_backward_default_7 = None
        add_tensor_45 = torch.ops.aten.add.Tensor(add_tensor_42, getitem_96);  add_tensor_42 = getitem_96 = None
        view_default_182 = torch.ops.aten.view.default(add_tensor_45, [1576, 384])
        t_default_109 = torch.ops.aten.t.default(t_default_33);  t_default_33 = None
        mm_default_30 = torch.ops.aten.mm.default(view_default_182, t_default_109);  t_default_109 = None
        t_default_110 = torch.ops.aten.t.default(view_default_182)
        mm_default_31 = torch.ops.aten.mm.default(t_default_110, view_default_85);  t_default_110 = view_default_85 = None
        t_default_111 = torch.ops.aten.t.default(mm_default_31);  mm_default_31 = None
        sum_dim_int_list_15 = torch.ops.aten.sum.dim_IntList(view_default_182, [0], True);  view_default_182 = None
        view_default_183 = torch.ops.aten.view.default(sum_dim_int_list_15, [384]);  sum_dim_int_list_15 = None
        t_default_112 = torch.ops.aten.t.default(t_default_111);  t_default_111 = None
        view_default_184 = torch.ops.aten.view.default(mm_default_30, [8, 197, 384]);  mm_default_30 = None
        view_default_185 = torch.ops.aten.view.default(view_default_184, [8, 197, 6, 64]);  view_default_184 = None
        transpose_int_43 = torch.ops.aten.transpose.int(view_default_185, 1, 2);  view_default_185 = None
        clone_default_54 = torch.ops.aten.clone.default(transpose_int_43, memory_format = torch.contiguous_format);  transpose_int_43 = None
        _unsafe_view_default_78 = torch.ops.aten._unsafe_view.default(clone_default_54, [48, 197, 64]);  clone_default_54 = None
        transpose_int_44 = torch.ops.aten.transpose.int(view_default_84, 1, 2);  view_default_84 = None
        bmm_default_36 = torch.ops.aten.bmm.default(transpose_int_44, _unsafe_view_default_78);  transpose_int_44 = None
        transpose_int_45 = torch.ops.aten.transpose.int(_unsafe_view_default_51, 1, 2);  _unsafe_view_default_51 = None
        bmm_default_37 = torch.ops.aten.bmm.default(_unsafe_view_default_78, transpose_int_45);  _unsafe_view_default_78 = transpose_int_45 = None
        view_default_186 = torch.ops.aten.view.default(bmm_default_36, [8, 6, 197, 64]);  bmm_default_36 = None
        view_default_187 = torch.ops.aten.view.default(bmm_default_37, [8, 6, 197, 197]);  bmm_default_37 = None
        _softmax_backward_data_default_3 = torch.ops.aten._softmax_backward_data.default(view_default_187, _softmax_default_8, -1, torch.float32);  view_default_187 = _softmax_default_8 = None
        mul_tensor_43 = torch.ops.aten.mul.Tensor(_softmax_backward_data_default_3, 0.125);  _softmax_backward_data_default_3 = None
        view_default_188 = torch.ops.aten.view.default(mul_tensor_43, [48, 197, 197]);  mul_tensor_43 = None
        transpose_int_46 = torch.ops.aten.transpose.int(_unsafe_view_default_48, 1, 2);  _unsafe_view_default_48 = None
        bmm_default_38 = torch.ops.aten.bmm.default(transpose_int_46, view_default_188);  transpose_int_46 = None
        transpose_int_47 = torch.ops.aten.transpose.int(_unsafe_view_default_49, 1, 2);  _unsafe_view_default_49 = None
        bmm_default_39 = torch.ops.aten.bmm.default(view_default_188, transpose_int_47);  view_default_188 = transpose_int_47 = None
        view_default_189 = torch.ops.aten.view.default(bmm_default_38, [8, 6, 64, 197]);  bmm_default_38 = None
        view_default_190 = torch.ops.aten.view.default(bmm_default_39, [8, 6, 197, 64]);  bmm_default_39 = None
        transpose_int_48 = torch.ops.aten.transpose.int(view_default_189, -2, -1);  view_default_189 = None
        select_backward_default_10 = torch.ops.aten.select_backward.default(view_default_186, [3, 8, 6, 197, 64], 0, 2);  view_default_186 = None
        select_backward_default_11 = torch.ops.aten.select_backward.default(transpose_int_48, [3, 8, 6, 197, 64], 0, 1);  transpose_int_48 = None
        add_tensor_46 = torch.ops.aten.add.Tensor(select_backward_default_10, select_backward_default_11);  select_backward_default_10 = select_backward_default_11 = None
        select_backward_default_12 = torch.ops.aten.select_backward.default(view_default_190, [3, 8, 6, 197, 64], 0, 0);  view_default_190 = None
        add_tensor_47 = torch.ops.aten.add.Tensor(add_tensor_46, select_backward_default_12);  add_tensor_46 = select_backward_default_12 = None
        permute_default_15 = torch.ops.aten.permute.default(add_tensor_47, [1, 3, 0, 2, 4]);  add_tensor_47 = None
        clone_default_55 = torch.ops.aten.clone.default(permute_default_15, memory_format = torch.contiguous_format);  permute_default_15 = None
        _unsafe_view_default_79 = torch.ops.aten._unsafe_view.default(clone_default_55, [8, 197, 1152]);  clone_default_55 = None
        view_default_191 = torch.ops.aten.view.default(_unsafe_view_default_79, [1576, 1152]);  _unsafe_view_default_79 = None
        t_default_113 = torch.ops.aten.t.default(t_default_32);  t_default_32 = None
        mm_default_32 = torch.ops.aten.mm.default(view_default_191, t_default_113);  t_default_113 = None
        t_default_114 = torch.ops.aten.t.default(view_default_191)
        mm_default_33 = torch.ops.aten.mm.default(t_default_114, view_default_81);  t_default_114 = view_default_81 = None
        t_default_115 = torch.ops.aten.t.default(mm_default_33);  mm_default_33 = None
        sum_dim_int_list_16 = torch.ops.aten.sum.dim_IntList(view_default_191, [0], True);  view_default_191 = None
        view_default_192 = torch.ops.aten.view.default(sum_dim_int_list_16, [1152]);  sum_dim_int_list_16 = None
        t_default_116 = torch.ops.aten.t.default(t_default_115);  t_default_115 = None
        view_default_193 = torch.ops.aten.view.default(mm_default_32, [8, 197, 384]);  mm_default_32 = None
        native_layer_norm_backward_default_8 = torch.ops.aten.native_layer_norm_backward.default(view_default_193, add_tensor_16, [384], getitem_49, getitem_50, primals_130, primals_129, [True, True, True]);  view_default_193 = add_tensor_16 = getitem_49 = getitem_50 = primals_130 = primals_129 = None
        getitem_99 = native_layer_norm_backward_default_8[0]
        getitem_100 = native_layer_norm_backward_default_8[1]
        getitem_101 = native_layer_norm_backward_default_8[2];  native_layer_norm_backward_default_8 = None
        add_tensor_48 = torch.ops.aten.add.Tensor(add_tensor_45, getitem_99);  add_tensor_45 = getitem_99 = None
        view_default_194 = torch.ops.aten.view.default(add_tensor_48, [1576, 384])
        t_default_117 = torch.ops.aten.t.default(t_default_31);  t_default_31 = None
        mm_default_34 = torch.ops.aten.mm.default(view_default_194, t_default_117);  t_default_117 = None
        t_default_118 = torch.ops.aten.t.default(view_default_194)
        mm_default_35 = torch.ops.aten.mm.default(t_default_118, view_default_79);  t_default_118 = view_default_79 = None
        t_default_119 = torch.ops.aten.t.default(mm_default_35);  mm_default_35 = None
        sum_dim_int_list_17 = torch.ops.aten.sum.dim_IntList(view_default_194, [0], True);  view_default_194 = None
        view_default_195 = torch.ops.aten.view.default(sum_dim_int_list_17, [384]);  sum_dim_int_list_17 = None
        t_default_120 = torch.ops.aten.t.default(t_default_119);  t_default_119 = None
        view_default_196 = torch.ops.aten.view.default(mm_default_34, [8, 197, 1536]);  mm_default_34 = None
        to_dtype_12 = torch.ops.aten.to.dtype(view_default_196, torch.float32);  view_default_196 = None
        to_dtype_13 = torch.ops.aten.to.dtype(view_default_78, torch.float32);  view_default_78 = None
        mul_tensor_44 = torch.ops.aten.mul.Tensor(to_dtype_13, 0.7071067811865476)
        erf_default_4 = torch.ops.aten.erf.default(mul_tensor_44);  mul_tensor_44 = None
        add_tensor_49 = torch.ops.aten.add.Tensor(erf_default_4, 1);  erf_default_4 = None
        mul_tensor_45 = torch.ops.aten.mul.Tensor(add_tensor_49, 0.5);  add_tensor_49 = None
        mul_tensor_46 = torch.ops.aten.mul.Tensor(to_dtype_13, to_dtype_13)
        mul_tensor_47 = torch.ops.aten.mul.Tensor(mul_tensor_46, -0.5);  mul_tensor_46 = None
        exp_default_4 = torch.ops.aten.exp.default(mul_tensor_47);  mul_tensor_47 = None
        mul_tensor_48 = torch.ops.aten.mul.Tensor(exp_default_4, 0.3989422804014327);  exp_default_4 = None
        mul_tensor_49 = torch.ops.aten.mul.Tensor(to_dtype_13, mul_tensor_48);  to_dtype_13 = mul_tensor_48 = None
        add_tensor_50 = torch.ops.aten.add.Tensor(mul_tensor_45, mul_tensor_49);  mul_tensor_45 = mul_tensor_49 = None
        mul_tensor_50 = torch.ops.aten.mul.Tensor(to_dtype_12, add_tensor_50);  to_dtype_12 = add_tensor_50 = None
        to_dtype_14 = torch.ops.aten.to.dtype(mul_tensor_50, torch.float32);  mul_tensor_50 = None
        view_default_197 = torch.ops.aten.view.default(to_dtype_14, [1576, 1536]);  to_dtype_14 = None
        t_default_121 = torch.ops.aten.t.default(t_default_30);  t_default_30 = None
        mm_default_36 = torch.ops.aten.mm.default(view_default_197, t_default_121);  t_default_121 = None
        t_default_122 = torch.ops.aten.t.default(view_default_197)
        mm_default_37 = torch.ops.aten.mm.default(t_default_122, view_default_77);  t_default_122 = view_default_77 = None
        t_default_123 = torch.ops.aten.t.default(mm_default_37);  mm_default_37 = None
        sum_dim_int_list_18 = torch.ops.aten.sum.dim_IntList(view_default_197, [0], True);  view_default_197 = None
        view_default_198 = torch.ops.aten.view.default(sum_dim_int_list_18, [1536]);  sum_dim_int_list_18 = None
        t_default_124 = torch.ops.aten.t.default(t_default_123);  t_default_123 = None
        view_default_199 = torch.ops.aten.view.default(mm_default_36, [8, 197, 384]);  mm_default_36 = None
        native_layer_norm_backward_default_9 = torch.ops.aten.native_layer_norm_backward.default(view_default_199, add_tensor_15, [384], getitem_46, getitem_47, primals_120, primals_119, [True, True, True]);  view_default_199 = add_tensor_15 = getitem_46 = getitem_47 = primals_120 = primals_119 = None
        getitem_102 = native_layer_norm_backward_default_9[0]
        getitem_103 = native_layer_norm_backward_default_9[1]
        getitem_104 = native_layer_norm_backward_default_9[2];  native_layer_norm_backward_default_9 = None
        add_tensor_51 = torch.ops.aten.add.Tensor(add_tensor_48, getitem_102);  add_tensor_48 = getitem_102 = None
        view_default_200 = torch.ops.aten.view.default(add_tensor_51, [1576, 384])
        t_default_125 = torch.ops.aten.t.default(t_default_29);  t_default_29 = None
        mm_default_38 = torch.ops.aten.mm.default(view_default_200, t_default_125);  t_default_125 = None
        t_default_126 = torch.ops.aten.t.default(view_default_200)
        mm_default_39 = torch.ops.aten.mm.default(t_default_126, view_default_75);  t_default_126 = view_default_75 = None
        t_default_127 = torch.ops.aten.t.default(mm_default_39);  mm_default_39 = None
        sum_dim_int_list_19 = torch.ops.aten.sum.dim_IntList(view_default_200, [0], True);  view_default_200 = None
        view_default_201 = torch.ops.aten.view.default(sum_dim_int_list_19, [384]);  sum_dim_int_list_19 = None
        t_default_128 = torch.ops.aten.t.default(t_default_127);  t_default_127 = None
        view_default_202 = torch.ops.aten.view.default(mm_default_38, [8, 197, 384]);  mm_default_38 = None
        view_default_203 = torch.ops.aten.view.default(view_default_202, [8, 197, 6, 64]);  view_default_202 = None
        transpose_int_49 = torch.ops.aten.transpose.int(view_default_203, 1, 2);  view_default_203 = None
        clone_default_56 = torch.ops.aten.clone.default(transpose_int_49, memory_format = torch.contiguous_format);  transpose_int_49 = None
        _unsafe_view_default_80 = torch.ops.aten._unsafe_view.default(clone_default_56, [48, 197, 64]);  clone_default_56 = None
        transpose_int_50 = torch.ops.aten.transpose.int(view_default_74, 1, 2);  view_default_74 = None
        bmm_default_40 = torch.ops.aten.bmm.default(transpose_int_50, _unsafe_view_default_80);  transpose_int_50 = None
        transpose_int_51 = torch.ops.aten.transpose.int(_unsafe_view_default_45, 1, 2);  _unsafe_view_default_45 = None
        bmm_default_41 = torch.ops.aten.bmm.default(_unsafe_view_default_80, transpose_int_51);  _unsafe_view_default_80 = transpose_int_51 = None
        view_default_204 = torch.ops.aten.view.default(bmm_default_40, [8, 6, 197, 64]);  bmm_default_40 = None
        view_default_205 = torch.ops.aten.view.default(bmm_default_41, [8, 6, 197, 197]);  bmm_default_41 = None
        _softmax_backward_data_default_4 = torch.ops.aten._softmax_backward_data.default(view_default_205, _softmax_default_7, -1, torch.float32);  view_default_205 = _softmax_default_7 = None
        mul_tensor_51 = torch.ops.aten.mul.Tensor(_softmax_backward_data_default_4, 0.125);  _softmax_backward_data_default_4 = None
        view_default_206 = torch.ops.aten.view.default(mul_tensor_51, [48, 197, 197]);  mul_tensor_51 = None
        transpose_int_52 = torch.ops.aten.transpose.int(_unsafe_view_default_42, 1, 2);  _unsafe_view_default_42 = None
        bmm_default_42 = torch.ops.aten.bmm.default(transpose_int_52, view_default_206);  transpose_int_52 = None
        transpose_int_53 = torch.ops.aten.transpose.int(_unsafe_view_default_43, 1, 2);  _unsafe_view_default_43 = None
        bmm_default_43 = torch.ops.aten.bmm.default(view_default_206, transpose_int_53);  view_default_206 = transpose_int_53 = None
        view_default_207 = torch.ops.aten.view.default(bmm_default_42, [8, 6, 64, 197]);  bmm_default_42 = None
        view_default_208 = torch.ops.aten.view.default(bmm_default_43, [8, 6, 197, 64]);  bmm_default_43 = None
        transpose_int_54 = torch.ops.aten.transpose.int(view_default_207, -2, -1);  view_default_207 = None
        select_backward_default_13 = torch.ops.aten.select_backward.default(view_default_204, [3, 8, 6, 197, 64], 0, 2);  view_default_204 = None
        select_backward_default_14 = torch.ops.aten.select_backward.default(transpose_int_54, [3, 8, 6, 197, 64], 0, 1);  transpose_int_54 = None
        add_tensor_52 = torch.ops.aten.add.Tensor(select_backward_default_13, select_backward_default_14);  select_backward_default_13 = select_backward_default_14 = None
        select_backward_default_15 = torch.ops.aten.select_backward.default(view_default_208, [3, 8, 6, 197, 64], 0, 0);  view_default_208 = None
        add_tensor_53 = torch.ops.aten.add.Tensor(add_tensor_52, select_backward_default_15);  add_tensor_52 = select_backward_default_15 = None
        permute_default_16 = torch.ops.aten.permute.default(add_tensor_53, [1, 3, 0, 2, 4]);  add_tensor_53 = None
        clone_default_57 = torch.ops.aten.clone.default(permute_default_16, memory_format = torch.contiguous_format);  permute_default_16 = None
        _unsafe_view_default_81 = torch.ops.aten._unsafe_view.default(clone_default_57, [8, 197, 1152]);  clone_default_57 = None
        view_default_209 = torch.ops.aten.view.default(_unsafe_view_default_81, [1576, 1152]);  _unsafe_view_default_81 = None
        t_default_129 = torch.ops.aten.t.default(t_default_28);  t_default_28 = None
        mm_default_40 = torch.ops.aten.mm.default(view_default_209, t_default_129);  t_default_129 = None
        t_default_130 = torch.ops.aten.t.default(view_default_209)
        mm_default_41 = torch.ops.aten.mm.default(t_default_130, view_default_71);  t_default_130 = view_default_71 = None
        t_default_131 = torch.ops.aten.t.default(mm_default_41);  mm_default_41 = None
        sum_dim_int_list_20 = torch.ops.aten.sum.dim_IntList(view_default_209, [0], True);  view_default_209 = None
        view_default_210 = torch.ops.aten.view.default(sum_dim_int_list_20, [1152]);  sum_dim_int_list_20 = None
        t_default_132 = torch.ops.aten.t.default(t_default_131);  t_default_131 = None
        view_default_211 = torch.ops.aten.view.default(mm_default_40, [8, 197, 384]);  mm_default_40 = None
        native_layer_norm_backward_default_10 = torch.ops.aten.native_layer_norm_backward.default(view_default_211, add_tensor_14, [384], getitem_43, getitem_44, primals_118, primals_117, [True, True, True]);  view_default_211 = add_tensor_14 = getitem_43 = getitem_44 = primals_118 = primals_117 = None
        getitem_105 = native_layer_norm_backward_default_10[0]
        getitem_106 = native_layer_norm_backward_default_10[1]
        getitem_107 = native_layer_norm_backward_default_10[2];  native_layer_norm_backward_default_10 = None
        add_tensor_54 = torch.ops.aten.add.Tensor(add_tensor_51, getitem_105);  add_tensor_51 = getitem_105 = None
        view_default_212 = torch.ops.aten.view.default(add_tensor_54, [1576, 384])
        t_default_133 = torch.ops.aten.t.default(t_default_27);  t_default_27 = None
        mm_default_42 = torch.ops.aten.mm.default(view_default_212, t_default_133);  t_default_133 = None
        t_default_134 = torch.ops.aten.t.default(view_default_212)
        mm_default_43 = torch.ops.aten.mm.default(t_default_134, view_default_69);  t_default_134 = view_default_69 = None
        t_default_135 = torch.ops.aten.t.default(mm_default_43);  mm_default_43 = None
        sum_dim_int_list_21 = torch.ops.aten.sum.dim_IntList(view_default_212, [0], True);  view_default_212 = None
        view_default_213 = torch.ops.aten.view.default(sum_dim_int_list_21, [384]);  sum_dim_int_list_21 = None
        t_default_136 = torch.ops.aten.t.default(t_default_135);  t_default_135 = None
        view_default_214 = torch.ops.aten.view.default(mm_default_42, [8, 197, 1536]);  mm_default_42 = None
        to_dtype_15 = torch.ops.aten.to.dtype(view_default_214, torch.float32);  view_default_214 = None
        to_dtype_16 = torch.ops.aten.to.dtype(view_default_68, torch.float32);  view_default_68 = None
        mul_tensor_52 = torch.ops.aten.mul.Tensor(to_dtype_16, 0.7071067811865476)
        erf_default_5 = torch.ops.aten.erf.default(mul_tensor_52);  mul_tensor_52 = None
        add_tensor_55 = torch.ops.aten.add.Tensor(erf_default_5, 1);  erf_default_5 = None
        mul_tensor_53 = torch.ops.aten.mul.Tensor(add_tensor_55, 0.5);  add_tensor_55 = None
        mul_tensor_54 = torch.ops.aten.mul.Tensor(to_dtype_16, to_dtype_16)
        mul_tensor_55 = torch.ops.aten.mul.Tensor(mul_tensor_54, -0.5);  mul_tensor_54 = None
        exp_default_5 = torch.ops.aten.exp.default(mul_tensor_55);  mul_tensor_55 = None
        mul_tensor_56 = torch.ops.aten.mul.Tensor(exp_default_5, 0.3989422804014327);  exp_default_5 = None
        mul_tensor_57 = torch.ops.aten.mul.Tensor(to_dtype_16, mul_tensor_56);  to_dtype_16 = mul_tensor_56 = None
        add_tensor_56 = torch.ops.aten.add.Tensor(mul_tensor_53, mul_tensor_57);  mul_tensor_53 = mul_tensor_57 = None
        mul_tensor_58 = torch.ops.aten.mul.Tensor(to_dtype_15, add_tensor_56);  to_dtype_15 = add_tensor_56 = None
        to_dtype_17 = torch.ops.aten.to.dtype(mul_tensor_58, torch.float32);  mul_tensor_58 = None
        view_default_215 = torch.ops.aten.view.default(to_dtype_17, [1576, 1536]);  to_dtype_17 = None
        t_default_137 = torch.ops.aten.t.default(t_default_26);  t_default_26 = None
        mm_default_44 = torch.ops.aten.mm.default(view_default_215, t_default_137);  t_default_137 = None
        t_default_138 = torch.ops.aten.t.default(view_default_215)
        mm_default_45 = torch.ops.aten.mm.default(t_default_138, view_default_67);  t_default_138 = view_default_67 = None
        t_default_139 = torch.ops.aten.t.default(mm_default_45);  mm_default_45 = None
        sum_dim_int_list_22 = torch.ops.aten.sum.dim_IntList(view_default_215, [0], True);  view_default_215 = None
        view_default_216 = torch.ops.aten.view.default(sum_dim_int_list_22, [1536]);  sum_dim_int_list_22 = None
        t_default_140 = torch.ops.aten.t.default(t_default_139);  t_default_139 = None
        view_default_217 = torch.ops.aten.view.default(mm_default_44, [8, 197, 384]);  mm_default_44 = None
        native_layer_norm_backward_default_11 = torch.ops.aten.native_layer_norm_backward.default(view_default_217, add_tensor_13, [384], getitem_40, getitem_41, primals_108, primals_107, [True, True, True]);  view_default_217 = add_tensor_13 = getitem_40 = getitem_41 = primals_108 = primals_107 = None
        getitem_108 = native_layer_norm_backward_default_11[0]
        getitem_109 = native_layer_norm_backward_default_11[1]
        getitem_110 = native_layer_norm_backward_default_11[2];  native_layer_norm_backward_default_11 = None
        add_tensor_57 = torch.ops.aten.add.Tensor(add_tensor_54, getitem_108);  add_tensor_54 = getitem_108 = None
        view_default_218 = torch.ops.aten.view.default(add_tensor_57, [1576, 384])
        t_default_141 = torch.ops.aten.t.default(t_default_25);  t_default_25 = None
        mm_default_46 = torch.ops.aten.mm.default(view_default_218, t_default_141);  t_default_141 = None
        t_default_142 = torch.ops.aten.t.default(view_default_218)
        mm_default_47 = torch.ops.aten.mm.default(t_default_142, view_default_65);  t_default_142 = view_default_65 = None
        t_default_143 = torch.ops.aten.t.default(mm_default_47);  mm_default_47 = None
        sum_dim_int_list_23 = torch.ops.aten.sum.dim_IntList(view_default_218, [0], True);  view_default_218 = None
        view_default_219 = torch.ops.aten.view.default(sum_dim_int_list_23, [384]);  sum_dim_int_list_23 = None
        t_default_144 = torch.ops.aten.t.default(t_default_143);  t_default_143 = None
        view_default_220 = torch.ops.aten.view.default(mm_default_46, [8, 197, 384]);  mm_default_46 = None
        view_default_221 = torch.ops.aten.view.default(view_default_220, [8, 197, 6, 64]);  view_default_220 = None
        transpose_int_55 = torch.ops.aten.transpose.int(view_default_221, 1, 2);  view_default_221 = None
        clone_default_58 = torch.ops.aten.clone.default(transpose_int_55, memory_format = torch.contiguous_format);  transpose_int_55 = None
        _unsafe_view_default_82 = torch.ops.aten._unsafe_view.default(clone_default_58, [48, 197, 64]);  clone_default_58 = None
        transpose_int_56 = torch.ops.aten.transpose.int(view_default_64, 1, 2);  view_default_64 = None
        bmm_default_44 = torch.ops.aten.bmm.default(transpose_int_56, _unsafe_view_default_82);  transpose_int_56 = None
        transpose_int_57 = torch.ops.aten.transpose.int(_unsafe_view_default_39, 1, 2);  _unsafe_view_default_39 = None
        bmm_default_45 = torch.ops.aten.bmm.default(_unsafe_view_default_82, transpose_int_57);  _unsafe_view_default_82 = transpose_int_57 = None
        view_default_222 = torch.ops.aten.view.default(bmm_default_44, [8, 6, 197, 64]);  bmm_default_44 = None
        view_default_223 = torch.ops.aten.view.default(bmm_default_45, [8, 6, 197, 197]);  bmm_default_45 = None
        _softmax_backward_data_default_5 = torch.ops.aten._softmax_backward_data.default(view_default_223, _softmax_default_6, -1, torch.float32);  view_default_223 = _softmax_default_6 = None
        mul_tensor_59 = torch.ops.aten.mul.Tensor(_softmax_backward_data_default_5, 0.125);  _softmax_backward_data_default_5 = None
        view_default_224 = torch.ops.aten.view.default(mul_tensor_59, [48, 197, 197]);  mul_tensor_59 = None
        transpose_int_58 = torch.ops.aten.transpose.int(_unsafe_view_default_36, 1, 2);  _unsafe_view_default_36 = None
        bmm_default_46 = torch.ops.aten.bmm.default(transpose_int_58, view_default_224);  transpose_int_58 = None
        transpose_int_59 = torch.ops.aten.transpose.int(_unsafe_view_default_37, 1, 2);  _unsafe_view_default_37 = None
        bmm_default_47 = torch.ops.aten.bmm.default(view_default_224, transpose_int_59);  view_default_224 = transpose_int_59 = None
        view_default_225 = torch.ops.aten.view.default(bmm_default_46, [8, 6, 64, 197]);  bmm_default_46 = None
        view_default_226 = torch.ops.aten.view.default(bmm_default_47, [8, 6, 197, 64]);  bmm_default_47 = None
        transpose_int_60 = torch.ops.aten.transpose.int(view_default_225, -2, -1);  view_default_225 = None
        select_backward_default_16 = torch.ops.aten.select_backward.default(view_default_222, [3, 8, 6, 197, 64], 0, 2);  view_default_222 = None
        select_backward_default_17 = torch.ops.aten.select_backward.default(transpose_int_60, [3, 8, 6, 197, 64], 0, 1);  transpose_int_60 = None
        add_tensor_58 = torch.ops.aten.add.Tensor(select_backward_default_16, select_backward_default_17);  select_backward_default_16 = select_backward_default_17 = None
        select_backward_default_18 = torch.ops.aten.select_backward.default(view_default_226, [3, 8, 6, 197, 64], 0, 0);  view_default_226 = None
        add_tensor_59 = torch.ops.aten.add.Tensor(add_tensor_58, select_backward_default_18);  add_tensor_58 = select_backward_default_18 = None
        permute_default_17 = torch.ops.aten.permute.default(add_tensor_59, [1, 3, 0, 2, 4]);  add_tensor_59 = None
        clone_default_59 = torch.ops.aten.clone.default(permute_default_17, memory_format = torch.contiguous_format);  permute_default_17 = None
        _unsafe_view_default_83 = torch.ops.aten._unsafe_view.default(clone_default_59, [8, 197, 1152]);  clone_default_59 = None
        view_default_227 = torch.ops.aten.view.default(_unsafe_view_default_83, [1576, 1152]);  _unsafe_view_default_83 = None
        t_default_145 = torch.ops.aten.t.default(t_default_24);  t_default_24 = None
        mm_default_48 = torch.ops.aten.mm.default(view_default_227, t_default_145);  t_default_145 = None
        t_default_146 = torch.ops.aten.t.default(view_default_227)
        mm_default_49 = torch.ops.aten.mm.default(t_default_146, view_default_61);  t_default_146 = view_default_61 = None
        t_default_147 = torch.ops.aten.t.default(mm_default_49);  mm_default_49 = None
        sum_dim_int_list_24 = torch.ops.aten.sum.dim_IntList(view_default_227, [0], True);  view_default_227 = None
        view_default_228 = torch.ops.aten.view.default(sum_dim_int_list_24, [1152]);  sum_dim_int_list_24 = None
        t_default_148 = torch.ops.aten.t.default(t_default_147);  t_default_147 = None
        view_default_229 = torch.ops.aten.view.default(mm_default_48, [8, 197, 384]);  mm_default_48 = None
        native_layer_norm_backward_default_12 = torch.ops.aten.native_layer_norm_backward.default(view_default_229, add_tensor_12, [384], getitem_37, getitem_38, primals_106, primals_105, [True, True, True]);  view_default_229 = add_tensor_12 = getitem_37 = getitem_38 = primals_106 = primals_105 = None
        getitem_111 = native_layer_norm_backward_default_12[0]
        getitem_112 = native_layer_norm_backward_default_12[1]
        getitem_113 = native_layer_norm_backward_default_12[2];  native_layer_norm_backward_default_12 = None
        add_tensor_60 = torch.ops.aten.add.Tensor(add_tensor_57, getitem_111);  add_tensor_57 = getitem_111 = None
        view_default_230 = torch.ops.aten.view.default(add_tensor_60, [1576, 384])
        t_default_149 = torch.ops.aten.t.default(t_default_23);  t_default_23 = None
        mm_default_50 = torch.ops.aten.mm.default(view_default_230, t_default_149);  t_default_149 = None
        t_default_150 = torch.ops.aten.t.default(view_default_230)
        mm_default_51 = torch.ops.aten.mm.default(t_default_150, view_default_59);  t_default_150 = view_default_59 = None
        t_default_151 = torch.ops.aten.t.default(mm_default_51);  mm_default_51 = None
        sum_dim_int_list_25 = torch.ops.aten.sum.dim_IntList(view_default_230, [0], True);  view_default_230 = None
        view_default_231 = torch.ops.aten.view.default(sum_dim_int_list_25, [384]);  sum_dim_int_list_25 = None
        t_default_152 = torch.ops.aten.t.default(t_default_151);  t_default_151 = None
        view_default_232 = torch.ops.aten.view.default(mm_default_50, [8, 197, 1536]);  mm_default_50 = None
        to_dtype_18 = torch.ops.aten.to.dtype(view_default_232, torch.float32);  view_default_232 = None
        to_dtype_19 = torch.ops.aten.to.dtype(view_default_58, torch.float32);  view_default_58 = None
        mul_tensor_60 = torch.ops.aten.mul.Tensor(to_dtype_19, 0.7071067811865476)
        erf_default_6 = torch.ops.aten.erf.default(mul_tensor_60);  mul_tensor_60 = None
        add_tensor_61 = torch.ops.aten.add.Tensor(erf_default_6, 1);  erf_default_6 = None
        mul_tensor_61 = torch.ops.aten.mul.Tensor(add_tensor_61, 0.5);  add_tensor_61 = None
        mul_tensor_62 = torch.ops.aten.mul.Tensor(to_dtype_19, to_dtype_19)
        mul_tensor_63 = torch.ops.aten.mul.Tensor(mul_tensor_62, -0.5);  mul_tensor_62 = None
        exp_default_6 = torch.ops.aten.exp.default(mul_tensor_63);  mul_tensor_63 = None
        mul_tensor_64 = torch.ops.aten.mul.Tensor(exp_default_6, 0.3989422804014327);  exp_default_6 = None
        mul_tensor_65 = torch.ops.aten.mul.Tensor(to_dtype_19, mul_tensor_64);  to_dtype_19 = mul_tensor_64 = None
        add_tensor_62 = torch.ops.aten.add.Tensor(mul_tensor_61, mul_tensor_65);  mul_tensor_61 = mul_tensor_65 = None
        mul_tensor_66 = torch.ops.aten.mul.Tensor(to_dtype_18, add_tensor_62);  to_dtype_18 = add_tensor_62 = None
        to_dtype_20 = torch.ops.aten.to.dtype(mul_tensor_66, torch.float32);  mul_tensor_66 = None
        view_default_233 = torch.ops.aten.view.default(to_dtype_20, [1576, 1536]);  to_dtype_20 = None
        t_default_153 = torch.ops.aten.t.default(t_default_22);  t_default_22 = None
        mm_default_52 = torch.ops.aten.mm.default(view_default_233, t_default_153);  t_default_153 = None
        t_default_154 = torch.ops.aten.t.default(view_default_233)
        mm_default_53 = torch.ops.aten.mm.default(t_default_154, view_default_57);  t_default_154 = view_default_57 = None
        t_default_155 = torch.ops.aten.t.default(mm_default_53);  mm_default_53 = None
        sum_dim_int_list_26 = torch.ops.aten.sum.dim_IntList(view_default_233, [0], True);  view_default_233 = None
        view_default_234 = torch.ops.aten.view.default(sum_dim_int_list_26, [1536]);  sum_dim_int_list_26 = None
        t_default_156 = torch.ops.aten.t.default(t_default_155);  t_default_155 = None
        view_default_235 = torch.ops.aten.view.default(mm_default_52, [8, 197, 384]);  mm_default_52 = None
        native_layer_norm_backward_default_13 = torch.ops.aten.native_layer_norm_backward.default(view_default_235, add_tensor_11, [384], getitem_34, getitem_35, primals_96, primals_95, [True, True, True]);  view_default_235 = add_tensor_11 = getitem_34 = getitem_35 = primals_96 = primals_95 = None
        getitem_114 = native_layer_norm_backward_default_13[0]
        getitem_115 = native_layer_norm_backward_default_13[1]
        getitem_116 = native_layer_norm_backward_default_13[2];  native_layer_norm_backward_default_13 = None
        add_tensor_63 = torch.ops.aten.add.Tensor(add_tensor_60, getitem_114);  add_tensor_60 = getitem_114 = None
        view_default_236 = torch.ops.aten.view.default(add_tensor_63, [1576, 384])
        t_default_157 = torch.ops.aten.t.default(t_default_21);  t_default_21 = None
        mm_default_54 = torch.ops.aten.mm.default(view_default_236, t_default_157);  t_default_157 = None
        t_default_158 = torch.ops.aten.t.default(view_default_236)
        mm_default_55 = torch.ops.aten.mm.default(t_default_158, view_default_55);  t_default_158 = view_default_55 = None
        t_default_159 = torch.ops.aten.t.default(mm_default_55);  mm_default_55 = None
        sum_dim_int_list_27 = torch.ops.aten.sum.dim_IntList(view_default_236, [0], True);  view_default_236 = None
        view_default_237 = torch.ops.aten.view.default(sum_dim_int_list_27, [384]);  sum_dim_int_list_27 = None
        t_default_160 = torch.ops.aten.t.default(t_default_159);  t_default_159 = None
        view_default_238 = torch.ops.aten.view.default(mm_default_54, [8, 197, 384]);  mm_default_54 = None
        view_default_239 = torch.ops.aten.view.default(view_default_238, [8, 197, 6, 64]);  view_default_238 = None
        transpose_int_61 = torch.ops.aten.transpose.int(view_default_239, 1, 2);  view_default_239 = None
        clone_default_60 = torch.ops.aten.clone.default(transpose_int_61, memory_format = torch.contiguous_format);  transpose_int_61 = None
        _unsafe_view_default_84 = torch.ops.aten._unsafe_view.default(clone_default_60, [48, 197, 64]);  clone_default_60 = None
        transpose_int_62 = torch.ops.aten.transpose.int(view_default_54, 1, 2);  view_default_54 = None
        bmm_default_48 = torch.ops.aten.bmm.default(transpose_int_62, _unsafe_view_default_84);  transpose_int_62 = None
        transpose_int_63 = torch.ops.aten.transpose.int(_unsafe_view_default_33, 1, 2);  _unsafe_view_default_33 = None
        bmm_default_49 = torch.ops.aten.bmm.default(_unsafe_view_default_84, transpose_int_63);  _unsafe_view_default_84 = transpose_int_63 = None
        view_default_240 = torch.ops.aten.view.default(bmm_default_48, [8, 6, 197, 64]);  bmm_default_48 = None
        view_default_241 = torch.ops.aten.view.default(bmm_default_49, [8, 6, 197, 197]);  bmm_default_49 = None
        _softmax_backward_data_default_6 = torch.ops.aten._softmax_backward_data.default(view_default_241, _softmax_default_5, -1, torch.float32);  view_default_241 = _softmax_default_5 = None
        mul_tensor_67 = torch.ops.aten.mul.Tensor(_softmax_backward_data_default_6, 0.125);  _softmax_backward_data_default_6 = None
        view_default_242 = torch.ops.aten.view.default(mul_tensor_67, [48, 197, 197]);  mul_tensor_67 = None
        transpose_int_64 = torch.ops.aten.transpose.int(_unsafe_view_default_30, 1, 2);  _unsafe_view_default_30 = None
        bmm_default_50 = torch.ops.aten.bmm.default(transpose_int_64, view_default_242);  transpose_int_64 = None
        transpose_int_65 = torch.ops.aten.transpose.int(_unsafe_view_default_31, 1, 2);  _unsafe_view_default_31 = None
        bmm_default_51 = torch.ops.aten.bmm.default(view_default_242, transpose_int_65);  view_default_242 = transpose_int_65 = None
        view_default_243 = torch.ops.aten.view.default(bmm_default_50, [8, 6, 64, 197]);  bmm_default_50 = None
        view_default_244 = torch.ops.aten.view.default(bmm_default_51, [8, 6, 197, 64]);  bmm_default_51 = None
        transpose_int_66 = torch.ops.aten.transpose.int(view_default_243, -2, -1);  view_default_243 = None
        select_backward_default_19 = torch.ops.aten.select_backward.default(view_default_240, [3, 8, 6, 197, 64], 0, 2);  view_default_240 = None
        select_backward_default_20 = torch.ops.aten.select_backward.default(transpose_int_66, [3, 8, 6, 197, 64], 0, 1);  transpose_int_66 = None
        add_tensor_64 = torch.ops.aten.add.Tensor(select_backward_default_19, select_backward_default_20);  select_backward_default_19 = select_backward_default_20 = None
        select_backward_default_21 = torch.ops.aten.select_backward.default(view_default_244, [3, 8, 6, 197, 64], 0, 0);  view_default_244 = None
        add_tensor_65 = torch.ops.aten.add.Tensor(add_tensor_64, select_backward_default_21);  add_tensor_64 = select_backward_default_21 = None
        permute_default_18 = torch.ops.aten.permute.default(add_tensor_65, [1, 3, 0, 2, 4]);  add_tensor_65 = None
        clone_default_61 = torch.ops.aten.clone.default(permute_default_18, memory_format = torch.contiguous_format);  permute_default_18 = None
        _unsafe_view_default_85 = torch.ops.aten._unsafe_view.default(clone_default_61, [8, 197, 1152]);  clone_default_61 = None
        view_default_245 = torch.ops.aten.view.default(_unsafe_view_default_85, [1576, 1152]);  _unsafe_view_default_85 = None
        t_default_161 = torch.ops.aten.t.default(t_default_20);  t_default_20 = None
        mm_default_56 = torch.ops.aten.mm.default(view_default_245, t_default_161);  t_default_161 = None
        t_default_162 = torch.ops.aten.t.default(view_default_245)
        mm_default_57 = torch.ops.aten.mm.default(t_default_162, view_default_51);  t_default_162 = view_default_51 = None
        t_default_163 = torch.ops.aten.t.default(mm_default_57);  mm_default_57 = None
        sum_dim_int_list_28 = torch.ops.aten.sum.dim_IntList(view_default_245, [0], True);  view_default_245 = None
        view_default_246 = torch.ops.aten.view.default(sum_dim_int_list_28, [1152]);  sum_dim_int_list_28 = None
        t_default_164 = torch.ops.aten.t.default(t_default_163);  t_default_163 = None
        view_default_247 = torch.ops.aten.view.default(mm_default_56, [8, 197, 384]);  mm_default_56 = None
        native_layer_norm_backward_default_14 = torch.ops.aten.native_layer_norm_backward.default(view_default_247, add_tensor_10, [384], getitem_31, getitem_32, primals_94, primals_93, [True, True, True]);  view_default_247 = add_tensor_10 = getitem_31 = getitem_32 = primals_94 = primals_93 = None
        getitem_117 = native_layer_norm_backward_default_14[0]
        getitem_118 = native_layer_norm_backward_default_14[1]
        getitem_119 = native_layer_norm_backward_default_14[2];  native_layer_norm_backward_default_14 = None
        add_tensor_66 = torch.ops.aten.add.Tensor(add_tensor_63, getitem_117);  add_tensor_63 = getitem_117 = None
        view_default_248 = torch.ops.aten.view.default(add_tensor_66, [1576, 384])
        t_default_165 = torch.ops.aten.t.default(t_default_19);  t_default_19 = None
        mm_default_58 = torch.ops.aten.mm.default(view_default_248, t_default_165);  t_default_165 = None
        t_default_166 = torch.ops.aten.t.default(view_default_248)
        mm_default_59 = torch.ops.aten.mm.default(t_default_166, view_default_49);  t_default_166 = view_default_49 = None
        t_default_167 = torch.ops.aten.t.default(mm_default_59);  mm_default_59 = None
        sum_dim_int_list_29 = torch.ops.aten.sum.dim_IntList(view_default_248, [0], True);  view_default_248 = None
        view_default_249 = torch.ops.aten.view.default(sum_dim_int_list_29, [384]);  sum_dim_int_list_29 = None
        t_default_168 = torch.ops.aten.t.default(t_default_167);  t_default_167 = None
        view_default_250 = torch.ops.aten.view.default(mm_default_58, [8, 197, 1536]);  mm_default_58 = None
        to_dtype_21 = torch.ops.aten.to.dtype(view_default_250, torch.float32);  view_default_250 = None
        to_dtype_22 = torch.ops.aten.to.dtype(view_default_48, torch.float32);  view_default_48 = None
        mul_tensor_68 = torch.ops.aten.mul.Tensor(to_dtype_22, 0.7071067811865476)
        erf_default_7 = torch.ops.aten.erf.default(mul_tensor_68);  mul_tensor_68 = None
        add_tensor_67 = torch.ops.aten.add.Tensor(erf_default_7, 1);  erf_default_7 = None
        mul_tensor_69 = torch.ops.aten.mul.Tensor(add_tensor_67, 0.5);  add_tensor_67 = None
        mul_tensor_70 = torch.ops.aten.mul.Tensor(to_dtype_22, to_dtype_22)
        mul_tensor_71 = torch.ops.aten.mul.Tensor(mul_tensor_70, -0.5);  mul_tensor_70 = None
        exp_default_7 = torch.ops.aten.exp.default(mul_tensor_71);  mul_tensor_71 = None
        mul_tensor_72 = torch.ops.aten.mul.Tensor(exp_default_7, 0.3989422804014327);  exp_default_7 = None
        mul_tensor_73 = torch.ops.aten.mul.Tensor(to_dtype_22, mul_tensor_72);  to_dtype_22 = mul_tensor_72 = None
        add_tensor_68 = torch.ops.aten.add.Tensor(mul_tensor_69, mul_tensor_73);  mul_tensor_69 = mul_tensor_73 = None
        mul_tensor_74 = torch.ops.aten.mul.Tensor(to_dtype_21, add_tensor_68);  to_dtype_21 = add_tensor_68 = None
        to_dtype_23 = torch.ops.aten.to.dtype(mul_tensor_74, torch.float32);  mul_tensor_74 = None
        view_default_251 = torch.ops.aten.view.default(to_dtype_23, [1576, 1536]);  to_dtype_23 = None
        t_default_169 = torch.ops.aten.t.default(t_default_18);  t_default_18 = None
        mm_default_60 = torch.ops.aten.mm.default(view_default_251, t_default_169);  t_default_169 = None
        t_default_170 = torch.ops.aten.t.default(view_default_251)
        mm_default_61 = torch.ops.aten.mm.default(t_default_170, view_default_47);  t_default_170 = view_default_47 = None
        t_default_171 = torch.ops.aten.t.default(mm_default_61);  mm_default_61 = None
        sum_dim_int_list_30 = torch.ops.aten.sum.dim_IntList(view_default_251, [0], True);  view_default_251 = None
        view_default_252 = torch.ops.aten.view.default(sum_dim_int_list_30, [1536]);  sum_dim_int_list_30 = None
        t_default_172 = torch.ops.aten.t.default(t_default_171);  t_default_171 = None
        view_default_253 = torch.ops.aten.view.default(mm_default_60, [8, 197, 384]);  mm_default_60 = None
        native_layer_norm_backward_default_15 = torch.ops.aten.native_layer_norm_backward.default(view_default_253, add_tensor_9, [384], getitem_28, getitem_29, primals_84, primals_83, [True, True, True]);  view_default_253 = add_tensor_9 = getitem_28 = getitem_29 = primals_84 = primals_83 = None
        getitem_120 = native_layer_norm_backward_default_15[0]
        getitem_121 = native_layer_norm_backward_default_15[1]
        getitem_122 = native_layer_norm_backward_default_15[2];  native_layer_norm_backward_default_15 = None
        add_tensor_69 = torch.ops.aten.add.Tensor(add_tensor_66, getitem_120);  add_tensor_66 = getitem_120 = None
        view_default_254 = torch.ops.aten.view.default(add_tensor_69, [1576, 384])
        t_default_173 = torch.ops.aten.t.default(t_default_17);  t_default_17 = None
        mm_default_62 = torch.ops.aten.mm.default(view_default_254, t_default_173);  t_default_173 = None
        t_default_174 = torch.ops.aten.t.default(view_default_254)
        mm_default_63 = torch.ops.aten.mm.default(t_default_174, view_default_45);  t_default_174 = view_default_45 = None
        t_default_175 = torch.ops.aten.t.default(mm_default_63);  mm_default_63 = None
        sum_dim_int_list_31 = torch.ops.aten.sum.dim_IntList(view_default_254, [0], True);  view_default_254 = None
        view_default_255 = torch.ops.aten.view.default(sum_dim_int_list_31, [384]);  sum_dim_int_list_31 = None
        t_default_176 = torch.ops.aten.t.default(t_default_175);  t_default_175 = None
        view_default_256 = torch.ops.aten.view.default(mm_default_62, [8, 197, 384]);  mm_default_62 = None
        view_default_257 = torch.ops.aten.view.default(view_default_256, [8, 197, 6, 64]);  view_default_256 = None
        transpose_int_67 = torch.ops.aten.transpose.int(view_default_257, 1, 2);  view_default_257 = None
        clone_default_62 = torch.ops.aten.clone.default(transpose_int_67, memory_format = torch.contiguous_format);  transpose_int_67 = None
        _unsafe_view_default_86 = torch.ops.aten._unsafe_view.default(clone_default_62, [48, 197, 64]);  clone_default_62 = None
        transpose_int_68 = torch.ops.aten.transpose.int(view_default_44, 1, 2);  view_default_44 = None
        bmm_default_52 = torch.ops.aten.bmm.default(transpose_int_68, _unsafe_view_default_86);  transpose_int_68 = None
        transpose_int_69 = torch.ops.aten.transpose.int(_unsafe_view_default_27, 1, 2);  _unsafe_view_default_27 = None
        bmm_default_53 = torch.ops.aten.bmm.default(_unsafe_view_default_86, transpose_int_69);  _unsafe_view_default_86 = transpose_int_69 = None
        view_default_258 = torch.ops.aten.view.default(bmm_default_52, [8, 6, 197, 64]);  bmm_default_52 = None
        view_default_259 = torch.ops.aten.view.default(bmm_default_53, [8, 6, 197, 197]);  bmm_default_53 = None
        _softmax_backward_data_default_7 = torch.ops.aten._softmax_backward_data.default(view_default_259, _softmax_default_4, -1, torch.float32);  view_default_259 = _softmax_default_4 = None
        mul_tensor_75 = torch.ops.aten.mul.Tensor(_softmax_backward_data_default_7, 0.125);  _softmax_backward_data_default_7 = None
        view_default_260 = torch.ops.aten.view.default(mul_tensor_75, [48, 197, 197]);  mul_tensor_75 = None
        transpose_int_70 = torch.ops.aten.transpose.int(_unsafe_view_default_24, 1, 2);  _unsafe_view_default_24 = None
        bmm_default_54 = torch.ops.aten.bmm.default(transpose_int_70, view_default_260);  transpose_int_70 = None
        transpose_int_71 = torch.ops.aten.transpose.int(_unsafe_view_default_25, 1, 2);  _unsafe_view_default_25 = None
        bmm_default_55 = torch.ops.aten.bmm.default(view_default_260, transpose_int_71);  view_default_260 = transpose_int_71 = None
        view_default_261 = torch.ops.aten.view.default(bmm_default_54, [8, 6, 64, 197]);  bmm_default_54 = None
        view_default_262 = torch.ops.aten.view.default(bmm_default_55, [8, 6, 197, 64]);  bmm_default_55 = None
        transpose_int_72 = torch.ops.aten.transpose.int(view_default_261, -2, -1);  view_default_261 = None
        select_backward_default_22 = torch.ops.aten.select_backward.default(view_default_258, [3, 8, 6, 197, 64], 0, 2);  view_default_258 = None
        select_backward_default_23 = torch.ops.aten.select_backward.default(transpose_int_72, [3, 8, 6, 197, 64], 0, 1);  transpose_int_72 = None
        add_tensor_70 = torch.ops.aten.add.Tensor(select_backward_default_22, select_backward_default_23);  select_backward_default_22 = select_backward_default_23 = None
        select_backward_default_24 = torch.ops.aten.select_backward.default(view_default_262, [3, 8, 6, 197, 64], 0, 0);  view_default_262 = None
        add_tensor_71 = torch.ops.aten.add.Tensor(add_tensor_70, select_backward_default_24);  add_tensor_70 = select_backward_default_24 = None
        permute_default_19 = torch.ops.aten.permute.default(add_tensor_71, [1, 3, 0, 2, 4]);  add_tensor_71 = None
        clone_default_63 = torch.ops.aten.clone.default(permute_default_19, memory_format = torch.contiguous_format);  permute_default_19 = None
        _unsafe_view_default_87 = torch.ops.aten._unsafe_view.default(clone_default_63, [8, 197, 1152]);  clone_default_63 = None
        view_default_263 = torch.ops.aten.view.default(_unsafe_view_default_87, [1576, 1152]);  _unsafe_view_default_87 = None
        t_default_177 = torch.ops.aten.t.default(t_default_16);  t_default_16 = None
        mm_default_64 = torch.ops.aten.mm.default(view_default_263, t_default_177);  t_default_177 = None
        t_default_178 = torch.ops.aten.t.default(view_default_263)
        mm_default_65 = torch.ops.aten.mm.default(t_default_178, view_default_41);  t_default_178 = view_default_41 = None
        t_default_179 = torch.ops.aten.t.default(mm_default_65);  mm_default_65 = None
        sum_dim_int_list_32 = torch.ops.aten.sum.dim_IntList(view_default_263, [0], True);  view_default_263 = None
        view_default_264 = torch.ops.aten.view.default(sum_dim_int_list_32, [1152]);  sum_dim_int_list_32 = None
        t_default_180 = torch.ops.aten.t.default(t_default_179);  t_default_179 = None
        view_default_265 = torch.ops.aten.view.default(mm_default_64, [8, 197, 384]);  mm_default_64 = None
        native_layer_norm_backward_default_16 = torch.ops.aten.native_layer_norm_backward.default(view_default_265, add_tensor_8, [384], getitem_25, getitem_26, primals_82, primals_81, [True, True, True]);  view_default_265 = add_tensor_8 = getitem_25 = getitem_26 = primals_82 = primals_81 = None
        getitem_123 = native_layer_norm_backward_default_16[0]
        getitem_124 = native_layer_norm_backward_default_16[1]
        getitem_125 = native_layer_norm_backward_default_16[2];  native_layer_norm_backward_default_16 = None
        add_tensor_72 = torch.ops.aten.add.Tensor(add_tensor_69, getitem_123);  add_tensor_69 = getitem_123 = None
        view_default_266 = torch.ops.aten.view.default(add_tensor_72, [1576, 384])
        t_default_181 = torch.ops.aten.t.default(t_default_15);  t_default_15 = None
        mm_default_66 = torch.ops.aten.mm.default(view_default_266, t_default_181);  t_default_181 = None
        t_default_182 = torch.ops.aten.t.default(view_default_266)
        mm_default_67 = torch.ops.aten.mm.default(t_default_182, view_default_39);  t_default_182 = view_default_39 = None
        t_default_183 = torch.ops.aten.t.default(mm_default_67);  mm_default_67 = None
        sum_dim_int_list_33 = torch.ops.aten.sum.dim_IntList(view_default_266, [0], True);  view_default_266 = None
        view_default_267 = torch.ops.aten.view.default(sum_dim_int_list_33, [384]);  sum_dim_int_list_33 = None
        t_default_184 = torch.ops.aten.t.default(t_default_183);  t_default_183 = None
        view_default_268 = torch.ops.aten.view.default(mm_default_66, [8, 197, 1536]);  mm_default_66 = None
        to_dtype_24 = torch.ops.aten.to.dtype(view_default_268, torch.float32);  view_default_268 = None
        to_dtype_25 = torch.ops.aten.to.dtype(view_default_38, torch.float32);  view_default_38 = None
        mul_tensor_76 = torch.ops.aten.mul.Tensor(to_dtype_25, 0.7071067811865476)
        erf_default_8 = torch.ops.aten.erf.default(mul_tensor_76);  mul_tensor_76 = None
        add_tensor_73 = torch.ops.aten.add.Tensor(erf_default_8, 1);  erf_default_8 = None
        mul_tensor_77 = torch.ops.aten.mul.Tensor(add_tensor_73, 0.5);  add_tensor_73 = None
        mul_tensor_78 = torch.ops.aten.mul.Tensor(to_dtype_25, to_dtype_25)
        mul_tensor_79 = torch.ops.aten.mul.Tensor(mul_tensor_78, -0.5);  mul_tensor_78 = None
        exp_default_8 = torch.ops.aten.exp.default(mul_tensor_79);  mul_tensor_79 = None
        mul_tensor_80 = torch.ops.aten.mul.Tensor(exp_default_8, 0.3989422804014327);  exp_default_8 = None
        mul_tensor_81 = torch.ops.aten.mul.Tensor(to_dtype_25, mul_tensor_80);  to_dtype_25 = mul_tensor_80 = None
        add_tensor_74 = torch.ops.aten.add.Tensor(mul_tensor_77, mul_tensor_81);  mul_tensor_77 = mul_tensor_81 = None
        mul_tensor_82 = torch.ops.aten.mul.Tensor(to_dtype_24, add_tensor_74);  to_dtype_24 = add_tensor_74 = None
        to_dtype_26 = torch.ops.aten.to.dtype(mul_tensor_82, torch.float32);  mul_tensor_82 = None
        view_default_269 = torch.ops.aten.view.default(to_dtype_26, [1576, 1536]);  to_dtype_26 = None
        t_default_185 = torch.ops.aten.t.default(t_default_14);  t_default_14 = None
        mm_default_68 = torch.ops.aten.mm.default(view_default_269, t_default_185);  t_default_185 = None
        t_default_186 = torch.ops.aten.t.default(view_default_269)
        mm_default_69 = torch.ops.aten.mm.default(t_default_186, view_default_37);  t_default_186 = view_default_37 = None
        t_default_187 = torch.ops.aten.t.default(mm_default_69);  mm_default_69 = None
        sum_dim_int_list_34 = torch.ops.aten.sum.dim_IntList(view_default_269, [0], True);  view_default_269 = None
        view_default_270 = torch.ops.aten.view.default(sum_dim_int_list_34, [1536]);  sum_dim_int_list_34 = None
        t_default_188 = torch.ops.aten.t.default(t_default_187);  t_default_187 = None
        view_default_271 = torch.ops.aten.view.default(mm_default_68, [8, 197, 384]);  mm_default_68 = None
        native_layer_norm_backward_default_17 = torch.ops.aten.native_layer_norm_backward.default(view_default_271, add_tensor_7, [384], getitem_22, getitem_23, primals_72, primals_71, [True, True, True]);  view_default_271 = add_tensor_7 = getitem_22 = getitem_23 = primals_72 = primals_71 = None
        getitem_126 = native_layer_norm_backward_default_17[0]
        getitem_127 = native_layer_norm_backward_default_17[1]
        getitem_128 = native_layer_norm_backward_default_17[2];  native_layer_norm_backward_default_17 = None
        add_tensor_75 = torch.ops.aten.add.Tensor(add_tensor_72, getitem_126);  add_tensor_72 = getitem_126 = None
        view_default_272 = torch.ops.aten.view.default(add_tensor_75, [1576, 384])
        t_default_189 = torch.ops.aten.t.default(t_default_13);  t_default_13 = None
        mm_default_70 = torch.ops.aten.mm.default(view_default_272, t_default_189);  t_default_189 = None
        t_default_190 = torch.ops.aten.t.default(view_default_272)
        mm_default_71 = torch.ops.aten.mm.default(t_default_190, view_default_35);  t_default_190 = view_default_35 = None
        t_default_191 = torch.ops.aten.t.default(mm_default_71);  mm_default_71 = None
        sum_dim_int_list_35 = torch.ops.aten.sum.dim_IntList(view_default_272, [0], True);  view_default_272 = None
        view_default_273 = torch.ops.aten.view.default(sum_dim_int_list_35, [384]);  sum_dim_int_list_35 = None
        t_default_192 = torch.ops.aten.t.default(t_default_191);  t_default_191 = None
        view_default_274 = torch.ops.aten.view.default(mm_default_70, [8, 197, 384]);  mm_default_70 = None
        view_default_275 = torch.ops.aten.view.default(view_default_274, [8, 197, 6, 64]);  view_default_274 = None
        transpose_int_73 = torch.ops.aten.transpose.int(view_default_275, 1, 2);  view_default_275 = None
        clone_default_64 = torch.ops.aten.clone.default(transpose_int_73, memory_format = torch.contiguous_format);  transpose_int_73 = None
        _unsafe_view_default_88 = torch.ops.aten._unsafe_view.default(clone_default_64, [48, 197, 64]);  clone_default_64 = None
        transpose_int_74 = torch.ops.aten.transpose.int(view_default_34, 1, 2);  view_default_34 = None
        bmm_default_56 = torch.ops.aten.bmm.default(transpose_int_74, _unsafe_view_default_88);  transpose_int_74 = None
        transpose_int_75 = torch.ops.aten.transpose.int(_unsafe_view_default_21, 1, 2);  _unsafe_view_default_21 = None
        bmm_default_57 = torch.ops.aten.bmm.default(_unsafe_view_default_88, transpose_int_75);  _unsafe_view_default_88 = transpose_int_75 = None
        view_default_276 = torch.ops.aten.view.default(bmm_default_56, [8, 6, 197, 64]);  bmm_default_56 = None
        view_default_277 = torch.ops.aten.view.default(bmm_default_57, [8, 6, 197, 197]);  bmm_default_57 = None
        _softmax_backward_data_default_8 = torch.ops.aten._softmax_backward_data.default(view_default_277, _softmax_default_3, -1, torch.float32);  view_default_277 = _softmax_default_3 = None
        mul_tensor_83 = torch.ops.aten.mul.Tensor(_softmax_backward_data_default_8, 0.125);  _softmax_backward_data_default_8 = None
        view_default_278 = torch.ops.aten.view.default(mul_tensor_83, [48, 197, 197]);  mul_tensor_83 = None
        transpose_int_76 = torch.ops.aten.transpose.int(_unsafe_view_default_18, 1, 2);  _unsafe_view_default_18 = None
        bmm_default_58 = torch.ops.aten.bmm.default(transpose_int_76, view_default_278);  transpose_int_76 = None
        transpose_int_77 = torch.ops.aten.transpose.int(_unsafe_view_default_19, 1, 2);  _unsafe_view_default_19 = None
        bmm_default_59 = torch.ops.aten.bmm.default(view_default_278, transpose_int_77);  view_default_278 = transpose_int_77 = None
        view_default_279 = torch.ops.aten.view.default(bmm_default_58, [8, 6, 64, 197]);  bmm_default_58 = None
        view_default_280 = torch.ops.aten.view.default(bmm_default_59, [8, 6, 197, 64]);  bmm_default_59 = None
        transpose_int_78 = torch.ops.aten.transpose.int(view_default_279, -2, -1);  view_default_279 = None
        select_backward_default_25 = torch.ops.aten.select_backward.default(view_default_276, [3, 8, 6, 197, 64], 0, 2);  view_default_276 = None
        select_backward_default_26 = torch.ops.aten.select_backward.default(transpose_int_78, [3, 8, 6, 197, 64], 0, 1);  transpose_int_78 = None
        add_tensor_76 = torch.ops.aten.add.Tensor(select_backward_default_25, select_backward_default_26);  select_backward_default_25 = select_backward_default_26 = None
        select_backward_default_27 = torch.ops.aten.select_backward.default(view_default_280, [3, 8, 6, 197, 64], 0, 0);  view_default_280 = None
        add_tensor_77 = torch.ops.aten.add.Tensor(add_tensor_76, select_backward_default_27);  add_tensor_76 = select_backward_default_27 = None
        permute_default_20 = torch.ops.aten.permute.default(add_tensor_77, [1, 3, 0, 2, 4]);  add_tensor_77 = None
        clone_default_65 = torch.ops.aten.clone.default(permute_default_20, memory_format = torch.contiguous_format);  permute_default_20 = None
        _unsafe_view_default_89 = torch.ops.aten._unsafe_view.default(clone_default_65, [8, 197, 1152]);  clone_default_65 = None
        view_default_281 = torch.ops.aten.view.default(_unsafe_view_default_89, [1576, 1152]);  _unsafe_view_default_89 = None
        t_default_193 = torch.ops.aten.t.default(t_default_12);  t_default_12 = None
        mm_default_72 = torch.ops.aten.mm.default(view_default_281, t_default_193);  t_default_193 = None
        t_default_194 = torch.ops.aten.t.default(view_default_281)
        mm_default_73 = torch.ops.aten.mm.default(t_default_194, view_default_31);  t_default_194 = view_default_31 = None
        t_default_195 = torch.ops.aten.t.default(mm_default_73);  mm_default_73 = None
        sum_dim_int_list_36 = torch.ops.aten.sum.dim_IntList(view_default_281, [0], True);  view_default_281 = None
        view_default_282 = torch.ops.aten.view.default(sum_dim_int_list_36, [1152]);  sum_dim_int_list_36 = None
        t_default_196 = torch.ops.aten.t.default(t_default_195);  t_default_195 = None
        view_default_283 = torch.ops.aten.view.default(mm_default_72, [8, 197, 384]);  mm_default_72 = None
        native_layer_norm_backward_default_18 = torch.ops.aten.native_layer_norm_backward.default(view_default_283, add_tensor_6, [384], getitem_19, getitem_20, primals_70, primals_69, [True, True, True]);  view_default_283 = add_tensor_6 = getitem_19 = getitem_20 = primals_70 = primals_69 = None
        getitem_129 = native_layer_norm_backward_default_18[0]
        getitem_130 = native_layer_norm_backward_default_18[1]
        getitem_131 = native_layer_norm_backward_default_18[2];  native_layer_norm_backward_default_18 = None
        add_tensor_78 = torch.ops.aten.add.Tensor(add_tensor_75, getitem_129);  add_tensor_75 = getitem_129 = None
        view_default_284 = torch.ops.aten.view.default(add_tensor_78, [1576, 384])
        t_default_197 = torch.ops.aten.t.default(t_default_11);  t_default_11 = None
        mm_default_74 = torch.ops.aten.mm.default(view_default_284, t_default_197);  t_default_197 = None
        t_default_198 = torch.ops.aten.t.default(view_default_284)
        mm_default_75 = torch.ops.aten.mm.default(t_default_198, view_default_29);  t_default_198 = view_default_29 = None
        t_default_199 = torch.ops.aten.t.default(mm_default_75);  mm_default_75 = None
        sum_dim_int_list_37 = torch.ops.aten.sum.dim_IntList(view_default_284, [0], True);  view_default_284 = None
        view_default_285 = torch.ops.aten.view.default(sum_dim_int_list_37, [384]);  sum_dim_int_list_37 = None
        t_default_200 = torch.ops.aten.t.default(t_default_199);  t_default_199 = None
        view_default_286 = torch.ops.aten.view.default(mm_default_74, [8, 197, 1536]);  mm_default_74 = None
        to_dtype_27 = torch.ops.aten.to.dtype(view_default_286, torch.float32);  view_default_286 = None
        to_dtype_28 = torch.ops.aten.to.dtype(view_default_28, torch.float32);  view_default_28 = None
        mul_tensor_84 = torch.ops.aten.mul.Tensor(to_dtype_28, 0.7071067811865476)
        erf_default_9 = torch.ops.aten.erf.default(mul_tensor_84);  mul_tensor_84 = None
        add_tensor_79 = torch.ops.aten.add.Tensor(erf_default_9, 1);  erf_default_9 = None
        mul_tensor_85 = torch.ops.aten.mul.Tensor(add_tensor_79, 0.5);  add_tensor_79 = None
        mul_tensor_86 = torch.ops.aten.mul.Tensor(to_dtype_28, to_dtype_28)
        mul_tensor_87 = torch.ops.aten.mul.Tensor(mul_tensor_86, -0.5);  mul_tensor_86 = None
        exp_default_9 = torch.ops.aten.exp.default(mul_tensor_87);  mul_tensor_87 = None
        mul_tensor_88 = torch.ops.aten.mul.Tensor(exp_default_9, 0.3989422804014327);  exp_default_9 = None
        mul_tensor_89 = torch.ops.aten.mul.Tensor(to_dtype_28, mul_tensor_88);  to_dtype_28 = mul_tensor_88 = None
        add_tensor_80 = torch.ops.aten.add.Tensor(mul_tensor_85, mul_tensor_89);  mul_tensor_85 = mul_tensor_89 = None
        mul_tensor_90 = torch.ops.aten.mul.Tensor(to_dtype_27, add_tensor_80);  to_dtype_27 = add_tensor_80 = None
        to_dtype_29 = torch.ops.aten.to.dtype(mul_tensor_90, torch.float32);  mul_tensor_90 = None
        view_default_287 = torch.ops.aten.view.default(to_dtype_29, [1576, 1536]);  to_dtype_29 = None
        t_default_201 = torch.ops.aten.t.default(t_default_10);  t_default_10 = None
        mm_default_76 = torch.ops.aten.mm.default(view_default_287, t_default_201);  t_default_201 = None
        t_default_202 = torch.ops.aten.t.default(view_default_287)
        mm_default_77 = torch.ops.aten.mm.default(t_default_202, view_default_27);  t_default_202 = view_default_27 = None
        t_default_203 = torch.ops.aten.t.default(mm_default_77);  mm_default_77 = None
        sum_dim_int_list_38 = torch.ops.aten.sum.dim_IntList(view_default_287, [0], True);  view_default_287 = None
        view_default_288 = torch.ops.aten.view.default(sum_dim_int_list_38, [1536]);  sum_dim_int_list_38 = None
        t_default_204 = torch.ops.aten.t.default(t_default_203);  t_default_203 = None
        view_default_289 = torch.ops.aten.view.default(mm_default_76, [8, 197, 384]);  mm_default_76 = None
        native_layer_norm_backward_default_19 = torch.ops.aten.native_layer_norm_backward.default(view_default_289, add_tensor_5, [384], getitem_16, getitem_17, primals_60, primals_59, [True, True, True]);  view_default_289 = add_tensor_5 = getitem_16 = getitem_17 = primals_60 = primals_59 = None
        getitem_132 = native_layer_norm_backward_default_19[0]
        getitem_133 = native_layer_norm_backward_default_19[1]
        getitem_134 = native_layer_norm_backward_default_19[2];  native_layer_norm_backward_default_19 = None
        add_tensor_81 = torch.ops.aten.add.Tensor(add_tensor_78, getitem_132);  add_tensor_78 = getitem_132 = None
        view_default_290 = torch.ops.aten.view.default(add_tensor_81, [1576, 384])
        t_default_205 = torch.ops.aten.t.default(t_default_9);  t_default_9 = None
        mm_default_78 = torch.ops.aten.mm.default(view_default_290, t_default_205);  t_default_205 = None
        t_default_206 = torch.ops.aten.t.default(view_default_290)
        mm_default_79 = torch.ops.aten.mm.default(t_default_206, view_default_25);  t_default_206 = view_default_25 = None
        t_default_207 = torch.ops.aten.t.default(mm_default_79);  mm_default_79 = None
        sum_dim_int_list_39 = torch.ops.aten.sum.dim_IntList(view_default_290, [0], True);  view_default_290 = None
        view_default_291 = torch.ops.aten.view.default(sum_dim_int_list_39, [384]);  sum_dim_int_list_39 = None
        t_default_208 = torch.ops.aten.t.default(t_default_207);  t_default_207 = None
        view_default_292 = torch.ops.aten.view.default(mm_default_78, [8, 197, 384]);  mm_default_78 = None
        view_default_293 = torch.ops.aten.view.default(view_default_292, [8, 197, 6, 64]);  view_default_292 = None
        transpose_int_79 = torch.ops.aten.transpose.int(view_default_293, 1, 2);  view_default_293 = None
        clone_default_66 = torch.ops.aten.clone.default(transpose_int_79, memory_format = torch.contiguous_format);  transpose_int_79 = None
        _unsafe_view_default_90 = torch.ops.aten._unsafe_view.default(clone_default_66, [48, 197, 64]);  clone_default_66 = None
        transpose_int_80 = torch.ops.aten.transpose.int(view_default_24, 1, 2);  view_default_24 = None
        bmm_default_60 = torch.ops.aten.bmm.default(transpose_int_80, _unsafe_view_default_90);  transpose_int_80 = None
        transpose_int_81 = torch.ops.aten.transpose.int(_unsafe_view_default_15, 1, 2);  _unsafe_view_default_15 = None
        bmm_default_61 = torch.ops.aten.bmm.default(_unsafe_view_default_90, transpose_int_81);  _unsafe_view_default_90 = transpose_int_81 = None
        view_default_294 = torch.ops.aten.view.default(bmm_default_60, [8, 6, 197, 64]);  bmm_default_60 = None
        view_default_295 = torch.ops.aten.view.default(bmm_default_61, [8, 6, 197, 197]);  bmm_default_61 = None
        _softmax_backward_data_default_9 = torch.ops.aten._softmax_backward_data.default(view_default_295, _softmax_default_2, -1, torch.float32);  view_default_295 = _softmax_default_2 = None
        mul_tensor_91 = torch.ops.aten.mul.Tensor(_softmax_backward_data_default_9, 0.125);  _softmax_backward_data_default_9 = None
        view_default_296 = torch.ops.aten.view.default(mul_tensor_91, [48, 197, 197]);  mul_tensor_91 = None
        transpose_int_82 = torch.ops.aten.transpose.int(_unsafe_view_default_12, 1, 2);  _unsafe_view_default_12 = None
        bmm_default_62 = torch.ops.aten.bmm.default(transpose_int_82, view_default_296);  transpose_int_82 = None
        transpose_int_83 = torch.ops.aten.transpose.int(_unsafe_view_default_13, 1, 2);  _unsafe_view_default_13 = None
        bmm_default_63 = torch.ops.aten.bmm.default(view_default_296, transpose_int_83);  view_default_296 = transpose_int_83 = None
        view_default_297 = torch.ops.aten.view.default(bmm_default_62, [8, 6, 64, 197]);  bmm_default_62 = None
        view_default_298 = torch.ops.aten.view.default(bmm_default_63, [8, 6, 197, 64]);  bmm_default_63 = None
        transpose_int_84 = torch.ops.aten.transpose.int(view_default_297, -2, -1);  view_default_297 = None
        select_backward_default_28 = torch.ops.aten.select_backward.default(view_default_294, [3, 8, 6, 197, 64], 0, 2);  view_default_294 = None
        select_backward_default_29 = torch.ops.aten.select_backward.default(transpose_int_84, [3, 8, 6, 197, 64], 0, 1);  transpose_int_84 = None
        add_tensor_82 = torch.ops.aten.add.Tensor(select_backward_default_28, select_backward_default_29);  select_backward_default_28 = select_backward_default_29 = None
        select_backward_default_30 = torch.ops.aten.select_backward.default(view_default_298, [3, 8, 6, 197, 64], 0, 0);  view_default_298 = None
        add_tensor_83 = torch.ops.aten.add.Tensor(add_tensor_82, select_backward_default_30);  add_tensor_82 = select_backward_default_30 = None
        permute_default_21 = torch.ops.aten.permute.default(add_tensor_83, [1, 3, 0, 2, 4]);  add_tensor_83 = None
        clone_default_67 = torch.ops.aten.clone.default(permute_default_21, memory_format = torch.contiguous_format);  permute_default_21 = None
        _unsafe_view_default_91 = torch.ops.aten._unsafe_view.default(clone_default_67, [8, 197, 1152]);  clone_default_67 = None
        view_default_299 = torch.ops.aten.view.default(_unsafe_view_default_91, [1576, 1152]);  _unsafe_view_default_91 = None
        t_default_209 = torch.ops.aten.t.default(t_default_8);  t_default_8 = None
        mm_default_80 = torch.ops.aten.mm.default(view_default_299, t_default_209);  t_default_209 = None
        t_default_210 = torch.ops.aten.t.default(view_default_299)
        mm_default_81 = torch.ops.aten.mm.default(t_default_210, view_default_21);  t_default_210 = view_default_21 = None
        t_default_211 = torch.ops.aten.t.default(mm_default_81);  mm_default_81 = None
        sum_dim_int_list_40 = torch.ops.aten.sum.dim_IntList(view_default_299, [0], True);  view_default_299 = None
        view_default_300 = torch.ops.aten.view.default(sum_dim_int_list_40, [1152]);  sum_dim_int_list_40 = None
        t_default_212 = torch.ops.aten.t.default(t_default_211);  t_default_211 = None
        view_default_301 = torch.ops.aten.view.default(mm_default_80, [8, 197, 384]);  mm_default_80 = None
        native_layer_norm_backward_default_20 = torch.ops.aten.native_layer_norm_backward.default(view_default_301, add_tensor_4, [384], getitem_13, getitem_14, primals_58, primals_57, [True, True, True]);  view_default_301 = add_tensor_4 = getitem_13 = getitem_14 = primals_58 = primals_57 = None
        getitem_135 = native_layer_norm_backward_default_20[0]
        getitem_136 = native_layer_norm_backward_default_20[1]
        getitem_137 = native_layer_norm_backward_default_20[2];  native_layer_norm_backward_default_20 = None
        add_tensor_84 = torch.ops.aten.add.Tensor(add_tensor_81, getitem_135);  add_tensor_81 = getitem_135 = None
        view_default_302 = torch.ops.aten.view.default(add_tensor_84, [1576, 384])
        t_default_213 = torch.ops.aten.t.default(t_default_7);  t_default_7 = None
        mm_default_82 = torch.ops.aten.mm.default(view_default_302, t_default_213);  t_default_213 = None
        t_default_214 = torch.ops.aten.t.default(view_default_302)
        mm_default_83 = torch.ops.aten.mm.default(t_default_214, view_default_19);  t_default_214 = view_default_19 = None
        t_default_215 = torch.ops.aten.t.default(mm_default_83);  mm_default_83 = None
        sum_dim_int_list_41 = torch.ops.aten.sum.dim_IntList(view_default_302, [0], True);  view_default_302 = None
        view_default_303 = torch.ops.aten.view.default(sum_dim_int_list_41, [384]);  sum_dim_int_list_41 = None
        t_default_216 = torch.ops.aten.t.default(t_default_215);  t_default_215 = None
        view_default_304 = torch.ops.aten.view.default(mm_default_82, [8, 197, 1536]);  mm_default_82 = None
        to_dtype_30 = torch.ops.aten.to.dtype(view_default_304, torch.float32);  view_default_304 = None
        to_dtype_31 = torch.ops.aten.to.dtype(view_default_18, torch.float32);  view_default_18 = None
        mul_tensor_92 = torch.ops.aten.mul.Tensor(to_dtype_31, 0.7071067811865476)
        erf_default_10 = torch.ops.aten.erf.default(mul_tensor_92);  mul_tensor_92 = None
        add_tensor_85 = torch.ops.aten.add.Tensor(erf_default_10, 1);  erf_default_10 = None
        mul_tensor_93 = torch.ops.aten.mul.Tensor(add_tensor_85, 0.5);  add_tensor_85 = None
        mul_tensor_94 = torch.ops.aten.mul.Tensor(to_dtype_31, to_dtype_31)
        mul_tensor_95 = torch.ops.aten.mul.Tensor(mul_tensor_94, -0.5);  mul_tensor_94 = None
        exp_default_10 = torch.ops.aten.exp.default(mul_tensor_95);  mul_tensor_95 = None
        mul_tensor_96 = torch.ops.aten.mul.Tensor(exp_default_10, 0.3989422804014327);  exp_default_10 = None
        mul_tensor_97 = torch.ops.aten.mul.Tensor(to_dtype_31, mul_tensor_96);  to_dtype_31 = mul_tensor_96 = None
        add_tensor_86 = torch.ops.aten.add.Tensor(mul_tensor_93, mul_tensor_97);  mul_tensor_93 = mul_tensor_97 = None
        mul_tensor_98 = torch.ops.aten.mul.Tensor(to_dtype_30, add_tensor_86);  to_dtype_30 = add_tensor_86 = None
        to_dtype_32 = torch.ops.aten.to.dtype(mul_tensor_98, torch.float32);  mul_tensor_98 = None
        view_default_305 = torch.ops.aten.view.default(to_dtype_32, [1576, 1536]);  to_dtype_32 = None
        t_default_217 = torch.ops.aten.t.default(t_default_6);  t_default_6 = None
        mm_default_84 = torch.ops.aten.mm.default(view_default_305, t_default_217);  t_default_217 = None
        t_default_218 = torch.ops.aten.t.default(view_default_305)
        mm_default_85 = torch.ops.aten.mm.default(t_default_218, view_default_17);  t_default_218 = view_default_17 = None
        t_default_219 = torch.ops.aten.t.default(mm_default_85);  mm_default_85 = None
        sum_dim_int_list_42 = torch.ops.aten.sum.dim_IntList(view_default_305, [0], True);  view_default_305 = None
        view_default_306 = torch.ops.aten.view.default(sum_dim_int_list_42, [1536]);  sum_dim_int_list_42 = None
        t_default_220 = torch.ops.aten.t.default(t_default_219);  t_default_219 = None
        view_default_307 = torch.ops.aten.view.default(mm_default_84, [8, 197, 384]);  mm_default_84 = None
        native_layer_norm_backward_default_21 = torch.ops.aten.native_layer_norm_backward.default(view_default_307, add_tensor_3, [384], getitem_10, getitem_11, primals_48, primals_47, [True, True, True]);  view_default_307 = add_tensor_3 = getitem_10 = getitem_11 = primals_48 = primals_47 = None
        getitem_138 = native_layer_norm_backward_default_21[0]
        getitem_139 = native_layer_norm_backward_default_21[1]
        getitem_140 = native_layer_norm_backward_default_21[2];  native_layer_norm_backward_default_21 = None
        add_tensor_87 = torch.ops.aten.add.Tensor(add_tensor_84, getitem_138);  add_tensor_84 = getitem_138 = None
        view_default_308 = torch.ops.aten.view.default(add_tensor_87, [1576, 384])
        t_default_221 = torch.ops.aten.t.default(t_default_5);  t_default_5 = None
        mm_default_86 = torch.ops.aten.mm.default(view_default_308, t_default_221);  t_default_221 = None
        t_default_222 = torch.ops.aten.t.default(view_default_308)
        mm_default_87 = torch.ops.aten.mm.default(t_default_222, view_default_15);  t_default_222 = view_default_15 = None
        t_default_223 = torch.ops.aten.t.default(mm_default_87);  mm_default_87 = None
        sum_dim_int_list_43 = torch.ops.aten.sum.dim_IntList(view_default_308, [0], True);  view_default_308 = None
        view_default_309 = torch.ops.aten.view.default(sum_dim_int_list_43, [384]);  sum_dim_int_list_43 = None
        t_default_224 = torch.ops.aten.t.default(t_default_223);  t_default_223 = None
        view_default_310 = torch.ops.aten.view.default(mm_default_86, [8, 197, 384]);  mm_default_86 = None
        view_default_311 = torch.ops.aten.view.default(view_default_310, [8, 197, 6, 64]);  view_default_310 = None
        transpose_int_85 = torch.ops.aten.transpose.int(view_default_311, 1, 2);  view_default_311 = None
        clone_default_68 = torch.ops.aten.clone.default(transpose_int_85, memory_format = torch.contiguous_format);  transpose_int_85 = None
        _unsafe_view_default_92 = torch.ops.aten._unsafe_view.default(clone_default_68, [48, 197, 64]);  clone_default_68 = None
        transpose_int_86 = torch.ops.aten.transpose.int(view_default_14, 1, 2);  view_default_14 = None
        bmm_default_64 = torch.ops.aten.bmm.default(transpose_int_86, _unsafe_view_default_92);  transpose_int_86 = None
        transpose_int_87 = torch.ops.aten.transpose.int(_unsafe_view_default_9, 1, 2);  _unsafe_view_default_9 = None
        bmm_default_65 = torch.ops.aten.bmm.default(_unsafe_view_default_92, transpose_int_87);  _unsafe_view_default_92 = transpose_int_87 = None
        view_default_312 = torch.ops.aten.view.default(bmm_default_64, [8, 6, 197, 64]);  bmm_default_64 = None
        view_default_313 = torch.ops.aten.view.default(bmm_default_65, [8, 6, 197, 197]);  bmm_default_65 = None
        _softmax_backward_data_default_10 = torch.ops.aten._softmax_backward_data.default(view_default_313, _softmax_default_1, -1, torch.float32);  view_default_313 = _softmax_default_1 = None
        mul_tensor_99 = torch.ops.aten.mul.Tensor(_softmax_backward_data_default_10, 0.125);  _softmax_backward_data_default_10 = None
        view_default_314 = torch.ops.aten.view.default(mul_tensor_99, [48, 197, 197]);  mul_tensor_99 = None
        transpose_int_88 = torch.ops.aten.transpose.int(_unsafe_view_default_6, 1, 2);  _unsafe_view_default_6 = None
        bmm_default_66 = torch.ops.aten.bmm.default(transpose_int_88, view_default_314);  transpose_int_88 = None
        transpose_int_89 = torch.ops.aten.transpose.int(_unsafe_view_default_7, 1, 2);  _unsafe_view_default_7 = None
        bmm_default_67 = torch.ops.aten.bmm.default(view_default_314, transpose_int_89);  view_default_314 = transpose_int_89 = None
        view_default_315 = torch.ops.aten.view.default(bmm_default_66, [8, 6, 64, 197]);  bmm_default_66 = None
        view_default_316 = torch.ops.aten.view.default(bmm_default_67, [8, 6, 197, 64]);  bmm_default_67 = None
        transpose_int_90 = torch.ops.aten.transpose.int(view_default_315, -2, -1);  view_default_315 = None
        select_backward_default_31 = torch.ops.aten.select_backward.default(view_default_312, [3, 8, 6, 197, 64], 0, 2);  view_default_312 = None
        select_backward_default_32 = torch.ops.aten.select_backward.default(transpose_int_90, [3, 8, 6, 197, 64], 0, 1);  transpose_int_90 = None
        add_tensor_88 = torch.ops.aten.add.Tensor(select_backward_default_31, select_backward_default_32);  select_backward_default_31 = select_backward_default_32 = None
        select_backward_default_33 = torch.ops.aten.select_backward.default(view_default_316, [3, 8, 6, 197, 64], 0, 0);  view_default_316 = None
        add_tensor_89 = torch.ops.aten.add.Tensor(add_tensor_88, select_backward_default_33);  add_tensor_88 = select_backward_default_33 = None
        permute_default_22 = torch.ops.aten.permute.default(add_tensor_89, [1, 3, 0, 2, 4]);  add_tensor_89 = None
        clone_default_69 = torch.ops.aten.clone.default(permute_default_22, memory_format = torch.contiguous_format);  permute_default_22 = None
        _unsafe_view_default_93 = torch.ops.aten._unsafe_view.default(clone_default_69, [8, 197, 1152]);  clone_default_69 = None
        view_default_317 = torch.ops.aten.view.default(_unsafe_view_default_93, [1576, 1152]);  _unsafe_view_default_93 = None
        t_default_225 = torch.ops.aten.t.default(t_default_4);  t_default_4 = None
        mm_default_88 = torch.ops.aten.mm.default(view_default_317, t_default_225);  t_default_225 = None
        t_default_226 = torch.ops.aten.t.default(view_default_317)
        mm_default_89 = torch.ops.aten.mm.default(t_default_226, view_default_11);  t_default_226 = view_default_11 = None
        t_default_227 = torch.ops.aten.t.default(mm_default_89);  mm_default_89 = None
        sum_dim_int_list_44 = torch.ops.aten.sum.dim_IntList(view_default_317, [0], True);  view_default_317 = None
        view_default_318 = torch.ops.aten.view.default(sum_dim_int_list_44, [1152]);  sum_dim_int_list_44 = None
        t_default_228 = torch.ops.aten.t.default(t_default_227);  t_default_227 = None
        view_default_319 = torch.ops.aten.view.default(mm_default_88, [8, 197, 384]);  mm_default_88 = None
        native_layer_norm_backward_default_22 = torch.ops.aten.native_layer_norm_backward.default(view_default_319, add_tensor_2, [384], getitem_7, getitem_8, primals_46, primals_45, [True, True, True]);  view_default_319 = add_tensor_2 = getitem_7 = getitem_8 = primals_46 = primals_45 = None
        getitem_141 = native_layer_norm_backward_default_22[0]
        getitem_142 = native_layer_norm_backward_default_22[1]
        getitem_143 = native_layer_norm_backward_default_22[2];  native_layer_norm_backward_default_22 = None
        add_tensor_90 = torch.ops.aten.add.Tensor(add_tensor_87, getitem_141);  add_tensor_87 = getitem_141 = None
        view_default_320 = torch.ops.aten.view.default(add_tensor_90, [1576, 384])
        t_default_229 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        mm_default_90 = torch.ops.aten.mm.default(view_default_320, t_default_229);  t_default_229 = None
        t_default_230 = torch.ops.aten.t.default(view_default_320)
        mm_default_91 = torch.ops.aten.mm.default(t_default_230, view_default_9);  t_default_230 = view_default_9 = None
        t_default_231 = torch.ops.aten.t.default(mm_default_91);  mm_default_91 = None
        sum_dim_int_list_45 = torch.ops.aten.sum.dim_IntList(view_default_320, [0], True);  view_default_320 = None
        view_default_321 = torch.ops.aten.view.default(sum_dim_int_list_45, [384]);  sum_dim_int_list_45 = None
        t_default_232 = torch.ops.aten.t.default(t_default_231);  t_default_231 = None
        view_default_322 = torch.ops.aten.view.default(mm_default_90, [8, 197, 1536]);  mm_default_90 = None
        to_dtype_33 = torch.ops.aten.to.dtype(view_default_322, torch.float32);  view_default_322 = None
        to_dtype_34 = torch.ops.aten.to.dtype(view_default_8, torch.float32);  view_default_8 = None
        mul_tensor_100 = torch.ops.aten.mul.Tensor(to_dtype_34, 0.7071067811865476)
        erf_default_11 = torch.ops.aten.erf.default(mul_tensor_100);  mul_tensor_100 = None
        add_tensor_91 = torch.ops.aten.add.Tensor(erf_default_11, 1);  erf_default_11 = None
        mul_tensor_101 = torch.ops.aten.mul.Tensor(add_tensor_91, 0.5);  add_tensor_91 = None
        mul_tensor_102 = torch.ops.aten.mul.Tensor(to_dtype_34, to_dtype_34)
        mul_tensor_103 = torch.ops.aten.mul.Tensor(mul_tensor_102, -0.5);  mul_tensor_102 = None
        exp_default_11 = torch.ops.aten.exp.default(mul_tensor_103);  mul_tensor_103 = None
        mul_tensor_104 = torch.ops.aten.mul.Tensor(exp_default_11, 0.3989422804014327);  exp_default_11 = None
        mul_tensor_105 = torch.ops.aten.mul.Tensor(to_dtype_34, mul_tensor_104);  to_dtype_34 = mul_tensor_104 = None
        add_tensor_92 = torch.ops.aten.add.Tensor(mul_tensor_101, mul_tensor_105);  mul_tensor_101 = mul_tensor_105 = None
        mul_tensor_106 = torch.ops.aten.mul.Tensor(to_dtype_33, add_tensor_92);  to_dtype_33 = add_tensor_92 = None
        to_dtype_35 = torch.ops.aten.to.dtype(mul_tensor_106, torch.float32);  mul_tensor_106 = None
        view_default_323 = torch.ops.aten.view.default(to_dtype_35, [1576, 1536]);  to_dtype_35 = None
        t_default_233 = torch.ops.aten.t.default(t_default_2);  t_default_2 = None
        mm_default_92 = torch.ops.aten.mm.default(view_default_323, t_default_233);  t_default_233 = None
        t_default_234 = torch.ops.aten.t.default(view_default_323)
        mm_default_93 = torch.ops.aten.mm.default(t_default_234, view_default_7);  t_default_234 = view_default_7 = None
        t_default_235 = torch.ops.aten.t.default(mm_default_93);  mm_default_93 = None
        sum_dim_int_list_46 = torch.ops.aten.sum.dim_IntList(view_default_323, [0], True);  view_default_323 = None
        view_default_324 = torch.ops.aten.view.default(sum_dim_int_list_46, [1536]);  sum_dim_int_list_46 = None
        t_default_236 = torch.ops.aten.t.default(t_default_235);  t_default_235 = None
        view_default_325 = torch.ops.aten.view.default(mm_default_92, [8, 197, 384]);  mm_default_92 = None
        native_layer_norm_backward_default_23 = torch.ops.aten.native_layer_norm_backward.default(view_default_325, add_tensor_1, [384], getitem_4, getitem_5, primals_12, primals_11, [True, True, True]);  view_default_325 = add_tensor_1 = getitem_4 = getitem_5 = primals_12 = primals_11 = None
        getitem_144 = native_layer_norm_backward_default_23[0]
        getitem_145 = native_layer_norm_backward_default_23[1]
        getitem_146 = native_layer_norm_backward_default_23[2];  native_layer_norm_backward_default_23 = None
        add_tensor_93 = torch.ops.aten.add.Tensor(add_tensor_90, getitem_144);  add_tensor_90 = getitem_144 = None
        view_default_326 = torch.ops.aten.view.default(add_tensor_93, [1576, 384])
        t_default_237 = torch.ops.aten.t.default(t_default_1);  t_default_1 = None
        mm_default_94 = torch.ops.aten.mm.default(view_default_326, t_default_237);  t_default_237 = None
        t_default_238 = torch.ops.aten.t.default(view_default_326)
        mm_default_95 = torch.ops.aten.mm.default(t_default_238, view_default_5);  t_default_238 = view_default_5 = None
        t_default_239 = torch.ops.aten.t.default(mm_default_95);  mm_default_95 = None
        sum_dim_int_list_47 = torch.ops.aten.sum.dim_IntList(view_default_326, [0], True);  view_default_326 = None
        view_default_327 = torch.ops.aten.view.default(sum_dim_int_list_47, [384]);  sum_dim_int_list_47 = None
        t_default_240 = torch.ops.aten.t.default(t_default_239);  t_default_239 = None
        view_default_328 = torch.ops.aten.view.default(mm_default_94, [8, 197, 384]);  mm_default_94 = None
        view_default_329 = torch.ops.aten.view.default(view_default_328, [8, 197, 6, 64]);  view_default_328 = None
        transpose_int_91 = torch.ops.aten.transpose.int(view_default_329, 1, 2);  view_default_329 = None
        clone_default_70 = torch.ops.aten.clone.default(transpose_int_91, memory_format = torch.contiguous_format);  transpose_int_91 = None
        _unsafe_view_default_94 = torch.ops.aten._unsafe_view.default(clone_default_70, [48, 197, 64]);  clone_default_70 = None
        transpose_int_92 = torch.ops.aten.transpose.int(view_default_4, 1, 2);  view_default_4 = None
        bmm_default_68 = torch.ops.aten.bmm.default(transpose_int_92, _unsafe_view_default_94);  transpose_int_92 = None
        transpose_int_93 = torch.ops.aten.transpose.int(_unsafe_view_default_3, 1, 2);  _unsafe_view_default_3 = None
        bmm_default_69 = torch.ops.aten.bmm.default(_unsafe_view_default_94, transpose_int_93);  _unsafe_view_default_94 = transpose_int_93 = None
        view_default_330 = torch.ops.aten.view.default(bmm_default_68, [8, 6, 197, 64]);  bmm_default_68 = None
        view_default_331 = torch.ops.aten.view.default(bmm_default_69, [8, 6, 197, 197]);  bmm_default_69 = None
        _softmax_backward_data_default_11 = torch.ops.aten._softmax_backward_data.default(view_default_331, _softmax_default, -1, torch.float32);  view_default_331 = _softmax_default = None
        mul_tensor_107 = torch.ops.aten.mul.Tensor(_softmax_backward_data_default_11, 0.125);  _softmax_backward_data_default_11 = None
        view_default_332 = torch.ops.aten.view.default(mul_tensor_107, [48, 197, 197]);  mul_tensor_107 = None
        transpose_int_94 = torch.ops.aten.transpose.int(_unsafe_view_default, 1, 2);  _unsafe_view_default = None
        bmm_default_70 = torch.ops.aten.bmm.default(transpose_int_94, view_default_332);  transpose_int_94 = None
        transpose_int_95 = torch.ops.aten.transpose.int(_unsafe_view_default_1, 1, 2);  _unsafe_view_default_1 = None
        bmm_default_71 = torch.ops.aten.bmm.default(view_default_332, transpose_int_95);  view_default_332 = transpose_int_95 = None
        view_default_333 = torch.ops.aten.view.default(bmm_default_70, [8, 6, 64, 197]);  bmm_default_70 = None
        view_default_334 = torch.ops.aten.view.default(bmm_default_71, [8, 6, 197, 64]);  bmm_default_71 = None
        transpose_int_96 = torch.ops.aten.transpose.int(view_default_333, -2, -1);  view_default_333 = None
        select_backward_default_34 = torch.ops.aten.select_backward.default(view_default_330, [3, 8, 6, 197, 64], 0, 2);  view_default_330 = None
        select_backward_default_35 = torch.ops.aten.select_backward.default(transpose_int_96, [3, 8, 6, 197, 64], 0, 1);  transpose_int_96 = None
        add_tensor_94 = torch.ops.aten.add.Tensor(select_backward_default_34, select_backward_default_35);  select_backward_default_34 = select_backward_default_35 = None
        select_backward_default_36 = torch.ops.aten.select_backward.default(view_default_334, [3, 8, 6, 197, 64], 0, 0);  view_default_334 = None
        add_tensor_95 = torch.ops.aten.add.Tensor(add_tensor_94, select_backward_default_36);  add_tensor_94 = select_backward_default_36 = None
        permute_default_23 = torch.ops.aten.permute.default(add_tensor_95, [1, 3, 0, 2, 4]);  add_tensor_95 = None
        clone_default_71 = torch.ops.aten.clone.default(permute_default_23, memory_format = torch.contiguous_format);  permute_default_23 = None
        _unsafe_view_default_95 = torch.ops.aten._unsafe_view.default(clone_default_71, [8, 197, 1152]);  clone_default_71 = None
        view_default_335 = torch.ops.aten.view.default(_unsafe_view_default_95, [1576, 1152]);  _unsafe_view_default_95 = None
        t_default_241 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default_96 = torch.ops.aten.mm.default(view_default_335, t_default_241);  t_default_241 = None
        t_default_242 = torch.ops.aten.t.default(view_default_335)
        mm_default_97 = torch.ops.aten.mm.default(t_default_242, view_default_1);  t_default_242 = view_default_1 = None
        t_default_243 = torch.ops.aten.t.default(mm_default_97);  mm_default_97 = None
        sum_dim_int_list_48 = torch.ops.aten.sum.dim_IntList(view_default_335, [0], True);  view_default_335 = None
        view_default_336 = torch.ops.aten.view.default(sum_dim_int_list_48, [1152]);  sum_dim_int_list_48 = None
        t_default_244 = torch.ops.aten.t.default(t_default_243);  t_default_243 = None
        view_default_337 = torch.ops.aten.view.default(mm_default_96, [8, 197, 384]);  mm_default_96 = None
        native_layer_norm_backward_default_24 = torch.ops.aten.native_layer_norm_backward.default(view_default_337, add_tensor, [384], getitem_1, getitem_2, primals_10, primals_9, [True, True, True]);  view_default_337 = add_tensor = getitem_1 = getitem_2 = primals_10 = primals_9 = None
        getitem_147 = native_layer_norm_backward_default_24[0]
        getitem_148 = native_layer_norm_backward_default_24[1]
        getitem_149 = native_layer_norm_backward_default_24[2];  native_layer_norm_backward_default_24 = None
        add_tensor_96 = torch.ops.aten.add.Tensor(add_tensor_93, getitem_147);  add_tensor_93 = getitem_147 = None
        sum_dim_int_list_49 = torch.ops.aten.sum.dim_IntList(add_tensor_96, [0], True)
        slice_tensor_1 = torch.ops.aten.slice.Tensor(add_tensor_96, 1, 0, 1)
        slice_tensor_2 = torch.ops.aten.slice.Tensor(add_tensor_96, 1, 1, 197);  add_tensor_96 = None
        sum_dim_int_list_50 = torch.ops.aten.sum.dim_IntList(slice_tensor_1, [0], True);  slice_tensor_1 = None
        transpose_int_97 = torch.ops.aten.transpose.int(slice_tensor_2, 1, 2);  slice_tensor_2 = None
        view_default_338 = torch.ops.aten.view.default(transpose_int_97, [8, 384, 14, 14]);  transpose_int_97 = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(view_default_338, primals_153, primals_151, [384], [16, 16], [0, 0], [1, 1], False, [0, 0], 1, [False, True, True]);  view_default_338 = primals_153 = primals_151 = None
        getitem_150 = convolution_backward_default[0]
        getitem_151 = convolution_backward_default[1]
        getitem_152 = convolution_backward_default[2];  convolution_backward_default = None
        return [addmm_default_48, view_default_327, t_default_240, view_default_336, t_default_244, view_default_324, t_default_236, view_default_321, t_default_232, getitem_149, getitem_148, getitem_146, getitem_145, view_default_147, t_default_80, view_default_156, t_default_84, view_default_144, t_default_76, view_default_141, t_default_72, getitem_89, getitem_88, getitem_86, getitem_85, view_default_129, t_default_64, view_default_138, t_default_68, view_default_126, t_default_60, view_default_123, t_default_56, getitem_83, getitem_82, getitem_80, getitem_79, view_default_309, t_default_224, view_default_318, t_default_228, view_default_306, t_default_220, view_default_303, t_default_216, getitem_143, getitem_142, getitem_140, getitem_139, view_default_291, t_default_208, view_default_300, t_default_212, view_default_288, t_default_204, view_default_285, t_default_200, getitem_137, getitem_136, getitem_134, getitem_133, view_default_273, t_default_192, view_default_282, t_default_196, view_default_270, t_default_188, view_default_267, t_default_184, getitem_131, getitem_130, getitem_128, getitem_127, view_default_255, t_default_176, view_default_264, t_default_180, view_default_252, t_default_172, view_default_249, t_default_168, getitem_125, getitem_124, getitem_122, getitem_121, view_default_237, t_default_160, view_default_246, t_default_164, view_default_234, t_default_156, view_default_231, t_default_152, getitem_119, getitem_118, getitem_116, getitem_115, view_default_219, t_default_144, view_default_228, t_default_148, view_default_216, t_default_140, view_default_213, t_default_136, getitem_113, getitem_112, getitem_110, getitem_109, view_default_201, t_default_128, view_default_210, t_default_132, view_default_198, t_default_124, view_default_195, t_default_120, getitem_107, getitem_106, getitem_104, getitem_103, view_default_183, t_default_112, view_default_192, t_default_116, view_default_180, t_default_108, view_default_177, t_default_104, getitem_101, getitem_100, getitem_98, getitem_97, view_default_165, t_default_96, view_default_174, t_default_100, view_default_162, t_default_92, view_default_159, t_default_88, getitem_95, getitem_94, getitem_92, getitem_91, sum_dim_int_list_50, view_default_121, t_default_52, getitem_77, getitem_76, getitem_152, getitem_151, sum_dim_int_list_49, None]
        
