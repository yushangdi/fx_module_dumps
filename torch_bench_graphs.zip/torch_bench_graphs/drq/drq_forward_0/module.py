
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/drq/drq_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19):
        div_tensor = torch.ops.aten.div.Tensor(primals_19, 255.0);  primals_19 = None
        convolution_default = torch.ops.aten.convolution.default(div_tensor, primals_12, primals_11, [2, 2], [0, 0], [1, 1], False, [0, 0], 1);  primals_11 = None
        relu_default = torch.ops.aten.relu.default(convolution_default);  convolution_default = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu_default, primals_14, primals_13, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_13 = None
        relu_default_1 = torch.ops.aten.relu.default(convolution_default_1);  convolution_default_1 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu_default_1, primals_16, primals_15, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_15 = None
        relu_default_2 = torch.ops.aten.relu.default(convolution_default_2);  convolution_default_2 = None
        convolution_default_3 = torch.ops.aten.convolution.default(relu_default_2, primals_18, primals_17, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_17 = None
        relu_default_3 = torch.ops.aten.relu.default(convolution_default_3);  convolution_default_3 = None
        view_default = torch.ops.aten.view.default(relu_default_3, [1, -1])
        t_default = torch.ops.aten.t.default(primals_2);  primals_2 = None
        addmm_default = torch.ops.aten.addmm.default(primals_1, view_default, t_default);  primals_1 = None
        native_layer_norm_default = torch.ops.aten.native_layer_norm.default(addmm_default, [50], primals_4, primals_3, 1e-05)
        getitem = native_layer_norm_default[0]
        getitem_1 = native_layer_norm_default[1]
        getitem_2 = native_layer_norm_default[2];  native_layer_norm_default = None
        tanh_default = torch.ops.aten.tanh.default(getitem);  getitem = None
        t_default_1 = torch.ops.aten.t.default(primals_6);  primals_6 = None
        addmm_default_1 = torch.ops.aten.addmm.default(primals_5, tanh_default, t_default_1);  primals_5 = None
        relu__default = torch.ops.aten.relu_.default(addmm_default_1);  addmm_default_1 = None
        t_default_2 = torch.ops.aten.t.default(primals_8);  primals_8 = None
        addmm_default_2 = torch.ops.aten.addmm.default(primals_7, relu__default, t_default_2);  primals_7 = None
        relu__default_1 = torch.ops.aten.relu_.default(addmm_default_2);  addmm_default_2 = None
        t_default_3 = torch.ops.aten.t.default(primals_10);  primals_10 = None
        addmm_default_3 = torch.ops.aten.addmm.default(primals_9, relu__default_1, t_default_3);  primals_9 = None
        split_tensor = torch.ops.aten.split.Tensor(addmm_default_3, 1, -1);  addmm_default_3 = None
        getitem_3 = split_tensor[0]
        getitem_4 = split_tensor[1];  split_tensor = None
        tanh_default_1 = torch.ops.aten.tanh.default(getitem_4);  getitem_4 = None
        add_tensor = torch.ops.aten.add.Tensor(tanh_default_1, 1)
        mul_tensor = torch.ops.aten.mul.Tensor(add_tensor, 6.0);  add_tensor = None
        add_tensor_1 = torch.ops.aten.add.Tensor(mul_tensor, -10);  mul_tensor = None
        exp_default = torch.ops.aten.exp.default(add_tensor_1);  add_tensor_1 = None
        return [div_tensor, relu_default, relu_default_1, relu_default_2, relu_default_3, tanh_default, getitem_3, exp_default, getitem_3, exp_default, primals_3, t_default_2, primals_4, t_default_3, tanh_default_1, div_tensor, relu_default_1, t_default_1, primals_18, relu_default_2, addmm_default, relu_default_3, relu_default, primals_16, relu__default_1, exp_default, getitem_2, view_default, t_default, primals_14, getitem_1, primals_12, tanh_default, relu__default]
        
