
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/drq/drq_backward_0/state_dict.pt'))

    
    
    def forward(self, primals_3, t_default_2, primals_4, t_default_3, tanh_default_1, div_tensor, relu_default_1, t_default_1, primals_18, relu_default_2, addmm_default, relu_default_3, relu_default, primals_16, relu__default_1, exp_default, getitem_2, view_default, t_default, primals_14, getitem_1, primals_12, tanh_default, relu__default, tangents_1, tangents_2, tangents_3, tangents_4, tangents_5, tangents_6, tangents_7, tangents_8, tangents_9, tangents_10):
        add_tensor_2 = torch.ops.aten.add.Tensor(tangents_7, tangents_9);  tangents_7 = tangents_9 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(tangents_8, tangents_10);  tangents_8 = tangents_10 = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(add_tensor_3, exp_default);  add_tensor_3 = exp_default = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(mul_tensor_1, 6.0);  mul_tensor_1 = None
        to_dtype = torch.ops.aten.to.dtype(mul_tensor_2, torch.float32);  mul_tensor_2 = None
        to_dtype_1 = torch.ops.aten.to.dtype(tanh_default_1, torch.float32);  tanh_default_1 = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(to_dtype_1, to_dtype_1);  to_dtype_1 = None
        rsub_scalar = torch.ops.aten.rsub.Scalar(mul_tensor_3, 1);  mul_tensor_3 = None
        conj_physical_default = torch.ops.aten.conj_physical.default(rsub_scalar);  rsub_scalar = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(to_dtype, conj_physical_default);  to_dtype = conj_physical_default = None
        to_dtype_2 = torch.ops.aten.to.dtype(mul_tensor_4, torch.float32);  mul_tensor_4 = None
        cat_default = torch.ops.aten.cat.default([add_tensor_2, to_dtype_2], 1);  add_tensor_2 = to_dtype_2 = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        mm_default = torch.ops.aten.mm.default(cat_default, t_default_4);  t_default_4 = None
        t_default_5 = torch.ops.aten.t.default(cat_default)
        mm_default_1 = torch.ops.aten.mm.default(t_default_5, relu__default_1);  t_default_5 = None
        t_default_6 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(cat_default, [0], True);  cat_default = None
        view_default_1 = torch.ops.aten.view.default(sum_dim_int_list, [2]);  sum_dim_int_list = None
        t_default_7 = torch.ops.aten.t.default(t_default_6);  t_default_6 = None
        to_dtype_3 = torch.ops.aten.to.dtype(mm_default, torch.float32);  mm_default = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default, to_dtype_3);  le_scalar = new_zeros_default = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        t_default_8 = torch.ops.aten.t.default(t_default_2);  t_default_2 = None
        mm_default_2 = torch.ops.aten.mm.default(to_dtype_5, t_default_8);  t_default_8 = None
        t_default_9 = torch.ops.aten.t.default(to_dtype_5)
        mm_default_3 = torch.ops.aten.mm.default(t_default_9, relu__default);  t_default_9 = None
        t_default_10 = torch.ops.aten.t.default(mm_default_3);  mm_default_3 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(to_dtype_5, [0], True);  to_dtype_5 = None
        view_default_2 = torch.ops.aten.view.default(sum_dim_int_list_1, [1024]);  sum_dim_int_list_1 = None
        t_default_11 = torch.ops.aten.t.default(t_default_10);  t_default_10 = None
        to_dtype_6 = torch.ops.aten.to.dtype(mm_default_2, torch.float32);  mm_default_2 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_1, to_dtype_6);  le_scalar_1 = new_zeros_default_1 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        t_default_12 = torch.ops.aten.t.default(t_default_1);  t_default_1 = None
        mm_default_4 = torch.ops.aten.mm.default(to_dtype_8, t_default_12);  t_default_12 = None
        t_default_13 = torch.ops.aten.t.default(to_dtype_8)
        mm_default_5 = torch.ops.aten.mm.default(t_default_13, tanh_default);  t_default_13 = None
        t_default_14 = torch.ops.aten.t.default(mm_default_5);  mm_default_5 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(to_dtype_8, [0], True);  to_dtype_8 = None
        view_default_3 = torch.ops.aten.view.default(sum_dim_int_list_2, [1024]);  sum_dim_int_list_2 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(tangents_6, mm_default_4);  tangents_6 = mm_default_4 = None
        t_default_15 = torch.ops.aten.t.default(t_default_14);  t_default_14 = None
        to_dtype_9 = torch.ops.aten.to.dtype(add_tensor_4, torch.float32);  add_tensor_4 = None
        to_dtype_10 = torch.ops.aten.to.dtype(tanh_default, torch.float32);  tanh_default = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(to_dtype_10, to_dtype_10);  to_dtype_10 = None
        rsub_scalar_1 = torch.ops.aten.rsub.Scalar(mul_tensor_5, 1);  mul_tensor_5 = None
        conj_physical_default_1 = torch.ops.aten.conj_physical.default(rsub_scalar_1);  rsub_scalar_1 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(to_dtype_9, conj_physical_default_1);  to_dtype_9 = conj_physical_default_1 = None
        to_dtype_11 = torch.ops.aten.to.dtype(mul_tensor_6, torch.float32);  mul_tensor_6 = None
        native_layer_norm_backward_default = torch.ops.aten.native_layer_norm_backward.default(to_dtype_11, addmm_default, [50], getitem_1, getitem_2, primals_4, primals_3, [True, True, True]);  to_dtype_11 = addmm_default = getitem_1 = getitem_2 = primals_4 = primals_3 = None
        getitem_5 = native_layer_norm_backward_default[0]
        getitem_6 = native_layer_norm_backward_default[1]
        getitem_7 = native_layer_norm_backward_default[2];  native_layer_norm_backward_default = None
        t_default_16 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default_6 = torch.ops.aten.mm.default(getitem_5, t_default_16);  t_default_16 = None
        t_default_17 = torch.ops.aten.t.default(getitem_5)
        mm_default_7 = torch.ops.aten.mm.default(t_default_17, view_default);  t_default_17 = view_default = None
        t_default_18 = torch.ops.aten.t.default(mm_default_7);  mm_default_7 = None
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(getitem_5, [0], True);  getitem_5 = None
        view_default_4 = torch.ops.aten.view.default(sum_dim_int_list_3, [50]);  sum_dim_int_list_3 = None
        t_default_19 = torch.ops.aten.t.default(t_default_18);  t_default_18 = None
        view_default_5 = torch.ops.aten.view.default(mm_default_6, [1, 32, 35, 35]);  mm_default_6 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(tangents_5, view_default_5);  tangents_5 = view_default_5 = None
        to_dtype_12 = torch.ops.aten.to.dtype(add_tensor_5, torch.float32);  add_tensor_5 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu_default_3, torch.float32);  relu_default_3 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_2 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_2, to_dtype_12);  le_scalar_2 = new_zeros_default_2 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(to_dtype_14, relu_default_2, primals_18, [32], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_14 = primals_18 = None
        getitem_8 = convolution_backward_default[0]
        getitem_9 = convolution_backward_default[1]
        getitem_10 = convolution_backward_default[2];  convolution_backward_default = None
        add_tensor_6 = torch.ops.aten.add.Tensor(tangents_4, getitem_8);  tangents_4 = getitem_8 = None
        to_dtype_15 = torch.ops.aten.to.dtype(add_tensor_6, torch.float32);  add_tensor_6 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu_default_2, torch.float32);  relu_default_2 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_3, to_dtype_15);  le_scalar_3 = new_zeros_default_3 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(to_dtype_17, relu_default_1, primals_16, [32], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_17 = primals_16 = None
        getitem_11 = convolution_backward_default_1[0]
        getitem_12 = convolution_backward_default_1[1]
        getitem_13 = convolution_backward_default_1[2];  convolution_backward_default_1 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(tangents_3, getitem_11);  tangents_3 = getitem_11 = None
        to_dtype_18 = torch.ops.aten.to.dtype(add_tensor_7, torch.float32);  add_tensor_7 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu_default_1, torch.float32);  relu_default_1 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_4, to_dtype_18);  le_scalar_4 = new_zeros_default_4 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(to_dtype_20, relu_default, primals_14, [32], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_20 = primals_14 = None
        getitem_14 = convolution_backward_default_2[0]
        getitem_15 = convolution_backward_default_2[1]
        getitem_16 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(tangents_2, getitem_14);  tangents_2 = getitem_14 = None
        to_dtype_21 = torch.ops.aten.to.dtype(add_tensor_8, torch.float32);  add_tensor_8 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu_default, torch.float32);  relu_default = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_5 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_5, to_dtype_21);  le_scalar_5 = new_zeros_default_5 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(to_dtype_23, div_tensor, primals_12, [32], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [False, True, True]);  to_dtype_23 = div_tensor = primals_12 = None
        getitem_18 = convolution_backward_default_3[1]
        getitem_19 = convolution_backward_default_3[2];  convolution_backward_default_3 = None
        return [view_default_4, t_default_19, getitem_7, getitem_6, view_default_3, t_default_15, view_default_2, t_default_11, view_default_1, t_default_7, getitem_19, getitem_18, getitem_16, getitem_15, getitem_13, getitem_12, getitem_10, getitem_9, None]
        
