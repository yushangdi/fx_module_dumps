
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/shufflenet_v2_x1_0/shufflenet_v2_x1_0_backward_0/state_dict.pt'))

    
    
    def forward(self, primals_93, primals_156, relu__default_16, relu__default_31, primals_157, convolution_default_26, primals_158, primals_96, primals_159, primals_97, primals_98, getitem_91, primals_99, primals_162, primals_163, primals_164, primals_102, primals_165, primals_103, primals_104, getitem_95, primals_105, primals_168, relu__default_17, primals_169, convolution_default_27, primals_170, convolution_default_49, getitem_172, primals_108, primals_171, primals_109, relu__default_32, primals_110, primals_111, primals_174, primals_175, convolution_default_50, primals_176, relu__default_10, primals_198, primals_261, convolution_default_17, primals_199, relu__default_25, getitem_43, convolution_default_39, primals_200, primals_338, convolution_default_12, primals_201, primals_264, convolution_default_46, primals_265, primals_333, primals_266, primals_339, primals_204, primals_267, primals_205, primals_206, getitem_161, relu__default_8, getitem_139, primals_207, primals_270, relu__default_11, primals_271, convolution_default_13, convolution_default_40, convolution_default_18, relu__default_30, primals_272, primals_210, primals_273, convolution_default_47, primals_211, primals_212, getitem_47, primals_213, primals_276, getitem_62, primals_277, convolution_default_14, convolution_default_19, primals_278, relu__default_26, primals_216, primals_279, convolution_default_48, primals_217, getitem_165, primals_218, primals_135, getitem_113, primals_27, relu__default_35, relu__default_21, primals_32, relu__default_5, convolution_default_33, convolution_default_8, primals_18, primals_138, mean_dim, primals_139, primals_20, primals_140, primals_141, convolution_default_55, convolution_default_34, getitem_25, view_default_31, primals_144, primals_33, primals_21, primals_145, getitem_117, primals_146, primals_31, relu__default_36, primals_147, t_default, primals_19, primals_25, primals_24, primals_26, primals_150, primals_151, primals_30, primals_152, primals_153, convolution_default_9, getitem_32, primals_313, convolution_default_37, primals_6, primals_318, getitem_128, getitem_84, convolution_default_51, getitem_80, relu__default_24, primals_306, primals_315, relu__default_15, primals_300, primals_314, primals_7, primals_302, relu__default_33, primals_10, primals_11, convolution_default_24, primals_5, primals_4, getitem_176, primals_12, primals_301, convolution_default_25, primals_303, primals_1, primals_308, primals_307, convolution_default_52, primals_312, primals_15, convolution_default_38, getitem_135, primals_309, primals_240, getitem_154, relu__default_19, convolution_default_30, primals_61, primals_241, primals_331, primals_66, primals_242, getitem_183, getitem_106, primals_243, primals_68, primals_60, primals_69, primals_246, convolution_default_54, primals_247, convolution_default_44, primals_67, relu__default_28, primals_248, primals_321, primals_62, primals_249, getitem_187, primals_324, convolution_default_53, primals_72, relu__default_34, convolution_default_45, primals_252, convolution_default_31, primals_320, primals_253, primals_254, primals_255, primals_327, primals_56, primals_325, primals_63, primals_319, relu__default_29, convolution_default_32, primals_258, convolution_default, primals_57, primals_259, primals_332, primals_326, relu__default_20, primals_260, primals_330, primals_297, primals_289, primals_114, primals_177, primals_51, relu__default_18, relu__default, primals_115, primals_50, convolution_default_28, primals_116, primals_295, getitem_5, primals_49, primals_117, primals_180, primals_87, getitem_4, primals_86, primals_48, primals_181, getitem_3, primals_182, primals_282, primals_85, primals_75, primals_120, primals_183, primals_121, primals_36, primals_84, primals_122, primals_92, primals_294, primals_73, primals_123, primals_186, primals_79, primals_296, convolution_default_1, primals_54, primals_91, primals_187, primals_337, convolution_default_3, primals_55, primals_74, primals_37, primals_188, convolution_default_2, primals_283, primals_126, primals_189, primals_38, relu__default_1, primals_127, primals_44, primals_290, primals_336, primals_81, primals_45, primals_128, primals_43, primals_80, primals_291, primals_129, primals_192, primals_284, primals_90, primals_285, primals_42, primals_193, getitem_102, convolution_default_29, primals_194, primals_132, primals_195, primals_39, primals_133, primals_134, primals_288, primals_78, relu__default_3, relu__default_2, convolution_default_22, convolution_default_4, relu__default_6, convolution_default_10, relu__default_9, relu__default_12, getitem_36, relu__default_14, convolution_default_5, relu__default_4, convolution_default_11, getitem_14, getitem_73, getitem_21, convolution_default_15, getitem_53, convolution_default_6, view_default_7, convolution_default_16, convolution_default_20, getitem_69, relu__default_7, relu__default_13, convolution_default_21, convolution_default_7, convolution_default_23, relu__default_22, primals_219, primals_222, getitem_145, convolution_default_41, primals_223, primals_224, primals_225, convolution_default_42, convolution_default_35, view_default_23, primals_228, primals_229, relu__default_23, getitem_124, primals_230, primals_231, relu__default_27, primals_234, convolution_default_43, primals_235, convolution_default_36, primals_236, primals_237, tangents_1):
        new_zeros_default = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_9 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_10 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_12 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_13 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_15 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_16 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_18 = torch.ops.aten.new_zeros.default(convolution_default_6, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_19 = torch.ops.aten.new_zeros.default(convolution_default_6, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_21 = torch.ops.aten.new_zeros.default(convolution_default_7, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_22 = torch.ops.aten.new_zeros.default(convolution_default_7, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_24 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_25 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_27 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_28 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_30 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_31 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_33 = torch.ops.aten.new_zeros.default(convolution_default_11, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_34 = torch.ops.aten.new_zeros.default(convolution_default_11, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_36 = torch.ops.aten.new_zeros.default(convolution_default_12, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_37 = torch.ops.aten.new_zeros.default(convolution_default_12, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_39 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_40 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_42 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_43 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_45 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_46 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_48 = torch.ops.aten.new_zeros.default(convolution_default_16, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_49 = torch.ops.aten.new_zeros.default(convolution_default_16, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_51 = torch.ops.aten.new_zeros.default(convolution_default_17, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_52 = torch.ops.aten.new_zeros.default(convolution_default_17, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_54 = torch.ops.aten.new_zeros.default(convolution_default_18, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_55 = torch.ops.aten.new_zeros.default(convolution_default_18, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_57 = torch.ops.aten.new_zeros.default(convolution_default_19, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_58 = torch.ops.aten.new_zeros.default(convolution_default_19, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_60 = torch.ops.aten.new_zeros.default(convolution_default_20, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_61 = torch.ops.aten.new_zeros.default(convolution_default_20, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_63 = torch.ops.aten.new_zeros.default(convolution_default_21, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_64 = torch.ops.aten.new_zeros.default(convolution_default_21, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_66 = torch.ops.aten.new_zeros.default(convolution_default_22, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_67 = torch.ops.aten.new_zeros.default(convolution_default_22, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_69 = torch.ops.aten.new_zeros.default(convolution_default_23, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_70 = torch.ops.aten.new_zeros.default(convolution_default_23, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_72 = torch.ops.aten.new_zeros.default(convolution_default_24, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_73 = torch.ops.aten.new_zeros.default(convolution_default_24, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_75 = torch.ops.aten.new_zeros.default(convolution_default_25, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_76 = torch.ops.aten.new_zeros.default(convolution_default_25, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_78 = torch.ops.aten.new_zeros.default(convolution_default_26, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_79 = torch.ops.aten.new_zeros.default(convolution_default_26, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_81 = torch.ops.aten.new_zeros.default(convolution_default_27, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_82 = torch.ops.aten.new_zeros.default(convolution_default_27, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_84 = torch.ops.aten.new_zeros.default(convolution_default_28, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_85 = torch.ops.aten.new_zeros.default(convolution_default_28, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_87 = torch.ops.aten.new_zeros.default(convolution_default_29, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_88 = torch.ops.aten.new_zeros.default(convolution_default_29, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_90 = torch.ops.aten.new_zeros.default(convolution_default_30, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_91 = torch.ops.aten.new_zeros.default(convolution_default_30, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_93 = torch.ops.aten.new_zeros.default(convolution_default_31, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_94 = torch.ops.aten.new_zeros.default(convolution_default_31, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_96 = torch.ops.aten.new_zeros.default(convolution_default_32, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_97 = torch.ops.aten.new_zeros.default(convolution_default_32, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_99 = torch.ops.aten.new_zeros.default(convolution_default_33, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_100 = torch.ops.aten.new_zeros.default(convolution_default_33, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_102 = torch.ops.aten.new_zeros.default(convolution_default_34, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_103 = torch.ops.aten.new_zeros.default(convolution_default_34, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_105 = torch.ops.aten.new_zeros.default(convolution_default_35, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_106 = torch.ops.aten.new_zeros.default(convolution_default_35, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_108 = torch.ops.aten.new_zeros.default(convolution_default_36, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_109 = torch.ops.aten.new_zeros.default(convolution_default_36, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_111 = torch.ops.aten.new_zeros.default(convolution_default_37, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_112 = torch.ops.aten.new_zeros.default(convolution_default_37, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_114 = torch.ops.aten.new_zeros.default(convolution_default_38, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_115 = torch.ops.aten.new_zeros.default(convolution_default_38, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_117 = torch.ops.aten.new_zeros.default(convolution_default_39, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_118 = torch.ops.aten.new_zeros.default(convolution_default_39, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_120 = torch.ops.aten.new_zeros.default(convolution_default_40, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_121 = torch.ops.aten.new_zeros.default(convolution_default_40, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_123 = torch.ops.aten.new_zeros.default(convolution_default_41, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_124 = torch.ops.aten.new_zeros.default(convolution_default_41, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_126 = torch.ops.aten.new_zeros.default(convolution_default_42, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_127 = torch.ops.aten.new_zeros.default(convolution_default_42, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_129 = torch.ops.aten.new_zeros.default(convolution_default_43, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_130 = torch.ops.aten.new_zeros.default(convolution_default_43, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_132 = torch.ops.aten.new_zeros.default(convolution_default_44, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_133 = torch.ops.aten.new_zeros.default(convolution_default_44, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_135 = torch.ops.aten.new_zeros.default(convolution_default_45, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_136 = torch.ops.aten.new_zeros.default(convolution_default_45, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_138 = torch.ops.aten.new_zeros.default(convolution_default_46, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_139 = torch.ops.aten.new_zeros.default(convolution_default_46, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_141 = torch.ops.aten.new_zeros.default(convolution_default_47, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_142 = torch.ops.aten.new_zeros.default(convolution_default_47, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_144 = torch.ops.aten.new_zeros.default(convolution_default_48, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_145 = torch.ops.aten.new_zeros.default(convolution_default_48, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_147 = torch.ops.aten.new_zeros.default(convolution_default_49, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_148 = torch.ops.aten.new_zeros.default(convolution_default_49, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_150 = torch.ops.aten.new_zeros.default(convolution_default_50, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_151 = torch.ops.aten.new_zeros.default(convolution_default_50, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_153 = torch.ops.aten.new_zeros.default(convolution_default_51, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_154 = torch.ops.aten.new_zeros.default(convolution_default_51, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_156 = torch.ops.aten.new_zeros.default(convolution_default_52, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_157 = torch.ops.aten.new_zeros.default(convolution_default_52, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_159 = torch.ops.aten.new_zeros.default(convolution_default_53, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_160 = torch.ops.aten.new_zeros.default(convolution_default_53, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_162 = torch.ops.aten.new_zeros.default(convolution_default_54, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_163 = torch.ops.aten.new_zeros.default(convolution_default_54, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_165 = torch.ops.aten.new_zeros.default(convolution_default_55, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_166 = torch.ops.aten.new_zeros.default(convolution_default_55, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, mean_dim);  t_default_2 = mean_dim = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_32 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        unsqueeze_default = torch.ops.aten.unsqueeze.default(mm_default, 2);  mm_default = None
        unsqueeze_default_1 = torch.ops.aten.unsqueeze.default(unsqueeze_default, 3);  unsqueeze_default = None
        expand_default = torch.ops.aten.expand.default(unsqueeze_default_1, [128, 1024, 7, 7]);  unsqueeze_default_1 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 49);  expand_default = None
        to_dtype = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default_36, torch.float32);  relu__default_36 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default_168 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_168, to_dtype);  le_scalar = new_zeros_default_168 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_2, convolution_default_55, primals_12, primals_10, primals_11, new_zeros_default_165, new_zeros_default_166, False, 1e-05, [True, True, True]);  to_dtype_2 = convolution_default_55 = primals_12 = primals_10 = primals_11 = new_zeros_default_165 = new_zeros_default_166 = None
        getitem_196 = native_batch_norm_backward_default[0]
        getitem_197 = native_batch_norm_backward_default[1]
        getitem_198 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(getitem_196, view_default_31, primals_7, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_196 = view_default_31 = primals_7 = None
        getitem_199 = convolution_backward_default[0]
        getitem_200 = convolution_backward_default[1];  convolution_backward_default = None
        view_default_33 = torch.ops.aten.view.default(getitem_199, [128, 232, 2, 7, 7]);  getitem_199 = None
        transpose_int_16 = torch.ops.aten.transpose.int(view_default_33, 1, 2);  view_default_33 = None
        clone_default_16 = torch.ops.aten.clone.default(transpose_int_16, memory_format = torch.contiguous_format);  transpose_int_16 = None
        _unsafe_view_default = torch.ops.aten._unsafe_view.default(clone_default_16, [128, 464, 7, 7]);  clone_default_16 = None
        slice_tensor = torch.ops.aten.slice.Tensor(_unsafe_view_default, 1, 0, 232)
        slice_tensor_1 = torch.ops.aten.slice.Tensor(_unsafe_view_default, 1, 232, 464);  _unsafe_view_default = None
        to_dtype_3 = torch.ops.aten.to.dtype(slice_tensor_1, torch.float32);  slice_tensor_1 = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu__default_35, torch.float32);  relu__default_35 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_169 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_169, to_dtype_3);  le_scalar_1 = new_zeros_default_169 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_5, convolution_default_54, primals_338, primals_336, primals_337, new_zeros_default_162, new_zeros_default_163, False, 1e-05, [True, True, True]);  to_dtype_5 = convolution_default_54 = primals_338 = primals_336 = primals_337 = new_zeros_default_162 = new_zeros_default_163 = None
        getitem_202 = native_batch_norm_backward_default_1[0]
        getitem_203 = native_batch_norm_backward_default_1[1]
        getitem_204 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_202, getitem_187, primals_333, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_202 = getitem_187 = primals_333 = None
        getitem_205 = convolution_backward_default_1[0]
        getitem_206 = convolution_backward_default_1[1];  convolution_backward_default_1 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(getitem_205, convolution_default_53, primals_332, primals_330, primals_331, new_zeros_default_159, new_zeros_default_160, False, 1e-05, [True, True, True]);  getitem_205 = convolution_default_53 = primals_332 = primals_330 = primals_331 = new_zeros_default_159 = new_zeros_default_160 = None
        getitem_208 = native_batch_norm_backward_default_2[0]
        getitem_209 = native_batch_norm_backward_default_2[1]
        getitem_210 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_208, relu__default_34, primals_327, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 232, [True, True, False]);  getitem_208 = primals_327 = None
        getitem_211 = convolution_backward_default_2[0]
        getitem_212 = convolution_backward_default_2[1];  convolution_backward_default_2 = None
        to_dtype_6 = torch.ops.aten.to.dtype(getitem_211, torch.float32);  getitem_211 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_34, torch.float32);  relu__default_34 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_170 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_170, to_dtype_6);  le_scalar_2 = new_zeros_default_170 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_8, convolution_default_52, primals_326, primals_324, primals_325, new_zeros_default_156, new_zeros_default_157, False, 1e-05, [True, True, True]);  to_dtype_8 = convolution_default_52 = primals_326 = primals_324 = primals_325 = new_zeros_default_156 = new_zeros_default_157 = None
        getitem_214 = native_batch_norm_backward_default_3[0]
        getitem_215 = native_batch_norm_backward_default_3[1]
        getitem_216 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_214, getitem_183, primals_321, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_214 = getitem_183 = primals_321 = None
        getitem_217 = convolution_backward_default_3[0]
        getitem_218 = convolution_backward_default_3[1];  convolution_backward_default_3 = None
        cat_default_16 = torch.ops.aten.cat.default([slice_tensor, getitem_217], 1);  slice_tensor = getitem_217 = None
        view_default_34 = torch.ops.aten.view.default(cat_default_16, [128, 232, 2, 7, 7]);  cat_default_16 = None
        transpose_int_17 = torch.ops.aten.transpose.int(view_default_34, 1, 2);  view_default_34 = None
        clone_default_17 = torch.ops.aten.clone.default(transpose_int_17, memory_format = torch.contiguous_format);  transpose_int_17 = None
        _unsafe_view_default_1 = torch.ops.aten._unsafe_view.default(clone_default_17, [128, 464, 7, 7]);  clone_default_17 = None
        slice_tensor_2 = torch.ops.aten.slice.Tensor(_unsafe_view_default_1, 1, 0, 232)
        slice_tensor_3 = torch.ops.aten.slice.Tensor(_unsafe_view_default_1, 1, 232, 464);  _unsafe_view_default_1 = None
        to_dtype_9 = torch.ops.aten.to.dtype(slice_tensor_3, torch.float32);  slice_tensor_3 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu__default_33, torch.float32);  relu__default_33 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_171 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_171, to_dtype_9);  le_scalar_3 = new_zeros_default_171 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_51, primals_320, primals_318, primals_319, new_zeros_default_153, new_zeros_default_154, False, 1e-05, [True, True, True]);  to_dtype_11 = convolution_default_51 = primals_320 = primals_318 = primals_319 = new_zeros_default_153 = new_zeros_default_154 = None
        getitem_220 = native_batch_norm_backward_default_4[0]
        getitem_221 = native_batch_norm_backward_default_4[1]
        getitem_222 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_220, getitem_176, primals_315, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_220 = getitem_176 = primals_315 = None
        getitem_223 = convolution_backward_default_4[0]
        getitem_224 = convolution_backward_default_4[1];  convolution_backward_default_4 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(getitem_223, convolution_default_50, primals_314, primals_312, primals_313, new_zeros_default_150, new_zeros_default_151, False, 1e-05, [True, True, True]);  getitem_223 = convolution_default_50 = primals_314 = primals_312 = primals_313 = new_zeros_default_150 = new_zeros_default_151 = None
        getitem_226 = native_batch_norm_backward_default_5[0]
        getitem_227 = native_batch_norm_backward_default_5[1]
        getitem_228 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_226, relu__default_32, primals_309, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 232, [True, True, False]);  getitem_226 = primals_309 = None
        getitem_229 = convolution_backward_default_5[0]
        getitem_230 = convolution_backward_default_5[1];  convolution_backward_default_5 = None
        to_dtype_12 = torch.ops.aten.to.dtype(getitem_229, torch.float32);  getitem_229 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_32, torch.float32);  relu__default_32 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_172 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_172, to_dtype_12);  le_scalar_4 = new_zeros_default_172 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_49, primals_308, primals_306, primals_307, new_zeros_default_147, new_zeros_default_148, False, 1e-05, [True, True, True]);  to_dtype_14 = convolution_default_49 = primals_308 = primals_306 = primals_307 = new_zeros_default_147 = new_zeros_default_148 = None
        getitem_232 = native_batch_norm_backward_default_6[0]
        getitem_233 = native_batch_norm_backward_default_6[1]
        getitem_234 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(getitem_232, getitem_172, primals_303, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_232 = getitem_172 = primals_303 = None
        getitem_235 = convolution_backward_default_6[0]
        getitem_236 = convolution_backward_default_6[1];  convolution_backward_default_6 = None
        cat_default_17 = torch.ops.aten.cat.default([slice_tensor_2, getitem_235], 1);  slice_tensor_2 = getitem_235 = None
        view_default_35 = torch.ops.aten.view.default(cat_default_17, [128, 232, 2, 7, 7]);  cat_default_17 = None
        transpose_int_18 = torch.ops.aten.transpose.int(view_default_35, 1, 2);  view_default_35 = None
        clone_default_18 = torch.ops.aten.clone.default(transpose_int_18, memory_format = torch.contiguous_format);  transpose_int_18 = None
        _unsafe_view_default_2 = torch.ops.aten._unsafe_view.default(clone_default_18, [128, 464, 7, 7]);  clone_default_18 = None
        slice_tensor_4 = torch.ops.aten.slice.Tensor(_unsafe_view_default_2, 1, 0, 232)
        slice_tensor_5 = torch.ops.aten.slice.Tensor(_unsafe_view_default_2, 1, 232, 464);  _unsafe_view_default_2 = None
        to_dtype_15 = torch.ops.aten.to.dtype(slice_tensor_5, torch.float32);  slice_tensor_5 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu__default_31, torch.float32);  relu__default_31 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_173 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_173, to_dtype_15);  le_scalar_5 = new_zeros_default_173 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_17, convolution_default_48, primals_302, primals_300, primals_301, new_zeros_default_144, new_zeros_default_145, False, 1e-05, [True, True, True]);  to_dtype_17 = convolution_default_48 = primals_302 = primals_300 = primals_301 = new_zeros_default_144 = new_zeros_default_145 = None
        getitem_238 = native_batch_norm_backward_default_7[0]
        getitem_239 = native_batch_norm_backward_default_7[1]
        getitem_240 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(getitem_238, getitem_165, primals_297, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_238 = getitem_165 = primals_297 = None
        getitem_241 = convolution_backward_default_7[0]
        getitem_242 = convolution_backward_default_7[1];  convolution_backward_default_7 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(getitem_241, convolution_default_47, primals_296, primals_294, primals_295, new_zeros_default_141, new_zeros_default_142, False, 1e-05, [True, True, True]);  getitem_241 = convolution_default_47 = primals_296 = primals_294 = primals_295 = new_zeros_default_141 = new_zeros_default_142 = None
        getitem_244 = native_batch_norm_backward_default_8[0]
        getitem_245 = native_batch_norm_backward_default_8[1]
        getitem_246 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(getitem_244, relu__default_30, primals_291, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 232, [True, True, False]);  getitem_244 = primals_291 = None
        getitem_247 = convolution_backward_default_8[0]
        getitem_248 = convolution_backward_default_8[1];  convolution_backward_default_8 = None
        to_dtype_18 = torch.ops.aten.to.dtype(getitem_247, torch.float32);  getitem_247 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu__default_30, torch.float32);  relu__default_30 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_174 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_174, to_dtype_18);  le_scalar_6 = new_zeros_default_174 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_20, convolution_default_46, primals_290, primals_288, primals_289, new_zeros_default_138, new_zeros_default_139, False, 1e-05, [True, True, True]);  to_dtype_20 = convolution_default_46 = primals_290 = primals_288 = primals_289 = new_zeros_default_138 = new_zeros_default_139 = None
        getitem_250 = native_batch_norm_backward_default_9[0]
        getitem_251 = native_batch_norm_backward_default_9[1]
        getitem_252 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_250, getitem_161, primals_285, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_250 = getitem_161 = primals_285 = None
        getitem_253 = convolution_backward_default_9[0]
        getitem_254 = convolution_backward_default_9[1];  convolution_backward_default_9 = None
        cat_default_18 = torch.ops.aten.cat.default([slice_tensor_4, getitem_253], 1);  slice_tensor_4 = getitem_253 = None
        view_default_36 = torch.ops.aten.view.default(cat_default_18, [128, 232, 2, 7, 7]);  cat_default_18 = None
        transpose_int_19 = torch.ops.aten.transpose.int(view_default_36, 1, 2);  view_default_36 = None
        clone_default_19 = torch.ops.aten.clone.default(transpose_int_19, memory_format = torch.contiguous_format);  transpose_int_19 = None
        _unsafe_view_default_3 = torch.ops.aten._unsafe_view.default(clone_default_19, [128, 464, 7, 7]);  clone_default_19 = None
        slice_tensor_6 = torch.ops.aten.slice.Tensor(_unsafe_view_default_3, 1, 0, 232)
        slice_tensor_7 = torch.ops.aten.slice.Tensor(_unsafe_view_default_3, 1, 232, 464);  _unsafe_view_default_3 = None
        to_dtype_21 = torch.ops.aten.to.dtype(slice_tensor_7, torch.float32);  slice_tensor_7 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_29, torch.float32);  relu__default_29 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_175 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_175, to_dtype_21);  le_scalar_7 = new_zeros_default_175 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_23, convolution_default_45, primals_284, primals_282, primals_283, new_zeros_default_135, new_zeros_default_136, False, 1e-05, [True, True, True]);  to_dtype_23 = convolution_default_45 = primals_284 = primals_282 = primals_283 = new_zeros_default_135 = new_zeros_default_136 = None
        getitem_256 = native_batch_norm_backward_default_10[0]
        getitem_257 = native_batch_norm_backward_default_10[1]
        getitem_258 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_256, getitem_154, primals_279, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_256 = getitem_154 = primals_279 = None
        getitem_259 = convolution_backward_default_10[0]
        getitem_260 = convolution_backward_default_10[1];  convolution_backward_default_10 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(getitem_259, convolution_default_44, primals_278, primals_276, primals_277, new_zeros_default_132, new_zeros_default_133, False, 1e-05, [True, True, True]);  getitem_259 = convolution_default_44 = primals_278 = primals_276 = primals_277 = new_zeros_default_132 = new_zeros_default_133 = None
        getitem_262 = native_batch_norm_backward_default_11[0]
        getitem_263 = native_batch_norm_backward_default_11[1]
        getitem_264 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_262, relu__default_28, primals_273, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 232, [True, True, False]);  getitem_262 = primals_273 = None
        getitem_265 = convolution_backward_default_11[0]
        getitem_266 = convolution_backward_default_11[1];  convolution_backward_default_11 = None
        to_dtype_24 = torch.ops.aten.to.dtype(getitem_265, torch.float32);  getitem_265 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_28, torch.float32);  relu__default_28 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_176 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_176, to_dtype_24);  le_scalar_8 = new_zeros_default_176 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_43, primals_272, primals_270, primals_271, new_zeros_default_129, new_zeros_default_130, False, 1e-05, [True, True, True]);  to_dtype_26 = convolution_default_43 = primals_272 = primals_270 = primals_271 = new_zeros_default_129 = new_zeros_default_130 = None
        getitem_268 = native_batch_norm_backward_default_12[0]
        getitem_269 = native_batch_norm_backward_default_12[1]
        getitem_270 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(getitem_268, view_default_23, primals_267, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_268 = primals_267 = None
        getitem_271 = convolution_backward_default_12[0]
        getitem_272 = convolution_backward_default_12[1];  convolution_backward_default_12 = None
        to_dtype_27 = torch.ops.aten.to.dtype(slice_tensor_6, torch.float32);  slice_tensor_6 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu__default_27, torch.float32);  relu__default_27 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_177 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_177, to_dtype_27);  le_scalar_9 = new_zeros_default_177 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_29, convolution_default_42, primals_266, primals_264, primals_265, new_zeros_default_126, new_zeros_default_127, False, 1e-05, [True, True, True]);  to_dtype_29 = convolution_default_42 = primals_266 = primals_264 = primals_265 = new_zeros_default_126 = new_zeros_default_127 = None
        getitem_274 = native_batch_norm_backward_default_13[0]
        getitem_275 = native_batch_norm_backward_default_13[1]
        getitem_276 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_274, getitem_145, primals_261, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_274 = getitem_145 = primals_261 = None
        getitem_277 = convolution_backward_default_13[0]
        getitem_278 = convolution_backward_default_13[1];  convolution_backward_default_13 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(getitem_277, convolution_default_41, primals_260, primals_258, primals_259, new_zeros_default_123, new_zeros_default_124, False, 1e-05, [True, True, True]);  getitem_277 = convolution_default_41 = primals_260 = primals_258 = primals_259 = new_zeros_default_123 = new_zeros_default_124 = None
        getitem_280 = native_batch_norm_backward_default_14[0]
        getitem_281 = native_batch_norm_backward_default_14[1]
        getitem_282 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_280, view_default_23, primals_255, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 232, [True, True, False]);  getitem_280 = view_default_23 = primals_255 = None
        getitem_283 = convolution_backward_default_14[0]
        getitem_284 = convolution_backward_default_14[1];  convolution_backward_default_14 = None
        add_tensor = torch.ops.aten.add.Tensor(getitem_271, getitem_283);  getitem_271 = getitem_283 = None
        view_default_37 = torch.ops.aten.view.default(add_tensor, [128, 116, 2, 14, 14]);  add_tensor = None
        transpose_int_20 = torch.ops.aten.transpose.int(view_default_37, 1, 2);  view_default_37 = None
        clone_default_20 = torch.ops.aten.clone.default(transpose_int_20, memory_format = torch.contiguous_format);  transpose_int_20 = None
        _unsafe_view_default_4 = torch.ops.aten._unsafe_view.default(clone_default_20, [128, 232, 14, 14]);  clone_default_20 = None
        slice_tensor_8 = torch.ops.aten.slice.Tensor(_unsafe_view_default_4, 1, 0, 116)
        slice_tensor_9 = torch.ops.aten.slice.Tensor(_unsafe_view_default_4, 1, 116, 232);  _unsafe_view_default_4 = None
        to_dtype_30 = torch.ops.aten.to.dtype(slice_tensor_9, torch.float32);  slice_tensor_9 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu__default_26, torch.float32);  relu__default_26 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_178 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_178, to_dtype_30);  le_scalar_10 = new_zeros_default_178 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default_40, primals_254, primals_252, primals_253, new_zeros_default_120, new_zeros_default_121, False, 1e-05, [True, True, True]);  to_dtype_32 = convolution_default_40 = primals_254 = primals_252 = primals_253 = new_zeros_default_120 = new_zeros_default_121 = None
        getitem_286 = native_batch_norm_backward_default_15[0]
        getitem_287 = native_batch_norm_backward_default_15[1]
        getitem_288 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_286, getitem_139, primals_249, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_286 = getitem_139 = primals_249 = None
        getitem_289 = convolution_backward_default_15[0]
        getitem_290 = convolution_backward_default_15[1];  convolution_backward_default_15 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(getitem_289, convolution_default_39, primals_248, primals_246, primals_247, new_zeros_default_117, new_zeros_default_118, False, 1e-05, [True, True, True]);  getitem_289 = convolution_default_39 = primals_248 = primals_246 = primals_247 = new_zeros_default_117 = new_zeros_default_118 = None
        getitem_292 = native_batch_norm_backward_default_16[0]
        getitem_293 = native_batch_norm_backward_default_16[1]
        getitem_294 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(getitem_292, relu__default_25, primals_243, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 116, [True, True, False]);  getitem_292 = primals_243 = None
        getitem_295 = convolution_backward_default_16[0]
        getitem_296 = convolution_backward_default_16[1];  convolution_backward_default_16 = None
        to_dtype_33 = torch.ops.aten.to.dtype(getitem_295, torch.float32);  getitem_295 = None
        to_dtype_34 = torch.ops.aten.to.dtype(relu__default_25, torch.float32);  relu__default_25 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        new_zeros_default_179 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_179, to_dtype_33);  le_scalar_11 = new_zeros_default_179 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_35, convolution_default_38, primals_242, primals_240, primals_241, new_zeros_default_114, new_zeros_default_115, False, 1e-05, [True, True, True]);  to_dtype_35 = convolution_default_38 = primals_242 = primals_240 = primals_241 = new_zeros_default_114 = new_zeros_default_115 = None
        getitem_298 = native_batch_norm_backward_default_17[0]
        getitem_299 = native_batch_norm_backward_default_17[1]
        getitem_300 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(getitem_298, getitem_135, primals_237, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_298 = getitem_135 = primals_237 = None
        getitem_301 = convolution_backward_default_17[0]
        getitem_302 = convolution_backward_default_17[1];  convolution_backward_default_17 = None
        cat_default_19 = torch.ops.aten.cat.default([slice_tensor_8, getitem_301], 1);  slice_tensor_8 = getitem_301 = None
        view_default_38 = torch.ops.aten.view.default(cat_default_19, [128, 116, 2, 14, 14]);  cat_default_19 = None
        transpose_int_21 = torch.ops.aten.transpose.int(view_default_38, 1, 2);  view_default_38 = None
        clone_default_21 = torch.ops.aten.clone.default(transpose_int_21, memory_format = torch.contiguous_format);  transpose_int_21 = None
        _unsafe_view_default_5 = torch.ops.aten._unsafe_view.default(clone_default_21, [128, 232, 14, 14]);  clone_default_21 = None
        slice_tensor_10 = torch.ops.aten.slice.Tensor(_unsafe_view_default_5, 1, 0, 116)
        slice_tensor_11 = torch.ops.aten.slice.Tensor(_unsafe_view_default_5, 1, 116, 232);  _unsafe_view_default_5 = None
        to_dtype_36 = torch.ops.aten.to.dtype(slice_tensor_11, torch.float32);  slice_tensor_11 = None
        to_dtype_37 = torch.ops.aten.to.dtype(relu__default_24, torch.float32);  relu__default_24 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        new_zeros_default_180 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_180, to_dtype_36);  le_scalar_12 = new_zeros_default_180 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_38, convolution_default_37, primals_236, primals_234, primals_235, new_zeros_default_111, new_zeros_default_112, False, 1e-05, [True, True, True]);  to_dtype_38 = convolution_default_37 = primals_236 = primals_234 = primals_235 = new_zeros_default_111 = new_zeros_default_112 = None
        getitem_304 = native_batch_norm_backward_default_18[0]
        getitem_305 = native_batch_norm_backward_default_18[1]
        getitem_306 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(getitem_304, getitem_128, primals_231, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_304 = getitem_128 = primals_231 = None
        getitem_307 = convolution_backward_default_18[0]
        getitem_308 = convolution_backward_default_18[1];  convolution_backward_default_18 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(getitem_307, convolution_default_36, primals_230, primals_228, primals_229, new_zeros_default_108, new_zeros_default_109, False, 1e-05, [True, True, True]);  getitem_307 = convolution_default_36 = primals_230 = primals_228 = primals_229 = new_zeros_default_108 = new_zeros_default_109 = None
        getitem_310 = native_batch_norm_backward_default_19[0]
        getitem_311 = native_batch_norm_backward_default_19[1]
        getitem_312 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_310, relu__default_23, primals_225, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 116, [True, True, False]);  getitem_310 = primals_225 = None
        getitem_313 = convolution_backward_default_19[0]
        getitem_314 = convolution_backward_default_19[1];  convolution_backward_default_19 = None
        to_dtype_39 = torch.ops.aten.to.dtype(getitem_313, torch.float32);  getitem_313 = None
        to_dtype_40 = torch.ops.aten.to.dtype(relu__default_23, torch.float32);  relu__default_23 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        new_zeros_default_181 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_181, to_dtype_39);  le_scalar_13 = new_zeros_default_181 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_41, convolution_default_35, primals_224, primals_222, primals_223, new_zeros_default_105, new_zeros_default_106, False, 1e-05, [True, True, True]);  to_dtype_41 = convolution_default_35 = primals_224 = primals_222 = primals_223 = new_zeros_default_105 = new_zeros_default_106 = None
        getitem_316 = native_batch_norm_backward_default_20[0]
        getitem_317 = native_batch_norm_backward_default_20[1]
        getitem_318 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(getitem_316, getitem_124, primals_219, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_316 = getitem_124 = primals_219 = None
        getitem_319 = convolution_backward_default_20[0]
        getitem_320 = convolution_backward_default_20[1];  convolution_backward_default_20 = None
        cat_default_20 = torch.ops.aten.cat.default([slice_tensor_10, getitem_319], 1);  slice_tensor_10 = getitem_319 = None
        view_default_39 = torch.ops.aten.view.default(cat_default_20, [128, 116, 2, 14, 14]);  cat_default_20 = None
        transpose_int_22 = torch.ops.aten.transpose.int(view_default_39, 1, 2);  view_default_39 = None
        clone_default_22 = torch.ops.aten.clone.default(transpose_int_22, memory_format = torch.contiguous_format);  transpose_int_22 = None
        _unsafe_view_default_6 = torch.ops.aten._unsafe_view.default(clone_default_22, [128, 232, 14, 14]);  clone_default_22 = None
        slice_tensor_12 = torch.ops.aten.slice.Tensor(_unsafe_view_default_6, 1, 0, 116)
        slice_tensor_13 = torch.ops.aten.slice.Tensor(_unsafe_view_default_6, 1, 116, 232);  _unsafe_view_default_6 = None
        to_dtype_42 = torch.ops.aten.to.dtype(slice_tensor_13, torch.float32);  slice_tensor_13 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu__default_22, torch.float32);  relu__default_22 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_182 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_182, to_dtype_42);  le_scalar_14 = new_zeros_default_182 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_44, convolution_default_34, primals_218, primals_216, primals_217, new_zeros_default_102, new_zeros_default_103, False, 1e-05, [True, True, True]);  to_dtype_44 = convolution_default_34 = primals_218 = primals_216 = primals_217 = new_zeros_default_102 = new_zeros_default_103 = None
        getitem_322 = native_batch_norm_backward_default_21[0]
        getitem_323 = native_batch_norm_backward_default_21[1]
        getitem_324 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(getitem_322, getitem_117, primals_213, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_322 = getitem_117 = primals_213 = None
        getitem_325 = convolution_backward_default_21[0]
        getitem_326 = convolution_backward_default_21[1];  convolution_backward_default_21 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(getitem_325, convolution_default_33, primals_212, primals_210, primals_211, new_zeros_default_99, new_zeros_default_100, False, 1e-05, [True, True, True]);  getitem_325 = convolution_default_33 = primals_212 = primals_210 = primals_211 = new_zeros_default_99 = new_zeros_default_100 = None
        getitem_328 = native_batch_norm_backward_default_22[0]
        getitem_329 = native_batch_norm_backward_default_22[1]
        getitem_330 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(getitem_328, relu__default_21, primals_207, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 116, [True, True, False]);  getitem_328 = primals_207 = None
        getitem_331 = convolution_backward_default_22[0]
        getitem_332 = convolution_backward_default_22[1];  convolution_backward_default_22 = None
        to_dtype_45 = torch.ops.aten.to.dtype(getitem_331, torch.float32);  getitem_331 = None
        to_dtype_46 = torch.ops.aten.to.dtype(relu__default_21, torch.float32);  relu__default_21 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_46, 0);  to_dtype_46 = None
        new_zeros_default_183 = torch.ops.aten.new_zeros.default(to_dtype_45, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_183, to_dtype_45);  le_scalar_15 = new_zeros_default_183 = to_dtype_45 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_47, convolution_default_32, primals_206, primals_204, primals_205, new_zeros_default_96, new_zeros_default_97, False, 1e-05, [True, True, True]);  to_dtype_47 = convolution_default_32 = primals_206 = primals_204 = primals_205 = new_zeros_default_96 = new_zeros_default_97 = None
        getitem_334 = native_batch_norm_backward_default_23[0]
        getitem_335 = native_batch_norm_backward_default_23[1]
        getitem_336 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(getitem_334, getitem_113, primals_201, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_334 = getitem_113 = primals_201 = None
        getitem_337 = convolution_backward_default_23[0]
        getitem_338 = convolution_backward_default_23[1];  convolution_backward_default_23 = None
        cat_default_21 = torch.ops.aten.cat.default([slice_tensor_12, getitem_337], 1);  slice_tensor_12 = getitem_337 = None
        view_default_40 = torch.ops.aten.view.default(cat_default_21, [128, 116, 2, 14, 14]);  cat_default_21 = None
        transpose_int_23 = torch.ops.aten.transpose.int(view_default_40, 1, 2);  view_default_40 = None
        clone_default_23 = torch.ops.aten.clone.default(transpose_int_23, memory_format = torch.contiguous_format);  transpose_int_23 = None
        _unsafe_view_default_7 = torch.ops.aten._unsafe_view.default(clone_default_23, [128, 232, 14, 14]);  clone_default_23 = None
        slice_tensor_14 = torch.ops.aten.slice.Tensor(_unsafe_view_default_7, 1, 0, 116)
        slice_tensor_15 = torch.ops.aten.slice.Tensor(_unsafe_view_default_7, 1, 116, 232);  _unsafe_view_default_7 = None
        to_dtype_48 = torch.ops.aten.to.dtype(slice_tensor_15, torch.float32);  slice_tensor_15 = None
        to_dtype_49 = torch.ops.aten.to.dtype(relu__default_20, torch.float32);  relu__default_20 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_49, 0);  to_dtype_49 = None
        new_zeros_default_184 = torch.ops.aten.new_zeros.default(to_dtype_48, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_184, to_dtype_48);  le_scalar_16 = new_zeros_default_184 = to_dtype_48 = None
        to_dtype_50 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_50, convolution_default_31, primals_200, primals_198, primals_199, new_zeros_default_93, new_zeros_default_94, False, 1e-05, [True, True, True]);  to_dtype_50 = convolution_default_31 = primals_200 = primals_198 = primals_199 = new_zeros_default_93 = new_zeros_default_94 = None
        getitem_340 = native_batch_norm_backward_default_24[0]
        getitem_341 = native_batch_norm_backward_default_24[1]
        getitem_342 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_340, getitem_106, primals_195, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_340 = getitem_106 = primals_195 = None
        getitem_343 = convolution_backward_default_24[0]
        getitem_344 = convolution_backward_default_24[1];  convolution_backward_default_24 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(getitem_343, convolution_default_30, primals_194, primals_192, primals_193, new_zeros_default_90, new_zeros_default_91, False, 1e-05, [True, True, True]);  getitem_343 = convolution_default_30 = primals_194 = primals_192 = primals_193 = new_zeros_default_90 = new_zeros_default_91 = None
        getitem_346 = native_batch_norm_backward_default_25[0]
        getitem_347 = native_batch_norm_backward_default_25[1]
        getitem_348 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_346, relu__default_19, primals_189, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 116, [True, True, False]);  getitem_346 = primals_189 = None
        getitem_349 = convolution_backward_default_25[0]
        getitem_350 = convolution_backward_default_25[1];  convolution_backward_default_25 = None
        to_dtype_51 = torch.ops.aten.to.dtype(getitem_349, torch.float32);  getitem_349 = None
        to_dtype_52 = torch.ops.aten.to.dtype(relu__default_19, torch.float32);  relu__default_19 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_52, 0);  to_dtype_52 = None
        new_zeros_default_185 = torch.ops.aten.new_zeros.default(to_dtype_51, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_17, new_zeros_default_185, to_dtype_51);  le_scalar_17 = new_zeros_default_185 = to_dtype_51 = None
        to_dtype_53 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_53, convolution_default_29, primals_188, primals_186, primals_187, new_zeros_default_87, new_zeros_default_88, False, 1e-05, [True, True, True]);  to_dtype_53 = convolution_default_29 = primals_188 = primals_186 = primals_187 = new_zeros_default_87 = new_zeros_default_88 = None
        getitem_352 = native_batch_norm_backward_default_26[0]
        getitem_353 = native_batch_norm_backward_default_26[1]
        getitem_354 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(getitem_352, getitem_102, primals_183, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_352 = getitem_102 = primals_183 = None
        getitem_355 = convolution_backward_default_26[0]
        getitem_356 = convolution_backward_default_26[1];  convolution_backward_default_26 = None
        cat_default_22 = torch.ops.aten.cat.default([slice_tensor_14, getitem_355], 1);  slice_tensor_14 = getitem_355 = None
        view_default_41 = torch.ops.aten.view.default(cat_default_22, [128, 116, 2, 14, 14]);  cat_default_22 = None
        transpose_int_24 = torch.ops.aten.transpose.int(view_default_41, 1, 2);  view_default_41 = None
        clone_default_24 = torch.ops.aten.clone.default(transpose_int_24, memory_format = torch.contiguous_format);  transpose_int_24 = None
        _unsafe_view_default_8 = torch.ops.aten._unsafe_view.default(clone_default_24, [128, 232, 14, 14]);  clone_default_24 = None
        slice_tensor_16 = torch.ops.aten.slice.Tensor(_unsafe_view_default_8, 1, 0, 116)
        slice_tensor_17 = torch.ops.aten.slice.Tensor(_unsafe_view_default_8, 1, 116, 232);  _unsafe_view_default_8 = None
        to_dtype_54 = torch.ops.aten.to.dtype(slice_tensor_17, torch.float32);  slice_tensor_17 = None
        to_dtype_55 = torch.ops.aten.to.dtype(relu__default_18, torch.float32);  relu__default_18 = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_55, 0);  to_dtype_55 = None
        new_zeros_default_186 = torch.ops.aten.new_zeros.default(to_dtype_54, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_18 = torch.ops.aten.where.self(le_scalar_18, new_zeros_default_186, to_dtype_54);  le_scalar_18 = new_zeros_default_186 = to_dtype_54 = None
        to_dtype_56 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_56, convolution_default_28, primals_182, primals_180, primals_181, new_zeros_default_84, new_zeros_default_85, False, 1e-05, [True, True, True]);  to_dtype_56 = convolution_default_28 = primals_182 = primals_180 = primals_181 = new_zeros_default_84 = new_zeros_default_85 = None
        getitem_358 = native_batch_norm_backward_default_27[0]
        getitem_359 = native_batch_norm_backward_default_27[1]
        getitem_360 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(getitem_358, getitem_95, primals_177, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_358 = getitem_95 = primals_177 = None
        getitem_361 = convolution_backward_default_27[0]
        getitem_362 = convolution_backward_default_27[1];  convolution_backward_default_27 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(getitem_361, convolution_default_27, primals_176, primals_174, primals_175, new_zeros_default_81, new_zeros_default_82, False, 1e-05, [True, True, True]);  getitem_361 = convolution_default_27 = primals_176 = primals_174 = primals_175 = new_zeros_default_81 = new_zeros_default_82 = None
        getitem_364 = native_batch_norm_backward_default_28[0]
        getitem_365 = native_batch_norm_backward_default_28[1]
        getitem_366 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(getitem_364, relu__default_17, primals_171, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 116, [True, True, False]);  getitem_364 = primals_171 = None
        getitem_367 = convolution_backward_default_28[0]
        getitem_368 = convolution_backward_default_28[1];  convolution_backward_default_28 = None
        to_dtype_57 = torch.ops.aten.to.dtype(getitem_367, torch.float32);  getitem_367 = None
        to_dtype_58 = torch.ops.aten.to.dtype(relu__default_17, torch.float32);  relu__default_17 = None
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_58, 0);  to_dtype_58 = None
        new_zeros_default_187 = torch.ops.aten.new_zeros.default(to_dtype_57, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_19 = torch.ops.aten.where.self(le_scalar_19, new_zeros_default_187, to_dtype_57);  le_scalar_19 = new_zeros_default_187 = to_dtype_57 = None
        to_dtype_59 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_59, convolution_default_26, primals_170, primals_168, primals_169, new_zeros_default_78, new_zeros_default_79, False, 1e-05, [True, True, True]);  to_dtype_59 = convolution_default_26 = primals_170 = primals_168 = primals_169 = new_zeros_default_78 = new_zeros_default_79 = None
        getitem_370 = native_batch_norm_backward_default_29[0]
        getitem_371 = native_batch_norm_backward_default_29[1]
        getitem_372 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(getitem_370, getitem_91, primals_165, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_370 = getitem_91 = primals_165 = None
        getitem_373 = convolution_backward_default_29[0]
        getitem_374 = convolution_backward_default_29[1];  convolution_backward_default_29 = None
        cat_default_23 = torch.ops.aten.cat.default([slice_tensor_16, getitem_373], 1);  slice_tensor_16 = getitem_373 = None
        view_default_42 = torch.ops.aten.view.default(cat_default_23, [128, 116, 2, 14, 14]);  cat_default_23 = None
        transpose_int_25 = torch.ops.aten.transpose.int(view_default_42, 1, 2);  view_default_42 = None
        clone_default_25 = torch.ops.aten.clone.default(transpose_int_25, memory_format = torch.contiguous_format);  transpose_int_25 = None
        _unsafe_view_default_9 = torch.ops.aten._unsafe_view.default(clone_default_25, [128, 232, 14, 14]);  clone_default_25 = None
        slice_tensor_18 = torch.ops.aten.slice.Tensor(_unsafe_view_default_9, 1, 0, 116)
        slice_tensor_19 = torch.ops.aten.slice.Tensor(_unsafe_view_default_9, 1, 116, 232);  _unsafe_view_default_9 = None
        to_dtype_60 = torch.ops.aten.to.dtype(slice_tensor_19, torch.float32);  slice_tensor_19 = None
        to_dtype_61 = torch.ops.aten.to.dtype(relu__default_16, torch.float32);  relu__default_16 = None
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_61, 0);  to_dtype_61 = None
        new_zeros_default_188 = torch.ops.aten.new_zeros.default(to_dtype_60, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_20 = torch.ops.aten.where.self(le_scalar_20, new_zeros_default_188, to_dtype_60);  le_scalar_20 = new_zeros_default_188 = to_dtype_60 = None
        to_dtype_62 = torch.ops.aten.to.dtype(where_self_20, torch.float32);  where_self_20 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_62, convolution_default_25, primals_164, primals_162, primals_163, new_zeros_default_75, new_zeros_default_76, False, 1e-05, [True, True, True]);  to_dtype_62 = convolution_default_25 = primals_164 = primals_162 = primals_163 = new_zeros_default_75 = new_zeros_default_76 = None
        getitem_376 = native_batch_norm_backward_default_30[0]
        getitem_377 = native_batch_norm_backward_default_30[1]
        getitem_378 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_376, getitem_84, primals_159, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_376 = getitem_84 = primals_159 = None
        getitem_379 = convolution_backward_default_30[0]
        getitem_380 = convolution_backward_default_30[1];  convolution_backward_default_30 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(getitem_379, convolution_default_24, primals_158, primals_156, primals_157, new_zeros_default_72, new_zeros_default_73, False, 1e-05, [True, True, True]);  getitem_379 = convolution_default_24 = primals_158 = primals_156 = primals_157 = new_zeros_default_72 = new_zeros_default_73 = None
        getitem_382 = native_batch_norm_backward_default_31[0]
        getitem_383 = native_batch_norm_backward_default_31[1]
        getitem_384 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(getitem_382, relu__default_15, primals_153, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 116, [True, True, False]);  getitem_382 = primals_153 = None
        getitem_385 = convolution_backward_default_31[0]
        getitem_386 = convolution_backward_default_31[1];  convolution_backward_default_31 = None
        to_dtype_63 = torch.ops.aten.to.dtype(getitem_385, torch.float32);  getitem_385 = None
        to_dtype_64 = torch.ops.aten.to.dtype(relu__default_15, torch.float32);  relu__default_15 = None
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_64, 0);  to_dtype_64 = None
        new_zeros_default_189 = torch.ops.aten.new_zeros.default(to_dtype_63, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_21 = torch.ops.aten.where.self(le_scalar_21, new_zeros_default_189, to_dtype_63);  le_scalar_21 = new_zeros_default_189 = to_dtype_63 = None
        to_dtype_65 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_65, convolution_default_23, primals_152, primals_150, primals_151, new_zeros_default_69, new_zeros_default_70, False, 1e-05, [True, True, True]);  to_dtype_65 = convolution_default_23 = primals_152 = primals_150 = primals_151 = new_zeros_default_69 = new_zeros_default_70 = None
        getitem_388 = native_batch_norm_backward_default_32[0]
        getitem_389 = native_batch_norm_backward_default_32[1]
        getitem_390 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(getitem_388, getitem_80, primals_147, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_388 = getitem_80 = primals_147 = None
        getitem_391 = convolution_backward_default_32[0]
        getitem_392 = convolution_backward_default_32[1];  convolution_backward_default_32 = None
        cat_default_24 = torch.ops.aten.cat.default([slice_tensor_18, getitem_391], 1);  slice_tensor_18 = getitem_391 = None
        view_default_43 = torch.ops.aten.view.default(cat_default_24, [128, 116, 2, 14, 14]);  cat_default_24 = None
        transpose_int_26 = torch.ops.aten.transpose.int(view_default_43, 1, 2);  view_default_43 = None
        clone_default_26 = torch.ops.aten.clone.default(transpose_int_26, memory_format = torch.contiguous_format);  transpose_int_26 = None
        _unsafe_view_default_10 = torch.ops.aten._unsafe_view.default(clone_default_26, [128, 232, 14, 14]);  clone_default_26 = None
        slice_tensor_20 = torch.ops.aten.slice.Tensor(_unsafe_view_default_10, 1, 0, 116)
        slice_tensor_21 = torch.ops.aten.slice.Tensor(_unsafe_view_default_10, 1, 116, 232);  _unsafe_view_default_10 = None
        to_dtype_66 = torch.ops.aten.to.dtype(slice_tensor_21, torch.float32);  slice_tensor_21 = None
        to_dtype_67 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_67, 0);  to_dtype_67 = None
        new_zeros_default_190 = torch.ops.aten.new_zeros.default(to_dtype_66, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_22 = torch.ops.aten.where.self(le_scalar_22, new_zeros_default_190, to_dtype_66);  le_scalar_22 = new_zeros_default_190 = to_dtype_66 = None
        to_dtype_68 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_68, convolution_default_22, primals_146, primals_144, primals_145, new_zeros_default_66, new_zeros_default_67, False, 1e-05, [True, True, True]);  to_dtype_68 = convolution_default_22 = primals_146 = primals_144 = primals_145 = new_zeros_default_66 = new_zeros_default_67 = None
        getitem_394 = native_batch_norm_backward_default_33[0]
        getitem_395 = native_batch_norm_backward_default_33[1]
        getitem_396 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(getitem_394, getitem_73, primals_141, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_394 = getitem_73 = primals_141 = None
        getitem_397 = convolution_backward_default_33[0]
        getitem_398 = convolution_backward_default_33[1];  convolution_backward_default_33 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(getitem_397, convolution_default_21, primals_140, primals_138, primals_139, new_zeros_default_63, new_zeros_default_64, False, 1e-05, [True, True, True]);  getitem_397 = convolution_default_21 = primals_140 = primals_138 = primals_139 = new_zeros_default_63 = new_zeros_default_64 = None
        getitem_400 = native_batch_norm_backward_default_34[0]
        getitem_401 = native_batch_norm_backward_default_34[1]
        getitem_402 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(getitem_400, relu__default_13, primals_135, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 116, [True, True, False]);  getitem_400 = primals_135 = None
        getitem_403 = convolution_backward_default_34[0]
        getitem_404 = convolution_backward_default_34[1];  convolution_backward_default_34 = None
        to_dtype_69 = torch.ops.aten.to.dtype(getitem_403, torch.float32);  getitem_403 = None
        to_dtype_70 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_70, 0);  to_dtype_70 = None
        new_zeros_default_191 = torch.ops.aten.new_zeros.default(to_dtype_69, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(le_scalar_23, new_zeros_default_191, to_dtype_69);  le_scalar_23 = new_zeros_default_191 = to_dtype_69 = None
        to_dtype_71 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_71, convolution_default_20, primals_134, primals_132, primals_133, new_zeros_default_60, new_zeros_default_61, False, 1e-05, [True, True, True]);  to_dtype_71 = convolution_default_20 = primals_134 = primals_132 = primals_133 = new_zeros_default_60 = new_zeros_default_61 = None
        getitem_406 = native_batch_norm_backward_default_35[0]
        getitem_407 = native_batch_norm_backward_default_35[1]
        getitem_408 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_406, getitem_69, primals_129, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_406 = getitem_69 = primals_129 = None
        getitem_409 = convolution_backward_default_35[0]
        getitem_410 = convolution_backward_default_35[1];  convolution_backward_default_35 = None
        cat_default_25 = torch.ops.aten.cat.default([slice_tensor_20, getitem_409], 1);  slice_tensor_20 = getitem_409 = None
        view_default_44 = torch.ops.aten.view.default(cat_default_25, [128, 116, 2, 14, 14]);  cat_default_25 = None
        transpose_int_27 = torch.ops.aten.transpose.int(view_default_44, 1, 2);  view_default_44 = None
        clone_default_27 = torch.ops.aten.clone.default(transpose_int_27, memory_format = torch.contiguous_format);  transpose_int_27 = None
        _unsafe_view_default_11 = torch.ops.aten._unsafe_view.default(clone_default_27, [128, 232, 14, 14]);  clone_default_27 = None
        slice_tensor_22 = torch.ops.aten.slice.Tensor(_unsafe_view_default_11, 1, 0, 116)
        slice_tensor_23 = torch.ops.aten.slice.Tensor(_unsafe_view_default_11, 1, 116, 232);  _unsafe_view_default_11 = None
        to_dtype_72 = torch.ops.aten.to.dtype(slice_tensor_23, torch.float32);  slice_tensor_23 = None
        to_dtype_73 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_73, 0);  to_dtype_73 = None
        new_zeros_default_192 = torch.ops.aten.new_zeros.default(to_dtype_72, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_24 = torch.ops.aten.where.self(le_scalar_24, new_zeros_default_192, to_dtype_72);  le_scalar_24 = new_zeros_default_192 = to_dtype_72 = None
        to_dtype_74 = torch.ops.aten.to.dtype(where_self_24, torch.float32);  where_self_24 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_74, convolution_default_19, primals_128, primals_126, primals_127, new_zeros_default_57, new_zeros_default_58, False, 1e-05, [True, True, True]);  to_dtype_74 = convolution_default_19 = primals_128 = primals_126 = primals_127 = new_zeros_default_57 = new_zeros_default_58 = None
        getitem_412 = native_batch_norm_backward_default_36[0]
        getitem_413 = native_batch_norm_backward_default_36[1]
        getitem_414 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(getitem_412, getitem_62, primals_123, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_412 = getitem_62 = primals_123 = None
        getitem_415 = convolution_backward_default_36[0]
        getitem_416 = convolution_backward_default_36[1];  convolution_backward_default_36 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(getitem_415, convolution_default_18, primals_122, primals_120, primals_121, new_zeros_default_54, new_zeros_default_55, False, 1e-05, [True, True, True]);  getitem_415 = convolution_default_18 = primals_122 = primals_120 = primals_121 = new_zeros_default_54 = new_zeros_default_55 = None
        getitem_418 = native_batch_norm_backward_default_37[0]
        getitem_419 = native_batch_norm_backward_default_37[1]
        getitem_420 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(getitem_418, relu__default_11, primals_117, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 116, [True, True, False]);  getitem_418 = primals_117 = None
        getitem_421 = convolution_backward_default_37[0]
        getitem_422 = convolution_backward_default_37[1];  convolution_backward_default_37 = None
        to_dtype_75 = torch.ops.aten.to.dtype(getitem_421, torch.float32);  getitem_421 = None
        to_dtype_76 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_76, 0);  to_dtype_76 = None
        new_zeros_default_193 = torch.ops.aten.new_zeros.default(to_dtype_75, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_25 = torch.ops.aten.where.self(le_scalar_25, new_zeros_default_193, to_dtype_75);  le_scalar_25 = new_zeros_default_193 = to_dtype_75 = None
        to_dtype_77 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_77, convolution_default_17, primals_116, primals_114, primals_115, new_zeros_default_51, new_zeros_default_52, False, 1e-05, [True, True, True]);  to_dtype_77 = convolution_default_17 = primals_116 = primals_114 = primals_115 = new_zeros_default_51 = new_zeros_default_52 = None
        getitem_424 = native_batch_norm_backward_default_38[0]
        getitem_425 = native_batch_norm_backward_default_38[1]
        getitem_426 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(getitem_424, view_default_7, primals_111, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_424 = primals_111 = None
        getitem_427 = convolution_backward_default_38[0]
        getitem_428 = convolution_backward_default_38[1];  convolution_backward_default_38 = None
        to_dtype_78 = torch.ops.aten.to.dtype(slice_tensor_22, torch.float32);  slice_tensor_22 = None
        to_dtype_79 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_26 = torch.ops.aten.le.Scalar(to_dtype_79, 0);  to_dtype_79 = None
        new_zeros_default_194 = torch.ops.aten.new_zeros.default(to_dtype_78, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_26 = torch.ops.aten.where.self(le_scalar_26, new_zeros_default_194, to_dtype_78);  le_scalar_26 = new_zeros_default_194 = to_dtype_78 = None
        to_dtype_80 = torch.ops.aten.to.dtype(where_self_26, torch.float32);  where_self_26 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_80, convolution_default_16, primals_110, primals_108, primals_109, new_zeros_default_48, new_zeros_default_49, False, 1e-05, [True, True, True]);  to_dtype_80 = convolution_default_16 = primals_110 = primals_108 = primals_109 = new_zeros_default_48 = new_zeros_default_49 = None
        getitem_430 = native_batch_norm_backward_default_39[0]
        getitem_431 = native_batch_norm_backward_default_39[1]
        getitem_432 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(getitem_430, getitem_53, primals_105, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_430 = getitem_53 = primals_105 = None
        getitem_433 = convolution_backward_default_39[0]
        getitem_434 = convolution_backward_default_39[1];  convolution_backward_default_39 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(getitem_433, convolution_default_15, primals_104, primals_102, primals_103, new_zeros_default_45, new_zeros_default_46, False, 1e-05, [True, True, True]);  getitem_433 = convolution_default_15 = primals_104 = primals_102 = primals_103 = new_zeros_default_45 = new_zeros_default_46 = None
        getitem_436 = native_batch_norm_backward_default_40[0]
        getitem_437 = native_batch_norm_backward_default_40[1]
        getitem_438 = native_batch_norm_backward_default_40[2];  native_batch_norm_backward_default_40 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(getitem_436, view_default_7, primals_99, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 116, [True, True, False]);  getitem_436 = view_default_7 = primals_99 = None
        getitem_439 = convolution_backward_default_40[0]
        getitem_440 = convolution_backward_default_40[1];  convolution_backward_default_40 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(getitem_427, getitem_439);  getitem_427 = getitem_439 = None
        view_default_45 = torch.ops.aten.view.default(add_tensor_1, [128, 58, 2, 28, 28]);  add_tensor_1 = None
        transpose_int_28 = torch.ops.aten.transpose.int(view_default_45, 1, 2);  view_default_45 = None
        clone_default_28 = torch.ops.aten.clone.default(transpose_int_28, memory_format = torch.contiguous_format);  transpose_int_28 = None
        _unsafe_view_default_12 = torch.ops.aten._unsafe_view.default(clone_default_28, [128, 116, 28, 28]);  clone_default_28 = None
        slice_tensor_24 = torch.ops.aten.slice.Tensor(_unsafe_view_default_12, 1, 0, 58)
        slice_tensor_25 = torch.ops.aten.slice.Tensor(_unsafe_view_default_12, 1, 58, 116);  _unsafe_view_default_12 = None
        to_dtype_81 = torch.ops.aten.to.dtype(slice_tensor_25, torch.float32);  slice_tensor_25 = None
        to_dtype_82 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_27 = torch.ops.aten.le.Scalar(to_dtype_82, 0);  to_dtype_82 = None
        new_zeros_default_195 = torch.ops.aten.new_zeros.default(to_dtype_81, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_27 = torch.ops.aten.where.self(le_scalar_27, new_zeros_default_195, to_dtype_81);  le_scalar_27 = new_zeros_default_195 = to_dtype_81 = None
        to_dtype_83 = torch.ops.aten.to.dtype(where_self_27, torch.float32);  where_self_27 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_83, convolution_default_14, primals_98, primals_96, primals_97, new_zeros_default_42, new_zeros_default_43, False, 1e-05, [True, True, True]);  to_dtype_83 = convolution_default_14 = primals_98 = primals_96 = primals_97 = new_zeros_default_42 = new_zeros_default_43 = None
        getitem_442 = native_batch_norm_backward_default_41[0]
        getitem_443 = native_batch_norm_backward_default_41[1]
        getitem_444 = native_batch_norm_backward_default_41[2];  native_batch_norm_backward_default_41 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(getitem_442, getitem_47, primals_93, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_442 = getitem_47 = primals_93 = None
        getitem_445 = convolution_backward_default_41[0]
        getitem_446 = convolution_backward_default_41[1];  convolution_backward_default_41 = None
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(getitem_445, convolution_default_13, primals_92, primals_90, primals_91, new_zeros_default_39, new_zeros_default_40, False, 1e-05, [True, True, True]);  getitem_445 = convolution_default_13 = primals_92 = primals_90 = primals_91 = new_zeros_default_39 = new_zeros_default_40 = None
        getitem_448 = native_batch_norm_backward_default_42[0]
        getitem_449 = native_batch_norm_backward_default_42[1]
        getitem_450 = native_batch_norm_backward_default_42[2];  native_batch_norm_backward_default_42 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(getitem_448, relu__default_8, primals_87, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 58, [True, True, False]);  getitem_448 = primals_87 = None
        getitem_451 = convolution_backward_default_42[0]
        getitem_452 = convolution_backward_default_42[1];  convolution_backward_default_42 = None
        to_dtype_84 = torch.ops.aten.to.dtype(getitem_451, torch.float32);  getitem_451 = None
        to_dtype_85 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_28 = torch.ops.aten.le.Scalar(to_dtype_85, 0);  to_dtype_85 = None
        new_zeros_default_196 = torch.ops.aten.new_zeros.default(to_dtype_84, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_28 = torch.ops.aten.where.self(le_scalar_28, new_zeros_default_196, to_dtype_84);  le_scalar_28 = new_zeros_default_196 = to_dtype_84 = None
        to_dtype_86 = torch.ops.aten.to.dtype(where_self_28, torch.float32);  where_self_28 = None
        native_batch_norm_backward_default_43 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_86, convolution_default_12, primals_86, primals_84, primals_85, new_zeros_default_36, new_zeros_default_37, False, 1e-05, [True, True, True]);  to_dtype_86 = convolution_default_12 = primals_86 = primals_84 = primals_85 = new_zeros_default_36 = new_zeros_default_37 = None
        getitem_454 = native_batch_norm_backward_default_43[0]
        getitem_455 = native_batch_norm_backward_default_43[1]
        getitem_456 = native_batch_norm_backward_default_43[2];  native_batch_norm_backward_default_43 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(getitem_454, getitem_43, primals_81, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_454 = getitem_43 = primals_81 = None
        getitem_457 = convolution_backward_default_43[0]
        getitem_458 = convolution_backward_default_43[1];  convolution_backward_default_43 = None
        cat_default_26 = torch.ops.aten.cat.default([slice_tensor_24, getitem_457], 1);  slice_tensor_24 = getitem_457 = None
        view_default_46 = torch.ops.aten.view.default(cat_default_26, [128, 58, 2, 28, 28]);  cat_default_26 = None
        transpose_int_29 = torch.ops.aten.transpose.int(view_default_46, 1, 2);  view_default_46 = None
        clone_default_29 = torch.ops.aten.clone.default(transpose_int_29, memory_format = torch.contiguous_format);  transpose_int_29 = None
        _unsafe_view_default_13 = torch.ops.aten._unsafe_view.default(clone_default_29, [128, 116, 28, 28]);  clone_default_29 = None
        slice_tensor_26 = torch.ops.aten.slice.Tensor(_unsafe_view_default_13, 1, 0, 58)
        slice_tensor_27 = torch.ops.aten.slice.Tensor(_unsafe_view_default_13, 1, 58, 116);  _unsafe_view_default_13 = None
        to_dtype_87 = torch.ops.aten.to.dtype(slice_tensor_27, torch.float32);  slice_tensor_27 = None
        to_dtype_88 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_29 = torch.ops.aten.le.Scalar(to_dtype_88, 0);  to_dtype_88 = None
        new_zeros_default_197 = torch.ops.aten.new_zeros.default(to_dtype_87, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_29 = torch.ops.aten.where.self(le_scalar_29, new_zeros_default_197, to_dtype_87);  le_scalar_29 = new_zeros_default_197 = to_dtype_87 = None
        to_dtype_89 = torch.ops.aten.to.dtype(where_self_29, torch.float32);  where_self_29 = None
        native_batch_norm_backward_default_44 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_89, convolution_default_11, primals_80, primals_78, primals_79, new_zeros_default_33, new_zeros_default_34, False, 1e-05, [True, True, True]);  to_dtype_89 = convolution_default_11 = primals_80 = primals_78 = primals_79 = new_zeros_default_33 = new_zeros_default_34 = None
        getitem_460 = native_batch_norm_backward_default_44[0]
        getitem_461 = native_batch_norm_backward_default_44[1]
        getitem_462 = native_batch_norm_backward_default_44[2];  native_batch_norm_backward_default_44 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(getitem_460, getitem_36, primals_75, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_460 = getitem_36 = primals_75 = None
        getitem_463 = convolution_backward_default_44[0]
        getitem_464 = convolution_backward_default_44[1];  convolution_backward_default_44 = None
        native_batch_norm_backward_default_45 = torch.ops.aten.native_batch_norm_backward.default(getitem_463, convolution_default_10, primals_74, primals_72, primals_73, new_zeros_default_30, new_zeros_default_31, False, 1e-05, [True, True, True]);  getitem_463 = convolution_default_10 = primals_74 = primals_72 = primals_73 = new_zeros_default_30 = new_zeros_default_31 = None
        getitem_466 = native_batch_norm_backward_default_45[0]
        getitem_467 = native_batch_norm_backward_default_45[1]
        getitem_468 = native_batch_norm_backward_default_45[2];  native_batch_norm_backward_default_45 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(getitem_466, relu__default_6, primals_69, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 58, [True, True, False]);  getitem_466 = primals_69 = None
        getitem_469 = convolution_backward_default_45[0]
        getitem_470 = convolution_backward_default_45[1];  convolution_backward_default_45 = None
        to_dtype_90 = torch.ops.aten.to.dtype(getitem_469, torch.float32);  getitem_469 = None
        to_dtype_91 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_30 = torch.ops.aten.le.Scalar(to_dtype_91, 0);  to_dtype_91 = None
        new_zeros_default_198 = torch.ops.aten.new_zeros.default(to_dtype_90, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_30 = torch.ops.aten.where.self(le_scalar_30, new_zeros_default_198, to_dtype_90);  le_scalar_30 = new_zeros_default_198 = to_dtype_90 = None
        to_dtype_92 = torch.ops.aten.to.dtype(where_self_30, torch.float32);  where_self_30 = None
        native_batch_norm_backward_default_46 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_92, convolution_default_9, primals_68, primals_66, primals_67, new_zeros_default_27, new_zeros_default_28, False, 1e-05, [True, True, True]);  to_dtype_92 = convolution_default_9 = primals_68 = primals_66 = primals_67 = new_zeros_default_27 = new_zeros_default_28 = None
        getitem_472 = native_batch_norm_backward_default_46[0]
        getitem_473 = native_batch_norm_backward_default_46[1]
        getitem_474 = native_batch_norm_backward_default_46[2];  native_batch_norm_backward_default_46 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(getitem_472, getitem_32, primals_63, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_472 = getitem_32 = primals_63 = None
        getitem_475 = convolution_backward_default_46[0]
        getitem_476 = convolution_backward_default_46[1];  convolution_backward_default_46 = None
        cat_default_27 = torch.ops.aten.cat.default([slice_tensor_26, getitem_475], 1);  slice_tensor_26 = getitem_475 = None
        view_default_47 = torch.ops.aten.view.default(cat_default_27, [128, 58, 2, 28, 28]);  cat_default_27 = None
        transpose_int_30 = torch.ops.aten.transpose.int(view_default_47, 1, 2);  view_default_47 = None
        clone_default_30 = torch.ops.aten.clone.default(transpose_int_30, memory_format = torch.contiguous_format);  transpose_int_30 = None
        _unsafe_view_default_14 = torch.ops.aten._unsafe_view.default(clone_default_30, [128, 116, 28, 28]);  clone_default_30 = None
        slice_tensor_28 = torch.ops.aten.slice.Tensor(_unsafe_view_default_14, 1, 0, 58)
        slice_tensor_29 = torch.ops.aten.slice.Tensor(_unsafe_view_default_14, 1, 58, 116);  _unsafe_view_default_14 = None
        to_dtype_93 = torch.ops.aten.to.dtype(slice_tensor_29, torch.float32);  slice_tensor_29 = None
        to_dtype_94 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_31 = torch.ops.aten.le.Scalar(to_dtype_94, 0);  to_dtype_94 = None
        new_zeros_default_199 = torch.ops.aten.new_zeros.default(to_dtype_93, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_31 = torch.ops.aten.where.self(le_scalar_31, new_zeros_default_199, to_dtype_93);  le_scalar_31 = new_zeros_default_199 = to_dtype_93 = None
        to_dtype_95 = torch.ops.aten.to.dtype(where_self_31, torch.float32);  where_self_31 = None
        native_batch_norm_backward_default_47 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_95, convolution_default_8, primals_62, primals_60, primals_61, new_zeros_default_24, new_zeros_default_25, False, 1e-05, [True, True, True]);  to_dtype_95 = convolution_default_8 = primals_62 = primals_60 = primals_61 = new_zeros_default_24 = new_zeros_default_25 = None
        getitem_478 = native_batch_norm_backward_default_47[0]
        getitem_479 = native_batch_norm_backward_default_47[1]
        getitem_480 = native_batch_norm_backward_default_47[2];  native_batch_norm_backward_default_47 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(getitem_478, getitem_25, primals_57, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_478 = getitem_25 = primals_57 = None
        getitem_481 = convolution_backward_default_47[0]
        getitem_482 = convolution_backward_default_47[1];  convolution_backward_default_47 = None
        native_batch_norm_backward_default_48 = torch.ops.aten.native_batch_norm_backward.default(getitem_481, convolution_default_7, primals_56, primals_54, primals_55, new_zeros_default_21, new_zeros_default_22, False, 1e-05, [True, True, True]);  getitem_481 = convolution_default_7 = primals_56 = primals_54 = primals_55 = new_zeros_default_21 = new_zeros_default_22 = None
        getitem_484 = native_batch_norm_backward_default_48[0]
        getitem_485 = native_batch_norm_backward_default_48[1]
        getitem_486 = native_batch_norm_backward_default_48[2];  native_batch_norm_backward_default_48 = None
        convolution_backward_default_48 = torch.ops.aten.convolution_backward.default(getitem_484, relu__default_4, primals_51, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 58, [True, True, False]);  getitem_484 = primals_51 = None
        getitem_487 = convolution_backward_default_48[0]
        getitem_488 = convolution_backward_default_48[1];  convolution_backward_default_48 = None
        to_dtype_96 = torch.ops.aten.to.dtype(getitem_487, torch.float32);  getitem_487 = None
        to_dtype_97 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_32 = torch.ops.aten.le.Scalar(to_dtype_97, 0);  to_dtype_97 = None
        new_zeros_default_200 = torch.ops.aten.new_zeros.default(to_dtype_96, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_32 = torch.ops.aten.where.self(le_scalar_32, new_zeros_default_200, to_dtype_96);  le_scalar_32 = new_zeros_default_200 = to_dtype_96 = None
        to_dtype_98 = torch.ops.aten.to.dtype(where_self_32, torch.float32);  where_self_32 = None
        native_batch_norm_backward_default_49 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_98, convolution_default_6, primals_50, primals_48, primals_49, new_zeros_default_18, new_zeros_default_19, False, 1e-05, [True, True, True]);  to_dtype_98 = convolution_default_6 = primals_50 = primals_48 = primals_49 = new_zeros_default_18 = new_zeros_default_19 = None
        getitem_490 = native_batch_norm_backward_default_49[0]
        getitem_491 = native_batch_norm_backward_default_49[1]
        getitem_492 = native_batch_norm_backward_default_49[2];  native_batch_norm_backward_default_49 = None
        convolution_backward_default_49 = torch.ops.aten.convolution_backward.default(getitem_490, getitem_21, primals_45, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_490 = getitem_21 = primals_45 = None
        getitem_493 = convolution_backward_default_49[0]
        getitem_494 = convolution_backward_default_49[1];  convolution_backward_default_49 = None
        cat_default_28 = torch.ops.aten.cat.default([slice_tensor_28, getitem_493], 1);  slice_tensor_28 = getitem_493 = None
        view_default_48 = torch.ops.aten.view.default(cat_default_28, [128, 58, 2, 28, 28]);  cat_default_28 = None
        transpose_int_31 = torch.ops.aten.transpose.int(view_default_48, 1, 2);  view_default_48 = None
        clone_default_31 = torch.ops.aten.clone.default(transpose_int_31, memory_format = torch.contiguous_format);  transpose_int_31 = None
        _unsafe_view_default_15 = torch.ops.aten._unsafe_view.default(clone_default_31, [128, 116, 28, 28]);  clone_default_31 = None
        slice_tensor_30 = torch.ops.aten.slice.Tensor(_unsafe_view_default_15, 1, 0, 58)
        slice_tensor_31 = torch.ops.aten.slice.Tensor(_unsafe_view_default_15, 1, 58, 116);  _unsafe_view_default_15 = None
        to_dtype_99 = torch.ops.aten.to.dtype(slice_tensor_31, torch.float32);  slice_tensor_31 = None
        to_dtype_100 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_33 = torch.ops.aten.le.Scalar(to_dtype_100, 0);  to_dtype_100 = None
        new_zeros_default_201 = torch.ops.aten.new_zeros.default(to_dtype_99, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_33 = torch.ops.aten.where.self(le_scalar_33, new_zeros_default_201, to_dtype_99);  le_scalar_33 = new_zeros_default_201 = to_dtype_99 = None
        to_dtype_101 = torch.ops.aten.to.dtype(where_self_33, torch.float32);  where_self_33 = None
        native_batch_norm_backward_default_50 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_101, convolution_default_5, primals_44, primals_42, primals_43, new_zeros_default_15, new_zeros_default_16, False, 1e-05, [True, True, True]);  to_dtype_101 = convolution_default_5 = primals_44 = primals_42 = primals_43 = new_zeros_default_15 = new_zeros_default_16 = None
        getitem_496 = native_batch_norm_backward_default_50[0]
        getitem_497 = native_batch_norm_backward_default_50[1]
        getitem_498 = native_batch_norm_backward_default_50[2];  native_batch_norm_backward_default_50 = None
        convolution_backward_default_50 = torch.ops.aten.convolution_backward.default(getitem_496, getitem_14, primals_39, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_496 = getitem_14 = primals_39 = None
        getitem_499 = convolution_backward_default_50[0]
        getitem_500 = convolution_backward_default_50[1];  convolution_backward_default_50 = None
        native_batch_norm_backward_default_51 = torch.ops.aten.native_batch_norm_backward.default(getitem_499, convolution_default_4, primals_38, primals_36, primals_37, new_zeros_default_12, new_zeros_default_13, False, 1e-05, [True, True, True]);  getitem_499 = convolution_default_4 = primals_38 = primals_36 = primals_37 = new_zeros_default_12 = new_zeros_default_13 = None
        getitem_502 = native_batch_norm_backward_default_51[0]
        getitem_503 = native_batch_norm_backward_default_51[1]
        getitem_504 = native_batch_norm_backward_default_51[2];  native_batch_norm_backward_default_51 = None
        convolution_backward_default_51 = torch.ops.aten.convolution_backward.default(getitem_502, relu__default_2, primals_33, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 58, [True, True, False]);  getitem_502 = primals_33 = None
        getitem_505 = convolution_backward_default_51[0]
        getitem_506 = convolution_backward_default_51[1];  convolution_backward_default_51 = None
        to_dtype_102 = torch.ops.aten.to.dtype(getitem_505, torch.float32);  getitem_505 = None
        to_dtype_103 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_34 = torch.ops.aten.le.Scalar(to_dtype_103, 0);  to_dtype_103 = None
        new_zeros_default_202 = torch.ops.aten.new_zeros.default(to_dtype_102, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_34 = torch.ops.aten.where.self(le_scalar_34, new_zeros_default_202, to_dtype_102);  le_scalar_34 = new_zeros_default_202 = to_dtype_102 = None
        to_dtype_104 = torch.ops.aten.to.dtype(where_self_34, torch.float32);  where_self_34 = None
        native_batch_norm_backward_default_52 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_104, convolution_default_3, primals_32, primals_30, primals_31, new_zeros_default_9, new_zeros_default_10, False, 1e-05, [True, True, True]);  to_dtype_104 = convolution_default_3 = primals_32 = primals_30 = primals_31 = new_zeros_default_9 = new_zeros_default_10 = None
        getitem_508 = native_batch_norm_backward_default_52[0]
        getitem_509 = native_batch_norm_backward_default_52[1]
        getitem_510 = native_batch_norm_backward_default_52[2];  native_batch_norm_backward_default_52 = None
        convolution_backward_default_52 = torch.ops.aten.convolution_backward.default(getitem_508, getitem_3, primals_27, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_508 = primals_27 = None
        getitem_511 = convolution_backward_default_52[0]
        getitem_512 = convolution_backward_default_52[1];  convolution_backward_default_52 = None
        to_dtype_105 = torch.ops.aten.to.dtype(slice_tensor_30, torch.float32);  slice_tensor_30 = None
        to_dtype_106 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_35 = torch.ops.aten.le.Scalar(to_dtype_106, 0);  to_dtype_106 = None
        new_zeros_default_203 = torch.ops.aten.new_zeros.default(to_dtype_105, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_35 = torch.ops.aten.where.self(le_scalar_35, new_zeros_default_203, to_dtype_105);  le_scalar_35 = new_zeros_default_203 = to_dtype_105 = None
        to_dtype_107 = torch.ops.aten.to.dtype(where_self_35, torch.float32);  where_self_35 = None
        native_batch_norm_backward_default_53 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_107, convolution_default_2, primals_26, primals_24, primals_25, new_zeros_default_6, new_zeros_default_7, False, 1e-05, [True, True, True]);  to_dtype_107 = convolution_default_2 = primals_26 = primals_24 = primals_25 = new_zeros_default_6 = new_zeros_default_7 = None
        getitem_514 = native_batch_norm_backward_default_53[0]
        getitem_515 = native_batch_norm_backward_default_53[1]
        getitem_516 = native_batch_norm_backward_default_53[2];  native_batch_norm_backward_default_53 = None
        convolution_backward_default_53 = torch.ops.aten.convolution_backward.default(getitem_514, getitem_5, primals_21, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_514 = getitem_5 = primals_21 = None
        getitem_517 = convolution_backward_default_53[0]
        getitem_518 = convolution_backward_default_53[1];  convolution_backward_default_53 = None
        native_batch_norm_backward_default_54 = torch.ops.aten.native_batch_norm_backward.default(getitem_517, convolution_default_1, primals_20, primals_18, primals_19, new_zeros_default_3, new_zeros_default_4, False, 1e-05, [True, True, True]);  getitem_517 = convolution_default_1 = primals_20 = primals_18 = primals_19 = new_zeros_default_3 = new_zeros_default_4 = None
        getitem_520 = native_batch_norm_backward_default_54[0]
        getitem_521 = native_batch_norm_backward_default_54[1]
        getitem_522 = native_batch_norm_backward_default_54[2];  native_batch_norm_backward_default_54 = None
        convolution_backward_default_54 = torch.ops.aten.convolution_backward.default(getitem_520, getitem_3, primals_15, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 24, [True, True, False]);  getitem_520 = getitem_3 = primals_15 = None
        getitem_523 = convolution_backward_default_54[0]
        getitem_524 = convolution_backward_default_54[1];  convolution_backward_default_54 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(getitem_511, getitem_523);  getitem_511 = getitem_523 = None
        max_pool2d_with_indices_backward_default = torch.ops.aten.max_pool2d_with_indices_backward.default(add_tensor_2, relu__default, [3, 3], [2, 2], [1, 1], [1, 1], False, getitem_4);  add_tensor_2 = getitem_4 = None
        to_dtype_108 = torch.ops.aten.to.dtype(max_pool2d_with_indices_backward_default, torch.float32);  max_pool2d_with_indices_backward_default = None
        to_dtype_109 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_36 = torch.ops.aten.le.Scalar(to_dtype_109, 0);  to_dtype_109 = None
        new_zeros_default_204 = torch.ops.aten.new_zeros.default(to_dtype_108, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_36 = torch.ops.aten.where.self(le_scalar_36, new_zeros_default_204, to_dtype_108);  le_scalar_36 = new_zeros_default_204 = to_dtype_108 = None
        to_dtype_110 = torch.ops.aten.to.dtype(where_self_36, torch.float32);  where_self_36 = None
        native_batch_norm_backward_default_55 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_110, convolution_default, primals_6, primals_4, primals_5, new_zeros_default, new_zeros_default_1, False, 1e-05, [True, True, True]);  to_dtype_110 = convolution_default = primals_6 = primals_4 = primals_5 = new_zeros_default = new_zeros_default_1 = None
        getitem_526 = native_batch_norm_backward_default_55[0]
        getitem_527 = native_batch_norm_backward_default_55[1]
        getitem_528 = native_batch_norm_backward_default_55[2];  native_batch_norm_backward_default_55 = None
        convolution_backward_default_55 = torch.ops.aten.convolution_backward.default(getitem_526, primals_339, primals_1, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_526 = primals_339 = primals_1 = None
        getitem_530 = convolution_backward_default_55[1];  convolution_backward_default_55 = None
        return [getitem_530, getitem_528, None, None, None, getitem_527, getitem_200, getitem_198, None, None, None, getitem_197, view_default_32, t_default_4, getitem_524, getitem_522, None, None, None, getitem_521, getitem_518, getitem_516, None, None, None, getitem_515, getitem_512, getitem_510, None, None, None, getitem_509, getitem_506, getitem_504, None, None, None, getitem_503, getitem_500, getitem_498, None, None, None, getitem_497, getitem_494, getitem_492, None, None, None, getitem_491, getitem_488, getitem_486, None, None, None, getitem_485, getitem_482, getitem_480, None, None, None, getitem_479, getitem_476, getitem_474, None, None, None, getitem_473, getitem_470, getitem_468, None, None, None, getitem_467, getitem_464, getitem_462, None, None, None, getitem_461, getitem_458, getitem_456, None, None, None, getitem_455, getitem_452, getitem_450, None, None, None, getitem_449, getitem_446, getitem_444, None, None, None, getitem_443, getitem_440, getitem_438, None, None, None, getitem_437, getitem_434, getitem_432, None, None, None, getitem_431, getitem_428, getitem_426, None, None, None, getitem_425, getitem_422, getitem_420, None, None, None, getitem_419, getitem_416, getitem_414, None, None, None, getitem_413, getitem_410, getitem_408, None, None, None, getitem_407, getitem_404, getitem_402, None, None, None, getitem_401, getitem_398, getitem_396, None, None, None, getitem_395, getitem_392, getitem_390, None, None, None, getitem_389, getitem_386, getitem_384, None, None, None, getitem_383, getitem_380, getitem_378, None, None, None, getitem_377, getitem_374, getitem_372, None, None, None, getitem_371, getitem_368, getitem_366, None, None, None, getitem_365, getitem_362, getitem_360, None, None, None, getitem_359, getitem_356, getitem_354, None, None, None, getitem_353, getitem_350, getitem_348, None, None, None, getitem_347, getitem_344, getitem_342, None, None, None, getitem_341, getitem_338, getitem_336, None, None, None, getitem_335, getitem_332, getitem_330, None, None, None, getitem_329, getitem_326, getitem_324, None, None, None, getitem_323, getitem_320, getitem_318, None, None, None, getitem_317, getitem_314, getitem_312, None, None, None, getitem_311, getitem_308, getitem_306, None, None, None, getitem_305, getitem_302, getitem_300, None, None, None, getitem_299, getitem_296, getitem_294, None, None, None, getitem_293, getitem_290, getitem_288, None, None, None, getitem_287, getitem_284, getitem_282, None, None, None, getitem_281, getitem_278, getitem_276, None, None, None, getitem_275, getitem_272, getitem_270, None, None, None, getitem_269, getitem_266, getitem_264, None, None, None, getitem_263, getitem_260, getitem_258, None, None, None, getitem_257, getitem_254, getitem_252, None, None, None, getitem_251, getitem_248, getitem_246, None, None, None, getitem_245, getitem_242, getitem_240, None, None, None, getitem_239, getitem_236, getitem_234, None, None, None, getitem_233, getitem_230, getitem_228, None, None, None, getitem_227, getitem_224, getitem_222, None, None, None, getitem_221, getitem_218, getitem_216, None, None, None, getitem_215, getitem_212, getitem_210, None, None, None, getitem_209, getitem_206, getitem_204, None, None, None, getitem_203, None]
        
