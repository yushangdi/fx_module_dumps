
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/shufflenet_v2_x1_0/shufflenet_v2_x1_0_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339):
        convolution_default = torch.ops.aten.convolution.default(primals_339, primals_1, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_6, primals_2, primals_4, primals_5, False, 0.1, 1e-05);  primals_2 = None
        getitem = native_batch_norm_default[0];  native_batch_norm_default = None
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu__default, [3, 3], [2, 2], [1, 1])
        getitem_3 = max_pool2d_with_indices_default[0]
        getitem_4 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_1 = torch.ops.aten.convolution.default(getitem_3, primals_15, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 24)
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_20, primals_16, primals_18, primals_19, False, 0.1, 1e-05);  primals_16 = None
        getitem_5 = native_batch_norm_default_1[0];  native_batch_norm_default_1 = None
        convolution_default_2 = torch.ops.aten.convolution.default(getitem_5, primals_21, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_26, primals_22, primals_24, primals_25, False, 0.1, 1e-05);  primals_22 = None
        getitem_8 = native_batch_norm_default_2[0];  native_batch_norm_default_2 = None
        relu__default_1 = torch.ops.aten.relu_.default(getitem_8);  getitem_8 = None
        convolution_default_3 = torch.ops.aten.convolution.default(getitem_3, primals_27, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_32, primals_28, primals_30, primals_31, False, 0.1, 1e-05);  primals_28 = None
        getitem_11 = native_batch_norm_default_3[0];  native_batch_norm_default_3 = None
        relu__default_2 = torch.ops.aten.relu_.default(getitem_11);  getitem_11 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu__default_2, primals_33, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 58)
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_38, primals_34, primals_36, primals_37, False, 0.1, 1e-05);  primals_34 = None
        getitem_14 = native_batch_norm_default_4[0];  native_batch_norm_default_4 = None
        convolution_default_5 = torch.ops.aten.convolution.default(getitem_14, primals_39, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_44, primals_40, primals_42, primals_43, False, 0.1, 1e-05);  primals_40 = None
        getitem_17 = native_batch_norm_default_5[0];  native_batch_norm_default_5 = None
        relu__default_3 = torch.ops.aten.relu_.default(getitem_17);  getitem_17 = None
        cat_default = torch.ops.aten.cat.default([relu__default_1, relu__default_3], 1)
        view_default = torch.ops.aten.view.default(cat_default, [128, 2, 58, 28, 28]);  cat_default = None
        transpose_int = torch.ops.aten.transpose.int(view_default, 1, 2);  view_default = None
        clone_default = torch.ops.aten.clone.default(transpose_int, memory_format = torch.contiguous_format);  transpose_int = None
        view_default_1 = torch.ops.aten.view.default(clone_default, [128, -1, 28, 28]);  clone_default = None
        split_tensor = torch.ops.aten.split.Tensor(view_default_1, 58, 1);  view_default_1 = None
        getitem_20 = split_tensor[0]
        getitem_21 = split_tensor[1];  split_tensor = None
        convolution_default_6 = torch.ops.aten.convolution.default(getitem_21, primals_45, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_50, primals_46, primals_48, primals_49, False, 0.1, 1e-05);  primals_46 = None
        getitem_22 = native_batch_norm_default_6[0];  native_batch_norm_default_6 = None
        relu__default_4 = torch.ops.aten.relu_.default(getitem_22);  getitem_22 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_4, primals_51, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 58)
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_56, primals_52, primals_54, primals_55, False, 0.1, 1e-05);  primals_52 = None
        getitem_25 = native_batch_norm_default_7[0];  native_batch_norm_default_7 = None
        convolution_default_8 = torch.ops.aten.convolution.default(getitem_25, primals_57, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_62, primals_58, primals_60, primals_61, False, 0.1, 1e-05);  primals_58 = None
        getitem_28 = native_batch_norm_default_8[0];  native_batch_norm_default_8 = None
        relu__default_5 = torch.ops.aten.relu_.default(getitem_28);  getitem_28 = None
        cat_default_1 = torch.ops.aten.cat.default([getitem_20, relu__default_5], 1);  getitem_20 = None
        view_default_2 = torch.ops.aten.view.default(cat_default_1, [128, 2, 58, 28, 28]);  cat_default_1 = None
        transpose_int_1 = torch.ops.aten.transpose.int(view_default_2, 1, 2);  view_default_2 = None
        clone_default_1 = torch.ops.aten.clone.default(transpose_int_1, memory_format = torch.contiguous_format);  transpose_int_1 = None
        view_default_3 = torch.ops.aten.view.default(clone_default_1, [128, -1, 28, 28]);  clone_default_1 = None
        split_tensor_1 = torch.ops.aten.split.Tensor(view_default_3, 58, 1);  view_default_3 = None
        getitem_31 = split_tensor_1[0]
        getitem_32 = split_tensor_1[1];  split_tensor_1 = None
        convolution_default_9 = torch.ops.aten.convolution.default(getitem_32, primals_63, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_68, primals_64, primals_66, primals_67, False, 0.1, 1e-05);  primals_64 = None
        getitem_33 = native_batch_norm_default_9[0];  native_batch_norm_default_9 = None
        relu__default_6 = torch.ops.aten.relu_.default(getitem_33);  getitem_33 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default_6, primals_69, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 58)
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_74, primals_70, primals_72, primals_73, False, 0.1, 1e-05);  primals_70 = None
        getitem_36 = native_batch_norm_default_10[0];  native_batch_norm_default_10 = None
        convolution_default_11 = torch.ops.aten.convolution.default(getitem_36, primals_75, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_80, primals_76, primals_78, primals_79, False, 0.1, 1e-05);  primals_76 = None
        getitem_39 = native_batch_norm_default_11[0];  native_batch_norm_default_11 = None
        relu__default_7 = torch.ops.aten.relu_.default(getitem_39);  getitem_39 = None
        cat_default_2 = torch.ops.aten.cat.default([getitem_31, relu__default_7], 1);  getitem_31 = None
        view_default_4 = torch.ops.aten.view.default(cat_default_2, [128, 2, 58, 28, 28]);  cat_default_2 = None
        transpose_int_2 = torch.ops.aten.transpose.int(view_default_4, 1, 2);  view_default_4 = None
        clone_default_2 = torch.ops.aten.clone.default(transpose_int_2, memory_format = torch.contiguous_format);  transpose_int_2 = None
        view_default_5 = torch.ops.aten.view.default(clone_default_2, [128, -1, 28, 28]);  clone_default_2 = None
        split_tensor_2 = torch.ops.aten.split.Tensor(view_default_5, 58, 1);  view_default_5 = None
        getitem_42 = split_tensor_2[0]
        getitem_43 = split_tensor_2[1];  split_tensor_2 = None
        convolution_default_12 = torch.ops.aten.convolution.default(getitem_43, primals_81, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_86, primals_82, primals_84, primals_85, False, 0.1, 1e-05);  primals_82 = None
        getitem_44 = native_batch_norm_default_12[0];  native_batch_norm_default_12 = None
        relu__default_8 = torch.ops.aten.relu_.default(getitem_44);  getitem_44 = None
        convolution_default_13 = torch.ops.aten.convolution.default(relu__default_8, primals_87, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 58)
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_92, primals_88, primals_90, primals_91, False, 0.1, 1e-05);  primals_88 = None
        getitem_47 = native_batch_norm_default_13[0];  native_batch_norm_default_13 = None
        convolution_default_14 = torch.ops.aten.convolution.default(getitem_47, primals_93, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_98, primals_94, primals_96, primals_97, False, 0.1, 1e-05);  primals_94 = None
        getitem_50 = native_batch_norm_default_14[0];  native_batch_norm_default_14 = None
        relu__default_9 = torch.ops.aten.relu_.default(getitem_50);  getitem_50 = None
        cat_default_3 = torch.ops.aten.cat.default([getitem_42, relu__default_9], 1);  getitem_42 = None
        view_default_6 = torch.ops.aten.view.default(cat_default_3, [128, 2, 58, 28, 28]);  cat_default_3 = None
        transpose_int_3 = torch.ops.aten.transpose.int(view_default_6, 1, 2);  view_default_6 = None
        clone_default_3 = torch.ops.aten.clone.default(transpose_int_3, memory_format = torch.contiguous_format);  transpose_int_3 = None
        view_default_7 = torch.ops.aten.view.default(clone_default_3, [128, -1, 28, 28]);  clone_default_3 = None
        convolution_default_15 = torch.ops.aten.convolution.default(view_default_7, primals_99, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 116)
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_104, primals_100, primals_102, primals_103, False, 0.1, 1e-05);  primals_100 = None
        getitem_53 = native_batch_norm_default_15[0];  native_batch_norm_default_15 = None
        convolution_default_16 = torch.ops.aten.convolution.default(getitem_53, primals_105, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_110, primals_106, primals_108, primals_109, False, 0.1, 1e-05);  primals_106 = None
        getitem_56 = native_batch_norm_default_16[0];  native_batch_norm_default_16 = None
        relu__default_10 = torch.ops.aten.relu_.default(getitem_56);  getitem_56 = None
        convolution_default_17 = torch.ops.aten.convolution.default(view_default_7, primals_111, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_116, primals_112, primals_114, primals_115, False, 0.1, 1e-05);  primals_112 = None
        getitem_59 = native_batch_norm_default_17[0];  native_batch_norm_default_17 = None
        relu__default_11 = torch.ops.aten.relu_.default(getitem_59);  getitem_59 = None
        convolution_default_18 = torch.ops.aten.convolution.default(relu__default_11, primals_117, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 116)
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_122, primals_118, primals_120, primals_121, False, 0.1, 1e-05);  primals_118 = None
        getitem_62 = native_batch_norm_default_18[0];  native_batch_norm_default_18 = None
        convolution_default_19 = torch.ops.aten.convolution.default(getitem_62, primals_123, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_128, primals_124, primals_126, primals_127, False, 0.1, 1e-05);  primals_124 = None
        getitem_65 = native_batch_norm_default_19[0];  native_batch_norm_default_19 = None
        relu__default_12 = torch.ops.aten.relu_.default(getitem_65);  getitem_65 = None
        cat_default_4 = torch.ops.aten.cat.default([relu__default_10, relu__default_12], 1)
        view_default_8 = torch.ops.aten.view.default(cat_default_4, [128, 2, 116, 14, 14]);  cat_default_4 = None
        transpose_int_4 = torch.ops.aten.transpose.int(view_default_8, 1, 2);  view_default_8 = None
        clone_default_4 = torch.ops.aten.clone.default(transpose_int_4, memory_format = torch.contiguous_format);  transpose_int_4 = None
        view_default_9 = torch.ops.aten.view.default(clone_default_4, [128, -1, 14, 14]);  clone_default_4 = None
        split_tensor_3 = torch.ops.aten.split.Tensor(view_default_9, 116, 1);  view_default_9 = None
        getitem_68 = split_tensor_3[0]
        getitem_69 = split_tensor_3[1];  split_tensor_3 = None
        convolution_default_20 = torch.ops.aten.convolution.default(getitem_69, primals_129, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_134, primals_130, primals_132, primals_133, False, 0.1, 1e-05);  primals_130 = None
        getitem_70 = native_batch_norm_default_20[0];  native_batch_norm_default_20 = None
        relu__default_13 = torch.ops.aten.relu_.default(getitem_70);  getitem_70 = None
        convolution_default_21 = torch.ops.aten.convolution.default(relu__default_13, primals_135, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 116)
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_140, primals_136, primals_138, primals_139, False, 0.1, 1e-05);  primals_136 = None
        getitem_73 = native_batch_norm_default_21[0];  native_batch_norm_default_21 = None
        convolution_default_22 = torch.ops.aten.convolution.default(getitem_73, primals_141, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_146, primals_142, primals_144, primals_145, False, 0.1, 1e-05);  primals_142 = None
        getitem_76 = native_batch_norm_default_22[0];  native_batch_norm_default_22 = None
        relu__default_14 = torch.ops.aten.relu_.default(getitem_76);  getitem_76 = None
        cat_default_5 = torch.ops.aten.cat.default([getitem_68, relu__default_14], 1);  getitem_68 = None
        view_default_10 = torch.ops.aten.view.default(cat_default_5, [128, 2, 116, 14, 14]);  cat_default_5 = None
        transpose_int_5 = torch.ops.aten.transpose.int(view_default_10, 1, 2);  view_default_10 = None
        clone_default_5 = torch.ops.aten.clone.default(transpose_int_5, memory_format = torch.contiguous_format);  transpose_int_5 = None
        view_default_11 = torch.ops.aten.view.default(clone_default_5, [128, -1, 14, 14]);  clone_default_5 = None
        split_tensor_4 = torch.ops.aten.split.Tensor(view_default_11, 116, 1);  view_default_11 = None
        getitem_79 = split_tensor_4[0]
        getitem_80 = split_tensor_4[1];  split_tensor_4 = None
        convolution_default_23 = torch.ops.aten.convolution.default(getitem_80, primals_147, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_152, primals_148, primals_150, primals_151, False, 0.1, 1e-05);  primals_148 = None
        getitem_81 = native_batch_norm_default_23[0];  native_batch_norm_default_23 = None
        relu__default_15 = torch.ops.aten.relu_.default(getitem_81);  getitem_81 = None
        convolution_default_24 = torch.ops.aten.convolution.default(relu__default_15, primals_153, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 116)
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_158, primals_154, primals_156, primals_157, False, 0.1, 1e-05);  primals_154 = None
        getitem_84 = native_batch_norm_default_24[0];  native_batch_norm_default_24 = None
        convolution_default_25 = torch.ops.aten.convolution.default(getitem_84, primals_159, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_164, primals_160, primals_162, primals_163, False, 0.1, 1e-05);  primals_160 = None
        getitem_87 = native_batch_norm_default_25[0];  native_batch_norm_default_25 = None
        relu__default_16 = torch.ops.aten.relu_.default(getitem_87);  getitem_87 = None
        cat_default_6 = torch.ops.aten.cat.default([getitem_79, relu__default_16], 1);  getitem_79 = None
        view_default_12 = torch.ops.aten.view.default(cat_default_6, [128, 2, 116, 14, 14]);  cat_default_6 = None
        transpose_int_6 = torch.ops.aten.transpose.int(view_default_12, 1, 2);  view_default_12 = None
        clone_default_6 = torch.ops.aten.clone.default(transpose_int_6, memory_format = torch.contiguous_format);  transpose_int_6 = None
        view_default_13 = torch.ops.aten.view.default(clone_default_6, [128, -1, 14, 14]);  clone_default_6 = None
        split_tensor_5 = torch.ops.aten.split.Tensor(view_default_13, 116, 1);  view_default_13 = None
        getitem_90 = split_tensor_5[0]
        getitem_91 = split_tensor_5[1];  split_tensor_5 = None
        convolution_default_26 = torch.ops.aten.convolution.default(getitem_91, primals_165, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_170, primals_166, primals_168, primals_169, False, 0.1, 1e-05);  primals_166 = None
        getitem_92 = native_batch_norm_default_26[0];  native_batch_norm_default_26 = None
        relu__default_17 = torch.ops.aten.relu_.default(getitem_92);  getitem_92 = None
        convolution_default_27 = torch.ops.aten.convolution.default(relu__default_17, primals_171, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 116)
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_176, primals_172, primals_174, primals_175, False, 0.1, 1e-05);  primals_172 = None
        getitem_95 = native_batch_norm_default_27[0];  native_batch_norm_default_27 = None
        convolution_default_28 = torch.ops.aten.convolution.default(getitem_95, primals_177, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_182, primals_178, primals_180, primals_181, False, 0.1, 1e-05);  primals_178 = None
        getitem_98 = native_batch_norm_default_28[0];  native_batch_norm_default_28 = None
        relu__default_18 = torch.ops.aten.relu_.default(getitem_98);  getitem_98 = None
        cat_default_7 = torch.ops.aten.cat.default([getitem_90, relu__default_18], 1);  getitem_90 = None
        view_default_14 = torch.ops.aten.view.default(cat_default_7, [128, 2, 116, 14, 14]);  cat_default_7 = None
        transpose_int_7 = torch.ops.aten.transpose.int(view_default_14, 1, 2);  view_default_14 = None
        clone_default_7 = torch.ops.aten.clone.default(transpose_int_7, memory_format = torch.contiguous_format);  transpose_int_7 = None
        view_default_15 = torch.ops.aten.view.default(clone_default_7, [128, -1, 14, 14]);  clone_default_7 = None
        split_tensor_6 = torch.ops.aten.split.Tensor(view_default_15, 116, 1);  view_default_15 = None
        getitem_101 = split_tensor_6[0]
        getitem_102 = split_tensor_6[1];  split_tensor_6 = None
        convolution_default_29 = torch.ops.aten.convolution.default(getitem_102, primals_183, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_188, primals_184, primals_186, primals_187, False, 0.1, 1e-05);  primals_184 = None
        getitem_103 = native_batch_norm_default_29[0];  native_batch_norm_default_29 = None
        relu__default_19 = torch.ops.aten.relu_.default(getitem_103);  getitem_103 = None
        convolution_default_30 = torch.ops.aten.convolution.default(relu__default_19, primals_189, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 116)
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_194, primals_190, primals_192, primals_193, False, 0.1, 1e-05);  primals_190 = None
        getitem_106 = native_batch_norm_default_30[0];  native_batch_norm_default_30 = None
        convolution_default_31 = torch.ops.aten.convolution.default(getitem_106, primals_195, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_31, primals_200, primals_196, primals_198, primals_199, False, 0.1, 1e-05);  primals_196 = None
        getitem_109 = native_batch_norm_default_31[0];  native_batch_norm_default_31 = None
        relu__default_20 = torch.ops.aten.relu_.default(getitem_109);  getitem_109 = None
        cat_default_8 = torch.ops.aten.cat.default([getitem_101, relu__default_20], 1);  getitem_101 = None
        view_default_16 = torch.ops.aten.view.default(cat_default_8, [128, 2, 116, 14, 14]);  cat_default_8 = None
        transpose_int_8 = torch.ops.aten.transpose.int(view_default_16, 1, 2);  view_default_16 = None
        clone_default_8 = torch.ops.aten.clone.default(transpose_int_8, memory_format = torch.contiguous_format);  transpose_int_8 = None
        view_default_17 = torch.ops.aten.view.default(clone_default_8, [128, -1, 14, 14]);  clone_default_8 = None
        split_tensor_7 = torch.ops.aten.split.Tensor(view_default_17, 116, 1);  view_default_17 = None
        getitem_112 = split_tensor_7[0]
        getitem_113 = split_tensor_7[1];  split_tensor_7 = None
        convolution_default_32 = torch.ops.aten.convolution.default(getitem_113, primals_201, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_206, primals_202, primals_204, primals_205, False, 0.1, 1e-05);  primals_202 = None
        getitem_114 = native_batch_norm_default_32[0];  native_batch_norm_default_32 = None
        relu__default_21 = torch.ops.aten.relu_.default(getitem_114);  getitem_114 = None
        convolution_default_33 = torch.ops.aten.convolution.default(relu__default_21, primals_207, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 116)
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_212, primals_208, primals_210, primals_211, False, 0.1, 1e-05);  primals_208 = None
        getitem_117 = native_batch_norm_default_33[0];  native_batch_norm_default_33 = None
        convolution_default_34 = torch.ops.aten.convolution.default(getitem_117, primals_213, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_218, primals_214, primals_216, primals_217, False, 0.1, 1e-05);  primals_214 = None
        getitem_120 = native_batch_norm_default_34[0];  native_batch_norm_default_34 = None
        relu__default_22 = torch.ops.aten.relu_.default(getitem_120);  getitem_120 = None
        cat_default_9 = torch.ops.aten.cat.default([getitem_112, relu__default_22], 1);  getitem_112 = None
        view_default_18 = torch.ops.aten.view.default(cat_default_9, [128, 2, 116, 14, 14]);  cat_default_9 = None
        transpose_int_9 = torch.ops.aten.transpose.int(view_default_18, 1, 2);  view_default_18 = None
        clone_default_9 = torch.ops.aten.clone.default(transpose_int_9, memory_format = torch.contiguous_format);  transpose_int_9 = None
        view_default_19 = torch.ops.aten.view.default(clone_default_9, [128, -1, 14, 14]);  clone_default_9 = None
        split_tensor_8 = torch.ops.aten.split.Tensor(view_default_19, 116, 1);  view_default_19 = None
        getitem_123 = split_tensor_8[0]
        getitem_124 = split_tensor_8[1];  split_tensor_8 = None
        convolution_default_35 = torch.ops.aten.convolution.default(getitem_124, primals_219, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_224, primals_220, primals_222, primals_223, False, 0.1, 1e-05);  primals_220 = None
        getitem_125 = native_batch_norm_default_35[0];  native_batch_norm_default_35 = None
        relu__default_23 = torch.ops.aten.relu_.default(getitem_125);  getitem_125 = None
        convolution_default_36 = torch.ops.aten.convolution.default(relu__default_23, primals_225, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 116)
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_230, primals_226, primals_228, primals_229, False, 0.1, 1e-05);  primals_226 = None
        getitem_128 = native_batch_norm_default_36[0];  native_batch_norm_default_36 = None
        convolution_default_37 = torch.ops.aten.convolution.default(getitem_128, primals_231, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_37, primals_236, primals_232, primals_234, primals_235, False, 0.1, 1e-05);  primals_232 = None
        getitem_131 = native_batch_norm_default_37[0];  native_batch_norm_default_37 = None
        relu__default_24 = torch.ops.aten.relu_.default(getitem_131);  getitem_131 = None
        cat_default_10 = torch.ops.aten.cat.default([getitem_123, relu__default_24], 1);  getitem_123 = None
        view_default_20 = torch.ops.aten.view.default(cat_default_10, [128, 2, 116, 14, 14]);  cat_default_10 = None
        transpose_int_10 = torch.ops.aten.transpose.int(view_default_20, 1, 2);  view_default_20 = None
        clone_default_10 = torch.ops.aten.clone.default(transpose_int_10, memory_format = torch.contiguous_format);  transpose_int_10 = None
        view_default_21 = torch.ops.aten.view.default(clone_default_10, [128, -1, 14, 14]);  clone_default_10 = None
        split_tensor_9 = torch.ops.aten.split.Tensor(view_default_21, 116, 1);  view_default_21 = None
        getitem_134 = split_tensor_9[0]
        getitem_135 = split_tensor_9[1];  split_tensor_9 = None
        convolution_default_38 = torch.ops.aten.convolution.default(getitem_135, primals_237, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_242, primals_238, primals_240, primals_241, False, 0.1, 1e-05);  primals_238 = None
        getitem_136 = native_batch_norm_default_38[0];  native_batch_norm_default_38 = None
        relu__default_25 = torch.ops.aten.relu_.default(getitem_136);  getitem_136 = None
        convolution_default_39 = torch.ops.aten.convolution.default(relu__default_25, primals_243, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 116)
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_39, primals_248, primals_244, primals_246, primals_247, False, 0.1, 1e-05);  primals_244 = None
        getitem_139 = native_batch_norm_default_39[0];  native_batch_norm_default_39 = None
        convolution_default_40 = torch.ops.aten.convolution.default(getitem_139, primals_249, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_254, primals_250, primals_252, primals_253, False, 0.1, 1e-05);  primals_250 = None
        getitem_142 = native_batch_norm_default_40[0];  native_batch_norm_default_40 = None
        relu__default_26 = torch.ops.aten.relu_.default(getitem_142);  getitem_142 = None
        cat_default_11 = torch.ops.aten.cat.default([getitem_134, relu__default_26], 1);  getitem_134 = None
        view_default_22 = torch.ops.aten.view.default(cat_default_11, [128, 2, 116, 14, 14]);  cat_default_11 = None
        transpose_int_11 = torch.ops.aten.transpose.int(view_default_22, 1, 2);  view_default_22 = None
        clone_default_11 = torch.ops.aten.clone.default(transpose_int_11, memory_format = torch.contiguous_format);  transpose_int_11 = None
        view_default_23 = torch.ops.aten.view.default(clone_default_11, [128, -1, 14, 14]);  clone_default_11 = None
        convolution_default_41 = torch.ops.aten.convolution.default(view_default_23, primals_255, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 232)
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_41, primals_260, primals_256, primals_258, primals_259, False, 0.1, 1e-05);  primals_256 = None
        getitem_145 = native_batch_norm_default_41[0];  native_batch_norm_default_41 = None
        convolution_default_42 = torch.ops.aten.convolution.default(getitem_145, primals_261, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_42, primals_266, primals_262, primals_264, primals_265, False, 0.1, 1e-05);  primals_262 = None
        getitem_148 = native_batch_norm_default_42[0];  native_batch_norm_default_42 = None
        relu__default_27 = torch.ops.aten.relu_.default(getitem_148);  getitem_148 = None
        convolution_default_43 = torch.ops.aten.convolution.default(view_default_23, primals_267, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_43, primals_272, primals_268, primals_270, primals_271, False, 0.1, 1e-05);  primals_268 = None
        getitem_151 = native_batch_norm_default_43[0];  native_batch_norm_default_43 = None
        relu__default_28 = torch.ops.aten.relu_.default(getitem_151);  getitem_151 = None
        convolution_default_44 = torch.ops.aten.convolution.default(relu__default_28, primals_273, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 232)
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_278, primals_274, primals_276, primals_277, False, 0.1, 1e-05);  primals_274 = None
        getitem_154 = native_batch_norm_default_44[0];  native_batch_norm_default_44 = None
        convolution_default_45 = torch.ops.aten.convolution.default(getitem_154, primals_279, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_45, primals_284, primals_280, primals_282, primals_283, False, 0.1, 1e-05);  primals_280 = None
        getitem_157 = native_batch_norm_default_45[0];  native_batch_norm_default_45 = None
        relu__default_29 = torch.ops.aten.relu_.default(getitem_157);  getitem_157 = None
        cat_default_12 = torch.ops.aten.cat.default([relu__default_27, relu__default_29], 1)
        view_default_24 = torch.ops.aten.view.default(cat_default_12, [128, 2, 232, 7, 7]);  cat_default_12 = None
        transpose_int_12 = torch.ops.aten.transpose.int(view_default_24, 1, 2);  view_default_24 = None
        clone_default_12 = torch.ops.aten.clone.default(transpose_int_12, memory_format = torch.contiguous_format);  transpose_int_12 = None
        view_default_25 = torch.ops.aten.view.default(clone_default_12, [128, -1, 7, 7]);  clone_default_12 = None
        split_tensor_10 = torch.ops.aten.split.Tensor(view_default_25, 232, 1);  view_default_25 = None
        getitem_160 = split_tensor_10[0]
        getitem_161 = split_tensor_10[1];  split_tensor_10 = None
        convolution_default_46 = torch.ops.aten.convolution.default(getitem_161, primals_285, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(convolution_default_46, primals_290, primals_286, primals_288, primals_289, False, 0.1, 1e-05);  primals_286 = None
        getitem_162 = native_batch_norm_default_46[0];  native_batch_norm_default_46 = None
        relu__default_30 = torch.ops.aten.relu_.default(getitem_162);  getitem_162 = None
        convolution_default_47 = torch.ops.aten.convolution.default(relu__default_30, primals_291, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 232)
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(convolution_default_47, primals_296, primals_292, primals_294, primals_295, False, 0.1, 1e-05);  primals_292 = None
        getitem_165 = native_batch_norm_default_47[0];  native_batch_norm_default_47 = None
        convolution_default_48 = torch.ops.aten.convolution.default(getitem_165, primals_297, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_48, primals_302, primals_298, primals_300, primals_301, False, 0.1, 1e-05);  primals_298 = None
        getitem_168 = native_batch_norm_default_48[0];  native_batch_norm_default_48 = None
        relu__default_31 = torch.ops.aten.relu_.default(getitem_168);  getitem_168 = None
        cat_default_13 = torch.ops.aten.cat.default([getitem_160, relu__default_31], 1);  getitem_160 = None
        view_default_26 = torch.ops.aten.view.default(cat_default_13, [128, 2, 232, 7, 7]);  cat_default_13 = None
        transpose_int_13 = torch.ops.aten.transpose.int(view_default_26, 1, 2);  view_default_26 = None
        clone_default_13 = torch.ops.aten.clone.default(transpose_int_13, memory_format = torch.contiguous_format);  transpose_int_13 = None
        view_default_27 = torch.ops.aten.view.default(clone_default_13, [128, -1, 7, 7]);  clone_default_13 = None
        split_tensor_11 = torch.ops.aten.split.Tensor(view_default_27, 232, 1);  view_default_27 = None
        getitem_171 = split_tensor_11[0]
        getitem_172 = split_tensor_11[1];  split_tensor_11 = None
        convolution_default_49 = torch.ops.aten.convolution.default(getitem_172, primals_303, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(convolution_default_49, primals_308, primals_304, primals_306, primals_307, False, 0.1, 1e-05);  primals_304 = None
        getitem_173 = native_batch_norm_default_49[0];  native_batch_norm_default_49 = None
        relu__default_32 = torch.ops.aten.relu_.default(getitem_173);  getitem_173 = None
        convolution_default_50 = torch.ops.aten.convolution.default(relu__default_32, primals_309, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 232)
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(convolution_default_50, primals_314, primals_310, primals_312, primals_313, False, 0.1, 1e-05);  primals_310 = None
        getitem_176 = native_batch_norm_default_50[0];  native_batch_norm_default_50 = None
        convolution_default_51 = torch.ops.aten.convolution.default(getitem_176, primals_315, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(convolution_default_51, primals_320, primals_316, primals_318, primals_319, False, 0.1, 1e-05);  primals_316 = None
        getitem_179 = native_batch_norm_default_51[0];  native_batch_norm_default_51 = None
        relu__default_33 = torch.ops.aten.relu_.default(getitem_179);  getitem_179 = None
        cat_default_14 = torch.ops.aten.cat.default([getitem_171, relu__default_33], 1);  getitem_171 = None
        view_default_28 = torch.ops.aten.view.default(cat_default_14, [128, 2, 232, 7, 7]);  cat_default_14 = None
        transpose_int_14 = torch.ops.aten.transpose.int(view_default_28, 1, 2);  view_default_28 = None
        clone_default_14 = torch.ops.aten.clone.default(transpose_int_14, memory_format = torch.contiguous_format);  transpose_int_14 = None
        view_default_29 = torch.ops.aten.view.default(clone_default_14, [128, -1, 7, 7]);  clone_default_14 = None
        split_tensor_12 = torch.ops.aten.split.Tensor(view_default_29, 232, 1);  view_default_29 = None
        getitem_182 = split_tensor_12[0]
        getitem_183 = split_tensor_12[1];  split_tensor_12 = None
        convolution_default_52 = torch.ops.aten.convolution.default(getitem_183, primals_321, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(convolution_default_52, primals_326, primals_322, primals_324, primals_325, False, 0.1, 1e-05);  primals_322 = None
        getitem_184 = native_batch_norm_default_52[0];  native_batch_norm_default_52 = None
        relu__default_34 = torch.ops.aten.relu_.default(getitem_184);  getitem_184 = None
        convolution_default_53 = torch.ops.aten.convolution.default(relu__default_34, primals_327, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 232)
        native_batch_norm_default_53 = torch.ops.aten.native_batch_norm.default(convolution_default_53, primals_332, primals_328, primals_330, primals_331, False, 0.1, 1e-05);  primals_328 = None
        getitem_187 = native_batch_norm_default_53[0];  native_batch_norm_default_53 = None
        convolution_default_54 = torch.ops.aten.convolution.default(getitem_187, primals_333, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_54 = torch.ops.aten.native_batch_norm.default(convolution_default_54, primals_338, primals_334, primals_336, primals_337, False, 0.1, 1e-05);  primals_334 = None
        getitem_190 = native_batch_norm_default_54[0];  native_batch_norm_default_54 = None
        relu__default_35 = torch.ops.aten.relu_.default(getitem_190);  getitem_190 = None
        cat_default_15 = torch.ops.aten.cat.default([getitem_182, relu__default_35], 1);  getitem_182 = None
        view_default_30 = torch.ops.aten.view.default(cat_default_15, [128, 2, 232, 7, 7]);  cat_default_15 = None
        transpose_int_15 = torch.ops.aten.transpose.int(view_default_30, 1, 2);  view_default_30 = None
        clone_default_15 = torch.ops.aten.clone.default(transpose_int_15, memory_format = torch.contiguous_format);  transpose_int_15 = None
        view_default_31 = torch.ops.aten.view.default(clone_default_15, [128, -1, 7, 7]);  clone_default_15 = None
        convolution_default_55 = torch.ops.aten.convolution.default(view_default_31, primals_7, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_55 = torch.ops.aten.native_batch_norm.default(convolution_default_55, primals_12, primals_8, primals_10, primals_11, False, 0.1, 1e-05);  primals_8 = None
        getitem_193 = native_batch_norm_default_55[0];  native_batch_norm_default_55 = None
        relu__default_36 = torch.ops.aten.relu_.default(getitem_193);  getitem_193 = None
        mean_dim = torch.ops.aten.mean.dim(relu__default_36, [2, 3])
        t_default = torch.ops.aten.t.default(primals_14);  primals_14 = None
        addmm_default = torch.ops.aten.addmm.default(primals_13, mean_dim, t_default);  primals_13 = None
        return [addmm_default, primals_93, primals_156, relu__default_16, relu__default_31, primals_157, convolution_default_26, primals_158, primals_96, primals_159, primals_97, primals_98, getitem_91, primals_99, primals_162, primals_163, primals_164, primals_102, primals_165, primals_103, primals_104, getitem_95, primals_105, primals_168, relu__default_17, primals_169, convolution_default_27, primals_170, convolution_default_49, getitem_172, primals_108, primals_171, primals_109, relu__default_32, primals_110, primals_111, primals_174, primals_175, convolution_default_50, primals_176, relu__default_10, primals_198, primals_261, convolution_default_17, primals_199, relu__default_25, getitem_43, convolution_default_39, primals_200, primals_338, convolution_default_12, primals_201, primals_264, convolution_default_46, primals_265, primals_333, primals_266, primals_339, primals_204, primals_267, primals_205, primals_206, getitem_161, relu__default_8, getitem_139, primals_207, primals_270, relu__default_11, primals_271, convolution_default_13, convolution_default_40, convolution_default_18, relu__default_30, primals_272, primals_210, primals_273, convolution_default_47, primals_211, primals_212, getitem_47, primals_213, primals_276, getitem_62, primals_277, convolution_default_14, convolution_default_19, primals_278, relu__default_26, primals_216, primals_279, convolution_default_48, primals_217, getitem_165, primals_218, primals_135, getitem_113, primals_27, relu__default_35, relu__default_21, primals_32, relu__default_5, convolution_default_33, convolution_default_8, primals_18, primals_138, mean_dim, primals_139, primals_20, primals_140, primals_141, convolution_default_55, convolution_default_34, getitem_25, view_default_31, primals_144, primals_33, primals_21, primals_145, getitem_117, primals_146, primals_31, relu__default_36, primals_147, t_default, primals_19, primals_25, primals_24, primals_26, primals_150, primals_151, primals_30, primals_152, primals_153, convolution_default_9, getitem_32, primals_313, convolution_default_37, primals_6, primals_318, getitem_128, getitem_84, convolution_default_51, getitem_80, relu__default_24, primals_306, primals_315, relu__default_15, primals_300, primals_314, primals_7, primals_302, relu__default_33, primals_10, primals_11, convolution_default_24, primals_5, primals_4, getitem_176, primals_12, primals_301, convolution_default_25, primals_303, primals_1, primals_308, primals_307, convolution_default_52, primals_312, primals_15, convolution_default_38, getitem_135, primals_309, primals_240, getitem_154, relu__default_19, convolution_default_30, primals_61, primals_241, primals_331, primals_66, primals_242, getitem_183, getitem_106, primals_243, primals_68, primals_60, primals_69, primals_246, convolution_default_54, primals_247, convolution_default_44, primals_67, relu__default_28, primals_248, primals_321, primals_62, primals_249, getitem_187, primals_324, convolution_default_53, primals_72, relu__default_34, convolution_default_45, primals_252, convolution_default_31, primals_320, primals_253, primals_254, primals_255, primals_327, primals_56, primals_325, primals_63, primals_319, relu__default_29, convolution_default_32, primals_258, convolution_default, primals_57, primals_259, primals_332, primals_326, relu__default_20, primals_260, primals_330, primals_297, primals_289, primals_114, primals_177, primals_51, relu__default_18, relu__default, primals_115, primals_50, convolution_default_28, primals_116, primals_295, getitem_5, primals_49, primals_117, primals_180, primals_87, getitem_4, primals_86, primals_48, primals_181, getitem_3, primals_182, primals_282, primals_85, primals_75, primals_120, primals_183, primals_121, primals_36, primals_84, primals_122, primals_92, primals_294, primals_73, primals_123, primals_186, primals_79, primals_296, convolution_default_1, primals_54, primals_91, primals_187, primals_337, convolution_default_3, primals_55, primals_74, primals_37, primals_188, convolution_default_2, primals_283, primals_126, primals_189, primals_38, relu__default_1, primals_127, primals_44, primals_290, primals_336, primals_81, primals_45, primals_128, primals_43, primals_80, primals_291, primals_129, primals_192, primals_284, primals_90, primals_285, primals_42, primals_193, getitem_102, convolution_default_29, primals_194, primals_132, primals_195, primals_39, primals_133, primals_134, primals_288, primals_78, relu__default_3, relu__default_2, convolution_default_22, convolution_default_4, relu__default_6, convolution_default_10, relu__default_9, relu__default_12, getitem_36, relu__default_14, convolution_default_5, relu__default_4, convolution_default_11, getitem_14, getitem_73, getitem_21, convolution_default_15, getitem_53, convolution_default_6, view_default_7, convolution_default_16, convolution_default_20, getitem_69, relu__default_7, relu__default_13, convolution_default_21, convolution_default_7, convolution_default_23, relu__default_22, primals_219, primals_222, getitem_145, convolution_default_41, primals_223, primals_224, primals_225, convolution_default_42, convolution_default_35, view_default_23, primals_228, primals_229, relu__default_23, getitem_124, primals_230, primals_231, relu__default_27, primals_234, convolution_default_43, primals_235, convolution_default_36, primals_236, primals_237]
        
