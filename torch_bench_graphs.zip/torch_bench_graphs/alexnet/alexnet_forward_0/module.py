
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/alexnet/alexnet_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17):
        convolution_default = torch.ops.aten.convolution.default(primals_17, primals_8, primals_7, [4, 4], [2, 2], [1, 1], False, [0, 0], 1);  primals_7 = None
        relu__default = torch.ops.aten.relu_.default(convolution_default);  convolution_default = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu__default, [3, 3], [2, 2])
        getitem = max_pool2d_with_indices_default[0]
        getitem_1 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_1 = torch.ops.aten.convolution.default(getitem, primals_12, primals_11, [1, 1], [2, 2], [1, 1], False, [0, 0], 1);  primals_11 = None
        relu__default_1 = torch.ops.aten.relu_.default(convolution_default_1);  convolution_default_1 = None
        max_pool2d_with_indices_default_1 = torch.ops.aten.max_pool2d_with_indices.default(relu__default_1, [3, 3], [2, 2])
        getitem_2 = max_pool2d_with_indices_default_1[0]
        getitem_3 = max_pool2d_with_indices_default_1[1];  max_pool2d_with_indices_default_1 = None
        convolution_default_2 = torch.ops.aten.convolution.default(getitem_2, primals_14, primals_13, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_13 = None
        relu__default_2 = torch.ops.aten.relu_.default(convolution_default_2);  convolution_default_2 = None
        convolution_default_3 = torch.ops.aten.convolution.default(relu__default_2, primals_16, primals_15, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_15 = None
        relu__default_3 = torch.ops.aten.relu_.default(convolution_default_3);  convolution_default_3 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu__default_3, primals_10, primals_9, [1, 1], [1, 1], [1, 1], False, [0, 0], 1);  primals_9 = None
        relu__default_4 = torch.ops.aten.relu_.default(convolution_default_4);  convolution_default_4 = None
        max_pool2d_with_indices_default_2 = torch.ops.aten.max_pool2d_with_indices.default(relu__default_4, [3, 3], [2, 2])
        getitem_4 = max_pool2d_with_indices_default_2[0]
        getitem_5 = max_pool2d_with_indices_default_2[1];  max_pool2d_with_indices_default_2 = None
        _adaptive_avg_pool2d_default = torch.ops.aten._adaptive_avg_pool2d.default(getitem_4, [6, 6])
        view_default = torch.ops.aten.view.default(_adaptive_avg_pool2d_default, [128, 9216]);  _adaptive_avg_pool2d_default = None
        t_default = torch.ops.aten.t.default(primals_2);  primals_2 = None
        addmm_default = torch.ops.aten.addmm.default(primals_1, view_default, t_default);  primals_1 = None
        relu__default_5 = torch.ops.aten.relu_.default(addmm_default);  addmm_default = None
        t_default_1 = torch.ops.aten.t.default(primals_4);  primals_4 = None
        addmm_default_1 = torch.ops.aten.addmm.default(primals_3, relu__default_5, t_default_1);  primals_3 = None
        relu__default_6 = torch.ops.aten.relu_.default(addmm_default_1);  addmm_default_1 = None
        t_default_2 = torch.ops.aten.t.default(primals_6);  primals_6 = None
        addmm_default_2 = torch.ops.aten.addmm.default(primals_5, relu__default_6, t_default_2);  primals_5 = None
        return [addmm_default_2, primals_17, t_default_1, getitem, relu__default_2, primals_16, primals_8, getitem_5, getitem_1, relu__default_6, primals_10, getitem_4, relu__default_1, relu__default_3, view_default, t_default, t_default_2, primals_12, getitem_2, primals_14, getitem_3, relu__default_5, relu__default_4, relu__default]
        
