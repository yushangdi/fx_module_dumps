
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/dcgan/dcgan_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21):
        convolution_default = torch.ops.aten.convolution.default(primals_21, primals_1, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        leaky_relu__default = torch.ops.aten.leaky_relu_.default(convolution_default, 0.2);  convolution_default = None
        convolution_default_1 = torch.ops.aten.convolution.default(leaky_relu__default, primals_3, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_8, primals_4, primals_6, primals_7, False, 0.1, 1e-05);  primals_4 = None
        getitem = native_batch_norm_default[0];  native_batch_norm_default = None
        leaky_relu__default_1 = torch.ops.aten.leaky_relu_.default(getitem, 0.2);  getitem = None
        convolution_default_2 = torch.ops.aten.convolution.default(leaky_relu__default_1, primals_9, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_14, primals_10, primals_12, primals_13, False, 0.1, 1e-05);  primals_10 = None
        getitem_3 = native_batch_norm_default_1[0];  native_batch_norm_default_1 = None
        leaky_relu__default_2 = torch.ops.aten.leaky_relu_.default(getitem_3, 0.2);  getitem_3 = None
        convolution_default_3 = torch.ops.aten.convolution.default(leaky_relu__default_2, primals_15, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_20, primals_16, primals_18, primals_19, False, 0.1, 1e-05);  primals_16 = None
        getitem_6 = native_batch_norm_default_2[0];  native_batch_norm_default_2 = None
        leaky_relu__default_3 = torch.ops.aten.leaky_relu_.default(getitem_6, 0.2);  getitem_6 = None
        convolution_default_4 = torch.ops.aten.convolution.default(leaky_relu__default_3, primals_2, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        sigmoid_default = torch.ops.aten.sigmoid.default(convolution_default_4);  convolution_default_4 = None
        return [sigmoid_default, primals_21, primals_14, primals_6, primals_7, leaky_relu__default_3, primals_13, sigmoid_default, primals_12, primals_9, convolution_default_2, convolution_default_1, leaky_relu__default, primals_15, primals_1, leaky_relu__default_1, primals_2, primals_3, leaky_relu__default_2, primals_18, primals_8, convolution_default_3, primals_19, primals_20]
        
