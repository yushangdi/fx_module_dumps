
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'torch_bench_graphs/dcgan/dcgan_joint_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, tangents_1):
        convolution_default = torch.ops.aten.convolution.default(primals_21, primals_1, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        leaky_relu__default = torch.ops.aten.leaky_relu_.default(convolution_default, 0.2);  convolution_default = None
        convolution_default_1 = torch.ops.aten.convolution.default(leaky_relu__default, primals_3, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_8, primals_4, primals_6, primals_7, False, 0.1, 1e-05);  primals_4 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        new_zeros_default = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_2 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        leaky_relu__default_1 = torch.ops.aten.leaky_relu_.default(getitem, 0.2);  getitem = None
        convolution_default_2 = torch.ops.aten.convolution.default(leaky_relu__default_1, primals_9, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_14, primals_10, primals_12, primals_13, False, 0.1, 1e-05);  primals_10 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_5 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        leaky_relu__default_2 = torch.ops.aten.leaky_relu_.default(getitem_3, 0.2);  getitem_3 = None
        convolution_default_3 = torch.ops.aten.convolution.default(leaky_relu__default_2, primals_15, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_20, primals_16, primals_18, primals_19, False, 0.1, 1e-05);  primals_16 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        new_zeros_default_8 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        leaky_relu__default_3 = torch.ops.aten.leaky_relu_.default(getitem_6, 0.2);  getitem_6 = None
        convolution_default_4 = torch.ops.aten.convolution.default(leaky_relu__default_3, primals_2, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        sigmoid_default = torch.ops.aten.sigmoid.default(convolution_default_4);  convolution_default_4 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(sigmoid_default, tangents_1)
        to_dtype = torch.ops.aten.to.dtype(tangents_1, torch.float32);  tangents_1 = None
        to_dtype_1 = torch.ops.aten.to.dtype(sigmoid_default, torch.float32)
        rsub_scalar = torch.ops.aten.rsub.Scalar(to_dtype_1, 1)
        mul_tensor = torch.ops.aten.mul.Tensor(to_dtype_1, rsub_scalar);  to_dtype_1 = rsub_scalar = None
        conj_physical_default = torch.ops.aten.conj_physical.default(mul_tensor);  mul_tensor = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(to_dtype, conj_physical_default);  to_dtype = conj_physical_default = None
        to_dtype_2 = torch.ops.aten.to.dtype(mul_tensor_1, torch.float32);  mul_tensor_1 = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(to_dtype_2, leaky_relu__default_3, primals_2, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  to_dtype_2 = primals_2 = None
        getitem_9 = convolution_backward_default[0]
        getitem_10 = convolution_backward_default[1]
        getitem_11 = convolution_backward_default[2];  convolution_backward_default = None
        to_dtype_3 = torch.ops.aten.to.dtype(getitem_9, torch.float32);  getitem_9 = None
        to_dtype_4 = torch.ops.aten.to.dtype(leaky_relu__default_3, torch.float32);  leaky_relu__default_3 = None
        gt_scalar = torch.ops.aten.gt.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(to_dtype_3, 0.2)
        where_self = torch.ops.aten.where.self(gt_scalar, to_dtype_3, mul_tensor_2);  gt_scalar = to_dtype_3 = mul_tensor_2 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_5, convolution_default_3, primals_20, primals_18, primals_19, new_zeros_default_6, new_zeros_default_7, False, 1e-05, [True, True, True]);  to_dtype_5 = convolution_default_3 = primals_20 = primals_18 = primals_19 = new_zeros_default_6 = new_zeros_default_7 = None
        getitem_12 = native_batch_norm_backward_default[0]
        getitem_13 = native_batch_norm_backward_default[1]
        getitem_14 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_12, leaky_relu__default_2, primals_15, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_12 = primals_15 = None
        getitem_15 = convolution_backward_default_1[0]
        getitem_16 = convolution_backward_default_1[1]
        getitem_17 = convolution_backward_default_1[2];  convolution_backward_default_1 = None
        to_dtype_6 = torch.ops.aten.to.dtype(getitem_15, torch.float32);  getitem_15 = None
        to_dtype_7 = torch.ops.aten.to.dtype(leaky_relu__default_2, torch.float32);  leaky_relu__default_2 = None
        gt_scalar_1 = torch.ops.aten.gt.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(to_dtype_6, 0.2)
        where_self_1 = torch.ops.aten.where.self(gt_scalar_1, to_dtype_6, mul_tensor_3);  gt_scalar_1 = to_dtype_6 = mul_tensor_3 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_8, convolution_default_2, primals_14, primals_12, primals_13, new_zeros_default_3, new_zeros_default_4, False, 1e-05, [True, True, True]);  to_dtype_8 = convolution_default_2 = primals_14 = primals_12 = primals_13 = new_zeros_default_3 = new_zeros_default_4 = None
        getitem_18 = native_batch_norm_backward_default_1[0]
        getitem_19 = native_batch_norm_backward_default_1[1]
        getitem_20 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_18, leaky_relu__default_1, primals_9, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_18 = primals_9 = None
        getitem_21 = convolution_backward_default_2[0]
        getitem_22 = convolution_backward_default_2[1]
        getitem_23 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        to_dtype_9 = torch.ops.aten.to.dtype(getitem_21, torch.float32);  getitem_21 = None
        to_dtype_10 = torch.ops.aten.to.dtype(leaky_relu__default_1, torch.float32);  leaky_relu__default_1 = None
        gt_scalar_2 = torch.ops.aten.gt.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(to_dtype_9, 0.2)
        where_self_2 = torch.ops.aten.where.self(gt_scalar_2, to_dtype_9, mul_tensor_4);  gt_scalar_2 = to_dtype_9 = mul_tensor_4 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_1, primals_8, primals_6, primals_7, new_zeros_default, new_zeros_default_1, False, 1e-05, [True, True, True]);  to_dtype_11 = convolution_default_1 = primals_8 = primals_6 = primals_7 = new_zeros_default = new_zeros_default_1 = None
        getitem_24 = native_batch_norm_backward_default_2[0]
        getitem_25 = native_batch_norm_backward_default_2[1]
        getitem_26 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_24, leaky_relu__default, primals_3, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_24 = primals_3 = None
        getitem_27 = convolution_backward_default_3[0]
        getitem_28 = convolution_backward_default_3[1]
        getitem_29 = convolution_backward_default_3[2];  convolution_backward_default_3 = None
        to_dtype_12 = torch.ops.aten.to.dtype(getitem_27, torch.float32);  getitem_27 = None
        to_dtype_13 = torch.ops.aten.to.dtype(leaky_relu__default, torch.float32);  leaky_relu__default = None
        gt_scalar_3 = torch.ops.aten.gt.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(to_dtype_12, 0.2)
        where_self_3 = torch.ops.aten.where.self(gt_scalar_3, to_dtype_12, mul_tensor_5);  gt_scalar_3 = to_dtype_12 = mul_tensor_5 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(to_dtype_14, primals_21, primals_1, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [False, True, False]);  to_dtype_14 = primals_21 = primals_1 = None
        getitem_30 = convolution_backward_default_4[0]
        getitem_31 = convolution_backward_default_4[1]
        getitem_32 = convolution_backward_default_4[2];  convolution_backward_default_4 = None
        return [sigmoid_default, getitem_31, getitem_10, getitem_28, getitem_26, None, None, None, getitem_25, getitem_22, getitem_20, None, None, None, getitem_19, getitem_16, getitem_14, None, None, None, getitem_13, None]
        
