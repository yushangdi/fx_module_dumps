
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/tf_efficientnet_b0_ns/tf_efficientnet_b0_ns_backward_0/state_dict.pt'))

    
    
    def forward(self, primals_11, primals_36, primals_238, primals_37, convolution_default_19, primals_240, primals_248, getitem_33, primals_99, getitem_71, mul_tensor_3, convolution_default_40, primals_188, primals_239, getitem_70, primals_148, primals_185, primals_195, getitem_72, primals_199, primals_173, getitem_35, primals_14, primals_180, getitem_36, getitem_34, primals_30, primals_340, add_tensor_27, primals_230, primals_344, primals_234, primals_348, primals_174, getitem_74, primals_179, primals_254, convolution_default_20, primals_8, primals_145, getitem_73, primals_189, primals_29, primals_13, primals_178, primals_193, primals_253, primals_338, getitem_38, primals_9, primals_343, getitem_37, primals_28, primals_190, primals_235, primals_175, primals_255, primals_7, primals_100, primals_184, primals_6, primals_194, primals_345, primals_4, primals_34, primals_250, primals_39, primals_339, silu__default_24, primals_233, primals_183, primals_102, primals_198, primals_229, primals_249, convolution_default_21, convolution_default_41, primals_32, primals_35, silu__default_12, getitem_116, sigmoid_default_1, primals_353, convolution_default_9, getitem_41, mean_dim_4, getitem_115, add_tensor_45, getitem_40, convolution_default_22, silu__default_37, primals_349, primals_150, primals_355, primals_354, getitem_119, getitem_16, getitem_118, getitem_17, convolution_default_62, getitem_15, getitem_18, getitem_39, silu__default_13, silu__default_38, primals_129, getitem_117, convolution_default_10, getitem_19, primals_358, primals_130, silu__default_39, mul_tensor_12, primals_258, primals_153, convolution_default_66, sigmoid_default_12, mean_dim_13, primals_259, getitem_20, getitem_121, silu__default_14, convolution_default_64, getitem_120, mul_tensor_4, primals_149, primals_350, convolution_default_65, sigmoid_default_4, getitem_122, convolution_default_11, primals_128, primals_107, primals_214, getitem_98, getitem_95, getitem_99, silu__default_6, primals_104, primals_106, primals_245, getitem_97, primals_105, primals_315, getitem_13, primals_244, mean_dim_1, getitem_43, getitem_23, getitem_44, add_tensor_38, getitem_12, mean_dim_2, convolution_default_25, getitem_22, convolution_default_24, silu__default_31, primals_319, getitem_14, getitem_45, getitem_101, convolution_default_55, primals_219, getitem_100, convolution_default_52, add_tensor_16, getitem_21, mul_tensor_1, primals_208, getitem_105, primals_314, silu__default_7, getitem_47, silu__default_32, constant_pad_nd_default_3, silu__default_4, getitem_46, primals_93, primals_213, convolution_default_12, convolution_default_7, primals_215, primals_313, sigmoid_default_10, constant_pad_nd_default, sigmoid_default_2, getitem_102, primals_218, mul_tensor_10, primals_210, primals_318, convolution_default_54, constant_pad_nd_default_4, primals_209, convolution_default_56, primals_243, silu__default_8, mean_dim_11, primals_95, mul_tensor_2, getitem_103, convolution_default_26, silu__default_5, primals_86, getitem_6, primals_323, mean_dim_6, getitem_80, mul_tensor, convolution_default_14, getitem_59, primals_324, add_tensor_53, getitem_58, getitem_79, getitem_81, sigmoid_default, getitem_61, silu__default_43, primals_84, getitem_62, convolution_default_4, convolution_default_35, convolution_default_34, getitem_137, getitem_63, getitem_136, primals_160, getitem_25, convolution_default_72, getitem_26, convolution_default_15, convolution_default_45, convolution_default_32, getitem_7, getitem_8, getitem_27, add_tensor_23, primals_92, primals_308, silu__default_19, getitem_83, getitem_57, silu__default_44, getitem_78, getitem_9, primals_88, getitem_82, getitem_135, getitem_65, convolution_default_75, getitem_28, add_tensor_9, convolution_default_76, primals_159, getitem_64, sigmoid_default_14, silu__default_45, convolution_default_5, getitem_10, primals_325, getitem_139, convolution_default_16, constant_pad_nd_default_2, getitem_138, convolution_default_6, getitem_29, constant_pad_nd_default_1, convolution_default_74, silu__default_20, silu__default_27, mean_dim_15, primals_83, primals_320, getitem_11, primals_91, silu__default_21, getitem_140, convolution_default_46, primals_305, getitem_133, mul_tensor_14, primals_90, mul_tensor_6, sigmoid_default_6, getitem_134, convolution_default_36, getitem_84, primals_81, primals_85, getitem_77, convolution_default_42, primals_21, primals_203, getitem_76, primals_275, getitem_75, primals_16, primals_274, primals_15, silu__default_25, mean_dim_8, primals_20, primals_25, primals_204, primals_273, primals_23, silu__default_26, primals_22, primals_200, primals_18, primals_27, sigmoid_default_8, primals_205, mul_tensor_8, convolution_default_44, primals_115, primals_155, primals_169, primals_119, primals_164, primals_114, primals_163, primals_260, primals_170, primals_111, primals_123, primals_125, convolution_default_39, primals_158, primals_168, primals_120, primals_360, primals_165, primals_359, primals_124, primals_154, primals_118, primals_69, getitem_48, getitem_89, primals_49, getitem_51, convolution_default_29, getitem_86, getitem_104, getitem_106, getitem_88, getitem_90, convolution_default_80, getitem_144, getitem_49, getitem_107, primals_71, getitem_85, primals_2, silu__default, convolution_default_27, primals_56, primals_269, mean_dim_5, getitem_54, convolution_default_47, getitem_146, getitem_50, getitem_52, mean_dim_9, getitem_53, getitem_108, primals_55, convolution_default_60, getitem_145, primals_77, view_default, primals_330, silu__default_34, add_tensor_34, primals_329, getitem_5, silu__default_28, primals_220, mean_dim, primals_334, getitem_110, primals_76, getitem_4, mean_dim_12, getitem_109, getitem_92, convolution_default_57, primals_53, primals_263, convolution_default_50, mean_dim_10, convolution_default_30, primals_57, getitem_91, primals_223, primals_74, primals_264, silu__default_16, primals_328, primals_225, primals_48, primals_78, primals_50, primals_333, getitem_56, getitem_3, silu__default_35, primals_79, getitem_55, silu__default_29, primals_224, primals_268, silu__default_1, silu__default_36, getitem, primals_44, primals_46, primals_265, primals_335, getitem_1, convolution_default_2, silu__default_30, sigmoid_default_11, primals_72, convolution_default, convolution_default_61, t_default, getitem_111, sigmoid_default_9, silu__default_17, mul_tensor_11, primals_228, convolution_default_51, primals_70, getitem_93, convolution_default_59, mul_tensor_9, mul_tensor_5, silu__default_18, convolution_default_49, primals_270, getitem_2, getitem_112, primals_1, sigmoid_default_5, getitem_113, primals_51, convolution_default_1, silu__default_2, convolution_default_31, getitem_94, primals_58, primals_109, getitem_125, getitem_31, getitem_68, primals_304, primals_134, primals_278, getitem_67, primals_284, convolution_default_37, primals_290, silu__default_46, primals_60, mean_dim_3, add_tensor_49, silu__default_40, primals_97, getitem_66, primals_303, getitem_30, primals_294, convolution_default_77, primals_41, primals_135, getitem_32, primals_279, getitem_128, primals_143, getitem_127, convolution_default_67, primals_309, primals_63, primals_62, primals_310, primals_64, primals_140, silu__default_22, primals_43, mean_dim_7, silu__default_47, primals_139, primals_288, primals_283, silu__default_41, getitem_142, primals_98, primals_285, sigmoid_default_15, getitem_126, primals_42, primals_280, silu__default_10, primals_300, silu__default_42, primals_295, convolution_default_17, mul_tensor_13, primals_144, silu__default_23, convolution_default_71, sigmoid_default_13, getitem_130, convolution_default_79, primals_298, primals_133, getitem_129, sigmoid_default_3, convolution_default_69, mean_dim_14, getitem_141, primals_65, primals_289, sigmoid_default_7, mul_tensor_15, getitem_143, primals_67, getitem_131, primals_299, silu__default_11, convolution_default_70, mul_tensor_7, getitem_124, primals_293, primals_138, tangents_1, tangents_2, tangents_3, tangents_4, tangents_5, tangents_6, tangents_7, tangents_8, tangents_9, tangents_10, tangents_11, tangents_12, tangents_13, tangents_14, tangents_15, tangents_16, tangents_17, tangents_18, tangents_19, tangents_20, tangents_21, tangents_22, tangents_23, tangents_24, tangents_25, tangents_26, tangents_27, tangents_28, tangents_29, tangents_30, tangents_31, tangents_32, tangents_33, tangents_34, tangents_35, tangents_36, tangents_37, tangents_38, tangents_39, tangents_40, tangents_41, tangents_42, tangents_43, tangents_44, tangents_45, tangents_46, tangents_47, tangents_48, tangents_49, tangents_50):
        clone_default = torch.ops.aten.clone.default(getitem);  getitem = None
        clone_default_1 = torch.ops.aten.clone.default(getitem_3);  getitem_3 = None
        clone_default_2 = torch.ops.aten.clone.default(convolution_default_2);  convolution_default_2 = None
        clone_default_3 = torch.ops.aten.clone.default(getitem_9);  getitem_9 = None
        clone_default_4 = torch.ops.aten.clone.default(getitem_12);  getitem_12 = None
        clone_default_5 = torch.ops.aten.clone.default(convolution_default_7);  convolution_default_7 = None
        clone_default_6 = torch.ops.aten.clone.default(getitem_18);  getitem_18 = None
        clone_default_7 = torch.ops.aten.clone.default(getitem_21);  getitem_21 = None
        clone_default_8 = torch.ops.aten.clone.default(convolution_default_12);  convolution_default_12 = None
        clone_default_9 = torch.ops.aten.clone.default(getitem_27);  getitem_27 = None
        clone_default_10 = torch.ops.aten.clone.default(getitem_30);  getitem_30 = None
        clone_default_11 = torch.ops.aten.clone.default(convolution_default_17);  convolution_default_17 = None
        clone_default_12 = torch.ops.aten.clone.default(getitem_36);  getitem_36 = None
        clone_default_13 = torch.ops.aten.clone.default(getitem_39);  getitem_39 = None
        clone_default_14 = torch.ops.aten.clone.default(convolution_default_22);  convolution_default_22 = None
        clone_default_15 = torch.ops.aten.clone.default(getitem_45);  getitem_45 = None
        clone_default_16 = torch.ops.aten.clone.default(getitem_48);  getitem_48 = None
        clone_default_17 = torch.ops.aten.clone.default(convolution_default_27);  convolution_default_27 = None
        clone_default_18 = torch.ops.aten.clone.default(getitem_54);  getitem_54 = None
        clone_default_19 = torch.ops.aten.clone.default(getitem_57);  getitem_57 = None
        clone_default_20 = torch.ops.aten.clone.default(convolution_default_32);  convolution_default_32 = None
        clone_default_21 = torch.ops.aten.clone.default(getitem_63);  getitem_63 = None
        clone_default_22 = torch.ops.aten.clone.default(getitem_66);  getitem_66 = None
        clone_default_23 = torch.ops.aten.clone.default(convolution_default_37);  convolution_default_37 = None
        clone_default_24 = torch.ops.aten.clone.default(getitem_72);  getitem_72 = None
        clone_default_25 = torch.ops.aten.clone.default(getitem_75);  getitem_75 = None
        clone_default_26 = torch.ops.aten.clone.default(convolution_default_42);  convolution_default_42 = None
        clone_default_27 = torch.ops.aten.clone.default(getitem_81);  getitem_81 = None
        clone_default_28 = torch.ops.aten.clone.default(getitem_84);  getitem_84 = None
        clone_default_29 = torch.ops.aten.clone.default(convolution_default_47);  convolution_default_47 = None
        clone_default_30 = torch.ops.aten.clone.default(getitem_90);  getitem_90 = None
        clone_default_31 = torch.ops.aten.clone.default(getitem_93);  getitem_93 = None
        clone_default_32 = torch.ops.aten.clone.default(convolution_default_52);  convolution_default_52 = None
        clone_default_33 = torch.ops.aten.clone.default(getitem_99);  getitem_99 = None
        clone_default_34 = torch.ops.aten.clone.default(getitem_102);  getitem_102 = None
        clone_default_35 = torch.ops.aten.clone.default(convolution_default_57);  convolution_default_57 = None
        clone_default_36 = torch.ops.aten.clone.default(getitem_108);  getitem_108 = None
        clone_default_37 = torch.ops.aten.clone.default(getitem_111);  getitem_111 = None
        clone_default_38 = torch.ops.aten.clone.default(convolution_default_62);  convolution_default_62 = None
        clone_default_39 = torch.ops.aten.clone.default(getitem_117);  getitem_117 = None
        clone_default_40 = torch.ops.aten.clone.default(getitem_120);  getitem_120 = None
        clone_default_41 = torch.ops.aten.clone.default(convolution_default_67);  convolution_default_67 = None
        clone_default_42 = torch.ops.aten.clone.default(getitem_126);  getitem_126 = None
        clone_default_43 = torch.ops.aten.clone.default(getitem_129);  getitem_129 = None
        clone_default_44 = torch.ops.aten.clone.default(convolution_default_72);  convolution_default_72 = None
        clone_default_45 = torch.ops.aten.clone.default(getitem_135);  getitem_135 = None
        clone_default_46 = torch.ops.aten.clone.default(getitem_138);  getitem_138 = None
        clone_default_47 = torch.ops.aten.clone.default(convolution_default_77);  convolution_default_77 = None
        clone_default_48 = torch.ops.aten.clone.default(getitem_144);  getitem_144 = None
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, view_default);  t_default_2 = view_default = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_1 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        view_default_2 = torch.ops.aten.view.default(mm_default, [128, 1280, 1, 1]);  mm_default = None
        expand_default = torch.ops.aten.expand.default(view_default_2, [128, 1280, 7, 7]);  view_default_2 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 49);  expand_default = None
        to_dtype = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_1 = torch.ops.aten.to.dtype(clone_default_48, torch.float32);  clone_default_48 = None
        neg_default = torch.ops.aten.neg.default(to_dtype_1)
        exp_default = torch.ops.aten.exp.default(neg_default);  neg_default = None
        add_tensor_58 = torch.ops.aten.add.Tensor(exp_default, 1);  exp_default = None
        reciprocal_default = torch.ops.aten.reciprocal.default(add_tensor_58);  add_tensor_58 = None
        mul_tensor_16 = torch.ops.aten.mul.Tensor(reciprocal_default, 1);  reciprocal_default = None
        mul_tensor_17 = torch.ops.aten.mul.Tensor(to_dtype, mul_tensor_16);  to_dtype = None
        rsub_scalar = torch.ops.aten.rsub.Scalar(mul_tensor_16, 1);  mul_tensor_16 = None
        mul_tensor_18 = torch.ops.aten.mul.Tensor(to_dtype_1, rsub_scalar);  to_dtype_1 = rsub_scalar = None
        add_tensor_59 = torch.ops.aten.add.Tensor(mul_tensor_18, 1);  mul_tensor_18 = None
        mul_tensor_19 = torch.ops.aten.mul.Tensor(mul_tensor_17, add_tensor_59);  mul_tensor_17 = add_tensor_59 = None
        to_dtype_2 = torch.ops.aten.to.dtype(mul_tensor_19, torch.float32);  mul_tensor_19 = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_2, convolution_default_80, primals_360, primals_358, primals_359, getitem_145, getitem_146, True, 0.001, [True, True, True]);  to_dtype_2 = convolution_default_80 = primals_360 = primals_358 = primals_359 = getitem_145 = getitem_146 = None
        getitem_147 = native_batch_norm_backward_default[0]
        getitem_148 = native_batch_norm_backward_default[1]
        getitem_149 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(getitem_147, getitem_141, primals_114, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_147 = getitem_141 = primals_114 = None
        getitem_150 = convolution_backward_default[0]
        getitem_151 = convolution_backward_default[1];  convolution_backward_default = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(getitem_150, convolution_default_79, primals_355, primals_353, primals_354, getitem_142, getitem_143, True, 0.001, [True, True, True]);  getitem_150 = convolution_default_79 = primals_355 = primals_353 = primals_354 = getitem_142 = getitem_143 = None
        getitem_153 = native_batch_norm_backward_default_1[0]
        getitem_154 = native_batch_norm_backward_default_1[1]
        getitem_155 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_153, mul_tensor_15, primals_107, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_153 = mul_tensor_15 = primals_107 = None
        getitem_156 = convolution_backward_default_1[0]
        getitem_157 = convolution_backward_default_1[1];  convolution_backward_default_1 = None
        mul_tensor_20 = torch.ops.aten.mul.Tensor(getitem_156, silu__default_46);  silu__default_46 = None
        mul_tensor_21 = torch.ops.aten.mul.Tensor(getitem_156, sigmoid_default_15);  getitem_156 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(mul_tensor_20, [2, 3], True);  mul_tensor_20 = None
        to_dtype_3 = torch.ops.aten.to.dtype(sum_dim_int_list_1, torch.float32);  sum_dim_int_list_1 = None
        to_dtype_4 = torch.ops.aten.to.dtype(sigmoid_default_15, torch.float32);  sigmoid_default_15 = None
        rsub_scalar_1 = torch.ops.aten.rsub.Scalar(to_dtype_4, 1)
        mul_tensor_22 = torch.ops.aten.mul.Tensor(to_dtype_4, rsub_scalar_1);  to_dtype_4 = rsub_scalar_1 = None
        conj_physical_default = torch.ops.aten.conj_physical.default(mul_tensor_22);  mul_tensor_22 = None
        mul_tensor_23 = torch.ops.aten.mul.Tensor(to_dtype_3, conj_physical_default);  to_dtype_3 = conj_physical_default = None
        to_dtype_5 = torch.ops.aten.to.dtype(mul_tensor_23, torch.float32);  mul_tensor_23 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(to_dtype_5, silu__default_47, primals_109, [1152], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_5 = silu__default_47 = primals_109 = None
        getitem_159 = convolution_backward_default_2[0]
        getitem_160 = convolution_backward_default_2[1]
        getitem_161 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        to_dtype_6 = torch.ops.aten.to.dtype(getitem_159, torch.float32);  getitem_159 = None
        to_dtype_7 = torch.ops.aten.to.dtype(clone_default_47, torch.float32);  clone_default_47 = None
        neg_default_1 = torch.ops.aten.neg.default(to_dtype_7)
        exp_default_1 = torch.ops.aten.exp.default(neg_default_1);  neg_default_1 = None
        add_tensor_60 = torch.ops.aten.add.Tensor(exp_default_1, 1);  exp_default_1 = None
        reciprocal_default_1 = torch.ops.aten.reciprocal.default(add_tensor_60);  add_tensor_60 = None
        mul_tensor_24 = torch.ops.aten.mul.Tensor(reciprocal_default_1, 1);  reciprocal_default_1 = None
        mul_tensor_25 = torch.ops.aten.mul.Tensor(to_dtype_6, mul_tensor_24);  to_dtype_6 = None
        rsub_scalar_2 = torch.ops.aten.rsub.Scalar(mul_tensor_24, 1);  mul_tensor_24 = None
        mul_tensor_26 = torch.ops.aten.mul.Tensor(to_dtype_7, rsub_scalar_2);  to_dtype_7 = rsub_scalar_2 = None
        add_tensor_61 = torch.ops.aten.add.Tensor(mul_tensor_26, 1);  mul_tensor_26 = None
        mul_tensor_27 = torch.ops.aten.mul.Tensor(mul_tensor_25, add_tensor_61);  mul_tensor_25 = add_tensor_61 = None
        to_dtype_8 = torch.ops.aten.to.dtype(mul_tensor_27, torch.float32);  mul_tensor_27 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(to_dtype_8, mean_dim_15, primals_111, [48], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_8 = mean_dim_15 = primals_111 = None
        getitem_162 = convolution_backward_default_3[0]
        getitem_163 = convolution_backward_default_3[1]
        getitem_164 = convolution_backward_default_3[2];  convolution_backward_default_3 = None
        expand_default_1 = torch.ops.aten.expand.default(getitem_162, [128, 1152, 7, 7]);  getitem_162 = None
        div_scalar_1 = torch.ops.aten.div.Scalar(expand_default_1, 49);  expand_default_1 = None
        add_tensor_62 = torch.ops.aten.add.Tensor(mul_tensor_21, div_scalar_1);  mul_tensor_21 = div_scalar_1 = None
        to_dtype_9 = torch.ops.aten.to.dtype(add_tensor_62, torch.float32);  add_tensor_62 = None
        to_dtype_10 = torch.ops.aten.to.dtype(clone_default_46, torch.float32);  clone_default_46 = None
        neg_default_2 = torch.ops.aten.neg.default(to_dtype_10)
        exp_default_2 = torch.ops.aten.exp.default(neg_default_2);  neg_default_2 = None
        add_tensor_63 = torch.ops.aten.add.Tensor(exp_default_2, 1);  exp_default_2 = None
        reciprocal_default_2 = torch.ops.aten.reciprocal.default(add_tensor_63);  add_tensor_63 = None
        mul_tensor_28 = torch.ops.aten.mul.Tensor(reciprocal_default_2, 1);  reciprocal_default_2 = None
        mul_tensor_29 = torch.ops.aten.mul.Tensor(to_dtype_9, mul_tensor_28);  to_dtype_9 = None
        rsub_scalar_3 = torch.ops.aten.rsub.Scalar(mul_tensor_28, 1);  mul_tensor_28 = None
        mul_tensor_30 = torch.ops.aten.mul.Tensor(to_dtype_10, rsub_scalar_3);  to_dtype_10 = rsub_scalar_3 = None
        add_tensor_64 = torch.ops.aten.add.Tensor(mul_tensor_30, 1);  mul_tensor_30 = None
        mul_tensor_31 = torch.ops.aten.mul.Tensor(mul_tensor_29, add_tensor_64);  mul_tensor_29 = add_tensor_64 = None
        to_dtype_11 = torch.ops.aten.to.dtype(mul_tensor_31, torch.float32);  mul_tensor_31 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_76, primals_350, primals_348, primals_349, getitem_139, getitem_140, True, 0.001, [True, True, True]);  to_dtype_11 = convolution_default_76 = primals_350 = primals_348 = primals_349 = getitem_139 = getitem_140 = None
        getitem_165 = native_batch_norm_backward_default_2[0]
        getitem_166 = native_batch_norm_backward_default_2[1]
        getitem_167 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_165, silu__default_45, primals_105, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1152, [True, True, False]);  getitem_165 = silu__default_45 = primals_105 = None
        getitem_168 = convolution_backward_default_4[0]
        getitem_169 = convolution_backward_default_4[1];  convolution_backward_default_4 = None
        to_dtype_12 = torch.ops.aten.to.dtype(getitem_168, torch.float32);  getitem_168 = None
        to_dtype_13 = torch.ops.aten.to.dtype(clone_default_45, torch.float32);  clone_default_45 = None
        neg_default_3 = torch.ops.aten.neg.default(to_dtype_13)
        exp_default_3 = torch.ops.aten.exp.default(neg_default_3);  neg_default_3 = None
        add_tensor_65 = torch.ops.aten.add.Tensor(exp_default_3, 1);  exp_default_3 = None
        reciprocal_default_3 = torch.ops.aten.reciprocal.default(add_tensor_65);  add_tensor_65 = None
        mul_tensor_32 = torch.ops.aten.mul.Tensor(reciprocal_default_3, 1);  reciprocal_default_3 = None
        mul_tensor_33 = torch.ops.aten.mul.Tensor(to_dtype_12, mul_tensor_32);  to_dtype_12 = None
        rsub_scalar_4 = torch.ops.aten.rsub.Scalar(mul_tensor_32, 1);  mul_tensor_32 = None
        mul_tensor_34 = torch.ops.aten.mul.Tensor(to_dtype_13, rsub_scalar_4);  to_dtype_13 = rsub_scalar_4 = None
        add_tensor_66 = torch.ops.aten.add.Tensor(mul_tensor_34, 1);  mul_tensor_34 = None
        mul_tensor_35 = torch.ops.aten.mul.Tensor(mul_tensor_33, add_tensor_66);  mul_tensor_33 = add_tensor_66 = None
        to_dtype_14 = torch.ops.aten.to.dtype(mul_tensor_35, torch.float32);  mul_tensor_35 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_75, primals_345, primals_343, primals_344, getitem_136, getitem_137, True, 0.001, [True, True, True]);  to_dtype_14 = convolution_default_75 = primals_345 = primals_343 = primals_344 = getitem_136 = getitem_137 = None
        getitem_171 = native_batch_norm_backward_default_3[0]
        getitem_172 = native_batch_norm_backward_default_3[1]
        getitem_173 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_171, add_tensor_53, primals_106, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_171 = add_tensor_53 = primals_106 = None
        getitem_174 = convolution_backward_default_5[0]
        getitem_175 = convolution_backward_default_5[1];  convolution_backward_default_5 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(getitem_174, convolution_default_74, primals_340, primals_338, primals_339, getitem_133, getitem_134, True, 0.001, [True, True, True]);  convolution_default_74 = primals_340 = primals_338 = primals_339 = getitem_133 = getitem_134 = None
        getitem_177 = native_batch_norm_backward_default_4[0]
        getitem_178 = native_batch_norm_backward_default_4[1]
        getitem_179 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(getitem_177, mul_tensor_14, primals_100, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_177 = mul_tensor_14 = primals_100 = None
        getitem_180 = convolution_backward_default_6[0]
        getitem_181 = convolution_backward_default_6[1];  convolution_backward_default_6 = None
        mul_tensor_36 = torch.ops.aten.mul.Tensor(getitem_180, silu__default_43);  silu__default_43 = None
        mul_tensor_37 = torch.ops.aten.mul.Tensor(getitem_180, sigmoid_default_14);  getitem_180 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(mul_tensor_36, [2, 3], True);  mul_tensor_36 = None
        to_dtype_15 = torch.ops.aten.to.dtype(sum_dim_int_list_2, torch.float32);  sum_dim_int_list_2 = None
        to_dtype_16 = torch.ops.aten.to.dtype(sigmoid_default_14, torch.float32);  sigmoid_default_14 = None
        rsub_scalar_5 = torch.ops.aten.rsub.Scalar(to_dtype_16, 1)
        mul_tensor_38 = torch.ops.aten.mul.Tensor(to_dtype_16, rsub_scalar_5);  to_dtype_16 = rsub_scalar_5 = None
        conj_physical_default_1 = torch.ops.aten.conj_physical.default(mul_tensor_38);  mul_tensor_38 = None
        mul_tensor_39 = torch.ops.aten.mul.Tensor(to_dtype_15, conj_physical_default_1);  to_dtype_15 = conj_physical_default_1 = None
        to_dtype_17 = torch.ops.aten.to.dtype(mul_tensor_39, torch.float32);  mul_tensor_39 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(to_dtype_17, silu__default_44, primals_102, [1152], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_17 = silu__default_44 = primals_102 = None
        getitem_183 = convolution_backward_default_7[0]
        getitem_184 = convolution_backward_default_7[1]
        getitem_185 = convolution_backward_default_7[2];  convolution_backward_default_7 = None
        to_dtype_18 = torch.ops.aten.to.dtype(getitem_183, torch.float32);  getitem_183 = None
        to_dtype_19 = torch.ops.aten.to.dtype(clone_default_44, torch.float32);  clone_default_44 = None
        neg_default_4 = torch.ops.aten.neg.default(to_dtype_19)
        exp_default_4 = torch.ops.aten.exp.default(neg_default_4);  neg_default_4 = None
        add_tensor_67 = torch.ops.aten.add.Tensor(exp_default_4, 1);  exp_default_4 = None
        reciprocal_default_4 = torch.ops.aten.reciprocal.default(add_tensor_67);  add_tensor_67 = None
        mul_tensor_40 = torch.ops.aten.mul.Tensor(reciprocal_default_4, 1);  reciprocal_default_4 = None
        mul_tensor_41 = torch.ops.aten.mul.Tensor(to_dtype_18, mul_tensor_40);  to_dtype_18 = None
        rsub_scalar_6 = torch.ops.aten.rsub.Scalar(mul_tensor_40, 1);  mul_tensor_40 = None
        mul_tensor_42 = torch.ops.aten.mul.Tensor(to_dtype_19, rsub_scalar_6);  to_dtype_19 = rsub_scalar_6 = None
        add_tensor_68 = torch.ops.aten.add.Tensor(mul_tensor_42, 1);  mul_tensor_42 = None
        mul_tensor_43 = torch.ops.aten.mul.Tensor(mul_tensor_41, add_tensor_68);  mul_tensor_41 = add_tensor_68 = None
        to_dtype_20 = torch.ops.aten.to.dtype(mul_tensor_43, torch.float32);  mul_tensor_43 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(to_dtype_20, mean_dim_14, primals_104, [48], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_20 = mean_dim_14 = primals_104 = None
        getitem_186 = convolution_backward_default_8[0]
        getitem_187 = convolution_backward_default_8[1]
        getitem_188 = convolution_backward_default_8[2];  convolution_backward_default_8 = None
        expand_default_2 = torch.ops.aten.expand.default(getitem_186, [128, 1152, 7, 7]);  getitem_186 = None
        div_scalar_2 = torch.ops.aten.div.Scalar(expand_default_2, 49);  expand_default_2 = None
        add_tensor_69 = torch.ops.aten.add.Tensor(mul_tensor_37, div_scalar_2);  mul_tensor_37 = div_scalar_2 = None
        to_dtype_21 = torch.ops.aten.to.dtype(add_tensor_69, torch.float32);  add_tensor_69 = None
        to_dtype_22 = torch.ops.aten.to.dtype(clone_default_43, torch.float32);  clone_default_43 = None
        neg_default_5 = torch.ops.aten.neg.default(to_dtype_22)
        exp_default_5 = torch.ops.aten.exp.default(neg_default_5);  neg_default_5 = None
        add_tensor_70 = torch.ops.aten.add.Tensor(exp_default_5, 1);  exp_default_5 = None
        reciprocal_default_5 = torch.ops.aten.reciprocal.default(add_tensor_70);  add_tensor_70 = None
        mul_tensor_44 = torch.ops.aten.mul.Tensor(reciprocal_default_5, 1);  reciprocal_default_5 = None
        mul_tensor_45 = torch.ops.aten.mul.Tensor(to_dtype_21, mul_tensor_44);  to_dtype_21 = None
        rsub_scalar_7 = torch.ops.aten.rsub.Scalar(mul_tensor_44, 1);  mul_tensor_44 = None
        mul_tensor_46 = torch.ops.aten.mul.Tensor(to_dtype_22, rsub_scalar_7);  to_dtype_22 = rsub_scalar_7 = None
        add_tensor_71 = torch.ops.aten.add.Tensor(mul_tensor_46, 1);  mul_tensor_46 = None
        mul_tensor_47 = torch.ops.aten.mul.Tensor(mul_tensor_45, add_tensor_71);  mul_tensor_45 = add_tensor_71 = None
        to_dtype_23 = torch.ops.aten.to.dtype(mul_tensor_47, torch.float32);  mul_tensor_47 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_23, convolution_default_71, primals_335, primals_333, primals_334, getitem_130, getitem_131, True, 0.001, [True, True, True]);  to_dtype_23 = convolution_default_71 = primals_335 = primals_333 = primals_334 = getitem_130 = getitem_131 = None
        getitem_189 = native_batch_norm_backward_default_5[0]
        getitem_190 = native_batch_norm_backward_default_5[1]
        getitem_191 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_189, silu__default_42, primals_98, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 1152, [True, True, False]);  getitem_189 = silu__default_42 = primals_98 = None
        getitem_192 = convolution_backward_default_9[0]
        getitem_193 = convolution_backward_default_9[1];  convolution_backward_default_9 = None
        to_dtype_24 = torch.ops.aten.to.dtype(getitem_192, torch.float32);  getitem_192 = None
        to_dtype_25 = torch.ops.aten.to.dtype(clone_default_42, torch.float32);  clone_default_42 = None
        neg_default_6 = torch.ops.aten.neg.default(to_dtype_25)
        exp_default_6 = torch.ops.aten.exp.default(neg_default_6);  neg_default_6 = None
        add_tensor_72 = torch.ops.aten.add.Tensor(exp_default_6, 1);  exp_default_6 = None
        reciprocal_default_6 = torch.ops.aten.reciprocal.default(add_tensor_72);  add_tensor_72 = None
        mul_tensor_48 = torch.ops.aten.mul.Tensor(reciprocal_default_6, 1);  reciprocal_default_6 = None
        mul_tensor_49 = torch.ops.aten.mul.Tensor(to_dtype_24, mul_tensor_48);  to_dtype_24 = None
        rsub_scalar_8 = torch.ops.aten.rsub.Scalar(mul_tensor_48, 1);  mul_tensor_48 = None
        mul_tensor_50 = torch.ops.aten.mul.Tensor(to_dtype_25, rsub_scalar_8);  to_dtype_25 = rsub_scalar_8 = None
        add_tensor_73 = torch.ops.aten.add.Tensor(mul_tensor_50, 1);  mul_tensor_50 = None
        mul_tensor_51 = torch.ops.aten.mul.Tensor(mul_tensor_49, add_tensor_73);  mul_tensor_49 = add_tensor_73 = None
        to_dtype_26 = torch.ops.aten.to.dtype(mul_tensor_51, torch.float32);  mul_tensor_51 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_70, primals_330, primals_328, primals_329, getitem_127, getitem_128, True, 0.001, [True, True, True]);  to_dtype_26 = convolution_default_70 = primals_330 = primals_328 = primals_329 = getitem_127 = getitem_128 = None
        getitem_195 = native_batch_norm_backward_default_6[0]
        getitem_196 = native_batch_norm_backward_default_6[1]
        getitem_197 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_195, add_tensor_49, primals_99, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_195 = add_tensor_49 = primals_99 = None
        getitem_198 = convolution_backward_default_10[0]
        getitem_199 = convolution_backward_default_10[1];  convolution_backward_default_10 = None
        add_tensor_74 = torch.ops.aten.add.Tensor(getitem_174, getitem_198);  getitem_174 = getitem_198 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_74, convolution_default_69, primals_325, primals_323, primals_324, getitem_124, getitem_125, True, 0.001, [True, True, True]);  convolution_default_69 = primals_325 = primals_323 = primals_324 = getitem_124 = getitem_125 = None
        getitem_201 = native_batch_norm_backward_default_7[0]
        getitem_202 = native_batch_norm_backward_default_7[1]
        getitem_203 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_201, mul_tensor_13, primals_93, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_201 = mul_tensor_13 = primals_93 = None
        getitem_204 = convolution_backward_default_11[0]
        getitem_205 = convolution_backward_default_11[1];  convolution_backward_default_11 = None
        mul_tensor_52 = torch.ops.aten.mul.Tensor(getitem_204, silu__default_40);  silu__default_40 = None
        mul_tensor_53 = torch.ops.aten.mul.Tensor(getitem_204, sigmoid_default_13);  getitem_204 = None
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(mul_tensor_52, [2, 3], True);  mul_tensor_52 = None
        to_dtype_27 = torch.ops.aten.to.dtype(sum_dim_int_list_3, torch.float32);  sum_dim_int_list_3 = None
        to_dtype_28 = torch.ops.aten.to.dtype(sigmoid_default_13, torch.float32);  sigmoid_default_13 = None
        rsub_scalar_9 = torch.ops.aten.rsub.Scalar(to_dtype_28, 1)
        mul_tensor_54 = torch.ops.aten.mul.Tensor(to_dtype_28, rsub_scalar_9);  to_dtype_28 = rsub_scalar_9 = None
        conj_physical_default_2 = torch.ops.aten.conj_physical.default(mul_tensor_54);  mul_tensor_54 = None
        mul_tensor_55 = torch.ops.aten.mul.Tensor(to_dtype_27, conj_physical_default_2);  to_dtype_27 = conj_physical_default_2 = None
        to_dtype_29 = torch.ops.aten.to.dtype(mul_tensor_55, torch.float32);  mul_tensor_55 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(to_dtype_29, silu__default_41, primals_95, [1152], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_29 = silu__default_41 = primals_95 = None
        getitem_207 = convolution_backward_default_12[0]
        getitem_208 = convolution_backward_default_12[1]
        getitem_209 = convolution_backward_default_12[2];  convolution_backward_default_12 = None
        to_dtype_30 = torch.ops.aten.to.dtype(getitem_207, torch.float32);  getitem_207 = None
        to_dtype_31 = torch.ops.aten.to.dtype(clone_default_41, torch.float32);  clone_default_41 = None
        neg_default_7 = torch.ops.aten.neg.default(to_dtype_31)
        exp_default_7 = torch.ops.aten.exp.default(neg_default_7);  neg_default_7 = None
        add_tensor_75 = torch.ops.aten.add.Tensor(exp_default_7, 1);  exp_default_7 = None
        reciprocal_default_7 = torch.ops.aten.reciprocal.default(add_tensor_75);  add_tensor_75 = None
        mul_tensor_56 = torch.ops.aten.mul.Tensor(reciprocal_default_7, 1);  reciprocal_default_7 = None
        mul_tensor_57 = torch.ops.aten.mul.Tensor(to_dtype_30, mul_tensor_56);  to_dtype_30 = None
        rsub_scalar_10 = torch.ops.aten.rsub.Scalar(mul_tensor_56, 1);  mul_tensor_56 = None
        mul_tensor_58 = torch.ops.aten.mul.Tensor(to_dtype_31, rsub_scalar_10);  to_dtype_31 = rsub_scalar_10 = None
        add_tensor_76 = torch.ops.aten.add.Tensor(mul_tensor_58, 1);  mul_tensor_58 = None
        mul_tensor_59 = torch.ops.aten.mul.Tensor(mul_tensor_57, add_tensor_76);  mul_tensor_57 = add_tensor_76 = None
        to_dtype_32 = torch.ops.aten.to.dtype(mul_tensor_59, torch.float32);  mul_tensor_59 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(to_dtype_32, mean_dim_13, primals_97, [48], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_32 = mean_dim_13 = primals_97 = None
        getitem_210 = convolution_backward_default_13[0]
        getitem_211 = convolution_backward_default_13[1]
        getitem_212 = convolution_backward_default_13[2];  convolution_backward_default_13 = None
        expand_default_3 = torch.ops.aten.expand.default(getitem_210, [128, 1152, 7, 7]);  getitem_210 = None
        div_scalar_3 = torch.ops.aten.div.Scalar(expand_default_3, 49);  expand_default_3 = None
        add_tensor_77 = torch.ops.aten.add.Tensor(mul_tensor_53, div_scalar_3);  mul_tensor_53 = div_scalar_3 = None
        to_dtype_33 = torch.ops.aten.to.dtype(add_tensor_77, torch.float32);  add_tensor_77 = None
        to_dtype_34 = torch.ops.aten.to.dtype(clone_default_40, torch.float32);  clone_default_40 = None
        neg_default_8 = torch.ops.aten.neg.default(to_dtype_34)
        exp_default_8 = torch.ops.aten.exp.default(neg_default_8);  neg_default_8 = None
        add_tensor_78 = torch.ops.aten.add.Tensor(exp_default_8, 1);  exp_default_8 = None
        reciprocal_default_8 = torch.ops.aten.reciprocal.default(add_tensor_78);  add_tensor_78 = None
        mul_tensor_60 = torch.ops.aten.mul.Tensor(reciprocal_default_8, 1);  reciprocal_default_8 = None
        mul_tensor_61 = torch.ops.aten.mul.Tensor(to_dtype_33, mul_tensor_60);  to_dtype_33 = None
        rsub_scalar_11 = torch.ops.aten.rsub.Scalar(mul_tensor_60, 1);  mul_tensor_60 = None
        mul_tensor_62 = torch.ops.aten.mul.Tensor(to_dtype_34, rsub_scalar_11);  to_dtype_34 = rsub_scalar_11 = None
        add_tensor_79 = torch.ops.aten.add.Tensor(mul_tensor_62, 1);  mul_tensor_62 = None
        mul_tensor_63 = torch.ops.aten.mul.Tensor(mul_tensor_61, add_tensor_79);  mul_tensor_61 = add_tensor_79 = None
        to_dtype_35 = torch.ops.aten.to.dtype(mul_tensor_63, torch.float32);  mul_tensor_63 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_35, convolution_default_66, primals_320, primals_318, primals_319, getitem_121, getitem_122, True, 0.001, [True, True, True]);  to_dtype_35 = convolution_default_66 = primals_320 = primals_318 = primals_319 = getitem_121 = getitem_122 = None
        getitem_213 = native_batch_norm_backward_default_8[0]
        getitem_214 = native_batch_norm_backward_default_8[1]
        getitem_215 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_213, silu__default_39, primals_91, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 1152, [True, True, False]);  getitem_213 = silu__default_39 = primals_91 = None
        getitem_216 = convolution_backward_default_14[0]
        getitem_217 = convolution_backward_default_14[1];  convolution_backward_default_14 = None
        to_dtype_36 = torch.ops.aten.to.dtype(getitem_216, torch.float32);  getitem_216 = None
        to_dtype_37 = torch.ops.aten.to.dtype(clone_default_39, torch.float32);  clone_default_39 = None
        neg_default_9 = torch.ops.aten.neg.default(to_dtype_37)
        exp_default_9 = torch.ops.aten.exp.default(neg_default_9);  neg_default_9 = None
        add_tensor_80 = torch.ops.aten.add.Tensor(exp_default_9, 1);  exp_default_9 = None
        reciprocal_default_9 = torch.ops.aten.reciprocal.default(add_tensor_80);  add_tensor_80 = None
        mul_tensor_64 = torch.ops.aten.mul.Tensor(reciprocal_default_9, 1);  reciprocal_default_9 = None
        mul_tensor_65 = torch.ops.aten.mul.Tensor(to_dtype_36, mul_tensor_64);  to_dtype_36 = None
        rsub_scalar_12 = torch.ops.aten.rsub.Scalar(mul_tensor_64, 1);  mul_tensor_64 = None
        mul_tensor_66 = torch.ops.aten.mul.Tensor(to_dtype_37, rsub_scalar_12);  to_dtype_37 = rsub_scalar_12 = None
        add_tensor_81 = torch.ops.aten.add.Tensor(mul_tensor_66, 1);  mul_tensor_66 = None
        mul_tensor_67 = torch.ops.aten.mul.Tensor(mul_tensor_65, add_tensor_81);  mul_tensor_65 = add_tensor_81 = None
        to_dtype_38 = torch.ops.aten.to.dtype(mul_tensor_67, torch.float32);  mul_tensor_67 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_38, convolution_default_65, primals_315, primals_313, primals_314, getitem_118, getitem_119, True, 0.001, [True, True, True]);  to_dtype_38 = convolution_default_65 = primals_315 = primals_313 = primals_314 = getitem_118 = getitem_119 = None
        getitem_219 = native_batch_norm_backward_default_9[0]
        getitem_220 = native_batch_norm_backward_default_9[1]
        getitem_221 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_219, add_tensor_45, primals_92, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_219 = add_tensor_45 = primals_92 = None
        getitem_222 = convolution_backward_default_15[0]
        getitem_223 = convolution_backward_default_15[1];  convolution_backward_default_15 = None
        add_tensor_82 = torch.ops.aten.add.Tensor(add_tensor_74, getitem_222);  add_tensor_74 = getitem_222 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_82, convolution_default_64, primals_310, primals_308, primals_309, getitem_115, getitem_116, True, 0.001, [True, True, True]);  convolution_default_64 = primals_310 = primals_308 = primals_309 = getitem_115 = getitem_116 = None
        getitem_225 = native_batch_norm_backward_default_10[0]
        getitem_226 = native_batch_norm_backward_default_10[1]
        getitem_227 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(getitem_225, mul_tensor_12, primals_86, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_225 = mul_tensor_12 = primals_86 = None
        getitem_228 = convolution_backward_default_16[0]
        getitem_229 = convolution_backward_default_16[1];  convolution_backward_default_16 = None
        mul_tensor_68 = torch.ops.aten.mul.Tensor(getitem_228, silu__default_37);  silu__default_37 = None
        mul_tensor_69 = torch.ops.aten.mul.Tensor(getitem_228, sigmoid_default_12);  getitem_228 = None
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(mul_tensor_68, [2, 3], True);  mul_tensor_68 = None
        to_dtype_39 = torch.ops.aten.to.dtype(sum_dim_int_list_4, torch.float32);  sum_dim_int_list_4 = None
        to_dtype_40 = torch.ops.aten.to.dtype(sigmoid_default_12, torch.float32);  sigmoid_default_12 = None
        rsub_scalar_13 = torch.ops.aten.rsub.Scalar(to_dtype_40, 1)
        mul_tensor_70 = torch.ops.aten.mul.Tensor(to_dtype_40, rsub_scalar_13);  to_dtype_40 = rsub_scalar_13 = None
        conj_physical_default_3 = torch.ops.aten.conj_physical.default(mul_tensor_70);  mul_tensor_70 = None
        mul_tensor_71 = torch.ops.aten.mul.Tensor(to_dtype_39, conj_physical_default_3);  to_dtype_39 = conj_physical_default_3 = None
        to_dtype_41 = torch.ops.aten.to.dtype(mul_tensor_71, torch.float32);  mul_tensor_71 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(to_dtype_41, silu__default_38, primals_88, [1152], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_41 = silu__default_38 = primals_88 = None
        getitem_231 = convolution_backward_default_17[0]
        getitem_232 = convolution_backward_default_17[1]
        getitem_233 = convolution_backward_default_17[2];  convolution_backward_default_17 = None
        to_dtype_42 = torch.ops.aten.to.dtype(getitem_231, torch.float32);  getitem_231 = None
        to_dtype_43 = torch.ops.aten.to.dtype(clone_default_38, torch.float32);  clone_default_38 = None
        neg_default_10 = torch.ops.aten.neg.default(to_dtype_43)
        exp_default_10 = torch.ops.aten.exp.default(neg_default_10);  neg_default_10 = None
        add_tensor_83 = torch.ops.aten.add.Tensor(exp_default_10, 1);  exp_default_10 = None
        reciprocal_default_10 = torch.ops.aten.reciprocal.default(add_tensor_83);  add_tensor_83 = None
        mul_tensor_72 = torch.ops.aten.mul.Tensor(reciprocal_default_10, 1);  reciprocal_default_10 = None
        mul_tensor_73 = torch.ops.aten.mul.Tensor(to_dtype_42, mul_tensor_72);  to_dtype_42 = None
        rsub_scalar_14 = torch.ops.aten.rsub.Scalar(mul_tensor_72, 1);  mul_tensor_72 = None
        mul_tensor_74 = torch.ops.aten.mul.Tensor(to_dtype_43, rsub_scalar_14);  to_dtype_43 = rsub_scalar_14 = None
        add_tensor_84 = torch.ops.aten.add.Tensor(mul_tensor_74, 1);  mul_tensor_74 = None
        mul_tensor_75 = torch.ops.aten.mul.Tensor(mul_tensor_73, add_tensor_84);  mul_tensor_73 = add_tensor_84 = None
        to_dtype_44 = torch.ops.aten.to.dtype(mul_tensor_75, torch.float32);  mul_tensor_75 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(to_dtype_44, mean_dim_12, primals_90, [48], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_44 = mean_dim_12 = primals_90 = None
        getitem_234 = convolution_backward_default_18[0]
        getitem_235 = convolution_backward_default_18[1]
        getitem_236 = convolution_backward_default_18[2];  convolution_backward_default_18 = None
        expand_default_4 = torch.ops.aten.expand.default(getitem_234, [128, 1152, 7, 7]);  getitem_234 = None
        div_scalar_4 = torch.ops.aten.div.Scalar(expand_default_4, 49);  expand_default_4 = None
        add_tensor_85 = torch.ops.aten.add.Tensor(mul_tensor_69, div_scalar_4);  mul_tensor_69 = div_scalar_4 = None
        to_dtype_45 = torch.ops.aten.to.dtype(add_tensor_85, torch.float32);  add_tensor_85 = None
        to_dtype_46 = torch.ops.aten.to.dtype(clone_default_37, torch.float32);  clone_default_37 = None
        neg_default_11 = torch.ops.aten.neg.default(to_dtype_46)
        exp_default_11 = torch.ops.aten.exp.default(neg_default_11);  neg_default_11 = None
        add_tensor_86 = torch.ops.aten.add.Tensor(exp_default_11, 1);  exp_default_11 = None
        reciprocal_default_11 = torch.ops.aten.reciprocal.default(add_tensor_86);  add_tensor_86 = None
        mul_tensor_76 = torch.ops.aten.mul.Tensor(reciprocal_default_11, 1);  reciprocal_default_11 = None
        mul_tensor_77 = torch.ops.aten.mul.Tensor(to_dtype_45, mul_tensor_76);  to_dtype_45 = None
        rsub_scalar_15 = torch.ops.aten.rsub.Scalar(mul_tensor_76, 1);  mul_tensor_76 = None
        mul_tensor_78 = torch.ops.aten.mul.Tensor(to_dtype_46, rsub_scalar_15);  to_dtype_46 = rsub_scalar_15 = None
        add_tensor_87 = torch.ops.aten.add.Tensor(mul_tensor_78, 1);  mul_tensor_78 = None
        mul_tensor_79 = torch.ops.aten.mul.Tensor(mul_tensor_77, add_tensor_87);  mul_tensor_77 = add_tensor_87 = None
        to_dtype_47 = torch.ops.aten.to.dtype(mul_tensor_79, torch.float32);  mul_tensor_79 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_47, convolution_default_61, primals_305, primals_303, primals_304, getitem_112, getitem_113, True, 0.001, [True, True, True]);  to_dtype_47 = convolution_default_61 = primals_305 = primals_303 = primals_304 = getitem_112 = getitem_113 = None
        getitem_237 = native_batch_norm_backward_default_11[0]
        getitem_238 = native_batch_norm_backward_default_11[1]
        getitem_239 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_237, silu__default_36, primals_84, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 1152, [True, True, False]);  getitem_237 = silu__default_36 = primals_84 = None
        getitem_240 = convolution_backward_default_19[0]
        getitem_241 = convolution_backward_default_19[1];  convolution_backward_default_19 = None
        to_dtype_48 = torch.ops.aten.to.dtype(getitem_240, torch.float32);  getitem_240 = None
        to_dtype_49 = torch.ops.aten.to.dtype(clone_default_36, torch.float32);  clone_default_36 = None
        neg_default_12 = torch.ops.aten.neg.default(to_dtype_49)
        exp_default_12 = torch.ops.aten.exp.default(neg_default_12);  neg_default_12 = None
        add_tensor_88 = torch.ops.aten.add.Tensor(exp_default_12, 1);  exp_default_12 = None
        reciprocal_default_12 = torch.ops.aten.reciprocal.default(add_tensor_88);  add_tensor_88 = None
        mul_tensor_80 = torch.ops.aten.mul.Tensor(reciprocal_default_12, 1);  reciprocal_default_12 = None
        mul_tensor_81 = torch.ops.aten.mul.Tensor(to_dtype_48, mul_tensor_80);  to_dtype_48 = None
        rsub_scalar_16 = torch.ops.aten.rsub.Scalar(mul_tensor_80, 1);  mul_tensor_80 = None
        mul_tensor_82 = torch.ops.aten.mul.Tensor(to_dtype_49, rsub_scalar_16);  to_dtype_49 = rsub_scalar_16 = None
        add_tensor_89 = torch.ops.aten.add.Tensor(mul_tensor_82, 1);  mul_tensor_82 = None
        mul_tensor_83 = torch.ops.aten.mul.Tensor(mul_tensor_81, add_tensor_89);  mul_tensor_81 = add_tensor_89 = None
        to_dtype_50 = torch.ops.aten.to.dtype(mul_tensor_83, torch.float32);  mul_tensor_83 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_50, convolution_default_60, primals_300, primals_298, primals_299, getitem_109, getitem_110, True, 0.001, [True, True, True]);  to_dtype_50 = convolution_default_60 = primals_300 = primals_298 = primals_299 = getitem_109 = getitem_110 = None
        getitem_243 = native_batch_norm_backward_default_12[0]
        getitem_244 = native_batch_norm_backward_default_12[1]
        getitem_245 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(getitem_243, getitem_105, primals_85, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_243 = getitem_105 = primals_85 = None
        getitem_246 = convolution_backward_default_20[0]
        getitem_247 = convolution_backward_default_20[1];  convolution_backward_default_20 = None
        add_tensor_90 = torch.ops.aten.add.Tensor(add_tensor_82, getitem_246);  add_tensor_82 = getitem_246 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_90, convolution_default_59, primals_295, primals_293, primals_294, getitem_106, getitem_107, True, 0.001, [True, True, True]);  add_tensor_90 = convolution_default_59 = primals_295 = primals_293 = primals_294 = getitem_106 = getitem_107 = None
        getitem_249 = native_batch_norm_backward_default_13[0]
        getitem_250 = native_batch_norm_backward_default_13[1]
        getitem_251 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(getitem_249, mul_tensor_11, primals_79, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_249 = mul_tensor_11 = primals_79 = None
        getitem_252 = convolution_backward_default_21[0]
        getitem_253 = convolution_backward_default_21[1];  convolution_backward_default_21 = None
        mul_tensor_84 = torch.ops.aten.mul.Tensor(getitem_252, silu__default_34);  silu__default_34 = None
        mul_tensor_85 = torch.ops.aten.mul.Tensor(getitem_252, sigmoid_default_11);  getitem_252 = None
        sum_dim_int_list_5 = torch.ops.aten.sum.dim_IntList(mul_tensor_84, [2, 3], True);  mul_tensor_84 = None
        to_dtype_51 = torch.ops.aten.to.dtype(sum_dim_int_list_5, torch.float32);  sum_dim_int_list_5 = None
        to_dtype_52 = torch.ops.aten.to.dtype(sigmoid_default_11, torch.float32);  sigmoid_default_11 = None
        rsub_scalar_17 = torch.ops.aten.rsub.Scalar(to_dtype_52, 1)
        mul_tensor_86 = torch.ops.aten.mul.Tensor(to_dtype_52, rsub_scalar_17);  to_dtype_52 = rsub_scalar_17 = None
        conj_physical_default_4 = torch.ops.aten.conj_physical.default(mul_tensor_86);  mul_tensor_86 = None
        mul_tensor_87 = torch.ops.aten.mul.Tensor(to_dtype_51, conj_physical_default_4);  to_dtype_51 = conj_physical_default_4 = None
        to_dtype_53 = torch.ops.aten.to.dtype(mul_tensor_87, torch.float32);  mul_tensor_87 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(to_dtype_53, silu__default_35, primals_81, [672], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_53 = silu__default_35 = primals_81 = None
        getitem_255 = convolution_backward_default_22[0]
        getitem_256 = convolution_backward_default_22[1]
        getitem_257 = convolution_backward_default_22[2];  convolution_backward_default_22 = None
        to_dtype_54 = torch.ops.aten.to.dtype(getitem_255, torch.float32);  getitem_255 = None
        to_dtype_55 = torch.ops.aten.to.dtype(clone_default_35, torch.float32);  clone_default_35 = None
        neg_default_13 = torch.ops.aten.neg.default(to_dtype_55)
        exp_default_13 = torch.ops.aten.exp.default(neg_default_13);  neg_default_13 = None
        add_tensor_91 = torch.ops.aten.add.Tensor(exp_default_13, 1);  exp_default_13 = None
        reciprocal_default_13 = torch.ops.aten.reciprocal.default(add_tensor_91);  add_tensor_91 = None
        mul_tensor_88 = torch.ops.aten.mul.Tensor(reciprocal_default_13, 1);  reciprocal_default_13 = None
        mul_tensor_89 = torch.ops.aten.mul.Tensor(to_dtype_54, mul_tensor_88);  to_dtype_54 = None
        rsub_scalar_18 = torch.ops.aten.rsub.Scalar(mul_tensor_88, 1);  mul_tensor_88 = None
        mul_tensor_90 = torch.ops.aten.mul.Tensor(to_dtype_55, rsub_scalar_18);  to_dtype_55 = rsub_scalar_18 = None
        add_tensor_92 = torch.ops.aten.add.Tensor(mul_tensor_90, 1);  mul_tensor_90 = None
        mul_tensor_91 = torch.ops.aten.mul.Tensor(mul_tensor_89, add_tensor_92);  mul_tensor_89 = add_tensor_92 = None
        to_dtype_56 = torch.ops.aten.to.dtype(mul_tensor_91, torch.float32);  mul_tensor_91 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(to_dtype_56, mean_dim_11, primals_83, [28], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_56 = mean_dim_11 = primals_83 = None
        getitem_258 = convolution_backward_default_23[0]
        getitem_259 = convolution_backward_default_23[1]
        getitem_260 = convolution_backward_default_23[2];  convolution_backward_default_23 = None
        expand_default_5 = torch.ops.aten.expand.default(getitem_258, [128, 672, 7, 7]);  getitem_258 = None
        div_scalar_5 = torch.ops.aten.div.Scalar(expand_default_5, 49);  expand_default_5 = None
        add_tensor_93 = torch.ops.aten.add.Tensor(mul_tensor_85, div_scalar_5);  mul_tensor_85 = div_scalar_5 = None
        to_dtype_57 = torch.ops.aten.to.dtype(add_tensor_93, torch.float32);  add_tensor_93 = None
        to_dtype_58 = torch.ops.aten.to.dtype(clone_default_34, torch.float32);  clone_default_34 = None
        neg_default_14 = torch.ops.aten.neg.default(to_dtype_58)
        exp_default_14 = torch.ops.aten.exp.default(neg_default_14);  neg_default_14 = None
        add_tensor_94 = torch.ops.aten.add.Tensor(exp_default_14, 1);  exp_default_14 = None
        reciprocal_default_14 = torch.ops.aten.reciprocal.default(add_tensor_94);  add_tensor_94 = None
        mul_tensor_92 = torch.ops.aten.mul.Tensor(reciprocal_default_14, 1);  reciprocal_default_14 = None
        mul_tensor_93 = torch.ops.aten.mul.Tensor(to_dtype_57, mul_tensor_92);  to_dtype_57 = None
        rsub_scalar_19 = torch.ops.aten.rsub.Scalar(mul_tensor_92, 1);  mul_tensor_92 = None
        mul_tensor_94 = torch.ops.aten.mul.Tensor(to_dtype_58, rsub_scalar_19);  to_dtype_58 = rsub_scalar_19 = None
        add_tensor_95 = torch.ops.aten.add.Tensor(mul_tensor_94, 1);  mul_tensor_94 = None
        mul_tensor_95 = torch.ops.aten.mul.Tensor(mul_tensor_93, add_tensor_95);  mul_tensor_93 = add_tensor_95 = None
        to_dtype_59 = torch.ops.aten.to.dtype(mul_tensor_95, torch.float32);  mul_tensor_95 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_59, convolution_default_56, primals_290, primals_288, primals_289, getitem_103, getitem_104, True, 0.001, [True, True, True]);  to_dtype_59 = convolution_default_56 = primals_290 = primals_288 = primals_289 = getitem_103 = getitem_104 = None
        getitem_261 = native_batch_norm_backward_default_14[0]
        getitem_262 = native_batch_norm_backward_default_14[1]
        getitem_263 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_261, constant_pad_nd_default_4, primals_77, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_261 = constant_pad_nd_default_4 = primals_77 = None
        getitem_264 = convolution_backward_default_24[0]
        getitem_265 = convolution_backward_default_24[1];  convolution_backward_default_24 = None
        constant_pad_nd_default_5 = torch.ops.aten.constant_pad_nd.default(getitem_264, [-1, -2, -1, -2]);  getitem_264 = None
        to_dtype_60 = torch.ops.aten.to.dtype(constant_pad_nd_default_5, torch.float32);  constant_pad_nd_default_5 = None
        to_dtype_61 = torch.ops.aten.to.dtype(clone_default_33, torch.float32);  clone_default_33 = None
        neg_default_15 = torch.ops.aten.neg.default(to_dtype_61)
        exp_default_15 = torch.ops.aten.exp.default(neg_default_15);  neg_default_15 = None
        add_tensor_96 = torch.ops.aten.add.Tensor(exp_default_15, 1);  exp_default_15 = None
        reciprocal_default_15 = torch.ops.aten.reciprocal.default(add_tensor_96);  add_tensor_96 = None
        mul_tensor_96 = torch.ops.aten.mul.Tensor(reciprocal_default_15, 1);  reciprocal_default_15 = None
        mul_tensor_97 = torch.ops.aten.mul.Tensor(to_dtype_60, mul_tensor_96);  to_dtype_60 = None
        rsub_scalar_20 = torch.ops.aten.rsub.Scalar(mul_tensor_96, 1);  mul_tensor_96 = None
        mul_tensor_98 = torch.ops.aten.mul.Tensor(to_dtype_61, rsub_scalar_20);  to_dtype_61 = rsub_scalar_20 = None
        add_tensor_97 = torch.ops.aten.add.Tensor(mul_tensor_98, 1);  mul_tensor_98 = None
        mul_tensor_99 = torch.ops.aten.mul.Tensor(mul_tensor_97, add_tensor_97);  mul_tensor_97 = add_tensor_97 = None
        to_dtype_62 = torch.ops.aten.to.dtype(mul_tensor_99, torch.float32);  mul_tensor_99 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_62, convolution_default_55, primals_285, primals_283, primals_284, getitem_100, getitem_101, True, 0.001, [True, True, True]);  to_dtype_62 = convolution_default_55 = primals_285 = primals_283 = primals_284 = getitem_100 = getitem_101 = None
        getitem_267 = native_batch_norm_backward_default_15[0]
        getitem_268 = native_batch_norm_backward_default_15[1]
        getitem_269 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_267, add_tensor_38, primals_78, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_267 = add_tensor_38 = primals_78 = None
        getitem_270 = convolution_backward_default_25[0]
        getitem_271 = convolution_backward_default_25[1];  convolution_backward_default_25 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(getitem_270, convolution_default_54, primals_280, primals_278, primals_279, getitem_97, getitem_98, True, 0.001, [True, True, True]);  convolution_default_54 = primals_280 = primals_278 = primals_279 = getitem_97 = getitem_98 = None
        getitem_273 = native_batch_norm_backward_default_16[0]
        getitem_274 = native_batch_norm_backward_default_16[1]
        getitem_275 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(getitem_273, mul_tensor_10, primals_72, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_273 = mul_tensor_10 = primals_72 = None
        getitem_276 = convolution_backward_default_26[0]
        getitem_277 = convolution_backward_default_26[1];  convolution_backward_default_26 = None
        mul_tensor_100 = torch.ops.aten.mul.Tensor(getitem_276, silu__default_31);  silu__default_31 = None
        mul_tensor_101 = torch.ops.aten.mul.Tensor(getitem_276, sigmoid_default_10);  getitem_276 = None
        sum_dim_int_list_6 = torch.ops.aten.sum.dim_IntList(mul_tensor_100, [2, 3], True);  mul_tensor_100 = None
        to_dtype_63 = torch.ops.aten.to.dtype(sum_dim_int_list_6, torch.float32);  sum_dim_int_list_6 = None
        to_dtype_64 = torch.ops.aten.to.dtype(sigmoid_default_10, torch.float32);  sigmoid_default_10 = None
        rsub_scalar_21 = torch.ops.aten.rsub.Scalar(to_dtype_64, 1)
        mul_tensor_102 = torch.ops.aten.mul.Tensor(to_dtype_64, rsub_scalar_21);  to_dtype_64 = rsub_scalar_21 = None
        conj_physical_default_5 = torch.ops.aten.conj_physical.default(mul_tensor_102);  mul_tensor_102 = None
        mul_tensor_103 = torch.ops.aten.mul.Tensor(to_dtype_63, conj_physical_default_5);  to_dtype_63 = conj_physical_default_5 = None
        to_dtype_65 = torch.ops.aten.to.dtype(mul_tensor_103, torch.float32);  mul_tensor_103 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(to_dtype_65, silu__default_32, primals_74, [672], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_65 = silu__default_32 = primals_74 = None
        getitem_279 = convolution_backward_default_27[0]
        getitem_280 = convolution_backward_default_27[1]
        getitem_281 = convolution_backward_default_27[2];  convolution_backward_default_27 = None
        to_dtype_66 = torch.ops.aten.to.dtype(getitem_279, torch.float32);  getitem_279 = None
        to_dtype_67 = torch.ops.aten.to.dtype(clone_default_32, torch.float32);  clone_default_32 = None
        neg_default_16 = torch.ops.aten.neg.default(to_dtype_67)
        exp_default_16 = torch.ops.aten.exp.default(neg_default_16);  neg_default_16 = None
        add_tensor_98 = torch.ops.aten.add.Tensor(exp_default_16, 1);  exp_default_16 = None
        reciprocal_default_16 = torch.ops.aten.reciprocal.default(add_tensor_98);  add_tensor_98 = None
        mul_tensor_104 = torch.ops.aten.mul.Tensor(reciprocal_default_16, 1);  reciprocal_default_16 = None
        mul_tensor_105 = torch.ops.aten.mul.Tensor(to_dtype_66, mul_tensor_104);  to_dtype_66 = None
        rsub_scalar_22 = torch.ops.aten.rsub.Scalar(mul_tensor_104, 1);  mul_tensor_104 = None
        mul_tensor_106 = torch.ops.aten.mul.Tensor(to_dtype_67, rsub_scalar_22);  to_dtype_67 = rsub_scalar_22 = None
        add_tensor_99 = torch.ops.aten.add.Tensor(mul_tensor_106, 1);  mul_tensor_106 = None
        mul_tensor_107 = torch.ops.aten.mul.Tensor(mul_tensor_105, add_tensor_99);  mul_tensor_105 = add_tensor_99 = None
        to_dtype_68 = torch.ops.aten.to.dtype(mul_tensor_107, torch.float32);  mul_tensor_107 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(to_dtype_68, mean_dim_10, primals_76, [28], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_68 = mean_dim_10 = primals_76 = None
        getitem_282 = convolution_backward_default_28[0]
        getitem_283 = convolution_backward_default_28[1]
        getitem_284 = convolution_backward_default_28[2];  convolution_backward_default_28 = None
        expand_default_6 = torch.ops.aten.expand.default(getitem_282, [128, 672, 14, 14]);  getitem_282 = None
        div_scalar_6 = torch.ops.aten.div.Scalar(expand_default_6, 196);  expand_default_6 = None
        add_tensor_100 = torch.ops.aten.add.Tensor(mul_tensor_101, div_scalar_6);  mul_tensor_101 = div_scalar_6 = None
        to_dtype_69 = torch.ops.aten.to.dtype(add_tensor_100, torch.float32);  add_tensor_100 = None
        to_dtype_70 = torch.ops.aten.to.dtype(clone_default_31, torch.float32);  clone_default_31 = None
        neg_default_17 = torch.ops.aten.neg.default(to_dtype_70)
        exp_default_17 = torch.ops.aten.exp.default(neg_default_17);  neg_default_17 = None
        add_tensor_101 = torch.ops.aten.add.Tensor(exp_default_17, 1);  exp_default_17 = None
        reciprocal_default_17 = torch.ops.aten.reciprocal.default(add_tensor_101);  add_tensor_101 = None
        mul_tensor_108 = torch.ops.aten.mul.Tensor(reciprocal_default_17, 1);  reciprocal_default_17 = None
        mul_tensor_109 = torch.ops.aten.mul.Tensor(to_dtype_69, mul_tensor_108);  to_dtype_69 = None
        rsub_scalar_23 = torch.ops.aten.rsub.Scalar(mul_tensor_108, 1);  mul_tensor_108 = None
        mul_tensor_110 = torch.ops.aten.mul.Tensor(to_dtype_70, rsub_scalar_23);  to_dtype_70 = rsub_scalar_23 = None
        add_tensor_102 = torch.ops.aten.add.Tensor(mul_tensor_110, 1);  mul_tensor_110 = None
        mul_tensor_111 = torch.ops.aten.mul.Tensor(mul_tensor_109, add_tensor_102);  mul_tensor_109 = add_tensor_102 = None
        to_dtype_71 = torch.ops.aten.to.dtype(mul_tensor_111, torch.float32);  mul_tensor_111 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_71, convolution_default_51, primals_275, primals_273, primals_274, getitem_94, getitem_95, True, 0.001, [True, True, True]);  to_dtype_71 = convolution_default_51 = primals_275 = primals_273 = primals_274 = getitem_94 = getitem_95 = None
        getitem_285 = native_batch_norm_backward_default_17[0]
        getitem_286 = native_batch_norm_backward_default_17[1]
        getitem_287 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(getitem_285, silu__default_30, primals_70, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_285 = silu__default_30 = primals_70 = None
        getitem_288 = convolution_backward_default_29[0]
        getitem_289 = convolution_backward_default_29[1];  convolution_backward_default_29 = None
        to_dtype_72 = torch.ops.aten.to.dtype(getitem_288, torch.float32);  getitem_288 = None
        to_dtype_73 = torch.ops.aten.to.dtype(clone_default_30, torch.float32);  clone_default_30 = None
        neg_default_18 = torch.ops.aten.neg.default(to_dtype_73)
        exp_default_18 = torch.ops.aten.exp.default(neg_default_18);  neg_default_18 = None
        add_tensor_103 = torch.ops.aten.add.Tensor(exp_default_18, 1);  exp_default_18 = None
        reciprocal_default_18 = torch.ops.aten.reciprocal.default(add_tensor_103);  add_tensor_103 = None
        mul_tensor_112 = torch.ops.aten.mul.Tensor(reciprocal_default_18, 1);  reciprocal_default_18 = None
        mul_tensor_113 = torch.ops.aten.mul.Tensor(to_dtype_72, mul_tensor_112);  to_dtype_72 = None
        rsub_scalar_24 = torch.ops.aten.rsub.Scalar(mul_tensor_112, 1);  mul_tensor_112 = None
        mul_tensor_114 = torch.ops.aten.mul.Tensor(to_dtype_73, rsub_scalar_24);  to_dtype_73 = rsub_scalar_24 = None
        add_tensor_104 = torch.ops.aten.add.Tensor(mul_tensor_114, 1);  mul_tensor_114 = None
        mul_tensor_115 = torch.ops.aten.mul.Tensor(mul_tensor_113, add_tensor_104);  mul_tensor_113 = add_tensor_104 = None
        to_dtype_74 = torch.ops.aten.to.dtype(mul_tensor_115, torch.float32);  mul_tensor_115 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_74, convolution_default_50, primals_270, primals_268, primals_269, getitem_91, getitem_92, True, 0.001, [True, True, True]);  to_dtype_74 = convolution_default_50 = primals_270 = primals_268 = primals_269 = getitem_91 = getitem_92 = None
        getitem_291 = native_batch_norm_backward_default_18[0]
        getitem_292 = native_batch_norm_backward_default_18[1]
        getitem_293 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_291, add_tensor_34, primals_71, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_291 = add_tensor_34 = primals_71 = None
        getitem_294 = convolution_backward_default_30[0]
        getitem_295 = convolution_backward_default_30[1];  convolution_backward_default_30 = None
        add_tensor_105 = torch.ops.aten.add.Tensor(getitem_270, getitem_294);  getitem_270 = getitem_294 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_105, convolution_default_49, primals_265, primals_263, primals_264, getitem_88, getitem_89, True, 0.001, [True, True, True]);  convolution_default_49 = primals_265 = primals_263 = primals_264 = getitem_88 = getitem_89 = None
        getitem_297 = native_batch_norm_backward_default_19[0]
        getitem_298 = native_batch_norm_backward_default_19[1]
        getitem_299 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(getitem_297, mul_tensor_9, primals_65, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_297 = mul_tensor_9 = primals_65 = None
        getitem_300 = convolution_backward_default_31[0]
        getitem_301 = convolution_backward_default_31[1];  convolution_backward_default_31 = None
        mul_tensor_116 = torch.ops.aten.mul.Tensor(getitem_300, silu__default_28);  silu__default_28 = None
        mul_tensor_117 = torch.ops.aten.mul.Tensor(getitem_300, sigmoid_default_9);  getitem_300 = None
        sum_dim_int_list_7 = torch.ops.aten.sum.dim_IntList(mul_tensor_116, [2, 3], True);  mul_tensor_116 = None
        to_dtype_75 = torch.ops.aten.to.dtype(sum_dim_int_list_7, torch.float32);  sum_dim_int_list_7 = None
        to_dtype_76 = torch.ops.aten.to.dtype(sigmoid_default_9, torch.float32);  sigmoid_default_9 = None
        rsub_scalar_25 = torch.ops.aten.rsub.Scalar(to_dtype_76, 1)
        mul_tensor_118 = torch.ops.aten.mul.Tensor(to_dtype_76, rsub_scalar_25);  to_dtype_76 = rsub_scalar_25 = None
        conj_physical_default_6 = torch.ops.aten.conj_physical.default(mul_tensor_118);  mul_tensor_118 = None
        mul_tensor_119 = torch.ops.aten.mul.Tensor(to_dtype_75, conj_physical_default_6);  to_dtype_75 = conj_physical_default_6 = None
        to_dtype_77 = torch.ops.aten.to.dtype(mul_tensor_119, torch.float32);  mul_tensor_119 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(to_dtype_77, silu__default_29, primals_67, [672], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_77 = silu__default_29 = primals_67 = None
        getitem_303 = convolution_backward_default_32[0]
        getitem_304 = convolution_backward_default_32[1]
        getitem_305 = convolution_backward_default_32[2];  convolution_backward_default_32 = None
        to_dtype_78 = torch.ops.aten.to.dtype(getitem_303, torch.float32);  getitem_303 = None
        to_dtype_79 = torch.ops.aten.to.dtype(clone_default_29, torch.float32);  clone_default_29 = None
        neg_default_19 = torch.ops.aten.neg.default(to_dtype_79)
        exp_default_19 = torch.ops.aten.exp.default(neg_default_19);  neg_default_19 = None
        add_tensor_106 = torch.ops.aten.add.Tensor(exp_default_19, 1);  exp_default_19 = None
        reciprocal_default_19 = torch.ops.aten.reciprocal.default(add_tensor_106);  add_tensor_106 = None
        mul_tensor_120 = torch.ops.aten.mul.Tensor(reciprocal_default_19, 1);  reciprocal_default_19 = None
        mul_tensor_121 = torch.ops.aten.mul.Tensor(to_dtype_78, mul_tensor_120);  to_dtype_78 = None
        rsub_scalar_26 = torch.ops.aten.rsub.Scalar(mul_tensor_120, 1);  mul_tensor_120 = None
        mul_tensor_122 = torch.ops.aten.mul.Tensor(to_dtype_79, rsub_scalar_26);  to_dtype_79 = rsub_scalar_26 = None
        add_tensor_107 = torch.ops.aten.add.Tensor(mul_tensor_122, 1);  mul_tensor_122 = None
        mul_tensor_123 = torch.ops.aten.mul.Tensor(mul_tensor_121, add_tensor_107);  mul_tensor_121 = add_tensor_107 = None
        to_dtype_80 = torch.ops.aten.to.dtype(mul_tensor_123, torch.float32);  mul_tensor_123 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(to_dtype_80, mean_dim_9, primals_69, [28], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_80 = mean_dim_9 = primals_69 = None
        getitem_306 = convolution_backward_default_33[0]
        getitem_307 = convolution_backward_default_33[1]
        getitem_308 = convolution_backward_default_33[2];  convolution_backward_default_33 = None
        expand_default_7 = torch.ops.aten.expand.default(getitem_306, [128, 672, 14, 14]);  getitem_306 = None
        div_scalar_7 = torch.ops.aten.div.Scalar(expand_default_7, 196);  expand_default_7 = None
        add_tensor_108 = torch.ops.aten.add.Tensor(mul_tensor_117, div_scalar_7);  mul_tensor_117 = div_scalar_7 = None
        to_dtype_81 = torch.ops.aten.to.dtype(add_tensor_108, torch.float32);  add_tensor_108 = None
        to_dtype_82 = torch.ops.aten.to.dtype(clone_default_28, torch.float32);  clone_default_28 = None
        neg_default_20 = torch.ops.aten.neg.default(to_dtype_82)
        exp_default_20 = torch.ops.aten.exp.default(neg_default_20);  neg_default_20 = None
        add_tensor_109 = torch.ops.aten.add.Tensor(exp_default_20, 1);  exp_default_20 = None
        reciprocal_default_20 = torch.ops.aten.reciprocal.default(add_tensor_109);  add_tensor_109 = None
        mul_tensor_124 = torch.ops.aten.mul.Tensor(reciprocal_default_20, 1);  reciprocal_default_20 = None
        mul_tensor_125 = torch.ops.aten.mul.Tensor(to_dtype_81, mul_tensor_124);  to_dtype_81 = None
        rsub_scalar_27 = torch.ops.aten.rsub.Scalar(mul_tensor_124, 1);  mul_tensor_124 = None
        mul_tensor_126 = torch.ops.aten.mul.Tensor(to_dtype_82, rsub_scalar_27);  to_dtype_82 = rsub_scalar_27 = None
        add_tensor_110 = torch.ops.aten.add.Tensor(mul_tensor_126, 1);  mul_tensor_126 = None
        mul_tensor_127 = torch.ops.aten.mul.Tensor(mul_tensor_125, add_tensor_110);  mul_tensor_125 = add_tensor_110 = None
        to_dtype_83 = torch.ops.aten.to.dtype(mul_tensor_127, torch.float32);  mul_tensor_127 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_83, convolution_default_46, primals_260, primals_258, primals_259, getitem_85, getitem_86, True, 0.001, [True, True, True]);  to_dtype_83 = convolution_default_46 = primals_260 = primals_258 = primals_259 = getitem_85 = getitem_86 = None
        getitem_309 = native_batch_norm_backward_default_20[0]
        getitem_310 = native_batch_norm_backward_default_20[1]
        getitem_311 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(getitem_309, silu__default_27, primals_63, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_309 = silu__default_27 = primals_63 = None
        getitem_312 = convolution_backward_default_34[0]
        getitem_313 = convolution_backward_default_34[1];  convolution_backward_default_34 = None
        to_dtype_84 = torch.ops.aten.to.dtype(getitem_312, torch.float32);  getitem_312 = None
        to_dtype_85 = torch.ops.aten.to.dtype(clone_default_27, torch.float32);  clone_default_27 = None
        neg_default_21 = torch.ops.aten.neg.default(to_dtype_85)
        exp_default_21 = torch.ops.aten.exp.default(neg_default_21);  neg_default_21 = None
        add_tensor_111 = torch.ops.aten.add.Tensor(exp_default_21, 1);  exp_default_21 = None
        reciprocal_default_21 = torch.ops.aten.reciprocal.default(add_tensor_111);  add_tensor_111 = None
        mul_tensor_128 = torch.ops.aten.mul.Tensor(reciprocal_default_21, 1);  reciprocal_default_21 = None
        mul_tensor_129 = torch.ops.aten.mul.Tensor(to_dtype_84, mul_tensor_128);  to_dtype_84 = None
        rsub_scalar_28 = torch.ops.aten.rsub.Scalar(mul_tensor_128, 1);  mul_tensor_128 = None
        mul_tensor_130 = torch.ops.aten.mul.Tensor(to_dtype_85, rsub_scalar_28);  to_dtype_85 = rsub_scalar_28 = None
        add_tensor_112 = torch.ops.aten.add.Tensor(mul_tensor_130, 1);  mul_tensor_130 = None
        mul_tensor_131 = torch.ops.aten.mul.Tensor(mul_tensor_129, add_tensor_112);  mul_tensor_129 = add_tensor_112 = None
        to_dtype_86 = torch.ops.aten.to.dtype(mul_tensor_131, torch.float32);  mul_tensor_131 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_86, convolution_default_45, primals_255, primals_253, primals_254, getitem_82, getitem_83, True, 0.001, [True, True, True]);  to_dtype_86 = convolution_default_45 = primals_255 = primals_253 = primals_254 = getitem_82 = getitem_83 = None
        getitem_315 = native_batch_norm_backward_default_21[0]
        getitem_316 = native_batch_norm_backward_default_21[1]
        getitem_317 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_315, getitem_78, primals_64, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_315 = getitem_78 = primals_64 = None
        getitem_318 = convolution_backward_default_35[0]
        getitem_319 = convolution_backward_default_35[1];  convolution_backward_default_35 = None
        add_tensor_113 = torch.ops.aten.add.Tensor(add_tensor_105, getitem_318);  add_tensor_105 = getitem_318 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_113, convolution_default_44, primals_250, primals_248, primals_249, getitem_79, getitem_80, True, 0.001, [True, True, True]);  add_tensor_113 = convolution_default_44 = primals_250 = primals_248 = primals_249 = getitem_79 = getitem_80 = None
        getitem_321 = native_batch_norm_backward_default_22[0]
        getitem_322 = native_batch_norm_backward_default_22[1]
        getitem_323 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(getitem_321, mul_tensor_8, primals_58, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_321 = mul_tensor_8 = primals_58 = None
        getitem_324 = convolution_backward_default_36[0]
        getitem_325 = convolution_backward_default_36[1];  convolution_backward_default_36 = None
        mul_tensor_132 = torch.ops.aten.mul.Tensor(getitem_324, silu__default_25);  silu__default_25 = None
        mul_tensor_133 = torch.ops.aten.mul.Tensor(getitem_324, sigmoid_default_8);  getitem_324 = None
        sum_dim_int_list_8 = torch.ops.aten.sum.dim_IntList(mul_tensor_132, [2, 3], True);  mul_tensor_132 = None
        to_dtype_87 = torch.ops.aten.to.dtype(sum_dim_int_list_8, torch.float32);  sum_dim_int_list_8 = None
        to_dtype_88 = torch.ops.aten.to.dtype(sigmoid_default_8, torch.float32);  sigmoid_default_8 = None
        rsub_scalar_29 = torch.ops.aten.rsub.Scalar(to_dtype_88, 1)
        mul_tensor_134 = torch.ops.aten.mul.Tensor(to_dtype_88, rsub_scalar_29);  to_dtype_88 = rsub_scalar_29 = None
        conj_physical_default_7 = torch.ops.aten.conj_physical.default(mul_tensor_134);  mul_tensor_134 = None
        mul_tensor_135 = torch.ops.aten.mul.Tensor(to_dtype_87, conj_physical_default_7);  to_dtype_87 = conj_physical_default_7 = None
        to_dtype_89 = torch.ops.aten.to.dtype(mul_tensor_135, torch.float32);  mul_tensor_135 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(to_dtype_89, silu__default_26, primals_60, [480], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_89 = silu__default_26 = primals_60 = None
        getitem_327 = convolution_backward_default_37[0]
        getitem_328 = convolution_backward_default_37[1]
        getitem_329 = convolution_backward_default_37[2];  convolution_backward_default_37 = None
        to_dtype_90 = torch.ops.aten.to.dtype(getitem_327, torch.float32);  getitem_327 = None
        to_dtype_91 = torch.ops.aten.to.dtype(clone_default_26, torch.float32);  clone_default_26 = None
        neg_default_22 = torch.ops.aten.neg.default(to_dtype_91)
        exp_default_22 = torch.ops.aten.exp.default(neg_default_22);  neg_default_22 = None
        add_tensor_114 = torch.ops.aten.add.Tensor(exp_default_22, 1);  exp_default_22 = None
        reciprocal_default_22 = torch.ops.aten.reciprocal.default(add_tensor_114);  add_tensor_114 = None
        mul_tensor_136 = torch.ops.aten.mul.Tensor(reciprocal_default_22, 1);  reciprocal_default_22 = None
        mul_tensor_137 = torch.ops.aten.mul.Tensor(to_dtype_90, mul_tensor_136);  to_dtype_90 = None
        rsub_scalar_30 = torch.ops.aten.rsub.Scalar(mul_tensor_136, 1);  mul_tensor_136 = None
        mul_tensor_138 = torch.ops.aten.mul.Tensor(to_dtype_91, rsub_scalar_30);  to_dtype_91 = rsub_scalar_30 = None
        add_tensor_115 = torch.ops.aten.add.Tensor(mul_tensor_138, 1);  mul_tensor_138 = None
        mul_tensor_139 = torch.ops.aten.mul.Tensor(mul_tensor_137, add_tensor_115);  mul_tensor_137 = add_tensor_115 = None
        to_dtype_92 = torch.ops.aten.to.dtype(mul_tensor_139, torch.float32);  mul_tensor_139 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(to_dtype_92, mean_dim_8, primals_62, [20], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_92 = mean_dim_8 = primals_62 = None
        getitem_330 = convolution_backward_default_38[0]
        getitem_331 = convolution_backward_default_38[1]
        getitem_332 = convolution_backward_default_38[2];  convolution_backward_default_38 = None
        expand_default_8 = torch.ops.aten.expand.default(getitem_330, [128, 480, 14, 14]);  getitem_330 = None
        div_scalar_8 = torch.ops.aten.div.Scalar(expand_default_8, 196);  expand_default_8 = None
        add_tensor_116 = torch.ops.aten.add.Tensor(mul_tensor_133, div_scalar_8);  mul_tensor_133 = div_scalar_8 = None
        to_dtype_93 = torch.ops.aten.to.dtype(add_tensor_116, torch.float32);  add_tensor_116 = None
        to_dtype_94 = torch.ops.aten.to.dtype(clone_default_25, torch.float32);  clone_default_25 = None
        neg_default_23 = torch.ops.aten.neg.default(to_dtype_94)
        exp_default_23 = torch.ops.aten.exp.default(neg_default_23);  neg_default_23 = None
        add_tensor_117 = torch.ops.aten.add.Tensor(exp_default_23, 1);  exp_default_23 = None
        reciprocal_default_23 = torch.ops.aten.reciprocal.default(add_tensor_117);  add_tensor_117 = None
        mul_tensor_140 = torch.ops.aten.mul.Tensor(reciprocal_default_23, 1);  reciprocal_default_23 = None
        mul_tensor_141 = torch.ops.aten.mul.Tensor(to_dtype_93, mul_tensor_140);  to_dtype_93 = None
        rsub_scalar_31 = torch.ops.aten.rsub.Scalar(mul_tensor_140, 1);  mul_tensor_140 = None
        mul_tensor_142 = torch.ops.aten.mul.Tensor(to_dtype_94, rsub_scalar_31);  to_dtype_94 = rsub_scalar_31 = None
        add_tensor_118 = torch.ops.aten.add.Tensor(mul_tensor_142, 1);  mul_tensor_142 = None
        mul_tensor_143 = torch.ops.aten.mul.Tensor(mul_tensor_141, add_tensor_118);  mul_tensor_141 = add_tensor_118 = None
        to_dtype_95 = torch.ops.aten.to.dtype(mul_tensor_143, torch.float32);  mul_tensor_143 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_95, convolution_default_41, primals_245, primals_243, primals_244, getitem_76, getitem_77, True, 0.001, [True, True, True]);  to_dtype_95 = convolution_default_41 = primals_245 = primals_243 = primals_244 = getitem_76 = getitem_77 = None
        getitem_333 = native_batch_norm_backward_default_23[0]
        getitem_334 = native_batch_norm_backward_default_23[1]
        getitem_335 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(getitem_333, silu__default_24, primals_56, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 480, [True, True, False]);  getitem_333 = silu__default_24 = primals_56 = None
        getitem_336 = convolution_backward_default_39[0]
        getitem_337 = convolution_backward_default_39[1];  convolution_backward_default_39 = None
        to_dtype_96 = torch.ops.aten.to.dtype(getitem_336, torch.float32);  getitem_336 = None
        to_dtype_97 = torch.ops.aten.to.dtype(clone_default_24, torch.float32);  clone_default_24 = None
        neg_default_24 = torch.ops.aten.neg.default(to_dtype_97)
        exp_default_24 = torch.ops.aten.exp.default(neg_default_24);  neg_default_24 = None
        add_tensor_119 = torch.ops.aten.add.Tensor(exp_default_24, 1);  exp_default_24 = None
        reciprocal_default_24 = torch.ops.aten.reciprocal.default(add_tensor_119);  add_tensor_119 = None
        mul_tensor_144 = torch.ops.aten.mul.Tensor(reciprocal_default_24, 1);  reciprocal_default_24 = None
        mul_tensor_145 = torch.ops.aten.mul.Tensor(to_dtype_96, mul_tensor_144);  to_dtype_96 = None
        rsub_scalar_32 = torch.ops.aten.rsub.Scalar(mul_tensor_144, 1);  mul_tensor_144 = None
        mul_tensor_146 = torch.ops.aten.mul.Tensor(to_dtype_97, rsub_scalar_32);  to_dtype_97 = rsub_scalar_32 = None
        add_tensor_120 = torch.ops.aten.add.Tensor(mul_tensor_146, 1);  mul_tensor_146 = None
        mul_tensor_147 = torch.ops.aten.mul.Tensor(mul_tensor_145, add_tensor_120);  mul_tensor_145 = add_tensor_120 = None
        to_dtype_98 = torch.ops.aten.to.dtype(mul_tensor_147, torch.float32);  mul_tensor_147 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_98, convolution_default_40, primals_240, primals_238, primals_239, getitem_73, getitem_74, True, 0.001, [True, True, True]);  to_dtype_98 = convolution_default_40 = primals_240 = primals_238 = primals_239 = getitem_73 = getitem_74 = None
        getitem_339 = native_batch_norm_backward_default_24[0]
        getitem_340 = native_batch_norm_backward_default_24[1]
        getitem_341 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(getitem_339, add_tensor_27, primals_57, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_339 = add_tensor_27 = primals_57 = None
        getitem_342 = convolution_backward_default_40[0]
        getitem_343 = convolution_backward_default_40[1];  convolution_backward_default_40 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(getitem_342, convolution_default_39, primals_235, primals_233, primals_234, getitem_70, getitem_71, True, 0.001, [True, True, True]);  convolution_default_39 = primals_235 = primals_233 = primals_234 = getitem_70 = getitem_71 = None
        getitem_345 = native_batch_norm_backward_default_25[0]
        getitem_346 = native_batch_norm_backward_default_25[1]
        getitem_347 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(getitem_345, mul_tensor_7, primals_51, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_345 = mul_tensor_7 = primals_51 = None
        getitem_348 = convolution_backward_default_41[0]
        getitem_349 = convolution_backward_default_41[1];  convolution_backward_default_41 = None
        mul_tensor_148 = torch.ops.aten.mul.Tensor(getitem_348, silu__default_22);  silu__default_22 = None
        mul_tensor_149 = torch.ops.aten.mul.Tensor(getitem_348, sigmoid_default_7);  getitem_348 = None
        sum_dim_int_list_9 = torch.ops.aten.sum.dim_IntList(mul_tensor_148, [2, 3], True);  mul_tensor_148 = None
        to_dtype_99 = torch.ops.aten.to.dtype(sum_dim_int_list_9, torch.float32);  sum_dim_int_list_9 = None
        to_dtype_100 = torch.ops.aten.to.dtype(sigmoid_default_7, torch.float32);  sigmoid_default_7 = None
        rsub_scalar_33 = torch.ops.aten.rsub.Scalar(to_dtype_100, 1)
        mul_tensor_150 = torch.ops.aten.mul.Tensor(to_dtype_100, rsub_scalar_33);  to_dtype_100 = rsub_scalar_33 = None
        conj_physical_default_8 = torch.ops.aten.conj_physical.default(mul_tensor_150);  mul_tensor_150 = None
        mul_tensor_151 = torch.ops.aten.mul.Tensor(to_dtype_99, conj_physical_default_8);  to_dtype_99 = conj_physical_default_8 = None
        to_dtype_101 = torch.ops.aten.to.dtype(mul_tensor_151, torch.float32);  mul_tensor_151 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(to_dtype_101, silu__default_23, primals_53, [480], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_101 = silu__default_23 = primals_53 = None
        getitem_351 = convolution_backward_default_42[0]
        getitem_352 = convolution_backward_default_42[1]
        getitem_353 = convolution_backward_default_42[2];  convolution_backward_default_42 = None
        to_dtype_102 = torch.ops.aten.to.dtype(getitem_351, torch.float32);  getitem_351 = None
        to_dtype_103 = torch.ops.aten.to.dtype(clone_default_23, torch.float32);  clone_default_23 = None
        neg_default_25 = torch.ops.aten.neg.default(to_dtype_103)
        exp_default_25 = torch.ops.aten.exp.default(neg_default_25);  neg_default_25 = None
        add_tensor_121 = torch.ops.aten.add.Tensor(exp_default_25, 1);  exp_default_25 = None
        reciprocal_default_25 = torch.ops.aten.reciprocal.default(add_tensor_121);  add_tensor_121 = None
        mul_tensor_152 = torch.ops.aten.mul.Tensor(reciprocal_default_25, 1);  reciprocal_default_25 = None
        mul_tensor_153 = torch.ops.aten.mul.Tensor(to_dtype_102, mul_tensor_152);  to_dtype_102 = None
        rsub_scalar_34 = torch.ops.aten.rsub.Scalar(mul_tensor_152, 1);  mul_tensor_152 = None
        mul_tensor_154 = torch.ops.aten.mul.Tensor(to_dtype_103, rsub_scalar_34);  to_dtype_103 = rsub_scalar_34 = None
        add_tensor_122 = torch.ops.aten.add.Tensor(mul_tensor_154, 1);  mul_tensor_154 = None
        mul_tensor_155 = torch.ops.aten.mul.Tensor(mul_tensor_153, add_tensor_122);  mul_tensor_153 = add_tensor_122 = None
        to_dtype_104 = torch.ops.aten.to.dtype(mul_tensor_155, torch.float32);  mul_tensor_155 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(to_dtype_104, mean_dim_7, primals_55, [20], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_104 = mean_dim_7 = primals_55 = None
        getitem_354 = convolution_backward_default_43[0]
        getitem_355 = convolution_backward_default_43[1]
        getitem_356 = convolution_backward_default_43[2];  convolution_backward_default_43 = None
        expand_default_9 = torch.ops.aten.expand.default(getitem_354, [128, 480, 14, 14]);  getitem_354 = None
        div_scalar_9 = torch.ops.aten.div.Scalar(expand_default_9, 196);  expand_default_9 = None
        add_tensor_123 = torch.ops.aten.add.Tensor(mul_tensor_149, div_scalar_9);  mul_tensor_149 = div_scalar_9 = None
        to_dtype_105 = torch.ops.aten.to.dtype(add_tensor_123, torch.float32);  add_tensor_123 = None
        to_dtype_106 = torch.ops.aten.to.dtype(clone_default_22, torch.float32);  clone_default_22 = None
        neg_default_26 = torch.ops.aten.neg.default(to_dtype_106)
        exp_default_26 = torch.ops.aten.exp.default(neg_default_26);  neg_default_26 = None
        add_tensor_124 = torch.ops.aten.add.Tensor(exp_default_26, 1);  exp_default_26 = None
        reciprocal_default_26 = torch.ops.aten.reciprocal.default(add_tensor_124);  add_tensor_124 = None
        mul_tensor_156 = torch.ops.aten.mul.Tensor(reciprocal_default_26, 1);  reciprocal_default_26 = None
        mul_tensor_157 = torch.ops.aten.mul.Tensor(to_dtype_105, mul_tensor_156);  to_dtype_105 = None
        rsub_scalar_35 = torch.ops.aten.rsub.Scalar(mul_tensor_156, 1);  mul_tensor_156 = None
        mul_tensor_158 = torch.ops.aten.mul.Tensor(to_dtype_106, rsub_scalar_35);  to_dtype_106 = rsub_scalar_35 = None
        add_tensor_125 = torch.ops.aten.add.Tensor(mul_tensor_158, 1);  mul_tensor_158 = None
        mul_tensor_159 = torch.ops.aten.mul.Tensor(mul_tensor_157, add_tensor_125);  mul_tensor_157 = add_tensor_125 = None
        to_dtype_107 = torch.ops.aten.to.dtype(mul_tensor_159, torch.float32);  mul_tensor_159 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_107, convolution_default_36, primals_230, primals_228, primals_229, getitem_67, getitem_68, True, 0.001, [True, True, True]);  to_dtype_107 = convolution_default_36 = primals_230 = primals_228 = primals_229 = getitem_67 = getitem_68 = None
        getitem_357 = native_batch_norm_backward_default_26[0]
        getitem_358 = native_batch_norm_backward_default_26[1]
        getitem_359 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(getitem_357, silu__default_21, primals_49, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 480, [True, True, False]);  getitem_357 = silu__default_21 = primals_49 = None
        getitem_360 = convolution_backward_default_44[0]
        getitem_361 = convolution_backward_default_44[1];  convolution_backward_default_44 = None
        to_dtype_108 = torch.ops.aten.to.dtype(getitem_360, torch.float32);  getitem_360 = None
        to_dtype_109 = torch.ops.aten.to.dtype(clone_default_21, torch.float32);  clone_default_21 = None
        neg_default_27 = torch.ops.aten.neg.default(to_dtype_109)
        exp_default_27 = torch.ops.aten.exp.default(neg_default_27);  neg_default_27 = None
        add_tensor_126 = torch.ops.aten.add.Tensor(exp_default_27, 1);  exp_default_27 = None
        reciprocal_default_27 = torch.ops.aten.reciprocal.default(add_tensor_126);  add_tensor_126 = None
        mul_tensor_160 = torch.ops.aten.mul.Tensor(reciprocal_default_27, 1);  reciprocal_default_27 = None
        mul_tensor_161 = torch.ops.aten.mul.Tensor(to_dtype_108, mul_tensor_160);  to_dtype_108 = None
        rsub_scalar_36 = torch.ops.aten.rsub.Scalar(mul_tensor_160, 1);  mul_tensor_160 = None
        mul_tensor_162 = torch.ops.aten.mul.Tensor(to_dtype_109, rsub_scalar_36);  to_dtype_109 = rsub_scalar_36 = None
        add_tensor_127 = torch.ops.aten.add.Tensor(mul_tensor_162, 1);  mul_tensor_162 = None
        mul_tensor_163 = torch.ops.aten.mul.Tensor(mul_tensor_161, add_tensor_127);  mul_tensor_161 = add_tensor_127 = None
        to_dtype_110 = torch.ops.aten.to.dtype(mul_tensor_163, torch.float32);  mul_tensor_163 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_110, convolution_default_35, primals_225, primals_223, primals_224, getitem_64, getitem_65, True, 0.001, [True, True, True]);  to_dtype_110 = convolution_default_35 = primals_225 = primals_223 = primals_224 = getitem_64 = getitem_65 = None
        getitem_363 = native_batch_norm_backward_default_27[0]
        getitem_364 = native_batch_norm_backward_default_27[1]
        getitem_365 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(getitem_363, add_tensor_23, primals_50, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_363 = add_tensor_23 = primals_50 = None
        getitem_366 = convolution_backward_default_45[0]
        getitem_367 = convolution_backward_default_45[1];  convolution_backward_default_45 = None
        add_tensor_128 = torch.ops.aten.add.Tensor(getitem_342, getitem_366);  getitem_342 = getitem_366 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_128, convolution_default_34, primals_220, primals_218, primals_219, getitem_61, getitem_62, True, 0.001, [True, True, True]);  convolution_default_34 = primals_220 = primals_218 = primals_219 = getitem_61 = getitem_62 = None
        getitem_369 = native_batch_norm_backward_default_28[0]
        getitem_370 = native_batch_norm_backward_default_28[1]
        getitem_371 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(getitem_369, mul_tensor_6, primals_44, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_369 = mul_tensor_6 = primals_44 = None
        getitem_372 = convolution_backward_default_46[0]
        getitem_373 = convolution_backward_default_46[1];  convolution_backward_default_46 = None
        mul_tensor_164 = torch.ops.aten.mul.Tensor(getitem_372, silu__default_19);  silu__default_19 = None
        mul_tensor_165 = torch.ops.aten.mul.Tensor(getitem_372, sigmoid_default_6);  getitem_372 = None
        sum_dim_int_list_10 = torch.ops.aten.sum.dim_IntList(mul_tensor_164, [2, 3], True);  mul_tensor_164 = None
        to_dtype_111 = torch.ops.aten.to.dtype(sum_dim_int_list_10, torch.float32);  sum_dim_int_list_10 = None
        to_dtype_112 = torch.ops.aten.to.dtype(sigmoid_default_6, torch.float32);  sigmoid_default_6 = None
        rsub_scalar_37 = torch.ops.aten.rsub.Scalar(to_dtype_112, 1)
        mul_tensor_166 = torch.ops.aten.mul.Tensor(to_dtype_112, rsub_scalar_37);  to_dtype_112 = rsub_scalar_37 = None
        conj_physical_default_9 = torch.ops.aten.conj_physical.default(mul_tensor_166);  mul_tensor_166 = None
        mul_tensor_167 = torch.ops.aten.mul.Tensor(to_dtype_111, conj_physical_default_9);  to_dtype_111 = conj_physical_default_9 = None
        to_dtype_113 = torch.ops.aten.to.dtype(mul_tensor_167, torch.float32);  mul_tensor_167 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(to_dtype_113, silu__default_20, primals_46, [480], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_113 = silu__default_20 = primals_46 = None
        getitem_375 = convolution_backward_default_47[0]
        getitem_376 = convolution_backward_default_47[1]
        getitem_377 = convolution_backward_default_47[2];  convolution_backward_default_47 = None
        to_dtype_114 = torch.ops.aten.to.dtype(getitem_375, torch.float32);  getitem_375 = None
        to_dtype_115 = torch.ops.aten.to.dtype(clone_default_20, torch.float32);  clone_default_20 = None
        neg_default_28 = torch.ops.aten.neg.default(to_dtype_115)
        exp_default_28 = torch.ops.aten.exp.default(neg_default_28);  neg_default_28 = None
        add_tensor_129 = torch.ops.aten.add.Tensor(exp_default_28, 1);  exp_default_28 = None
        reciprocal_default_28 = torch.ops.aten.reciprocal.default(add_tensor_129);  add_tensor_129 = None
        mul_tensor_168 = torch.ops.aten.mul.Tensor(reciprocal_default_28, 1);  reciprocal_default_28 = None
        mul_tensor_169 = torch.ops.aten.mul.Tensor(to_dtype_114, mul_tensor_168);  to_dtype_114 = None
        rsub_scalar_38 = torch.ops.aten.rsub.Scalar(mul_tensor_168, 1);  mul_tensor_168 = None
        mul_tensor_170 = torch.ops.aten.mul.Tensor(to_dtype_115, rsub_scalar_38);  to_dtype_115 = rsub_scalar_38 = None
        add_tensor_130 = torch.ops.aten.add.Tensor(mul_tensor_170, 1);  mul_tensor_170 = None
        mul_tensor_171 = torch.ops.aten.mul.Tensor(mul_tensor_169, add_tensor_130);  mul_tensor_169 = add_tensor_130 = None
        to_dtype_116 = torch.ops.aten.to.dtype(mul_tensor_171, torch.float32);  mul_tensor_171 = None
        convolution_backward_default_48 = torch.ops.aten.convolution_backward.default(to_dtype_116, mean_dim_6, primals_48, [20], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_116 = mean_dim_6 = primals_48 = None
        getitem_378 = convolution_backward_default_48[0]
        getitem_379 = convolution_backward_default_48[1]
        getitem_380 = convolution_backward_default_48[2];  convolution_backward_default_48 = None
        expand_default_10 = torch.ops.aten.expand.default(getitem_378, [128, 480, 14, 14]);  getitem_378 = None
        div_scalar_10 = torch.ops.aten.div.Scalar(expand_default_10, 196);  expand_default_10 = None
        add_tensor_131 = torch.ops.aten.add.Tensor(mul_tensor_165, div_scalar_10);  mul_tensor_165 = div_scalar_10 = None
        to_dtype_117 = torch.ops.aten.to.dtype(add_tensor_131, torch.float32);  add_tensor_131 = None
        to_dtype_118 = torch.ops.aten.to.dtype(clone_default_19, torch.float32);  clone_default_19 = None
        neg_default_29 = torch.ops.aten.neg.default(to_dtype_118)
        exp_default_29 = torch.ops.aten.exp.default(neg_default_29);  neg_default_29 = None
        add_tensor_132 = torch.ops.aten.add.Tensor(exp_default_29, 1);  exp_default_29 = None
        reciprocal_default_29 = torch.ops.aten.reciprocal.default(add_tensor_132);  add_tensor_132 = None
        mul_tensor_172 = torch.ops.aten.mul.Tensor(reciprocal_default_29, 1);  reciprocal_default_29 = None
        mul_tensor_173 = torch.ops.aten.mul.Tensor(to_dtype_117, mul_tensor_172);  to_dtype_117 = None
        rsub_scalar_39 = torch.ops.aten.rsub.Scalar(mul_tensor_172, 1);  mul_tensor_172 = None
        mul_tensor_174 = torch.ops.aten.mul.Tensor(to_dtype_118, rsub_scalar_39);  to_dtype_118 = rsub_scalar_39 = None
        add_tensor_133 = torch.ops.aten.add.Tensor(mul_tensor_174, 1);  mul_tensor_174 = None
        mul_tensor_175 = torch.ops.aten.mul.Tensor(mul_tensor_173, add_tensor_133);  mul_tensor_173 = add_tensor_133 = None
        to_dtype_119 = torch.ops.aten.to.dtype(mul_tensor_175, torch.float32);  mul_tensor_175 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_119, convolution_default_31, primals_215, primals_213, primals_214, getitem_58, getitem_59, True, 0.001, [True, True, True]);  to_dtype_119 = convolution_default_31 = primals_215 = primals_213 = primals_214 = getitem_58 = getitem_59 = None
        getitem_381 = native_batch_norm_backward_default_29[0]
        getitem_382 = native_batch_norm_backward_default_29[1]
        getitem_383 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        convolution_backward_default_49 = torch.ops.aten.convolution_backward.default(getitem_381, silu__default_18, primals_42, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 480, [True, True, False]);  getitem_381 = silu__default_18 = primals_42 = None
        getitem_384 = convolution_backward_default_49[0]
        getitem_385 = convolution_backward_default_49[1];  convolution_backward_default_49 = None
        to_dtype_120 = torch.ops.aten.to.dtype(getitem_384, torch.float32);  getitem_384 = None
        to_dtype_121 = torch.ops.aten.to.dtype(clone_default_18, torch.float32);  clone_default_18 = None
        neg_default_30 = torch.ops.aten.neg.default(to_dtype_121)
        exp_default_30 = torch.ops.aten.exp.default(neg_default_30);  neg_default_30 = None
        add_tensor_134 = torch.ops.aten.add.Tensor(exp_default_30, 1);  exp_default_30 = None
        reciprocal_default_30 = torch.ops.aten.reciprocal.default(add_tensor_134);  add_tensor_134 = None
        mul_tensor_176 = torch.ops.aten.mul.Tensor(reciprocal_default_30, 1);  reciprocal_default_30 = None
        mul_tensor_177 = torch.ops.aten.mul.Tensor(to_dtype_120, mul_tensor_176);  to_dtype_120 = None
        rsub_scalar_40 = torch.ops.aten.rsub.Scalar(mul_tensor_176, 1);  mul_tensor_176 = None
        mul_tensor_178 = torch.ops.aten.mul.Tensor(to_dtype_121, rsub_scalar_40);  to_dtype_121 = rsub_scalar_40 = None
        add_tensor_135 = torch.ops.aten.add.Tensor(mul_tensor_178, 1);  mul_tensor_178 = None
        mul_tensor_179 = torch.ops.aten.mul.Tensor(mul_tensor_177, add_tensor_135);  mul_tensor_177 = add_tensor_135 = None
        to_dtype_122 = torch.ops.aten.to.dtype(mul_tensor_179, torch.float32);  mul_tensor_179 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_122, convolution_default_30, primals_210, primals_208, primals_209, getitem_55, getitem_56, True, 0.001, [True, True, True]);  to_dtype_122 = convolution_default_30 = primals_210 = primals_208 = primals_209 = getitem_55 = getitem_56 = None
        getitem_387 = native_batch_norm_backward_default_30[0]
        getitem_388 = native_batch_norm_backward_default_30[1]
        getitem_389 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_50 = torch.ops.aten.convolution_backward.default(getitem_387, getitem_51, primals_43, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_387 = getitem_51 = primals_43 = None
        getitem_390 = convolution_backward_default_50[0]
        getitem_391 = convolution_backward_default_50[1];  convolution_backward_default_50 = None
        add_tensor_136 = torch.ops.aten.add.Tensor(add_tensor_128, getitem_390);  add_tensor_128 = getitem_390 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_136, convolution_default_29, primals_205, primals_203, primals_204, getitem_52, getitem_53, True, 0.001, [True, True, True]);  add_tensor_136 = convolution_default_29 = primals_205 = primals_203 = primals_204 = getitem_52 = getitem_53 = None
        getitem_393 = native_batch_norm_backward_default_31[0]
        getitem_394 = native_batch_norm_backward_default_31[1]
        getitem_395 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        convolution_backward_default_51 = torch.ops.aten.convolution_backward.default(getitem_393, mul_tensor_5, primals_37, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_393 = mul_tensor_5 = primals_37 = None
        getitem_396 = convolution_backward_default_51[0]
        getitem_397 = convolution_backward_default_51[1];  convolution_backward_default_51 = None
        mul_tensor_180 = torch.ops.aten.mul.Tensor(getitem_396, silu__default_16);  silu__default_16 = None
        mul_tensor_181 = torch.ops.aten.mul.Tensor(getitem_396, sigmoid_default_5);  getitem_396 = None
        sum_dim_int_list_11 = torch.ops.aten.sum.dim_IntList(mul_tensor_180, [2, 3], True);  mul_tensor_180 = None
        to_dtype_123 = torch.ops.aten.to.dtype(sum_dim_int_list_11, torch.float32);  sum_dim_int_list_11 = None
        to_dtype_124 = torch.ops.aten.to.dtype(sigmoid_default_5, torch.float32);  sigmoid_default_5 = None
        rsub_scalar_41 = torch.ops.aten.rsub.Scalar(to_dtype_124, 1)
        mul_tensor_182 = torch.ops.aten.mul.Tensor(to_dtype_124, rsub_scalar_41);  to_dtype_124 = rsub_scalar_41 = None
        conj_physical_default_10 = torch.ops.aten.conj_physical.default(mul_tensor_182);  mul_tensor_182 = None
        mul_tensor_183 = torch.ops.aten.mul.Tensor(to_dtype_123, conj_physical_default_10);  to_dtype_123 = conj_physical_default_10 = None
        to_dtype_125 = torch.ops.aten.to.dtype(mul_tensor_183, torch.float32);  mul_tensor_183 = None
        convolution_backward_default_52 = torch.ops.aten.convolution_backward.default(to_dtype_125, silu__default_17, primals_39, [240], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_125 = silu__default_17 = primals_39 = None
        getitem_399 = convolution_backward_default_52[0]
        getitem_400 = convolution_backward_default_52[1]
        getitem_401 = convolution_backward_default_52[2];  convolution_backward_default_52 = None
        to_dtype_126 = torch.ops.aten.to.dtype(getitem_399, torch.float32);  getitem_399 = None
        to_dtype_127 = torch.ops.aten.to.dtype(clone_default_17, torch.float32);  clone_default_17 = None
        neg_default_31 = torch.ops.aten.neg.default(to_dtype_127)
        exp_default_31 = torch.ops.aten.exp.default(neg_default_31);  neg_default_31 = None
        add_tensor_137 = torch.ops.aten.add.Tensor(exp_default_31, 1);  exp_default_31 = None
        reciprocal_default_31 = torch.ops.aten.reciprocal.default(add_tensor_137);  add_tensor_137 = None
        mul_tensor_184 = torch.ops.aten.mul.Tensor(reciprocal_default_31, 1);  reciprocal_default_31 = None
        mul_tensor_185 = torch.ops.aten.mul.Tensor(to_dtype_126, mul_tensor_184);  to_dtype_126 = None
        rsub_scalar_42 = torch.ops.aten.rsub.Scalar(mul_tensor_184, 1);  mul_tensor_184 = None
        mul_tensor_186 = torch.ops.aten.mul.Tensor(to_dtype_127, rsub_scalar_42);  to_dtype_127 = rsub_scalar_42 = None
        add_tensor_138 = torch.ops.aten.add.Tensor(mul_tensor_186, 1);  mul_tensor_186 = None
        mul_tensor_187 = torch.ops.aten.mul.Tensor(mul_tensor_185, add_tensor_138);  mul_tensor_185 = add_tensor_138 = None
        to_dtype_128 = torch.ops.aten.to.dtype(mul_tensor_187, torch.float32);  mul_tensor_187 = None
        convolution_backward_default_53 = torch.ops.aten.convolution_backward.default(to_dtype_128, mean_dim_5, primals_41, [10], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_128 = mean_dim_5 = primals_41 = None
        getitem_402 = convolution_backward_default_53[0]
        getitem_403 = convolution_backward_default_53[1]
        getitem_404 = convolution_backward_default_53[2];  convolution_backward_default_53 = None
        expand_default_11 = torch.ops.aten.expand.default(getitem_402, [128, 240, 14, 14]);  getitem_402 = None
        div_scalar_11 = torch.ops.aten.div.Scalar(expand_default_11, 196);  expand_default_11 = None
        add_tensor_139 = torch.ops.aten.add.Tensor(mul_tensor_181, div_scalar_11);  mul_tensor_181 = div_scalar_11 = None
        to_dtype_129 = torch.ops.aten.to.dtype(add_tensor_139, torch.float32);  add_tensor_139 = None
        to_dtype_130 = torch.ops.aten.to.dtype(clone_default_16, torch.float32);  clone_default_16 = None
        neg_default_32 = torch.ops.aten.neg.default(to_dtype_130)
        exp_default_32 = torch.ops.aten.exp.default(neg_default_32);  neg_default_32 = None
        add_tensor_140 = torch.ops.aten.add.Tensor(exp_default_32, 1);  exp_default_32 = None
        reciprocal_default_32 = torch.ops.aten.reciprocal.default(add_tensor_140);  add_tensor_140 = None
        mul_tensor_188 = torch.ops.aten.mul.Tensor(reciprocal_default_32, 1);  reciprocal_default_32 = None
        mul_tensor_189 = torch.ops.aten.mul.Tensor(to_dtype_129, mul_tensor_188);  to_dtype_129 = None
        rsub_scalar_43 = torch.ops.aten.rsub.Scalar(mul_tensor_188, 1);  mul_tensor_188 = None
        mul_tensor_190 = torch.ops.aten.mul.Tensor(to_dtype_130, rsub_scalar_43);  to_dtype_130 = rsub_scalar_43 = None
        add_tensor_141 = torch.ops.aten.add.Tensor(mul_tensor_190, 1);  mul_tensor_190 = None
        mul_tensor_191 = torch.ops.aten.mul.Tensor(mul_tensor_189, add_tensor_141);  mul_tensor_189 = add_tensor_141 = None
        to_dtype_131 = torch.ops.aten.to.dtype(mul_tensor_191, torch.float32);  mul_tensor_191 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_131, convolution_default_26, primals_200, primals_198, primals_199, getitem_49, getitem_50, True, 0.001, [True, True, True]);  to_dtype_131 = convolution_default_26 = primals_200 = primals_198 = primals_199 = getitem_49 = getitem_50 = None
        getitem_405 = native_batch_norm_backward_default_32[0]
        getitem_406 = native_batch_norm_backward_default_32[1]
        getitem_407 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        convolution_backward_default_54 = torch.ops.aten.convolution_backward.default(getitem_405, constant_pad_nd_default_3, primals_35, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 240, [True, True, False]);  getitem_405 = constant_pad_nd_default_3 = primals_35 = None
        getitem_408 = convolution_backward_default_54[0]
        getitem_409 = convolution_backward_default_54[1];  convolution_backward_default_54 = None
        constant_pad_nd_default_6 = torch.ops.aten.constant_pad_nd.default(getitem_408, [0, -1, 0, -1]);  getitem_408 = None
        to_dtype_132 = torch.ops.aten.to.dtype(constant_pad_nd_default_6, torch.float32);  constant_pad_nd_default_6 = None
        to_dtype_133 = torch.ops.aten.to.dtype(clone_default_15, torch.float32);  clone_default_15 = None
        neg_default_33 = torch.ops.aten.neg.default(to_dtype_133)
        exp_default_33 = torch.ops.aten.exp.default(neg_default_33);  neg_default_33 = None
        add_tensor_142 = torch.ops.aten.add.Tensor(exp_default_33, 1);  exp_default_33 = None
        reciprocal_default_33 = torch.ops.aten.reciprocal.default(add_tensor_142);  add_tensor_142 = None
        mul_tensor_192 = torch.ops.aten.mul.Tensor(reciprocal_default_33, 1);  reciprocal_default_33 = None
        mul_tensor_193 = torch.ops.aten.mul.Tensor(to_dtype_132, mul_tensor_192);  to_dtype_132 = None
        rsub_scalar_44 = torch.ops.aten.rsub.Scalar(mul_tensor_192, 1);  mul_tensor_192 = None
        mul_tensor_194 = torch.ops.aten.mul.Tensor(to_dtype_133, rsub_scalar_44);  to_dtype_133 = rsub_scalar_44 = None
        add_tensor_143 = torch.ops.aten.add.Tensor(mul_tensor_194, 1);  mul_tensor_194 = None
        mul_tensor_195 = torch.ops.aten.mul.Tensor(mul_tensor_193, add_tensor_143);  mul_tensor_193 = add_tensor_143 = None
        to_dtype_134 = torch.ops.aten.to.dtype(mul_tensor_195, torch.float32);  mul_tensor_195 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_134, convolution_default_25, primals_195, primals_193, primals_194, getitem_46, getitem_47, True, 0.001, [True, True, True]);  to_dtype_134 = convolution_default_25 = primals_195 = primals_193 = primals_194 = getitem_46 = getitem_47 = None
        getitem_411 = native_batch_norm_backward_default_33[0]
        getitem_412 = native_batch_norm_backward_default_33[1]
        getitem_413 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        convolution_backward_default_55 = torch.ops.aten.convolution_backward.default(getitem_411, add_tensor_16, primals_36, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_411 = add_tensor_16 = primals_36 = None
        getitem_414 = convolution_backward_default_55[0]
        getitem_415 = convolution_backward_default_55[1];  convolution_backward_default_55 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(getitem_414, convolution_default_24, primals_190, primals_188, primals_189, getitem_43, getitem_44, True, 0.001, [True, True, True]);  convolution_default_24 = primals_190 = primals_188 = primals_189 = getitem_43 = getitem_44 = None
        getitem_417 = native_batch_norm_backward_default_34[0]
        getitem_418 = native_batch_norm_backward_default_34[1]
        getitem_419 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        convolution_backward_default_56 = torch.ops.aten.convolution_backward.default(getitem_417, mul_tensor_4, primals_30, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_417 = mul_tensor_4 = primals_30 = None
        getitem_420 = convolution_backward_default_56[0]
        getitem_421 = convolution_backward_default_56[1];  convolution_backward_default_56 = None
        mul_tensor_196 = torch.ops.aten.mul.Tensor(getitem_420, silu__default_13);  silu__default_13 = None
        mul_tensor_197 = torch.ops.aten.mul.Tensor(getitem_420, sigmoid_default_4);  getitem_420 = None
        sum_dim_int_list_12 = torch.ops.aten.sum.dim_IntList(mul_tensor_196, [2, 3], True);  mul_tensor_196 = None
        to_dtype_135 = torch.ops.aten.to.dtype(sum_dim_int_list_12, torch.float32);  sum_dim_int_list_12 = None
        to_dtype_136 = torch.ops.aten.to.dtype(sigmoid_default_4, torch.float32);  sigmoid_default_4 = None
        rsub_scalar_45 = torch.ops.aten.rsub.Scalar(to_dtype_136, 1)
        mul_tensor_198 = torch.ops.aten.mul.Tensor(to_dtype_136, rsub_scalar_45);  to_dtype_136 = rsub_scalar_45 = None
        conj_physical_default_11 = torch.ops.aten.conj_physical.default(mul_tensor_198);  mul_tensor_198 = None
        mul_tensor_199 = torch.ops.aten.mul.Tensor(to_dtype_135, conj_physical_default_11);  to_dtype_135 = conj_physical_default_11 = None
        to_dtype_137 = torch.ops.aten.to.dtype(mul_tensor_199, torch.float32);  mul_tensor_199 = None
        convolution_backward_default_57 = torch.ops.aten.convolution_backward.default(to_dtype_137, silu__default_14, primals_32, [240], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_137 = silu__default_14 = primals_32 = None
        getitem_423 = convolution_backward_default_57[0]
        getitem_424 = convolution_backward_default_57[1]
        getitem_425 = convolution_backward_default_57[2];  convolution_backward_default_57 = None
        to_dtype_138 = torch.ops.aten.to.dtype(getitem_423, torch.float32);  getitem_423 = None
        to_dtype_139 = torch.ops.aten.to.dtype(clone_default_14, torch.float32);  clone_default_14 = None
        neg_default_34 = torch.ops.aten.neg.default(to_dtype_139)
        exp_default_34 = torch.ops.aten.exp.default(neg_default_34);  neg_default_34 = None
        add_tensor_144 = torch.ops.aten.add.Tensor(exp_default_34, 1);  exp_default_34 = None
        reciprocal_default_34 = torch.ops.aten.reciprocal.default(add_tensor_144);  add_tensor_144 = None
        mul_tensor_200 = torch.ops.aten.mul.Tensor(reciprocal_default_34, 1);  reciprocal_default_34 = None
        mul_tensor_201 = torch.ops.aten.mul.Tensor(to_dtype_138, mul_tensor_200);  to_dtype_138 = None
        rsub_scalar_46 = torch.ops.aten.rsub.Scalar(mul_tensor_200, 1);  mul_tensor_200 = None
        mul_tensor_202 = torch.ops.aten.mul.Tensor(to_dtype_139, rsub_scalar_46);  to_dtype_139 = rsub_scalar_46 = None
        add_tensor_145 = torch.ops.aten.add.Tensor(mul_tensor_202, 1);  mul_tensor_202 = None
        mul_tensor_203 = torch.ops.aten.mul.Tensor(mul_tensor_201, add_tensor_145);  mul_tensor_201 = add_tensor_145 = None
        to_dtype_140 = torch.ops.aten.to.dtype(mul_tensor_203, torch.float32);  mul_tensor_203 = None
        convolution_backward_default_58 = torch.ops.aten.convolution_backward.default(to_dtype_140, mean_dim_4, primals_34, [10], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_140 = mean_dim_4 = primals_34 = None
        getitem_426 = convolution_backward_default_58[0]
        getitem_427 = convolution_backward_default_58[1]
        getitem_428 = convolution_backward_default_58[2];  convolution_backward_default_58 = None
        expand_default_12 = torch.ops.aten.expand.default(getitem_426, [128, 240, 28, 28]);  getitem_426 = None
        div_scalar_12 = torch.ops.aten.div.Scalar(expand_default_12, 784);  expand_default_12 = None
        add_tensor_146 = torch.ops.aten.add.Tensor(mul_tensor_197, div_scalar_12);  mul_tensor_197 = div_scalar_12 = None
        to_dtype_141 = torch.ops.aten.to.dtype(add_tensor_146, torch.float32);  add_tensor_146 = None
        to_dtype_142 = torch.ops.aten.to.dtype(clone_default_13, torch.float32);  clone_default_13 = None
        neg_default_35 = torch.ops.aten.neg.default(to_dtype_142)
        exp_default_35 = torch.ops.aten.exp.default(neg_default_35);  neg_default_35 = None
        add_tensor_147 = torch.ops.aten.add.Tensor(exp_default_35, 1);  exp_default_35 = None
        reciprocal_default_35 = torch.ops.aten.reciprocal.default(add_tensor_147);  add_tensor_147 = None
        mul_tensor_204 = torch.ops.aten.mul.Tensor(reciprocal_default_35, 1);  reciprocal_default_35 = None
        mul_tensor_205 = torch.ops.aten.mul.Tensor(to_dtype_141, mul_tensor_204);  to_dtype_141 = None
        rsub_scalar_47 = torch.ops.aten.rsub.Scalar(mul_tensor_204, 1);  mul_tensor_204 = None
        mul_tensor_206 = torch.ops.aten.mul.Tensor(to_dtype_142, rsub_scalar_47);  to_dtype_142 = rsub_scalar_47 = None
        add_tensor_148 = torch.ops.aten.add.Tensor(mul_tensor_206, 1);  mul_tensor_206 = None
        mul_tensor_207 = torch.ops.aten.mul.Tensor(mul_tensor_205, add_tensor_148);  mul_tensor_205 = add_tensor_148 = None
        to_dtype_143 = torch.ops.aten.to.dtype(mul_tensor_207, torch.float32);  mul_tensor_207 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_143, convolution_default_21, primals_185, primals_183, primals_184, getitem_40, getitem_41, True, 0.001, [True, True, True]);  to_dtype_143 = convolution_default_21 = primals_185 = primals_183 = primals_184 = getitem_40 = getitem_41 = None
        getitem_429 = native_batch_norm_backward_default_35[0]
        getitem_430 = native_batch_norm_backward_default_35[1]
        getitem_431 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        convolution_backward_default_59 = torch.ops.aten.convolution_backward.default(getitem_429, silu__default_12, primals_28, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 240, [True, True, False]);  getitem_429 = silu__default_12 = primals_28 = None
        getitem_432 = convolution_backward_default_59[0]
        getitem_433 = convolution_backward_default_59[1];  convolution_backward_default_59 = None
        to_dtype_144 = torch.ops.aten.to.dtype(getitem_432, torch.float32);  getitem_432 = None
        to_dtype_145 = torch.ops.aten.to.dtype(clone_default_12, torch.float32);  clone_default_12 = None
        neg_default_36 = torch.ops.aten.neg.default(to_dtype_145)
        exp_default_36 = torch.ops.aten.exp.default(neg_default_36);  neg_default_36 = None
        add_tensor_149 = torch.ops.aten.add.Tensor(exp_default_36, 1);  exp_default_36 = None
        reciprocal_default_36 = torch.ops.aten.reciprocal.default(add_tensor_149);  add_tensor_149 = None
        mul_tensor_208 = torch.ops.aten.mul.Tensor(reciprocal_default_36, 1);  reciprocal_default_36 = None
        mul_tensor_209 = torch.ops.aten.mul.Tensor(to_dtype_144, mul_tensor_208);  to_dtype_144 = None
        rsub_scalar_48 = torch.ops.aten.rsub.Scalar(mul_tensor_208, 1);  mul_tensor_208 = None
        mul_tensor_210 = torch.ops.aten.mul.Tensor(to_dtype_145, rsub_scalar_48);  to_dtype_145 = rsub_scalar_48 = None
        add_tensor_150 = torch.ops.aten.add.Tensor(mul_tensor_210, 1);  mul_tensor_210 = None
        mul_tensor_211 = torch.ops.aten.mul.Tensor(mul_tensor_209, add_tensor_150);  mul_tensor_209 = add_tensor_150 = None
        to_dtype_146 = torch.ops.aten.to.dtype(mul_tensor_211, torch.float32);  mul_tensor_211 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_146, convolution_default_20, primals_180, primals_178, primals_179, getitem_37, getitem_38, True, 0.001, [True, True, True]);  to_dtype_146 = convolution_default_20 = primals_180 = primals_178 = primals_179 = getitem_37 = getitem_38 = None
        getitem_435 = native_batch_norm_backward_default_36[0]
        getitem_436 = native_batch_norm_backward_default_36[1]
        getitem_437 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        convolution_backward_default_60 = torch.ops.aten.convolution_backward.default(getitem_435, getitem_33, primals_29, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_435 = getitem_33 = primals_29 = None
        getitem_438 = convolution_backward_default_60[0]
        getitem_439 = convolution_backward_default_60[1];  convolution_backward_default_60 = None
        add_tensor_151 = torch.ops.aten.add.Tensor(getitem_414, getitem_438);  getitem_414 = getitem_438 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_151, convolution_default_19, primals_175, primals_173, primals_174, getitem_34, getitem_35, True, 0.001, [True, True, True]);  add_tensor_151 = convolution_default_19 = primals_175 = primals_173 = primals_174 = getitem_34 = getitem_35 = None
        getitem_441 = native_batch_norm_backward_default_37[0]
        getitem_442 = native_batch_norm_backward_default_37[1]
        getitem_443 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        convolution_backward_default_61 = torch.ops.aten.convolution_backward.default(getitem_441, mul_tensor_3, primals_23, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_441 = mul_tensor_3 = primals_23 = None
        getitem_444 = convolution_backward_default_61[0]
        getitem_445 = convolution_backward_default_61[1];  convolution_backward_default_61 = None
        mul_tensor_212 = torch.ops.aten.mul.Tensor(getitem_444, silu__default_10);  silu__default_10 = None
        mul_tensor_213 = torch.ops.aten.mul.Tensor(getitem_444, sigmoid_default_3);  getitem_444 = None
        sum_dim_int_list_13 = torch.ops.aten.sum.dim_IntList(mul_tensor_212, [2, 3], True);  mul_tensor_212 = None
        to_dtype_147 = torch.ops.aten.to.dtype(sum_dim_int_list_13, torch.float32);  sum_dim_int_list_13 = None
        to_dtype_148 = torch.ops.aten.to.dtype(sigmoid_default_3, torch.float32);  sigmoid_default_3 = None
        rsub_scalar_49 = torch.ops.aten.rsub.Scalar(to_dtype_148, 1)
        mul_tensor_214 = torch.ops.aten.mul.Tensor(to_dtype_148, rsub_scalar_49);  to_dtype_148 = rsub_scalar_49 = None
        conj_physical_default_12 = torch.ops.aten.conj_physical.default(mul_tensor_214);  mul_tensor_214 = None
        mul_tensor_215 = torch.ops.aten.mul.Tensor(to_dtype_147, conj_physical_default_12);  to_dtype_147 = conj_physical_default_12 = None
        to_dtype_149 = torch.ops.aten.to.dtype(mul_tensor_215, torch.float32);  mul_tensor_215 = None
        convolution_backward_default_62 = torch.ops.aten.convolution_backward.default(to_dtype_149, silu__default_11, primals_25, [144], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_149 = silu__default_11 = primals_25 = None
        getitem_447 = convolution_backward_default_62[0]
        getitem_448 = convolution_backward_default_62[1]
        getitem_449 = convolution_backward_default_62[2];  convolution_backward_default_62 = None
        to_dtype_150 = torch.ops.aten.to.dtype(getitem_447, torch.float32);  getitem_447 = None
        to_dtype_151 = torch.ops.aten.to.dtype(clone_default_11, torch.float32);  clone_default_11 = None
        neg_default_37 = torch.ops.aten.neg.default(to_dtype_151)
        exp_default_37 = torch.ops.aten.exp.default(neg_default_37);  neg_default_37 = None
        add_tensor_152 = torch.ops.aten.add.Tensor(exp_default_37, 1);  exp_default_37 = None
        reciprocal_default_37 = torch.ops.aten.reciprocal.default(add_tensor_152);  add_tensor_152 = None
        mul_tensor_216 = torch.ops.aten.mul.Tensor(reciprocal_default_37, 1);  reciprocal_default_37 = None
        mul_tensor_217 = torch.ops.aten.mul.Tensor(to_dtype_150, mul_tensor_216);  to_dtype_150 = None
        rsub_scalar_50 = torch.ops.aten.rsub.Scalar(mul_tensor_216, 1);  mul_tensor_216 = None
        mul_tensor_218 = torch.ops.aten.mul.Tensor(to_dtype_151, rsub_scalar_50);  to_dtype_151 = rsub_scalar_50 = None
        add_tensor_153 = torch.ops.aten.add.Tensor(mul_tensor_218, 1);  mul_tensor_218 = None
        mul_tensor_219 = torch.ops.aten.mul.Tensor(mul_tensor_217, add_tensor_153);  mul_tensor_217 = add_tensor_153 = None
        to_dtype_152 = torch.ops.aten.to.dtype(mul_tensor_219, torch.float32);  mul_tensor_219 = None
        convolution_backward_default_63 = torch.ops.aten.convolution_backward.default(to_dtype_152, mean_dim_3, primals_27, [6], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_152 = mean_dim_3 = primals_27 = None
        getitem_450 = convolution_backward_default_63[0]
        getitem_451 = convolution_backward_default_63[1]
        getitem_452 = convolution_backward_default_63[2];  convolution_backward_default_63 = None
        expand_default_13 = torch.ops.aten.expand.default(getitem_450, [128, 144, 28, 28]);  getitem_450 = None
        div_scalar_13 = torch.ops.aten.div.Scalar(expand_default_13, 784);  expand_default_13 = None
        add_tensor_154 = torch.ops.aten.add.Tensor(mul_tensor_213, div_scalar_13);  mul_tensor_213 = div_scalar_13 = None
        to_dtype_153 = torch.ops.aten.to.dtype(add_tensor_154, torch.float32);  add_tensor_154 = None
        to_dtype_154 = torch.ops.aten.to.dtype(clone_default_10, torch.float32);  clone_default_10 = None
        neg_default_38 = torch.ops.aten.neg.default(to_dtype_154)
        exp_default_38 = torch.ops.aten.exp.default(neg_default_38);  neg_default_38 = None
        add_tensor_155 = torch.ops.aten.add.Tensor(exp_default_38, 1);  exp_default_38 = None
        reciprocal_default_38 = torch.ops.aten.reciprocal.default(add_tensor_155);  add_tensor_155 = None
        mul_tensor_220 = torch.ops.aten.mul.Tensor(reciprocal_default_38, 1);  reciprocal_default_38 = None
        mul_tensor_221 = torch.ops.aten.mul.Tensor(to_dtype_153, mul_tensor_220);  to_dtype_153 = None
        rsub_scalar_51 = torch.ops.aten.rsub.Scalar(mul_tensor_220, 1);  mul_tensor_220 = None
        mul_tensor_222 = torch.ops.aten.mul.Tensor(to_dtype_154, rsub_scalar_51);  to_dtype_154 = rsub_scalar_51 = None
        add_tensor_156 = torch.ops.aten.add.Tensor(mul_tensor_222, 1);  mul_tensor_222 = None
        mul_tensor_223 = torch.ops.aten.mul.Tensor(mul_tensor_221, add_tensor_156);  mul_tensor_221 = add_tensor_156 = None
        to_dtype_155 = torch.ops.aten.to.dtype(mul_tensor_223, torch.float32);  mul_tensor_223 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_155, convolution_default_16, primals_170, primals_168, primals_169, getitem_31, getitem_32, True, 0.001, [True, True, True]);  to_dtype_155 = convolution_default_16 = primals_170 = primals_168 = primals_169 = getitem_31 = getitem_32 = None
        getitem_453 = native_batch_norm_backward_default_38[0]
        getitem_454 = native_batch_norm_backward_default_38[1]
        getitem_455 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        convolution_backward_default_64 = torch.ops.aten.convolution_backward.default(getitem_453, constant_pad_nd_default_2, primals_21, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 144, [True, True, False]);  getitem_453 = constant_pad_nd_default_2 = primals_21 = None
        getitem_456 = convolution_backward_default_64[0]
        getitem_457 = convolution_backward_default_64[1];  convolution_backward_default_64 = None
        constant_pad_nd_default_7 = torch.ops.aten.constant_pad_nd.default(getitem_456, [-1, -2, -1, -2]);  getitem_456 = None
        to_dtype_156 = torch.ops.aten.to.dtype(constant_pad_nd_default_7, torch.float32);  constant_pad_nd_default_7 = None
        to_dtype_157 = torch.ops.aten.to.dtype(clone_default_9, torch.float32);  clone_default_9 = None
        neg_default_39 = torch.ops.aten.neg.default(to_dtype_157)
        exp_default_39 = torch.ops.aten.exp.default(neg_default_39);  neg_default_39 = None
        add_tensor_157 = torch.ops.aten.add.Tensor(exp_default_39, 1);  exp_default_39 = None
        reciprocal_default_39 = torch.ops.aten.reciprocal.default(add_tensor_157);  add_tensor_157 = None
        mul_tensor_224 = torch.ops.aten.mul.Tensor(reciprocal_default_39, 1);  reciprocal_default_39 = None
        mul_tensor_225 = torch.ops.aten.mul.Tensor(to_dtype_156, mul_tensor_224);  to_dtype_156 = None
        rsub_scalar_52 = torch.ops.aten.rsub.Scalar(mul_tensor_224, 1);  mul_tensor_224 = None
        mul_tensor_226 = torch.ops.aten.mul.Tensor(to_dtype_157, rsub_scalar_52);  to_dtype_157 = rsub_scalar_52 = None
        add_tensor_158 = torch.ops.aten.add.Tensor(mul_tensor_226, 1);  mul_tensor_226 = None
        mul_tensor_227 = torch.ops.aten.mul.Tensor(mul_tensor_225, add_tensor_158);  mul_tensor_225 = add_tensor_158 = None
        to_dtype_158 = torch.ops.aten.to.dtype(mul_tensor_227, torch.float32);  mul_tensor_227 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_158, convolution_default_15, primals_165, primals_163, primals_164, getitem_28, getitem_29, True, 0.001, [True, True, True]);  to_dtype_158 = convolution_default_15 = primals_165 = primals_163 = primals_164 = getitem_28 = getitem_29 = None
        getitem_459 = native_batch_norm_backward_default_39[0]
        getitem_460 = native_batch_norm_backward_default_39[1]
        getitem_461 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        convolution_backward_default_65 = torch.ops.aten.convolution_backward.default(getitem_459, add_tensor_9, primals_22, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_459 = add_tensor_9 = primals_22 = None
        getitem_462 = convolution_backward_default_65[0]
        getitem_463 = convolution_backward_default_65[1];  convolution_backward_default_65 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(getitem_462, convolution_default_14, primals_160, primals_158, primals_159, getitem_25, getitem_26, True, 0.001, [True, True, True]);  convolution_default_14 = primals_160 = primals_158 = primals_159 = getitem_25 = getitem_26 = None
        getitem_465 = native_batch_norm_backward_default_40[0]
        getitem_466 = native_batch_norm_backward_default_40[1]
        getitem_467 = native_batch_norm_backward_default_40[2];  native_batch_norm_backward_default_40 = None
        convolution_backward_default_66 = torch.ops.aten.convolution_backward.default(getitem_465, mul_tensor_2, primals_16, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_465 = mul_tensor_2 = primals_16 = None
        getitem_468 = convolution_backward_default_66[0]
        getitem_469 = convolution_backward_default_66[1];  convolution_backward_default_66 = None
        mul_tensor_228 = torch.ops.aten.mul.Tensor(getitem_468, silu__default_7);  silu__default_7 = None
        mul_tensor_229 = torch.ops.aten.mul.Tensor(getitem_468, sigmoid_default_2);  getitem_468 = None
        sum_dim_int_list_14 = torch.ops.aten.sum.dim_IntList(mul_tensor_228, [2, 3], True);  mul_tensor_228 = None
        to_dtype_159 = torch.ops.aten.to.dtype(sum_dim_int_list_14, torch.float32);  sum_dim_int_list_14 = None
        to_dtype_160 = torch.ops.aten.to.dtype(sigmoid_default_2, torch.float32);  sigmoid_default_2 = None
        rsub_scalar_53 = torch.ops.aten.rsub.Scalar(to_dtype_160, 1)
        mul_tensor_230 = torch.ops.aten.mul.Tensor(to_dtype_160, rsub_scalar_53);  to_dtype_160 = rsub_scalar_53 = None
        conj_physical_default_13 = torch.ops.aten.conj_physical.default(mul_tensor_230);  mul_tensor_230 = None
        mul_tensor_231 = torch.ops.aten.mul.Tensor(to_dtype_159, conj_physical_default_13);  to_dtype_159 = conj_physical_default_13 = None
        to_dtype_161 = torch.ops.aten.to.dtype(mul_tensor_231, torch.float32);  mul_tensor_231 = None
        convolution_backward_default_67 = torch.ops.aten.convolution_backward.default(to_dtype_161, silu__default_8, primals_18, [144], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_161 = silu__default_8 = primals_18 = None
        getitem_471 = convolution_backward_default_67[0]
        getitem_472 = convolution_backward_default_67[1]
        getitem_473 = convolution_backward_default_67[2];  convolution_backward_default_67 = None
        to_dtype_162 = torch.ops.aten.to.dtype(getitem_471, torch.float32);  getitem_471 = None
        to_dtype_163 = torch.ops.aten.to.dtype(clone_default_8, torch.float32);  clone_default_8 = None
        neg_default_40 = torch.ops.aten.neg.default(to_dtype_163)
        exp_default_40 = torch.ops.aten.exp.default(neg_default_40);  neg_default_40 = None
        add_tensor_159 = torch.ops.aten.add.Tensor(exp_default_40, 1);  exp_default_40 = None
        reciprocal_default_40 = torch.ops.aten.reciprocal.default(add_tensor_159);  add_tensor_159 = None
        mul_tensor_232 = torch.ops.aten.mul.Tensor(reciprocal_default_40, 1);  reciprocal_default_40 = None
        mul_tensor_233 = torch.ops.aten.mul.Tensor(to_dtype_162, mul_tensor_232);  to_dtype_162 = None
        rsub_scalar_54 = torch.ops.aten.rsub.Scalar(mul_tensor_232, 1);  mul_tensor_232 = None
        mul_tensor_234 = torch.ops.aten.mul.Tensor(to_dtype_163, rsub_scalar_54);  to_dtype_163 = rsub_scalar_54 = None
        add_tensor_160 = torch.ops.aten.add.Tensor(mul_tensor_234, 1);  mul_tensor_234 = None
        mul_tensor_235 = torch.ops.aten.mul.Tensor(mul_tensor_233, add_tensor_160);  mul_tensor_233 = add_tensor_160 = None
        to_dtype_164 = torch.ops.aten.to.dtype(mul_tensor_235, torch.float32);  mul_tensor_235 = None
        convolution_backward_default_68 = torch.ops.aten.convolution_backward.default(to_dtype_164, mean_dim_2, primals_20, [6], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_164 = mean_dim_2 = primals_20 = None
        getitem_474 = convolution_backward_default_68[0]
        getitem_475 = convolution_backward_default_68[1]
        getitem_476 = convolution_backward_default_68[2];  convolution_backward_default_68 = None
        expand_default_14 = torch.ops.aten.expand.default(getitem_474, [128, 144, 56, 56]);  getitem_474 = None
        div_scalar_14 = torch.ops.aten.div.Scalar(expand_default_14, 3136);  expand_default_14 = None
        add_tensor_161 = torch.ops.aten.add.Tensor(mul_tensor_229, div_scalar_14);  mul_tensor_229 = div_scalar_14 = None
        to_dtype_165 = torch.ops.aten.to.dtype(add_tensor_161, torch.float32);  add_tensor_161 = None
        to_dtype_166 = torch.ops.aten.to.dtype(clone_default_7, torch.float32);  clone_default_7 = None
        neg_default_41 = torch.ops.aten.neg.default(to_dtype_166)
        exp_default_41 = torch.ops.aten.exp.default(neg_default_41);  neg_default_41 = None
        add_tensor_162 = torch.ops.aten.add.Tensor(exp_default_41, 1);  exp_default_41 = None
        reciprocal_default_41 = torch.ops.aten.reciprocal.default(add_tensor_162);  add_tensor_162 = None
        mul_tensor_236 = torch.ops.aten.mul.Tensor(reciprocal_default_41, 1);  reciprocal_default_41 = None
        mul_tensor_237 = torch.ops.aten.mul.Tensor(to_dtype_165, mul_tensor_236);  to_dtype_165 = None
        rsub_scalar_55 = torch.ops.aten.rsub.Scalar(mul_tensor_236, 1);  mul_tensor_236 = None
        mul_tensor_238 = torch.ops.aten.mul.Tensor(to_dtype_166, rsub_scalar_55);  to_dtype_166 = rsub_scalar_55 = None
        add_tensor_163 = torch.ops.aten.add.Tensor(mul_tensor_238, 1);  mul_tensor_238 = None
        mul_tensor_239 = torch.ops.aten.mul.Tensor(mul_tensor_237, add_tensor_163);  mul_tensor_237 = add_tensor_163 = None
        to_dtype_167 = torch.ops.aten.to.dtype(mul_tensor_239, torch.float32);  mul_tensor_239 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_167, convolution_default_11, primals_155, primals_153, primals_154, getitem_22, getitem_23, True, 0.001, [True, True, True]);  to_dtype_167 = convolution_default_11 = primals_155 = primals_153 = primals_154 = getitem_22 = getitem_23 = None
        getitem_477 = native_batch_norm_backward_default_41[0]
        getitem_478 = native_batch_norm_backward_default_41[1]
        getitem_479 = native_batch_norm_backward_default_41[2];  native_batch_norm_backward_default_41 = None
        convolution_backward_default_69 = torch.ops.aten.convolution_backward.default(getitem_477, silu__default_6, primals_14, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 144, [True, True, False]);  getitem_477 = silu__default_6 = primals_14 = None
        getitem_480 = convolution_backward_default_69[0]
        getitem_481 = convolution_backward_default_69[1];  convolution_backward_default_69 = None
        to_dtype_168 = torch.ops.aten.to.dtype(getitem_480, torch.float32);  getitem_480 = None
        to_dtype_169 = torch.ops.aten.to.dtype(clone_default_6, torch.float32);  clone_default_6 = None
        neg_default_42 = torch.ops.aten.neg.default(to_dtype_169)
        exp_default_42 = torch.ops.aten.exp.default(neg_default_42);  neg_default_42 = None
        add_tensor_164 = torch.ops.aten.add.Tensor(exp_default_42, 1);  exp_default_42 = None
        reciprocal_default_42 = torch.ops.aten.reciprocal.default(add_tensor_164);  add_tensor_164 = None
        mul_tensor_240 = torch.ops.aten.mul.Tensor(reciprocal_default_42, 1);  reciprocal_default_42 = None
        mul_tensor_241 = torch.ops.aten.mul.Tensor(to_dtype_168, mul_tensor_240);  to_dtype_168 = None
        rsub_scalar_56 = torch.ops.aten.rsub.Scalar(mul_tensor_240, 1);  mul_tensor_240 = None
        mul_tensor_242 = torch.ops.aten.mul.Tensor(to_dtype_169, rsub_scalar_56);  to_dtype_169 = rsub_scalar_56 = None
        add_tensor_165 = torch.ops.aten.add.Tensor(mul_tensor_242, 1);  mul_tensor_242 = None
        mul_tensor_243 = torch.ops.aten.mul.Tensor(mul_tensor_241, add_tensor_165);  mul_tensor_241 = add_tensor_165 = None
        to_dtype_170 = torch.ops.aten.to.dtype(mul_tensor_243, torch.float32);  mul_tensor_243 = None
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_170, convolution_default_10, primals_150, primals_148, primals_149, getitem_19, getitem_20, True, 0.001, [True, True, True]);  to_dtype_170 = convolution_default_10 = primals_150 = primals_148 = primals_149 = getitem_19 = getitem_20 = None
        getitem_483 = native_batch_norm_backward_default_42[0]
        getitem_484 = native_batch_norm_backward_default_42[1]
        getitem_485 = native_batch_norm_backward_default_42[2];  native_batch_norm_backward_default_42 = None
        convolution_backward_default_70 = torch.ops.aten.convolution_backward.default(getitem_483, getitem_15, primals_15, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_483 = getitem_15 = primals_15 = None
        getitem_486 = convolution_backward_default_70[0]
        getitem_487 = convolution_backward_default_70[1];  convolution_backward_default_70 = None
        add_tensor_166 = torch.ops.aten.add.Tensor(getitem_462, getitem_486);  getitem_462 = getitem_486 = None
        native_batch_norm_backward_default_43 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_166, convolution_default_9, primals_145, primals_143, primals_144, getitem_16, getitem_17, True, 0.001, [True, True, True]);  add_tensor_166 = convolution_default_9 = primals_145 = primals_143 = primals_144 = getitem_16 = getitem_17 = None
        getitem_489 = native_batch_norm_backward_default_43[0]
        getitem_490 = native_batch_norm_backward_default_43[1]
        getitem_491 = native_batch_norm_backward_default_43[2];  native_batch_norm_backward_default_43 = None
        convolution_backward_default_71 = torch.ops.aten.convolution_backward.default(getitem_489, mul_tensor_1, primals_9, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_489 = mul_tensor_1 = primals_9 = None
        getitem_492 = convolution_backward_default_71[0]
        getitem_493 = convolution_backward_default_71[1];  convolution_backward_default_71 = None
        mul_tensor_244 = torch.ops.aten.mul.Tensor(getitem_492, silu__default_4);  silu__default_4 = None
        mul_tensor_245 = torch.ops.aten.mul.Tensor(getitem_492, sigmoid_default_1);  getitem_492 = None
        sum_dim_int_list_15 = torch.ops.aten.sum.dim_IntList(mul_tensor_244, [2, 3], True);  mul_tensor_244 = None
        to_dtype_171 = torch.ops.aten.to.dtype(sum_dim_int_list_15, torch.float32);  sum_dim_int_list_15 = None
        to_dtype_172 = torch.ops.aten.to.dtype(sigmoid_default_1, torch.float32);  sigmoid_default_1 = None
        rsub_scalar_57 = torch.ops.aten.rsub.Scalar(to_dtype_172, 1)
        mul_tensor_246 = torch.ops.aten.mul.Tensor(to_dtype_172, rsub_scalar_57);  to_dtype_172 = rsub_scalar_57 = None
        conj_physical_default_14 = torch.ops.aten.conj_physical.default(mul_tensor_246);  mul_tensor_246 = None
        mul_tensor_247 = torch.ops.aten.mul.Tensor(to_dtype_171, conj_physical_default_14);  to_dtype_171 = conj_physical_default_14 = None
        to_dtype_173 = torch.ops.aten.to.dtype(mul_tensor_247, torch.float32);  mul_tensor_247 = None
        convolution_backward_default_72 = torch.ops.aten.convolution_backward.default(to_dtype_173, silu__default_5, primals_11, [96], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_173 = silu__default_5 = primals_11 = None
        getitem_495 = convolution_backward_default_72[0]
        getitem_496 = convolution_backward_default_72[1]
        getitem_497 = convolution_backward_default_72[2];  convolution_backward_default_72 = None
        to_dtype_174 = torch.ops.aten.to.dtype(getitem_495, torch.float32);  getitem_495 = None
        to_dtype_175 = torch.ops.aten.to.dtype(clone_default_5, torch.float32);  clone_default_5 = None
        neg_default_43 = torch.ops.aten.neg.default(to_dtype_175)
        exp_default_43 = torch.ops.aten.exp.default(neg_default_43);  neg_default_43 = None
        add_tensor_167 = torch.ops.aten.add.Tensor(exp_default_43, 1);  exp_default_43 = None
        reciprocal_default_43 = torch.ops.aten.reciprocal.default(add_tensor_167);  add_tensor_167 = None
        mul_tensor_248 = torch.ops.aten.mul.Tensor(reciprocal_default_43, 1);  reciprocal_default_43 = None
        mul_tensor_249 = torch.ops.aten.mul.Tensor(to_dtype_174, mul_tensor_248);  to_dtype_174 = None
        rsub_scalar_58 = torch.ops.aten.rsub.Scalar(mul_tensor_248, 1);  mul_tensor_248 = None
        mul_tensor_250 = torch.ops.aten.mul.Tensor(to_dtype_175, rsub_scalar_58);  to_dtype_175 = rsub_scalar_58 = None
        add_tensor_168 = torch.ops.aten.add.Tensor(mul_tensor_250, 1);  mul_tensor_250 = None
        mul_tensor_251 = torch.ops.aten.mul.Tensor(mul_tensor_249, add_tensor_168);  mul_tensor_249 = add_tensor_168 = None
        to_dtype_176 = torch.ops.aten.to.dtype(mul_tensor_251, torch.float32);  mul_tensor_251 = None
        convolution_backward_default_73 = torch.ops.aten.convolution_backward.default(to_dtype_176, mean_dim_1, primals_13, [4], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_176 = mean_dim_1 = primals_13 = None
        getitem_498 = convolution_backward_default_73[0]
        getitem_499 = convolution_backward_default_73[1]
        getitem_500 = convolution_backward_default_73[2];  convolution_backward_default_73 = None
        expand_default_15 = torch.ops.aten.expand.default(getitem_498, [128, 96, 56, 56]);  getitem_498 = None
        div_scalar_15 = torch.ops.aten.div.Scalar(expand_default_15, 3136);  expand_default_15 = None
        add_tensor_169 = torch.ops.aten.add.Tensor(mul_tensor_245, div_scalar_15);  mul_tensor_245 = div_scalar_15 = None
        to_dtype_177 = torch.ops.aten.to.dtype(add_tensor_169, torch.float32);  add_tensor_169 = None
        to_dtype_178 = torch.ops.aten.to.dtype(clone_default_4, torch.float32);  clone_default_4 = None
        neg_default_44 = torch.ops.aten.neg.default(to_dtype_178)
        exp_default_44 = torch.ops.aten.exp.default(neg_default_44);  neg_default_44 = None
        add_tensor_170 = torch.ops.aten.add.Tensor(exp_default_44, 1);  exp_default_44 = None
        reciprocal_default_44 = torch.ops.aten.reciprocal.default(add_tensor_170);  add_tensor_170 = None
        mul_tensor_252 = torch.ops.aten.mul.Tensor(reciprocal_default_44, 1);  reciprocal_default_44 = None
        mul_tensor_253 = torch.ops.aten.mul.Tensor(to_dtype_177, mul_tensor_252);  to_dtype_177 = None
        rsub_scalar_59 = torch.ops.aten.rsub.Scalar(mul_tensor_252, 1);  mul_tensor_252 = None
        mul_tensor_254 = torch.ops.aten.mul.Tensor(to_dtype_178, rsub_scalar_59);  to_dtype_178 = rsub_scalar_59 = None
        add_tensor_171 = torch.ops.aten.add.Tensor(mul_tensor_254, 1);  mul_tensor_254 = None
        mul_tensor_255 = torch.ops.aten.mul.Tensor(mul_tensor_253, add_tensor_171);  mul_tensor_253 = add_tensor_171 = None
        to_dtype_179 = torch.ops.aten.to.dtype(mul_tensor_255, torch.float32);  mul_tensor_255 = None
        native_batch_norm_backward_default_44 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_179, convolution_default_6, primals_140, primals_138, primals_139, getitem_13, getitem_14, True, 0.001, [True, True, True]);  to_dtype_179 = convolution_default_6 = primals_140 = primals_138 = primals_139 = getitem_13 = getitem_14 = None
        getitem_501 = native_batch_norm_backward_default_44[0]
        getitem_502 = native_batch_norm_backward_default_44[1]
        getitem_503 = native_batch_norm_backward_default_44[2];  native_batch_norm_backward_default_44 = None
        convolution_backward_default_74 = torch.ops.aten.convolution_backward.default(getitem_501, constant_pad_nd_default_1, primals_7, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 96, [True, True, False]);  getitem_501 = constant_pad_nd_default_1 = primals_7 = None
        getitem_504 = convolution_backward_default_74[0]
        getitem_505 = convolution_backward_default_74[1];  convolution_backward_default_74 = None
        constant_pad_nd_default_8 = torch.ops.aten.constant_pad_nd.default(getitem_504, [0, -1, 0, -1]);  getitem_504 = None
        to_dtype_180 = torch.ops.aten.to.dtype(constant_pad_nd_default_8, torch.float32);  constant_pad_nd_default_8 = None
        to_dtype_181 = torch.ops.aten.to.dtype(clone_default_3, torch.float32);  clone_default_3 = None
        neg_default_45 = torch.ops.aten.neg.default(to_dtype_181)
        exp_default_45 = torch.ops.aten.exp.default(neg_default_45);  neg_default_45 = None
        add_tensor_172 = torch.ops.aten.add.Tensor(exp_default_45, 1);  exp_default_45 = None
        reciprocal_default_45 = torch.ops.aten.reciprocal.default(add_tensor_172);  add_tensor_172 = None
        mul_tensor_256 = torch.ops.aten.mul.Tensor(reciprocal_default_45, 1);  reciprocal_default_45 = None
        mul_tensor_257 = torch.ops.aten.mul.Tensor(to_dtype_180, mul_tensor_256);  to_dtype_180 = None
        rsub_scalar_60 = torch.ops.aten.rsub.Scalar(mul_tensor_256, 1);  mul_tensor_256 = None
        mul_tensor_258 = torch.ops.aten.mul.Tensor(to_dtype_181, rsub_scalar_60);  to_dtype_181 = rsub_scalar_60 = None
        add_tensor_173 = torch.ops.aten.add.Tensor(mul_tensor_258, 1);  mul_tensor_258 = None
        mul_tensor_259 = torch.ops.aten.mul.Tensor(mul_tensor_257, add_tensor_173);  mul_tensor_257 = add_tensor_173 = None
        to_dtype_182 = torch.ops.aten.to.dtype(mul_tensor_259, torch.float32);  mul_tensor_259 = None
        native_batch_norm_backward_default_45 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_182, convolution_default_5, primals_135, primals_133, primals_134, getitem_10, getitem_11, True, 0.001, [True, True, True]);  to_dtype_182 = convolution_default_5 = primals_135 = primals_133 = primals_134 = getitem_10 = getitem_11 = None
        getitem_507 = native_batch_norm_backward_default_45[0]
        getitem_508 = native_batch_norm_backward_default_45[1]
        getitem_509 = native_batch_norm_backward_default_45[2];  native_batch_norm_backward_default_45 = None
        convolution_backward_default_75 = torch.ops.aten.convolution_backward.default(getitem_507, getitem_6, primals_8, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_507 = getitem_6 = primals_8 = None
        getitem_510 = convolution_backward_default_75[0]
        getitem_511 = convolution_backward_default_75[1];  convolution_backward_default_75 = None
        native_batch_norm_backward_default_46 = torch.ops.aten.native_batch_norm_backward.default(getitem_510, convolution_default_4, primals_130, primals_128, primals_129, getitem_7, getitem_8, True, 0.001, [True, True, True]);  getitem_510 = convolution_default_4 = primals_130 = primals_128 = primals_129 = getitem_7 = getitem_8 = None
        getitem_513 = native_batch_norm_backward_default_46[0]
        getitem_514 = native_batch_norm_backward_default_46[1]
        getitem_515 = native_batch_norm_backward_default_46[2];  native_batch_norm_backward_default_46 = None
        convolution_backward_default_76 = torch.ops.aten.convolution_backward.default(getitem_513, mul_tensor, primals_2, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_513 = mul_tensor = primals_2 = None
        getitem_516 = convolution_backward_default_76[0]
        getitem_517 = convolution_backward_default_76[1];  convolution_backward_default_76 = None
        mul_tensor_260 = torch.ops.aten.mul.Tensor(getitem_516, silu__default_1);  silu__default_1 = None
        mul_tensor_261 = torch.ops.aten.mul.Tensor(getitem_516, sigmoid_default);  getitem_516 = None
        sum_dim_int_list_16 = torch.ops.aten.sum.dim_IntList(mul_tensor_260, [2, 3], True);  mul_tensor_260 = None
        to_dtype_183 = torch.ops.aten.to.dtype(sum_dim_int_list_16, torch.float32);  sum_dim_int_list_16 = None
        to_dtype_184 = torch.ops.aten.to.dtype(sigmoid_default, torch.float32);  sigmoid_default = None
        rsub_scalar_61 = torch.ops.aten.rsub.Scalar(to_dtype_184, 1)
        mul_tensor_262 = torch.ops.aten.mul.Tensor(to_dtype_184, rsub_scalar_61);  to_dtype_184 = rsub_scalar_61 = None
        conj_physical_default_15 = torch.ops.aten.conj_physical.default(mul_tensor_262);  mul_tensor_262 = None
        mul_tensor_263 = torch.ops.aten.mul.Tensor(to_dtype_183, conj_physical_default_15);  to_dtype_183 = conj_physical_default_15 = None
        to_dtype_185 = torch.ops.aten.to.dtype(mul_tensor_263, torch.float32);  mul_tensor_263 = None
        convolution_backward_default_77 = torch.ops.aten.convolution_backward.default(to_dtype_185, silu__default_2, primals_4, [32], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_185 = silu__default_2 = primals_4 = None
        getitem_519 = convolution_backward_default_77[0]
        getitem_520 = convolution_backward_default_77[1]
        getitem_521 = convolution_backward_default_77[2];  convolution_backward_default_77 = None
        to_dtype_186 = torch.ops.aten.to.dtype(getitem_519, torch.float32);  getitem_519 = None
        to_dtype_187 = torch.ops.aten.to.dtype(clone_default_2, torch.float32);  clone_default_2 = None
        neg_default_46 = torch.ops.aten.neg.default(to_dtype_187)
        exp_default_46 = torch.ops.aten.exp.default(neg_default_46);  neg_default_46 = None
        add_tensor_174 = torch.ops.aten.add.Tensor(exp_default_46, 1);  exp_default_46 = None
        reciprocal_default_46 = torch.ops.aten.reciprocal.default(add_tensor_174);  add_tensor_174 = None
        mul_tensor_264 = torch.ops.aten.mul.Tensor(reciprocal_default_46, 1);  reciprocal_default_46 = None
        mul_tensor_265 = torch.ops.aten.mul.Tensor(to_dtype_186, mul_tensor_264);  to_dtype_186 = None
        rsub_scalar_62 = torch.ops.aten.rsub.Scalar(mul_tensor_264, 1);  mul_tensor_264 = None
        mul_tensor_266 = torch.ops.aten.mul.Tensor(to_dtype_187, rsub_scalar_62);  to_dtype_187 = rsub_scalar_62 = None
        add_tensor_175 = torch.ops.aten.add.Tensor(mul_tensor_266, 1);  mul_tensor_266 = None
        mul_tensor_267 = torch.ops.aten.mul.Tensor(mul_tensor_265, add_tensor_175);  mul_tensor_265 = add_tensor_175 = None
        to_dtype_188 = torch.ops.aten.to.dtype(mul_tensor_267, torch.float32);  mul_tensor_267 = None
        convolution_backward_default_78 = torch.ops.aten.convolution_backward.default(to_dtype_188, mean_dim, primals_6, [8], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_188 = mean_dim = primals_6 = None
        getitem_522 = convolution_backward_default_78[0]
        getitem_523 = convolution_backward_default_78[1]
        getitem_524 = convolution_backward_default_78[2];  convolution_backward_default_78 = None
        expand_default_16 = torch.ops.aten.expand.default(getitem_522, [128, 32, 112, 112]);  getitem_522 = None
        div_scalar_16 = torch.ops.aten.div.Scalar(expand_default_16, 12544);  expand_default_16 = None
        add_tensor_176 = torch.ops.aten.add.Tensor(mul_tensor_261, div_scalar_16);  mul_tensor_261 = div_scalar_16 = None
        to_dtype_189 = torch.ops.aten.to.dtype(add_tensor_176, torch.float32);  add_tensor_176 = None
        to_dtype_190 = torch.ops.aten.to.dtype(clone_default_1, torch.float32);  clone_default_1 = None
        neg_default_47 = torch.ops.aten.neg.default(to_dtype_190)
        exp_default_47 = torch.ops.aten.exp.default(neg_default_47);  neg_default_47 = None
        add_tensor_177 = torch.ops.aten.add.Tensor(exp_default_47, 1);  exp_default_47 = None
        reciprocal_default_47 = torch.ops.aten.reciprocal.default(add_tensor_177);  add_tensor_177 = None
        mul_tensor_268 = torch.ops.aten.mul.Tensor(reciprocal_default_47, 1);  reciprocal_default_47 = None
        mul_tensor_269 = torch.ops.aten.mul.Tensor(to_dtype_189, mul_tensor_268);  to_dtype_189 = None
        rsub_scalar_63 = torch.ops.aten.rsub.Scalar(mul_tensor_268, 1);  mul_tensor_268 = None
        mul_tensor_270 = torch.ops.aten.mul.Tensor(to_dtype_190, rsub_scalar_63);  to_dtype_190 = rsub_scalar_63 = None
        add_tensor_178 = torch.ops.aten.add.Tensor(mul_tensor_270, 1);  mul_tensor_270 = None
        mul_tensor_271 = torch.ops.aten.mul.Tensor(mul_tensor_269, add_tensor_178);  mul_tensor_269 = add_tensor_178 = None
        to_dtype_191 = torch.ops.aten.to.dtype(mul_tensor_271, torch.float32);  mul_tensor_271 = None
        native_batch_norm_backward_default_47 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_191, convolution_default_1, primals_125, primals_123, primals_124, getitem_4, getitem_5, True, 0.001, [True, True, True]);  to_dtype_191 = convolution_default_1 = primals_125 = primals_123 = primals_124 = getitem_4 = getitem_5 = None
        getitem_525 = native_batch_norm_backward_default_47[0]
        getitem_526 = native_batch_norm_backward_default_47[1]
        getitem_527 = native_batch_norm_backward_default_47[2];  native_batch_norm_backward_default_47 = None
        convolution_backward_default_79 = torch.ops.aten.convolution_backward.default(getitem_525, silu__default, primals_1, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 32, [True, True, False]);  getitem_525 = silu__default = primals_1 = None
        getitem_528 = convolution_backward_default_79[0]
        getitem_529 = convolution_backward_default_79[1];  convolution_backward_default_79 = None
        to_dtype_192 = torch.ops.aten.to.dtype(getitem_528, torch.float32);  getitem_528 = None
        to_dtype_193 = torch.ops.aten.to.dtype(clone_default, torch.float32);  clone_default = None
        neg_default_48 = torch.ops.aten.neg.default(to_dtype_193)
        exp_default_48 = torch.ops.aten.exp.default(neg_default_48);  neg_default_48 = None
        add_tensor_179 = torch.ops.aten.add.Tensor(exp_default_48, 1);  exp_default_48 = None
        reciprocal_default_48 = torch.ops.aten.reciprocal.default(add_tensor_179);  add_tensor_179 = None
        mul_tensor_272 = torch.ops.aten.mul.Tensor(reciprocal_default_48, 1);  reciprocal_default_48 = None
        mul_tensor_273 = torch.ops.aten.mul.Tensor(to_dtype_192, mul_tensor_272);  to_dtype_192 = None
        rsub_scalar_64 = torch.ops.aten.rsub.Scalar(mul_tensor_272, 1);  mul_tensor_272 = None
        mul_tensor_274 = torch.ops.aten.mul.Tensor(to_dtype_193, rsub_scalar_64);  to_dtype_193 = rsub_scalar_64 = None
        add_tensor_180 = torch.ops.aten.add.Tensor(mul_tensor_274, 1);  mul_tensor_274 = None
        mul_tensor_275 = torch.ops.aten.mul.Tensor(mul_tensor_273, add_tensor_180);  mul_tensor_273 = add_tensor_180 = None
        to_dtype_194 = torch.ops.aten.to.dtype(mul_tensor_275, torch.float32);  mul_tensor_275 = None
        native_batch_norm_backward_default_48 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_194, convolution_default, primals_120, primals_118, primals_119, getitem_1, getitem_2, True, 0.001, [True, True, True]);  to_dtype_194 = convolution_default = primals_120 = primals_118 = primals_119 = getitem_1 = getitem_2 = None
        getitem_531 = native_batch_norm_backward_default_48[0]
        getitem_532 = native_batch_norm_backward_default_48[1]
        getitem_533 = native_batch_norm_backward_default_48[2];  native_batch_norm_backward_default_48 = None
        convolution_backward_default_80 = torch.ops.aten.convolution_backward.default(getitem_531, constant_pad_nd_default, primals_115, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_531 = constant_pad_nd_default = primals_115 = None
        getitem_535 = convolution_backward_default_80[1];  convolution_backward_default_80 = None
        return [getitem_529, getitem_517, getitem_521, getitem_520, getitem_524, getitem_523, getitem_505, getitem_511, getitem_493, getitem_497, getitem_496, getitem_500, getitem_499, getitem_481, getitem_487, getitem_469, getitem_473, getitem_472, getitem_476, getitem_475, getitem_457, getitem_463, getitem_445, getitem_449, getitem_448, getitem_452, getitem_451, getitem_433, getitem_439, getitem_421, getitem_425, getitem_424, getitem_428, getitem_427, getitem_409, getitem_415, getitem_397, getitem_401, getitem_400, getitem_404, getitem_403, getitem_385, getitem_391, getitem_373, getitem_377, getitem_376, getitem_380, getitem_379, getitem_361, getitem_367, getitem_349, getitem_353, getitem_352, getitem_356, getitem_355, getitem_337, getitem_343, getitem_325, getitem_329, getitem_328, getitem_332, getitem_331, getitem_313, getitem_319, getitem_301, getitem_305, getitem_304, getitem_308, getitem_307, getitem_289, getitem_295, getitem_277, getitem_281, getitem_280, getitem_284, getitem_283, getitem_265, getitem_271, getitem_253, getitem_257, getitem_256, getitem_260, getitem_259, getitem_241, getitem_247, getitem_229, getitem_233, getitem_232, getitem_236, getitem_235, getitem_217, getitem_223, getitem_205, getitem_209, getitem_208, getitem_212, getitem_211, getitem_193, getitem_199, getitem_181, getitem_185, getitem_184, getitem_188, getitem_187, getitem_169, getitem_175, getitem_157, getitem_161, getitem_160, getitem_164, getitem_163, view_default_1, t_default_4, getitem_151, getitem_535, None, None, None, None, getitem_532, getitem_533, None, None, None, getitem_526, getitem_527, None, None, None, getitem_514, getitem_515, None, None, None, getitem_508, getitem_509, None, None, None, getitem_502, getitem_503, None, None, None, getitem_490, getitem_491, None, None, None, getitem_484, getitem_485, None, None, None, getitem_478, getitem_479, None, None, None, getitem_466, getitem_467, None, None, None, getitem_460, getitem_461, None, None, None, getitem_454, getitem_455, None, None, None, getitem_442, getitem_443, None, None, None, getitem_436, getitem_437, None, None, None, getitem_430, getitem_431, None, None, None, getitem_418, getitem_419, None, None, None, getitem_412, getitem_413, None, None, None, getitem_406, getitem_407, None, None, None, getitem_394, getitem_395, None, None, None, getitem_388, getitem_389, None, None, None, getitem_382, getitem_383, None, None, None, getitem_370, getitem_371, None, None, None, getitem_364, getitem_365, None, None, None, getitem_358, getitem_359, None, None, None, getitem_346, getitem_347, None, None, None, getitem_340, getitem_341, None, None, None, getitem_334, getitem_335, None, None, None, getitem_322, getitem_323, None, None, None, getitem_316, getitem_317, None, None, None, getitem_310, getitem_311, None, None, None, getitem_298, getitem_299, None, None, None, getitem_292, getitem_293, None, None, None, getitem_286, getitem_287, None, None, None, getitem_274, getitem_275, None, None, None, getitem_268, getitem_269, None, None, None, getitem_262, getitem_263, None, None, None, getitem_250, getitem_251, None, None, None, getitem_244, getitem_245, None, None, None, getitem_238, getitem_239, None, None, None, getitem_226, getitem_227, None, None, None, getitem_220, getitem_221, None, None, None, getitem_214, getitem_215, None, None, None, getitem_202, getitem_203, None, None, None, getitem_196, getitem_197, None, None, None, getitem_190, getitem_191, None, None, None, getitem_178, getitem_179, None, None, None, getitem_172, getitem_173, None, None, None, getitem_166, getitem_167, None, None, None, getitem_154, getitem_155, None, None, None, getitem_148, getitem_149]
        
