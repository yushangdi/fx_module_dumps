
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/inception_v3/inception_v3_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339, primals_340, primals_341, primals_342, primals_343, primals_344, primals_345, primals_346, primals_347, primals_348, primals_349, primals_350, primals_351, primals_352, primals_353, primals_354, primals_355, primals_356, primals_357, primals_358, primals_359, primals_360, primals_361, primals_362, primals_363, primals_364, primals_365, primals_366, primals_367, primals_368, primals_369, primals_370, primals_371, primals_372, primals_373, primals_374, primals_375, primals_376, primals_377, primals_378, primals_379, primals_380, primals_381, primals_382, primals_383, primals_384, primals_385, primals_386, primals_387, primals_388, primals_389, primals_390, primals_391, primals_392, primals_393, primals_394, primals_395, primals_396, primals_397, primals_398, primals_399, primals_400, primals_401, primals_402, primals_403, primals_404, primals_405, primals_406, primals_407, primals_408, primals_409, primals_410, primals_411, primals_412, primals_413, primals_414, primals_415, primals_416, primals_417, primals_418, primals_419, primals_420, primals_421, primals_422, primals_423, primals_424, primals_425, primals_426, primals_427, primals_428, primals_429, primals_430, primals_431, primals_432, primals_433, primals_434, primals_435, primals_436, primals_437, primals_438, primals_439, primals_440, primals_441, primals_442, primals_443, primals_444, primals_445, primals_446, primals_447, primals_448, primals_449, primals_450, primals_451, primals_452, primals_453, primals_454, primals_455, primals_456, primals_457, primals_458, primals_459, primals_460, primals_461, primals_462, primals_463, primals_464, primals_465, primals_466, primals_467, primals_468, primals_469, primals_470, primals_471, primals_472, primals_473, primals_474, primals_475, primals_476, primals_477, primals_478, primals_479, primals_480, primals_481, primals_482, primals_483, primals_484, primals_485, primals_486, primals_487, primals_488, primals_489, primals_490, primals_491, primals_492, primals_493, primals_494, primals_495, primals_496, primals_497, primals_498, primals_499, primals_500, primals_501, primals_502, primals_503, primals_504, primals_505, primals_506, primals_507, primals_508, primals_509, primals_510, primals_511, primals_512, primals_513, primals_514, primals_515, primals_516, primals_517, primals_518, primals_519, primals_520, primals_521, primals_522, primals_523, primals_524, primals_525, primals_526, primals_527, primals_528, primals_529, primals_530, primals_531, primals_532, primals_533, primals_534, primals_535, primals_536, primals_537, primals_538, primals_539, primals_540, primals_541, primals_542, primals_543, primals_544, primals_545, primals_546, primals_547, primals_548, primals_549, primals_550, primals_551, primals_552, primals_553, primals_554, primals_555, primals_556, primals_557, primals_558, primals_559, primals_560, primals_561, primals_562, primals_563, primals_564, primals_565, primals_566, primals_567):
        convolution_default = torch.ops.aten.convolution.default(primals_567, primals_6, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_5, primals_1, primals_3, primals_4, True, 0.1, 0.001);  primals_1 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default, primals_12, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_11, primals_7, primals_9, primals_10, True, 0.1, 0.001);  primals_7 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        relu__default_1 = torch.ops.aten.relu_.default(getitem_3);  getitem_3 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_18, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_17, primals_13, primals_15, primals_16, True, 0.1, 0.001);  primals_13 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        relu__default_2 = torch.ops.aten.relu_.default(getitem_6);  getitem_6 = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu__default_2, [3, 3], [2, 2])
        getitem_9 = max_pool2d_with_indices_default[0]
        getitem_10 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_3 = torch.ops.aten.convolution.default(getitem_9, primals_24, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_23, primals_19, primals_21, primals_22, True, 0.1, 0.001);  primals_19 = None
        getitem_11 = native_batch_norm_default_3[0]
        getitem_12 = native_batch_norm_default_3[1]
        getitem_13 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        relu__default_3 = torch.ops.aten.relu_.default(getitem_11);  getitem_11 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu__default_3, primals_30, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_29, primals_25, primals_27, primals_28, True, 0.1, 0.001);  primals_25 = None
        getitem_14 = native_batch_norm_default_4[0]
        getitem_15 = native_batch_norm_default_4[1]
        getitem_16 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        relu__default_4 = torch.ops.aten.relu_.default(getitem_14);  getitem_14 = None
        max_pool2d_with_indices_default_1 = torch.ops.aten.max_pool2d_with_indices.default(relu__default_4, [3, 3], [2, 2])
        getitem_17 = max_pool2d_with_indices_default_1[0]
        getitem_18 = max_pool2d_with_indices_default_1[1];  max_pool2d_with_indices_default_1 = None
        convolution_default_5 = torch.ops.aten.convolution.default(getitem_17, primals_36, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_35, primals_31, primals_33, primals_34, True, 0.1, 0.001);  primals_31 = None
        getitem_19 = native_batch_norm_default_5[0]
        getitem_20 = native_batch_norm_default_5[1]
        getitem_21 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        relu__default_5 = torch.ops.aten.relu_.default(getitem_19);  getitem_19 = None
        convolution_default_6 = torch.ops.aten.convolution.default(getitem_17, primals_60, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_59, primals_55, primals_57, primals_58, True, 0.1, 0.001);  primals_55 = None
        getitem_22 = native_batch_norm_default_6[0]
        getitem_23 = native_batch_norm_default_6[1]
        getitem_24 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        relu__default_6 = torch.ops.aten.relu_.default(getitem_22);  getitem_22 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_6, primals_66, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_65, primals_61, primals_63, primals_64, True, 0.1, 0.001);  primals_61 = None
        getitem_25 = native_batch_norm_default_7[0]
        getitem_26 = native_batch_norm_default_7[1]
        getitem_27 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        relu__default_7 = torch.ops.aten.relu_.default(getitem_25);  getitem_25 = None
        convolution_default_8 = torch.ops.aten.convolution.default(getitem_17, primals_42, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_41, primals_37, primals_39, primals_40, True, 0.1, 0.001);  primals_37 = None
        getitem_28 = native_batch_norm_default_8[0]
        getitem_29 = native_batch_norm_default_8[1]
        getitem_30 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        relu__default_8 = torch.ops.aten.relu_.default(getitem_28);  getitem_28 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_8, primals_48, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_47, primals_43, primals_45, primals_46, True, 0.1, 0.001);  primals_43 = None
        getitem_31 = native_batch_norm_default_9[0]
        getitem_32 = native_batch_norm_default_9[1]
        getitem_33 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        relu__default_9 = torch.ops.aten.relu_.default(getitem_31);  getitem_31 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default_9, primals_54, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_53, primals_49, primals_51, primals_52, True, 0.1, 0.001);  primals_49 = None
        getitem_34 = native_batch_norm_default_10[0]
        getitem_35 = native_batch_norm_default_10[1]
        getitem_36 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        relu__default_10 = torch.ops.aten.relu_.default(getitem_34);  getitem_34 = None
        avg_pool2d_default = torch.ops.aten.avg_pool2d.default(getitem_17, [3, 3], [1, 1], [1, 1])
        convolution_default_11 = torch.ops.aten.convolution.default(avg_pool2d_default, primals_72, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_71, primals_67, primals_69, primals_70, True, 0.1, 0.001);  primals_67 = None
        getitem_37 = native_batch_norm_default_11[0]
        getitem_38 = native_batch_norm_default_11[1]
        getitem_39 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        relu__default_11 = torch.ops.aten.relu_.default(getitem_37);  getitem_37 = None
        cat_default = torch.ops.aten.cat.default([relu__default_5, relu__default_7, relu__default_10, relu__default_11], 1)
        convolution_default_12 = torch.ops.aten.convolution.default(cat_default, primals_78, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_77, primals_73, primals_75, primals_76, True, 0.1, 0.001);  primals_73 = None
        getitem_40 = native_batch_norm_default_12[0]
        getitem_41 = native_batch_norm_default_12[1]
        getitem_42 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        relu__default_12 = torch.ops.aten.relu_.default(getitem_40);  getitem_40 = None
        convolution_default_13 = torch.ops.aten.convolution.default(cat_default, primals_102, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_101, primals_97, primals_99, primals_100, True, 0.1, 0.001);  primals_97 = None
        getitem_43 = native_batch_norm_default_13[0]
        getitem_44 = native_batch_norm_default_13[1]
        getitem_45 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        relu__default_13 = torch.ops.aten.relu_.default(getitem_43);  getitem_43 = None
        convolution_default_14 = torch.ops.aten.convolution.default(relu__default_13, primals_108, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_107, primals_103, primals_105, primals_106, True, 0.1, 0.001);  primals_103 = None
        getitem_46 = native_batch_norm_default_14[0]
        getitem_47 = native_batch_norm_default_14[1]
        getitem_48 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        relu__default_14 = torch.ops.aten.relu_.default(getitem_46);  getitem_46 = None
        convolution_default_15 = torch.ops.aten.convolution.default(cat_default, primals_84, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_83, primals_79, primals_81, primals_82, True, 0.1, 0.001);  primals_79 = None
        getitem_49 = native_batch_norm_default_15[0]
        getitem_50 = native_batch_norm_default_15[1]
        getitem_51 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        relu__default_15 = torch.ops.aten.relu_.default(getitem_49);  getitem_49 = None
        convolution_default_16 = torch.ops.aten.convolution.default(relu__default_15, primals_90, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_89, primals_85, primals_87, primals_88, True, 0.1, 0.001);  primals_85 = None
        getitem_52 = native_batch_norm_default_16[0]
        getitem_53 = native_batch_norm_default_16[1]
        getitem_54 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        relu__default_16 = torch.ops.aten.relu_.default(getitem_52);  getitem_52 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu__default_16, primals_96, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_95, primals_91, primals_93, primals_94, True, 0.1, 0.001);  primals_91 = None
        getitem_55 = native_batch_norm_default_17[0]
        getitem_56 = native_batch_norm_default_17[1]
        getitem_57 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        relu__default_17 = torch.ops.aten.relu_.default(getitem_55);  getitem_55 = None
        avg_pool2d_default_1 = torch.ops.aten.avg_pool2d.default(cat_default, [3, 3], [1, 1], [1, 1])
        convolution_default_18 = torch.ops.aten.convolution.default(avg_pool2d_default_1, primals_114, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_113, primals_109, primals_111, primals_112, True, 0.1, 0.001);  primals_109 = None
        getitem_58 = native_batch_norm_default_18[0]
        getitem_59 = native_batch_norm_default_18[1]
        getitem_60 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        relu__default_18 = torch.ops.aten.relu_.default(getitem_58);  getitem_58 = None
        cat_default_1 = torch.ops.aten.cat.default([relu__default_12, relu__default_14, relu__default_17, relu__default_18], 1)
        convolution_default_19 = torch.ops.aten.convolution.default(cat_default_1, primals_120, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_119, primals_115, primals_117, primals_118, True, 0.1, 0.001);  primals_115 = None
        getitem_61 = native_batch_norm_default_19[0]
        getitem_62 = native_batch_norm_default_19[1]
        getitem_63 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        relu__default_19 = torch.ops.aten.relu_.default(getitem_61);  getitem_61 = None
        convolution_default_20 = torch.ops.aten.convolution.default(cat_default_1, primals_144, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_143, primals_139, primals_141, primals_142, True, 0.1, 0.001);  primals_139 = None
        getitem_64 = native_batch_norm_default_20[0]
        getitem_65 = native_batch_norm_default_20[1]
        getitem_66 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        relu__default_20 = torch.ops.aten.relu_.default(getitem_64);  getitem_64 = None
        convolution_default_21 = torch.ops.aten.convolution.default(relu__default_20, primals_150, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_149, primals_145, primals_147, primals_148, True, 0.1, 0.001);  primals_145 = None
        getitem_67 = native_batch_norm_default_21[0]
        getitem_68 = native_batch_norm_default_21[1]
        getitem_69 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        relu__default_21 = torch.ops.aten.relu_.default(getitem_67);  getitem_67 = None
        convolution_default_22 = torch.ops.aten.convolution.default(cat_default_1, primals_126, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_125, primals_121, primals_123, primals_124, True, 0.1, 0.001);  primals_121 = None
        getitem_70 = native_batch_norm_default_22[0]
        getitem_71 = native_batch_norm_default_22[1]
        getitem_72 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        relu__default_22 = torch.ops.aten.relu_.default(getitem_70);  getitem_70 = None
        convolution_default_23 = torch.ops.aten.convolution.default(relu__default_22, primals_132, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_131, primals_127, primals_129, primals_130, True, 0.1, 0.001);  primals_127 = None
        getitem_73 = native_batch_norm_default_23[0]
        getitem_74 = native_batch_norm_default_23[1]
        getitem_75 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        relu__default_23 = torch.ops.aten.relu_.default(getitem_73);  getitem_73 = None
        convolution_default_24 = torch.ops.aten.convolution.default(relu__default_23, primals_138, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_137, primals_133, primals_135, primals_136, True, 0.1, 0.001);  primals_133 = None
        getitem_76 = native_batch_norm_default_24[0]
        getitem_77 = native_batch_norm_default_24[1]
        getitem_78 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        relu__default_24 = torch.ops.aten.relu_.default(getitem_76);  getitem_76 = None
        avg_pool2d_default_2 = torch.ops.aten.avg_pool2d.default(cat_default_1, [3, 3], [1, 1], [1, 1])
        convolution_default_25 = torch.ops.aten.convolution.default(avg_pool2d_default_2, primals_156, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_155, primals_151, primals_153, primals_154, True, 0.1, 0.001);  primals_151 = None
        getitem_79 = native_batch_norm_default_25[0]
        getitem_80 = native_batch_norm_default_25[1]
        getitem_81 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        relu__default_25 = torch.ops.aten.relu_.default(getitem_79);  getitem_79 = None
        cat_default_2 = torch.ops.aten.cat.default([relu__default_19, relu__default_21, relu__default_24, relu__default_25], 1)
        convolution_default_26 = torch.ops.aten.convolution.default(cat_default_2, primals_162, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_161, primals_157, primals_159, primals_160, True, 0.1, 0.001);  primals_157 = None
        getitem_82 = native_batch_norm_default_26[0]
        getitem_83 = native_batch_norm_default_26[1]
        getitem_84 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        relu__default_26 = torch.ops.aten.relu_.default(getitem_82);  getitem_82 = None
        convolution_default_27 = torch.ops.aten.convolution.default(cat_default_2, primals_168, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_167, primals_163, primals_165, primals_166, True, 0.1, 0.001);  primals_163 = None
        getitem_85 = native_batch_norm_default_27[0]
        getitem_86 = native_batch_norm_default_27[1]
        getitem_87 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        relu__default_27 = torch.ops.aten.relu_.default(getitem_85);  getitem_85 = None
        convolution_default_28 = torch.ops.aten.convolution.default(relu__default_27, primals_174, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_173, primals_169, primals_171, primals_172, True, 0.1, 0.001);  primals_169 = None
        getitem_88 = native_batch_norm_default_28[0]
        getitem_89 = native_batch_norm_default_28[1]
        getitem_90 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        relu__default_28 = torch.ops.aten.relu_.default(getitem_88);  getitem_88 = None
        convolution_default_29 = torch.ops.aten.convolution.default(relu__default_28, primals_180, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_179, primals_175, primals_177, primals_178, True, 0.1, 0.001);  primals_175 = None
        getitem_91 = native_batch_norm_default_29[0]
        getitem_92 = native_batch_norm_default_29[1]
        getitem_93 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        relu__default_29 = torch.ops.aten.relu_.default(getitem_91);  getitem_91 = None
        max_pool2d_with_indices_default_2 = torch.ops.aten.max_pool2d_with_indices.default(cat_default_2, [3, 3], [2, 2])
        getitem_94 = max_pool2d_with_indices_default_2[0]
        getitem_95 = max_pool2d_with_indices_default_2[1];  max_pool2d_with_indices_default_2 = None
        cat_default_3 = torch.ops.aten.cat.default([relu__default_26, relu__default_29, getitem_94], 1);  getitem_94 = None
        convolution_default_30 = torch.ops.aten.convolution.default(cat_default_3, primals_186, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_185, primals_181, primals_183, primals_184, True, 0.1, 0.001);  primals_181 = None
        getitem_96 = native_batch_norm_default_30[0]
        getitem_97 = native_batch_norm_default_30[1]
        getitem_98 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        relu__default_30 = torch.ops.aten.relu_.default(getitem_96);  getitem_96 = None
        convolution_default_31 = torch.ops.aten.convolution.default(cat_default_3, primals_192, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_31, primals_191, primals_187, primals_189, primals_190, True, 0.1, 0.001);  primals_187 = None
        getitem_99 = native_batch_norm_default_31[0]
        getitem_100 = native_batch_norm_default_31[1]
        getitem_101 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        relu__default_31 = torch.ops.aten.relu_.default(getitem_99);  getitem_99 = None
        convolution_default_32 = torch.ops.aten.convolution.default(relu__default_31, primals_198, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_197, primals_193, primals_195, primals_196, True, 0.1, 0.001);  primals_193 = None
        getitem_102 = native_batch_norm_default_32[0]
        getitem_103 = native_batch_norm_default_32[1]
        getitem_104 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        relu__default_32 = torch.ops.aten.relu_.default(getitem_102);  getitem_102 = None
        convolution_default_33 = torch.ops.aten.convolution.default(relu__default_32, primals_204, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_203, primals_199, primals_201, primals_202, True, 0.1, 0.001);  primals_199 = None
        getitem_105 = native_batch_norm_default_33[0]
        getitem_106 = native_batch_norm_default_33[1]
        getitem_107 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        relu__default_33 = torch.ops.aten.relu_.default(getitem_105);  getitem_105 = None
        convolution_default_34 = torch.ops.aten.convolution.default(cat_default_3, primals_210, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_209, primals_205, primals_207, primals_208, True, 0.1, 0.001);  primals_205 = None
        getitem_108 = native_batch_norm_default_34[0]
        getitem_109 = native_batch_norm_default_34[1]
        getitem_110 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        relu__default_34 = torch.ops.aten.relu_.default(getitem_108);  getitem_108 = None
        convolution_default_35 = torch.ops.aten.convolution.default(relu__default_34, primals_216, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_215, primals_211, primals_213, primals_214, True, 0.1, 0.001);  primals_211 = None
        getitem_111 = native_batch_norm_default_35[0]
        getitem_112 = native_batch_norm_default_35[1]
        getitem_113 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        relu__default_35 = torch.ops.aten.relu_.default(getitem_111);  getitem_111 = None
        convolution_default_36 = torch.ops.aten.convolution.default(relu__default_35, primals_222, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_221, primals_217, primals_219, primals_220, True, 0.1, 0.001);  primals_217 = None
        getitem_114 = native_batch_norm_default_36[0]
        getitem_115 = native_batch_norm_default_36[1]
        getitem_116 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        relu__default_36 = torch.ops.aten.relu_.default(getitem_114);  getitem_114 = None
        convolution_default_37 = torch.ops.aten.convolution.default(relu__default_36, primals_228, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_37, primals_227, primals_223, primals_225, primals_226, True, 0.1, 0.001);  primals_223 = None
        getitem_117 = native_batch_norm_default_37[0]
        getitem_118 = native_batch_norm_default_37[1]
        getitem_119 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        relu__default_37 = torch.ops.aten.relu_.default(getitem_117);  getitem_117 = None
        convolution_default_38 = torch.ops.aten.convolution.default(relu__default_37, primals_234, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_233, primals_229, primals_231, primals_232, True, 0.1, 0.001);  primals_229 = None
        getitem_120 = native_batch_norm_default_38[0]
        getitem_121 = native_batch_norm_default_38[1]
        getitem_122 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        relu__default_38 = torch.ops.aten.relu_.default(getitem_120);  getitem_120 = None
        avg_pool2d_default_3 = torch.ops.aten.avg_pool2d.default(cat_default_3, [3, 3], [1, 1], [1, 1])
        convolution_default_39 = torch.ops.aten.convolution.default(avg_pool2d_default_3, primals_240, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_39, primals_239, primals_235, primals_237, primals_238, True, 0.1, 0.001);  primals_235 = None
        getitem_123 = native_batch_norm_default_39[0]
        getitem_124 = native_batch_norm_default_39[1]
        getitem_125 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        relu__default_39 = torch.ops.aten.relu_.default(getitem_123);  getitem_123 = None
        cat_default_4 = torch.ops.aten.cat.default([relu__default_30, relu__default_33, relu__default_38, relu__default_39], 1)
        convolution_default_40 = torch.ops.aten.convolution.default(cat_default_4, primals_246, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_245, primals_241, primals_243, primals_244, True, 0.1, 0.001);  primals_241 = None
        getitem_126 = native_batch_norm_default_40[0]
        getitem_127 = native_batch_norm_default_40[1]
        getitem_128 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        relu__default_40 = torch.ops.aten.relu_.default(getitem_126);  getitem_126 = None
        convolution_default_41 = torch.ops.aten.convolution.default(cat_default_4, primals_252, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_41, primals_251, primals_247, primals_249, primals_250, True, 0.1, 0.001);  primals_247 = None
        getitem_129 = native_batch_norm_default_41[0]
        getitem_130 = native_batch_norm_default_41[1]
        getitem_131 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        relu__default_41 = torch.ops.aten.relu_.default(getitem_129);  getitem_129 = None
        convolution_default_42 = torch.ops.aten.convolution.default(relu__default_41, primals_258, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_42, primals_257, primals_253, primals_255, primals_256, True, 0.1, 0.001);  primals_253 = None
        getitem_132 = native_batch_norm_default_42[0]
        getitem_133 = native_batch_norm_default_42[1]
        getitem_134 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        relu__default_42 = torch.ops.aten.relu_.default(getitem_132);  getitem_132 = None
        convolution_default_43 = torch.ops.aten.convolution.default(relu__default_42, primals_264, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_43, primals_263, primals_259, primals_261, primals_262, True, 0.1, 0.001);  primals_259 = None
        getitem_135 = native_batch_norm_default_43[0]
        getitem_136 = native_batch_norm_default_43[1]
        getitem_137 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        relu__default_43 = torch.ops.aten.relu_.default(getitem_135);  getitem_135 = None
        convolution_default_44 = torch.ops.aten.convolution.default(cat_default_4, primals_270, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_269, primals_265, primals_267, primals_268, True, 0.1, 0.001);  primals_265 = None
        getitem_138 = native_batch_norm_default_44[0]
        getitem_139 = native_batch_norm_default_44[1]
        getitem_140 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        relu__default_44 = torch.ops.aten.relu_.default(getitem_138);  getitem_138 = None
        convolution_default_45 = torch.ops.aten.convolution.default(relu__default_44, primals_276, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_45, primals_275, primals_271, primals_273, primals_274, True, 0.1, 0.001);  primals_271 = None
        getitem_141 = native_batch_norm_default_45[0]
        getitem_142 = native_batch_norm_default_45[1]
        getitem_143 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        relu__default_45 = torch.ops.aten.relu_.default(getitem_141);  getitem_141 = None
        convolution_default_46 = torch.ops.aten.convolution.default(relu__default_45, primals_282, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(convolution_default_46, primals_281, primals_277, primals_279, primals_280, True, 0.1, 0.001);  primals_277 = None
        getitem_144 = native_batch_norm_default_46[0]
        getitem_145 = native_batch_norm_default_46[1]
        getitem_146 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        relu__default_46 = torch.ops.aten.relu_.default(getitem_144);  getitem_144 = None
        convolution_default_47 = torch.ops.aten.convolution.default(relu__default_46, primals_288, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(convolution_default_47, primals_287, primals_283, primals_285, primals_286, True, 0.1, 0.001);  primals_283 = None
        getitem_147 = native_batch_norm_default_47[0]
        getitem_148 = native_batch_norm_default_47[1]
        getitem_149 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        relu__default_47 = torch.ops.aten.relu_.default(getitem_147);  getitem_147 = None
        convolution_default_48 = torch.ops.aten.convolution.default(relu__default_47, primals_294, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_48, primals_293, primals_289, primals_291, primals_292, True, 0.1, 0.001);  primals_289 = None
        getitem_150 = native_batch_norm_default_48[0]
        getitem_151 = native_batch_norm_default_48[1]
        getitem_152 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        relu__default_48 = torch.ops.aten.relu_.default(getitem_150);  getitem_150 = None
        avg_pool2d_default_4 = torch.ops.aten.avg_pool2d.default(cat_default_4, [3, 3], [1, 1], [1, 1])
        convolution_default_49 = torch.ops.aten.convolution.default(avg_pool2d_default_4, primals_300, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(convolution_default_49, primals_299, primals_295, primals_297, primals_298, True, 0.1, 0.001);  primals_295 = None
        getitem_153 = native_batch_norm_default_49[0]
        getitem_154 = native_batch_norm_default_49[1]
        getitem_155 = native_batch_norm_default_49[2];  native_batch_norm_default_49 = None
        relu__default_49 = torch.ops.aten.relu_.default(getitem_153);  getitem_153 = None
        cat_default_5 = torch.ops.aten.cat.default([relu__default_40, relu__default_43, relu__default_48, relu__default_49], 1)
        convolution_default_50 = torch.ops.aten.convolution.default(cat_default_5, primals_306, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(convolution_default_50, primals_305, primals_301, primals_303, primals_304, True, 0.1, 0.001);  primals_301 = None
        getitem_156 = native_batch_norm_default_50[0]
        getitem_157 = native_batch_norm_default_50[1]
        getitem_158 = native_batch_norm_default_50[2];  native_batch_norm_default_50 = None
        relu__default_50 = torch.ops.aten.relu_.default(getitem_156);  getitem_156 = None
        convolution_default_51 = torch.ops.aten.convolution.default(cat_default_5, primals_312, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(convolution_default_51, primals_311, primals_307, primals_309, primals_310, True, 0.1, 0.001);  primals_307 = None
        getitem_159 = native_batch_norm_default_51[0]
        getitem_160 = native_batch_norm_default_51[1]
        getitem_161 = native_batch_norm_default_51[2];  native_batch_norm_default_51 = None
        relu__default_51 = torch.ops.aten.relu_.default(getitem_159);  getitem_159 = None
        convolution_default_52 = torch.ops.aten.convolution.default(relu__default_51, primals_318, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(convolution_default_52, primals_317, primals_313, primals_315, primals_316, True, 0.1, 0.001);  primals_313 = None
        getitem_162 = native_batch_norm_default_52[0]
        getitem_163 = native_batch_norm_default_52[1]
        getitem_164 = native_batch_norm_default_52[2];  native_batch_norm_default_52 = None
        relu__default_52 = torch.ops.aten.relu_.default(getitem_162);  getitem_162 = None
        convolution_default_53 = torch.ops.aten.convolution.default(relu__default_52, primals_324, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_53 = torch.ops.aten.native_batch_norm.default(convolution_default_53, primals_323, primals_319, primals_321, primals_322, True, 0.1, 0.001);  primals_319 = None
        getitem_165 = native_batch_norm_default_53[0]
        getitem_166 = native_batch_norm_default_53[1]
        getitem_167 = native_batch_norm_default_53[2];  native_batch_norm_default_53 = None
        relu__default_53 = torch.ops.aten.relu_.default(getitem_165);  getitem_165 = None
        convolution_default_54 = torch.ops.aten.convolution.default(cat_default_5, primals_330, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_54 = torch.ops.aten.native_batch_norm.default(convolution_default_54, primals_329, primals_325, primals_327, primals_328, True, 0.1, 0.001);  primals_325 = None
        getitem_168 = native_batch_norm_default_54[0]
        getitem_169 = native_batch_norm_default_54[1]
        getitem_170 = native_batch_norm_default_54[2];  native_batch_norm_default_54 = None
        relu__default_54 = torch.ops.aten.relu_.default(getitem_168);  getitem_168 = None
        convolution_default_55 = torch.ops.aten.convolution.default(relu__default_54, primals_336, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_55 = torch.ops.aten.native_batch_norm.default(convolution_default_55, primals_335, primals_331, primals_333, primals_334, True, 0.1, 0.001);  primals_331 = None
        getitem_171 = native_batch_norm_default_55[0]
        getitem_172 = native_batch_norm_default_55[1]
        getitem_173 = native_batch_norm_default_55[2];  native_batch_norm_default_55 = None
        relu__default_55 = torch.ops.aten.relu_.default(getitem_171);  getitem_171 = None
        convolution_default_56 = torch.ops.aten.convolution.default(relu__default_55, primals_342, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_56 = torch.ops.aten.native_batch_norm.default(convolution_default_56, primals_341, primals_337, primals_339, primals_340, True, 0.1, 0.001);  primals_337 = None
        getitem_174 = native_batch_norm_default_56[0]
        getitem_175 = native_batch_norm_default_56[1]
        getitem_176 = native_batch_norm_default_56[2];  native_batch_norm_default_56 = None
        relu__default_56 = torch.ops.aten.relu_.default(getitem_174);  getitem_174 = None
        convolution_default_57 = torch.ops.aten.convolution.default(relu__default_56, primals_348, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_57 = torch.ops.aten.native_batch_norm.default(convolution_default_57, primals_347, primals_343, primals_345, primals_346, True, 0.1, 0.001);  primals_343 = None
        getitem_177 = native_batch_norm_default_57[0]
        getitem_178 = native_batch_norm_default_57[1]
        getitem_179 = native_batch_norm_default_57[2];  native_batch_norm_default_57 = None
        relu__default_57 = torch.ops.aten.relu_.default(getitem_177);  getitem_177 = None
        convolution_default_58 = torch.ops.aten.convolution.default(relu__default_57, primals_354, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_58 = torch.ops.aten.native_batch_norm.default(convolution_default_58, primals_353, primals_349, primals_351, primals_352, True, 0.1, 0.001);  primals_349 = None
        getitem_180 = native_batch_norm_default_58[0]
        getitem_181 = native_batch_norm_default_58[1]
        getitem_182 = native_batch_norm_default_58[2];  native_batch_norm_default_58 = None
        relu__default_58 = torch.ops.aten.relu_.default(getitem_180);  getitem_180 = None
        avg_pool2d_default_5 = torch.ops.aten.avg_pool2d.default(cat_default_5, [3, 3], [1, 1], [1, 1])
        convolution_default_59 = torch.ops.aten.convolution.default(avg_pool2d_default_5, primals_360, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_59 = torch.ops.aten.native_batch_norm.default(convolution_default_59, primals_359, primals_355, primals_357, primals_358, True, 0.1, 0.001);  primals_355 = None
        getitem_183 = native_batch_norm_default_59[0]
        getitem_184 = native_batch_norm_default_59[1]
        getitem_185 = native_batch_norm_default_59[2];  native_batch_norm_default_59 = None
        relu__default_59 = torch.ops.aten.relu_.default(getitem_183);  getitem_183 = None
        cat_default_6 = torch.ops.aten.cat.default([relu__default_50, relu__default_53, relu__default_58, relu__default_59], 1)
        convolution_default_60 = torch.ops.aten.convolution.default(cat_default_6, primals_366, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_60 = torch.ops.aten.native_batch_norm.default(convolution_default_60, primals_365, primals_361, primals_363, primals_364, True, 0.1, 0.001);  primals_361 = None
        getitem_186 = native_batch_norm_default_60[0]
        getitem_187 = native_batch_norm_default_60[1]
        getitem_188 = native_batch_norm_default_60[2];  native_batch_norm_default_60 = None
        relu__default_60 = torch.ops.aten.relu_.default(getitem_186);  getitem_186 = None
        convolution_default_61 = torch.ops.aten.convolution.default(cat_default_6, primals_372, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_61 = torch.ops.aten.native_batch_norm.default(convolution_default_61, primals_371, primals_367, primals_369, primals_370, True, 0.1, 0.001);  primals_367 = None
        getitem_189 = native_batch_norm_default_61[0]
        getitem_190 = native_batch_norm_default_61[1]
        getitem_191 = native_batch_norm_default_61[2];  native_batch_norm_default_61 = None
        relu__default_61 = torch.ops.aten.relu_.default(getitem_189);  getitem_189 = None
        convolution_default_62 = torch.ops.aten.convolution.default(relu__default_61, primals_378, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_62 = torch.ops.aten.native_batch_norm.default(convolution_default_62, primals_377, primals_373, primals_375, primals_376, True, 0.1, 0.001);  primals_373 = None
        getitem_192 = native_batch_norm_default_62[0]
        getitem_193 = native_batch_norm_default_62[1]
        getitem_194 = native_batch_norm_default_62[2];  native_batch_norm_default_62 = None
        relu__default_62 = torch.ops.aten.relu_.default(getitem_192);  getitem_192 = None
        convolution_default_63 = torch.ops.aten.convolution.default(relu__default_62, primals_384, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_63 = torch.ops.aten.native_batch_norm.default(convolution_default_63, primals_383, primals_379, primals_381, primals_382, True, 0.1, 0.001);  primals_379 = None
        getitem_195 = native_batch_norm_default_63[0]
        getitem_196 = native_batch_norm_default_63[1]
        getitem_197 = native_batch_norm_default_63[2];  native_batch_norm_default_63 = None
        relu__default_63 = torch.ops.aten.relu_.default(getitem_195);  getitem_195 = None
        convolution_default_64 = torch.ops.aten.convolution.default(cat_default_6, primals_390, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_64 = torch.ops.aten.native_batch_norm.default(convolution_default_64, primals_389, primals_385, primals_387, primals_388, True, 0.1, 0.001);  primals_385 = None
        getitem_198 = native_batch_norm_default_64[0]
        getitem_199 = native_batch_norm_default_64[1]
        getitem_200 = native_batch_norm_default_64[2];  native_batch_norm_default_64 = None
        relu__default_64 = torch.ops.aten.relu_.default(getitem_198);  getitem_198 = None
        convolution_default_65 = torch.ops.aten.convolution.default(relu__default_64, primals_396, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_65 = torch.ops.aten.native_batch_norm.default(convolution_default_65, primals_395, primals_391, primals_393, primals_394, True, 0.1, 0.001);  primals_391 = None
        getitem_201 = native_batch_norm_default_65[0]
        getitem_202 = native_batch_norm_default_65[1]
        getitem_203 = native_batch_norm_default_65[2];  native_batch_norm_default_65 = None
        relu__default_65 = torch.ops.aten.relu_.default(getitem_201);  getitem_201 = None
        convolution_default_66 = torch.ops.aten.convolution.default(relu__default_65, primals_402, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_66 = torch.ops.aten.native_batch_norm.default(convolution_default_66, primals_401, primals_397, primals_399, primals_400, True, 0.1, 0.001);  primals_397 = None
        getitem_204 = native_batch_norm_default_66[0]
        getitem_205 = native_batch_norm_default_66[1]
        getitem_206 = native_batch_norm_default_66[2];  native_batch_norm_default_66 = None
        relu__default_66 = torch.ops.aten.relu_.default(getitem_204);  getitem_204 = None
        convolution_default_67 = torch.ops.aten.convolution.default(relu__default_66, primals_408, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_67 = torch.ops.aten.native_batch_norm.default(convolution_default_67, primals_407, primals_403, primals_405, primals_406, True, 0.1, 0.001);  primals_403 = None
        getitem_207 = native_batch_norm_default_67[0]
        getitem_208 = native_batch_norm_default_67[1]
        getitem_209 = native_batch_norm_default_67[2];  native_batch_norm_default_67 = None
        relu__default_67 = torch.ops.aten.relu_.default(getitem_207);  getitem_207 = None
        convolution_default_68 = torch.ops.aten.convolution.default(relu__default_67, primals_414, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_68 = torch.ops.aten.native_batch_norm.default(convolution_default_68, primals_413, primals_409, primals_411, primals_412, True, 0.1, 0.001);  primals_409 = None
        getitem_210 = native_batch_norm_default_68[0]
        getitem_211 = native_batch_norm_default_68[1]
        getitem_212 = native_batch_norm_default_68[2];  native_batch_norm_default_68 = None
        relu__default_68 = torch.ops.aten.relu_.default(getitem_210);  getitem_210 = None
        avg_pool2d_default_6 = torch.ops.aten.avg_pool2d.default(cat_default_6, [3, 3], [1, 1], [1, 1])
        convolution_default_69 = torch.ops.aten.convolution.default(avg_pool2d_default_6, primals_420, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_69 = torch.ops.aten.native_batch_norm.default(convolution_default_69, primals_419, primals_415, primals_417, primals_418, True, 0.1, 0.001);  primals_415 = None
        getitem_213 = native_batch_norm_default_69[0]
        getitem_214 = native_batch_norm_default_69[1]
        getitem_215 = native_batch_norm_default_69[2];  native_batch_norm_default_69 = None
        relu__default_69 = torch.ops.aten.relu_.default(getitem_213);  getitem_213 = None
        cat_default_7 = torch.ops.aten.cat.default([relu__default_60, relu__default_63, relu__default_68, relu__default_69], 1)
        convolution_default_70 = torch.ops.aten.convolution.default(cat_default_7, primals_426, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_70 = torch.ops.aten.native_batch_norm.default(convolution_default_70, primals_425, primals_421, primals_423, primals_424, True, 0.1, 0.001);  primals_421 = None
        getitem_216 = native_batch_norm_default_70[0]
        getitem_217 = native_batch_norm_default_70[1]
        getitem_218 = native_batch_norm_default_70[2];  native_batch_norm_default_70 = None
        relu__default_70 = torch.ops.aten.relu_.default(getitem_216);  getitem_216 = None
        convolution_default_71 = torch.ops.aten.convolution.default(relu__default_70, primals_432, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_71 = torch.ops.aten.native_batch_norm.default(convolution_default_71, primals_431, primals_427, primals_429, primals_430, True, 0.1, 0.001);  primals_427 = None
        getitem_219 = native_batch_norm_default_71[0]
        getitem_220 = native_batch_norm_default_71[1]
        getitem_221 = native_batch_norm_default_71[2];  native_batch_norm_default_71 = None
        relu__default_71 = torch.ops.aten.relu_.default(getitem_219);  getitem_219 = None
        convolution_default_72 = torch.ops.aten.convolution.default(cat_default_7, primals_438, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_72 = torch.ops.aten.native_batch_norm.default(convolution_default_72, primals_437, primals_433, primals_435, primals_436, True, 0.1, 0.001);  primals_433 = None
        getitem_222 = native_batch_norm_default_72[0]
        getitem_223 = native_batch_norm_default_72[1]
        getitem_224 = native_batch_norm_default_72[2];  native_batch_norm_default_72 = None
        relu__default_72 = torch.ops.aten.relu_.default(getitem_222);  getitem_222 = None
        convolution_default_73 = torch.ops.aten.convolution.default(relu__default_72, primals_444, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_73 = torch.ops.aten.native_batch_norm.default(convolution_default_73, primals_443, primals_439, primals_441, primals_442, True, 0.1, 0.001);  primals_439 = None
        getitem_225 = native_batch_norm_default_73[0]
        getitem_226 = native_batch_norm_default_73[1]
        getitem_227 = native_batch_norm_default_73[2];  native_batch_norm_default_73 = None
        relu__default_73 = torch.ops.aten.relu_.default(getitem_225);  getitem_225 = None
        convolution_default_74 = torch.ops.aten.convolution.default(relu__default_73, primals_450, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_74 = torch.ops.aten.native_batch_norm.default(convolution_default_74, primals_449, primals_445, primals_447, primals_448, True, 0.1, 0.001);  primals_445 = None
        getitem_228 = native_batch_norm_default_74[0]
        getitem_229 = native_batch_norm_default_74[1]
        getitem_230 = native_batch_norm_default_74[2];  native_batch_norm_default_74 = None
        relu__default_74 = torch.ops.aten.relu_.default(getitem_228);  getitem_228 = None
        convolution_default_75 = torch.ops.aten.convolution.default(relu__default_74, primals_456, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_75 = torch.ops.aten.native_batch_norm.default(convolution_default_75, primals_455, primals_451, primals_453, primals_454, True, 0.1, 0.001);  primals_451 = None
        getitem_231 = native_batch_norm_default_75[0]
        getitem_232 = native_batch_norm_default_75[1]
        getitem_233 = native_batch_norm_default_75[2];  native_batch_norm_default_75 = None
        relu__default_75 = torch.ops.aten.relu_.default(getitem_231);  getitem_231 = None
        max_pool2d_with_indices_default_3 = torch.ops.aten.max_pool2d_with_indices.default(cat_default_7, [3, 3], [2, 2])
        getitem_234 = max_pool2d_with_indices_default_3[0]
        getitem_235 = max_pool2d_with_indices_default_3[1];  max_pool2d_with_indices_default_3 = None
        cat_default_8 = torch.ops.aten.cat.default([relu__default_71, relu__default_75, getitem_234], 1);  getitem_234 = None
        convolution_default_76 = torch.ops.aten.convolution.default(cat_default_8, primals_462, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_76 = torch.ops.aten.native_batch_norm.default(convolution_default_76, primals_461, primals_457, primals_459, primals_460, True, 0.1, 0.001);  primals_457 = None
        getitem_236 = native_batch_norm_default_76[0]
        getitem_237 = native_batch_norm_default_76[1]
        getitem_238 = native_batch_norm_default_76[2];  native_batch_norm_default_76 = None
        relu__default_76 = torch.ops.aten.relu_.default(getitem_236);  getitem_236 = None
        convolution_default_77 = torch.ops.aten.convolution.default(cat_default_8, primals_468, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_77 = torch.ops.aten.native_batch_norm.default(convolution_default_77, primals_467, primals_463, primals_465, primals_466, True, 0.1, 0.001);  primals_463 = None
        getitem_239 = native_batch_norm_default_77[0]
        getitem_240 = native_batch_norm_default_77[1]
        getitem_241 = native_batch_norm_default_77[2];  native_batch_norm_default_77 = None
        relu__default_77 = torch.ops.aten.relu_.default(getitem_239);  getitem_239 = None
        convolution_default_78 = torch.ops.aten.convolution.default(relu__default_77, primals_474, None, [1, 1], [0, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_78 = torch.ops.aten.native_batch_norm.default(convolution_default_78, primals_473, primals_469, primals_471, primals_472, True, 0.1, 0.001);  primals_469 = None
        getitem_242 = native_batch_norm_default_78[0]
        getitem_243 = native_batch_norm_default_78[1]
        getitem_244 = native_batch_norm_default_78[2];  native_batch_norm_default_78 = None
        relu__default_78 = torch.ops.aten.relu_.default(getitem_242);  getitem_242 = None
        convolution_default_79 = torch.ops.aten.convolution.default(relu__default_77, primals_480, None, [1, 1], [1, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_79 = torch.ops.aten.native_batch_norm.default(convolution_default_79, primals_479, primals_475, primals_477, primals_478, True, 0.1, 0.001);  primals_475 = None
        getitem_245 = native_batch_norm_default_79[0]
        getitem_246 = native_batch_norm_default_79[1]
        getitem_247 = native_batch_norm_default_79[2];  native_batch_norm_default_79 = None
        relu__default_79 = torch.ops.aten.relu_.default(getitem_245);  getitem_245 = None
        cat_default_9 = torch.ops.aten.cat.default([relu__default_78, relu__default_79], 1)
        convolution_default_80 = torch.ops.aten.convolution.default(cat_default_8, primals_486, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_80 = torch.ops.aten.native_batch_norm.default(convolution_default_80, primals_485, primals_481, primals_483, primals_484, True, 0.1, 0.001);  primals_481 = None
        getitem_248 = native_batch_norm_default_80[0]
        getitem_249 = native_batch_norm_default_80[1]
        getitem_250 = native_batch_norm_default_80[2];  native_batch_norm_default_80 = None
        relu__default_80 = torch.ops.aten.relu_.default(getitem_248);  getitem_248 = None
        convolution_default_81 = torch.ops.aten.convolution.default(relu__default_80, primals_492, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_81 = torch.ops.aten.native_batch_norm.default(convolution_default_81, primals_491, primals_487, primals_489, primals_490, True, 0.1, 0.001);  primals_487 = None
        getitem_251 = native_batch_norm_default_81[0]
        getitem_252 = native_batch_norm_default_81[1]
        getitem_253 = native_batch_norm_default_81[2];  native_batch_norm_default_81 = None
        relu__default_81 = torch.ops.aten.relu_.default(getitem_251);  getitem_251 = None
        convolution_default_82 = torch.ops.aten.convolution.default(relu__default_81, primals_498, None, [1, 1], [0, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_82 = torch.ops.aten.native_batch_norm.default(convolution_default_82, primals_497, primals_493, primals_495, primals_496, True, 0.1, 0.001);  primals_493 = None
        getitem_254 = native_batch_norm_default_82[0]
        getitem_255 = native_batch_norm_default_82[1]
        getitem_256 = native_batch_norm_default_82[2];  native_batch_norm_default_82 = None
        relu__default_82 = torch.ops.aten.relu_.default(getitem_254);  getitem_254 = None
        convolution_default_83 = torch.ops.aten.convolution.default(relu__default_81, primals_504, None, [1, 1], [1, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_83 = torch.ops.aten.native_batch_norm.default(convolution_default_83, primals_503, primals_499, primals_501, primals_502, True, 0.1, 0.001);  primals_499 = None
        getitem_257 = native_batch_norm_default_83[0]
        getitem_258 = native_batch_norm_default_83[1]
        getitem_259 = native_batch_norm_default_83[2];  native_batch_norm_default_83 = None
        relu__default_83 = torch.ops.aten.relu_.default(getitem_257);  getitem_257 = None
        cat_default_10 = torch.ops.aten.cat.default([relu__default_82, relu__default_83], 1)
        avg_pool2d_default_7 = torch.ops.aten.avg_pool2d.default(cat_default_8, [3, 3], [1, 1], [1, 1])
        convolution_default_84 = torch.ops.aten.convolution.default(avg_pool2d_default_7, primals_510, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_84 = torch.ops.aten.native_batch_norm.default(convolution_default_84, primals_509, primals_505, primals_507, primals_508, True, 0.1, 0.001);  primals_505 = None
        getitem_260 = native_batch_norm_default_84[0]
        getitem_261 = native_batch_norm_default_84[1]
        getitem_262 = native_batch_norm_default_84[2];  native_batch_norm_default_84 = None
        relu__default_84 = torch.ops.aten.relu_.default(getitem_260);  getitem_260 = None
        cat_default_11 = torch.ops.aten.cat.default([relu__default_76, cat_default_9, cat_default_10, relu__default_84], 1);  cat_default_9 = cat_default_10 = None
        convolution_default_85 = torch.ops.aten.convolution.default(cat_default_11, primals_516, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_85 = torch.ops.aten.native_batch_norm.default(convolution_default_85, primals_515, primals_511, primals_513, primals_514, True, 0.1, 0.001);  primals_511 = None
        getitem_263 = native_batch_norm_default_85[0]
        getitem_264 = native_batch_norm_default_85[1]
        getitem_265 = native_batch_norm_default_85[2];  native_batch_norm_default_85 = None
        relu__default_85 = torch.ops.aten.relu_.default(getitem_263);  getitem_263 = None
        convolution_default_86 = torch.ops.aten.convolution.default(cat_default_11, primals_522, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_86 = torch.ops.aten.native_batch_norm.default(convolution_default_86, primals_521, primals_517, primals_519, primals_520, True, 0.1, 0.001);  primals_517 = None
        getitem_266 = native_batch_norm_default_86[0]
        getitem_267 = native_batch_norm_default_86[1]
        getitem_268 = native_batch_norm_default_86[2];  native_batch_norm_default_86 = None
        relu__default_86 = torch.ops.aten.relu_.default(getitem_266);  getitem_266 = None
        convolution_default_87 = torch.ops.aten.convolution.default(relu__default_86, primals_528, None, [1, 1], [0, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_87 = torch.ops.aten.native_batch_norm.default(convolution_default_87, primals_527, primals_523, primals_525, primals_526, True, 0.1, 0.001);  primals_523 = None
        getitem_269 = native_batch_norm_default_87[0]
        getitem_270 = native_batch_norm_default_87[1]
        getitem_271 = native_batch_norm_default_87[2];  native_batch_norm_default_87 = None
        relu__default_87 = torch.ops.aten.relu_.default(getitem_269);  getitem_269 = None
        convolution_default_88 = torch.ops.aten.convolution.default(relu__default_86, primals_534, None, [1, 1], [1, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_88 = torch.ops.aten.native_batch_norm.default(convolution_default_88, primals_533, primals_529, primals_531, primals_532, True, 0.1, 0.001);  primals_529 = None
        getitem_272 = native_batch_norm_default_88[0]
        getitem_273 = native_batch_norm_default_88[1]
        getitem_274 = native_batch_norm_default_88[2];  native_batch_norm_default_88 = None
        relu__default_88 = torch.ops.aten.relu_.default(getitem_272);  getitem_272 = None
        cat_default_12 = torch.ops.aten.cat.default([relu__default_87, relu__default_88], 1)
        convolution_default_89 = torch.ops.aten.convolution.default(cat_default_11, primals_540, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_89 = torch.ops.aten.native_batch_norm.default(convolution_default_89, primals_539, primals_535, primals_537, primals_538, True, 0.1, 0.001);  primals_535 = None
        getitem_275 = native_batch_norm_default_89[0]
        getitem_276 = native_batch_norm_default_89[1]
        getitem_277 = native_batch_norm_default_89[2];  native_batch_norm_default_89 = None
        relu__default_89 = torch.ops.aten.relu_.default(getitem_275);  getitem_275 = None
        convolution_default_90 = torch.ops.aten.convolution.default(relu__default_89, primals_546, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_90 = torch.ops.aten.native_batch_norm.default(convolution_default_90, primals_545, primals_541, primals_543, primals_544, True, 0.1, 0.001);  primals_541 = None
        getitem_278 = native_batch_norm_default_90[0]
        getitem_279 = native_batch_norm_default_90[1]
        getitem_280 = native_batch_norm_default_90[2];  native_batch_norm_default_90 = None
        relu__default_90 = torch.ops.aten.relu_.default(getitem_278);  getitem_278 = None
        convolution_default_91 = torch.ops.aten.convolution.default(relu__default_90, primals_552, None, [1, 1], [0, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_91 = torch.ops.aten.native_batch_norm.default(convolution_default_91, primals_551, primals_547, primals_549, primals_550, True, 0.1, 0.001);  primals_547 = None
        getitem_281 = native_batch_norm_default_91[0]
        getitem_282 = native_batch_norm_default_91[1]
        getitem_283 = native_batch_norm_default_91[2];  native_batch_norm_default_91 = None
        relu__default_91 = torch.ops.aten.relu_.default(getitem_281);  getitem_281 = None
        convolution_default_92 = torch.ops.aten.convolution.default(relu__default_90, primals_558, None, [1, 1], [1, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_92 = torch.ops.aten.native_batch_norm.default(convolution_default_92, primals_557, primals_553, primals_555, primals_556, True, 0.1, 0.001);  primals_553 = None
        getitem_284 = native_batch_norm_default_92[0]
        getitem_285 = native_batch_norm_default_92[1]
        getitem_286 = native_batch_norm_default_92[2];  native_batch_norm_default_92 = None
        relu__default_92 = torch.ops.aten.relu_.default(getitem_284);  getitem_284 = None
        cat_default_13 = torch.ops.aten.cat.default([relu__default_91, relu__default_92], 1)
        avg_pool2d_default_8 = torch.ops.aten.avg_pool2d.default(cat_default_11, [3, 3], [1, 1], [1, 1])
        convolution_default_93 = torch.ops.aten.convolution.default(avg_pool2d_default_8, primals_564, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_93 = torch.ops.aten.native_batch_norm.default(convolution_default_93, primals_563, primals_559, primals_561, primals_562, True, 0.1, 0.001);  primals_559 = None
        getitem_287 = native_batch_norm_default_93[0]
        getitem_288 = native_batch_norm_default_93[1]
        getitem_289 = native_batch_norm_default_93[2];  native_batch_norm_default_93 = None
        relu__default_93 = torch.ops.aten.relu_.default(getitem_287);  getitem_287 = None
        cat_default_14 = torch.ops.aten.cat.default([relu__default_85, cat_default_12, cat_default_13, relu__default_93], 1);  cat_default_12 = cat_default_13 = None
        mean_dim = torch.ops.aten.mean.dim(cat_default_14, [-1, -2], True);  cat_default_14 = None
        view_default = torch.ops.aten.view.default(mean_dim, [128, 2048]);  mean_dim = None
        t_default = torch.ops.aten.t.default(primals_566);  primals_566 = None
        addmm_default = torch.ops.aten.addmm.default(primals_565, view_default, t_default);  primals_565 = None
        return [addmm_default, primals_298, convolution_default_26, getitem_280, primals_303, getitem_223, primals_51, primals_299, convolution_default_47, primals_58, primals_304, relu__default_90, primals_381, primals_371, getitem_84, getitem_83, getitem_149, convolution_default_91, primals_52, getitem_148, relu__default_72, getitem_224, primals_311, primals_369, convolution_default_73, primals_382, getitem_283, getitem_282, primals_63, primals_65, primals_300, relu__default_26, primals_12, primals_66, primals_312, relu__default_47, getitem_227, primals_376, convolution_default_27, getitem_226, primals_378, convolution_default_48, primals_57, primals_297, relu__default_91, primals_59, primals_377, getitem_87, primals_370, getitem_86, convolution_default_92, getitem_152, primals_294, primals_375, getitem_151, relu__default_73, primals_309, primals_54, primals_384, primals_6, primals_60, convolution_default_74, getitem_285, primals_305, relu__default_27, primals_64, getitem_286, primals_53, primals_372, relu__default_48, convolution_default_28, relu__default_92, getitem_229, primals_383, convolution_default_49, getitem_230, primals_310, avg_pool2d_default_4, primals_387, primals_306, primals_358, primals_522, getitem_13, primals_342, primals_442, getitem_12, relu__default_60, avg_pool2d_default_7, convolution_default_84, primals_351, primals_443, primals_352, primals_345, primals_359, primals_525, convolution_default_61, primals_450, primals_340, primals_447, primals_526, primals_22, primals_366, primals_333, relu__default_3, convolution_default_63, primals_527, primals_24, primals_335, primals_18, getitem_191, convolution_default_85, primals_528, convolution_default_4, getitem_190, getitem_261, primals_444, primals_28, getitem_262, primals_334, primals_353, primals_336, getitem_16, primals_354, primals_531, getitem_15, primals_347, primals_532, relu__default_61, primals_448, primals_15, primals_365, primals_533, primals_449, convolution_default_62, relu__default_84, primals_27, primals_534, primals_339, primals_441, relu__default_4, primals_341, primals_537, getitem_193, primals_21, primals_357, primals_453, getitem_194, cat_default_11, primals_17, primals_538, getitem_17, convolution_default_5, primals_23, primals_454, getitem_18, primals_348, primals_539, primals_364, primals_455, primals_16, primals_540, getitem_264, getitem_265, primals_456, relu__default_62, primals_346, primals_360, relu__default_85, primals_363, getitem_119, primals_172, avg_pool2d_default_8, getitem_166, getitem_160, relu__default_74, primals_87, relu__default_37, getitem_161, convolution_default_93, primals_90, convolution_default_75, primals_160, primals_167, primals_101, primals_99, convolution_default_38, primals_89, relu__default_51, primals_327, primals_102, getitem_233, getitem_288, primals_88, primals_330, primals_317, getitem_232, convolution_default_52, getitem_289, getitem_122, avg_pool2d_default_3, getitem_121, getitem_164, primals_329, primals_94, primals_161, primals_315, getitem_163, primals_166, relu__default_75, primals_173, relu__default_93, relu__default_38, view_default, primals_95, cat_default_8, primals_171, relu__default_52, getitem_235, primals_165, convolution_default_76, primals_96, primals_323, primals_162, getitem_237, primals_178, primals_322, convolution_default_39, convolution_default_53, getitem_240, primals_5, primals_324, primals_174, primals_316, relu__default_53, relu__default_76, t_default, primals_177, primals_328, relu__default_39, getitem_124, primals_93, primals_168, primals_318, getitem_167, getitem_238, cat_default_4, primals_100, getitem_125, primals_321, convolution_default_59, primals_564, getitem_26, getitem_89, primals_83, getitem_20, primals_208, getitem_90, primals_70, getitem_21, getitem_63, getitem_62, convolution_default_54, getitem_197, primals_240, getitem_57, avg_pool2d_default_1, primals_567, getitem_56, primals_238, convolution_default_40, primals_71, primals_209, primals_243, relu__default_5, relu__default_28, convolution_default, getitem_170, getitem_169, primals_246, getitem_128, primals_204, primals_237, convolution_default_6, convolution_default_29, getitem_127, relu__default_19, primals_201, primals_207, relu__default_17, relu__default_63, primals_239, convolution_default_42, convolution_default_18, convolution_default_20, getitem_24, getitem_93, primals_244, convolution_default_64, getitem_23, getitem_92, primals_210, relu__default_54, primals_77, primals_78, relu__default_40, primals_245, getitem_66, convolution_default_55, primals_255, getitem_65, getitem_200, convolution_default_41, getitem_199, primals_251, cat_default_1, primals_76, primals_216, primals_72, primals_203, relu__default_6, getitem_59, getitem_60, relu__default_29, primals_75, getitem_172, convolution_default_7, primals_69, primals_214, getitem_130, getitem_173, primals_84, relu__default_7, relu__default_20, relu__default_64, primals_202, primals_250, getitem_131, primals_213, getitem_95, convolution_default_30, cat_default_3, primals_215, convolution_default_21, convolution_default_65, primals_81, relu__default_18, relu__default_55, primals_252, primals_82, getitem_27, relu__default_41, primals_249, convolution_default_19, convolution_default_56, primals_186, primals_459, primals_142, primals_501, getitem_5, primals_156, primals_180, primals_460, primals_502, getitem_140, primals_189, getitem_4, getitem_134, primals_461, primals_503, getitem_133, convolution_default_8, relu__default_44, convolution_default_77, primals_462, primals_504, primals_141, primals_154, primals_124, convolution_default_45, getitem_30, getitem_241, primals_137, relu__default_1, primals_143, getitem_29, getitem_139, primals_465, primals_507, relu__default_42, convolution_default_2, primals_466, primals_508, getitem_143, primals_191, getitem_142, primals_148, primals_198, convolution_default_43, primals_132, primals_467, primals_509, primals_136, primals_159, primals_147, primals_468, primals_185, primals_510, relu__default_8, getitem_8, relu__default_77, primals_196, getitem_7, primals_155, convolution_default_9, getitem_137, convolution_default_78, primals_144, primals_197, primals_126, primals_138, getitem_136, relu__default_45, primals_471, primals_513, primals_129, primals_131, primals_149, primals_472, primals_514, convolution_default_46, primals_125, primals_473, primals_515, relu__default_2, getitem_32, getitem_243, getitem_33, getitem_244, primals_190, primals_474, primals_516, relu__default_43, primals_179, primals_150, getitem_9, convolution_default_44, convolution_default_3, getitem_10, primals_184, primals_135, primals_477, primals_519, relu__default_9, getitem_48, relu__default_78, getitem_145, primals_183, getitem_146, primals_130, primals_195, primals_478, primals_153, primals_520, relu__default_46, primals_192, convolution_default_10, convolution_default_79, primals_479, primals_521, primals_9, primals_30, getitem_97, getitem_202, getitem_274, getitem_69, getitem_273, convolution_default_86, getitem_98, getitem_203, getitem_247, primals_411, getitem_246, primals_47, primals_48, getitem_68, primals_418, relu__default_21, relu__default_65, getitem_268, primals_420, getitem_267, relu__default_30, relu__default_88, primals_405, convolution_default_22, primals_45, convolution_default_66, relu__default_79, convolution_default_31, primals_419, getitem_72, getitem_206, getitem_71, relu__default_86, convolution_default_89, getitem_101, getitem_205, primals_413, getitem_100, primals_39, primals_414, convolution_default_80, convolution_default_87, primals_417, getitem_277, primals_42, getitem_276, primals_408, primals_36, getitem_250, relu__default_22, getitem_249, relu__default_66, getitem_271, primals_3, relu__default_31, getitem_270, primals_46, primals_41, convolution_default_23, primals_29, primals_407, convolution_default_67, primals_34, convolution_default_32, relu__default_89, primals_33, primals_412, convolution_default_50, relu__default_80, getitem_208, convolution_default_90, getitem_103, relu__default_87, relu__default_67, relu__default_32, convolution_default_81, primals_35, convolution_default_88, getitem_74, getitem_75, relu__default_23, getitem_209, primals_40, getitem_104, getitem_279, primals_406, primals_543, primals_256, avg_pool2d_default, primals_293, convolution_default_70, primals_544, getitem_36, primals_286, relu__default_14, getitem_113, getitem_112, getitem_176, getitem_175, convolution_default_68, primals_545, getitem_35, primals_257, primals_291, primals_546, primals_268, convolution_default_15, getitem_218, getitem_217, getitem_212, primals_287, primals_399, getitem_211, primals_11, avg_pool2d_default_6, primals_390, relu__default_35, relu__default_56, relu__default_10, getitem_51, primals_549, getitem_50, convolution_default_11, convolution_default_36, primals_550, convolution_default_57, relu__default_70, primals_551, primals_280, relu__default_68, primals_261, primals_402, primals_270, primals_552, convolution_default_69, primals_258, convolution_default_71, primals_279, getitem_116, getitem_179, relu__default_15, getitem_115, getitem_178, getitem_38, primals_10, primals_292, getitem_39, primals_269, convolution_default_16, getitem_221, primals_555, getitem_220, primals_288, primals_401, primals_276, primals_556, primals_264, primals_267, primals_389, cat_default_7, primals_388, primals_557, relu__default_36, relu__default_57, primals_275, primals_393, primals_395, primals_274, primals_558, getitem_215, primals_282, primals_281, convolution_default_37, getitem_214, primals_263, primals_285, relu__default_11, convolution_default_58, relu__default_71, convolution_default_12, getitem_54, avg_pool2d_default_5, primals_400, primals_561, convolution_default_72, primals_396, relu__default_16, getitem_188, primals_262, primals_562, relu__default_69, primals_4, getitem_118, primals_563, getitem_53, primals_394, cat_default, primals_273, convolution_default_17, getitem_181, primals_480, getitem_42, getitem_252, primals_114, primals_231, getitem_41, convolution_default_24, getitem_155, getitem_154, getitem_182, getitem_253, primals_118, primals_423, convolution_default_33, primals_228, primals_436, relu__default_58, primals_426, primals_483, getitem_78, relu__default_81, primals_119, primals_220, primals_484, getitem_77, avg_pool2d_default_2, getitem_107, primals_117, relu__default_12, getitem_106, primals_485, convolution_default_82, primals_234, primals_486, convolution_default_13, relu__default_49, primals_425, getitem_184, getitem_256, getitem_185, relu__default_24, getitem_255, primals_424, convolution_default_25, relu__default_33, getitem_196, primals_437, primals_489, getitem_45, getitem_44, primals_435, primals_490, convolution_default_34, cat_default_5, primals_491, primals_111, primals_219, primals_106, getitem_158, primals_222, primals_492, getitem_157, getitem_2, relu__default_82, relu__default_59, getitem_110, cat_default_2, primals_105, getitem_1, relu__default_13, primals_438, getitem_109, convolution_default_60, primals_107, primals_221, convolution_default_83, primals_120, relu__default, primals_225, primals_431, primals_108, primals_226, primals_495, convolution_default_14, getitem_81, getitem_80, primals_227, primals_429, primals_496, relu__default_50, getitem_258, cat_default_6, relu__default_83, primals_497, relu__default_34, convolution_default_51, primals_123, primals_498, primals_432, relu__default_25, primals_232, primals_113, getitem_47, convolution_default_35, primals_430, getitem_187, getitem_259, convolution_default_1, primals_112, primals_233]
        
