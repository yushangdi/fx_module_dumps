
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/regnety_002/regnety_002_backward_0/state_dict.pt'))

    
    
    def forward(self, primals_101, getitem_76, primals_298, convolution_default_11, primals_97, primals_252, primals_163, primals_297, mean_dim, primals_98, getitem_83, primals_4, primals_158, primals_95, primals_286, relu__default_23, convolution_default_12, relu__default_2, getitem_77, getitem_116, primals_292, getitem_22, mean_dim_7, primals_3, primals_302, convolution_default_41, primals_157, relu_default_2, primals_161, getitem_8, primals_253, convolution_default_39, convolution_default, convolution_default_61, primals_256, relu__default_22, getitem_25, relu__default_34, primals_301, getitem_82, primals_103, getitem_7, primals_288, primals_102, primals_291, primals_162, primals_258, getitem_115, getitem_118, primals_287, primals_257, getitem_26, relu__default_35, getitem_80, getitem_23, primals_296, view_default, primals_293, convolution_default_40, getitem_119, mean_dim_11, primals_99, primals_231, primals_243, convolution_default_24, primals_251, mul_tensor_10, relu__default_16, primals_236, convolution_default_33, primals_247, relu_default_6, getitem_86, t_default, primals_207, relu_default_9, mul_tensor_3, primals_268, convolution_default_8, relu_default_3, sigmoid_default_6, primals_248, getitem_1, getitem_104, primals_267, relu__default_12, primals_266, primals_233, convolution_default_69, primals_261, convolution_default_38, getitem_79, convolution_default_23, sigmoid_default_3, primals_29, getitem_17, primals_206, sigmoid_default_7, primals_242, relu_default_7, sigmoid_default_2, getitem_103, getitem_112, getitem_67, primals_263, primals_203, primals_271, getitem_16, getitem_34, relu_default_5, primals_31, primals_208, sigmoid_default_12, primals_202, primals_241, convolution_default_44, relu_default_10, relu__default_19, primals_232, convolution_default_55, getitem_65, getitem_85, getitem_113, getitem_68, convolution_default_45, primals_33, getitem_73, relu__default_39, getitem_46, primals_34, primals_35, sigmoid_default_10, primals_272, relu__default_4, primals_262, relu__default_11, getitem_47, convolution_default_30, primals_237, convolution_default_34, getitem_74, mul_tensor_12, primals_246, convolution_default_35, primals_36, primals_238, mul_tensor_6, convolution_default_59, relu__default_24, relu__default_33, convolution_default_17, getitem_64, mul_tensor_7, mul_tensor_2, getitem_14, convolution_default_66, primals_88, relu__default_8, relu__default_17, primals_42, primals_91, primals_112, convolution_default_7, getitem_32, primals_92, getitem_125, relu__default_30, primals_90, mean_dim_5, primals_93, primals_106, primals_86, sigmoid_default_9, primals_111, getitem_121, relu__default_29, getitem_61, convolution_default_54, primals_303, getitem_100, primals_41, primals_316, primals_38, mean_dim_12, mul_tensor_9, getitem_124, primals_317, primals_85, getitem_13, sigmoid_default_1, sigmoid_default_5, getitem_128, getitem_122, convolution_default_65, primals_107, mul_tensor_5, relu__default_9, mean_dim_9, getitem_31, getitem_127, primals_43, primals_318, relu__default_5, primals_108, relu__default_37, mean_dim_2, primals_40, mul_tensor_1, getitem_101, relu__default_6, relu__default_18, primals_45, getitem_62, relu__default_28, getitem_58, primals_12, primals_78, getitem_97, convolution_default_51, primals_81, relu_default_4, getitem_92, relu__default_32, getitem_91, getitem_98, mul_tensor_8, primals_141, primals_198, mean_dim_8, primals_76, primals_191, primals_8, primals_84, mean_dim_10, primals_138, relu__default_26, primals_197, relu__default_31, primals_77, primals_14, sigmoid_default_8, getitem_110, getitem_56, getitem_109, convolution_default_29, getitem_59, primals_5, primals_79, getitem_107, relu__default_27, primals_10, primals_83, primals_137, getitem_55, convolution_default_28, relu__default_25, primals_136, primals_193, primals_11, convolution_default_60, primals_13, primals_196, convolution_default_46, primals_201, convolution_default_56, primals_192, primals_6, primals_74, primals_167, primals_69, primals_171, primals_65, primals_228, convolution_default_18, primals_227, getitem_37, getitem_35, primals_58, primals_226, mean_dim_1, primals_63, getitem_20, primals_223, primals_64, getitem_38, primals_70, primals_172, primals_71, primals_221, primals_173, primals_168, primals_166, primals_222, primals_72, getitem_19, primals_62, primals_60, primals_67, primals_47, relu__default_15, convolution_default_2, primals_128, relu_default_11, getitem_94, relu__default_38, primals_122, primals_27, primals_56, getitem_28, convolution_default_49, primals_16, primals_126, relu__default_1, relu_default_8, primals_142, convolution_default_1, getitem_11, getitem_50, mul_tensor_4, primals_131, primals_156, getitem_41, primals_53, primals_153, relu__default, relu__default_10, relu__default_36, primals_19, sigmoid_default_11, getitem_5, getitem_53, primals_143, relu_default_1, getitem_44, primals_24, primals_127, primals_147, primals_22, primals_28, relu__default_14, primals_151, primals_18, primals_132, getitem_43, getitem_4, getitem_52, relu__default_7, getitem_106, primals_121, convolution_default_20, getitem_49, getitem_40, mean_dim_3, mean_dim_4, primals_55, primals_51, getitem_95, primals_148, convolution_default_50, convolution_default_64, primals_57, primals_21, primals_48, primals_146, getitem_29, mul_tensor_11, getitem_2, getitem_10, convolution_default_14, primals_20, primals_26, relu__default_13, sigmoid_default_4, primals_50, convolution_default_5, relu_default_12, primals_133, primals_152, primals_123, primals_49, convolution_default_6, convolution_default_13, convolution_default_19, convolution_default_25, primals_187, getitem_71, primals_311, getitem_130, mean_dim_6, primals_177, primals_186, primals_277, primals_312, primals_182, getitem_131, primals_178, primals_308, primals_188, getitem_89, primals_282, primals_273, primals_176, primals_283, primals_313, primals_307, primals_181, primals_306, primals_281, getitem_88, relu__default_20, relu__default_21, primals_183, primals_278, primals_276, getitem_70, primals_118, primals_116, primals_216, primals_113, relu_default, primals_117, relu__default_3, primals_218, primals_213, sigmoid_default, primals_211, mul_tensor, primals_217, primals_212, tangents_1, tangents_2, tangents_3, tangents_4, tangents_5, tangents_6, tangents_7, tangents_8, tangents_9, tangents_10, tangents_11, tangents_12, tangents_13, tangents_14, tangents_15, tangents_16, tangents_17, tangents_18, tangents_19, tangents_20, tangents_21, tangents_22, tangents_23, tangents_24, tangents_25, tangents_26, tangents_27, tangents_28, tangents_29, tangents_30, tangents_31, tangents_32, tangents_33, tangents_34, tangents_35, tangents_36, tangents_37, tangents_38, tangents_39, tangents_40, tangents_41, tangents_42, tangents_43, tangents_44, tangents_45):
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, view_default);  t_default_2 = view_default = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_1 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        view_default_2 = torch.ops.aten.view.default(mm_default, [128, 368, 1, 1]);  mm_default = None
        expand_default = torch.ops.aten.expand.default(view_default_2, [128, 368, 7, 7]);  view_default_2 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 49);  expand_default = None
        to_dtype = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu_default_12, torch.float32);  relu_default_12 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default_44 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_44, to_dtype);  le_scalar = new_zeros_default_44 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_2, convolution_default_69, primals_318, primals_316, primals_317, getitem_130, getitem_131, True, 1e-05, [True, True, True]);  convolution_default_69 = primals_318 = primals_316 = primals_317 = getitem_130 = getitem_131 = None
        getitem_132 = native_batch_norm_backward_default[0]
        getitem_133 = native_batch_norm_backward_default[1]
        getitem_134 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(getitem_132, mul_tensor_12, primals_93, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_132 = mul_tensor_12 = primals_93 = None
        getitem_135 = convolution_backward_default[0]
        getitem_136 = convolution_backward_default[1];  convolution_backward_default = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(getitem_135, relu__default_38)
        mul_tensor_14 = torch.ops.aten.mul.Tensor(getitem_135, sigmoid_default_12);  getitem_135 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(mul_tensor_13, [2, 3], True);  mul_tensor_13 = None
        to_dtype_3 = torch.ops.aten.to.dtype(sum_dim_int_list_1, torch.float32);  sum_dim_int_list_1 = None
        to_dtype_4 = torch.ops.aten.to.dtype(sigmoid_default_12, torch.float32);  sigmoid_default_12 = None
        rsub_scalar = torch.ops.aten.rsub.Scalar(to_dtype_4, 1)
        mul_tensor_15 = torch.ops.aten.mul.Tensor(to_dtype_4, rsub_scalar);  to_dtype_4 = rsub_scalar = None
        conj_physical_default = torch.ops.aten.conj_physical.default(mul_tensor_15);  mul_tensor_15 = None
        mul_tensor_16 = torch.ops.aten.mul.Tensor(to_dtype_3, conj_physical_default);  to_dtype_3 = conj_physical_default = None
        to_dtype_5 = torch.ops.aten.to.dtype(mul_tensor_16, torch.float32);  mul_tensor_16 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(to_dtype_5, relu__default_39, primals_97, [368], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_5 = primals_97 = None
        getitem_138 = convolution_backward_default_1[0]
        getitem_139 = convolution_backward_default_1[1]
        getitem_140 = convolution_backward_default_1[2];  convolution_backward_default_1 = None
        to_dtype_6 = torch.ops.aten.to.dtype(getitem_138, torch.float32);  getitem_138 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_39, torch.float32);  relu__default_39 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_45 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_45, to_dtype_6);  le_scalar_1 = new_zeros_default_45 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(to_dtype_8, mean_dim_12, primals_95, [92], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_8 = mean_dim_12 = primals_95 = None
        getitem_141 = convolution_backward_default_2[0]
        getitem_142 = convolution_backward_default_2[1]
        getitem_143 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        expand_default_1 = torch.ops.aten.expand.default(getitem_141, [128, 368, 7, 7]);  getitem_141 = None
        div_scalar_1 = torch.ops.aten.div.Scalar(expand_default_1, 49);  expand_default_1 = None
        add_tensor_57 = torch.ops.aten.add.Tensor(mul_tensor_14, div_scalar_1);  mul_tensor_14 = div_scalar_1 = None
        to_dtype_9 = torch.ops.aten.to.dtype(add_tensor_57, torch.float32);  add_tensor_57 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu__default_38, torch.float32);  relu__default_38 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_46 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_46, to_dtype_9);  le_scalar_2 = new_zeros_default_46 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_66, primals_313, primals_311, primals_312, getitem_127, getitem_128, True, 1e-05, [True, True, True]);  to_dtype_11 = convolution_default_66 = primals_313 = primals_311 = primals_312 = getitem_127 = getitem_128 = None
        getitem_144 = native_batch_norm_backward_default_1[0]
        getitem_145 = native_batch_norm_backward_default_1[1]
        getitem_146 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_144, relu__default_37, primals_92, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 46, [True, True, False]);  getitem_144 = primals_92 = None
        getitem_147 = convolution_backward_default_3[0]
        getitem_148 = convolution_backward_default_3[1];  convolution_backward_default_3 = None
        to_dtype_12 = torch.ops.aten.to.dtype(getitem_147, torch.float32);  getitem_147 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_37, torch.float32);  relu__default_37 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_47 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_47, to_dtype_12);  le_scalar_3 = new_zeros_default_47 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_65, primals_308, primals_306, primals_307, getitem_124, getitem_125, True, 1e-05, [True, True, True]);  to_dtype_14 = convolution_default_65 = primals_308 = primals_306 = primals_307 = getitem_124 = getitem_125 = None
        getitem_150 = native_batch_norm_backward_default_2[0]
        getitem_151 = native_batch_norm_backward_default_2[1]
        getitem_152 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_150, relu_default_11, primals_91, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_150 = primals_91 = None
        getitem_153 = convolution_backward_default_4[0]
        getitem_154 = convolution_backward_default_4[1];  convolution_backward_default_4 = None
        add_tensor_58 = torch.ops.aten.add.Tensor(to_dtype_2, getitem_153);  to_dtype_2 = getitem_153 = None
        to_dtype_15 = torch.ops.aten.to.dtype(add_tensor_58, torch.float32);  add_tensor_58 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu_default_11, torch.float32);  relu_default_11 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_48 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_48, to_dtype_15);  le_scalar_4 = new_zeros_default_48 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_17, convolution_default_64, primals_303, primals_301, primals_302, getitem_121, getitem_122, True, 1e-05, [True, True, True]);  convolution_default_64 = primals_303 = primals_301 = primals_302 = getitem_121 = getitem_122 = None
        getitem_156 = native_batch_norm_backward_default_3[0]
        getitem_157 = native_batch_norm_backward_default_3[1]
        getitem_158 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_156, mul_tensor_11, primals_86, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_156 = mul_tensor_11 = primals_86 = None
        getitem_159 = convolution_backward_default_5[0]
        getitem_160 = convolution_backward_default_5[1];  convolution_backward_default_5 = None
        mul_tensor_17 = torch.ops.aten.mul.Tensor(getitem_159, relu__default_35)
        mul_tensor_18 = torch.ops.aten.mul.Tensor(getitem_159, sigmoid_default_11);  getitem_159 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(mul_tensor_17, [2, 3], True);  mul_tensor_17 = None
        to_dtype_18 = torch.ops.aten.to.dtype(sum_dim_int_list_2, torch.float32);  sum_dim_int_list_2 = None
        to_dtype_19 = torch.ops.aten.to.dtype(sigmoid_default_11, torch.float32);  sigmoid_default_11 = None
        rsub_scalar_1 = torch.ops.aten.rsub.Scalar(to_dtype_19, 1)
        mul_tensor_19 = torch.ops.aten.mul.Tensor(to_dtype_19, rsub_scalar_1);  to_dtype_19 = rsub_scalar_1 = None
        conj_physical_default_1 = torch.ops.aten.conj_physical.default(mul_tensor_19);  mul_tensor_19 = None
        mul_tensor_20 = torch.ops.aten.mul.Tensor(to_dtype_18, conj_physical_default_1);  to_dtype_18 = conj_physical_default_1 = None
        to_dtype_20 = torch.ops.aten.to.dtype(mul_tensor_20, torch.float32);  mul_tensor_20 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(to_dtype_20, relu__default_36, primals_90, [368], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_20 = primals_90 = None
        getitem_162 = convolution_backward_default_6[0]
        getitem_163 = convolution_backward_default_6[1]
        getitem_164 = convolution_backward_default_6[2];  convolution_backward_default_6 = None
        to_dtype_21 = torch.ops.aten.to.dtype(getitem_162, torch.float32);  getitem_162 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_36, torch.float32);  relu__default_36 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_49 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_49, to_dtype_21);  le_scalar_5 = new_zeros_default_49 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(to_dtype_23, mean_dim_11, primals_88, [92], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_23 = mean_dim_11 = primals_88 = None
        getitem_165 = convolution_backward_default_7[0]
        getitem_166 = convolution_backward_default_7[1]
        getitem_167 = convolution_backward_default_7[2];  convolution_backward_default_7 = None
        expand_default_2 = torch.ops.aten.expand.default(getitem_165, [128, 368, 7, 7]);  getitem_165 = None
        div_scalar_2 = torch.ops.aten.div.Scalar(expand_default_2, 49);  expand_default_2 = None
        add_tensor_59 = torch.ops.aten.add.Tensor(mul_tensor_18, div_scalar_2);  mul_tensor_18 = div_scalar_2 = None
        to_dtype_24 = torch.ops.aten.to.dtype(add_tensor_59, torch.float32);  add_tensor_59 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_35, torch.float32);  relu__default_35 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_50 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_50, to_dtype_24);  le_scalar_6 = new_zeros_default_50 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_61, primals_298, primals_296, primals_297, getitem_118, getitem_119, True, 1e-05, [True, True, True]);  to_dtype_26 = convolution_default_61 = primals_298 = primals_296 = primals_297 = getitem_118 = getitem_119 = None
        getitem_168 = native_batch_norm_backward_default_4[0]
        getitem_169 = native_batch_norm_backward_default_4[1]
        getitem_170 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(getitem_168, relu__default_34, primals_85, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 46, [True, True, False]);  getitem_168 = primals_85 = None
        getitem_171 = convolution_backward_default_8[0]
        getitem_172 = convolution_backward_default_8[1];  convolution_backward_default_8 = None
        to_dtype_27 = torch.ops.aten.to.dtype(getitem_171, torch.float32);  getitem_171 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu__default_34, torch.float32);  relu__default_34 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_51 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_51, to_dtype_27);  le_scalar_7 = new_zeros_default_51 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_29, convolution_default_60, primals_293, primals_291, primals_292, getitem_115, getitem_116, True, 1e-05, [True, True, True]);  to_dtype_29 = convolution_default_60 = primals_293 = primals_291 = primals_292 = getitem_115 = getitem_116 = None
        getitem_174 = native_batch_norm_backward_default_5[0]
        getitem_175 = native_batch_norm_backward_default_5[1]
        getitem_176 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_174, relu_default_10, primals_84, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_174 = primals_84 = None
        getitem_177 = convolution_backward_default_9[0]
        getitem_178 = convolution_backward_default_9[1];  convolution_backward_default_9 = None
        add_tensor_60 = torch.ops.aten.add.Tensor(to_dtype_17, getitem_177);  to_dtype_17 = getitem_177 = None
        to_dtype_30 = torch.ops.aten.to.dtype(add_tensor_60, torch.float32);  add_tensor_60 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu_default_10, torch.float32);  relu_default_10 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_52 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_52, to_dtype_30);  le_scalar_8 = new_zeros_default_52 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default_59, primals_288, primals_286, primals_287, getitem_112, getitem_113, True, 1e-05, [True, True, True]);  convolution_default_59 = primals_288 = primals_286 = primals_287 = getitem_112 = getitem_113 = None
        getitem_180 = native_batch_norm_backward_default_6[0]
        getitem_181 = native_batch_norm_backward_default_6[1]
        getitem_182 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_180, mul_tensor_10, primals_79, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_180 = mul_tensor_10 = primals_79 = None
        getitem_183 = convolution_backward_default_10[0]
        getitem_184 = convolution_backward_default_10[1];  convolution_backward_default_10 = None
        mul_tensor_21 = torch.ops.aten.mul.Tensor(getitem_183, relu__default_32)
        mul_tensor_22 = torch.ops.aten.mul.Tensor(getitem_183, sigmoid_default_10);  getitem_183 = None
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(mul_tensor_21, [2, 3], True);  mul_tensor_21 = None
        to_dtype_33 = torch.ops.aten.to.dtype(sum_dim_int_list_3, torch.float32);  sum_dim_int_list_3 = None
        to_dtype_34 = torch.ops.aten.to.dtype(sigmoid_default_10, torch.float32);  sigmoid_default_10 = None
        rsub_scalar_2 = torch.ops.aten.rsub.Scalar(to_dtype_34, 1)
        mul_tensor_23 = torch.ops.aten.mul.Tensor(to_dtype_34, rsub_scalar_2);  to_dtype_34 = rsub_scalar_2 = None
        conj_physical_default_2 = torch.ops.aten.conj_physical.default(mul_tensor_23);  mul_tensor_23 = None
        mul_tensor_24 = torch.ops.aten.mul.Tensor(to_dtype_33, conj_physical_default_2);  to_dtype_33 = conj_physical_default_2 = None
        to_dtype_35 = torch.ops.aten.to.dtype(mul_tensor_24, torch.float32);  mul_tensor_24 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(to_dtype_35, relu__default_33, primals_83, [368], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_35 = primals_83 = None
        getitem_186 = convolution_backward_default_11[0]
        getitem_187 = convolution_backward_default_11[1]
        getitem_188 = convolution_backward_default_11[2];  convolution_backward_default_11 = None
        to_dtype_36 = torch.ops.aten.to.dtype(getitem_186, torch.float32);  getitem_186 = None
        to_dtype_37 = torch.ops.aten.to.dtype(relu__default_33, torch.float32);  relu__default_33 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        new_zeros_default_53 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_53, to_dtype_36);  le_scalar_9 = new_zeros_default_53 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(to_dtype_38, mean_dim_10, primals_81, [92], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_38 = mean_dim_10 = primals_81 = None
        getitem_189 = convolution_backward_default_12[0]
        getitem_190 = convolution_backward_default_12[1]
        getitem_191 = convolution_backward_default_12[2];  convolution_backward_default_12 = None
        expand_default_3 = torch.ops.aten.expand.default(getitem_189, [128, 368, 7, 7]);  getitem_189 = None
        div_scalar_3 = torch.ops.aten.div.Scalar(expand_default_3, 49);  expand_default_3 = None
        add_tensor_61 = torch.ops.aten.add.Tensor(mul_tensor_22, div_scalar_3);  mul_tensor_22 = div_scalar_3 = None
        to_dtype_39 = torch.ops.aten.to.dtype(add_tensor_61, torch.float32);  add_tensor_61 = None
        to_dtype_40 = torch.ops.aten.to.dtype(relu__default_32, torch.float32);  relu__default_32 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        new_zeros_default_54 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_54, to_dtype_39);  le_scalar_10 = new_zeros_default_54 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_41, convolution_default_56, primals_283, primals_281, primals_282, getitem_109, getitem_110, True, 1e-05, [True, True, True]);  to_dtype_41 = convolution_default_56 = primals_283 = primals_281 = primals_282 = getitem_109 = getitem_110 = None
        getitem_192 = native_batch_norm_backward_default_7[0]
        getitem_193 = native_batch_norm_backward_default_7[1]
        getitem_194 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_192, relu__default_31, primals_78, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 46, [True, True, False]);  getitem_192 = primals_78 = None
        getitem_195 = convolution_backward_default_13[0]
        getitem_196 = convolution_backward_default_13[1];  convolution_backward_default_13 = None
        to_dtype_42 = torch.ops.aten.to.dtype(getitem_195, torch.float32);  getitem_195 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu__default_31, torch.float32);  relu__default_31 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_55 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_55, to_dtype_42);  le_scalar_11 = new_zeros_default_55 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_44, convolution_default_55, primals_278, primals_276, primals_277, getitem_106, getitem_107, True, 1e-05, [True, True, True]);  to_dtype_44 = convolution_default_55 = primals_278 = primals_276 = primals_277 = getitem_106 = getitem_107 = None
        getitem_198 = native_batch_norm_backward_default_8[0]
        getitem_199 = native_batch_norm_backward_default_8[1]
        getitem_200 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_198, relu_default_9, primals_77, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_198 = primals_77 = None
        getitem_201 = convolution_backward_default_14[0]
        getitem_202 = convolution_backward_default_14[1];  convolution_backward_default_14 = None
        add_tensor_62 = torch.ops.aten.add.Tensor(to_dtype_32, getitem_201);  to_dtype_32 = getitem_201 = None
        to_dtype_45 = torch.ops.aten.to.dtype(add_tensor_62, torch.float32);  add_tensor_62 = None
        to_dtype_46 = torch.ops.aten.to.dtype(relu_default_9, torch.float32);  relu_default_9 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_46, 0);  to_dtype_46 = None
        new_zeros_default_56 = torch.ops.aten.new_zeros.default(to_dtype_45, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_56, to_dtype_45);  le_scalar_12 = new_zeros_default_56 = to_dtype_45 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_47, convolution_default_54, primals_273, primals_271, primals_272, getitem_103, getitem_104, True, 1e-05, [True, True, True]);  convolution_default_54 = primals_273 = primals_271 = primals_272 = getitem_103 = getitem_104 = None
        getitem_204 = native_batch_norm_backward_default_9[0]
        getitem_205 = native_batch_norm_backward_default_9[1]
        getitem_206 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_204, mul_tensor_9, primals_72, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_204 = mul_tensor_9 = primals_72 = None
        getitem_207 = convolution_backward_default_15[0]
        getitem_208 = convolution_backward_default_15[1];  convolution_backward_default_15 = None
        mul_tensor_25 = torch.ops.aten.mul.Tensor(getitem_207, relu__default_29)
        mul_tensor_26 = torch.ops.aten.mul.Tensor(getitem_207, sigmoid_default_9);  getitem_207 = None
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(mul_tensor_25, [2, 3], True);  mul_tensor_25 = None
        to_dtype_48 = torch.ops.aten.to.dtype(sum_dim_int_list_4, torch.float32);  sum_dim_int_list_4 = None
        to_dtype_49 = torch.ops.aten.to.dtype(sigmoid_default_9, torch.float32);  sigmoid_default_9 = None
        rsub_scalar_3 = torch.ops.aten.rsub.Scalar(to_dtype_49, 1)
        mul_tensor_27 = torch.ops.aten.mul.Tensor(to_dtype_49, rsub_scalar_3);  to_dtype_49 = rsub_scalar_3 = None
        conj_physical_default_3 = torch.ops.aten.conj_physical.default(mul_tensor_27);  mul_tensor_27 = None
        mul_tensor_28 = torch.ops.aten.mul.Tensor(to_dtype_48, conj_physical_default_3);  to_dtype_48 = conj_physical_default_3 = None
        to_dtype_50 = torch.ops.aten.to.dtype(mul_tensor_28, torch.float32);  mul_tensor_28 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(to_dtype_50, relu__default_30, primals_76, [368], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_50 = primals_76 = None
        getitem_210 = convolution_backward_default_16[0]
        getitem_211 = convolution_backward_default_16[1]
        getitem_212 = convolution_backward_default_16[2];  convolution_backward_default_16 = None
        to_dtype_51 = torch.ops.aten.to.dtype(getitem_210, torch.float32);  getitem_210 = None
        to_dtype_52 = torch.ops.aten.to.dtype(relu__default_30, torch.float32);  relu__default_30 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_52, 0);  to_dtype_52 = None
        new_zeros_default_57 = torch.ops.aten.new_zeros.default(to_dtype_51, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_57, to_dtype_51);  le_scalar_13 = new_zeros_default_57 = to_dtype_51 = None
        to_dtype_53 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(to_dtype_53, mean_dim_9, primals_74, [92], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_53 = mean_dim_9 = primals_74 = None
        getitem_213 = convolution_backward_default_17[0]
        getitem_214 = convolution_backward_default_17[1]
        getitem_215 = convolution_backward_default_17[2];  convolution_backward_default_17 = None
        expand_default_4 = torch.ops.aten.expand.default(getitem_213, [128, 368, 7, 7]);  getitem_213 = None
        div_scalar_4 = torch.ops.aten.div.Scalar(expand_default_4, 49);  expand_default_4 = None
        add_tensor_63 = torch.ops.aten.add.Tensor(mul_tensor_26, div_scalar_4);  mul_tensor_26 = div_scalar_4 = None
        to_dtype_54 = torch.ops.aten.to.dtype(add_tensor_63, torch.float32);  add_tensor_63 = None
        to_dtype_55 = torch.ops.aten.to.dtype(relu__default_29, torch.float32);  relu__default_29 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_55, 0);  to_dtype_55 = None
        new_zeros_default_58 = torch.ops.aten.new_zeros.default(to_dtype_54, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_58, to_dtype_54);  le_scalar_14 = new_zeros_default_58 = to_dtype_54 = None
        to_dtype_56 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_56, convolution_default_51, primals_268, primals_266, primals_267, getitem_100, getitem_101, True, 1e-05, [True, True, True]);  to_dtype_56 = convolution_default_51 = primals_268 = primals_266 = primals_267 = getitem_100 = getitem_101 = None
        getitem_216 = native_batch_norm_backward_default_10[0]
        getitem_217 = native_batch_norm_backward_default_10[1]
        getitem_218 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(getitem_216, relu__default_28, primals_71, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 46, [True, True, False]);  getitem_216 = primals_71 = None
        getitem_219 = convolution_backward_default_18[0]
        getitem_220 = convolution_backward_default_18[1];  convolution_backward_default_18 = None
        to_dtype_57 = torch.ops.aten.to.dtype(getitem_219, torch.float32);  getitem_219 = None
        to_dtype_58 = torch.ops.aten.to.dtype(relu__default_28, torch.float32);  relu__default_28 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_58, 0);  to_dtype_58 = None
        new_zeros_default_59 = torch.ops.aten.new_zeros.default(to_dtype_57, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_59, to_dtype_57);  le_scalar_15 = new_zeros_default_59 = to_dtype_57 = None
        to_dtype_59 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_59, convolution_default_50, primals_263, primals_261, primals_262, getitem_97, getitem_98, True, 1e-05, [True, True, True]);  to_dtype_59 = convolution_default_50 = primals_263 = primals_261 = primals_262 = getitem_97 = getitem_98 = None
        getitem_222 = native_batch_norm_backward_default_11[0]
        getitem_223 = native_batch_norm_backward_default_11[1]
        getitem_224 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_222, relu_default_8, primals_70, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_222 = primals_70 = None
        getitem_225 = convolution_backward_default_19[0]
        getitem_226 = convolution_backward_default_19[1];  convolution_backward_default_19 = None
        add_tensor_64 = torch.ops.aten.add.Tensor(to_dtype_47, getitem_225);  to_dtype_47 = getitem_225 = None
        to_dtype_60 = torch.ops.aten.to.dtype(add_tensor_64, torch.float32);  add_tensor_64 = None
        to_dtype_61 = torch.ops.aten.to.dtype(relu_default_8, torch.float32);  relu_default_8 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_61, 0);  to_dtype_61 = None
        new_zeros_default_60 = torch.ops.aten.new_zeros.default(to_dtype_60, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_60, to_dtype_60);  le_scalar_16 = new_zeros_default_60 = to_dtype_60 = None
        to_dtype_62 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_62, convolution_default_49, primals_258, primals_256, primals_257, getitem_94, getitem_95, True, 1e-05, [True, True, True]);  convolution_default_49 = primals_258 = primals_256 = primals_257 = getitem_94 = getitem_95 = None
        getitem_228 = native_batch_norm_backward_default_12[0]
        getitem_229 = native_batch_norm_backward_default_12[1]
        getitem_230 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(getitem_228, mul_tensor_8, primals_65, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_228 = mul_tensor_8 = primals_65 = None
        getitem_231 = convolution_backward_default_20[0]
        getitem_232 = convolution_backward_default_20[1];  convolution_backward_default_20 = None
        mul_tensor_29 = torch.ops.aten.mul.Tensor(getitem_231, relu__default_26)
        mul_tensor_30 = torch.ops.aten.mul.Tensor(getitem_231, sigmoid_default_8);  getitem_231 = None
        sum_dim_int_list_5 = torch.ops.aten.sum.dim_IntList(mul_tensor_29, [2, 3], True);  mul_tensor_29 = None
        to_dtype_63 = torch.ops.aten.to.dtype(sum_dim_int_list_5, torch.float32);  sum_dim_int_list_5 = None
        to_dtype_64 = torch.ops.aten.to.dtype(sigmoid_default_8, torch.float32);  sigmoid_default_8 = None
        rsub_scalar_4 = torch.ops.aten.rsub.Scalar(to_dtype_64, 1)
        mul_tensor_31 = torch.ops.aten.mul.Tensor(to_dtype_64, rsub_scalar_4);  to_dtype_64 = rsub_scalar_4 = None
        conj_physical_default_4 = torch.ops.aten.conj_physical.default(mul_tensor_31);  mul_tensor_31 = None
        mul_tensor_32 = torch.ops.aten.mul.Tensor(to_dtype_63, conj_physical_default_4);  to_dtype_63 = conj_physical_default_4 = None
        to_dtype_65 = torch.ops.aten.to.dtype(mul_tensor_32, torch.float32);  mul_tensor_32 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(to_dtype_65, relu__default_27, primals_69, [368], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_65 = primals_69 = None
        getitem_234 = convolution_backward_default_21[0]
        getitem_235 = convolution_backward_default_21[1]
        getitem_236 = convolution_backward_default_21[2];  convolution_backward_default_21 = None
        to_dtype_66 = torch.ops.aten.to.dtype(getitem_234, torch.float32);  getitem_234 = None
        to_dtype_67 = torch.ops.aten.to.dtype(relu__default_27, torch.float32);  relu__default_27 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_67, 0);  to_dtype_67 = None
        new_zeros_default_61 = torch.ops.aten.new_zeros.default(to_dtype_66, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_17, new_zeros_default_61, to_dtype_66);  le_scalar_17 = new_zeros_default_61 = to_dtype_66 = None
        to_dtype_68 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(to_dtype_68, mean_dim_8, primals_67, [92], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_68 = mean_dim_8 = primals_67 = None
        getitem_237 = convolution_backward_default_22[0]
        getitem_238 = convolution_backward_default_22[1]
        getitem_239 = convolution_backward_default_22[2];  convolution_backward_default_22 = None
        expand_default_5 = torch.ops.aten.expand.default(getitem_237, [128, 368, 7, 7]);  getitem_237 = None
        div_scalar_5 = torch.ops.aten.div.Scalar(expand_default_5, 49);  expand_default_5 = None
        add_tensor_65 = torch.ops.aten.add.Tensor(mul_tensor_30, div_scalar_5);  mul_tensor_30 = div_scalar_5 = None
        to_dtype_69 = torch.ops.aten.to.dtype(add_tensor_65, torch.float32);  add_tensor_65 = None
        to_dtype_70 = torch.ops.aten.to.dtype(relu__default_26, torch.float32);  relu__default_26 = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_70, 0);  to_dtype_70 = None
        new_zeros_default_62 = torch.ops.aten.new_zeros.default(to_dtype_69, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_18 = torch.ops.aten.where.self(le_scalar_18, new_zeros_default_62, to_dtype_69);  le_scalar_18 = new_zeros_default_62 = to_dtype_69 = None
        to_dtype_71 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_71, convolution_default_46, primals_253, primals_251, primals_252, getitem_91, getitem_92, True, 1e-05, [True, True, True]);  to_dtype_71 = convolution_default_46 = primals_253 = primals_251 = primals_252 = getitem_91 = getitem_92 = None
        getitem_240 = native_batch_norm_backward_default_13[0]
        getitem_241 = native_batch_norm_backward_default_13[1]
        getitem_242 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(getitem_240, relu__default_25, primals_64, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 46, [True, True, False]);  getitem_240 = primals_64 = None
        getitem_243 = convolution_backward_default_23[0]
        getitem_244 = convolution_backward_default_23[1];  convolution_backward_default_23 = None
        to_dtype_72 = torch.ops.aten.to.dtype(getitem_243, torch.float32);  getitem_243 = None
        to_dtype_73 = torch.ops.aten.to.dtype(relu__default_25, torch.float32);  relu__default_25 = None
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_73, 0);  to_dtype_73 = None
        new_zeros_default_63 = torch.ops.aten.new_zeros.default(to_dtype_72, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_19 = torch.ops.aten.where.self(le_scalar_19, new_zeros_default_63, to_dtype_72);  le_scalar_19 = new_zeros_default_63 = to_dtype_72 = None
        to_dtype_74 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_74, convolution_default_45, primals_248, primals_246, primals_247, getitem_88, getitem_89, True, 1e-05, [True, True, True]);  to_dtype_74 = convolution_default_45 = primals_248 = primals_246 = primals_247 = getitem_88 = getitem_89 = None
        getitem_246 = native_batch_norm_backward_default_14[0]
        getitem_247 = native_batch_norm_backward_default_14[1]
        getitem_248 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_246, relu_default_7, primals_63, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_246 = primals_63 = None
        getitem_249 = convolution_backward_default_24[0]
        getitem_250 = convolution_backward_default_24[1];  convolution_backward_default_24 = None
        add_tensor_66 = torch.ops.aten.add.Tensor(to_dtype_62, getitem_249);  to_dtype_62 = getitem_249 = None
        to_dtype_75 = torch.ops.aten.to.dtype(add_tensor_66, torch.float32);  add_tensor_66 = None
        to_dtype_76 = torch.ops.aten.to.dtype(relu_default_7, torch.float32);  relu_default_7 = None
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_76, 0);  to_dtype_76 = None
        new_zeros_default_64 = torch.ops.aten.new_zeros.default(to_dtype_75, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_20 = torch.ops.aten.where.self(le_scalar_20, new_zeros_default_64, to_dtype_75);  le_scalar_20 = new_zeros_default_64 = to_dtype_75 = None
        to_dtype_77 = torch.ops.aten.to.dtype(where_self_20, torch.float32);  where_self_20 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_77, convolution_default_44, primals_243, primals_241, primals_242, getitem_85, getitem_86, True, 1e-05, [True, True, True]);  convolution_default_44 = primals_243 = primals_241 = primals_242 = getitem_85 = getitem_86 = None
        getitem_252 = native_batch_norm_backward_default_15[0]
        getitem_253 = native_batch_norm_backward_default_15[1]
        getitem_254 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_252, mul_tensor_7, primals_58, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_252 = mul_tensor_7 = primals_58 = None
        getitem_255 = convolution_backward_default_25[0]
        getitem_256 = convolution_backward_default_25[1];  convolution_backward_default_25 = None
        mul_tensor_33 = torch.ops.aten.mul.Tensor(getitem_255, relu__default_23)
        mul_tensor_34 = torch.ops.aten.mul.Tensor(getitem_255, sigmoid_default_7);  getitem_255 = None
        sum_dim_int_list_6 = torch.ops.aten.sum.dim_IntList(mul_tensor_33, [2, 3], True);  mul_tensor_33 = None
        to_dtype_78 = torch.ops.aten.to.dtype(sum_dim_int_list_6, torch.float32);  sum_dim_int_list_6 = None
        to_dtype_79 = torch.ops.aten.to.dtype(sigmoid_default_7, torch.float32);  sigmoid_default_7 = None
        rsub_scalar_5 = torch.ops.aten.rsub.Scalar(to_dtype_79, 1)
        mul_tensor_35 = torch.ops.aten.mul.Tensor(to_dtype_79, rsub_scalar_5);  to_dtype_79 = rsub_scalar_5 = None
        conj_physical_default_5 = torch.ops.aten.conj_physical.default(mul_tensor_35);  mul_tensor_35 = None
        mul_tensor_36 = torch.ops.aten.mul.Tensor(to_dtype_78, conj_physical_default_5);  to_dtype_78 = conj_physical_default_5 = None
        to_dtype_80 = torch.ops.aten.to.dtype(mul_tensor_36, torch.float32);  mul_tensor_36 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(to_dtype_80, relu__default_24, primals_62, [368], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_80 = primals_62 = None
        getitem_258 = convolution_backward_default_26[0]
        getitem_259 = convolution_backward_default_26[1]
        getitem_260 = convolution_backward_default_26[2];  convolution_backward_default_26 = None
        to_dtype_81 = torch.ops.aten.to.dtype(getitem_258, torch.float32);  getitem_258 = None
        to_dtype_82 = torch.ops.aten.to.dtype(relu__default_24, torch.float32);  relu__default_24 = None
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_82, 0);  to_dtype_82 = None
        new_zeros_default_65 = torch.ops.aten.new_zeros.default(to_dtype_81, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_21 = torch.ops.aten.where.self(le_scalar_21, new_zeros_default_65, to_dtype_81);  le_scalar_21 = new_zeros_default_65 = to_dtype_81 = None
        to_dtype_83 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(to_dtype_83, mean_dim_7, primals_60, [92], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_83 = mean_dim_7 = primals_60 = None
        getitem_261 = convolution_backward_default_27[0]
        getitem_262 = convolution_backward_default_27[1]
        getitem_263 = convolution_backward_default_27[2];  convolution_backward_default_27 = None
        expand_default_6 = torch.ops.aten.expand.default(getitem_261, [128, 368, 7, 7]);  getitem_261 = None
        div_scalar_6 = torch.ops.aten.div.Scalar(expand_default_6, 49);  expand_default_6 = None
        add_tensor_67 = torch.ops.aten.add.Tensor(mul_tensor_34, div_scalar_6);  mul_tensor_34 = div_scalar_6 = None
        to_dtype_84 = torch.ops.aten.to.dtype(add_tensor_67, torch.float32);  add_tensor_67 = None
        to_dtype_85 = torch.ops.aten.to.dtype(relu__default_23, torch.float32);  relu__default_23 = None
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_85, 0);  to_dtype_85 = None
        new_zeros_default_66 = torch.ops.aten.new_zeros.default(to_dtype_84, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_22 = torch.ops.aten.where.self(le_scalar_22, new_zeros_default_66, to_dtype_84);  le_scalar_22 = new_zeros_default_66 = to_dtype_84 = None
        to_dtype_86 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_86, convolution_default_41, primals_238, primals_236, primals_237, getitem_82, getitem_83, True, 1e-05, [True, True, True]);  to_dtype_86 = convolution_default_41 = primals_238 = primals_236 = primals_237 = getitem_82 = getitem_83 = None
        getitem_264 = native_batch_norm_backward_default_16[0]
        getitem_265 = native_batch_norm_backward_default_16[1]
        getitem_266 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(getitem_264, relu__default_22, primals_57, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 46, [True, True, False]);  getitem_264 = primals_57 = None
        getitem_267 = convolution_backward_default_28[0]
        getitem_268 = convolution_backward_default_28[1];  convolution_backward_default_28 = None
        to_dtype_87 = torch.ops.aten.to.dtype(getitem_267, torch.float32);  getitem_267 = None
        to_dtype_88 = torch.ops.aten.to.dtype(relu__default_22, torch.float32);  relu__default_22 = None
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_88, 0);  to_dtype_88 = None
        new_zeros_default_67 = torch.ops.aten.new_zeros.default(to_dtype_87, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(le_scalar_23, new_zeros_default_67, to_dtype_87);  le_scalar_23 = new_zeros_default_67 = to_dtype_87 = None
        to_dtype_89 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_89, convolution_default_40, primals_233, primals_231, primals_232, getitem_79, getitem_80, True, 1e-05, [True, True, True]);  to_dtype_89 = convolution_default_40 = primals_233 = primals_231 = primals_232 = getitem_79 = getitem_80 = None
        getitem_270 = native_batch_norm_backward_default_17[0]
        getitem_271 = native_batch_norm_backward_default_17[1]
        getitem_272 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(getitem_270, relu_default_6, primals_56, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_270 = primals_56 = None
        getitem_273 = convolution_backward_default_29[0]
        getitem_274 = convolution_backward_default_29[1];  convolution_backward_default_29 = None
        add_tensor_68 = torch.ops.aten.add.Tensor(to_dtype_77, getitem_273);  to_dtype_77 = getitem_273 = None
        to_dtype_90 = torch.ops.aten.to.dtype(add_tensor_68, torch.float32);  add_tensor_68 = None
        to_dtype_91 = torch.ops.aten.to.dtype(relu_default_6, torch.float32);  relu_default_6 = None
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_91, 0);  to_dtype_91 = None
        new_zeros_default_68 = torch.ops.aten.new_zeros.default(to_dtype_90, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_24 = torch.ops.aten.where.self(le_scalar_24, new_zeros_default_68, to_dtype_90);  le_scalar_24 = new_zeros_default_68 = to_dtype_90 = None
        to_dtype_92 = torch.ops.aten.to.dtype(where_self_24, torch.float32);  where_self_24 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_92, convolution_default_39, primals_228, primals_226, primals_227, getitem_76, getitem_77, True, 1e-05, [True, True, True]);  convolution_default_39 = primals_228 = primals_226 = primals_227 = getitem_76 = getitem_77 = None
        getitem_276 = native_batch_norm_backward_default_18[0]
        getitem_277 = native_batch_norm_backward_default_18[1]
        getitem_278 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_276, relu_default_5, primals_51, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_276 = primals_51 = None
        getitem_279 = convolution_backward_default_30[0]
        getitem_280 = convolution_backward_default_30[1];  convolution_backward_default_30 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_92, convolution_default_38, primals_223, primals_221, primals_222, getitem_73, getitem_74, True, 1e-05, [True, True, True]);  to_dtype_92 = convolution_default_38 = primals_223 = primals_221 = primals_222 = getitem_73 = getitem_74 = None
        getitem_282 = native_batch_norm_backward_default_19[0]
        getitem_283 = native_batch_norm_backward_default_19[1]
        getitem_284 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(getitem_282, mul_tensor_6, primals_50, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_282 = mul_tensor_6 = primals_50 = None
        getitem_285 = convolution_backward_default_31[0]
        getitem_286 = convolution_backward_default_31[1];  convolution_backward_default_31 = None
        mul_tensor_37 = torch.ops.aten.mul.Tensor(getitem_285, relu__default_20)
        mul_tensor_38 = torch.ops.aten.mul.Tensor(getitem_285, sigmoid_default_6);  getitem_285 = None
        sum_dim_int_list_7 = torch.ops.aten.sum.dim_IntList(mul_tensor_37, [2, 3], True);  mul_tensor_37 = None
        to_dtype_93 = torch.ops.aten.to.dtype(sum_dim_int_list_7, torch.float32);  sum_dim_int_list_7 = None
        to_dtype_94 = torch.ops.aten.to.dtype(sigmoid_default_6, torch.float32);  sigmoid_default_6 = None
        rsub_scalar_6 = torch.ops.aten.rsub.Scalar(to_dtype_94, 1)
        mul_tensor_39 = torch.ops.aten.mul.Tensor(to_dtype_94, rsub_scalar_6);  to_dtype_94 = rsub_scalar_6 = None
        conj_physical_default_6 = torch.ops.aten.conj_physical.default(mul_tensor_39);  mul_tensor_39 = None
        mul_tensor_40 = torch.ops.aten.mul.Tensor(to_dtype_93, conj_physical_default_6);  to_dtype_93 = conj_physical_default_6 = None
        to_dtype_95 = torch.ops.aten.to.dtype(mul_tensor_40, torch.float32);  mul_tensor_40 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(to_dtype_95, relu__default_21, primals_55, [368], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_95 = primals_55 = None
        getitem_288 = convolution_backward_default_32[0]
        getitem_289 = convolution_backward_default_32[1]
        getitem_290 = convolution_backward_default_32[2];  convolution_backward_default_32 = None
        to_dtype_96 = torch.ops.aten.to.dtype(getitem_288, torch.float32);  getitem_288 = None
        to_dtype_97 = torch.ops.aten.to.dtype(relu__default_21, torch.float32);  relu__default_21 = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_97, 0);  to_dtype_97 = None
        new_zeros_default_69 = torch.ops.aten.new_zeros.default(to_dtype_96, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_25 = torch.ops.aten.where.self(le_scalar_25, new_zeros_default_69, to_dtype_96);  le_scalar_25 = new_zeros_default_69 = to_dtype_96 = None
        to_dtype_98 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(to_dtype_98, mean_dim_6, primals_53, [38], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_98 = mean_dim_6 = primals_53 = None
        getitem_291 = convolution_backward_default_33[0]
        getitem_292 = convolution_backward_default_33[1]
        getitem_293 = convolution_backward_default_33[2];  convolution_backward_default_33 = None
        expand_default_7 = torch.ops.aten.expand.default(getitem_291, [128, 368, 7, 7]);  getitem_291 = None
        div_scalar_7 = torch.ops.aten.div.Scalar(expand_default_7, 49);  expand_default_7 = None
        add_tensor_69 = torch.ops.aten.add.Tensor(mul_tensor_38, div_scalar_7);  mul_tensor_38 = div_scalar_7 = None
        to_dtype_99 = torch.ops.aten.to.dtype(add_tensor_69, torch.float32);  add_tensor_69 = None
        to_dtype_100 = torch.ops.aten.to.dtype(relu__default_20, torch.float32);  relu__default_20 = None
        le_scalar_26 = torch.ops.aten.le.Scalar(to_dtype_100, 0);  to_dtype_100 = None
        new_zeros_default_70 = torch.ops.aten.new_zeros.default(to_dtype_99, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_26 = torch.ops.aten.where.self(le_scalar_26, new_zeros_default_70, to_dtype_99);  le_scalar_26 = new_zeros_default_70 = to_dtype_99 = None
        to_dtype_101 = torch.ops.aten.to.dtype(where_self_26, torch.float32);  where_self_26 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_101, convolution_default_35, primals_218, primals_216, primals_217, getitem_70, getitem_71, True, 1e-05, [True, True, True]);  to_dtype_101 = convolution_default_35 = primals_218 = primals_216 = primals_217 = getitem_70 = getitem_71 = None
        getitem_294 = native_batch_norm_backward_default_20[0]
        getitem_295 = native_batch_norm_backward_default_20[1]
        getitem_296 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(getitem_294, relu__default_19, primals_49, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 46, [True, True, False]);  getitem_294 = primals_49 = None
        getitem_297 = convolution_backward_default_34[0]
        getitem_298 = convolution_backward_default_34[1];  convolution_backward_default_34 = None
        to_dtype_102 = torch.ops.aten.to.dtype(getitem_297, torch.float32);  getitem_297 = None
        to_dtype_103 = torch.ops.aten.to.dtype(relu__default_19, torch.float32);  relu__default_19 = None
        le_scalar_27 = torch.ops.aten.le.Scalar(to_dtype_103, 0);  to_dtype_103 = None
        new_zeros_default_71 = torch.ops.aten.new_zeros.default(to_dtype_102, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_27 = torch.ops.aten.where.self(le_scalar_27, new_zeros_default_71, to_dtype_102);  le_scalar_27 = new_zeros_default_71 = to_dtype_102 = None
        to_dtype_104 = torch.ops.aten.to.dtype(where_self_27, torch.float32);  where_self_27 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_104, convolution_default_34, primals_213, primals_211, primals_212, getitem_67, getitem_68, True, 1e-05, [True, True, True]);  to_dtype_104 = convolution_default_34 = primals_213 = primals_211 = primals_212 = getitem_67 = getitem_68 = None
        getitem_300 = native_batch_norm_backward_default_21[0]
        getitem_301 = native_batch_norm_backward_default_21[1]
        getitem_302 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_300, relu_default_5, primals_48, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_300 = primals_48 = None
        getitem_303 = convolution_backward_default_35[0]
        getitem_304 = convolution_backward_default_35[1];  convolution_backward_default_35 = None
        add_tensor_70 = torch.ops.aten.add.Tensor(getitem_279, getitem_303);  getitem_279 = getitem_303 = None
        to_dtype_105 = torch.ops.aten.to.dtype(add_tensor_70, torch.float32);  add_tensor_70 = None
        to_dtype_106 = torch.ops.aten.to.dtype(relu_default_5, torch.float32);  relu_default_5 = None
        le_scalar_28 = torch.ops.aten.le.Scalar(to_dtype_106, 0);  to_dtype_106 = None
        new_zeros_default_72 = torch.ops.aten.new_zeros.default(to_dtype_105, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_28 = torch.ops.aten.where.self(le_scalar_28, new_zeros_default_72, to_dtype_105);  le_scalar_28 = new_zeros_default_72 = to_dtype_105 = None
        to_dtype_107 = torch.ops.aten.to.dtype(where_self_28, torch.float32);  where_self_28 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_107, convolution_default_33, primals_208, primals_206, primals_207, getitem_64, getitem_65, True, 1e-05, [True, True, True]);  convolution_default_33 = primals_208 = primals_206 = primals_207 = getitem_64 = getitem_65 = None
        getitem_306 = native_batch_norm_backward_default_22[0]
        getitem_307 = native_batch_norm_backward_default_22[1]
        getitem_308 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(getitem_306, mul_tensor_5, primals_43, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_306 = mul_tensor_5 = primals_43 = None
        getitem_309 = convolution_backward_default_36[0]
        getitem_310 = convolution_backward_default_36[1];  convolution_backward_default_36 = None
        mul_tensor_41 = torch.ops.aten.mul.Tensor(getitem_309, relu__default_17)
        mul_tensor_42 = torch.ops.aten.mul.Tensor(getitem_309, sigmoid_default_5);  getitem_309 = None
        sum_dim_int_list_8 = torch.ops.aten.sum.dim_IntList(mul_tensor_41, [2, 3], True);  mul_tensor_41 = None
        to_dtype_108 = torch.ops.aten.to.dtype(sum_dim_int_list_8, torch.float32);  sum_dim_int_list_8 = None
        to_dtype_109 = torch.ops.aten.to.dtype(sigmoid_default_5, torch.float32);  sigmoid_default_5 = None
        rsub_scalar_7 = torch.ops.aten.rsub.Scalar(to_dtype_109, 1)
        mul_tensor_43 = torch.ops.aten.mul.Tensor(to_dtype_109, rsub_scalar_7);  to_dtype_109 = rsub_scalar_7 = None
        conj_physical_default_7 = torch.ops.aten.conj_physical.default(mul_tensor_43);  mul_tensor_43 = None
        mul_tensor_44 = torch.ops.aten.mul.Tensor(to_dtype_108, conj_physical_default_7);  to_dtype_108 = conj_physical_default_7 = None
        to_dtype_110 = torch.ops.aten.to.dtype(mul_tensor_44, torch.float32);  mul_tensor_44 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(to_dtype_110, relu__default_18, primals_47, [152], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_110 = primals_47 = None
        getitem_312 = convolution_backward_default_37[0]
        getitem_313 = convolution_backward_default_37[1]
        getitem_314 = convolution_backward_default_37[2];  convolution_backward_default_37 = None
        to_dtype_111 = torch.ops.aten.to.dtype(getitem_312, torch.float32);  getitem_312 = None
        to_dtype_112 = torch.ops.aten.to.dtype(relu__default_18, torch.float32);  relu__default_18 = None
        le_scalar_29 = torch.ops.aten.le.Scalar(to_dtype_112, 0);  to_dtype_112 = None
        new_zeros_default_73 = torch.ops.aten.new_zeros.default(to_dtype_111, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_29 = torch.ops.aten.where.self(le_scalar_29, new_zeros_default_73, to_dtype_111);  le_scalar_29 = new_zeros_default_73 = to_dtype_111 = None
        to_dtype_113 = torch.ops.aten.to.dtype(where_self_29, torch.float32);  where_self_29 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(to_dtype_113, mean_dim_5, primals_45, [38], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_113 = mean_dim_5 = primals_45 = None
        getitem_315 = convolution_backward_default_38[0]
        getitem_316 = convolution_backward_default_38[1]
        getitem_317 = convolution_backward_default_38[2];  convolution_backward_default_38 = None
        expand_default_8 = torch.ops.aten.expand.default(getitem_315, [128, 152, 14, 14]);  getitem_315 = None
        div_scalar_8 = torch.ops.aten.div.Scalar(expand_default_8, 196);  expand_default_8 = None
        add_tensor_71 = torch.ops.aten.add.Tensor(mul_tensor_42, div_scalar_8);  mul_tensor_42 = div_scalar_8 = None
        to_dtype_114 = torch.ops.aten.to.dtype(add_tensor_71, torch.float32);  add_tensor_71 = None
        to_dtype_115 = torch.ops.aten.to.dtype(relu__default_17, torch.float32);  relu__default_17 = None
        le_scalar_30 = torch.ops.aten.le.Scalar(to_dtype_115, 0);  to_dtype_115 = None
        new_zeros_default_74 = torch.ops.aten.new_zeros.default(to_dtype_114, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_30 = torch.ops.aten.where.self(le_scalar_30, new_zeros_default_74, to_dtype_114);  le_scalar_30 = new_zeros_default_74 = to_dtype_114 = None
        to_dtype_116 = torch.ops.aten.to.dtype(where_self_30, torch.float32);  where_self_30 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_116, convolution_default_30, primals_203, primals_201, primals_202, getitem_61, getitem_62, True, 1e-05, [True, True, True]);  to_dtype_116 = convolution_default_30 = primals_203 = primals_201 = primals_202 = getitem_61 = getitem_62 = None
        getitem_318 = native_batch_norm_backward_default_23[0]
        getitem_319 = native_batch_norm_backward_default_23[1]
        getitem_320 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(getitem_318, relu__default_16, primals_42, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 19, [True, True, False]);  getitem_318 = primals_42 = None
        getitem_321 = convolution_backward_default_39[0]
        getitem_322 = convolution_backward_default_39[1];  convolution_backward_default_39 = None
        to_dtype_117 = torch.ops.aten.to.dtype(getitem_321, torch.float32);  getitem_321 = None
        to_dtype_118 = torch.ops.aten.to.dtype(relu__default_16, torch.float32);  relu__default_16 = None
        le_scalar_31 = torch.ops.aten.le.Scalar(to_dtype_118, 0);  to_dtype_118 = None
        new_zeros_default_75 = torch.ops.aten.new_zeros.default(to_dtype_117, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_31 = torch.ops.aten.where.self(le_scalar_31, new_zeros_default_75, to_dtype_117);  le_scalar_31 = new_zeros_default_75 = to_dtype_117 = None
        to_dtype_119 = torch.ops.aten.to.dtype(where_self_31, torch.float32);  where_self_31 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_119, convolution_default_29, primals_198, primals_196, primals_197, getitem_58, getitem_59, True, 1e-05, [True, True, True]);  to_dtype_119 = convolution_default_29 = primals_198 = primals_196 = primals_197 = getitem_58 = getitem_59 = None
        getitem_324 = native_batch_norm_backward_default_24[0]
        getitem_325 = native_batch_norm_backward_default_24[1]
        getitem_326 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(getitem_324, relu_default_4, primals_41, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_324 = primals_41 = None
        getitem_327 = convolution_backward_default_40[0]
        getitem_328 = convolution_backward_default_40[1];  convolution_backward_default_40 = None
        add_tensor_72 = torch.ops.aten.add.Tensor(to_dtype_107, getitem_327);  to_dtype_107 = getitem_327 = None
        to_dtype_120 = torch.ops.aten.to.dtype(add_tensor_72, torch.float32);  add_tensor_72 = None
        to_dtype_121 = torch.ops.aten.to.dtype(relu_default_4, torch.float32);  relu_default_4 = None
        le_scalar_32 = torch.ops.aten.le.Scalar(to_dtype_121, 0);  to_dtype_121 = None
        new_zeros_default_76 = torch.ops.aten.new_zeros.default(to_dtype_120, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_32 = torch.ops.aten.where.self(le_scalar_32, new_zeros_default_76, to_dtype_120);  le_scalar_32 = new_zeros_default_76 = to_dtype_120 = None
        to_dtype_122 = torch.ops.aten.to.dtype(where_self_32, torch.float32);  where_self_32 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_122, convolution_default_28, primals_193, primals_191, primals_192, getitem_55, getitem_56, True, 1e-05, [True, True, True]);  convolution_default_28 = primals_193 = primals_191 = primals_192 = getitem_55 = getitem_56 = None
        getitem_330 = native_batch_norm_backward_default_25[0]
        getitem_331 = native_batch_norm_backward_default_25[1]
        getitem_332 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(getitem_330, mul_tensor_4, primals_36, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_330 = mul_tensor_4 = primals_36 = None
        getitem_333 = convolution_backward_default_41[0]
        getitem_334 = convolution_backward_default_41[1];  convolution_backward_default_41 = None
        mul_tensor_45 = torch.ops.aten.mul.Tensor(getitem_333, relu__default_14)
        mul_tensor_46 = torch.ops.aten.mul.Tensor(getitem_333, sigmoid_default_4);  getitem_333 = None
        sum_dim_int_list_9 = torch.ops.aten.sum.dim_IntList(mul_tensor_45, [2, 3], True);  mul_tensor_45 = None
        to_dtype_123 = torch.ops.aten.to.dtype(sum_dim_int_list_9, torch.float32);  sum_dim_int_list_9 = None
        to_dtype_124 = torch.ops.aten.to.dtype(sigmoid_default_4, torch.float32);  sigmoid_default_4 = None
        rsub_scalar_8 = torch.ops.aten.rsub.Scalar(to_dtype_124, 1)
        mul_tensor_47 = torch.ops.aten.mul.Tensor(to_dtype_124, rsub_scalar_8);  to_dtype_124 = rsub_scalar_8 = None
        conj_physical_default_8 = torch.ops.aten.conj_physical.default(mul_tensor_47);  mul_tensor_47 = None
        mul_tensor_48 = torch.ops.aten.mul.Tensor(to_dtype_123, conj_physical_default_8);  to_dtype_123 = conj_physical_default_8 = None
        to_dtype_125 = torch.ops.aten.to.dtype(mul_tensor_48, torch.float32);  mul_tensor_48 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(to_dtype_125, relu__default_15, primals_40, [152], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_125 = primals_40 = None
        getitem_336 = convolution_backward_default_42[0]
        getitem_337 = convolution_backward_default_42[1]
        getitem_338 = convolution_backward_default_42[2];  convolution_backward_default_42 = None
        to_dtype_126 = torch.ops.aten.to.dtype(getitem_336, torch.float32);  getitem_336 = None
        to_dtype_127 = torch.ops.aten.to.dtype(relu__default_15, torch.float32);  relu__default_15 = None
        le_scalar_33 = torch.ops.aten.le.Scalar(to_dtype_127, 0);  to_dtype_127 = None
        new_zeros_default_77 = torch.ops.aten.new_zeros.default(to_dtype_126, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_33 = torch.ops.aten.where.self(le_scalar_33, new_zeros_default_77, to_dtype_126);  le_scalar_33 = new_zeros_default_77 = to_dtype_126 = None
        to_dtype_128 = torch.ops.aten.to.dtype(where_self_33, torch.float32);  where_self_33 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(to_dtype_128, mean_dim_4, primals_38, [38], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_128 = mean_dim_4 = primals_38 = None
        getitem_339 = convolution_backward_default_43[0]
        getitem_340 = convolution_backward_default_43[1]
        getitem_341 = convolution_backward_default_43[2];  convolution_backward_default_43 = None
        expand_default_9 = torch.ops.aten.expand.default(getitem_339, [128, 152, 14, 14]);  getitem_339 = None
        div_scalar_9 = torch.ops.aten.div.Scalar(expand_default_9, 196);  expand_default_9 = None
        add_tensor_73 = torch.ops.aten.add.Tensor(mul_tensor_46, div_scalar_9);  mul_tensor_46 = div_scalar_9 = None
        to_dtype_129 = torch.ops.aten.to.dtype(add_tensor_73, torch.float32);  add_tensor_73 = None
        to_dtype_130 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar_34 = torch.ops.aten.le.Scalar(to_dtype_130, 0);  to_dtype_130 = None
        new_zeros_default_78 = torch.ops.aten.new_zeros.default(to_dtype_129, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_34 = torch.ops.aten.where.self(le_scalar_34, new_zeros_default_78, to_dtype_129);  le_scalar_34 = new_zeros_default_78 = to_dtype_129 = None
        to_dtype_131 = torch.ops.aten.to.dtype(where_self_34, torch.float32);  where_self_34 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_131, convolution_default_25, primals_188, primals_186, primals_187, getitem_52, getitem_53, True, 1e-05, [True, True, True]);  to_dtype_131 = convolution_default_25 = primals_188 = primals_186 = primals_187 = getitem_52 = getitem_53 = None
        getitem_342 = native_batch_norm_backward_default_26[0]
        getitem_343 = native_batch_norm_backward_default_26[1]
        getitem_344 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(getitem_342, relu__default_13, primals_35, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 19, [True, True, False]);  getitem_342 = primals_35 = None
        getitem_345 = convolution_backward_default_44[0]
        getitem_346 = convolution_backward_default_44[1];  convolution_backward_default_44 = None
        to_dtype_132 = torch.ops.aten.to.dtype(getitem_345, torch.float32);  getitem_345 = None
        to_dtype_133 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_35 = torch.ops.aten.le.Scalar(to_dtype_133, 0);  to_dtype_133 = None
        new_zeros_default_79 = torch.ops.aten.new_zeros.default(to_dtype_132, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_35 = torch.ops.aten.where.self(le_scalar_35, new_zeros_default_79, to_dtype_132);  le_scalar_35 = new_zeros_default_79 = to_dtype_132 = None
        to_dtype_134 = torch.ops.aten.to.dtype(where_self_35, torch.float32);  where_self_35 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_134, convolution_default_24, primals_183, primals_181, primals_182, getitem_49, getitem_50, True, 1e-05, [True, True, True]);  to_dtype_134 = convolution_default_24 = primals_183 = primals_181 = primals_182 = getitem_49 = getitem_50 = None
        getitem_348 = native_batch_norm_backward_default_27[0]
        getitem_349 = native_batch_norm_backward_default_27[1]
        getitem_350 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(getitem_348, relu_default_3, primals_34, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_348 = primals_34 = None
        getitem_351 = convolution_backward_default_45[0]
        getitem_352 = convolution_backward_default_45[1];  convolution_backward_default_45 = None
        add_tensor_74 = torch.ops.aten.add.Tensor(to_dtype_122, getitem_351);  to_dtype_122 = getitem_351 = None
        to_dtype_135 = torch.ops.aten.to.dtype(add_tensor_74, torch.float32);  add_tensor_74 = None
        to_dtype_136 = torch.ops.aten.to.dtype(relu_default_3, torch.float32);  relu_default_3 = None
        le_scalar_36 = torch.ops.aten.le.Scalar(to_dtype_136, 0);  to_dtype_136 = None
        new_zeros_default_80 = torch.ops.aten.new_zeros.default(to_dtype_135, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_36 = torch.ops.aten.where.self(le_scalar_36, new_zeros_default_80, to_dtype_135);  le_scalar_36 = new_zeros_default_80 = to_dtype_135 = None
        to_dtype_137 = torch.ops.aten.to.dtype(where_self_36, torch.float32);  where_self_36 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_137, convolution_default_23, primals_178, primals_176, primals_177, getitem_46, getitem_47, True, 1e-05, [True, True, True]);  convolution_default_23 = primals_178 = primals_176 = primals_177 = getitem_46 = getitem_47 = None
        getitem_354 = native_batch_norm_backward_default_28[0]
        getitem_355 = native_batch_norm_backward_default_28[1]
        getitem_356 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(getitem_354, mul_tensor_3, primals_29, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_354 = mul_tensor_3 = primals_29 = None
        getitem_357 = convolution_backward_default_46[0]
        getitem_358 = convolution_backward_default_46[1];  convolution_backward_default_46 = None
        mul_tensor_49 = torch.ops.aten.mul.Tensor(getitem_357, relu__default_11)
        mul_tensor_50 = torch.ops.aten.mul.Tensor(getitem_357, sigmoid_default_3);  getitem_357 = None
        sum_dim_int_list_10 = torch.ops.aten.sum.dim_IntList(mul_tensor_49, [2, 3], True);  mul_tensor_49 = None
        to_dtype_138 = torch.ops.aten.to.dtype(sum_dim_int_list_10, torch.float32);  sum_dim_int_list_10 = None
        to_dtype_139 = torch.ops.aten.to.dtype(sigmoid_default_3, torch.float32);  sigmoid_default_3 = None
        rsub_scalar_9 = torch.ops.aten.rsub.Scalar(to_dtype_139, 1)
        mul_tensor_51 = torch.ops.aten.mul.Tensor(to_dtype_139, rsub_scalar_9);  to_dtype_139 = rsub_scalar_9 = None
        conj_physical_default_9 = torch.ops.aten.conj_physical.default(mul_tensor_51);  mul_tensor_51 = None
        mul_tensor_52 = torch.ops.aten.mul.Tensor(to_dtype_138, conj_physical_default_9);  to_dtype_138 = conj_physical_default_9 = None
        to_dtype_140 = torch.ops.aten.to.dtype(mul_tensor_52, torch.float32);  mul_tensor_52 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(to_dtype_140, relu__default_12, primals_33, [152], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_140 = primals_33 = None
        getitem_360 = convolution_backward_default_47[0]
        getitem_361 = convolution_backward_default_47[1]
        getitem_362 = convolution_backward_default_47[2];  convolution_backward_default_47 = None
        to_dtype_141 = torch.ops.aten.to.dtype(getitem_360, torch.float32);  getitem_360 = None
        to_dtype_142 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_37 = torch.ops.aten.le.Scalar(to_dtype_142, 0);  to_dtype_142 = None
        new_zeros_default_81 = torch.ops.aten.new_zeros.default(to_dtype_141, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_37 = torch.ops.aten.where.self(le_scalar_37, new_zeros_default_81, to_dtype_141);  le_scalar_37 = new_zeros_default_81 = to_dtype_141 = None
        to_dtype_143 = torch.ops.aten.to.dtype(where_self_37, torch.float32);  where_self_37 = None
        convolution_backward_default_48 = torch.ops.aten.convolution_backward.default(to_dtype_143, mean_dim_3, primals_31, [38], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_143 = mean_dim_3 = primals_31 = None
        getitem_363 = convolution_backward_default_48[0]
        getitem_364 = convolution_backward_default_48[1]
        getitem_365 = convolution_backward_default_48[2];  convolution_backward_default_48 = None
        expand_default_10 = torch.ops.aten.expand.default(getitem_363, [128, 152, 14, 14]);  getitem_363 = None
        div_scalar_10 = torch.ops.aten.div.Scalar(expand_default_10, 196);  expand_default_10 = None
        add_tensor_75 = torch.ops.aten.add.Tensor(mul_tensor_50, div_scalar_10);  mul_tensor_50 = div_scalar_10 = None
        to_dtype_144 = torch.ops.aten.to.dtype(add_tensor_75, torch.float32);  add_tensor_75 = None
        to_dtype_145 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_38 = torch.ops.aten.le.Scalar(to_dtype_145, 0);  to_dtype_145 = None
        new_zeros_default_82 = torch.ops.aten.new_zeros.default(to_dtype_144, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_38 = torch.ops.aten.where.self(le_scalar_38, new_zeros_default_82, to_dtype_144);  le_scalar_38 = new_zeros_default_82 = to_dtype_144 = None
        to_dtype_146 = torch.ops.aten.to.dtype(where_self_38, torch.float32);  where_self_38 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_146, convolution_default_20, primals_173, primals_171, primals_172, getitem_43, getitem_44, True, 1e-05, [True, True, True]);  to_dtype_146 = convolution_default_20 = primals_173 = primals_171 = primals_172 = getitem_43 = getitem_44 = None
        getitem_366 = native_batch_norm_backward_default_29[0]
        getitem_367 = native_batch_norm_backward_default_29[1]
        getitem_368 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        convolution_backward_default_49 = torch.ops.aten.convolution_backward.default(getitem_366, relu__default_10, primals_28, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 19, [True, True, False]);  getitem_366 = primals_28 = None
        getitem_369 = convolution_backward_default_49[0]
        getitem_370 = convolution_backward_default_49[1];  convolution_backward_default_49 = None
        to_dtype_147 = torch.ops.aten.to.dtype(getitem_369, torch.float32);  getitem_369 = None
        to_dtype_148 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_39 = torch.ops.aten.le.Scalar(to_dtype_148, 0);  to_dtype_148 = None
        new_zeros_default_83 = torch.ops.aten.new_zeros.default(to_dtype_147, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_39 = torch.ops.aten.where.self(le_scalar_39, new_zeros_default_83, to_dtype_147);  le_scalar_39 = new_zeros_default_83 = to_dtype_147 = None
        to_dtype_149 = torch.ops.aten.to.dtype(where_self_39, torch.float32);  where_self_39 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_149, convolution_default_19, primals_168, primals_166, primals_167, getitem_40, getitem_41, True, 1e-05, [True, True, True]);  to_dtype_149 = convolution_default_19 = primals_168 = primals_166 = primals_167 = getitem_40 = getitem_41 = None
        getitem_372 = native_batch_norm_backward_default_30[0]
        getitem_373 = native_batch_norm_backward_default_30[1]
        getitem_374 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_50 = torch.ops.aten.convolution_backward.default(getitem_372, relu_default_2, primals_27, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_372 = primals_27 = None
        getitem_375 = convolution_backward_default_50[0]
        getitem_376 = convolution_backward_default_50[1];  convolution_backward_default_50 = None
        add_tensor_76 = torch.ops.aten.add.Tensor(to_dtype_137, getitem_375);  to_dtype_137 = getitem_375 = None
        to_dtype_150 = torch.ops.aten.to.dtype(add_tensor_76, torch.float32);  add_tensor_76 = None
        to_dtype_151 = torch.ops.aten.to.dtype(relu_default_2, torch.float32);  relu_default_2 = None
        le_scalar_40 = torch.ops.aten.le.Scalar(to_dtype_151, 0);  to_dtype_151 = None
        new_zeros_default_84 = torch.ops.aten.new_zeros.default(to_dtype_150, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_40 = torch.ops.aten.where.self(le_scalar_40, new_zeros_default_84, to_dtype_150);  le_scalar_40 = new_zeros_default_84 = to_dtype_150 = None
        to_dtype_152 = torch.ops.aten.to.dtype(where_self_40, torch.float32);  where_self_40 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_152, convolution_default_18, primals_163, primals_161, primals_162, getitem_37, getitem_38, True, 1e-05, [True, True, True]);  convolution_default_18 = primals_163 = primals_161 = primals_162 = getitem_37 = getitem_38 = None
        getitem_378 = native_batch_norm_backward_default_31[0]
        getitem_379 = native_batch_norm_backward_default_31[1]
        getitem_380 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        convolution_backward_default_51 = torch.ops.aten.convolution_backward.default(getitem_378, relu_default_1, primals_22, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_378 = primals_22 = None
        getitem_381 = convolution_backward_default_51[0]
        getitem_382 = convolution_backward_default_51[1];  convolution_backward_default_51 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_152, convolution_default_17, primals_158, primals_156, primals_157, getitem_34, getitem_35, True, 1e-05, [True, True, True]);  to_dtype_152 = convolution_default_17 = primals_158 = primals_156 = primals_157 = getitem_34 = getitem_35 = None
        getitem_384 = native_batch_norm_backward_default_32[0]
        getitem_385 = native_batch_norm_backward_default_32[1]
        getitem_386 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        convolution_backward_default_52 = torch.ops.aten.convolution_backward.default(getitem_384, mul_tensor_2, primals_21, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_384 = mul_tensor_2 = primals_21 = None
        getitem_387 = convolution_backward_default_52[0]
        getitem_388 = convolution_backward_default_52[1];  convolution_backward_default_52 = None
        mul_tensor_53 = torch.ops.aten.mul.Tensor(getitem_387, relu__default_8)
        mul_tensor_54 = torch.ops.aten.mul.Tensor(getitem_387, sigmoid_default_2);  getitem_387 = None
        sum_dim_int_list_11 = torch.ops.aten.sum.dim_IntList(mul_tensor_53, [2, 3], True);  mul_tensor_53 = None
        to_dtype_153 = torch.ops.aten.to.dtype(sum_dim_int_list_11, torch.float32);  sum_dim_int_list_11 = None
        to_dtype_154 = torch.ops.aten.to.dtype(sigmoid_default_2, torch.float32);  sigmoid_default_2 = None
        rsub_scalar_10 = torch.ops.aten.rsub.Scalar(to_dtype_154, 1)
        mul_tensor_55 = torch.ops.aten.mul.Tensor(to_dtype_154, rsub_scalar_10);  to_dtype_154 = rsub_scalar_10 = None
        conj_physical_default_10 = torch.ops.aten.conj_physical.default(mul_tensor_55);  mul_tensor_55 = None
        mul_tensor_56 = torch.ops.aten.mul.Tensor(to_dtype_153, conj_physical_default_10);  to_dtype_153 = conj_physical_default_10 = None
        to_dtype_155 = torch.ops.aten.to.dtype(mul_tensor_56, torch.float32);  mul_tensor_56 = None
        convolution_backward_default_53 = torch.ops.aten.convolution_backward.default(to_dtype_155, relu__default_9, primals_26, [152], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_155 = primals_26 = None
        getitem_390 = convolution_backward_default_53[0]
        getitem_391 = convolution_backward_default_53[1]
        getitem_392 = convolution_backward_default_53[2];  convolution_backward_default_53 = None
        to_dtype_156 = torch.ops.aten.to.dtype(getitem_390, torch.float32);  getitem_390 = None
        to_dtype_157 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_41 = torch.ops.aten.le.Scalar(to_dtype_157, 0);  to_dtype_157 = None
        new_zeros_default_85 = torch.ops.aten.new_zeros.default(to_dtype_156, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_41 = torch.ops.aten.where.self(le_scalar_41, new_zeros_default_85, to_dtype_156);  le_scalar_41 = new_zeros_default_85 = to_dtype_156 = None
        to_dtype_158 = torch.ops.aten.to.dtype(where_self_41, torch.float32);  where_self_41 = None
        convolution_backward_default_54 = torch.ops.aten.convolution_backward.default(to_dtype_158, mean_dim_2, primals_24, [14], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_158 = mean_dim_2 = primals_24 = None
        getitem_393 = convolution_backward_default_54[0]
        getitem_394 = convolution_backward_default_54[1]
        getitem_395 = convolution_backward_default_54[2];  convolution_backward_default_54 = None
        expand_default_11 = torch.ops.aten.expand.default(getitem_393, [128, 152, 14, 14]);  getitem_393 = None
        div_scalar_11 = torch.ops.aten.div.Scalar(expand_default_11, 196);  expand_default_11 = None
        add_tensor_77 = torch.ops.aten.add.Tensor(mul_tensor_54, div_scalar_11);  mul_tensor_54 = div_scalar_11 = None
        to_dtype_159 = torch.ops.aten.to.dtype(add_tensor_77, torch.float32);  add_tensor_77 = None
        to_dtype_160 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_42 = torch.ops.aten.le.Scalar(to_dtype_160, 0);  to_dtype_160 = None
        new_zeros_default_86 = torch.ops.aten.new_zeros.default(to_dtype_159, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_42 = torch.ops.aten.where.self(le_scalar_42, new_zeros_default_86, to_dtype_159);  le_scalar_42 = new_zeros_default_86 = to_dtype_159 = None
        to_dtype_161 = torch.ops.aten.to.dtype(where_self_42, torch.float32);  where_self_42 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_161, convolution_default_14, primals_153, primals_151, primals_152, getitem_31, getitem_32, True, 1e-05, [True, True, True]);  to_dtype_161 = convolution_default_14 = primals_153 = primals_151 = primals_152 = getitem_31 = getitem_32 = None
        getitem_396 = native_batch_norm_backward_default_33[0]
        getitem_397 = native_batch_norm_backward_default_33[1]
        getitem_398 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        convolution_backward_default_55 = torch.ops.aten.convolution_backward.default(getitem_396, relu__default_7, primals_20, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 19, [True, True, False]);  getitem_396 = primals_20 = None
        getitem_399 = convolution_backward_default_55[0]
        getitem_400 = convolution_backward_default_55[1];  convolution_backward_default_55 = None
        to_dtype_162 = torch.ops.aten.to.dtype(getitem_399, torch.float32);  getitem_399 = None
        to_dtype_163 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_43 = torch.ops.aten.le.Scalar(to_dtype_163, 0);  to_dtype_163 = None
        new_zeros_default_87 = torch.ops.aten.new_zeros.default(to_dtype_162, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_43 = torch.ops.aten.where.self(le_scalar_43, new_zeros_default_87, to_dtype_162);  le_scalar_43 = new_zeros_default_87 = to_dtype_162 = None
        to_dtype_164 = torch.ops.aten.to.dtype(where_self_43, torch.float32);  where_self_43 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_164, convolution_default_13, primals_148, primals_146, primals_147, getitem_28, getitem_29, True, 1e-05, [True, True, True]);  to_dtype_164 = convolution_default_13 = primals_148 = primals_146 = primals_147 = getitem_28 = getitem_29 = None
        getitem_402 = native_batch_norm_backward_default_34[0]
        getitem_403 = native_batch_norm_backward_default_34[1]
        getitem_404 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        convolution_backward_default_56 = torch.ops.aten.convolution_backward.default(getitem_402, relu_default_1, primals_19, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_402 = primals_19 = None
        getitem_405 = convolution_backward_default_56[0]
        getitem_406 = convolution_backward_default_56[1];  convolution_backward_default_56 = None
        add_tensor_78 = torch.ops.aten.add.Tensor(getitem_381, getitem_405);  getitem_381 = getitem_405 = None
        to_dtype_165 = torch.ops.aten.to.dtype(add_tensor_78, torch.float32);  add_tensor_78 = None
        to_dtype_166 = torch.ops.aten.to.dtype(relu_default_1, torch.float32);  relu_default_1 = None
        le_scalar_44 = torch.ops.aten.le.Scalar(to_dtype_166, 0);  to_dtype_166 = None
        new_zeros_default_88 = torch.ops.aten.new_zeros.default(to_dtype_165, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_44 = torch.ops.aten.where.self(le_scalar_44, new_zeros_default_88, to_dtype_165);  le_scalar_44 = new_zeros_default_88 = to_dtype_165 = None
        to_dtype_167 = torch.ops.aten.to.dtype(where_self_44, torch.float32);  where_self_44 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_167, convolution_default_12, primals_143, primals_141, primals_142, getitem_25, getitem_26, True, 1e-05, [True, True, True]);  convolution_default_12 = primals_143 = primals_141 = primals_142 = getitem_25 = getitem_26 = None
        getitem_408 = native_batch_norm_backward_default_35[0]
        getitem_409 = native_batch_norm_backward_default_35[1]
        getitem_410 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        convolution_backward_default_57 = torch.ops.aten.convolution_backward.default(getitem_408, relu_default, primals_14, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_408 = primals_14 = None
        getitem_411 = convolution_backward_default_57[0]
        getitem_412 = convolution_backward_default_57[1];  convolution_backward_default_57 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_167, convolution_default_11, primals_138, primals_136, primals_137, getitem_22, getitem_23, True, 1e-05, [True, True, True]);  to_dtype_167 = convolution_default_11 = primals_138 = primals_136 = primals_137 = getitem_22 = getitem_23 = None
        getitem_414 = native_batch_norm_backward_default_36[0]
        getitem_415 = native_batch_norm_backward_default_36[1]
        getitem_416 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        convolution_backward_default_58 = torch.ops.aten.convolution_backward.default(getitem_414, mul_tensor_1, primals_13, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_414 = mul_tensor_1 = primals_13 = None
        getitem_417 = convolution_backward_default_58[0]
        getitem_418 = convolution_backward_default_58[1];  convolution_backward_default_58 = None
        mul_tensor_57 = torch.ops.aten.mul.Tensor(getitem_417, relu__default_5)
        mul_tensor_58 = torch.ops.aten.mul.Tensor(getitem_417, sigmoid_default_1);  getitem_417 = None
        sum_dim_int_list_12 = torch.ops.aten.sum.dim_IntList(mul_tensor_57, [2, 3], True);  mul_tensor_57 = None
        to_dtype_168 = torch.ops.aten.to.dtype(sum_dim_int_list_12, torch.float32);  sum_dim_int_list_12 = None
        to_dtype_169 = torch.ops.aten.to.dtype(sigmoid_default_1, torch.float32);  sigmoid_default_1 = None
        rsub_scalar_11 = torch.ops.aten.rsub.Scalar(to_dtype_169, 1)
        mul_tensor_59 = torch.ops.aten.mul.Tensor(to_dtype_169, rsub_scalar_11);  to_dtype_169 = rsub_scalar_11 = None
        conj_physical_default_11 = torch.ops.aten.conj_physical.default(mul_tensor_59);  mul_tensor_59 = None
        mul_tensor_60 = torch.ops.aten.mul.Tensor(to_dtype_168, conj_physical_default_11);  to_dtype_168 = conj_physical_default_11 = None
        to_dtype_170 = torch.ops.aten.to.dtype(mul_tensor_60, torch.float32);  mul_tensor_60 = None
        convolution_backward_default_59 = torch.ops.aten.convolution_backward.default(to_dtype_170, relu__default_6, primals_18, [56], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_170 = primals_18 = None
        getitem_420 = convolution_backward_default_59[0]
        getitem_421 = convolution_backward_default_59[1]
        getitem_422 = convolution_backward_default_59[2];  convolution_backward_default_59 = None
        to_dtype_171 = torch.ops.aten.to.dtype(getitem_420, torch.float32);  getitem_420 = None
        to_dtype_172 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_45 = torch.ops.aten.le.Scalar(to_dtype_172, 0);  to_dtype_172 = None
        new_zeros_default_89 = torch.ops.aten.new_zeros.default(to_dtype_171, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_45 = torch.ops.aten.where.self(le_scalar_45, new_zeros_default_89, to_dtype_171);  le_scalar_45 = new_zeros_default_89 = to_dtype_171 = None
        to_dtype_173 = torch.ops.aten.to.dtype(where_self_45, torch.float32);  where_self_45 = None
        convolution_backward_default_60 = torch.ops.aten.convolution_backward.default(to_dtype_173, mean_dim_1, primals_16, [6], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_173 = mean_dim_1 = primals_16 = None
        getitem_423 = convolution_backward_default_60[0]
        getitem_424 = convolution_backward_default_60[1]
        getitem_425 = convolution_backward_default_60[2];  convolution_backward_default_60 = None
        expand_default_12 = torch.ops.aten.expand.default(getitem_423, [128, 56, 28, 28]);  getitem_423 = None
        div_scalar_12 = torch.ops.aten.div.Scalar(expand_default_12, 784);  expand_default_12 = None
        add_tensor_79 = torch.ops.aten.add.Tensor(mul_tensor_58, div_scalar_12);  mul_tensor_58 = div_scalar_12 = None
        to_dtype_174 = torch.ops.aten.to.dtype(add_tensor_79, torch.float32);  add_tensor_79 = None
        to_dtype_175 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_46 = torch.ops.aten.le.Scalar(to_dtype_175, 0);  to_dtype_175 = None
        new_zeros_default_90 = torch.ops.aten.new_zeros.default(to_dtype_174, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_46 = torch.ops.aten.where.self(le_scalar_46, new_zeros_default_90, to_dtype_174);  le_scalar_46 = new_zeros_default_90 = to_dtype_174 = None
        to_dtype_176 = torch.ops.aten.to.dtype(where_self_46, torch.float32);  where_self_46 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_176, convolution_default_8, primals_133, primals_131, primals_132, getitem_19, getitem_20, True, 1e-05, [True, True, True]);  to_dtype_176 = convolution_default_8 = primals_133 = primals_131 = primals_132 = getitem_19 = getitem_20 = None
        getitem_426 = native_batch_norm_backward_default_37[0]
        getitem_427 = native_batch_norm_backward_default_37[1]
        getitem_428 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        convolution_backward_default_61 = torch.ops.aten.convolution_backward.default(getitem_426, relu__default_4, primals_12, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 7, [True, True, False]);  getitem_426 = primals_12 = None
        getitem_429 = convolution_backward_default_61[0]
        getitem_430 = convolution_backward_default_61[1];  convolution_backward_default_61 = None
        to_dtype_177 = torch.ops.aten.to.dtype(getitem_429, torch.float32);  getitem_429 = None
        to_dtype_178 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_47 = torch.ops.aten.le.Scalar(to_dtype_178, 0);  to_dtype_178 = None
        new_zeros_default_91 = torch.ops.aten.new_zeros.default(to_dtype_177, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_47 = torch.ops.aten.where.self(le_scalar_47, new_zeros_default_91, to_dtype_177);  le_scalar_47 = new_zeros_default_91 = to_dtype_177 = None
        to_dtype_179 = torch.ops.aten.to.dtype(where_self_47, torch.float32);  where_self_47 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_179, convolution_default_7, primals_128, primals_126, primals_127, getitem_16, getitem_17, True, 1e-05, [True, True, True]);  to_dtype_179 = convolution_default_7 = primals_128 = primals_126 = primals_127 = getitem_16 = getitem_17 = None
        getitem_432 = native_batch_norm_backward_default_38[0]
        getitem_433 = native_batch_norm_backward_default_38[1]
        getitem_434 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        convolution_backward_default_62 = torch.ops.aten.convolution_backward.default(getitem_432, relu_default, primals_11, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_432 = primals_11 = None
        getitem_435 = convolution_backward_default_62[0]
        getitem_436 = convolution_backward_default_62[1];  convolution_backward_default_62 = None
        add_tensor_80 = torch.ops.aten.add.Tensor(getitem_411, getitem_435);  getitem_411 = getitem_435 = None
        to_dtype_180 = torch.ops.aten.to.dtype(add_tensor_80, torch.float32);  add_tensor_80 = None
        to_dtype_181 = torch.ops.aten.to.dtype(relu_default, torch.float32);  relu_default = None
        le_scalar_48 = torch.ops.aten.le.Scalar(to_dtype_181, 0);  to_dtype_181 = None
        new_zeros_default_92 = torch.ops.aten.new_zeros.default(to_dtype_180, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_48 = torch.ops.aten.where.self(le_scalar_48, new_zeros_default_92, to_dtype_180);  le_scalar_48 = new_zeros_default_92 = to_dtype_180 = None
        to_dtype_182 = torch.ops.aten.to.dtype(where_self_48, torch.float32);  where_self_48 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_182, convolution_default_6, primals_123, primals_121, primals_122, getitem_13, getitem_14, True, 1e-05, [True, True, True]);  convolution_default_6 = primals_123 = primals_121 = primals_122 = getitem_13 = getitem_14 = None
        getitem_438 = native_batch_norm_backward_default_39[0]
        getitem_439 = native_batch_norm_backward_default_39[1]
        getitem_440 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        convolution_backward_default_63 = torch.ops.aten.convolution_backward.default(getitem_438, relu__default, primals_6, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_438 = primals_6 = None
        getitem_441 = convolution_backward_default_63[0]
        getitem_442 = convolution_backward_default_63[1];  convolution_backward_default_63 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_182, convolution_default_5, primals_118, primals_116, primals_117, getitem_10, getitem_11, True, 1e-05, [True, True, True]);  to_dtype_182 = convolution_default_5 = primals_118 = primals_116 = primals_117 = getitem_10 = getitem_11 = None
        getitem_444 = native_batch_norm_backward_default_40[0]
        getitem_445 = native_batch_norm_backward_default_40[1]
        getitem_446 = native_batch_norm_backward_default_40[2];  native_batch_norm_backward_default_40 = None
        convolution_backward_default_64 = torch.ops.aten.convolution_backward.default(getitem_444, mul_tensor, primals_5, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_444 = mul_tensor = primals_5 = None
        getitem_447 = convolution_backward_default_64[0]
        getitem_448 = convolution_backward_default_64[1];  convolution_backward_default_64 = None
        mul_tensor_61 = torch.ops.aten.mul.Tensor(getitem_447, relu__default_2)
        mul_tensor_62 = torch.ops.aten.mul.Tensor(getitem_447, sigmoid_default);  getitem_447 = None
        sum_dim_int_list_13 = torch.ops.aten.sum.dim_IntList(mul_tensor_61, [2, 3], True);  mul_tensor_61 = None
        to_dtype_183 = torch.ops.aten.to.dtype(sum_dim_int_list_13, torch.float32);  sum_dim_int_list_13 = None
        to_dtype_184 = torch.ops.aten.to.dtype(sigmoid_default, torch.float32);  sigmoid_default = None
        rsub_scalar_12 = torch.ops.aten.rsub.Scalar(to_dtype_184, 1)
        mul_tensor_63 = torch.ops.aten.mul.Tensor(to_dtype_184, rsub_scalar_12);  to_dtype_184 = rsub_scalar_12 = None
        conj_physical_default_12 = torch.ops.aten.conj_physical.default(mul_tensor_63);  mul_tensor_63 = None
        mul_tensor_64 = torch.ops.aten.mul.Tensor(to_dtype_183, conj_physical_default_12);  to_dtype_183 = conj_physical_default_12 = None
        to_dtype_185 = torch.ops.aten.to.dtype(mul_tensor_64, torch.float32);  mul_tensor_64 = None
        convolution_backward_default_65 = torch.ops.aten.convolution_backward.default(to_dtype_185, relu__default_3, primals_10, [24], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_185 = primals_10 = None
        getitem_450 = convolution_backward_default_65[0]
        getitem_451 = convolution_backward_default_65[1]
        getitem_452 = convolution_backward_default_65[2];  convolution_backward_default_65 = None
        to_dtype_186 = torch.ops.aten.to.dtype(getitem_450, torch.float32);  getitem_450 = None
        to_dtype_187 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_49 = torch.ops.aten.le.Scalar(to_dtype_187, 0);  to_dtype_187 = None
        new_zeros_default_93 = torch.ops.aten.new_zeros.default(to_dtype_186, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_49 = torch.ops.aten.where.self(le_scalar_49, new_zeros_default_93, to_dtype_186);  le_scalar_49 = new_zeros_default_93 = to_dtype_186 = None
        to_dtype_188 = torch.ops.aten.to.dtype(where_self_49, torch.float32);  where_self_49 = None
        convolution_backward_default_66 = torch.ops.aten.convolution_backward.default(to_dtype_188, mean_dim, primals_8, [8], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_188 = mean_dim = primals_8 = None
        getitem_453 = convolution_backward_default_66[0]
        getitem_454 = convolution_backward_default_66[1]
        getitem_455 = convolution_backward_default_66[2];  convolution_backward_default_66 = None
        expand_default_13 = torch.ops.aten.expand.default(getitem_453, [128, 24, 56, 56]);  getitem_453 = None
        div_scalar_13 = torch.ops.aten.div.Scalar(expand_default_13, 3136);  expand_default_13 = None
        add_tensor_81 = torch.ops.aten.add.Tensor(mul_tensor_62, div_scalar_13);  mul_tensor_62 = div_scalar_13 = None
        to_dtype_189 = torch.ops.aten.to.dtype(add_tensor_81, torch.float32);  add_tensor_81 = None
        to_dtype_190 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_50 = torch.ops.aten.le.Scalar(to_dtype_190, 0);  to_dtype_190 = None
        new_zeros_default_94 = torch.ops.aten.new_zeros.default(to_dtype_189, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_50 = torch.ops.aten.where.self(le_scalar_50, new_zeros_default_94, to_dtype_189);  le_scalar_50 = new_zeros_default_94 = to_dtype_189 = None
        to_dtype_191 = torch.ops.aten.to.dtype(where_self_50, torch.float32);  where_self_50 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_191, convolution_default_2, primals_113, primals_111, primals_112, getitem_7, getitem_8, True, 1e-05, [True, True, True]);  to_dtype_191 = convolution_default_2 = primals_113 = primals_111 = primals_112 = getitem_7 = getitem_8 = None
        getitem_456 = native_batch_norm_backward_default_41[0]
        getitem_457 = native_batch_norm_backward_default_41[1]
        getitem_458 = native_batch_norm_backward_default_41[2];  native_batch_norm_backward_default_41 = None
        convolution_backward_default_67 = torch.ops.aten.convolution_backward.default(getitem_456, relu__default_1, primals_4, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 3, [True, True, False]);  getitem_456 = primals_4 = None
        getitem_459 = convolution_backward_default_67[0]
        getitem_460 = convolution_backward_default_67[1];  convolution_backward_default_67 = None
        to_dtype_192 = torch.ops.aten.to.dtype(getitem_459, torch.float32);  getitem_459 = None
        to_dtype_193 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_51 = torch.ops.aten.le.Scalar(to_dtype_193, 0);  to_dtype_193 = None
        new_zeros_default_95 = torch.ops.aten.new_zeros.default(to_dtype_192, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_51 = torch.ops.aten.where.self(le_scalar_51, new_zeros_default_95, to_dtype_192);  le_scalar_51 = new_zeros_default_95 = to_dtype_192 = None
        to_dtype_194 = torch.ops.aten.to.dtype(where_self_51, torch.float32);  where_self_51 = None
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_194, convolution_default_1, primals_108, primals_106, primals_107, getitem_4, getitem_5, True, 1e-05, [True, True, True]);  to_dtype_194 = convolution_default_1 = primals_108 = primals_106 = primals_107 = getitem_4 = getitem_5 = None
        getitem_462 = native_batch_norm_backward_default_42[0]
        getitem_463 = native_batch_norm_backward_default_42[1]
        getitem_464 = native_batch_norm_backward_default_42[2];  native_batch_norm_backward_default_42 = None
        convolution_backward_default_68 = torch.ops.aten.convolution_backward.default(getitem_462, relu__default, primals_3, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_462 = primals_3 = None
        getitem_465 = convolution_backward_default_68[0]
        getitem_466 = convolution_backward_default_68[1];  convolution_backward_default_68 = None
        add_tensor_82 = torch.ops.aten.add.Tensor(getitem_441, getitem_465);  getitem_441 = getitem_465 = None
        to_dtype_195 = torch.ops.aten.to.dtype(add_tensor_82, torch.float32);  add_tensor_82 = None
        to_dtype_196 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_52 = torch.ops.aten.le.Scalar(to_dtype_196, 0);  to_dtype_196 = None
        new_zeros_default_96 = torch.ops.aten.new_zeros.default(to_dtype_195, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_52 = torch.ops.aten.where.self(le_scalar_52, new_zeros_default_96, to_dtype_195);  le_scalar_52 = new_zeros_default_96 = to_dtype_195 = None
        to_dtype_197 = torch.ops.aten.to.dtype(where_self_52, torch.float32);  where_self_52 = None
        native_batch_norm_backward_default_43 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_197, convolution_default, primals_103, primals_101, primals_102, getitem_1, getitem_2, True, 1e-05, [True, True, True]);  to_dtype_197 = convolution_default = primals_103 = primals_101 = primals_102 = getitem_1 = getitem_2 = None
        getitem_468 = native_batch_norm_backward_default_43[0]
        getitem_469 = native_batch_norm_backward_default_43[1]
        getitem_470 = native_batch_norm_backward_default_43[2];  native_batch_norm_backward_default_43 = None
        convolution_backward_default_69 = torch.ops.aten.convolution_backward.default(getitem_468, primals_99, primals_98, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_468 = primals_99 = primals_98 = None
        getitem_472 = convolution_backward_default_69[1];  convolution_backward_default_69 = None
        return [view_default_1, t_default_4, getitem_466, getitem_460, getitem_448, getitem_442, getitem_455, getitem_454, getitem_452, getitem_451, getitem_436, getitem_430, getitem_418, getitem_412, getitem_425, getitem_424, getitem_422, getitem_421, getitem_406, getitem_400, getitem_388, getitem_382, getitem_395, getitem_394, getitem_392, getitem_391, getitem_376, getitem_370, getitem_358, getitem_365, getitem_364, getitem_362, getitem_361, getitem_352, getitem_346, getitem_334, getitem_341, getitem_340, getitem_338, getitem_337, getitem_328, getitem_322, getitem_310, getitem_317, getitem_316, getitem_314, getitem_313, getitem_304, getitem_298, getitem_286, getitem_280, getitem_293, getitem_292, getitem_290, getitem_289, getitem_274, getitem_268, getitem_256, getitem_263, getitem_262, getitem_260, getitem_259, getitem_250, getitem_244, getitem_232, getitem_239, getitem_238, getitem_236, getitem_235, getitem_226, getitem_220, getitem_208, getitem_215, getitem_214, getitem_212, getitem_211, getitem_202, getitem_196, getitem_184, getitem_191, getitem_190, getitem_188, getitem_187, getitem_178, getitem_172, getitem_160, getitem_167, getitem_166, getitem_164, getitem_163, getitem_154, getitem_148, getitem_136, getitem_143, getitem_142, getitem_140, getitem_139, getitem_472, None, None, None, None, getitem_469, getitem_470, None, None, None, getitem_463, getitem_464, None, None, None, getitem_457, getitem_458, None, None, None, getitem_445, getitem_446, None, None, None, getitem_439, getitem_440, None, None, None, getitem_433, getitem_434, None, None, None, getitem_427, getitem_428, None, None, None, getitem_415, getitem_416, None, None, None, getitem_409, getitem_410, None, None, None, getitem_403, getitem_404, None, None, None, getitem_397, getitem_398, None, None, None, getitem_385, getitem_386, None, None, None, getitem_379, getitem_380, None, None, None, getitem_373, getitem_374, None, None, None, getitem_367, getitem_368, None, None, None, getitem_355, getitem_356, None, None, None, getitem_349, getitem_350, None, None, None, getitem_343, getitem_344, None, None, None, getitem_331, getitem_332, None, None, None, getitem_325, getitem_326, None, None, None, getitem_319, getitem_320, None, None, None, getitem_307, getitem_308, None, None, None, getitem_301, getitem_302, None, None, None, getitem_295, getitem_296, None, None, None, getitem_283, getitem_284, None, None, None, getitem_277, getitem_278, None, None, None, getitem_271, getitem_272, None, None, None, getitem_265, getitem_266, None, None, None, getitem_253, getitem_254, None, None, None, getitem_247, getitem_248, None, None, None, getitem_241, getitem_242, None, None, None, getitem_229, getitem_230, None, None, None, getitem_223, getitem_224, None, None, None, getitem_217, getitem_218, None, None, None, getitem_205, getitem_206, None, None, None, getitem_199, getitem_200, None, None, None, getitem_193, getitem_194, None, None, None, getitem_181, getitem_182, None, None, None, getitem_175, getitem_176, None, None, None, getitem_169, getitem_170, None, None, None, getitem_157, getitem_158, None, None, None, getitem_151, getitem_152, None, None, None, getitem_145, getitem_146, None, None, None, getitem_133, getitem_134]
        
