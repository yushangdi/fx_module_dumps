
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/tf_inception_v3/tf_inception_v3_joint_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339, primals_340, primals_341, primals_342, primals_343, primals_344, primals_345, primals_346, primals_347, primals_348, primals_349, primals_350, primals_351, primals_352, primals_353, primals_354, primals_355, primals_356, primals_357, primals_358, primals_359, primals_360, primals_361, primals_362, primals_363, primals_364, primals_365, primals_366, primals_367, primals_368, primals_369, primals_370, primals_371, primals_372, primals_373, primals_374, primals_375, primals_376, primals_377, primals_378, primals_379, primals_380, primals_381, primals_382, primals_383, primals_384, primals_385, primals_386, primals_387, primals_388, primals_389, primals_390, primals_391, primals_392, primals_393, primals_394, primals_395, primals_396, primals_397, primals_398, primals_399, primals_400, primals_401, primals_402, primals_403, primals_404, primals_405, primals_406, primals_407, primals_408, primals_409, primals_410, primals_411, primals_412, primals_413, primals_414, primals_415, primals_416, primals_417, primals_418, primals_419, primals_420, primals_421, primals_422, primals_423, primals_424, primals_425, primals_426, primals_427, primals_428, primals_429, primals_430, primals_431, primals_432, primals_433, primals_434, primals_435, primals_436, primals_437, primals_438, primals_439, primals_440, primals_441, primals_442, primals_443, primals_444, primals_445, primals_446, primals_447, primals_448, primals_449, primals_450, primals_451, primals_452, primals_453, primals_454, primals_455, primals_456, primals_457, primals_458, primals_459, primals_460, primals_461, primals_462, primals_463, primals_464, primals_465, primals_466, primals_467, primals_468, primals_469, primals_470, primals_471, primals_472, primals_473, primals_474, primals_475, primals_476, primals_477, primals_478, primals_479, primals_480, primals_481, primals_482, primals_483, primals_484, primals_485, primals_486, primals_487, primals_488, primals_489, primals_490, primals_491, primals_492, primals_493, primals_494, primals_495, primals_496, primals_497, primals_498, primals_499, primals_500, primals_501, primals_502, primals_503, primals_504, primals_505, primals_506, primals_507, primals_508, primals_509, primals_510, primals_511, primals_512, primals_513, primals_514, primals_515, primals_516, primals_517, primals_518, primals_519, primals_520, primals_521, primals_522, primals_523, primals_524, primals_525, primals_526, primals_527, primals_528, primals_529, primals_530, primals_531, primals_532, primals_533, primals_534, primals_535, primals_536, primals_537, primals_538, primals_539, primals_540, primals_541, primals_542, primals_543, primals_544, primals_545, primals_546, primals_547, primals_548, primals_549, primals_550, primals_551, primals_552, primals_553, primals_554, primals_555, primals_556, primals_557, primals_558, primals_559, primals_560, primals_561, primals_562, primals_563, primals_564, primals_565, primals_566, primals_567, tangents_1):
        convolution_default = torch.ops.aten.convolution.default(primals_567, primals_6, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor = torch.ops.aten.add_.Tensor(primals_2, 1);  primals_2 = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_5, primals_1, primals_3, primals_4, True, 0.1, 0.001);  primals_1 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        new_zeros_default = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default, primals_12, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_1 = torch.ops.aten.add_.Tensor(primals_8, 1);  primals_8 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_11, primals_7, primals_9, primals_10, True, 0.1, 0.001);  primals_7 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_1 = torch.ops.aten.relu_.default(getitem_3);  getitem_3 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_18, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_2 = torch.ops.aten.add_.Tensor(primals_14, 1);  primals_14 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_17, primals_13, primals_15, primals_16, True, 0.1, 0.001);  primals_13 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        new_zeros_default_2 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_2 = torch.ops.aten.relu_.default(getitem_6);  getitem_6 = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu__default_2, [3, 3], [2, 2])
        getitem_9 = max_pool2d_with_indices_default[0]
        getitem_10 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_3 = torch.ops.aten.convolution.default(getitem_9, primals_24, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_3 = torch.ops.aten.add_.Tensor(primals_20, 1);  primals_20 = None
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_23, primals_19, primals_21, primals_22, True, 0.1, 0.001);  primals_19 = None
        getitem_11 = native_batch_norm_default_3[0]
        getitem_12 = native_batch_norm_default_3[1]
        getitem_13 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_3 = torch.ops.aten.relu_.default(getitem_11);  getitem_11 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu__default_3, primals_30, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_4 = torch.ops.aten.add_.Tensor(primals_26, 1);  primals_26 = None
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_29, primals_25, primals_27, primals_28, True, 0.1, 0.001);  primals_25 = None
        getitem_14 = native_batch_norm_default_4[0]
        getitem_15 = native_batch_norm_default_4[1]
        getitem_16 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_4 = torch.ops.aten.relu_.default(getitem_14);  getitem_14 = None
        max_pool2d_with_indices_default_1 = torch.ops.aten.max_pool2d_with_indices.default(relu__default_4, [3, 3], [2, 2])
        getitem_17 = max_pool2d_with_indices_default_1[0]
        getitem_18 = max_pool2d_with_indices_default_1[1];  max_pool2d_with_indices_default_1 = None
        convolution_default_5 = torch.ops.aten.convolution.default(getitem_17, primals_36, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_5 = torch.ops.aten.add_.Tensor(primals_32, 1);  primals_32 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_35, primals_31, primals_33, primals_34, True, 0.1, 0.001);  primals_31 = None
        getitem_19 = native_batch_norm_default_5[0]
        getitem_20 = native_batch_norm_default_5[1]
        getitem_21 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        new_zeros_default_5 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_5 = torch.ops.aten.relu_.default(getitem_19);  getitem_19 = None
        convolution_default_6 = torch.ops.aten.convolution.default(getitem_17, primals_60, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_6 = torch.ops.aten.add_.Tensor(primals_56, 1);  primals_56 = None
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_59, primals_55, primals_57, primals_58, True, 0.1, 0.001);  primals_55 = None
        getitem_22 = native_batch_norm_default_6[0]
        getitem_23 = native_batch_norm_default_6[1]
        getitem_24 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(convolution_default_6, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_6 = torch.ops.aten.relu_.default(getitem_22);  getitem_22 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_6, primals_66, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 1)
        add__tensor_7 = torch.ops.aten.add_.Tensor(primals_62, 1);  primals_62 = None
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_65, primals_61, primals_63, primals_64, True, 0.1, 0.001);  primals_61 = None
        getitem_25 = native_batch_norm_default_7[0]
        getitem_26 = native_batch_norm_default_7[1]
        getitem_27 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(convolution_default_7, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_7 = torch.ops.aten.relu_.default(getitem_25);  getitem_25 = None
        convolution_default_8 = torch.ops.aten.convolution.default(getitem_17, primals_42, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_8 = torch.ops.aten.add_.Tensor(primals_38, 1);  primals_38 = None
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_41, primals_37, primals_39, primals_40, True, 0.1, 0.001);  primals_37 = None
        getitem_28 = native_batch_norm_default_8[0]
        getitem_29 = native_batch_norm_default_8[1]
        getitem_30 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        new_zeros_default_8 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_8 = torch.ops.aten.relu_.default(getitem_28);  getitem_28 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_8, primals_48, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_9 = torch.ops.aten.add_.Tensor(primals_44, 1);  primals_44 = None
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_47, primals_43, primals_45, primals_46, True, 0.1, 0.001);  primals_43 = None
        getitem_31 = native_batch_norm_default_9[0]
        getitem_32 = native_batch_norm_default_9[1]
        getitem_33 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        new_zeros_default_9 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_9 = torch.ops.aten.relu_.default(getitem_31);  getitem_31 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default_9, primals_54, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_10 = torch.ops.aten.add_.Tensor(primals_50, 1);  primals_50 = None
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_53, primals_49, primals_51, primals_52, True, 0.1, 0.001);  primals_49 = None
        getitem_34 = native_batch_norm_default_10[0]
        getitem_35 = native_batch_norm_default_10[1]
        getitem_36 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        new_zeros_default_10 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_10 = torch.ops.aten.relu_.default(getitem_34);  getitem_34 = None
        avg_pool2d_default = torch.ops.aten.avg_pool2d.default(getitem_17, [3, 3], [1, 1], [1, 1])
        convolution_default_11 = torch.ops.aten.convolution.default(avg_pool2d_default, primals_72, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_11 = torch.ops.aten.add_.Tensor(primals_68, 1);  primals_68 = None
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_71, primals_67, primals_69, primals_70, True, 0.1, 0.001);  primals_67 = None
        getitem_37 = native_batch_norm_default_11[0]
        getitem_38 = native_batch_norm_default_11[1]
        getitem_39 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        new_zeros_default_11 = torch.ops.aten.new_zeros.default(convolution_default_11, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_11 = torch.ops.aten.relu_.default(getitem_37);  getitem_37 = None
        cat_default = torch.ops.aten.cat.default([relu__default_5, relu__default_7, relu__default_10, relu__default_11], 1)
        convolution_default_12 = torch.ops.aten.convolution.default(cat_default, primals_78, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_12 = torch.ops.aten.add_.Tensor(primals_74, 1);  primals_74 = None
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_77, primals_73, primals_75, primals_76, True, 0.1, 0.001);  primals_73 = None
        getitem_40 = native_batch_norm_default_12[0]
        getitem_41 = native_batch_norm_default_12[1]
        getitem_42 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        new_zeros_default_12 = torch.ops.aten.new_zeros.default(convolution_default_12, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_12 = torch.ops.aten.relu_.default(getitem_40);  getitem_40 = None
        convolution_default_13 = torch.ops.aten.convolution.default(cat_default, primals_102, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_13 = torch.ops.aten.add_.Tensor(primals_98, 1);  primals_98 = None
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_101, primals_97, primals_99, primals_100, True, 0.1, 0.001);  primals_97 = None
        getitem_43 = native_batch_norm_default_13[0]
        getitem_44 = native_batch_norm_default_13[1]
        getitem_45 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        new_zeros_default_13 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_13 = torch.ops.aten.relu_.default(getitem_43);  getitem_43 = None
        convolution_default_14 = torch.ops.aten.convolution.default(relu__default_13, primals_108, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 1)
        add__tensor_14 = torch.ops.aten.add_.Tensor(primals_104, 1);  primals_104 = None
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_107, primals_103, primals_105, primals_106, True, 0.1, 0.001);  primals_103 = None
        getitem_46 = native_batch_norm_default_14[0]
        getitem_47 = native_batch_norm_default_14[1]
        getitem_48 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        new_zeros_default_14 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_14 = torch.ops.aten.relu_.default(getitem_46);  getitem_46 = None
        convolution_default_15 = torch.ops.aten.convolution.default(cat_default, primals_84, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_15 = torch.ops.aten.add_.Tensor(primals_80, 1);  primals_80 = None
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_83, primals_79, primals_81, primals_82, True, 0.1, 0.001);  primals_79 = None
        getitem_49 = native_batch_norm_default_15[0]
        getitem_50 = native_batch_norm_default_15[1]
        getitem_51 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        new_zeros_default_15 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_15 = torch.ops.aten.relu_.default(getitem_49);  getitem_49 = None
        convolution_default_16 = torch.ops.aten.convolution.default(relu__default_15, primals_90, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_16 = torch.ops.aten.add_.Tensor(primals_86, 1);  primals_86 = None
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_89, primals_85, primals_87, primals_88, True, 0.1, 0.001);  primals_85 = None
        getitem_52 = native_batch_norm_default_16[0]
        getitem_53 = native_batch_norm_default_16[1]
        getitem_54 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        new_zeros_default_16 = torch.ops.aten.new_zeros.default(convolution_default_16, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_16 = torch.ops.aten.relu_.default(getitem_52);  getitem_52 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu__default_16, primals_96, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_17 = torch.ops.aten.add_.Tensor(primals_92, 1);  primals_92 = None
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_95, primals_91, primals_93, primals_94, True, 0.1, 0.001);  primals_91 = None
        getitem_55 = native_batch_norm_default_17[0]
        getitem_56 = native_batch_norm_default_17[1]
        getitem_57 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        new_zeros_default_17 = torch.ops.aten.new_zeros.default(convolution_default_17, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_17 = torch.ops.aten.relu_.default(getitem_55);  getitem_55 = None
        avg_pool2d_default_1 = torch.ops.aten.avg_pool2d.default(cat_default, [3, 3], [1, 1], [1, 1])
        convolution_default_18 = torch.ops.aten.convolution.default(avg_pool2d_default_1, primals_114, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_18 = torch.ops.aten.add_.Tensor(primals_110, 1);  primals_110 = None
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_113, primals_109, primals_111, primals_112, True, 0.1, 0.001);  primals_109 = None
        getitem_58 = native_batch_norm_default_18[0]
        getitem_59 = native_batch_norm_default_18[1]
        getitem_60 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        new_zeros_default_18 = torch.ops.aten.new_zeros.default(convolution_default_18, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_18 = torch.ops.aten.relu_.default(getitem_58);  getitem_58 = None
        cat_default_1 = torch.ops.aten.cat.default([relu__default_12, relu__default_14, relu__default_17, relu__default_18], 1)
        convolution_default_19 = torch.ops.aten.convolution.default(cat_default_1, primals_120, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_19 = torch.ops.aten.add_.Tensor(primals_116, 1);  primals_116 = None
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_119, primals_115, primals_117, primals_118, True, 0.1, 0.001);  primals_115 = None
        getitem_61 = native_batch_norm_default_19[0]
        getitem_62 = native_batch_norm_default_19[1]
        getitem_63 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        new_zeros_default_19 = torch.ops.aten.new_zeros.default(convolution_default_19, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_19 = torch.ops.aten.relu_.default(getitem_61);  getitem_61 = None
        convolution_default_20 = torch.ops.aten.convolution.default(cat_default_1, primals_144, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_20 = torch.ops.aten.add_.Tensor(primals_140, 1);  primals_140 = None
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_143, primals_139, primals_141, primals_142, True, 0.1, 0.001);  primals_139 = None
        getitem_64 = native_batch_norm_default_20[0]
        getitem_65 = native_batch_norm_default_20[1]
        getitem_66 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        new_zeros_default_20 = torch.ops.aten.new_zeros.default(convolution_default_20, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_20 = torch.ops.aten.relu_.default(getitem_64);  getitem_64 = None
        convolution_default_21 = torch.ops.aten.convolution.default(relu__default_20, primals_150, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 1)
        add__tensor_21 = torch.ops.aten.add_.Tensor(primals_146, 1);  primals_146 = None
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_149, primals_145, primals_147, primals_148, True, 0.1, 0.001);  primals_145 = None
        getitem_67 = native_batch_norm_default_21[0]
        getitem_68 = native_batch_norm_default_21[1]
        getitem_69 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        new_zeros_default_21 = torch.ops.aten.new_zeros.default(convolution_default_21, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_21 = torch.ops.aten.relu_.default(getitem_67);  getitem_67 = None
        convolution_default_22 = torch.ops.aten.convolution.default(cat_default_1, primals_126, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_22 = torch.ops.aten.add_.Tensor(primals_122, 1);  primals_122 = None
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_125, primals_121, primals_123, primals_124, True, 0.1, 0.001);  primals_121 = None
        getitem_70 = native_batch_norm_default_22[0]
        getitem_71 = native_batch_norm_default_22[1]
        getitem_72 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        new_zeros_default_22 = torch.ops.aten.new_zeros.default(convolution_default_22, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_22 = torch.ops.aten.relu_.default(getitem_70);  getitem_70 = None
        convolution_default_23 = torch.ops.aten.convolution.default(relu__default_22, primals_132, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_23 = torch.ops.aten.add_.Tensor(primals_128, 1);  primals_128 = None
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_131, primals_127, primals_129, primals_130, True, 0.1, 0.001);  primals_127 = None
        getitem_73 = native_batch_norm_default_23[0]
        getitem_74 = native_batch_norm_default_23[1]
        getitem_75 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        new_zeros_default_23 = torch.ops.aten.new_zeros.default(convolution_default_23, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_23 = torch.ops.aten.relu_.default(getitem_73);  getitem_73 = None
        convolution_default_24 = torch.ops.aten.convolution.default(relu__default_23, primals_138, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_24 = torch.ops.aten.add_.Tensor(primals_134, 1);  primals_134 = None
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_137, primals_133, primals_135, primals_136, True, 0.1, 0.001);  primals_133 = None
        getitem_76 = native_batch_norm_default_24[0]
        getitem_77 = native_batch_norm_default_24[1]
        getitem_78 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        new_zeros_default_24 = torch.ops.aten.new_zeros.default(convolution_default_24, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_24 = torch.ops.aten.relu_.default(getitem_76);  getitem_76 = None
        avg_pool2d_default_2 = torch.ops.aten.avg_pool2d.default(cat_default_1, [3, 3], [1, 1], [1, 1])
        convolution_default_25 = torch.ops.aten.convolution.default(avg_pool2d_default_2, primals_156, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_25 = torch.ops.aten.add_.Tensor(primals_152, 1);  primals_152 = None
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_155, primals_151, primals_153, primals_154, True, 0.1, 0.001);  primals_151 = None
        getitem_79 = native_batch_norm_default_25[0]
        getitem_80 = native_batch_norm_default_25[1]
        getitem_81 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        new_zeros_default_25 = torch.ops.aten.new_zeros.default(convolution_default_25, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_25 = torch.ops.aten.relu_.default(getitem_79);  getitem_79 = None
        cat_default_2 = torch.ops.aten.cat.default([relu__default_19, relu__default_21, relu__default_24, relu__default_25], 1)
        convolution_default_26 = torch.ops.aten.convolution.default(cat_default_2, primals_162, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_26 = torch.ops.aten.add_.Tensor(primals_158, 1);  primals_158 = None
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_161, primals_157, primals_159, primals_160, True, 0.1, 0.001);  primals_157 = None
        getitem_82 = native_batch_norm_default_26[0]
        getitem_83 = native_batch_norm_default_26[1]
        getitem_84 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        new_zeros_default_26 = torch.ops.aten.new_zeros.default(convolution_default_26, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_26 = torch.ops.aten.relu_.default(getitem_82);  getitem_82 = None
        convolution_default_27 = torch.ops.aten.convolution.default(cat_default_2, primals_168, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_27 = torch.ops.aten.add_.Tensor(primals_164, 1);  primals_164 = None
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_167, primals_163, primals_165, primals_166, True, 0.1, 0.001);  primals_163 = None
        getitem_85 = native_batch_norm_default_27[0]
        getitem_86 = native_batch_norm_default_27[1]
        getitem_87 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        new_zeros_default_27 = torch.ops.aten.new_zeros.default(convolution_default_27, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_27 = torch.ops.aten.relu_.default(getitem_85);  getitem_85 = None
        convolution_default_28 = torch.ops.aten.convolution.default(relu__default_27, primals_174, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_28 = torch.ops.aten.add_.Tensor(primals_170, 1);  primals_170 = None
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_173, primals_169, primals_171, primals_172, True, 0.1, 0.001);  primals_169 = None
        getitem_88 = native_batch_norm_default_28[0]
        getitem_89 = native_batch_norm_default_28[1]
        getitem_90 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        new_zeros_default_28 = torch.ops.aten.new_zeros.default(convolution_default_28, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_28 = torch.ops.aten.relu_.default(getitem_88);  getitem_88 = None
        convolution_default_29 = torch.ops.aten.convolution.default(relu__default_28, primals_180, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_29 = torch.ops.aten.add_.Tensor(primals_176, 1);  primals_176 = None
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_179, primals_175, primals_177, primals_178, True, 0.1, 0.001);  primals_175 = None
        getitem_91 = native_batch_norm_default_29[0]
        getitem_92 = native_batch_norm_default_29[1]
        getitem_93 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        new_zeros_default_29 = torch.ops.aten.new_zeros.default(convolution_default_29, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_29 = torch.ops.aten.relu_.default(getitem_91);  getitem_91 = None
        max_pool2d_with_indices_default_2 = torch.ops.aten.max_pool2d_with_indices.default(cat_default_2, [3, 3], [2, 2])
        getitem_94 = max_pool2d_with_indices_default_2[0]
        getitem_95 = max_pool2d_with_indices_default_2[1];  max_pool2d_with_indices_default_2 = None
        cat_default_3 = torch.ops.aten.cat.default([relu__default_26, relu__default_29, getitem_94], 1);  getitem_94 = None
        convolution_default_30 = torch.ops.aten.convolution.default(cat_default_3, primals_186, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_30 = torch.ops.aten.add_.Tensor(primals_182, 1);  primals_182 = None
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_185, primals_181, primals_183, primals_184, True, 0.1, 0.001);  primals_181 = None
        getitem_96 = native_batch_norm_default_30[0]
        getitem_97 = native_batch_norm_default_30[1]
        getitem_98 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        new_zeros_default_30 = torch.ops.aten.new_zeros.default(convolution_default_30, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_30 = torch.ops.aten.relu_.default(getitem_96);  getitem_96 = None
        convolution_default_31 = torch.ops.aten.convolution.default(cat_default_3, primals_192, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_31 = torch.ops.aten.add_.Tensor(primals_188, 1);  primals_188 = None
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_31, primals_191, primals_187, primals_189, primals_190, True, 0.1, 0.001);  primals_187 = None
        getitem_99 = native_batch_norm_default_31[0]
        getitem_100 = native_batch_norm_default_31[1]
        getitem_101 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        new_zeros_default_31 = torch.ops.aten.new_zeros.default(convolution_default_31, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_31 = torch.ops.aten.relu_.default(getitem_99);  getitem_99 = None
        convolution_default_32 = torch.ops.aten.convolution.default(relu__default_31, primals_198, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        add__tensor_32 = torch.ops.aten.add_.Tensor(primals_194, 1);  primals_194 = None
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_197, primals_193, primals_195, primals_196, True, 0.1, 0.001);  primals_193 = None
        getitem_102 = native_batch_norm_default_32[0]
        getitem_103 = native_batch_norm_default_32[1]
        getitem_104 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        new_zeros_default_32 = torch.ops.aten.new_zeros.default(convolution_default_32, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_32 = torch.ops.aten.relu_.default(getitem_102);  getitem_102 = None
        convolution_default_33 = torch.ops.aten.convolution.default(relu__default_32, primals_204, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        add__tensor_33 = torch.ops.aten.add_.Tensor(primals_200, 1);  primals_200 = None
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_203, primals_199, primals_201, primals_202, True, 0.1, 0.001);  primals_199 = None
        getitem_105 = native_batch_norm_default_33[0]
        getitem_106 = native_batch_norm_default_33[1]
        getitem_107 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        new_zeros_default_33 = torch.ops.aten.new_zeros.default(convolution_default_33, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_33 = torch.ops.aten.relu_.default(getitem_105);  getitem_105 = None
        convolution_default_34 = torch.ops.aten.convolution.default(cat_default_3, primals_210, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_34 = torch.ops.aten.add_.Tensor(primals_206, 1);  primals_206 = None
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_209, primals_205, primals_207, primals_208, True, 0.1, 0.001);  primals_205 = None
        getitem_108 = native_batch_norm_default_34[0]
        getitem_109 = native_batch_norm_default_34[1]
        getitem_110 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        new_zeros_default_34 = torch.ops.aten.new_zeros.default(convolution_default_34, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_34 = torch.ops.aten.relu_.default(getitem_108);  getitem_108 = None
        convolution_default_35 = torch.ops.aten.convolution.default(relu__default_34, primals_216, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        add__tensor_35 = torch.ops.aten.add_.Tensor(primals_212, 1);  primals_212 = None
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_215, primals_211, primals_213, primals_214, True, 0.1, 0.001);  primals_211 = None
        getitem_111 = native_batch_norm_default_35[0]
        getitem_112 = native_batch_norm_default_35[1]
        getitem_113 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        new_zeros_default_35 = torch.ops.aten.new_zeros.default(convolution_default_35, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_35 = torch.ops.aten.relu_.default(getitem_111);  getitem_111 = None
        convolution_default_36 = torch.ops.aten.convolution.default(relu__default_35, primals_222, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        add__tensor_36 = torch.ops.aten.add_.Tensor(primals_218, 1);  primals_218 = None
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_221, primals_217, primals_219, primals_220, True, 0.1, 0.001);  primals_217 = None
        getitem_114 = native_batch_norm_default_36[0]
        getitem_115 = native_batch_norm_default_36[1]
        getitem_116 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        new_zeros_default_36 = torch.ops.aten.new_zeros.default(convolution_default_36, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_36 = torch.ops.aten.relu_.default(getitem_114);  getitem_114 = None
        convolution_default_37 = torch.ops.aten.convolution.default(relu__default_36, primals_228, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        add__tensor_37 = torch.ops.aten.add_.Tensor(primals_224, 1);  primals_224 = None
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_37, primals_227, primals_223, primals_225, primals_226, True, 0.1, 0.001);  primals_223 = None
        getitem_117 = native_batch_norm_default_37[0]
        getitem_118 = native_batch_norm_default_37[1]
        getitem_119 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        new_zeros_default_37 = torch.ops.aten.new_zeros.default(convolution_default_37, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_37 = torch.ops.aten.relu_.default(getitem_117);  getitem_117 = None
        convolution_default_38 = torch.ops.aten.convolution.default(relu__default_37, primals_234, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        add__tensor_38 = torch.ops.aten.add_.Tensor(primals_230, 1);  primals_230 = None
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_233, primals_229, primals_231, primals_232, True, 0.1, 0.001);  primals_229 = None
        getitem_120 = native_batch_norm_default_38[0]
        getitem_121 = native_batch_norm_default_38[1]
        getitem_122 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        new_zeros_default_38 = torch.ops.aten.new_zeros.default(convolution_default_38, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_38 = torch.ops.aten.relu_.default(getitem_120);  getitem_120 = None
        avg_pool2d_default_3 = torch.ops.aten.avg_pool2d.default(cat_default_3, [3, 3], [1, 1], [1, 1])
        convolution_default_39 = torch.ops.aten.convolution.default(avg_pool2d_default_3, primals_240, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_39 = torch.ops.aten.add_.Tensor(primals_236, 1);  primals_236 = None
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_39, primals_239, primals_235, primals_237, primals_238, True, 0.1, 0.001);  primals_235 = None
        getitem_123 = native_batch_norm_default_39[0]
        getitem_124 = native_batch_norm_default_39[1]
        getitem_125 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        new_zeros_default_39 = torch.ops.aten.new_zeros.default(convolution_default_39, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_39 = torch.ops.aten.relu_.default(getitem_123);  getitem_123 = None
        cat_default_4 = torch.ops.aten.cat.default([relu__default_30, relu__default_33, relu__default_38, relu__default_39], 1)
        convolution_default_40 = torch.ops.aten.convolution.default(cat_default_4, primals_246, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_40 = torch.ops.aten.add_.Tensor(primals_242, 1);  primals_242 = None
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_245, primals_241, primals_243, primals_244, True, 0.1, 0.001);  primals_241 = None
        getitem_126 = native_batch_norm_default_40[0]
        getitem_127 = native_batch_norm_default_40[1]
        getitem_128 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        new_zeros_default_40 = torch.ops.aten.new_zeros.default(convolution_default_40, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_40 = torch.ops.aten.relu_.default(getitem_126);  getitem_126 = None
        convolution_default_41 = torch.ops.aten.convolution.default(cat_default_4, primals_252, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_41 = torch.ops.aten.add_.Tensor(primals_248, 1);  primals_248 = None
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_41, primals_251, primals_247, primals_249, primals_250, True, 0.1, 0.001);  primals_247 = None
        getitem_129 = native_batch_norm_default_41[0]
        getitem_130 = native_batch_norm_default_41[1]
        getitem_131 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        new_zeros_default_41 = torch.ops.aten.new_zeros.default(convolution_default_41, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_41 = torch.ops.aten.relu_.default(getitem_129);  getitem_129 = None
        convolution_default_42 = torch.ops.aten.convolution.default(relu__default_41, primals_258, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        add__tensor_42 = torch.ops.aten.add_.Tensor(primals_254, 1);  primals_254 = None
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_42, primals_257, primals_253, primals_255, primals_256, True, 0.1, 0.001);  primals_253 = None
        getitem_132 = native_batch_norm_default_42[0]
        getitem_133 = native_batch_norm_default_42[1]
        getitem_134 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        new_zeros_default_42 = torch.ops.aten.new_zeros.default(convolution_default_42, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_42 = torch.ops.aten.relu_.default(getitem_132);  getitem_132 = None
        convolution_default_43 = torch.ops.aten.convolution.default(relu__default_42, primals_264, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        add__tensor_43 = torch.ops.aten.add_.Tensor(primals_260, 1);  primals_260 = None
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_43, primals_263, primals_259, primals_261, primals_262, True, 0.1, 0.001);  primals_259 = None
        getitem_135 = native_batch_norm_default_43[0]
        getitem_136 = native_batch_norm_default_43[1]
        getitem_137 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        new_zeros_default_43 = torch.ops.aten.new_zeros.default(convolution_default_43, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_43 = torch.ops.aten.relu_.default(getitem_135);  getitem_135 = None
        convolution_default_44 = torch.ops.aten.convolution.default(cat_default_4, primals_270, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_44 = torch.ops.aten.add_.Tensor(primals_266, 1);  primals_266 = None
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_269, primals_265, primals_267, primals_268, True, 0.1, 0.001);  primals_265 = None
        getitem_138 = native_batch_norm_default_44[0]
        getitem_139 = native_batch_norm_default_44[1]
        getitem_140 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        new_zeros_default_44 = torch.ops.aten.new_zeros.default(convolution_default_44, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_44 = torch.ops.aten.relu_.default(getitem_138);  getitem_138 = None
        convolution_default_45 = torch.ops.aten.convolution.default(relu__default_44, primals_276, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        add__tensor_45 = torch.ops.aten.add_.Tensor(primals_272, 1);  primals_272 = None
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_45, primals_275, primals_271, primals_273, primals_274, True, 0.1, 0.001);  primals_271 = None
        getitem_141 = native_batch_norm_default_45[0]
        getitem_142 = native_batch_norm_default_45[1]
        getitem_143 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        new_zeros_default_45 = torch.ops.aten.new_zeros.default(convolution_default_45, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_45 = torch.ops.aten.relu_.default(getitem_141);  getitem_141 = None
        convolution_default_46 = torch.ops.aten.convolution.default(relu__default_45, primals_282, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        add__tensor_46 = torch.ops.aten.add_.Tensor(primals_278, 1);  primals_278 = None
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(convolution_default_46, primals_281, primals_277, primals_279, primals_280, True, 0.1, 0.001);  primals_277 = None
        getitem_144 = native_batch_norm_default_46[0]
        getitem_145 = native_batch_norm_default_46[1]
        getitem_146 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        new_zeros_default_46 = torch.ops.aten.new_zeros.default(convolution_default_46, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_46 = torch.ops.aten.relu_.default(getitem_144);  getitem_144 = None
        convolution_default_47 = torch.ops.aten.convolution.default(relu__default_46, primals_288, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        add__tensor_47 = torch.ops.aten.add_.Tensor(primals_284, 1);  primals_284 = None
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(convolution_default_47, primals_287, primals_283, primals_285, primals_286, True, 0.1, 0.001);  primals_283 = None
        getitem_147 = native_batch_norm_default_47[0]
        getitem_148 = native_batch_norm_default_47[1]
        getitem_149 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        new_zeros_default_47 = torch.ops.aten.new_zeros.default(convolution_default_47, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_47 = torch.ops.aten.relu_.default(getitem_147);  getitem_147 = None
        convolution_default_48 = torch.ops.aten.convolution.default(relu__default_47, primals_294, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        add__tensor_48 = torch.ops.aten.add_.Tensor(primals_290, 1);  primals_290 = None
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_48, primals_293, primals_289, primals_291, primals_292, True, 0.1, 0.001);  primals_289 = None
        getitem_150 = native_batch_norm_default_48[0]
        getitem_151 = native_batch_norm_default_48[1]
        getitem_152 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        new_zeros_default_48 = torch.ops.aten.new_zeros.default(convolution_default_48, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_48 = torch.ops.aten.relu_.default(getitem_150);  getitem_150 = None
        avg_pool2d_default_4 = torch.ops.aten.avg_pool2d.default(cat_default_4, [3, 3], [1, 1], [1, 1])
        convolution_default_49 = torch.ops.aten.convolution.default(avg_pool2d_default_4, primals_300, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_49 = torch.ops.aten.add_.Tensor(primals_296, 1);  primals_296 = None
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(convolution_default_49, primals_299, primals_295, primals_297, primals_298, True, 0.1, 0.001);  primals_295 = None
        getitem_153 = native_batch_norm_default_49[0]
        getitem_154 = native_batch_norm_default_49[1]
        getitem_155 = native_batch_norm_default_49[2];  native_batch_norm_default_49 = None
        new_zeros_default_49 = torch.ops.aten.new_zeros.default(convolution_default_49, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_49 = torch.ops.aten.relu_.default(getitem_153);  getitem_153 = None
        cat_default_5 = torch.ops.aten.cat.default([relu__default_40, relu__default_43, relu__default_48, relu__default_49], 1)
        convolution_default_50 = torch.ops.aten.convolution.default(cat_default_5, primals_306, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_50 = torch.ops.aten.add_.Tensor(primals_302, 1);  primals_302 = None
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(convolution_default_50, primals_305, primals_301, primals_303, primals_304, True, 0.1, 0.001);  primals_301 = None
        getitem_156 = native_batch_norm_default_50[0]
        getitem_157 = native_batch_norm_default_50[1]
        getitem_158 = native_batch_norm_default_50[2];  native_batch_norm_default_50 = None
        new_zeros_default_50 = torch.ops.aten.new_zeros.default(convolution_default_50, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_50 = torch.ops.aten.relu_.default(getitem_156);  getitem_156 = None
        convolution_default_51 = torch.ops.aten.convolution.default(cat_default_5, primals_312, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_51 = torch.ops.aten.add_.Tensor(primals_308, 1);  primals_308 = None
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(convolution_default_51, primals_311, primals_307, primals_309, primals_310, True, 0.1, 0.001);  primals_307 = None
        getitem_159 = native_batch_norm_default_51[0]
        getitem_160 = native_batch_norm_default_51[1]
        getitem_161 = native_batch_norm_default_51[2];  native_batch_norm_default_51 = None
        new_zeros_default_51 = torch.ops.aten.new_zeros.default(convolution_default_51, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_51 = torch.ops.aten.relu_.default(getitem_159);  getitem_159 = None
        convolution_default_52 = torch.ops.aten.convolution.default(relu__default_51, primals_318, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        add__tensor_52 = torch.ops.aten.add_.Tensor(primals_314, 1);  primals_314 = None
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(convolution_default_52, primals_317, primals_313, primals_315, primals_316, True, 0.1, 0.001);  primals_313 = None
        getitem_162 = native_batch_norm_default_52[0]
        getitem_163 = native_batch_norm_default_52[1]
        getitem_164 = native_batch_norm_default_52[2];  native_batch_norm_default_52 = None
        new_zeros_default_52 = torch.ops.aten.new_zeros.default(convolution_default_52, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_52 = torch.ops.aten.relu_.default(getitem_162);  getitem_162 = None
        convolution_default_53 = torch.ops.aten.convolution.default(relu__default_52, primals_324, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        add__tensor_53 = torch.ops.aten.add_.Tensor(primals_320, 1);  primals_320 = None
        native_batch_norm_default_53 = torch.ops.aten.native_batch_norm.default(convolution_default_53, primals_323, primals_319, primals_321, primals_322, True, 0.1, 0.001);  primals_319 = None
        getitem_165 = native_batch_norm_default_53[0]
        getitem_166 = native_batch_norm_default_53[1]
        getitem_167 = native_batch_norm_default_53[2];  native_batch_norm_default_53 = None
        new_zeros_default_53 = torch.ops.aten.new_zeros.default(convolution_default_53, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_53 = torch.ops.aten.relu_.default(getitem_165);  getitem_165 = None
        convolution_default_54 = torch.ops.aten.convolution.default(cat_default_5, primals_330, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_54 = torch.ops.aten.add_.Tensor(primals_326, 1);  primals_326 = None
        native_batch_norm_default_54 = torch.ops.aten.native_batch_norm.default(convolution_default_54, primals_329, primals_325, primals_327, primals_328, True, 0.1, 0.001);  primals_325 = None
        getitem_168 = native_batch_norm_default_54[0]
        getitem_169 = native_batch_norm_default_54[1]
        getitem_170 = native_batch_norm_default_54[2];  native_batch_norm_default_54 = None
        new_zeros_default_54 = torch.ops.aten.new_zeros.default(convolution_default_54, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_54 = torch.ops.aten.relu_.default(getitem_168);  getitem_168 = None
        convolution_default_55 = torch.ops.aten.convolution.default(relu__default_54, primals_336, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        add__tensor_55 = torch.ops.aten.add_.Tensor(primals_332, 1);  primals_332 = None
        native_batch_norm_default_55 = torch.ops.aten.native_batch_norm.default(convolution_default_55, primals_335, primals_331, primals_333, primals_334, True, 0.1, 0.001);  primals_331 = None
        getitem_171 = native_batch_norm_default_55[0]
        getitem_172 = native_batch_norm_default_55[1]
        getitem_173 = native_batch_norm_default_55[2];  native_batch_norm_default_55 = None
        new_zeros_default_55 = torch.ops.aten.new_zeros.default(convolution_default_55, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_55 = torch.ops.aten.relu_.default(getitem_171);  getitem_171 = None
        convolution_default_56 = torch.ops.aten.convolution.default(relu__default_55, primals_342, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        add__tensor_56 = torch.ops.aten.add_.Tensor(primals_338, 1);  primals_338 = None
        native_batch_norm_default_56 = torch.ops.aten.native_batch_norm.default(convolution_default_56, primals_341, primals_337, primals_339, primals_340, True, 0.1, 0.001);  primals_337 = None
        getitem_174 = native_batch_norm_default_56[0]
        getitem_175 = native_batch_norm_default_56[1]
        getitem_176 = native_batch_norm_default_56[2];  native_batch_norm_default_56 = None
        new_zeros_default_56 = torch.ops.aten.new_zeros.default(convolution_default_56, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_56 = torch.ops.aten.relu_.default(getitem_174);  getitem_174 = None
        convolution_default_57 = torch.ops.aten.convolution.default(relu__default_56, primals_348, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        add__tensor_57 = torch.ops.aten.add_.Tensor(primals_344, 1);  primals_344 = None
        native_batch_norm_default_57 = torch.ops.aten.native_batch_norm.default(convolution_default_57, primals_347, primals_343, primals_345, primals_346, True, 0.1, 0.001);  primals_343 = None
        getitem_177 = native_batch_norm_default_57[0]
        getitem_178 = native_batch_norm_default_57[1]
        getitem_179 = native_batch_norm_default_57[2];  native_batch_norm_default_57 = None
        new_zeros_default_57 = torch.ops.aten.new_zeros.default(convolution_default_57, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_57 = torch.ops.aten.relu_.default(getitem_177);  getitem_177 = None
        convolution_default_58 = torch.ops.aten.convolution.default(relu__default_57, primals_354, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        add__tensor_58 = torch.ops.aten.add_.Tensor(primals_350, 1);  primals_350 = None
        native_batch_norm_default_58 = torch.ops.aten.native_batch_norm.default(convolution_default_58, primals_353, primals_349, primals_351, primals_352, True, 0.1, 0.001);  primals_349 = None
        getitem_180 = native_batch_norm_default_58[0]
        getitem_181 = native_batch_norm_default_58[1]
        getitem_182 = native_batch_norm_default_58[2];  native_batch_norm_default_58 = None
        new_zeros_default_58 = torch.ops.aten.new_zeros.default(convolution_default_58, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_58 = torch.ops.aten.relu_.default(getitem_180);  getitem_180 = None
        avg_pool2d_default_5 = torch.ops.aten.avg_pool2d.default(cat_default_5, [3, 3], [1, 1], [1, 1])
        convolution_default_59 = torch.ops.aten.convolution.default(avg_pool2d_default_5, primals_360, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_59 = torch.ops.aten.add_.Tensor(primals_356, 1);  primals_356 = None
        native_batch_norm_default_59 = torch.ops.aten.native_batch_norm.default(convolution_default_59, primals_359, primals_355, primals_357, primals_358, True, 0.1, 0.001);  primals_355 = None
        getitem_183 = native_batch_norm_default_59[0]
        getitem_184 = native_batch_norm_default_59[1]
        getitem_185 = native_batch_norm_default_59[2];  native_batch_norm_default_59 = None
        new_zeros_default_59 = torch.ops.aten.new_zeros.default(convolution_default_59, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_59 = torch.ops.aten.relu_.default(getitem_183);  getitem_183 = None
        cat_default_6 = torch.ops.aten.cat.default([relu__default_50, relu__default_53, relu__default_58, relu__default_59], 1)
        convolution_default_60 = torch.ops.aten.convolution.default(cat_default_6, primals_366, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_60 = torch.ops.aten.add_.Tensor(primals_362, 1);  primals_362 = None
        native_batch_norm_default_60 = torch.ops.aten.native_batch_norm.default(convolution_default_60, primals_365, primals_361, primals_363, primals_364, True, 0.1, 0.001);  primals_361 = None
        getitem_186 = native_batch_norm_default_60[0]
        getitem_187 = native_batch_norm_default_60[1]
        getitem_188 = native_batch_norm_default_60[2];  native_batch_norm_default_60 = None
        new_zeros_default_60 = torch.ops.aten.new_zeros.default(convolution_default_60, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_60 = torch.ops.aten.relu_.default(getitem_186);  getitem_186 = None
        convolution_default_61 = torch.ops.aten.convolution.default(cat_default_6, primals_372, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_61 = torch.ops.aten.add_.Tensor(primals_368, 1);  primals_368 = None
        native_batch_norm_default_61 = torch.ops.aten.native_batch_norm.default(convolution_default_61, primals_371, primals_367, primals_369, primals_370, True, 0.1, 0.001);  primals_367 = None
        getitem_189 = native_batch_norm_default_61[0]
        getitem_190 = native_batch_norm_default_61[1]
        getitem_191 = native_batch_norm_default_61[2];  native_batch_norm_default_61 = None
        new_zeros_default_61 = torch.ops.aten.new_zeros.default(convolution_default_61, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_61 = torch.ops.aten.relu_.default(getitem_189);  getitem_189 = None
        convolution_default_62 = torch.ops.aten.convolution.default(relu__default_61, primals_378, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        add__tensor_62 = torch.ops.aten.add_.Tensor(primals_374, 1);  primals_374 = None
        native_batch_norm_default_62 = torch.ops.aten.native_batch_norm.default(convolution_default_62, primals_377, primals_373, primals_375, primals_376, True, 0.1, 0.001);  primals_373 = None
        getitem_192 = native_batch_norm_default_62[0]
        getitem_193 = native_batch_norm_default_62[1]
        getitem_194 = native_batch_norm_default_62[2];  native_batch_norm_default_62 = None
        new_zeros_default_62 = torch.ops.aten.new_zeros.default(convolution_default_62, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_62 = torch.ops.aten.relu_.default(getitem_192);  getitem_192 = None
        convolution_default_63 = torch.ops.aten.convolution.default(relu__default_62, primals_384, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        add__tensor_63 = torch.ops.aten.add_.Tensor(primals_380, 1);  primals_380 = None
        native_batch_norm_default_63 = torch.ops.aten.native_batch_norm.default(convolution_default_63, primals_383, primals_379, primals_381, primals_382, True, 0.1, 0.001);  primals_379 = None
        getitem_195 = native_batch_norm_default_63[0]
        getitem_196 = native_batch_norm_default_63[1]
        getitem_197 = native_batch_norm_default_63[2];  native_batch_norm_default_63 = None
        new_zeros_default_63 = torch.ops.aten.new_zeros.default(convolution_default_63, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_63 = torch.ops.aten.relu_.default(getitem_195);  getitem_195 = None
        convolution_default_64 = torch.ops.aten.convolution.default(cat_default_6, primals_390, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_64 = torch.ops.aten.add_.Tensor(primals_386, 1);  primals_386 = None
        native_batch_norm_default_64 = torch.ops.aten.native_batch_norm.default(convolution_default_64, primals_389, primals_385, primals_387, primals_388, True, 0.1, 0.001);  primals_385 = None
        getitem_198 = native_batch_norm_default_64[0]
        getitem_199 = native_batch_norm_default_64[1]
        getitem_200 = native_batch_norm_default_64[2];  native_batch_norm_default_64 = None
        new_zeros_default_64 = torch.ops.aten.new_zeros.default(convolution_default_64, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_64 = torch.ops.aten.relu_.default(getitem_198);  getitem_198 = None
        convolution_default_65 = torch.ops.aten.convolution.default(relu__default_64, primals_396, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        add__tensor_65 = torch.ops.aten.add_.Tensor(primals_392, 1);  primals_392 = None
        native_batch_norm_default_65 = torch.ops.aten.native_batch_norm.default(convolution_default_65, primals_395, primals_391, primals_393, primals_394, True, 0.1, 0.001);  primals_391 = None
        getitem_201 = native_batch_norm_default_65[0]
        getitem_202 = native_batch_norm_default_65[1]
        getitem_203 = native_batch_norm_default_65[2];  native_batch_norm_default_65 = None
        new_zeros_default_65 = torch.ops.aten.new_zeros.default(convolution_default_65, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_65 = torch.ops.aten.relu_.default(getitem_201);  getitem_201 = None
        convolution_default_66 = torch.ops.aten.convolution.default(relu__default_65, primals_402, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        add__tensor_66 = torch.ops.aten.add_.Tensor(primals_398, 1);  primals_398 = None
        native_batch_norm_default_66 = torch.ops.aten.native_batch_norm.default(convolution_default_66, primals_401, primals_397, primals_399, primals_400, True, 0.1, 0.001);  primals_397 = None
        getitem_204 = native_batch_norm_default_66[0]
        getitem_205 = native_batch_norm_default_66[1]
        getitem_206 = native_batch_norm_default_66[2];  native_batch_norm_default_66 = None
        new_zeros_default_66 = torch.ops.aten.new_zeros.default(convolution_default_66, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_66 = torch.ops.aten.relu_.default(getitem_204);  getitem_204 = None
        convolution_default_67 = torch.ops.aten.convolution.default(relu__default_66, primals_408, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        add__tensor_67 = torch.ops.aten.add_.Tensor(primals_404, 1);  primals_404 = None
        native_batch_norm_default_67 = torch.ops.aten.native_batch_norm.default(convolution_default_67, primals_407, primals_403, primals_405, primals_406, True, 0.1, 0.001);  primals_403 = None
        getitem_207 = native_batch_norm_default_67[0]
        getitem_208 = native_batch_norm_default_67[1]
        getitem_209 = native_batch_norm_default_67[2];  native_batch_norm_default_67 = None
        new_zeros_default_67 = torch.ops.aten.new_zeros.default(convolution_default_67, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_67 = torch.ops.aten.relu_.default(getitem_207);  getitem_207 = None
        convolution_default_68 = torch.ops.aten.convolution.default(relu__default_67, primals_414, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        add__tensor_68 = torch.ops.aten.add_.Tensor(primals_410, 1);  primals_410 = None
        native_batch_norm_default_68 = torch.ops.aten.native_batch_norm.default(convolution_default_68, primals_413, primals_409, primals_411, primals_412, True, 0.1, 0.001);  primals_409 = None
        getitem_210 = native_batch_norm_default_68[0]
        getitem_211 = native_batch_norm_default_68[1]
        getitem_212 = native_batch_norm_default_68[2];  native_batch_norm_default_68 = None
        new_zeros_default_68 = torch.ops.aten.new_zeros.default(convolution_default_68, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_68 = torch.ops.aten.relu_.default(getitem_210);  getitem_210 = None
        avg_pool2d_default_6 = torch.ops.aten.avg_pool2d.default(cat_default_6, [3, 3], [1, 1], [1, 1])
        convolution_default_69 = torch.ops.aten.convolution.default(avg_pool2d_default_6, primals_420, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_69 = torch.ops.aten.add_.Tensor(primals_416, 1);  primals_416 = None
        native_batch_norm_default_69 = torch.ops.aten.native_batch_norm.default(convolution_default_69, primals_419, primals_415, primals_417, primals_418, True, 0.1, 0.001);  primals_415 = None
        getitem_213 = native_batch_norm_default_69[0]
        getitem_214 = native_batch_norm_default_69[1]
        getitem_215 = native_batch_norm_default_69[2];  native_batch_norm_default_69 = None
        new_zeros_default_69 = torch.ops.aten.new_zeros.default(convolution_default_69, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_69 = torch.ops.aten.relu_.default(getitem_213);  getitem_213 = None
        cat_default_7 = torch.ops.aten.cat.default([relu__default_60, relu__default_63, relu__default_68, relu__default_69], 1)
        convolution_default_70 = torch.ops.aten.convolution.default(cat_default_7, primals_426, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_70 = torch.ops.aten.add_.Tensor(primals_422, 1);  primals_422 = None
        native_batch_norm_default_70 = torch.ops.aten.native_batch_norm.default(convolution_default_70, primals_425, primals_421, primals_423, primals_424, True, 0.1, 0.001);  primals_421 = None
        getitem_216 = native_batch_norm_default_70[0]
        getitem_217 = native_batch_norm_default_70[1]
        getitem_218 = native_batch_norm_default_70[2];  native_batch_norm_default_70 = None
        new_zeros_default_70 = torch.ops.aten.new_zeros.default(convolution_default_70, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_70 = torch.ops.aten.relu_.default(getitem_216);  getitem_216 = None
        convolution_default_71 = torch.ops.aten.convolution.default(relu__default_70, primals_432, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_71 = torch.ops.aten.add_.Tensor(primals_428, 1);  primals_428 = None
        native_batch_norm_default_71 = torch.ops.aten.native_batch_norm.default(convolution_default_71, primals_431, primals_427, primals_429, primals_430, True, 0.1, 0.001);  primals_427 = None
        getitem_219 = native_batch_norm_default_71[0]
        getitem_220 = native_batch_norm_default_71[1]
        getitem_221 = native_batch_norm_default_71[2];  native_batch_norm_default_71 = None
        new_zeros_default_71 = torch.ops.aten.new_zeros.default(convolution_default_71, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_71 = torch.ops.aten.relu_.default(getitem_219);  getitem_219 = None
        convolution_default_72 = torch.ops.aten.convolution.default(cat_default_7, primals_438, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_72 = torch.ops.aten.add_.Tensor(primals_434, 1);  primals_434 = None
        native_batch_norm_default_72 = torch.ops.aten.native_batch_norm.default(convolution_default_72, primals_437, primals_433, primals_435, primals_436, True, 0.1, 0.001);  primals_433 = None
        getitem_222 = native_batch_norm_default_72[0]
        getitem_223 = native_batch_norm_default_72[1]
        getitem_224 = native_batch_norm_default_72[2];  native_batch_norm_default_72 = None
        new_zeros_default_72 = torch.ops.aten.new_zeros.default(convolution_default_72, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_72 = torch.ops.aten.relu_.default(getitem_222);  getitem_222 = None
        convolution_default_73 = torch.ops.aten.convolution.default(relu__default_72, primals_444, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        add__tensor_73 = torch.ops.aten.add_.Tensor(primals_440, 1);  primals_440 = None
        native_batch_norm_default_73 = torch.ops.aten.native_batch_norm.default(convolution_default_73, primals_443, primals_439, primals_441, primals_442, True, 0.1, 0.001);  primals_439 = None
        getitem_225 = native_batch_norm_default_73[0]
        getitem_226 = native_batch_norm_default_73[1]
        getitem_227 = native_batch_norm_default_73[2];  native_batch_norm_default_73 = None
        new_zeros_default_73 = torch.ops.aten.new_zeros.default(convolution_default_73, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_73 = torch.ops.aten.relu_.default(getitem_225);  getitem_225 = None
        convolution_default_74 = torch.ops.aten.convolution.default(relu__default_73, primals_450, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        add__tensor_74 = torch.ops.aten.add_.Tensor(primals_446, 1);  primals_446 = None
        native_batch_norm_default_74 = torch.ops.aten.native_batch_norm.default(convolution_default_74, primals_449, primals_445, primals_447, primals_448, True, 0.1, 0.001);  primals_445 = None
        getitem_228 = native_batch_norm_default_74[0]
        getitem_229 = native_batch_norm_default_74[1]
        getitem_230 = native_batch_norm_default_74[2];  native_batch_norm_default_74 = None
        new_zeros_default_74 = torch.ops.aten.new_zeros.default(convolution_default_74, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_74 = torch.ops.aten.relu_.default(getitem_228);  getitem_228 = None
        convolution_default_75 = torch.ops.aten.convolution.default(relu__default_74, primals_456, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_75 = torch.ops.aten.add_.Tensor(primals_452, 1);  primals_452 = None
        native_batch_norm_default_75 = torch.ops.aten.native_batch_norm.default(convolution_default_75, primals_455, primals_451, primals_453, primals_454, True, 0.1, 0.001);  primals_451 = None
        getitem_231 = native_batch_norm_default_75[0]
        getitem_232 = native_batch_norm_default_75[1]
        getitem_233 = native_batch_norm_default_75[2];  native_batch_norm_default_75 = None
        new_zeros_default_75 = torch.ops.aten.new_zeros.default(convolution_default_75, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_75 = torch.ops.aten.relu_.default(getitem_231);  getitem_231 = None
        max_pool2d_with_indices_default_3 = torch.ops.aten.max_pool2d_with_indices.default(cat_default_7, [3, 3], [2, 2])
        getitem_234 = max_pool2d_with_indices_default_3[0]
        getitem_235 = max_pool2d_with_indices_default_3[1];  max_pool2d_with_indices_default_3 = None
        cat_default_8 = torch.ops.aten.cat.default([relu__default_71, relu__default_75, getitem_234], 1);  getitem_234 = None
        convolution_default_76 = torch.ops.aten.convolution.default(cat_default_8, primals_462, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_76 = torch.ops.aten.add_.Tensor(primals_458, 1);  primals_458 = None
        native_batch_norm_default_76 = torch.ops.aten.native_batch_norm.default(convolution_default_76, primals_461, primals_457, primals_459, primals_460, True, 0.1, 0.001);  primals_457 = None
        getitem_236 = native_batch_norm_default_76[0]
        getitem_237 = native_batch_norm_default_76[1]
        getitem_238 = native_batch_norm_default_76[2];  native_batch_norm_default_76 = None
        new_zeros_default_76 = torch.ops.aten.new_zeros.default(convolution_default_76, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_76 = torch.ops.aten.relu_.default(getitem_236);  getitem_236 = None
        convolution_default_77 = torch.ops.aten.convolution.default(cat_default_8, primals_468, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_77 = torch.ops.aten.add_.Tensor(primals_464, 1);  primals_464 = None
        native_batch_norm_default_77 = torch.ops.aten.native_batch_norm.default(convolution_default_77, primals_467, primals_463, primals_465, primals_466, True, 0.1, 0.001);  primals_463 = None
        getitem_239 = native_batch_norm_default_77[0]
        getitem_240 = native_batch_norm_default_77[1]
        getitem_241 = native_batch_norm_default_77[2];  native_batch_norm_default_77 = None
        new_zeros_default_77 = torch.ops.aten.new_zeros.default(convolution_default_77, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_77 = torch.ops.aten.relu_.default(getitem_239);  getitem_239 = None
        convolution_default_78 = torch.ops.aten.convolution.default(relu__default_77, primals_474, None, [1, 1], [0, 1], [1, 1], False, [0, 0], 1)
        add__tensor_78 = torch.ops.aten.add_.Tensor(primals_470, 1);  primals_470 = None
        native_batch_norm_default_78 = torch.ops.aten.native_batch_norm.default(convolution_default_78, primals_473, primals_469, primals_471, primals_472, True, 0.1, 0.001);  primals_469 = None
        getitem_242 = native_batch_norm_default_78[0]
        getitem_243 = native_batch_norm_default_78[1]
        getitem_244 = native_batch_norm_default_78[2];  native_batch_norm_default_78 = None
        new_zeros_default_78 = torch.ops.aten.new_zeros.default(convolution_default_78, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_78 = torch.ops.aten.relu_.default(getitem_242);  getitem_242 = None
        convolution_default_79 = torch.ops.aten.convolution.default(relu__default_77, primals_480, None, [1, 1], [1, 0], [1, 1], False, [0, 0], 1)
        add__tensor_79 = torch.ops.aten.add_.Tensor(primals_476, 1);  primals_476 = None
        native_batch_norm_default_79 = torch.ops.aten.native_batch_norm.default(convolution_default_79, primals_479, primals_475, primals_477, primals_478, True, 0.1, 0.001);  primals_475 = None
        getitem_245 = native_batch_norm_default_79[0]
        getitem_246 = native_batch_norm_default_79[1]
        getitem_247 = native_batch_norm_default_79[2];  native_batch_norm_default_79 = None
        new_zeros_default_79 = torch.ops.aten.new_zeros.default(convolution_default_79, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_79 = torch.ops.aten.relu_.default(getitem_245);  getitem_245 = None
        cat_default_9 = torch.ops.aten.cat.default([relu__default_78, relu__default_79], 1)
        convolution_default_80 = torch.ops.aten.convolution.default(cat_default_8, primals_486, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_80 = torch.ops.aten.add_.Tensor(primals_482, 1);  primals_482 = None
        native_batch_norm_default_80 = torch.ops.aten.native_batch_norm.default(convolution_default_80, primals_485, primals_481, primals_483, primals_484, True, 0.1, 0.001);  primals_481 = None
        getitem_248 = native_batch_norm_default_80[0]
        getitem_249 = native_batch_norm_default_80[1]
        getitem_250 = native_batch_norm_default_80[2];  native_batch_norm_default_80 = None
        new_zeros_default_80 = torch.ops.aten.new_zeros.default(convolution_default_80, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_80 = torch.ops.aten.relu_.default(getitem_248);  getitem_248 = None
        convolution_default_81 = torch.ops.aten.convolution.default(relu__default_80, primals_492, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_81 = torch.ops.aten.add_.Tensor(primals_488, 1);  primals_488 = None
        native_batch_norm_default_81 = torch.ops.aten.native_batch_norm.default(convolution_default_81, primals_491, primals_487, primals_489, primals_490, True, 0.1, 0.001);  primals_487 = None
        getitem_251 = native_batch_norm_default_81[0]
        getitem_252 = native_batch_norm_default_81[1]
        getitem_253 = native_batch_norm_default_81[2];  native_batch_norm_default_81 = None
        new_zeros_default_81 = torch.ops.aten.new_zeros.default(convolution_default_81, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_81 = torch.ops.aten.relu_.default(getitem_251);  getitem_251 = None
        convolution_default_82 = torch.ops.aten.convolution.default(relu__default_81, primals_498, None, [1, 1], [0, 1], [1, 1], False, [0, 0], 1)
        add__tensor_82 = torch.ops.aten.add_.Tensor(primals_494, 1);  primals_494 = None
        native_batch_norm_default_82 = torch.ops.aten.native_batch_norm.default(convolution_default_82, primals_497, primals_493, primals_495, primals_496, True, 0.1, 0.001);  primals_493 = None
        getitem_254 = native_batch_norm_default_82[0]
        getitem_255 = native_batch_norm_default_82[1]
        getitem_256 = native_batch_norm_default_82[2];  native_batch_norm_default_82 = None
        new_zeros_default_82 = torch.ops.aten.new_zeros.default(convolution_default_82, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_82 = torch.ops.aten.relu_.default(getitem_254);  getitem_254 = None
        convolution_default_83 = torch.ops.aten.convolution.default(relu__default_81, primals_504, None, [1, 1], [1, 0], [1, 1], False, [0, 0], 1)
        add__tensor_83 = torch.ops.aten.add_.Tensor(primals_500, 1);  primals_500 = None
        native_batch_norm_default_83 = torch.ops.aten.native_batch_norm.default(convolution_default_83, primals_503, primals_499, primals_501, primals_502, True, 0.1, 0.001);  primals_499 = None
        getitem_257 = native_batch_norm_default_83[0]
        getitem_258 = native_batch_norm_default_83[1]
        getitem_259 = native_batch_norm_default_83[2];  native_batch_norm_default_83 = None
        new_zeros_default_83 = torch.ops.aten.new_zeros.default(convolution_default_83, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_83 = torch.ops.aten.relu_.default(getitem_257);  getitem_257 = None
        cat_default_10 = torch.ops.aten.cat.default([relu__default_82, relu__default_83], 1)
        avg_pool2d_default_7 = torch.ops.aten.avg_pool2d.default(cat_default_8, [3, 3], [1, 1], [1, 1])
        convolution_default_84 = torch.ops.aten.convolution.default(avg_pool2d_default_7, primals_510, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_84 = torch.ops.aten.add_.Tensor(primals_506, 1);  primals_506 = None
        native_batch_norm_default_84 = torch.ops.aten.native_batch_norm.default(convolution_default_84, primals_509, primals_505, primals_507, primals_508, True, 0.1, 0.001);  primals_505 = None
        getitem_260 = native_batch_norm_default_84[0]
        getitem_261 = native_batch_norm_default_84[1]
        getitem_262 = native_batch_norm_default_84[2];  native_batch_norm_default_84 = None
        new_zeros_default_84 = torch.ops.aten.new_zeros.default(convolution_default_84, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_84 = torch.ops.aten.relu_.default(getitem_260);  getitem_260 = None
        cat_default_11 = torch.ops.aten.cat.default([relu__default_76, cat_default_9, cat_default_10, relu__default_84], 1);  cat_default_9 = cat_default_10 = None
        convolution_default_85 = torch.ops.aten.convolution.default(cat_default_11, primals_516, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_85 = torch.ops.aten.add_.Tensor(primals_512, 1);  primals_512 = None
        native_batch_norm_default_85 = torch.ops.aten.native_batch_norm.default(convolution_default_85, primals_515, primals_511, primals_513, primals_514, True, 0.1, 0.001);  primals_511 = None
        getitem_263 = native_batch_norm_default_85[0]
        getitem_264 = native_batch_norm_default_85[1]
        getitem_265 = native_batch_norm_default_85[2];  native_batch_norm_default_85 = None
        new_zeros_default_85 = torch.ops.aten.new_zeros.default(convolution_default_85, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_85 = torch.ops.aten.relu_.default(getitem_263);  getitem_263 = None
        convolution_default_86 = torch.ops.aten.convolution.default(cat_default_11, primals_522, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_86 = torch.ops.aten.add_.Tensor(primals_518, 1);  primals_518 = None
        native_batch_norm_default_86 = torch.ops.aten.native_batch_norm.default(convolution_default_86, primals_521, primals_517, primals_519, primals_520, True, 0.1, 0.001);  primals_517 = None
        getitem_266 = native_batch_norm_default_86[0]
        getitem_267 = native_batch_norm_default_86[1]
        getitem_268 = native_batch_norm_default_86[2];  native_batch_norm_default_86 = None
        new_zeros_default_86 = torch.ops.aten.new_zeros.default(convolution_default_86, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_86 = torch.ops.aten.relu_.default(getitem_266);  getitem_266 = None
        convolution_default_87 = torch.ops.aten.convolution.default(relu__default_86, primals_528, None, [1, 1], [0, 1], [1, 1], False, [0, 0], 1)
        add__tensor_87 = torch.ops.aten.add_.Tensor(primals_524, 1);  primals_524 = None
        native_batch_norm_default_87 = torch.ops.aten.native_batch_norm.default(convolution_default_87, primals_527, primals_523, primals_525, primals_526, True, 0.1, 0.001);  primals_523 = None
        getitem_269 = native_batch_norm_default_87[0]
        getitem_270 = native_batch_norm_default_87[1]
        getitem_271 = native_batch_norm_default_87[2];  native_batch_norm_default_87 = None
        new_zeros_default_87 = torch.ops.aten.new_zeros.default(convolution_default_87, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_87 = torch.ops.aten.relu_.default(getitem_269);  getitem_269 = None
        convolution_default_88 = torch.ops.aten.convolution.default(relu__default_86, primals_534, None, [1, 1], [1, 0], [1, 1], False, [0, 0], 1)
        add__tensor_88 = torch.ops.aten.add_.Tensor(primals_530, 1);  primals_530 = None
        native_batch_norm_default_88 = torch.ops.aten.native_batch_norm.default(convolution_default_88, primals_533, primals_529, primals_531, primals_532, True, 0.1, 0.001);  primals_529 = None
        getitem_272 = native_batch_norm_default_88[0]
        getitem_273 = native_batch_norm_default_88[1]
        getitem_274 = native_batch_norm_default_88[2];  native_batch_norm_default_88 = None
        new_zeros_default_88 = torch.ops.aten.new_zeros.default(convolution_default_88, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_88 = torch.ops.aten.relu_.default(getitem_272);  getitem_272 = None
        cat_default_12 = torch.ops.aten.cat.default([relu__default_87, relu__default_88], 1)
        convolution_default_89 = torch.ops.aten.convolution.default(cat_default_11, primals_540, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_89 = torch.ops.aten.add_.Tensor(primals_536, 1);  primals_536 = None
        native_batch_norm_default_89 = torch.ops.aten.native_batch_norm.default(convolution_default_89, primals_539, primals_535, primals_537, primals_538, True, 0.1, 0.001);  primals_535 = None
        getitem_275 = native_batch_norm_default_89[0]
        getitem_276 = native_batch_norm_default_89[1]
        getitem_277 = native_batch_norm_default_89[2];  native_batch_norm_default_89 = None
        new_zeros_default_89 = torch.ops.aten.new_zeros.default(convolution_default_89, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_89 = torch.ops.aten.relu_.default(getitem_275);  getitem_275 = None
        convolution_default_90 = torch.ops.aten.convolution.default(relu__default_89, primals_546, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_90 = torch.ops.aten.add_.Tensor(primals_542, 1);  primals_542 = None
        native_batch_norm_default_90 = torch.ops.aten.native_batch_norm.default(convolution_default_90, primals_545, primals_541, primals_543, primals_544, True, 0.1, 0.001);  primals_541 = None
        getitem_278 = native_batch_norm_default_90[0]
        getitem_279 = native_batch_norm_default_90[1]
        getitem_280 = native_batch_norm_default_90[2];  native_batch_norm_default_90 = None
        new_zeros_default_90 = torch.ops.aten.new_zeros.default(convolution_default_90, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_90 = torch.ops.aten.relu_.default(getitem_278);  getitem_278 = None
        convolution_default_91 = torch.ops.aten.convolution.default(relu__default_90, primals_552, None, [1, 1], [0, 1], [1, 1], False, [0, 0], 1)
        add__tensor_91 = torch.ops.aten.add_.Tensor(primals_548, 1);  primals_548 = None
        native_batch_norm_default_91 = torch.ops.aten.native_batch_norm.default(convolution_default_91, primals_551, primals_547, primals_549, primals_550, True, 0.1, 0.001);  primals_547 = None
        getitem_281 = native_batch_norm_default_91[0]
        getitem_282 = native_batch_norm_default_91[1]
        getitem_283 = native_batch_norm_default_91[2];  native_batch_norm_default_91 = None
        new_zeros_default_91 = torch.ops.aten.new_zeros.default(convolution_default_91, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_91 = torch.ops.aten.relu_.default(getitem_281);  getitem_281 = None
        convolution_default_92 = torch.ops.aten.convolution.default(relu__default_90, primals_558, None, [1, 1], [1, 0], [1, 1], False, [0, 0], 1)
        add__tensor_92 = torch.ops.aten.add_.Tensor(primals_554, 1);  primals_554 = None
        native_batch_norm_default_92 = torch.ops.aten.native_batch_norm.default(convolution_default_92, primals_557, primals_553, primals_555, primals_556, True, 0.1, 0.001);  primals_553 = None
        getitem_284 = native_batch_norm_default_92[0]
        getitem_285 = native_batch_norm_default_92[1]
        getitem_286 = native_batch_norm_default_92[2];  native_batch_norm_default_92 = None
        new_zeros_default_92 = torch.ops.aten.new_zeros.default(convolution_default_92, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_92 = torch.ops.aten.relu_.default(getitem_284);  getitem_284 = None
        cat_default_13 = torch.ops.aten.cat.default([relu__default_91, relu__default_92], 1)
        avg_pool2d_default_8 = torch.ops.aten.avg_pool2d.default(cat_default_11, [3, 3], [1, 1], [1, 1])
        convolution_default_93 = torch.ops.aten.convolution.default(avg_pool2d_default_8, primals_564, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_93 = torch.ops.aten.add_.Tensor(primals_560, 1);  primals_560 = None
        native_batch_norm_default_93 = torch.ops.aten.native_batch_norm.default(convolution_default_93, primals_563, primals_559, primals_561, primals_562, True, 0.1, 0.001);  primals_559 = None
        getitem_287 = native_batch_norm_default_93[0]
        getitem_288 = native_batch_norm_default_93[1]
        getitem_289 = native_batch_norm_default_93[2];  native_batch_norm_default_93 = None
        new_zeros_default_93 = torch.ops.aten.new_zeros.default(convolution_default_93, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_93 = torch.ops.aten.relu_.default(getitem_287);  getitem_287 = None
        cat_default_14 = torch.ops.aten.cat.default([relu__default_85, cat_default_12, cat_default_13, relu__default_93], 1);  cat_default_12 = cat_default_13 = None
        mean_dim = torch.ops.aten.mean.dim(cat_default_14, [-1, -2], True);  cat_default_14 = None
        view_default = torch.ops.aten.view.default(mean_dim, [128, 2048]);  mean_dim = None
        t_default = torch.ops.aten.t.default(primals_566);  primals_566 = None
        addmm_default = torch.ops.aten.addmm.default(primals_565, view_default, t_default);  primals_565 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(addmm_default, tangents_1)
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, view_default);  t_default_2 = view_default = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_1 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        view_default_2 = torch.ops.aten.view.default(mm_default, [128, 2048, 1, 1]);  mm_default = None
        expand_default = torch.ops.aten.expand.default(view_default_2, [128, 2048, 8, 8]);  view_default_2 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 64);  expand_default = None
        slice_tensor = torch.ops.aten.slice.Tensor(div_scalar, 1, 0, 320)
        slice_tensor_1 = torch.ops.aten.slice.Tensor(div_scalar, 1, 320, 1088)
        slice_tensor_2 = torch.ops.aten.slice.Tensor(div_scalar, 1, 1088, 1856)
        slice_tensor_3 = torch.ops.aten.slice.Tensor(div_scalar, 1, 1856, 2048);  div_scalar = None
        to_dtype = torch.ops.aten.to.dtype(slice_tensor_3, torch.float32);  slice_tensor_3 = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default_93, torch.float32);  relu__default_93 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default_94 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_94, to_dtype);  le_scalar = new_zeros_default_94 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_2, convolution_default_93, primals_563, primals_561, primals_562, getitem_288, getitem_289, True, 0.001, [True, True, True]);  to_dtype_2 = convolution_default_93 = primals_563 = primals_561 = primals_562 = getitem_288 = getitem_289 = None
        getitem_290 = native_batch_norm_backward_default[0]
        getitem_291 = native_batch_norm_backward_default[1]
        getitem_292 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(getitem_290, avg_pool2d_default_8, primals_564, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_290 = avg_pool2d_default_8 = primals_564 = None
        getitem_293 = convolution_backward_default[0]
        getitem_294 = convolution_backward_default[1]
        getitem_295 = convolution_backward_default[2];  convolution_backward_default = None
        avg_pool2d_backward_default = torch.ops.aten.avg_pool2d_backward.default(getitem_293, cat_default_11, [3, 3], [1, 1], [1, 1], False, True, None);  getitem_293 = None
        slice_tensor_4 = torch.ops.aten.slice.Tensor(slice_tensor_2, 1, 0, 384)
        slice_tensor_5 = torch.ops.aten.slice.Tensor(slice_tensor_2, 1, 384, 768);  slice_tensor_2 = None
        to_dtype_3 = torch.ops.aten.to.dtype(slice_tensor_5, torch.float32);  slice_tensor_5 = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu__default_92, torch.float32);  relu__default_92 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_95 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_95, to_dtype_3);  le_scalar_1 = new_zeros_default_95 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_5, convolution_default_92, primals_557, primals_555, primals_556, getitem_285, getitem_286, True, 0.001, [True, True, True]);  to_dtype_5 = convolution_default_92 = primals_557 = primals_555 = primals_556 = getitem_285 = getitem_286 = None
        getitem_296 = native_batch_norm_backward_default_1[0]
        getitem_297 = native_batch_norm_backward_default_1[1]
        getitem_298 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_296, relu__default_90, primals_558, [0], [1, 1], [1, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_296 = primals_558 = None
        getitem_299 = convolution_backward_default_1[0]
        getitem_300 = convolution_backward_default_1[1]
        getitem_301 = convolution_backward_default_1[2];  convolution_backward_default_1 = None
        to_dtype_6 = torch.ops.aten.to.dtype(slice_tensor_4, torch.float32);  slice_tensor_4 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_91, torch.float32);  relu__default_91 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_96 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_96, to_dtype_6);  le_scalar_2 = new_zeros_default_96 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_8, convolution_default_91, primals_551, primals_549, primals_550, getitem_282, getitem_283, True, 0.001, [True, True, True]);  to_dtype_8 = convolution_default_91 = primals_551 = primals_549 = primals_550 = getitem_282 = getitem_283 = None
        getitem_302 = native_batch_norm_backward_default_2[0]
        getitem_303 = native_batch_norm_backward_default_2[1]
        getitem_304 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_302, relu__default_90, primals_552, [0], [1, 1], [0, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_302 = primals_552 = None
        getitem_305 = convolution_backward_default_2[0]
        getitem_306 = convolution_backward_default_2[1]
        getitem_307 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        add_tensor = torch.ops.aten.add.Tensor(getitem_299, getitem_305);  getitem_299 = getitem_305 = None
        to_dtype_9 = torch.ops.aten.to.dtype(add_tensor, torch.float32);  add_tensor = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu__default_90, torch.float32);  relu__default_90 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_97 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_97, to_dtype_9);  le_scalar_3 = new_zeros_default_97 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_90, primals_545, primals_543, primals_544, getitem_279, getitem_280, True, 0.001, [True, True, True]);  to_dtype_11 = convolution_default_90 = primals_545 = primals_543 = primals_544 = getitem_279 = getitem_280 = None
        getitem_308 = native_batch_norm_backward_default_3[0]
        getitem_309 = native_batch_norm_backward_default_3[1]
        getitem_310 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_308, relu__default_89, primals_546, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_308 = primals_546 = None
        getitem_311 = convolution_backward_default_3[0]
        getitem_312 = convolution_backward_default_3[1]
        getitem_313 = convolution_backward_default_3[2];  convolution_backward_default_3 = None
        to_dtype_12 = torch.ops.aten.to.dtype(getitem_311, torch.float32);  getitem_311 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_89, torch.float32);  relu__default_89 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_98 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_98, to_dtype_12);  le_scalar_4 = new_zeros_default_98 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_89, primals_539, primals_537, primals_538, getitem_276, getitem_277, True, 0.001, [True, True, True]);  to_dtype_14 = convolution_default_89 = primals_539 = primals_537 = primals_538 = getitem_276 = getitem_277 = None
        getitem_314 = native_batch_norm_backward_default_4[0]
        getitem_315 = native_batch_norm_backward_default_4[1]
        getitem_316 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_314, cat_default_11, primals_540, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_314 = primals_540 = None
        getitem_317 = convolution_backward_default_4[0]
        getitem_318 = convolution_backward_default_4[1]
        getitem_319 = convolution_backward_default_4[2];  convolution_backward_default_4 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default, getitem_317);  avg_pool2d_backward_default = getitem_317 = None
        slice_tensor_6 = torch.ops.aten.slice.Tensor(slice_tensor_1, 1, 0, 384)
        slice_tensor_7 = torch.ops.aten.slice.Tensor(slice_tensor_1, 1, 384, 768);  slice_tensor_1 = None
        to_dtype_15 = torch.ops.aten.to.dtype(slice_tensor_7, torch.float32);  slice_tensor_7 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu__default_88, torch.float32);  relu__default_88 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_99 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_99, to_dtype_15);  le_scalar_5 = new_zeros_default_99 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_17, convolution_default_88, primals_533, primals_531, primals_532, getitem_273, getitem_274, True, 0.001, [True, True, True]);  to_dtype_17 = convolution_default_88 = primals_533 = primals_531 = primals_532 = getitem_273 = getitem_274 = None
        getitem_320 = native_batch_norm_backward_default_5[0]
        getitem_321 = native_batch_norm_backward_default_5[1]
        getitem_322 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_320, relu__default_86, primals_534, [0], [1, 1], [1, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_320 = primals_534 = None
        getitem_323 = convolution_backward_default_5[0]
        getitem_324 = convolution_backward_default_5[1]
        getitem_325 = convolution_backward_default_5[2];  convolution_backward_default_5 = None
        to_dtype_18 = torch.ops.aten.to.dtype(slice_tensor_6, torch.float32);  slice_tensor_6 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu__default_87, torch.float32);  relu__default_87 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_100 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_100, to_dtype_18);  le_scalar_6 = new_zeros_default_100 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_20, convolution_default_87, primals_527, primals_525, primals_526, getitem_270, getitem_271, True, 0.001, [True, True, True]);  to_dtype_20 = convolution_default_87 = primals_527 = primals_525 = primals_526 = getitem_270 = getitem_271 = None
        getitem_326 = native_batch_norm_backward_default_6[0]
        getitem_327 = native_batch_norm_backward_default_6[1]
        getitem_328 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(getitem_326, relu__default_86, primals_528, [0], [1, 1], [0, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_326 = primals_528 = None
        getitem_329 = convolution_backward_default_6[0]
        getitem_330 = convolution_backward_default_6[1]
        getitem_331 = convolution_backward_default_6[2];  convolution_backward_default_6 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(getitem_323, getitem_329);  getitem_323 = getitem_329 = None
        to_dtype_21 = torch.ops.aten.to.dtype(add_tensor_2, torch.float32);  add_tensor_2 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_86, torch.float32);  relu__default_86 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_101 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_101, to_dtype_21);  le_scalar_7 = new_zeros_default_101 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_23, convolution_default_86, primals_521, primals_519, primals_520, getitem_267, getitem_268, True, 0.001, [True, True, True]);  to_dtype_23 = convolution_default_86 = primals_521 = primals_519 = primals_520 = getitem_267 = getitem_268 = None
        getitem_332 = native_batch_norm_backward_default_7[0]
        getitem_333 = native_batch_norm_backward_default_7[1]
        getitem_334 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(getitem_332, cat_default_11, primals_522, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_332 = primals_522 = None
        getitem_335 = convolution_backward_default_7[0]
        getitem_336 = convolution_backward_default_7[1]
        getitem_337 = convolution_backward_default_7[2];  convolution_backward_default_7 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(add_tensor_1, getitem_335);  add_tensor_1 = getitem_335 = None
        to_dtype_24 = torch.ops.aten.to.dtype(slice_tensor, torch.float32);  slice_tensor = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_85, torch.float32);  relu__default_85 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_102 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_102, to_dtype_24);  le_scalar_8 = new_zeros_default_102 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_85, primals_515, primals_513, primals_514, getitem_264, getitem_265, True, 0.001, [True, True, True]);  to_dtype_26 = convolution_default_85 = primals_515 = primals_513 = primals_514 = getitem_264 = getitem_265 = None
        getitem_338 = native_batch_norm_backward_default_8[0]
        getitem_339 = native_batch_norm_backward_default_8[1]
        getitem_340 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(getitem_338, cat_default_11, primals_516, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_338 = cat_default_11 = primals_516 = None
        getitem_341 = convolution_backward_default_8[0]
        getitem_342 = convolution_backward_default_8[1]
        getitem_343 = convolution_backward_default_8[2];  convolution_backward_default_8 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(add_tensor_3, getitem_341);  add_tensor_3 = getitem_341 = None
        slice_tensor_8 = torch.ops.aten.slice.Tensor(add_tensor_4, 1, 0, 320)
        slice_tensor_9 = torch.ops.aten.slice.Tensor(add_tensor_4, 1, 320, 1088)
        slice_tensor_10 = torch.ops.aten.slice.Tensor(add_tensor_4, 1, 1088, 1856)
        slice_tensor_11 = torch.ops.aten.slice.Tensor(add_tensor_4, 1, 1856, 2048);  add_tensor_4 = None
        to_dtype_27 = torch.ops.aten.to.dtype(slice_tensor_11, torch.float32);  slice_tensor_11 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu__default_84, torch.float32);  relu__default_84 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_103 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_103, to_dtype_27);  le_scalar_9 = new_zeros_default_103 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_29, convolution_default_84, primals_509, primals_507, primals_508, getitem_261, getitem_262, True, 0.001, [True, True, True]);  to_dtype_29 = convolution_default_84 = primals_509 = primals_507 = primals_508 = getitem_261 = getitem_262 = None
        getitem_344 = native_batch_norm_backward_default_9[0]
        getitem_345 = native_batch_norm_backward_default_9[1]
        getitem_346 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_344, avg_pool2d_default_7, primals_510, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_344 = avg_pool2d_default_7 = primals_510 = None
        getitem_347 = convolution_backward_default_9[0]
        getitem_348 = convolution_backward_default_9[1]
        getitem_349 = convolution_backward_default_9[2];  convolution_backward_default_9 = None
        avg_pool2d_backward_default_1 = torch.ops.aten.avg_pool2d_backward.default(getitem_347, cat_default_8, [3, 3], [1, 1], [1, 1], False, True, None);  getitem_347 = None
        slice_tensor_12 = torch.ops.aten.slice.Tensor(slice_tensor_10, 1, 0, 384)
        slice_tensor_13 = torch.ops.aten.slice.Tensor(slice_tensor_10, 1, 384, 768);  slice_tensor_10 = None
        to_dtype_30 = torch.ops.aten.to.dtype(slice_tensor_13, torch.float32);  slice_tensor_13 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu__default_83, torch.float32);  relu__default_83 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_104 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_104, to_dtype_30);  le_scalar_10 = new_zeros_default_104 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default_83, primals_503, primals_501, primals_502, getitem_258, getitem_259, True, 0.001, [True, True, True]);  to_dtype_32 = convolution_default_83 = primals_503 = primals_501 = primals_502 = getitem_258 = getitem_259 = None
        getitem_350 = native_batch_norm_backward_default_10[0]
        getitem_351 = native_batch_norm_backward_default_10[1]
        getitem_352 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_350, relu__default_81, primals_504, [0], [1, 1], [1, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_350 = primals_504 = None
        getitem_353 = convolution_backward_default_10[0]
        getitem_354 = convolution_backward_default_10[1]
        getitem_355 = convolution_backward_default_10[2];  convolution_backward_default_10 = None
        to_dtype_33 = torch.ops.aten.to.dtype(slice_tensor_12, torch.float32);  slice_tensor_12 = None
        to_dtype_34 = torch.ops.aten.to.dtype(relu__default_82, torch.float32);  relu__default_82 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        new_zeros_default_105 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_105, to_dtype_33);  le_scalar_11 = new_zeros_default_105 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_35, convolution_default_82, primals_497, primals_495, primals_496, getitem_255, getitem_256, True, 0.001, [True, True, True]);  to_dtype_35 = convolution_default_82 = primals_497 = primals_495 = primals_496 = getitem_255 = getitem_256 = None
        getitem_356 = native_batch_norm_backward_default_11[0]
        getitem_357 = native_batch_norm_backward_default_11[1]
        getitem_358 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_356, relu__default_81, primals_498, [0], [1, 1], [0, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_356 = primals_498 = None
        getitem_359 = convolution_backward_default_11[0]
        getitem_360 = convolution_backward_default_11[1]
        getitem_361 = convolution_backward_default_11[2];  convolution_backward_default_11 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(getitem_353, getitem_359);  getitem_353 = getitem_359 = None
        to_dtype_36 = torch.ops.aten.to.dtype(add_tensor_5, torch.float32);  add_tensor_5 = None
        to_dtype_37 = torch.ops.aten.to.dtype(relu__default_81, torch.float32);  relu__default_81 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        new_zeros_default_106 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_106, to_dtype_36);  le_scalar_12 = new_zeros_default_106 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_38, convolution_default_81, primals_491, primals_489, primals_490, getitem_252, getitem_253, True, 0.001, [True, True, True]);  to_dtype_38 = convolution_default_81 = primals_491 = primals_489 = primals_490 = getitem_252 = getitem_253 = None
        getitem_362 = native_batch_norm_backward_default_12[0]
        getitem_363 = native_batch_norm_backward_default_12[1]
        getitem_364 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(getitem_362, relu__default_80, primals_492, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_362 = primals_492 = None
        getitem_365 = convolution_backward_default_12[0]
        getitem_366 = convolution_backward_default_12[1]
        getitem_367 = convolution_backward_default_12[2];  convolution_backward_default_12 = None
        to_dtype_39 = torch.ops.aten.to.dtype(getitem_365, torch.float32);  getitem_365 = None
        to_dtype_40 = torch.ops.aten.to.dtype(relu__default_80, torch.float32);  relu__default_80 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        new_zeros_default_107 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_107, to_dtype_39);  le_scalar_13 = new_zeros_default_107 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_41, convolution_default_80, primals_485, primals_483, primals_484, getitem_249, getitem_250, True, 0.001, [True, True, True]);  to_dtype_41 = convolution_default_80 = primals_485 = primals_483 = primals_484 = getitem_249 = getitem_250 = None
        getitem_368 = native_batch_norm_backward_default_13[0]
        getitem_369 = native_batch_norm_backward_default_13[1]
        getitem_370 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_368, cat_default_8, primals_486, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_368 = primals_486 = None
        getitem_371 = convolution_backward_default_13[0]
        getitem_372 = convolution_backward_default_13[1]
        getitem_373 = convolution_backward_default_13[2];  convolution_backward_default_13 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default_1, getitem_371);  avg_pool2d_backward_default_1 = getitem_371 = None
        slice_tensor_14 = torch.ops.aten.slice.Tensor(slice_tensor_9, 1, 0, 384)
        slice_tensor_15 = torch.ops.aten.slice.Tensor(slice_tensor_9, 1, 384, 768);  slice_tensor_9 = None
        to_dtype_42 = torch.ops.aten.to.dtype(slice_tensor_15, torch.float32);  slice_tensor_15 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu__default_79, torch.float32);  relu__default_79 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_108 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_108, to_dtype_42);  le_scalar_14 = new_zeros_default_108 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_44, convolution_default_79, primals_479, primals_477, primals_478, getitem_246, getitem_247, True, 0.001, [True, True, True]);  to_dtype_44 = convolution_default_79 = primals_479 = primals_477 = primals_478 = getitem_246 = getitem_247 = None
        getitem_374 = native_batch_norm_backward_default_14[0]
        getitem_375 = native_batch_norm_backward_default_14[1]
        getitem_376 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_374, relu__default_77, primals_480, [0], [1, 1], [1, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_374 = primals_480 = None
        getitem_377 = convolution_backward_default_14[0]
        getitem_378 = convolution_backward_default_14[1]
        getitem_379 = convolution_backward_default_14[2];  convolution_backward_default_14 = None
        to_dtype_45 = torch.ops.aten.to.dtype(slice_tensor_14, torch.float32);  slice_tensor_14 = None
        to_dtype_46 = torch.ops.aten.to.dtype(relu__default_78, torch.float32);  relu__default_78 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_46, 0);  to_dtype_46 = None
        new_zeros_default_109 = torch.ops.aten.new_zeros.default(to_dtype_45, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_109, to_dtype_45);  le_scalar_15 = new_zeros_default_109 = to_dtype_45 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_47, convolution_default_78, primals_473, primals_471, primals_472, getitem_243, getitem_244, True, 0.001, [True, True, True]);  to_dtype_47 = convolution_default_78 = primals_473 = primals_471 = primals_472 = getitem_243 = getitem_244 = None
        getitem_380 = native_batch_norm_backward_default_15[0]
        getitem_381 = native_batch_norm_backward_default_15[1]
        getitem_382 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_380, relu__default_77, primals_474, [0], [1, 1], [0, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_380 = primals_474 = None
        getitem_383 = convolution_backward_default_15[0]
        getitem_384 = convolution_backward_default_15[1]
        getitem_385 = convolution_backward_default_15[2];  convolution_backward_default_15 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(getitem_377, getitem_383);  getitem_377 = getitem_383 = None
        to_dtype_48 = torch.ops.aten.to.dtype(add_tensor_7, torch.float32);  add_tensor_7 = None
        to_dtype_49 = torch.ops.aten.to.dtype(relu__default_77, torch.float32);  relu__default_77 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_49, 0);  to_dtype_49 = None
        new_zeros_default_110 = torch.ops.aten.new_zeros.default(to_dtype_48, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_110, to_dtype_48);  le_scalar_16 = new_zeros_default_110 = to_dtype_48 = None
        to_dtype_50 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_50, convolution_default_77, primals_467, primals_465, primals_466, getitem_240, getitem_241, True, 0.001, [True, True, True]);  to_dtype_50 = convolution_default_77 = primals_467 = primals_465 = primals_466 = getitem_240 = getitem_241 = None
        getitem_386 = native_batch_norm_backward_default_16[0]
        getitem_387 = native_batch_norm_backward_default_16[1]
        getitem_388 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(getitem_386, cat_default_8, primals_468, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_386 = primals_468 = None
        getitem_389 = convolution_backward_default_16[0]
        getitem_390 = convolution_backward_default_16[1]
        getitem_391 = convolution_backward_default_16[2];  convolution_backward_default_16 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(add_tensor_6, getitem_389);  add_tensor_6 = getitem_389 = None
        to_dtype_51 = torch.ops.aten.to.dtype(slice_tensor_8, torch.float32);  slice_tensor_8 = None
        to_dtype_52 = torch.ops.aten.to.dtype(relu__default_76, torch.float32);  relu__default_76 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_52, 0);  to_dtype_52 = None
        new_zeros_default_111 = torch.ops.aten.new_zeros.default(to_dtype_51, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_17, new_zeros_default_111, to_dtype_51);  le_scalar_17 = new_zeros_default_111 = to_dtype_51 = None
        to_dtype_53 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_53, convolution_default_76, primals_461, primals_459, primals_460, getitem_237, getitem_238, True, 0.001, [True, True, True]);  to_dtype_53 = convolution_default_76 = primals_461 = primals_459 = primals_460 = getitem_237 = getitem_238 = None
        getitem_392 = native_batch_norm_backward_default_17[0]
        getitem_393 = native_batch_norm_backward_default_17[1]
        getitem_394 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(getitem_392, cat_default_8, primals_462, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_392 = cat_default_8 = primals_462 = None
        getitem_395 = convolution_backward_default_17[0]
        getitem_396 = convolution_backward_default_17[1]
        getitem_397 = convolution_backward_default_17[2];  convolution_backward_default_17 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(add_tensor_8, getitem_395);  add_tensor_8 = getitem_395 = None
        slice_tensor_16 = torch.ops.aten.slice.Tensor(add_tensor_9, 1, 0, 320)
        slice_tensor_17 = torch.ops.aten.slice.Tensor(add_tensor_9, 1, 320, 512)
        slice_tensor_18 = torch.ops.aten.slice.Tensor(add_tensor_9, 1, 512, 1280);  add_tensor_9 = None
        max_pool2d_with_indices_backward_default = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_18, cat_default_7, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_235);  slice_tensor_18 = getitem_235 = None
        to_dtype_54 = torch.ops.aten.to.dtype(slice_tensor_17, torch.float32);  slice_tensor_17 = None
        to_dtype_55 = torch.ops.aten.to.dtype(relu__default_75, torch.float32);  relu__default_75 = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_55, 0);  to_dtype_55 = None
        new_zeros_default_112 = torch.ops.aten.new_zeros.default(to_dtype_54, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_18 = torch.ops.aten.where.self(le_scalar_18, new_zeros_default_112, to_dtype_54);  le_scalar_18 = new_zeros_default_112 = to_dtype_54 = None
        to_dtype_56 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_56, convolution_default_75, primals_455, primals_453, primals_454, getitem_232, getitem_233, True, 0.001, [True, True, True]);  to_dtype_56 = convolution_default_75 = primals_455 = primals_453 = primals_454 = getitem_232 = getitem_233 = None
        getitem_398 = native_batch_norm_backward_default_18[0]
        getitem_399 = native_batch_norm_backward_default_18[1]
        getitem_400 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(getitem_398, relu__default_74, primals_456, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_398 = primals_456 = None
        getitem_401 = convolution_backward_default_18[0]
        getitem_402 = convolution_backward_default_18[1]
        getitem_403 = convolution_backward_default_18[2];  convolution_backward_default_18 = None
        to_dtype_57 = torch.ops.aten.to.dtype(getitem_401, torch.float32);  getitem_401 = None
        to_dtype_58 = torch.ops.aten.to.dtype(relu__default_74, torch.float32);  relu__default_74 = None
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_58, 0);  to_dtype_58 = None
        new_zeros_default_113 = torch.ops.aten.new_zeros.default(to_dtype_57, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_19 = torch.ops.aten.where.self(le_scalar_19, new_zeros_default_113, to_dtype_57);  le_scalar_19 = new_zeros_default_113 = to_dtype_57 = None
        to_dtype_59 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_59, convolution_default_74, primals_449, primals_447, primals_448, getitem_229, getitem_230, True, 0.001, [True, True, True]);  to_dtype_59 = convolution_default_74 = primals_449 = primals_447 = primals_448 = getitem_229 = getitem_230 = None
        getitem_404 = native_batch_norm_backward_default_19[0]
        getitem_405 = native_batch_norm_backward_default_19[1]
        getitem_406 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_404, relu__default_73, primals_450, [0], [1, 1], [3, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_404 = primals_450 = None
        getitem_407 = convolution_backward_default_19[0]
        getitem_408 = convolution_backward_default_19[1]
        getitem_409 = convolution_backward_default_19[2];  convolution_backward_default_19 = None
        to_dtype_60 = torch.ops.aten.to.dtype(getitem_407, torch.float32);  getitem_407 = None
        to_dtype_61 = torch.ops.aten.to.dtype(relu__default_73, torch.float32);  relu__default_73 = None
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_61, 0);  to_dtype_61 = None
        new_zeros_default_114 = torch.ops.aten.new_zeros.default(to_dtype_60, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_20 = torch.ops.aten.where.self(le_scalar_20, new_zeros_default_114, to_dtype_60);  le_scalar_20 = new_zeros_default_114 = to_dtype_60 = None
        to_dtype_62 = torch.ops.aten.to.dtype(where_self_20, torch.float32);  where_self_20 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_62, convolution_default_73, primals_443, primals_441, primals_442, getitem_226, getitem_227, True, 0.001, [True, True, True]);  to_dtype_62 = convolution_default_73 = primals_443 = primals_441 = primals_442 = getitem_226 = getitem_227 = None
        getitem_410 = native_batch_norm_backward_default_20[0]
        getitem_411 = native_batch_norm_backward_default_20[1]
        getitem_412 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(getitem_410, relu__default_72, primals_444, [0], [1, 1], [0, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_410 = primals_444 = None
        getitem_413 = convolution_backward_default_20[0]
        getitem_414 = convolution_backward_default_20[1]
        getitem_415 = convolution_backward_default_20[2];  convolution_backward_default_20 = None
        to_dtype_63 = torch.ops.aten.to.dtype(getitem_413, torch.float32);  getitem_413 = None
        to_dtype_64 = torch.ops.aten.to.dtype(relu__default_72, torch.float32);  relu__default_72 = None
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_64, 0);  to_dtype_64 = None
        new_zeros_default_115 = torch.ops.aten.new_zeros.default(to_dtype_63, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_21 = torch.ops.aten.where.self(le_scalar_21, new_zeros_default_115, to_dtype_63);  le_scalar_21 = new_zeros_default_115 = to_dtype_63 = None
        to_dtype_65 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_65, convolution_default_72, primals_437, primals_435, primals_436, getitem_223, getitem_224, True, 0.001, [True, True, True]);  to_dtype_65 = convolution_default_72 = primals_437 = primals_435 = primals_436 = getitem_223 = getitem_224 = None
        getitem_416 = native_batch_norm_backward_default_21[0]
        getitem_417 = native_batch_norm_backward_default_21[1]
        getitem_418 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(getitem_416, cat_default_7, primals_438, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_416 = primals_438 = None
        getitem_419 = convolution_backward_default_21[0]
        getitem_420 = convolution_backward_default_21[1]
        getitem_421 = convolution_backward_default_21[2];  convolution_backward_default_21 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(max_pool2d_with_indices_backward_default, getitem_419);  max_pool2d_with_indices_backward_default = getitem_419 = None
        to_dtype_66 = torch.ops.aten.to.dtype(slice_tensor_16, torch.float32);  slice_tensor_16 = None
        to_dtype_67 = torch.ops.aten.to.dtype(relu__default_71, torch.float32);  relu__default_71 = None
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_67, 0);  to_dtype_67 = None
        new_zeros_default_116 = torch.ops.aten.new_zeros.default(to_dtype_66, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_22 = torch.ops.aten.where.self(le_scalar_22, new_zeros_default_116, to_dtype_66);  le_scalar_22 = new_zeros_default_116 = to_dtype_66 = None
        to_dtype_68 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_68, convolution_default_71, primals_431, primals_429, primals_430, getitem_220, getitem_221, True, 0.001, [True, True, True]);  to_dtype_68 = convolution_default_71 = primals_431 = primals_429 = primals_430 = getitem_220 = getitem_221 = None
        getitem_422 = native_batch_norm_backward_default_22[0]
        getitem_423 = native_batch_norm_backward_default_22[1]
        getitem_424 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(getitem_422, relu__default_70, primals_432, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_422 = primals_432 = None
        getitem_425 = convolution_backward_default_22[0]
        getitem_426 = convolution_backward_default_22[1]
        getitem_427 = convolution_backward_default_22[2];  convolution_backward_default_22 = None
        to_dtype_69 = torch.ops.aten.to.dtype(getitem_425, torch.float32);  getitem_425 = None
        to_dtype_70 = torch.ops.aten.to.dtype(relu__default_70, torch.float32);  relu__default_70 = None
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_70, 0);  to_dtype_70 = None
        new_zeros_default_117 = torch.ops.aten.new_zeros.default(to_dtype_69, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(le_scalar_23, new_zeros_default_117, to_dtype_69);  le_scalar_23 = new_zeros_default_117 = to_dtype_69 = None
        to_dtype_71 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_71, convolution_default_70, primals_425, primals_423, primals_424, getitem_217, getitem_218, True, 0.001, [True, True, True]);  to_dtype_71 = convolution_default_70 = primals_425 = primals_423 = primals_424 = getitem_217 = getitem_218 = None
        getitem_428 = native_batch_norm_backward_default_23[0]
        getitem_429 = native_batch_norm_backward_default_23[1]
        getitem_430 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(getitem_428, cat_default_7, primals_426, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_428 = cat_default_7 = primals_426 = None
        getitem_431 = convolution_backward_default_23[0]
        getitem_432 = convolution_backward_default_23[1]
        getitem_433 = convolution_backward_default_23[2];  convolution_backward_default_23 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(add_tensor_10, getitem_431);  add_tensor_10 = getitem_431 = None
        slice_tensor_19 = torch.ops.aten.slice.Tensor(add_tensor_11, 1, 0, 192)
        slice_tensor_20 = torch.ops.aten.slice.Tensor(add_tensor_11, 1, 192, 384)
        slice_tensor_21 = torch.ops.aten.slice.Tensor(add_tensor_11, 1, 384, 576)
        slice_tensor_22 = torch.ops.aten.slice.Tensor(add_tensor_11, 1, 576, 768);  add_tensor_11 = None
        to_dtype_72 = torch.ops.aten.to.dtype(slice_tensor_22, torch.float32);  slice_tensor_22 = None
        to_dtype_73 = torch.ops.aten.to.dtype(relu__default_69, torch.float32);  relu__default_69 = None
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_73, 0);  to_dtype_73 = None
        new_zeros_default_118 = torch.ops.aten.new_zeros.default(to_dtype_72, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_24 = torch.ops.aten.where.self(le_scalar_24, new_zeros_default_118, to_dtype_72);  le_scalar_24 = new_zeros_default_118 = to_dtype_72 = None
        to_dtype_74 = torch.ops.aten.to.dtype(where_self_24, torch.float32);  where_self_24 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_74, convolution_default_69, primals_419, primals_417, primals_418, getitem_214, getitem_215, True, 0.001, [True, True, True]);  to_dtype_74 = convolution_default_69 = primals_419 = primals_417 = primals_418 = getitem_214 = getitem_215 = None
        getitem_434 = native_batch_norm_backward_default_24[0]
        getitem_435 = native_batch_norm_backward_default_24[1]
        getitem_436 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_434, avg_pool2d_default_6, primals_420, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_434 = avg_pool2d_default_6 = primals_420 = None
        getitem_437 = convolution_backward_default_24[0]
        getitem_438 = convolution_backward_default_24[1]
        getitem_439 = convolution_backward_default_24[2];  convolution_backward_default_24 = None
        avg_pool2d_backward_default_2 = torch.ops.aten.avg_pool2d_backward.default(getitem_437, cat_default_6, [3, 3], [1, 1], [1, 1], False, True, None);  getitem_437 = None
        to_dtype_75 = torch.ops.aten.to.dtype(slice_tensor_21, torch.float32);  slice_tensor_21 = None
        to_dtype_76 = torch.ops.aten.to.dtype(relu__default_68, torch.float32);  relu__default_68 = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_76, 0);  to_dtype_76 = None
        new_zeros_default_119 = torch.ops.aten.new_zeros.default(to_dtype_75, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_25 = torch.ops.aten.where.self(le_scalar_25, new_zeros_default_119, to_dtype_75);  le_scalar_25 = new_zeros_default_119 = to_dtype_75 = None
        to_dtype_77 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_77, convolution_default_68, primals_413, primals_411, primals_412, getitem_211, getitem_212, True, 0.001, [True, True, True]);  to_dtype_77 = convolution_default_68 = primals_413 = primals_411 = primals_412 = getitem_211 = getitem_212 = None
        getitem_440 = native_batch_norm_backward_default_25[0]
        getitem_441 = native_batch_norm_backward_default_25[1]
        getitem_442 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_440, relu__default_67, primals_414, [0], [1, 1], [0, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_440 = primals_414 = None
        getitem_443 = convolution_backward_default_25[0]
        getitem_444 = convolution_backward_default_25[1]
        getitem_445 = convolution_backward_default_25[2];  convolution_backward_default_25 = None
        to_dtype_78 = torch.ops.aten.to.dtype(getitem_443, torch.float32);  getitem_443 = None
        to_dtype_79 = torch.ops.aten.to.dtype(relu__default_67, torch.float32);  relu__default_67 = None
        le_scalar_26 = torch.ops.aten.le.Scalar(to_dtype_79, 0);  to_dtype_79 = None
        new_zeros_default_120 = torch.ops.aten.new_zeros.default(to_dtype_78, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_26 = torch.ops.aten.where.self(le_scalar_26, new_zeros_default_120, to_dtype_78);  le_scalar_26 = new_zeros_default_120 = to_dtype_78 = None
        to_dtype_80 = torch.ops.aten.to.dtype(where_self_26, torch.float32);  where_self_26 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_80, convolution_default_67, primals_407, primals_405, primals_406, getitem_208, getitem_209, True, 0.001, [True, True, True]);  to_dtype_80 = convolution_default_67 = primals_407 = primals_405 = primals_406 = getitem_208 = getitem_209 = None
        getitem_446 = native_batch_norm_backward_default_26[0]
        getitem_447 = native_batch_norm_backward_default_26[1]
        getitem_448 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(getitem_446, relu__default_66, primals_408, [0], [1, 1], [3, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_446 = primals_408 = None
        getitem_449 = convolution_backward_default_26[0]
        getitem_450 = convolution_backward_default_26[1]
        getitem_451 = convolution_backward_default_26[2];  convolution_backward_default_26 = None
        to_dtype_81 = torch.ops.aten.to.dtype(getitem_449, torch.float32);  getitem_449 = None
        to_dtype_82 = torch.ops.aten.to.dtype(relu__default_66, torch.float32);  relu__default_66 = None
        le_scalar_27 = torch.ops.aten.le.Scalar(to_dtype_82, 0);  to_dtype_82 = None
        new_zeros_default_121 = torch.ops.aten.new_zeros.default(to_dtype_81, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_27 = torch.ops.aten.where.self(le_scalar_27, new_zeros_default_121, to_dtype_81);  le_scalar_27 = new_zeros_default_121 = to_dtype_81 = None
        to_dtype_83 = torch.ops.aten.to.dtype(where_self_27, torch.float32);  where_self_27 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_83, convolution_default_66, primals_401, primals_399, primals_400, getitem_205, getitem_206, True, 0.001, [True, True, True]);  to_dtype_83 = convolution_default_66 = primals_401 = primals_399 = primals_400 = getitem_205 = getitem_206 = None
        getitem_452 = native_batch_norm_backward_default_27[0]
        getitem_453 = native_batch_norm_backward_default_27[1]
        getitem_454 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(getitem_452, relu__default_65, primals_402, [0], [1, 1], [0, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_452 = primals_402 = None
        getitem_455 = convolution_backward_default_27[0]
        getitem_456 = convolution_backward_default_27[1]
        getitem_457 = convolution_backward_default_27[2];  convolution_backward_default_27 = None
        to_dtype_84 = torch.ops.aten.to.dtype(getitem_455, torch.float32);  getitem_455 = None
        to_dtype_85 = torch.ops.aten.to.dtype(relu__default_65, torch.float32);  relu__default_65 = None
        le_scalar_28 = torch.ops.aten.le.Scalar(to_dtype_85, 0);  to_dtype_85 = None
        new_zeros_default_122 = torch.ops.aten.new_zeros.default(to_dtype_84, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_28 = torch.ops.aten.where.self(le_scalar_28, new_zeros_default_122, to_dtype_84);  le_scalar_28 = new_zeros_default_122 = to_dtype_84 = None
        to_dtype_86 = torch.ops.aten.to.dtype(where_self_28, torch.float32);  where_self_28 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_86, convolution_default_65, primals_395, primals_393, primals_394, getitem_202, getitem_203, True, 0.001, [True, True, True]);  to_dtype_86 = convolution_default_65 = primals_395 = primals_393 = primals_394 = getitem_202 = getitem_203 = None
        getitem_458 = native_batch_norm_backward_default_28[0]
        getitem_459 = native_batch_norm_backward_default_28[1]
        getitem_460 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(getitem_458, relu__default_64, primals_396, [0], [1, 1], [3, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_458 = primals_396 = None
        getitem_461 = convolution_backward_default_28[0]
        getitem_462 = convolution_backward_default_28[1]
        getitem_463 = convolution_backward_default_28[2];  convolution_backward_default_28 = None
        to_dtype_87 = torch.ops.aten.to.dtype(getitem_461, torch.float32);  getitem_461 = None
        to_dtype_88 = torch.ops.aten.to.dtype(relu__default_64, torch.float32);  relu__default_64 = None
        le_scalar_29 = torch.ops.aten.le.Scalar(to_dtype_88, 0);  to_dtype_88 = None
        new_zeros_default_123 = torch.ops.aten.new_zeros.default(to_dtype_87, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_29 = torch.ops.aten.where.self(le_scalar_29, new_zeros_default_123, to_dtype_87);  le_scalar_29 = new_zeros_default_123 = to_dtype_87 = None
        to_dtype_89 = torch.ops.aten.to.dtype(where_self_29, torch.float32);  where_self_29 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_89, convolution_default_64, primals_389, primals_387, primals_388, getitem_199, getitem_200, True, 0.001, [True, True, True]);  to_dtype_89 = convolution_default_64 = primals_389 = primals_387 = primals_388 = getitem_199 = getitem_200 = None
        getitem_464 = native_batch_norm_backward_default_29[0]
        getitem_465 = native_batch_norm_backward_default_29[1]
        getitem_466 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(getitem_464, cat_default_6, primals_390, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_464 = primals_390 = None
        getitem_467 = convolution_backward_default_29[0]
        getitem_468 = convolution_backward_default_29[1]
        getitem_469 = convolution_backward_default_29[2];  convolution_backward_default_29 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default_2, getitem_467);  avg_pool2d_backward_default_2 = getitem_467 = None
        to_dtype_90 = torch.ops.aten.to.dtype(slice_tensor_20, torch.float32);  slice_tensor_20 = None
        to_dtype_91 = torch.ops.aten.to.dtype(relu__default_63, torch.float32);  relu__default_63 = None
        le_scalar_30 = torch.ops.aten.le.Scalar(to_dtype_91, 0);  to_dtype_91 = None
        new_zeros_default_124 = torch.ops.aten.new_zeros.default(to_dtype_90, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_30 = torch.ops.aten.where.self(le_scalar_30, new_zeros_default_124, to_dtype_90);  le_scalar_30 = new_zeros_default_124 = to_dtype_90 = None
        to_dtype_92 = torch.ops.aten.to.dtype(where_self_30, torch.float32);  where_self_30 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_92, convolution_default_63, primals_383, primals_381, primals_382, getitem_196, getitem_197, True, 0.001, [True, True, True]);  to_dtype_92 = convolution_default_63 = primals_383 = primals_381 = primals_382 = getitem_196 = getitem_197 = None
        getitem_470 = native_batch_norm_backward_default_30[0]
        getitem_471 = native_batch_norm_backward_default_30[1]
        getitem_472 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_470, relu__default_62, primals_384, [0], [1, 1], [3, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_470 = primals_384 = None
        getitem_473 = convolution_backward_default_30[0]
        getitem_474 = convolution_backward_default_30[1]
        getitem_475 = convolution_backward_default_30[2];  convolution_backward_default_30 = None
        to_dtype_93 = torch.ops.aten.to.dtype(getitem_473, torch.float32);  getitem_473 = None
        to_dtype_94 = torch.ops.aten.to.dtype(relu__default_62, torch.float32);  relu__default_62 = None
        le_scalar_31 = torch.ops.aten.le.Scalar(to_dtype_94, 0);  to_dtype_94 = None
        new_zeros_default_125 = torch.ops.aten.new_zeros.default(to_dtype_93, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_31 = torch.ops.aten.where.self(le_scalar_31, new_zeros_default_125, to_dtype_93);  le_scalar_31 = new_zeros_default_125 = to_dtype_93 = None
        to_dtype_95 = torch.ops.aten.to.dtype(where_self_31, torch.float32);  where_self_31 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_95, convolution_default_62, primals_377, primals_375, primals_376, getitem_193, getitem_194, True, 0.001, [True, True, True]);  to_dtype_95 = convolution_default_62 = primals_377 = primals_375 = primals_376 = getitem_193 = getitem_194 = None
        getitem_476 = native_batch_norm_backward_default_31[0]
        getitem_477 = native_batch_norm_backward_default_31[1]
        getitem_478 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(getitem_476, relu__default_61, primals_378, [0], [1, 1], [0, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_476 = primals_378 = None
        getitem_479 = convolution_backward_default_31[0]
        getitem_480 = convolution_backward_default_31[1]
        getitem_481 = convolution_backward_default_31[2];  convolution_backward_default_31 = None
        to_dtype_96 = torch.ops.aten.to.dtype(getitem_479, torch.float32);  getitem_479 = None
        to_dtype_97 = torch.ops.aten.to.dtype(relu__default_61, torch.float32);  relu__default_61 = None
        le_scalar_32 = torch.ops.aten.le.Scalar(to_dtype_97, 0);  to_dtype_97 = None
        new_zeros_default_126 = torch.ops.aten.new_zeros.default(to_dtype_96, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_32 = torch.ops.aten.where.self(le_scalar_32, new_zeros_default_126, to_dtype_96);  le_scalar_32 = new_zeros_default_126 = to_dtype_96 = None
        to_dtype_98 = torch.ops.aten.to.dtype(where_self_32, torch.float32);  where_self_32 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_98, convolution_default_61, primals_371, primals_369, primals_370, getitem_190, getitem_191, True, 0.001, [True, True, True]);  to_dtype_98 = convolution_default_61 = primals_371 = primals_369 = primals_370 = getitem_190 = getitem_191 = None
        getitem_482 = native_batch_norm_backward_default_32[0]
        getitem_483 = native_batch_norm_backward_default_32[1]
        getitem_484 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(getitem_482, cat_default_6, primals_372, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_482 = primals_372 = None
        getitem_485 = convolution_backward_default_32[0]
        getitem_486 = convolution_backward_default_32[1]
        getitem_487 = convolution_backward_default_32[2];  convolution_backward_default_32 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(add_tensor_12, getitem_485);  add_tensor_12 = getitem_485 = None
        to_dtype_99 = torch.ops.aten.to.dtype(slice_tensor_19, torch.float32);  slice_tensor_19 = None
        to_dtype_100 = torch.ops.aten.to.dtype(relu__default_60, torch.float32);  relu__default_60 = None
        le_scalar_33 = torch.ops.aten.le.Scalar(to_dtype_100, 0);  to_dtype_100 = None
        new_zeros_default_127 = torch.ops.aten.new_zeros.default(to_dtype_99, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_33 = torch.ops.aten.where.self(le_scalar_33, new_zeros_default_127, to_dtype_99);  le_scalar_33 = new_zeros_default_127 = to_dtype_99 = None
        to_dtype_101 = torch.ops.aten.to.dtype(where_self_33, torch.float32);  where_self_33 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_101, convolution_default_60, primals_365, primals_363, primals_364, getitem_187, getitem_188, True, 0.001, [True, True, True]);  to_dtype_101 = convolution_default_60 = primals_365 = primals_363 = primals_364 = getitem_187 = getitem_188 = None
        getitem_488 = native_batch_norm_backward_default_33[0]
        getitem_489 = native_batch_norm_backward_default_33[1]
        getitem_490 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(getitem_488, cat_default_6, primals_366, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_488 = cat_default_6 = primals_366 = None
        getitem_491 = convolution_backward_default_33[0]
        getitem_492 = convolution_backward_default_33[1]
        getitem_493 = convolution_backward_default_33[2];  convolution_backward_default_33 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(add_tensor_13, getitem_491);  add_tensor_13 = getitem_491 = None
        slice_tensor_23 = torch.ops.aten.slice.Tensor(add_tensor_14, 1, 0, 192)
        slice_tensor_24 = torch.ops.aten.slice.Tensor(add_tensor_14, 1, 192, 384)
        slice_tensor_25 = torch.ops.aten.slice.Tensor(add_tensor_14, 1, 384, 576)
        slice_tensor_26 = torch.ops.aten.slice.Tensor(add_tensor_14, 1, 576, 768);  add_tensor_14 = None
        to_dtype_102 = torch.ops.aten.to.dtype(slice_tensor_26, torch.float32);  slice_tensor_26 = None
        to_dtype_103 = torch.ops.aten.to.dtype(relu__default_59, torch.float32);  relu__default_59 = None
        le_scalar_34 = torch.ops.aten.le.Scalar(to_dtype_103, 0);  to_dtype_103 = None
        new_zeros_default_128 = torch.ops.aten.new_zeros.default(to_dtype_102, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_34 = torch.ops.aten.where.self(le_scalar_34, new_zeros_default_128, to_dtype_102);  le_scalar_34 = new_zeros_default_128 = to_dtype_102 = None
        to_dtype_104 = torch.ops.aten.to.dtype(where_self_34, torch.float32);  where_self_34 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_104, convolution_default_59, primals_359, primals_357, primals_358, getitem_184, getitem_185, True, 0.001, [True, True, True]);  to_dtype_104 = convolution_default_59 = primals_359 = primals_357 = primals_358 = getitem_184 = getitem_185 = None
        getitem_494 = native_batch_norm_backward_default_34[0]
        getitem_495 = native_batch_norm_backward_default_34[1]
        getitem_496 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(getitem_494, avg_pool2d_default_5, primals_360, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_494 = avg_pool2d_default_5 = primals_360 = None
        getitem_497 = convolution_backward_default_34[0]
        getitem_498 = convolution_backward_default_34[1]
        getitem_499 = convolution_backward_default_34[2];  convolution_backward_default_34 = None
        avg_pool2d_backward_default_3 = torch.ops.aten.avg_pool2d_backward.default(getitem_497, cat_default_5, [3, 3], [1, 1], [1, 1], False, True, None);  getitem_497 = None
        to_dtype_105 = torch.ops.aten.to.dtype(slice_tensor_25, torch.float32);  slice_tensor_25 = None
        to_dtype_106 = torch.ops.aten.to.dtype(relu__default_58, torch.float32);  relu__default_58 = None
        le_scalar_35 = torch.ops.aten.le.Scalar(to_dtype_106, 0);  to_dtype_106 = None
        new_zeros_default_129 = torch.ops.aten.new_zeros.default(to_dtype_105, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_35 = torch.ops.aten.where.self(le_scalar_35, new_zeros_default_129, to_dtype_105);  le_scalar_35 = new_zeros_default_129 = to_dtype_105 = None
        to_dtype_107 = torch.ops.aten.to.dtype(where_self_35, torch.float32);  where_self_35 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_107, convolution_default_58, primals_353, primals_351, primals_352, getitem_181, getitem_182, True, 0.001, [True, True, True]);  to_dtype_107 = convolution_default_58 = primals_353 = primals_351 = primals_352 = getitem_181 = getitem_182 = None
        getitem_500 = native_batch_norm_backward_default_35[0]
        getitem_501 = native_batch_norm_backward_default_35[1]
        getitem_502 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_500, relu__default_57, primals_354, [0], [1, 1], [0, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_500 = primals_354 = None
        getitem_503 = convolution_backward_default_35[0]
        getitem_504 = convolution_backward_default_35[1]
        getitem_505 = convolution_backward_default_35[2];  convolution_backward_default_35 = None
        to_dtype_108 = torch.ops.aten.to.dtype(getitem_503, torch.float32);  getitem_503 = None
        to_dtype_109 = torch.ops.aten.to.dtype(relu__default_57, torch.float32);  relu__default_57 = None
        le_scalar_36 = torch.ops.aten.le.Scalar(to_dtype_109, 0);  to_dtype_109 = None
        new_zeros_default_130 = torch.ops.aten.new_zeros.default(to_dtype_108, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_36 = torch.ops.aten.where.self(le_scalar_36, new_zeros_default_130, to_dtype_108);  le_scalar_36 = new_zeros_default_130 = to_dtype_108 = None
        to_dtype_110 = torch.ops.aten.to.dtype(where_self_36, torch.float32);  where_self_36 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_110, convolution_default_57, primals_347, primals_345, primals_346, getitem_178, getitem_179, True, 0.001, [True, True, True]);  to_dtype_110 = convolution_default_57 = primals_347 = primals_345 = primals_346 = getitem_178 = getitem_179 = None
        getitem_506 = native_batch_norm_backward_default_36[0]
        getitem_507 = native_batch_norm_backward_default_36[1]
        getitem_508 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(getitem_506, relu__default_56, primals_348, [0], [1, 1], [3, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_506 = primals_348 = None
        getitem_509 = convolution_backward_default_36[0]
        getitem_510 = convolution_backward_default_36[1]
        getitem_511 = convolution_backward_default_36[2];  convolution_backward_default_36 = None
        to_dtype_111 = torch.ops.aten.to.dtype(getitem_509, torch.float32);  getitem_509 = None
        to_dtype_112 = torch.ops.aten.to.dtype(relu__default_56, torch.float32);  relu__default_56 = None
        le_scalar_37 = torch.ops.aten.le.Scalar(to_dtype_112, 0);  to_dtype_112 = None
        new_zeros_default_131 = torch.ops.aten.new_zeros.default(to_dtype_111, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_37 = torch.ops.aten.where.self(le_scalar_37, new_zeros_default_131, to_dtype_111);  le_scalar_37 = new_zeros_default_131 = to_dtype_111 = None
        to_dtype_113 = torch.ops.aten.to.dtype(where_self_37, torch.float32);  where_self_37 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_113, convolution_default_56, primals_341, primals_339, primals_340, getitem_175, getitem_176, True, 0.001, [True, True, True]);  to_dtype_113 = convolution_default_56 = primals_341 = primals_339 = primals_340 = getitem_175 = getitem_176 = None
        getitem_512 = native_batch_norm_backward_default_37[0]
        getitem_513 = native_batch_norm_backward_default_37[1]
        getitem_514 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(getitem_512, relu__default_55, primals_342, [0], [1, 1], [0, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_512 = primals_342 = None
        getitem_515 = convolution_backward_default_37[0]
        getitem_516 = convolution_backward_default_37[1]
        getitem_517 = convolution_backward_default_37[2];  convolution_backward_default_37 = None
        to_dtype_114 = torch.ops.aten.to.dtype(getitem_515, torch.float32);  getitem_515 = None
        to_dtype_115 = torch.ops.aten.to.dtype(relu__default_55, torch.float32);  relu__default_55 = None
        le_scalar_38 = torch.ops.aten.le.Scalar(to_dtype_115, 0);  to_dtype_115 = None
        new_zeros_default_132 = torch.ops.aten.new_zeros.default(to_dtype_114, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_38 = torch.ops.aten.where.self(le_scalar_38, new_zeros_default_132, to_dtype_114);  le_scalar_38 = new_zeros_default_132 = to_dtype_114 = None
        to_dtype_116 = torch.ops.aten.to.dtype(where_self_38, torch.float32);  where_self_38 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_116, convolution_default_55, primals_335, primals_333, primals_334, getitem_172, getitem_173, True, 0.001, [True, True, True]);  to_dtype_116 = convolution_default_55 = primals_335 = primals_333 = primals_334 = getitem_172 = getitem_173 = None
        getitem_518 = native_batch_norm_backward_default_38[0]
        getitem_519 = native_batch_norm_backward_default_38[1]
        getitem_520 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(getitem_518, relu__default_54, primals_336, [0], [1, 1], [3, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_518 = primals_336 = None
        getitem_521 = convolution_backward_default_38[0]
        getitem_522 = convolution_backward_default_38[1]
        getitem_523 = convolution_backward_default_38[2];  convolution_backward_default_38 = None
        to_dtype_117 = torch.ops.aten.to.dtype(getitem_521, torch.float32);  getitem_521 = None
        to_dtype_118 = torch.ops.aten.to.dtype(relu__default_54, torch.float32);  relu__default_54 = None
        le_scalar_39 = torch.ops.aten.le.Scalar(to_dtype_118, 0);  to_dtype_118 = None
        new_zeros_default_133 = torch.ops.aten.new_zeros.default(to_dtype_117, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_39 = torch.ops.aten.where.self(le_scalar_39, new_zeros_default_133, to_dtype_117);  le_scalar_39 = new_zeros_default_133 = to_dtype_117 = None
        to_dtype_119 = torch.ops.aten.to.dtype(where_self_39, torch.float32);  where_self_39 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_119, convolution_default_54, primals_329, primals_327, primals_328, getitem_169, getitem_170, True, 0.001, [True, True, True]);  to_dtype_119 = convolution_default_54 = primals_329 = primals_327 = primals_328 = getitem_169 = getitem_170 = None
        getitem_524 = native_batch_norm_backward_default_39[0]
        getitem_525 = native_batch_norm_backward_default_39[1]
        getitem_526 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(getitem_524, cat_default_5, primals_330, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_524 = primals_330 = None
        getitem_527 = convolution_backward_default_39[0]
        getitem_528 = convolution_backward_default_39[1]
        getitem_529 = convolution_backward_default_39[2];  convolution_backward_default_39 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default_3, getitem_527);  avg_pool2d_backward_default_3 = getitem_527 = None
        to_dtype_120 = torch.ops.aten.to.dtype(slice_tensor_24, torch.float32);  slice_tensor_24 = None
        to_dtype_121 = torch.ops.aten.to.dtype(relu__default_53, torch.float32);  relu__default_53 = None
        le_scalar_40 = torch.ops.aten.le.Scalar(to_dtype_121, 0);  to_dtype_121 = None
        new_zeros_default_134 = torch.ops.aten.new_zeros.default(to_dtype_120, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_40 = torch.ops.aten.where.self(le_scalar_40, new_zeros_default_134, to_dtype_120);  le_scalar_40 = new_zeros_default_134 = to_dtype_120 = None
        to_dtype_122 = torch.ops.aten.to.dtype(where_self_40, torch.float32);  where_self_40 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_122, convolution_default_53, primals_323, primals_321, primals_322, getitem_166, getitem_167, True, 0.001, [True, True, True]);  to_dtype_122 = convolution_default_53 = primals_323 = primals_321 = primals_322 = getitem_166 = getitem_167 = None
        getitem_530 = native_batch_norm_backward_default_40[0]
        getitem_531 = native_batch_norm_backward_default_40[1]
        getitem_532 = native_batch_norm_backward_default_40[2];  native_batch_norm_backward_default_40 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(getitem_530, relu__default_52, primals_324, [0], [1, 1], [3, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_530 = primals_324 = None
        getitem_533 = convolution_backward_default_40[0]
        getitem_534 = convolution_backward_default_40[1]
        getitem_535 = convolution_backward_default_40[2];  convolution_backward_default_40 = None
        to_dtype_123 = torch.ops.aten.to.dtype(getitem_533, torch.float32);  getitem_533 = None
        to_dtype_124 = torch.ops.aten.to.dtype(relu__default_52, torch.float32);  relu__default_52 = None
        le_scalar_41 = torch.ops.aten.le.Scalar(to_dtype_124, 0);  to_dtype_124 = None
        new_zeros_default_135 = torch.ops.aten.new_zeros.default(to_dtype_123, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_41 = torch.ops.aten.where.self(le_scalar_41, new_zeros_default_135, to_dtype_123);  le_scalar_41 = new_zeros_default_135 = to_dtype_123 = None
        to_dtype_125 = torch.ops.aten.to.dtype(where_self_41, torch.float32);  where_self_41 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_125, convolution_default_52, primals_317, primals_315, primals_316, getitem_163, getitem_164, True, 0.001, [True, True, True]);  to_dtype_125 = convolution_default_52 = primals_317 = primals_315 = primals_316 = getitem_163 = getitem_164 = None
        getitem_536 = native_batch_norm_backward_default_41[0]
        getitem_537 = native_batch_norm_backward_default_41[1]
        getitem_538 = native_batch_norm_backward_default_41[2];  native_batch_norm_backward_default_41 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(getitem_536, relu__default_51, primals_318, [0], [1, 1], [0, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_536 = primals_318 = None
        getitem_539 = convolution_backward_default_41[0]
        getitem_540 = convolution_backward_default_41[1]
        getitem_541 = convolution_backward_default_41[2];  convolution_backward_default_41 = None
        to_dtype_126 = torch.ops.aten.to.dtype(getitem_539, torch.float32);  getitem_539 = None
        to_dtype_127 = torch.ops.aten.to.dtype(relu__default_51, torch.float32);  relu__default_51 = None
        le_scalar_42 = torch.ops.aten.le.Scalar(to_dtype_127, 0);  to_dtype_127 = None
        new_zeros_default_136 = torch.ops.aten.new_zeros.default(to_dtype_126, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_42 = torch.ops.aten.where.self(le_scalar_42, new_zeros_default_136, to_dtype_126);  le_scalar_42 = new_zeros_default_136 = to_dtype_126 = None
        to_dtype_128 = torch.ops.aten.to.dtype(where_self_42, torch.float32);  where_self_42 = None
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_128, convolution_default_51, primals_311, primals_309, primals_310, getitem_160, getitem_161, True, 0.001, [True, True, True]);  to_dtype_128 = convolution_default_51 = primals_311 = primals_309 = primals_310 = getitem_160 = getitem_161 = None
        getitem_542 = native_batch_norm_backward_default_42[0]
        getitem_543 = native_batch_norm_backward_default_42[1]
        getitem_544 = native_batch_norm_backward_default_42[2];  native_batch_norm_backward_default_42 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(getitem_542, cat_default_5, primals_312, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_542 = primals_312 = None
        getitem_545 = convolution_backward_default_42[0]
        getitem_546 = convolution_backward_default_42[1]
        getitem_547 = convolution_backward_default_42[2];  convolution_backward_default_42 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(add_tensor_15, getitem_545);  add_tensor_15 = getitem_545 = None
        to_dtype_129 = torch.ops.aten.to.dtype(slice_tensor_23, torch.float32);  slice_tensor_23 = None
        to_dtype_130 = torch.ops.aten.to.dtype(relu__default_50, torch.float32);  relu__default_50 = None
        le_scalar_43 = torch.ops.aten.le.Scalar(to_dtype_130, 0);  to_dtype_130 = None
        new_zeros_default_137 = torch.ops.aten.new_zeros.default(to_dtype_129, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_43 = torch.ops.aten.where.self(le_scalar_43, new_zeros_default_137, to_dtype_129);  le_scalar_43 = new_zeros_default_137 = to_dtype_129 = None
        to_dtype_131 = torch.ops.aten.to.dtype(where_self_43, torch.float32);  where_self_43 = None
        native_batch_norm_backward_default_43 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_131, convolution_default_50, primals_305, primals_303, primals_304, getitem_157, getitem_158, True, 0.001, [True, True, True]);  to_dtype_131 = convolution_default_50 = primals_305 = primals_303 = primals_304 = getitem_157 = getitem_158 = None
        getitem_548 = native_batch_norm_backward_default_43[0]
        getitem_549 = native_batch_norm_backward_default_43[1]
        getitem_550 = native_batch_norm_backward_default_43[2];  native_batch_norm_backward_default_43 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(getitem_548, cat_default_5, primals_306, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_548 = cat_default_5 = primals_306 = None
        getitem_551 = convolution_backward_default_43[0]
        getitem_552 = convolution_backward_default_43[1]
        getitem_553 = convolution_backward_default_43[2];  convolution_backward_default_43 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(add_tensor_16, getitem_551);  add_tensor_16 = getitem_551 = None
        slice_tensor_27 = torch.ops.aten.slice.Tensor(add_tensor_17, 1, 0, 192)
        slice_tensor_28 = torch.ops.aten.slice.Tensor(add_tensor_17, 1, 192, 384)
        slice_tensor_29 = torch.ops.aten.slice.Tensor(add_tensor_17, 1, 384, 576)
        slice_tensor_30 = torch.ops.aten.slice.Tensor(add_tensor_17, 1, 576, 768);  add_tensor_17 = None
        to_dtype_132 = torch.ops.aten.to.dtype(slice_tensor_30, torch.float32);  slice_tensor_30 = None
        to_dtype_133 = torch.ops.aten.to.dtype(relu__default_49, torch.float32);  relu__default_49 = None
        le_scalar_44 = torch.ops.aten.le.Scalar(to_dtype_133, 0);  to_dtype_133 = None
        new_zeros_default_138 = torch.ops.aten.new_zeros.default(to_dtype_132, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_44 = torch.ops.aten.where.self(le_scalar_44, new_zeros_default_138, to_dtype_132);  le_scalar_44 = new_zeros_default_138 = to_dtype_132 = None
        to_dtype_134 = torch.ops.aten.to.dtype(where_self_44, torch.float32);  where_self_44 = None
        native_batch_norm_backward_default_44 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_134, convolution_default_49, primals_299, primals_297, primals_298, getitem_154, getitem_155, True, 0.001, [True, True, True]);  to_dtype_134 = convolution_default_49 = primals_299 = primals_297 = primals_298 = getitem_154 = getitem_155 = None
        getitem_554 = native_batch_norm_backward_default_44[0]
        getitem_555 = native_batch_norm_backward_default_44[1]
        getitem_556 = native_batch_norm_backward_default_44[2];  native_batch_norm_backward_default_44 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(getitem_554, avg_pool2d_default_4, primals_300, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_554 = avg_pool2d_default_4 = primals_300 = None
        getitem_557 = convolution_backward_default_44[0]
        getitem_558 = convolution_backward_default_44[1]
        getitem_559 = convolution_backward_default_44[2];  convolution_backward_default_44 = None
        avg_pool2d_backward_default_4 = torch.ops.aten.avg_pool2d_backward.default(getitem_557, cat_default_4, [3, 3], [1, 1], [1, 1], False, True, None);  getitem_557 = None
        to_dtype_135 = torch.ops.aten.to.dtype(slice_tensor_29, torch.float32);  slice_tensor_29 = None
        to_dtype_136 = torch.ops.aten.to.dtype(relu__default_48, torch.float32);  relu__default_48 = None
        le_scalar_45 = torch.ops.aten.le.Scalar(to_dtype_136, 0);  to_dtype_136 = None
        new_zeros_default_139 = torch.ops.aten.new_zeros.default(to_dtype_135, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_45 = torch.ops.aten.where.self(le_scalar_45, new_zeros_default_139, to_dtype_135);  le_scalar_45 = new_zeros_default_139 = to_dtype_135 = None
        to_dtype_137 = torch.ops.aten.to.dtype(where_self_45, torch.float32);  where_self_45 = None
        native_batch_norm_backward_default_45 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_137, convolution_default_48, primals_293, primals_291, primals_292, getitem_151, getitem_152, True, 0.001, [True, True, True]);  to_dtype_137 = convolution_default_48 = primals_293 = primals_291 = primals_292 = getitem_151 = getitem_152 = None
        getitem_560 = native_batch_norm_backward_default_45[0]
        getitem_561 = native_batch_norm_backward_default_45[1]
        getitem_562 = native_batch_norm_backward_default_45[2];  native_batch_norm_backward_default_45 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(getitem_560, relu__default_47, primals_294, [0], [1, 1], [0, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_560 = primals_294 = None
        getitem_563 = convolution_backward_default_45[0]
        getitem_564 = convolution_backward_default_45[1]
        getitem_565 = convolution_backward_default_45[2];  convolution_backward_default_45 = None
        to_dtype_138 = torch.ops.aten.to.dtype(getitem_563, torch.float32);  getitem_563 = None
        to_dtype_139 = torch.ops.aten.to.dtype(relu__default_47, torch.float32);  relu__default_47 = None
        le_scalar_46 = torch.ops.aten.le.Scalar(to_dtype_139, 0);  to_dtype_139 = None
        new_zeros_default_140 = torch.ops.aten.new_zeros.default(to_dtype_138, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_46 = torch.ops.aten.where.self(le_scalar_46, new_zeros_default_140, to_dtype_138);  le_scalar_46 = new_zeros_default_140 = to_dtype_138 = None
        to_dtype_140 = torch.ops.aten.to.dtype(where_self_46, torch.float32);  where_self_46 = None
        native_batch_norm_backward_default_46 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_140, convolution_default_47, primals_287, primals_285, primals_286, getitem_148, getitem_149, True, 0.001, [True, True, True]);  to_dtype_140 = convolution_default_47 = primals_287 = primals_285 = primals_286 = getitem_148 = getitem_149 = None
        getitem_566 = native_batch_norm_backward_default_46[0]
        getitem_567 = native_batch_norm_backward_default_46[1]
        getitem_568 = native_batch_norm_backward_default_46[2];  native_batch_norm_backward_default_46 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(getitem_566, relu__default_46, primals_288, [0], [1, 1], [3, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_566 = primals_288 = None
        getitem_569 = convolution_backward_default_46[0]
        getitem_570 = convolution_backward_default_46[1]
        getitem_571 = convolution_backward_default_46[2];  convolution_backward_default_46 = None
        to_dtype_141 = torch.ops.aten.to.dtype(getitem_569, torch.float32);  getitem_569 = None
        to_dtype_142 = torch.ops.aten.to.dtype(relu__default_46, torch.float32);  relu__default_46 = None
        le_scalar_47 = torch.ops.aten.le.Scalar(to_dtype_142, 0);  to_dtype_142 = None
        new_zeros_default_141 = torch.ops.aten.new_zeros.default(to_dtype_141, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_47 = torch.ops.aten.where.self(le_scalar_47, new_zeros_default_141, to_dtype_141);  le_scalar_47 = new_zeros_default_141 = to_dtype_141 = None
        to_dtype_143 = torch.ops.aten.to.dtype(where_self_47, torch.float32);  where_self_47 = None
        native_batch_norm_backward_default_47 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_143, convolution_default_46, primals_281, primals_279, primals_280, getitem_145, getitem_146, True, 0.001, [True, True, True]);  to_dtype_143 = convolution_default_46 = primals_281 = primals_279 = primals_280 = getitem_145 = getitem_146 = None
        getitem_572 = native_batch_norm_backward_default_47[0]
        getitem_573 = native_batch_norm_backward_default_47[1]
        getitem_574 = native_batch_norm_backward_default_47[2];  native_batch_norm_backward_default_47 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(getitem_572, relu__default_45, primals_282, [0], [1, 1], [0, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_572 = primals_282 = None
        getitem_575 = convolution_backward_default_47[0]
        getitem_576 = convolution_backward_default_47[1]
        getitem_577 = convolution_backward_default_47[2];  convolution_backward_default_47 = None
        to_dtype_144 = torch.ops.aten.to.dtype(getitem_575, torch.float32);  getitem_575 = None
        to_dtype_145 = torch.ops.aten.to.dtype(relu__default_45, torch.float32);  relu__default_45 = None
        le_scalar_48 = torch.ops.aten.le.Scalar(to_dtype_145, 0);  to_dtype_145 = None
        new_zeros_default_142 = torch.ops.aten.new_zeros.default(to_dtype_144, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_48 = torch.ops.aten.where.self(le_scalar_48, new_zeros_default_142, to_dtype_144);  le_scalar_48 = new_zeros_default_142 = to_dtype_144 = None
        to_dtype_146 = torch.ops.aten.to.dtype(where_self_48, torch.float32);  where_self_48 = None
        native_batch_norm_backward_default_48 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_146, convolution_default_45, primals_275, primals_273, primals_274, getitem_142, getitem_143, True, 0.001, [True, True, True]);  to_dtype_146 = convolution_default_45 = primals_275 = primals_273 = primals_274 = getitem_142 = getitem_143 = None
        getitem_578 = native_batch_norm_backward_default_48[0]
        getitem_579 = native_batch_norm_backward_default_48[1]
        getitem_580 = native_batch_norm_backward_default_48[2];  native_batch_norm_backward_default_48 = None
        convolution_backward_default_48 = torch.ops.aten.convolution_backward.default(getitem_578, relu__default_44, primals_276, [0], [1, 1], [3, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_578 = primals_276 = None
        getitem_581 = convolution_backward_default_48[0]
        getitem_582 = convolution_backward_default_48[1]
        getitem_583 = convolution_backward_default_48[2];  convolution_backward_default_48 = None
        to_dtype_147 = torch.ops.aten.to.dtype(getitem_581, torch.float32);  getitem_581 = None
        to_dtype_148 = torch.ops.aten.to.dtype(relu__default_44, torch.float32);  relu__default_44 = None
        le_scalar_49 = torch.ops.aten.le.Scalar(to_dtype_148, 0);  to_dtype_148 = None
        new_zeros_default_143 = torch.ops.aten.new_zeros.default(to_dtype_147, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_49 = torch.ops.aten.where.self(le_scalar_49, new_zeros_default_143, to_dtype_147);  le_scalar_49 = new_zeros_default_143 = to_dtype_147 = None
        to_dtype_149 = torch.ops.aten.to.dtype(where_self_49, torch.float32);  where_self_49 = None
        native_batch_norm_backward_default_49 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_149, convolution_default_44, primals_269, primals_267, primals_268, getitem_139, getitem_140, True, 0.001, [True, True, True]);  to_dtype_149 = convolution_default_44 = primals_269 = primals_267 = primals_268 = getitem_139 = getitem_140 = None
        getitem_584 = native_batch_norm_backward_default_49[0]
        getitem_585 = native_batch_norm_backward_default_49[1]
        getitem_586 = native_batch_norm_backward_default_49[2];  native_batch_norm_backward_default_49 = None
        convolution_backward_default_49 = torch.ops.aten.convolution_backward.default(getitem_584, cat_default_4, primals_270, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_584 = primals_270 = None
        getitem_587 = convolution_backward_default_49[0]
        getitem_588 = convolution_backward_default_49[1]
        getitem_589 = convolution_backward_default_49[2];  convolution_backward_default_49 = None
        add_tensor_18 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default_4, getitem_587);  avg_pool2d_backward_default_4 = getitem_587 = None
        to_dtype_150 = torch.ops.aten.to.dtype(slice_tensor_28, torch.float32);  slice_tensor_28 = None
        to_dtype_151 = torch.ops.aten.to.dtype(relu__default_43, torch.float32);  relu__default_43 = None
        le_scalar_50 = torch.ops.aten.le.Scalar(to_dtype_151, 0);  to_dtype_151 = None
        new_zeros_default_144 = torch.ops.aten.new_zeros.default(to_dtype_150, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_50 = torch.ops.aten.where.self(le_scalar_50, new_zeros_default_144, to_dtype_150);  le_scalar_50 = new_zeros_default_144 = to_dtype_150 = None
        to_dtype_152 = torch.ops.aten.to.dtype(where_self_50, torch.float32);  where_self_50 = None
        native_batch_norm_backward_default_50 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_152, convolution_default_43, primals_263, primals_261, primals_262, getitem_136, getitem_137, True, 0.001, [True, True, True]);  to_dtype_152 = convolution_default_43 = primals_263 = primals_261 = primals_262 = getitem_136 = getitem_137 = None
        getitem_590 = native_batch_norm_backward_default_50[0]
        getitem_591 = native_batch_norm_backward_default_50[1]
        getitem_592 = native_batch_norm_backward_default_50[2];  native_batch_norm_backward_default_50 = None
        convolution_backward_default_50 = torch.ops.aten.convolution_backward.default(getitem_590, relu__default_42, primals_264, [0], [1, 1], [3, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_590 = primals_264 = None
        getitem_593 = convolution_backward_default_50[0]
        getitem_594 = convolution_backward_default_50[1]
        getitem_595 = convolution_backward_default_50[2];  convolution_backward_default_50 = None
        to_dtype_153 = torch.ops.aten.to.dtype(getitem_593, torch.float32);  getitem_593 = None
        to_dtype_154 = torch.ops.aten.to.dtype(relu__default_42, torch.float32);  relu__default_42 = None
        le_scalar_51 = torch.ops.aten.le.Scalar(to_dtype_154, 0);  to_dtype_154 = None
        new_zeros_default_145 = torch.ops.aten.new_zeros.default(to_dtype_153, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_51 = torch.ops.aten.where.self(le_scalar_51, new_zeros_default_145, to_dtype_153);  le_scalar_51 = new_zeros_default_145 = to_dtype_153 = None
        to_dtype_155 = torch.ops.aten.to.dtype(where_self_51, torch.float32);  where_self_51 = None
        native_batch_norm_backward_default_51 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_155, convolution_default_42, primals_257, primals_255, primals_256, getitem_133, getitem_134, True, 0.001, [True, True, True]);  to_dtype_155 = convolution_default_42 = primals_257 = primals_255 = primals_256 = getitem_133 = getitem_134 = None
        getitem_596 = native_batch_norm_backward_default_51[0]
        getitem_597 = native_batch_norm_backward_default_51[1]
        getitem_598 = native_batch_norm_backward_default_51[2];  native_batch_norm_backward_default_51 = None
        convolution_backward_default_51 = torch.ops.aten.convolution_backward.default(getitem_596, relu__default_41, primals_258, [0], [1, 1], [0, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_596 = primals_258 = None
        getitem_599 = convolution_backward_default_51[0]
        getitem_600 = convolution_backward_default_51[1]
        getitem_601 = convolution_backward_default_51[2];  convolution_backward_default_51 = None
        to_dtype_156 = torch.ops.aten.to.dtype(getitem_599, torch.float32);  getitem_599 = None
        to_dtype_157 = torch.ops.aten.to.dtype(relu__default_41, torch.float32);  relu__default_41 = None
        le_scalar_52 = torch.ops.aten.le.Scalar(to_dtype_157, 0);  to_dtype_157 = None
        new_zeros_default_146 = torch.ops.aten.new_zeros.default(to_dtype_156, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_52 = torch.ops.aten.where.self(le_scalar_52, new_zeros_default_146, to_dtype_156);  le_scalar_52 = new_zeros_default_146 = to_dtype_156 = None
        to_dtype_158 = torch.ops.aten.to.dtype(where_self_52, torch.float32);  where_self_52 = None
        native_batch_norm_backward_default_52 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_158, convolution_default_41, primals_251, primals_249, primals_250, getitem_130, getitem_131, True, 0.001, [True, True, True]);  to_dtype_158 = convolution_default_41 = primals_251 = primals_249 = primals_250 = getitem_130 = getitem_131 = None
        getitem_602 = native_batch_norm_backward_default_52[0]
        getitem_603 = native_batch_norm_backward_default_52[1]
        getitem_604 = native_batch_norm_backward_default_52[2];  native_batch_norm_backward_default_52 = None
        convolution_backward_default_52 = torch.ops.aten.convolution_backward.default(getitem_602, cat_default_4, primals_252, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_602 = primals_252 = None
        getitem_605 = convolution_backward_default_52[0]
        getitem_606 = convolution_backward_default_52[1]
        getitem_607 = convolution_backward_default_52[2];  convolution_backward_default_52 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(add_tensor_18, getitem_605);  add_tensor_18 = getitem_605 = None
        to_dtype_159 = torch.ops.aten.to.dtype(slice_tensor_27, torch.float32);  slice_tensor_27 = None
        to_dtype_160 = torch.ops.aten.to.dtype(relu__default_40, torch.float32);  relu__default_40 = None
        le_scalar_53 = torch.ops.aten.le.Scalar(to_dtype_160, 0);  to_dtype_160 = None
        new_zeros_default_147 = torch.ops.aten.new_zeros.default(to_dtype_159, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_53 = torch.ops.aten.where.self(le_scalar_53, new_zeros_default_147, to_dtype_159);  le_scalar_53 = new_zeros_default_147 = to_dtype_159 = None
        to_dtype_161 = torch.ops.aten.to.dtype(where_self_53, torch.float32);  where_self_53 = None
        native_batch_norm_backward_default_53 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_161, convolution_default_40, primals_245, primals_243, primals_244, getitem_127, getitem_128, True, 0.001, [True, True, True]);  to_dtype_161 = convolution_default_40 = primals_245 = primals_243 = primals_244 = getitem_127 = getitem_128 = None
        getitem_608 = native_batch_norm_backward_default_53[0]
        getitem_609 = native_batch_norm_backward_default_53[1]
        getitem_610 = native_batch_norm_backward_default_53[2];  native_batch_norm_backward_default_53 = None
        convolution_backward_default_53 = torch.ops.aten.convolution_backward.default(getitem_608, cat_default_4, primals_246, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_608 = cat_default_4 = primals_246 = None
        getitem_611 = convolution_backward_default_53[0]
        getitem_612 = convolution_backward_default_53[1]
        getitem_613 = convolution_backward_default_53[2];  convolution_backward_default_53 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(add_tensor_19, getitem_611);  add_tensor_19 = getitem_611 = None
        slice_tensor_31 = torch.ops.aten.slice.Tensor(add_tensor_20, 1, 0, 192)
        slice_tensor_32 = torch.ops.aten.slice.Tensor(add_tensor_20, 1, 192, 384)
        slice_tensor_33 = torch.ops.aten.slice.Tensor(add_tensor_20, 1, 384, 576)
        slice_tensor_34 = torch.ops.aten.slice.Tensor(add_tensor_20, 1, 576, 768);  add_tensor_20 = None
        to_dtype_162 = torch.ops.aten.to.dtype(slice_tensor_34, torch.float32);  slice_tensor_34 = None
        to_dtype_163 = torch.ops.aten.to.dtype(relu__default_39, torch.float32);  relu__default_39 = None
        le_scalar_54 = torch.ops.aten.le.Scalar(to_dtype_163, 0);  to_dtype_163 = None
        new_zeros_default_148 = torch.ops.aten.new_zeros.default(to_dtype_162, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_54 = torch.ops.aten.where.self(le_scalar_54, new_zeros_default_148, to_dtype_162);  le_scalar_54 = new_zeros_default_148 = to_dtype_162 = None
        to_dtype_164 = torch.ops.aten.to.dtype(where_self_54, torch.float32);  where_self_54 = None
        native_batch_norm_backward_default_54 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_164, convolution_default_39, primals_239, primals_237, primals_238, getitem_124, getitem_125, True, 0.001, [True, True, True]);  to_dtype_164 = convolution_default_39 = primals_239 = primals_237 = primals_238 = getitem_124 = getitem_125 = None
        getitem_614 = native_batch_norm_backward_default_54[0]
        getitem_615 = native_batch_norm_backward_default_54[1]
        getitem_616 = native_batch_norm_backward_default_54[2];  native_batch_norm_backward_default_54 = None
        convolution_backward_default_54 = torch.ops.aten.convolution_backward.default(getitem_614, avg_pool2d_default_3, primals_240, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_614 = avg_pool2d_default_3 = primals_240 = None
        getitem_617 = convolution_backward_default_54[0]
        getitem_618 = convolution_backward_default_54[1]
        getitem_619 = convolution_backward_default_54[2];  convolution_backward_default_54 = None
        avg_pool2d_backward_default_5 = torch.ops.aten.avg_pool2d_backward.default(getitem_617, cat_default_3, [3, 3], [1, 1], [1, 1], False, True, None);  getitem_617 = None
        to_dtype_165 = torch.ops.aten.to.dtype(slice_tensor_33, torch.float32);  slice_tensor_33 = None
        to_dtype_166 = torch.ops.aten.to.dtype(relu__default_38, torch.float32);  relu__default_38 = None
        le_scalar_55 = torch.ops.aten.le.Scalar(to_dtype_166, 0);  to_dtype_166 = None
        new_zeros_default_149 = torch.ops.aten.new_zeros.default(to_dtype_165, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_55 = torch.ops.aten.where.self(le_scalar_55, new_zeros_default_149, to_dtype_165);  le_scalar_55 = new_zeros_default_149 = to_dtype_165 = None
        to_dtype_167 = torch.ops.aten.to.dtype(where_self_55, torch.float32);  where_self_55 = None
        native_batch_norm_backward_default_55 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_167, convolution_default_38, primals_233, primals_231, primals_232, getitem_121, getitem_122, True, 0.001, [True, True, True]);  to_dtype_167 = convolution_default_38 = primals_233 = primals_231 = primals_232 = getitem_121 = getitem_122 = None
        getitem_620 = native_batch_norm_backward_default_55[0]
        getitem_621 = native_batch_norm_backward_default_55[1]
        getitem_622 = native_batch_norm_backward_default_55[2];  native_batch_norm_backward_default_55 = None
        convolution_backward_default_55 = torch.ops.aten.convolution_backward.default(getitem_620, relu__default_37, primals_234, [0], [1, 1], [0, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_620 = primals_234 = None
        getitem_623 = convolution_backward_default_55[0]
        getitem_624 = convolution_backward_default_55[1]
        getitem_625 = convolution_backward_default_55[2];  convolution_backward_default_55 = None
        to_dtype_168 = torch.ops.aten.to.dtype(getitem_623, torch.float32);  getitem_623 = None
        to_dtype_169 = torch.ops.aten.to.dtype(relu__default_37, torch.float32);  relu__default_37 = None
        le_scalar_56 = torch.ops.aten.le.Scalar(to_dtype_169, 0);  to_dtype_169 = None
        new_zeros_default_150 = torch.ops.aten.new_zeros.default(to_dtype_168, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_56 = torch.ops.aten.where.self(le_scalar_56, new_zeros_default_150, to_dtype_168);  le_scalar_56 = new_zeros_default_150 = to_dtype_168 = None
        to_dtype_170 = torch.ops.aten.to.dtype(where_self_56, torch.float32);  where_self_56 = None
        native_batch_norm_backward_default_56 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_170, convolution_default_37, primals_227, primals_225, primals_226, getitem_118, getitem_119, True, 0.001, [True, True, True]);  to_dtype_170 = convolution_default_37 = primals_227 = primals_225 = primals_226 = getitem_118 = getitem_119 = None
        getitem_626 = native_batch_norm_backward_default_56[0]
        getitem_627 = native_batch_norm_backward_default_56[1]
        getitem_628 = native_batch_norm_backward_default_56[2];  native_batch_norm_backward_default_56 = None
        convolution_backward_default_56 = torch.ops.aten.convolution_backward.default(getitem_626, relu__default_36, primals_228, [0], [1, 1], [3, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_626 = primals_228 = None
        getitem_629 = convolution_backward_default_56[0]
        getitem_630 = convolution_backward_default_56[1]
        getitem_631 = convolution_backward_default_56[2];  convolution_backward_default_56 = None
        to_dtype_171 = torch.ops.aten.to.dtype(getitem_629, torch.float32);  getitem_629 = None
        to_dtype_172 = torch.ops.aten.to.dtype(relu__default_36, torch.float32);  relu__default_36 = None
        le_scalar_57 = torch.ops.aten.le.Scalar(to_dtype_172, 0);  to_dtype_172 = None
        new_zeros_default_151 = torch.ops.aten.new_zeros.default(to_dtype_171, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_57 = torch.ops.aten.where.self(le_scalar_57, new_zeros_default_151, to_dtype_171);  le_scalar_57 = new_zeros_default_151 = to_dtype_171 = None
        to_dtype_173 = torch.ops.aten.to.dtype(where_self_57, torch.float32);  where_self_57 = None
        native_batch_norm_backward_default_57 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_173, convolution_default_36, primals_221, primals_219, primals_220, getitem_115, getitem_116, True, 0.001, [True, True, True]);  to_dtype_173 = convolution_default_36 = primals_221 = primals_219 = primals_220 = getitem_115 = getitem_116 = None
        getitem_632 = native_batch_norm_backward_default_57[0]
        getitem_633 = native_batch_norm_backward_default_57[1]
        getitem_634 = native_batch_norm_backward_default_57[2];  native_batch_norm_backward_default_57 = None
        convolution_backward_default_57 = torch.ops.aten.convolution_backward.default(getitem_632, relu__default_35, primals_222, [0], [1, 1], [0, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_632 = primals_222 = None
        getitem_635 = convolution_backward_default_57[0]
        getitem_636 = convolution_backward_default_57[1]
        getitem_637 = convolution_backward_default_57[2];  convolution_backward_default_57 = None
        to_dtype_174 = torch.ops.aten.to.dtype(getitem_635, torch.float32);  getitem_635 = None
        to_dtype_175 = torch.ops.aten.to.dtype(relu__default_35, torch.float32);  relu__default_35 = None
        le_scalar_58 = torch.ops.aten.le.Scalar(to_dtype_175, 0);  to_dtype_175 = None
        new_zeros_default_152 = torch.ops.aten.new_zeros.default(to_dtype_174, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_58 = torch.ops.aten.where.self(le_scalar_58, new_zeros_default_152, to_dtype_174);  le_scalar_58 = new_zeros_default_152 = to_dtype_174 = None
        to_dtype_176 = torch.ops.aten.to.dtype(where_self_58, torch.float32);  where_self_58 = None
        native_batch_norm_backward_default_58 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_176, convolution_default_35, primals_215, primals_213, primals_214, getitem_112, getitem_113, True, 0.001, [True, True, True]);  to_dtype_176 = convolution_default_35 = primals_215 = primals_213 = primals_214 = getitem_112 = getitem_113 = None
        getitem_638 = native_batch_norm_backward_default_58[0]
        getitem_639 = native_batch_norm_backward_default_58[1]
        getitem_640 = native_batch_norm_backward_default_58[2];  native_batch_norm_backward_default_58 = None
        convolution_backward_default_58 = torch.ops.aten.convolution_backward.default(getitem_638, relu__default_34, primals_216, [0], [1, 1], [3, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_638 = primals_216 = None
        getitem_641 = convolution_backward_default_58[0]
        getitem_642 = convolution_backward_default_58[1]
        getitem_643 = convolution_backward_default_58[2];  convolution_backward_default_58 = None
        to_dtype_177 = torch.ops.aten.to.dtype(getitem_641, torch.float32);  getitem_641 = None
        to_dtype_178 = torch.ops.aten.to.dtype(relu__default_34, torch.float32);  relu__default_34 = None
        le_scalar_59 = torch.ops.aten.le.Scalar(to_dtype_178, 0);  to_dtype_178 = None
        new_zeros_default_153 = torch.ops.aten.new_zeros.default(to_dtype_177, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_59 = torch.ops.aten.where.self(le_scalar_59, new_zeros_default_153, to_dtype_177);  le_scalar_59 = new_zeros_default_153 = to_dtype_177 = None
        to_dtype_179 = torch.ops.aten.to.dtype(where_self_59, torch.float32);  where_self_59 = None
        native_batch_norm_backward_default_59 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_179, convolution_default_34, primals_209, primals_207, primals_208, getitem_109, getitem_110, True, 0.001, [True, True, True]);  to_dtype_179 = convolution_default_34 = primals_209 = primals_207 = primals_208 = getitem_109 = getitem_110 = None
        getitem_644 = native_batch_norm_backward_default_59[0]
        getitem_645 = native_batch_norm_backward_default_59[1]
        getitem_646 = native_batch_norm_backward_default_59[2];  native_batch_norm_backward_default_59 = None
        convolution_backward_default_59 = torch.ops.aten.convolution_backward.default(getitem_644, cat_default_3, primals_210, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_644 = primals_210 = None
        getitem_647 = convolution_backward_default_59[0]
        getitem_648 = convolution_backward_default_59[1]
        getitem_649 = convolution_backward_default_59[2];  convolution_backward_default_59 = None
        add_tensor_21 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default_5, getitem_647);  avg_pool2d_backward_default_5 = getitem_647 = None
        to_dtype_180 = torch.ops.aten.to.dtype(slice_tensor_32, torch.float32);  slice_tensor_32 = None
        to_dtype_181 = torch.ops.aten.to.dtype(relu__default_33, torch.float32);  relu__default_33 = None
        le_scalar_60 = torch.ops.aten.le.Scalar(to_dtype_181, 0);  to_dtype_181 = None
        new_zeros_default_154 = torch.ops.aten.new_zeros.default(to_dtype_180, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_60 = torch.ops.aten.where.self(le_scalar_60, new_zeros_default_154, to_dtype_180);  le_scalar_60 = new_zeros_default_154 = to_dtype_180 = None
        to_dtype_182 = torch.ops.aten.to.dtype(where_self_60, torch.float32);  where_self_60 = None
        native_batch_norm_backward_default_60 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_182, convolution_default_33, primals_203, primals_201, primals_202, getitem_106, getitem_107, True, 0.001, [True, True, True]);  to_dtype_182 = convolution_default_33 = primals_203 = primals_201 = primals_202 = getitem_106 = getitem_107 = None
        getitem_650 = native_batch_norm_backward_default_60[0]
        getitem_651 = native_batch_norm_backward_default_60[1]
        getitem_652 = native_batch_norm_backward_default_60[2];  native_batch_norm_backward_default_60 = None
        convolution_backward_default_60 = torch.ops.aten.convolution_backward.default(getitem_650, relu__default_32, primals_204, [0], [1, 1], [3, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_650 = primals_204 = None
        getitem_653 = convolution_backward_default_60[0]
        getitem_654 = convolution_backward_default_60[1]
        getitem_655 = convolution_backward_default_60[2];  convolution_backward_default_60 = None
        to_dtype_183 = torch.ops.aten.to.dtype(getitem_653, torch.float32);  getitem_653 = None
        to_dtype_184 = torch.ops.aten.to.dtype(relu__default_32, torch.float32);  relu__default_32 = None
        le_scalar_61 = torch.ops.aten.le.Scalar(to_dtype_184, 0);  to_dtype_184 = None
        new_zeros_default_155 = torch.ops.aten.new_zeros.default(to_dtype_183, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_61 = torch.ops.aten.where.self(le_scalar_61, new_zeros_default_155, to_dtype_183);  le_scalar_61 = new_zeros_default_155 = to_dtype_183 = None
        to_dtype_185 = torch.ops.aten.to.dtype(where_self_61, torch.float32);  where_self_61 = None
        native_batch_norm_backward_default_61 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_185, convolution_default_32, primals_197, primals_195, primals_196, getitem_103, getitem_104, True, 0.001, [True, True, True]);  to_dtype_185 = convolution_default_32 = primals_197 = primals_195 = primals_196 = getitem_103 = getitem_104 = None
        getitem_656 = native_batch_norm_backward_default_61[0]
        getitem_657 = native_batch_norm_backward_default_61[1]
        getitem_658 = native_batch_norm_backward_default_61[2];  native_batch_norm_backward_default_61 = None
        convolution_backward_default_61 = torch.ops.aten.convolution_backward.default(getitem_656, relu__default_31, primals_198, [0], [1, 1], [0, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_656 = primals_198 = None
        getitem_659 = convolution_backward_default_61[0]
        getitem_660 = convolution_backward_default_61[1]
        getitem_661 = convolution_backward_default_61[2];  convolution_backward_default_61 = None
        to_dtype_186 = torch.ops.aten.to.dtype(getitem_659, torch.float32);  getitem_659 = None
        to_dtype_187 = torch.ops.aten.to.dtype(relu__default_31, torch.float32);  relu__default_31 = None
        le_scalar_62 = torch.ops.aten.le.Scalar(to_dtype_187, 0);  to_dtype_187 = None
        new_zeros_default_156 = torch.ops.aten.new_zeros.default(to_dtype_186, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_62 = torch.ops.aten.where.self(le_scalar_62, new_zeros_default_156, to_dtype_186);  le_scalar_62 = new_zeros_default_156 = to_dtype_186 = None
        to_dtype_188 = torch.ops.aten.to.dtype(where_self_62, torch.float32);  where_self_62 = None
        native_batch_norm_backward_default_62 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_188, convolution_default_31, primals_191, primals_189, primals_190, getitem_100, getitem_101, True, 0.001, [True, True, True]);  to_dtype_188 = convolution_default_31 = primals_191 = primals_189 = primals_190 = getitem_100 = getitem_101 = None
        getitem_662 = native_batch_norm_backward_default_62[0]
        getitem_663 = native_batch_norm_backward_default_62[1]
        getitem_664 = native_batch_norm_backward_default_62[2];  native_batch_norm_backward_default_62 = None
        convolution_backward_default_62 = torch.ops.aten.convolution_backward.default(getitem_662, cat_default_3, primals_192, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_662 = primals_192 = None
        getitem_665 = convolution_backward_default_62[0]
        getitem_666 = convolution_backward_default_62[1]
        getitem_667 = convolution_backward_default_62[2];  convolution_backward_default_62 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(add_tensor_21, getitem_665);  add_tensor_21 = getitem_665 = None
        to_dtype_189 = torch.ops.aten.to.dtype(slice_tensor_31, torch.float32);  slice_tensor_31 = None
        to_dtype_190 = torch.ops.aten.to.dtype(relu__default_30, torch.float32);  relu__default_30 = None
        le_scalar_63 = torch.ops.aten.le.Scalar(to_dtype_190, 0);  to_dtype_190 = None
        new_zeros_default_157 = torch.ops.aten.new_zeros.default(to_dtype_189, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_63 = torch.ops.aten.where.self(le_scalar_63, new_zeros_default_157, to_dtype_189);  le_scalar_63 = new_zeros_default_157 = to_dtype_189 = None
        to_dtype_191 = torch.ops.aten.to.dtype(where_self_63, torch.float32);  where_self_63 = None
        native_batch_norm_backward_default_63 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_191, convolution_default_30, primals_185, primals_183, primals_184, getitem_97, getitem_98, True, 0.001, [True, True, True]);  to_dtype_191 = convolution_default_30 = primals_185 = primals_183 = primals_184 = getitem_97 = getitem_98 = None
        getitem_668 = native_batch_norm_backward_default_63[0]
        getitem_669 = native_batch_norm_backward_default_63[1]
        getitem_670 = native_batch_norm_backward_default_63[2];  native_batch_norm_backward_default_63 = None
        convolution_backward_default_63 = torch.ops.aten.convolution_backward.default(getitem_668, cat_default_3, primals_186, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_668 = cat_default_3 = primals_186 = None
        getitem_671 = convolution_backward_default_63[0]
        getitem_672 = convolution_backward_default_63[1]
        getitem_673 = convolution_backward_default_63[2];  convolution_backward_default_63 = None
        add_tensor_23 = torch.ops.aten.add.Tensor(add_tensor_22, getitem_671);  add_tensor_22 = getitem_671 = None
        slice_tensor_35 = torch.ops.aten.slice.Tensor(add_tensor_23, 1, 0, 384)
        slice_tensor_36 = torch.ops.aten.slice.Tensor(add_tensor_23, 1, 384, 480)
        slice_tensor_37 = torch.ops.aten.slice.Tensor(add_tensor_23, 1, 480, 768);  add_tensor_23 = None
        max_pool2d_with_indices_backward_default_1 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_37, cat_default_2, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_95);  slice_tensor_37 = getitem_95 = None
        to_dtype_192 = torch.ops.aten.to.dtype(slice_tensor_36, torch.float32);  slice_tensor_36 = None
        to_dtype_193 = torch.ops.aten.to.dtype(relu__default_29, torch.float32);  relu__default_29 = None
        le_scalar_64 = torch.ops.aten.le.Scalar(to_dtype_193, 0);  to_dtype_193 = None
        new_zeros_default_158 = torch.ops.aten.new_zeros.default(to_dtype_192, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_64 = torch.ops.aten.where.self(le_scalar_64, new_zeros_default_158, to_dtype_192);  le_scalar_64 = new_zeros_default_158 = to_dtype_192 = None
        to_dtype_194 = torch.ops.aten.to.dtype(where_self_64, torch.float32);  where_self_64 = None
        native_batch_norm_backward_default_64 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_194, convolution_default_29, primals_179, primals_177, primals_178, getitem_92, getitem_93, True, 0.001, [True, True, True]);  to_dtype_194 = convolution_default_29 = primals_179 = primals_177 = primals_178 = getitem_92 = getitem_93 = None
        getitem_674 = native_batch_norm_backward_default_64[0]
        getitem_675 = native_batch_norm_backward_default_64[1]
        getitem_676 = native_batch_norm_backward_default_64[2];  native_batch_norm_backward_default_64 = None
        convolution_backward_default_64 = torch.ops.aten.convolution_backward.default(getitem_674, relu__default_28, primals_180, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_674 = primals_180 = None
        getitem_677 = convolution_backward_default_64[0]
        getitem_678 = convolution_backward_default_64[1]
        getitem_679 = convolution_backward_default_64[2];  convolution_backward_default_64 = None
        to_dtype_195 = torch.ops.aten.to.dtype(getitem_677, torch.float32);  getitem_677 = None
        to_dtype_196 = torch.ops.aten.to.dtype(relu__default_28, torch.float32);  relu__default_28 = None
        le_scalar_65 = torch.ops.aten.le.Scalar(to_dtype_196, 0);  to_dtype_196 = None
        new_zeros_default_159 = torch.ops.aten.new_zeros.default(to_dtype_195, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_65 = torch.ops.aten.where.self(le_scalar_65, new_zeros_default_159, to_dtype_195);  le_scalar_65 = new_zeros_default_159 = to_dtype_195 = None
        to_dtype_197 = torch.ops.aten.to.dtype(where_self_65, torch.float32);  where_self_65 = None
        native_batch_norm_backward_default_65 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_197, convolution_default_28, primals_173, primals_171, primals_172, getitem_89, getitem_90, True, 0.001, [True, True, True]);  to_dtype_197 = convolution_default_28 = primals_173 = primals_171 = primals_172 = getitem_89 = getitem_90 = None
        getitem_680 = native_batch_norm_backward_default_65[0]
        getitem_681 = native_batch_norm_backward_default_65[1]
        getitem_682 = native_batch_norm_backward_default_65[2];  native_batch_norm_backward_default_65 = None
        convolution_backward_default_65 = torch.ops.aten.convolution_backward.default(getitem_680, relu__default_27, primals_174, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_680 = primals_174 = None
        getitem_683 = convolution_backward_default_65[0]
        getitem_684 = convolution_backward_default_65[1]
        getitem_685 = convolution_backward_default_65[2];  convolution_backward_default_65 = None
        to_dtype_198 = torch.ops.aten.to.dtype(getitem_683, torch.float32);  getitem_683 = None
        to_dtype_199 = torch.ops.aten.to.dtype(relu__default_27, torch.float32);  relu__default_27 = None
        le_scalar_66 = torch.ops.aten.le.Scalar(to_dtype_199, 0);  to_dtype_199 = None
        new_zeros_default_160 = torch.ops.aten.new_zeros.default(to_dtype_198, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_66 = torch.ops.aten.where.self(le_scalar_66, new_zeros_default_160, to_dtype_198);  le_scalar_66 = new_zeros_default_160 = to_dtype_198 = None
        to_dtype_200 = torch.ops.aten.to.dtype(where_self_66, torch.float32);  where_self_66 = None
        native_batch_norm_backward_default_66 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_200, convolution_default_27, primals_167, primals_165, primals_166, getitem_86, getitem_87, True, 0.001, [True, True, True]);  to_dtype_200 = convolution_default_27 = primals_167 = primals_165 = primals_166 = getitem_86 = getitem_87 = None
        getitem_686 = native_batch_norm_backward_default_66[0]
        getitem_687 = native_batch_norm_backward_default_66[1]
        getitem_688 = native_batch_norm_backward_default_66[2];  native_batch_norm_backward_default_66 = None
        convolution_backward_default_66 = torch.ops.aten.convolution_backward.default(getitem_686, cat_default_2, primals_168, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_686 = primals_168 = None
        getitem_689 = convolution_backward_default_66[0]
        getitem_690 = convolution_backward_default_66[1]
        getitem_691 = convolution_backward_default_66[2];  convolution_backward_default_66 = None
        add_tensor_24 = torch.ops.aten.add.Tensor(max_pool2d_with_indices_backward_default_1, getitem_689);  max_pool2d_with_indices_backward_default_1 = getitem_689 = None
        to_dtype_201 = torch.ops.aten.to.dtype(slice_tensor_35, torch.float32);  slice_tensor_35 = None
        to_dtype_202 = torch.ops.aten.to.dtype(relu__default_26, torch.float32);  relu__default_26 = None
        le_scalar_67 = torch.ops.aten.le.Scalar(to_dtype_202, 0);  to_dtype_202 = None
        new_zeros_default_161 = torch.ops.aten.new_zeros.default(to_dtype_201, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_67 = torch.ops.aten.where.self(le_scalar_67, new_zeros_default_161, to_dtype_201);  le_scalar_67 = new_zeros_default_161 = to_dtype_201 = None
        to_dtype_203 = torch.ops.aten.to.dtype(where_self_67, torch.float32);  where_self_67 = None
        native_batch_norm_backward_default_67 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_203, convolution_default_26, primals_161, primals_159, primals_160, getitem_83, getitem_84, True, 0.001, [True, True, True]);  to_dtype_203 = convolution_default_26 = primals_161 = primals_159 = primals_160 = getitem_83 = getitem_84 = None
        getitem_692 = native_batch_norm_backward_default_67[0]
        getitem_693 = native_batch_norm_backward_default_67[1]
        getitem_694 = native_batch_norm_backward_default_67[2];  native_batch_norm_backward_default_67 = None
        convolution_backward_default_67 = torch.ops.aten.convolution_backward.default(getitem_692, cat_default_2, primals_162, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_692 = cat_default_2 = primals_162 = None
        getitem_695 = convolution_backward_default_67[0]
        getitem_696 = convolution_backward_default_67[1]
        getitem_697 = convolution_backward_default_67[2];  convolution_backward_default_67 = None
        add_tensor_25 = torch.ops.aten.add.Tensor(add_tensor_24, getitem_695);  add_tensor_24 = getitem_695 = None
        slice_tensor_38 = torch.ops.aten.slice.Tensor(add_tensor_25, 1, 0, 64)
        slice_tensor_39 = torch.ops.aten.slice.Tensor(add_tensor_25, 1, 64, 128)
        slice_tensor_40 = torch.ops.aten.slice.Tensor(add_tensor_25, 1, 128, 224)
        slice_tensor_41 = torch.ops.aten.slice.Tensor(add_tensor_25, 1, 224, 288);  add_tensor_25 = None
        to_dtype_204 = torch.ops.aten.to.dtype(slice_tensor_41, torch.float32);  slice_tensor_41 = None
        to_dtype_205 = torch.ops.aten.to.dtype(relu__default_25, torch.float32);  relu__default_25 = None
        le_scalar_68 = torch.ops.aten.le.Scalar(to_dtype_205, 0);  to_dtype_205 = None
        new_zeros_default_162 = torch.ops.aten.new_zeros.default(to_dtype_204, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_68 = torch.ops.aten.where.self(le_scalar_68, new_zeros_default_162, to_dtype_204);  le_scalar_68 = new_zeros_default_162 = to_dtype_204 = None
        to_dtype_206 = torch.ops.aten.to.dtype(where_self_68, torch.float32);  where_self_68 = None
        native_batch_norm_backward_default_68 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_206, convolution_default_25, primals_155, primals_153, primals_154, getitem_80, getitem_81, True, 0.001, [True, True, True]);  to_dtype_206 = convolution_default_25 = primals_155 = primals_153 = primals_154 = getitem_80 = getitem_81 = None
        getitem_698 = native_batch_norm_backward_default_68[0]
        getitem_699 = native_batch_norm_backward_default_68[1]
        getitem_700 = native_batch_norm_backward_default_68[2];  native_batch_norm_backward_default_68 = None
        convolution_backward_default_68 = torch.ops.aten.convolution_backward.default(getitem_698, avg_pool2d_default_2, primals_156, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_698 = avg_pool2d_default_2 = primals_156 = None
        getitem_701 = convolution_backward_default_68[0]
        getitem_702 = convolution_backward_default_68[1]
        getitem_703 = convolution_backward_default_68[2];  convolution_backward_default_68 = None
        avg_pool2d_backward_default_6 = torch.ops.aten.avg_pool2d_backward.default(getitem_701, cat_default_1, [3, 3], [1, 1], [1, 1], False, True, None);  getitem_701 = None
        to_dtype_207 = torch.ops.aten.to.dtype(slice_tensor_40, torch.float32);  slice_tensor_40 = None
        to_dtype_208 = torch.ops.aten.to.dtype(relu__default_24, torch.float32);  relu__default_24 = None
        le_scalar_69 = torch.ops.aten.le.Scalar(to_dtype_208, 0);  to_dtype_208 = None
        new_zeros_default_163 = torch.ops.aten.new_zeros.default(to_dtype_207, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_69 = torch.ops.aten.where.self(le_scalar_69, new_zeros_default_163, to_dtype_207);  le_scalar_69 = new_zeros_default_163 = to_dtype_207 = None
        to_dtype_209 = torch.ops.aten.to.dtype(where_self_69, torch.float32);  where_self_69 = None
        native_batch_norm_backward_default_69 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_209, convolution_default_24, primals_137, primals_135, primals_136, getitem_77, getitem_78, True, 0.001, [True, True, True]);  to_dtype_209 = convolution_default_24 = primals_137 = primals_135 = primals_136 = getitem_77 = getitem_78 = None
        getitem_704 = native_batch_norm_backward_default_69[0]
        getitem_705 = native_batch_norm_backward_default_69[1]
        getitem_706 = native_batch_norm_backward_default_69[2];  native_batch_norm_backward_default_69 = None
        convolution_backward_default_69 = torch.ops.aten.convolution_backward.default(getitem_704, relu__default_23, primals_138, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_704 = primals_138 = None
        getitem_707 = convolution_backward_default_69[0]
        getitem_708 = convolution_backward_default_69[1]
        getitem_709 = convolution_backward_default_69[2];  convolution_backward_default_69 = None
        to_dtype_210 = torch.ops.aten.to.dtype(getitem_707, torch.float32);  getitem_707 = None
        to_dtype_211 = torch.ops.aten.to.dtype(relu__default_23, torch.float32);  relu__default_23 = None
        le_scalar_70 = torch.ops.aten.le.Scalar(to_dtype_211, 0);  to_dtype_211 = None
        new_zeros_default_164 = torch.ops.aten.new_zeros.default(to_dtype_210, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_70 = torch.ops.aten.where.self(le_scalar_70, new_zeros_default_164, to_dtype_210);  le_scalar_70 = new_zeros_default_164 = to_dtype_210 = None
        to_dtype_212 = torch.ops.aten.to.dtype(where_self_70, torch.float32);  where_self_70 = None
        native_batch_norm_backward_default_70 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_212, convolution_default_23, primals_131, primals_129, primals_130, getitem_74, getitem_75, True, 0.001, [True, True, True]);  to_dtype_212 = convolution_default_23 = primals_131 = primals_129 = primals_130 = getitem_74 = getitem_75 = None
        getitem_710 = native_batch_norm_backward_default_70[0]
        getitem_711 = native_batch_norm_backward_default_70[1]
        getitem_712 = native_batch_norm_backward_default_70[2];  native_batch_norm_backward_default_70 = None
        convolution_backward_default_70 = torch.ops.aten.convolution_backward.default(getitem_710, relu__default_22, primals_132, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_710 = primals_132 = None
        getitem_713 = convolution_backward_default_70[0]
        getitem_714 = convolution_backward_default_70[1]
        getitem_715 = convolution_backward_default_70[2];  convolution_backward_default_70 = None
        to_dtype_213 = torch.ops.aten.to.dtype(getitem_713, torch.float32);  getitem_713 = None
        to_dtype_214 = torch.ops.aten.to.dtype(relu__default_22, torch.float32);  relu__default_22 = None
        le_scalar_71 = torch.ops.aten.le.Scalar(to_dtype_214, 0);  to_dtype_214 = None
        new_zeros_default_165 = torch.ops.aten.new_zeros.default(to_dtype_213, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_71 = torch.ops.aten.where.self(le_scalar_71, new_zeros_default_165, to_dtype_213);  le_scalar_71 = new_zeros_default_165 = to_dtype_213 = None
        to_dtype_215 = torch.ops.aten.to.dtype(where_self_71, torch.float32);  where_self_71 = None
        native_batch_norm_backward_default_71 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_215, convolution_default_22, primals_125, primals_123, primals_124, getitem_71, getitem_72, True, 0.001, [True, True, True]);  to_dtype_215 = convolution_default_22 = primals_125 = primals_123 = primals_124 = getitem_71 = getitem_72 = None
        getitem_716 = native_batch_norm_backward_default_71[0]
        getitem_717 = native_batch_norm_backward_default_71[1]
        getitem_718 = native_batch_norm_backward_default_71[2];  native_batch_norm_backward_default_71 = None
        convolution_backward_default_71 = torch.ops.aten.convolution_backward.default(getitem_716, cat_default_1, primals_126, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_716 = primals_126 = None
        getitem_719 = convolution_backward_default_71[0]
        getitem_720 = convolution_backward_default_71[1]
        getitem_721 = convolution_backward_default_71[2];  convolution_backward_default_71 = None
        add_tensor_26 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default_6, getitem_719);  avg_pool2d_backward_default_6 = getitem_719 = None
        to_dtype_216 = torch.ops.aten.to.dtype(slice_tensor_39, torch.float32);  slice_tensor_39 = None
        to_dtype_217 = torch.ops.aten.to.dtype(relu__default_21, torch.float32);  relu__default_21 = None
        le_scalar_72 = torch.ops.aten.le.Scalar(to_dtype_217, 0);  to_dtype_217 = None
        new_zeros_default_166 = torch.ops.aten.new_zeros.default(to_dtype_216, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_72 = torch.ops.aten.where.self(le_scalar_72, new_zeros_default_166, to_dtype_216);  le_scalar_72 = new_zeros_default_166 = to_dtype_216 = None
        to_dtype_218 = torch.ops.aten.to.dtype(where_self_72, torch.float32);  where_self_72 = None
        native_batch_norm_backward_default_72 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_218, convolution_default_21, primals_149, primals_147, primals_148, getitem_68, getitem_69, True, 0.001, [True, True, True]);  to_dtype_218 = convolution_default_21 = primals_149 = primals_147 = primals_148 = getitem_68 = getitem_69 = None
        getitem_722 = native_batch_norm_backward_default_72[0]
        getitem_723 = native_batch_norm_backward_default_72[1]
        getitem_724 = native_batch_norm_backward_default_72[2];  native_batch_norm_backward_default_72 = None
        convolution_backward_default_72 = torch.ops.aten.convolution_backward.default(getitem_722, relu__default_20, primals_150, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_722 = primals_150 = None
        getitem_725 = convolution_backward_default_72[0]
        getitem_726 = convolution_backward_default_72[1]
        getitem_727 = convolution_backward_default_72[2];  convolution_backward_default_72 = None
        to_dtype_219 = torch.ops.aten.to.dtype(getitem_725, torch.float32);  getitem_725 = None
        to_dtype_220 = torch.ops.aten.to.dtype(relu__default_20, torch.float32);  relu__default_20 = None
        le_scalar_73 = torch.ops.aten.le.Scalar(to_dtype_220, 0);  to_dtype_220 = None
        new_zeros_default_167 = torch.ops.aten.new_zeros.default(to_dtype_219, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_73 = torch.ops.aten.where.self(le_scalar_73, new_zeros_default_167, to_dtype_219);  le_scalar_73 = new_zeros_default_167 = to_dtype_219 = None
        to_dtype_221 = torch.ops.aten.to.dtype(where_self_73, torch.float32);  where_self_73 = None
        native_batch_norm_backward_default_73 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_221, convolution_default_20, primals_143, primals_141, primals_142, getitem_65, getitem_66, True, 0.001, [True, True, True]);  to_dtype_221 = convolution_default_20 = primals_143 = primals_141 = primals_142 = getitem_65 = getitem_66 = None
        getitem_728 = native_batch_norm_backward_default_73[0]
        getitem_729 = native_batch_norm_backward_default_73[1]
        getitem_730 = native_batch_norm_backward_default_73[2];  native_batch_norm_backward_default_73 = None
        convolution_backward_default_73 = torch.ops.aten.convolution_backward.default(getitem_728, cat_default_1, primals_144, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_728 = primals_144 = None
        getitem_731 = convolution_backward_default_73[0]
        getitem_732 = convolution_backward_default_73[1]
        getitem_733 = convolution_backward_default_73[2];  convolution_backward_default_73 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(add_tensor_26, getitem_731);  add_tensor_26 = getitem_731 = None
        to_dtype_222 = torch.ops.aten.to.dtype(slice_tensor_38, torch.float32);  slice_tensor_38 = None
        to_dtype_223 = torch.ops.aten.to.dtype(relu__default_19, torch.float32);  relu__default_19 = None
        le_scalar_74 = torch.ops.aten.le.Scalar(to_dtype_223, 0);  to_dtype_223 = None
        new_zeros_default_168 = torch.ops.aten.new_zeros.default(to_dtype_222, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_74 = torch.ops.aten.where.self(le_scalar_74, new_zeros_default_168, to_dtype_222);  le_scalar_74 = new_zeros_default_168 = to_dtype_222 = None
        to_dtype_224 = torch.ops.aten.to.dtype(where_self_74, torch.float32);  where_self_74 = None
        native_batch_norm_backward_default_74 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_224, convolution_default_19, primals_119, primals_117, primals_118, getitem_62, getitem_63, True, 0.001, [True, True, True]);  to_dtype_224 = convolution_default_19 = primals_119 = primals_117 = primals_118 = getitem_62 = getitem_63 = None
        getitem_734 = native_batch_norm_backward_default_74[0]
        getitem_735 = native_batch_norm_backward_default_74[1]
        getitem_736 = native_batch_norm_backward_default_74[2];  native_batch_norm_backward_default_74 = None
        convolution_backward_default_74 = torch.ops.aten.convolution_backward.default(getitem_734, cat_default_1, primals_120, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_734 = cat_default_1 = primals_120 = None
        getitem_737 = convolution_backward_default_74[0]
        getitem_738 = convolution_backward_default_74[1]
        getitem_739 = convolution_backward_default_74[2];  convolution_backward_default_74 = None
        add_tensor_28 = torch.ops.aten.add.Tensor(add_tensor_27, getitem_737);  add_tensor_27 = getitem_737 = None
        slice_tensor_42 = torch.ops.aten.slice.Tensor(add_tensor_28, 1, 0, 64)
        slice_tensor_43 = torch.ops.aten.slice.Tensor(add_tensor_28, 1, 64, 128)
        slice_tensor_44 = torch.ops.aten.slice.Tensor(add_tensor_28, 1, 128, 224)
        slice_tensor_45 = torch.ops.aten.slice.Tensor(add_tensor_28, 1, 224, 288);  add_tensor_28 = None
        to_dtype_225 = torch.ops.aten.to.dtype(slice_tensor_45, torch.float32);  slice_tensor_45 = None
        to_dtype_226 = torch.ops.aten.to.dtype(relu__default_18, torch.float32);  relu__default_18 = None
        le_scalar_75 = torch.ops.aten.le.Scalar(to_dtype_226, 0);  to_dtype_226 = None
        new_zeros_default_169 = torch.ops.aten.new_zeros.default(to_dtype_225, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_75 = torch.ops.aten.where.self(le_scalar_75, new_zeros_default_169, to_dtype_225);  le_scalar_75 = new_zeros_default_169 = to_dtype_225 = None
        to_dtype_227 = torch.ops.aten.to.dtype(where_self_75, torch.float32);  where_self_75 = None
        native_batch_norm_backward_default_75 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_227, convolution_default_18, primals_113, primals_111, primals_112, getitem_59, getitem_60, True, 0.001, [True, True, True]);  to_dtype_227 = convolution_default_18 = primals_113 = primals_111 = primals_112 = getitem_59 = getitem_60 = None
        getitem_740 = native_batch_norm_backward_default_75[0]
        getitem_741 = native_batch_norm_backward_default_75[1]
        getitem_742 = native_batch_norm_backward_default_75[2];  native_batch_norm_backward_default_75 = None
        convolution_backward_default_75 = torch.ops.aten.convolution_backward.default(getitem_740, avg_pool2d_default_1, primals_114, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_740 = avg_pool2d_default_1 = primals_114 = None
        getitem_743 = convolution_backward_default_75[0]
        getitem_744 = convolution_backward_default_75[1]
        getitem_745 = convolution_backward_default_75[2];  convolution_backward_default_75 = None
        avg_pool2d_backward_default_7 = torch.ops.aten.avg_pool2d_backward.default(getitem_743, cat_default, [3, 3], [1, 1], [1, 1], False, True, None);  getitem_743 = None
        to_dtype_228 = torch.ops.aten.to.dtype(slice_tensor_44, torch.float32);  slice_tensor_44 = None
        to_dtype_229 = torch.ops.aten.to.dtype(relu__default_17, torch.float32);  relu__default_17 = None
        le_scalar_76 = torch.ops.aten.le.Scalar(to_dtype_229, 0);  to_dtype_229 = None
        new_zeros_default_170 = torch.ops.aten.new_zeros.default(to_dtype_228, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_76 = torch.ops.aten.where.self(le_scalar_76, new_zeros_default_170, to_dtype_228);  le_scalar_76 = new_zeros_default_170 = to_dtype_228 = None
        to_dtype_230 = torch.ops.aten.to.dtype(where_self_76, torch.float32);  where_self_76 = None
        native_batch_norm_backward_default_76 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_230, convolution_default_17, primals_95, primals_93, primals_94, getitem_56, getitem_57, True, 0.001, [True, True, True]);  to_dtype_230 = convolution_default_17 = primals_95 = primals_93 = primals_94 = getitem_56 = getitem_57 = None
        getitem_746 = native_batch_norm_backward_default_76[0]
        getitem_747 = native_batch_norm_backward_default_76[1]
        getitem_748 = native_batch_norm_backward_default_76[2];  native_batch_norm_backward_default_76 = None
        convolution_backward_default_76 = torch.ops.aten.convolution_backward.default(getitem_746, relu__default_16, primals_96, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_746 = primals_96 = None
        getitem_749 = convolution_backward_default_76[0]
        getitem_750 = convolution_backward_default_76[1]
        getitem_751 = convolution_backward_default_76[2];  convolution_backward_default_76 = None
        to_dtype_231 = torch.ops.aten.to.dtype(getitem_749, torch.float32);  getitem_749 = None
        to_dtype_232 = torch.ops.aten.to.dtype(relu__default_16, torch.float32);  relu__default_16 = None
        le_scalar_77 = torch.ops.aten.le.Scalar(to_dtype_232, 0);  to_dtype_232 = None
        new_zeros_default_171 = torch.ops.aten.new_zeros.default(to_dtype_231, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_77 = torch.ops.aten.where.self(le_scalar_77, new_zeros_default_171, to_dtype_231);  le_scalar_77 = new_zeros_default_171 = to_dtype_231 = None
        to_dtype_233 = torch.ops.aten.to.dtype(where_self_77, torch.float32);  where_self_77 = None
        native_batch_norm_backward_default_77 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_233, convolution_default_16, primals_89, primals_87, primals_88, getitem_53, getitem_54, True, 0.001, [True, True, True]);  to_dtype_233 = convolution_default_16 = primals_89 = primals_87 = primals_88 = getitem_53 = getitem_54 = None
        getitem_752 = native_batch_norm_backward_default_77[0]
        getitem_753 = native_batch_norm_backward_default_77[1]
        getitem_754 = native_batch_norm_backward_default_77[2];  native_batch_norm_backward_default_77 = None
        convolution_backward_default_77 = torch.ops.aten.convolution_backward.default(getitem_752, relu__default_15, primals_90, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_752 = primals_90 = None
        getitem_755 = convolution_backward_default_77[0]
        getitem_756 = convolution_backward_default_77[1]
        getitem_757 = convolution_backward_default_77[2];  convolution_backward_default_77 = None
        to_dtype_234 = torch.ops.aten.to.dtype(getitem_755, torch.float32);  getitem_755 = None
        to_dtype_235 = torch.ops.aten.to.dtype(relu__default_15, torch.float32);  relu__default_15 = None
        le_scalar_78 = torch.ops.aten.le.Scalar(to_dtype_235, 0);  to_dtype_235 = None
        new_zeros_default_172 = torch.ops.aten.new_zeros.default(to_dtype_234, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_78 = torch.ops.aten.where.self(le_scalar_78, new_zeros_default_172, to_dtype_234);  le_scalar_78 = new_zeros_default_172 = to_dtype_234 = None
        to_dtype_236 = torch.ops.aten.to.dtype(where_self_78, torch.float32);  where_self_78 = None
        native_batch_norm_backward_default_78 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_236, convolution_default_15, primals_83, primals_81, primals_82, getitem_50, getitem_51, True, 0.001, [True, True, True]);  to_dtype_236 = convolution_default_15 = primals_83 = primals_81 = primals_82 = getitem_50 = getitem_51 = None
        getitem_758 = native_batch_norm_backward_default_78[0]
        getitem_759 = native_batch_norm_backward_default_78[1]
        getitem_760 = native_batch_norm_backward_default_78[2];  native_batch_norm_backward_default_78 = None
        convolution_backward_default_78 = torch.ops.aten.convolution_backward.default(getitem_758, cat_default, primals_84, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_758 = primals_84 = None
        getitem_761 = convolution_backward_default_78[0]
        getitem_762 = convolution_backward_default_78[1]
        getitem_763 = convolution_backward_default_78[2];  convolution_backward_default_78 = None
        add_tensor_29 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default_7, getitem_761);  avg_pool2d_backward_default_7 = getitem_761 = None
        to_dtype_237 = torch.ops.aten.to.dtype(slice_tensor_43, torch.float32);  slice_tensor_43 = None
        to_dtype_238 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar_79 = torch.ops.aten.le.Scalar(to_dtype_238, 0);  to_dtype_238 = None
        new_zeros_default_173 = torch.ops.aten.new_zeros.default(to_dtype_237, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_79 = torch.ops.aten.where.self(le_scalar_79, new_zeros_default_173, to_dtype_237);  le_scalar_79 = new_zeros_default_173 = to_dtype_237 = None
        to_dtype_239 = torch.ops.aten.to.dtype(where_self_79, torch.float32);  where_self_79 = None
        native_batch_norm_backward_default_79 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_239, convolution_default_14, primals_107, primals_105, primals_106, getitem_47, getitem_48, True, 0.001, [True, True, True]);  to_dtype_239 = convolution_default_14 = primals_107 = primals_105 = primals_106 = getitem_47 = getitem_48 = None
        getitem_764 = native_batch_norm_backward_default_79[0]
        getitem_765 = native_batch_norm_backward_default_79[1]
        getitem_766 = native_batch_norm_backward_default_79[2];  native_batch_norm_backward_default_79 = None
        convolution_backward_default_79 = torch.ops.aten.convolution_backward.default(getitem_764, relu__default_13, primals_108, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_764 = primals_108 = None
        getitem_767 = convolution_backward_default_79[0]
        getitem_768 = convolution_backward_default_79[1]
        getitem_769 = convolution_backward_default_79[2];  convolution_backward_default_79 = None
        to_dtype_240 = torch.ops.aten.to.dtype(getitem_767, torch.float32);  getitem_767 = None
        to_dtype_241 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_80 = torch.ops.aten.le.Scalar(to_dtype_241, 0);  to_dtype_241 = None
        new_zeros_default_174 = torch.ops.aten.new_zeros.default(to_dtype_240, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_80 = torch.ops.aten.where.self(le_scalar_80, new_zeros_default_174, to_dtype_240);  le_scalar_80 = new_zeros_default_174 = to_dtype_240 = None
        to_dtype_242 = torch.ops.aten.to.dtype(where_self_80, torch.float32);  where_self_80 = None
        native_batch_norm_backward_default_80 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_242, convolution_default_13, primals_101, primals_99, primals_100, getitem_44, getitem_45, True, 0.001, [True, True, True]);  to_dtype_242 = convolution_default_13 = primals_101 = primals_99 = primals_100 = getitem_44 = getitem_45 = None
        getitem_770 = native_batch_norm_backward_default_80[0]
        getitem_771 = native_batch_norm_backward_default_80[1]
        getitem_772 = native_batch_norm_backward_default_80[2];  native_batch_norm_backward_default_80 = None
        convolution_backward_default_80 = torch.ops.aten.convolution_backward.default(getitem_770, cat_default, primals_102, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_770 = primals_102 = None
        getitem_773 = convolution_backward_default_80[0]
        getitem_774 = convolution_backward_default_80[1]
        getitem_775 = convolution_backward_default_80[2];  convolution_backward_default_80 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(add_tensor_29, getitem_773);  add_tensor_29 = getitem_773 = None
        to_dtype_243 = torch.ops.aten.to.dtype(slice_tensor_42, torch.float32);  slice_tensor_42 = None
        to_dtype_244 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_81 = torch.ops.aten.le.Scalar(to_dtype_244, 0);  to_dtype_244 = None
        new_zeros_default_175 = torch.ops.aten.new_zeros.default(to_dtype_243, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_81 = torch.ops.aten.where.self(le_scalar_81, new_zeros_default_175, to_dtype_243);  le_scalar_81 = new_zeros_default_175 = to_dtype_243 = None
        to_dtype_245 = torch.ops.aten.to.dtype(where_self_81, torch.float32);  where_self_81 = None
        native_batch_norm_backward_default_81 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_245, convolution_default_12, primals_77, primals_75, primals_76, getitem_41, getitem_42, True, 0.001, [True, True, True]);  to_dtype_245 = convolution_default_12 = primals_77 = primals_75 = primals_76 = getitem_41 = getitem_42 = None
        getitem_776 = native_batch_norm_backward_default_81[0]
        getitem_777 = native_batch_norm_backward_default_81[1]
        getitem_778 = native_batch_norm_backward_default_81[2];  native_batch_norm_backward_default_81 = None
        convolution_backward_default_81 = torch.ops.aten.convolution_backward.default(getitem_776, cat_default, primals_78, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_776 = cat_default = primals_78 = None
        getitem_779 = convolution_backward_default_81[0]
        getitem_780 = convolution_backward_default_81[1]
        getitem_781 = convolution_backward_default_81[2];  convolution_backward_default_81 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(add_tensor_30, getitem_779);  add_tensor_30 = getitem_779 = None
        slice_tensor_46 = torch.ops.aten.slice.Tensor(add_tensor_31, 1, 0, 64)
        slice_tensor_47 = torch.ops.aten.slice.Tensor(add_tensor_31, 1, 64, 128)
        slice_tensor_48 = torch.ops.aten.slice.Tensor(add_tensor_31, 1, 128, 224)
        slice_tensor_49 = torch.ops.aten.slice.Tensor(add_tensor_31, 1, 224, 256);  add_tensor_31 = None
        to_dtype_246 = torch.ops.aten.to.dtype(slice_tensor_49, torch.float32);  slice_tensor_49 = None
        to_dtype_247 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_82 = torch.ops.aten.le.Scalar(to_dtype_247, 0);  to_dtype_247 = None
        new_zeros_default_176 = torch.ops.aten.new_zeros.default(to_dtype_246, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_82 = torch.ops.aten.where.self(le_scalar_82, new_zeros_default_176, to_dtype_246);  le_scalar_82 = new_zeros_default_176 = to_dtype_246 = None
        to_dtype_248 = torch.ops.aten.to.dtype(where_self_82, torch.float32);  where_self_82 = None
        native_batch_norm_backward_default_82 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_248, convolution_default_11, primals_71, primals_69, primals_70, getitem_38, getitem_39, True, 0.001, [True, True, True]);  to_dtype_248 = convolution_default_11 = primals_71 = primals_69 = primals_70 = getitem_38 = getitem_39 = None
        getitem_782 = native_batch_norm_backward_default_82[0]
        getitem_783 = native_batch_norm_backward_default_82[1]
        getitem_784 = native_batch_norm_backward_default_82[2];  native_batch_norm_backward_default_82 = None
        convolution_backward_default_82 = torch.ops.aten.convolution_backward.default(getitem_782, avg_pool2d_default, primals_72, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_782 = avg_pool2d_default = primals_72 = None
        getitem_785 = convolution_backward_default_82[0]
        getitem_786 = convolution_backward_default_82[1]
        getitem_787 = convolution_backward_default_82[2];  convolution_backward_default_82 = None
        avg_pool2d_backward_default_8 = torch.ops.aten.avg_pool2d_backward.default(getitem_785, getitem_17, [3, 3], [1, 1], [1, 1], False, True, None);  getitem_785 = None
        to_dtype_249 = torch.ops.aten.to.dtype(slice_tensor_48, torch.float32);  slice_tensor_48 = None
        to_dtype_250 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_83 = torch.ops.aten.le.Scalar(to_dtype_250, 0);  to_dtype_250 = None
        new_zeros_default_177 = torch.ops.aten.new_zeros.default(to_dtype_249, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_83 = torch.ops.aten.where.self(le_scalar_83, new_zeros_default_177, to_dtype_249);  le_scalar_83 = new_zeros_default_177 = to_dtype_249 = None
        to_dtype_251 = torch.ops.aten.to.dtype(where_self_83, torch.float32);  where_self_83 = None
        native_batch_norm_backward_default_83 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_251, convolution_default_10, primals_53, primals_51, primals_52, getitem_35, getitem_36, True, 0.001, [True, True, True]);  to_dtype_251 = convolution_default_10 = primals_53 = primals_51 = primals_52 = getitem_35 = getitem_36 = None
        getitem_788 = native_batch_norm_backward_default_83[0]
        getitem_789 = native_batch_norm_backward_default_83[1]
        getitem_790 = native_batch_norm_backward_default_83[2];  native_batch_norm_backward_default_83 = None
        convolution_backward_default_83 = torch.ops.aten.convolution_backward.default(getitem_788, relu__default_9, primals_54, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_788 = primals_54 = None
        getitem_791 = convolution_backward_default_83[0]
        getitem_792 = convolution_backward_default_83[1]
        getitem_793 = convolution_backward_default_83[2];  convolution_backward_default_83 = None
        to_dtype_252 = torch.ops.aten.to.dtype(getitem_791, torch.float32);  getitem_791 = None
        to_dtype_253 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_84 = torch.ops.aten.le.Scalar(to_dtype_253, 0);  to_dtype_253 = None
        new_zeros_default_178 = torch.ops.aten.new_zeros.default(to_dtype_252, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_84 = torch.ops.aten.where.self(le_scalar_84, new_zeros_default_178, to_dtype_252);  le_scalar_84 = new_zeros_default_178 = to_dtype_252 = None
        to_dtype_254 = torch.ops.aten.to.dtype(where_self_84, torch.float32);  where_self_84 = None
        native_batch_norm_backward_default_84 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_254, convolution_default_9, primals_47, primals_45, primals_46, getitem_32, getitem_33, True, 0.001, [True, True, True]);  to_dtype_254 = convolution_default_9 = primals_47 = primals_45 = primals_46 = getitem_32 = getitem_33 = None
        getitem_794 = native_batch_norm_backward_default_84[0]
        getitem_795 = native_batch_norm_backward_default_84[1]
        getitem_796 = native_batch_norm_backward_default_84[2];  native_batch_norm_backward_default_84 = None
        convolution_backward_default_84 = torch.ops.aten.convolution_backward.default(getitem_794, relu__default_8, primals_48, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_794 = primals_48 = None
        getitem_797 = convolution_backward_default_84[0]
        getitem_798 = convolution_backward_default_84[1]
        getitem_799 = convolution_backward_default_84[2];  convolution_backward_default_84 = None
        to_dtype_255 = torch.ops.aten.to.dtype(getitem_797, torch.float32);  getitem_797 = None
        to_dtype_256 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_85 = torch.ops.aten.le.Scalar(to_dtype_256, 0);  to_dtype_256 = None
        new_zeros_default_179 = torch.ops.aten.new_zeros.default(to_dtype_255, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_85 = torch.ops.aten.where.self(le_scalar_85, new_zeros_default_179, to_dtype_255);  le_scalar_85 = new_zeros_default_179 = to_dtype_255 = None
        to_dtype_257 = torch.ops.aten.to.dtype(where_self_85, torch.float32);  where_self_85 = None
        native_batch_norm_backward_default_85 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_257, convolution_default_8, primals_41, primals_39, primals_40, getitem_29, getitem_30, True, 0.001, [True, True, True]);  to_dtype_257 = convolution_default_8 = primals_41 = primals_39 = primals_40 = getitem_29 = getitem_30 = None
        getitem_800 = native_batch_norm_backward_default_85[0]
        getitem_801 = native_batch_norm_backward_default_85[1]
        getitem_802 = native_batch_norm_backward_default_85[2];  native_batch_norm_backward_default_85 = None
        convolution_backward_default_85 = torch.ops.aten.convolution_backward.default(getitem_800, getitem_17, primals_42, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_800 = primals_42 = None
        getitem_803 = convolution_backward_default_85[0]
        getitem_804 = convolution_backward_default_85[1]
        getitem_805 = convolution_backward_default_85[2];  convolution_backward_default_85 = None
        add_tensor_32 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default_8, getitem_803);  avg_pool2d_backward_default_8 = getitem_803 = None
        to_dtype_258 = torch.ops.aten.to.dtype(slice_tensor_47, torch.float32);  slice_tensor_47 = None
        to_dtype_259 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_86 = torch.ops.aten.le.Scalar(to_dtype_259, 0);  to_dtype_259 = None
        new_zeros_default_180 = torch.ops.aten.new_zeros.default(to_dtype_258, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_86 = torch.ops.aten.where.self(le_scalar_86, new_zeros_default_180, to_dtype_258);  le_scalar_86 = new_zeros_default_180 = to_dtype_258 = None
        to_dtype_260 = torch.ops.aten.to.dtype(where_self_86, torch.float32);  where_self_86 = None
        native_batch_norm_backward_default_86 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_260, convolution_default_7, primals_65, primals_63, primals_64, getitem_26, getitem_27, True, 0.001, [True, True, True]);  to_dtype_260 = convolution_default_7 = primals_65 = primals_63 = primals_64 = getitem_26 = getitem_27 = None
        getitem_806 = native_batch_norm_backward_default_86[0]
        getitem_807 = native_batch_norm_backward_default_86[1]
        getitem_808 = native_batch_norm_backward_default_86[2];  native_batch_norm_backward_default_86 = None
        convolution_backward_default_86 = torch.ops.aten.convolution_backward.default(getitem_806, relu__default_6, primals_66, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_806 = primals_66 = None
        getitem_809 = convolution_backward_default_86[0]
        getitem_810 = convolution_backward_default_86[1]
        getitem_811 = convolution_backward_default_86[2];  convolution_backward_default_86 = None
        to_dtype_261 = torch.ops.aten.to.dtype(getitem_809, torch.float32);  getitem_809 = None
        to_dtype_262 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_87 = torch.ops.aten.le.Scalar(to_dtype_262, 0);  to_dtype_262 = None
        new_zeros_default_181 = torch.ops.aten.new_zeros.default(to_dtype_261, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_87 = torch.ops.aten.where.self(le_scalar_87, new_zeros_default_181, to_dtype_261);  le_scalar_87 = new_zeros_default_181 = to_dtype_261 = None
        to_dtype_263 = torch.ops.aten.to.dtype(where_self_87, torch.float32);  where_self_87 = None
        native_batch_norm_backward_default_87 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_263, convolution_default_6, primals_59, primals_57, primals_58, getitem_23, getitem_24, True, 0.001, [True, True, True]);  to_dtype_263 = convolution_default_6 = primals_59 = primals_57 = primals_58 = getitem_23 = getitem_24 = None
        getitem_812 = native_batch_norm_backward_default_87[0]
        getitem_813 = native_batch_norm_backward_default_87[1]
        getitem_814 = native_batch_norm_backward_default_87[2];  native_batch_norm_backward_default_87 = None
        convolution_backward_default_87 = torch.ops.aten.convolution_backward.default(getitem_812, getitem_17, primals_60, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_812 = primals_60 = None
        getitem_815 = convolution_backward_default_87[0]
        getitem_816 = convolution_backward_default_87[1]
        getitem_817 = convolution_backward_default_87[2];  convolution_backward_default_87 = None
        add_tensor_33 = torch.ops.aten.add.Tensor(add_tensor_32, getitem_815);  add_tensor_32 = getitem_815 = None
        to_dtype_264 = torch.ops.aten.to.dtype(slice_tensor_46, torch.float32);  slice_tensor_46 = None
        to_dtype_265 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_88 = torch.ops.aten.le.Scalar(to_dtype_265, 0);  to_dtype_265 = None
        new_zeros_default_182 = torch.ops.aten.new_zeros.default(to_dtype_264, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_88 = torch.ops.aten.where.self(le_scalar_88, new_zeros_default_182, to_dtype_264);  le_scalar_88 = new_zeros_default_182 = to_dtype_264 = None
        to_dtype_266 = torch.ops.aten.to.dtype(where_self_88, torch.float32);  where_self_88 = None
        native_batch_norm_backward_default_88 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_266, convolution_default_5, primals_35, primals_33, primals_34, getitem_20, getitem_21, True, 0.001, [True, True, True]);  to_dtype_266 = convolution_default_5 = primals_35 = primals_33 = primals_34 = getitem_20 = getitem_21 = None
        getitem_818 = native_batch_norm_backward_default_88[0]
        getitem_819 = native_batch_norm_backward_default_88[1]
        getitem_820 = native_batch_norm_backward_default_88[2];  native_batch_norm_backward_default_88 = None
        convolution_backward_default_88 = torch.ops.aten.convolution_backward.default(getitem_818, getitem_17, primals_36, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_818 = getitem_17 = primals_36 = None
        getitem_821 = convolution_backward_default_88[0]
        getitem_822 = convolution_backward_default_88[1]
        getitem_823 = convolution_backward_default_88[2];  convolution_backward_default_88 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(add_tensor_33, getitem_821);  add_tensor_33 = getitem_821 = None
        max_pool2d_with_indices_backward_default_2 = torch.ops.aten.max_pool2d_with_indices_backward.default(add_tensor_34, relu__default_4, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_18);  add_tensor_34 = getitem_18 = None
        to_dtype_267 = torch.ops.aten.to.dtype(max_pool2d_with_indices_backward_default_2, torch.float32);  max_pool2d_with_indices_backward_default_2 = None
        to_dtype_268 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_89 = torch.ops.aten.le.Scalar(to_dtype_268, 0);  to_dtype_268 = None
        new_zeros_default_183 = torch.ops.aten.new_zeros.default(to_dtype_267, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_89 = torch.ops.aten.where.self(le_scalar_89, new_zeros_default_183, to_dtype_267);  le_scalar_89 = new_zeros_default_183 = to_dtype_267 = None
        to_dtype_269 = torch.ops.aten.to.dtype(where_self_89, torch.float32);  where_self_89 = None
        native_batch_norm_backward_default_89 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_269, convolution_default_4, primals_29, primals_27, primals_28, getitem_15, getitem_16, True, 0.001, [True, True, True]);  to_dtype_269 = convolution_default_4 = primals_29 = primals_27 = primals_28 = getitem_15 = getitem_16 = None
        getitem_824 = native_batch_norm_backward_default_89[0]
        getitem_825 = native_batch_norm_backward_default_89[1]
        getitem_826 = native_batch_norm_backward_default_89[2];  native_batch_norm_backward_default_89 = None
        convolution_backward_default_89 = torch.ops.aten.convolution_backward.default(getitem_824, relu__default_3, primals_30, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_824 = primals_30 = None
        getitem_827 = convolution_backward_default_89[0]
        getitem_828 = convolution_backward_default_89[1]
        getitem_829 = convolution_backward_default_89[2];  convolution_backward_default_89 = None
        to_dtype_270 = torch.ops.aten.to.dtype(getitem_827, torch.float32);  getitem_827 = None
        to_dtype_271 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_90 = torch.ops.aten.le.Scalar(to_dtype_271, 0);  to_dtype_271 = None
        new_zeros_default_184 = torch.ops.aten.new_zeros.default(to_dtype_270, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_90 = torch.ops.aten.where.self(le_scalar_90, new_zeros_default_184, to_dtype_270);  le_scalar_90 = new_zeros_default_184 = to_dtype_270 = None
        to_dtype_272 = torch.ops.aten.to.dtype(where_self_90, torch.float32);  where_self_90 = None
        native_batch_norm_backward_default_90 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_272, convolution_default_3, primals_23, primals_21, primals_22, getitem_12, getitem_13, True, 0.001, [True, True, True]);  to_dtype_272 = convolution_default_3 = primals_23 = primals_21 = primals_22 = getitem_12 = getitem_13 = None
        getitem_830 = native_batch_norm_backward_default_90[0]
        getitem_831 = native_batch_norm_backward_default_90[1]
        getitem_832 = native_batch_norm_backward_default_90[2];  native_batch_norm_backward_default_90 = None
        convolution_backward_default_90 = torch.ops.aten.convolution_backward.default(getitem_830, getitem_9, primals_24, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_830 = getitem_9 = primals_24 = None
        getitem_833 = convolution_backward_default_90[0]
        getitem_834 = convolution_backward_default_90[1]
        getitem_835 = convolution_backward_default_90[2];  convolution_backward_default_90 = None
        max_pool2d_with_indices_backward_default_3 = torch.ops.aten.max_pool2d_with_indices_backward.default(getitem_833, relu__default_2, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_10);  getitem_833 = getitem_10 = None
        to_dtype_273 = torch.ops.aten.to.dtype(max_pool2d_with_indices_backward_default_3, torch.float32);  max_pool2d_with_indices_backward_default_3 = None
        to_dtype_274 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_91 = torch.ops.aten.le.Scalar(to_dtype_274, 0);  to_dtype_274 = None
        new_zeros_default_185 = torch.ops.aten.new_zeros.default(to_dtype_273, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_91 = torch.ops.aten.where.self(le_scalar_91, new_zeros_default_185, to_dtype_273);  le_scalar_91 = new_zeros_default_185 = to_dtype_273 = None
        to_dtype_275 = torch.ops.aten.to.dtype(where_self_91, torch.float32);  where_self_91 = None
        native_batch_norm_backward_default_91 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_275, convolution_default_2, primals_17, primals_15, primals_16, getitem_7, getitem_8, True, 0.001, [True, True, True]);  to_dtype_275 = convolution_default_2 = primals_17 = primals_15 = primals_16 = getitem_7 = getitem_8 = None
        getitem_836 = native_batch_norm_backward_default_91[0]
        getitem_837 = native_batch_norm_backward_default_91[1]
        getitem_838 = native_batch_norm_backward_default_91[2];  native_batch_norm_backward_default_91 = None
        convolution_backward_default_91 = torch.ops.aten.convolution_backward.default(getitem_836, relu__default_1, primals_18, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_836 = primals_18 = None
        getitem_839 = convolution_backward_default_91[0]
        getitem_840 = convolution_backward_default_91[1]
        getitem_841 = convolution_backward_default_91[2];  convolution_backward_default_91 = None
        to_dtype_276 = torch.ops.aten.to.dtype(getitem_839, torch.float32);  getitem_839 = None
        to_dtype_277 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_92 = torch.ops.aten.le.Scalar(to_dtype_277, 0);  to_dtype_277 = None
        new_zeros_default_186 = torch.ops.aten.new_zeros.default(to_dtype_276, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_92 = torch.ops.aten.where.self(le_scalar_92, new_zeros_default_186, to_dtype_276);  le_scalar_92 = new_zeros_default_186 = to_dtype_276 = None
        to_dtype_278 = torch.ops.aten.to.dtype(where_self_92, torch.float32);  where_self_92 = None
        native_batch_norm_backward_default_92 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_278, convolution_default_1, primals_11, primals_9, primals_10, getitem_4, getitem_5, True, 0.001, [True, True, True]);  to_dtype_278 = convolution_default_1 = primals_11 = primals_9 = primals_10 = getitem_4 = getitem_5 = None
        getitem_842 = native_batch_norm_backward_default_92[0]
        getitem_843 = native_batch_norm_backward_default_92[1]
        getitem_844 = native_batch_norm_backward_default_92[2];  native_batch_norm_backward_default_92 = None
        convolution_backward_default_92 = torch.ops.aten.convolution_backward.default(getitem_842, relu__default, primals_12, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_842 = primals_12 = None
        getitem_845 = convolution_backward_default_92[0]
        getitem_846 = convolution_backward_default_92[1]
        getitem_847 = convolution_backward_default_92[2];  convolution_backward_default_92 = None
        to_dtype_279 = torch.ops.aten.to.dtype(getitem_845, torch.float32);  getitem_845 = None
        to_dtype_280 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_93 = torch.ops.aten.le.Scalar(to_dtype_280, 0);  to_dtype_280 = None
        new_zeros_default_187 = torch.ops.aten.new_zeros.default(to_dtype_279, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_93 = torch.ops.aten.where.self(le_scalar_93, new_zeros_default_187, to_dtype_279);  le_scalar_93 = new_zeros_default_187 = to_dtype_279 = None
        to_dtype_281 = torch.ops.aten.to.dtype(where_self_93, torch.float32);  where_self_93 = None
        native_batch_norm_backward_default_93 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_281, convolution_default, primals_5, primals_3, primals_4, getitem_1, getitem_2, True, 0.001, [True, True, True]);  to_dtype_281 = convolution_default = primals_5 = primals_3 = primals_4 = getitem_1 = getitem_2 = None
        getitem_848 = native_batch_norm_backward_default_93[0]
        getitem_849 = native_batch_norm_backward_default_93[1]
        getitem_850 = native_batch_norm_backward_default_93[2];  native_batch_norm_backward_default_93 = None
        convolution_backward_default_93 = torch.ops.aten.convolution_backward.default(getitem_848, primals_567, primals_6, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_848 = primals_567 = primals_6 = None
        getitem_851 = convolution_backward_default_93[0]
        getitem_852 = convolution_backward_default_93[1]
        getitem_853 = convolution_backward_default_93[2];  convolution_backward_default_93 = None
        return [addmm_default, getitem_850, None, None, None, getitem_849, getitem_852, getitem_844, None, None, None, getitem_843, getitem_846, getitem_838, None, None, None, getitem_837, getitem_840, getitem_832, None, None, None, getitem_831, getitem_834, getitem_826, None, None, None, getitem_825, getitem_828, getitem_820, None, None, None, getitem_819, getitem_822, getitem_802, None, None, None, getitem_801, getitem_804, getitem_796, None, None, None, getitem_795, getitem_798, getitem_790, None, None, None, getitem_789, getitem_792, getitem_814, None, None, None, getitem_813, getitem_816, getitem_808, None, None, None, getitem_807, getitem_810, getitem_784, None, None, None, getitem_783, getitem_786, getitem_778, None, None, None, getitem_777, getitem_780, getitem_760, None, None, None, getitem_759, getitem_762, getitem_754, None, None, None, getitem_753, getitem_756, getitem_748, None, None, None, getitem_747, getitem_750, getitem_772, None, None, None, getitem_771, getitem_774, getitem_766, None, None, None, getitem_765, getitem_768, getitem_742, None, None, None, getitem_741, getitem_744, getitem_736, None, None, None, getitem_735, getitem_738, getitem_718, None, None, None, getitem_717, getitem_720, getitem_712, None, None, None, getitem_711, getitem_714, getitem_706, None, None, None, getitem_705, getitem_708, getitem_730, None, None, None, getitem_729, getitem_732, getitem_724, None, None, None, getitem_723, getitem_726, getitem_700, None, None, None, getitem_699, getitem_702, getitem_694, None, None, None, getitem_693, getitem_696, getitem_688, None, None, None, getitem_687, getitem_690, getitem_682, None, None, None, getitem_681, getitem_684, getitem_676, None, None, None, getitem_675, getitem_678, getitem_670, None, None, None, getitem_669, getitem_672, getitem_664, None, None, None, getitem_663, getitem_666, getitem_658, None, None, None, getitem_657, getitem_660, getitem_652, None, None, None, getitem_651, getitem_654, getitem_646, None, None, None, getitem_645, getitem_648, getitem_640, None, None, None, getitem_639, getitem_642, getitem_634, None, None, None, getitem_633, getitem_636, getitem_628, None, None, None, getitem_627, getitem_630, getitem_622, None, None, None, getitem_621, getitem_624, getitem_616, None, None, None, getitem_615, getitem_618, getitem_610, None, None, None, getitem_609, getitem_612, getitem_604, None, None, None, getitem_603, getitem_606, getitem_598, None, None, None, getitem_597, getitem_600, getitem_592, None, None, None, getitem_591, getitem_594, getitem_586, None, None, None, getitem_585, getitem_588, getitem_580, None, None, None, getitem_579, getitem_582, getitem_574, None, None, None, getitem_573, getitem_576, getitem_568, None, None, None, getitem_567, getitem_570, getitem_562, None, None, None, getitem_561, getitem_564, getitem_556, None, None, None, getitem_555, getitem_558, getitem_550, None, None, None, getitem_549, getitem_552, getitem_544, None, None, None, getitem_543, getitem_546, getitem_538, None, None, None, getitem_537, getitem_540, getitem_532, None, None, None, getitem_531, getitem_534, getitem_526, None, None, None, getitem_525, getitem_528, getitem_520, None, None, None, getitem_519, getitem_522, getitem_514, None, None, None, getitem_513, getitem_516, getitem_508, None, None, None, getitem_507, getitem_510, getitem_502, None, None, None, getitem_501, getitem_504, getitem_496, None, None, None, getitem_495, getitem_498, getitem_490, None, None, None, getitem_489, getitem_492, getitem_484, None, None, None, getitem_483, getitem_486, getitem_478, None, None, None, getitem_477, getitem_480, getitem_472, None, None, None, getitem_471, getitem_474, getitem_466, None, None, None, getitem_465, getitem_468, getitem_460, None, None, None, getitem_459, getitem_462, getitem_454, None, None, None, getitem_453, getitem_456, getitem_448, None, None, None, getitem_447, getitem_450, getitem_442, None, None, None, getitem_441, getitem_444, getitem_436, None, None, None, getitem_435, getitem_438, getitem_430, None, None, None, getitem_429, getitem_432, getitem_424, None, None, None, getitem_423, getitem_426, getitem_418, None, None, None, getitem_417, getitem_420, getitem_412, None, None, None, getitem_411, getitem_414, getitem_406, None, None, None, getitem_405, getitem_408, getitem_400, None, None, None, getitem_399, getitem_402, getitem_394, None, None, None, getitem_393, getitem_396, getitem_388, None, None, None, getitem_387, getitem_390, getitem_382, None, None, None, getitem_381, getitem_384, getitem_376, None, None, None, getitem_375, getitem_378, getitem_370, None, None, None, getitem_369, getitem_372, getitem_364, None, None, None, getitem_363, getitem_366, getitem_358, None, None, None, getitem_357, getitem_360, getitem_352, None, None, None, getitem_351, getitem_354, getitem_346, None, None, None, getitem_345, getitem_348, getitem_340, None, None, None, getitem_339, getitem_342, getitem_334, None, None, None, getitem_333, getitem_336, getitem_328, None, None, None, getitem_327, getitem_330, getitem_322, None, None, None, getitem_321, getitem_324, getitem_316, None, None, None, getitem_315, getitem_318, getitem_310, None, None, None, getitem_309, getitem_312, getitem_304, None, None, None, getitem_303, getitem_306, getitem_298, None, None, None, getitem_297, getitem_300, getitem_292, None, None, None, getitem_291, getitem_294, view_default_1, t_default_4, None]
        
