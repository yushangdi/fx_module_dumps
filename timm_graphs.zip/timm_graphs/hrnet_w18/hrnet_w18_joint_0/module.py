
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/hrnet_w18/hrnet_w18_joint_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339, primals_340, primals_341, primals_342, primals_343, primals_344, primals_345, primals_346, primals_347, primals_348, primals_349, primals_350, primals_351, primals_352, primals_353, primals_354, primals_355, primals_356, primals_357, primals_358, primals_359, primals_360, primals_361, primals_362, primals_363, primals_364, primals_365, primals_366, primals_367, primals_368, primals_369, primals_370, primals_371, primals_372, primals_373, primals_374, primals_375, primals_376, primals_377, primals_378, primals_379, primals_380, primals_381, primals_382, primals_383, primals_384, primals_385, primals_386, primals_387, primals_388, primals_389, primals_390, primals_391, primals_392, primals_393, primals_394, primals_395, primals_396, primals_397, primals_398, primals_399, primals_400, primals_401, primals_402, primals_403, primals_404, primals_405, primals_406, primals_407, primals_408, primals_409, primals_410, primals_411, primals_412, primals_413, primals_414, primals_415, primals_416, primals_417, primals_418, primals_419, primals_420, primals_421, primals_422, primals_423, primals_424, primals_425, primals_426, primals_427, primals_428, primals_429, primals_430, primals_431, primals_432, primals_433, primals_434, primals_435, primals_436, primals_437, primals_438, primals_439, primals_440, primals_441, primals_442, primals_443, primals_444, primals_445, primals_446, primals_447, primals_448, primals_449, primals_450, primals_451, primals_452, primals_453, primals_454, primals_455, primals_456, primals_457, primals_458, primals_459, primals_460, primals_461, primals_462, primals_463, primals_464, primals_465, primals_466, primals_467, primals_468, primals_469, primals_470, primals_471, primals_472, primals_473, primals_474, primals_475, primals_476, primals_477, primals_478, primals_479, primals_480, primals_481, primals_482, primals_483, primals_484, primals_485, primals_486, primals_487, primals_488, primals_489, primals_490, primals_491, primals_492, primals_493, primals_494, primals_495, primals_496, primals_497, primals_498, primals_499, primals_500, primals_501, primals_502, primals_503, primals_504, primals_505, primals_506, primals_507, primals_508, primals_509, primals_510, primals_511, primals_512, primals_513, primals_514, primals_515, primals_516, primals_517, primals_518, primals_519, primals_520, primals_521, primals_522, primals_523, primals_524, primals_525, primals_526, primals_527, primals_528, primals_529, primals_530, primals_531, primals_532, primals_533, primals_534, primals_535, primals_536, primals_537, primals_538, primals_539, primals_540, primals_541, primals_542, primals_543, primals_544, primals_545, primals_546, primals_547, primals_548, primals_549, primals_550, primals_551, primals_552, primals_553, primals_554, primals_555, primals_556, primals_557, primals_558, primals_559, primals_560, primals_561, primals_562, primals_563, primals_564, primals_565, primals_566, primals_567, primals_568, primals_569, primals_570, primals_571, primals_572, primals_573, primals_574, primals_575, primals_576, primals_577, primals_578, primals_579, primals_580, primals_581, primals_582, primals_583, primals_584, primals_585, primals_586, primals_587, primals_588, primals_589, primals_590, primals_591, primals_592, primals_593, primals_594, primals_595, primals_596, primals_597, primals_598, primals_599, primals_600, primals_601, primals_602, primals_603, primals_604, primals_605, primals_606, primals_607, primals_608, primals_609, primals_610, primals_611, primals_612, primals_613, primals_614, primals_615, primals_616, primals_617, primals_618, primals_619, primals_620, primals_621, primals_622, primals_623, primals_624, primals_625, primals_626, primals_627, primals_628, primals_629, primals_630, primals_631, primals_632, primals_633, primals_634, primals_635, primals_636, primals_637, primals_638, primals_639, primals_640, primals_641, primals_642, primals_643, primals_644, primals_645, primals_646, primals_647, primals_648, primals_649, primals_650, primals_651, primals_652, primals_653, primals_654, primals_655, primals_656, primals_657, primals_658, primals_659, primals_660, primals_661, primals_662, primals_663, primals_664, primals_665, primals_666, primals_667, primals_668, primals_669, primals_670, primals_671, primals_672, primals_673, primals_674, primals_675, primals_676, primals_677, primals_678, primals_679, primals_680, primals_681, primals_682, primals_683, primals_684, primals_685, primals_686, primals_687, primals_688, primals_689, primals_690, primals_691, primals_692, primals_693, primals_694, primals_695, primals_696, primals_697, primals_698, primals_699, primals_700, primals_701, primals_702, primals_703, primals_704, primals_705, primals_706, primals_707, primals_708, primals_709, primals_710, primals_711, primals_712, primals_713, primals_714, primals_715, primals_716, primals_717, primals_718, primals_719, primals_720, primals_721, primals_722, primals_723, primals_724, primals_725, primals_726, primals_727, primals_728, primals_729, primals_730, primals_731, primals_732, primals_733, primals_734, primals_735, primals_736, primals_737, primals_738, primals_739, primals_740, primals_741, primals_742, primals_743, primals_744, primals_745, primals_746, primals_747, primals_748, primals_749, primals_750, primals_751, primals_752, primals_753, primals_754, primals_755, primals_756, primals_757, primals_758, primals_759, primals_760, primals_761, primals_762, primals_763, primals_764, primals_765, primals_766, primals_767, primals_768, primals_769, primals_770, primals_771, primals_772, primals_773, primals_774, primals_775, primals_776, primals_777, primals_778, primals_779, primals_780, primals_781, primals_782, primals_783, primals_784, primals_785, primals_786, primals_787, primals_788, primals_789, primals_790, primals_791, primals_792, primals_793, primals_794, primals_795, primals_796, primals_797, primals_798, primals_799, primals_800, primals_801, primals_802, primals_803, primals_804, primals_805, primals_806, primals_807, primals_808, primals_809, primals_810, primals_811, primals_812, primals_813, primals_814, primals_815, primals_816, primals_817, primals_818, primals_819, primals_820, primals_821, primals_822, primals_823, primals_824, primals_825, primals_826, primals_827, primals_828, primals_829, primals_830, primals_831, primals_832, primals_833, primals_834, primals_835, primals_836, primals_837, primals_838, primals_839, primals_840, primals_841, primals_842, primals_843, primals_844, primals_845, primals_846, primals_847, primals_848, primals_849, primals_850, primals_851, primals_852, primals_853, primals_854, primals_855, primals_856, primals_857, primals_858, primals_859, primals_860, primals_861, primals_862, primals_863, primals_864, primals_865, primals_866, primals_867, primals_868, primals_869, primals_870, primals_871, primals_872, primals_873, primals_874, primals_875, primals_876, primals_877, primals_878, primals_879, primals_880, primals_881, primals_882, primals_883, primals_884, primals_885, primals_886, primals_887, primals_888, primals_889, primals_890, primals_891, primals_892, primals_893, primals_894, primals_895, primals_896, primals_897, primals_898, primals_899, primals_900, primals_901, primals_902, primals_903, primals_904, primals_905, primals_906, primals_907, primals_908, primals_909, primals_910, primals_911, primals_912, primals_913, primals_914, primals_915, primals_916, primals_917, primals_918, primals_919, primals_920, primals_921, primals_922, primals_923, primals_924, primals_925, primals_926, primals_927, primals_928, primals_929, primals_930, primals_931, primals_932, primals_933, primals_934, primals_935, primals_936, primals_937, primals_938, primals_939, primals_940, primals_941, primals_942, primals_943, primals_944, primals_945, primals_946, primals_947, primals_948, primals_949, primals_950, primals_951, primals_952, primals_953, primals_954, primals_955, primals_956, primals_957, primals_958, primals_959, primals_960, primals_961, primals_962, primals_963, primals_964, primals_965, primals_966, primals_967, primals_968, primals_969, primals_970, primals_971, primals_972, primals_973, primals_974, primals_975, primals_976, primals_977, primals_978, primals_979, primals_980, primals_981, primals_982, primals_983, primals_984, primals_985, primals_986, primals_987, primals_988, primals_989, primals_990, primals_991, primals_992, primals_993, primals_994, primals_995, primals_996, primals_997, primals_998, primals_999, primals_1000, primals_1001, primals_1002, primals_1003, primals_1004, primals_1005, primals_1006, primals_1007, primals_1008, primals_1009, primals_1010, primals_1011, primals_1012, primals_1013, primals_1014, primals_1015, primals_1016, primals_1017, primals_1018, primals_1019, primals_1020, primals_1021, primals_1022, primals_1023, primals_1024, primals_1025, primals_1026, primals_1027, primals_1028, primals_1029, primals_1030, primals_1031, primals_1032, primals_1033, primals_1034, primals_1035, primals_1036, primals_1037, primals_1038, primals_1039, primals_1040, primals_1041, primals_1042, primals_1043, primals_1044, primals_1045, primals_1046, primals_1047, primals_1048, primals_1049, primals_1050, primals_1051, primals_1052, primals_1053, primals_1054, primals_1055, primals_1056, primals_1057, primals_1058, primals_1059, primals_1060, primals_1061, primals_1062, primals_1063, primals_1064, primals_1065, primals_1066, primals_1067, primals_1068, primals_1069, primals_1070, primals_1071, primals_1072, primals_1073, primals_1074, primals_1075, primals_1076, primals_1077, primals_1078, primals_1079, primals_1080, primals_1081, primals_1082, primals_1083, primals_1084, primals_1085, primals_1086, primals_1087, primals_1088, primals_1089, primals_1090, primals_1091, primals_1092, primals_1093, primals_1094, primals_1095, primals_1096, primals_1097, primals_1098, primals_1099, primals_1100, primals_1101, primals_1102, primals_1103, primals_1104, primals_1105, primals_1106, primals_1107, primals_1108, primals_1109, primals_1110, primals_1111, primals_1112, primals_1113, primals_1114, primals_1115, primals_1116, primals_1117, primals_1118, primals_1119, primals_1120, primals_1121, primals_1122, primals_1123, primals_1124, primals_1125, primals_1126, primals_1127, primals_1128, primals_1129, primals_1130, primals_1131, primals_1132, primals_1133, primals_1134, primals_1135, primals_1136, primals_1137, primals_1138, primals_1139, primals_1140, primals_1141, primals_1142, primals_1143, primals_1144, primals_1145, primals_1146, primals_1147, primals_1148, primals_1149, primals_1150, primals_1151, primals_1152, primals_1153, primals_1154, primals_1155, primals_1156, primals_1157, primals_1158, primals_1159, primals_1160, primals_1161, primals_1162, primals_1163, primals_1164, primals_1165, primals_1166, primals_1167, primals_1168, primals_1169, primals_1170, primals_1171, primals_1172, primals_1173, primals_1174, primals_1175, primals_1176, primals_1177, primals_1178, primals_1179, primals_1180, primals_1181, primals_1182, primals_1183, primals_1184, primals_1185, primals_1186, primals_1187, primals_1188, primals_1189, primals_1190, primals_1191, primals_1192, primals_1193, primals_1194, primals_1195, primals_1196, primals_1197, primals_1198, primals_1199, primals_1200, primals_1201, primals_1202, primals_1203, primals_1204, primals_1205, primals_1206, primals_1207, primals_1208, primals_1209, primals_1210, primals_1211, primals_1212, primals_1213, primals_1214, primals_1215, primals_1216, primals_1217, primals_1218, primals_1219, primals_1220, primals_1221, primals_1222, primals_1223, primals_1224, primals_1225, primals_1226, primals_1227, primals_1228, primals_1229, primals_1230, primals_1231, primals_1232, primals_1233, primals_1234, primals_1235, primals_1236, primals_1237, primals_1238, primals_1239, primals_1240, primals_1241, primals_1242, primals_1243, primals_1244, primals_1245, primals_1246, primals_1247, primals_1248, primals_1249, primals_1250, primals_1251, primals_1252, primals_1253, primals_1254, primals_1255, primals_1256, primals_1257, primals_1258, primals_1259, primals_1260, primals_1261, primals_1262, primals_1263, primals_1264, primals_1265, primals_1266, primals_1267, primals_1268, primals_1269, primals_1270, primals_1271, primals_1272, primals_1273, primals_1274, primals_1275, primals_1276, primals_1277, primals_1278, primals_1279, primals_1280, primals_1281, primals_1282, primals_1283, primals_1284, primals_1285, primals_1286, primals_1287, primals_1288, primals_1289, primals_1290, primals_1291, primals_1292, primals_1293, primals_1294, primals_1295, primals_1296, primals_1297, primals_1298, primals_1299, primals_1300, primals_1301, primals_1302, primals_1303, primals_1304, primals_1305, primals_1306, primals_1307, primals_1308, primals_1309, primals_1310, primals_1311, primals_1312, primals_1313, primals_1314, primals_1315, primals_1316, primals_1317, primals_1318, primals_1319, primals_1320, primals_1321, primals_1322, primals_1323, primals_1324, primals_1325, primals_1326, primals_1327, primals_1328, primals_1329, primals_1330, primals_1331, primals_1332, primals_1333, primals_1334, primals_1335, primals_1336, primals_1337, primals_1338, primals_1339, primals_1340, primals_1341, primals_1342, primals_1343, primals_1344, primals_1345, primals_1346, primals_1347, primals_1348, primals_1349, primals_1350, primals_1351, primals_1352, primals_1353, primals_1354, primals_1355, primals_1356, primals_1357, primals_1358, primals_1359, primals_1360, primals_1361, primals_1362, primals_1363, primals_1364, primals_1365, primals_1366, primals_1367, primals_1368, primals_1369, primals_1370, primals_1371, primals_1372, primals_1373, primals_1374, primals_1375, primals_1376, primals_1377, primals_1378, primals_1379, primals_1380, primals_1381, primals_1382, primals_1383, primals_1384, primals_1385, primals_1386, primals_1387, primals_1388, primals_1389, primals_1390, primals_1391, primals_1392, primals_1393, primals_1394, primals_1395, primals_1396, primals_1397, primals_1398, primals_1399, primals_1400, primals_1401, primals_1402, primals_1403, primals_1404, primals_1405, primals_1406, primals_1407, primals_1408, primals_1409, primals_1410, primals_1411, primals_1412, primals_1413, primals_1414, primals_1415, primals_1416, primals_1417, primals_1418, primals_1419, primals_1420, primals_1421, primals_1422, primals_1423, primals_1424, primals_1425, primals_1426, primals_1427, primals_1428, primals_1429, primals_1430, primals_1431, primals_1432, primals_1433, primals_1434, primals_1435, primals_1436, primals_1437, primals_1438, primals_1439, primals_1440, primals_1441, primals_1442, primals_1443, primals_1444, primals_1445, primals_1446, primals_1447, primals_1448, primals_1449, primals_1450, primals_1451, primals_1452, primals_1453, primals_1454, primals_1455, primals_1456, primals_1457, primals_1458, primals_1459, primals_1460, primals_1461, primals_1462, primals_1463, primals_1464, primals_1465, primals_1466, primals_1467, primals_1468, primals_1469, primals_1470, primals_1471, primals_1472, primals_1473, primals_1474, primals_1475, primals_1476, primals_1477, primals_1478, primals_1479, primals_1480, primals_1481, primals_1482, primals_1483, primals_1484, primals_1485, primals_1486, primals_1487, primals_1488, primals_1489, primals_1490, primals_1491, primals_1492, primals_1493, primals_1494, primals_1495, primals_1496, primals_1497, primals_1498, primals_1499, primals_1500, primals_1501, primals_1502, primals_1503, primals_1504, primals_1505, primals_1506, primals_1507, primals_1508, primals_1509, primals_1510, primals_1511, primals_1512, primals_1513, primals_1514, primals_1515, primals_1516, primals_1517, primals_1518, primals_1519, primals_1520, primals_1521, primals_1522, primals_1523, primals_1524, primals_1525, primals_1526, primals_1527, primals_1528, primals_1529, primals_1530, primals_1531, primals_1532, primals_1533, primals_1534, primals_1535, primals_1536, primals_1537, primals_1538, primals_1539, primals_1540, primals_1541, primals_1542, primals_1543, primals_1544, primals_1545, primals_1546, primals_1547, primals_1548, primals_1549, primals_1550, primals_1551, primals_1552, primals_1553, primals_1554, primals_1555, primals_1556, primals_1557, primals_1558, primals_1559, primals_1560, primals_1561, primals_1562, primals_1563, primals_1564, primals_1565, primals_1566, primals_1567, primals_1568, primals_1569, primals_1570, primals_1571, primals_1572, primals_1573, primals_1574, primals_1575, primals_1576, primals_1577, primals_1578, primals_1579, primals_1580, primals_1581, primals_1582, primals_1583, primals_1584, primals_1585, primals_1586, primals_1587, primals_1588, primals_1589, primals_1590, primals_1591, primals_1592, primals_1593, primals_1594, primals_1595, primals_1596, primals_1597, primals_1598, primals_1599, primals_1600, primals_1601, primals_1602, primals_1603, primals_1604, primals_1605, primals_1606, primals_1607, primals_1608, primals_1609, primals_1610, primals_1611, primals_1612, primals_1613, primals_1614, primals_1615, primals_1616, primals_1617, primals_1618, primals_1619, primals_1620, primals_1621, primals_1622, primals_1623, primals_1624, primals_1625, primals_1626, primals_1627, primals_1628, primals_1629, primals_1630, primals_1631, primals_1632, primals_1633, primals_1634, primals_1635, primals_1636, primals_1637, primals_1638, primals_1639, primals_1640, primals_1641, primals_1642, primals_1643, primals_1644, primals_1645, primals_1646, primals_1647, primals_1648, primals_1649, primals_1650, primals_1651, primals_1652, primals_1653, primals_1654, primals_1655, primals_1656, primals_1657, primals_1658, primals_1659, primals_1660, primals_1661, primals_1662, primals_1663, primals_1664, primals_1665, primals_1666, primals_1667, primals_1668, primals_1669, primals_1670, primals_1671, primals_1672, primals_1673, primals_1674, primals_1675, primals_1676, primals_1677, primals_1678, primals_1679, primals_1680, primals_1681, primals_1682, primals_1683, primals_1684, primals_1685, primals_1686, primals_1687, primals_1688, primals_1689, primals_1690, primals_1691, primals_1692, primals_1693, primals_1694, primals_1695, primals_1696, primals_1697, primals_1698, primals_1699, primals_1700, primals_1701, primals_1702, primals_1703, primals_1704, primals_1705, primals_1706, primals_1707, primals_1708, primals_1709, primals_1710, primals_1711, primals_1712, primals_1713, primals_1714, primals_1715, primals_1716, primals_1717, primals_1718, primals_1719, primals_1720, primals_1721, primals_1722, primals_1723, primals_1724, primals_1725, primals_1726, primals_1727, primals_1728, primals_1729, primals_1730, primals_1731, primals_1732, primals_1733, primals_1734, primals_1735, primals_1736, primals_1737, primals_1738, primals_1739, primals_1740, primals_1741, primals_1742, primals_1743, primals_1744, primals_1745, primals_1746, primals_1747, primals_1748, primals_1749, primals_1750, primals_1751, primals_1752, primals_1753, primals_1754, primals_1755, primals_1756, primals_1757, primals_1758, primals_1759, primals_1760, primals_1761, primals_1762, primals_1763, primals_1764, primals_1765, primals_1766, primals_1767, primals_1768, primals_1769, primals_1770, primals_1771, primals_1772, primals_1773, primals_1774, primals_1775, primals_1776, primals_1777, primals_1778, primals_1779, primals_1780, primals_1781, primals_1782, primals_1783, primals_1784, primals_1785, primals_1786, primals_1787, primals_1788, primals_1789, primals_1790, primals_1791, primals_1792, primals_1793, primals_1794, primals_1795, primals_1796, primals_1797, primals_1798, primals_1799, primals_1800, primals_1801, primals_1802, primals_1803, primals_1804, primals_1805, primals_1806, primals_1807, primals_1808, primals_1809, primals_1810, primals_1811, primals_1812, primals_1813, primals_1814, primals_1815, primals_1816, primals_1817, primals_1818, primals_1819, primals_1820, primals_1821, primals_1822, primals_1823, primals_1824, primals_1825, primals_1826, primals_1827, primals_1828, primals_1829, primals_1830, primals_1831, primals_1832, primals_1833, primals_1834, primals_1835, primals_1836, primals_1837, primals_1838, primals_1839, primals_1840, primals_1841, primals_1842, primals_1843, primals_1844, primals_1845, primals_1846, primals_1847, primals_1848, primals_1849, primals_1850, primals_1851, primals_1852, primals_1853, primals_1854, primals_1855, primals_1856, primals_1857, primals_1858, primals_1859, primals_1860, primals_1861, primals_1862, primals_1863, primals_1864, primals_1865, primals_1866, primals_1867, primals_1868, primals_1869, primals_1870, primals_1871, primals_1872, primals_1873, primals_1874, primals_1875, primals_1876, primals_1877, primals_1878, primals_1879, primals_1880, primals_1881, primals_1882, primals_1883, primals_1884, primals_1885, primals_1886, primals_1887, primals_1888, primals_1889, primals_1890, primals_1891, primals_1892, primals_1893, primals_1894, primals_1895, primals_1896, primals_1897, primals_1898, primals_1899, primals_1900, primals_1901, primals_1902, primals_1903, primals_1904, primals_1905, primals_1906, primals_1907, primals_1908, primals_1909, primals_1910, primals_1911, primals_1912, primals_1913, primals_1914, primals_1915, primals_1916, primals_1917, primals_1918, primals_1919, primals_1920, primals_1921, primals_1922, primals_1923, primals_1924, primals_1925, primals_1926, primals_1927, primals_1928, primals_1929, primals_1930, primals_1931, primals_1932, primals_1933, primals_1934, primals_1935, primals_1936, primals_1937, primals_1938, primals_1939, primals_1940, primals_1941, primals_1942, primals_1943, primals_1944, primals_1945, primals_1946, primals_1947, primals_1948, primals_1949, primals_1950, primals_1951, primals_1952, primals_1953, primals_1954, primals_1955, primals_1956, primals_1957, tangents_1):
        convolution_default = torch.ops.aten.convolution.default(primals_1957, primals_13, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor = torch.ops.aten.add_.Tensor(primals_2, 1);  primals_2 = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_5, primals_1, primals_3, primals_4, True, 0.1, 1e-05);  primals_1 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        new_zeros_default = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default, primals_14, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_1 = torch.ops.aten.add_.Tensor(primals_7, 1);  primals_7 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_10, primals_6, primals_8, primals_9, True, 0.1, 1e-05);  primals_6 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_1 = torch.ops.aten.relu_.default(getitem_3);  getitem_3 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_154, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_2 = torch.ops.aten.add_.Tensor(primals_140, 1);  primals_140 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_143, primals_139, primals_141, primals_142, True, 0.1, 1e-05);  primals_139 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        new_zeros_default_2 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_2 = torch.ops.aten.relu_.default(getitem_6);  getitem_6 = None
        convolution_default_3 = torch.ops.aten.convolution.default(relu__default_2, primals_155, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_3 = torch.ops.aten.add_.Tensor(primals_145, 1);  primals_145 = None
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_148, primals_144, primals_146, primals_147, True, 0.1, 1e-05);  primals_144 = None
        getitem_9 = native_batch_norm_default_3[0]
        getitem_10 = native_batch_norm_default_3[1]
        getitem_11 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_3 = torch.ops.aten.relu_.default(getitem_9);  getitem_9 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu__default_3, primals_156, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_4 = torch.ops.aten.add_.Tensor(primals_150, 1);  primals_150 = None
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_153, primals_149, primals_151, primals_152, True, 0.1, 1e-05);  primals_149 = None
        getitem_12 = native_batch_norm_default_4[0]
        getitem_13 = native_batch_norm_default_4[1]
        getitem_14 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_1, primals_157, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_5 = torch.ops.aten.add_.Tensor(primals_159, 1);  primals_159 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_162, primals_158, primals_160, primals_161, True, 0.1, 1e-05);  primals_158 = None
        getitem_15 = native_batch_norm_default_5[0]
        getitem_16 = native_batch_norm_default_5[1]
        getitem_17 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        new_zeros_default_5 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_6 = torch.ops.aten.add_.Tensor(getitem_12, getitem_15);  getitem_12 = getitem_15 = None
        relu__default_4 = torch.ops.aten.relu_.default(add__tensor_6);  add__tensor_6 = None
        convolution_default_6 = torch.ops.aten.convolution.default(relu__default_4, primals_178, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_7 = torch.ops.aten.add_.Tensor(primals_164, 1);  primals_164 = None
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_167, primals_163, primals_165, primals_166, True, 0.1, 1e-05);  primals_163 = None
        getitem_18 = native_batch_norm_default_6[0]
        getitem_19 = native_batch_norm_default_6[1]
        getitem_20 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(convolution_default_6, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_5 = torch.ops.aten.relu_.default(getitem_18);  getitem_18 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_5, primals_179, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_8 = torch.ops.aten.add_.Tensor(primals_169, 1);  primals_169 = None
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_172, primals_168, primals_170, primals_171, True, 0.1, 1e-05);  primals_168 = None
        getitem_21 = native_batch_norm_default_7[0]
        getitem_22 = native_batch_norm_default_7[1]
        getitem_23 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(convolution_default_7, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_6 = torch.ops.aten.relu_.default(getitem_21);  getitem_21 = None
        convolution_default_8 = torch.ops.aten.convolution.default(relu__default_6, primals_180, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_9 = torch.ops.aten.add_.Tensor(primals_174, 1);  primals_174 = None
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_177, primals_173, primals_175, primals_176, True, 0.1, 1e-05);  primals_173 = None
        getitem_24 = native_batch_norm_default_8[0]
        getitem_25 = native_batch_norm_default_8[1]
        getitem_26 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        new_zeros_default_8 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_10 = torch.ops.aten.add_.Tensor(getitem_24, relu__default_4);  getitem_24 = None
        relu__default_7 = torch.ops.aten.relu_.default(add__tensor_10);  add__tensor_10 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_7, primals_196, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_11 = torch.ops.aten.add_.Tensor(primals_182, 1);  primals_182 = None
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_185, primals_181, primals_183, primals_184, True, 0.1, 1e-05);  primals_181 = None
        getitem_27 = native_batch_norm_default_9[0]
        getitem_28 = native_batch_norm_default_9[1]
        getitem_29 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        new_zeros_default_9 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_8 = torch.ops.aten.relu_.default(getitem_27);  getitem_27 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default_8, primals_197, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_12 = torch.ops.aten.add_.Tensor(primals_187, 1);  primals_187 = None
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_190, primals_186, primals_188, primals_189, True, 0.1, 1e-05);  primals_186 = None
        getitem_30 = native_batch_norm_default_10[0]
        getitem_31 = native_batch_norm_default_10[1]
        getitem_32 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        new_zeros_default_10 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_9 = torch.ops.aten.relu_.default(getitem_30);  getitem_30 = None
        convolution_default_11 = torch.ops.aten.convolution.default(relu__default_9, primals_198, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_13 = torch.ops.aten.add_.Tensor(primals_192, 1);  primals_192 = None
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_195, primals_191, primals_193, primals_194, True, 0.1, 1e-05);  primals_191 = None
        getitem_33 = native_batch_norm_default_11[0]
        getitem_34 = native_batch_norm_default_11[1]
        getitem_35 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        new_zeros_default_11 = torch.ops.aten.new_zeros.default(convolution_default_11, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_14 = torch.ops.aten.add_.Tensor(getitem_33, relu__default_7);  getitem_33 = None
        relu__default_10 = torch.ops.aten.relu_.default(add__tensor_14);  add__tensor_14 = None
        convolution_default_12 = torch.ops.aten.convolution.default(relu__default_10, primals_214, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_15 = torch.ops.aten.add_.Tensor(primals_200, 1);  primals_200 = None
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_203, primals_199, primals_201, primals_202, True, 0.1, 1e-05);  primals_199 = None
        getitem_36 = native_batch_norm_default_12[0]
        getitem_37 = native_batch_norm_default_12[1]
        getitem_38 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        new_zeros_default_12 = torch.ops.aten.new_zeros.default(convolution_default_12, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_11 = torch.ops.aten.relu_.default(getitem_36);  getitem_36 = None
        convolution_default_13 = torch.ops.aten.convolution.default(relu__default_11, primals_215, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_16 = torch.ops.aten.add_.Tensor(primals_205, 1);  primals_205 = None
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_208, primals_204, primals_206, primals_207, True, 0.1, 1e-05);  primals_204 = None
        getitem_39 = native_batch_norm_default_13[0]
        getitem_40 = native_batch_norm_default_13[1]
        getitem_41 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        new_zeros_default_13 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_12 = torch.ops.aten.relu_.default(getitem_39);  getitem_39 = None
        convolution_default_14 = torch.ops.aten.convolution.default(relu__default_12, primals_216, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_17 = torch.ops.aten.add_.Tensor(primals_210, 1);  primals_210 = None
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_213, primals_209, primals_211, primals_212, True, 0.1, 1e-05);  primals_209 = None
        getitem_42 = native_batch_norm_default_14[0]
        getitem_43 = native_batch_norm_default_14[1]
        getitem_44 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        new_zeros_default_14 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_18 = torch.ops.aten.add_.Tensor(getitem_42, relu__default_10);  getitem_42 = None
        relu__default_13 = torch.ops.aten.relu_.default(add__tensor_18);  add__tensor_18 = None
        convolution_default_15 = torch.ops.aten.convolution.default(relu__default_13, primals_1465, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_19 = torch.ops.aten.add_.Tensor(primals_1467, 1);  primals_1467 = None
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_1470, primals_1466, primals_1468, primals_1469, True, 0.1, 1e-05);  primals_1466 = None
        getitem_45 = native_batch_norm_default_15[0]
        getitem_46 = native_batch_norm_default_15[1]
        getitem_47 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        new_zeros_default_15 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_14 = torch.ops.aten.relu_.default(getitem_45);  getitem_45 = None
        convolution_default_16 = torch.ops.aten.convolution.default(relu__default_13, primals_1471, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_20 = torch.ops.aten.add_.Tensor(primals_1473, 1);  primals_1473 = None
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_1476, primals_1472, primals_1474, primals_1475, True, 0.1, 1e-05);  primals_1472 = None
        getitem_48 = native_batch_norm_default_16[0]
        getitem_49 = native_batch_norm_default_16[1]
        getitem_50 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        new_zeros_default_16 = torch.ops.aten.new_zeros.default(convolution_default_16, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_15 = torch.ops.aten.relu_.default(getitem_48);  getitem_48 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu__default_14, primals_227, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_21 = torch.ops.aten.add_.Tensor(primals_218, 1);  primals_218 = None
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_221, primals_217, primals_219, primals_220, True, 0.1, 1e-05);  primals_217 = None
        getitem_51 = native_batch_norm_default_17[0]
        getitem_52 = native_batch_norm_default_17[1]
        getitem_53 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        new_zeros_default_17 = torch.ops.aten.new_zeros.default(convolution_default_17, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_16 = torch.ops.aten.relu_.default(getitem_51);  getitem_51 = None
        convolution_default_18 = torch.ops.aten.convolution.default(relu__default_16, primals_228, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_22 = torch.ops.aten.add_.Tensor(primals_223, 1);  primals_223 = None
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_226, primals_222, primals_224, primals_225, True, 0.1, 1e-05);  primals_222 = None
        getitem_54 = native_batch_norm_default_18[0]
        getitem_55 = native_batch_norm_default_18[1]
        getitem_56 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        new_zeros_default_18 = torch.ops.aten.new_zeros.default(convolution_default_18, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_23 = torch.ops.aten.add_.Tensor(getitem_54, relu__default_14);  getitem_54 = None
        relu__default_17 = torch.ops.aten.relu_.default(add__tensor_23);  add__tensor_23 = None
        convolution_default_19 = torch.ops.aten.convolution.default(relu__default_17, primals_239, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_24 = torch.ops.aten.add_.Tensor(primals_230, 1);  primals_230 = None
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_233, primals_229, primals_231, primals_232, True, 0.1, 1e-05);  primals_229 = None
        getitem_57 = native_batch_norm_default_19[0]
        getitem_58 = native_batch_norm_default_19[1]
        getitem_59 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        new_zeros_default_19 = torch.ops.aten.new_zeros.default(convolution_default_19, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_18 = torch.ops.aten.relu_.default(getitem_57);  getitem_57 = None
        convolution_default_20 = torch.ops.aten.convolution.default(relu__default_18, primals_240, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_25 = torch.ops.aten.add_.Tensor(primals_235, 1);  primals_235 = None
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_238, primals_234, primals_236, primals_237, True, 0.1, 1e-05);  primals_234 = None
        getitem_60 = native_batch_norm_default_20[0]
        getitem_61 = native_batch_norm_default_20[1]
        getitem_62 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        new_zeros_default_20 = torch.ops.aten.new_zeros.default(convolution_default_20, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_26 = torch.ops.aten.add_.Tensor(getitem_60, relu__default_17);  getitem_60 = None
        relu__default_19 = torch.ops.aten.relu_.default(add__tensor_26);  add__tensor_26 = None
        convolution_default_21 = torch.ops.aten.convolution.default(relu__default_19, primals_251, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_27 = torch.ops.aten.add_.Tensor(primals_242, 1);  primals_242 = None
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_245, primals_241, primals_243, primals_244, True, 0.1, 1e-05);  primals_241 = None
        getitem_63 = native_batch_norm_default_21[0]
        getitem_64 = native_batch_norm_default_21[1]
        getitem_65 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        new_zeros_default_21 = torch.ops.aten.new_zeros.default(convolution_default_21, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_20 = torch.ops.aten.relu_.default(getitem_63);  getitem_63 = None
        convolution_default_22 = torch.ops.aten.convolution.default(relu__default_20, primals_252, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_28 = torch.ops.aten.add_.Tensor(primals_247, 1);  primals_247 = None
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_250, primals_246, primals_248, primals_249, True, 0.1, 1e-05);  primals_246 = None
        getitem_66 = native_batch_norm_default_22[0]
        getitem_67 = native_batch_norm_default_22[1]
        getitem_68 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        new_zeros_default_22 = torch.ops.aten.new_zeros.default(convolution_default_22, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_29 = torch.ops.aten.add_.Tensor(getitem_66, relu__default_19);  getitem_66 = None
        relu__default_21 = torch.ops.aten.relu_.default(add__tensor_29);  add__tensor_29 = None
        convolution_default_23 = torch.ops.aten.convolution.default(relu__default_21, primals_263, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_30 = torch.ops.aten.add_.Tensor(primals_254, 1);  primals_254 = None
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_257, primals_253, primals_255, primals_256, True, 0.1, 1e-05);  primals_253 = None
        getitem_69 = native_batch_norm_default_23[0]
        getitem_70 = native_batch_norm_default_23[1]
        getitem_71 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        new_zeros_default_23 = torch.ops.aten.new_zeros.default(convolution_default_23, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_22 = torch.ops.aten.relu_.default(getitem_69);  getitem_69 = None
        convolution_default_24 = torch.ops.aten.convolution.default(relu__default_22, primals_264, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_31 = torch.ops.aten.add_.Tensor(primals_259, 1);  primals_259 = None
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_262, primals_258, primals_260, primals_261, True, 0.1, 1e-05);  primals_258 = None
        getitem_72 = native_batch_norm_default_24[0]
        getitem_73 = native_batch_norm_default_24[1]
        getitem_74 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        new_zeros_default_24 = torch.ops.aten.new_zeros.default(convolution_default_24, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_32 = torch.ops.aten.add_.Tensor(getitem_72, relu__default_21);  getitem_72 = None
        relu__default_23 = torch.ops.aten.relu_.default(add__tensor_32);  add__tensor_32 = None
        convolution_default_25 = torch.ops.aten.convolution.default(relu__default_15, primals_275, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_33 = torch.ops.aten.add_.Tensor(primals_266, 1);  primals_266 = None
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_269, primals_265, primals_267, primals_268, True, 0.1, 1e-05);  primals_265 = None
        getitem_75 = native_batch_norm_default_25[0]
        getitem_76 = native_batch_norm_default_25[1]
        getitem_77 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        new_zeros_default_25 = torch.ops.aten.new_zeros.default(convolution_default_25, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_24 = torch.ops.aten.relu_.default(getitem_75);  getitem_75 = None
        convolution_default_26 = torch.ops.aten.convolution.default(relu__default_24, primals_276, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_34 = torch.ops.aten.add_.Tensor(primals_271, 1);  primals_271 = None
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_274, primals_270, primals_272, primals_273, True, 0.1, 1e-05);  primals_270 = None
        getitem_78 = native_batch_norm_default_26[0]
        getitem_79 = native_batch_norm_default_26[1]
        getitem_80 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        new_zeros_default_26 = torch.ops.aten.new_zeros.default(convolution_default_26, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_35 = torch.ops.aten.add_.Tensor(getitem_78, relu__default_15);  getitem_78 = None
        relu__default_25 = torch.ops.aten.relu_.default(add__tensor_35);  add__tensor_35 = None
        convolution_default_27 = torch.ops.aten.convolution.default(relu__default_25, primals_287, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_36 = torch.ops.aten.add_.Tensor(primals_278, 1);  primals_278 = None
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_281, primals_277, primals_279, primals_280, True, 0.1, 1e-05);  primals_277 = None
        getitem_81 = native_batch_norm_default_27[0]
        getitem_82 = native_batch_norm_default_27[1]
        getitem_83 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        new_zeros_default_27 = torch.ops.aten.new_zeros.default(convolution_default_27, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_26 = torch.ops.aten.relu_.default(getitem_81);  getitem_81 = None
        convolution_default_28 = torch.ops.aten.convolution.default(relu__default_26, primals_288, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_37 = torch.ops.aten.add_.Tensor(primals_283, 1);  primals_283 = None
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_286, primals_282, primals_284, primals_285, True, 0.1, 1e-05);  primals_282 = None
        getitem_84 = native_batch_norm_default_28[0]
        getitem_85 = native_batch_norm_default_28[1]
        getitem_86 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        new_zeros_default_28 = torch.ops.aten.new_zeros.default(convolution_default_28, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_38 = torch.ops.aten.add_.Tensor(getitem_84, relu__default_25);  getitem_84 = None
        relu__default_27 = torch.ops.aten.relu_.default(add__tensor_38);  add__tensor_38 = None
        convolution_default_29 = torch.ops.aten.convolution.default(relu__default_27, primals_299, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_39 = torch.ops.aten.add_.Tensor(primals_290, 1);  primals_290 = None
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_293, primals_289, primals_291, primals_292, True, 0.1, 1e-05);  primals_289 = None
        getitem_87 = native_batch_norm_default_29[0]
        getitem_88 = native_batch_norm_default_29[1]
        getitem_89 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        new_zeros_default_29 = torch.ops.aten.new_zeros.default(convolution_default_29, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_28 = torch.ops.aten.relu_.default(getitem_87);  getitem_87 = None
        convolution_default_30 = torch.ops.aten.convolution.default(relu__default_28, primals_300, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_40 = torch.ops.aten.add_.Tensor(primals_295, 1);  primals_295 = None
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_298, primals_294, primals_296, primals_297, True, 0.1, 1e-05);  primals_294 = None
        getitem_90 = native_batch_norm_default_30[0]
        getitem_91 = native_batch_norm_default_30[1]
        getitem_92 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        new_zeros_default_30 = torch.ops.aten.new_zeros.default(convolution_default_30, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_41 = torch.ops.aten.add_.Tensor(getitem_90, relu__default_27);  getitem_90 = None
        relu__default_29 = torch.ops.aten.relu_.default(add__tensor_41);  add__tensor_41 = None
        convolution_default_31 = torch.ops.aten.convolution.default(relu__default_29, primals_311, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_42 = torch.ops.aten.add_.Tensor(primals_302, 1);  primals_302 = None
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_31, primals_305, primals_301, primals_303, primals_304, True, 0.1, 1e-05);  primals_301 = None
        getitem_93 = native_batch_norm_default_31[0]
        getitem_94 = native_batch_norm_default_31[1]
        getitem_95 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        new_zeros_default_31 = torch.ops.aten.new_zeros.default(convolution_default_31, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_30 = torch.ops.aten.relu_.default(getitem_93);  getitem_93 = None
        convolution_default_32 = torch.ops.aten.convolution.default(relu__default_30, primals_312, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_43 = torch.ops.aten.add_.Tensor(primals_307, 1);  primals_307 = None
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_310, primals_306, primals_308, primals_309, True, 0.1, 1e-05);  primals_306 = None
        getitem_96 = native_batch_norm_default_32[0]
        getitem_97 = native_batch_norm_default_32[1]
        getitem_98 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        new_zeros_default_32 = torch.ops.aten.new_zeros.default(convolution_default_32, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_44 = torch.ops.aten.add_.Tensor(getitem_96, relu__default_29);  getitem_96 = None
        relu__default_31 = torch.ops.aten.relu_.default(add__tensor_44);  add__tensor_44 = None
        convolution_default_33 = torch.ops.aten.convolution.default(relu__default_31, primals_1675, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_45 = torch.ops.aten.add_.Tensor(primals_1677, 1);  primals_1677 = None
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_1680, primals_1676, primals_1678, primals_1679, True, 0.1, 1e-05);  primals_1676 = None
        getitem_99 = native_batch_norm_default_33[0]
        getitem_100 = native_batch_norm_default_33[1]
        getitem_101 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        new_zeros_default_33 = torch.ops.aten.new_zeros.default(convolution_default_33, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec = torch.ops.aten.upsample_nearest2d.vec(getitem_99, None, [2.0, 2.0]);  getitem_99 = None
        add_tensor = torch.ops.aten.add.Tensor(relu__default_23, upsample_nearest2d_vec);  upsample_nearest2d_vec = None
        relu_default = torch.ops.aten.relu.default(add_tensor);  add_tensor = None
        convolution_default_34 = torch.ops.aten.convolution.default(relu__default_23, primals_1489, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_46 = torch.ops.aten.add_.Tensor(primals_1491, 1);  primals_1491 = None
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_1494, primals_1490, primals_1492, primals_1493, True, 0.1, 1e-05);  primals_1490 = None
        getitem_102 = native_batch_norm_default_34[0]
        getitem_103 = native_batch_norm_default_34[1]
        getitem_104 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        new_zeros_default_34 = torch.ops.aten.new_zeros.default(convolution_default_34, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_1 = torch.ops.aten.add.Tensor(getitem_102, relu__default_31);  getitem_102 = None
        relu_default_1 = torch.ops.aten.relu.default(add_tensor_1);  add_tensor_1 = None
        convolution_default_35 = torch.ops.aten.convolution.default(relu_default_1, primals_1477, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_47 = torch.ops.aten.add_.Tensor(primals_1479, 1);  primals_1479 = None
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_1482, primals_1478, primals_1480, primals_1481, True, 0.1, 1e-05);  primals_1478 = None
        getitem_105 = native_batch_norm_default_35[0]
        getitem_106 = native_batch_norm_default_35[1]
        getitem_107 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        new_zeros_default_35 = torch.ops.aten.new_zeros.default(convolution_default_35, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_32 = torch.ops.aten.relu_.default(getitem_105);  getitem_105 = None
        convolution_default_36 = torch.ops.aten.convolution.default(relu_default, primals_323, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_48 = torch.ops.aten.add_.Tensor(primals_314, 1);  primals_314 = None
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_317, primals_313, primals_315, primals_316, True, 0.1, 1e-05);  primals_313 = None
        getitem_108 = native_batch_norm_default_36[0]
        getitem_109 = native_batch_norm_default_36[1]
        getitem_110 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        new_zeros_default_36 = torch.ops.aten.new_zeros.default(convolution_default_36, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_33 = torch.ops.aten.relu_.default(getitem_108);  getitem_108 = None
        convolution_default_37 = torch.ops.aten.convolution.default(relu__default_33, primals_324, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_49 = torch.ops.aten.add_.Tensor(primals_319, 1);  primals_319 = None
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_37, primals_322, primals_318, primals_320, primals_321, True, 0.1, 1e-05);  primals_318 = None
        getitem_111 = native_batch_norm_default_37[0]
        getitem_112 = native_batch_norm_default_37[1]
        getitem_113 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        new_zeros_default_37 = torch.ops.aten.new_zeros.default(convolution_default_37, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_50 = torch.ops.aten.add_.Tensor(getitem_111, relu_default);  getitem_111 = None
        relu__default_34 = torch.ops.aten.relu_.default(add__tensor_50);  add__tensor_50 = None
        convolution_default_38 = torch.ops.aten.convolution.default(relu__default_34, primals_335, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_51 = torch.ops.aten.add_.Tensor(primals_326, 1);  primals_326 = None
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_329, primals_325, primals_327, primals_328, True, 0.1, 1e-05);  primals_325 = None
        getitem_114 = native_batch_norm_default_38[0]
        getitem_115 = native_batch_norm_default_38[1]
        getitem_116 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        new_zeros_default_38 = torch.ops.aten.new_zeros.default(convolution_default_38, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_35 = torch.ops.aten.relu_.default(getitem_114);  getitem_114 = None
        convolution_default_39 = torch.ops.aten.convolution.default(relu__default_35, primals_336, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_52 = torch.ops.aten.add_.Tensor(primals_331, 1);  primals_331 = None
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_39, primals_334, primals_330, primals_332, primals_333, True, 0.1, 1e-05);  primals_330 = None
        getitem_117 = native_batch_norm_default_39[0]
        getitem_118 = native_batch_norm_default_39[1]
        getitem_119 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        new_zeros_default_39 = torch.ops.aten.new_zeros.default(convolution_default_39, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_53 = torch.ops.aten.add_.Tensor(getitem_117, relu__default_34);  getitem_117 = None
        relu__default_36 = torch.ops.aten.relu_.default(add__tensor_53);  add__tensor_53 = None
        convolution_default_40 = torch.ops.aten.convolution.default(relu__default_36, primals_347, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_54 = torch.ops.aten.add_.Tensor(primals_338, 1);  primals_338 = None
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_341, primals_337, primals_339, primals_340, True, 0.1, 1e-05);  primals_337 = None
        getitem_120 = native_batch_norm_default_40[0]
        getitem_121 = native_batch_norm_default_40[1]
        getitem_122 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        new_zeros_default_40 = torch.ops.aten.new_zeros.default(convolution_default_40, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_37 = torch.ops.aten.relu_.default(getitem_120);  getitem_120 = None
        convolution_default_41 = torch.ops.aten.convolution.default(relu__default_37, primals_348, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_55 = torch.ops.aten.add_.Tensor(primals_343, 1);  primals_343 = None
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_41, primals_346, primals_342, primals_344, primals_345, True, 0.1, 1e-05);  primals_342 = None
        getitem_123 = native_batch_norm_default_41[0]
        getitem_124 = native_batch_norm_default_41[1]
        getitem_125 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        new_zeros_default_41 = torch.ops.aten.new_zeros.default(convolution_default_41, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_56 = torch.ops.aten.add_.Tensor(getitem_123, relu__default_36);  getitem_123 = None
        relu__default_38 = torch.ops.aten.relu_.default(add__tensor_56);  add__tensor_56 = None
        convolution_default_42 = torch.ops.aten.convolution.default(relu__default_38, primals_359, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_57 = torch.ops.aten.add_.Tensor(primals_350, 1);  primals_350 = None
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_42, primals_353, primals_349, primals_351, primals_352, True, 0.1, 1e-05);  primals_349 = None
        getitem_126 = native_batch_norm_default_42[0]
        getitem_127 = native_batch_norm_default_42[1]
        getitem_128 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        new_zeros_default_42 = torch.ops.aten.new_zeros.default(convolution_default_42, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_39 = torch.ops.aten.relu_.default(getitem_126);  getitem_126 = None
        convolution_default_43 = torch.ops.aten.convolution.default(relu__default_39, primals_360, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_58 = torch.ops.aten.add_.Tensor(primals_355, 1);  primals_355 = None
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_43, primals_358, primals_354, primals_356, primals_357, True, 0.1, 1e-05);  primals_354 = None
        getitem_129 = native_batch_norm_default_43[0]
        getitem_130 = native_batch_norm_default_43[1]
        getitem_131 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        new_zeros_default_43 = torch.ops.aten.new_zeros.default(convolution_default_43, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_59 = torch.ops.aten.add_.Tensor(getitem_129, relu__default_38);  getitem_129 = None
        relu__default_40 = torch.ops.aten.relu_.default(add__tensor_59);  add__tensor_59 = None
        convolution_default_44 = torch.ops.aten.convolution.default(relu_default_1, primals_371, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_60 = torch.ops.aten.add_.Tensor(primals_362, 1);  primals_362 = None
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_365, primals_361, primals_363, primals_364, True, 0.1, 1e-05);  primals_361 = None
        getitem_132 = native_batch_norm_default_44[0]
        getitem_133 = native_batch_norm_default_44[1]
        getitem_134 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        new_zeros_default_44 = torch.ops.aten.new_zeros.default(convolution_default_44, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_41 = torch.ops.aten.relu_.default(getitem_132);  getitem_132 = None
        convolution_default_45 = torch.ops.aten.convolution.default(relu__default_41, primals_372, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_61 = torch.ops.aten.add_.Tensor(primals_367, 1);  primals_367 = None
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_45, primals_370, primals_366, primals_368, primals_369, True, 0.1, 1e-05);  primals_366 = None
        getitem_135 = native_batch_norm_default_45[0]
        getitem_136 = native_batch_norm_default_45[1]
        getitem_137 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        new_zeros_default_45 = torch.ops.aten.new_zeros.default(convolution_default_45, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_62 = torch.ops.aten.add_.Tensor(getitem_135, relu_default_1);  getitem_135 = None
        relu__default_42 = torch.ops.aten.relu_.default(add__tensor_62);  add__tensor_62 = None
        convolution_default_46 = torch.ops.aten.convolution.default(relu__default_42, primals_383, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_63 = torch.ops.aten.add_.Tensor(primals_374, 1);  primals_374 = None
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(convolution_default_46, primals_377, primals_373, primals_375, primals_376, True, 0.1, 1e-05);  primals_373 = None
        getitem_138 = native_batch_norm_default_46[0]
        getitem_139 = native_batch_norm_default_46[1]
        getitem_140 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        new_zeros_default_46 = torch.ops.aten.new_zeros.default(convolution_default_46, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_43 = torch.ops.aten.relu_.default(getitem_138);  getitem_138 = None
        convolution_default_47 = torch.ops.aten.convolution.default(relu__default_43, primals_384, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_64 = torch.ops.aten.add_.Tensor(primals_379, 1);  primals_379 = None
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(convolution_default_47, primals_382, primals_378, primals_380, primals_381, True, 0.1, 1e-05);  primals_378 = None
        getitem_141 = native_batch_norm_default_47[0]
        getitem_142 = native_batch_norm_default_47[1]
        getitem_143 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        new_zeros_default_47 = torch.ops.aten.new_zeros.default(convolution_default_47, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_65 = torch.ops.aten.add_.Tensor(getitem_141, relu__default_42);  getitem_141 = None
        relu__default_44 = torch.ops.aten.relu_.default(add__tensor_65);  add__tensor_65 = None
        convolution_default_48 = torch.ops.aten.convolution.default(relu__default_44, primals_395, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_66 = torch.ops.aten.add_.Tensor(primals_386, 1);  primals_386 = None
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_48, primals_389, primals_385, primals_387, primals_388, True, 0.1, 1e-05);  primals_385 = None
        getitem_144 = native_batch_norm_default_48[0]
        getitem_145 = native_batch_norm_default_48[1]
        getitem_146 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        new_zeros_default_48 = torch.ops.aten.new_zeros.default(convolution_default_48, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_45 = torch.ops.aten.relu_.default(getitem_144);  getitem_144 = None
        convolution_default_49 = torch.ops.aten.convolution.default(relu__default_45, primals_396, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_67 = torch.ops.aten.add_.Tensor(primals_391, 1);  primals_391 = None
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(convolution_default_49, primals_394, primals_390, primals_392, primals_393, True, 0.1, 1e-05);  primals_390 = None
        getitem_147 = native_batch_norm_default_49[0]
        getitem_148 = native_batch_norm_default_49[1]
        getitem_149 = native_batch_norm_default_49[2];  native_batch_norm_default_49 = None
        new_zeros_default_49 = torch.ops.aten.new_zeros.default(convolution_default_49, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_68 = torch.ops.aten.add_.Tensor(getitem_147, relu__default_44);  getitem_147 = None
        relu__default_46 = torch.ops.aten.relu_.default(add__tensor_68);  add__tensor_68 = None
        convolution_default_50 = torch.ops.aten.convolution.default(relu__default_46, primals_407, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_69 = torch.ops.aten.add_.Tensor(primals_398, 1);  primals_398 = None
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(convolution_default_50, primals_401, primals_397, primals_399, primals_400, True, 0.1, 1e-05);  primals_397 = None
        getitem_150 = native_batch_norm_default_50[0]
        getitem_151 = native_batch_norm_default_50[1]
        getitem_152 = native_batch_norm_default_50[2];  native_batch_norm_default_50 = None
        new_zeros_default_50 = torch.ops.aten.new_zeros.default(convolution_default_50, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_47 = torch.ops.aten.relu_.default(getitem_150);  getitem_150 = None
        convolution_default_51 = torch.ops.aten.convolution.default(relu__default_47, primals_408, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_70 = torch.ops.aten.add_.Tensor(primals_403, 1);  primals_403 = None
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(convolution_default_51, primals_406, primals_402, primals_404, primals_405, True, 0.1, 1e-05);  primals_402 = None
        getitem_153 = native_batch_norm_default_51[0]
        getitem_154 = native_batch_norm_default_51[1]
        getitem_155 = native_batch_norm_default_51[2];  native_batch_norm_default_51 = None
        new_zeros_default_51 = torch.ops.aten.new_zeros.default(convolution_default_51, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_71 = torch.ops.aten.add_.Tensor(getitem_153, relu__default_46);  getitem_153 = None
        relu__default_48 = torch.ops.aten.relu_.default(add__tensor_71);  add__tensor_71 = None
        convolution_default_52 = torch.ops.aten.convolution.default(relu__default_32, primals_419, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_72 = torch.ops.aten.add_.Tensor(primals_410, 1);  primals_410 = None
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(convolution_default_52, primals_413, primals_409, primals_411, primals_412, True, 0.1, 1e-05);  primals_409 = None
        getitem_156 = native_batch_norm_default_52[0]
        getitem_157 = native_batch_norm_default_52[1]
        getitem_158 = native_batch_norm_default_52[2];  native_batch_norm_default_52 = None
        new_zeros_default_52 = torch.ops.aten.new_zeros.default(convolution_default_52, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_49 = torch.ops.aten.relu_.default(getitem_156);  getitem_156 = None
        convolution_default_53 = torch.ops.aten.convolution.default(relu__default_49, primals_420, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_73 = torch.ops.aten.add_.Tensor(primals_415, 1);  primals_415 = None
        native_batch_norm_default_53 = torch.ops.aten.native_batch_norm.default(convolution_default_53, primals_418, primals_414, primals_416, primals_417, True, 0.1, 1e-05);  primals_414 = None
        getitem_159 = native_batch_norm_default_53[0]
        getitem_160 = native_batch_norm_default_53[1]
        getitem_161 = native_batch_norm_default_53[2];  native_batch_norm_default_53 = None
        new_zeros_default_53 = torch.ops.aten.new_zeros.default(convolution_default_53, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_74 = torch.ops.aten.add_.Tensor(getitem_159, relu__default_32);  getitem_159 = None
        relu__default_50 = torch.ops.aten.relu_.default(add__tensor_74);  add__tensor_74 = None
        convolution_default_54 = torch.ops.aten.convolution.default(relu__default_50, primals_431, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_75 = torch.ops.aten.add_.Tensor(primals_422, 1);  primals_422 = None
        native_batch_norm_default_54 = torch.ops.aten.native_batch_norm.default(convolution_default_54, primals_425, primals_421, primals_423, primals_424, True, 0.1, 1e-05);  primals_421 = None
        getitem_162 = native_batch_norm_default_54[0]
        getitem_163 = native_batch_norm_default_54[1]
        getitem_164 = native_batch_norm_default_54[2];  native_batch_norm_default_54 = None
        new_zeros_default_54 = torch.ops.aten.new_zeros.default(convolution_default_54, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_51 = torch.ops.aten.relu_.default(getitem_162);  getitem_162 = None
        convolution_default_55 = torch.ops.aten.convolution.default(relu__default_51, primals_432, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_76 = torch.ops.aten.add_.Tensor(primals_427, 1);  primals_427 = None
        native_batch_norm_default_55 = torch.ops.aten.native_batch_norm.default(convolution_default_55, primals_430, primals_426, primals_428, primals_429, True, 0.1, 1e-05);  primals_426 = None
        getitem_165 = native_batch_norm_default_55[0]
        getitem_166 = native_batch_norm_default_55[1]
        getitem_167 = native_batch_norm_default_55[2];  native_batch_norm_default_55 = None
        new_zeros_default_55 = torch.ops.aten.new_zeros.default(convolution_default_55, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_77 = torch.ops.aten.add_.Tensor(getitem_165, relu__default_50);  getitem_165 = None
        relu__default_52 = torch.ops.aten.relu_.default(add__tensor_77);  add__tensor_77 = None
        convolution_default_56 = torch.ops.aten.convolution.default(relu__default_52, primals_443, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_78 = torch.ops.aten.add_.Tensor(primals_434, 1);  primals_434 = None
        native_batch_norm_default_56 = torch.ops.aten.native_batch_norm.default(convolution_default_56, primals_437, primals_433, primals_435, primals_436, True, 0.1, 1e-05);  primals_433 = None
        getitem_168 = native_batch_norm_default_56[0]
        getitem_169 = native_batch_norm_default_56[1]
        getitem_170 = native_batch_norm_default_56[2];  native_batch_norm_default_56 = None
        new_zeros_default_56 = torch.ops.aten.new_zeros.default(convolution_default_56, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_53 = torch.ops.aten.relu_.default(getitem_168);  getitem_168 = None
        convolution_default_57 = torch.ops.aten.convolution.default(relu__default_53, primals_444, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_79 = torch.ops.aten.add_.Tensor(primals_439, 1);  primals_439 = None
        native_batch_norm_default_57 = torch.ops.aten.native_batch_norm.default(convolution_default_57, primals_442, primals_438, primals_440, primals_441, True, 0.1, 1e-05);  primals_438 = None
        getitem_171 = native_batch_norm_default_57[0]
        getitem_172 = native_batch_norm_default_57[1]
        getitem_173 = native_batch_norm_default_57[2];  native_batch_norm_default_57 = None
        new_zeros_default_57 = torch.ops.aten.new_zeros.default(convolution_default_57, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_80 = torch.ops.aten.add_.Tensor(getitem_171, relu__default_52);  getitem_171 = None
        relu__default_54 = torch.ops.aten.relu_.default(add__tensor_80);  add__tensor_80 = None
        convolution_default_58 = torch.ops.aten.convolution.default(relu__default_54, primals_455, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_81 = torch.ops.aten.add_.Tensor(primals_446, 1);  primals_446 = None
        native_batch_norm_default_58 = torch.ops.aten.native_batch_norm.default(convolution_default_58, primals_449, primals_445, primals_447, primals_448, True, 0.1, 1e-05);  primals_445 = None
        getitem_174 = native_batch_norm_default_58[0]
        getitem_175 = native_batch_norm_default_58[1]
        getitem_176 = native_batch_norm_default_58[2];  native_batch_norm_default_58 = None
        new_zeros_default_58 = torch.ops.aten.new_zeros.default(convolution_default_58, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_55 = torch.ops.aten.relu_.default(getitem_174);  getitem_174 = None
        convolution_default_59 = torch.ops.aten.convolution.default(relu__default_55, primals_456, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_82 = torch.ops.aten.add_.Tensor(primals_451, 1);  primals_451 = None
        native_batch_norm_default_59 = torch.ops.aten.native_batch_norm.default(convolution_default_59, primals_454, primals_450, primals_452, primals_453, True, 0.1, 1e-05);  primals_450 = None
        getitem_177 = native_batch_norm_default_59[0]
        getitem_178 = native_batch_norm_default_59[1]
        getitem_179 = native_batch_norm_default_59[2];  native_batch_norm_default_59 = None
        new_zeros_default_59 = torch.ops.aten.new_zeros.default(convolution_default_59, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_83 = torch.ops.aten.add_.Tensor(getitem_177, relu__default_54);  getitem_177 = None
        relu__default_56 = torch.ops.aten.relu_.default(add__tensor_83);  add__tensor_83 = None
        convolution_default_60 = torch.ops.aten.convolution.default(relu__default_48, primals_1759, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_84 = torch.ops.aten.add_.Tensor(primals_1761, 1);  primals_1761 = None
        native_batch_norm_default_60 = torch.ops.aten.native_batch_norm.default(convolution_default_60, primals_1764, primals_1760, primals_1762, primals_1763, True, 0.1, 1e-05);  primals_1760 = None
        getitem_180 = native_batch_norm_default_60[0]
        getitem_181 = native_batch_norm_default_60[1]
        getitem_182 = native_batch_norm_default_60[2];  native_batch_norm_default_60 = None
        new_zeros_default_60 = torch.ops.aten.new_zeros.default(convolution_default_60, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_1 = torch.ops.aten.upsample_nearest2d.vec(getitem_180, None, [2.0, 2.0]);  getitem_180 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(relu__default_40, upsample_nearest2d_vec_1);  upsample_nearest2d_vec_1 = None
        convolution_default_61 = torch.ops.aten.convolution.default(relu__default_56, primals_1801, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_85 = torch.ops.aten.add_.Tensor(primals_1803, 1);  primals_1803 = None
        native_batch_norm_default_61 = torch.ops.aten.native_batch_norm.default(convolution_default_61, primals_1806, primals_1802, primals_1804, primals_1805, True, 0.1, 1e-05);  primals_1802 = None
        getitem_183 = native_batch_norm_default_61[0]
        getitem_184 = native_batch_norm_default_61[1]
        getitem_185 = native_batch_norm_default_61[2];  native_batch_norm_default_61 = None
        new_zeros_default_61 = torch.ops.aten.new_zeros.default(convolution_default_61, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_2 = torch.ops.aten.upsample_nearest2d.vec(getitem_183, None, [4.0, 4.0]);  getitem_183 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(add_tensor_2, upsample_nearest2d_vec_2);  add_tensor_2 = upsample_nearest2d_vec_2 = None
        relu_default_2 = torch.ops.aten.relu.default(add_tensor_3);  add_tensor_3 = None
        convolution_default_62 = torch.ops.aten.convolution.default(relu__default_40, primals_1597, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_86 = torch.ops.aten.add_.Tensor(primals_1599, 1);  primals_1599 = None
        native_batch_norm_default_62 = torch.ops.aten.native_batch_norm.default(convolution_default_62, primals_1602, primals_1598, primals_1600, primals_1601, True, 0.1, 1e-05);  primals_1598 = None
        getitem_186 = native_batch_norm_default_62[0]
        getitem_187 = native_batch_norm_default_62[1]
        getitem_188 = native_batch_norm_default_62[2];  native_batch_norm_default_62 = None
        new_zeros_default_62 = torch.ops.aten.new_zeros.default(convolution_default_62, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_4 = torch.ops.aten.add.Tensor(getitem_186, relu__default_48);  getitem_186 = None
        convolution_default_63 = torch.ops.aten.convolution.default(relu__default_56, primals_1861, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_87 = torch.ops.aten.add_.Tensor(primals_1863, 1);  primals_1863 = None
        native_batch_norm_default_63 = torch.ops.aten.native_batch_norm.default(convolution_default_63, primals_1866, primals_1862, primals_1864, primals_1865, True, 0.1, 1e-05);  primals_1862 = None
        getitem_189 = native_batch_norm_default_63[0]
        getitem_190 = native_batch_norm_default_63[1]
        getitem_191 = native_batch_norm_default_63[2];  native_batch_norm_default_63 = None
        new_zeros_default_63 = torch.ops.aten.new_zeros.default(convolution_default_63, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_3 = torch.ops.aten.upsample_nearest2d.vec(getitem_189, None, [2.0, 2.0]);  getitem_189 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(add_tensor_4, upsample_nearest2d_vec_3);  add_tensor_4 = upsample_nearest2d_vec_3 = None
        relu_default_3 = torch.ops.aten.relu.default(add_tensor_5);  add_tensor_5 = None
        convolution_default_64 = torch.ops.aten.convolution.default(relu__default_40, primals_1603, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_88 = torch.ops.aten.add_.Tensor(primals_1605, 1);  primals_1605 = None
        native_batch_norm_default_64 = torch.ops.aten.native_batch_norm.default(convolution_default_64, primals_1608, primals_1604, primals_1606, primals_1607, True, 0.1, 1e-05);  primals_1604 = None
        getitem_192 = native_batch_norm_default_64[0]
        getitem_193 = native_batch_norm_default_64[1]
        getitem_194 = native_batch_norm_default_64[2];  native_batch_norm_default_64 = None
        new_zeros_default_64 = torch.ops.aten.new_zeros.default(convolution_default_64, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_4 = torch.ops.aten.relu.default(getitem_192);  getitem_192 = None
        convolution_default_65 = torch.ops.aten.convolution.default(relu_default_4, primals_1609, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_89 = torch.ops.aten.add_.Tensor(primals_1611, 1);  primals_1611 = None
        native_batch_norm_default_65 = torch.ops.aten.native_batch_norm.default(convolution_default_65, primals_1614, primals_1610, primals_1612, primals_1613, True, 0.1, 1e-05);  primals_1610 = None
        getitem_195 = native_batch_norm_default_65[0]
        getitem_196 = native_batch_norm_default_65[1]
        getitem_197 = native_batch_norm_default_65[2];  native_batch_norm_default_65 = None
        new_zeros_default_65 = torch.ops.aten.new_zeros.default(convolution_default_65, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_66 = torch.ops.aten.convolution.default(relu__default_48, primals_1765, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_90 = torch.ops.aten.add_.Tensor(primals_1767, 1);  primals_1767 = None
        native_batch_norm_default_66 = torch.ops.aten.native_batch_norm.default(convolution_default_66, primals_1770, primals_1766, primals_1768, primals_1769, True, 0.1, 1e-05);  primals_1766 = None
        getitem_198 = native_batch_norm_default_66[0]
        getitem_199 = native_batch_norm_default_66[1]
        getitem_200 = native_batch_norm_default_66[2];  native_batch_norm_default_66 = None
        new_zeros_default_66 = torch.ops.aten.new_zeros.default(convolution_default_66, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_6 = torch.ops.aten.add.Tensor(getitem_195, getitem_198);  getitem_195 = getitem_198 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(add_tensor_6, relu__default_56);  add_tensor_6 = None
        relu_default_5 = torch.ops.aten.relu.default(add_tensor_7);  add_tensor_7 = None
        convolution_default_67 = torch.ops.aten.convolution.default(relu_default_2, primals_467, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_91 = torch.ops.aten.add_.Tensor(primals_458, 1);  primals_458 = None
        native_batch_norm_default_67 = torch.ops.aten.native_batch_norm.default(convolution_default_67, primals_461, primals_457, primals_459, primals_460, True, 0.1, 1e-05);  primals_457 = None
        getitem_201 = native_batch_norm_default_67[0]
        getitem_202 = native_batch_norm_default_67[1]
        getitem_203 = native_batch_norm_default_67[2];  native_batch_norm_default_67 = None
        new_zeros_default_67 = torch.ops.aten.new_zeros.default(convolution_default_67, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_57 = torch.ops.aten.relu_.default(getitem_201);  getitem_201 = None
        convolution_default_68 = torch.ops.aten.convolution.default(relu__default_57, primals_468, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_92 = torch.ops.aten.add_.Tensor(primals_463, 1);  primals_463 = None
        native_batch_norm_default_68 = torch.ops.aten.native_batch_norm.default(convolution_default_68, primals_466, primals_462, primals_464, primals_465, True, 0.1, 1e-05);  primals_462 = None
        getitem_204 = native_batch_norm_default_68[0]
        getitem_205 = native_batch_norm_default_68[1]
        getitem_206 = native_batch_norm_default_68[2];  native_batch_norm_default_68 = None
        new_zeros_default_68 = torch.ops.aten.new_zeros.default(convolution_default_68, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_93 = torch.ops.aten.add_.Tensor(getitem_204, relu_default_2);  getitem_204 = None
        relu__default_58 = torch.ops.aten.relu_.default(add__tensor_93);  add__tensor_93 = None
        convolution_default_69 = torch.ops.aten.convolution.default(relu__default_58, primals_479, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_94 = torch.ops.aten.add_.Tensor(primals_470, 1);  primals_470 = None
        native_batch_norm_default_69 = torch.ops.aten.native_batch_norm.default(convolution_default_69, primals_473, primals_469, primals_471, primals_472, True, 0.1, 1e-05);  primals_469 = None
        getitem_207 = native_batch_norm_default_69[0]
        getitem_208 = native_batch_norm_default_69[1]
        getitem_209 = native_batch_norm_default_69[2];  native_batch_norm_default_69 = None
        new_zeros_default_69 = torch.ops.aten.new_zeros.default(convolution_default_69, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_59 = torch.ops.aten.relu_.default(getitem_207);  getitem_207 = None
        convolution_default_70 = torch.ops.aten.convolution.default(relu__default_59, primals_480, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_95 = torch.ops.aten.add_.Tensor(primals_475, 1);  primals_475 = None
        native_batch_norm_default_70 = torch.ops.aten.native_batch_norm.default(convolution_default_70, primals_478, primals_474, primals_476, primals_477, True, 0.1, 1e-05);  primals_474 = None
        getitem_210 = native_batch_norm_default_70[0]
        getitem_211 = native_batch_norm_default_70[1]
        getitem_212 = native_batch_norm_default_70[2];  native_batch_norm_default_70 = None
        new_zeros_default_70 = torch.ops.aten.new_zeros.default(convolution_default_70, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_96 = torch.ops.aten.add_.Tensor(getitem_210, relu__default_58);  getitem_210 = None
        relu__default_60 = torch.ops.aten.relu_.default(add__tensor_96);  add__tensor_96 = None
        convolution_default_71 = torch.ops.aten.convolution.default(relu__default_60, primals_491, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_97 = torch.ops.aten.add_.Tensor(primals_482, 1);  primals_482 = None
        native_batch_norm_default_71 = torch.ops.aten.native_batch_norm.default(convolution_default_71, primals_485, primals_481, primals_483, primals_484, True, 0.1, 1e-05);  primals_481 = None
        getitem_213 = native_batch_norm_default_71[0]
        getitem_214 = native_batch_norm_default_71[1]
        getitem_215 = native_batch_norm_default_71[2];  native_batch_norm_default_71 = None
        new_zeros_default_71 = torch.ops.aten.new_zeros.default(convolution_default_71, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_61 = torch.ops.aten.relu_.default(getitem_213);  getitem_213 = None
        convolution_default_72 = torch.ops.aten.convolution.default(relu__default_61, primals_492, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_98 = torch.ops.aten.add_.Tensor(primals_487, 1);  primals_487 = None
        native_batch_norm_default_72 = torch.ops.aten.native_batch_norm.default(convolution_default_72, primals_490, primals_486, primals_488, primals_489, True, 0.1, 1e-05);  primals_486 = None
        getitem_216 = native_batch_norm_default_72[0]
        getitem_217 = native_batch_norm_default_72[1]
        getitem_218 = native_batch_norm_default_72[2];  native_batch_norm_default_72 = None
        new_zeros_default_72 = torch.ops.aten.new_zeros.default(convolution_default_72, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_99 = torch.ops.aten.add_.Tensor(getitem_216, relu__default_60);  getitem_216 = None
        relu__default_62 = torch.ops.aten.relu_.default(add__tensor_99);  add__tensor_99 = None
        convolution_default_73 = torch.ops.aten.convolution.default(relu__default_62, primals_503, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_100 = torch.ops.aten.add_.Tensor(primals_494, 1);  primals_494 = None
        native_batch_norm_default_73 = torch.ops.aten.native_batch_norm.default(convolution_default_73, primals_497, primals_493, primals_495, primals_496, True, 0.1, 1e-05);  primals_493 = None
        getitem_219 = native_batch_norm_default_73[0]
        getitem_220 = native_batch_norm_default_73[1]
        getitem_221 = native_batch_norm_default_73[2];  native_batch_norm_default_73 = None
        new_zeros_default_73 = torch.ops.aten.new_zeros.default(convolution_default_73, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_63 = torch.ops.aten.relu_.default(getitem_219);  getitem_219 = None
        convolution_default_74 = torch.ops.aten.convolution.default(relu__default_63, primals_504, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_101 = torch.ops.aten.add_.Tensor(primals_499, 1);  primals_499 = None
        native_batch_norm_default_74 = torch.ops.aten.native_batch_norm.default(convolution_default_74, primals_502, primals_498, primals_500, primals_501, True, 0.1, 1e-05);  primals_498 = None
        getitem_222 = native_batch_norm_default_74[0]
        getitem_223 = native_batch_norm_default_74[1]
        getitem_224 = native_batch_norm_default_74[2];  native_batch_norm_default_74 = None
        new_zeros_default_74 = torch.ops.aten.new_zeros.default(convolution_default_74, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_102 = torch.ops.aten.add_.Tensor(getitem_222, relu__default_62);  getitem_222 = None
        relu__default_64 = torch.ops.aten.relu_.default(add__tensor_102);  add__tensor_102 = None
        convolution_default_75 = torch.ops.aten.convolution.default(relu_default_3, primals_515, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_103 = torch.ops.aten.add_.Tensor(primals_506, 1);  primals_506 = None
        native_batch_norm_default_75 = torch.ops.aten.native_batch_norm.default(convolution_default_75, primals_509, primals_505, primals_507, primals_508, True, 0.1, 1e-05);  primals_505 = None
        getitem_225 = native_batch_norm_default_75[0]
        getitem_226 = native_batch_norm_default_75[1]
        getitem_227 = native_batch_norm_default_75[2];  native_batch_norm_default_75 = None
        new_zeros_default_75 = torch.ops.aten.new_zeros.default(convolution_default_75, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_65 = torch.ops.aten.relu_.default(getitem_225);  getitem_225 = None
        convolution_default_76 = torch.ops.aten.convolution.default(relu__default_65, primals_516, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_104 = torch.ops.aten.add_.Tensor(primals_511, 1);  primals_511 = None
        native_batch_norm_default_76 = torch.ops.aten.native_batch_norm.default(convolution_default_76, primals_514, primals_510, primals_512, primals_513, True, 0.1, 1e-05);  primals_510 = None
        getitem_228 = native_batch_norm_default_76[0]
        getitem_229 = native_batch_norm_default_76[1]
        getitem_230 = native_batch_norm_default_76[2];  native_batch_norm_default_76 = None
        new_zeros_default_76 = torch.ops.aten.new_zeros.default(convolution_default_76, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_105 = torch.ops.aten.add_.Tensor(getitem_228, relu_default_3);  getitem_228 = None
        relu__default_66 = torch.ops.aten.relu_.default(add__tensor_105);  add__tensor_105 = None
        convolution_default_77 = torch.ops.aten.convolution.default(relu__default_66, primals_527, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_106 = torch.ops.aten.add_.Tensor(primals_518, 1);  primals_518 = None
        native_batch_norm_default_77 = torch.ops.aten.native_batch_norm.default(convolution_default_77, primals_521, primals_517, primals_519, primals_520, True, 0.1, 1e-05);  primals_517 = None
        getitem_231 = native_batch_norm_default_77[0]
        getitem_232 = native_batch_norm_default_77[1]
        getitem_233 = native_batch_norm_default_77[2];  native_batch_norm_default_77 = None
        new_zeros_default_77 = torch.ops.aten.new_zeros.default(convolution_default_77, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_67 = torch.ops.aten.relu_.default(getitem_231);  getitem_231 = None
        convolution_default_78 = torch.ops.aten.convolution.default(relu__default_67, primals_528, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_107 = torch.ops.aten.add_.Tensor(primals_523, 1);  primals_523 = None
        native_batch_norm_default_78 = torch.ops.aten.native_batch_norm.default(convolution_default_78, primals_526, primals_522, primals_524, primals_525, True, 0.1, 1e-05);  primals_522 = None
        getitem_234 = native_batch_norm_default_78[0]
        getitem_235 = native_batch_norm_default_78[1]
        getitem_236 = native_batch_norm_default_78[2];  native_batch_norm_default_78 = None
        new_zeros_default_78 = torch.ops.aten.new_zeros.default(convolution_default_78, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_108 = torch.ops.aten.add_.Tensor(getitem_234, relu__default_66);  getitem_234 = None
        relu__default_68 = torch.ops.aten.relu_.default(add__tensor_108);  add__tensor_108 = None
        convolution_default_79 = torch.ops.aten.convolution.default(relu__default_68, primals_539, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_109 = torch.ops.aten.add_.Tensor(primals_530, 1);  primals_530 = None
        native_batch_norm_default_79 = torch.ops.aten.native_batch_norm.default(convolution_default_79, primals_533, primals_529, primals_531, primals_532, True, 0.1, 1e-05);  primals_529 = None
        getitem_237 = native_batch_norm_default_79[0]
        getitem_238 = native_batch_norm_default_79[1]
        getitem_239 = native_batch_norm_default_79[2];  native_batch_norm_default_79 = None
        new_zeros_default_79 = torch.ops.aten.new_zeros.default(convolution_default_79, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_69 = torch.ops.aten.relu_.default(getitem_237);  getitem_237 = None
        convolution_default_80 = torch.ops.aten.convolution.default(relu__default_69, primals_540, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_110 = torch.ops.aten.add_.Tensor(primals_535, 1);  primals_535 = None
        native_batch_norm_default_80 = torch.ops.aten.native_batch_norm.default(convolution_default_80, primals_538, primals_534, primals_536, primals_537, True, 0.1, 1e-05);  primals_534 = None
        getitem_240 = native_batch_norm_default_80[0]
        getitem_241 = native_batch_norm_default_80[1]
        getitem_242 = native_batch_norm_default_80[2];  native_batch_norm_default_80 = None
        new_zeros_default_80 = torch.ops.aten.new_zeros.default(convolution_default_80, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_111 = torch.ops.aten.add_.Tensor(getitem_240, relu__default_68);  getitem_240 = None
        relu__default_70 = torch.ops.aten.relu_.default(add__tensor_111);  add__tensor_111 = None
        convolution_default_81 = torch.ops.aten.convolution.default(relu__default_70, primals_551, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_112 = torch.ops.aten.add_.Tensor(primals_542, 1);  primals_542 = None
        native_batch_norm_default_81 = torch.ops.aten.native_batch_norm.default(convolution_default_81, primals_545, primals_541, primals_543, primals_544, True, 0.1, 1e-05);  primals_541 = None
        getitem_243 = native_batch_norm_default_81[0]
        getitem_244 = native_batch_norm_default_81[1]
        getitem_245 = native_batch_norm_default_81[2];  native_batch_norm_default_81 = None
        new_zeros_default_81 = torch.ops.aten.new_zeros.default(convolution_default_81, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_71 = torch.ops.aten.relu_.default(getitem_243);  getitem_243 = None
        convolution_default_82 = torch.ops.aten.convolution.default(relu__default_71, primals_552, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_113 = torch.ops.aten.add_.Tensor(primals_547, 1);  primals_547 = None
        native_batch_norm_default_82 = torch.ops.aten.native_batch_norm.default(convolution_default_82, primals_550, primals_546, primals_548, primals_549, True, 0.1, 1e-05);  primals_546 = None
        getitem_246 = native_batch_norm_default_82[0]
        getitem_247 = native_batch_norm_default_82[1]
        getitem_248 = native_batch_norm_default_82[2];  native_batch_norm_default_82 = None
        new_zeros_default_82 = torch.ops.aten.new_zeros.default(convolution_default_82, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_114 = torch.ops.aten.add_.Tensor(getitem_246, relu__default_70);  getitem_246 = None
        relu__default_72 = torch.ops.aten.relu_.default(add__tensor_114);  add__tensor_114 = None
        convolution_default_83 = torch.ops.aten.convolution.default(relu_default_5, primals_563, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_115 = torch.ops.aten.add_.Tensor(primals_554, 1);  primals_554 = None
        native_batch_norm_default_83 = torch.ops.aten.native_batch_norm.default(convolution_default_83, primals_557, primals_553, primals_555, primals_556, True, 0.1, 1e-05);  primals_553 = None
        getitem_249 = native_batch_norm_default_83[0]
        getitem_250 = native_batch_norm_default_83[1]
        getitem_251 = native_batch_norm_default_83[2];  native_batch_norm_default_83 = None
        new_zeros_default_83 = torch.ops.aten.new_zeros.default(convolution_default_83, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_73 = torch.ops.aten.relu_.default(getitem_249);  getitem_249 = None
        convolution_default_84 = torch.ops.aten.convolution.default(relu__default_73, primals_564, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_116 = torch.ops.aten.add_.Tensor(primals_559, 1);  primals_559 = None
        native_batch_norm_default_84 = torch.ops.aten.native_batch_norm.default(convolution_default_84, primals_562, primals_558, primals_560, primals_561, True, 0.1, 1e-05);  primals_558 = None
        getitem_252 = native_batch_norm_default_84[0]
        getitem_253 = native_batch_norm_default_84[1]
        getitem_254 = native_batch_norm_default_84[2];  native_batch_norm_default_84 = None
        new_zeros_default_84 = torch.ops.aten.new_zeros.default(convolution_default_84, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_117 = torch.ops.aten.add_.Tensor(getitem_252, relu_default_5);  getitem_252 = None
        relu__default_74 = torch.ops.aten.relu_.default(add__tensor_117);  add__tensor_117 = None
        convolution_default_85 = torch.ops.aten.convolution.default(relu__default_74, primals_575, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_118 = torch.ops.aten.add_.Tensor(primals_566, 1);  primals_566 = None
        native_batch_norm_default_85 = torch.ops.aten.native_batch_norm.default(convolution_default_85, primals_569, primals_565, primals_567, primals_568, True, 0.1, 1e-05);  primals_565 = None
        getitem_255 = native_batch_norm_default_85[0]
        getitem_256 = native_batch_norm_default_85[1]
        getitem_257 = native_batch_norm_default_85[2];  native_batch_norm_default_85 = None
        new_zeros_default_85 = torch.ops.aten.new_zeros.default(convolution_default_85, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_75 = torch.ops.aten.relu_.default(getitem_255);  getitem_255 = None
        convolution_default_86 = torch.ops.aten.convolution.default(relu__default_75, primals_576, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_119 = torch.ops.aten.add_.Tensor(primals_571, 1);  primals_571 = None
        native_batch_norm_default_86 = torch.ops.aten.native_batch_norm.default(convolution_default_86, primals_574, primals_570, primals_572, primals_573, True, 0.1, 1e-05);  primals_570 = None
        getitem_258 = native_batch_norm_default_86[0]
        getitem_259 = native_batch_norm_default_86[1]
        getitem_260 = native_batch_norm_default_86[2];  native_batch_norm_default_86 = None
        new_zeros_default_86 = torch.ops.aten.new_zeros.default(convolution_default_86, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_120 = torch.ops.aten.add_.Tensor(getitem_258, relu__default_74);  getitem_258 = None
        relu__default_76 = torch.ops.aten.relu_.default(add__tensor_120);  add__tensor_120 = None
        convolution_default_87 = torch.ops.aten.convolution.default(relu__default_76, primals_587, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_121 = torch.ops.aten.add_.Tensor(primals_578, 1);  primals_578 = None
        native_batch_norm_default_87 = torch.ops.aten.native_batch_norm.default(convolution_default_87, primals_581, primals_577, primals_579, primals_580, True, 0.1, 1e-05);  primals_577 = None
        getitem_261 = native_batch_norm_default_87[0]
        getitem_262 = native_batch_norm_default_87[1]
        getitem_263 = native_batch_norm_default_87[2];  native_batch_norm_default_87 = None
        new_zeros_default_87 = torch.ops.aten.new_zeros.default(convolution_default_87, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_77 = torch.ops.aten.relu_.default(getitem_261);  getitem_261 = None
        convolution_default_88 = torch.ops.aten.convolution.default(relu__default_77, primals_588, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_122 = torch.ops.aten.add_.Tensor(primals_583, 1);  primals_583 = None
        native_batch_norm_default_88 = torch.ops.aten.native_batch_norm.default(convolution_default_88, primals_586, primals_582, primals_584, primals_585, True, 0.1, 1e-05);  primals_582 = None
        getitem_264 = native_batch_norm_default_88[0]
        getitem_265 = native_batch_norm_default_88[1]
        getitem_266 = native_batch_norm_default_88[2];  native_batch_norm_default_88 = None
        new_zeros_default_88 = torch.ops.aten.new_zeros.default(convolution_default_88, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_123 = torch.ops.aten.add_.Tensor(getitem_264, relu__default_76);  getitem_264 = None
        relu__default_78 = torch.ops.aten.relu_.default(add__tensor_123);  add__tensor_123 = None
        convolution_default_89 = torch.ops.aten.convolution.default(relu__default_78, primals_599, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_124 = torch.ops.aten.add_.Tensor(primals_590, 1);  primals_590 = None
        native_batch_norm_default_89 = torch.ops.aten.native_batch_norm.default(convolution_default_89, primals_593, primals_589, primals_591, primals_592, True, 0.1, 1e-05);  primals_589 = None
        getitem_267 = native_batch_norm_default_89[0]
        getitem_268 = native_batch_norm_default_89[1]
        getitem_269 = native_batch_norm_default_89[2];  native_batch_norm_default_89 = None
        new_zeros_default_89 = torch.ops.aten.new_zeros.default(convolution_default_89, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_79 = torch.ops.aten.relu_.default(getitem_267);  getitem_267 = None
        convolution_default_90 = torch.ops.aten.convolution.default(relu__default_79, primals_600, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_125 = torch.ops.aten.add_.Tensor(primals_595, 1);  primals_595 = None
        native_batch_norm_default_90 = torch.ops.aten.native_batch_norm.default(convolution_default_90, primals_598, primals_594, primals_596, primals_597, True, 0.1, 1e-05);  primals_594 = None
        getitem_270 = native_batch_norm_default_90[0]
        getitem_271 = native_batch_norm_default_90[1]
        getitem_272 = native_batch_norm_default_90[2];  native_batch_norm_default_90 = None
        new_zeros_default_90 = torch.ops.aten.new_zeros.default(convolution_default_90, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_126 = torch.ops.aten.add_.Tensor(getitem_270, relu__default_78);  getitem_270 = None
        relu__default_80 = torch.ops.aten.relu_.default(add__tensor_126);  add__tensor_126 = None
        convolution_default_91 = torch.ops.aten.convolution.default(relu__default_72, primals_1771, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_127 = torch.ops.aten.add_.Tensor(primals_1773, 1);  primals_1773 = None
        native_batch_norm_default_91 = torch.ops.aten.native_batch_norm.default(convolution_default_91, primals_1776, primals_1772, primals_1774, primals_1775, True, 0.1, 1e-05);  primals_1772 = None
        getitem_273 = native_batch_norm_default_91[0]
        getitem_274 = native_batch_norm_default_91[1]
        getitem_275 = native_batch_norm_default_91[2];  native_batch_norm_default_91 = None
        new_zeros_default_91 = torch.ops.aten.new_zeros.default(convolution_default_91, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_4 = torch.ops.aten.upsample_nearest2d.vec(getitem_273, None, [2.0, 2.0]);  getitem_273 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(relu__default_64, upsample_nearest2d_vec_4);  upsample_nearest2d_vec_4 = None
        convolution_default_92 = torch.ops.aten.convolution.default(relu__default_80, primals_1867, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_128 = torch.ops.aten.add_.Tensor(primals_1869, 1);  primals_1869 = None
        native_batch_norm_default_92 = torch.ops.aten.native_batch_norm.default(convolution_default_92, primals_1872, primals_1868, primals_1870, primals_1871, True, 0.1, 1e-05);  primals_1868 = None
        getitem_276 = native_batch_norm_default_92[0]
        getitem_277 = native_batch_norm_default_92[1]
        getitem_278 = native_batch_norm_default_92[2];  native_batch_norm_default_92 = None
        new_zeros_default_92 = torch.ops.aten.new_zeros.default(convolution_default_92, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_5 = torch.ops.aten.upsample_nearest2d.vec(getitem_276, None, [4.0, 4.0]);  getitem_276 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(add_tensor_8, upsample_nearest2d_vec_5);  add_tensor_8 = upsample_nearest2d_vec_5 = None
        relu_default_6 = torch.ops.aten.relu.default(add_tensor_9);  add_tensor_9 = None
        convolution_default_93 = torch.ops.aten.convolution.default(relu__default_64, primals_1615, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_129 = torch.ops.aten.add_.Tensor(primals_1617, 1);  primals_1617 = None
        native_batch_norm_default_93 = torch.ops.aten.native_batch_norm.default(convolution_default_93, primals_1620, primals_1616, primals_1618, primals_1619, True, 0.1, 1e-05);  primals_1616 = None
        getitem_279 = native_batch_norm_default_93[0]
        getitem_280 = native_batch_norm_default_93[1]
        getitem_281 = native_batch_norm_default_93[2];  native_batch_norm_default_93 = None
        new_zeros_default_93 = torch.ops.aten.new_zeros.default(convolution_default_93, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_10 = torch.ops.aten.add.Tensor(getitem_279, relu__default_72);  getitem_279 = None
        convolution_default_94 = torch.ops.aten.convolution.default(relu__default_80, primals_1873, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_130 = torch.ops.aten.add_.Tensor(primals_1875, 1);  primals_1875 = None
        native_batch_norm_default_94 = torch.ops.aten.native_batch_norm.default(convolution_default_94, primals_1878, primals_1874, primals_1876, primals_1877, True, 0.1, 1e-05);  primals_1874 = None
        getitem_282 = native_batch_norm_default_94[0]
        getitem_283 = native_batch_norm_default_94[1]
        getitem_284 = native_batch_norm_default_94[2];  native_batch_norm_default_94 = None
        new_zeros_default_94 = torch.ops.aten.new_zeros.default(convolution_default_94, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_6 = torch.ops.aten.upsample_nearest2d.vec(getitem_282, None, [2.0, 2.0]);  getitem_282 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(add_tensor_10, upsample_nearest2d_vec_6);  add_tensor_10 = upsample_nearest2d_vec_6 = None
        relu_default_7 = torch.ops.aten.relu.default(add_tensor_11);  add_tensor_11 = None
        convolution_default_95 = torch.ops.aten.convolution.default(relu__default_64, primals_1621, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_131 = torch.ops.aten.add_.Tensor(primals_1623, 1);  primals_1623 = None
        native_batch_norm_default_95 = torch.ops.aten.native_batch_norm.default(convolution_default_95, primals_1626, primals_1622, primals_1624, primals_1625, True, 0.1, 1e-05);  primals_1622 = None
        getitem_285 = native_batch_norm_default_95[0]
        getitem_286 = native_batch_norm_default_95[1]
        getitem_287 = native_batch_norm_default_95[2];  native_batch_norm_default_95 = None
        new_zeros_default_95 = torch.ops.aten.new_zeros.default(convolution_default_95, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_8 = torch.ops.aten.relu.default(getitem_285);  getitem_285 = None
        convolution_default_96 = torch.ops.aten.convolution.default(relu_default_8, primals_1627, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_132 = torch.ops.aten.add_.Tensor(primals_1629, 1);  primals_1629 = None
        native_batch_norm_default_96 = torch.ops.aten.native_batch_norm.default(convolution_default_96, primals_1632, primals_1628, primals_1630, primals_1631, True, 0.1, 1e-05);  primals_1628 = None
        getitem_288 = native_batch_norm_default_96[0]
        getitem_289 = native_batch_norm_default_96[1]
        getitem_290 = native_batch_norm_default_96[2];  native_batch_norm_default_96 = None
        new_zeros_default_96 = torch.ops.aten.new_zeros.default(convolution_default_96, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_97 = torch.ops.aten.convolution.default(relu__default_72, primals_1777, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_133 = torch.ops.aten.add_.Tensor(primals_1779, 1);  primals_1779 = None
        native_batch_norm_default_97 = torch.ops.aten.native_batch_norm.default(convolution_default_97, primals_1782, primals_1778, primals_1780, primals_1781, True, 0.1, 1e-05);  primals_1778 = None
        getitem_291 = native_batch_norm_default_97[0]
        getitem_292 = native_batch_norm_default_97[1]
        getitem_293 = native_batch_norm_default_97[2];  native_batch_norm_default_97 = None
        new_zeros_default_97 = torch.ops.aten.new_zeros.default(convolution_default_97, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_12 = torch.ops.aten.add.Tensor(getitem_288, getitem_291);  getitem_288 = getitem_291 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(add_tensor_12, relu__default_80);  add_tensor_12 = None
        relu_default_9 = torch.ops.aten.relu.default(add_tensor_13);  add_tensor_13 = None
        convolution_default_98 = torch.ops.aten.convolution.default(relu_default_6, primals_611, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_134 = torch.ops.aten.add_.Tensor(primals_602, 1);  primals_602 = None
        native_batch_norm_default_98 = torch.ops.aten.native_batch_norm.default(convolution_default_98, primals_605, primals_601, primals_603, primals_604, True, 0.1, 1e-05);  primals_601 = None
        getitem_294 = native_batch_norm_default_98[0]
        getitem_295 = native_batch_norm_default_98[1]
        getitem_296 = native_batch_norm_default_98[2];  native_batch_norm_default_98 = None
        new_zeros_default_98 = torch.ops.aten.new_zeros.default(convolution_default_98, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_81 = torch.ops.aten.relu_.default(getitem_294);  getitem_294 = None
        convolution_default_99 = torch.ops.aten.convolution.default(relu__default_81, primals_612, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_135 = torch.ops.aten.add_.Tensor(primals_607, 1);  primals_607 = None
        native_batch_norm_default_99 = torch.ops.aten.native_batch_norm.default(convolution_default_99, primals_610, primals_606, primals_608, primals_609, True, 0.1, 1e-05);  primals_606 = None
        getitem_297 = native_batch_norm_default_99[0]
        getitem_298 = native_batch_norm_default_99[1]
        getitem_299 = native_batch_norm_default_99[2];  native_batch_norm_default_99 = None
        new_zeros_default_99 = torch.ops.aten.new_zeros.default(convolution_default_99, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_136 = torch.ops.aten.add_.Tensor(getitem_297, relu_default_6);  getitem_297 = None
        relu__default_82 = torch.ops.aten.relu_.default(add__tensor_136);  add__tensor_136 = None
        convolution_default_100 = torch.ops.aten.convolution.default(relu__default_82, primals_623, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_137 = torch.ops.aten.add_.Tensor(primals_614, 1);  primals_614 = None
        native_batch_norm_default_100 = torch.ops.aten.native_batch_norm.default(convolution_default_100, primals_617, primals_613, primals_615, primals_616, True, 0.1, 1e-05);  primals_613 = None
        getitem_300 = native_batch_norm_default_100[0]
        getitem_301 = native_batch_norm_default_100[1]
        getitem_302 = native_batch_norm_default_100[2];  native_batch_norm_default_100 = None
        new_zeros_default_100 = torch.ops.aten.new_zeros.default(convolution_default_100, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_83 = torch.ops.aten.relu_.default(getitem_300);  getitem_300 = None
        convolution_default_101 = torch.ops.aten.convolution.default(relu__default_83, primals_624, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_138 = torch.ops.aten.add_.Tensor(primals_619, 1);  primals_619 = None
        native_batch_norm_default_101 = torch.ops.aten.native_batch_norm.default(convolution_default_101, primals_622, primals_618, primals_620, primals_621, True, 0.1, 1e-05);  primals_618 = None
        getitem_303 = native_batch_norm_default_101[0]
        getitem_304 = native_batch_norm_default_101[1]
        getitem_305 = native_batch_norm_default_101[2];  native_batch_norm_default_101 = None
        new_zeros_default_101 = torch.ops.aten.new_zeros.default(convolution_default_101, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_139 = torch.ops.aten.add_.Tensor(getitem_303, relu__default_82);  getitem_303 = None
        relu__default_84 = torch.ops.aten.relu_.default(add__tensor_139);  add__tensor_139 = None
        convolution_default_102 = torch.ops.aten.convolution.default(relu__default_84, primals_635, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_140 = torch.ops.aten.add_.Tensor(primals_626, 1);  primals_626 = None
        native_batch_norm_default_102 = torch.ops.aten.native_batch_norm.default(convolution_default_102, primals_629, primals_625, primals_627, primals_628, True, 0.1, 1e-05);  primals_625 = None
        getitem_306 = native_batch_norm_default_102[0]
        getitem_307 = native_batch_norm_default_102[1]
        getitem_308 = native_batch_norm_default_102[2];  native_batch_norm_default_102 = None
        new_zeros_default_102 = torch.ops.aten.new_zeros.default(convolution_default_102, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_85 = torch.ops.aten.relu_.default(getitem_306);  getitem_306 = None
        convolution_default_103 = torch.ops.aten.convolution.default(relu__default_85, primals_636, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_141 = torch.ops.aten.add_.Tensor(primals_631, 1);  primals_631 = None
        native_batch_norm_default_103 = torch.ops.aten.native_batch_norm.default(convolution_default_103, primals_634, primals_630, primals_632, primals_633, True, 0.1, 1e-05);  primals_630 = None
        getitem_309 = native_batch_norm_default_103[0]
        getitem_310 = native_batch_norm_default_103[1]
        getitem_311 = native_batch_norm_default_103[2];  native_batch_norm_default_103 = None
        new_zeros_default_103 = torch.ops.aten.new_zeros.default(convolution_default_103, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_142 = torch.ops.aten.add_.Tensor(getitem_309, relu__default_84);  getitem_309 = None
        relu__default_86 = torch.ops.aten.relu_.default(add__tensor_142);  add__tensor_142 = None
        convolution_default_104 = torch.ops.aten.convolution.default(relu__default_86, primals_647, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_143 = torch.ops.aten.add_.Tensor(primals_638, 1);  primals_638 = None
        native_batch_norm_default_104 = torch.ops.aten.native_batch_norm.default(convolution_default_104, primals_641, primals_637, primals_639, primals_640, True, 0.1, 1e-05);  primals_637 = None
        getitem_312 = native_batch_norm_default_104[0]
        getitem_313 = native_batch_norm_default_104[1]
        getitem_314 = native_batch_norm_default_104[2];  native_batch_norm_default_104 = None
        new_zeros_default_104 = torch.ops.aten.new_zeros.default(convolution_default_104, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_87 = torch.ops.aten.relu_.default(getitem_312);  getitem_312 = None
        convolution_default_105 = torch.ops.aten.convolution.default(relu__default_87, primals_648, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_144 = torch.ops.aten.add_.Tensor(primals_643, 1);  primals_643 = None
        native_batch_norm_default_105 = torch.ops.aten.native_batch_norm.default(convolution_default_105, primals_646, primals_642, primals_644, primals_645, True, 0.1, 1e-05);  primals_642 = None
        getitem_315 = native_batch_norm_default_105[0]
        getitem_316 = native_batch_norm_default_105[1]
        getitem_317 = native_batch_norm_default_105[2];  native_batch_norm_default_105 = None
        new_zeros_default_105 = torch.ops.aten.new_zeros.default(convolution_default_105, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_145 = torch.ops.aten.add_.Tensor(getitem_315, relu__default_86);  getitem_315 = None
        relu__default_88 = torch.ops.aten.relu_.default(add__tensor_145);  add__tensor_145 = None
        convolution_default_106 = torch.ops.aten.convolution.default(relu_default_7, primals_659, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_146 = torch.ops.aten.add_.Tensor(primals_650, 1);  primals_650 = None
        native_batch_norm_default_106 = torch.ops.aten.native_batch_norm.default(convolution_default_106, primals_653, primals_649, primals_651, primals_652, True, 0.1, 1e-05);  primals_649 = None
        getitem_318 = native_batch_norm_default_106[0]
        getitem_319 = native_batch_norm_default_106[1]
        getitem_320 = native_batch_norm_default_106[2];  native_batch_norm_default_106 = None
        new_zeros_default_106 = torch.ops.aten.new_zeros.default(convolution_default_106, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_89 = torch.ops.aten.relu_.default(getitem_318);  getitem_318 = None
        convolution_default_107 = torch.ops.aten.convolution.default(relu__default_89, primals_660, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_147 = torch.ops.aten.add_.Tensor(primals_655, 1);  primals_655 = None
        native_batch_norm_default_107 = torch.ops.aten.native_batch_norm.default(convolution_default_107, primals_658, primals_654, primals_656, primals_657, True, 0.1, 1e-05);  primals_654 = None
        getitem_321 = native_batch_norm_default_107[0]
        getitem_322 = native_batch_norm_default_107[1]
        getitem_323 = native_batch_norm_default_107[2];  native_batch_norm_default_107 = None
        new_zeros_default_107 = torch.ops.aten.new_zeros.default(convolution_default_107, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_148 = torch.ops.aten.add_.Tensor(getitem_321, relu_default_7);  getitem_321 = None
        relu__default_90 = torch.ops.aten.relu_.default(add__tensor_148);  add__tensor_148 = None
        convolution_default_108 = torch.ops.aten.convolution.default(relu__default_90, primals_671, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_149 = torch.ops.aten.add_.Tensor(primals_662, 1);  primals_662 = None
        native_batch_norm_default_108 = torch.ops.aten.native_batch_norm.default(convolution_default_108, primals_665, primals_661, primals_663, primals_664, True, 0.1, 1e-05);  primals_661 = None
        getitem_324 = native_batch_norm_default_108[0]
        getitem_325 = native_batch_norm_default_108[1]
        getitem_326 = native_batch_norm_default_108[2];  native_batch_norm_default_108 = None
        new_zeros_default_108 = torch.ops.aten.new_zeros.default(convolution_default_108, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_91 = torch.ops.aten.relu_.default(getitem_324);  getitem_324 = None
        convolution_default_109 = torch.ops.aten.convolution.default(relu__default_91, primals_672, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_150 = torch.ops.aten.add_.Tensor(primals_667, 1);  primals_667 = None
        native_batch_norm_default_109 = torch.ops.aten.native_batch_norm.default(convolution_default_109, primals_670, primals_666, primals_668, primals_669, True, 0.1, 1e-05);  primals_666 = None
        getitem_327 = native_batch_norm_default_109[0]
        getitem_328 = native_batch_norm_default_109[1]
        getitem_329 = native_batch_norm_default_109[2];  native_batch_norm_default_109 = None
        new_zeros_default_109 = torch.ops.aten.new_zeros.default(convolution_default_109, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_151 = torch.ops.aten.add_.Tensor(getitem_327, relu__default_90);  getitem_327 = None
        relu__default_92 = torch.ops.aten.relu_.default(add__tensor_151);  add__tensor_151 = None
        convolution_default_110 = torch.ops.aten.convolution.default(relu__default_92, primals_683, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_152 = torch.ops.aten.add_.Tensor(primals_674, 1);  primals_674 = None
        native_batch_norm_default_110 = torch.ops.aten.native_batch_norm.default(convolution_default_110, primals_677, primals_673, primals_675, primals_676, True, 0.1, 1e-05);  primals_673 = None
        getitem_330 = native_batch_norm_default_110[0]
        getitem_331 = native_batch_norm_default_110[1]
        getitem_332 = native_batch_norm_default_110[2];  native_batch_norm_default_110 = None
        new_zeros_default_110 = torch.ops.aten.new_zeros.default(convolution_default_110, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_93 = torch.ops.aten.relu_.default(getitem_330);  getitem_330 = None
        convolution_default_111 = torch.ops.aten.convolution.default(relu__default_93, primals_684, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_153 = torch.ops.aten.add_.Tensor(primals_679, 1);  primals_679 = None
        native_batch_norm_default_111 = torch.ops.aten.native_batch_norm.default(convolution_default_111, primals_682, primals_678, primals_680, primals_681, True, 0.1, 1e-05);  primals_678 = None
        getitem_333 = native_batch_norm_default_111[0]
        getitem_334 = native_batch_norm_default_111[1]
        getitem_335 = native_batch_norm_default_111[2];  native_batch_norm_default_111 = None
        new_zeros_default_111 = torch.ops.aten.new_zeros.default(convolution_default_111, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_154 = torch.ops.aten.add_.Tensor(getitem_333, relu__default_92);  getitem_333 = None
        relu__default_94 = torch.ops.aten.relu_.default(add__tensor_154);  add__tensor_154 = None
        convolution_default_112 = torch.ops.aten.convolution.default(relu__default_94, primals_695, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_155 = torch.ops.aten.add_.Tensor(primals_686, 1);  primals_686 = None
        native_batch_norm_default_112 = torch.ops.aten.native_batch_norm.default(convolution_default_112, primals_689, primals_685, primals_687, primals_688, True, 0.1, 1e-05);  primals_685 = None
        getitem_336 = native_batch_norm_default_112[0]
        getitem_337 = native_batch_norm_default_112[1]
        getitem_338 = native_batch_norm_default_112[2];  native_batch_norm_default_112 = None
        new_zeros_default_112 = torch.ops.aten.new_zeros.default(convolution_default_112, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_95 = torch.ops.aten.relu_.default(getitem_336);  getitem_336 = None
        convolution_default_113 = torch.ops.aten.convolution.default(relu__default_95, primals_696, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_156 = torch.ops.aten.add_.Tensor(primals_691, 1);  primals_691 = None
        native_batch_norm_default_113 = torch.ops.aten.native_batch_norm.default(convolution_default_113, primals_694, primals_690, primals_692, primals_693, True, 0.1, 1e-05);  primals_690 = None
        getitem_339 = native_batch_norm_default_113[0]
        getitem_340 = native_batch_norm_default_113[1]
        getitem_341 = native_batch_norm_default_113[2];  native_batch_norm_default_113 = None
        new_zeros_default_113 = torch.ops.aten.new_zeros.default(convolution_default_113, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_157 = torch.ops.aten.add_.Tensor(getitem_339, relu__default_94);  getitem_339 = None
        relu__default_96 = torch.ops.aten.relu_.default(add__tensor_157);  add__tensor_157 = None
        convolution_default_114 = torch.ops.aten.convolution.default(relu_default_9, primals_707, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_158 = torch.ops.aten.add_.Tensor(primals_698, 1);  primals_698 = None
        native_batch_norm_default_114 = torch.ops.aten.native_batch_norm.default(convolution_default_114, primals_701, primals_697, primals_699, primals_700, True, 0.1, 1e-05);  primals_697 = None
        getitem_342 = native_batch_norm_default_114[0]
        getitem_343 = native_batch_norm_default_114[1]
        getitem_344 = native_batch_norm_default_114[2];  native_batch_norm_default_114 = None
        new_zeros_default_114 = torch.ops.aten.new_zeros.default(convolution_default_114, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_97 = torch.ops.aten.relu_.default(getitem_342);  getitem_342 = None
        convolution_default_115 = torch.ops.aten.convolution.default(relu__default_97, primals_708, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_159 = torch.ops.aten.add_.Tensor(primals_703, 1);  primals_703 = None
        native_batch_norm_default_115 = torch.ops.aten.native_batch_norm.default(convolution_default_115, primals_706, primals_702, primals_704, primals_705, True, 0.1, 1e-05);  primals_702 = None
        getitem_345 = native_batch_norm_default_115[0]
        getitem_346 = native_batch_norm_default_115[1]
        getitem_347 = native_batch_norm_default_115[2];  native_batch_norm_default_115 = None
        new_zeros_default_115 = torch.ops.aten.new_zeros.default(convolution_default_115, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_160 = torch.ops.aten.add_.Tensor(getitem_345, relu_default_9);  getitem_345 = None
        relu__default_98 = torch.ops.aten.relu_.default(add__tensor_160);  add__tensor_160 = None
        convolution_default_116 = torch.ops.aten.convolution.default(relu__default_98, primals_719, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_161 = torch.ops.aten.add_.Tensor(primals_710, 1);  primals_710 = None
        native_batch_norm_default_116 = torch.ops.aten.native_batch_norm.default(convolution_default_116, primals_713, primals_709, primals_711, primals_712, True, 0.1, 1e-05);  primals_709 = None
        getitem_348 = native_batch_norm_default_116[0]
        getitem_349 = native_batch_norm_default_116[1]
        getitem_350 = native_batch_norm_default_116[2];  native_batch_norm_default_116 = None
        new_zeros_default_116 = torch.ops.aten.new_zeros.default(convolution_default_116, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_99 = torch.ops.aten.relu_.default(getitem_348);  getitem_348 = None
        convolution_default_117 = torch.ops.aten.convolution.default(relu__default_99, primals_720, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_162 = torch.ops.aten.add_.Tensor(primals_715, 1);  primals_715 = None
        native_batch_norm_default_117 = torch.ops.aten.native_batch_norm.default(convolution_default_117, primals_718, primals_714, primals_716, primals_717, True, 0.1, 1e-05);  primals_714 = None
        getitem_351 = native_batch_norm_default_117[0]
        getitem_352 = native_batch_norm_default_117[1]
        getitem_353 = native_batch_norm_default_117[2];  native_batch_norm_default_117 = None
        new_zeros_default_117 = torch.ops.aten.new_zeros.default(convolution_default_117, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_163 = torch.ops.aten.add_.Tensor(getitem_351, relu__default_98);  getitem_351 = None
        relu__default_100 = torch.ops.aten.relu_.default(add__tensor_163);  add__tensor_163 = None
        convolution_default_118 = torch.ops.aten.convolution.default(relu__default_100, primals_731, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_164 = torch.ops.aten.add_.Tensor(primals_722, 1);  primals_722 = None
        native_batch_norm_default_118 = torch.ops.aten.native_batch_norm.default(convolution_default_118, primals_725, primals_721, primals_723, primals_724, True, 0.1, 1e-05);  primals_721 = None
        getitem_354 = native_batch_norm_default_118[0]
        getitem_355 = native_batch_norm_default_118[1]
        getitem_356 = native_batch_norm_default_118[2];  native_batch_norm_default_118 = None
        new_zeros_default_118 = torch.ops.aten.new_zeros.default(convolution_default_118, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_101 = torch.ops.aten.relu_.default(getitem_354);  getitem_354 = None
        convolution_default_119 = torch.ops.aten.convolution.default(relu__default_101, primals_732, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_165 = torch.ops.aten.add_.Tensor(primals_727, 1);  primals_727 = None
        native_batch_norm_default_119 = torch.ops.aten.native_batch_norm.default(convolution_default_119, primals_730, primals_726, primals_728, primals_729, True, 0.1, 1e-05);  primals_726 = None
        getitem_357 = native_batch_norm_default_119[0]
        getitem_358 = native_batch_norm_default_119[1]
        getitem_359 = native_batch_norm_default_119[2];  native_batch_norm_default_119 = None
        new_zeros_default_119 = torch.ops.aten.new_zeros.default(convolution_default_119, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_166 = torch.ops.aten.add_.Tensor(getitem_357, relu__default_100);  getitem_357 = None
        relu__default_102 = torch.ops.aten.relu_.default(add__tensor_166);  add__tensor_166 = None
        convolution_default_120 = torch.ops.aten.convolution.default(relu__default_102, primals_743, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_167 = torch.ops.aten.add_.Tensor(primals_734, 1);  primals_734 = None
        native_batch_norm_default_120 = torch.ops.aten.native_batch_norm.default(convolution_default_120, primals_737, primals_733, primals_735, primals_736, True, 0.1, 1e-05);  primals_733 = None
        getitem_360 = native_batch_norm_default_120[0]
        getitem_361 = native_batch_norm_default_120[1]
        getitem_362 = native_batch_norm_default_120[2];  native_batch_norm_default_120 = None
        new_zeros_default_120 = torch.ops.aten.new_zeros.default(convolution_default_120, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_103 = torch.ops.aten.relu_.default(getitem_360);  getitem_360 = None
        convolution_default_121 = torch.ops.aten.convolution.default(relu__default_103, primals_744, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_168 = torch.ops.aten.add_.Tensor(primals_739, 1);  primals_739 = None
        native_batch_norm_default_121 = torch.ops.aten.native_batch_norm.default(convolution_default_121, primals_742, primals_738, primals_740, primals_741, True, 0.1, 1e-05);  primals_738 = None
        getitem_363 = native_batch_norm_default_121[0]
        getitem_364 = native_batch_norm_default_121[1]
        getitem_365 = native_batch_norm_default_121[2];  native_batch_norm_default_121 = None
        new_zeros_default_121 = torch.ops.aten.new_zeros.default(convolution_default_121, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_169 = torch.ops.aten.add_.Tensor(getitem_363, relu__default_102);  getitem_363 = None
        relu__default_104 = torch.ops.aten.relu_.default(add__tensor_169);  add__tensor_169 = None
        convolution_default_122 = torch.ops.aten.convolution.default(relu__default_96, primals_1783, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_170 = torch.ops.aten.add_.Tensor(primals_1785, 1);  primals_1785 = None
        native_batch_norm_default_122 = torch.ops.aten.native_batch_norm.default(convolution_default_122, primals_1788, primals_1784, primals_1786, primals_1787, True, 0.1, 1e-05);  primals_1784 = None
        getitem_366 = native_batch_norm_default_122[0]
        getitem_367 = native_batch_norm_default_122[1]
        getitem_368 = native_batch_norm_default_122[2];  native_batch_norm_default_122 = None
        new_zeros_default_122 = torch.ops.aten.new_zeros.default(convolution_default_122, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_7 = torch.ops.aten.upsample_nearest2d.vec(getitem_366, None, [2.0, 2.0]);  getitem_366 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(relu__default_88, upsample_nearest2d_vec_7);  upsample_nearest2d_vec_7 = None
        convolution_default_123 = torch.ops.aten.convolution.default(relu__default_104, primals_1879, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_171 = torch.ops.aten.add_.Tensor(primals_1881, 1);  primals_1881 = None
        native_batch_norm_default_123 = torch.ops.aten.native_batch_norm.default(convolution_default_123, primals_1884, primals_1880, primals_1882, primals_1883, True, 0.1, 1e-05);  primals_1880 = None
        getitem_369 = native_batch_norm_default_123[0]
        getitem_370 = native_batch_norm_default_123[1]
        getitem_371 = native_batch_norm_default_123[2];  native_batch_norm_default_123 = None
        new_zeros_default_123 = torch.ops.aten.new_zeros.default(convolution_default_123, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_8 = torch.ops.aten.upsample_nearest2d.vec(getitem_369, None, [4.0, 4.0]);  getitem_369 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(add_tensor_14, upsample_nearest2d_vec_8);  add_tensor_14 = upsample_nearest2d_vec_8 = None
        relu_default_10 = torch.ops.aten.relu.default(add_tensor_15);  add_tensor_15 = None
        convolution_default_124 = torch.ops.aten.convolution.default(relu__default_88, primals_1633, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_172 = torch.ops.aten.add_.Tensor(primals_1635, 1);  primals_1635 = None
        native_batch_norm_default_124 = torch.ops.aten.native_batch_norm.default(convolution_default_124, primals_1638, primals_1634, primals_1636, primals_1637, True, 0.1, 1e-05);  primals_1634 = None
        getitem_372 = native_batch_norm_default_124[0]
        getitem_373 = native_batch_norm_default_124[1]
        getitem_374 = native_batch_norm_default_124[2];  native_batch_norm_default_124 = None
        new_zeros_default_124 = torch.ops.aten.new_zeros.default(convolution_default_124, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_16 = torch.ops.aten.add.Tensor(getitem_372, relu__default_96);  getitem_372 = None
        convolution_default_125 = torch.ops.aten.convolution.default(relu__default_104, primals_1885, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_173 = torch.ops.aten.add_.Tensor(primals_1887, 1);  primals_1887 = None
        native_batch_norm_default_125 = torch.ops.aten.native_batch_norm.default(convolution_default_125, primals_1890, primals_1886, primals_1888, primals_1889, True, 0.1, 1e-05);  primals_1886 = None
        getitem_375 = native_batch_norm_default_125[0]
        getitem_376 = native_batch_norm_default_125[1]
        getitem_377 = native_batch_norm_default_125[2];  native_batch_norm_default_125 = None
        new_zeros_default_125 = torch.ops.aten.new_zeros.default(convolution_default_125, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_9 = torch.ops.aten.upsample_nearest2d.vec(getitem_375, None, [2.0, 2.0]);  getitem_375 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(add_tensor_16, upsample_nearest2d_vec_9);  add_tensor_16 = upsample_nearest2d_vec_9 = None
        relu_default_11 = torch.ops.aten.relu.default(add_tensor_17);  add_tensor_17 = None
        convolution_default_126 = torch.ops.aten.convolution.default(relu__default_88, primals_1639, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_174 = torch.ops.aten.add_.Tensor(primals_1641, 1);  primals_1641 = None
        native_batch_norm_default_126 = torch.ops.aten.native_batch_norm.default(convolution_default_126, primals_1644, primals_1640, primals_1642, primals_1643, True, 0.1, 1e-05);  primals_1640 = None
        getitem_378 = native_batch_norm_default_126[0]
        getitem_379 = native_batch_norm_default_126[1]
        getitem_380 = native_batch_norm_default_126[2];  native_batch_norm_default_126 = None
        new_zeros_default_126 = torch.ops.aten.new_zeros.default(convolution_default_126, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_12 = torch.ops.aten.relu.default(getitem_378);  getitem_378 = None
        convolution_default_127 = torch.ops.aten.convolution.default(relu_default_12, primals_1645, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_175 = torch.ops.aten.add_.Tensor(primals_1647, 1);  primals_1647 = None
        native_batch_norm_default_127 = torch.ops.aten.native_batch_norm.default(convolution_default_127, primals_1650, primals_1646, primals_1648, primals_1649, True, 0.1, 1e-05);  primals_1646 = None
        getitem_381 = native_batch_norm_default_127[0]
        getitem_382 = native_batch_norm_default_127[1]
        getitem_383 = native_batch_norm_default_127[2];  native_batch_norm_default_127 = None
        new_zeros_default_127 = torch.ops.aten.new_zeros.default(convolution_default_127, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_128 = torch.ops.aten.convolution.default(relu__default_96, primals_1789, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_176 = torch.ops.aten.add_.Tensor(primals_1791, 1);  primals_1791 = None
        native_batch_norm_default_128 = torch.ops.aten.native_batch_norm.default(convolution_default_128, primals_1794, primals_1790, primals_1792, primals_1793, True, 0.1, 1e-05);  primals_1790 = None
        getitem_384 = native_batch_norm_default_128[0]
        getitem_385 = native_batch_norm_default_128[1]
        getitem_386 = native_batch_norm_default_128[2];  native_batch_norm_default_128 = None
        new_zeros_default_128 = torch.ops.aten.new_zeros.default(convolution_default_128, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_18 = torch.ops.aten.add.Tensor(getitem_381, getitem_384);  getitem_381 = getitem_384 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(add_tensor_18, relu__default_104);  add_tensor_18 = None
        relu_default_13 = torch.ops.aten.relu.default(add_tensor_19);  add_tensor_19 = None
        convolution_default_129 = torch.ops.aten.convolution.default(relu_default_10, primals_755, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_177 = torch.ops.aten.add_.Tensor(primals_746, 1);  primals_746 = None
        native_batch_norm_default_129 = torch.ops.aten.native_batch_norm.default(convolution_default_129, primals_749, primals_745, primals_747, primals_748, True, 0.1, 1e-05);  primals_745 = None
        getitem_387 = native_batch_norm_default_129[0]
        getitem_388 = native_batch_norm_default_129[1]
        getitem_389 = native_batch_norm_default_129[2];  native_batch_norm_default_129 = None
        new_zeros_default_129 = torch.ops.aten.new_zeros.default(convolution_default_129, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_105 = torch.ops.aten.relu_.default(getitem_387);  getitem_387 = None
        convolution_default_130 = torch.ops.aten.convolution.default(relu__default_105, primals_756, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_178 = torch.ops.aten.add_.Tensor(primals_751, 1);  primals_751 = None
        native_batch_norm_default_130 = torch.ops.aten.native_batch_norm.default(convolution_default_130, primals_754, primals_750, primals_752, primals_753, True, 0.1, 1e-05);  primals_750 = None
        getitem_390 = native_batch_norm_default_130[0]
        getitem_391 = native_batch_norm_default_130[1]
        getitem_392 = native_batch_norm_default_130[2];  native_batch_norm_default_130 = None
        new_zeros_default_130 = torch.ops.aten.new_zeros.default(convolution_default_130, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_179 = torch.ops.aten.add_.Tensor(getitem_390, relu_default_10);  getitem_390 = None
        relu__default_106 = torch.ops.aten.relu_.default(add__tensor_179);  add__tensor_179 = None
        convolution_default_131 = torch.ops.aten.convolution.default(relu__default_106, primals_767, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_180 = torch.ops.aten.add_.Tensor(primals_758, 1);  primals_758 = None
        native_batch_norm_default_131 = torch.ops.aten.native_batch_norm.default(convolution_default_131, primals_761, primals_757, primals_759, primals_760, True, 0.1, 1e-05);  primals_757 = None
        getitem_393 = native_batch_norm_default_131[0]
        getitem_394 = native_batch_norm_default_131[1]
        getitem_395 = native_batch_norm_default_131[2];  native_batch_norm_default_131 = None
        new_zeros_default_131 = torch.ops.aten.new_zeros.default(convolution_default_131, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_107 = torch.ops.aten.relu_.default(getitem_393);  getitem_393 = None
        convolution_default_132 = torch.ops.aten.convolution.default(relu__default_107, primals_768, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_181 = torch.ops.aten.add_.Tensor(primals_763, 1);  primals_763 = None
        native_batch_norm_default_132 = torch.ops.aten.native_batch_norm.default(convolution_default_132, primals_766, primals_762, primals_764, primals_765, True, 0.1, 1e-05);  primals_762 = None
        getitem_396 = native_batch_norm_default_132[0]
        getitem_397 = native_batch_norm_default_132[1]
        getitem_398 = native_batch_norm_default_132[2];  native_batch_norm_default_132 = None
        new_zeros_default_132 = torch.ops.aten.new_zeros.default(convolution_default_132, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_182 = torch.ops.aten.add_.Tensor(getitem_396, relu__default_106);  getitem_396 = None
        relu__default_108 = torch.ops.aten.relu_.default(add__tensor_182);  add__tensor_182 = None
        convolution_default_133 = torch.ops.aten.convolution.default(relu__default_108, primals_779, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_183 = torch.ops.aten.add_.Tensor(primals_770, 1);  primals_770 = None
        native_batch_norm_default_133 = torch.ops.aten.native_batch_norm.default(convolution_default_133, primals_773, primals_769, primals_771, primals_772, True, 0.1, 1e-05);  primals_769 = None
        getitem_399 = native_batch_norm_default_133[0]
        getitem_400 = native_batch_norm_default_133[1]
        getitem_401 = native_batch_norm_default_133[2];  native_batch_norm_default_133 = None
        new_zeros_default_133 = torch.ops.aten.new_zeros.default(convolution_default_133, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_109 = torch.ops.aten.relu_.default(getitem_399);  getitem_399 = None
        convolution_default_134 = torch.ops.aten.convolution.default(relu__default_109, primals_780, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_184 = torch.ops.aten.add_.Tensor(primals_775, 1);  primals_775 = None
        native_batch_norm_default_134 = torch.ops.aten.native_batch_norm.default(convolution_default_134, primals_778, primals_774, primals_776, primals_777, True, 0.1, 1e-05);  primals_774 = None
        getitem_402 = native_batch_norm_default_134[0]
        getitem_403 = native_batch_norm_default_134[1]
        getitem_404 = native_batch_norm_default_134[2];  native_batch_norm_default_134 = None
        new_zeros_default_134 = torch.ops.aten.new_zeros.default(convolution_default_134, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_185 = torch.ops.aten.add_.Tensor(getitem_402, relu__default_108);  getitem_402 = None
        relu__default_110 = torch.ops.aten.relu_.default(add__tensor_185);  add__tensor_185 = None
        convolution_default_135 = torch.ops.aten.convolution.default(relu__default_110, primals_791, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_186 = torch.ops.aten.add_.Tensor(primals_782, 1);  primals_782 = None
        native_batch_norm_default_135 = torch.ops.aten.native_batch_norm.default(convolution_default_135, primals_785, primals_781, primals_783, primals_784, True, 0.1, 1e-05);  primals_781 = None
        getitem_405 = native_batch_norm_default_135[0]
        getitem_406 = native_batch_norm_default_135[1]
        getitem_407 = native_batch_norm_default_135[2];  native_batch_norm_default_135 = None
        new_zeros_default_135 = torch.ops.aten.new_zeros.default(convolution_default_135, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_111 = torch.ops.aten.relu_.default(getitem_405);  getitem_405 = None
        convolution_default_136 = torch.ops.aten.convolution.default(relu__default_111, primals_792, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_187 = torch.ops.aten.add_.Tensor(primals_787, 1);  primals_787 = None
        native_batch_norm_default_136 = torch.ops.aten.native_batch_norm.default(convolution_default_136, primals_790, primals_786, primals_788, primals_789, True, 0.1, 1e-05);  primals_786 = None
        getitem_408 = native_batch_norm_default_136[0]
        getitem_409 = native_batch_norm_default_136[1]
        getitem_410 = native_batch_norm_default_136[2];  native_batch_norm_default_136 = None
        new_zeros_default_136 = torch.ops.aten.new_zeros.default(convolution_default_136, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_188 = torch.ops.aten.add_.Tensor(getitem_408, relu__default_110);  getitem_408 = None
        relu__default_112 = torch.ops.aten.relu_.default(add__tensor_188);  add__tensor_188 = None
        convolution_default_137 = torch.ops.aten.convolution.default(relu_default_11, primals_803, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_189 = torch.ops.aten.add_.Tensor(primals_794, 1);  primals_794 = None
        native_batch_norm_default_137 = torch.ops.aten.native_batch_norm.default(convolution_default_137, primals_797, primals_793, primals_795, primals_796, True, 0.1, 1e-05);  primals_793 = None
        getitem_411 = native_batch_norm_default_137[0]
        getitem_412 = native_batch_norm_default_137[1]
        getitem_413 = native_batch_norm_default_137[2];  native_batch_norm_default_137 = None
        new_zeros_default_137 = torch.ops.aten.new_zeros.default(convolution_default_137, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_113 = torch.ops.aten.relu_.default(getitem_411);  getitem_411 = None
        convolution_default_138 = torch.ops.aten.convolution.default(relu__default_113, primals_804, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_190 = torch.ops.aten.add_.Tensor(primals_799, 1);  primals_799 = None
        native_batch_norm_default_138 = torch.ops.aten.native_batch_norm.default(convolution_default_138, primals_802, primals_798, primals_800, primals_801, True, 0.1, 1e-05);  primals_798 = None
        getitem_414 = native_batch_norm_default_138[0]
        getitem_415 = native_batch_norm_default_138[1]
        getitem_416 = native_batch_norm_default_138[2];  native_batch_norm_default_138 = None
        new_zeros_default_138 = torch.ops.aten.new_zeros.default(convolution_default_138, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_191 = torch.ops.aten.add_.Tensor(getitem_414, relu_default_11);  getitem_414 = None
        relu__default_114 = torch.ops.aten.relu_.default(add__tensor_191);  add__tensor_191 = None
        convolution_default_139 = torch.ops.aten.convolution.default(relu__default_114, primals_815, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_192 = torch.ops.aten.add_.Tensor(primals_806, 1);  primals_806 = None
        native_batch_norm_default_139 = torch.ops.aten.native_batch_norm.default(convolution_default_139, primals_809, primals_805, primals_807, primals_808, True, 0.1, 1e-05);  primals_805 = None
        getitem_417 = native_batch_norm_default_139[0]
        getitem_418 = native_batch_norm_default_139[1]
        getitem_419 = native_batch_norm_default_139[2];  native_batch_norm_default_139 = None
        new_zeros_default_139 = torch.ops.aten.new_zeros.default(convolution_default_139, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_115 = torch.ops.aten.relu_.default(getitem_417);  getitem_417 = None
        convolution_default_140 = torch.ops.aten.convolution.default(relu__default_115, primals_816, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_193 = torch.ops.aten.add_.Tensor(primals_811, 1);  primals_811 = None
        native_batch_norm_default_140 = torch.ops.aten.native_batch_norm.default(convolution_default_140, primals_814, primals_810, primals_812, primals_813, True, 0.1, 1e-05);  primals_810 = None
        getitem_420 = native_batch_norm_default_140[0]
        getitem_421 = native_batch_norm_default_140[1]
        getitem_422 = native_batch_norm_default_140[2];  native_batch_norm_default_140 = None
        new_zeros_default_140 = torch.ops.aten.new_zeros.default(convolution_default_140, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_194 = torch.ops.aten.add_.Tensor(getitem_420, relu__default_114);  getitem_420 = None
        relu__default_116 = torch.ops.aten.relu_.default(add__tensor_194);  add__tensor_194 = None
        convolution_default_141 = torch.ops.aten.convolution.default(relu__default_116, primals_827, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_195 = torch.ops.aten.add_.Tensor(primals_818, 1);  primals_818 = None
        native_batch_norm_default_141 = torch.ops.aten.native_batch_norm.default(convolution_default_141, primals_821, primals_817, primals_819, primals_820, True, 0.1, 1e-05);  primals_817 = None
        getitem_423 = native_batch_norm_default_141[0]
        getitem_424 = native_batch_norm_default_141[1]
        getitem_425 = native_batch_norm_default_141[2];  native_batch_norm_default_141 = None
        new_zeros_default_141 = torch.ops.aten.new_zeros.default(convolution_default_141, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_117 = torch.ops.aten.relu_.default(getitem_423);  getitem_423 = None
        convolution_default_142 = torch.ops.aten.convolution.default(relu__default_117, primals_828, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_196 = torch.ops.aten.add_.Tensor(primals_823, 1);  primals_823 = None
        native_batch_norm_default_142 = torch.ops.aten.native_batch_norm.default(convolution_default_142, primals_826, primals_822, primals_824, primals_825, True, 0.1, 1e-05);  primals_822 = None
        getitem_426 = native_batch_norm_default_142[0]
        getitem_427 = native_batch_norm_default_142[1]
        getitem_428 = native_batch_norm_default_142[2];  native_batch_norm_default_142 = None
        new_zeros_default_142 = torch.ops.aten.new_zeros.default(convolution_default_142, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_197 = torch.ops.aten.add_.Tensor(getitem_426, relu__default_116);  getitem_426 = None
        relu__default_118 = torch.ops.aten.relu_.default(add__tensor_197);  add__tensor_197 = None
        convolution_default_143 = torch.ops.aten.convolution.default(relu__default_118, primals_839, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_198 = torch.ops.aten.add_.Tensor(primals_830, 1);  primals_830 = None
        native_batch_norm_default_143 = torch.ops.aten.native_batch_norm.default(convolution_default_143, primals_833, primals_829, primals_831, primals_832, True, 0.1, 1e-05);  primals_829 = None
        getitem_429 = native_batch_norm_default_143[0]
        getitem_430 = native_batch_norm_default_143[1]
        getitem_431 = native_batch_norm_default_143[2];  native_batch_norm_default_143 = None
        new_zeros_default_143 = torch.ops.aten.new_zeros.default(convolution_default_143, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_119 = torch.ops.aten.relu_.default(getitem_429);  getitem_429 = None
        convolution_default_144 = torch.ops.aten.convolution.default(relu__default_119, primals_840, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_199 = torch.ops.aten.add_.Tensor(primals_835, 1);  primals_835 = None
        native_batch_norm_default_144 = torch.ops.aten.native_batch_norm.default(convolution_default_144, primals_838, primals_834, primals_836, primals_837, True, 0.1, 1e-05);  primals_834 = None
        getitem_432 = native_batch_norm_default_144[0]
        getitem_433 = native_batch_norm_default_144[1]
        getitem_434 = native_batch_norm_default_144[2];  native_batch_norm_default_144 = None
        new_zeros_default_144 = torch.ops.aten.new_zeros.default(convolution_default_144, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_200 = torch.ops.aten.add_.Tensor(getitem_432, relu__default_118);  getitem_432 = None
        relu__default_120 = torch.ops.aten.relu_.default(add__tensor_200);  add__tensor_200 = None
        convolution_default_145 = torch.ops.aten.convolution.default(relu_default_13, primals_851, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_201 = torch.ops.aten.add_.Tensor(primals_842, 1);  primals_842 = None
        native_batch_norm_default_145 = torch.ops.aten.native_batch_norm.default(convolution_default_145, primals_845, primals_841, primals_843, primals_844, True, 0.1, 1e-05);  primals_841 = None
        getitem_435 = native_batch_norm_default_145[0]
        getitem_436 = native_batch_norm_default_145[1]
        getitem_437 = native_batch_norm_default_145[2];  native_batch_norm_default_145 = None
        new_zeros_default_145 = torch.ops.aten.new_zeros.default(convolution_default_145, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_121 = torch.ops.aten.relu_.default(getitem_435);  getitem_435 = None
        convolution_default_146 = torch.ops.aten.convolution.default(relu__default_121, primals_852, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_202 = torch.ops.aten.add_.Tensor(primals_847, 1);  primals_847 = None
        native_batch_norm_default_146 = torch.ops.aten.native_batch_norm.default(convolution_default_146, primals_850, primals_846, primals_848, primals_849, True, 0.1, 1e-05);  primals_846 = None
        getitem_438 = native_batch_norm_default_146[0]
        getitem_439 = native_batch_norm_default_146[1]
        getitem_440 = native_batch_norm_default_146[2];  native_batch_norm_default_146 = None
        new_zeros_default_146 = torch.ops.aten.new_zeros.default(convolution_default_146, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_203 = torch.ops.aten.add_.Tensor(getitem_438, relu_default_13);  getitem_438 = None
        relu__default_122 = torch.ops.aten.relu_.default(add__tensor_203);  add__tensor_203 = None
        convolution_default_147 = torch.ops.aten.convolution.default(relu__default_122, primals_863, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_204 = torch.ops.aten.add_.Tensor(primals_854, 1);  primals_854 = None
        native_batch_norm_default_147 = torch.ops.aten.native_batch_norm.default(convolution_default_147, primals_857, primals_853, primals_855, primals_856, True, 0.1, 1e-05);  primals_853 = None
        getitem_441 = native_batch_norm_default_147[0]
        getitem_442 = native_batch_norm_default_147[1]
        getitem_443 = native_batch_norm_default_147[2];  native_batch_norm_default_147 = None
        new_zeros_default_147 = torch.ops.aten.new_zeros.default(convolution_default_147, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_123 = torch.ops.aten.relu_.default(getitem_441);  getitem_441 = None
        convolution_default_148 = torch.ops.aten.convolution.default(relu__default_123, primals_864, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_205 = torch.ops.aten.add_.Tensor(primals_859, 1);  primals_859 = None
        native_batch_norm_default_148 = torch.ops.aten.native_batch_norm.default(convolution_default_148, primals_862, primals_858, primals_860, primals_861, True, 0.1, 1e-05);  primals_858 = None
        getitem_444 = native_batch_norm_default_148[0]
        getitem_445 = native_batch_norm_default_148[1]
        getitem_446 = native_batch_norm_default_148[2];  native_batch_norm_default_148 = None
        new_zeros_default_148 = torch.ops.aten.new_zeros.default(convolution_default_148, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_206 = torch.ops.aten.add_.Tensor(getitem_444, relu__default_122);  getitem_444 = None
        relu__default_124 = torch.ops.aten.relu_.default(add__tensor_206);  add__tensor_206 = None
        convolution_default_149 = torch.ops.aten.convolution.default(relu__default_124, primals_875, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_207 = torch.ops.aten.add_.Tensor(primals_866, 1);  primals_866 = None
        native_batch_norm_default_149 = torch.ops.aten.native_batch_norm.default(convolution_default_149, primals_869, primals_865, primals_867, primals_868, True, 0.1, 1e-05);  primals_865 = None
        getitem_447 = native_batch_norm_default_149[0]
        getitem_448 = native_batch_norm_default_149[1]
        getitem_449 = native_batch_norm_default_149[2];  native_batch_norm_default_149 = None
        new_zeros_default_149 = torch.ops.aten.new_zeros.default(convolution_default_149, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_125 = torch.ops.aten.relu_.default(getitem_447);  getitem_447 = None
        convolution_default_150 = torch.ops.aten.convolution.default(relu__default_125, primals_876, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_208 = torch.ops.aten.add_.Tensor(primals_871, 1);  primals_871 = None
        native_batch_norm_default_150 = torch.ops.aten.native_batch_norm.default(convolution_default_150, primals_874, primals_870, primals_872, primals_873, True, 0.1, 1e-05);  primals_870 = None
        getitem_450 = native_batch_norm_default_150[0]
        getitem_451 = native_batch_norm_default_150[1]
        getitem_452 = native_batch_norm_default_150[2];  native_batch_norm_default_150 = None
        new_zeros_default_150 = torch.ops.aten.new_zeros.default(convolution_default_150, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_209 = torch.ops.aten.add_.Tensor(getitem_450, relu__default_124);  getitem_450 = None
        relu__default_126 = torch.ops.aten.relu_.default(add__tensor_209);  add__tensor_209 = None
        convolution_default_151 = torch.ops.aten.convolution.default(relu__default_126, primals_887, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_210 = torch.ops.aten.add_.Tensor(primals_878, 1);  primals_878 = None
        native_batch_norm_default_151 = torch.ops.aten.native_batch_norm.default(convolution_default_151, primals_881, primals_877, primals_879, primals_880, True, 0.1, 1e-05);  primals_877 = None
        getitem_453 = native_batch_norm_default_151[0]
        getitem_454 = native_batch_norm_default_151[1]
        getitem_455 = native_batch_norm_default_151[2];  native_batch_norm_default_151 = None
        new_zeros_default_151 = torch.ops.aten.new_zeros.default(convolution_default_151, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_127 = torch.ops.aten.relu_.default(getitem_453);  getitem_453 = None
        convolution_default_152 = torch.ops.aten.convolution.default(relu__default_127, primals_888, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_211 = torch.ops.aten.add_.Tensor(primals_883, 1);  primals_883 = None
        native_batch_norm_default_152 = torch.ops.aten.native_batch_norm.default(convolution_default_152, primals_886, primals_882, primals_884, primals_885, True, 0.1, 1e-05);  primals_882 = None
        getitem_456 = native_batch_norm_default_152[0]
        getitem_457 = native_batch_norm_default_152[1]
        getitem_458 = native_batch_norm_default_152[2];  native_batch_norm_default_152 = None
        new_zeros_default_152 = torch.ops.aten.new_zeros.default(convolution_default_152, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_212 = torch.ops.aten.add_.Tensor(getitem_456, relu__default_126);  getitem_456 = None
        relu__default_128 = torch.ops.aten.relu_.default(add__tensor_212);  add__tensor_212 = None
        convolution_default_153 = torch.ops.aten.convolution.default(relu__default_120, primals_1795, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_213 = torch.ops.aten.add_.Tensor(primals_1797, 1);  primals_1797 = None
        native_batch_norm_default_153 = torch.ops.aten.native_batch_norm.default(convolution_default_153, primals_1800, primals_1796, primals_1798, primals_1799, True, 0.1, 1e-05);  primals_1796 = None
        getitem_459 = native_batch_norm_default_153[0]
        getitem_460 = native_batch_norm_default_153[1]
        getitem_461 = native_batch_norm_default_153[2];  native_batch_norm_default_153 = None
        new_zeros_default_153 = torch.ops.aten.new_zeros.default(convolution_default_153, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_10 = torch.ops.aten.upsample_nearest2d.vec(getitem_459, None, [2.0, 2.0]);  getitem_459 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(relu__default_112, upsample_nearest2d_vec_10);  upsample_nearest2d_vec_10 = None
        convolution_default_154 = torch.ops.aten.convolution.default(relu__default_128, primals_1891, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_214 = torch.ops.aten.add_.Tensor(primals_1893, 1);  primals_1893 = None
        native_batch_norm_default_154 = torch.ops.aten.native_batch_norm.default(convolution_default_154, primals_1896, primals_1892, primals_1894, primals_1895, True, 0.1, 1e-05);  primals_1892 = None
        getitem_462 = native_batch_norm_default_154[0]
        getitem_463 = native_batch_norm_default_154[1]
        getitem_464 = native_batch_norm_default_154[2];  native_batch_norm_default_154 = None
        new_zeros_default_154 = torch.ops.aten.new_zeros.default(convolution_default_154, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_11 = torch.ops.aten.upsample_nearest2d.vec(getitem_462, None, [4.0, 4.0]);  getitem_462 = None
        add_tensor_21 = torch.ops.aten.add.Tensor(add_tensor_20, upsample_nearest2d_vec_11);  add_tensor_20 = upsample_nearest2d_vec_11 = None
        relu_default_14 = torch.ops.aten.relu.default(add_tensor_21);  add_tensor_21 = None
        convolution_default_155 = torch.ops.aten.convolution.default(relu__default_112, primals_1651, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_215 = torch.ops.aten.add_.Tensor(primals_1653, 1);  primals_1653 = None
        native_batch_norm_default_155 = torch.ops.aten.native_batch_norm.default(convolution_default_155, primals_1656, primals_1652, primals_1654, primals_1655, True, 0.1, 1e-05);  primals_1652 = None
        getitem_465 = native_batch_norm_default_155[0]
        getitem_466 = native_batch_norm_default_155[1]
        getitem_467 = native_batch_norm_default_155[2];  native_batch_norm_default_155 = None
        new_zeros_default_155 = torch.ops.aten.new_zeros.default(convolution_default_155, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_22 = torch.ops.aten.add.Tensor(getitem_465, relu__default_120);  getitem_465 = None
        convolution_default_156 = torch.ops.aten.convolution.default(relu__default_128, primals_1897, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_216 = torch.ops.aten.add_.Tensor(primals_1899, 1);  primals_1899 = None
        native_batch_norm_default_156 = torch.ops.aten.native_batch_norm.default(convolution_default_156, primals_1902, primals_1898, primals_1900, primals_1901, True, 0.1, 1e-05);  primals_1898 = None
        getitem_468 = native_batch_norm_default_156[0]
        getitem_469 = native_batch_norm_default_156[1]
        getitem_470 = native_batch_norm_default_156[2];  native_batch_norm_default_156 = None
        new_zeros_default_156 = torch.ops.aten.new_zeros.default(convolution_default_156, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_12 = torch.ops.aten.upsample_nearest2d.vec(getitem_468, None, [2.0, 2.0]);  getitem_468 = None
        add_tensor_23 = torch.ops.aten.add.Tensor(add_tensor_22, upsample_nearest2d_vec_12);  add_tensor_22 = upsample_nearest2d_vec_12 = None
        relu_default_15 = torch.ops.aten.relu.default(add_tensor_23);  add_tensor_23 = None
        convolution_default_157 = torch.ops.aten.convolution.default(relu__default_112, primals_1657, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_217 = torch.ops.aten.add_.Tensor(primals_1659, 1);  primals_1659 = None
        native_batch_norm_default_157 = torch.ops.aten.native_batch_norm.default(convolution_default_157, primals_1662, primals_1658, primals_1660, primals_1661, True, 0.1, 1e-05);  primals_1658 = None
        getitem_471 = native_batch_norm_default_157[0]
        getitem_472 = native_batch_norm_default_157[1]
        getitem_473 = native_batch_norm_default_157[2];  native_batch_norm_default_157 = None
        new_zeros_default_157 = torch.ops.aten.new_zeros.default(convolution_default_157, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_16 = torch.ops.aten.relu.default(getitem_471);  getitem_471 = None
        convolution_default_158 = torch.ops.aten.convolution.default(relu_default_16, primals_1663, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_218 = torch.ops.aten.add_.Tensor(primals_1665, 1);  primals_1665 = None
        native_batch_norm_default_158 = torch.ops.aten.native_batch_norm.default(convolution_default_158, primals_1668, primals_1664, primals_1666, primals_1667, True, 0.1, 1e-05);  primals_1664 = None
        getitem_474 = native_batch_norm_default_158[0]
        getitem_475 = native_batch_norm_default_158[1]
        getitem_476 = native_batch_norm_default_158[2];  native_batch_norm_default_158 = None
        new_zeros_default_158 = torch.ops.aten.new_zeros.default(convolution_default_158, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_159 = torch.ops.aten.convolution.default(relu__default_120, primals_1681, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_219 = torch.ops.aten.add_.Tensor(primals_1683, 1);  primals_1683 = None
        native_batch_norm_default_159 = torch.ops.aten.native_batch_norm.default(convolution_default_159, primals_1686, primals_1682, primals_1684, primals_1685, True, 0.1, 1e-05);  primals_1682 = None
        getitem_477 = native_batch_norm_default_159[0]
        getitem_478 = native_batch_norm_default_159[1]
        getitem_479 = native_batch_norm_default_159[2];  native_batch_norm_default_159 = None
        new_zeros_default_159 = torch.ops.aten.new_zeros.default(convolution_default_159, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_24 = torch.ops.aten.add.Tensor(getitem_474, getitem_477);  getitem_474 = getitem_477 = None
        add_tensor_25 = torch.ops.aten.add.Tensor(add_tensor_24, relu__default_128);  add_tensor_24 = None
        relu_default_17 = torch.ops.aten.relu.default(add_tensor_25);  add_tensor_25 = None
        convolution_default_160 = torch.ops.aten.convolution.default(relu_default_17, primals_1483, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_220 = torch.ops.aten.add_.Tensor(primals_1485, 1);  primals_1485 = None
        native_batch_norm_default_160 = torch.ops.aten.native_batch_norm.default(convolution_default_160, primals_1488, primals_1484, primals_1486, primals_1487, True, 0.1, 1e-05);  primals_1484 = None
        getitem_480 = native_batch_norm_default_160[0]
        getitem_481 = native_batch_norm_default_160[1]
        getitem_482 = native_batch_norm_default_160[2];  native_batch_norm_default_160 = None
        new_zeros_default_160 = torch.ops.aten.new_zeros.default(convolution_default_160, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_129 = torch.ops.aten.relu_.default(getitem_480);  getitem_480 = None
        convolution_default_161 = torch.ops.aten.convolution.default(relu_default_14, primals_899, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_221 = torch.ops.aten.add_.Tensor(primals_890, 1);  primals_890 = None
        native_batch_norm_default_161 = torch.ops.aten.native_batch_norm.default(convolution_default_161, primals_893, primals_889, primals_891, primals_892, True, 0.1, 1e-05);  primals_889 = None
        getitem_483 = native_batch_norm_default_161[0]
        getitem_484 = native_batch_norm_default_161[1]
        getitem_485 = native_batch_norm_default_161[2];  native_batch_norm_default_161 = None
        new_zeros_default_161 = torch.ops.aten.new_zeros.default(convolution_default_161, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_130 = torch.ops.aten.relu_.default(getitem_483);  getitem_483 = None
        convolution_default_162 = torch.ops.aten.convolution.default(relu__default_130, primals_900, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_222 = torch.ops.aten.add_.Tensor(primals_895, 1);  primals_895 = None
        native_batch_norm_default_162 = torch.ops.aten.native_batch_norm.default(convolution_default_162, primals_898, primals_894, primals_896, primals_897, True, 0.1, 1e-05);  primals_894 = None
        getitem_486 = native_batch_norm_default_162[0]
        getitem_487 = native_batch_norm_default_162[1]
        getitem_488 = native_batch_norm_default_162[2];  native_batch_norm_default_162 = None
        new_zeros_default_162 = torch.ops.aten.new_zeros.default(convolution_default_162, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_223 = torch.ops.aten.add_.Tensor(getitem_486, relu_default_14);  getitem_486 = None
        relu__default_131 = torch.ops.aten.relu_.default(add__tensor_223);  add__tensor_223 = None
        convolution_default_163 = torch.ops.aten.convolution.default(relu__default_131, primals_911, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_224 = torch.ops.aten.add_.Tensor(primals_902, 1);  primals_902 = None
        native_batch_norm_default_163 = torch.ops.aten.native_batch_norm.default(convolution_default_163, primals_905, primals_901, primals_903, primals_904, True, 0.1, 1e-05);  primals_901 = None
        getitem_489 = native_batch_norm_default_163[0]
        getitem_490 = native_batch_norm_default_163[1]
        getitem_491 = native_batch_norm_default_163[2];  native_batch_norm_default_163 = None
        new_zeros_default_163 = torch.ops.aten.new_zeros.default(convolution_default_163, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_132 = torch.ops.aten.relu_.default(getitem_489);  getitem_489 = None
        convolution_default_164 = torch.ops.aten.convolution.default(relu__default_132, primals_912, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_225 = torch.ops.aten.add_.Tensor(primals_907, 1);  primals_907 = None
        native_batch_norm_default_164 = torch.ops.aten.native_batch_norm.default(convolution_default_164, primals_910, primals_906, primals_908, primals_909, True, 0.1, 1e-05);  primals_906 = None
        getitem_492 = native_batch_norm_default_164[0]
        getitem_493 = native_batch_norm_default_164[1]
        getitem_494 = native_batch_norm_default_164[2];  native_batch_norm_default_164 = None
        new_zeros_default_164 = torch.ops.aten.new_zeros.default(convolution_default_164, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_226 = torch.ops.aten.add_.Tensor(getitem_492, relu__default_131);  getitem_492 = None
        relu__default_133 = torch.ops.aten.relu_.default(add__tensor_226);  add__tensor_226 = None
        convolution_default_165 = torch.ops.aten.convolution.default(relu__default_133, primals_923, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_227 = torch.ops.aten.add_.Tensor(primals_914, 1);  primals_914 = None
        native_batch_norm_default_165 = torch.ops.aten.native_batch_norm.default(convolution_default_165, primals_917, primals_913, primals_915, primals_916, True, 0.1, 1e-05);  primals_913 = None
        getitem_495 = native_batch_norm_default_165[0]
        getitem_496 = native_batch_norm_default_165[1]
        getitem_497 = native_batch_norm_default_165[2];  native_batch_norm_default_165 = None
        new_zeros_default_165 = torch.ops.aten.new_zeros.default(convolution_default_165, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_134 = torch.ops.aten.relu_.default(getitem_495);  getitem_495 = None
        convolution_default_166 = torch.ops.aten.convolution.default(relu__default_134, primals_924, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_228 = torch.ops.aten.add_.Tensor(primals_919, 1);  primals_919 = None
        native_batch_norm_default_166 = torch.ops.aten.native_batch_norm.default(convolution_default_166, primals_922, primals_918, primals_920, primals_921, True, 0.1, 1e-05);  primals_918 = None
        getitem_498 = native_batch_norm_default_166[0]
        getitem_499 = native_batch_norm_default_166[1]
        getitem_500 = native_batch_norm_default_166[2];  native_batch_norm_default_166 = None
        new_zeros_default_166 = torch.ops.aten.new_zeros.default(convolution_default_166, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_229 = torch.ops.aten.add_.Tensor(getitem_498, relu__default_133);  getitem_498 = None
        relu__default_135 = torch.ops.aten.relu_.default(add__tensor_229);  add__tensor_229 = None
        convolution_default_167 = torch.ops.aten.convolution.default(relu__default_135, primals_935, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_230 = torch.ops.aten.add_.Tensor(primals_926, 1);  primals_926 = None
        native_batch_norm_default_167 = torch.ops.aten.native_batch_norm.default(convolution_default_167, primals_929, primals_925, primals_927, primals_928, True, 0.1, 1e-05);  primals_925 = None
        getitem_501 = native_batch_norm_default_167[0]
        getitem_502 = native_batch_norm_default_167[1]
        getitem_503 = native_batch_norm_default_167[2];  native_batch_norm_default_167 = None
        new_zeros_default_167 = torch.ops.aten.new_zeros.default(convolution_default_167, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_136 = torch.ops.aten.relu_.default(getitem_501);  getitem_501 = None
        convolution_default_168 = torch.ops.aten.convolution.default(relu__default_136, primals_936, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_231 = torch.ops.aten.add_.Tensor(primals_931, 1);  primals_931 = None
        native_batch_norm_default_168 = torch.ops.aten.native_batch_norm.default(convolution_default_168, primals_934, primals_930, primals_932, primals_933, True, 0.1, 1e-05);  primals_930 = None
        getitem_504 = native_batch_norm_default_168[0]
        getitem_505 = native_batch_norm_default_168[1]
        getitem_506 = native_batch_norm_default_168[2];  native_batch_norm_default_168 = None
        new_zeros_default_168 = torch.ops.aten.new_zeros.default(convolution_default_168, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_232 = torch.ops.aten.add_.Tensor(getitem_504, relu__default_135);  getitem_504 = None
        relu__default_137 = torch.ops.aten.relu_.default(add__tensor_232);  add__tensor_232 = None
        convolution_default_169 = torch.ops.aten.convolution.default(relu_default_15, primals_947, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_233 = torch.ops.aten.add_.Tensor(primals_938, 1);  primals_938 = None
        native_batch_norm_default_169 = torch.ops.aten.native_batch_norm.default(convolution_default_169, primals_941, primals_937, primals_939, primals_940, True, 0.1, 1e-05);  primals_937 = None
        getitem_507 = native_batch_norm_default_169[0]
        getitem_508 = native_batch_norm_default_169[1]
        getitem_509 = native_batch_norm_default_169[2];  native_batch_norm_default_169 = None
        new_zeros_default_169 = torch.ops.aten.new_zeros.default(convolution_default_169, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_138 = torch.ops.aten.relu_.default(getitem_507);  getitem_507 = None
        convolution_default_170 = torch.ops.aten.convolution.default(relu__default_138, primals_948, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_234 = torch.ops.aten.add_.Tensor(primals_943, 1);  primals_943 = None
        native_batch_norm_default_170 = torch.ops.aten.native_batch_norm.default(convolution_default_170, primals_946, primals_942, primals_944, primals_945, True, 0.1, 1e-05);  primals_942 = None
        getitem_510 = native_batch_norm_default_170[0]
        getitem_511 = native_batch_norm_default_170[1]
        getitem_512 = native_batch_norm_default_170[2];  native_batch_norm_default_170 = None
        new_zeros_default_170 = torch.ops.aten.new_zeros.default(convolution_default_170, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_235 = torch.ops.aten.add_.Tensor(getitem_510, relu_default_15);  getitem_510 = None
        relu__default_139 = torch.ops.aten.relu_.default(add__tensor_235);  add__tensor_235 = None
        convolution_default_171 = torch.ops.aten.convolution.default(relu__default_139, primals_959, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_236 = torch.ops.aten.add_.Tensor(primals_950, 1);  primals_950 = None
        native_batch_norm_default_171 = torch.ops.aten.native_batch_norm.default(convolution_default_171, primals_953, primals_949, primals_951, primals_952, True, 0.1, 1e-05);  primals_949 = None
        getitem_513 = native_batch_norm_default_171[0]
        getitem_514 = native_batch_norm_default_171[1]
        getitem_515 = native_batch_norm_default_171[2];  native_batch_norm_default_171 = None
        new_zeros_default_171 = torch.ops.aten.new_zeros.default(convolution_default_171, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_140 = torch.ops.aten.relu_.default(getitem_513);  getitem_513 = None
        convolution_default_172 = torch.ops.aten.convolution.default(relu__default_140, primals_960, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_237 = torch.ops.aten.add_.Tensor(primals_955, 1);  primals_955 = None
        native_batch_norm_default_172 = torch.ops.aten.native_batch_norm.default(convolution_default_172, primals_958, primals_954, primals_956, primals_957, True, 0.1, 1e-05);  primals_954 = None
        getitem_516 = native_batch_norm_default_172[0]
        getitem_517 = native_batch_norm_default_172[1]
        getitem_518 = native_batch_norm_default_172[2];  native_batch_norm_default_172 = None
        new_zeros_default_172 = torch.ops.aten.new_zeros.default(convolution_default_172, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_238 = torch.ops.aten.add_.Tensor(getitem_516, relu__default_139);  getitem_516 = None
        relu__default_141 = torch.ops.aten.relu_.default(add__tensor_238);  add__tensor_238 = None
        convolution_default_173 = torch.ops.aten.convolution.default(relu__default_141, primals_971, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_239 = torch.ops.aten.add_.Tensor(primals_962, 1);  primals_962 = None
        native_batch_norm_default_173 = torch.ops.aten.native_batch_norm.default(convolution_default_173, primals_965, primals_961, primals_963, primals_964, True, 0.1, 1e-05);  primals_961 = None
        getitem_519 = native_batch_norm_default_173[0]
        getitem_520 = native_batch_norm_default_173[1]
        getitem_521 = native_batch_norm_default_173[2];  native_batch_norm_default_173 = None
        new_zeros_default_173 = torch.ops.aten.new_zeros.default(convolution_default_173, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_142 = torch.ops.aten.relu_.default(getitem_519);  getitem_519 = None
        convolution_default_174 = torch.ops.aten.convolution.default(relu__default_142, primals_972, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_240 = torch.ops.aten.add_.Tensor(primals_967, 1);  primals_967 = None
        native_batch_norm_default_174 = torch.ops.aten.native_batch_norm.default(convolution_default_174, primals_970, primals_966, primals_968, primals_969, True, 0.1, 1e-05);  primals_966 = None
        getitem_522 = native_batch_norm_default_174[0]
        getitem_523 = native_batch_norm_default_174[1]
        getitem_524 = native_batch_norm_default_174[2];  native_batch_norm_default_174 = None
        new_zeros_default_174 = torch.ops.aten.new_zeros.default(convolution_default_174, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_241 = torch.ops.aten.add_.Tensor(getitem_522, relu__default_141);  getitem_522 = None
        relu__default_143 = torch.ops.aten.relu_.default(add__tensor_241);  add__tensor_241 = None
        convolution_default_175 = torch.ops.aten.convolution.default(relu__default_143, primals_983, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_242 = torch.ops.aten.add_.Tensor(primals_974, 1);  primals_974 = None
        native_batch_norm_default_175 = torch.ops.aten.native_batch_norm.default(convolution_default_175, primals_977, primals_973, primals_975, primals_976, True, 0.1, 1e-05);  primals_973 = None
        getitem_525 = native_batch_norm_default_175[0]
        getitem_526 = native_batch_norm_default_175[1]
        getitem_527 = native_batch_norm_default_175[2];  native_batch_norm_default_175 = None
        new_zeros_default_175 = torch.ops.aten.new_zeros.default(convolution_default_175, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_144 = torch.ops.aten.relu_.default(getitem_525);  getitem_525 = None
        convolution_default_176 = torch.ops.aten.convolution.default(relu__default_144, primals_984, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_243 = torch.ops.aten.add_.Tensor(primals_979, 1);  primals_979 = None
        native_batch_norm_default_176 = torch.ops.aten.native_batch_norm.default(convolution_default_176, primals_982, primals_978, primals_980, primals_981, True, 0.1, 1e-05);  primals_978 = None
        getitem_528 = native_batch_norm_default_176[0]
        getitem_529 = native_batch_norm_default_176[1]
        getitem_530 = native_batch_norm_default_176[2];  native_batch_norm_default_176 = None
        new_zeros_default_176 = torch.ops.aten.new_zeros.default(convolution_default_176, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_244 = torch.ops.aten.add_.Tensor(getitem_528, relu__default_143);  getitem_528 = None
        relu__default_145 = torch.ops.aten.relu_.default(add__tensor_244);  add__tensor_244 = None
        convolution_default_177 = torch.ops.aten.convolution.default(relu_default_17, primals_995, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_245 = torch.ops.aten.add_.Tensor(primals_986, 1);  primals_986 = None
        native_batch_norm_default_177 = torch.ops.aten.native_batch_norm.default(convolution_default_177, primals_989, primals_985, primals_987, primals_988, True, 0.1, 1e-05);  primals_985 = None
        getitem_531 = native_batch_norm_default_177[0]
        getitem_532 = native_batch_norm_default_177[1]
        getitem_533 = native_batch_norm_default_177[2];  native_batch_norm_default_177 = None
        new_zeros_default_177 = torch.ops.aten.new_zeros.default(convolution_default_177, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_146 = torch.ops.aten.relu_.default(getitem_531);  getitem_531 = None
        convolution_default_178 = torch.ops.aten.convolution.default(relu__default_146, primals_996, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_246 = torch.ops.aten.add_.Tensor(primals_991, 1);  primals_991 = None
        native_batch_norm_default_178 = torch.ops.aten.native_batch_norm.default(convolution_default_178, primals_994, primals_990, primals_992, primals_993, True, 0.1, 1e-05);  primals_990 = None
        getitem_534 = native_batch_norm_default_178[0]
        getitem_535 = native_batch_norm_default_178[1]
        getitem_536 = native_batch_norm_default_178[2];  native_batch_norm_default_178 = None
        new_zeros_default_178 = torch.ops.aten.new_zeros.default(convolution_default_178, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_247 = torch.ops.aten.add_.Tensor(getitem_534, relu_default_17);  getitem_534 = None
        relu__default_147 = torch.ops.aten.relu_.default(add__tensor_247);  add__tensor_247 = None
        convolution_default_179 = torch.ops.aten.convolution.default(relu__default_147, primals_1007, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_248 = torch.ops.aten.add_.Tensor(primals_998, 1);  primals_998 = None
        native_batch_norm_default_179 = torch.ops.aten.native_batch_norm.default(convolution_default_179, primals_1001, primals_997, primals_999, primals_1000, True, 0.1, 1e-05);  primals_997 = None
        getitem_537 = native_batch_norm_default_179[0]
        getitem_538 = native_batch_norm_default_179[1]
        getitem_539 = native_batch_norm_default_179[2];  native_batch_norm_default_179 = None
        new_zeros_default_179 = torch.ops.aten.new_zeros.default(convolution_default_179, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_148 = torch.ops.aten.relu_.default(getitem_537);  getitem_537 = None
        convolution_default_180 = torch.ops.aten.convolution.default(relu__default_148, primals_1008, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_249 = torch.ops.aten.add_.Tensor(primals_1003, 1);  primals_1003 = None
        native_batch_norm_default_180 = torch.ops.aten.native_batch_norm.default(convolution_default_180, primals_1006, primals_1002, primals_1004, primals_1005, True, 0.1, 1e-05);  primals_1002 = None
        getitem_540 = native_batch_norm_default_180[0]
        getitem_541 = native_batch_norm_default_180[1]
        getitem_542 = native_batch_norm_default_180[2];  native_batch_norm_default_180 = None
        new_zeros_default_180 = torch.ops.aten.new_zeros.default(convolution_default_180, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_250 = torch.ops.aten.add_.Tensor(getitem_540, relu__default_147);  getitem_540 = None
        relu__default_149 = torch.ops.aten.relu_.default(add__tensor_250);  add__tensor_250 = None
        convolution_default_181 = torch.ops.aten.convolution.default(relu__default_149, primals_1019, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_251 = torch.ops.aten.add_.Tensor(primals_1010, 1);  primals_1010 = None
        native_batch_norm_default_181 = torch.ops.aten.native_batch_norm.default(convolution_default_181, primals_1013, primals_1009, primals_1011, primals_1012, True, 0.1, 1e-05);  primals_1009 = None
        getitem_543 = native_batch_norm_default_181[0]
        getitem_544 = native_batch_norm_default_181[1]
        getitem_545 = native_batch_norm_default_181[2];  native_batch_norm_default_181 = None
        new_zeros_default_181 = torch.ops.aten.new_zeros.default(convolution_default_181, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_150 = torch.ops.aten.relu_.default(getitem_543);  getitem_543 = None
        convolution_default_182 = torch.ops.aten.convolution.default(relu__default_150, primals_1020, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_252 = torch.ops.aten.add_.Tensor(primals_1015, 1);  primals_1015 = None
        native_batch_norm_default_182 = torch.ops.aten.native_batch_norm.default(convolution_default_182, primals_1018, primals_1014, primals_1016, primals_1017, True, 0.1, 1e-05);  primals_1014 = None
        getitem_546 = native_batch_norm_default_182[0]
        getitem_547 = native_batch_norm_default_182[1]
        getitem_548 = native_batch_norm_default_182[2];  native_batch_norm_default_182 = None
        new_zeros_default_182 = torch.ops.aten.new_zeros.default(convolution_default_182, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_253 = torch.ops.aten.add_.Tensor(getitem_546, relu__default_149);  getitem_546 = None
        relu__default_151 = torch.ops.aten.relu_.default(add__tensor_253);  add__tensor_253 = None
        convolution_default_183 = torch.ops.aten.convolution.default(relu__default_151, primals_1031, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_254 = torch.ops.aten.add_.Tensor(primals_1022, 1);  primals_1022 = None
        native_batch_norm_default_183 = torch.ops.aten.native_batch_norm.default(convolution_default_183, primals_1025, primals_1021, primals_1023, primals_1024, True, 0.1, 1e-05);  primals_1021 = None
        getitem_549 = native_batch_norm_default_183[0]
        getitem_550 = native_batch_norm_default_183[1]
        getitem_551 = native_batch_norm_default_183[2];  native_batch_norm_default_183 = None
        new_zeros_default_183 = torch.ops.aten.new_zeros.default(convolution_default_183, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_152 = torch.ops.aten.relu_.default(getitem_549);  getitem_549 = None
        convolution_default_184 = torch.ops.aten.convolution.default(relu__default_152, primals_1032, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_255 = torch.ops.aten.add_.Tensor(primals_1027, 1);  primals_1027 = None
        native_batch_norm_default_184 = torch.ops.aten.native_batch_norm.default(convolution_default_184, primals_1030, primals_1026, primals_1028, primals_1029, True, 0.1, 1e-05);  primals_1026 = None
        getitem_552 = native_batch_norm_default_184[0]
        getitem_553 = native_batch_norm_default_184[1]
        getitem_554 = native_batch_norm_default_184[2];  native_batch_norm_default_184 = None
        new_zeros_default_184 = torch.ops.aten.new_zeros.default(convolution_default_184, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_256 = torch.ops.aten.add_.Tensor(getitem_552, relu__default_151);  getitem_552 = None
        relu__default_153 = torch.ops.aten.relu_.default(add__tensor_256);  add__tensor_256 = None
        convolution_default_185 = torch.ops.aten.convolution.default(relu__default_129, primals_1043, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_257 = torch.ops.aten.add_.Tensor(primals_1034, 1);  primals_1034 = None
        native_batch_norm_default_185 = torch.ops.aten.native_batch_norm.default(convolution_default_185, primals_1037, primals_1033, primals_1035, primals_1036, True, 0.1, 1e-05);  primals_1033 = None
        getitem_555 = native_batch_norm_default_185[0]
        getitem_556 = native_batch_norm_default_185[1]
        getitem_557 = native_batch_norm_default_185[2];  native_batch_norm_default_185 = None
        new_zeros_default_185 = torch.ops.aten.new_zeros.default(convolution_default_185, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_154 = torch.ops.aten.relu_.default(getitem_555);  getitem_555 = None
        convolution_default_186 = torch.ops.aten.convolution.default(relu__default_154, primals_1044, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_258 = torch.ops.aten.add_.Tensor(primals_1039, 1);  primals_1039 = None
        native_batch_norm_default_186 = torch.ops.aten.native_batch_norm.default(convolution_default_186, primals_1042, primals_1038, primals_1040, primals_1041, True, 0.1, 1e-05);  primals_1038 = None
        getitem_558 = native_batch_norm_default_186[0]
        getitem_559 = native_batch_norm_default_186[1]
        getitem_560 = native_batch_norm_default_186[2];  native_batch_norm_default_186 = None
        new_zeros_default_186 = torch.ops.aten.new_zeros.default(convolution_default_186, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_259 = torch.ops.aten.add_.Tensor(getitem_558, relu__default_129);  getitem_558 = None
        relu__default_155 = torch.ops.aten.relu_.default(add__tensor_259);  add__tensor_259 = None
        convolution_default_187 = torch.ops.aten.convolution.default(relu__default_155, primals_1055, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_260 = torch.ops.aten.add_.Tensor(primals_1046, 1);  primals_1046 = None
        native_batch_norm_default_187 = torch.ops.aten.native_batch_norm.default(convolution_default_187, primals_1049, primals_1045, primals_1047, primals_1048, True, 0.1, 1e-05);  primals_1045 = None
        getitem_561 = native_batch_norm_default_187[0]
        getitem_562 = native_batch_norm_default_187[1]
        getitem_563 = native_batch_norm_default_187[2];  native_batch_norm_default_187 = None
        new_zeros_default_187 = torch.ops.aten.new_zeros.default(convolution_default_187, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_156 = torch.ops.aten.relu_.default(getitem_561);  getitem_561 = None
        convolution_default_188 = torch.ops.aten.convolution.default(relu__default_156, primals_1056, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_261 = torch.ops.aten.add_.Tensor(primals_1051, 1);  primals_1051 = None
        native_batch_norm_default_188 = torch.ops.aten.native_batch_norm.default(convolution_default_188, primals_1054, primals_1050, primals_1052, primals_1053, True, 0.1, 1e-05);  primals_1050 = None
        getitem_564 = native_batch_norm_default_188[0]
        getitem_565 = native_batch_norm_default_188[1]
        getitem_566 = native_batch_norm_default_188[2];  native_batch_norm_default_188 = None
        new_zeros_default_188 = torch.ops.aten.new_zeros.default(convolution_default_188, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_262 = torch.ops.aten.add_.Tensor(getitem_564, relu__default_155);  getitem_564 = None
        relu__default_157 = torch.ops.aten.relu_.default(add__tensor_262);  add__tensor_262 = None
        convolution_default_189 = torch.ops.aten.convolution.default(relu__default_157, primals_1067, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_263 = torch.ops.aten.add_.Tensor(primals_1058, 1);  primals_1058 = None
        native_batch_norm_default_189 = torch.ops.aten.native_batch_norm.default(convolution_default_189, primals_1061, primals_1057, primals_1059, primals_1060, True, 0.1, 1e-05);  primals_1057 = None
        getitem_567 = native_batch_norm_default_189[0]
        getitem_568 = native_batch_norm_default_189[1]
        getitem_569 = native_batch_norm_default_189[2];  native_batch_norm_default_189 = None
        new_zeros_default_189 = torch.ops.aten.new_zeros.default(convolution_default_189, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_158 = torch.ops.aten.relu_.default(getitem_567);  getitem_567 = None
        convolution_default_190 = torch.ops.aten.convolution.default(relu__default_158, primals_1068, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_264 = torch.ops.aten.add_.Tensor(primals_1063, 1);  primals_1063 = None
        native_batch_norm_default_190 = torch.ops.aten.native_batch_norm.default(convolution_default_190, primals_1066, primals_1062, primals_1064, primals_1065, True, 0.1, 1e-05);  primals_1062 = None
        getitem_570 = native_batch_norm_default_190[0]
        getitem_571 = native_batch_norm_default_190[1]
        getitem_572 = native_batch_norm_default_190[2];  native_batch_norm_default_190 = None
        new_zeros_default_190 = torch.ops.aten.new_zeros.default(convolution_default_190, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_265 = torch.ops.aten.add_.Tensor(getitem_570, relu__default_157);  getitem_570 = None
        relu__default_159 = torch.ops.aten.relu_.default(add__tensor_265);  add__tensor_265 = None
        convolution_default_191 = torch.ops.aten.convolution.default(relu__default_159, primals_1079, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_266 = torch.ops.aten.add_.Tensor(primals_1070, 1);  primals_1070 = None
        native_batch_norm_default_191 = torch.ops.aten.native_batch_norm.default(convolution_default_191, primals_1073, primals_1069, primals_1071, primals_1072, True, 0.1, 1e-05);  primals_1069 = None
        getitem_573 = native_batch_norm_default_191[0]
        getitem_574 = native_batch_norm_default_191[1]
        getitem_575 = native_batch_norm_default_191[2];  native_batch_norm_default_191 = None
        new_zeros_default_191 = torch.ops.aten.new_zeros.default(convolution_default_191, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_160 = torch.ops.aten.relu_.default(getitem_573);  getitem_573 = None
        convolution_default_192 = torch.ops.aten.convolution.default(relu__default_160, primals_1080, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_267 = torch.ops.aten.add_.Tensor(primals_1075, 1);  primals_1075 = None
        native_batch_norm_default_192 = torch.ops.aten.native_batch_norm.default(convolution_default_192, primals_1078, primals_1074, primals_1076, primals_1077, True, 0.1, 1e-05);  primals_1074 = None
        getitem_576 = native_batch_norm_default_192[0]
        getitem_577 = native_batch_norm_default_192[1]
        getitem_578 = native_batch_norm_default_192[2];  native_batch_norm_default_192 = None
        new_zeros_default_192 = torch.ops.aten.new_zeros.default(convolution_default_192, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_268 = torch.ops.aten.add_.Tensor(getitem_576, relu__default_159);  getitem_576 = None
        relu__default_161 = torch.ops.aten.relu_.default(add__tensor_268);  add__tensor_268 = None
        convolution_default_193 = torch.ops.aten.convolution.default(relu__default_145, primals_1687, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_269 = torch.ops.aten.add_.Tensor(primals_1689, 1);  primals_1689 = None
        native_batch_norm_default_193 = torch.ops.aten.native_batch_norm.default(convolution_default_193, primals_1692, primals_1688, primals_1690, primals_1691, True, 0.1, 1e-05);  primals_1688 = None
        getitem_579 = native_batch_norm_default_193[0]
        getitem_580 = native_batch_norm_default_193[1]
        getitem_581 = native_batch_norm_default_193[2];  native_batch_norm_default_193 = None
        new_zeros_default_193 = torch.ops.aten.new_zeros.default(convolution_default_193, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_13 = torch.ops.aten.upsample_nearest2d.vec(getitem_579, None, [2.0, 2.0]);  getitem_579 = None
        add_tensor_26 = torch.ops.aten.add.Tensor(relu__default_137, upsample_nearest2d_vec_13);  upsample_nearest2d_vec_13 = None
        convolution_default_194 = torch.ops.aten.convolution.default(relu__default_153, primals_1807, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_270 = torch.ops.aten.add_.Tensor(primals_1809, 1);  primals_1809 = None
        native_batch_norm_default_194 = torch.ops.aten.native_batch_norm.default(convolution_default_194, primals_1812, primals_1808, primals_1810, primals_1811, True, 0.1, 1e-05);  primals_1808 = None
        getitem_582 = native_batch_norm_default_194[0]
        getitem_583 = native_batch_norm_default_194[1]
        getitem_584 = native_batch_norm_default_194[2];  native_batch_norm_default_194 = None
        new_zeros_default_194 = torch.ops.aten.new_zeros.default(convolution_default_194, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_14 = torch.ops.aten.upsample_nearest2d.vec(getitem_582, None, [4.0, 4.0]);  getitem_582 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(add_tensor_26, upsample_nearest2d_vec_14);  add_tensor_26 = upsample_nearest2d_vec_14 = None
        convolution_default_195 = torch.ops.aten.convolution.default(relu__default_161, primals_1903, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_271 = torch.ops.aten.add_.Tensor(primals_1905, 1);  primals_1905 = None
        native_batch_norm_default_195 = torch.ops.aten.native_batch_norm.default(convolution_default_195, primals_1908, primals_1904, primals_1906, primals_1907, True, 0.1, 1e-05);  primals_1904 = None
        getitem_585 = native_batch_norm_default_195[0]
        getitem_586 = native_batch_norm_default_195[1]
        getitem_587 = native_batch_norm_default_195[2];  native_batch_norm_default_195 = None
        new_zeros_default_195 = torch.ops.aten.new_zeros.default(convolution_default_195, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_15 = torch.ops.aten.upsample_nearest2d.vec(getitem_585, None, [8.0, 8.0]);  getitem_585 = None
        add_tensor_28 = torch.ops.aten.add.Tensor(add_tensor_27, upsample_nearest2d_vec_15);  add_tensor_27 = upsample_nearest2d_vec_15 = None
        relu_default_18 = torch.ops.aten.relu.default(add_tensor_28);  add_tensor_28 = None
        convolution_default_196 = torch.ops.aten.convolution.default(relu__default_137, primals_1669, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_272 = torch.ops.aten.add_.Tensor(primals_1671, 1);  primals_1671 = None
        native_batch_norm_default_196 = torch.ops.aten.native_batch_norm.default(convolution_default_196, primals_1674, primals_1670, primals_1672, primals_1673, True, 0.1, 1e-05);  primals_1670 = None
        getitem_588 = native_batch_norm_default_196[0]
        getitem_589 = native_batch_norm_default_196[1]
        getitem_590 = native_batch_norm_default_196[2];  native_batch_norm_default_196 = None
        new_zeros_default_196 = torch.ops.aten.new_zeros.default(convolution_default_196, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_29 = torch.ops.aten.add.Tensor(getitem_588, relu__default_145);  getitem_588 = None
        convolution_default_197 = torch.ops.aten.convolution.default(relu__default_153, primals_1813, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_273 = torch.ops.aten.add_.Tensor(primals_1815, 1);  primals_1815 = None
        native_batch_norm_default_197 = torch.ops.aten.native_batch_norm.default(convolution_default_197, primals_1818, primals_1814, primals_1816, primals_1817, True, 0.1, 1e-05);  primals_1814 = None
        getitem_591 = native_batch_norm_default_197[0]
        getitem_592 = native_batch_norm_default_197[1]
        getitem_593 = native_batch_norm_default_197[2];  native_batch_norm_default_197 = None
        new_zeros_default_197 = torch.ops.aten.new_zeros.default(convolution_default_197, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_16 = torch.ops.aten.upsample_nearest2d.vec(getitem_591, None, [2.0, 2.0]);  getitem_591 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(add_tensor_29, upsample_nearest2d_vec_16);  add_tensor_29 = upsample_nearest2d_vec_16 = None
        convolution_default_198 = torch.ops.aten.convolution.default(relu__default_161, primals_1915, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_274 = torch.ops.aten.add_.Tensor(primals_1917, 1);  primals_1917 = None
        native_batch_norm_default_198 = torch.ops.aten.native_batch_norm.default(convolution_default_198, primals_1920, primals_1916, primals_1918, primals_1919, True, 0.1, 1e-05);  primals_1916 = None
        getitem_594 = native_batch_norm_default_198[0]
        getitem_595 = native_batch_norm_default_198[1]
        getitem_596 = native_batch_norm_default_198[2];  native_batch_norm_default_198 = None
        new_zeros_default_198 = torch.ops.aten.new_zeros.default(convolution_default_198, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_17 = torch.ops.aten.upsample_nearest2d.vec(getitem_594, None, [4.0, 4.0]);  getitem_594 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(add_tensor_30, upsample_nearest2d_vec_17);  add_tensor_30 = upsample_nearest2d_vec_17 = None
        relu_default_19 = torch.ops.aten.relu.default(add_tensor_31);  add_tensor_31 = None
        convolution_default_199 = torch.ops.aten.convolution.default(relu__default_137, primals_1495, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_275 = torch.ops.aten.add_.Tensor(primals_1497, 1);  primals_1497 = None
        native_batch_norm_default_199 = torch.ops.aten.native_batch_norm.default(convolution_default_199, primals_1500, primals_1496, primals_1498, primals_1499, True, 0.1, 1e-05);  primals_1496 = None
        getitem_597 = native_batch_norm_default_199[0]
        getitem_598 = native_batch_norm_default_199[1]
        getitem_599 = native_batch_norm_default_199[2];  native_batch_norm_default_199 = None
        new_zeros_default_199 = torch.ops.aten.new_zeros.default(convolution_default_199, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_20 = torch.ops.aten.relu.default(getitem_597);  getitem_597 = None
        convolution_default_200 = torch.ops.aten.convolution.default(relu_default_20, primals_1501, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_276 = torch.ops.aten.add_.Tensor(primals_1503, 1);  primals_1503 = None
        native_batch_norm_default_200 = torch.ops.aten.native_batch_norm.default(convolution_default_200, primals_1506, primals_1502, primals_1504, primals_1505, True, 0.1, 1e-05);  primals_1502 = None
        getitem_600 = native_batch_norm_default_200[0]
        getitem_601 = native_batch_norm_default_200[1]
        getitem_602 = native_batch_norm_default_200[2];  native_batch_norm_default_200 = None
        new_zeros_default_200 = torch.ops.aten.new_zeros.default(convolution_default_200, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_201 = torch.ops.aten.convolution.default(relu__default_145, primals_1693, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_277 = torch.ops.aten.add_.Tensor(primals_1695, 1);  primals_1695 = None
        native_batch_norm_default_201 = torch.ops.aten.native_batch_norm.default(convolution_default_201, primals_1698, primals_1694, primals_1696, primals_1697, True, 0.1, 1e-05);  primals_1694 = None
        getitem_603 = native_batch_norm_default_201[0]
        getitem_604 = native_batch_norm_default_201[1]
        getitem_605 = native_batch_norm_default_201[2];  native_batch_norm_default_201 = None
        new_zeros_default_201 = torch.ops.aten.new_zeros.default(convolution_default_201, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_32 = torch.ops.aten.add.Tensor(getitem_600, getitem_603);  getitem_600 = getitem_603 = None
        add_tensor_33 = torch.ops.aten.add.Tensor(add_tensor_32, relu__default_153);  add_tensor_32 = None
        convolution_default_202 = torch.ops.aten.convolution.default(relu__default_161, primals_1921, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_278 = torch.ops.aten.add_.Tensor(primals_1923, 1);  primals_1923 = None
        native_batch_norm_default_202 = torch.ops.aten.native_batch_norm.default(convolution_default_202, primals_1926, primals_1922, primals_1924, primals_1925, True, 0.1, 1e-05);  primals_1922 = None
        getitem_606 = native_batch_norm_default_202[0]
        getitem_607 = native_batch_norm_default_202[1]
        getitem_608 = native_batch_norm_default_202[2];  native_batch_norm_default_202 = None
        new_zeros_default_202 = torch.ops.aten.new_zeros.default(convolution_default_202, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_18 = torch.ops.aten.upsample_nearest2d.vec(getitem_606, None, [2.0, 2.0]);  getitem_606 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(add_tensor_33, upsample_nearest2d_vec_18);  add_tensor_33 = upsample_nearest2d_vec_18 = None
        relu_default_21 = torch.ops.aten.relu.default(add_tensor_34);  add_tensor_34 = None
        convolution_default_203 = torch.ops.aten.convolution.default(relu__default_137, primals_1507, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_279 = torch.ops.aten.add_.Tensor(primals_1509, 1);  primals_1509 = None
        native_batch_norm_default_203 = torch.ops.aten.native_batch_norm.default(convolution_default_203, primals_1512, primals_1508, primals_1510, primals_1511, True, 0.1, 1e-05);  primals_1508 = None
        getitem_609 = native_batch_norm_default_203[0]
        getitem_610 = native_batch_norm_default_203[1]
        getitem_611 = native_batch_norm_default_203[2];  native_batch_norm_default_203 = None
        new_zeros_default_203 = torch.ops.aten.new_zeros.default(convolution_default_203, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_22 = torch.ops.aten.relu.default(getitem_609);  getitem_609 = None
        convolution_default_204 = torch.ops.aten.convolution.default(relu_default_22, primals_1513, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_280 = torch.ops.aten.add_.Tensor(primals_1515, 1);  primals_1515 = None
        native_batch_norm_default_204 = torch.ops.aten.native_batch_norm.default(convolution_default_204, primals_1518, primals_1514, primals_1516, primals_1517, True, 0.1, 1e-05);  primals_1514 = None
        getitem_612 = native_batch_norm_default_204[0]
        getitem_613 = native_batch_norm_default_204[1]
        getitem_614 = native_batch_norm_default_204[2];  native_batch_norm_default_204 = None
        new_zeros_default_204 = torch.ops.aten.new_zeros.default(convolution_default_204, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_23 = torch.ops.aten.relu.default(getitem_612);  getitem_612 = None
        convolution_default_205 = torch.ops.aten.convolution.default(relu_default_23, primals_1519, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_281 = torch.ops.aten.add_.Tensor(primals_1521, 1);  primals_1521 = None
        native_batch_norm_default_205 = torch.ops.aten.native_batch_norm.default(convolution_default_205, primals_1524, primals_1520, primals_1522, primals_1523, True, 0.1, 1e-05);  primals_1520 = None
        getitem_615 = native_batch_norm_default_205[0]
        getitem_616 = native_batch_norm_default_205[1]
        getitem_617 = native_batch_norm_default_205[2];  native_batch_norm_default_205 = None
        new_zeros_default_205 = torch.ops.aten.new_zeros.default(convolution_default_205, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_206 = torch.ops.aten.convolution.default(relu__default_145, primals_1699, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_282 = torch.ops.aten.add_.Tensor(primals_1701, 1);  primals_1701 = None
        native_batch_norm_default_206 = torch.ops.aten.native_batch_norm.default(convolution_default_206, primals_1704, primals_1700, primals_1702, primals_1703, True, 0.1, 1e-05);  primals_1700 = None
        getitem_618 = native_batch_norm_default_206[0]
        getitem_619 = native_batch_norm_default_206[1]
        getitem_620 = native_batch_norm_default_206[2];  native_batch_norm_default_206 = None
        new_zeros_default_206 = torch.ops.aten.new_zeros.default(convolution_default_206, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_24 = torch.ops.aten.relu.default(getitem_618);  getitem_618 = None
        convolution_default_207 = torch.ops.aten.convolution.default(relu_default_24, primals_1705, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_283 = torch.ops.aten.add_.Tensor(primals_1707, 1);  primals_1707 = None
        native_batch_norm_default_207 = torch.ops.aten.native_batch_norm.default(convolution_default_207, primals_1710, primals_1706, primals_1708, primals_1709, True, 0.1, 1e-05);  primals_1706 = None
        getitem_621 = native_batch_norm_default_207[0]
        getitem_622 = native_batch_norm_default_207[1]
        getitem_623 = native_batch_norm_default_207[2];  native_batch_norm_default_207 = None
        new_zeros_default_207 = torch.ops.aten.new_zeros.default(convolution_default_207, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_35 = torch.ops.aten.add.Tensor(getitem_615, getitem_621);  getitem_615 = getitem_621 = None
        convolution_default_208 = torch.ops.aten.convolution.default(relu__default_153, primals_1819, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_284 = torch.ops.aten.add_.Tensor(primals_1821, 1);  primals_1821 = None
        native_batch_norm_default_208 = torch.ops.aten.native_batch_norm.default(convolution_default_208, primals_1824, primals_1820, primals_1822, primals_1823, True, 0.1, 1e-05);  primals_1820 = None
        getitem_624 = native_batch_norm_default_208[0]
        getitem_625 = native_batch_norm_default_208[1]
        getitem_626 = native_batch_norm_default_208[2];  native_batch_norm_default_208 = None
        new_zeros_default_208 = torch.ops.aten.new_zeros.default(convolution_default_208, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_36 = torch.ops.aten.add.Tensor(add_tensor_35, getitem_624);  add_tensor_35 = getitem_624 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(add_tensor_36, relu__default_161);  add_tensor_36 = None
        relu_default_25 = torch.ops.aten.relu.default(add_tensor_37);  add_tensor_37 = None
        convolution_default_209 = torch.ops.aten.convolution.default(relu_default_18, primals_1091, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_285 = torch.ops.aten.add_.Tensor(primals_1082, 1);  primals_1082 = None
        native_batch_norm_default_209 = torch.ops.aten.native_batch_norm.default(convolution_default_209, primals_1085, primals_1081, primals_1083, primals_1084, True, 0.1, 1e-05);  primals_1081 = None
        getitem_627 = native_batch_norm_default_209[0]
        getitem_628 = native_batch_norm_default_209[1]
        getitem_629 = native_batch_norm_default_209[2];  native_batch_norm_default_209 = None
        new_zeros_default_209 = torch.ops.aten.new_zeros.default(convolution_default_209, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_162 = torch.ops.aten.relu_.default(getitem_627);  getitem_627 = None
        convolution_default_210 = torch.ops.aten.convolution.default(relu__default_162, primals_1092, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_286 = torch.ops.aten.add_.Tensor(primals_1087, 1);  primals_1087 = None
        native_batch_norm_default_210 = torch.ops.aten.native_batch_norm.default(convolution_default_210, primals_1090, primals_1086, primals_1088, primals_1089, True, 0.1, 1e-05);  primals_1086 = None
        getitem_630 = native_batch_norm_default_210[0]
        getitem_631 = native_batch_norm_default_210[1]
        getitem_632 = native_batch_norm_default_210[2];  native_batch_norm_default_210 = None
        new_zeros_default_210 = torch.ops.aten.new_zeros.default(convolution_default_210, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_287 = torch.ops.aten.add_.Tensor(getitem_630, relu_default_18);  getitem_630 = None
        relu__default_163 = torch.ops.aten.relu_.default(add__tensor_287);  add__tensor_287 = None
        convolution_default_211 = torch.ops.aten.convolution.default(relu__default_163, primals_1103, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_288 = torch.ops.aten.add_.Tensor(primals_1094, 1);  primals_1094 = None
        native_batch_norm_default_211 = torch.ops.aten.native_batch_norm.default(convolution_default_211, primals_1097, primals_1093, primals_1095, primals_1096, True, 0.1, 1e-05);  primals_1093 = None
        getitem_633 = native_batch_norm_default_211[0]
        getitem_634 = native_batch_norm_default_211[1]
        getitem_635 = native_batch_norm_default_211[2];  native_batch_norm_default_211 = None
        new_zeros_default_211 = torch.ops.aten.new_zeros.default(convolution_default_211, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_164 = torch.ops.aten.relu_.default(getitem_633);  getitem_633 = None
        convolution_default_212 = torch.ops.aten.convolution.default(relu__default_164, primals_1104, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_289 = torch.ops.aten.add_.Tensor(primals_1099, 1);  primals_1099 = None
        native_batch_norm_default_212 = torch.ops.aten.native_batch_norm.default(convolution_default_212, primals_1102, primals_1098, primals_1100, primals_1101, True, 0.1, 1e-05);  primals_1098 = None
        getitem_636 = native_batch_norm_default_212[0]
        getitem_637 = native_batch_norm_default_212[1]
        getitem_638 = native_batch_norm_default_212[2];  native_batch_norm_default_212 = None
        new_zeros_default_212 = torch.ops.aten.new_zeros.default(convolution_default_212, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_290 = torch.ops.aten.add_.Tensor(getitem_636, relu__default_163);  getitem_636 = None
        relu__default_165 = torch.ops.aten.relu_.default(add__tensor_290);  add__tensor_290 = None
        convolution_default_213 = torch.ops.aten.convolution.default(relu__default_165, primals_1115, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_291 = torch.ops.aten.add_.Tensor(primals_1106, 1);  primals_1106 = None
        native_batch_norm_default_213 = torch.ops.aten.native_batch_norm.default(convolution_default_213, primals_1109, primals_1105, primals_1107, primals_1108, True, 0.1, 1e-05);  primals_1105 = None
        getitem_639 = native_batch_norm_default_213[0]
        getitem_640 = native_batch_norm_default_213[1]
        getitem_641 = native_batch_norm_default_213[2];  native_batch_norm_default_213 = None
        new_zeros_default_213 = torch.ops.aten.new_zeros.default(convolution_default_213, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_166 = torch.ops.aten.relu_.default(getitem_639);  getitem_639 = None
        convolution_default_214 = torch.ops.aten.convolution.default(relu__default_166, primals_1116, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_292 = torch.ops.aten.add_.Tensor(primals_1111, 1);  primals_1111 = None
        native_batch_norm_default_214 = torch.ops.aten.native_batch_norm.default(convolution_default_214, primals_1114, primals_1110, primals_1112, primals_1113, True, 0.1, 1e-05);  primals_1110 = None
        getitem_642 = native_batch_norm_default_214[0]
        getitem_643 = native_batch_norm_default_214[1]
        getitem_644 = native_batch_norm_default_214[2];  native_batch_norm_default_214 = None
        new_zeros_default_214 = torch.ops.aten.new_zeros.default(convolution_default_214, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_293 = torch.ops.aten.add_.Tensor(getitem_642, relu__default_165);  getitem_642 = None
        relu__default_167 = torch.ops.aten.relu_.default(add__tensor_293);  add__tensor_293 = None
        convolution_default_215 = torch.ops.aten.convolution.default(relu__default_167, primals_1127, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_294 = torch.ops.aten.add_.Tensor(primals_1118, 1);  primals_1118 = None
        native_batch_norm_default_215 = torch.ops.aten.native_batch_norm.default(convolution_default_215, primals_1121, primals_1117, primals_1119, primals_1120, True, 0.1, 1e-05);  primals_1117 = None
        getitem_645 = native_batch_norm_default_215[0]
        getitem_646 = native_batch_norm_default_215[1]
        getitem_647 = native_batch_norm_default_215[2];  native_batch_norm_default_215 = None
        new_zeros_default_215 = torch.ops.aten.new_zeros.default(convolution_default_215, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_168 = torch.ops.aten.relu_.default(getitem_645);  getitem_645 = None
        convolution_default_216 = torch.ops.aten.convolution.default(relu__default_168, primals_1128, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_295 = torch.ops.aten.add_.Tensor(primals_1123, 1);  primals_1123 = None
        native_batch_norm_default_216 = torch.ops.aten.native_batch_norm.default(convolution_default_216, primals_1126, primals_1122, primals_1124, primals_1125, True, 0.1, 1e-05);  primals_1122 = None
        getitem_648 = native_batch_norm_default_216[0]
        getitem_649 = native_batch_norm_default_216[1]
        getitem_650 = native_batch_norm_default_216[2];  native_batch_norm_default_216 = None
        new_zeros_default_216 = torch.ops.aten.new_zeros.default(convolution_default_216, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_296 = torch.ops.aten.add_.Tensor(getitem_648, relu__default_167);  getitem_648 = None
        relu__default_169 = torch.ops.aten.relu_.default(add__tensor_296);  add__tensor_296 = None
        convolution_default_217 = torch.ops.aten.convolution.default(relu_default_19, primals_1139, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_297 = torch.ops.aten.add_.Tensor(primals_1130, 1);  primals_1130 = None
        native_batch_norm_default_217 = torch.ops.aten.native_batch_norm.default(convolution_default_217, primals_1133, primals_1129, primals_1131, primals_1132, True, 0.1, 1e-05);  primals_1129 = None
        getitem_651 = native_batch_norm_default_217[0]
        getitem_652 = native_batch_norm_default_217[1]
        getitem_653 = native_batch_norm_default_217[2];  native_batch_norm_default_217 = None
        new_zeros_default_217 = torch.ops.aten.new_zeros.default(convolution_default_217, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_170 = torch.ops.aten.relu_.default(getitem_651);  getitem_651 = None
        convolution_default_218 = torch.ops.aten.convolution.default(relu__default_170, primals_1140, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_298 = torch.ops.aten.add_.Tensor(primals_1135, 1);  primals_1135 = None
        native_batch_norm_default_218 = torch.ops.aten.native_batch_norm.default(convolution_default_218, primals_1138, primals_1134, primals_1136, primals_1137, True, 0.1, 1e-05);  primals_1134 = None
        getitem_654 = native_batch_norm_default_218[0]
        getitem_655 = native_batch_norm_default_218[1]
        getitem_656 = native_batch_norm_default_218[2];  native_batch_norm_default_218 = None
        new_zeros_default_218 = torch.ops.aten.new_zeros.default(convolution_default_218, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_299 = torch.ops.aten.add_.Tensor(getitem_654, relu_default_19);  getitem_654 = None
        relu__default_171 = torch.ops.aten.relu_.default(add__tensor_299);  add__tensor_299 = None
        convolution_default_219 = torch.ops.aten.convolution.default(relu__default_171, primals_1151, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_300 = torch.ops.aten.add_.Tensor(primals_1142, 1);  primals_1142 = None
        native_batch_norm_default_219 = torch.ops.aten.native_batch_norm.default(convolution_default_219, primals_1145, primals_1141, primals_1143, primals_1144, True, 0.1, 1e-05);  primals_1141 = None
        getitem_657 = native_batch_norm_default_219[0]
        getitem_658 = native_batch_norm_default_219[1]
        getitem_659 = native_batch_norm_default_219[2];  native_batch_norm_default_219 = None
        new_zeros_default_219 = torch.ops.aten.new_zeros.default(convolution_default_219, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_172 = torch.ops.aten.relu_.default(getitem_657);  getitem_657 = None
        convolution_default_220 = torch.ops.aten.convolution.default(relu__default_172, primals_1152, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_301 = torch.ops.aten.add_.Tensor(primals_1147, 1);  primals_1147 = None
        native_batch_norm_default_220 = torch.ops.aten.native_batch_norm.default(convolution_default_220, primals_1150, primals_1146, primals_1148, primals_1149, True, 0.1, 1e-05);  primals_1146 = None
        getitem_660 = native_batch_norm_default_220[0]
        getitem_661 = native_batch_norm_default_220[1]
        getitem_662 = native_batch_norm_default_220[2];  native_batch_norm_default_220 = None
        new_zeros_default_220 = torch.ops.aten.new_zeros.default(convolution_default_220, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_302 = torch.ops.aten.add_.Tensor(getitem_660, relu__default_171);  getitem_660 = None
        relu__default_173 = torch.ops.aten.relu_.default(add__tensor_302);  add__tensor_302 = None
        convolution_default_221 = torch.ops.aten.convolution.default(relu__default_173, primals_1163, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_303 = torch.ops.aten.add_.Tensor(primals_1154, 1);  primals_1154 = None
        native_batch_norm_default_221 = torch.ops.aten.native_batch_norm.default(convolution_default_221, primals_1157, primals_1153, primals_1155, primals_1156, True, 0.1, 1e-05);  primals_1153 = None
        getitem_663 = native_batch_norm_default_221[0]
        getitem_664 = native_batch_norm_default_221[1]
        getitem_665 = native_batch_norm_default_221[2];  native_batch_norm_default_221 = None
        new_zeros_default_221 = torch.ops.aten.new_zeros.default(convolution_default_221, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_174 = torch.ops.aten.relu_.default(getitem_663);  getitem_663 = None
        convolution_default_222 = torch.ops.aten.convolution.default(relu__default_174, primals_1164, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_304 = torch.ops.aten.add_.Tensor(primals_1159, 1);  primals_1159 = None
        native_batch_norm_default_222 = torch.ops.aten.native_batch_norm.default(convolution_default_222, primals_1162, primals_1158, primals_1160, primals_1161, True, 0.1, 1e-05);  primals_1158 = None
        getitem_666 = native_batch_norm_default_222[0]
        getitem_667 = native_batch_norm_default_222[1]
        getitem_668 = native_batch_norm_default_222[2];  native_batch_norm_default_222 = None
        new_zeros_default_222 = torch.ops.aten.new_zeros.default(convolution_default_222, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_305 = torch.ops.aten.add_.Tensor(getitem_666, relu__default_173);  getitem_666 = None
        relu__default_175 = torch.ops.aten.relu_.default(add__tensor_305);  add__tensor_305 = None
        convolution_default_223 = torch.ops.aten.convolution.default(relu__default_175, primals_1175, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_306 = torch.ops.aten.add_.Tensor(primals_1166, 1);  primals_1166 = None
        native_batch_norm_default_223 = torch.ops.aten.native_batch_norm.default(convolution_default_223, primals_1169, primals_1165, primals_1167, primals_1168, True, 0.1, 1e-05);  primals_1165 = None
        getitem_669 = native_batch_norm_default_223[0]
        getitem_670 = native_batch_norm_default_223[1]
        getitem_671 = native_batch_norm_default_223[2];  native_batch_norm_default_223 = None
        new_zeros_default_223 = torch.ops.aten.new_zeros.default(convolution_default_223, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_176 = torch.ops.aten.relu_.default(getitem_669);  getitem_669 = None
        convolution_default_224 = torch.ops.aten.convolution.default(relu__default_176, primals_1176, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_307 = torch.ops.aten.add_.Tensor(primals_1171, 1);  primals_1171 = None
        native_batch_norm_default_224 = torch.ops.aten.native_batch_norm.default(convolution_default_224, primals_1174, primals_1170, primals_1172, primals_1173, True, 0.1, 1e-05);  primals_1170 = None
        getitem_672 = native_batch_norm_default_224[0]
        getitem_673 = native_batch_norm_default_224[1]
        getitem_674 = native_batch_norm_default_224[2];  native_batch_norm_default_224 = None
        new_zeros_default_224 = torch.ops.aten.new_zeros.default(convolution_default_224, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_308 = torch.ops.aten.add_.Tensor(getitem_672, relu__default_175);  getitem_672 = None
        relu__default_177 = torch.ops.aten.relu_.default(add__tensor_308);  add__tensor_308 = None
        convolution_default_225 = torch.ops.aten.convolution.default(relu_default_21, primals_1187, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_309 = torch.ops.aten.add_.Tensor(primals_1178, 1);  primals_1178 = None
        native_batch_norm_default_225 = torch.ops.aten.native_batch_norm.default(convolution_default_225, primals_1181, primals_1177, primals_1179, primals_1180, True, 0.1, 1e-05);  primals_1177 = None
        getitem_675 = native_batch_norm_default_225[0]
        getitem_676 = native_batch_norm_default_225[1]
        getitem_677 = native_batch_norm_default_225[2];  native_batch_norm_default_225 = None
        new_zeros_default_225 = torch.ops.aten.new_zeros.default(convolution_default_225, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_178 = torch.ops.aten.relu_.default(getitem_675);  getitem_675 = None
        convolution_default_226 = torch.ops.aten.convolution.default(relu__default_178, primals_1188, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_310 = torch.ops.aten.add_.Tensor(primals_1183, 1);  primals_1183 = None
        native_batch_norm_default_226 = torch.ops.aten.native_batch_norm.default(convolution_default_226, primals_1186, primals_1182, primals_1184, primals_1185, True, 0.1, 1e-05);  primals_1182 = None
        getitem_678 = native_batch_norm_default_226[0]
        getitem_679 = native_batch_norm_default_226[1]
        getitem_680 = native_batch_norm_default_226[2];  native_batch_norm_default_226 = None
        new_zeros_default_226 = torch.ops.aten.new_zeros.default(convolution_default_226, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_311 = torch.ops.aten.add_.Tensor(getitem_678, relu_default_21);  getitem_678 = None
        relu__default_179 = torch.ops.aten.relu_.default(add__tensor_311);  add__tensor_311 = None
        convolution_default_227 = torch.ops.aten.convolution.default(relu__default_179, primals_1199, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_312 = torch.ops.aten.add_.Tensor(primals_1190, 1);  primals_1190 = None
        native_batch_norm_default_227 = torch.ops.aten.native_batch_norm.default(convolution_default_227, primals_1193, primals_1189, primals_1191, primals_1192, True, 0.1, 1e-05);  primals_1189 = None
        getitem_681 = native_batch_norm_default_227[0]
        getitem_682 = native_batch_norm_default_227[1]
        getitem_683 = native_batch_norm_default_227[2];  native_batch_norm_default_227 = None
        new_zeros_default_227 = torch.ops.aten.new_zeros.default(convolution_default_227, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_180 = torch.ops.aten.relu_.default(getitem_681);  getitem_681 = None
        convolution_default_228 = torch.ops.aten.convolution.default(relu__default_180, primals_1200, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_313 = torch.ops.aten.add_.Tensor(primals_1195, 1);  primals_1195 = None
        native_batch_norm_default_228 = torch.ops.aten.native_batch_norm.default(convolution_default_228, primals_1198, primals_1194, primals_1196, primals_1197, True, 0.1, 1e-05);  primals_1194 = None
        getitem_684 = native_batch_norm_default_228[0]
        getitem_685 = native_batch_norm_default_228[1]
        getitem_686 = native_batch_norm_default_228[2];  native_batch_norm_default_228 = None
        new_zeros_default_228 = torch.ops.aten.new_zeros.default(convolution_default_228, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_314 = torch.ops.aten.add_.Tensor(getitem_684, relu__default_179);  getitem_684 = None
        relu__default_181 = torch.ops.aten.relu_.default(add__tensor_314);  add__tensor_314 = None
        convolution_default_229 = torch.ops.aten.convolution.default(relu__default_181, primals_1211, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_315 = torch.ops.aten.add_.Tensor(primals_1202, 1);  primals_1202 = None
        native_batch_norm_default_229 = torch.ops.aten.native_batch_norm.default(convolution_default_229, primals_1205, primals_1201, primals_1203, primals_1204, True, 0.1, 1e-05);  primals_1201 = None
        getitem_687 = native_batch_norm_default_229[0]
        getitem_688 = native_batch_norm_default_229[1]
        getitem_689 = native_batch_norm_default_229[2];  native_batch_norm_default_229 = None
        new_zeros_default_229 = torch.ops.aten.new_zeros.default(convolution_default_229, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_182 = torch.ops.aten.relu_.default(getitem_687);  getitem_687 = None
        convolution_default_230 = torch.ops.aten.convolution.default(relu__default_182, primals_1212, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_316 = torch.ops.aten.add_.Tensor(primals_1207, 1);  primals_1207 = None
        native_batch_norm_default_230 = torch.ops.aten.native_batch_norm.default(convolution_default_230, primals_1210, primals_1206, primals_1208, primals_1209, True, 0.1, 1e-05);  primals_1206 = None
        getitem_690 = native_batch_norm_default_230[0]
        getitem_691 = native_batch_norm_default_230[1]
        getitem_692 = native_batch_norm_default_230[2];  native_batch_norm_default_230 = None
        new_zeros_default_230 = torch.ops.aten.new_zeros.default(convolution_default_230, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_317 = torch.ops.aten.add_.Tensor(getitem_690, relu__default_181);  getitem_690 = None
        relu__default_183 = torch.ops.aten.relu_.default(add__tensor_317);  add__tensor_317 = None
        convolution_default_231 = torch.ops.aten.convolution.default(relu__default_183, primals_1223, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_318 = torch.ops.aten.add_.Tensor(primals_1214, 1);  primals_1214 = None
        native_batch_norm_default_231 = torch.ops.aten.native_batch_norm.default(convolution_default_231, primals_1217, primals_1213, primals_1215, primals_1216, True, 0.1, 1e-05);  primals_1213 = None
        getitem_693 = native_batch_norm_default_231[0]
        getitem_694 = native_batch_norm_default_231[1]
        getitem_695 = native_batch_norm_default_231[2];  native_batch_norm_default_231 = None
        new_zeros_default_231 = torch.ops.aten.new_zeros.default(convolution_default_231, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_184 = torch.ops.aten.relu_.default(getitem_693);  getitem_693 = None
        convolution_default_232 = torch.ops.aten.convolution.default(relu__default_184, primals_1224, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_319 = torch.ops.aten.add_.Tensor(primals_1219, 1);  primals_1219 = None
        native_batch_norm_default_232 = torch.ops.aten.native_batch_norm.default(convolution_default_232, primals_1222, primals_1218, primals_1220, primals_1221, True, 0.1, 1e-05);  primals_1218 = None
        getitem_696 = native_batch_norm_default_232[0]
        getitem_697 = native_batch_norm_default_232[1]
        getitem_698 = native_batch_norm_default_232[2];  native_batch_norm_default_232 = None
        new_zeros_default_232 = torch.ops.aten.new_zeros.default(convolution_default_232, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_320 = torch.ops.aten.add_.Tensor(getitem_696, relu__default_183);  getitem_696 = None
        relu__default_185 = torch.ops.aten.relu_.default(add__tensor_320);  add__tensor_320 = None
        convolution_default_233 = torch.ops.aten.convolution.default(relu_default_25, primals_1235, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_321 = torch.ops.aten.add_.Tensor(primals_1226, 1);  primals_1226 = None
        native_batch_norm_default_233 = torch.ops.aten.native_batch_norm.default(convolution_default_233, primals_1229, primals_1225, primals_1227, primals_1228, True, 0.1, 1e-05);  primals_1225 = None
        getitem_699 = native_batch_norm_default_233[0]
        getitem_700 = native_batch_norm_default_233[1]
        getitem_701 = native_batch_norm_default_233[2];  native_batch_norm_default_233 = None
        new_zeros_default_233 = torch.ops.aten.new_zeros.default(convolution_default_233, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_186 = torch.ops.aten.relu_.default(getitem_699);  getitem_699 = None
        convolution_default_234 = torch.ops.aten.convolution.default(relu__default_186, primals_1236, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_322 = torch.ops.aten.add_.Tensor(primals_1231, 1);  primals_1231 = None
        native_batch_norm_default_234 = torch.ops.aten.native_batch_norm.default(convolution_default_234, primals_1234, primals_1230, primals_1232, primals_1233, True, 0.1, 1e-05);  primals_1230 = None
        getitem_702 = native_batch_norm_default_234[0]
        getitem_703 = native_batch_norm_default_234[1]
        getitem_704 = native_batch_norm_default_234[2];  native_batch_norm_default_234 = None
        new_zeros_default_234 = torch.ops.aten.new_zeros.default(convolution_default_234, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_323 = torch.ops.aten.add_.Tensor(getitem_702, relu_default_25);  getitem_702 = None
        relu__default_187 = torch.ops.aten.relu_.default(add__tensor_323);  add__tensor_323 = None
        convolution_default_235 = torch.ops.aten.convolution.default(relu__default_187, primals_1247, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_324 = torch.ops.aten.add_.Tensor(primals_1238, 1);  primals_1238 = None
        native_batch_norm_default_235 = torch.ops.aten.native_batch_norm.default(convolution_default_235, primals_1241, primals_1237, primals_1239, primals_1240, True, 0.1, 1e-05);  primals_1237 = None
        getitem_705 = native_batch_norm_default_235[0]
        getitem_706 = native_batch_norm_default_235[1]
        getitem_707 = native_batch_norm_default_235[2];  native_batch_norm_default_235 = None
        new_zeros_default_235 = torch.ops.aten.new_zeros.default(convolution_default_235, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_188 = torch.ops.aten.relu_.default(getitem_705);  getitem_705 = None
        convolution_default_236 = torch.ops.aten.convolution.default(relu__default_188, primals_1248, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_325 = torch.ops.aten.add_.Tensor(primals_1243, 1);  primals_1243 = None
        native_batch_norm_default_236 = torch.ops.aten.native_batch_norm.default(convolution_default_236, primals_1246, primals_1242, primals_1244, primals_1245, True, 0.1, 1e-05);  primals_1242 = None
        getitem_708 = native_batch_norm_default_236[0]
        getitem_709 = native_batch_norm_default_236[1]
        getitem_710 = native_batch_norm_default_236[2];  native_batch_norm_default_236 = None
        new_zeros_default_236 = torch.ops.aten.new_zeros.default(convolution_default_236, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_326 = torch.ops.aten.add_.Tensor(getitem_708, relu__default_187);  getitem_708 = None
        relu__default_189 = torch.ops.aten.relu_.default(add__tensor_326);  add__tensor_326 = None
        convolution_default_237 = torch.ops.aten.convolution.default(relu__default_189, primals_1259, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_327 = torch.ops.aten.add_.Tensor(primals_1250, 1);  primals_1250 = None
        native_batch_norm_default_237 = torch.ops.aten.native_batch_norm.default(convolution_default_237, primals_1253, primals_1249, primals_1251, primals_1252, True, 0.1, 1e-05);  primals_1249 = None
        getitem_711 = native_batch_norm_default_237[0]
        getitem_712 = native_batch_norm_default_237[1]
        getitem_713 = native_batch_norm_default_237[2];  native_batch_norm_default_237 = None
        new_zeros_default_237 = torch.ops.aten.new_zeros.default(convolution_default_237, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_190 = torch.ops.aten.relu_.default(getitem_711);  getitem_711 = None
        convolution_default_238 = torch.ops.aten.convolution.default(relu__default_190, primals_1260, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_328 = torch.ops.aten.add_.Tensor(primals_1255, 1);  primals_1255 = None
        native_batch_norm_default_238 = torch.ops.aten.native_batch_norm.default(convolution_default_238, primals_1258, primals_1254, primals_1256, primals_1257, True, 0.1, 1e-05);  primals_1254 = None
        getitem_714 = native_batch_norm_default_238[0]
        getitem_715 = native_batch_norm_default_238[1]
        getitem_716 = native_batch_norm_default_238[2];  native_batch_norm_default_238 = None
        new_zeros_default_238 = torch.ops.aten.new_zeros.default(convolution_default_238, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_329 = torch.ops.aten.add_.Tensor(getitem_714, relu__default_189);  getitem_714 = None
        relu__default_191 = torch.ops.aten.relu_.default(add__tensor_329);  add__tensor_329 = None
        convolution_default_239 = torch.ops.aten.convolution.default(relu__default_191, primals_1271, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_330 = torch.ops.aten.add_.Tensor(primals_1262, 1);  primals_1262 = None
        native_batch_norm_default_239 = torch.ops.aten.native_batch_norm.default(convolution_default_239, primals_1265, primals_1261, primals_1263, primals_1264, True, 0.1, 1e-05);  primals_1261 = None
        getitem_717 = native_batch_norm_default_239[0]
        getitem_718 = native_batch_norm_default_239[1]
        getitem_719 = native_batch_norm_default_239[2];  native_batch_norm_default_239 = None
        new_zeros_default_239 = torch.ops.aten.new_zeros.default(convolution_default_239, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_192 = torch.ops.aten.relu_.default(getitem_717);  getitem_717 = None
        convolution_default_240 = torch.ops.aten.convolution.default(relu__default_192, primals_1272, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_331 = torch.ops.aten.add_.Tensor(primals_1267, 1);  primals_1267 = None
        native_batch_norm_default_240 = torch.ops.aten.native_batch_norm.default(convolution_default_240, primals_1270, primals_1266, primals_1268, primals_1269, True, 0.1, 1e-05);  primals_1266 = None
        getitem_720 = native_batch_norm_default_240[0]
        getitem_721 = native_batch_norm_default_240[1]
        getitem_722 = native_batch_norm_default_240[2];  native_batch_norm_default_240 = None
        new_zeros_default_240 = torch.ops.aten.new_zeros.default(convolution_default_240, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_332 = torch.ops.aten.add_.Tensor(getitem_720, relu__default_191);  getitem_720 = None
        relu__default_193 = torch.ops.aten.relu_.default(add__tensor_332);  add__tensor_332 = None
        convolution_default_241 = torch.ops.aten.convolution.default(relu__default_177, primals_1711, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_333 = torch.ops.aten.add_.Tensor(primals_1713, 1);  primals_1713 = None
        native_batch_norm_default_241 = torch.ops.aten.native_batch_norm.default(convolution_default_241, primals_1716, primals_1712, primals_1714, primals_1715, True, 0.1, 1e-05);  primals_1712 = None
        getitem_723 = native_batch_norm_default_241[0]
        getitem_724 = native_batch_norm_default_241[1]
        getitem_725 = native_batch_norm_default_241[2];  native_batch_norm_default_241 = None
        new_zeros_default_241 = torch.ops.aten.new_zeros.default(convolution_default_241, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_19 = torch.ops.aten.upsample_nearest2d.vec(getitem_723, None, [2.0, 2.0]);  getitem_723 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(relu__default_169, upsample_nearest2d_vec_19);  upsample_nearest2d_vec_19 = None
        convolution_default_242 = torch.ops.aten.convolution.default(relu__default_185, primals_1825, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_334 = torch.ops.aten.add_.Tensor(primals_1827, 1);  primals_1827 = None
        native_batch_norm_default_242 = torch.ops.aten.native_batch_norm.default(convolution_default_242, primals_1830, primals_1826, primals_1828, primals_1829, True, 0.1, 1e-05);  primals_1826 = None
        getitem_726 = native_batch_norm_default_242[0]
        getitem_727 = native_batch_norm_default_242[1]
        getitem_728 = native_batch_norm_default_242[2];  native_batch_norm_default_242 = None
        new_zeros_default_242 = torch.ops.aten.new_zeros.default(convolution_default_242, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_20 = torch.ops.aten.upsample_nearest2d.vec(getitem_726, None, [4.0, 4.0]);  getitem_726 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(add_tensor_38, upsample_nearest2d_vec_20);  add_tensor_38 = upsample_nearest2d_vec_20 = None
        convolution_default_243 = torch.ops.aten.convolution.default(relu__default_193, primals_1927, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_335 = torch.ops.aten.add_.Tensor(primals_1929, 1);  primals_1929 = None
        native_batch_norm_default_243 = torch.ops.aten.native_batch_norm.default(convolution_default_243, primals_1932, primals_1928, primals_1930, primals_1931, True, 0.1, 1e-05);  primals_1928 = None
        getitem_729 = native_batch_norm_default_243[0]
        getitem_730 = native_batch_norm_default_243[1]
        getitem_731 = native_batch_norm_default_243[2];  native_batch_norm_default_243 = None
        new_zeros_default_243 = torch.ops.aten.new_zeros.default(convolution_default_243, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_21 = torch.ops.aten.upsample_nearest2d.vec(getitem_729, None, [8.0, 8.0]);  getitem_729 = None
        add_tensor_40 = torch.ops.aten.add.Tensor(add_tensor_39, upsample_nearest2d_vec_21);  add_tensor_39 = upsample_nearest2d_vec_21 = None
        relu_default_26 = torch.ops.aten.relu.default(add_tensor_40);  add_tensor_40 = None
        convolution_default_244 = torch.ops.aten.convolution.default(relu__default_169, primals_1525, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_336 = torch.ops.aten.add_.Tensor(primals_1527, 1);  primals_1527 = None
        native_batch_norm_default_244 = torch.ops.aten.native_batch_norm.default(convolution_default_244, primals_1530, primals_1526, primals_1528, primals_1529, True, 0.1, 1e-05);  primals_1526 = None
        getitem_732 = native_batch_norm_default_244[0]
        getitem_733 = native_batch_norm_default_244[1]
        getitem_734 = native_batch_norm_default_244[2];  native_batch_norm_default_244 = None
        new_zeros_default_244 = torch.ops.aten.new_zeros.default(convolution_default_244, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_41 = torch.ops.aten.add.Tensor(getitem_732, relu__default_177);  getitem_732 = None
        convolution_default_245 = torch.ops.aten.convolution.default(relu__default_185, primals_1831, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_337 = torch.ops.aten.add_.Tensor(primals_1833, 1);  primals_1833 = None
        native_batch_norm_default_245 = torch.ops.aten.native_batch_norm.default(convolution_default_245, primals_1836, primals_1832, primals_1834, primals_1835, True, 0.1, 1e-05);  primals_1832 = None
        getitem_735 = native_batch_norm_default_245[0]
        getitem_736 = native_batch_norm_default_245[1]
        getitem_737 = native_batch_norm_default_245[2];  native_batch_norm_default_245 = None
        new_zeros_default_245 = torch.ops.aten.new_zeros.default(convolution_default_245, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_22 = torch.ops.aten.upsample_nearest2d.vec(getitem_735, None, [2.0, 2.0]);  getitem_735 = None
        add_tensor_42 = torch.ops.aten.add.Tensor(add_tensor_41, upsample_nearest2d_vec_22);  add_tensor_41 = upsample_nearest2d_vec_22 = None
        convolution_default_246 = torch.ops.aten.convolution.default(relu__default_193, primals_1933, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_338 = torch.ops.aten.add_.Tensor(primals_1935, 1);  primals_1935 = None
        native_batch_norm_default_246 = torch.ops.aten.native_batch_norm.default(convolution_default_246, primals_1938, primals_1934, primals_1936, primals_1937, True, 0.1, 1e-05);  primals_1934 = None
        getitem_738 = native_batch_norm_default_246[0]
        getitem_739 = native_batch_norm_default_246[1]
        getitem_740 = native_batch_norm_default_246[2];  native_batch_norm_default_246 = None
        new_zeros_default_246 = torch.ops.aten.new_zeros.default(convolution_default_246, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_23 = torch.ops.aten.upsample_nearest2d.vec(getitem_738, None, [4.0, 4.0]);  getitem_738 = None
        add_tensor_43 = torch.ops.aten.add.Tensor(add_tensor_42, upsample_nearest2d_vec_23);  add_tensor_42 = upsample_nearest2d_vec_23 = None
        relu_default_27 = torch.ops.aten.relu.default(add_tensor_43);  add_tensor_43 = None
        convolution_default_247 = torch.ops.aten.convolution.default(relu__default_169, primals_1531, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_339 = torch.ops.aten.add_.Tensor(primals_1533, 1);  primals_1533 = None
        native_batch_norm_default_247 = torch.ops.aten.native_batch_norm.default(convolution_default_247, primals_1536, primals_1532, primals_1534, primals_1535, True, 0.1, 1e-05);  primals_1532 = None
        getitem_741 = native_batch_norm_default_247[0]
        getitem_742 = native_batch_norm_default_247[1]
        getitem_743 = native_batch_norm_default_247[2];  native_batch_norm_default_247 = None
        new_zeros_default_247 = torch.ops.aten.new_zeros.default(convolution_default_247, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_28 = torch.ops.aten.relu.default(getitem_741);  getitem_741 = None
        convolution_default_248 = torch.ops.aten.convolution.default(relu_default_28, primals_1537, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_340 = torch.ops.aten.add_.Tensor(primals_1539, 1);  primals_1539 = None
        native_batch_norm_default_248 = torch.ops.aten.native_batch_norm.default(convolution_default_248, primals_1542, primals_1538, primals_1540, primals_1541, True, 0.1, 1e-05);  primals_1538 = None
        getitem_744 = native_batch_norm_default_248[0]
        getitem_745 = native_batch_norm_default_248[1]
        getitem_746 = native_batch_norm_default_248[2];  native_batch_norm_default_248 = None
        new_zeros_default_248 = torch.ops.aten.new_zeros.default(convolution_default_248, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_249 = torch.ops.aten.convolution.default(relu__default_177, primals_1717, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_341 = torch.ops.aten.add_.Tensor(primals_1719, 1);  primals_1719 = None
        native_batch_norm_default_249 = torch.ops.aten.native_batch_norm.default(convolution_default_249, primals_1722, primals_1718, primals_1720, primals_1721, True, 0.1, 1e-05);  primals_1718 = None
        getitem_747 = native_batch_norm_default_249[0]
        getitem_748 = native_batch_norm_default_249[1]
        getitem_749 = native_batch_norm_default_249[2];  native_batch_norm_default_249 = None
        new_zeros_default_249 = torch.ops.aten.new_zeros.default(convolution_default_249, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_44 = torch.ops.aten.add.Tensor(getitem_744, getitem_747);  getitem_744 = getitem_747 = None
        add_tensor_45 = torch.ops.aten.add.Tensor(add_tensor_44, relu__default_185);  add_tensor_44 = None
        convolution_default_250 = torch.ops.aten.convolution.default(relu__default_193, primals_1939, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_342 = torch.ops.aten.add_.Tensor(primals_1941, 1);  primals_1941 = None
        native_batch_norm_default_250 = torch.ops.aten.native_batch_norm.default(convolution_default_250, primals_1944, primals_1940, primals_1942, primals_1943, True, 0.1, 1e-05);  primals_1940 = None
        getitem_750 = native_batch_norm_default_250[0]
        getitem_751 = native_batch_norm_default_250[1]
        getitem_752 = native_batch_norm_default_250[2];  native_batch_norm_default_250 = None
        new_zeros_default_250 = torch.ops.aten.new_zeros.default(convolution_default_250, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_24 = torch.ops.aten.upsample_nearest2d.vec(getitem_750, None, [2.0, 2.0]);  getitem_750 = None
        add_tensor_46 = torch.ops.aten.add.Tensor(add_tensor_45, upsample_nearest2d_vec_24);  add_tensor_45 = upsample_nearest2d_vec_24 = None
        relu_default_29 = torch.ops.aten.relu.default(add_tensor_46);  add_tensor_46 = None
        convolution_default_251 = torch.ops.aten.convolution.default(relu__default_169, primals_1543, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_343 = torch.ops.aten.add_.Tensor(primals_1545, 1);  primals_1545 = None
        native_batch_norm_default_251 = torch.ops.aten.native_batch_norm.default(convolution_default_251, primals_1548, primals_1544, primals_1546, primals_1547, True, 0.1, 1e-05);  primals_1544 = None
        getitem_753 = native_batch_norm_default_251[0]
        getitem_754 = native_batch_norm_default_251[1]
        getitem_755 = native_batch_norm_default_251[2];  native_batch_norm_default_251 = None
        new_zeros_default_251 = torch.ops.aten.new_zeros.default(convolution_default_251, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_30 = torch.ops.aten.relu.default(getitem_753);  getitem_753 = None
        convolution_default_252 = torch.ops.aten.convolution.default(relu_default_30, primals_1549, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_344 = torch.ops.aten.add_.Tensor(primals_1551, 1);  primals_1551 = None
        native_batch_norm_default_252 = torch.ops.aten.native_batch_norm.default(convolution_default_252, primals_1554, primals_1550, primals_1552, primals_1553, True, 0.1, 1e-05);  primals_1550 = None
        getitem_756 = native_batch_norm_default_252[0]
        getitem_757 = native_batch_norm_default_252[1]
        getitem_758 = native_batch_norm_default_252[2];  native_batch_norm_default_252 = None
        new_zeros_default_252 = torch.ops.aten.new_zeros.default(convolution_default_252, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_31 = torch.ops.aten.relu.default(getitem_756);  getitem_756 = None
        convolution_default_253 = torch.ops.aten.convolution.default(relu_default_31, primals_1555, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_345 = torch.ops.aten.add_.Tensor(primals_1557, 1);  primals_1557 = None
        native_batch_norm_default_253 = torch.ops.aten.native_batch_norm.default(convolution_default_253, primals_1560, primals_1556, primals_1558, primals_1559, True, 0.1, 1e-05);  primals_1556 = None
        getitem_759 = native_batch_norm_default_253[0]
        getitem_760 = native_batch_norm_default_253[1]
        getitem_761 = native_batch_norm_default_253[2];  native_batch_norm_default_253 = None
        new_zeros_default_253 = torch.ops.aten.new_zeros.default(convolution_default_253, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_254 = torch.ops.aten.convolution.default(relu__default_177, primals_1723, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_346 = torch.ops.aten.add_.Tensor(primals_1725, 1);  primals_1725 = None
        native_batch_norm_default_254 = torch.ops.aten.native_batch_norm.default(convolution_default_254, primals_1728, primals_1724, primals_1726, primals_1727, True, 0.1, 1e-05);  primals_1724 = None
        getitem_762 = native_batch_norm_default_254[0]
        getitem_763 = native_batch_norm_default_254[1]
        getitem_764 = native_batch_norm_default_254[2];  native_batch_norm_default_254 = None
        new_zeros_default_254 = torch.ops.aten.new_zeros.default(convolution_default_254, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_32 = torch.ops.aten.relu.default(getitem_762);  getitem_762 = None
        convolution_default_255 = torch.ops.aten.convolution.default(relu_default_32, primals_1729, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_347 = torch.ops.aten.add_.Tensor(primals_1731, 1);  primals_1731 = None
        native_batch_norm_default_255 = torch.ops.aten.native_batch_norm.default(convolution_default_255, primals_1734, primals_1730, primals_1732, primals_1733, True, 0.1, 1e-05);  primals_1730 = None
        getitem_765 = native_batch_norm_default_255[0]
        getitem_766 = native_batch_norm_default_255[1]
        getitem_767 = native_batch_norm_default_255[2];  native_batch_norm_default_255 = None
        new_zeros_default_255 = torch.ops.aten.new_zeros.default(convolution_default_255, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_47 = torch.ops.aten.add.Tensor(getitem_759, getitem_765);  getitem_759 = getitem_765 = None
        convolution_default_256 = torch.ops.aten.convolution.default(relu__default_185, primals_1837, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_348 = torch.ops.aten.add_.Tensor(primals_1839, 1);  primals_1839 = None
        native_batch_norm_default_256 = torch.ops.aten.native_batch_norm.default(convolution_default_256, primals_1842, primals_1838, primals_1840, primals_1841, True, 0.1, 1e-05);  primals_1838 = None
        getitem_768 = native_batch_norm_default_256[0]
        getitem_769 = native_batch_norm_default_256[1]
        getitem_770 = native_batch_norm_default_256[2];  native_batch_norm_default_256 = None
        new_zeros_default_256 = torch.ops.aten.new_zeros.default(convolution_default_256, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_48 = torch.ops.aten.add.Tensor(add_tensor_47, getitem_768);  add_tensor_47 = getitem_768 = None
        add_tensor_49 = torch.ops.aten.add.Tensor(add_tensor_48, relu__default_193);  add_tensor_48 = None
        relu_default_33 = torch.ops.aten.relu.default(add_tensor_49);  add_tensor_49 = None
        convolution_default_257 = torch.ops.aten.convolution.default(relu_default_26, primals_1283, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_349 = torch.ops.aten.add_.Tensor(primals_1274, 1);  primals_1274 = None
        native_batch_norm_default_257 = torch.ops.aten.native_batch_norm.default(convolution_default_257, primals_1277, primals_1273, primals_1275, primals_1276, True, 0.1, 1e-05);  primals_1273 = None
        getitem_771 = native_batch_norm_default_257[0]
        getitem_772 = native_batch_norm_default_257[1]
        getitem_773 = native_batch_norm_default_257[2];  native_batch_norm_default_257 = None
        new_zeros_default_257 = torch.ops.aten.new_zeros.default(convolution_default_257, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_194 = torch.ops.aten.relu_.default(getitem_771);  getitem_771 = None
        convolution_default_258 = torch.ops.aten.convolution.default(relu__default_194, primals_1284, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_350 = torch.ops.aten.add_.Tensor(primals_1279, 1);  primals_1279 = None
        native_batch_norm_default_258 = torch.ops.aten.native_batch_norm.default(convolution_default_258, primals_1282, primals_1278, primals_1280, primals_1281, True, 0.1, 1e-05);  primals_1278 = None
        getitem_774 = native_batch_norm_default_258[0]
        getitem_775 = native_batch_norm_default_258[1]
        getitem_776 = native_batch_norm_default_258[2];  native_batch_norm_default_258 = None
        new_zeros_default_258 = torch.ops.aten.new_zeros.default(convolution_default_258, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_351 = torch.ops.aten.add_.Tensor(getitem_774, relu_default_26);  getitem_774 = None
        relu__default_195 = torch.ops.aten.relu_.default(add__tensor_351);  add__tensor_351 = None
        convolution_default_259 = torch.ops.aten.convolution.default(relu__default_195, primals_1295, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_352 = torch.ops.aten.add_.Tensor(primals_1286, 1);  primals_1286 = None
        native_batch_norm_default_259 = torch.ops.aten.native_batch_norm.default(convolution_default_259, primals_1289, primals_1285, primals_1287, primals_1288, True, 0.1, 1e-05);  primals_1285 = None
        getitem_777 = native_batch_norm_default_259[0]
        getitem_778 = native_batch_norm_default_259[1]
        getitem_779 = native_batch_norm_default_259[2];  native_batch_norm_default_259 = None
        new_zeros_default_259 = torch.ops.aten.new_zeros.default(convolution_default_259, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_196 = torch.ops.aten.relu_.default(getitem_777);  getitem_777 = None
        convolution_default_260 = torch.ops.aten.convolution.default(relu__default_196, primals_1296, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_353 = torch.ops.aten.add_.Tensor(primals_1291, 1);  primals_1291 = None
        native_batch_norm_default_260 = torch.ops.aten.native_batch_norm.default(convolution_default_260, primals_1294, primals_1290, primals_1292, primals_1293, True, 0.1, 1e-05);  primals_1290 = None
        getitem_780 = native_batch_norm_default_260[0]
        getitem_781 = native_batch_norm_default_260[1]
        getitem_782 = native_batch_norm_default_260[2];  native_batch_norm_default_260 = None
        new_zeros_default_260 = torch.ops.aten.new_zeros.default(convolution_default_260, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_354 = torch.ops.aten.add_.Tensor(getitem_780, relu__default_195);  getitem_780 = None
        relu__default_197 = torch.ops.aten.relu_.default(add__tensor_354);  add__tensor_354 = None
        convolution_default_261 = torch.ops.aten.convolution.default(relu__default_197, primals_1307, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_355 = torch.ops.aten.add_.Tensor(primals_1298, 1);  primals_1298 = None
        native_batch_norm_default_261 = torch.ops.aten.native_batch_norm.default(convolution_default_261, primals_1301, primals_1297, primals_1299, primals_1300, True, 0.1, 1e-05);  primals_1297 = None
        getitem_783 = native_batch_norm_default_261[0]
        getitem_784 = native_batch_norm_default_261[1]
        getitem_785 = native_batch_norm_default_261[2];  native_batch_norm_default_261 = None
        new_zeros_default_261 = torch.ops.aten.new_zeros.default(convolution_default_261, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_198 = torch.ops.aten.relu_.default(getitem_783);  getitem_783 = None
        convolution_default_262 = torch.ops.aten.convolution.default(relu__default_198, primals_1308, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_356 = torch.ops.aten.add_.Tensor(primals_1303, 1);  primals_1303 = None
        native_batch_norm_default_262 = torch.ops.aten.native_batch_norm.default(convolution_default_262, primals_1306, primals_1302, primals_1304, primals_1305, True, 0.1, 1e-05);  primals_1302 = None
        getitem_786 = native_batch_norm_default_262[0]
        getitem_787 = native_batch_norm_default_262[1]
        getitem_788 = native_batch_norm_default_262[2];  native_batch_norm_default_262 = None
        new_zeros_default_262 = torch.ops.aten.new_zeros.default(convolution_default_262, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_357 = torch.ops.aten.add_.Tensor(getitem_786, relu__default_197);  getitem_786 = None
        relu__default_199 = torch.ops.aten.relu_.default(add__tensor_357);  add__tensor_357 = None
        convolution_default_263 = torch.ops.aten.convolution.default(relu__default_199, primals_1319, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_358 = torch.ops.aten.add_.Tensor(primals_1310, 1);  primals_1310 = None
        native_batch_norm_default_263 = torch.ops.aten.native_batch_norm.default(convolution_default_263, primals_1313, primals_1309, primals_1311, primals_1312, True, 0.1, 1e-05);  primals_1309 = None
        getitem_789 = native_batch_norm_default_263[0]
        getitem_790 = native_batch_norm_default_263[1]
        getitem_791 = native_batch_norm_default_263[2];  native_batch_norm_default_263 = None
        new_zeros_default_263 = torch.ops.aten.new_zeros.default(convolution_default_263, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_200 = torch.ops.aten.relu_.default(getitem_789);  getitem_789 = None
        convolution_default_264 = torch.ops.aten.convolution.default(relu__default_200, primals_1320, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_359 = torch.ops.aten.add_.Tensor(primals_1315, 1);  primals_1315 = None
        native_batch_norm_default_264 = torch.ops.aten.native_batch_norm.default(convolution_default_264, primals_1318, primals_1314, primals_1316, primals_1317, True, 0.1, 1e-05);  primals_1314 = None
        getitem_792 = native_batch_norm_default_264[0]
        getitem_793 = native_batch_norm_default_264[1]
        getitem_794 = native_batch_norm_default_264[2];  native_batch_norm_default_264 = None
        new_zeros_default_264 = torch.ops.aten.new_zeros.default(convolution_default_264, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_360 = torch.ops.aten.add_.Tensor(getitem_792, relu__default_199);  getitem_792 = None
        relu__default_201 = torch.ops.aten.relu_.default(add__tensor_360);  add__tensor_360 = None
        convolution_default_265 = torch.ops.aten.convolution.default(relu_default_27, primals_1331, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_361 = torch.ops.aten.add_.Tensor(primals_1322, 1);  primals_1322 = None
        native_batch_norm_default_265 = torch.ops.aten.native_batch_norm.default(convolution_default_265, primals_1325, primals_1321, primals_1323, primals_1324, True, 0.1, 1e-05);  primals_1321 = None
        getitem_795 = native_batch_norm_default_265[0]
        getitem_796 = native_batch_norm_default_265[1]
        getitem_797 = native_batch_norm_default_265[2];  native_batch_norm_default_265 = None
        new_zeros_default_265 = torch.ops.aten.new_zeros.default(convolution_default_265, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_202 = torch.ops.aten.relu_.default(getitem_795);  getitem_795 = None
        convolution_default_266 = torch.ops.aten.convolution.default(relu__default_202, primals_1332, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_362 = torch.ops.aten.add_.Tensor(primals_1327, 1);  primals_1327 = None
        native_batch_norm_default_266 = torch.ops.aten.native_batch_norm.default(convolution_default_266, primals_1330, primals_1326, primals_1328, primals_1329, True, 0.1, 1e-05);  primals_1326 = None
        getitem_798 = native_batch_norm_default_266[0]
        getitem_799 = native_batch_norm_default_266[1]
        getitem_800 = native_batch_norm_default_266[2];  native_batch_norm_default_266 = None
        new_zeros_default_266 = torch.ops.aten.new_zeros.default(convolution_default_266, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_363 = torch.ops.aten.add_.Tensor(getitem_798, relu_default_27);  getitem_798 = None
        relu__default_203 = torch.ops.aten.relu_.default(add__tensor_363);  add__tensor_363 = None
        convolution_default_267 = torch.ops.aten.convolution.default(relu__default_203, primals_1343, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_364 = torch.ops.aten.add_.Tensor(primals_1334, 1);  primals_1334 = None
        native_batch_norm_default_267 = torch.ops.aten.native_batch_norm.default(convolution_default_267, primals_1337, primals_1333, primals_1335, primals_1336, True, 0.1, 1e-05);  primals_1333 = None
        getitem_801 = native_batch_norm_default_267[0]
        getitem_802 = native_batch_norm_default_267[1]
        getitem_803 = native_batch_norm_default_267[2];  native_batch_norm_default_267 = None
        new_zeros_default_267 = torch.ops.aten.new_zeros.default(convolution_default_267, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_204 = torch.ops.aten.relu_.default(getitem_801);  getitem_801 = None
        convolution_default_268 = torch.ops.aten.convolution.default(relu__default_204, primals_1344, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_365 = torch.ops.aten.add_.Tensor(primals_1339, 1);  primals_1339 = None
        native_batch_norm_default_268 = torch.ops.aten.native_batch_norm.default(convolution_default_268, primals_1342, primals_1338, primals_1340, primals_1341, True, 0.1, 1e-05);  primals_1338 = None
        getitem_804 = native_batch_norm_default_268[0]
        getitem_805 = native_batch_norm_default_268[1]
        getitem_806 = native_batch_norm_default_268[2];  native_batch_norm_default_268 = None
        new_zeros_default_268 = torch.ops.aten.new_zeros.default(convolution_default_268, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_366 = torch.ops.aten.add_.Tensor(getitem_804, relu__default_203);  getitem_804 = None
        relu__default_205 = torch.ops.aten.relu_.default(add__tensor_366);  add__tensor_366 = None
        convolution_default_269 = torch.ops.aten.convolution.default(relu__default_205, primals_1355, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_367 = torch.ops.aten.add_.Tensor(primals_1346, 1);  primals_1346 = None
        native_batch_norm_default_269 = torch.ops.aten.native_batch_norm.default(convolution_default_269, primals_1349, primals_1345, primals_1347, primals_1348, True, 0.1, 1e-05);  primals_1345 = None
        getitem_807 = native_batch_norm_default_269[0]
        getitem_808 = native_batch_norm_default_269[1]
        getitem_809 = native_batch_norm_default_269[2];  native_batch_norm_default_269 = None
        new_zeros_default_269 = torch.ops.aten.new_zeros.default(convolution_default_269, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_206 = torch.ops.aten.relu_.default(getitem_807);  getitem_807 = None
        convolution_default_270 = torch.ops.aten.convolution.default(relu__default_206, primals_1356, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_368 = torch.ops.aten.add_.Tensor(primals_1351, 1);  primals_1351 = None
        native_batch_norm_default_270 = torch.ops.aten.native_batch_norm.default(convolution_default_270, primals_1354, primals_1350, primals_1352, primals_1353, True, 0.1, 1e-05);  primals_1350 = None
        getitem_810 = native_batch_norm_default_270[0]
        getitem_811 = native_batch_norm_default_270[1]
        getitem_812 = native_batch_norm_default_270[2];  native_batch_norm_default_270 = None
        new_zeros_default_270 = torch.ops.aten.new_zeros.default(convolution_default_270, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_369 = torch.ops.aten.add_.Tensor(getitem_810, relu__default_205);  getitem_810 = None
        relu__default_207 = torch.ops.aten.relu_.default(add__tensor_369);  add__tensor_369 = None
        convolution_default_271 = torch.ops.aten.convolution.default(relu__default_207, primals_1367, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_370 = torch.ops.aten.add_.Tensor(primals_1358, 1);  primals_1358 = None
        native_batch_norm_default_271 = torch.ops.aten.native_batch_norm.default(convolution_default_271, primals_1361, primals_1357, primals_1359, primals_1360, True, 0.1, 1e-05);  primals_1357 = None
        getitem_813 = native_batch_norm_default_271[0]
        getitem_814 = native_batch_norm_default_271[1]
        getitem_815 = native_batch_norm_default_271[2];  native_batch_norm_default_271 = None
        new_zeros_default_271 = torch.ops.aten.new_zeros.default(convolution_default_271, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_208 = torch.ops.aten.relu_.default(getitem_813);  getitem_813 = None
        convolution_default_272 = torch.ops.aten.convolution.default(relu__default_208, primals_1368, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_371 = torch.ops.aten.add_.Tensor(primals_1363, 1);  primals_1363 = None
        native_batch_norm_default_272 = torch.ops.aten.native_batch_norm.default(convolution_default_272, primals_1366, primals_1362, primals_1364, primals_1365, True, 0.1, 1e-05);  primals_1362 = None
        getitem_816 = native_batch_norm_default_272[0]
        getitem_817 = native_batch_norm_default_272[1]
        getitem_818 = native_batch_norm_default_272[2];  native_batch_norm_default_272 = None
        new_zeros_default_272 = torch.ops.aten.new_zeros.default(convolution_default_272, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_372 = torch.ops.aten.add_.Tensor(getitem_816, relu__default_207);  getitem_816 = None
        relu__default_209 = torch.ops.aten.relu_.default(add__tensor_372);  add__tensor_372 = None
        convolution_default_273 = torch.ops.aten.convolution.default(relu_default_29, primals_1379, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_373 = torch.ops.aten.add_.Tensor(primals_1370, 1);  primals_1370 = None
        native_batch_norm_default_273 = torch.ops.aten.native_batch_norm.default(convolution_default_273, primals_1373, primals_1369, primals_1371, primals_1372, True, 0.1, 1e-05);  primals_1369 = None
        getitem_819 = native_batch_norm_default_273[0]
        getitem_820 = native_batch_norm_default_273[1]
        getitem_821 = native_batch_norm_default_273[2];  native_batch_norm_default_273 = None
        new_zeros_default_273 = torch.ops.aten.new_zeros.default(convolution_default_273, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_210 = torch.ops.aten.relu_.default(getitem_819);  getitem_819 = None
        convolution_default_274 = torch.ops.aten.convolution.default(relu__default_210, primals_1380, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_374 = torch.ops.aten.add_.Tensor(primals_1375, 1);  primals_1375 = None
        native_batch_norm_default_274 = torch.ops.aten.native_batch_norm.default(convolution_default_274, primals_1378, primals_1374, primals_1376, primals_1377, True, 0.1, 1e-05);  primals_1374 = None
        getitem_822 = native_batch_norm_default_274[0]
        getitem_823 = native_batch_norm_default_274[1]
        getitem_824 = native_batch_norm_default_274[2];  native_batch_norm_default_274 = None
        new_zeros_default_274 = torch.ops.aten.new_zeros.default(convolution_default_274, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_375 = torch.ops.aten.add_.Tensor(getitem_822, relu_default_29);  getitem_822 = None
        relu__default_211 = torch.ops.aten.relu_.default(add__tensor_375);  add__tensor_375 = None
        convolution_default_275 = torch.ops.aten.convolution.default(relu__default_211, primals_1391, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_376 = torch.ops.aten.add_.Tensor(primals_1382, 1);  primals_1382 = None
        native_batch_norm_default_275 = torch.ops.aten.native_batch_norm.default(convolution_default_275, primals_1385, primals_1381, primals_1383, primals_1384, True, 0.1, 1e-05);  primals_1381 = None
        getitem_825 = native_batch_norm_default_275[0]
        getitem_826 = native_batch_norm_default_275[1]
        getitem_827 = native_batch_norm_default_275[2];  native_batch_norm_default_275 = None
        new_zeros_default_275 = torch.ops.aten.new_zeros.default(convolution_default_275, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_212 = torch.ops.aten.relu_.default(getitem_825);  getitem_825 = None
        convolution_default_276 = torch.ops.aten.convolution.default(relu__default_212, primals_1392, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_377 = torch.ops.aten.add_.Tensor(primals_1387, 1);  primals_1387 = None
        native_batch_norm_default_276 = torch.ops.aten.native_batch_norm.default(convolution_default_276, primals_1390, primals_1386, primals_1388, primals_1389, True, 0.1, 1e-05);  primals_1386 = None
        getitem_828 = native_batch_norm_default_276[0]
        getitem_829 = native_batch_norm_default_276[1]
        getitem_830 = native_batch_norm_default_276[2];  native_batch_norm_default_276 = None
        new_zeros_default_276 = torch.ops.aten.new_zeros.default(convolution_default_276, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_378 = torch.ops.aten.add_.Tensor(getitem_828, relu__default_211);  getitem_828 = None
        relu__default_213 = torch.ops.aten.relu_.default(add__tensor_378);  add__tensor_378 = None
        convolution_default_277 = torch.ops.aten.convolution.default(relu__default_213, primals_1403, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_379 = torch.ops.aten.add_.Tensor(primals_1394, 1);  primals_1394 = None
        native_batch_norm_default_277 = torch.ops.aten.native_batch_norm.default(convolution_default_277, primals_1397, primals_1393, primals_1395, primals_1396, True, 0.1, 1e-05);  primals_1393 = None
        getitem_831 = native_batch_norm_default_277[0]
        getitem_832 = native_batch_norm_default_277[1]
        getitem_833 = native_batch_norm_default_277[2];  native_batch_norm_default_277 = None
        new_zeros_default_277 = torch.ops.aten.new_zeros.default(convolution_default_277, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_214 = torch.ops.aten.relu_.default(getitem_831);  getitem_831 = None
        convolution_default_278 = torch.ops.aten.convolution.default(relu__default_214, primals_1404, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_380 = torch.ops.aten.add_.Tensor(primals_1399, 1);  primals_1399 = None
        native_batch_norm_default_278 = torch.ops.aten.native_batch_norm.default(convolution_default_278, primals_1402, primals_1398, primals_1400, primals_1401, True, 0.1, 1e-05);  primals_1398 = None
        getitem_834 = native_batch_norm_default_278[0]
        getitem_835 = native_batch_norm_default_278[1]
        getitem_836 = native_batch_norm_default_278[2];  native_batch_norm_default_278 = None
        new_zeros_default_278 = torch.ops.aten.new_zeros.default(convolution_default_278, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_381 = torch.ops.aten.add_.Tensor(getitem_834, relu__default_213);  getitem_834 = None
        relu__default_215 = torch.ops.aten.relu_.default(add__tensor_381);  add__tensor_381 = None
        convolution_default_279 = torch.ops.aten.convolution.default(relu__default_215, primals_1415, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_382 = torch.ops.aten.add_.Tensor(primals_1406, 1);  primals_1406 = None
        native_batch_norm_default_279 = torch.ops.aten.native_batch_norm.default(convolution_default_279, primals_1409, primals_1405, primals_1407, primals_1408, True, 0.1, 1e-05);  primals_1405 = None
        getitem_837 = native_batch_norm_default_279[0]
        getitem_838 = native_batch_norm_default_279[1]
        getitem_839 = native_batch_norm_default_279[2];  native_batch_norm_default_279 = None
        new_zeros_default_279 = torch.ops.aten.new_zeros.default(convolution_default_279, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_216 = torch.ops.aten.relu_.default(getitem_837);  getitem_837 = None
        convolution_default_280 = torch.ops.aten.convolution.default(relu__default_216, primals_1416, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_383 = torch.ops.aten.add_.Tensor(primals_1411, 1);  primals_1411 = None
        native_batch_norm_default_280 = torch.ops.aten.native_batch_norm.default(convolution_default_280, primals_1414, primals_1410, primals_1412, primals_1413, True, 0.1, 1e-05);  primals_1410 = None
        getitem_840 = native_batch_norm_default_280[0]
        getitem_841 = native_batch_norm_default_280[1]
        getitem_842 = native_batch_norm_default_280[2];  native_batch_norm_default_280 = None
        new_zeros_default_280 = torch.ops.aten.new_zeros.default(convolution_default_280, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_384 = torch.ops.aten.add_.Tensor(getitem_840, relu__default_215);  getitem_840 = None
        relu__default_217 = torch.ops.aten.relu_.default(add__tensor_384);  add__tensor_384 = None
        convolution_default_281 = torch.ops.aten.convolution.default(relu_default_33, primals_1427, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_385 = torch.ops.aten.add_.Tensor(primals_1418, 1);  primals_1418 = None
        native_batch_norm_default_281 = torch.ops.aten.native_batch_norm.default(convolution_default_281, primals_1421, primals_1417, primals_1419, primals_1420, True, 0.1, 1e-05);  primals_1417 = None
        getitem_843 = native_batch_norm_default_281[0]
        getitem_844 = native_batch_norm_default_281[1]
        getitem_845 = native_batch_norm_default_281[2];  native_batch_norm_default_281 = None
        new_zeros_default_281 = torch.ops.aten.new_zeros.default(convolution_default_281, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_218 = torch.ops.aten.relu_.default(getitem_843);  getitem_843 = None
        convolution_default_282 = torch.ops.aten.convolution.default(relu__default_218, primals_1428, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_386 = torch.ops.aten.add_.Tensor(primals_1423, 1);  primals_1423 = None
        native_batch_norm_default_282 = torch.ops.aten.native_batch_norm.default(convolution_default_282, primals_1426, primals_1422, primals_1424, primals_1425, True, 0.1, 1e-05);  primals_1422 = None
        getitem_846 = native_batch_norm_default_282[0]
        getitem_847 = native_batch_norm_default_282[1]
        getitem_848 = native_batch_norm_default_282[2];  native_batch_norm_default_282 = None
        new_zeros_default_282 = torch.ops.aten.new_zeros.default(convolution_default_282, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_387 = torch.ops.aten.add_.Tensor(getitem_846, relu_default_33);  getitem_846 = None
        relu__default_219 = torch.ops.aten.relu_.default(add__tensor_387);  add__tensor_387 = None
        convolution_default_283 = torch.ops.aten.convolution.default(relu__default_219, primals_1439, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_388 = torch.ops.aten.add_.Tensor(primals_1430, 1);  primals_1430 = None
        native_batch_norm_default_283 = torch.ops.aten.native_batch_norm.default(convolution_default_283, primals_1433, primals_1429, primals_1431, primals_1432, True, 0.1, 1e-05);  primals_1429 = None
        getitem_849 = native_batch_norm_default_283[0]
        getitem_850 = native_batch_norm_default_283[1]
        getitem_851 = native_batch_norm_default_283[2];  native_batch_norm_default_283 = None
        new_zeros_default_283 = torch.ops.aten.new_zeros.default(convolution_default_283, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_220 = torch.ops.aten.relu_.default(getitem_849);  getitem_849 = None
        convolution_default_284 = torch.ops.aten.convolution.default(relu__default_220, primals_1440, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_389 = torch.ops.aten.add_.Tensor(primals_1435, 1);  primals_1435 = None
        native_batch_norm_default_284 = torch.ops.aten.native_batch_norm.default(convolution_default_284, primals_1438, primals_1434, primals_1436, primals_1437, True, 0.1, 1e-05);  primals_1434 = None
        getitem_852 = native_batch_norm_default_284[0]
        getitem_853 = native_batch_norm_default_284[1]
        getitem_854 = native_batch_norm_default_284[2];  native_batch_norm_default_284 = None
        new_zeros_default_284 = torch.ops.aten.new_zeros.default(convolution_default_284, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_390 = torch.ops.aten.add_.Tensor(getitem_852, relu__default_219);  getitem_852 = None
        relu__default_221 = torch.ops.aten.relu_.default(add__tensor_390);  add__tensor_390 = None
        convolution_default_285 = torch.ops.aten.convolution.default(relu__default_221, primals_1451, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_391 = torch.ops.aten.add_.Tensor(primals_1442, 1);  primals_1442 = None
        native_batch_norm_default_285 = torch.ops.aten.native_batch_norm.default(convolution_default_285, primals_1445, primals_1441, primals_1443, primals_1444, True, 0.1, 1e-05);  primals_1441 = None
        getitem_855 = native_batch_norm_default_285[0]
        getitem_856 = native_batch_norm_default_285[1]
        getitem_857 = native_batch_norm_default_285[2];  native_batch_norm_default_285 = None
        new_zeros_default_285 = torch.ops.aten.new_zeros.default(convolution_default_285, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_222 = torch.ops.aten.relu_.default(getitem_855);  getitem_855 = None
        convolution_default_286 = torch.ops.aten.convolution.default(relu__default_222, primals_1452, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_392 = torch.ops.aten.add_.Tensor(primals_1447, 1);  primals_1447 = None
        native_batch_norm_default_286 = torch.ops.aten.native_batch_norm.default(convolution_default_286, primals_1450, primals_1446, primals_1448, primals_1449, True, 0.1, 1e-05);  primals_1446 = None
        getitem_858 = native_batch_norm_default_286[0]
        getitem_859 = native_batch_norm_default_286[1]
        getitem_860 = native_batch_norm_default_286[2];  native_batch_norm_default_286 = None
        new_zeros_default_286 = torch.ops.aten.new_zeros.default(convolution_default_286, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_393 = torch.ops.aten.add_.Tensor(getitem_858, relu__default_221);  getitem_858 = None
        relu__default_223 = torch.ops.aten.relu_.default(add__tensor_393);  add__tensor_393 = None
        convolution_default_287 = torch.ops.aten.convolution.default(relu__default_223, primals_1463, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_394 = torch.ops.aten.add_.Tensor(primals_1454, 1);  primals_1454 = None
        native_batch_norm_default_287 = torch.ops.aten.native_batch_norm.default(convolution_default_287, primals_1457, primals_1453, primals_1455, primals_1456, True, 0.1, 1e-05);  primals_1453 = None
        getitem_861 = native_batch_norm_default_287[0]
        getitem_862 = native_batch_norm_default_287[1]
        getitem_863 = native_batch_norm_default_287[2];  native_batch_norm_default_287 = None
        new_zeros_default_287 = torch.ops.aten.new_zeros.default(convolution_default_287, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_224 = torch.ops.aten.relu_.default(getitem_861);  getitem_861 = None
        convolution_default_288 = torch.ops.aten.convolution.default(relu__default_224, primals_1464, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_395 = torch.ops.aten.add_.Tensor(primals_1459, 1);  primals_1459 = None
        native_batch_norm_default_288 = torch.ops.aten.native_batch_norm.default(convolution_default_288, primals_1462, primals_1458, primals_1460, primals_1461, True, 0.1, 1e-05);  primals_1458 = None
        getitem_864 = native_batch_norm_default_288[0]
        getitem_865 = native_batch_norm_default_288[1]
        getitem_866 = native_batch_norm_default_288[2];  native_batch_norm_default_288 = None
        new_zeros_default_288 = torch.ops.aten.new_zeros.default(convolution_default_288, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_396 = torch.ops.aten.add_.Tensor(getitem_864, relu__default_223);  getitem_864 = None
        relu__default_225 = torch.ops.aten.relu_.default(add__tensor_396);  add__tensor_396 = None
        convolution_default_289 = torch.ops.aten.convolution.default(relu__default_209, primals_1735, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_397 = torch.ops.aten.add_.Tensor(primals_1737, 1);  primals_1737 = None
        native_batch_norm_default_289 = torch.ops.aten.native_batch_norm.default(convolution_default_289, primals_1740, primals_1736, primals_1738, primals_1739, True, 0.1, 1e-05);  primals_1736 = None
        getitem_867 = native_batch_norm_default_289[0]
        getitem_868 = native_batch_norm_default_289[1]
        getitem_869 = native_batch_norm_default_289[2];  native_batch_norm_default_289 = None
        new_zeros_default_289 = torch.ops.aten.new_zeros.default(convolution_default_289, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_25 = torch.ops.aten.upsample_nearest2d.vec(getitem_867, None, [2.0, 2.0]);  getitem_867 = None
        add_tensor_50 = torch.ops.aten.add.Tensor(relu__default_201, upsample_nearest2d_vec_25);  upsample_nearest2d_vec_25 = None
        convolution_default_290 = torch.ops.aten.convolution.default(relu__default_217, primals_1843, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_398 = torch.ops.aten.add_.Tensor(primals_1845, 1);  primals_1845 = None
        native_batch_norm_default_290 = torch.ops.aten.native_batch_norm.default(convolution_default_290, primals_1848, primals_1844, primals_1846, primals_1847, True, 0.1, 1e-05);  primals_1844 = None
        getitem_870 = native_batch_norm_default_290[0]
        getitem_871 = native_batch_norm_default_290[1]
        getitem_872 = native_batch_norm_default_290[2];  native_batch_norm_default_290 = None
        new_zeros_default_290 = torch.ops.aten.new_zeros.default(convolution_default_290, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_26 = torch.ops.aten.upsample_nearest2d.vec(getitem_870, None, [4.0, 4.0]);  getitem_870 = None
        add_tensor_51 = torch.ops.aten.add.Tensor(add_tensor_50, upsample_nearest2d_vec_26);  add_tensor_50 = upsample_nearest2d_vec_26 = None
        convolution_default_291 = torch.ops.aten.convolution.default(relu__default_225, primals_1945, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_399 = torch.ops.aten.add_.Tensor(primals_1947, 1);  primals_1947 = None
        native_batch_norm_default_291 = torch.ops.aten.native_batch_norm.default(convolution_default_291, primals_1950, primals_1946, primals_1948, primals_1949, True, 0.1, 1e-05);  primals_1946 = None
        getitem_873 = native_batch_norm_default_291[0]
        getitem_874 = native_batch_norm_default_291[1]
        getitem_875 = native_batch_norm_default_291[2];  native_batch_norm_default_291 = None
        new_zeros_default_291 = torch.ops.aten.new_zeros.default(convolution_default_291, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_27 = torch.ops.aten.upsample_nearest2d.vec(getitem_873, None, [8.0, 8.0]);  getitem_873 = None
        add_tensor_52 = torch.ops.aten.add.Tensor(add_tensor_51, upsample_nearest2d_vec_27);  add_tensor_51 = upsample_nearest2d_vec_27 = None
        relu_default_34 = torch.ops.aten.relu.default(add_tensor_52);  add_tensor_52 = None
        convolution_default_292 = torch.ops.aten.convolution.default(relu__default_201, primals_1561, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_400 = torch.ops.aten.add_.Tensor(primals_1563, 1);  primals_1563 = None
        native_batch_norm_default_292 = torch.ops.aten.native_batch_norm.default(convolution_default_292, primals_1566, primals_1562, primals_1564, primals_1565, True, 0.1, 1e-05);  primals_1562 = None
        getitem_876 = native_batch_norm_default_292[0]
        getitem_877 = native_batch_norm_default_292[1]
        getitem_878 = native_batch_norm_default_292[2];  native_batch_norm_default_292 = None
        new_zeros_default_292 = torch.ops.aten.new_zeros.default(convolution_default_292, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_53 = torch.ops.aten.add.Tensor(getitem_876, relu__default_209);  getitem_876 = None
        convolution_default_293 = torch.ops.aten.convolution.default(relu__default_217, primals_1849, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_401 = torch.ops.aten.add_.Tensor(primals_1851, 1);  primals_1851 = None
        native_batch_norm_default_293 = torch.ops.aten.native_batch_norm.default(convolution_default_293, primals_1854, primals_1850, primals_1852, primals_1853, True, 0.1, 1e-05);  primals_1850 = None
        getitem_879 = native_batch_norm_default_293[0]
        getitem_880 = native_batch_norm_default_293[1]
        getitem_881 = native_batch_norm_default_293[2];  native_batch_norm_default_293 = None
        new_zeros_default_293 = torch.ops.aten.new_zeros.default(convolution_default_293, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_28 = torch.ops.aten.upsample_nearest2d.vec(getitem_879, None, [2.0, 2.0]);  getitem_879 = None
        add_tensor_54 = torch.ops.aten.add.Tensor(add_tensor_53, upsample_nearest2d_vec_28);  add_tensor_53 = upsample_nearest2d_vec_28 = None
        convolution_default_294 = torch.ops.aten.convolution.default(relu__default_225, primals_1951, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_402 = torch.ops.aten.add_.Tensor(primals_1953, 1);  primals_1953 = None
        native_batch_norm_default_294 = torch.ops.aten.native_batch_norm.default(convolution_default_294, primals_1956, primals_1952, primals_1954, primals_1955, True, 0.1, 1e-05);  primals_1952 = None
        getitem_882 = native_batch_norm_default_294[0]
        getitem_883 = native_batch_norm_default_294[1]
        getitem_884 = native_batch_norm_default_294[2];  native_batch_norm_default_294 = None
        new_zeros_default_294 = torch.ops.aten.new_zeros.default(convolution_default_294, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_29 = torch.ops.aten.upsample_nearest2d.vec(getitem_882, None, [4.0, 4.0]);  getitem_882 = None
        add_tensor_55 = torch.ops.aten.add.Tensor(add_tensor_54, upsample_nearest2d_vec_29);  add_tensor_54 = upsample_nearest2d_vec_29 = None
        relu_default_35 = torch.ops.aten.relu.default(add_tensor_55);  add_tensor_55 = None
        convolution_default_295 = torch.ops.aten.convolution.default(relu__default_201, primals_1567, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_403 = torch.ops.aten.add_.Tensor(primals_1569, 1);  primals_1569 = None
        native_batch_norm_default_295 = torch.ops.aten.native_batch_norm.default(convolution_default_295, primals_1572, primals_1568, primals_1570, primals_1571, True, 0.1, 1e-05);  primals_1568 = None
        getitem_885 = native_batch_norm_default_295[0]
        getitem_886 = native_batch_norm_default_295[1]
        getitem_887 = native_batch_norm_default_295[2];  native_batch_norm_default_295 = None
        new_zeros_default_295 = torch.ops.aten.new_zeros.default(convolution_default_295, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_36 = torch.ops.aten.relu.default(getitem_885);  getitem_885 = None
        convolution_default_296 = torch.ops.aten.convolution.default(relu_default_36, primals_1573, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_404 = torch.ops.aten.add_.Tensor(primals_1575, 1);  primals_1575 = None
        native_batch_norm_default_296 = torch.ops.aten.native_batch_norm.default(convolution_default_296, primals_1578, primals_1574, primals_1576, primals_1577, True, 0.1, 1e-05);  primals_1574 = None
        getitem_888 = native_batch_norm_default_296[0]
        getitem_889 = native_batch_norm_default_296[1]
        getitem_890 = native_batch_norm_default_296[2];  native_batch_norm_default_296 = None
        new_zeros_default_296 = torch.ops.aten.new_zeros.default(convolution_default_296, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_297 = torch.ops.aten.convolution.default(relu__default_209, primals_1741, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_405 = torch.ops.aten.add_.Tensor(primals_1743, 1);  primals_1743 = None
        native_batch_norm_default_297 = torch.ops.aten.native_batch_norm.default(convolution_default_297, primals_1746, primals_1742, primals_1744, primals_1745, True, 0.1, 1e-05);  primals_1742 = None
        getitem_891 = native_batch_norm_default_297[0]
        getitem_892 = native_batch_norm_default_297[1]
        getitem_893 = native_batch_norm_default_297[2];  native_batch_norm_default_297 = None
        new_zeros_default_297 = torch.ops.aten.new_zeros.default(convolution_default_297, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_56 = torch.ops.aten.add.Tensor(getitem_888, getitem_891);  getitem_888 = getitem_891 = None
        add_tensor_57 = torch.ops.aten.add.Tensor(add_tensor_56, relu__default_217);  add_tensor_56 = None
        convolution_default_298 = torch.ops.aten.convolution.default(relu__default_225, primals_1909, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_406 = torch.ops.aten.add_.Tensor(primals_1911, 1);  primals_1911 = None
        native_batch_norm_default_298 = torch.ops.aten.native_batch_norm.default(convolution_default_298, primals_1914, primals_1910, primals_1912, primals_1913, True, 0.1, 1e-05);  primals_1910 = None
        getitem_894 = native_batch_norm_default_298[0]
        getitem_895 = native_batch_norm_default_298[1]
        getitem_896 = native_batch_norm_default_298[2];  native_batch_norm_default_298 = None
        new_zeros_default_298 = torch.ops.aten.new_zeros.default(convolution_default_298, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        upsample_nearest2d_vec_30 = torch.ops.aten.upsample_nearest2d.vec(getitem_894, None, [2.0, 2.0]);  getitem_894 = None
        add_tensor_58 = torch.ops.aten.add.Tensor(add_tensor_57, upsample_nearest2d_vec_30);  add_tensor_57 = upsample_nearest2d_vec_30 = None
        relu_default_37 = torch.ops.aten.relu.default(add_tensor_58);  add_tensor_58 = None
        convolution_default_299 = torch.ops.aten.convolution.default(relu__default_201, primals_1579, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_407 = torch.ops.aten.add_.Tensor(primals_1581, 1);  primals_1581 = None
        native_batch_norm_default_299 = torch.ops.aten.native_batch_norm.default(convolution_default_299, primals_1584, primals_1580, primals_1582, primals_1583, True, 0.1, 1e-05);  primals_1580 = None
        getitem_897 = native_batch_norm_default_299[0]
        getitem_898 = native_batch_norm_default_299[1]
        getitem_899 = native_batch_norm_default_299[2];  native_batch_norm_default_299 = None
        new_zeros_default_299 = torch.ops.aten.new_zeros.default(convolution_default_299, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_38 = torch.ops.aten.relu.default(getitem_897);  getitem_897 = None
        convolution_default_300 = torch.ops.aten.convolution.default(relu_default_38, primals_1585, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_408 = torch.ops.aten.add_.Tensor(primals_1587, 1);  primals_1587 = None
        native_batch_norm_default_300 = torch.ops.aten.native_batch_norm.default(convolution_default_300, primals_1590, primals_1586, primals_1588, primals_1589, True, 0.1, 1e-05);  primals_1586 = None
        getitem_900 = native_batch_norm_default_300[0]
        getitem_901 = native_batch_norm_default_300[1]
        getitem_902 = native_batch_norm_default_300[2];  native_batch_norm_default_300 = None
        new_zeros_default_300 = torch.ops.aten.new_zeros.default(convolution_default_300, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_39 = torch.ops.aten.relu.default(getitem_900);  getitem_900 = None
        convolution_default_301 = torch.ops.aten.convolution.default(relu_default_39, primals_1591, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_409 = torch.ops.aten.add_.Tensor(primals_1593, 1);  primals_1593 = None
        native_batch_norm_default_301 = torch.ops.aten.native_batch_norm.default(convolution_default_301, primals_1596, primals_1592, primals_1594, primals_1595, True, 0.1, 1e-05);  primals_1592 = None
        getitem_903 = native_batch_norm_default_301[0]
        getitem_904 = native_batch_norm_default_301[1]
        getitem_905 = native_batch_norm_default_301[2];  native_batch_norm_default_301 = None
        new_zeros_default_301 = torch.ops.aten.new_zeros.default(convolution_default_301, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_302 = torch.ops.aten.convolution.default(relu__default_209, primals_1747, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_410 = torch.ops.aten.add_.Tensor(primals_1749, 1);  primals_1749 = None
        native_batch_norm_default_302 = torch.ops.aten.native_batch_norm.default(convolution_default_302, primals_1752, primals_1748, primals_1750, primals_1751, True, 0.1, 1e-05);  primals_1748 = None
        getitem_906 = native_batch_norm_default_302[0]
        getitem_907 = native_batch_norm_default_302[1]
        getitem_908 = native_batch_norm_default_302[2];  native_batch_norm_default_302 = None
        new_zeros_default_302 = torch.ops.aten.new_zeros.default(convolution_default_302, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_40 = torch.ops.aten.relu.default(getitem_906);  getitem_906 = None
        convolution_default_303 = torch.ops.aten.convolution.default(relu_default_40, primals_1753, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_411 = torch.ops.aten.add_.Tensor(primals_1755, 1);  primals_1755 = None
        native_batch_norm_default_303 = torch.ops.aten.native_batch_norm.default(convolution_default_303, primals_1758, primals_1754, primals_1756, primals_1757, True, 0.1, 1e-05);  primals_1754 = None
        getitem_909 = native_batch_norm_default_303[0]
        getitem_910 = native_batch_norm_default_303[1]
        getitem_911 = native_batch_norm_default_303[2];  native_batch_norm_default_303 = None
        new_zeros_default_303 = torch.ops.aten.new_zeros.default(convolution_default_303, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_59 = torch.ops.aten.add.Tensor(getitem_903, getitem_909);  getitem_903 = getitem_909 = None
        convolution_default_304 = torch.ops.aten.convolution.default(relu__default_217, primals_1855, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_412 = torch.ops.aten.add_.Tensor(primals_1857, 1);  primals_1857 = None
        native_batch_norm_default_304 = torch.ops.aten.native_batch_norm.default(convolution_default_304, primals_1860, primals_1856, primals_1858, primals_1859, True, 0.1, 1e-05);  primals_1856 = None
        getitem_912 = native_batch_norm_default_304[0]
        getitem_913 = native_batch_norm_default_304[1]
        getitem_914 = native_batch_norm_default_304[2];  native_batch_norm_default_304 = None
        new_zeros_default_304 = torch.ops.aten.new_zeros.default(convolution_default_304, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_60 = torch.ops.aten.add.Tensor(add_tensor_59, getitem_912);  add_tensor_59 = getitem_912 = None
        add_tensor_61 = torch.ops.aten.add.Tensor(add_tensor_60, relu__default_225);  add_tensor_60 = None
        relu_default_41 = torch.ops.aten.relu.default(add_tensor_61);  add_tensor_61 = None
        convolution_default_305 = torch.ops.aten.convolution.default(relu_default_34, primals_58, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_413 = torch.ops.aten.add_.Tensor(primals_44, 1);  primals_44 = None
        native_batch_norm_default_305 = torch.ops.aten.native_batch_norm.default(convolution_default_305, primals_47, primals_43, primals_45, primals_46, True, 0.1, 1e-05);  primals_43 = None
        getitem_915 = native_batch_norm_default_305[0]
        getitem_916 = native_batch_norm_default_305[1]
        getitem_917 = native_batch_norm_default_305[2];  native_batch_norm_default_305 = None
        new_zeros_default_305 = torch.ops.aten.new_zeros.default(convolution_default_305, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_226 = torch.ops.aten.relu_.default(getitem_915);  getitem_915 = None
        convolution_default_306 = torch.ops.aten.convolution.default(relu__default_226, primals_59, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_414 = torch.ops.aten.add_.Tensor(primals_49, 1);  primals_49 = None
        native_batch_norm_default_306 = torch.ops.aten.native_batch_norm.default(convolution_default_306, primals_52, primals_48, primals_50, primals_51, True, 0.1, 1e-05);  primals_48 = None
        getitem_918 = native_batch_norm_default_306[0]
        getitem_919 = native_batch_norm_default_306[1]
        getitem_920 = native_batch_norm_default_306[2];  native_batch_norm_default_306 = None
        new_zeros_default_306 = torch.ops.aten.new_zeros.default(convolution_default_306, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_227 = torch.ops.aten.relu_.default(getitem_918);  getitem_918 = None
        convolution_default_307 = torch.ops.aten.convolution.default(relu__default_227, primals_60, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_415 = torch.ops.aten.add_.Tensor(primals_54, 1);  primals_54 = None
        native_batch_norm_default_307 = torch.ops.aten.native_batch_norm.default(convolution_default_307, primals_57, primals_53, primals_55, primals_56, True, 0.1, 1e-05);  primals_53 = None
        getitem_921 = native_batch_norm_default_307[0]
        getitem_922 = native_batch_norm_default_307[1]
        getitem_923 = native_batch_norm_default_307[2];  native_batch_norm_default_307 = None
        new_zeros_default_307 = torch.ops.aten.new_zeros.default(convolution_default_307, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_308 = torch.ops.aten.convolution.default(relu_default_34, primals_61, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_416 = torch.ops.aten.add_.Tensor(primals_63, 1);  primals_63 = None
        native_batch_norm_default_308 = torch.ops.aten.native_batch_norm.default(convolution_default_308, primals_66, primals_62, primals_64, primals_65, True, 0.1, 1e-05);  primals_62 = None
        getitem_924 = native_batch_norm_default_308[0]
        getitem_925 = native_batch_norm_default_308[1]
        getitem_926 = native_batch_norm_default_308[2];  native_batch_norm_default_308 = None
        new_zeros_default_308 = torch.ops.aten.new_zeros.default(convolution_default_308, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_417 = torch.ops.aten.add_.Tensor(getitem_921, getitem_924);  getitem_921 = getitem_924 = None
        relu__default_228 = torch.ops.aten.relu_.default(add__tensor_417);  add__tensor_417 = None
        convolution_default_309 = torch.ops.aten.convolution.default(relu_default_35, primals_82, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_418 = torch.ops.aten.add_.Tensor(primals_68, 1);  primals_68 = None
        native_batch_norm_default_309 = torch.ops.aten.native_batch_norm.default(convolution_default_309, primals_71, primals_67, primals_69, primals_70, True, 0.1, 1e-05);  primals_67 = None
        getitem_927 = native_batch_norm_default_309[0]
        getitem_928 = native_batch_norm_default_309[1]
        getitem_929 = native_batch_norm_default_309[2];  native_batch_norm_default_309 = None
        new_zeros_default_309 = torch.ops.aten.new_zeros.default(convolution_default_309, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_229 = torch.ops.aten.relu_.default(getitem_927);  getitem_927 = None
        convolution_default_310 = torch.ops.aten.convolution.default(relu__default_229, primals_83, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_419 = torch.ops.aten.add_.Tensor(primals_73, 1);  primals_73 = None
        native_batch_norm_default_310 = torch.ops.aten.native_batch_norm.default(convolution_default_310, primals_76, primals_72, primals_74, primals_75, True, 0.1, 1e-05);  primals_72 = None
        getitem_930 = native_batch_norm_default_310[0]
        getitem_931 = native_batch_norm_default_310[1]
        getitem_932 = native_batch_norm_default_310[2];  native_batch_norm_default_310 = None
        new_zeros_default_310 = torch.ops.aten.new_zeros.default(convolution_default_310, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_230 = torch.ops.aten.relu_.default(getitem_930);  getitem_930 = None
        convolution_default_311 = torch.ops.aten.convolution.default(relu__default_230, primals_84, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_420 = torch.ops.aten.add_.Tensor(primals_78, 1);  primals_78 = None
        native_batch_norm_default_311 = torch.ops.aten.native_batch_norm.default(convolution_default_311, primals_81, primals_77, primals_79, primals_80, True, 0.1, 1e-05);  primals_77 = None
        getitem_933 = native_batch_norm_default_311[0]
        getitem_934 = native_batch_norm_default_311[1]
        getitem_935 = native_batch_norm_default_311[2];  native_batch_norm_default_311 = None
        new_zeros_default_311 = torch.ops.aten.new_zeros.default(convolution_default_311, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_312 = torch.ops.aten.convolution.default(relu_default_35, primals_85, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_421 = torch.ops.aten.add_.Tensor(primals_87, 1);  primals_87 = None
        native_batch_norm_default_312 = torch.ops.aten.native_batch_norm.default(convolution_default_312, primals_90, primals_86, primals_88, primals_89, True, 0.1, 1e-05);  primals_86 = None
        getitem_936 = native_batch_norm_default_312[0]
        getitem_937 = native_batch_norm_default_312[1]
        getitem_938 = native_batch_norm_default_312[2];  native_batch_norm_default_312 = None
        new_zeros_default_312 = torch.ops.aten.new_zeros.default(convolution_default_312, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_422 = torch.ops.aten.add_.Tensor(getitem_933, getitem_936);  getitem_933 = getitem_936 = None
        relu__default_231 = torch.ops.aten.relu_.default(add__tensor_422);  add__tensor_422 = None
        convolution_default_313 = torch.ops.aten.convolution.default(relu__default_228, primals_16, primals_15, [2, 2], [1, 1], [1, 1], False, [0, 0], 1);  primals_15 = None
        add__tensor_423 = torch.ops.aten.add_.Tensor(primals_18, 1);  primals_18 = None
        native_batch_norm_default_313 = torch.ops.aten.native_batch_norm.default(convolution_default_313, primals_21, primals_17, primals_19, primals_20, True, 0.1, 1e-05);  primals_17 = None
        getitem_939 = native_batch_norm_default_313[0]
        getitem_940 = native_batch_norm_default_313[1]
        getitem_941 = native_batch_norm_default_313[2];  native_batch_norm_default_313 = None
        new_zeros_default_313 = torch.ops.aten.new_zeros.default(convolution_default_313, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_232 = torch.ops.aten.relu_.default(getitem_939);  getitem_939 = None
        add_tensor_62 = torch.ops.aten.add.Tensor(relu__default_231, relu__default_232)
        convolution_default_314 = torch.ops.aten.convolution.default(relu_default_37, primals_106, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_424 = torch.ops.aten.add_.Tensor(primals_92, 1);  primals_92 = None
        native_batch_norm_default_314 = torch.ops.aten.native_batch_norm.default(convolution_default_314, primals_95, primals_91, primals_93, primals_94, True, 0.1, 1e-05);  primals_91 = None
        getitem_942 = native_batch_norm_default_314[0]
        getitem_943 = native_batch_norm_default_314[1]
        getitem_944 = native_batch_norm_default_314[2];  native_batch_norm_default_314 = None
        new_zeros_default_314 = torch.ops.aten.new_zeros.default(convolution_default_314, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_233 = torch.ops.aten.relu_.default(getitem_942);  getitem_942 = None
        convolution_default_315 = torch.ops.aten.convolution.default(relu__default_233, primals_107, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_425 = torch.ops.aten.add_.Tensor(primals_97, 1);  primals_97 = None
        native_batch_norm_default_315 = torch.ops.aten.native_batch_norm.default(convolution_default_315, primals_100, primals_96, primals_98, primals_99, True, 0.1, 1e-05);  primals_96 = None
        getitem_945 = native_batch_norm_default_315[0]
        getitem_946 = native_batch_norm_default_315[1]
        getitem_947 = native_batch_norm_default_315[2];  native_batch_norm_default_315 = None
        new_zeros_default_315 = torch.ops.aten.new_zeros.default(convolution_default_315, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_234 = torch.ops.aten.relu_.default(getitem_945);  getitem_945 = None
        convolution_default_316 = torch.ops.aten.convolution.default(relu__default_234, primals_108, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_426 = torch.ops.aten.add_.Tensor(primals_102, 1);  primals_102 = None
        native_batch_norm_default_316 = torch.ops.aten.native_batch_norm.default(convolution_default_316, primals_105, primals_101, primals_103, primals_104, True, 0.1, 1e-05);  primals_101 = None
        getitem_948 = native_batch_norm_default_316[0]
        getitem_949 = native_batch_norm_default_316[1]
        getitem_950 = native_batch_norm_default_316[2];  native_batch_norm_default_316 = None
        new_zeros_default_316 = torch.ops.aten.new_zeros.default(convolution_default_316, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_317 = torch.ops.aten.convolution.default(relu_default_37, primals_109, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_427 = torch.ops.aten.add_.Tensor(primals_111, 1);  primals_111 = None
        native_batch_norm_default_317 = torch.ops.aten.native_batch_norm.default(convolution_default_317, primals_114, primals_110, primals_112, primals_113, True, 0.1, 1e-05);  primals_110 = None
        getitem_951 = native_batch_norm_default_317[0]
        getitem_952 = native_batch_norm_default_317[1]
        getitem_953 = native_batch_norm_default_317[2];  native_batch_norm_default_317 = None
        new_zeros_default_317 = torch.ops.aten.new_zeros.default(convolution_default_317, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_428 = torch.ops.aten.add_.Tensor(getitem_948, getitem_951);  getitem_948 = getitem_951 = None
        relu__default_235 = torch.ops.aten.relu_.default(add__tensor_428);  add__tensor_428 = None
        convolution_default_318 = torch.ops.aten.convolution.default(add_tensor_62, primals_23, primals_22, [2, 2], [1, 1], [1, 1], False, [0, 0], 1);  primals_22 = None
        add__tensor_429 = torch.ops.aten.add_.Tensor(primals_25, 1);  primals_25 = None
        native_batch_norm_default_318 = torch.ops.aten.native_batch_norm.default(convolution_default_318, primals_28, primals_24, primals_26, primals_27, True, 0.1, 1e-05);  primals_24 = None
        getitem_954 = native_batch_norm_default_318[0]
        getitem_955 = native_batch_norm_default_318[1]
        getitem_956 = native_batch_norm_default_318[2];  native_batch_norm_default_318 = None
        new_zeros_default_318 = torch.ops.aten.new_zeros.default(convolution_default_318, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_236 = torch.ops.aten.relu_.default(getitem_954);  getitem_954 = None
        add_tensor_63 = torch.ops.aten.add.Tensor(relu__default_235, relu__default_236)
        convolution_default_319 = torch.ops.aten.convolution.default(relu_default_41, primals_130, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_430 = torch.ops.aten.add_.Tensor(primals_116, 1);  primals_116 = None
        native_batch_norm_default_319 = torch.ops.aten.native_batch_norm.default(convolution_default_319, primals_119, primals_115, primals_117, primals_118, True, 0.1, 1e-05);  primals_115 = None
        getitem_957 = native_batch_norm_default_319[0]
        getitem_958 = native_batch_norm_default_319[1]
        getitem_959 = native_batch_norm_default_319[2];  native_batch_norm_default_319 = None
        new_zeros_default_319 = torch.ops.aten.new_zeros.default(convolution_default_319, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_237 = torch.ops.aten.relu_.default(getitem_957);  getitem_957 = None
        convolution_default_320 = torch.ops.aten.convolution.default(relu__default_237, primals_131, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_431 = torch.ops.aten.add_.Tensor(primals_121, 1);  primals_121 = None
        native_batch_norm_default_320 = torch.ops.aten.native_batch_norm.default(convolution_default_320, primals_124, primals_120, primals_122, primals_123, True, 0.1, 1e-05);  primals_120 = None
        getitem_960 = native_batch_norm_default_320[0]
        getitem_961 = native_batch_norm_default_320[1]
        getitem_962 = native_batch_norm_default_320[2];  native_batch_norm_default_320 = None
        new_zeros_default_320 = torch.ops.aten.new_zeros.default(convolution_default_320, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_238 = torch.ops.aten.relu_.default(getitem_960);  getitem_960 = None
        convolution_default_321 = torch.ops.aten.convolution.default(relu__default_238, primals_132, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_432 = torch.ops.aten.add_.Tensor(primals_126, 1);  primals_126 = None
        native_batch_norm_default_321 = torch.ops.aten.native_batch_norm.default(convolution_default_321, primals_129, primals_125, primals_127, primals_128, True, 0.1, 1e-05);  primals_125 = None
        getitem_963 = native_batch_norm_default_321[0]
        getitem_964 = native_batch_norm_default_321[1]
        getitem_965 = native_batch_norm_default_321[2];  native_batch_norm_default_321 = None
        new_zeros_default_321 = torch.ops.aten.new_zeros.default(convolution_default_321, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_322 = torch.ops.aten.convolution.default(relu_default_41, primals_133, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_433 = torch.ops.aten.add_.Tensor(primals_135, 1);  primals_135 = None
        native_batch_norm_default_322 = torch.ops.aten.native_batch_norm.default(convolution_default_322, primals_138, primals_134, primals_136, primals_137, True, 0.1, 1e-05);  primals_134 = None
        getitem_966 = native_batch_norm_default_322[0]
        getitem_967 = native_batch_norm_default_322[1]
        getitem_968 = native_batch_norm_default_322[2];  native_batch_norm_default_322 = None
        new_zeros_default_322 = torch.ops.aten.new_zeros.default(convolution_default_322, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_434 = torch.ops.aten.add_.Tensor(getitem_963, getitem_966);  getitem_963 = getitem_966 = None
        relu__default_239 = torch.ops.aten.relu_.default(add__tensor_434);  add__tensor_434 = None
        convolution_default_323 = torch.ops.aten.convolution.default(add_tensor_63, primals_30, primals_29, [2, 2], [1, 1], [1, 1], False, [0, 0], 1);  primals_29 = None
        add__tensor_435 = torch.ops.aten.add_.Tensor(primals_32, 1);  primals_32 = None
        native_batch_norm_default_323 = torch.ops.aten.native_batch_norm.default(convolution_default_323, primals_35, primals_31, primals_33, primals_34, True, 0.1, 1e-05);  primals_31 = None
        getitem_969 = native_batch_norm_default_323[0]
        getitem_970 = native_batch_norm_default_323[1]
        getitem_971 = native_batch_norm_default_323[2];  native_batch_norm_default_323 = None
        new_zeros_default_323 = torch.ops.aten.new_zeros.default(convolution_default_323, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_240 = torch.ops.aten.relu_.default(getitem_969);  getitem_969 = None
        add_tensor_64 = torch.ops.aten.add.Tensor(relu__default_239, relu__default_240)
        convolution_default_324 = torch.ops.aten.convolution.default(add_tensor_64, primals_37, primals_36, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_36 = None
        add__tensor_436 = torch.ops.aten.add_.Tensor(primals_39, 1);  primals_39 = None
        native_batch_norm_default_324 = torch.ops.aten.native_batch_norm.default(convolution_default_324, primals_42, primals_38, primals_40, primals_41, True, 0.1, 1e-05);  primals_38 = None
        getitem_972 = native_batch_norm_default_324[0]
        getitem_973 = native_batch_norm_default_324[1]
        getitem_974 = native_batch_norm_default_324[2];  native_batch_norm_default_324 = None
        new_zeros_default_324 = torch.ops.aten.new_zeros.default(convolution_default_324, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_241 = torch.ops.aten.relu_.default(getitem_972);  getitem_972 = None
        mean_dim = torch.ops.aten.mean.dim(relu__default_241, [-1, -2], True)
        view_default = torch.ops.aten.view.default(mean_dim, [128, 2048]);  mean_dim = None
        t_default = torch.ops.aten.t.default(primals_12);  primals_12 = None
        addmm_default = torch.ops.aten.addmm.default(primals_11, view_default, t_default);  primals_11 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(addmm_default, tangents_1)
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, view_default);  t_default_2 = view_default = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_1 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        view_default_2 = torch.ops.aten.view.default(mm_default, [128, 2048, 1, 1]);  mm_default = None
        expand_default = torch.ops.aten.expand.default(view_default_2, [128, 2048, 7, 7]);  view_default_2 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 49);  expand_default = None
        to_dtype = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default_241, torch.float32);  relu__default_241 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default_325 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_325, to_dtype);  le_scalar = new_zeros_default_325 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_2, convolution_default_324, primals_42, primals_40, primals_41, getitem_973, getitem_974, True, 1e-05, [True, True, True]);  to_dtype_2 = convolution_default_324 = primals_42 = primals_40 = primals_41 = getitem_973 = getitem_974 = None
        getitem_975 = native_batch_norm_backward_default[0]
        getitem_976 = native_batch_norm_backward_default[1]
        getitem_977 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(getitem_975, add_tensor_64, primals_37, [2048], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_975 = add_tensor_64 = primals_37 = None
        getitem_978 = convolution_backward_default[0]
        getitem_979 = convolution_backward_default[1]
        getitem_980 = convolution_backward_default[2];  convolution_backward_default = None
        to_dtype_3 = torch.ops.aten.to.dtype(getitem_978, torch.float32)
        to_dtype_4 = torch.ops.aten.to.dtype(relu__default_240, torch.float32);  relu__default_240 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_326 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_326, to_dtype_3);  le_scalar_1 = new_zeros_default_326 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_5, convolution_default_323, primals_35, primals_33, primals_34, getitem_970, getitem_971, True, 1e-05, [True, True, True]);  to_dtype_5 = convolution_default_323 = primals_35 = primals_33 = primals_34 = getitem_970 = getitem_971 = None
        getitem_981 = native_batch_norm_backward_default_1[0]
        getitem_982 = native_batch_norm_backward_default_1[1]
        getitem_983 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_981, add_tensor_63, primals_30, [1024], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_981 = add_tensor_63 = primals_30 = None
        getitem_984 = convolution_backward_default_1[0]
        getitem_985 = convolution_backward_default_1[1]
        getitem_986 = convolution_backward_default_1[2];  convolution_backward_default_1 = None
        to_dtype_6 = torch.ops.aten.to.dtype(getitem_978, torch.float32);  getitem_978 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_239, torch.float32);  relu__default_239 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_327 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_327, to_dtype_6);  le_scalar_2 = new_zeros_default_327 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_8, convolution_default_322, primals_138, primals_136, primals_137, getitem_967, getitem_968, True, 1e-05, [True, True, True]);  convolution_default_322 = primals_138 = primals_136 = primals_137 = getitem_967 = getitem_968 = None
        getitem_987 = native_batch_norm_backward_default_2[0]
        getitem_988 = native_batch_norm_backward_default_2[1]
        getitem_989 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_987, relu_default_41, primals_133, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_987 = primals_133 = None
        getitem_990 = convolution_backward_default_2[0]
        getitem_991 = convolution_backward_default_2[1]
        getitem_992 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_8, convolution_default_321, primals_129, primals_127, primals_128, getitem_964, getitem_965, True, 1e-05, [True, True, True]);  to_dtype_8 = convolution_default_321 = primals_129 = primals_127 = primals_128 = getitem_964 = getitem_965 = None
        getitem_993 = native_batch_norm_backward_default_3[0]
        getitem_994 = native_batch_norm_backward_default_3[1]
        getitem_995 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_993, relu__default_238, primals_132, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_993 = primals_132 = None
        getitem_996 = convolution_backward_default_3[0]
        getitem_997 = convolution_backward_default_3[1]
        getitem_998 = convolution_backward_default_3[2];  convolution_backward_default_3 = None
        to_dtype_9 = torch.ops.aten.to.dtype(getitem_996, torch.float32);  getitem_996 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu__default_238, torch.float32);  relu__default_238 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_328 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_328, to_dtype_9);  le_scalar_3 = new_zeros_default_328 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_320, primals_124, primals_122, primals_123, getitem_961, getitem_962, True, 1e-05, [True, True, True]);  to_dtype_11 = convolution_default_320 = primals_124 = primals_122 = primals_123 = getitem_961 = getitem_962 = None
        getitem_999 = native_batch_norm_backward_default_4[0]
        getitem_1000 = native_batch_norm_backward_default_4[1]
        getitem_1001 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_999, relu__default_237, primals_131, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_999 = primals_131 = None
        getitem_1002 = convolution_backward_default_4[0]
        getitem_1003 = convolution_backward_default_4[1]
        getitem_1004 = convolution_backward_default_4[2];  convolution_backward_default_4 = None
        to_dtype_12 = torch.ops.aten.to.dtype(getitem_1002, torch.float32);  getitem_1002 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_237, torch.float32);  relu__default_237 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_329 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_329, to_dtype_12);  le_scalar_4 = new_zeros_default_329 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_319, primals_119, primals_117, primals_118, getitem_958, getitem_959, True, 1e-05, [True, True, True]);  to_dtype_14 = convolution_default_319 = primals_119 = primals_117 = primals_118 = getitem_958 = getitem_959 = None
        getitem_1005 = native_batch_norm_backward_default_5[0]
        getitem_1006 = native_batch_norm_backward_default_5[1]
        getitem_1007 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_1005, relu_default_41, primals_130, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1005 = primals_130 = None
        getitem_1008 = convolution_backward_default_5[0]
        getitem_1009 = convolution_backward_default_5[1]
        getitem_1010 = convolution_backward_default_5[2];  convolution_backward_default_5 = None
        add_tensor_65 = torch.ops.aten.add.Tensor(getitem_990, getitem_1008);  getitem_990 = getitem_1008 = None
        to_dtype_15 = torch.ops.aten.to.dtype(getitem_984, torch.float32)
        to_dtype_16 = torch.ops.aten.to.dtype(relu__default_236, torch.float32);  relu__default_236 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_330 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_330, to_dtype_15);  le_scalar_5 = new_zeros_default_330 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_17, convolution_default_318, primals_28, primals_26, primals_27, getitem_955, getitem_956, True, 1e-05, [True, True, True]);  to_dtype_17 = convolution_default_318 = primals_28 = primals_26 = primals_27 = getitem_955 = getitem_956 = None
        getitem_1011 = native_batch_norm_backward_default_6[0]
        getitem_1012 = native_batch_norm_backward_default_6[1]
        getitem_1013 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(getitem_1011, add_tensor_62, primals_23, [512], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_1011 = add_tensor_62 = primals_23 = None
        getitem_1014 = convolution_backward_default_6[0]
        getitem_1015 = convolution_backward_default_6[1]
        getitem_1016 = convolution_backward_default_6[2];  convolution_backward_default_6 = None
        to_dtype_18 = torch.ops.aten.to.dtype(getitem_984, torch.float32);  getitem_984 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu__default_235, torch.float32);  relu__default_235 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_331 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_331, to_dtype_18);  le_scalar_6 = new_zeros_default_331 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_20, convolution_default_317, primals_114, primals_112, primals_113, getitem_952, getitem_953, True, 1e-05, [True, True, True]);  convolution_default_317 = primals_114 = primals_112 = primals_113 = getitem_952 = getitem_953 = None
        getitem_1017 = native_batch_norm_backward_default_7[0]
        getitem_1018 = native_batch_norm_backward_default_7[1]
        getitem_1019 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(getitem_1017, relu_default_37, primals_109, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1017 = primals_109 = None
        getitem_1020 = convolution_backward_default_7[0]
        getitem_1021 = convolution_backward_default_7[1]
        getitem_1022 = convolution_backward_default_7[2];  convolution_backward_default_7 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_20, convolution_default_316, primals_105, primals_103, primals_104, getitem_949, getitem_950, True, 1e-05, [True, True, True]);  to_dtype_20 = convolution_default_316 = primals_105 = primals_103 = primals_104 = getitem_949 = getitem_950 = None
        getitem_1023 = native_batch_norm_backward_default_8[0]
        getitem_1024 = native_batch_norm_backward_default_8[1]
        getitem_1025 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(getitem_1023, relu__default_234, primals_108, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1023 = primals_108 = None
        getitem_1026 = convolution_backward_default_8[0]
        getitem_1027 = convolution_backward_default_8[1]
        getitem_1028 = convolution_backward_default_8[2];  convolution_backward_default_8 = None
        to_dtype_21 = torch.ops.aten.to.dtype(getitem_1026, torch.float32);  getitem_1026 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_234, torch.float32);  relu__default_234 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_332 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_332, to_dtype_21);  le_scalar_7 = new_zeros_default_332 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_23, convolution_default_315, primals_100, primals_98, primals_99, getitem_946, getitem_947, True, 1e-05, [True, True, True]);  to_dtype_23 = convolution_default_315 = primals_100 = primals_98 = primals_99 = getitem_946 = getitem_947 = None
        getitem_1029 = native_batch_norm_backward_default_9[0]
        getitem_1030 = native_batch_norm_backward_default_9[1]
        getitem_1031 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_1029, relu__default_233, primals_107, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1029 = primals_107 = None
        getitem_1032 = convolution_backward_default_9[0]
        getitem_1033 = convolution_backward_default_9[1]
        getitem_1034 = convolution_backward_default_9[2];  convolution_backward_default_9 = None
        to_dtype_24 = torch.ops.aten.to.dtype(getitem_1032, torch.float32);  getitem_1032 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_233, torch.float32);  relu__default_233 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_333 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_333, to_dtype_24);  le_scalar_8 = new_zeros_default_333 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_314, primals_95, primals_93, primals_94, getitem_943, getitem_944, True, 1e-05, [True, True, True]);  to_dtype_26 = convolution_default_314 = primals_95 = primals_93 = primals_94 = getitem_943 = getitem_944 = None
        getitem_1035 = native_batch_norm_backward_default_10[0]
        getitem_1036 = native_batch_norm_backward_default_10[1]
        getitem_1037 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_1035, relu_default_37, primals_106, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1035 = primals_106 = None
        getitem_1038 = convolution_backward_default_10[0]
        getitem_1039 = convolution_backward_default_10[1]
        getitem_1040 = convolution_backward_default_10[2];  convolution_backward_default_10 = None
        add_tensor_66 = torch.ops.aten.add.Tensor(getitem_1020, getitem_1038);  getitem_1020 = getitem_1038 = None
        to_dtype_27 = torch.ops.aten.to.dtype(getitem_1014, torch.float32)
        to_dtype_28 = torch.ops.aten.to.dtype(relu__default_232, torch.float32);  relu__default_232 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_334 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_334, to_dtype_27);  le_scalar_9 = new_zeros_default_334 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_29, convolution_default_313, primals_21, primals_19, primals_20, getitem_940, getitem_941, True, 1e-05, [True, True, True]);  to_dtype_29 = convolution_default_313 = primals_21 = primals_19 = primals_20 = getitem_940 = getitem_941 = None
        getitem_1041 = native_batch_norm_backward_default_11[0]
        getitem_1042 = native_batch_norm_backward_default_11[1]
        getitem_1043 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_1041, relu__default_228, primals_16, [256], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_1041 = primals_16 = None
        getitem_1044 = convolution_backward_default_11[0]
        getitem_1045 = convolution_backward_default_11[1]
        getitem_1046 = convolution_backward_default_11[2];  convolution_backward_default_11 = None
        to_dtype_30 = torch.ops.aten.to.dtype(getitem_1014, torch.float32);  getitem_1014 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu__default_231, torch.float32);  relu__default_231 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_335 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_335, to_dtype_30);  le_scalar_10 = new_zeros_default_335 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default_312, primals_90, primals_88, primals_89, getitem_937, getitem_938, True, 1e-05, [True, True, True]);  convolution_default_312 = primals_90 = primals_88 = primals_89 = getitem_937 = getitem_938 = None
        getitem_1047 = native_batch_norm_backward_default_12[0]
        getitem_1048 = native_batch_norm_backward_default_12[1]
        getitem_1049 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(getitem_1047, relu_default_35, primals_85, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1047 = primals_85 = None
        getitem_1050 = convolution_backward_default_12[0]
        getitem_1051 = convolution_backward_default_12[1]
        getitem_1052 = convolution_backward_default_12[2];  convolution_backward_default_12 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default_311, primals_81, primals_79, primals_80, getitem_934, getitem_935, True, 1e-05, [True, True, True]);  to_dtype_32 = convolution_default_311 = primals_81 = primals_79 = primals_80 = getitem_934 = getitem_935 = None
        getitem_1053 = native_batch_norm_backward_default_13[0]
        getitem_1054 = native_batch_norm_backward_default_13[1]
        getitem_1055 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_1053, relu__default_230, primals_84, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1053 = primals_84 = None
        getitem_1056 = convolution_backward_default_13[0]
        getitem_1057 = convolution_backward_default_13[1]
        getitem_1058 = convolution_backward_default_13[2];  convolution_backward_default_13 = None
        to_dtype_33 = torch.ops.aten.to.dtype(getitem_1056, torch.float32);  getitem_1056 = None
        to_dtype_34 = torch.ops.aten.to.dtype(relu__default_230, torch.float32);  relu__default_230 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        new_zeros_default_336 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_336, to_dtype_33);  le_scalar_11 = new_zeros_default_336 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_35, convolution_default_310, primals_76, primals_74, primals_75, getitem_931, getitem_932, True, 1e-05, [True, True, True]);  to_dtype_35 = convolution_default_310 = primals_76 = primals_74 = primals_75 = getitem_931 = getitem_932 = None
        getitem_1059 = native_batch_norm_backward_default_14[0]
        getitem_1060 = native_batch_norm_backward_default_14[1]
        getitem_1061 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_1059, relu__default_229, primals_83, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1059 = primals_83 = None
        getitem_1062 = convolution_backward_default_14[0]
        getitem_1063 = convolution_backward_default_14[1]
        getitem_1064 = convolution_backward_default_14[2];  convolution_backward_default_14 = None
        to_dtype_36 = torch.ops.aten.to.dtype(getitem_1062, torch.float32);  getitem_1062 = None
        to_dtype_37 = torch.ops.aten.to.dtype(relu__default_229, torch.float32);  relu__default_229 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        new_zeros_default_337 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_337, to_dtype_36);  le_scalar_12 = new_zeros_default_337 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_38, convolution_default_309, primals_71, primals_69, primals_70, getitem_928, getitem_929, True, 1e-05, [True, True, True]);  to_dtype_38 = convolution_default_309 = primals_71 = primals_69 = primals_70 = getitem_928 = getitem_929 = None
        getitem_1065 = native_batch_norm_backward_default_15[0]
        getitem_1066 = native_batch_norm_backward_default_15[1]
        getitem_1067 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_1065, relu_default_35, primals_82, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1065 = primals_82 = None
        getitem_1068 = convolution_backward_default_15[0]
        getitem_1069 = convolution_backward_default_15[1]
        getitem_1070 = convolution_backward_default_15[2];  convolution_backward_default_15 = None
        add_tensor_67 = torch.ops.aten.add.Tensor(getitem_1050, getitem_1068);  getitem_1050 = getitem_1068 = None
        to_dtype_39 = torch.ops.aten.to.dtype(getitem_1044, torch.float32);  getitem_1044 = None
        to_dtype_40 = torch.ops.aten.to.dtype(relu__default_228, torch.float32);  relu__default_228 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        new_zeros_default_338 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_338, to_dtype_39);  le_scalar_13 = new_zeros_default_338 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_41, convolution_default_308, primals_66, primals_64, primals_65, getitem_925, getitem_926, True, 1e-05, [True, True, True]);  convolution_default_308 = primals_66 = primals_64 = primals_65 = getitem_925 = getitem_926 = None
        getitem_1071 = native_batch_norm_backward_default_16[0]
        getitem_1072 = native_batch_norm_backward_default_16[1]
        getitem_1073 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(getitem_1071, relu_default_34, primals_61, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1071 = primals_61 = None
        getitem_1074 = convolution_backward_default_16[0]
        getitem_1075 = convolution_backward_default_16[1]
        getitem_1076 = convolution_backward_default_16[2];  convolution_backward_default_16 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_41, convolution_default_307, primals_57, primals_55, primals_56, getitem_922, getitem_923, True, 1e-05, [True, True, True]);  to_dtype_41 = convolution_default_307 = primals_57 = primals_55 = primals_56 = getitem_922 = getitem_923 = None
        getitem_1077 = native_batch_norm_backward_default_17[0]
        getitem_1078 = native_batch_norm_backward_default_17[1]
        getitem_1079 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(getitem_1077, relu__default_227, primals_60, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1077 = primals_60 = None
        getitem_1080 = convolution_backward_default_17[0]
        getitem_1081 = convolution_backward_default_17[1]
        getitem_1082 = convolution_backward_default_17[2];  convolution_backward_default_17 = None
        to_dtype_42 = torch.ops.aten.to.dtype(getitem_1080, torch.float32);  getitem_1080 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu__default_227, torch.float32);  relu__default_227 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_339 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_339, to_dtype_42);  le_scalar_14 = new_zeros_default_339 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_44, convolution_default_306, primals_52, primals_50, primals_51, getitem_919, getitem_920, True, 1e-05, [True, True, True]);  to_dtype_44 = convolution_default_306 = primals_52 = primals_50 = primals_51 = getitem_919 = getitem_920 = None
        getitem_1083 = native_batch_norm_backward_default_18[0]
        getitem_1084 = native_batch_norm_backward_default_18[1]
        getitem_1085 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(getitem_1083, relu__default_226, primals_59, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1083 = primals_59 = None
        getitem_1086 = convolution_backward_default_18[0]
        getitem_1087 = convolution_backward_default_18[1]
        getitem_1088 = convolution_backward_default_18[2];  convolution_backward_default_18 = None
        to_dtype_45 = torch.ops.aten.to.dtype(getitem_1086, torch.float32);  getitem_1086 = None
        to_dtype_46 = torch.ops.aten.to.dtype(relu__default_226, torch.float32);  relu__default_226 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_46, 0);  to_dtype_46 = None
        new_zeros_default_340 = torch.ops.aten.new_zeros.default(to_dtype_45, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_340, to_dtype_45);  le_scalar_15 = new_zeros_default_340 = to_dtype_45 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_47, convolution_default_305, primals_47, primals_45, primals_46, getitem_916, getitem_917, True, 1e-05, [True, True, True]);  to_dtype_47 = convolution_default_305 = primals_47 = primals_45 = primals_46 = getitem_916 = getitem_917 = None
        getitem_1089 = native_batch_norm_backward_default_19[0]
        getitem_1090 = native_batch_norm_backward_default_19[1]
        getitem_1091 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_1089, relu_default_34, primals_58, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1089 = primals_58 = None
        getitem_1092 = convolution_backward_default_19[0]
        getitem_1093 = convolution_backward_default_19[1]
        getitem_1094 = convolution_backward_default_19[2];  convolution_backward_default_19 = None
        add_tensor_68 = torch.ops.aten.add.Tensor(getitem_1074, getitem_1092);  getitem_1074 = getitem_1092 = None
        to_dtype_48 = torch.ops.aten.to.dtype(add_tensor_65, torch.float32);  add_tensor_65 = None
        to_dtype_49 = torch.ops.aten.to.dtype(relu_default_41, torch.float32);  relu_default_41 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_49, 0);  to_dtype_49 = None
        new_zeros_default_341 = torch.ops.aten.new_zeros.default(to_dtype_48, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_341, to_dtype_48);  le_scalar_16 = new_zeros_default_341 = to_dtype_48 = None
        to_dtype_50 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_50, convolution_default_304, primals_1860, primals_1858, primals_1859, getitem_913, getitem_914, True, 1e-05, [True, True, True]);  convolution_default_304 = primals_1860 = primals_1858 = primals_1859 = getitem_913 = getitem_914 = None
        getitem_1095 = native_batch_norm_backward_default_20[0]
        getitem_1096 = native_batch_norm_backward_default_20[1]
        getitem_1097 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(getitem_1095, relu__default_217, primals_1855, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1095 = primals_1855 = None
        getitem_1098 = convolution_backward_default_20[0]
        getitem_1099 = convolution_backward_default_20[1]
        getitem_1100 = convolution_backward_default_20[2];  convolution_backward_default_20 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_50, convolution_default_303, primals_1758, primals_1756, primals_1757, getitem_910, getitem_911, True, 1e-05, [True, True, True]);  convolution_default_303 = primals_1758 = primals_1756 = primals_1757 = getitem_910 = getitem_911 = None
        getitem_1101 = native_batch_norm_backward_default_21[0]
        getitem_1102 = native_batch_norm_backward_default_21[1]
        getitem_1103 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(getitem_1101, relu_default_40, primals_1753, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1101 = primals_1753 = None
        getitem_1104 = convolution_backward_default_21[0]
        getitem_1105 = convolution_backward_default_21[1]
        getitem_1106 = convolution_backward_default_21[2];  convolution_backward_default_21 = None
        to_dtype_51 = torch.ops.aten.to.dtype(getitem_1104, torch.float32);  getitem_1104 = None
        to_dtype_52 = torch.ops.aten.to.dtype(relu_default_40, torch.float32);  relu_default_40 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_52, 0);  to_dtype_52 = None
        new_zeros_default_342 = torch.ops.aten.new_zeros.default(to_dtype_51, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_17, new_zeros_default_342, to_dtype_51);  le_scalar_17 = new_zeros_default_342 = to_dtype_51 = None
        to_dtype_53 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_53, convolution_default_302, primals_1752, primals_1750, primals_1751, getitem_907, getitem_908, True, 1e-05, [True, True, True]);  to_dtype_53 = convolution_default_302 = primals_1752 = primals_1750 = primals_1751 = getitem_907 = getitem_908 = None
        getitem_1107 = native_batch_norm_backward_default_22[0]
        getitem_1108 = native_batch_norm_backward_default_22[1]
        getitem_1109 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(getitem_1107, relu__default_209, primals_1747, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1107 = primals_1747 = None
        getitem_1110 = convolution_backward_default_22[0]
        getitem_1111 = convolution_backward_default_22[1]
        getitem_1112 = convolution_backward_default_22[2];  convolution_backward_default_22 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_50, convolution_default_301, primals_1596, primals_1594, primals_1595, getitem_904, getitem_905, True, 1e-05, [True, True, True]);  convolution_default_301 = primals_1596 = primals_1594 = primals_1595 = getitem_904 = getitem_905 = None
        getitem_1113 = native_batch_norm_backward_default_23[0]
        getitem_1114 = native_batch_norm_backward_default_23[1]
        getitem_1115 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(getitem_1113, relu_default_39, primals_1591, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1113 = primals_1591 = None
        getitem_1116 = convolution_backward_default_23[0]
        getitem_1117 = convolution_backward_default_23[1]
        getitem_1118 = convolution_backward_default_23[2];  convolution_backward_default_23 = None
        to_dtype_54 = torch.ops.aten.to.dtype(getitem_1116, torch.float32);  getitem_1116 = None
        to_dtype_55 = torch.ops.aten.to.dtype(relu_default_39, torch.float32);  relu_default_39 = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_55, 0);  to_dtype_55 = None
        new_zeros_default_343 = torch.ops.aten.new_zeros.default(to_dtype_54, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_18 = torch.ops.aten.where.self(le_scalar_18, new_zeros_default_343, to_dtype_54);  le_scalar_18 = new_zeros_default_343 = to_dtype_54 = None
        to_dtype_56 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_56, convolution_default_300, primals_1590, primals_1588, primals_1589, getitem_901, getitem_902, True, 1e-05, [True, True, True]);  to_dtype_56 = convolution_default_300 = primals_1590 = primals_1588 = primals_1589 = getitem_901 = getitem_902 = None
        getitem_1119 = native_batch_norm_backward_default_24[0]
        getitem_1120 = native_batch_norm_backward_default_24[1]
        getitem_1121 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_1119, relu_default_38, primals_1585, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1119 = primals_1585 = None
        getitem_1122 = convolution_backward_default_24[0]
        getitem_1123 = convolution_backward_default_24[1]
        getitem_1124 = convolution_backward_default_24[2];  convolution_backward_default_24 = None
        to_dtype_57 = torch.ops.aten.to.dtype(getitem_1122, torch.float32);  getitem_1122 = None
        to_dtype_58 = torch.ops.aten.to.dtype(relu_default_38, torch.float32);  relu_default_38 = None
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_58, 0);  to_dtype_58 = None
        new_zeros_default_344 = torch.ops.aten.new_zeros.default(to_dtype_57, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_19 = torch.ops.aten.where.self(le_scalar_19, new_zeros_default_344, to_dtype_57);  le_scalar_19 = new_zeros_default_344 = to_dtype_57 = None
        to_dtype_59 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_59, convolution_default_299, primals_1584, primals_1582, primals_1583, getitem_898, getitem_899, True, 1e-05, [True, True, True]);  to_dtype_59 = convolution_default_299 = primals_1584 = primals_1582 = primals_1583 = getitem_898 = getitem_899 = None
        getitem_1125 = native_batch_norm_backward_default_25[0]
        getitem_1126 = native_batch_norm_backward_default_25[1]
        getitem_1127 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_1125, relu__default_201, primals_1579, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1125 = primals_1579 = None
        getitem_1128 = convolution_backward_default_25[0]
        getitem_1129 = convolution_backward_default_25[1]
        getitem_1130 = convolution_backward_default_25[2];  convolution_backward_default_25 = None
        to_dtype_60 = torch.ops.aten.to.dtype(add_tensor_66, torch.float32);  add_tensor_66 = None
        to_dtype_61 = torch.ops.aten.to.dtype(relu_default_37, torch.float32);  relu_default_37 = None
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_61, 0);  to_dtype_61 = None
        new_zeros_default_345 = torch.ops.aten.new_zeros.default(to_dtype_60, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_20 = torch.ops.aten.where.self(le_scalar_20, new_zeros_default_345, to_dtype_60);  le_scalar_20 = new_zeros_default_345 = to_dtype_60 = None
        to_dtype_62 = torch.ops.aten.to.dtype(where_self_20, torch.float32);  where_self_20 = None
        upsample_nearest2d_backward_vec = torch.ops.aten.upsample_nearest2d_backward.vec(to_dtype_62, None, [128, 72, 7, 7], [2.0, 2.0])
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(upsample_nearest2d_backward_vec, convolution_default_298, primals_1914, primals_1912, primals_1913, getitem_895, getitem_896, True, 1e-05, [True, True, True]);  upsample_nearest2d_backward_vec = convolution_default_298 = primals_1914 = primals_1912 = primals_1913 = getitem_895 = getitem_896 = None
        getitem_1131 = native_batch_norm_backward_default_26[0]
        getitem_1132 = native_batch_norm_backward_default_26[1]
        getitem_1133 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(getitem_1131, relu__default_225, primals_1909, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1131 = primals_1909 = None
        getitem_1134 = convolution_backward_default_26[0]
        getitem_1135 = convolution_backward_default_26[1]
        getitem_1136 = convolution_backward_default_26[2];  convolution_backward_default_26 = None
        add_tensor_69 = torch.ops.aten.add.Tensor(to_dtype_50, getitem_1134);  to_dtype_50 = getitem_1134 = None
        add_tensor_70 = torch.ops.aten.add.Tensor(getitem_1098, to_dtype_62);  getitem_1098 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_62, convolution_default_297, primals_1746, primals_1744, primals_1745, getitem_892, getitem_893, True, 1e-05, [True, True, True]);  convolution_default_297 = primals_1746 = primals_1744 = primals_1745 = getitem_892 = getitem_893 = None
        getitem_1137 = native_batch_norm_backward_default_27[0]
        getitem_1138 = native_batch_norm_backward_default_27[1]
        getitem_1139 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(getitem_1137, relu__default_209, primals_1741, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1137 = primals_1741 = None
        getitem_1140 = convolution_backward_default_27[0]
        getitem_1141 = convolution_backward_default_27[1]
        getitem_1142 = convolution_backward_default_27[2];  convolution_backward_default_27 = None
        add_tensor_71 = torch.ops.aten.add.Tensor(getitem_1110, getitem_1140);  getitem_1110 = getitem_1140 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_62, convolution_default_296, primals_1578, primals_1576, primals_1577, getitem_889, getitem_890, True, 1e-05, [True, True, True]);  to_dtype_62 = convolution_default_296 = primals_1578 = primals_1576 = primals_1577 = getitem_889 = getitem_890 = None
        getitem_1143 = native_batch_norm_backward_default_28[0]
        getitem_1144 = native_batch_norm_backward_default_28[1]
        getitem_1145 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(getitem_1143, relu_default_36, primals_1573, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1143 = primals_1573 = None
        getitem_1146 = convolution_backward_default_28[0]
        getitem_1147 = convolution_backward_default_28[1]
        getitem_1148 = convolution_backward_default_28[2];  convolution_backward_default_28 = None
        to_dtype_63 = torch.ops.aten.to.dtype(getitem_1146, torch.float32);  getitem_1146 = None
        to_dtype_64 = torch.ops.aten.to.dtype(relu_default_36, torch.float32);  relu_default_36 = None
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_64, 0);  to_dtype_64 = None
        new_zeros_default_346 = torch.ops.aten.new_zeros.default(to_dtype_63, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_21 = torch.ops.aten.where.self(le_scalar_21, new_zeros_default_346, to_dtype_63);  le_scalar_21 = new_zeros_default_346 = to_dtype_63 = None
        to_dtype_65 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_65, convolution_default_295, primals_1572, primals_1570, primals_1571, getitem_886, getitem_887, True, 1e-05, [True, True, True]);  to_dtype_65 = convolution_default_295 = primals_1572 = primals_1570 = primals_1571 = getitem_886 = getitem_887 = None
        getitem_1149 = native_batch_norm_backward_default_29[0]
        getitem_1150 = native_batch_norm_backward_default_29[1]
        getitem_1151 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(getitem_1149, relu__default_201, primals_1567, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1149 = primals_1567 = None
        getitem_1152 = convolution_backward_default_29[0]
        getitem_1153 = convolution_backward_default_29[1]
        getitem_1154 = convolution_backward_default_29[2];  convolution_backward_default_29 = None
        add_tensor_72 = torch.ops.aten.add.Tensor(getitem_1128, getitem_1152);  getitem_1128 = getitem_1152 = None
        to_dtype_66 = torch.ops.aten.to.dtype(add_tensor_67, torch.float32);  add_tensor_67 = None
        to_dtype_67 = torch.ops.aten.to.dtype(relu_default_35, torch.float32);  relu_default_35 = None
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_67, 0);  to_dtype_67 = None
        new_zeros_default_347 = torch.ops.aten.new_zeros.default(to_dtype_66, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_22 = torch.ops.aten.where.self(le_scalar_22, new_zeros_default_347, to_dtype_66);  le_scalar_22 = new_zeros_default_347 = to_dtype_66 = None
        to_dtype_68 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        upsample_nearest2d_backward_vec_1 = torch.ops.aten.upsample_nearest2d_backward.vec(to_dtype_68, None, [128, 36, 7, 7], [4.0, 4.0])
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(upsample_nearest2d_backward_vec_1, convolution_default_294, primals_1956, primals_1954, primals_1955, getitem_883, getitem_884, True, 1e-05, [True, True, True]);  upsample_nearest2d_backward_vec_1 = convolution_default_294 = primals_1956 = primals_1954 = primals_1955 = getitem_883 = getitem_884 = None
        getitem_1155 = native_batch_norm_backward_default_30[0]
        getitem_1156 = native_batch_norm_backward_default_30[1]
        getitem_1157 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_1155, relu__default_225, primals_1951, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1155 = primals_1951 = None
        getitem_1158 = convolution_backward_default_30[0]
        getitem_1159 = convolution_backward_default_30[1]
        getitem_1160 = convolution_backward_default_30[2];  convolution_backward_default_30 = None
        add_tensor_73 = torch.ops.aten.add.Tensor(add_tensor_69, getitem_1158);  add_tensor_69 = getitem_1158 = None
        upsample_nearest2d_backward_vec_2 = torch.ops.aten.upsample_nearest2d_backward.vec(to_dtype_68, None, [128, 36, 14, 14], [2.0, 2.0])
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(upsample_nearest2d_backward_vec_2, convolution_default_293, primals_1854, primals_1852, primals_1853, getitem_880, getitem_881, True, 1e-05, [True, True, True]);  upsample_nearest2d_backward_vec_2 = convolution_default_293 = primals_1854 = primals_1852 = primals_1853 = getitem_880 = getitem_881 = None
        getitem_1161 = native_batch_norm_backward_default_31[0]
        getitem_1162 = native_batch_norm_backward_default_31[1]
        getitem_1163 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(getitem_1161, relu__default_217, primals_1849, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1161 = primals_1849 = None
        getitem_1164 = convolution_backward_default_31[0]
        getitem_1165 = convolution_backward_default_31[1]
        getitem_1166 = convolution_backward_default_31[2];  convolution_backward_default_31 = None
        add_tensor_74 = torch.ops.aten.add.Tensor(add_tensor_70, getitem_1164);  add_tensor_70 = getitem_1164 = None
        add_tensor_75 = torch.ops.aten.add.Tensor(add_tensor_71, to_dtype_68);  add_tensor_71 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_68, convolution_default_292, primals_1566, primals_1564, primals_1565, getitem_877, getitem_878, True, 1e-05, [True, True, True]);  to_dtype_68 = convolution_default_292 = primals_1566 = primals_1564 = primals_1565 = getitem_877 = getitem_878 = None
        getitem_1167 = native_batch_norm_backward_default_32[0]
        getitem_1168 = native_batch_norm_backward_default_32[1]
        getitem_1169 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(getitem_1167, relu__default_201, primals_1561, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1167 = primals_1561 = None
        getitem_1170 = convolution_backward_default_32[0]
        getitem_1171 = convolution_backward_default_32[1]
        getitem_1172 = convolution_backward_default_32[2];  convolution_backward_default_32 = None
        add_tensor_76 = torch.ops.aten.add.Tensor(add_tensor_72, getitem_1170);  add_tensor_72 = getitem_1170 = None
        to_dtype_69 = torch.ops.aten.to.dtype(add_tensor_68, torch.float32);  add_tensor_68 = None
        to_dtype_70 = torch.ops.aten.to.dtype(relu_default_34, torch.float32);  relu_default_34 = None
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_70, 0);  to_dtype_70 = None
        new_zeros_default_348 = torch.ops.aten.new_zeros.default(to_dtype_69, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(le_scalar_23, new_zeros_default_348, to_dtype_69);  le_scalar_23 = new_zeros_default_348 = to_dtype_69 = None
        to_dtype_71 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        upsample_nearest2d_backward_vec_3 = torch.ops.aten.upsample_nearest2d_backward.vec(to_dtype_71, None, [128, 18, 7, 7], [8.0, 8.0])
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(upsample_nearest2d_backward_vec_3, convolution_default_291, primals_1950, primals_1948, primals_1949, getitem_874, getitem_875, True, 1e-05, [True, True, True]);  upsample_nearest2d_backward_vec_3 = convolution_default_291 = primals_1950 = primals_1948 = primals_1949 = getitem_874 = getitem_875 = None
        getitem_1173 = native_batch_norm_backward_default_33[0]
        getitem_1174 = native_batch_norm_backward_default_33[1]
        getitem_1175 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(getitem_1173, relu__default_225, primals_1945, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1173 = primals_1945 = None
        getitem_1176 = convolution_backward_default_33[0]
        getitem_1177 = convolution_backward_default_33[1]
        getitem_1178 = convolution_backward_default_33[2];  convolution_backward_default_33 = None
        add_tensor_77 = torch.ops.aten.add.Tensor(add_tensor_73, getitem_1176);  add_tensor_73 = getitem_1176 = None
        upsample_nearest2d_backward_vec_4 = torch.ops.aten.upsample_nearest2d_backward.vec(to_dtype_71, None, [128, 18, 14, 14], [4.0, 4.0])
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(upsample_nearest2d_backward_vec_4, convolution_default_290, primals_1848, primals_1846, primals_1847, getitem_871, getitem_872, True, 1e-05, [True, True, True]);  upsample_nearest2d_backward_vec_4 = convolution_default_290 = primals_1848 = primals_1846 = primals_1847 = getitem_871 = getitem_872 = None
        getitem_1179 = native_batch_norm_backward_default_34[0]
        getitem_1180 = native_batch_norm_backward_default_34[1]
        getitem_1181 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(getitem_1179, relu__default_217, primals_1843, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1179 = primals_1843 = None
        getitem_1182 = convolution_backward_default_34[0]
        getitem_1183 = convolution_backward_default_34[1]
        getitem_1184 = convolution_backward_default_34[2];  convolution_backward_default_34 = None
        add_tensor_78 = torch.ops.aten.add.Tensor(add_tensor_74, getitem_1182);  add_tensor_74 = getitem_1182 = None
        add_tensor_79 = torch.ops.aten.add.Tensor(add_tensor_76, to_dtype_71);  add_tensor_76 = None
        upsample_nearest2d_backward_vec_5 = torch.ops.aten.upsample_nearest2d_backward.vec(to_dtype_71, None, [128, 18, 28, 28], [2.0, 2.0]);  to_dtype_71 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(upsample_nearest2d_backward_vec_5, convolution_default_289, primals_1740, primals_1738, primals_1739, getitem_868, getitem_869, True, 1e-05, [True, True, True]);  upsample_nearest2d_backward_vec_5 = convolution_default_289 = primals_1740 = primals_1738 = primals_1739 = getitem_868 = getitem_869 = None
        getitem_1185 = native_batch_norm_backward_default_35[0]
        getitem_1186 = native_batch_norm_backward_default_35[1]
        getitem_1187 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_1185, relu__default_209, primals_1735, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1185 = primals_1735 = None
        getitem_1188 = convolution_backward_default_35[0]
        getitem_1189 = convolution_backward_default_35[1]
        getitem_1190 = convolution_backward_default_35[2];  convolution_backward_default_35 = None
        add_tensor_80 = torch.ops.aten.add.Tensor(add_tensor_75, getitem_1188);  add_tensor_75 = getitem_1188 = None
        to_dtype_72 = torch.ops.aten.to.dtype(add_tensor_77, torch.float32);  add_tensor_77 = None
        to_dtype_73 = torch.ops.aten.to.dtype(relu__default_225, torch.float32);  relu__default_225 = None
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_73, 0);  to_dtype_73 = None
        new_zeros_default_349 = torch.ops.aten.new_zeros.default(to_dtype_72, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_24 = torch.ops.aten.where.self(le_scalar_24, new_zeros_default_349, to_dtype_72);  le_scalar_24 = new_zeros_default_349 = to_dtype_72 = None
        to_dtype_74 = torch.ops.aten.to.dtype(where_self_24, torch.float32);  where_self_24 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_74, convolution_default_288, primals_1462, primals_1460, primals_1461, getitem_865, getitem_866, True, 1e-05, [True, True, True]);  convolution_default_288 = primals_1462 = primals_1460 = primals_1461 = getitem_865 = getitem_866 = None
        getitem_1191 = native_batch_norm_backward_default_36[0]
        getitem_1192 = native_batch_norm_backward_default_36[1]
        getitem_1193 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(getitem_1191, relu__default_224, primals_1464, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1191 = primals_1464 = None
        getitem_1194 = convolution_backward_default_36[0]
        getitem_1195 = convolution_backward_default_36[1]
        getitem_1196 = convolution_backward_default_36[2];  convolution_backward_default_36 = None
        to_dtype_75 = torch.ops.aten.to.dtype(getitem_1194, torch.float32);  getitem_1194 = None
        to_dtype_76 = torch.ops.aten.to.dtype(relu__default_224, torch.float32);  relu__default_224 = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_76, 0);  to_dtype_76 = None
        new_zeros_default_350 = torch.ops.aten.new_zeros.default(to_dtype_75, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_25 = torch.ops.aten.where.self(le_scalar_25, new_zeros_default_350, to_dtype_75);  le_scalar_25 = new_zeros_default_350 = to_dtype_75 = None
        to_dtype_77 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_77, convolution_default_287, primals_1457, primals_1455, primals_1456, getitem_862, getitem_863, True, 1e-05, [True, True, True]);  to_dtype_77 = convolution_default_287 = primals_1457 = primals_1455 = primals_1456 = getitem_862 = getitem_863 = None
        getitem_1197 = native_batch_norm_backward_default_37[0]
        getitem_1198 = native_batch_norm_backward_default_37[1]
        getitem_1199 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(getitem_1197, relu__default_223, primals_1463, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1197 = primals_1463 = None
        getitem_1200 = convolution_backward_default_37[0]
        getitem_1201 = convolution_backward_default_37[1]
        getitem_1202 = convolution_backward_default_37[2];  convolution_backward_default_37 = None
        add_tensor_81 = torch.ops.aten.add.Tensor(to_dtype_74, getitem_1200);  to_dtype_74 = getitem_1200 = None
        to_dtype_78 = torch.ops.aten.to.dtype(add_tensor_81, torch.float32);  add_tensor_81 = None
        to_dtype_79 = torch.ops.aten.to.dtype(relu__default_223, torch.float32);  relu__default_223 = None
        le_scalar_26 = torch.ops.aten.le.Scalar(to_dtype_79, 0);  to_dtype_79 = None
        new_zeros_default_351 = torch.ops.aten.new_zeros.default(to_dtype_78, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_26 = torch.ops.aten.where.self(le_scalar_26, new_zeros_default_351, to_dtype_78);  le_scalar_26 = new_zeros_default_351 = to_dtype_78 = None
        to_dtype_80 = torch.ops.aten.to.dtype(where_self_26, torch.float32);  where_self_26 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_80, convolution_default_286, primals_1450, primals_1448, primals_1449, getitem_859, getitem_860, True, 1e-05, [True, True, True]);  convolution_default_286 = primals_1450 = primals_1448 = primals_1449 = getitem_859 = getitem_860 = None
        getitem_1203 = native_batch_norm_backward_default_38[0]
        getitem_1204 = native_batch_norm_backward_default_38[1]
        getitem_1205 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(getitem_1203, relu__default_222, primals_1452, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1203 = primals_1452 = None
        getitem_1206 = convolution_backward_default_38[0]
        getitem_1207 = convolution_backward_default_38[1]
        getitem_1208 = convolution_backward_default_38[2];  convolution_backward_default_38 = None
        to_dtype_81 = torch.ops.aten.to.dtype(getitem_1206, torch.float32);  getitem_1206 = None
        to_dtype_82 = torch.ops.aten.to.dtype(relu__default_222, torch.float32);  relu__default_222 = None
        le_scalar_27 = torch.ops.aten.le.Scalar(to_dtype_82, 0);  to_dtype_82 = None
        new_zeros_default_352 = torch.ops.aten.new_zeros.default(to_dtype_81, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_27 = torch.ops.aten.where.self(le_scalar_27, new_zeros_default_352, to_dtype_81);  le_scalar_27 = new_zeros_default_352 = to_dtype_81 = None
        to_dtype_83 = torch.ops.aten.to.dtype(where_self_27, torch.float32);  where_self_27 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_83, convolution_default_285, primals_1445, primals_1443, primals_1444, getitem_856, getitem_857, True, 1e-05, [True, True, True]);  to_dtype_83 = convolution_default_285 = primals_1445 = primals_1443 = primals_1444 = getitem_856 = getitem_857 = None
        getitem_1209 = native_batch_norm_backward_default_39[0]
        getitem_1210 = native_batch_norm_backward_default_39[1]
        getitem_1211 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(getitem_1209, relu__default_221, primals_1451, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1209 = primals_1451 = None
        getitem_1212 = convolution_backward_default_39[0]
        getitem_1213 = convolution_backward_default_39[1]
        getitem_1214 = convolution_backward_default_39[2];  convolution_backward_default_39 = None
        add_tensor_82 = torch.ops.aten.add.Tensor(to_dtype_80, getitem_1212);  to_dtype_80 = getitem_1212 = None
        to_dtype_84 = torch.ops.aten.to.dtype(add_tensor_82, torch.float32);  add_tensor_82 = None
        to_dtype_85 = torch.ops.aten.to.dtype(relu__default_221, torch.float32);  relu__default_221 = None
        le_scalar_28 = torch.ops.aten.le.Scalar(to_dtype_85, 0);  to_dtype_85 = None
        new_zeros_default_353 = torch.ops.aten.new_zeros.default(to_dtype_84, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_28 = torch.ops.aten.where.self(le_scalar_28, new_zeros_default_353, to_dtype_84);  le_scalar_28 = new_zeros_default_353 = to_dtype_84 = None
        to_dtype_86 = torch.ops.aten.to.dtype(where_self_28, torch.float32);  where_self_28 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_86, convolution_default_284, primals_1438, primals_1436, primals_1437, getitem_853, getitem_854, True, 1e-05, [True, True, True]);  convolution_default_284 = primals_1438 = primals_1436 = primals_1437 = getitem_853 = getitem_854 = None
        getitem_1215 = native_batch_norm_backward_default_40[0]
        getitem_1216 = native_batch_norm_backward_default_40[1]
        getitem_1217 = native_batch_norm_backward_default_40[2];  native_batch_norm_backward_default_40 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(getitem_1215, relu__default_220, primals_1440, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1215 = primals_1440 = None
        getitem_1218 = convolution_backward_default_40[0]
        getitem_1219 = convolution_backward_default_40[1]
        getitem_1220 = convolution_backward_default_40[2];  convolution_backward_default_40 = None
        to_dtype_87 = torch.ops.aten.to.dtype(getitem_1218, torch.float32);  getitem_1218 = None
        to_dtype_88 = torch.ops.aten.to.dtype(relu__default_220, torch.float32);  relu__default_220 = None
        le_scalar_29 = torch.ops.aten.le.Scalar(to_dtype_88, 0);  to_dtype_88 = None
        new_zeros_default_354 = torch.ops.aten.new_zeros.default(to_dtype_87, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_29 = torch.ops.aten.where.self(le_scalar_29, new_zeros_default_354, to_dtype_87);  le_scalar_29 = new_zeros_default_354 = to_dtype_87 = None
        to_dtype_89 = torch.ops.aten.to.dtype(where_self_29, torch.float32);  where_self_29 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_89, convolution_default_283, primals_1433, primals_1431, primals_1432, getitem_850, getitem_851, True, 1e-05, [True, True, True]);  to_dtype_89 = convolution_default_283 = primals_1433 = primals_1431 = primals_1432 = getitem_850 = getitem_851 = None
        getitem_1221 = native_batch_norm_backward_default_41[0]
        getitem_1222 = native_batch_norm_backward_default_41[1]
        getitem_1223 = native_batch_norm_backward_default_41[2];  native_batch_norm_backward_default_41 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(getitem_1221, relu__default_219, primals_1439, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1221 = primals_1439 = None
        getitem_1224 = convolution_backward_default_41[0]
        getitem_1225 = convolution_backward_default_41[1]
        getitem_1226 = convolution_backward_default_41[2];  convolution_backward_default_41 = None
        add_tensor_83 = torch.ops.aten.add.Tensor(to_dtype_86, getitem_1224);  to_dtype_86 = getitem_1224 = None
        to_dtype_90 = torch.ops.aten.to.dtype(add_tensor_83, torch.float32);  add_tensor_83 = None
        to_dtype_91 = torch.ops.aten.to.dtype(relu__default_219, torch.float32);  relu__default_219 = None
        le_scalar_30 = torch.ops.aten.le.Scalar(to_dtype_91, 0);  to_dtype_91 = None
        new_zeros_default_355 = torch.ops.aten.new_zeros.default(to_dtype_90, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_30 = torch.ops.aten.where.self(le_scalar_30, new_zeros_default_355, to_dtype_90);  le_scalar_30 = new_zeros_default_355 = to_dtype_90 = None
        to_dtype_92 = torch.ops.aten.to.dtype(where_self_30, torch.float32);  where_self_30 = None
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_92, convolution_default_282, primals_1426, primals_1424, primals_1425, getitem_847, getitem_848, True, 1e-05, [True, True, True]);  convolution_default_282 = primals_1426 = primals_1424 = primals_1425 = getitem_847 = getitem_848 = None
        getitem_1227 = native_batch_norm_backward_default_42[0]
        getitem_1228 = native_batch_norm_backward_default_42[1]
        getitem_1229 = native_batch_norm_backward_default_42[2];  native_batch_norm_backward_default_42 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(getitem_1227, relu__default_218, primals_1428, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1227 = primals_1428 = None
        getitem_1230 = convolution_backward_default_42[0]
        getitem_1231 = convolution_backward_default_42[1]
        getitem_1232 = convolution_backward_default_42[2];  convolution_backward_default_42 = None
        to_dtype_93 = torch.ops.aten.to.dtype(getitem_1230, torch.float32);  getitem_1230 = None
        to_dtype_94 = torch.ops.aten.to.dtype(relu__default_218, torch.float32);  relu__default_218 = None
        le_scalar_31 = torch.ops.aten.le.Scalar(to_dtype_94, 0);  to_dtype_94 = None
        new_zeros_default_356 = torch.ops.aten.new_zeros.default(to_dtype_93, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_31 = torch.ops.aten.where.self(le_scalar_31, new_zeros_default_356, to_dtype_93);  le_scalar_31 = new_zeros_default_356 = to_dtype_93 = None
        to_dtype_95 = torch.ops.aten.to.dtype(where_self_31, torch.float32);  where_self_31 = None
        native_batch_norm_backward_default_43 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_95, convolution_default_281, primals_1421, primals_1419, primals_1420, getitem_844, getitem_845, True, 1e-05, [True, True, True]);  to_dtype_95 = convolution_default_281 = primals_1421 = primals_1419 = primals_1420 = getitem_844 = getitem_845 = None
        getitem_1233 = native_batch_norm_backward_default_43[0]
        getitem_1234 = native_batch_norm_backward_default_43[1]
        getitem_1235 = native_batch_norm_backward_default_43[2];  native_batch_norm_backward_default_43 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(getitem_1233, relu_default_33, primals_1427, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1233 = primals_1427 = None
        getitem_1236 = convolution_backward_default_43[0]
        getitem_1237 = convolution_backward_default_43[1]
        getitem_1238 = convolution_backward_default_43[2];  convolution_backward_default_43 = None
        add_tensor_84 = torch.ops.aten.add.Tensor(to_dtype_92, getitem_1236);  to_dtype_92 = getitem_1236 = None
        to_dtype_96 = torch.ops.aten.to.dtype(add_tensor_78, torch.float32);  add_tensor_78 = None
        to_dtype_97 = torch.ops.aten.to.dtype(relu__default_217, torch.float32);  relu__default_217 = None
        le_scalar_32 = torch.ops.aten.le.Scalar(to_dtype_97, 0);  to_dtype_97 = None
        new_zeros_default_357 = torch.ops.aten.new_zeros.default(to_dtype_96, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_32 = torch.ops.aten.where.self(le_scalar_32, new_zeros_default_357, to_dtype_96);  le_scalar_32 = new_zeros_default_357 = to_dtype_96 = None
        to_dtype_98 = torch.ops.aten.to.dtype(where_self_32, torch.float32);  where_self_32 = None
        native_batch_norm_backward_default_44 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_98, convolution_default_280, primals_1414, primals_1412, primals_1413, getitem_841, getitem_842, True, 1e-05, [True, True, True]);  convolution_default_280 = primals_1414 = primals_1412 = primals_1413 = getitem_841 = getitem_842 = None
        getitem_1239 = native_batch_norm_backward_default_44[0]
        getitem_1240 = native_batch_norm_backward_default_44[1]
        getitem_1241 = native_batch_norm_backward_default_44[2];  native_batch_norm_backward_default_44 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(getitem_1239, relu__default_216, primals_1416, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1239 = primals_1416 = None
        getitem_1242 = convolution_backward_default_44[0]
        getitem_1243 = convolution_backward_default_44[1]
        getitem_1244 = convolution_backward_default_44[2];  convolution_backward_default_44 = None
        to_dtype_99 = torch.ops.aten.to.dtype(getitem_1242, torch.float32);  getitem_1242 = None
        to_dtype_100 = torch.ops.aten.to.dtype(relu__default_216, torch.float32);  relu__default_216 = None
        le_scalar_33 = torch.ops.aten.le.Scalar(to_dtype_100, 0);  to_dtype_100 = None
        new_zeros_default_358 = torch.ops.aten.new_zeros.default(to_dtype_99, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_33 = torch.ops.aten.where.self(le_scalar_33, new_zeros_default_358, to_dtype_99);  le_scalar_33 = new_zeros_default_358 = to_dtype_99 = None
        to_dtype_101 = torch.ops.aten.to.dtype(where_self_33, torch.float32);  where_self_33 = None
        native_batch_norm_backward_default_45 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_101, convolution_default_279, primals_1409, primals_1407, primals_1408, getitem_838, getitem_839, True, 1e-05, [True, True, True]);  to_dtype_101 = convolution_default_279 = primals_1409 = primals_1407 = primals_1408 = getitem_838 = getitem_839 = None
        getitem_1245 = native_batch_norm_backward_default_45[0]
        getitem_1246 = native_batch_norm_backward_default_45[1]
        getitem_1247 = native_batch_norm_backward_default_45[2];  native_batch_norm_backward_default_45 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(getitem_1245, relu__default_215, primals_1415, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1245 = primals_1415 = None
        getitem_1248 = convolution_backward_default_45[0]
        getitem_1249 = convolution_backward_default_45[1]
        getitem_1250 = convolution_backward_default_45[2];  convolution_backward_default_45 = None
        add_tensor_85 = torch.ops.aten.add.Tensor(to_dtype_98, getitem_1248);  to_dtype_98 = getitem_1248 = None
        to_dtype_102 = torch.ops.aten.to.dtype(add_tensor_85, torch.float32);  add_tensor_85 = None
        to_dtype_103 = torch.ops.aten.to.dtype(relu__default_215, torch.float32);  relu__default_215 = None
        le_scalar_34 = torch.ops.aten.le.Scalar(to_dtype_103, 0);  to_dtype_103 = None
        new_zeros_default_359 = torch.ops.aten.new_zeros.default(to_dtype_102, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_34 = torch.ops.aten.where.self(le_scalar_34, new_zeros_default_359, to_dtype_102);  le_scalar_34 = new_zeros_default_359 = to_dtype_102 = None
        to_dtype_104 = torch.ops.aten.to.dtype(where_self_34, torch.float32);  where_self_34 = None
        native_batch_norm_backward_default_46 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_104, convolution_default_278, primals_1402, primals_1400, primals_1401, getitem_835, getitem_836, True, 1e-05, [True, True, True]);  convolution_default_278 = primals_1402 = primals_1400 = primals_1401 = getitem_835 = getitem_836 = None
        getitem_1251 = native_batch_norm_backward_default_46[0]
        getitem_1252 = native_batch_norm_backward_default_46[1]
        getitem_1253 = native_batch_norm_backward_default_46[2];  native_batch_norm_backward_default_46 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(getitem_1251, relu__default_214, primals_1404, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1251 = primals_1404 = None
        getitem_1254 = convolution_backward_default_46[0]
        getitem_1255 = convolution_backward_default_46[1]
        getitem_1256 = convolution_backward_default_46[2];  convolution_backward_default_46 = None
        to_dtype_105 = torch.ops.aten.to.dtype(getitem_1254, torch.float32);  getitem_1254 = None
        to_dtype_106 = torch.ops.aten.to.dtype(relu__default_214, torch.float32);  relu__default_214 = None
        le_scalar_35 = torch.ops.aten.le.Scalar(to_dtype_106, 0);  to_dtype_106 = None
        new_zeros_default_360 = torch.ops.aten.new_zeros.default(to_dtype_105, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_35 = torch.ops.aten.where.self(le_scalar_35, new_zeros_default_360, to_dtype_105);  le_scalar_35 = new_zeros_default_360 = to_dtype_105 = None
        to_dtype_107 = torch.ops.aten.to.dtype(where_self_35, torch.float32);  where_self_35 = None
        native_batch_norm_backward_default_47 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_107, convolution_default_277, primals_1397, primals_1395, primals_1396, getitem_832, getitem_833, True, 1e-05, [True, True, True]);  to_dtype_107 = convolution_default_277 = primals_1397 = primals_1395 = primals_1396 = getitem_832 = getitem_833 = None
        getitem_1257 = native_batch_norm_backward_default_47[0]
        getitem_1258 = native_batch_norm_backward_default_47[1]
        getitem_1259 = native_batch_norm_backward_default_47[2];  native_batch_norm_backward_default_47 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(getitem_1257, relu__default_213, primals_1403, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1257 = primals_1403 = None
        getitem_1260 = convolution_backward_default_47[0]
        getitem_1261 = convolution_backward_default_47[1]
        getitem_1262 = convolution_backward_default_47[2];  convolution_backward_default_47 = None
        add_tensor_86 = torch.ops.aten.add.Tensor(to_dtype_104, getitem_1260);  to_dtype_104 = getitem_1260 = None
        to_dtype_108 = torch.ops.aten.to.dtype(add_tensor_86, torch.float32);  add_tensor_86 = None
        to_dtype_109 = torch.ops.aten.to.dtype(relu__default_213, torch.float32);  relu__default_213 = None
        le_scalar_36 = torch.ops.aten.le.Scalar(to_dtype_109, 0);  to_dtype_109 = None
        new_zeros_default_361 = torch.ops.aten.new_zeros.default(to_dtype_108, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_36 = torch.ops.aten.where.self(le_scalar_36, new_zeros_default_361, to_dtype_108);  le_scalar_36 = new_zeros_default_361 = to_dtype_108 = None
        to_dtype_110 = torch.ops.aten.to.dtype(where_self_36, torch.float32);  where_self_36 = None
        native_batch_norm_backward_default_48 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_110, convolution_default_276, primals_1390, primals_1388, primals_1389, getitem_829, getitem_830, True, 1e-05, [True, True, True]);  convolution_default_276 = primals_1390 = primals_1388 = primals_1389 = getitem_829 = getitem_830 = None
        getitem_1263 = native_batch_norm_backward_default_48[0]
        getitem_1264 = native_batch_norm_backward_default_48[1]
        getitem_1265 = native_batch_norm_backward_default_48[2];  native_batch_norm_backward_default_48 = None
        convolution_backward_default_48 = torch.ops.aten.convolution_backward.default(getitem_1263, relu__default_212, primals_1392, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1263 = primals_1392 = None
        getitem_1266 = convolution_backward_default_48[0]
        getitem_1267 = convolution_backward_default_48[1]
        getitem_1268 = convolution_backward_default_48[2];  convolution_backward_default_48 = None
        to_dtype_111 = torch.ops.aten.to.dtype(getitem_1266, torch.float32);  getitem_1266 = None
        to_dtype_112 = torch.ops.aten.to.dtype(relu__default_212, torch.float32);  relu__default_212 = None
        le_scalar_37 = torch.ops.aten.le.Scalar(to_dtype_112, 0);  to_dtype_112 = None
        new_zeros_default_362 = torch.ops.aten.new_zeros.default(to_dtype_111, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_37 = torch.ops.aten.where.self(le_scalar_37, new_zeros_default_362, to_dtype_111);  le_scalar_37 = new_zeros_default_362 = to_dtype_111 = None
        to_dtype_113 = torch.ops.aten.to.dtype(where_self_37, torch.float32);  where_self_37 = None
        native_batch_norm_backward_default_49 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_113, convolution_default_275, primals_1385, primals_1383, primals_1384, getitem_826, getitem_827, True, 1e-05, [True, True, True]);  to_dtype_113 = convolution_default_275 = primals_1385 = primals_1383 = primals_1384 = getitem_826 = getitem_827 = None
        getitem_1269 = native_batch_norm_backward_default_49[0]
        getitem_1270 = native_batch_norm_backward_default_49[1]
        getitem_1271 = native_batch_norm_backward_default_49[2];  native_batch_norm_backward_default_49 = None
        convolution_backward_default_49 = torch.ops.aten.convolution_backward.default(getitem_1269, relu__default_211, primals_1391, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1269 = primals_1391 = None
        getitem_1272 = convolution_backward_default_49[0]
        getitem_1273 = convolution_backward_default_49[1]
        getitem_1274 = convolution_backward_default_49[2];  convolution_backward_default_49 = None
        add_tensor_87 = torch.ops.aten.add.Tensor(to_dtype_110, getitem_1272);  to_dtype_110 = getitem_1272 = None
        to_dtype_114 = torch.ops.aten.to.dtype(add_tensor_87, torch.float32);  add_tensor_87 = None
        to_dtype_115 = torch.ops.aten.to.dtype(relu__default_211, torch.float32);  relu__default_211 = None
        le_scalar_38 = torch.ops.aten.le.Scalar(to_dtype_115, 0);  to_dtype_115 = None
        new_zeros_default_363 = torch.ops.aten.new_zeros.default(to_dtype_114, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_38 = torch.ops.aten.where.self(le_scalar_38, new_zeros_default_363, to_dtype_114);  le_scalar_38 = new_zeros_default_363 = to_dtype_114 = None
        to_dtype_116 = torch.ops.aten.to.dtype(where_self_38, torch.float32);  where_self_38 = None
        native_batch_norm_backward_default_50 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_116, convolution_default_274, primals_1378, primals_1376, primals_1377, getitem_823, getitem_824, True, 1e-05, [True, True, True]);  convolution_default_274 = primals_1378 = primals_1376 = primals_1377 = getitem_823 = getitem_824 = None
        getitem_1275 = native_batch_norm_backward_default_50[0]
        getitem_1276 = native_batch_norm_backward_default_50[1]
        getitem_1277 = native_batch_norm_backward_default_50[2];  native_batch_norm_backward_default_50 = None
        convolution_backward_default_50 = torch.ops.aten.convolution_backward.default(getitem_1275, relu__default_210, primals_1380, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1275 = primals_1380 = None
        getitem_1278 = convolution_backward_default_50[0]
        getitem_1279 = convolution_backward_default_50[1]
        getitem_1280 = convolution_backward_default_50[2];  convolution_backward_default_50 = None
        to_dtype_117 = torch.ops.aten.to.dtype(getitem_1278, torch.float32);  getitem_1278 = None
        to_dtype_118 = torch.ops.aten.to.dtype(relu__default_210, torch.float32);  relu__default_210 = None
        le_scalar_39 = torch.ops.aten.le.Scalar(to_dtype_118, 0);  to_dtype_118 = None
        new_zeros_default_364 = torch.ops.aten.new_zeros.default(to_dtype_117, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_39 = torch.ops.aten.where.self(le_scalar_39, new_zeros_default_364, to_dtype_117);  le_scalar_39 = new_zeros_default_364 = to_dtype_117 = None
        to_dtype_119 = torch.ops.aten.to.dtype(where_self_39, torch.float32);  where_self_39 = None
        native_batch_norm_backward_default_51 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_119, convolution_default_273, primals_1373, primals_1371, primals_1372, getitem_820, getitem_821, True, 1e-05, [True, True, True]);  to_dtype_119 = convolution_default_273 = primals_1373 = primals_1371 = primals_1372 = getitem_820 = getitem_821 = None
        getitem_1281 = native_batch_norm_backward_default_51[0]
        getitem_1282 = native_batch_norm_backward_default_51[1]
        getitem_1283 = native_batch_norm_backward_default_51[2];  native_batch_norm_backward_default_51 = None
        convolution_backward_default_51 = torch.ops.aten.convolution_backward.default(getitem_1281, relu_default_29, primals_1379, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1281 = primals_1379 = None
        getitem_1284 = convolution_backward_default_51[0]
        getitem_1285 = convolution_backward_default_51[1]
        getitem_1286 = convolution_backward_default_51[2];  convolution_backward_default_51 = None
        add_tensor_88 = torch.ops.aten.add.Tensor(to_dtype_116, getitem_1284);  to_dtype_116 = getitem_1284 = None
        to_dtype_120 = torch.ops.aten.to.dtype(add_tensor_80, torch.float32);  add_tensor_80 = None
        to_dtype_121 = torch.ops.aten.to.dtype(relu__default_209, torch.float32);  relu__default_209 = None
        le_scalar_40 = torch.ops.aten.le.Scalar(to_dtype_121, 0);  to_dtype_121 = None
        new_zeros_default_365 = torch.ops.aten.new_zeros.default(to_dtype_120, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_40 = torch.ops.aten.where.self(le_scalar_40, new_zeros_default_365, to_dtype_120);  le_scalar_40 = new_zeros_default_365 = to_dtype_120 = None
        to_dtype_122 = torch.ops.aten.to.dtype(where_self_40, torch.float32);  where_self_40 = None
        native_batch_norm_backward_default_52 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_122, convolution_default_272, primals_1366, primals_1364, primals_1365, getitem_817, getitem_818, True, 1e-05, [True, True, True]);  convolution_default_272 = primals_1366 = primals_1364 = primals_1365 = getitem_817 = getitem_818 = None
        getitem_1287 = native_batch_norm_backward_default_52[0]
        getitem_1288 = native_batch_norm_backward_default_52[1]
        getitem_1289 = native_batch_norm_backward_default_52[2];  native_batch_norm_backward_default_52 = None
        convolution_backward_default_52 = torch.ops.aten.convolution_backward.default(getitem_1287, relu__default_208, primals_1368, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1287 = primals_1368 = None
        getitem_1290 = convolution_backward_default_52[0]
        getitem_1291 = convolution_backward_default_52[1]
        getitem_1292 = convolution_backward_default_52[2];  convolution_backward_default_52 = None
        to_dtype_123 = torch.ops.aten.to.dtype(getitem_1290, torch.float32);  getitem_1290 = None
        to_dtype_124 = torch.ops.aten.to.dtype(relu__default_208, torch.float32);  relu__default_208 = None
        le_scalar_41 = torch.ops.aten.le.Scalar(to_dtype_124, 0);  to_dtype_124 = None
        new_zeros_default_366 = torch.ops.aten.new_zeros.default(to_dtype_123, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_41 = torch.ops.aten.where.self(le_scalar_41, new_zeros_default_366, to_dtype_123);  le_scalar_41 = new_zeros_default_366 = to_dtype_123 = None
        to_dtype_125 = torch.ops.aten.to.dtype(where_self_41, torch.float32);  where_self_41 = None
        native_batch_norm_backward_default_53 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_125, convolution_default_271, primals_1361, primals_1359, primals_1360, getitem_814, getitem_815, True, 1e-05, [True, True, True]);  to_dtype_125 = convolution_default_271 = primals_1361 = primals_1359 = primals_1360 = getitem_814 = getitem_815 = None
        getitem_1293 = native_batch_norm_backward_default_53[0]
        getitem_1294 = native_batch_norm_backward_default_53[1]
        getitem_1295 = native_batch_norm_backward_default_53[2];  native_batch_norm_backward_default_53 = None
        convolution_backward_default_53 = torch.ops.aten.convolution_backward.default(getitem_1293, relu__default_207, primals_1367, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1293 = primals_1367 = None
        getitem_1296 = convolution_backward_default_53[0]
        getitem_1297 = convolution_backward_default_53[1]
        getitem_1298 = convolution_backward_default_53[2];  convolution_backward_default_53 = None
        add_tensor_89 = torch.ops.aten.add.Tensor(to_dtype_122, getitem_1296);  to_dtype_122 = getitem_1296 = None
        to_dtype_126 = torch.ops.aten.to.dtype(add_tensor_89, torch.float32);  add_tensor_89 = None
        to_dtype_127 = torch.ops.aten.to.dtype(relu__default_207, torch.float32);  relu__default_207 = None
        le_scalar_42 = torch.ops.aten.le.Scalar(to_dtype_127, 0);  to_dtype_127 = None
        new_zeros_default_367 = torch.ops.aten.new_zeros.default(to_dtype_126, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_42 = torch.ops.aten.where.self(le_scalar_42, new_zeros_default_367, to_dtype_126);  le_scalar_42 = new_zeros_default_367 = to_dtype_126 = None
        to_dtype_128 = torch.ops.aten.to.dtype(where_self_42, torch.float32);  where_self_42 = None
        native_batch_norm_backward_default_54 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_128, convolution_default_270, primals_1354, primals_1352, primals_1353, getitem_811, getitem_812, True, 1e-05, [True, True, True]);  convolution_default_270 = primals_1354 = primals_1352 = primals_1353 = getitem_811 = getitem_812 = None
        getitem_1299 = native_batch_norm_backward_default_54[0]
        getitem_1300 = native_batch_norm_backward_default_54[1]
        getitem_1301 = native_batch_norm_backward_default_54[2];  native_batch_norm_backward_default_54 = None
        convolution_backward_default_54 = torch.ops.aten.convolution_backward.default(getitem_1299, relu__default_206, primals_1356, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1299 = primals_1356 = None
        getitem_1302 = convolution_backward_default_54[0]
        getitem_1303 = convolution_backward_default_54[1]
        getitem_1304 = convolution_backward_default_54[2];  convolution_backward_default_54 = None
        to_dtype_129 = torch.ops.aten.to.dtype(getitem_1302, torch.float32);  getitem_1302 = None
        to_dtype_130 = torch.ops.aten.to.dtype(relu__default_206, torch.float32);  relu__default_206 = None
        le_scalar_43 = torch.ops.aten.le.Scalar(to_dtype_130, 0);  to_dtype_130 = None
        new_zeros_default_368 = torch.ops.aten.new_zeros.default(to_dtype_129, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_43 = torch.ops.aten.where.self(le_scalar_43, new_zeros_default_368, to_dtype_129);  le_scalar_43 = new_zeros_default_368 = to_dtype_129 = None
        to_dtype_131 = torch.ops.aten.to.dtype(where_self_43, torch.float32);  where_self_43 = None
        native_batch_norm_backward_default_55 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_131, convolution_default_269, primals_1349, primals_1347, primals_1348, getitem_808, getitem_809, True, 1e-05, [True, True, True]);  to_dtype_131 = convolution_default_269 = primals_1349 = primals_1347 = primals_1348 = getitem_808 = getitem_809 = None
        getitem_1305 = native_batch_norm_backward_default_55[0]
        getitem_1306 = native_batch_norm_backward_default_55[1]
        getitem_1307 = native_batch_norm_backward_default_55[2];  native_batch_norm_backward_default_55 = None
        convolution_backward_default_55 = torch.ops.aten.convolution_backward.default(getitem_1305, relu__default_205, primals_1355, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1305 = primals_1355 = None
        getitem_1308 = convolution_backward_default_55[0]
        getitem_1309 = convolution_backward_default_55[1]
        getitem_1310 = convolution_backward_default_55[2];  convolution_backward_default_55 = None
        add_tensor_90 = torch.ops.aten.add.Tensor(to_dtype_128, getitem_1308);  to_dtype_128 = getitem_1308 = None
        to_dtype_132 = torch.ops.aten.to.dtype(add_tensor_90, torch.float32);  add_tensor_90 = None
        to_dtype_133 = torch.ops.aten.to.dtype(relu__default_205, torch.float32);  relu__default_205 = None
        le_scalar_44 = torch.ops.aten.le.Scalar(to_dtype_133, 0);  to_dtype_133 = None
        new_zeros_default_369 = torch.ops.aten.new_zeros.default(to_dtype_132, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_44 = torch.ops.aten.where.self(le_scalar_44, new_zeros_default_369, to_dtype_132);  le_scalar_44 = new_zeros_default_369 = to_dtype_132 = None
        to_dtype_134 = torch.ops.aten.to.dtype(where_self_44, torch.float32);  where_self_44 = None
        native_batch_norm_backward_default_56 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_134, convolution_default_268, primals_1342, primals_1340, primals_1341, getitem_805, getitem_806, True, 1e-05, [True, True, True]);  convolution_default_268 = primals_1342 = primals_1340 = primals_1341 = getitem_805 = getitem_806 = None
        getitem_1311 = native_batch_norm_backward_default_56[0]
        getitem_1312 = native_batch_norm_backward_default_56[1]
        getitem_1313 = native_batch_norm_backward_default_56[2];  native_batch_norm_backward_default_56 = None
        convolution_backward_default_56 = torch.ops.aten.convolution_backward.default(getitem_1311, relu__default_204, primals_1344, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1311 = primals_1344 = None
        getitem_1314 = convolution_backward_default_56[0]
        getitem_1315 = convolution_backward_default_56[1]
        getitem_1316 = convolution_backward_default_56[2];  convolution_backward_default_56 = None
        to_dtype_135 = torch.ops.aten.to.dtype(getitem_1314, torch.float32);  getitem_1314 = None
        to_dtype_136 = torch.ops.aten.to.dtype(relu__default_204, torch.float32);  relu__default_204 = None
        le_scalar_45 = torch.ops.aten.le.Scalar(to_dtype_136, 0);  to_dtype_136 = None
        new_zeros_default_370 = torch.ops.aten.new_zeros.default(to_dtype_135, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_45 = torch.ops.aten.where.self(le_scalar_45, new_zeros_default_370, to_dtype_135);  le_scalar_45 = new_zeros_default_370 = to_dtype_135 = None
        to_dtype_137 = torch.ops.aten.to.dtype(where_self_45, torch.float32);  where_self_45 = None
        native_batch_norm_backward_default_57 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_137, convolution_default_267, primals_1337, primals_1335, primals_1336, getitem_802, getitem_803, True, 1e-05, [True, True, True]);  to_dtype_137 = convolution_default_267 = primals_1337 = primals_1335 = primals_1336 = getitem_802 = getitem_803 = None
        getitem_1317 = native_batch_norm_backward_default_57[0]
        getitem_1318 = native_batch_norm_backward_default_57[1]
        getitem_1319 = native_batch_norm_backward_default_57[2];  native_batch_norm_backward_default_57 = None
        convolution_backward_default_57 = torch.ops.aten.convolution_backward.default(getitem_1317, relu__default_203, primals_1343, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1317 = primals_1343 = None
        getitem_1320 = convolution_backward_default_57[0]
        getitem_1321 = convolution_backward_default_57[1]
        getitem_1322 = convolution_backward_default_57[2];  convolution_backward_default_57 = None
        add_tensor_91 = torch.ops.aten.add.Tensor(to_dtype_134, getitem_1320);  to_dtype_134 = getitem_1320 = None
        to_dtype_138 = torch.ops.aten.to.dtype(add_tensor_91, torch.float32);  add_tensor_91 = None
        to_dtype_139 = torch.ops.aten.to.dtype(relu__default_203, torch.float32);  relu__default_203 = None
        le_scalar_46 = torch.ops.aten.le.Scalar(to_dtype_139, 0);  to_dtype_139 = None
        new_zeros_default_371 = torch.ops.aten.new_zeros.default(to_dtype_138, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_46 = torch.ops.aten.where.self(le_scalar_46, new_zeros_default_371, to_dtype_138);  le_scalar_46 = new_zeros_default_371 = to_dtype_138 = None
        to_dtype_140 = torch.ops.aten.to.dtype(where_self_46, torch.float32);  where_self_46 = None
        native_batch_norm_backward_default_58 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_140, convolution_default_266, primals_1330, primals_1328, primals_1329, getitem_799, getitem_800, True, 1e-05, [True, True, True]);  convolution_default_266 = primals_1330 = primals_1328 = primals_1329 = getitem_799 = getitem_800 = None
        getitem_1323 = native_batch_norm_backward_default_58[0]
        getitem_1324 = native_batch_norm_backward_default_58[1]
        getitem_1325 = native_batch_norm_backward_default_58[2];  native_batch_norm_backward_default_58 = None
        convolution_backward_default_58 = torch.ops.aten.convolution_backward.default(getitem_1323, relu__default_202, primals_1332, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1323 = primals_1332 = None
        getitem_1326 = convolution_backward_default_58[0]
        getitem_1327 = convolution_backward_default_58[1]
        getitem_1328 = convolution_backward_default_58[2];  convolution_backward_default_58 = None
        to_dtype_141 = torch.ops.aten.to.dtype(getitem_1326, torch.float32);  getitem_1326 = None
        to_dtype_142 = torch.ops.aten.to.dtype(relu__default_202, torch.float32);  relu__default_202 = None
        le_scalar_47 = torch.ops.aten.le.Scalar(to_dtype_142, 0);  to_dtype_142 = None
        new_zeros_default_372 = torch.ops.aten.new_zeros.default(to_dtype_141, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_47 = torch.ops.aten.where.self(le_scalar_47, new_zeros_default_372, to_dtype_141);  le_scalar_47 = new_zeros_default_372 = to_dtype_141 = None
        to_dtype_143 = torch.ops.aten.to.dtype(where_self_47, torch.float32);  where_self_47 = None
        native_batch_norm_backward_default_59 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_143, convolution_default_265, primals_1325, primals_1323, primals_1324, getitem_796, getitem_797, True, 1e-05, [True, True, True]);  to_dtype_143 = convolution_default_265 = primals_1325 = primals_1323 = primals_1324 = getitem_796 = getitem_797 = None
        getitem_1329 = native_batch_norm_backward_default_59[0]
        getitem_1330 = native_batch_norm_backward_default_59[1]
        getitem_1331 = native_batch_norm_backward_default_59[2];  native_batch_norm_backward_default_59 = None
        convolution_backward_default_59 = torch.ops.aten.convolution_backward.default(getitem_1329, relu_default_27, primals_1331, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1329 = primals_1331 = None
        getitem_1332 = convolution_backward_default_59[0]
        getitem_1333 = convolution_backward_default_59[1]
        getitem_1334 = convolution_backward_default_59[2];  convolution_backward_default_59 = None
        add_tensor_92 = torch.ops.aten.add.Tensor(to_dtype_140, getitem_1332);  to_dtype_140 = getitem_1332 = None
        to_dtype_144 = torch.ops.aten.to.dtype(add_tensor_79, torch.float32);  add_tensor_79 = None
        to_dtype_145 = torch.ops.aten.to.dtype(relu__default_201, torch.float32);  relu__default_201 = None
        le_scalar_48 = torch.ops.aten.le.Scalar(to_dtype_145, 0);  to_dtype_145 = None
        new_zeros_default_373 = torch.ops.aten.new_zeros.default(to_dtype_144, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_48 = torch.ops.aten.where.self(le_scalar_48, new_zeros_default_373, to_dtype_144);  le_scalar_48 = new_zeros_default_373 = to_dtype_144 = None
        to_dtype_146 = torch.ops.aten.to.dtype(where_self_48, torch.float32);  where_self_48 = None
        native_batch_norm_backward_default_60 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_146, convolution_default_264, primals_1318, primals_1316, primals_1317, getitem_793, getitem_794, True, 1e-05, [True, True, True]);  convolution_default_264 = primals_1318 = primals_1316 = primals_1317 = getitem_793 = getitem_794 = None
        getitem_1335 = native_batch_norm_backward_default_60[0]
        getitem_1336 = native_batch_norm_backward_default_60[1]
        getitem_1337 = native_batch_norm_backward_default_60[2];  native_batch_norm_backward_default_60 = None
        convolution_backward_default_60 = torch.ops.aten.convolution_backward.default(getitem_1335, relu__default_200, primals_1320, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1335 = primals_1320 = None
        getitem_1338 = convolution_backward_default_60[0]
        getitem_1339 = convolution_backward_default_60[1]
        getitem_1340 = convolution_backward_default_60[2];  convolution_backward_default_60 = None
        to_dtype_147 = torch.ops.aten.to.dtype(getitem_1338, torch.float32);  getitem_1338 = None
        to_dtype_148 = torch.ops.aten.to.dtype(relu__default_200, torch.float32);  relu__default_200 = None
        le_scalar_49 = torch.ops.aten.le.Scalar(to_dtype_148, 0);  to_dtype_148 = None
        new_zeros_default_374 = torch.ops.aten.new_zeros.default(to_dtype_147, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_49 = torch.ops.aten.where.self(le_scalar_49, new_zeros_default_374, to_dtype_147);  le_scalar_49 = new_zeros_default_374 = to_dtype_147 = None
        to_dtype_149 = torch.ops.aten.to.dtype(where_self_49, torch.float32);  where_self_49 = None
        native_batch_norm_backward_default_61 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_149, convolution_default_263, primals_1313, primals_1311, primals_1312, getitem_790, getitem_791, True, 1e-05, [True, True, True]);  to_dtype_149 = convolution_default_263 = primals_1313 = primals_1311 = primals_1312 = getitem_790 = getitem_791 = None
        getitem_1341 = native_batch_norm_backward_default_61[0]
        getitem_1342 = native_batch_norm_backward_default_61[1]
        getitem_1343 = native_batch_norm_backward_default_61[2];  native_batch_norm_backward_default_61 = None
        convolution_backward_default_61 = torch.ops.aten.convolution_backward.default(getitem_1341, relu__default_199, primals_1319, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1341 = primals_1319 = None
        getitem_1344 = convolution_backward_default_61[0]
        getitem_1345 = convolution_backward_default_61[1]
        getitem_1346 = convolution_backward_default_61[2];  convolution_backward_default_61 = None
        add_tensor_93 = torch.ops.aten.add.Tensor(to_dtype_146, getitem_1344);  to_dtype_146 = getitem_1344 = None
        to_dtype_150 = torch.ops.aten.to.dtype(add_tensor_93, torch.float32);  add_tensor_93 = None
        to_dtype_151 = torch.ops.aten.to.dtype(relu__default_199, torch.float32);  relu__default_199 = None
        le_scalar_50 = torch.ops.aten.le.Scalar(to_dtype_151, 0);  to_dtype_151 = None
        new_zeros_default_375 = torch.ops.aten.new_zeros.default(to_dtype_150, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_50 = torch.ops.aten.where.self(le_scalar_50, new_zeros_default_375, to_dtype_150);  le_scalar_50 = new_zeros_default_375 = to_dtype_150 = None
        to_dtype_152 = torch.ops.aten.to.dtype(where_self_50, torch.float32);  where_self_50 = None
        native_batch_norm_backward_default_62 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_152, convolution_default_262, primals_1306, primals_1304, primals_1305, getitem_787, getitem_788, True, 1e-05, [True, True, True]);  convolution_default_262 = primals_1306 = primals_1304 = primals_1305 = getitem_787 = getitem_788 = None
        getitem_1347 = native_batch_norm_backward_default_62[0]
        getitem_1348 = native_batch_norm_backward_default_62[1]
        getitem_1349 = native_batch_norm_backward_default_62[2];  native_batch_norm_backward_default_62 = None
        convolution_backward_default_62 = torch.ops.aten.convolution_backward.default(getitem_1347, relu__default_198, primals_1308, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1347 = primals_1308 = None
        getitem_1350 = convolution_backward_default_62[0]
        getitem_1351 = convolution_backward_default_62[1]
        getitem_1352 = convolution_backward_default_62[2];  convolution_backward_default_62 = None
        to_dtype_153 = torch.ops.aten.to.dtype(getitem_1350, torch.float32);  getitem_1350 = None
        to_dtype_154 = torch.ops.aten.to.dtype(relu__default_198, torch.float32);  relu__default_198 = None
        le_scalar_51 = torch.ops.aten.le.Scalar(to_dtype_154, 0);  to_dtype_154 = None
        new_zeros_default_376 = torch.ops.aten.new_zeros.default(to_dtype_153, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_51 = torch.ops.aten.where.self(le_scalar_51, new_zeros_default_376, to_dtype_153);  le_scalar_51 = new_zeros_default_376 = to_dtype_153 = None
        to_dtype_155 = torch.ops.aten.to.dtype(where_self_51, torch.float32);  where_self_51 = None
        native_batch_norm_backward_default_63 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_155, convolution_default_261, primals_1301, primals_1299, primals_1300, getitem_784, getitem_785, True, 1e-05, [True, True, True]);  to_dtype_155 = convolution_default_261 = primals_1301 = primals_1299 = primals_1300 = getitem_784 = getitem_785 = None
        getitem_1353 = native_batch_norm_backward_default_63[0]
        getitem_1354 = native_batch_norm_backward_default_63[1]
        getitem_1355 = native_batch_norm_backward_default_63[2];  native_batch_norm_backward_default_63 = None
        convolution_backward_default_63 = torch.ops.aten.convolution_backward.default(getitem_1353, relu__default_197, primals_1307, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1353 = primals_1307 = None
        getitem_1356 = convolution_backward_default_63[0]
        getitem_1357 = convolution_backward_default_63[1]
        getitem_1358 = convolution_backward_default_63[2];  convolution_backward_default_63 = None
        add_tensor_94 = torch.ops.aten.add.Tensor(to_dtype_152, getitem_1356);  to_dtype_152 = getitem_1356 = None
        to_dtype_156 = torch.ops.aten.to.dtype(add_tensor_94, torch.float32);  add_tensor_94 = None
        to_dtype_157 = torch.ops.aten.to.dtype(relu__default_197, torch.float32);  relu__default_197 = None
        le_scalar_52 = torch.ops.aten.le.Scalar(to_dtype_157, 0);  to_dtype_157 = None
        new_zeros_default_377 = torch.ops.aten.new_zeros.default(to_dtype_156, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_52 = torch.ops.aten.where.self(le_scalar_52, new_zeros_default_377, to_dtype_156);  le_scalar_52 = new_zeros_default_377 = to_dtype_156 = None
        to_dtype_158 = torch.ops.aten.to.dtype(where_self_52, torch.float32);  where_self_52 = None
        native_batch_norm_backward_default_64 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_158, convolution_default_260, primals_1294, primals_1292, primals_1293, getitem_781, getitem_782, True, 1e-05, [True, True, True]);  convolution_default_260 = primals_1294 = primals_1292 = primals_1293 = getitem_781 = getitem_782 = None
        getitem_1359 = native_batch_norm_backward_default_64[0]
        getitem_1360 = native_batch_norm_backward_default_64[1]
        getitem_1361 = native_batch_norm_backward_default_64[2];  native_batch_norm_backward_default_64 = None
        convolution_backward_default_64 = torch.ops.aten.convolution_backward.default(getitem_1359, relu__default_196, primals_1296, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1359 = primals_1296 = None
        getitem_1362 = convolution_backward_default_64[0]
        getitem_1363 = convolution_backward_default_64[1]
        getitem_1364 = convolution_backward_default_64[2];  convolution_backward_default_64 = None
        to_dtype_159 = torch.ops.aten.to.dtype(getitem_1362, torch.float32);  getitem_1362 = None
        to_dtype_160 = torch.ops.aten.to.dtype(relu__default_196, torch.float32);  relu__default_196 = None
        le_scalar_53 = torch.ops.aten.le.Scalar(to_dtype_160, 0);  to_dtype_160 = None
        new_zeros_default_378 = torch.ops.aten.new_zeros.default(to_dtype_159, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_53 = torch.ops.aten.where.self(le_scalar_53, new_zeros_default_378, to_dtype_159);  le_scalar_53 = new_zeros_default_378 = to_dtype_159 = None
        to_dtype_161 = torch.ops.aten.to.dtype(where_self_53, torch.float32);  where_self_53 = None
        native_batch_norm_backward_default_65 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_161, convolution_default_259, primals_1289, primals_1287, primals_1288, getitem_778, getitem_779, True, 1e-05, [True, True, True]);  to_dtype_161 = convolution_default_259 = primals_1289 = primals_1287 = primals_1288 = getitem_778 = getitem_779 = None
        getitem_1365 = native_batch_norm_backward_default_65[0]
        getitem_1366 = native_batch_norm_backward_default_65[1]
        getitem_1367 = native_batch_norm_backward_default_65[2];  native_batch_norm_backward_default_65 = None
        convolution_backward_default_65 = torch.ops.aten.convolution_backward.default(getitem_1365, relu__default_195, primals_1295, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1365 = primals_1295 = None
        getitem_1368 = convolution_backward_default_65[0]
        getitem_1369 = convolution_backward_default_65[1]
        getitem_1370 = convolution_backward_default_65[2];  convolution_backward_default_65 = None
        add_tensor_95 = torch.ops.aten.add.Tensor(to_dtype_158, getitem_1368);  to_dtype_158 = getitem_1368 = None
        to_dtype_162 = torch.ops.aten.to.dtype(add_tensor_95, torch.float32);  add_tensor_95 = None
        to_dtype_163 = torch.ops.aten.to.dtype(relu__default_195, torch.float32);  relu__default_195 = None
        le_scalar_54 = torch.ops.aten.le.Scalar(to_dtype_163, 0);  to_dtype_163 = None
        new_zeros_default_379 = torch.ops.aten.new_zeros.default(to_dtype_162, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_54 = torch.ops.aten.where.self(le_scalar_54, new_zeros_default_379, to_dtype_162);  le_scalar_54 = new_zeros_default_379 = to_dtype_162 = None
        to_dtype_164 = torch.ops.aten.to.dtype(where_self_54, torch.float32);  where_self_54 = None
        native_batch_norm_backward_default_66 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_164, convolution_default_258, primals_1282, primals_1280, primals_1281, getitem_775, getitem_776, True, 1e-05, [True, True, True]);  convolution_default_258 = primals_1282 = primals_1280 = primals_1281 = getitem_775 = getitem_776 = None
        getitem_1371 = native_batch_norm_backward_default_66[0]
        getitem_1372 = native_batch_norm_backward_default_66[1]
        getitem_1373 = native_batch_norm_backward_default_66[2];  native_batch_norm_backward_default_66 = None
        convolution_backward_default_66 = torch.ops.aten.convolution_backward.default(getitem_1371, relu__default_194, primals_1284, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1371 = primals_1284 = None
        getitem_1374 = convolution_backward_default_66[0]
        getitem_1375 = convolution_backward_default_66[1]
        getitem_1376 = convolution_backward_default_66[2];  convolution_backward_default_66 = None
        to_dtype_165 = torch.ops.aten.to.dtype(getitem_1374, torch.float32);  getitem_1374 = None
        to_dtype_166 = torch.ops.aten.to.dtype(relu__default_194, torch.float32);  relu__default_194 = None
        le_scalar_55 = torch.ops.aten.le.Scalar(to_dtype_166, 0);  to_dtype_166 = None
        new_zeros_default_380 = torch.ops.aten.new_zeros.default(to_dtype_165, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_55 = torch.ops.aten.where.self(le_scalar_55, new_zeros_default_380, to_dtype_165);  le_scalar_55 = new_zeros_default_380 = to_dtype_165 = None
        to_dtype_167 = torch.ops.aten.to.dtype(where_self_55, torch.float32);  where_self_55 = None
        native_batch_norm_backward_default_67 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_167, convolution_default_257, primals_1277, primals_1275, primals_1276, getitem_772, getitem_773, True, 1e-05, [True, True, True]);  to_dtype_167 = convolution_default_257 = primals_1277 = primals_1275 = primals_1276 = getitem_772 = getitem_773 = None
        getitem_1377 = native_batch_norm_backward_default_67[0]
        getitem_1378 = native_batch_norm_backward_default_67[1]
        getitem_1379 = native_batch_norm_backward_default_67[2];  native_batch_norm_backward_default_67 = None
        convolution_backward_default_67 = torch.ops.aten.convolution_backward.default(getitem_1377, relu_default_26, primals_1283, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1377 = primals_1283 = None
        getitem_1380 = convolution_backward_default_67[0]
        getitem_1381 = convolution_backward_default_67[1]
        getitem_1382 = convolution_backward_default_67[2];  convolution_backward_default_67 = None
        add_tensor_96 = torch.ops.aten.add.Tensor(to_dtype_164, getitem_1380);  to_dtype_164 = getitem_1380 = None
        to_dtype_168 = torch.ops.aten.to.dtype(add_tensor_84, torch.float32);  add_tensor_84 = None
        to_dtype_169 = torch.ops.aten.to.dtype(relu_default_33, torch.float32);  relu_default_33 = None
        le_scalar_56 = torch.ops.aten.le.Scalar(to_dtype_169, 0);  to_dtype_169 = None
        new_zeros_default_381 = torch.ops.aten.new_zeros.default(to_dtype_168, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_56 = torch.ops.aten.where.self(le_scalar_56, new_zeros_default_381, to_dtype_168);  le_scalar_56 = new_zeros_default_381 = to_dtype_168 = None
        to_dtype_170 = torch.ops.aten.to.dtype(where_self_56, torch.float32);  where_self_56 = None
        native_batch_norm_backward_default_68 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_170, convolution_default_256, primals_1842, primals_1840, primals_1841, getitem_769, getitem_770, True, 1e-05, [True, True, True]);  convolution_default_256 = primals_1842 = primals_1840 = primals_1841 = getitem_769 = getitem_770 = None
        getitem_1383 = native_batch_norm_backward_default_68[0]
        getitem_1384 = native_batch_norm_backward_default_68[1]
        getitem_1385 = native_batch_norm_backward_default_68[2];  native_batch_norm_backward_default_68 = None
        convolution_backward_default_68 = torch.ops.aten.convolution_backward.default(getitem_1383, relu__default_185, primals_1837, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1383 = primals_1837 = None
        getitem_1386 = convolution_backward_default_68[0]
        getitem_1387 = convolution_backward_default_68[1]
        getitem_1388 = convolution_backward_default_68[2];  convolution_backward_default_68 = None
        native_batch_norm_backward_default_69 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_170, convolution_default_255, primals_1734, primals_1732, primals_1733, getitem_766, getitem_767, True, 1e-05, [True, True, True]);  convolution_default_255 = primals_1734 = primals_1732 = primals_1733 = getitem_766 = getitem_767 = None
        getitem_1389 = native_batch_norm_backward_default_69[0]
        getitem_1390 = native_batch_norm_backward_default_69[1]
        getitem_1391 = native_batch_norm_backward_default_69[2];  native_batch_norm_backward_default_69 = None
        convolution_backward_default_69 = torch.ops.aten.convolution_backward.default(getitem_1389, relu_default_32, primals_1729, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1389 = primals_1729 = None
        getitem_1392 = convolution_backward_default_69[0]
        getitem_1393 = convolution_backward_default_69[1]
        getitem_1394 = convolution_backward_default_69[2];  convolution_backward_default_69 = None
        to_dtype_171 = torch.ops.aten.to.dtype(getitem_1392, torch.float32);  getitem_1392 = None
        to_dtype_172 = torch.ops.aten.to.dtype(relu_default_32, torch.float32);  relu_default_32 = None
        le_scalar_57 = torch.ops.aten.le.Scalar(to_dtype_172, 0);  to_dtype_172 = None
        new_zeros_default_382 = torch.ops.aten.new_zeros.default(to_dtype_171, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_57 = torch.ops.aten.where.self(le_scalar_57, new_zeros_default_382, to_dtype_171);  le_scalar_57 = new_zeros_default_382 = to_dtype_171 = None
        to_dtype_173 = torch.ops.aten.to.dtype(where_self_57, torch.float32);  where_self_57 = None
        native_batch_norm_backward_default_70 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_173, convolution_default_254, primals_1728, primals_1726, primals_1727, getitem_763, getitem_764, True, 1e-05, [True, True, True]);  to_dtype_173 = convolution_default_254 = primals_1728 = primals_1726 = primals_1727 = getitem_763 = getitem_764 = None
        getitem_1395 = native_batch_norm_backward_default_70[0]
        getitem_1396 = native_batch_norm_backward_default_70[1]
        getitem_1397 = native_batch_norm_backward_default_70[2];  native_batch_norm_backward_default_70 = None
        convolution_backward_default_70 = torch.ops.aten.convolution_backward.default(getitem_1395, relu__default_177, primals_1723, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1395 = primals_1723 = None
        getitem_1398 = convolution_backward_default_70[0]
        getitem_1399 = convolution_backward_default_70[1]
        getitem_1400 = convolution_backward_default_70[2];  convolution_backward_default_70 = None
        native_batch_norm_backward_default_71 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_170, convolution_default_253, primals_1560, primals_1558, primals_1559, getitem_760, getitem_761, True, 1e-05, [True, True, True]);  convolution_default_253 = primals_1560 = primals_1558 = primals_1559 = getitem_760 = getitem_761 = None
        getitem_1401 = native_batch_norm_backward_default_71[0]
        getitem_1402 = native_batch_norm_backward_default_71[1]
        getitem_1403 = native_batch_norm_backward_default_71[2];  native_batch_norm_backward_default_71 = None
        convolution_backward_default_71 = torch.ops.aten.convolution_backward.default(getitem_1401, relu_default_31, primals_1555, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1401 = primals_1555 = None
        getitem_1404 = convolution_backward_default_71[0]
        getitem_1405 = convolution_backward_default_71[1]
        getitem_1406 = convolution_backward_default_71[2];  convolution_backward_default_71 = None
        to_dtype_174 = torch.ops.aten.to.dtype(getitem_1404, torch.float32);  getitem_1404 = None
        to_dtype_175 = torch.ops.aten.to.dtype(relu_default_31, torch.float32);  relu_default_31 = None
        le_scalar_58 = torch.ops.aten.le.Scalar(to_dtype_175, 0);  to_dtype_175 = None
        new_zeros_default_383 = torch.ops.aten.new_zeros.default(to_dtype_174, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_58 = torch.ops.aten.where.self(le_scalar_58, new_zeros_default_383, to_dtype_174);  le_scalar_58 = new_zeros_default_383 = to_dtype_174 = None
        to_dtype_176 = torch.ops.aten.to.dtype(where_self_58, torch.float32);  where_self_58 = None
        native_batch_norm_backward_default_72 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_176, convolution_default_252, primals_1554, primals_1552, primals_1553, getitem_757, getitem_758, True, 1e-05, [True, True, True]);  to_dtype_176 = convolution_default_252 = primals_1554 = primals_1552 = primals_1553 = getitem_757 = getitem_758 = None
        getitem_1407 = native_batch_norm_backward_default_72[0]
        getitem_1408 = native_batch_norm_backward_default_72[1]
        getitem_1409 = native_batch_norm_backward_default_72[2];  native_batch_norm_backward_default_72 = None
        convolution_backward_default_72 = torch.ops.aten.convolution_backward.default(getitem_1407, relu_default_30, primals_1549, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1407 = primals_1549 = None
        getitem_1410 = convolution_backward_default_72[0]
        getitem_1411 = convolution_backward_default_72[1]
        getitem_1412 = convolution_backward_default_72[2];  convolution_backward_default_72 = None
        to_dtype_177 = torch.ops.aten.to.dtype(getitem_1410, torch.float32);  getitem_1410 = None
        to_dtype_178 = torch.ops.aten.to.dtype(relu_default_30, torch.float32);  relu_default_30 = None
        le_scalar_59 = torch.ops.aten.le.Scalar(to_dtype_178, 0);  to_dtype_178 = None
        new_zeros_default_384 = torch.ops.aten.new_zeros.default(to_dtype_177, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_59 = torch.ops.aten.where.self(le_scalar_59, new_zeros_default_384, to_dtype_177);  le_scalar_59 = new_zeros_default_384 = to_dtype_177 = None
        to_dtype_179 = torch.ops.aten.to.dtype(where_self_59, torch.float32);  where_self_59 = None
        native_batch_norm_backward_default_73 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_179, convolution_default_251, primals_1548, primals_1546, primals_1547, getitem_754, getitem_755, True, 1e-05, [True, True, True]);  to_dtype_179 = convolution_default_251 = primals_1548 = primals_1546 = primals_1547 = getitem_754 = getitem_755 = None
        getitem_1413 = native_batch_norm_backward_default_73[0]
        getitem_1414 = native_batch_norm_backward_default_73[1]
        getitem_1415 = native_batch_norm_backward_default_73[2];  native_batch_norm_backward_default_73 = None
        convolution_backward_default_73 = torch.ops.aten.convolution_backward.default(getitem_1413, relu__default_169, primals_1543, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1413 = primals_1543 = None
        getitem_1416 = convolution_backward_default_73[0]
        getitem_1417 = convolution_backward_default_73[1]
        getitem_1418 = convolution_backward_default_73[2];  convolution_backward_default_73 = None
        to_dtype_180 = torch.ops.aten.to.dtype(add_tensor_88, torch.float32);  add_tensor_88 = None
        to_dtype_181 = torch.ops.aten.to.dtype(relu_default_29, torch.float32);  relu_default_29 = None
        le_scalar_60 = torch.ops.aten.le.Scalar(to_dtype_181, 0);  to_dtype_181 = None
        new_zeros_default_385 = torch.ops.aten.new_zeros.default(to_dtype_180, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_60 = torch.ops.aten.where.self(le_scalar_60, new_zeros_default_385, to_dtype_180);  le_scalar_60 = new_zeros_default_385 = to_dtype_180 = None
        to_dtype_182 = torch.ops.aten.to.dtype(where_self_60, torch.float32);  where_self_60 = None
        upsample_nearest2d_backward_vec_6 = torch.ops.aten.upsample_nearest2d_backward.vec(to_dtype_182, None, [128, 72, 7, 7], [2.0, 2.0])
        native_batch_norm_backward_default_74 = torch.ops.aten.native_batch_norm_backward.default(upsample_nearest2d_backward_vec_6, convolution_default_250, primals_1944, primals_1942, primals_1943, getitem_751, getitem_752, True, 1e-05, [True, True, True]);  upsample_nearest2d_backward_vec_6 = convolution_default_250 = primals_1944 = primals_1942 = primals_1943 = getitem_751 = getitem_752 = None
        getitem_1419 = native_batch_norm_backward_default_74[0]
        getitem_1420 = native_batch_norm_backward_default_74[1]
        getitem_1421 = native_batch_norm_backward_default_74[2];  native_batch_norm_backward_default_74 = None
        convolution_backward_default_74 = torch.ops.aten.convolution_backward.default(getitem_1419, relu__default_193, primals_1939, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1419 = primals_1939 = None
        getitem_1422 = convolution_backward_default_74[0]
        getitem_1423 = convolution_backward_default_74[1]
        getitem_1424 = convolution_backward_default_74[2];  convolution_backward_default_74 = None
        add_tensor_97 = torch.ops.aten.add.Tensor(to_dtype_170, getitem_1422);  to_dtype_170 = getitem_1422 = None
        add_tensor_98 = torch.ops.aten.add.Tensor(getitem_1386, to_dtype_182);  getitem_1386 = None
        native_batch_norm_backward_default_75 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_182, convolution_default_249, primals_1722, primals_1720, primals_1721, getitem_748, getitem_749, True, 1e-05, [True, True, True]);  convolution_default_249 = primals_1722 = primals_1720 = primals_1721 = getitem_748 = getitem_749 = None
        getitem_1425 = native_batch_norm_backward_default_75[0]
        getitem_1426 = native_batch_norm_backward_default_75[1]
        getitem_1427 = native_batch_norm_backward_default_75[2];  native_batch_norm_backward_default_75 = None
        convolution_backward_default_75 = torch.ops.aten.convolution_backward.default(getitem_1425, relu__default_177, primals_1717, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1425 = primals_1717 = None
        getitem_1428 = convolution_backward_default_75[0]
        getitem_1429 = convolution_backward_default_75[1]
        getitem_1430 = convolution_backward_default_75[2];  convolution_backward_default_75 = None
        add_tensor_99 = torch.ops.aten.add.Tensor(getitem_1398, getitem_1428);  getitem_1398 = getitem_1428 = None
        native_batch_norm_backward_default_76 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_182, convolution_default_248, primals_1542, primals_1540, primals_1541, getitem_745, getitem_746, True, 1e-05, [True, True, True]);  to_dtype_182 = convolution_default_248 = primals_1542 = primals_1540 = primals_1541 = getitem_745 = getitem_746 = None
        getitem_1431 = native_batch_norm_backward_default_76[0]
        getitem_1432 = native_batch_norm_backward_default_76[1]
        getitem_1433 = native_batch_norm_backward_default_76[2];  native_batch_norm_backward_default_76 = None
        convolution_backward_default_76 = torch.ops.aten.convolution_backward.default(getitem_1431, relu_default_28, primals_1537, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1431 = primals_1537 = None
        getitem_1434 = convolution_backward_default_76[0]
        getitem_1435 = convolution_backward_default_76[1]
        getitem_1436 = convolution_backward_default_76[2];  convolution_backward_default_76 = None
        to_dtype_183 = torch.ops.aten.to.dtype(getitem_1434, torch.float32);  getitem_1434 = None
        to_dtype_184 = torch.ops.aten.to.dtype(relu_default_28, torch.float32);  relu_default_28 = None
        le_scalar_61 = torch.ops.aten.le.Scalar(to_dtype_184, 0);  to_dtype_184 = None
        new_zeros_default_386 = torch.ops.aten.new_zeros.default(to_dtype_183, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_61 = torch.ops.aten.where.self(le_scalar_61, new_zeros_default_386, to_dtype_183);  le_scalar_61 = new_zeros_default_386 = to_dtype_183 = None
        to_dtype_185 = torch.ops.aten.to.dtype(where_self_61, torch.float32);  where_self_61 = None
        native_batch_norm_backward_default_77 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_185, convolution_default_247, primals_1536, primals_1534, primals_1535, getitem_742, getitem_743, True, 1e-05, [True, True, True]);  to_dtype_185 = convolution_default_247 = primals_1536 = primals_1534 = primals_1535 = getitem_742 = getitem_743 = None
        getitem_1437 = native_batch_norm_backward_default_77[0]
        getitem_1438 = native_batch_norm_backward_default_77[1]
        getitem_1439 = native_batch_norm_backward_default_77[2];  native_batch_norm_backward_default_77 = None
        convolution_backward_default_77 = torch.ops.aten.convolution_backward.default(getitem_1437, relu__default_169, primals_1531, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1437 = primals_1531 = None
        getitem_1440 = convolution_backward_default_77[0]
        getitem_1441 = convolution_backward_default_77[1]
        getitem_1442 = convolution_backward_default_77[2];  convolution_backward_default_77 = None
        add_tensor_100 = torch.ops.aten.add.Tensor(getitem_1416, getitem_1440);  getitem_1416 = getitem_1440 = None
        to_dtype_186 = torch.ops.aten.to.dtype(add_tensor_92, torch.float32);  add_tensor_92 = None
        to_dtype_187 = torch.ops.aten.to.dtype(relu_default_27, torch.float32);  relu_default_27 = None
        le_scalar_62 = torch.ops.aten.le.Scalar(to_dtype_187, 0);  to_dtype_187 = None
        new_zeros_default_387 = torch.ops.aten.new_zeros.default(to_dtype_186, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_62 = torch.ops.aten.where.self(le_scalar_62, new_zeros_default_387, to_dtype_186);  le_scalar_62 = new_zeros_default_387 = to_dtype_186 = None
        to_dtype_188 = torch.ops.aten.to.dtype(where_self_62, torch.float32);  where_self_62 = None
        upsample_nearest2d_backward_vec_7 = torch.ops.aten.upsample_nearest2d_backward.vec(to_dtype_188, None, [128, 36, 7, 7], [4.0, 4.0])
        native_batch_norm_backward_default_78 = torch.ops.aten.native_batch_norm_backward.default(upsample_nearest2d_backward_vec_7, convolution_default_246, primals_1938, primals_1936, primals_1937, getitem_739, getitem_740, True, 1e-05, [True, True, True]);  upsample_nearest2d_backward_vec_7 = convolution_default_246 = primals_1938 = primals_1936 = primals_1937 = getitem_739 = getitem_740 = None
        getitem_1443 = native_batch_norm_backward_default_78[0]
        getitem_1444 = native_batch_norm_backward_default_78[1]
        getitem_1445 = native_batch_norm_backward_default_78[2];  native_batch_norm_backward_default_78 = None
        convolution_backward_default_78 = torch.ops.aten.convolution_backward.default(getitem_1443, relu__default_193, primals_1933, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1443 = primals_1933 = None
        getitem_1446 = convolution_backward_default_78[0]
        getitem_1447 = convolution_backward_default_78[1]
        getitem_1448 = convolution_backward_default_78[2];  convolution_backward_default_78 = None
        add_tensor_101 = torch.ops.aten.add.Tensor(add_tensor_97, getitem_1446);  add_tensor_97 = getitem_1446 = None
        upsample_nearest2d_backward_vec_8 = torch.ops.aten.upsample_nearest2d_backward.vec(to_dtype_188, None, [128, 36, 14, 14], [2.0, 2.0])
        native_batch_norm_backward_default_79 = torch.ops.aten.native_batch_norm_backward.default(upsample_nearest2d_backward_vec_8, convolution_default_245, primals_1836, primals_1834, primals_1835, getitem_736, getitem_737, True, 1e-05, [True, True, True]);  upsample_nearest2d_backward_vec_8 = convolution_default_245 = primals_1836 = primals_1834 = primals_1835 = getitem_736 = getitem_737 = None
        getitem_1449 = native_batch_norm_backward_default_79[0]
        getitem_1450 = native_batch_norm_backward_default_79[1]
        getitem_1451 = native_batch_norm_backward_default_79[2];  native_batch_norm_backward_default_79 = None
        convolution_backward_default_79 = torch.ops.aten.convolution_backward.default(getitem_1449, relu__default_185, primals_1831, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1449 = primals_1831 = None
        getitem_1452 = convolution_backward_default_79[0]
        getitem_1453 = convolution_backward_default_79[1]
        getitem_1454 = convolution_backward_default_79[2];  convolution_backward_default_79 = None
        add_tensor_102 = torch.ops.aten.add.Tensor(add_tensor_98, getitem_1452);  add_tensor_98 = getitem_1452 = None
        add_tensor_103 = torch.ops.aten.add.Tensor(add_tensor_99, to_dtype_188);  add_tensor_99 = None
        native_batch_norm_backward_default_80 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_188, convolution_default_244, primals_1530, primals_1528, primals_1529, getitem_733, getitem_734, True, 1e-05, [True, True, True]);  to_dtype_188 = convolution_default_244 = primals_1530 = primals_1528 = primals_1529 = getitem_733 = getitem_734 = None
        getitem_1455 = native_batch_norm_backward_default_80[0]
        getitem_1456 = native_batch_norm_backward_default_80[1]
        getitem_1457 = native_batch_norm_backward_default_80[2];  native_batch_norm_backward_default_80 = None
        convolution_backward_default_80 = torch.ops.aten.convolution_backward.default(getitem_1455, relu__default_169, primals_1525, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1455 = primals_1525 = None
        getitem_1458 = convolution_backward_default_80[0]
        getitem_1459 = convolution_backward_default_80[1]
        getitem_1460 = convolution_backward_default_80[2];  convolution_backward_default_80 = None
        add_tensor_104 = torch.ops.aten.add.Tensor(add_tensor_100, getitem_1458);  add_tensor_100 = getitem_1458 = None
        to_dtype_189 = torch.ops.aten.to.dtype(add_tensor_96, torch.float32);  add_tensor_96 = None
        to_dtype_190 = torch.ops.aten.to.dtype(relu_default_26, torch.float32);  relu_default_26 = None
        le_scalar_63 = torch.ops.aten.le.Scalar(to_dtype_190, 0);  to_dtype_190 = None
        new_zeros_default_388 = torch.ops.aten.new_zeros.default(to_dtype_189, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_63 = torch.ops.aten.where.self(le_scalar_63, new_zeros_default_388, to_dtype_189);  le_scalar_63 = new_zeros_default_388 = to_dtype_189 = None
        to_dtype_191 = torch.ops.aten.to.dtype(where_self_63, torch.float32);  where_self_63 = None
        upsample_nearest2d_backward_vec_9 = torch.ops.aten.upsample_nearest2d_backward.vec(to_dtype_191, None, [128, 18, 7, 7], [8.0, 8.0])
        native_batch_norm_backward_default_81 = torch.ops.aten.native_batch_norm_backward.default(upsample_nearest2d_backward_vec_9, convolution_default_243, primals_1932, primals_1930, primals_1931, getitem_730, getitem_731, True, 1e-05, [True, True, True]);  upsample_nearest2d_backward_vec_9 = convolution_default_243 = primals_1932 = primals_1930 = primals_1931 = getitem_730 = getitem_731 = None
        getitem_1461 = native_batch_norm_backward_default_81[0]
        getitem_1462 = native_batch_norm_backward_default_81[1]
        getitem_1463 = native_batch_norm_backward_default_81[2];  native_batch_norm_backward_default_81 = None
        convolution_backward_default_81 = torch.ops.aten.convolution_backward.default(getitem_1461, relu__default_193, primals_1927, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1461 = primals_1927 = None
        getitem_1464 = convolution_backward_default_81[0]
        getitem_1465 = convolution_backward_default_81[1]
        getitem_1466 = convolution_backward_default_81[2];  convolution_backward_default_81 = None
        add_tensor_105 = torch.ops.aten.add.Tensor(add_tensor_101, getitem_1464);  add_tensor_101 = getitem_1464 = None
        upsample_nearest2d_backward_vec_10 = torch.ops.aten.upsample_nearest2d_backward.vec(to_dtype_191, None, [128, 18, 14, 14], [4.0, 4.0])
        native_batch_norm_backward_default_82 = torch.ops.aten.native_batch_norm_backward.default(upsample_nearest2d_backward_vec_10, convolution_default_242, primals_1830, primals_1828, primals_1829, getitem_727, getitem_728, True, 1e-05, [True, True, True]);  upsample_nearest2d_backward_vec_10 = convolution_default_242 = primals_1830 = primals_1828 = primals_1829 = getitem_727 = getitem_728 = None
        getitem_1467 = native_batch_norm_backward_default_82[0]
        getitem_1468 = native_batch_norm_backward_default_82[1]
        getitem_1469 = native_batch_norm_backward_default_82[2];  native_batch_norm_backward_default_82 = None
        convolution_backward_default_82 = torch.ops.aten.convolution_backward.default(getitem_1467, relu__default_185, primals_1825, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1467 = primals_1825 = None
        getitem_1470 = convolution_backward_default_82[0]
        getitem_1471 = convolution_backward_default_82[1]
        getitem_1472 = convolution_backward_default_82[2];  convolution_backward_default_82 = None
        add_tensor_106 = torch.ops.aten.add.Tensor(add_tensor_102, getitem_1470);  add_tensor_102 = getitem_1470 = None
        add_tensor_107 = torch.ops.aten.add.Tensor(add_tensor_104, to_dtype_191);  add_tensor_104 = None
        upsample_nearest2d_backward_vec_11 = torch.ops.aten.upsample_nearest2d_backward.vec(to_dtype_191, None, [128, 18, 28, 28], [2.0, 2.0]);  to_dtype_191 = None
        native_batch_norm_backward_default_83 = torch.ops.aten.native_batch_norm_backward.default(upsample_nearest2d_backward_vec_11, convolution_default_241, primals_1716, primals_1714, primals_1715, getitem_724, getitem_725, True, 1e-05, [True, True, True]);  upsample_nearest2d_backward_vec_11 = convolution_default_241 = primals_1716 = primals_1714 = primals_1715 = getitem_724 = getitem_725 = None
        getitem_1473 = native_batch_norm_backward_default_83[0]
        getitem_1474 = native_batch_norm_backward_default_83[1]
        getitem_1475 = native_batch_norm_backward_default_83[2];  native_batch_norm_backward_default_83 = None
        convolution_backward_default_83 = torch.ops.aten.convolution_backward.default(getitem_1473, relu__default_177, primals_1711, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1473 = primals_1711 = None
        getitem_1476 = convolution_backward_default_83[0]
        getitem_1477 = convolution_backward_default_83[1]
        getitem_1478 = convolution_backward_default_83[2];  convolution_backward_default_83 = None
        add_tensor_108 = torch.ops.aten.add.Tensor(add_tensor_103, getitem_1476);  add_tensor_103 = getitem_1476 = None
        to_dtype_192 = torch.ops.aten.to.dtype(add_tensor_105, torch.float32);  add_tensor_105 = None
        to_dtype_193 = torch.ops.aten.to.dtype(relu__default_193, torch.float32);  relu__default_193 = None
        le_scalar_64 = torch.ops.aten.le.Scalar(to_dtype_193, 0);  to_dtype_193 = None
        new_zeros_default_389 = torch.ops.aten.new_zeros.default(to_dtype_192, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_64 = torch.ops.aten.where.self(le_scalar_64, new_zeros_default_389, to_dtype_192);  le_scalar_64 = new_zeros_default_389 = to_dtype_192 = None
        to_dtype_194 = torch.ops.aten.to.dtype(where_self_64, torch.float32);  where_self_64 = None
        native_batch_norm_backward_default_84 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_194, convolution_default_240, primals_1270, primals_1268, primals_1269, getitem_721, getitem_722, True, 1e-05, [True, True, True]);  convolution_default_240 = primals_1270 = primals_1268 = primals_1269 = getitem_721 = getitem_722 = None
        getitem_1479 = native_batch_norm_backward_default_84[0]
        getitem_1480 = native_batch_norm_backward_default_84[1]
        getitem_1481 = native_batch_norm_backward_default_84[2];  native_batch_norm_backward_default_84 = None
        convolution_backward_default_84 = torch.ops.aten.convolution_backward.default(getitem_1479, relu__default_192, primals_1272, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1479 = primals_1272 = None
        getitem_1482 = convolution_backward_default_84[0]
        getitem_1483 = convolution_backward_default_84[1]
        getitem_1484 = convolution_backward_default_84[2];  convolution_backward_default_84 = None
        to_dtype_195 = torch.ops.aten.to.dtype(getitem_1482, torch.float32);  getitem_1482 = None
        to_dtype_196 = torch.ops.aten.to.dtype(relu__default_192, torch.float32);  relu__default_192 = None
        le_scalar_65 = torch.ops.aten.le.Scalar(to_dtype_196, 0);  to_dtype_196 = None
        new_zeros_default_390 = torch.ops.aten.new_zeros.default(to_dtype_195, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_65 = torch.ops.aten.where.self(le_scalar_65, new_zeros_default_390, to_dtype_195);  le_scalar_65 = new_zeros_default_390 = to_dtype_195 = None
        to_dtype_197 = torch.ops.aten.to.dtype(where_self_65, torch.float32);  where_self_65 = None
        native_batch_norm_backward_default_85 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_197, convolution_default_239, primals_1265, primals_1263, primals_1264, getitem_718, getitem_719, True, 1e-05, [True, True, True]);  to_dtype_197 = convolution_default_239 = primals_1265 = primals_1263 = primals_1264 = getitem_718 = getitem_719 = None
        getitem_1485 = native_batch_norm_backward_default_85[0]
        getitem_1486 = native_batch_norm_backward_default_85[1]
        getitem_1487 = native_batch_norm_backward_default_85[2];  native_batch_norm_backward_default_85 = None
        convolution_backward_default_85 = torch.ops.aten.convolution_backward.default(getitem_1485, relu__default_191, primals_1271, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1485 = primals_1271 = None
        getitem_1488 = convolution_backward_default_85[0]
        getitem_1489 = convolution_backward_default_85[1]
        getitem_1490 = convolution_backward_default_85[2];  convolution_backward_default_85 = None
        add_tensor_109 = torch.ops.aten.add.Tensor(to_dtype_194, getitem_1488);  to_dtype_194 = getitem_1488 = None
        to_dtype_198 = torch.ops.aten.to.dtype(add_tensor_109, torch.float32);  add_tensor_109 = None
        to_dtype_199 = torch.ops.aten.to.dtype(relu__default_191, torch.float32);  relu__default_191 = None
        le_scalar_66 = torch.ops.aten.le.Scalar(to_dtype_199, 0);  to_dtype_199 = None
        new_zeros_default_391 = torch.ops.aten.new_zeros.default(to_dtype_198, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_66 = torch.ops.aten.where.self(le_scalar_66, new_zeros_default_391, to_dtype_198);  le_scalar_66 = new_zeros_default_391 = to_dtype_198 = None
        to_dtype_200 = torch.ops.aten.to.dtype(where_self_66, torch.float32);  where_self_66 = None
        native_batch_norm_backward_default_86 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_200, convolution_default_238, primals_1258, primals_1256, primals_1257, getitem_715, getitem_716, True, 1e-05, [True, True, True]);  convolution_default_238 = primals_1258 = primals_1256 = primals_1257 = getitem_715 = getitem_716 = None
        getitem_1491 = native_batch_norm_backward_default_86[0]
        getitem_1492 = native_batch_norm_backward_default_86[1]
        getitem_1493 = native_batch_norm_backward_default_86[2];  native_batch_norm_backward_default_86 = None
        convolution_backward_default_86 = torch.ops.aten.convolution_backward.default(getitem_1491, relu__default_190, primals_1260, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1491 = primals_1260 = None
        getitem_1494 = convolution_backward_default_86[0]
        getitem_1495 = convolution_backward_default_86[1]
        getitem_1496 = convolution_backward_default_86[2];  convolution_backward_default_86 = None
        to_dtype_201 = torch.ops.aten.to.dtype(getitem_1494, torch.float32);  getitem_1494 = None
        to_dtype_202 = torch.ops.aten.to.dtype(relu__default_190, torch.float32);  relu__default_190 = None
        le_scalar_67 = torch.ops.aten.le.Scalar(to_dtype_202, 0);  to_dtype_202 = None
        new_zeros_default_392 = torch.ops.aten.new_zeros.default(to_dtype_201, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_67 = torch.ops.aten.where.self(le_scalar_67, new_zeros_default_392, to_dtype_201);  le_scalar_67 = new_zeros_default_392 = to_dtype_201 = None
        to_dtype_203 = torch.ops.aten.to.dtype(where_self_67, torch.float32);  where_self_67 = None
        native_batch_norm_backward_default_87 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_203, convolution_default_237, primals_1253, primals_1251, primals_1252, getitem_712, getitem_713, True, 1e-05, [True, True, True]);  to_dtype_203 = convolution_default_237 = primals_1253 = primals_1251 = primals_1252 = getitem_712 = getitem_713 = None
        getitem_1497 = native_batch_norm_backward_default_87[0]
        getitem_1498 = native_batch_norm_backward_default_87[1]
        getitem_1499 = native_batch_norm_backward_default_87[2];  native_batch_norm_backward_default_87 = None
        convolution_backward_default_87 = torch.ops.aten.convolution_backward.default(getitem_1497, relu__default_189, primals_1259, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1497 = primals_1259 = None
        getitem_1500 = convolution_backward_default_87[0]
        getitem_1501 = convolution_backward_default_87[1]
        getitem_1502 = convolution_backward_default_87[2];  convolution_backward_default_87 = None
        add_tensor_110 = torch.ops.aten.add.Tensor(to_dtype_200, getitem_1500);  to_dtype_200 = getitem_1500 = None
        to_dtype_204 = torch.ops.aten.to.dtype(add_tensor_110, torch.float32);  add_tensor_110 = None
        to_dtype_205 = torch.ops.aten.to.dtype(relu__default_189, torch.float32);  relu__default_189 = None
        le_scalar_68 = torch.ops.aten.le.Scalar(to_dtype_205, 0);  to_dtype_205 = None
        new_zeros_default_393 = torch.ops.aten.new_zeros.default(to_dtype_204, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_68 = torch.ops.aten.where.self(le_scalar_68, new_zeros_default_393, to_dtype_204);  le_scalar_68 = new_zeros_default_393 = to_dtype_204 = None
        to_dtype_206 = torch.ops.aten.to.dtype(where_self_68, torch.float32);  where_self_68 = None
        native_batch_norm_backward_default_88 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_206, convolution_default_236, primals_1246, primals_1244, primals_1245, getitem_709, getitem_710, True, 1e-05, [True, True, True]);  convolution_default_236 = primals_1246 = primals_1244 = primals_1245 = getitem_709 = getitem_710 = None
        getitem_1503 = native_batch_norm_backward_default_88[0]
        getitem_1504 = native_batch_norm_backward_default_88[1]
        getitem_1505 = native_batch_norm_backward_default_88[2];  native_batch_norm_backward_default_88 = None
        convolution_backward_default_88 = torch.ops.aten.convolution_backward.default(getitem_1503, relu__default_188, primals_1248, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1503 = primals_1248 = None
        getitem_1506 = convolution_backward_default_88[0]
        getitem_1507 = convolution_backward_default_88[1]
        getitem_1508 = convolution_backward_default_88[2];  convolution_backward_default_88 = None
        to_dtype_207 = torch.ops.aten.to.dtype(getitem_1506, torch.float32);  getitem_1506 = None
        to_dtype_208 = torch.ops.aten.to.dtype(relu__default_188, torch.float32);  relu__default_188 = None
        le_scalar_69 = torch.ops.aten.le.Scalar(to_dtype_208, 0);  to_dtype_208 = None
        new_zeros_default_394 = torch.ops.aten.new_zeros.default(to_dtype_207, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_69 = torch.ops.aten.where.self(le_scalar_69, new_zeros_default_394, to_dtype_207);  le_scalar_69 = new_zeros_default_394 = to_dtype_207 = None
        to_dtype_209 = torch.ops.aten.to.dtype(where_self_69, torch.float32);  where_self_69 = None
        native_batch_norm_backward_default_89 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_209, convolution_default_235, primals_1241, primals_1239, primals_1240, getitem_706, getitem_707, True, 1e-05, [True, True, True]);  to_dtype_209 = convolution_default_235 = primals_1241 = primals_1239 = primals_1240 = getitem_706 = getitem_707 = None
        getitem_1509 = native_batch_norm_backward_default_89[0]
        getitem_1510 = native_batch_norm_backward_default_89[1]
        getitem_1511 = native_batch_norm_backward_default_89[2];  native_batch_norm_backward_default_89 = None
        convolution_backward_default_89 = torch.ops.aten.convolution_backward.default(getitem_1509, relu__default_187, primals_1247, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1509 = primals_1247 = None
        getitem_1512 = convolution_backward_default_89[0]
        getitem_1513 = convolution_backward_default_89[1]
        getitem_1514 = convolution_backward_default_89[2];  convolution_backward_default_89 = None
        add_tensor_111 = torch.ops.aten.add.Tensor(to_dtype_206, getitem_1512);  to_dtype_206 = getitem_1512 = None
        to_dtype_210 = torch.ops.aten.to.dtype(add_tensor_111, torch.float32);  add_tensor_111 = None
        to_dtype_211 = torch.ops.aten.to.dtype(relu__default_187, torch.float32);  relu__default_187 = None
        le_scalar_70 = torch.ops.aten.le.Scalar(to_dtype_211, 0);  to_dtype_211 = None
        new_zeros_default_395 = torch.ops.aten.new_zeros.default(to_dtype_210, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_70 = torch.ops.aten.where.self(le_scalar_70, new_zeros_default_395, to_dtype_210);  le_scalar_70 = new_zeros_default_395 = to_dtype_210 = None
        to_dtype_212 = torch.ops.aten.to.dtype(where_self_70, torch.float32);  where_self_70 = None
        native_batch_norm_backward_default_90 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_212, convolution_default_234, primals_1234, primals_1232, primals_1233, getitem_703, getitem_704, True, 1e-05, [True, True, True]);  convolution_default_234 = primals_1234 = primals_1232 = primals_1233 = getitem_703 = getitem_704 = None
        getitem_1515 = native_batch_norm_backward_default_90[0]
        getitem_1516 = native_batch_norm_backward_default_90[1]
        getitem_1517 = native_batch_norm_backward_default_90[2];  native_batch_norm_backward_default_90 = None
        convolution_backward_default_90 = torch.ops.aten.convolution_backward.default(getitem_1515, relu__default_186, primals_1236, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1515 = primals_1236 = None
        getitem_1518 = convolution_backward_default_90[0]
        getitem_1519 = convolution_backward_default_90[1]
        getitem_1520 = convolution_backward_default_90[2];  convolution_backward_default_90 = None
        to_dtype_213 = torch.ops.aten.to.dtype(getitem_1518, torch.float32);  getitem_1518 = None
        to_dtype_214 = torch.ops.aten.to.dtype(relu__default_186, torch.float32);  relu__default_186 = None
        le_scalar_71 = torch.ops.aten.le.Scalar(to_dtype_214, 0);  to_dtype_214 = None
        new_zeros_default_396 = torch.ops.aten.new_zeros.default(to_dtype_213, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_71 = torch.ops.aten.where.self(le_scalar_71, new_zeros_default_396, to_dtype_213);  le_scalar_71 = new_zeros_default_396 = to_dtype_213 = None
        to_dtype_215 = torch.ops.aten.to.dtype(where_self_71, torch.float32);  where_self_71 = None
        native_batch_norm_backward_default_91 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_215, convolution_default_233, primals_1229, primals_1227, primals_1228, getitem_700, getitem_701, True, 1e-05, [True, True, True]);  to_dtype_215 = convolution_default_233 = primals_1229 = primals_1227 = primals_1228 = getitem_700 = getitem_701 = None
        getitem_1521 = native_batch_norm_backward_default_91[0]
        getitem_1522 = native_batch_norm_backward_default_91[1]
        getitem_1523 = native_batch_norm_backward_default_91[2];  native_batch_norm_backward_default_91 = None
        convolution_backward_default_91 = torch.ops.aten.convolution_backward.default(getitem_1521, relu_default_25, primals_1235, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1521 = primals_1235 = None
        getitem_1524 = convolution_backward_default_91[0]
        getitem_1525 = convolution_backward_default_91[1]
        getitem_1526 = convolution_backward_default_91[2];  convolution_backward_default_91 = None
        add_tensor_112 = torch.ops.aten.add.Tensor(to_dtype_212, getitem_1524);  to_dtype_212 = getitem_1524 = None
        to_dtype_216 = torch.ops.aten.to.dtype(add_tensor_106, torch.float32);  add_tensor_106 = None
        to_dtype_217 = torch.ops.aten.to.dtype(relu__default_185, torch.float32);  relu__default_185 = None
        le_scalar_72 = torch.ops.aten.le.Scalar(to_dtype_217, 0);  to_dtype_217 = None
        new_zeros_default_397 = torch.ops.aten.new_zeros.default(to_dtype_216, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_72 = torch.ops.aten.where.self(le_scalar_72, new_zeros_default_397, to_dtype_216);  le_scalar_72 = new_zeros_default_397 = to_dtype_216 = None
        to_dtype_218 = torch.ops.aten.to.dtype(where_self_72, torch.float32);  where_self_72 = None
        native_batch_norm_backward_default_92 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_218, convolution_default_232, primals_1222, primals_1220, primals_1221, getitem_697, getitem_698, True, 1e-05, [True, True, True]);  convolution_default_232 = primals_1222 = primals_1220 = primals_1221 = getitem_697 = getitem_698 = None
        getitem_1527 = native_batch_norm_backward_default_92[0]
        getitem_1528 = native_batch_norm_backward_default_92[1]
        getitem_1529 = native_batch_norm_backward_default_92[2];  native_batch_norm_backward_default_92 = None
        convolution_backward_default_92 = torch.ops.aten.convolution_backward.default(getitem_1527, relu__default_184, primals_1224, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1527 = primals_1224 = None
        getitem_1530 = convolution_backward_default_92[0]
        getitem_1531 = convolution_backward_default_92[1]
        getitem_1532 = convolution_backward_default_92[2];  convolution_backward_default_92 = None
        to_dtype_219 = torch.ops.aten.to.dtype(getitem_1530, torch.float32);  getitem_1530 = None
        to_dtype_220 = torch.ops.aten.to.dtype(relu__default_184, torch.float32);  relu__default_184 = None
        le_scalar_73 = torch.ops.aten.le.Scalar(to_dtype_220, 0);  to_dtype_220 = None
        new_zeros_default_398 = torch.ops.aten.new_zeros.default(to_dtype_219, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_73 = torch.ops.aten.where.self(le_scalar_73, new_zeros_default_398, to_dtype_219);  le_scalar_73 = new_zeros_default_398 = to_dtype_219 = None
        to_dtype_221 = torch.ops.aten.to.dtype(where_self_73, torch.float32);  where_self_73 = None
        native_batch_norm_backward_default_93 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_221, convolution_default_231, primals_1217, primals_1215, primals_1216, getitem_694, getitem_695, True, 1e-05, [True, True, True]);  to_dtype_221 = convolution_default_231 = primals_1217 = primals_1215 = primals_1216 = getitem_694 = getitem_695 = None
        getitem_1533 = native_batch_norm_backward_default_93[0]
        getitem_1534 = native_batch_norm_backward_default_93[1]
        getitem_1535 = native_batch_norm_backward_default_93[2];  native_batch_norm_backward_default_93 = None
        convolution_backward_default_93 = torch.ops.aten.convolution_backward.default(getitem_1533, relu__default_183, primals_1223, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1533 = primals_1223 = None
        getitem_1536 = convolution_backward_default_93[0]
        getitem_1537 = convolution_backward_default_93[1]
        getitem_1538 = convolution_backward_default_93[2];  convolution_backward_default_93 = None
        add_tensor_113 = torch.ops.aten.add.Tensor(to_dtype_218, getitem_1536);  to_dtype_218 = getitem_1536 = None
        to_dtype_222 = torch.ops.aten.to.dtype(add_tensor_113, torch.float32);  add_tensor_113 = None
        to_dtype_223 = torch.ops.aten.to.dtype(relu__default_183, torch.float32);  relu__default_183 = None
        le_scalar_74 = torch.ops.aten.le.Scalar(to_dtype_223, 0);  to_dtype_223 = None
        new_zeros_default_399 = torch.ops.aten.new_zeros.default(to_dtype_222, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_74 = torch.ops.aten.where.self(le_scalar_74, new_zeros_default_399, to_dtype_222);  le_scalar_74 = new_zeros_default_399 = to_dtype_222 = None
        to_dtype_224 = torch.ops.aten.to.dtype(where_self_74, torch.float32);  where_self_74 = None
        native_batch_norm_backward_default_94 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_224, convolution_default_230, primals_1210, primals_1208, primals_1209, getitem_691, getitem_692, True, 1e-05, [True, True, True]);  convolution_default_230 = primals_1210 = primals_1208 = primals_1209 = getitem_691 = getitem_692 = None
        getitem_1539 = native_batch_norm_backward_default_94[0]
        getitem_1540 = native_batch_norm_backward_default_94[1]
        getitem_1541 = native_batch_norm_backward_default_94[2];  native_batch_norm_backward_default_94 = None
        convolution_backward_default_94 = torch.ops.aten.convolution_backward.default(getitem_1539, relu__default_182, primals_1212, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1539 = primals_1212 = None
        getitem_1542 = convolution_backward_default_94[0]
        getitem_1543 = convolution_backward_default_94[1]
        getitem_1544 = convolution_backward_default_94[2];  convolution_backward_default_94 = None
        to_dtype_225 = torch.ops.aten.to.dtype(getitem_1542, torch.float32);  getitem_1542 = None
        to_dtype_226 = torch.ops.aten.to.dtype(relu__default_182, torch.float32);  relu__default_182 = None
        le_scalar_75 = torch.ops.aten.le.Scalar(to_dtype_226, 0);  to_dtype_226 = None
        new_zeros_default_400 = torch.ops.aten.new_zeros.default(to_dtype_225, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_75 = torch.ops.aten.where.self(le_scalar_75, new_zeros_default_400, to_dtype_225);  le_scalar_75 = new_zeros_default_400 = to_dtype_225 = None
        to_dtype_227 = torch.ops.aten.to.dtype(where_self_75, torch.float32);  where_self_75 = None
        native_batch_norm_backward_default_95 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_227, convolution_default_229, primals_1205, primals_1203, primals_1204, getitem_688, getitem_689, True, 1e-05, [True, True, True]);  to_dtype_227 = convolution_default_229 = primals_1205 = primals_1203 = primals_1204 = getitem_688 = getitem_689 = None
        getitem_1545 = native_batch_norm_backward_default_95[0]
        getitem_1546 = native_batch_norm_backward_default_95[1]
        getitem_1547 = native_batch_norm_backward_default_95[2];  native_batch_norm_backward_default_95 = None
        convolution_backward_default_95 = torch.ops.aten.convolution_backward.default(getitem_1545, relu__default_181, primals_1211, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1545 = primals_1211 = None
        getitem_1548 = convolution_backward_default_95[0]
        getitem_1549 = convolution_backward_default_95[1]
        getitem_1550 = convolution_backward_default_95[2];  convolution_backward_default_95 = None
        add_tensor_114 = torch.ops.aten.add.Tensor(to_dtype_224, getitem_1548);  to_dtype_224 = getitem_1548 = None
        to_dtype_228 = torch.ops.aten.to.dtype(add_tensor_114, torch.float32);  add_tensor_114 = None
        to_dtype_229 = torch.ops.aten.to.dtype(relu__default_181, torch.float32);  relu__default_181 = None
        le_scalar_76 = torch.ops.aten.le.Scalar(to_dtype_229, 0);  to_dtype_229 = None
        new_zeros_default_401 = torch.ops.aten.new_zeros.default(to_dtype_228, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_76 = torch.ops.aten.where.self(le_scalar_76, new_zeros_default_401, to_dtype_228);  le_scalar_76 = new_zeros_default_401 = to_dtype_228 = None
        to_dtype_230 = torch.ops.aten.to.dtype(where_self_76, torch.float32);  where_self_76 = None
        native_batch_norm_backward_default_96 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_230, convolution_default_228, primals_1198, primals_1196, primals_1197, getitem_685, getitem_686, True, 1e-05, [True, True, True]);  convolution_default_228 = primals_1198 = primals_1196 = primals_1197 = getitem_685 = getitem_686 = None
        getitem_1551 = native_batch_norm_backward_default_96[0]
        getitem_1552 = native_batch_norm_backward_default_96[1]
        getitem_1553 = native_batch_norm_backward_default_96[2];  native_batch_norm_backward_default_96 = None
        convolution_backward_default_96 = torch.ops.aten.convolution_backward.default(getitem_1551, relu__default_180, primals_1200, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1551 = primals_1200 = None
        getitem_1554 = convolution_backward_default_96[0]
        getitem_1555 = convolution_backward_default_96[1]
        getitem_1556 = convolution_backward_default_96[2];  convolution_backward_default_96 = None
        to_dtype_231 = torch.ops.aten.to.dtype(getitem_1554, torch.float32);  getitem_1554 = None
        to_dtype_232 = torch.ops.aten.to.dtype(relu__default_180, torch.float32);  relu__default_180 = None
        le_scalar_77 = torch.ops.aten.le.Scalar(to_dtype_232, 0);  to_dtype_232 = None
        new_zeros_default_402 = torch.ops.aten.new_zeros.default(to_dtype_231, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_77 = torch.ops.aten.where.self(le_scalar_77, new_zeros_default_402, to_dtype_231);  le_scalar_77 = new_zeros_default_402 = to_dtype_231 = None
        to_dtype_233 = torch.ops.aten.to.dtype(where_self_77, torch.float32);  where_self_77 = None
        native_batch_norm_backward_default_97 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_233, convolution_default_227, primals_1193, primals_1191, primals_1192, getitem_682, getitem_683, True, 1e-05, [True, True, True]);  to_dtype_233 = convolution_default_227 = primals_1193 = primals_1191 = primals_1192 = getitem_682 = getitem_683 = None
        getitem_1557 = native_batch_norm_backward_default_97[0]
        getitem_1558 = native_batch_norm_backward_default_97[1]
        getitem_1559 = native_batch_norm_backward_default_97[2];  native_batch_norm_backward_default_97 = None
        convolution_backward_default_97 = torch.ops.aten.convolution_backward.default(getitem_1557, relu__default_179, primals_1199, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1557 = primals_1199 = None
        getitem_1560 = convolution_backward_default_97[0]
        getitem_1561 = convolution_backward_default_97[1]
        getitem_1562 = convolution_backward_default_97[2];  convolution_backward_default_97 = None
        add_tensor_115 = torch.ops.aten.add.Tensor(to_dtype_230, getitem_1560);  to_dtype_230 = getitem_1560 = None
        to_dtype_234 = torch.ops.aten.to.dtype(add_tensor_115, torch.float32);  add_tensor_115 = None
        to_dtype_235 = torch.ops.aten.to.dtype(relu__default_179, torch.float32);  relu__default_179 = None
        le_scalar_78 = torch.ops.aten.le.Scalar(to_dtype_235, 0);  to_dtype_235 = None
        new_zeros_default_403 = torch.ops.aten.new_zeros.default(to_dtype_234, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_78 = torch.ops.aten.where.self(le_scalar_78, new_zeros_default_403, to_dtype_234);  le_scalar_78 = new_zeros_default_403 = to_dtype_234 = None
        to_dtype_236 = torch.ops.aten.to.dtype(where_self_78, torch.float32);  where_self_78 = None
        native_batch_norm_backward_default_98 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_236, convolution_default_226, primals_1186, primals_1184, primals_1185, getitem_679, getitem_680, True, 1e-05, [True, True, True]);  convolution_default_226 = primals_1186 = primals_1184 = primals_1185 = getitem_679 = getitem_680 = None
        getitem_1563 = native_batch_norm_backward_default_98[0]
        getitem_1564 = native_batch_norm_backward_default_98[1]
        getitem_1565 = native_batch_norm_backward_default_98[2];  native_batch_norm_backward_default_98 = None
        convolution_backward_default_98 = torch.ops.aten.convolution_backward.default(getitem_1563, relu__default_178, primals_1188, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1563 = primals_1188 = None
        getitem_1566 = convolution_backward_default_98[0]
        getitem_1567 = convolution_backward_default_98[1]
        getitem_1568 = convolution_backward_default_98[2];  convolution_backward_default_98 = None
        to_dtype_237 = torch.ops.aten.to.dtype(getitem_1566, torch.float32);  getitem_1566 = None
        to_dtype_238 = torch.ops.aten.to.dtype(relu__default_178, torch.float32);  relu__default_178 = None
        le_scalar_79 = torch.ops.aten.le.Scalar(to_dtype_238, 0);  to_dtype_238 = None
        new_zeros_default_404 = torch.ops.aten.new_zeros.default(to_dtype_237, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_79 = torch.ops.aten.where.self(le_scalar_79, new_zeros_default_404, to_dtype_237);  le_scalar_79 = new_zeros_default_404 = to_dtype_237 = None
        to_dtype_239 = torch.ops.aten.to.dtype(where_self_79, torch.float32);  where_self_79 = None
        native_batch_norm_backward_default_99 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_239, convolution_default_225, primals_1181, primals_1179, primals_1180, getitem_676, getitem_677, True, 1e-05, [True, True, True]);  to_dtype_239 = convolution_default_225 = primals_1181 = primals_1179 = primals_1180 = getitem_676 = getitem_677 = None
        getitem_1569 = native_batch_norm_backward_default_99[0]
        getitem_1570 = native_batch_norm_backward_default_99[1]
        getitem_1571 = native_batch_norm_backward_default_99[2];  native_batch_norm_backward_default_99 = None
        convolution_backward_default_99 = torch.ops.aten.convolution_backward.default(getitem_1569, relu_default_21, primals_1187, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1569 = primals_1187 = None
        getitem_1572 = convolution_backward_default_99[0]
        getitem_1573 = convolution_backward_default_99[1]
        getitem_1574 = convolution_backward_default_99[2];  convolution_backward_default_99 = None
        add_tensor_116 = torch.ops.aten.add.Tensor(to_dtype_236, getitem_1572);  to_dtype_236 = getitem_1572 = None
        to_dtype_240 = torch.ops.aten.to.dtype(add_tensor_108, torch.float32);  add_tensor_108 = None
        to_dtype_241 = torch.ops.aten.to.dtype(relu__default_177, torch.float32);  relu__default_177 = None
        le_scalar_80 = torch.ops.aten.le.Scalar(to_dtype_241, 0);  to_dtype_241 = None
        new_zeros_default_405 = torch.ops.aten.new_zeros.default(to_dtype_240, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_80 = torch.ops.aten.where.self(le_scalar_80, new_zeros_default_405, to_dtype_240);  le_scalar_80 = new_zeros_default_405 = to_dtype_240 = None
        to_dtype_242 = torch.ops.aten.to.dtype(where_self_80, torch.float32);  where_self_80 = None
        native_batch_norm_backward_default_100 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_242, convolution_default_224, primals_1174, primals_1172, primals_1173, getitem_673, getitem_674, True, 1e-05, [True, True, True]);  convolution_default_224 = primals_1174 = primals_1172 = primals_1173 = getitem_673 = getitem_674 = None
        getitem_1575 = native_batch_norm_backward_default_100[0]
        getitem_1576 = native_batch_norm_backward_default_100[1]
        getitem_1577 = native_batch_norm_backward_default_100[2];  native_batch_norm_backward_default_100 = None
        convolution_backward_default_100 = torch.ops.aten.convolution_backward.default(getitem_1575, relu__default_176, primals_1176, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1575 = primals_1176 = None
        getitem_1578 = convolution_backward_default_100[0]
        getitem_1579 = convolution_backward_default_100[1]
        getitem_1580 = convolution_backward_default_100[2];  convolution_backward_default_100 = None
        to_dtype_243 = torch.ops.aten.to.dtype(getitem_1578, torch.float32);  getitem_1578 = None
        to_dtype_244 = torch.ops.aten.to.dtype(relu__default_176, torch.float32);  relu__default_176 = None
        le_scalar_81 = torch.ops.aten.le.Scalar(to_dtype_244, 0);  to_dtype_244 = None
        new_zeros_default_406 = torch.ops.aten.new_zeros.default(to_dtype_243, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_81 = torch.ops.aten.where.self(le_scalar_81, new_zeros_default_406, to_dtype_243);  le_scalar_81 = new_zeros_default_406 = to_dtype_243 = None
        to_dtype_245 = torch.ops.aten.to.dtype(where_self_81, torch.float32);  where_self_81 = None
        native_batch_norm_backward_default_101 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_245, convolution_default_223, primals_1169, primals_1167, primals_1168, getitem_670, getitem_671, True, 1e-05, [True, True, True]);  to_dtype_245 = convolution_default_223 = primals_1169 = primals_1167 = primals_1168 = getitem_670 = getitem_671 = None
        getitem_1581 = native_batch_norm_backward_default_101[0]
        getitem_1582 = native_batch_norm_backward_default_101[1]
        getitem_1583 = native_batch_norm_backward_default_101[2];  native_batch_norm_backward_default_101 = None
        convolution_backward_default_101 = torch.ops.aten.convolution_backward.default(getitem_1581, relu__default_175, primals_1175, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1581 = primals_1175 = None
        getitem_1584 = convolution_backward_default_101[0]
        getitem_1585 = convolution_backward_default_101[1]
        getitem_1586 = convolution_backward_default_101[2];  convolution_backward_default_101 = None
        add_tensor_117 = torch.ops.aten.add.Tensor(to_dtype_242, getitem_1584);  to_dtype_242 = getitem_1584 = None
        to_dtype_246 = torch.ops.aten.to.dtype(add_tensor_117, torch.float32);  add_tensor_117 = None
        to_dtype_247 = torch.ops.aten.to.dtype(relu__default_175, torch.float32);  relu__default_175 = None
        le_scalar_82 = torch.ops.aten.le.Scalar(to_dtype_247, 0);  to_dtype_247 = None
        new_zeros_default_407 = torch.ops.aten.new_zeros.default(to_dtype_246, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_82 = torch.ops.aten.where.self(le_scalar_82, new_zeros_default_407, to_dtype_246);  le_scalar_82 = new_zeros_default_407 = to_dtype_246 = None
        to_dtype_248 = torch.ops.aten.to.dtype(where_self_82, torch.float32);  where_self_82 = None
        native_batch_norm_backward_default_102 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_248, convolution_default_222, primals_1162, primals_1160, primals_1161, getitem_667, getitem_668, True, 1e-05, [True, True, True]);  convolution_default_222 = primals_1162 = primals_1160 = primals_1161 = getitem_667 = getitem_668 = None
        getitem_1587 = native_batch_norm_backward_default_102[0]
        getitem_1588 = native_batch_norm_backward_default_102[1]
        getitem_1589 = native_batch_norm_backward_default_102[2];  native_batch_norm_backward_default_102 = None
        convolution_backward_default_102 = torch.ops.aten.convolution_backward.default(getitem_1587, relu__default_174, primals_1164, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1587 = primals_1164 = None
        getitem_1590 = convolution_backward_default_102[0]
        getitem_1591 = convolution_backward_default_102[1]
        getitem_1592 = convolution_backward_default_102[2];  convolution_backward_default_102 = None
        to_dtype_249 = torch.ops.aten.to.dtype(getitem_1590, torch.float32);  getitem_1590 = None
        to_dtype_250 = torch.ops.aten.to.dtype(relu__default_174, torch.float32);  relu__default_174 = None
        le_scalar_83 = torch.ops.aten.le.Scalar(to_dtype_250, 0);  to_dtype_250 = None
        new_zeros_default_408 = torch.ops.aten.new_zeros.default(to_dtype_249, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_83 = torch.ops.aten.where.self(le_scalar_83, new_zeros_default_408, to_dtype_249);  le_scalar_83 = new_zeros_default_408 = to_dtype_249 = None
        to_dtype_251 = torch.ops.aten.to.dtype(where_self_83, torch.float32);  where_self_83 = None
        native_batch_norm_backward_default_103 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_251, convolution_default_221, primals_1157, primals_1155, primals_1156, getitem_664, getitem_665, True, 1e-05, [True, True, True]);  to_dtype_251 = convolution_default_221 = primals_1157 = primals_1155 = primals_1156 = getitem_664 = getitem_665 = None
        getitem_1593 = native_batch_norm_backward_default_103[0]
        getitem_1594 = native_batch_norm_backward_default_103[1]
        getitem_1595 = native_batch_norm_backward_default_103[2];  native_batch_norm_backward_default_103 = None
        convolution_backward_default_103 = torch.ops.aten.convolution_backward.default(getitem_1593, relu__default_173, primals_1163, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1593 = primals_1163 = None
        getitem_1596 = convolution_backward_default_103[0]
        getitem_1597 = convolution_backward_default_103[1]
        getitem_1598 = convolution_backward_default_103[2];  convolution_backward_default_103 = None
        add_tensor_118 = torch.ops.aten.add.Tensor(to_dtype_248, getitem_1596);  to_dtype_248 = getitem_1596 = None
        to_dtype_252 = torch.ops.aten.to.dtype(add_tensor_118, torch.float32);  add_tensor_118 = None
        to_dtype_253 = torch.ops.aten.to.dtype(relu__default_173, torch.float32);  relu__default_173 = None
        le_scalar_84 = torch.ops.aten.le.Scalar(to_dtype_253, 0);  to_dtype_253 = None
        new_zeros_default_409 = torch.ops.aten.new_zeros.default(to_dtype_252, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_84 = torch.ops.aten.where.self(le_scalar_84, new_zeros_default_409, to_dtype_252);  le_scalar_84 = new_zeros_default_409 = to_dtype_252 = None
        to_dtype_254 = torch.ops.aten.to.dtype(where_self_84, torch.float32);  where_self_84 = None
        native_batch_norm_backward_default_104 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_254, convolution_default_220, primals_1150, primals_1148, primals_1149, getitem_661, getitem_662, True, 1e-05, [True, True, True]);  convolution_default_220 = primals_1150 = primals_1148 = primals_1149 = getitem_661 = getitem_662 = None
        getitem_1599 = native_batch_norm_backward_default_104[0]
        getitem_1600 = native_batch_norm_backward_default_104[1]
        getitem_1601 = native_batch_norm_backward_default_104[2];  native_batch_norm_backward_default_104 = None
        convolution_backward_default_104 = torch.ops.aten.convolution_backward.default(getitem_1599, relu__default_172, primals_1152, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1599 = primals_1152 = None
        getitem_1602 = convolution_backward_default_104[0]
        getitem_1603 = convolution_backward_default_104[1]
        getitem_1604 = convolution_backward_default_104[2];  convolution_backward_default_104 = None
        to_dtype_255 = torch.ops.aten.to.dtype(getitem_1602, torch.float32);  getitem_1602 = None
        to_dtype_256 = torch.ops.aten.to.dtype(relu__default_172, torch.float32);  relu__default_172 = None
        le_scalar_85 = torch.ops.aten.le.Scalar(to_dtype_256, 0);  to_dtype_256 = None
        new_zeros_default_410 = torch.ops.aten.new_zeros.default(to_dtype_255, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_85 = torch.ops.aten.where.self(le_scalar_85, new_zeros_default_410, to_dtype_255);  le_scalar_85 = new_zeros_default_410 = to_dtype_255 = None
        to_dtype_257 = torch.ops.aten.to.dtype(where_self_85, torch.float32);  where_self_85 = None
        native_batch_norm_backward_default_105 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_257, convolution_default_219, primals_1145, primals_1143, primals_1144, getitem_658, getitem_659, True, 1e-05, [True, True, True]);  to_dtype_257 = convolution_default_219 = primals_1145 = primals_1143 = primals_1144 = getitem_658 = getitem_659 = None
        getitem_1605 = native_batch_norm_backward_default_105[0]
        getitem_1606 = native_batch_norm_backward_default_105[1]
        getitem_1607 = native_batch_norm_backward_default_105[2];  native_batch_norm_backward_default_105 = None
        convolution_backward_default_105 = torch.ops.aten.convolution_backward.default(getitem_1605, relu__default_171, primals_1151, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1605 = primals_1151 = None
        getitem_1608 = convolution_backward_default_105[0]
        getitem_1609 = convolution_backward_default_105[1]
        getitem_1610 = convolution_backward_default_105[2];  convolution_backward_default_105 = None
        add_tensor_119 = torch.ops.aten.add.Tensor(to_dtype_254, getitem_1608);  to_dtype_254 = getitem_1608 = None
        to_dtype_258 = torch.ops.aten.to.dtype(add_tensor_119, torch.float32);  add_tensor_119 = None
        to_dtype_259 = torch.ops.aten.to.dtype(relu__default_171, torch.float32);  relu__default_171 = None
        le_scalar_86 = torch.ops.aten.le.Scalar(to_dtype_259, 0);  to_dtype_259 = None
        new_zeros_default_411 = torch.ops.aten.new_zeros.default(to_dtype_258, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_86 = torch.ops.aten.where.self(le_scalar_86, new_zeros_default_411, to_dtype_258);  le_scalar_86 = new_zeros_default_411 = to_dtype_258 = None
        to_dtype_260 = torch.ops.aten.to.dtype(where_self_86, torch.float32);  where_self_86 = None
        native_batch_norm_backward_default_106 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_260, convolution_default_218, primals_1138, primals_1136, primals_1137, getitem_655, getitem_656, True, 1e-05, [True, True, True]);  convolution_default_218 = primals_1138 = primals_1136 = primals_1137 = getitem_655 = getitem_656 = None
        getitem_1611 = native_batch_norm_backward_default_106[0]
        getitem_1612 = native_batch_norm_backward_default_106[1]
        getitem_1613 = native_batch_norm_backward_default_106[2];  native_batch_norm_backward_default_106 = None
        convolution_backward_default_106 = torch.ops.aten.convolution_backward.default(getitem_1611, relu__default_170, primals_1140, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1611 = primals_1140 = None
        getitem_1614 = convolution_backward_default_106[0]
        getitem_1615 = convolution_backward_default_106[1]
        getitem_1616 = convolution_backward_default_106[2];  convolution_backward_default_106 = None
        to_dtype_261 = torch.ops.aten.to.dtype(getitem_1614, torch.float32);  getitem_1614 = None
        to_dtype_262 = torch.ops.aten.to.dtype(relu__default_170, torch.float32);  relu__default_170 = None
        le_scalar_87 = torch.ops.aten.le.Scalar(to_dtype_262, 0);  to_dtype_262 = None
        new_zeros_default_412 = torch.ops.aten.new_zeros.default(to_dtype_261, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_87 = torch.ops.aten.where.self(le_scalar_87, new_zeros_default_412, to_dtype_261);  le_scalar_87 = new_zeros_default_412 = to_dtype_261 = None
        to_dtype_263 = torch.ops.aten.to.dtype(where_self_87, torch.float32);  where_self_87 = None
        native_batch_norm_backward_default_107 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_263, convolution_default_217, primals_1133, primals_1131, primals_1132, getitem_652, getitem_653, True, 1e-05, [True, True, True]);  to_dtype_263 = convolution_default_217 = primals_1133 = primals_1131 = primals_1132 = getitem_652 = getitem_653 = None
        getitem_1617 = native_batch_norm_backward_default_107[0]
        getitem_1618 = native_batch_norm_backward_default_107[1]
        getitem_1619 = native_batch_norm_backward_default_107[2];  native_batch_norm_backward_default_107 = None
        convolution_backward_default_107 = torch.ops.aten.convolution_backward.default(getitem_1617, relu_default_19, primals_1139, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1617 = primals_1139 = None
        getitem_1620 = convolution_backward_default_107[0]
        getitem_1621 = convolution_backward_default_107[1]
        getitem_1622 = convolution_backward_default_107[2];  convolution_backward_default_107 = None
        add_tensor_120 = torch.ops.aten.add.Tensor(to_dtype_260, getitem_1620);  to_dtype_260 = getitem_1620 = None
        to_dtype_264 = torch.ops.aten.to.dtype(add_tensor_107, torch.float32);  add_tensor_107 = None
        to_dtype_265 = torch.ops.aten.to.dtype(relu__default_169, torch.float32);  relu__default_169 = None
        le_scalar_88 = torch.ops.aten.le.Scalar(to_dtype_265, 0);  to_dtype_265 = None
        new_zeros_default_413 = torch.ops.aten.new_zeros.default(to_dtype_264, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_88 = torch.ops.aten.where.self(le_scalar_88, new_zeros_default_413, to_dtype_264);  le_scalar_88 = new_zeros_default_413 = to_dtype_264 = None
        to_dtype_266 = torch.ops.aten.to.dtype(where_self_88, torch.float32);  where_self_88 = None
        native_batch_norm_backward_default_108 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_266, convolution_default_216, primals_1126, primals_1124, primals_1125, getitem_649, getitem_650, True, 1e-05, [True, True, True]);  convolution_default_216 = primals_1126 = primals_1124 = primals_1125 = getitem_649 = getitem_650 = None
        getitem_1623 = native_batch_norm_backward_default_108[0]
        getitem_1624 = native_batch_norm_backward_default_108[1]
        getitem_1625 = native_batch_norm_backward_default_108[2];  native_batch_norm_backward_default_108 = None
        convolution_backward_default_108 = torch.ops.aten.convolution_backward.default(getitem_1623, relu__default_168, primals_1128, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1623 = primals_1128 = None
        getitem_1626 = convolution_backward_default_108[0]
        getitem_1627 = convolution_backward_default_108[1]
        getitem_1628 = convolution_backward_default_108[2];  convolution_backward_default_108 = None
        to_dtype_267 = torch.ops.aten.to.dtype(getitem_1626, torch.float32);  getitem_1626 = None
        to_dtype_268 = torch.ops.aten.to.dtype(relu__default_168, torch.float32);  relu__default_168 = None
        le_scalar_89 = torch.ops.aten.le.Scalar(to_dtype_268, 0);  to_dtype_268 = None
        new_zeros_default_414 = torch.ops.aten.new_zeros.default(to_dtype_267, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_89 = torch.ops.aten.where.self(le_scalar_89, new_zeros_default_414, to_dtype_267);  le_scalar_89 = new_zeros_default_414 = to_dtype_267 = None
        to_dtype_269 = torch.ops.aten.to.dtype(where_self_89, torch.float32);  where_self_89 = None
        native_batch_norm_backward_default_109 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_269, convolution_default_215, primals_1121, primals_1119, primals_1120, getitem_646, getitem_647, True, 1e-05, [True, True, True]);  to_dtype_269 = convolution_default_215 = primals_1121 = primals_1119 = primals_1120 = getitem_646 = getitem_647 = None
        getitem_1629 = native_batch_norm_backward_default_109[0]
        getitem_1630 = native_batch_norm_backward_default_109[1]
        getitem_1631 = native_batch_norm_backward_default_109[2];  native_batch_norm_backward_default_109 = None
        convolution_backward_default_109 = torch.ops.aten.convolution_backward.default(getitem_1629, relu__default_167, primals_1127, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1629 = primals_1127 = None
        getitem_1632 = convolution_backward_default_109[0]
        getitem_1633 = convolution_backward_default_109[1]
        getitem_1634 = convolution_backward_default_109[2];  convolution_backward_default_109 = None
        add_tensor_121 = torch.ops.aten.add.Tensor(to_dtype_266, getitem_1632);  to_dtype_266 = getitem_1632 = None
        to_dtype_270 = torch.ops.aten.to.dtype(add_tensor_121, torch.float32);  add_tensor_121 = None
        to_dtype_271 = torch.ops.aten.to.dtype(relu__default_167, torch.float32);  relu__default_167 = None
        le_scalar_90 = torch.ops.aten.le.Scalar(to_dtype_271, 0);  to_dtype_271 = None
        new_zeros_default_415 = torch.ops.aten.new_zeros.default(to_dtype_270, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_90 = torch.ops.aten.where.self(le_scalar_90, new_zeros_default_415, to_dtype_270);  le_scalar_90 = new_zeros_default_415 = to_dtype_270 = None
        to_dtype_272 = torch.ops.aten.to.dtype(where_self_90, torch.float32);  where_self_90 = None
        native_batch_norm_backward_default_110 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_272, convolution_default_214, primals_1114, primals_1112, primals_1113, getitem_643, getitem_644, True, 1e-05, [True, True, True]);  convolution_default_214 = primals_1114 = primals_1112 = primals_1113 = getitem_643 = getitem_644 = None
        getitem_1635 = native_batch_norm_backward_default_110[0]
        getitem_1636 = native_batch_norm_backward_default_110[1]
        getitem_1637 = native_batch_norm_backward_default_110[2];  native_batch_norm_backward_default_110 = None
        convolution_backward_default_110 = torch.ops.aten.convolution_backward.default(getitem_1635, relu__default_166, primals_1116, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1635 = primals_1116 = None
        getitem_1638 = convolution_backward_default_110[0]
        getitem_1639 = convolution_backward_default_110[1]
        getitem_1640 = convolution_backward_default_110[2];  convolution_backward_default_110 = None
        to_dtype_273 = torch.ops.aten.to.dtype(getitem_1638, torch.float32);  getitem_1638 = None
        to_dtype_274 = torch.ops.aten.to.dtype(relu__default_166, torch.float32);  relu__default_166 = None
        le_scalar_91 = torch.ops.aten.le.Scalar(to_dtype_274, 0);  to_dtype_274 = None
        new_zeros_default_416 = torch.ops.aten.new_zeros.default(to_dtype_273, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_91 = torch.ops.aten.where.self(le_scalar_91, new_zeros_default_416, to_dtype_273);  le_scalar_91 = new_zeros_default_416 = to_dtype_273 = None
        to_dtype_275 = torch.ops.aten.to.dtype(where_self_91, torch.float32);  where_self_91 = None
        native_batch_norm_backward_default_111 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_275, convolution_default_213, primals_1109, primals_1107, primals_1108, getitem_640, getitem_641, True, 1e-05, [True, True, True]);  to_dtype_275 = convolution_default_213 = primals_1109 = primals_1107 = primals_1108 = getitem_640 = getitem_641 = None
        getitem_1641 = native_batch_norm_backward_default_111[0]
        getitem_1642 = native_batch_norm_backward_default_111[1]
        getitem_1643 = native_batch_norm_backward_default_111[2];  native_batch_norm_backward_default_111 = None
        convolution_backward_default_111 = torch.ops.aten.convolution_backward.default(getitem_1641, relu__default_165, primals_1115, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1641 = primals_1115 = None
        getitem_1644 = convolution_backward_default_111[0]
        getitem_1645 = convolution_backward_default_111[1]
        getitem_1646 = convolution_backward_default_111[2];  convolution_backward_default_111 = None
        add_tensor_122 = torch.ops.aten.add.Tensor(to_dtype_272, getitem_1644);  to_dtype_272 = getitem_1644 = None
        to_dtype_276 = torch.ops.aten.to.dtype(add_tensor_122, torch.float32);  add_tensor_122 = None
        to_dtype_277 = torch.ops.aten.to.dtype(relu__default_165, torch.float32);  relu__default_165 = None
        le_scalar_92 = torch.ops.aten.le.Scalar(to_dtype_277, 0);  to_dtype_277 = None
        new_zeros_default_417 = torch.ops.aten.new_zeros.default(to_dtype_276, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_92 = torch.ops.aten.where.self(le_scalar_92, new_zeros_default_417, to_dtype_276);  le_scalar_92 = new_zeros_default_417 = to_dtype_276 = None
        to_dtype_278 = torch.ops.aten.to.dtype(where_self_92, torch.float32);  where_self_92 = None
        native_batch_norm_backward_default_112 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_278, convolution_default_212, primals_1102, primals_1100, primals_1101, getitem_637, getitem_638, True, 1e-05, [True, True, True]);  convolution_default_212 = primals_1102 = primals_1100 = primals_1101 = getitem_637 = getitem_638 = None
        getitem_1647 = native_batch_norm_backward_default_112[0]
        getitem_1648 = native_batch_norm_backward_default_112[1]
        getitem_1649 = native_batch_norm_backward_default_112[2];  native_batch_norm_backward_default_112 = None
        convolution_backward_default_112 = torch.ops.aten.convolution_backward.default(getitem_1647, relu__default_164, primals_1104, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1647 = primals_1104 = None
        getitem_1650 = convolution_backward_default_112[0]
        getitem_1651 = convolution_backward_default_112[1]
        getitem_1652 = convolution_backward_default_112[2];  convolution_backward_default_112 = None
        to_dtype_279 = torch.ops.aten.to.dtype(getitem_1650, torch.float32);  getitem_1650 = None
        to_dtype_280 = torch.ops.aten.to.dtype(relu__default_164, torch.float32);  relu__default_164 = None
        le_scalar_93 = torch.ops.aten.le.Scalar(to_dtype_280, 0);  to_dtype_280 = None
        new_zeros_default_418 = torch.ops.aten.new_zeros.default(to_dtype_279, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_93 = torch.ops.aten.where.self(le_scalar_93, new_zeros_default_418, to_dtype_279);  le_scalar_93 = new_zeros_default_418 = to_dtype_279 = None
        to_dtype_281 = torch.ops.aten.to.dtype(where_self_93, torch.float32);  where_self_93 = None
        native_batch_norm_backward_default_113 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_281, convolution_default_211, primals_1097, primals_1095, primals_1096, getitem_634, getitem_635, True, 1e-05, [True, True, True]);  to_dtype_281 = convolution_default_211 = primals_1097 = primals_1095 = primals_1096 = getitem_634 = getitem_635 = None
        getitem_1653 = native_batch_norm_backward_default_113[0]
        getitem_1654 = native_batch_norm_backward_default_113[1]
        getitem_1655 = native_batch_norm_backward_default_113[2];  native_batch_norm_backward_default_113 = None
        convolution_backward_default_113 = torch.ops.aten.convolution_backward.default(getitem_1653, relu__default_163, primals_1103, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1653 = primals_1103 = None
        getitem_1656 = convolution_backward_default_113[0]
        getitem_1657 = convolution_backward_default_113[1]
        getitem_1658 = convolution_backward_default_113[2];  convolution_backward_default_113 = None
        add_tensor_123 = torch.ops.aten.add.Tensor(to_dtype_278, getitem_1656);  to_dtype_278 = getitem_1656 = None
        to_dtype_282 = torch.ops.aten.to.dtype(add_tensor_123, torch.float32);  add_tensor_123 = None
        to_dtype_283 = torch.ops.aten.to.dtype(relu__default_163, torch.float32);  relu__default_163 = None
        le_scalar_94 = torch.ops.aten.le.Scalar(to_dtype_283, 0);  to_dtype_283 = None
        new_zeros_default_419 = torch.ops.aten.new_zeros.default(to_dtype_282, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_94 = torch.ops.aten.where.self(le_scalar_94, new_zeros_default_419, to_dtype_282);  le_scalar_94 = new_zeros_default_419 = to_dtype_282 = None
        to_dtype_284 = torch.ops.aten.to.dtype(where_self_94, torch.float32);  where_self_94 = None
        native_batch_norm_backward_default_114 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_284, convolution_default_210, primals_1090, primals_1088, primals_1089, getitem_631, getitem_632, True, 1e-05, [True, True, True]);  convolution_default_210 = primals_1090 = primals_1088 = primals_1089 = getitem_631 = getitem_632 = None
        getitem_1659 = native_batch_norm_backward_default_114[0]
        getitem_1660 = native_batch_norm_backward_default_114[1]
        getitem_1661 = native_batch_norm_backward_default_114[2];  native_batch_norm_backward_default_114 = None
        convolution_backward_default_114 = torch.ops.aten.convolution_backward.default(getitem_1659, relu__default_162, primals_1092, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1659 = primals_1092 = None
        getitem_1662 = convolution_backward_default_114[0]
        getitem_1663 = convolution_backward_default_114[1]
        getitem_1664 = convolution_backward_default_114[2];  convolution_backward_default_114 = None
        to_dtype_285 = torch.ops.aten.to.dtype(getitem_1662, torch.float32);  getitem_1662 = None
        to_dtype_286 = torch.ops.aten.to.dtype(relu__default_162, torch.float32);  relu__default_162 = None
        le_scalar_95 = torch.ops.aten.le.Scalar(to_dtype_286, 0);  to_dtype_286 = None
        new_zeros_default_420 = torch.ops.aten.new_zeros.default(to_dtype_285, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_95 = torch.ops.aten.where.self(le_scalar_95, new_zeros_default_420, to_dtype_285);  le_scalar_95 = new_zeros_default_420 = to_dtype_285 = None
        to_dtype_287 = torch.ops.aten.to.dtype(where_self_95, torch.float32);  where_self_95 = None
        native_batch_norm_backward_default_115 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_287, convolution_default_209, primals_1085, primals_1083, primals_1084, getitem_628, getitem_629, True, 1e-05, [True, True, True]);  to_dtype_287 = convolution_default_209 = primals_1085 = primals_1083 = primals_1084 = getitem_628 = getitem_629 = None
        getitem_1665 = native_batch_norm_backward_default_115[0]
        getitem_1666 = native_batch_norm_backward_default_115[1]
        getitem_1667 = native_batch_norm_backward_default_115[2];  native_batch_norm_backward_default_115 = None
        convolution_backward_default_115 = torch.ops.aten.convolution_backward.default(getitem_1665, relu_default_18, primals_1091, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1665 = primals_1091 = None
        getitem_1668 = convolution_backward_default_115[0]
        getitem_1669 = convolution_backward_default_115[1]
        getitem_1670 = convolution_backward_default_115[2];  convolution_backward_default_115 = None
        add_tensor_124 = torch.ops.aten.add.Tensor(to_dtype_284, getitem_1668);  to_dtype_284 = getitem_1668 = None
        to_dtype_288 = torch.ops.aten.to.dtype(add_tensor_112, torch.float32);  add_tensor_112 = None
        to_dtype_289 = torch.ops.aten.to.dtype(relu_default_25, torch.float32);  relu_default_25 = None
        le_scalar_96 = torch.ops.aten.le.Scalar(to_dtype_289, 0);  to_dtype_289 = None
        new_zeros_default_421 = torch.ops.aten.new_zeros.default(to_dtype_288, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_96 = torch.ops.aten.where.self(le_scalar_96, new_zeros_default_421, to_dtype_288);  le_scalar_96 = new_zeros_default_421 = to_dtype_288 = None
        to_dtype_290 = torch.ops.aten.to.dtype(where_self_96, torch.float32);  where_self_96 = None
        native_batch_norm_backward_default_116 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_290, convolution_default_208, primals_1824, primals_1822, primals_1823, getitem_625, getitem_626, True, 1e-05, [True, True, True]);  convolution_default_208 = primals_1824 = primals_1822 = primals_1823 = getitem_625 = getitem_626 = None
        getitem_1671 = native_batch_norm_backward_default_116[0]
        getitem_1672 = native_batch_norm_backward_default_116[1]
        getitem_1673 = native_batch_norm_backward_default_116[2];  native_batch_norm_backward_default_116 = None
        convolution_backward_default_116 = torch.ops.aten.convolution_backward.default(getitem_1671, relu__default_153, primals_1819, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1671 = primals_1819 = None
        getitem_1674 = convolution_backward_default_116[0]
        getitem_1675 = convolution_backward_default_116[1]
        getitem_1676 = convolution_backward_default_116[2];  convolution_backward_default_116 = None
        native_batch_norm_backward_default_117 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_290, convolution_default_207, primals_1710, primals_1708, primals_1709, getitem_622, getitem_623, True, 1e-05, [True, True, True]);  convolution_default_207 = primals_1710 = primals_1708 = primals_1709 = getitem_622 = getitem_623 = None
        getitem_1677 = native_batch_norm_backward_default_117[0]
        getitem_1678 = native_batch_norm_backward_default_117[1]
        getitem_1679 = native_batch_norm_backward_default_117[2];  native_batch_norm_backward_default_117 = None
        convolution_backward_default_117 = torch.ops.aten.convolution_backward.default(getitem_1677, relu_default_24, primals_1705, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1677 = primals_1705 = None
        getitem_1680 = convolution_backward_default_117[0]
        getitem_1681 = convolution_backward_default_117[1]
        getitem_1682 = convolution_backward_default_117[2];  convolution_backward_default_117 = None
        to_dtype_291 = torch.ops.aten.to.dtype(getitem_1680, torch.float32);  getitem_1680 = None
        to_dtype_292 = torch.ops.aten.to.dtype(relu_default_24, torch.float32);  relu_default_24 = None
        le_scalar_97 = torch.ops.aten.le.Scalar(to_dtype_292, 0);  to_dtype_292 = None
        new_zeros_default_422 = torch.ops.aten.new_zeros.default(to_dtype_291, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_97 = torch.ops.aten.where.self(le_scalar_97, new_zeros_default_422, to_dtype_291);  le_scalar_97 = new_zeros_default_422 = to_dtype_291 = None
        to_dtype_293 = torch.ops.aten.to.dtype(where_self_97, torch.float32);  where_self_97 = None
        native_batch_norm_backward_default_118 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_293, convolution_default_206, primals_1704, primals_1702, primals_1703, getitem_619, getitem_620, True, 1e-05, [True, True, True]);  to_dtype_293 = convolution_default_206 = primals_1704 = primals_1702 = primals_1703 = getitem_619 = getitem_620 = None
        getitem_1683 = native_batch_norm_backward_default_118[0]
        getitem_1684 = native_batch_norm_backward_default_118[1]
        getitem_1685 = native_batch_norm_backward_default_118[2];  native_batch_norm_backward_default_118 = None
        convolution_backward_default_118 = torch.ops.aten.convolution_backward.default(getitem_1683, relu__default_145, primals_1699, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1683 = primals_1699 = None
        getitem_1686 = convolution_backward_default_118[0]
        getitem_1687 = convolution_backward_default_118[1]
        getitem_1688 = convolution_backward_default_118[2];  convolution_backward_default_118 = None
        native_batch_norm_backward_default_119 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_290, convolution_default_205, primals_1524, primals_1522, primals_1523, getitem_616, getitem_617, True, 1e-05, [True, True, True]);  convolution_default_205 = primals_1524 = primals_1522 = primals_1523 = getitem_616 = getitem_617 = None
        getitem_1689 = native_batch_norm_backward_default_119[0]
        getitem_1690 = native_batch_norm_backward_default_119[1]
        getitem_1691 = native_batch_norm_backward_default_119[2];  native_batch_norm_backward_default_119 = None
        convolution_backward_default_119 = torch.ops.aten.convolution_backward.default(getitem_1689, relu_default_23, primals_1519, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1689 = primals_1519 = None
        getitem_1692 = convolution_backward_default_119[0]
        getitem_1693 = convolution_backward_default_119[1]
        getitem_1694 = convolution_backward_default_119[2];  convolution_backward_default_119 = None
        to_dtype_294 = torch.ops.aten.to.dtype(getitem_1692, torch.float32);  getitem_1692 = None
        to_dtype_295 = torch.ops.aten.to.dtype(relu_default_23, torch.float32);  relu_default_23 = None
        le_scalar_98 = torch.ops.aten.le.Scalar(to_dtype_295, 0);  to_dtype_295 = None
        new_zeros_default_423 = torch.ops.aten.new_zeros.default(to_dtype_294, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_98 = torch.ops.aten.where.self(le_scalar_98, new_zeros_default_423, to_dtype_294);  le_scalar_98 = new_zeros_default_423 = to_dtype_294 = None
        to_dtype_296 = torch.ops.aten.to.dtype(where_self_98, torch.float32);  where_self_98 = None
        native_batch_norm_backward_default_120 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_296, convolution_default_204, primals_1518, primals_1516, primals_1517, getitem_613, getitem_614, True, 1e-05, [True, True, True]);  to_dtype_296 = convolution_default_204 = primals_1518 = primals_1516 = primals_1517 = getitem_613 = getitem_614 = None
        getitem_1695 = native_batch_norm_backward_default_120[0]
        getitem_1696 = native_batch_norm_backward_default_120[1]
        getitem_1697 = native_batch_norm_backward_default_120[2];  native_batch_norm_backward_default_120 = None
        convolution_backward_default_120 = torch.ops.aten.convolution_backward.default(getitem_1695, relu_default_22, primals_1513, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1695 = primals_1513 = None
        getitem_1698 = convolution_backward_default_120[0]
        getitem_1699 = convolution_backward_default_120[1]
        getitem_1700 = convolution_backward_default_120[2];  convolution_backward_default_120 = None
        to_dtype_297 = torch.ops.aten.to.dtype(getitem_1698, torch.float32);  getitem_1698 = None
        to_dtype_298 = torch.ops.aten.to.dtype(relu_default_22, torch.float32);  relu_default_22 = None
        le_scalar_99 = torch.ops.aten.le.Scalar(to_dtype_298, 0);  to_dtype_298 = None
        new_zeros_default_424 = torch.ops.aten.new_zeros.default(to_dtype_297, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_99 = torch.ops.aten.where.self(le_scalar_99, new_zeros_default_424, to_dtype_297);  le_scalar_99 = new_zeros_default_424 = to_dtype_297 = None
        to_dtype_299 = torch.ops.aten.to.dtype(where_self_99, torch.float32);  where_self_99 = None
        native_batch_norm_backward_default_121 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_299, convolution_default_203, primals_1512, primals_1510, primals_1511, getitem_610, getitem_611, True, 1e-05, [True, True, True]);  to_dtype_299 = convolution_default_203 = primals_1512 = primals_1510 = primals_1511 = getitem_610 = getitem_611 = None
        getitem_1701 = native_batch_norm_backward_default_121[0]
        getitem_1702 = native_batch_norm_backward_default_121[1]
        getitem_1703 = native_batch_norm_backward_default_121[2];  native_batch_norm_backward_default_121 = None
        convolution_backward_default_121 = torch.ops.aten.convolution_backward.default(getitem_1701, relu__default_137, primals_1507, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1701 = primals_1507 = None
        getitem_1704 = convolution_backward_default_121[0]
        getitem_1705 = convolution_backward_default_121[1]
        getitem_1706 = convolution_backward_default_121[2];  convolution_backward_default_121 = None
        to_dtype_300 = torch.ops.aten.to.dtype(add_tensor_116, torch.float32);  add_tensor_116 = None
        to_dtype_301 = torch.ops.aten.to.dtype(relu_default_21, torch.float32);  relu_default_21 = None
        le_scalar_100 = torch.ops.aten.le.Scalar(to_dtype_301, 0);  to_dtype_301 = None
        new_zeros_default_425 = torch.ops.aten.new_zeros.default(to_dtype_300, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_100 = torch.ops.aten.where.self(le_scalar_100, new_zeros_default_425, to_dtype_300);  le_scalar_100 = new_zeros_default_425 = to_dtype_300 = None
        to_dtype_302 = torch.ops.aten.to.dtype(where_self_100, torch.float32);  where_self_100 = None
        upsample_nearest2d_backward_vec_12 = torch.ops.aten.upsample_nearest2d_backward.vec(to_dtype_302, None, [128, 72, 7, 7], [2.0, 2.0])
        native_batch_norm_backward_default_122 = torch.ops.aten.native_batch_norm_backward.default(upsample_nearest2d_backward_vec_12, convolution_default_202, primals_1926, primals_1924, primals_1925, getitem_607, getitem_608, True, 1e-05, [True, True, True]);  upsample_nearest2d_backward_vec_12 = convolution_default_202 = primals_1926 = primals_1924 = primals_1925 = getitem_607 = getitem_608 = None
        getitem_1707 = native_batch_norm_backward_default_122[0]
        getitem_1708 = native_batch_norm_backward_default_122[1]
        getitem_1709 = native_batch_norm_backward_default_122[2];  native_batch_norm_backward_default_122 = None
        convolution_backward_default_122 = torch.ops.aten.convolution_backward.default(getitem_1707, relu__default_161, primals_1921, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1707 = primals_1921 = None
        getitem_1710 = convolution_backward_default_122[0]
        getitem_1711 = convolution_backward_default_122[1]
        getitem_1712 = convolution_backward_default_122[2];  convolution_backward_default_122 = None
        add_tensor_125 = torch.ops.aten.add.Tensor(to_dtype_290, getitem_1710);  to_dtype_290 = getitem_1710 = None
        add_tensor_126 = torch.ops.aten.add.Tensor(getitem_1674, to_dtype_302);  getitem_1674 = None
        native_batch_norm_backward_default_123 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_302, convolution_default_201, primals_1698, primals_1696, primals_1697, getitem_604, getitem_605, True, 1e-05, [True, True, True]);  convolution_default_201 = primals_1698 = primals_1696 = primals_1697 = getitem_604 = getitem_605 = None
        getitem_1713 = native_batch_norm_backward_default_123[0]
        getitem_1714 = native_batch_norm_backward_default_123[1]
        getitem_1715 = native_batch_norm_backward_default_123[2];  native_batch_norm_backward_default_123 = None
        convolution_backward_default_123 = torch.ops.aten.convolution_backward.default(getitem_1713, relu__default_145, primals_1693, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1713 = primals_1693 = None
        getitem_1716 = convolution_backward_default_123[0]
        getitem_1717 = convolution_backward_default_123[1]
        getitem_1718 = convolution_backward_default_123[2];  convolution_backward_default_123 = None
        add_tensor_127 = torch.ops.aten.add.Tensor(getitem_1686, getitem_1716);  getitem_1686 = getitem_1716 = None
        native_batch_norm_backward_default_124 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_302, convolution_default_200, primals_1506, primals_1504, primals_1505, getitem_601, getitem_602, True, 1e-05, [True, True, True]);  to_dtype_302 = convolution_default_200 = primals_1506 = primals_1504 = primals_1505 = getitem_601 = getitem_602 = None
        getitem_1719 = native_batch_norm_backward_default_124[0]
        getitem_1720 = native_batch_norm_backward_default_124[1]
        getitem_1721 = native_batch_norm_backward_default_124[2];  native_batch_norm_backward_default_124 = None
        convolution_backward_default_124 = torch.ops.aten.convolution_backward.default(getitem_1719, relu_default_20, primals_1501, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1719 = primals_1501 = None
        getitem_1722 = convolution_backward_default_124[0]
        getitem_1723 = convolution_backward_default_124[1]
        getitem_1724 = convolution_backward_default_124[2];  convolution_backward_default_124 = None
        to_dtype_303 = torch.ops.aten.to.dtype(getitem_1722, torch.float32);  getitem_1722 = None
        to_dtype_304 = torch.ops.aten.to.dtype(relu_default_20, torch.float32);  relu_default_20 = None
        le_scalar_101 = torch.ops.aten.le.Scalar(to_dtype_304, 0);  to_dtype_304 = None
        new_zeros_default_426 = torch.ops.aten.new_zeros.default(to_dtype_303, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_101 = torch.ops.aten.where.self(le_scalar_101, new_zeros_default_426, to_dtype_303);  le_scalar_101 = new_zeros_default_426 = to_dtype_303 = None
        to_dtype_305 = torch.ops.aten.to.dtype(where_self_101, torch.float32);  where_self_101 = None
        native_batch_norm_backward_default_125 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_305, convolution_default_199, primals_1500, primals_1498, primals_1499, getitem_598, getitem_599, True, 1e-05, [True, True, True]);  to_dtype_305 = convolution_default_199 = primals_1500 = primals_1498 = primals_1499 = getitem_598 = getitem_599 = None
        getitem_1725 = native_batch_norm_backward_default_125[0]
        getitem_1726 = native_batch_norm_backward_default_125[1]
        getitem_1727 = native_batch_norm_backward_default_125[2];  native_batch_norm_backward_default_125 = None
        convolution_backward_default_125 = torch.ops.aten.convolution_backward.default(getitem_1725, relu__default_137, primals_1495, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1725 = primals_1495 = None
        getitem_1728 = convolution_backward_default_125[0]
        getitem_1729 = convolution_backward_default_125[1]
        getitem_1730 = convolution_backward_default_125[2];  convolution_backward_default_125 = None
        add_tensor_128 = torch.ops.aten.add.Tensor(getitem_1704, getitem_1728);  getitem_1704 = getitem_1728 = None
        to_dtype_306 = torch.ops.aten.to.dtype(add_tensor_120, torch.float32);  add_tensor_120 = None
        to_dtype_307 = torch.ops.aten.to.dtype(relu_default_19, torch.float32);  relu_default_19 = None
        le_scalar_102 = torch.ops.aten.le.Scalar(to_dtype_307, 0);  to_dtype_307 = None
        new_zeros_default_427 = torch.ops.aten.new_zeros.default(to_dtype_306, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_102 = torch.ops.aten.where.self(le_scalar_102, new_zeros_default_427, to_dtype_306);  le_scalar_102 = new_zeros_default_427 = to_dtype_306 = None
        to_dtype_308 = torch.ops.aten.to.dtype(where_self_102, torch.float32);  where_self_102 = None
        upsample_nearest2d_backward_vec_13 = torch.ops.aten.upsample_nearest2d_backward.vec(to_dtype_308, None, [128, 36, 7, 7], [4.0, 4.0])
        native_batch_norm_backward_default_126 = torch.ops.aten.native_batch_norm_backward.default(upsample_nearest2d_backward_vec_13, convolution_default_198, primals_1920, primals_1918, primals_1919, getitem_595, getitem_596, True, 1e-05, [True, True, True]);  upsample_nearest2d_backward_vec_13 = convolution_default_198 = primals_1920 = primals_1918 = primals_1919 = getitem_595 = getitem_596 = None
        getitem_1731 = native_batch_norm_backward_default_126[0]
        getitem_1732 = native_batch_norm_backward_default_126[1]
        getitem_1733 = native_batch_norm_backward_default_126[2];  native_batch_norm_backward_default_126 = None
        convolution_backward_default_126 = torch.ops.aten.convolution_backward.default(getitem_1731, relu__default_161, primals_1915, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1731 = primals_1915 = None
        getitem_1734 = convolution_backward_default_126[0]
        getitem_1735 = convolution_backward_default_126[1]
        getitem_1736 = convolution_backward_default_126[2];  convolution_backward_default_126 = None
        add_tensor_129 = torch.ops.aten.add.Tensor(add_tensor_125, getitem_1734);  add_tensor_125 = getitem_1734 = None
        upsample_nearest2d_backward_vec_14 = torch.ops.aten.upsample_nearest2d_backward.vec(to_dtype_308, None, [128, 36, 14, 14], [2.0, 2.0])
        native_batch_norm_backward_default_127 = torch.ops.aten.native_batch_norm_backward.default(upsample_nearest2d_backward_vec_14, convolution_default_197, primals_1818, primals_1816, primals_1817, getitem_592, getitem_593, True, 1e-05, [True, True, True]);  upsample_nearest2d_backward_vec_14 = convolution_default_197 = primals_1818 = primals_1816 = primals_1817 = getitem_592 = getitem_593 = None
        getitem_1737 = native_batch_norm_backward_default_127[0]
        getitem_1738 = native_batch_norm_backward_default_127[1]
        getitem_1739 = native_batch_norm_backward_default_127[2];  native_batch_norm_backward_default_127 = None
        convolution_backward_default_127 = torch.ops.aten.convolution_backward.default(getitem_1737, relu__default_153, primals_1813, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1737 = primals_1813 = None
        getitem_1740 = convolution_backward_default_127[0]
        getitem_1741 = convolution_backward_default_127[1]
        getitem_1742 = convolution_backward_default_127[2];  convolution_backward_default_127 = None
        add_tensor_130 = torch.ops.aten.add.Tensor(add_tensor_126, getitem_1740);  add_tensor_126 = getitem_1740 = None
        add_tensor_131 = torch.ops.aten.add.Tensor(add_tensor_127, to_dtype_308);  add_tensor_127 = None
        native_batch_norm_backward_default_128 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_308, convolution_default_196, primals_1674, primals_1672, primals_1673, getitem_589, getitem_590, True, 1e-05, [True, True, True]);  to_dtype_308 = convolution_default_196 = primals_1674 = primals_1672 = primals_1673 = getitem_589 = getitem_590 = None
        getitem_1743 = native_batch_norm_backward_default_128[0]
        getitem_1744 = native_batch_norm_backward_default_128[1]
        getitem_1745 = native_batch_norm_backward_default_128[2];  native_batch_norm_backward_default_128 = None
        convolution_backward_default_128 = torch.ops.aten.convolution_backward.default(getitem_1743, relu__default_137, primals_1669, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1743 = primals_1669 = None
        getitem_1746 = convolution_backward_default_128[0]
        getitem_1747 = convolution_backward_default_128[1]
        getitem_1748 = convolution_backward_default_128[2];  convolution_backward_default_128 = None
        add_tensor_132 = torch.ops.aten.add.Tensor(add_tensor_128, getitem_1746);  add_tensor_128 = getitem_1746 = None
        to_dtype_309 = torch.ops.aten.to.dtype(add_tensor_124, torch.float32);  add_tensor_124 = None
        to_dtype_310 = torch.ops.aten.to.dtype(relu_default_18, torch.float32);  relu_default_18 = None
        le_scalar_103 = torch.ops.aten.le.Scalar(to_dtype_310, 0);  to_dtype_310 = None
        new_zeros_default_428 = torch.ops.aten.new_zeros.default(to_dtype_309, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_103 = torch.ops.aten.where.self(le_scalar_103, new_zeros_default_428, to_dtype_309);  le_scalar_103 = new_zeros_default_428 = to_dtype_309 = None
        to_dtype_311 = torch.ops.aten.to.dtype(where_self_103, torch.float32);  where_self_103 = None
        upsample_nearest2d_backward_vec_15 = torch.ops.aten.upsample_nearest2d_backward.vec(to_dtype_311, None, [128, 18, 7, 7], [8.0, 8.0])
        native_batch_norm_backward_default_129 = torch.ops.aten.native_batch_norm_backward.default(upsample_nearest2d_backward_vec_15, convolution_default_195, primals_1908, primals_1906, primals_1907, getitem_586, getitem_587, True, 1e-05, [True, True, True]);  upsample_nearest2d_backward_vec_15 = convolution_default_195 = primals_1908 = primals_1906 = primals_1907 = getitem_586 = getitem_587 = None
        getitem_1749 = native_batch_norm_backward_default_129[0]
        getitem_1750 = native_batch_norm_backward_default_129[1]
        getitem_1751 = native_batch_norm_backward_default_129[2];  native_batch_norm_backward_default_129 = None
        convolution_backward_default_129 = torch.ops.aten.convolution_backward.default(getitem_1749, relu__default_161, primals_1903, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1749 = primals_1903 = None
        getitem_1752 = convolution_backward_default_129[0]
        getitem_1753 = convolution_backward_default_129[1]
        getitem_1754 = convolution_backward_default_129[2];  convolution_backward_default_129 = None
        add_tensor_133 = torch.ops.aten.add.Tensor(add_tensor_129, getitem_1752);  add_tensor_129 = getitem_1752 = None
        upsample_nearest2d_backward_vec_16 = torch.ops.aten.upsample_nearest2d_backward.vec(to_dtype_311, None, [128, 18, 14, 14], [4.0, 4.0])
        native_batch_norm_backward_default_130 = torch.ops.aten.native_batch_norm_backward.default(upsample_nearest2d_backward_vec_16, convolution_default_194, primals_1812, primals_1810, primals_1811, getitem_583, getitem_584, True, 1e-05, [True, True, True]);  upsample_nearest2d_backward_vec_16 = convolution_default_194 = primals_1812 = primals_1810 = primals_1811 = getitem_583 = getitem_584 = None
        getitem_1755 = native_batch_norm_backward_default_130[0]
        getitem_1756 = native_batch_norm_backward_default_130[1]
        getitem_1757 = native_batch_norm_backward_default_130[2];  native_batch_norm_backward_default_130 = None
        convolution_backward_default_130 = torch.ops.aten.convolution_backward.default(getitem_1755, relu__default_153, primals_1807, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1755 = primals_1807 = None
        getitem_1758 = convolution_backward_default_130[0]
        getitem_1759 = convolution_backward_default_130[1]
        getitem_1760 = convolution_backward_default_130[2];  convolution_backward_default_130 = None
        add_tensor_134 = torch.ops.aten.add.Tensor(add_tensor_130, getitem_1758);  add_tensor_130 = getitem_1758 = None
        add_tensor_135 = torch.ops.aten.add.Tensor(add_tensor_132, to_dtype_311);  add_tensor_132 = None
        upsample_nearest2d_backward_vec_17 = torch.ops.aten.upsample_nearest2d_backward.vec(to_dtype_311, None, [128, 18, 28, 28], [2.0, 2.0]);  to_dtype_311 = None
        native_batch_norm_backward_default_131 = torch.ops.aten.native_batch_norm_backward.default(upsample_nearest2d_backward_vec_17, convolution_default_193, primals_1692, primals_1690, primals_1691, getitem_580, getitem_581, True, 1e-05, [True, True, True]);  upsample_nearest2d_backward_vec_17 = convolution_default_193 = primals_1692 = primals_1690 = primals_1691 = getitem_580 = getitem_581 = None
        getitem_1761 = native_batch_norm_backward_default_131[0]
        getitem_1762 = native_batch_norm_backward_default_131[1]
        getitem_1763 = native_batch_norm_backward_default_131[2];  native_batch_norm_backward_default_131 = None
        convolution_backward_default_131 = torch.ops.aten.convolution_backward.default(getitem_1761, relu__default_145, primals_1687, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1761 = primals_1687 = None
        getitem_1764 = convolution_backward_default_131[0]
        getitem_1765 = convolution_backward_default_131[1]
        getitem_1766 = convolution_backward_default_131[2];  convolution_backward_default_131 = None
        add_tensor_136 = torch.ops.aten.add.Tensor(add_tensor_131, getitem_1764);  add_tensor_131 = getitem_1764 = None
        to_dtype_312 = torch.ops.aten.to.dtype(add_tensor_133, torch.float32);  add_tensor_133 = None
        to_dtype_313 = torch.ops.aten.to.dtype(relu__default_161, torch.float32);  relu__default_161 = None
        le_scalar_104 = torch.ops.aten.le.Scalar(to_dtype_313, 0);  to_dtype_313 = None
        new_zeros_default_429 = torch.ops.aten.new_zeros.default(to_dtype_312, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_104 = torch.ops.aten.where.self(le_scalar_104, new_zeros_default_429, to_dtype_312);  le_scalar_104 = new_zeros_default_429 = to_dtype_312 = None
        to_dtype_314 = torch.ops.aten.to.dtype(where_self_104, torch.float32);  where_self_104 = None
        native_batch_norm_backward_default_132 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_314, convolution_default_192, primals_1078, primals_1076, primals_1077, getitem_577, getitem_578, True, 1e-05, [True, True, True]);  convolution_default_192 = primals_1078 = primals_1076 = primals_1077 = getitem_577 = getitem_578 = None
        getitem_1767 = native_batch_norm_backward_default_132[0]
        getitem_1768 = native_batch_norm_backward_default_132[1]
        getitem_1769 = native_batch_norm_backward_default_132[2];  native_batch_norm_backward_default_132 = None
        convolution_backward_default_132 = torch.ops.aten.convolution_backward.default(getitem_1767, relu__default_160, primals_1080, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1767 = primals_1080 = None
        getitem_1770 = convolution_backward_default_132[0]
        getitem_1771 = convolution_backward_default_132[1]
        getitem_1772 = convolution_backward_default_132[2];  convolution_backward_default_132 = None
        to_dtype_315 = torch.ops.aten.to.dtype(getitem_1770, torch.float32);  getitem_1770 = None
        to_dtype_316 = torch.ops.aten.to.dtype(relu__default_160, torch.float32);  relu__default_160 = None
        le_scalar_105 = torch.ops.aten.le.Scalar(to_dtype_316, 0);  to_dtype_316 = None
        new_zeros_default_430 = torch.ops.aten.new_zeros.default(to_dtype_315, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_105 = torch.ops.aten.where.self(le_scalar_105, new_zeros_default_430, to_dtype_315);  le_scalar_105 = new_zeros_default_430 = to_dtype_315 = None
        to_dtype_317 = torch.ops.aten.to.dtype(where_self_105, torch.float32);  where_self_105 = None
        native_batch_norm_backward_default_133 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_317, convolution_default_191, primals_1073, primals_1071, primals_1072, getitem_574, getitem_575, True, 1e-05, [True, True, True]);  to_dtype_317 = convolution_default_191 = primals_1073 = primals_1071 = primals_1072 = getitem_574 = getitem_575 = None
        getitem_1773 = native_batch_norm_backward_default_133[0]
        getitem_1774 = native_batch_norm_backward_default_133[1]
        getitem_1775 = native_batch_norm_backward_default_133[2];  native_batch_norm_backward_default_133 = None
        convolution_backward_default_133 = torch.ops.aten.convolution_backward.default(getitem_1773, relu__default_159, primals_1079, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1773 = primals_1079 = None
        getitem_1776 = convolution_backward_default_133[0]
        getitem_1777 = convolution_backward_default_133[1]
        getitem_1778 = convolution_backward_default_133[2];  convolution_backward_default_133 = None
        add_tensor_137 = torch.ops.aten.add.Tensor(to_dtype_314, getitem_1776);  to_dtype_314 = getitem_1776 = None
        to_dtype_318 = torch.ops.aten.to.dtype(add_tensor_137, torch.float32);  add_tensor_137 = None
        to_dtype_319 = torch.ops.aten.to.dtype(relu__default_159, torch.float32);  relu__default_159 = None
        le_scalar_106 = torch.ops.aten.le.Scalar(to_dtype_319, 0);  to_dtype_319 = None
        new_zeros_default_431 = torch.ops.aten.new_zeros.default(to_dtype_318, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_106 = torch.ops.aten.where.self(le_scalar_106, new_zeros_default_431, to_dtype_318);  le_scalar_106 = new_zeros_default_431 = to_dtype_318 = None
        to_dtype_320 = torch.ops.aten.to.dtype(where_self_106, torch.float32);  where_self_106 = None
        native_batch_norm_backward_default_134 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_320, convolution_default_190, primals_1066, primals_1064, primals_1065, getitem_571, getitem_572, True, 1e-05, [True, True, True]);  convolution_default_190 = primals_1066 = primals_1064 = primals_1065 = getitem_571 = getitem_572 = None
        getitem_1779 = native_batch_norm_backward_default_134[0]
        getitem_1780 = native_batch_norm_backward_default_134[1]
        getitem_1781 = native_batch_norm_backward_default_134[2];  native_batch_norm_backward_default_134 = None
        convolution_backward_default_134 = torch.ops.aten.convolution_backward.default(getitem_1779, relu__default_158, primals_1068, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1779 = primals_1068 = None
        getitem_1782 = convolution_backward_default_134[0]
        getitem_1783 = convolution_backward_default_134[1]
        getitem_1784 = convolution_backward_default_134[2];  convolution_backward_default_134 = None
        to_dtype_321 = torch.ops.aten.to.dtype(getitem_1782, torch.float32);  getitem_1782 = None
        to_dtype_322 = torch.ops.aten.to.dtype(relu__default_158, torch.float32);  relu__default_158 = None
        le_scalar_107 = torch.ops.aten.le.Scalar(to_dtype_322, 0);  to_dtype_322 = None
        new_zeros_default_432 = torch.ops.aten.new_zeros.default(to_dtype_321, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_107 = torch.ops.aten.where.self(le_scalar_107, new_zeros_default_432, to_dtype_321);  le_scalar_107 = new_zeros_default_432 = to_dtype_321 = None
        to_dtype_323 = torch.ops.aten.to.dtype(where_self_107, torch.float32);  where_self_107 = None
        native_batch_norm_backward_default_135 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_323, convolution_default_189, primals_1061, primals_1059, primals_1060, getitem_568, getitem_569, True, 1e-05, [True, True, True]);  to_dtype_323 = convolution_default_189 = primals_1061 = primals_1059 = primals_1060 = getitem_568 = getitem_569 = None
        getitem_1785 = native_batch_norm_backward_default_135[0]
        getitem_1786 = native_batch_norm_backward_default_135[1]
        getitem_1787 = native_batch_norm_backward_default_135[2];  native_batch_norm_backward_default_135 = None
        convolution_backward_default_135 = torch.ops.aten.convolution_backward.default(getitem_1785, relu__default_157, primals_1067, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1785 = primals_1067 = None
        getitem_1788 = convolution_backward_default_135[0]
        getitem_1789 = convolution_backward_default_135[1]
        getitem_1790 = convolution_backward_default_135[2];  convolution_backward_default_135 = None
        add_tensor_138 = torch.ops.aten.add.Tensor(to_dtype_320, getitem_1788);  to_dtype_320 = getitem_1788 = None
        to_dtype_324 = torch.ops.aten.to.dtype(add_tensor_138, torch.float32);  add_tensor_138 = None
        to_dtype_325 = torch.ops.aten.to.dtype(relu__default_157, torch.float32);  relu__default_157 = None
        le_scalar_108 = torch.ops.aten.le.Scalar(to_dtype_325, 0);  to_dtype_325 = None
        new_zeros_default_433 = torch.ops.aten.new_zeros.default(to_dtype_324, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_108 = torch.ops.aten.where.self(le_scalar_108, new_zeros_default_433, to_dtype_324);  le_scalar_108 = new_zeros_default_433 = to_dtype_324 = None
        to_dtype_326 = torch.ops.aten.to.dtype(where_self_108, torch.float32);  where_self_108 = None
        native_batch_norm_backward_default_136 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_326, convolution_default_188, primals_1054, primals_1052, primals_1053, getitem_565, getitem_566, True, 1e-05, [True, True, True]);  convolution_default_188 = primals_1054 = primals_1052 = primals_1053 = getitem_565 = getitem_566 = None
        getitem_1791 = native_batch_norm_backward_default_136[0]
        getitem_1792 = native_batch_norm_backward_default_136[1]
        getitem_1793 = native_batch_norm_backward_default_136[2];  native_batch_norm_backward_default_136 = None
        convolution_backward_default_136 = torch.ops.aten.convolution_backward.default(getitem_1791, relu__default_156, primals_1056, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1791 = primals_1056 = None
        getitem_1794 = convolution_backward_default_136[0]
        getitem_1795 = convolution_backward_default_136[1]
        getitem_1796 = convolution_backward_default_136[2];  convolution_backward_default_136 = None
        to_dtype_327 = torch.ops.aten.to.dtype(getitem_1794, torch.float32);  getitem_1794 = None
        to_dtype_328 = torch.ops.aten.to.dtype(relu__default_156, torch.float32);  relu__default_156 = None
        le_scalar_109 = torch.ops.aten.le.Scalar(to_dtype_328, 0);  to_dtype_328 = None
        new_zeros_default_434 = torch.ops.aten.new_zeros.default(to_dtype_327, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_109 = torch.ops.aten.where.self(le_scalar_109, new_zeros_default_434, to_dtype_327);  le_scalar_109 = new_zeros_default_434 = to_dtype_327 = None
        to_dtype_329 = torch.ops.aten.to.dtype(where_self_109, torch.float32);  where_self_109 = None
        native_batch_norm_backward_default_137 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_329, convolution_default_187, primals_1049, primals_1047, primals_1048, getitem_562, getitem_563, True, 1e-05, [True, True, True]);  to_dtype_329 = convolution_default_187 = primals_1049 = primals_1047 = primals_1048 = getitem_562 = getitem_563 = None
        getitem_1797 = native_batch_norm_backward_default_137[0]
        getitem_1798 = native_batch_norm_backward_default_137[1]
        getitem_1799 = native_batch_norm_backward_default_137[2];  native_batch_norm_backward_default_137 = None
        convolution_backward_default_137 = torch.ops.aten.convolution_backward.default(getitem_1797, relu__default_155, primals_1055, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1797 = primals_1055 = None
        getitem_1800 = convolution_backward_default_137[0]
        getitem_1801 = convolution_backward_default_137[1]
        getitem_1802 = convolution_backward_default_137[2];  convolution_backward_default_137 = None
        add_tensor_139 = torch.ops.aten.add.Tensor(to_dtype_326, getitem_1800);  to_dtype_326 = getitem_1800 = None
        to_dtype_330 = torch.ops.aten.to.dtype(add_tensor_139, torch.float32);  add_tensor_139 = None
        to_dtype_331 = torch.ops.aten.to.dtype(relu__default_155, torch.float32);  relu__default_155 = None
        le_scalar_110 = torch.ops.aten.le.Scalar(to_dtype_331, 0);  to_dtype_331 = None
        new_zeros_default_435 = torch.ops.aten.new_zeros.default(to_dtype_330, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_110 = torch.ops.aten.where.self(le_scalar_110, new_zeros_default_435, to_dtype_330);  le_scalar_110 = new_zeros_default_435 = to_dtype_330 = None
        to_dtype_332 = torch.ops.aten.to.dtype(where_self_110, torch.float32);  where_self_110 = None
        native_batch_norm_backward_default_138 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_332, convolution_default_186, primals_1042, primals_1040, primals_1041, getitem_559, getitem_560, True, 1e-05, [True, True, True]);  convolution_default_186 = primals_1042 = primals_1040 = primals_1041 = getitem_559 = getitem_560 = None
        getitem_1803 = native_batch_norm_backward_default_138[0]
        getitem_1804 = native_batch_norm_backward_default_138[1]
        getitem_1805 = native_batch_norm_backward_default_138[2];  native_batch_norm_backward_default_138 = None
        convolution_backward_default_138 = torch.ops.aten.convolution_backward.default(getitem_1803, relu__default_154, primals_1044, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1803 = primals_1044 = None
        getitem_1806 = convolution_backward_default_138[0]
        getitem_1807 = convolution_backward_default_138[1]
        getitem_1808 = convolution_backward_default_138[2];  convolution_backward_default_138 = None
        to_dtype_333 = torch.ops.aten.to.dtype(getitem_1806, torch.float32);  getitem_1806 = None
        to_dtype_334 = torch.ops.aten.to.dtype(relu__default_154, torch.float32);  relu__default_154 = None
        le_scalar_111 = torch.ops.aten.le.Scalar(to_dtype_334, 0);  to_dtype_334 = None
        new_zeros_default_436 = torch.ops.aten.new_zeros.default(to_dtype_333, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_111 = torch.ops.aten.where.self(le_scalar_111, new_zeros_default_436, to_dtype_333);  le_scalar_111 = new_zeros_default_436 = to_dtype_333 = None
        to_dtype_335 = torch.ops.aten.to.dtype(where_self_111, torch.float32);  where_self_111 = None
        native_batch_norm_backward_default_139 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_335, convolution_default_185, primals_1037, primals_1035, primals_1036, getitem_556, getitem_557, True, 1e-05, [True, True, True]);  to_dtype_335 = convolution_default_185 = primals_1037 = primals_1035 = primals_1036 = getitem_556 = getitem_557 = None
        getitem_1809 = native_batch_norm_backward_default_139[0]
        getitem_1810 = native_batch_norm_backward_default_139[1]
        getitem_1811 = native_batch_norm_backward_default_139[2];  native_batch_norm_backward_default_139 = None
        convolution_backward_default_139 = torch.ops.aten.convolution_backward.default(getitem_1809, relu__default_129, primals_1043, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1809 = primals_1043 = None
        getitem_1812 = convolution_backward_default_139[0]
        getitem_1813 = convolution_backward_default_139[1]
        getitem_1814 = convolution_backward_default_139[2];  convolution_backward_default_139 = None
        add_tensor_140 = torch.ops.aten.add.Tensor(to_dtype_332, getitem_1812);  to_dtype_332 = getitem_1812 = None
        to_dtype_336 = torch.ops.aten.to.dtype(add_tensor_134, torch.float32);  add_tensor_134 = None
        to_dtype_337 = torch.ops.aten.to.dtype(relu__default_153, torch.float32);  relu__default_153 = None
        le_scalar_112 = torch.ops.aten.le.Scalar(to_dtype_337, 0);  to_dtype_337 = None
        new_zeros_default_437 = torch.ops.aten.new_zeros.default(to_dtype_336, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_112 = torch.ops.aten.where.self(le_scalar_112, new_zeros_default_437, to_dtype_336);  le_scalar_112 = new_zeros_default_437 = to_dtype_336 = None
        to_dtype_338 = torch.ops.aten.to.dtype(where_self_112, torch.float32);  where_self_112 = None
        native_batch_norm_backward_default_140 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_338, convolution_default_184, primals_1030, primals_1028, primals_1029, getitem_553, getitem_554, True, 1e-05, [True, True, True]);  convolution_default_184 = primals_1030 = primals_1028 = primals_1029 = getitem_553 = getitem_554 = None
        getitem_1815 = native_batch_norm_backward_default_140[0]
        getitem_1816 = native_batch_norm_backward_default_140[1]
        getitem_1817 = native_batch_norm_backward_default_140[2];  native_batch_norm_backward_default_140 = None
        convolution_backward_default_140 = torch.ops.aten.convolution_backward.default(getitem_1815, relu__default_152, primals_1032, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1815 = primals_1032 = None
        getitem_1818 = convolution_backward_default_140[0]
        getitem_1819 = convolution_backward_default_140[1]
        getitem_1820 = convolution_backward_default_140[2];  convolution_backward_default_140 = None
        to_dtype_339 = torch.ops.aten.to.dtype(getitem_1818, torch.float32);  getitem_1818 = None
        to_dtype_340 = torch.ops.aten.to.dtype(relu__default_152, torch.float32);  relu__default_152 = None
        le_scalar_113 = torch.ops.aten.le.Scalar(to_dtype_340, 0);  to_dtype_340 = None
        new_zeros_default_438 = torch.ops.aten.new_zeros.default(to_dtype_339, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_113 = torch.ops.aten.where.self(le_scalar_113, new_zeros_default_438, to_dtype_339);  le_scalar_113 = new_zeros_default_438 = to_dtype_339 = None
        to_dtype_341 = torch.ops.aten.to.dtype(where_self_113, torch.float32);  where_self_113 = None
        native_batch_norm_backward_default_141 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_341, convolution_default_183, primals_1025, primals_1023, primals_1024, getitem_550, getitem_551, True, 1e-05, [True, True, True]);  to_dtype_341 = convolution_default_183 = primals_1025 = primals_1023 = primals_1024 = getitem_550 = getitem_551 = None
        getitem_1821 = native_batch_norm_backward_default_141[0]
        getitem_1822 = native_batch_norm_backward_default_141[1]
        getitem_1823 = native_batch_norm_backward_default_141[2];  native_batch_norm_backward_default_141 = None
        convolution_backward_default_141 = torch.ops.aten.convolution_backward.default(getitem_1821, relu__default_151, primals_1031, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1821 = primals_1031 = None
        getitem_1824 = convolution_backward_default_141[0]
        getitem_1825 = convolution_backward_default_141[1]
        getitem_1826 = convolution_backward_default_141[2];  convolution_backward_default_141 = None
        add_tensor_141 = torch.ops.aten.add.Tensor(to_dtype_338, getitem_1824);  to_dtype_338 = getitem_1824 = None
        to_dtype_342 = torch.ops.aten.to.dtype(add_tensor_141, torch.float32);  add_tensor_141 = None
        to_dtype_343 = torch.ops.aten.to.dtype(relu__default_151, torch.float32);  relu__default_151 = None
        le_scalar_114 = torch.ops.aten.le.Scalar(to_dtype_343, 0);  to_dtype_343 = None
        new_zeros_default_439 = torch.ops.aten.new_zeros.default(to_dtype_342, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_114 = torch.ops.aten.where.self(le_scalar_114, new_zeros_default_439, to_dtype_342);  le_scalar_114 = new_zeros_default_439 = to_dtype_342 = None
        to_dtype_344 = torch.ops.aten.to.dtype(where_self_114, torch.float32);  where_self_114 = None
        native_batch_norm_backward_default_142 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_344, convolution_default_182, primals_1018, primals_1016, primals_1017, getitem_547, getitem_548, True, 1e-05, [True, True, True]);  convolution_default_182 = primals_1018 = primals_1016 = primals_1017 = getitem_547 = getitem_548 = None
        getitem_1827 = native_batch_norm_backward_default_142[0]
        getitem_1828 = native_batch_norm_backward_default_142[1]
        getitem_1829 = native_batch_norm_backward_default_142[2];  native_batch_norm_backward_default_142 = None
        convolution_backward_default_142 = torch.ops.aten.convolution_backward.default(getitem_1827, relu__default_150, primals_1020, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1827 = primals_1020 = None
        getitem_1830 = convolution_backward_default_142[0]
        getitem_1831 = convolution_backward_default_142[1]
        getitem_1832 = convolution_backward_default_142[2];  convolution_backward_default_142 = None
        to_dtype_345 = torch.ops.aten.to.dtype(getitem_1830, torch.float32);  getitem_1830 = None
        to_dtype_346 = torch.ops.aten.to.dtype(relu__default_150, torch.float32);  relu__default_150 = None
        le_scalar_115 = torch.ops.aten.le.Scalar(to_dtype_346, 0);  to_dtype_346 = None
        new_zeros_default_440 = torch.ops.aten.new_zeros.default(to_dtype_345, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_115 = torch.ops.aten.where.self(le_scalar_115, new_zeros_default_440, to_dtype_345);  le_scalar_115 = new_zeros_default_440 = to_dtype_345 = None
        to_dtype_347 = torch.ops.aten.to.dtype(where_self_115, torch.float32);  where_self_115 = None
        native_batch_norm_backward_default_143 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_347, convolution_default_181, primals_1013, primals_1011, primals_1012, getitem_544, getitem_545, True, 1e-05, [True, True, True]);  to_dtype_347 = convolution_default_181 = primals_1013 = primals_1011 = primals_1012 = getitem_544 = getitem_545 = None
        getitem_1833 = native_batch_norm_backward_default_143[0]
        getitem_1834 = native_batch_norm_backward_default_143[1]
        getitem_1835 = native_batch_norm_backward_default_143[2];  native_batch_norm_backward_default_143 = None
        convolution_backward_default_143 = torch.ops.aten.convolution_backward.default(getitem_1833, relu__default_149, primals_1019, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1833 = primals_1019 = None
        getitem_1836 = convolution_backward_default_143[0]
        getitem_1837 = convolution_backward_default_143[1]
        getitem_1838 = convolution_backward_default_143[2];  convolution_backward_default_143 = None
        add_tensor_142 = torch.ops.aten.add.Tensor(to_dtype_344, getitem_1836);  to_dtype_344 = getitem_1836 = None
        to_dtype_348 = torch.ops.aten.to.dtype(add_tensor_142, torch.float32);  add_tensor_142 = None
        to_dtype_349 = torch.ops.aten.to.dtype(relu__default_149, torch.float32);  relu__default_149 = None
        le_scalar_116 = torch.ops.aten.le.Scalar(to_dtype_349, 0);  to_dtype_349 = None
        new_zeros_default_441 = torch.ops.aten.new_zeros.default(to_dtype_348, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_116 = torch.ops.aten.where.self(le_scalar_116, new_zeros_default_441, to_dtype_348);  le_scalar_116 = new_zeros_default_441 = to_dtype_348 = None
        to_dtype_350 = torch.ops.aten.to.dtype(where_self_116, torch.float32);  where_self_116 = None
        native_batch_norm_backward_default_144 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_350, convolution_default_180, primals_1006, primals_1004, primals_1005, getitem_541, getitem_542, True, 1e-05, [True, True, True]);  convolution_default_180 = primals_1006 = primals_1004 = primals_1005 = getitem_541 = getitem_542 = None
        getitem_1839 = native_batch_norm_backward_default_144[0]
        getitem_1840 = native_batch_norm_backward_default_144[1]
        getitem_1841 = native_batch_norm_backward_default_144[2];  native_batch_norm_backward_default_144 = None
        convolution_backward_default_144 = torch.ops.aten.convolution_backward.default(getitem_1839, relu__default_148, primals_1008, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1839 = primals_1008 = None
        getitem_1842 = convolution_backward_default_144[0]
        getitem_1843 = convolution_backward_default_144[1]
        getitem_1844 = convolution_backward_default_144[2];  convolution_backward_default_144 = None
        to_dtype_351 = torch.ops.aten.to.dtype(getitem_1842, torch.float32);  getitem_1842 = None
        to_dtype_352 = torch.ops.aten.to.dtype(relu__default_148, torch.float32);  relu__default_148 = None
        le_scalar_117 = torch.ops.aten.le.Scalar(to_dtype_352, 0);  to_dtype_352 = None
        new_zeros_default_442 = torch.ops.aten.new_zeros.default(to_dtype_351, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_117 = torch.ops.aten.where.self(le_scalar_117, new_zeros_default_442, to_dtype_351);  le_scalar_117 = new_zeros_default_442 = to_dtype_351 = None
        to_dtype_353 = torch.ops.aten.to.dtype(where_self_117, torch.float32);  where_self_117 = None
        native_batch_norm_backward_default_145 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_353, convolution_default_179, primals_1001, primals_999, primals_1000, getitem_538, getitem_539, True, 1e-05, [True, True, True]);  to_dtype_353 = convolution_default_179 = primals_1001 = primals_999 = primals_1000 = getitem_538 = getitem_539 = None
        getitem_1845 = native_batch_norm_backward_default_145[0]
        getitem_1846 = native_batch_norm_backward_default_145[1]
        getitem_1847 = native_batch_norm_backward_default_145[2];  native_batch_norm_backward_default_145 = None
        convolution_backward_default_145 = torch.ops.aten.convolution_backward.default(getitem_1845, relu__default_147, primals_1007, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1845 = primals_1007 = None
        getitem_1848 = convolution_backward_default_145[0]
        getitem_1849 = convolution_backward_default_145[1]
        getitem_1850 = convolution_backward_default_145[2];  convolution_backward_default_145 = None
        add_tensor_143 = torch.ops.aten.add.Tensor(to_dtype_350, getitem_1848);  to_dtype_350 = getitem_1848 = None
        to_dtype_354 = torch.ops.aten.to.dtype(add_tensor_143, torch.float32);  add_tensor_143 = None
        to_dtype_355 = torch.ops.aten.to.dtype(relu__default_147, torch.float32);  relu__default_147 = None
        le_scalar_118 = torch.ops.aten.le.Scalar(to_dtype_355, 0);  to_dtype_355 = None
        new_zeros_default_443 = torch.ops.aten.new_zeros.default(to_dtype_354, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_118 = torch.ops.aten.where.self(le_scalar_118, new_zeros_default_443, to_dtype_354);  le_scalar_118 = new_zeros_default_443 = to_dtype_354 = None
        to_dtype_356 = torch.ops.aten.to.dtype(where_self_118, torch.float32);  where_self_118 = None
        native_batch_norm_backward_default_146 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_356, convolution_default_178, primals_994, primals_992, primals_993, getitem_535, getitem_536, True, 1e-05, [True, True, True]);  convolution_default_178 = primals_994 = primals_992 = primals_993 = getitem_535 = getitem_536 = None
        getitem_1851 = native_batch_norm_backward_default_146[0]
        getitem_1852 = native_batch_norm_backward_default_146[1]
        getitem_1853 = native_batch_norm_backward_default_146[2];  native_batch_norm_backward_default_146 = None
        convolution_backward_default_146 = torch.ops.aten.convolution_backward.default(getitem_1851, relu__default_146, primals_996, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1851 = primals_996 = None
        getitem_1854 = convolution_backward_default_146[0]
        getitem_1855 = convolution_backward_default_146[1]
        getitem_1856 = convolution_backward_default_146[2];  convolution_backward_default_146 = None
        to_dtype_357 = torch.ops.aten.to.dtype(getitem_1854, torch.float32);  getitem_1854 = None
        to_dtype_358 = torch.ops.aten.to.dtype(relu__default_146, torch.float32);  relu__default_146 = None
        le_scalar_119 = torch.ops.aten.le.Scalar(to_dtype_358, 0);  to_dtype_358 = None
        new_zeros_default_444 = torch.ops.aten.new_zeros.default(to_dtype_357, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_119 = torch.ops.aten.where.self(le_scalar_119, new_zeros_default_444, to_dtype_357);  le_scalar_119 = new_zeros_default_444 = to_dtype_357 = None
        to_dtype_359 = torch.ops.aten.to.dtype(where_self_119, torch.float32);  where_self_119 = None
        native_batch_norm_backward_default_147 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_359, convolution_default_177, primals_989, primals_987, primals_988, getitem_532, getitem_533, True, 1e-05, [True, True, True]);  to_dtype_359 = convolution_default_177 = primals_989 = primals_987 = primals_988 = getitem_532 = getitem_533 = None
        getitem_1857 = native_batch_norm_backward_default_147[0]
        getitem_1858 = native_batch_norm_backward_default_147[1]
        getitem_1859 = native_batch_norm_backward_default_147[2];  native_batch_norm_backward_default_147 = None
        convolution_backward_default_147 = torch.ops.aten.convolution_backward.default(getitem_1857, relu_default_17, primals_995, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1857 = primals_995 = None
        getitem_1860 = convolution_backward_default_147[0]
        getitem_1861 = convolution_backward_default_147[1]
        getitem_1862 = convolution_backward_default_147[2];  convolution_backward_default_147 = None
        add_tensor_144 = torch.ops.aten.add.Tensor(to_dtype_356, getitem_1860);  to_dtype_356 = getitem_1860 = None
        to_dtype_360 = torch.ops.aten.to.dtype(add_tensor_136, torch.float32);  add_tensor_136 = None
        to_dtype_361 = torch.ops.aten.to.dtype(relu__default_145, torch.float32);  relu__default_145 = None
        le_scalar_120 = torch.ops.aten.le.Scalar(to_dtype_361, 0);  to_dtype_361 = None
        new_zeros_default_445 = torch.ops.aten.new_zeros.default(to_dtype_360, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_120 = torch.ops.aten.where.self(le_scalar_120, new_zeros_default_445, to_dtype_360);  le_scalar_120 = new_zeros_default_445 = to_dtype_360 = None
        to_dtype_362 = torch.ops.aten.to.dtype(where_self_120, torch.float32);  where_self_120 = None
        native_batch_norm_backward_default_148 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_362, convolution_default_176, primals_982, primals_980, primals_981, getitem_529, getitem_530, True, 1e-05, [True, True, True]);  convolution_default_176 = primals_982 = primals_980 = primals_981 = getitem_529 = getitem_530 = None
        getitem_1863 = native_batch_norm_backward_default_148[0]
        getitem_1864 = native_batch_norm_backward_default_148[1]
        getitem_1865 = native_batch_norm_backward_default_148[2];  native_batch_norm_backward_default_148 = None
        convolution_backward_default_148 = torch.ops.aten.convolution_backward.default(getitem_1863, relu__default_144, primals_984, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1863 = primals_984 = None
        getitem_1866 = convolution_backward_default_148[0]
        getitem_1867 = convolution_backward_default_148[1]
        getitem_1868 = convolution_backward_default_148[2];  convolution_backward_default_148 = None
        to_dtype_363 = torch.ops.aten.to.dtype(getitem_1866, torch.float32);  getitem_1866 = None
        to_dtype_364 = torch.ops.aten.to.dtype(relu__default_144, torch.float32);  relu__default_144 = None
        le_scalar_121 = torch.ops.aten.le.Scalar(to_dtype_364, 0);  to_dtype_364 = None
        new_zeros_default_446 = torch.ops.aten.new_zeros.default(to_dtype_363, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_121 = torch.ops.aten.where.self(le_scalar_121, new_zeros_default_446, to_dtype_363);  le_scalar_121 = new_zeros_default_446 = to_dtype_363 = None
        to_dtype_365 = torch.ops.aten.to.dtype(where_self_121, torch.float32);  where_self_121 = None
        native_batch_norm_backward_default_149 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_365, convolution_default_175, primals_977, primals_975, primals_976, getitem_526, getitem_527, True, 1e-05, [True, True, True]);  to_dtype_365 = convolution_default_175 = primals_977 = primals_975 = primals_976 = getitem_526 = getitem_527 = None
        getitem_1869 = native_batch_norm_backward_default_149[0]
        getitem_1870 = native_batch_norm_backward_default_149[1]
        getitem_1871 = native_batch_norm_backward_default_149[2];  native_batch_norm_backward_default_149 = None
        convolution_backward_default_149 = torch.ops.aten.convolution_backward.default(getitem_1869, relu__default_143, primals_983, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1869 = primals_983 = None
        getitem_1872 = convolution_backward_default_149[0]
        getitem_1873 = convolution_backward_default_149[1]
        getitem_1874 = convolution_backward_default_149[2];  convolution_backward_default_149 = None
        add_tensor_145 = torch.ops.aten.add.Tensor(to_dtype_362, getitem_1872);  to_dtype_362 = getitem_1872 = None
        to_dtype_366 = torch.ops.aten.to.dtype(add_tensor_145, torch.float32);  add_tensor_145 = None
        to_dtype_367 = torch.ops.aten.to.dtype(relu__default_143, torch.float32);  relu__default_143 = None
        le_scalar_122 = torch.ops.aten.le.Scalar(to_dtype_367, 0);  to_dtype_367 = None
        new_zeros_default_447 = torch.ops.aten.new_zeros.default(to_dtype_366, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_122 = torch.ops.aten.where.self(le_scalar_122, new_zeros_default_447, to_dtype_366);  le_scalar_122 = new_zeros_default_447 = to_dtype_366 = None
        to_dtype_368 = torch.ops.aten.to.dtype(where_self_122, torch.float32);  where_self_122 = None
        native_batch_norm_backward_default_150 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_368, convolution_default_174, primals_970, primals_968, primals_969, getitem_523, getitem_524, True, 1e-05, [True, True, True]);  convolution_default_174 = primals_970 = primals_968 = primals_969 = getitem_523 = getitem_524 = None
        getitem_1875 = native_batch_norm_backward_default_150[0]
        getitem_1876 = native_batch_norm_backward_default_150[1]
        getitem_1877 = native_batch_norm_backward_default_150[2];  native_batch_norm_backward_default_150 = None
        convolution_backward_default_150 = torch.ops.aten.convolution_backward.default(getitem_1875, relu__default_142, primals_972, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1875 = primals_972 = None
        getitem_1878 = convolution_backward_default_150[0]
        getitem_1879 = convolution_backward_default_150[1]
        getitem_1880 = convolution_backward_default_150[2];  convolution_backward_default_150 = None
        to_dtype_369 = torch.ops.aten.to.dtype(getitem_1878, torch.float32);  getitem_1878 = None
        to_dtype_370 = torch.ops.aten.to.dtype(relu__default_142, torch.float32);  relu__default_142 = None
        le_scalar_123 = torch.ops.aten.le.Scalar(to_dtype_370, 0);  to_dtype_370 = None
        new_zeros_default_448 = torch.ops.aten.new_zeros.default(to_dtype_369, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_123 = torch.ops.aten.where.self(le_scalar_123, new_zeros_default_448, to_dtype_369);  le_scalar_123 = new_zeros_default_448 = to_dtype_369 = None
        to_dtype_371 = torch.ops.aten.to.dtype(where_self_123, torch.float32);  where_self_123 = None
        native_batch_norm_backward_default_151 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_371, convolution_default_173, primals_965, primals_963, primals_964, getitem_520, getitem_521, True, 1e-05, [True, True, True]);  to_dtype_371 = convolution_default_173 = primals_965 = primals_963 = primals_964 = getitem_520 = getitem_521 = None
        getitem_1881 = native_batch_norm_backward_default_151[0]
        getitem_1882 = native_batch_norm_backward_default_151[1]
        getitem_1883 = native_batch_norm_backward_default_151[2];  native_batch_norm_backward_default_151 = None
        convolution_backward_default_151 = torch.ops.aten.convolution_backward.default(getitem_1881, relu__default_141, primals_971, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1881 = primals_971 = None
        getitem_1884 = convolution_backward_default_151[0]
        getitem_1885 = convolution_backward_default_151[1]
        getitem_1886 = convolution_backward_default_151[2];  convolution_backward_default_151 = None
        add_tensor_146 = torch.ops.aten.add.Tensor(to_dtype_368, getitem_1884);  to_dtype_368 = getitem_1884 = None
        to_dtype_372 = torch.ops.aten.to.dtype(add_tensor_146, torch.float32);  add_tensor_146 = None
        to_dtype_373 = torch.ops.aten.to.dtype(relu__default_141, torch.float32);  relu__default_141 = None
        le_scalar_124 = torch.ops.aten.le.Scalar(to_dtype_373, 0);  to_dtype_373 = None
        new_zeros_default_449 = torch.ops.aten.new_zeros.default(to_dtype_372, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_124 = torch.ops.aten.where.self(le_scalar_124, new_zeros_default_449, to_dtype_372);  le_scalar_124 = new_zeros_default_449 = to_dtype_372 = None
        to_dtype_374 = torch.ops.aten.to.dtype(where_self_124, torch.float32);  where_self_124 = None
        native_batch_norm_backward_default_152 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_374, convolution_default_172, primals_958, primals_956, primals_957, getitem_517, getitem_518, True, 1e-05, [True, True, True]);  convolution_default_172 = primals_958 = primals_956 = primals_957 = getitem_517 = getitem_518 = None
        getitem_1887 = native_batch_norm_backward_default_152[0]
        getitem_1888 = native_batch_norm_backward_default_152[1]
        getitem_1889 = native_batch_norm_backward_default_152[2];  native_batch_norm_backward_default_152 = None
        convolution_backward_default_152 = torch.ops.aten.convolution_backward.default(getitem_1887, relu__default_140, primals_960, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1887 = primals_960 = None
        getitem_1890 = convolution_backward_default_152[0]
        getitem_1891 = convolution_backward_default_152[1]
        getitem_1892 = convolution_backward_default_152[2];  convolution_backward_default_152 = None
        to_dtype_375 = torch.ops.aten.to.dtype(getitem_1890, torch.float32);  getitem_1890 = None
        to_dtype_376 = torch.ops.aten.to.dtype(relu__default_140, torch.float32);  relu__default_140 = None
        le_scalar_125 = torch.ops.aten.le.Scalar(to_dtype_376, 0);  to_dtype_376 = None
        new_zeros_default_450 = torch.ops.aten.new_zeros.default(to_dtype_375, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_125 = torch.ops.aten.where.self(le_scalar_125, new_zeros_default_450, to_dtype_375);  le_scalar_125 = new_zeros_default_450 = to_dtype_375 = None
        to_dtype_377 = torch.ops.aten.to.dtype(where_self_125, torch.float32);  where_self_125 = None
        native_batch_norm_backward_default_153 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_377, convolution_default_171, primals_953, primals_951, primals_952, getitem_514, getitem_515, True, 1e-05, [True, True, True]);  to_dtype_377 = convolution_default_171 = primals_953 = primals_951 = primals_952 = getitem_514 = getitem_515 = None
        getitem_1893 = native_batch_norm_backward_default_153[0]
        getitem_1894 = native_batch_norm_backward_default_153[1]
        getitem_1895 = native_batch_norm_backward_default_153[2];  native_batch_norm_backward_default_153 = None
        convolution_backward_default_153 = torch.ops.aten.convolution_backward.default(getitem_1893, relu__default_139, primals_959, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1893 = primals_959 = None
        getitem_1896 = convolution_backward_default_153[0]
        getitem_1897 = convolution_backward_default_153[1]
        getitem_1898 = convolution_backward_default_153[2];  convolution_backward_default_153 = None
        add_tensor_147 = torch.ops.aten.add.Tensor(to_dtype_374, getitem_1896);  to_dtype_374 = getitem_1896 = None
        to_dtype_378 = torch.ops.aten.to.dtype(add_tensor_147, torch.float32);  add_tensor_147 = None
        to_dtype_379 = torch.ops.aten.to.dtype(relu__default_139, torch.float32);  relu__default_139 = None
        le_scalar_126 = torch.ops.aten.le.Scalar(to_dtype_379, 0);  to_dtype_379 = None
        new_zeros_default_451 = torch.ops.aten.new_zeros.default(to_dtype_378, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_126 = torch.ops.aten.where.self(le_scalar_126, new_zeros_default_451, to_dtype_378);  le_scalar_126 = new_zeros_default_451 = to_dtype_378 = None
        to_dtype_380 = torch.ops.aten.to.dtype(where_self_126, torch.float32);  where_self_126 = None
        native_batch_norm_backward_default_154 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_380, convolution_default_170, primals_946, primals_944, primals_945, getitem_511, getitem_512, True, 1e-05, [True, True, True]);  convolution_default_170 = primals_946 = primals_944 = primals_945 = getitem_511 = getitem_512 = None
        getitem_1899 = native_batch_norm_backward_default_154[0]
        getitem_1900 = native_batch_norm_backward_default_154[1]
        getitem_1901 = native_batch_norm_backward_default_154[2];  native_batch_norm_backward_default_154 = None
        convolution_backward_default_154 = torch.ops.aten.convolution_backward.default(getitem_1899, relu__default_138, primals_948, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1899 = primals_948 = None
        getitem_1902 = convolution_backward_default_154[0]
        getitem_1903 = convolution_backward_default_154[1]
        getitem_1904 = convolution_backward_default_154[2];  convolution_backward_default_154 = None
        to_dtype_381 = torch.ops.aten.to.dtype(getitem_1902, torch.float32);  getitem_1902 = None
        to_dtype_382 = torch.ops.aten.to.dtype(relu__default_138, torch.float32);  relu__default_138 = None
        le_scalar_127 = torch.ops.aten.le.Scalar(to_dtype_382, 0);  to_dtype_382 = None
        new_zeros_default_452 = torch.ops.aten.new_zeros.default(to_dtype_381, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_127 = torch.ops.aten.where.self(le_scalar_127, new_zeros_default_452, to_dtype_381);  le_scalar_127 = new_zeros_default_452 = to_dtype_381 = None
        to_dtype_383 = torch.ops.aten.to.dtype(where_self_127, torch.float32);  where_self_127 = None
        native_batch_norm_backward_default_155 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_383, convolution_default_169, primals_941, primals_939, primals_940, getitem_508, getitem_509, True, 1e-05, [True, True, True]);  to_dtype_383 = convolution_default_169 = primals_941 = primals_939 = primals_940 = getitem_508 = getitem_509 = None
        getitem_1905 = native_batch_norm_backward_default_155[0]
        getitem_1906 = native_batch_norm_backward_default_155[1]
        getitem_1907 = native_batch_norm_backward_default_155[2];  native_batch_norm_backward_default_155 = None
        convolution_backward_default_155 = torch.ops.aten.convolution_backward.default(getitem_1905, relu_default_15, primals_947, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1905 = primals_947 = None
        getitem_1908 = convolution_backward_default_155[0]
        getitem_1909 = convolution_backward_default_155[1]
        getitem_1910 = convolution_backward_default_155[2];  convolution_backward_default_155 = None
        add_tensor_148 = torch.ops.aten.add.Tensor(to_dtype_380, getitem_1908);  to_dtype_380 = getitem_1908 = None
        to_dtype_384 = torch.ops.aten.to.dtype(add_tensor_135, torch.float32);  add_tensor_135 = None
        to_dtype_385 = torch.ops.aten.to.dtype(relu__default_137, torch.float32);  relu__default_137 = None
        le_scalar_128 = torch.ops.aten.le.Scalar(to_dtype_385, 0);  to_dtype_385 = None
        new_zeros_default_453 = torch.ops.aten.new_zeros.default(to_dtype_384, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_128 = torch.ops.aten.where.self(le_scalar_128, new_zeros_default_453, to_dtype_384);  le_scalar_128 = new_zeros_default_453 = to_dtype_384 = None
        to_dtype_386 = torch.ops.aten.to.dtype(where_self_128, torch.float32);  where_self_128 = None
        native_batch_norm_backward_default_156 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_386, convolution_default_168, primals_934, primals_932, primals_933, getitem_505, getitem_506, True, 1e-05, [True, True, True]);  convolution_default_168 = primals_934 = primals_932 = primals_933 = getitem_505 = getitem_506 = None
        getitem_1911 = native_batch_norm_backward_default_156[0]
        getitem_1912 = native_batch_norm_backward_default_156[1]
        getitem_1913 = native_batch_norm_backward_default_156[2];  native_batch_norm_backward_default_156 = None
        convolution_backward_default_156 = torch.ops.aten.convolution_backward.default(getitem_1911, relu__default_136, primals_936, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1911 = primals_936 = None
        getitem_1914 = convolution_backward_default_156[0]
        getitem_1915 = convolution_backward_default_156[1]
        getitem_1916 = convolution_backward_default_156[2];  convolution_backward_default_156 = None
        to_dtype_387 = torch.ops.aten.to.dtype(getitem_1914, torch.float32);  getitem_1914 = None
        to_dtype_388 = torch.ops.aten.to.dtype(relu__default_136, torch.float32);  relu__default_136 = None
        le_scalar_129 = torch.ops.aten.le.Scalar(to_dtype_388, 0);  to_dtype_388 = None
        new_zeros_default_454 = torch.ops.aten.new_zeros.default(to_dtype_387, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_129 = torch.ops.aten.where.self(le_scalar_129, new_zeros_default_454, to_dtype_387);  le_scalar_129 = new_zeros_default_454 = to_dtype_387 = None
        to_dtype_389 = torch.ops.aten.to.dtype(where_self_129, torch.float32);  where_self_129 = None
        native_batch_norm_backward_default_157 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_389, convolution_default_167, primals_929, primals_927, primals_928, getitem_502, getitem_503, True, 1e-05, [True, True, True]);  to_dtype_389 = convolution_default_167 = primals_929 = primals_927 = primals_928 = getitem_502 = getitem_503 = None
        getitem_1917 = native_batch_norm_backward_default_157[0]
        getitem_1918 = native_batch_norm_backward_default_157[1]
        getitem_1919 = native_batch_norm_backward_default_157[2];  native_batch_norm_backward_default_157 = None
        convolution_backward_default_157 = torch.ops.aten.convolution_backward.default(getitem_1917, relu__default_135, primals_935, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1917 = primals_935 = None
        getitem_1920 = convolution_backward_default_157[0]
        getitem_1921 = convolution_backward_default_157[1]
        getitem_1922 = convolution_backward_default_157[2];  convolution_backward_default_157 = None
        add_tensor_149 = torch.ops.aten.add.Tensor(to_dtype_386, getitem_1920);  to_dtype_386 = getitem_1920 = None
        to_dtype_390 = torch.ops.aten.to.dtype(add_tensor_149, torch.float32);  add_tensor_149 = None
        to_dtype_391 = torch.ops.aten.to.dtype(relu__default_135, torch.float32);  relu__default_135 = None
        le_scalar_130 = torch.ops.aten.le.Scalar(to_dtype_391, 0);  to_dtype_391 = None
        new_zeros_default_455 = torch.ops.aten.new_zeros.default(to_dtype_390, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_130 = torch.ops.aten.where.self(le_scalar_130, new_zeros_default_455, to_dtype_390);  le_scalar_130 = new_zeros_default_455 = to_dtype_390 = None
        to_dtype_392 = torch.ops.aten.to.dtype(where_self_130, torch.float32);  where_self_130 = None
        native_batch_norm_backward_default_158 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_392, convolution_default_166, primals_922, primals_920, primals_921, getitem_499, getitem_500, True, 1e-05, [True, True, True]);  convolution_default_166 = primals_922 = primals_920 = primals_921 = getitem_499 = getitem_500 = None
        getitem_1923 = native_batch_norm_backward_default_158[0]
        getitem_1924 = native_batch_norm_backward_default_158[1]
        getitem_1925 = native_batch_norm_backward_default_158[2];  native_batch_norm_backward_default_158 = None
        convolution_backward_default_158 = torch.ops.aten.convolution_backward.default(getitem_1923, relu__default_134, primals_924, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1923 = primals_924 = None
        getitem_1926 = convolution_backward_default_158[0]
        getitem_1927 = convolution_backward_default_158[1]
        getitem_1928 = convolution_backward_default_158[2];  convolution_backward_default_158 = None
        to_dtype_393 = torch.ops.aten.to.dtype(getitem_1926, torch.float32);  getitem_1926 = None
        to_dtype_394 = torch.ops.aten.to.dtype(relu__default_134, torch.float32);  relu__default_134 = None
        le_scalar_131 = torch.ops.aten.le.Scalar(to_dtype_394, 0);  to_dtype_394 = None
        new_zeros_default_456 = torch.ops.aten.new_zeros.default(to_dtype_393, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_131 = torch.ops.aten.where.self(le_scalar_131, new_zeros_default_456, to_dtype_393);  le_scalar_131 = new_zeros_default_456 = to_dtype_393 = None
        to_dtype_395 = torch.ops.aten.to.dtype(where_self_131, torch.float32);  where_self_131 = None
        native_batch_norm_backward_default_159 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_395, convolution_default_165, primals_917, primals_915, primals_916, getitem_496, getitem_497, True, 1e-05, [True, True, True]);  to_dtype_395 = convolution_default_165 = primals_917 = primals_915 = primals_916 = getitem_496 = getitem_497 = None
        getitem_1929 = native_batch_norm_backward_default_159[0]
        getitem_1930 = native_batch_norm_backward_default_159[1]
        getitem_1931 = native_batch_norm_backward_default_159[2];  native_batch_norm_backward_default_159 = None
        convolution_backward_default_159 = torch.ops.aten.convolution_backward.default(getitem_1929, relu__default_133, primals_923, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1929 = primals_923 = None
        getitem_1932 = convolution_backward_default_159[0]
        getitem_1933 = convolution_backward_default_159[1]
        getitem_1934 = convolution_backward_default_159[2];  convolution_backward_default_159 = None
        add_tensor_150 = torch.ops.aten.add.Tensor(to_dtype_392, getitem_1932);  to_dtype_392 = getitem_1932 = None
        to_dtype_396 = torch.ops.aten.to.dtype(add_tensor_150, torch.float32);  add_tensor_150 = None
        to_dtype_397 = torch.ops.aten.to.dtype(relu__default_133, torch.float32);  relu__default_133 = None
        le_scalar_132 = torch.ops.aten.le.Scalar(to_dtype_397, 0);  to_dtype_397 = None
        new_zeros_default_457 = torch.ops.aten.new_zeros.default(to_dtype_396, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_132 = torch.ops.aten.where.self(le_scalar_132, new_zeros_default_457, to_dtype_396);  le_scalar_132 = new_zeros_default_457 = to_dtype_396 = None
        to_dtype_398 = torch.ops.aten.to.dtype(where_self_132, torch.float32);  where_self_132 = None
        native_batch_norm_backward_default_160 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_398, convolution_default_164, primals_910, primals_908, primals_909, getitem_493, getitem_494, True, 1e-05, [True, True, True]);  convolution_default_164 = primals_910 = primals_908 = primals_909 = getitem_493 = getitem_494 = None
        getitem_1935 = native_batch_norm_backward_default_160[0]
        getitem_1936 = native_batch_norm_backward_default_160[1]
        getitem_1937 = native_batch_norm_backward_default_160[2];  native_batch_norm_backward_default_160 = None
        convolution_backward_default_160 = torch.ops.aten.convolution_backward.default(getitem_1935, relu__default_132, primals_912, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1935 = primals_912 = None
        getitem_1938 = convolution_backward_default_160[0]
        getitem_1939 = convolution_backward_default_160[1]
        getitem_1940 = convolution_backward_default_160[2];  convolution_backward_default_160 = None
        to_dtype_399 = torch.ops.aten.to.dtype(getitem_1938, torch.float32);  getitem_1938 = None
        to_dtype_400 = torch.ops.aten.to.dtype(relu__default_132, torch.float32);  relu__default_132 = None
        le_scalar_133 = torch.ops.aten.le.Scalar(to_dtype_400, 0);  to_dtype_400 = None
        new_zeros_default_458 = torch.ops.aten.new_zeros.default(to_dtype_399, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_133 = torch.ops.aten.where.self(le_scalar_133, new_zeros_default_458, to_dtype_399);  le_scalar_133 = new_zeros_default_458 = to_dtype_399 = None
        to_dtype_401 = torch.ops.aten.to.dtype(where_self_133, torch.float32);  where_self_133 = None
        native_batch_norm_backward_default_161 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_401, convolution_default_163, primals_905, primals_903, primals_904, getitem_490, getitem_491, True, 1e-05, [True, True, True]);  to_dtype_401 = convolution_default_163 = primals_905 = primals_903 = primals_904 = getitem_490 = getitem_491 = None
        getitem_1941 = native_batch_norm_backward_default_161[0]
        getitem_1942 = native_batch_norm_backward_default_161[1]
        getitem_1943 = native_batch_norm_backward_default_161[2];  native_batch_norm_backward_default_161 = None
        convolution_backward_default_161 = torch.ops.aten.convolution_backward.default(getitem_1941, relu__default_131, primals_911, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1941 = primals_911 = None
        getitem_1944 = convolution_backward_default_161[0]
        getitem_1945 = convolution_backward_default_161[1]
        getitem_1946 = convolution_backward_default_161[2];  convolution_backward_default_161 = None
        add_tensor_151 = torch.ops.aten.add.Tensor(to_dtype_398, getitem_1944);  to_dtype_398 = getitem_1944 = None
        to_dtype_402 = torch.ops.aten.to.dtype(add_tensor_151, torch.float32);  add_tensor_151 = None
        to_dtype_403 = torch.ops.aten.to.dtype(relu__default_131, torch.float32);  relu__default_131 = None
        le_scalar_134 = torch.ops.aten.le.Scalar(to_dtype_403, 0);  to_dtype_403 = None
        new_zeros_default_459 = torch.ops.aten.new_zeros.default(to_dtype_402, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_134 = torch.ops.aten.where.self(le_scalar_134, new_zeros_default_459, to_dtype_402);  le_scalar_134 = new_zeros_default_459 = to_dtype_402 = None
        to_dtype_404 = torch.ops.aten.to.dtype(where_self_134, torch.float32);  where_self_134 = None
        native_batch_norm_backward_default_162 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_404, convolution_default_162, primals_898, primals_896, primals_897, getitem_487, getitem_488, True, 1e-05, [True, True, True]);  convolution_default_162 = primals_898 = primals_896 = primals_897 = getitem_487 = getitem_488 = None
        getitem_1947 = native_batch_norm_backward_default_162[0]
        getitem_1948 = native_batch_norm_backward_default_162[1]
        getitem_1949 = native_batch_norm_backward_default_162[2];  native_batch_norm_backward_default_162 = None
        convolution_backward_default_162 = torch.ops.aten.convolution_backward.default(getitem_1947, relu__default_130, primals_900, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1947 = primals_900 = None
        getitem_1950 = convolution_backward_default_162[0]
        getitem_1951 = convolution_backward_default_162[1]
        getitem_1952 = convolution_backward_default_162[2];  convolution_backward_default_162 = None
        to_dtype_405 = torch.ops.aten.to.dtype(getitem_1950, torch.float32);  getitem_1950 = None
        to_dtype_406 = torch.ops.aten.to.dtype(relu__default_130, torch.float32);  relu__default_130 = None
        le_scalar_135 = torch.ops.aten.le.Scalar(to_dtype_406, 0);  to_dtype_406 = None
        new_zeros_default_460 = torch.ops.aten.new_zeros.default(to_dtype_405, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_135 = torch.ops.aten.where.self(le_scalar_135, new_zeros_default_460, to_dtype_405);  le_scalar_135 = new_zeros_default_460 = to_dtype_405 = None
        to_dtype_407 = torch.ops.aten.to.dtype(where_self_135, torch.float32);  where_self_135 = None
        native_batch_norm_backward_default_163 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_407, convolution_default_161, primals_893, primals_891, primals_892, getitem_484, getitem_485, True, 1e-05, [True, True, True]);  to_dtype_407 = convolution_default_161 = primals_893 = primals_891 = primals_892 = getitem_484 = getitem_485 = None
        getitem_1953 = native_batch_norm_backward_default_163[0]
        getitem_1954 = native_batch_norm_backward_default_163[1]
        getitem_1955 = native_batch_norm_backward_default_163[2];  native_batch_norm_backward_default_163 = None
        convolution_backward_default_163 = torch.ops.aten.convolution_backward.default(getitem_1953, relu_default_14, primals_899, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1953 = primals_899 = None
        getitem_1956 = convolution_backward_default_163[0]
        getitem_1957 = convolution_backward_default_163[1]
        getitem_1958 = convolution_backward_default_163[2];  convolution_backward_default_163 = None
        add_tensor_152 = torch.ops.aten.add.Tensor(to_dtype_404, getitem_1956);  to_dtype_404 = getitem_1956 = None
        to_dtype_408 = torch.ops.aten.to.dtype(add_tensor_140, torch.float32);  add_tensor_140 = None
        to_dtype_409 = torch.ops.aten.to.dtype(relu__default_129, torch.float32);  relu__default_129 = None
        le_scalar_136 = torch.ops.aten.le.Scalar(to_dtype_409, 0);  to_dtype_409 = None
        new_zeros_default_461 = torch.ops.aten.new_zeros.default(to_dtype_408, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_136 = torch.ops.aten.where.self(le_scalar_136, new_zeros_default_461, to_dtype_408);  le_scalar_136 = new_zeros_default_461 = to_dtype_408 = None
        to_dtype_410 = torch.ops.aten.to.dtype(where_self_136, torch.float32);  where_self_136 = None
        native_batch_norm_backward_default_164 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_410, convolution_default_160, primals_1488, primals_1486, primals_1487, getitem_481, getitem_482, True, 1e-05, [True, True, True]);  to_dtype_410 = convolution_default_160 = primals_1488 = primals_1486 = primals_1487 = getitem_481 = getitem_482 = None
        getitem_1959 = native_batch_norm_backward_default_164[0]
        getitem_1960 = native_batch_norm_backward_default_164[1]
        getitem_1961 = native_batch_norm_backward_default_164[2];  native_batch_norm_backward_default_164 = None
        convolution_backward_default_164 = torch.ops.aten.convolution_backward.default(getitem_1959, relu_default_17, primals_1483, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1959 = primals_1483 = None
        getitem_1962 = convolution_backward_default_164[0]
        getitem_1963 = convolution_backward_default_164[1]
        getitem_1964 = convolution_backward_default_164[2];  convolution_backward_default_164 = None
        add_tensor_153 = torch.ops.aten.add.Tensor(add_tensor_144, getitem_1962);  add_tensor_144 = getitem_1962 = None
        to_dtype_411 = torch.ops.aten.to.dtype(add_tensor_153, torch.float32);  add_tensor_153 = None
        to_dtype_412 = torch.ops.aten.to.dtype(relu_default_17, torch.float32);  relu_default_17 = None
        le_scalar_137 = torch.ops.aten.le.Scalar(to_dtype_412, 0);  to_dtype_412 = None
        new_zeros_default_462 = torch.ops.aten.new_zeros.default(to_dtype_411, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_137 = torch.ops.aten.where.self(le_scalar_137, new_zeros_default_462, to_dtype_411);  le_scalar_137 = new_zeros_default_462 = to_dtype_411 = None
        to_dtype_413 = torch.ops.aten.to.dtype(where_self_137, torch.float32);  where_self_137 = None
        native_batch_norm_backward_default_165 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_413, convolution_default_159, primals_1686, primals_1684, primals_1685, getitem_478, getitem_479, True, 1e-05, [True, True, True]);  convolution_default_159 = primals_1686 = primals_1684 = primals_1685 = getitem_478 = getitem_479 = None
        getitem_1965 = native_batch_norm_backward_default_165[0]
        getitem_1966 = native_batch_norm_backward_default_165[1]
        getitem_1967 = native_batch_norm_backward_default_165[2];  native_batch_norm_backward_default_165 = None
        convolution_backward_default_165 = torch.ops.aten.convolution_backward.default(getitem_1965, relu__default_120, primals_1681, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1965 = primals_1681 = None
        getitem_1968 = convolution_backward_default_165[0]
        getitem_1969 = convolution_backward_default_165[1]
        getitem_1970 = convolution_backward_default_165[2];  convolution_backward_default_165 = None
        native_batch_norm_backward_default_166 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_413, convolution_default_158, primals_1668, primals_1666, primals_1667, getitem_475, getitem_476, True, 1e-05, [True, True, True]);  convolution_default_158 = primals_1668 = primals_1666 = primals_1667 = getitem_475 = getitem_476 = None
        getitem_1971 = native_batch_norm_backward_default_166[0]
        getitem_1972 = native_batch_norm_backward_default_166[1]
        getitem_1973 = native_batch_norm_backward_default_166[2];  native_batch_norm_backward_default_166 = None
        convolution_backward_default_166 = torch.ops.aten.convolution_backward.default(getitem_1971, relu_default_16, primals_1663, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1971 = primals_1663 = None
        getitem_1974 = convolution_backward_default_166[0]
        getitem_1975 = convolution_backward_default_166[1]
        getitem_1976 = convolution_backward_default_166[2];  convolution_backward_default_166 = None
        to_dtype_414 = torch.ops.aten.to.dtype(getitem_1974, torch.float32);  getitem_1974 = None
        to_dtype_415 = torch.ops.aten.to.dtype(relu_default_16, torch.float32);  relu_default_16 = None
        le_scalar_138 = torch.ops.aten.le.Scalar(to_dtype_415, 0);  to_dtype_415 = None
        new_zeros_default_463 = torch.ops.aten.new_zeros.default(to_dtype_414, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_138 = torch.ops.aten.where.self(le_scalar_138, new_zeros_default_463, to_dtype_414);  le_scalar_138 = new_zeros_default_463 = to_dtype_414 = None
        to_dtype_416 = torch.ops.aten.to.dtype(where_self_138, torch.float32);  where_self_138 = None
        native_batch_norm_backward_default_167 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_416, convolution_default_157, primals_1662, primals_1660, primals_1661, getitem_472, getitem_473, True, 1e-05, [True, True, True]);  to_dtype_416 = convolution_default_157 = primals_1662 = primals_1660 = primals_1661 = getitem_472 = getitem_473 = None
        getitem_1977 = native_batch_norm_backward_default_167[0]
        getitem_1978 = native_batch_norm_backward_default_167[1]
        getitem_1979 = native_batch_norm_backward_default_167[2];  native_batch_norm_backward_default_167 = None
        convolution_backward_default_167 = torch.ops.aten.convolution_backward.default(getitem_1977, relu__default_112, primals_1657, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1977 = primals_1657 = None
        getitem_1980 = convolution_backward_default_167[0]
        getitem_1981 = convolution_backward_default_167[1]
        getitem_1982 = convolution_backward_default_167[2];  convolution_backward_default_167 = None
        to_dtype_417 = torch.ops.aten.to.dtype(add_tensor_148, torch.float32);  add_tensor_148 = None
        to_dtype_418 = torch.ops.aten.to.dtype(relu_default_15, torch.float32);  relu_default_15 = None
        le_scalar_139 = torch.ops.aten.le.Scalar(to_dtype_418, 0);  to_dtype_418 = None
        new_zeros_default_464 = torch.ops.aten.new_zeros.default(to_dtype_417, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_139 = torch.ops.aten.where.self(le_scalar_139, new_zeros_default_464, to_dtype_417);  le_scalar_139 = new_zeros_default_464 = to_dtype_417 = None
        to_dtype_419 = torch.ops.aten.to.dtype(where_self_139, torch.float32);  where_self_139 = None
        upsample_nearest2d_backward_vec_18 = torch.ops.aten.upsample_nearest2d_backward.vec(to_dtype_419, None, [128, 36, 14, 14], [2.0, 2.0])
        native_batch_norm_backward_default_168 = torch.ops.aten.native_batch_norm_backward.default(upsample_nearest2d_backward_vec_18, convolution_default_156, primals_1902, primals_1900, primals_1901, getitem_469, getitem_470, True, 1e-05, [True, True, True]);  upsample_nearest2d_backward_vec_18 = convolution_default_156 = primals_1902 = primals_1900 = primals_1901 = getitem_469 = getitem_470 = None
        getitem_1983 = native_batch_norm_backward_default_168[0]
        getitem_1984 = native_batch_norm_backward_default_168[1]
        getitem_1985 = native_batch_norm_backward_default_168[2];  native_batch_norm_backward_default_168 = None
        convolution_backward_default_168 = torch.ops.aten.convolution_backward.default(getitem_1983, relu__default_128, primals_1897, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1983 = primals_1897 = None
        getitem_1986 = convolution_backward_default_168[0]
        getitem_1987 = convolution_backward_default_168[1]
        getitem_1988 = convolution_backward_default_168[2];  convolution_backward_default_168 = None
        add_tensor_154 = torch.ops.aten.add.Tensor(to_dtype_413, getitem_1986);  to_dtype_413 = getitem_1986 = None
        add_tensor_155 = torch.ops.aten.add.Tensor(getitem_1968, to_dtype_419);  getitem_1968 = None
        native_batch_norm_backward_default_169 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_419, convolution_default_155, primals_1656, primals_1654, primals_1655, getitem_466, getitem_467, True, 1e-05, [True, True, True]);  to_dtype_419 = convolution_default_155 = primals_1656 = primals_1654 = primals_1655 = getitem_466 = getitem_467 = None
        getitem_1989 = native_batch_norm_backward_default_169[0]
        getitem_1990 = native_batch_norm_backward_default_169[1]
        getitem_1991 = native_batch_norm_backward_default_169[2];  native_batch_norm_backward_default_169 = None
        convolution_backward_default_169 = torch.ops.aten.convolution_backward.default(getitem_1989, relu__default_112, primals_1651, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1989 = primals_1651 = None
        getitem_1992 = convolution_backward_default_169[0]
        getitem_1993 = convolution_backward_default_169[1]
        getitem_1994 = convolution_backward_default_169[2];  convolution_backward_default_169 = None
        add_tensor_156 = torch.ops.aten.add.Tensor(getitem_1980, getitem_1992);  getitem_1980 = getitem_1992 = None
        to_dtype_420 = torch.ops.aten.to.dtype(add_tensor_152, torch.float32);  add_tensor_152 = None
        to_dtype_421 = torch.ops.aten.to.dtype(relu_default_14, torch.float32);  relu_default_14 = None
        le_scalar_140 = torch.ops.aten.le.Scalar(to_dtype_421, 0);  to_dtype_421 = None
        new_zeros_default_465 = torch.ops.aten.new_zeros.default(to_dtype_420, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_140 = torch.ops.aten.where.self(le_scalar_140, new_zeros_default_465, to_dtype_420);  le_scalar_140 = new_zeros_default_465 = to_dtype_420 = None
        to_dtype_422 = torch.ops.aten.to.dtype(where_self_140, torch.float32);  where_self_140 = None
        upsample_nearest2d_backward_vec_19 = torch.ops.aten.upsample_nearest2d_backward.vec(to_dtype_422, None, [128, 18, 14, 14], [4.0, 4.0])
        native_batch_norm_backward_default_170 = torch.ops.aten.native_batch_norm_backward.default(upsample_nearest2d_backward_vec_19, convolution_default_154, primals_1896, primals_1894, primals_1895, getitem_463, getitem_464, True, 1e-05, [True, True, True]);  upsample_nearest2d_backward_vec_19 = convolution_default_154 = primals_1896 = primals_1894 = primals_1895 = getitem_463 = getitem_464 = None
        getitem_1995 = native_batch_norm_backward_default_170[0]
        getitem_1996 = native_batch_norm_backward_default_170[1]
        getitem_1997 = native_batch_norm_backward_default_170[2];  native_batch_norm_backward_default_170 = None
        convolution_backward_default_170 = torch.ops.aten.convolution_backward.default(getitem_1995, relu__default_128, primals_1891, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1995 = primals_1891 = None
        getitem_1998 = convolution_backward_default_170[0]
        getitem_1999 = convolution_backward_default_170[1]
        getitem_2000 = convolution_backward_default_170[2];  convolution_backward_default_170 = None
        add_tensor_157 = torch.ops.aten.add.Tensor(add_tensor_154, getitem_1998);  add_tensor_154 = getitem_1998 = None
        add_tensor_158 = torch.ops.aten.add.Tensor(add_tensor_156, to_dtype_422);  add_tensor_156 = None
        upsample_nearest2d_backward_vec_20 = torch.ops.aten.upsample_nearest2d_backward.vec(to_dtype_422, None, [128, 18, 28, 28], [2.0, 2.0]);  to_dtype_422 = None
        native_batch_norm_backward_default_171 = torch.ops.aten.native_batch_norm_backward.default(upsample_nearest2d_backward_vec_20, convolution_default_153, primals_1800, primals_1798, primals_1799, getitem_460, getitem_461, True, 1e-05, [True, True, True]);  upsample_nearest2d_backward_vec_20 = convolution_default_153 = primals_1800 = primals_1798 = primals_1799 = getitem_460 = getitem_461 = None
        getitem_2001 = native_batch_norm_backward_default_171[0]
        getitem_2002 = native_batch_norm_backward_default_171[1]
        getitem_2003 = native_batch_norm_backward_default_171[2];  native_batch_norm_backward_default_171 = None
        convolution_backward_default_171 = torch.ops.aten.convolution_backward.default(getitem_2001, relu__default_120, primals_1795, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2001 = primals_1795 = None
        getitem_2004 = convolution_backward_default_171[0]
        getitem_2005 = convolution_backward_default_171[1]
        getitem_2006 = convolution_backward_default_171[2];  convolution_backward_default_171 = None
        add_tensor_159 = torch.ops.aten.add.Tensor(add_tensor_155, getitem_2004);  add_tensor_155 = getitem_2004 = None
        to_dtype_423 = torch.ops.aten.to.dtype(add_tensor_157, torch.float32);  add_tensor_157 = None
        to_dtype_424 = torch.ops.aten.to.dtype(relu__default_128, torch.float32);  relu__default_128 = None
        le_scalar_141 = torch.ops.aten.le.Scalar(to_dtype_424, 0);  to_dtype_424 = None
        new_zeros_default_466 = torch.ops.aten.new_zeros.default(to_dtype_423, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_141 = torch.ops.aten.where.self(le_scalar_141, new_zeros_default_466, to_dtype_423);  le_scalar_141 = new_zeros_default_466 = to_dtype_423 = None
        to_dtype_425 = torch.ops.aten.to.dtype(where_self_141, torch.float32);  where_self_141 = None
        native_batch_norm_backward_default_172 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_425, convolution_default_152, primals_886, primals_884, primals_885, getitem_457, getitem_458, True, 1e-05, [True, True, True]);  convolution_default_152 = primals_886 = primals_884 = primals_885 = getitem_457 = getitem_458 = None
        getitem_2007 = native_batch_norm_backward_default_172[0]
        getitem_2008 = native_batch_norm_backward_default_172[1]
        getitem_2009 = native_batch_norm_backward_default_172[2];  native_batch_norm_backward_default_172 = None
        convolution_backward_default_172 = torch.ops.aten.convolution_backward.default(getitem_2007, relu__default_127, primals_888, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2007 = primals_888 = None
        getitem_2010 = convolution_backward_default_172[0]
        getitem_2011 = convolution_backward_default_172[1]
        getitem_2012 = convolution_backward_default_172[2];  convolution_backward_default_172 = None
        to_dtype_426 = torch.ops.aten.to.dtype(getitem_2010, torch.float32);  getitem_2010 = None
        to_dtype_427 = torch.ops.aten.to.dtype(relu__default_127, torch.float32);  relu__default_127 = None
        le_scalar_142 = torch.ops.aten.le.Scalar(to_dtype_427, 0);  to_dtype_427 = None
        new_zeros_default_467 = torch.ops.aten.new_zeros.default(to_dtype_426, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_142 = torch.ops.aten.where.self(le_scalar_142, new_zeros_default_467, to_dtype_426);  le_scalar_142 = new_zeros_default_467 = to_dtype_426 = None
        to_dtype_428 = torch.ops.aten.to.dtype(where_self_142, torch.float32);  where_self_142 = None
        native_batch_norm_backward_default_173 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_428, convolution_default_151, primals_881, primals_879, primals_880, getitem_454, getitem_455, True, 1e-05, [True, True, True]);  to_dtype_428 = convolution_default_151 = primals_881 = primals_879 = primals_880 = getitem_454 = getitem_455 = None
        getitem_2013 = native_batch_norm_backward_default_173[0]
        getitem_2014 = native_batch_norm_backward_default_173[1]
        getitem_2015 = native_batch_norm_backward_default_173[2];  native_batch_norm_backward_default_173 = None
        convolution_backward_default_173 = torch.ops.aten.convolution_backward.default(getitem_2013, relu__default_126, primals_887, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2013 = primals_887 = None
        getitem_2016 = convolution_backward_default_173[0]
        getitem_2017 = convolution_backward_default_173[1]
        getitem_2018 = convolution_backward_default_173[2];  convolution_backward_default_173 = None
        add_tensor_160 = torch.ops.aten.add.Tensor(to_dtype_425, getitem_2016);  to_dtype_425 = getitem_2016 = None
        to_dtype_429 = torch.ops.aten.to.dtype(add_tensor_160, torch.float32);  add_tensor_160 = None
        to_dtype_430 = torch.ops.aten.to.dtype(relu__default_126, torch.float32);  relu__default_126 = None
        le_scalar_143 = torch.ops.aten.le.Scalar(to_dtype_430, 0);  to_dtype_430 = None
        new_zeros_default_468 = torch.ops.aten.new_zeros.default(to_dtype_429, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_143 = torch.ops.aten.where.self(le_scalar_143, new_zeros_default_468, to_dtype_429);  le_scalar_143 = new_zeros_default_468 = to_dtype_429 = None
        to_dtype_431 = torch.ops.aten.to.dtype(where_self_143, torch.float32);  where_self_143 = None
        native_batch_norm_backward_default_174 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_431, convolution_default_150, primals_874, primals_872, primals_873, getitem_451, getitem_452, True, 1e-05, [True, True, True]);  convolution_default_150 = primals_874 = primals_872 = primals_873 = getitem_451 = getitem_452 = None
        getitem_2019 = native_batch_norm_backward_default_174[0]
        getitem_2020 = native_batch_norm_backward_default_174[1]
        getitem_2021 = native_batch_norm_backward_default_174[2];  native_batch_norm_backward_default_174 = None
        convolution_backward_default_174 = torch.ops.aten.convolution_backward.default(getitem_2019, relu__default_125, primals_876, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2019 = primals_876 = None
        getitem_2022 = convolution_backward_default_174[0]
        getitem_2023 = convolution_backward_default_174[1]
        getitem_2024 = convolution_backward_default_174[2];  convolution_backward_default_174 = None
        to_dtype_432 = torch.ops.aten.to.dtype(getitem_2022, torch.float32);  getitem_2022 = None
        to_dtype_433 = torch.ops.aten.to.dtype(relu__default_125, torch.float32);  relu__default_125 = None
        le_scalar_144 = torch.ops.aten.le.Scalar(to_dtype_433, 0);  to_dtype_433 = None
        new_zeros_default_469 = torch.ops.aten.new_zeros.default(to_dtype_432, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_144 = torch.ops.aten.where.self(le_scalar_144, new_zeros_default_469, to_dtype_432);  le_scalar_144 = new_zeros_default_469 = to_dtype_432 = None
        to_dtype_434 = torch.ops.aten.to.dtype(where_self_144, torch.float32);  where_self_144 = None
        native_batch_norm_backward_default_175 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_434, convolution_default_149, primals_869, primals_867, primals_868, getitem_448, getitem_449, True, 1e-05, [True, True, True]);  to_dtype_434 = convolution_default_149 = primals_869 = primals_867 = primals_868 = getitem_448 = getitem_449 = None
        getitem_2025 = native_batch_norm_backward_default_175[0]
        getitem_2026 = native_batch_norm_backward_default_175[1]
        getitem_2027 = native_batch_norm_backward_default_175[2];  native_batch_norm_backward_default_175 = None
        convolution_backward_default_175 = torch.ops.aten.convolution_backward.default(getitem_2025, relu__default_124, primals_875, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2025 = primals_875 = None
        getitem_2028 = convolution_backward_default_175[0]
        getitem_2029 = convolution_backward_default_175[1]
        getitem_2030 = convolution_backward_default_175[2];  convolution_backward_default_175 = None
        add_tensor_161 = torch.ops.aten.add.Tensor(to_dtype_431, getitem_2028);  to_dtype_431 = getitem_2028 = None
        to_dtype_435 = torch.ops.aten.to.dtype(add_tensor_161, torch.float32);  add_tensor_161 = None
        to_dtype_436 = torch.ops.aten.to.dtype(relu__default_124, torch.float32);  relu__default_124 = None
        le_scalar_145 = torch.ops.aten.le.Scalar(to_dtype_436, 0);  to_dtype_436 = None
        new_zeros_default_470 = torch.ops.aten.new_zeros.default(to_dtype_435, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_145 = torch.ops.aten.where.self(le_scalar_145, new_zeros_default_470, to_dtype_435);  le_scalar_145 = new_zeros_default_470 = to_dtype_435 = None
        to_dtype_437 = torch.ops.aten.to.dtype(where_self_145, torch.float32);  where_self_145 = None
        native_batch_norm_backward_default_176 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_437, convolution_default_148, primals_862, primals_860, primals_861, getitem_445, getitem_446, True, 1e-05, [True, True, True]);  convolution_default_148 = primals_862 = primals_860 = primals_861 = getitem_445 = getitem_446 = None
        getitem_2031 = native_batch_norm_backward_default_176[0]
        getitem_2032 = native_batch_norm_backward_default_176[1]
        getitem_2033 = native_batch_norm_backward_default_176[2];  native_batch_norm_backward_default_176 = None
        convolution_backward_default_176 = torch.ops.aten.convolution_backward.default(getitem_2031, relu__default_123, primals_864, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2031 = primals_864 = None
        getitem_2034 = convolution_backward_default_176[0]
        getitem_2035 = convolution_backward_default_176[1]
        getitem_2036 = convolution_backward_default_176[2];  convolution_backward_default_176 = None
        to_dtype_438 = torch.ops.aten.to.dtype(getitem_2034, torch.float32);  getitem_2034 = None
        to_dtype_439 = torch.ops.aten.to.dtype(relu__default_123, torch.float32);  relu__default_123 = None
        le_scalar_146 = torch.ops.aten.le.Scalar(to_dtype_439, 0);  to_dtype_439 = None
        new_zeros_default_471 = torch.ops.aten.new_zeros.default(to_dtype_438, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_146 = torch.ops.aten.where.self(le_scalar_146, new_zeros_default_471, to_dtype_438);  le_scalar_146 = new_zeros_default_471 = to_dtype_438 = None
        to_dtype_440 = torch.ops.aten.to.dtype(where_self_146, torch.float32);  where_self_146 = None
        native_batch_norm_backward_default_177 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_440, convolution_default_147, primals_857, primals_855, primals_856, getitem_442, getitem_443, True, 1e-05, [True, True, True]);  to_dtype_440 = convolution_default_147 = primals_857 = primals_855 = primals_856 = getitem_442 = getitem_443 = None
        getitem_2037 = native_batch_norm_backward_default_177[0]
        getitem_2038 = native_batch_norm_backward_default_177[1]
        getitem_2039 = native_batch_norm_backward_default_177[2];  native_batch_norm_backward_default_177 = None
        convolution_backward_default_177 = torch.ops.aten.convolution_backward.default(getitem_2037, relu__default_122, primals_863, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2037 = primals_863 = None
        getitem_2040 = convolution_backward_default_177[0]
        getitem_2041 = convolution_backward_default_177[1]
        getitem_2042 = convolution_backward_default_177[2];  convolution_backward_default_177 = None
        add_tensor_162 = torch.ops.aten.add.Tensor(to_dtype_437, getitem_2040);  to_dtype_437 = getitem_2040 = None
        to_dtype_441 = torch.ops.aten.to.dtype(add_tensor_162, torch.float32);  add_tensor_162 = None
        to_dtype_442 = torch.ops.aten.to.dtype(relu__default_122, torch.float32);  relu__default_122 = None
        le_scalar_147 = torch.ops.aten.le.Scalar(to_dtype_442, 0);  to_dtype_442 = None
        new_zeros_default_472 = torch.ops.aten.new_zeros.default(to_dtype_441, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_147 = torch.ops.aten.where.self(le_scalar_147, new_zeros_default_472, to_dtype_441);  le_scalar_147 = new_zeros_default_472 = to_dtype_441 = None
        to_dtype_443 = torch.ops.aten.to.dtype(where_self_147, torch.float32);  where_self_147 = None
        native_batch_norm_backward_default_178 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_443, convolution_default_146, primals_850, primals_848, primals_849, getitem_439, getitem_440, True, 1e-05, [True, True, True]);  convolution_default_146 = primals_850 = primals_848 = primals_849 = getitem_439 = getitem_440 = None
        getitem_2043 = native_batch_norm_backward_default_178[0]
        getitem_2044 = native_batch_norm_backward_default_178[1]
        getitem_2045 = native_batch_norm_backward_default_178[2];  native_batch_norm_backward_default_178 = None
        convolution_backward_default_178 = torch.ops.aten.convolution_backward.default(getitem_2043, relu__default_121, primals_852, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2043 = primals_852 = None
        getitem_2046 = convolution_backward_default_178[0]
        getitem_2047 = convolution_backward_default_178[1]
        getitem_2048 = convolution_backward_default_178[2];  convolution_backward_default_178 = None
        to_dtype_444 = torch.ops.aten.to.dtype(getitem_2046, torch.float32);  getitem_2046 = None
        to_dtype_445 = torch.ops.aten.to.dtype(relu__default_121, torch.float32);  relu__default_121 = None
        le_scalar_148 = torch.ops.aten.le.Scalar(to_dtype_445, 0);  to_dtype_445 = None
        new_zeros_default_473 = torch.ops.aten.new_zeros.default(to_dtype_444, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_148 = torch.ops.aten.where.self(le_scalar_148, new_zeros_default_473, to_dtype_444);  le_scalar_148 = new_zeros_default_473 = to_dtype_444 = None
        to_dtype_446 = torch.ops.aten.to.dtype(where_self_148, torch.float32);  where_self_148 = None
        native_batch_norm_backward_default_179 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_446, convolution_default_145, primals_845, primals_843, primals_844, getitem_436, getitem_437, True, 1e-05, [True, True, True]);  to_dtype_446 = convolution_default_145 = primals_845 = primals_843 = primals_844 = getitem_436 = getitem_437 = None
        getitem_2049 = native_batch_norm_backward_default_179[0]
        getitem_2050 = native_batch_norm_backward_default_179[1]
        getitem_2051 = native_batch_norm_backward_default_179[2];  native_batch_norm_backward_default_179 = None
        convolution_backward_default_179 = torch.ops.aten.convolution_backward.default(getitem_2049, relu_default_13, primals_851, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2049 = primals_851 = None
        getitem_2052 = convolution_backward_default_179[0]
        getitem_2053 = convolution_backward_default_179[1]
        getitem_2054 = convolution_backward_default_179[2];  convolution_backward_default_179 = None
        add_tensor_163 = torch.ops.aten.add.Tensor(to_dtype_443, getitem_2052);  to_dtype_443 = getitem_2052 = None
        to_dtype_447 = torch.ops.aten.to.dtype(add_tensor_159, torch.float32);  add_tensor_159 = None
        to_dtype_448 = torch.ops.aten.to.dtype(relu__default_120, torch.float32);  relu__default_120 = None
        le_scalar_149 = torch.ops.aten.le.Scalar(to_dtype_448, 0);  to_dtype_448 = None
        new_zeros_default_474 = torch.ops.aten.new_zeros.default(to_dtype_447, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_149 = torch.ops.aten.where.self(le_scalar_149, new_zeros_default_474, to_dtype_447);  le_scalar_149 = new_zeros_default_474 = to_dtype_447 = None
        to_dtype_449 = torch.ops.aten.to.dtype(where_self_149, torch.float32);  where_self_149 = None
        native_batch_norm_backward_default_180 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_449, convolution_default_144, primals_838, primals_836, primals_837, getitem_433, getitem_434, True, 1e-05, [True, True, True]);  convolution_default_144 = primals_838 = primals_836 = primals_837 = getitem_433 = getitem_434 = None
        getitem_2055 = native_batch_norm_backward_default_180[0]
        getitem_2056 = native_batch_norm_backward_default_180[1]
        getitem_2057 = native_batch_norm_backward_default_180[2];  native_batch_norm_backward_default_180 = None
        convolution_backward_default_180 = torch.ops.aten.convolution_backward.default(getitem_2055, relu__default_119, primals_840, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2055 = primals_840 = None
        getitem_2058 = convolution_backward_default_180[0]
        getitem_2059 = convolution_backward_default_180[1]
        getitem_2060 = convolution_backward_default_180[2];  convolution_backward_default_180 = None
        to_dtype_450 = torch.ops.aten.to.dtype(getitem_2058, torch.float32);  getitem_2058 = None
        to_dtype_451 = torch.ops.aten.to.dtype(relu__default_119, torch.float32);  relu__default_119 = None
        le_scalar_150 = torch.ops.aten.le.Scalar(to_dtype_451, 0);  to_dtype_451 = None
        new_zeros_default_475 = torch.ops.aten.new_zeros.default(to_dtype_450, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_150 = torch.ops.aten.where.self(le_scalar_150, new_zeros_default_475, to_dtype_450);  le_scalar_150 = new_zeros_default_475 = to_dtype_450 = None
        to_dtype_452 = torch.ops.aten.to.dtype(where_self_150, torch.float32);  where_self_150 = None
        native_batch_norm_backward_default_181 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_452, convolution_default_143, primals_833, primals_831, primals_832, getitem_430, getitem_431, True, 1e-05, [True, True, True]);  to_dtype_452 = convolution_default_143 = primals_833 = primals_831 = primals_832 = getitem_430 = getitem_431 = None
        getitem_2061 = native_batch_norm_backward_default_181[0]
        getitem_2062 = native_batch_norm_backward_default_181[1]
        getitem_2063 = native_batch_norm_backward_default_181[2];  native_batch_norm_backward_default_181 = None
        convolution_backward_default_181 = torch.ops.aten.convolution_backward.default(getitem_2061, relu__default_118, primals_839, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2061 = primals_839 = None
        getitem_2064 = convolution_backward_default_181[0]
        getitem_2065 = convolution_backward_default_181[1]
        getitem_2066 = convolution_backward_default_181[2];  convolution_backward_default_181 = None
        add_tensor_164 = torch.ops.aten.add.Tensor(to_dtype_449, getitem_2064);  to_dtype_449 = getitem_2064 = None
        to_dtype_453 = torch.ops.aten.to.dtype(add_tensor_164, torch.float32);  add_tensor_164 = None
        to_dtype_454 = torch.ops.aten.to.dtype(relu__default_118, torch.float32);  relu__default_118 = None
        le_scalar_151 = torch.ops.aten.le.Scalar(to_dtype_454, 0);  to_dtype_454 = None
        new_zeros_default_476 = torch.ops.aten.new_zeros.default(to_dtype_453, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_151 = torch.ops.aten.where.self(le_scalar_151, new_zeros_default_476, to_dtype_453);  le_scalar_151 = new_zeros_default_476 = to_dtype_453 = None
        to_dtype_455 = torch.ops.aten.to.dtype(where_self_151, torch.float32);  where_self_151 = None
        native_batch_norm_backward_default_182 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_455, convolution_default_142, primals_826, primals_824, primals_825, getitem_427, getitem_428, True, 1e-05, [True, True, True]);  convolution_default_142 = primals_826 = primals_824 = primals_825 = getitem_427 = getitem_428 = None
        getitem_2067 = native_batch_norm_backward_default_182[0]
        getitem_2068 = native_batch_norm_backward_default_182[1]
        getitem_2069 = native_batch_norm_backward_default_182[2];  native_batch_norm_backward_default_182 = None
        convolution_backward_default_182 = torch.ops.aten.convolution_backward.default(getitem_2067, relu__default_117, primals_828, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2067 = primals_828 = None
        getitem_2070 = convolution_backward_default_182[0]
        getitem_2071 = convolution_backward_default_182[1]
        getitem_2072 = convolution_backward_default_182[2];  convolution_backward_default_182 = None
        to_dtype_456 = torch.ops.aten.to.dtype(getitem_2070, torch.float32);  getitem_2070 = None
        to_dtype_457 = torch.ops.aten.to.dtype(relu__default_117, torch.float32);  relu__default_117 = None
        le_scalar_152 = torch.ops.aten.le.Scalar(to_dtype_457, 0);  to_dtype_457 = None
        new_zeros_default_477 = torch.ops.aten.new_zeros.default(to_dtype_456, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_152 = torch.ops.aten.where.self(le_scalar_152, new_zeros_default_477, to_dtype_456);  le_scalar_152 = new_zeros_default_477 = to_dtype_456 = None
        to_dtype_458 = torch.ops.aten.to.dtype(where_self_152, torch.float32);  where_self_152 = None
        native_batch_norm_backward_default_183 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_458, convolution_default_141, primals_821, primals_819, primals_820, getitem_424, getitem_425, True, 1e-05, [True, True, True]);  to_dtype_458 = convolution_default_141 = primals_821 = primals_819 = primals_820 = getitem_424 = getitem_425 = None
        getitem_2073 = native_batch_norm_backward_default_183[0]
        getitem_2074 = native_batch_norm_backward_default_183[1]
        getitem_2075 = native_batch_norm_backward_default_183[2];  native_batch_norm_backward_default_183 = None
        convolution_backward_default_183 = torch.ops.aten.convolution_backward.default(getitem_2073, relu__default_116, primals_827, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2073 = primals_827 = None
        getitem_2076 = convolution_backward_default_183[0]
        getitem_2077 = convolution_backward_default_183[1]
        getitem_2078 = convolution_backward_default_183[2];  convolution_backward_default_183 = None
        add_tensor_165 = torch.ops.aten.add.Tensor(to_dtype_455, getitem_2076);  to_dtype_455 = getitem_2076 = None
        to_dtype_459 = torch.ops.aten.to.dtype(add_tensor_165, torch.float32);  add_tensor_165 = None
        to_dtype_460 = torch.ops.aten.to.dtype(relu__default_116, torch.float32);  relu__default_116 = None
        le_scalar_153 = torch.ops.aten.le.Scalar(to_dtype_460, 0);  to_dtype_460 = None
        new_zeros_default_478 = torch.ops.aten.new_zeros.default(to_dtype_459, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_153 = torch.ops.aten.where.self(le_scalar_153, new_zeros_default_478, to_dtype_459);  le_scalar_153 = new_zeros_default_478 = to_dtype_459 = None
        to_dtype_461 = torch.ops.aten.to.dtype(where_self_153, torch.float32);  where_self_153 = None
        native_batch_norm_backward_default_184 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_461, convolution_default_140, primals_814, primals_812, primals_813, getitem_421, getitem_422, True, 1e-05, [True, True, True]);  convolution_default_140 = primals_814 = primals_812 = primals_813 = getitem_421 = getitem_422 = None
        getitem_2079 = native_batch_norm_backward_default_184[0]
        getitem_2080 = native_batch_norm_backward_default_184[1]
        getitem_2081 = native_batch_norm_backward_default_184[2];  native_batch_norm_backward_default_184 = None
        convolution_backward_default_184 = torch.ops.aten.convolution_backward.default(getitem_2079, relu__default_115, primals_816, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2079 = primals_816 = None
        getitem_2082 = convolution_backward_default_184[0]
        getitem_2083 = convolution_backward_default_184[1]
        getitem_2084 = convolution_backward_default_184[2];  convolution_backward_default_184 = None
        to_dtype_462 = torch.ops.aten.to.dtype(getitem_2082, torch.float32);  getitem_2082 = None
        to_dtype_463 = torch.ops.aten.to.dtype(relu__default_115, torch.float32);  relu__default_115 = None
        le_scalar_154 = torch.ops.aten.le.Scalar(to_dtype_463, 0);  to_dtype_463 = None
        new_zeros_default_479 = torch.ops.aten.new_zeros.default(to_dtype_462, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_154 = torch.ops.aten.where.self(le_scalar_154, new_zeros_default_479, to_dtype_462);  le_scalar_154 = new_zeros_default_479 = to_dtype_462 = None
        to_dtype_464 = torch.ops.aten.to.dtype(where_self_154, torch.float32);  where_self_154 = None
        native_batch_norm_backward_default_185 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_464, convolution_default_139, primals_809, primals_807, primals_808, getitem_418, getitem_419, True, 1e-05, [True, True, True]);  to_dtype_464 = convolution_default_139 = primals_809 = primals_807 = primals_808 = getitem_418 = getitem_419 = None
        getitem_2085 = native_batch_norm_backward_default_185[0]
        getitem_2086 = native_batch_norm_backward_default_185[1]
        getitem_2087 = native_batch_norm_backward_default_185[2];  native_batch_norm_backward_default_185 = None
        convolution_backward_default_185 = torch.ops.aten.convolution_backward.default(getitem_2085, relu__default_114, primals_815, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2085 = primals_815 = None
        getitem_2088 = convolution_backward_default_185[0]
        getitem_2089 = convolution_backward_default_185[1]
        getitem_2090 = convolution_backward_default_185[2];  convolution_backward_default_185 = None
        add_tensor_166 = torch.ops.aten.add.Tensor(to_dtype_461, getitem_2088);  to_dtype_461 = getitem_2088 = None
        to_dtype_465 = torch.ops.aten.to.dtype(add_tensor_166, torch.float32);  add_tensor_166 = None
        to_dtype_466 = torch.ops.aten.to.dtype(relu__default_114, torch.float32);  relu__default_114 = None
        le_scalar_155 = torch.ops.aten.le.Scalar(to_dtype_466, 0);  to_dtype_466 = None
        new_zeros_default_480 = torch.ops.aten.new_zeros.default(to_dtype_465, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_155 = torch.ops.aten.where.self(le_scalar_155, new_zeros_default_480, to_dtype_465);  le_scalar_155 = new_zeros_default_480 = to_dtype_465 = None
        to_dtype_467 = torch.ops.aten.to.dtype(where_self_155, torch.float32);  where_self_155 = None
        native_batch_norm_backward_default_186 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_467, convolution_default_138, primals_802, primals_800, primals_801, getitem_415, getitem_416, True, 1e-05, [True, True, True]);  convolution_default_138 = primals_802 = primals_800 = primals_801 = getitem_415 = getitem_416 = None
        getitem_2091 = native_batch_norm_backward_default_186[0]
        getitem_2092 = native_batch_norm_backward_default_186[1]
        getitem_2093 = native_batch_norm_backward_default_186[2];  native_batch_norm_backward_default_186 = None
        convolution_backward_default_186 = torch.ops.aten.convolution_backward.default(getitem_2091, relu__default_113, primals_804, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2091 = primals_804 = None
        getitem_2094 = convolution_backward_default_186[0]
        getitem_2095 = convolution_backward_default_186[1]
        getitem_2096 = convolution_backward_default_186[2];  convolution_backward_default_186 = None
        to_dtype_468 = torch.ops.aten.to.dtype(getitem_2094, torch.float32);  getitem_2094 = None
        to_dtype_469 = torch.ops.aten.to.dtype(relu__default_113, torch.float32);  relu__default_113 = None
        le_scalar_156 = torch.ops.aten.le.Scalar(to_dtype_469, 0);  to_dtype_469 = None
        new_zeros_default_481 = torch.ops.aten.new_zeros.default(to_dtype_468, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_156 = torch.ops.aten.where.self(le_scalar_156, new_zeros_default_481, to_dtype_468);  le_scalar_156 = new_zeros_default_481 = to_dtype_468 = None
        to_dtype_470 = torch.ops.aten.to.dtype(where_self_156, torch.float32);  where_self_156 = None
        native_batch_norm_backward_default_187 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_470, convolution_default_137, primals_797, primals_795, primals_796, getitem_412, getitem_413, True, 1e-05, [True, True, True]);  to_dtype_470 = convolution_default_137 = primals_797 = primals_795 = primals_796 = getitem_412 = getitem_413 = None
        getitem_2097 = native_batch_norm_backward_default_187[0]
        getitem_2098 = native_batch_norm_backward_default_187[1]
        getitem_2099 = native_batch_norm_backward_default_187[2];  native_batch_norm_backward_default_187 = None
        convolution_backward_default_187 = torch.ops.aten.convolution_backward.default(getitem_2097, relu_default_11, primals_803, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2097 = primals_803 = None
        getitem_2100 = convolution_backward_default_187[0]
        getitem_2101 = convolution_backward_default_187[1]
        getitem_2102 = convolution_backward_default_187[2];  convolution_backward_default_187 = None
        add_tensor_167 = torch.ops.aten.add.Tensor(to_dtype_467, getitem_2100);  to_dtype_467 = getitem_2100 = None
        to_dtype_471 = torch.ops.aten.to.dtype(add_tensor_158, torch.float32);  add_tensor_158 = None
        to_dtype_472 = torch.ops.aten.to.dtype(relu__default_112, torch.float32);  relu__default_112 = None
        le_scalar_157 = torch.ops.aten.le.Scalar(to_dtype_472, 0);  to_dtype_472 = None
        new_zeros_default_482 = torch.ops.aten.new_zeros.default(to_dtype_471, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_157 = torch.ops.aten.where.self(le_scalar_157, new_zeros_default_482, to_dtype_471);  le_scalar_157 = new_zeros_default_482 = to_dtype_471 = None
        to_dtype_473 = torch.ops.aten.to.dtype(where_self_157, torch.float32);  where_self_157 = None
        native_batch_norm_backward_default_188 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_473, convolution_default_136, primals_790, primals_788, primals_789, getitem_409, getitem_410, True, 1e-05, [True, True, True]);  convolution_default_136 = primals_790 = primals_788 = primals_789 = getitem_409 = getitem_410 = None
        getitem_2103 = native_batch_norm_backward_default_188[0]
        getitem_2104 = native_batch_norm_backward_default_188[1]
        getitem_2105 = native_batch_norm_backward_default_188[2];  native_batch_norm_backward_default_188 = None
        convolution_backward_default_188 = torch.ops.aten.convolution_backward.default(getitem_2103, relu__default_111, primals_792, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2103 = primals_792 = None
        getitem_2106 = convolution_backward_default_188[0]
        getitem_2107 = convolution_backward_default_188[1]
        getitem_2108 = convolution_backward_default_188[2];  convolution_backward_default_188 = None
        to_dtype_474 = torch.ops.aten.to.dtype(getitem_2106, torch.float32);  getitem_2106 = None
        to_dtype_475 = torch.ops.aten.to.dtype(relu__default_111, torch.float32);  relu__default_111 = None
        le_scalar_158 = torch.ops.aten.le.Scalar(to_dtype_475, 0);  to_dtype_475 = None
        new_zeros_default_483 = torch.ops.aten.new_zeros.default(to_dtype_474, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_158 = torch.ops.aten.where.self(le_scalar_158, new_zeros_default_483, to_dtype_474);  le_scalar_158 = new_zeros_default_483 = to_dtype_474 = None
        to_dtype_476 = torch.ops.aten.to.dtype(where_self_158, torch.float32);  where_self_158 = None
        native_batch_norm_backward_default_189 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_476, convolution_default_135, primals_785, primals_783, primals_784, getitem_406, getitem_407, True, 1e-05, [True, True, True]);  to_dtype_476 = convolution_default_135 = primals_785 = primals_783 = primals_784 = getitem_406 = getitem_407 = None
        getitem_2109 = native_batch_norm_backward_default_189[0]
        getitem_2110 = native_batch_norm_backward_default_189[1]
        getitem_2111 = native_batch_norm_backward_default_189[2];  native_batch_norm_backward_default_189 = None
        convolution_backward_default_189 = torch.ops.aten.convolution_backward.default(getitem_2109, relu__default_110, primals_791, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2109 = primals_791 = None
        getitem_2112 = convolution_backward_default_189[0]
        getitem_2113 = convolution_backward_default_189[1]
        getitem_2114 = convolution_backward_default_189[2];  convolution_backward_default_189 = None
        add_tensor_168 = torch.ops.aten.add.Tensor(to_dtype_473, getitem_2112);  to_dtype_473 = getitem_2112 = None
        to_dtype_477 = torch.ops.aten.to.dtype(add_tensor_168, torch.float32);  add_tensor_168 = None
        to_dtype_478 = torch.ops.aten.to.dtype(relu__default_110, torch.float32);  relu__default_110 = None
        le_scalar_159 = torch.ops.aten.le.Scalar(to_dtype_478, 0);  to_dtype_478 = None
        new_zeros_default_484 = torch.ops.aten.new_zeros.default(to_dtype_477, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_159 = torch.ops.aten.where.self(le_scalar_159, new_zeros_default_484, to_dtype_477);  le_scalar_159 = new_zeros_default_484 = to_dtype_477 = None
        to_dtype_479 = torch.ops.aten.to.dtype(where_self_159, torch.float32);  where_self_159 = None
        native_batch_norm_backward_default_190 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_479, convolution_default_134, primals_778, primals_776, primals_777, getitem_403, getitem_404, True, 1e-05, [True, True, True]);  convolution_default_134 = primals_778 = primals_776 = primals_777 = getitem_403 = getitem_404 = None
        getitem_2115 = native_batch_norm_backward_default_190[0]
        getitem_2116 = native_batch_norm_backward_default_190[1]
        getitem_2117 = native_batch_norm_backward_default_190[2];  native_batch_norm_backward_default_190 = None
        convolution_backward_default_190 = torch.ops.aten.convolution_backward.default(getitem_2115, relu__default_109, primals_780, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2115 = primals_780 = None
        getitem_2118 = convolution_backward_default_190[0]
        getitem_2119 = convolution_backward_default_190[1]
        getitem_2120 = convolution_backward_default_190[2];  convolution_backward_default_190 = None
        to_dtype_480 = torch.ops.aten.to.dtype(getitem_2118, torch.float32);  getitem_2118 = None
        to_dtype_481 = torch.ops.aten.to.dtype(relu__default_109, torch.float32);  relu__default_109 = None
        le_scalar_160 = torch.ops.aten.le.Scalar(to_dtype_481, 0);  to_dtype_481 = None
        new_zeros_default_485 = torch.ops.aten.new_zeros.default(to_dtype_480, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_160 = torch.ops.aten.where.self(le_scalar_160, new_zeros_default_485, to_dtype_480);  le_scalar_160 = new_zeros_default_485 = to_dtype_480 = None
        to_dtype_482 = torch.ops.aten.to.dtype(where_self_160, torch.float32);  where_self_160 = None
        native_batch_norm_backward_default_191 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_482, convolution_default_133, primals_773, primals_771, primals_772, getitem_400, getitem_401, True, 1e-05, [True, True, True]);  to_dtype_482 = convolution_default_133 = primals_773 = primals_771 = primals_772 = getitem_400 = getitem_401 = None
        getitem_2121 = native_batch_norm_backward_default_191[0]
        getitem_2122 = native_batch_norm_backward_default_191[1]
        getitem_2123 = native_batch_norm_backward_default_191[2];  native_batch_norm_backward_default_191 = None
        convolution_backward_default_191 = torch.ops.aten.convolution_backward.default(getitem_2121, relu__default_108, primals_779, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2121 = primals_779 = None
        getitem_2124 = convolution_backward_default_191[0]
        getitem_2125 = convolution_backward_default_191[1]
        getitem_2126 = convolution_backward_default_191[2];  convolution_backward_default_191 = None
        add_tensor_169 = torch.ops.aten.add.Tensor(to_dtype_479, getitem_2124);  to_dtype_479 = getitem_2124 = None
        to_dtype_483 = torch.ops.aten.to.dtype(add_tensor_169, torch.float32);  add_tensor_169 = None
        to_dtype_484 = torch.ops.aten.to.dtype(relu__default_108, torch.float32);  relu__default_108 = None
        le_scalar_161 = torch.ops.aten.le.Scalar(to_dtype_484, 0);  to_dtype_484 = None
        new_zeros_default_486 = torch.ops.aten.new_zeros.default(to_dtype_483, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_161 = torch.ops.aten.where.self(le_scalar_161, new_zeros_default_486, to_dtype_483);  le_scalar_161 = new_zeros_default_486 = to_dtype_483 = None
        to_dtype_485 = torch.ops.aten.to.dtype(where_self_161, torch.float32);  where_self_161 = None
        native_batch_norm_backward_default_192 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_485, convolution_default_132, primals_766, primals_764, primals_765, getitem_397, getitem_398, True, 1e-05, [True, True, True]);  convolution_default_132 = primals_766 = primals_764 = primals_765 = getitem_397 = getitem_398 = None
        getitem_2127 = native_batch_norm_backward_default_192[0]
        getitem_2128 = native_batch_norm_backward_default_192[1]
        getitem_2129 = native_batch_norm_backward_default_192[2];  native_batch_norm_backward_default_192 = None
        convolution_backward_default_192 = torch.ops.aten.convolution_backward.default(getitem_2127, relu__default_107, primals_768, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2127 = primals_768 = None
        getitem_2130 = convolution_backward_default_192[0]
        getitem_2131 = convolution_backward_default_192[1]
        getitem_2132 = convolution_backward_default_192[2];  convolution_backward_default_192 = None
        to_dtype_486 = torch.ops.aten.to.dtype(getitem_2130, torch.float32);  getitem_2130 = None
        to_dtype_487 = torch.ops.aten.to.dtype(relu__default_107, torch.float32);  relu__default_107 = None
        le_scalar_162 = torch.ops.aten.le.Scalar(to_dtype_487, 0);  to_dtype_487 = None
        new_zeros_default_487 = torch.ops.aten.new_zeros.default(to_dtype_486, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_162 = torch.ops.aten.where.self(le_scalar_162, new_zeros_default_487, to_dtype_486);  le_scalar_162 = new_zeros_default_487 = to_dtype_486 = None
        to_dtype_488 = torch.ops.aten.to.dtype(where_self_162, torch.float32);  where_self_162 = None
        native_batch_norm_backward_default_193 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_488, convolution_default_131, primals_761, primals_759, primals_760, getitem_394, getitem_395, True, 1e-05, [True, True, True]);  to_dtype_488 = convolution_default_131 = primals_761 = primals_759 = primals_760 = getitem_394 = getitem_395 = None
        getitem_2133 = native_batch_norm_backward_default_193[0]
        getitem_2134 = native_batch_norm_backward_default_193[1]
        getitem_2135 = native_batch_norm_backward_default_193[2];  native_batch_norm_backward_default_193 = None
        convolution_backward_default_193 = torch.ops.aten.convolution_backward.default(getitem_2133, relu__default_106, primals_767, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2133 = primals_767 = None
        getitem_2136 = convolution_backward_default_193[0]
        getitem_2137 = convolution_backward_default_193[1]
        getitem_2138 = convolution_backward_default_193[2];  convolution_backward_default_193 = None
        add_tensor_170 = torch.ops.aten.add.Tensor(to_dtype_485, getitem_2136);  to_dtype_485 = getitem_2136 = None
        to_dtype_489 = torch.ops.aten.to.dtype(add_tensor_170, torch.float32);  add_tensor_170 = None
        to_dtype_490 = torch.ops.aten.to.dtype(relu__default_106, torch.float32);  relu__default_106 = None
        le_scalar_163 = torch.ops.aten.le.Scalar(to_dtype_490, 0);  to_dtype_490 = None
        new_zeros_default_488 = torch.ops.aten.new_zeros.default(to_dtype_489, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_163 = torch.ops.aten.where.self(le_scalar_163, new_zeros_default_488, to_dtype_489);  le_scalar_163 = new_zeros_default_488 = to_dtype_489 = None
        to_dtype_491 = torch.ops.aten.to.dtype(where_self_163, torch.float32);  where_self_163 = None
        native_batch_norm_backward_default_194 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_491, convolution_default_130, primals_754, primals_752, primals_753, getitem_391, getitem_392, True, 1e-05, [True, True, True]);  convolution_default_130 = primals_754 = primals_752 = primals_753 = getitem_391 = getitem_392 = None
        getitem_2139 = native_batch_norm_backward_default_194[0]
        getitem_2140 = native_batch_norm_backward_default_194[1]
        getitem_2141 = native_batch_norm_backward_default_194[2];  native_batch_norm_backward_default_194 = None
        convolution_backward_default_194 = torch.ops.aten.convolution_backward.default(getitem_2139, relu__default_105, primals_756, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2139 = primals_756 = None
        getitem_2142 = convolution_backward_default_194[0]
        getitem_2143 = convolution_backward_default_194[1]
        getitem_2144 = convolution_backward_default_194[2];  convolution_backward_default_194 = None
        to_dtype_492 = torch.ops.aten.to.dtype(getitem_2142, torch.float32);  getitem_2142 = None
        to_dtype_493 = torch.ops.aten.to.dtype(relu__default_105, torch.float32);  relu__default_105 = None
        le_scalar_164 = torch.ops.aten.le.Scalar(to_dtype_493, 0);  to_dtype_493 = None
        new_zeros_default_489 = torch.ops.aten.new_zeros.default(to_dtype_492, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_164 = torch.ops.aten.where.self(le_scalar_164, new_zeros_default_489, to_dtype_492);  le_scalar_164 = new_zeros_default_489 = to_dtype_492 = None
        to_dtype_494 = torch.ops.aten.to.dtype(where_self_164, torch.float32);  where_self_164 = None
        native_batch_norm_backward_default_195 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_494, convolution_default_129, primals_749, primals_747, primals_748, getitem_388, getitem_389, True, 1e-05, [True, True, True]);  to_dtype_494 = convolution_default_129 = primals_749 = primals_747 = primals_748 = getitem_388 = getitem_389 = None
        getitem_2145 = native_batch_norm_backward_default_195[0]
        getitem_2146 = native_batch_norm_backward_default_195[1]
        getitem_2147 = native_batch_norm_backward_default_195[2];  native_batch_norm_backward_default_195 = None
        convolution_backward_default_195 = torch.ops.aten.convolution_backward.default(getitem_2145, relu_default_10, primals_755, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2145 = primals_755 = None
        getitem_2148 = convolution_backward_default_195[0]
        getitem_2149 = convolution_backward_default_195[1]
        getitem_2150 = convolution_backward_default_195[2];  convolution_backward_default_195 = None
        add_tensor_171 = torch.ops.aten.add.Tensor(to_dtype_491, getitem_2148);  to_dtype_491 = getitem_2148 = None
        to_dtype_495 = torch.ops.aten.to.dtype(add_tensor_163, torch.float32);  add_tensor_163 = None
        to_dtype_496 = torch.ops.aten.to.dtype(relu_default_13, torch.float32);  relu_default_13 = None
        le_scalar_165 = torch.ops.aten.le.Scalar(to_dtype_496, 0);  to_dtype_496 = None
        new_zeros_default_490 = torch.ops.aten.new_zeros.default(to_dtype_495, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_165 = torch.ops.aten.where.self(le_scalar_165, new_zeros_default_490, to_dtype_495);  le_scalar_165 = new_zeros_default_490 = to_dtype_495 = None
        to_dtype_497 = torch.ops.aten.to.dtype(where_self_165, torch.float32);  where_self_165 = None
        native_batch_norm_backward_default_196 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_497, convolution_default_128, primals_1794, primals_1792, primals_1793, getitem_385, getitem_386, True, 1e-05, [True, True, True]);  convolution_default_128 = primals_1794 = primals_1792 = primals_1793 = getitem_385 = getitem_386 = None
        getitem_2151 = native_batch_norm_backward_default_196[0]
        getitem_2152 = native_batch_norm_backward_default_196[1]
        getitem_2153 = native_batch_norm_backward_default_196[2];  native_batch_norm_backward_default_196 = None
        convolution_backward_default_196 = torch.ops.aten.convolution_backward.default(getitem_2151, relu__default_96, primals_1789, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2151 = primals_1789 = None
        getitem_2154 = convolution_backward_default_196[0]
        getitem_2155 = convolution_backward_default_196[1]
        getitem_2156 = convolution_backward_default_196[2];  convolution_backward_default_196 = None
        native_batch_norm_backward_default_197 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_497, convolution_default_127, primals_1650, primals_1648, primals_1649, getitem_382, getitem_383, True, 1e-05, [True, True, True]);  convolution_default_127 = primals_1650 = primals_1648 = primals_1649 = getitem_382 = getitem_383 = None
        getitem_2157 = native_batch_norm_backward_default_197[0]
        getitem_2158 = native_batch_norm_backward_default_197[1]
        getitem_2159 = native_batch_norm_backward_default_197[2];  native_batch_norm_backward_default_197 = None
        convolution_backward_default_197 = torch.ops.aten.convolution_backward.default(getitem_2157, relu_default_12, primals_1645, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2157 = primals_1645 = None
        getitem_2160 = convolution_backward_default_197[0]
        getitem_2161 = convolution_backward_default_197[1]
        getitem_2162 = convolution_backward_default_197[2];  convolution_backward_default_197 = None
        to_dtype_498 = torch.ops.aten.to.dtype(getitem_2160, torch.float32);  getitem_2160 = None
        to_dtype_499 = torch.ops.aten.to.dtype(relu_default_12, torch.float32);  relu_default_12 = None
        le_scalar_166 = torch.ops.aten.le.Scalar(to_dtype_499, 0);  to_dtype_499 = None
        new_zeros_default_491 = torch.ops.aten.new_zeros.default(to_dtype_498, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_166 = torch.ops.aten.where.self(le_scalar_166, new_zeros_default_491, to_dtype_498);  le_scalar_166 = new_zeros_default_491 = to_dtype_498 = None
        to_dtype_500 = torch.ops.aten.to.dtype(where_self_166, torch.float32);  where_self_166 = None
        native_batch_norm_backward_default_198 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_500, convolution_default_126, primals_1644, primals_1642, primals_1643, getitem_379, getitem_380, True, 1e-05, [True, True, True]);  to_dtype_500 = convolution_default_126 = primals_1644 = primals_1642 = primals_1643 = getitem_379 = getitem_380 = None
        getitem_2163 = native_batch_norm_backward_default_198[0]
        getitem_2164 = native_batch_norm_backward_default_198[1]
        getitem_2165 = native_batch_norm_backward_default_198[2];  native_batch_norm_backward_default_198 = None
        convolution_backward_default_198 = torch.ops.aten.convolution_backward.default(getitem_2163, relu__default_88, primals_1639, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2163 = primals_1639 = None
        getitem_2166 = convolution_backward_default_198[0]
        getitem_2167 = convolution_backward_default_198[1]
        getitem_2168 = convolution_backward_default_198[2];  convolution_backward_default_198 = None
        to_dtype_501 = torch.ops.aten.to.dtype(add_tensor_167, torch.float32);  add_tensor_167 = None
        to_dtype_502 = torch.ops.aten.to.dtype(relu_default_11, torch.float32);  relu_default_11 = None
        le_scalar_167 = torch.ops.aten.le.Scalar(to_dtype_502, 0);  to_dtype_502 = None
        new_zeros_default_492 = torch.ops.aten.new_zeros.default(to_dtype_501, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_167 = torch.ops.aten.where.self(le_scalar_167, new_zeros_default_492, to_dtype_501);  le_scalar_167 = new_zeros_default_492 = to_dtype_501 = None
        to_dtype_503 = torch.ops.aten.to.dtype(where_self_167, torch.float32);  where_self_167 = None
        upsample_nearest2d_backward_vec_21 = torch.ops.aten.upsample_nearest2d_backward.vec(to_dtype_503, None, [128, 36, 14, 14], [2.0, 2.0])
        native_batch_norm_backward_default_199 = torch.ops.aten.native_batch_norm_backward.default(upsample_nearest2d_backward_vec_21, convolution_default_125, primals_1890, primals_1888, primals_1889, getitem_376, getitem_377, True, 1e-05, [True, True, True]);  upsample_nearest2d_backward_vec_21 = convolution_default_125 = primals_1890 = primals_1888 = primals_1889 = getitem_376 = getitem_377 = None
        getitem_2169 = native_batch_norm_backward_default_199[0]
        getitem_2170 = native_batch_norm_backward_default_199[1]
        getitem_2171 = native_batch_norm_backward_default_199[2];  native_batch_norm_backward_default_199 = None
        convolution_backward_default_199 = torch.ops.aten.convolution_backward.default(getitem_2169, relu__default_104, primals_1885, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2169 = primals_1885 = None
        getitem_2172 = convolution_backward_default_199[0]
        getitem_2173 = convolution_backward_default_199[1]
        getitem_2174 = convolution_backward_default_199[2];  convolution_backward_default_199 = None
        add_tensor_172 = torch.ops.aten.add.Tensor(to_dtype_497, getitem_2172);  to_dtype_497 = getitem_2172 = None
        add_tensor_173 = torch.ops.aten.add.Tensor(getitem_2154, to_dtype_503);  getitem_2154 = None
        native_batch_norm_backward_default_200 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_503, convolution_default_124, primals_1638, primals_1636, primals_1637, getitem_373, getitem_374, True, 1e-05, [True, True, True]);  to_dtype_503 = convolution_default_124 = primals_1638 = primals_1636 = primals_1637 = getitem_373 = getitem_374 = None
        getitem_2175 = native_batch_norm_backward_default_200[0]
        getitem_2176 = native_batch_norm_backward_default_200[1]
        getitem_2177 = native_batch_norm_backward_default_200[2];  native_batch_norm_backward_default_200 = None
        convolution_backward_default_200 = torch.ops.aten.convolution_backward.default(getitem_2175, relu__default_88, primals_1633, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2175 = primals_1633 = None
        getitem_2178 = convolution_backward_default_200[0]
        getitem_2179 = convolution_backward_default_200[1]
        getitem_2180 = convolution_backward_default_200[2];  convolution_backward_default_200 = None
        add_tensor_174 = torch.ops.aten.add.Tensor(getitem_2166, getitem_2178);  getitem_2166 = getitem_2178 = None
        to_dtype_504 = torch.ops.aten.to.dtype(add_tensor_171, torch.float32);  add_tensor_171 = None
        to_dtype_505 = torch.ops.aten.to.dtype(relu_default_10, torch.float32);  relu_default_10 = None
        le_scalar_168 = torch.ops.aten.le.Scalar(to_dtype_505, 0);  to_dtype_505 = None
        new_zeros_default_493 = torch.ops.aten.new_zeros.default(to_dtype_504, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_168 = torch.ops.aten.where.self(le_scalar_168, new_zeros_default_493, to_dtype_504);  le_scalar_168 = new_zeros_default_493 = to_dtype_504 = None
        to_dtype_506 = torch.ops.aten.to.dtype(where_self_168, torch.float32);  where_self_168 = None
        upsample_nearest2d_backward_vec_22 = torch.ops.aten.upsample_nearest2d_backward.vec(to_dtype_506, None, [128, 18, 14, 14], [4.0, 4.0])
        native_batch_norm_backward_default_201 = torch.ops.aten.native_batch_norm_backward.default(upsample_nearest2d_backward_vec_22, convolution_default_123, primals_1884, primals_1882, primals_1883, getitem_370, getitem_371, True, 1e-05, [True, True, True]);  upsample_nearest2d_backward_vec_22 = convolution_default_123 = primals_1884 = primals_1882 = primals_1883 = getitem_370 = getitem_371 = None
        getitem_2181 = native_batch_norm_backward_default_201[0]
        getitem_2182 = native_batch_norm_backward_default_201[1]
        getitem_2183 = native_batch_norm_backward_default_201[2];  native_batch_norm_backward_default_201 = None
        convolution_backward_default_201 = torch.ops.aten.convolution_backward.default(getitem_2181, relu__default_104, primals_1879, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2181 = primals_1879 = None
        getitem_2184 = convolution_backward_default_201[0]
        getitem_2185 = convolution_backward_default_201[1]
        getitem_2186 = convolution_backward_default_201[2];  convolution_backward_default_201 = None
        add_tensor_175 = torch.ops.aten.add.Tensor(add_tensor_172, getitem_2184);  add_tensor_172 = getitem_2184 = None
        add_tensor_176 = torch.ops.aten.add.Tensor(add_tensor_174, to_dtype_506);  add_tensor_174 = None
        upsample_nearest2d_backward_vec_23 = torch.ops.aten.upsample_nearest2d_backward.vec(to_dtype_506, None, [128, 18, 28, 28], [2.0, 2.0]);  to_dtype_506 = None
        native_batch_norm_backward_default_202 = torch.ops.aten.native_batch_norm_backward.default(upsample_nearest2d_backward_vec_23, convolution_default_122, primals_1788, primals_1786, primals_1787, getitem_367, getitem_368, True, 1e-05, [True, True, True]);  upsample_nearest2d_backward_vec_23 = convolution_default_122 = primals_1788 = primals_1786 = primals_1787 = getitem_367 = getitem_368 = None
        getitem_2187 = native_batch_norm_backward_default_202[0]
        getitem_2188 = native_batch_norm_backward_default_202[1]
        getitem_2189 = native_batch_norm_backward_default_202[2];  native_batch_norm_backward_default_202 = None
        convolution_backward_default_202 = torch.ops.aten.convolution_backward.default(getitem_2187, relu__default_96, primals_1783, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2187 = primals_1783 = None
        getitem_2190 = convolution_backward_default_202[0]
        getitem_2191 = convolution_backward_default_202[1]
        getitem_2192 = convolution_backward_default_202[2];  convolution_backward_default_202 = None
        add_tensor_177 = torch.ops.aten.add.Tensor(add_tensor_173, getitem_2190);  add_tensor_173 = getitem_2190 = None
        to_dtype_507 = torch.ops.aten.to.dtype(add_tensor_175, torch.float32);  add_tensor_175 = None
        to_dtype_508 = torch.ops.aten.to.dtype(relu__default_104, torch.float32);  relu__default_104 = None
        le_scalar_169 = torch.ops.aten.le.Scalar(to_dtype_508, 0);  to_dtype_508 = None
        new_zeros_default_494 = torch.ops.aten.new_zeros.default(to_dtype_507, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_169 = torch.ops.aten.where.self(le_scalar_169, new_zeros_default_494, to_dtype_507);  le_scalar_169 = new_zeros_default_494 = to_dtype_507 = None
        to_dtype_509 = torch.ops.aten.to.dtype(where_self_169, torch.float32);  where_self_169 = None
        native_batch_norm_backward_default_203 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_509, convolution_default_121, primals_742, primals_740, primals_741, getitem_364, getitem_365, True, 1e-05, [True, True, True]);  convolution_default_121 = primals_742 = primals_740 = primals_741 = getitem_364 = getitem_365 = None
        getitem_2193 = native_batch_norm_backward_default_203[0]
        getitem_2194 = native_batch_norm_backward_default_203[1]
        getitem_2195 = native_batch_norm_backward_default_203[2];  native_batch_norm_backward_default_203 = None
        convolution_backward_default_203 = torch.ops.aten.convolution_backward.default(getitem_2193, relu__default_103, primals_744, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2193 = primals_744 = None
        getitem_2196 = convolution_backward_default_203[0]
        getitem_2197 = convolution_backward_default_203[1]
        getitem_2198 = convolution_backward_default_203[2];  convolution_backward_default_203 = None
        to_dtype_510 = torch.ops.aten.to.dtype(getitem_2196, torch.float32);  getitem_2196 = None
        to_dtype_511 = torch.ops.aten.to.dtype(relu__default_103, torch.float32);  relu__default_103 = None
        le_scalar_170 = torch.ops.aten.le.Scalar(to_dtype_511, 0);  to_dtype_511 = None
        new_zeros_default_495 = torch.ops.aten.new_zeros.default(to_dtype_510, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_170 = torch.ops.aten.where.self(le_scalar_170, new_zeros_default_495, to_dtype_510);  le_scalar_170 = new_zeros_default_495 = to_dtype_510 = None
        to_dtype_512 = torch.ops.aten.to.dtype(where_self_170, torch.float32);  where_self_170 = None
        native_batch_norm_backward_default_204 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_512, convolution_default_120, primals_737, primals_735, primals_736, getitem_361, getitem_362, True, 1e-05, [True, True, True]);  to_dtype_512 = convolution_default_120 = primals_737 = primals_735 = primals_736 = getitem_361 = getitem_362 = None
        getitem_2199 = native_batch_norm_backward_default_204[0]
        getitem_2200 = native_batch_norm_backward_default_204[1]
        getitem_2201 = native_batch_norm_backward_default_204[2];  native_batch_norm_backward_default_204 = None
        convolution_backward_default_204 = torch.ops.aten.convolution_backward.default(getitem_2199, relu__default_102, primals_743, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2199 = primals_743 = None
        getitem_2202 = convolution_backward_default_204[0]
        getitem_2203 = convolution_backward_default_204[1]
        getitem_2204 = convolution_backward_default_204[2];  convolution_backward_default_204 = None
        add_tensor_178 = torch.ops.aten.add.Tensor(to_dtype_509, getitem_2202);  to_dtype_509 = getitem_2202 = None
        to_dtype_513 = torch.ops.aten.to.dtype(add_tensor_178, torch.float32);  add_tensor_178 = None
        to_dtype_514 = torch.ops.aten.to.dtype(relu__default_102, torch.float32);  relu__default_102 = None
        le_scalar_171 = torch.ops.aten.le.Scalar(to_dtype_514, 0);  to_dtype_514 = None
        new_zeros_default_496 = torch.ops.aten.new_zeros.default(to_dtype_513, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_171 = torch.ops.aten.where.self(le_scalar_171, new_zeros_default_496, to_dtype_513);  le_scalar_171 = new_zeros_default_496 = to_dtype_513 = None
        to_dtype_515 = torch.ops.aten.to.dtype(where_self_171, torch.float32);  where_self_171 = None
        native_batch_norm_backward_default_205 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_515, convolution_default_119, primals_730, primals_728, primals_729, getitem_358, getitem_359, True, 1e-05, [True, True, True]);  convolution_default_119 = primals_730 = primals_728 = primals_729 = getitem_358 = getitem_359 = None
        getitem_2205 = native_batch_norm_backward_default_205[0]
        getitem_2206 = native_batch_norm_backward_default_205[1]
        getitem_2207 = native_batch_norm_backward_default_205[2];  native_batch_norm_backward_default_205 = None
        convolution_backward_default_205 = torch.ops.aten.convolution_backward.default(getitem_2205, relu__default_101, primals_732, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2205 = primals_732 = None
        getitem_2208 = convolution_backward_default_205[0]
        getitem_2209 = convolution_backward_default_205[1]
        getitem_2210 = convolution_backward_default_205[2];  convolution_backward_default_205 = None
        to_dtype_516 = torch.ops.aten.to.dtype(getitem_2208, torch.float32);  getitem_2208 = None
        to_dtype_517 = torch.ops.aten.to.dtype(relu__default_101, torch.float32);  relu__default_101 = None
        le_scalar_172 = torch.ops.aten.le.Scalar(to_dtype_517, 0);  to_dtype_517 = None
        new_zeros_default_497 = torch.ops.aten.new_zeros.default(to_dtype_516, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_172 = torch.ops.aten.where.self(le_scalar_172, new_zeros_default_497, to_dtype_516);  le_scalar_172 = new_zeros_default_497 = to_dtype_516 = None
        to_dtype_518 = torch.ops.aten.to.dtype(where_self_172, torch.float32);  where_self_172 = None
        native_batch_norm_backward_default_206 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_518, convolution_default_118, primals_725, primals_723, primals_724, getitem_355, getitem_356, True, 1e-05, [True, True, True]);  to_dtype_518 = convolution_default_118 = primals_725 = primals_723 = primals_724 = getitem_355 = getitem_356 = None
        getitem_2211 = native_batch_norm_backward_default_206[0]
        getitem_2212 = native_batch_norm_backward_default_206[1]
        getitem_2213 = native_batch_norm_backward_default_206[2];  native_batch_norm_backward_default_206 = None
        convolution_backward_default_206 = torch.ops.aten.convolution_backward.default(getitem_2211, relu__default_100, primals_731, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2211 = primals_731 = None
        getitem_2214 = convolution_backward_default_206[0]
        getitem_2215 = convolution_backward_default_206[1]
        getitem_2216 = convolution_backward_default_206[2];  convolution_backward_default_206 = None
        add_tensor_179 = torch.ops.aten.add.Tensor(to_dtype_515, getitem_2214);  to_dtype_515 = getitem_2214 = None
        to_dtype_519 = torch.ops.aten.to.dtype(add_tensor_179, torch.float32);  add_tensor_179 = None
        to_dtype_520 = torch.ops.aten.to.dtype(relu__default_100, torch.float32);  relu__default_100 = None
        le_scalar_173 = torch.ops.aten.le.Scalar(to_dtype_520, 0);  to_dtype_520 = None
        new_zeros_default_498 = torch.ops.aten.new_zeros.default(to_dtype_519, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_173 = torch.ops.aten.where.self(le_scalar_173, new_zeros_default_498, to_dtype_519);  le_scalar_173 = new_zeros_default_498 = to_dtype_519 = None
        to_dtype_521 = torch.ops.aten.to.dtype(where_self_173, torch.float32);  where_self_173 = None
        native_batch_norm_backward_default_207 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_521, convolution_default_117, primals_718, primals_716, primals_717, getitem_352, getitem_353, True, 1e-05, [True, True, True]);  convolution_default_117 = primals_718 = primals_716 = primals_717 = getitem_352 = getitem_353 = None
        getitem_2217 = native_batch_norm_backward_default_207[0]
        getitem_2218 = native_batch_norm_backward_default_207[1]
        getitem_2219 = native_batch_norm_backward_default_207[2];  native_batch_norm_backward_default_207 = None
        convolution_backward_default_207 = torch.ops.aten.convolution_backward.default(getitem_2217, relu__default_99, primals_720, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2217 = primals_720 = None
        getitem_2220 = convolution_backward_default_207[0]
        getitem_2221 = convolution_backward_default_207[1]
        getitem_2222 = convolution_backward_default_207[2];  convolution_backward_default_207 = None
        to_dtype_522 = torch.ops.aten.to.dtype(getitem_2220, torch.float32);  getitem_2220 = None
        to_dtype_523 = torch.ops.aten.to.dtype(relu__default_99, torch.float32);  relu__default_99 = None
        le_scalar_174 = torch.ops.aten.le.Scalar(to_dtype_523, 0);  to_dtype_523 = None
        new_zeros_default_499 = torch.ops.aten.new_zeros.default(to_dtype_522, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_174 = torch.ops.aten.where.self(le_scalar_174, new_zeros_default_499, to_dtype_522);  le_scalar_174 = new_zeros_default_499 = to_dtype_522 = None
        to_dtype_524 = torch.ops.aten.to.dtype(where_self_174, torch.float32);  where_self_174 = None
        native_batch_norm_backward_default_208 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_524, convolution_default_116, primals_713, primals_711, primals_712, getitem_349, getitem_350, True, 1e-05, [True, True, True]);  to_dtype_524 = convolution_default_116 = primals_713 = primals_711 = primals_712 = getitem_349 = getitem_350 = None
        getitem_2223 = native_batch_norm_backward_default_208[0]
        getitem_2224 = native_batch_norm_backward_default_208[1]
        getitem_2225 = native_batch_norm_backward_default_208[2];  native_batch_norm_backward_default_208 = None
        convolution_backward_default_208 = torch.ops.aten.convolution_backward.default(getitem_2223, relu__default_98, primals_719, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2223 = primals_719 = None
        getitem_2226 = convolution_backward_default_208[0]
        getitem_2227 = convolution_backward_default_208[1]
        getitem_2228 = convolution_backward_default_208[2];  convolution_backward_default_208 = None
        add_tensor_180 = torch.ops.aten.add.Tensor(to_dtype_521, getitem_2226);  to_dtype_521 = getitem_2226 = None
        to_dtype_525 = torch.ops.aten.to.dtype(add_tensor_180, torch.float32);  add_tensor_180 = None
        to_dtype_526 = torch.ops.aten.to.dtype(relu__default_98, torch.float32);  relu__default_98 = None
        le_scalar_175 = torch.ops.aten.le.Scalar(to_dtype_526, 0);  to_dtype_526 = None
        new_zeros_default_500 = torch.ops.aten.new_zeros.default(to_dtype_525, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_175 = torch.ops.aten.where.self(le_scalar_175, new_zeros_default_500, to_dtype_525);  le_scalar_175 = new_zeros_default_500 = to_dtype_525 = None
        to_dtype_527 = torch.ops.aten.to.dtype(where_self_175, torch.float32);  where_self_175 = None
        native_batch_norm_backward_default_209 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_527, convolution_default_115, primals_706, primals_704, primals_705, getitem_346, getitem_347, True, 1e-05, [True, True, True]);  convolution_default_115 = primals_706 = primals_704 = primals_705 = getitem_346 = getitem_347 = None
        getitem_2229 = native_batch_norm_backward_default_209[0]
        getitem_2230 = native_batch_norm_backward_default_209[1]
        getitem_2231 = native_batch_norm_backward_default_209[2];  native_batch_norm_backward_default_209 = None
        convolution_backward_default_209 = torch.ops.aten.convolution_backward.default(getitem_2229, relu__default_97, primals_708, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2229 = primals_708 = None
        getitem_2232 = convolution_backward_default_209[0]
        getitem_2233 = convolution_backward_default_209[1]
        getitem_2234 = convolution_backward_default_209[2];  convolution_backward_default_209 = None
        to_dtype_528 = torch.ops.aten.to.dtype(getitem_2232, torch.float32);  getitem_2232 = None
        to_dtype_529 = torch.ops.aten.to.dtype(relu__default_97, torch.float32);  relu__default_97 = None
        le_scalar_176 = torch.ops.aten.le.Scalar(to_dtype_529, 0);  to_dtype_529 = None
        new_zeros_default_501 = torch.ops.aten.new_zeros.default(to_dtype_528, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_176 = torch.ops.aten.where.self(le_scalar_176, new_zeros_default_501, to_dtype_528);  le_scalar_176 = new_zeros_default_501 = to_dtype_528 = None
        to_dtype_530 = torch.ops.aten.to.dtype(where_self_176, torch.float32);  where_self_176 = None
        native_batch_norm_backward_default_210 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_530, convolution_default_114, primals_701, primals_699, primals_700, getitem_343, getitem_344, True, 1e-05, [True, True, True]);  to_dtype_530 = convolution_default_114 = primals_701 = primals_699 = primals_700 = getitem_343 = getitem_344 = None
        getitem_2235 = native_batch_norm_backward_default_210[0]
        getitem_2236 = native_batch_norm_backward_default_210[1]
        getitem_2237 = native_batch_norm_backward_default_210[2];  native_batch_norm_backward_default_210 = None
        convolution_backward_default_210 = torch.ops.aten.convolution_backward.default(getitem_2235, relu_default_9, primals_707, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2235 = primals_707 = None
        getitem_2238 = convolution_backward_default_210[0]
        getitem_2239 = convolution_backward_default_210[1]
        getitem_2240 = convolution_backward_default_210[2];  convolution_backward_default_210 = None
        add_tensor_181 = torch.ops.aten.add.Tensor(to_dtype_527, getitem_2238);  to_dtype_527 = getitem_2238 = None
        to_dtype_531 = torch.ops.aten.to.dtype(add_tensor_177, torch.float32);  add_tensor_177 = None
        to_dtype_532 = torch.ops.aten.to.dtype(relu__default_96, torch.float32);  relu__default_96 = None
        le_scalar_177 = torch.ops.aten.le.Scalar(to_dtype_532, 0);  to_dtype_532 = None
        new_zeros_default_502 = torch.ops.aten.new_zeros.default(to_dtype_531, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_177 = torch.ops.aten.where.self(le_scalar_177, new_zeros_default_502, to_dtype_531);  le_scalar_177 = new_zeros_default_502 = to_dtype_531 = None
        to_dtype_533 = torch.ops.aten.to.dtype(where_self_177, torch.float32);  where_self_177 = None
        native_batch_norm_backward_default_211 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_533, convolution_default_113, primals_694, primals_692, primals_693, getitem_340, getitem_341, True, 1e-05, [True, True, True]);  convolution_default_113 = primals_694 = primals_692 = primals_693 = getitem_340 = getitem_341 = None
        getitem_2241 = native_batch_norm_backward_default_211[0]
        getitem_2242 = native_batch_norm_backward_default_211[1]
        getitem_2243 = native_batch_norm_backward_default_211[2];  native_batch_norm_backward_default_211 = None
        convolution_backward_default_211 = torch.ops.aten.convolution_backward.default(getitem_2241, relu__default_95, primals_696, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2241 = primals_696 = None
        getitem_2244 = convolution_backward_default_211[0]
        getitem_2245 = convolution_backward_default_211[1]
        getitem_2246 = convolution_backward_default_211[2];  convolution_backward_default_211 = None
        to_dtype_534 = torch.ops.aten.to.dtype(getitem_2244, torch.float32);  getitem_2244 = None
        to_dtype_535 = torch.ops.aten.to.dtype(relu__default_95, torch.float32);  relu__default_95 = None
        le_scalar_178 = torch.ops.aten.le.Scalar(to_dtype_535, 0);  to_dtype_535 = None
        new_zeros_default_503 = torch.ops.aten.new_zeros.default(to_dtype_534, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_178 = torch.ops.aten.where.self(le_scalar_178, new_zeros_default_503, to_dtype_534);  le_scalar_178 = new_zeros_default_503 = to_dtype_534 = None
        to_dtype_536 = torch.ops.aten.to.dtype(where_self_178, torch.float32);  where_self_178 = None
        native_batch_norm_backward_default_212 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_536, convolution_default_112, primals_689, primals_687, primals_688, getitem_337, getitem_338, True, 1e-05, [True, True, True]);  to_dtype_536 = convolution_default_112 = primals_689 = primals_687 = primals_688 = getitem_337 = getitem_338 = None
        getitem_2247 = native_batch_norm_backward_default_212[0]
        getitem_2248 = native_batch_norm_backward_default_212[1]
        getitem_2249 = native_batch_norm_backward_default_212[2];  native_batch_norm_backward_default_212 = None
        convolution_backward_default_212 = torch.ops.aten.convolution_backward.default(getitem_2247, relu__default_94, primals_695, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2247 = primals_695 = None
        getitem_2250 = convolution_backward_default_212[0]
        getitem_2251 = convolution_backward_default_212[1]
        getitem_2252 = convolution_backward_default_212[2];  convolution_backward_default_212 = None
        add_tensor_182 = torch.ops.aten.add.Tensor(to_dtype_533, getitem_2250);  to_dtype_533 = getitem_2250 = None
        to_dtype_537 = torch.ops.aten.to.dtype(add_tensor_182, torch.float32);  add_tensor_182 = None
        to_dtype_538 = torch.ops.aten.to.dtype(relu__default_94, torch.float32);  relu__default_94 = None
        le_scalar_179 = torch.ops.aten.le.Scalar(to_dtype_538, 0);  to_dtype_538 = None
        new_zeros_default_504 = torch.ops.aten.new_zeros.default(to_dtype_537, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_179 = torch.ops.aten.where.self(le_scalar_179, new_zeros_default_504, to_dtype_537);  le_scalar_179 = new_zeros_default_504 = to_dtype_537 = None
        to_dtype_539 = torch.ops.aten.to.dtype(where_self_179, torch.float32);  where_self_179 = None
        native_batch_norm_backward_default_213 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_539, convolution_default_111, primals_682, primals_680, primals_681, getitem_334, getitem_335, True, 1e-05, [True, True, True]);  convolution_default_111 = primals_682 = primals_680 = primals_681 = getitem_334 = getitem_335 = None
        getitem_2253 = native_batch_norm_backward_default_213[0]
        getitem_2254 = native_batch_norm_backward_default_213[1]
        getitem_2255 = native_batch_norm_backward_default_213[2];  native_batch_norm_backward_default_213 = None
        convolution_backward_default_213 = torch.ops.aten.convolution_backward.default(getitem_2253, relu__default_93, primals_684, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2253 = primals_684 = None
        getitem_2256 = convolution_backward_default_213[0]
        getitem_2257 = convolution_backward_default_213[1]
        getitem_2258 = convolution_backward_default_213[2];  convolution_backward_default_213 = None
        to_dtype_540 = torch.ops.aten.to.dtype(getitem_2256, torch.float32);  getitem_2256 = None
        to_dtype_541 = torch.ops.aten.to.dtype(relu__default_93, torch.float32);  relu__default_93 = None
        le_scalar_180 = torch.ops.aten.le.Scalar(to_dtype_541, 0);  to_dtype_541 = None
        new_zeros_default_505 = torch.ops.aten.new_zeros.default(to_dtype_540, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_180 = torch.ops.aten.where.self(le_scalar_180, new_zeros_default_505, to_dtype_540);  le_scalar_180 = new_zeros_default_505 = to_dtype_540 = None
        to_dtype_542 = torch.ops.aten.to.dtype(where_self_180, torch.float32);  where_self_180 = None
        native_batch_norm_backward_default_214 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_542, convolution_default_110, primals_677, primals_675, primals_676, getitem_331, getitem_332, True, 1e-05, [True, True, True]);  to_dtype_542 = convolution_default_110 = primals_677 = primals_675 = primals_676 = getitem_331 = getitem_332 = None
        getitem_2259 = native_batch_norm_backward_default_214[0]
        getitem_2260 = native_batch_norm_backward_default_214[1]
        getitem_2261 = native_batch_norm_backward_default_214[2];  native_batch_norm_backward_default_214 = None
        convolution_backward_default_214 = torch.ops.aten.convolution_backward.default(getitem_2259, relu__default_92, primals_683, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2259 = primals_683 = None
        getitem_2262 = convolution_backward_default_214[0]
        getitem_2263 = convolution_backward_default_214[1]
        getitem_2264 = convolution_backward_default_214[2];  convolution_backward_default_214 = None
        add_tensor_183 = torch.ops.aten.add.Tensor(to_dtype_539, getitem_2262);  to_dtype_539 = getitem_2262 = None
        to_dtype_543 = torch.ops.aten.to.dtype(add_tensor_183, torch.float32);  add_tensor_183 = None
        to_dtype_544 = torch.ops.aten.to.dtype(relu__default_92, torch.float32);  relu__default_92 = None
        le_scalar_181 = torch.ops.aten.le.Scalar(to_dtype_544, 0);  to_dtype_544 = None
        new_zeros_default_506 = torch.ops.aten.new_zeros.default(to_dtype_543, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_181 = torch.ops.aten.where.self(le_scalar_181, new_zeros_default_506, to_dtype_543);  le_scalar_181 = new_zeros_default_506 = to_dtype_543 = None
        to_dtype_545 = torch.ops.aten.to.dtype(where_self_181, torch.float32);  where_self_181 = None
        native_batch_norm_backward_default_215 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_545, convolution_default_109, primals_670, primals_668, primals_669, getitem_328, getitem_329, True, 1e-05, [True, True, True]);  convolution_default_109 = primals_670 = primals_668 = primals_669 = getitem_328 = getitem_329 = None
        getitem_2265 = native_batch_norm_backward_default_215[0]
        getitem_2266 = native_batch_norm_backward_default_215[1]
        getitem_2267 = native_batch_norm_backward_default_215[2];  native_batch_norm_backward_default_215 = None
        convolution_backward_default_215 = torch.ops.aten.convolution_backward.default(getitem_2265, relu__default_91, primals_672, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2265 = primals_672 = None
        getitem_2268 = convolution_backward_default_215[0]
        getitem_2269 = convolution_backward_default_215[1]
        getitem_2270 = convolution_backward_default_215[2];  convolution_backward_default_215 = None
        to_dtype_546 = torch.ops.aten.to.dtype(getitem_2268, torch.float32);  getitem_2268 = None
        to_dtype_547 = torch.ops.aten.to.dtype(relu__default_91, torch.float32);  relu__default_91 = None
        le_scalar_182 = torch.ops.aten.le.Scalar(to_dtype_547, 0);  to_dtype_547 = None
        new_zeros_default_507 = torch.ops.aten.new_zeros.default(to_dtype_546, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_182 = torch.ops.aten.where.self(le_scalar_182, new_zeros_default_507, to_dtype_546);  le_scalar_182 = new_zeros_default_507 = to_dtype_546 = None
        to_dtype_548 = torch.ops.aten.to.dtype(where_self_182, torch.float32);  where_self_182 = None
        native_batch_norm_backward_default_216 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_548, convolution_default_108, primals_665, primals_663, primals_664, getitem_325, getitem_326, True, 1e-05, [True, True, True]);  to_dtype_548 = convolution_default_108 = primals_665 = primals_663 = primals_664 = getitem_325 = getitem_326 = None
        getitem_2271 = native_batch_norm_backward_default_216[0]
        getitem_2272 = native_batch_norm_backward_default_216[1]
        getitem_2273 = native_batch_norm_backward_default_216[2];  native_batch_norm_backward_default_216 = None
        convolution_backward_default_216 = torch.ops.aten.convolution_backward.default(getitem_2271, relu__default_90, primals_671, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2271 = primals_671 = None
        getitem_2274 = convolution_backward_default_216[0]
        getitem_2275 = convolution_backward_default_216[1]
        getitem_2276 = convolution_backward_default_216[2];  convolution_backward_default_216 = None
        add_tensor_184 = torch.ops.aten.add.Tensor(to_dtype_545, getitem_2274);  to_dtype_545 = getitem_2274 = None
        to_dtype_549 = torch.ops.aten.to.dtype(add_tensor_184, torch.float32);  add_tensor_184 = None
        to_dtype_550 = torch.ops.aten.to.dtype(relu__default_90, torch.float32);  relu__default_90 = None
        le_scalar_183 = torch.ops.aten.le.Scalar(to_dtype_550, 0);  to_dtype_550 = None
        new_zeros_default_508 = torch.ops.aten.new_zeros.default(to_dtype_549, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_183 = torch.ops.aten.where.self(le_scalar_183, new_zeros_default_508, to_dtype_549);  le_scalar_183 = new_zeros_default_508 = to_dtype_549 = None
        to_dtype_551 = torch.ops.aten.to.dtype(where_self_183, torch.float32);  where_self_183 = None
        native_batch_norm_backward_default_217 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_551, convolution_default_107, primals_658, primals_656, primals_657, getitem_322, getitem_323, True, 1e-05, [True, True, True]);  convolution_default_107 = primals_658 = primals_656 = primals_657 = getitem_322 = getitem_323 = None
        getitem_2277 = native_batch_norm_backward_default_217[0]
        getitem_2278 = native_batch_norm_backward_default_217[1]
        getitem_2279 = native_batch_norm_backward_default_217[2];  native_batch_norm_backward_default_217 = None
        convolution_backward_default_217 = torch.ops.aten.convolution_backward.default(getitem_2277, relu__default_89, primals_660, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2277 = primals_660 = None
        getitem_2280 = convolution_backward_default_217[0]
        getitem_2281 = convolution_backward_default_217[1]
        getitem_2282 = convolution_backward_default_217[2];  convolution_backward_default_217 = None
        to_dtype_552 = torch.ops.aten.to.dtype(getitem_2280, torch.float32);  getitem_2280 = None
        to_dtype_553 = torch.ops.aten.to.dtype(relu__default_89, torch.float32);  relu__default_89 = None
        le_scalar_184 = torch.ops.aten.le.Scalar(to_dtype_553, 0);  to_dtype_553 = None
        new_zeros_default_509 = torch.ops.aten.new_zeros.default(to_dtype_552, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_184 = torch.ops.aten.where.self(le_scalar_184, new_zeros_default_509, to_dtype_552);  le_scalar_184 = new_zeros_default_509 = to_dtype_552 = None
        to_dtype_554 = torch.ops.aten.to.dtype(where_self_184, torch.float32);  where_self_184 = None
        native_batch_norm_backward_default_218 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_554, convolution_default_106, primals_653, primals_651, primals_652, getitem_319, getitem_320, True, 1e-05, [True, True, True]);  to_dtype_554 = convolution_default_106 = primals_653 = primals_651 = primals_652 = getitem_319 = getitem_320 = None
        getitem_2283 = native_batch_norm_backward_default_218[0]
        getitem_2284 = native_batch_norm_backward_default_218[1]
        getitem_2285 = native_batch_norm_backward_default_218[2];  native_batch_norm_backward_default_218 = None
        convolution_backward_default_218 = torch.ops.aten.convolution_backward.default(getitem_2283, relu_default_7, primals_659, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2283 = primals_659 = None
        getitem_2286 = convolution_backward_default_218[0]
        getitem_2287 = convolution_backward_default_218[1]
        getitem_2288 = convolution_backward_default_218[2];  convolution_backward_default_218 = None
        add_tensor_185 = torch.ops.aten.add.Tensor(to_dtype_551, getitem_2286);  to_dtype_551 = getitem_2286 = None
        to_dtype_555 = torch.ops.aten.to.dtype(add_tensor_176, torch.float32);  add_tensor_176 = None
        to_dtype_556 = torch.ops.aten.to.dtype(relu__default_88, torch.float32);  relu__default_88 = None
        le_scalar_185 = torch.ops.aten.le.Scalar(to_dtype_556, 0);  to_dtype_556 = None
        new_zeros_default_510 = torch.ops.aten.new_zeros.default(to_dtype_555, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_185 = torch.ops.aten.where.self(le_scalar_185, new_zeros_default_510, to_dtype_555);  le_scalar_185 = new_zeros_default_510 = to_dtype_555 = None
        to_dtype_557 = torch.ops.aten.to.dtype(where_self_185, torch.float32);  where_self_185 = None
        native_batch_norm_backward_default_219 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_557, convolution_default_105, primals_646, primals_644, primals_645, getitem_316, getitem_317, True, 1e-05, [True, True, True]);  convolution_default_105 = primals_646 = primals_644 = primals_645 = getitem_316 = getitem_317 = None
        getitem_2289 = native_batch_norm_backward_default_219[0]
        getitem_2290 = native_batch_norm_backward_default_219[1]
        getitem_2291 = native_batch_norm_backward_default_219[2];  native_batch_norm_backward_default_219 = None
        convolution_backward_default_219 = torch.ops.aten.convolution_backward.default(getitem_2289, relu__default_87, primals_648, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2289 = primals_648 = None
        getitem_2292 = convolution_backward_default_219[0]
        getitem_2293 = convolution_backward_default_219[1]
        getitem_2294 = convolution_backward_default_219[2];  convolution_backward_default_219 = None
        to_dtype_558 = torch.ops.aten.to.dtype(getitem_2292, torch.float32);  getitem_2292 = None
        to_dtype_559 = torch.ops.aten.to.dtype(relu__default_87, torch.float32);  relu__default_87 = None
        le_scalar_186 = torch.ops.aten.le.Scalar(to_dtype_559, 0);  to_dtype_559 = None
        new_zeros_default_511 = torch.ops.aten.new_zeros.default(to_dtype_558, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_186 = torch.ops.aten.where.self(le_scalar_186, new_zeros_default_511, to_dtype_558);  le_scalar_186 = new_zeros_default_511 = to_dtype_558 = None
        to_dtype_560 = torch.ops.aten.to.dtype(where_self_186, torch.float32);  where_self_186 = None
        native_batch_norm_backward_default_220 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_560, convolution_default_104, primals_641, primals_639, primals_640, getitem_313, getitem_314, True, 1e-05, [True, True, True]);  to_dtype_560 = convolution_default_104 = primals_641 = primals_639 = primals_640 = getitem_313 = getitem_314 = None
        getitem_2295 = native_batch_norm_backward_default_220[0]
        getitem_2296 = native_batch_norm_backward_default_220[1]
        getitem_2297 = native_batch_norm_backward_default_220[2];  native_batch_norm_backward_default_220 = None
        convolution_backward_default_220 = torch.ops.aten.convolution_backward.default(getitem_2295, relu__default_86, primals_647, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2295 = primals_647 = None
        getitem_2298 = convolution_backward_default_220[0]
        getitem_2299 = convolution_backward_default_220[1]
        getitem_2300 = convolution_backward_default_220[2];  convolution_backward_default_220 = None
        add_tensor_186 = torch.ops.aten.add.Tensor(to_dtype_557, getitem_2298);  to_dtype_557 = getitem_2298 = None
        to_dtype_561 = torch.ops.aten.to.dtype(add_tensor_186, torch.float32);  add_tensor_186 = None
        to_dtype_562 = torch.ops.aten.to.dtype(relu__default_86, torch.float32);  relu__default_86 = None
        le_scalar_187 = torch.ops.aten.le.Scalar(to_dtype_562, 0);  to_dtype_562 = None
        new_zeros_default_512 = torch.ops.aten.new_zeros.default(to_dtype_561, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_187 = torch.ops.aten.where.self(le_scalar_187, new_zeros_default_512, to_dtype_561);  le_scalar_187 = new_zeros_default_512 = to_dtype_561 = None
        to_dtype_563 = torch.ops.aten.to.dtype(where_self_187, torch.float32);  where_self_187 = None
        native_batch_norm_backward_default_221 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_563, convolution_default_103, primals_634, primals_632, primals_633, getitem_310, getitem_311, True, 1e-05, [True, True, True]);  convolution_default_103 = primals_634 = primals_632 = primals_633 = getitem_310 = getitem_311 = None
        getitem_2301 = native_batch_norm_backward_default_221[0]
        getitem_2302 = native_batch_norm_backward_default_221[1]
        getitem_2303 = native_batch_norm_backward_default_221[2];  native_batch_norm_backward_default_221 = None
        convolution_backward_default_221 = torch.ops.aten.convolution_backward.default(getitem_2301, relu__default_85, primals_636, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2301 = primals_636 = None
        getitem_2304 = convolution_backward_default_221[0]
        getitem_2305 = convolution_backward_default_221[1]
        getitem_2306 = convolution_backward_default_221[2];  convolution_backward_default_221 = None
        to_dtype_564 = torch.ops.aten.to.dtype(getitem_2304, torch.float32);  getitem_2304 = None
        to_dtype_565 = torch.ops.aten.to.dtype(relu__default_85, torch.float32);  relu__default_85 = None
        le_scalar_188 = torch.ops.aten.le.Scalar(to_dtype_565, 0);  to_dtype_565 = None
        new_zeros_default_513 = torch.ops.aten.new_zeros.default(to_dtype_564, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_188 = torch.ops.aten.where.self(le_scalar_188, new_zeros_default_513, to_dtype_564);  le_scalar_188 = new_zeros_default_513 = to_dtype_564 = None
        to_dtype_566 = torch.ops.aten.to.dtype(where_self_188, torch.float32);  where_self_188 = None
        native_batch_norm_backward_default_222 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_566, convolution_default_102, primals_629, primals_627, primals_628, getitem_307, getitem_308, True, 1e-05, [True, True, True]);  to_dtype_566 = convolution_default_102 = primals_629 = primals_627 = primals_628 = getitem_307 = getitem_308 = None
        getitem_2307 = native_batch_norm_backward_default_222[0]
        getitem_2308 = native_batch_norm_backward_default_222[1]
        getitem_2309 = native_batch_norm_backward_default_222[2];  native_batch_norm_backward_default_222 = None
        convolution_backward_default_222 = torch.ops.aten.convolution_backward.default(getitem_2307, relu__default_84, primals_635, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2307 = primals_635 = None
        getitem_2310 = convolution_backward_default_222[0]
        getitem_2311 = convolution_backward_default_222[1]
        getitem_2312 = convolution_backward_default_222[2];  convolution_backward_default_222 = None
        add_tensor_187 = torch.ops.aten.add.Tensor(to_dtype_563, getitem_2310);  to_dtype_563 = getitem_2310 = None
        to_dtype_567 = torch.ops.aten.to.dtype(add_tensor_187, torch.float32);  add_tensor_187 = None
        to_dtype_568 = torch.ops.aten.to.dtype(relu__default_84, torch.float32);  relu__default_84 = None
        le_scalar_189 = torch.ops.aten.le.Scalar(to_dtype_568, 0);  to_dtype_568 = None
        new_zeros_default_514 = torch.ops.aten.new_zeros.default(to_dtype_567, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_189 = torch.ops.aten.where.self(le_scalar_189, new_zeros_default_514, to_dtype_567);  le_scalar_189 = new_zeros_default_514 = to_dtype_567 = None
        to_dtype_569 = torch.ops.aten.to.dtype(where_self_189, torch.float32);  where_self_189 = None
        native_batch_norm_backward_default_223 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_569, convolution_default_101, primals_622, primals_620, primals_621, getitem_304, getitem_305, True, 1e-05, [True, True, True]);  convolution_default_101 = primals_622 = primals_620 = primals_621 = getitem_304 = getitem_305 = None
        getitem_2313 = native_batch_norm_backward_default_223[0]
        getitem_2314 = native_batch_norm_backward_default_223[1]
        getitem_2315 = native_batch_norm_backward_default_223[2];  native_batch_norm_backward_default_223 = None
        convolution_backward_default_223 = torch.ops.aten.convolution_backward.default(getitem_2313, relu__default_83, primals_624, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2313 = primals_624 = None
        getitem_2316 = convolution_backward_default_223[0]
        getitem_2317 = convolution_backward_default_223[1]
        getitem_2318 = convolution_backward_default_223[2];  convolution_backward_default_223 = None
        to_dtype_570 = torch.ops.aten.to.dtype(getitem_2316, torch.float32);  getitem_2316 = None
        to_dtype_571 = torch.ops.aten.to.dtype(relu__default_83, torch.float32);  relu__default_83 = None
        le_scalar_190 = torch.ops.aten.le.Scalar(to_dtype_571, 0);  to_dtype_571 = None
        new_zeros_default_515 = torch.ops.aten.new_zeros.default(to_dtype_570, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_190 = torch.ops.aten.where.self(le_scalar_190, new_zeros_default_515, to_dtype_570);  le_scalar_190 = new_zeros_default_515 = to_dtype_570 = None
        to_dtype_572 = torch.ops.aten.to.dtype(where_self_190, torch.float32);  where_self_190 = None
        native_batch_norm_backward_default_224 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_572, convolution_default_100, primals_617, primals_615, primals_616, getitem_301, getitem_302, True, 1e-05, [True, True, True]);  to_dtype_572 = convolution_default_100 = primals_617 = primals_615 = primals_616 = getitem_301 = getitem_302 = None
        getitem_2319 = native_batch_norm_backward_default_224[0]
        getitem_2320 = native_batch_norm_backward_default_224[1]
        getitem_2321 = native_batch_norm_backward_default_224[2];  native_batch_norm_backward_default_224 = None
        convolution_backward_default_224 = torch.ops.aten.convolution_backward.default(getitem_2319, relu__default_82, primals_623, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2319 = primals_623 = None
        getitem_2322 = convolution_backward_default_224[0]
        getitem_2323 = convolution_backward_default_224[1]
        getitem_2324 = convolution_backward_default_224[2];  convolution_backward_default_224 = None
        add_tensor_188 = torch.ops.aten.add.Tensor(to_dtype_569, getitem_2322);  to_dtype_569 = getitem_2322 = None
        to_dtype_573 = torch.ops.aten.to.dtype(add_tensor_188, torch.float32);  add_tensor_188 = None
        to_dtype_574 = torch.ops.aten.to.dtype(relu__default_82, torch.float32);  relu__default_82 = None
        le_scalar_191 = torch.ops.aten.le.Scalar(to_dtype_574, 0);  to_dtype_574 = None
        new_zeros_default_516 = torch.ops.aten.new_zeros.default(to_dtype_573, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_191 = torch.ops.aten.where.self(le_scalar_191, new_zeros_default_516, to_dtype_573);  le_scalar_191 = new_zeros_default_516 = to_dtype_573 = None
        to_dtype_575 = torch.ops.aten.to.dtype(where_self_191, torch.float32);  where_self_191 = None
        native_batch_norm_backward_default_225 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_575, convolution_default_99, primals_610, primals_608, primals_609, getitem_298, getitem_299, True, 1e-05, [True, True, True]);  convolution_default_99 = primals_610 = primals_608 = primals_609 = getitem_298 = getitem_299 = None
        getitem_2325 = native_batch_norm_backward_default_225[0]
        getitem_2326 = native_batch_norm_backward_default_225[1]
        getitem_2327 = native_batch_norm_backward_default_225[2];  native_batch_norm_backward_default_225 = None
        convolution_backward_default_225 = torch.ops.aten.convolution_backward.default(getitem_2325, relu__default_81, primals_612, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2325 = primals_612 = None
        getitem_2328 = convolution_backward_default_225[0]
        getitem_2329 = convolution_backward_default_225[1]
        getitem_2330 = convolution_backward_default_225[2];  convolution_backward_default_225 = None
        to_dtype_576 = torch.ops.aten.to.dtype(getitem_2328, torch.float32);  getitem_2328 = None
        to_dtype_577 = torch.ops.aten.to.dtype(relu__default_81, torch.float32);  relu__default_81 = None
        le_scalar_192 = torch.ops.aten.le.Scalar(to_dtype_577, 0);  to_dtype_577 = None
        new_zeros_default_517 = torch.ops.aten.new_zeros.default(to_dtype_576, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_192 = torch.ops.aten.where.self(le_scalar_192, new_zeros_default_517, to_dtype_576);  le_scalar_192 = new_zeros_default_517 = to_dtype_576 = None
        to_dtype_578 = torch.ops.aten.to.dtype(where_self_192, torch.float32);  where_self_192 = None
        native_batch_norm_backward_default_226 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_578, convolution_default_98, primals_605, primals_603, primals_604, getitem_295, getitem_296, True, 1e-05, [True, True, True]);  to_dtype_578 = convolution_default_98 = primals_605 = primals_603 = primals_604 = getitem_295 = getitem_296 = None
        getitem_2331 = native_batch_norm_backward_default_226[0]
        getitem_2332 = native_batch_norm_backward_default_226[1]
        getitem_2333 = native_batch_norm_backward_default_226[2];  native_batch_norm_backward_default_226 = None
        convolution_backward_default_226 = torch.ops.aten.convolution_backward.default(getitem_2331, relu_default_6, primals_611, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2331 = primals_611 = None
        getitem_2334 = convolution_backward_default_226[0]
        getitem_2335 = convolution_backward_default_226[1]
        getitem_2336 = convolution_backward_default_226[2];  convolution_backward_default_226 = None
        add_tensor_189 = torch.ops.aten.add.Tensor(to_dtype_575, getitem_2334);  to_dtype_575 = getitem_2334 = None
        to_dtype_579 = torch.ops.aten.to.dtype(add_tensor_181, torch.float32);  add_tensor_181 = None
        to_dtype_580 = torch.ops.aten.to.dtype(relu_default_9, torch.float32);  relu_default_9 = None
        le_scalar_193 = torch.ops.aten.le.Scalar(to_dtype_580, 0);  to_dtype_580 = None
        new_zeros_default_518 = torch.ops.aten.new_zeros.default(to_dtype_579, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_193 = torch.ops.aten.where.self(le_scalar_193, new_zeros_default_518, to_dtype_579);  le_scalar_193 = new_zeros_default_518 = to_dtype_579 = None
        to_dtype_581 = torch.ops.aten.to.dtype(where_self_193, torch.float32);  where_self_193 = None
        native_batch_norm_backward_default_227 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_581, convolution_default_97, primals_1782, primals_1780, primals_1781, getitem_292, getitem_293, True, 1e-05, [True, True, True]);  convolution_default_97 = primals_1782 = primals_1780 = primals_1781 = getitem_292 = getitem_293 = None
        getitem_2337 = native_batch_norm_backward_default_227[0]
        getitem_2338 = native_batch_norm_backward_default_227[1]
        getitem_2339 = native_batch_norm_backward_default_227[2];  native_batch_norm_backward_default_227 = None
        convolution_backward_default_227 = torch.ops.aten.convolution_backward.default(getitem_2337, relu__default_72, primals_1777, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2337 = primals_1777 = None
        getitem_2340 = convolution_backward_default_227[0]
        getitem_2341 = convolution_backward_default_227[1]
        getitem_2342 = convolution_backward_default_227[2];  convolution_backward_default_227 = None
        native_batch_norm_backward_default_228 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_581, convolution_default_96, primals_1632, primals_1630, primals_1631, getitem_289, getitem_290, True, 1e-05, [True, True, True]);  convolution_default_96 = primals_1632 = primals_1630 = primals_1631 = getitem_289 = getitem_290 = None
        getitem_2343 = native_batch_norm_backward_default_228[0]
        getitem_2344 = native_batch_norm_backward_default_228[1]
        getitem_2345 = native_batch_norm_backward_default_228[2];  native_batch_norm_backward_default_228 = None
        convolution_backward_default_228 = torch.ops.aten.convolution_backward.default(getitem_2343, relu_default_8, primals_1627, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2343 = primals_1627 = None
        getitem_2346 = convolution_backward_default_228[0]
        getitem_2347 = convolution_backward_default_228[1]
        getitem_2348 = convolution_backward_default_228[2];  convolution_backward_default_228 = None
        to_dtype_582 = torch.ops.aten.to.dtype(getitem_2346, torch.float32);  getitem_2346 = None
        to_dtype_583 = torch.ops.aten.to.dtype(relu_default_8, torch.float32);  relu_default_8 = None
        le_scalar_194 = torch.ops.aten.le.Scalar(to_dtype_583, 0);  to_dtype_583 = None
        new_zeros_default_519 = torch.ops.aten.new_zeros.default(to_dtype_582, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_194 = torch.ops.aten.where.self(le_scalar_194, new_zeros_default_519, to_dtype_582);  le_scalar_194 = new_zeros_default_519 = to_dtype_582 = None
        to_dtype_584 = torch.ops.aten.to.dtype(where_self_194, torch.float32);  where_self_194 = None
        native_batch_norm_backward_default_229 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_584, convolution_default_95, primals_1626, primals_1624, primals_1625, getitem_286, getitem_287, True, 1e-05, [True, True, True]);  to_dtype_584 = convolution_default_95 = primals_1626 = primals_1624 = primals_1625 = getitem_286 = getitem_287 = None
        getitem_2349 = native_batch_norm_backward_default_229[0]
        getitem_2350 = native_batch_norm_backward_default_229[1]
        getitem_2351 = native_batch_norm_backward_default_229[2];  native_batch_norm_backward_default_229 = None
        convolution_backward_default_229 = torch.ops.aten.convolution_backward.default(getitem_2349, relu__default_64, primals_1621, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2349 = primals_1621 = None
        getitem_2352 = convolution_backward_default_229[0]
        getitem_2353 = convolution_backward_default_229[1]
        getitem_2354 = convolution_backward_default_229[2];  convolution_backward_default_229 = None
        to_dtype_585 = torch.ops.aten.to.dtype(add_tensor_185, torch.float32);  add_tensor_185 = None
        to_dtype_586 = torch.ops.aten.to.dtype(relu_default_7, torch.float32);  relu_default_7 = None
        le_scalar_195 = torch.ops.aten.le.Scalar(to_dtype_586, 0);  to_dtype_586 = None
        new_zeros_default_520 = torch.ops.aten.new_zeros.default(to_dtype_585, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_195 = torch.ops.aten.where.self(le_scalar_195, new_zeros_default_520, to_dtype_585);  le_scalar_195 = new_zeros_default_520 = to_dtype_585 = None
        to_dtype_587 = torch.ops.aten.to.dtype(where_self_195, torch.float32);  where_self_195 = None
        upsample_nearest2d_backward_vec_24 = torch.ops.aten.upsample_nearest2d_backward.vec(to_dtype_587, None, [128, 36, 14, 14], [2.0, 2.0])
        native_batch_norm_backward_default_230 = torch.ops.aten.native_batch_norm_backward.default(upsample_nearest2d_backward_vec_24, convolution_default_94, primals_1878, primals_1876, primals_1877, getitem_283, getitem_284, True, 1e-05, [True, True, True]);  upsample_nearest2d_backward_vec_24 = convolution_default_94 = primals_1878 = primals_1876 = primals_1877 = getitem_283 = getitem_284 = None
        getitem_2355 = native_batch_norm_backward_default_230[0]
        getitem_2356 = native_batch_norm_backward_default_230[1]
        getitem_2357 = native_batch_norm_backward_default_230[2];  native_batch_norm_backward_default_230 = None
        convolution_backward_default_230 = torch.ops.aten.convolution_backward.default(getitem_2355, relu__default_80, primals_1873, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2355 = primals_1873 = None
        getitem_2358 = convolution_backward_default_230[0]
        getitem_2359 = convolution_backward_default_230[1]
        getitem_2360 = convolution_backward_default_230[2];  convolution_backward_default_230 = None
        add_tensor_190 = torch.ops.aten.add.Tensor(to_dtype_581, getitem_2358);  to_dtype_581 = getitem_2358 = None
        add_tensor_191 = torch.ops.aten.add.Tensor(getitem_2340, to_dtype_587);  getitem_2340 = None
        native_batch_norm_backward_default_231 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_587, convolution_default_93, primals_1620, primals_1618, primals_1619, getitem_280, getitem_281, True, 1e-05, [True, True, True]);  to_dtype_587 = convolution_default_93 = primals_1620 = primals_1618 = primals_1619 = getitem_280 = getitem_281 = None
        getitem_2361 = native_batch_norm_backward_default_231[0]
        getitem_2362 = native_batch_norm_backward_default_231[1]
        getitem_2363 = native_batch_norm_backward_default_231[2];  native_batch_norm_backward_default_231 = None
        convolution_backward_default_231 = torch.ops.aten.convolution_backward.default(getitem_2361, relu__default_64, primals_1615, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2361 = primals_1615 = None
        getitem_2364 = convolution_backward_default_231[0]
        getitem_2365 = convolution_backward_default_231[1]
        getitem_2366 = convolution_backward_default_231[2];  convolution_backward_default_231 = None
        add_tensor_192 = torch.ops.aten.add.Tensor(getitem_2352, getitem_2364);  getitem_2352 = getitem_2364 = None
        to_dtype_588 = torch.ops.aten.to.dtype(add_tensor_189, torch.float32);  add_tensor_189 = None
        to_dtype_589 = torch.ops.aten.to.dtype(relu_default_6, torch.float32);  relu_default_6 = None
        le_scalar_196 = torch.ops.aten.le.Scalar(to_dtype_589, 0);  to_dtype_589 = None
        new_zeros_default_521 = torch.ops.aten.new_zeros.default(to_dtype_588, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_196 = torch.ops.aten.where.self(le_scalar_196, new_zeros_default_521, to_dtype_588);  le_scalar_196 = new_zeros_default_521 = to_dtype_588 = None
        to_dtype_590 = torch.ops.aten.to.dtype(where_self_196, torch.float32);  where_self_196 = None
        upsample_nearest2d_backward_vec_25 = torch.ops.aten.upsample_nearest2d_backward.vec(to_dtype_590, None, [128, 18, 14, 14], [4.0, 4.0])
        native_batch_norm_backward_default_232 = torch.ops.aten.native_batch_norm_backward.default(upsample_nearest2d_backward_vec_25, convolution_default_92, primals_1872, primals_1870, primals_1871, getitem_277, getitem_278, True, 1e-05, [True, True, True]);  upsample_nearest2d_backward_vec_25 = convolution_default_92 = primals_1872 = primals_1870 = primals_1871 = getitem_277 = getitem_278 = None
        getitem_2367 = native_batch_norm_backward_default_232[0]
        getitem_2368 = native_batch_norm_backward_default_232[1]
        getitem_2369 = native_batch_norm_backward_default_232[2];  native_batch_norm_backward_default_232 = None
        convolution_backward_default_232 = torch.ops.aten.convolution_backward.default(getitem_2367, relu__default_80, primals_1867, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2367 = primals_1867 = None
        getitem_2370 = convolution_backward_default_232[0]
        getitem_2371 = convolution_backward_default_232[1]
        getitem_2372 = convolution_backward_default_232[2];  convolution_backward_default_232 = None
        add_tensor_193 = torch.ops.aten.add.Tensor(add_tensor_190, getitem_2370);  add_tensor_190 = getitem_2370 = None
        add_tensor_194 = torch.ops.aten.add.Tensor(add_tensor_192, to_dtype_590);  add_tensor_192 = None
        upsample_nearest2d_backward_vec_26 = torch.ops.aten.upsample_nearest2d_backward.vec(to_dtype_590, None, [128, 18, 28, 28], [2.0, 2.0]);  to_dtype_590 = None
        native_batch_norm_backward_default_233 = torch.ops.aten.native_batch_norm_backward.default(upsample_nearest2d_backward_vec_26, convolution_default_91, primals_1776, primals_1774, primals_1775, getitem_274, getitem_275, True, 1e-05, [True, True, True]);  upsample_nearest2d_backward_vec_26 = convolution_default_91 = primals_1776 = primals_1774 = primals_1775 = getitem_274 = getitem_275 = None
        getitem_2373 = native_batch_norm_backward_default_233[0]
        getitem_2374 = native_batch_norm_backward_default_233[1]
        getitem_2375 = native_batch_norm_backward_default_233[2];  native_batch_norm_backward_default_233 = None
        convolution_backward_default_233 = torch.ops.aten.convolution_backward.default(getitem_2373, relu__default_72, primals_1771, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2373 = primals_1771 = None
        getitem_2376 = convolution_backward_default_233[0]
        getitem_2377 = convolution_backward_default_233[1]
        getitem_2378 = convolution_backward_default_233[2];  convolution_backward_default_233 = None
        add_tensor_195 = torch.ops.aten.add.Tensor(add_tensor_191, getitem_2376);  add_tensor_191 = getitem_2376 = None
        to_dtype_591 = torch.ops.aten.to.dtype(add_tensor_193, torch.float32);  add_tensor_193 = None
        to_dtype_592 = torch.ops.aten.to.dtype(relu__default_80, torch.float32);  relu__default_80 = None
        le_scalar_197 = torch.ops.aten.le.Scalar(to_dtype_592, 0);  to_dtype_592 = None
        new_zeros_default_522 = torch.ops.aten.new_zeros.default(to_dtype_591, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_197 = torch.ops.aten.where.self(le_scalar_197, new_zeros_default_522, to_dtype_591);  le_scalar_197 = new_zeros_default_522 = to_dtype_591 = None
        to_dtype_593 = torch.ops.aten.to.dtype(where_self_197, torch.float32);  where_self_197 = None
        native_batch_norm_backward_default_234 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_593, convolution_default_90, primals_598, primals_596, primals_597, getitem_271, getitem_272, True, 1e-05, [True, True, True]);  convolution_default_90 = primals_598 = primals_596 = primals_597 = getitem_271 = getitem_272 = None
        getitem_2379 = native_batch_norm_backward_default_234[0]
        getitem_2380 = native_batch_norm_backward_default_234[1]
        getitem_2381 = native_batch_norm_backward_default_234[2];  native_batch_norm_backward_default_234 = None
        convolution_backward_default_234 = torch.ops.aten.convolution_backward.default(getitem_2379, relu__default_79, primals_600, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2379 = primals_600 = None
        getitem_2382 = convolution_backward_default_234[0]
        getitem_2383 = convolution_backward_default_234[1]
        getitem_2384 = convolution_backward_default_234[2];  convolution_backward_default_234 = None
        to_dtype_594 = torch.ops.aten.to.dtype(getitem_2382, torch.float32);  getitem_2382 = None
        to_dtype_595 = torch.ops.aten.to.dtype(relu__default_79, torch.float32);  relu__default_79 = None
        le_scalar_198 = torch.ops.aten.le.Scalar(to_dtype_595, 0);  to_dtype_595 = None
        new_zeros_default_523 = torch.ops.aten.new_zeros.default(to_dtype_594, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_198 = torch.ops.aten.where.self(le_scalar_198, new_zeros_default_523, to_dtype_594);  le_scalar_198 = new_zeros_default_523 = to_dtype_594 = None
        to_dtype_596 = torch.ops.aten.to.dtype(where_self_198, torch.float32);  where_self_198 = None
        native_batch_norm_backward_default_235 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_596, convolution_default_89, primals_593, primals_591, primals_592, getitem_268, getitem_269, True, 1e-05, [True, True, True]);  to_dtype_596 = convolution_default_89 = primals_593 = primals_591 = primals_592 = getitem_268 = getitem_269 = None
        getitem_2385 = native_batch_norm_backward_default_235[0]
        getitem_2386 = native_batch_norm_backward_default_235[1]
        getitem_2387 = native_batch_norm_backward_default_235[2];  native_batch_norm_backward_default_235 = None
        convolution_backward_default_235 = torch.ops.aten.convolution_backward.default(getitem_2385, relu__default_78, primals_599, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2385 = primals_599 = None
        getitem_2388 = convolution_backward_default_235[0]
        getitem_2389 = convolution_backward_default_235[1]
        getitem_2390 = convolution_backward_default_235[2];  convolution_backward_default_235 = None
        add_tensor_196 = torch.ops.aten.add.Tensor(to_dtype_593, getitem_2388);  to_dtype_593 = getitem_2388 = None
        to_dtype_597 = torch.ops.aten.to.dtype(add_tensor_196, torch.float32);  add_tensor_196 = None
        to_dtype_598 = torch.ops.aten.to.dtype(relu__default_78, torch.float32);  relu__default_78 = None
        le_scalar_199 = torch.ops.aten.le.Scalar(to_dtype_598, 0);  to_dtype_598 = None
        new_zeros_default_524 = torch.ops.aten.new_zeros.default(to_dtype_597, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_199 = torch.ops.aten.where.self(le_scalar_199, new_zeros_default_524, to_dtype_597);  le_scalar_199 = new_zeros_default_524 = to_dtype_597 = None
        to_dtype_599 = torch.ops.aten.to.dtype(where_self_199, torch.float32);  where_self_199 = None
        native_batch_norm_backward_default_236 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_599, convolution_default_88, primals_586, primals_584, primals_585, getitem_265, getitem_266, True, 1e-05, [True, True, True]);  convolution_default_88 = primals_586 = primals_584 = primals_585 = getitem_265 = getitem_266 = None
        getitem_2391 = native_batch_norm_backward_default_236[0]
        getitem_2392 = native_batch_norm_backward_default_236[1]
        getitem_2393 = native_batch_norm_backward_default_236[2];  native_batch_norm_backward_default_236 = None
        convolution_backward_default_236 = torch.ops.aten.convolution_backward.default(getitem_2391, relu__default_77, primals_588, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2391 = primals_588 = None
        getitem_2394 = convolution_backward_default_236[0]
        getitem_2395 = convolution_backward_default_236[1]
        getitem_2396 = convolution_backward_default_236[2];  convolution_backward_default_236 = None
        to_dtype_600 = torch.ops.aten.to.dtype(getitem_2394, torch.float32);  getitem_2394 = None
        to_dtype_601 = torch.ops.aten.to.dtype(relu__default_77, torch.float32);  relu__default_77 = None
        le_scalar_200 = torch.ops.aten.le.Scalar(to_dtype_601, 0);  to_dtype_601 = None
        new_zeros_default_525 = torch.ops.aten.new_zeros.default(to_dtype_600, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_200 = torch.ops.aten.where.self(le_scalar_200, new_zeros_default_525, to_dtype_600);  le_scalar_200 = new_zeros_default_525 = to_dtype_600 = None
        to_dtype_602 = torch.ops.aten.to.dtype(where_self_200, torch.float32);  where_self_200 = None
        native_batch_norm_backward_default_237 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_602, convolution_default_87, primals_581, primals_579, primals_580, getitem_262, getitem_263, True, 1e-05, [True, True, True]);  to_dtype_602 = convolution_default_87 = primals_581 = primals_579 = primals_580 = getitem_262 = getitem_263 = None
        getitem_2397 = native_batch_norm_backward_default_237[0]
        getitem_2398 = native_batch_norm_backward_default_237[1]
        getitem_2399 = native_batch_norm_backward_default_237[2];  native_batch_norm_backward_default_237 = None
        convolution_backward_default_237 = torch.ops.aten.convolution_backward.default(getitem_2397, relu__default_76, primals_587, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2397 = primals_587 = None
        getitem_2400 = convolution_backward_default_237[0]
        getitem_2401 = convolution_backward_default_237[1]
        getitem_2402 = convolution_backward_default_237[2];  convolution_backward_default_237 = None
        add_tensor_197 = torch.ops.aten.add.Tensor(to_dtype_599, getitem_2400);  to_dtype_599 = getitem_2400 = None
        to_dtype_603 = torch.ops.aten.to.dtype(add_tensor_197, torch.float32);  add_tensor_197 = None
        to_dtype_604 = torch.ops.aten.to.dtype(relu__default_76, torch.float32);  relu__default_76 = None
        le_scalar_201 = torch.ops.aten.le.Scalar(to_dtype_604, 0);  to_dtype_604 = None
        new_zeros_default_526 = torch.ops.aten.new_zeros.default(to_dtype_603, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_201 = torch.ops.aten.where.self(le_scalar_201, new_zeros_default_526, to_dtype_603);  le_scalar_201 = new_zeros_default_526 = to_dtype_603 = None
        to_dtype_605 = torch.ops.aten.to.dtype(where_self_201, torch.float32);  where_self_201 = None
        native_batch_norm_backward_default_238 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_605, convolution_default_86, primals_574, primals_572, primals_573, getitem_259, getitem_260, True, 1e-05, [True, True, True]);  convolution_default_86 = primals_574 = primals_572 = primals_573 = getitem_259 = getitem_260 = None
        getitem_2403 = native_batch_norm_backward_default_238[0]
        getitem_2404 = native_batch_norm_backward_default_238[1]
        getitem_2405 = native_batch_norm_backward_default_238[2];  native_batch_norm_backward_default_238 = None
        convolution_backward_default_238 = torch.ops.aten.convolution_backward.default(getitem_2403, relu__default_75, primals_576, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2403 = primals_576 = None
        getitem_2406 = convolution_backward_default_238[0]
        getitem_2407 = convolution_backward_default_238[1]
        getitem_2408 = convolution_backward_default_238[2];  convolution_backward_default_238 = None
        to_dtype_606 = torch.ops.aten.to.dtype(getitem_2406, torch.float32);  getitem_2406 = None
        to_dtype_607 = torch.ops.aten.to.dtype(relu__default_75, torch.float32);  relu__default_75 = None
        le_scalar_202 = torch.ops.aten.le.Scalar(to_dtype_607, 0);  to_dtype_607 = None
        new_zeros_default_527 = torch.ops.aten.new_zeros.default(to_dtype_606, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_202 = torch.ops.aten.where.self(le_scalar_202, new_zeros_default_527, to_dtype_606);  le_scalar_202 = new_zeros_default_527 = to_dtype_606 = None
        to_dtype_608 = torch.ops.aten.to.dtype(where_self_202, torch.float32);  where_self_202 = None
        native_batch_norm_backward_default_239 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_608, convolution_default_85, primals_569, primals_567, primals_568, getitem_256, getitem_257, True, 1e-05, [True, True, True]);  to_dtype_608 = convolution_default_85 = primals_569 = primals_567 = primals_568 = getitem_256 = getitem_257 = None
        getitem_2409 = native_batch_norm_backward_default_239[0]
        getitem_2410 = native_batch_norm_backward_default_239[1]
        getitem_2411 = native_batch_norm_backward_default_239[2];  native_batch_norm_backward_default_239 = None
        convolution_backward_default_239 = torch.ops.aten.convolution_backward.default(getitem_2409, relu__default_74, primals_575, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2409 = primals_575 = None
        getitem_2412 = convolution_backward_default_239[0]
        getitem_2413 = convolution_backward_default_239[1]
        getitem_2414 = convolution_backward_default_239[2];  convolution_backward_default_239 = None
        add_tensor_198 = torch.ops.aten.add.Tensor(to_dtype_605, getitem_2412);  to_dtype_605 = getitem_2412 = None
        to_dtype_609 = torch.ops.aten.to.dtype(add_tensor_198, torch.float32);  add_tensor_198 = None
        to_dtype_610 = torch.ops.aten.to.dtype(relu__default_74, torch.float32);  relu__default_74 = None
        le_scalar_203 = torch.ops.aten.le.Scalar(to_dtype_610, 0);  to_dtype_610 = None
        new_zeros_default_528 = torch.ops.aten.new_zeros.default(to_dtype_609, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_203 = torch.ops.aten.where.self(le_scalar_203, new_zeros_default_528, to_dtype_609);  le_scalar_203 = new_zeros_default_528 = to_dtype_609 = None
        to_dtype_611 = torch.ops.aten.to.dtype(where_self_203, torch.float32);  where_self_203 = None
        native_batch_norm_backward_default_240 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_611, convolution_default_84, primals_562, primals_560, primals_561, getitem_253, getitem_254, True, 1e-05, [True, True, True]);  convolution_default_84 = primals_562 = primals_560 = primals_561 = getitem_253 = getitem_254 = None
        getitem_2415 = native_batch_norm_backward_default_240[0]
        getitem_2416 = native_batch_norm_backward_default_240[1]
        getitem_2417 = native_batch_norm_backward_default_240[2];  native_batch_norm_backward_default_240 = None
        convolution_backward_default_240 = torch.ops.aten.convolution_backward.default(getitem_2415, relu__default_73, primals_564, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2415 = primals_564 = None
        getitem_2418 = convolution_backward_default_240[0]
        getitem_2419 = convolution_backward_default_240[1]
        getitem_2420 = convolution_backward_default_240[2];  convolution_backward_default_240 = None
        to_dtype_612 = torch.ops.aten.to.dtype(getitem_2418, torch.float32);  getitem_2418 = None
        to_dtype_613 = torch.ops.aten.to.dtype(relu__default_73, torch.float32);  relu__default_73 = None
        le_scalar_204 = torch.ops.aten.le.Scalar(to_dtype_613, 0);  to_dtype_613 = None
        new_zeros_default_529 = torch.ops.aten.new_zeros.default(to_dtype_612, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_204 = torch.ops.aten.where.self(le_scalar_204, new_zeros_default_529, to_dtype_612);  le_scalar_204 = new_zeros_default_529 = to_dtype_612 = None
        to_dtype_614 = torch.ops.aten.to.dtype(where_self_204, torch.float32);  where_self_204 = None
        native_batch_norm_backward_default_241 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_614, convolution_default_83, primals_557, primals_555, primals_556, getitem_250, getitem_251, True, 1e-05, [True, True, True]);  to_dtype_614 = convolution_default_83 = primals_557 = primals_555 = primals_556 = getitem_250 = getitem_251 = None
        getitem_2421 = native_batch_norm_backward_default_241[0]
        getitem_2422 = native_batch_norm_backward_default_241[1]
        getitem_2423 = native_batch_norm_backward_default_241[2];  native_batch_norm_backward_default_241 = None
        convolution_backward_default_241 = torch.ops.aten.convolution_backward.default(getitem_2421, relu_default_5, primals_563, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2421 = primals_563 = None
        getitem_2424 = convolution_backward_default_241[0]
        getitem_2425 = convolution_backward_default_241[1]
        getitem_2426 = convolution_backward_default_241[2];  convolution_backward_default_241 = None
        add_tensor_199 = torch.ops.aten.add.Tensor(to_dtype_611, getitem_2424);  to_dtype_611 = getitem_2424 = None
        to_dtype_615 = torch.ops.aten.to.dtype(add_tensor_195, torch.float32);  add_tensor_195 = None
        to_dtype_616 = torch.ops.aten.to.dtype(relu__default_72, torch.float32);  relu__default_72 = None
        le_scalar_205 = torch.ops.aten.le.Scalar(to_dtype_616, 0);  to_dtype_616 = None
        new_zeros_default_530 = torch.ops.aten.new_zeros.default(to_dtype_615, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_205 = torch.ops.aten.where.self(le_scalar_205, new_zeros_default_530, to_dtype_615);  le_scalar_205 = new_zeros_default_530 = to_dtype_615 = None
        to_dtype_617 = torch.ops.aten.to.dtype(where_self_205, torch.float32);  where_self_205 = None
        native_batch_norm_backward_default_242 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_617, convolution_default_82, primals_550, primals_548, primals_549, getitem_247, getitem_248, True, 1e-05, [True, True, True]);  convolution_default_82 = primals_550 = primals_548 = primals_549 = getitem_247 = getitem_248 = None
        getitem_2427 = native_batch_norm_backward_default_242[0]
        getitem_2428 = native_batch_norm_backward_default_242[1]
        getitem_2429 = native_batch_norm_backward_default_242[2];  native_batch_norm_backward_default_242 = None
        convolution_backward_default_242 = torch.ops.aten.convolution_backward.default(getitem_2427, relu__default_71, primals_552, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2427 = primals_552 = None
        getitem_2430 = convolution_backward_default_242[0]
        getitem_2431 = convolution_backward_default_242[1]
        getitem_2432 = convolution_backward_default_242[2];  convolution_backward_default_242 = None
        to_dtype_618 = torch.ops.aten.to.dtype(getitem_2430, torch.float32);  getitem_2430 = None
        to_dtype_619 = torch.ops.aten.to.dtype(relu__default_71, torch.float32);  relu__default_71 = None
        le_scalar_206 = torch.ops.aten.le.Scalar(to_dtype_619, 0);  to_dtype_619 = None
        new_zeros_default_531 = torch.ops.aten.new_zeros.default(to_dtype_618, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_206 = torch.ops.aten.where.self(le_scalar_206, new_zeros_default_531, to_dtype_618);  le_scalar_206 = new_zeros_default_531 = to_dtype_618 = None
        to_dtype_620 = torch.ops.aten.to.dtype(where_self_206, torch.float32);  where_self_206 = None
        native_batch_norm_backward_default_243 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_620, convolution_default_81, primals_545, primals_543, primals_544, getitem_244, getitem_245, True, 1e-05, [True, True, True]);  to_dtype_620 = convolution_default_81 = primals_545 = primals_543 = primals_544 = getitem_244 = getitem_245 = None
        getitem_2433 = native_batch_norm_backward_default_243[0]
        getitem_2434 = native_batch_norm_backward_default_243[1]
        getitem_2435 = native_batch_norm_backward_default_243[2];  native_batch_norm_backward_default_243 = None
        convolution_backward_default_243 = torch.ops.aten.convolution_backward.default(getitem_2433, relu__default_70, primals_551, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2433 = primals_551 = None
        getitem_2436 = convolution_backward_default_243[0]
        getitem_2437 = convolution_backward_default_243[1]
        getitem_2438 = convolution_backward_default_243[2];  convolution_backward_default_243 = None
        add_tensor_200 = torch.ops.aten.add.Tensor(to_dtype_617, getitem_2436);  to_dtype_617 = getitem_2436 = None
        to_dtype_621 = torch.ops.aten.to.dtype(add_tensor_200, torch.float32);  add_tensor_200 = None
        to_dtype_622 = torch.ops.aten.to.dtype(relu__default_70, torch.float32);  relu__default_70 = None
        le_scalar_207 = torch.ops.aten.le.Scalar(to_dtype_622, 0);  to_dtype_622 = None
        new_zeros_default_532 = torch.ops.aten.new_zeros.default(to_dtype_621, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_207 = torch.ops.aten.where.self(le_scalar_207, new_zeros_default_532, to_dtype_621);  le_scalar_207 = new_zeros_default_532 = to_dtype_621 = None
        to_dtype_623 = torch.ops.aten.to.dtype(where_self_207, torch.float32);  where_self_207 = None
        native_batch_norm_backward_default_244 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_623, convolution_default_80, primals_538, primals_536, primals_537, getitem_241, getitem_242, True, 1e-05, [True, True, True]);  convolution_default_80 = primals_538 = primals_536 = primals_537 = getitem_241 = getitem_242 = None
        getitem_2439 = native_batch_norm_backward_default_244[0]
        getitem_2440 = native_batch_norm_backward_default_244[1]
        getitem_2441 = native_batch_norm_backward_default_244[2];  native_batch_norm_backward_default_244 = None
        convolution_backward_default_244 = torch.ops.aten.convolution_backward.default(getitem_2439, relu__default_69, primals_540, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2439 = primals_540 = None
        getitem_2442 = convolution_backward_default_244[0]
        getitem_2443 = convolution_backward_default_244[1]
        getitem_2444 = convolution_backward_default_244[2];  convolution_backward_default_244 = None
        to_dtype_624 = torch.ops.aten.to.dtype(getitem_2442, torch.float32);  getitem_2442 = None
        to_dtype_625 = torch.ops.aten.to.dtype(relu__default_69, torch.float32);  relu__default_69 = None
        le_scalar_208 = torch.ops.aten.le.Scalar(to_dtype_625, 0);  to_dtype_625 = None
        new_zeros_default_533 = torch.ops.aten.new_zeros.default(to_dtype_624, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_208 = torch.ops.aten.where.self(le_scalar_208, new_zeros_default_533, to_dtype_624);  le_scalar_208 = new_zeros_default_533 = to_dtype_624 = None
        to_dtype_626 = torch.ops.aten.to.dtype(where_self_208, torch.float32);  where_self_208 = None
        native_batch_norm_backward_default_245 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_626, convolution_default_79, primals_533, primals_531, primals_532, getitem_238, getitem_239, True, 1e-05, [True, True, True]);  to_dtype_626 = convolution_default_79 = primals_533 = primals_531 = primals_532 = getitem_238 = getitem_239 = None
        getitem_2445 = native_batch_norm_backward_default_245[0]
        getitem_2446 = native_batch_norm_backward_default_245[1]
        getitem_2447 = native_batch_norm_backward_default_245[2];  native_batch_norm_backward_default_245 = None
        convolution_backward_default_245 = torch.ops.aten.convolution_backward.default(getitem_2445, relu__default_68, primals_539, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2445 = primals_539 = None
        getitem_2448 = convolution_backward_default_245[0]
        getitem_2449 = convolution_backward_default_245[1]
        getitem_2450 = convolution_backward_default_245[2];  convolution_backward_default_245 = None
        add_tensor_201 = torch.ops.aten.add.Tensor(to_dtype_623, getitem_2448);  to_dtype_623 = getitem_2448 = None
        to_dtype_627 = torch.ops.aten.to.dtype(add_tensor_201, torch.float32);  add_tensor_201 = None
        to_dtype_628 = torch.ops.aten.to.dtype(relu__default_68, torch.float32);  relu__default_68 = None
        le_scalar_209 = torch.ops.aten.le.Scalar(to_dtype_628, 0);  to_dtype_628 = None
        new_zeros_default_534 = torch.ops.aten.new_zeros.default(to_dtype_627, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_209 = torch.ops.aten.where.self(le_scalar_209, new_zeros_default_534, to_dtype_627);  le_scalar_209 = new_zeros_default_534 = to_dtype_627 = None
        to_dtype_629 = torch.ops.aten.to.dtype(where_self_209, torch.float32);  where_self_209 = None
        native_batch_norm_backward_default_246 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_629, convolution_default_78, primals_526, primals_524, primals_525, getitem_235, getitem_236, True, 1e-05, [True, True, True]);  convolution_default_78 = primals_526 = primals_524 = primals_525 = getitem_235 = getitem_236 = None
        getitem_2451 = native_batch_norm_backward_default_246[0]
        getitem_2452 = native_batch_norm_backward_default_246[1]
        getitem_2453 = native_batch_norm_backward_default_246[2];  native_batch_norm_backward_default_246 = None
        convolution_backward_default_246 = torch.ops.aten.convolution_backward.default(getitem_2451, relu__default_67, primals_528, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2451 = primals_528 = None
        getitem_2454 = convolution_backward_default_246[0]
        getitem_2455 = convolution_backward_default_246[1]
        getitem_2456 = convolution_backward_default_246[2];  convolution_backward_default_246 = None
        to_dtype_630 = torch.ops.aten.to.dtype(getitem_2454, torch.float32);  getitem_2454 = None
        to_dtype_631 = torch.ops.aten.to.dtype(relu__default_67, torch.float32);  relu__default_67 = None
        le_scalar_210 = torch.ops.aten.le.Scalar(to_dtype_631, 0);  to_dtype_631 = None
        new_zeros_default_535 = torch.ops.aten.new_zeros.default(to_dtype_630, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_210 = torch.ops.aten.where.self(le_scalar_210, new_zeros_default_535, to_dtype_630);  le_scalar_210 = new_zeros_default_535 = to_dtype_630 = None
        to_dtype_632 = torch.ops.aten.to.dtype(where_self_210, torch.float32);  where_self_210 = None
        native_batch_norm_backward_default_247 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_632, convolution_default_77, primals_521, primals_519, primals_520, getitem_232, getitem_233, True, 1e-05, [True, True, True]);  to_dtype_632 = convolution_default_77 = primals_521 = primals_519 = primals_520 = getitem_232 = getitem_233 = None
        getitem_2457 = native_batch_norm_backward_default_247[0]
        getitem_2458 = native_batch_norm_backward_default_247[1]
        getitem_2459 = native_batch_norm_backward_default_247[2];  native_batch_norm_backward_default_247 = None
        convolution_backward_default_247 = torch.ops.aten.convolution_backward.default(getitem_2457, relu__default_66, primals_527, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2457 = primals_527 = None
        getitem_2460 = convolution_backward_default_247[0]
        getitem_2461 = convolution_backward_default_247[1]
        getitem_2462 = convolution_backward_default_247[2];  convolution_backward_default_247 = None
        add_tensor_202 = torch.ops.aten.add.Tensor(to_dtype_629, getitem_2460);  to_dtype_629 = getitem_2460 = None
        to_dtype_633 = torch.ops.aten.to.dtype(add_tensor_202, torch.float32);  add_tensor_202 = None
        to_dtype_634 = torch.ops.aten.to.dtype(relu__default_66, torch.float32);  relu__default_66 = None
        le_scalar_211 = torch.ops.aten.le.Scalar(to_dtype_634, 0);  to_dtype_634 = None
        new_zeros_default_536 = torch.ops.aten.new_zeros.default(to_dtype_633, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_211 = torch.ops.aten.where.self(le_scalar_211, new_zeros_default_536, to_dtype_633);  le_scalar_211 = new_zeros_default_536 = to_dtype_633 = None
        to_dtype_635 = torch.ops.aten.to.dtype(where_self_211, torch.float32);  where_self_211 = None
        native_batch_norm_backward_default_248 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_635, convolution_default_76, primals_514, primals_512, primals_513, getitem_229, getitem_230, True, 1e-05, [True, True, True]);  convolution_default_76 = primals_514 = primals_512 = primals_513 = getitem_229 = getitem_230 = None
        getitem_2463 = native_batch_norm_backward_default_248[0]
        getitem_2464 = native_batch_norm_backward_default_248[1]
        getitem_2465 = native_batch_norm_backward_default_248[2];  native_batch_norm_backward_default_248 = None
        convolution_backward_default_248 = torch.ops.aten.convolution_backward.default(getitem_2463, relu__default_65, primals_516, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2463 = primals_516 = None
        getitem_2466 = convolution_backward_default_248[0]
        getitem_2467 = convolution_backward_default_248[1]
        getitem_2468 = convolution_backward_default_248[2];  convolution_backward_default_248 = None
        to_dtype_636 = torch.ops.aten.to.dtype(getitem_2466, torch.float32);  getitem_2466 = None
        to_dtype_637 = torch.ops.aten.to.dtype(relu__default_65, torch.float32);  relu__default_65 = None
        le_scalar_212 = torch.ops.aten.le.Scalar(to_dtype_637, 0);  to_dtype_637 = None
        new_zeros_default_537 = torch.ops.aten.new_zeros.default(to_dtype_636, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_212 = torch.ops.aten.where.self(le_scalar_212, new_zeros_default_537, to_dtype_636);  le_scalar_212 = new_zeros_default_537 = to_dtype_636 = None
        to_dtype_638 = torch.ops.aten.to.dtype(where_self_212, torch.float32);  where_self_212 = None
        native_batch_norm_backward_default_249 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_638, convolution_default_75, primals_509, primals_507, primals_508, getitem_226, getitem_227, True, 1e-05, [True, True, True]);  to_dtype_638 = convolution_default_75 = primals_509 = primals_507 = primals_508 = getitem_226 = getitem_227 = None
        getitem_2469 = native_batch_norm_backward_default_249[0]
        getitem_2470 = native_batch_norm_backward_default_249[1]
        getitem_2471 = native_batch_norm_backward_default_249[2];  native_batch_norm_backward_default_249 = None
        convolution_backward_default_249 = torch.ops.aten.convolution_backward.default(getitem_2469, relu_default_3, primals_515, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2469 = primals_515 = None
        getitem_2472 = convolution_backward_default_249[0]
        getitem_2473 = convolution_backward_default_249[1]
        getitem_2474 = convolution_backward_default_249[2];  convolution_backward_default_249 = None
        add_tensor_203 = torch.ops.aten.add.Tensor(to_dtype_635, getitem_2472);  to_dtype_635 = getitem_2472 = None
        to_dtype_639 = torch.ops.aten.to.dtype(add_tensor_194, torch.float32);  add_tensor_194 = None
        to_dtype_640 = torch.ops.aten.to.dtype(relu__default_64, torch.float32);  relu__default_64 = None
        le_scalar_213 = torch.ops.aten.le.Scalar(to_dtype_640, 0);  to_dtype_640 = None
        new_zeros_default_538 = torch.ops.aten.new_zeros.default(to_dtype_639, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_213 = torch.ops.aten.where.self(le_scalar_213, new_zeros_default_538, to_dtype_639);  le_scalar_213 = new_zeros_default_538 = to_dtype_639 = None
        to_dtype_641 = torch.ops.aten.to.dtype(where_self_213, torch.float32);  where_self_213 = None
        native_batch_norm_backward_default_250 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_641, convolution_default_74, primals_502, primals_500, primals_501, getitem_223, getitem_224, True, 1e-05, [True, True, True]);  convolution_default_74 = primals_502 = primals_500 = primals_501 = getitem_223 = getitem_224 = None
        getitem_2475 = native_batch_norm_backward_default_250[0]
        getitem_2476 = native_batch_norm_backward_default_250[1]
        getitem_2477 = native_batch_norm_backward_default_250[2];  native_batch_norm_backward_default_250 = None
        convolution_backward_default_250 = torch.ops.aten.convolution_backward.default(getitem_2475, relu__default_63, primals_504, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2475 = primals_504 = None
        getitem_2478 = convolution_backward_default_250[0]
        getitem_2479 = convolution_backward_default_250[1]
        getitem_2480 = convolution_backward_default_250[2];  convolution_backward_default_250 = None
        to_dtype_642 = torch.ops.aten.to.dtype(getitem_2478, torch.float32);  getitem_2478 = None
        to_dtype_643 = torch.ops.aten.to.dtype(relu__default_63, torch.float32);  relu__default_63 = None
        le_scalar_214 = torch.ops.aten.le.Scalar(to_dtype_643, 0);  to_dtype_643 = None
        new_zeros_default_539 = torch.ops.aten.new_zeros.default(to_dtype_642, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_214 = torch.ops.aten.where.self(le_scalar_214, new_zeros_default_539, to_dtype_642);  le_scalar_214 = new_zeros_default_539 = to_dtype_642 = None
        to_dtype_644 = torch.ops.aten.to.dtype(where_self_214, torch.float32);  where_self_214 = None
        native_batch_norm_backward_default_251 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_644, convolution_default_73, primals_497, primals_495, primals_496, getitem_220, getitem_221, True, 1e-05, [True, True, True]);  to_dtype_644 = convolution_default_73 = primals_497 = primals_495 = primals_496 = getitem_220 = getitem_221 = None
        getitem_2481 = native_batch_norm_backward_default_251[0]
        getitem_2482 = native_batch_norm_backward_default_251[1]
        getitem_2483 = native_batch_norm_backward_default_251[2];  native_batch_norm_backward_default_251 = None
        convolution_backward_default_251 = torch.ops.aten.convolution_backward.default(getitem_2481, relu__default_62, primals_503, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2481 = primals_503 = None
        getitem_2484 = convolution_backward_default_251[0]
        getitem_2485 = convolution_backward_default_251[1]
        getitem_2486 = convolution_backward_default_251[2];  convolution_backward_default_251 = None
        add_tensor_204 = torch.ops.aten.add.Tensor(to_dtype_641, getitem_2484);  to_dtype_641 = getitem_2484 = None
        to_dtype_645 = torch.ops.aten.to.dtype(add_tensor_204, torch.float32);  add_tensor_204 = None
        to_dtype_646 = torch.ops.aten.to.dtype(relu__default_62, torch.float32);  relu__default_62 = None
        le_scalar_215 = torch.ops.aten.le.Scalar(to_dtype_646, 0);  to_dtype_646 = None
        new_zeros_default_540 = torch.ops.aten.new_zeros.default(to_dtype_645, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_215 = torch.ops.aten.where.self(le_scalar_215, new_zeros_default_540, to_dtype_645);  le_scalar_215 = new_zeros_default_540 = to_dtype_645 = None
        to_dtype_647 = torch.ops.aten.to.dtype(where_self_215, torch.float32);  where_self_215 = None
        native_batch_norm_backward_default_252 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_647, convolution_default_72, primals_490, primals_488, primals_489, getitem_217, getitem_218, True, 1e-05, [True, True, True]);  convolution_default_72 = primals_490 = primals_488 = primals_489 = getitem_217 = getitem_218 = None
        getitem_2487 = native_batch_norm_backward_default_252[0]
        getitem_2488 = native_batch_norm_backward_default_252[1]
        getitem_2489 = native_batch_norm_backward_default_252[2];  native_batch_norm_backward_default_252 = None
        convolution_backward_default_252 = torch.ops.aten.convolution_backward.default(getitem_2487, relu__default_61, primals_492, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2487 = primals_492 = None
        getitem_2490 = convolution_backward_default_252[0]
        getitem_2491 = convolution_backward_default_252[1]
        getitem_2492 = convolution_backward_default_252[2];  convolution_backward_default_252 = None
        to_dtype_648 = torch.ops.aten.to.dtype(getitem_2490, torch.float32);  getitem_2490 = None
        to_dtype_649 = torch.ops.aten.to.dtype(relu__default_61, torch.float32);  relu__default_61 = None
        le_scalar_216 = torch.ops.aten.le.Scalar(to_dtype_649, 0);  to_dtype_649 = None
        new_zeros_default_541 = torch.ops.aten.new_zeros.default(to_dtype_648, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_216 = torch.ops.aten.where.self(le_scalar_216, new_zeros_default_541, to_dtype_648);  le_scalar_216 = new_zeros_default_541 = to_dtype_648 = None
        to_dtype_650 = torch.ops.aten.to.dtype(where_self_216, torch.float32);  where_self_216 = None
        native_batch_norm_backward_default_253 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_650, convolution_default_71, primals_485, primals_483, primals_484, getitem_214, getitem_215, True, 1e-05, [True, True, True]);  to_dtype_650 = convolution_default_71 = primals_485 = primals_483 = primals_484 = getitem_214 = getitem_215 = None
        getitem_2493 = native_batch_norm_backward_default_253[0]
        getitem_2494 = native_batch_norm_backward_default_253[1]
        getitem_2495 = native_batch_norm_backward_default_253[2];  native_batch_norm_backward_default_253 = None
        convolution_backward_default_253 = torch.ops.aten.convolution_backward.default(getitem_2493, relu__default_60, primals_491, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2493 = primals_491 = None
        getitem_2496 = convolution_backward_default_253[0]
        getitem_2497 = convolution_backward_default_253[1]
        getitem_2498 = convolution_backward_default_253[2];  convolution_backward_default_253 = None
        add_tensor_205 = torch.ops.aten.add.Tensor(to_dtype_647, getitem_2496);  to_dtype_647 = getitem_2496 = None
        to_dtype_651 = torch.ops.aten.to.dtype(add_tensor_205, torch.float32);  add_tensor_205 = None
        to_dtype_652 = torch.ops.aten.to.dtype(relu__default_60, torch.float32);  relu__default_60 = None
        le_scalar_217 = torch.ops.aten.le.Scalar(to_dtype_652, 0);  to_dtype_652 = None
        new_zeros_default_542 = torch.ops.aten.new_zeros.default(to_dtype_651, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_217 = torch.ops.aten.where.self(le_scalar_217, new_zeros_default_542, to_dtype_651);  le_scalar_217 = new_zeros_default_542 = to_dtype_651 = None
        to_dtype_653 = torch.ops.aten.to.dtype(where_self_217, torch.float32);  where_self_217 = None
        native_batch_norm_backward_default_254 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_653, convolution_default_70, primals_478, primals_476, primals_477, getitem_211, getitem_212, True, 1e-05, [True, True, True]);  convolution_default_70 = primals_478 = primals_476 = primals_477 = getitem_211 = getitem_212 = None
        getitem_2499 = native_batch_norm_backward_default_254[0]
        getitem_2500 = native_batch_norm_backward_default_254[1]
        getitem_2501 = native_batch_norm_backward_default_254[2];  native_batch_norm_backward_default_254 = None
        convolution_backward_default_254 = torch.ops.aten.convolution_backward.default(getitem_2499, relu__default_59, primals_480, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2499 = primals_480 = None
        getitem_2502 = convolution_backward_default_254[0]
        getitem_2503 = convolution_backward_default_254[1]
        getitem_2504 = convolution_backward_default_254[2];  convolution_backward_default_254 = None
        to_dtype_654 = torch.ops.aten.to.dtype(getitem_2502, torch.float32);  getitem_2502 = None
        to_dtype_655 = torch.ops.aten.to.dtype(relu__default_59, torch.float32);  relu__default_59 = None
        le_scalar_218 = torch.ops.aten.le.Scalar(to_dtype_655, 0);  to_dtype_655 = None
        new_zeros_default_543 = torch.ops.aten.new_zeros.default(to_dtype_654, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_218 = torch.ops.aten.where.self(le_scalar_218, new_zeros_default_543, to_dtype_654);  le_scalar_218 = new_zeros_default_543 = to_dtype_654 = None
        to_dtype_656 = torch.ops.aten.to.dtype(where_self_218, torch.float32);  where_self_218 = None
        native_batch_norm_backward_default_255 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_656, convolution_default_69, primals_473, primals_471, primals_472, getitem_208, getitem_209, True, 1e-05, [True, True, True]);  to_dtype_656 = convolution_default_69 = primals_473 = primals_471 = primals_472 = getitem_208 = getitem_209 = None
        getitem_2505 = native_batch_norm_backward_default_255[0]
        getitem_2506 = native_batch_norm_backward_default_255[1]
        getitem_2507 = native_batch_norm_backward_default_255[2];  native_batch_norm_backward_default_255 = None
        convolution_backward_default_255 = torch.ops.aten.convolution_backward.default(getitem_2505, relu__default_58, primals_479, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2505 = primals_479 = None
        getitem_2508 = convolution_backward_default_255[0]
        getitem_2509 = convolution_backward_default_255[1]
        getitem_2510 = convolution_backward_default_255[2];  convolution_backward_default_255 = None
        add_tensor_206 = torch.ops.aten.add.Tensor(to_dtype_653, getitem_2508);  to_dtype_653 = getitem_2508 = None
        to_dtype_657 = torch.ops.aten.to.dtype(add_tensor_206, torch.float32);  add_tensor_206 = None
        to_dtype_658 = torch.ops.aten.to.dtype(relu__default_58, torch.float32);  relu__default_58 = None
        le_scalar_219 = torch.ops.aten.le.Scalar(to_dtype_658, 0);  to_dtype_658 = None
        new_zeros_default_544 = torch.ops.aten.new_zeros.default(to_dtype_657, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_219 = torch.ops.aten.where.self(le_scalar_219, new_zeros_default_544, to_dtype_657);  le_scalar_219 = new_zeros_default_544 = to_dtype_657 = None
        to_dtype_659 = torch.ops.aten.to.dtype(where_self_219, torch.float32);  where_self_219 = None
        native_batch_norm_backward_default_256 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_659, convolution_default_68, primals_466, primals_464, primals_465, getitem_205, getitem_206, True, 1e-05, [True, True, True]);  convolution_default_68 = primals_466 = primals_464 = primals_465 = getitem_205 = getitem_206 = None
        getitem_2511 = native_batch_norm_backward_default_256[0]
        getitem_2512 = native_batch_norm_backward_default_256[1]
        getitem_2513 = native_batch_norm_backward_default_256[2];  native_batch_norm_backward_default_256 = None
        convolution_backward_default_256 = torch.ops.aten.convolution_backward.default(getitem_2511, relu__default_57, primals_468, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2511 = primals_468 = None
        getitem_2514 = convolution_backward_default_256[0]
        getitem_2515 = convolution_backward_default_256[1]
        getitem_2516 = convolution_backward_default_256[2];  convolution_backward_default_256 = None
        to_dtype_660 = torch.ops.aten.to.dtype(getitem_2514, torch.float32);  getitem_2514 = None
        to_dtype_661 = torch.ops.aten.to.dtype(relu__default_57, torch.float32);  relu__default_57 = None
        le_scalar_220 = torch.ops.aten.le.Scalar(to_dtype_661, 0);  to_dtype_661 = None
        new_zeros_default_545 = torch.ops.aten.new_zeros.default(to_dtype_660, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_220 = torch.ops.aten.where.self(le_scalar_220, new_zeros_default_545, to_dtype_660);  le_scalar_220 = new_zeros_default_545 = to_dtype_660 = None
        to_dtype_662 = torch.ops.aten.to.dtype(where_self_220, torch.float32);  where_self_220 = None
        native_batch_norm_backward_default_257 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_662, convolution_default_67, primals_461, primals_459, primals_460, getitem_202, getitem_203, True, 1e-05, [True, True, True]);  to_dtype_662 = convolution_default_67 = primals_461 = primals_459 = primals_460 = getitem_202 = getitem_203 = None
        getitem_2517 = native_batch_norm_backward_default_257[0]
        getitem_2518 = native_batch_norm_backward_default_257[1]
        getitem_2519 = native_batch_norm_backward_default_257[2];  native_batch_norm_backward_default_257 = None
        convolution_backward_default_257 = torch.ops.aten.convolution_backward.default(getitem_2517, relu_default_2, primals_467, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2517 = primals_467 = None
        getitem_2520 = convolution_backward_default_257[0]
        getitem_2521 = convolution_backward_default_257[1]
        getitem_2522 = convolution_backward_default_257[2];  convolution_backward_default_257 = None
        add_tensor_207 = torch.ops.aten.add.Tensor(to_dtype_659, getitem_2520);  to_dtype_659 = getitem_2520 = None
        to_dtype_663 = torch.ops.aten.to.dtype(add_tensor_199, torch.float32);  add_tensor_199 = None
        to_dtype_664 = torch.ops.aten.to.dtype(relu_default_5, torch.float32);  relu_default_5 = None
        le_scalar_221 = torch.ops.aten.le.Scalar(to_dtype_664, 0);  to_dtype_664 = None
        new_zeros_default_546 = torch.ops.aten.new_zeros.default(to_dtype_663, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_221 = torch.ops.aten.where.self(le_scalar_221, new_zeros_default_546, to_dtype_663);  le_scalar_221 = new_zeros_default_546 = to_dtype_663 = None
        to_dtype_665 = torch.ops.aten.to.dtype(where_self_221, torch.float32);  where_self_221 = None
        native_batch_norm_backward_default_258 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_665, convolution_default_66, primals_1770, primals_1768, primals_1769, getitem_199, getitem_200, True, 1e-05, [True, True, True]);  convolution_default_66 = primals_1770 = primals_1768 = primals_1769 = getitem_199 = getitem_200 = None
        getitem_2523 = native_batch_norm_backward_default_258[0]
        getitem_2524 = native_batch_norm_backward_default_258[1]
        getitem_2525 = native_batch_norm_backward_default_258[2];  native_batch_norm_backward_default_258 = None
        convolution_backward_default_258 = torch.ops.aten.convolution_backward.default(getitem_2523, relu__default_48, primals_1765, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2523 = primals_1765 = None
        getitem_2526 = convolution_backward_default_258[0]
        getitem_2527 = convolution_backward_default_258[1]
        getitem_2528 = convolution_backward_default_258[2];  convolution_backward_default_258 = None
        native_batch_norm_backward_default_259 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_665, convolution_default_65, primals_1614, primals_1612, primals_1613, getitem_196, getitem_197, True, 1e-05, [True, True, True]);  convolution_default_65 = primals_1614 = primals_1612 = primals_1613 = getitem_196 = getitem_197 = None
        getitem_2529 = native_batch_norm_backward_default_259[0]
        getitem_2530 = native_batch_norm_backward_default_259[1]
        getitem_2531 = native_batch_norm_backward_default_259[2];  native_batch_norm_backward_default_259 = None
        convolution_backward_default_259 = torch.ops.aten.convolution_backward.default(getitem_2529, relu_default_4, primals_1609, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2529 = primals_1609 = None
        getitem_2532 = convolution_backward_default_259[0]
        getitem_2533 = convolution_backward_default_259[1]
        getitem_2534 = convolution_backward_default_259[2];  convolution_backward_default_259 = None
        to_dtype_666 = torch.ops.aten.to.dtype(getitem_2532, torch.float32);  getitem_2532 = None
        to_dtype_667 = torch.ops.aten.to.dtype(relu_default_4, torch.float32);  relu_default_4 = None
        le_scalar_222 = torch.ops.aten.le.Scalar(to_dtype_667, 0);  to_dtype_667 = None
        new_zeros_default_547 = torch.ops.aten.new_zeros.default(to_dtype_666, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_222 = torch.ops.aten.where.self(le_scalar_222, new_zeros_default_547, to_dtype_666);  le_scalar_222 = new_zeros_default_547 = to_dtype_666 = None
        to_dtype_668 = torch.ops.aten.to.dtype(where_self_222, torch.float32);  where_self_222 = None
        native_batch_norm_backward_default_260 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_668, convolution_default_64, primals_1608, primals_1606, primals_1607, getitem_193, getitem_194, True, 1e-05, [True, True, True]);  to_dtype_668 = convolution_default_64 = primals_1608 = primals_1606 = primals_1607 = getitem_193 = getitem_194 = None
        getitem_2535 = native_batch_norm_backward_default_260[0]
        getitem_2536 = native_batch_norm_backward_default_260[1]
        getitem_2537 = native_batch_norm_backward_default_260[2];  native_batch_norm_backward_default_260 = None
        convolution_backward_default_260 = torch.ops.aten.convolution_backward.default(getitem_2535, relu__default_40, primals_1603, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2535 = primals_1603 = None
        getitem_2538 = convolution_backward_default_260[0]
        getitem_2539 = convolution_backward_default_260[1]
        getitem_2540 = convolution_backward_default_260[2];  convolution_backward_default_260 = None
        to_dtype_669 = torch.ops.aten.to.dtype(add_tensor_203, torch.float32);  add_tensor_203 = None
        to_dtype_670 = torch.ops.aten.to.dtype(relu_default_3, torch.float32);  relu_default_3 = None
        le_scalar_223 = torch.ops.aten.le.Scalar(to_dtype_670, 0);  to_dtype_670 = None
        new_zeros_default_548 = torch.ops.aten.new_zeros.default(to_dtype_669, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_223 = torch.ops.aten.where.self(le_scalar_223, new_zeros_default_548, to_dtype_669);  le_scalar_223 = new_zeros_default_548 = to_dtype_669 = None
        to_dtype_671 = torch.ops.aten.to.dtype(where_self_223, torch.float32);  where_self_223 = None
        upsample_nearest2d_backward_vec_27 = torch.ops.aten.upsample_nearest2d_backward.vec(to_dtype_671, None, [128, 36, 14, 14], [2.0, 2.0])
        native_batch_norm_backward_default_261 = torch.ops.aten.native_batch_norm_backward.default(upsample_nearest2d_backward_vec_27, convolution_default_63, primals_1866, primals_1864, primals_1865, getitem_190, getitem_191, True, 1e-05, [True, True, True]);  upsample_nearest2d_backward_vec_27 = convolution_default_63 = primals_1866 = primals_1864 = primals_1865 = getitem_190 = getitem_191 = None
        getitem_2541 = native_batch_norm_backward_default_261[0]
        getitem_2542 = native_batch_norm_backward_default_261[1]
        getitem_2543 = native_batch_norm_backward_default_261[2];  native_batch_norm_backward_default_261 = None
        convolution_backward_default_261 = torch.ops.aten.convolution_backward.default(getitem_2541, relu__default_56, primals_1861, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2541 = primals_1861 = None
        getitem_2544 = convolution_backward_default_261[0]
        getitem_2545 = convolution_backward_default_261[1]
        getitem_2546 = convolution_backward_default_261[2];  convolution_backward_default_261 = None
        add_tensor_208 = torch.ops.aten.add.Tensor(to_dtype_665, getitem_2544);  to_dtype_665 = getitem_2544 = None
        add_tensor_209 = torch.ops.aten.add.Tensor(getitem_2526, to_dtype_671);  getitem_2526 = None
        native_batch_norm_backward_default_262 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_671, convolution_default_62, primals_1602, primals_1600, primals_1601, getitem_187, getitem_188, True, 1e-05, [True, True, True]);  to_dtype_671 = convolution_default_62 = primals_1602 = primals_1600 = primals_1601 = getitem_187 = getitem_188 = None
        getitem_2547 = native_batch_norm_backward_default_262[0]
        getitem_2548 = native_batch_norm_backward_default_262[1]
        getitem_2549 = native_batch_norm_backward_default_262[2];  native_batch_norm_backward_default_262 = None
        convolution_backward_default_262 = torch.ops.aten.convolution_backward.default(getitem_2547, relu__default_40, primals_1597, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2547 = primals_1597 = None
        getitem_2550 = convolution_backward_default_262[0]
        getitem_2551 = convolution_backward_default_262[1]
        getitem_2552 = convolution_backward_default_262[2];  convolution_backward_default_262 = None
        add_tensor_210 = torch.ops.aten.add.Tensor(getitem_2538, getitem_2550);  getitem_2538 = getitem_2550 = None
        to_dtype_672 = torch.ops.aten.to.dtype(add_tensor_207, torch.float32);  add_tensor_207 = None
        to_dtype_673 = torch.ops.aten.to.dtype(relu_default_2, torch.float32);  relu_default_2 = None
        le_scalar_224 = torch.ops.aten.le.Scalar(to_dtype_673, 0);  to_dtype_673 = None
        new_zeros_default_549 = torch.ops.aten.new_zeros.default(to_dtype_672, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_224 = torch.ops.aten.where.self(le_scalar_224, new_zeros_default_549, to_dtype_672);  le_scalar_224 = new_zeros_default_549 = to_dtype_672 = None
        to_dtype_674 = torch.ops.aten.to.dtype(where_self_224, torch.float32);  where_self_224 = None
        upsample_nearest2d_backward_vec_28 = torch.ops.aten.upsample_nearest2d_backward.vec(to_dtype_674, None, [128, 18, 14, 14], [4.0, 4.0])
        native_batch_norm_backward_default_263 = torch.ops.aten.native_batch_norm_backward.default(upsample_nearest2d_backward_vec_28, convolution_default_61, primals_1806, primals_1804, primals_1805, getitem_184, getitem_185, True, 1e-05, [True, True, True]);  upsample_nearest2d_backward_vec_28 = convolution_default_61 = primals_1806 = primals_1804 = primals_1805 = getitem_184 = getitem_185 = None
        getitem_2553 = native_batch_norm_backward_default_263[0]
        getitem_2554 = native_batch_norm_backward_default_263[1]
        getitem_2555 = native_batch_norm_backward_default_263[2];  native_batch_norm_backward_default_263 = None
        convolution_backward_default_263 = torch.ops.aten.convolution_backward.default(getitem_2553, relu__default_56, primals_1801, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2553 = primals_1801 = None
        getitem_2556 = convolution_backward_default_263[0]
        getitem_2557 = convolution_backward_default_263[1]
        getitem_2558 = convolution_backward_default_263[2];  convolution_backward_default_263 = None
        add_tensor_211 = torch.ops.aten.add.Tensor(add_tensor_208, getitem_2556);  add_tensor_208 = getitem_2556 = None
        add_tensor_212 = torch.ops.aten.add.Tensor(add_tensor_210, to_dtype_674);  add_tensor_210 = None
        upsample_nearest2d_backward_vec_29 = torch.ops.aten.upsample_nearest2d_backward.vec(to_dtype_674, None, [128, 18, 28, 28], [2.0, 2.0]);  to_dtype_674 = None
        native_batch_norm_backward_default_264 = torch.ops.aten.native_batch_norm_backward.default(upsample_nearest2d_backward_vec_29, convolution_default_60, primals_1764, primals_1762, primals_1763, getitem_181, getitem_182, True, 1e-05, [True, True, True]);  upsample_nearest2d_backward_vec_29 = convolution_default_60 = primals_1764 = primals_1762 = primals_1763 = getitem_181 = getitem_182 = None
        getitem_2559 = native_batch_norm_backward_default_264[0]
        getitem_2560 = native_batch_norm_backward_default_264[1]
        getitem_2561 = native_batch_norm_backward_default_264[2];  native_batch_norm_backward_default_264 = None
        convolution_backward_default_264 = torch.ops.aten.convolution_backward.default(getitem_2559, relu__default_48, primals_1759, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2559 = primals_1759 = None
        getitem_2562 = convolution_backward_default_264[0]
        getitem_2563 = convolution_backward_default_264[1]
        getitem_2564 = convolution_backward_default_264[2];  convolution_backward_default_264 = None
        add_tensor_213 = torch.ops.aten.add.Tensor(add_tensor_209, getitem_2562);  add_tensor_209 = getitem_2562 = None
        to_dtype_675 = torch.ops.aten.to.dtype(add_tensor_211, torch.float32);  add_tensor_211 = None
        to_dtype_676 = torch.ops.aten.to.dtype(relu__default_56, torch.float32);  relu__default_56 = None
        le_scalar_225 = torch.ops.aten.le.Scalar(to_dtype_676, 0);  to_dtype_676 = None
        new_zeros_default_550 = torch.ops.aten.new_zeros.default(to_dtype_675, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_225 = torch.ops.aten.where.self(le_scalar_225, new_zeros_default_550, to_dtype_675);  le_scalar_225 = new_zeros_default_550 = to_dtype_675 = None
        to_dtype_677 = torch.ops.aten.to.dtype(where_self_225, torch.float32);  where_self_225 = None
        native_batch_norm_backward_default_265 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_677, convolution_default_59, primals_454, primals_452, primals_453, getitem_178, getitem_179, True, 1e-05, [True, True, True]);  convolution_default_59 = primals_454 = primals_452 = primals_453 = getitem_178 = getitem_179 = None
        getitem_2565 = native_batch_norm_backward_default_265[0]
        getitem_2566 = native_batch_norm_backward_default_265[1]
        getitem_2567 = native_batch_norm_backward_default_265[2];  native_batch_norm_backward_default_265 = None
        convolution_backward_default_265 = torch.ops.aten.convolution_backward.default(getitem_2565, relu__default_55, primals_456, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2565 = primals_456 = None
        getitem_2568 = convolution_backward_default_265[0]
        getitem_2569 = convolution_backward_default_265[1]
        getitem_2570 = convolution_backward_default_265[2];  convolution_backward_default_265 = None
        to_dtype_678 = torch.ops.aten.to.dtype(getitem_2568, torch.float32);  getitem_2568 = None
        to_dtype_679 = torch.ops.aten.to.dtype(relu__default_55, torch.float32);  relu__default_55 = None
        le_scalar_226 = torch.ops.aten.le.Scalar(to_dtype_679, 0);  to_dtype_679 = None
        new_zeros_default_551 = torch.ops.aten.new_zeros.default(to_dtype_678, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_226 = torch.ops.aten.where.self(le_scalar_226, new_zeros_default_551, to_dtype_678);  le_scalar_226 = new_zeros_default_551 = to_dtype_678 = None
        to_dtype_680 = torch.ops.aten.to.dtype(where_self_226, torch.float32);  where_self_226 = None
        native_batch_norm_backward_default_266 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_680, convolution_default_58, primals_449, primals_447, primals_448, getitem_175, getitem_176, True, 1e-05, [True, True, True]);  to_dtype_680 = convolution_default_58 = primals_449 = primals_447 = primals_448 = getitem_175 = getitem_176 = None
        getitem_2571 = native_batch_norm_backward_default_266[0]
        getitem_2572 = native_batch_norm_backward_default_266[1]
        getitem_2573 = native_batch_norm_backward_default_266[2];  native_batch_norm_backward_default_266 = None
        convolution_backward_default_266 = torch.ops.aten.convolution_backward.default(getitem_2571, relu__default_54, primals_455, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2571 = primals_455 = None
        getitem_2574 = convolution_backward_default_266[0]
        getitem_2575 = convolution_backward_default_266[1]
        getitem_2576 = convolution_backward_default_266[2];  convolution_backward_default_266 = None
        add_tensor_214 = torch.ops.aten.add.Tensor(to_dtype_677, getitem_2574);  to_dtype_677 = getitem_2574 = None
        to_dtype_681 = torch.ops.aten.to.dtype(add_tensor_214, torch.float32);  add_tensor_214 = None
        to_dtype_682 = torch.ops.aten.to.dtype(relu__default_54, torch.float32);  relu__default_54 = None
        le_scalar_227 = torch.ops.aten.le.Scalar(to_dtype_682, 0);  to_dtype_682 = None
        new_zeros_default_552 = torch.ops.aten.new_zeros.default(to_dtype_681, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_227 = torch.ops.aten.where.self(le_scalar_227, new_zeros_default_552, to_dtype_681);  le_scalar_227 = new_zeros_default_552 = to_dtype_681 = None
        to_dtype_683 = torch.ops.aten.to.dtype(where_self_227, torch.float32);  where_self_227 = None
        native_batch_norm_backward_default_267 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_683, convolution_default_57, primals_442, primals_440, primals_441, getitem_172, getitem_173, True, 1e-05, [True, True, True]);  convolution_default_57 = primals_442 = primals_440 = primals_441 = getitem_172 = getitem_173 = None
        getitem_2577 = native_batch_norm_backward_default_267[0]
        getitem_2578 = native_batch_norm_backward_default_267[1]
        getitem_2579 = native_batch_norm_backward_default_267[2];  native_batch_norm_backward_default_267 = None
        convolution_backward_default_267 = torch.ops.aten.convolution_backward.default(getitem_2577, relu__default_53, primals_444, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2577 = primals_444 = None
        getitem_2580 = convolution_backward_default_267[0]
        getitem_2581 = convolution_backward_default_267[1]
        getitem_2582 = convolution_backward_default_267[2];  convolution_backward_default_267 = None
        to_dtype_684 = torch.ops.aten.to.dtype(getitem_2580, torch.float32);  getitem_2580 = None
        to_dtype_685 = torch.ops.aten.to.dtype(relu__default_53, torch.float32);  relu__default_53 = None
        le_scalar_228 = torch.ops.aten.le.Scalar(to_dtype_685, 0);  to_dtype_685 = None
        new_zeros_default_553 = torch.ops.aten.new_zeros.default(to_dtype_684, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_228 = torch.ops.aten.where.self(le_scalar_228, new_zeros_default_553, to_dtype_684);  le_scalar_228 = new_zeros_default_553 = to_dtype_684 = None
        to_dtype_686 = torch.ops.aten.to.dtype(where_self_228, torch.float32);  where_self_228 = None
        native_batch_norm_backward_default_268 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_686, convolution_default_56, primals_437, primals_435, primals_436, getitem_169, getitem_170, True, 1e-05, [True, True, True]);  to_dtype_686 = convolution_default_56 = primals_437 = primals_435 = primals_436 = getitem_169 = getitem_170 = None
        getitem_2583 = native_batch_norm_backward_default_268[0]
        getitem_2584 = native_batch_norm_backward_default_268[1]
        getitem_2585 = native_batch_norm_backward_default_268[2];  native_batch_norm_backward_default_268 = None
        convolution_backward_default_268 = torch.ops.aten.convolution_backward.default(getitem_2583, relu__default_52, primals_443, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2583 = primals_443 = None
        getitem_2586 = convolution_backward_default_268[0]
        getitem_2587 = convolution_backward_default_268[1]
        getitem_2588 = convolution_backward_default_268[2];  convolution_backward_default_268 = None
        add_tensor_215 = torch.ops.aten.add.Tensor(to_dtype_683, getitem_2586);  to_dtype_683 = getitem_2586 = None
        to_dtype_687 = torch.ops.aten.to.dtype(add_tensor_215, torch.float32);  add_tensor_215 = None
        to_dtype_688 = torch.ops.aten.to.dtype(relu__default_52, torch.float32);  relu__default_52 = None
        le_scalar_229 = torch.ops.aten.le.Scalar(to_dtype_688, 0);  to_dtype_688 = None
        new_zeros_default_554 = torch.ops.aten.new_zeros.default(to_dtype_687, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_229 = torch.ops.aten.where.self(le_scalar_229, new_zeros_default_554, to_dtype_687);  le_scalar_229 = new_zeros_default_554 = to_dtype_687 = None
        to_dtype_689 = torch.ops.aten.to.dtype(where_self_229, torch.float32);  where_self_229 = None
        native_batch_norm_backward_default_269 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_689, convolution_default_55, primals_430, primals_428, primals_429, getitem_166, getitem_167, True, 1e-05, [True, True, True]);  convolution_default_55 = primals_430 = primals_428 = primals_429 = getitem_166 = getitem_167 = None
        getitem_2589 = native_batch_norm_backward_default_269[0]
        getitem_2590 = native_batch_norm_backward_default_269[1]
        getitem_2591 = native_batch_norm_backward_default_269[2];  native_batch_norm_backward_default_269 = None
        convolution_backward_default_269 = torch.ops.aten.convolution_backward.default(getitem_2589, relu__default_51, primals_432, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2589 = primals_432 = None
        getitem_2592 = convolution_backward_default_269[0]
        getitem_2593 = convolution_backward_default_269[1]
        getitem_2594 = convolution_backward_default_269[2];  convolution_backward_default_269 = None
        to_dtype_690 = torch.ops.aten.to.dtype(getitem_2592, torch.float32);  getitem_2592 = None
        to_dtype_691 = torch.ops.aten.to.dtype(relu__default_51, torch.float32);  relu__default_51 = None
        le_scalar_230 = torch.ops.aten.le.Scalar(to_dtype_691, 0);  to_dtype_691 = None
        new_zeros_default_555 = torch.ops.aten.new_zeros.default(to_dtype_690, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_230 = torch.ops.aten.where.self(le_scalar_230, new_zeros_default_555, to_dtype_690);  le_scalar_230 = new_zeros_default_555 = to_dtype_690 = None
        to_dtype_692 = torch.ops.aten.to.dtype(where_self_230, torch.float32);  where_self_230 = None
        native_batch_norm_backward_default_270 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_692, convolution_default_54, primals_425, primals_423, primals_424, getitem_163, getitem_164, True, 1e-05, [True, True, True]);  to_dtype_692 = convolution_default_54 = primals_425 = primals_423 = primals_424 = getitem_163 = getitem_164 = None
        getitem_2595 = native_batch_norm_backward_default_270[0]
        getitem_2596 = native_batch_norm_backward_default_270[1]
        getitem_2597 = native_batch_norm_backward_default_270[2];  native_batch_norm_backward_default_270 = None
        convolution_backward_default_270 = torch.ops.aten.convolution_backward.default(getitem_2595, relu__default_50, primals_431, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2595 = primals_431 = None
        getitem_2598 = convolution_backward_default_270[0]
        getitem_2599 = convolution_backward_default_270[1]
        getitem_2600 = convolution_backward_default_270[2];  convolution_backward_default_270 = None
        add_tensor_216 = torch.ops.aten.add.Tensor(to_dtype_689, getitem_2598);  to_dtype_689 = getitem_2598 = None
        to_dtype_693 = torch.ops.aten.to.dtype(add_tensor_216, torch.float32);  add_tensor_216 = None
        to_dtype_694 = torch.ops.aten.to.dtype(relu__default_50, torch.float32);  relu__default_50 = None
        le_scalar_231 = torch.ops.aten.le.Scalar(to_dtype_694, 0);  to_dtype_694 = None
        new_zeros_default_556 = torch.ops.aten.new_zeros.default(to_dtype_693, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_231 = torch.ops.aten.where.self(le_scalar_231, new_zeros_default_556, to_dtype_693);  le_scalar_231 = new_zeros_default_556 = to_dtype_693 = None
        to_dtype_695 = torch.ops.aten.to.dtype(where_self_231, torch.float32);  where_self_231 = None
        native_batch_norm_backward_default_271 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_695, convolution_default_53, primals_418, primals_416, primals_417, getitem_160, getitem_161, True, 1e-05, [True, True, True]);  convolution_default_53 = primals_418 = primals_416 = primals_417 = getitem_160 = getitem_161 = None
        getitem_2601 = native_batch_norm_backward_default_271[0]
        getitem_2602 = native_batch_norm_backward_default_271[1]
        getitem_2603 = native_batch_norm_backward_default_271[2];  native_batch_norm_backward_default_271 = None
        convolution_backward_default_271 = torch.ops.aten.convolution_backward.default(getitem_2601, relu__default_49, primals_420, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2601 = primals_420 = None
        getitem_2604 = convolution_backward_default_271[0]
        getitem_2605 = convolution_backward_default_271[1]
        getitem_2606 = convolution_backward_default_271[2];  convolution_backward_default_271 = None
        to_dtype_696 = torch.ops.aten.to.dtype(getitem_2604, torch.float32);  getitem_2604 = None
        to_dtype_697 = torch.ops.aten.to.dtype(relu__default_49, torch.float32);  relu__default_49 = None
        le_scalar_232 = torch.ops.aten.le.Scalar(to_dtype_697, 0);  to_dtype_697 = None
        new_zeros_default_557 = torch.ops.aten.new_zeros.default(to_dtype_696, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_232 = torch.ops.aten.where.self(le_scalar_232, new_zeros_default_557, to_dtype_696);  le_scalar_232 = new_zeros_default_557 = to_dtype_696 = None
        to_dtype_698 = torch.ops.aten.to.dtype(where_self_232, torch.float32);  where_self_232 = None
        native_batch_norm_backward_default_272 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_698, convolution_default_52, primals_413, primals_411, primals_412, getitem_157, getitem_158, True, 1e-05, [True, True, True]);  to_dtype_698 = convolution_default_52 = primals_413 = primals_411 = primals_412 = getitem_157 = getitem_158 = None
        getitem_2607 = native_batch_norm_backward_default_272[0]
        getitem_2608 = native_batch_norm_backward_default_272[1]
        getitem_2609 = native_batch_norm_backward_default_272[2];  native_batch_norm_backward_default_272 = None
        convolution_backward_default_272 = torch.ops.aten.convolution_backward.default(getitem_2607, relu__default_32, primals_419, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2607 = primals_419 = None
        getitem_2610 = convolution_backward_default_272[0]
        getitem_2611 = convolution_backward_default_272[1]
        getitem_2612 = convolution_backward_default_272[2];  convolution_backward_default_272 = None
        add_tensor_217 = torch.ops.aten.add.Tensor(to_dtype_695, getitem_2610);  to_dtype_695 = getitem_2610 = None
        to_dtype_699 = torch.ops.aten.to.dtype(add_tensor_213, torch.float32);  add_tensor_213 = None
        to_dtype_700 = torch.ops.aten.to.dtype(relu__default_48, torch.float32);  relu__default_48 = None
        le_scalar_233 = torch.ops.aten.le.Scalar(to_dtype_700, 0);  to_dtype_700 = None
        new_zeros_default_558 = torch.ops.aten.new_zeros.default(to_dtype_699, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_233 = torch.ops.aten.where.self(le_scalar_233, new_zeros_default_558, to_dtype_699);  le_scalar_233 = new_zeros_default_558 = to_dtype_699 = None
        to_dtype_701 = torch.ops.aten.to.dtype(where_self_233, torch.float32);  where_self_233 = None
        native_batch_norm_backward_default_273 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_701, convolution_default_51, primals_406, primals_404, primals_405, getitem_154, getitem_155, True, 1e-05, [True, True, True]);  convolution_default_51 = primals_406 = primals_404 = primals_405 = getitem_154 = getitem_155 = None
        getitem_2613 = native_batch_norm_backward_default_273[0]
        getitem_2614 = native_batch_norm_backward_default_273[1]
        getitem_2615 = native_batch_norm_backward_default_273[2];  native_batch_norm_backward_default_273 = None
        convolution_backward_default_273 = torch.ops.aten.convolution_backward.default(getitem_2613, relu__default_47, primals_408, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2613 = primals_408 = None
        getitem_2616 = convolution_backward_default_273[0]
        getitem_2617 = convolution_backward_default_273[1]
        getitem_2618 = convolution_backward_default_273[2];  convolution_backward_default_273 = None
        to_dtype_702 = torch.ops.aten.to.dtype(getitem_2616, torch.float32);  getitem_2616 = None
        to_dtype_703 = torch.ops.aten.to.dtype(relu__default_47, torch.float32);  relu__default_47 = None
        le_scalar_234 = torch.ops.aten.le.Scalar(to_dtype_703, 0);  to_dtype_703 = None
        new_zeros_default_559 = torch.ops.aten.new_zeros.default(to_dtype_702, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_234 = torch.ops.aten.where.self(le_scalar_234, new_zeros_default_559, to_dtype_702);  le_scalar_234 = new_zeros_default_559 = to_dtype_702 = None
        to_dtype_704 = torch.ops.aten.to.dtype(where_self_234, torch.float32);  where_self_234 = None
        native_batch_norm_backward_default_274 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_704, convolution_default_50, primals_401, primals_399, primals_400, getitem_151, getitem_152, True, 1e-05, [True, True, True]);  to_dtype_704 = convolution_default_50 = primals_401 = primals_399 = primals_400 = getitem_151 = getitem_152 = None
        getitem_2619 = native_batch_norm_backward_default_274[0]
        getitem_2620 = native_batch_norm_backward_default_274[1]
        getitem_2621 = native_batch_norm_backward_default_274[2];  native_batch_norm_backward_default_274 = None
        convolution_backward_default_274 = torch.ops.aten.convolution_backward.default(getitem_2619, relu__default_46, primals_407, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2619 = primals_407 = None
        getitem_2622 = convolution_backward_default_274[0]
        getitem_2623 = convolution_backward_default_274[1]
        getitem_2624 = convolution_backward_default_274[2];  convolution_backward_default_274 = None
        add_tensor_218 = torch.ops.aten.add.Tensor(to_dtype_701, getitem_2622);  to_dtype_701 = getitem_2622 = None
        to_dtype_705 = torch.ops.aten.to.dtype(add_tensor_218, torch.float32);  add_tensor_218 = None
        to_dtype_706 = torch.ops.aten.to.dtype(relu__default_46, torch.float32);  relu__default_46 = None
        le_scalar_235 = torch.ops.aten.le.Scalar(to_dtype_706, 0);  to_dtype_706 = None
        new_zeros_default_560 = torch.ops.aten.new_zeros.default(to_dtype_705, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_235 = torch.ops.aten.where.self(le_scalar_235, new_zeros_default_560, to_dtype_705);  le_scalar_235 = new_zeros_default_560 = to_dtype_705 = None
        to_dtype_707 = torch.ops.aten.to.dtype(where_self_235, torch.float32);  where_self_235 = None
        native_batch_norm_backward_default_275 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_707, convolution_default_49, primals_394, primals_392, primals_393, getitem_148, getitem_149, True, 1e-05, [True, True, True]);  convolution_default_49 = primals_394 = primals_392 = primals_393 = getitem_148 = getitem_149 = None
        getitem_2625 = native_batch_norm_backward_default_275[0]
        getitem_2626 = native_batch_norm_backward_default_275[1]
        getitem_2627 = native_batch_norm_backward_default_275[2];  native_batch_norm_backward_default_275 = None
        convolution_backward_default_275 = torch.ops.aten.convolution_backward.default(getitem_2625, relu__default_45, primals_396, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2625 = primals_396 = None
        getitem_2628 = convolution_backward_default_275[0]
        getitem_2629 = convolution_backward_default_275[1]
        getitem_2630 = convolution_backward_default_275[2];  convolution_backward_default_275 = None
        to_dtype_708 = torch.ops.aten.to.dtype(getitem_2628, torch.float32);  getitem_2628 = None
        to_dtype_709 = torch.ops.aten.to.dtype(relu__default_45, torch.float32);  relu__default_45 = None
        le_scalar_236 = torch.ops.aten.le.Scalar(to_dtype_709, 0);  to_dtype_709 = None
        new_zeros_default_561 = torch.ops.aten.new_zeros.default(to_dtype_708, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_236 = torch.ops.aten.where.self(le_scalar_236, new_zeros_default_561, to_dtype_708);  le_scalar_236 = new_zeros_default_561 = to_dtype_708 = None
        to_dtype_710 = torch.ops.aten.to.dtype(where_self_236, torch.float32);  where_self_236 = None
        native_batch_norm_backward_default_276 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_710, convolution_default_48, primals_389, primals_387, primals_388, getitem_145, getitem_146, True, 1e-05, [True, True, True]);  to_dtype_710 = convolution_default_48 = primals_389 = primals_387 = primals_388 = getitem_145 = getitem_146 = None
        getitem_2631 = native_batch_norm_backward_default_276[0]
        getitem_2632 = native_batch_norm_backward_default_276[1]
        getitem_2633 = native_batch_norm_backward_default_276[2];  native_batch_norm_backward_default_276 = None
        convolution_backward_default_276 = torch.ops.aten.convolution_backward.default(getitem_2631, relu__default_44, primals_395, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2631 = primals_395 = None
        getitem_2634 = convolution_backward_default_276[0]
        getitem_2635 = convolution_backward_default_276[1]
        getitem_2636 = convolution_backward_default_276[2];  convolution_backward_default_276 = None
        add_tensor_219 = torch.ops.aten.add.Tensor(to_dtype_707, getitem_2634);  to_dtype_707 = getitem_2634 = None
        to_dtype_711 = torch.ops.aten.to.dtype(add_tensor_219, torch.float32);  add_tensor_219 = None
        to_dtype_712 = torch.ops.aten.to.dtype(relu__default_44, torch.float32);  relu__default_44 = None
        le_scalar_237 = torch.ops.aten.le.Scalar(to_dtype_712, 0);  to_dtype_712 = None
        new_zeros_default_562 = torch.ops.aten.new_zeros.default(to_dtype_711, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_237 = torch.ops.aten.where.self(le_scalar_237, new_zeros_default_562, to_dtype_711);  le_scalar_237 = new_zeros_default_562 = to_dtype_711 = None
        to_dtype_713 = torch.ops.aten.to.dtype(where_self_237, torch.float32);  where_self_237 = None
        native_batch_norm_backward_default_277 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_713, convolution_default_47, primals_382, primals_380, primals_381, getitem_142, getitem_143, True, 1e-05, [True, True, True]);  convolution_default_47 = primals_382 = primals_380 = primals_381 = getitem_142 = getitem_143 = None
        getitem_2637 = native_batch_norm_backward_default_277[0]
        getitem_2638 = native_batch_norm_backward_default_277[1]
        getitem_2639 = native_batch_norm_backward_default_277[2];  native_batch_norm_backward_default_277 = None
        convolution_backward_default_277 = torch.ops.aten.convolution_backward.default(getitem_2637, relu__default_43, primals_384, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2637 = primals_384 = None
        getitem_2640 = convolution_backward_default_277[0]
        getitem_2641 = convolution_backward_default_277[1]
        getitem_2642 = convolution_backward_default_277[2];  convolution_backward_default_277 = None
        to_dtype_714 = torch.ops.aten.to.dtype(getitem_2640, torch.float32);  getitem_2640 = None
        to_dtype_715 = torch.ops.aten.to.dtype(relu__default_43, torch.float32);  relu__default_43 = None
        le_scalar_238 = torch.ops.aten.le.Scalar(to_dtype_715, 0);  to_dtype_715 = None
        new_zeros_default_563 = torch.ops.aten.new_zeros.default(to_dtype_714, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_238 = torch.ops.aten.where.self(le_scalar_238, new_zeros_default_563, to_dtype_714);  le_scalar_238 = new_zeros_default_563 = to_dtype_714 = None
        to_dtype_716 = torch.ops.aten.to.dtype(where_self_238, torch.float32);  where_self_238 = None
        native_batch_norm_backward_default_278 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_716, convolution_default_46, primals_377, primals_375, primals_376, getitem_139, getitem_140, True, 1e-05, [True, True, True]);  to_dtype_716 = convolution_default_46 = primals_377 = primals_375 = primals_376 = getitem_139 = getitem_140 = None
        getitem_2643 = native_batch_norm_backward_default_278[0]
        getitem_2644 = native_batch_norm_backward_default_278[1]
        getitem_2645 = native_batch_norm_backward_default_278[2];  native_batch_norm_backward_default_278 = None
        convolution_backward_default_278 = torch.ops.aten.convolution_backward.default(getitem_2643, relu__default_42, primals_383, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2643 = primals_383 = None
        getitem_2646 = convolution_backward_default_278[0]
        getitem_2647 = convolution_backward_default_278[1]
        getitem_2648 = convolution_backward_default_278[2];  convolution_backward_default_278 = None
        add_tensor_220 = torch.ops.aten.add.Tensor(to_dtype_713, getitem_2646);  to_dtype_713 = getitem_2646 = None
        to_dtype_717 = torch.ops.aten.to.dtype(add_tensor_220, torch.float32);  add_tensor_220 = None
        to_dtype_718 = torch.ops.aten.to.dtype(relu__default_42, torch.float32);  relu__default_42 = None
        le_scalar_239 = torch.ops.aten.le.Scalar(to_dtype_718, 0);  to_dtype_718 = None
        new_zeros_default_564 = torch.ops.aten.new_zeros.default(to_dtype_717, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_239 = torch.ops.aten.where.self(le_scalar_239, new_zeros_default_564, to_dtype_717);  le_scalar_239 = new_zeros_default_564 = to_dtype_717 = None
        to_dtype_719 = torch.ops.aten.to.dtype(where_self_239, torch.float32);  where_self_239 = None
        native_batch_norm_backward_default_279 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_719, convolution_default_45, primals_370, primals_368, primals_369, getitem_136, getitem_137, True, 1e-05, [True, True, True]);  convolution_default_45 = primals_370 = primals_368 = primals_369 = getitem_136 = getitem_137 = None
        getitem_2649 = native_batch_norm_backward_default_279[0]
        getitem_2650 = native_batch_norm_backward_default_279[1]
        getitem_2651 = native_batch_norm_backward_default_279[2];  native_batch_norm_backward_default_279 = None
        convolution_backward_default_279 = torch.ops.aten.convolution_backward.default(getitem_2649, relu__default_41, primals_372, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2649 = primals_372 = None
        getitem_2652 = convolution_backward_default_279[0]
        getitem_2653 = convolution_backward_default_279[1]
        getitem_2654 = convolution_backward_default_279[2];  convolution_backward_default_279 = None
        to_dtype_720 = torch.ops.aten.to.dtype(getitem_2652, torch.float32);  getitem_2652 = None
        to_dtype_721 = torch.ops.aten.to.dtype(relu__default_41, torch.float32);  relu__default_41 = None
        le_scalar_240 = torch.ops.aten.le.Scalar(to_dtype_721, 0);  to_dtype_721 = None
        new_zeros_default_565 = torch.ops.aten.new_zeros.default(to_dtype_720, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_240 = torch.ops.aten.where.self(le_scalar_240, new_zeros_default_565, to_dtype_720);  le_scalar_240 = new_zeros_default_565 = to_dtype_720 = None
        to_dtype_722 = torch.ops.aten.to.dtype(where_self_240, torch.float32);  where_self_240 = None
        native_batch_norm_backward_default_280 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_722, convolution_default_44, primals_365, primals_363, primals_364, getitem_133, getitem_134, True, 1e-05, [True, True, True]);  to_dtype_722 = convolution_default_44 = primals_365 = primals_363 = primals_364 = getitem_133 = getitem_134 = None
        getitem_2655 = native_batch_norm_backward_default_280[0]
        getitem_2656 = native_batch_norm_backward_default_280[1]
        getitem_2657 = native_batch_norm_backward_default_280[2];  native_batch_norm_backward_default_280 = None
        convolution_backward_default_280 = torch.ops.aten.convolution_backward.default(getitem_2655, relu_default_1, primals_371, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2655 = primals_371 = None
        getitem_2658 = convolution_backward_default_280[0]
        getitem_2659 = convolution_backward_default_280[1]
        getitem_2660 = convolution_backward_default_280[2];  convolution_backward_default_280 = None
        add_tensor_221 = torch.ops.aten.add.Tensor(to_dtype_719, getitem_2658);  to_dtype_719 = getitem_2658 = None
        to_dtype_723 = torch.ops.aten.to.dtype(add_tensor_212, torch.float32);  add_tensor_212 = None
        to_dtype_724 = torch.ops.aten.to.dtype(relu__default_40, torch.float32);  relu__default_40 = None
        le_scalar_241 = torch.ops.aten.le.Scalar(to_dtype_724, 0);  to_dtype_724 = None
        new_zeros_default_566 = torch.ops.aten.new_zeros.default(to_dtype_723, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_241 = torch.ops.aten.where.self(le_scalar_241, new_zeros_default_566, to_dtype_723);  le_scalar_241 = new_zeros_default_566 = to_dtype_723 = None
        to_dtype_725 = torch.ops.aten.to.dtype(where_self_241, torch.float32);  where_self_241 = None
        native_batch_norm_backward_default_281 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_725, convolution_default_43, primals_358, primals_356, primals_357, getitem_130, getitem_131, True, 1e-05, [True, True, True]);  convolution_default_43 = primals_358 = primals_356 = primals_357 = getitem_130 = getitem_131 = None
        getitem_2661 = native_batch_norm_backward_default_281[0]
        getitem_2662 = native_batch_norm_backward_default_281[1]
        getitem_2663 = native_batch_norm_backward_default_281[2];  native_batch_norm_backward_default_281 = None
        convolution_backward_default_281 = torch.ops.aten.convolution_backward.default(getitem_2661, relu__default_39, primals_360, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2661 = primals_360 = None
        getitem_2664 = convolution_backward_default_281[0]
        getitem_2665 = convolution_backward_default_281[1]
        getitem_2666 = convolution_backward_default_281[2];  convolution_backward_default_281 = None
        to_dtype_726 = torch.ops.aten.to.dtype(getitem_2664, torch.float32);  getitem_2664 = None
        to_dtype_727 = torch.ops.aten.to.dtype(relu__default_39, torch.float32);  relu__default_39 = None
        le_scalar_242 = torch.ops.aten.le.Scalar(to_dtype_727, 0);  to_dtype_727 = None
        new_zeros_default_567 = torch.ops.aten.new_zeros.default(to_dtype_726, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_242 = torch.ops.aten.where.self(le_scalar_242, new_zeros_default_567, to_dtype_726);  le_scalar_242 = new_zeros_default_567 = to_dtype_726 = None
        to_dtype_728 = torch.ops.aten.to.dtype(where_self_242, torch.float32);  where_self_242 = None
        native_batch_norm_backward_default_282 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_728, convolution_default_42, primals_353, primals_351, primals_352, getitem_127, getitem_128, True, 1e-05, [True, True, True]);  to_dtype_728 = convolution_default_42 = primals_353 = primals_351 = primals_352 = getitem_127 = getitem_128 = None
        getitem_2667 = native_batch_norm_backward_default_282[0]
        getitem_2668 = native_batch_norm_backward_default_282[1]
        getitem_2669 = native_batch_norm_backward_default_282[2];  native_batch_norm_backward_default_282 = None
        convolution_backward_default_282 = torch.ops.aten.convolution_backward.default(getitem_2667, relu__default_38, primals_359, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2667 = primals_359 = None
        getitem_2670 = convolution_backward_default_282[0]
        getitem_2671 = convolution_backward_default_282[1]
        getitem_2672 = convolution_backward_default_282[2];  convolution_backward_default_282 = None
        add_tensor_222 = torch.ops.aten.add.Tensor(to_dtype_725, getitem_2670);  to_dtype_725 = getitem_2670 = None
        to_dtype_729 = torch.ops.aten.to.dtype(add_tensor_222, torch.float32);  add_tensor_222 = None
        to_dtype_730 = torch.ops.aten.to.dtype(relu__default_38, torch.float32);  relu__default_38 = None
        le_scalar_243 = torch.ops.aten.le.Scalar(to_dtype_730, 0);  to_dtype_730 = None
        new_zeros_default_568 = torch.ops.aten.new_zeros.default(to_dtype_729, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_243 = torch.ops.aten.where.self(le_scalar_243, new_zeros_default_568, to_dtype_729);  le_scalar_243 = new_zeros_default_568 = to_dtype_729 = None
        to_dtype_731 = torch.ops.aten.to.dtype(where_self_243, torch.float32);  where_self_243 = None
        native_batch_norm_backward_default_283 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_731, convolution_default_41, primals_346, primals_344, primals_345, getitem_124, getitem_125, True, 1e-05, [True, True, True]);  convolution_default_41 = primals_346 = primals_344 = primals_345 = getitem_124 = getitem_125 = None
        getitem_2673 = native_batch_norm_backward_default_283[0]
        getitem_2674 = native_batch_norm_backward_default_283[1]
        getitem_2675 = native_batch_norm_backward_default_283[2];  native_batch_norm_backward_default_283 = None
        convolution_backward_default_283 = torch.ops.aten.convolution_backward.default(getitem_2673, relu__default_37, primals_348, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2673 = primals_348 = None
        getitem_2676 = convolution_backward_default_283[0]
        getitem_2677 = convolution_backward_default_283[1]
        getitem_2678 = convolution_backward_default_283[2];  convolution_backward_default_283 = None
        to_dtype_732 = torch.ops.aten.to.dtype(getitem_2676, torch.float32);  getitem_2676 = None
        to_dtype_733 = torch.ops.aten.to.dtype(relu__default_37, torch.float32);  relu__default_37 = None
        le_scalar_244 = torch.ops.aten.le.Scalar(to_dtype_733, 0);  to_dtype_733 = None
        new_zeros_default_569 = torch.ops.aten.new_zeros.default(to_dtype_732, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_244 = torch.ops.aten.where.self(le_scalar_244, new_zeros_default_569, to_dtype_732);  le_scalar_244 = new_zeros_default_569 = to_dtype_732 = None
        to_dtype_734 = torch.ops.aten.to.dtype(where_self_244, torch.float32);  where_self_244 = None
        native_batch_norm_backward_default_284 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_734, convolution_default_40, primals_341, primals_339, primals_340, getitem_121, getitem_122, True, 1e-05, [True, True, True]);  to_dtype_734 = convolution_default_40 = primals_341 = primals_339 = primals_340 = getitem_121 = getitem_122 = None
        getitem_2679 = native_batch_norm_backward_default_284[0]
        getitem_2680 = native_batch_norm_backward_default_284[1]
        getitem_2681 = native_batch_norm_backward_default_284[2];  native_batch_norm_backward_default_284 = None
        convolution_backward_default_284 = torch.ops.aten.convolution_backward.default(getitem_2679, relu__default_36, primals_347, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2679 = primals_347 = None
        getitem_2682 = convolution_backward_default_284[0]
        getitem_2683 = convolution_backward_default_284[1]
        getitem_2684 = convolution_backward_default_284[2];  convolution_backward_default_284 = None
        add_tensor_223 = torch.ops.aten.add.Tensor(to_dtype_731, getitem_2682);  to_dtype_731 = getitem_2682 = None
        to_dtype_735 = torch.ops.aten.to.dtype(add_tensor_223, torch.float32);  add_tensor_223 = None
        to_dtype_736 = torch.ops.aten.to.dtype(relu__default_36, torch.float32);  relu__default_36 = None
        le_scalar_245 = torch.ops.aten.le.Scalar(to_dtype_736, 0);  to_dtype_736 = None
        new_zeros_default_570 = torch.ops.aten.new_zeros.default(to_dtype_735, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_245 = torch.ops.aten.where.self(le_scalar_245, new_zeros_default_570, to_dtype_735);  le_scalar_245 = new_zeros_default_570 = to_dtype_735 = None
        to_dtype_737 = torch.ops.aten.to.dtype(where_self_245, torch.float32);  where_self_245 = None
        native_batch_norm_backward_default_285 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_737, convolution_default_39, primals_334, primals_332, primals_333, getitem_118, getitem_119, True, 1e-05, [True, True, True]);  convolution_default_39 = primals_334 = primals_332 = primals_333 = getitem_118 = getitem_119 = None
        getitem_2685 = native_batch_norm_backward_default_285[0]
        getitem_2686 = native_batch_norm_backward_default_285[1]
        getitem_2687 = native_batch_norm_backward_default_285[2];  native_batch_norm_backward_default_285 = None
        convolution_backward_default_285 = torch.ops.aten.convolution_backward.default(getitem_2685, relu__default_35, primals_336, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2685 = primals_336 = None
        getitem_2688 = convolution_backward_default_285[0]
        getitem_2689 = convolution_backward_default_285[1]
        getitem_2690 = convolution_backward_default_285[2];  convolution_backward_default_285 = None
        to_dtype_738 = torch.ops.aten.to.dtype(getitem_2688, torch.float32);  getitem_2688 = None
        to_dtype_739 = torch.ops.aten.to.dtype(relu__default_35, torch.float32);  relu__default_35 = None
        le_scalar_246 = torch.ops.aten.le.Scalar(to_dtype_739, 0);  to_dtype_739 = None
        new_zeros_default_571 = torch.ops.aten.new_zeros.default(to_dtype_738, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_246 = torch.ops.aten.where.self(le_scalar_246, new_zeros_default_571, to_dtype_738);  le_scalar_246 = new_zeros_default_571 = to_dtype_738 = None
        to_dtype_740 = torch.ops.aten.to.dtype(where_self_246, torch.float32);  where_self_246 = None
        native_batch_norm_backward_default_286 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_740, convolution_default_38, primals_329, primals_327, primals_328, getitem_115, getitem_116, True, 1e-05, [True, True, True]);  to_dtype_740 = convolution_default_38 = primals_329 = primals_327 = primals_328 = getitem_115 = getitem_116 = None
        getitem_2691 = native_batch_norm_backward_default_286[0]
        getitem_2692 = native_batch_norm_backward_default_286[1]
        getitem_2693 = native_batch_norm_backward_default_286[2];  native_batch_norm_backward_default_286 = None
        convolution_backward_default_286 = torch.ops.aten.convolution_backward.default(getitem_2691, relu__default_34, primals_335, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2691 = primals_335 = None
        getitem_2694 = convolution_backward_default_286[0]
        getitem_2695 = convolution_backward_default_286[1]
        getitem_2696 = convolution_backward_default_286[2];  convolution_backward_default_286 = None
        add_tensor_224 = torch.ops.aten.add.Tensor(to_dtype_737, getitem_2694);  to_dtype_737 = getitem_2694 = None
        to_dtype_741 = torch.ops.aten.to.dtype(add_tensor_224, torch.float32);  add_tensor_224 = None
        to_dtype_742 = torch.ops.aten.to.dtype(relu__default_34, torch.float32);  relu__default_34 = None
        le_scalar_247 = torch.ops.aten.le.Scalar(to_dtype_742, 0);  to_dtype_742 = None
        new_zeros_default_572 = torch.ops.aten.new_zeros.default(to_dtype_741, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_247 = torch.ops.aten.where.self(le_scalar_247, new_zeros_default_572, to_dtype_741);  le_scalar_247 = new_zeros_default_572 = to_dtype_741 = None
        to_dtype_743 = torch.ops.aten.to.dtype(where_self_247, torch.float32);  where_self_247 = None
        native_batch_norm_backward_default_287 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_743, convolution_default_37, primals_322, primals_320, primals_321, getitem_112, getitem_113, True, 1e-05, [True, True, True]);  convolution_default_37 = primals_322 = primals_320 = primals_321 = getitem_112 = getitem_113 = None
        getitem_2697 = native_batch_norm_backward_default_287[0]
        getitem_2698 = native_batch_norm_backward_default_287[1]
        getitem_2699 = native_batch_norm_backward_default_287[2];  native_batch_norm_backward_default_287 = None
        convolution_backward_default_287 = torch.ops.aten.convolution_backward.default(getitem_2697, relu__default_33, primals_324, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2697 = primals_324 = None
        getitem_2700 = convolution_backward_default_287[0]
        getitem_2701 = convolution_backward_default_287[1]
        getitem_2702 = convolution_backward_default_287[2];  convolution_backward_default_287 = None
        to_dtype_744 = torch.ops.aten.to.dtype(getitem_2700, torch.float32);  getitem_2700 = None
        to_dtype_745 = torch.ops.aten.to.dtype(relu__default_33, torch.float32);  relu__default_33 = None
        le_scalar_248 = torch.ops.aten.le.Scalar(to_dtype_745, 0);  to_dtype_745 = None
        new_zeros_default_573 = torch.ops.aten.new_zeros.default(to_dtype_744, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_248 = torch.ops.aten.where.self(le_scalar_248, new_zeros_default_573, to_dtype_744);  le_scalar_248 = new_zeros_default_573 = to_dtype_744 = None
        to_dtype_746 = torch.ops.aten.to.dtype(where_self_248, torch.float32);  where_self_248 = None
        native_batch_norm_backward_default_288 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_746, convolution_default_36, primals_317, primals_315, primals_316, getitem_109, getitem_110, True, 1e-05, [True, True, True]);  to_dtype_746 = convolution_default_36 = primals_317 = primals_315 = primals_316 = getitem_109 = getitem_110 = None
        getitem_2703 = native_batch_norm_backward_default_288[0]
        getitem_2704 = native_batch_norm_backward_default_288[1]
        getitem_2705 = native_batch_norm_backward_default_288[2];  native_batch_norm_backward_default_288 = None
        convolution_backward_default_288 = torch.ops.aten.convolution_backward.default(getitem_2703, relu_default, primals_323, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2703 = primals_323 = None
        getitem_2706 = convolution_backward_default_288[0]
        getitem_2707 = convolution_backward_default_288[1]
        getitem_2708 = convolution_backward_default_288[2];  convolution_backward_default_288 = None
        add_tensor_225 = torch.ops.aten.add.Tensor(to_dtype_743, getitem_2706);  to_dtype_743 = getitem_2706 = None
        to_dtype_747 = torch.ops.aten.to.dtype(add_tensor_217, torch.float32);  add_tensor_217 = None
        to_dtype_748 = torch.ops.aten.to.dtype(relu__default_32, torch.float32);  relu__default_32 = None
        le_scalar_249 = torch.ops.aten.le.Scalar(to_dtype_748, 0);  to_dtype_748 = None
        new_zeros_default_574 = torch.ops.aten.new_zeros.default(to_dtype_747, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_249 = torch.ops.aten.where.self(le_scalar_249, new_zeros_default_574, to_dtype_747);  le_scalar_249 = new_zeros_default_574 = to_dtype_747 = None
        to_dtype_749 = torch.ops.aten.to.dtype(where_self_249, torch.float32);  where_self_249 = None
        native_batch_norm_backward_default_289 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_749, convolution_default_35, primals_1482, primals_1480, primals_1481, getitem_106, getitem_107, True, 1e-05, [True, True, True]);  to_dtype_749 = convolution_default_35 = primals_1482 = primals_1480 = primals_1481 = getitem_106 = getitem_107 = None
        getitem_2709 = native_batch_norm_backward_default_289[0]
        getitem_2710 = native_batch_norm_backward_default_289[1]
        getitem_2711 = native_batch_norm_backward_default_289[2];  native_batch_norm_backward_default_289 = None
        convolution_backward_default_289 = torch.ops.aten.convolution_backward.default(getitem_2709, relu_default_1, primals_1477, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2709 = primals_1477 = None
        getitem_2712 = convolution_backward_default_289[0]
        getitem_2713 = convolution_backward_default_289[1]
        getitem_2714 = convolution_backward_default_289[2];  convolution_backward_default_289 = None
        add_tensor_226 = torch.ops.aten.add.Tensor(add_tensor_221, getitem_2712);  add_tensor_221 = getitem_2712 = None
        to_dtype_750 = torch.ops.aten.to.dtype(add_tensor_226, torch.float32);  add_tensor_226 = None
        to_dtype_751 = torch.ops.aten.to.dtype(relu_default_1, torch.float32);  relu_default_1 = None
        le_scalar_250 = torch.ops.aten.le.Scalar(to_dtype_751, 0);  to_dtype_751 = None
        new_zeros_default_575 = torch.ops.aten.new_zeros.default(to_dtype_750, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_250 = torch.ops.aten.where.self(le_scalar_250, new_zeros_default_575, to_dtype_750);  le_scalar_250 = new_zeros_default_575 = to_dtype_750 = None
        to_dtype_752 = torch.ops.aten.to.dtype(where_self_250, torch.float32);  where_self_250 = None
        native_batch_norm_backward_default_290 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_752, convolution_default_34, primals_1494, primals_1492, primals_1493, getitem_103, getitem_104, True, 1e-05, [True, True, True]);  convolution_default_34 = primals_1494 = primals_1492 = primals_1493 = getitem_103 = getitem_104 = None
        getitem_2715 = native_batch_norm_backward_default_290[0]
        getitem_2716 = native_batch_norm_backward_default_290[1]
        getitem_2717 = native_batch_norm_backward_default_290[2];  native_batch_norm_backward_default_290 = None
        convolution_backward_default_290 = torch.ops.aten.convolution_backward.default(getitem_2715, relu__default_23, primals_1489, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2715 = primals_1489 = None
        getitem_2718 = convolution_backward_default_290[0]
        getitem_2719 = convolution_backward_default_290[1]
        getitem_2720 = convolution_backward_default_290[2];  convolution_backward_default_290 = None
        to_dtype_753 = torch.ops.aten.to.dtype(add_tensor_225, torch.float32);  add_tensor_225 = None
        to_dtype_754 = torch.ops.aten.to.dtype(relu_default, torch.float32);  relu_default = None
        le_scalar_251 = torch.ops.aten.le.Scalar(to_dtype_754, 0);  to_dtype_754 = None
        new_zeros_default_576 = torch.ops.aten.new_zeros.default(to_dtype_753, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_251 = torch.ops.aten.where.self(le_scalar_251, new_zeros_default_576, to_dtype_753);  le_scalar_251 = new_zeros_default_576 = to_dtype_753 = None
        to_dtype_755 = torch.ops.aten.to.dtype(where_self_251, torch.float32);  where_self_251 = None
        add_tensor_227 = torch.ops.aten.add.Tensor(getitem_2718, to_dtype_755);  getitem_2718 = None
        upsample_nearest2d_backward_vec_30 = torch.ops.aten.upsample_nearest2d_backward.vec(to_dtype_755, None, [128, 18, 28, 28], [2.0, 2.0]);  to_dtype_755 = None
        native_batch_norm_backward_default_291 = torch.ops.aten.native_batch_norm_backward.default(upsample_nearest2d_backward_vec_30, convolution_default_33, primals_1680, primals_1678, primals_1679, getitem_100, getitem_101, True, 1e-05, [True, True, True]);  upsample_nearest2d_backward_vec_30 = convolution_default_33 = primals_1680 = primals_1678 = primals_1679 = getitem_100 = getitem_101 = None
        getitem_2721 = native_batch_norm_backward_default_291[0]
        getitem_2722 = native_batch_norm_backward_default_291[1]
        getitem_2723 = native_batch_norm_backward_default_291[2];  native_batch_norm_backward_default_291 = None
        convolution_backward_default_291 = torch.ops.aten.convolution_backward.default(getitem_2721, relu__default_31, primals_1675, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2721 = primals_1675 = None
        getitem_2724 = convolution_backward_default_291[0]
        getitem_2725 = convolution_backward_default_291[1]
        getitem_2726 = convolution_backward_default_291[2];  convolution_backward_default_291 = None
        add_tensor_228 = torch.ops.aten.add.Tensor(to_dtype_752, getitem_2724);  to_dtype_752 = getitem_2724 = None
        to_dtype_756 = torch.ops.aten.to.dtype(add_tensor_228, torch.float32);  add_tensor_228 = None
        to_dtype_757 = torch.ops.aten.to.dtype(relu__default_31, torch.float32);  relu__default_31 = None
        le_scalar_252 = torch.ops.aten.le.Scalar(to_dtype_757, 0);  to_dtype_757 = None
        new_zeros_default_577 = torch.ops.aten.new_zeros.default(to_dtype_756, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_252 = torch.ops.aten.where.self(le_scalar_252, new_zeros_default_577, to_dtype_756);  le_scalar_252 = new_zeros_default_577 = to_dtype_756 = None
        to_dtype_758 = torch.ops.aten.to.dtype(where_self_252, torch.float32);  where_self_252 = None
        native_batch_norm_backward_default_292 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_758, convolution_default_32, primals_310, primals_308, primals_309, getitem_97, getitem_98, True, 1e-05, [True, True, True]);  convolution_default_32 = primals_310 = primals_308 = primals_309 = getitem_97 = getitem_98 = None
        getitem_2727 = native_batch_norm_backward_default_292[0]
        getitem_2728 = native_batch_norm_backward_default_292[1]
        getitem_2729 = native_batch_norm_backward_default_292[2];  native_batch_norm_backward_default_292 = None
        convolution_backward_default_292 = torch.ops.aten.convolution_backward.default(getitem_2727, relu__default_30, primals_312, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2727 = primals_312 = None
        getitem_2730 = convolution_backward_default_292[0]
        getitem_2731 = convolution_backward_default_292[1]
        getitem_2732 = convolution_backward_default_292[2];  convolution_backward_default_292 = None
        to_dtype_759 = torch.ops.aten.to.dtype(getitem_2730, torch.float32);  getitem_2730 = None
        to_dtype_760 = torch.ops.aten.to.dtype(relu__default_30, torch.float32);  relu__default_30 = None
        le_scalar_253 = torch.ops.aten.le.Scalar(to_dtype_760, 0);  to_dtype_760 = None
        new_zeros_default_578 = torch.ops.aten.new_zeros.default(to_dtype_759, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_253 = torch.ops.aten.where.self(le_scalar_253, new_zeros_default_578, to_dtype_759);  le_scalar_253 = new_zeros_default_578 = to_dtype_759 = None
        to_dtype_761 = torch.ops.aten.to.dtype(where_self_253, torch.float32);  where_self_253 = None
        native_batch_norm_backward_default_293 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_761, convolution_default_31, primals_305, primals_303, primals_304, getitem_94, getitem_95, True, 1e-05, [True, True, True]);  to_dtype_761 = convolution_default_31 = primals_305 = primals_303 = primals_304 = getitem_94 = getitem_95 = None
        getitem_2733 = native_batch_norm_backward_default_293[0]
        getitem_2734 = native_batch_norm_backward_default_293[1]
        getitem_2735 = native_batch_norm_backward_default_293[2];  native_batch_norm_backward_default_293 = None
        convolution_backward_default_293 = torch.ops.aten.convolution_backward.default(getitem_2733, relu__default_29, primals_311, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2733 = primals_311 = None
        getitem_2736 = convolution_backward_default_293[0]
        getitem_2737 = convolution_backward_default_293[1]
        getitem_2738 = convolution_backward_default_293[2];  convolution_backward_default_293 = None
        add_tensor_229 = torch.ops.aten.add.Tensor(to_dtype_758, getitem_2736);  to_dtype_758 = getitem_2736 = None
        to_dtype_762 = torch.ops.aten.to.dtype(add_tensor_229, torch.float32);  add_tensor_229 = None
        to_dtype_763 = torch.ops.aten.to.dtype(relu__default_29, torch.float32);  relu__default_29 = None
        le_scalar_254 = torch.ops.aten.le.Scalar(to_dtype_763, 0);  to_dtype_763 = None
        new_zeros_default_579 = torch.ops.aten.new_zeros.default(to_dtype_762, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_254 = torch.ops.aten.where.self(le_scalar_254, new_zeros_default_579, to_dtype_762);  le_scalar_254 = new_zeros_default_579 = to_dtype_762 = None
        to_dtype_764 = torch.ops.aten.to.dtype(where_self_254, torch.float32);  where_self_254 = None
        native_batch_norm_backward_default_294 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_764, convolution_default_30, primals_298, primals_296, primals_297, getitem_91, getitem_92, True, 1e-05, [True, True, True]);  convolution_default_30 = primals_298 = primals_296 = primals_297 = getitem_91 = getitem_92 = None
        getitem_2739 = native_batch_norm_backward_default_294[0]
        getitem_2740 = native_batch_norm_backward_default_294[1]
        getitem_2741 = native_batch_norm_backward_default_294[2];  native_batch_norm_backward_default_294 = None
        convolution_backward_default_294 = torch.ops.aten.convolution_backward.default(getitem_2739, relu__default_28, primals_300, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2739 = primals_300 = None
        getitem_2742 = convolution_backward_default_294[0]
        getitem_2743 = convolution_backward_default_294[1]
        getitem_2744 = convolution_backward_default_294[2];  convolution_backward_default_294 = None
        to_dtype_765 = torch.ops.aten.to.dtype(getitem_2742, torch.float32);  getitem_2742 = None
        to_dtype_766 = torch.ops.aten.to.dtype(relu__default_28, torch.float32);  relu__default_28 = None
        le_scalar_255 = torch.ops.aten.le.Scalar(to_dtype_766, 0);  to_dtype_766 = None
        new_zeros_default_580 = torch.ops.aten.new_zeros.default(to_dtype_765, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_255 = torch.ops.aten.where.self(le_scalar_255, new_zeros_default_580, to_dtype_765);  le_scalar_255 = new_zeros_default_580 = to_dtype_765 = None
        to_dtype_767 = torch.ops.aten.to.dtype(where_self_255, torch.float32);  where_self_255 = None
        native_batch_norm_backward_default_295 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_767, convolution_default_29, primals_293, primals_291, primals_292, getitem_88, getitem_89, True, 1e-05, [True, True, True]);  to_dtype_767 = convolution_default_29 = primals_293 = primals_291 = primals_292 = getitem_88 = getitem_89 = None
        getitem_2745 = native_batch_norm_backward_default_295[0]
        getitem_2746 = native_batch_norm_backward_default_295[1]
        getitem_2747 = native_batch_norm_backward_default_295[2];  native_batch_norm_backward_default_295 = None
        convolution_backward_default_295 = torch.ops.aten.convolution_backward.default(getitem_2745, relu__default_27, primals_299, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2745 = primals_299 = None
        getitem_2748 = convolution_backward_default_295[0]
        getitem_2749 = convolution_backward_default_295[1]
        getitem_2750 = convolution_backward_default_295[2];  convolution_backward_default_295 = None
        add_tensor_230 = torch.ops.aten.add.Tensor(to_dtype_764, getitem_2748);  to_dtype_764 = getitem_2748 = None
        to_dtype_768 = torch.ops.aten.to.dtype(add_tensor_230, torch.float32);  add_tensor_230 = None
        to_dtype_769 = torch.ops.aten.to.dtype(relu__default_27, torch.float32);  relu__default_27 = None
        le_scalar_256 = torch.ops.aten.le.Scalar(to_dtype_769, 0);  to_dtype_769 = None
        new_zeros_default_581 = torch.ops.aten.new_zeros.default(to_dtype_768, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_256 = torch.ops.aten.where.self(le_scalar_256, new_zeros_default_581, to_dtype_768);  le_scalar_256 = new_zeros_default_581 = to_dtype_768 = None
        to_dtype_770 = torch.ops.aten.to.dtype(where_self_256, torch.float32);  where_self_256 = None
        native_batch_norm_backward_default_296 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_770, convolution_default_28, primals_286, primals_284, primals_285, getitem_85, getitem_86, True, 1e-05, [True, True, True]);  convolution_default_28 = primals_286 = primals_284 = primals_285 = getitem_85 = getitem_86 = None
        getitem_2751 = native_batch_norm_backward_default_296[0]
        getitem_2752 = native_batch_norm_backward_default_296[1]
        getitem_2753 = native_batch_norm_backward_default_296[2];  native_batch_norm_backward_default_296 = None
        convolution_backward_default_296 = torch.ops.aten.convolution_backward.default(getitem_2751, relu__default_26, primals_288, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2751 = primals_288 = None
        getitem_2754 = convolution_backward_default_296[0]
        getitem_2755 = convolution_backward_default_296[1]
        getitem_2756 = convolution_backward_default_296[2];  convolution_backward_default_296 = None
        to_dtype_771 = torch.ops.aten.to.dtype(getitem_2754, torch.float32);  getitem_2754 = None
        to_dtype_772 = torch.ops.aten.to.dtype(relu__default_26, torch.float32);  relu__default_26 = None
        le_scalar_257 = torch.ops.aten.le.Scalar(to_dtype_772, 0);  to_dtype_772 = None
        new_zeros_default_582 = torch.ops.aten.new_zeros.default(to_dtype_771, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_257 = torch.ops.aten.where.self(le_scalar_257, new_zeros_default_582, to_dtype_771);  le_scalar_257 = new_zeros_default_582 = to_dtype_771 = None
        to_dtype_773 = torch.ops.aten.to.dtype(where_self_257, torch.float32);  where_self_257 = None
        native_batch_norm_backward_default_297 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_773, convolution_default_27, primals_281, primals_279, primals_280, getitem_82, getitem_83, True, 1e-05, [True, True, True]);  to_dtype_773 = convolution_default_27 = primals_281 = primals_279 = primals_280 = getitem_82 = getitem_83 = None
        getitem_2757 = native_batch_norm_backward_default_297[0]
        getitem_2758 = native_batch_norm_backward_default_297[1]
        getitem_2759 = native_batch_norm_backward_default_297[2];  native_batch_norm_backward_default_297 = None
        convolution_backward_default_297 = torch.ops.aten.convolution_backward.default(getitem_2757, relu__default_25, primals_287, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2757 = primals_287 = None
        getitem_2760 = convolution_backward_default_297[0]
        getitem_2761 = convolution_backward_default_297[1]
        getitem_2762 = convolution_backward_default_297[2];  convolution_backward_default_297 = None
        add_tensor_231 = torch.ops.aten.add.Tensor(to_dtype_770, getitem_2760);  to_dtype_770 = getitem_2760 = None
        to_dtype_774 = torch.ops.aten.to.dtype(add_tensor_231, torch.float32);  add_tensor_231 = None
        to_dtype_775 = torch.ops.aten.to.dtype(relu__default_25, torch.float32);  relu__default_25 = None
        le_scalar_258 = torch.ops.aten.le.Scalar(to_dtype_775, 0);  to_dtype_775 = None
        new_zeros_default_583 = torch.ops.aten.new_zeros.default(to_dtype_774, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_258 = torch.ops.aten.where.self(le_scalar_258, new_zeros_default_583, to_dtype_774);  le_scalar_258 = new_zeros_default_583 = to_dtype_774 = None
        to_dtype_776 = torch.ops.aten.to.dtype(where_self_258, torch.float32);  where_self_258 = None
        native_batch_norm_backward_default_298 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_776, convolution_default_26, primals_274, primals_272, primals_273, getitem_79, getitem_80, True, 1e-05, [True, True, True]);  convolution_default_26 = primals_274 = primals_272 = primals_273 = getitem_79 = getitem_80 = None
        getitem_2763 = native_batch_norm_backward_default_298[0]
        getitem_2764 = native_batch_norm_backward_default_298[1]
        getitem_2765 = native_batch_norm_backward_default_298[2];  native_batch_norm_backward_default_298 = None
        convolution_backward_default_298 = torch.ops.aten.convolution_backward.default(getitem_2763, relu__default_24, primals_276, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2763 = primals_276 = None
        getitem_2766 = convolution_backward_default_298[0]
        getitem_2767 = convolution_backward_default_298[1]
        getitem_2768 = convolution_backward_default_298[2];  convolution_backward_default_298 = None
        to_dtype_777 = torch.ops.aten.to.dtype(getitem_2766, torch.float32);  getitem_2766 = None
        to_dtype_778 = torch.ops.aten.to.dtype(relu__default_24, torch.float32);  relu__default_24 = None
        le_scalar_259 = torch.ops.aten.le.Scalar(to_dtype_778, 0);  to_dtype_778 = None
        new_zeros_default_584 = torch.ops.aten.new_zeros.default(to_dtype_777, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_259 = torch.ops.aten.where.self(le_scalar_259, new_zeros_default_584, to_dtype_777);  le_scalar_259 = new_zeros_default_584 = to_dtype_777 = None
        to_dtype_779 = torch.ops.aten.to.dtype(where_self_259, torch.float32);  where_self_259 = None
        native_batch_norm_backward_default_299 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_779, convolution_default_25, primals_269, primals_267, primals_268, getitem_76, getitem_77, True, 1e-05, [True, True, True]);  to_dtype_779 = convolution_default_25 = primals_269 = primals_267 = primals_268 = getitem_76 = getitem_77 = None
        getitem_2769 = native_batch_norm_backward_default_299[0]
        getitem_2770 = native_batch_norm_backward_default_299[1]
        getitem_2771 = native_batch_norm_backward_default_299[2];  native_batch_norm_backward_default_299 = None
        convolution_backward_default_299 = torch.ops.aten.convolution_backward.default(getitem_2769, relu__default_15, primals_275, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2769 = primals_275 = None
        getitem_2772 = convolution_backward_default_299[0]
        getitem_2773 = convolution_backward_default_299[1]
        getitem_2774 = convolution_backward_default_299[2];  convolution_backward_default_299 = None
        add_tensor_232 = torch.ops.aten.add.Tensor(to_dtype_776, getitem_2772);  to_dtype_776 = getitem_2772 = None
        to_dtype_780 = torch.ops.aten.to.dtype(add_tensor_227, torch.float32);  add_tensor_227 = None
        to_dtype_781 = torch.ops.aten.to.dtype(relu__default_23, torch.float32);  relu__default_23 = None
        le_scalar_260 = torch.ops.aten.le.Scalar(to_dtype_781, 0);  to_dtype_781 = None
        new_zeros_default_585 = torch.ops.aten.new_zeros.default(to_dtype_780, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_260 = torch.ops.aten.where.self(le_scalar_260, new_zeros_default_585, to_dtype_780);  le_scalar_260 = new_zeros_default_585 = to_dtype_780 = None
        to_dtype_782 = torch.ops.aten.to.dtype(where_self_260, torch.float32);  where_self_260 = None
        native_batch_norm_backward_default_300 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_782, convolution_default_24, primals_262, primals_260, primals_261, getitem_73, getitem_74, True, 1e-05, [True, True, True]);  convolution_default_24 = primals_262 = primals_260 = primals_261 = getitem_73 = getitem_74 = None
        getitem_2775 = native_batch_norm_backward_default_300[0]
        getitem_2776 = native_batch_norm_backward_default_300[1]
        getitem_2777 = native_batch_norm_backward_default_300[2];  native_batch_norm_backward_default_300 = None
        convolution_backward_default_300 = torch.ops.aten.convolution_backward.default(getitem_2775, relu__default_22, primals_264, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2775 = primals_264 = None
        getitem_2778 = convolution_backward_default_300[0]
        getitem_2779 = convolution_backward_default_300[1]
        getitem_2780 = convolution_backward_default_300[2];  convolution_backward_default_300 = None
        to_dtype_783 = torch.ops.aten.to.dtype(getitem_2778, torch.float32);  getitem_2778 = None
        to_dtype_784 = torch.ops.aten.to.dtype(relu__default_22, torch.float32);  relu__default_22 = None
        le_scalar_261 = torch.ops.aten.le.Scalar(to_dtype_784, 0);  to_dtype_784 = None
        new_zeros_default_586 = torch.ops.aten.new_zeros.default(to_dtype_783, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_261 = torch.ops.aten.where.self(le_scalar_261, new_zeros_default_586, to_dtype_783);  le_scalar_261 = new_zeros_default_586 = to_dtype_783 = None
        to_dtype_785 = torch.ops.aten.to.dtype(where_self_261, torch.float32);  where_self_261 = None
        native_batch_norm_backward_default_301 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_785, convolution_default_23, primals_257, primals_255, primals_256, getitem_70, getitem_71, True, 1e-05, [True, True, True]);  to_dtype_785 = convolution_default_23 = primals_257 = primals_255 = primals_256 = getitem_70 = getitem_71 = None
        getitem_2781 = native_batch_norm_backward_default_301[0]
        getitem_2782 = native_batch_norm_backward_default_301[1]
        getitem_2783 = native_batch_norm_backward_default_301[2];  native_batch_norm_backward_default_301 = None
        convolution_backward_default_301 = torch.ops.aten.convolution_backward.default(getitem_2781, relu__default_21, primals_263, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2781 = primals_263 = None
        getitem_2784 = convolution_backward_default_301[0]
        getitem_2785 = convolution_backward_default_301[1]
        getitem_2786 = convolution_backward_default_301[2];  convolution_backward_default_301 = None
        add_tensor_233 = torch.ops.aten.add.Tensor(to_dtype_782, getitem_2784);  to_dtype_782 = getitem_2784 = None
        to_dtype_786 = torch.ops.aten.to.dtype(add_tensor_233, torch.float32);  add_tensor_233 = None
        to_dtype_787 = torch.ops.aten.to.dtype(relu__default_21, torch.float32);  relu__default_21 = None
        le_scalar_262 = torch.ops.aten.le.Scalar(to_dtype_787, 0);  to_dtype_787 = None
        new_zeros_default_587 = torch.ops.aten.new_zeros.default(to_dtype_786, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_262 = torch.ops.aten.where.self(le_scalar_262, new_zeros_default_587, to_dtype_786);  le_scalar_262 = new_zeros_default_587 = to_dtype_786 = None
        to_dtype_788 = torch.ops.aten.to.dtype(where_self_262, torch.float32);  where_self_262 = None
        native_batch_norm_backward_default_302 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_788, convolution_default_22, primals_250, primals_248, primals_249, getitem_67, getitem_68, True, 1e-05, [True, True, True]);  convolution_default_22 = primals_250 = primals_248 = primals_249 = getitem_67 = getitem_68 = None
        getitem_2787 = native_batch_norm_backward_default_302[0]
        getitem_2788 = native_batch_norm_backward_default_302[1]
        getitem_2789 = native_batch_norm_backward_default_302[2];  native_batch_norm_backward_default_302 = None
        convolution_backward_default_302 = torch.ops.aten.convolution_backward.default(getitem_2787, relu__default_20, primals_252, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2787 = primals_252 = None
        getitem_2790 = convolution_backward_default_302[0]
        getitem_2791 = convolution_backward_default_302[1]
        getitem_2792 = convolution_backward_default_302[2];  convolution_backward_default_302 = None
        to_dtype_789 = torch.ops.aten.to.dtype(getitem_2790, torch.float32);  getitem_2790 = None
        to_dtype_790 = torch.ops.aten.to.dtype(relu__default_20, torch.float32);  relu__default_20 = None
        le_scalar_263 = torch.ops.aten.le.Scalar(to_dtype_790, 0);  to_dtype_790 = None
        new_zeros_default_588 = torch.ops.aten.new_zeros.default(to_dtype_789, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_263 = torch.ops.aten.where.self(le_scalar_263, new_zeros_default_588, to_dtype_789);  le_scalar_263 = new_zeros_default_588 = to_dtype_789 = None
        to_dtype_791 = torch.ops.aten.to.dtype(where_self_263, torch.float32);  where_self_263 = None
        native_batch_norm_backward_default_303 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_791, convolution_default_21, primals_245, primals_243, primals_244, getitem_64, getitem_65, True, 1e-05, [True, True, True]);  to_dtype_791 = convolution_default_21 = primals_245 = primals_243 = primals_244 = getitem_64 = getitem_65 = None
        getitem_2793 = native_batch_norm_backward_default_303[0]
        getitem_2794 = native_batch_norm_backward_default_303[1]
        getitem_2795 = native_batch_norm_backward_default_303[2];  native_batch_norm_backward_default_303 = None
        convolution_backward_default_303 = torch.ops.aten.convolution_backward.default(getitem_2793, relu__default_19, primals_251, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2793 = primals_251 = None
        getitem_2796 = convolution_backward_default_303[0]
        getitem_2797 = convolution_backward_default_303[1]
        getitem_2798 = convolution_backward_default_303[2];  convolution_backward_default_303 = None
        add_tensor_234 = torch.ops.aten.add.Tensor(to_dtype_788, getitem_2796);  to_dtype_788 = getitem_2796 = None
        to_dtype_792 = torch.ops.aten.to.dtype(add_tensor_234, torch.float32);  add_tensor_234 = None
        to_dtype_793 = torch.ops.aten.to.dtype(relu__default_19, torch.float32);  relu__default_19 = None
        le_scalar_264 = torch.ops.aten.le.Scalar(to_dtype_793, 0);  to_dtype_793 = None
        new_zeros_default_589 = torch.ops.aten.new_zeros.default(to_dtype_792, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_264 = torch.ops.aten.where.self(le_scalar_264, new_zeros_default_589, to_dtype_792);  le_scalar_264 = new_zeros_default_589 = to_dtype_792 = None
        to_dtype_794 = torch.ops.aten.to.dtype(where_self_264, torch.float32);  where_self_264 = None
        native_batch_norm_backward_default_304 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_794, convolution_default_20, primals_238, primals_236, primals_237, getitem_61, getitem_62, True, 1e-05, [True, True, True]);  convolution_default_20 = primals_238 = primals_236 = primals_237 = getitem_61 = getitem_62 = None
        getitem_2799 = native_batch_norm_backward_default_304[0]
        getitem_2800 = native_batch_norm_backward_default_304[1]
        getitem_2801 = native_batch_norm_backward_default_304[2];  native_batch_norm_backward_default_304 = None
        convolution_backward_default_304 = torch.ops.aten.convolution_backward.default(getitem_2799, relu__default_18, primals_240, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2799 = primals_240 = None
        getitem_2802 = convolution_backward_default_304[0]
        getitem_2803 = convolution_backward_default_304[1]
        getitem_2804 = convolution_backward_default_304[2];  convolution_backward_default_304 = None
        to_dtype_795 = torch.ops.aten.to.dtype(getitem_2802, torch.float32);  getitem_2802 = None
        to_dtype_796 = torch.ops.aten.to.dtype(relu__default_18, torch.float32);  relu__default_18 = None
        le_scalar_265 = torch.ops.aten.le.Scalar(to_dtype_796, 0);  to_dtype_796 = None
        new_zeros_default_590 = torch.ops.aten.new_zeros.default(to_dtype_795, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_265 = torch.ops.aten.where.self(le_scalar_265, new_zeros_default_590, to_dtype_795);  le_scalar_265 = new_zeros_default_590 = to_dtype_795 = None
        to_dtype_797 = torch.ops.aten.to.dtype(where_self_265, torch.float32);  where_self_265 = None
        native_batch_norm_backward_default_305 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_797, convolution_default_19, primals_233, primals_231, primals_232, getitem_58, getitem_59, True, 1e-05, [True, True, True]);  to_dtype_797 = convolution_default_19 = primals_233 = primals_231 = primals_232 = getitem_58 = getitem_59 = None
        getitem_2805 = native_batch_norm_backward_default_305[0]
        getitem_2806 = native_batch_norm_backward_default_305[1]
        getitem_2807 = native_batch_norm_backward_default_305[2];  native_batch_norm_backward_default_305 = None
        convolution_backward_default_305 = torch.ops.aten.convolution_backward.default(getitem_2805, relu__default_17, primals_239, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2805 = primals_239 = None
        getitem_2808 = convolution_backward_default_305[0]
        getitem_2809 = convolution_backward_default_305[1]
        getitem_2810 = convolution_backward_default_305[2];  convolution_backward_default_305 = None
        add_tensor_235 = torch.ops.aten.add.Tensor(to_dtype_794, getitem_2808);  to_dtype_794 = getitem_2808 = None
        to_dtype_798 = torch.ops.aten.to.dtype(add_tensor_235, torch.float32);  add_tensor_235 = None
        to_dtype_799 = torch.ops.aten.to.dtype(relu__default_17, torch.float32);  relu__default_17 = None
        le_scalar_266 = torch.ops.aten.le.Scalar(to_dtype_799, 0);  to_dtype_799 = None
        new_zeros_default_591 = torch.ops.aten.new_zeros.default(to_dtype_798, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_266 = torch.ops.aten.where.self(le_scalar_266, new_zeros_default_591, to_dtype_798);  le_scalar_266 = new_zeros_default_591 = to_dtype_798 = None
        to_dtype_800 = torch.ops.aten.to.dtype(where_self_266, torch.float32);  where_self_266 = None
        native_batch_norm_backward_default_306 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_800, convolution_default_18, primals_226, primals_224, primals_225, getitem_55, getitem_56, True, 1e-05, [True, True, True]);  convolution_default_18 = primals_226 = primals_224 = primals_225 = getitem_55 = getitem_56 = None
        getitem_2811 = native_batch_norm_backward_default_306[0]
        getitem_2812 = native_batch_norm_backward_default_306[1]
        getitem_2813 = native_batch_norm_backward_default_306[2];  native_batch_norm_backward_default_306 = None
        convolution_backward_default_306 = torch.ops.aten.convolution_backward.default(getitem_2811, relu__default_16, primals_228, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2811 = primals_228 = None
        getitem_2814 = convolution_backward_default_306[0]
        getitem_2815 = convolution_backward_default_306[1]
        getitem_2816 = convolution_backward_default_306[2];  convolution_backward_default_306 = None
        to_dtype_801 = torch.ops.aten.to.dtype(getitem_2814, torch.float32);  getitem_2814 = None
        to_dtype_802 = torch.ops.aten.to.dtype(relu__default_16, torch.float32);  relu__default_16 = None
        le_scalar_267 = torch.ops.aten.le.Scalar(to_dtype_802, 0);  to_dtype_802 = None
        new_zeros_default_592 = torch.ops.aten.new_zeros.default(to_dtype_801, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_267 = torch.ops.aten.where.self(le_scalar_267, new_zeros_default_592, to_dtype_801);  le_scalar_267 = new_zeros_default_592 = to_dtype_801 = None
        to_dtype_803 = torch.ops.aten.to.dtype(where_self_267, torch.float32);  where_self_267 = None
        native_batch_norm_backward_default_307 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_803, convolution_default_17, primals_221, primals_219, primals_220, getitem_52, getitem_53, True, 1e-05, [True, True, True]);  to_dtype_803 = convolution_default_17 = primals_221 = primals_219 = primals_220 = getitem_52 = getitem_53 = None
        getitem_2817 = native_batch_norm_backward_default_307[0]
        getitem_2818 = native_batch_norm_backward_default_307[1]
        getitem_2819 = native_batch_norm_backward_default_307[2];  native_batch_norm_backward_default_307 = None
        convolution_backward_default_307 = torch.ops.aten.convolution_backward.default(getitem_2817, relu__default_14, primals_227, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2817 = primals_227 = None
        getitem_2820 = convolution_backward_default_307[0]
        getitem_2821 = convolution_backward_default_307[1]
        getitem_2822 = convolution_backward_default_307[2];  convolution_backward_default_307 = None
        add_tensor_236 = torch.ops.aten.add.Tensor(to_dtype_800, getitem_2820);  to_dtype_800 = getitem_2820 = None
        to_dtype_804 = torch.ops.aten.to.dtype(add_tensor_232, torch.float32);  add_tensor_232 = None
        to_dtype_805 = torch.ops.aten.to.dtype(relu__default_15, torch.float32);  relu__default_15 = None
        le_scalar_268 = torch.ops.aten.le.Scalar(to_dtype_805, 0);  to_dtype_805 = None
        new_zeros_default_593 = torch.ops.aten.new_zeros.default(to_dtype_804, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_268 = torch.ops.aten.where.self(le_scalar_268, new_zeros_default_593, to_dtype_804);  le_scalar_268 = new_zeros_default_593 = to_dtype_804 = None
        to_dtype_806 = torch.ops.aten.to.dtype(where_self_268, torch.float32);  where_self_268 = None
        native_batch_norm_backward_default_308 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_806, convolution_default_16, primals_1476, primals_1474, primals_1475, getitem_49, getitem_50, True, 1e-05, [True, True, True]);  to_dtype_806 = convolution_default_16 = primals_1476 = primals_1474 = primals_1475 = getitem_49 = getitem_50 = None
        getitem_2823 = native_batch_norm_backward_default_308[0]
        getitem_2824 = native_batch_norm_backward_default_308[1]
        getitem_2825 = native_batch_norm_backward_default_308[2];  native_batch_norm_backward_default_308 = None
        convolution_backward_default_308 = torch.ops.aten.convolution_backward.default(getitem_2823, relu__default_13, primals_1471, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2823 = primals_1471 = None
        getitem_2826 = convolution_backward_default_308[0]
        getitem_2827 = convolution_backward_default_308[1]
        getitem_2828 = convolution_backward_default_308[2];  convolution_backward_default_308 = None
        to_dtype_807 = torch.ops.aten.to.dtype(add_tensor_236, torch.float32);  add_tensor_236 = None
        to_dtype_808 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar_269 = torch.ops.aten.le.Scalar(to_dtype_808, 0);  to_dtype_808 = None
        new_zeros_default_594 = torch.ops.aten.new_zeros.default(to_dtype_807, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_269 = torch.ops.aten.where.self(le_scalar_269, new_zeros_default_594, to_dtype_807);  le_scalar_269 = new_zeros_default_594 = to_dtype_807 = None
        to_dtype_809 = torch.ops.aten.to.dtype(where_self_269, torch.float32);  where_self_269 = None
        native_batch_norm_backward_default_309 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_809, convolution_default_15, primals_1470, primals_1468, primals_1469, getitem_46, getitem_47, True, 1e-05, [True, True, True]);  to_dtype_809 = convolution_default_15 = primals_1470 = primals_1468 = primals_1469 = getitem_46 = getitem_47 = None
        getitem_2829 = native_batch_norm_backward_default_309[0]
        getitem_2830 = native_batch_norm_backward_default_309[1]
        getitem_2831 = native_batch_norm_backward_default_309[2];  native_batch_norm_backward_default_309 = None
        convolution_backward_default_309 = torch.ops.aten.convolution_backward.default(getitem_2829, relu__default_13, primals_1465, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2829 = primals_1465 = None
        getitem_2832 = convolution_backward_default_309[0]
        getitem_2833 = convolution_backward_default_309[1]
        getitem_2834 = convolution_backward_default_309[2];  convolution_backward_default_309 = None
        add_tensor_237 = torch.ops.aten.add.Tensor(getitem_2826, getitem_2832);  getitem_2826 = getitem_2832 = None
        to_dtype_810 = torch.ops.aten.to.dtype(add_tensor_237, torch.float32);  add_tensor_237 = None
        to_dtype_811 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_270 = torch.ops.aten.le.Scalar(to_dtype_811, 0);  to_dtype_811 = None
        new_zeros_default_595 = torch.ops.aten.new_zeros.default(to_dtype_810, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_270 = torch.ops.aten.where.self(le_scalar_270, new_zeros_default_595, to_dtype_810);  le_scalar_270 = new_zeros_default_595 = to_dtype_810 = None
        to_dtype_812 = torch.ops.aten.to.dtype(where_self_270, torch.float32);  where_self_270 = None
        native_batch_norm_backward_default_310 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_812, convolution_default_14, primals_213, primals_211, primals_212, getitem_43, getitem_44, True, 1e-05, [True, True, True]);  convolution_default_14 = primals_213 = primals_211 = primals_212 = getitem_43 = getitem_44 = None
        getitem_2835 = native_batch_norm_backward_default_310[0]
        getitem_2836 = native_batch_norm_backward_default_310[1]
        getitem_2837 = native_batch_norm_backward_default_310[2];  native_batch_norm_backward_default_310 = None
        convolution_backward_default_310 = torch.ops.aten.convolution_backward.default(getitem_2835, relu__default_12, primals_216, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2835 = primals_216 = None
        getitem_2838 = convolution_backward_default_310[0]
        getitem_2839 = convolution_backward_default_310[1]
        getitem_2840 = convolution_backward_default_310[2];  convolution_backward_default_310 = None
        to_dtype_813 = torch.ops.aten.to.dtype(getitem_2838, torch.float32);  getitem_2838 = None
        to_dtype_814 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_271 = torch.ops.aten.le.Scalar(to_dtype_814, 0);  to_dtype_814 = None
        new_zeros_default_596 = torch.ops.aten.new_zeros.default(to_dtype_813, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_271 = torch.ops.aten.where.self(le_scalar_271, new_zeros_default_596, to_dtype_813);  le_scalar_271 = new_zeros_default_596 = to_dtype_813 = None
        to_dtype_815 = torch.ops.aten.to.dtype(where_self_271, torch.float32);  where_self_271 = None
        native_batch_norm_backward_default_311 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_815, convolution_default_13, primals_208, primals_206, primals_207, getitem_40, getitem_41, True, 1e-05, [True, True, True]);  to_dtype_815 = convolution_default_13 = primals_208 = primals_206 = primals_207 = getitem_40 = getitem_41 = None
        getitem_2841 = native_batch_norm_backward_default_311[0]
        getitem_2842 = native_batch_norm_backward_default_311[1]
        getitem_2843 = native_batch_norm_backward_default_311[2];  native_batch_norm_backward_default_311 = None
        convolution_backward_default_311 = torch.ops.aten.convolution_backward.default(getitem_2841, relu__default_11, primals_215, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2841 = primals_215 = None
        getitem_2844 = convolution_backward_default_311[0]
        getitem_2845 = convolution_backward_default_311[1]
        getitem_2846 = convolution_backward_default_311[2];  convolution_backward_default_311 = None
        to_dtype_816 = torch.ops.aten.to.dtype(getitem_2844, torch.float32);  getitem_2844 = None
        to_dtype_817 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_272 = torch.ops.aten.le.Scalar(to_dtype_817, 0);  to_dtype_817 = None
        new_zeros_default_597 = torch.ops.aten.new_zeros.default(to_dtype_816, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_272 = torch.ops.aten.where.self(le_scalar_272, new_zeros_default_597, to_dtype_816);  le_scalar_272 = new_zeros_default_597 = to_dtype_816 = None
        to_dtype_818 = torch.ops.aten.to.dtype(where_self_272, torch.float32);  where_self_272 = None
        native_batch_norm_backward_default_312 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_818, convolution_default_12, primals_203, primals_201, primals_202, getitem_37, getitem_38, True, 1e-05, [True, True, True]);  to_dtype_818 = convolution_default_12 = primals_203 = primals_201 = primals_202 = getitem_37 = getitem_38 = None
        getitem_2847 = native_batch_norm_backward_default_312[0]
        getitem_2848 = native_batch_norm_backward_default_312[1]
        getitem_2849 = native_batch_norm_backward_default_312[2];  native_batch_norm_backward_default_312 = None
        convolution_backward_default_312 = torch.ops.aten.convolution_backward.default(getitem_2847, relu__default_10, primals_214, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2847 = primals_214 = None
        getitem_2850 = convolution_backward_default_312[0]
        getitem_2851 = convolution_backward_default_312[1]
        getitem_2852 = convolution_backward_default_312[2];  convolution_backward_default_312 = None
        add_tensor_238 = torch.ops.aten.add.Tensor(to_dtype_812, getitem_2850);  to_dtype_812 = getitem_2850 = None
        to_dtype_819 = torch.ops.aten.to.dtype(add_tensor_238, torch.float32);  add_tensor_238 = None
        to_dtype_820 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_273 = torch.ops.aten.le.Scalar(to_dtype_820, 0);  to_dtype_820 = None
        new_zeros_default_598 = torch.ops.aten.new_zeros.default(to_dtype_819, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_273 = torch.ops.aten.where.self(le_scalar_273, new_zeros_default_598, to_dtype_819);  le_scalar_273 = new_zeros_default_598 = to_dtype_819 = None
        to_dtype_821 = torch.ops.aten.to.dtype(where_self_273, torch.float32);  where_self_273 = None
        native_batch_norm_backward_default_313 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_821, convolution_default_11, primals_195, primals_193, primals_194, getitem_34, getitem_35, True, 1e-05, [True, True, True]);  convolution_default_11 = primals_195 = primals_193 = primals_194 = getitem_34 = getitem_35 = None
        getitem_2853 = native_batch_norm_backward_default_313[0]
        getitem_2854 = native_batch_norm_backward_default_313[1]
        getitem_2855 = native_batch_norm_backward_default_313[2];  native_batch_norm_backward_default_313 = None
        convolution_backward_default_313 = torch.ops.aten.convolution_backward.default(getitem_2853, relu__default_9, primals_198, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2853 = primals_198 = None
        getitem_2856 = convolution_backward_default_313[0]
        getitem_2857 = convolution_backward_default_313[1]
        getitem_2858 = convolution_backward_default_313[2];  convolution_backward_default_313 = None
        to_dtype_822 = torch.ops.aten.to.dtype(getitem_2856, torch.float32);  getitem_2856 = None
        to_dtype_823 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_274 = torch.ops.aten.le.Scalar(to_dtype_823, 0);  to_dtype_823 = None
        new_zeros_default_599 = torch.ops.aten.new_zeros.default(to_dtype_822, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_274 = torch.ops.aten.where.self(le_scalar_274, new_zeros_default_599, to_dtype_822);  le_scalar_274 = new_zeros_default_599 = to_dtype_822 = None
        to_dtype_824 = torch.ops.aten.to.dtype(where_self_274, torch.float32);  where_self_274 = None
        native_batch_norm_backward_default_314 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_824, convolution_default_10, primals_190, primals_188, primals_189, getitem_31, getitem_32, True, 1e-05, [True, True, True]);  to_dtype_824 = convolution_default_10 = primals_190 = primals_188 = primals_189 = getitem_31 = getitem_32 = None
        getitem_2859 = native_batch_norm_backward_default_314[0]
        getitem_2860 = native_batch_norm_backward_default_314[1]
        getitem_2861 = native_batch_norm_backward_default_314[2];  native_batch_norm_backward_default_314 = None
        convolution_backward_default_314 = torch.ops.aten.convolution_backward.default(getitem_2859, relu__default_8, primals_197, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2859 = primals_197 = None
        getitem_2862 = convolution_backward_default_314[0]
        getitem_2863 = convolution_backward_default_314[1]
        getitem_2864 = convolution_backward_default_314[2];  convolution_backward_default_314 = None
        to_dtype_825 = torch.ops.aten.to.dtype(getitem_2862, torch.float32);  getitem_2862 = None
        to_dtype_826 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_275 = torch.ops.aten.le.Scalar(to_dtype_826, 0);  to_dtype_826 = None
        new_zeros_default_600 = torch.ops.aten.new_zeros.default(to_dtype_825, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_275 = torch.ops.aten.where.self(le_scalar_275, new_zeros_default_600, to_dtype_825);  le_scalar_275 = new_zeros_default_600 = to_dtype_825 = None
        to_dtype_827 = torch.ops.aten.to.dtype(where_self_275, torch.float32);  where_self_275 = None
        native_batch_norm_backward_default_315 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_827, convolution_default_9, primals_185, primals_183, primals_184, getitem_28, getitem_29, True, 1e-05, [True, True, True]);  to_dtype_827 = convolution_default_9 = primals_185 = primals_183 = primals_184 = getitem_28 = getitem_29 = None
        getitem_2865 = native_batch_norm_backward_default_315[0]
        getitem_2866 = native_batch_norm_backward_default_315[1]
        getitem_2867 = native_batch_norm_backward_default_315[2];  native_batch_norm_backward_default_315 = None
        convolution_backward_default_315 = torch.ops.aten.convolution_backward.default(getitem_2865, relu__default_7, primals_196, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2865 = primals_196 = None
        getitem_2868 = convolution_backward_default_315[0]
        getitem_2869 = convolution_backward_default_315[1]
        getitem_2870 = convolution_backward_default_315[2];  convolution_backward_default_315 = None
        add_tensor_239 = torch.ops.aten.add.Tensor(to_dtype_821, getitem_2868);  to_dtype_821 = getitem_2868 = None
        to_dtype_828 = torch.ops.aten.to.dtype(add_tensor_239, torch.float32);  add_tensor_239 = None
        to_dtype_829 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_276 = torch.ops.aten.le.Scalar(to_dtype_829, 0);  to_dtype_829 = None
        new_zeros_default_601 = torch.ops.aten.new_zeros.default(to_dtype_828, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_276 = torch.ops.aten.where.self(le_scalar_276, new_zeros_default_601, to_dtype_828);  le_scalar_276 = new_zeros_default_601 = to_dtype_828 = None
        to_dtype_830 = torch.ops.aten.to.dtype(where_self_276, torch.float32);  where_self_276 = None
        native_batch_norm_backward_default_316 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_830, convolution_default_8, primals_177, primals_175, primals_176, getitem_25, getitem_26, True, 1e-05, [True, True, True]);  convolution_default_8 = primals_177 = primals_175 = primals_176 = getitem_25 = getitem_26 = None
        getitem_2871 = native_batch_norm_backward_default_316[0]
        getitem_2872 = native_batch_norm_backward_default_316[1]
        getitem_2873 = native_batch_norm_backward_default_316[2];  native_batch_norm_backward_default_316 = None
        convolution_backward_default_316 = torch.ops.aten.convolution_backward.default(getitem_2871, relu__default_6, primals_180, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2871 = primals_180 = None
        getitem_2874 = convolution_backward_default_316[0]
        getitem_2875 = convolution_backward_default_316[1]
        getitem_2876 = convolution_backward_default_316[2];  convolution_backward_default_316 = None
        to_dtype_831 = torch.ops.aten.to.dtype(getitem_2874, torch.float32);  getitem_2874 = None
        to_dtype_832 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_277 = torch.ops.aten.le.Scalar(to_dtype_832, 0);  to_dtype_832 = None
        new_zeros_default_602 = torch.ops.aten.new_zeros.default(to_dtype_831, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_277 = torch.ops.aten.where.self(le_scalar_277, new_zeros_default_602, to_dtype_831);  le_scalar_277 = new_zeros_default_602 = to_dtype_831 = None
        to_dtype_833 = torch.ops.aten.to.dtype(where_self_277, torch.float32);  where_self_277 = None
        native_batch_norm_backward_default_317 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_833, convolution_default_7, primals_172, primals_170, primals_171, getitem_22, getitem_23, True, 1e-05, [True, True, True]);  to_dtype_833 = convolution_default_7 = primals_172 = primals_170 = primals_171 = getitem_22 = getitem_23 = None
        getitem_2877 = native_batch_norm_backward_default_317[0]
        getitem_2878 = native_batch_norm_backward_default_317[1]
        getitem_2879 = native_batch_norm_backward_default_317[2];  native_batch_norm_backward_default_317 = None
        convolution_backward_default_317 = torch.ops.aten.convolution_backward.default(getitem_2877, relu__default_5, primals_179, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2877 = primals_179 = None
        getitem_2880 = convolution_backward_default_317[0]
        getitem_2881 = convolution_backward_default_317[1]
        getitem_2882 = convolution_backward_default_317[2];  convolution_backward_default_317 = None
        to_dtype_834 = torch.ops.aten.to.dtype(getitem_2880, torch.float32);  getitem_2880 = None
        to_dtype_835 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_278 = torch.ops.aten.le.Scalar(to_dtype_835, 0);  to_dtype_835 = None
        new_zeros_default_603 = torch.ops.aten.new_zeros.default(to_dtype_834, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_278 = torch.ops.aten.where.self(le_scalar_278, new_zeros_default_603, to_dtype_834);  le_scalar_278 = new_zeros_default_603 = to_dtype_834 = None
        to_dtype_836 = torch.ops.aten.to.dtype(where_self_278, torch.float32);  where_self_278 = None
        native_batch_norm_backward_default_318 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_836, convolution_default_6, primals_167, primals_165, primals_166, getitem_19, getitem_20, True, 1e-05, [True, True, True]);  to_dtype_836 = convolution_default_6 = primals_167 = primals_165 = primals_166 = getitem_19 = getitem_20 = None
        getitem_2883 = native_batch_norm_backward_default_318[0]
        getitem_2884 = native_batch_norm_backward_default_318[1]
        getitem_2885 = native_batch_norm_backward_default_318[2];  native_batch_norm_backward_default_318 = None
        convolution_backward_default_318 = torch.ops.aten.convolution_backward.default(getitem_2883, relu__default_4, primals_178, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2883 = primals_178 = None
        getitem_2886 = convolution_backward_default_318[0]
        getitem_2887 = convolution_backward_default_318[1]
        getitem_2888 = convolution_backward_default_318[2];  convolution_backward_default_318 = None
        add_tensor_240 = torch.ops.aten.add.Tensor(to_dtype_830, getitem_2886);  to_dtype_830 = getitem_2886 = None
        to_dtype_837 = torch.ops.aten.to.dtype(add_tensor_240, torch.float32);  add_tensor_240 = None
        to_dtype_838 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_279 = torch.ops.aten.le.Scalar(to_dtype_838, 0);  to_dtype_838 = None
        new_zeros_default_604 = torch.ops.aten.new_zeros.default(to_dtype_837, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_279 = torch.ops.aten.where.self(le_scalar_279, new_zeros_default_604, to_dtype_837);  le_scalar_279 = new_zeros_default_604 = to_dtype_837 = None
        to_dtype_839 = torch.ops.aten.to.dtype(where_self_279, torch.float32);  where_self_279 = None
        native_batch_norm_backward_default_319 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_839, convolution_default_5, primals_162, primals_160, primals_161, getitem_16, getitem_17, True, 1e-05, [True, True, True]);  convolution_default_5 = primals_162 = primals_160 = primals_161 = getitem_16 = getitem_17 = None
        getitem_2889 = native_batch_norm_backward_default_319[0]
        getitem_2890 = native_batch_norm_backward_default_319[1]
        getitem_2891 = native_batch_norm_backward_default_319[2];  native_batch_norm_backward_default_319 = None
        convolution_backward_default_319 = torch.ops.aten.convolution_backward.default(getitem_2889, relu__default_1, primals_157, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2889 = primals_157 = None
        getitem_2892 = convolution_backward_default_319[0]
        getitem_2893 = convolution_backward_default_319[1]
        getitem_2894 = convolution_backward_default_319[2];  convolution_backward_default_319 = None
        native_batch_norm_backward_default_320 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_839, convolution_default_4, primals_153, primals_151, primals_152, getitem_13, getitem_14, True, 1e-05, [True, True, True]);  to_dtype_839 = convolution_default_4 = primals_153 = primals_151 = primals_152 = getitem_13 = getitem_14 = None
        getitem_2895 = native_batch_norm_backward_default_320[0]
        getitem_2896 = native_batch_norm_backward_default_320[1]
        getitem_2897 = native_batch_norm_backward_default_320[2];  native_batch_norm_backward_default_320 = None
        convolution_backward_default_320 = torch.ops.aten.convolution_backward.default(getitem_2895, relu__default_3, primals_156, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2895 = primals_156 = None
        getitem_2898 = convolution_backward_default_320[0]
        getitem_2899 = convolution_backward_default_320[1]
        getitem_2900 = convolution_backward_default_320[2];  convolution_backward_default_320 = None
        to_dtype_840 = torch.ops.aten.to.dtype(getitem_2898, torch.float32);  getitem_2898 = None
        to_dtype_841 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_280 = torch.ops.aten.le.Scalar(to_dtype_841, 0);  to_dtype_841 = None
        new_zeros_default_605 = torch.ops.aten.new_zeros.default(to_dtype_840, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_280 = torch.ops.aten.where.self(le_scalar_280, new_zeros_default_605, to_dtype_840);  le_scalar_280 = new_zeros_default_605 = to_dtype_840 = None
        to_dtype_842 = torch.ops.aten.to.dtype(where_self_280, torch.float32);  where_self_280 = None
        native_batch_norm_backward_default_321 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_842, convolution_default_3, primals_148, primals_146, primals_147, getitem_10, getitem_11, True, 1e-05, [True, True, True]);  to_dtype_842 = convolution_default_3 = primals_148 = primals_146 = primals_147 = getitem_10 = getitem_11 = None
        getitem_2901 = native_batch_norm_backward_default_321[0]
        getitem_2902 = native_batch_norm_backward_default_321[1]
        getitem_2903 = native_batch_norm_backward_default_321[2];  native_batch_norm_backward_default_321 = None
        convolution_backward_default_321 = torch.ops.aten.convolution_backward.default(getitem_2901, relu__default_2, primals_155, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2901 = primals_155 = None
        getitem_2904 = convolution_backward_default_321[0]
        getitem_2905 = convolution_backward_default_321[1]
        getitem_2906 = convolution_backward_default_321[2];  convolution_backward_default_321 = None
        to_dtype_843 = torch.ops.aten.to.dtype(getitem_2904, torch.float32);  getitem_2904 = None
        to_dtype_844 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_281 = torch.ops.aten.le.Scalar(to_dtype_844, 0);  to_dtype_844 = None
        new_zeros_default_606 = torch.ops.aten.new_zeros.default(to_dtype_843, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_281 = torch.ops.aten.where.self(le_scalar_281, new_zeros_default_606, to_dtype_843);  le_scalar_281 = new_zeros_default_606 = to_dtype_843 = None
        to_dtype_845 = torch.ops.aten.to.dtype(where_self_281, torch.float32);  where_self_281 = None
        native_batch_norm_backward_default_322 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_845, convolution_default_2, primals_143, primals_141, primals_142, getitem_7, getitem_8, True, 1e-05, [True, True, True]);  to_dtype_845 = convolution_default_2 = primals_143 = primals_141 = primals_142 = getitem_7 = getitem_8 = None
        getitem_2907 = native_batch_norm_backward_default_322[0]
        getitem_2908 = native_batch_norm_backward_default_322[1]
        getitem_2909 = native_batch_norm_backward_default_322[2];  native_batch_norm_backward_default_322 = None
        convolution_backward_default_322 = torch.ops.aten.convolution_backward.default(getitem_2907, relu__default_1, primals_154, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2907 = primals_154 = None
        getitem_2910 = convolution_backward_default_322[0]
        getitem_2911 = convolution_backward_default_322[1]
        getitem_2912 = convolution_backward_default_322[2];  convolution_backward_default_322 = None
        add_tensor_241 = torch.ops.aten.add.Tensor(getitem_2892, getitem_2910);  getitem_2892 = getitem_2910 = None
        to_dtype_846 = torch.ops.aten.to.dtype(add_tensor_241, torch.float32);  add_tensor_241 = None
        to_dtype_847 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_282 = torch.ops.aten.le.Scalar(to_dtype_847, 0);  to_dtype_847 = None
        new_zeros_default_607 = torch.ops.aten.new_zeros.default(to_dtype_846, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_282 = torch.ops.aten.where.self(le_scalar_282, new_zeros_default_607, to_dtype_846);  le_scalar_282 = new_zeros_default_607 = to_dtype_846 = None
        to_dtype_848 = torch.ops.aten.to.dtype(where_self_282, torch.float32);  where_self_282 = None
        native_batch_norm_backward_default_323 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_848, convolution_default_1, primals_10, primals_8, primals_9, getitem_4, getitem_5, True, 1e-05, [True, True, True]);  to_dtype_848 = convolution_default_1 = primals_10 = primals_8 = primals_9 = getitem_4 = getitem_5 = None
        getitem_2913 = native_batch_norm_backward_default_323[0]
        getitem_2914 = native_batch_norm_backward_default_323[1]
        getitem_2915 = native_batch_norm_backward_default_323[2];  native_batch_norm_backward_default_323 = None
        convolution_backward_default_323 = torch.ops.aten.convolution_backward.default(getitem_2913, relu__default, primals_14, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2913 = primals_14 = None
        getitem_2916 = convolution_backward_default_323[0]
        getitem_2917 = convolution_backward_default_323[1]
        getitem_2918 = convolution_backward_default_323[2];  convolution_backward_default_323 = None
        to_dtype_849 = torch.ops.aten.to.dtype(getitem_2916, torch.float32);  getitem_2916 = None
        to_dtype_850 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_283 = torch.ops.aten.le.Scalar(to_dtype_850, 0);  to_dtype_850 = None
        new_zeros_default_608 = torch.ops.aten.new_zeros.default(to_dtype_849, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_283 = torch.ops.aten.where.self(le_scalar_283, new_zeros_default_608, to_dtype_849);  le_scalar_283 = new_zeros_default_608 = to_dtype_849 = None
        to_dtype_851 = torch.ops.aten.to.dtype(where_self_283, torch.float32);  where_self_283 = None
        native_batch_norm_backward_default_324 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_851, convolution_default, primals_5, primals_3, primals_4, getitem_1, getitem_2, True, 1e-05, [True, True, True]);  to_dtype_851 = convolution_default = primals_5 = primals_3 = primals_4 = getitem_1 = getitem_2 = None
        getitem_2919 = native_batch_norm_backward_default_324[0]
        getitem_2920 = native_batch_norm_backward_default_324[1]
        getitem_2921 = native_batch_norm_backward_default_324[2];  native_batch_norm_backward_default_324 = None
        convolution_backward_default_324 = torch.ops.aten.convolution_backward.default(getitem_2919, primals_1957, primals_13, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_2919 = primals_1957 = primals_13 = None
        getitem_2922 = convolution_backward_default_324[0]
        getitem_2923 = convolution_backward_default_324[1]
        getitem_2924 = convolution_backward_default_324[2];  convolution_backward_default_324 = None
        return [addmm_default, getitem_2921, None, None, None, getitem_2920, getitem_2915, None, None, None, getitem_2914, view_default_1, t_default_4, getitem_2923, getitem_2917, getitem_1046, getitem_1045, getitem_1043, None, None, None, getitem_1042, getitem_1016, getitem_1015, getitem_1013, None, None, None, getitem_1012, getitem_986, getitem_985, getitem_983, None, None, None, getitem_982, getitem_980, getitem_979, getitem_977, None, None, None, getitem_976, getitem_1091, None, None, None, getitem_1090, getitem_1085, None, None, None, getitem_1084, getitem_1079, None, None, None, getitem_1078, getitem_1093, getitem_1087, getitem_1081, getitem_1075, getitem_1073, None, None, None, getitem_1072, getitem_1067, None, None, None, getitem_1066, getitem_1061, None, None, None, getitem_1060, getitem_1055, None, None, None, getitem_1054, getitem_1069, getitem_1063, getitem_1057, getitem_1051, getitem_1049, None, None, None, getitem_1048, getitem_1037, None, None, None, getitem_1036, getitem_1031, None, None, None, getitem_1030, getitem_1025, None, None, None, getitem_1024, getitem_1039, getitem_1033, getitem_1027, getitem_1021, getitem_1019, None, None, None, getitem_1018, getitem_1007, None, None, None, getitem_1006, getitem_1001, None, None, None, getitem_1000, getitem_995, None, None, None, getitem_994, getitem_1009, getitem_1003, getitem_997, getitem_991, getitem_989, None, None, None, getitem_988, getitem_2909, None, None, None, getitem_2908, getitem_2903, None, None, None, getitem_2902, getitem_2897, None, None, None, getitem_2896, getitem_2911, getitem_2905, getitem_2899, getitem_2893, getitem_2891, None, None, None, getitem_2890, getitem_2885, None, None, None, getitem_2884, getitem_2879, None, None, None, getitem_2878, getitem_2873, None, None, None, getitem_2872, getitem_2887, getitem_2881, getitem_2875, getitem_2867, None, None, None, getitem_2866, getitem_2861, None, None, None, getitem_2860, getitem_2855, None, None, None, getitem_2854, getitem_2869, getitem_2863, getitem_2857, getitem_2849, None, None, None, getitem_2848, getitem_2843, None, None, None, getitem_2842, getitem_2837, None, None, None, getitem_2836, getitem_2851, getitem_2845, getitem_2839, getitem_2819, None, None, None, getitem_2818, getitem_2813, None, None, None, getitem_2812, getitem_2821, getitem_2815, getitem_2807, None, None, None, getitem_2806, getitem_2801, None, None, None, getitem_2800, getitem_2809, getitem_2803, getitem_2795, None, None, None, getitem_2794, getitem_2789, None, None, None, getitem_2788, getitem_2797, getitem_2791, getitem_2783, None, None, None, getitem_2782, getitem_2777, None, None, None, getitem_2776, getitem_2785, getitem_2779, getitem_2771, None, None, None, getitem_2770, getitem_2765, None, None, None, getitem_2764, getitem_2773, getitem_2767, getitem_2759, None, None, None, getitem_2758, getitem_2753, None, None, None, getitem_2752, getitem_2761, getitem_2755, getitem_2747, None, None, None, getitem_2746, getitem_2741, None, None, None, getitem_2740, getitem_2749, getitem_2743, getitem_2735, None, None, None, getitem_2734, getitem_2729, None, None, None, getitem_2728, getitem_2737, getitem_2731, getitem_2705, None, None, None, getitem_2704, getitem_2699, None, None, None, getitem_2698, getitem_2707, getitem_2701, getitem_2693, None, None, None, getitem_2692, getitem_2687, None, None, None, getitem_2686, getitem_2695, getitem_2689, getitem_2681, None, None, None, getitem_2680, getitem_2675, None, None, None, getitem_2674, getitem_2683, getitem_2677, getitem_2669, None, None, None, getitem_2668, getitem_2663, None, None, None, getitem_2662, getitem_2671, getitem_2665, getitem_2657, None, None, None, getitem_2656, getitem_2651, None, None, None, getitem_2650, getitem_2659, getitem_2653, getitem_2645, None, None, None, getitem_2644, getitem_2639, None, None, None, getitem_2638, getitem_2647, getitem_2641, getitem_2633, None, None, None, getitem_2632, getitem_2627, None, None, None, getitem_2626, getitem_2635, getitem_2629, getitem_2621, None, None, None, getitem_2620, getitem_2615, None, None, None, getitem_2614, getitem_2623, getitem_2617, getitem_2609, None, None, None, getitem_2608, getitem_2603, None, None, None, getitem_2602, getitem_2611, getitem_2605, getitem_2597, None, None, None, getitem_2596, getitem_2591, None, None, None, getitem_2590, getitem_2599, getitem_2593, getitem_2585, None, None, None, getitem_2584, getitem_2579, None, None, None, getitem_2578, getitem_2587, getitem_2581, getitem_2573, None, None, None, getitem_2572, getitem_2567, None, None, None, getitem_2566, getitem_2575, getitem_2569, getitem_2519, None, None, None, getitem_2518, getitem_2513, None, None, None, getitem_2512, getitem_2521, getitem_2515, getitem_2507, None, None, None, getitem_2506, getitem_2501, None, None, None, getitem_2500, getitem_2509, getitem_2503, getitem_2495, None, None, None, getitem_2494, getitem_2489, None, None, None, getitem_2488, getitem_2497, getitem_2491, getitem_2483, None, None, None, getitem_2482, getitem_2477, None, None, None, getitem_2476, getitem_2485, getitem_2479, getitem_2471, None, None, None, getitem_2470, getitem_2465, None, None, None, getitem_2464, getitem_2473, getitem_2467, getitem_2459, None, None, None, getitem_2458, getitem_2453, None, None, None, getitem_2452, getitem_2461, getitem_2455, getitem_2447, None, None, None, getitem_2446, getitem_2441, None, None, None, getitem_2440, getitem_2449, getitem_2443, getitem_2435, None, None, None, getitem_2434, getitem_2429, None, None, None, getitem_2428, getitem_2437, getitem_2431, getitem_2423, None, None, None, getitem_2422, getitem_2417, None, None, None, getitem_2416, getitem_2425, getitem_2419, getitem_2411, None, None, None, getitem_2410, getitem_2405, None, None, None, getitem_2404, getitem_2413, getitem_2407, getitem_2399, None, None, None, getitem_2398, getitem_2393, None, None, None, getitem_2392, getitem_2401, getitem_2395, getitem_2387, None, None, None, getitem_2386, getitem_2381, None, None, None, getitem_2380, getitem_2389, getitem_2383, getitem_2333, None, None, None, getitem_2332, getitem_2327, None, None, None, getitem_2326, getitem_2335, getitem_2329, getitem_2321, None, None, None, getitem_2320, getitem_2315, None, None, None, getitem_2314, getitem_2323, getitem_2317, getitem_2309, None, None, None, getitem_2308, getitem_2303, None, None, None, getitem_2302, getitem_2311, getitem_2305, getitem_2297, None, None, None, getitem_2296, getitem_2291, None, None, None, getitem_2290, getitem_2299, getitem_2293, getitem_2285, None, None, None, getitem_2284, getitem_2279, None, None, None, getitem_2278, getitem_2287, getitem_2281, getitem_2273, None, None, None, getitem_2272, getitem_2267, None, None, None, getitem_2266, getitem_2275, getitem_2269, getitem_2261, None, None, None, getitem_2260, getitem_2255, None, None, None, getitem_2254, getitem_2263, getitem_2257, getitem_2249, None, None, None, getitem_2248, getitem_2243, None, None, None, getitem_2242, getitem_2251, getitem_2245, getitem_2237, None, None, None, getitem_2236, getitem_2231, None, None, None, getitem_2230, getitem_2239, getitem_2233, getitem_2225, None, None, None, getitem_2224, getitem_2219, None, None, None, getitem_2218, getitem_2227, getitem_2221, getitem_2213, None, None, None, getitem_2212, getitem_2207, None, None, None, getitem_2206, getitem_2215, getitem_2209, getitem_2201, None, None, None, getitem_2200, getitem_2195, None, None, None, getitem_2194, getitem_2203, getitem_2197, getitem_2147, None, None, None, getitem_2146, getitem_2141, None, None, None, getitem_2140, getitem_2149, getitem_2143, getitem_2135, None, None, None, getitem_2134, getitem_2129, None, None, None, getitem_2128, getitem_2137, getitem_2131, getitem_2123, None, None, None, getitem_2122, getitem_2117, None, None, None, getitem_2116, getitem_2125, getitem_2119, getitem_2111, None, None, None, getitem_2110, getitem_2105, None, None, None, getitem_2104, getitem_2113, getitem_2107, getitem_2099, None, None, None, getitem_2098, getitem_2093, None, None, None, getitem_2092, getitem_2101, getitem_2095, getitem_2087, None, None, None, getitem_2086, getitem_2081, None, None, None, getitem_2080, getitem_2089, getitem_2083, getitem_2075, None, None, None, getitem_2074, getitem_2069, None, None, None, getitem_2068, getitem_2077, getitem_2071, getitem_2063, None, None, None, getitem_2062, getitem_2057, None, None, None, getitem_2056, getitem_2065, getitem_2059, getitem_2051, None, None, None, getitem_2050, getitem_2045, None, None, None, getitem_2044, getitem_2053, getitem_2047, getitem_2039, None, None, None, getitem_2038, getitem_2033, None, None, None, getitem_2032, getitem_2041, getitem_2035, getitem_2027, None, None, None, getitem_2026, getitem_2021, None, None, None, getitem_2020, getitem_2029, getitem_2023, getitem_2015, None, None, None, getitem_2014, getitem_2009, None, None, None, getitem_2008, getitem_2017, getitem_2011, getitem_1955, None, None, None, getitem_1954, getitem_1949, None, None, None, getitem_1948, getitem_1957, getitem_1951, getitem_1943, None, None, None, getitem_1942, getitem_1937, None, None, None, getitem_1936, getitem_1945, getitem_1939, getitem_1931, None, None, None, getitem_1930, getitem_1925, None, None, None, getitem_1924, getitem_1933, getitem_1927, getitem_1919, None, None, None, getitem_1918, getitem_1913, None, None, None, getitem_1912, getitem_1921, getitem_1915, getitem_1907, None, None, None, getitem_1906, getitem_1901, None, None, None, getitem_1900, getitem_1909, getitem_1903, getitem_1895, None, None, None, getitem_1894, getitem_1889, None, None, None, getitem_1888, getitem_1897, getitem_1891, getitem_1883, None, None, None, getitem_1882, getitem_1877, None, None, None, getitem_1876, getitem_1885, getitem_1879, getitem_1871, None, None, None, getitem_1870, getitem_1865, None, None, None, getitem_1864, getitem_1873, getitem_1867, getitem_1859, None, None, None, getitem_1858, getitem_1853, None, None, None, getitem_1852, getitem_1861, getitem_1855, getitem_1847, None, None, None, getitem_1846, getitem_1841, None, None, None, getitem_1840, getitem_1849, getitem_1843, getitem_1835, None, None, None, getitem_1834, getitem_1829, None, None, None, getitem_1828, getitem_1837, getitem_1831, getitem_1823, None, None, None, getitem_1822, getitem_1817, None, None, None, getitem_1816, getitem_1825, getitem_1819, getitem_1811, None, None, None, getitem_1810, getitem_1805, None, None, None, getitem_1804, getitem_1813, getitem_1807, getitem_1799, None, None, None, getitem_1798, getitem_1793, None, None, None, getitem_1792, getitem_1801, getitem_1795, getitem_1787, None, None, None, getitem_1786, getitem_1781, None, None, None, getitem_1780, getitem_1789, getitem_1783, getitem_1775, None, None, None, getitem_1774, getitem_1769, None, None, None, getitem_1768, getitem_1777, getitem_1771, getitem_1667, None, None, None, getitem_1666, getitem_1661, None, None, None, getitem_1660, getitem_1669, getitem_1663, getitem_1655, None, None, None, getitem_1654, getitem_1649, None, None, None, getitem_1648, getitem_1657, getitem_1651, getitem_1643, None, None, None, getitem_1642, getitem_1637, None, None, None, getitem_1636, getitem_1645, getitem_1639, getitem_1631, None, None, None, getitem_1630, getitem_1625, None, None, None, getitem_1624, getitem_1633, getitem_1627, getitem_1619, None, None, None, getitem_1618, getitem_1613, None, None, None, getitem_1612, getitem_1621, getitem_1615, getitem_1607, None, None, None, getitem_1606, getitem_1601, None, None, None, getitem_1600, getitem_1609, getitem_1603, getitem_1595, None, None, None, getitem_1594, getitem_1589, None, None, None, getitem_1588, getitem_1597, getitem_1591, getitem_1583, None, None, None, getitem_1582, getitem_1577, None, None, None, getitem_1576, getitem_1585, getitem_1579, getitem_1571, None, None, None, getitem_1570, getitem_1565, None, None, None, getitem_1564, getitem_1573, getitem_1567, getitem_1559, None, None, None, getitem_1558, getitem_1553, None, None, None, getitem_1552, getitem_1561, getitem_1555, getitem_1547, None, None, None, getitem_1546, getitem_1541, None, None, None, getitem_1540, getitem_1549, getitem_1543, getitem_1535, None, None, None, getitem_1534, getitem_1529, None, None, None, getitem_1528, getitem_1537, getitem_1531, getitem_1523, None, None, None, getitem_1522, getitem_1517, None, None, None, getitem_1516, getitem_1525, getitem_1519, getitem_1511, None, None, None, getitem_1510, getitem_1505, None, None, None, getitem_1504, getitem_1513, getitem_1507, getitem_1499, None, None, None, getitem_1498, getitem_1493, None, None, None, getitem_1492, getitem_1501, getitem_1495, getitem_1487, None, None, None, getitem_1486, getitem_1481, None, None, None, getitem_1480, getitem_1489, getitem_1483, getitem_1379, None, None, None, getitem_1378, getitem_1373, None, None, None, getitem_1372, getitem_1381, getitem_1375, getitem_1367, None, None, None, getitem_1366, getitem_1361, None, None, None, getitem_1360, getitem_1369, getitem_1363, getitem_1355, None, None, None, getitem_1354, getitem_1349, None, None, None, getitem_1348, getitem_1357, getitem_1351, getitem_1343, None, None, None, getitem_1342, getitem_1337, None, None, None, getitem_1336, getitem_1345, getitem_1339, getitem_1331, None, None, None, getitem_1330, getitem_1325, None, None, None, getitem_1324, getitem_1333, getitem_1327, getitem_1319, None, None, None, getitem_1318, getitem_1313, None, None, None, getitem_1312, getitem_1321, getitem_1315, getitem_1307, None, None, None, getitem_1306, getitem_1301, None, None, None, getitem_1300, getitem_1309, getitem_1303, getitem_1295, None, None, None, getitem_1294, getitem_1289, None, None, None, getitem_1288, getitem_1297, getitem_1291, getitem_1283, None, None, None, getitem_1282, getitem_1277, None, None, None, getitem_1276, getitem_1285, getitem_1279, getitem_1271, None, None, None, getitem_1270, getitem_1265, None, None, None, getitem_1264, getitem_1273, getitem_1267, getitem_1259, None, None, None, getitem_1258, getitem_1253, None, None, None, getitem_1252, getitem_1261, getitem_1255, getitem_1247, None, None, None, getitem_1246, getitem_1241, None, None, None, getitem_1240, getitem_1249, getitem_1243, getitem_1235, None, None, None, getitem_1234, getitem_1229, None, None, None, getitem_1228, getitem_1237, getitem_1231, getitem_1223, None, None, None, getitem_1222, getitem_1217, None, None, None, getitem_1216, getitem_1225, getitem_1219, getitem_1211, None, None, None, getitem_1210, getitem_1205, None, None, None, getitem_1204, getitem_1213, getitem_1207, getitem_1199, None, None, None, getitem_1198, getitem_1193, None, None, None, getitem_1192, getitem_1201, getitem_1195, getitem_2833, getitem_2831, None, None, None, getitem_2830, getitem_2827, getitem_2825, None, None, None, getitem_2824, getitem_2713, getitem_2711, None, None, None, getitem_2710, getitem_1963, getitem_1961, None, None, None, getitem_1960, getitem_2719, getitem_2717, None, None, None, getitem_2716, getitem_1729, getitem_1727, None, None, None, getitem_1726, getitem_1723, getitem_1721, None, None, None, getitem_1720, getitem_1705, getitem_1703, None, None, None, getitem_1702, getitem_1699, getitem_1697, None, None, None, getitem_1696, getitem_1693, getitem_1691, None, None, None, getitem_1690, getitem_1459, getitem_1457, None, None, None, getitem_1456, getitem_1441, getitem_1439, None, None, None, getitem_1438, getitem_1435, getitem_1433, None, None, None, getitem_1432, getitem_1417, getitem_1415, None, None, None, getitem_1414, getitem_1411, getitem_1409, None, None, None, getitem_1408, getitem_1405, getitem_1403, None, None, None, getitem_1402, getitem_1171, getitem_1169, None, None, None, getitem_1168, getitem_1153, getitem_1151, None, None, None, getitem_1150, getitem_1147, getitem_1145, None, None, None, getitem_1144, getitem_1129, getitem_1127, None, None, None, getitem_1126, getitem_1123, getitem_1121, None, None, None, getitem_1120, getitem_1117, getitem_1115, None, None, None, getitem_1114, getitem_2551, getitem_2549, None, None, None, getitem_2548, getitem_2539, getitem_2537, None, None, None, getitem_2536, getitem_2533, getitem_2531, None, None, None, getitem_2530, getitem_2365, getitem_2363, None, None, None, getitem_2362, getitem_2353, getitem_2351, None, None, None, getitem_2350, getitem_2347, getitem_2345, None, None, None, getitem_2344, getitem_2179, getitem_2177, None, None, None, getitem_2176, getitem_2167, getitem_2165, None, None, None, getitem_2164, getitem_2161, getitem_2159, None, None, None, getitem_2158, getitem_1993, getitem_1991, None, None, None, getitem_1990, getitem_1981, getitem_1979, None, None, None, getitem_1978, getitem_1975, getitem_1973, None, None, None, getitem_1972, getitem_1747, getitem_1745, None, None, None, getitem_1744, getitem_2725, getitem_2723, None, None, None, getitem_2722, getitem_1969, getitem_1967, None, None, None, getitem_1966, getitem_1765, getitem_1763, None, None, None, getitem_1762, getitem_1717, getitem_1715, None, None, None, getitem_1714, getitem_1687, getitem_1685, None, None, None, getitem_1684, getitem_1681, getitem_1679, None, None, None, getitem_1678, getitem_1477, getitem_1475, None, None, None, getitem_1474, getitem_1429, getitem_1427, None, None, None, getitem_1426, getitem_1399, getitem_1397, None, None, None, getitem_1396, getitem_1393, getitem_1391, None, None, None, getitem_1390, getitem_1189, getitem_1187, None, None, None, getitem_1186, getitem_1141, getitem_1139, None, None, None, getitem_1138, getitem_1111, getitem_1109, None, None, None, getitem_1108, getitem_1105, getitem_1103, None, None, None, getitem_1102, getitem_2563, getitem_2561, None, None, None, getitem_2560, getitem_2527, getitem_2525, None, None, None, getitem_2524, getitem_2377, getitem_2375, None, None, None, getitem_2374, getitem_2341, getitem_2339, None, None, None, getitem_2338, getitem_2191, getitem_2189, None, None, None, getitem_2188, getitem_2155, getitem_2153, None, None, None, getitem_2152, getitem_2005, getitem_2003, None, None, None, getitem_2002, getitem_2557, getitem_2555, None, None, None, getitem_2554, getitem_1759, getitem_1757, None, None, None, getitem_1756, getitem_1741, getitem_1739, None, None, None, getitem_1738, getitem_1675, getitem_1673, None, None, None, getitem_1672, getitem_1471, getitem_1469, None, None, None, getitem_1468, getitem_1453, getitem_1451, None, None, None, getitem_1450, getitem_1387, getitem_1385, None, None, None, getitem_1384, getitem_1183, getitem_1181, None, None, None, getitem_1180, getitem_1165, getitem_1163, None, None, None, getitem_1162, getitem_1099, getitem_1097, None, None, None, getitem_1096, getitem_2545, getitem_2543, None, None, None, getitem_2542, getitem_2371, getitem_2369, None, None, None, getitem_2368, getitem_2359, getitem_2357, None, None, None, getitem_2356, getitem_2185, getitem_2183, None, None, None, getitem_2182, getitem_2173, getitem_2171, None, None, None, getitem_2170, getitem_1999, getitem_1997, None, None, None, getitem_1996, getitem_1987, getitem_1985, None, None, None, getitem_1984, getitem_1753, getitem_1751, None, None, None, getitem_1750, getitem_1135, getitem_1133, None, None, None, getitem_1132, getitem_1735, getitem_1733, None, None, None, getitem_1732, getitem_1711, getitem_1709, None, None, None, getitem_1708, getitem_1465, getitem_1463, None, None, None, getitem_1462, getitem_1447, getitem_1445, None, None, None, getitem_1444, getitem_1423, getitem_1421, None, None, None, getitem_1420, getitem_1177, getitem_1175, None, None, None, getitem_1174, getitem_1159, getitem_1157, None, None, None, getitem_1156, None]
        
