
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/hrnet_w18/hrnet_w18_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339, primals_340, primals_341, primals_342, primals_343, primals_344, primals_345, primals_346, primals_347, primals_348, primals_349, primals_350, primals_351, primals_352, primals_353, primals_354, primals_355, primals_356, primals_357, primals_358, primals_359, primals_360, primals_361, primals_362, primals_363, primals_364, primals_365, primals_366, primals_367, primals_368, primals_369, primals_370, primals_371, primals_372, primals_373, primals_374, primals_375, primals_376, primals_377, primals_378, primals_379, primals_380, primals_381, primals_382, primals_383, primals_384, primals_385, primals_386, primals_387, primals_388, primals_389, primals_390, primals_391, primals_392, primals_393, primals_394, primals_395, primals_396, primals_397, primals_398, primals_399, primals_400, primals_401, primals_402, primals_403, primals_404, primals_405, primals_406, primals_407, primals_408, primals_409, primals_410, primals_411, primals_412, primals_413, primals_414, primals_415, primals_416, primals_417, primals_418, primals_419, primals_420, primals_421, primals_422, primals_423, primals_424, primals_425, primals_426, primals_427, primals_428, primals_429, primals_430, primals_431, primals_432, primals_433, primals_434, primals_435, primals_436, primals_437, primals_438, primals_439, primals_440, primals_441, primals_442, primals_443, primals_444, primals_445, primals_446, primals_447, primals_448, primals_449, primals_450, primals_451, primals_452, primals_453, primals_454, primals_455, primals_456, primals_457, primals_458, primals_459, primals_460, primals_461, primals_462, primals_463, primals_464, primals_465, primals_466, primals_467, primals_468, primals_469, primals_470, primals_471, primals_472, primals_473, primals_474, primals_475, primals_476, primals_477, primals_478, primals_479, primals_480, primals_481, primals_482, primals_483, primals_484, primals_485, primals_486, primals_487, primals_488, primals_489, primals_490, primals_491, primals_492, primals_493, primals_494, primals_495, primals_496, primals_497, primals_498, primals_499, primals_500, primals_501, primals_502, primals_503, primals_504, primals_505, primals_506, primals_507, primals_508, primals_509, primals_510, primals_511, primals_512, primals_513, primals_514, primals_515, primals_516, primals_517, primals_518, primals_519, primals_520, primals_521, primals_522, primals_523, primals_524, primals_525, primals_526, primals_527, primals_528, primals_529, primals_530, primals_531, primals_532, primals_533, primals_534, primals_535, primals_536, primals_537, primals_538, primals_539, primals_540, primals_541, primals_542, primals_543, primals_544, primals_545, primals_546, primals_547, primals_548, primals_549, primals_550, primals_551, primals_552, primals_553, primals_554, primals_555, primals_556, primals_557, primals_558, primals_559, primals_560, primals_561, primals_562, primals_563, primals_564, primals_565, primals_566, primals_567, primals_568, primals_569, primals_570, primals_571, primals_572, primals_573, primals_574, primals_575, primals_576, primals_577, primals_578, primals_579, primals_580, primals_581, primals_582, primals_583, primals_584, primals_585, primals_586, primals_587, primals_588, primals_589, primals_590, primals_591, primals_592, primals_593, primals_594, primals_595, primals_596, primals_597, primals_598, primals_599, primals_600, primals_601, primals_602, primals_603, primals_604, primals_605, primals_606, primals_607, primals_608, primals_609, primals_610, primals_611, primals_612, primals_613, primals_614, primals_615, primals_616, primals_617, primals_618, primals_619, primals_620, primals_621, primals_622, primals_623, primals_624, primals_625, primals_626, primals_627, primals_628, primals_629, primals_630, primals_631, primals_632, primals_633, primals_634, primals_635, primals_636, primals_637, primals_638, primals_639, primals_640, primals_641, primals_642, primals_643, primals_644, primals_645, primals_646, primals_647, primals_648, primals_649, primals_650, primals_651, primals_652, primals_653, primals_654, primals_655, primals_656, primals_657, primals_658, primals_659, primals_660, primals_661, primals_662, primals_663, primals_664, primals_665, primals_666, primals_667, primals_668, primals_669, primals_670, primals_671, primals_672, primals_673, primals_674, primals_675, primals_676, primals_677, primals_678, primals_679, primals_680, primals_681, primals_682, primals_683, primals_684, primals_685, primals_686, primals_687, primals_688, primals_689, primals_690, primals_691, primals_692, primals_693, primals_694, primals_695, primals_696, primals_697, primals_698, primals_699, primals_700, primals_701, primals_702, primals_703, primals_704, primals_705, primals_706, primals_707, primals_708, primals_709, primals_710, primals_711, primals_712, primals_713, primals_714, primals_715, primals_716, primals_717, primals_718, primals_719, primals_720, primals_721, primals_722, primals_723, primals_724, primals_725, primals_726, primals_727, primals_728, primals_729, primals_730, primals_731, primals_732, primals_733, primals_734, primals_735, primals_736, primals_737, primals_738, primals_739, primals_740, primals_741, primals_742, primals_743, primals_744, primals_745, primals_746, primals_747, primals_748, primals_749, primals_750, primals_751, primals_752, primals_753, primals_754, primals_755, primals_756, primals_757, primals_758, primals_759, primals_760, primals_761, primals_762, primals_763, primals_764, primals_765, primals_766, primals_767, primals_768, primals_769, primals_770, primals_771, primals_772, primals_773, primals_774, primals_775, primals_776, primals_777, primals_778, primals_779, primals_780, primals_781, primals_782, primals_783, primals_784, primals_785, primals_786, primals_787, primals_788, primals_789, primals_790, primals_791, primals_792, primals_793, primals_794, primals_795, primals_796, primals_797, primals_798, primals_799, primals_800, primals_801, primals_802, primals_803, primals_804, primals_805, primals_806, primals_807, primals_808, primals_809, primals_810, primals_811, primals_812, primals_813, primals_814, primals_815, primals_816, primals_817, primals_818, primals_819, primals_820, primals_821, primals_822, primals_823, primals_824, primals_825, primals_826, primals_827, primals_828, primals_829, primals_830, primals_831, primals_832, primals_833, primals_834, primals_835, primals_836, primals_837, primals_838, primals_839, primals_840, primals_841, primals_842, primals_843, primals_844, primals_845, primals_846, primals_847, primals_848, primals_849, primals_850, primals_851, primals_852, primals_853, primals_854, primals_855, primals_856, primals_857, primals_858, primals_859, primals_860, primals_861, primals_862, primals_863, primals_864, primals_865, primals_866, primals_867, primals_868, primals_869, primals_870, primals_871, primals_872, primals_873, primals_874, primals_875, primals_876, primals_877, primals_878, primals_879, primals_880, primals_881, primals_882, primals_883, primals_884, primals_885, primals_886, primals_887, primals_888, primals_889, primals_890, primals_891, primals_892, primals_893, primals_894, primals_895, primals_896, primals_897, primals_898, primals_899, primals_900, primals_901, primals_902, primals_903, primals_904, primals_905, primals_906, primals_907, primals_908, primals_909, primals_910, primals_911, primals_912, primals_913, primals_914, primals_915, primals_916, primals_917, primals_918, primals_919, primals_920, primals_921, primals_922, primals_923, primals_924, primals_925, primals_926, primals_927, primals_928, primals_929, primals_930, primals_931, primals_932, primals_933, primals_934, primals_935, primals_936, primals_937, primals_938, primals_939, primals_940, primals_941, primals_942, primals_943, primals_944, primals_945, primals_946, primals_947, primals_948, primals_949, primals_950, primals_951, primals_952, primals_953, primals_954, primals_955, primals_956, primals_957, primals_958, primals_959, primals_960, primals_961, primals_962, primals_963, primals_964, primals_965, primals_966, primals_967, primals_968, primals_969, primals_970, primals_971, primals_972, primals_973, primals_974, primals_975, primals_976, primals_977, primals_978, primals_979, primals_980, primals_981, primals_982, primals_983, primals_984, primals_985, primals_986, primals_987, primals_988, primals_989, primals_990, primals_991, primals_992, primals_993, primals_994, primals_995, primals_996, primals_997, primals_998, primals_999, primals_1000, primals_1001, primals_1002, primals_1003, primals_1004, primals_1005, primals_1006, primals_1007, primals_1008, primals_1009, primals_1010, primals_1011, primals_1012, primals_1013, primals_1014, primals_1015, primals_1016, primals_1017, primals_1018, primals_1019, primals_1020, primals_1021, primals_1022, primals_1023, primals_1024, primals_1025, primals_1026, primals_1027, primals_1028, primals_1029, primals_1030, primals_1031, primals_1032, primals_1033, primals_1034, primals_1035, primals_1036, primals_1037, primals_1038, primals_1039, primals_1040, primals_1041, primals_1042, primals_1043, primals_1044, primals_1045, primals_1046, primals_1047, primals_1048, primals_1049, primals_1050, primals_1051, primals_1052, primals_1053, primals_1054, primals_1055, primals_1056, primals_1057, primals_1058, primals_1059, primals_1060, primals_1061, primals_1062, primals_1063, primals_1064, primals_1065, primals_1066, primals_1067, primals_1068, primals_1069, primals_1070, primals_1071, primals_1072, primals_1073, primals_1074, primals_1075, primals_1076, primals_1077, primals_1078, primals_1079, primals_1080, primals_1081, primals_1082, primals_1083, primals_1084, primals_1085, primals_1086, primals_1087, primals_1088, primals_1089, primals_1090, primals_1091, primals_1092, primals_1093, primals_1094, primals_1095, primals_1096, primals_1097, primals_1098, primals_1099, primals_1100, primals_1101, primals_1102, primals_1103, primals_1104, primals_1105, primals_1106, primals_1107, primals_1108, primals_1109, primals_1110, primals_1111, primals_1112, primals_1113, primals_1114, primals_1115, primals_1116, primals_1117, primals_1118, primals_1119, primals_1120, primals_1121, primals_1122, primals_1123, primals_1124, primals_1125, primals_1126, primals_1127, primals_1128, primals_1129, primals_1130, primals_1131, primals_1132, primals_1133, primals_1134, primals_1135, primals_1136, primals_1137, primals_1138, primals_1139, primals_1140, primals_1141, primals_1142, primals_1143, primals_1144, primals_1145, primals_1146, primals_1147, primals_1148, primals_1149, primals_1150, primals_1151, primals_1152, primals_1153, primals_1154, primals_1155, primals_1156, primals_1157, primals_1158, primals_1159, primals_1160, primals_1161, primals_1162, primals_1163, primals_1164, primals_1165, primals_1166, primals_1167, primals_1168, primals_1169, primals_1170, primals_1171, primals_1172, primals_1173, primals_1174, primals_1175, primals_1176, primals_1177, primals_1178, primals_1179, primals_1180, primals_1181, primals_1182, primals_1183, primals_1184, primals_1185, primals_1186, primals_1187, primals_1188, primals_1189, primals_1190, primals_1191, primals_1192, primals_1193, primals_1194, primals_1195, primals_1196, primals_1197, primals_1198, primals_1199, primals_1200, primals_1201, primals_1202, primals_1203, primals_1204, primals_1205, primals_1206, primals_1207, primals_1208, primals_1209, primals_1210, primals_1211, primals_1212, primals_1213, primals_1214, primals_1215, primals_1216, primals_1217, primals_1218, primals_1219, primals_1220, primals_1221, primals_1222, primals_1223, primals_1224, primals_1225, primals_1226, primals_1227, primals_1228, primals_1229, primals_1230, primals_1231, primals_1232, primals_1233, primals_1234, primals_1235, primals_1236, primals_1237, primals_1238, primals_1239, primals_1240, primals_1241, primals_1242, primals_1243, primals_1244, primals_1245, primals_1246, primals_1247, primals_1248, primals_1249, primals_1250, primals_1251, primals_1252, primals_1253, primals_1254, primals_1255, primals_1256, primals_1257, primals_1258, primals_1259, primals_1260, primals_1261, primals_1262, primals_1263, primals_1264, primals_1265, primals_1266, primals_1267, primals_1268, primals_1269, primals_1270, primals_1271, primals_1272, primals_1273, primals_1274, primals_1275, primals_1276, primals_1277, primals_1278, primals_1279, primals_1280, primals_1281, primals_1282, primals_1283, primals_1284, primals_1285, primals_1286, primals_1287, primals_1288, primals_1289, primals_1290, primals_1291, primals_1292, primals_1293, primals_1294, primals_1295, primals_1296, primals_1297, primals_1298, primals_1299, primals_1300, primals_1301, primals_1302, primals_1303, primals_1304, primals_1305, primals_1306, primals_1307, primals_1308, primals_1309, primals_1310, primals_1311, primals_1312, primals_1313, primals_1314, primals_1315, primals_1316, primals_1317, primals_1318, primals_1319, primals_1320, primals_1321, primals_1322, primals_1323, primals_1324, primals_1325, primals_1326, primals_1327, primals_1328, primals_1329, primals_1330, primals_1331, primals_1332, primals_1333, primals_1334, primals_1335, primals_1336, primals_1337, primals_1338, primals_1339, primals_1340, primals_1341, primals_1342, primals_1343, primals_1344, primals_1345, primals_1346, primals_1347, primals_1348, primals_1349, primals_1350, primals_1351, primals_1352, primals_1353, primals_1354, primals_1355, primals_1356, primals_1357, primals_1358, primals_1359, primals_1360, primals_1361, primals_1362, primals_1363, primals_1364, primals_1365, primals_1366, primals_1367, primals_1368, primals_1369, primals_1370, primals_1371, primals_1372, primals_1373, primals_1374, primals_1375, primals_1376, primals_1377, primals_1378, primals_1379, primals_1380, primals_1381, primals_1382, primals_1383, primals_1384, primals_1385, primals_1386, primals_1387, primals_1388, primals_1389, primals_1390, primals_1391, primals_1392, primals_1393, primals_1394, primals_1395, primals_1396, primals_1397, primals_1398, primals_1399, primals_1400, primals_1401, primals_1402, primals_1403, primals_1404, primals_1405, primals_1406, primals_1407, primals_1408, primals_1409, primals_1410, primals_1411, primals_1412, primals_1413, primals_1414, primals_1415, primals_1416, primals_1417, primals_1418, primals_1419, primals_1420, primals_1421, primals_1422, primals_1423, primals_1424, primals_1425, primals_1426, primals_1427, primals_1428, primals_1429, primals_1430, primals_1431, primals_1432, primals_1433, primals_1434, primals_1435, primals_1436, primals_1437, primals_1438, primals_1439, primals_1440, primals_1441, primals_1442, primals_1443, primals_1444, primals_1445, primals_1446, primals_1447, primals_1448, primals_1449, primals_1450, primals_1451, primals_1452, primals_1453, primals_1454, primals_1455, primals_1456, primals_1457, primals_1458, primals_1459, primals_1460, primals_1461, primals_1462, primals_1463, primals_1464, primals_1465, primals_1466, primals_1467, primals_1468, primals_1469, primals_1470, primals_1471, primals_1472, primals_1473, primals_1474, primals_1475, primals_1476, primals_1477, primals_1478, primals_1479, primals_1480, primals_1481, primals_1482, primals_1483, primals_1484, primals_1485, primals_1486, primals_1487, primals_1488, primals_1489, primals_1490, primals_1491, primals_1492, primals_1493, primals_1494, primals_1495, primals_1496, primals_1497, primals_1498, primals_1499, primals_1500, primals_1501, primals_1502, primals_1503, primals_1504, primals_1505, primals_1506, primals_1507, primals_1508, primals_1509, primals_1510, primals_1511, primals_1512, primals_1513, primals_1514, primals_1515, primals_1516, primals_1517, primals_1518, primals_1519, primals_1520, primals_1521, primals_1522, primals_1523, primals_1524, primals_1525, primals_1526, primals_1527, primals_1528, primals_1529, primals_1530, primals_1531, primals_1532, primals_1533, primals_1534, primals_1535, primals_1536, primals_1537, primals_1538, primals_1539, primals_1540, primals_1541, primals_1542, primals_1543, primals_1544, primals_1545, primals_1546, primals_1547, primals_1548, primals_1549, primals_1550, primals_1551, primals_1552, primals_1553, primals_1554, primals_1555, primals_1556, primals_1557, primals_1558, primals_1559, primals_1560, primals_1561, primals_1562, primals_1563, primals_1564, primals_1565, primals_1566, primals_1567, primals_1568, primals_1569, primals_1570, primals_1571, primals_1572, primals_1573, primals_1574, primals_1575, primals_1576, primals_1577, primals_1578, primals_1579, primals_1580, primals_1581, primals_1582, primals_1583, primals_1584, primals_1585, primals_1586, primals_1587, primals_1588, primals_1589, primals_1590, primals_1591, primals_1592, primals_1593, primals_1594, primals_1595, primals_1596, primals_1597, primals_1598, primals_1599, primals_1600, primals_1601, primals_1602, primals_1603, primals_1604, primals_1605, primals_1606, primals_1607, primals_1608, primals_1609, primals_1610, primals_1611, primals_1612, primals_1613, primals_1614, primals_1615, primals_1616, primals_1617, primals_1618, primals_1619, primals_1620, primals_1621, primals_1622, primals_1623, primals_1624, primals_1625, primals_1626, primals_1627, primals_1628, primals_1629, primals_1630, primals_1631, primals_1632, primals_1633, primals_1634, primals_1635, primals_1636, primals_1637, primals_1638, primals_1639, primals_1640, primals_1641, primals_1642, primals_1643, primals_1644, primals_1645, primals_1646, primals_1647, primals_1648, primals_1649, primals_1650, primals_1651, primals_1652, primals_1653, primals_1654, primals_1655, primals_1656, primals_1657, primals_1658, primals_1659, primals_1660, primals_1661, primals_1662, primals_1663, primals_1664, primals_1665, primals_1666, primals_1667, primals_1668, primals_1669, primals_1670, primals_1671, primals_1672, primals_1673, primals_1674, primals_1675, primals_1676, primals_1677, primals_1678, primals_1679, primals_1680, primals_1681, primals_1682, primals_1683, primals_1684, primals_1685, primals_1686, primals_1687, primals_1688, primals_1689, primals_1690, primals_1691, primals_1692, primals_1693, primals_1694, primals_1695, primals_1696, primals_1697, primals_1698, primals_1699, primals_1700, primals_1701, primals_1702, primals_1703, primals_1704, primals_1705, primals_1706, primals_1707, primals_1708, primals_1709, primals_1710, primals_1711, primals_1712, primals_1713, primals_1714, primals_1715, primals_1716, primals_1717, primals_1718, primals_1719, primals_1720, primals_1721, primals_1722, primals_1723, primals_1724, primals_1725, primals_1726, primals_1727, primals_1728, primals_1729, primals_1730, primals_1731, primals_1732, primals_1733, primals_1734, primals_1735, primals_1736, primals_1737, primals_1738, primals_1739, primals_1740, primals_1741, primals_1742, primals_1743, primals_1744, primals_1745, primals_1746, primals_1747, primals_1748, primals_1749, primals_1750, primals_1751, primals_1752, primals_1753, primals_1754, primals_1755, primals_1756, primals_1757, primals_1758, primals_1759, primals_1760, primals_1761, primals_1762, primals_1763, primals_1764, primals_1765, primals_1766, primals_1767, primals_1768, primals_1769, primals_1770, primals_1771, primals_1772, primals_1773, primals_1774, primals_1775, primals_1776, primals_1777, primals_1778, primals_1779, primals_1780, primals_1781, primals_1782, primals_1783, primals_1784, primals_1785, primals_1786, primals_1787, primals_1788, primals_1789, primals_1790, primals_1791, primals_1792, primals_1793, primals_1794, primals_1795, primals_1796, primals_1797, primals_1798, primals_1799, primals_1800, primals_1801, primals_1802, primals_1803, primals_1804, primals_1805, primals_1806, primals_1807, primals_1808, primals_1809, primals_1810, primals_1811, primals_1812, primals_1813, primals_1814, primals_1815, primals_1816, primals_1817, primals_1818, primals_1819, primals_1820, primals_1821, primals_1822, primals_1823, primals_1824, primals_1825, primals_1826, primals_1827, primals_1828, primals_1829, primals_1830, primals_1831, primals_1832, primals_1833, primals_1834, primals_1835, primals_1836, primals_1837, primals_1838, primals_1839, primals_1840, primals_1841, primals_1842, primals_1843, primals_1844, primals_1845, primals_1846, primals_1847, primals_1848, primals_1849, primals_1850, primals_1851, primals_1852, primals_1853, primals_1854, primals_1855, primals_1856, primals_1857, primals_1858, primals_1859, primals_1860, primals_1861, primals_1862, primals_1863, primals_1864, primals_1865, primals_1866, primals_1867, primals_1868, primals_1869, primals_1870, primals_1871, primals_1872, primals_1873, primals_1874, primals_1875, primals_1876, primals_1877, primals_1878, primals_1879, primals_1880, primals_1881, primals_1882, primals_1883, primals_1884, primals_1885, primals_1886, primals_1887, primals_1888, primals_1889, primals_1890, primals_1891, primals_1892, primals_1893, primals_1894, primals_1895, primals_1896, primals_1897, primals_1898, primals_1899, primals_1900, primals_1901, primals_1902, primals_1903, primals_1904, primals_1905, primals_1906, primals_1907, primals_1908, primals_1909, primals_1910, primals_1911, primals_1912, primals_1913, primals_1914, primals_1915, primals_1916, primals_1917, primals_1918, primals_1919, primals_1920, primals_1921, primals_1922, primals_1923, primals_1924, primals_1925, primals_1926, primals_1927, primals_1928, primals_1929, primals_1930, primals_1931, primals_1932, primals_1933, primals_1934, primals_1935, primals_1936, primals_1937, primals_1938, primals_1939, primals_1940, primals_1941, primals_1942, primals_1943, primals_1944, primals_1945, primals_1946, primals_1947, primals_1948, primals_1949, primals_1950, primals_1951, primals_1952, primals_1953, primals_1954, primals_1955, primals_1956, primals_1957):
        convolution_default = torch.ops.aten.convolution.default(primals_1957, primals_13, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_5, primals_1, primals_3, primals_4, True, 0.1, 1e-05);  primals_1 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default, primals_14, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_10, primals_6, primals_8, primals_9, True, 0.1, 1e-05);  primals_6 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        relu__default_1 = torch.ops.aten.relu_.default(getitem_3);  getitem_3 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_154, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_143, primals_139, primals_141, primals_142, True, 0.1, 1e-05);  primals_139 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        relu__default_2 = torch.ops.aten.relu_.default(getitem_6);  getitem_6 = None
        convolution_default_3 = torch.ops.aten.convolution.default(relu__default_2, primals_155, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_148, primals_144, primals_146, primals_147, True, 0.1, 1e-05);  primals_144 = None
        getitem_9 = native_batch_norm_default_3[0]
        getitem_10 = native_batch_norm_default_3[1]
        getitem_11 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        relu__default_3 = torch.ops.aten.relu_.default(getitem_9);  getitem_9 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu__default_3, primals_156, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_153, primals_149, primals_151, primals_152, True, 0.1, 1e-05);  primals_149 = None
        getitem_12 = native_batch_norm_default_4[0]
        getitem_13 = native_batch_norm_default_4[1]
        getitem_14 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_1, primals_157, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_162, primals_158, primals_160, primals_161, True, 0.1, 1e-05);  primals_158 = None
        getitem_15 = native_batch_norm_default_5[0]
        getitem_16 = native_batch_norm_default_5[1]
        getitem_17 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        add__tensor_6 = torch.ops.aten.add_.Tensor(getitem_12, getitem_15);  getitem_12 = getitem_15 = None
        relu__default_4 = torch.ops.aten.relu_.default(add__tensor_6);  add__tensor_6 = None
        convolution_default_6 = torch.ops.aten.convolution.default(relu__default_4, primals_178, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_167, primals_163, primals_165, primals_166, True, 0.1, 1e-05);  primals_163 = None
        getitem_18 = native_batch_norm_default_6[0]
        getitem_19 = native_batch_norm_default_6[1]
        getitem_20 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        relu__default_5 = torch.ops.aten.relu_.default(getitem_18);  getitem_18 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_5, primals_179, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_172, primals_168, primals_170, primals_171, True, 0.1, 1e-05);  primals_168 = None
        getitem_21 = native_batch_norm_default_7[0]
        getitem_22 = native_batch_norm_default_7[1]
        getitem_23 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        relu__default_6 = torch.ops.aten.relu_.default(getitem_21);  getitem_21 = None
        convolution_default_8 = torch.ops.aten.convolution.default(relu__default_6, primals_180, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_177, primals_173, primals_175, primals_176, True, 0.1, 1e-05);  primals_173 = None
        getitem_24 = native_batch_norm_default_8[0]
        getitem_25 = native_batch_norm_default_8[1]
        getitem_26 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        add__tensor_10 = torch.ops.aten.add_.Tensor(getitem_24, relu__default_4);  getitem_24 = None
        relu__default_7 = torch.ops.aten.relu_.default(add__tensor_10);  add__tensor_10 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_7, primals_196, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_185, primals_181, primals_183, primals_184, True, 0.1, 1e-05);  primals_181 = None
        getitem_27 = native_batch_norm_default_9[0]
        getitem_28 = native_batch_norm_default_9[1]
        getitem_29 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        relu__default_8 = torch.ops.aten.relu_.default(getitem_27);  getitem_27 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default_8, primals_197, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_190, primals_186, primals_188, primals_189, True, 0.1, 1e-05);  primals_186 = None
        getitem_30 = native_batch_norm_default_10[0]
        getitem_31 = native_batch_norm_default_10[1]
        getitem_32 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        relu__default_9 = torch.ops.aten.relu_.default(getitem_30);  getitem_30 = None
        convolution_default_11 = torch.ops.aten.convolution.default(relu__default_9, primals_198, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_195, primals_191, primals_193, primals_194, True, 0.1, 1e-05);  primals_191 = None
        getitem_33 = native_batch_norm_default_11[0]
        getitem_34 = native_batch_norm_default_11[1]
        getitem_35 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        add__tensor_14 = torch.ops.aten.add_.Tensor(getitem_33, relu__default_7);  getitem_33 = None
        relu__default_10 = torch.ops.aten.relu_.default(add__tensor_14);  add__tensor_14 = None
        convolution_default_12 = torch.ops.aten.convolution.default(relu__default_10, primals_214, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_203, primals_199, primals_201, primals_202, True, 0.1, 1e-05);  primals_199 = None
        getitem_36 = native_batch_norm_default_12[0]
        getitem_37 = native_batch_norm_default_12[1]
        getitem_38 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        relu__default_11 = torch.ops.aten.relu_.default(getitem_36);  getitem_36 = None
        convolution_default_13 = torch.ops.aten.convolution.default(relu__default_11, primals_215, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_208, primals_204, primals_206, primals_207, True, 0.1, 1e-05);  primals_204 = None
        getitem_39 = native_batch_norm_default_13[0]
        getitem_40 = native_batch_norm_default_13[1]
        getitem_41 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        relu__default_12 = torch.ops.aten.relu_.default(getitem_39);  getitem_39 = None
        convolution_default_14 = torch.ops.aten.convolution.default(relu__default_12, primals_216, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_213, primals_209, primals_211, primals_212, True, 0.1, 1e-05);  primals_209 = None
        getitem_42 = native_batch_norm_default_14[0]
        getitem_43 = native_batch_norm_default_14[1]
        getitem_44 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        add__tensor_18 = torch.ops.aten.add_.Tensor(getitem_42, relu__default_10);  getitem_42 = None
        relu__default_13 = torch.ops.aten.relu_.default(add__tensor_18);  add__tensor_18 = None
        convolution_default_15 = torch.ops.aten.convolution.default(relu__default_13, primals_1465, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_1470, primals_1466, primals_1468, primals_1469, True, 0.1, 1e-05);  primals_1466 = None
        getitem_45 = native_batch_norm_default_15[0]
        getitem_46 = native_batch_norm_default_15[1]
        getitem_47 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        relu__default_14 = torch.ops.aten.relu_.default(getitem_45);  getitem_45 = None
        convolution_default_16 = torch.ops.aten.convolution.default(relu__default_13, primals_1471, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_1476, primals_1472, primals_1474, primals_1475, True, 0.1, 1e-05);  primals_1472 = None
        getitem_48 = native_batch_norm_default_16[0]
        getitem_49 = native_batch_norm_default_16[1]
        getitem_50 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        relu__default_15 = torch.ops.aten.relu_.default(getitem_48);  getitem_48 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu__default_14, primals_227, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_221, primals_217, primals_219, primals_220, True, 0.1, 1e-05);  primals_217 = None
        getitem_51 = native_batch_norm_default_17[0]
        getitem_52 = native_batch_norm_default_17[1]
        getitem_53 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        relu__default_16 = torch.ops.aten.relu_.default(getitem_51);  getitem_51 = None
        convolution_default_18 = torch.ops.aten.convolution.default(relu__default_16, primals_228, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_226, primals_222, primals_224, primals_225, True, 0.1, 1e-05);  primals_222 = None
        getitem_54 = native_batch_norm_default_18[0]
        getitem_55 = native_batch_norm_default_18[1]
        getitem_56 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        add__tensor_23 = torch.ops.aten.add_.Tensor(getitem_54, relu__default_14);  getitem_54 = None
        relu__default_17 = torch.ops.aten.relu_.default(add__tensor_23);  add__tensor_23 = None
        convolution_default_19 = torch.ops.aten.convolution.default(relu__default_17, primals_239, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_233, primals_229, primals_231, primals_232, True, 0.1, 1e-05);  primals_229 = None
        getitem_57 = native_batch_norm_default_19[0]
        getitem_58 = native_batch_norm_default_19[1]
        getitem_59 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        relu__default_18 = torch.ops.aten.relu_.default(getitem_57);  getitem_57 = None
        convolution_default_20 = torch.ops.aten.convolution.default(relu__default_18, primals_240, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_238, primals_234, primals_236, primals_237, True, 0.1, 1e-05);  primals_234 = None
        getitem_60 = native_batch_norm_default_20[0]
        getitem_61 = native_batch_norm_default_20[1]
        getitem_62 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        add__tensor_26 = torch.ops.aten.add_.Tensor(getitem_60, relu__default_17);  getitem_60 = None
        relu__default_19 = torch.ops.aten.relu_.default(add__tensor_26);  add__tensor_26 = None
        convolution_default_21 = torch.ops.aten.convolution.default(relu__default_19, primals_251, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_245, primals_241, primals_243, primals_244, True, 0.1, 1e-05);  primals_241 = None
        getitem_63 = native_batch_norm_default_21[0]
        getitem_64 = native_batch_norm_default_21[1]
        getitem_65 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        relu__default_20 = torch.ops.aten.relu_.default(getitem_63);  getitem_63 = None
        convolution_default_22 = torch.ops.aten.convolution.default(relu__default_20, primals_252, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_250, primals_246, primals_248, primals_249, True, 0.1, 1e-05);  primals_246 = None
        getitem_66 = native_batch_norm_default_22[0]
        getitem_67 = native_batch_norm_default_22[1]
        getitem_68 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        add__tensor_29 = torch.ops.aten.add_.Tensor(getitem_66, relu__default_19);  getitem_66 = None
        relu__default_21 = torch.ops.aten.relu_.default(add__tensor_29);  add__tensor_29 = None
        convolution_default_23 = torch.ops.aten.convolution.default(relu__default_21, primals_263, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_257, primals_253, primals_255, primals_256, True, 0.1, 1e-05);  primals_253 = None
        getitem_69 = native_batch_norm_default_23[0]
        getitem_70 = native_batch_norm_default_23[1]
        getitem_71 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        relu__default_22 = torch.ops.aten.relu_.default(getitem_69);  getitem_69 = None
        convolution_default_24 = torch.ops.aten.convolution.default(relu__default_22, primals_264, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_262, primals_258, primals_260, primals_261, True, 0.1, 1e-05);  primals_258 = None
        getitem_72 = native_batch_norm_default_24[0]
        getitem_73 = native_batch_norm_default_24[1]
        getitem_74 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        add__tensor_32 = torch.ops.aten.add_.Tensor(getitem_72, relu__default_21);  getitem_72 = None
        relu__default_23 = torch.ops.aten.relu_.default(add__tensor_32);  add__tensor_32 = None
        convolution_default_25 = torch.ops.aten.convolution.default(relu__default_15, primals_275, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_269, primals_265, primals_267, primals_268, True, 0.1, 1e-05);  primals_265 = None
        getitem_75 = native_batch_norm_default_25[0]
        getitem_76 = native_batch_norm_default_25[1]
        getitem_77 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        relu__default_24 = torch.ops.aten.relu_.default(getitem_75);  getitem_75 = None
        convolution_default_26 = torch.ops.aten.convolution.default(relu__default_24, primals_276, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_274, primals_270, primals_272, primals_273, True, 0.1, 1e-05);  primals_270 = None
        getitem_78 = native_batch_norm_default_26[0]
        getitem_79 = native_batch_norm_default_26[1]
        getitem_80 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        add__tensor_35 = torch.ops.aten.add_.Tensor(getitem_78, relu__default_15);  getitem_78 = None
        relu__default_25 = torch.ops.aten.relu_.default(add__tensor_35);  add__tensor_35 = None
        convolution_default_27 = torch.ops.aten.convolution.default(relu__default_25, primals_287, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_281, primals_277, primals_279, primals_280, True, 0.1, 1e-05);  primals_277 = None
        getitem_81 = native_batch_norm_default_27[0]
        getitem_82 = native_batch_norm_default_27[1]
        getitem_83 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        relu__default_26 = torch.ops.aten.relu_.default(getitem_81);  getitem_81 = None
        convolution_default_28 = torch.ops.aten.convolution.default(relu__default_26, primals_288, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_286, primals_282, primals_284, primals_285, True, 0.1, 1e-05);  primals_282 = None
        getitem_84 = native_batch_norm_default_28[0]
        getitem_85 = native_batch_norm_default_28[1]
        getitem_86 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        add__tensor_38 = torch.ops.aten.add_.Tensor(getitem_84, relu__default_25);  getitem_84 = None
        relu__default_27 = torch.ops.aten.relu_.default(add__tensor_38);  add__tensor_38 = None
        convolution_default_29 = torch.ops.aten.convolution.default(relu__default_27, primals_299, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_293, primals_289, primals_291, primals_292, True, 0.1, 1e-05);  primals_289 = None
        getitem_87 = native_batch_norm_default_29[0]
        getitem_88 = native_batch_norm_default_29[1]
        getitem_89 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        relu__default_28 = torch.ops.aten.relu_.default(getitem_87);  getitem_87 = None
        convolution_default_30 = torch.ops.aten.convolution.default(relu__default_28, primals_300, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_298, primals_294, primals_296, primals_297, True, 0.1, 1e-05);  primals_294 = None
        getitem_90 = native_batch_norm_default_30[0]
        getitem_91 = native_batch_norm_default_30[1]
        getitem_92 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        add__tensor_41 = torch.ops.aten.add_.Tensor(getitem_90, relu__default_27);  getitem_90 = None
        relu__default_29 = torch.ops.aten.relu_.default(add__tensor_41);  add__tensor_41 = None
        convolution_default_31 = torch.ops.aten.convolution.default(relu__default_29, primals_311, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_31, primals_305, primals_301, primals_303, primals_304, True, 0.1, 1e-05);  primals_301 = None
        getitem_93 = native_batch_norm_default_31[0]
        getitem_94 = native_batch_norm_default_31[1]
        getitem_95 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        relu__default_30 = torch.ops.aten.relu_.default(getitem_93);  getitem_93 = None
        convolution_default_32 = torch.ops.aten.convolution.default(relu__default_30, primals_312, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_310, primals_306, primals_308, primals_309, True, 0.1, 1e-05);  primals_306 = None
        getitem_96 = native_batch_norm_default_32[0]
        getitem_97 = native_batch_norm_default_32[1]
        getitem_98 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        add__tensor_44 = torch.ops.aten.add_.Tensor(getitem_96, relu__default_29);  getitem_96 = None
        relu__default_31 = torch.ops.aten.relu_.default(add__tensor_44);  add__tensor_44 = None
        convolution_default_33 = torch.ops.aten.convolution.default(relu__default_31, primals_1675, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_1680, primals_1676, primals_1678, primals_1679, True, 0.1, 1e-05);  primals_1676 = None
        getitem_99 = native_batch_norm_default_33[0]
        getitem_100 = native_batch_norm_default_33[1]
        getitem_101 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        upsample_nearest2d_vec = torch.ops.aten.upsample_nearest2d.vec(getitem_99, None, [2.0, 2.0]);  getitem_99 = None
        add_tensor = torch.ops.aten.add.Tensor(relu__default_23, upsample_nearest2d_vec);  upsample_nearest2d_vec = None
        relu_default = torch.ops.aten.relu.default(add_tensor);  add_tensor = None
        convolution_default_34 = torch.ops.aten.convolution.default(relu__default_23, primals_1489, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_1494, primals_1490, primals_1492, primals_1493, True, 0.1, 1e-05);  primals_1490 = None
        getitem_102 = native_batch_norm_default_34[0]
        getitem_103 = native_batch_norm_default_34[1]
        getitem_104 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(getitem_102, relu__default_31);  getitem_102 = None
        relu_default_1 = torch.ops.aten.relu.default(add_tensor_1);  add_tensor_1 = None
        convolution_default_35 = torch.ops.aten.convolution.default(relu_default_1, primals_1477, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_1482, primals_1478, primals_1480, primals_1481, True, 0.1, 1e-05);  primals_1478 = None
        getitem_105 = native_batch_norm_default_35[0]
        getitem_106 = native_batch_norm_default_35[1]
        getitem_107 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        relu__default_32 = torch.ops.aten.relu_.default(getitem_105);  getitem_105 = None
        convolution_default_36 = torch.ops.aten.convolution.default(relu_default, primals_323, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_317, primals_313, primals_315, primals_316, True, 0.1, 1e-05);  primals_313 = None
        getitem_108 = native_batch_norm_default_36[0]
        getitem_109 = native_batch_norm_default_36[1]
        getitem_110 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        relu__default_33 = torch.ops.aten.relu_.default(getitem_108);  getitem_108 = None
        convolution_default_37 = torch.ops.aten.convolution.default(relu__default_33, primals_324, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_37, primals_322, primals_318, primals_320, primals_321, True, 0.1, 1e-05);  primals_318 = None
        getitem_111 = native_batch_norm_default_37[0]
        getitem_112 = native_batch_norm_default_37[1]
        getitem_113 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        add__tensor_50 = torch.ops.aten.add_.Tensor(getitem_111, relu_default);  getitem_111 = None
        relu__default_34 = torch.ops.aten.relu_.default(add__tensor_50);  add__tensor_50 = None
        convolution_default_38 = torch.ops.aten.convolution.default(relu__default_34, primals_335, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_329, primals_325, primals_327, primals_328, True, 0.1, 1e-05);  primals_325 = None
        getitem_114 = native_batch_norm_default_38[0]
        getitem_115 = native_batch_norm_default_38[1]
        getitem_116 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        relu__default_35 = torch.ops.aten.relu_.default(getitem_114);  getitem_114 = None
        convolution_default_39 = torch.ops.aten.convolution.default(relu__default_35, primals_336, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_39, primals_334, primals_330, primals_332, primals_333, True, 0.1, 1e-05);  primals_330 = None
        getitem_117 = native_batch_norm_default_39[0]
        getitem_118 = native_batch_norm_default_39[1]
        getitem_119 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        add__tensor_53 = torch.ops.aten.add_.Tensor(getitem_117, relu__default_34);  getitem_117 = None
        relu__default_36 = torch.ops.aten.relu_.default(add__tensor_53);  add__tensor_53 = None
        convolution_default_40 = torch.ops.aten.convolution.default(relu__default_36, primals_347, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_341, primals_337, primals_339, primals_340, True, 0.1, 1e-05);  primals_337 = None
        getitem_120 = native_batch_norm_default_40[0]
        getitem_121 = native_batch_norm_default_40[1]
        getitem_122 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        relu__default_37 = torch.ops.aten.relu_.default(getitem_120);  getitem_120 = None
        convolution_default_41 = torch.ops.aten.convolution.default(relu__default_37, primals_348, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_41, primals_346, primals_342, primals_344, primals_345, True, 0.1, 1e-05);  primals_342 = None
        getitem_123 = native_batch_norm_default_41[0]
        getitem_124 = native_batch_norm_default_41[1]
        getitem_125 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        add__tensor_56 = torch.ops.aten.add_.Tensor(getitem_123, relu__default_36);  getitem_123 = None
        relu__default_38 = torch.ops.aten.relu_.default(add__tensor_56);  add__tensor_56 = None
        convolution_default_42 = torch.ops.aten.convolution.default(relu__default_38, primals_359, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_42, primals_353, primals_349, primals_351, primals_352, True, 0.1, 1e-05);  primals_349 = None
        getitem_126 = native_batch_norm_default_42[0]
        getitem_127 = native_batch_norm_default_42[1]
        getitem_128 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        relu__default_39 = torch.ops.aten.relu_.default(getitem_126);  getitem_126 = None
        convolution_default_43 = torch.ops.aten.convolution.default(relu__default_39, primals_360, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_43, primals_358, primals_354, primals_356, primals_357, True, 0.1, 1e-05);  primals_354 = None
        getitem_129 = native_batch_norm_default_43[0]
        getitem_130 = native_batch_norm_default_43[1]
        getitem_131 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        add__tensor_59 = torch.ops.aten.add_.Tensor(getitem_129, relu__default_38);  getitem_129 = None
        relu__default_40 = torch.ops.aten.relu_.default(add__tensor_59);  add__tensor_59 = None
        convolution_default_44 = torch.ops.aten.convolution.default(relu_default_1, primals_371, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_365, primals_361, primals_363, primals_364, True, 0.1, 1e-05);  primals_361 = None
        getitem_132 = native_batch_norm_default_44[0]
        getitem_133 = native_batch_norm_default_44[1]
        getitem_134 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        relu__default_41 = torch.ops.aten.relu_.default(getitem_132);  getitem_132 = None
        convolution_default_45 = torch.ops.aten.convolution.default(relu__default_41, primals_372, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_45, primals_370, primals_366, primals_368, primals_369, True, 0.1, 1e-05);  primals_366 = None
        getitem_135 = native_batch_norm_default_45[0]
        getitem_136 = native_batch_norm_default_45[1]
        getitem_137 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        add__tensor_62 = torch.ops.aten.add_.Tensor(getitem_135, relu_default_1);  getitem_135 = None
        relu__default_42 = torch.ops.aten.relu_.default(add__tensor_62);  add__tensor_62 = None
        convolution_default_46 = torch.ops.aten.convolution.default(relu__default_42, primals_383, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(convolution_default_46, primals_377, primals_373, primals_375, primals_376, True, 0.1, 1e-05);  primals_373 = None
        getitem_138 = native_batch_norm_default_46[0]
        getitem_139 = native_batch_norm_default_46[1]
        getitem_140 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        relu__default_43 = torch.ops.aten.relu_.default(getitem_138);  getitem_138 = None
        convolution_default_47 = torch.ops.aten.convolution.default(relu__default_43, primals_384, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(convolution_default_47, primals_382, primals_378, primals_380, primals_381, True, 0.1, 1e-05);  primals_378 = None
        getitem_141 = native_batch_norm_default_47[0]
        getitem_142 = native_batch_norm_default_47[1]
        getitem_143 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        add__tensor_65 = torch.ops.aten.add_.Tensor(getitem_141, relu__default_42);  getitem_141 = None
        relu__default_44 = torch.ops.aten.relu_.default(add__tensor_65);  add__tensor_65 = None
        convolution_default_48 = torch.ops.aten.convolution.default(relu__default_44, primals_395, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_48, primals_389, primals_385, primals_387, primals_388, True, 0.1, 1e-05);  primals_385 = None
        getitem_144 = native_batch_norm_default_48[0]
        getitem_145 = native_batch_norm_default_48[1]
        getitem_146 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        relu__default_45 = torch.ops.aten.relu_.default(getitem_144);  getitem_144 = None
        convolution_default_49 = torch.ops.aten.convolution.default(relu__default_45, primals_396, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(convolution_default_49, primals_394, primals_390, primals_392, primals_393, True, 0.1, 1e-05);  primals_390 = None
        getitem_147 = native_batch_norm_default_49[0]
        getitem_148 = native_batch_norm_default_49[1]
        getitem_149 = native_batch_norm_default_49[2];  native_batch_norm_default_49 = None
        add__tensor_68 = torch.ops.aten.add_.Tensor(getitem_147, relu__default_44);  getitem_147 = None
        relu__default_46 = torch.ops.aten.relu_.default(add__tensor_68);  add__tensor_68 = None
        convolution_default_50 = torch.ops.aten.convolution.default(relu__default_46, primals_407, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(convolution_default_50, primals_401, primals_397, primals_399, primals_400, True, 0.1, 1e-05);  primals_397 = None
        getitem_150 = native_batch_norm_default_50[0]
        getitem_151 = native_batch_norm_default_50[1]
        getitem_152 = native_batch_norm_default_50[2];  native_batch_norm_default_50 = None
        relu__default_47 = torch.ops.aten.relu_.default(getitem_150);  getitem_150 = None
        convolution_default_51 = torch.ops.aten.convolution.default(relu__default_47, primals_408, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(convolution_default_51, primals_406, primals_402, primals_404, primals_405, True, 0.1, 1e-05);  primals_402 = None
        getitem_153 = native_batch_norm_default_51[0]
        getitem_154 = native_batch_norm_default_51[1]
        getitem_155 = native_batch_norm_default_51[2];  native_batch_norm_default_51 = None
        add__tensor_71 = torch.ops.aten.add_.Tensor(getitem_153, relu__default_46);  getitem_153 = None
        relu__default_48 = torch.ops.aten.relu_.default(add__tensor_71);  add__tensor_71 = None
        convolution_default_52 = torch.ops.aten.convolution.default(relu__default_32, primals_419, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(convolution_default_52, primals_413, primals_409, primals_411, primals_412, True, 0.1, 1e-05);  primals_409 = None
        getitem_156 = native_batch_norm_default_52[0]
        getitem_157 = native_batch_norm_default_52[1]
        getitem_158 = native_batch_norm_default_52[2];  native_batch_norm_default_52 = None
        relu__default_49 = torch.ops.aten.relu_.default(getitem_156);  getitem_156 = None
        convolution_default_53 = torch.ops.aten.convolution.default(relu__default_49, primals_420, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_53 = torch.ops.aten.native_batch_norm.default(convolution_default_53, primals_418, primals_414, primals_416, primals_417, True, 0.1, 1e-05);  primals_414 = None
        getitem_159 = native_batch_norm_default_53[0]
        getitem_160 = native_batch_norm_default_53[1]
        getitem_161 = native_batch_norm_default_53[2];  native_batch_norm_default_53 = None
        add__tensor_74 = torch.ops.aten.add_.Tensor(getitem_159, relu__default_32);  getitem_159 = None
        relu__default_50 = torch.ops.aten.relu_.default(add__tensor_74);  add__tensor_74 = None
        convolution_default_54 = torch.ops.aten.convolution.default(relu__default_50, primals_431, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_54 = torch.ops.aten.native_batch_norm.default(convolution_default_54, primals_425, primals_421, primals_423, primals_424, True, 0.1, 1e-05);  primals_421 = None
        getitem_162 = native_batch_norm_default_54[0]
        getitem_163 = native_batch_norm_default_54[1]
        getitem_164 = native_batch_norm_default_54[2];  native_batch_norm_default_54 = None
        relu__default_51 = torch.ops.aten.relu_.default(getitem_162);  getitem_162 = None
        convolution_default_55 = torch.ops.aten.convolution.default(relu__default_51, primals_432, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_55 = torch.ops.aten.native_batch_norm.default(convolution_default_55, primals_430, primals_426, primals_428, primals_429, True, 0.1, 1e-05);  primals_426 = None
        getitem_165 = native_batch_norm_default_55[0]
        getitem_166 = native_batch_norm_default_55[1]
        getitem_167 = native_batch_norm_default_55[2];  native_batch_norm_default_55 = None
        add__tensor_77 = torch.ops.aten.add_.Tensor(getitem_165, relu__default_50);  getitem_165 = None
        relu__default_52 = torch.ops.aten.relu_.default(add__tensor_77);  add__tensor_77 = None
        convolution_default_56 = torch.ops.aten.convolution.default(relu__default_52, primals_443, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_56 = torch.ops.aten.native_batch_norm.default(convolution_default_56, primals_437, primals_433, primals_435, primals_436, True, 0.1, 1e-05);  primals_433 = None
        getitem_168 = native_batch_norm_default_56[0]
        getitem_169 = native_batch_norm_default_56[1]
        getitem_170 = native_batch_norm_default_56[2];  native_batch_norm_default_56 = None
        relu__default_53 = torch.ops.aten.relu_.default(getitem_168);  getitem_168 = None
        convolution_default_57 = torch.ops.aten.convolution.default(relu__default_53, primals_444, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_57 = torch.ops.aten.native_batch_norm.default(convolution_default_57, primals_442, primals_438, primals_440, primals_441, True, 0.1, 1e-05);  primals_438 = None
        getitem_171 = native_batch_norm_default_57[0]
        getitem_172 = native_batch_norm_default_57[1]
        getitem_173 = native_batch_norm_default_57[2];  native_batch_norm_default_57 = None
        add__tensor_80 = torch.ops.aten.add_.Tensor(getitem_171, relu__default_52);  getitem_171 = None
        relu__default_54 = torch.ops.aten.relu_.default(add__tensor_80);  add__tensor_80 = None
        convolution_default_58 = torch.ops.aten.convolution.default(relu__default_54, primals_455, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_58 = torch.ops.aten.native_batch_norm.default(convolution_default_58, primals_449, primals_445, primals_447, primals_448, True, 0.1, 1e-05);  primals_445 = None
        getitem_174 = native_batch_norm_default_58[0]
        getitem_175 = native_batch_norm_default_58[1]
        getitem_176 = native_batch_norm_default_58[2];  native_batch_norm_default_58 = None
        relu__default_55 = torch.ops.aten.relu_.default(getitem_174);  getitem_174 = None
        convolution_default_59 = torch.ops.aten.convolution.default(relu__default_55, primals_456, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_59 = torch.ops.aten.native_batch_norm.default(convolution_default_59, primals_454, primals_450, primals_452, primals_453, True, 0.1, 1e-05);  primals_450 = None
        getitem_177 = native_batch_norm_default_59[0]
        getitem_178 = native_batch_norm_default_59[1]
        getitem_179 = native_batch_norm_default_59[2];  native_batch_norm_default_59 = None
        add__tensor_83 = torch.ops.aten.add_.Tensor(getitem_177, relu__default_54);  getitem_177 = None
        relu__default_56 = torch.ops.aten.relu_.default(add__tensor_83);  add__tensor_83 = None
        convolution_default_60 = torch.ops.aten.convolution.default(relu__default_48, primals_1759, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_60 = torch.ops.aten.native_batch_norm.default(convolution_default_60, primals_1764, primals_1760, primals_1762, primals_1763, True, 0.1, 1e-05);  primals_1760 = None
        getitem_180 = native_batch_norm_default_60[0]
        getitem_181 = native_batch_norm_default_60[1]
        getitem_182 = native_batch_norm_default_60[2];  native_batch_norm_default_60 = None
        upsample_nearest2d_vec_1 = torch.ops.aten.upsample_nearest2d.vec(getitem_180, None, [2.0, 2.0]);  getitem_180 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(relu__default_40, upsample_nearest2d_vec_1);  upsample_nearest2d_vec_1 = None
        convolution_default_61 = torch.ops.aten.convolution.default(relu__default_56, primals_1801, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_61 = torch.ops.aten.native_batch_norm.default(convolution_default_61, primals_1806, primals_1802, primals_1804, primals_1805, True, 0.1, 1e-05);  primals_1802 = None
        getitem_183 = native_batch_norm_default_61[0]
        getitem_184 = native_batch_norm_default_61[1]
        getitem_185 = native_batch_norm_default_61[2];  native_batch_norm_default_61 = None
        upsample_nearest2d_vec_2 = torch.ops.aten.upsample_nearest2d.vec(getitem_183, None, [4.0, 4.0]);  getitem_183 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(add_tensor_2, upsample_nearest2d_vec_2);  add_tensor_2 = upsample_nearest2d_vec_2 = None
        relu_default_2 = torch.ops.aten.relu.default(add_tensor_3);  add_tensor_3 = None
        convolution_default_62 = torch.ops.aten.convolution.default(relu__default_40, primals_1597, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_62 = torch.ops.aten.native_batch_norm.default(convolution_default_62, primals_1602, primals_1598, primals_1600, primals_1601, True, 0.1, 1e-05);  primals_1598 = None
        getitem_186 = native_batch_norm_default_62[0]
        getitem_187 = native_batch_norm_default_62[1]
        getitem_188 = native_batch_norm_default_62[2];  native_batch_norm_default_62 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(getitem_186, relu__default_48);  getitem_186 = None
        convolution_default_63 = torch.ops.aten.convolution.default(relu__default_56, primals_1861, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_63 = torch.ops.aten.native_batch_norm.default(convolution_default_63, primals_1866, primals_1862, primals_1864, primals_1865, True, 0.1, 1e-05);  primals_1862 = None
        getitem_189 = native_batch_norm_default_63[0]
        getitem_190 = native_batch_norm_default_63[1]
        getitem_191 = native_batch_norm_default_63[2];  native_batch_norm_default_63 = None
        upsample_nearest2d_vec_3 = torch.ops.aten.upsample_nearest2d.vec(getitem_189, None, [2.0, 2.0]);  getitem_189 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(add_tensor_4, upsample_nearest2d_vec_3);  add_tensor_4 = upsample_nearest2d_vec_3 = None
        relu_default_3 = torch.ops.aten.relu.default(add_tensor_5);  add_tensor_5 = None
        convolution_default_64 = torch.ops.aten.convolution.default(relu__default_40, primals_1603, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_64 = torch.ops.aten.native_batch_norm.default(convolution_default_64, primals_1608, primals_1604, primals_1606, primals_1607, True, 0.1, 1e-05);  primals_1604 = None
        getitem_192 = native_batch_norm_default_64[0]
        getitem_193 = native_batch_norm_default_64[1]
        getitem_194 = native_batch_norm_default_64[2];  native_batch_norm_default_64 = None
        relu_default_4 = torch.ops.aten.relu.default(getitem_192);  getitem_192 = None
        convolution_default_65 = torch.ops.aten.convolution.default(relu_default_4, primals_1609, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_65 = torch.ops.aten.native_batch_norm.default(convolution_default_65, primals_1614, primals_1610, primals_1612, primals_1613, True, 0.1, 1e-05);  primals_1610 = None
        getitem_195 = native_batch_norm_default_65[0]
        getitem_196 = native_batch_norm_default_65[1]
        getitem_197 = native_batch_norm_default_65[2];  native_batch_norm_default_65 = None
        convolution_default_66 = torch.ops.aten.convolution.default(relu__default_48, primals_1765, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_66 = torch.ops.aten.native_batch_norm.default(convolution_default_66, primals_1770, primals_1766, primals_1768, primals_1769, True, 0.1, 1e-05);  primals_1766 = None
        getitem_198 = native_batch_norm_default_66[0]
        getitem_199 = native_batch_norm_default_66[1]
        getitem_200 = native_batch_norm_default_66[2];  native_batch_norm_default_66 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(getitem_195, getitem_198);  getitem_195 = getitem_198 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(add_tensor_6, relu__default_56);  add_tensor_6 = None
        relu_default_5 = torch.ops.aten.relu.default(add_tensor_7);  add_tensor_7 = None
        convolution_default_67 = torch.ops.aten.convolution.default(relu_default_2, primals_467, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_67 = torch.ops.aten.native_batch_norm.default(convolution_default_67, primals_461, primals_457, primals_459, primals_460, True, 0.1, 1e-05);  primals_457 = None
        getitem_201 = native_batch_norm_default_67[0]
        getitem_202 = native_batch_norm_default_67[1]
        getitem_203 = native_batch_norm_default_67[2];  native_batch_norm_default_67 = None
        relu__default_57 = torch.ops.aten.relu_.default(getitem_201);  getitem_201 = None
        convolution_default_68 = torch.ops.aten.convolution.default(relu__default_57, primals_468, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_68 = torch.ops.aten.native_batch_norm.default(convolution_default_68, primals_466, primals_462, primals_464, primals_465, True, 0.1, 1e-05);  primals_462 = None
        getitem_204 = native_batch_norm_default_68[0]
        getitem_205 = native_batch_norm_default_68[1]
        getitem_206 = native_batch_norm_default_68[2];  native_batch_norm_default_68 = None
        add__tensor_93 = torch.ops.aten.add_.Tensor(getitem_204, relu_default_2);  getitem_204 = None
        relu__default_58 = torch.ops.aten.relu_.default(add__tensor_93);  add__tensor_93 = None
        convolution_default_69 = torch.ops.aten.convolution.default(relu__default_58, primals_479, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_69 = torch.ops.aten.native_batch_norm.default(convolution_default_69, primals_473, primals_469, primals_471, primals_472, True, 0.1, 1e-05);  primals_469 = None
        getitem_207 = native_batch_norm_default_69[0]
        getitem_208 = native_batch_norm_default_69[1]
        getitem_209 = native_batch_norm_default_69[2];  native_batch_norm_default_69 = None
        relu__default_59 = torch.ops.aten.relu_.default(getitem_207);  getitem_207 = None
        convolution_default_70 = torch.ops.aten.convolution.default(relu__default_59, primals_480, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_70 = torch.ops.aten.native_batch_norm.default(convolution_default_70, primals_478, primals_474, primals_476, primals_477, True, 0.1, 1e-05);  primals_474 = None
        getitem_210 = native_batch_norm_default_70[0]
        getitem_211 = native_batch_norm_default_70[1]
        getitem_212 = native_batch_norm_default_70[2];  native_batch_norm_default_70 = None
        add__tensor_96 = torch.ops.aten.add_.Tensor(getitem_210, relu__default_58);  getitem_210 = None
        relu__default_60 = torch.ops.aten.relu_.default(add__tensor_96);  add__tensor_96 = None
        convolution_default_71 = torch.ops.aten.convolution.default(relu__default_60, primals_491, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_71 = torch.ops.aten.native_batch_norm.default(convolution_default_71, primals_485, primals_481, primals_483, primals_484, True, 0.1, 1e-05);  primals_481 = None
        getitem_213 = native_batch_norm_default_71[0]
        getitem_214 = native_batch_norm_default_71[1]
        getitem_215 = native_batch_norm_default_71[2];  native_batch_norm_default_71 = None
        relu__default_61 = torch.ops.aten.relu_.default(getitem_213);  getitem_213 = None
        convolution_default_72 = torch.ops.aten.convolution.default(relu__default_61, primals_492, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_72 = torch.ops.aten.native_batch_norm.default(convolution_default_72, primals_490, primals_486, primals_488, primals_489, True, 0.1, 1e-05);  primals_486 = None
        getitem_216 = native_batch_norm_default_72[0]
        getitem_217 = native_batch_norm_default_72[1]
        getitem_218 = native_batch_norm_default_72[2];  native_batch_norm_default_72 = None
        add__tensor_99 = torch.ops.aten.add_.Tensor(getitem_216, relu__default_60);  getitem_216 = None
        relu__default_62 = torch.ops.aten.relu_.default(add__tensor_99);  add__tensor_99 = None
        convolution_default_73 = torch.ops.aten.convolution.default(relu__default_62, primals_503, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_73 = torch.ops.aten.native_batch_norm.default(convolution_default_73, primals_497, primals_493, primals_495, primals_496, True, 0.1, 1e-05);  primals_493 = None
        getitem_219 = native_batch_norm_default_73[0]
        getitem_220 = native_batch_norm_default_73[1]
        getitem_221 = native_batch_norm_default_73[2];  native_batch_norm_default_73 = None
        relu__default_63 = torch.ops.aten.relu_.default(getitem_219);  getitem_219 = None
        convolution_default_74 = torch.ops.aten.convolution.default(relu__default_63, primals_504, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_74 = torch.ops.aten.native_batch_norm.default(convolution_default_74, primals_502, primals_498, primals_500, primals_501, True, 0.1, 1e-05);  primals_498 = None
        getitem_222 = native_batch_norm_default_74[0]
        getitem_223 = native_batch_norm_default_74[1]
        getitem_224 = native_batch_norm_default_74[2];  native_batch_norm_default_74 = None
        add__tensor_102 = torch.ops.aten.add_.Tensor(getitem_222, relu__default_62);  getitem_222 = None
        relu__default_64 = torch.ops.aten.relu_.default(add__tensor_102);  add__tensor_102 = None
        convolution_default_75 = torch.ops.aten.convolution.default(relu_default_3, primals_515, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_75 = torch.ops.aten.native_batch_norm.default(convolution_default_75, primals_509, primals_505, primals_507, primals_508, True, 0.1, 1e-05);  primals_505 = None
        getitem_225 = native_batch_norm_default_75[0]
        getitem_226 = native_batch_norm_default_75[1]
        getitem_227 = native_batch_norm_default_75[2];  native_batch_norm_default_75 = None
        relu__default_65 = torch.ops.aten.relu_.default(getitem_225);  getitem_225 = None
        convolution_default_76 = torch.ops.aten.convolution.default(relu__default_65, primals_516, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_76 = torch.ops.aten.native_batch_norm.default(convolution_default_76, primals_514, primals_510, primals_512, primals_513, True, 0.1, 1e-05);  primals_510 = None
        getitem_228 = native_batch_norm_default_76[0]
        getitem_229 = native_batch_norm_default_76[1]
        getitem_230 = native_batch_norm_default_76[2];  native_batch_norm_default_76 = None
        add__tensor_105 = torch.ops.aten.add_.Tensor(getitem_228, relu_default_3);  getitem_228 = None
        relu__default_66 = torch.ops.aten.relu_.default(add__tensor_105);  add__tensor_105 = None
        convolution_default_77 = torch.ops.aten.convolution.default(relu__default_66, primals_527, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_77 = torch.ops.aten.native_batch_norm.default(convolution_default_77, primals_521, primals_517, primals_519, primals_520, True, 0.1, 1e-05);  primals_517 = None
        getitem_231 = native_batch_norm_default_77[0]
        getitem_232 = native_batch_norm_default_77[1]
        getitem_233 = native_batch_norm_default_77[2];  native_batch_norm_default_77 = None
        relu__default_67 = torch.ops.aten.relu_.default(getitem_231);  getitem_231 = None
        convolution_default_78 = torch.ops.aten.convolution.default(relu__default_67, primals_528, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_78 = torch.ops.aten.native_batch_norm.default(convolution_default_78, primals_526, primals_522, primals_524, primals_525, True, 0.1, 1e-05);  primals_522 = None
        getitem_234 = native_batch_norm_default_78[0]
        getitem_235 = native_batch_norm_default_78[1]
        getitem_236 = native_batch_norm_default_78[2];  native_batch_norm_default_78 = None
        add__tensor_108 = torch.ops.aten.add_.Tensor(getitem_234, relu__default_66);  getitem_234 = None
        relu__default_68 = torch.ops.aten.relu_.default(add__tensor_108);  add__tensor_108 = None
        convolution_default_79 = torch.ops.aten.convolution.default(relu__default_68, primals_539, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_79 = torch.ops.aten.native_batch_norm.default(convolution_default_79, primals_533, primals_529, primals_531, primals_532, True, 0.1, 1e-05);  primals_529 = None
        getitem_237 = native_batch_norm_default_79[0]
        getitem_238 = native_batch_norm_default_79[1]
        getitem_239 = native_batch_norm_default_79[2];  native_batch_norm_default_79 = None
        relu__default_69 = torch.ops.aten.relu_.default(getitem_237);  getitem_237 = None
        convolution_default_80 = torch.ops.aten.convolution.default(relu__default_69, primals_540, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_80 = torch.ops.aten.native_batch_norm.default(convolution_default_80, primals_538, primals_534, primals_536, primals_537, True, 0.1, 1e-05);  primals_534 = None
        getitem_240 = native_batch_norm_default_80[0]
        getitem_241 = native_batch_norm_default_80[1]
        getitem_242 = native_batch_norm_default_80[2];  native_batch_norm_default_80 = None
        add__tensor_111 = torch.ops.aten.add_.Tensor(getitem_240, relu__default_68);  getitem_240 = None
        relu__default_70 = torch.ops.aten.relu_.default(add__tensor_111);  add__tensor_111 = None
        convolution_default_81 = torch.ops.aten.convolution.default(relu__default_70, primals_551, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_81 = torch.ops.aten.native_batch_norm.default(convolution_default_81, primals_545, primals_541, primals_543, primals_544, True, 0.1, 1e-05);  primals_541 = None
        getitem_243 = native_batch_norm_default_81[0]
        getitem_244 = native_batch_norm_default_81[1]
        getitem_245 = native_batch_norm_default_81[2];  native_batch_norm_default_81 = None
        relu__default_71 = torch.ops.aten.relu_.default(getitem_243);  getitem_243 = None
        convolution_default_82 = torch.ops.aten.convolution.default(relu__default_71, primals_552, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_82 = torch.ops.aten.native_batch_norm.default(convolution_default_82, primals_550, primals_546, primals_548, primals_549, True, 0.1, 1e-05);  primals_546 = None
        getitem_246 = native_batch_norm_default_82[0]
        getitem_247 = native_batch_norm_default_82[1]
        getitem_248 = native_batch_norm_default_82[2];  native_batch_norm_default_82 = None
        add__tensor_114 = torch.ops.aten.add_.Tensor(getitem_246, relu__default_70);  getitem_246 = None
        relu__default_72 = torch.ops.aten.relu_.default(add__tensor_114);  add__tensor_114 = None
        convolution_default_83 = torch.ops.aten.convolution.default(relu_default_5, primals_563, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_83 = torch.ops.aten.native_batch_norm.default(convolution_default_83, primals_557, primals_553, primals_555, primals_556, True, 0.1, 1e-05);  primals_553 = None
        getitem_249 = native_batch_norm_default_83[0]
        getitem_250 = native_batch_norm_default_83[1]
        getitem_251 = native_batch_norm_default_83[2];  native_batch_norm_default_83 = None
        relu__default_73 = torch.ops.aten.relu_.default(getitem_249);  getitem_249 = None
        convolution_default_84 = torch.ops.aten.convolution.default(relu__default_73, primals_564, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_84 = torch.ops.aten.native_batch_norm.default(convolution_default_84, primals_562, primals_558, primals_560, primals_561, True, 0.1, 1e-05);  primals_558 = None
        getitem_252 = native_batch_norm_default_84[0]
        getitem_253 = native_batch_norm_default_84[1]
        getitem_254 = native_batch_norm_default_84[2];  native_batch_norm_default_84 = None
        add__tensor_117 = torch.ops.aten.add_.Tensor(getitem_252, relu_default_5);  getitem_252 = None
        relu__default_74 = torch.ops.aten.relu_.default(add__tensor_117);  add__tensor_117 = None
        convolution_default_85 = torch.ops.aten.convolution.default(relu__default_74, primals_575, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_85 = torch.ops.aten.native_batch_norm.default(convolution_default_85, primals_569, primals_565, primals_567, primals_568, True, 0.1, 1e-05);  primals_565 = None
        getitem_255 = native_batch_norm_default_85[0]
        getitem_256 = native_batch_norm_default_85[1]
        getitem_257 = native_batch_norm_default_85[2];  native_batch_norm_default_85 = None
        relu__default_75 = torch.ops.aten.relu_.default(getitem_255);  getitem_255 = None
        convolution_default_86 = torch.ops.aten.convolution.default(relu__default_75, primals_576, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_86 = torch.ops.aten.native_batch_norm.default(convolution_default_86, primals_574, primals_570, primals_572, primals_573, True, 0.1, 1e-05);  primals_570 = None
        getitem_258 = native_batch_norm_default_86[0]
        getitem_259 = native_batch_norm_default_86[1]
        getitem_260 = native_batch_norm_default_86[2];  native_batch_norm_default_86 = None
        add__tensor_120 = torch.ops.aten.add_.Tensor(getitem_258, relu__default_74);  getitem_258 = None
        relu__default_76 = torch.ops.aten.relu_.default(add__tensor_120);  add__tensor_120 = None
        convolution_default_87 = torch.ops.aten.convolution.default(relu__default_76, primals_587, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_87 = torch.ops.aten.native_batch_norm.default(convolution_default_87, primals_581, primals_577, primals_579, primals_580, True, 0.1, 1e-05);  primals_577 = None
        getitem_261 = native_batch_norm_default_87[0]
        getitem_262 = native_batch_norm_default_87[1]
        getitem_263 = native_batch_norm_default_87[2];  native_batch_norm_default_87 = None
        relu__default_77 = torch.ops.aten.relu_.default(getitem_261);  getitem_261 = None
        convolution_default_88 = torch.ops.aten.convolution.default(relu__default_77, primals_588, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_88 = torch.ops.aten.native_batch_norm.default(convolution_default_88, primals_586, primals_582, primals_584, primals_585, True, 0.1, 1e-05);  primals_582 = None
        getitem_264 = native_batch_norm_default_88[0]
        getitem_265 = native_batch_norm_default_88[1]
        getitem_266 = native_batch_norm_default_88[2];  native_batch_norm_default_88 = None
        add__tensor_123 = torch.ops.aten.add_.Tensor(getitem_264, relu__default_76);  getitem_264 = None
        relu__default_78 = torch.ops.aten.relu_.default(add__tensor_123);  add__tensor_123 = None
        convolution_default_89 = torch.ops.aten.convolution.default(relu__default_78, primals_599, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_89 = torch.ops.aten.native_batch_norm.default(convolution_default_89, primals_593, primals_589, primals_591, primals_592, True, 0.1, 1e-05);  primals_589 = None
        getitem_267 = native_batch_norm_default_89[0]
        getitem_268 = native_batch_norm_default_89[1]
        getitem_269 = native_batch_norm_default_89[2];  native_batch_norm_default_89 = None
        relu__default_79 = torch.ops.aten.relu_.default(getitem_267);  getitem_267 = None
        convolution_default_90 = torch.ops.aten.convolution.default(relu__default_79, primals_600, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_90 = torch.ops.aten.native_batch_norm.default(convolution_default_90, primals_598, primals_594, primals_596, primals_597, True, 0.1, 1e-05);  primals_594 = None
        getitem_270 = native_batch_norm_default_90[0]
        getitem_271 = native_batch_norm_default_90[1]
        getitem_272 = native_batch_norm_default_90[2];  native_batch_norm_default_90 = None
        add__tensor_126 = torch.ops.aten.add_.Tensor(getitem_270, relu__default_78);  getitem_270 = None
        relu__default_80 = torch.ops.aten.relu_.default(add__tensor_126);  add__tensor_126 = None
        convolution_default_91 = torch.ops.aten.convolution.default(relu__default_72, primals_1771, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_91 = torch.ops.aten.native_batch_norm.default(convolution_default_91, primals_1776, primals_1772, primals_1774, primals_1775, True, 0.1, 1e-05);  primals_1772 = None
        getitem_273 = native_batch_norm_default_91[0]
        getitem_274 = native_batch_norm_default_91[1]
        getitem_275 = native_batch_norm_default_91[2];  native_batch_norm_default_91 = None
        upsample_nearest2d_vec_4 = torch.ops.aten.upsample_nearest2d.vec(getitem_273, None, [2.0, 2.0]);  getitem_273 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(relu__default_64, upsample_nearest2d_vec_4);  upsample_nearest2d_vec_4 = None
        convolution_default_92 = torch.ops.aten.convolution.default(relu__default_80, primals_1867, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_92 = torch.ops.aten.native_batch_norm.default(convolution_default_92, primals_1872, primals_1868, primals_1870, primals_1871, True, 0.1, 1e-05);  primals_1868 = None
        getitem_276 = native_batch_norm_default_92[0]
        getitem_277 = native_batch_norm_default_92[1]
        getitem_278 = native_batch_norm_default_92[2];  native_batch_norm_default_92 = None
        upsample_nearest2d_vec_5 = torch.ops.aten.upsample_nearest2d.vec(getitem_276, None, [4.0, 4.0]);  getitem_276 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(add_tensor_8, upsample_nearest2d_vec_5);  add_tensor_8 = upsample_nearest2d_vec_5 = None
        relu_default_6 = torch.ops.aten.relu.default(add_tensor_9);  add_tensor_9 = None
        convolution_default_93 = torch.ops.aten.convolution.default(relu__default_64, primals_1615, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_93 = torch.ops.aten.native_batch_norm.default(convolution_default_93, primals_1620, primals_1616, primals_1618, primals_1619, True, 0.1, 1e-05);  primals_1616 = None
        getitem_279 = native_batch_norm_default_93[0]
        getitem_280 = native_batch_norm_default_93[1]
        getitem_281 = native_batch_norm_default_93[2];  native_batch_norm_default_93 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(getitem_279, relu__default_72);  getitem_279 = None
        convolution_default_94 = torch.ops.aten.convolution.default(relu__default_80, primals_1873, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_94 = torch.ops.aten.native_batch_norm.default(convolution_default_94, primals_1878, primals_1874, primals_1876, primals_1877, True, 0.1, 1e-05);  primals_1874 = None
        getitem_282 = native_batch_norm_default_94[0]
        getitem_283 = native_batch_norm_default_94[1]
        getitem_284 = native_batch_norm_default_94[2];  native_batch_norm_default_94 = None
        upsample_nearest2d_vec_6 = torch.ops.aten.upsample_nearest2d.vec(getitem_282, None, [2.0, 2.0]);  getitem_282 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(add_tensor_10, upsample_nearest2d_vec_6);  add_tensor_10 = upsample_nearest2d_vec_6 = None
        relu_default_7 = torch.ops.aten.relu.default(add_tensor_11);  add_tensor_11 = None
        convolution_default_95 = torch.ops.aten.convolution.default(relu__default_64, primals_1621, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_95 = torch.ops.aten.native_batch_norm.default(convolution_default_95, primals_1626, primals_1622, primals_1624, primals_1625, True, 0.1, 1e-05);  primals_1622 = None
        getitem_285 = native_batch_norm_default_95[0]
        getitem_286 = native_batch_norm_default_95[1]
        getitem_287 = native_batch_norm_default_95[2];  native_batch_norm_default_95 = None
        relu_default_8 = torch.ops.aten.relu.default(getitem_285);  getitem_285 = None
        convolution_default_96 = torch.ops.aten.convolution.default(relu_default_8, primals_1627, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_96 = torch.ops.aten.native_batch_norm.default(convolution_default_96, primals_1632, primals_1628, primals_1630, primals_1631, True, 0.1, 1e-05);  primals_1628 = None
        getitem_288 = native_batch_norm_default_96[0]
        getitem_289 = native_batch_norm_default_96[1]
        getitem_290 = native_batch_norm_default_96[2];  native_batch_norm_default_96 = None
        convolution_default_97 = torch.ops.aten.convolution.default(relu__default_72, primals_1777, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_97 = torch.ops.aten.native_batch_norm.default(convolution_default_97, primals_1782, primals_1778, primals_1780, primals_1781, True, 0.1, 1e-05);  primals_1778 = None
        getitem_291 = native_batch_norm_default_97[0]
        getitem_292 = native_batch_norm_default_97[1]
        getitem_293 = native_batch_norm_default_97[2];  native_batch_norm_default_97 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(getitem_288, getitem_291);  getitem_288 = getitem_291 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(add_tensor_12, relu__default_80);  add_tensor_12 = None
        relu_default_9 = torch.ops.aten.relu.default(add_tensor_13);  add_tensor_13 = None
        convolution_default_98 = torch.ops.aten.convolution.default(relu_default_6, primals_611, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_98 = torch.ops.aten.native_batch_norm.default(convolution_default_98, primals_605, primals_601, primals_603, primals_604, True, 0.1, 1e-05);  primals_601 = None
        getitem_294 = native_batch_norm_default_98[0]
        getitem_295 = native_batch_norm_default_98[1]
        getitem_296 = native_batch_norm_default_98[2];  native_batch_norm_default_98 = None
        relu__default_81 = torch.ops.aten.relu_.default(getitem_294);  getitem_294 = None
        convolution_default_99 = torch.ops.aten.convolution.default(relu__default_81, primals_612, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_99 = torch.ops.aten.native_batch_norm.default(convolution_default_99, primals_610, primals_606, primals_608, primals_609, True, 0.1, 1e-05);  primals_606 = None
        getitem_297 = native_batch_norm_default_99[0]
        getitem_298 = native_batch_norm_default_99[1]
        getitem_299 = native_batch_norm_default_99[2];  native_batch_norm_default_99 = None
        add__tensor_136 = torch.ops.aten.add_.Tensor(getitem_297, relu_default_6);  getitem_297 = None
        relu__default_82 = torch.ops.aten.relu_.default(add__tensor_136);  add__tensor_136 = None
        convolution_default_100 = torch.ops.aten.convolution.default(relu__default_82, primals_623, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_100 = torch.ops.aten.native_batch_norm.default(convolution_default_100, primals_617, primals_613, primals_615, primals_616, True, 0.1, 1e-05);  primals_613 = None
        getitem_300 = native_batch_norm_default_100[0]
        getitem_301 = native_batch_norm_default_100[1]
        getitem_302 = native_batch_norm_default_100[2];  native_batch_norm_default_100 = None
        relu__default_83 = torch.ops.aten.relu_.default(getitem_300);  getitem_300 = None
        convolution_default_101 = torch.ops.aten.convolution.default(relu__default_83, primals_624, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_101 = torch.ops.aten.native_batch_norm.default(convolution_default_101, primals_622, primals_618, primals_620, primals_621, True, 0.1, 1e-05);  primals_618 = None
        getitem_303 = native_batch_norm_default_101[0]
        getitem_304 = native_batch_norm_default_101[1]
        getitem_305 = native_batch_norm_default_101[2];  native_batch_norm_default_101 = None
        add__tensor_139 = torch.ops.aten.add_.Tensor(getitem_303, relu__default_82);  getitem_303 = None
        relu__default_84 = torch.ops.aten.relu_.default(add__tensor_139);  add__tensor_139 = None
        convolution_default_102 = torch.ops.aten.convolution.default(relu__default_84, primals_635, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_102 = torch.ops.aten.native_batch_norm.default(convolution_default_102, primals_629, primals_625, primals_627, primals_628, True, 0.1, 1e-05);  primals_625 = None
        getitem_306 = native_batch_norm_default_102[0]
        getitem_307 = native_batch_norm_default_102[1]
        getitem_308 = native_batch_norm_default_102[2];  native_batch_norm_default_102 = None
        relu__default_85 = torch.ops.aten.relu_.default(getitem_306);  getitem_306 = None
        convolution_default_103 = torch.ops.aten.convolution.default(relu__default_85, primals_636, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_103 = torch.ops.aten.native_batch_norm.default(convolution_default_103, primals_634, primals_630, primals_632, primals_633, True, 0.1, 1e-05);  primals_630 = None
        getitem_309 = native_batch_norm_default_103[0]
        getitem_310 = native_batch_norm_default_103[1]
        getitem_311 = native_batch_norm_default_103[2];  native_batch_norm_default_103 = None
        add__tensor_142 = torch.ops.aten.add_.Tensor(getitem_309, relu__default_84);  getitem_309 = None
        relu__default_86 = torch.ops.aten.relu_.default(add__tensor_142);  add__tensor_142 = None
        convolution_default_104 = torch.ops.aten.convolution.default(relu__default_86, primals_647, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_104 = torch.ops.aten.native_batch_norm.default(convolution_default_104, primals_641, primals_637, primals_639, primals_640, True, 0.1, 1e-05);  primals_637 = None
        getitem_312 = native_batch_norm_default_104[0]
        getitem_313 = native_batch_norm_default_104[1]
        getitem_314 = native_batch_norm_default_104[2];  native_batch_norm_default_104 = None
        relu__default_87 = torch.ops.aten.relu_.default(getitem_312);  getitem_312 = None
        convolution_default_105 = torch.ops.aten.convolution.default(relu__default_87, primals_648, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_105 = torch.ops.aten.native_batch_norm.default(convolution_default_105, primals_646, primals_642, primals_644, primals_645, True, 0.1, 1e-05);  primals_642 = None
        getitem_315 = native_batch_norm_default_105[0]
        getitem_316 = native_batch_norm_default_105[1]
        getitem_317 = native_batch_norm_default_105[2];  native_batch_norm_default_105 = None
        add__tensor_145 = torch.ops.aten.add_.Tensor(getitem_315, relu__default_86);  getitem_315 = None
        relu__default_88 = torch.ops.aten.relu_.default(add__tensor_145);  add__tensor_145 = None
        convolution_default_106 = torch.ops.aten.convolution.default(relu_default_7, primals_659, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_106 = torch.ops.aten.native_batch_norm.default(convolution_default_106, primals_653, primals_649, primals_651, primals_652, True, 0.1, 1e-05);  primals_649 = None
        getitem_318 = native_batch_norm_default_106[0]
        getitem_319 = native_batch_norm_default_106[1]
        getitem_320 = native_batch_norm_default_106[2];  native_batch_norm_default_106 = None
        relu__default_89 = torch.ops.aten.relu_.default(getitem_318);  getitem_318 = None
        convolution_default_107 = torch.ops.aten.convolution.default(relu__default_89, primals_660, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_107 = torch.ops.aten.native_batch_norm.default(convolution_default_107, primals_658, primals_654, primals_656, primals_657, True, 0.1, 1e-05);  primals_654 = None
        getitem_321 = native_batch_norm_default_107[0]
        getitem_322 = native_batch_norm_default_107[1]
        getitem_323 = native_batch_norm_default_107[2];  native_batch_norm_default_107 = None
        add__tensor_148 = torch.ops.aten.add_.Tensor(getitem_321, relu_default_7);  getitem_321 = None
        relu__default_90 = torch.ops.aten.relu_.default(add__tensor_148);  add__tensor_148 = None
        convolution_default_108 = torch.ops.aten.convolution.default(relu__default_90, primals_671, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_108 = torch.ops.aten.native_batch_norm.default(convolution_default_108, primals_665, primals_661, primals_663, primals_664, True, 0.1, 1e-05);  primals_661 = None
        getitem_324 = native_batch_norm_default_108[0]
        getitem_325 = native_batch_norm_default_108[1]
        getitem_326 = native_batch_norm_default_108[2];  native_batch_norm_default_108 = None
        relu__default_91 = torch.ops.aten.relu_.default(getitem_324);  getitem_324 = None
        convolution_default_109 = torch.ops.aten.convolution.default(relu__default_91, primals_672, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_109 = torch.ops.aten.native_batch_norm.default(convolution_default_109, primals_670, primals_666, primals_668, primals_669, True, 0.1, 1e-05);  primals_666 = None
        getitem_327 = native_batch_norm_default_109[0]
        getitem_328 = native_batch_norm_default_109[1]
        getitem_329 = native_batch_norm_default_109[2];  native_batch_norm_default_109 = None
        add__tensor_151 = torch.ops.aten.add_.Tensor(getitem_327, relu__default_90);  getitem_327 = None
        relu__default_92 = torch.ops.aten.relu_.default(add__tensor_151);  add__tensor_151 = None
        convolution_default_110 = torch.ops.aten.convolution.default(relu__default_92, primals_683, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_110 = torch.ops.aten.native_batch_norm.default(convolution_default_110, primals_677, primals_673, primals_675, primals_676, True, 0.1, 1e-05);  primals_673 = None
        getitem_330 = native_batch_norm_default_110[0]
        getitem_331 = native_batch_norm_default_110[1]
        getitem_332 = native_batch_norm_default_110[2];  native_batch_norm_default_110 = None
        relu__default_93 = torch.ops.aten.relu_.default(getitem_330);  getitem_330 = None
        convolution_default_111 = torch.ops.aten.convolution.default(relu__default_93, primals_684, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_111 = torch.ops.aten.native_batch_norm.default(convolution_default_111, primals_682, primals_678, primals_680, primals_681, True, 0.1, 1e-05);  primals_678 = None
        getitem_333 = native_batch_norm_default_111[0]
        getitem_334 = native_batch_norm_default_111[1]
        getitem_335 = native_batch_norm_default_111[2];  native_batch_norm_default_111 = None
        add__tensor_154 = torch.ops.aten.add_.Tensor(getitem_333, relu__default_92);  getitem_333 = None
        relu__default_94 = torch.ops.aten.relu_.default(add__tensor_154);  add__tensor_154 = None
        convolution_default_112 = torch.ops.aten.convolution.default(relu__default_94, primals_695, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_112 = torch.ops.aten.native_batch_norm.default(convolution_default_112, primals_689, primals_685, primals_687, primals_688, True, 0.1, 1e-05);  primals_685 = None
        getitem_336 = native_batch_norm_default_112[0]
        getitem_337 = native_batch_norm_default_112[1]
        getitem_338 = native_batch_norm_default_112[2];  native_batch_norm_default_112 = None
        relu__default_95 = torch.ops.aten.relu_.default(getitem_336);  getitem_336 = None
        convolution_default_113 = torch.ops.aten.convolution.default(relu__default_95, primals_696, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_113 = torch.ops.aten.native_batch_norm.default(convolution_default_113, primals_694, primals_690, primals_692, primals_693, True, 0.1, 1e-05);  primals_690 = None
        getitem_339 = native_batch_norm_default_113[0]
        getitem_340 = native_batch_norm_default_113[1]
        getitem_341 = native_batch_norm_default_113[2];  native_batch_norm_default_113 = None
        add__tensor_157 = torch.ops.aten.add_.Tensor(getitem_339, relu__default_94);  getitem_339 = None
        relu__default_96 = torch.ops.aten.relu_.default(add__tensor_157);  add__tensor_157 = None
        convolution_default_114 = torch.ops.aten.convolution.default(relu_default_9, primals_707, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_114 = torch.ops.aten.native_batch_norm.default(convolution_default_114, primals_701, primals_697, primals_699, primals_700, True, 0.1, 1e-05);  primals_697 = None
        getitem_342 = native_batch_norm_default_114[0]
        getitem_343 = native_batch_norm_default_114[1]
        getitem_344 = native_batch_norm_default_114[2];  native_batch_norm_default_114 = None
        relu__default_97 = torch.ops.aten.relu_.default(getitem_342);  getitem_342 = None
        convolution_default_115 = torch.ops.aten.convolution.default(relu__default_97, primals_708, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_115 = torch.ops.aten.native_batch_norm.default(convolution_default_115, primals_706, primals_702, primals_704, primals_705, True, 0.1, 1e-05);  primals_702 = None
        getitem_345 = native_batch_norm_default_115[0]
        getitem_346 = native_batch_norm_default_115[1]
        getitem_347 = native_batch_norm_default_115[2];  native_batch_norm_default_115 = None
        add__tensor_160 = torch.ops.aten.add_.Tensor(getitem_345, relu_default_9);  getitem_345 = None
        relu__default_98 = torch.ops.aten.relu_.default(add__tensor_160);  add__tensor_160 = None
        convolution_default_116 = torch.ops.aten.convolution.default(relu__default_98, primals_719, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_116 = torch.ops.aten.native_batch_norm.default(convolution_default_116, primals_713, primals_709, primals_711, primals_712, True, 0.1, 1e-05);  primals_709 = None
        getitem_348 = native_batch_norm_default_116[0]
        getitem_349 = native_batch_norm_default_116[1]
        getitem_350 = native_batch_norm_default_116[2];  native_batch_norm_default_116 = None
        relu__default_99 = torch.ops.aten.relu_.default(getitem_348);  getitem_348 = None
        convolution_default_117 = torch.ops.aten.convolution.default(relu__default_99, primals_720, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_117 = torch.ops.aten.native_batch_norm.default(convolution_default_117, primals_718, primals_714, primals_716, primals_717, True, 0.1, 1e-05);  primals_714 = None
        getitem_351 = native_batch_norm_default_117[0]
        getitem_352 = native_batch_norm_default_117[1]
        getitem_353 = native_batch_norm_default_117[2];  native_batch_norm_default_117 = None
        add__tensor_163 = torch.ops.aten.add_.Tensor(getitem_351, relu__default_98);  getitem_351 = None
        relu__default_100 = torch.ops.aten.relu_.default(add__tensor_163);  add__tensor_163 = None
        convolution_default_118 = torch.ops.aten.convolution.default(relu__default_100, primals_731, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_118 = torch.ops.aten.native_batch_norm.default(convolution_default_118, primals_725, primals_721, primals_723, primals_724, True, 0.1, 1e-05);  primals_721 = None
        getitem_354 = native_batch_norm_default_118[0]
        getitem_355 = native_batch_norm_default_118[1]
        getitem_356 = native_batch_norm_default_118[2];  native_batch_norm_default_118 = None
        relu__default_101 = torch.ops.aten.relu_.default(getitem_354);  getitem_354 = None
        convolution_default_119 = torch.ops.aten.convolution.default(relu__default_101, primals_732, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_119 = torch.ops.aten.native_batch_norm.default(convolution_default_119, primals_730, primals_726, primals_728, primals_729, True, 0.1, 1e-05);  primals_726 = None
        getitem_357 = native_batch_norm_default_119[0]
        getitem_358 = native_batch_norm_default_119[1]
        getitem_359 = native_batch_norm_default_119[2];  native_batch_norm_default_119 = None
        add__tensor_166 = torch.ops.aten.add_.Tensor(getitem_357, relu__default_100);  getitem_357 = None
        relu__default_102 = torch.ops.aten.relu_.default(add__tensor_166);  add__tensor_166 = None
        convolution_default_120 = torch.ops.aten.convolution.default(relu__default_102, primals_743, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_120 = torch.ops.aten.native_batch_norm.default(convolution_default_120, primals_737, primals_733, primals_735, primals_736, True, 0.1, 1e-05);  primals_733 = None
        getitem_360 = native_batch_norm_default_120[0]
        getitem_361 = native_batch_norm_default_120[1]
        getitem_362 = native_batch_norm_default_120[2];  native_batch_norm_default_120 = None
        relu__default_103 = torch.ops.aten.relu_.default(getitem_360);  getitem_360 = None
        convolution_default_121 = torch.ops.aten.convolution.default(relu__default_103, primals_744, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_121 = torch.ops.aten.native_batch_norm.default(convolution_default_121, primals_742, primals_738, primals_740, primals_741, True, 0.1, 1e-05);  primals_738 = None
        getitem_363 = native_batch_norm_default_121[0]
        getitem_364 = native_batch_norm_default_121[1]
        getitem_365 = native_batch_norm_default_121[2];  native_batch_norm_default_121 = None
        add__tensor_169 = torch.ops.aten.add_.Tensor(getitem_363, relu__default_102);  getitem_363 = None
        relu__default_104 = torch.ops.aten.relu_.default(add__tensor_169);  add__tensor_169 = None
        convolution_default_122 = torch.ops.aten.convolution.default(relu__default_96, primals_1783, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_122 = torch.ops.aten.native_batch_norm.default(convolution_default_122, primals_1788, primals_1784, primals_1786, primals_1787, True, 0.1, 1e-05);  primals_1784 = None
        getitem_366 = native_batch_norm_default_122[0]
        getitem_367 = native_batch_norm_default_122[1]
        getitem_368 = native_batch_norm_default_122[2];  native_batch_norm_default_122 = None
        upsample_nearest2d_vec_7 = torch.ops.aten.upsample_nearest2d.vec(getitem_366, None, [2.0, 2.0]);  getitem_366 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(relu__default_88, upsample_nearest2d_vec_7);  upsample_nearest2d_vec_7 = None
        convolution_default_123 = torch.ops.aten.convolution.default(relu__default_104, primals_1879, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_123 = torch.ops.aten.native_batch_norm.default(convolution_default_123, primals_1884, primals_1880, primals_1882, primals_1883, True, 0.1, 1e-05);  primals_1880 = None
        getitem_369 = native_batch_norm_default_123[0]
        getitem_370 = native_batch_norm_default_123[1]
        getitem_371 = native_batch_norm_default_123[2];  native_batch_norm_default_123 = None
        upsample_nearest2d_vec_8 = torch.ops.aten.upsample_nearest2d.vec(getitem_369, None, [4.0, 4.0]);  getitem_369 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(add_tensor_14, upsample_nearest2d_vec_8);  add_tensor_14 = upsample_nearest2d_vec_8 = None
        relu_default_10 = torch.ops.aten.relu.default(add_tensor_15);  add_tensor_15 = None
        convolution_default_124 = torch.ops.aten.convolution.default(relu__default_88, primals_1633, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_124 = torch.ops.aten.native_batch_norm.default(convolution_default_124, primals_1638, primals_1634, primals_1636, primals_1637, True, 0.1, 1e-05);  primals_1634 = None
        getitem_372 = native_batch_norm_default_124[0]
        getitem_373 = native_batch_norm_default_124[1]
        getitem_374 = native_batch_norm_default_124[2];  native_batch_norm_default_124 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(getitem_372, relu__default_96);  getitem_372 = None
        convolution_default_125 = torch.ops.aten.convolution.default(relu__default_104, primals_1885, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_125 = torch.ops.aten.native_batch_norm.default(convolution_default_125, primals_1890, primals_1886, primals_1888, primals_1889, True, 0.1, 1e-05);  primals_1886 = None
        getitem_375 = native_batch_norm_default_125[0]
        getitem_376 = native_batch_norm_default_125[1]
        getitem_377 = native_batch_norm_default_125[2];  native_batch_norm_default_125 = None
        upsample_nearest2d_vec_9 = torch.ops.aten.upsample_nearest2d.vec(getitem_375, None, [2.0, 2.0]);  getitem_375 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(add_tensor_16, upsample_nearest2d_vec_9);  add_tensor_16 = upsample_nearest2d_vec_9 = None
        relu_default_11 = torch.ops.aten.relu.default(add_tensor_17);  add_tensor_17 = None
        convolution_default_126 = torch.ops.aten.convolution.default(relu__default_88, primals_1639, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_126 = torch.ops.aten.native_batch_norm.default(convolution_default_126, primals_1644, primals_1640, primals_1642, primals_1643, True, 0.1, 1e-05);  primals_1640 = None
        getitem_378 = native_batch_norm_default_126[0]
        getitem_379 = native_batch_norm_default_126[1]
        getitem_380 = native_batch_norm_default_126[2];  native_batch_norm_default_126 = None
        relu_default_12 = torch.ops.aten.relu.default(getitem_378);  getitem_378 = None
        convolution_default_127 = torch.ops.aten.convolution.default(relu_default_12, primals_1645, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_127 = torch.ops.aten.native_batch_norm.default(convolution_default_127, primals_1650, primals_1646, primals_1648, primals_1649, True, 0.1, 1e-05);  primals_1646 = None
        getitem_381 = native_batch_norm_default_127[0]
        getitem_382 = native_batch_norm_default_127[1]
        getitem_383 = native_batch_norm_default_127[2];  native_batch_norm_default_127 = None
        convolution_default_128 = torch.ops.aten.convolution.default(relu__default_96, primals_1789, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_128 = torch.ops.aten.native_batch_norm.default(convolution_default_128, primals_1794, primals_1790, primals_1792, primals_1793, True, 0.1, 1e-05);  primals_1790 = None
        getitem_384 = native_batch_norm_default_128[0]
        getitem_385 = native_batch_norm_default_128[1]
        getitem_386 = native_batch_norm_default_128[2];  native_batch_norm_default_128 = None
        add_tensor_18 = torch.ops.aten.add.Tensor(getitem_381, getitem_384);  getitem_381 = getitem_384 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(add_tensor_18, relu__default_104);  add_tensor_18 = None
        relu_default_13 = torch.ops.aten.relu.default(add_tensor_19);  add_tensor_19 = None
        convolution_default_129 = torch.ops.aten.convolution.default(relu_default_10, primals_755, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_129 = torch.ops.aten.native_batch_norm.default(convolution_default_129, primals_749, primals_745, primals_747, primals_748, True, 0.1, 1e-05);  primals_745 = None
        getitem_387 = native_batch_norm_default_129[0]
        getitem_388 = native_batch_norm_default_129[1]
        getitem_389 = native_batch_norm_default_129[2];  native_batch_norm_default_129 = None
        relu__default_105 = torch.ops.aten.relu_.default(getitem_387);  getitem_387 = None
        convolution_default_130 = torch.ops.aten.convolution.default(relu__default_105, primals_756, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_130 = torch.ops.aten.native_batch_norm.default(convolution_default_130, primals_754, primals_750, primals_752, primals_753, True, 0.1, 1e-05);  primals_750 = None
        getitem_390 = native_batch_norm_default_130[0]
        getitem_391 = native_batch_norm_default_130[1]
        getitem_392 = native_batch_norm_default_130[2];  native_batch_norm_default_130 = None
        add__tensor_179 = torch.ops.aten.add_.Tensor(getitem_390, relu_default_10);  getitem_390 = None
        relu__default_106 = torch.ops.aten.relu_.default(add__tensor_179);  add__tensor_179 = None
        convolution_default_131 = torch.ops.aten.convolution.default(relu__default_106, primals_767, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_131 = torch.ops.aten.native_batch_norm.default(convolution_default_131, primals_761, primals_757, primals_759, primals_760, True, 0.1, 1e-05);  primals_757 = None
        getitem_393 = native_batch_norm_default_131[0]
        getitem_394 = native_batch_norm_default_131[1]
        getitem_395 = native_batch_norm_default_131[2];  native_batch_norm_default_131 = None
        relu__default_107 = torch.ops.aten.relu_.default(getitem_393);  getitem_393 = None
        convolution_default_132 = torch.ops.aten.convolution.default(relu__default_107, primals_768, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_132 = torch.ops.aten.native_batch_norm.default(convolution_default_132, primals_766, primals_762, primals_764, primals_765, True, 0.1, 1e-05);  primals_762 = None
        getitem_396 = native_batch_norm_default_132[0]
        getitem_397 = native_batch_norm_default_132[1]
        getitem_398 = native_batch_norm_default_132[2];  native_batch_norm_default_132 = None
        add__tensor_182 = torch.ops.aten.add_.Tensor(getitem_396, relu__default_106);  getitem_396 = None
        relu__default_108 = torch.ops.aten.relu_.default(add__tensor_182);  add__tensor_182 = None
        convolution_default_133 = torch.ops.aten.convolution.default(relu__default_108, primals_779, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_133 = torch.ops.aten.native_batch_norm.default(convolution_default_133, primals_773, primals_769, primals_771, primals_772, True, 0.1, 1e-05);  primals_769 = None
        getitem_399 = native_batch_norm_default_133[0]
        getitem_400 = native_batch_norm_default_133[1]
        getitem_401 = native_batch_norm_default_133[2];  native_batch_norm_default_133 = None
        relu__default_109 = torch.ops.aten.relu_.default(getitem_399);  getitem_399 = None
        convolution_default_134 = torch.ops.aten.convolution.default(relu__default_109, primals_780, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_134 = torch.ops.aten.native_batch_norm.default(convolution_default_134, primals_778, primals_774, primals_776, primals_777, True, 0.1, 1e-05);  primals_774 = None
        getitem_402 = native_batch_norm_default_134[0]
        getitem_403 = native_batch_norm_default_134[1]
        getitem_404 = native_batch_norm_default_134[2];  native_batch_norm_default_134 = None
        add__tensor_185 = torch.ops.aten.add_.Tensor(getitem_402, relu__default_108);  getitem_402 = None
        relu__default_110 = torch.ops.aten.relu_.default(add__tensor_185);  add__tensor_185 = None
        convolution_default_135 = torch.ops.aten.convolution.default(relu__default_110, primals_791, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_135 = torch.ops.aten.native_batch_norm.default(convolution_default_135, primals_785, primals_781, primals_783, primals_784, True, 0.1, 1e-05);  primals_781 = None
        getitem_405 = native_batch_norm_default_135[0]
        getitem_406 = native_batch_norm_default_135[1]
        getitem_407 = native_batch_norm_default_135[2];  native_batch_norm_default_135 = None
        relu__default_111 = torch.ops.aten.relu_.default(getitem_405);  getitem_405 = None
        convolution_default_136 = torch.ops.aten.convolution.default(relu__default_111, primals_792, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_136 = torch.ops.aten.native_batch_norm.default(convolution_default_136, primals_790, primals_786, primals_788, primals_789, True, 0.1, 1e-05);  primals_786 = None
        getitem_408 = native_batch_norm_default_136[0]
        getitem_409 = native_batch_norm_default_136[1]
        getitem_410 = native_batch_norm_default_136[2];  native_batch_norm_default_136 = None
        add__tensor_188 = torch.ops.aten.add_.Tensor(getitem_408, relu__default_110);  getitem_408 = None
        relu__default_112 = torch.ops.aten.relu_.default(add__tensor_188);  add__tensor_188 = None
        convolution_default_137 = torch.ops.aten.convolution.default(relu_default_11, primals_803, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_137 = torch.ops.aten.native_batch_norm.default(convolution_default_137, primals_797, primals_793, primals_795, primals_796, True, 0.1, 1e-05);  primals_793 = None
        getitem_411 = native_batch_norm_default_137[0]
        getitem_412 = native_batch_norm_default_137[1]
        getitem_413 = native_batch_norm_default_137[2];  native_batch_norm_default_137 = None
        relu__default_113 = torch.ops.aten.relu_.default(getitem_411);  getitem_411 = None
        convolution_default_138 = torch.ops.aten.convolution.default(relu__default_113, primals_804, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_138 = torch.ops.aten.native_batch_norm.default(convolution_default_138, primals_802, primals_798, primals_800, primals_801, True, 0.1, 1e-05);  primals_798 = None
        getitem_414 = native_batch_norm_default_138[0]
        getitem_415 = native_batch_norm_default_138[1]
        getitem_416 = native_batch_norm_default_138[2];  native_batch_norm_default_138 = None
        add__tensor_191 = torch.ops.aten.add_.Tensor(getitem_414, relu_default_11);  getitem_414 = None
        relu__default_114 = torch.ops.aten.relu_.default(add__tensor_191);  add__tensor_191 = None
        convolution_default_139 = torch.ops.aten.convolution.default(relu__default_114, primals_815, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_139 = torch.ops.aten.native_batch_norm.default(convolution_default_139, primals_809, primals_805, primals_807, primals_808, True, 0.1, 1e-05);  primals_805 = None
        getitem_417 = native_batch_norm_default_139[0]
        getitem_418 = native_batch_norm_default_139[1]
        getitem_419 = native_batch_norm_default_139[2];  native_batch_norm_default_139 = None
        relu__default_115 = torch.ops.aten.relu_.default(getitem_417);  getitem_417 = None
        convolution_default_140 = torch.ops.aten.convolution.default(relu__default_115, primals_816, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_140 = torch.ops.aten.native_batch_norm.default(convolution_default_140, primals_814, primals_810, primals_812, primals_813, True, 0.1, 1e-05);  primals_810 = None
        getitem_420 = native_batch_norm_default_140[0]
        getitem_421 = native_batch_norm_default_140[1]
        getitem_422 = native_batch_norm_default_140[2];  native_batch_norm_default_140 = None
        add__tensor_194 = torch.ops.aten.add_.Tensor(getitem_420, relu__default_114);  getitem_420 = None
        relu__default_116 = torch.ops.aten.relu_.default(add__tensor_194);  add__tensor_194 = None
        convolution_default_141 = torch.ops.aten.convolution.default(relu__default_116, primals_827, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_141 = torch.ops.aten.native_batch_norm.default(convolution_default_141, primals_821, primals_817, primals_819, primals_820, True, 0.1, 1e-05);  primals_817 = None
        getitem_423 = native_batch_norm_default_141[0]
        getitem_424 = native_batch_norm_default_141[1]
        getitem_425 = native_batch_norm_default_141[2];  native_batch_norm_default_141 = None
        relu__default_117 = torch.ops.aten.relu_.default(getitem_423);  getitem_423 = None
        convolution_default_142 = torch.ops.aten.convolution.default(relu__default_117, primals_828, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_142 = torch.ops.aten.native_batch_norm.default(convolution_default_142, primals_826, primals_822, primals_824, primals_825, True, 0.1, 1e-05);  primals_822 = None
        getitem_426 = native_batch_norm_default_142[0]
        getitem_427 = native_batch_norm_default_142[1]
        getitem_428 = native_batch_norm_default_142[2];  native_batch_norm_default_142 = None
        add__tensor_197 = torch.ops.aten.add_.Tensor(getitem_426, relu__default_116);  getitem_426 = None
        relu__default_118 = torch.ops.aten.relu_.default(add__tensor_197);  add__tensor_197 = None
        convolution_default_143 = torch.ops.aten.convolution.default(relu__default_118, primals_839, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_143 = torch.ops.aten.native_batch_norm.default(convolution_default_143, primals_833, primals_829, primals_831, primals_832, True, 0.1, 1e-05);  primals_829 = None
        getitem_429 = native_batch_norm_default_143[0]
        getitem_430 = native_batch_norm_default_143[1]
        getitem_431 = native_batch_norm_default_143[2];  native_batch_norm_default_143 = None
        relu__default_119 = torch.ops.aten.relu_.default(getitem_429);  getitem_429 = None
        convolution_default_144 = torch.ops.aten.convolution.default(relu__default_119, primals_840, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_144 = torch.ops.aten.native_batch_norm.default(convolution_default_144, primals_838, primals_834, primals_836, primals_837, True, 0.1, 1e-05);  primals_834 = None
        getitem_432 = native_batch_norm_default_144[0]
        getitem_433 = native_batch_norm_default_144[1]
        getitem_434 = native_batch_norm_default_144[2];  native_batch_norm_default_144 = None
        add__tensor_200 = torch.ops.aten.add_.Tensor(getitem_432, relu__default_118);  getitem_432 = None
        relu__default_120 = torch.ops.aten.relu_.default(add__tensor_200);  add__tensor_200 = None
        convolution_default_145 = torch.ops.aten.convolution.default(relu_default_13, primals_851, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_145 = torch.ops.aten.native_batch_norm.default(convolution_default_145, primals_845, primals_841, primals_843, primals_844, True, 0.1, 1e-05);  primals_841 = None
        getitem_435 = native_batch_norm_default_145[0]
        getitem_436 = native_batch_norm_default_145[1]
        getitem_437 = native_batch_norm_default_145[2];  native_batch_norm_default_145 = None
        relu__default_121 = torch.ops.aten.relu_.default(getitem_435);  getitem_435 = None
        convolution_default_146 = torch.ops.aten.convolution.default(relu__default_121, primals_852, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_146 = torch.ops.aten.native_batch_norm.default(convolution_default_146, primals_850, primals_846, primals_848, primals_849, True, 0.1, 1e-05);  primals_846 = None
        getitem_438 = native_batch_norm_default_146[0]
        getitem_439 = native_batch_norm_default_146[1]
        getitem_440 = native_batch_norm_default_146[2];  native_batch_norm_default_146 = None
        add__tensor_203 = torch.ops.aten.add_.Tensor(getitem_438, relu_default_13);  getitem_438 = None
        relu__default_122 = torch.ops.aten.relu_.default(add__tensor_203);  add__tensor_203 = None
        convolution_default_147 = torch.ops.aten.convolution.default(relu__default_122, primals_863, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_147 = torch.ops.aten.native_batch_norm.default(convolution_default_147, primals_857, primals_853, primals_855, primals_856, True, 0.1, 1e-05);  primals_853 = None
        getitem_441 = native_batch_norm_default_147[0]
        getitem_442 = native_batch_norm_default_147[1]
        getitem_443 = native_batch_norm_default_147[2];  native_batch_norm_default_147 = None
        relu__default_123 = torch.ops.aten.relu_.default(getitem_441);  getitem_441 = None
        convolution_default_148 = torch.ops.aten.convolution.default(relu__default_123, primals_864, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_148 = torch.ops.aten.native_batch_norm.default(convolution_default_148, primals_862, primals_858, primals_860, primals_861, True, 0.1, 1e-05);  primals_858 = None
        getitem_444 = native_batch_norm_default_148[0]
        getitem_445 = native_batch_norm_default_148[1]
        getitem_446 = native_batch_norm_default_148[2];  native_batch_norm_default_148 = None
        add__tensor_206 = torch.ops.aten.add_.Tensor(getitem_444, relu__default_122);  getitem_444 = None
        relu__default_124 = torch.ops.aten.relu_.default(add__tensor_206);  add__tensor_206 = None
        convolution_default_149 = torch.ops.aten.convolution.default(relu__default_124, primals_875, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_149 = torch.ops.aten.native_batch_norm.default(convolution_default_149, primals_869, primals_865, primals_867, primals_868, True, 0.1, 1e-05);  primals_865 = None
        getitem_447 = native_batch_norm_default_149[0]
        getitem_448 = native_batch_norm_default_149[1]
        getitem_449 = native_batch_norm_default_149[2];  native_batch_norm_default_149 = None
        relu__default_125 = torch.ops.aten.relu_.default(getitem_447);  getitem_447 = None
        convolution_default_150 = torch.ops.aten.convolution.default(relu__default_125, primals_876, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_150 = torch.ops.aten.native_batch_norm.default(convolution_default_150, primals_874, primals_870, primals_872, primals_873, True, 0.1, 1e-05);  primals_870 = None
        getitem_450 = native_batch_norm_default_150[0]
        getitem_451 = native_batch_norm_default_150[1]
        getitem_452 = native_batch_norm_default_150[2];  native_batch_norm_default_150 = None
        add__tensor_209 = torch.ops.aten.add_.Tensor(getitem_450, relu__default_124);  getitem_450 = None
        relu__default_126 = torch.ops.aten.relu_.default(add__tensor_209);  add__tensor_209 = None
        convolution_default_151 = torch.ops.aten.convolution.default(relu__default_126, primals_887, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_151 = torch.ops.aten.native_batch_norm.default(convolution_default_151, primals_881, primals_877, primals_879, primals_880, True, 0.1, 1e-05);  primals_877 = None
        getitem_453 = native_batch_norm_default_151[0]
        getitem_454 = native_batch_norm_default_151[1]
        getitem_455 = native_batch_norm_default_151[2];  native_batch_norm_default_151 = None
        relu__default_127 = torch.ops.aten.relu_.default(getitem_453);  getitem_453 = None
        convolution_default_152 = torch.ops.aten.convolution.default(relu__default_127, primals_888, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_152 = torch.ops.aten.native_batch_norm.default(convolution_default_152, primals_886, primals_882, primals_884, primals_885, True, 0.1, 1e-05);  primals_882 = None
        getitem_456 = native_batch_norm_default_152[0]
        getitem_457 = native_batch_norm_default_152[1]
        getitem_458 = native_batch_norm_default_152[2];  native_batch_norm_default_152 = None
        add__tensor_212 = torch.ops.aten.add_.Tensor(getitem_456, relu__default_126);  getitem_456 = None
        relu__default_128 = torch.ops.aten.relu_.default(add__tensor_212);  add__tensor_212 = None
        convolution_default_153 = torch.ops.aten.convolution.default(relu__default_120, primals_1795, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_153 = torch.ops.aten.native_batch_norm.default(convolution_default_153, primals_1800, primals_1796, primals_1798, primals_1799, True, 0.1, 1e-05);  primals_1796 = None
        getitem_459 = native_batch_norm_default_153[0]
        getitem_460 = native_batch_norm_default_153[1]
        getitem_461 = native_batch_norm_default_153[2];  native_batch_norm_default_153 = None
        upsample_nearest2d_vec_10 = torch.ops.aten.upsample_nearest2d.vec(getitem_459, None, [2.0, 2.0]);  getitem_459 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(relu__default_112, upsample_nearest2d_vec_10);  upsample_nearest2d_vec_10 = None
        convolution_default_154 = torch.ops.aten.convolution.default(relu__default_128, primals_1891, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_154 = torch.ops.aten.native_batch_norm.default(convolution_default_154, primals_1896, primals_1892, primals_1894, primals_1895, True, 0.1, 1e-05);  primals_1892 = None
        getitem_462 = native_batch_norm_default_154[0]
        getitem_463 = native_batch_norm_default_154[1]
        getitem_464 = native_batch_norm_default_154[2];  native_batch_norm_default_154 = None
        upsample_nearest2d_vec_11 = torch.ops.aten.upsample_nearest2d.vec(getitem_462, None, [4.0, 4.0]);  getitem_462 = None
        add_tensor_21 = torch.ops.aten.add.Tensor(add_tensor_20, upsample_nearest2d_vec_11);  add_tensor_20 = upsample_nearest2d_vec_11 = None
        relu_default_14 = torch.ops.aten.relu.default(add_tensor_21);  add_tensor_21 = None
        convolution_default_155 = torch.ops.aten.convolution.default(relu__default_112, primals_1651, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_155 = torch.ops.aten.native_batch_norm.default(convolution_default_155, primals_1656, primals_1652, primals_1654, primals_1655, True, 0.1, 1e-05);  primals_1652 = None
        getitem_465 = native_batch_norm_default_155[0]
        getitem_466 = native_batch_norm_default_155[1]
        getitem_467 = native_batch_norm_default_155[2];  native_batch_norm_default_155 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(getitem_465, relu__default_120);  getitem_465 = None
        convolution_default_156 = torch.ops.aten.convolution.default(relu__default_128, primals_1897, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_156 = torch.ops.aten.native_batch_norm.default(convolution_default_156, primals_1902, primals_1898, primals_1900, primals_1901, True, 0.1, 1e-05);  primals_1898 = None
        getitem_468 = native_batch_norm_default_156[0]
        getitem_469 = native_batch_norm_default_156[1]
        getitem_470 = native_batch_norm_default_156[2];  native_batch_norm_default_156 = None
        upsample_nearest2d_vec_12 = torch.ops.aten.upsample_nearest2d.vec(getitem_468, None, [2.0, 2.0]);  getitem_468 = None
        add_tensor_23 = torch.ops.aten.add.Tensor(add_tensor_22, upsample_nearest2d_vec_12);  add_tensor_22 = upsample_nearest2d_vec_12 = None
        relu_default_15 = torch.ops.aten.relu.default(add_tensor_23);  add_tensor_23 = None
        convolution_default_157 = torch.ops.aten.convolution.default(relu__default_112, primals_1657, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_157 = torch.ops.aten.native_batch_norm.default(convolution_default_157, primals_1662, primals_1658, primals_1660, primals_1661, True, 0.1, 1e-05);  primals_1658 = None
        getitem_471 = native_batch_norm_default_157[0]
        getitem_472 = native_batch_norm_default_157[1]
        getitem_473 = native_batch_norm_default_157[2];  native_batch_norm_default_157 = None
        relu_default_16 = torch.ops.aten.relu.default(getitem_471);  getitem_471 = None
        convolution_default_158 = torch.ops.aten.convolution.default(relu_default_16, primals_1663, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_158 = torch.ops.aten.native_batch_norm.default(convolution_default_158, primals_1668, primals_1664, primals_1666, primals_1667, True, 0.1, 1e-05);  primals_1664 = None
        getitem_474 = native_batch_norm_default_158[0]
        getitem_475 = native_batch_norm_default_158[1]
        getitem_476 = native_batch_norm_default_158[2];  native_batch_norm_default_158 = None
        convolution_default_159 = torch.ops.aten.convolution.default(relu__default_120, primals_1681, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_159 = torch.ops.aten.native_batch_norm.default(convolution_default_159, primals_1686, primals_1682, primals_1684, primals_1685, True, 0.1, 1e-05);  primals_1682 = None
        getitem_477 = native_batch_norm_default_159[0]
        getitem_478 = native_batch_norm_default_159[1]
        getitem_479 = native_batch_norm_default_159[2];  native_batch_norm_default_159 = None
        add_tensor_24 = torch.ops.aten.add.Tensor(getitem_474, getitem_477);  getitem_474 = getitem_477 = None
        add_tensor_25 = torch.ops.aten.add.Tensor(add_tensor_24, relu__default_128);  add_tensor_24 = None
        relu_default_17 = torch.ops.aten.relu.default(add_tensor_25);  add_tensor_25 = None
        convolution_default_160 = torch.ops.aten.convolution.default(relu_default_17, primals_1483, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_160 = torch.ops.aten.native_batch_norm.default(convolution_default_160, primals_1488, primals_1484, primals_1486, primals_1487, True, 0.1, 1e-05);  primals_1484 = None
        getitem_480 = native_batch_norm_default_160[0]
        getitem_481 = native_batch_norm_default_160[1]
        getitem_482 = native_batch_norm_default_160[2];  native_batch_norm_default_160 = None
        relu__default_129 = torch.ops.aten.relu_.default(getitem_480);  getitem_480 = None
        convolution_default_161 = torch.ops.aten.convolution.default(relu_default_14, primals_899, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_161 = torch.ops.aten.native_batch_norm.default(convolution_default_161, primals_893, primals_889, primals_891, primals_892, True, 0.1, 1e-05);  primals_889 = None
        getitem_483 = native_batch_norm_default_161[0]
        getitem_484 = native_batch_norm_default_161[1]
        getitem_485 = native_batch_norm_default_161[2];  native_batch_norm_default_161 = None
        relu__default_130 = torch.ops.aten.relu_.default(getitem_483);  getitem_483 = None
        convolution_default_162 = torch.ops.aten.convolution.default(relu__default_130, primals_900, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_162 = torch.ops.aten.native_batch_norm.default(convolution_default_162, primals_898, primals_894, primals_896, primals_897, True, 0.1, 1e-05);  primals_894 = None
        getitem_486 = native_batch_norm_default_162[0]
        getitem_487 = native_batch_norm_default_162[1]
        getitem_488 = native_batch_norm_default_162[2];  native_batch_norm_default_162 = None
        add__tensor_223 = torch.ops.aten.add_.Tensor(getitem_486, relu_default_14);  getitem_486 = None
        relu__default_131 = torch.ops.aten.relu_.default(add__tensor_223);  add__tensor_223 = None
        convolution_default_163 = torch.ops.aten.convolution.default(relu__default_131, primals_911, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_163 = torch.ops.aten.native_batch_norm.default(convolution_default_163, primals_905, primals_901, primals_903, primals_904, True, 0.1, 1e-05);  primals_901 = None
        getitem_489 = native_batch_norm_default_163[0]
        getitem_490 = native_batch_norm_default_163[1]
        getitem_491 = native_batch_norm_default_163[2];  native_batch_norm_default_163 = None
        relu__default_132 = torch.ops.aten.relu_.default(getitem_489);  getitem_489 = None
        convolution_default_164 = torch.ops.aten.convolution.default(relu__default_132, primals_912, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_164 = torch.ops.aten.native_batch_norm.default(convolution_default_164, primals_910, primals_906, primals_908, primals_909, True, 0.1, 1e-05);  primals_906 = None
        getitem_492 = native_batch_norm_default_164[0]
        getitem_493 = native_batch_norm_default_164[1]
        getitem_494 = native_batch_norm_default_164[2];  native_batch_norm_default_164 = None
        add__tensor_226 = torch.ops.aten.add_.Tensor(getitem_492, relu__default_131);  getitem_492 = None
        relu__default_133 = torch.ops.aten.relu_.default(add__tensor_226);  add__tensor_226 = None
        convolution_default_165 = torch.ops.aten.convolution.default(relu__default_133, primals_923, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_165 = torch.ops.aten.native_batch_norm.default(convolution_default_165, primals_917, primals_913, primals_915, primals_916, True, 0.1, 1e-05);  primals_913 = None
        getitem_495 = native_batch_norm_default_165[0]
        getitem_496 = native_batch_norm_default_165[1]
        getitem_497 = native_batch_norm_default_165[2];  native_batch_norm_default_165 = None
        relu__default_134 = torch.ops.aten.relu_.default(getitem_495);  getitem_495 = None
        convolution_default_166 = torch.ops.aten.convolution.default(relu__default_134, primals_924, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_166 = torch.ops.aten.native_batch_norm.default(convolution_default_166, primals_922, primals_918, primals_920, primals_921, True, 0.1, 1e-05);  primals_918 = None
        getitem_498 = native_batch_norm_default_166[0]
        getitem_499 = native_batch_norm_default_166[1]
        getitem_500 = native_batch_norm_default_166[2];  native_batch_norm_default_166 = None
        add__tensor_229 = torch.ops.aten.add_.Tensor(getitem_498, relu__default_133);  getitem_498 = None
        relu__default_135 = torch.ops.aten.relu_.default(add__tensor_229);  add__tensor_229 = None
        convolution_default_167 = torch.ops.aten.convolution.default(relu__default_135, primals_935, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_167 = torch.ops.aten.native_batch_norm.default(convolution_default_167, primals_929, primals_925, primals_927, primals_928, True, 0.1, 1e-05);  primals_925 = None
        getitem_501 = native_batch_norm_default_167[0]
        getitem_502 = native_batch_norm_default_167[1]
        getitem_503 = native_batch_norm_default_167[2];  native_batch_norm_default_167 = None
        relu__default_136 = torch.ops.aten.relu_.default(getitem_501);  getitem_501 = None
        convolution_default_168 = torch.ops.aten.convolution.default(relu__default_136, primals_936, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_168 = torch.ops.aten.native_batch_norm.default(convolution_default_168, primals_934, primals_930, primals_932, primals_933, True, 0.1, 1e-05);  primals_930 = None
        getitem_504 = native_batch_norm_default_168[0]
        getitem_505 = native_batch_norm_default_168[1]
        getitem_506 = native_batch_norm_default_168[2];  native_batch_norm_default_168 = None
        add__tensor_232 = torch.ops.aten.add_.Tensor(getitem_504, relu__default_135);  getitem_504 = None
        relu__default_137 = torch.ops.aten.relu_.default(add__tensor_232);  add__tensor_232 = None
        convolution_default_169 = torch.ops.aten.convolution.default(relu_default_15, primals_947, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_169 = torch.ops.aten.native_batch_norm.default(convolution_default_169, primals_941, primals_937, primals_939, primals_940, True, 0.1, 1e-05);  primals_937 = None
        getitem_507 = native_batch_norm_default_169[0]
        getitem_508 = native_batch_norm_default_169[1]
        getitem_509 = native_batch_norm_default_169[2];  native_batch_norm_default_169 = None
        relu__default_138 = torch.ops.aten.relu_.default(getitem_507);  getitem_507 = None
        convolution_default_170 = torch.ops.aten.convolution.default(relu__default_138, primals_948, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_170 = torch.ops.aten.native_batch_norm.default(convolution_default_170, primals_946, primals_942, primals_944, primals_945, True, 0.1, 1e-05);  primals_942 = None
        getitem_510 = native_batch_norm_default_170[0]
        getitem_511 = native_batch_norm_default_170[1]
        getitem_512 = native_batch_norm_default_170[2];  native_batch_norm_default_170 = None
        add__tensor_235 = torch.ops.aten.add_.Tensor(getitem_510, relu_default_15);  getitem_510 = None
        relu__default_139 = torch.ops.aten.relu_.default(add__tensor_235);  add__tensor_235 = None
        convolution_default_171 = torch.ops.aten.convolution.default(relu__default_139, primals_959, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_171 = torch.ops.aten.native_batch_norm.default(convolution_default_171, primals_953, primals_949, primals_951, primals_952, True, 0.1, 1e-05);  primals_949 = None
        getitem_513 = native_batch_norm_default_171[0]
        getitem_514 = native_batch_norm_default_171[1]
        getitem_515 = native_batch_norm_default_171[2];  native_batch_norm_default_171 = None
        relu__default_140 = torch.ops.aten.relu_.default(getitem_513);  getitem_513 = None
        convolution_default_172 = torch.ops.aten.convolution.default(relu__default_140, primals_960, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_172 = torch.ops.aten.native_batch_norm.default(convolution_default_172, primals_958, primals_954, primals_956, primals_957, True, 0.1, 1e-05);  primals_954 = None
        getitem_516 = native_batch_norm_default_172[0]
        getitem_517 = native_batch_norm_default_172[1]
        getitem_518 = native_batch_norm_default_172[2];  native_batch_norm_default_172 = None
        add__tensor_238 = torch.ops.aten.add_.Tensor(getitem_516, relu__default_139);  getitem_516 = None
        relu__default_141 = torch.ops.aten.relu_.default(add__tensor_238);  add__tensor_238 = None
        convolution_default_173 = torch.ops.aten.convolution.default(relu__default_141, primals_971, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_173 = torch.ops.aten.native_batch_norm.default(convolution_default_173, primals_965, primals_961, primals_963, primals_964, True, 0.1, 1e-05);  primals_961 = None
        getitem_519 = native_batch_norm_default_173[0]
        getitem_520 = native_batch_norm_default_173[1]
        getitem_521 = native_batch_norm_default_173[2];  native_batch_norm_default_173 = None
        relu__default_142 = torch.ops.aten.relu_.default(getitem_519);  getitem_519 = None
        convolution_default_174 = torch.ops.aten.convolution.default(relu__default_142, primals_972, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_174 = torch.ops.aten.native_batch_norm.default(convolution_default_174, primals_970, primals_966, primals_968, primals_969, True, 0.1, 1e-05);  primals_966 = None
        getitem_522 = native_batch_norm_default_174[0]
        getitem_523 = native_batch_norm_default_174[1]
        getitem_524 = native_batch_norm_default_174[2];  native_batch_norm_default_174 = None
        add__tensor_241 = torch.ops.aten.add_.Tensor(getitem_522, relu__default_141);  getitem_522 = None
        relu__default_143 = torch.ops.aten.relu_.default(add__tensor_241);  add__tensor_241 = None
        convolution_default_175 = torch.ops.aten.convolution.default(relu__default_143, primals_983, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_175 = torch.ops.aten.native_batch_norm.default(convolution_default_175, primals_977, primals_973, primals_975, primals_976, True, 0.1, 1e-05);  primals_973 = None
        getitem_525 = native_batch_norm_default_175[0]
        getitem_526 = native_batch_norm_default_175[1]
        getitem_527 = native_batch_norm_default_175[2];  native_batch_norm_default_175 = None
        relu__default_144 = torch.ops.aten.relu_.default(getitem_525);  getitem_525 = None
        convolution_default_176 = torch.ops.aten.convolution.default(relu__default_144, primals_984, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_176 = torch.ops.aten.native_batch_norm.default(convolution_default_176, primals_982, primals_978, primals_980, primals_981, True, 0.1, 1e-05);  primals_978 = None
        getitem_528 = native_batch_norm_default_176[0]
        getitem_529 = native_batch_norm_default_176[1]
        getitem_530 = native_batch_norm_default_176[2];  native_batch_norm_default_176 = None
        add__tensor_244 = torch.ops.aten.add_.Tensor(getitem_528, relu__default_143);  getitem_528 = None
        relu__default_145 = torch.ops.aten.relu_.default(add__tensor_244);  add__tensor_244 = None
        convolution_default_177 = torch.ops.aten.convolution.default(relu_default_17, primals_995, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_177 = torch.ops.aten.native_batch_norm.default(convolution_default_177, primals_989, primals_985, primals_987, primals_988, True, 0.1, 1e-05);  primals_985 = None
        getitem_531 = native_batch_norm_default_177[0]
        getitem_532 = native_batch_norm_default_177[1]
        getitem_533 = native_batch_norm_default_177[2];  native_batch_norm_default_177 = None
        relu__default_146 = torch.ops.aten.relu_.default(getitem_531);  getitem_531 = None
        convolution_default_178 = torch.ops.aten.convolution.default(relu__default_146, primals_996, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_178 = torch.ops.aten.native_batch_norm.default(convolution_default_178, primals_994, primals_990, primals_992, primals_993, True, 0.1, 1e-05);  primals_990 = None
        getitem_534 = native_batch_norm_default_178[0]
        getitem_535 = native_batch_norm_default_178[1]
        getitem_536 = native_batch_norm_default_178[2];  native_batch_norm_default_178 = None
        add__tensor_247 = torch.ops.aten.add_.Tensor(getitem_534, relu_default_17);  getitem_534 = None
        relu__default_147 = torch.ops.aten.relu_.default(add__tensor_247);  add__tensor_247 = None
        convolution_default_179 = torch.ops.aten.convolution.default(relu__default_147, primals_1007, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_179 = torch.ops.aten.native_batch_norm.default(convolution_default_179, primals_1001, primals_997, primals_999, primals_1000, True, 0.1, 1e-05);  primals_997 = None
        getitem_537 = native_batch_norm_default_179[0]
        getitem_538 = native_batch_norm_default_179[1]
        getitem_539 = native_batch_norm_default_179[2];  native_batch_norm_default_179 = None
        relu__default_148 = torch.ops.aten.relu_.default(getitem_537);  getitem_537 = None
        convolution_default_180 = torch.ops.aten.convolution.default(relu__default_148, primals_1008, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_180 = torch.ops.aten.native_batch_norm.default(convolution_default_180, primals_1006, primals_1002, primals_1004, primals_1005, True, 0.1, 1e-05);  primals_1002 = None
        getitem_540 = native_batch_norm_default_180[0]
        getitem_541 = native_batch_norm_default_180[1]
        getitem_542 = native_batch_norm_default_180[2];  native_batch_norm_default_180 = None
        add__tensor_250 = torch.ops.aten.add_.Tensor(getitem_540, relu__default_147);  getitem_540 = None
        relu__default_149 = torch.ops.aten.relu_.default(add__tensor_250);  add__tensor_250 = None
        convolution_default_181 = torch.ops.aten.convolution.default(relu__default_149, primals_1019, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_181 = torch.ops.aten.native_batch_norm.default(convolution_default_181, primals_1013, primals_1009, primals_1011, primals_1012, True, 0.1, 1e-05);  primals_1009 = None
        getitem_543 = native_batch_norm_default_181[0]
        getitem_544 = native_batch_norm_default_181[1]
        getitem_545 = native_batch_norm_default_181[2];  native_batch_norm_default_181 = None
        relu__default_150 = torch.ops.aten.relu_.default(getitem_543);  getitem_543 = None
        convolution_default_182 = torch.ops.aten.convolution.default(relu__default_150, primals_1020, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_182 = torch.ops.aten.native_batch_norm.default(convolution_default_182, primals_1018, primals_1014, primals_1016, primals_1017, True, 0.1, 1e-05);  primals_1014 = None
        getitem_546 = native_batch_norm_default_182[0]
        getitem_547 = native_batch_norm_default_182[1]
        getitem_548 = native_batch_norm_default_182[2];  native_batch_norm_default_182 = None
        add__tensor_253 = torch.ops.aten.add_.Tensor(getitem_546, relu__default_149);  getitem_546 = None
        relu__default_151 = torch.ops.aten.relu_.default(add__tensor_253);  add__tensor_253 = None
        convolution_default_183 = torch.ops.aten.convolution.default(relu__default_151, primals_1031, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_183 = torch.ops.aten.native_batch_norm.default(convolution_default_183, primals_1025, primals_1021, primals_1023, primals_1024, True, 0.1, 1e-05);  primals_1021 = None
        getitem_549 = native_batch_norm_default_183[0]
        getitem_550 = native_batch_norm_default_183[1]
        getitem_551 = native_batch_norm_default_183[2];  native_batch_norm_default_183 = None
        relu__default_152 = torch.ops.aten.relu_.default(getitem_549);  getitem_549 = None
        convolution_default_184 = torch.ops.aten.convolution.default(relu__default_152, primals_1032, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_184 = torch.ops.aten.native_batch_norm.default(convolution_default_184, primals_1030, primals_1026, primals_1028, primals_1029, True, 0.1, 1e-05);  primals_1026 = None
        getitem_552 = native_batch_norm_default_184[0]
        getitem_553 = native_batch_norm_default_184[1]
        getitem_554 = native_batch_norm_default_184[2];  native_batch_norm_default_184 = None
        add__tensor_256 = torch.ops.aten.add_.Tensor(getitem_552, relu__default_151);  getitem_552 = None
        relu__default_153 = torch.ops.aten.relu_.default(add__tensor_256);  add__tensor_256 = None
        convolution_default_185 = torch.ops.aten.convolution.default(relu__default_129, primals_1043, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_185 = torch.ops.aten.native_batch_norm.default(convolution_default_185, primals_1037, primals_1033, primals_1035, primals_1036, True, 0.1, 1e-05);  primals_1033 = None
        getitem_555 = native_batch_norm_default_185[0]
        getitem_556 = native_batch_norm_default_185[1]
        getitem_557 = native_batch_norm_default_185[2];  native_batch_norm_default_185 = None
        relu__default_154 = torch.ops.aten.relu_.default(getitem_555);  getitem_555 = None
        convolution_default_186 = torch.ops.aten.convolution.default(relu__default_154, primals_1044, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_186 = torch.ops.aten.native_batch_norm.default(convolution_default_186, primals_1042, primals_1038, primals_1040, primals_1041, True, 0.1, 1e-05);  primals_1038 = None
        getitem_558 = native_batch_norm_default_186[0]
        getitem_559 = native_batch_norm_default_186[1]
        getitem_560 = native_batch_norm_default_186[2];  native_batch_norm_default_186 = None
        add__tensor_259 = torch.ops.aten.add_.Tensor(getitem_558, relu__default_129);  getitem_558 = None
        relu__default_155 = torch.ops.aten.relu_.default(add__tensor_259);  add__tensor_259 = None
        convolution_default_187 = torch.ops.aten.convolution.default(relu__default_155, primals_1055, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_187 = torch.ops.aten.native_batch_norm.default(convolution_default_187, primals_1049, primals_1045, primals_1047, primals_1048, True, 0.1, 1e-05);  primals_1045 = None
        getitem_561 = native_batch_norm_default_187[0]
        getitem_562 = native_batch_norm_default_187[1]
        getitem_563 = native_batch_norm_default_187[2];  native_batch_norm_default_187 = None
        relu__default_156 = torch.ops.aten.relu_.default(getitem_561);  getitem_561 = None
        convolution_default_188 = torch.ops.aten.convolution.default(relu__default_156, primals_1056, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_188 = torch.ops.aten.native_batch_norm.default(convolution_default_188, primals_1054, primals_1050, primals_1052, primals_1053, True, 0.1, 1e-05);  primals_1050 = None
        getitem_564 = native_batch_norm_default_188[0]
        getitem_565 = native_batch_norm_default_188[1]
        getitem_566 = native_batch_norm_default_188[2];  native_batch_norm_default_188 = None
        add__tensor_262 = torch.ops.aten.add_.Tensor(getitem_564, relu__default_155);  getitem_564 = None
        relu__default_157 = torch.ops.aten.relu_.default(add__tensor_262);  add__tensor_262 = None
        convolution_default_189 = torch.ops.aten.convolution.default(relu__default_157, primals_1067, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_189 = torch.ops.aten.native_batch_norm.default(convolution_default_189, primals_1061, primals_1057, primals_1059, primals_1060, True, 0.1, 1e-05);  primals_1057 = None
        getitem_567 = native_batch_norm_default_189[0]
        getitem_568 = native_batch_norm_default_189[1]
        getitem_569 = native_batch_norm_default_189[2];  native_batch_norm_default_189 = None
        relu__default_158 = torch.ops.aten.relu_.default(getitem_567);  getitem_567 = None
        convolution_default_190 = torch.ops.aten.convolution.default(relu__default_158, primals_1068, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_190 = torch.ops.aten.native_batch_norm.default(convolution_default_190, primals_1066, primals_1062, primals_1064, primals_1065, True, 0.1, 1e-05);  primals_1062 = None
        getitem_570 = native_batch_norm_default_190[0]
        getitem_571 = native_batch_norm_default_190[1]
        getitem_572 = native_batch_norm_default_190[2];  native_batch_norm_default_190 = None
        add__tensor_265 = torch.ops.aten.add_.Tensor(getitem_570, relu__default_157);  getitem_570 = None
        relu__default_159 = torch.ops.aten.relu_.default(add__tensor_265);  add__tensor_265 = None
        convolution_default_191 = torch.ops.aten.convolution.default(relu__default_159, primals_1079, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_191 = torch.ops.aten.native_batch_norm.default(convolution_default_191, primals_1073, primals_1069, primals_1071, primals_1072, True, 0.1, 1e-05);  primals_1069 = None
        getitem_573 = native_batch_norm_default_191[0]
        getitem_574 = native_batch_norm_default_191[1]
        getitem_575 = native_batch_norm_default_191[2];  native_batch_norm_default_191 = None
        relu__default_160 = torch.ops.aten.relu_.default(getitem_573);  getitem_573 = None
        convolution_default_192 = torch.ops.aten.convolution.default(relu__default_160, primals_1080, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_192 = torch.ops.aten.native_batch_norm.default(convolution_default_192, primals_1078, primals_1074, primals_1076, primals_1077, True, 0.1, 1e-05);  primals_1074 = None
        getitem_576 = native_batch_norm_default_192[0]
        getitem_577 = native_batch_norm_default_192[1]
        getitem_578 = native_batch_norm_default_192[2];  native_batch_norm_default_192 = None
        add__tensor_268 = torch.ops.aten.add_.Tensor(getitem_576, relu__default_159);  getitem_576 = None
        relu__default_161 = torch.ops.aten.relu_.default(add__tensor_268);  add__tensor_268 = None
        convolution_default_193 = torch.ops.aten.convolution.default(relu__default_145, primals_1687, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_193 = torch.ops.aten.native_batch_norm.default(convolution_default_193, primals_1692, primals_1688, primals_1690, primals_1691, True, 0.1, 1e-05);  primals_1688 = None
        getitem_579 = native_batch_norm_default_193[0]
        getitem_580 = native_batch_norm_default_193[1]
        getitem_581 = native_batch_norm_default_193[2];  native_batch_norm_default_193 = None
        upsample_nearest2d_vec_13 = torch.ops.aten.upsample_nearest2d.vec(getitem_579, None, [2.0, 2.0]);  getitem_579 = None
        add_tensor_26 = torch.ops.aten.add.Tensor(relu__default_137, upsample_nearest2d_vec_13);  upsample_nearest2d_vec_13 = None
        convolution_default_194 = torch.ops.aten.convolution.default(relu__default_153, primals_1807, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_194 = torch.ops.aten.native_batch_norm.default(convolution_default_194, primals_1812, primals_1808, primals_1810, primals_1811, True, 0.1, 1e-05);  primals_1808 = None
        getitem_582 = native_batch_norm_default_194[0]
        getitem_583 = native_batch_norm_default_194[1]
        getitem_584 = native_batch_norm_default_194[2];  native_batch_norm_default_194 = None
        upsample_nearest2d_vec_14 = torch.ops.aten.upsample_nearest2d.vec(getitem_582, None, [4.0, 4.0]);  getitem_582 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(add_tensor_26, upsample_nearest2d_vec_14);  add_tensor_26 = upsample_nearest2d_vec_14 = None
        convolution_default_195 = torch.ops.aten.convolution.default(relu__default_161, primals_1903, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_195 = torch.ops.aten.native_batch_norm.default(convolution_default_195, primals_1908, primals_1904, primals_1906, primals_1907, True, 0.1, 1e-05);  primals_1904 = None
        getitem_585 = native_batch_norm_default_195[0]
        getitem_586 = native_batch_norm_default_195[1]
        getitem_587 = native_batch_norm_default_195[2];  native_batch_norm_default_195 = None
        upsample_nearest2d_vec_15 = torch.ops.aten.upsample_nearest2d.vec(getitem_585, None, [8.0, 8.0]);  getitem_585 = None
        add_tensor_28 = torch.ops.aten.add.Tensor(add_tensor_27, upsample_nearest2d_vec_15);  add_tensor_27 = upsample_nearest2d_vec_15 = None
        relu_default_18 = torch.ops.aten.relu.default(add_tensor_28);  add_tensor_28 = None
        convolution_default_196 = torch.ops.aten.convolution.default(relu__default_137, primals_1669, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_196 = torch.ops.aten.native_batch_norm.default(convolution_default_196, primals_1674, primals_1670, primals_1672, primals_1673, True, 0.1, 1e-05);  primals_1670 = None
        getitem_588 = native_batch_norm_default_196[0]
        getitem_589 = native_batch_norm_default_196[1]
        getitem_590 = native_batch_norm_default_196[2];  native_batch_norm_default_196 = None
        add_tensor_29 = torch.ops.aten.add.Tensor(getitem_588, relu__default_145);  getitem_588 = None
        convolution_default_197 = torch.ops.aten.convolution.default(relu__default_153, primals_1813, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_197 = torch.ops.aten.native_batch_norm.default(convolution_default_197, primals_1818, primals_1814, primals_1816, primals_1817, True, 0.1, 1e-05);  primals_1814 = None
        getitem_591 = native_batch_norm_default_197[0]
        getitem_592 = native_batch_norm_default_197[1]
        getitem_593 = native_batch_norm_default_197[2];  native_batch_norm_default_197 = None
        upsample_nearest2d_vec_16 = torch.ops.aten.upsample_nearest2d.vec(getitem_591, None, [2.0, 2.0]);  getitem_591 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(add_tensor_29, upsample_nearest2d_vec_16);  add_tensor_29 = upsample_nearest2d_vec_16 = None
        convolution_default_198 = torch.ops.aten.convolution.default(relu__default_161, primals_1915, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_198 = torch.ops.aten.native_batch_norm.default(convolution_default_198, primals_1920, primals_1916, primals_1918, primals_1919, True, 0.1, 1e-05);  primals_1916 = None
        getitem_594 = native_batch_norm_default_198[0]
        getitem_595 = native_batch_norm_default_198[1]
        getitem_596 = native_batch_norm_default_198[2];  native_batch_norm_default_198 = None
        upsample_nearest2d_vec_17 = torch.ops.aten.upsample_nearest2d.vec(getitem_594, None, [4.0, 4.0]);  getitem_594 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(add_tensor_30, upsample_nearest2d_vec_17);  add_tensor_30 = upsample_nearest2d_vec_17 = None
        relu_default_19 = torch.ops.aten.relu.default(add_tensor_31);  add_tensor_31 = None
        convolution_default_199 = torch.ops.aten.convolution.default(relu__default_137, primals_1495, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_199 = torch.ops.aten.native_batch_norm.default(convolution_default_199, primals_1500, primals_1496, primals_1498, primals_1499, True, 0.1, 1e-05);  primals_1496 = None
        getitem_597 = native_batch_norm_default_199[0]
        getitem_598 = native_batch_norm_default_199[1]
        getitem_599 = native_batch_norm_default_199[2];  native_batch_norm_default_199 = None
        relu_default_20 = torch.ops.aten.relu.default(getitem_597);  getitem_597 = None
        convolution_default_200 = torch.ops.aten.convolution.default(relu_default_20, primals_1501, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_200 = torch.ops.aten.native_batch_norm.default(convolution_default_200, primals_1506, primals_1502, primals_1504, primals_1505, True, 0.1, 1e-05);  primals_1502 = None
        getitem_600 = native_batch_norm_default_200[0]
        getitem_601 = native_batch_norm_default_200[1]
        getitem_602 = native_batch_norm_default_200[2];  native_batch_norm_default_200 = None
        convolution_default_201 = torch.ops.aten.convolution.default(relu__default_145, primals_1693, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_201 = torch.ops.aten.native_batch_norm.default(convolution_default_201, primals_1698, primals_1694, primals_1696, primals_1697, True, 0.1, 1e-05);  primals_1694 = None
        getitem_603 = native_batch_norm_default_201[0]
        getitem_604 = native_batch_norm_default_201[1]
        getitem_605 = native_batch_norm_default_201[2];  native_batch_norm_default_201 = None
        add_tensor_32 = torch.ops.aten.add.Tensor(getitem_600, getitem_603);  getitem_600 = getitem_603 = None
        add_tensor_33 = torch.ops.aten.add.Tensor(add_tensor_32, relu__default_153);  add_tensor_32 = None
        convolution_default_202 = torch.ops.aten.convolution.default(relu__default_161, primals_1921, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_202 = torch.ops.aten.native_batch_norm.default(convolution_default_202, primals_1926, primals_1922, primals_1924, primals_1925, True, 0.1, 1e-05);  primals_1922 = None
        getitem_606 = native_batch_norm_default_202[0]
        getitem_607 = native_batch_norm_default_202[1]
        getitem_608 = native_batch_norm_default_202[2];  native_batch_norm_default_202 = None
        upsample_nearest2d_vec_18 = torch.ops.aten.upsample_nearest2d.vec(getitem_606, None, [2.0, 2.0]);  getitem_606 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(add_tensor_33, upsample_nearest2d_vec_18);  add_tensor_33 = upsample_nearest2d_vec_18 = None
        relu_default_21 = torch.ops.aten.relu.default(add_tensor_34);  add_tensor_34 = None
        convolution_default_203 = torch.ops.aten.convolution.default(relu__default_137, primals_1507, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_203 = torch.ops.aten.native_batch_norm.default(convolution_default_203, primals_1512, primals_1508, primals_1510, primals_1511, True, 0.1, 1e-05);  primals_1508 = None
        getitem_609 = native_batch_norm_default_203[0]
        getitem_610 = native_batch_norm_default_203[1]
        getitem_611 = native_batch_norm_default_203[2];  native_batch_norm_default_203 = None
        relu_default_22 = torch.ops.aten.relu.default(getitem_609);  getitem_609 = None
        convolution_default_204 = torch.ops.aten.convolution.default(relu_default_22, primals_1513, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_204 = torch.ops.aten.native_batch_norm.default(convolution_default_204, primals_1518, primals_1514, primals_1516, primals_1517, True, 0.1, 1e-05);  primals_1514 = None
        getitem_612 = native_batch_norm_default_204[0]
        getitem_613 = native_batch_norm_default_204[1]
        getitem_614 = native_batch_norm_default_204[2];  native_batch_norm_default_204 = None
        relu_default_23 = torch.ops.aten.relu.default(getitem_612);  getitem_612 = None
        convolution_default_205 = torch.ops.aten.convolution.default(relu_default_23, primals_1519, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_205 = torch.ops.aten.native_batch_norm.default(convolution_default_205, primals_1524, primals_1520, primals_1522, primals_1523, True, 0.1, 1e-05);  primals_1520 = None
        getitem_615 = native_batch_norm_default_205[0]
        getitem_616 = native_batch_norm_default_205[1]
        getitem_617 = native_batch_norm_default_205[2];  native_batch_norm_default_205 = None
        convolution_default_206 = torch.ops.aten.convolution.default(relu__default_145, primals_1699, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_206 = torch.ops.aten.native_batch_norm.default(convolution_default_206, primals_1704, primals_1700, primals_1702, primals_1703, True, 0.1, 1e-05);  primals_1700 = None
        getitem_618 = native_batch_norm_default_206[0]
        getitem_619 = native_batch_norm_default_206[1]
        getitem_620 = native_batch_norm_default_206[2];  native_batch_norm_default_206 = None
        relu_default_24 = torch.ops.aten.relu.default(getitem_618);  getitem_618 = None
        convolution_default_207 = torch.ops.aten.convolution.default(relu_default_24, primals_1705, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_207 = torch.ops.aten.native_batch_norm.default(convolution_default_207, primals_1710, primals_1706, primals_1708, primals_1709, True, 0.1, 1e-05);  primals_1706 = None
        getitem_621 = native_batch_norm_default_207[0]
        getitem_622 = native_batch_norm_default_207[1]
        getitem_623 = native_batch_norm_default_207[2];  native_batch_norm_default_207 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(getitem_615, getitem_621);  getitem_615 = getitem_621 = None
        convolution_default_208 = torch.ops.aten.convolution.default(relu__default_153, primals_1819, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_208 = torch.ops.aten.native_batch_norm.default(convolution_default_208, primals_1824, primals_1820, primals_1822, primals_1823, True, 0.1, 1e-05);  primals_1820 = None
        getitem_624 = native_batch_norm_default_208[0]
        getitem_625 = native_batch_norm_default_208[1]
        getitem_626 = native_batch_norm_default_208[2];  native_batch_norm_default_208 = None
        add_tensor_36 = torch.ops.aten.add.Tensor(add_tensor_35, getitem_624);  add_tensor_35 = getitem_624 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(add_tensor_36, relu__default_161);  add_tensor_36 = None
        relu_default_25 = torch.ops.aten.relu.default(add_tensor_37);  add_tensor_37 = None
        convolution_default_209 = torch.ops.aten.convolution.default(relu_default_18, primals_1091, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_209 = torch.ops.aten.native_batch_norm.default(convolution_default_209, primals_1085, primals_1081, primals_1083, primals_1084, True, 0.1, 1e-05);  primals_1081 = None
        getitem_627 = native_batch_norm_default_209[0]
        getitem_628 = native_batch_norm_default_209[1]
        getitem_629 = native_batch_norm_default_209[2];  native_batch_norm_default_209 = None
        relu__default_162 = torch.ops.aten.relu_.default(getitem_627);  getitem_627 = None
        convolution_default_210 = torch.ops.aten.convolution.default(relu__default_162, primals_1092, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_210 = torch.ops.aten.native_batch_norm.default(convolution_default_210, primals_1090, primals_1086, primals_1088, primals_1089, True, 0.1, 1e-05);  primals_1086 = None
        getitem_630 = native_batch_norm_default_210[0]
        getitem_631 = native_batch_norm_default_210[1]
        getitem_632 = native_batch_norm_default_210[2];  native_batch_norm_default_210 = None
        add__tensor_287 = torch.ops.aten.add_.Tensor(getitem_630, relu_default_18);  getitem_630 = None
        relu__default_163 = torch.ops.aten.relu_.default(add__tensor_287);  add__tensor_287 = None
        convolution_default_211 = torch.ops.aten.convolution.default(relu__default_163, primals_1103, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_211 = torch.ops.aten.native_batch_norm.default(convolution_default_211, primals_1097, primals_1093, primals_1095, primals_1096, True, 0.1, 1e-05);  primals_1093 = None
        getitem_633 = native_batch_norm_default_211[0]
        getitem_634 = native_batch_norm_default_211[1]
        getitem_635 = native_batch_norm_default_211[2];  native_batch_norm_default_211 = None
        relu__default_164 = torch.ops.aten.relu_.default(getitem_633);  getitem_633 = None
        convolution_default_212 = torch.ops.aten.convolution.default(relu__default_164, primals_1104, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_212 = torch.ops.aten.native_batch_norm.default(convolution_default_212, primals_1102, primals_1098, primals_1100, primals_1101, True, 0.1, 1e-05);  primals_1098 = None
        getitem_636 = native_batch_norm_default_212[0]
        getitem_637 = native_batch_norm_default_212[1]
        getitem_638 = native_batch_norm_default_212[2];  native_batch_norm_default_212 = None
        add__tensor_290 = torch.ops.aten.add_.Tensor(getitem_636, relu__default_163);  getitem_636 = None
        relu__default_165 = torch.ops.aten.relu_.default(add__tensor_290);  add__tensor_290 = None
        convolution_default_213 = torch.ops.aten.convolution.default(relu__default_165, primals_1115, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_213 = torch.ops.aten.native_batch_norm.default(convolution_default_213, primals_1109, primals_1105, primals_1107, primals_1108, True, 0.1, 1e-05);  primals_1105 = None
        getitem_639 = native_batch_norm_default_213[0]
        getitem_640 = native_batch_norm_default_213[1]
        getitem_641 = native_batch_norm_default_213[2];  native_batch_norm_default_213 = None
        relu__default_166 = torch.ops.aten.relu_.default(getitem_639);  getitem_639 = None
        convolution_default_214 = torch.ops.aten.convolution.default(relu__default_166, primals_1116, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_214 = torch.ops.aten.native_batch_norm.default(convolution_default_214, primals_1114, primals_1110, primals_1112, primals_1113, True, 0.1, 1e-05);  primals_1110 = None
        getitem_642 = native_batch_norm_default_214[0]
        getitem_643 = native_batch_norm_default_214[1]
        getitem_644 = native_batch_norm_default_214[2];  native_batch_norm_default_214 = None
        add__tensor_293 = torch.ops.aten.add_.Tensor(getitem_642, relu__default_165);  getitem_642 = None
        relu__default_167 = torch.ops.aten.relu_.default(add__tensor_293);  add__tensor_293 = None
        convolution_default_215 = torch.ops.aten.convolution.default(relu__default_167, primals_1127, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_215 = torch.ops.aten.native_batch_norm.default(convolution_default_215, primals_1121, primals_1117, primals_1119, primals_1120, True, 0.1, 1e-05);  primals_1117 = None
        getitem_645 = native_batch_norm_default_215[0]
        getitem_646 = native_batch_norm_default_215[1]
        getitem_647 = native_batch_norm_default_215[2];  native_batch_norm_default_215 = None
        relu__default_168 = torch.ops.aten.relu_.default(getitem_645);  getitem_645 = None
        convolution_default_216 = torch.ops.aten.convolution.default(relu__default_168, primals_1128, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_216 = torch.ops.aten.native_batch_norm.default(convolution_default_216, primals_1126, primals_1122, primals_1124, primals_1125, True, 0.1, 1e-05);  primals_1122 = None
        getitem_648 = native_batch_norm_default_216[0]
        getitem_649 = native_batch_norm_default_216[1]
        getitem_650 = native_batch_norm_default_216[2];  native_batch_norm_default_216 = None
        add__tensor_296 = torch.ops.aten.add_.Tensor(getitem_648, relu__default_167);  getitem_648 = None
        relu__default_169 = torch.ops.aten.relu_.default(add__tensor_296);  add__tensor_296 = None
        convolution_default_217 = torch.ops.aten.convolution.default(relu_default_19, primals_1139, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_217 = torch.ops.aten.native_batch_norm.default(convolution_default_217, primals_1133, primals_1129, primals_1131, primals_1132, True, 0.1, 1e-05);  primals_1129 = None
        getitem_651 = native_batch_norm_default_217[0]
        getitem_652 = native_batch_norm_default_217[1]
        getitem_653 = native_batch_norm_default_217[2];  native_batch_norm_default_217 = None
        relu__default_170 = torch.ops.aten.relu_.default(getitem_651);  getitem_651 = None
        convolution_default_218 = torch.ops.aten.convolution.default(relu__default_170, primals_1140, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_218 = torch.ops.aten.native_batch_norm.default(convolution_default_218, primals_1138, primals_1134, primals_1136, primals_1137, True, 0.1, 1e-05);  primals_1134 = None
        getitem_654 = native_batch_norm_default_218[0]
        getitem_655 = native_batch_norm_default_218[1]
        getitem_656 = native_batch_norm_default_218[2];  native_batch_norm_default_218 = None
        add__tensor_299 = torch.ops.aten.add_.Tensor(getitem_654, relu_default_19);  getitem_654 = None
        relu__default_171 = torch.ops.aten.relu_.default(add__tensor_299);  add__tensor_299 = None
        convolution_default_219 = torch.ops.aten.convolution.default(relu__default_171, primals_1151, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_219 = torch.ops.aten.native_batch_norm.default(convolution_default_219, primals_1145, primals_1141, primals_1143, primals_1144, True, 0.1, 1e-05);  primals_1141 = None
        getitem_657 = native_batch_norm_default_219[0]
        getitem_658 = native_batch_norm_default_219[1]
        getitem_659 = native_batch_norm_default_219[2];  native_batch_norm_default_219 = None
        relu__default_172 = torch.ops.aten.relu_.default(getitem_657);  getitem_657 = None
        convolution_default_220 = torch.ops.aten.convolution.default(relu__default_172, primals_1152, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_220 = torch.ops.aten.native_batch_norm.default(convolution_default_220, primals_1150, primals_1146, primals_1148, primals_1149, True, 0.1, 1e-05);  primals_1146 = None
        getitem_660 = native_batch_norm_default_220[0]
        getitem_661 = native_batch_norm_default_220[1]
        getitem_662 = native_batch_norm_default_220[2];  native_batch_norm_default_220 = None
        add__tensor_302 = torch.ops.aten.add_.Tensor(getitem_660, relu__default_171);  getitem_660 = None
        relu__default_173 = torch.ops.aten.relu_.default(add__tensor_302);  add__tensor_302 = None
        convolution_default_221 = torch.ops.aten.convolution.default(relu__default_173, primals_1163, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_221 = torch.ops.aten.native_batch_norm.default(convolution_default_221, primals_1157, primals_1153, primals_1155, primals_1156, True, 0.1, 1e-05);  primals_1153 = None
        getitem_663 = native_batch_norm_default_221[0]
        getitem_664 = native_batch_norm_default_221[1]
        getitem_665 = native_batch_norm_default_221[2];  native_batch_norm_default_221 = None
        relu__default_174 = torch.ops.aten.relu_.default(getitem_663);  getitem_663 = None
        convolution_default_222 = torch.ops.aten.convolution.default(relu__default_174, primals_1164, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_222 = torch.ops.aten.native_batch_norm.default(convolution_default_222, primals_1162, primals_1158, primals_1160, primals_1161, True, 0.1, 1e-05);  primals_1158 = None
        getitem_666 = native_batch_norm_default_222[0]
        getitem_667 = native_batch_norm_default_222[1]
        getitem_668 = native_batch_norm_default_222[2];  native_batch_norm_default_222 = None
        add__tensor_305 = torch.ops.aten.add_.Tensor(getitem_666, relu__default_173);  getitem_666 = None
        relu__default_175 = torch.ops.aten.relu_.default(add__tensor_305);  add__tensor_305 = None
        convolution_default_223 = torch.ops.aten.convolution.default(relu__default_175, primals_1175, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_223 = torch.ops.aten.native_batch_norm.default(convolution_default_223, primals_1169, primals_1165, primals_1167, primals_1168, True, 0.1, 1e-05);  primals_1165 = None
        getitem_669 = native_batch_norm_default_223[0]
        getitem_670 = native_batch_norm_default_223[1]
        getitem_671 = native_batch_norm_default_223[2];  native_batch_norm_default_223 = None
        relu__default_176 = torch.ops.aten.relu_.default(getitem_669);  getitem_669 = None
        convolution_default_224 = torch.ops.aten.convolution.default(relu__default_176, primals_1176, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_224 = torch.ops.aten.native_batch_norm.default(convolution_default_224, primals_1174, primals_1170, primals_1172, primals_1173, True, 0.1, 1e-05);  primals_1170 = None
        getitem_672 = native_batch_norm_default_224[0]
        getitem_673 = native_batch_norm_default_224[1]
        getitem_674 = native_batch_norm_default_224[2];  native_batch_norm_default_224 = None
        add__tensor_308 = torch.ops.aten.add_.Tensor(getitem_672, relu__default_175);  getitem_672 = None
        relu__default_177 = torch.ops.aten.relu_.default(add__tensor_308);  add__tensor_308 = None
        convolution_default_225 = torch.ops.aten.convolution.default(relu_default_21, primals_1187, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_225 = torch.ops.aten.native_batch_norm.default(convolution_default_225, primals_1181, primals_1177, primals_1179, primals_1180, True, 0.1, 1e-05);  primals_1177 = None
        getitem_675 = native_batch_norm_default_225[0]
        getitem_676 = native_batch_norm_default_225[1]
        getitem_677 = native_batch_norm_default_225[2];  native_batch_norm_default_225 = None
        relu__default_178 = torch.ops.aten.relu_.default(getitem_675);  getitem_675 = None
        convolution_default_226 = torch.ops.aten.convolution.default(relu__default_178, primals_1188, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_226 = torch.ops.aten.native_batch_norm.default(convolution_default_226, primals_1186, primals_1182, primals_1184, primals_1185, True, 0.1, 1e-05);  primals_1182 = None
        getitem_678 = native_batch_norm_default_226[0]
        getitem_679 = native_batch_norm_default_226[1]
        getitem_680 = native_batch_norm_default_226[2];  native_batch_norm_default_226 = None
        add__tensor_311 = torch.ops.aten.add_.Tensor(getitem_678, relu_default_21);  getitem_678 = None
        relu__default_179 = torch.ops.aten.relu_.default(add__tensor_311);  add__tensor_311 = None
        convolution_default_227 = torch.ops.aten.convolution.default(relu__default_179, primals_1199, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_227 = torch.ops.aten.native_batch_norm.default(convolution_default_227, primals_1193, primals_1189, primals_1191, primals_1192, True, 0.1, 1e-05);  primals_1189 = None
        getitem_681 = native_batch_norm_default_227[0]
        getitem_682 = native_batch_norm_default_227[1]
        getitem_683 = native_batch_norm_default_227[2];  native_batch_norm_default_227 = None
        relu__default_180 = torch.ops.aten.relu_.default(getitem_681);  getitem_681 = None
        convolution_default_228 = torch.ops.aten.convolution.default(relu__default_180, primals_1200, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_228 = torch.ops.aten.native_batch_norm.default(convolution_default_228, primals_1198, primals_1194, primals_1196, primals_1197, True, 0.1, 1e-05);  primals_1194 = None
        getitem_684 = native_batch_norm_default_228[0]
        getitem_685 = native_batch_norm_default_228[1]
        getitem_686 = native_batch_norm_default_228[2];  native_batch_norm_default_228 = None
        add__tensor_314 = torch.ops.aten.add_.Tensor(getitem_684, relu__default_179);  getitem_684 = None
        relu__default_181 = torch.ops.aten.relu_.default(add__tensor_314);  add__tensor_314 = None
        convolution_default_229 = torch.ops.aten.convolution.default(relu__default_181, primals_1211, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_229 = torch.ops.aten.native_batch_norm.default(convolution_default_229, primals_1205, primals_1201, primals_1203, primals_1204, True, 0.1, 1e-05);  primals_1201 = None
        getitem_687 = native_batch_norm_default_229[0]
        getitem_688 = native_batch_norm_default_229[1]
        getitem_689 = native_batch_norm_default_229[2];  native_batch_norm_default_229 = None
        relu__default_182 = torch.ops.aten.relu_.default(getitem_687);  getitem_687 = None
        convolution_default_230 = torch.ops.aten.convolution.default(relu__default_182, primals_1212, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_230 = torch.ops.aten.native_batch_norm.default(convolution_default_230, primals_1210, primals_1206, primals_1208, primals_1209, True, 0.1, 1e-05);  primals_1206 = None
        getitem_690 = native_batch_norm_default_230[0]
        getitem_691 = native_batch_norm_default_230[1]
        getitem_692 = native_batch_norm_default_230[2];  native_batch_norm_default_230 = None
        add__tensor_317 = torch.ops.aten.add_.Tensor(getitem_690, relu__default_181);  getitem_690 = None
        relu__default_183 = torch.ops.aten.relu_.default(add__tensor_317);  add__tensor_317 = None
        convolution_default_231 = torch.ops.aten.convolution.default(relu__default_183, primals_1223, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_231 = torch.ops.aten.native_batch_norm.default(convolution_default_231, primals_1217, primals_1213, primals_1215, primals_1216, True, 0.1, 1e-05);  primals_1213 = None
        getitem_693 = native_batch_norm_default_231[0]
        getitem_694 = native_batch_norm_default_231[1]
        getitem_695 = native_batch_norm_default_231[2];  native_batch_norm_default_231 = None
        relu__default_184 = torch.ops.aten.relu_.default(getitem_693);  getitem_693 = None
        convolution_default_232 = torch.ops.aten.convolution.default(relu__default_184, primals_1224, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_232 = torch.ops.aten.native_batch_norm.default(convolution_default_232, primals_1222, primals_1218, primals_1220, primals_1221, True, 0.1, 1e-05);  primals_1218 = None
        getitem_696 = native_batch_norm_default_232[0]
        getitem_697 = native_batch_norm_default_232[1]
        getitem_698 = native_batch_norm_default_232[2];  native_batch_norm_default_232 = None
        add__tensor_320 = torch.ops.aten.add_.Tensor(getitem_696, relu__default_183);  getitem_696 = None
        relu__default_185 = torch.ops.aten.relu_.default(add__tensor_320);  add__tensor_320 = None
        convolution_default_233 = torch.ops.aten.convolution.default(relu_default_25, primals_1235, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_233 = torch.ops.aten.native_batch_norm.default(convolution_default_233, primals_1229, primals_1225, primals_1227, primals_1228, True, 0.1, 1e-05);  primals_1225 = None
        getitem_699 = native_batch_norm_default_233[0]
        getitem_700 = native_batch_norm_default_233[1]
        getitem_701 = native_batch_norm_default_233[2];  native_batch_norm_default_233 = None
        relu__default_186 = torch.ops.aten.relu_.default(getitem_699);  getitem_699 = None
        convolution_default_234 = torch.ops.aten.convolution.default(relu__default_186, primals_1236, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_234 = torch.ops.aten.native_batch_norm.default(convolution_default_234, primals_1234, primals_1230, primals_1232, primals_1233, True, 0.1, 1e-05);  primals_1230 = None
        getitem_702 = native_batch_norm_default_234[0]
        getitem_703 = native_batch_norm_default_234[1]
        getitem_704 = native_batch_norm_default_234[2];  native_batch_norm_default_234 = None
        add__tensor_323 = torch.ops.aten.add_.Tensor(getitem_702, relu_default_25);  getitem_702 = None
        relu__default_187 = torch.ops.aten.relu_.default(add__tensor_323);  add__tensor_323 = None
        convolution_default_235 = torch.ops.aten.convolution.default(relu__default_187, primals_1247, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_235 = torch.ops.aten.native_batch_norm.default(convolution_default_235, primals_1241, primals_1237, primals_1239, primals_1240, True, 0.1, 1e-05);  primals_1237 = None
        getitem_705 = native_batch_norm_default_235[0]
        getitem_706 = native_batch_norm_default_235[1]
        getitem_707 = native_batch_norm_default_235[2];  native_batch_norm_default_235 = None
        relu__default_188 = torch.ops.aten.relu_.default(getitem_705);  getitem_705 = None
        convolution_default_236 = torch.ops.aten.convolution.default(relu__default_188, primals_1248, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_236 = torch.ops.aten.native_batch_norm.default(convolution_default_236, primals_1246, primals_1242, primals_1244, primals_1245, True, 0.1, 1e-05);  primals_1242 = None
        getitem_708 = native_batch_norm_default_236[0]
        getitem_709 = native_batch_norm_default_236[1]
        getitem_710 = native_batch_norm_default_236[2];  native_batch_norm_default_236 = None
        add__tensor_326 = torch.ops.aten.add_.Tensor(getitem_708, relu__default_187);  getitem_708 = None
        relu__default_189 = torch.ops.aten.relu_.default(add__tensor_326);  add__tensor_326 = None
        convolution_default_237 = torch.ops.aten.convolution.default(relu__default_189, primals_1259, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_237 = torch.ops.aten.native_batch_norm.default(convolution_default_237, primals_1253, primals_1249, primals_1251, primals_1252, True, 0.1, 1e-05);  primals_1249 = None
        getitem_711 = native_batch_norm_default_237[0]
        getitem_712 = native_batch_norm_default_237[1]
        getitem_713 = native_batch_norm_default_237[2];  native_batch_norm_default_237 = None
        relu__default_190 = torch.ops.aten.relu_.default(getitem_711);  getitem_711 = None
        convolution_default_238 = torch.ops.aten.convolution.default(relu__default_190, primals_1260, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_238 = torch.ops.aten.native_batch_norm.default(convolution_default_238, primals_1258, primals_1254, primals_1256, primals_1257, True, 0.1, 1e-05);  primals_1254 = None
        getitem_714 = native_batch_norm_default_238[0]
        getitem_715 = native_batch_norm_default_238[1]
        getitem_716 = native_batch_norm_default_238[2];  native_batch_norm_default_238 = None
        add__tensor_329 = torch.ops.aten.add_.Tensor(getitem_714, relu__default_189);  getitem_714 = None
        relu__default_191 = torch.ops.aten.relu_.default(add__tensor_329);  add__tensor_329 = None
        convolution_default_239 = torch.ops.aten.convolution.default(relu__default_191, primals_1271, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_239 = torch.ops.aten.native_batch_norm.default(convolution_default_239, primals_1265, primals_1261, primals_1263, primals_1264, True, 0.1, 1e-05);  primals_1261 = None
        getitem_717 = native_batch_norm_default_239[0]
        getitem_718 = native_batch_norm_default_239[1]
        getitem_719 = native_batch_norm_default_239[2];  native_batch_norm_default_239 = None
        relu__default_192 = torch.ops.aten.relu_.default(getitem_717);  getitem_717 = None
        convolution_default_240 = torch.ops.aten.convolution.default(relu__default_192, primals_1272, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_240 = torch.ops.aten.native_batch_norm.default(convolution_default_240, primals_1270, primals_1266, primals_1268, primals_1269, True, 0.1, 1e-05);  primals_1266 = None
        getitem_720 = native_batch_norm_default_240[0]
        getitem_721 = native_batch_norm_default_240[1]
        getitem_722 = native_batch_norm_default_240[2];  native_batch_norm_default_240 = None
        add__tensor_332 = torch.ops.aten.add_.Tensor(getitem_720, relu__default_191);  getitem_720 = None
        relu__default_193 = torch.ops.aten.relu_.default(add__tensor_332);  add__tensor_332 = None
        convolution_default_241 = torch.ops.aten.convolution.default(relu__default_177, primals_1711, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_241 = torch.ops.aten.native_batch_norm.default(convolution_default_241, primals_1716, primals_1712, primals_1714, primals_1715, True, 0.1, 1e-05);  primals_1712 = None
        getitem_723 = native_batch_norm_default_241[0]
        getitem_724 = native_batch_norm_default_241[1]
        getitem_725 = native_batch_norm_default_241[2];  native_batch_norm_default_241 = None
        upsample_nearest2d_vec_19 = torch.ops.aten.upsample_nearest2d.vec(getitem_723, None, [2.0, 2.0]);  getitem_723 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(relu__default_169, upsample_nearest2d_vec_19);  upsample_nearest2d_vec_19 = None
        convolution_default_242 = torch.ops.aten.convolution.default(relu__default_185, primals_1825, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_242 = torch.ops.aten.native_batch_norm.default(convolution_default_242, primals_1830, primals_1826, primals_1828, primals_1829, True, 0.1, 1e-05);  primals_1826 = None
        getitem_726 = native_batch_norm_default_242[0]
        getitem_727 = native_batch_norm_default_242[1]
        getitem_728 = native_batch_norm_default_242[2];  native_batch_norm_default_242 = None
        upsample_nearest2d_vec_20 = torch.ops.aten.upsample_nearest2d.vec(getitem_726, None, [4.0, 4.0]);  getitem_726 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(add_tensor_38, upsample_nearest2d_vec_20);  add_tensor_38 = upsample_nearest2d_vec_20 = None
        convolution_default_243 = torch.ops.aten.convolution.default(relu__default_193, primals_1927, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_243 = torch.ops.aten.native_batch_norm.default(convolution_default_243, primals_1932, primals_1928, primals_1930, primals_1931, True, 0.1, 1e-05);  primals_1928 = None
        getitem_729 = native_batch_norm_default_243[0]
        getitem_730 = native_batch_norm_default_243[1]
        getitem_731 = native_batch_norm_default_243[2];  native_batch_norm_default_243 = None
        upsample_nearest2d_vec_21 = torch.ops.aten.upsample_nearest2d.vec(getitem_729, None, [8.0, 8.0]);  getitem_729 = None
        add_tensor_40 = torch.ops.aten.add.Tensor(add_tensor_39, upsample_nearest2d_vec_21);  add_tensor_39 = upsample_nearest2d_vec_21 = None
        relu_default_26 = torch.ops.aten.relu.default(add_tensor_40);  add_tensor_40 = None
        convolution_default_244 = torch.ops.aten.convolution.default(relu__default_169, primals_1525, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_244 = torch.ops.aten.native_batch_norm.default(convolution_default_244, primals_1530, primals_1526, primals_1528, primals_1529, True, 0.1, 1e-05);  primals_1526 = None
        getitem_732 = native_batch_norm_default_244[0]
        getitem_733 = native_batch_norm_default_244[1]
        getitem_734 = native_batch_norm_default_244[2];  native_batch_norm_default_244 = None
        add_tensor_41 = torch.ops.aten.add.Tensor(getitem_732, relu__default_177);  getitem_732 = None
        convolution_default_245 = torch.ops.aten.convolution.default(relu__default_185, primals_1831, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_245 = torch.ops.aten.native_batch_norm.default(convolution_default_245, primals_1836, primals_1832, primals_1834, primals_1835, True, 0.1, 1e-05);  primals_1832 = None
        getitem_735 = native_batch_norm_default_245[0]
        getitem_736 = native_batch_norm_default_245[1]
        getitem_737 = native_batch_norm_default_245[2];  native_batch_norm_default_245 = None
        upsample_nearest2d_vec_22 = torch.ops.aten.upsample_nearest2d.vec(getitem_735, None, [2.0, 2.0]);  getitem_735 = None
        add_tensor_42 = torch.ops.aten.add.Tensor(add_tensor_41, upsample_nearest2d_vec_22);  add_tensor_41 = upsample_nearest2d_vec_22 = None
        convolution_default_246 = torch.ops.aten.convolution.default(relu__default_193, primals_1933, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_246 = torch.ops.aten.native_batch_norm.default(convolution_default_246, primals_1938, primals_1934, primals_1936, primals_1937, True, 0.1, 1e-05);  primals_1934 = None
        getitem_738 = native_batch_norm_default_246[0]
        getitem_739 = native_batch_norm_default_246[1]
        getitem_740 = native_batch_norm_default_246[2];  native_batch_norm_default_246 = None
        upsample_nearest2d_vec_23 = torch.ops.aten.upsample_nearest2d.vec(getitem_738, None, [4.0, 4.0]);  getitem_738 = None
        add_tensor_43 = torch.ops.aten.add.Tensor(add_tensor_42, upsample_nearest2d_vec_23);  add_tensor_42 = upsample_nearest2d_vec_23 = None
        relu_default_27 = torch.ops.aten.relu.default(add_tensor_43);  add_tensor_43 = None
        convolution_default_247 = torch.ops.aten.convolution.default(relu__default_169, primals_1531, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_247 = torch.ops.aten.native_batch_norm.default(convolution_default_247, primals_1536, primals_1532, primals_1534, primals_1535, True, 0.1, 1e-05);  primals_1532 = None
        getitem_741 = native_batch_norm_default_247[0]
        getitem_742 = native_batch_norm_default_247[1]
        getitem_743 = native_batch_norm_default_247[2];  native_batch_norm_default_247 = None
        relu_default_28 = torch.ops.aten.relu.default(getitem_741);  getitem_741 = None
        convolution_default_248 = torch.ops.aten.convolution.default(relu_default_28, primals_1537, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_248 = torch.ops.aten.native_batch_norm.default(convolution_default_248, primals_1542, primals_1538, primals_1540, primals_1541, True, 0.1, 1e-05);  primals_1538 = None
        getitem_744 = native_batch_norm_default_248[0]
        getitem_745 = native_batch_norm_default_248[1]
        getitem_746 = native_batch_norm_default_248[2];  native_batch_norm_default_248 = None
        convolution_default_249 = torch.ops.aten.convolution.default(relu__default_177, primals_1717, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_249 = torch.ops.aten.native_batch_norm.default(convolution_default_249, primals_1722, primals_1718, primals_1720, primals_1721, True, 0.1, 1e-05);  primals_1718 = None
        getitem_747 = native_batch_norm_default_249[0]
        getitem_748 = native_batch_norm_default_249[1]
        getitem_749 = native_batch_norm_default_249[2];  native_batch_norm_default_249 = None
        add_tensor_44 = torch.ops.aten.add.Tensor(getitem_744, getitem_747);  getitem_744 = getitem_747 = None
        add_tensor_45 = torch.ops.aten.add.Tensor(add_tensor_44, relu__default_185);  add_tensor_44 = None
        convolution_default_250 = torch.ops.aten.convolution.default(relu__default_193, primals_1939, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_250 = torch.ops.aten.native_batch_norm.default(convolution_default_250, primals_1944, primals_1940, primals_1942, primals_1943, True, 0.1, 1e-05);  primals_1940 = None
        getitem_750 = native_batch_norm_default_250[0]
        getitem_751 = native_batch_norm_default_250[1]
        getitem_752 = native_batch_norm_default_250[2];  native_batch_norm_default_250 = None
        upsample_nearest2d_vec_24 = torch.ops.aten.upsample_nearest2d.vec(getitem_750, None, [2.0, 2.0]);  getitem_750 = None
        add_tensor_46 = torch.ops.aten.add.Tensor(add_tensor_45, upsample_nearest2d_vec_24);  add_tensor_45 = upsample_nearest2d_vec_24 = None
        relu_default_29 = torch.ops.aten.relu.default(add_tensor_46);  add_tensor_46 = None
        convolution_default_251 = torch.ops.aten.convolution.default(relu__default_169, primals_1543, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_251 = torch.ops.aten.native_batch_norm.default(convolution_default_251, primals_1548, primals_1544, primals_1546, primals_1547, True, 0.1, 1e-05);  primals_1544 = None
        getitem_753 = native_batch_norm_default_251[0]
        getitem_754 = native_batch_norm_default_251[1]
        getitem_755 = native_batch_norm_default_251[2];  native_batch_norm_default_251 = None
        relu_default_30 = torch.ops.aten.relu.default(getitem_753);  getitem_753 = None
        convolution_default_252 = torch.ops.aten.convolution.default(relu_default_30, primals_1549, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_252 = torch.ops.aten.native_batch_norm.default(convolution_default_252, primals_1554, primals_1550, primals_1552, primals_1553, True, 0.1, 1e-05);  primals_1550 = None
        getitem_756 = native_batch_norm_default_252[0]
        getitem_757 = native_batch_norm_default_252[1]
        getitem_758 = native_batch_norm_default_252[2];  native_batch_norm_default_252 = None
        relu_default_31 = torch.ops.aten.relu.default(getitem_756);  getitem_756 = None
        convolution_default_253 = torch.ops.aten.convolution.default(relu_default_31, primals_1555, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_253 = torch.ops.aten.native_batch_norm.default(convolution_default_253, primals_1560, primals_1556, primals_1558, primals_1559, True, 0.1, 1e-05);  primals_1556 = None
        getitem_759 = native_batch_norm_default_253[0]
        getitem_760 = native_batch_norm_default_253[1]
        getitem_761 = native_batch_norm_default_253[2];  native_batch_norm_default_253 = None
        convolution_default_254 = torch.ops.aten.convolution.default(relu__default_177, primals_1723, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_254 = torch.ops.aten.native_batch_norm.default(convolution_default_254, primals_1728, primals_1724, primals_1726, primals_1727, True, 0.1, 1e-05);  primals_1724 = None
        getitem_762 = native_batch_norm_default_254[0]
        getitem_763 = native_batch_norm_default_254[1]
        getitem_764 = native_batch_norm_default_254[2];  native_batch_norm_default_254 = None
        relu_default_32 = torch.ops.aten.relu.default(getitem_762);  getitem_762 = None
        convolution_default_255 = torch.ops.aten.convolution.default(relu_default_32, primals_1729, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_255 = torch.ops.aten.native_batch_norm.default(convolution_default_255, primals_1734, primals_1730, primals_1732, primals_1733, True, 0.1, 1e-05);  primals_1730 = None
        getitem_765 = native_batch_norm_default_255[0]
        getitem_766 = native_batch_norm_default_255[1]
        getitem_767 = native_batch_norm_default_255[2];  native_batch_norm_default_255 = None
        add_tensor_47 = torch.ops.aten.add.Tensor(getitem_759, getitem_765);  getitem_759 = getitem_765 = None
        convolution_default_256 = torch.ops.aten.convolution.default(relu__default_185, primals_1837, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_256 = torch.ops.aten.native_batch_norm.default(convolution_default_256, primals_1842, primals_1838, primals_1840, primals_1841, True, 0.1, 1e-05);  primals_1838 = None
        getitem_768 = native_batch_norm_default_256[0]
        getitem_769 = native_batch_norm_default_256[1]
        getitem_770 = native_batch_norm_default_256[2];  native_batch_norm_default_256 = None
        add_tensor_48 = torch.ops.aten.add.Tensor(add_tensor_47, getitem_768);  add_tensor_47 = getitem_768 = None
        add_tensor_49 = torch.ops.aten.add.Tensor(add_tensor_48, relu__default_193);  add_tensor_48 = None
        relu_default_33 = torch.ops.aten.relu.default(add_tensor_49);  add_tensor_49 = None
        convolution_default_257 = torch.ops.aten.convolution.default(relu_default_26, primals_1283, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_257 = torch.ops.aten.native_batch_norm.default(convolution_default_257, primals_1277, primals_1273, primals_1275, primals_1276, True, 0.1, 1e-05);  primals_1273 = None
        getitem_771 = native_batch_norm_default_257[0]
        getitem_772 = native_batch_norm_default_257[1]
        getitem_773 = native_batch_norm_default_257[2];  native_batch_norm_default_257 = None
        relu__default_194 = torch.ops.aten.relu_.default(getitem_771);  getitem_771 = None
        convolution_default_258 = torch.ops.aten.convolution.default(relu__default_194, primals_1284, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_258 = torch.ops.aten.native_batch_norm.default(convolution_default_258, primals_1282, primals_1278, primals_1280, primals_1281, True, 0.1, 1e-05);  primals_1278 = None
        getitem_774 = native_batch_norm_default_258[0]
        getitem_775 = native_batch_norm_default_258[1]
        getitem_776 = native_batch_norm_default_258[2];  native_batch_norm_default_258 = None
        add__tensor_351 = torch.ops.aten.add_.Tensor(getitem_774, relu_default_26);  getitem_774 = None
        relu__default_195 = torch.ops.aten.relu_.default(add__tensor_351);  add__tensor_351 = None
        convolution_default_259 = torch.ops.aten.convolution.default(relu__default_195, primals_1295, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_259 = torch.ops.aten.native_batch_norm.default(convolution_default_259, primals_1289, primals_1285, primals_1287, primals_1288, True, 0.1, 1e-05);  primals_1285 = None
        getitem_777 = native_batch_norm_default_259[0]
        getitem_778 = native_batch_norm_default_259[1]
        getitem_779 = native_batch_norm_default_259[2];  native_batch_norm_default_259 = None
        relu__default_196 = torch.ops.aten.relu_.default(getitem_777);  getitem_777 = None
        convolution_default_260 = torch.ops.aten.convolution.default(relu__default_196, primals_1296, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_260 = torch.ops.aten.native_batch_norm.default(convolution_default_260, primals_1294, primals_1290, primals_1292, primals_1293, True, 0.1, 1e-05);  primals_1290 = None
        getitem_780 = native_batch_norm_default_260[0]
        getitem_781 = native_batch_norm_default_260[1]
        getitem_782 = native_batch_norm_default_260[2];  native_batch_norm_default_260 = None
        add__tensor_354 = torch.ops.aten.add_.Tensor(getitem_780, relu__default_195);  getitem_780 = None
        relu__default_197 = torch.ops.aten.relu_.default(add__tensor_354);  add__tensor_354 = None
        convolution_default_261 = torch.ops.aten.convolution.default(relu__default_197, primals_1307, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_261 = torch.ops.aten.native_batch_norm.default(convolution_default_261, primals_1301, primals_1297, primals_1299, primals_1300, True, 0.1, 1e-05);  primals_1297 = None
        getitem_783 = native_batch_norm_default_261[0]
        getitem_784 = native_batch_norm_default_261[1]
        getitem_785 = native_batch_norm_default_261[2];  native_batch_norm_default_261 = None
        relu__default_198 = torch.ops.aten.relu_.default(getitem_783);  getitem_783 = None
        convolution_default_262 = torch.ops.aten.convolution.default(relu__default_198, primals_1308, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_262 = torch.ops.aten.native_batch_norm.default(convolution_default_262, primals_1306, primals_1302, primals_1304, primals_1305, True, 0.1, 1e-05);  primals_1302 = None
        getitem_786 = native_batch_norm_default_262[0]
        getitem_787 = native_batch_norm_default_262[1]
        getitem_788 = native_batch_norm_default_262[2];  native_batch_norm_default_262 = None
        add__tensor_357 = torch.ops.aten.add_.Tensor(getitem_786, relu__default_197);  getitem_786 = None
        relu__default_199 = torch.ops.aten.relu_.default(add__tensor_357);  add__tensor_357 = None
        convolution_default_263 = torch.ops.aten.convolution.default(relu__default_199, primals_1319, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_263 = torch.ops.aten.native_batch_norm.default(convolution_default_263, primals_1313, primals_1309, primals_1311, primals_1312, True, 0.1, 1e-05);  primals_1309 = None
        getitem_789 = native_batch_norm_default_263[0]
        getitem_790 = native_batch_norm_default_263[1]
        getitem_791 = native_batch_norm_default_263[2];  native_batch_norm_default_263 = None
        relu__default_200 = torch.ops.aten.relu_.default(getitem_789);  getitem_789 = None
        convolution_default_264 = torch.ops.aten.convolution.default(relu__default_200, primals_1320, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_264 = torch.ops.aten.native_batch_norm.default(convolution_default_264, primals_1318, primals_1314, primals_1316, primals_1317, True, 0.1, 1e-05);  primals_1314 = None
        getitem_792 = native_batch_norm_default_264[0]
        getitem_793 = native_batch_norm_default_264[1]
        getitem_794 = native_batch_norm_default_264[2];  native_batch_norm_default_264 = None
        add__tensor_360 = torch.ops.aten.add_.Tensor(getitem_792, relu__default_199);  getitem_792 = None
        relu__default_201 = torch.ops.aten.relu_.default(add__tensor_360);  add__tensor_360 = None
        convolution_default_265 = torch.ops.aten.convolution.default(relu_default_27, primals_1331, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_265 = torch.ops.aten.native_batch_norm.default(convolution_default_265, primals_1325, primals_1321, primals_1323, primals_1324, True, 0.1, 1e-05);  primals_1321 = None
        getitem_795 = native_batch_norm_default_265[0]
        getitem_796 = native_batch_norm_default_265[1]
        getitem_797 = native_batch_norm_default_265[2];  native_batch_norm_default_265 = None
        relu__default_202 = torch.ops.aten.relu_.default(getitem_795);  getitem_795 = None
        convolution_default_266 = torch.ops.aten.convolution.default(relu__default_202, primals_1332, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_266 = torch.ops.aten.native_batch_norm.default(convolution_default_266, primals_1330, primals_1326, primals_1328, primals_1329, True, 0.1, 1e-05);  primals_1326 = None
        getitem_798 = native_batch_norm_default_266[0]
        getitem_799 = native_batch_norm_default_266[1]
        getitem_800 = native_batch_norm_default_266[2];  native_batch_norm_default_266 = None
        add__tensor_363 = torch.ops.aten.add_.Tensor(getitem_798, relu_default_27);  getitem_798 = None
        relu__default_203 = torch.ops.aten.relu_.default(add__tensor_363);  add__tensor_363 = None
        convolution_default_267 = torch.ops.aten.convolution.default(relu__default_203, primals_1343, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_267 = torch.ops.aten.native_batch_norm.default(convolution_default_267, primals_1337, primals_1333, primals_1335, primals_1336, True, 0.1, 1e-05);  primals_1333 = None
        getitem_801 = native_batch_norm_default_267[0]
        getitem_802 = native_batch_norm_default_267[1]
        getitem_803 = native_batch_norm_default_267[2];  native_batch_norm_default_267 = None
        relu__default_204 = torch.ops.aten.relu_.default(getitem_801);  getitem_801 = None
        convolution_default_268 = torch.ops.aten.convolution.default(relu__default_204, primals_1344, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_268 = torch.ops.aten.native_batch_norm.default(convolution_default_268, primals_1342, primals_1338, primals_1340, primals_1341, True, 0.1, 1e-05);  primals_1338 = None
        getitem_804 = native_batch_norm_default_268[0]
        getitem_805 = native_batch_norm_default_268[1]
        getitem_806 = native_batch_norm_default_268[2];  native_batch_norm_default_268 = None
        add__tensor_366 = torch.ops.aten.add_.Tensor(getitem_804, relu__default_203);  getitem_804 = None
        relu__default_205 = torch.ops.aten.relu_.default(add__tensor_366);  add__tensor_366 = None
        convolution_default_269 = torch.ops.aten.convolution.default(relu__default_205, primals_1355, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_269 = torch.ops.aten.native_batch_norm.default(convolution_default_269, primals_1349, primals_1345, primals_1347, primals_1348, True, 0.1, 1e-05);  primals_1345 = None
        getitem_807 = native_batch_norm_default_269[0]
        getitem_808 = native_batch_norm_default_269[1]
        getitem_809 = native_batch_norm_default_269[2];  native_batch_norm_default_269 = None
        relu__default_206 = torch.ops.aten.relu_.default(getitem_807);  getitem_807 = None
        convolution_default_270 = torch.ops.aten.convolution.default(relu__default_206, primals_1356, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_270 = torch.ops.aten.native_batch_norm.default(convolution_default_270, primals_1354, primals_1350, primals_1352, primals_1353, True, 0.1, 1e-05);  primals_1350 = None
        getitem_810 = native_batch_norm_default_270[0]
        getitem_811 = native_batch_norm_default_270[1]
        getitem_812 = native_batch_norm_default_270[2];  native_batch_norm_default_270 = None
        add__tensor_369 = torch.ops.aten.add_.Tensor(getitem_810, relu__default_205);  getitem_810 = None
        relu__default_207 = torch.ops.aten.relu_.default(add__tensor_369);  add__tensor_369 = None
        convolution_default_271 = torch.ops.aten.convolution.default(relu__default_207, primals_1367, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_271 = torch.ops.aten.native_batch_norm.default(convolution_default_271, primals_1361, primals_1357, primals_1359, primals_1360, True, 0.1, 1e-05);  primals_1357 = None
        getitem_813 = native_batch_norm_default_271[0]
        getitem_814 = native_batch_norm_default_271[1]
        getitem_815 = native_batch_norm_default_271[2];  native_batch_norm_default_271 = None
        relu__default_208 = torch.ops.aten.relu_.default(getitem_813);  getitem_813 = None
        convolution_default_272 = torch.ops.aten.convolution.default(relu__default_208, primals_1368, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_272 = torch.ops.aten.native_batch_norm.default(convolution_default_272, primals_1366, primals_1362, primals_1364, primals_1365, True, 0.1, 1e-05);  primals_1362 = None
        getitem_816 = native_batch_norm_default_272[0]
        getitem_817 = native_batch_norm_default_272[1]
        getitem_818 = native_batch_norm_default_272[2];  native_batch_norm_default_272 = None
        add__tensor_372 = torch.ops.aten.add_.Tensor(getitem_816, relu__default_207);  getitem_816 = None
        relu__default_209 = torch.ops.aten.relu_.default(add__tensor_372);  add__tensor_372 = None
        convolution_default_273 = torch.ops.aten.convolution.default(relu_default_29, primals_1379, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_273 = torch.ops.aten.native_batch_norm.default(convolution_default_273, primals_1373, primals_1369, primals_1371, primals_1372, True, 0.1, 1e-05);  primals_1369 = None
        getitem_819 = native_batch_norm_default_273[0]
        getitem_820 = native_batch_norm_default_273[1]
        getitem_821 = native_batch_norm_default_273[2];  native_batch_norm_default_273 = None
        relu__default_210 = torch.ops.aten.relu_.default(getitem_819);  getitem_819 = None
        convolution_default_274 = torch.ops.aten.convolution.default(relu__default_210, primals_1380, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_274 = torch.ops.aten.native_batch_norm.default(convolution_default_274, primals_1378, primals_1374, primals_1376, primals_1377, True, 0.1, 1e-05);  primals_1374 = None
        getitem_822 = native_batch_norm_default_274[0]
        getitem_823 = native_batch_norm_default_274[1]
        getitem_824 = native_batch_norm_default_274[2];  native_batch_norm_default_274 = None
        add__tensor_375 = torch.ops.aten.add_.Tensor(getitem_822, relu_default_29);  getitem_822 = None
        relu__default_211 = torch.ops.aten.relu_.default(add__tensor_375);  add__tensor_375 = None
        convolution_default_275 = torch.ops.aten.convolution.default(relu__default_211, primals_1391, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_275 = torch.ops.aten.native_batch_norm.default(convolution_default_275, primals_1385, primals_1381, primals_1383, primals_1384, True, 0.1, 1e-05);  primals_1381 = None
        getitem_825 = native_batch_norm_default_275[0]
        getitem_826 = native_batch_norm_default_275[1]
        getitem_827 = native_batch_norm_default_275[2];  native_batch_norm_default_275 = None
        relu__default_212 = torch.ops.aten.relu_.default(getitem_825);  getitem_825 = None
        convolution_default_276 = torch.ops.aten.convolution.default(relu__default_212, primals_1392, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_276 = torch.ops.aten.native_batch_norm.default(convolution_default_276, primals_1390, primals_1386, primals_1388, primals_1389, True, 0.1, 1e-05);  primals_1386 = None
        getitem_828 = native_batch_norm_default_276[0]
        getitem_829 = native_batch_norm_default_276[1]
        getitem_830 = native_batch_norm_default_276[2];  native_batch_norm_default_276 = None
        add__tensor_378 = torch.ops.aten.add_.Tensor(getitem_828, relu__default_211);  getitem_828 = None
        relu__default_213 = torch.ops.aten.relu_.default(add__tensor_378);  add__tensor_378 = None
        convolution_default_277 = torch.ops.aten.convolution.default(relu__default_213, primals_1403, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_277 = torch.ops.aten.native_batch_norm.default(convolution_default_277, primals_1397, primals_1393, primals_1395, primals_1396, True, 0.1, 1e-05);  primals_1393 = None
        getitem_831 = native_batch_norm_default_277[0]
        getitem_832 = native_batch_norm_default_277[1]
        getitem_833 = native_batch_norm_default_277[2];  native_batch_norm_default_277 = None
        relu__default_214 = torch.ops.aten.relu_.default(getitem_831);  getitem_831 = None
        convolution_default_278 = torch.ops.aten.convolution.default(relu__default_214, primals_1404, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_278 = torch.ops.aten.native_batch_norm.default(convolution_default_278, primals_1402, primals_1398, primals_1400, primals_1401, True, 0.1, 1e-05);  primals_1398 = None
        getitem_834 = native_batch_norm_default_278[0]
        getitem_835 = native_batch_norm_default_278[1]
        getitem_836 = native_batch_norm_default_278[2];  native_batch_norm_default_278 = None
        add__tensor_381 = torch.ops.aten.add_.Tensor(getitem_834, relu__default_213);  getitem_834 = None
        relu__default_215 = torch.ops.aten.relu_.default(add__tensor_381);  add__tensor_381 = None
        convolution_default_279 = torch.ops.aten.convolution.default(relu__default_215, primals_1415, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_279 = torch.ops.aten.native_batch_norm.default(convolution_default_279, primals_1409, primals_1405, primals_1407, primals_1408, True, 0.1, 1e-05);  primals_1405 = None
        getitem_837 = native_batch_norm_default_279[0]
        getitem_838 = native_batch_norm_default_279[1]
        getitem_839 = native_batch_norm_default_279[2];  native_batch_norm_default_279 = None
        relu__default_216 = torch.ops.aten.relu_.default(getitem_837);  getitem_837 = None
        convolution_default_280 = torch.ops.aten.convolution.default(relu__default_216, primals_1416, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_280 = torch.ops.aten.native_batch_norm.default(convolution_default_280, primals_1414, primals_1410, primals_1412, primals_1413, True, 0.1, 1e-05);  primals_1410 = None
        getitem_840 = native_batch_norm_default_280[0]
        getitem_841 = native_batch_norm_default_280[1]
        getitem_842 = native_batch_norm_default_280[2];  native_batch_norm_default_280 = None
        add__tensor_384 = torch.ops.aten.add_.Tensor(getitem_840, relu__default_215);  getitem_840 = None
        relu__default_217 = torch.ops.aten.relu_.default(add__tensor_384);  add__tensor_384 = None
        convolution_default_281 = torch.ops.aten.convolution.default(relu_default_33, primals_1427, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_281 = torch.ops.aten.native_batch_norm.default(convolution_default_281, primals_1421, primals_1417, primals_1419, primals_1420, True, 0.1, 1e-05);  primals_1417 = None
        getitem_843 = native_batch_norm_default_281[0]
        getitem_844 = native_batch_norm_default_281[1]
        getitem_845 = native_batch_norm_default_281[2];  native_batch_norm_default_281 = None
        relu__default_218 = torch.ops.aten.relu_.default(getitem_843);  getitem_843 = None
        convolution_default_282 = torch.ops.aten.convolution.default(relu__default_218, primals_1428, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_282 = torch.ops.aten.native_batch_norm.default(convolution_default_282, primals_1426, primals_1422, primals_1424, primals_1425, True, 0.1, 1e-05);  primals_1422 = None
        getitem_846 = native_batch_norm_default_282[0]
        getitem_847 = native_batch_norm_default_282[1]
        getitem_848 = native_batch_norm_default_282[2];  native_batch_norm_default_282 = None
        add__tensor_387 = torch.ops.aten.add_.Tensor(getitem_846, relu_default_33);  getitem_846 = None
        relu__default_219 = torch.ops.aten.relu_.default(add__tensor_387);  add__tensor_387 = None
        convolution_default_283 = torch.ops.aten.convolution.default(relu__default_219, primals_1439, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_283 = torch.ops.aten.native_batch_norm.default(convolution_default_283, primals_1433, primals_1429, primals_1431, primals_1432, True, 0.1, 1e-05);  primals_1429 = None
        getitem_849 = native_batch_norm_default_283[0]
        getitem_850 = native_batch_norm_default_283[1]
        getitem_851 = native_batch_norm_default_283[2];  native_batch_norm_default_283 = None
        relu__default_220 = torch.ops.aten.relu_.default(getitem_849);  getitem_849 = None
        convolution_default_284 = torch.ops.aten.convolution.default(relu__default_220, primals_1440, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_284 = torch.ops.aten.native_batch_norm.default(convolution_default_284, primals_1438, primals_1434, primals_1436, primals_1437, True, 0.1, 1e-05);  primals_1434 = None
        getitem_852 = native_batch_norm_default_284[0]
        getitem_853 = native_batch_norm_default_284[1]
        getitem_854 = native_batch_norm_default_284[2];  native_batch_norm_default_284 = None
        add__tensor_390 = torch.ops.aten.add_.Tensor(getitem_852, relu__default_219);  getitem_852 = None
        relu__default_221 = torch.ops.aten.relu_.default(add__tensor_390);  add__tensor_390 = None
        convolution_default_285 = torch.ops.aten.convolution.default(relu__default_221, primals_1451, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_285 = torch.ops.aten.native_batch_norm.default(convolution_default_285, primals_1445, primals_1441, primals_1443, primals_1444, True, 0.1, 1e-05);  primals_1441 = None
        getitem_855 = native_batch_norm_default_285[0]
        getitem_856 = native_batch_norm_default_285[1]
        getitem_857 = native_batch_norm_default_285[2];  native_batch_norm_default_285 = None
        relu__default_222 = torch.ops.aten.relu_.default(getitem_855);  getitem_855 = None
        convolution_default_286 = torch.ops.aten.convolution.default(relu__default_222, primals_1452, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_286 = torch.ops.aten.native_batch_norm.default(convolution_default_286, primals_1450, primals_1446, primals_1448, primals_1449, True, 0.1, 1e-05);  primals_1446 = None
        getitem_858 = native_batch_norm_default_286[0]
        getitem_859 = native_batch_norm_default_286[1]
        getitem_860 = native_batch_norm_default_286[2];  native_batch_norm_default_286 = None
        add__tensor_393 = torch.ops.aten.add_.Tensor(getitem_858, relu__default_221);  getitem_858 = None
        relu__default_223 = torch.ops.aten.relu_.default(add__tensor_393);  add__tensor_393 = None
        convolution_default_287 = torch.ops.aten.convolution.default(relu__default_223, primals_1463, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_287 = torch.ops.aten.native_batch_norm.default(convolution_default_287, primals_1457, primals_1453, primals_1455, primals_1456, True, 0.1, 1e-05);  primals_1453 = None
        getitem_861 = native_batch_norm_default_287[0]
        getitem_862 = native_batch_norm_default_287[1]
        getitem_863 = native_batch_norm_default_287[2];  native_batch_norm_default_287 = None
        relu__default_224 = torch.ops.aten.relu_.default(getitem_861);  getitem_861 = None
        convolution_default_288 = torch.ops.aten.convolution.default(relu__default_224, primals_1464, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_288 = torch.ops.aten.native_batch_norm.default(convolution_default_288, primals_1462, primals_1458, primals_1460, primals_1461, True, 0.1, 1e-05);  primals_1458 = None
        getitem_864 = native_batch_norm_default_288[0]
        getitem_865 = native_batch_norm_default_288[1]
        getitem_866 = native_batch_norm_default_288[2];  native_batch_norm_default_288 = None
        add__tensor_396 = torch.ops.aten.add_.Tensor(getitem_864, relu__default_223);  getitem_864 = None
        relu__default_225 = torch.ops.aten.relu_.default(add__tensor_396);  add__tensor_396 = None
        convolution_default_289 = torch.ops.aten.convolution.default(relu__default_209, primals_1735, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_289 = torch.ops.aten.native_batch_norm.default(convolution_default_289, primals_1740, primals_1736, primals_1738, primals_1739, True, 0.1, 1e-05);  primals_1736 = None
        getitem_867 = native_batch_norm_default_289[0]
        getitem_868 = native_batch_norm_default_289[1]
        getitem_869 = native_batch_norm_default_289[2];  native_batch_norm_default_289 = None
        upsample_nearest2d_vec_25 = torch.ops.aten.upsample_nearest2d.vec(getitem_867, None, [2.0, 2.0]);  getitem_867 = None
        add_tensor_50 = torch.ops.aten.add.Tensor(relu__default_201, upsample_nearest2d_vec_25);  upsample_nearest2d_vec_25 = None
        convolution_default_290 = torch.ops.aten.convolution.default(relu__default_217, primals_1843, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_290 = torch.ops.aten.native_batch_norm.default(convolution_default_290, primals_1848, primals_1844, primals_1846, primals_1847, True, 0.1, 1e-05);  primals_1844 = None
        getitem_870 = native_batch_norm_default_290[0]
        getitem_871 = native_batch_norm_default_290[1]
        getitem_872 = native_batch_norm_default_290[2];  native_batch_norm_default_290 = None
        upsample_nearest2d_vec_26 = torch.ops.aten.upsample_nearest2d.vec(getitem_870, None, [4.0, 4.0]);  getitem_870 = None
        add_tensor_51 = torch.ops.aten.add.Tensor(add_tensor_50, upsample_nearest2d_vec_26);  add_tensor_50 = upsample_nearest2d_vec_26 = None
        convolution_default_291 = torch.ops.aten.convolution.default(relu__default_225, primals_1945, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_291 = torch.ops.aten.native_batch_norm.default(convolution_default_291, primals_1950, primals_1946, primals_1948, primals_1949, True, 0.1, 1e-05);  primals_1946 = None
        getitem_873 = native_batch_norm_default_291[0]
        getitem_874 = native_batch_norm_default_291[1]
        getitem_875 = native_batch_norm_default_291[2];  native_batch_norm_default_291 = None
        upsample_nearest2d_vec_27 = torch.ops.aten.upsample_nearest2d.vec(getitem_873, None, [8.0, 8.0]);  getitem_873 = None
        add_tensor_52 = torch.ops.aten.add.Tensor(add_tensor_51, upsample_nearest2d_vec_27);  add_tensor_51 = upsample_nearest2d_vec_27 = None
        relu_default_34 = torch.ops.aten.relu.default(add_tensor_52);  add_tensor_52 = None
        convolution_default_292 = torch.ops.aten.convolution.default(relu__default_201, primals_1561, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_292 = torch.ops.aten.native_batch_norm.default(convolution_default_292, primals_1566, primals_1562, primals_1564, primals_1565, True, 0.1, 1e-05);  primals_1562 = None
        getitem_876 = native_batch_norm_default_292[0]
        getitem_877 = native_batch_norm_default_292[1]
        getitem_878 = native_batch_norm_default_292[2];  native_batch_norm_default_292 = None
        add_tensor_53 = torch.ops.aten.add.Tensor(getitem_876, relu__default_209);  getitem_876 = None
        convolution_default_293 = torch.ops.aten.convolution.default(relu__default_217, primals_1849, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_293 = torch.ops.aten.native_batch_norm.default(convolution_default_293, primals_1854, primals_1850, primals_1852, primals_1853, True, 0.1, 1e-05);  primals_1850 = None
        getitem_879 = native_batch_norm_default_293[0]
        getitem_880 = native_batch_norm_default_293[1]
        getitem_881 = native_batch_norm_default_293[2];  native_batch_norm_default_293 = None
        upsample_nearest2d_vec_28 = torch.ops.aten.upsample_nearest2d.vec(getitem_879, None, [2.0, 2.0]);  getitem_879 = None
        add_tensor_54 = torch.ops.aten.add.Tensor(add_tensor_53, upsample_nearest2d_vec_28);  add_tensor_53 = upsample_nearest2d_vec_28 = None
        convolution_default_294 = torch.ops.aten.convolution.default(relu__default_225, primals_1951, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_294 = torch.ops.aten.native_batch_norm.default(convolution_default_294, primals_1956, primals_1952, primals_1954, primals_1955, True, 0.1, 1e-05);  primals_1952 = None
        getitem_882 = native_batch_norm_default_294[0]
        getitem_883 = native_batch_norm_default_294[1]
        getitem_884 = native_batch_norm_default_294[2];  native_batch_norm_default_294 = None
        upsample_nearest2d_vec_29 = torch.ops.aten.upsample_nearest2d.vec(getitem_882, None, [4.0, 4.0]);  getitem_882 = None
        add_tensor_55 = torch.ops.aten.add.Tensor(add_tensor_54, upsample_nearest2d_vec_29);  add_tensor_54 = upsample_nearest2d_vec_29 = None
        relu_default_35 = torch.ops.aten.relu.default(add_tensor_55);  add_tensor_55 = None
        convolution_default_295 = torch.ops.aten.convolution.default(relu__default_201, primals_1567, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_295 = torch.ops.aten.native_batch_norm.default(convolution_default_295, primals_1572, primals_1568, primals_1570, primals_1571, True, 0.1, 1e-05);  primals_1568 = None
        getitem_885 = native_batch_norm_default_295[0]
        getitem_886 = native_batch_norm_default_295[1]
        getitem_887 = native_batch_norm_default_295[2];  native_batch_norm_default_295 = None
        relu_default_36 = torch.ops.aten.relu.default(getitem_885);  getitem_885 = None
        convolution_default_296 = torch.ops.aten.convolution.default(relu_default_36, primals_1573, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_296 = torch.ops.aten.native_batch_norm.default(convolution_default_296, primals_1578, primals_1574, primals_1576, primals_1577, True, 0.1, 1e-05);  primals_1574 = None
        getitem_888 = native_batch_norm_default_296[0]
        getitem_889 = native_batch_norm_default_296[1]
        getitem_890 = native_batch_norm_default_296[2];  native_batch_norm_default_296 = None
        convolution_default_297 = torch.ops.aten.convolution.default(relu__default_209, primals_1741, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_297 = torch.ops.aten.native_batch_norm.default(convolution_default_297, primals_1746, primals_1742, primals_1744, primals_1745, True, 0.1, 1e-05);  primals_1742 = None
        getitem_891 = native_batch_norm_default_297[0]
        getitem_892 = native_batch_norm_default_297[1]
        getitem_893 = native_batch_norm_default_297[2];  native_batch_norm_default_297 = None
        add_tensor_56 = torch.ops.aten.add.Tensor(getitem_888, getitem_891);  getitem_888 = getitem_891 = None
        add_tensor_57 = torch.ops.aten.add.Tensor(add_tensor_56, relu__default_217);  add_tensor_56 = None
        convolution_default_298 = torch.ops.aten.convolution.default(relu__default_225, primals_1909, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_298 = torch.ops.aten.native_batch_norm.default(convolution_default_298, primals_1914, primals_1910, primals_1912, primals_1913, True, 0.1, 1e-05);  primals_1910 = None
        getitem_894 = native_batch_norm_default_298[0]
        getitem_895 = native_batch_norm_default_298[1]
        getitem_896 = native_batch_norm_default_298[2];  native_batch_norm_default_298 = None
        upsample_nearest2d_vec_30 = torch.ops.aten.upsample_nearest2d.vec(getitem_894, None, [2.0, 2.0]);  getitem_894 = None
        add_tensor_58 = torch.ops.aten.add.Tensor(add_tensor_57, upsample_nearest2d_vec_30);  add_tensor_57 = upsample_nearest2d_vec_30 = None
        relu_default_37 = torch.ops.aten.relu.default(add_tensor_58);  add_tensor_58 = None
        convolution_default_299 = torch.ops.aten.convolution.default(relu__default_201, primals_1579, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_299 = torch.ops.aten.native_batch_norm.default(convolution_default_299, primals_1584, primals_1580, primals_1582, primals_1583, True, 0.1, 1e-05);  primals_1580 = None
        getitem_897 = native_batch_norm_default_299[0]
        getitem_898 = native_batch_norm_default_299[1]
        getitem_899 = native_batch_norm_default_299[2];  native_batch_norm_default_299 = None
        relu_default_38 = torch.ops.aten.relu.default(getitem_897);  getitem_897 = None
        convolution_default_300 = torch.ops.aten.convolution.default(relu_default_38, primals_1585, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_300 = torch.ops.aten.native_batch_norm.default(convolution_default_300, primals_1590, primals_1586, primals_1588, primals_1589, True, 0.1, 1e-05);  primals_1586 = None
        getitem_900 = native_batch_norm_default_300[0]
        getitem_901 = native_batch_norm_default_300[1]
        getitem_902 = native_batch_norm_default_300[2];  native_batch_norm_default_300 = None
        relu_default_39 = torch.ops.aten.relu.default(getitem_900);  getitem_900 = None
        convolution_default_301 = torch.ops.aten.convolution.default(relu_default_39, primals_1591, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_301 = torch.ops.aten.native_batch_norm.default(convolution_default_301, primals_1596, primals_1592, primals_1594, primals_1595, True, 0.1, 1e-05);  primals_1592 = None
        getitem_903 = native_batch_norm_default_301[0]
        getitem_904 = native_batch_norm_default_301[1]
        getitem_905 = native_batch_norm_default_301[2];  native_batch_norm_default_301 = None
        convolution_default_302 = torch.ops.aten.convolution.default(relu__default_209, primals_1747, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_302 = torch.ops.aten.native_batch_norm.default(convolution_default_302, primals_1752, primals_1748, primals_1750, primals_1751, True, 0.1, 1e-05);  primals_1748 = None
        getitem_906 = native_batch_norm_default_302[0]
        getitem_907 = native_batch_norm_default_302[1]
        getitem_908 = native_batch_norm_default_302[2];  native_batch_norm_default_302 = None
        relu_default_40 = torch.ops.aten.relu.default(getitem_906);  getitem_906 = None
        convolution_default_303 = torch.ops.aten.convolution.default(relu_default_40, primals_1753, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_303 = torch.ops.aten.native_batch_norm.default(convolution_default_303, primals_1758, primals_1754, primals_1756, primals_1757, True, 0.1, 1e-05);  primals_1754 = None
        getitem_909 = native_batch_norm_default_303[0]
        getitem_910 = native_batch_norm_default_303[1]
        getitem_911 = native_batch_norm_default_303[2];  native_batch_norm_default_303 = None
        add_tensor_59 = torch.ops.aten.add.Tensor(getitem_903, getitem_909);  getitem_903 = getitem_909 = None
        convolution_default_304 = torch.ops.aten.convolution.default(relu__default_217, primals_1855, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_304 = torch.ops.aten.native_batch_norm.default(convolution_default_304, primals_1860, primals_1856, primals_1858, primals_1859, True, 0.1, 1e-05);  primals_1856 = None
        getitem_912 = native_batch_norm_default_304[0]
        getitem_913 = native_batch_norm_default_304[1]
        getitem_914 = native_batch_norm_default_304[2];  native_batch_norm_default_304 = None
        add_tensor_60 = torch.ops.aten.add.Tensor(add_tensor_59, getitem_912);  add_tensor_59 = getitem_912 = None
        add_tensor_61 = torch.ops.aten.add.Tensor(add_tensor_60, relu__default_225);  add_tensor_60 = None
        relu_default_41 = torch.ops.aten.relu.default(add_tensor_61);  add_tensor_61 = None
        convolution_default_305 = torch.ops.aten.convolution.default(relu_default_34, primals_58, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_305 = torch.ops.aten.native_batch_norm.default(convolution_default_305, primals_47, primals_43, primals_45, primals_46, True, 0.1, 1e-05);  primals_43 = None
        getitem_915 = native_batch_norm_default_305[0]
        getitem_916 = native_batch_norm_default_305[1]
        getitem_917 = native_batch_norm_default_305[2];  native_batch_norm_default_305 = None
        relu__default_226 = torch.ops.aten.relu_.default(getitem_915);  getitem_915 = None
        convolution_default_306 = torch.ops.aten.convolution.default(relu__default_226, primals_59, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_306 = torch.ops.aten.native_batch_norm.default(convolution_default_306, primals_52, primals_48, primals_50, primals_51, True, 0.1, 1e-05);  primals_48 = None
        getitem_918 = native_batch_norm_default_306[0]
        getitem_919 = native_batch_norm_default_306[1]
        getitem_920 = native_batch_norm_default_306[2];  native_batch_norm_default_306 = None
        relu__default_227 = torch.ops.aten.relu_.default(getitem_918);  getitem_918 = None
        convolution_default_307 = torch.ops.aten.convolution.default(relu__default_227, primals_60, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_307 = torch.ops.aten.native_batch_norm.default(convolution_default_307, primals_57, primals_53, primals_55, primals_56, True, 0.1, 1e-05);  primals_53 = None
        getitem_921 = native_batch_norm_default_307[0]
        getitem_922 = native_batch_norm_default_307[1]
        getitem_923 = native_batch_norm_default_307[2];  native_batch_norm_default_307 = None
        convolution_default_308 = torch.ops.aten.convolution.default(relu_default_34, primals_61, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_308 = torch.ops.aten.native_batch_norm.default(convolution_default_308, primals_66, primals_62, primals_64, primals_65, True, 0.1, 1e-05);  primals_62 = None
        getitem_924 = native_batch_norm_default_308[0]
        getitem_925 = native_batch_norm_default_308[1]
        getitem_926 = native_batch_norm_default_308[2];  native_batch_norm_default_308 = None
        add__tensor_417 = torch.ops.aten.add_.Tensor(getitem_921, getitem_924);  getitem_921 = getitem_924 = None
        relu__default_228 = torch.ops.aten.relu_.default(add__tensor_417);  add__tensor_417 = None
        convolution_default_309 = torch.ops.aten.convolution.default(relu_default_35, primals_82, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_309 = torch.ops.aten.native_batch_norm.default(convolution_default_309, primals_71, primals_67, primals_69, primals_70, True, 0.1, 1e-05);  primals_67 = None
        getitem_927 = native_batch_norm_default_309[0]
        getitem_928 = native_batch_norm_default_309[1]
        getitem_929 = native_batch_norm_default_309[2];  native_batch_norm_default_309 = None
        relu__default_229 = torch.ops.aten.relu_.default(getitem_927);  getitem_927 = None
        convolution_default_310 = torch.ops.aten.convolution.default(relu__default_229, primals_83, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_310 = torch.ops.aten.native_batch_norm.default(convolution_default_310, primals_76, primals_72, primals_74, primals_75, True, 0.1, 1e-05);  primals_72 = None
        getitem_930 = native_batch_norm_default_310[0]
        getitem_931 = native_batch_norm_default_310[1]
        getitem_932 = native_batch_norm_default_310[2];  native_batch_norm_default_310 = None
        relu__default_230 = torch.ops.aten.relu_.default(getitem_930);  getitem_930 = None
        convolution_default_311 = torch.ops.aten.convolution.default(relu__default_230, primals_84, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_311 = torch.ops.aten.native_batch_norm.default(convolution_default_311, primals_81, primals_77, primals_79, primals_80, True, 0.1, 1e-05);  primals_77 = None
        getitem_933 = native_batch_norm_default_311[0]
        getitem_934 = native_batch_norm_default_311[1]
        getitem_935 = native_batch_norm_default_311[2];  native_batch_norm_default_311 = None
        convolution_default_312 = torch.ops.aten.convolution.default(relu_default_35, primals_85, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_312 = torch.ops.aten.native_batch_norm.default(convolution_default_312, primals_90, primals_86, primals_88, primals_89, True, 0.1, 1e-05);  primals_86 = None
        getitem_936 = native_batch_norm_default_312[0]
        getitem_937 = native_batch_norm_default_312[1]
        getitem_938 = native_batch_norm_default_312[2];  native_batch_norm_default_312 = None
        add__tensor_422 = torch.ops.aten.add_.Tensor(getitem_933, getitem_936);  getitem_933 = getitem_936 = None
        relu__default_231 = torch.ops.aten.relu_.default(add__tensor_422);  add__tensor_422 = None
        convolution_default_313 = torch.ops.aten.convolution.default(relu__default_228, primals_16, primals_15, [2, 2], [1, 1], [1, 1], False, [0, 0], 1);  primals_15 = None
        native_batch_norm_default_313 = torch.ops.aten.native_batch_norm.default(convolution_default_313, primals_21, primals_17, primals_19, primals_20, True, 0.1, 1e-05);  primals_17 = None
        getitem_939 = native_batch_norm_default_313[0]
        getitem_940 = native_batch_norm_default_313[1]
        getitem_941 = native_batch_norm_default_313[2];  native_batch_norm_default_313 = None
        relu__default_232 = torch.ops.aten.relu_.default(getitem_939);  getitem_939 = None
        add_tensor_62 = torch.ops.aten.add.Tensor(relu__default_231, relu__default_232)
        convolution_default_314 = torch.ops.aten.convolution.default(relu_default_37, primals_106, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_314 = torch.ops.aten.native_batch_norm.default(convolution_default_314, primals_95, primals_91, primals_93, primals_94, True, 0.1, 1e-05);  primals_91 = None
        getitem_942 = native_batch_norm_default_314[0]
        getitem_943 = native_batch_norm_default_314[1]
        getitem_944 = native_batch_norm_default_314[2];  native_batch_norm_default_314 = None
        relu__default_233 = torch.ops.aten.relu_.default(getitem_942);  getitem_942 = None
        convolution_default_315 = torch.ops.aten.convolution.default(relu__default_233, primals_107, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_315 = torch.ops.aten.native_batch_norm.default(convolution_default_315, primals_100, primals_96, primals_98, primals_99, True, 0.1, 1e-05);  primals_96 = None
        getitem_945 = native_batch_norm_default_315[0]
        getitem_946 = native_batch_norm_default_315[1]
        getitem_947 = native_batch_norm_default_315[2];  native_batch_norm_default_315 = None
        relu__default_234 = torch.ops.aten.relu_.default(getitem_945);  getitem_945 = None
        convolution_default_316 = torch.ops.aten.convolution.default(relu__default_234, primals_108, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_316 = torch.ops.aten.native_batch_norm.default(convolution_default_316, primals_105, primals_101, primals_103, primals_104, True, 0.1, 1e-05);  primals_101 = None
        getitem_948 = native_batch_norm_default_316[0]
        getitem_949 = native_batch_norm_default_316[1]
        getitem_950 = native_batch_norm_default_316[2];  native_batch_norm_default_316 = None
        convolution_default_317 = torch.ops.aten.convolution.default(relu_default_37, primals_109, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_317 = torch.ops.aten.native_batch_norm.default(convolution_default_317, primals_114, primals_110, primals_112, primals_113, True, 0.1, 1e-05);  primals_110 = None
        getitem_951 = native_batch_norm_default_317[0]
        getitem_952 = native_batch_norm_default_317[1]
        getitem_953 = native_batch_norm_default_317[2];  native_batch_norm_default_317 = None
        add__tensor_428 = torch.ops.aten.add_.Tensor(getitem_948, getitem_951);  getitem_948 = getitem_951 = None
        relu__default_235 = torch.ops.aten.relu_.default(add__tensor_428);  add__tensor_428 = None
        convolution_default_318 = torch.ops.aten.convolution.default(add_tensor_62, primals_23, primals_22, [2, 2], [1, 1], [1, 1], False, [0, 0], 1);  primals_22 = None
        native_batch_norm_default_318 = torch.ops.aten.native_batch_norm.default(convolution_default_318, primals_28, primals_24, primals_26, primals_27, True, 0.1, 1e-05);  primals_24 = None
        getitem_954 = native_batch_norm_default_318[0]
        getitem_955 = native_batch_norm_default_318[1]
        getitem_956 = native_batch_norm_default_318[2];  native_batch_norm_default_318 = None
        relu__default_236 = torch.ops.aten.relu_.default(getitem_954);  getitem_954 = None
        add_tensor_63 = torch.ops.aten.add.Tensor(relu__default_235, relu__default_236)
        convolution_default_319 = torch.ops.aten.convolution.default(relu_default_41, primals_130, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_319 = torch.ops.aten.native_batch_norm.default(convolution_default_319, primals_119, primals_115, primals_117, primals_118, True, 0.1, 1e-05);  primals_115 = None
        getitem_957 = native_batch_norm_default_319[0]
        getitem_958 = native_batch_norm_default_319[1]
        getitem_959 = native_batch_norm_default_319[2];  native_batch_norm_default_319 = None
        relu__default_237 = torch.ops.aten.relu_.default(getitem_957);  getitem_957 = None
        convolution_default_320 = torch.ops.aten.convolution.default(relu__default_237, primals_131, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_320 = torch.ops.aten.native_batch_norm.default(convolution_default_320, primals_124, primals_120, primals_122, primals_123, True, 0.1, 1e-05);  primals_120 = None
        getitem_960 = native_batch_norm_default_320[0]
        getitem_961 = native_batch_norm_default_320[1]
        getitem_962 = native_batch_norm_default_320[2];  native_batch_norm_default_320 = None
        relu__default_238 = torch.ops.aten.relu_.default(getitem_960);  getitem_960 = None
        convolution_default_321 = torch.ops.aten.convolution.default(relu__default_238, primals_132, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_321 = torch.ops.aten.native_batch_norm.default(convolution_default_321, primals_129, primals_125, primals_127, primals_128, True, 0.1, 1e-05);  primals_125 = None
        getitem_963 = native_batch_norm_default_321[0]
        getitem_964 = native_batch_norm_default_321[1]
        getitem_965 = native_batch_norm_default_321[2];  native_batch_norm_default_321 = None
        convolution_default_322 = torch.ops.aten.convolution.default(relu_default_41, primals_133, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_322 = torch.ops.aten.native_batch_norm.default(convolution_default_322, primals_138, primals_134, primals_136, primals_137, True, 0.1, 1e-05);  primals_134 = None
        getitem_966 = native_batch_norm_default_322[0]
        getitem_967 = native_batch_norm_default_322[1]
        getitem_968 = native_batch_norm_default_322[2];  native_batch_norm_default_322 = None
        add__tensor_434 = torch.ops.aten.add_.Tensor(getitem_963, getitem_966);  getitem_963 = getitem_966 = None
        relu__default_239 = torch.ops.aten.relu_.default(add__tensor_434);  add__tensor_434 = None
        convolution_default_323 = torch.ops.aten.convolution.default(add_tensor_63, primals_30, primals_29, [2, 2], [1, 1], [1, 1], False, [0, 0], 1);  primals_29 = None
        native_batch_norm_default_323 = torch.ops.aten.native_batch_norm.default(convolution_default_323, primals_35, primals_31, primals_33, primals_34, True, 0.1, 1e-05);  primals_31 = None
        getitem_969 = native_batch_norm_default_323[0]
        getitem_970 = native_batch_norm_default_323[1]
        getitem_971 = native_batch_norm_default_323[2];  native_batch_norm_default_323 = None
        relu__default_240 = torch.ops.aten.relu_.default(getitem_969);  getitem_969 = None
        add_tensor_64 = torch.ops.aten.add.Tensor(relu__default_239, relu__default_240)
        convolution_default_324 = torch.ops.aten.convolution.default(add_tensor_64, primals_37, primals_36, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_36 = None
        native_batch_norm_default_324 = torch.ops.aten.native_batch_norm.default(convolution_default_324, primals_42, primals_38, primals_40, primals_41, True, 0.1, 1e-05);  primals_38 = None
        getitem_972 = native_batch_norm_default_324[0]
        getitem_973 = native_batch_norm_default_324[1]
        getitem_974 = native_batch_norm_default_324[2];  native_batch_norm_default_324 = None
        relu__default_241 = torch.ops.aten.relu_.default(getitem_972);  getitem_972 = None
        mean_dim = torch.ops.aten.mean.dim(relu__default_241, [-1, -2], True)
        view_default = torch.ops.aten.view.default(mean_dim, [128, 2048]);  mean_dim = None
        t_default = torch.ops.aten.t.default(primals_12);  primals_12 = None
        addmm_default = torch.ops.aten.addmm.default(primals_11, view_default, t_default);  primals_11 = None
        return [addmm_default, primals_1282, getitem_821, primals_383, primals_1280, primals_855, primals_389, getitem_820, primals_857, primals_170, primals_585, primals_1281, primals_1663, primals_384, primals_1276, relu__default_210, primals_1666, primals_1662, getitem_563, primals_1240, primals_1284, primals_591, getitem_562, primals_869, primals_1229, primals_1661, primals_588, primals_179, primals_867, primals_1660, primals_1289, primals_165, primals_584, convolution_default_274, primals_579, primals_581, relu__default_156, primals_171, primals_1232, primals_1287, primals_863, primals_177, primals_1657, getitem_824, primals_381, convolution_default_188, primals_856, primals_1283, getitem_823, primals_1656, primals_596, primals_862, primals_392, primals_1655, primals_380, primals_1277, primals_1654, primals_387, primals_852, primals_1233, primals_1292, relu__default_211, primals_175, primals_166, getitem_566, getitem_565, primals_180, primals_393, primals_396, primals_1234, primals_860, primals_1651, primals_167, primals_388, primals_1235, primals_586, convolution_default_275, relu__default_157, primals_1650, primals_172, primals_395, primals_178, primals_861, primals_1236, primals_592, primals_1241, primals_1649, primals_382, primals_1648, convolution_default_189, primals_593, primals_868, primals_1288, primals_597, primals_864, getitem_826, primals_580, primals_176, primals_1239, primals_394, primals_587, getitem_827, primals_716, primals_1565, primals_737, primals_1522, primals_915, primals_1463, primals_1523, primals_740, primals_924, getitem_607, getitem_608, relu__default_186, primals_1567, primals_639, primals_922, getitem_149, primals_1468, primals_1536, getitem_148, convolution_default_227, convolution_default_234, getitem_632, primals_720, primals_742, primals_640, primals_748, primals_911, primals_743, primals_1469, primals_732, getitem_65, primals_641, primals_928, primals_1470, getitem_64, primals_1570, primals_939, primals_1475, primals_921, primals_1471, primals_1530, primals_747, primals_927, primals_731, primals_934, primals_908, primals_1572, primals_644, primals_713, primals_936, primals_1528, primals_929, primals_1529, relu__default_20, primals_920, primals_1573, getitem_245, primals_645, convolution_default_203, primals_724, primals_736, primals_910, primals_718, convolution_default_50, getitem_611, relu__default_163, primals_646, primals_1474, relu__default_46, getitem_610, relu_default_26, primals_717, primals_741, primals_917, primals_1531, convolution_default_22, convolution_default_211, primals_940, relu__default_75, relu__default_180, primals_647, primals_912, getitem_152, primals_728, convolution_default_82, primals_1476, getitem_151, convolution_default_83, primals_652, getitem_635, primals_1477, primals_1576, relu_default_22, primals_648, primals_1525, primals_909, getitem_68, primals_1577, relu__default_72, getitem_67, primals_729, primals_1524, primals_1566, relu__default_47, primals_719, primals_932, primals_1480, primals_1540, primals_651, primals_1579, getitem_256, convolution_default_204, primals_1578, relu__default_164, primals_1481, getitem_706, primals_735, relu__default_21, primals_653, primals_725, getitem_707, primals_1482, convolution_default_51, primals_1465, getitem_212, primals_1537, primals_1464, primals_744, primals_933, primals_723, primals_935, primals_1564, primals_941, getitem_685, getitem_686, relu__default_188, convolution_default_236, primals_656, primals_1535, convolution_default_23, getitem_244, getitem_613, primals_1534, getitem_614, primals_657, primals_730, convolution_default_229, getitem_247, primals_712, primals_923, getitem_248, primals_916, primals_1582, convolution_default_84, convolution_default_256, primals_627, relu__default_148, primals_317, getitem_359, primals_41, primals_634, primals_977, convolution_default_173, primals_963, relu__default_141, primals_37, primals_320, getitem_871, primals_316, convolution_default_174, primals_30, primals_132, getitem_872, primals_632, relu__default_102, getitem_542, primals_131, primals_624, getitem_541, convolution_default_293, getitem_521, primals_309, convolution_default_120, primals_143, getitem_520, primals_35, primals_970, primals_136, primals_981, getitem_358, primals_26, primals_304, primals_628, primals_972, primals_969, getitem_875, primals_968, getitem_362, primals_635, primals_33, primals_971, getitem_361, relu__default_142, primals_311, primals_964, relu_default_34, relu__default_149, getitem_874, primals_130, primals_40, primals_138, primals_312, primals_142, primals_620, relu__default_103, convolution_default_181, primals_965, primals_622, convolution_default_292, convolution_default_121, getitem_544, primals_146, primals_980, getitem_523, getitem_545, primals_28, getitem_524, primals_34, primals_137, primals_310, primals_27, primals_322, primals_636, primals_305, getitem_364, primals_321, relu__default_150, primals_141, primals_621, primals_315, primals_975, primals_976, primals_308, relu__default_143, primals_633, primals_629, primals_133, primals_623, convolution_default_175, convolution_default_182, getitem_365, getitem_877, convolution_default_301, primals_79, primals_749, primals_82, primals_779, primals_780, primals_1378, primals_85, primals_754, primals_1371, primals_1380, primals_1383, primals_760, primals_752, primals_1367, getitem_311, getitem_383, primals_777, getitem_310, getitem_382, primals_768, primals_95, primals_1377, primals_765, primals_771, primals_764, primals_1368, relu__default_86, convolution_default_128, primals_753, primals_761, primals_1000, primals_778, convolution_default_104, getitem_386, relu_default_13, getitem_385, primals_83, primals_766, primals_89, primals_1372, primals_94, primals_1379, primals_81, getitem_314, getitem_313, primals_88, primals_1376, primals_755, primals_772, relu__default_87, primals_773, convolution_default_129, primals_759, primals_80, primals_756, primals_84, primals_776, primals_1373, convolution_default_105, primals_90, primals_93, primals_767, primals_1364, convolution_default_43, relu__default_238, primals_1137, primals_1139, getitem_800, relu__default_134, primals_1360, relu__default_4, getitem_799, primals_1348, getitem_128, relu__default_71, getitem_127, getitem_497, convolution_default_166, primals_285, relu__default_135, relu__default_239, primals_449, getitem_14, primals_1353, getitem_13, relu__default_203, primals_444, primals_1140, getitem_965, primals_268, primals_1136, primals_1356, primals_272, primals_1143, getitem_964, primals_436, relu__default_39, primals_437, getitem_500, getitem_499, convolution_default_267, primals_1354, primals_1349, primals_1128, primals_273, primals_1355, convolution_default_5, primals_269, primals_1366, primals_440, getitem_17, getitem_803, convolution_default_322, getitem_802, getitem_16, primals_448, getitem_131, getitem_968, getitem_130, getitem_967, primals_1127, primals_1352, convolution_default_167, primals_1133, relu__default_204, primals_443, relu__default_40, primals_281, primals_1131, primals_441, primals_1361, primals_442, primals_1126, primals_1365, convolution_default_6, convolution_default_268, primals_275, primals_1359, primals_274, primals_1138, convolution_default_323, primals_276, getitem_502, convolution_default_44, getitem_503, primals_279, primals_1132, primals_284, convolution_default_168, primals_447, relu__default_136, primals_280, getitem_19, getitem_805, getitem_946, primals_1187, getitem_659, getitem_941, primals_1192, primals_611, getitem_338, getitem_337, getitem_476, getitem_475, getitem_658, primals_1088, relu__default_172, primals_1072, relu__default_232, primals_473, convolution_default_220, primals_1186, primals_472, primals_1085, primals_480, primals_1073, relu__default_95, convolution_default_159, primals_478, primals_1084, convolution_default_113, convolution_default_314, primals_615, primals_485, primals_484, primals_1077, primals_1181, getitem_479, getitem_662, getitem_944, primals_1076, relu_default_17, getitem_478, getitem_661, getitem_943, primals_1196, getitem_341, primals_617, primals_1179, getitem_340, primals_603, primals_598, relu__default_173, primals_1188, relu__default_233, relu__default_96, primals_477, primals_479, primals_1184, convolution_default_315, primals_610, convolution_default_160, convolution_default_221, primals_600, primals_1185, convolution_default_114, primals_1180, primals_483, getitem_481, primals_616, primals_1193, primals_1079, getitem_664, convolution_default_222, primals_1080, primals_476, primals_1078, primals_604, primals_605, primals_1191, primals_608, primals_599, primals_1083, primals_1197, getitem_343, primals_471, getitem_482, getitem_665, getitem_947, getitem_344, primals_609, convolution_default_161, primals_612, relu__default_129, relu__default_234, convolution_default_316, convolution_default_151, primals_118, getitem_287, primals_123, relu__default_126, primals_112, convolution_default_152, getitem_286, primals_113, relu_default_8, getitem_107, getitem_106, getitem_455, convolution_default_96, getitem_454, primals_127, relu__default_32, primals_114, getitem_290, primals_128, getitem_289, relu__default_127, primals_129, convolution_default_36, convolution_default_97, getitem_110, getitem_109, getitem_457, relu_default_9, primals_122, relu__default_33, getitem_292, getitem_458, primals_124, getitem_293, primals_119, relu__default_128, convolution_default_37, convolution_default_153, primals_117, convolution_default_98, getitem_731, convolution_default_299, convolution_default_283, getitem_970, relu__default_219, getitem_730, getitem_779, getitem_896, getitem_895, convolution_default_284, primals_1144, convolution_default_244, getitem_86, getitem_778, getitem_85, getitem_920, getitem_919, relu__default_196, getitem_851, convolution_default_246, getitem_850, getitem_734, convolution_default_260, relu__default_227, convolution_default_245, getitem_733, relu__default_220, relu__default_27, getitem_899, convolution_default_307, convolution_default_29, getitem_782, getitem_898, getitem_781, getitem_89, getitem_88, getitem_923, relu_default_38, getitem_922, relu__default_197, getitem_853, relu__default_28, getitem_854, getitem_736, convolution_default_308, getitem_737, convolution_default_300, convolution_default_261, getitem_208, relu__default_221, convolution_default_30, getitem_209, convolution_default_285, getitem_901, primals_663, primals_672, primals_1776, relu__default_119, primals_660, convolution_default_144, primals_1774, relu__default_120, primals_564, primals_567, primals_1415, primals_1775, primals_668, primals_669, primals_1420, primals_1777, getitem_434, primals_573, primals_1404, getitem_433, primals_1414, primals_572, primals_1780, primals_1403, primals_574, primals_563, primals_664, primals_659, primals_1781, primals_1782, primals_658, primals_562, primals_1783, primals_1412, primals_1409, convolution_default_145, primals_1788, primals_1413, getitem_262, primals_575, primals_1407, primals_1786, getitem_436, primals_1787, primals_665, getitem_437, primals_569, primals_675, primals_1421, primals_1789, primals_671, primals_1419, relu__default_121, primals_1408, getitem_250, convolution_default_146, primals_568, primals_670, primals_1416, primals_576, primals_1792, getitem_176, getitem_754, getitem_200, relu_default_5, getitem_755, primals_1735, relu__default_55, getitem_199, primals_1858, primals_1732, convolution_default_59, relu_default_30, primals_1859, relu__default_56, primals_1733, primals_1860, primals_1734, primals_1861, convolution_default_252, convolution_default_67, getitem_179, getitem_178, getitem_758, getitem_263, getitem_757, primals_1864, primals_1738, getitem_203, primals_1865, getitem_202, primals_1739, primals_1866, primals_1172, primals_1740, primals_1169, relu_default_31, primals_1741, primals_1867, primals_1175, relu__default_57, convolution_default_60, primals_1167, primals_1162, convolution_default_253, primals_1870, primals_1750, primals_1744, relu_default_2, convolution_default_68, primals_1871, primals_1163, primals_1164, getitem_760, primals_1872, primals_1168, primals_1745, getitem_181, primals_1873, primals_1746, getitem_182, primals_1174, primals_1747, relu__default_77, primals_1173, getitem_761, convolution_default_61, convolution_default_88, primals_1876, primals_1176, convolution_default_254, relu__default_151, primals_1583, getitem_569, relu__default_12, primals_345, primals_1584, relu__default_212, relu__default_235, primals_154, convolution_default_14, getitem_410, getitem_548, getitem_568, primals_153, relu__default_13, convolution_default_137, primals_344, primals_1585, getitem_547, getitem_710, convolution_default_276, primals_346, relu__default_112, relu__default_213, getitem_709, primals_357, relu__default_158, getitem_593, primals_161, primals_356, convolution_default_190, getitem_592, getitem_44, primals_1588, getitem_43, getitem_830, primals_1589, getitem_829, primals_358, getitem_413, primals_157, primals_353, primals_147, primals_351, getitem_412, primals_1590, primals_348, convolution_default_183, primals_151, primals_1591, relu__default_189, getitem_596, convolution_default_198, getitem_572, convolution_default_237, relu__default_113, getitem_571, primals_347, getitem_551, relu_default_19, getitem_550, getitem_595, relu__default_58, primals_1594, getitem_713, primals_160, convolution_default_15, primals_155, getitem_712, primals_1595, relu__default_159, convolution_default_277, convolution_default_138, primals_1596, primals_148, relu__default_152, convolution_default_199, primals_1597, getitem_46, relu__default_190, getitem_47, convolution_default_191, getitem_832, convolution_default_184, getitem_833, getitem_415, primals_152, primals_1600, relu__default_114, relu__default_14, primals_156, getitem_416, convolution_default_238, primals_1601, relu__default_214, convolution_default_278, primals_1602, convolution_default_69, convolution_default_139, getitem_574, convolution_default_205, primals_162, primals_352, primals_1603, convolution_default_16, getitem_553, primals_1461, getitem_220, primals_892, primals_1751, convolution_default_122, getitem_637, primals_1462, getitem_317, relu__default_62, primals_1752, relu__default_104, primals_203, getitem_638, getitem_316, primals_198, primals_376, primals_372, primals_898, primals_1443, primals_4, primals_214, primals_1460, primals_1753, primals_8, relu__default_165, primals_891, relu__default_88, primals_896, primals_1756, primals_375, getitem_368, primals_1457, getitem_367, primals_212, convolution_default_213, primals_216, primals_1757, primals_900, primals_369, primals_185, convolution_default_106, primals_1758, primals_194, primals_202, primals_1444, primals_215, getitem_641, primals_1759, primals_1445, getitem_640, primals_1764, getitem_320, convolution_default_123, primals_3, getitem_319, primals_184, primals_211, primals_190, primals_899, getitem_370, primals_359, relu_default_10, primals_9, primals_377, primals_1762, relu__default_166, primals_1448, primals_903, primals_1763, primals_1452, relu__default_89, getitem_371, primals_368, getitem_218, primals_1765, primals_201, primals_904, primals_1449, convolution_default_214, primals_195, primals_196, primals_206, primals_371, primals_5, primals_1450, convolution_default_107, primals_193, primals_363, primals_183, primals_1451, primals_365, primals_370, primals_1768, convolution_default_124, primals_905, primals_360, primals_893, primals_188, convolution_default_73, primals_1771, getitem_643, primals_213, getitem_644, primals_208, primals_1455, primals_189, primals_1769, primals_197, primals_207, getitem_322, primals_897, primals_364, primals_1456, primals_1770, getitem_953, primals_428, primals_1645, getitem_155, primals_419, primals_1644, relu_default_23, primals_417, getitem_20, primals_1643, relu__default_5, convolution_default_72, primals_1642, convolution_default_7, convolution_default_52, getitem_154, convolution_default_8, relu__default_48, getitem_236, getitem_617, getitem_217, getitem_239, convolution_default_208, primals_1639, getitem_616, getitem_23, primals_432, primals_1638, getitem_22, primals_420, getitem_158, primals_1637, getitem_157, convolution_default_79, primals_1636, primals_430, primals_435, relu__default_6, primals_431, convolution_default_80, relu__default_49, convolution_default_206, primals_423, getitem_238, getitem_620, primals_1633, getitem_619, getitem_215, relu__default_68, convolution_default_53, relu__default_61, primals_1632, primals_418, primals_1630, relu_default_24, getitem_25, primals_416, getitem_26, primals_425, primals_560, primals_1627, primals_561, primals_1631, convolution_default_54, convolution_default_9, convolution_default_207, getitem_160, getitem_161, primals_1626, relu__default_50, relu__default_7, primals_429, primals_424, primals_1625, getitem_388, primals_1709, getitem_133, getitem_806, primals_46, primals_694, getitem_971, getitem_389, primals_1710, getitem_134, primals_696, primals_1224, primals_1210, primals_1711, getitem_527, primals_51, primals_692, convolution_default_269, primals_1228, relu__default_105, relu__default_41, getitem_526, primals_693, primals_1269, relu__default_205, primals_1209, relu__default_240, primals_57, convolution_default_130, primals_1208, convolution_default_45, getitem_950, primals_1270, getitem_949, primals_695, getitem_211, primals_680, primals_704, primals_1271, add_tensor_64, primals_1199, relu__default_144, primals_1714, convolution_default_324, primals_45, getitem_809, primals_1715, primals_1223, getitem_392, getitem_808, primals_1716, getitem_137, getitem_391, getitem_136, convolution_default_176, primals_1717, primals_58, primals_1220, primals_1260, primals_1205, primals_1265, getitem_974, getitem_973, primals_688, convolution_default_317, relu__default_206, primals_1211, relu__default_106, relu__default_42, primals_1215, primals_55, primals_677, getitem_530, getitem_952, primals_1217, primals_42, primals_684, primals_1212, primals_1275, primals_50, primals_1720, getitem_529, relu__default_241, primals_56, primals_689, convolution_default_270, primals_52, primals_687, primals_701, primals_708, convolution_default_131, primals_1264, primals_1721, convolution_default_46, relu__default_145, primals_1227, primals_706, primals_1722, primals_700, primals_1263, primals_1272, view_default, primals_1723, primals_682, primals_1200, getitem_394, getitem_139, convolution_default_318, getitem_811, primals_47, convolution_default_47, primals_707, convolution_default_177, relu__default_207, add_tensor_63, primals_1726, getitem_812, primals_681, primals_699, primals_1198, primals_1222, primals_683, primals_676, primals_1727, primals_1221, getitem_395, primals_1216, getitem_140, convolution_default_271, primals_705, primals_1728, t_default, primals_1203, primals_1268, primals_711, primals_1204, primals_1729, relu__default_107, convolution_default_132, getitem_92, getitem_91, primals_1546, getitem_506, getitem_505, getitem_689, getitem_688, primals_1543, relu__default_29, primals_994, primals_1542, primals_1547, convolution_default_31, relu__default_182, primals_987, primals_1553, relu__default_137, getitem_95, convolution_default_85, convolution_default_230, primals_984, primals_1558, getitem_94, primals_1554, convolution_default_169, primals_1552, getitem_235, primals_992, relu__default_30, getitem_509, getitem_692, getitem_508, getitem_691, primals_988, primals_1549, primals_1548, primals_993, primals_1555, convolution_default_32, relu__default_138, relu__default_183, primals_983, primals_1560, primals_982, convolution_default_170, convolution_default_231, primals_1561, getitem_97, primals_995, primals_996, primals_1559, getitem_98, primals_999, primals_1541, relu__default_69, primals_989, relu__default_34, getitem_112, getitem_113, convolution_default_78, relu__default_73, getitem_233, convolution_default_38, getitem_116, getitem_115, relu__default_67, relu__default_35, convolution_default_70, convolution_default_39, getitem_232, getitem_118, getitem_119, primals_1341, convolution_default_156, primals_839, relu__default_174, primals_19, primals_1060, relu__default_97, primals_1059, getitem_296, convolution_default_115, getitem_461, primals_1331, getitem_460, relu__default_98, primals_1071, primals_23, primals_838, getitem_295, primals_837, primals_848, getitem_668, primals_836, getitem_260, getitem_667, primals_1332, relu__default_81, getitem_347, primals_1054, getitem_346, getitem_836, primals_1061, primals_1337, relu__default_76, primals_840, convolution_default_99, convolution_default_154, getitem_463, primals_1055, primals_851, relu_default_14, primals_1347, primals_14, primals_1571, primals_1342, convolution_default_87, getitem_464, relu__default_175, primals_1067, getitem_299, getitem_259, primals_20, getitem_298, primals_1343, primals_1335, convolution_default_223, primals_1056, primals_850, primals_845, convolution_default_116, primals_1064, convolution_default_155, primals_10, primals_1066, getitem_671, relu__default_82, getitem_670, primals_1336, getitem_349, primals_1065, getitem_350, primals_16, primals_1344, relu__default_176, convolution_default_100, primals_1340, relu__default_99, primals_1068, convolution_default_117, primals_1053, getitem_466, convolution_default_224, primals_13, primals_844, primals_21, primals_1330, primals_849, getitem_467, primals_843, primals_1919, convolution_default_286, getitem_902, getitem_926, primals_454, relu__default_122, primals_461, primals_1920, getitem_878, primals_1921, getitem_857, relu_default_39, getitem_925, getitem_440, getitem_856, relu__default_228, convolution_default_309, getitem_439, primals_460, getitem_485, primals_1924, getitem_484, primals_452, getitem_881, relu__default_222, getitem_880, getitem_905, primals_1925, convolution_default_304, getitem_904, getitem_929, relu__default_130, primals_467, getitem_928, primals_1926, primals_465, primals_466, primals_1927, convolution_default_147, primals_464, primals_1932, convolution_default_162, getitem_884, convolution_default_294, relu__default_229, getitem_860, getitem_859, getitem_443, primals_1930, getitem_442, relu_default_35, getitem_883, convolution_default_302, primals_1931, getitem_488, convolution_default_310, getitem_487, relu__default_223, primals_455, primals_453, primals_1933, getitem_907, relu__default_123, primals_456, getitem_908, convolution_default_295, relu__default_131, convolution_default_287, relu_default_40, primals_1936, convolution_default_148, primals_944, convolution_default_311, getitem_931, primals_468, primals_1939, getitem_932, convolution_default_163, primals_459, primals_1937, convolution_default_303, relu__default_230, primals_1938, primals_1835, getitem_784, primals_512, primals_509, getitem_71, primals_1836, getitem_785, getitem_70, primals_1837, getitem_266, primals_513, getitem_265, relu__default_198, convolution_default_24, convolution_default_262, relu__default_22, primals_508, primals_1840, primals_507, primals_1841, getitem_788, getitem_787, primals_1842, relu__default_78, primals_516, primals_1843, convolution_default_89, primals_514, getitem_74, primals_521, getitem_73, primals_520, relu__default_199, primals_515, getitem_269, primals_1846, getitem_268, primals_1847, relu__default_23, primals_1848, convolution_default_263, primals_1849, relu__default_79, primals_1854, convolution_default_25, primals_519, getitem_790, primals_1855, convolution_default_90, primals_1852, primals_524, getitem_791, primals_1853, getitem_76, convolution_default_264, relu__default_200, primals_1025, primals_1031, convolution_default_62, primals_1020, getitem_185, getitem_764, getitem_184, getitem_419, primals_1032, getitem_418, getitem_763, getitem_253, relu_default_32, relu__default_115, primals_1023, convolution_default_255, convolution_default_140, getitem_188, primals_1018, getitem_767, getitem_187, getitem_766, getitem_422, getitem_421, primals_1017, primals_1019, primals_1029, convolution_default_63, getitem_251, relu__default_116, relu_default_3, primals_1035, primals_1030, primals_1024, convolution_default_280, convolution_default_64, convolution_default_141, getitem_769, primals_1028, getitem_190, getitem_770, getitem_191, getitem_575, primals_1793, getitem_323, getitem_623, getitem_622, convolution_default_215, getitem_715, getitem_740, primals_1794, getitem_739, relu__default_167, getitem_50, relu__default_160, getitem_716, primals_1795, convolution_default_108, primals_1834, convolution_default_192, primals_1831, relu__default_90, convolution_default_216, getitem_49, relu__default_161, getitem_835, primals_1830, relu__default_191, primals_1829, relu__default_15, primals_1798, getitem_647, convolution_default_239, primals_1828, getitem_646, getitem_578, getitem_626, primals_1799, relu_default_25, getitem_326, getitem_577, getitem_625, getitem_325, primals_1800, convolution_default_17, primals_1801, getitem_719, convolution_default_247, relu__default_168, getitem_721, relu__default_215, getitem_718, primals_1825, getitem_743, convolution_default_279, relu__default_91, convolution_default_257, primals_1824, getitem_742, primals_1823, getitem_53, getitem_52, primals_1804, relu__default_192, getitem_839, convolution_default_209, getitem_838, primals_1805, convolution_default_109, convolution_default_193, relu_default_28, primals_1806, relu__default_16, primals_1807, primals_1819, convolution_default_240, convolution_default_195, getitem_649, relu__default_216, convolution_default_217, getitem_650, getitem_580, getitem_628, convolution_default_248, primals_1822, primals_1818, convolution_default_18, getitem_581, getitem_328, getitem_629, primals_1810, relu__default_92, primals_1817, getitem_329, relu__default_169, primals_1811, primals_1816, getitem_722, relu__default_162, primals_1812, convolution_default_110, convolution_default_194, convolution_default_210, getitem_745, primals_1813, primals_801, primals_1500, getitem_374, primals_1493, primals_804, getitem_373, primals_827, primals_1900, primals_831, primals_828, primals_1499, primals_1494, primals_1487, primals_1156, primals_1901, relu_default_11, getitem_164, primals_1902, getitem_163, primals_1501, primals_821, primals_1903, primals_832, primals_826, primals_800, primals_1498, relu__default_51, getitem_377, primals_1486, primals_1148, convolution_default_125, getitem_376, primals_1149, primals_1906, primals_812, primals_1907, convolution_default_55, primals_833, primals_1483, primals_1152, primals_1908, relu__default_60, convolution_default_126, primals_820, primals_1909, primals_802, primals_808, primals_1495, getitem_167, getitem_166, primals_1155, primals_825, primals_1150, primals_1157, primals_1489, primals_1912, primals_814, primals_803, getitem_379, primals_1913, relu__default_52, primals_1145, primals_813, primals_819, primals_816, primals_1914, primals_1161, primals_1151, primals_1160, primals_1915, primals_824, primals_1488, primals_807, primals_809, convolution_default_56, convolution_default_127, primals_815, getitem_380, primals_1492, primals_1918, relu_default_12, getitem_598, primals_1506, getitem_554, getitem_695, getitem_599, getitem_694, primals_291, primals_886, primals_1505, primals_1308, primals_1504, convolution_default_185, primals_292, relu_default_20, relu__default_153, getitem_680, getitem_398, relu__default_184, primals_876, primals_1301, getitem_397, convolution_default_200, convolution_default_232, primals_300, primals_1300, primals_879, primals_884, primals_296, primals_286, primals_874, getitem_557, primals_1507, getitem_602, getitem_556, primals_1304, getitem_601, primals_1305, primals_1519, primals_287, primals_1518, getitem_698, relu__default_108, getitem_697, primals_293, primals_1517, primals_1293, relu__default_154, convolution_default_201, convolution_default_133, primals_1306, primals_298, primals_1516, primals_299, primals_881, primals_1299, primals_873, relu__default_185, getitem_401, convolution_default_186, primals_1294, primals_887, getitem_400, convolution_default_202, getitem_604, convolution_default_233, primals_1511, primals_872, getitem_605, primals_1296, primals_880, relu__default_109, primals_1510, primals_297, relu__default_155, relu__default_179, primals_875, primals_1307, primals_1295, getitem_559, primals_1513, getitem_560, primals_888, primals_1512, primals_885, convolution_default_134, convolution_default_187, primals_303, getitem_700, getitem_701, primals_288, primals_1957, getitem_511, primals_1942, getitem_29, getitem_28, relu__default_139, primals_1943, primals_1944, primals_1041, getitem_512, primals_1036, primals_1945, primals_1040, relu__default_8, convolution_default_171, primals_1044, convolution_default_10, primals_1042, getitem_515, primals_1948, getitem_514, primals_1949, primals_1049, primals_1950, getitem_32, primals_1951, relu__default_140, getitem_31, primals_1043, primals_1037, getitem_683, primals_1048, convolution_default_172, primals_1954, relu__default_9, relu__default_187, primals_1047, primals_1955, primals_1956, getitem_682, convolution_default_11, primals_1052, getitem_517, getitem_518, relu__default_43, getitem_301, convolution_default_40, getitem_532, getitem_302, getitem_226, primals_1007, relu__default_36, primals_100, getitem_533, primals_1006, convolution_default_92, convolution_default_76, primals_1005, convolution_default_41, relu__default_83, relu__default_80, relu__default_146, convolution_default_101, primals_1001, primals_109, getitem_143, convolution_default_178, getitem_272, primals_99, getitem_142, getitem_227, getitem_122, primals_1016, getitem_121, convolution_default_91, primals_107, getitem_271, primals_103, getitem_305, primals_98, primals_1011, getitem_304, getitem_275, getitem_536, primals_1004, getitem_535, relu__default_37, getitem_274, getitem_2, getitem_704, relu__default_44, primals_1013, relu__default_84, getitem_1, convolution_default_48, relu__default_147, primals_108, getitem_145, getitem_703, relu__default, relu_default_6, primals_104, convolution_default_102, getitem_205, convolution_default_179, getitem_124, primals_1012, convolution_default_42, getitem_125, getitem_146, getitem_307, relu__default_65, convolution_default_1, convolution_default_93, getitem_538, convolution_default_180, primals_105, primals_106, relu__default_38, relu__default_45, getitem_631, getitem_277, getitem_278, primals_1008, getitem_308, getitem_214, convolution_default_49, getitem_539, getitem_4, convolution_default_103, relu__default_85, primals_789, getitem_862, primals_783, primals_75, primals_221, getitem_674, getitem_863, primals_239, getitem_241, getitem_673, primals_1690, getitem_353, primals_792, convolution_default_228, getitem_352, primals_220, relu__default_224, primals_225, primals_1691, primals_244, getitem_815, getitem_814, convolution_default_288, primals_248, primals_249, primals_1692, primals_69, primals_788, primals_1693, primals_784, primals_71, getitem_230, relu__default_177, relu__default_208, relu__default_70, getitem_866, primals_59, convolution_default_225, getitem_865, primals_61, relu__default_100, primals_1696, primals_70, primals_796, convolution_default_272, convolution_default_118, primals_1697, primals_243, primals_791, primals_231, getitem_677, primals_1698, relu__default_225, primals_228, primals_236, getitem_676, primals_74, primals_785, primals_1699, getitem_356, primals_226, getitem_355, getitem_818, primals_76, convolution_default_77, convolution_default_81, getitem_817, relu__default_178, convolution_default_289, primals_224, primals_1702, relu__default_101, primals_64, primals_245, relu__default_209, primals_1703, getitem_229, convolution_default_226, getitem_868, primals_1704, primals_66, primals_237, primals_797, primals_232, primals_790, primals_1705, primals_238, convolution_default_119, primals_233, convolution_default_291, primals_795, relu__default_66, convolution_default_273, primals_240, primals_65, primals_60, getitem_242, getitem_869, primals_227, primals_1708, getitem_679, convolution_default_290, primals_219, getitem_445, getitem_491, convolution_default_235, primals_525, primals_536, getitem_446, getitem_490, getitem_910, getitem_911, relu__default_231, primals_527, getitem_935, convolution_default_164, relu__default_132, getitem_934, relu__default_124, convolution_default_149, primals_533, getitem_914, relu_default_41, primals_539, getitem_913, getitem_449, getitem_448, primals_537, convolution_default_312, primals_528, getitem_494, getitem_493, getitem_938, getitem_937, relu__default_125, primals_532, relu__default_181, relu__default_133, convolution_default_305, convolution_default_150, primals_538, primals_526, convolution_default_313, primals_531, convolution_default_165, getitem_916, primals_540, getitem_451, add_tensor_62, primals_323, getitem_917, getitem_452, getitem_496, getitem_940, convolution_default_306, relu__default_226, getitem_634, primals_1119, primals_1109, primals_1323, getitem_956, relu__default_24, relu_default_15, primals_1384, primals_1606, getitem_77, convolution_default_26, relu__default_236, primals_1113, relu__default_25, getitem_955, primals_1607, primals_1320, primals_1124, primals_1325, getitem_794, primals_1319, primals_1401, primals_1608, getitem_470, getitem_793, getitem_469, primals_1609, convolution_default_319, primals_1385, getitem_80, convolution_default_86, getitem_79, primals_1114, getitem_254, getitem_959, primals_1395, primals_1612, getitem_958, primals_1613, relu__default_201, primals_1614, primals_1112, convolution_default_265, primals_1615, relu__default_237, primals_1312, primals_1328, primals_1396, primals_1116, primals_1390, getitem_473, primals_1316, primals_1392, convolution_default_27, primals_1318, convolution_default_157, getitem_797, primals_1125, primals_1120, getitem_472, primals_1313, primals_1115, primals_1324, getitem_796, primals_1618, convolution_default_320, primals_1619, primals_1121, primals_1317, primals_1391, primals_1620, relu_default_16, relu__default_202, getitem_961, getitem_82, primals_1621, convolution_default_321, primals_1400, primals_1397, getitem_83, primals_1402, getitem_257, primals_1389, primals_1329, convolution_default_28, convolution_default_266, primals_1388, convolution_default_158, relu__default_26, primals_1311, getitem_962, primals_1624, getitem_425, getitem_886, getitem_424, convolution_default_33, relu__default_31, relu__default_59, relu_default_36, relu__default_117, convolution_default_142, primals_332, getitem_887, getitem_101, relu_default, convolution_default_296, getitem_100, convolution_default_212, primals_328, convolution_default_298, primals_336, convolution_default_34, getitem_890, getitem_428, getitem_889, getitem_427, relu_default_37, relu__default_118, convolution_default_297, primals_324, primals_329, primals_335, primals_339, convolution_default_143, primals_334, getitem_103, primals_340, primals_327, convolution_default_35, getitem_104, primals_333, getitem_892, getitem_893, primals_341, getitem_430, relu_default_1, getitem_431, primals_951, primals_1089, getitem_5, primals_252, primals_1097, primals_946, primals_1686, convolution_default_218, primals_250, convolution_default_241, relu_default_33, primals_263, primals_1685, relu__default_193, primals_549, primals_256, relu__default_1, getitem_583, primals_1684, getitem_584, getitem_653, primals_952, convolution_default_2, getitem_652, primals_1428, convolution_default_197, getitem_206, primals_545, primals_557, primals_1091, primals_556, primals_543, primals_945, primals_1102, primals_1431, getitem_725, primals_1104, primals_1432, getitem_724, primals_255, primals_555, relu__default_170, primals_1681, primals_1433, getitem_8, getitem_587, primals_1680, getitem_7, primals_1092, primals_1679, relu__default_194, primals_1678, relu_default_18, getitem_586, primals_551, primals_1436, relu_default_27, primals_960, primals_1090, relu__default_2, convolution_default_242, primals_1437, getitem_656, convolution_default_258, primals_1675, primals_956, getitem_655, getitem_727, primals_1438, primals_1095, convolution_default_243, primals_267, convolution_default_196, primals_550, primals_1674, convolution_default_3, primals_1439, primals_953, primals_544, getitem_728, primals_1424, primals_1687, primals_264, relu__default_171, primals_1101, primals_1673, getitem_775, primals_1096, primals_947, getitem_776, primals_262, primals_1440, primals_1672, primals_1103, primals_261, primals_958, primals_1427, convolution_default_219, primals_1108, relu__default_195, primals_959, relu__default_3, primals_257, getitem_10, primals_251, primals_1669, getitem_11, primals_1426, getitem_589, primals_260, primals_1425, primals_1668, primals_548, primals_957, primals_1107, getitem_590, convolution_default_259, primals_552, primals_948, primals_1667, primals_1100, convolution_default_4, getitem_746, primals_1877, getitem_841, getitem_170, primals_1878, getitem_842, convolution_default, getitem_169, primals_399, primals_1258, primals_1245, primals_1879, convolution_default_249, getitem_332, convolution_default_57, getitem_331, relu__default_53, relu__default_217, getitem_749, getitem_748, getitem_194, convolution_default_281, primals_407, primals_1244, primals_1882, primals_406, primals_1252, getitem_193, relu__default_93, primals_1883, primals_1884, getitem_845, primals_401, primals_1885, getitem_847, convolution_default_111, convolution_default_250, getitem_844, relu_default_4, primals_411, getitem_173, getitem_172, primals_400, getitem_752, primals_1248, primals_1253, primals_1888, getitem_751, relu__default_218, primals_413, convolution_default_65, getitem_335, primals_1889, relu__default_54, getitem_334, primals_1894, primals_408, convolution_default_251, convolution_default_282, primals_1890, primals_1259, convolution_default_71, relu__default_94, getitem_196, primals_404, primals_1257, primals_1891, convolution_default_58, primals_412, primals_1247, getitem_197, relu_default_29, primals_1256, primals_1246, convolution_default_66, convolution_default_112, primals_1895, getitem_848, primals_405, primals_1896, primals_1251, getitem_175, primals_1897, relu__default_10, getitem_55, primals_501, getitem_34, getitem_56, primals_500, getitem_404, getitem_403, primals_489, getitem_35, relu__default_64, relu__default_63, convolution_default_19, getitem_281, getitem_773, relu__default_17, convolution_default_94, getitem_280, relu__default_110, primals_492, convolution_default_12, getitem_772, relu_default_7, getitem_59, convolution_default_135, getitem_58, getitem_223, getitem_38, primals_502, getitem_37, primals_488, getitem_407, primals_503, primals_496, convolution_default_74, relu__default_18, relu__default_74, getitem_284, getitem_406, getitem_283, convolution_default_75, relu__default_11, relu__default_111, convolution_default_20, primals_491, convolution_default_95, convolution_default_13, primals_504, convolution_default_136, primals_490, convolution_default_21, primals_495, getitem_224, getitem_40, getitem_61, getitem_62, getitem_41, relu__default_19, primals_497, relu_default_21, getitem_409, getitem_221]
        
