
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/pnasnet5large/pnasnet5large_joint_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339, primals_340, primals_341, primals_342, primals_343, primals_344, primals_345, primals_346, primals_347, primals_348, primals_349, primals_350, primals_351, primals_352, primals_353, primals_354, primals_355, primals_356, primals_357, primals_358, primals_359, primals_360, primals_361, primals_362, primals_363, primals_364, primals_365, primals_366, primals_367, primals_368, primals_369, primals_370, primals_371, primals_372, primals_373, primals_374, primals_375, primals_376, primals_377, primals_378, primals_379, primals_380, primals_381, primals_382, primals_383, primals_384, primals_385, primals_386, primals_387, primals_388, primals_389, primals_390, primals_391, primals_392, primals_393, primals_394, primals_395, primals_396, primals_397, primals_398, primals_399, primals_400, primals_401, primals_402, primals_403, primals_404, primals_405, primals_406, primals_407, primals_408, primals_409, primals_410, primals_411, primals_412, primals_413, primals_414, primals_415, primals_416, primals_417, primals_418, primals_419, primals_420, primals_421, primals_422, primals_423, primals_424, primals_425, primals_426, primals_427, primals_428, primals_429, primals_430, primals_431, primals_432, primals_433, primals_434, primals_435, primals_436, primals_437, primals_438, primals_439, primals_440, primals_441, primals_442, primals_443, primals_444, primals_445, primals_446, primals_447, primals_448, primals_449, primals_450, primals_451, primals_452, primals_453, primals_454, primals_455, primals_456, primals_457, primals_458, primals_459, primals_460, primals_461, primals_462, primals_463, primals_464, primals_465, primals_466, primals_467, primals_468, primals_469, primals_470, primals_471, primals_472, primals_473, primals_474, primals_475, primals_476, primals_477, primals_478, primals_479, primals_480, primals_481, primals_482, primals_483, primals_484, primals_485, primals_486, primals_487, primals_488, primals_489, primals_490, primals_491, primals_492, primals_493, primals_494, primals_495, primals_496, primals_497, primals_498, primals_499, primals_500, primals_501, primals_502, primals_503, primals_504, primals_505, primals_506, primals_507, primals_508, primals_509, primals_510, primals_511, primals_512, primals_513, primals_514, primals_515, primals_516, primals_517, primals_518, primals_519, primals_520, primals_521, primals_522, primals_523, primals_524, primals_525, primals_526, primals_527, primals_528, primals_529, primals_530, primals_531, primals_532, primals_533, primals_534, primals_535, primals_536, primals_537, primals_538, primals_539, primals_540, primals_541, primals_542, primals_543, primals_544, primals_545, primals_546, primals_547, primals_548, primals_549, primals_550, primals_551, primals_552, primals_553, primals_554, primals_555, primals_556, primals_557, primals_558, primals_559, primals_560, primals_561, primals_562, primals_563, primals_564, primals_565, primals_566, primals_567, primals_568, primals_569, primals_570, primals_571, primals_572, primals_573, primals_574, primals_575, primals_576, primals_577, primals_578, primals_579, primals_580, primals_581, primals_582, primals_583, primals_584, primals_585, primals_586, primals_587, primals_588, primals_589, primals_590, primals_591, primals_592, primals_593, primals_594, primals_595, primals_596, primals_597, primals_598, primals_599, primals_600, primals_601, primals_602, primals_603, primals_604, primals_605, primals_606, primals_607, primals_608, primals_609, primals_610, primals_611, primals_612, primals_613, primals_614, primals_615, primals_616, primals_617, primals_618, primals_619, primals_620, primals_621, primals_622, primals_623, primals_624, primals_625, primals_626, primals_627, primals_628, primals_629, primals_630, primals_631, primals_632, primals_633, primals_634, primals_635, primals_636, primals_637, primals_638, primals_639, primals_640, primals_641, primals_642, primals_643, primals_644, primals_645, primals_646, primals_647, primals_648, primals_649, primals_650, primals_651, primals_652, primals_653, primals_654, primals_655, primals_656, primals_657, primals_658, primals_659, primals_660, primals_661, primals_662, primals_663, primals_664, primals_665, primals_666, primals_667, primals_668, primals_669, primals_670, primals_671, primals_672, primals_673, primals_674, primals_675, primals_676, primals_677, primals_678, primals_679, primals_680, primals_681, primals_682, primals_683, primals_684, primals_685, primals_686, primals_687, primals_688, primals_689, primals_690, primals_691, primals_692, primals_693, primals_694, primals_695, primals_696, primals_697, primals_698, primals_699, primals_700, primals_701, primals_702, primals_703, primals_704, primals_705, primals_706, primals_707, primals_708, primals_709, primals_710, primals_711, primals_712, primals_713, primals_714, primals_715, primals_716, primals_717, primals_718, primals_719, primals_720, primals_721, primals_722, primals_723, primals_724, primals_725, primals_726, primals_727, primals_728, primals_729, primals_730, primals_731, primals_732, primals_733, primals_734, primals_735, primals_736, primals_737, primals_738, primals_739, primals_740, primals_741, primals_742, primals_743, primals_744, primals_745, primals_746, primals_747, primals_748, primals_749, primals_750, primals_751, primals_752, primals_753, primals_754, primals_755, primals_756, primals_757, primals_758, primals_759, primals_760, primals_761, primals_762, primals_763, primals_764, primals_765, primals_766, primals_767, primals_768, primals_769, primals_770, primals_771, primals_772, primals_773, primals_774, primals_775, primals_776, primals_777, primals_778, primals_779, primals_780, primals_781, primals_782, primals_783, primals_784, primals_785, primals_786, primals_787, primals_788, primals_789, primals_790, primals_791, primals_792, primals_793, primals_794, primals_795, primals_796, primals_797, primals_798, primals_799, primals_800, primals_801, primals_802, primals_803, primals_804, primals_805, primals_806, primals_807, primals_808, primals_809, primals_810, primals_811, primals_812, primals_813, primals_814, primals_815, primals_816, primals_817, primals_818, primals_819, primals_820, primals_821, primals_822, primals_823, primals_824, primals_825, primals_826, primals_827, primals_828, primals_829, primals_830, primals_831, primals_832, primals_833, primals_834, primals_835, primals_836, primals_837, primals_838, primals_839, primals_840, primals_841, primals_842, primals_843, primals_844, primals_845, primals_846, primals_847, primals_848, primals_849, primals_850, primals_851, primals_852, primals_853, primals_854, primals_855, primals_856, primals_857, primals_858, primals_859, primals_860, primals_861, primals_862, primals_863, primals_864, primals_865, primals_866, primals_867, primals_868, primals_869, primals_870, primals_871, primals_872, primals_873, primals_874, primals_875, primals_876, primals_877, primals_878, primals_879, primals_880, primals_881, primals_882, primals_883, primals_884, primals_885, primals_886, primals_887, primals_888, primals_889, primals_890, primals_891, primals_892, primals_893, primals_894, primals_895, primals_896, primals_897, primals_898, primals_899, primals_900, primals_901, primals_902, primals_903, primals_904, primals_905, primals_906, primals_907, primals_908, primals_909, primals_910, primals_911, primals_912, primals_913, primals_914, primals_915, primals_916, primals_917, primals_918, primals_919, primals_920, primals_921, primals_922, primals_923, primals_924, primals_925, primals_926, primals_927, primals_928, primals_929, primals_930, primals_931, primals_932, primals_933, primals_934, primals_935, primals_936, primals_937, primals_938, primals_939, primals_940, primals_941, primals_942, primals_943, primals_944, primals_945, primals_946, primals_947, primals_948, primals_949, primals_950, primals_951, primals_952, primals_953, primals_954, primals_955, primals_956, primals_957, primals_958, primals_959, primals_960, primals_961, primals_962, primals_963, primals_964, primals_965, primals_966, primals_967, primals_968, primals_969, primals_970, primals_971, primals_972, primals_973, primals_974, primals_975, primals_976, primals_977, primals_978, primals_979, primals_980, primals_981, primals_982, primals_983, primals_984, primals_985, primals_986, primals_987, primals_988, primals_989, primals_990, primals_991, primals_992, primals_993, primals_994, primals_995, primals_996, primals_997, primals_998, primals_999, primals_1000, primals_1001, primals_1002, primals_1003, primals_1004, primals_1005, primals_1006, primals_1007, primals_1008, primals_1009, primals_1010, primals_1011, primals_1012, primals_1013, primals_1014, primals_1015, primals_1016, primals_1017, primals_1018, primals_1019, primals_1020, primals_1021, primals_1022, primals_1023, primals_1024, primals_1025, primals_1026, primals_1027, primals_1028, primals_1029, primals_1030, primals_1031, primals_1032, primals_1033, primals_1034, primals_1035, primals_1036, primals_1037, primals_1038, primals_1039, primals_1040, primals_1041, primals_1042, primals_1043, primals_1044, primals_1045, primals_1046, primals_1047, primals_1048, primals_1049, primals_1050, primals_1051, primals_1052, primals_1053, primals_1054, primals_1055, primals_1056, primals_1057, primals_1058, primals_1059, primals_1060, primals_1061, primals_1062, primals_1063, primals_1064, primals_1065, primals_1066, primals_1067, primals_1068, primals_1069, primals_1070, primals_1071, primals_1072, primals_1073, primals_1074, primals_1075, primals_1076, primals_1077, primals_1078, primals_1079, primals_1080, primals_1081, primals_1082, primals_1083, primals_1084, primals_1085, primals_1086, primals_1087, primals_1088, primals_1089, primals_1090, primals_1091, primals_1092, primals_1093, primals_1094, primals_1095, primals_1096, primals_1097, primals_1098, primals_1099, primals_1100, primals_1101, primals_1102, primals_1103, primals_1104, primals_1105, primals_1106, primals_1107, primals_1108, primals_1109, primals_1110, primals_1111, primals_1112, primals_1113, primals_1114, primals_1115, primals_1116, primals_1117, primals_1118, primals_1119, primals_1120, primals_1121, primals_1122, primals_1123, primals_1124, primals_1125, primals_1126, primals_1127, primals_1128, primals_1129, primals_1130, primals_1131, primals_1132, primals_1133, primals_1134, primals_1135, primals_1136, primals_1137, primals_1138, primals_1139, primals_1140, primals_1141, primals_1142, primals_1143, primals_1144, primals_1145, primals_1146, primals_1147, primals_1148, primals_1149, primals_1150, primals_1151, primals_1152, primals_1153, primals_1154, primals_1155, primals_1156, primals_1157, primals_1158, primals_1159, primals_1160, primals_1161, primals_1162, primals_1163, primals_1164, primals_1165, primals_1166, primals_1167, primals_1168, primals_1169, primals_1170, primals_1171, primals_1172, primals_1173, primals_1174, primals_1175, primals_1176, primals_1177, primals_1178, primals_1179, primals_1180, primals_1181, primals_1182, primals_1183, primals_1184, primals_1185, primals_1186, primals_1187, primals_1188, primals_1189, primals_1190, primals_1191, primals_1192, primals_1193, primals_1194, primals_1195, primals_1196, primals_1197, primals_1198, primals_1199, primals_1200, primals_1201, primals_1202, primals_1203, primals_1204, primals_1205, primals_1206, primals_1207, primals_1208, primals_1209, primals_1210, primals_1211, primals_1212, primals_1213, primals_1214, primals_1215, primals_1216, primals_1217, primals_1218, primals_1219, primals_1220, primals_1221, primals_1222, primals_1223, primals_1224, primals_1225, primals_1226, primals_1227, primals_1228, primals_1229, primals_1230, primals_1231, primals_1232, primals_1233, primals_1234, primals_1235, primals_1236, primals_1237, primals_1238, primals_1239, primals_1240, primals_1241, primals_1242, primals_1243, primals_1244, primals_1245, primals_1246, primals_1247, primals_1248, primals_1249, primals_1250, primals_1251, primals_1252, primals_1253, primals_1254, primals_1255, primals_1256, primals_1257, primals_1258, primals_1259, primals_1260, primals_1261, primals_1262, primals_1263, primals_1264, primals_1265, primals_1266, primals_1267, primals_1268, primals_1269, primals_1270, primals_1271, primals_1272, primals_1273, primals_1274, primals_1275, primals_1276, primals_1277, primals_1278, primals_1279, primals_1280, primals_1281, primals_1282, primals_1283, primals_1284, primals_1285, primals_1286, primals_1287, primals_1288, primals_1289, primals_1290, primals_1291, primals_1292, primals_1293, primals_1294, primals_1295, primals_1296, primals_1297, primals_1298, primals_1299, primals_1300, primals_1301, primals_1302, primals_1303, primals_1304, primals_1305, primals_1306, primals_1307, primals_1308, primals_1309, primals_1310, primals_1311, primals_1312, primals_1313, primals_1314, primals_1315, primals_1316, primals_1317, primals_1318, primals_1319, primals_1320, primals_1321, primals_1322, primals_1323, primals_1324, primals_1325, primals_1326, primals_1327, primals_1328, primals_1329, primals_1330, primals_1331, primals_1332, primals_1333, primals_1334, primals_1335, primals_1336, primals_1337, primals_1338, primals_1339, primals_1340, primals_1341, primals_1342, primals_1343, primals_1344, primals_1345, primals_1346, primals_1347, primals_1348, primals_1349, primals_1350, primals_1351, primals_1352, primals_1353, primals_1354, primals_1355, primals_1356, primals_1357, primals_1358, primals_1359, primals_1360, primals_1361, primals_1362, primals_1363, primals_1364, primals_1365, primals_1366, primals_1367, primals_1368, primals_1369, primals_1370, primals_1371, primals_1372, primals_1373, primals_1374, primals_1375, primals_1376, primals_1377, primals_1378, primals_1379, primals_1380, primals_1381, tangents_1, tangents_2):
        convolution_default = torch.ops.aten.convolution.default(primals_1376, primals_1373, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor = torch.ops.aten.add.Tensor(primals_1377, 1);  primals_1377 = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_1380, primals_1381, primals_1378, primals_1379, True, 0.1, 0.001);  primals_1381 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        new_zeros_default = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default = torch.ops.aten.relu.default(getitem)
        convolution_default_1 = torch.ops.aten.convolution.default(relu_default, primals_1269, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor = torch.ops.aten.add_.Tensor(primals_1265, 1);  primals_1265 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_1268, primals_1264, primals_1266, primals_1267, True, 0.1, 0.001);  primals_1264 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_1 = torch.ops.aten.relu.default(getitem)
        constant_pad_nd_default = torch.ops.aten.constant_pad_nd.default(relu_default_1, [2, 2, 2, 2], 0.0)
        convolution_default_2 = torch.ops.aten.convolution.default(constant_pad_nd_default, primals_1178, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 96)
        convolution_default_3 = torch.ops.aten.convolution.default(convolution_default_2, primals_1179, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_1 = torch.ops.aten.add_.Tensor(primals_1169, 1);  primals_1169 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_1172, primals_1168, primals_1170, primals_1171, True, 0.1, 0.001);  primals_1168 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        new_zeros_default_2 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_2 = torch.ops.aten.relu.default(getitem_6);  getitem_6 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu_default_2, primals_1180, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 54)
        convolution_default_5 = torch.ops.aten.convolution.default(convolution_default_4, primals_1181, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_2 = torch.ops.aten.add_.Tensor(primals_1174, 1);  primals_1174 = None
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_1177, primals_1173, primals_1175, primals_1176, True, 0.1, 0.001);  primals_1173 = None
        getitem_9 = native_batch_norm_default_3[0]
        getitem_10 = native_batch_norm_default_3[1]
        getitem_11 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        constant_pad_nd_default_1 = torch.ops.aten.constant_pad_nd.default(getitem, [1, 1, 1, 1], -inf)
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_1, [3, 3], [2, 2])
        getitem_12 = max_pool2d_with_indices_default[0]
        getitem_13 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_6 = torch.ops.aten.convolution.default(getitem_12, primals_1182, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_3 = torch.ops.aten.add_.Tensor(primals_1184, 1);  primals_1184 = None
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_1187, primals_1183, primals_1185, primals_1186, True, 0.1, 0.001);  primals_1183 = None
        getitem_14 = native_batch_norm_default_4[0]
        getitem_15 = native_batch_norm_default_4[1]
        getitem_16 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(convolution_default_6, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_1 = torch.ops.aten.add.Tensor(getitem_9, getitem_14);  getitem_9 = getitem_14 = None
        relu_default_3 = torch.ops.aten.relu.default(getitem_3)
        constant_pad_nd_default_2 = torch.ops.aten.constant_pad_nd.default(relu_default_3, [3, 3, 3, 3], 0.0)
        convolution_default_7 = torch.ops.aten.convolution.default(constant_pad_nd_default_2, primals_1198, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 54)
        convolution_default_8 = torch.ops.aten.convolution.default(convolution_default_7, primals_1199, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_4 = torch.ops.aten.add_.Tensor(primals_1189, 1);  primals_1189 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_1192, primals_1188, primals_1190, primals_1191, True, 0.1, 0.001);  primals_1188 = None
        getitem_17 = native_batch_norm_default_5[0]
        getitem_18 = native_batch_norm_default_5[1]
        getitem_19 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        new_zeros_default_5 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_4 = torch.ops.aten.relu.default(getitem_17);  getitem_17 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu_default_4, primals_1200, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 54)
        convolution_default_10 = torch.ops.aten.convolution.default(convolution_default_9, primals_1201, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_5 = torch.ops.aten.add_.Tensor(primals_1194, 1);  primals_1194 = None
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_1197, primals_1193, primals_1195, primals_1196, True, 0.1, 0.001);  primals_1193 = None
        getitem_20 = native_batch_norm_default_6[0]
        getitem_21 = native_batch_norm_default_6[1]
        getitem_22 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        constant_pad_nd_default_3 = torch.ops.aten.constant_pad_nd.default(getitem_3, [1, 1, 1, 1], -inf)
        max_pool2d_with_indices_default_1 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_3, [3, 3], [2, 2])
        getitem_23 = max_pool2d_with_indices_default_1[0]
        getitem_24 = max_pool2d_with_indices_default_1[1];  max_pool2d_with_indices_default_1 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(getitem_20, getitem_23);  getitem_20 = getitem_23 = None
        relu_default_5 = torch.ops.aten.relu.default(getitem_3)
        constant_pad_nd_default_4 = torch.ops.aten.constant_pad_nd.default(relu_default_5, [2, 2, 2, 2], 0.0)
        convolution_default_11 = torch.ops.aten.convolution.default(constant_pad_nd_default_4, primals_1212, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 54)
        convolution_default_12 = torch.ops.aten.convolution.default(convolution_default_11, primals_1213, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_6 = torch.ops.aten.add_.Tensor(primals_1203, 1);  primals_1203 = None
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_1206, primals_1202, primals_1204, primals_1205, True, 0.1, 0.001);  primals_1202 = None
        getitem_25 = native_batch_norm_default_7[0]
        getitem_26 = native_batch_norm_default_7[1]
        getitem_27 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(convolution_default_12, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_6 = torch.ops.aten.relu.default(getitem_25);  getitem_25 = None
        convolution_default_13 = torch.ops.aten.convolution.default(relu_default_6, primals_1214, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 54)
        convolution_default_14 = torch.ops.aten.convolution.default(convolution_default_13, primals_1215, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_7 = torch.ops.aten.add_.Tensor(primals_1208, 1);  primals_1208 = None
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_1211, primals_1207, primals_1209, primals_1210, True, 0.1, 0.001);  primals_1207 = None
        getitem_28 = native_batch_norm_default_8[0]
        getitem_29 = native_batch_norm_default_8[1]
        getitem_30 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        new_zeros_default_8 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_7 = torch.ops.aten.relu.default(getitem_3)
        constant_pad_nd_default_5 = torch.ops.aten.constant_pad_nd.default(relu_default_7, [1, 1, 1, 1], 0.0)
        convolution_default_15 = torch.ops.aten.convolution.default(constant_pad_nd_default_5, primals_1226, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 54)
        convolution_default_16 = torch.ops.aten.convolution.default(convolution_default_15, primals_1227, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_8 = torch.ops.aten.add_.Tensor(primals_1217, 1);  primals_1217 = None
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_1220, primals_1216, primals_1218, primals_1219, True, 0.1, 0.001);  primals_1216 = None
        getitem_31 = native_batch_norm_default_9[0]
        getitem_32 = native_batch_norm_default_9[1]
        getitem_33 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        new_zeros_default_9 = torch.ops.aten.new_zeros.default(convolution_default_16, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_8 = torch.ops.aten.relu.default(getitem_31);  getitem_31 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu_default_8, primals_1228, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 54)
        convolution_default_18 = torch.ops.aten.convolution.default(convolution_default_17, primals_1229, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_9 = torch.ops.aten.add_.Tensor(primals_1222, 1);  primals_1222 = None
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_1225, primals_1221, primals_1223, primals_1224, True, 0.1, 0.001);  primals_1221 = None
        getitem_34 = native_batch_norm_default_10[0]
        getitem_35 = native_batch_norm_default_10[1]
        getitem_36 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        new_zeros_default_10 = torch.ops.aten.new_zeros.default(convolution_default_18, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_3 = torch.ops.aten.add.Tensor(getitem_28, getitem_34);  getitem_28 = getitem_34 = None
        relu_default_9 = torch.ops.aten.relu.default(add_tensor_3)
        convolution_default_19 = torch.ops.aten.convolution.default(relu_default_9, primals_1240, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 54)
        convolution_default_20 = torch.ops.aten.convolution.default(convolution_default_19, primals_1241, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_10 = torch.ops.aten.add_.Tensor(primals_1231, 1);  primals_1231 = None
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_1234, primals_1230, primals_1232, primals_1233, True, 0.1, 0.001);  primals_1230 = None
        getitem_37 = native_batch_norm_default_11[0]
        getitem_38 = native_batch_norm_default_11[1]
        getitem_39 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        new_zeros_default_11 = torch.ops.aten.new_zeros.default(convolution_default_20, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_10 = torch.ops.aten.relu.default(getitem_37);  getitem_37 = None
        convolution_default_21 = torch.ops.aten.convolution.default(relu_default_10, primals_1242, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 54)
        convolution_default_22 = torch.ops.aten.convolution.default(convolution_default_21, primals_1243, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_11 = torch.ops.aten.add_.Tensor(primals_1236, 1);  primals_1236 = None
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_1239, primals_1235, primals_1237, primals_1238, True, 0.1, 0.001);  primals_1235 = None
        getitem_40 = native_batch_norm_default_12[0]
        getitem_41 = native_batch_norm_default_12[1]
        getitem_42 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        new_zeros_default_12 = torch.ops.aten.new_zeros.default(convolution_default_22, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        constant_pad_nd_default_6 = torch.ops.aten.constant_pad_nd.default(getitem_3, [1, 1, 1, 1], -inf)
        max_pool2d_with_indices_default_2 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_6, [3, 3], [2, 2])
        getitem_43 = max_pool2d_with_indices_default_2[0]
        getitem_44 = max_pool2d_with_indices_default_2[1];  max_pool2d_with_indices_default_2 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(getitem_40, getitem_43);  getitem_40 = getitem_43 = None
        relu_default_11 = torch.ops.aten.relu.default(getitem)
        constant_pad_nd_default_7 = torch.ops.aten.constant_pad_nd.default(relu_default_11, [1, 1, 1, 1], 0.0)
        convolution_default_23 = torch.ops.aten.convolution.default(constant_pad_nd_default_7, primals_1254, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 96)
        convolution_default_24 = torch.ops.aten.convolution.default(convolution_default_23, primals_1255, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_12 = torch.ops.aten.add_.Tensor(primals_1245, 1);  primals_1245 = None
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_1248, primals_1244, primals_1246, primals_1247, True, 0.1, 0.001);  primals_1244 = None
        getitem_45 = native_batch_norm_default_13[0]
        getitem_46 = native_batch_norm_default_13[1]
        getitem_47 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        new_zeros_default_13 = torch.ops.aten.new_zeros.default(convolution_default_24, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_12 = torch.ops.aten.relu.default(getitem_45);  getitem_45 = None
        convolution_default_25 = torch.ops.aten.convolution.default(relu_default_12, primals_1256, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 54)
        convolution_default_26 = torch.ops.aten.convolution.default(convolution_default_25, primals_1257, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_13 = torch.ops.aten.add_.Tensor(primals_1250, 1);  primals_1250 = None
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_1253, primals_1249, primals_1251, primals_1252, True, 0.1, 0.001);  primals_1249 = None
        getitem_48 = native_batch_norm_default_14[0]
        getitem_49 = native_batch_norm_default_14[1]
        getitem_50 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        new_zeros_default_14 = torch.ops.aten.new_zeros.default(convolution_default_26, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_13 = torch.ops.aten.relu.default(getitem_3);  getitem_3 = None
        convolution_default_27 = torch.ops.aten.convolution.default(relu_default_13, primals_1263, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_14 = torch.ops.aten.add_.Tensor(primals_1259, 1);  primals_1259 = None
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_1262, primals_1258, primals_1260, primals_1261, True, 0.1, 0.001);  primals_1258 = None
        getitem_51 = native_batch_norm_default_15[0]
        getitem_52 = native_batch_norm_default_15[1]
        getitem_53 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        new_zeros_default_15 = torch.ops.aten.new_zeros.default(convolution_default_27, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_5 = torch.ops.aten.add.Tensor(getitem_48, getitem_51);  getitem_48 = getitem_51 = None
        cat_default = torch.ops.aten.cat.default([add_tensor_1, add_tensor_2, add_tensor_3, add_tensor_4, add_tensor_5], 1);  add_tensor_1 = add_tensor_2 = add_tensor_3 = add_tensor_4 = add_tensor_5 = None
        relu_default_14 = torch.ops.aten.relu.default(getitem);  getitem = None
        avg_pool2d_default = torch.ops.aten.avg_pool2d.default(relu_default_14, [1, 1], [2, 2], [0, 0], False, False)
        convolution_default_28 = torch.ops.aten.convolution.default(avg_pool2d_default, primals_1371, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        constant_pad_nd_default_8 = torch.ops.aten.constant_pad_nd.default(relu_default_14, [-1, 1, -1, 1], 0.0)
        avg_pool2d_default_1 = torch.ops.aten.avg_pool2d.default(constant_pad_nd_default_8, [1, 1], [2, 2], [0, 0], False, False)
        convolution_default_29 = torch.ops.aten.convolution.default(avg_pool2d_default_1, primals_1372, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_1 = torch.ops.aten.cat.default([convolution_default_28, convolution_default_29], 1);  convolution_default_28 = convolution_default_29 = None
        add__tensor_15 = torch.ops.aten.add_.Tensor(primals_1367, 1);  primals_1367 = None
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(cat_default_1, primals_1370, primals_1366, primals_1368, primals_1369, True, 0.1, 0.001);  primals_1366 = None
        getitem_54 = native_batch_norm_default_16[0]
        getitem_55 = native_batch_norm_default_16[1]
        getitem_56 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        new_zeros_default_16 = torch.ops.aten.new_zeros.default(cat_default_1, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_15 = torch.ops.aten.relu.default(cat_default)
        convolution_default_30 = torch.ops.aten.convolution.default(relu_default_15, primals_1365, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_16 = torch.ops.aten.add_.Tensor(primals_1361, 1);  primals_1361 = None
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_1364, primals_1360, primals_1362, primals_1363, True, 0.1, 0.001);  primals_1360 = None
        getitem_57 = native_batch_norm_default_17[0]
        getitem_58 = native_batch_norm_default_17[1]
        getitem_59 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        new_zeros_default_17 = torch.ops.aten.new_zeros.default(convolution_default_30, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_16 = torch.ops.aten.relu.default(getitem_54)
        constant_pad_nd_default_9 = torch.ops.aten.constant_pad_nd.default(relu_default_16, [2, 2, 2, 2], 0.0)
        convolution_default_31 = torch.ops.aten.convolution.default(constant_pad_nd_default_9, primals_1280, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 108)
        convolution_default_32 = torch.ops.aten.convolution.default(convolution_default_31, primals_1281, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_17 = torch.ops.aten.add_.Tensor(primals_1271, 1);  primals_1271 = None
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_1274, primals_1270, primals_1272, primals_1273, True, 0.1, 0.001);  primals_1270 = None
        getitem_60 = native_batch_norm_default_18[0]
        getitem_61 = native_batch_norm_default_18[1]
        getitem_62 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        new_zeros_default_18 = torch.ops.aten.new_zeros.default(convolution_default_32, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_17 = torch.ops.aten.relu.default(getitem_60);  getitem_60 = None
        convolution_default_33 = torch.ops.aten.convolution.default(relu_default_17, primals_1282, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 108)
        convolution_default_34 = torch.ops.aten.convolution.default(convolution_default_33, primals_1283, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_18 = torch.ops.aten.add_.Tensor(primals_1276, 1);  primals_1276 = None
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_1279, primals_1275, primals_1277, primals_1278, True, 0.1, 0.001);  primals_1275 = None
        getitem_63 = native_batch_norm_default_19[0]
        getitem_64 = native_batch_norm_default_19[1]
        getitem_65 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        new_zeros_default_19 = torch.ops.aten.new_zeros.default(convolution_default_34, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        constant_pad_nd_default_10 = torch.ops.aten.constant_pad_nd.default(getitem_54, [1, 1, 1, 1], -inf)
        max_pool2d_with_indices_default_3 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_10, [3, 3], [2, 2])
        getitem_66 = max_pool2d_with_indices_default_3[0]
        getitem_67 = max_pool2d_with_indices_default_3[1];  max_pool2d_with_indices_default_3 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(getitem_63, getitem_66);  getitem_63 = getitem_66 = None
        relu_default_18 = torch.ops.aten.relu.default(getitem_57)
        constant_pad_nd_default_11 = torch.ops.aten.constant_pad_nd.default(relu_default_18, [3, 3, 3, 3], 0.0)
        convolution_default_35 = torch.ops.aten.convolution.default(constant_pad_nd_default_11, primals_1294, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 108)
        convolution_default_36 = torch.ops.aten.convolution.default(convolution_default_35, primals_1295, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_19 = torch.ops.aten.add_.Tensor(primals_1285, 1);  primals_1285 = None
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_1288, primals_1284, primals_1286, primals_1287, True, 0.1, 0.001);  primals_1284 = None
        getitem_68 = native_batch_norm_default_20[0]
        getitem_69 = native_batch_norm_default_20[1]
        getitem_70 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        new_zeros_default_20 = torch.ops.aten.new_zeros.default(convolution_default_36, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_19 = torch.ops.aten.relu.default(getitem_68);  getitem_68 = None
        convolution_default_37 = torch.ops.aten.convolution.default(relu_default_19, primals_1296, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 108)
        convolution_default_38 = torch.ops.aten.convolution.default(convolution_default_37, primals_1297, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_20 = torch.ops.aten.add_.Tensor(primals_1290, 1);  primals_1290 = None
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_1293, primals_1289, primals_1291, primals_1292, True, 0.1, 0.001);  primals_1289 = None
        getitem_71 = native_batch_norm_default_21[0]
        getitem_72 = native_batch_norm_default_21[1]
        getitem_73 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        new_zeros_default_21 = torch.ops.aten.new_zeros.default(convolution_default_38, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        constant_pad_nd_default_12 = torch.ops.aten.constant_pad_nd.default(getitem_57, [1, 1, 1, 1], -inf)
        max_pool2d_with_indices_default_4 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_12, [3, 3], [2, 2])
        getitem_74 = max_pool2d_with_indices_default_4[0]
        getitem_75 = max_pool2d_with_indices_default_4[1];  max_pool2d_with_indices_default_4 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(getitem_71, getitem_74);  getitem_71 = getitem_74 = None
        relu_default_20 = torch.ops.aten.relu.default(getitem_57)
        constant_pad_nd_default_13 = torch.ops.aten.constant_pad_nd.default(relu_default_20, [2, 2, 2, 2], 0.0)
        convolution_default_39 = torch.ops.aten.convolution.default(constant_pad_nd_default_13, primals_1308, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 108)
        convolution_default_40 = torch.ops.aten.convolution.default(convolution_default_39, primals_1309, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_21 = torch.ops.aten.add_.Tensor(primals_1299, 1);  primals_1299 = None
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_1302, primals_1298, primals_1300, primals_1301, True, 0.1, 0.001);  primals_1298 = None
        getitem_76 = native_batch_norm_default_22[0]
        getitem_77 = native_batch_norm_default_22[1]
        getitem_78 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        new_zeros_default_22 = torch.ops.aten.new_zeros.default(convolution_default_40, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_21 = torch.ops.aten.relu.default(getitem_76);  getitem_76 = None
        convolution_default_41 = torch.ops.aten.convolution.default(relu_default_21, primals_1310, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 108)
        convolution_default_42 = torch.ops.aten.convolution.default(convolution_default_41, primals_1311, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_22 = torch.ops.aten.add_.Tensor(primals_1304, 1);  primals_1304 = None
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_42, primals_1307, primals_1303, primals_1305, primals_1306, True, 0.1, 0.001);  primals_1303 = None
        getitem_79 = native_batch_norm_default_23[0]
        getitem_80 = native_batch_norm_default_23[1]
        getitem_81 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        new_zeros_default_23 = torch.ops.aten.new_zeros.default(convolution_default_42, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_22 = torch.ops.aten.relu.default(getitem_57)
        constant_pad_nd_default_14 = torch.ops.aten.constant_pad_nd.default(relu_default_22, [1, 1, 1, 1], 0.0)
        convolution_default_43 = torch.ops.aten.convolution.default(constant_pad_nd_default_14, primals_1322, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 108)
        convolution_default_44 = torch.ops.aten.convolution.default(convolution_default_43, primals_1323, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_23 = torch.ops.aten.add_.Tensor(primals_1313, 1);  primals_1313 = None
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_1316, primals_1312, primals_1314, primals_1315, True, 0.1, 0.001);  primals_1312 = None
        getitem_82 = native_batch_norm_default_24[0]
        getitem_83 = native_batch_norm_default_24[1]
        getitem_84 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        new_zeros_default_24 = torch.ops.aten.new_zeros.default(convolution_default_44, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_23 = torch.ops.aten.relu.default(getitem_82);  getitem_82 = None
        convolution_default_45 = torch.ops.aten.convolution.default(relu_default_23, primals_1324, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 108)
        convolution_default_46 = torch.ops.aten.convolution.default(convolution_default_45, primals_1325, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_24 = torch.ops.aten.add_.Tensor(primals_1318, 1);  primals_1318 = None
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_46, primals_1321, primals_1317, primals_1319, primals_1320, True, 0.1, 0.001);  primals_1317 = None
        getitem_85 = native_batch_norm_default_25[0]
        getitem_86 = native_batch_norm_default_25[1]
        getitem_87 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        new_zeros_default_25 = torch.ops.aten.new_zeros.default(convolution_default_46, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_8 = torch.ops.aten.add.Tensor(getitem_79, getitem_85);  getitem_79 = getitem_85 = None
        relu_default_24 = torch.ops.aten.relu.default(add_tensor_8)
        convolution_default_47 = torch.ops.aten.convolution.default(relu_default_24, primals_1336, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 108)
        convolution_default_48 = torch.ops.aten.convolution.default(convolution_default_47, primals_1337, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_25 = torch.ops.aten.add_.Tensor(primals_1327, 1);  primals_1327 = None
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_48, primals_1330, primals_1326, primals_1328, primals_1329, True, 0.1, 0.001);  primals_1326 = None
        getitem_88 = native_batch_norm_default_26[0]
        getitem_89 = native_batch_norm_default_26[1]
        getitem_90 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        new_zeros_default_26 = torch.ops.aten.new_zeros.default(convolution_default_48, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_25 = torch.ops.aten.relu.default(getitem_88);  getitem_88 = None
        convolution_default_49 = torch.ops.aten.convolution.default(relu_default_25, primals_1338, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 108)
        convolution_default_50 = torch.ops.aten.convolution.default(convolution_default_49, primals_1339, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_26 = torch.ops.aten.add_.Tensor(primals_1332, 1);  primals_1332 = None
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_50, primals_1335, primals_1331, primals_1333, primals_1334, True, 0.1, 0.001);  primals_1331 = None
        getitem_91 = native_batch_norm_default_27[0]
        getitem_92 = native_batch_norm_default_27[1]
        getitem_93 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        new_zeros_default_27 = torch.ops.aten.new_zeros.default(convolution_default_50, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        constant_pad_nd_default_15 = torch.ops.aten.constant_pad_nd.default(getitem_57, [1, 1, 1, 1], -inf)
        max_pool2d_with_indices_default_5 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_15, [3, 3], [2, 2])
        getitem_94 = max_pool2d_with_indices_default_5[0]
        getitem_95 = max_pool2d_with_indices_default_5[1];  max_pool2d_with_indices_default_5 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(getitem_91, getitem_94);  getitem_91 = getitem_94 = None
        relu_default_26 = torch.ops.aten.relu.default(getitem_54);  getitem_54 = None
        constant_pad_nd_default_16 = torch.ops.aten.constant_pad_nd.default(relu_default_26, [1, 1, 1, 1], 0.0)
        convolution_default_51 = torch.ops.aten.convolution.default(constant_pad_nd_default_16, primals_1350, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 108)
        convolution_default_52 = torch.ops.aten.convolution.default(convolution_default_51, primals_1351, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_27 = torch.ops.aten.add_.Tensor(primals_1341, 1);  primals_1341 = None
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_52, primals_1344, primals_1340, primals_1342, primals_1343, True, 0.1, 0.001);  primals_1340 = None
        getitem_96 = native_batch_norm_default_28[0]
        getitem_97 = native_batch_norm_default_28[1]
        getitem_98 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        new_zeros_default_28 = torch.ops.aten.new_zeros.default(convolution_default_52, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_27 = torch.ops.aten.relu.default(getitem_96);  getitem_96 = None
        convolution_default_53 = torch.ops.aten.convolution.default(relu_default_27, primals_1352, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 108)
        convolution_default_54 = torch.ops.aten.convolution.default(convolution_default_53, primals_1353, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_28 = torch.ops.aten.add_.Tensor(primals_1346, 1);  primals_1346 = None
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_54, primals_1349, primals_1345, primals_1347, primals_1348, True, 0.1, 0.001);  primals_1345 = None
        getitem_99 = native_batch_norm_default_29[0]
        getitem_100 = native_batch_norm_default_29[1]
        getitem_101 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        new_zeros_default_29 = torch.ops.aten.new_zeros.default(convolution_default_54, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_28 = torch.ops.aten.relu.default(getitem_57);  getitem_57 = None
        convolution_default_55 = torch.ops.aten.convolution.default(relu_default_28, primals_1359, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_29 = torch.ops.aten.add_.Tensor(primals_1355, 1);  primals_1355 = None
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_55, primals_1358, primals_1354, primals_1356, primals_1357, True, 0.1, 0.001);  primals_1354 = None
        getitem_102 = native_batch_norm_default_30[0]
        getitem_103 = native_batch_norm_default_30[1]
        getitem_104 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        new_zeros_default_30 = torch.ops.aten.new_zeros.default(convolution_default_55, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_10 = torch.ops.aten.add.Tensor(getitem_99, getitem_102);  getitem_99 = getitem_102 = None
        cat_default_2 = torch.ops.aten.cat.default([add_tensor_6, add_tensor_7, add_tensor_8, add_tensor_9, add_tensor_10], 1);  add_tensor_6 = add_tensor_7 = add_tensor_8 = add_tensor_9 = add_tensor_10 = None
        relu_default_29 = torch.ops.aten.relu.default(cat_default);  cat_default = None
        avg_pool2d_default_2 = torch.ops.aten.avg_pool2d.default(relu_default_29, [1, 1], [2, 2], [0, 0], False, False)
        convolution_default_56 = torch.ops.aten.convolution.default(avg_pool2d_default_2, primals_96, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        constant_pad_nd_default_17 = torch.ops.aten.constant_pad_nd.default(relu_default_29, [-1, 1, -1, 1], 0.0)
        avg_pool2d_default_3 = torch.ops.aten.avg_pool2d.default(constant_pad_nd_default_17, [1, 1], [2, 2], [0, 0], False, False)
        convolution_default_57 = torch.ops.aten.convolution.default(avg_pool2d_default_3, primals_97, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_3 = torch.ops.aten.cat.default([convolution_default_56, convolution_default_57], 1);  convolution_default_56 = convolution_default_57 = None
        add__tensor_30 = torch.ops.aten.add_.Tensor(primals_92, 1);  primals_92 = None
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(cat_default_3, primals_95, primals_91, primals_93, primals_94, True, 0.1, 0.001);  primals_91 = None
        getitem_105 = native_batch_norm_default_31[0]
        getitem_106 = native_batch_norm_default_31[1]
        getitem_107 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        new_zeros_default_31 = torch.ops.aten.new_zeros.default(cat_default_3, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_30 = torch.ops.aten.relu.default(cat_default_2)
        convolution_default_58 = torch.ops.aten.convolution.default(relu_default_30, primals_90, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_31 = torch.ops.aten.add_.Tensor(primals_86, 1);  primals_86 = None
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_58, primals_89, primals_85, primals_87, primals_88, True, 0.1, 0.001);  primals_85 = None
        getitem_108 = native_batch_norm_default_32[0]
        getitem_109 = native_batch_norm_default_32[1]
        getitem_110 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        new_zeros_default_32 = torch.ops.aten.new_zeros.default(convolution_default_58, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_31 = torch.ops.aten.relu.default(getitem_105)
        convolution_default_59 = torch.ops.aten.convolution.default(relu_default_31, primals_11, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 216)
        convolution_default_60 = torch.ops.aten.convolution.default(convolution_default_59, primals_12, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_32 = torch.ops.aten.add_.Tensor(primals_2, 1);  primals_2 = None
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_60, primals_5, primals_1, primals_3, primals_4, True, 0.1, 0.001);  primals_1 = None
        getitem_111 = native_batch_norm_default_33[0]
        getitem_112 = native_batch_norm_default_33[1]
        getitem_113 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        new_zeros_default_33 = torch.ops.aten.new_zeros.default(convolution_default_60, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_32 = torch.ops.aten.relu.default(getitem_111);  getitem_111 = None
        convolution_default_61 = torch.ops.aten.convolution.default(relu_default_32, primals_13, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 216)
        convolution_default_62 = torch.ops.aten.convolution.default(convolution_default_61, primals_14, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_33 = torch.ops.aten.add_.Tensor(primals_7, 1);  primals_7 = None
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_62, primals_10, primals_6, primals_8, primals_9, True, 0.1, 0.001);  primals_6 = None
        getitem_114 = native_batch_norm_default_34[0]
        getitem_115 = native_batch_norm_default_34[1]
        getitem_116 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        new_zeros_default_34 = torch.ops.aten.new_zeros.default(convolution_default_62, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        max_pool2d_with_indices_default_6 = torch.ops.aten.max_pool2d_with_indices.default(getitem_105, [3, 3], [1, 1], [1, 1])
        getitem_117 = max_pool2d_with_indices_default_6[0]
        getitem_118 = max_pool2d_with_indices_default_6[1];  max_pool2d_with_indices_default_6 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(getitem_114, getitem_117);  getitem_114 = getitem_117 = None
        relu_default_33 = torch.ops.aten.relu.default(getitem_108)
        convolution_default_63 = torch.ops.aten.convolution.default(relu_default_33, primals_25, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 216)
        convolution_default_64 = torch.ops.aten.convolution.default(convolution_default_63, primals_26, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_34 = torch.ops.aten.add_.Tensor(primals_16, 1);  primals_16 = None
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_64, primals_19, primals_15, primals_17, primals_18, True, 0.1, 0.001);  primals_15 = None
        getitem_119 = native_batch_norm_default_35[0]
        getitem_120 = native_batch_norm_default_35[1]
        getitem_121 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        new_zeros_default_35 = torch.ops.aten.new_zeros.default(convolution_default_64, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_34 = torch.ops.aten.relu.default(getitem_119);  getitem_119 = None
        convolution_default_65 = torch.ops.aten.convolution.default(relu_default_34, primals_27, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 216)
        convolution_default_66 = torch.ops.aten.convolution.default(convolution_default_65, primals_28, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_35 = torch.ops.aten.add_.Tensor(primals_21, 1);  primals_21 = None
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_66, primals_24, primals_20, primals_22, primals_23, True, 0.1, 0.001);  primals_20 = None
        getitem_122 = native_batch_norm_default_36[0]
        getitem_123 = native_batch_norm_default_36[1]
        getitem_124 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        new_zeros_default_36 = torch.ops.aten.new_zeros.default(convolution_default_66, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        max_pool2d_with_indices_default_7 = torch.ops.aten.max_pool2d_with_indices.default(getitem_108, [3, 3], [1, 1], [1, 1])
        getitem_125 = max_pool2d_with_indices_default_7[0]
        getitem_126 = max_pool2d_with_indices_default_7[1];  max_pool2d_with_indices_default_7 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(getitem_122, getitem_125);  getitem_122 = getitem_125 = None
        relu_default_35 = torch.ops.aten.relu.default(getitem_108)
        convolution_default_67 = torch.ops.aten.convolution.default(relu_default_35, primals_39, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 216)
        convolution_default_68 = torch.ops.aten.convolution.default(convolution_default_67, primals_40, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_36 = torch.ops.aten.add_.Tensor(primals_30, 1);  primals_30 = None
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_68, primals_33, primals_29, primals_31, primals_32, True, 0.1, 0.001);  primals_29 = None
        getitem_127 = native_batch_norm_default_37[0]
        getitem_128 = native_batch_norm_default_37[1]
        getitem_129 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        new_zeros_default_37 = torch.ops.aten.new_zeros.default(convolution_default_68, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_36 = torch.ops.aten.relu.default(getitem_127);  getitem_127 = None
        convolution_default_69 = torch.ops.aten.convolution.default(relu_default_36, primals_41, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 216)
        convolution_default_70 = torch.ops.aten.convolution.default(convolution_default_69, primals_42, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_37 = torch.ops.aten.add_.Tensor(primals_35, 1);  primals_35 = None
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_70, primals_38, primals_34, primals_36, primals_37, True, 0.1, 0.001);  primals_34 = None
        getitem_130 = native_batch_norm_default_38[0]
        getitem_131 = native_batch_norm_default_38[1]
        getitem_132 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        new_zeros_default_38 = torch.ops.aten.new_zeros.default(convolution_default_70, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_37 = torch.ops.aten.relu.default(getitem_108)
        convolution_default_71 = torch.ops.aten.convolution.default(relu_default_37, primals_53, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_72 = torch.ops.aten.convolution.default(convolution_default_71, primals_54, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_38 = torch.ops.aten.add_.Tensor(primals_44, 1);  primals_44 = None
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_72, primals_47, primals_43, primals_45, primals_46, True, 0.1, 0.001);  primals_43 = None
        getitem_133 = native_batch_norm_default_39[0]
        getitem_134 = native_batch_norm_default_39[1]
        getitem_135 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        new_zeros_default_39 = torch.ops.aten.new_zeros.default(convolution_default_72, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_38 = torch.ops.aten.relu.default(getitem_133);  getitem_133 = None
        convolution_default_73 = torch.ops.aten.convolution.default(relu_default_38, primals_55, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_74 = torch.ops.aten.convolution.default(convolution_default_73, primals_56, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_39 = torch.ops.aten.add_.Tensor(primals_49, 1);  primals_49 = None
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_74, primals_52, primals_48, primals_50, primals_51, True, 0.1, 0.001);  primals_48 = None
        getitem_136 = native_batch_norm_default_40[0]
        getitem_137 = native_batch_norm_default_40[1]
        getitem_138 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        new_zeros_default_40 = torch.ops.aten.new_zeros.default(convolution_default_74, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_13 = torch.ops.aten.add.Tensor(getitem_130, getitem_136);  getitem_130 = getitem_136 = None
        relu_default_39 = torch.ops.aten.relu.default(add_tensor_13)
        convolution_default_75 = torch.ops.aten.convolution.default(relu_default_39, primals_67, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_76 = torch.ops.aten.convolution.default(convolution_default_75, primals_68, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_40 = torch.ops.aten.add_.Tensor(primals_58, 1);  primals_58 = None
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_76, primals_61, primals_57, primals_59, primals_60, True, 0.1, 0.001);  primals_57 = None
        getitem_139 = native_batch_norm_default_41[0]
        getitem_140 = native_batch_norm_default_41[1]
        getitem_141 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        new_zeros_default_41 = torch.ops.aten.new_zeros.default(convolution_default_76, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_40 = torch.ops.aten.relu.default(getitem_139);  getitem_139 = None
        convolution_default_77 = torch.ops.aten.convolution.default(relu_default_40, primals_69, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_78 = torch.ops.aten.convolution.default(convolution_default_77, primals_70, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_41 = torch.ops.aten.add_.Tensor(primals_63, 1);  primals_63 = None
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_78, primals_66, primals_62, primals_64, primals_65, True, 0.1, 0.001);  primals_62 = None
        getitem_142 = native_batch_norm_default_42[0]
        getitem_143 = native_batch_norm_default_42[1]
        getitem_144 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        new_zeros_default_42 = torch.ops.aten.new_zeros.default(convolution_default_78, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        max_pool2d_with_indices_default_8 = torch.ops.aten.max_pool2d_with_indices.default(getitem_108, [3, 3], [1, 1], [1, 1])
        getitem_145 = max_pool2d_with_indices_default_8[0]
        getitem_146 = max_pool2d_with_indices_default_8[1];  max_pool2d_with_indices_default_8 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(getitem_142, getitem_145);  getitem_142 = getitem_145 = None
        relu_default_41 = torch.ops.aten.relu.default(getitem_105)
        convolution_default_79 = torch.ops.aten.convolution.default(relu_default_41, primals_81, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_80 = torch.ops.aten.convolution.default(convolution_default_79, primals_82, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_42 = torch.ops.aten.add_.Tensor(primals_72, 1);  primals_72 = None
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_80, primals_75, primals_71, primals_73, primals_74, True, 0.1, 0.001);  primals_71 = None
        getitem_147 = native_batch_norm_default_43[0]
        getitem_148 = native_batch_norm_default_43[1]
        getitem_149 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        new_zeros_default_43 = torch.ops.aten.new_zeros.default(convolution_default_80, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_42 = torch.ops.aten.relu.default(getitem_147);  getitem_147 = None
        convolution_default_81 = torch.ops.aten.convolution.default(relu_default_42, primals_83, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_82 = torch.ops.aten.convolution.default(convolution_default_81, primals_84, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_43 = torch.ops.aten.add_.Tensor(primals_77, 1);  primals_77 = None
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_82, primals_80, primals_76, primals_78, primals_79, True, 0.1, 0.001);  primals_76 = None
        getitem_150 = native_batch_norm_default_44[0]
        getitem_151 = native_batch_norm_default_44[1]
        getitem_152 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        new_zeros_default_44 = torch.ops.aten.new_zeros.default(convolution_default_82, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_15 = torch.ops.aten.add.Tensor(getitem_150, getitem_108);  getitem_150 = None
        cat_default_4 = torch.ops.aten.cat.default([add_tensor_11, add_tensor_12, add_tensor_13, add_tensor_14, add_tensor_15], 1);  add_tensor_11 = add_tensor_12 = add_tensor_13 = add_tensor_14 = add_tensor_15 = None
        relu_default_43 = torch.ops.aten.relu.default(cat_default_2);  cat_default_2 = None
        convolution_default_83 = torch.ops.aten.convolution.default(relu_default_43, primals_385, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_44 = torch.ops.aten.add_.Tensor(primals_381, 1);  primals_381 = None
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_83, primals_384, primals_380, primals_382, primals_383, True, 0.1, 0.001);  primals_380 = None
        getitem_153 = native_batch_norm_default_45[0]
        getitem_154 = native_batch_norm_default_45[1]
        getitem_155 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        new_zeros_default_45 = torch.ops.aten.new_zeros.default(convolution_default_83, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_44 = torch.ops.aten.relu.default(cat_default_4)
        convolution_default_84 = torch.ops.aten.convolution.default(relu_default_44, primals_379, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_45 = torch.ops.aten.add_.Tensor(primals_375, 1);  primals_375 = None
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(convolution_default_84, primals_378, primals_374, primals_376, primals_377, True, 0.1, 0.001);  primals_374 = None
        getitem_156 = native_batch_norm_default_46[0]
        getitem_157 = native_batch_norm_default_46[1]
        getitem_158 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        new_zeros_default_46 = torch.ops.aten.new_zeros.default(convolution_default_84, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_45 = torch.ops.aten.relu.default(getitem_153)
        convolution_default_85 = torch.ops.aten.convolution.default(relu_default_45, primals_300, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 216)
        convolution_default_86 = torch.ops.aten.convolution.default(convolution_default_85, primals_301, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_46 = torch.ops.aten.add_.Tensor(primals_291, 1);  primals_291 = None
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(convolution_default_86, primals_294, primals_290, primals_292, primals_293, True, 0.1, 0.001);  primals_290 = None
        getitem_159 = native_batch_norm_default_47[0]
        getitem_160 = native_batch_norm_default_47[1]
        getitem_161 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        new_zeros_default_47 = torch.ops.aten.new_zeros.default(convolution_default_86, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_46 = torch.ops.aten.relu.default(getitem_159);  getitem_159 = None
        convolution_default_87 = torch.ops.aten.convolution.default(relu_default_46, primals_302, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 216)
        convolution_default_88 = torch.ops.aten.convolution.default(convolution_default_87, primals_303, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_47 = torch.ops.aten.add_.Tensor(primals_296, 1);  primals_296 = None
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_88, primals_299, primals_295, primals_297, primals_298, True, 0.1, 0.001);  primals_295 = None
        getitem_162 = native_batch_norm_default_48[0]
        getitem_163 = native_batch_norm_default_48[1]
        getitem_164 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        new_zeros_default_48 = torch.ops.aten.new_zeros.default(convolution_default_88, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        max_pool2d_with_indices_default_9 = torch.ops.aten.max_pool2d_with_indices.default(getitem_153, [3, 3], [1, 1], [1, 1])
        getitem_165 = max_pool2d_with_indices_default_9[0]
        getitem_166 = max_pool2d_with_indices_default_9[1];  max_pool2d_with_indices_default_9 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(getitem_162, getitem_165);  getitem_162 = getitem_165 = None
        relu_default_47 = torch.ops.aten.relu.default(getitem_156)
        convolution_default_89 = torch.ops.aten.convolution.default(relu_default_47, primals_314, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 216)
        convolution_default_90 = torch.ops.aten.convolution.default(convolution_default_89, primals_315, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_48 = torch.ops.aten.add_.Tensor(primals_305, 1);  primals_305 = None
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(convolution_default_90, primals_308, primals_304, primals_306, primals_307, True, 0.1, 0.001);  primals_304 = None
        getitem_167 = native_batch_norm_default_49[0]
        getitem_168 = native_batch_norm_default_49[1]
        getitem_169 = native_batch_norm_default_49[2];  native_batch_norm_default_49 = None
        new_zeros_default_49 = torch.ops.aten.new_zeros.default(convolution_default_90, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_48 = torch.ops.aten.relu.default(getitem_167);  getitem_167 = None
        convolution_default_91 = torch.ops.aten.convolution.default(relu_default_48, primals_316, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 216)
        convolution_default_92 = torch.ops.aten.convolution.default(convolution_default_91, primals_317, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_49 = torch.ops.aten.add_.Tensor(primals_310, 1);  primals_310 = None
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(convolution_default_92, primals_313, primals_309, primals_311, primals_312, True, 0.1, 0.001);  primals_309 = None
        getitem_170 = native_batch_norm_default_50[0]
        getitem_171 = native_batch_norm_default_50[1]
        getitem_172 = native_batch_norm_default_50[2];  native_batch_norm_default_50 = None
        new_zeros_default_50 = torch.ops.aten.new_zeros.default(convolution_default_92, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        max_pool2d_with_indices_default_10 = torch.ops.aten.max_pool2d_with_indices.default(getitem_156, [3, 3], [1, 1], [1, 1])
        getitem_173 = max_pool2d_with_indices_default_10[0]
        getitem_174 = max_pool2d_with_indices_default_10[1];  max_pool2d_with_indices_default_10 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(getitem_170, getitem_173);  getitem_170 = getitem_173 = None
        relu_default_49 = torch.ops.aten.relu.default(getitem_156)
        convolution_default_93 = torch.ops.aten.convolution.default(relu_default_49, primals_328, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 216)
        convolution_default_94 = torch.ops.aten.convolution.default(convolution_default_93, primals_329, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_50 = torch.ops.aten.add_.Tensor(primals_319, 1);  primals_319 = None
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(convolution_default_94, primals_322, primals_318, primals_320, primals_321, True, 0.1, 0.001);  primals_318 = None
        getitem_175 = native_batch_norm_default_51[0]
        getitem_176 = native_batch_norm_default_51[1]
        getitem_177 = native_batch_norm_default_51[2];  native_batch_norm_default_51 = None
        new_zeros_default_51 = torch.ops.aten.new_zeros.default(convolution_default_94, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_50 = torch.ops.aten.relu.default(getitem_175);  getitem_175 = None
        convolution_default_95 = torch.ops.aten.convolution.default(relu_default_50, primals_330, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 216)
        convolution_default_96 = torch.ops.aten.convolution.default(convolution_default_95, primals_331, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_51 = torch.ops.aten.add_.Tensor(primals_324, 1);  primals_324 = None
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(convolution_default_96, primals_327, primals_323, primals_325, primals_326, True, 0.1, 0.001);  primals_323 = None
        getitem_178 = native_batch_norm_default_52[0]
        getitem_179 = native_batch_norm_default_52[1]
        getitem_180 = native_batch_norm_default_52[2];  native_batch_norm_default_52 = None
        new_zeros_default_52 = torch.ops.aten.new_zeros.default(convolution_default_96, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_51 = torch.ops.aten.relu.default(getitem_156)
        convolution_default_97 = torch.ops.aten.convolution.default(relu_default_51, primals_342, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_98 = torch.ops.aten.convolution.default(convolution_default_97, primals_343, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_52 = torch.ops.aten.add_.Tensor(primals_333, 1);  primals_333 = None
        native_batch_norm_default_53 = torch.ops.aten.native_batch_norm.default(convolution_default_98, primals_336, primals_332, primals_334, primals_335, True, 0.1, 0.001);  primals_332 = None
        getitem_181 = native_batch_norm_default_53[0]
        getitem_182 = native_batch_norm_default_53[1]
        getitem_183 = native_batch_norm_default_53[2];  native_batch_norm_default_53 = None
        new_zeros_default_53 = torch.ops.aten.new_zeros.default(convolution_default_98, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_52 = torch.ops.aten.relu.default(getitem_181);  getitem_181 = None
        convolution_default_99 = torch.ops.aten.convolution.default(relu_default_52, primals_344, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_100 = torch.ops.aten.convolution.default(convolution_default_99, primals_345, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_53 = torch.ops.aten.add_.Tensor(primals_338, 1);  primals_338 = None
        native_batch_norm_default_54 = torch.ops.aten.native_batch_norm.default(convolution_default_100, primals_341, primals_337, primals_339, primals_340, True, 0.1, 0.001);  primals_337 = None
        getitem_184 = native_batch_norm_default_54[0]
        getitem_185 = native_batch_norm_default_54[1]
        getitem_186 = native_batch_norm_default_54[2];  native_batch_norm_default_54 = None
        new_zeros_default_54 = torch.ops.aten.new_zeros.default(convolution_default_100, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_18 = torch.ops.aten.add.Tensor(getitem_178, getitem_184);  getitem_178 = getitem_184 = None
        relu_default_53 = torch.ops.aten.relu.default(add_tensor_18)
        convolution_default_101 = torch.ops.aten.convolution.default(relu_default_53, primals_356, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_102 = torch.ops.aten.convolution.default(convolution_default_101, primals_357, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_54 = torch.ops.aten.add_.Tensor(primals_347, 1);  primals_347 = None
        native_batch_norm_default_55 = torch.ops.aten.native_batch_norm.default(convolution_default_102, primals_350, primals_346, primals_348, primals_349, True, 0.1, 0.001);  primals_346 = None
        getitem_187 = native_batch_norm_default_55[0]
        getitem_188 = native_batch_norm_default_55[1]
        getitem_189 = native_batch_norm_default_55[2];  native_batch_norm_default_55 = None
        new_zeros_default_55 = torch.ops.aten.new_zeros.default(convolution_default_102, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_54 = torch.ops.aten.relu.default(getitem_187);  getitem_187 = None
        convolution_default_103 = torch.ops.aten.convolution.default(relu_default_54, primals_358, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_104 = torch.ops.aten.convolution.default(convolution_default_103, primals_359, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_55 = torch.ops.aten.add_.Tensor(primals_352, 1);  primals_352 = None
        native_batch_norm_default_56 = torch.ops.aten.native_batch_norm.default(convolution_default_104, primals_355, primals_351, primals_353, primals_354, True, 0.1, 0.001);  primals_351 = None
        getitem_190 = native_batch_norm_default_56[0]
        getitem_191 = native_batch_norm_default_56[1]
        getitem_192 = native_batch_norm_default_56[2];  native_batch_norm_default_56 = None
        new_zeros_default_56 = torch.ops.aten.new_zeros.default(convolution_default_104, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        max_pool2d_with_indices_default_11 = torch.ops.aten.max_pool2d_with_indices.default(getitem_156, [3, 3], [1, 1], [1, 1])
        getitem_193 = max_pool2d_with_indices_default_11[0]
        getitem_194 = max_pool2d_with_indices_default_11[1];  max_pool2d_with_indices_default_11 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(getitem_190, getitem_193);  getitem_190 = getitem_193 = None
        relu_default_55 = torch.ops.aten.relu.default(getitem_153)
        convolution_default_105 = torch.ops.aten.convolution.default(relu_default_55, primals_370, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_106 = torch.ops.aten.convolution.default(convolution_default_105, primals_371, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_56 = torch.ops.aten.add_.Tensor(primals_361, 1);  primals_361 = None
        native_batch_norm_default_57 = torch.ops.aten.native_batch_norm.default(convolution_default_106, primals_364, primals_360, primals_362, primals_363, True, 0.1, 0.001);  primals_360 = None
        getitem_195 = native_batch_norm_default_57[0]
        getitem_196 = native_batch_norm_default_57[1]
        getitem_197 = native_batch_norm_default_57[2];  native_batch_norm_default_57 = None
        new_zeros_default_57 = torch.ops.aten.new_zeros.default(convolution_default_106, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_56 = torch.ops.aten.relu.default(getitem_195);  getitem_195 = None
        convolution_default_107 = torch.ops.aten.convolution.default(relu_default_56, primals_372, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_108 = torch.ops.aten.convolution.default(convolution_default_107, primals_373, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_57 = torch.ops.aten.add_.Tensor(primals_366, 1);  primals_366 = None
        native_batch_norm_default_58 = torch.ops.aten.native_batch_norm.default(convolution_default_108, primals_369, primals_365, primals_367, primals_368, True, 0.1, 0.001);  primals_365 = None
        getitem_198 = native_batch_norm_default_58[0]
        getitem_199 = native_batch_norm_default_58[1]
        getitem_200 = native_batch_norm_default_58[2];  native_batch_norm_default_58 = None
        new_zeros_default_58 = torch.ops.aten.new_zeros.default(convolution_default_108, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_20 = torch.ops.aten.add.Tensor(getitem_198, getitem_156);  getitem_198 = None
        cat_default_5 = torch.ops.aten.cat.default([add_tensor_16, add_tensor_17, add_tensor_18, add_tensor_19, add_tensor_20], 1);  add_tensor_16 = add_tensor_17 = add_tensor_18 = add_tensor_19 = add_tensor_20 = None
        relu_default_57 = torch.ops.aten.relu.default(cat_default_4);  cat_default_4 = None
        convolution_default_109 = torch.ops.aten.convolution.default(relu_default_57, primals_481, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_58 = torch.ops.aten.add_.Tensor(primals_477, 1);  primals_477 = None
        native_batch_norm_default_59 = torch.ops.aten.native_batch_norm.default(convolution_default_109, primals_480, primals_476, primals_478, primals_479, True, 0.1, 0.001);  primals_476 = None
        getitem_201 = native_batch_norm_default_59[0]
        getitem_202 = native_batch_norm_default_59[1]
        getitem_203 = native_batch_norm_default_59[2];  native_batch_norm_default_59 = None
        new_zeros_default_59 = torch.ops.aten.new_zeros.default(convolution_default_109, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_58 = torch.ops.aten.relu.default(cat_default_5)
        convolution_default_110 = torch.ops.aten.convolution.default(relu_default_58, primals_475, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_59 = torch.ops.aten.add_.Tensor(primals_471, 1);  primals_471 = None
        native_batch_norm_default_60 = torch.ops.aten.native_batch_norm.default(convolution_default_110, primals_474, primals_470, primals_472, primals_473, True, 0.1, 0.001);  primals_470 = None
        getitem_204 = native_batch_norm_default_60[0]
        getitem_205 = native_batch_norm_default_60[1]
        getitem_206 = native_batch_norm_default_60[2];  native_batch_norm_default_60 = None
        new_zeros_default_60 = torch.ops.aten.new_zeros.default(convolution_default_110, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_59 = torch.ops.aten.relu.default(getitem_201)
        convolution_default_111 = torch.ops.aten.convolution.default(relu_default_59, primals_396, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 216)
        convolution_default_112 = torch.ops.aten.convolution.default(convolution_default_111, primals_397, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_60 = torch.ops.aten.add_.Tensor(primals_387, 1);  primals_387 = None
        native_batch_norm_default_61 = torch.ops.aten.native_batch_norm.default(convolution_default_112, primals_390, primals_386, primals_388, primals_389, True, 0.1, 0.001);  primals_386 = None
        getitem_207 = native_batch_norm_default_61[0]
        getitem_208 = native_batch_norm_default_61[1]
        getitem_209 = native_batch_norm_default_61[2];  native_batch_norm_default_61 = None
        new_zeros_default_61 = torch.ops.aten.new_zeros.default(convolution_default_112, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_60 = torch.ops.aten.relu.default(getitem_207);  getitem_207 = None
        convolution_default_113 = torch.ops.aten.convolution.default(relu_default_60, primals_398, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 216)
        convolution_default_114 = torch.ops.aten.convolution.default(convolution_default_113, primals_399, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_61 = torch.ops.aten.add_.Tensor(primals_392, 1);  primals_392 = None
        native_batch_norm_default_62 = torch.ops.aten.native_batch_norm.default(convolution_default_114, primals_395, primals_391, primals_393, primals_394, True, 0.1, 0.001);  primals_391 = None
        getitem_210 = native_batch_norm_default_62[0]
        getitem_211 = native_batch_norm_default_62[1]
        getitem_212 = native_batch_norm_default_62[2];  native_batch_norm_default_62 = None
        new_zeros_default_62 = torch.ops.aten.new_zeros.default(convolution_default_114, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        max_pool2d_with_indices_default_12 = torch.ops.aten.max_pool2d_with_indices.default(getitem_201, [3, 3], [1, 1], [1, 1])
        getitem_213 = max_pool2d_with_indices_default_12[0]
        getitem_214 = max_pool2d_with_indices_default_12[1];  max_pool2d_with_indices_default_12 = None
        add_tensor_21 = torch.ops.aten.add.Tensor(getitem_210, getitem_213);  getitem_210 = getitem_213 = None
        relu_default_61 = torch.ops.aten.relu.default(getitem_204)
        convolution_default_115 = torch.ops.aten.convolution.default(relu_default_61, primals_410, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 216)
        convolution_default_116 = torch.ops.aten.convolution.default(convolution_default_115, primals_411, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_62 = torch.ops.aten.add_.Tensor(primals_401, 1);  primals_401 = None
        native_batch_norm_default_63 = torch.ops.aten.native_batch_norm.default(convolution_default_116, primals_404, primals_400, primals_402, primals_403, True, 0.1, 0.001);  primals_400 = None
        getitem_215 = native_batch_norm_default_63[0]
        getitem_216 = native_batch_norm_default_63[1]
        getitem_217 = native_batch_norm_default_63[2];  native_batch_norm_default_63 = None
        new_zeros_default_63 = torch.ops.aten.new_zeros.default(convolution_default_116, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_62 = torch.ops.aten.relu.default(getitem_215);  getitem_215 = None
        convolution_default_117 = torch.ops.aten.convolution.default(relu_default_62, primals_412, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 216)
        convolution_default_118 = torch.ops.aten.convolution.default(convolution_default_117, primals_413, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_63 = torch.ops.aten.add_.Tensor(primals_406, 1);  primals_406 = None
        native_batch_norm_default_64 = torch.ops.aten.native_batch_norm.default(convolution_default_118, primals_409, primals_405, primals_407, primals_408, True, 0.1, 0.001);  primals_405 = None
        getitem_218 = native_batch_norm_default_64[0]
        getitem_219 = native_batch_norm_default_64[1]
        getitem_220 = native_batch_norm_default_64[2];  native_batch_norm_default_64 = None
        new_zeros_default_64 = torch.ops.aten.new_zeros.default(convolution_default_118, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        max_pool2d_with_indices_default_13 = torch.ops.aten.max_pool2d_with_indices.default(getitem_204, [3, 3], [1, 1], [1, 1])
        getitem_221 = max_pool2d_with_indices_default_13[0]
        getitem_222 = max_pool2d_with_indices_default_13[1];  max_pool2d_with_indices_default_13 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(getitem_218, getitem_221);  getitem_218 = getitem_221 = None
        relu_default_63 = torch.ops.aten.relu.default(getitem_204)
        convolution_default_119 = torch.ops.aten.convolution.default(relu_default_63, primals_424, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 216)
        convolution_default_120 = torch.ops.aten.convolution.default(convolution_default_119, primals_425, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_64 = torch.ops.aten.add_.Tensor(primals_415, 1);  primals_415 = None
        native_batch_norm_default_65 = torch.ops.aten.native_batch_norm.default(convolution_default_120, primals_418, primals_414, primals_416, primals_417, True, 0.1, 0.001);  primals_414 = None
        getitem_223 = native_batch_norm_default_65[0]
        getitem_224 = native_batch_norm_default_65[1]
        getitem_225 = native_batch_norm_default_65[2];  native_batch_norm_default_65 = None
        new_zeros_default_65 = torch.ops.aten.new_zeros.default(convolution_default_120, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_64 = torch.ops.aten.relu.default(getitem_223);  getitem_223 = None
        convolution_default_121 = torch.ops.aten.convolution.default(relu_default_64, primals_426, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 216)
        convolution_default_122 = torch.ops.aten.convolution.default(convolution_default_121, primals_427, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_65 = torch.ops.aten.add_.Tensor(primals_420, 1);  primals_420 = None
        native_batch_norm_default_66 = torch.ops.aten.native_batch_norm.default(convolution_default_122, primals_423, primals_419, primals_421, primals_422, True, 0.1, 0.001);  primals_419 = None
        getitem_226 = native_batch_norm_default_66[0]
        getitem_227 = native_batch_norm_default_66[1]
        getitem_228 = native_batch_norm_default_66[2];  native_batch_norm_default_66 = None
        new_zeros_default_66 = torch.ops.aten.new_zeros.default(convolution_default_122, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_65 = torch.ops.aten.relu.default(getitem_204)
        convolution_default_123 = torch.ops.aten.convolution.default(relu_default_65, primals_438, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_124 = torch.ops.aten.convolution.default(convolution_default_123, primals_439, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_66 = torch.ops.aten.add_.Tensor(primals_429, 1);  primals_429 = None
        native_batch_norm_default_67 = torch.ops.aten.native_batch_norm.default(convolution_default_124, primals_432, primals_428, primals_430, primals_431, True, 0.1, 0.001);  primals_428 = None
        getitem_229 = native_batch_norm_default_67[0]
        getitem_230 = native_batch_norm_default_67[1]
        getitem_231 = native_batch_norm_default_67[2];  native_batch_norm_default_67 = None
        new_zeros_default_67 = torch.ops.aten.new_zeros.default(convolution_default_124, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_66 = torch.ops.aten.relu.default(getitem_229);  getitem_229 = None
        convolution_default_125 = torch.ops.aten.convolution.default(relu_default_66, primals_440, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_126 = torch.ops.aten.convolution.default(convolution_default_125, primals_441, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_67 = torch.ops.aten.add_.Tensor(primals_434, 1);  primals_434 = None
        native_batch_norm_default_68 = torch.ops.aten.native_batch_norm.default(convolution_default_126, primals_437, primals_433, primals_435, primals_436, True, 0.1, 0.001);  primals_433 = None
        getitem_232 = native_batch_norm_default_68[0]
        getitem_233 = native_batch_norm_default_68[1]
        getitem_234 = native_batch_norm_default_68[2];  native_batch_norm_default_68 = None
        new_zeros_default_68 = torch.ops.aten.new_zeros.default(convolution_default_126, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_23 = torch.ops.aten.add.Tensor(getitem_226, getitem_232);  getitem_226 = getitem_232 = None
        relu_default_67 = torch.ops.aten.relu.default(add_tensor_23)
        convolution_default_127 = torch.ops.aten.convolution.default(relu_default_67, primals_452, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_128 = torch.ops.aten.convolution.default(convolution_default_127, primals_453, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_68 = torch.ops.aten.add_.Tensor(primals_443, 1);  primals_443 = None
        native_batch_norm_default_69 = torch.ops.aten.native_batch_norm.default(convolution_default_128, primals_446, primals_442, primals_444, primals_445, True, 0.1, 0.001);  primals_442 = None
        getitem_235 = native_batch_norm_default_69[0]
        getitem_236 = native_batch_norm_default_69[1]
        getitem_237 = native_batch_norm_default_69[2];  native_batch_norm_default_69 = None
        new_zeros_default_69 = torch.ops.aten.new_zeros.default(convolution_default_128, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_68 = torch.ops.aten.relu.default(getitem_235);  getitem_235 = None
        convolution_default_129 = torch.ops.aten.convolution.default(relu_default_68, primals_454, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_130 = torch.ops.aten.convolution.default(convolution_default_129, primals_455, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_69 = torch.ops.aten.add_.Tensor(primals_448, 1);  primals_448 = None
        native_batch_norm_default_70 = torch.ops.aten.native_batch_norm.default(convolution_default_130, primals_451, primals_447, primals_449, primals_450, True, 0.1, 0.001);  primals_447 = None
        getitem_238 = native_batch_norm_default_70[0]
        getitem_239 = native_batch_norm_default_70[1]
        getitem_240 = native_batch_norm_default_70[2];  native_batch_norm_default_70 = None
        new_zeros_default_70 = torch.ops.aten.new_zeros.default(convolution_default_130, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        max_pool2d_with_indices_default_14 = torch.ops.aten.max_pool2d_with_indices.default(getitem_204, [3, 3], [1, 1], [1, 1])
        getitem_241 = max_pool2d_with_indices_default_14[0]
        getitem_242 = max_pool2d_with_indices_default_14[1];  max_pool2d_with_indices_default_14 = None
        add_tensor_24 = torch.ops.aten.add.Tensor(getitem_238, getitem_241);  getitem_238 = getitem_241 = None
        relu_default_69 = torch.ops.aten.relu.default(getitem_201)
        convolution_default_131 = torch.ops.aten.convolution.default(relu_default_69, primals_466, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_132 = torch.ops.aten.convolution.default(convolution_default_131, primals_467, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_70 = torch.ops.aten.add_.Tensor(primals_457, 1);  primals_457 = None
        native_batch_norm_default_71 = torch.ops.aten.native_batch_norm.default(convolution_default_132, primals_460, primals_456, primals_458, primals_459, True, 0.1, 0.001);  primals_456 = None
        getitem_243 = native_batch_norm_default_71[0]
        getitem_244 = native_batch_norm_default_71[1]
        getitem_245 = native_batch_norm_default_71[2];  native_batch_norm_default_71 = None
        new_zeros_default_71 = torch.ops.aten.new_zeros.default(convolution_default_132, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_70 = torch.ops.aten.relu.default(getitem_243);  getitem_243 = None
        convolution_default_133 = torch.ops.aten.convolution.default(relu_default_70, primals_468, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_134 = torch.ops.aten.convolution.default(convolution_default_133, primals_469, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_71 = torch.ops.aten.add_.Tensor(primals_462, 1);  primals_462 = None
        native_batch_norm_default_72 = torch.ops.aten.native_batch_norm.default(convolution_default_134, primals_465, primals_461, primals_463, primals_464, True, 0.1, 0.001);  primals_461 = None
        getitem_246 = native_batch_norm_default_72[0]
        getitem_247 = native_batch_norm_default_72[1]
        getitem_248 = native_batch_norm_default_72[2];  native_batch_norm_default_72 = None
        new_zeros_default_72 = torch.ops.aten.new_zeros.default(convolution_default_134, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_25 = torch.ops.aten.add.Tensor(getitem_246, getitem_204);  getitem_246 = None
        cat_default_6 = torch.ops.aten.cat.default([add_tensor_21, add_tensor_22, add_tensor_23, add_tensor_24, add_tensor_25], 1);  add_tensor_21 = add_tensor_22 = add_tensor_23 = add_tensor_24 = add_tensor_25 = None
        relu_default_71 = torch.ops.aten.relu.default(cat_default_5);  cat_default_5 = None
        convolution_default_135 = torch.ops.aten.convolution.default(relu_default_71, primals_577, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_72 = torch.ops.aten.add_.Tensor(primals_573, 1);  primals_573 = None
        native_batch_norm_default_73 = torch.ops.aten.native_batch_norm.default(convolution_default_135, primals_576, primals_572, primals_574, primals_575, True, 0.1, 0.001);  primals_572 = None
        getitem_249 = native_batch_norm_default_73[0]
        getitem_250 = native_batch_norm_default_73[1]
        getitem_251 = native_batch_norm_default_73[2];  native_batch_norm_default_73 = None
        new_zeros_default_73 = torch.ops.aten.new_zeros.default(convolution_default_135, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_72 = torch.ops.aten.relu.default(cat_default_6)
        convolution_default_136 = torch.ops.aten.convolution.default(relu_default_72, primals_571, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_73 = torch.ops.aten.add_.Tensor(primals_567, 1);  primals_567 = None
        native_batch_norm_default_74 = torch.ops.aten.native_batch_norm.default(convolution_default_136, primals_570, primals_566, primals_568, primals_569, True, 0.1, 0.001);  primals_566 = None
        getitem_252 = native_batch_norm_default_74[0]
        getitem_253 = native_batch_norm_default_74[1]
        getitem_254 = native_batch_norm_default_74[2];  native_batch_norm_default_74 = None
        new_zeros_default_74 = torch.ops.aten.new_zeros.default(convolution_default_136, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_73 = torch.ops.aten.relu.default(getitem_249)
        convolution_default_137 = torch.ops.aten.convolution.default(relu_default_73, primals_492, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 216)
        convolution_default_138 = torch.ops.aten.convolution.default(convolution_default_137, primals_493, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_74 = torch.ops.aten.add_.Tensor(primals_483, 1);  primals_483 = None
        native_batch_norm_default_75 = torch.ops.aten.native_batch_norm.default(convolution_default_138, primals_486, primals_482, primals_484, primals_485, True, 0.1, 0.001);  primals_482 = None
        getitem_255 = native_batch_norm_default_75[0]
        getitem_256 = native_batch_norm_default_75[1]
        getitem_257 = native_batch_norm_default_75[2];  native_batch_norm_default_75 = None
        new_zeros_default_75 = torch.ops.aten.new_zeros.default(convolution_default_138, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_74 = torch.ops.aten.relu.default(getitem_255);  getitem_255 = None
        convolution_default_139 = torch.ops.aten.convolution.default(relu_default_74, primals_494, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 216)
        convolution_default_140 = torch.ops.aten.convolution.default(convolution_default_139, primals_495, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_75 = torch.ops.aten.add_.Tensor(primals_488, 1);  primals_488 = None
        native_batch_norm_default_76 = torch.ops.aten.native_batch_norm.default(convolution_default_140, primals_491, primals_487, primals_489, primals_490, True, 0.1, 0.001);  primals_487 = None
        getitem_258 = native_batch_norm_default_76[0]
        getitem_259 = native_batch_norm_default_76[1]
        getitem_260 = native_batch_norm_default_76[2];  native_batch_norm_default_76 = None
        new_zeros_default_76 = torch.ops.aten.new_zeros.default(convolution_default_140, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        max_pool2d_with_indices_default_15 = torch.ops.aten.max_pool2d_with_indices.default(getitem_249, [3, 3], [1, 1], [1, 1])
        getitem_261 = max_pool2d_with_indices_default_15[0]
        getitem_262 = max_pool2d_with_indices_default_15[1];  max_pool2d_with_indices_default_15 = None
        add_tensor_26 = torch.ops.aten.add.Tensor(getitem_258, getitem_261);  getitem_258 = getitem_261 = None
        relu_default_75 = torch.ops.aten.relu.default(getitem_252)
        convolution_default_141 = torch.ops.aten.convolution.default(relu_default_75, primals_506, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 216)
        convolution_default_142 = torch.ops.aten.convolution.default(convolution_default_141, primals_507, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_76 = torch.ops.aten.add_.Tensor(primals_497, 1);  primals_497 = None
        native_batch_norm_default_77 = torch.ops.aten.native_batch_norm.default(convolution_default_142, primals_500, primals_496, primals_498, primals_499, True, 0.1, 0.001);  primals_496 = None
        getitem_263 = native_batch_norm_default_77[0]
        getitem_264 = native_batch_norm_default_77[1]
        getitem_265 = native_batch_norm_default_77[2];  native_batch_norm_default_77 = None
        new_zeros_default_77 = torch.ops.aten.new_zeros.default(convolution_default_142, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_76 = torch.ops.aten.relu.default(getitem_263);  getitem_263 = None
        convolution_default_143 = torch.ops.aten.convolution.default(relu_default_76, primals_508, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 216)
        convolution_default_144 = torch.ops.aten.convolution.default(convolution_default_143, primals_509, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_77 = torch.ops.aten.add_.Tensor(primals_502, 1);  primals_502 = None
        native_batch_norm_default_78 = torch.ops.aten.native_batch_norm.default(convolution_default_144, primals_505, primals_501, primals_503, primals_504, True, 0.1, 0.001);  primals_501 = None
        getitem_266 = native_batch_norm_default_78[0]
        getitem_267 = native_batch_norm_default_78[1]
        getitem_268 = native_batch_norm_default_78[2];  native_batch_norm_default_78 = None
        new_zeros_default_78 = torch.ops.aten.new_zeros.default(convolution_default_144, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        max_pool2d_with_indices_default_16 = torch.ops.aten.max_pool2d_with_indices.default(getitem_252, [3, 3], [1, 1], [1, 1])
        getitem_269 = max_pool2d_with_indices_default_16[0]
        getitem_270 = max_pool2d_with_indices_default_16[1];  max_pool2d_with_indices_default_16 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(getitem_266, getitem_269);  getitem_266 = getitem_269 = None
        relu_default_77 = torch.ops.aten.relu.default(getitem_252)
        convolution_default_145 = torch.ops.aten.convolution.default(relu_default_77, primals_520, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 216)
        convolution_default_146 = torch.ops.aten.convolution.default(convolution_default_145, primals_521, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_78 = torch.ops.aten.add_.Tensor(primals_511, 1);  primals_511 = None
        native_batch_norm_default_79 = torch.ops.aten.native_batch_norm.default(convolution_default_146, primals_514, primals_510, primals_512, primals_513, True, 0.1, 0.001);  primals_510 = None
        getitem_271 = native_batch_norm_default_79[0]
        getitem_272 = native_batch_norm_default_79[1]
        getitem_273 = native_batch_norm_default_79[2];  native_batch_norm_default_79 = None
        new_zeros_default_79 = torch.ops.aten.new_zeros.default(convolution_default_146, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_78 = torch.ops.aten.relu.default(getitem_271);  getitem_271 = None
        convolution_default_147 = torch.ops.aten.convolution.default(relu_default_78, primals_522, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 216)
        convolution_default_148 = torch.ops.aten.convolution.default(convolution_default_147, primals_523, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_79 = torch.ops.aten.add_.Tensor(primals_516, 1);  primals_516 = None
        native_batch_norm_default_80 = torch.ops.aten.native_batch_norm.default(convolution_default_148, primals_519, primals_515, primals_517, primals_518, True, 0.1, 0.001);  primals_515 = None
        getitem_274 = native_batch_norm_default_80[0]
        getitem_275 = native_batch_norm_default_80[1]
        getitem_276 = native_batch_norm_default_80[2];  native_batch_norm_default_80 = None
        new_zeros_default_80 = torch.ops.aten.new_zeros.default(convolution_default_148, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_79 = torch.ops.aten.relu.default(getitem_252)
        convolution_default_149 = torch.ops.aten.convolution.default(relu_default_79, primals_534, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_150 = torch.ops.aten.convolution.default(convolution_default_149, primals_535, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_80 = torch.ops.aten.add_.Tensor(primals_525, 1);  primals_525 = None
        native_batch_norm_default_81 = torch.ops.aten.native_batch_norm.default(convolution_default_150, primals_528, primals_524, primals_526, primals_527, True, 0.1, 0.001);  primals_524 = None
        getitem_277 = native_batch_norm_default_81[0]
        getitem_278 = native_batch_norm_default_81[1]
        getitem_279 = native_batch_norm_default_81[2];  native_batch_norm_default_81 = None
        new_zeros_default_81 = torch.ops.aten.new_zeros.default(convolution_default_150, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_80 = torch.ops.aten.relu.default(getitem_277);  getitem_277 = None
        convolution_default_151 = torch.ops.aten.convolution.default(relu_default_80, primals_536, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_152 = torch.ops.aten.convolution.default(convolution_default_151, primals_537, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_81 = torch.ops.aten.add_.Tensor(primals_530, 1);  primals_530 = None
        native_batch_norm_default_82 = torch.ops.aten.native_batch_norm.default(convolution_default_152, primals_533, primals_529, primals_531, primals_532, True, 0.1, 0.001);  primals_529 = None
        getitem_280 = native_batch_norm_default_82[0]
        getitem_281 = native_batch_norm_default_82[1]
        getitem_282 = native_batch_norm_default_82[2];  native_batch_norm_default_82 = None
        new_zeros_default_82 = torch.ops.aten.new_zeros.default(convolution_default_152, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_28 = torch.ops.aten.add.Tensor(getitem_274, getitem_280);  getitem_274 = getitem_280 = None
        relu_default_81 = torch.ops.aten.relu.default(add_tensor_28)
        convolution_default_153 = torch.ops.aten.convolution.default(relu_default_81, primals_548, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_154 = torch.ops.aten.convolution.default(convolution_default_153, primals_549, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_82 = torch.ops.aten.add_.Tensor(primals_539, 1);  primals_539 = None
        native_batch_norm_default_83 = torch.ops.aten.native_batch_norm.default(convolution_default_154, primals_542, primals_538, primals_540, primals_541, True, 0.1, 0.001);  primals_538 = None
        getitem_283 = native_batch_norm_default_83[0]
        getitem_284 = native_batch_norm_default_83[1]
        getitem_285 = native_batch_norm_default_83[2];  native_batch_norm_default_83 = None
        new_zeros_default_83 = torch.ops.aten.new_zeros.default(convolution_default_154, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_82 = torch.ops.aten.relu.default(getitem_283);  getitem_283 = None
        convolution_default_155 = torch.ops.aten.convolution.default(relu_default_82, primals_550, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_156 = torch.ops.aten.convolution.default(convolution_default_155, primals_551, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_83 = torch.ops.aten.add_.Tensor(primals_544, 1);  primals_544 = None
        native_batch_norm_default_84 = torch.ops.aten.native_batch_norm.default(convolution_default_156, primals_547, primals_543, primals_545, primals_546, True, 0.1, 0.001);  primals_543 = None
        getitem_286 = native_batch_norm_default_84[0]
        getitem_287 = native_batch_norm_default_84[1]
        getitem_288 = native_batch_norm_default_84[2];  native_batch_norm_default_84 = None
        new_zeros_default_84 = torch.ops.aten.new_zeros.default(convolution_default_156, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        max_pool2d_with_indices_default_17 = torch.ops.aten.max_pool2d_with_indices.default(getitem_252, [3, 3], [1, 1], [1, 1])
        getitem_289 = max_pool2d_with_indices_default_17[0]
        getitem_290 = max_pool2d_with_indices_default_17[1];  max_pool2d_with_indices_default_17 = None
        add_tensor_29 = torch.ops.aten.add.Tensor(getitem_286, getitem_289);  getitem_286 = getitem_289 = None
        relu_default_83 = torch.ops.aten.relu.default(getitem_249)
        convolution_default_157 = torch.ops.aten.convolution.default(relu_default_83, primals_562, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_158 = torch.ops.aten.convolution.default(convolution_default_157, primals_563, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_84 = torch.ops.aten.add_.Tensor(primals_553, 1);  primals_553 = None
        native_batch_norm_default_85 = torch.ops.aten.native_batch_norm.default(convolution_default_158, primals_556, primals_552, primals_554, primals_555, True, 0.1, 0.001);  primals_552 = None
        getitem_291 = native_batch_norm_default_85[0]
        getitem_292 = native_batch_norm_default_85[1]
        getitem_293 = native_batch_norm_default_85[2];  native_batch_norm_default_85 = None
        new_zeros_default_85 = torch.ops.aten.new_zeros.default(convolution_default_158, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_84 = torch.ops.aten.relu.default(getitem_291);  getitem_291 = None
        convolution_default_159 = torch.ops.aten.convolution.default(relu_default_84, primals_564, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_160 = torch.ops.aten.convolution.default(convolution_default_159, primals_565, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_85 = torch.ops.aten.add_.Tensor(primals_558, 1);  primals_558 = None
        native_batch_norm_default_86 = torch.ops.aten.native_batch_norm.default(convolution_default_160, primals_561, primals_557, primals_559, primals_560, True, 0.1, 0.001);  primals_557 = None
        getitem_294 = native_batch_norm_default_86[0]
        getitem_295 = native_batch_norm_default_86[1]
        getitem_296 = native_batch_norm_default_86[2];  native_batch_norm_default_86 = None
        new_zeros_default_86 = torch.ops.aten.new_zeros.default(convolution_default_160, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_30 = torch.ops.aten.add.Tensor(getitem_294, getitem_252);  getitem_294 = None
        cat_default_7 = torch.ops.aten.cat.default([add_tensor_26, add_tensor_27, add_tensor_28, add_tensor_29, add_tensor_30], 1);  add_tensor_26 = add_tensor_27 = add_tensor_28 = add_tensor_29 = add_tensor_30 = None
        relu_default_85 = torch.ops.aten.relu.default(cat_default_6);  cat_default_6 = None
        convolution_default_161 = torch.ops.aten.convolution.default(relu_default_85, primals_679, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_86 = torch.ops.aten.add_.Tensor(primals_675, 1);  primals_675 = None
        native_batch_norm_default_87 = torch.ops.aten.native_batch_norm.default(convolution_default_161, primals_678, primals_674, primals_676, primals_677, True, 0.1, 0.001);  primals_674 = None
        getitem_297 = native_batch_norm_default_87[0]
        getitem_298 = native_batch_norm_default_87[1]
        getitem_299 = native_batch_norm_default_87[2];  native_batch_norm_default_87 = None
        new_zeros_default_87 = torch.ops.aten.new_zeros.default(convolution_default_161, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_86 = torch.ops.aten.relu.default(cat_default_7)
        convolution_default_162 = torch.ops.aten.convolution.default(relu_default_86, primals_673, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_87 = torch.ops.aten.add_.Tensor(primals_669, 1);  primals_669 = None
        native_batch_norm_default_88 = torch.ops.aten.native_batch_norm.default(convolution_default_162, primals_672, primals_668, primals_670, primals_671, True, 0.1, 0.001);  primals_668 = None
        getitem_300 = native_batch_norm_default_88[0]
        getitem_301 = native_batch_norm_default_88[1]
        getitem_302 = native_batch_norm_default_88[2];  native_batch_norm_default_88 = None
        new_zeros_default_88 = torch.ops.aten.new_zeros.default(convolution_default_162, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_87 = torch.ops.aten.relu.default(getitem_297)
        constant_pad_nd_default_18 = torch.ops.aten.constant_pad_nd.default(relu_default_87, [1, 2, 1, 2], 0.0)
        convolution_default_163 = torch.ops.aten.convolution.default(constant_pad_nd_default_18, primals_588, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 432)
        convolution_default_164 = torch.ops.aten.convolution.default(convolution_default_163, primals_589, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_88 = torch.ops.aten.add_.Tensor(primals_579, 1);  primals_579 = None
        native_batch_norm_default_89 = torch.ops.aten.native_batch_norm.default(convolution_default_164, primals_582, primals_578, primals_580, primals_581, True, 0.1, 0.001);  primals_578 = None
        getitem_303 = native_batch_norm_default_89[0]
        getitem_304 = native_batch_norm_default_89[1]
        getitem_305 = native_batch_norm_default_89[2];  native_batch_norm_default_89 = None
        new_zeros_default_89 = torch.ops.aten.new_zeros.default(convolution_default_164, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_88 = torch.ops.aten.relu.default(getitem_303);  getitem_303 = None
        convolution_default_165 = torch.ops.aten.convolution.default(relu_default_88, primals_590, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 432)
        convolution_default_166 = torch.ops.aten.convolution.default(convolution_default_165, primals_591, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_89 = torch.ops.aten.add_.Tensor(primals_584, 1);  primals_584 = None
        native_batch_norm_default_90 = torch.ops.aten.native_batch_norm.default(convolution_default_166, primals_587, primals_583, primals_585, primals_586, True, 0.1, 0.001);  primals_583 = None
        getitem_306 = native_batch_norm_default_90[0]
        getitem_307 = native_batch_norm_default_90[1]
        getitem_308 = native_batch_norm_default_90[2];  native_batch_norm_default_90 = None
        new_zeros_default_90 = torch.ops.aten.new_zeros.default(convolution_default_166, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        constant_pad_nd_default_19 = torch.ops.aten.constant_pad_nd.default(getitem_297, [0, 1, 0, 1], -inf)
        max_pool2d_with_indices_default_18 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_19, [3, 3], [2, 2])
        getitem_309 = max_pool2d_with_indices_default_18[0]
        getitem_310 = max_pool2d_with_indices_default_18[1];  max_pool2d_with_indices_default_18 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(getitem_306, getitem_309);  getitem_306 = getitem_309 = None
        relu_default_89 = torch.ops.aten.relu.default(getitem_300)
        constant_pad_nd_default_20 = torch.ops.aten.constant_pad_nd.default(relu_default_89, [2, 3, 2, 3], 0.0)
        convolution_default_167 = torch.ops.aten.convolution.default(constant_pad_nd_default_20, primals_602, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 432)
        convolution_default_168 = torch.ops.aten.convolution.default(convolution_default_167, primals_603, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_90 = torch.ops.aten.add_.Tensor(primals_593, 1);  primals_593 = None
        native_batch_norm_default_91 = torch.ops.aten.native_batch_norm.default(convolution_default_168, primals_596, primals_592, primals_594, primals_595, True, 0.1, 0.001);  primals_592 = None
        getitem_311 = native_batch_norm_default_91[0]
        getitem_312 = native_batch_norm_default_91[1]
        getitem_313 = native_batch_norm_default_91[2];  native_batch_norm_default_91 = None
        new_zeros_default_91 = torch.ops.aten.new_zeros.default(convolution_default_168, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_90 = torch.ops.aten.relu.default(getitem_311);  getitem_311 = None
        convolution_default_169 = torch.ops.aten.convolution.default(relu_default_90, primals_604, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 432)
        convolution_default_170 = torch.ops.aten.convolution.default(convolution_default_169, primals_605, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_91 = torch.ops.aten.add_.Tensor(primals_598, 1);  primals_598 = None
        native_batch_norm_default_92 = torch.ops.aten.native_batch_norm.default(convolution_default_170, primals_601, primals_597, primals_599, primals_600, True, 0.1, 0.001);  primals_597 = None
        getitem_314 = native_batch_norm_default_92[0]
        getitem_315 = native_batch_norm_default_92[1]
        getitem_316 = native_batch_norm_default_92[2];  native_batch_norm_default_92 = None
        new_zeros_default_92 = torch.ops.aten.new_zeros.default(convolution_default_170, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        constant_pad_nd_default_21 = torch.ops.aten.constant_pad_nd.default(getitem_300, [0, 1, 0, 1], -inf)
        max_pool2d_with_indices_default_19 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_21, [3, 3], [2, 2])
        getitem_317 = max_pool2d_with_indices_default_19[0]
        getitem_318 = max_pool2d_with_indices_default_19[1];  max_pool2d_with_indices_default_19 = None
        add_tensor_32 = torch.ops.aten.add.Tensor(getitem_314, getitem_317);  getitem_314 = getitem_317 = None
        relu_default_91 = torch.ops.aten.relu.default(getitem_300)
        constant_pad_nd_default_22 = torch.ops.aten.constant_pad_nd.default(relu_default_91, [1, 2, 1, 2], 0.0)
        convolution_default_171 = torch.ops.aten.convolution.default(constant_pad_nd_default_22, primals_616, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 432)
        convolution_default_172 = torch.ops.aten.convolution.default(convolution_default_171, primals_617, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_92 = torch.ops.aten.add_.Tensor(primals_607, 1);  primals_607 = None
        native_batch_norm_default_93 = torch.ops.aten.native_batch_norm.default(convolution_default_172, primals_610, primals_606, primals_608, primals_609, True, 0.1, 0.001);  primals_606 = None
        getitem_319 = native_batch_norm_default_93[0]
        getitem_320 = native_batch_norm_default_93[1]
        getitem_321 = native_batch_norm_default_93[2];  native_batch_norm_default_93 = None
        new_zeros_default_93 = torch.ops.aten.new_zeros.default(convolution_default_172, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_92 = torch.ops.aten.relu.default(getitem_319);  getitem_319 = None
        convolution_default_173 = torch.ops.aten.convolution.default(relu_default_92, primals_618, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 432)
        convolution_default_174 = torch.ops.aten.convolution.default(convolution_default_173, primals_619, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_93 = torch.ops.aten.add_.Tensor(primals_612, 1);  primals_612 = None
        native_batch_norm_default_94 = torch.ops.aten.native_batch_norm.default(convolution_default_174, primals_615, primals_611, primals_613, primals_614, True, 0.1, 0.001);  primals_611 = None
        getitem_322 = native_batch_norm_default_94[0]
        getitem_323 = native_batch_norm_default_94[1]
        getitem_324 = native_batch_norm_default_94[2];  native_batch_norm_default_94 = None
        new_zeros_default_94 = torch.ops.aten.new_zeros.default(convolution_default_174, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_93 = torch.ops.aten.relu.default(getitem_300)
        constant_pad_nd_default_23 = torch.ops.aten.constant_pad_nd.default(relu_default_93, [0, 1, 0, 1], 0.0)
        convolution_default_175 = torch.ops.aten.convolution.default(constant_pad_nd_default_23, primals_630, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 432)
        convolution_default_176 = torch.ops.aten.convolution.default(convolution_default_175, primals_631, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_94 = torch.ops.aten.add_.Tensor(primals_621, 1);  primals_621 = None
        native_batch_norm_default_95 = torch.ops.aten.native_batch_norm.default(convolution_default_176, primals_624, primals_620, primals_622, primals_623, True, 0.1, 0.001);  primals_620 = None
        getitem_325 = native_batch_norm_default_95[0]
        getitem_326 = native_batch_norm_default_95[1]
        getitem_327 = native_batch_norm_default_95[2];  native_batch_norm_default_95 = None
        new_zeros_default_95 = torch.ops.aten.new_zeros.default(convolution_default_176, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_94 = torch.ops.aten.relu.default(getitem_325);  getitem_325 = None
        convolution_default_177 = torch.ops.aten.convolution.default(relu_default_94, primals_632, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_178 = torch.ops.aten.convolution.default(convolution_default_177, primals_633, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_95 = torch.ops.aten.add_.Tensor(primals_626, 1);  primals_626 = None
        native_batch_norm_default_96 = torch.ops.aten.native_batch_norm.default(convolution_default_178, primals_629, primals_625, primals_627, primals_628, True, 0.1, 0.001);  primals_625 = None
        getitem_328 = native_batch_norm_default_96[0]
        getitem_329 = native_batch_norm_default_96[1]
        getitem_330 = native_batch_norm_default_96[2];  native_batch_norm_default_96 = None
        new_zeros_default_96 = torch.ops.aten.new_zeros.default(convolution_default_178, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_33 = torch.ops.aten.add.Tensor(getitem_322, getitem_328);  getitem_322 = getitem_328 = None
        relu_default_95 = torch.ops.aten.relu.default(add_tensor_33)
        convolution_default_179 = torch.ops.aten.convolution.default(relu_default_95, primals_644, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_180 = torch.ops.aten.convolution.default(convolution_default_179, primals_645, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_96 = torch.ops.aten.add_.Tensor(primals_635, 1);  primals_635 = None
        native_batch_norm_default_97 = torch.ops.aten.native_batch_norm.default(convolution_default_180, primals_638, primals_634, primals_636, primals_637, True, 0.1, 0.001);  primals_634 = None
        getitem_331 = native_batch_norm_default_97[0]
        getitem_332 = native_batch_norm_default_97[1]
        getitem_333 = native_batch_norm_default_97[2];  native_batch_norm_default_97 = None
        new_zeros_default_97 = torch.ops.aten.new_zeros.default(convolution_default_180, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_96 = torch.ops.aten.relu.default(getitem_331);  getitem_331 = None
        convolution_default_181 = torch.ops.aten.convolution.default(relu_default_96, primals_646, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_182 = torch.ops.aten.convolution.default(convolution_default_181, primals_647, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_97 = torch.ops.aten.add_.Tensor(primals_640, 1);  primals_640 = None
        native_batch_norm_default_98 = torch.ops.aten.native_batch_norm.default(convolution_default_182, primals_643, primals_639, primals_641, primals_642, True, 0.1, 0.001);  primals_639 = None
        getitem_334 = native_batch_norm_default_98[0]
        getitem_335 = native_batch_norm_default_98[1]
        getitem_336 = native_batch_norm_default_98[2];  native_batch_norm_default_98 = None
        new_zeros_default_98 = torch.ops.aten.new_zeros.default(convolution_default_182, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        constant_pad_nd_default_24 = torch.ops.aten.constant_pad_nd.default(getitem_300, [0, 1, 0, 1], -inf)
        max_pool2d_with_indices_default_20 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_24, [3, 3], [2, 2])
        getitem_337 = max_pool2d_with_indices_default_20[0]
        getitem_338 = max_pool2d_with_indices_default_20[1];  max_pool2d_with_indices_default_20 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(getitem_334, getitem_337);  getitem_334 = getitem_337 = None
        relu_default_97 = torch.ops.aten.relu.default(getitem_297);  getitem_297 = None
        constant_pad_nd_default_25 = torch.ops.aten.constant_pad_nd.default(relu_default_97, [0, 1, 0, 1], 0.0)
        convolution_default_183 = torch.ops.aten.convolution.default(constant_pad_nd_default_25, primals_658, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 432)
        convolution_default_184 = torch.ops.aten.convolution.default(convolution_default_183, primals_659, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_98 = torch.ops.aten.add_.Tensor(primals_649, 1);  primals_649 = None
        native_batch_norm_default_99 = torch.ops.aten.native_batch_norm.default(convolution_default_184, primals_652, primals_648, primals_650, primals_651, True, 0.1, 0.001);  primals_648 = None
        getitem_339 = native_batch_norm_default_99[0]
        getitem_340 = native_batch_norm_default_99[1]
        getitem_341 = native_batch_norm_default_99[2];  native_batch_norm_default_99 = None
        new_zeros_default_99 = torch.ops.aten.new_zeros.default(convolution_default_184, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_98 = torch.ops.aten.relu.default(getitem_339);  getitem_339 = None
        convolution_default_185 = torch.ops.aten.convolution.default(relu_default_98, primals_660, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_186 = torch.ops.aten.convolution.default(convolution_default_185, primals_661, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_99 = torch.ops.aten.add_.Tensor(primals_654, 1);  primals_654 = None
        native_batch_norm_default_100 = torch.ops.aten.native_batch_norm.default(convolution_default_186, primals_657, primals_653, primals_655, primals_656, True, 0.1, 0.001);  primals_653 = None
        getitem_342 = native_batch_norm_default_100[0]
        getitem_343 = native_batch_norm_default_100[1]
        getitem_344 = native_batch_norm_default_100[2];  native_batch_norm_default_100 = None
        new_zeros_default_100 = torch.ops.aten.new_zeros.default(convolution_default_186, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_99 = torch.ops.aten.relu.default(getitem_300);  getitem_300 = None
        convolution_default_187 = torch.ops.aten.convolution.default(relu_default_99, primals_667, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_100 = torch.ops.aten.add_.Tensor(primals_663, 1);  primals_663 = None
        native_batch_norm_default_101 = torch.ops.aten.native_batch_norm.default(convolution_default_187, primals_666, primals_662, primals_664, primals_665, True, 0.1, 0.001);  primals_662 = None
        getitem_345 = native_batch_norm_default_101[0]
        getitem_346 = native_batch_norm_default_101[1]
        getitem_347 = native_batch_norm_default_101[2];  native_batch_norm_default_101 = None
        new_zeros_default_101 = torch.ops.aten.new_zeros.default(convolution_default_187, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_35 = torch.ops.aten.add.Tensor(getitem_342, getitem_345);  getitem_342 = getitem_345 = None
        cat_default_8 = torch.ops.aten.cat.default([add_tensor_31, add_tensor_32, add_tensor_33, add_tensor_34, add_tensor_35], 1);  add_tensor_31 = add_tensor_32 = add_tensor_33 = add_tensor_34 = add_tensor_35 = None
        relu_default_100 = torch.ops.aten.relu.default(cat_default_7);  cat_default_7 = None
        avg_pool2d_default_4 = torch.ops.aten.avg_pool2d.default(relu_default_100, [1, 1], [2, 2], [0, 0], False, False)
        convolution_default_188 = torch.ops.aten.convolution.default(avg_pool2d_default_4, primals_775, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        constant_pad_nd_default_26 = torch.ops.aten.constant_pad_nd.default(relu_default_100, [-1, 1, -1, 1], 0.0)
        avg_pool2d_default_5 = torch.ops.aten.avg_pool2d.default(constant_pad_nd_default_26, [1, 1], [2, 2], [0, 0], False, False)
        convolution_default_189 = torch.ops.aten.convolution.default(avg_pool2d_default_5, primals_776, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_9 = torch.ops.aten.cat.default([convolution_default_188, convolution_default_189], 1);  convolution_default_188 = convolution_default_189 = None
        add__tensor_101 = torch.ops.aten.add_.Tensor(primals_771, 1);  primals_771 = None
        native_batch_norm_default_102 = torch.ops.aten.native_batch_norm.default(cat_default_9, primals_774, primals_770, primals_772, primals_773, True, 0.1, 0.001);  primals_770 = None
        getitem_348 = native_batch_norm_default_102[0]
        getitem_349 = native_batch_norm_default_102[1]
        getitem_350 = native_batch_norm_default_102[2];  native_batch_norm_default_102 = None
        new_zeros_default_102 = torch.ops.aten.new_zeros.default(cat_default_9, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_101 = torch.ops.aten.relu.default(cat_default_8)
        convolution_default_190 = torch.ops.aten.convolution.default(relu_default_101, primals_769, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_102 = torch.ops.aten.add_.Tensor(primals_765, 1);  primals_765 = None
        native_batch_norm_default_103 = torch.ops.aten.native_batch_norm.default(convolution_default_190, primals_768, primals_764, primals_766, primals_767, True, 0.1, 0.001);  primals_764 = None
        getitem_351 = native_batch_norm_default_103[0]
        getitem_352 = native_batch_norm_default_103[1]
        getitem_353 = native_batch_norm_default_103[2];  native_batch_norm_default_103 = None
        new_zeros_default_103 = torch.ops.aten.new_zeros.default(convolution_default_190, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_102 = torch.ops.aten.relu.default(getitem_348)
        convolution_default_191 = torch.ops.aten.convolution.default(relu_default_102, primals_690, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 432)
        convolution_default_192 = torch.ops.aten.convolution.default(convolution_default_191, primals_691, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_103 = torch.ops.aten.add_.Tensor(primals_681, 1);  primals_681 = None
        native_batch_norm_default_104 = torch.ops.aten.native_batch_norm.default(convolution_default_192, primals_684, primals_680, primals_682, primals_683, True, 0.1, 0.001);  primals_680 = None
        getitem_354 = native_batch_norm_default_104[0]
        getitem_355 = native_batch_norm_default_104[1]
        getitem_356 = native_batch_norm_default_104[2];  native_batch_norm_default_104 = None
        new_zeros_default_104 = torch.ops.aten.new_zeros.default(convolution_default_192, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_103 = torch.ops.aten.relu.default(getitem_354);  getitem_354 = None
        convolution_default_193 = torch.ops.aten.convolution.default(relu_default_103, primals_692, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 432)
        convolution_default_194 = torch.ops.aten.convolution.default(convolution_default_193, primals_693, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_104 = torch.ops.aten.add_.Tensor(primals_686, 1);  primals_686 = None
        native_batch_norm_default_105 = torch.ops.aten.native_batch_norm.default(convolution_default_194, primals_689, primals_685, primals_687, primals_688, True, 0.1, 0.001);  primals_685 = None
        getitem_357 = native_batch_norm_default_105[0]
        getitem_358 = native_batch_norm_default_105[1]
        getitem_359 = native_batch_norm_default_105[2];  native_batch_norm_default_105 = None
        new_zeros_default_105 = torch.ops.aten.new_zeros.default(convolution_default_194, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        max_pool2d_with_indices_default_21 = torch.ops.aten.max_pool2d_with_indices.default(getitem_348, [3, 3], [1, 1], [1, 1])
        getitem_360 = max_pool2d_with_indices_default_21[0]
        getitem_361 = max_pool2d_with_indices_default_21[1];  max_pool2d_with_indices_default_21 = None
        add_tensor_36 = torch.ops.aten.add.Tensor(getitem_357, getitem_360);  getitem_357 = getitem_360 = None
        relu_default_104 = torch.ops.aten.relu.default(getitem_351)
        convolution_default_195 = torch.ops.aten.convolution.default(relu_default_104, primals_704, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 432)
        convolution_default_196 = torch.ops.aten.convolution.default(convolution_default_195, primals_705, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_105 = torch.ops.aten.add_.Tensor(primals_695, 1);  primals_695 = None
        native_batch_norm_default_106 = torch.ops.aten.native_batch_norm.default(convolution_default_196, primals_698, primals_694, primals_696, primals_697, True, 0.1, 0.001);  primals_694 = None
        getitem_362 = native_batch_norm_default_106[0]
        getitem_363 = native_batch_norm_default_106[1]
        getitem_364 = native_batch_norm_default_106[2];  native_batch_norm_default_106 = None
        new_zeros_default_106 = torch.ops.aten.new_zeros.default(convolution_default_196, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_105 = torch.ops.aten.relu.default(getitem_362);  getitem_362 = None
        convolution_default_197 = torch.ops.aten.convolution.default(relu_default_105, primals_706, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 432)
        convolution_default_198 = torch.ops.aten.convolution.default(convolution_default_197, primals_707, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_106 = torch.ops.aten.add_.Tensor(primals_700, 1);  primals_700 = None
        native_batch_norm_default_107 = torch.ops.aten.native_batch_norm.default(convolution_default_198, primals_703, primals_699, primals_701, primals_702, True, 0.1, 0.001);  primals_699 = None
        getitem_365 = native_batch_norm_default_107[0]
        getitem_366 = native_batch_norm_default_107[1]
        getitem_367 = native_batch_norm_default_107[2];  native_batch_norm_default_107 = None
        new_zeros_default_107 = torch.ops.aten.new_zeros.default(convolution_default_198, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        max_pool2d_with_indices_default_22 = torch.ops.aten.max_pool2d_with_indices.default(getitem_351, [3, 3], [1, 1], [1, 1])
        getitem_368 = max_pool2d_with_indices_default_22[0]
        getitem_369 = max_pool2d_with_indices_default_22[1];  max_pool2d_with_indices_default_22 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(getitem_365, getitem_368);  getitem_365 = getitem_368 = None
        relu_default_106 = torch.ops.aten.relu.default(getitem_351)
        convolution_default_199 = torch.ops.aten.convolution.default(relu_default_106, primals_718, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 432)
        convolution_default_200 = torch.ops.aten.convolution.default(convolution_default_199, primals_719, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_107 = torch.ops.aten.add_.Tensor(primals_709, 1);  primals_709 = None
        native_batch_norm_default_108 = torch.ops.aten.native_batch_norm.default(convolution_default_200, primals_712, primals_708, primals_710, primals_711, True, 0.1, 0.001);  primals_708 = None
        getitem_370 = native_batch_norm_default_108[0]
        getitem_371 = native_batch_norm_default_108[1]
        getitem_372 = native_batch_norm_default_108[2];  native_batch_norm_default_108 = None
        new_zeros_default_108 = torch.ops.aten.new_zeros.default(convolution_default_200, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_107 = torch.ops.aten.relu.default(getitem_370);  getitem_370 = None
        convolution_default_201 = torch.ops.aten.convolution.default(relu_default_107, primals_720, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 432)
        convolution_default_202 = torch.ops.aten.convolution.default(convolution_default_201, primals_721, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_108 = torch.ops.aten.add_.Tensor(primals_714, 1);  primals_714 = None
        native_batch_norm_default_109 = torch.ops.aten.native_batch_norm.default(convolution_default_202, primals_717, primals_713, primals_715, primals_716, True, 0.1, 0.001);  primals_713 = None
        getitem_373 = native_batch_norm_default_109[0]
        getitem_374 = native_batch_norm_default_109[1]
        getitem_375 = native_batch_norm_default_109[2];  native_batch_norm_default_109 = None
        new_zeros_default_109 = torch.ops.aten.new_zeros.default(convolution_default_202, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_108 = torch.ops.aten.relu.default(getitem_351)
        convolution_default_203 = torch.ops.aten.convolution.default(relu_default_108, primals_732, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_204 = torch.ops.aten.convolution.default(convolution_default_203, primals_733, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_109 = torch.ops.aten.add_.Tensor(primals_723, 1);  primals_723 = None
        native_batch_norm_default_110 = torch.ops.aten.native_batch_norm.default(convolution_default_204, primals_726, primals_722, primals_724, primals_725, True, 0.1, 0.001);  primals_722 = None
        getitem_376 = native_batch_norm_default_110[0]
        getitem_377 = native_batch_norm_default_110[1]
        getitem_378 = native_batch_norm_default_110[2];  native_batch_norm_default_110 = None
        new_zeros_default_110 = torch.ops.aten.new_zeros.default(convolution_default_204, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_109 = torch.ops.aten.relu.default(getitem_376);  getitem_376 = None
        convolution_default_205 = torch.ops.aten.convolution.default(relu_default_109, primals_734, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_206 = torch.ops.aten.convolution.default(convolution_default_205, primals_735, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_110 = torch.ops.aten.add_.Tensor(primals_728, 1);  primals_728 = None
        native_batch_norm_default_111 = torch.ops.aten.native_batch_norm.default(convolution_default_206, primals_731, primals_727, primals_729, primals_730, True, 0.1, 0.001);  primals_727 = None
        getitem_379 = native_batch_norm_default_111[0]
        getitem_380 = native_batch_norm_default_111[1]
        getitem_381 = native_batch_norm_default_111[2];  native_batch_norm_default_111 = None
        new_zeros_default_111 = torch.ops.aten.new_zeros.default(convolution_default_206, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_38 = torch.ops.aten.add.Tensor(getitem_373, getitem_379);  getitem_373 = getitem_379 = None
        relu_default_110 = torch.ops.aten.relu.default(add_tensor_38)
        convolution_default_207 = torch.ops.aten.convolution.default(relu_default_110, primals_746, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_208 = torch.ops.aten.convolution.default(convolution_default_207, primals_747, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_111 = torch.ops.aten.add_.Tensor(primals_737, 1);  primals_737 = None
        native_batch_norm_default_112 = torch.ops.aten.native_batch_norm.default(convolution_default_208, primals_740, primals_736, primals_738, primals_739, True, 0.1, 0.001);  primals_736 = None
        getitem_382 = native_batch_norm_default_112[0]
        getitem_383 = native_batch_norm_default_112[1]
        getitem_384 = native_batch_norm_default_112[2];  native_batch_norm_default_112 = None
        new_zeros_default_112 = torch.ops.aten.new_zeros.default(convolution_default_208, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_111 = torch.ops.aten.relu.default(getitem_382);  getitem_382 = None
        convolution_default_209 = torch.ops.aten.convolution.default(relu_default_111, primals_748, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_210 = torch.ops.aten.convolution.default(convolution_default_209, primals_749, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_112 = torch.ops.aten.add_.Tensor(primals_742, 1);  primals_742 = None
        native_batch_norm_default_113 = torch.ops.aten.native_batch_norm.default(convolution_default_210, primals_745, primals_741, primals_743, primals_744, True, 0.1, 0.001);  primals_741 = None
        getitem_385 = native_batch_norm_default_113[0]
        getitem_386 = native_batch_norm_default_113[1]
        getitem_387 = native_batch_norm_default_113[2];  native_batch_norm_default_113 = None
        new_zeros_default_113 = torch.ops.aten.new_zeros.default(convolution_default_210, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        max_pool2d_with_indices_default_23 = torch.ops.aten.max_pool2d_with_indices.default(getitem_351, [3, 3], [1, 1], [1, 1])
        getitem_388 = max_pool2d_with_indices_default_23[0]
        getitem_389 = max_pool2d_with_indices_default_23[1];  max_pool2d_with_indices_default_23 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(getitem_385, getitem_388);  getitem_385 = getitem_388 = None
        relu_default_112 = torch.ops.aten.relu.default(getitem_348)
        convolution_default_211 = torch.ops.aten.convolution.default(relu_default_112, primals_760, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_212 = torch.ops.aten.convolution.default(convolution_default_211, primals_761, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_113 = torch.ops.aten.add_.Tensor(primals_751, 1);  primals_751 = None
        native_batch_norm_default_114 = torch.ops.aten.native_batch_norm.default(convolution_default_212, primals_754, primals_750, primals_752, primals_753, True, 0.1, 0.001);  primals_750 = None
        getitem_390 = native_batch_norm_default_114[0]
        getitem_391 = native_batch_norm_default_114[1]
        getitem_392 = native_batch_norm_default_114[2];  native_batch_norm_default_114 = None
        new_zeros_default_114 = torch.ops.aten.new_zeros.default(convolution_default_212, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_113 = torch.ops.aten.relu.default(getitem_390);  getitem_390 = None
        convolution_default_213 = torch.ops.aten.convolution.default(relu_default_113, primals_762, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_214 = torch.ops.aten.convolution.default(convolution_default_213, primals_763, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_114 = torch.ops.aten.add_.Tensor(primals_756, 1);  primals_756 = None
        native_batch_norm_default_115 = torch.ops.aten.native_batch_norm.default(convolution_default_214, primals_759, primals_755, primals_757, primals_758, True, 0.1, 0.001);  primals_755 = None
        getitem_393 = native_batch_norm_default_115[0]
        getitem_394 = native_batch_norm_default_115[1]
        getitem_395 = native_batch_norm_default_115[2];  native_batch_norm_default_115 = None
        new_zeros_default_115 = torch.ops.aten.new_zeros.default(convolution_default_214, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_40 = torch.ops.aten.add.Tensor(getitem_393, getitem_351);  getitem_393 = None
        cat_default_10 = torch.ops.aten.cat.default([add_tensor_36, add_tensor_37, add_tensor_38, add_tensor_39, add_tensor_40], 1);  add_tensor_36 = add_tensor_37 = add_tensor_38 = add_tensor_39 = add_tensor_40 = None
        relu_default_114 = torch.ops.aten.relu.default(cat_default_8);  cat_default_8 = None
        convolution_default_215 = torch.ops.aten.convolution.default(relu_default_114, primals_872, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_115 = torch.ops.aten.add_.Tensor(primals_868, 1);  primals_868 = None
        native_batch_norm_default_116 = torch.ops.aten.native_batch_norm.default(convolution_default_215, primals_871, primals_867, primals_869, primals_870, True, 0.1, 0.001);  primals_867 = None
        getitem_396 = native_batch_norm_default_116[0]
        getitem_397 = native_batch_norm_default_116[1]
        getitem_398 = native_batch_norm_default_116[2];  native_batch_norm_default_116 = None
        new_zeros_default_116 = torch.ops.aten.new_zeros.default(convolution_default_215, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_115 = torch.ops.aten.relu.default(cat_default_10)
        convolution_default_216 = torch.ops.aten.convolution.default(relu_default_115, primals_866, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_116 = torch.ops.aten.add_.Tensor(primals_862, 1);  primals_862 = None
        native_batch_norm_default_117 = torch.ops.aten.native_batch_norm.default(convolution_default_216, primals_865, primals_861, primals_863, primals_864, True, 0.1, 0.001);  primals_861 = None
        getitem_399 = native_batch_norm_default_117[0]
        getitem_400 = native_batch_norm_default_117[1]
        getitem_401 = native_batch_norm_default_117[2];  native_batch_norm_default_117 = None
        new_zeros_default_117 = torch.ops.aten.new_zeros.default(convolution_default_216, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_116 = torch.ops.aten.relu.default(getitem_396)
        convolution_default_217 = torch.ops.aten.convolution.default(relu_default_116, primals_787, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 432)
        convolution_default_218 = torch.ops.aten.convolution.default(convolution_default_217, primals_788, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_117 = torch.ops.aten.add_.Tensor(primals_778, 1);  primals_778 = None
        native_batch_norm_default_118 = torch.ops.aten.native_batch_norm.default(convolution_default_218, primals_781, primals_777, primals_779, primals_780, True, 0.1, 0.001);  primals_777 = None
        getitem_402 = native_batch_norm_default_118[0]
        getitem_403 = native_batch_norm_default_118[1]
        getitem_404 = native_batch_norm_default_118[2];  native_batch_norm_default_118 = None
        new_zeros_default_118 = torch.ops.aten.new_zeros.default(convolution_default_218, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_117 = torch.ops.aten.relu.default(getitem_402);  getitem_402 = None
        convolution_default_219 = torch.ops.aten.convolution.default(relu_default_117, primals_789, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 432)
        convolution_default_220 = torch.ops.aten.convolution.default(convolution_default_219, primals_790, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_118 = torch.ops.aten.add_.Tensor(primals_783, 1);  primals_783 = None
        native_batch_norm_default_119 = torch.ops.aten.native_batch_norm.default(convolution_default_220, primals_786, primals_782, primals_784, primals_785, True, 0.1, 0.001);  primals_782 = None
        getitem_405 = native_batch_norm_default_119[0]
        getitem_406 = native_batch_norm_default_119[1]
        getitem_407 = native_batch_norm_default_119[2];  native_batch_norm_default_119 = None
        new_zeros_default_119 = torch.ops.aten.new_zeros.default(convolution_default_220, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        max_pool2d_with_indices_default_24 = torch.ops.aten.max_pool2d_with_indices.default(getitem_396, [3, 3], [1, 1], [1, 1])
        getitem_408 = max_pool2d_with_indices_default_24[0]
        getitem_409 = max_pool2d_with_indices_default_24[1];  max_pool2d_with_indices_default_24 = None
        add_tensor_41 = torch.ops.aten.add.Tensor(getitem_405, getitem_408);  getitem_405 = getitem_408 = None
        relu_default_118 = torch.ops.aten.relu.default(getitem_399)
        convolution_default_221 = torch.ops.aten.convolution.default(relu_default_118, primals_801, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 432)
        convolution_default_222 = torch.ops.aten.convolution.default(convolution_default_221, primals_802, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_119 = torch.ops.aten.add_.Tensor(primals_792, 1);  primals_792 = None
        native_batch_norm_default_120 = torch.ops.aten.native_batch_norm.default(convolution_default_222, primals_795, primals_791, primals_793, primals_794, True, 0.1, 0.001);  primals_791 = None
        getitem_410 = native_batch_norm_default_120[0]
        getitem_411 = native_batch_norm_default_120[1]
        getitem_412 = native_batch_norm_default_120[2];  native_batch_norm_default_120 = None
        new_zeros_default_120 = torch.ops.aten.new_zeros.default(convolution_default_222, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_119 = torch.ops.aten.relu.default(getitem_410);  getitem_410 = None
        convolution_default_223 = torch.ops.aten.convolution.default(relu_default_119, primals_803, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 432)
        convolution_default_224 = torch.ops.aten.convolution.default(convolution_default_223, primals_804, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_120 = torch.ops.aten.add_.Tensor(primals_797, 1);  primals_797 = None
        native_batch_norm_default_121 = torch.ops.aten.native_batch_norm.default(convolution_default_224, primals_800, primals_796, primals_798, primals_799, True, 0.1, 0.001);  primals_796 = None
        getitem_413 = native_batch_norm_default_121[0]
        getitem_414 = native_batch_norm_default_121[1]
        getitem_415 = native_batch_norm_default_121[2];  native_batch_norm_default_121 = None
        new_zeros_default_121 = torch.ops.aten.new_zeros.default(convolution_default_224, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        max_pool2d_with_indices_default_25 = torch.ops.aten.max_pool2d_with_indices.default(getitem_399, [3, 3], [1, 1], [1, 1])
        getitem_416 = max_pool2d_with_indices_default_25[0]
        getitem_417 = max_pool2d_with_indices_default_25[1];  max_pool2d_with_indices_default_25 = None
        add_tensor_42 = torch.ops.aten.add.Tensor(getitem_413, getitem_416);  getitem_413 = getitem_416 = None
        relu_default_120 = torch.ops.aten.relu.default(getitem_399)
        convolution_default_225 = torch.ops.aten.convolution.default(relu_default_120, primals_815, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 432)
        convolution_default_226 = torch.ops.aten.convolution.default(convolution_default_225, primals_816, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_121 = torch.ops.aten.add_.Tensor(primals_806, 1);  primals_806 = None
        native_batch_norm_default_122 = torch.ops.aten.native_batch_norm.default(convolution_default_226, primals_809, primals_805, primals_807, primals_808, True, 0.1, 0.001);  primals_805 = None
        getitem_418 = native_batch_norm_default_122[0]
        getitem_419 = native_batch_norm_default_122[1]
        getitem_420 = native_batch_norm_default_122[2];  native_batch_norm_default_122 = None
        new_zeros_default_122 = torch.ops.aten.new_zeros.default(convolution_default_226, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_121 = torch.ops.aten.relu.default(getitem_418);  getitem_418 = None
        convolution_default_227 = torch.ops.aten.convolution.default(relu_default_121, primals_817, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 432)
        convolution_default_228 = torch.ops.aten.convolution.default(convolution_default_227, primals_818, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_122 = torch.ops.aten.add_.Tensor(primals_811, 1);  primals_811 = None
        native_batch_norm_default_123 = torch.ops.aten.native_batch_norm.default(convolution_default_228, primals_814, primals_810, primals_812, primals_813, True, 0.1, 0.001);  primals_810 = None
        getitem_421 = native_batch_norm_default_123[0]
        getitem_422 = native_batch_norm_default_123[1]
        getitem_423 = native_batch_norm_default_123[2];  native_batch_norm_default_123 = None
        new_zeros_default_123 = torch.ops.aten.new_zeros.default(convolution_default_228, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_122 = torch.ops.aten.relu.default(getitem_399)
        convolution_default_229 = torch.ops.aten.convolution.default(relu_default_122, primals_829, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_230 = torch.ops.aten.convolution.default(convolution_default_229, primals_830, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_123 = torch.ops.aten.add_.Tensor(primals_820, 1);  primals_820 = None
        native_batch_norm_default_124 = torch.ops.aten.native_batch_norm.default(convolution_default_230, primals_823, primals_819, primals_821, primals_822, True, 0.1, 0.001);  primals_819 = None
        getitem_424 = native_batch_norm_default_124[0]
        getitem_425 = native_batch_norm_default_124[1]
        getitem_426 = native_batch_norm_default_124[2];  native_batch_norm_default_124 = None
        new_zeros_default_124 = torch.ops.aten.new_zeros.default(convolution_default_230, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_123 = torch.ops.aten.relu.default(getitem_424);  getitem_424 = None
        convolution_default_231 = torch.ops.aten.convolution.default(relu_default_123, primals_831, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_232 = torch.ops.aten.convolution.default(convolution_default_231, primals_832, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_124 = torch.ops.aten.add_.Tensor(primals_825, 1);  primals_825 = None
        native_batch_norm_default_125 = torch.ops.aten.native_batch_norm.default(convolution_default_232, primals_828, primals_824, primals_826, primals_827, True, 0.1, 0.001);  primals_824 = None
        getitem_427 = native_batch_norm_default_125[0]
        getitem_428 = native_batch_norm_default_125[1]
        getitem_429 = native_batch_norm_default_125[2];  native_batch_norm_default_125 = None
        new_zeros_default_125 = torch.ops.aten.new_zeros.default(convolution_default_232, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_43 = torch.ops.aten.add.Tensor(getitem_421, getitem_427);  getitem_421 = getitem_427 = None
        relu_default_124 = torch.ops.aten.relu.default(add_tensor_43)
        convolution_default_233 = torch.ops.aten.convolution.default(relu_default_124, primals_843, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_234 = torch.ops.aten.convolution.default(convolution_default_233, primals_844, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_125 = torch.ops.aten.add_.Tensor(primals_834, 1);  primals_834 = None
        native_batch_norm_default_126 = torch.ops.aten.native_batch_norm.default(convolution_default_234, primals_837, primals_833, primals_835, primals_836, True, 0.1, 0.001);  primals_833 = None
        getitem_430 = native_batch_norm_default_126[0]
        getitem_431 = native_batch_norm_default_126[1]
        getitem_432 = native_batch_norm_default_126[2];  native_batch_norm_default_126 = None
        new_zeros_default_126 = torch.ops.aten.new_zeros.default(convolution_default_234, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_125 = torch.ops.aten.relu.default(getitem_430);  getitem_430 = None
        convolution_default_235 = torch.ops.aten.convolution.default(relu_default_125, primals_845, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_236 = torch.ops.aten.convolution.default(convolution_default_235, primals_846, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_126 = torch.ops.aten.add_.Tensor(primals_839, 1);  primals_839 = None
        native_batch_norm_default_127 = torch.ops.aten.native_batch_norm.default(convolution_default_236, primals_842, primals_838, primals_840, primals_841, True, 0.1, 0.001);  primals_838 = None
        getitem_433 = native_batch_norm_default_127[0]
        getitem_434 = native_batch_norm_default_127[1]
        getitem_435 = native_batch_norm_default_127[2];  native_batch_norm_default_127 = None
        new_zeros_default_127 = torch.ops.aten.new_zeros.default(convolution_default_236, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        max_pool2d_with_indices_default_26 = torch.ops.aten.max_pool2d_with_indices.default(getitem_399, [3, 3], [1, 1], [1, 1])
        getitem_436 = max_pool2d_with_indices_default_26[0]
        getitem_437 = max_pool2d_with_indices_default_26[1];  max_pool2d_with_indices_default_26 = None
        add_tensor_44 = torch.ops.aten.add.Tensor(getitem_433, getitem_436);  getitem_433 = getitem_436 = None
        relu_default_126 = torch.ops.aten.relu.default(getitem_396)
        convolution_default_237 = torch.ops.aten.convolution.default(relu_default_126, primals_857, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_238 = torch.ops.aten.convolution.default(convolution_default_237, primals_858, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_127 = torch.ops.aten.add_.Tensor(primals_848, 1);  primals_848 = None
        native_batch_norm_default_128 = torch.ops.aten.native_batch_norm.default(convolution_default_238, primals_851, primals_847, primals_849, primals_850, True, 0.1, 0.001);  primals_847 = None
        getitem_438 = native_batch_norm_default_128[0]
        getitem_439 = native_batch_norm_default_128[1]
        getitem_440 = native_batch_norm_default_128[2];  native_batch_norm_default_128 = None
        new_zeros_default_128 = torch.ops.aten.new_zeros.default(convolution_default_238, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_127 = torch.ops.aten.relu.default(getitem_438);  getitem_438 = None
        convolution_default_239 = torch.ops.aten.convolution.default(relu_default_127, primals_859, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_240 = torch.ops.aten.convolution.default(convolution_default_239, primals_860, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_128 = torch.ops.aten.add_.Tensor(primals_853, 1);  primals_853 = None
        native_batch_norm_default_129 = torch.ops.aten.native_batch_norm.default(convolution_default_240, primals_856, primals_852, primals_854, primals_855, True, 0.1, 0.001);  primals_852 = None
        getitem_441 = native_batch_norm_default_129[0]
        getitem_442 = native_batch_norm_default_129[1]
        getitem_443 = native_batch_norm_default_129[2];  native_batch_norm_default_129 = None
        new_zeros_default_129 = torch.ops.aten.new_zeros.default(convolution_default_240, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_45 = torch.ops.aten.add.Tensor(getitem_441, getitem_399);  getitem_441 = None
        cat_default_11 = torch.ops.aten.cat.default([add_tensor_41, add_tensor_42, add_tensor_43, add_tensor_44, add_tensor_45], 1);  add_tensor_41 = add_tensor_42 = add_tensor_43 = add_tensor_44 = add_tensor_45 = None
        relu_default_128 = torch.ops.aten.relu.default(cat_default_10);  cat_default_10 = None
        convolution_default_241 = torch.ops.aten.convolution.default(relu_default_128, primals_968, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_129 = torch.ops.aten.add_.Tensor(primals_964, 1);  primals_964 = None
        native_batch_norm_default_130 = torch.ops.aten.native_batch_norm.default(convolution_default_241, primals_967, primals_963, primals_965, primals_966, True, 0.1, 0.001);  primals_963 = None
        getitem_444 = native_batch_norm_default_130[0]
        getitem_445 = native_batch_norm_default_130[1]
        getitem_446 = native_batch_norm_default_130[2];  native_batch_norm_default_130 = None
        new_zeros_default_130 = torch.ops.aten.new_zeros.default(convolution_default_241, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_129 = torch.ops.aten.relu.default(cat_default_11)
        convolution_default_242 = torch.ops.aten.convolution.default(relu_default_129, primals_962, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_130 = torch.ops.aten.add_.Tensor(primals_958, 1);  primals_958 = None
        native_batch_norm_default_131 = torch.ops.aten.native_batch_norm.default(convolution_default_242, primals_961, primals_957, primals_959, primals_960, True, 0.1, 0.001);  primals_957 = None
        getitem_447 = native_batch_norm_default_131[0]
        getitem_448 = native_batch_norm_default_131[1]
        getitem_449 = native_batch_norm_default_131[2];  native_batch_norm_default_131 = None
        new_zeros_default_131 = torch.ops.aten.new_zeros.default(convolution_default_242, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_130 = torch.ops.aten.relu.default(getitem_444)
        convolution_default_243 = torch.ops.aten.convolution.default(relu_default_130, primals_883, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 432)
        convolution_default_244 = torch.ops.aten.convolution.default(convolution_default_243, primals_884, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_131 = torch.ops.aten.add_.Tensor(primals_874, 1);  primals_874 = None
        native_batch_norm_default_132 = torch.ops.aten.native_batch_norm.default(convolution_default_244, primals_877, primals_873, primals_875, primals_876, True, 0.1, 0.001);  primals_873 = None
        getitem_450 = native_batch_norm_default_132[0]
        getitem_451 = native_batch_norm_default_132[1]
        getitem_452 = native_batch_norm_default_132[2];  native_batch_norm_default_132 = None
        new_zeros_default_132 = torch.ops.aten.new_zeros.default(convolution_default_244, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_131 = torch.ops.aten.relu.default(getitem_450);  getitem_450 = None
        convolution_default_245 = torch.ops.aten.convolution.default(relu_default_131, primals_885, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 432)
        convolution_default_246 = torch.ops.aten.convolution.default(convolution_default_245, primals_886, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_132 = torch.ops.aten.add_.Tensor(primals_879, 1);  primals_879 = None
        native_batch_norm_default_133 = torch.ops.aten.native_batch_norm.default(convolution_default_246, primals_882, primals_878, primals_880, primals_881, True, 0.1, 0.001);  primals_878 = None
        getitem_453 = native_batch_norm_default_133[0]
        getitem_454 = native_batch_norm_default_133[1]
        getitem_455 = native_batch_norm_default_133[2];  native_batch_norm_default_133 = None
        new_zeros_default_133 = torch.ops.aten.new_zeros.default(convolution_default_246, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        max_pool2d_with_indices_default_27 = torch.ops.aten.max_pool2d_with_indices.default(getitem_444, [3, 3], [1, 1], [1, 1])
        getitem_456 = max_pool2d_with_indices_default_27[0]
        getitem_457 = max_pool2d_with_indices_default_27[1];  max_pool2d_with_indices_default_27 = None
        add_tensor_46 = torch.ops.aten.add.Tensor(getitem_453, getitem_456);  getitem_453 = getitem_456 = None
        relu_default_132 = torch.ops.aten.relu.default(getitem_447)
        convolution_default_247 = torch.ops.aten.convolution.default(relu_default_132, primals_897, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 432)
        convolution_default_248 = torch.ops.aten.convolution.default(convolution_default_247, primals_898, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_133 = torch.ops.aten.add_.Tensor(primals_888, 1);  primals_888 = None
        native_batch_norm_default_134 = torch.ops.aten.native_batch_norm.default(convolution_default_248, primals_891, primals_887, primals_889, primals_890, True, 0.1, 0.001);  primals_887 = None
        getitem_458 = native_batch_norm_default_134[0]
        getitem_459 = native_batch_norm_default_134[1]
        getitem_460 = native_batch_norm_default_134[2];  native_batch_norm_default_134 = None
        new_zeros_default_134 = torch.ops.aten.new_zeros.default(convolution_default_248, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_133 = torch.ops.aten.relu.default(getitem_458);  getitem_458 = None
        convolution_default_249 = torch.ops.aten.convolution.default(relu_default_133, primals_899, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 432)
        convolution_default_250 = torch.ops.aten.convolution.default(convolution_default_249, primals_900, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_134 = torch.ops.aten.add_.Tensor(primals_893, 1);  primals_893 = None
        native_batch_norm_default_135 = torch.ops.aten.native_batch_norm.default(convolution_default_250, primals_896, primals_892, primals_894, primals_895, True, 0.1, 0.001);  primals_892 = None
        getitem_461 = native_batch_norm_default_135[0]
        getitem_462 = native_batch_norm_default_135[1]
        getitem_463 = native_batch_norm_default_135[2];  native_batch_norm_default_135 = None
        new_zeros_default_135 = torch.ops.aten.new_zeros.default(convolution_default_250, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        max_pool2d_with_indices_default_28 = torch.ops.aten.max_pool2d_with_indices.default(getitem_447, [3, 3], [1, 1], [1, 1])
        getitem_464 = max_pool2d_with_indices_default_28[0]
        getitem_465 = max_pool2d_with_indices_default_28[1];  max_pool2d_with_indices_default_28 = None
        add_tensor_47 = torch.ops.aten.add.Tensor(getitem_461, getitem_464);  getitem_461 = getitem_464 = None
        relu_default_134 = torch.ops.aten.relu.default(getitem_447)
        convolution_default_251 = torch.ops.aten.convolution.default(relu_default_134, primals_911, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 432)
        convolution_default_252 = torch.ops.aten.convolution.default(convolution_default_251, primals_912, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_135 = torch.ops.aten.add_.Tensor(primals_902, 1);  primals_902 = None
        native_batch_norm_default_136 = torch.ops.aten.native_batch_norm.default(convolution_default_252, primals_905, primals_901, primals_903, primals_904, True, 0.1, 0.001);  primals_901 = None
        getitem_466 = native_batch_norm_default_136[0]
        getitem_467 = native_batch_norm_default_136[1]
        getitem_468 = native_batch_norm_default_136[2];  native_batch_norm_default_136 = None
        new_zeros_default_136 = torch.ops.aten.new_zeros.default(convolution_default_252, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_135 = torch.ops.aten.relu.default(getitem_466);  getitem_466 = None
        convolution_default_253 = torch.ops.aten.convolution.default(relu_default_135, primals_913, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 432)
        convolution_default_254 = torch.ops.aten.convolution.default(convolution_default_253, primals_914, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_136 = torch.ops.aten.add_.Tensor(primals_907, 1);  primals_907 = None
        native_batch_norm_default_137 = torch.ops.aten.native_batch_norm.default(convolution_default_254, primals_910, primals_906, primals_908, primals_909, True, 0.1, 0.001);  primals_906 = None
        getitem_469 = native_batch_norm_default_137[0]
        getitem_470 = native_batch_norm_default_137[1]
        getitem_471 = native_batch_norm_default_137[2];  native_batch_norm_default_137 = None
        new_zeros_default_137 = torch.ops.aten.new_zeros.default(convolution_default_254, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_136 = torch.ops.aten.relu.default(getitem_447)
        convolution_default_255 = torch.ops.aten.convolution.default(relu_default_136, primals_925, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_256 = torch.ops.aten.convolution.default(convolution_default_255, primals_926, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_137 = torch.ops.aten.add_.Tensor(primals_916, 1);  primals_916 = None
        native_batch_norm_default_138 = torch.ops.aten.native_batch_norm.default(convolution_default_256, primals_919, primals_915, primals_917, primals_918, True, 0.1, 0.001);  primals_915 = None
        getitem_472 = native_batch_norm_default_138[0]
        getitem_473 = native_batch_norm_default_138[1]
        getitem_474 = native_batch_norm_default_138[2];  native_batch_norm_default_138 = None
        new_zeros_default_138 = torch.ops.aten.new_zeros.default(convolution_default_256, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_137 = torch.ops.aten.relu.default(getitem_472);  getitem_472 = None
        convolution_default_257 = torch.ops.aten.convolution.default(relu_default_137, primals_927, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_258 = torch.ops.aten.convolution.default(convolution_default_257, primals_928, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_138 = torch.ops.aten.add_.Tensor(primals_921, 1);  primals_921 = None
        native_batch_norm_default_139 = torch.ops.aten.native_batch_norm.default(convolution_default_258, primals_924, primals_920, primals_922, primals_923, True, 0.1, 0.001);  primals_920 = None
        getitem_475 = native_batch_norm_default_139[0]
        getitem_476 = native_batch_norm_default_139[1]
        getitem_477 = native_batch_norm_default_139[2];  native_batch_norm_default_139 = None
        new_zeros_default_139 = torch.ops.aten.new_zeros.default(convolution_default_258, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_48 = torch.ops.aten.add.Tensor(getitem_469, getitem_475);  getitem_469 = getitem_475 = None
        relu_default_138 = torch.ops.aten.relu.default(add_tensor_48)
        convolution_default_259 = torch.ops.aten.convolution.default(relu_default_138, primals_939, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_260 = torch.ops.aten.convolution.default(convolution_default_259, primals_940, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_139 = torch.ops.aten.add_.Tensor(primals_930, 1);  primals_930 = None
        native_batch_norm_default_140 = torch.ops.aten.native_batch_norm.default(convolution_default_260, primals_933, primals_929, primals_931, primals_932, True, 0.1, 0.001);  primals_929 = None
        getitem_478 = native_batch_norm_default_140[0]
        getitem_479 = native_batch_norm_default_140[1]
        getitem_480 = native_batch_norm_default_140[2];  native_batch_norm_default_140 = None
        new_zeros_default_140 = torch.ops.aten.new_zeros.default(convolution_default_260, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_139 = torch.ops.aten.relu.default(getitem_478);  getitem_478 = None
        convolution_default_261 = torch.ops.aten.convolution.default(relu_default_139, primals_941, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_262 = torch.ops.aten.convolution.default(convolution_default_261, primals_942, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_140 = torch.ops.aten.add_.Tensor(primals_935, 1);  primals_935 = None
        native_batch_norm_default_141 = torch.ops.aten.native_batch_norm.default(convolution_default_262, primals_938, primals_934, primals_936, primals_937, True, 0.1, 0.001);  primals_934 = None
        getitem_481 = native_batch_norm_default_141[0]
        getitem_482 = native_batch_norm_default_141[1]
        getitem_483 = native_batch_norm_default_141[2];  native_batch_norm_default_141 = None
        new_zeros_default_141 = torch.ops.aten.new_zeros.default(convolution_default_262, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        max_pool2d_with_indices_default_29 = torch.ops.aten.max_pool2d_with_indices.default(getitem_447, [3, 3], [1, 1], [1, 1])
        getitem_484 = max_pool2d_with_indices_default_29[0]
        getitem_485 = max_pool2d_with_indices_default_29[1];  max_pool2d_with_indices_default_29 = None
        add_tensor_49 = torch.ops.aten.add.Tensor(getitem_481, getitem_484);  getitem_481 = getitem_484 = None
        relu_default_140 = torch.ops.aten.relu.default(getitem_444)
        convolution_default_263 = torch.ops.aten.convolution.default(relu_default_140, primals_953, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_264 = torch.ops.aten.convolution.default(convolution_default_263, primals_954, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_141 = torch.ops.aten.add_.Tensor(primals_944, 1);  primals_944 = None
        native_batch_norm_default_142 = torch.ops.aten.native_batch_norm.default(convolution_default_264, primals_947, primals_943, primals_945, primals_946, True, 0.1, 0.001);  primals_943 = None
        getitem_486 = native_batch_norm_default_142[0]
        getitem_487 = native_batch_norm_default_142[1]
        getitem_488 = native_batch_norm_default_142[2];  native_batch_norm_default_142 = None
        new_zeros_default_142 = torch.ops.aten.new_zeros.default(convolution_default_264, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_141 = torch.ops.aten.relu.default(getitem_486);  getitem_486 = None
        convolution_default_265 = torch.ops.aten.convolution.default(relu_default_141, primals_955, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_266 = torch.ops.aten.convolution.default(convolution_default_265, primals_956, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_142 = torch.ops.aten.add_.Tensor(primals_949, 1);  primals_949 = None
        native_batch_norm_default_143 = torch.ops.aten.native_batch_norm.default(convolution_default_266, primals_952, primals_948, primals_950, primals_951, True, 0.1, 0.001);  primals_948 = None
        getitem_489 = native_batch_norm_default_143[0]
        getitem_490 = native_batch_norm_default_143[1]
        getitem_491 = native_batch_norm_default_143[2];  native_batch_norm_default_143 = None
        new_zeros_default_143 = torch.ops.aten.new_zeros.default(convolution_default_266, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_50 = torch.ops.aten.add.Tensor(getitem_489, getitem_447);  getitem_489 = None
        cat_default_12 = torch.ops.aten.cat.default([add_tensor_46, add_tensor_47, add_tensor_48, add_tensor_49, add_tensor_50], 1);  add_tensor_46 = add_tensor_47 = add_tensor_48 = add_tensor_49 = add_tensor_50 = None
        relu_default_142 = torch.ops.aten.relu.default(cat_default_11);  cat_default_11 = None
        convolution_default_267 = torch.ops.aten.convolution.default(relu_default_142, primals_1070, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_143 = torch.ops.aten.add_.Tensor(primals_1066, 1);  primals_1066 = None
        native_batch_norm_default_144 = torch.ops.aten.native_batch_norm.default(convolution_default_267, primals_1069, primals_1065, primals_1067, primals_1068, True, 0.1, 0.001);  primals_1065 = None
        getitem_492 = native_batch_norm_default_144[0]
        getitem_493 = native_batch_norm_default_144[1]
        getitem_494 = native_batch_norm_default_144[2];  native_batch_norm_default_144 = None
        new_zeros_default_144 = torch.ops.aten.new_zeros.default(convolution_default_267, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_143 = torch.ops.aten.relu.default(cat_default_12)
        convolution_default_268 = torch.ops.aten.convolution.default(relu_default_143, primals_1064, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_144 = torch.ops.aten.add_.Tensor(primals_1060, 1);  primals_1060 = None
        native_batch_norm_default_145 = torch.ops.aten.native_batch_norm.default(convolution_default_268, primals_1063, primals_1059, primals_1061, primals_1062, True, 0.1, 0.001);  primals_1059 = None
        getitem_495 = native_batch_norm_default_145[0]
        getitem_496 = native_batch_norm_default_145[1]
        getitem_497 = native_batch_norm_default_145[2];  native_batch_norm_default_145 = None
        new_zeros_default_145 = torch.ops.aten.new_zeros.default(convolution_default_268, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_144 = torch.ops.aten.relu.default(getitem_492)
        constant_pad_nd_default_27 = torch.ops.aten.constant_pad_nd.default(relu_default_144, [2, 2, 2, 2], 0.0)
        convolution_default_269 = torch.ops.aten.convolution.default(constant_pad_nd_default_27, primals_979, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 864)
        convolution_default_270 = torch.ops.aten.convolution.default(convolution_default_269, primals_980, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_145 = torch.ops.aten.add_.Tensor(primals_970, 1);  primals_970 = None
        native_batch_norm_default_146 = torch.ops.aten.native_batch_norm.default(convolution_default_270, primals_973, primals_969, primals_971, primals_972, True, 0.1, 0.001);  primals_969 = None
        getitem_498 = native_batch_norm_default_146[0]
        getitem_499 = native_batch_norm_default_146[1]
        getitem_500 = native_batch_norm_default_146[2];  native_batch_norm_default_146 = None
        new_zeros_default_146 = torch.ops.aten.new_zeros.default(convolution_default_270, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_145 = torch.ops.aten.relu.default(getitem_498);  getitem_498 = None
        convolution_default_271 = torch.ops.aten.convolution.default(relu_default_145, primals_981, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 864)
        convolution_default_272 = torch.ops.aten.convolution.default(convolution_default_271, primals_982, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_146 = torch.ops.aten.add_.Tensor(primals_975, 1);  primals_975 = None
        native_batch_norm_default_147 = torch.ops.aten.native_batch_norm.default(convolution_default_272, primals_978, primals_974, primals_976, primals_977, True, 0.1, 0.001);  primals_974 = None
        getitem_501 = native_batch_norm_default_147[0]
        getitem_502 = native_batch_norm_default_147[1]
        getitem_503 = native_batch_norm_default_147[2];  native_batch_norm_default_147 = None
        new_zeros_default_147 = torch.ops.aten.new_zeros.default(convolution_default_272, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        constant_pad_nd_default_28 = torch.ops.aten.constant_pad_nd.default(getitem_492, [1, 1, 1, 1], -inf)
        max_pool2d_with_indices_default_30 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_28, [3, 3], [2, 2])
        getitem_504 = max_pool2d_with_indices_default_30[0]
        getitem_505 = max_pool2d_with_indices_default_30[1];  max_pool2d_with_indices_default_30 = None
        add_tensor_51 = torch.ops.aten.add.Tensor(getitem_501, getitem_504);  getitem_501 = getitem_504 = None
        relu_default_146 = torch.ops.aten.relu.default(getitem_495)
        constant_pad_nd_default_29 = torch.ops.aten.constant_pad_nd.default(relu_default_146, [3, 3, 3, 3], 0.0)
        convolution_default_273 = torch.ops.aten.convolution.default(constant_pad_nd_default_29, primals_993, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 864)
        convolution_default_274 = torch.ops.aten.convolution.default(convolution_default_273, primals_994, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_147 = torch.ops.aten.add_.Tensor(primals_984, 1);  primals_984 = None
        native_batch_norm_default_148 = torch.ops.aten.native_batch_norm.default(convolution_default_274, primals_987, primals_983, primals_985, primals_986, True, 0.1, 0.001);  primals_983 = None
        getitem_506 = native_batch_norm_default_148[0]
        getitem_507 = native_batch_norm_default_148[1]
        getitem_508 = native_batch_norm_default_148[2];  native_batch_norm_default_148 = None
        new_zeros_default_148 = torch.ops.aten.new_zeros.default(convolution_default_274, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_147 = torch.ops.aten.relu.default(getitem_506);  getitem_506 = None
        convolution_default_275 = torch.ops.aten.convolution.default(relu_default_147, primals_995, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 864)
        convolution_default_276 = torch.ops.aten.convolution.default(convolution_default_275, primals_996, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_148 = torch.ops.aten.add_.Tensor(primals_989, 1);  primals_989 = None
        native_batch_norm_default_149 = torch.ops.aten.native_batch_norm.default(convolution_default_276, primals_992, primals_988, primals_990, primals_991, True, 0.1, 0.001);  primals_988 = None
        getitem_509 = native_batch_norm_default_149[0]
        getitem_510 = native_batch_norm_default_149[1]
        getitem_511 = native_batch_norm_default_149[2];  native_batch_norm_default_149 = None
        new_zeros_default_149 = torch.ops.aten.new_zeros.default(convolution_default_276, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        constant_pad_nd_default_30 = torch.ops.aten.constant_pad_nd.default(getitem_495, [1, 1, 1, 1], -inf)
        max_pool2d_with_indices_default_31 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_30, [3, 3], [2, 2])
        getitem_512 = max_pool2d_with_indices_default_31[0]
        getitem_513 = max_pool2d_with_indices_default_31[1];  max_pool2d_with_indices_default_31 = None
        add_tensor_52 = torch.ops.aten.add.Tensor(getitem_509, getitem_512);  getitem_509 = getitem_512 = None
        relu_default_148 = torch.ops.aten.relu.default(getitem_495)
        constant_pad_nd_default_31 = torch.ops.aten.constant_pad_nd.default(relu_default_148, [2, 2, 2, 2], 0.0)
        convolution_default_277 = torch.ops.aten.convolution.default(constant_pad_nd_default_31, primals_1007, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 864)
        convolution_default_278 = torch.ops.aten.convolution.default(convolution_default_277, primals_1008, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_149 = torch.ops.aten.add_.Tensor(primals_998, 1);  primals_998 = None
        native_batch_norm_default_150 = torch.ops.aten.native_batch_norm.default(convolution_default_278, primals_1001, primals_997, primals_999, primals_1000, True, 0.1, 0.001);  primals_997 = None
        getitem_514 = native_batch_norm_default_150[0]
        getitem_515 = native_batch_norm_default_150[1]
        getitem_516 = native_batch_norm_default_150[2];  native_batch_norm_default_150 = None
        new_zeros_default_150 = torch.ops.aten.new_zeros.default(convolution_default_278, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_149 = torch.ops.aten.relu.default(getitem_514);  getitem_514 = None
        convolution_default_279 = torch.ops.aten.convolution.default(relu_default_149, primals_1009, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 864)
        convolution_default_280 = torch.ops.aten.convolution.default(convolution_default_279, primals_1010, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_150 = torch.ops.aten.add_.Tensor(primals_1003, 1);  primals_1003 = None
        native_batch_norm_default_151 = torch.ops.aten.native_batch_norm.default(convolution_default_280, primals_1006, primals_1002, primals_1004, primals_1005, True, 0.1, 0.001);  primals_1002 = None
        getitem_517 = native_batch_norm_default_151[0]
        getitem_518 = native_batch_norm_default_151[1]
        getitem_519 = native_batch_norm_default_151[2];  native_batch_norm_default_151 = None
        new_zeros_default_151 = torch.ops.aten.new_zeros.default(convolution_default_280, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_150 = torch.ops.aten.relu.default(getitem_495)
        constant_pad_nd_default_32 = torch.ops.aten.constant_pad_nd.default(relu_default_150, [1, 1, 1, 1], 0.0)
        convolution_default_281 = torch.ops.aten.convolution.default(constant_pad_nd_default_32, primals_1021, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 864)
        convolution_default_282 = torch.ops.aten.convolution.default(convolution_default_281, primals_1022, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_151 = torch.ops.aten.add_.Tensor(primals_1012, 1);  primals_1012 = None
        native_batch_norm_default_152 = torch.ops.aten.native_batch_norm.default(convolution_default_282, primals_1015, primals_1011, primals_1013, primals_1014, True, 0.1, 0.001);  primals_1011 = None
        getitem_520 = native_batch_norm_default_152[0]
        getitem_521 = native_batch_norm_default_152[1]
        getitem_522 = native_batch_norm_default_152[2];  native_batch_norm_default_152 = None
        new_zeros_default_152 = torch.ops.aten.new_zeros.default(convolution_default_282, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_151 = torch.ops.aten.relu.default(getitem_520);  getitem_520 = None
        convolution_default_283 = torch.ops.aten.convolution.default(relu_default_151, primals_1023, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_284 = torch.ops.aten.convolution.default(convolution_default_283, primals_1024, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_152 = torch.ops.aten.add_.Tensor(primals_1017, 1);  primals_1017 = None
        native_batch_norm_default_153 = torch.ops.aten.native_batch_norm.default(convolution_default_284, primals_1020, primals_1016, primals_1018, primals_1019, True, 0.1, 0.001);  primals_1016 = None
        getitem_523 = native_batch_norm_default_153[0]
        getitem_524 = native_batch_norm_default_153[1]
        getitem_525 = native_batch_norm_default_153[2];  native_batch_norm_default_153 = None
        new_zeros_default_153 = torch.ops.aten.new_zeros.default(convolution_default_284, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_53 = torch.ops.aten.add.Tensor(getitem_517, getitem_523);  getitem_517 = getitem_523 = None
        relu_default_152 = torch.ops.aten.relu.default(add_tensor_53)
        convolution_default_285 = torch.ops.aten.convolution.default(relu_default_152, primals_1035, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_286 = torch.ops.aten.convolution.default(convolution_default_285, primals_1036, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_153 = torch.ops.aten.add_.Tensor(primals_1026, 1);  primals_1026 = None
        native_batch_norm_default_154 = torch.ops.aten.native_batch_norm.default(convolution_default_286, primals_1029, primals_1025, primals_1027, primals_1028, True, 0.1, 0.001);  primals_1025 = None
        getitem_526 = native_batch_norm_default_154[0]
        getitem_527 = native_batch_norm_default_154[1]
        getitem_528 = native_batch_norm_default_154[2];  native_batch_norm_default_154 = None
        new_zeros_default_154 = torch.ops.aten.new_zeros.default(convolution_default_286, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_153 = torch.ops.aten.relu.default(getitem_526);  getitem_526 = None
        convolution_default_287 = torch.ops.aten.convolution.default(relu_default_153, primals_1037, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_288 = torch.ops.aten.convolution.default(convolution_default_287, primals_1038, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_154 = torch.ops.aten.add_.Tensor(primals_1031, 1);  primals_1031 = None
        native_batch_norm_default_155 = torch.ops.aten.native_batch_norm.default(convolution_default_288, primals_1034, primals_1030, primals_1032, primals_1033, True, 0.1, 0.001);  primals_1030 = None
        getitem_529 = native_batch_norm_default_155[0]
        getitem_530 = native_batch_norm_default_155[1]
        getitem_531 = native_batch_norm_default_155[2];  native_batch_norm_default_155 = None
        new_zeros_default_155 = torch.ops.aten.new_zeros.default(convolution_default_288, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        constant_pad_nd_default_33 = torch.ops.aten.constant_pad_nd.default(getitem_495, [1, 1, 1, 1], -inf)
        max_pool2d_with_indices_default_32 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_33, [3, 3], [2, 2])
        getitem_532 = max_pool2d_with_indices_default_32[0]
        getitem_533 = max_pool2d_with_indices_default_32[1];  max_pool2d_with_indices_default_32 = None
        add_tensor_54 = torch.ops.aten.add.Tensor(getitem_529, getitem_532);  getitem_529 = getitem_532 = None
        relu_default_154 = torch.ops.aten.relu.default(getitem_492);  getitem_492 = None
        constant_pad_nd_default_34 = torch.ops.aten.constant_pad_nd.default(relu_default_154, [1, 1, 1, 1], 0.0)
        convolution_default_289 = torch.ops.aten.convolution.default(constant_pad_nd_default_34, primals_1049, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 864)
        convolution_default_290 = torch.ops.aten.convolution.default(convolution_default_289, primals_1050, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_155 = torch.ops.aten.add_.Tensor(primals_1040, 1);  primals_1040 = None
        native_batch_norm_default_156 = torch.ops.aten.native_batch_norm.default(convolution_default_290, primals_1043, primals_1039, primals_1041, primals_1042, True, 0.1, 0.001);  primals_1039 = None
        getitem_534 = native_batch_norm_default_156[0]
        getitem_535 = native_batch_norm_default_156[1]
        getitem_536 = native_batch_norm_default_156[2];  native_batch_norm_default_156 = None
        new_zeros_default_156 = torch.ops.aten.new_zeros.default(convolution_default_290, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_155 = torch.ops.aten.relu.default(getitem_534);  getitem_534 = None
        convolution_default_291 = torch.ops.aten.convolution.default(relu_default_155, primals_1051, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_292 = torch.ops.aten.convolution.default(convolution_default_291, primals_1052, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_156 = torch.ops.aten.add_.Tensor(primals_1045, 1);  primals_1045 = None
        native_batch_norm_default_157 = torch.ops.aten.native_batch_norm.default(convolution_default_292, primals_1048, primals_1044, primals_1046, primals_1047, True, 0.1, 0.001);  primals_1044 = None
        getitem_537 = native_batch_norm_default_157[0]
        getitem_538 = native_batch_norm_default_157[1]
        getitem_539 = native_batch_norm_default_157[2];  native_batch_norm_default_157 = None
        new_zeros_default_157 = torch.ops.aten.new_zeros.default(convolution_default_292, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_156 = torch.ops.aten.relu.default(getitem_495);  getitem_495 = None
        convolution_default_293 = torch.ops.aten.convolution.default(relu_default_156, primals_1058, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_157 = torch.ops.aten.add_.Tensor(primals_1054, 1);  primals_1054 = None
        native_batch_norm_default_158 = torch.ops.aten.native_batch_norm.default(convolution_default_293, primals_1057, primals_1053, primals_1055, primals_1056, True, 0.1, 0.001);  primals_1053 = None
        getitem_540 = native_batch_norm_default_158[0]
        getitem_541 = native_batch_norm_default_158[1]
        getitem_542 = native_batch_norm_default_158[2];  native_batch_norm_default_158 = None
        new_zeros_default_158 = torch.ops.aten.new_zeros.default(convolution_default_293, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_55 = torch.ops.aten.add.Tensor(getitem_537, getitem_540);  getitem_537 = getitem_540 = None
        cat_default_13 = torch.ops.aten.cat.default([add_tensor_51, add_tensor_52, add_tensor_53, add_tensor_54, add_tensor_55], 1);  add_tensor_51 = add_tensor_52 = add_tensor_53 = add_tensor_54 = add_tensor_55 = None
        relu_default_157 = torch.ops.aten.relu.default(cat_default_12);  cat_default_12 = None
        avg_pool2d_default_6 = torch.ops.aten.avg_pool2d.default(relu_default_157, [1, 1], [2, 2], [0, 0], False, False)
        convolution_default_294 = torch.ops.aten.convolution.default(avg_pool2d_default_6, primals_1166, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        constant_pad_nd_default_35 = torch.ops.aten.constant_pad_nd.default(relu_default_157, [-1, 1, -1, 1], 0.0)
        avg_pool2d_default_7 = torch.ops.aten.avg_pool2d.default(constant_pad_nd_default_35, [1, 1], [2, 2], [0, 0], False, False)
        convolution_default_295 = torch.ops.aten.convolution.default(avg_pool2d_default_7, primals_1167, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_14 = torch.ops.aten.cat.default([convolution_default_294, convolution_default_295], 1);  convolution_default_294 = convolution_default_295 = None
        add__tensor_158 = torch.ops.aten.add_.Tensor(primals_1162, 1);  primals_1162 = None
        native_batch_norm_default_159 = torch.ops.aten.native_batch_norm.default(cat_default_14, primals_1165, primals_1161, primals_1163, primals_1164, True, 0.1, 0.001);  primals_1161 = None
        getitem_543 = native_batch_norm_default_159[0]
        getitem_544 = native_batch_norm_default_159[1]
        getitem_545 = native_batch_norm_default_159[2];  native_batch_norm_default_159 = None
        new_zeros_default_159 = torch.ops.aten.new_zeros.default(cat_default_14, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_158 = torch.ops.aten.relu.default(cat_default_13)
        convolution_default_296 = torch.ops.aten.convolution.default(relu_default_158, primals_1160, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_159 = torch.ops.aten.add_.Tensor(primals_1156, 1);  primals_1156 = None
        native_batch_norm_default_160 = torch.ops.aten.native_batch_norm.default(convolution_default_296, primals_1159, primals_1155, primals_1157, primals_1158, True, 0.1, 0.001);  primals_1155 = None
        getitem_546 = native_batch_norm_default_160[0]
        getitem_547 = native_batch_norm_default_160[1]
        getitem_548 = native_batch_norm_default_160[2];  native_batch_norm_default_160 = None
        new_zeros_default_160 = torch.ops.aten.new_zeros.default(convolution_default_296, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_159 = torch.ops.aten.relu.default(getitem_543)
        convolution_default_297 = torch.ops.aten.convolution.default(relu_default_159, primals_1081, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 864)
        convolution_default_298 = torch.ops.aten.convolution.default(convolution_default_297, primals_1082, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_160 = torch.ops.aten.add_.Tensor(primals_1072, 1);  primals_1072 = None
        native_batch_norm_default_161 = torch.ops.aten.native_batch_norm.default(convolution_default_298, primals_1075, primals_1071, primals_1073, primals_1074, True, 0.1, 0.001);  primals_1071 = None
        getitem_549 = native_batch_norm_default_161[0]
        getitem_550 = native_batch_norm_default_161[1]
        getitem_551 = native_batch_norm_default_161[2];  native_batch_norm_default_161 = None
        new_zeros_default_161 = torch.ops.aten.new_zeros.default(convolution_default_298, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_160 = torch.ops.aten.relu.default(getitem_549);  getitem_549 = None
        convolution_default_299 = torch.ops.aten.convolution.default(relu_default_160, primals_1083, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 864)
        convolution_default_300 = torch.ops.aten.convolution.default(convolution_default_299, primals_1084, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_161 = torch.ops.aten.add_.Tensor(primals_1077, 1);  primals_1077 = None
        native_batch_norm_default_162 = torch.ops.aten.native_batch_norm.default(convolution_default_300, primals_1080, primals_1076, primals_1078, primals_1079, True, 0.1, 0.001);  primals_1076 = None
        getitem_552 = native_batch_norm_default_162[0]
        getitem_553 = native_batch_norm_default_162[1]
        getitem_554 = native_batch_norm_default_162[2];  native_batch_norm_default_162 = None
        new_zeros_default_162 = torch.ops.aten.new_zeros.default(convolution_default_300, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        max_pool2d_with_indices_default_33 = torch.ops.aten.max_pool2d_with_indices.default(getitem_543, [3, 3], [1, 1], [1, 1])
        getitem_555 = max_pool2d_with_indices_default_33[0]
        getitem_556 = max_pool2d_with_indices_default_33[1];  max_pool2d_with_indices_default_33 = None
        add_tensor_56 = torch.ops.aten.add.Tensor(getitem_552, getitem_555);  getitem_552 = getitem_555 = None
        relu_default_161 = torch.ops.aten.relu.default(getitem_546)
        convolution_default_301 = torch.ops.aten.convolution.default(relu_default_161, primals_1095, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 864)
        convolution_default_302 = torch.ops.aten.convolution.default(convolution_default_301, primals_1096, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_162 = torch.ops.aten.add_.Tensor(primals_1086, 1);  primals_1086 = None
        native_batch_norm_default_163 = torch.ops.aten.native_batch_norm.default(convolution_default_302, primals_1089, primals_1085, primals_1087, primals_1088, True, 0.1, 0.001);  primals_1085 = None
        getitem_557 = native_batch_norm_default_163[0]
        getitem_558 = native_batch_norm_default_163[1]
        getitem_559 = native_batch_norm_default_163[2];  native_batch_norm_default_163 = None
        new_zeros_default_163 = torch.ops.aten.new_zeros.default(convolution_default_302, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_162 = torch.ops.aten.relu.default(getitem_557);  getitem_557 = None
        convolution_default_303 = torch.ops.aten.convolution.default(relu_default_162, primals_1097, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 864)
        convolution_default_304 = torch.ops.aten.convolution.default(convolution_default_303, primals_1098, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_163 = torch.ops.aten.add_.Tensor(primals_1091, 1);  primals_1091 = None
        native_batch_norm_default_164 = torch.ops.aten.native_batch_norm.default(convolution_default_304, primals_1094, primals_1090, primals_1092, primals_1093, True, 0.1, 0.001);  primals_1090 = None
        getitem_560 = native_batch_norm_default_164[0]
        getitem_561 = native_batch_norm_default_164[1]
        getitem_562 = native_batch_norm_default_164[2];  native_batch_norm_default_164 = None
        new_zeros_default_164 = torch.ops.aten.new_zeros.default(convolution_default_304, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        max_pool2d_with_indices_default_34 = torch.ops.aten.max_pool2d_with_indices.default(getitem_546, [3, 3], [1, 1], [1, 1])
        getitem_563 = max_pool2d_with_indices_default_34[0]
        getitem_564 = max_pool2d_with_indices_default_34[1];  max_pool2d_with_indices_default_34 = None
        add_tensor_57 = torch.ops.aten.add.Tensor(getitem_560, getitem_563);  getitem_560 = getitem_563 = None
        relu_default_163 = torch.ops.aten.relu.default(getitem_546)
        convolution_default_305 = torch.ops.aten.convolution.default(relu_default_163, primals_1109, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 864)
        convolution_default_306 = torch.ops.aten.convolution.default(convolution_default_305, primals_1110, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_164 = torch.ops.aten.add_.Tensor(primals_1100, 1);  primals_1100 = None
        native_batch_norm_default_165 = torch.ops.aten.native_batch_norm.default(convolution_default_306, primals_1103, primals_1099, primals_1101, primals_1102, True, 0.1, 0.001);  primals_1099 = None
        getitem_565 = native_batch_norm_default_165[0]
        getitem_566 = native_batch_norm_default_165[1]
        getitem_567 = native_batch_norm_default_165[2];  native_batch_norm_default_165 = None
        new_zeros_default_165 = torch.ops.aten.new_zeros.default(convolution_default_306, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_164 = torch.ops.aten.relu.default(getitem_565);  getitem_565 = None
        convolution_default_307 = torch.ops.aten.convolution.default(relu_default_164, primals_1111, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 864)
        convolution_default_308 = torch.ops.aten.convolution.default(convolution_default_307, primals_1112, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_165 = torch.ops.aten.add_.Tensor(primals_1105, 1);  primals_1105 = None
        native_batch_norm_default_166 = torch.ops.aten.native_batch_norm.default(convolution_default_308, primals_1108, primals_1104, primals_1106, primals_1107, True, 0.1, 0.001);  primals_1104 = None
        getitem_568 = native_batch_norm_default_166[0]
        getitem_569 = native_batch_norm_default_166[1]
        getitem_570 = native_batch_norm_default_166[2];  native_batch_norm_default_166 = None
        new_zeros_default_166 = torch.ops.aten.new_zeros.default(convolution_default_308, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_165 = torch.ops.aten.relu.default(getitem_546)
        convolution_default_309 = torch.ops.aten.convolution.default(relu_default_165, primals_1123, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_310 = torch.ops.aten.convolution.default(convolution_default_309, primals_1124, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_166 = torch.ops.aten.add_.Tensor(primals_1114, 1);  primals_1114 = None
        native_batch_norm_default_167 = torch.ops.aten.native_batch_norm.default(convolution_default_310, primals_1117, primals_1113, primals_1115, primals_1116, True, 0.1, 0.001);  primals_1113 = None
        getitem_571 = native_batch_norm_default_167[0]
        getitem_572 = native_batch_norm_default_167[1]
        getitem_573 = native_batch_norm_default_167[2];  native_batch_norm_default_167 = None
        new_zeros_default_167 = torch.ops.aten.new_zeros.default(convolution_default_310, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_166 = torch.ops.aten.relu.default(getitem_571);  getitem_571 = None
        convolution_default_311 = torch.ops.aten.convolution.default(relu_default_166, primals_1125, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_312 = torch.ops.aten.convolution.default(convolution_default_311, primals_1126, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_167 = torch.ops.aten.add_.Tensor(primals_1119, 1);  primals_1119 = None
        native_batch_norm_default_168 = torch.ops.aten.native_batch_norm.default(convolution_default_312, primals_1122, primals_1118, primals_1120, primals_1121, True, 0.1, 0.001);  primals_1118 = None
        getitem_574 = native_batch_norm_default_168[0]
        getitem_575 = native_batch_norm_default_168[1]
        getitem_576 = native_batch_norm_default_168[2];  native_batch_norm_default_168 = None
        new_zeros_default_168 = torch.ops.aten.new_zeros.default(convolution_default_312, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_58 = torch.ops.aten.add.Tensor(getitem_568, getitem_574);  getitem_568 = getitem_574 = None
        relu_default_167 = torch.ops.aten.relu.default(add_tensor_58)
        convolution_default_313 = torch.ops.aten.convolution.default(relu_default_167, primals_1137, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_314 = torch.ops.aten.convolution.default(convolution_default_313, primals_1138, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_168 = torch.ops.aten.add_.Tensor(primals_1128, 1);  primals_1128 = None
        native_batch_norm_default_169 = torch.ops.aten.native_batch_norm.default(convolution_default_314, primals_1131, primals_1127, primals_1129, primals_1130, True, 0.1, 0.001);  primals_1127 = None
        getitem_577 = native_batch_norm_default_169[0]
        getitem_578 = native_batch_norm_default_169[1]
        getitem_579 = native_batch_norm_default_169[2];  native_batch_norm_default_169 = None
        new_zeros_default_169 = torch.ops.aten.new_zeros.default(convolution_default_314, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_168 = torch.ops.aten.relu.default(getitem_577);  getitem_577 = None
        convolution_default_315 = torch.ops.aten.convolution.default(relu_default_168, primals_1139, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_316 = torch.ops.aten.convolution.default(convolution_default_315, primals_1140, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_169 = torch.ops.aten.add_.Tensor(primals_1133, 1);  primals_1133 = None
        native_batch_norm_default_170 = torch.ops.aten.native_batch_norm.default(convolution_default_316, primals_1136, primals_1132, primals_1134, primals_1135, True, 0.1, 0.001);  primals_1132 = None
        getitem_580 = native_batch_norm_default_170[0]
        getitem_581 = native_batch_norm_default_170[1]
        getitem_582 = native_batch_norm_default_170[2];  native_batch_norm_default_170 = None
        new_zeros_default_170 = torch.ops.aten.new_zeros.default(convolution_default_316, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        max_pool2d_with_indices_default_35 = torch.ops.aten.max_pool2d_with_indices.default(getitem_546, [3, 3], [1, 1], [1, 1])
        getitem_583 = max_pool2d_with_indices_default_35[0]
        getitem_584 = max_pool2d_with_indices_default_35[1];  max_pool2d_with_indices_default_35 = None
        add_tensor_59 = torch.ops.aten.add.Tensor(getitem_580, getitem_583);  getitem_580 = getitem_583 = None
        relu_default_169 = torch.ops.aten.relu.default(getitem_543)
        convolution_default_317 = torch.ops.aten.convolution.default(relu_default_169, primals_1151, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_318 = torch.ops.aten.convolution.default(convolution_default_317, primals_1152, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_170 = torch.ops.aten.add_.Tensor(primals_1142, 1);  primals_1142 = None
        native_batch_norm_default_171 = torch.ops.aten.native_batch_norm.default(convolution_default_318, primals_1145, primals_1141, primals_1143, primals_1144, True, 0.1, 0.001);  primals_1141 = None
        getitem_585 = native_batch_norm_default_171[0]
        getitem_586 = native_batch_norm_default_171[1]
        getitem_587 = native_batch_norm_default_171[2];  native_batch_norm_default_171 = None
        new_zeros_default_171 = torch.ops.aten.new_zeros.default(convolution_default_318, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_170 = torch.ops.aten.relu.default(getitem_585);  getitem_585 = None
        convolution_default_319 = torch.ops.aten.convolution.default(relu_default_170, primals_1153, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_320 = torch.ops.aten.convolution.default(convolution_default_319, primals_1154, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_171 = torch.ops.aten.add_.Tensor(primals_1147, 1);  primals_1147 = None
        native_batch_norm_default_172 = torch.ops.aten.native_batch_norm.default(convolution_default_320, primals_1150, primals_1146, primals_1148, primals_1149, True, 0.1, 0.001);  primals_1146 = None
        getitem_588 = native_batch_norm_default_172[0]
        getitem_589 = native_batch_norm_default_172[1]
        getitem_590 = native_batch_norm_default_172[2];  native_batch_norm_default_172 = None
        new_zeros_default_172 = torch.ops.aten.new_zeros.default(convolution_default_320, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_60 = torch.ops.aten.add.Tensor(getitem_588, getitem_546);  getitem_588 = None
        cat_default_15 = torch.ops.aten.cat.default([add_tensor_56, add_tensor_57, add_tensor_58, add_tensor_59, add_tensor_60], 1);  add_tensor_56 = add_tensor_57 = add_tensor_58 = add_tensor_59 = add_tensor_60 = None
        relu_default_171 = torch.ops.aten.relu.default(cat_default_13);  cat_default_13 = None
        convolution_default_321 = torch.ops.aten.convolution.default(relu_default_171, primals_193, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_172 = torch.ops.aten.add_.Tensor(primals_189, 1);  primals_189 = None
        native_batch_norm_default_173 = torch.ops.aten.native_batch_norm.default(convolution_default_321, primals_192, primals_188, primals_190, primals_191, True, 0.1, 0.001);  primals_188 = None
        getitem_591 = native_batch_norm_default_173[0]
        getitem_592 = native_batch_norm_default_173[1]
        getitem_593 = native_batch_norm_default_173[2];  native_batch_norm_default_173 = None
        new_zeros_default_173 = torch.ops.aten.new_zeros.default(convolution_default_321, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_172 = torch.ops.aten.relu.default(cat_default_15)
        convolution_default_322 = torch.ops.aten.convolution.default(relu_default_172, primals_187, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_173 = torch.ops.aten.add_.Tensor(primals_183, 1);  primals_183 = None
        native_batch_norm_default_174 = torch.ops.aten.native_batch_norm.default(convolution_default_322, primals_186, primals_182, primals_184, primals_185, True, 0.1, 0.001);  primals_182 = None
        getitem_594 = native_batch_norm_default_174[0]
        getitem_595 = native_batch_norm_default_174[1]
        getitem_596 = native_batch_norm_default_174[2];  native_batch_norm_default_174 = None
        new_zeros_default_174 = torch.ops.aten.new_zeros.default(convolution_default_322, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_173 = torch.ops.aten.relu.default(getitem_591)
        convolution_default_323 = torch.ops.aten.convolution.default(relu_default_173, primals_108, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 864)
        convolution_default_324 = torch.ops.aten.convolution.default(convolution_default_323, primals_109, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_174 = torch.ops.aten.add_.Tensor(primals_99, 1);  primals_99 = None
        native_batch_norm_default_175 = torch.ops.aten.native_batch_norm.default(convolution_default_324, primals_102, primals_98, primals_100, primals_101, True, 0.1, 0.001);  primals_98 = None
        getitem_597 = native_batch_norm_default_175[0]
        getitem_598 = native_batch_norm_default_175[1]
        getitem_599 = native_batch_norm_default_175[2];  native_batch_norm_default_175 = None
        new_zeros_default_175 = torch.ops.aten.new_zeros.default(convolution_default_324, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_174 = torch.ops.aten.relu.default(getitem_597);  getitem_597 = None
        convolution_default_325 = torch.ops.aten.convolution.default(relu_default_174, primals_110, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 864)
        convolution_default_326 = torch.ops.aten.convolution.default(convolution_default_325, primals_111, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_175 = torch.ops.aten.add_.Tensor(primals_104, 1);  primals_104 = None
        native_batch_norm_default_176 = torch.ops.aten.native_batch_norm.default(convolution_default_326, primals_107, primals_103, primals_105, primals_106, True, 0.1, 0.001);  primals_103 = None
        getitem_600 = native_batch_norm_default_176[0]
        getitem_601 = native_batch_norm_default_176[1]
        getitem_602 = native_batch_norm_default_176[2];  native_batch_norm_default_176 = None
        new_zeros_default_176 = torch.ops.aten.new_zeros.default(convolution_default_326, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        max_pool2d_with_indices_default_36 = torch.ops.aten.max_pool2d_with_indices.default(getitem_591, [3, 3], [1, 1], [1, 1])
        getitem_603 = max_pool2d_with_indices_default_36[0]
        getitem_604 = max_pool2d_with_indices_default_36[1];  max_pool2d_with_indices_default_36 = None
        add_tensor_61 = torch.ops.aten.add.Tensor(getitem_600, getitem_603);  getitem_600 = getitem_603 = None
        relu_default_175 = torch.ops.aten.relu.default(getitem_594)
        convolution_default_327 = torch.ops.aten.convolution.default(relu_default_175, primals_122, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 864)
        convolution_default_328 = torch.ops.aten.convolution.default(convolution_default_327, primals_123, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_176 = torch.ops.aten.add_.Tensor(primals_113, 1);  primals_113 = None
        native_batch_norm_default_177 = torch.ops.aten.native_batch_norm.default(convolution_default_328, primals_116, primals_112, primals_114, primals_115, True, 0.1, 0.001);  primals_112 = None
        getitem_605 = native_batch_norm_default_177[0]
        getitem_606 = native_batch_norm_default_177[1]
        getitem_607 = native_batch_norm_default_177[2];  native_batch_norm_default_177 = None
        new_zeros_default_177 = torch.ops.aten.new_zeros.default(convolution_default_328, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_176 = torch.ops.aten.relu.default(getitem_605);  getitem_605 = None
        convolution_default_329 = torch.ops.aten.convolution.default(relu_default_176, primals_124, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 864)
        convolution_default_330 = torch.ops.aten.convolution.default(convolution_default_329, primals_125, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_177 = torch.ops.aten.add_.Tensor(primals_118, 1);  primals_118 = None
        native_batch_norm_default_178 = torch.ops.aten.native_batch_norm.default(convolution_default_330, primals_121, primals_117, primals_119, primals_120, True, 0.1, 0.001);  primals_117 = None
        getitem_608 = native_batch_norm_default_178[0]
        getitem_609 = native_batch_norm_default_178[1]
        getitem_610 = native_batch_norm_default_178[2];  native_batch_norm_default_178 = None
        new_zeros_default_178 = torch.ops.aten.new_zeros.default(convolution_default_330, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        max_pool2d_with_indices_default_37 = torch.ops.aten.max_pool2d_with_indices.default(getitem_594, [3, 3], [1, 1], [1, 1])
        getitem_611 = max_pool2d_with_indices_default_37[0]
        getitem_612 = max_pool2d_with_indices_default_37[1];  max_pool2d_with_indices_default_37 = None
        add_tensor_62 = torch.ops.aten.add.Tensor(getitem_608, getitem_611);  getitem_608 = getitem_611 = None
        relu_default_177 = torch.ops.aten.relu.default(getitem_594)
        convolution_default_331 = torch.ops.aten.convolution.default(relu_default_177, primals_136, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 864)
        convolution_default_332 = torch.ops.aten.convolution.default(convolution_default_331, primals_137, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_178 = torch.ops.aten.add_.Tensor(primals_127, 1);  primals_127 = None
        native_batch_norm_default_179 = torch.ops.aten.native_batch_norm.default(convolution_default_332, primals_130, primals_126, primals_128, primals_129, True, 0.1, 0.001);  primals_126 = None
        getitem_613 = native_batch_norm_default_179[0]
        getitem_614 = native_batch_norm_default_179[1]
        getitem_615 = native_batch_norm_default_179[2];  native_batch_norm_default_179 = None
        new_zeros_default_179 = torch.ops.aten.new_zeros.default(convolution_default_332, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_178 = torch.ops.aten.relu.default(getitem_613);  getitem_613 = None
        convolution_default_333 = torch.ops.aten.convolution.default(relu_default_178, primals_138, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 864)
        convolution_default_334 = torch.ops.aten.convolution.default(convolution_default_333, primals_139, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_179 = torch.ops.aten.add_.Tensor(primals_132, 1);  primals_132 = None
        native_batch_norm_default_180 = torch.ops.aten.native_batch_norm.default(convolution_default_334, primals_135, primals_131, primals_133, primals_134, True, 0.1, 0.001);  primals_131 = None
        getitem_616 = native_batch_norm_default_180[0]
        getitem_617 = native_batch_norm_default_180[1]
        getitem_618 = native_batch_norm_default_180[2];  native_batch_norm_default_180 = None
        new_zeros_default_180 = torch.ops.aten.new_zeros.default(convolution_default_334, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_179 = torch.ops.aten.relu.default(getitem_594)
        convolution_default_335 = torch.ops.aten.convolution.default(relu_default_179, primals_150, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_336 = torch.ops.aten.convolution.default(convolution_default_335, primals_151, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_180 = torch.ops.aten.add_.Tensor(primals_141, 1);  primals_141 = None
        native_batch_norm_default_181 = torch.ops.aten.native_batch_norm.default(convolution_default_336, primals_144, primals_140, primals_142, primals_143, True, 0.1, 0.001);  primals_140 = None
        getitem_619 = native_batch_norm_default_181[0]
        getitem_620 = native_batch_norm_default_181[1]
        getitem_621 = native_batch_norm_default_181[2];  native_batch_norm_default_181 = None
        new_zeros_default_181 = torch.ops.aten.new_zeros.default(convolution_default_336, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_180 = torch.ops.aten.relu.default(getitem_619);  getitem_619 = None
        convolution_default_337 = torch.ops.aten.convolution.default(relu_default_180, primals_152, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_338 = torch.ops.aten.convolution.default(convolution_default_337, primals_153, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_181 = torch.ops.aten.add_.Tensor(primals_146, 1);  primals_146 = None
        native_batch_norm_default_182 = torch.ops.aten.native_batch_norm.default(convolution_default_338, primals_149, primals_145, primals_147, primals_148, True, 0.1, 0.001);  primals_145 = None
        getitem_622 = native_batch_norm_default_182[0]
        getitem_623 = native_batch_norm_default_182[1]
        getitem_624 = native_batch_norm_default_182[2];  native_batch_norm_default_182 = None
        new_zeros_default_182 = torch.ops.aten.new_zeros.default(convolution_default_338, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_63 = torch.ops.aten.add.Tensor(getitem_616, getitem_622);  getitem_616 = getitem_622 = None
        relu_default_181 = torch.ops.aten.relu.default(add_tensor_63)
        convolution_default_339 = torch.ops.aten.convolution.default(relu_default_181, primals_164, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_340 = torch.ops.aten.convolution.default(convolution_default_339, primals_165, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_182 = torch.ops.aten.add_.Tensor(primals_155, 1);  primals_155 = None
        native_batch_norm_default_183 = torch.ops.aten.native_batch_norm.default(convolution_default_340, primals_158, primals_154, primals_156, primals_157, True, 0.1, 0.001);  primals_154 = None
        getitem_625 = native_batch_norm_default_183[0]
        getitem_626 = native_batch_norm_default_183[1]
        getitem_627 = native_batch_norm_default_183[2];  native_batch_norm_default_183 = None
        new_zeros_default_183 = torch.ops.aten.new_zeros.default(convolution_default_340, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_182 = torch.ops.aten.relu.default(getitem_625);  getitem_625 = None
        convolution_default_341 = torch.ops.aten.convolution.default(relu_default_182, primals_166, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_342 = torch.ops.aten.convolution.default(convolution_default_341, primals_167, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_183 = torch.ops.aten.add_.Tensor(primals_160, 1);  primals_160 = None
        native_batch_norm_default_184 = torch.ops.aten.native_batch_norm.default(convolution_default_342, primals_163, primals_159, primals_161, primals_162, True, 0.1, 0.001);  primals_159 = None
        getitem_628 = native_batch_norm_default_184[0]
        getitem_629 = native_batch_norm_default_184[1]
        getitem_630 = native_batch_norm_default_184[2];  native_batch_norm_default_184 = None
        new_zeros_default_184 = torch.ops.aten.new_zeros.default(convolution_default_342, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        max_pool2d_with_indices_default_38 = torch.ops.aten.max_pool2d_with_indices.default(getitem_594, [3, 3], [1, 1], [1, 1])
        getitem_631 = max_pool2d_with_indices_default_38[0]
        getitem_632 = max_pool2d_with_indices_default_38[1];  max_pool2d_with_indices_default_38 = None
        add_tensor_64 = torch.ops.aten.add.Tensor(getitem_628, getitem_631);  getitem_628 = getitem_631 = None
        relu_default_183 = torch.ops.aten.relu.default(getitem_591)
        convolution_default_343 = torch.ops.aten.convolution.default(relu_default_183, primals_178, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_344 = torch.ops.aten.convolution.default(convolution_default_343, primals_179, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_184 = torch.ops.aten.add_.Tensor(primals_169, 1);  primals_169 = None
        native_batch_norm_default_185 = torch.ops.aten.native_batch_norm.default(convolution_default_344, primals_172, primals_168, primals_170, primals_171, True, 0.1, 0.001);  primals_168 = None
        getitem_633 = native_batch_norm_default_185[0]
        getitem_634 = native_batch_norm_default_185[1]
        getitem_635 = native_batch_norm_default_185[2];  native_batch_norm_default_185 = None
        new_zeros_default_185 = torch.ops.aten.new_zeros.default(convolution_default_344, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_184 = torch.ops.aten.relu.default(getitem_633);  getitem_633 = None
        convolution_default_345 = torch.ops.aten.convolution.default(relu_default_184, primals_180, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_346 = torch.ops.aten.convolution.default(convolution_default_345, primals_181, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_185 = torch.ops.aten.add_.Tensor(primals_174, 1);  primals_174 = None
        native_batch_norm_default_186 = torch.ops.aten.native_batch_norm.default(convolution_default_346, primals_177, primals_173, primals_175, primals_176, True, 0.1, 0.001);  primals_173 = None
        getitem_636 = native_batch_norm_default_186[0]
        getitem_637 = native_batch_norm_default_186[1]
        getitem_638 = native_batch_norm_default_186[2];  native_batch_norm_default_186 = None
        new_zeros_default_186 = torch.ops.aten.new_zeros.default(convolution_default_346, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_65 = torch.ops.aten.add.Tensor(getitem_636, getitem_594);  getitem_636 = None
        cat_default_16 = torch.ops.aten.cat.default([add_tensor_61, add_tensor_62, add_tensor_63, add_tensor_64, add_tensor_65], 1);  add_tensor_61 = add_tensor_62 = add_tensor_63 = add_tensor_64 = add_tensor_65 = None
        relu_default_185 = torch.ops.aten.relu.default(cat_default_15);  cat_default_15 = None
        convolution_default_347 = torch.ops.aten.convolution.default(relu_default_185, primals_289, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_186 = torch.ops.aten.add_.Tensor(primals_285, 1);  primals_285 = None
        native_batch_norm_default_187 = torch.ops.aten.native_batch_norm.default(convolution_default_347, primals_288, primals_284, primals_286, primals_287, True, 0.1, 0.001);  primals_284 = None
        getitem_639 = native_batch_norm_default_187[0]
        getitem_640 = native_batch_norm_default_187[1]
        getitem_641 = native_batch_norm_default_187[2];  native_batch_norm_default_187 = None
        new_zeros_default_187 = torch.ops.aten.new_zeros.default(convolution_default_347, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_186 = torch.ops.aten.relu.default(cat_default_16);  cat_default_16 = None
        convolution_default_348 = torch.ops.aten.convolution.default(relu_default_186, primals_283, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_187 = torch.ops.aten.add_.Tensor(primals_279, 1);  primals_279 = None
        native_batch_norm_default_188 = torch.ops.aten.native_batch_norm.default(convolution_default_348, primals_282, primals_278, primals_280, primals_281, True, 0.1, 0.001);  primals_278 = None
        getitem_642 = native_batch_norm_default_188[0]
        getitem_643 = native_batch_norm_default_188[1]
        getitem_644 = native_batch_norm_default_188[2];  native_batch_norm_default_188 = None
        new_zeros_default_188 = torch.ops.aten.new_zeros.default(convolution_default_348, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_187 = torch.ops.aten.relu.default(getitem_639)
        convolution_default_349 = torch.ops.aten.convolution.default(relu_default_187, primals_204, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 864)
        convolution_default_350 = torch.ops.aten.convolution.default(convolution_default_349, primals_205, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_188 = torch.ops.aten.add_.Tensor(primals_195, 1);  primals_195 = None
        native_batch_norm_default_189 = torch.ops.aten.native_batch_norm.default(convolution_default_350, primals_198, primals_194, primals_196, primals_197, True, 0.1, 0.001);  primals_194 = None
        getitem_645 = native_batch_norm_default_189[0]
        getitem_646 = native_batch_norm_default_189[1]
        getitem_647 = native_batch_norm_default_189[2];  native_batch_norm_default_189 = None
        new_zeros_default_189 = torch.ops.aten.new_zeros.default(convolution_default_350, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_188 = torch.ops.aten.relu.default(getitem_645);  getitem_645 = None
        convolution_default_351 = torch.ops.aten.convolution.default(relu_default_188, primals_206, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 864)
        convolution_default_352 = torch.ops.aten.convolution.default(convolution_default_351, primals_207, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_189 = torch.ops.aten.add_.Tensor(primals_200, 1);  primals_200 = None
        native_batch_norm_default_190 = torch.ops.aten.native_batch_norm.default(convolution_default_352, primals_203, primals_199, primals_201, primals_202, True, 0.1, 0.001);  primals_199 = None
        getitem_648 = native_batch_norm_default_190[0]
        getitem_649 = native_batch_norm_default_190[1]
        getitem_650 = native_batch_norm_default_190[2];  native_batch_norm_default_190 = None
        new_zeros_default_190 = torch.ops.aten.new_zeros.default(convolution_default_352, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        max_pool2d_with_indices_default_39 = torch.ops.aten.max_pool2d_with_indices.default(getitem_639, [3, 3], [1, 1], [1, 1])
        getitem_651 = max_pool2d_with_indices_default_39[0]
        getitem_652 = max_pool2d_with_indices_default_39[1];  max_pool2d_with_indices_default_39 = None
        add_tensor_66 = torch.ops.aten.add.Tensor(getitem_648, getitem_651);  getitem_648 = getitem_651 = None
        relu_default_189 = torch.ops.aten.relu.default(getitem_642)
        convolution_default_353 = torch.ops.aten.convolution.default(relu_default_189, primals_218, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 864)
        convolution_default_354 = torch.ops.aten.convolution.default(convolution_default_353, primals_219, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_190 = torch.ops.aten.add_.Tensor(primals_209, 1);  primals_209 = None
        native_batch_norm_default_191 = torch.ops.aten.native_batch_norm.default(convolution_default_354, primals_212, primals_208, primals_210, primals_211, True, 0.1, 0.001);  primals_208 = None
        getitem_653 = native_batch_norm_default_191[0]
        getitem_654 = native_batch_norm_default_191[1]
        getitem_655 = native_batch_norm_default_191[2];  native_batch_norm_default_191 = None
        new_zeros_default_191 = torch.ops.aten.new_zeros.default(convolution_default_354, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_190 = torch.ops.aten.relu.default(getitem_653);  getitem_653 = None
        convolution_default_355 = torch.ops.aten.convolution.default(relu_default_190, primals_220, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 864)
        convolution_default_356 = torch.ops.aten.convolution.default(convolution_default_355, primals_221, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_191 = torch.ops.aten.add_.Tensor(primals_214, 1);  primals_214 = None
        native_batch_norm_default_192 = torch.ops.aten.native_batch_norm.default(convolution_default_356, primals_217, primals_213, primals_215, primals_216, True, 0.1, 0.001);  primals_213 = None
        getitem_656 = native_batch_norm_default_192[0]
        getitem_657 = native_batch_norm_default_192[1]
        getitem_658 = native_batch_norm_default_192[2];  native_batch_norm_default_192 = None
        new_zeros_default_192 = torch.ops.aten.new_zeros.default(convolution_default_356, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        max_pool2d_with_indices_default_40 = torch.ops.aten.max_pool2d_with_indices.default(getitem_642, [3, 3], [1, 1], [1, 1])
        getitem_659 = max_pool2d_with_indices_default_40[0]
        getitem_660 = max_pool2d_with_indices_default_40[1];  max_pool2d_with_indices_default_40 = None
        add_tensor_67 = torch.ops.aten.add.Tensor(getitem_656, getitem_659);  getitem_656 = getitem_659 = None
        relu_default_191 = torch.ops.aten.relu.default(getitem_642)
        convolution_default_357 = torch.ops.aten.convolution.default(relu_default_191, primals_232, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 864)
        convolution_default_358 = torch.ops.aten.convolution.default(convolution_default_357, primals_233, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_192 = torch.ops.aten.add_.Tensor(primals_223, 1);  primals_223 = None
        native_batch_norm_default_193 = torch.ops.aten.native_batch_norm.default(convolution_default_358, primals_226, primals_222, primals_224, primals_225, True, 0.1, 0.001);  primals_222 = None
        getitem_661 = native_batch_norm_default_193[0]
        getitem_662 = native_batch_norm_default_193[1]
        getitem_663 = native_batch_norm_default_193[2];  native_batch_norm_default_193 = None
        new_zeros_default_193 = torch.ops.aten.new_zeros.default(convolution_default_358, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_192 = torch.ops.aten.relu.default(getitem_661);  getitem_661 = None
        convolution_default_359 = torch.ops.aten.convolution.default(relu_default_192, primals_234, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 864)
        convolution_default_360 = torch.ops.aten.convolution.default(convolution_default_359, primals_235, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_193 = torch.ops.aten.add_.Tensor(primals_228, 1);  primals_228 = None
        native_batch_norm_default_194 = torch.ops.aten.native_batch_norm.default(convolution_default_360, primals_231, primals_227, primals_229, primals_230, True, 0.1, 0.001);  primals_227 = None
        getitem_664 = native_batch_norm_default_194[0]
        getitem_665 = native_batch_norm_default_194[1]
        getitem_666 = native_batch_norm_default_194[2];  native_batch_norm_default_194 = None
        new_zeros_default_194 = torch.ops.aten.new_zeros.default(convolution_default_360, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_193 = torch.ops.aten.relu.default(getitem_642)
        convolution_default_361 = torch.ops.aten.convolution.default(relu_default_193, primals_246, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_362 = torch.ops.aten.convolution.default(convolution_default_361, primals_247, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_194 = torch.ops.aten.add_.Tensor(primals_237, 1);  primals_237 = None
        native_batch_norm_default_195 = torch.ops.aten.native_batch_norm.default(convolution_default_362, primals_240, primals_236, primals_238, primals_239, True, 0.1, 0.001);  primals_236 = None
        getitem_667 = native_batch_norm_default_195[0]
        getitem_668 = native_batch_norm_default_195[1]
        getitem_669 = native_batch_norm_default_195[2];  native_batch_norm_default_195 = None
        new_zeros_default_195 = torch.ops.aten.new_zeros.default(convolution_default_362, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_194 = torch.ops.aten.relu.default(getitem_667);  getitem_667 = None
        convolution_default_363 = torch.ops.aten.convolution.default(relu_default_194, primals_248, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_364 = torch.ops.aten.convolution.default(convolution_default_363, primals_249, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_195 = torch.ops.aten.add_.Tensor(primals_242, 1);  primals_242 = None
        native_batch_norm_default_196 = torch.ops.aten.native_batch_norm.default(convolution_default_364, primals_245, primals_241, primals_243, primals_244, True, 0.1, 0.001);  primals_241 = None
        getitem_670 = native_batch_norm_default_196[0]
        getitem_671 = native_batch_norm_default_196[1]
        getitem_672 = native_batch_norm_default_196[2];  native_batch_norm_default_196 = None
        new_zeros_default_196 = torch.ops.aten.new_zeros.default(convolution_default_364, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_68 = torch.ops.aten.add.Tensor(getitem_664, getitem_670);  getitem_664 = getitem_670 = None
        relu_default_195 = torch.ops.aten.relu.default(add_tensor_68)
        convolution_default_365 = torch.ops.aten.convolution.default(relu_default_195, primals_260, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_366 = torch.ops.aten.convolution.default(convolution_default_365, primals_261, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_196 = torch.ops.aten.add_.Tensor(primals_251, 1);  primals_251 = None
        native_batch_norm_default_197 = torch.ops.aten.native_batch_norm.default(convolution_default_366, primals_254, primals_250, primals_252, primals_253, True, 0.1, 0.001);  primals_250 = None
        getitem_673 = native_batch_norm_default_197[0]
        getitem_674 = native_batch_norm_default_197[1]
        getitem_675 = native_batch_norm_default_197[2];  native_batch_norm_default_197 = None
        new_zeros_default_197 = torch.ops.aten.new_zeros.default(convolution_default_366, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_196 = torch.ops.aten.relu.default(getitem_673);  getitem_673 = None
        convolution_default_367 = torch.ops.aten.convolution.default(relu_default_196, primals_262, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_368 = torch.ops.aten.convolution.default(convolution_default_367, primals_263, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_197 = torch.ops.aten.add_.Tensor(primals_256, 1);  primals_256 = None
        native_batch_norm_default_198 = torch.ops.aten.native_batch_norm.default(convolution_default_368, primals_259, primals_255, primals_257, primals_258, True, 0.1, 0.001);  primals_255 = None
        getitem_676 = native_batch_norm_default_198[0]
        getitem_677 = native_batch_norm_default_198[1]
        getitem_678 = native_batch_norm_default_198[2];  native_batch_norm_default_198 = None
        new_zeros_default_198 = torch.ops.aten.new_zeros.default(convolution_default_368, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        max_pool2d_with_indices_default_41 = torch.ops.aten.max_pool2d_with_indices.default(getitem_642, [3, 3], [1, 1], [1, 1])
        getitem_679 = max_pool2d_with_indices_default_41[0]
        getitem_680 = max_pool2d_with_indices_default_41[1];  max_pool2d_with_indices_default_41 = None
        add_tensor_69 = torch.ops.aten.add.Tensor(getitem_676, getitem_679);  getitem_676 = getitem_679 = None
        relu_default_197 = torch.ops.aten.relu.default(getitem_639)
        convolution_default_369 = torch.ops.aten.convolution.default(relu_default_197, primals_274, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_370 = torch.ops.aten.convolution.default(convolution_default_369, primals_275, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_198 = torch.ops.aten.add_.Tensor(primals_265, 1);  primals_265 = None
        native_batch_norm_default_199 = torch.ops.aten.native_batch_norm.default(convolution_default_370, primals_268, primals_264, primals_266, primals_267, True, 0.1, 0.001);  primals_264 = None
        getitem_681 = native_batch_norm_default_199[0]
        getitem_682 = native_batch_norm_default_199[1]
        getitem_683 = native_batch_norm_default_199[2];  native_batch_norm_default_199 = None
        new_zeros_default_199 = torch.ops.aten.new_zeros.default(convolution_default_370, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_198 = torch.ops.aten.relu.default(getitem_681);  getitem_681 = None
        convolution_default_371 = torch.ops.aten.convolution.default(relu_default_198, primals_276, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_372 = torch.ops.aten.convolution.default(convolution_default_371, primals_277, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_199 = torch.ops.aten.add_.Tensor(primals_270, 1);  primals_270 = None
        native_batch_norm_default_200 = torch.ops.aten.native_batch_norm.default(convolution_default_372, primals_273, primals_269, primals_271, primals_272, True, 0.1, 0.001);  primals_269 = None
        getitem_684 = native_batch_norm_default_200[0]
        getitem_685 = native_batch_norm_default_200[1]
        getitem_686 = native_batch_norm_default_200[2];  native_batch_norm_default_200 = None
        new_zeros_default_200 = torch.ops.aten.new_zeros.default(convolution_default_372, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_70 = torch.ops.aten.add.Tensor(getitem_684, getitem_642);  getitem_684 = None
        cat_default_17 = torch.ops.aten.cat.default([add_tensor_66, add_tensor_67, add_tensor_68, add_tensor_69, add_tensor_70], 1);  add_tensor_66 = add_tensor_67 = add_tensor_68 = add_tensor_69 = add_tensor_70 = None
        relu_default_199 = torch.ops.aten.relu.default(cat_default_17);  cat_default_17 = None
        mean_dim = torch.ops.aten.mean.dim(relu_default_199, [-1, -2], True)
        view_default = torch.ops.aten.view.default(mean_dim, [32, 4320]);  mean_dim = None
        t_default = torch.ops.aten.t.default(primals_1375);  primals_1375 = None
        addmm_default = torch.ops.aten.addmm.default(primals_1374, view_default, t_default);  primals_1374 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(addmm_default, tangents_1)
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, view_default);  t_default_2 = view_default = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_1 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        view_default_2 = torch.ops.aten.view.default(mm_default, [32, 4320, 1, 1]);  mm_default = None
        expand_default = torch.ops.aten.expand.default(view_default_2, [32, 4320, 11, 11]);  view_default_2 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 121);  expand_default = None
        to_dtype = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu_default_199, torch.float32);  relu_default_199 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default_201 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_201, to_dtype);  le_scalar = new_zeros_default_201 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        slice_tensor = torch.ops.aten.slice.Tensor(to_dtype_2, 1, 0, 864)
        slice_tensor_1 = torch.ops.aten.slice.Tensor(to_dtype_2, 1, 864, 1728)
        slice_tensor_2 = torch.ops.aten.slice.Tensor(to_dtype_2, 1, 1728, 2592)
        slice_tensor_3 = torch.ops.aten.slice.Tensor(to_dtype_2, 1, 2592, 3456)
        slice_tensor_4 = torch.ops.aten.slice.Tensor(to_dtype_2, 1, 3456, 4320);  to_dtype_2 = None
        clone_default = torch.ops.aten.clone.default(slice_tensor_4, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(clone_default, convolution_default_372, primals_273, primals_271, primals_272, getitem_685, getitem_686, True, 0.001, [True, True, True]);  clone_default = convolution_default_372 = primals_273 = primals_271 = primals_272 = getitem_685 = getitem_686 = None
        getitem_687 = native_batch_norm_backward_default[0]
        getitem_688 = native_batch_norm_backward_default[1]
        getitem_689 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(getitem_687, convolution_default_371, primals_277, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_687 = convolution_default_371 = primals_277 = None
        getitem_690 = convolution_backward_default[0]
        getitem_691 = convolution_backward_default[1]
        getitem_692 = convolution_backward_default[2];  convolution_backward_default = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_690, relu_default_198, primals_276, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_690 = primals_276 = None
        getitem_693 = convolution_backward_default_1[0]
        getitem_694 = convolution_backward_default_1[1]
        getitem_695 = convolution_backward_default_1[2];  convolution_backward_default_1 = None
        to_dtype_3 = torch.ops.aten.to.dtype(getitem_693, torch.float32);  getitem_693 = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu_default_198, torch.float32);  relu_default_198 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_202 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_202, to_dtype_3);  le_scalar_1 = new_zeros_default_202 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_5, convolution_default_370, primals_268, primals_266, primals_267, getitem_682, getitem_683, True, 0.001, [True, True, True]);  to_dtype_5 = convolution_default_370 = primals_268 = primals_266 = primals_267 = getitem_682 = getitem_683 = None
        getitem_696 = native_batch_norm_backward_default_1[0]
        getitem_697 = native_batch_norm_backward_default_1[1]
        getitem_698 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_696, convolution_default_369, primals_275, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_696 = convolution_default_369 = primals_275 = None
        getitem_699 = convolution_backward_default_2[0]
        getitem_700 = convolution_backward_default_2[1]
        getitem_701 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_699, relu_default_197, primals_274, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_699 = primals_274 = None
        getitem_702 = convolution_backward_default_3[0]
        getitem_703 = convolution_backward_default_3[1]
        getitem_704 = convolution_backward_default_3[2];  convolution_backward_default_3 = None
        to_dtype_6 = torch.ops.aten.to.dtype(getitem_702, torch.float32);  getitem_702 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu_default_197, torch.float32);  relu_default_197 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_203 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_203, to_dtype_6);  le_scalar_2 = new_zeros_default_203 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        max_pool2d_with_indices_backward_default = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_3, getitem_642, [3, 3], [1, 1], [1, 1], [1, 1], False, getitem_680);  getitem_680 = None
        add_tensor_71 = torch.ops.aten.add.Tensor(slice_tensor_4, max_pool2d_with_indices_backward_default);  slice_tensor_4 = max_pool2d_with_indices_backward_default = None
        clone_default_1 = torch.ops.aten.clone.default(slice_tensor_3, memory_format = torch.contiguous_format);  slice_tensor_3 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(clone_default_1, convolution_default_368, primals_259, primals_257, primals_258, getitem_677, getitem_678, True, 0.001, [True, True, True]);  clone_default_1 = convolution_default_368 = primals_259 = primals_257 = primals_258 = getitem_677 = getitem_678 = None
        getitem_705 = native_batch_norm_backward_default_2[0]
        getitem_706 = native_batch_norm_backward_default_2[1]
        getitem_707 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_705, convolution_default_367, primals_263, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_705 = convolution_default_367 = primals_263 = None
        getitem_708 = convolution_backward_default_4[0]
        getitem_709 = convolution_backward_default_4[1]
        getitem_710 = convolution_backward_default_4[2];  convolution_backward_default_4 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_708, relu_default_196, primals_262, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_708 = primals_262 = None
        getitem_711 = convolution_backward_default_5[0]
        getitem_712 = convolution_backward_default_5[1]
        getitem_713 = convolution_backward_default_5[2];  convolution_backward_default_5 = None
        to_dtype_9 = torch.ops.aten.to.dtype(getitem_711, torch.float32);  getitem_711 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu_default_196, torch.float32);  relu_default_196 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_204 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_204, to_dtype_9);  le_scalar_3 = new_zeros_default_204 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_366, primals_254, primals_252, primals_253, getitem_674, getitem_675, True, 0.001, [True, True, True]);  to_dtype_11 = convolution_default_366 = primals_254 = primals_252 = primals_253 = getitem_674 = getitem_675 = None
        getitem_714 = native_batch_norm_backward_default_3[0]
        getitem_715 = native_batch_norm_backward_default_3[1]
        getitem_716 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(getitem_714, convolution_default_365, primals_261, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_714 = convolution_default_365 = primals_261 = None
        getitem_717 = convolution_backward_default_6[0]
        getitem_718 = convolution_backward_default_6[1]
        getitem_719 = convolution_backward_default_6[2];  convolution_backward_default_6 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(getitem_717, relu_default_195, primals_260, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_717 = primals_260 = None
        getitem_720 = convolution_backward_default_7[0]
        getitem_721 = convolution_backward_default_7[1]
        getitem_722 = convolution_backward_default_7[2];  convolution_backward_default_7 = None
        to_dtype_12 = torch.ops.aten.to.dtype(getitem_720, torch.float32);  getitem_720 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu_default_195, torch.float32);  relu_default_195 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_205 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_205, to_dtype_12);  le_scalar_4 = new_zeros_default_205 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        add_tensor_72 = torch.ops.aten.add.Tensor(slice_tensor_2, to_dtype_14);  slice_tensor_2 = to_dtype_14 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_72, convolution_default_364, primals_245, primals_243, primals_244, getitem_671, getitem_672, True, 0.001, [True, True, True]);  convolution_default_364 = primals_245 = primals_243 = primals_244 = getitem_671 = getitem_672 = None
        getitem_723 = native_batch_norm_backward_default_4[0]
        getitem_724 = native_batch_norm_backward_default_4[1]
        getitem_725 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(getitem_723, convolution_default_363, primals_249, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_723 = convolution_default_363 = primals_249 = None
        getitem_726 = convolution_backward_default_8[0]
        getitem_727 = convolution_backward_default_8[1]
        getitem_728 = convolution_backward_default_8[2];  convolution_backward_default_8 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_726, relu_default_194, primals_248, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_726 = primals_248 = None
        getitem_729 = convolution_backward_default_9[0]
        getitem_730 = convolution_backward_default_9[1]
        getitem_731 = convolution_backward_default_9[2];  convolution_backward_default_9 = None
        to_dtype_15 = torch.ops.aten.to.dtype(getitem_729, torch.float32);  getitem_729 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu_default_194, torch.float32);  relu_default_194 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_206 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_206, to_dtype_15);  le_scalar_5 = new_zeros_default_206 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_17, convolution_default_362, primals_240, primals_238, primals_239, getitem_668, getitem_669, True, 0.001, [True, True, True]);  to_dtype_17 = convolution_default_362 = primals_240 = primals_238 = primals_239 = getitem_668 = getitem_669 = None
        getitem_732 = native_batch_norm_backward_default_5[0]
        getitem_733 = native_batch_norm_backward_default_5[1]
        getitem_734 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_732, convolution_default_361, primals_247, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_732 = convolution_default_361 = primals_247 = None
        getitem_735 = convolution_backward_default_10[0]
        getitem_736 = convolution_backward_default_10[1]
        getitem_737 = convolution_backward_default_10[2];  convolution_backward_default_10 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_735, relu_default_193, primals_246, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_735 = primals_246 = None
        getitem_738 = convolution_backward_default_11[0]
        getitem_739 = convolution_backward_default_11[1]
        getitem_740 = convolution_backward_default_11[2];  convolution_backward_default_11 = None
        to_dtype_18 = torch.ops.aten.to.dtype(getitem_738, torch.float32);  getitem_738 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu_default_193, torch.float32);  relu_default_193 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_207 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_207, to_dtype_18);  le_scalar_6 = new_zeros_default_207 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        add_tensor_73 = torch.ops.aten.add.Tensor(add_tensor_71, to_dtype_20);  add_tensor_71 = to_dtype_20 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_72, convolution_default_360, primals_231, primals_229, primals_230, getitem_665, getitem_666, True, 0.001, [True, True, True]);  add_tensor_72 = convolution_default_360 = primals_231 = primals_229 = primals_230 = getitem_665 = getitem_666 = None
        getitem_741 = native_batch_norm_backward_default_6[0]
        getitem_742 = native_batch_norm_backward_default_6[1]
        getitem_743 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(getitem_741, convolution_default_359, primals_235, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_741 = convolution_default_359 = primals_235 = None
        getitem_744 = convolution_backward_default_12[0]
        getitem_745 = convolution_backward_default_12[1]
        getitem_746 = convolution_backward_default_12[2];  convolution_backward_default_12 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_744, relu_default_192, primals_234, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_744 = primals_234 = None
        getitem_747 = convolution_backward_default_13[0]
        getitem_748 = convolution_backward_default_13[1]
        getitem_749 = convolution_backward_default_13[2];  convolution_backward_default_13 = None
        to_dtype_21 = torch.ops.aten.to.dtype(getitem_747, torch.float32);  getitem_747 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu_default_192, torch.float32);  relu_default_192 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_208 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_208, to_dtype_21);  le_scalar_7 = new_zeros_default_208 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_23, convolution_default_358, primals_226, primals_224, primals_225, getitem_662, getitem_663, True, 0.001, [True, True, True]);  to_dtype_23 = convolution_default_358 = primals_226 = primals_224 = primals_225 = getitem_662 = getitem_663 = None
        getitem_750 = native_batch_norm_backward_default_7[0]
        getitem_751 = native_batch_norm_backward_default_7[1]
        getitem_752 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_750, convolution_default_357, primals_233, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_750 = convolution_default_357 = primals_233 = None
        getitem_753 = convolution_backward_default_14[0]
        getitem_754 = convolution_backward_default_14[1]
        getitem_755 = convolution_backward_default_14[2];  convolution_backward_default_14 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_753, relu_default_191, primals_232, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_753 = primals_232 = None
        getitem_756 = convolution_backward_default_15[0]
        getitem_757 = convolution_backward_default_15[1]
        getitem_758 = convolution_backward_default_15[2];  convolution_backward_default_15 = None
        to_dtype_24 = torch.ops.aten.to.dtype(getitem_756, torch.float32);  getitem_756 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu_default_191, torch.float32);  relu_default_191 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_209 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_209, to_dtype_24);  le_scalar_8 = new_zeros_default_209 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        add_tensor_74 = torch.ops.aten.add.Tensor(add_tensor_73, to_dtype_26);  add_tensor_73 = to_dtype_26 = None
        max_pool2d_with_indices_backward_default_1 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_1, getitem_642, [3, 3], [1, 1], [1, 1], [1, 1], False, getitem_660);  getitem_642 = getitem_660 = None
        add_tensor_75 = torch.ops.aten.add.Tensor(add_tensor_74, max_pool2d_with_indices_backward_default_1);  add_tensor_74 = max_pool2d_with_indices_backward_default_1 = None
        clone_default_2 = torch.ops.aten.clone.default(slice_tensor_1, memory_format = torch.contiguous_format);  slice_tensor_1 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(clone_default_2, convolution_default_356, primals_217, primals_215, primals_216, getitem_657, getitem_658, True, 0.001, [True, True, True]);  clone_default_2 = convolution_default_356 = primals_217 = primals_215 = primals_216 = getitem_657 = getitem_658 = None
        getitem_759 = native_batch_norm_backward_default_8[0]
        getitem_760 = native_batch_norm_backward_default_8[1]
        getitem_761 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(getitem_759, convolution_default_355, primals_221, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_759 = convolution_default_355 = primals_221 = None
        getitem_762 = convolution_backward_default_16[0]
        getitem_763 = convolution_backward_default_16[1]
        getitem_764 = convolution_backward_default_16[2];  convolution_backward_default_16 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(getitem_762, relu_default_190, primals_220, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_762 = primals_220 = None
        getitem_765 = convolution_backward_default_17[0]
        getitem_766 = convolution_backward_default_17[1]
        getitem_767 = convolution_backward_default_17[2];  convolution_backward_default_17 = None
        to_dtype_27 = torch.ops.aten.to.dtype(getitem_765, torch.float32);  getitem_765 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu_default_190, torch.float32);  relu_default_190 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_210 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_210, to_dtype_27);  le_scalar_9 = new_zeros_default_210 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_29, convolution_default_354, primals_212, primals_210, primals_211, getitem_654, getitem_655, True, 0.001, [True, True, True]);  to_dtype_29 = convolution_default_354 = primals_212 = primals_210 = primals_211 = getitem_654 = getitem_655 = None
        getitem_768 = native_batch_norm_backward_default_9[0]
        getitem_769 = native_batch_norm_backward_default_9[1]
        getitem_770 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(getitem_768, convolution_default_353, primals_219, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_768 = convolution_default_353 = primals_219 = None
        getitem_771 = convolution_backward_default_18[0]
        getitem_772 = convolution_backward_default_18[1]
        getitem_773 = convolution_backward_default_18[2];  convolution_backward_default_18 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_771, relu_default_189, primals_218, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_771 = primals_218 = None
        getitem_774 = convolution_backward_default_19[0]
        getitem_775 = convolution_backward_default_19[1]
        getitem_776 = convolution_backward_default_19[2];  convolution_backward_default_19 = None
        to_dtype_30 = torch.ops.aten.to.dtype(getitem_774, torch.float32);  getitem_774 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu_default_189, torch.float32);  relu_default_189 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_211 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_211, to_dtype_30);  le_scalar_10 = new_zeros_default_211 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        add_tensor_76 = torch.ops.aten.add.Tensor(add_tensor_75, to_dtype_32);  add_tensor_75 = to_dtype_32 = None
        max_pool2d_with_indices_backward_default_2 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor, getitem_639, [3, 3], [1, 1], [1, 1], [1, 1], False, getitem_652);  getitem_639 = getitem_652 = None
        add_tensor_77 = torch.ops.aten.add.Tensor(to_dtype_8, max_pool2d_with_indices_backward_default_2);  to_dtype_8 = max_pool2d_with_indices_backward_default_2 = None
        clone_default_3 = torch.ops.aten.clone.default(slice_tensor, memory_format = torch.contiguous_format);  slice_tensor = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(clone_default_3, convolution_default_352, primals_203, primals_201, primals_202, getitem_649, getitem_650, True, 0.001, [True, True, True]);  clone_default_3 = convolution_default_352 = primals_203 = primals_201 = primals_202 = getitem_649 = getitem_650 = None
        getitem_777 = native_batch_norm_backward_default_10[0]
        getitem_778 = native_batch_norm_backward_default_10[1]
        getitem_779 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(getitem_777, convolution_default_351, primals_207, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_777 = convolution_default_351 = primals_207 = None
        getitem_780 = convolution_backward_default_20[0]
        getitem_781 = convolution_backward_default_20[1]
        getitem_782 = convolution_backward_default_20[2];  convolution_backward_default_20 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(getitem_780, relu_default_188, primals_206, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_780 = primals_206 = None
        getitem_783 = convolution_backward_default_21[0]
        getitem_784 = convolution_backward_default_21[1]
        getitem_785 = convolution_backward_default_21[2];  convolution_backward_default_21 = None
        to_dtype_33 = torch.ops.aten.to.dtype(getitem_783, torch.float32);  getitem_783 = None
        to_dtype_34 = torch.ops.aten.to.dtype(relu_default_188, torch.float32);  relu_default_188 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        new_zeros_default_212 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_212, to_dtype_33);  le_scalar_11 = new_zeros_default_212 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_35, convolution_default_350, primals_198, primals_196, primals_197, getitem_646, getitem_647, True, 0.001, [True, True, True]);  to_dtype_35 = convolution_default_350 = primals_198 = primals_196 = primals_197 = getitem_646 = getitem_647 = None
        getitem_786 = native_batch_norm_backward_default_11[0]
        getitem_787 = native_batch_norm_backward_default_11[1]
        getitem_788 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(getitem_786, convolution_default_349, primals_205, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_786 = convolution_default_349 = primals_205 = None
        getitem_789 = convolution_backward_default_22[0]
        getitem_790 = convolution_backward_default_22[1]
        getitem_791 = convolution_backward_default_22[2];  convolution_backward_default_22 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(getitem_789, relu_default_187, primals_204, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_789 = primals_204 = None
        getitem_792 = convolution_backward_default_23[0]
        getitem_793 = convolution_backward_default_23[1]
        getitem_794 = convolution_backward_default_23[2];  convolution_backward_default_23 = None
        to_dtype_36 = torch.ops.aten.to.dtype(getitem_792, torch.float32);  getitem_792 = None
        to_dtype_37 = torch.ops.aten.to.dtype(relu_default_187, torch.float32);  relu_default_187 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        new_zeros_default_213 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_213, to_dtype_36);  le_scalar_12 = new_zeros_default_213 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        add_tensor_78 = torch.ops.aten.add.Tensor(add_tensor_77, to_dtype_38);  add_tensor_77 = to_dtype_38 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_76, convolution_default_348, primals_282, primals_280, primals_281, getitem_643, getitem_644, True, 0.001, [True, True, True]);  add_tensor_76 = convolution_default_348 = primals_282 = primals_280 = primals_281 = getitem_643 = getitem_644 = None
        getitem_795 = native_batch_norm_backward_default_12[0]
        getitem_796 = native_batch_norm_backward_default_12[1]
        getitem_797 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_795, relu_default_186, primals_283, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_795 = primals_283 = None
        getitem_798 = convolution_backward_default_24[0]
        getitem_799 = convolution_backward_default_24[1]
        getitem_800 = convolution_backward_default_24[2];  convolution_backward_default_24 = None
        to_dtype_39 = torch.ops.aten.to.dtype(getitem_798, torch.float32);  getitem_798 = None
        to_dtype_40 = torch.ops.aten.to.dtype(relu_default_186, torch.float32);  relu_default_186 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        new_zeros_default_214 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_214, to_dtype_39);  le_scalar_13 = new_zeros_default_214 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_78, convolution_default_347, primals_288, primals_286, primals_287, getitem_640, getitem_641, True, 0.001, [True, True, True]);  add_tensor_78 = convolution_default_347 = primals_288 = primals_286 = primals_287 = getitem_640 = getitem_641 = None
        getitem_801 = native_batch_norm_backward_default_13[0]
        getitem_802 = native_batch_norm_backward_default_13[1]
        getitem_803 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_801, relu_default_185, primals_289, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_801 = primals_289 = None
        getitem_804 = convolution_backward_default_25[0]
        getitem_805 = convolution_backward_default_25[1]
        getitem_806 = convolution_backward_default_25[2];  convolution_backward_default_25 = None
        to_dtype_42 = torch.ops.aten.to.dtype(getitem_804, torch.float32);  getitem_804 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu_default_185, torch.float32);  relu_default_185 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_215 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_215, to_dtype_42);  le_scalar_14 = new_zeros_default_215 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        slice_tensor_5 = torch.ops.aten.slice.Tensor(to_dtype_41, 1, 0, 864)
        slice_tensor_6 = torch.ops.aten.slice.Tensor(to_dtype_41, 1, 864, 1728)
        slice_tensor_7 = torch.ops.aten.slice.Tensor(to_dtype_41, 1, 1728, 2592)
        slice_tensor_8 = torch.ops.aten.slice.Tensor(to_dtype_41, 1, 2592, 3456)
        slice_tensor_9 = torch.ops.aten.slice.Tensor(to_dtype_41, 1, 3456, 4320);  to_dtype_41 = None
        clone_default_4 = torch.ops.aten.clone.default(slice_tensor_9, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(clone_default_4, convolution_default_346, primals_177, primals_175, primals_176, getitem_637, getitem_638, True, 0.001, [True, True, True]);  clone_default_4 = convolution_default_346 = primals_177 = primals_175 = primals_176 = getitem_637 = getitem_638 = None
        getitem_807 = native_batch_norm_backward_default_14[0]
        getitem_808 = native_batch_norm_backward_default_14[1]
        getitem_809 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(getitem_807, convolution_default_345, primals_181, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_807 = convolution_default_345 = primals_181 = None
        getitem_810 = convolution_backward_default_26[0]
        getitem_811 = convolution_backward_default_26[1]
        getitem_812 = convolution_backward_default_26[2];  convolution_backward_default_26 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(getitem_810, relu_default_184, primals_180, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_810 = primals_180 = None
        getitem_813 = convolution_backward_default_27[0]
        getitem_814 = convolution_backward_default_27[1]
        getitem_815 = convolution_backward_default_27[2];  convolution_backward_default_27 = None
        to_dtype_45 = torch.ops.aten.to.dtype(getitem_813, torch.float32);  getitem_813 = None
        to_dtype_46 = torch.ops.aten.to.dtype(relu_default_184, torch.float32);  relu_default_184 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_46, 0);  to_dtype_46 = None
        new_zeros_default_216 = torch.ops.aten.new_zeros.default(to_dtype_45, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_216, to_dtype_45);  le_scalar_15 = new_zeros_default_216 = to_dtype_45 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_47, convolution_default_344, primals_172, primals_170, primals_171, getitem_634, getitem_635, True, 0.001, [True, True, True]);  to_dtype_47 = convolution_default_344 = primals_172 = primals_170 = primals_171 = getitem_634 = getitem_635 = None
        getitem_816 = native_batch_norm_backward_default_15[0]
        getitem_817 = native_batch_norm_backward_default_15[1]
        getitem_818 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(getitem_816, convolution_default_343, primals_179, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_816 = convolution_default_343 = primals_179 = None
        getitem_819 = convolution_backward_default_28[0]
        getitem_820 = convolution_backward_default_28[1]
        getitem_821 = convolution_backward_default_28[2];  convolution_backward_default_28 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(getitem_819, relu_default_183, primals_178, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_819 = primals_178 = None
        getitem_822 = convolution_backward_default_29[0]
        getitem_823 = convolution_backward_default_29[1]
        getitem_824 = convolution_backward_default_29[2];  convolution_backward_default_29 = None
        to_dtype_48 = torch.ops.aten.to.dtype(getitem_822, torch.float32);  getitem_822 = None
        to_dtype_49 = torch.ops.aten.to.dtype(relu_default_183, torch.float32);  relu_default_183 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_49, 0);  to_dtype_49 = None
        new_zeros_default_217 = torch.ops.aten.new_zeros.default(to_dtype_48, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_217, to_dtype_48);  le_scalar_16 = new_zeros_default_217 = to_dtype_48 = None
        to_dtype_50 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        max_pool2d_with_indices_backward_default_3 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_8, getitem_594, [3, 3], [1, 1], [1, 1], [1, 1], False, getitem_632);  getitem_632 = None
        add_tensor_79 = torch.ops.aten.add.Tensor(slice_tensor_9, max_pool2d_with_indices_backward_default_3);  slice_tensor_9 = max_pool2d_with_indices_backward_default_3 = None
        clone_default_5 = torch.ops.aten.clone.default(slice_tensor_8, memory_format = torch.contiguous_format);  slice_tensor_8 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(clone_default_5, convolution_default_342, primals_163, primals_161, primals_162, getitem_629, getitem_630, True, 0.001, [True, True, True]);  clone_default_5 = convolution_default_342 = primals_163 = primals_161 = primals_162 = getitem_629 = getitem_630 = None
        getitem_825 = native_batch_norm_backward_default_16[0]
        getitem_826 = native_batch_norm_backward_default_16[1]
        getitem_827 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_825, convolution_default_341, primals_167, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_825 = convolution_default_341 = primals_167 = None
        getitem_828 = convolution_backward_default_30[0]
        getitem_829 = convolution_backward_default_30[1]
        getitem_830 = convolution_backward_default_30[2];  convolution_backward_default_30 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(getitem_828, relu_default_182, primals_166, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_828 = primals_166 = None
        getitem_831 = convolution_backward_default_31[0]
        getitem_832 = convolution_backward_default_31[1]
        getitem_833 = convolution_backward_default_31[2];  convolution_backward_default_31 = None
        to_dtype_51 = torch.ops.aten.to.dtype(getitem_831, torch.float32);  getitem_831 = None
        to_dtype_52 = torch.ops.aten.to.dtype(relu_default_182, torch.float32);  relu_default_182 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_52, 0);  to_dtype_52 = None
        new_zeros_default_218 = torch.ops.aten.new_zeros.default(to_dtype_51, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_17, new_zeros_default_218, to_dtype_51);  le_scalar_17 = new_zeros_default_218 = to_dtype_51 = None
        to_dtype_53 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_53, convolution_default_340, primals_158, primals_156, primals_157, getitem_626, getitem_627, True, 0.001, [True, True, True]);  to_dtype_53 = convolution_default_340 = primals_158 = primals_156 = primals_157 = getitem_626 = getitem_627 = None
        getitem_834 = native_batch_norm_backward_default_17[0]
        getitem_835 = native_batch_norm_backward_default_17[1]
        getitem_836 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(getitem_834, convolution_default_339, primals_165, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_834 = convolution_default_339 = primals_165 = None
        getitem_837 = convolution_backward_default_32[0]
        getitem_838 = convolution_backward_default_32[1]
        getitem_839 = convolution_backward_default_32[2];  convolution_backward_default_32 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(getitem_837, relu_default_181, primals_164, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_837 = primals_164 = None
        getitem_840 = convolution_backward_default_33[0]
        getitem_841 = convolution_backward_default_33[1]
        getitem_842 = convolution_backward_default_33[2];  convolution_backward_default_33 = None
        to_dtype_54 = torch.ops.aten.to.dtype(getitem_840, torch.float32);  getitem_840 = None
        to_dtype_55 = torch.ops.aten.to.dtype(relu_default_181, torch.float32);  relu_default_181 = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_55, 0);  to_dtype_55 = None
        new_zeros_default_219 = torch.ops.aten.new_zeros.default(to_dtype_54, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_18 = torch.ops.aten.where.self(le_scalar_18, new_zeros_default_219, to_dtype_54);  le_scalar_18 = new_zeros_default_219 = to_dtype_54 = None
        to_dtype_56 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        add_tensor_80 = torch.ops.aten.add.Tensor(slice_tensor_7, to_dtype_56);  slice_tensor_7 = to_dtype_56 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_80, convolution_default_338, primals_149, primals_147, primals_148, getitem_623, getitem_624, True, 0.001, [True, True, True]);  convolution_default_338 = primals_149 = primals_147 = primals_148 = getitem_623 = getitem_624 = None
        getitem_843 = native_batch_norm_backward_default_18[0]
        getitem_844 = native_batch_norm_backward_default_18[1]
        getitem_845 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(getitem_843, convolution_default_337, primals_153, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_843 = convolution_default_337 = primals_153 = None
        getitem_846 = convolution_backward_default_34[0]
        getitem_847 = convolution_backward_default_34[1]
        getitem_848 = convolution_backward_default_34[2];  convolution_backward_default_34 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_846, relu_default_180, primals_152, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_846 = primals_152 = None
        getitem_849 = convolution_backward_default_35[0]
        getitem_850 = convolution_backward_default_35[1]
        getitem_851 = convolution_backward_default_35[2];  convolution_backward_default_35 = None
        to_dtype_57 = torch.ops.aten.to.dtype(getitem_849, torch.float32);  getitem_849 = None
        to_dtype_58 = torch.ops.aten.to.dtype(relu_default_180, torch.float32);  relu_default_180 = None
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_58, 0);  to_dtype_58 = None
        new_zeros_default_220 = torch.ops.aten.new_zeros.default(to_dtype_57, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_19 = torch.ops.aten.where.self(le_scalar_19, new_zeros_default_220, to_dtype_57);  le_scalar_19 = new_zeros_default_220 = to_dtype_57 = None
        to_dtype_59 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_59, convolution_default_336, primals_144, primals_142, primals_143, getitem_620, getitem_621, True, 0.001, [True, True, True]);  to_dtype_59 = convolution_default_336 = primals_144 = primals_142 = primals_143 = getitem_620 = getitem_621 = None
        getitem_852 = native_batch_norm_backward_default_19[0]
        getitem_853 = native_batch_norm_backward_default_19[1]
        getitem_854 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(getitem_852, convolution_default_335, primals_151, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_852 = convolution_default_335 = primals_151 = None
        getitem_855 = convolution_backward_default_36[0]
        getitem_856 = convolution_backward_default_36[1]
        getitem_857 = convolution_backward_default_36[2];  convolution_backward_default_36 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(getitem_855, relu_default_179, primals_150, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_855 = primals_150 = None
        getitem_858 = convolution_backward_default_37[0]
        getitem_859 = convolution_backward_default_37[1]
        getitem_860 = convolution_backward_default_37[2];  convolution_backward_default_37 = None
        to_dtype_60 = torch.ops.aten.to.dtype(getitem_858, torch.float32);  getitem_858 = None
        to_dtype_61 = torch.ops.aten.to.dtype(relu_default_179, torch.float32);  relu_default_179 = None
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_61, 0);  to_dtype_61 = None
        new_zeros_default_221 = torch.ops.aten.new_zeros.default(to_dtype_60, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_20 = torch.ops.aten.where.self(le_scalar_20, new_zeros_default_221, to_dtype_60);  le_scalar_20 = new_zeros_default_221 = to_dtype_60 = None
        to_dtype_62 = torch.ops.aten.to.dtype(where_self_20, torch.float32);  where_self_20 = None
        add_tensor_81 = torch.ops.aten.add.Tensor(add_tensor_79, to_dtype_62);  add_tensor_79 = to_dtype_62 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_80, convolution_default_334, primals_135, primals_133, primals_134, getitem_617, getitem_618, True, 0.001, [True, True, True]);  add_tensor_80 = convolution_default_334 = primals_135 = primals_133 = primals_134 = getitem_617 = getitem_618 = None
        getitem_861 = native_batch_norm_backward_default_20[0]
        getitem_862 = native_batch_norm_backward_default_20[1]
        getitem_863 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(getitem_861, convolution_default_333, primals_139, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_861 = convolution_default_333 = primals_139 = None
        getitem_864 = convolution_backward_default_38[0]
        getitem_865 = convolution_backward_default_38[1]
        getitem_866 = convolution_backward_default_38[2];  convolution_backward_default_38 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(getitem_864, relu_default_178, primals_138, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_864 = primals_138 = None
        getitem_867 = convolution_backward_default_39[0]
        getitem_868 = convolution_backward_default_39[1]
        getitem_869 = convolution_backward_default_39[2];  convolution_backward_default_39 = None
        to_dtype_63 = torch.ops.aten.to.dtype(getitem_867, torch.float32);  getitem_867 = None
        to_dtype_64 = torch.ops.aten.to.dtype(relu_default_178, torch.float32);  relu_default_178 = None
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_64, 0);  to_dtype_64 = None
        new_zeros_default_222 = torch.ops.aten.new_zeros.default(to_dtype_63, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_21 = torch.ops.aten.where.self(le_scalar_21, new_zeros_default_222, to_dtype_63);  le_scalar_21 = new_zeros_default_222 = to_dtype_63 = None
        to_dtype_65 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_65, convolution_default_332, primals_130, primals_128, primals_129, getitem_614, getitem_615, True, 0.001, [True, True, True]);  to_dtype_65 = convolution_default_332 = primals_130 = primals_128 = primals_129 = getitem_614 = getitem_615 = None
        getitem_870 = native_batch_norm_backward_default_21[0]
        getitem_871 = native_batch_norm_backward_default_21[1]
        getitem_872 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(getitem_870, convolution_default_331, primals_137, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_870 = convolution_default_331 = primals_137 = None
        getitem_873 = convolution_backward_default_40[0]
        getitem_874 = convolution_backward_default_40[1]
        getitem_875 = convolution_backward_default_40[2];  convolution_backward_default_40 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(getitem_873, relu_default_177, primals_136, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_873 = primals_136 = None
        getitem_876 = convolution_backward_default_41[0]
        getitem_877 = convolution_backward_default_41[1]
        getitem_878 = convolution_backward_default_41[2];  convolution_backward_default_41 = None
        to_dtype_66 = torch.ops.aten.to.dtype(getitem_876, torch.float32);  getitem_876 = None
        to_dtype_67 = torch.ops.aten.to.dtype(relu_default_177, torch.float32);  relu_default_177 = None
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_67, 0);  to_dtype_67 = None
        new_zeros_default_223 = torch.ops.aten.new_zeros.default(to_dtype_66, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_22 = torch.ops.aten.where.self(le_scalar_22, new_zeros_default_223, to_dtype_66);  le_scalar_22 = new_zeros_default_223 = to_dtype_66 = None
        to_dtype_68 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        add_tensor_82 = torch.ops.aten.add.Tensor(add_tensor_81, to_dtype_68);  add_tensor_81 = to_dtype_68 = None
        max_pool2d_with_indices_backward_default_4 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_6, getitem_594, [3, 3], [1, 1], [1, 1], [1, 1], False, getitem_612);  getitem_594 = getitem_612 = None
        add_tensor_83 = torch.ops.aten.add.Tensor(add_tensor_82, max_pool2d_with_indices_backward_default_4);  add_tensor_82 = max_pool2d_with_indices_backward_default_4 = None
        clone_default_6 = torch.ops.aten.clone.default(slice_tensor_6, memory_format = torch.contiguous_format);  slice_tensor_6 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(clone_default_6, convolution_default_330, primals_121, primals_119, primals_120, getitem_609, getitem_610, True, 0.001, [True, True, True]);  clone_default_6 = convolution_default_330 = primals_121 = primals_119 = primals_120 = getitem_609 = getitem_610 = None
        getitem_879 = native_batch_norm_backward_default_22[0]
        getitem_880 = native_batch_norm_backward_default_22[1]
        getitem_881 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(getitem_879, convolution_default_329, primals_125, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_879 = convolution_default_329 = primals_125 = None
        getitem_882 = convolution_backward_default_42[0]
        getitem_883 = convolution_backward_default_42[1]
        getitem_884 = convolution_backward_default_42[2];  convolution_backward_default_42 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(getitem_882, relu_default_176, primals_124, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_882 = primals_124 = None
        getitem_885 = convolution_backward_default_43[0]
        getitem_886 = convolution_backward_default_43[1]
        getitem_887 = convolution_backward_default_43[2];  convolution_backward_default_43 = None
        to_dtype_69 = torch.ops.aten.to.dtype(getitem_885, torch.float32);  getitem_885 = None
        to_dtype_70 = torch.ops.aten.to.dtype(relu_default_176, torch.float32);  relu_default_176 = None
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_70, 0);  to_dtype_70 = None
        new_zeros_default_224 = torch.ops.aten.new_zeros.default(to_dtype_69, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(le_scalar_23, new_zeros_default_224, to_dtype_69);  le_scalar_23 = new_zeros_default_224 = to_dtype_69 = None
        to_dtype_71 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_71, convolution_default_328, primals_116, primals_114, primals_115, getitem_606, getitem_607, True, 0.001, [True, True, True]);  to_dtype_71 = convolution_default_328 = primals_116 = primals_114 = primals_115 = getitem_606 = getitem_607 = None
        getitem_888 = native_batch_norm_backward_default_23[0]
        getitem_889 = native_batch_norm_backward_default_23[1]
        getitem_890 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(getitem_888, convolution_default_327, primals_123, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_888 = convolution_default_327 = primals_123 = None
        getitem_891 = convolution_backward_default_44[0]
        getitem_892 = convolution_backward_default_44[1]
        getitem_893 = convolution_backward_default_44[2];  convolution_backward_default_44 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(getitem_891, relu_default_175, primals_122, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_891 = primals_122 = None
        getitem_894 = convolution_backward_default_45[0]
        getitem_895 = convolution_backward_default_45[1]
        getitem_896 = convolution_backward_default_45[2];  convolution_backward_default_45 = None
        to_dtype_72 = torch.ops.aten.to.dtype(getitem_894, torch.float32);  getitem_894 = None
        to_dtype_73 = torch.ops.aten.to.dtype(relu_default_175, torch.float32);  relu_default_175 = None
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_73, 0);  to_dtype_73 = None
        new_zeros_default_225 = torch.ops.aten.new_zeros.default(to_dtype_72, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_24 = torch.ops.aten.where.self(le_scalar_24, new_zeros_default_225, to_dtype_72);  le_scalar_24 = new_zeros_default_225 = to_dtype_72 = None
        to_dtype_74 = torch.ops.aten.to.dtype(where_self_24, torch.float32);  where_self_24 = None
        add_tensor_84 = torch.ops.aten.add.Tensor(add_tensor_83, to_dtype_74);  add_tensor_83 = to_dtype_74 = None
        max_pool2d_with_indices_backward_default_5 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_5, getitem_591, [3, 3], [1, 1], [1, 1], [1, 1], False, getitem_604);  getitem_591 = getitem_604 = None
        add_tensor_85 = torch.ops.aten.add.Tensor(to_dtype_50, max_pool2d_with_indices_backward_default_5);  to_dtype_50 = max_pool2d_with_indices_backward_default_5 = None
        clone_default_7 = torch.ops.aten.clone.default(slice_tensor_5, memory_format = torch.contiguous_format);  slice_tensor_5 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(clone_default_7, convolution_default_326, primals_107, primals_105, primals_106, getitem_601, getitem_602, True, 0.001, [True, True, True]);  clone_default_7 = convolution_default_326 = primals_107 = primals_105 = primals_106 = getitem_601 = getitem_602 = None
        getitem_897 = native_batch_norm_backward_default_24[0]
        getitem_898 = native_batch_norm_backward_default_24[1]
        getitem_899 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(getitem_897, convolution_default_325, primals_111, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_897 = convolution_default_325 = primals_111 = None
        getitem_900 = convolution_backward_default_46[0]
        getitem_901 = convolution_backward_default_46[1]
        getitem_902 = convolution_backward_default_46[2];  convolution_backward_default_46 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(getitem_900, relu_default_174, primals_110, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_900 = primals_110 = None
        getitem_903 = convolution_backward_default_47[0]
        getitem_904 = convolution_backward_default_47[1]
        getitem_905 = convolution_backward_default_47[2];  convolution_backward_default_47 = None
        to_dtype_75 = torch.ops.aten.to.dtype(getitem_903, torch.float32);  getitem_903 = None
        to_dtype_76 = torch.ops.aten.to.dtype(relu_default_174, torch.float32);  relu_default_174 = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_76, 0);  to_dtype_76 = None
        new_zeros_default_226 = torch.ops.aten.new_zeros.default(to_dtype_75, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_25 = torch.ops.aten.where.self(le_scalar_25, new_zeros_default_226, to_dtype_75);  le_scalar_25 = new_zeros_default_226 = to_dtype_75 = None
        to_dtype_77 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_77, convolution_default_324, primals_102, primals_100, primals_101, getitem_598, getitem_599, True, 0.001, [True, True, True]);  to_dtype_77 = convolution_default_324 = primals_102 = primals_100 = primals_101 = getitem_598 = getitem_599 = None
        getitem_906 = native_batch_norm_backward_default_25[0]
        getitem_907 = native_batch_norm_backward_default_25[1]
        getitem_908 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        convolution_backward_default_48 = torch.ops.aten.convolution_backward.default(getitem_906, convolution_default_323, primals_109, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_906 = convolution_default_323 = primals_109 = None
        getitem_909 = convolution_backward_default_48[0]
        getitem_910 = convolution_backward_default_48[1]
        getitem_911 = convolution_backward_default_48[2];  convolution_backward_default_48 = None
        convolution_backward_default_49 = torch.ops.aten.convolution_backward.default(getitem_909, relu_default_173, primals_108, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_909 = primals_108 = None
        getitem_912 = convolution_backward_default_49[0]
        getitem_913 = convolution_backward_default_49[1]
        getitem_914 = convolution_backward_default_49[2];  convolution_backward_default_49 = None
        to_dtype_78 = torch.ops.aten.to.dtype(getitem_912, torch.float32);  getitem_912 = None
        to_dtype_79 = torch.ops.aten.to.dtype(relu_default_173, torch.float32);  relu_default_173 = None
        le_scalar_26 = torch.ops.aten.le.Scalar(to_dtype_79, 0);  to_dtype_79 = None
        new_zeros_default_227 = torch.ops.aten.new_zeros.default(to_dtype_78, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_26 = torch.ops.aten.where.self(le_scalar_26, new_zeros_default_227, to_dtype_78);  le_scalar_26 = new_zeros_default_227 = to_dtype_78 = None
        to_dtype_80 = torch.ops.aten.to.dtype(where_self_26, torch.float32);  where_self_26 = None
        add_tensor_86 = torch.ops.aten.add.Tensor(add_tensor_85, to_dtype_80);  add_tensor_85 = to_dtype_80 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_84, convolution_default_322, primals_186, primals_184, primals_185, getitem_595, getitem_596, True, 0.001, [True, True, True]);  add_tensor_84 = convolution_default_322 = primals_186 = primals_184 = primals_185 = getitem_595 = getitem_596 = None
        getitem_915 = native_batch_norm_backward_default_26[0]
        getitem_916 = native_batch_norm_backward_default_26[1]
        getitem_917 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_50 = torch.ops.aten.convolution_backward.default(getitem_915, relu_default_172, primals_187, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_915 = primals_187 = None
        getitem_918 = convolution_backward_default_50[0]
        getitem_919 = convolution_backward_default_50[1]
        getitem_920 = convolution_backward_default_50[2];  convolution_backward_default_50 = None
        to_dtype_81 = torch.ops.aten.to.dtype(getitem_918, torch.float32);  getitem_918 = None
        to_dtype_82 = torch.ops.aten.to.dtype(relu_default_172, torch.float32);  relu_default_172 = None
        le_scalar_27 = torch.ops.aten.le.Scalar(to_dtype_82, 0);  to_dtype_82 = None
        new_zeros_default_228 = torch.ops.aten.new_zeros.default(to_dtype_81, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_27 = torch.ops.aten.where.self(le_scalar_27, new_zeros_default_228, to_dtype_81);  le_scalar_27 = new_zeros_default_228 = to_dtype_81 = None
        to_dtype_83 = torch.ops.aten.to.dtype(where_self_27, torch.float32);  where_self_27 = None
        add_tensor_87 = torch.ops.aten.add.Tensor(to_dtype_44, to_dtype_83);  to_dtype_44 = to_dtype_83 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_86, convolution_default_321, primals_192, primals_190, primals_191, getitem_592, getitem_593, True, 0.001, [True, True, True]);  add_tensor_86 = convolution_default_321 = primals_192 = primals_190 = primals_191 = getitem_592 = getitem_593 = None
        getitem_921 = native_batch_norm_backward_default_27[0]
        getitem_922 = native_batch_norm_backward_default_27[1]
        getitem_923 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        convolution_backward_default_51 = torch.ops.aten.convolution_backward.default(getitem_921, relu_default_171, primals_193, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_921 = primals_193 = None
        getitem_924 = convolution_backward_default_51[0]
        getitem_925 = convolution_backward_default_51[1]
        getitem_926 = convolution_backward_default_51[2];  convolution_backward_default_51 = None
        to_dtype_84 = torch.ops.aten.to.dtype(getitem_924, torch.float32);  getitem_924 = None
        to_dtype_85 = torch.ops.aten.to.dtype(relu_default_171, torch.float32);  relu_default_171 = None
        le_scalar_28 = torch.ops.aten.le.Scalar(to_dtype_85, 0);  to_dtype_85 = None
        new_zeros_default_229 = torch.ops.aten.new_zeros.default(to_dtype_84, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_28 = torch.ops.aten.where.self(le_scalar_28, new_zeros_default_229, to_dtype_84);  le_scalar_28 = new_zeros_default_229 = to_dtype_84 = None
        to_dtype_86 = torch.ops.aten.to.dtype(where_self_28, torch.float32);  where_self_28 = None
        slice_tensor_10 = torch.ops.aten.slice.Tensor(add_tensor_87, 1, 0, 864)
        slice_tensor_11 = torch.ops.aten.slice.Tensor(add_tensor_87, 1, 864, 1728)
        slice_tensor_12 = torch.ops.aten.slice.Tensor(add_tensor_87, 1, 1728, 2592)
        slice_tensor_13 = torch.ops.aten.slice.Tensor(add_tensor_87, 1, 2592, 3456)
        slice_tensor_14 = torch.ops.aten.slice.Tensor(add_tensor_87, 1, 3456, 4320);  add_tensor_87 = None
        clone_default_8 = torch.ops.aten.clone.default(slice_tensor_14, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(clone_default_8, convolution_default_320, primals_1150, primals_1148, primals_1149, getitem_589, getitem_590, True, 0.001, [True, True, True]);  clone_default_8 = convolution_default_320 = primals_1150 = primals_1148 = primals_1149 = getitem_589 = getitem_590 = None
        getitem_927 = native_batch_norm_backward_default_28[0]
        getitem_928 = native_batch_norm_backward_default_28[1]
        getitem_929 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        convolution_backward_default_52 = torch.ops.aten.convolution_backward.default(getitem_927, convolution_default_319, primals_1154, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_927 = convolution_default_319 = primals_1154 = None
        getitem_930 = convolution_backward_default_52[0]
        getitem_931 = convolution_backward_default_52[1]
        getitem_932 = convolution_backward_default_52[2];  convolution_backward_default_52 = None
        convolution_backward_default_53 = torch.ops.aten.convolution_backward.default(getitem_930, relu_default_170, primals_1153, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_930 = primals_1153 = None
        getitem_933 = convolution_backward_default_53[0]
        getitem_934 = convolution_backward_default_53[1]
        getitem_935 = convolution_backward_default_53[2];  convolution_backward_default_53 = None
        to_dtype_87 = torch.ops.aten.to.dtype(getitem_933, torch.float32);  getitem_933 = None
        to_dtype_88 = torch.ops.aten.to.dtype(relu_default_170, torch.float32);  relu_default_170 = None
        le_scalar_29 = torch.ops.aten.le.Scalar(to_dtype_88, 0);  to_dtype_88 = None
        new_zeros_default_230 = torch.ops.aten.new_zeros.default(to_dtype_87, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_29 = torch.ops.aten.where.self(le_scalar_29, new_zeros_default_230, to_dtype_87);  le_scalar_29 = new_zeros_default_230 = to_dtype_87 = None
        to_dtype_89 = torch.ops.aten.to.dtype(where_self_29, torch.float32);  where_self_29 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_89, convolution_default_318, primals_1145, primals_1143, primals_1144, getitem_586, getitem_587, True, 0.001, [True, True, True]);  to_dtype_89 = convolution_default_318 = primals_1145 = primals_1143 = primals_1144 = getitem_586 = getitem_587 = None
        getitem_936 = native_batch_norm_backward_default_29[0]
        getitem_937 = native_batch_norm_backward_default_29[1]
        getitem_938 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        convolution_backward_default_54 = torch.ops.aten.convolution_backward.default(getitem_936, convolution_default_317, primals_1152, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_936 = convolution_default_317 = primals_1152 = None
        getitem_939 = convolution_backward_default_54[0]
        getitem_940 = convolution_backward_default_54[1]
        getitem_941 = convolution_backward_default_54[2];  convolution_backward_default_54 = None
        convolution_backward_default_55 = torch.ops.aten.convolution_backward.default(getitem_939, relu_default_169, primals_1151, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_939 = primals_1151 = None
        getitem_942 = convolution_backward_default_55[0]
        getitem_943 = convolution_backward_default_55[1]
        getitem_944 = convolution_backward_default_55[2];  convolution_backward_default_55 = None
        to_dtype_90 = torch.ops.aten.to.dtype(getitem_942, torch.float32);  getitem_942 = None
        to_dtype_91 = torch.ops.aten.to.dtype(relu_default_169, torch.float32);  relu_default_169 = None
        le_scalar_30 = torch.ops.aten.le.Scalar(to_dtype_91, 0);  to_dtype_91 = None
        new_zeros_default_231 = torch.ops.aten.new_zeros.default(to_dtype_90, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_30 = torch.ops.aten.where.self(le_scalar_30, new_zeros_default_231, to_dtype_90);  le_scalar_30 = new_zeros_default_231 = to_dtype_90 = None
        to_dtype_92 = torch.ops.aten.to.dtype(where_self_30, torch.float32);  where_self_30 = None
        max_pool2d_with_indices_backward_default_6 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_13, getitem_546, [3, 3], [1, 1], [1, 1], [1, 1], False, getitem_584);  getitem_584 = None
        add_tensor_88 = torch.ops.aten.add.Tensor(slice_tensor_14, max_pool2d_with_indices_backward_default_6);  slice_tensor_14 = max_pool2d_with_indices_backward_default_6 = None
        clone_default_9 = torch.ops.aten.clone.default(slice_tensor_13, memory_format = torch.contiguous_format);  slice_tensor_13 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(clone_default_9, convolution_default_316, primals_1136, primals_1134, primals_1135, getitem_581, getitem_582, True, 0.001, [True, True, True]);  clone_default_9 = convolution_default_316 = primals_1136 = primals_1134 = primals_1135 = getitem_581 = getitem_582 = None
        getitem_945 = native_batch_norm_backward_default_30[0]
        getitem_946 = native_batch_norm_backward_default_30[1]
        getitem_947 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_56 = torch.ops.aten.convolution_backward.default(getitem_945, convolution_default_315, primals_1140, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_945 = convolution_default_315 = primals_1140 = None
        getitem_948 = convolution_backward_default_56[0]
        getitem_949 = convolution_backward_default_56[1]
        getitem_950 = convolution_backward_default_56[2];  convolution_backward_default_56 = None
        convolution_backward_default_57 = torch.ops.aten.convolution_backward.default(getitem_948, relu_default_168, primals_1139, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_948 = primals_1139 = None
        getitem_951 = convolution_backward_default_57[0]
        getitem_952 = convolution_backward_default_57[1]
        getitem_953 = convolution_backward_default_57[2];  convolution_backward_default_57 = None
        to_dtype_93 = torch.ops.aten.to.dtype(getitem_951, torch.float32);  getitem_951 = None
        to_dtype_94 = torch.ops.aten.to.dtype(relu_default_168, torch.float32);  relu_default_168 = None
        le_scalar_31 = torch.ops.aten.le.Scalar(to_dtype_94, 0);  to_dtype_94 = None
        new_zeros_default_232 = torch.ops.aten.new_zeros.default(to_dtype_93, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_31 = torch.ops.aten.where.self(le_scalar_31, new_zeros_default_232, to_dtype_93);  le_scalar_31 = new_zeros_default_232 = to_dtype_93 = None
        to_dtype_95 = torch.ops.aten.to.dtype(where_self_31, torch.float32);  where_self_31 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_95, convolution_default_314, primals_1131, primals_1129, primals_1130, getitem_578, getitem_579, True, 0.001, [True, True, True]);  to_dtype_95 = convolution_default_314 = primals_1131 = primals_1129 = primals_1130 = getitem_578 = getitem_579 = None
        getitem_954 = native_batch_norm_backward_default_31[0]
        getitem_955 = native_batch_norm_backward_default_31[1]
        getitem_956 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        convolution_backward_default_58 = torch.ops.aten.convolution_backward.default(getitem_954, convolution_default_313, primals_1138, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_954 = convolution_default_313 = primals_1138 = None
        getitem_957 = convolution_backward_default_58[0]
        getitem_958 = convolution_backward_default_58[1]
        getitem_959 = convolution_backward_default_58[2];  convolution_backward_default_58 = None
        convolution_backward_default_59 = torch.ops.aten.convolution_backward.default(getitem_957, relu_default_167, primals_1137, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_957 = primals_1137 = None
        getitem_960 = convolution_backward_default_59[0]
        getitem_961 = convolution_backward_default_59[1]
        getitem_962 = convolution_backward_default_59[2];  convolution_backward_default_59 = None
        to_dtype_96 = torch.ops.aten.to.dtype(getitem_960, torch.float32);  getitem_960 = None
        to_dtype_97 = torch.ops.aten.to.dtype(relu_default_167, torch.float32);  relu_default_167 = None
        le_scalar_32 = torch.ops.aten.le.Scalar(to_dtype_97, 0);  to_dtype_97 = None
        new_zeros_default_233 = torch.ops.aten.new_zeros.default(to_dtype_96, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_32 = torch.ops.aten.where.self(le_scalar_32, new_zeros_default_233, to_dtype_96);  le_scalar_32 = new_zeros_default_233 = to_dtype_96 = None
        to_dtype_98 = torch.ops.aten.to.dtype(where_self_32, torch.float32);  where_self_32 = None
        add_tensor_89 = torch.ops.aten.add.Tensor(slice_tensor_12, to_dtype_98);  slice_tensor_12 = to_dtype_98 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_89, convolution_default_312, primals_1122, primals_1120, primals_1121, getitem_575, getitem_576, True, 0.001, [True, True, True]);  convolution_default_312 = primals_1122 = primals_1120 = primals_1121 = getitem_575 = getitem_576 = None
        getitem_963 = native_batch_norm_backward_default_32[0]
        getitem_964 = native_batch_norm_backward_default_32[1]
        getitem_965 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        convolution_backward_default_60 = torch.ops.aten.convolution_backward.default(getitem_963, convolution_default_311, primals_1126, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_963 = convolution_default_311 = primals_1126 = None
        getitem_966 = convolution_backward_default_60[0]
        getitem_967 = convolution_backward_default_60[1]
        getitem_968 = convolution_backward_default_60[2];  convolution_backward_default_60 = None
        convolution_backward_default_61 = torch.ops.aten.convolution_backward.default(getitem_966, relu_default_166, primals_1125, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_966 = primals_1125 = None
        getitem_969 = convolution_backward_default_61[0]
        getitem_970 = convolution_backward_default_61[1]
        getitem_971 = convolution_backward_default_61[2];  convolution_backward_default_61 = None
        to_dtype_99 = torch.ops.aten.to.dtype(getitem_969, torch.float32);  getitem_969 = None
        to_dtype_100 = torch.ops.aten.to.dtype(relu_default_166, torch.float32);  relu_default_166 = None
        le_scalar_33 = torch.ops.aten.le.Scalar(to_dtype_100, 0);  to_dtype_100 = None
        new_zeros_default_234 = torch.ops.aten.new_zeros.default(to_dtype_99, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_33 = torch.ops.aten.where.self(le_scalar_33, new_zeros_default_234, to_dtype_99);  le_scalar_33 = new_zeros_default_234 = to_dtype_99 = None
        to_dtype_101 = torch.ops.aten.to.dtype(where_self_33, torch.float32);  where_self_33 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_101, convolution_default_310, primals_1117, primals_1115, primals_1116, getitem_572, getitem_573, True, 0.001, [True, True, True]);  to_dtype_101 = convolution_default_310 = primals_1117 = primals_1115 = primals_1116 = getitem_572 = getitem_573 = None
        getitem_972 = native_batch_norm_backward_default_33[0]
        getitem_973 = native_batch_norm_backward_default_33[1]
        getitem_974 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        convolution_backward_default_62 = torch.ops.aten.convolution_backward.default(getitem_972, convolution_default_309, primals_1124, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_972 = convolution_default_309 = primals_1124 = None
        getitem_975 = convolution_backward_default_62[0]
        getitem_976 = convolution_backward_default_62[1]
        getitem_977 = convolution_backward_default_62[2];  convolution_backward_default_62 = None
        convolution_backward_default_63 = torch.ops.aten.convolution_backward.default(getitem_975, relu_default_165, primals_1123, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_975 = primals_1123 = None
        getitem_978 = convolution_backward_default_63[0]
        getitem_979 = convolution_backward_default_63[1]
        getitem_980 = convolution_backward_default_63[2];  convolution_backward_default_63 = None
        to_dtype_102 = torch.ops.aten.to.dtype(getitem_978, torch.float32);  getitem_978 = None
        to_dtype_103 = torch.ops.aten.to.dtype(relu_default_165, torch.float32);  relu_default_165 = None
        le_scalar_34 = torch.ops.aten.le.Scalar(to_dtype_103, 0);  to_dtype_103 = None
        new_zeros_default_235 = torch.ops.aten.new_zeros.default(to_dtype_102, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_34 = torch.ops.aten.where.self(le_scalar_34, new_zeros_default_235, to_dtype_102);  le_scalar_34 = new_zeros_default_235 = to_dtype_102 = None
        to_dtype_104 = torch.ops.aten.to.dtype(where_self_34, torch.float32);  where_self_34 = None
        add_tensor_90 = torch.ops.aten.add.Tensor(add_tensor_88, to_dtype_104);  add_tensor_88 = to_dtype_104 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_89, convolution_default_308, primals_1108, primals_1106, primals_1107, getitem_569, getitem_570, True, 0.001, [True, True, True]);  add_tensor_89 = convolution_default_308 = primals_1108 = primals_1106 = primals_1107 = getitem_569 = getitem_570 = None
        getitem_981 = native_batch_norm_backward_default_34[0]
        getitem_982 = native_batch_norm_backward_default_34[1]
        getitem_983 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        convolution_backward_default_64 = torch.ops.aten.convolution_backward.default(getitem_981, convolution_default_307, primals_1112, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_981 = convolution_default_307 = primals_1112 = None
        getitem_984 = convolution_backward_default_64[0]
        getitem_985 = convolution_backward_default_64[1]
        getitem_986 = convolution_backward_default_64[2];  convolution_backward_default_64 = None
        convolution_backward_default_65 = torch.ops.aten.convolution_backward.default(getitem_984, relu_default_164, primals_1111, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_984 = primals_1111 = None
        getitem_987 = convolution_backward_default_65[0]
        getitem_988 = convolution_backward_default_65[1]
        getitem_989 = convolution_backward_default_65[2];  convolution_backward_default_65 = None
        to_dtype_105 = torch.ops.aten.to.dtype(getitem_987, torch.float32);  getitem_987 = None
        to_dtype_106 = torch.ops.aten.to.dtype(relu_default_164, torch.float32);  relu_default_164 = None
        le_scalar_35 = torch.ops.aten.le.Scalar(to_dtype_106, 0);  to_dtype_106 = None
        new_zeros_default_236 = torch.ops.aten.new_zeros.default(to_dtype_105, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_35 = torch.ops.aten.where.self(le_scalar_35, new_zeros_default_236, to_dtype_105);  le_scalar_35 = new_zeros_default_236 = to_dtype_105 = None
        to_dtype_107 = torch.ops.aten.to.dtype(where_self_35, torch.float32);  where_self_35 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_107, convolution_default_306, primals_1103, primals_1101, primals_1102, getitem_566, getitem_567, True, 0.001, [True, True, True]);  to_dtype_107 = convolution_default_306 = primals_1103 = primals_1101 = primals_1102 = getitem_566 = getitem_567 = None
        getitem_990 = native_batch_norm_backward_default_35[0]
        getitem_991 = native_batch_norm_backward_default_35[1]
        getitem_992 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        convolution_backward_default_66 = torch.ops.aten.convolution_backward.default(getitem_990, convolution_default_305, primals_1110, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_990 = convolution_default_305 = primals_1110 = None
        getitem_993 = convolution_backward_default_66[0]
        getitem_994 = convolution_backward_default_66[1]
        getitem_995 = convolution_backward_default_66[2];  convolution_backward_default_66 = None
        convolution_backward_default_67 = torch.ops.aten.convolution_backward.default(getitem_993, relu_default_163, primals_1109, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_993 = primals_1109 = None
        getitem_996 = convolution_backward_default_67[0]
        getitem_997 = convolution_backward_default_67[1]
        getitem_998 = convolution_backward_default_67[2];  convolution_backward_default_67 = None
        to_dtype_108 = torch.ops.aten.to.dtype(getitem_996, torch.float32);  getitem_996 = None
        to_dtype_109 = torch.ops.aten.to.dtype(relu_default_163, torch.float32);  relu_default_163 = None
        le_scalar_36 = torch.ops.aten.le.Scalar(to_dtype_109, 0);  to_dtype_109 = None
        new_zeros_default_237 = torch.ops.aten.new_zeros.default(to_dtype_108, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_36 = torch.ops.aten.where.self(le_scalar_36, new_zeros_default_237, to_dtype_108);  le_scalar_36 = new_zeros_default_237 = to_dtype_108 = None
        to_dtype_110 = torch.ops.aten.to.dtype(where_self_36, torch.float32);  where_self_36 = None
        add_tensor_91 = torch.ops.aten.add.Tensor(add_tensor_90, to_dtype_110);  add_tensor_90 = to_dtype_110 = None
        max_pool2d_with_indices_backward_default_7 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_11, getitem_546, [3, 3], [1, 1], [1, 1], [1, 1], False, getitem_564);  getitem_546 = getitem_564 = None
        add_tensor_92 = torch.ops.aten.add.Tensor(add_tensor_91, max_pool2d_with_indices_backward_default_7);  add_tensor_91 = max_pool2d_with_indices_backward_default_7 = None
        clone_default_10 = torch.ops.aten.clone.default(slice_tensor_11, memory_format = torch.contiguous_format);  slice_tensor_11 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(clone_default_10, convolution_default_304, primals_1094, primals_1092, primals_1093, getitem_561, getitem_562, True, 0.001, [True, True, True]);  clone_default_10 = convolution_default_304 = primals_1094 = primals_1092 = primals_1093 = getitem_561 = getitem_562 = None
        getitem_999 = native_batch_norm_backward_default_36[0]
        getitem_1000 = native_batch_norm_backward_default_36[1]
        getitem_1001 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        convolution_backward_default_68 = torch.ops.aten.convolution_backward.default(getitem_999, convolution_default_303, primals_1098, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_999 = convolution_default_303 = primals_1098 = None
        getitem_1002 = convolution_backward_default_68[0]
        getitem_1003 = convolution_backward_default_68[1]
        getitem_1004 = convolution_backward_default_68[2];  convolution_backward_default_68 = None
        convolution_backward_default_69 = torch.ops.aten.convolution_backward.default(getitem_1002, relu_default_162, primals_1097, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_1002 = primals_1097 = None
        getitem_1005 = convolution_backward_default_69[0]
        getitem_1006 = convolution_backward_default_69[1]
        getitem_1007 = convolution_backward_default_69[2];  convolution_backward_default_69 = None
        to_dtype_111 = torch.ops.aten.to.dtype(getitem_1005, torch.float32);  getitem_1005 = None
        to_dtype_112 = torch.ops.aten.to.dtype(relu_default_162, torch.float32);  relu_default_162 = None
        le_scalar_37 = torch.ops.aten.le.Scalar(to_dtype_112, 0);  to_dtype_112 = None
        new_zeros_default_238 = torch.ops.aten.new_zeros.default(to_dtype_111, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_37 = torch.ops.aten.where.self(le_scalar_37, new_zeros_default_238, to_dtype_111);  le_scalar_37 = new_zeros_default_238 = to_dtype_111 = None
        to_dtype_113 = torch.ops.aten.to.dtype(where_self_37, torch.float32);  where_self_37 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_113, convolution_default_302, primals_1089, primals_1087, primals_1088, getitem_558, getitem_559, True, 0.001, [True, True, True]);  to_dtype_113 = convolution_default_302 = primals_1089 = primals_1087 = primals_1088 = getitem_558 = getitem_559 = None
        getitem_1008 = native_batch_norm_backward_default_37[0]
        getitem_1009 = native_batch_norm_backward_default_37[1]
        getitem_1010 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        convolution_backward_default_70 = torch.ops.aten.convolution_backward.default(getitem_1008, convolution_default_301, primals_1096, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1008 = convolution_default_301 = primals_1096 = None
        getitem_1011 = convolution_backward_default_70[0]
        getitem_1012 = convolution_backward_default_70[1]
        getitem_1013 = convolution_backward_default_70[2];  convolution_backward_default_70 = None
        convolution_backward_default_71 = torch.ops.aten.convolution_backward.default(getitem_1011, relu_default_161, primals_1095, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_1011 = primals_1095 = None
        getitem_1014 = convolution_backward_default_71[0]
        getitem_1015 = convolution_backward_default_71[1]
        getitem_1016 = convolution_backward_default_71[2];  convolution_backward_default_71 = None
        to_dtype_114 = torch.ops.aten.to.dtype(getitem_1014, torch.float32);  getitem_1014 = None
        to_dtype_115 = torch.ops.aten.to.dtype(relu_default_161, torch.float32);  relu_default_161 = None
        le_scalar_38 = torch.ops.aten.le.Scalar(to_dtype_115, 0);  to_dtype_115 = None
        new_zeros_default_239 = torch.ops.aten.new_zeros.default(to_dtype_114, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_38 = torch.ops.aten.where.self(le_scalar_38, new_zeros_default_239, to_dtype_114);  le_scalar_38 = new_zeros_default_239 = to_dtype_114 = None
        to_dtype_116 = torch.ops.aten.to.dtype(where_self_38, torch.float32);  where_self_38 = None
        add_tensor_93 = torch.ops.aten.add.Tensor(add_tensor_92, to_dtype_116);  add_tensor_92 = to_dtype_116 = None
        max_pool2d_with_indices_backward_default_8 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_10, getitem_543, [3, 3], [1, 1], [1, 1], [1, 1], False, getitem_556);  getitem_543 = getitem_556 = None
        add_tensor_94 = torch.ops.aten.add.Tensor(to_dtype_92, max_pool2d_with_indices_backward_default_8);  to_dtype_92 = max_pool2d_with_indices_backward_default_8 = None
        clone_default_11 = torch.ops.aten.clone.default(slice_tensor_10, memory_format = torch.contiguous_format);  slice_tensor_10 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(clone_default_11, convolution_default_300, primals_1080, primals_1078, primals_1079, getitem_553, getitem_554, True, 0.001, [True, True, True]);  clone_default_11 = convolution_default_300 = primals_1080 = primals_1078 = primals_1079 = getitem_553 = getitem_554 = None
        getitem_1017 = native_batch_norm_backward_default_38[0]
        getitem_1018 = native_batch_norm_backward_default_38[1]
        getitem_1019 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        convolution_backward_default_72 = torch.ops.aten.convolution_backward.default(getitem_1017, convolution_default_299, primals_1084, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1017 = convolution_default_299 = primals_1084 = None
        getitem_1020 = convolution_backward_default_72[0]
        getitem_1021 = convolution_backward_default_72[1]
        getitem_1022 = convolution_backward_default_72[2];  convolution_backward_default_72 = None
        convolution_backward_default_73 = torch.ops.aten.convolution_backward.default(getitem_1020, relu_default_160, primals_1083, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_1020 = primals_1083 = None
        getitem_1023 = convolution_backward_default_73[0]
        getitem_1024 = convolution_backward_default_73[1]
        getitem_1025 = convolution_backward_default_73[2];  convolution_backward_default_73 = None
        to_dtype_117 = torch.ops.aten.to.dtype(getitem_1023, torch.float32);  getitem_1023 = None
        to_dtype_118 = torch.ops.aten.to.dtype(relu_default_160, torch.float32);  relu_default_160 = None
        le_scalar_39 = torch.ops.aten.le.Scalar(to_dtype_118, 0);  to_dtype_118 = None
        new_zeros_default_240 = torch.ops.aten.new_zeros.default(to_dtype_117, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_39 = torch.ops.aten.where.self(le_scalar_39, new_zeros_default_240, to_dtype_117);  le_scalar_39 = new_zeros_default_240 = to_dtype_117 = None
        to_dtype_119 = torch.ops.aten.to.dtype(where_self_39, torch.float32);  where_self_39 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_119, convolution_default_298, primals_1075, primals_1073, primals_1074, getitem_550, getitem_551, True, 0.001, [True, True, True]);  to_dtype_119 = convolution_default_298 = primals_1075 = primals_1073 = primals_1074 = getitem_550 = getitem_551 = None
        getitem_1026 = native_batch_norm_backward_default_39[0]
        getitem_1027 = native_batch_norm_backward_default_39[1]
        getitem_1028 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        convolution_backward_default_74 = torch.ops.aten.convolution_backward.default(getitem_1026, convolution_default_297, primals_1082, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1026 = convolution_default_297 = primals_1082 = None
        getitem_1029 = convolution_backward_default_74[0]
        getitem_1030 = convolution_backward_default_74[1]
        getitem_1031 = convolution_backward_default_74[2];  convolution_backward_default_74 = None
        convolution_backward_default_75 = torch.ops.aten.convolution_backward.default(getitem_1029, relu_default_159, primals_1081, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_1029 = primals_1081 = None
        getitem_1032 = convolution_backward_default_75[0]
        getitem_1033 = convolution_backward_default_75[1]
        getitem_1034 = convolution_backward_default_75[2];  convolution_backward_default_75 = None
        to_dtype_120 = torch.ops.aten.to.dtype(getitem_1032, torch.float32);  getitem_1032 = None
        to_dtype_121 = torch.ops.aten.to.dtype(relu_default_159, torch.float32);  relu_default_159 = None
        le_scalar_40 = torch.ops.aten.le.Scalar(to_dtype_121, 0);  to_dtype_121 = None
        new_zeros_default_241 = torch.ops.aten.new_zeros.default(to_dtype_120, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_40 = torch.ops.aten.where.self(le_scalar_40, new_zeros_default_241, to_dtype_120);  le_scalar_40 = new_zeros_default_241 = to_dtype_120 = None
        to_dtype_122 = torch.ops.aten.to.dtype(where_self_40, torch.float32);  where_self_40 = None
        add_tensor_95 = torch.ops.aten.add.Tensor(add_tensor_94, to_dtype_122);  add_tensor_94 = to_dtype_122 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_93, convolution_default_296, primals_1159, primals_1157, primals_1158, getitem_547, getitem_548, True, 0.001, [True, True, True]);  add_tensor_93 = convolution_default_296 = primals_1159 = primals_1157 = primals_1158 = getitem_547 = getitem_548 = None
        getitem_1035 = native_batch_norm_backward_default_40[0]
        getitem_1036 = native_batch_norm_backward_default_40[1]
        getitem_1037 = native_batch_norm_backward_default_40[2];  native_batch_norm_backward_default_40 = None
        convolution_backward_default_76 = torch.ops.aten.convolution_backward.default(getitem_1035, relu_default_158, primals_1160, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1035 = primals_1160 = None
        getitem_1038 = convolution_backward_default_76[0]
        getitem_1039 = convolution_backward_default_76[1]
        getitem_1040 = convolution_backward_default_76[2];  convolution_backward_default_76 = None
        to_dtype_123 = torch.ops.aten.to.dtype(getitem_1038, torch.float32);  getitem_1038 = None
        to_dtype_124 = torch.ops.aten.to.dtype(relu_default_158, torch.float32);  relu_default_158 = None
        le_scalar_41 = torch.ops.aten.le.Scalar(to_dtype_124, 0);  to_dtype_124 = None
        new_zeros_default_242 = torch.ops.aten.new_zeros.default(to_dtype_123, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_41 = torch.ops.aten.where.self(le_scalar_41, new_zeros_default_242, to_dtype_123);  le_scalar_41 = new_zeros_default_242 = to_dtype_123 = None
        to_dtype_125 = torch.ops.aten.to.dtype(where_self_41, torch.float32);  where_self_41 = None
        add_tensor_96 = torch.ops.aten.add.Tensor(to_dtype_86, to_dtype_125);  to_dtype_86 = to_dtype_125 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_95, cat_default_14, primals_1165, primals_1163, primals_1164, getitem_544, getitem_545, True, 0.001, [True, True, True]);  add_tensor_95 = cat_default_14 = primals_1165 = primals_1163 = primals_1164 = getitem_544 = getitem_545 = None
        getitem_1041 = native_batch_norm_backward_default_41[0]
        getitem_1042 = native_batch_norm_backward_default_41[1]
        getitem_1043 = native_batch_norm_backward_default_41[2];  native_batch_norm_backward_default_41 = None
        slice_tensor_15 = torch.ops.aten.slice.Tensor(getitem_1041, 1, 0, 432)
        slice_tensor_16 = torch.ops.aten.slice.Tensor(getitem_1041, 1, 432, 864);  getitem_1041 = None
        convolution_backward_default_77 = torch.ops.aten.convolution_backward.default(slice_tensor_16, avg_pool2d_default_7, primals_1167, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_16 = avg_pool2d_default_7 = primals_1167 = None
        getitem_1044 = convolution_backward_default_77[0]
        getitem_1045 = convolution_backward_default_77[1]
        getitem_1046 = convolution_backward_default_77[2];  convolution_backward_default_77 = None
        avg_pool2d_backward_default = torch.ops.aten.avg_pool2d_backward.default(getitem_1044, constant_pad_nd_default_35, [1, 1], [2, 2], [0, 0], False, False, None);  getitem_1044 = constant_pad_nd_default_35 = None
        constant_pad_nd_default_36 = torch.ops.aten.constant_pad_nd.default(avg_pool2d_backward_default, [1, -1, 1, -1]);  avg_pool2d_backward_default = None
        convolution_backward_default_78 = torch.ops.aten.convolution_backward.default(slice_tensor_15, avg_pool2d_default_6, primals_1166, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_15 = avg_pool2d_default_6 = primals_1166 = None
        getitem_1047 = convolution_backward_default_78[0]
        getitem_1048 = convolution_backward_default_78[1]
        getitem_1049 = convolution_backward_default_78[2];  convolution_backward_default_78 = None
        avg_pool2d_backward_default_1 = torch.ops.aten.avg_pool2d_backward.default(getitem_1047, relu_default_157, [1, 1], [2, 2], [0, 0], False, False, None);  getitem_1047 = None
        add_tensor_97 = torch.ops.aten.add.Tensor(constant_pad_nd_default_36, avg_pool2d_backward_default_1);  constant_pad_nd_default_36 = avg_pool2d_backward_default_1 = None
        to_dtype_126 = torch.ops.aten.to.dtype(add_tensor_97, torch.float32);  add_tensor_97 = None
        to_dtype_127 = torch.ops.aten.to.dtype(relu_default_157, torch.float32);  relu_default_157 = None
        le_scalar_42 = torch.ops.aten.le.Scalar(to_dtype_127, 0);  to_dtype_127 = None
        new_zeros_default_243 = torch.ops.aten.new_zeros.default(to_dtype_126, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_42 = torch.ops.aten.where.self(le_scalar_42, new_zeros_default_243, to_dtype_126);  le_scalar_42 = new_zeros_default_243 = to_dtype_126 = None
        to_dtype_128 = torch.ops.aten.to.dtype(where_self_42, torch.float32);  where_self_42 = None
        slice_tensor_17 = torch.ops.aten.slice.Tensor(add_tensor_96, 1, 0, 864)
        slice_tensor_18 = torch.ops.aten.slice.Tensor(add_tensor_96, 1, 864, 1728)
        slice_tensor_19 = torch.ops.aten.slice.Tensor(add_tensor_96, 1, 1728, 2592)
        slice_tensor_20 = torch.ops.aten.slice.Tensor(add_tensor_96, 1, 2592, 3456)
        slice_tensor_21 = torch.ops.aten.slice.Tensor(add_tensor_96, 1, 3456, 4320);  add_tensor_96 = None
        clone_default_12 = torch.ops.aten.clone.default(slice_tensor_21, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(clone_default_12, convolution_default_293, primals_1057, primals_1055, primals_1056, getitem_541, getitem_542, True, 0.001, [True, True, True]);  clone_default_12 = convolution_default_293 = primals_1057 = primals_1055 = primals_1056 = getitem_541 = getitem_542 = None
        getitem_1050 = native_batch_norm_backward_default_42[0]
        getitem_1051 = native_batch_norm_backward_default_42[1]
        getitem_1052 = native_batch_norm_backward_default_42[2];  native_batch_norm_backward_default_42 = None
        convolution_backward_default_79 = torch.ops.aten.convolution_backward.default(getitem_1050, relu_default_156, primals_1058, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1050 = primals_1058 = None
        getitem_1053 = convolution_backward_default_79[0]
        getitem_1054 = convolution_backward_default_79[1]
        getitem_1055 = convolution_backward_default_79[2];  convolution_backward_default_79 = None
        to_dtype_129 = torch.ops.aten.to.dtype(getitem_1053, torch.float32);  getitem_1053 = None
        to_dtype_130 = torch.ops.aten.to.dtype(relu_default_156, torch.float32);  relu_default_156 = None
        le_scalar_43 = torch.ops.aten.le.Scalar(to_dtype_130, 0);  to_dtype_130 = None
        new_zeros_default_244 = torch.ops.aten.new_zeros.default(to_dtype_129, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_43 = torch.ops.aten.where.self(le_scalar_43, new_zeros_default_244, to_dtype_129);  le_scalar_43 = new_zeros_default_244 = to_dtype_129 = None
        to_dtype_131 = torch.ops.aten.to.dtype(where_self_43, torch.float32);  where_self_43 = None
        clone_default_13 = torch.ops.aten.clone.default(slice_tensor_21, memory_format = torch.contiguous_format);  slice_tensor_21 = None
        native_batch_norm_backward_default_43 = torch.ops.aten.native_batch_norm_backward.default(clone_default_13, convolution_default_292, primals_1048, primals_1046, primals_1047, getitem_538, getitem_539, True, 0.001, [True, True, True]);  clone_default_13 = convolution_default_292 = primals_1048 = primals_1046 = primals_1047 = getitem_538 = getitem_539 = None
        getitem_1056 = native_batch_norm_backward_default_43[0]
        getitem_1057 = native_batch_norm_backward_default_43[1]
        getitem_1058 = native_batch_norm_backward_default_43[2];  native_batch_norm_backward_default_43 = None
        convolution_backward_default_80 = torch.ops.aten.convolution_backward.default(getitem_1056, convolution_default_291, primals_1052, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1056 = convolution_default_291 = primals_1052 = None
        getitem_1059 = convolution_backward_default_80[0]
        getitem_1060 = convolution_backward_default_80[1]
        getitem_1061 = convolution_backward_default_80[2];  convolution_backward_default_80 = None
        convolution_backward_default_81 = torch.ops.aten.convolution_backward.default(getitem_1059, relu_default_155, primals_1051, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_1059 = primals_1051 = None
        getitem_1062 = convolution_backward_default_81[0]
        getitem_1063 = convolution_backward_default_81[1]
        getitem_1064 = convolution_backward_default_81[2];  convolution_backward_default_81 = None
        to_dtype_132 = torch.ops.aten.to.dtype(getitem_1062, torch.float32);  getitem_1062 = None
        to_dtype_133 = torch.ops.aten.to.dtype(relu_default_155, torch.float32);  relu_default_155 = None
        le_scalar_44 = torch.ops.aten.le.Scalar(to_dtype_133, 0);  to_dtype_133 = None
        new_zeros_default_245 = torch.ops.aten.new_zeros.default(to_dtype_132, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_44 = torch.ops.aten.where.self(le_scalar_44, new_zeros_default_245, to_dtype_132);  le_scalar_44 = new_zeros_default_245 = to_dtype_132 = None
        to_dtype_134 = torch.ops.aten.to.dtype(where_self_44, torch.float32);  where_self_44 = None
        native_batch_norm_backward_default_44 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_134, convolution_default_290, primals_1043, primals_1041, primals_1042, getitem_535, getitem_536, True, 0.001, [True, True, True]);  to_dtype_134 = convolution_default_290 = primals_1043 = primals_1041 = primals_1042 = getitem_535 = getitem_536 = None
        getitem_1065 = native_batch_norm_backward_default_44[0]
        getitem_1066 = native_batch_norm_backward_default_44[1]
        getitem_1067 = native_batch_norm_backward_default_44[2];  native_batch_norm_backward_default_44 = None
        convolution_backward_default_82 = torch.ops.aten.convolution_backward.default(getitem_1065, convolution_default_289, primals_1050, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1065 = convolution_default_289 = primals_1050 = None
        getitem_1068 = convolution_backward_default_82[0]
        getitem_1069 = convolution_backward_default_82[1]
        getitem_1070 = convolution_backward_default_82[2];  convolution_backward_default_82 = None
        convolution_backward_default_83 = torch.ops.aten.convolution_backward.default(getitem_1068, constant_pad_nd_default_34, primals_1049, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_1068 = constant_pad_nd_default_34 = primals_1049 = None
        getitem_1071 = convolution_backward_default_83[0]
        getitem_1072 = convolution_backward_default_83[1]
        getitem_1073 = convolution_backward_default_83[2];  convolution_backward_default_83 = None
        constant_pad_nd_default_37 = torch.ops.aten.constant_pad_nd.default(getitem_1071, [-1, -1, -1, -1]);  getitem_1071 = None
        to_dtype_135 = torch.ops.aten.to.dtype(constant_pad_nd_default_37, torch.float32);  constant_pad_nd_default_37 = None
        to_dtype_136 = torch.ops.aten.to.dtype(relu_default_154, torch.float32);  relu_default_154 = None
        le_scalar_45 = torch.ops.aten.le.Scalar(to_dtype_136, 0);  to_dtype_136 = None
        new_zeros_default_246 = torch.ops.aten.new_zeros.default(to_dtype_135, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_45 = torch.ops.aten.where.self(le_scalar_45, new_zeros_default_246, to_dtype_135);  le_scalar_45 = new_zeros_default_246 = to_dtype_135 = None
        to_dtype_137 = torch.ops.aten.to.dtype(where_self_45, torch.float32);  where_self_45 = None
        max_pool2d_with_indices_backward_default_9 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_20, constant_pad_nd_default_33, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_533);  constant_pad_nd_default_33 = getitem_533 = None
        constant_pad_nd_default_38 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default_9, [-1, -1, -1, -1]);  max_pool2d_with_indices_backward_default_9 = None
        add_tensor_98 = torch.ops.aten.add.Tensor(to_dtype_131, constant_pad_nd_default_38);  to_dtype_131 = constant_pad_nd_default_38 = None
        clone_default_14 = torch.ops.aten.clone.default(slice_tensor_20, memory_format = torch.contiguous_format);  slice_tensor_20 = None
        native_batch_norm_backward_default_45 = torch.ops.aten.native_batch_norm_backward.default(clone_default_14, convolution_default_288, primals_1034, primals_1032, primals_1033, getitem_530, getitem_531, True, 0.001, [True, True, True]);  clone_default_14 = convolution_default_288 = primals_1034 = primals_1032 = primals_1033 = getitem_530 = getitem_531 = None
        getitem_1074 = native_batch_norm_backward_default_45[0]
        getitem_1075 = native_batch_norm_backward_default_45[1]
        getitem_1076 = native_batch_norm_backward_default_45[2];  native_batch_norm_backward_default_45 = None
        convolution_backward_default_84 = torch.ops.aten.convolution_backward.default(getitem_1074, convolution_default_287, primals_1038, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1074 = convolution_default_287 = primals_1038 = None
        getitem_1077 = convolution_backward_default_84[0]
        getitem_1078 = convolution_backward_default_84[1]
        getitem_1079 = convolution_backward_default_84[2];  convolution_backward_default_84 = None
        convolution_backward_default_85 = torch.ops.aten.convolution_backward.default(getitem_1077, relu_default_153, primals_1037, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_1077 = primals_1037 = None
        getitem_1080 = convolution_backward_default_85[0]
        getitem_1081 = convolution_backward_default_85[1]
        getitem_1082 = convolution_backward_default_85[2];  convolution_backward_default_85 = None
        to_dtype_138 = torch.ops.aten.to.dtype(getitem_1080, torch.float32);  getitem_1080 = None
        to_dtype_139 = torch.ops.aten.to.dtype(relu_default_153, torch.float32);  relu_default_153 = None
        le_scalar_46 = torch.ops.aten.le.Scalar(to_dtype_139, 0);  to_dtype_139 = None
        new_zeros_default_247 = torch.ops.aten.new_zeros.default(to_dtype_138, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_46 = torch.ops.aten.where.self(le_scalar_46, new_zeros_default_247, to_dtype_138);  le_scalar_46 = new_zeros_default_247 = to_dtype_138 = None
        to_dtype_140 = torch.ops.aten.to.dtype(where_self_46, torch.float32);  where_self_46 = None
        native_batch_norm_backward_default_46 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_140, convolution_default_286, primals_1029, primals_1027, primals_1028, getitem_527, getitem_528, True, 0.001, [True, True, True]);  to_dtype_140 = convolution_default_286 = primals_1029 = primals_1027 = primals_1028 = getitem_527 = getitem_528 = None
        getitem_1083 = native_batch_norm_backward_default_46[0]
        getitem_1084 = native_batch_norm_backward_default_46[1]
        getitem_1085 = native_batch_norm_backward_default_46[2];  native_batch_norm_backward_default_46 = None
        convolution_backward_default_86 = torch.ops.aten.convolution_backward.default(getitem_1083, convolution_default_285, primals_1036, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1083 = convolution_default_285 = primals_1036 = None
        getitem_1086 = convolution_backward_default_86[0]
        getitem_1087 = convolution_backward_default_86[1]
        getitem_1088 = convolution_backward_default_86[2];  convolution_backward_default_86 = None
        convolution_backward_default_87 = torch.ops.aten.convolution_backward.default(getitem_1086, relu_default_152, primals_1035, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_1086 = primals_1035 = None
        getitem_1089 = convolution_backward_default_87[0]
        getitem_1090 = convolution_backward_default_87[1]
        getitem_1091 = convolution_backward_default_87[2];  convolution_backward_default_87 = None
        to_dtype_141 = torch.ops.aten.to.dtype(getitem_1089, torch.float32);  getitem_1089 = None
        to_dtype_142 = torch.ops.aten.to.dtype(relu_default_152, torch.float32);  relu_default_152 = None
        le_scalar_47 = torch.ops.aten.le.Scalar(to_dtype_142, 0);  to_dtype_142 = None
        new_zeros_default_248 = torch.ops.aten.new_zeros.default(to_dtype_141, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_47 = torch.ops.aten.where.self(le_scalar_47, new_zeros_default_248, to_dtype_141);  le_scalar_47 = new_zeros_default_248 = to_dtype_141 = None
        to_dtype_143 = torch.ops.aten.to.dtype(where_self_47, torch.float32);  where_self_47 = None
        add_tensor_99 = torch.ops.aten.add.Tensor(slice_tensor_19, to_dtype_143);  slice_tensor_19 = to_dtype_143 = None
        native_batch_norm_backward_default_47 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_99, convolution_default_284, primals_1020, primals_1018, primals_1019, getitem_524, getitem_525, True, 0.001, [True, True, True]);  convolution_default_284 = primals_1020 = primals_1018 = primals_1019 = getitem_524 = getitem_525 = None
        getitem_1092 = native_batch_norm_backward_default_47[0]
        getitem_1093 = native_batch_norm_backward_default_47[1]
        getitem_1094 = native_batch_norm_backward_default_47[2];  native_batch_norm_backward_default_47 = None
        convolution_backward_default_88 = torch.ops.aten.convolution_backward.default(getitem_1092, convolution_default_283, primals_1024, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1092 = convolution_default_283 = primals_1024 = None
        getitem_1095 = convolution_backward_default_88[0]
        getitem_1096 = convolution_backward_default_88[1]
        getitem_1097 = convolution_backward_default_88[2];  convolution_backward_default_88 = None
        convolution_backward_default_89 = torch.ops.aten.convolution_backward.default(getitem_1095, relu_default_151, primals_1023, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_1095 = primals_1023 = None
        getitem_1098 = convolution_backward_default_89[0]
        getitem_1099 = convolution_backward_default_89[1]
        getitem_1100 = convolution_backward_default_89[2];  convolution_backward_default_89 = None
        to_dtype_144 = torch.ops.aten.to.dtype(getitem_1098, torch.float32);  getitem_1098 = None
        to_dtype_145 = torch.ops.aten.to.dtype(relu_default_151, torch.float32);  relu_default_151 = None
        le_scalar_48 = torch.ops.aten.le.Scalar(to_dtype_145, 0);  to_dtype_145 = None
        new_zeros_default_249 = torch.ops.aten.new_zeros.default(to_dtype_144, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_48 = torch.ops.aten.where.self(le_scalar_48, new_zeros_default_249, to_dtype_144);  le_scalar_48 = new_zeros_default_249 = to_dtype_144 = None
        to_dtype_146 = torch.ops.aten.to.dtype(where_self_48, torch.float32);  where_self_48 = None
        native_batch_norm_backward_default_48 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_146, convolution_default_282, primals_1015, primals_1013, primals_1014, getitem_521, getitem_522, True, 0.001, [True, True, True]);  to_dtype_146 = convolution_default_282 = primals_1015 = primals_1013 = primals_1014 = getitem_521 = getitem_522 = None
        getitem_1101 = native_batch_norm_backward_default_48[0]
        getitem_1102 = native_batch_norm_backward_default_48[1]
        getitem_1103 = native_batch_norm_backward_default_48[2];  native_batch_norm_backward_default_48 = None
        convolution_backward_default_90 = torch.ops.aten.convolution_backward.default(getitem_1101, convolution_default_281, primals_1022, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1101 = convolution_default_281 = primals_1022 = None
        getitem_1104 = convolution_backward_default_90[0]
        getitem_1105 = convolution_backward_default_90[1]
        getitem_1106 = convolution_backward_default_90[2];  convolution_backward_default_90 = None
        convolution_backward_default_91 = torch.ops.aten.convolution_backward.default(getitem_1104, constant_pad_nd_default_32, primals_1021, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_1104 = constant_pad_nd_default_32 = primals_1021 = None
        getitem_1107 = convolution_backward_default_91[0]
        getitem_1108 = convolution_backward_default_91[1]
        getitem_1109 = convolution_backward_default_91[2];  convolution_backward_default_91 = None
        constant_pad_nd_default_39 = torch.ops.aten.constant_pad_nd.default(getitem_1107, [-1, -1, -1, -1]);  getitem_1107 = None
        to_dtype_147 = torch.ops.aten.to.dtype(constant_pad_nd_default_39, torch.float32);  constant_pad_nd_default_39 = None
        to_dtype_148 = torch.ops.aten.to.dtype(relu_default_150, torch.float32);  relu_default_150 = None
        le_scalar_49 = torch.ops.aten.le.Scalar(to_dtype_148, 0);  to_dtype_148 = None
        new_zeros_default_250 = torch.ops.aten.new_zeros.default(to_dtype_147, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_49 = torch.ops.aten.where.self(le_scalar_49, new_zeros_default_250, to_dtype_147);  le_scalar_49 = new_zeros_default_250 = to_dtype_147 = None
        to_dtype_149 = torch.ops.aten.to.dtype(where_self_49, torch.float32);  where_self_49 = None
        add_tensor_100 = torch.ops.aten.add.Tensor(add_tensor_98, to_dtype_149);  add_tensor_98 = to_dtype_149 = None
        native_batch_norm_backward_default_49 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_99, convolution_default_280, primals_1006, primals_1004, primals_1005, getitem_518, getitem_519, True, 0.001, [True, True, True]);  add_tensor_99 = convolution_default_280 = primals_1006 = primals_1004 = primals_1005 = getitem_518 = getitem_519 = None
        getitem_1110 = native_batch_norm_backward_default_49[0]
        getitem_1111 = native_batch_norm_backward_default_49[1]
        getitem_1112 = native_batch_norm_backward_default_49[2];  native_batch_norm_backward_default_49 = None
        convolution_backward_default_92 = torch.ops.aten.convolution_backward.default(getitem_1110, convolution_default_279, primals_1010, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1110 = convolution_default_279 = primals_1010 = None
        getitem_1113 = convolution_backward_default_92[0]
        getitem_1114 = convolution_backward_default_92[1]
        getitem_1115 = convolution_backward_default_92[2];  convolution_backward_default_92 = None
        convolution_backward_default_93 = torch.ops.aten.convolution_backward.default(getitem_1113, relu_default_149, primals_1009, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_1113 = primals_1009 = None
        getitem_1116 = convolution_backward_default_93[0]
        getitem_1117 = convolution_backward_default_93[1]
        getitem_1118 = convolution_backward_default_93[2];  convolution_backward_default_93 = None
        to_dtype_150 = torch.ops.aten.to.dtype(getitem_1116, torch.float32);  getitem_1116 = None
        to_dtype_151 = torch.ops.aten.to.dtype(relu_default_149, torch.float32);  relu_default_149 = None
        le_scalar_50 = torch.ops.aten.le.Scalar(to_dtype_151, 0);  to_dtype_151 = None
        new_zeros_default_251 = torch.ops.aten.new_zeros.default(to_dtype_150, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_50 = torch.ops.aten.where.self(le_scalar_50, new_zeros_default_251, to_dtype_150);  le_scalar_50 = new_zeros_default_251 = to_dtype_150 = None
        to_dtype_152 = torch.ops.aten.to.dtype(where_self_50, torch.float32);  where_self_50 = None
        native_batch_norm_backward_default_50 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_152, convolution_default_278, primals_1001, primals_999, primals_1000, getitem_515, getitem_516, True, 0.001, [True, True, True]);  to_dtype_152 = convolution_default_278 = primals_1001 = primals_999 = primals_1000 = getitem_515 = getitem_516 = None
        getitem_1119 = native_batch_norm_backward_default_50[0]
        getitem_1120 = native_batch_norm_backward_default_50[1]
        getitem_1121 = native_batch_norm_backward_default_50[2];  native_batch_norm_backward_default_50 = None
        convolution_backward_default_94 = torch.ops.aten.convolution_backward.default(getitem_1119, convolution_default_277, primals_1008, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1119 = convolution_default_277 = primals_1008 = None
        getitem_1122 = convolution_backward_default_94[0]
        getitem_1123 = convolution_backward_default_94[1]
        getitem_1124 = convolution_backward_default_94[2];  convolution_backward_default_94 = None
        convolution_backward_default_95 = torch.ops.aten.convolution_backward.default(getitem_1122, constant_pad_nd_default_31, primals_1007, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_1122 = constant_pad_nd_default_31 = primals_1007 = None
        getitem_1125 = convolution_backward_default_95[0]
        getitem_1126 = convolution_backward_default_95[1]
        getitem_1127 = convolution_backward_default_95[2];  convolution_backward_default_95 = None
        constant_pad_nd_default_40 = torch.ops.aten.constant_pad_nd.default(getitem_1125, [-2, -2, -2, -2]);  getitem_1125 = None
        to_dtype_153 = torch.ops.aten.to.dtype(constant_pad_nd_default_40, torch.float32);  constant_pad_nd_default_40 = None
        to_dtype_154 = torch.ops.aten.to.dtype(relu_default_148, torch.float32);  relu_default_148 = None
        le_scalar_51 = torch.ops.aten.le.Scalar(to_dtype_154, 0);  to_dtype_154 = None
        new_zeros_default_252 = torch.ops.aten.new_zeros.default(to_dtype_153, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_51 = torch.ops.aten.where.self(le_scalar_51, new_zeros_default_252, to_dtype_153);  le_scalar_51 = new_zeros_default_252 = to_dtype_153 = None
        to_dtype_155 = torch.ops.aten.to.dtype(where_self_51, torch.float32);  where_self_51 = None
        add_tensor_101 = torch.ops.aten.add.Tensor(add_tensor_100, to_dtype_155);  add_tensor_100 = to_dtype_155 = None
        max_pool2d_with_indices_backward_default_10 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_18, constant_pad_nd_default_30, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_513);  constant_pad_nd_default_30 = getitem_513 = None
        constant_pad_nd_default_41 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default_10, [-1, -1, -1, -1]);  max_pool2d_with_indices_backward_default_10 = None
        add_tensor_102 = torch.ops.aten.add.Tensor(add_tensor_101, constant_pad_nd_default_41);  add_tensor_101 = constant_pad_nd_default_41 = None
        clone_default_15 = torch.ops.aten.clone.default(slice_tensor_18, memory_format = torch.contiguous_format);  slice_tensor_18 = None
        native_batch_norm_backward_default_51 = torch.ops.aten.native_batch_norm_backward.default(clone_default_15, convolution_default_276, primals_992, primals_990, primals_991, getitem_510, getitem_511, True, 0.001, [True, True, True]);  clone_default_15 = convolution_default_276 = primals_992 = primals_990 = primals_991 = getitem_510 = getitem_511 = None
        getitem_1128 = native_batch_norm_backward_default_51[0]
        getitem_1129 = native_batch_norm_backward_default_51[1]
        getitem_1130 = native_batch_norm_backward_default_51[2];  native_batch_norm_backward_default_51 = None
        convolution_backward_default_96 = torch.ops.aten.convolution_backward.default(getitem_1128, convolution_default_275, primals_996, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1128 = convolution_default_275 = primals_996 = None
        getitem_1131 = convolution_backward_default_96[0]
        getitem_1132 = convolution_backward_default_96[1]
        getitem_1133 = convolution_backward_default_96[2];  convolution_backward_default_96 = None
        convolution_backward_default_97 = torch.ops.aten.convolution_backward.default(getitem_1131, relu_default_147, primals_995, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_1131 = primals_995 = None
        getitem_1134 = convolution_backward_default_97[0]
        getitem_1135 = convolution_backward_default_97[1]
        getitem_1136 = convolution_backward_default_97[2];  convolution_backward_default_97 = None
        to_dtype_156 = torch.ops.aten.to.dtype(getitem_1134, torch.float32);  getitem_1134 = None
        to_dtype_157 = torch.ops.aten.to.dtype(relu_default_147, torch.float32);  relu_default_147 = None
        le_scalar_52 = torch.ops.aten.le.Scalar(to_dtype_157, 0);  to_dtype_157 = None
        new_zeros_default_253 = torch.ops.aten.new_zeros.default(to_dtype_156, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_52 = torch.ops.aten.where.self(le_scalar_52, new_zeros_default_253, to_dtype_156);  le_scalar_52 = new_zeros_default_253 = to_dtype_156 = None
        to_dtype_158 = torch.ops.aten.to.dtype(where_self_52, torch.float32);  where_self_52 = None
        native_batch_norm_backward_default_52 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_158, convolution_default_274, primals_987, primals_985, primals_986, getitem_507, getitem_508, True, 0.001, [True, True, True]);  to_dtype_158 = convolution_default_274 = primals_987 = primals_985 = primals_986 = getitem_507 = getitem_508 = None
        getitem_1137 = native_batch_norm_backward_default_52[0]
        getitem_1138 = native_batch_norm_backward_default_52[1]
        getitem_1139 = native_batch_norm_backward_default_52[2];  native_batch_norm_backward_default_52 = None
        convolution_backward_default_98 = torch.ops.aten.convolution_backward.default(getitem_1137, convolution_default_273, primals_994, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1137 = convolution_default_273 = primals_994 = None
        getitem_1140 = convolution_backward_default_98[0]
        getitem_1141 = convolution_backward_default_98[1]
        getitem_1142 = convolution_backward_default_98[2];  convolution_backward_default_98 = None
        convolution_backward_default_99 = torch.ops.aten.convolution_backward.default(getitem_1140, constant_pad_nd_default_29, primals_993, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_1140 = constant_pad_nd_default_29 = primals_993 = None
        getitem_1143 = convolution_backward_default_99[0]
        getitem_1144 = convolution_backward_default_99[1]
        getitem_1145 = convolution_backward_default_99[2];  convolution_backward_default_99 = None
        constant_pad_nd_default_42 = torch.ops.aten.constant_pad_nd.default(getitem_1143, [-3, -3, -3, -3]);  getitem_1143 = None
        to_dtype_159 = torch.ops.aten.to.dtype(constant_pad_nd_default_42, torch.float32);  constant_pad_nd_default_42 = None
        to_dtype_160 = torch.ops.aten.to.dtype(relu_default_146, torch.float32);  relu_default_146 = None
        le_scalar_53 = torch.ops.aten.le.Scalar(to_dtype_160, 0);  to_dtype_160 = None
        new_zeros_default_254 = torch.ops.aten.new_zeros.default(to_dtype_159, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_53 = torch.ops.aten.where.self(le_scalar_53, new_zeros_default_254, to_dtype_159);  le_scalar_53 = new_zeros_default_254 = to_dtype_159 = None
        to_dtype_161 = torch.ops.aten.to.dtype(where_self_53, torch.float32);  where_self_53 = None
        add_tensor_103 = torch.ops.aten.add.Tensor(add_tensor_102, to_dtype_161);  add_tensor_102 = to_dtype_161 = None
        max_pool2d_with_indices_backward_default_11 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_17, constant_pad_nd_default_28, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_505);  constant_pad_nd_default_28 = getitem_505 = None
        constant_pad_nd_default_43 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default_11, [-1, -1, -1, -1]);  max_pool2d_with_indices_backward_default_11 = None
        add_tensor_104 = torch.ops.aten.add.Tensor(to_dtype_137, constant_pad_nd_default_43);  to_dtype_137 = constant_pad_nd_default_43 = None
        clone_default_16 = torch.ops.aten.clone.default(slice_tensor_17, memory_format = torch.contiguous_format);  slice_tensor_17 = None
        native_batch_norm_backward_default_53 = torch.ops.aten.native_batch_norm_backward.default(clone_default_16, convolution_default_272, primals_978, primals_976, primals_977, getitem_502, getitem_503, True, 0.001, [True, True, True]);  clone_default_16 = convolution_default_272 = primals_978 = primals_976 = primals_977 = getitem_502 = getitem_503 = None
        getitem_1146 = native_batch_norm_backward_default_53[0]
        getitem_1147 = native_batch_norm_backward_default_53[1]
        getitem_1148 = native_batch_norm_backward_default_53[2];  native_batch_norm_backward_default_53 = None
        convolution_backward_default_100 = torch.ops.aten.convolution_backward.default(getitem_1146, convolution_default_271, primals_982, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1146 = convolution_default_271 = primals_982 = None
        getitem_1149 = convolution_backward_default_100[0]
        getitem_1150 = convolution_backward_default_100[1]
        getitem_1151 = convolution_backward_default_100[2];  convolution_backward_default_100 = None
        convolution_backward_default_101 = torch.ops.aten.convolution_backward.default(getitem_1149, relu_default_145, primals_981, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_1149 = primals_981 = None
        getitem_1152 = convolution_backward_default_101[0]
        getitem_1153 = convolution_backward_default_101[1]
        getitem_1154 = convolution_backward_default_101[2];  convolution_backward_default_101 = None
        to_dtype_162 = torch.ops.aten.to.dtype(getitem_1152, torch.float32);  getitem_1152 = None
        to_dtype_163 = torch.ops.aten.to.dtype(relu_default_145, torch.float32);  relu_default_145 = None
        le_scalar_54 = torch.ops.aten.le.Scalar(to_dtype_163, 0);  to_dtype_163 = None
        new_zeros_default_255 = torch.ops.aten.new_zeros.default(to_dtype_162, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_54 = torch.ops.aten.where.self(le_scalar_54, new_zeros_default_255, to_dtype_162);  le_scalar_54 = new_zeros_default_255 = to_dtype_162 = None
        to_dtype_164 = torch.ops.aten.to.dtype(where_self_54, torch.float32);  where_self_54 = None
        native_batch_norm_backward_default_54 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_164, convolution_default_270, primals_973, primals_971, primals_972, getitem_499, getitem_500, True, 0.001, [True, True, True]);  to_dtype_164 = convolution_default_270 = primals_973 = primals_971 = primals_972 = getitem_499 = getitem_500 = None
        getitem_1155 = native_batch_norm_backward_default_54[0]
        getitem_1156 = native_batch_norm_backward_default_54[1]
        getitem_1157 = native_batch_norm_backward_default_54[2];  native_batch_norm_backward_default_54 = None
        convolution_backward_default_102 = torch.ops.aten.convolution_backward.default(getitem_1155, convolution_default_269, primals_980, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1155 = convolution_default_269 = primals_980 = None
        getitem_1158 = convolution_backward_default_102[0]
        getitem_1159 = convolution_backward_default_102[1]
        getitem_1160 = convolution_backward_default_102[2];  convolution_backward_default_102 = None
        convolution_backward_default_103 = torch.ops.aten.convolution_backward.default(getitem_1158, constant_pad_nd_default_27, primals_979, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 864, [True, True, False]);  getitem_1158 = constant_pad_nd_default_27 = primals_979 = None
        getitem_1161 = convolution_backward_default_103[0]
        getitem_1162 = convolution_backward_default_103[1]
        getitem_1163 = convolution_backward_default_103[2];  convolution_backward_default_103 = None
        constant_pad_nd_default_44 = torch.ops.aten.constant_pad_nd.default(getitem_1161, [-2, -2, -2, -2]);  getitem_1161 = None
        to_dtype_165 = torch.ops.aten.to.dtype(constant_pad_nd_default_44, torch.float32);  constant_pad_nd_default_44 = None
        to_dtype_166 = torch.ops.aten.to.dtype(relu_default_144, torch.float32);  relu_default_144 = None
        le_scalar_55 = torch.ops.aten.le.Scalar(to_dtype_166, 0);  to_dtype_166 = None
        new_zeros_default_256 = torch.ops.aten.new_zeros.default(to_dtype_165, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_55 = torch.ops.aten.where.self(le_scalar_55, new_zeros_default_256, to_dtype_165);  le_scalar_55 = new_zeros_default_256 = to_dtype_165 = None
        to_dtype_167 = torch.ops.aten.to.dtype(where_self_55, torch.float32);  where_self_55 = None
        add_tensor_105 = torch.ops.aten.add.Tensor(add_tensor_104, to_dtype_167);  add_tensor_104 = to_dtype_167 = None
        native_batch_norm_backward_default_55 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_103, convolution_default_268, primals_1063, primals_1061, primals_1062, getitem_496, getitem_497, True, 0.001, [True, True, True]);  add_tensor_103 = convolution_default_268 = primals_1063 = primals_1061 = primals_1062 = getitem_496 = getitem_497 = None
        getitem_1164 = native_batch_norm_backward_default_55[0]
        getitem_1165 = native_batch_norm_backward_default_55[1]
        getitem_1166 = native_batch_norm_backward_default_55[2];  native_batch_norm_backward_default_55 = None
        convolution_backward_default_104 = torch.ops.aten.convolution_backward.default(getitem_1164, relu_default_143, primals_1064, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1164 = primals_1064 = None
        getitem_1167 = convolution_backward_default_104[0]
        getitem_1168 = convolution_backward_default_104[1]
        getitem_1169 = convolution_backward_default_104[2];  convolution_backward_default_104 = None
        to_dtype_168 = torch.ops.aten.to.dtype(getitem_1167, torch.float32);  getitem_1167 = None
        to_dtype_169 = torch.ops.aten.to.dtype(relu_default_143, torch.float32);  relu_default_143 = None
        le_scalar_56 = torch.ops.aten.le.Scalar(to_dtype_169, 0);  to_dtype_169 = None
        new_zeros_default_257 = torch.ops.aten.new_zeros.default(to_dtype_168, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_56 = torch.ops.aten.where.self(le_scalar_56, new_zeros_default_257, to_dtype_168);  le_scalar_56 = new_zeros_default_257 = to_dtype_168 = None
        to_dtype_170 = torch.ops.aten.to.dtype(where_self_56, torch.float32);  where_self_56 = None
        add_tensor_106 = torch.ops.aten.add.Tensor(to_dtype_128, to_dtype_170);  to_dtype_128 = to_dtype_170 = None
        native_batch_norm_backward_default_56 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_105, convolution_default_267, primals_1069, primals_1067, primals_1068, getitem_493, getitem_494, True, 0.001, [True, True, True]);  add_tensor_105 = convolution_default_267 = primals_1069 = primals_1067 = primals_1068 = getitem_493 = getitem_494 = None
        getitem_1170 = native_batch_norm_backward_default_56[0]
        getitem_1171 = native_batch_norm_backward_default_56[1]
        getitem_1172 = native_batch_norm_backward_default_56[2];  native_batch_norm_backward_default_56 = None
        convolution_backward_default_105 = torch.ops.aten.convolution_backward.default(getitem_1170, relu_default_142, primals_1070, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1170 = primals_1070 = None
        getitem_1173 = convolution_backward_default_105[0]
        getitem_1174 = convolution_backward_default_105[1]
        getitem_1175 = convolution_backward_default_105[2];  convolution_backward_default_105 = None
        to_dtype_171 = torch.ops.aten.to.dtype(getitem_1173, torch.float32);  getitem_1173 = None
        to_dtype_172 = torch.ops.aten.to.dtype(relu_default_142, torch.float32);  relu_default_142 = None
        le_scalar_57 = torch.ops.aten.le.Scalar(to_dtype_172, 0);  to_dtype_172 = None
        new_zeros_default_258 = torch.ops.aten.new_zeros.default(to_dtype_171, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_57 = torch.ops.aten.where.self(le_scalar_57, new_zeros_default_258, to_dtype_171);  le_scalar_57 = new_zeros_default_258 = to_dtype_171 = None
        to_dtype_173 = torch.ops.aten.to.dtype(where_self_57, torch.float32);  where_self_57 = None
        slice_tensor_22 = torch.ops.aten.slice.Tensor(add_tensor_106, 1, 0, 432)
        slice_tensor_23 = torch.ops.aten.slice.Tensor(add_tensor_106, 1, 432, 864)
        slice_tensor_24 = torch.ops.aten.slice.Tensor(add_tensor_106, 1, 864, 1296)
        slice_tensor_25 = torch.ops.aten.slice.Tensor(add_tensor_106, 1, 1296, 1728)
        slice_tensor_26 = torch.ops.aten.slice.Tensor(add_tensor_106, 1, 1728, 2160);  add_tensor_106 = None
        clone_default_17 = torch.ops.aten.clone.default(slice_tensor_26, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_57 = torch.ops.aten.native_batch_norm_backward.default(clone_default_17, convolution_default_266, primals_952, primals_950, primals_951, getitem_490, getitem_491, True, 0.001, [True, True, True]);  clone_default_17 = convolution_default_266 = primals_952 = primals_950 = primals_951 = getitem_490 = getitem_491 = None
        getitem_1176 = native_batch_norm_backward_default_57[0]
        getitem_1177 = native_batch_norm_backward_default_57[1]
        getitem_1178 = native_batch_norm_backward_default_57[2];  native_batch_norm_backward_default_57 = None
        convolution_backward_default_106 = torch.ops.aten.convolution_backward.default(getitem_1176, convolution_default_265, primals_956, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1176 = convolution_default_265 = primals_956 = None
        getitem_1179 = convolution_backward_default_106[0]
        getitem_1180 = convolution_backward_default_106[1]
        getitem_1181 = convolution_backward_default_106[2];  convolution_backward_default_106 = None
        convolution_backward_default_107 = torch.ops.aten.convolution_backward.default(getitem_1179, relu_default_141, primals_955, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1179 = primals_955 = None
        getitem_1182 = convolution_backward_default_107[0]
        getitem_1183 = convolution_backward_default_107[1]
        getitem_1184 = convolution_backward_default_107[2];  convolution_backward_default_107 = None
        to_dtype_174 = torch.ops.aten.to.dtype(getitem_1182, torch.float32);  getitem_1182 = None
        to_dtype_175 = torch.ops.aten.to.dtype(relu_default_141, torch.float32);  relu_default_141 = None
        le_scalar_58 = torch.ops.aten.le.Scalar(to_dtype_175, 0);  to_dtype_175 = None
        new_zeros_default_259 = torch.ops.aten.new_zeros.default(to_dtype_174, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_58 = torch.ops.aten.where.self(le_scalar_58, new_zeros_default_259, to_dtype_174);  le_scalar_58 = new_zeros_default_259 = to_dtype_174 = None
        to_dtype_176 = torch.ops.aten.to.dtype(where_self_58, torch.float32);  where_self_58 = None
        native_batch_norm_backward_default_58 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_176, convolution_default_264, primals_947, primals_945, primals_946, getitem_487, getitem_488, True, 0.001, [True, True, True]);  to_dtype_176 = convolution_default_264 = primals_947 = primals_945 = primals_946 = getitem_487 = getitem_488 = None
        getitem_1185 = native_batch_norm_backward_default_58[0]
        getitem_1186 = native_batch_norm_backward_default_58[1]
        getitem_1187 = native_batch_norm_backward_default_58[2];  native_batch_norm_backward_default_58 = None
        convolution_backward_default_108 = torch.ops.aten.convolution_backward.default(getitem_1185, convolution_default_263, primals_954, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1185 = convolution_default_263 = primals_954 = None
        getitem_1188 = convolution_backward_default_108[0]
        getitem_1189 = convolution_backward_default_108[1]
        getitem_1190 = convolution_backward_default_108[2];  convolution_backward_default_108 = None
        convolution_backward_default_109 = torch.ops.aten.convolution_backward.default(getitem_1188, relu_default_140, primals_953, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1188 = primals_953 = None
        getitem_1191 = convolution_backward_default_109[0]
        getitem_1192 = convolution_backward_default_109[1]
        getitem_1193 = convolution_backward_default_109[2];  convolution_backward_default_109 = None
        to_dtype_177 = torch.ops.aten.to.dtype(getitem_1191, torch.float32);  getitem_1191 = None
        to_dtype_178 = torch.ops.aten.to.dtype(relu_default_140, torch.float32);  relu_default_140 = None
        le_scalar_59 = torch.ops.aten.le.Scalar(to_dtype_178, 0);  to_dtype_178 = None
        new_zeros_default_260 = torch.ops.aten.new_zeros.default(to_dtype_177, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_59 = torch.ops.aten.where.self(le_scalar_59, new_zeros_default_260, to_dtype_177);  le_scalar_59 = new_zeros_default_260 = to_dtype_177 = None
        to_dtype_179 = torch.ops.aten.to.dtype(where_self_59, torch.float32);  where_self_59 = None
        max_pool2d_with_indices_backward_default_12 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_25, getitem_447, [3, 3], [1, 1], [1, 1], [1, 1], False, getitem_485);  getitem_485 = None
        add_tensor_107 = torch.ops.aten.add.Tensor(slice_tensor_26, max_pool2d_with_indices_backward_default_12);  slice_tensor_26 = max_pool2d_with_indices_backward_default_12 = None
        clone_default_18 = torch.ops.aten.clone.default(slice_tensor_25, memory_format = torch.contiguous_format);  slice_tensor_25 = None
        native_batch_norm_backward_default_59 = torch.ops.aten.native_batch_norm_backward.default(clone_default_18, convolution_default_262, primals_938, primals_936, primals_937, getitem_482, getitem_483, True, 0.001, [True, True, True]);  clone_default_18 = convolution_default_262 = primals_938 = primals_936 = primals_937 = getitem_482 = getitem_483 = None
        getitem_1194 = native_batch_norm_backward_default_59[0]
        getitem_1195 = native_batch_norm_backward_default_59[1]
        getitem_1196 = native_batch_norm_backward_default_59[2];  native_batch_norm_backward_default_59 = None
        convolution_backward_default_110 = torch.ops.aten.convolution_backward.default(getitem_1194, convolution_default_261, primals_942, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1194 = convolution_default_261 = primals_942 = None
        getitem_1197 = convolution_backward_default_110[0]
        getitem_1198 = convolution_backward_default_110[1]
        getitem_1199 = convolution_backward_default_110[2];  convolution_backward_default_110 = None
        convolution_backward_default_111 = torch.ops.aten.convolution_backward.default(getitem_1197, relu_default_139, primals_941, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1197 = primals_941 = None
        getitem_1200 = convolution_backward_default_111[0]
        getitem_1201 = convolution_backward_default_111[1]
        getitem_1202 = convolution_backward_default_111[2];  convolution_backward_default_111 = None
        to_dtype_180 = torch.ops.aten.to.dtype(getitem_1200, torch.float32);  getitem_1200 = None
        to_dtype_181 = torch.ops.aten.to.dtype(relu_default_139, torch.float32);  relu_default_139 = None
        le_scalar_60 = torch.ops.aten.le.Scalar(to_dtype_181, 0);  to_dtype_181 = None
        new_zeros_default_261 = torch.ops.aten.new_zeros.default(to_dtype_180, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_60 = torch.ops.aten.where.self(le_scalar_60, new_zeros_default_261, to_dtype_180);  le_scalar_60 = new_zeros_default_261 = to_dtype_180 = None
        to_dtype_182 = torch.ops.aten.to.dtype(where_self_60, torch.float32);  where_self_60 = None
        native_batch_norm_backward_default_60 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_182, convolution_default_260, primals_933, primals_931, primals_932, getitem_479, getitem_480, True, 0.001, [True, True, True]);  to_dtype_182 = convolution_default_260 = primals_933 = primals_931 = primals_932 = getitem_479 = getitem_480 = None
        getitem_1203 = native_batch_norm_backward_default_60[0]
        getitem_1204 = native_batch_norm_backward_default_60[1]
        getitem_1205 = native_batch_norm_backward_default_60[2];  native_batch_norm_backward_default_60 = None
        convolution_backward_default_112 = torch.ops.aten.convolution_backward.default(getitem_1203, convolution_default_259, primals_940, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1203 = convolution_default_259 = primals_940 = None
        getitem_1206 = convolution_backward_default_112[0]
        getitem_1207 = convolution_backward_default_112[1]
        getitem_1208 = convolution_backward_default_112[2];  convolution_backward_default_112 = None
        convolution_backward_default_113 = torch.ops.aten.convolution_backward.default(getitem_1206, relu_default_138, primals_939, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1206 = primals_939 = None
        getitem_1209 = convolution_backward_default_113[0]
        getitem_1210 = convolution_backward_default_113[1]
        getitem_1211 = convolution_backward_default_113[2];  convolution_backward_default_113 = None
        to_dtype_183 = torch.ops.aten.to.dtype(getitem_1209, torch.float32);  getitem_1209 = None
        to_dtype_184 = torch.ops.aten.to.dtype(relu_default_138, torch.float32);  relu_default_138 = None
        le_scalar_61 = torch.ops.aten.le.Scalar(to_dtype_184, 0);  to_dtype_184 = None
        new_zeros_default_262 = torch.ops.aten.new_zeros.default(to_dtype_183, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_61 = torch.ops.aten.where.self(le_scalar_61, new_zeros_default_262, to_dtype_183);  le_scalar_61 = new_zeros_default_262 = to_dtype_183 = None
        to_dtype_185 = torch.ops.aten.to.dtype(where_self_61, torch.float32);  where_self_61 = None
        add_tensor_108 = torch.ops.aten.add.Tensor(slice_tensor_24, to_dtype_185);  slice_tensor_24 = to_dtype_185 = None
        native_batch_norm_backward_default_61 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_108, convolution_default_258, primals_924, primals_922, primals_923, getitem_476, getitem_477, True, 0.001, [True, True, True]);  convolution_default_258 = primals_924 = primals_922 = primals_923 = getitem_476 = getitem_477 = None
        getitem_1212 = native_batch_norm_backward_default_61[0]
        getitem_1213 = native_batch_norm_backward_default_61[1]
        getitem_1214 = native_batch_norm_backward_default_61[2];  native_batch_norm_backward_default_61 = None
        convolution_backward_default_114 = torch.ops.aten.convolution_backward.default(getitem_1212, convolution_default_257, primals_928, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1212 = convolution_default_257 = primals_928 = None
        getitem_1215 = convolution_backward_default_114[0]
        getitem_1216 = convolution_backward_default_114[1]
        getitem_1217 = convolution_backward_default_114[2];  convolution_backward_default_114 = None
        convolution_backward_default_115 = torch.ops.aten.convolution_backward.default(getitem_1215, relu_default_137, primals_927, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1215 = primals_927 = None
        getitem_1218 = convolution_backward_default_115[0]
        getitem_1219 = convolution_backward_default_115[1]
        getitem_1220 = convolution_backward_default_115[2];  convolution_backward_default_115 = None
        to_dtype_186 = torch.ops.aten.to.dtype(getitem_1218, torch.float32);  getitem_1218 = None
        to_dtype_187 = torch.ops.aten.to.dtype(relu_default_137, torch.float32);  relu_default_137 = None
        le_scalar_62 = torch.ops.aten.le.Scalar(to_dtype_187, 0);  to_dtype_187 = None
        new_zeros_default_263 = torch.ops.aten.new_zeros.default(to_dtype_186, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_62 = torch.ops.aten.where.self(le_scalar_62, new_zeros_default_263, to_dtype_186);  le_scalar_62 = new_zeros_default_263 = to_dtype_186 = None
        to_dtype_188 = torch.ops.aten.to.dtype(where_self_62, torch.float32);  where_self_62 = None
        native_batch_norm_backward_default_62 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_188, convolution_default_256, primals_919, primals_917, primals_918, getitem_473, getitem_474, True, 0.001, [True, True, True]);  to_dtype_188 = convolution_default_256 = primals_919 = primals_917 = primals_918 = getitem_473 = getitem_474 = None
        getitem_1221 = native_batch_norm_backward_default_62[0]
        getitem_1222 = native_batch_norm_backward_default_62[1]
        getitem_1223 = native_batch_norm_backward_default_62[2];  native_batch_norm_backward_default_62 = None
        convolution_backward_default_116 = torch.ops.aten.convolution_backward.default(getitem_1221, convolution_default_255, primals_926, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1221 = convolution_default_255 = primals_926 = None
        getitem_1224 = convolution_backward_default_116[0]
        getitem_1225 = convolution_backward_default_116[1]
        getitem_1226 = convolution_backward_default_116[2];  convolution_backward_default_116 = None
        convolution_backward_default_117 = torch.ops.aten.convolution_backward.default(getitem_1224, relu_default_136, primals_925, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1224 = primals_925 = None
        getitem_1227 = convolution_backward_default_117[0]
        getitem_1228 = convolution_backward_default_117[1]
        getitem_1229 = convolution_backward_default_117[2];  convolution_backward_default_117 = None
        to_dtype_189 = torch.ops.aten.to.dtype(getitem_1227, torch.float32);  getitem_1227 = None
        to_dtype_190 = torch.ops.aten.to.dtype(relu_default_136, torch.float32);  relu_default_136 = None
        le_scalar_63 = torch.ops.aten.le.Scalar(to_dtype_190, 0);  to_dtype_190 = None
        new_zeros_default_264 = torch.ops.aten.new_zeros.default(to_dtype_189, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_63 = torch.ops.aten.where.self(le_scalar_63, new_zeros_default_264, to_dtype_189);  le_scalar_63 = new_zeros_default_264 = to_dtype_189 = None
        to_dtype_191 = torch.ops.aten.to.dtype(where_self_63, torch.float32);  where_self_63 = None
        add_tensor_109 = torch.ops.aten.add.Tensor(add_tensor_107, to_dtype_191);  add_tensor_107 = to_dtype_191 = None
        native_batch_norm_backward_default_63 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_108, convolution_default_254, primals_910, primals_908, primals_909, getitem_470, getitem_471, True, 0.001, [True, True, True]);  add_tensor_108 = convolution_default_254 = primals_910 = primals_908 = primals_909 = getitem_470 = getitem_471 = None
        getitem_1230 = native_batch_norm_backward_default_63[0]
        getitem_1231 = native_batch_norm_backward_default_63[1]
        getitem_1232 = native_batch_norm_backward_default_63[2];  native_batch_norm_backward_default_63 = None
        convolution_backward_default_118 = torch.ops.aten.convolution_backward.default(getitem_1230, convolution_default_253, primals_914, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1230 = convolution_default_253 = primals_914 = None
        getitem_1233 = convolution_backward_default_118[0]
        getitem_1234 = convolution_backward_default_118[1]
        getitem_1235 = convolution_backward_default_118[2];  convolution_backward_default_118 = None
        convolution_backward_default_119 = torch.ops.aten.convolution_backward.default(getitem_1233, relu_default_135, primals_913, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1233 = primals_913 = None
        getitem_1236 = convolution_backward_default_119[0]
        getitem_1237 = convolution_backward_default_119[1]
        getitem_1238 = convolution_backward_default_119[2];  convolution_backward_default_119 = None
        to_dtype_192 = torch.ops.aten.to.dtype(getitem_1236, torch.float32);  getitem_1236 = None
        to_dtype_193 = torch.ops.aten.to.dtype(relu_default_135, torch.float32);  relu_default_135 = None
        le_scalar_64 = torch.ops.aten.le.Scalar(to_dtype_193, 0);  to_dtype_193 = None
        new_zeros_default_265 = torch.ops.aten.new_zeros.default(to_dtype_192, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_64 = torch.ops.aten.where.self(le_scalar_64, new_zeros_default_265, to_dtype_192);  le_scalar_64 = new_zeros_default_265 = to_dtype_192 = None
        to_dtype_194 = torch.ops.aten.to.dtype(where_self_64, torch.float32);  where_self_64 = None
        native_batch_norm_backward_default_64 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_194, convolution_default_252, primals_905, primals_903, primals_904, getitem_467, getitem_468, True, 0.001, [True, True, True]);  to_dtype_194 = convolution_default_252 = primals_905 = primals_903 = primals_904 = getitem_467 = getitem_468 = None
        getitem_1239 = native_batch_norm_backward_default_64[0]
        getitem_1240 = native_batch_norm_backward_default_64[1]
        getitem_1241 = native_batch_norm_backward_default_64[2];  native_batch_norm_backward_default_64 = None
        convolution_backward_default_120 = torch.ops.aten.convolution_backward.default(getitem_1239, convolution_default_251, primals_912, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1239 = convolution_default_251 = primals_912 = None
        getitem_1242 = convolution_backward_default_120[0]
        getitem_1243 = convolution_backward_default_120[1]
        getitem_1244 = convolution_backward_default_120[2];  convolution_backward_default_120 = None
        convolution_backward_default_121 = torch.ops.aten.convolution_backward.default(getitem_1242, relu_default_134, primals_911, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1242 = primals_911 = None
        getitem_1245 = convolution_backward_default_121[0]
        getitem_1246 = convolution_backward_default_121[1]
        getitem_1247 = convolution_backward_default_121[2];  convolution_backward_default_121 = None
        to_dtype_195 = torch.ops.aten.to.dtype(getitem_1245, torch.float32);  getitem_1245 = None
        to_dtype_196 = torch.ops.aten.to.dtype(relu_default_134, torch.float32);  relu_default_134 = None
        le_scalar_65 = torch.ops.aten.le.Scalar(to_dtype_196, 0);  to_dtype_196 = None
        new_zeros_default_266 = torch.ops.aten.new_zeros.default(to_dtype_195, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_65 = torch.ops.aten.where.self(le_scalar_65, new_zeros_default_266, to_dtype_195);  le_scalar_65 = new_zeros_default_266 = to_dtype_195 = None
        to_dtype_197 = torch.ops.aten.to.dtype(where_self_65, torch.float32);  where_self_65 = None
        add_tensor_110 = torch.ops.aten.add.Tensor(add_tensor_109, to_dtype_197);  add_tensor_109 = to_dtype_197 = None
        max_pool2d_with_indices_backward_default_13 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_23, getitem_447, [3, 3], [1, 1], [1, 1], [1, 1], False, getitem_465);  getitem_447 = getitem_465 = None
        add_tensor_111 = torch.ops.aten.add.Tensor(add_tensor_110, max_pool2d_with_indices_backward_default_13);  add_tensor_110 = max_pool2d_with_indices_backward_default_13 = None
        clone_default_19 = torch.ops.aten.clone.default(slice_tensor_23, memory_format = torch.contiguous_format);  slice_tensor_23 = None
        native_batch_norm_backward_default_65 = torch.ops.aten.native_batch_norm_backward.default(clone_default_19, convolution_default_250, primals_896, primals_894, primals_895, getitem_462, getitem_463, True, 0.001, [True, True, True]);  clone_default_19 = convolution_default_250 = primals_896 = primals_894 = primals_895 = getitem_462 = getitem_463 = None
        getitem_1248 = native_batch_norm_backward_default_65[0]
        getitem_1249 = native_batch_norm_backward_default_65[1]
        getitem_1250 = native_batch_norm_backward_default_65[2];  native_batch_norm_backward_default_65 = None
        convolution_backward_default_122 = torch.ops.aten.convolution_backward.default(getitem_1248, convolution_default_249, primals_900, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1248 = convolution_default_249 = primals_900 = None
        getitem_1251 = convolution_backward_default_122[0]
        getitem_1252 = convolution_backward_default_122[1]
        getitem_1253 = convolution_backward_default_122[2];  convolution_backward_default_122 = None
        convolution_backward_default_123 = torch.ops.aten.convolution_backward.default(getitem_1251, relu_default_133, primals_899, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1251 = primals_899 = None
        getitem_1254 = convolution_backward_default_123[0]
        getitem_1255 = convolution_backward_default_123[1]
        getitem_1256 = convolution_backward_default_123[2];  convolution_backward_default_123 = None
        to_dtype_198 = torch.ops.aten.to.dtype(getitem_1254, torch.float32);  getitem_1254 = None
        to_dtype_199 = torch.ops.aten.to.dtype(relu_default_133, torch.float32);  relu_default_133 = None
        le_scalar_66 = torch.ops.aten.le.Scalar(to_dtype_199, 0);  to_dtype_199 = None
        new_zeros_default_267 = torch.ops.aten.new_zeros.default(to_dtype_198, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_66 = torch.ops.aten.where.self(le_scalar_66, new_zeros_default_267, to_dtype_198);  le_scalar_66 = new_zeros_default_267 = to_dtype_198 = None
        to_dtype_200 = torch.ops.aten.to.dtype(where_self_66, torch.float32);  where_self_66 = None
        native_batch_norm_backward_default_66 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_200, convolution_default_248, primals_891, primals_889, primals_890, getitem_459, getitem_460, True, 0.001, [True, True, True]);  to_dtype_200 = convolution_default_248 = primals_891 = primals_889 = primals_890 = getitem_459 = getitem_460 = None
        getitem_1257 = native_batch_norm_backward_default_66[0]
        getitem_1258 = native_batch_norm_backward_default_66[1]
        getitem_1259 = native_batch_norm_backward_default_66[2];  native_batch_norm_backward_default_66 = None
        convolution_backward_default_124 = torch.ops.aten.convolution_backward.default(getitem_1257, convolution_default_247, primals_898, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1257 = convolution_default_247 = primals_898 = None
        getitem_1260 = convolution_backward_default_124[0]
        getitem_1261 = convolution_backward_default_124[1]
        getitem_1262 = convolution_backward_default_124[2];  convolution_backward_default_124 = None
        convolution_backward_default_125 = torch.ops.aten.convolution_backward.default(getitem_1260, relu_default_132, primals_897, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1260 = primals_897 = None
        getitem_1263 = convolution_backward_default_125[0]
        getitem_1264 = convolution_backward_default_125[1]
        getitem_1265 = convolution_backward_default_125[2];  convolution_backward_default_125 = None
        to_dtype_201 = torch.ops.aten.to.dtype(getitem_1263, torch.float32);  getitem_1263 = None
        to_dtype_202 = torch.ops.aten.to.dtype(relu_default_132, torch.float32);  relu_default_132 = None
        le_scalar_67 = torch.ops.aten.le.Scalar(to_dtype_202, 0);  to_dtype_202 = None
        new_zeros_default_268 = torch.ops.aten.new_zeros.default(to_dtype_201, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_67 = torch.ops.aten.where.self(le_scalar_67, new_zeros_default_268, to_dtype_201);  le_scalar_67 = new_zeros_default_268 = to_dtype_201 = None
        to_dtype_203 = torch.ops.aten.to.dtype(where_self_67, torch.float32);  where_self_67 = None
        add_tensor_112 = torch.ops.aten.add.Tensor(add_tensor_111, to_dtype_203);  add_tensor_111 = to_dtype_203 = None
        max_pool2d_with_indices_backward_default_14 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_22, getitem_444, [3, 3], [1, 1], [1, 1], [1, 1], False, getitem_457);  getitem_444 = getitem_457 = None
        add_tensor_113 = torch.ops.aten.add.Tensor(to_dtype_179, max_pool2d_with_indices_backward_default_14);  to_dtype_179 = max_pool2d_with_indices_backward_default_14 = None
        clone_default_20 = torch.ops.aten.clone.default(slice_tensor_22, memory_format = torch.contiguous_format);  slice_tensor_22 = None
        native_batch_norm_backward_default_67 = torch.ops.aten.native_batch_norm_backward.default(clone_default_20, convolution_default_246, primals_882, primals_880, primals_881, getitem_454, getitem_455, True, 0.001, [True, True, True]);  clone_default_20 = convolution_default_246 = primals_882 = primals_880 = primals_881 = getitem_454 = getitem_455 = None
        getitem_1266 = native_batch_norm_backward_default_67[0]
        getitem_1267 = native_batch_norm_backward_default_67[1]
        getitem_1268 = native_batch_norm_backward_default_67[2];  native_batch_norm_backward_default_67 = None
        convolution_backward_default_126 = torch.ops.aten.convolution_backward.default(getitem_1266, convolution_default_245, primals_886, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1266 = convolution_default_245 = primals_886 = None
        getitem_1269 = convolution_backward_default_126[0]
        getitem_1270 = convolution_backward_default_126[1]
        getitem_1271 = convolution_backward_default_126[2];  convolution_backward_default_126 = None
        convolution_backward_default_127 = torch.ops.aten.convolution_backward.default(getitem_1269, relu_default_131, primals_885, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1269 = primals_885 = None
        getitem_1272 = convolution_backward_default_127[0]
        getitem_1273 = convolution_backward_default_127[1]
        getitem_1274 = convolution_backward_default_127[2];  convolution_backward_default_127 = None
        to_dtype_204 = torch.ops.aten.to.dtype(getitem_1272, torch.float32);  getitem_1272 = None
        to_dtype_205 = torch.ops.aten.to.dtype(relu_default_131, torch.float32);  relu_default_131 = None
        le_scalar_68 = torch.ops.aten.le.Scalar(to_dtype_205, 0);  to_dtype_205 = None
        new_zeros_default_269 = torch.ops.aten.new_zeros.default(to_dtype_204, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_68 = torch.ops.aten.where.self(le_scalar_68, new_zeros_default_269, to_dtype_204);  le_scalar_68 = new_zeros_default_269 = to_dtype_204 = None
        to_dtype_206 = torch.ops.aten.to.dtype(where_self_68, torch.float32);  where_self_68 = None
        native_batch_norm_backward_default_68 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_206, convolution_default_244, primals_877, primals_875, primals_876, getitem_451, getitem_452, True, 0.001, [True, True, True]);  to_dtype_206 = convolution_default_244 = primals_877 = primals_875 = primals_876 = getitem_451 = getitem_452 = None
        getitem_1275 = native_batch_norm_backward_default_68[0]
        getitem_1276 = native_batch_norm_backward_default_68[1]
        getitem_1277 = native_batch_norm_backward_default_68[2];  native_batch_norm_backward_default_68 = None
        convolution_backward_default_128 = torch.ops.aten.convolution_backward.default(getitem_1275, convolution_default_243, primals_884, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1275 = convolution_default_243 = primals_884 = None
        getitem_1278 = convolution_backward_default_128[0]
        getitem_1279 = convolution_backward_default_128[1]
        getitem_1280 = convolution_backward_default_128[2];  convolution_backward_default_128 = None
        convolution_backward_default_129 = torch.ops.aten.convolution_backward.default(getitem_1278, relu_default_130, primals_883, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1278 = primals_883 = None
        getitem_1281 = convolution_backward_default_129[0]
        getitem_1282 = convolution_backward_default_129[1]
        getitem_1283 = convolution_backward_default_129[2];  convolution_backward_default_129 = None
        to_dtype_207 = torch.ops.aten.to.dtype(getitem_1281, torch.float32);  getitem_1281 = None
        to_dtype_208 = torch.ops.aten.to.dtype(relu_default_130, torch.float32);  relu_default_130 = None
        le_scalar_69 = torch.ops.aten.le.Scalar(to_dtype_208, 0);  to_dtype_208 = None
        new_zeros_default_270 = torch.ops.aten.new_zeros.default(to_dtype_207, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_69 = torch.ops.aten.where.self(le_scalar_69, new_zeros_default_270, to_dtype_207);  le_scalar_69 = new_zeros_default_270 = to_dtype_207 = None
        to_dtype_209 = torch.ops.aten.to.dtype(where_self_69, torch.float32);  where_self_69 = None
        add_tensor_114 = torch.ops.aten.add.Tensor(add_tensor_113, to_dtype_209);  add_tensor_113 = to_dtype_209 = None
        native_batch_norm_backward_default_69 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_112, convolution_default_242, primals_961, primals_959, primals_960, getitem_448, getitem_449, True, 0.001, [True, True, True]);  add_tensor_112 = convolution_default_242 = primals_961 = primals_959 = primals_960 = getitem_448 = getitem_449 = None
        getitem_1284 = native_batch_norm_backward_default_69[0]
        getitem_1285 = native_batch_norm_backward_default_69[1]
        getitem_1286 = native_batch_norm_backward_default_69[2];  native_batch_norm_backward_default_69 = None
        convolution_backward_default_130 = torch.ops.aten.convolution_backward.default(getitem_1284, relu_default_129, primals_962, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1284 = primals_962 = None
        getitem_1287 = convolution_backward_default_130[0]
        getitem_1288 = convolution_backward_default_130[1]
        getitem_1289 = convolution_backward_default_130[2];  convolution_backward_default_130 = None
        to_dtype_210 = torch.ops.aten.to.dtype(getitem_1287, torch.float32);  getitem_1287 = None
        to_dtype_211 = torch.ops.aten.to.dtype(relu_default_129, torch.float32);  relu_default_129 = None
        le_scalar_70 = torch.ops.aten.le.Scalar(to_dtype_211, 0);  to_dtype_211 = None
        new_zeros_default_271 = torch.ops.aten.new_zeros.default(to_dtype_210, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_70 = torch.ops.aten.where.self(le_scalar_70, new_zeros_default_271, to_dtype_210);  le_scalar_70 = new_zeros_default_271 = to_dtype_210 = None
        to_dtype_212 = torch.ops.aten.to.dtype(where_self_70, torch.float32);  where_self_70 = None
        add_tensor_115 = torch.ops.aten.add.Tensor(to_dtype_173, to_dtype_212);  to_dtype_173 = to_dtype_212 = None
        native_batch_norm_backward_default_70 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_114, convolution_default_241, primals_967, primals_965, primals_966, getitem_445, getitem_446, True, 0.001, [True, True, True]);  add_tensor_114 = convolution_default_241 = primals_967 = primals_965 = primals_966 = getitem_445 = getitem_446 = None
        getitem_1290 = native_batch_norm_backward_default_70[0]
        getitem_1291 = native_batch_norm_backward_default_70[1]
        getitem_1292 = native_batch_norm_backward_default_70[2];  native_batch_norm_backward_default_70 = None
        convolution_backward_default_131 = torch.ops.aten.convolution_backward.default(getitem_1290, relu_default_128, primals_968, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1290 = primals_968 = None
        getitem_1293 = convolution_backward_default_131[0]
        getitem_1294 = convolution_backward_default_131[1]
        getitem_1295 = convolution_backward_default_131[2];  convolution_backward_default_131 = None
        to_dtype_213 = torch.ops.aten.to.dtype(getitem_1293, torch.float32);  getitem_1293 = None
        to_dtype_214 = torch.ops.aten.to.dtype(relu_default_128, torch.float32);  relu_default_128 = None
        le_scalar_71 = torch.ops.aten.le.Scalar(to_dtype_214, 0);  to_dtype_214 = None
        new_zeros_default_272 = torch.ops.aten.new_zeros.default(to_dtype_213, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_71 = torch.ops.aten.where.self(le_scalar_71, new_zeros_default_272, to_dtype_213);  le_scalar_71 = new_zeros_default_272 = to_dtype_213 = None
        to_dtype_215 = torch.ops.aten.to.dtype(where_self_71, torch.float32);  where_self_71 = None
        slice_tensor_27 = torch.ops.aten.slice.Tensor(add_tensor_115, 1, 0, 432)
        slice_tensor_28 = torch.ops.aten.slice.Tensor(add_tensor_115, 1, 432, 864)
        slice_tensor_29 = torch.ops.aten.slice.Tensor(add_tensor_115, 1, 864, 1296)
        slice_tensor_30 = torch.ops.aten.slice.Tensor(add_tensor_115, 1, 1296, 1728)
        slice_tensor_31 = torch.ops.aten.slice.Tensor(add_tensor_115, 1, 1728, 2160);  add_tensor_115 = None
        clone_default_21 = torch.ops.aten.clone.default(slice_tensor_31, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_71 = torch.ops.aten.native_batch_norm_backward.default(clone_default_21, convolution_default_240, primals_856, primals_854, primals_855, getitem_442, getitem_443, True, 0.001, [True, True, True]);  clone_default_21 = convolution_default_240 = primals_856 = primals_854 = primals_855 = getitem_442 = getitem_443 = None
        getitem_1296 = native_batch_norm_backward_default_71[0]
        getitem_1297 = native_batch_norm_backward_default_71[1]
        getitem_1298 = native_batch_norm_backward_default_71[2];  native_batch_norm_backward_default_71 = None
        convolution_backward_default_132 = torch.ops.aten.convolution_backward.default(getitem_1296, convolution_default_239, primals_860, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1296 = convolution_default_239 = primals_860 = None
        getitem_1299 = convolution_backward_default_132[0]
        getitem_1300 = convolution_backward_default_132[1]
        getitem_1301 = convolution_backward_default_132[2];  convolution_backward_default_132 = None
        convolution_backward_default_133 = torch.ops.aten.convolution_backward.default(getitem_1299, relu_default_127, primals_859, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1299 = primals_859 = None
        getitem_1302 = convolution_backward_default_133[0]
        getitem_1303 = convolution_backward_default_133[1]
        getitem_1304 = convolution_backward_default_133[2];  convolution_backward_default_133 = None
        to_dtype_216 = torch.ops.aten.to.dtype(getitem_1302, torch.float32);  getitem_1302 = None
        to_dtype_217 = torch.ops.aten.to.dtype(relu_default_127, torch.float32);  relu_default_127 = None
        le_scalar_72 = torch.ops.aten.le.Scalar(to_dtype_217, 0);  to_dtype_217 = None
        new_zeros_default_273 = torch.ops.aten.new_zeros.default(to_dtype_216, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_72 = torch.ops.aten.where.self(le_scalar_72, new_zeros_default_273, to_dtype_216);  le_scalar_72 = new_zeros_default_273 = to_dtype_216 = None
        to_dtype_218 = torch.ops.aten.to.dtype(where_self_72, torch.float32);  where_self_72 = None
        native_batch_norm_backward_default_72 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_218, convolution_default_238, primals_851, primals_849, primals_850, getitem_439, getitem_440, True, 0.001, [True, True, True]);  to_dtype_218 = convolution_default_238 = primals_851 = primals_849 = primals_850 = getitem_439 = getitem_440 = None
        getitem_1305 = native_batch_norm_backward_default_72[0]
        getitem_1306 = native_batch_norm_backward_default_72[1]
        getitem_1307 = native_batch_norm_backward_default_72[2];  native_batch_norm_backward_default_72 = None
        convolution_backward_default_134 = torch.ops.aten.convolution_backward.default(getitem_1305, convolution_default_237, primals_858, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1305 = convolution_default_237 = primals_858 = None
        getitem_1308 = convolution_backward_default_134[0]
        getitem_1309 = convolution_backward_default_134[1]
        getitem_1310 = convolution_backward_default_134[2];  convolution_backward_default_134 = None
        convolution_backward_default_135 = torch.ops.aten.convolution_backward.default(getitem_1308, relu_default_126, primals_857, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1308 = primals_857 = None
        getitem_1311 = convolution_backward_default_135[0]
        getitem_1312 = convolution_backward_default_135[1]
        getitem_1313 = convolution_backward_default_135[2];  convolution_backward_default_135 = None
        to_dtype_219 = torch.ops.aten.to.dtype(getitem_1311, torch.float32);  getitem_1311 = None
        to_dtype_220 = torch.ops.aten.to.dtype(relu_default_126, torch.float32);  relu_default_126 = None
        le_scalar_73 = torch.ops.aten.le.Scalar(to_dtype_220, 0);  to_dtype_220 = None
        new_zeros_default_274 = torch.ops.aten.new_zeros.default(to_dtype_219, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_73 = torch.ops.aten.where.self(le_scalar_73, new_zeros_default_274, to_dtype_219);  le_scalar_73 = new_zeros_default_274 = to_dtype_219 = None
        to_dtype_221 = torch.ops.aten.to.dtype(where_self_73, torch.float32);  where_self_73 = None
        max_pool2d_with_indices_backward_default_15 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_30, getitem_399, [3, 3], [1, 1], [1, 1], [1, 1], False, getitem_437);  getitem_437 = None
        add_tensor_116 = torch.ops.aten.add.Tensor(slice_tensor_31, max_pool2d_with_indices_backward_default_15);  slice_tensor_31 = max_pool2d_with_indices_backward_default_15 = None
        clone_default_22 = torch.ops.aten.clone.default(slice_tensor_30, memory_format = torch.contiguous_format);  slice_tensor_30 = None
        native_batch_norm_backward_default_73 = torch.ops.aten.native_batch_norm_backward.default(clone_default_22, convolution_default_236, primals_842, primals_840, primals_841, getitem_434, getitem_435, True, 0.001, [True, True, True]);  clone_default_22 = convolution_default_236 = primals_842 = primals_840 = primals_841 = getitem_434 = getitem_435 = None
        getitem_1314 = native_batch_norm_backward_default_73[0]
        getitem_1315 = native_batch_norm_backward_default_73[1]
        getitem_1316 = native_batch_norm_backward_default_73[2];  native_batch_norm_backward_default_73 = None
        convolution_backward_default_136 = torch.ops.aten.convolution_backward.default(getitem_1314, convolution_default_235, primals_846, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1314 = convolution_default_235 = primals_846 = None
        getitem_1317 = convolution_backward_default_136[0]
        getitem_1318 = convolution_backward_default_136[1]
        getitem_1319 = convolution_backward_default_136[2];  convolution_backward_default_136 = None
        convolution_backward_default_137 = torch.ops.aten.convolution_backward.default(getitem_1317, relu_default_125, primals_845, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1317 = primals_845 = None
        getitem_1320 = convolution_backward_default_137[0]
        getitem_1321 = convolution_backward_default_137[1]
        getitem_1322 = convolution_backward_default_137[2];  convolution_backward_default_137 = None
        to_dtype_222 = torch.ops.aten.to.dtype(getitem_1320, torch.float32);  getitem_1320 = None
        to_dtype_223 = torch.ops.aten.to.dtype(relu_default_125, torch.float32);  relu_default_125 = None
        le_scalar_74 = torch.ops.aten.le.Scalar(to_dtype_223, 0);  to_dtype_223 = None
        new_zeros_default_275 = torch.ops.aten.new_zeros.default(to_dtype_222, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_74 = torch.ops.aten.where.self(le_scalar_74, new_zeros_default_275, to_dtype_222);  le_scalar_74 = new_zeros_default_275 = to_dtype_222 = None
        to_dtype_224 = torch.ops.aten.to.dtype(where_self_74, torch.float32);  where_self_74 = None
        native_batch_norm_backward_default_74 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_224, convolution_default_234, primals_837, primals_835, primals_836, getitem_431, getitem_432, True, 0.001, [True, True, True]);  to_dtype_224 = convolution_default_234 = primals_837 = primals_835 = primals_836 = getitem_431 = getitem_432 = None
        getitem_1323 = native_batch_norm_backward_default_74[0]
        getitem_1324 = native_batch_norm_backward_default_74[1]
        getitem_1325 = native_batch_norm_backward_default_74[2];  native_batch_norm_backward_default_74 = None
        convolution_backward_default_138 = torch.ops.aten.convolution_backward.default(getitem_1323, convolution_default_233, primals_844, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1323 = convolution_default_233 = primals_844 = None
        getitem_1326 = convolution_backward_default_138[0]
        getitem_1327 = convolution_backward_default_138[1]
        getitem_1328 = convolution_backward_default_138[2];  convolution_backward_default_138 = None
        convolution_backward_default_139 = torch.ops.aten.convolution_backward.default(getitem_1326, relu_default_124, primals_843, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1326 = primals_843 = None
        getitem_1329 = convolution_backward_default_139[0]
        getitem_1330 = convolution_backward_default_139[1]
        getitem_1331 = convolution_backward_default_139[2];  convolution_backward_default_139 = None
        to_dtype_225 = torch.ops.aten.to.dtype(getitem_1329, torch.float32);  getitem_1329 = None
        to_dtype_226 = torch.ops.aten.to.dtype(relu_default_124, torch.float32);  relu_default_124 = None
        le_scalar_75 = torch.ops.aten.le.Scalar(to_dtype_226, 0);  to_dtype_226 = None
        new_zeros_default_276 = torch.ops.aten.new_zeros.default(to_dtype_225, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_75 = torch.ops.aten.where.self(le_scalar_75, new_zeros_default_276, to_dtype_225);  le_scalar_75 = new_zeros_default_276 = to_dtype_225 = None
        to_dtype_227 = torch.ops.aten.to.dtype(where_self_75, torch.float32);  where_self_75 = None
        add_tensor_117 = torch.ops.aten.add.Tensor(slice_tensor_29, to_dtype_227);  slice_tensor_29 = to_dtype_227 = None
        native_batch_norm_backward_default_75 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_117, convolution_default_232, primals_828, primals_826, primals_827, getitem_428, getitem_429, True, 0.001, [True, True, True]);  convolution_default_232 = primals_828 = primals_826 = primals_827 = getitem_428 = getitem_429 = None
        getitem_1332 = native_batch_norm_backward_default_75[0]
        getitem_1333 = native_batch_norm_backward_default_75[1]
        getitem_1334 = native_batch_norm_backward_default_75[2];  native_batch_norm_backward_default_75 = None
        convolution_backward_default_140 = torch.ops.aten.convolution_backward.default(getitem_1332, convolution_default_231, primals_832, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1332 = convolution_default_231 = primals_832 = None
        getitem_1335 = convolution_backward_default_140[0]
        getitem_1336 = convolution_backward_default_140[1]
        getitem_1337 = convolution_backward_default_140[2];  convolution_backward_default_140 = None
        convolution_backward_default_141 = torch.ops.aten.convolution_backward.default(getitem_1335, relu_default_123, primals_831, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1335 = primals_831 = None
        getitem_1338 = convolution_backward_default_141[0]
        getitem_1339 = convolution_backward_default_141[1]
        getitem_1340 = convolution_backward_default_141[2];  convolution_backward_default_141 = None
        to_dtype_228 = torch.ops.aten.to.dtype(getitem_1338, torch.float32);  getitem_1338 = None
        to_dtype_229 = torch.ops.aten.to.dtype(relu_default_123, torch.float32);  relu_default_123 = None
        le_scalar_76 = torch.ops.aten.le.Scalar(to_dtype_229, 0);  to_dtype_229 = None
        new_zeros_default_277 = torch.ops.aten.new_zeros.default(to_dtype_228, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_76 = torch.ops.aten.where.self(le_scalar_76, new_zeros_default_277, to_dtype_228);  le_scalar_76 = new_zeros_default_277 = to_dtype_228 = None
        to_dtype_230 = torch.ops.aten.to.dtype(where_self_76, torch.float32);  where_self_76 = None
        native_batch_norm_backward_default_76 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_230, convolution_default_230, primals_823, primals_821, primals_822, getitem_425, getitem_426, True, 0.001, [True, True, True]);  to_dtype_230 = convolution_default_230 = primals_823 = primals_821 = primals_822 = getitem_425 = getitem_426 = None
        getitem_1341 = native_batch_norm_backward_default_76[0]
        getitem_1342 = native_batch_norm_backward_default_76[1]
        getitem_1343 = native_batch_norm_backward_default_76[2];  native_batch_norm_backward_default_76 = None
        convolution_backward_default_142 = torch.ops.aten.convolution_backward.default(getitem_1341, convolution_default_229, primals_830, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1341 = convolution_default_229 = primals_830 = None
        getitem_1344 = convolution_backward_default_142[0]
        getitem_1345 = convolution_backward_default_142[1]
        getitem_1346 = convolution_backward_default_142[2];  convolution_backward_default_142 = None
        convolution_backward_default_143 = torch.ops.aten.convolution_backward.default(getitem_1344, relu_default_122, primals_829, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1344 = primals_829 = None
        getitem_1347 = convolution_backward_default_143[0]
        getitem_1348 = convolution_backward_default_143[1]
        getitem_1349 = convolution_backward_default_143[2];  convolution_backward_default_143 = None
        to_dtype_231 = torch.ops.aten.to.dtype(getitem_1347, torch.float32);  getitem_1347 = None
        to_dtype_232 = torch.ops.aten.to.dtype(relu_default_122, torch.float32);  relu_default_122 = None
        le_scalar_77 = torch.ops.aten.le.Scalar(to_dtype_232, 0);  to_dtype_232 = None
        new_zeros_default_278 = torch.ops.aten.new_zeros.default(to_dtype_231, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_77 = torch.ops.aten.where.self(le_scalar_77, new_zeros_default_278, to_dtype_231);  le_scalar_77 = new_zeros_default_278 = to_dtype_231 = None
        to_dtype_233 = torch.ops.aten.to.dtype(where_self_77, torch.float32);  where_self_77 = None
        add_tensor_118 = torch.ops.aten.add.Tensor(add_tensor_116, to_dtype_233);  add_tensor_116 = to_dtype_233 = None
        native_batch_norm_backward_default_77 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_117, convolution_default_228, primals_814, primals_812, primals_813, getitem_422, getitem_423, True, 0.001, [True, True, True]);  add_tensor_117 = convolution_default_228 = primals_814 = primals_812 = primals_813 = getitem_422 = getitem_423 = None
        getitem_1350 = native_batch_norm_backward_default_77[0]
        getitem_1351 = native_batch_norm_backward_default_77[1]
        getitem_1352 = native_batch_norm_backward_default_77[2];  native_batch_norm_backward_default_77 = None
        convolution_backward_default_144 = torch.ops.aten.convolution_backward.default(getitem_1350, convolution_default_227, primals_818, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1350 = convolution_default_227 = primals_818 = None
        getitem_1353 = convolution_backward_default_144[0]
        getitem_1354 = convolution_backward_default_144[1]
        getitem_1355 = convolution_backward_default_144[2];  convolution_backward_default_144 = None
        convolution_backward_default_145 = torch.ops.aten.convolution_backward.default(getitem_1353, relu_default_121, primals_817, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1353 = primals_817 = None
        getitem_1356 = convolution_backward_default_145[0]
        getitem_1357 = convolution_backward_default_145[1]
        getitem_1358 = convolution_backward_default_145[2];  convolution_backward_default_145 = None
        to_dtype_234 = torch.ops.aten.to.dtype(getitem_1356, torch.float32);  getitem_1356 = None
        to_dtype_235 = torch.ops.aten.to.dtype(relu_default_121, torch.float32);  relu_default_121 = None
        le_scalar_78 = torch.ops.aten.le.Scalar(to_dtype_235, 0);  to_dtype_235 = None
        new_zeros_default_279 = torch.ops.aten.new_zeros.default(to_dtype_234, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_78 = torch.ops.aten.where.self(le_scalar_78, new_zeros_default_279, to_dtype_234);  le_scalar_78 = new_zeros_default_279 = to_dtype_234 = None
        to_dtype_236 = torch.ops.aten.to.dtype(where_self_78, torch.float32);  where_self_78 = None
        native_batch_norm_backward_default_78 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_236, convolution_default_226, primals_809, primals_807, primals_808, getitem_419, getitem_420, True, 0.001, [True, True, True]);  to_dtype_236 = convolution_default_226 = primals_809 = primals_807 = primals_808 = getitem_419 = getitem_420 = None
        getitem_1359 = native_batch_norm_backward_default_78[0]
        getitem_1360 = native_batch_norm_backward_default_78[1]
        getitem_1361 = native_batch_norm_backward_default_78[2];  native_batch_norm_backward_default_78 = None
        convolution_backward_default_146 = torch.ops.aten.convolution_backward.default(getitem_1359, convolution_default_225, primals_816, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1359 = convolution_default_225 = primals_816 = None
        getitem_1362 = convolution_backward_default_146[0]
        getitem_1363 = convolution_backward_default_146[1]
        getitem_1364 = convolution_backward_default_146[2];  convolution_backward_default_146 = None
        convolution_backward_default_147 = torch.ops.aten.convolution_backward.default(getitem_1362, relu_default_120, primals_815, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1362 = primals_815 = None
        getitem_1365 = convolution_backward_default_147[0]
        getitem_1366 = convolution_backward_default_147[1]
        getitem_1367 = convolution_backward_default_147[2];  convolution_backward_default_147 = None
        to_dtype_237 = torch.ops.aten.to.dtype(getitem_1365, torch.float32);  getitem_1365 = None
        to_dtype_238 = torch.ops.aten.to.dtype(relu_default_120, torch.float32);  relu_default_120 = None
        le_scalar_79 = torch.ops.aten.le.Scalar(to_dtype_238, 0);  to_dtype_238 = None
        new_zeros_default_280 = torch.ops.aten.new_zeros.default(to_dtype_237, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_79 = torch.ops.aten.where.self(le_scalar_79, new_zeros_default_280, to_dtype_237);  le_scalar_79 = new_zeros_default_280 = to_dtype_237 = None
        to_dtype_239 = torch.ops.aten.to.dtype(where_self_79, torch.float32);  where_self_79 = None
        add_tensor_119 = torch.ops.aten.add.Tensor(add_tensor_118, to_dtype_239);  add_tensor_118 = to_dtype_239 = None
        max_pool2d_with_indices_backward_default_16 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_28, getitem_399, [3, 3], [1, 1], [1, 1], [1, 1], False, getitem_417);  getitem_399 = getitem_417 = None
        add_tensor_120 = torch.ops.aten.add.Tensor(add_tensor_119, max_pool2d_with_indices_backward_default_16);  add_tensor_119 = max_pool2d_with_indices_backward_default_16 = None
        clone_default_23 = torch.ops.aten.clone.default(slice_tensor_28, memory_format = torch.contiguous_format);  slice_tensor_28 = None
        native_batch_norm_backward_default_79 = torch.ops.aten.native_batch_norm_backward.default(clone_default_23, convolution_default_224, primals_800, primals_798, primals_799, getitem_414, getitem_415, True, 0.001, [True, True, True]);  clone_default_23 = convolution_default_224 = primals_800 = primals_798 = primals_799 = getitem_414 = getitem_415 = None
        getitem_1368 = native_batch_norm_backward_default_79[0]
        getitem_1369 = native_batch_norm_backward_default_79[1]
        getitem_1370 = native_batch_norm_backward_default_79[2];  native_batch_norm_backward_default_79 = None
        convolution_backward_default_148 = torch.ops.aten.convolution_backward.default(getitem_1368, convolution_default_223, primals_804, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1368 = convolution_default_223 = primals_804 = None
        getitem_1371 = convolution_backward_default_148[0]
        getitem_1372 = convolution_backward_default_148[1]
        getitem_1373 = convolution_backward_default_148[2];  convolution_backward_default_148 = None
        convolution_backward_default_149 = torch.ops.aten.convolution_backward.default(getitem_1371, relu_default_119, primals_803, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1371 = primals_803 = None
        getitem_1374 = convolution_backward_default_149[0]
        getitem_1375 = convolution_backward_default_149[1]
        getitem_1376 = convolution_backward_default_149[2];  convolution_backward_default_149 = None
        to_dtype_240 = torch.ops.aten.to.dtype(getitem_1374, torch.float32);  getitem_1374 = None
        to_dtype_241 = torch.ops.aten.to.dtype(relu_default_119, torch.float32);  relu_default_119 = None
        le_scalar_80 = torch.ops.aten.le.Scalar(to_dtype_241, 0);  to_dtype_241 = None
        new_zeros_default_281 = torch.ops.aten.new_zeros.default(to_dtype_240, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_80 = torch.ops.aten.where.self(le_scalar_80, new_zeros_default_281, to_dtype_240);  le_scalar_80 = new_zeros_default_281 = to_dtype_240 = None
        to_dtype_242 = torch.ops.aten.to.dtype(where_self_80, torch.float32);  where_self_80 = None
        native_batch_norm_backward_default_80 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_242, convolution_default_222, primals_795, primals_793, primals_794, getitem_411, getitem_412, True, 0.001, [True, True, True]);  to_dtype_242 = convolution_default_222 = primals_795 = primals_793 = primals_794 = getitem_411 = getitem_412 = None
        getitem_1377 = native_batch_norm_backward_default_80[0]
        getitem_1378 = native_batch_norm_backward_default_80[1]
        getitem_1379 = native_batch_norm_backward_default_80[2];  native_batch_norm_backward_default_80 = None
        convolution_backward_default_150 = torch.ops.aten.convolution_backward.default(getitem_1377, convolution_default_221, primals_802, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1377 = convolution_default_221 = primals_802 = None
        getitem_1380 = convolution_backward_default_150[0]
        getitem_1381 = convolution_backward_default_150[1]
        getitem_1382 = convolution_backward_default_150[2];  convolution_backward_default_150 = None
        convolution_backward_default_151 = torch.ops.aten.convolution_backward.default(getitem_1380, relu_default_118, primals_801, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1380 = primals_801 = None
        getitem_1383 = convolution_backward_default_151[0]
        getitem_1384 = convolution_backward_default_151[1]
        getitem_1385 = convolution_backward_default_151[2];  convolution_backward_default_151 = None
        to_dtype_243 = torch.ops.aten.to.dtype(getitem_1383, torch.float32);  getitem_1383 = None
        to_dtype_244 = torch.ops.aten.to.dtype(relu_default_118, torch.float32);  relu_default_118 = None
        le_scalar_81 = torch.ops.aten.le.Scalar(to_dtype_244, 0);  to_dtype_244 = None
        new_zeros_default_282 = torch.ops.aten.new_zeros.default(to_dtype_243, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_81 = torch.ops.aten.where.self(le_scalar_81, new_zeros_default_282, to_dtype_243);  le_scalar_81 = new_zeros_default_282 = to_dtype_243 = None
        to_dtype_245 = torch.ops.aten.to.dtype(where_self_81, torch.float32);  where_self_81 = None
        add_tensor_121 = torch.ops.aten.add.Tensor(add_tensor_120, to_dtype_245);  add_tensor_120 = to_dtype_245 = None
        max_pool2d_with_indices_backward_default_17 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_27, getitem_396, [3, 3], [1, 1], [1, 1], [1, 1], False, getitem_409);  getitem_396 = getitem_409 = None
        add_tensor_122 = torch.ops.aten.add.Tensor(to_dtype_221, max_pool2d_with_indices_backward_default_17);  to_dtype_221 = max_pool2d_with_indices_backward_default_17 = None
        clone_default_24 = torch.ops.aten.clone.default(slice_tensor_27, memory_format = torch.contiguous_format);  slice_tensor_27 = None
        native_batch_norm_backward_default_81 = torch.ops.aten.native_batch_norm_backward.default(clone_default_24, convolution_default_220, primals_786, primals_784, primals_785, getitem_406, getitem_407, True, 0.001, [True, True, True]);  clone_default_24 = convolution_default_220 = primals_786 = primals_784 = primals_785 = getitem_406 = getitem_407 = None
        getitem_1386 = native_batch_norm_backward_default_81[0]
        getitem_1387 = native_batch_norm_backward_default_81[1]
        getitem_1388 = native_batch_norm_backward_default_81[2];  native_batch_norm_backward_default_81 = None
        convolution_backward_default_152 = torch.ops.aten.convolution_backward.default(getitem_1386, convolution_default_219, primals_790, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1386 = convolution_default_219 = primals_790 = None
        getitem_1389 = convolution_backward_default_152[0]
        getitem_1390 = convolution_backward_default_152[1]
        getitem_1391 = convolution_backward_default_152[2];  convolution_backward_default_152 = None
        convolution_backward_default_153 = torch.ops.aten.convolution_backward.default(getitem_1389, relu_default_117, primals_789, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1389 = primals_789 = None
        getitem_1392 = convolution_backward_default_153[0]
        getitem_1393 = convolution_backward_default_153[1]
        getitem_1394 = convolution_backward_default_153[2];  convolution_backward_default_153 = None
        to_dtype_246 = torch.ops.aten.to.dtype(getitem_1392, torch.float32);  getitem_1392 = None
        to_dtype_247 = torch.ops.aten.to.dtype(relu_default_117, torch.float32);  relu_default_117 = None
        le_scalar_82 = torch.ops.aten.le.Scalar(to_dtype_247, 0);  to_dtype_247 = None
        new_zeros_default_283 = torch.ops.aten.new_zeros.default(to_dtype_246, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_82 = torch.ops.aten.where.self(le_scalar_82, new_zeros_default_283, to_dtype_246);  le_scalar_82 = new_zeros_default_283 = to_dtype_246 = None
        to_dtype_248 = torch.ops.aten.to.dtype(where_self_82, torch.float32);  where_self_82 = None
        native_batch_norm_backward_default_82 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_248, convolution_default_218, primals_781, primals_779, primals_780, getitem_403, getitem_404, True, 0.001, [True, True, True]);  to_dtype_248 = convolution_default_218 = primals_781 = primals_779 = primals_780 = getitem_403 = getitem_404 = None
        getitem_1395 = native_batch_norm_backward_default_82[0]
        getitem_1396 = native_batch_norm_backward_default_82[1]
        getitem_1397 = native_batch_norm_backward_default_82[2];  native_batch_norm_backward_default_82 = None
        convolution_backward_default_154 = torch.ops.aten.convolution_backward.default(getitem_1395, convolution_default_217, primals_788, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1395 = convolution_default_217 = primals_788 = None
        getitem_1398 = convolution_backward_default_154[0]
        getitem_1399 = convolution_backward_default_154[1]
        getitem_1400 = convolution_backward_default_154[2];  convolution_backward_default_154 = None
        convolution_backward_default_155 = torch.ops.aten.convolution_backward.default(getitem_1398, relu_default_116, primals_787, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1398 = primals_787 = None
        getitem_1401 = convolution_backward_default_155[0]
        getitem_1402 = convolution_backward_default_155[1]
        getitem_1403 = convolution_backward_default_155[2];  convolution_backward_default_155 = None
        to_dtype_249 = torch.ops.aten.to.dtype(getitem_1401, torch.float32);  getitem_1401 = None
        to_dtype_250 = torch.ops.aten.to.dtype(relu_default_116, torch.float32);  relu_default_116 = None
        le_scalar_83 = torch.ops.aten.le.Scalar(to_dtype_250, 0);  to_dtype_250 = None
        new_zeros_default_284 = torch.ops.aten.new_zeros.default(to_dtype_249, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_83 = torch.ops.aten.where.self(le_scalar_83, new_zeros_default_284, to_dtype_249);  le_scalar_83 = new_zeros_default_284 = to_dtype_249 = None
        to_dtype_251 = torch.ops.aten.to.dtype(where_self_83, torch.float32);  where_self_83 = None
        add_tensor_123 = torch.ops.aten.add.Tensor(add_tensor_122, to_dtype_251);  add_tensor_122 = to_dtype_251 = None
        native_batch_norm_backward_default_83 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_121, convolution_default_216, primals_865, primals_863, primals_864, getitem_400, getitem_401, True, 0.001, [True, True, True]);  add_tensor_121 = convolution_default_216 = primals_865 = primals_863 = primals_864 = getitem_400 = getitem_401 = None
        getitem_1404 = native_batch_norm_backward_default_83[0]
        getitem_1405 = native_batch_norm_backward_default_83[1]
        getitem_1406 = native_batch_norm_backward_default_83[2];  native_batch_norm_backward_default_83 = None
        convolution_backward_default_156 = torch.ops.aten.convolution_backward.default(getitem_1404, relu_default_115, primals_866, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1404 = primals_866 = None
        getitem_1407 = convolution_backward_default_156[0]
        getitem_1408 = convolution_backward_default_156[1]
        getitem_1409 = convolution_backward_default_156[2];  convolution_backward_default_156 = None
        to_dtype_252 = torch.ops.aten.to.dtype(getitem_1407, torch.float32);  getitem_1407 = None
        to_dtype_253 = torch.ops.aten.to.dtype(relu_default_115, torch.float32);  relu_default_115 = None
        le_scalar_84 = torch.ops.aten.le.Scalar(to_dtype_253, 0);  to_dtype_253 = None
        new_zeros_default_285 = torch.ops.aten.new_zeros.default(to_dtype_252, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_84 = torch.ops.aten.where.self(le_scalar_84, new_zeros_default_285, to_dtype_252);  le_scalar_84 = new_zeros_default_285 = to_dtype_252 = None
        to_dtype_254 = torch.ops.aten.to.dtype(where_self_84, torch.float32);  where_self_84 = None
        add_tensor_124 = torch.ops.aten.add.Tensor(to_dtype_215, to_dtype_254);  to_dtype_215 = to_dtype_254 = None
        native_batch_norm_backward_default_84 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_123, convolution_default_215, primals_871, primals_869, primals_870, getitem_397, getitem_398, True, 0.001, [True, True, True]);  add_tensor_123 = convolution_default_215 = primals_871 = primals_869 = primals_870 = getitem_397 = getitem_398 = None
        getitem_1410 = native_batch_norm_backward_default_84[0]
        getitem_1411 = native_batch_norm_backward_default_84[1]
        getitem_1412 = native_batch_norm_backward_default_84[2];  native_batch_norm_backward_default_84 = None
        convolution_backward_default_157 = torch.ops.aten.convolution_backward.default(getitem_1410, relu_default_114, primals_872, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1410 = primals_872 = None
        getitem_1413 = convolution_backward_default_157[0]
        getitem_1414 = convolution_backward_default_157[1]
        getitem_1415 = convolution_backward_default_157[2];  convolution_backward_default_157 = None
        to_dtype_255 = torch.ops.aten.to.dtype(getitem_1413, torch.float32);  getitem_1413 = None
        to_dtype_256 = torch.ops.aten.to.dtype(relu_default_114, torch.float32);  relu_default_114 = None
        le_scalar_85 = torch.ops.aten.le.Scalar(to_dtype_256, 0);  to_dtype_256 = None
        new_zeros_default_286 = torch.ops.aten.new_zeros.default(to_dtype_255, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_85 = torch.ops.aten.where.self(le_scalar_85, new_zeros_default_286, to_dtype_255);  le_scalar_85 = new_zeros_default_286 = to_dtype_255 = None
        to_dtype_257 = torch.ops.aten.to.dtype(where_self_85, torch.float32);  where_self_85 = None
        slice_tensor_32 = torch.ops.aten.slice.Tensor(add_tensor_124, 1, 0, 432)
        slice_tensor_33 = torch.ops.aten.slice.Tensor(add_tensor_124, 1, 432, 864)
        slice_tensor_34 = torch.ops.aten.slice.Tensor(add_tensor_124, 1, 864, 1296)
        slice_tensor_35 = torch.ops.aten.slice.Tensor(add_tensor_124, 1, 1296, 1728)
        slice_tensor_36 = torch.ops.aten.slice.Tensor(add_tensor_124, 1, 1728, 2160);  add_tensor_124 = None
        clone_default_25 = torch.ops.aten.clone.default(slice_tensor_36, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_85 = torch.ops.aten.native_batch_norm_backward.default(clone_default_25, convolution_default_214, primals_759, primals_757, primals_758, getitem_394, getitem_395, True, 0.001, [True, True, True]);  clone_default_25 = convolution_default_214 = primals_759 = primals_757 = primals_758 = getitem_394 = getitem_395 = None
        getitem_1416 = native_batch_norm_backward_default_85[0]
        getitem_1417 = native_batch_norm_backward_default_85[1]
        getitem_1418 = native_batch_norm_backward_default_85[2];  native_batch_norm_backward_default_85 = None
        convolution_backward_default_158 = torch.ops.aten.convolution_backward.default(getitem_1416, convolution_default_213, primals_763, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1416 = convolution_default_213 = primals_763 = None
        getitem_1419 = convolution_backward_default_158[0]
        getitem_1420 = convolution_backward_default_158[1]
        getitem_1421 = convolution_backward_default_158[2];  convolution_backward_default_158 = None
        convolution_backward_default_159 = torch.ops.aten.convolution_backward.default(getitem_1419, relu_default_113, primals_762, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1419 = primals_762 = None
        getitem_1422 = convolution_backward_default_159[0]
        getitem_1423 = convolution_backward_default_159[1]
        getitem_1424 = convolution_backward_default_159[2];  convolution_backward_default_159 = None
        to_dtype_258 = torch.ops.aten.to.dtype(getitem_1422, torch.float32);  getitem_1422 = None
        to_dtype_259 = torch.ops.aten.to.dtype(relu_default_113, torch.float32);  relu_default_113 = None
        le_scalar_86 = torch.ops.aten.le.Scalar(to_dtype_259, 0);  to_dtype_259 = None
        new_zeros_default_287 = torch.ops.aten.new_zeros.default(to_dtype_258, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_86 = torch.ops.aten.where.self(le_scalar_86, new_zeros_default_287, to_dtype_258);  le_scalar_86 = new_zeros_default_287 = to_dtype_258 = None
        to_dtype_260 = torch.ops.aten.to.dtype(where_self_86, torch.float32);  where_self_86 = None
        native_batch_norm_backward_default_86 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_260, convolution_default_212, primals_754, primals_752, primals_753, getitem_391, getitem_392, True, 0.001, [True, True, True]);  to_dtype_260 = convolution_default_212 = primals_754 = primals_752 = primals_753 = getitem_391 = getitem_392 = None
        getitem_1425 = native_batch_norm_backward_default_86[0]
        getitem_1426 = native_batch_norm_backward_default_86[1]
        getitem_1427 = native_batch_norm_backward_default_86[2];  native_batch_norm_backward_default_86 = None
        convolution_backward_default_160 = torch.ops.aten.convolution_backward.default(getitem_1425, convolution_default_211, primals_761, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1425 = convolution_default_211 = primals_761 = None
        getitem_1428 = convolution_backward_default_160[0]
        getitem_1429 = convolution_backward_default_160[1]
        getitem_1430 = convolution_backward_default_160[2];  convolution_backward_default_160 = None
        convolution_backward_default_161 = torch.ops.aten.convolution_backward.default(getitem_1428, relu_default_112, primals_760, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1428 = primals_760 = None
        getitem_1431 = convolution_backward_default_161[0]
        getitem_1432 = convolution_backward_default_161[1]
        getitem_1433 = convolution_backward_default_161[2];  convolution_backward_default_161 = None
        to_dtype_261 = torch.ops.aten.to.dtype(getitem_1431, torch.float32);  getitem_1431 = None
        to_dtype_262 = torch.ops.aten.to.dtype(relu_default_112, torch.float32);  relu_default_112 = None
        le_scalar_87 = torch.ops.aten.le.Scalar(to_dtype_262, 0);  to_dtype_262 = None
        new_zeros_default_288 = torch.ops.aten.new_zeros.default(to_dtype_261, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_87 = torch.ops.aten.where.self(le_scalar_87, new_zeros_default_288, to_dtype_261);  le_scalar_87 = new_zeros_default_288 = to_dtype_261 = None
        to_dtype_263 = torch.ops.aten.to.dtype(where_self_87, torch.float32);  where_self_87 = None
        max_pool2d_with_indices_backward_default_18 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_35, getitem_351, [3, 3], [1, 1], [1, 1], [1, 1], False, getitem_389);  getitem_389 = None
        add_tensor_125 = torch.ops.aten.add.Tensor(slice_tensor_36, max_pool2d_with_indices_backward_default_18);  slice_tensor_36 = max_pool2d_with_indices_backward_default_18 = None
        clone_default_26 = torch.ops.aten.clone.default(slice_tensor_35, memory_format = torch.contiguous_format);  slice_tensor_35 = None
        native_batch_norm_backward_default_87 = torch.ops.aten.native_batch_norm_backward.default(clone_default_26, convolution_default_210, primals_745, primals_743, primals_744, getitem_386, getitem_387, True, 0.001, [True, True, True]);  clone_default_26 = convolution_default_210 = primals_745 = primals_743 = primals_744 = getitem_386 = getitem_387 = None
        getitem_1434 = native_batch_norm_backward_default_87[0]
        getitem_1435 = native_batch_norm_backward_default_87[1]
        getitem_1436 = native_batch_norm_backward_default_87[2];  native_batch_norm_backward_default_87 = None
        convolution_backward_default_162 = torch.ops.aten.convolution_backward.default(getitem_1434, convolution_default_209, primals_749, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1434 = convolution_default_209 = primals_749 = None
        getitem_1437 = convolution_backward_default_162[0]
        getitem_1438 = convolution_backward_default_162[1]
        getitem_1439 = convolution_backward_default_162[2];  convolution_backward_default_162 = None
        convolution_backward_default_163 = torch.ops.aten.convolution_backward.default(getitem_1437, relu_default_111, primals_748, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1437 = primals_748 = None
        getitem_1440 = convolution_backward_default_163[0]
        getitem_1441 = convolution_backward_default_163[1]
        getitem_1442 = convolution_backward_default_163[2];  convolution_backward_default_163 = None
        to_dtype_264 = torch.ops.aten.to.dtype(getitem_1440, torch.float32);  getitem_1440 = None
        to_dtype_265 = torch.ops.aten.to.dtype(relu_default_111, torch.float32);  relu_default_111 = None
        le_scalar_88 = torch.ops.aten.le.Scalar(to_dtype_265, 0);  to_dtype_265 = None
        new_zeros_default_289 = torch.ops.aten.new_zeros.default(to_dtype_264, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_88 = torch.ops.aten.where.self(le_scalar_88, new_zeros_default_289, to_dtype_264);  le_scalar_88 = new_zeros_default_289 = to_dtype_264 = None
        to_dtype_266 = torch.ops.aten.to.dtype(where_self_88, torch.float32);  where_self_88 = None
        native_batch_norm_backward_default_88 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_266, convolution_default_208, primals_740, primals_738, primals_739, getitem_383, getitem_384, True, 0.001, [True, True, True]);  to_dtype_266 = convolution_default_208 = primals_740 = primals_738 = primals_739 = getitem_383 = getitem_384 = None
        getitem_1443 = native_batch_norm_backward_default_88[0]
        getitem_1444 = native_batch_norm_backward_default_88[1]
        getitem_1445 = native_batch_norm_backward_default_88[2];  native_batch_norm_backward_default_88 = None
        convolution_backward_default_164 = torch.ops.aten.convolution_backward.default(getitem_1443, convolution_default_207, primals_747, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1443 = convolution_default_207 = primals_747 = None
        getitem_1446 = convolution_backward_default_164[0]
        getitem_1447 = convolution_backward_default_164[1]
        getitem_1448 = convolution_backward_default_164[2];  convolution_backward_default_164 = None
        convolution_backward_default_165 = torch.ops.aten.convolution_backward.default(getitem_1446, relu_default_110, primals_746, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1446 = primals_746 = None
        getitem_1449 = convolution_backward_default_165[0]
        getitem_1450 = convolution_backward_default_165[1]
        getitem_1451 = convolution_backward_default_165[2];  convolution_backward_default_165 = None
        to_dtype_267 = torch.ops.aten.to.dtype(getitem_1449, torch.float32);  getitem_1449 = None
        to_dtype_268 = torch.ops.aten.to.dtype(relu_default_110, torch.float32);  relu_default_110 = None
        le_scalar_89 = torch.ops.aten.le.Scalar(to_dtype_268, 0);  to_dtype_268 = None
        new_zeros_default_290 = torch.ops.aten.new_zeros.default(to_dtype_267, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_89 = torch.ops.aten.where.self(le_scalar_89, new_zeros_default_290, to_dtype_267);  le_scalar_89 = new_zeros_default_290 = to_dtype_267 = None
        to_dtype_269 = torch.ops.aten.to.dtype(where_self_89, torch.float32);  where_self_89 = None
        add_tensor_126 = torch.ops.aten.add.Tensor(slice_tensor_34, to_dtype_269);  slice_tensor_34 = to_dtype_269 = None
        native_batch_norm_backward_default_89 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_126, convolution_default_206, primals_731, primals_729, primals_730, getitem_380, getitem_381, True, 0.001, [True, True, True]);  convolution_default_206 = primals_731 = primals_729 = primals_730 = getitem_380 = getitem_381 = None
        getitem_1452 = native_batch_norm_backward_default_89[0]
        getitem_1453 = native_batch_norm_backward_default_89[1]
        getitem_1454 = native_batch_norm_backward_default_89[2];  native_batch_norm_backward_default_89 = None
        convolution_backward_default_166 = torch.ops.aten.convolution_backward.default(getitem_1452, convolution_default_205, primals_735, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1452 = convolution_default_205 = primals_735 = None
        getitem_1455 = convolution_backward_default_166[0]
        getitem_1456 = convolution_backward_default_166[1]
        getitem_1457 = convolution_backward_default_166[2];  convolution_backward_default_166 = None
        convolution_backward_default_167 = torch.ops.aten.convolution_backward.default(getitem_1455, relu_default_109, primals_734, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1455 = primals_734 = None
        getitem_1458 = convolution_backward_default_167[0]
        getitem_1459 = convolution_backward_default_167[1]
        getitem_1460 = convolution_backward_default_167[2];  convolution_backward_default_167 = None
        to_dtype_270 = torch.ops.aten.to.dtype(getitem_1458, torch.float32);  getitem_1458 = None
        to_dtype_271 = torch.ops.aten.to.dtype(relu_default_109, torch.float32);  relu_default_109 = None
        le_scalar_90 = torch.ops.aten.le.Scalar(to_dtype_271, 0);  to_dtype_271 = None
        new_zeros_default_291 = torch.ops.aten.new_zeros.default(to_dtype_270, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_90 = torch.ops.aten.where.self(le_scalar_90, new_zeros_default_291, to_dtype_270);  le_scalar_90 = new_zeros_default_291 = to_dtype_270 = None
        to_dtype_272 = torch.ops.aten.to.dtype(where_self_90, torch.float32);  where_self_90 = None
        native_batch_norm_backward_default_90 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_272, convolution_default_204, primals_726, primals_724, primals_725, getitem_377, getitem_378, True, 0.001, [True, True, True]);  to_dtype_272 = convolution_default_204 = primals_726 = primals_724 = primals_725 = getitem_377 = getitem_378 = None
        getitem_1461 = native_batch_norm_backward_default_90[0]
        getitem_1462 = native_batch_norm_backward_default_90[1]
        getitem_1463 = native_batch_norm_backward_default_90[2];  native_batch_norm_backward_default_90 = None
        convolution_backward_default_168 = torch.ops.aten.convolution_backward.default(getitem_1461, convolution_default_203, primals_733, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1461 = convolution_default_203 = primals_733 = None
        getitem_1464 = convolution_backward_default_168[0]
        getitem_1465 = convolution_backward_default_168[1]
        getitem_1466 = convolution_backward_default_168[2];  convolution_backward_default_168 = None
        convolution_backward_default_169 = torch.ops.aten.convolution_backward.default(getitem_1464, relu_default_108, primals_732, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1464 = primals_732 = None
        getitem_1467 = convolution_backward_default_169[0]
        getitem_1468 = convolution_backward_default_169[1]
        getitem_1469 = convolution_backward_default_169[2];  convolution_backward_default_169 = None
        to_dtype_273 = torch.ops.aten.to.dtype(getitem_1467, torch.float32);  getitem_1467 = None
        to_dtype_274 = torch.ops.aten.to.dtype(relu_default_108, torch.float32);  relu_default_108 = None
        le_scalar_91 = torch.ops.aten.le.Scalar(to_dtype_274, 0);  to_dtype_274 = None
        new_zeros_default_292 = torch.ops.aten.new_zeros.default(to_dtype_273, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_91 = torch.ops.aten.where.self(le_scalar_91, new_zeros_default_292, to_dtype_273);  le_scalar_91 = new_zeros_default_292 = to_dtype_273 = None
        to_dtype_275 = torch.ops.aten.to.dtype(where_self_91, torch.float32);  where_self_91 = None
        add_tensor_127 = torch.ops.aten.add.Tensor(add_tensor_125, to_dtype_275);  add_tensor_125 = to_dtype_275 = None
        native_batch_norm_backward_default_91 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_126, convolution_default_202, primals_717, primals_715, primals_716, getitem_374, getitem_375, True, 0.001, [True, True, True]);  add_tensor_126 = convolution_default_202 = primals_717 = primals_715 = primals_716 = getitem_374 = getitem_375 = None
        getitem_1470 = native_batch_norm_backward_default_91[0]
        getitem_1471 = native_batch_norm_backward_default_91[1]
        getitem_1472 = native_batch_norm_backward_default_91[2];  native_batch_norm_backward_default_91 = None
        convolution_backward_default_170 = torch.ops.aten.convolution_backward.default(getitem_1470, convolution_default_201, primals_721, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1470 = convolution_default_201 = primals_721 = None
        getitem_1473 = convolution_backward_default_170[0]
        getitem_1474 = convolution_backward_default_170[1]
        getitem_1475 = convolution_backward_default_170[2];  convolution_backward_default_170 = None
        convolution_backward_default_171 = torch.ops.aten.convolution_backward.default(getitem_1473, relu_default_107, primals_720, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1473 = primals_720 = None
        getitem_1476 = convolution_backward_default_171[0]
        getitem_1477 = convolution_backward_default_171[1]
        getitem_1478 = convolution_backward_default_171[2];  convolution_backward_default_171 = None
        to_dtype_276 = torch.ops.aten.to.dtype(getitem_1476, torch.float32);  getitem_1476 = None
        to_dtype_277 = torch.ops.aten.to.dtype(relu_default_107, torch.float32);  relu_default_107 = None
        le_scalar_92 = torch.ops.aten.le.Scalar(to_dtype_277, 0);  to_dtype_277 = None
        new_zeros_default_293 = torch.ops.aten.new_zeros.default(to_dtype_276, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_92 = torch.ops.aten.where.self(le_scalar_92, new_zeros_default_293, to_dtype_276);  le_scalar_92 = new_zeros_default_293 = to_dtype_276 = None
        to_dtype_278 = torch.ops.aten.to.dtype(where_self_92, torch.float32);  where_self_92 = None
        native_batch_norm_backward_default_92 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_278, convolution_default_200, primals_712, primals_710, primals_711, getitem_371, getitem_372, True, 0.001, [True, True, True]);  to_dtype_278 = convolution_default_200 = primals_712 = primals_710 = primals_711 = getitem_371 = getitem_372 = None
        getitem_1479 = native_batch_norm_backward_default_92[0]
        getitem_1480 = native_batch_norm_backward_default_92[1]
        getitem_1481 = native_batch_norm_backward_default_92[2];  native_batch_norm_backward_default_92 = None
        convolution_backward_default_172 = torch.ops.aten.convolution_backward.default(getitem_1479, convolution_default_199, primals_719, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1479 = convolution_default_199 = primals_719 = None
        getitem_1482 = convolution_backward_default_172[0]
        getitem_1483 = convolution_backward_default_172[1]
        getitem_1484 = convolution_backward_default_172[2];  convolution_backward_default_172 = None
        convolution_backward_default_173 = torch.ops.aten.convolution_backward.default(getitem_1482, relu_default_106, primals_718, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1482 = primals_718 = None
        getitem_1485 = convolution_backward_default_173[0]
        getitem_1486 = convolution_backward_default_173[1]
        getitem_1487 = convolution_backward_default_173[2];  convolution_backward_default_173 = None
        to_dtype_279 = torch.ops.aten.to.dtype(getitem_1485, torch.float32);  getitem_1485 = None
        to_dtype_280 = torch.ops.aten.to.dtype(relu_default_106, torch.float32);  relu_default_106 = None
        le_scalar_93 = torch.ops.aten.le.Scalar(to_dtype_280, 0);  to_dtype_280 = None
        new_zeros_default_294 = torch.ops.aten.new_zeros.default(to_dtype_279, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_93 = torch.ops.aten.where.self(le_scalar_93, new_zeros_default_294, to_dtype_279);  le_scalar_93 = new_zeros_default_294 = to_dtype_279 = None
        to_dtype_281 = torch.ops.aten.to.dtype(where_self_93, torch.float32);  where_self_93 = None
        add_tensor_128 = torch.ops.aten.add.Tensor(add_tensor_127, to_dtype_281);  add_tensor_127 = to_dtype_281 = None
        max_pool2d_with_indices_backward_default_19 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_33, getitem_351, [3, 3], [1, 1], [1, 1], [1, 1], False, getitem_369);  getitem_351 = getitem_369 = None
        add_tensor_129 = torch.ops.aten.add.Tensor(add_tensor_128, max_pool2d_with_indices_backward_default_19);  add_tensor_128 = max_pool2d_with_indices_backward_default_19 = None
        clone_default_27 = torch.ops.aten.clone.default(slice_tensor_33, memory_format = torch.contiguous_format);  slice_tensor_33 = None
        native_batch_norm_backward_default_93 = torch.ops.aten.native_batch_norm_backward.default(clone_default_27, convolution_default_198, primals_703, primals_701, primals_702, getitem_366, getitem_367, True, 0.001, [True, True, True]);  clone_default_27 = convolution_default_198 = primals_703 = primals_701 = primals_702 = getitem_366 = getitem_367 = None
        getitem_1488 = native_batch_norm_backward_default_93[0]
        getitem_1489 = native_batch_norm_backward_default_93[1]
        getitem_1490 = native_batch_norm_backward_default_93[2];  native_batch_norm_backward_default_93 = None
        convolution_backward_default_174 = torch.ops.aten.convolution_backward.default(getitem_1488, convolution_default_197, primals_707, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1488 = convolution_default_197 = primals_707 = None
        getitem_1491 = convolution_backward_default_174[0]
        getitem_1492 = convolution_backward_default_174[1]
        getitem_1493 = convolution_backward_default_174[2];  convolution_backward_default_174 = None
        convolution_backward_default_175 = torch.ops.aten.convolution_backward.default(getitem_1491, relu_default_105, primals_706, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1491 = primals_706 = None
        getitem_1494 = convolution_backward_default_175[0]
        getitem_1495 = convolution_backward_default_175[1]
        getitem_1496 = convolution_backward_default_175[2];  convolution_backward_default_175 = None
        to_dtype_282 = torch.ops.aten.to.dtype(getitem_1494, torch.float32);  getitem_1494 = None
        to_dtype_283 = torch.ops.aten.to.dtype(relu_default_105, torch.float32);  relu_default_105 = None
        le_scalar_94 = torch.ops.aten.le.Scalar(to_dtype_283, 0);  to_dtype_283 = None
        new_zeros_default_295 = torch.ops.aten.new_zeros.default(to_dtype_282, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_94 = torch.ops.aten.where.self(le_scalar_94, new_zeros_default_295, to_dtype_282);  le_scalar_94 = new_zeros_default_295 = to_dtype_282 = None
        to_dtype_284 = torch.ops.aten.to.dtype(where_self_94, torch.float32);  where_self_94 = None
        native_batch_norm_backward_default_94 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_284, convolution_default_196, primals_698, primals_696, primals_697, getitem_363, getitem_364, True, 0.001, [True, True, True]);  to_dtype_284 = convolution_default_196 = primals_698 = primals_696 = primals_697 = getitem_363 = getitem_364 = None
        getitem_1497 = native_batch_norm_backward_default_94[0]
        getitem_1498 = native_batch_norm_backward_default_94[1]
        getitem_1499 = native_batch_norm_backward_default_94[2];  native_batch_norm_backward_default_94 = None
        convolution_backward_default_176 = torch.ops.aten.convolution_backward.default(getitem_1497, convolution_default_195, primals_705, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1497 = convolution_default_195 = primals_705 = None
        getitem_1500 = convolution_backward_default_176[0]
        getitem_1501 = convolution_backward_default_176[1]
        getitem_1502 = convolution_backward_default_176[2];  convolution_backward_default_176 = None
        convolution_backward_default_177 = torch.ops.aten.convolution_backward.default(getitem_1500, relu_default_104, primals_704, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1500 = primals_704 = None
        getitem_1503 = convolution_backward_default_177[0]
        getitem_1504 = convolution_backward_default_177[1]
        getitem_1505 = convolution_backward_default_177[2];  convolution_backward_default_177 = None
        to_dtype_285 = torch.ops.aten.to.dtype(getitem_1503, torch.float32);  getitem_1503 = None
        to_dtype_286 = torch.ops.aten.to.dtype(relu_default_104, torch.float32);  relu_default_104 = None
        le_scalar_95 = torch.ops.aten.le.Scalar(to_dtype_286, 0);  to_dtype_286 = None
        new_zeros_default_296 = torch.ops.aten.new_zeros.default(to_dtype_285, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_95 = torch.ops.aten.where.self(le_scalar_95, new_zeros_default_296, to_dtype_285);  le_scalar_95 = new_zeros_default_296 = to_dtype_285 = None
        to_dtype_287 = torch.ops.aten.to.dtype(where_self_95, torch.float32);  where_self_95 = None
        add_tensor_130 = torch.ops.aten.add.Tensor(add_tensor_129, to_dtype_287);  add_tensor_129 = to_dtype_287 = None
        max_pool2d_with_indices_backward_default_20 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_32, getitem_348, [3, 3], [1, 1], [1, 1], [1, 1], False, getitem_361);  getitem_348 = getitem_361 = None
        add_tensor_131 = torch.ops.aten.add.Tensor(to_dtype_263, max_pool2d_with_indices_backward_default_20);  to_dtype_263 = max_pool2d_with_indices_backward_default_20 = None
        clone_default_28 = torch.ops.aten.clone.default(slice_tensor_32, memory_format = torch.contiguous_format);  slice_tensor_32 = None
        native_batch_norm_backward_default_95 = torch.ops.aten.native_batch_norm_backward.default(clone_default_28, convolution_default_194, primals_689, primals_687, primals_688, getitem_358, getitem_359, True, 0.001, [True, True, True]);  clone_default_28 = convolution_default_194 = primals_689 = primals_687 = primals_688 = getitem_358 = getitem_359 = None
        getitem_1506 = native_batch_norm_backward_default_95[0]
        getitem_1507 = native_batch_norm_backward_default_95[1]
        getitem_1508 = native_batch_norm_backward_default_95[2];  native_batch_norm_backward_default_95 = None
        convolution_backward_default_178 = torch.ops.aten.convolution_backward.default(getitem_1506, convolution_default_193, primals_693, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1506 = convolution_default_193 = primals_693 = None
        getitem_1509 = convolution_backward_default_178[0]
        getitem_1510 = convolution_backward_default_178[1]
        getitem_1511 = convolution_backward_default_178[2];  convolution_backward_default_178 = None
        convolution_backward_default_179 = torch.ops.aten.convolution_backward.default(getitem_1509, relu_default_103, primals_692, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1509 = primals_692 = None
        getitem_1512 = convolution_backward_default_179[0]
        getitem_1513 = convolution_backward_default_179[1]
        getitem_1514 = convolution_backward_default_179[2];  convolution_backward_default_179 = None
        to_dtype_288 = torch.ops.aten.to.dtype(getitem_1512, torch.float32);  getitem_1512 = None
        to_dtype_289 = torch.ops.aten.to.dtype(relu_default_103, torch.float32);  relu_default_103 = None
        le_scalar_96 = torch.ops.aten.le.Scalar(to_dtype_289, 0);  to_dtype_289 = None
        new_zeros_default_297 = torch.ops.aten.new_zeros.default(to_dtype_288, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_96 = torch.ops.aten.where.self(le_scalar_96, new_zeros_default_297, to_dtype_288);  le_scalar_96 = new_zeros_default_297 = to_dtype_288 = None
        to_dtype_290 = torch.ops.aten.to.dtype(where_self_96, torch.float32);  where_self_96 = None
        native_batch_norm_backward_default_96 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_290, convolution_default_192, primals_684, primals_682, primals_683, getitem_355, getitem_356, True, 0.001, [True, True, True]);  to_dtype_290 = convolution_default_192 = primals_684 = primals_682 = primals_683 = getitem_355 = getitem_356 = None
        getitem_1515 = native_batch_norm_backward_default_96[0]
        getitem_1516 = native_batch_norm_backward_default_96[1]
        getitem_1517 = native_batch_norm_backward_default_96[2];  native_batch_norm_backward_default_96 = None
        convolution_backward_default_180 = torch.ops.aten.convolution_backward.default(getitem_1515, convolution_default_191, primals_691, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1515 = convolution_default_191 = primals_691 = None
        getitem_1518 = convolution_backward_default_180[0]
        getitem_1519 = convolution_backward_default_180[1]
        getitem_1520 = convolution_backward_default_180[2];  convolution_backward_default_180 = None
        convolution_backward_default_181 = torch.ops.aten.convolution_backward.default(getitem_1518, relu_default_102, primals_690, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1518 = primals_690 = None
        getitem_1521 = convolution_backward_default_181[0]
        getitem_1522 = convolution_backward_default_181[1]
        getitem_1523 = convolution_backward_default_181[2];  convolution_backward_default_181 = None
        to_dtype_291 = torch.ops.aten.to.dtype(getitem_1521, torch.float32);  getitem_1521 = None
        to_dtype_292 = torch.ops.aten.to.dtype(relu_default_102, torch.float32);  relu_default_102 = None
        le_scalar_97 = torch.ops.aten.le.Scalar(to_dtype_292, 0);  to_dtype_292 = None
        new_zeros_default_298 = torch.ops.aten.new_zeros.default(to_dtype_291, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_97 = torch.ops.aten.where.self(le_scalar_97, new_zeros_default_298, to_dtype_291);  le_scalar_97 = new_zeros_default_298 = to_dtype_291 = None
        to_dtype_293 = torch.ops.aten.to.dtype(where_self_97, torch.float32);  where_self_97 = None
        add_tensor_132 = torch.ops.aten.add.Tensor(add_tensor_131, to_dtype_293);  add_tensor_131 = to_dtype_293 = None
        native_batch_norm_backward_default_97 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_130, convolution_default_190, primals_768, primals_766, primals_767, getitem_352, getitem_353, True, 0.001, [True, True, True]);  add_tensor_130 = convolution_default_190 = primals_768 = primals_766 = primals_767 = getitem_352 = getitem_353 = None
        getitem_1524 = native_batch_norm_backward_default_97[0]
        getitem_1525 = native_batch_norm_backward_default_97[1]
        getitem_1526 = native_batch_norm_backward_default_97[2];  native_batch_norm_backward_default_97 = None
        convolution_backward_default_182 = torch.ops.aten.convolution_backward.default(getitem_1524, relu_default_101, primals_769, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1524 = primals_769 = None
        getitem_1527 = convolution_backward_default_182[0]
        getitem_1528 = convolution_backward_default_182[1]
        getitem_1529 = convolution_backward_default_182[2];  convolution_backward_default_182 = None
        to_dtype_294 = torch.ops.aten.to.dtype(getitem_1527, torch.float32);  getitem_1527 = None
        to_dtype_295 = torch.ops.aten.to.dtype(relu_default_101, torch.float32);  relu_default_101 = None
        le_scalar_98 = torch.ops.aten.le.Scalar(to_dtype_295, 0);  to_dtype_295 = None
        new_zeros_default_299 = torch.ops.aten.new_zeros.default(to_dtype_294, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_98 = torch.ops.aten.where.self(le_scalar_98, new_zeros_default_299, to_dtype_294);  le_scalar_98 = new_zeros_default_299 = to_dtype_294 = None
        to_dtype_296 = torch.ops.aten.to.dtype(where_self_98, torch.float32);  where_self_98 = None
        add_tensor_133 = torch.ops.aten.add.Tensor(to_dtype_257, to_dtype_296);  to_dtype_257 = to_dtype_296 = None
        native_batch_norm_backward_default_98 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_132, cat_default_9, primals_774, primals_772, primals_773, getitem_349, getitem_350, True, 0.001, [True, True, True]);  add_tensor_132 = cat_default_9 = primals_774 = primals_772 = primals_773 = getitem_349 = getitem_350 = None
        getitem_1530 = native_batch_norm_backward_default_98[0]
        getitem_1531 = native_batch_norm_backward_default_98[1]
        getitem_1532 = native_batch_norm_backward_default_98[2];  native_batch_norm_backward_default_98 = None
        slice_tensor_37 = torch.ops.aten.slice.Tensor(getitem_1530, 1, 0, 216)
        slice_tensor_38 = torch.ops.aten.slice.Tensor(getitem_1530, 1, 216, 432);  getitem_1530 = None
        convolution_backward_default_183 = torch.ops.aten.convolution_backward.default(slice_tensor_38, avg_pool2d_default_5, primals_776, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_38 = avg_pool2d_default_5 = primals_776 = None
        getitem_1533 = convolution_backward_default_183[0]
        getitem_1534 = convolution_backward_default_183[1]
        getitem_1535 = convolution_backward_default_183[2];  convolution_backward_default_183 = None
        avg_pool2d_backward_default_2 = torch.ops.aten.avg_pool2d_backward.default(getitem_1533, constant_pad_nd_default_26, [1, 1], [2, 2], [0, 0], False, False, None);  getitem_1533 = constant_pad_nd_default_26 = None
        constant_pad_nd_default_45 = torch.ops.aten.constant_pad_nd.default(avg_pool2d_backward_default_2, [1, -1, 1, -1]);  avg_pool2d_backward_default_2 = None
        convolution_backward_default_184 = torch.ops.aten.convolution_backward.default(slice_tensor_37, avg_pool2d_default_4, primals_775, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_37 = avg_pool2d_default_4 = primals_775 = None
        getitem_1536 = convolution_backward_default_184[0]
        getitem_1537 = convolution_backward_default_184[1]
        getitem_1538 = convolution_backward_default_184[2];  convolution_backward_default_184 = None
        avg_pool2d_backward_default_3 = torch.ops.aten.avg_pool2d_backward.default(getitem_1536, relu_default_100, [1, 1], [2, 2], [0, 0], False, False, None);  getitem_1536 = None
        add_tensor_134 = torch.ops.aten.add.Tensor(constant_pad_nd_default_45, avg_pool2d_backward_default_3);  constant_pad_nd_default_45 = avg_pool2d_backward_default_3 = None
        to_dtype_297 = torch.ops.aten.to.dtype(add_tensor_134, torch.float32);  add_tensor_134 = None
        to_dtype_298 = torch.ops.aten.to.dtype(relu_default_100, torch.float32);  relu_default_100 = None
        le_scalar_99 = torch.ops.aten.le.Scalar(to_dtype_298, 0);  to_dtype_298 = None
        new_zeros_default_300 = torch.ops.aten.new_zeros.default(to_dtype_297, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_99 = torch.ops.aten.where.self(le_scalar_99, new_zeros_default_300, to_dtype_297);  le_scalar_99 = new_zeros_default_300 = to_dtype_297 = None
        to_dtype_299 = torch.ops.aten.to.dtype(where_self_99, torch.float32);  where_self_99 = None
        slice_tensor_39 = torch.ops.aten.slice.Tensor(add_tensor_133, 1, 0, 432)
        slice_tensor_40 = torch.ops.aten.slice.Tensor(add_tensor_133, 1, 432, 864)
        slice_tensor_41 = torch.ops.aten.slice.Tensor(add_tensor_133, 1, 864, 1296)
        slice_tensor_42 = torch.ops.aten.slice.Tensor(add_tensor_133, 1, 1296, 1728)
        slice_tensor_43 = torch.ops.aten.slice.Tensor(add_tensor_133, 1, 1728, 2160);  add_tensor_133 = None
        clone_default_29 = torch.ops.aten.clone.default(slice_tensor_43, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_99 = torch.ops.aten.native_batch_norm_backward.default(clone_default_29, convolution_default_187, primals_666, primals_664, primals_665, getitem_346, getitem_347, True, 0.001, [True, True, True]);  clone_default_29 = convolution_default_187 = primals_666 = primals_664 = primals_665 = getitem_346 = getitem_347 = None
        getitem_1539 = native_batch_norm_backward_default_99[0]
        getitem_1540 = native_batch_norm_backward_default_99[1]
        getitem_1541 = native_batch_norm_backward_default_99[2];  native_batch_norm_backward_default_99 = None
        convolution_backward_default_185 = torch.ops.aten.convolution_backward.default(getitem_1539, relu_default_99, primals_667, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1539 = primals_667 = None
        getitem_1542 = convolution_backward_default_185[0]
        getitem_1543 = convolution_backward_default_185[1]
        getitem_1544 = convolution_backward_default_185[2];  convolution_backward_default_185 = None
        to_dtype_300 = torch.ops.aten.to.dtype(getitem_1542, torch.float32);  getitem_1542 = None
        to_dtype_301 = torch.ops.aten.to.dtype(relu_default_99, torch.float32);  relu_default_99 = None
        le_scalar_100 = torch.ops.aten.le.Scalar(to_dtype_301, 0);  to_dtype_301 = None
        new_zeros_default_301 = torch.ops.aten.new_zeros.default(to_dtype_300, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_100 = torch.ops.aten.where.self(le_scalar_100, new_zeros_default_301, to_dtype_300);  le_scalar_100 = new_zeros_default_301 = to_dtype_300 = None
        to_dtype_302 = torch.ops.aten.to.dtype(where_self_100, torch.float32);  where_self_100 = None
        clone_default_30 = torch.ops.aten.clone.default(slice_tensor_43, memory_format = torch.contiguous_format);  slice_tensor_43 = None
        native_batch_norm_backward_default_100 = torch.ops.aten.native_batch_norm_backward.default(clone_default_30, convolution_default_186, primals_657, primals_655, primals_656, getitem_343, getitem_344, True, 0.001, [True, True, True]);  clone_default_30 = convolution_default_186 = primals_657 = primals_655 = primals_656 = getitem_343 = getitem_344 = None
        getitem_1545 = native_batch_norm_backward_default_100[0]
        getitem_1546 = native_batch_norm_backward_default_100[1]
        getitem_1547 = native_batch_norm_backward_default_100[2];  native_batch_norm_backward_default_100 = None
        convolution_backward_default_186 = torch.ops.aten.convolution_backward.default(getitem_1545, convolution_default_185, primals_661, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1545 = convolution_default_185 = primals_661 = None
        getitem_1548 = convolution_backward_default_186[0]
        getitem_1549 = convolution_backward_default_186[1]
        getitem_1550 = convolution_backward_default_186[2];  convolution_backward_default_186 = None
        convolution_backward_default_187 = torch.ops.aten.convolution_backward.default(getitem_1548, relu_default_98, primals_660, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1548 = primals_660 = None
        getitem_1551 = convolution_backward_default_187[0]
        getitem_1552 = convolution_backward_default_187[1]
        getitem_1553 = convolution_backward_default_187[2];  convolution_backward_default_187 = None
        to_dtype_303 = torch.ops.aten.to.dtype(getitem_1551, torch.float32);  getitem_1551 = None
        to_dtype_304 = torch.ops.aten.to.dtype(relu_default_98, torch.float32);  relu_default_98 = None
        le_scalar_101 = torch.ops.aten.le.Scalar(to_dtype_304, 0);  to_dtype_304 = None
        new_zeros_default_302 = torch.ops.aten.new_zeros.default(to_dtype_303, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_101 = torch.ops.aten.where.self(le_scalar_101, new_zeros_default_302, to_dtype_303);  le_scalar_101 = new_zeros_default_302 = to_dtype_303 = None
        to_dtype_305 = torch.ops.aten.to.dtype(where_self_101, torch.float32);  where_self_101 = None
        native_batch_norm_backward_default_101 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_305, convolution_default_184, primals_652, primals_650, primals_651, getitem_340, getitem_341, True, 0.001, [True, True, True]);  to_dtype_305 = convolution_default_184 = primals_652 = primals_650 = primals_651 = getitem_340 = getitem_341 = None
        getitem_1554 = native_batch_norm_backward_default_101[0]
        getitem_1555 = native_batch_norm_backward_default_101[1]
        getitem_1556 = native_batch_norm_backward_default_101[2];  native_batch_norm_backward_default_101 = None
        convolution_backward_default_188 = torch.ops.aten.convolution_backward.default(getitem_1554, convolution_default_183, primals_659, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1554 = convolution_default_183 = primals_659 = None
        getitem_1557 = convolution_backward_default_188[0]
        getitem_1558 = convolution_backward_default_188[1]
        getitem_1559 = convolution_backward_default_188[2];  convolution_backward_default_188 = None
        convolution_backward_default_189 = torch.ops.aten.convolution_backward.default(getitem_1557, constant_pad_nd_default_25, primals_658, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1557 = constant_pad_nd_default_25 = primals_658 = None
        getitem_1560 = convolution_backward_default_189[0]
        getitem_1561 = convolution_backward_default_189[1]
        getitem_1562 = convolution_backward_default_189[2];  convolution_backward_default_189 = None
        constant_pad_nd_default_46 = torch.ops.aten.constant_pad_nd.default(getitem_1560, [0, -1, 0, -1]);  getitem_1560 = None
        to_dtype_306 = torch.ops.aten.to.dtype(constant_pad_nd_default_46, torch.float32);  constant_pad_nd_default_46 = None
        to_dtype_307 = torch.ops.aten.to.dtype(relu_default_97, torch.float32);  relu_default_97 = None
        le_scalar_102 = torch.ops.aten.le.Scalar(to_dtype_307, 0);  to_dtype_307 = None
        new_zeros_default_303 = torch.ops.aten.new_zeros.default(to_dtype_306, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_102 = torch.ops.aten.where.self(le_scalar_102, new_zeros_default_303, to_dtype_306);  le_scalar_102 = new_zeros_default_303 = to_dtype_306 = None
        to_dtype_308 = torch.ops.aten.to.dtype(where_self_102, torch.float32);  where_self_102 = None
        max_pool2d_with_indices_backward_default_21 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_42, constant_pad_nd_default_24, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_338);  constant_pad_nd_default_24 = getitem_338 = None
        constant_pad_nd_default_47 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default_21, [0, -1, 0, -1]);  max_pool2d_with_indices_backward_default_21 = None
        add_tensor_135 = torch.ops.aten.add.Tensor(to_dtype_302, constant_pad_nd_default_47);  to_dtype_302 = constant_pad_nd_default_47 = None
        clone_default_31 = torch.ops.aten.clone.default(slice_tensor_42, memory_format = torch.contiguous_format);  slice_tensor_42 = None
        native_batch_norm_backward_default_102 = torch.ops.aten.native_batch_norm_backward.default(clone_default_31, convolution_default_182, primals_643, primals_641, primals_642, getitem_335, getitem_336, True, 0.001, [True, True, True]);  clone_default_31 = convolution_default_182 = primals_643 = primals_641 = primals_642 = getitem_335 = getitem_336 = None
        getitem_1563 = native_batch_norm_backward_default_102[0]
        getitem_1564 = native_batch_norm_backward_default_102[1]
        getitem_1565 = native_batch_norm_backward_default_102[2];  native_batch_norm_backward_default_102 = None
        convolution_backward_default_190 = torch.ops.aten.convolution_backward.default(getitem_1563, convolution_default_181, primals_647, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1563 = convolution_default_181 = primals_647 = None
        getitem_1566 = convolution_backward_default_190[0]
        getitem_1567 = convolution_backward_default_190[1]
        getitem_1568 = convolution_backward_default_190[2];  convolution_backward_default_190 = None
        convolution_backward_default_191 = torch.ops.aten.convolution_backward.default(getitem_1566, relu_default_96, primals_646, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1566 = primals_646 = None
        getitem_1569 = convolution_backward_default_191[0]
        getitem_1570 = convolution_backward_default_191[1]
        getitem_1571 = convolution_backward_default_191[2];  convolution_backward_default_191 = None
        to_dtype_309 = torch.ops.aten.to.dtype(getitem_1569, torch.float32);  getitem_1569 = None
        to_dtype_310 = torch.ops.aten.to.dtype(relu_default_96, torch.float32);  relu_default_96 = None
        le_scalar_103 = torch.ops.aten.le.Scalar(to_dtype_310, 0);  to_dtype_310 = None
        new_zeros_default_304 = torch.ops.aten.new_zeros.default(to_dtype_309, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_103 = torch.ops.aten.where.self(le_scalar_103, new_zeros_default_304, to_dtype_309);  le_scalar_103 = new_zeros_default_304 = to_dtype_309 = None
        to_dtype_311 = torch.ops.aten.to.dtype(where_self_103, torch.float32);  where_self_103 = None
        native_batch_norm_backward_default_103 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_311, convolution_default_180, primals_638, primals_636, primals_637, getitem_332, getitem_333, True, 0.001, [True, True, True]);  to_dtype_311 = convolution_default_180 = primals_638 = primals_636 = primals_637 = getitem_332 = getitem_333 = None
        getitem_1572 = native_batch_norm_backward_default_103[0]
        getitem_1573 = native_batch_norm_backward_default_103[1]
        getitem_1574 = native_batch_norm_backward_default_103[2];  native_batch_norm_backward_default_103 = None
        convolution_backward_default_192 = torch.ops.aten.convolution_backward.default(getitem_1572, convolution_default_179, primals_645, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1572 = convolution_default_179 = primals_645 = None
        getitem_1575 = convolution_backward_default_192[0]
        getitem_1576 = convolution_backward_default_192[1]
        getitem_1577 = convolution_backward_default_192[2];  convolution_backward_default_192 = None
        convolution_backward_default_193 = torch.ops.aten.convolution_backward.default(getitem_1575, relu_default_95, primals_644, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1575 = primals_644 = None
        getitem_1578 = convolution_backward_default_193[0]
        getitem_1579 = convolution_backward_default_193[1]
        getitem_1580 = convolution_backward_default_193[2];  convolution_backward_default_193 = None
        to_dtype_312 = torch.ops.aten.to.dtype(getitem_1578, torch.float32);  getitem_1578 = None
        to_dtype_313 = torch.ops.aten.to.dtype(relu_default_95, torch.float32);  relu_default_95 = None
        le_scalar_104 = torch.ops.aten.le.Scalar(to_dtype_313, 0);  to_dtype_313 = None
        new_zeros_default_305 = torch.ops.aten.new_zeros.default(to_dtype_312, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_104 = torch.ops.aten.where.self(le_scalar_104, new_zeros_default_305, to_dtype_312);  le_scalar_104 = new_zeros_default_305 = to_dtype_312 = None
        to_dtype_314 = torch.ops.aten.to.dtype(where_self_104, torch.float32);  where_self_104 = None
        add_tensor_136 = torch.ops.aten.add.Tensor(slice_tensor_41, to_dtype_314);  slice_tensor_41 = to_dtype_314 = None
        native_batch_norm_backward_default_104 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_136, convolution_default_178, primals_629, primals_627, primals_628, getitem_329, getitem_330, True, 0.001, [True, True, True]);  convolution_default_178 = primals_629 = primals_627 = primals_628 = getitem_329 = getitem_330 = None
        getitem_1581 = native_batch_norm_backward_default_104[0]
        getitem_1582 = native_batch_norm_backward_default_104[1]
        getitem_1583 = native_batch_norm_backward_default_104[2];  native_batch_norm_backward_default_104 = None
        convolution_backward_default_194 = torch.ops.aten.convolution_backward.default(getitem_1581, convolution_default_177, primals_633, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1581 = convolution_default_177 = primals_633 = None
        getitem_1584 = convolution_backward_default_194[0]
        getitem_1585 = convolution_backward_default_194[1]
        getitem_1586 = convolution_backward_default_194[2];  convolution_backward_default_194 = None
        convolution_backward_default_195 = torch.ops.aten.convolution_backward.default(getitem_1584, relu_default_94, primals_632, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1584 = primals_632 = None
        getitem_1587 = convolution_backward_default_195[0]
        getitem_1588 = convolution_backward_default_195[1]
        getitem_1589 = convolution_backward_default_195[2];  convolution_backward_default_195 = None
        to_dtype_315 = torch.ops.aten.to.dtype(getitem_1587, torch.float32);  getitem_1587 = None
        to_dtype_316 = torch.ops.aten.to.dtype(relu_default_94, torch.float32);  relu_default_94 = None
        le_scalar_105 = torch.ops.aten.le.Scalar(to_dtype_316, 0);  to_dtype_316 = None
        new_zeros_default_306 = torch.ops.aten.new_zeros.default(to_dtype_315, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_105 = torch.ops.aten.where.self(le_scalar_105, new_zeros_default_306, to_dtype_315);  le_scalar_105 = new_zeros_default_306 = to_dtype_315 = None
        to_dtype_317 = torch.ops.aten.to.dtype(where_self_105, torch.float32);  where_self_105 = None
        native_batch_norm_backward_default_105 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_317, convolution_default_176, primals_624, primals_622, primals_623, getitem_326, getitem_327, True, 0.001, [True, True, True]);  to_dtype_317 = convolution_default_176 = primals_624 = primals_622 = primals_623 = getitem_326 = getitem_327 = None
        getitem_1590 = native_batch_norm_backward_default_105[0]
        getitem_1591 = native_batch_norm_backward_default_105[1]
        getitem_1592 = native_batch_norm_backward_default_105[2];  native_batch_norm_backward_default_105 = None
        convolution_backward_default_196 = torch.ops.aten.convolution_backward.default(getitem_1590, convolution_default_175, primals_631, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1590 = convolution_default_175 = primals_631 = None
        getitem_1593 = convolution_backward_default_196[0]
        getitem_1594 = convolution_backward_default_196[1]
        getitem_1595 = convolution_backward_default_196[2];  convolution_backward_default_196 = None
        convolution_backward_default_197 = torch.ops.aten.convolution_backward.default(getitem_1593, constant_pad_nd_default_23, primals_630, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1593 = constant_pad_nd_default_23 = primals_630 = None
        getitem_1596 = convolution_backward_default_197[0]
        getitem_1597 = convolution_backward_default_197[1]
        getitem_1598 = convolution_backward_default_197[2];  convolution_backward_default_197 = None
        constant_pad_nd_default_48 = torch.ops.aten.constant_pad_nd.default(getitem_1596, [0, -1, 0, -1]);  getitem_1596 = None
        to_dtype_318 = torch.ops.aten.to.dtype(constant_pad_nd_default_48, torch.float32);  constant_pad_nd_default_48 = None
        to_dtype_319 = torch.ops.aten.to.dtype(relu_default_93, torch.float32);  relu_default_93 = None
        le_scalar_106 = torch.ops.aten.le.Scalar(to_dtype_319, 0);  to_dtype_319 = None
        new_zeros_default_307 = torch.ops.aten.new_zeros.default(to_dtype_318, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_106 = torch.ops.aten.where.self(le_scalar_106, new_zeros_default_307, to_dtype_318);  le_scalar_106 = new_zeros_default_307 = to_dtype_318 = None
        to_dtype_320 = torch.ops.aten.to.dtype(where_self_106, torch.float32);  where_self_106 = None
        add_tensor_137 = torch.ops.aten.add.Tensor(add_tensor_135, to_dtype_320);  add_tensor_135 = to_dtype_320 = None
        native_batch_norm_backward_default_106 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_136, convolution_default_174, primals_615, primals_613, primals_614, getitem_323, getitem_324, True, 0.001, [True, True, True]);  add_tensor_136 = convolution_default_174 = primals_615 = primals_613 = primals_614 = getitem_323 = getitem_324 = None
        getitem_1599 = native_batch_norm_backward_default_106[0]
        getitem_1600 = native_batch_norm_backward_default_106[1]
        getitem_1601 = native_batch_norm_backward_default_106[2];  native_batch_norm_backward_default_106 = None
        convolution_backward_default_198 = torch.ops.aten.convolution_backward.default(getitem_1599, convolution_default_173, primals_619, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1599 = convolution_default_173 = primals_619 = None
        getitem_1602 = convolution_backward_default_198[0]
        getitem_1603 = convolution_backward_default_198[1]
        getitem_1604 = convolution_backward_default_198[2];  convolution_backward_default_198 = None
        convolution_backward_default_199 = torch.ops.aten.convolution_backward.default(getitem_1602, relu_default_92, primals_618, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1602 = primals_618 = None
        getitem_1605 = convolution_backward_default_199[0]
        getitem_1606 = convolution_backward_default_199[1]
        getitem_1607 = convolution_backward_default_199[2];  convolution_backward_default_199 = None
        to_dtype_321 = torch.ops.aten.to.dtype(getitem_1605, torch.float32);  getitem_1605 = None
        to_dtype_322 = torch.ops.aten.to.dtype(relu_default_92, torch.float32);  relu_default_92 = None
        le_scalar_107 = torch.ops.aten.le.Scalar(to_dtype_322, 0);  to_dtype_322 = None
        new_zeros_default_308 = torch.ops.aten.new_zeros.default(to_dtype_321, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_107 = torch.ops.aten.where.self(le_scalar_107, new_zeros_default_308, to_dtype_321);  le_scalar_107 = new_zeros_default_308 = to_dtype_321 = None
        to_dtype_323 = torch.ops.aten.to.dtype(where_self_107, torch.float32);  where_self_107 = None
        native_batch_norm_backward_default_107 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_323, convolution_default_172, primals_610, primals_608, primals_609, getitem_320, getitem_321, True, 0.001, [True, True, True]);  to_dtype_323 = convolution_default_172 = primals_610 = primals_608 = primals_609 = getitem_320 = getitem_321 = None
        getitem_1608 = native_batch_norm_backward_default_107[0]
        getitem_1609 = native_batch_norm_backward_default_107[1]
        getitem_1610 = native_batch_norm_backward_default_107[2];  native_batch_norm_backward_default_107 = None
        convolution_backward_default_200 = torch.ops.aten.convolution_backward.default(getitem_1608, convolution_default_171, primals_617, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1608 = convolution_default_171 = primals_617 = None
        getitem_1611 = convolution_backward_default_200[0]
        getitem_1612 = convolution_backward_default_200[1]
        getitem_1613 = convolution_backward_default_200[2];  convolution_backward_default_200 = None
        convolution_backward_default_201 = torch.ops.aten.convolution_backward.default(getitem_1611, constant_pad_nd_default_22, primals_616, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1611 = constant_pad_nd_default_22 = primals_616 = None
        getitem_1614 = convolution_backward_default_201[0]
        getitem_1615 = convolution_backward_default_201[1]
        getitem_1616 = convolution_backward_default_201[2];  convolution_backward_default_201 = None
        constant_pad_nd_default_49 = torch.ops.aten.constant_pad_nd.default(getitem_1614, [-1, -2, -1, -2]);  getitem_1614 = None
        to_dtype_324 = torch.ops.aten.to.dtype(constant_pad_nd_default_49, torch.float32);  constant_pad_nd_default_49 = None
        to_dtype_325 = torch.ops.aten.to.dtype(relu_default_91, torch.float32);  relu_default_91 = None
        le_scalar_108 = torch.ops.aten.le.Scalar(to_dtype_325, 0);  to_dtype_325 = None
        new_zeros_default_309 = torch.ops.aten.new_zeros.default(to_dtype_324, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_108 = torch.ops.aten.where.self(le_scalar_108, new_zeros_default_309, to_dtype_324);  le_scalar_108 = new_zeros_default_309 = to_dtype_324 = None
        to_dtype_326 = torch.ops.aten.to.dtype(where_self_108, torch.float32);  where_self_108 = None
        add_tensor_138 = torch.ops.aten.add.Tensor(add_tensor_137, to_dtype_326);  add_tensor_137 = to_dtype_326 = None
        max_pool2d_with_indices_backward_default_22 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_40, constant_pad_nd_default_21, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_318);  constant_pad_nd_default_21 = getitem_318 = None
        constant_pad_nd_default_50 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default_22, [0, -1, 0, -1]);  max_pool2d_with_indices_backward_default_22 = None
        add_tensor_139 = torch.ops.aten.add.Tensor(add_tensor_138, constant_pad_nd_default_50);  add_tensor_138 = constant_pad_nd_default_50 = None
        clone_default_32 = torch.ops.aten.clone.default(slice_tensor_40, memory_format = torch.contiguous_format);  slice_tensor_40 = None
        native_batch_norm_backward_default_108 = torch.ops.aten.native_batch_norm_backward.default(clone_default_32, convolution_default_170, primals_601, primals_599, primals_600, getitem_315, getitem_316, True, 0.001, [True, True, True]);  clone_default_32 = convolution_default_170 = primals_601 = primals_599 = primals_600 = getitem_315 = getitem_316 = None
        getitem_1617 = native_batch_norm_backward_default_108[0]
        getitem_1618 = native_batch_norm_backward_default_108[1]
        getitem_1619 = native_batch_norm_backward_default_108[2];  native_batch_norm_backward_default_108 = None
        convolution_backward_default_202 = torch.ops.aten.convolution_backward.default(getitem_1617, convolution_default_169, primals_605, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1617 = convolution_default_169 = primals_605 = None
        getitem_1620 = convolution_backward_default_202[0]
        getitem_1621 = convolution_backward_default_202[1]
        getitem_1622 = convolution_backward_default_202[2];  convolution_backward_default_202 = None
        convolution_backward_default_203 = torch.ops.aten.convolution_backward.default(getitem_1620, relu_default_90, primals_604, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1620 = primals_604 = None
        getitem_1623 = convolution_backward_default_203[0]
        getitem_1624 = convolution_backward_default_203[1]
        getitem_1625 = convolution_backward_default_203[2];  convolution_backward_default_203 = None
        to_dtype_327 = torch.ops.aten.to.dtype(getitem_1623, torch.float32);  getitem_1623 = None
        to_dtype_328 = torch.ops.aten.to.dtype(relu_default_90, torch.float32);  relu_default_90 = None
        le_scalar_109 = torch.ops.aten.le.Scalar(to_dtype_328, 0);  to_dtype_328 = None
        new_zeros_default_310 = torch.ops.aten.new_zeros.default(to_dtype_327, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_109 = torch.ops.aten.where.self(le_scalar_109, new_zeros_default_310, to_dtype_327);  le_scalar_109 = new_zeros_default_310 = to_dtype_327 = None
        to_dtype_329 = torch.ops.aten.to.dtype(where_self_109, torch.float32);  where_self_109 = None
        native_batch_norm_backward_default_109 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_329, convolution_default_168, primals_596, primals_594, primals_595, getitem_312, getitem_313, True, 0.001, [True, True, True]);  to_dtype_329 = convolution_default_168 = primals_596 = primals_594 = primals_595 = getitem_312 = getitem_313 = None
        getitem_1626 = native_batch_norm_backward_default_109[0]
        getitem_1627 = native_batch_norm_backward_default_109[1]
        getitem_1628 = native_batch_norm_backward_default_109[2];  native_batch_norm_backward_default_109 = None
        convolution_backward_default_204 = torch.ops.aten.convolution_backward.default(getitem_1626, convolution_default_167, primals_603, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1626 = convolution_default_167 = primals_603 = None
        getitem_1629 = convolution_backward_default_204[0]
        getitem_1630 = convolution_backward_default_204[1]
        getitem_1631 = convolution_backward_default_204[2];  convolution_backward_default_204 = None
        convolution_backward_default_205 = torch.ops.aten.convolution_backward.default(getitem_1629, constant_pad_nd_default_20, primals_602, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1629 = constant_pad_nd_default_20 = primals_602 = None
        getitem_1632 = convolution_backward_default_205[0]
        getitem_1633 = convolution_backward_default_205[1]
        getitem_1634 = convolution_backward_default_205[2];  convolution_backward_default_205 = None
        constant_pad_nd_default_51 = torch.ops.aten.constant_pad_nd.default(getitem_1632, [-2, -3, -2, -3]);  getitem_1632 = None
        to_dtype_330 = torch.ops.aten.to.dtype(constant_pad_nd_default_51, torch.float32);  constant_pad_nd_default_51 = None
        to_dtype_331 = torch.ops.aten.to.dtype(relu_default_89, torch.float32);  relu_default_89 = None
        le_scalar_110 = torch.ops.aten.le.Scalar(to_dtype_331, 0);  to_dtype_331 = None
        new_zeros_default_311 = torch.ops.aten.new_zeros.default(to_dtype_330, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_110 = torch.ops.aten.where.self(le_scalar_110, new_zeros_default_311, to_dtype_330);  le_scalar_110 = new_zeros_default_311 = to_dtype_330 = None
        to_dtype_332 = torch.ops.aten.to.dtype(where_self_110, torch.float32);  where_self_110 = None
        add_tensor_140 = torch.ops.aten.add.Tensor(add_tensor_139, to_dtype_332);  add_tensor_139 = to_dtype_332 = None
        max_pool2d_with_indices_backward_default_23 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_39, constant_pad_nd_default_19, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_310);  constant_pad_nd_default_19 = getitem_310 = None
        constant_pad_nd_default_52 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default_23, [0, -1, 0, -1]);  max_pool2d_with_indices_backward_default_23 = None
        add_tensor_141 = torch.ops.aten.add.Tensor(to_dtype_308, constant_pad_nd_default_52);  to_dtype_308 = constant_pad_nd_default_52 = None
        clone_default_33 = torch.ops.aten.clone.default(slice_tensor_39, memory_format = torch.contiguous_format);  slice_tensor_39 = None
        native_batch_norm_backward_default_110 = torch.ops.aten.native_batch_norm_backward.default(clone_default_33, convolution_default_166, primals_587, primals_585, primals_586, getitem_307, getitem_308, True, 0.001, [True, True, True]);  clone_default_33 = convolution_default_166 = primals_587 = primals_585 = primals_586 = getitem_307 = getitem_308 = None
        getitem_1635 = native_batch_norm_backward_default_110[0]
        getitem_1636 = native_batch_norm_backward_default_110[1]
        getitem_1637 = native_batch_norm_backward_default_110[2];  native_batch_norm_backward_default_110 = None
        convolution_backward_default_206 = torch.ops.aten.convolution_backward.default(getitem_1635, convolution_default_165, primals_591, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1635 = convolution_default_165 = primals_591 = None
        getitem_1638 = convolution_backward_default_206[0]
        getitem_1639 = convolution_backward_default_206[1]
        getitem_1640 = convolution_backward_default_206[2];  convolution_backward_default_206 = None
        convolution_backward_default_207 = torch.ops.aten.convolution_backward.default(getitem_1638, relu_default_88, primals_590, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1638 = primals_590 = None
        getitem_1641 = convolution_backward_default_207[0]
        getitem_1642 = convolution_backward_default_207[1]
        getitem_1643 = convolution_backward_default_207[2];  convolution_backward_default_207 = None
        to_dtype_333 = torch.ops.aten.to.dtype(getitem_1641, torch.float32);  getitem_1641 = None
        to_dtype_334 = torch.ops.aten.to.dtype(relu_default_88, torch.float32);  relu_default_88 = None
        le_scalar_111 = torch.ops.aten.le.Scalar(to_dtype_334, 0);  to_dtype_334 = None
        new_zeros_default_312 = torch.ops.aten.new_zeros.default(to_dtype_333, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_111 = torch.ops.aten.where.self(le_scalar_111, new_zeros_default_312, to_dtype_333);  le_scalar_111 = new_zeros_default_312 = to_dtype_333 = None
        to_dtype_335 = torch.ops.aten.to.dtype(where_self_111, torch.float32);  where_self_111 = None
        native_batch_norm_backward_default_111 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_335, convolution_default_164, primals_582, primals_580, primals_581, getitem_304, getitem_305, True, 0.001, [True, True, True]);  to_dtype_335 = convolution_default_164 = primals_582 = primals_580 = primals_581 = getitem_304 = getitem_305 = None
        getitem_1644 = native_batch_norm_backward_default_111[0]
        getitem_1645 = native_batch_norm_backward_default_111[1]
        getitem_1646 = native_batch_norm_backward_default_111[2];  native_batch_norm_backward_default_111 = None
        convolution_backward_default_208 = torch.ops.aten.convolution_backward.default(getitem_1644, convolution_default_163, primals_589, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1644 = convolution_default_163 = primals_589 = None
        getitem_1647 = convolution_backward_default_208[0]
        getitem_1648 = convolution_backward_default_208[1]
        getitem_1649 = convolution_backward_default_208[2];  convolution_backward_default_208 = None
        convolution_backward_default_209 = torch.ops.aten.convolution_backward.default(getitem_1647, constant_pad_nd_default_18, primals_588, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 432, [True, True, False]);  getitem_1647 = constant_pad_nd_default_18 = primals_588 = None
        getitem_1650 = convolution_backward_default_209[0]
        getitem_1651 = convolution_backward_default_209[1]
        getitem_1652 = convolution_backward_default_209[2];  convolution_backward_default_209 = None
        constant_pad_nd_default_53 = torch.ops.aten.constant_pad_nd.default(getitem_1650, [-1, -2, -1, -2]);  getitem_1650 = None
        to_dtype_336 = torch.ops.aten.to.dtype(constant_pad_nd_default_53, torch.float32);  constant_pad_nd_default_53 = None
        to_dtype_337 = torch.ops.aten.to.dtype(relu_default_87, torch.float32);  relu_default_87 = None
        le_scalar_112 = torch.ops.aten.le.Scalar(to_dtype_337, 0);  to_dtype_337 = None
        new_zeros_default_313 = torch.ops.aten.new_zeros.default(to_dtype_336, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_112 = torch.ops.aten.where.self(le_scalar_112, new_zeros_default_313, to_dtype_336);  le_scalar_112 = new_zeros_default_313 = to_dtype_336 = None
        to_dtype_338 = torch.ops.aten.to.dtype(where_self_112, torch.float32);  where_self_112 = None
        add_tensor_142 = torch.ops.aten.add.Tensor(add_tensor_141, to_dtype_338);  add_tensor_141 = to_dtype_338 = None
        native_batch_norm_backward_default_112 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_140, convolution_default_162, primals_672, primals_670, primals_671, getitem_301, getitem_302, True, 0.001, [True, True, True]);  add_tensor_140 = convolution_default_162 = primals_672 = primals_670 = primals_671 = getitem_301 = getitem_302 = None
        getitem_1653 = native_batch_norm_backward_default_112[0]
        getitem_1654 = native_batch_norm_backward_default_112[1]
        getitem_1655 = native_batch_norm_backward_default_112[2];  native_batch_norm_backward_default_112 = None
        convolution_backward_default_210 = torch.ops.aten.convolution_backward.default(getitem_1653, relu_default_86, primals_673, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1653 = primals_673 = None
        getitem_1656 = convolution_backward_default_210[0]
        getitem_1657 = convolution_backward_default_210[1]
        getitem_1658 = convolution_backward_default_210[2];  convolution_backward_default_210 = None
        to_dtype_339 = torch.ops.aten.to.dtype(getitem_1656, torch.float32);  getitem_1656 = None
        to_dtype_340 = torch.ops.aten.to.dtype(relu_default_86, torch.float32);  relu_default_86 = None
        le_scalar_113 = torch.ops.aten.le.Scalar(to_dtype_340, 0);  to_dtype_340 = None
        new_zeros_default_314 = torch.ops.aten.new_zeros.default(to_dtype_339, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_113 = torch.ops.aten.where.self(le_scalar_113, new_zeros_default_314, to_dtype_339);  le_scalar_113 = new_zeros_default_314 = to_dtype_339 = None
        to_dtype_341 = torch.ops.aten.to.dtype(where_self_113, torch.float32);  where_self_113 = None
        add_tensor_143 = torch.ops.aten.add.Tensor(to_dtype_299, to_dtype_341);  to_dtype_299 = to_dtype_341 = None
        native_batch_norm_backward_default_113 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_142, convolution_default_161, primals_678, primals_676, primals_677, getitem_298, getitem_299, True, 0.001, [True, True, True]);  add_tensor_142 = convolution_default_161 = primals_678 = primals_676 = primals_677 = getitem_298 = getitem_299 = None
        getitem_1659 = native_batch_norm_backward_default_113[0]
        getitem_1660 = native_batch_norm_backward_default_113[1]
        getitem_1661 = native_batch_norm_backward_default_113[2];  native_batch_norm_backward_default_113 = None
        convolution_backward_default_211 = torch.ops.aten.convolution_backward.default(getitem_1659, relu_default_85, primals_679, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1659 = primals_679 = None
        getitem_1662 = convolution_backward_default_211[0]
        getitem_1663 = convolution_backward_default_211[1]
        getitem_1664 = convolution_backward_default_211[2];  convolution_backward_default_211 = None
        to_dtype_342 = torch.ops.aten.to.dtype(getitem_1662, torch.float32);  getitem_1662 = None
        to_dtype_343 = torch.ops.aten.to.dtype(relu_default_85, torch.float32);  relu_default_85 = None
        le_scalar_114 = torch.ops.aten.le.Scalar(to_dtype_343, 0);  to_dtype_343 = None
        new_zeros_default_315 = torch.ops.aten.new_zeros.default(to_dtype_342, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_114 = torch.ops.aten.where.self(le_scalar_114, new_zeros_default_315, to_dtype_342);  le_scalar_114 = new_zeros_default_315 = to_dtype_342 = None
        to_dtype_344 = torch.ops.aten.to.dtype(where_self_114, torch.float32);  where_self_114 = None
        slice_tensor_44 = torch.ops.aten.slice.Tensor(add_tensor_143, 1, 0, 216)
        slice_tensor_45 = torch.ops.aten.slice.Tensor(add_tensor_143, 1, 216, 432)
        slice_tensor_46 = torch.ops.aten.slice.Tensor(add_tensor_143, 1, 432, 648)
        slice_tensor_47 = torch.ops.aten.slice.Tensor(add_tensor_143, 1, 648, 864)
        slice_tensor_48 = torch.ops.aten.slice.Tensor(add_tensor_143, 1, 864, 1080);  add_tensor_143 = None
        clone_default_34 = torch.ops.aten.clone.default(slice_tensor_48, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_114 = torch.ops.aten.native_batch_norm_backward.default(clone_default_34, convolution_default_160, primals_561, primals_559, primals_560, getitem_295, getitem_296, True, 0.001, [True, True, True]);  clone_default_34 = convolution_default_160 = primals_561 = primals_559 = primals_560 = getitem_295 = getitem_296 = None
        getitem_1665 = native_batch_norm_backward_default_114[0]
        getitem_1666 = native_batch_norm_backward_default_114[1]
        getitem_1667 = native_batch_norm_backward_default_114[2];  native_batch_norm_backward_default_114 = None
        convolution_backward_default_212 = torch.ops.aten.convolution_backward.default(getitem_1665, convolution_default_159, primals_565, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1665 = convolution_default_159 = primals_565 = None
        getitem_1668 = convolution_backward_default_212[0]
        getitem_1669 = convolution_backward_default_212[1]
        getitem_1670 = convolution_backward_default_212[2];  convolution_backward_default_212 = None
        convolution_backward_default_213 = torch.ops.aten.convolution_backward.default(getitem_1668, relu_default_84, primals_564, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_1668 = primals_564 = None
        getitem_1671 = convolution_backward_default_213[0]
        getitem_1672 = convolution_backward_default_213[1]
        getitem_1673 = convolution_backward_default_213[2];  convolution_backward_default_213 = None
        to_dtype_345 = torch.ops.aten.to.dtype(getitem_1671, torch.float32);  getitem_1671 = None
        to_dtype_346 = torch.ops.aten.to.dtype(relu_default_84, torch.float32);  relu_default_84 = None
        le_scalar_115 = torch.ops.aten.le.Scalar(to_dtype_346, 0);  to_dtype_346 = None
        new_zeros_default_316 = torch.ops.aten.new_zeros.default(to_dtype_345, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_115 = torch.ops.aten.where.self(le_scalar_115, new_zeros_default_316, to_dtype_345);  le_scalar_115 = new_zeros_default_316 = to_dtype_345 = None
        to_dtype_347 = torch.ops.aten.to.dtype(where_self_115, torch.float32);  where_self_115 = None
        native_batch_norm_backward_default_115 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_347, convolution_default_158, primals_556, primals_554, primals_555, getitem_292, getitem_293, True, 0.001, [True, True, True]);  to_dtype_347 = convolution_default_158 = primals_556 = primals_554 = primals_555 = getitem_292 = getitem_293 = None
        getitem_1674 = native_batch_norm_backward_default_115[0]
        getitem_1675 = native_batch_norm_backward_default_115[1]
        getitem_1676 = native_batch_norm_backward_default_115[2];  native_batch_norm_backward_default_115 = None
        convolution_backward_default_214 = torch.ops.aten.convolution_backward.default(getitem_1674, convolution_default_157, primals_563, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1674 = convolution_default_157 = primals_563 = None
        getitem_1677 = convolution_backward_default_214[0]
        getitem_1678 = convolution_backward_default_214[1]
        getitem_1679 = convolution_backward_default_214[2];  convolution_backward_default_214 = None
        convolution_backward_default_215 = torch.ops.aten.convolution_backward.default(getitem_1677, relu_default_83, primals_562, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_1677 = primals_562 = None
        getitem_1680 = convolution_backward_default_215[0]
        getitem_1681 = convolution_backward_default_215[1]
        getitem_1682 = convolution_backward_default_215[2];  convolution_backward_default_215 = None
        to_dtype_348 = torch.ops.aten.to.dtype(getitem_1680, torch.float32);  getitem_1680 = None
        to_dtype_349 = torch.ops.aten.to.dtype(relu_default_83, torch.float32);  relu_default_83 = None
        le_scalar_116 = torch.ops.aten.le.Scalar(to_dtype_349, 0);  to_dtype_349 = None
        new_zeros_default_317 = torch.ops.aten.new_zeros.default(to_dtype_348, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_116 = torch.ops.aten.where.self(le_scalar_116, new_zeros_default_317, to_dtype_348);  le_scalar_116 = new_zeros_default_317 = to_dtype_348 = None
        to_dtype_350 = torch.ops.aten.to.dtype(where_self_116, torch.float32);  where_self_116 = None
        max_pool2d_with_indices_backward_default_24 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_47, getitem_252, [3, 3], [1, 1], [1, 1], [1, 1], False, getitem_290);  getitem_290 = None
        add_tensor_144 = torch.ops.aten.add.Tensor(slice_tensor_48, max_pool2d_with_indices_backward_default_24);  slice_tensor_48 = max_pool2d_with_indices_backward_default_24 = None
        clone_default_35 = torch.ops.aten.clone.default(slice_tensor_47, memory_format = torch.contiguous_format);  slice_tensor_47 = None
        native_batch_norm_backward_default_116 = torch.ops.aten.native_batch_norm_backward.default(clone_default_35, convolution_default_156, primals_547, primals_545, primals_546, getitem_287, getitem_288, True, 0.001, [True, True, True]);  clone_default_35 = convolution_default_156 = primals_547 = primals_545 = primals_546 = getitem_287 = getitem_288 = None
        getitem_1683 = native_batch_norm_backward_default_116[0]
        getitem_1684 = native_batch_norm_backward_default_116[1]
        getitem_1685 = native_batch_norm_backward_default_116[2];  native_batch_norm_backward_default_116 = None
        convolution_backward_default_216 = torch.ops.aten.convolution_backward.default(getitem_1683, convolution_default_155, primals_551, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1683 = convolution_default_155 = primals_551 = None
        getitem_1686 = convolution_backward_default_216[0]
        getitem_1687 = convolution_backward_default_216[1]
        getitem_1688 = convolution_backward_default_216[2];  convolution_backward_default_216 = None
        convolution_backward_default_217 = torch.ops.aten.convolution_backward.default(getitem_1686, relu_default_82, primals_550, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_1686 = primals_550 = None
        getitem_1689 = convolution_backward_default_217[0]
        getitem_1690 = convolution_backward_default_217[1]
        getitem_1691 = convolution_backward_default_217[2];  convolution_backward_default_217 = None
        to_dtype_351 = torch.ops.aten.to.dtype(getitem_1689, torch.float32);  getitem_1689 = None
        to_dtype_352 = torch.ops.aten.to.dtype(relu_default_82, torch.float32);  relu_default_82 = None
        le_scalar_117 = torch.ops.aten.le.Scalar(to_dtype_352, 0);  to_dtype_352 = None
        new_zeros_default_318 = torch.ops.aten.new_zeros.default(to_dtype_351, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_117 = torch.ops.aten.where.self(le_scalar_117, new_zeros_default_318, to_dtype_351);  le_scalar_117 = new_zeros_default_318 = to_dtype_351 = None
        to_dtype_353 = torch.ops.aten.to.dtype(where_self_117, torch.float32);  where_self_117 = None
        native_batch_norm_backward_default_117 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_353, convolution_default_154, primals_542, primals_540, primals_541, getitem_284, getitem_285, True, 0.001, [True, True, True]);  to_dtype_353 = convolution_default_154 = primals_542 = primals_540 = primals_541 = getitem_284 = getitem_285 = None
        getitem_1692 = native_batch_norm_backward_default_117[0]
        getitem_1693 = native_batch_norm_backward_default_117[1]
        getitem_1694 = native_batch_norm_backward_default_117[2];  native_batch_norm_backward_default_117 = None
        convolution_backward_default_218 = torch.ops.aten.convolution_backward.default(getitem_1692, convolution_default_153, primals_549, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1692 = convolution_default_153 = primals_549 = None
        getitem_1695 = convolution_backward_default_218[0]
        getitem_1696 = convolution_backward_default_218[1]
        getitem_1697 = convolution_backward_default_218[2];  convolution_backward_default_218 = None
        convolution_backward_default_219 = torch.ops.aten.convolution_backward.default(getitem_1695, relu_default_81, primals_548, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_1695 = primals_548 = None
        getitem_1698 = convolution_backward_default_219[0]
        getitem_1699 = convolution_backward_default_219[1]
        getitem_1700 = convolution_backward_default_219[2];  convolution_backward_default_219 = None
        to_dtype_354 = torch.ops.aten.to.dtype(getitem_1698, torch.float32);  getitem_1698 = None
        to_dtype_355 = torch.ops.aten.to.dtype(relu_default_81, torch.float32);  relu_default_81 = None
        le_scalar_118 = torch.ops.aten.le.Scalar(to_dtype_355, 0);  to_dtype_355 = None
        new_zeros_default_319 = torch.ops.aten.new_zeros.default(to_dtype_354, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_118 = torch.ops.aten.where.self(le_scalar_118, new_zeros_default_319, to_dtype_354);  le_scalar_118 = new_zeros_default_319 = to_dtype_354 = None
        to_dtype_356 = torch.ops.aten.to.dtype(where_self_118, torch.float32);  where_self_118 = None
        add_tensor_145 = torch.ops.aten.add.Tensor(slice_tensor_46, to_dtype_356);  slice_tensor_46 = to_dtype_356 = None
        native_batch_norm_backward_default_118 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_145, convolution_default_152, primals_533, primals_531, primals_532, getitem_281, getitem_282, True, 0.001, [True, True, True]);  convolution_default_152 = primals_533 = primals_531 = primals_532 = getitem_281 = getitem_282 = None
        getitem_1701 = native_batch_norm_backward_default_118[0]
        getitem_1702 = native_batch_norm_backward_default_118[1]
        getitem_1703 = native_batch_norm_backward_default_118[2];  native_batch_norm_backward_default_118 = None
        convolution_backward_default_220 = torch.ops.aten.convolution_backward.default(getitem_1701, convolution_default_151, primals_537, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1701 = convolution_default_151 = primals_537 = None
        getitem_1704 = convolution_backward_default_220[0]
        getitem_1705 = convolution_backward_default_220[1]
        getitem_1706 = convolution_backward_default_220[2];  convolution_backward_default_220 = None
        convolution_backward_default_221 = torch.ops.aten.convolution_backward.default(getitem_1704, relu_default_80, primals_536, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_1704 = primals_536 = None
        getitem_1707 = convolution_backward_default_221[0]
        getitem_1708 = convolution_backward_default_221[1]
        getitem_1709 = convolution_backward_default_221[2];  convolution_backward_default_221 = None
        to_dtype_357 = torch.ops.aten.to.dtype(getitem_1707, torch.float32);  getitem_1707 = None
        to_dtype_358 = torch.ops.aten.to.dtype(relu_default_80, torch.float32);  relu_default_80 = None
        le_scalar_119 = torch.ops.aten.le.Scalar(to_dtype_358, 0);  to_dtype_358 = None
        new_zeros_default_320 = torch.ops.aten.new_zeros.default(to_dtype_357, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_119 = torch.ops.aten.where.self(le_scalar_119, new_zeros_default_320, to_dtype_357);  le_scalar_119 = new_zeros_default_320 = to_dtype_357 = None
        to_dtype_359 = torch.ops.aten.to.dtype(where_self_119, torch.float32);  where_self_119 = None
        native_batch_norm_backward_default_119 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_359, convolution_default_150, primals_528, primals_526, primals_527, getitem_278, getitem_279, True, 0.001, [True, True, True]);  to_dtype_359 = convolution_default_150 = primals_528 = primals_526 = primals_527 = getitem_278 = getitem_279 = None
        getitem_1710 = native_batch_norm_backward_default_119[0]
        getitem_1711 = native_batch_norm_backward_default_119[1]
        getitem_1712 = native_batch_norm_backward_default_119[2];  native_batch_norm_backward_default_119 = None
        convolution_backward_default_222 = torch.ops.aten.convolution_backward.default(getitem_1710, convolution_default_149, primals_535, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1710 = convolution_default_149 = primals_535 = None
        getitem_1713 = convolution_backward_default_222[0]
        getitem_1714 = convolution_backward_default_222[1]
        getitem_1715 = convolution_backward_default_222[2];  convolution_backward_default_222 = None
        convolution_backward_default_223 = torch.ops.aten.convolution_backward.default(getitem_1713, relu_default_79, primals_534, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_1713 = primals_534 = None
        getitem_1716 = convolution_backward_default_223[0]
        getitem_1717 = convolution_backward_default_223[1]
        getitem_1718 = convolution_backward_default_223[2];  convolution_backward_default_223 = None
        to_dtype_360 = torch.ops.aten.to.dtype(getitem_1716, torch.float32);  getitem_1716 = None
        to_dtype_361 = torch.ops.aten.to.dtype(relu_default_79, torch.float32);  relu_default_79 = None
        le_scalar_120 = torch.ops.aten.le.Scalar(to_dtype_361, 0);  to_dtype_361 = None
        new_zeros_default_321 = torch.ops.aten.new_zeros.default(to_dtype_360, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_120 = torch.ops.aten.where.self(le_scalar_120, new_zeros_default_321, to_dtype_360);  le_scalar_120 = new_zeros_default_321 = to_dtype_360 = None
        to_dtype_362 = torch.ops.aten.to.dtype(where_self_120, torch.float32);  where_self_120 = None
        add_tensor_146 = torch.ops.aten.add.Tensor(add_tensor_144, to_dtype_362);  add_tensor_144 = to_dtype_362 = None
        native_batch_norm_backward_default_120 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_145, convolution_default_148, primals_519, primals_517, primals_518, getitem_275, getitem_276, True, 0.001, [True, True, True]);  add_tensor_145 = convolution_default_148 = primals_519 = primals_517 = primals_518 = getitem_275 = getitem_276 = None
        getitem_1719 = native_batch_norm_backward_default_120[0]
        getitem_1720 = native_batch_norm_backward_default_120[1]
        getitem_1721 = native_batch_norm_backward_default_120[2];  native_batch_norm_backward_default_120 = None
        convolution_backward_default_224 = torch.ops.aten.convolution_backward.default(getitem_1719, convolution_default_147, primals_523, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1719 = convolution_default_147 = primals_523 = None
        getitem_1722 = convolution_backward_default_224[0]
        getitem_1723 = convolution_backward_default_224[1]
        getitem_1724 = convolution_backward_default_224[2];  convolution_backward_default_224 = None
        convolution_backward_default_225 = torch.ops.aten.convolution_backward.default(getitem_1722, relu_default_78, primals_522, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_1722 = primals_522 = None
        getitem_1725 = convolution_backward_default_225[0]
        getitem_1726 = convolution_backward_default_225[1]
        getitem_1727 = convolution_backward_default_225[2];  convolution_backward_default_225 = None
        to_dtype_363 = torch.ops.aten.to.dtype(getitem_1725, torch.float32);  getitem_1725 = None
        to_dtype_364 = torch.ops.aten.to.dtype(relu_default_78, torch.float32);  relu_default_78 = None
        le_scalar_121 = torch.ops.aten.le.Scalar(to_dtype_364, 0);  to_dtype_364 = None
        new_zeros_default_322 = torch.ops.aten.new_zeros.default(to_dtype_363, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_121 = torch.ops.aten.where.self(le_scalar_121, new_zeros_default_322, to_dtype_363);  le_scalar_121 = new_zeros_default_322 = to_dtype_363 = None
        to_dtype_365 = torch.ops.aten.to.dtype(where_self_121, torch.float32);  where_self_121 = None
        native_batch_norm_backward_default_121 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_365, convolution_default_146, primals_514, primals_512, primals_513, getitem_272, getitem_273, True, 0.001, [True, True, True]);  to_dtype_365 = convolution_default_146 = primals_514 = primals_512 = primals_513 = getitem_272 = getitem_273 = None
        getitem_1728 = native_batch_norm_backward_default_121[0]
        getitem_1729 = native_batch_norm_backward_default_121[1]
        getitem_1730 = native_batch_norm_backward_default_121[2];  native_batch_norm_backward_default_121 = None
        convolution_backward_default_226 = torch.ops.aten.convolution_backward.default(getitem_1728, convolution_default_145, primals_521, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1728 = convolution_default_145 = primals_521 = None
        getitem_1731 = convolution_backward_default_226[0]
        getitem_1732 = convolution_backward_default_226[1]
        getitem_1733 = convolution_backward_default_226[2];  convolution_backward_default_226 = None
        convolution_backward_default_227 = torch.ops.aten.convolution_backward.default(getitem_1731, relu_default_77, primals_520, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_1731 = primals_520 = None
        getitem_1734 = convolution_backward_default_227[0]
        getitem_1735 = convolution_backward_default_227[1]
        getitem_1736 = convolution_backward_default_227[2];  convolution_backward_default_227 = None
        to_dtype_366 = torch.ops.aten.to.dtype(getitem_1734, torch.float32);  getitem_1734 = None
        to_dtype_367 = torch.ops.aten.to.dtype(relu_default_77, torch.float32);  relu_default_77 = None
        le_scalar_122 = torch.ops.aten.le.Scalar(to_dtype_367, 0);  to_dtype_367 = None
        new_zeros_default_323 = torch.ops.aten.new_zeros.default(to_dtype_366, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_122 = torch.ops.aten.where.self(le_scalar_122, new_zeros_default_323, to_dtype_366);  le_scalar_122 = new_zeros_default_323 = to_dtype_366 = None
        to_dtype_368 = torch.ops.aten.to.dtype(where_self_122, torch.float32);  where_self_122 = None
        add_tensor_147 = torch.ops.aten.add.Tensor(add_tensor_146, to_dtype_368);  add_tensor_146 = to_dtype_368 = None
        max_pool2d_with_indices_backward_default_25 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_45, getitem_252, [3, 3], [1, 1], [1, 1], [1, 1], False, getitem_270);  getitem_252 = getitem_270 = None
        add_tensor_148 = torch.ops.aten.add.Tensor(add_tensor_147, max_pool2d_with_indices_backward_default_25);  add_tensor_147 = max_pool2d_with_indices_backward_default_25 = None
        clone_default_36 = torch.ops.aten.clone.default(slice_tensor_45, memory_format = torch.contiguous_format);  slice_tensor_45 = None
        native_batch_norm_backward_default_122 = torch.ops.aten.native_batch_norm_backward.default(clone_default_36, convolution_default_144, primals_505, primals_503, primals_504, getitem_267, getitem_268, True, 0.001, [True, True, True]);  clone_default_36 = convolution_default_144 = primals_505 = primals_503 = primals_504 = getitem_267 = getitem_268 = None
        getitem_1737 = native_batch_norm_backward_default_122[0]
        getitem_1738 = native_batch_norm_backward_default_122[1]
        getitem_1739 = native_batch_norm_backward_default_122[2];  native_batch_norm_backward_default_122 = None
        convolution_backward_default_228 = torch.ops.aten.convolution_backward.default(getitem_1737, convolution_default_143, primals_509, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1737 = convolution_default_143 = primals_509 = None
        getitem_1740 = convolution_backward_default_228[0]
        getitem_1741 = convolution_backward_default_228[1]
        getitem_1742 = convolution_backward_default_228[2];  convolution_backward_default_228 = None
        convolution_backward_default_229 = torch.ops.aten.convolution_backward.default(getitem_1740, relu_default_76, primals_508, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_1740 = primals_508 = None
        getitem_1743 = convolution_backward_default_229[0]
        getitem_1744 = convolution_backward_default_229[1]
        getitem_1745 = convolution_backward_default_229[2];  convolution_backward_default_229 = None
        to_dtype_369 = torch.ops.aten.to.dtype(getitem_1743, torch.float32);  getitem_1743 = None
        to_dtype_370 = torch.ops.aten.to.dtype(relu_default_76, torch.float32);  relu_default_76 = None
        le_scalar_123 = torch.ops.aten.le.Scalar(to_dtype_370, 0);  to_dtype_370 = None
        new_zeros_default_324 = torch.ops.aten.new_zeros.default(to_dtype_369, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_123 = torch.ops.aten.where.self(le_scalar_123, new_zeros_default_324, to_dtype_369);  le_scalar_123 = new_zeros_default_324 = to_dtype_369 = None
        to_dtype_371 = torch.ops.aten.to.dtype(where_self_123, torch.float32);  where_self_123 = None
        native_batch_norm_backward_default_123 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_371, convolution_default_142, primals_500, primals_498, primals_499, getitem_264, getitem_265, True, 0.001, [True, True, True]);  to_dtype_371 = convolution_default_142 = primals_500 = primals_498 = primals_499 = getitem_264 = getitem_265 = None
        getitem_1746 = native_batch_norm_backward_default_123[0]
        getitem_1747 = native_batch_norm_backward_default_123[1]
        getitem_1748 = native_batch_norm_backward_default_123[2];  native_batch_norm_backward_default_123 = None
        convolution_backward_default_230 = torch.ops.aten.convolution_backward.default(getitem_1746, convolution_default_141, primals_507, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1746 = convolution_default_141 = primals_507 = None
        getitem_1749 = convolution_backward_default_230[0]
        getitem_1750 = convolution_backward_default_230[1]
        getitem_1751 = convolution_backward_default_230[2];  convolution_backward_default_230 = None
        convolution_backward_default_231 = torch.ops.aten.convolution_backward.default(getitem_1749, relu_default_75, primals_506, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_1749 = primals_506 = None
        getitem_1752 = convolution_backward_default_231[0]
        getitem_1753 = convolution_backward_default_231[1]
        getitem_1754 = convolution_backward_default_231[2];  convolution_backward_default_231 = None
        to_dtype_372 = torch.ops.aten.to.dtype(getitem_1752, torch.float32);  getitem_1752 = None
        to_dtype_373 = torch.ops.aten.to.dtype(relu_default_75, torch.float32);  relu_default_75 = None
        le_scalar_124 = torch.ops.aten.le.Scalar(to_dtype_373, 0);  to_dtype_373 = None
        new_zeros_default_325 = torch.ops.aten.new_zeros.default(to_dtype_372, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_124 = torch.ops.aten.where.self(le_scalar_124, new_zeros_default_325, to_dtype_372);  le_scalar_124 = new_zeros_default_325 = to_dtype_372 = None
        to_dtype_374 = torch.ops.aten.to.dtype(where_self_124, torch.float32);  where_self_124 = None
        add_tensor_149 = torch.ops.aten.add.Tensor(add_tensor_148, to_dtype_374);  add_tensor_148 = to_dtype_374 = None
        max_pool2d_with_indices_backward_default_26 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_44, getitem_249, [3, 3], [1, 1], [1, 1], [1, 1], False, getitem_262);  getitem_249 = getitem_262 = None
        add_tensor_150 = torch.ops.aten.add.Tensor(to_dtype_350, max_pool2d_with_indices_backward_default_26);  to_dtype_350 = max_pool2d_with_indices_backward_default_26 = None
        clone_default_37 = torch.ops.aten.clone.default(slice_tensor_44, memory_format = torch.contiguous_format);  slice_tensor_44 = None
        native_batch_norm_backward_default_124 = torch.ops.aten.native_batch_norm_backward.default(clone_default_37, convolution_default_140, primals_491, primals_489, primals_490, getitem_259, getitem_260, True, 0.001, [True, True, True]);  clone_default_37 = convolution_default_140 = primals_491 = primals_489 = primals_490 = getitem_259 = getitem_260 = None
        getitem_1755 = native_batch_norm_backward_default_124[0]
        getitem_1756 = native_batch_norm_backward_default_124[1]
        getitem_1757 = native_batch_norm_backward_default_124[2];  native_batch_norm_backward_default_124 = None
        convolution_backward_default_232 = torch.ops.aten.convolution_backward.default(getitem_1755, convolution_default_139, primals_495, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1755 = convolution_default_139 = primals_495 = None
        getitem_1758 = convolution_backward_default_232[0]
        getitem_1759 = convolution_backward_default_232[1]
        getitem_1760 = convolution_backward_default_232[2];  convolution_backward_default_232 = None
        convolution_backward_default_233 = torch.ops.aten.convolution_backward.default(getitem_1758, relu_default_74, primals_494, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_1758 = primals_494 = None
        getitem_1761 = convolution_backward_default_233[0]
        getitem_1762 = convolution_backward_default_233[1]
        getitem_1763 = convolution_backward_default_233[2];  convolution_backward_default_233 = None
        to_dtype_375 = torch.ops.aten.to.dtype(getitem_1761, torch.float32);  getitem_1761 = None
        to_dtype_376 = torch.ops.aten.to.dtype(relu_default_74, torch.float32);  relu_default_74 = None
        le_scalar_125 = torch.ops.aten.le.Scalar(to_dtype_376, 0);  to_dtype_376 = None
        new_zeros_default_326 = torch.ops.aten.new_zeros.default(to_dtype_375, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_125 = torch.ops.aten.where.self(le_scalar_125, new_zeros_default_326, to_dtype_375);  le_scalar_125 = new_zeros_default_326 = to_dtype_375 = None
        to_dtype_377 = torch.ops.aten.to.dtype(where_self_125, torch.float32);  where_self_125 = None
        native_batch_norm_backward_default_125 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_377, convolution_default_138, primals_486, primals_484, primals_485, getitem_256, getitem_257, True, 0.001, [True, True, True]);  to_dtype_377 = convolution_default_138 = primals_486 = primals_484 = primals_485 = getitem_256 = getitem_257 = None
        getitem_1764 = native_batch_norm_backward_default_125[0]
        getitem_1765 = native_batch_norm_backward_default_125[1]
        getitem_1766 = native_batch_norm_backward_default_125[2];  native_batch_norm_backward_default_125 = None
        convolution_backward_default_234 = torch.ops.aten.convolution_backward.default(getitem_1764, convolution_default_137, primals_493, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1764 = convolution_default_137 = primals_493 = None
        getitem_1767 = convolution_backward_default_234[0]
        getitem_1768 = convolution_backward_default_234[1]
        getitem_1769 = convolution_backward_default_234[2];  convolution_backward_default_234 = None
        convolution_backward_default_235 = torch.ops.aten.convolution_backward.default(getitem_1767, relu_default_73, primals_492, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_1767 = primals_492 = None
        getitem_1770 = convolution_backward_default_235[0]
        getitem_1771 = convolution_backward_default_235[1]
        getitem_1772 = convolution_backward_default_235[2];  convolution_backward_default_235 = None
        to_dtype_378 = torch.ops.aten.to.dtype(getitem_1770, torch.float32);  getitem_1770 = None
        to_dtype_379 = torch.ops.aten.to.dtype(relu_default_73, torch.float32);  relu_default_73 = None
        le_scalar_126 = torch.ops.aten.le.Scalar(to_dtype_379, 0);  to_dtype_379 = None
        new_zeros_default_327 = torch.ops.aten.new_zeros.default(to_dtype_378, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_126 = torch.ops.aten.where.self(le_scalar_126, new_zeros_default_327, to_dtype_378);  le_scalar_126 = new_zeros_default_327 = to_dtype_378 = None
        to_dtype_380 = torch.ops.aten.to.dtype(where_self_126, torch.float32);  where_self_126 = None
        add_tensor_151 = torch.ops.aten.add.Tensor(add_tensor_150, to_dtype_380);  add_tensor_150 = to_dtype_380 = None
        native_batch_norm_backward_default_126 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_149, convolution_default_136, primals_570, primals_568, primals_569, getitem_253, getitem_254, True, 0.001, [True, True, True]);  add_tensor_149 = convolution_default_136 = primals_570 = primals_568 = primals_569 = getitem_253 = getitem_254 = None
        getitem_1773 = native_batch_norm_backward_default_126[0]
        getitem_1774 = native_batch_norm_backward_default_126[1]
        getitem_1775 = native_batch_norm_backward_default_126[2];  native_batch_norm_backward_default_126 = None
        convolution_backward_default_236 = torch.ops.aten.convolution_backward.default(getitem_1773, relu_default_72, primals_571, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1773 = primals_571 = None
        getitem_1776 = convolution_backward_default_236[0]
        getitem_1777 = convolution_backward_default_236[1]
        getitem_1778 = convolution_backward_default_236[2];  convolution_backward_default_236 = None
        to_dtype_381 = torch.ops.aten.to.dtype(getitem_1776, torch.float32);  getitem_1776 = None
        to_dtype_382 = torch.ops.aten.to.dtype(relu_default_72, torch.float32);  relu_default_72 = None
        le_scalar_127 = torch.ops.aten.le.Scalar(to_dtype_382, 0);  to_dtype_382 = None
        new_zeros_default_328 = torch.ops.aten.new_zeros.default(to_dtype_381, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_127 = torch.ops.aten.where.self(le_scalar_127, new_zeros_default_328, to_dtype_381);  le_scalar_127 = new_zeros_default_328 = to_dtype_381 = None
        to_dtype_383 = torch.ops.aten.to.dtype(where_self_127, torch.float32);  where_self_127 = None
        add_tensor_152 = torch.ops.aten.add.Tensor(to_dtype_344, to_dtype_383);  to_dtype_344 = to_dtype_383 = None
        native_batch_norm_backward_default_127 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_151, convolution_default_135, primals_576, primals_574, primals_575, getitem_250, getitem_251, True, 0.001, [True, True, True]);  add_tensor_151 = convolution_default_135 = primals_576 = primals_574 = primals_575 = getitem_250 = getitem_251 = None
        getitem_1779 = native_batch_norm_backward_default_127[0]
        getitem_1780 = native_batch_norm_backward_default_127[1]
        getitem_1781 = native_batch_norm_backward_default_127[2];  native_batch_norm_backward_default_127 = None
        convolution_backward_default_237 = torch.ops.aten.convolution_backward.default(getitem_1779, relu_default_71, primals_577, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1779 = primals_577 = None
        getitem_1782 = convolution_backward_default_237[0]
        getitem_1783 = convolution_backward_default_237[1]
        getitem_1784 = convolution_backward_default_237[2];  convolution_backward_default_237 = None
        to_dtype_384 = torch.ops.aten.to.dtype(getitem_1782, torch.float32);  getitem_1782 = None
        to_dtype_385 = torch.ops.aten.to.dtype(relu_default_71, torch.float32);  relu_default_71 = None
        le_scalar_128 = torch.ops.aten.le.Scalar(to_dtype_385, 0);  to_dtype_385 = None
        new_zeros_default_329 = torch.ops.aten.new_zeros.default(to_dtype_384, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_128 = torch.ops.aten.where.self(le_scalar_128, new_zeros_default_329, to_dtype_384);  le_scalar_128 = new_zeros_default_329 = to_dtype_384 = None
        to_dtype_386 = torch.ops.aten.to.dtype(where_self_128, torch.float32);  where_self_128 = None
        slice_tensor_49 = torch.ops.aten.slice.Tensor(add_tensor_152, 1, 0, 216)
        slice_tensor_50 = torch.ops.aten.slice.Tensor(add_tensor_152, 1, 216, 432)
        slice_tensor_51 = torch.ops.aten.slice.Tensor(add_tensor_152, 1, 432, 648)
        slice_tensor_52 = torch.ops.aten.slice.Tensor(add_tensor_152, 1, 648, 864)
        slice_tensor_53 = torch.ops.aten.slice.Tensor(add_tensor_152, 1, 864, 1080);  add_tensor_152 = None
        clone_default_38 = torch.ops.aten.clone.default(slice_tensor_53, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_128 = torch.ops.aten.native_batch_norm_backward.default(clone_default_38, convolution_default_134, primals_465, primals_463, primals_464, getitem_247, getitem_248, True, 0.001, [True, True, True]);  clone_default_38 = convolution_default_134 = primals_465 = primals_463 = primals_464 = getitem_247 = getitem_248 = None
        getitem_1785 = native_batch_norm_backward_default_128[0]
        getitem_1786 = native_batch_norm_backward_default_128[1]
        getitem_1787 = native_batch_norm_backward_default_128[2];  native_batch_norm_backward_default_128 = None
        convolution_backward_default_238 = torch.ops.aten.convolution_backward.default(getitem_1785, convolution_default_133, primals_469, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1785 = convolution_default_133 = primals_469 = None
        getitem_1788 = convolution_backward_default_238[0]
        getitem_1789 = convolution_backward_default_238[1]
        getitem_1790 = convolution_backward_default_238[2];  convolution_backward_default_238 = None
        convolution_backward_default_239 = torch.ops.aten.convolution_backward.default(getitem_1788, relu_default_70, primals_468, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_1788 = primals_468 = None
        getitem_1791 = convolution_backward_default_239[0]
        getitem_1792 = convolution_backward_default_239[1]
        getitem_1793 = convolution_backward_default_239[2];  convolution_backward_default_239 = None
        to_dtype_387 = torch.ops.aten.to.dtype(getitem_1791, torch.float32);  getitem_1791 = None
        to_dtype_388 = torch.ops.aten.to.dtype(relu_default_70, torch.float32);  relu_default_70 = None
        le_scalar_129 = torch.ops.aten.le.Scalar(to_dtype_388, 0);  to_dtype_388 = None
        new_zeros_default_330 = torch.ops.aten.new_zeros.default(to_dtype_387, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_129 = torch.ops.aten.where.self(le_scalar_129, new_zeros_default_330, to_dtype_387);  le_scalar_129 = new_zeros_default_330 = to_dtype_387 = None
        to_dtype_389 = torch.ops.aten.to.dtype(where_self_129, torch.float32);  where_self_129 = None
        native_batch_norm_backward_default_129 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_389, convolution_default_132, primals_460, primals_458, primals_459, getitem_244, getitem_245, True, 0.001, [True, True, True]);  to_dtype_389 = convolution_default_132 = primals_460 = primals_458 = primals_459 = getitem_244 = getitem_245 = None
        getitem_1794 = native_batch_norm_backward_default_129[0]
        getitem_1795 = native_batch_norm_backward_default_129[1]
        getitem_1796 = native_batch_norm_backward_default_129[2];  native_batch_norm_backward_default_129 = None
        convolution_backward_default_240 = torch.ops.aten.convolution_backward.default(getitem_1794, convolution_default_131, primals_467, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1794 = convolution_default_131 = primals_467 = None
        getitem_1797 = convolution_backward_default_240[0]
        getitem_1798 = convolution_backward_default_240[1]
        getitem_1799 = convolution_backward_default_240[2];  convolution_backward_default_240 = None
        convolution_backward_default_241 = torch.ops.aten.convolution_backward.default(getitem_1797, relu_default_69, primals_466, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_1797 = primals_466 = None
        getitem_1800 = convolution_backward_default_241[0]
        getitem_1801 = convolution_backward_default_241[1]
        getitem_1802 = convolution_backward_default_241[2];  convolution_backward_default_241 = None
        to_dtype_390 = torch.ops.aten.to.dtype(getitem_1800, torch.float32);  getitem_1800 = None
        to_dtype_391 = torch.ops.aten.to.dtype(relu_default_69, torch.float32);  relu_default_69 = None
        le_scalar_130 = torch.ops.aten.le.Scalar(to_dtype_391, 0);  to_dtype_391 = None
        new_zeros_default_331 = torch.ops.aten.new_zeros.default(to_dtype_390, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_130 = torch.ops.aten.where.self(le_scalar_130, new_zeros_default_331, to_dtype_390);  le_scalar_130 = new_zeros_default_331 = to_dtype_390 = None
        to_dtype_392 = torch.ops.aten.to.dtype(where_self_130, torch.float32);  where_self_130 = None
        max_pool2d_with_indices_backward_default_27 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_52, getitem_204, [3, 3], [1, 1], [1, 1], [1, 1], False, getitem_242);  getitem_242 = None
        add_tensor_153 = torch.ops.aten.add.Tensor(slice_tensor_53, max_pool2d_with_indices_backward_default_27);  slice_tensor_53 = max_pool2d_with_indices_backward_default_27 = None
        clone_default_39 = torch.ops.aten.clone.default(slice_tensor_52, memory_format = torch.contiguous_format);  slice_tensor_52 = None
        native_batch_norm_backward_default_130 = torch.ops.aten.native_batch_norm_backward.default(clone_default_39, convolution_default_130, primals_451, primals_449, primals_450, getitem_239, getitem_240, True, 0.001, [True, True, True]);  clone_default_39 = convolution_default_130 = primals_451 = primals_449 = primals_450 = getitem_239 = getitem_240 = None
        getitem_1803 = native_batch_norm_backward_default_130[0]
        getitem_1804 = native_batch_norm_backward_default_130[1]
        getitem_1805 = native_batch_norm_backward_default_130[2];  native_batch_norm_backward_default_130 = None
        convolution_backward_default_242 = torch.ops.aten.convolution_backward.default(getitem_1803, convolution_default_129, primals_455, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1803 = convolution_default_129 = primals_455 = None
        getitem_1806 = convolution_backward_default_242[0]
        getitem_1807 = convolution_backward_default_242[1]
        getitem_1808 = convolution_backward_default_242[2];  convolution_backward_default_242 = None
        convolution_backward_default_243 = torch.ops.aten.convolution_backward.default(getitem_1806, relu_default_68, primals_454, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_1806 = primals_454 = None
        getitem_1809 = convolution_backward_default_243[0]
        getitem_1810 = convolution_backward_default_243[1]
        getitem_1811 = convolution_backward_default_243[2];  convolution_backward_default_243 = None
        to_dtype_393 = torch.ops.aten.to.dtype(getitem_1809, torch.float32);  getitem_1809 = None
        to_dtype_394 = torch.ops.aten.to.dtype(relu_default_68, torch.float32);  relu_default_68 = None
        le_scalar_131 = torch.ops.aten.le.Scalar(to_dtype_394, 0);  to_dtype_394 = None
        new_zeros_default_332 = torch.ops.aten.new_zeros.default(to_dtype_393, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_131 = torch.ops.aten.where.self(le_scalar_131, new_zeros_default_332, to_dtype_393);  le_scalar_131 = new_zeros_default_332 = to_dtype_393 = None
        to_dtype_395 = torch.ops.aten.to.dtype(where_self_131, torch.float32);  where_self_131 = None
        native_batch_norm_backward_default_131 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_395, convolution_default_128, primals_446, primals_444, primals_445, getitem_236, getitem_237, True, 0.001, [True, True, True]);  to_dtype_395 = convolution_default_128 = primals_446 = primals_444 = primals_445 = getitem_236 = getitem_237 = None
        getitem_1812 = native_batch_norm_backward_default_131[0]
        getitem_1813 = native_batch_norm_backward_default_131[1]
        getitem_1814 = native_batch_norm_backward_default_131[2];  native_batch_norm_backward_default_131 = None
        convolution_backward_default_244 = torch.ops.aten.convolution_backward.default(getitem_1812, convolution_default_127, primals_453, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1812 = convolution_default_127 = primals_453 = None
        getitem_1815 = convolution_backward_default_244[0]
        getitem_1816 = convolution_backward_default_244[1]
        getitem_1817 = convolution_backward_default_244[2];  convolution_backward_default_244 = None
        convolution_backward_default_245 = torch.ops.aten.convolution_backward.default(getitem_1815, relu_default_67, primals_452, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_1815 = primals_452 = None
        getitem_1818 = convolution_backward_default_245[0]
        getitem_1819 = convolution_backward_default_245[1]
        getitem_1820 = convolution_backward_default_245[2];  convolution_backward_default_245 = None
        to_dtype_396 = torch.ops.aten.to.dtype(getitem_1818, torch.float32);  getitem_1818 = None
        to_dtype_397 = torch.ops.aten.to.dtype(relu_default_67, torch.float32);  relu_default_67 = None
        le_scalar_132 = torch.ops.aten.le.Scalar(to_dtype_397, 0);  to_dtype_397 = None
        new_zeros_default_333 = torch.ops.aten.new_zeros.default(to_dtype_396, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_132 = torch.ops.aten.where.self(le_scalar_132, new_zeros_default_333, to_dtype_396);  le_scalar_132 = new_zeros_default_333 = to_dtype_396 = None
        to_dtype_398 = torch.ops.aten.to.dtype(where_self_132, torch.float32);  where_self_132 = None
        add_tensor_154 = torch.ops.aten.add.Tensor(slice_tensor_51, to_dtype_398);  slice_tensor_51 = to_dtype_398 = None
        native_batch_norm_backward_default_132 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_154, convolution_default_126, primals_437, primals_435, primals_436, getitem_233, getitem_234, True, 0.001, [True, True, True]);  convolution_default_126 = primals_437 = primals_435 = primals_436 = getitem_233 = getitem_234 = None
        getitem_1821 = native_batch_norm_backward_default_132[0]
        getitem_1822 = native_batch_norm_backward_default_132[1]
        getitem_1823 = native_batch_norm_backward_default_132[2];  native_batch_norm_backward_default_132 = None
        convolution_backward_default_246 = torch.ops.aten.convolution_backward.default(getitem_1821, convolution_default_125, primals_441, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1821 = convolution_default_125 = primals_441 = None
        getitem_1824 = convolution_backward_default_246[0]
        getitem_1825 = convolution_backward_default_246[1]
        getitem_1826 = convolution_backward_default_246[2];  convolution_backward_default_246 = None
        convolution_backward_default_247 = torch.ops.aten.convolution_backward.default(getitem_1824, relu_default_66, primals_440, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_1824 = primals_440 = None
        getitem_1827 = convolution_backward_default_247[0]
        getitem_1828 = convolution_backward_default_247[1]
        getitem_1829 = convolution_backward_default_247[2];  convolution_backward_default_247 = None
        to_dtype_399 = torch.ops.aten.to.dtype(getitem_1827, torch.float32);  getitem_1827 = None
        to_dtype_400 = torch.ops.aten.to.dtype(relu_default_66, torch.float32);  relu_default_66 = None
        le_scalar_133 = torch.ops.aten.le.Scalar(to_dtype_400, 0);  to_dtype_400 = None
        new_zeros_default_334 = torch.ops.aten.new_zeros.default(to_dtype_399, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_133 = torch.ops.aten.where.self(le_scalar_133, new_zeros_default_334, to_dtype_399);  le_scalar_133 = new_zeros_default_334 = to_dtype_399 = None
        to_dtype_401 = torch.ops.aten.to.dtype(where_self_133, torch.float32);  where_self_133 = None
        native_batch_norm_backward_default_133 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_401, convolution_default_124, primals_432, primals_430, primals_431, getitem_230, getitem_231, True, 0.001, [True, True, True]);  to_dtype_401 = convolution_default_124 = primals_432 = primals_430 = primals_431 = getitem_230 = getitem_231 = None
        getitem_1830 = native_batch_norm_backward_default_133[0]
        getitem_1831 = native_batch_norm_backward_default_133[1]
        getitem_1832 = native_batch_norm_backward_default_133[2];  native_batch_norm_backward_default_133 = None
        convolution_backward_default_248 = torch.ops.aten.convolution_backward.default(getitem_1830, convolution_default_123, primals_439, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1830 = convolution_default_123 = primals_439 = None
        getitem_1833 = convolution_backward_default_248[0]
        getitem_1834 = convolution_backward_default_248[1]
        getitem_1835 = convolution_backward_default_248[2];  convolution_backward_default_248 = None
        convolution_backward_default_249 = torch.ops.aten.convolution_backward.default(getitem_1833, relu_default_65, primals_438, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_1833 = primals_438 = None
        getitem_1836 = convolution_backward_default_249[0]
        getitem_1837 = convolution_backward_default_249[1]
        getitem_1838 = convolution_backward_default_249[2];  convolution_backward_default_249 = None
        to_dtype_402 = torch.ops.aten.to.dtype(getitem_1836, torch.float32);  getitem_1836 = None
        to_dtype_403 = torch.ops.aten.to.dtype(relu_default_65, torch.float32);  relu_default_65 = None
        le_scalar_134 = torch.ops.aten.le.Scalar(to_dtype_403, 0);  to_dtype_403 = None
        new_zeros_default_335 = torch.ops.aten.new_zeros.default(to_dtype_402, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_134 = torch.ops.aten.where.self(le_scalar_134, new_zeros_default_335, to_dtype_402);  le_scalar_134 = new_zeros_default_335 = to_dtype_402 = None
        to_dtype_404 = torch.ops.aten.to.dtype(where_self_134, torch.float32);  where_self_134 = None
        add_tensor_155 = torch.ops.aten.add.Tensor(add_tensor_153, to_dtype_404);  add_tensor_153 = to_dtype_404 = None
        native_batch_norm_backward_default_134 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_154, convolution_default_122, primals_423, primals_421, primals_422, getitem_227, getitem_228, True, 0.001, [True, True, True]);  add_tensor_154 = convolution_default_122 = primals_423 = primals_421 = primals_422 = getitem_227 = getitem_228 = None
        getitem_1839 = native_batch_norm_backward_default_134[0]
        getitem_1840 = native_batch_norm_backward_default_134[1]
        getitem_1841 = native_batch_norm_backward_default_134[2];  native_batch_norm_backward_default_134 = None
        convolution_backward_default_250 = torch.ops.aten.convolution_backward.default(getitem_1839, convolution_default_121, primals_427, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1839 = convolution_default_121 = primals_427 = None
        getitem_1842 = convolution_backward_default_250[0]
        getitem_1843 = convolution_backward_default_250[1]
        getitem_1844 = convolution_backward_default_250[2];  convolution_backward_default_250 = None
        convolution_backward_default_251 = torch.ops.aten.convolution_backward.default(getitem_1842, relu_default_64, primals_426, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_1842 = primals_426 = None
        getitem_1845 = convolution_backward_default_251[0]
        getitem_1846 = convolution_backward_default_251[1]
        getitem_1847 = convolution_backward_default_251[2];  convolution_backward_default_251 = None
        to_dtype_405 = torch.ops.aten.to.dtype(getitem_1845, torch.float32);  getitem_1845 = None
        to_dtype_406 = torch.ops.aten.to.dtype(relu_default_64, torch.float32);  relu_default_64 = None
        le_scalar_135 = torch.ops.aten.le.Scalar(to_dtype_406, 0);  to_dtype_406 = None
        new_zeros_default_336 = torch.ops.aten.new_zeros.default(to_dtype_405, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_135 = torch.ops.aten.where.self(le_scalar_135, new_zeros_default_336, to_dtype_405);  le_scalar_135 = new_zeros_default_336 = to_dtype_405 = None
        to_dtype_407 = torch.ops.aten.to.dtype(where_self_135, torch.float32);  where_self_135 = None
        native_batch_norm_backward_default_135 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_407, convolution_default_120, primals_418, primals_416, primals_417, getitem_224, getitem_225, True, 0.001, [True, True, True]);  to_dtype_407 = convolution_default_120 = primals_418 = primals_416 = primals_417 = getitem_224 = getitem_225 = None
        getitem_1848 = native_batch_norm_backward_default_135[0]
        getitem_1849 = native_batch_norm_backward_default_135[1]
        getitem_1850 = native_batch_norm_backward_default_135[2];  native_batch_norm_backward_default_135 = None
        convolution_backward_default_252 = torch.ops.aten.convolution_backward.default(getitem_1848, convolution_default_119, primals_425, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1848 = convolution_default_119 = primals_425 = None
        getitem_1851 = convolution_backward_default_252[0]
        getitem_1852 = convolution_backward_default_252[1]
        getitem_1853 = convolution_backward_default_252[2];  convolution_backward_default_252 = None
        convolution_backward_default_253 = torch.ops.aten.convolution_backward.default(getitem_1851, relu_default_63, primals_424, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_1851 = primals_424 = None
        getitem_1854 = convolution_backward_default_253[0]
        getitem_1855 = convolution_backward_default_253[1]
        getitem_1856 = convolution_backward_default_253[2];  convolution_backward_default_253 = None
        to_dtype_408 = torch.ops.aten.to.dtype(getitem_1854, torch.float32);  getitem_1854 = None
        to_dtype_409 = torch.ops.aten.to.dtype(relu_default_63, torch.float32);  relu_default_63 = None
        le_scalar_136 = torch.ops.aten.le.Scalar(to_dtype_409, 0);  to_dtype_409 = None
        new_zeros_default_337 = torch.ops.aten.new_zeros.default(to_dtype_408, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_136 = torch.ops.aten.where.self(le_scalar_136, new_zeros_default_337, to_dtype_408);  le_scalar_136 = new_zeros_default_337 = to_dtype_408 = None
        to_dtype_410 = torch.ops.aten.to.dtype(where_self_136, torch.float32);  where_self_136 = None
        add_tensor_156 = torch.ops.aten.add.Tensor(add_tensor_155, to_dtype_410);  add_tensor_155 = to_dtype_410 = None
        max_pool2d_with_indices_backward_default_28 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_50, getitem_204, [3, 3], [1, 1], [1, 1], [1, 1], False, getitem_222);  getitem_204 = getitem_222 = None
        add_tensor_157 = torch.ops.aten.add.Tensor(add_tensor_156, max_pool2d_with_indices_backward_default_28);  add_tensor_156 = max_pool2d_with_indices_backward_default_28 = None
        clone_default_40 = torch.ops.aten.clone.default(slice_tensor_50, memory_format = torch.contiguous_format);  slice_tensor_50 = None
        native_batch_norm_backward_default_136 = torch.ops.aten.native_batch_norm_backward.default(clone_default_40, convolution_default_118, primals_409, primals_407, primals_408, getitem_219, getitem_220, True, 0.001, [True, True, True]);  clone_default_40 = convolution_default_118 = primals_409 = primals_407 = primals_408 = getitem_219 = getitem_220 = None
        getitem_1857 = native_batch_norm_backward_default_136[0]
        getitem_1858 = native_batch_norm_backward_default_136[1]
        getitem_1859 = native_batch_norm_backward_default_136[2];  native_batch_norm_backward_default_136 = None
        convolution_backward_default_254 = torch.ops.aten.convolution_backward.default(getitem_1857, convolution_default_117, primals_413, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1857 = convolution_default_117 = primals_413 = None
        getitem_1860 = convolution_backward_default_254[0]
        getitem_1861 = convolution_backward_default_254[1]
        getitem_1862 = convolution_backward_default_254[2];  convolution_backward_default_254 = None
        convolution_backward_default_255 = torch.ops.aten.convolution_backward.default(getitem_1860, relu_default_62, primals_412, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_1860 = primals_412 = None
        getitem_1863 = convolution_backward_default_255[0]
        getitem_1864 = convolution_backward_default_255[1]
        getitem_1865 = convolution_backward_default_255[2];  convolution_backward_default_255 = None
        to_dtype_411 = torch.ops.aten.to.dtype(getitem_1863, torch.float32);  getitem_1863 = None
        to_dtype_412 = torch.ops.aten.to.dtype(relu_default_62, torch.float32);  relu_default_62 = None
        le_scalar_137 = torch.ops.aten.le.Scalar(to_dtype_412, 0);  to_dtype_412 = None
        new_zeros_default_338 = torch.ops.aten.new_zeros.default(to_dtype_411, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_137 = torch.ops.aten.where.self(le_scalar_137, new_zeros_default_338, to_dtype_411);  le_scalar_137 = new_zeros_default_338 = to_dtype_411 = None
        to_dtype_413 = torch.ops.aten.to.dtype(where_self_137, torch.float32);  where_self_137 = None
        native_batch_norm_backward_default_137 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_413, convolution_default_116, primals_404, primals_402, primals_403, getitem_216, getitem_217, True, 0.001, [True, True, True]);  to_dtype_413 = convolution_default_116 = primals_404 = primals_402 = primals_403 = getitem_216 = getitem_217 = None
        getitem_1866 = native_batch_norm_backward_default_137[0]
        getitem_1867 = native_batch_norm_backward_default_137[1]
        getitem_1868 = native_batch_norm_backward_default_137[2];  native_batch_norm_backward_default_137 = None
        convolution_backward_default_256 = torch.ops.aten.convolution_backward.default(getitem_1866, convolution_default_115, primals_411, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1866 = convolution_default_115 = primals_411 = None
        getitem_1869 = convolution_backward_default_256[0]
        getitem_1870 = convolution_backward_default_256[1]
        getitem_1871 = convolution_backward_default_256[2];  convolution_backward_default_256 = None
        convolution_backward_default_257 = torch.ops.aten.convolution_backward.default(getitem_1869, relu_default_61, primals_410, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_1869 = primals_410 = None
        getitem_1872 = convolution_backward_default_257[0]
        getitem_1873 = convolution_backward_default_257[1]
        getitem_1874 = convolution_backward_default_257[2];  convolution_backward_default_257 = None
        to_dtype_414 = torch.ops.aten.to.dtype(getitem_1872, torch.float32);  getitem_1872 = None
        to_dtype_415 = torch.ops.aten.to.dtype(relu_default_61, torch.float32);  relu_default_61 = None
        le_scalar_138 = torch.ops.aten.le.Scalar(to_dtype_415, 0);  to_dtype_415 = None
        new_zeros_default_339 = torch.ops.aten.new_zeros.default(to_dtype_414, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_138 = torch.ops.aten.where.self(le_scalar_138, new_zeros_default_339, to_dtype_414);  le_scalar_138 = new_zeros_default_339 = to_dtype_414 = None
        to_dtype_416 = torch.ops.aten.to.dtype(where_self_138, torch.float32);  where_self_138 = None
        add_tensor_158 = torch.ops.aten.add.Tensor(add_tensor_157, to_dtype_416);  add_tensor_157 = to_dtype_416 = None
        max_pool2d_with_indices_backward_default_29 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_49, getitem_201, [3, 3], [1, 1], [1, 1], [1, 1], False, getitem_214);  getitem_201 = getitem_214 = None
        add_tensor_159 = torch.ops.aten.add.Tensor(to_dtype_392, max_pool2d_with_indices_backward_default_29);  to_dtype_392 = max_pool2d_with_indices_backward_default_29 = None
        clone_default_41 = torch.ops.aten.clone.default(slice_tensor_49, memory_format = torch.contiguous_format);  slice_tensor_49 = None
        native_batch_norm_backward_default_138 = torch.ops.aten.native_batch_norm_backward.default(clone_default_41, convolution_default_114, primals_395, primals_393, primals_394, getitem_211, getitem_212, True, 0.001, [True, True, True]);  clone_default_41 = convolution_default_114 = primals_395 = primals_393 = primals_394 = getitem_211 = getitem_212 = None
        getitem_1875 = native_batch_norm_backward_default_138[0]
        getitem_1876 = native_batch_norm_backward_default_138[1]
        getitem_1877 = native_batch_norm_backward_default_138[2];  native_batch_norm_backward_default_138 = None
        convolution_backward_default_258 = torch.ops.aten.convolution_backward.default(getitem_1875, convolution_default_113, primals_399, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1875 = convolution_default_113 = primals_399 = None
        getitem_1878 = convolution_backward_default_258[0]
        getitem_1879 = convolution_backward_default_258[1]
        getitem_1880 = convolution_backward_default_258[2];  convolution_backward_default_258 = None
        convolution_backward_default_259 = torch.ops.aten.convolution_backward.default(getitem_1878, relu_default_60, primals_398, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_1878 = primals_398 = None
        getitem_1881 = convolution_backward_default_259[0]
        getitem_1882 = convolution_backward_default_259[1]
        getitem_1883 = convolution_backward_default_259[2];  convolution_backward_default_259 = None
        to_dtype_417 = torch.ops.aten.to.dtype(getitem_1881, torch.float32);  getitem_1881 = None
        to_dtype_418 = torch.ops.aten.to.dtype(relu_default_60, torch.float32);  relu_default_60 = None
        le_scalar_139 = torch.ops.aten.le.Scalar(to_dtype_418, 0);  to_dtype_418 = None
        new_zeros_default_340 = torch.ops.aten.new_zeros.default(to_dtype_417, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_139 = torch.ops.aten.where.self(le_scalar_139, new_zeros_default_340, to_dtype_417);  le_scalar_139 = new_zeros_default_340 = to_dtype_417 = None
        to_dtype_419 = torch.ops.aten.to.dtype(where_self_139, torch.float32);  where_self_139 = None
        native_batch_norm_backward_default_139 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_419, convolution_default_112, primals_390, primals_388, primals_389, getitem_208, getitem_209, True, 0.001, [True, True, True]);  to_dtype_419 = convolution_default_112 = primals_390 = primals_388 = primals_389 = getitem_208 = getitem_209 = None
        getitem_1884 = native_batch_norm_backward_default_139[0]
        getitem_1885 = native_batch_norm_backward_default_139[1]
        getitem_1886 = native_batch_norm_backward_default_139[2];  native_batch_norm_backward_default_139 = None
        convolution_backward_default_260 = torch.ops.aten.convolution_backward.default(getitem_1884, convolution_default_111, primals_397, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1884 = convolution_default_111 = primals_397 = None
        getitem_1887 = convolution_backward_default_260[0]
        getitem_1888 = convolution_backward_default_260[1]
        getitem_1889 = convolution_backward_default_260[2];  convolution_backward_default_260 = None
        convolution_backward_default_261 = torch.ops.aten.convolution_backward.default(getitem_1887, relu_default_59, primals_396, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_1887 = primals_396 = None
        getitem_1890 = convolution_backward_default_261[0]
        getitem_1891 = convolution_backward_default_261[1]
        getitem_1892 = convolution_backward_default_261[2];  convolution_backward_default_261 = None
        to_dtype_420 = torch.ops.aten.to.dtype(getitem_1890, torch.float32);  getitem_1890 = None
        to_dtype_421 = torch.ops.aten.to.dtype(relu_default_59, torch.float32);  relu_default_59 = None
        le_scalar_140 = torch.ops.aten.le.Scalar(to_dtype_421, 0);  to_dtype_421 = None
        new_zeros_default_341 = torch.ops.aten.new_zeros.default(to_dtype_420, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_140 = torch.ops.aten.where.self(le_scalar_140, new_zeros_default_341, to_dtype_420);  le_scalar_140 = new_zeros_default_341 = to_dtype_420 = None
        to_dtype_422 = torch.ops.aten.to.dtype(where_self_140, torch.float32);  where_self_140 = None
        add_tensor_160 = torch.ops.aten.add.Tensor(add_tensor_159, to_dtype_422);  add_tensor_159 = to_dtype_422 = None
        native_batch_norm_backward_default_140 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_158, convolution_default_110, primals_474, primals_472, primals_473, getitem_205, getitem_206, True, 0.001, [True, True, True]);  add_tensor_158 = convolution_default_110 = primals_474 = primals_472 = primals_473 = getitem_205 = getitem_206 = None
        getitem_1893 = native_batch_norm_backward_default_140[0]
        getitem_1894 = native_batch_norm_backward_default_140[1]
        getitem_1895 = native_batch_norm_backward_default_140[2];  native_batch_norm_backward_default_140 = None
        convolution_backward_default_262 = torch.ops.aten.convolution_backward.default(getitem_1893, relu_default_58, primals_475, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1893 = primals_475 = None
        getitem_1896 = convolution_backward_default_262[0]
        getitem_1897 = convolution_backward_default_262[1]
        getitem_1898 = convolution_backward_default_262[2];  convolution_backward_default_262 = None
        to_dtype_423 = torch.ops.aten.to.dtype(getitem_1896, torch.float32);  getitem_1896 = None
        to_dtype_424 = torch.ops.aten.to.dtype(relu_default_58, torch.float32);  relu_default_58 = None
        le_scalar_141 = torch.ops.aten.le.Scalar(to_dtype_424, 0);  to_dtype_424 = None
        new_zeros_default_342 = torch.ops.aten.new_zeros.default(to_dtype_423, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_141 = torch.ops.aten.where.self(le_scalar_141, new_zeros_default_342, to_dtype_423);  le_scalar_141 = new_zeros_default_342 = to_dtype_423 = None
        to_dtype_425 = torch.ops.aten.to.dtype(where_self_141, torch.float32);  where_self_141 = None
        add_tensor_161 = torch.ops.aten.add.Tensor(to_dtype_386, to_dtype_425);  to_dtype_386 = to_dtype_425 = None
        native_batch_norm_backward_default_141 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_160, convolution_default_109, primals_480, primals_478, primals_479, getitem_202, getitem_203, True, 0.001, [True, True, True]);  add_tensor_160 = convolution_default_109 = primals_480 = primals_478 = primals_479 = getitem_202 = getitem_203 = None
        getitem_1899 = native_batch_norm_backward_default_141[0]
        getitem_1900 = native_batch_norm_backward_default_141[1]
        getitem_1901 = native_batch_norm_backward_default_141[2];  native_batch_norm_backward_default_141 = None
        convolution_backward_default_263 = torch.ops.aten.convolution_backward.default(getitem_1899, relu_default_57, primals_481, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1899 = primals_481 = None
        getitem_1902 = convolution_backward_default_263[0]
        getitem_1903 = convolution_backward_default_263[1]
        getitem_1904 = convolution_backward_default_263[2];  convolution_backward_default_263 = None
        to_dtype_426 = torch.ops.aten.to.dtype(getitem_1902, torch.float32);  getitem_1902 = None
        to_dtype_427 = torch.ops.aten.to.dtype(relu_default_57, torch.float32);  relu_default_57 = None
        le_scalar_142 = torch.ops.aten.le.Scalar(to_dtype_427, 0);  to_dtype_427 = None
        new_zeros_default_343 = torch.ops.aten.new_zeros.default(to_dtype_426, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_142 = torch.ops.aten.where.self(le_scalar_142, new_zeros_default_343, to_dtype_426);  le_scalar_142 = new_zeros_default_343 = to_dtype_426 = None
        to_dtype_428 = torch.ops.aten.to.dtype(where_self_142, torch.float32);  where_self_142 = None
        slice_tensor_54 = torch.ops.aten.slice.Tensor(add_tensor_161, 1, 0, 216)
        slice_tensor_55 = torch.ops.aten.slice.Tensor(add_tensor_161, 1, 216, 432)
        slice_tensor_56 = torch.ops.aten.slice.Tensor(add_tensor_161, 1, 432, 648)
        slice_tensor_57 = torch.ops.aten.slice.Tensor(add_tensor_161, 1, 648, 864)
        slice_tensor_58 = torch.ops.aten.slice.Tensor(add_tensor_161, 1, 864, 1080);  add_tensor_161 = None
        clone_default_42 = torch.ops.aten.clone.default(slice_tensor_58, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_142 = torch.ops.aten.native_batch_norm_backward.default(clone_default_42, convolution_default_108, primals_369, primals_367, primals_368, getitem_199, getitem_200, True, 0.001, [True, True, True]);  clone_default_42 = convolution_default_108 = primals_369 = primals_367 = primals_368 = getitem_199 = getitem_200 = None
        getitem_1905 = native_batch_norm_backward_default_142[0]
        getitem_1906 = native_batch_norm_backward_default_142[1]
        getitem_1907 = native_batch_norm_backward_default_142[2];  native_batch_norm_backward_default_142 = None
        convolution_backward_default_264 = torch.ops.aten.convolution_backward.default(getitem_1905, convolution_default_107, primals_373, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1905 = convolution_default_107 = primals_373 = None
        getitem_1908 = convolution_backward_default_264[0]
        getitem_1909 = convolution_backward_default_264[1]
        getitem_1910 = convolution_backward_default_264[2];  convolution_backward_default_264 = None
        convolution_backward_default_265 = torch.ops.aten.convolution_backward.default(getitem_1908, relu_default_56, primals_372, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_1908 = primals_372 = None
        getitem_1911 = convolution_backward_default_265[0]
        getitem_1912 = convolution_backward_default_265[1]
        getitem_1913 = convolution_backward_default_265[2];  convolution_backward_default_265 = None
        to_dtype_429 = torch.ops.aten.to.dtype(getitem_1911, torch.float32);  getitem_1911 = None
        to_dtype_430 = torch.ops.aten.to.dtype(relu_default_56, torch.float32);  relu_default_56 = None
        le_scalar_143 = torch.ops.aten.le.Scalar(to_dtype_430, 0);  to_dtype_430 = None
        new_zeros_default_344 = torch.ops.aten.new_zeros.default(to_dtype_429, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_143 = torch.ops.aten.where.self(le_scalar_143, new_zeros_default_344, to_dtype_429);  le_scalar_143 = new_zeros_default_344 = to_dtype_429 = None
        to_dtype_431 = torch.ops.aten.to.dtype(where_self_143, torch.float32);  where_self_143 = None
        native_batch_norm_backward_default_143 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_431, convolution_default_106, primals_364, primals_362, primals_363, getitem_196, getitem_197, True, 0.001, [True, True, True]);  to_dtype_431 = convolution_default_106 = primals_364 = primals_362 = primals_363 = getitem_196 = getitem_197 = None
        getitem_1914 = native_batch_norm_backward_default_143[0]
        getitem_1915 = native_batch_norm_backward_default_143[1]
        getitem_1916 = native_batch_norm_backward_default_143[2];  native_batch_norm_backward_default_143 = None
        convolution_backward_default_266 = torch.ops.aten.convolution_backward.default(getitem_1914, convolution_default_105, primals_371, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1914 = convolution_default_105 = primals_371 = None
        getitem_1917 = convolution_backward_default_266[0]
        getitem_1918 = convolution_backward_default_266[1]
        getitem_1919 = convolution_backward_default_266[2];  convolution_backward_default_266 = None
        convolution_backward_default_267 = torch.ops.aten.convolution_backward.default(getitem_1917, relu_default_55, primals_370, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_1917 = primals_370 = None
        getitem_1920 = convolution_backward_default_267[0]
        getitem_1921 = convolution_backward_default_267[1]
        getitem_1922 = convolution_backward_default_267[2];  convolution_backward_default_267 = None
        to_dtype_432 = torch.ops.aten.to.dtype(getitem_1920, torch.float32);  getitem_1920 = None
        to_dtype_433 = torch.ops.aten.to.dtype(relu_default_55, torch.float32);  relu_default_55 = None
        le_scalar_144 = torch.ops.aten.le.Scalar(to_dtype_433, 0);  to_dtype_433 = None
        new_zeros_default_345 = torch.ops.aten.new_zeros.default(to_dtype_432, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_144 = torch.ops.aten.where.self(le_scalar_144, new_zeros_default_345, to_dtype_432);  le_scalar_144 = new_zeros_default_345 = to_dtype_432 = None
        to_dtype_434 = torch.ops.aten.to.dtype(where_self_144, torch.float32);  where_self_144 = None
        max_pool2d_with_indices_backward_default_30 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_57, getitem_156, [3, 3], [1, 1], [1, 1], [1, 1], False, getitem_194);  getitem_194 = None
        add_tensor_162 = torch.ops.aten.add.Tensor(slice_tensor_58, max_pool2d_with_indices_backward_default_30);  slice_tensor_58 = max_pool2d_with_indices_backward_default_30 = None
        clone_default_43 = torch.ops.aten.clone.default(slice_tensor_57, memory_format = torch.contiguous_format);  slice_tensor_57 = None
        native_batch_norm_backward_default_144 = torch.ops.aten.native_batch_norm_backward.default(clone_default_43, convolution_default_104, primals_355, primals_353, primals_354, getitem_191, getitem_192, True, 0.001, [True, True, True]);  clone_default_43 = convolution_default_104 = primals_355 = primals_353 = primals_354 = getitem_191 = getitem_192 = None
        getitem_1923 = native_batch_norm_backward_default_144[0]
        getitem_1924 = native_batch_norm_backward_default_144[1]
        getitem_1925 = native_batch_norm_backward_default_144[2];  native_batch_norm_backward_default_144 = None
        convolution_backward_default_268 = torch.ops.aten.convolution_backward.default(getitem_1923, convolution_default_103, primals_359, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1923 = convolution_default_103 = primals_359 = None
        getitem_1926 = convolution_backward_default_268[0]
        getitem_1927 = convolution_backward_default_268[1]
        getitem_1928 = convolution_backward_default_268[2];  convolution_backward_default_268 = None
        convolution_backward_default_269 = torch.ops.aten.convolution_backward.default(getitem_1926, relu_default_54, primals_358, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_1926 = primals_358 = None
        getitem_1929 = convolution_backward_default_269[0]
        getitem_1930 = convolution_backward_default_269[1]
        getitem_1931 = convolution_backward_default_269[2];  convolution_backward_default_269 = None
        to_dtype_435 = torch.ops.aten.to.dtype(getitem_1929, torch.float32);  getitem_1929 = None
        to_dtype_436 = torch.ops.aten.to.dtype(relu_default_54, torch.float32);  relu_default_54 = None
        le_scalar_145 = torch.ops.aten.le.Scalar(to_dtype_436, 0);  to_dtype_436 = None
        new_zeros_default_346 = torch.ops.aten.new_zeros.default(to_dtype_435, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_145 = torch.ops.aten.where.self(le_scalar_145, new_zeros_default_346, to_dtype_435);  le_scalar_145 = new_zeros_default_346 = to_dtype_435 = None
        to_dtype_437 = torch.ops.aten.to.dtype(where_self_145, torch.float32);  where_self_145 = None
        native_batch_norm_backward_default_145 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_437, convolution_default_102, primals_350, primals_348, primals_349, getitem_188, getitem_189, True, 0.001, [True, True, True]);  to_dtype_437 = convolution_default_102 = primals_350 = primals_348 = primals_349 = getitem_188 = getitem_189 = None
        getitem_1932 = native_batch_norm_backward_default_145[0]
        getitem_1933 = native_batch_norm_backward_default_145[1]
        getitem_1934 = native_batch_norm_backward_default_145[2];  native_batch_norm_backward_default_145 = None
        convolution_backward_default_270 = torch.ops.aten.convolution_backward.default(getitem_1932, convolution_default_101, primals_357, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1932 = convolution_default_101 = primals_357 = None
        getitem_1935 = convolution_backward_default_270[0]
        getitem_1936 = convolution_backward_default_270[1]
        getitem_1937 = convolution_backward_default_270[2];  convolution_backward_default_270 = None
        convolution_backward_default_271 = torch.ops.aten.convolution_backward.default(getitem_1935, relu_default_53, primals_356, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_1935 = primals_356 = None
        getitem_1938 = convolution_backward_default_271[0]
        getitem_1939 = convolution_backward_default_271[1]
        getitem_1940 = convolution_backward_default_271[2];  convolution_backward_default_271 = None
        to_dtype_438 = torch.ops.aten.to.dtype(getitem_1938, torch.float32);  getitem_1938 = None
        to_dtype_439 = torch.ops.aten.to.dtype(relu_default_53, torch.float32);  relu_default_53 = None
        le_scalar_146 = torch.ops.aten.le.Scalar(to_dtype_439, 0);  to_dtype_439 = None
        new_zeros_default_347 = torch.ops.aten.new_zeros.default(to_dtype_438, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_146 = torch.ops.aten.where.self(le_scalar_146, new_zeros_default_347, to_dtype_438);  le_scalar_146 = new_zeros_default_347 = to_dtype_438 = None
        to_dtype_440 = torch.ops.aten.to.dtype(where_self_146, torch.float32);  where_self_146 = None
        add_tensor_163 = torch.ops.aten.add.Tensor(slice_tensor_56, to_dtype_440);  slice_tensor_56 = to_dtype_440 = None
        native_batch_norm_backward_default_146 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_163, convolution_default_100, primals_341, primals_339, primals_340, getitem_185, getitem_186, True, 0.001, [True, True, True]);  convolution_default_100 = primals_341 = primals_339 = primals_340 = getitem_185 = getitem_186 = None
        getitem_1941 = native_batch_norm_backward_default_146[0]
        getitem_1942 = native_batch_norm_backward_default_146[1]
        getitem_1943 = native_batch_norm_backward_default_146[2];  native_batch_norm_backward_default_146 = None
        convolution_backward_default_272 = torch.ops.aten.convolution_backward.default(getitem_1941, convolution_default_99, primals_345, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1941 = convolution_default_99 = primals_345 = None
        getitem_1944 = convolution_backward_default_272[0]
        getitem_1945 = convolution_backward_default_272[1]
        getitem_1946 = convolution_backward_default_272[2];  convolution_backward_default_272 = None
        convolution_backward_default_273 = torch.ops.aten.convolution_backward.default(getitem_1944, relu_default_52, primals_344, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_1944 = primals_344 = None
        getitem_1947 = convolution_backward_default_273[0]
        getitem_1948 = convolution_backward_default_273[1]
        getitem_1949 = convolution_backward_default_273[2];  convolution_backward_default_273 = None
        to_dtype_441 = torch.ops.aten.to.dtype(getitem_1947, torch.float32);  getitem_1947 = None
        to_dtype_442 = torch.ops.aten.to.dtype(relu_default_52, torch.float32);  relu_default_52 = None
        le_scalar_147 = torch.ops.aten.le.Scalar(to_dtype_442, 0);  to_dtype_442 = None
        new_zeros_default_348 = torch.ops.aten.new_zeros.default(to_dtype_441, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_147 = torch.ops.aten.where.self(le_scalar_147, new_zeros_default_348, to_dtype_441);  le_scalar_147 = new_zeros_default_348 = to_dtype_441 = None
        to_dtype_443 = torch.ops.aten.to.dtype(where_self_147, torch.float32);  where_self_147 = None
        native_batch_norm_backward_default_147 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_443, convolution_default_98, primals_336, primals_334, primals_335, getitem_182, getitem_183, True, 0.001, [True, True, True]);  to_dtype_443 = convolution_default_98 = primals_336 = primals_334 = primals_335 = getitem_182 = getitem_183 = None
        getitem_1950 = native_batch_norm_backward_default_147[0]
        getitem_1951 = native_batch_norm_backward_default_147[1]
        getitem_1952 = native_batch_norm_backward_default_147[2];  native_batch_norm_backward_default_147 = None
        convolution_backward_default_274 = torch.ops.aten.convolution_backward.default(getitem_1950, convolution_default_97, primals_343, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1950 = convolution_default_97 = primals_343 = None
        getitem_1953 = convolution_backward_default_274[0]
        getitem_1954 = convolution_backward_default_274[1]
        getitem_1955 = convolution_backward_default_274[2];  convolution_backward_default_274 = None
        convolution_backward_default_275 = torch.ops.aten.convolution_backward.default(getitem_1953, relu_default_51, primals_342, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_1953 = primals_342 = None
        getitem_1956 = convolution_backward_default_275[0]
        getitem_1957 = convolution_backward_default_275[1]
        getitem_1958 = convolution_backward_default_275[2];  convolution_backward_default_275 = None
        to_dtype_444 = torch.ops.aten.to.dtype(getitem_1956, torch.float32);  getitem_1956 = None
        to_dtype_445 = torch.ops.aten.to.dtype(relu_default_51, torch.float32);  relu_default_51 = None
        le_scalar_148 = torch.ops.aten.le.Scalar(to_dtype_445, 0);  to_dtype_445 = None
        new_zeros_default_349 = torch.ops.aten.new_zeros.default(to_dtype_444, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_148 = torch.ops.aten.where.self(le_scalar_148, new_zeros_default_349, to_dtype_444);  le_scalar_148 = new_zeros_default_349 = to_dtype_444 = None
        to_dtype_446 = torch.ops.aten.to.dtype(where_self_148, torch.float32);  where_self_148 = None
        add_tensor_164 = torch.ops.aten.add.Tensor(add_tensor_162, to_dtype_446);  add_tensor_162 = to_dtype_446 = None
        native_batch_norm_backward_default_148 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_163, convolution_default_96, primals_327, primals_325, primals_326, getitem_179, getitem_180, True, 0.001, [True, True, True]);  add_tensor_163 = convolution_default_96 = primals_327 = primals_325 = primals_326 = getitem_179 = getitem_180 = None
        getitem_1959 = native_batch_norm_backward_default_148[0]
        getitem_1960 = native_batch_norm_backward_default_148[1]
        getitem_1961 = native_batch_norm_backward_default_148[2];  native_batch_norm_backward_default_148 = None
        convolution_backward_default_276 = torch.ops.aten.convolution_backward.default(getitem_1959, convolution_default_95, primals_331, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1959 = convolution_default_95 = primals_331 = None
        getitem_1962 = convolution_backward_default_276[0]
        getitem_1963 = convolution_backward_default_276[1]
        getitem_1964 = convolution_backward_default_276[2];  convolution_backward_default_276 = None
        convolution_backward_default_277 = torch.ops.aten.convolution_backward.default(getitem_1962, relu_default_50, primals_330, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_1962 = primals_330 = None
        getitem_1965 = convolution_backward_default_277[0]
        getitem_1966 = convolution_backward_default_277[1]
        getitem_1967 = convolution_backward_default_277[2];  convolution_backward_default_277 = None
        to_dtype_447 = torch.ops.aten.to.dtype(getitem_1965, torch.float32);  getitem_1965 = None
        to_dtype_448 = torch.ops.aten.to.dtype(relu_default_50, torch.float32);  relu_default_50 = None
        le_scalar_149 = torch.ops.aten.le.Scalar(to_dtype_448, 0);  to_dtype_448 = None
        new_zeros_default_350 = torch.ops.aten.new_zeros.default(to_dtype_447, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_149 = torch.ops.aten.where.self(le_scalar_149, new_zeros_default_350, to_dtype_447);  le_scalar_149 = new_zeros_default_350 = to_dtype_447 = None
        to_dtype_449 = torch.ops.aten.to.dtype(where_self_149, torch.float32);  where_self_149 = None
        native_batch_norm_backward_default_149 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_449, convolution_default_94, primals_322, primals_320, primals_321, getitem_176, getitem_177, True, 0.001, [True, True, True]);  to_dtype_449 = convolution_default_94 = primals_322 = primals_320 = primals_321 = getitem_176 = getitem_177 = None
        getitem_1968 = native_batch_norm_backward_default_149[0]
        getitem_1969 = native_batch_norm_backward_default_149[1]
        getitem_1970 = native_batch_norm_backward_default_149[2];  native_batch_norm_backward_default_149 = None
        convolution_backward_default_278 = torch.ops.aten.convolution_backward.default(getitem_1968, convolution_default_93, primals_329, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1968 = convolution_default_93 = primals_329 = None
        getitem_1971 = convolution_backward_default_278[0]
        getitem_1972 = convolution_backward_default_278[1]
        getitem_1973 = convolution_backward_default_278[2];  convolution_backward_default_278 = None
        convolution_backward_default_279 = torch.ops.aten.convolution_backward.default(getitem_1971, relu_default_49, primals_328, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_1971 = primals_328 = None
        getitem_1974 = convolution_backward_default_279[0]
        getitem_1975 = convolution_backward_default_279[1]
        getitem_1976 = convolution_backward_default_279[2];  convolution_backward_default_279 = None
        to_dtype_450 = torch.ops.aten.to.dtype(getitem_1974, torch.float32);  getitem_1974 = None
        to_dtype_451 = torch.ops.aten.to.dtype(relu_default_49, torch.float32);  relu_default_49 = None
        le_scalar_150 = torch.ops.aten.le.Scalar(to_dtype_451, 0);  to_dtype_451 = None
        new_zeros_default_351 = torch.ops.aten.new_zeros.default(to_dtype_450, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_150 = torch.ops.aten.where.self(le_scalar_150, new_zeros_default_351, to_dtype_450);  le_scalar_150 = new_zeros_default_351 = to_dtype_450 = None
        to_dtype_452 = torch.ops.aten.to.dtype(where_self_150, torch.float32);  where_self_150 = None
        add_tensor_165 = torch.ops.aten.add.Tensor(add_tensor_164, to_dtype_452);  add_tensor_164 = to_dtype_452 = None
        max_pool2d_with_indices_backward_default_31 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_55, getitem_156, [3, 3], [1, 1], [1, 1], [1, 1], False, getitem_174);  getitem_156 = getitem_174 = None
        add_tensor_166 = torch.ops.aten.add.Tensor(add_tensor_165, max_pool2d_with_indices_backward_default_31);  add_tensor_165 = max_pool2d_with_indices_backward_default_31 = None
        clone_default_44 = torch.ops.aten.clone.default(slice_tensor_55, memory_format = torch.contiguous_format);  slice_tensor_55 = None
        native_batch_norm_backward_default_150 = torch.ops.aten.native_batch_norm_backward.default(clone_default_44, convolution_default_92, primals_313, primals_311, primals_312, getitem_171, getitem_172, True, 0.001, [True, True, True]);  clone_default_44 = convolution_default_92 = primals_313 = primals_311 = primals_312 = getitem_171 = getitem_172 = None
        getitem_1977 = native_batch_norm_backward_default_150[0]
        getitem_1978 = native_batch_norm_backward_default_150[1]
        getitem_1979 = native_batch_norm_backward_default_150[2];  native_batch_norm_backward_default_150 = None
        convolution_backward_default_280 = torch.ops.aten.convolution_backward.default(getitem_1977, convolution_default_91, primals_317, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1977 = convolution_default_91 = primals_317 = None
        getitem_1980 = convolution_backward_default_280[0]
        getitem_1981 = convolution_backward_default_280[1]
        getitem_1982 = convolution_backward_default_280[2];  convolution_backward_default_280 = None
        convolution_backward_default_281 = torch.ops.aten.convolution_backward.default(getitem_1980, relu_default_48, primals_316, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_1980 = primals_316 = None
        getitem_1983 = convolution_backward_default_281[0]
        getitem_1984 = convolution_backward_default_281[1]
        getitem_1985 = convolution_backward_default_281[2];  convolution_backward_default_281 = None
        to_dtype_453 = torch.ops.aten.to.dtype(getitem_1983, torch.float32);  getitem_1983 = None
        to_dtype_454 = torch.ops.aten.to.dtype(relu_default_48, torch.float32);  relu_default_48 = None
        le_scalar_151 = torch.ops.aten.le.Scalar(to_dtype_454, 0);  to_dtype_454 = None
        new_zeros_default_352 = torch.ops.aten.new_zeros.default(to_dtype_453, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_151 = torch.ops.aten.where.self(le_scalar_151, new_zeros_default_352, to_dtype_453);  le_scalar_151 = new_zeros_default_352 = to_dtype_453 = None
        to_dtype_455 = torch.ops.aten.to.dtype(where_self_151, torch.float32);  where_self_151 = None
        native_batch_norm_backward_default_151 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_455, convolution_default_90, primals_308, primals_306, primals_307, getitem_168, getitem_169, True, 0.001, [True, True, True]);  to_dtype_455 = convolution_default_90 = primals_308 = primals_306 = primals_307 = getitem_168 = getitem_169 = None
        getitem_1986 = native_batch_norm_backward_default_151[0]
        getitem_1987 = native_batch_norm_backward_default_151[1]
        getitem_1988 = native_batch_norm_backward_default_151[2];  native_batch_norm_backward_default_151 = None
        convolution_backward_default_282 = torch.ops.aten.convolution_backward.default(getitem_1986, convolution_default_89, primals_315, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1986 = convolution_default_89 = primals_315 = None
        getitem_1989 = convolution_backward_default_282[0]
        getitem_1990 = convolution_backward_default_282[1]
        getitem_1991 = convolution_backward_default_282[2];  convolution_backward_default_282 = None
        convolution_backward_default_283 = torch.ops.aten.convolution_backward.default(getitem_1989, relu_default_47, primals_314, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_1989 = primals_314 = None
        getitem_1992 = convolution_backward_default_283[0]
        getitem_1993 = convolution_backward_default_283[1]
        getitem_1994 = convolution_backward_default_283[2];  convolution_backward_default_283 = None
        to_dtype_456 = torch.ops.aten.to.dtype(getitem_1992, torch.float32);  getitem_1992 = None
        to_dtype_457 = torch.ops.aten.to.dtype(relu_default_47, torch.float32);  relu_default_47 = None
        le_scalar_152 = torch.ops.aten.le.Scalar(to_dtype_457, 0);  to_dtype_457 = None
        new_zeros_default_353 = torch.ops.aten.new_zeros.default(to_dtype_456, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_152 = torch.ops.aten.where.self(le_scalar_152, new_zeros_default_353, to_dtype_456);  le_scalar_152 = new_zeros_default_353 = to_dtype_456 = None
        to_dtype_458 = torch.ops.aten.to.dtype(where_self_152, torch.float32);  where_self_152 = None
        add_tensor_167 = torch.ops.aten.add.Tensor(add_tensor_166, to_dtype_458);  add_tensor_166 = to_dtype_458 = None
        max_pool2d_with_indices_backward_default_32 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_54, getitem_153, [3, 3], [1, 1], [1, 1], [1, 1], False, getitem_166);  getitem_153 = getitem_166 = None
        add_tensor_168 = torch.ops.aten.add.Tensor(to_dtype_434, max_pool2d_with_indices_backward_default_32);  to_dtype_434 = max_pool2d_with_indices_backward_default_32 = None
        clone_default_45 = torch.ops.aten.clone.default(slice_tensor_54, memory_format = torch.contiguous_format);  slice_tensor_54 = None
        native_batch_norm_backward_default_152 = torch.ops.aten.native_batch_norm_backward.default(clone_default_45, convolution_default_88, primals_299, primals_297, primals_298, getitem_163, getitem_164, True, 0.001, [True, True, True]);  clone_default_45 = convolution_default_88 = primals_299 = primals_297 = primals_298 = getitem_163 = getitem_164 = None
        getitem_1995 = native_batch_norm_backward_default_152[0]
        getitem_1996 = native_batch_norm_backward_default_152[1]
        getitem_1997 = native_batch_norm_backward_default_152[2];  native_batch_norm_backward_default_152 = None
        convolution_backward_default_284 = torch.ops.aten.convolution_backward.default(getitem_1995, convolution_default_87, primals_303, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1995 = convolution_default_87 = primals_303 = None
        getitem_1998 = convolution_backward_default_284[0]
        getitem_1999 = convolution_backward_default_284[1]
        getitem_2000 = convolution_backward_default_284[2];  convolution_backward_default_284 = None
        convolution_backward_default_285 = torch.ops.aten.convolution_backward.default(getitem_1998, relu_default_46, primals_302, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_1998 = primals_302 = None
        getitem_2001 = convolution_backward_default_285[0]
        getitem_2002 = convolution_backward_default_285[1]
        getitem_2003 = convolution_backward_default_285[2];  convolution_backward_default_285 = None
        to_dtype_459 = torch.ops.aten.to.dtype(getitem_2001, torch.float32);  getitem_2001 = None
        to_dtype_460 = torch.ops.aten.to.dtype(relu_default_46, torch.float32);  relu_default_46 = None
        le_scalar_153 = torch.ops.aten.le.Scalar(to_dtype_460, 0);  to_dtype_460 = None
        new_zeros_default_354 = torch.ops.aten.new_zeros.default(to_dtype_459, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_153 = torch.ops.aten.where.self(le_scalar_153, new_zeros_default_354, to_dtype_459);  le_scalar_153 = new_zeros_default_354 = to_dtype_459 = None
        to_dtype_461 = torch.ops.aten.to.dtype(where_self_153, torch.float32);  where_self_153 = None
        native_batch_norm_backward_default_153 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_461, convolution_default_86, primals_294, primals_292, primals_293, getitem_160, getitem_161, True, 0.001, [True, True, True]);  to_dtype_461 = convolution_default_86 = primals_294 = primals_292 = primals_293 = getitem_160 = getitem_161 = None
        getitem_2004 = native_batch_norm_backward_default_153[0]
        getitem_2005 = native_batch_norm_backward_default_153[1]
        getitem_2006 = native_batch_norm_backward_default_153[2];  native_batch_norm_backward_default_153 = None
        convolution_backward_default_286 = torch.ops.aten.convolution_backward.default(getitem_2004, convolution_default_85, primals_301, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2004 = convolution_default_85 = primals_301 = None
        getitem_2007 = convolution_backward_default_286[0]
        getitem_2008 = convolution_backward_default_286[1]
        getitem_2009 = convolution_backward_default_286[2];  convolution_backward_default_286 = None
        convolution_backward_default_287 = torch.ops.aten.convolution_backward.default(getitem_2007, relu_default_45, primals_300, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_2007 = primals_300 = None
        getitem_2010 = convolution_backward_default_287[0]
        getitem_2011 = convolution_backward_default_287[1]
        getitem_2012 = convolution_backward_default_287[2];  convolution_backward_default_287 = None
        to_dtype_462 = torch.ops.aten.to.dtype(getitem_2010, torch.float32);  getitem_2010 = None
        to_dtype_463 = torch.ops.aten.to.dtype(relu_default_45, torch.float32);  relu_default_45 = None
        le_scalar_154 = torch.ops.aten.le.Scalar(to_dtype_463, 0);  to_dtype_463 = None
        new_zeros_default_355 = torch.ops.aten.new_zeros.default(to_dtype_462, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_154 = torch.ops.aten.where.self(le_scalar_154, new_zeros_default_355, to_dtype_462);  le_scalar_154 = new_zeros_default_355 = to_dtype_462 = None
        to_dtype_464 = torch.ops.aten.to.dtype(where_self_154, torch.float32);  where_self_154 = None
        add_tensor_169 = torch.ops.aten.add.Tensor(add_tensor_168, to_dtype_464);  add_tensor_168 = to_dtype_464 = None
        native_batch_norm_backward_default_154 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_167, convolution_default_84, primals_378, primals_376, primals_377, getitem_157, getitem_158, True, 0.001, [True, True, True]);  add_tensor_167 = convolution_default_84 = primals_378 = primals_376 = primals_377 = getitem_157 = getitem_158 = None
        getitem_2013 = native_batch_norm_backward_default_154[0]
        getitem_2014 = native_batch_norm_backward_default_154[1]
        getitem_2015 = native_batch_norm_backward_default_154[2];  native_batch_norm_backward_default_154 = None
        convolution_backward_default_288 = torch.ops.aten.convolution_backward.default(getitem_2013, relu_default_44, primals_379, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2013 = primals_379 = None
        getitem_2016 = convolution_backward_default_288[0]
        getitem_2017 = convolution_backward_default_288[1]
        getitem_2018 = convolution_backward_default_288[2];  convolution_backward_default_288 = None
        to_dtype_465 = torch.ops.aten.to.dtype(getitem_2016, torch.float32);  getitem_2016 = None
        to_dtype_466 = torch.ops.aten.to.dtype(relu_default_44, torch.float32);  relu_default_44 = None
        le_scalar_155 = torch.ops.aten.le.Scalar(to_dtype_466, 0);  to_dtype_466 = None
        new_zeros_default_356 = torch.ops.aten.new_zeros.default(to_dtype_465, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_155 = torch.ops.aten.where.self(le_scalar_155, new_zeros_default_356, to_dtype_465);  le_scalar_155 = new_zeros_default_356 = to_dtype_465 = None
        to_dtype_467 = torch.ops.aten.to.dtype(where_self_155, torch.float32);  where_self_155 = None
        add_tensor_170 = torch.ops.aten.add.Tensor(to_dtype_428, to_dtype_467);  to_dtype_428 = to_dtype_467 = None
        native_batch_norm_backward_default_155 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_169, convolution_default_83, primals_384, primals_382, primals_383, getitem_154, getitem_155, True, 0.001, [True, True, True]);  add_tensor_169 = convolution_default_83 = primals_384 = primals_382 = primals_383 = getitem_154 = getitem_155 = None
        getitem_2019 = native_batch_norm_backward_default_155[0]
        getitem_2020 = native_batch_norm_backward_default_155[1]
        getitem_2021 = native_batch_norm_backward_default_155[2];  native_batch_norm_backward_default_155 = None
        convolution_backward_default_289 = torch.ops.aten.convolution_backward.default(getitem_2019, relu_default_43, primals_385, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2019 = primals_385 = None
        getitem_2022 = convolution_backward_default_289[0]
        getitem_2023 = convolution_backward_default_289[1]
        getitem_2024 = convolution_backward_default_289[2];  convolution_backward_default_289 = None
        to_dtype_468 = torch.ops.aten.to.dtype(getitem_2022, torch.float32);  getitem_2022 = None
        to_dtype_469 = torch.ops.aten.to.dtype(relu_default_43, torch.float32);  relu_default_43 = None
        le_scalar_156 = torch.ops.aten.le.Scalar(to_dtype_469, 0);  to_dtype_469 = None
        new_zeros_default_357 = torch.ops.aten.new_zeros.default(to_dtype_468, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_156 = torch.ops.aten.where.self(le_scalar_156, new_zeros_default_357, to_dtype_468);  le_scalar_156 = new_zeros_default_357 = to_dtype_468 = None
        to_dtype_470 = torch.ops.aten.to.dtype(where_self_156, torch.float32);  where_self_156 = None
        slice_tensor_59 = torch.ops.aten.slice.Tensor(add_tensor_170, 1, 0, 216)
        slice_tensor_60 = torch.ops.aten.slice.Tensor(add_tensor_170, 1, 216, 432)
        slice_tensor_61 = torch.ops.aten.slice.Tensor(add_tensor_170, 1, 432, 648)
        slice_tensor_62 = torch.ops.aten.slice.Tensor(add_tensor_170, 1, 648, 864)
        slice_tensor_63 = torch.ops.aten.slice.Tensor(add_tensor_170, 1, 864, 1080);  add_tensor_170 = None
        clone_default_46 = torch.ops.aten.clone.default(slice_tensor_63, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_156 = torch.ops.aten.native_batch_norm_backward.default(clone_default_46, convolution_default_82, primals_80, primals_78, primals_79, getitem_151, getitem_152, True, 0.001, [True, True, True]);  clone_default_46 = convolution_default_82 = primals_80 = primals_78 = primals_79 = getitem_151 = getitem_152 = None
        getitem_2025 = native_batch_norm_backward_default_156[0]
        getitem_2026 = native_batch_norm_backward_default_156[1]
        getitem_2027 = native_batch_norm_backward_default_156[2];  native_batch_norm_backward_default_156 = None
        convolution_backward_default_290 = torch.ops.aten.convolution_backward.default(getitem_2025, convolution_default_81, primals_84, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2025 = convolution_default_81 = primals_84 = None
        getitem_2028 = convolution_backward_default_290[0]
        getitem_2029 = convolution_backward_default_290[1]
        getitem_2030 = convolution_backward_default_290[2];  convolution_backward_default_290 = None
        convolution_backward_default_291 = torch.ops.aten.convolution_backward.default(getitem_2028, relu_default_42, primals_83, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_2028 = primals_83 = None
        getitem_2031 = convolution_backward_default_291[0]
        getitem_2032 = convolution_backward_default_291[1]
        getitem_2033 = convolution_backward_default_291[2];  convolution_backward_default_291 = None
        to_dtype_471 = torch.ops.aten.to.dtype(getitem_2031, torch.float32);  getitem_2031 = None
        to_dtype_472 = torch.ops.aten.to.dtype(relu_default_42, torch.float32);  relu_default_42 = None
        le_scalar_157 = torch.ops.aten.le.Scalar(to_dtype_472, 0);  to_dtype_472 = None
        new_zeros_default_358 = torch.ops.aten.new_zeros.default(to_dtype_471, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_157 = torch.ops.aten.where.self(le_scalar_157, new_zeros_default_358, to_dtype_471);  le_scalar_157 = new_zeros_default_358 = to_dtype_471 = None
        to_dtype_473 = torch.ops.aten.to.dtype(where_self_157, torch.float32);  where_self_157 = None
        native_batch_norm_backward_default_157 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_473, convolution_default_80, primals_75, primals_73, primals_74, getitem_148, getitem_149, True, 0.001, [True, True, True]);  to_dtype_473 = convolution_default_80 = primals_75 = primals_73 = primals_74 = getitem_148 = getitem_149 = None
        getitem_2034 = native_batch_norm_backward_default_157[0]
        getitem_2035 = native_batch_norm_backward_default_157[1]
        getitem_2036 = native_batch_norm_backward_default_157[2];  native_batch_norm_backward_default_157 = None
        convolution_backward_default_292 = torch.ops.aten.convolution_backward.default(getitem_2034, convolution_default_79, primals_82, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2034 = convolution_default_79 = primals_82 = None
        getitem_2037 = convolution_backward_default_292[0]
        getitem_2038 = convolution_backward_default_292[1]
        getitem_2039 = convolution_backward_default_292[2];  convolution_backward_default_292 = None
        convolution_backward_default_293 = torch.ops.aten.convolution_backward.default(getitem_2037, relu_default_41, primals_81, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_2037 = primals_81 = None
        getitem_2040 = convolution_backward_default_293[0]
        getitem_2041 = convolution_backward_default_293[1]
        getitem_2042 = convolution_backward_default_293[2];  convolution_backward_default_293 = None
        to_dtype_474 = torch.ops.aten.to.dtype(getitem_2040, torch.float32);  getitem_2040 = None
        to_dtype_475 = torch.ops.aten.to.dtype(relu_default_41, torch.float32);  relu_default_41 = None
        le_scalar_158 = torch.ops.aten.le.Scalar(to_dtype_475, 0);  to_dtype_475 = None
        new_zeros_default_359 = torch.ops.aten.new_zeros.default(to_dtype_474, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_158 = torch.ops.aten.where.self(le_scalar_158, new_zeros_default_359, to_dtype_474);  le_scalar_158 = new_zeros_default_359 = to_dtype_474 = None
        to_dtype_476 = torch.ops.aten.to.dtype(where_self_158, torch.float32);  where_self_158 = None
        max_pool2d_with_indices_backward_default_33 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_62, getitem_108, [3, 3], [1, 1], [1, 1], [1, 1], False, getitem_146);  getitem_146 = None
        add_tensor_171 = torch.ops.aten.add.Tensor(slice_tensor_63, max_pool2d_with_indices_backward_default_33);  slice_tensor_63 = max_pool2d_with_indices_backward_default_33 = None
        clone_default_47 = torch.ops.aten.clone.default(slice_tensor_62, memory_format = torch.contiguous_format);  slice_tensor_62 = None
        native_batch_norm_backward_default_158 = torch.ops.aten.native_batch_norm_backward.default(clone_default_47, convolution_default_78, primals_66, primals_64, primals_65, getitem_143, getitem_144, True, 0.001, [True, True, True]);  clone_default_47 = convolution_default_78 = primals_66 = primals_64 = primals_65 = getitem_143 = getitem_144 = None
        getitem_2043 = native_batch_norm_backward_default_158[0]
        getitem_2044 = native_batch_norm_backward_default_158[1]
        getitem_2045 = native_batch_norm_backward_default_158[2];  native_batch_norm_backward_default_158 = None
        convolution_backward_default_294 = torch.ops.aten.convolution_backward.default(getitem_2043, convolution_default_77, primals_70, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2043 = convolution_default_77 = primals_70 = None
        getitem_2046 = convolution_backward_default_294[0]
        getitem_2047 = convolution_backward_default_294[1]
        getitem_2048 = convolution_backward_default_294[2];  convolution_backward_default_294 = None
        convolution_backward_default_295 = torch.ops.aten.convolution_backward.default(getitem_2046, relu_default_40, primals_69, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_2046 = primals_69 = None
        getitem_2049 = convolution_backward_default_295[0]
        getitem_2050 = convolution_backward_default_295[1]
        getitem_2051 = convolution_backward_default_295[2];  convolution_backward_default_295 = None
        to_dtype_477 = torch.ops.aten.to.dtype(getitem_2049, torch.float32);  getitem_2049 = None
        to_dtype_478 = torch.ops.aten.to.dtype(relu_default_40, torch.float32);  relu_default_40 = None
        le_scalar_159 = torch.ops.aten.le.Scalar(to_dtype_478, 0);  to_dtype_478 = None
        new_zeros_default_360 = torch.ops.aten.new_zeros.default(to_dtype_477, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_159 = torch.ops.aten.where.self(le_scalar_159, new_zeros_default_360, to_dtype_477);  le_scalar_159 = new_zeros_default_360 = to_dtype_477 = None
        to_dtype_479 = torch.ops.aten.to.dtype(where_self_159, torch.float32);  where_self_159 = None
        native_batch_norm_backward_default_159 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_479, convolution_default_76, primals_61, primals_59, primals_60, getitem_140, getitem_141, True, 0.001, [True, True, True]);  to_dtype_479 = convolution_default_76 = primals_61 = primals_59 = primals_60 = getitem_140 = getitem_141 = None
        getitem_2052 = native_batch_norm_backward_default_159[0]
        getitem_2053 = native_batch_norm_backward_default_159[1]
        getitem_2054 = native_batch_norm_backward_default_159[2];  native_batch_norm_backward_default_159 = None
        convolution_backward_default_296 = torch.ops.aten.convolution_backward.default(getitem_2052, convolution_default_75, primals_68, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2052 = convolution_default_75 = primals_68 = None
        getitem_2055 = convolution_backward_default_296[0]
        getitem_2056 = convolution_backward_default_296[1]
        getitem_2057 = convolution_backward_default_296[2];  convolution_backward_default_296 = None
        convolution_backward_default_297 = torch.ops.aten.convolution_backward.default(getitem_2055, relu_default_39, primals_67, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_2055 = primals_67 = None
        getitem_2058 = convolution_backward_default_297[0]
        getitem_2059 = convolution_backward_default_297[1]
        getitem_2060 = convolution_backward_default_297[2];  convolution_backward_default_297 = None
        to_dtype_480 = torch.ops.aten.to.dtype(getitem_2058, torch.float32);  getitem_2058 = None
        to_dtype_481 = torch.ops.aten.to.dtype(relu_default_39, torch.float32);  relu_default_39 = None
        le_scalar_160 = torch.ops.aten.le.Scalar(to_dtype_481, 0);  to_dtype_481 = None
        new_zeros_default_361 = torch.ops.aten.new_zeros.default(to_dtype_480, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_160 = torch.ops.aten.where.self(le_scalar_160, new_zeros_default_361, to_dtype_480);  le_scalar_160 = new_zeros_default_361 = to_dtype_480 = None
        to_dtype_482 = torch.ops.aten.to.dtype(where_self_160, torch.float32);  where_self_160 = None
        add_tensor_172 = torch.ops.aten.add.Tensor(slice_tensor_61, to_dtype_482);  slice_tensor_61 = to_dtype_482 = None
        native_batch_norm_backward_default_160 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_172, convolution_default_74, primals_52, primals_50, primals_51, getitem_137, getitem_138, True, 0.001, [True, True, True]);  convolution_default_74 = primals_52 = primals_50 = primals_51 = getitem_137 = getitem_138 = None
        getitem_2061 = native_batch_norm_backward_default_160[0]
        getitem_2062 = native_batch_norm_backward_default_160[1]
        getitem_2063 = native_batch_norm_backward_default_160[2];  native_batch_norm_backward_default_160 = None
        convolution_backward_default_298 = torch.ops.aten.convolution_backward.default(getitem_2061, convolution_default_73, primals_56, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2061 = convolution_default_73 = primals_56 = None
        getitem_2064 = convolution_backward_default_298[0]
        getitem_2065 = convolution_backward_default_298[1]
        getitem_2066 = convolution_backward_default_298[2];  convolution_backward_default_298 = None
        convolution_backward_default_299 = torch.ops.aten.convolution_backward.default(getitem_2064, relu_default_38, primals_55, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_2064 = primals_55 = None
        getitem_2067 = convolution_backward_default_299[0]
        getitem_2068 = convolution_backward_default_299[1]
        getitem_2069 = convolution_backward_default_299[2];  convolution_backward_default_299 = None
        to_dtype_483 = torch.ops.aten.to.dtype(getitem_2067, torch.float32);  getitem_2067 = None
        to_dtype_484 = torch.ops.aten.to.dtype(relu_default_38, torch.float32);  relu_default_38 = None
        le_scalar_161 = torch.ops.aten.le.Scalar(to_dtype_484, 0);  to_dtype_484 = None
        new_zeros_default_362 = torch.ops.aten.new_zeros.default(to_dtype_483, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_161 = torch.ops.aten.where.self(le_scalar_161, new_zeros_default_362, to_dtype_483);  le_scalar_161 = new_zeros_default_362 = to_dtype_483 = None
        to_dtype_485 = torch.ops.aten.to.dtype(where_self_161, torch.float32);  where_self_161 = None
        native_batch_norm_backward_default_161 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_485, convolution_default_72, primals_47, primals_45, primals_46, getitem_134, getitem_135, True, 0.001, [True, True, True]);  to_dtype_485 = convolution_default_72 = primals_47 = primals_45 = primals_46 = getitem_134 = getitem_135 = None
        getitem_2070 = native_batch_norm_backward_default_161[0]
        getitem_2071 = native_batch_norm_backward_default_161[1]
        getitem_2072 = native_batch_norm_backward_default_161[2];  native_batch_norm_backward_default_161 = None
        convolution_backward_default_300 = torch.ops.aten.convolution_backward.default(getitem_2070, convolution_default_71, primals_54, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2070 = convolution_default_71 = primals_54 = None
        getitem_2073 = convolution_backward_default_300[0]
        getitem_2074 = convolution_backward_default_300[1]
        getitem_2075 = convolution_backward_default_300[2];  convolution_backward_default_300 = None
        convolution_backward_default_301 = torch.ops.aten.convolution_backward.default(getitem_2073, relu_default_37, primals_53, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_2073 = primals_53 = None
        getitem_2076 = convolution_backward_default_301[0]
        getitem_2077 = convolution_backward_default_301[1]
        getitem_2078 = convolution_backward_default_301[2];  convolution_backward_default_301 = None
        to_dtype_486 = torch.ops.aten.to.dtype(getitem_2076, torch.float32);  getitem_2076 = None
        to_dtype_487 = torch.ops.aten.to.dtype(relu_default_37, torch.float32);  relu_default_37 = None
        le_scalar_162 = torch.ops.aten.le.Scalar(to_dtype_487, 0);  to_dtype_487 = None
        new_zeros_default_363 = torch.ops.aten.new_zeros.default(to_dtype_486, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_162 = torch.ops.aten.where.self(le_scalar_162, new_zeros_default_363, to_dtype_486);  le_scalar_162 = new_zeros_default_363 = to_dtype_486 = None
        to_dtype_488 = torch.ops.aten.to.dtype(where_self_162, torch.float32);  where_self_162 = None
        add_tensor_173 = torch.ops.aten.add.Tensor(add_tensor_171, to_dtype_488);  add_tensor_171 = to_dtype_488 = None
        native_batch_norm_backward_default_162 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_172, convolution_default_70, primals_38, primals_36, primals_37, getitem_131, getitem_132, True, 0.001, [True, True, True]);  add_tensor_172 = convolution_default_70 = primals_38 = primals_36 = primals_37 = getitem_131 = getitem_132 = None
        getitem_2079 = native_batch_norm_backward_default_162[0]
        getitem_2080 = native_batch_norm_backward_default_162[1]
        getitem_2081 = native_batch_norm_backward_default_162[2];  native_batch_norm_backward_default_162 = None
        convolution_backward_default_302 = torch.ops.aten.convolution_backward.default(getitem_2079, convolution_default_69, primals_42, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2079 = convolution_default_69 = primals_42 = None
        getitem_2082 = convolution_backward_default_302[0]
        getitem_2083 = convolution_backward_default_302[1]
        getitem_2084 = convolution_backward_default_302[2];  convolution_backward_default_302 = None
        convolution_backward_default_303 = torch.ops.aten.convolution_backward.default(getitem_2082, relu_default_36, primals_41, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_2082 = primals_41 = None
        getitem_2085 = convolution_backward_default_303[0]
        getitem_2086 = convolution_backward_default_303[1]
        getitem_2087 = convolution_backward_default_303[2];  convolution_backward_default_303 = None
        to_dtype_489 = torch.ops.aten.to.dtype(getitem_2085, torch.float32);  getitem_2085 = None
        to_dtype_490 = torch.ops.aten.to.dtype(relu_default_36, torch.float32);  relu_default_36 = None
        le_scalar_163 = torch.ops.aten.le.Scalar(to_dtype_490, 0);  to_dtype_490 = None
        new_zeros_default_364 = torch.ops.aten.new_zeros.default(to_dtype_489, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_163 = torch.ops.aten.where.self(le_scalar_163, new_zeros_default_364, to_dtype_489);  le_scalar_163 = new_zeros_default_364 = to_dtype_489 = None
        to_dtype_491 = torch.ops.aten.to.dtype(where_self_163, torch.float32);  where_self_163 = None
        native_batch_norm_backward_default_163 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_491, convolution_default_68, primals_33, primals_31, primals_32, getitem_128, getitem_129, True, 0.001, [True, True, True]);  to_dtype_491 = convolution_default_68 = primals_33 = primals_31 = primals_32 = getitem_128 = getitem_129 = None
        getitem_2088 = native_batch_norm_backward_default_163[0]
        getitem_2089 = native_batch_norm_backward_default_163[1]
        getitem_2090 = native_batch_norm_backward_default_163[2];  native_batch_norm_backward_default_163 = None
        convolution_backward_default_304 = torch.ops.aten.convolution_backward.default(getitem_2088, convolution_default_67, primals_40, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2088 = convolution_default_67 = primals_40 = None
        getitem_2091 = convolution_backward_default_304[0]
        getitem_2092 = convolution_backward_default_304[1]
        getitem_2093 = convolution_backward_default_304[2];  convolution_backward_default_304 = None
        convolution_backward_default_305 = torch.ops.aten.convolution_backward.default(getitem_2091, relu_default_35, primals_39, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_2091 = primals_39 = None
        getitem_2094 = convolution_backward_default_305[0]
        getitem_2095 = convolution_backward_default_305[1]
        getitem_2096 = convolution_backward_default_305[2];  convolution_backward_default_305 = None
        to_dtype_492 = torch.ops.aten.to.dtype(getitem_2094, torch.float32);  getitem_2094 = None
        to_dtype_493 = torch.ops.aten.to.dtype(relu_default_35, torch.float32);  relu_default_35 = None
        le_scalar_164 = torch.ops.aten.le.Scalar(to_dtype_493, 0);  to_dtype_493 = None
        new_zeros_default_365 = torch.ops.aten.new_zeros.default(to_dtype_492, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_164 = torch.ops.aten.where.self(le_scalar_164, new_zeros_default_365, to_dtype_492);  le_scalar_164 = new_zeros_default_365 = to_dtype_492 = None
        to_dtype_494 = torch.ops.aten.to.dtype(where_self_164, torch.float32);  where_self_164 = None
        add_tensor_174 = torch.ops.aten.add.Tensor(add_tensor_173, to_dtype_494);  add_tensor_173 = to_dtype_494 = None
        max_pool2d_with_indices_backward_default_34 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_60, getitem_108, [3, 3], [1, 1], [1, 1], [1, 1], False, getitem_126);  getitem_108 = getitem_126 = None
        add_tensor_175 = torch.ops.aten.add.Tensor(add_tensor_174, max_pool2d_with_indices_backward_default_34);  add_tensor_174 = max_pool2d_with_indices_backward_default_34 = None
        clone_default_48 = torch.ops.aten.clone.default(slice_tensor_60, memory_format = torch.contiguous_format);  slice_tensor_60 = None
        native_batch_norm_backward_default_164 = torch.ops.aten.native_batch_norm_backward.default(clone_default_48, convolution_default_66, primals_24, primals_22, primals_23, getitem_123, getitem_124, True, 0.001, [True, True, True]);  clone_default_48 = convolution_default_66 = primals_24 = primals_22 = primals_23 = getitem_123 = getitem_124 = None
        getitem_2097 = native_batch_norm_backward_default_164[0]
        getitem_2098 = native_batch_norm_backward_default_164[1]
        getitem_2099 = native_batch_norm_backward_default_164[2];  native_batch_norm_backward_default_164 = None
        convolution_backward_default_306 = torch.ops.aten.convolution_backward.default(getitem_2097, convolution_default_65, primals_28, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2097 = convolution_default_65 = primals_28 = None
        getitem_2100 = convolution_backward_default_306[0]
        getitem_2101 = convolution_backward_default_306[1]
        getitem_2102 = convolution_backward_default_306[2];  convolution_backward_default_306 = None
        convolution_backward_default_307 = torch.ops.aten.convolution_backward.default(getitem_2100, relu_default_34, primals_27, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_2100 = primals_27 = None
        getitem_2103 = convolution_backward_default_307[0]
        getitem_2104 = convolution_backward_default_307[1]
        getitem_2105 = convolution_backward_default_307[2];  convolution_backward_default_307 = None
        to_dtype_495 = torch.ops.aten.to.dtype(getitem_2103, torch.float32);  getitem_2103 = None
        to_dtype_496 = torch.ops.aten.to.dtype(relu_default_34, torch.float32);  relu_default_34 = None
        le_scalar_165 = torch.ops.aten.le.Scalar(to_dtype_496, 0);  to_dtype_496 = None
        new_zeros_default_366 = torch.ops.aten.new_zeros.default(to_dtype_495, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_165 = torch.ops.aten.where.self(le_scalar_165, new_zeros_default_366, to_dtype_495);  le_scalar_165 = new_zeros_default_366 = to_dtype_495 = None
        to_dtype_497 = torch.ops.aten.to.dtype(where_self_165, torch.float32);  where_self_165 = None
        native_batch_norm_backward_default_165 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_497, convolution_default_64, primals_19, primals_17, primals_18, getitem_120, getitem_121, True, 0.001, [True, True, True]);  to_dtype_497 = convolution_default_64 = primals_19 = primals_17 = primals_18 = getitem_120 = getitem_121 = None
        getitem_2106 = native_batch_norm_backward_default_165[0]
        getitem_2107 = native_batch_norm_backward_default_165[1]
        getitem_2108 = native_batch_norm_backward_default_165[2];  native_batch_norm_backward_default_165 = None
        convolution_backward_default_308 = torch.ops.aten.convolution_backward.default(getitem_2106, convolution_default_63, primals_26, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2106 = convolution_default_63 = primals_26 = None
        getitem_2109 = convolution_backward_default_308[0]
        getitem_2110 = convolution_backward_default_308[1]
        getitem_2111 = convolution_backward_default_308[2];  convolution_backward_default_308 = None
        convolution_backward_default_309 = torch.ops.aten.convolution_backward.default(getitem_2109, relu_default_33, primals_25, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_2109 = primals_25 = None
        getitem_2112 = convolution_backward_default_309[0]
        getitem_2113 = convolution_backward_default_309[1]
        getitem_2114 = convolution_backward_default_309[2];  convolution_backward_default_309 = None
        to_dtype_498 = torch.ops.aten.to.dtype(getitem_2112, torch.float32);  getitem_2112 = None
        to_dtype_499 = torch.ops.aten.to.dtype(relu_default_33, torch.float32);  relu_default_33 = None
        le_scalar_166 = torch.ops.aten.le.Scalar(to_dtype_499, 0);  to_dtype_499 = None
        new_zeros_default_367 = torch.ops.aten.new_zeros.default(to_dtype_498, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_166 = torch.ops.aten.where.self(le_scalar_166, new_zeros_default_367, to_dtype_498);  le_scalar_166 = new_zeros_default_367 = to_dtype_498 = None
        to_dtype_500 = torch.ops.aten.to.dtype(where_self_166, torch.float32);  where_self_166 = None
        add_tensor_176 = torch.ops.aten.add.Tensor(add_tensor_175, to_dtype_500);  add_tensor_175 = to_dtype_500 = None
        max_pool2d_with_indices_backward_default_35 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_59, getitem_105, [3, 3], [1, 1], [1, 1], [1, 1], False, getitem_118);  getitem_105 = getitem_118 = None
        add_tensor_177 = torch.ops.aten.add.Tensor(to_dtype_476, max_pool2d_with_indices_backward_default_35);  to_dtype_476 = max_pool2d_with_indices_backward_default_35 = None
        clone_default_49 = torch.ops.aten.clone.default(slice_tensor_59, memory_format = torch.contiguous_format);  slice_tensor_59 = None
        native_batch_norm_backward_default_166 = torch.ops.aten.native_batch_norm_backward.default(clone_default_49, convolution_default_62, primals_10, primals_8, primals_9, getitem_115, getitem_116, True, 0.001, [True, True, True]);  clone_default_49 = convolution_default_62 = primals_10 = primals_8 = primals_9 = getitem_115 = getitem_116 = None
        getitem_2115 = native_batch_norm_backward_default_166[0]
        getitem_2116 = native_batch_norm_backward_default_166[1]
        getitem_2117 = native_batch_norm_backward_default_166[2];  native_batch_norm_backward_default_166 = None
        convolution_backward_default_310 = torch.ops.aten.convolution_backward.default(getitem_2115, convolution_default_61, primals_14, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2115 = convolution_default_61 = primals_14 = None
        getitem_2118 = convolution_backward_default_310[0]
        getitem_2119 = convolution_backward_default_310[1]
        getitem_2120 = convolution_backward_default_310[2];  convolution_backward_default_310 = None
        convolution_backward_default_311 = torch.ops.aten.convolution_backward.default(getitem_2118, relu_default_32, primals_13, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_2118 = primals_13 = None
        getitem_2121 = convolution_backward_default_311[0]
        getitem_2122 = convolution_backward_default_311[1]
        getitem_2123 = convolution_backward_default_311[2];  convolution_backward_default_311 = None
        to_dtype_501 = torch.ops.aten.to.dtype(getitem_2121, torch.float32);  getitem_2121 = None
        to_dtype_502 = torch.ops.aten.to.dtype(relu_default_32, torch.float32);  relu_default_32 = None
        le_scalar_167 = torch.ops.aten.le.Scalar(to_dtype_502, 0);  to_dtype_502 = None
        new_zeros_default_368 = torch.ops.aten.new_zeros.default(to_dtype_501, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_167 = torch.ops.aten.where.self(le_scalar_167, new_zeros_default_368, to_dtype_501);  le_scalar_167 = new_zeros_default_368 = to_dtype_501 = None
        to_dtype_503 = torch.ops.aten.to.dtype(where_self_167, torch.float32);  where_self_167 = None
        native_batch_norm_backward_default_167 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_503, convolution_default_60, primals_5, primals_3, primals_4, getitem_112, getitem_113, True, 0.001, [True, True, True]);  to_dtype_503 = convolution_default_60 = primals_5 = primals_3 = primals_4 = getitem_112 = getitem_113 = None
        getitem_2124 = native_batch_norm_backward_default_167[0]
        getitem_2125 = native_batch_norm_backward_default_167[1]
        getitem_2126 = native_batch_norm_backward_default_167[2];  native_batch_norm_backward_default_167 = None
        convolution_backward_default_312 = torch.ops.aten.convolution_backward.default(getitem_2124, convolution_default_59, primals_12, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2124 = convolution_default_59 = primals_12 = None
        getitem_2127 = convolution_backward_default_312[0]
        getitem_2128 = convolution_backward_default_312[1]
        getitem_2129 = convolution_backward_default_312[2];  convolution_backward_default_312 = None
        convolution_backward_default_313 = torch.ops.aten.convolution_backward.default(getitem_2127, relu_default_31, primals_11, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 216, [True, True, False]);  getitem_2127 = primals_11 = None
        getitem_2130 = convolution_backward_default_313[0]
        getitem_2131 = convolution_backward_default_313[1]
        getitem_2132 = convolution_backward_default_313[2];  convolution_backward_default_313 = None
        to_dtype_504 = torch.ops.aten.to.dtype(getitem_2130, torch.float32);  getitem_2130 = None
        to_dtype_505 = torch.ops.aten.to.dtype(relu_default_31, torch.float32);  relu_default_31 = None
        le_scalar_168 = torch.ops.aten.le.Scalar(to_dtype_505, 0);  to_dtype_505 = None
        new_zeros_default_369 = torch.ops.aten.new_zeros.default(to_dtype_504, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_168 = torch.ops.aten.where.self(le_scalar_168, new_zeros_default_369, to_dtype_504);  le_scalar_168 = new_zeros_default_369 = to_dtype_504 = None
        to_dtype_506 = torch.ops.aten.to.dtype(where_self_168, torch.float32);  where_self_168 = None
        add_tensor_178 = torch.ops.aten.add.Tensor(add_tensor_177, to_dtype_506);  add_tensor_177 = to_dtype_506 = None
        native_batch_norm_backward_default_168 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_176, convolution_default_58, primals_89, primals_87, primals_88, getitem_109, getitem_110, True, 0.001, [True, True, True]);  add_tensor_176 = convolution_default_58 = primals_89 = primals_87 = primals_88 = getitem_109 = getitem_110 = None
        getitem_2133 = native_batch_norm_backward_default_168[0]
        getitem_2134 = native_batch_norm_backward_default_168[1]
        getitem_2135 = native_batch_norm_backward_default_168[2];  native_batch_norm_backward_default_168 = None
        convolution_backward_default_314 = torch.ops.aten.convolution_backward.default(getitem_2133, relu_default_30, primals_90, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2133 = primals_90 = None
        getitem_2136 = convolution_backward_default_314[0]
        getitem_2137 = convolution_backward_default_314[1]
        getitem_2138 = convolution_backward_default_314[2];  convolution_backward_default_314 = None
        to_dtype_507 = torch.ops.aten.to.dtype(getitem_2136, torch.float32);  getitem_2136 = None
        to_dtype_508 = torch.ops.aten.to.dtype(relu_default_30, torch.float32);  relu_default_30 = None
        le_scalar_169 = torch.ops.aten.le.Scalar(to_dtype_508, 0);  to_dtype_508 = None
        new_zeros_default_370 = torch.ops.aten.new_zeros.default(to_dtype_507, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_169 = torch.ops.aten.where.self(le_scalar_169, new_zeros_default_370, to_dtype_507);  le_scalar_169 = new_zeros_default_370 = to_dtype_507 = None
        to_dtype_509 = torch.ops.aten.to.dtype(where_self_169, torch.float32);  where_self_169 = None
        add_tensor_179 = torch.ops.aten.add.Tensor(to_dtype_470, to_dtype_509);  to_dtype_470 = to_dtype_509 = None
        native_batch_norm_backward_default_169 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_178, cat_default_3, primals_95, primals_93, primals_94, getitem_106, getitem_107, True, 0.001, [True, True, True]);  add_tensor_178 = cat_default_3 = primals_95 = primals_93 = primals_94 = getitem_106 = getitem_107 = None
        getitem_2139 = native_batch_norm_backward_default_169[0]
        getitem_2140 = native_batch_norm_backward_default_169[1]
        getitem_2141 = native_batch_norm_backward_default_169[2];  native_batch_norm_backward_default_169 = None
        slice_tensor_64 = torch.ops.aten.slice.Tensor(getitem_2139, 1, 0, 108)
        slice_tensor_65 = torch.ops.aten.slice.Tensor(getitem_2139, 1, 108, 216);  getitem_2139 = None
        convolution_backward_default_315 = torch.ops.aten.convolution_backward.default(slice_tensor_65, avg_pool2d_default_3, primals_97, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_65 = avg_pool2d_default_3 = primals_97 = None
        getitem_2142 = convolution_backward_default_315[0]
        getitem_2143 = convolution_backward_default_315[1]
        getitem_2144 = convolution_backward_default_315[2];  convolution_backward_default_315 = None
        avg_pool2d_backward_default_4 = torch.ops.aten.avg_pool2d_backward.default(getitem_2142, constant_pad_nd_default_17, [1, 1], [2, 2], [0, 0], False, False, None);  getitem_2142 = constant_pad_nd_default_17 = None
        constant_pad_nd_default_54 = torch.ops.aten.constant_pad_nd.default(avg_pool2d_backward_default_4, [1, -1, 1, -1]);  avg_pool2d_backward_default_4 = None
        convolution_backward_default_316 = torch.ops.aten.convolution_backward.default(slice_tensor_64, avg_pool2d_default_2, primals_96, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_64 = avg_pool2d_default_2 = primals_96 = None
        getitem_2145 = convolution_backward_default_316[0]
        getitem_2146 = convolution_backward_default_316[1]
        getitem_2147 = convolution_backward_default_316[2];  convolution_backward_default_316 = None
        avg_pool2d_backward_default_5 = torch.ops.aten.avg_pool2d_backward.default(getitem_2145, relu_default_29, [1, 1], [2, 2], [0, 0], False, False, None);  getitem_2145 = None
        add_tensor_180 = torch.ops.aten.add.Tensor(constant_pad_nd_default_54, avg_pool2d_backward_default_5);  constant_pad_nd_default_54 = avg_pool2d_backward_default_5 = None
        to_dtype_510 = torch.ops.aten.to.dtype(add_tensor_180, torch.float32);  add_tensor_180 = None
        to_dtype_511 = torch.ops.aten.to.dtype(relu_default_29, torch.float32);  relu_default_29 = None
        le_scalar_170 = torch.ops.aten.le.Scalar(to_dtype_511, 0);  to_dtype_511 = None
        new_zeros_default_371 = torch.ops.aten.new_zeros.default(to_dtype_510, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_170 = torch.ops.aten.where.self(le_scalar_170, new_zeros_default_371, to_dtype_510);  le_scalar_170 = new_zeros_default_371 = to_dtype_510 = None
        to_dtype_512 = torch.ops.aten.to.dtype(where_self_170, torch.float32);  where_self_170 = None
        slice_tensor_66 = torch.ops.aten.slice.Tensor(add_tensor_179, 1, 0, 108)
        slice_tensor_67 = torch.ops.aten.slice.Tensor(add_tensor_179, 1, 108, 216)
        slice_tensor_68 = torch.ops.aten.slice.Tensor(add_tensor_179, 1, 216, 324)
        slice_tensor_69 = torch.ops.aten.slice.Tensor(add_tensor_179, 1, 324, 432)
        slice_tensor_70 = torch.ops.aten.slice.Tensor(add_tensor_179, 1, 432, 540);  add_tensor_179 = None
        clone_default_50 = torch.ops.aten.clone.default(slice_tensor_70, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_170 = torch.ops.aten.native_batch_norm_backward.default(clone_default_50, convolution_default_55, primals_1358, primals_1356, primals_1357, getitem_103, getitem_104, True, 0.001, [True, True, True]);  clone_default_50 = convolution_default_55 = primals_1358 = primals_1356 = primals_1357 = getitem_103 = getitem_104 = None
        getitem_2148 = native_batch_norm_backward_default_170[0]
        getitem_2149 = native_batch_norm_backward_default_170[1]
        getitem_2150 = native_batch_norm_backward_default_170[2];  native_batch_norm_backward_default_170 = None
        convolution_backward_default_317 = torch.ops.aten.convolution_backward.default(getitem_2148, relu_default_28, primals_1359, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2148 = primals_1359 = None
        getitem_2151 = convolution_backward_default_317[0]
        getitem_2152 = convolution_backward_default_317[1]
        getitem_2153 = convolution_backward_default_317[2];  convolution_backward_default_317 = None
        to_dtype_513 = torch.ops.aten.to.dtype(getitem_2151, torch.float32);  getitem_2151 = None
        to_dtype_514 = torch.ops.aten.to.dtype(relu_default_28, torch.float32);  relu_default_28 = None
        le_scalar_171 = torch.ops.aten.le.Scalar(to_dtype_514, 0);  to_dtype_514 = None
        new_zeros_default_372 = torch.ops.aten.new_zeros.default(to_dtype_513, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_171 = torch.ops.aten.where.self(le_scalar_171, new_zeros_default_372, to_dtype_513);  le_scalar_171 = new_zeros_default_372 = to_dtype_513 = None
        to_dtype_515 = torch.ops.aten.to.dtype(where_self_171, torch.float32);  where_self_171 = None
        clone_default_51 = torch.ops.aten.clone.default(slice_tensor_70, memory_format = torch.contiguous_format);  slice_tensor_70 = None
        native_batch_norm_backward_default_171 = torch.ops.aten.native_batch_norm_backward.default(clone_default_51, convolution_default_54, primals_1349, primals_1347, primals_1348, getitem_100, getitem_101, True, 0.001, [True, True, True]);  clone_default_51 = convolution_default_54 = primals_1349 = primals_1347 = primals_1348 = getitem_100 = getitem_101 = None
        getitem_2154 = native_batch_norm_backward_default_171[0]
        getitem_2155 = native_batch_norm_backward_default_171[1]
        getitem_2156 = native_batch_norm_backward_default_171[2];  native_batch_norm_backward_default_171 = None
        convolution_backward_default_318 = torch.ops.aten.convolution_backward.default(getitem_2154, convolution_default_53, primals_1353, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2154 = convolution_default_53 = primals_1353 = None
        getitem_2157 = convolution_backward_default_318[0]
        getitem_2158 = convolution_backward_default_318[1]
        getitem_2159 = convolution_backward_default_318[2];  convolution_backward_default_318 = None
        convolution_backward_default_319 = torch.ops.aten.convolution_backward.default(getitem_2157, relu_default_27, primals_1352, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 108, [True, True, False]);  getitem_2157 = primals_1352 = None
        getitem_2160 = convolution_backward_default_319[0]
        getitem_2161 = convolution_backward_default_319[1]
        getitem_2162 = convolution_backward_default_319[2];  convolution_backward_default_319 = None
        to_dtype_516 = torch.ops.aten.to.dtype(getitem_2160, torch.float32);  getitem_2160 = None
        to_dtype_517 = torch.ops.aten.to.dtype(relu_default_27, torch.float32);  relu_default_27 = None
        le_scalar_172 = torch.ops.aten.le.Scalar(to_dtype_517, 0);  to_dtype_517 = None
        new_zeros_default_373 = torch.ops.aten.new_zeros.default(to_dtype_516, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_172 = torch.ops.aten.where.self(le_scalar_172, new_zeros_default_373, to_dtype_516);  le_scalar_172 = new_zeros_default_373 = to_dtype_516 = None
        to_dtype_518 = torch.ops.aten.to.dtype(where_self_172, torch.float32);  where_self_172 = None
        native_batch_norm_backward_default_172 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_518, convolution_default_52, primals_1344, primals_1342, primals_1343, getitem_97, getitem_98, True, 0.001, [True, True, True]);  to_dtype_518 = convolution_default_52 = primals_1344 = primals_1342 = primals_1343 = getitem_97 = getitem_98 = None
        getitem_2163 = native_batch_norm_backward_default_172[0]
        getitem_2164 = native_batch_norm_backward_default_172[1]
        getitem_2165 = native_batch_norm_backward_default_172[2];  native_batch_norm_backward_default_172 = None
        convolution_backward_default_320 = torch.ops.aten.convolution_backward.default(getitem_2163, convolution_default_51, primals_1351, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2163 = convolution_default_51 = primals_1351 = None
        getitem_2166 = convolution_backward_default_320[0]
        getitem_2167 = convolution_backward_default_320[1]
        getitem_2168 = convolution_backward_default_320[2];  convolution_backward_default_320 = None
        convolution_backward_default_321 = torch.ops.aten.convolution_backward.default(getitem_2166, constant_pad_nd_default_16, primals_1350, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 108, [True, True, False]);  getitem_2166 = constant_pad_nd_default_16 = primals_1350 = None
        getitem_2169 = convolution_backward_default_321[0]
        getitem_2170 = convolution_backward_default_321[1]
        getitem_2171 = convolution_backward_default_321[2];  convolution_backward_default_321 = None
        constant_pad_nd_default_55 = torch.ops.aten.constant_pad_nd.default(getitem_2169, [-1, -1, -1, -1]);  getitem_2169 = None
        to_dtype_519 = torch.ops.aten.to.dtype(constant_pad_nd_default_55, torch.float32);  constant_pad_nd_default_55 = None
        to_dtype_520 = torch.ops.aten.to.dtype(relu_default_26, torch.float32);  relu_default_26 = None
        le_scalar_173 = torch.ops.aten.le.Scalar(to_dtype_520, 0);  to_dtype_520 = None
        new_zeros_default_374 = torch.ops.aten.new_zeros.default(to_dtype_519, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_173 = torch.ops.aten.where.self(le_scalar_173, new_zeros_default_374, to_dtype_519);  le_scalar_173 = new_zeros_default_374 = to_dtype_519 = None
        to_dtype_521 = torch.ops.aten.to.dtype(where_self_173, torch.float32);  where_self_173 = None
        max_pool2d_with_indices_backward_default_36 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_69, constant_pad_nd_default_15, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_95);  constant_pad_nd_default_15 = getitem_95 = None
        constant_pad_nd_default_56 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default_36, [-1, -1, -1, -1]);  max_pool2d_with_indices_backward_default_36 = None
        add_tensor_181 = torch.ops.aten.add.Tensor(to_dtype_515, constant_pad_nd_default_56);  to_dtype_515 = constant_pad_nd_default_56 = None
        clone_default_52 = torch.ops.aten.clone.default(slice_tensor_69, memory_format = torch.contiguous_format);  slice_tensor_69 = None
        native_batch_norm_backward_default_173 = torch.ops.aten.native_batch_norm_backward.default(clone_default_52, convolution_default_50, primals_1335, primals_1333, primals_1334, getitem_92, getitem_93, True, 0.001, [True, True, True]);  clone_default_52 = convolution_default_50 = primals_1335 = primals_1333 = primals_1334 = getitem_92 = getitem_93 = None
        getitem_2172 = native_batch_norm_backward_default_173[0]
        getitem_2173 = native_batch_norm_backward_default_173[1]
        getitem_2174 = native_batch_norm_backward_default_173[2];  native_batch_norm_backward_default_173 = None
        convolution_backward_default_322 = torch.ops.aten.convolution_backward.default(getitem_2172, convolution_default_49, primals_1339, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2172 = convolution_default_49 = primals_1339 = None
        getitem_2175 = convolution_backward_default_322[0]
        getitem_2176 = convolution_backward_default_322[1]
        getitem_2177 = convolution_backward_default_322[2];  convolution_backward_default_322 = None
        convolution_backward_default_323 = torch.ops.aten.convolution_backward.default(getitem_2175, relu_default_25, primals_1338, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 108, [True, True, False]);  getitem_2175 = primals_1338 = None
        getitem_2178 = convolution_backward_default_323[0]
        getitem_2179 = convolution_backward_default_323[1]
        getitem_2180 = convolution_backward_default_323[2];  convolution_backward_default_323 = None
        to_dtype_522 = torch.ops.aten.to.dtype(getitem_2178, torch.float32);  getitem_2178 = None
        to_dtype_523 = torch.ops.aten.to.dtype(relu_default_25, torch.float32);  relu_default_25 = None
        le_scalar_174 = torch.ops.aten.le.Scalar(to_dtype_523, 0);  to_dtype_523 = None
        new_zeros_default_375 = torch.ops.aten.new_zeros.default(to_dtype_522, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_174 = torch.ops.aten.where.self(le_scalar_174, new_zeros_default_375, to_dtype_522);  le_scalar_174 = new_zeros_default_375 = to_dtype_522 = None
        to_dtype_524 = torch.ops.aten.to.dtype(where_self_174, torch.float32);  where_self_174 = None
        native_batch_norm_backward_default_174 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_524, convolution_default_48, primals_1330, primals_1328, primals_1329, getitem_89, getitem_90, True, 0.001, [True, True, True]);  to_dtype_524 = convolution_default_48 = primals_1330 = primals_1328 = primals_1329 = getitem_89 = getitem_90 = None
        getitem_2181 = native_batch_norm_backward_default_174[0]
        getitem_2182 = native_batch_norm_backward_default_174[1]
        getitem_2183 = native_batch_norm_backward_default_174[2];  native_batch_norm_backward_default_174 = None
        convolution_backward_default_324 = torch.ops.aten.convolution_backward.default(getitem_2181, convolution_default_47, primals_1337, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2181 = convolution_default_47 = primals_1337 = None
        getitem_2184 = convolution_backward_default_324[0]
        getitem_2185 = convolution_backward_default_324[1]
        getitem_2186 = convolution_backward_default_324[2];  convolution_backward_default_324 = None
        convolution_backward_default_325 = torch.ops.aten.convolution_backward.default(getitem_2184, relu_default_24, primals_1336, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 108, [True, True, False]);  getitem_2184 = primals_1336 = None
        getitem_2187 = convolution_backward_default_325[0]
        getitem_2188 = convolution_backward_default_325[1]
        getitem_2189 = convolution_backward_default_325[2];  convolution_backward_default_325 = None
        to_dtype_525 = torch.ops.aten.to.dtype(getitem_2187, torch.float32);  getitem_2187 = None
        to_dtype_526 = torch.ops.aten.to.dtype(relu_default_24, torch.float32);  relu_default_24 = None
        le_scalar_175 = torch.ops.aten.le.Scalar(to_dtype_526, 0);  to_dtype_526 = None
        new_zeros_default_376 = torch.ops.aten.new_zeros.default(to_dtype_525, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_175 = torch.ops.aten.where.self(le_scalar_175, new_zeros_default_376, to_dtype_525);  le_scalar_175 = new_zeros_default_376 = to_dtype_525 = None
        to_dtype_527 = torch.ops.aten.to.dtype(where_self_175, torch.float32);  where_self_175 = None
        add_tensor_182 = torch.ops.aten.add.Tensor(slice_tensor_68, to_dtype_527);  slice_tensor_68 = to_dtype_527 = None
        native_batch_norm_backward_default_175 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_182, convolution_default_46, primals_1321, primals_1319, primals_1320, getitem_86, getitem_87, True, 0.001, [True, True, True]);  convolution_default_46 = primals_1321 = primals_1319 = primals_1320 = getitem_86 = getitem_87 = None
        getitem_2190 = native_batch_norm_backward_default_175[0]
        getitem_2191 = native_batch_norm_backward_default_175[1]
        getitem_2192 = native_batch_norm_backward_default_175[2];  native_batch_norm_backward_default_175 = None
        convolution_backward_default_326 = torch.ops.aten.convolution_backward.default(getitem_2190, convolution_default_45, primals_1325, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2190 = convolution_default_45 = primals_1325 = None
        getitem_2193 = convolution_backward_default_326[0]
        getitem_2194 = convolution_backward_default_326[1]
        getitem_2195 = convolution_backward_default_326[2];  convolution_backward_default_326 = None
        convolution_backward_default_327 = torch.ops.aten.convolution_backward.default(getitem_2193, relu_default_23, primals_1324, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 108, [True, True, False]);  getitem_2193 = primals_1324 = None
        getitem_2196 = convolution_backward_default_327[0]
        getitem_2197 = convolution_backward_default_327[1]
        getitem_2198 = convolution_backward_default_327[2];  convolution_backward_default_327 = None
        to_dtype_528 = torch.ops.aten.to.dtype(getitem_2196, torch.float32);  getitem_2196 = None
        to_dtype_529 = torch.ops.aten.to.dtype(relu_default_23, torch.float32);  relu_default_23 = None
        le_scalar_176 = torch.ops.aten.le.Scalar(to_dtype_529, 0);  to_dtype_529 = None
        new_zeros_default_377 = torch.ops.aten.new_zeros.default(to_dtype_528, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_176 = torch.ops.aten.where.self(le_scalar_176, new_zeros_default_377, to_dtype_528);  le_scalar_176 = new_zeros_default_377 = to_dtype_528 = None
        to_dtype_530 = torch.ops.aten.to.dtype(where_self_176, torch.float32);  where_self_176 = None
        native_batch_norm_backward_default_176 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_530, convolution_default_44, primals_1316, primals_1314, primals_1315, getitem_83, getitem_84, True, 0.001, [True, True, True]);  to_dtype_530 = convolution_default_44 = primals_1316 = primals_1314 = primals_1315 = getitem_83 = getitem_84 = None
        getitem_2199 = native_batch_norm_backward_default_176[0]
        getitem_2200 = native_batch_norm_backward_default_176[1]
        getitem_2201 = native_batch_norm_backward_default_176[2];  native_batch_norm_backward_default_176 = None
        convolution_backward_default_328 = torch.ops.aten.convolution_backward.default(getitem_2199, convolution_default_43, primals_1323, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2199 = convolution_default_43 = primals_1323 = None
        getitem_2202 = convolution_backward_default_328[0]
        getitem_2203 = convolution_backward_default_328[1]
        getitem_2204 = convolution_backward_default_328[2];  convolution_backward_default_328 = None
        convolution_backward_default_329 = torch.ops.aten.convolution_backward.default(getitem_2202, constant_pad_nd_default_14, primals_1322, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 108, [True, True, False]);  getitem_2202 = constant_pad_nd_default_14 = primals_1322 = None
        getitem_2205 = convolution_backward_default_329[0]
        getitem_2206 = convolution_backward_default_329[1]
        getitem_2207 = convolution_backward_default_329[2];  convolution_backward_default_329 = None
        constant_pad_nd_default_57 = torch.ops.aten.constant_pad_nd.default(getitem_2205, [-1, -1, -1, -1]);  getitem_2205 = None
        to_dtype_531 = torch.ops.aten.to.dtype(constant_pad_nd_default_57, torch.float32);  constant_pad_nd_default_57 = None
        to_dtype_532 = torch.ops.aten.to.dtype(relu_default_22, torch.float32);  relu_default_22 = None
        le_scalar_177 = torch.ops.aten.le.Scalar(to_dtype_532, 0);  to_dtype_532 = None
        new_zeros_default_378 = torch.ops.aten.new_zeros.default(to_dtype_531, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_177 = torch.ops.aten.where.self(le_scalar_177, new_zeros_default_378, to_dtype_531);  le_scalar_177 = new_zeros_default_378 = to_dtype_531 = None
        to_dtype_533 = torch.ops.aten.to.dtype(where_self_177, torch.float32);  where_self_177 = None
        add_tensor_183 = torch.ops.aten.add.Tensor(add_tensor_181, to_dtype_533);  add_tensor_181 = to_dtype_533 = None
        native_batch_norm_backward_default_177 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_182, convolution_default_42, primals_1307, primals_1305, primals_1306, getitem_80, getitem_81, True, 0.001, [True, True, True]);  add_tensor_182 = convolution_default_42 = primals_1307 = primals_1305 = primals_1306 = getitem_80 = getitem_81 = None
        getitem_2208 = native_batch_norm_backward_default_177[0]
        getitem_2209 = native_batch_norm_backward_default_177[1]
        getitem_2210 = native_batch_norm_backward_default_177[2];  native_batch_norm_backward_default_177 = None
        convolution_backward_default_330 = torch.ops.aten.convolution_backward.default(getitem_2208, convolution_default_41, primals_1311, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2208 = convolution_default_41 = primals_1311 = None
        getitem_2211 = convolution_backward_default_330[0]
        getitem_2212 = convolution_backward_default_330[1]
        getitem_2213 = convolution_backward_default_330[2];  convolution_backward_default_330 = None
        convolution_backward_default_331 = torch.ops.aten.convolution_backward.default(getitem_2211, relu_default_21, primals_1310, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 108, [True, True, False]);  getitem_2211 = primals_1310 = None
        getitem_2214 = convolution_backward_default_331[0]
        getitem_2215 = convolution_backward_default_331[1]
        getitem_2216 = convolution_backward_default_331[2];  convolution_backward_default_331 = None
        to_dtype_534 = torch.ops.aten.to.dtype(getitem_2214, torch.float32);  getitem_2214 = None
        to_dtype_535 = torch.ops.aten.to.dtype(relu_default_21, torch.float32);  relu_default_21 = None
        le_scalar_178 = torch.ops.aten.le.Scalar(to_dtype_535, 0);  to_dtype_535 = None
        new_zeros_default_379 = torch.ops.aten.new_zeros.default(to_dtype_534, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_178 = torch.ops.aten.where.self(le_scalar_178, new_zeros_default_379, to_dtype_534);  le_scalar_178 = new_zeros_default_379 = to_dtype_534 = None
        to_dtype_536 = torch.ops.aten.to.dtype(where_self_178, torch.float32);  where_self_178 = None
        native_batch_norm_backward_default_178 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_536, convolution_default_40, primals_1302, primals_1300, primals_1301, getitem_77, getitem_78, True, 0.001, [True, True, True]);  to_dtype_536 = convolution_default_40 = primals_1302 = primals_1300 = primals_1301 = getitem_77 = getitem_78 = None
        getitem_2217 = native_batch_norm_backward_default_178[0]
        getitem_2218 = native_batch_norm_backward_default_178[1]
        getitem_2219 = native_batch_norm_backward_default_178[2];  native_batch_norm_backward_default_178 = None
        convolution_backward_default_332 = torch.ops.aten.convolution_backward.default(getitem_2217, convolution_default_39, primals_1309, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2217 = convolution_default_39 = primals_1309 = None
        getitem_2220 = convolution_backward_default_332[0]
        getitem_2221 = convolution_backward_default_332[1]
        getitem_2222 = convolution_backward_default_332[2];  convolution_backward_default_332 = None
        convolution_backward_default_333 = torch.ops.aten.convolution_backward.default(getitem_2220, constant_pad_nd_default_13, primals_1308, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 108, [True, True, False]);  getitem_2220 = constant_pad_nd_default_13 = primals_1308 = None
        getitem_2223 = convolution_backward_default_333[0]
        getitem_2224 = convolution_backward_default_333[1]
        getitem_2225 = convolution_backward_default_333[2];  convolution_backward_default_333 = None
        constant_pad_nd_default_58 = torch.ops.aten.constant_pad_nd.default(getitem_2223, [-2, -2, -2, -2]);  getitem_2223 = None
        to_dtype_537 = torch.ops.aten.to.dtype(constant_pad_nd_default_58, torch.float32);  constant_pad_nd_default_58 = None
        to_dtype_538 = torch.ops.aten.to.dtype(relu_default_20, torch.float32);  relu_default_20 = None
        le_scalar_179 = torch.ops.aten.le.Scalar(to_dtype_538, 0);  to_dtype_538 = None
        new_zeros_default_380 = torch.ops.aten.new_zeros.default(to_dtype_537, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_179 = torch.ops.aten.where.self(le_scalar_179, new_zeros_default_380, to_dtype_537);  le_scalar_179 = new_zeros_default_380 = to_dtype_537 = None
        to_dtype_539 = torch.ops.aten.to.dtype(where_self_179, torch.float32);  where_self_179 = None
        add_tensor_184 = torch.ops.aten.add.Tensor(add_tensor_183, to_dtype_539);  add_tensor_183 = to_dtype_539 = None
        max_pool2d_with_indices_backward_default_37 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_67, constant_pad_nd_default_12, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_75);  constant_pad_nd_default_12 = getitem_75 = None
        constant_pad_nd_default_59 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default_37, [-1, -1, -1, -1]);  max_pool2d_with_indices_backward_default_37 = None
        add_tensor_185 = torch.ops.aten.add.Tensor(add_tensor_184, constant_pad_nd_default_59);  add_tensor_184 = constant_pad_nd_default_59 = None
        clone_default_53 = torch.ops.aten.clone.default(slice_tensor_67, memory_format = torch.contiguous_format);  slice_tensor_67 = None
        native_batch_norm_backward_default_179 = torch.ops.aten.native_batch_norm_backward.default(clone_default_53, convolution_default_38, primals_1293, primals_1291, primals_1292, getitem_72, getitem_73, True, 0.001, [True, True, True]);  clone_default_53 = convolution_default_38 = primals_1293 = primals_1291 = primals_1292 = getitem_72 = getitem_73 = None
        getitem_2226 = native_batch_norm_backward_default_179[0]
        getitem_2227 = native_batch_norm_backward_default_179[1]
        getitem_2228 = native_batch_norm_backward_default_179[2];  native_batch_norm_backward_default_179 = None
        convolution_backward_default_334 = torch.ops.aten.convolution_backward.default(getitem_2226, convolution_default_37, primals_1297, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2226 = convolution_default_37 = primals_1297 = None
        getitem_2229 = convolution_backward_default_334[0]
        getitem_2230 = convolution_backward_default_334[1]
        getitem_2231 = convolution_backward_default_334[2];  convolution_backward_default_334 = None
        convolution_backward_default_335 = torch.ops.aten.convolution_backward.default(getitem_2229, relu_default_19, primals_1296, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 108, [True, True, False]);  getitem_2229 = primals_1296 = None
        getitem_2232 = convolution_backward_default_335[0]
        getitem_2233 = convolution_backward_default_335[1]
        getitem_2234 = convolution_backward_default_335[2];  convolution_backward_default_335 = None
        to_dtype_540 = torch.ops.aten.to.dtype(getitem_2232, torch.float32);  getitem_2232 = None
        to_dtype_541 = torch.ops.aten.to.dtype(relu_default_19, torch.float32);  relu_default_19 = None
        le_scalar_180 = torch.ops.aten.le.Scalar(to_dtype_541, 0);  to_dtype_541 = None
        new_zeros_default_381 = torch.ops.aten.new_zeros.default(to_dtype_540, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_180 = torch.ops.aten.where.self(le_scalar_180, new_zeros_default_381, to_dtype_540);  le_scalar_180 = new_zeros_default_381 = to_dtype_540 = None
        to_dtype_542 = torch.ops.aten.to.dtype(where_self_180, torch.float32);  where_self_180 = None
        native_batch_norm_backward_default_180 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_542, convolution_default_36, primals_1288, primals_1286, primals_1287, getitem_69, getitem_70, True, 0.001, [True, True, True]);  to_dtype_542 = convolution_default_36 = primals_1288 = primals_1286 = primals_1287 = getitem_69 = getitem_70 = None
        getitem_2235 = native_batch_norm_backward_default_180[0]
        getitem_2236 = native_batch_norm_backward_default_180[1]
        getitem_2237 = native_batch_norm_backward_default_180[2];  native_batch_norm_backward_default_180 = None
        convolution_backward_default_336 = torch.ops.aten.convolution_backward.default(getitem_2235, convolution_default_35, primals_1295, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2235 = convolution_default_35 = primals_1295 = None
        getitem_2238 = convolution_backward_default_336[0]
        getitem_2239 = convolution_backward_default_336[1]
        getitem_2240 = convolution_backward_default_336[2];  convolution_backward_default_336 = None
        convolution_backward_default_337 = torch.ops.aten.convolution_backward.default(getitem_2238, constant_pad_nd_default_11, primals_1294, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 108, [True, True, False]);  getitem_2238 = constant_pad_nd_default_11 = primals_1294 = None
        getitem_2241 = convolution_backward_default_337[0]
        getitem_2242 = convolution_backward_default_337[1]
        getitem_2243 = convolution_backward_default_337[2];  convolution_backward_default_337 = None
        constant_pad_nd_default_60 = torch.ops.aten.constant_pad_nd.default(getitem_2241, [-3, -3, -3, -3]);  getitem_2241 = None
        to_dtype_543 = torch.ops.aten.to.dtype(constant_pad_nd_default_60, torch.float32);  constant_pad_nd_default_60 = None
        to_dtype_544 = torch.ops.aten.to.dtype(relu_default_18, torch.float32);  relu_default_18 = None
        le_scalar_181 = torch.ops.aten.le.Scalar(to_dtype_544, 0);  to_dtype_544 = None
        new_zeros_default_382 = torch.ops.aten.new_zeros.default(to_dtype_543, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_181 = torch.ops.aten.where.self(le_scalar_181, new_zeros_default_382, to_dtype_543);  le_scalar_181 = new_zeros_default_382 = to_dtype_543 = None
        to_dtype_545 = torch.ops.aten.to.dtype(where_self_181, torch.float32);  where_self_181 = None
        add_tensor_186 = torch.ops.aten.add.Tensor(add_tensor_185, to_dtype_545);  add_tensor_185 = to_dtype_545 = None
        max_pool2d_with_indices_backward_default_38 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_66, constant_pad_nd_default_10, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_67);  constant_pad_nd_default_10 = getitem_67 = None
        constant_pad_nd_default_61 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default_38, [-1, -1, -1, -1]);  max_pool2d_with_indices_backward_default_38 = None
        add_tensor_187 = torch.ops.aten.add.Tensor(to_dtype_521, constant_pad_nd_default_61);  to_dtype_521 = constant_pad_nd_default_61 = None
        clone_default_54 = torch.ops.aten.clone.default(slice_tensor_66, memory_format = torch.contiguous_format);  slice_tensor_66 = None
        native_batch_norm_backward_default_181 = torch.ops.aten.native_batch_norm_backward.default(clone_default_54, convolution_default_34, primals_1279, primals_1277, primals_1278, getitem_64, getitem_65, True, 0.001, [True, True, True]);  clone_default_54 = convolution_default_34 = primals_1279 = primals_1277 = primals_1278 = getitem_64 = getitem_65 = None
        getitem_2244 = native_batch_norm_backward_default_181[0]
        getitem_2245 = native_batch_norm_backward_default_181[1]
        getitem_2246 = native_batch_norm_backward_default_181[2];  native_batch_norm_backward_default_181 = None
        convolution_backward_default_338 = torch.ops.aten.convolution_backward.default(getitem_2244, convolution_default_33, primals_1283, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2244 = convolution_default_33 = primals_1283 = None
        getitem_2247 = convolution_backward_default_338[0]
        getitem_2248 = convolution_backward_default_338[1]
        getitem_2249 = convolution_backward_default_338[2];  convolution_backward_default_338 = None
        convolution_backward_default_339 = torch.ops.aten.convolution_backward.default(getitem_2247, relu_default_17, primals_1282, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 108, [True, True, False]);  getitem_2247 = primals_1282 = None
        getitem_2250 = convolution_backward_default_339[0]
        getitem_2251 = convolution_backward_default_339[1]
        getitem_2252 = convolution_backward_default_339[2];  convolution_backward_default_339 = None
        to_dtype_546 = torch.ops.aten.to.dtype(getitem_2250, torch.float32);  getitem_2250 = None
        to_dtype_547 = torch.ops.aten.to.dtype(relu_default_17, torch.float32);  relu_default_17 = None
        le_scalar_182 = torch.ops.aten.le.Scalar(to_dtype_547, 0);  to_dtype_547 = None
        new_zeros_default_383 = torch.ops.aten.new_zeros.default(to_dtype_546, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_182 = torch.ops.aten.where.self(le_scalar_182, new_zeros_default_383, to_dtype_546);  le_scalar_182 = new_zeros_default_383 = to_dtype_546 = None
        to_dtype_548 = torch.ops.aten.to.dtype(where_self_182, torch.float32);  where_self_182 = None
        native_batch_norm_backward_default_182 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_548, convolution_default_32, primals_1274, primals_1272, primals_1273, getitem_61, getitem_62, True, 0.001, [True, True, True]);  to_dtype_548 = convolution_default_32 = primals_1274 = primals_1272 = primals_1273 = getitem_61 = getitem_62 = None
        getitem_2253 = native_batch_norm_backward_default_182[0]
        getitem_2254 = native_batch_norm_backward_default_182[1]
        getitem_2255 = native_batch_norm_backward_default_182[2];  native_batch_norm_backward_default_182 = None
        convolution_backward_default_340 = torch.ops.aten.convolution_backward.default(getitem_2253, convolution_default_31, primals_1281, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2253 = convolution_default_31 = primals_1281 = None
        getitem_2256 = convolution_backward_default_340[0]
        getitem_2257 = convolution_backward_default_340[1]
        getitem_2258 = convolution_backward_default_340[2];  convolution_backward_default_340 = None
        convolution_backward_default_341 = torch.ops.aten.convolution_backward.default(getitem_2256, constant_pad_nd_default_9, primals_1280, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 108, [True, True, False]);  getitem_2256 = constant_pad_nd_default_9 = primals_1280 = None
        getitem_2259 = convolution_backward_default_341[0]
        getitem_2260 = convolution_backward_default_341[1]
        getitem_2261 = convolution_backward_default_341[2];  convolution_backward_default_341 = None
        constant_pad_nd_default_62 = torch.ops.aten.constant_pad_nd.default(getitem_2259, [-2, -2, -2, -2]);  getitem_2259 = None
        to_dtype_549 = torch.ops.aten.to.dtype(constant_pad_nd_default_62, torch.float32);  constant_pad_nd_default_62 = None
        to_dtype_550 = torch.ops.aten.to.dtype(relu_default_16, torch.float32);  relu_default_16 = None
        le_scalar_183 = torch.ops.aten.le.Scalar(to_dtype_550, 0);  to_dtype_550 = None
        new_zeros_default_384 = torch.ops.aten.new_zeros.default(to_dtype_549, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_183 = torch.ops.aten.where.self(le_scalar_183, new_zeros_default_384, to_dtype_549);  le_scalar_183 = new_zeros_default_384 = to_dtype_549 = None
        to_dtype_551 = torch.ops.aten.to.dtype(where_self_183, torch.float32);  where_self_183 = None
        add_tensor_188 = torch.ops.aten.add.Tensor(add_tensor_187, to_dtype_551);  add_tensor_187 = to_dtype_551 = None
        native_batch_norm_backward_default_183 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_186, convolution_default_30, primals_1364, primals_1362, primals_1363, getitem_58, getitem_59, True, 0.001, [True, True, True]);  add_tensor_186 = convolution_default_30 = primals_1364 = primals_1362 = primals_1363 = getitem_58 = getitem_59 = None
        getitem_2262 = native_batch_norm_backward_default_183[0]
        getitem_2263 = native_batch_norm_backward_default_183[1]
        getitem_2264 = native_batch_norm_backward_default_183[2];  native_batch_norm_backward_default_183 = None
        convolution_backward_default_342 = torch.ops.aten.convolution_backward.default(getitem_2262, relu_default_15, primals_1365, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2262 = primals_1365 = None
        getitem_2265 = convolution_backward_default_342[0]
        getitem_2266 = convolution_backward_default_342[1]
        getitem_2267 = convolution_backward_default_342[2];  convolution_backward_default_342 = None
        to_dtype_552 = torch.ops.aten.to.dtype(getitem_2265, torch.float32);  getitem_2265 = None
        to_dtype_553 = torch.ops.aten.to.dtype(relu_default_15, torch.float32);  relu_default_15 = None
        le_scalar_184 = torch.ops.aten.le.Scalar(to_dtype_553, 0);  to_dtype_553 = None
        new_zeros_default_385 = torch.ops.aten.new_zeros.default(to_dtype_552, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_184 = torch.ops.aten.where.self(le_scalar_184, new_zeros_default_385, to_dtype_552);  le_scalar_184 = new_zeros_default_385 = to_dtype_552 = None
        to_dtype_554 = torch.ops.aten.to.dtype(where_self_184, torch.float32);  where_self_184 = None
        add_tensor_189 = torch.ops.aten.add.Tensor(to_dtype_512, to_dtype_554);  to_dtype_512 = to_dtype_554 = None
        native_batch_norm_backward_default_184 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_188, cat_default_1, primals_1370, primals_1368, primals_1369, getitem_55, getitem_56, True, 0.001, [True, True, True]);  add_tensor_188 = cat_default_1 = primals_1370 = primals_1368 = primals_1369 = getitem_55 = getitem_56 = None
        getitem_2268 = native_batch_norm_backward_default_184[0]
        getitem_2269 = native_batch_norm_backward_default_184[1]
        getitem_2270 = native_batch_norm_backward_default_184[2];  native_batch_norm_backward_default_184 = None
        slice_tensor_71 = torch.ops.aten.slice.Tensor(getitem_2268, 1, 0, 54)
        slice_tensor_72 = torch.ops.aten.slice.Tensor(getitem_2268, 1, 54, 108);  getitem_2268 = None
        convolution_backward_default_343 = torch.ops.aten.convolution_backward.default(slice_tensor_72, avg_pool2d_default_1, primals_1372, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_72 = avg_pool2d_default_1 = primals_1372 = None
        getitem_2271 = convolution_backward_default_343[0]
        getitem_2272 = convolution_backward_default_343[1]
        getitem_2273 = convolution_backward_default_343[2];  convolution_backward_default_343 = None
        avg_pool2d_backward_default_6 = torch.ops.aten.avg_pool2d_backward.default(getitem_2271, constant_pad_nd_default_8, [1, 1], [2, 2], [0, 0], False, False, None);  getitem_2271 = constant_pad_nd_default_8 = None
        constant_pad_nd_default_63 = torch.ops.aten.constant_pad_nd.default(avg_pool2d_backward_default_6, [1, -1, 1, -1]);  avg_pool2d_backward_default_6 = None
        convolution_backward_default_344 = torch.ops.aten.convolution_backward.default(slice_tensor_71, avg_pool2d_default, primals_1371, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_71 = avg_pool2d_default = primals_1371 = None
        getitem_2274 = convolution_backward_default_344[0]
        getitem_2275 = convolution_backward_default_344[1]
        getitem_2276 = convolution_backward_default_344[2];  convolution_backward_default_344 = None
        avg_pool2d_backward_default_7 = torch.ops.aten.avg_pool2d_backward.default(getitem_2274, relu_default_14, [1, 1], [2, 2], [0, 0], False, False, None);  getitem_2274 = None
        add_tensor_190 = torch.ops.aten.add.Tensor(constant_pad_nd_default_63, avg_pool2d_backward_default_7);  constant_pad_nd_default_63 = avg_pool2d_backward_default_7 = None
        to_dtype_555 = torch.ops.aten.to.dtype(add_tensor_190, torch.float32);  add_tensor_190 = None
        to_dtype_556 = torch.ops.aten.to.dtype(relu_default_14, torch.float32);  relu_default_14 = None
        le_scalar_185 = torch.ops.aten.le.Scalar(to_dtype_556, 0);  to_dtype_556 = None
        new_zeros_default_386 = torch.ops.aten.new_zeros.default(to_dtype_555, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_185 = torch.ops.aten.where.self(le_scalar_185, new_zeros_default_386, to_dtype_555);  le_scalar_185 = new_zeros_default_386 = to_dtype_555 = None
        to_dtype_557 = torch.ops.aten.to.dtype(where_self_185, torch.float32);  where_self_185 = None
        slice_tensor_73 = torch.ops.aten.slice.Tensor(add_tensor_189, 1, 0, 54)
        slice_tensor_74 = torch.ops.aten.slice.Tensor(add_tensor_189, 1, 54, 108)
        slice_tensor_75 = torch.ops.aten.slice.Tensor(add_tensor_189, 1, 108, 162)
        slice_tensor_76 = torch.ops.aten.slice.Tensor(add_tensor_189, 1, 162, 216)
        slice_tensor_77 = torch.ops.aten.slice.Tensor(add_tensor_189, 1, 216, 270);  add_tensor_189 = None
        clone_default_55 = torch.ops.aten.clone.default(slice_tensor_77, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_185 = torch.ops.aten.native_batch_norm_backward.default(clone_default_55, convolution_default_27, primals_1262, primals_1260, primals_1261, getitem_52, getitem_53, True, 0.001, [True, True, True]);  clone_default_55 = convolution_default_27 = primals_1262 = primals_1260 = primals_1261 = getitem_52 = getitem_53 = None
        getitem_2277 = native_batch_norm_backward_default_185[0]
        getitem_2278 = native_batch_norm_backward_default_185[1]
        getitem_2279 = native_batch_norm_backward_default_185[2];  native_batch_norm_backward_default_185 = None
        convolution_backward_default_345 = torch.ops.aten.convolution_backward.default(getitem_2277, relu_default_13, primals_1263, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2277 = primals_1263 = None
        getitem_2280 = convolution_backward_default_345[0]
        getitem_2281 = convolution_backward_default_345[1]
        getitem_2282 = convolution_backward_default_345[2];  convolution_backward_default_345 = None
        to_dtype_558 = torch.ops.aten.to.dtype(getitem_2280, torch.float32);  getitem_2280 = None
        to_dtype_559 = torch.ops.aten.to.dtype(relu_default_13, torch.float32);  relu_default_13 = None
        le_scalar_186 = torch.ops.aten.le.Scalar(to_dtype_559, 0);  to_dtype_559 = None
        new_zeros_default_387 = torch.ops.aten.new_zeros.default(to_dtype_558, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_186 = torch.ops.aten.where.self(le_scalar_186, new_zeros_default_387, to_dtype_558);  le_scalar_186 = new_zeros_default_387 = to_dtype_558 = None
        to_dtype_560 = torch.ops.aten.to.dtype(where_self_186, torch.float32);  where_self_186 = None
        clone_default_56 = torch.ops.aten.clone.default(slice_tensor_77, memory_format = torch.contiguous_format);  slice_tensor_77 = None
        native_batch_norm_backward_default_186 = torch.ops.aten.native_batch_norm_backward.default(clone_default_56, convolution_default_26, primals_1253, primals_1251, primals_1252, getitem_49, getitem_50, True, 0.001, [True, True, True]);  clone_default_56 = convolution_default_26 = primals_1253 = primals_1251 = primals_1252 = getitem_49 = getitem_50 = None
        getitem_2283 = native_batch_norm_backward_default_186[0]
        getitem_2284 = native_batch_norm_backward_default_186[1]
        getitem_2285 = native_batch_norm_backward_default_186[2];  native_batch_norm_backward_default_186 = None
        convolution_backward_default_346 = torch.ops.aten.convolution_backward.default(getitem_2283, convolution_default_25, primals_1257, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2283 = convolution_default_25 = primals_1257 = None
        getitem_2286 = convolution_backward_default_346[0]
        getitem_2287 = convolution_backward_default_346[1]
        getitem_2288 = convolution_backward_default_346[2];  convolution_backward_default_346 = None
        convolution_backward_default_347 = torch.ops.aten.convolution_backward.default(getitem_2286, relu_default_12, primals_1256, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 54, [True, True, False]);  getitem_2286 = primals_1256 = None
        getitem_2289 = convolution_backward_default_347[0]
        getitem_2290 = convolution_backward_default_347[1]
        getitem_2291 = convolution_backward_default_347[2];  convolution_backward_default_347 = None
        to_dtype_561 = torch.ops.aten.to.dtype(getitem_2289, torch.float32);  getitem_2289 = None
        to_dtype_562 = torch.ops.aten.to.dtype(relu_default_12, torch.float32);  relu_default_12 = None
        le_scalar_187 = torch.ops.aten.le.Scalar(to_dtype_562, 0);  to_dtype_562 = None
        new_zeros_default_388 = torch.ops.aten.new_zeros.default(to_dtype_561, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_187 = torch.ops.aten.where.self(le_scalar_187, new_zeros_default_388, to_dtype_561);  le_scalar_187 = new_zeros_default_388 = to_dtype_561 = None
        to_dtype_563 = torch.ops.aten.to.dtype(where_self_187, torch.float32);  where_self_187 = None
        native_batch_norm_backward_default_187 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_563, convolution_default_24, primals_1248, primals_1246, primals_1247, getitem_46, getitem_47, True, 0.001, [True, True, True]);  to_dtype_563 = convolution_default_24 = primals_1248 = primals_1246 = primals_1247 = getitem_46 = getitem_47 = None
        getitem_2292 = native_batch_norm_backward_default_187[0]
        getitem_2293 = native_batch_norm_backward_default_187[1]
        getitem_2294 = native_batch_norm_backward_default_187[2];  native_batch_norm_backward_default_187 = None
        convolution_backward_default_348 = torch.ops.aten.convolution_backward.default(getitem_2292, convolution_default_23, primals_1255, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2292 = convolution_default_23 = primals_1255 = None
        getitem_2295 = convolution_backward_default_348[0]
        getitem_2296 = convolution_backward_default_348[1]
        getitem_2297 = convolution_backward_default_348[2];  convolution_backward_default_348 = None
        convolution_backward_default_349 = torch.ops.aten.convolution_backward.default(getitem_2295, constant_pad_nd_default_7, primals_1254, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 96, [True, True, False]);  getitem_2295 = constant_pad_nd_default_7 = primals_1254 = None
        getitem_2298 = convolution_backward_default_349[0]
        getitem_2299 = convolution_backward_default_349[1]
        getitem_2300 = convolution_backward_default_349[2];  convolution_backward_default_349 = None
        constant_pad_nd_default_64 = torch.ops.aten.constant_pad_nd.default(getitem_2298, [-1, -1, -1, -1]);  getitem_2298 = None
        to_dtype_564 = torch.ops.aten.to.dtype(constant_pad_nd_default_64, torch.float32);  constant_pad_nd_default_64 = None
        to_dtype_565 = torch.ops.aten.to.dtype(relu_default_11, torch.float32);  relu_default_11 = None
        le_scalar_188 = torch.ops.aten.le.Scalar(to_dtype_565, 0);  to_dtype_565 = None
        new_zeros_default_389 = torch.ops.aten.new_zeros.default(to_dtype_564, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_188 = torch.ops.aten.where.self(le_scalar_188, new_zeros_default_389, to_dtype_564);  le_scalar_188 = new_zeros_default_389 = to_dtype_564 = None
        to_dtype_566 = torch.ops.aten.to.dtype(where_self_188, torch.float32);  where_self_188 = None
        add_tensor_191 = torch.ops.aten.add.Tensor(to_dtype_557, to_dtype_566);  to_dtype_557 = to_dtype_566 = None
        max_pool2d_with_indices_backward_default_39 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_76, constant_pad_nd_default_6, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_44);  constant_pad_nd_default_6 = getitem_44 = None
        constant_pad_nd_default_65 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default_39, [-1, -1, -1, -1]);  max_pool2d_with_indices_backward_default_39 = None
        add_tensor_192 = torch.ops.aten.add.Tensor(to_dtype_560, constant_pad_nd_default_65);  to_dtype_560 = constant_pad_nd_default_65 = None
        clone_default_57 = torch.ops.aten.clone.default(slice_tensor_76, memory_format = torch.contiguous_format);  slice_tensor_76 = None
        native_batch_norm_backward_default_188 = torch.ops.aten.native_batch_norm_backward.default(clone_default_57, convolution_default_22, primals_1239, primals_1237, primals_1238, getitem_41, getitem_42, True, 0.001, [True, True, True]);  clone_default_57 = convolution_default_22 = primals_1239 = primals_1237 = primals_1238 = getitem_41 = getitem_42 = None
        getitem_2301 = native_batch_norm_backward_default_188[0]
        getitem_2302 = native_batch_norm_backward_default_188[1]
        getitem_2303 = native_batch_norm_backward_default_188[2];  native_batch_norm_backward_default_188 = None
        convolution_backward_default_350 = torch.ops.aten.convolution_backward.default(getitem_2301, convolution_default_21, primals_1243, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2301 = convolution_default_21 = primals_1243 = None
        getitem_2304 = convolution_backward_default_350[0]
        getitem_2305 = convolution_backward_default_350[1]
        getitem_2306 = convolution_backward_default_350[2];  convolution_backward_default_350 = None
        convolution_backward_default_351 = torch.ops.aten.convolution_backward.default(getitem_2304, relu_default_10, primals_1242, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 54, [True, True, False]);  getitem_2304 = primals_1242 = None
        getitem_2307 = convolution_backward_default_351[0]
        getitem_2308 = convolution_backward_default_351[1]
        getitem_2309 = convolution_backward_default_351[2];  convolution_backward_default_351 = None
        to_dtype_567 = torch.ops.aten.to.dtype(getitem_2307, torch.float32);  getitem_2307 = None
        to_dtype_568 = torch.ops.aten.to.dtype(relu_default_10, torch.float32);  relu_default_10 = None
        le_scalar_189 = torch.ops.aten.le.Scalar(to_dtype_568, 0);  to_dtype_568 = None
        new_zeros_default_390 = torch.ops.aten.new_zeros.default(to_dtype_567, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_189 = torch.ops.aten.where.self(le_scalar_189, new_zeros_default_390, to_dtype_567);  le_scalar_189 = new_zeros_default_390 = to_dtype_567 = None
        to_dtype_569 = torch.ops.aten.to.dtype(where_self_189, torch.float32);  where_self_189 = None
        native_batch_norm_backward_default_189 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_569, convolution_default_20, primals_1234, primals_1232, primals_1233, getitem_38, getitem_39, True, 0.001, [True, True, True]);  to_dtype_569 = convolution_default_20 = primals_1234 = primals_1232 = primals_1233 = getitem_38 = getitem_39 = None
        getitem_2310 = native_batch_norm_backward_default_189[0]
        getitem_2311 = native_batch_norm_backward_default_189[1]
        getitem_2312 = native_batch_norm_backward_default_189[2];  native_batch_norm_backward_default_189 = None
        convolution_backward_default_352 = torch.ops.aten.convolution_backward.default(getitem_2310, convolution_default_19, primals_1241, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2310 = convolution_default_19 = primals_1241 = None
        getitem_2313 = convolution_backward_default_352[0]
        getitem_2314 = convolution_backward_default_352[1]
        getitem_2315 = convolution_backward_default_352[2];  convolution_backward_default_352 = None
        convolution_backward_default_353 = torch.ops.aten.convolution_backward.default(getitem_2313, relu_default_9, primals_1240, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 54, [True, True, False]);  getitem_2313 = primals_1240 = None
        getitem_2316 = convolution_backward_default_353[0]
        getitem_2317 = convolution_backward_default_353[1]
        getitem_2318 = convolution_backward_default_353[2];  convolution_backward_default_353 = None
        to_dtype_570 = torch.ops.aten.to.dtype(getitem_2316, torch.float32);  getitem_2316 = None
        to_dtype_571 = torch.ops.aten.to.dtype(relu_default_9, torch.float32);  relu_default_9 = None
        le_scalar_190 = torch.ops.aten.le.Scalar(to_dtype_571, 0);  to_dtype_571 = None
        new_zeros_default_391 = torch.ops.aten.new_zeros.default(to_dtype_570, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_190 = torch.ops.aten.where.self(le_scalar_190, new_zeros_default_391, to_dtype_570);  le_scalar_190 = new_zeros_default_391 = to_dtype_570 = None
        to_dtype_572 = torch.ops.aten.to.dtype(where_self_190, torch.float32);  where_self_190 = None
        add_tensor_193 = torch.ops.aten.add.Tensor(slice_tensor_75, to_dtype_572);  slice_tensor_75 = to_dtype_572 = None
        native_batch_norm_backward_default_190 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_193, convolution_default_18, primals_1225, primals_1223, primals_1224, getitem_35, getitem_36, True, 0.001, [True, True, True]);  convolution_default_18 = primals_1225 = primals_1223 = primals_1224 = getitem_35 = getitem_36 = None
        getitem_2319 = native_batch_norm_backward_default_190[0]
        getitem_2320 = native_batch_norm_backward_default_190[1]
        getitem_2321 = native_batch_norm_backward_default_190[2];  native_batch_norm_backward_default_190 = None
        convolution_backward_default_354 = torch.ops.aten.convolution_backward.default(getitem_2319, convolution_default_17, primals_1229, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2319 = convolution_default_17 = primals_1229 = None
        getitem_2322 = convolution_backward_default_354[0]
        getitem_2323 = convolution_backward_default_354[1]
        getitem_2324 = convolution_backward_default_354[2];  convolution_backward_default_354 = None
        convolution_backward_default_355 = torch.ops.aten.convolution_backward.default(getitem_2322, relu_default_8, primals_1228, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 54, [True, True, False]);  getitem_2322 = primals_1228 = None
        getitem_2325 = convolution_backward_default_355[0]
        getitem_2326 = convolution_backward_default_355[1]
        getitem_2327 = convolution_backward_default_355[2];  convolution_backward_default_355 = None
        to_dtype_573 = torch.ops.aten.to.dtype(getitem_2325, torch.float32);  getitem_2325 = None
        to_dtype_574 = torch.ops.aten.to.dtype(relu_default_8, torch.float32);  relu_default_8 = None
        le_scalar_191 = torch.ops.aten.le.Scalar(to_dtype_574, 0);  to_dtype_574 = None
        new_zeros_default_392 = torch.ops.aten.new_zeros.default(to_dtype_573, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_191 = torch.ops.aten.where.self(le_scalar_191, new_zeros_default_392, to_dtype_573);  le_scalar_191 = new_zeros_default_392 = to_dtype_573 = None
        to_dtype_575 = torch.ops.aten.to.dtype(where_self_191, torch.float32);  where_self_191 = None
        native_batch_norm_backward_default_191 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_575, convolution_default_16, primals_1220, primals_1218, primals_1219, getitem_32, getitem_33, True, 0.001, [True, True, True]);  to_dtype_575 = convolution_default_16 = primals_1220 = primals_1218 = primals_1219 = getitem_32 = getitem_33 = None
        getitem_2328 = native_batch_norm_backward_default_191[0]
        getitem_2329 = native_batch_norm_backward_default_191[1]
        getitem_2330 = native_batch_norm_backward_default_191[2];  native_batch_norm_backward_default_191 = None
        convolution_backward_default_356 = torch.ops.aten.convolution_backward.default(getitem_2328, convolution_default_15, primals_1227, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2328 = convolution_default_15 = primals_1227 = None
        getitem_2331 = convolution_backward_default_356[0]
        getitem_2332 = convolution_backward_default_356[1]
        getitem_2333 = convolution_backward_default_356[2];  convolution_backward_default_356 = None
        convolution_backward_default_357 = torch.ops.aten.convolution_backward.default(getitem_2331, constant_pad_nd_default_5, primals_1226, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 54, [True, True, False]);  getitem_2331 = constant_pad_nd_default_5 = primals_1226 = None
        getitem_2334 = convolution_backward_default_357[0]
        getitem_2335 = convolution_backward_default_357[1]
        getitem_2336 = convolution_backward_default_357[2];  convolution_backward_default_357 = None
        constant_pad_nd_default_66 = torch.ops.aten.constant_pad_nd.default(getitem_2334, [-1, -1, -1, -1]);  getitem_2334 = None
        to_dtype_576 = torch.ops.aten.to.dtype(constant_pad_nd_default_66, torch.float32);  constant_pad_nd_default_66 = None
        to_dtype_577 = torch.ops.aten.to.dtype(relu_default_7, torch.float32);  relu_default_7 = None
        le_scalar_192 = torch.ops.aten.le.Scalar(to_dtype_577, 0);  to_dtype_577 = None
        new_zeros_default_393 = torch.ops.aten.new_zeros.default(to_dtype_576, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_192 = torch.ops.aten.where.self(le_scalar_192, new_zeros_default_393, to_dtype_576);  le_scalar_192 = new_zeros_default_393 = to_dtype_576 = None
        to_dtype_578 = torch.ops.aten.to.dtype(where_self_192, torch.float32);  where_self_192 = None
        add_tensor_194 = torch.ops.aten.add.Tensor(add_tensor_192, to_dtype_578);  add_tensor_192 = to_dtype_578 = None
        native_batch_norm_backward_default_192 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_193, convolution_default_14, primals_1211, primals_1209, primals_1210, getitem_29, getitem_30, True, 0.001, [True, True, True]);  add_tensor_193 = convolution_default_14 = primals_1211 = primals_1209 = primals_1210 = getitem_29 = getitem_30 = None
        getitem_2337 = native_batch_norm_backward_default_192[0]
        getitem_2338 = native_batch_norm_backward_default_192[1]
        getitem_2339 = native_batch_norm_backward_default_192[2];  native_batch_norm_backward_default_192 = None
        convolution_backward_default_358 = torch.ops.aten.convolution_backward.default(getitem_2337, convolution_default_13, primals_1215, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2337 = convolution_default_13 = primals_1215 = None
        getitem_2340 = convolution_backward_default_358[0]
        getitem_2341 = convolution_backward_default_358[1]
        getitem_2342 = convolution_backward_default_358[2];  convolution_backward_default_358 = None
        convolution_backward_default_359 = torch.ops.aten.convolution_backward.default(getitem_2340, relu_default_6, primals_1214, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 54, [True, True, False]);  getitem_2340 = primals_1214 = None
        getitem_2343 = convolution_backward_default_359[0]
        getitem_2344 = convolution_backward_default_359[1]
        getitem_2345 = convolution_backward_default_359[2];  convolution_backward_default_359 = None
        to_dtype_579 = torch.ops.aten.to.dtype(getitem_2343, torch.float32);  getitem_2343 = None
        to_dtype_580 = torch.ops.aten.to.dtype(relu_default_6, torch.float32);  relu_default_6 = None
        le_scalar_193 = torch.ops.aten.le.Scalar(to_dtype_580, 0);  to_dtype_580 = None
        new_zeros_default_394 = torch.ops.aten.new_zeros.default(to_dtype_579, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_193 = torch.ops.aten.where.self(le_scalar_193, new_zeros_default_394, to_dtype_579);  le_scalar_193 = new_zeros_default_394 = to_dtype_579 = None
        to_dtype_581 = torch.ops.aten.to.dtype(where_self_193, torch.float32);  where_self_193 = None
        native_batch_norm_backward_default_193 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_581, convolution_default_12, primals_1206, primals_1204, primals_1205, getitem_26, getitem_27, True, 0.001, [True, True, True]);  to_dtype_581 = convolution_default_12 = primals_1206 = primals_1204 = primals_1205 = getitem_26 = getitem_27 = None
        getitem_2346 = native_batch_norm_backward_default_193[0]
        getitem_2347 = native_batch_norm_backward_default_193[1]
        getitem_2348 = native_batch_norm_backward_default_193[2];  native_batch_norm_backward_default_193 = None
        convolution_backward_default_360 = torch.ops.aten.convolution_backward.default(getitem_2346, convolution_default_11, primals_1213, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2346 = convolution_default_11 = primals_1213 = None
        getitem_2349 = convolution_backward_default_360[0]
        getitem_2350 = convolution_backward_default_360[1]
        getitem_2351 = convolution_backward_default_360[2];  convolution_backward_default_360 = None
        convolution_backward_default_361 = torch.ops.aten.convolution_backward.default(getitem_2349, constant_pad_nd_default_4, primals_1212, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 54, [True, True, False]);  getitem_2349 = constant_pad_nd_default_4 = primals_1212 = None
        getitem_2352 = convolution_backward_default_361[0]
        getitem_2353 = convolution_backward_default_361[1]
        getitem_2354 = convolution_backward_default_361[2];  convolution_backward_default_361 = None
        constant_pad_nd_default_67 = torch.ops.aten.constant_pad_nd.default(getitem_2352, [-2, -2, -2, -2]);  getitem_2352 = None
        to_dtype_582 = torch.ops.aten.to.dtype(constant_pad_nd_default_67, torch.float32);  constant_pad_nd_default_67 = None
        to_dtype_583 = torch.ops.aten.to.dtype(relu_default_5, torch.float32);  relu_default_5 = None
        le_scalar_194 = torch.ops.aten.le.Scalar(to_dtype_583, 0);  to_dtype_583 = None
        new_zeros_default_395 = torch.ops.aten.new_zeros.default(to_dtype_582, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_194 = torch.ops.aten.where.self(le_scalar_194, new_zeros_default_395, to_dtype_582);  le_scalar_194 = new_zeros_default_395 = to_dtype_582 = None
        to_dtype_584 = torch.ops.aten.to.dtype(where_self_194, torch.float32);  where_self_194 = None
        add_tensor_195 = torch.ops.aten.add.Tensor(add_tensor_194, to_dtype_584);  add_tensor_194 = to_dtype_584 = None
        max_pool2d_with_indices_backward_default_40 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_74, constant_pad_nd_default_3, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_24);  constant_pad_nd_default_3 = getitem_24 = None
        constant_pad_nd_default_68 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default_40, [-1, -1, -1, -1]);  max_pool2d_with_indices_backward_default_40 = None
        add_tensor_196 = torch.ops.aten.add.Tensor(add_tensor_195, constant_pad_nd_default_68);  add_tensor_195 = constant_pad_nd_default_68 = None
        clone_default_58 = torch.ops.aten.clone.default(slice_tensor_74, memory_format = torch.contiguous_format);  slice_tensor_74 = None
        native_batch_norm_backward_default_194 = torch.ops.aten.native_batch_norm_backward.default(clone_default_58, convolution_default_10, primals_1197, primals_1195, primals_1196, getitem_21, getitem_22, True, 0.001, [True, True, True]);  clone_default_58 = convolution_default_10 = primals_1197 = primals_1195 = primals_1196 = getitem_21 = getitem_22 = None
        getitem_2355 = native_batch_norm_backward_default_194[0]
        getitem_2356 = native_batch_norm_backward_default_194[1]
        getitem_2357 = native_batch_norm_backward_default_194[2];  native_batch_norm_backward_default_194 = None
        convolution_backward_default_362 = torch.ops.aten.convolution_backward.default(getitem_2355, convolution_default_9, primals_1201, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2355 = convolution_default_9 = primals_1201 = None
        getitem_2358 = convolution_backward_default_362[0]
        getitem_2359 = convolution_backward_default_362[1]
        getitem_2360 = convolution_backward_default_362[2];  convolution_backward_default_362 = None
        convolution_backward_default_363 = torch.ops.aten.convolution_backward.default(getitem_2358, relu_default_4, primals_1200, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 54, [True, True, False]);  getitem_2358 = primals_1200 = None
        getitem_2361 = convolution_backward_default_363[0]
        getitem_2362 = convolution_backward_default_363[1]
        getitem_2363 = convolution_backward_default_363[2];  convolution_backward_default_363 = None
        to_dtype_585 = torch.ops.aten.to.dtype(getitem_2361, torch.float32);  getitem_2361 = None
        to_dtype_586 = torch.ops.aten.to.dtype(relu_default_4, torch.float32);  relu_default_4 = None
        le_scalar_195 = torch.ops.aten.le.Scalar(to_dtype_586, 0);  to_dtype_586 = None
        new_zeros_default_396 = torch.ops.aten.new_zeros.default(to_dtype_585, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_195 = torch.ops.aten.where.self(le_scalar_195, new_zeros_default_396, to_dtype_585);  le_scalar_195 = new_zeros_default_396 = to_dtype_585 = None
        to_dtype_587 = torch.ops.aten.to.dtype(where_self_195, torch.float32);  where_self_195 = None
        native_batch_norm_backward_default_195 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_587, convolution_default_8, primals_1192, primals_1190, primals_1191, getitem_18, getitem_19, True, 0.001, [True, True, True]);  to_dtype_587 = convolution_default_8 = primals_1192 = primals_1190 = primals_1191 = getitem_18 = getitem_19 = None
        getitem_2364 = native_batch_norm_backward_default_195[0]
        getitem_2365 = native_batch_norm_backward_default_195[1]
        getitem_2366 = native_batch_norm_backward_default_195[2];  native_batch_norm_backward_default_195 = None
        convolution_backward_default_364 = torch.ops.aten.convolution_backward.default(getitem_2364, convolution_default_7, primals_1199, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2364 = convolution_default_7 = primals_1199 = None
        getitem_2367 = convolution_backward_default_364[0]
        getitem_2368 = convolution_backward_default_364[1]
        getitem_2369 = convolution_backward_default_364[2];  convolution_backward_default_364 = None
        convolution_backward_default_365 = torch.ops.aten.convolution_backward.default(getitem_2367, constant_pad_nd_default_2, primals_1198, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 54, [True, True, False]);  getitem_2367 = constant_pad_nd_default_2 = primals_1198 = None
        getitem_2370 = convolution_backward_default_365[0]
        getitem_2371 = convolution_backward_default_365[1]
        getitem_2372 = convolution_backward_default_365[2];  convolution_backward_default_365 = None
        constant_pad_nd_default_69 = torch.ops.aten.constant_pad_nd.default(getitem_2370, [-3, -3, -3, -3]);  getitem_2370 = None
        to_dtype_588 = torch.ops.aten.to.dtype(constant_pad_nd_default_69, torch.float32);  constant_pad_nd_default_69 = None
        to_dtype_589 = torch.ops.aten.to.dtype(relu_default_3, torch.float32);  relu_default_3 = None
        le_scalar_196 = torch.ops.aten.le.Scalar(to_dtype_589, 0);  to_dtype_589 = None
        new_zeros_default_397 = torch.ops.aten.new_zeros.default(to_dtype_588, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_196 = torch.ops.aten.where.self(le_scalar_196, new_zeros_default_397, to_dtype_588);  le_scalar_196 = new_zeros_default_397 = to_dtype_588 = None
        to_dtype_590 = torch.ops.aten.to.dtype(where_self_196, torch.float32);  where_self_196 = None
        add_tensor_197 = torch.ops.aten.add.Tensor(add_tensor_196, to_dtype_590);  add_tensor_196 = to_dtype_590 = None
        clone_default_59 = torch.ops.aten.clone.default(slice_tensor_73, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_196 = torch.ops.aten.native_batch_norm_backward.default(clone_default_59, convolution_default_6, primals_1187, primals_1185, primals_1186, getitem_15, getitem_16, True, 0.001, [True, True, True]);  clone_default_59 = convolution_default_6 = primals_1187 = primals_1185 = primals_1186 = getitem_15 = getitem_16 = None
        getitem_2373 = native_batch_norm_backward_default_196[0]
        getitem_2374 = native_batch_norm_backward_default_196[1]
        getitem_2375 = native_batch_norm_backward_default_196[2];  native_batch_norm_backward_default_196 = None
        convolution_backward_default_366 = torch.ops.aten.convolution_backward.default(getitem_2373, getitem_12, primals_1182, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2373 = getitem_12 = primals_1182 = None
        getitem_2376 = convolution_backward_default_366[0]
        getitem_2377 = convolution_backward_default_366[1]
        getitem_2378 = convolution_backward_default_366[2];  convolution_backward_default_366 = None
        max_pool2d_with_indices_backward_default_41 = torch.ops.aten.max_pool2d_with_indices_backward.default(getitem_2376, constant_pad_nd_default_1, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_13);  getitem_2376 = constant_pad_nd_default_1 = getitem_13 = None
        constant_pad_nd_default_70 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default_41, [-1, -1, -1, -1]);  max_pool2d_with_indices_backward_default_41 = None
        add_tensor_198 = torch.ops.aten.add.Tensor(add_tensor_191, constant_pad_nd_default_70);  add_tensor_191 = constant_pad_nd_default_70 = None
        clone_default_60 = torch.ops.aten.clone.default(slice_tensor_73, memory_format = torch.contiguous_format);  slice_tensor_73 = None
        native_batch_norm_backward_default_197 = torch.ops.aten.native_batch_norm_backward.default(clone_default_60, convolution_default_5, primals_1177, primals_1175, primals_1176, getitem_10, getitem_11, True, 0.001, [True, True, True]);  clone_default_60 = convolution_default_5 = primals_1177 = primals_1175 = primals_1176 = getitem_10 = getitem_11 = None
        getitem_2379 = native_batch_norm_backward_default_197[0]
        getitem_2380 = native_batch_norm_backward_default_197[1]
        getitem_2381 = native_batch_norm_backward_default_197[2];  native_batch_norm_backward_default_197 = None
        convolution_backward_default_367 = torch.ops.aten.convolution_backward.default(getitem_2379, convolution_default_4, primals_1181, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2379 = convolution_default_4 = primals_1181 = None
        getitem_2382 = convolution_backward_default_367[0]
        getitem_2383 = convolution_backward_default_367[1]
        getitem_2384 = convolution_backward_default_367[2];  convolution_backward_default_367 = None
        convolution_backward_default_368 = torch.ops.aten.convolution_backward.default(getitem_2382, relu_default_2, primals_1180, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 54, [True, True, False]);  getitem_2382 = primals_1180 = None
        getitem_2385 = convolution_backward_default_368[0]
        getitem_2386 = convolution_backward_default_368[1]
        getitem_2387 = convolution_backward_default_368[2];  convolution_backward_default_368 = None
        to_dtype_591 = torch.ops.aten.to.dtype(getitem_2385, torch.float32);  getitem_2385 = None
        to_dtype_592 = torch.ops.aten.to.dtype(relu_default_2, torch.float32);  relu_default_2 = None
        le_scalar_197 = torch.ops.aten.le.Scalar(to_dtype_592, 0);  to_dtype_592 = None
        new_zeros_default_398 = torch.ops.aten.new_zeros.default(to_dtype_591, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_197 = torch.ops.aten.where.self(le_scalar_197, new_zeros_default_398, to_dtype_591);  le_scalar_197 = new_zeros_default_398 = to_dtype_591 = None
        to_dtype_593 = torch.ops.aten.to.dtype(where_self_197, torch.float32);  where_self_197 = None
        native_batch_norm_backward_default_198 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_593, convolution_default_3, primals_1172, primals_1170, primals_1171, getitem_7, getitem_8, True, 0.001, [True, True, True]);  to_dtype_593 = convolution_default_3 = primals_1172 = primals_1170 = primals_1171 = getitem_7 = getitem_8 = None
        getitem_2388 = native_batch_norm_backward_default_198[0]
        getitem_2389 = native_batch_norm_backward_default_198[1]
        getitem_2390 = native_batch_norm_backward_default_198[2];  native_batch_norm_backward_default_198 = None
        convolution_backward_default_369 = torch.ops.aten.convolution_backward.default(getitem_2388, convolution_default_2, primals_1179, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2388 = convolution_default_2 = primals_1179 = None
        getitem_2391 = convolution_backward_default_369[0]
        getitem_2392 = convolution_backward_default_369[1]
        getitem_2393 = convolution_backward_default_369[2];  convolution_backward_default_369 = None
        convolution_backward_default_370 = torch.ops.aten.convolution_backward.default(getitem_2391, constant_pad_nd_default, primals_1178, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 96, [True, True, False]);  getitem_2391 = constant_pad_nd_default = primals_1178 = None
        getitem_2394 = convolution_backward_default_370[0]
        getitem_2395 = convolution_backward_default_370[1]
        getitem_2396 = convolution_backward_default_370[2];  convolution_backward_default_370 = None
        constant_pad_nd_default_71 = torch.ops.aten.constant_pad_nd.default(getitem_2394, [-2, -2, -2, -2]);  getitem_2394 = None
        to_dtype_594 = torch.ops.aten.to.dtype(constant_pad_nd_default_71, torch.float32);  constant_pad_nd_default_71 = None
        to_dtype_595 = torch.ops.aten.to.dtype(relu_default_1, torch.float32);  relu_default_1 = None
        le_scalar_198 = torch.ops.aten.le.Scalar(to_dtype_595, 0);  to_dtype_595 = None
        new_zeros_default_399 = torch.ops.aten.new_zeros.default(to_dtype_594, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_198 = torch.ops.aten.where.self(le_scalar_198, new_zeros_default_399, to_dtype_594);  le_scalar_198 = new_zeros_default_399 = to_dtype_594 = None
        to_dtype_596 = torch.ops.aten.to.dtype(where_self_198, torch.float32);  where_self_198 = None
        add_tensor_199 = torch.ops.aten.add.Tensor(add_tensor_198, to_dtype_596);  add_tensor_198 = to_dtype_596 = None
        native_batch_norm_backward_default_199 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_197, convolution_default_1, primals_1268, primals_1266, primals_1267, getitem_4, getitem_5, True, 0.001, [True, True, True]);  add_tensor_197 = convolution_default_1 = primals_1268 = primals_1266 = primals_1267 = getitem_4 = getitem_5 = None
        getitem_2397 = native_batch_norm_backward_default_199[0]
        getitem_2398 = native_batch_norm_backward_default_199[1]
        getitem_2399 = native_batch_norm_backward_default_199[2];  native_batch_norm_backward_default_199 = None
        convolution_backward_default_371 = torch.ops.aten.convolution_backward.default(getitem_2397, relu_default, primals_1269, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2397 = primals_1269 = None
        getitem_2400 = convolution_backward_default_371[0]
        getitem_2401 = convolution_backward_default_371[1]
        getitem_2402 = convolution_backward_default_371[2];  convolution_backward_default_371 = None
        to_dtype_597 = torch.ops.aten.to.dtype(getitem_2400, torch.float32);  getitem_2400 = None
        to_dtype_598 = torch.ops.aten.to.dtype(relu_default, torch.float32);  relu_default = None
        le_scalar_199 = torch.ops.aten.le.Scalar(to_dtype_598, 0);  to_dtype_598 = None
        new_zeros_default_400 = torch.ops.aten.new_zeros.default(to_dtype_597, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_199 = torch.ops.aten.where.self(le_scalar_199, new_zeros_default_400, to_dtype_597);  le_scalar_199 = new_zeros_default_400 = to_dtype_597 = None
        to_dtype_599 = torch.ops.aten.to.dtype(where_self_199, torch.float32);  where_self_199 = None
        add_tensor_200 = torch.ops.aten.add.Tensor(add_tensor_199, to_dtype_599);  add_tensor_199 = to_dtype_599 = None
        native_batch_norm_backward_default_200 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_200, convolution_default, primals_1380, primals_1378, primals_1379, getitem_1, getitem_2, True, 0.001, [True, True, True]);  add_tensor_200 = convolution_default = primals_1380 = primals_1378 = primals_1379 = getitem_1 = getitem_2 = None
        getitem_2403 = native_batch_norm_backward_default_200[0]
        getitem_2404 = native_batch_norm_backward_default_200[1]
        getitem_2405 = native_batch_norm_backward_default_200[2];  native_batch_norm_backward_default_200 = None
        convolution_backward_default_372 = torch.ops.aten.convolution_backward.default(getitem_2403, primals_1376, primals_1373, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_2403 = primals_1376 = primals_1373 = None
        getitem_2406 = convolution_backward_default_372[0]
        getitem_2407 = convolution_backward_default_372[1]
        getitem_2408 = convolution_backward_default_372[2];  convolution_backward_default_372 = None
        return [addmm_default, add_tensor, getitem_2126, None, None, None, getitem_2125, getitem_2117, None, None, None, getitem_2116, getitem_2131, getitem_2128, getitem_2122, getitem_2119, getitem_2108, None, None, None, getitem_2107, getitem_2099, None, None, None, getitem_2098, getitem_2113, getitem_2110, getitem_2104, getitem_2101, getitem_2090, None, None, None, getitem_2089, getitem_2081, None, None, None, getitem_2080, getitem_2095, getitem_2092, getitem_2086, getitem_2083, getitem_2072, None, None, None, getitem_2071, getitem_2063, None, None, None, getitem_2062, getitem_2077, getitem_2074, getitem_2068, getitem_2065, getitem_2054, None, None, None, getitem_2053, getitem_2045, None, None, None, getitem_2044, getitem_2059, getitem_2056, getitem_2050, getitem_2047, getitem_2036, None, None, None, getitem_2035, getitem_2027, None, None, None, getitem_2026, getitem_2041, getitem_2038, getitem_2032, getitem_2029, getitem_2135, None, None, None, getitem_2134, getitem_2137, getitem_2141, None, None, None, getitem_2140, getitem_2146, getitem_2143, getitem_908, None, None, None, getitem_907, getitem_899, None, None, None, getitem_898, getitem_913, getitem_910, getitem_904, getitem_901, getitem_890, None, None, None, getitem_889, getitem_881, None, None, None, getitem_880, getitem_895, getitem_892, getitem_886, getitem_883, getitem_872, None, None, None, getitem_871, getitem_863, None, None, None, getitem_862, getitem_877, getitem_874, getitem_868, getitem_865, getitem_854, None, None, None, getitem_853, getitem_845, None, None, None, getitem_844, getitem_859, getitem_856, getitem_850, getitem_847, getitem_836, None, None, None, getitem_835, getitem_827, None, None, None, getitem_826, getitem_841, getitem_838, getitem_832, getitem_829, getitem_818, None, None, None, getitem_817, getitem_809, None, None, None, getitem_808, getitem_823, getitem_820, getitem_814, getitem_811, getitem_917, None, None, None, getitem_916, getitem_919, getitem_923, None, None, None, getitem_922, getitem_925, getitem_788, None, None, None, getitem_787, getitem_779, None, None, None, getitem_778, getitem_793, getitem_790, getitem_784, getitem_781, getitem_770, None, None, None, getitem_769, getitem_761, None, None, None, getitem_760, getitem_775, getitem_772, getitem_766, getitem_763, getitem_752, None, None, None, getitem_751, getitem_743, None, None, None, getitem_742, getitem_757, getitem_754, getitem_748, getitem_745, getitem_734, None, None, None, getitem_733, getitem_725, None, None, None, getitem_724, getitem_739, getitem_736, getitem_730, getitem_727, getitem_716, None, None, None, getitem_715, getitem_707, None, None, None, getitem_706, getitem_721, getitem_718, getitem_712, getitem_709, getitem_698, None, None, None, getitem_697, getitem_689, None, None, None, getitem_688, getitem_703, getitem_700, getitem_694, getitem_691, getitem_797, None, None, None, getitem_796, getitem_799, getitem_803, None, None, None, getitem_802, getitem_805, getitem_2006, None, None, None, getitem_2005, getitem_1997, None, None, None, getitem_1996, getitem_2011, getitem_2008, getitem_2002, getitem_1999, getitem_1988, None, None, None, getitem_1987, getitem_1979, None, None, None, getitem_1978, getitem_1993, getitem_1990, getitem_1984, getitem_1981, getitem_1970, None, None, None, getitem_1969, getitem_1961, None, None, None, getitem_1960, getitem_1975, getitem_1972, getitem_1966, getitem_1963, getitem_1952, None, None, None, getitem_1951, getitem_1943, None, None, None, getitem_1942, getitem_1957, getitem_1954, getitem_1948, getitem_1945, getitem_1934, None, None, None, getitem_1933, getitem_1925, None, None, None, getitem_1924, getitem_1939, getitem_1936, getitem_1930, getitem_1927, getitem_1916, None, None, None, getitem_1915, getitem_1907, None, None, None, getitem_1906, getitem_1921, getitem_1918, getitem_1912, getitem_1909, getitem_2015, None, None, None, getitem_2014, getitem_2017, getitem_2021, None, None, None, getitem_2020, getitem_2023, getitem_1886, None, None, None, getitem_1885, getitem_1877, None, None, None, getitem_1876, getitem_1891, getitem_1888, getitem_1882, getitem_1879, getitem_1868, None, None, None, getitem_1867, getitem_1859, None, None, None, getitem_1858, getitem_1873, getitem_1870, getitem_1864, getitem_1861, getitem_1850, None, None, None, getitem_1849, getitem_1841, None, None, None, getitem_1840, getitem_1855, getitem_1852, getitem_1846, getitem_1843, getitem_1832, None, None, None, getitem_1831, getitem_1823, None, None, None, getitem_1822, getitem_1837, getitem_1834, getitem_1828, getitem_1825, getitem_1814, None, None, None, getitem_1813, getitem_1805, None, None, None, getitem_1804, getitem_1819, getitem_1816, getitem_1810, getitem_1807, getitem_1796, None, None, None, getitem_1795, getitem_1787, None, None, None, getitem_1786, getitem_1801, getitem_1798, getitem_1792, getitem_1789, getitem_1895, None, None, None, getitem_1894, getitem_1897, getitem_1901, None, None, None, getitem_1900, getitem_1903, getitem_1766, None, None, None, getitem_1765, getitem_1757, None, None, None, getitem_1756, getitem_1771, getitem_1768, getitem_1762, getitem_1759, getitem_1748, None, None, None, getitem_1747, getitem_1739, None, None, None, getitem_1738, getitem_1753, getitem_1750, getitem_1744, getitem_1741, getitem_1730, None, None, None, getitem_1729, getitem_1721, None, None, None, getitem_1720, getitem_1735, getitem_1732, getitem_1726, getitem_1723, getitem_1712, None, None, None, getitem_1711, getitem_1703, None, None, None, getitem_1702, getitem_1717, getitem_1714, getitem_1708, getitem_1705, getitem_1694, None, None, None, getitem_1693, getitem_1685, None, None, None, getitem_1684, getitem_1699, getitem_1696, getitem_1690, getitem_1687, getitem_1676, None, None, None, getitem_1675, getitem_1667, None, None, None, getitem_1666, getitem_1681, getitem_1678, getitem_1672, getitem_1669, getitem_1775, None, None, None, getitem_1774, getitem_1777, getitem_1781, None, None, None, getitem_1780, getitem_1783, getitem_1646, None, None, None, getitem_1645, getitem_1637, None, None, None, getitem_1636, getitem_1651, getitem_1648, getitem_1642, getitem_1639, getitem_1628, None, None, None, getitem_1627, getitem_1619, None, None, None, getitem_1618, getitem_1633, getitem_1630, getitem_1624, getitem_1621, getitem_1610, None, None, None, getitem_1609, getitem_1601, None, None, None, getitem_1600, getitem_1615, getitem_1612, getitem_1606, getitem_1603, getitem_1592, None, None, None, getitem_1591, getitem_1583, None, None, None, getitem_1582, getitem_1597, getitem_1594, getitem_1588, getitem_1585, getitem_1574, None, None, None, getitem_1573, getitem_1565, None, None, None, getitem_1564, getitem_1579, getitem_1576, getitem_1570, getitem_1567, getitem_1556, None, None, None, getitem_1555, getitem_1547, None, None, None, getitem_1546, getitem_1561, getitem_1558, getitem_1552, getitem_1549, getitem_1541, None, None, None, getitem_1540, getitem_1543, getitem_1655, None, None, None, getitem_1654, getitem_1657, getitem_1661, None, None, None, getitem_1660, getitem_1663, getitem_1517, None, None, None, getitem_1516, getitem_1508, None, None, None, getitem_1507, getitem_1522, getitem_1519, getitem_1513, getitem_1510, getitem_1499, None, None, None, getitem_1498, getitem_1490, None, None, None, getitem_1489, getitem_1504, getitem_1501, getitem_1495, getitem_1492, getitem_1481, None, None, None, getitem_1480, getitem_1472, None, None, None, getitem_1471, getitem_1486, getitem_1483, getitem_1477, getitem_1474, getitem_1463, None, None, None, getitem_1462, getitem_1454, None, None, None, getitem_1453, getitem_1468, getitem_1465, getitem_1459, getitem_1456, getitem_1445, None, None, None, getitem_1444, getitem_1436, None, None, None, getitem_1435, getitem_1450, getitem_1447, getitem_1441, getitem_1438, getitem_1427, None, None, None, getitem_1426, getitem_1418, None, None, None, getitem_1417, getitem_1432, getitem_1429, getitem_1423, getitem_1420, getitem_1526, None, None, None, getitem_1525, getitem_1528, getitem_1532, None, None, None, getitem_1531, getitem_1537, getitem_1534, getitem_1397, None, None, None, getitem_1396, getitem_1388, None, None, None, getitem_1387, getitem_1402, getitem_1399, getitem_1393, getitem_1390, getitem_1379, None, None, None, getitem_1378, getitem_1370, None, None, None, getitem_1369, getitem_1384, getitem_1381, getitem_1375, getitem_1372, getitem_1361, None, None, None, getitem_1360, getitem_1352, None, None, None, getitem_1351, getitem_1366, getitem_1363, getitem_1357, getitem_1354, getitem_1343, None, None, None, getitem_1342, getitem_1334, None, None, None, getitem_1333, getitem_1348, getitem_1345, getitem_1339, getitem_1336, getitem_1325, None, None, None, getitem_1324, getitem_1316, None, None, None, getitem_1315, getitem_1330, getitem_1327, getitem_1321, getitem_1318, getitem_1307, None, None, None, getitem_1306, getitem_1298, None, None, None, getitem_1297, getitem_1312, getitem_1309, getitem_1303, getitem_1300, getitem_1406, None, None, None, getitem_1405, getitem_1408, getitem_1412, None, None, None, getitem_1411, getitem_1414, getitem_1277, None, None, None, getitem_1276, getitem_1268, None, None, None, getitem_1267, getitem_1282, getitem_1279, getitem_1273, getitem_1270, getitem_1259, None, None, None, getitem_1258, getitem_1250, None, None, None, getitem_1249, getitem_1264, getitem_1261, getitem_1255, getitem_1252, getitem_1241, None, None, None, getitem_1240, getitem_1232, None, None, None, getitem_1231, getitem_1246, getitem_1243, getitem_1237, getitem_1234, getitem_1223, None, None, None, getitem_1222, getitem_1214, None, None, None, getitem_1213, getitem_1228, getitem_1225, getitem_1219, getitem_1216, getitem_1205, None, None, None, getitem_1204, getitem_1196, None, None, None, getitem_1195, getitem_1210, getitem_1207, getitem_1201, getitem_1198, getitem_1187, None, None, None, getitem_1186, getitem_1178, None, None, None, getitem_1177, getitem_1192, getitem_1189, getitem_1183, getitem_1180, getitem_1286, None, None, None, getitem_1285, getitem_1288, getitem_1292, None, None, None, getitem_1291, getitem_1294, getitem_1157, None, None, None, getitem_1156, getitem_1148, None, None, None, getitem_1147, getitem_1162, getitem_1159, getitem_1153, getitem_1150, getitem_1139, None, None, None, getitem_1138, getitem_1130, None, None, None, getitem_1129, getitem_1144, getitem_1141, getitem_1135, getitem_1132, getitem_1121, None, None, None, getitem_1120, getitem_1112, None, None, None, getitem_1111, getitem_1126, getitem_1123, getitem_1117, getitem_1114, getitem_1103, None, None, None, getitem_1102, getitem_1094, None, None, None, getitem_1093, getitem_1108, getitem_1105, getitem_1099, getitem_1096, getitem_1085, None, None, None, getitem_1084, getitem_1076, None, None, None, getitem_1075, getitem_1090, getitem_1087, getitem_1081, getitem_1078, getitem_1067, None, None, None, getitem_1066, getitem_1058, None, None, None, getitem_1057, getitem_1072, getitem_1069, getitem_1063, getitem_1060, getitem_1052, None, None, None, getitem_1051, getitem_1054, getitem_1166, None, None, None, getitem_1165, getitem_1168, getitem_1172, None, None, None, getitem_1171, getitem_1174, getitem_1028, None, None, None, getitem_1027, getitem_1019, None, None, None, getitem_1018, getitem_1033, getitem_1030, getitem_1024, getitem_1021, getitem_1010, None, None, None, getitem_1009, getitem_1001, None, None, None, getitem_1000, getitem_1015, getitem_1012, getitem_1006, getitem_1003, getitem_992, None, None, None, getitem_991, getitem_983, None, None, None, getitem_982, getitem_997, getitem_994, getitem_988, getitem_985, getitem_974, None, None, None, getitem_973, getitem_965, None, None, None, getitem_964, getitem_979, getitem_976, getitem_970, getitem_967, getitem_956, None, None, None, getitem_955, getitem_947, None, None, None, getitem_946, getitem_961, getitem_958, getitem_952, getitem_949, getitem_938, None, None, None, getitem_937, getitem_929, None, None, None, getitem_928, getitem_943, getitem_940, getitem_934, getitem_931, getitem_1037, None, None, None, getitem_1036, getitem_1039, getitem_1043, None, None, None, getitem_1042, getitem_1048, getitem_1045, getitem_2390, None, None, None, getitem_2389, getitem_2381, None, None, None, getitem_2380, getitem_2395, getitem_2392, getitem_2386, getitem_2383, getitem_2377, getitem_2375, None, None, None, getitem_2374, getitem_2366, None, None, None, getitem_2365, getitem_2357, None, None, None, getitem_2356, getitem_2371, getitem_2368, getitem_2362, getitem_2359, getitem_2348, None, None, None, getitem_2347, getitem_2339, None, None, None, getitem_2338, getitem_2353, getitem_2350, getitem_2344, getitem_2341, getitem_2330, None, None, None, getitem_2329, getitem_2321, None, None, None, getitem_2320, getitem_2335, getitem_2332, getitem_2326, getitem_2323, getitem_2312, None, None, None, getitem_2311, getitem_2303, None, None, None, getitem_2302, getitem_2317, getitem_2314, getitem_2308, getitem_2305, getitem_2294, None, None, None, getitem_2293, getitem_2285, None, None, None, getitem_2284, getitem_2299, getitem_2296, getitem_2290, getitem_2287, getitem_2279, None, None, None, getitem_2278, getitem_2281, getitem_2399, None, None, None, getitem_2398, getitem_2401, getitem_2255, None, None, None, getitem_2254, getitem_2246, None, None, None, getitem_2245, getitem_2260, getitem_2257, getitem_2251, getitem_2248, getitem_2237, None, None, None, getitem_2236, getitem_2228, None, None, None, getitem_2227, getitem_2242, getitem_2239, getitem_2233, getitem_2230, getitem_2219, None, None, None, getitem_2218, getitem_2210, None, None, None, getitem_2209, getitem_2224, getitem_2221, getitem_2215, getitem_2212, getitem_2201, None, None, None, getitem_2200, getitem_2192, None, None, None, getitem_2191, getitem_2206, getitem_2203, getitem_2197, getitem_2194, getitem_2183, None, None, None, getitem_2182, getitem_2174, None, None, None, getitem_2173, getitem_2188, getitem_2185, getitem_2179, getitem_2176, getitem_2165, None, None, None, getitem_2164, getitem_2156, None, None, None, getitem_2155, getitem_2170, getitem_2167, getitem_2161, getitem_2158, getitem_2150, None, None, None, getitem_2149, getitem_2152, getitem_2264, None, None, None, getitem_2263, getitem_2266, getitem_2270, None, None, None, getitem_2269, getitem_2275, getitem_2272, getitem_2407, view_default_1, t_default_4, None, None, None, None, getitem_2404, getitem_2405]
        
