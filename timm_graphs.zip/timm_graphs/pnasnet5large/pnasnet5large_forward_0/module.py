
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/pnasnet5large/pnasnet5large_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339, primals_340, primals_341, primals_342, primals_343, primals_344, primals_345, primals_346, primals_347, primals_348, primals_349, primals_350, primals_351, primals_352, primals_353, primals_354, primals_355, primals_356, primals_357, primals_358, primals_359, primals_360, primals_361, primals_362, primals_363, primals_364, primals_365, primals_366, primals_367, primals_368, primals_369, primals_370, primals_371, primals_372, primals_373, primals_374, primals_375, primals_376, primals_377, primals_378, primals_379, primals_380, primals_381, primals_382, primals_383, primals_384, primals_385, primals_386, primals_387, primals_388, primals_389, primals_390, primals_391, primals_392, primals_393, primals_394, primals_395, primals_396, primals_397, primals_398, primals_399, primals_400, primals_401, primals_402, primals_403, primals_404, primals_405, primals_406, primals_407, primals_408, primals_409, primals_410, primals_411, primals_412, primals_413, primals_414, primals_415, primals_416, primals_417, primals_418, primals_419, primals_420, primals_421, primals_422, primals_423, primals_424, primals_425, primals_426, primals_427, primals_428, primals_429, primals_430, primals_431, primals_432, primals_433, primals_434, primals_435, primals_436, primals_437, primals_438, primals_439, primals_440, primals_441, primals_442, primals_443, primals_444, primals_445, primals_446, primals_447, primals_448, primals_449, primals_450, primals_451, primals_452, primals_453, primals_454, primals_455, primals_456, primals_457, primals_458, primals_459, primals_460, primals_461, primals_462, primals_463, primals_464, primals_465, primals_466, primals_467, primals_468, primals_469, primals_470, primals_471, primals_472, primals_473, primals_474, primals_475, primals_476, primals_477, primals_478, primals_479, primals_480, primals_481, primals_482, primals_483, primals_484, primals_485, primals_486, primals_487, primals_488, primals_489, primals_490, primals_491, primals_492, primals_493, primals_494, primals_495, primals_496, primals_497, primals_498, primals_499, primals_500, primals_501, primals_502, primals_503, primals_504, primals_505, primals_506, primals_507, primals_508, primals_509, primals_510, primals_511, primals_512, primals_513, primals_514, primals_515, primals_516, primals_517, primals_518, primals_519, primals_520, primals_521, primals_522, primals_523, primals_524, primals_525, primals_526, primals_527, primals_528, primals_529, primals_530, primals_531, primals_532, primals_533, primals_534, primals_535, primals_536, primals_537, primals_538, primals_539, primals_540, primals_541, primals_542, primals_543, primals_544, primals_545, primals_546, primals_547, primals_548, primals_549, primals_550, primals_551, primals_552, primals_553, primals_554, primals_555, primals_556, primals_557, primals_558, primals_559, primals_560, primals_561, primals_562, primals_563, primals_564, primals_565, primals_566, primals_567, primals_568, primals_569, primals_570, primals_571, primals_572, primals_573, primals_574, primals_575, primals_576, primals_577, primals_578, primals_579, primals_580, primals_581, primals_582, primals_583, primals_584, primals_585, primals_586, primals_587, primals_588, primals_589, primals_590, primals_591, primals_592, primals_593, primals_594, primals_595, primals_596, primals_597, primals_598, primals_599, primals_600, primals_601, primals_602, primals_603, primals_604, primals_605, primals_606, primals_607, primals_608, primals_609, primals_610, primals_611, primals_612, primals_613, primals_614, primals_615, primals_616, primals_617, primals_618, primals_619, primals_620, primals_621, primals_622, primals_623, primals_624, primals_625, primals_626, primals_627, primals_628, primals_629, primals_630, primals_631, primals_632, primals_633, primals_634, primals_635, primals_636, primals_637, primals_638, primals_639, primals_640, primals_641, primals_642, primals_643, primals_644, primals_645, primals_646, primals_647, primals_648, primals_649, primals_650, primals_651, primals_652, primals_653, primals_654, primals_655, primals_656, primals_657, primals_658, primals_659, primals_660, primals_661, primals_662, primals_663, primals_664, primals_665, primals_666, primals_667, primals_668, primals_669, primals_670, primals_671, primals_672, primals_673, primals_674, primals_675, primals_676, primals_677, primals_678, primals_679, primals_680, primals_681, primals_682, primals_683, primals_684, primals_685, primals_686, primals_687, primals_688, primals_689, primals_690, primals_691, primals_692, primals_693, primals_694, primals_695, primals_696, primals_697, primals_698, primals_699, primals_700, primals_701, primals_702, primals_703, primals_704, primals_705, primals_706, primals_707, primals_708, primals_709, primals_710, primals_711, primals_712, primals_713, primals_714, primals_715, primals_716, primals_717, primals_718, primals_719, primals_720, primals_721, primals_722, primals_723, primals_724, primals_725, primals_726, primals_727, primals_728, primals_729, primals_730, primals_731, primals_732, primals_733, primals_734, primals_735, primals_736, primals_737, primals_738, primals_739, primals_740, primals_741, primals_742, primals_743, primals_744, primals_745, primals_746, primals_747, primals_748, primals_749, primals_750, primals_751, primals_752, primals_753, primals_754, primals_755, primals_756, primals_757, primals_758, primals_759, primals_760, primals_761, primals_762, primals_763, primals_764, primals_765, primals_766, primals_767, primals_768, primals_769, primals_770, primals_771, primals_772, primals_773, primals_774, primals_775, primals_776, primals_777, primals_778, primals_779, primals_780, primals_781, primals_782, primals_783, primals_784, primals_785, primals_786, primals_787, primals_788, primals_789, primals_790, primals_791, primals_792, primals_793, primals_794, primals_795, primals_796, primals_797, primals_798, primals_799, primals_800, primals_801, primals_802, primals_803, primals_804, primals_805, primals_806, primals_807, primals_808, primals_809, primals_810, primals_811, primals_812, primals_813, primals_814, primals_815, primals_816, primals_817, primals_818, primals_819, primals_820, primals_821, primals_822, primals_823, primals_824, primals_825, primals_826, primals_827, primals_828, primals_829, primals_830, primals_831, primals_832, primals_833, primals_834, primals_835, primals_836, primals_837, primals_838, primals_839, primals_840, primals_841, primals_842, primals_843, primals_844, primals_845, primals_846, primals_847, primals_848, primals_849, primals_850, primals_851, primals_852, primals_853, primals_854, primals_855, primals_856, primals_857, primals_858, primals_859, primals_860, primals_861, primals_862, primals_863, primals_864, primals_865, primals_866, primals_867, primals_868, primals_869, primals_870, primals_871, primals_872, primals_873, primals_874, primals_875, primals_876, primals_877, primals_878, primals_879, primals_880, primals_881, primals_882, primals_883, primals_884, primals_885, primals_886, primals_887, primals_888, primals_889, primals_890, primals_891, primals_892, primals_893, primals_894, primals_895, primals_896, primals_897, primals_898, primals_899, primals_900, primals_901, primals_902, primals_903, primals_904, primals_905, primals_906, primals_907, primals_908, primals_909, primals_910, primals_911, primals_912, primals_913, primals_914, primals_915, primals_916, primals_917, primals_918, primals_919, primals_920, primals_921, primals_922, primals_923, primals_924, primals_925, primals_926, primals_927, primals_928, primals_929, primals_930, primals_931, primals_932, primals_933, primals_934, primals_935, primals_936, primals_937, primals_938, primals_939, primals_940, primals_941, primals_942, primals_943, primals_944, primals_945, primals_946, primals_947, primals_948, primals_949, primals_950, primals_951, primals_952, primals_953, primals_954, primals_955, primals_956, primals_957, primals_958, primals_959, primals_960, primals_961, primals_962, primals_963, primals_964, primals_965, primals_966, primals_967, primals_968, primals_969, primals_970, primals_971, primals_972, primals_973, primals_974, primals_975, primals_976, primals_977, primals_978, primals_979, primals_980, primals_981, primals_982, primals_983, primals_984, primals_985, primals_986, primals_987, primals_988, primals_989, primals_990, primals_991, primals_992, primals_993, primals_994, primals_995, primals_996, primals_997, primals_998, primals_999, primals_1000, primals_1001, primals_1002, primals_1003, primals_1004, primals_1005, primals_1006, primals_1007, primals_1008, primals_1009, primals_1010, primals_1011, primals_1012, primals_1013, primals_1014, primals_1015, primals_1016, primals_1017, primals_1018, primals_1019, primals_1020, primals_1021, primals_1022, primals_1023, primals_1024, primals_1025, primals_1026, primals_1027, primals_1028, primals_1029, primals_1030, primals_1031, primals_1032, primals_1033, primals_1034, primals_1035, primals_1036, primals_1037, primals_1038, primals_1039, primals_1040, primals_1041, primals_1042, primals_1043, primals_1044, primals_1045, primals_1046, primals_1047, primals_1048, primals_1049, primals_1050, primals_1051, primals_1052, primals_1053, primals_1054, primals_1055, primals_1056, primals_1057, primals_1058, primals_1059, primals_1060, primals_1061, primals_1062, primals_1063, primals_1064, primals_1065, primals_1066, primals_1067, primals_1068, primals_1069, primals_1070, primals_1071, primals_1072, primals_1073, primals_1074, primals_1075, primals_1076, primals_1077, primals_1078, primals_1079, primals_1080, primals_1081, primals_1082, primals_1083, primals_1084, primals_1085, primals_1086, primals_1087, primals_1088, primals_1089, primals_1090, primals_1091, primals_1092, primals_1093, primals_1094, primals_1095, primals_1096, primals_1097, primals_1098, primals_1099, primals_1100, primals_1101, primals_1102, primals_1103, primals_1104, primals_1105, primals_1106, primals_1107, primals_1108, primals_1109, primals_1110, primals_1111, primals_1112, primals_1113, primals_1114, primals_1115, primals_1116, primals_1117, primals_1118, primals_1119, primals_1120, primals_1121, primals_1122, primals_1123, primals_1124, primals_1125, primals_1126, primals_1127, primals_1128, primals_1129, primals_1130, primals_1131, primals_1132, primals_1133, primals_1134, primals_1135, primals_1136, primals_1137, primals_1138, primals_1139, primals_1140, primals_1141, primals_1142, primals_1143, primals_1144, primals_1145, primals_1146, primals_1147, primals_1148, primals_1149, primals_1150, primals_1151, primals_1152, primals_1153, primals_1154, primals_1155, primals_1156, primals_1157, primals_1158, primals_1159, primals_1160, primals_1161, primals_1162, primals_1163, primals_1164, primals_1165, primals_1166, primals_1167, primals_1168, primals_1169, primals_1170, primals_1171, primals_1172, primals_1173, primals_1174, primals_1175, primals_1176, primals_1177, primals_1178, primals_1179, primals_1180, primals_1181, primals_1182, primals_1183, primals_1184, primals_1185, primals_1186, primals_1187, primals_1188, primals_1189, primals_1190, primals_1191, primals_1192, primals_1193, primals_1194, primals_1195, primals_1196, primals_1197, primals_1198, primals_1199, primals_1200, primals_1201, primals_1202, primals_1203, primals_1204, primals_1205, primals_1206, primals_1207, primals_1208, primals_1209, primals_1210, primals_1211, primals_1212, primals_1213, primals_1214, primals_1215, primals_1216, primals_1217, primals_1218, primals_1219, primals_1220, primals_1221, primals_1222, primals_1223, primals_1224, primals_1225, primals_1226, primals_1227, primals_1228, primals_1229, primals_1230, primals_1231, primals_1232, primals_1233, primals_1234, primals_1235, primals_1236, primals_1237, primals_1238, primals_1239, primals_1240, primals_1241, primals_1242, primals_1243, primals_1244, primals_1245, primals_1246, primals_1247, primals_1248, primals_1249, primals_1250, primals_1251, primals_1252, primals_1253, primals_1254, primals_1255, primals_1256, primals_1257, primals_1258, primals_1259, primals_1260, primals_1261, primals_1262, primals_1263, primals_1264, primals_1265, primals_1266, primals_1267, primals_1268, primals_1269, primals_1270, primals_1271, primals_1272, primals_1273, primals_1274, primals_1275, primals_1276, primals_1277, primals_1278, primals_1279, primals_1280, primals_1281, primals_1282, primals_1283, primals_1284, primals_1285, primals_1286, primals_1287, primals_1288, primals_1289, primals_1290, primals_1291, primals_1292, primals_1293, primals_1294, primals_1295, primals_1296, primals_1297, primals_1298, primals_1299, primals_1300, primals_1301, primals_1302, primals_1303, primals_1304, primals_1305, primals_1306, primals_1307, primals_1308, primals_1309, primals_1310, primals_1311, primals_1312, primals_1313, primals_1314, primals_1315, primals_1316, primals_1317, primals_1318, primals_1319, primals_1320, primals_1321, primals_1322, primals_1323, primals_1324, primals_1325, primals_1326, primals_1327, primals_1328, primals_1329, primals_1330, primals_1331, primals_1332, primals_1333, primals_1334, primals_1335, primals_1336, primals_1337, primals_1338, primals_1339, primals_1340, primals_1341, primals_1342, primals_1343, primals_1344, primals_1345, primals_1346, primals_1347, primals_1348, primals_1349, primals_1350, primals_1351, primals_1352, primals_1353, primals_1354, primals_1355, primals_1356, primals_1357, primals_1358, primals_1359, primals_1360, primals_1361, primals_1362, primals_1363, primals_1364, primals_1365, primals_1366, primals_1367, primals_1368, primals_1369, primals_1370, primals_1371, primals_1372, primals_1373, primals_1374, primals_1375, primals_1376, primals_1377, primals_1378, primals_1379, primals_1380, primals_1381):
        convolution_default = torch.ops.aten.convolution.default(primals_1376, primals_1373, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor = torch.ops.aten.add.Tensor(primals_1377, 1);  primals_1377 = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_1380, primals_1381, primals_1378, primals_1379, True, 0.1, 0.001);  primals_1381 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        relu_default = torch.ops.aten.relu.default(getitem)
        convolution_default_1 = torch.ops.aten.convolution.default(relu_default, primals_1269, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_1268, primals_1264, primals_1266, primals_1267, True, 0.1, 0.001);  primals_1264 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        relu_default_1 = torch.ops.aten.relu.default(getitem)
        constant_pad_nd_default = torch.ops.aten.constant_pad_nd.default(relu_default_1, [2, 2, 2, 2], 0.0)
        convolution_default_2 = torch.ops.aten.convolution.default(constant_pad_nd_default, primals_1178, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 96)
        convolution_default_3 = torch.ops.aten.convolution.default(convolution_default_2, primals_1179, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_1172, primals_1168, primals_1170, primals_1171, True, 0.1, 0.001);  primals_1168 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        relu_default_2 = torch.ops.aten.relu.default(getitem_6);  getitem_6 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu_default_2, primals_1180, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 54)
        convolution_default_5 = torch.ops.aten.convolution.default(convolution_default_4, primals_1181, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_1177, primals_1173, primals_1175, primals_1176, True, 0.1, 0.001);  primals_1173 = None
        getitem_9 = native_batch_norm_default_3[0]
        getitem_10 = native_batch_norm_default_3[1]
        getitem_11 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        constant_pad_nd_default_1 = torch.ops.aten.constant_pad_nd.default(getitem, [1, 1, 1, 1], -inf)
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_1, [3, 3], [2, 2])
        getitem_12 = max_pool2d_with_indices_default[0]
        getitem_13 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_6 = torch.ops.aten.convolution.default(getitem_12, primals_1182, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_1187, primals_1183, primals_1185, primals_1186, True, 0.1, 0.001);  primals_1183 = None
        getitem_14 = native_batch_norm_default_4[0]
        getitem_15 = native_batch_norm_default_4[1]
        getitem_16 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(getitem_9, getitem_14);  getitem_9 = getitem_14 = None
        relu_default_3 = torch.ops.aten.relu.default(getitem_3)
        constant_pad_nd_default_2 = torch.ops.aten.constant_pad_nd.default(relu_default_3, [3, 3, 3, 3], 0.0)
        convolution_default_7 = torch.ops.aten.convolution.default(constant_pad_nd_default_2, primals_1198, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 54)
        convolution_default_8 = torch.ops.aten.convolution.default(convolution_default_7, primals_1199, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_1192, primals_1188, primals_1190, primals_1191, True, 0.1, 0.001);  primals_1188 = None
        getitem_17 = native_batch_norm_default_5[0]
        getitem_18 = native_batch_norm_default_5[1]
        getitem_19 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        relu_default_4 = torch.ops.aten.relu.default(getitem_17);  getitem_17 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu_default_4, primals_1200, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 54)
        convolution_default_10 = torch.ops.aten.convolution.default(convolution_default_9, primals_1201, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_1197, primals_1193, primals_1195, primals_1196, True, 0.1, 0.001);  primals_1193 = None
        getitem_20 = native_batch_norm_default_6[0]
        getitem_21 = native_batch_norm_default_6[1]
        getitem_22 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        constant_pad_nd_default_3 = torch.ops.aten.constant_pad_nd.default(getitem_3, [1, 1, 1, 1], -inf)
        max_pool2d_with_indices_default_1 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_3, [3, 3], [2, 2])
        getitem_23 = max_pool2d_with_indices_default_1[0]
        getitem_24 = max_pool2d_with_indices_default_1[1];  max_pool2d_with_indices_default_1 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(getitem_20, getitem_23);  getitem_20 = getitem_23 = None
        relu_default_5 = torch.ops.aten.relu.default(getitem_3)
        constant_pad_nd_default_4 = torch.ops.aten.constant_pad_nd.default(relu_default_5, [2, 2, 2, 2], 0.0)
        convolution_default_11 = torch.ops.aten.convolution.default(constant_pad_nd_default_4, primals_1212, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 54)
        convolution_default_12 = torch.ops.aten.convolution.default(convolution_default_11, primals_1213, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_1206, primals_1202, primals_1204, primals_1205, True, 0.1, 0.001);  primals_1202 = None
        getitem_25 = native_batch_norm_default_7[0]
        getitem_26 = native_batch_norm_default_7[1]
        getitem_27 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        relu_default_6 = torch.ops.aten.relu.default(getitem_25);  getitem_25 = None
        convolution_default_13 = torch.ops.aten.convolution.default(relu_default_6, primals_1214, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 54)
        convolution_default_14 = torch.ops.aten.convolution.default(convolution_default_13, primals_1215, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_1211, primals_1207, primals_1209, primals_1210, True, 0.1, 0.001);  primals_1207 = None
        getitem_28 = native_batch_norm_default_8[0]
        getitem_29 = native_batch_norm_default_8[1]
        getitem_30 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        relu_default_7 = torch.ops.aten.relu.default(getitem_3)
        constant_pad_nd_default_5 = torch.ops.aten.constant_pad_nd.default(relu_default_7, [1, 1, 1, 1], 0.0)
        convolution_default_15 = torch.ops.aten.convolution.default(constant_pad_nd_default_5, primals_1226, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 54)
        convolution_default_16 = torch.ops.aten.convolution.default(convolution_default_15, primals_1227, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_1220, primals_1216, primals_1218, primals_1219, True, 0.1, 0.001);  primals_1216 = None
        getitem_31 = native_batch_norm_default_9[0]
        getitem_32 = native_batch_norm_default_9[1]
        getitem_33 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        relu_default_8 = torch.ops.aten.relu.default(getitem_31);  getitem_31 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu_default_8, primals_1228, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 54)
        convolution_default_18 = torch.ops.aten.convolution.default(convolution_default_17, primals_1229, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_1225, primals_1221, primals_1223, primals_1224, True, 0.1, 0.001);  primals_1221 = None
        getitem_34 = native_batch_norm_default_10[0]
        getitem_35 = native_batch_norm_default_10[1]
        getitem_36 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(getitem_28, getitem_34);  getitem_28 = getitem_34 = None
        relu_default_9 = torch.ops.aten.relu.default(add_tensor_3)
        convolution_default_19 = torch.ops.aten.convolution.default(relu_default_9, primals_1240, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 54)
        convolution_default_20 = torch.ops.aten.convolution.default(convolution_default_19, primals_1241, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_1234, primals_1230, primals_1232, primals_1233, True, 0.1, 0.001);  primals_1230 = None
        getitem_37 = native_batch_norm_default_11[0]
        getitem_38 = native_batch_norm_default_11[1]
        getitem_39 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        relu_default_10 = torch.ops.aten.relu.default(getitem_37);  getitem_37 = None
        convolution_default_21 = torch.ops.aten.convolution.default(relu_default_10, primals_1242, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 54)
        convolution_default_22 = torch.ops.aten.convolution.default(convolution_default_21, primals_1243, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_1239, primals_1235, primals_1237, primals_1238, True, 0.1, 0.001);  primals_1235 = None
        getitem_40 = native_batch_norm_default_12[0]
        getitem_41 = native_batch_norm_default_12[1]
        getitem_42 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        constant_pad_nd_default_6 = torch.ops.aten.constant_pad_nd.default(getitem_3, [1, 1, 1, 1], -inf)
        max_pool2d_with_indices_default_2 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_6, [3, 3], [2, 2])
        getitem_43 = max_pool2d_with_indices_default_2[0]
        getitem_44 = max_pool2d_with_indices_default_2[1];  max_pool2d_with_indices_default_2 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(getitem_40, getitem_43);  getitem_40 = getitem_43 = None
        relu_default_11 = torch.ops.aten.relu.default(getitem)
        constant_pad_nd_default_7 = torch.ops.aten.constant_pad_nd.default(relu_default_11, [1, 1, 1, 1], 0.0)
        convolution_default_23 = torch.ops.aten.convolution.default(constant_pad_nd_default_7, primals_1254, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 96)
        convolution_default_24 = torch.ops.aten.convolution.default(convolution_default_23, primals_1255, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_1248, primals_1244, primals_1246, primals_1247, True, 0.1, 0.001);  primals_1244 = None
        getitem_45 = native_batch_norm_default_13[0]
        getitem_46 = native_batch_norm_default_13[1]
        getitem_47 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        relu_default_12 = torch.ops.aten.relu.default(getitem_45);  getitem_45 = None
        convolution_default_25 = torch.ops.aten.convolution.default(relu_default_12, primals_1256, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 54)
        convolution_default_26 = torch.ops.aten.convolution.default(convolution_default_25, primals_1257, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_1253, primals_1249, primals_1251, primals_1252, True, 0.1, 0.001);  primals_1249 = None
        getitem_48 = native_batch_norm_default_14[0]
        getitem_49 = native_batch_norm_default_14[1]
        getitem_50 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        relu_default_13 = torch.ops.aten.relu.default(getitem_3);  getitem_3 = None
        convolution_default_27 = torch.ops.aten.convolution.default(relu_default_13, primals_1263, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_1262, primals_1258, primals_1260, primals_1261, True, 0.1, 0.001);  primals_1258 = None
        getitem_51 = native_batch_norm_default_15[0]
        getitem_52 = native_batch_norm_default_15[1]
        getitem_53 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(getitem_48, getitem_51);  getitem_48 = getitem_51 = None
        cat_default = torch.ops.aten.cat.default([add_tensor_1, add_tensor_2, add_tensor_3, add_tensor_4, add_tensor_5], 1);  add_tensor_1 = add_tensor_2 = add_tensor_3 = add_tensor_4 = add_tensor_5 = None
        relu_default_14 = torch.ops.aten.relu.default(getitem);  getitem = None
        avg_pool2d_default = torch.ops.aten.avg_pool2d.default(relu_default_14, [1, 1], [2, 2], [0, 0], False, False)
        convolution_default_28 = torch.ops.aten.convolution.default(avg_pool2d_default, primals_1371, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        constant_pad_nd_default_8 = torch.ops.aten.constant_pad_nd.default(relu_default_14, [-1, 1, -1, 1], 0.0)
        avg_pool2d_default_1 = torch.ops.aten.avg_pool2d.default(constant_pad_nd_default_8, [1, 1], [2, 2], [0, 0], False, False)
        convolution_default_29 = torch.ops.aten.convolution.default(avg_pool2d_default_1, primals_1372, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_1 = torch.ops.aten.cat.default([convolution_default_28, convolution_default_29], 1);  convolution_default_28 = convolution_default_29 = None
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(cat_default_1, primals_1370, primals_1366, primals_1368, primals_1369, True, 0.1, 0.001);  primals_1366 = None
        getitem_54 = native_batch_norm_default_16[0]
        getitem_55 = native_batch_norm_default_16[1]
        getitem_56 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        relu_default_15 = torch.ops.aten.relu.default(cat_default)
        convolution_default_30 = torch.ops.aten.convolution.default(relu_default_15, primals_1365, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_1364, primals_1360, primals_1362, primals_1363, True, 0.1, 0.001);  primals_1360 = None
        getitem_57 = native_batch_norm_default_17[0]
        getitem_58 = native_batch_norm_default_17[1]
        getitem_59 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        relu_default_16 = torch.ops.aten.relu.default(getitem_54)
        constant_pad_nd_default_9 = torch.ops.aten.constant_pad_nd.default(relu_default_16, [2, 2, 2, 2], 0.0)
        convolution_default_31 = torch.ops.aten.convolution.default(constant_pad_nd_default_9, primals_1280, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 108)
        convolution_default_32 = torch.ops.aten.convolution.default(convolution_default_31, primals_1281, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_1274, primals_1270, primals_1272, primals_1273, True, 0.1, 0.001);  primals_1270 = None
        getitem_60 = native_batch_norm_default_18[0]
        getitem_61 = native_batch_norm_default_18[1]
        getitem_62 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        relu_default_17 = torch.ops.aten.relu.default(getitem_60);  getitem_60 = None
        convolution_default_33 = torch.ops.aten.convolution.default(relu_default_17, primals_1282, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 108)
        convolution_default_34 = torch.ops.aten.convolution.default(convolution_default_33, primals_1283, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_1279, primals_1275, primals_1277, primals_1278, True, 0.1, 0.001);  primals_1275 = None
        getitem_63 = native_batch_norm_default_19[0]
        getitem_64 = native_batch_norm_default_19[1]
        getitem_65 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        constant_pad_nd_default_10 = torch.ops.aten.constant_pad_nd.default(getitem_54, [1, 1, 1, 1], -inf)
        max_pool2d_with_indices_default_3 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_10, [3, 3], [2, 2])
        getitem_66 = max_pool2d_with_indices_default_3[0]
        getitem_67 = max_pool2d_with_indices_default_3[1];  max_pool2d_with_indices_default_3 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(getitem_63, getitem_66);  getitem_63 = getitem_66 = None
        relu_default_18 = torch.ops.aten.relu.default(getitem_57)
        constant_pad_nd_default_11 = torch.ops.aten.constant_pad_nd.default(relu_default_18, [3, 3, 3, 3], 0.0)
        convolution_default_35 = torch.ops.aten.convolution.default(constant_pad_nd_default_11, primals_1294, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 108)
        convolution_default_36 = torch.ops.aten.convolution.default(convolution_default_35, primals_1295, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_1288, primals_1284, primals_1286, primals_1287, True, 0.1, 0.001);  primals_1284 = None
        getitem_68 = native_batch_norm_default_20[0]
        getitem_69 = native_batch_norm_default_20[1]
        getitem_70 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        relu_default_19 = torch.ops.aten.relu.default(getitem_68);  getitem_68 = None
        convolution_default_37 = torch.ops.aten.convolution.default(relu_default_19, primals_1296, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 108)
        convolution_default_38 = torch.ops.aten.convolution.default(convolution_default_37, primals_1297, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_1293, primals_1289, primals_1291, primals_1292, True, 0.1, 0.001);  primals_1289 = None
        getitem_71 = native_batch_norm_default_21[0]
        getitem_72 = native_batch_norm_default_21[1]
        getitem_73 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        constant_pad_nd_default_12 = torch.ops.aten.constant_pad_nd.default(getitem_57, [1, 1, 1, 1], -inf)
        max_pool2d_with_indices_default_4 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_12, [3, 3], [2, 2])
        getitem_74 = max_pool2d_with_indices_default_4[0]
        getitem_75 = max_pool2d_with_indices_default_4[1];  max_pool2d_with_indices_default_4 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(getitem_71, getitem_74);  getitem_71 = getitem_74 = None
        relu_default_20 = torch.ops.aten.relu.default(getitem_57)
        constant_pad_nd_default_13 = torch.ops.aten.constant_pad_nd.default(relu_default_20, [2, 2, 2, 2], 0.0)
        convolution_default_39 = torch.ops.aten.convolution.default(constant_pad_nd_default_13, primals_1308, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 108)
        convolution_default_40 = torch.ops.aten.convolution.default(convolution_default_39, primals_1309, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_1302, primals_1298, primals_1300, primals_1301, True, 0.1, 0.001);  primals_1298 = None
        getitem_76 = native_batch_norm_default_22[0]
        getitem_77 = native_batch_norm_default_22[1]
        getitem_78 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        relu_default_21 = torch.ops.aten.relu.default(getitem_76);  getitem_76 = None
        convolution_default_41 = torch.ops.aten.convolution.default(relu_default_21, primals_1310, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 108)
        convolution_default_42 = torch.ops.aten.convolution.default(convolution_default_41, primals_1311, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_42, primals_1307, primals_1303, primals_1305, primals_1306, True, 0.1, 0.001);  primals_1303 = None
        getitem_79 = native_batch_norm_default_23[0]
        getitem_80 = native_batch_norm_default_23[1]
        getitem_81 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        relu_default_22 = torch.ops.aten.relu.default(getitem_57)
        constant_pad_nd_default_14 = torch.ops.aten.constant_pad_nd.default(relu_default_22, [1, 1, 1, 1], 0.0)
        convolution_default_43 = torch.ops.aten.convolution.default(constant_pad_nd_default_14, primals_1322, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 108)
        convolution_default_44 = torch.ops.aten.convolution.default(convolution_default_43, primals_1323, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_1316, primals_1312, primals_1314, primals_1315, True, 0.1, 0.001);  primals_1312 = None
        getitem_82 = native_batch_norm_default_24[0]
        getitem_83 = native_batch_norm_default_24[1]
        getitem_84 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        relu_default_23 = torch.ops.aten.relu.default(getitem_82);  getitem_82 = None
        convolution_default_45 = torch.ops.aten.convolution.default(relu_default_23, primals_1324, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 108)
        convolution_default_46 = torch.ops.aten.convolution.default(convolution_default_45, primals_1325, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_46, primals_1321, primals_1317, primals_1319, primals_1320, True, 0.1, 0.001);  primals_1317 = None
        getitem_85 = native_batch_norm_default_25[0]
        getitem_86 = native_batch_norm_default_25[1]
        getitem_87 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(getitem_79, getitem_85);  getitem_79 = getitem_85 = None
        relu_default_24 = torch.ops.aten.relu.default(add_tensor_8)
        convolution_default_47 = torch.ops.aten.convolution.default(relu_default_24, primals_1336, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 108)
        convolution_default_48 = torch.ops.aten.convolution.default(convolution_default_47, primals_1337, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_48, primals_1330, primals_1326, primals_1328, primals_1329, True, 0.1, 0.001);  primals_1326 = None
        getitem_88 = native_batch_norm_default_26[0]
        getitem_89 = native_batch_norm_default_26[1]
        getitem_90 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        relu_default_25 = torch.ops.aten.relu.default(getitem_88);  getitem_88 = None
        convolution_default_49 = torch.ops.aten.convolution.default(relu_default_25, primals_1338, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 108)
        convolution_default_50 = torch.ops.aten.convolution.default(convolution_default_49, primals_1339, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_50, primals_1335, primals_1331, primals_1333, primals_1334, True, 0.1, 0.001);  primals_1331 = None
        getitem_91 = native_batch_norm_default_27[0]
        getitem_92 = native_batch_norm_default_27[1]
        getitem_93 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        constant_pad_nd_default_15 = torch.ops.aten.constant_pad_nd.default(getitem_57, [1, 1, 1, 1], -inf)
        max_pool2d_with_indices_default_5 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_15, [3, 3], [2, 2])
        getitem_94 = max_pool2d_with_indices_default_5[0]
        getitem_95 = max_pool2d_with_indices_default_5[1];  max_pool2d_with_indices_default_5 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(getitem_91, getitem_94);  getitem_91 = getitem_94 = None
        relu_default_26 = torch.ops.aten.relu.default(getitem_54);  getitem_54 = None
        constant_pad_nd_default_16 = torch.ops.aten.constant_pad_nd.default(relu_default_26, [1, 1, 1, 1], 0.0)
        convolution_default_51 = torch.ops.aten.convolution.default(constant_pad_nd_default_16, primals_1350, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 108)
        convolution_default_52 = torch.ops.aten.convolution.default(convolution_default_51, primals_1351, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_52, primals_1344, primals_1340, primals_1342, primals_1343, True, 0.1, 0.001);  primals_1340 = None
        getitem_96 = native_batch_norm_default_28[0]
        getitem_97 = native_batch_norm_default_28[1]
        getitem_98 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        relu_default_27 = torch.ops.aten.relu.default(getitem_96);  getitem_96 = None
        convolution_default_53 = torch.ops.aten.convolution.default(relu_default_27, primals_1352, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 108)
        convolution_default_54 = torch.ops.aten.convolution.default(convolution_default_53, primals_1353, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_54, primals_1349, primals_1345, primals_1347, primals_1348, True, 0.1, 0.001);  primals_1345 = None
        getitem_99 = native_batch_norm_default_29[0]
        getitem_100 = native_batch_norm_default_29[1]
        getitem_101 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        relu_default_28 = torch.ops.aten.relu.default(getitem_57);  getitem_57 = None
        convolution_default_55 = torch.ops.aten.convolution.default(relu_default_28, primals_1359, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_55, primals_1358, primals_1354, primals_1356, primals_1357, True, 0.1, 0.001);  primals_1354 = None
        getitem_102 = native_batch_norm_default_30[0]
        getitem_103 = native_batch_norm_default_30[1]
        getitem_104 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(getitem_99, getitem_102);  getitem_99 = getitem_102 = None
        cat_default_2 = torch.ops.aten.cat.default([add_tensor_6, add_tensor_7, add_tensor_8, add_tensor_9, add_tensor_10], 1);  add_tensor_6 = add_tensor_7 = add_tensor_8 = add_tensor_9 = add_tensor_10 = None
        relu_default_29 = torch.ops.aten.relu.default(cat_default);  cat_default = None
        avg_pool2d_default_2 = torch.ops.aten.avg_pool2d.default(relu_default_29, [1, 1], [2, 2], [0, 0], False, False)
        convolution_default_56 = torch.ops.aten.convolution.default(avg_pool2d_default_2, primals_96, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        constant_pad_nd_default_17 = torch.ops.aten.constant_pad_nd.default(relu_default_29, [-1, 1, -1, 1], 0.0)
        avg_pool2d_default_3 = torch.ops.aten.avg_pool2d.default(constant_pad_nd_default_17, [1, 1], [2, 2], [0, 0], False, False)
        convolution_default_57 = torch.ops.aten.convolution.default(avg_pool2d_default_3, primals_97, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_3 = torch.ops.aten.cat.default([convolution_default_56, convolution_default_57], 1);  convolution_default_56 = convolution_default_57 = None
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(cat_default_3, primals_95, primals_91, primals_93, primals_94, True, 0.1, 0.001);  primals_91 = None
        getitem_105 = native_batch_norm_default_31[0]
        getitem_106 = native_batch_norm_default_31[1]
        getitem_107 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        relu_default_30 = torch.ops.aten.relu.default(cat_default_2)
        convolution_default_58 = torch.ops.aten.convolution.default(relu_default_30, primals_90, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_58, primals_89, primals_85, primals_87, primals_88, True, 0.1, 0.001);  primals_85 = None
        getitem_108 = native_batch_norm_default_32[0]
        getitem_109 = native_batch_norm_default_32[1]
        getitem_110 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        relu_default_31 = torch.ops.aten.relu.default(getitem_105)
        convolution_default_59 = torch.ops.aten.convolution.default(relu_default_31, primals_11, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 216)
        convolution_default_60 = torch.ops.aten.convolution.default(convolution_default_59, primals_12, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_60, primals_5, primals_1, primals_3, primals_4, True, 0.1, 0.001);  primals_1 = None
        getitem_111 = native_batch_norm_default_33[0]
        getitem_112 = native_batch_norm_default_33[1]
        getitem_113 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        relu_default_32 = torch.ops.aten.relu.default(getitem_111);  getitem_111 = None
        convolution_default_61 = torch.ops.aten.convolution.default(relu_default_32, primals_13, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 216)
        convolution_default_62 = torch.ops.aten.convolution.default(convolution_default_61, primals_14, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_62, primals_10, primals_6, primals_8, primals_9, True, 0.1, 0.001);  primals_6 = None
        getitem_114 = native_batch_norm_default_34[0]
        getitem_115 = native_batch_norm_default_34[1]
        getitem_116 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        max_pool2d_with_indices_default_6 = torch.ops.aten.max_pool2d_with_indices.default(getitem_105, [3, 3], [1, 1], [1, 1])
        getitem_117 = max_pool2d_with_indices_default_6[0]
        getitem_118 = max_pool2d_with_indices_default_6[1];  max_pool2d_with_indices_default_6 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(getitem_114, getitem_117);  getitem_114 = getitem_117 = None
        relu_default_33 = torch.ops.aten.relu.default(getitem_108)
        convolution_default_63 = torch.ops.aten.convolution.default(relu_default_33, primals_25, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 216)
        convolution_default_64 = torch.ops.aten.convolution.default(convolution_default_63, primals_26, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_64, primals_19, primals_15, primals_17, primals_18, True, 0.1, 0.001);  primals_15 = None
        getitem_119 = native_batch_norm_default_35[0]
        getitem_120 = native_batch_norm_default_35[1]
        getitem_121 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        relu_default_34 = torch.ops.aten.relu.default(getitem_119);  getitem_119 = None
        convolution_default_65 = torch.ops.aten.convolution.default(relu_default_34, primals_27, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 216)
        convolution_default_66 = torch.ops.aten.convolution.default(convolution_default_65, primals_28, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_66, primals_24, primals_20, primals_22, primals_23, True, 0.1, 0.001);  primals_20 = None
        getitem_122 = native_batch_norm_default_36[0]
        getitem_123 = native_batch_norm_default_36[1]
        getitem_124 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        max_pool2d_with_indices_default_7 = torch.ops.aten.max_pool2d_with_indices.default(getitem_108, [3, 3], [1, 1], [1, 1])
        getitem_125 = max_pool2d_with_indices_default_7[0]
        getitem_126 = max_pool2d_with_indices_default_7[1];  max_pool2d_with_indices_default_7 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(getitem_122, getitem_125);  getitem_122 = getitem_125 = None
        relu_default_35 = torch.ops.aten.relu.default(getitem_108)
        convolution_default_67 = torch.ops.aten.convolution.default(relu_default_35, primals_39, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 216)
        convolution_default_68 = torch.ops.aten.convolution.default(convolution_default_67, primals_40, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_68, primals_33, primals_29, primals_31, primals_32, True, 0.1, 0.001);  primals_29 = None
        getitem_127 = native_batch_norm_default_37[0]
        getitem_128 = native_batch_norm_default_37[1]
        getitem_129 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        relu_default_36 = torch.ops.aten.relu.default(getitem_127);  getitem_127 = None
        convolution_default_69 = torch.ops.aten.convolution.default(relu_default_36, primals_41, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 216)
        convolution_default_70 = torch.ops.aten.convolution.default(convolution_default_69, primals_42, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_70, primals_38, primals_34, primals_36, primals_37, True, 0.1, 0.001);  primals_34 = None
        getitem_130 = native_batch_norm_default_38[0]
        getitem_131 = native_batch_norm_default_38[1]
        getitem_132 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        relu_default_37 = torch.ops.aten.relu.default(getitem_108)
        convolution_default_71 = torch.ops.aten.convolution.default(relu_default_37, primals_53, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_72 = torch.ops.aten.convolution.default(convolution_default_71, primals_54, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_72, primals_47, primals_43, primals_45, primals_46, True, 0.1, 0.001);  primals_43 = None
        getitem_133 = native_batch_norm_default_39[0]
        getitem_134 = native_batch_norm_default_39[1]
        getitem_135 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        relu_default_38 = torch.ops.aten.relu.default(getitem_133);  getitem_133 = None
        convolution_default_73 = torch.ops.aten.convolution.default(relu_default_38, primals_55, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_74 = torch.ops.aten.convolution.default(convolution_default_73, primals_56, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_74, primals_52, primals_48, primals_50, primals_51, True, 0.1, 0.001);  primals_48 = None
        getitem_136 = native_batch_norm_default_40[0]
        getitem_137 = native_batch_norm_default_40[1]
        getitem_138 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(getitem_130, getitem_136);  getitem_130 = getitem_136 = None
        relu_default_39 = torch.ops.aten.relu.default(add_tensor_13)
        convolution_default_75 = torch.ops.aten.convolution.default(relu_default_39, primals_67, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_76 = torch.ops.aten.convolution.default(convolution_default_75, primals_68, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_76, primals_61, primals_57, primals_59, primals_60, True, 0.1, 0.001);  primals_57 = None
        getitem_139 = native_batch_norm_default_41[0]
        getitem_140 = native_batch_norm_default_41[1]
        getitem_141 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        relu_default_40 = torch.ops.aten.relu.default(getitem_139);  getitem_139 = None
        convolution_default_77 = torch.ops.aten.convolution.default(relu_default_40, primals_69, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_78 = torch.ops.aten.convolution.default(convolution_default_77, primals_70, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_78, primals_66, primals_62, primals_64, primals_65, True, 0.1, 0.001);  primals_62 = None
        getitem_142 = native_batch_norm_default_42[0]
        getitem_143 = native_batch_norm_default_42[1]
        getitem_144 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        max_pool2d_with_indices_default_8 = torch.ops.aten.max_pool2d_with_indices.default(getitem_108, [3, 3], [1, 1], [1, 1])
        getitem_145 = max_pool2d_with_indices_default_8[0]
        getitem_146 = max_pool2d_with_indices_default_8[1];  max_pool2d_with_indices_default_8 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(getitem_142, getitem_145);  getitem_142 = getitem_145 = None
        relu_default_41 = torch.ops.aten.relu.default(getitem_105)
        convolution_default_79 = torch.ops.aten.convolution.default(relu_default_41, primals_81, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_80 = torch.ops.aten.convolution.default(convolution_default_79, primals_82, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_80, primals_75, primals_71, primals_73, primals_74, True, 0.1, 0.001);  primals_71 = None
        getitem_147 = native_batch_norm_default_43[0]
        getitem_148 = native_batch_norm_default_43[1]
        getitem_149 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        relu_default_42 = torch.ops.aten.relu.default(getitem_147);  getitem_147 = None
        convolution_default_81 = torch.ops.aten.convolution.default(relu_default_42, primals_83, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_82 = torch.ops.aten.convolution.default(convolution_default_81, primals_84, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_82, primals_80, primals_76, primals_78, primals_79, True, 0.1, 0.001);  primals_76 = None
        getitem_150 = native_batch_norm_default_44[0]
        getitem_151 = native_batch_norm_default_44[1]
        getitem_152 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(getitem_150, getitem_108);  getitem_150 = None
        cat_default_4 = torch.ops.aten.cat.default([add_tensor_11, add_tensor_12, add_tensor_13, add_tensor_14, add_tensor_15], 1);  add_tensor_11 = add_tensor_12 = add_tensor_13 = add_tensor_14 = add_tensor_15 = None
        relu_default_43 = torch.ops.aten.relu.default(cat_default_2);  cat_default_2 = None
        convolution_default_83 = torch.ops.aten.convolution.default(relu_default_43, primals_385, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_83, primals_384, primals_380, primals_382, primals_383, True, 0.1, 0.001);  primals_380 = None
        getitem_153 = native_batch_norm_default_45[0]
        getitem_154 = native_batch_norm_default_45[1]
        getitem_155 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        relu_default_44 = torch.ops.aten.relu.default(cat_default_4)
        convolution_default_84 = torch.ops.aten.convolution.default(relu_default_44, primals_379, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(convolution_default_84, primals_378, primals_374, primals_376, primals_377, True, 0.1, 0.001);  primals_374 = None
        getitem_156 = native_batch_norm_default_46[0]
        getitem_157 = native_batch_norm_default_46[1]
        getitem_158 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        relu_default_45 = torch.ops.aten.relu.default(getitem_153)
        convolution_default_85 = torch.ops.aten.convolution.default(relu_default_45, primals_300, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 216)
        convolution_default_86 = torch.ops.aten.convolution.default(convolution_default_85, primals_301, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(convolution_default_86, primals_294, primals_290, primals_292, primals_293, True, 0.1, 0.001);  primals_290 = None
        getitem_159 = native_batch_norm_default_47[0]
        getitem_160 = native_batch_norm_default_47[1]
        getitem_161 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        relu_default_46 = torch.ops.aten.relu.default(getitem_159);  getitem_159 = None
        convolution_default_87 = torch.ops.aten.convolution.default(relu_default_46, primals_302, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 216)
        convolution_default_88 = torch.ops.aten.convolution.default(convolution_default_87, primals_303, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_88, primals_299, primals_295, primals_297, primals_298, True, 0.1, 0.001);  primals_295 = None
        getitem_162 = native_batch_norm_default_48[0]
        getitem_163 = native_batch_norm_default_48[1]
        getitem_164 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        max_pool2d_with_indices_default_9 = torch.ops.aten.max_pool2d_with_indices.default(getitem_153, [3, 3], [1, 1], [1, 1])
        getitem_165 = max_pool2d_with_indices_default_9[0]
        getitem_166 = max_pool2d_with_indices_default_9[1];  max_pool2d_with_indices_default_9 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(getitem_162, getitem_165);  getitem_162 = getitem_165 = None
        relu_default_47 = torch.ops.aten.relu.default(getitem_156)
        convolution_default_89 = torch.ops.aten.convolution.default(relu_default_47, primals_314, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 216)
        convolution_default_90 = torch.ops.aten.convolution.default(convolution_default_89, primals_315, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(convolution_default_90, primals_308, primals_304, primals_306, primals_307, True, 0.1, 0.001);  primals_304 = None
        getitem_167 = native_batch_norm_default_49[0]
        getitem_168 = native_batch_norm_default_49[1]
        getitem_169 = native_batch_norm_default_49[2];  native_batch_norm_default_49 = None
        relu_default_48 = torch.ops.aten.relu.default(getitem_167);  getitem_167 = None
        convolution_default_91 = torch.ops.aten.convolution.default(relu_default_48, primals_316, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 216)
        convolution_default_92 = torch.ops.aten.convolution.default(convolution_default_91, primals_317, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(convolution_default_92, primals_313, primals_309, primals_311, primals_312, True, 0.1, 0.001);  primals_309 = None
        getitem_170 = native_batch_norm_default_50[0]
        getitem_171 = native_batch_norm_default_50[1]
        getitem_172 = native_batch_norm_default_50[2];  native_batch_norm_default_50 = None
        max_pool2d_with_indices_default_10 = torch.ops.aten.max_pool2d_with_indices.default(getitem_156, [3, 3], [1, 1], [1, 1])
        getitem_173 = max_pool2d_with_indices_default_10[0]
        getitem_174 = max_pool2d_with_indices_default_10[1];  max_pool2d_with_indices_default_10 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(getitem_170, getitem_173);  getitem_170 = getitem_173 = None
        relu_default_49 = torch.ops.aten.relu.default(getitem_156)
        convolution_default_93 = torch.ops.aten.convolution.default(relu_default_49, primals_328, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 216)
        convolution_default_94 = torch.ops.aten.convolution.default(convolution_default_93, primals_329, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(convolution_default_94, primals_322, primals_318, primals_320, primals_321, True, 0.1, 0.001);  primals_318 = None
        getitem_175 = native_batch_norm_default_51[0]
        getitem_176 = native_batch_norm_default_51[1]
        getitem_177 = native_batch_norm_default_51[2];  native_batch_norm_default_51 = None
        relu_default_50 = torch.ops.aten.relu.default(getitem_175);  getitem_175 = None
        convolution_default_95 = torch.ops.aten.convolution.default(relu_default_50, primals_330, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 216)
        convolution_default_96 = torch.ops.aten.convolution.default(convolution_default_95, primals_331, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(convolution_default_96, primals_327, primals_323, primals_325, primals_326, True, 0.1, 0.001);  primals_323 = None
        getitem_178 = native_batch_norm_default_52[0]
        getitem_179 = native_batch_norm_default_52[1]
        getitem_180 = native_batch_norm_default_52[2];  native_batch_norm_default_52 = None
        relu_default_51 = torch.ops.aten.relu.default(getitem_156)
        convolution_default_97 = torch.ops.aten.convolution.default(relu_default_51, primals_342, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_98 = torch.ops.aten.convolution.default(convolution_default_97, primals_343, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_53 = torch.ops.aten.native_batch_norm.default(convolution_default_98, primals_336, primals_332, primals_334, primals_335, True, 0.1, 0.001);  primals_332 = None
        getitem_181 = native_batch_norm_default_53[0]
        getitem_182 = native_batch_norm_default_53[1]
        getitem_183 = native_batch_norm_default_53[2];  native_batch_norm_default_53 = None
        relu_default_52 = torch.ops.aten.relu.default(getitem_181);  getitem_181 = None
        convolution_default_99 = torch.ops.aten.convolution.default(relu_default_52, primals_344, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_100 = torch.ops.aten.convolution.default(convolution_default_99, primals_345, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_54 = torch.ops.aten.native_batch_norm.default(convolution_default_100, primals_341, primals_337, primals_339, primals_340, True, 0.1, 0.001);  primals_337 = None
        getitem_184 = native_batch_norm_default_54[0]
        getitem_185 = native_batch_norm_default_54[1]
        getitem_186 = native_batch_norm_default_54[2];  native_batch_norm_default_54 = None
        add_tensor_18 = torch.ops.aten.add.Tensor(getitem_178, getitem_184);  getitem_178 = getitem_184 = None
        relu_default_53 = torch.ops.aten.relu.default(add_tensor_18)
        convolution_default_101 = torch.ops.aten.convolution.default(relu_default_53, primals_356, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_102 = torch.ops.aten.convolution.default(convolution_default_101, primals_357, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_55 = torch.ops.aten.native_batch_norm.default(convolution_default_102, primals_350, primals_346, primals_348, primals_349, True, 0.1, 0.001);  primals_346 = None
        getitem_187 = native_batch_norm_default_55[0]
        getitem_188 = native_batch_norm_default_55[1]
        getitem_189 = native_batch_norm_default_55[2];  native_batch_norm_default_55 = None
        relu_default_54 = torch.ops.aten.relu.default(getitem_187);  getitem_187 = None
        convolution_default_103 = torch.ops.aten.convolution.default(relu_default_54, primals_358, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_104 = torch.ops.aten.convolution.default(convolution_default_103, primals_359, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_56 = torch.ops.aten.native_batch_norm.default(convolution_default_104, primals_355, primals_351, primals_353, primals_354, True, 0.1, 0.001);  primals_351 = None
        getitem_190 = native_batch_norm_default_56[0]
        getitem_191 = native_batch_norm_default_56[1]
        getitem_192 = native_batch_norm_default_56[2];  native_batch_norm_default_56 = None
        max_pool2d_with_indices_default_11 = torch.ops.aten.max_pool2d_with_indices.default(getitem_156, [3, 3], [1, 1], [1, 1])
        getitem_193 = max_pool2d_with_indices_default_11[0]
        getitem_194 = max_pool2d_with_indices_default_11[1];  max_pool2d_with_indices_default_11 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(getitem_190, getitem_193);  getitem_190 = getitem_193 = None
        relu_default_55 = torch.ops.aten.relu.default(getitem_153)
        convolution_default_105 = torch.ops.aten.convolution.default(relu_default_55, primals_370, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_106 = torch.ops.aten.convolution.default(convolution_default_105, primals_371, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_57 = torch.ops.aten.native_batch_norm.default(convolution_default_106, primals_364, primals_360, primals_362, primals_363, True, 0.1, 0.001);  primals_360 = None
        getitem_195 = native_batch_norm_default_57[0]
        getitem_196 = native_batch_norm_default_57[1]
        getitem_197 = native_batch_norm_default_57[2];  native_batch_norm_default_57 = None
        relu_default_56 = torch.ops.aten.relu.default(getitem_195);  getitem_195 = None
        convolution_default_107 = torch.ops.aten.convolution.default(relu_default_56, primals_372, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_108 = torch.ops.aten.convolution.default(convolution_default_107, primals_373, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_58 = torch.ops.aten.native_batch_norm.default(convolution_default_108, primals_369, primals_365, primals_367, primals_368, True, 0.1, 0.001);  primals_365 = None
        getitem_198 = native_batch_norm_default_58[0]
        getitem_199 = native_batch_norm_default_58[1]
        getitem_200 = native_batch_norm_default_58[2];  native_batch_norm_default_58 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(getitem_198, getitem_156);  getitem_198 = None
        cat_default_5 = torch.ops.aten.cat.default([add_tensor_16, add_tensor_17, add_tensor_18, add_tensor_19, add_tensor_20], 1);  add_tensor_16 = add_tensor_17 = add_tensor_18 = add_tensor_19 = add_tensor_20 = None
        relu_default_57 = torch.ops.aten.relu.default(cat_default_4);  cat_default_4 = None
        convolution_default_109 = torch.ops.aten.convolution.default(relu_default_57, primals_481, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_59 = torch.ops.aten.native_batch_norm.default(convolution_default_109, primals_480, primals_476, primals_478, primals_479, True, 0.1, 0.001);  primals_476 = None
        getitem_201 = native_batch_norm_default_59[0]
        getitem_202 = native_batch_norm_default_59[1]
        getitem_203 = native_batch_norm_default_59[2];  native_batch_norm_default_59 = None
        relu_default_58 = torch.ops.aten.relu.default(cat_default_5)
        convolution_default_110 = torch.ops.aten.convolution.default(relu_default_58, primals_475, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_60 = torch.ops.aten.native_batch_norm.default(convolution_default_110, primals_474, primals_470, primals_472, primals_473, True, 0.1, 0.001);  primals_470 = None
        getitem_204 = native_batch_norm_default_60[0]
        getitem_205 = native_batch_norm_default_60[1]
        getitem_206 = native_batch_norm_default_60[2];  native_batch_norm_default_60 = None
        relu_default_59 = torch.ops.aten.relu.default(getitem_201)
        convolution_default_111 = torch.ops.aten.convolution.default(relu_default_59, primals_396, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 216)
        convolution_default_112 = torch.ops.aten.convolution.default(convolution_default_111, primals_397, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_61 = torch.ops.aten.native_batch_norm.default(convolution_default_112, primals_390, primals_386, primals_388, primals_389, True, 0.1, 0.001);  primals_386 = None
        getitem_207 = native_batch_norm_default_61[0]
        getitem_208 = native_batch_norm_default_61[1]
        getitem_209 = native_batch_norm_default_61[2];  native_batch_norm_default_61 = None
        relu_default_60 = torch.ops.aten.relu.default(getitem_207);  getitem_207 = None
        convolution_default_113 = torch.ops.aten.convolution.default(relu_default_60, primals_398, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 216)
        convolution_default_114 = torch.ops.aten.convolution.default(convolution_default_113, primals_399, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_62 = torch.ops.aten.native_batch_norm.default(convolution_default_114, primals_395, primals_391, primals_393, primals_394, True, 0.1, 0.001);  primals_391 = None
        getitem_210 = native_batch_norm_default_62[0]
        getitem_211 = native_batch_norm_default_62[1]
        getitem_212 = native_batch_norm_default_62[2];  native_batch_norm_default_62 = None
        max_pool2d_with_indices_default_12 = torch.ops.aten.max_pool2d_with_indices.default(getitem_201, [3, 3], [1, 1], [1, 1])
        getitem_213 = max_pool2d_with_indices_default_12[0]
        getitem_214 = max_pool2d_with_indices_default_12[1];  max_pool2d_with_indices_default_12 = None
        add_tensor_21 = torch.ops.aten.add.Tensor(getitem_210, getitem_213);  getitem_210 = getitem_213 = None
        relu_default_61 = torch.ops.aten.relu.default(getitem_204)
        convolution_default_115 = torch.ops.aten.convolution.default(relu_default_61, primals_410, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 216)
        convolution_default_116 = torch.ops.aten.convolution.default(convolution_default_115, primals_411, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_63 = torch.ops.aten.native_batch_norm.default(convolution_default_116, primals_404, primals_400, primals_402, primals_403, True, 0.1, 0.001);  primals_400 = None
        getitem_215 = native_batch_norm_default_63[0]
        getitem_216 = native_batch_norm_default_63[1]
        getitem_217 = native_batch_norm_default_63[2];  native_batch_norm_default_63 = None
        relu_default_62 = torch.ops.aten.relu.default(getitem_215);  getitem_215 = None
        convolution_default_117 = torch.ops.aten.convolution.default(relu_default_62, primals_412, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 216)
        convolution_default_118 = torch.ops.aten.convolution.default(convolution_default_117, primals_413, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_64 = torch.ops.aten.native_batch_norm.default(convolution_default_118, primals_409, primals_405, primals_407, primals_408, True, 0.1, 0.001);  primals_405 = None
        getitem_218 = native_batch_norm_default_64[0]
        getitem_219 = native_batch_norm_default_64[1]
        getitem_220 = native_batch_norm_default_64[2];  native_batch_norm_default_64 = None
        max_pool2d_with_indices_default_13 = torch.ops.aten.max_pool2d_with_indices.default(getitem_204, [3, 3], [1, 1], [1, 1])
        getitem_221 = max_pool2d_with_indices_default_13[0]
        getitem_222 = max_pool2d_with_indices_default_13[1];  max_pool2d_with_indices_default_13 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(getitem_218, getitem_221);  getitem_218 = getitem_221 = None
        relu_default_63 = torch.ops.aten.relu.default(getitem_204)
        convolution_default_119 = torch.ops.aten.convolution.default(relu_default_63, primals_424, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 216)
        convolution_default_120 = torch.ops.aten.convolution.default(convolution_default_119, primals_425, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_65 = torch.ops.aten.native_batch_norm.default(convolution_default_120, primals_418, primals_414, primals_416, primals_417, True, 0.1, 0.001);  primals_414 = None
        getitem_223 = native_batch_norm_default_65[0]
        getitem_224 = native_batch_norm_default_65[1]
        getitem_225 = native_batch_norm_default_65[2];  native_batch_norm_default_65 = None
        relu_default_64 = torch.ops.aten.relu.default(getitem_223);  getitem_223 = None
        convolution_default_121 = torch.ops.aten.convolution.default(relu_default_64, primals_426, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 216)
        convolution_default_122 = torch.ops.aten.convolution.default(convolution_default_121, primals_427, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_66 = torch.ops.aten.native_batch_norm.default(convolution_default_122, primals_423, primals_419, primals_421, primals_422, True, 0.1, 0.001);  primals_419 = None
        getitem_226 = native_batch_norm_default_66[0]
        getitem_227 = native_batch_norm_default_66[1]
        getitem_228 = native_batch_norm_default_66[2];  native_batch_norm_default_66 = None
        relu_default_65 = torch.ops.aten.relu.default(getitem_204)
        convolution_default_123 = torch.ops.aten.convolution.default(relu_default_65, primals_438, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_124 = torch.ops.aten.convolution.default(convolution_default_123, primals_439, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_67 = torch.ops.aten.native_batch_norm.default(convolution_default_124, primals_432, primals_428, primals_430, primals_431, True, 0.1, 0.001);  primals_428 = None
        getitem_229 = native_batch_norm_default_67[0]
        getitem_230 = native_batch_norm_default_67[1]
        getitem_231 = native_batch_norm_default_67[2];  native_batch_norm_default_67 = None
        relu_default_66 = torch.ops.aten.relu.default(getitem_229);  getitem_229 = None
        convolution_default_125 = torch.ops.aten.convolution.default(relu_default_66, primals_440, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_126 = torch.ops.aten.convolution.default(convolution_default_125, primals_441, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_68 = torch.ops.aten.native_batch_norm.default(convolution_default_126, primals_437, primals_433, primals_435, primals_436, True, 0.1, 0.001);  primals_433 = None
        getitem_232 = native_batch_norm_default_68[0]
        getitem_233 = native_batch_norm_default_68[1]
        getitem_234 = native_batch_norm_default_68[2];  native_batch_norm_default_68 = None
        add_tensor_23 = torch.ops.aten.add.Tensor(getitem_226, getitem_232);  getitem_226 = getitem_232 = None
        relu_default_67 = torch.ops.aten.relu.default(add_tensor_23)
        convolution_default_127 = torch.ops.aten.convolution.default(relu_default_67, primals_452, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_128 = torch.ops.aten.convolution.default(convolution_default_127, primals_453, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_69 = torch.ops.aten.native_batch_norm.default(convolution_default_128, primals_446, primals_442, primals_444, primals_445, True, 0.1, 0.001);  primals_442 = None
        getitem_235 = native_batch_norm_default_69[0]
        getitem_236 = native_batch_norm_default_69[1]
        getitem_237 = native_batch_norm_default_69[2];  native_batch_norm_default_69 = None
        relu_default_68 = torch.ops.aten.relu.default(getitem_235);  getitem_235 = None
        convolution_default_129 = torch.ops.aten.convolution.default(relu_default_68, primals_454, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_130 = torch.ops.aten.convolution.default(convolution_default_129, primals_455, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_70 = torch.ops.aten.native_batch_norm.default(convolution_default_130, primals_451, primals_447, primals_449, primals_450, True, 0.1, 0.001);  primals_447 = None
        getitem_238 = native_batch_norm_default_70[0]
        getitem_239 = native_batch_norm_default_70[1]
        getitem_240 = native_batch_norm_default_70[2];  native_batch_norm_default_70 = None
        max_pool2d_with_indices_default_14 = torch.ops.aten.max_pool2d_with_indices.default(getitem_204, [3, 3], [1, 1], [1, 1])
        getitem_241 = max_pool2d_with_indices_default_14[0]
        getitem_242 = max_pool2d_with_indices_default_14[1];  max_pool2d_with_indices_default_14 = None
        add_tensor_24 = torch.ops.aten.add.Tensor(getitem_238, getitem_241);  getitem_238 = getitem_241 = None
        relu_default_69 = torch.ops.aten.relu.default(getitem_201)
        convolution_default_131 = torch.ops.aten.convolution.default(relu_default_69, primals_466, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_132 = torch.ops.aten.convolution.default(convolution_default_131, primals_467, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_71 = torch.ops.aten.native_batch_norm.default(convolution_default_132, primals_460, primals_456, primals_458, primals_459, True, 0.1, 0.001);  primals_456 = None
        getitem_243 = native_batch_norm_default_71[0]
        getitem_244 = native_batch_norm_default_71[1]
        getitem_245 = native_batch_norm_default_71[2];  native_batch_norm_default_71 = None
        relu_default_70 = torch.ops.aten.relu.default(getitem_243);  getitem_243 = None
        convolution_default_133 = torch.ops.aten.convolution.default(relu_default_70, primals_468, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_134 = torch.ops.aten.convolution.default(convolution_default_133, primals_469, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_72 = torch.ops.aten.native_batch_norm.default(convolution_default_134, primals_465, primals_461, primals_463, primals_464, True, 0.1, 0.001);  primals_461 = None
        getitem_246 = native_batch_norm_default_72[0]
        getitem_247 = native_batch_norm_default_72[1]
        getitem_248 = native_batch_norm_default_72[2];  native_batch_norm_default_72 = None
        add_tensor_25 = torch.ops.aten.add.Tensor(getitem_246, getitem_204);  getitem_246 = None
        cat_default_6 = torch.ops.aten.cat.default([add_tensor_21, add_tensor_22, add_tensor_23, add_tensor_24, add_tensor_25], 1);  add_tensor_21 = add_tensor_22 = add_tensor_23 = add_tensor_24 = add_tensor_25 = None
        relu_default_71 = torch.ops.aten.relu.default(cat_default_5);  cat_default_5 = None
        convolution_default_135 = torch.ops.aten.convolution.default(relu_default_71, primals_577, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_73 = torch.ops.aten.native_batch_norm.default(convolution_default_135, primals_576, primals_572, primals_574, primals_575, True, 0.1, 0.001);  primals_572 = None
        getitem_249 = native_batch_norm_default_73[0]
        getitem_250 = native_batch_norm_default_73[1]
        getitem_251 = native_batch_norm_default_73[2];  native_batch_norm_default_73 = None
        relu_default_72 = torch.ops.aten.relu.default(cat_default_6)
        convolution_default_136 = torch.ops.aten.convolution.default(relu_default_72, primals_571, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_74 = torch.ops.aten.native_batch_norm.default(convolution_default_136, primals_570, primals_566, primals_568, primals_569, True, 0.1, 0.001);  primals_566 = None
        getitem_252 = native_batch_norm_default_74[0]
        getitem_253 = native_batch_norm_default_74[1]
        getitem_254 = native_batch_norm_default_74[2];  native_batch_norm_default_74 = None
        relu_default_73 = torch.ops.aten.relu.default(getitem_249)
        convolution_default_137 = torch.ops.aten.convolution.default(relu_default_73, primals_492, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 216)
        convolution_default_138 = torch.ops.aten.convolution.default(convolution_default_137, primals_493, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_75 = torch.ops.aten.native_batch_norm.default(convolution_default_138, primals_486, primals_482, primals_484, primals_485, True, 0.1, 0.001);  primals_482 = None
        getitem_255 = native_batch_norm_default_75[0]
        getitem_256 = native_batch_norm_default_75[1]
        getitem_257 = native_batch_norm_default_75[2];  native_batch_norm_default_75 = None
        relu_default_74 = torch.ops.aten.relu.default(getitem_255);  getitem_255 = None
        convolution_default_139 = torch.ops.aten.convolution.default(relu_default_74, primals_494, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 216)
        convolution_default_140 = torch.ops.aten.convolution.default(convolution_default_139, primals_495, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_76 = torch.ops.aten.native_batch_norm.default(convolution_default_140, primals_491, primals_487, primals_489, primals_490, True, 0.1, 0.001);  primals_487 = None
        getitem_258 = native_batch_norm_default_76[0]
        getitem_259 = native_batch_norm_default_76[1]
        getitem_260 = native_batch_norm_default_76[2];  native_batch_norm_default_76 = None
        max_pool2d_with_indices_default_15 = torch.ops.aten.max_pool2d_with_indices.default(getitem_249, [3, 3], [1, 1], [1, 1])
        getitem_261 = max_pool2d_with_indices_default_15[0]
        getitem_262 = max_pool2d_with_indices_default_15[1];  max_pool2d_with_indices_default_15 = None
        add_tensor_26 = torch.ops.aten.add.Tensor(getitem_258, getitem_261);  getitem_258 = getitem_261 = None
        relu_default_75 = torch.ops.aten.relu.default(getitem_252)
        convolution_default_141 = torch.ops.aten.convolution.default(relu_default_75, primals_506, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 216)
        convolution_default_142 = torch.ops.aten.convolution.default(convolution_default_141, primals_507, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_77 = torch.ops.aten.native_batch_norm.default(convolution_default_142, primals_500, primals_496, primals_498, primals_499, True, 0.1, 0.001);  primals_496 = None
        getitem_263 = native_batch_norm_default_77[0]
        getitem_264 = native_batch_norm_default_77[1]
        getitem_265 = native_batch_norm_default_77[2];  native_batch_norm_default_77 = None
        relu_default_76 = torch.ops.aten.relu.default(getitem_263);  getitem_263 = None
        convolution_default_143 = torch.ops.aten.convolution.default(relu_default_76, primals_508, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 216)
        convolution_default_144 = torch.ops.aten.convolution.default(convolution_default_143, primals_509, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_78 = torch.ops.aten.native_batch_norm.default(convolution_default_144, primals_505, primals_501, primals_503, primals_504, True, 0.1, 0.001);  primals_501 = None
        getitem_266 = native_batch_norm_default_78[0]
        getitem_267 = native_batch_norm_default_78[1]
        getitem_268 = native_batch_norm_default_78[2];  native_batch_norm_default_78 = None
        max_pool2d_with_indices_default_16 = torch.ops.aten.max_pool2d_with_indices.default(getitem_252, [3, 3], [1, 1], [1, 1])
        getitem_269 = max_pool2d_with_indices_default_16[0]
        getitem_270 = max_pool2d_with_indices_default_16[1];  max_pool2d_with_indices_default_16 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(getitem_266, getitem_269);  getitem_266 = getitem_269 = None
        relu_default_77 = torch.ops.aten.relu.default(getitem_252)
        convolution_default_145 = torch.ops.aten.convolution.default(relu_default_77, primals_520, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 216)
        convolution_default_146 = torch.ops.aten.convolution.default(convolution_default_145, primals_521, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_79 = torch.ops.aten.native_batch_norm.default(convolution_default_146, primals_514, primals_510, primals_512, primals_513, True, 0.1, 0.001);  primals_510 = None
        getitem_271 = native_batch_norm_default_79[0]
        getitem_272 = native_batch_norm_default_79[1]
        getitem_273 = native_batch_norm_default_79[2];  native_batch_norm_default_79 = None
        relu_default_78 = torch.ops.aten.relu.default(getitem_271);  getitem_271 = None
        convolution_default_147 = torch.ops.aten.convolution.default(relu_default_78, primals_522, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 216)
        convolution_default_148 = torch.ops.aten.convolution.default(convolution_default_147, primals_523, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_80 = torch.ops.aten.native_batch_norm.default(convolution_default_148, primals_519, primals_515, primals_517, primals_518, True, 0.1, 0.001);  primals_515 = None
        getitem_274 = native_batch_norm_default_80[0]
        getitem_275 = native_batch_norm_default_80[1]
        getitem_276 = native_batch_norm_default_80[2];  native_batch_norm_default_80 = None
        relu_default_79 = torch.ops.aten.relu.default(getitem_252)
        convolution_default_149 = torch.ops.aten.convolution.default(relu_default_79, primals_534, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_150 = torch.ops.aten.convolution.default(convolution_default_149, primals_535, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_81 = torch.ops.aten.native_batch_norm.default(convolution_default_150, primals_528, primals_524, primals_526, primals_527, True, 0.1, 0.001);  primals_524 = None
        getitem_277 = native_batch_norm_default_81[0]
        getitem_278 = native_batch_norm_default_81[1]
        getitem_279 = native_batch_norm_default_81[2];  native_batch_norm_default_81 = None
        relu_default_80 = torch.ops.aten.relu.default(getitem_277);  getitem_277 = None
        convolution_default_151 = torch.ops.aten.convolution.default(relu_default_80, primals_536, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_152 = torch.ops.aten.convolution.default(convolution_default_151, primals_537, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_82 = torch.ops.aten.native_batch_norm.default(convolution_default_152, primals_533, primals_529, primals_531, primals_532, True, 0.1, 0.001);  primals_529 = None
        getitem_280 = native_batch_norm_default_82[0]
        getitem_281 = native_batch_norm_default_82[1]
        getitem_282 = native_batch_norm_default_82[2];  native_batch_norm_default_82 = None
        add_tensor_28 = torch.ops.aten.add.Tensor(getitem_274, getitem_280);  getitem_274 = getitem_280 = None
        relu_default_81 = torch.ops.aten.relu.default(add_tensor_28)
        convolution_default_153 = torch.ops.aten.convolution.default(relu_default_81, primals_548, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_154 = torch.ops.aten.convolution.default(convolution_default_153, primals_549, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_83 = torch.ops.aten.native_batch_norm.default(convolution_default_154, primals_542, primals_538, primals_540, primals_541, True, 0.1, 0.001);  primals_538 = None
        getitem_283 = native_batch_norm_default_83[0]
        getitem_284 = native_batch_norm_default_83[1]
        getitem_285 = native_batch_norm_default_83[2];  native_batch_norm_default_83 = None
        relu_default_82 = torch.ops.aten.relu.default(getitem_283);  getitem_283 = None
        convolution_default_155 = torch.ops.aten.convolution.default(relu_default_82, primals_550, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_156 = torch.ops.aten.convolution.default(convolution_default_155, primals_551, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_84 = torch.ops.aten.native_batch_norm.default(convolution_default_156, primals_547, primals_543, primals_545, primals_546, True, 0.1, 0.001);  primals_543 = None
        getitem_286 = native_batch_norm_default_84[0]
        getitem_287 = native_batch_norm_default_84[1]
        getitem_288 = native_batch_norm_default_84[2];  native_batch_norm_default_84 = None
        max_pool2d_with_indices_default_17 = torch.ops.aten.max_pool2d_with_indices.default(getitem_252, [3, 3], [1, 1], [1, 1])
        getitem_289 = max_pool2d_with_indices_default_17[0]
        getitem_290 = max_pool2d_with_indices_default_17[1];  max_pool2d_with_indices_default_17 = None
        add_tensor_29 = torch.ops.aten.add.Tensor(getitem_286, getitem_289);  getitem_286 = getitem_289 = None
        relu_default_83 = torch.ops.aten.relu.default(getitem_249)
        convolution_default_157 = torch.ops.aten.convolution.default(relu_default_83, primals_562, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_158 = torch.ops.aten.convolution.default(convolution_default_157, primals_563, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_85 = torch.ops.aten.native_batch_norm.default(convolution_default_158, primals_556, primals_552, primals_554, primals_555, True, 0.1, 0.001);  primals_552 = None
        getitem_291 = native_batch_norm_default_85[0]
        getitem_292 = native_batch_norm_default_85[1]
        getitem_293 = native_batch_norm_default_85[2];  native_batch_norm_default_85 = None
        relu_default_84 = torch.ops.aten.relu.default(getitem_291);  getitem_291 = None
        convolution_default_159 = torch.ops.aten.convolution.default(relu_default_84, primals_564, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 216)
        convolution_default_160 = torch.ops.aten.convolution.default(convolution_default_159, primals_565, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_86 = torch.ops.aten.native_batch_norm.default(convolution_default_160, primals_561, primals_557, primals_559, primals_560, True, 0.1, 0.001);  primals_557 = None
        getitem_294 = native_batch_norm_default_86[0]
        getitem_295 = native_batch_norm_default_86[1]
        getitem_296 = native_batch_norm_default_86[2];  native_batch_norm_default_86 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(getitem_294, getitem_252);  getitem_294 = None
        cat_default_7 = torch.ops.aten.cat.default([add_tensor_26, add_tensor_27, add_tensor_28, add_tensor_29, add_tensor_30], 1);  add_tensor_26 = add_tensor_27 = add_tensor_28 = add_tensor_29 = add_tensor_30 = None
        relu_default_85 = torch.ops.aten.relu.default(cat_default_6);  cat_default_6 = None
        convolution_default_161 = torch.ops.aten.convolution.default(relu_default_85, primals_679, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_87 = torch.ops.aten.native_batch_norm.default(convolution_default_161, primals_678, primals_674, primals_676, primals_677, True, 0.1, 0.001);  primals_674 = None
        getitem_297 = native_batch_norm_default_87[0]
        getitem_298 = native_batch_norm_default_87[1]
        getitem_299 = native_batch_norm_default_87[2];  native_batch_norm_default_87 = None
        relu_default_86 = torch.ops.aten.relu.default(cat_default_7)
        convolution_default_162 = torch.ops.aten.convolution.default(relu_default_86, primals_673, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_88 = torch.ops.aten.native_batch_norm.default(convolution_default_162, primals_672, primals_668, primals_670, primals_671, True, 0.1, 0.001);  primals_668 = None
        getitem_300 = native_batch_norm_default_88[0]
        getitem_301 = native_batch_norm_default_88[1]
        getitem_302 = native_batch_norm_default_88[2];  native_batch_norm_default_88 = None
        relu_default_87 = torch.ops.aten.relu.default(getitem_297)
        constant_pad_nd_default_18 = torch.ops.aten.constant_pad_nd.default(relu_default_87, [1, 2, 1, 2], 0.0)
        convolution_default_163 = torch.ops.aten.convolution.default(constant_pad_nd_default_18, primals_588, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 432)
        convolution_default_164 = torch.ops.aten.convolution.default(convolution_default_163, primals_589, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_89 = torch.ops.aten.native_batch_norm.default(convolution_default_164, primals_582, primals_578, primals_580, primals_581, True, 0.1, 0.001);  primals_578 = None
        getitem_303 = native_batch_norm_default_89[0]
        getitem_304 = native_batch_norm_default_89[1]
        getitem_305 = native_batch_norm_default_89[2];  native_batch_norm_default_89 = None
        relu_default_88 = torch.ops.aten.relu.default(getitem_303);  getitem_303 = None
        convolution_default_165 = torch.ops.aten.convolution.default(relu_default_88, primals_590, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 432)
        convolution_default_166 = torch.ops.aten.convolution.default(convolution_default_165, primals_591, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_90 = torch.ops.aten.native_batch_norm.default(convolution_default_166, primals_587, primals_583, primals_585, primals_586, True, 0.1, 0.001);  primals_583 = None
        getitem_306 = native_batch_norm_default_90[0]
        getitem_307 = native_batch_norm_default_90[1]
        getitem_308 = native_batch_norm_default_90[2];  native_batch_norm_default_90 = None
        constant_pad_nd_default_19 = torch.ops.aten.constant_pad_nd.default(getitem_297, [0, 1, 0, 1], -inf)
        max_pool2d_with_indices_default_18 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_19, [3, 3], [2, 2])
        getitem_309 = max_pool2d_with_indices_default_18[0]
        getitem_310 = max_pool2d_with_indices_default_18[1];  max_pool2d_with_indices_default_18 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(getitem_306, getitem_309);  getitem_306 = getitem_309 = None
        relu_default_89 = torch.ops.aten.relu.default(getitem_300)
        constant_pad_nd_default_20 = torch.ops.aten.constant_pad_nd.default(relu_default_89, [2, 3, 2, 3], 0.0)
        convolution_default_167 = torch.ops.aten.convolution.default(constant_pad_nd_default_20, primals_602, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 432)
        convolution_default_168 = torch.ops.aten.convolution.default(convolution_default_167, primals_603, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_91 = torch.ops.aten.native_batch_norm.default(convolution_default_168, primals_596, primals_592, primals_594, primals_595, True, 0.1, 0.001);  primals_592 = None
        getitem_311 = native_batch_norm_default_91[0]
        getitem_312 = native_batch_norm_default_91[1]
        getitem_313 = native_batch_norm_default_91[2];  native_batch_norm_default_91 = None
        relu_default_90 = torch.ops.aten.relu.default(getitem_311);  getitem_311 = None
        convolution_default_169 = torch.ops.aten.convolution.default(relu_default_90, primals_604, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 432)
        convolution_default_170 = torch.ops.aten.convolution.default(convolution_default_169, primals_605, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_92 = torch.ops.aten.native_batch_norm.default(convolution_default_170, primals_601, primals_597, primals_599, primals_600, True, 0.1, 0.001);  primals_597 = None
        getitem_314 = native_batch_norm_default_92[0]
        getitem_315 = native_batch_norm_default_92[1]
        getitem_316 = native_batch_norm_default_92[2];  native_batch_norm_default_92 = None
        constant_pad_nd_default_21 = torch.ops.aten.constant_pad_nd.default(getitem_300, [0, 1, 0, 1], -inf)
        max_pool2d_with_indices_default_19 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_21, [3, 3], [2, 2])
        getitem_317 = max_pool2d_with_indices_default_19[0]
        getitem_318 = max_pool2d_with_indices_default_19[1];  max_pool2d_with_indices_default_19 = None
        add_tensor_32 = torch.ops.aten.add.Tensor(getitem_314, getitem_317);  getitem_314 = getitem_317 = None
        relu_default_91 = torch.ops.aten.relu.default(getitem_300)
        constant_pad_nd_default_22 = torch.ops.aten.constant_pad_nd.default(relu_default_91, [1, 2, 1, 2], 0.0)
        convolution_default_171 = torch.ops.aten.convolution.default(constant_pad_nd_default_22, primals_616, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 432)
        convolution_default_172 = torch.ops.aten.convolution.default(convolution_default_171, primals_617, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_93 = torch.ops.aten.native_batch_norm.default(convolution_default_172, primals_610, primals_606, primals_608, primals_609, True, 0.1, 0.001);  primals_606 = None
        getitem_319 = native_batch_norm_default_93[0]
        getitem_320 = native_batch_norm_default_93[1]
        getitem_321 = native_batch_norm_default_93[2];  native_batch_norm_default_93 = None
        relu_default_92 = torch.ops.aten.relu.default(getitem_319);  getitem_319 = None
        convolution_default_173 = torch.ops.aten.convolution.default(relu_default_92, primals_618, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 432)
        convolution_default_174 = torch.ops.aten.convolution.default(convolution_default_173, primals_619, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_94 = torch.ops.aten.native_batch_norm.default(convolution_default_174, primals_615, primals_611, primals_613, primals_614, True, 0.1, 0.001);  primals_611 = None
        getitem_322 = native_batch_norm_default_94[0]
        getitem_323 = native_batch_norm_default_94[1]
        getitem_324 = native_batch_norm_default_94[2];  native_batch_norm_default_94 = None
        relu_default_93 = torch.ops.aten.relu.default(getitem_300)
        constant_pad_nd_default_23 = torch.ops.aten.constant_pad_nd.default(relu_default_93, [0, 1, 0, 1], 0.0)
        convolution_default_175 = torch.ops.aten.convolution.default(constant_pad_nd_default_23, primals_630, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 432)
        convolution_default_176 = torch.ops.aten.convolution.default(convolution_default_175, primals_631, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_95 = torch.ops.aten.native_batch_norm.default(convolution_default_176, primals_624, primals_620, primals_622, primals_623, True, 0.1, 0.001);  primals_620 = None
        getitem_325 = native_batch_norm_default_95[0]
        getitem_326 = native_batch_norm_default_95[1]
        getitem_327 = native_batch_norm_default_95[2];  native_batch_norm_default_95 = None
        relu_default_94 = torch.ops.aten.relu.default(getitem_325);  getitem_325 = None
        convolution_default_177 = torch.ops.aten.convolution.default(relu_default_94, primals_632, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_178 = torch.ops.aten.convolution.default(convolution_default_177, primals_633, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_96 = torch.ops.aten.native_batch_norm.default(convolution_default_178, primals_629, primals_625, primals_627, primals_628, True, 0.1, 0.001);  primals_625 = None
        getitem_328 = native_batch_norm_default_96[0]
        getitem_329 = native_batch_norm_default_96[1]
        getitem_330 = native_batch_norm_default_96[2];  native_batch_norm_default_96 = None
        add_tensor_33 = torch.ops.aten.add.Tensor(getitem_322, getitem_328);  getitem_322 = getitem_328 = None
        relu_default_95 = torch.ops.aten.relu.default(add_tensor_33)
        convolution_default_179 = torch.ops.aten.convolution.default(relu_default_95, primals_644, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_180 = torch.ops.aten.convolution.default(convolution_default_179, primals_645, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_97 = torch.ops.aten.native_batch_norm.default(convolution_default_180, primals_638, primals_634, primals_636, primals_637, True, 0.1, 0.001);  primals_634 = None
        getitem_331 = native_batch_norm_default_97[0]
        getitem_332 = native_batch_norm_default_97[1]
        getitem_333 = native_batch_norm_default_97[2];  native_batch_norm_default_97 = None
        relu_default_96 = torch.ops.aten.relu.default(getitem_331);  getitem_331 = None
        convolution_default_181 = torch.ops.aten.convolution.default(relu_default_96, primals_646, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_182 = torch.ops.aten.convolution.default(convolution_default_181, primals_647, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_98 = torch.ops.aten.native_batch_norm.default(convolution_default_182, primals_643, primals_639, primals_641, primals_642, True, 0.1, 0.001);  primals_639 = None
        getitem_334 = native_batch_norm_default_98[0]
        getitem_335 = native_batch_norm_default_98[1]
        getitem_336 = native_batch_norm_default_98[2];  native_batch_norm_default_98 = None
        constant_pad_nd_default_24 = torch.ops.aten.constant_pad_nd.default(getitem_300, [0, 1, 0, 1], -inf)
        max_pool2d_with_indices_default_20 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_24, [3, 3], [2, 2])
        getitem_337 = max_pool2d_with_indices_default_20[0]
        getitem_338 = max_pool2d_with_indices_default_20[1];  max_pool2d_with_indices_default_20 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(getitem_334, getitem_337);  getitem_334 = getitem_337 = None
        relu_default_97 = torch.ops.aten.relu.default(getitem_297);  getitem_297 = None
        constant_pad_nd_default_25 = torch.ops.aten.constant_pad_nd.default(relu_default_97, [0, 1, 0, 1], 0.0)
        convolution_default_183 = torch.ops.aten.convolution.default(constant_pad_nd_default_25, primals_658, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 432)
        convolution_default_184 = torch.ops.aten.convolution.default(convolution_default_183, primals_659, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_99 = torch.ops.aten.native_batch_norm.default(convolution_default_184, primals_652, primals_648, primals_650, primals_651, True, 0.1, 0.001);  primals_648 = None
        getitem_339 = native_batch_norm_default_99[0]
        getitem_340 = native_batch_norm_default_99[1]
        getitem_341 = native_batch_norm_default_99[2];  native_batch_norm_default_99 = None
        relu_default_98 = torch.ops.aten.relu.default(getitem_339);  getitem_339 = None
        convolution_default_185 = torch.ops.aten.convolution.default(relu_default_98, primals_660, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_186 = torch.ops.aten.convolution.default(convolution_default_185, primals_661, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_100 = torch.ops.aten.native_batch_norm.default(convolution_default_186, primals_657, primals_653, primals_655, primals_656, True, 0.1, 0.001);  primals_653 = None
        getitem_342 = native_batch_norm_default_100[0]
        getitem_343 = native_batch_norm_default_100[1]
        getitem_344 = native_batch_norm_default_100[2];  native_batch_norm_default_100 = None
        relu_default_99 = torch.ops.aten.relu.default(getitem_300);  getitem_300 = None
        convolution_default_187 = torch.ops.aten.convolution.default(relu_default_99, primals_667, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_101 = torch.ops.aten.native_batch_norm.default(convolution_default_187, primals_666, primals_662, primals_664, primals_665, True, 0.1, 0.001);  primals_662 = None
        getitem_345 = native_batch_norm_default_101[0]
        getitem_346 = native_batch_norm_default_101[1]
        getitem_347 = native_batch_norm_default_101[2];  native_batch_norm_default_101 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(getitem_342, getitem_345);  getitem_342 = getitem_345 = None
        cat_default_8 = torch.ops.aten.cat.default([add_tensor_31, add_tensor_32, add_tensor_33, add_tensor_34, add_tensor_35], 1);  add_tensor_31 = add_tensor_32 = add_tensor_33 = add_tensor_34 = add_tensor_35 = None
        relu_default_100 = torch.ops.aten.relu.default(cat_default_7);  cat_default_7 = None
        avg_pool2d_default_4 = torch.ops.aten.avg_pool2d.default(relu_default_100, [1, 1], [2, 2], [0, 0], False, False)
        convolution_default_188 = torch.ops.aten.convolution.default(avg_pool2d_default_4, primals_775, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        constant_pad_nd_default_26 = torch.ops.aten.constant_pad_nd.default(relu_default_100, [-1, 1, -1, 1], 0.0)
        avg_pool2d_default_5 = torch.ops.aten.avg_pool2d.default(constant_pad_nd_default_26, [1, 1], [2, 2], [0, 0], False, False)
        convolution_default_189 = torch.ops.aten.convolution.default(avg_pool2d_default_5, primals_776, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_9 = torch.ops.aten.cat.default([convolution_default_188, convolution_default_189], 1);  convolution_default_188 = convolution_default_189 = None
        native_batch_norm_default_102 = torch.ops.aten.native_batch_norm.default(cat_default_9, primals_774, primals_770, primals_772, primals_773, True, 0.1, 0.001);  primals_770 = None
        getitem_348 = native_batch_norm_default_102[0]
        getitem_349 = native_batch_norm_default_102[1]
        getitem_350 = native_batch_norm_default_102[2];  native_batch_norm_default_102 = None
        relu_default_101 = torch.ops.aten.relu.default(cat_default_8)
        convolution_default_190 = torch.ops.aten.convolution.default(relu_default_101, primals_769, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_103 = torch.ops.aten.native_batch_norm.default(convolution_default_190, primals_768, primals_764, primals_766, primals_767, True, 0.1, 0.001);  primals_764 = None
        getitem_351 = native_batch_norm_default_103[0]
        getitem_352 = native_batch_norm_default_103[1]
        getitem_353 = native_batch_norm_default_103[2];  native_batch_norm_default_103 = None
        relu_default_102 = torch.ops.aten.relu.default(getitem_348)
        convolution_default_191 = torch.ops.aten.convolution.default(relu_default_102, primals_690, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 432)
        convolution_default_192 = torch.ops.aten.convolution.default(convolution_default_191, primals_691, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_104 = torch.ops.aten.native_batch_norm.default(convolution_default_192, primals_684, primals_680, primals_682, primals_683, True, 0.1, 0.001);  primals_680 = None
        getitem_354 = native_batch_norm_default_104[0]
        getitem_355 = native_batch_norm_default_104[1]
        getitem_356 = native_batch_norm_default_104[2];  native_batch_norm_default_104 = None
        relu_default_103 = torch.ops.aten.relu.default(getitem_354);  getitem_354 = None
        convolution_default_193 = torch.ops.aten.convolution.default(relu_default_103, primals_692, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 432)
        convolution_default_194 = torch.ops.aten.convolution.default(convolution_default_193, primals_693, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_105 = torch.ops.aten.native_batch_norm.default(convolution_default_194, primals_689, primals_685, primals_687, primals_688, True, 0.1, 0.001);  primals_685 = None
        getitem_357 = native_batch_norm_default_105[0]
        getitem_358 = native_batch_norm_default_105[1]
        getitem_359 = native_batch_norm_default_105[2];  native_batch_norm_default_105 = None
        max_pool2d_with_indices_default_21 = torch.ops.aten.max_pool2d_with_indices.default(getitem_348, [3, 3], [1, 1], [1, 1])
        getitem_360 = max_pool2d_with_indices_default_21[0]
        getitem_361 = max_pool2d_with_indices_default_21[1];  max_pool2d_with_indices_default_21 = None
        add_tensor_36 = torch.ops.aten.add.Tensor(getitem_357, getitem_360);  getitem_357 = getitem_360 = None
        relu_default_104 = torch.ops.aten.relu.default(getitem_351)
        convolution_default_195 = torch.ops.aten.convolution.default(relu_default_104, primals_704, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 432)
        convolution_default_196 = torch.ops.aten.convolution.default(convolution_default_195, primals_705, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_106 = torch.ops.aten.native_batch_norm.default(convolution_default_196, primals_698, primals_694, primals_696, primals_697, True, 0.1, 0.001);  primals_694 = None
        getitem_362 = native_batch_norm_default_106[0]
        getitem_363 = native_batch_norm_default_106[1]
        getitem_364 = native_batch_norm_default_106[2];  native_batch_norm_default_106 = None
        relu_default_105 = torch.ops.aten.relu.default(getitem_362);  getitem_362 = None
        convolution_default_197 = torch.ops.aten.convolution.default(relu_default_105, primals_706, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 432)
        convolution_default_198 = torch.ops.aten.convolution.default(convolution_default_197, primals_707, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_107 = torch.ops.aten.native_batch_norm.default(convolution_default_198, primals_703, primals_699, primals_701, primals_702, True, 0.1, 0.001);  primals_699 = None
        getitem_365 = native_batch_norm_default_107[0]
        getitem_366 = native_batch_norm_default_107[1]
        getitem_367 = native_batch_norm_default_107[2];  native_batch_norm_default_107 = None
        max_pool2d_with_indices_default_22 = torch.ops.aten.max_pool2d_with_indices.default(getitem_351, [3, 3], [1, 1], [1, 1])
        getitem_368 = max_pool2d_with_indices_default_22[0]
        getitem_369 = max_pool2d_with_indices_default_22[1];  max_pool2d_with_indices_default_22 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(getitem_365, getitem_368);  getitem_365 = getitem_368 = None
        relu_default_106 = torch.ops.aten.relu.default(getitem_351)
        convolution_default_199 = torch.ops.aten.convolution.default(relu_default_106, primals_718, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 432)
        convolution_default_200 = torch.ops.aten.convolution.default(convolution_default_199, primals_719, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_108 = torch.ops.aten.native_batch_norm.default(convolution_default_200, primals_712, primals_708, primals_710, primals_711, True, 0.1, 0.001);  primals_708 = None
        getitem_370 = native_batch_norm_default_108[0]
        getitem_371 = native_batch_norm_default_108[1]
        getitem_372 = native_batch_norm_default_108[2];  native_batch_norm_default_108 = None
        relu_default_107 = torch.ops.aten.relu.default(getitem_370);  getitem_370 = None
        convolution_default_201 = torch.ops.aten.convolution.default(relu_default_107, primals_720, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 432)
        convolution_default_202 = torch.ops.aten.convolution.default(convolution_default_201, primals_721, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_109 = torch.ops.aten.native_batch_norm.default(convolution_default_202, primals_717, primals_713, primals_715, primals_716, True, 0.1, 0.001);  primals_713 = None
        getitem_373 = native_batch_norm_default_109[0]
        getitem_374 = native_batch_norm_default_109[1]
        getitem_375 = native_batch_norm_default_109[2];  native_batch_norm_default_109 = None
        relu_default_108 = torch.ops.aten.relu.default(getitem_351)
        convolution_default_203 = torch.ops.aten.convolution.default(relu_default_108, primals_732, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_204 = torch.ops.aten.convolution.default(convolution_default_203, primals_733, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_110 = torch.ops.aten.native_batch_norm.default(convolution_default_204, primals_726, primals_722, primals_724, primals_725, True, 0.1, 0.001);  primals_722 = None
        getitem_376 = native_batch_norm_default_110[0]
        getitem_377 = native_batch_norm_default_110[1]
        getitem_378 = native_batch_norm_default_110[2];  native_batch_norm_default_110 = None
        relu_default_109 = torch.ops.aten.relu.default(getitem_376);  getitem_376 = None
        convolution_default_205 = torch.ops.aten.convolution.default(relu_default_109, primals_734, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_206 = torch.ops.aten.convolution.default(convolution_default_205, primals_735, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_111 = torch.ops.aten.native_batch_norm.default(convolution_default_206, primals_731, primals_727, primals_729, primals_730, True, 0.1, 0.001);  primals_727 = None
        getitem_379 = native_batch_norm_default_111[0]
        getitem_380 = native_batch_norm_default_111[1]
        getitem_381 = native_batch_norm_default_111[2];  native_batch_norm_default_111 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(getitem_373, getitem_379);  getitem_373 = getitem_379 = None
        relu_default_110 = torch.ops.aten.relu.default(add_tensor_38)
        convolution_default_207 = torch.ops.aten.convolution.default(relu_default_110, primals_746, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_208 = torch.ops.aten.convolution.default(convolution_default_207, primals_747, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_112 = torch.ops.aten.native_batch_norm.default(convolution_default_208, primals_740, primals_736, primals_738, primals_739, True, 0.1, 0.001);  primals_736 = None
        getitem_382 = native_batch_norm_default_112[0]
        getitem_383 = native_batch_norm_default_112[1]
        getitem_384 = native_batch_norm_default_112[2];  native_batch_norm_default_112 = None
        relu_default_111 = torch.ops.aten.relu.default(getitem_382);  getitem_382 = None
        convolution_default_209 = torch.ops.aten.convolution.default(relu_default_111, primals_748, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_210 = torch.ops.aten.convolution.default(convolution_default_209, primals_749, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_113 = torch.ops.aten.native_batch_norm.default(convolution_default_210, primals_745, primals_741, primals_743, primals_744, True, 0.1, 0.001);  primals_741 = None
        getitem_385 = native_batch_norm_default_113[0]
        getitem_386 = native_batch_norm_default_113[1]
        getitem_387 = native_batch_norm_default_113[2];  native_batch_norm_default_113 = None
        max_pool2d_with_indices_default_23 = torch.ops.aten.max_pool2d_with_indices.default(getitem_351, [3, 3], [1, 1], [1, 1])
        getitem_388 = max_pool2d_with_indices_default_23[0]
        getitem_389 = max_pool2d_with_indices_default_23[1];  max_pool2d_with_indices_default_23 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(getitem_385, getitem_388);  getitem_385 = getitem_388 = None
        relu_default_112 = torch.ops.aten.relu.default(getitem_348)
        convolution_default_211 = torch.ops.aten.convolution.default(relu_default_112, primals_760, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_212 = torch.ops.aten.convolution.default(convolution_default_211, primals_761, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_114 = torch.ops.aten.native_batch_norm.default(convolution_default_212, primals_754, primals_750, primals_752, primals_753, True, 0.1, 0.001);  primals_750 = None
        getitem_390 = native_batch_norm_default_114[0]
        getitem_391 = native_batch_norm_default_114[1]
        getitem_392 = native_batch_norm_default_114[2];  native_batch_norm_default_114 = None
        relu_default_113 = torch.ops.aten.relu.default(getitem_390);  getitem_390 = None
        convolution_default_213 = torch.ops.aten.convolution.default(relu_default_113, primals_762, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_214 = torch.ops.aten.convolution.default(convolution_default_213, primals_763, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_115 = torch.ops.aten.native_batch_norm.default(convolution_default_214, primals_759, primals_755, primals_757, primals_758, True, 0.1, 0.001);  primals_755 = None
        getitem_393 = native_batch_norm_default_115[0]
        getitem_394 = native_batch_norm_default_115[1]
        getitem_395 = native_batch_norm_default_115[2];  native_batch_norm_default_115 = None
        add_tensor_40 = torch.ops.aten.add.Tensor(getitem_393, getitem_351);  getitem_393 = None
        cat_default_10 = torch.ops.aten.cat.default([add_tensor_36, add_tensor_37, add_tensor_38, add_tensor_39, add_tensor_40], 1);  add_tensor_36 = add_tensor_37 = add_tensor_38 = add_tensor_39 = add_tensor_40 = None
        relu_default_114 = torch.ops.aten.relu.default(cat_default_8);  cat_default_8 = None
        convolution_default_215 = torch.ops.aten.convolution.default(relu_default_114, primals_872, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_116 = torch.ops.aten.native_batch_norm.default(convolution_default_215, primals_871, primals_867, primals_869, primals_870, True, 0.1, 0.001);  primals_867 = None
        getitem_396 = native_batch_norm_default_116[0]
        getitem_397 = native_batch_norm_default_116[1]
        getitem_398 = native_batch_norm_default_116[2];  native_batch_norm_default_116 = None
        relu_default_115 = torch.ops.aten.relu.default(cat_default_10)
        convolution_default_216 = torch.ops.aten.convolution.default(relu_default_115, primals_866, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_117 = torch.ops.aten.native_batch_norm.default(convolution_default_216, primals_865, primals_861, primals_863, primals_864, True, 0.1, 0.001);  primals_861 = None
        getitem_399 = native_batch_norm_default_117[0]
        getitem_400 = native_batch_norm_default_117[1]
        getitem_401 = native_batch_norm_default_117[2];  native_batch_norm_default_117 = None
        relu_default_116 = torch.ops.aten.relu.default(getitem_396)
        convolution_default_217 = torch.ops.aten.convolution.default(relu_default_116, primals_787, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 432)
        convolution_default_218 = torch.ops.aten.convolution.default(convolution_default_217, primals_788, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_118 = torch.ops.aten.native_batch_norm.default(convolution_default_218, primals_781, primals_777, primals_779, primals_780, True, 0.1, 0.001);  primals_777 = None
        getitem_402 = native_batch_norm_default_118[0]
        getitem_403 = native_batch_norm_default_118[1]
        getitem_404 = native_batch_norm_default_118[2];  native_batch_norm_default_118 = None
        relu_default_117 = torch.ops.aten.relu.default(getitem_402);  getitem_402 = None
        convolution_default_219 = torch.ops.aten.convolution.default(relu_default_117, primals_789, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 432)
        convolution_default_220 = torch.ops.aten.convolution.default(convolution_default_219, primals_790, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_119 = torch.ops.aten.native_batch_norm.default(convolution_default_220, primals_786, primals_782, primals_784, primals_785, True, 0.1, 0.001);  primals_782 = None
        getitem_405 = native_batch_norm_default_119[0]
        getitem_406 = native_batch_norm_default_119[1]
        getitem_407 = native_batch_norm_default_119[2];  native_batch_norm_default_119 = None
        max_pool2d_with_indices_default_24 = torch.ops.aten.max_pool2d_with_indices.default(getitem_396, [3, 3], [1, 1], [1, 1])
        getitem_408 = max_pool2d_with_indices_default_24[0]
        getitem_409 = max_pool2d_with_indices_default_24[1];  max_pool2d_with_indices_default_24 = None
        add_tensor_41 = torch.ops.aten.add.Tensor(getitem_405, getitem_408);  getitem_405 = getitem_408 = None
        relu_default_118 = torch.ops.aten.relu.default(getitem_399)
        convolution_default_221 = torch.ops.aten.convolution.default(relu_default_118, primals_801, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 432)
        convolution_default_222 = torch.ops.aten.convolution.default(convolution_default_221, primals_802, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_120 = torch.ops.aten.native_batch_norm.default(convolution_default_222, primals_795, primals_791, primals_793, primals_794, True, 0.1, 0.001);  primals_791 = None
        getitem_410 = native_batch_norm_default_120[0]
        getitem_411 = native_batch_norm_default_120[1]
        getitem_412 = native_batch_norm_default_120[2];  native_batch_norm_default_120 = None
        relu_default_119 = torch.ops.aten.relu.default(getitem_410);  getitem_410 = None
        convolution_default_223 = torch.ops.aten.convolution.default(relu_default_119, primals_803, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 432)
        convolution_default_224 = torch.ops.aten.convolution.default(convolution_default_223, primals_804, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_121 = torch.ops.aten.native_batch_norm.default(convolution_default_224, primals_800, primals_796, primals_798, primals_799, True, 0.1, 0.001);  primals_796 = None
        getitem_413 = native_batch_norm_default_121[0]
        getitem_414 = native_batch_norm_default_121[1]
        getitem_415 = native_batch_norm_default_121[2];  native_batch_norm_default_121 = None
        max_pool2d_with_indices_default_25 = torch.ops.aten.max_pool2d_with_indices.default(getitem_399, [3, 3], [1, 1], [1, 1])
        getitem_416 = max_pool2d_with_indices_default_25[0]
        getitem_417 = max_pool2d_with_indices_default_25[1];  max_pool2d_with_indices_default_25 = None
        add_tensor_42 = torch.ops.aten.add.Tensor(getitem_413, getitem_416);  getitem_413 = getitem_416 = None
        relu_default_120 = torch.ops.aten.relu.default(getitem_399)
        convolution_default_225 = torch.ops.aten.convolution.default(relu_default_120, primals_815, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 432)
        convolution_default_226 = torch.ops.aten.convolution.default(convolution_default_225, primals_816, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_122 = torch.ops.aten.native_batch_norm.default(convolution_default_226, primals_809, primals_805, primals_807, primals_808, True, 0.1, 0.001);  primals_805 = None
        getitem_418 = native_batch_norm_default_122[0]
        getitem_419 = native_batch_norm_default_122[1]
        getitem_420 = native_batch_norm_default_122[2];  native_batch_norm_default_122 = None
        relu_default_121 = torch.ops.aten.relu.default(getitem_418);  getitem_418 = None
        convolution_default_227 = torch.ops.aten.convolution.default(relu_default_121, primals_817, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 432)
        convolution_default_228 = torch.ops.aten.convolution.default(convolution_default_227, primals_818, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_123 = torch.ops.aten.native_batch_norm.default(convolution_default_228, primals_814, primals_810, primals_812, primals_813, True, 0.1, 0.001);  primals_810 = None
        getitem_421 = native_batch_norm_default_123[0]
        getitem_422 = native_batch_norm_default_123[1]
        getitem_423 = native_batch_norm_default_123[2];  native_batch_norm_default_123 = None
        relu_default_122 = torch.ops.aten.relu.default(getitem_399)
        convolution_default_229 = torch.ops.aten.convolution.default(relu_default_122, primals_829, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_230 = torch.ops.aten.convolution.default(convolution_default_229, primals_830, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_124 = torch.ops.aten.native_batch_norm.default(convolution_default_230, primals_823, primals_819, primals_821, primals_822, True, 0.1, 0.001);  primals_819 = None
        getitem_424 = native_batch_norm_default_124[0]
        getitem_425 = native_batch_norm_default_124[1]
        getitem_426 = native_batch_norm_default_124[2];  native_batch_norm_default_124 = None
        relu_default_123 = torch.ops.aten.relu.default(getitem_424);  getitem_424 = None
        convolution_default_231 = torch.ops.aten.convolution.default(relu_default_123, primals_831, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_232 = torch.ops.aten.convolution.default(convolution_default_231, primals_832, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_125 = torch.ops.aten.native_batch_norm.default(convolution_default_232, primals_828, primals_824, primals_826, primals_827, True, 0.1, 0.001);  primals_824 = None
        getitem_427 = native_batch_norm_default_125[0]
        getitem_428 = native_batch_norm_default_125[1]
        getitem_429 = native_batch_norm_default_125[2];  native_batch_norm_default_125 = None
        add_tensor_43 = torch.ops.aten.add.Tensor(getitem_421, getitem_427);  getitem_421 = getitem_427 = None
        relu_default_124 = torch.ops.aten.relu.default(add_tensor_43)
        convolution_default_233 = torch.ops.aten.convolution.default(relu_default_124, primals_843, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_234 = torch.ops.aten.convolution.default(convolution_default_233, primals_844, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_126 = torch.ops.aten.native_batch_norm.default(convolution_default_234, primals_837, primals_833, primals_835, primals_836, True, 0.1, 0.001);  primals_833 = None
        getitem_430 = native_batch_norm_default_126[0]
        getitem_431 = native_batch_norm_default_126[1]
        getitem_432 = native_batch_norm_default_126[2];  native_batch_norm_default_126 = None
        relu_default_125 = torch.ops.aten.relu.default(getitem_430);  getitem_430 = None
        convolution_default_235 = torch.ops.aten.convolution.default(relu_default_125, primals_845, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_236 = torch.ops.aten.convolution.default(convolution_default_235, primals_846, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_127 = torch.ops.aten.native_batch_norm.default(convolution_default_236, primals_842, primals_838, primals_840, primals_841, True, 0.1, 0.001);  primals_838 = None
        getitem_433 = native_batch_norm_default_127[0]
        getitem_434 = native_batch_norm_default_127[1]
        getitem_435 = native_batch_norm_default_127[2];  native_batch_norm_default_127 = None
        max_pool2d_with_indices_default_26 = torch.ops.aten.max_pool2d_with_indices.default(getitem_399, [3, 3], [1, 1], [1, 1])
        getitem_436 = max_pool2d_with_indices_default_26[0]
        getitem_437 = max_pool2d_with_indices_default_26[1];  max_pool2d_with_indices_default_26 = None
        add_tensor_44 = torch.ops.aten.add.Tensor(getitem_433, getitem_436);  getitem_433 = getitem_436 = None
        relu_default_126 = torch.ops.aten.relu.default(getitem_396)
        convolution_default_237 = torch.ops.aten.convolution.default(relu_default_126, primals_857, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_238 = torch.ops.aten.convolution.default(convolution_default_237, primals_858, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_128 = torch.ops.aten.native_batch_norm.default(convolution_default_238, primals_851, primals_847, primals_849, primals_850, True, 0.1, 0.001);  primals_847 = None
        getitem_438 = native_batch_norm_default_128[0]
        getitem_439 = native_batch_norm_default_128[1]
        getitem_440 = native_batch_norm_default_128[2];  native_batch_norm_default_128 = None
        relu_default_127 = torch.ops.aten.relu.default(getitem_438);  getitem_438 = None
        convolution_default_239 = torch.ops.aten.convolution.default(relu_default_127, primals_859, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_240 = torch.ops.aten.convolution.default(convolution_default_239, primals_860, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_129 = torch.ops.aten.native_batch_norm.default(convolution_default_240, primals_856, primals_852, primals_854, primals_855, True, 0.1, 0.001);  primals_852 = None
        getitem_441 = native_batch_norm_default_129[0]
        getitem_442 = native_batch_norm_default_129[1]
        getitem_443 = native_batch_norm_default_129[2];  native_batch_norm_default_129 = None
        add_tensor_45 = torch.ops.aten.add.Tensor(getitem_441, getitem_399);  getitem_441 = None
        cat_default_11 = torch.ops.aten.cat.default([add_tensor_41, add_tensor_42, add_tensor_43, add_tensor_44, add_tensor_45], 1);  add_tensor_41 = add_tensor_42 = add_tensor_43 = add_tensor_44 = add_tensor_45 = None
        relu_default_128 = torch.ops.aten.relu.default(cat_default_10);  cat_default_10 = None
        convolution_default_241 = torch.ops.aten.convolution.default(relu_default_128, primals_968, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_130 = torch.ops.aten.native_batch_norm.default(convolution_default_241, primals_967, primals_963, primals_965, primals_966, True, 0.1, 0.001);  primals_963 = None
        getitem_444 = native_batch_norm_default_130[0]
        getitem_445 = native_batch_norm_default_130[1]
        getitem_446 = native_batch_norm_default_130[2];  native_batch_norm_default_130 = None
        relu_default_129 = torch.ops.aten.relu.default(cat_default_11)
        convolution_default_242 = torch.ops.aten.convolution.default(relu_default_129, primals_962, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_131 = torch.ops.aten.native_batch_norm.default(convolution_default_242, primals_961, primals_957, primals_959, primals_960, True, 0.1, 0.001);  primals_957 = None
        getitem_447 = native_batch_norm_default_131[0]
        getitem_448 = native_batch_norm_default_131[1]
        getitem_449 = native_batch_norm_default_131[2];  native_batch_norm_default_131 = None
        relu_default_130 = torch.ops.aten.relu.default(getitem_444)
        convolution_default_243 = torch.ops.aten.convolution.default(relu_default_130, primals_883, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 432)
        convolution_default_244 = torch.ops.aten.convolution.default(convolution_default_243, primals_884, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_132 = torch.ops.aten.native_batch_norm.default(convolution_default_244, primals_877, primals_873, primals_875, primals_876, True, 0.1, 0.001);  primals_873 = None
        getitem_450 = native_batch_norm_default_132[0]
        getitem_451 = native_batch_norm_default_132[1]
        getitem_452 = native_batch_norm_default_132[2];  native_batch_norm_default_132 = None
        relu_default_131 = torch.ops.aten.relu.default(getitem_450);  getitem_450 = None
        convolution_default_245 = torch.ops.aten.convolution.default(relu_default_131, primals_885, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 432)
        convolution_default_246 = torch.ops.aten.convolution.default(convolution_default_245, primals_886, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_133 = torch.ops.aten.native_batch_norm.default(convolution_default_246, primals_882, primals_878, primals_880, primals_881, True, 0.1, 0.001);  primals_878 = None
        getitem_453 = native_batch_norm_default_133[0]
        getitem_454 = native_batch_norm_default_133[1]
        getitem_455 = native_batch_norm_default_133[2];  native_batch_norm_default_133 = None
        max_pool2d_with_indices_default_27 = torch.ops.aten.max_pool2d_with_indices.default(getitem_444, [3, 3], [1, 1], [1, 1])
        getitem_456 = max_pool2d_with_indices_default_27[0]
        getitem_457 = max_pool2d_with_indices_default_27[1];  max_pool2d_with_indices_default_27 = None
        add_tensor_46 = torch.ops.aten.add.Tensor(getitem_453, getitem_456);  getitem_453 = getitem_456 = None
        relu_default_132 = torch.ops.aten.relu.default(getitem_447)
        convolution_default_247 = torch.ops.aten.convolution.default(relu_default_132, primals_897, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 432)
        convolution_default_248 = torch.ops.aten.convolution.default(convolution_default_247, primals_898, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_134 = torch.ops.aten.native_batch_norm.default(convolution_default_248, primals_891, primals_887, primals_889, primals_890, True, 0.1, 0.001);  primals_887 = None
        getitem_458 = native_batch_norm_default_134[0]
        getitem_459 = native_batch_norm_default_134[1]
        getitem_460 = native_batch_norm_default_134[2];  native_batch_norm_default_134 = None
        relu_default_133 = torch.ops.aten.relu.default(getitem_458);  getitem_458 = None
        convolution_default_249 = torch.ops.aten.convolution.default(relu_default_133, primals_899, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 432)
        convolution_default_250 = torch.ops.aten.convolution.default(convolution_default_249, primals_900, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_135 = torch.ops.aten.native_batch_norm.default(convolution_default_250, primals_896, primals_892, primals_894, primals_895, True, 0.1, 0.001);  primals_892 = None
        getitem_461 = native_batch_norm_default_135[0]
        getitem_462 = native_batch_norm_default_135[1]
        getitem_463 = native_batch_norm_default_135[2];  native_batch_norm_default_135 = None
        max_pool2d_with_indices_default_28 = torch.ops.aten.max_pool2d_with_indices.default(getitem_447, [3, 3], [1, 1], [1, 1])
        getitem_464 = max_pool2d_with_indices_default_28[0]
        getitem_465 = max_pool2d_with_indices_default_28[1];  max_pool2d_with_indices_default_28 = None
        add_tensor_47 = torch.ops.aten.add.Tensor(getitem_461, getitem_464);  getitem_461 = getitem_464 = None
        relu_default_134 = torch.ops.aten.relu.default(getitem_447)
        convolution_default_251 = torch.ops.aten.convolution.default(relu_default_134, primals_911, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 432)
        convolution_default_252 = torch.ops.aten.convolution.default(convolution_default_251, primals_912, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_136 = torch.ops.aten.native_batch_norm.default(convolution_default_252, primals_905, primals_901, primals_903, primals_904, True, 0.1, 0.001);  primals_901 = None
        getitem_466 = native_batch_norm_default_136[0]
        getitem_467 = native_batch_norm_default_136[1]
        getitem_468 = native_batch_norm_default_136[2];  native_batch_norm_default_136 = None
        relu_default_135 = torch.ops.aten.relu.default(getitem_466);  getitem_466 = None
        convolution_default_253 = torch.ops.aten.convolution.default(relu_default_135, primals_913, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 432)
        convolution_default_254 = torch.ops.aten.convolution.default(convolution_default_253, primals_914, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_137 = torch.ops.aten.native_batch_norm.default(convolution_default_254, primals_910, primals_906, primals_908, primals_909, True, 0.1, 0.001);  primals_906 = None
        getitem_469 = native_batch_norm_default_137[0]
        getitem_470 = native_batch_norm_default_137[1]
        getitem_471 = native_batch_norm_default_137[2];  native_batch_norm_default_137 = None
        relu_default_136 = torch.ops.aten.relu.default(getitem_447)
        convolution_default_255 = torch.ops.aten.convolution.default(relu_default_136, primals_925, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_256 = torch.ops.aten.convolution.default(convolution_default_255, primals_926, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_138 = torch.ops.aten.native_batch_norm.default(convolution_default_256, primals_919, primals_915, primals_917, primals_918, True, 0.1, 0.001);  primals_915 = None
        getitem_472 = native_batch_norm_default_138[0]
        getitem_473 = native_batch_norm_default_138[1]
        getitem_474 = native_batch_norm_default_138[2];  native_batch_norm_default_138 = None
        relu_default_137 = torch.ops.aten.relu.default(getitem_472);  getitem_472 = None
        convolution_default_257 = torch.ops.aten.convolution.default(relu_default_137, primals_927, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_258 = torch.ops.aten.convolution.default(convolution_default_257, primals_928, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_139 = torch.ops.aten.native_batch_norm.default(convolution_default_258, primals_924, primals_920, primals_922, primals_923, True, 0.1, 0.001);  primals_920 = None
        getitem_475 = native_batch_norm_default_139[0]
        getitem_476 = native_batch_norm_default_139[1]
        getitem_477 = native_batch_norm_default_139[2];  native_batch_norm_default_139 = None
        add_tensor_48 = torch.ops.aten.add.Tensor(getitem_469, getitem_475);  getitem_469 = getitem_475 = None
        relu_default_138 = torch.ops.aten.relu.default(add_tensor_48)
        convolution_default_259 = torch.ops.aten.convolution.default(relu_default_138, primals_939, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_260 = torch.ops.aten.convolution.default(convolution_default_259, primals_940, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_140 = torch.ops.aten.native_batch_norm.default(convolution_default_260, primals_933, primals_929, primals_931, primals_932, True, 0.1, 0.001);  primals_929 = None
        getitem_478 = native_batch_norm_default_140[0]
        getitem_479 = native_batch_norm_default_140[1]
        getitem_480 = native_batch_norm_default_140[2];  native_batch_norm_default_140 = None
        relu_default_139 = torch.ops.aten.relu.default(getitem_478);  getitem_478 = None
        convolution_default_261 = torch.ops.aten.convolution.default(relu_default_139, primals_941, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_262 = torch.ops.aten.convolution.default(convolution_default_261, primals_942, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_141 = torch.ops.aten.native_batch_norm.default(convolution_default_262, primals_938, primals_934, primals_936, primals_937, True, 0.1, 0.001);  primals_934 = None
        getitem_481 = native_batch_norm_default_141[0]
        getitem_482 = native_batch_norm_default_141[1]
        getitem_483 = native_batch_norm_default_141[2];  native_batch_norm_default_141 = None
        max_pool2d_with_indices_default_29 = torch.ops.aten.max_pool2d_with_indices.default(getitem_447, [3, 3], [1, 1], [1, 1])
        getitem_484 = max_pool2d_with_indices_default_29[0]
        getitem_485 = max_pool2d_with_indices_default_29[1];  max_pool2d_with_indices_default_29 = None
        add_tensor_49 = torch.ops.aten.add.Tensor(getitem_481, getitem_484);  getitem_481 = getitem_484 = None
        relu_default_140 = torch.ops.aten.relu.default(getitem_444)
        convolution_default_263 = torch.ops.aten.convolution.default(relu_default_140, primals_953, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_264 = torch.ops.aten.convolution.default(convolution_default_263, primals_954, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_142 = torch.ops.aten.native_batch_norm.default(convolution_default_264, primals_947, primals_943, primals_945, primals_946, True, 0.1, 0.001);  primals_943 = None
        getitem_486 = native_batch_norm_default_142[0]
        getitem_487 = native_batch_norm_default_142[1]
        getitem_488 = native_batch_norm_default_142[2];  native_batch_norm_default_142 = None
        relu_default_141 = torch.ops.aten.relu.default(getitem_486);  getitem_486 = None
        convolution_default_265 = torch.ops.aten.convolution.default(relu_default_141, primals_955, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 432)
        convolution_default_266 = torch.ops.aten.convolution.default(convolution_default_265, primals_956, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_143 = torch.ops.aten.native_batch_norm.default(convolution_default_266, primals_952, primals_948, primals_950, primals_951, True, 0.1, 0.001);  primals_948 = None
        getitem_489 = native_batch_norm_default_143[0]
        getitem_490 = native_batch_norm_default_143[1]
        getitem_491 = native_batch_norm_default_143[2];  native_batch_norm_default_143 = None
        add_tensor_50 = torch.ops.aten.add.Tensor(getitem_489, getitem_447);  getitem_489 = None
        cat_default_12 = torch.ops.aten.cat.default([add_tensor_46, add_tensor_47, add_tensor_48, add_tensor_49, add_tensor_50], 1);  add_tensor_46 = add_tensor_47 = add_tensor_48 = add_tensor_49 = add_tensor_50 = None
        relu_default_142 = torch.ops.aten.relu.default(cat_default_11);  cat_default_11 = None
        convolution_default_267 = torch.ops.aten.convolution.default(relu_default_142, primals_1070, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_144 = torch.ops.aten.native_batch_norm.default(convolution_default_267, primals_1069, primals_1065, primals_1067, primals_1068, True, 0.1, 0.001);  primals_1065 = None
        getitem_492 = native_batch_norm_default_144[0]
        getitem_493 = native_batch_norm_default_144[1]
        getitem_494 = native_batch_norm_default_144[2];  native_batch_norm_default_144 = None
        relu_default_143 = torch.ops.aten.relu.default(cat_default_12)
        convolution_default_268 = torch.ops.aten.convolution.default(relu_default_143, primals_1064, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_145 = torch.ops.aten.native_batch_norm.default(convolution_default_268, primals_1063, primals_1059, primals_1061, primals_1062, True, 0.1, 0.001);  primals_1059 = None
        getitem_495 = native_batch_norm_default_145[0]
        getitem_496 = native_batch_norm_default_145[1]
        getitem_497 = native_batch_norm_default_145[2];  native_batch_norm_default_145 = None
        relu_default_144 = torch.ops.aten.relu.default(getitem_492)
        constant_pad_nd_default_27 = torch.ops.aten.constant_pad_nd.default(relu_default_144, [2, 2, 2, 2], 0.0)
        convolution_default_269 = torch.ops.aten.convolution.default(constant_pad_nd_default_27, primals_979, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 864)
        convolution_default_270 = torch.ops.aten.convolution.default(convolution_default_269, primals_980, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_146 = torch.ops.aten.native_batch_norm.default(convolution_default_270, primals_973, primals_969, primals_971, primals_972, True, 0.1, 0.001);  primals_969 = None
        getitem_498 = native_batch_norm_default_146[0]
        getitem_499 = native_batch_norm_default_146[1]
        getitem_500 = native_batch_norm_default_146[2];  native_batch_norm_default_146 = None
        relu_default_145 = torch.ops.aten.relu.default(getitem_498);  getitem_498 = None
        convolution_default_271 = torch.ops.aten.convolution.default(relu_default_145, primals_981, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 864)
        convolution_default_272 = torch.ops.aten.convolution.default(convolution_default_271, primals_982, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_147 = torch.ops.aten.native_batch_norm.default(convolution_default_272, primals_978, primals_974, primals_976, primals_977, True, 0.1, 0.001);  primals_974 = None
        getitem_501 = native_batch_norm_default_147[0]
        getitem_502 = native_batch_norm_default_147[1]
        getitem_503 = native_batch_norm_default_147[2];  native_batch_norm_default_147 = None
        constant_pad_nd_default_28 = torch.ops.aten.constant_pad_nd.default(getitem_492, [1, 1, 1, 1], -inf)
        max_pool2d_with_indices_default_30 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_28, [3, 3], [2, 2])
        getitem_504 = max_pool2d_with_indices_default_30[0]
        getitem_505 = max_pool2d_with_indices_default_30[1];  max_pool2d_with_indices_default_30 = None
        add_tensor_51 = torch.ops.aten.add.Tensor(getitem_501, getitem_504);  getitem_501 = getitem_504 = None
        relu_default_146 = torch.ops.aten.relu.default(getitem_495)
        constant_pad_nd_default_29 = torch.ops.aten.constant_pad_nd.default(relu_default_146, [3, 3, 3, 3], 0.0)
        convolution_default_273 = torch.ops.aten.convolution.default(constant_pad_nd_default_29, primals_993, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 864)
        convolution_default_274 = torch.ops.aten.convolution.default(convolution_default_273, primals_994, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_148 = torch.ops.aten.native_batch_norm.default(convolution_default_274, primals_987, primals_983, primals_985, primals_986, True, 0.1, 0.001);  primals_983 = None
        getitem_506 = native_batch_norm_default_148[0]
        getitem_507 = native_batch_norm_default_148[1]
        getitem_508 = native_batch_norm_default_148[2];  native_batch_norm_default_148 = None
        relu_default_147 = torch.ops.aten.relu.default(getitem_506);  getitem_506 = None
        convolution_default_275 = torch.ops.aten.convolution.default(relu_default_147, primals_995, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 864)
        convolution_default_276 = torch.ops.aten.convolution.default(convolution_default_275, primals_996, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_149 = torch.ops.aten.native_batch_norm.default(convolution_default_276, primals_992, primals_988, primals_990, primals_991, True, 0.1, 0.001);  primals_988 = None
        getitem_509 = native_batch_norm_default_149[0]
        getitem_510 = native_batch_norm_default_149[1]
        getitem_511 = native_batch_norm_default_149[2];  native_batch_norm_default_149 = None
        constant_pad_nd_default_30 = torch.ops.aten.constant_pad_nd.default(getitem_495, [1, 1, 1, 1], -inf)
        max_pool2d_with_indices_default_31 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_30, [3, 3], [2, 2])
        getitem_512 = max_pool2d_with_indices_default_31[0]
        getitem_513 = max_pool2d_with_indices_default_31[1];  max_pool2d_with_indices_default_31 = None
        add_tensor_52 = torch.ops.aten.add.Tensor(getitem_509, getitem_512);  getitem_509 = getitem_512 = None
        relu_default_148 = torch.ops.aten.relu.default(getitem_495)
        constant_pad_nd_default_31 = torch.ops.aten.constant_pad_nd.default(relu_default_148, [2, 2, 2, 2], 0.0)
        convolution_default_277 = torch.ops.aten.convolution.default(constant_pad_nd_default_31, primals_1007, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 864)
        convolution_default_278 = torch.ops.aten.convolution.default(convolution_default_277, primals_1008, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_150 = torch.ops.aten.native_batch_norm.default(convolution_default_278, primals_1001, primals_997, primals_999, primals_1000, True, 0.1, 0.001);  primals_997 = None
        getitem_514 = native_batch_norm_default_150[0]
        getitem_515 = native_batch_norm_default_150[1]
        getitem_516 = native_batch_norm_default_150[2];  native_batch_norm_default_150 = None
        relu_default_149 = torch.ops.aten.relu.default(getitem_514);  getitem_514 = None
        convolution_default_279 = torch.ops.aten.convolution.default(relu_default_149, primals_1009, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 864)
        convolution_default_280 = torch.ops.aten.convolution.default(convolution_default_279, primals_1010, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_151 = torch.ops.aten.native_batch_norm.default(convolution_default_280, primals_1006, primals_1002, primals_1004, primals_1005, True, 0.1, 0.001);  primals_1002 = None
        getitem_517 = native_batch_norm_default_151[0]
        getitem_518 = native_batch_norm_default_151[1]
        getitem_519 = native_batch_norm_default_151[2];  native_batch_norm_default_151 = None
        relu_default_150 = torch.ops.aten.relu.default(getitem_495)
        constant_pad_nd_default_32 = torch.ops.aten.constant_pad_nd.default(relu_default_150, [1, 1, 1, 1], 0.0)
        convolution_default_281 = torch.ops.aten.convolution.default(constant_pad_nd_default_32, primals_1021, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 864)
        convolution_default_282 = torch.ops.aten.convolution.default(convolution_default_281, primals_1022, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_152 = torch.ops.aten.native_batch_norm.default(convolution_default_282, primals_1015, primals_1011, primals_1013, primals_1014, True, 0.1, 0.001);  primals_1011 = None
        getitem_520 = native_batch_norm_default_152[0]
        getitem_521 = native_batch_norm_default_152[1]
        getitem_522 = native_batch_norm_default_152[2];  native_batch_norm_default_152 = None
        relu_default_151 = torch.ops.aten.relu.default(getitem_520);  getitem_520 = None
        convolution_default_283 = torch.ops.aten.convolution.default(relu_default_151, primals_1023, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_284 = torch.ops.aten.convolution.default(convolution_default_283, primals_1024, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_153 = torch.ops.aten.native_batch_norm.default(convolution_default_284, primals_1020, primals_1016, primals_1018, primals_1019, True, 0.1, 0.001);  primals_1016 = None
        getitem_523 = native_batch_norm_default_153[0]
        getitem_524 = native_batch_norm_default_153[1]
        getitem_525 = native_batch_norm_default_153[2];  native_batch_norm_default_153 = None
        add_tensor_53 = torch.ops.aten.add.Tensor(getitem_517, getitem_523);  getitem_517 = getitem_523 = None
        relu_default_152 = torch.ops.aten.relu.default(add_tensor_53)
        convolution_default_285 = torch.ops.aten.convolution.default(relu_default_152, primals_1035, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_286 = torch.ops.aten.convolution.default(convolution_default_285, primals_1036, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_154 = torch.ops.aten.native_batch_norm.default(convolution_default_286, primals_1029, primals_1025, primals_1027, primals_1028, True, 0.1, 0.001);  primals_1025 = None
        getitem_526 = native_batch_norm_default_154[0]
        getitem_527 = native_batch_norm_default_154[1]
        getitem_528 = native_batch_norm_default_154[2];  native_batch_norm_default_154 = None
        relu_default_153 = torch.ops.aten.relu.default(getitem_526);  getitem_526 = None
        convolution_default_287 = torch.ops.aten.convolution.default(relu_default_153, primals_1037, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_288 = torch.ops.aten.convolution.default(convolution_default_287, primals_1038, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_155 = torch.ops.aten.native_batch_norm.default(convolution_default_288, primals_1034, primals_1030, primals_1032, primals_1033, True, 0.1, 0.001);  primals_1030 = None
        getitem_529 = native_batch_norm_default_155[0]
        getitem_530 = native_batch_norm_default_155[1]
        getitem_531 = native_batch_norm_default_155[2];  native_batch_norm_default_155 = None
        constant_pad_nd_default_33 = torch.ops.aten.constant_pad_nd.default(getitem_495, [1, 1, 1, 1], -inf)
        max_pool2d_with_indices_default_32 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_33, [3, 3], [2, 2])
        getitem_532 = max_pool2d_with_indices_default_32[0]
        getitem_533 = max_pool2d_with_indices_default_32[1];  max_pool2d_with_indices_default_32 = None
        add_tensor_54 = torch.ops.aten.add.Tensor(getitem_529, getitem_532);  getitem_529 = getitem_532 = None
        relu_default_154 = torch.ops.aten.relu.default(getitem_492);  getitem_492 = None
        constant_pad_nd_default_34 = torch.ops.aten.constant_pad_nd.default(relu_default_154, [1, 1, 1, 1], 0.0)
        convolution_default_289 = torch.ops.aten.convolution.default(constant_pad_nd_default_34, primals_1049, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 864)
        convolution_default_290 = torch.ops.aten.convolution.default(convolution_default_289, primals_1050, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_156 = torch.ops.aten.native_batch_norm.default(convolution_default_290, primals_1043, primals_1039, primals_1041, primals_1042, True, 0.1, 0.001);  primals_1039 = None
        getitem_534 = native_batch_norm_default_156[0]
        getitem_535 = native_batch_norm_default_156[1]
        getitem_536 = native_batch_norm_default_156[2];  native_batch_norm_default_156 = None
        relu_default_155 = torch.ops.aten.relu.default(getitem_534);  getitem_534 = None
        convolution_default_291 = torch.ops.aten.convolution.default(relu_default_155, primals_1051, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_292 = torch.ops.aten.convolution.default(convolution_default_291, primals_1052, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_157 = torch.ops.aten.native_batch_norm.default(convolution_default_292, primals_1048, primals_1044, primals_1046, primals_1047, True, 0.1, 0.001);  primals_1044 = None
        getitem_537 = native_batch_norm_default_157[0]
        getitem_538 = native_batch_norm_default_157[1]
        getitem_539 = native_batch_norm_default_157[2];  native_batch_norm_default_157 = None
        relu_default_156 = torch.ops.aten.relu.default(getitem_495);  getitem_495 = None
        convolution_default_293 = torch.ops.aten.convolution.default(relu_default_156, primals_1058, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_158 = torch.ops.aten.native_batch_norm.default(convolution_default_293, primals_1057, primals_1053, primals_1055, primals_1056, True, 0.1, 0.001);  primals_1053 = None
        getitem_540 = native_batch_norm_default_158[0]
        getitem_541 = native_batch_norm_default_158[1]
        getitem_542 = native_batch_norm_default_158[2];  native_batch_norm_default_158 = None
        add_tensor_55 = torch.ops.aten.add.Tensor(getitem_537, getitem_540);  getitem_537 = getitem_540 = None
        cat_default_13 = torch.ops.aten.cat.default([add_tensor_51, add_tensor_52, add_tensor_53, add_tensor_54, add_tensor_55], 1);  add_tensor_51 = add_tensor_52 = add_tensor_53 = add_tensor_54 = add_tensor_55 = None
        relu_default_157 = torch.ops.aten.relu.default(cat_default_12);  cat_default_12 = None
        avg_pool2d_default_6 = torch.ops.aten.avg_pool2d.default(relu_default_157, [1, 1], [2, 2], [0, 0], False, False)
        convolution_default_294 = torch.ops.aten.convolution.default(avg_pool2d_default_6, primals_1166, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        constant_pad_nd_default_35 = torch.ops.aten.constant_pad_nd.default(relu_default_157, [-1, 1, -1, 1], 0.0)
        avg_pool2d_default_7 = torch.ops.aten.avg_pool2d.default(constant_pad_nd_default_35, [1, 1], [2, 2], [0, 0], False, False)
        convolution_default_295 = torch.ops.aten.convolution.default(avg_pool2d_default_7, primals_1167, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_14 = torch.ops.aten.cat.default([convolution_default_294, convolution_default_295], 1);  convolution_default_294 = convolution_default_295 = None
        native_batch_norm_default_159 = torch.ops.aten.native_batch_norm.default(cat_default_14, primals_1165, primals_1161, primals_1163, primals_1164, True, 0.1, 0.001);  primals_1161 = None
        getitem_543 = native_batch_norm_default_159[0]
        getitem_544 = native_batch_norm_default_159[1]
        getitem_545 = native_batch_norm_default_159[2];  native_batch_norm_default_159 = None
        relu_default_158 = torch.ops.aten.relu.default(cat_default_13)
        convolution_default_296 = torch.ops.aten.convolution.default(relu_default_158, primals_1160, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_160 = torch.ops.aten.native_batch_norm.default(convolution_default_296, primals_1159, primals_1155, primals_1157, primals_1158, True, 0.1, 0.001);  primals_1155 = None
        getitem_546 = native_batch_norm_default_160[0]
        getitem_547 = native_batch_norm_default_160[1]
        getitem_548 = native_batch_norm_default_160[2];  native_batch_norm_default_160 = None
        relu_default_159 = torch.ops.aten.relu.default(getitem_543)
        convolution_default_297 = torch.ops.aten.convolution.default(relu_default_159, primals_1081, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 864)
        convolution_default_298 = torch.ops.aten.convolution.default(convolution_default_297, primals_1082, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_161 = torch.ops.aten.native_batch_norm.default(convolution_default_298, primals_1075, primals_1071, primals_1073, primals_1074, True, 0.1, 0.001);  primals_1071 = None
        getitem_549 = native_batch_norm_default_161[0]
        getitem_550 = native_batch_norm_default_161[1]
        getitem_551 = native_batch_norm_default_161[2];  native_batch_norm_default_161 = None
        relu_default_160 = torch.ops.aten.relu.default(getitem_549);  getitem_549 = None
        convolution_default_299 = torch.ops.aten.convolution.default(relu_default_160, primals_1083, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 864)
        convolution_default_300 = torch.ops.aten.convolution.default(convolution_default_299, primals_1084, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_162 = torch.ops.aten.native_batch_norm.default(convolution_default_300, primals_1080, primals_1076, primals_1078, primals_1079, True, 0.1, 0.001);  primals_1076 = None
        getitem_552 = native_batch_norm_default_162[0]
        getitem_553 = native_batch_norm_default_162[1]
        getitem_554 = native_batch_norm_default_162[2];  native_batch_norm_default_162 = None
        max_pool2d_with_indices_default_33 = torch.ops.aten.max_pool2d_with_indices.default(getitem_543, [3, 3], [1, 1], [1, 1])
        getitem_555 = max_pool2d_with_indices_default_33[0]
        getitem_556 = max_pool2d_with_indices_default_33[1];  max_pool2d_with_indices_default_33 = None
        add_tensor_56 = torch.ops.aten.add.Tensor(getitem_552, getitem_555);  getitem_552 = getitem_555 = None
        relu_default_161 = torch.ops.aten.relu.default(getitem_546)
        convolution_default_301 = torch.ops.aten.convolution.default(relu_default_161, primals_1095, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 864)
        convolution_default_302 = torch.ops.aten.convolution.default(convolution_default_301, primals_1096, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_163 = torch.ops.aten.native_batch_norm.default(convolution_default_302, primals_1089, primals_1085, primals_1087, primals_1088, True, 0.1, 0.001);  primals_1085 = None
        getitem_557 = native_batch_norm_default_163[0]
        getitem_558 = native_batch_norm_default_163[1]
        getitem_559 = native_batch_norm_default_163[2];  native_batch_norm_default_163 = None
        relu_default_162 = torch.ops.aten.relu.default(getitem_557);  getitem_557 = None
        convolution_default_303 = torch.ops.aten.convolution.default(relu_default_162, primals_1097, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 864)
        convolution_default_304 = torch.ops.aten.convolution.default(convolution_default_303, primals_1098, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_164 = torch.ops.aten.native_batch_norm.default(convolution_default_304, primals_1094, primals_1090, primals_1092, primals_1093, True, 0.1, 0.001);  primals_1090 = None
        getitem_560 = native_batch_norm_default_164[0]
        getitem_561 = native_batch_norm_default_164[1]
        getitem_562 = native_batch_norm_default_164[2];  native_batch_norm_default_164 = None
        max_pool2d_with_indices_default_34 = torch.ops.aten.max_pool2d_with_indices.default(getitem_546, [3, 3], [1, 1], [1, 1])
        getitem_563 = max_pool2d_with_indices_default_34[0]
        getitem_564 = max_pool2d_with_indices_default_34[1];  max_pool2d_with_indices_default_34 = None
        add_tensor_57 = torch.ops.aten.add.Tensor(getitem_560, getitem_563);  getitem_560 = getitem_563 = None
        relu_default_163 = torch.ops.aten.relu.default(getitem_546)
        convolution_default_305 = torch.ops.aten.convolution.default(relu_default_163, primals_1109, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 864)
        convolution_default_306 = torch.ops.aten.convolution.default(convolution_default_305, primals_1110, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_165 = torch.ops.aten.native_batch_norm.default(convolution_default_306, primals_1103, primals_1099, primals_1101, primals_1102, True, 0.1, 0.001);  primals_1099 = None
        getitem_565 = native_batch_norm_default_165[0]
        getitem_566 = native_batch_norm_default_165[1]
        getitem_567 = native_batch_norm_default_165[2];  native_batch_norm_default_165 = None
        relu_default_164 = torch.ops.aten.relu.default(getitem_565);  getitem_565 = None
        convolution_default_307 = torch.ops.aten.convolution.default(relu_default_164, primals_1111, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 864)
        convolution_default_308 = torch.ops.aten.convolution.default(convolution_default_307, primals_1112, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_166 = torch.ops.aten.native_batch_norm.default(convolution_default_308, primals_1108, primals_1104, primals_1106, primals_1107, True, 0.1, 0.001);  primals_1104 = None
        getitem_568 = native_batch_norm_default_166[0]
        getitem_569 = native_batch_norm_default_166[1]
        getitem_570 = native_batch_norm_default_166[2];  native_batch_norm_default_166 = None
        relu_default_165 = torch.ops.aten.relu.default(getitem_546)
        convolution_default_309 = torch.ops.aten.convolution.default(relu_default_165, primals_1123, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_310 = torch.ops.aten.convolution.default(convolution_default_309, primals_1124, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_167 = torch.ops.aten.native_batch_norm.default(convolution_default_310, primals_1117, primals_1113, primals_1115, primals_1116, True, 0.1, 0.001);  primals_1113 = None
        getitem_571 = native_batch_norm_default_167[0]
        getitem_572 = native_batch_norm_default_167[1]
        getitem_573 = native_batch_norm_default_167[2];  native_batch_norm_default_167 = None
        relu_default_166 = torch.ops.aten.relu.default(getitem_571);  getitem_571 = None
        convolution_default_311 = torch.ops.aten.convolution.default(relu_default_166, primals_1125, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_312 = torch.ops.aten.convolution.default(convolution_default_311, primals_1126, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_168 = torch.ops.aten.native_batch_norm.default(convolution_default_312, primals_1122, primals_1118, primals_1120, primals_1121, True, 0.1, 0.001);  primals_1118 = None
        getitem_574 = native_batch_norm_default_168[0]
        getitem_575 = native_batch_norm_default_168[1]
        getitem_576 = native_batch_norm_default_168[2];  native_batch_norm_default_168 = None
        add_tensor_58 = torch.ops.aten.add.Tensor(getitem_568, getitem_574);  getitem_568 = getitem_574 = None
        relu_default_167 = torch.ops.aten.relu.default(add_tensor_58)
        convolution_default_313 = torch.ops.aten.convolution.default(relu_default_167, primals_1137, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_314 = torch.ops.aten.convolution.default(convolution_default_313, primals_1138, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_169 = torch.ops.aten.native_batch_norm.default(convolution_default_314, primals_1131, primals_1127, primals_1129, primals_1130, True, 0.1, 0.001);  primals_1127 = None
        getitem_577 = native_batch_norm_default_169[0]
        getitem_578 = native_batch_norm_default_169[1]
        getitem_579 = native_batch_norm_default_169[2];  native_batch_norm_default_169 = None
        relu_default_168 = torch.ops.aten.relu.default(getitem_577);  getitem_577 = None
        convolution_default_315 = torch.ops.aten.convolution.default(relu_default_168, primals_1139, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_316 = torch.ops.aten.convolution.default(convolution_default_315, primals_1140, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_170 = torch.ops.aten.native_batch_norm.default(convolution_default_316, primals_1136, primals_1132, primals_1134, primals_1135, True, 0.1, 0.001);  primals_1132 = None
        getitem_580 = native_batch_norm_default_170[0]
        getitem_581 = native_batch_norm_default_170[1]
        getitem_582 = native_batch_norm_default_170[2];  native_batch_norm_default_170 = None
        max_pool2d_with_indices_default_35 = torch.ops.aten.max_pool2d_with_indices.default(getitem_546, [3, 3], [1, 1], [1, 1])
        getitem_583 = max_pool2d_with_indices_default_35[0]
        getitem_584 = max_pool2d_with_indices_default_35[1];  max_pool2d_with_indices_default_35 = None
        add_tensor_59 = torch.ops.aten.add.Tensor(getitem_580, getitem_583);  getitem_580 = getitem_583 = None
        relu_default_169 = torch.ops.aten.relu.default(getitem_543)
        convolution_default_317 = torch.ops.aten.convolution.default(relu_default_169, primals_1151, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_318 = torch.ops.aten.convolution.default(convolution_default_317, primals_1152, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_171 = torch.ops.aten.native_batch_norm.default(convolution_default_318, primals_1145, primals_1141, primals_1143, primals_1144, True, 0.1, 0.001);  primals_1141 = None
        getitem_585 = native_batch_norm_default_171[0]
        getitem_586 = native_batch_norm_default_171[1]
        getitem_587 = native_batch_norm_default_171[2];  native_batch_norm_default_171 = None
        relu_default_170 = torch.ops.aten.relu.default(getitem_585);  getitem_585 = None
        convolution_default_319 = torch.ops.aten.convolution.default(relu_default_170, primals_1153, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_320 = torch.ops.aten.convolution.default(convolution_default_319, primals_1154, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_172 = torch.ops.aten.native_batch_norm.default(convolution_default_320, primals_1150, primals_1146, primals_1148, primals_1149, True, 0.1, 0.001);  primals_1146 = None
        getitem_588 = native_batch_norm_default_172[0]
        getitem_589 = native_batch_norm_default_172[1]
        getitem_590 = native_batch_norm_default_172[2];  native_batch_norm_default_172 = None
        add_tensor_60 = torch.ops.aten.add.Tensor(getitem_588, getitem_546);  getitem_588 = None
        cat_default_15 = torch.ops.aten.cat.default([add_tensor_56, add_tensor_57, add_tensor_58, add_tensor_59, add_tensor_60], 1);  add_tensor_56 = add_tensor_57 = add_tensor_58 = add_tensor_59 = add_tensor_60 = None
        relu_default_171 = torch.ops.aten.relu.default(cat_default_13);  cat_default_13 = None
        convolution_default_321 = torch.ops.aten.convolution.default(relu_default_171, primals_193, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_173 = torch.ops.aten.native_batch_norm.default(convolution_default_321, primals_192, primals_188, primals_190, primals_191, True, 0.1, 0.001);  primals_188 = None
        getitem_591 = native_batch_norm_default_173[0]
        getitem_592 = native_batch_norm_default_173[1]
        getitem_593 = native_batch_norm_default_173[2];  native_batch_norm_default_173 = None
        relu_default_172 = torch.ops.aten.relu.default(cat_default_15)
        convolution_default_322 = torch.ops.aten.convolution.default(relu_default_172, primals_187, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_174 = torch.ops.aten.native_batch_norm.default(convolution_default_322, primals_186, primals_182, primals_184, primals_185, True, 0.1, 0.001);  primals_182 = None
        getitem_594 = native_batch_norm_default_174[0]
        getitem_595 = native_batch_norm_default_174[1]
        getitem_596 = native_batch_norm_default_174[2];  native_batch_norm_default_174 = None
        relu_default_173 = torch.ops.aten.relu.default(getitem_591)
        convolution_default_323 = torch.ops.aten.convolution.default(relu_default_173, primals_108, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 864)
        convolution_default_324 = torch.ops.aten.convolution.default(convolution_default_323, primals_109, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_175 = torch.ops.aten.native_batch_norm.default(convolution_default_324, primals_102, primals_98, primals_100, primals_101, True, 0.1, 0.001);  primals_98 = None
        getitem_597 = native_batch_norm_default_175[0]
        getitem_598 = native_batch_norm_default_175[1]
        getitem_599 = native_batch_norm_default_175[2];  native_batch_norm_default_175 = None
        relu_default_174 = torch.ops.aten.relu.default(getitem_597);  getitem_597 = None
        convolution_default_325 = torch.ops.aten.convolution.default(relu_default_174, primals_110, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 864)
        convolution_default_326 = torch.ops.aten.convolution.default(convolution_default_325, primals_111, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_176 = torch.ops.aten.native_batch_norm.default(convolution_default_326, primals_107, primals_103, primals_105, primals_106, True, 0.1, 0.001);  primals_103 = None
        getitem_600 = native_batch_norm_default_176[0]
        getitem_601 = native_batch_norm_default_176[1]
        getitem_602 = native_batch_norm_default_176[2];  native_batch_norm_default_176 = None
        max_pool2d_with_indices_default_36 = torch.ops.aten.max_pool2d_with_indices.default(getitem_591, [3, 3], [1, 1], [1, 1])
        getitem_603 = max_pool2d_with_indices_default_36[0]
        getitem_604 = max_pool2d_with_indices_default_36[1];  max_pool2d_with_indices_default_36 = None
        add_tensor_61 = torch.ops.aten.add.Tensor(getitem_600, getitem_603);  getitem_600 = getitem_603 = None
        relu_default_175 = torch.ops.aten.relu.default(getitem_594)
        convolution_default_327 = torch.ops.aten.convolution.default(relu_default_175, primals_122, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 864)
        convolution_default_328 = torch.ops.aten.convolution.default(convolution_default_327, primals_123, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_177 = torch.ops.aten.native_batch_norm.default(convolution_default_328, primals_116, primals_112, primals_114, primals_115, True, 0.1, 0.001);  primals_112 = None
        getitem_605 = native_batch_norm_default_177[0]
        getitem_606 = native_batch_norm_default_177[1]
        getitem_607 = native_batch_norm_default_177[2];  native_batch_norm_default_177 = None
        relu_default_176 = torch.ops.aten.relu.default(getitem_605);  getitem_605 = None
        convolution_default_329 = torch.ops.aten.convolution.default(relu_default_176, primals_124, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 864)
        convolution_default_330 = torch.ops.aten.convolution.default(convolution_default_329, primals_125, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_178 = torch.ops.aten.native_batch_norm.default(convolution_default_330, primals_121, primals_117, primals_119, primals_120, True, 0.1, 0.001);  primals_117 = None
        getitem_608 = native_batch_norm_default_178[0]
        getitem_609 = native_batch_norm_default_178[1]
        getitem_610 = native_batch_norm_default_178[2];  native_batch_norm_default_178 = None
        max_pool2d_with_indices_default_37 = torch.ops.aten.max_pool2d_with_indices.default(getitem_594, [3, 3], [1, 1], [1, 1])
        getitem_611 = max_pool2d_with_indices_default_37[0]
        getitem_612 = max_pool2d_with_indices_default_37[1];  max_pool2d_with_indices_default_37 = None
        add_tensor_62 = torch.ops.aten.add.Tensor(getitem_608, getitem_611);  getitem_608 = getitem_611 = None
        relu_default_177 = torch.ops.aten.relu.default(getitem_594)
        convolution_default_331 = torch.ops.aten.convolution.default(relu_default_177, primals_136, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 864)
        convolution_default_332 = torch.ops.aten.convolution.default(convolution_default_331, primals_137, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_179 = torch.ops.aten.native_batch_norm.default(convolution_default_332, primals_130, primals_126, primals_128, primals_129, True, 0.1, 0.001);  primals_126 = None
        getitem_613 = native_batch_norm_default_179[0]
        getitem_614 = native_batch_norm_default_179[1]
        getitem_615 = native_batch_norm_default_179[2];  native_batch_norm_default_179 = None
        relu_default_178 = torch.ops.aten.relu.default(getitem_613);  getitem_613 = None
        convolution_default_333 = torch.ops.aten.convolution.default(relu_default_178, primals_138, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 864)
        convolution_default_334 = torch.ops.aten.convolution.default(convolution_default_333, primals_139, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_180 = torch.ops.aten.native_batch_norm.default(convolution_default_334, primals_135, primals_131, primals_133, primals_134, True, 0.1, 0.001);  primals_131 = None
        getitem_616 = native_batch_norm_default_180[0]
        getitem_617 = native_batch_norm_default_180[1]
        getitem_618 = native_batch_norm_default_180[2];  native_batch_norm_default_180 = None
        relu_default_179 = torch.ops.aten.relu.default(getitem_594)
        convolution_default_335 = torch.ops.aten.convolution.default(relu_default_179, primals_150, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_336 = torch.ops.aten.convolution.default(convolution_default_335, primals_151, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_181 = torch.ops.aten.native_batch_norm.default(convolution_default_336, primals_144, primals_140, primals_142, primals_143, True, 0.1, 0.001);  primals_140 = None
        getitem_619 = native_batch_norm_default_181[0]
        getitem_620 = native_batch_norm_default_181[1]
        getitem_621 = native_batch_norm_default_181[2];  native_batch_norm_default_181 = None
        relu_default_180 = torch.ops.aten.relu.default(getitem_619);  getitem_619 = None
        convolution_default_337 = torch.ops.aten.convolution.default(relu_default_180, primals_152, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_338 = torch.ops.aten.convolution.default(convolution_default_337, primals_153, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_182 = torch.ops.aten.native_batch_norm.default(convolution_default_338, primals_149, primals_145, primals_147, primals_148, True, 0.1, 0.001);  primals_145 = None
        getitem_622 = native_batch_norm_default_182[0]
        getitem_623 = native_batch_norm_default_182[1]
        getitem_624 = native_batch_norm_default_182[2];  native_batch_norm_default_182 = None
        add_tensor_63 = torch.ops.aten.add.Tensor(getitem_616, getitem_622);  getitem_616 = getitem_622 = None
        relu_default_181 = torch.ops.aten.relu.default(add_tensor_63)
        convolution_default_339 = torch.ops.aten.convolution.default(relu_default_181, primals_164, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_340 = torch.ops.aten.convolution.default(convolution_default_339, primals_165, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_183 = torch.ops.aten.native_batch_norm.default(convolution_default_340, primals_158, primals_154, primals_156, primals_157, True, 0.1, 0.001);  primals_154 = None
        getitem_625 = native_batch_norm_default_183[0]
        getitem_626 = native_batch_norm_default_183[1]
        getitem_627 = native_batch_norm_default_183[2];  native_batch_norm_default_183 = None
        relu_default_182 = torch.ops.aten.relu.default(getitem_625);  getitem_625 = None
        convolution_default_341 = torch.ops.aten.convolution.default(relu_default_182, primals_166, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_342 = torch.ops.aten.convolution.default(convolution_default_341, primals_167, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_184 = torch.ops.aten.native_batch_norm.default(convolution_default_342, primals_163, primals_159, primals_161, primals_162, True, 0.1, 0.001);  primals_159 = None
        getitem_628 = native_batch_norm_default_184[0]
        getitem_629 = native_batch_norm_default_184[1]
        getitem_630 = native_batch_norm_default_184[2];  native_batch_norm_default_184 = None
        max_pool2d_with_indices_default_38 = torch.ops.aten.max_pool2d_with_indices.default(getitem_594, [3, 3], [1, 1], [1, 1])
        getitem_631 = max_pool2d_with_indices_default_38[0]
        getitem_632 = max_pool2d_with_indices_default_38[1];  max_pool2d_with_indices_default_38 = None
        add_tensor_64 = torch.ops.aten.add.Tensor(getitem_628, getitem_631);  getitem_628 = getitem_631 = None
        relu_default_183 = torch.ops.aten.relu.default(getitem_591)
        convolution_default_343 = torch.ops.aten.convolution.default(relu_default_183, primals_178, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_344 = torch.ops.aten.convolution.default(convolution_default_343, primals_179, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_185 = torch.ops.aten.native_batch_norm.default(convolution_default_344, primals_172, primals_168, primals_170, primals_171, True, 0.1, 0.001);  primals_168 = None
        getitem_633 = native_batch_norm_default_185[0]
        getitem_634 = native_batch_norm_default_185[1]
        getitem_635 = native_batch_norm_default_185[2];  native_batch_norm_default_185 = None
        relu_default_184 = torch.ops.aten.relu.default(getitem_633);  getitem_633 = None
        convolution_default_345 = torch.ops.aten.convolution.default(relu_default_184, primals_180, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_346 = torch.ops.aten.convolution.default(convolution_default_345, primals_181, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_186 = torch.ops.aten.native_batch_norm.default(convolution_default_346, primals_177, primals_173, primals_175, primals_176, True, 0.1, 0.001);  primals_173 = None
        getitem_636 = native_batch_norm_default_186[0]
        getitem_637 = native_batch_norm_default_186[1]
        getitem_638 = native_batch_norm_default_186[2];  native_batch_norm_default_186 = None
        add_tensor_65 = torch.ops.aten.add.Tensor(getitem_636, getitem_594);  getitem_636 = None
        cat_default_16 = torch.ops.aten.cat.default([add_tensor_61, add_tensor_62, add_tensor_63, add_tensor_64, add_tensor_65], 1);  add_tensor_61 = add_tensor_62 = add_tensor_63 = add_tensor_64 = add_tensor_65 = None
        relu_default_185 = torch.ops.aten.relu.default(cat_default_15);  cat_default_15 = None
        convolution_default_347 = torch.ops.aten.convolution.default(relu_default_185, primals_289, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_187 = torch.ops.aten.native_batch_norm.default(convolution_default_347, primals_288, primals_284, primals_286, primals_287, True, 0.1, 0.001);  primals_284 = None
        getitem_639 = native_batch_norm_default_187[0]
        getitem_640 = native_batch_norm_default_187[1]
        getitem_641 = native_batch_norm_default_187[2];  native_batch_norm_default_187 = None
        relu_default_186 = torch.ops.aten.relu.default(cat_default_16);  cat_default_16 = None
        convolution_default_348 = torch.ops.aten.convolution.default(relu_default_186, primals_283, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_188 = torch.ops.aten.native_batch_norm.default(convolution_default_348, primals_282, primals_278, primals_280, primals_281, True, 0.1, 0.001);  primals_278 = None
        getitem_642 = native_batch_norm_default_188[0]
        getitem_643 = native_batch_norm_default_188[1]
        getitem_644 = native_batch_norm_default_188[2];  native_batch_norm_default_188 = None
        relu_default_187 = torch.ops.aten.relu.default(getitem_639)
        convolution_default_349 = torch.ops.aten.convolution.default(relu_default_187, primals_204, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 864)
        convolution_default_350 = torch.ops.aten.convolution.default(convolution_default_349, primals_205, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_189 = torch.ops.aten.native_batch_norm.default(convolution_default_350, primals_198, primals_194, primals_196, primals_197, True, 0.1, 0.001);  primals_194 = None
        getitem_645 = native_batch_norm_default_189[0]
        getitem_646 = native_batch_norm_default_189[1]
        getitem_647 = native_batch_norm_default_189[2];  native_batch_norm_default_189 = None
        relu_default_188 = torch.ops.aten.relu.default(getitem_645);  getitem_645 = None
        convolution_default_351 = torch.ops.aten.convolution.default(relu_default_188, primals_206, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 864)
        convolution_default_352 = torch.ops.aten.convolution.default(convolution_default_351, primals_207, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_190 = torch.ops.aten.native_batch_norm.default(convolution_default_352, primals_203, primals_199, primals_201, primals_202, True, 0.1, 0.001);  primals_199 = None
        getitem_648 = native_batch_norm_default_190[0]
        getitem_649 = native_batch_norm_default_190[1]
        getitem_650 = native_batch_norm_default_190[2];  native_batch_norm_default_190 = None
        max_pool2d_with_indices_default_39 = torch.ops.aten.max_pool2d_with_indices.default(getitem_639, [3, 3], [1, 1], [1, 1])
        getitem_651 = max_pool2d_with_indices_default_39[0]
        getitem_652 = max_pool2d_with_indices_default_39[1];  max_pool2d_with_indices_default_39 = None
        add_tensor_66 = torch.ops.aten.add.Tensor(getitem_648, getitem_651);  getitem_648 = getitem_651 = None
        relu_default_189 = torch.ops.aten.relu.default(getitem_642)
        convolution_default_353 = torch.ops.aten.convolution.default(relu_default_189, primals_218, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 864)
        convolution_default_354 = torch.ops.aten.convolution.default(convolution_default_353, primals_219, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_191 = torch.ops.aten.native_batch_norm.default(convolution_default_354, primals_212, primals_208, primals_210, primals_211, True, 0.1, 0.001);  primals_208 = None
        getitem_653 = native_batch_norm_default_191[0]
        getitem_654 = native_batch_norm_default_191[1]
        getitem_655 = native_batch_norm_default_191[2];  native_batch_norm_default_191 = None
        relu_default_190 = torch.ops.aten.relu.default(getitem_653);  getitem_653 = None
        convolution_default_355 = torch.ops.aten.convolution.default(relu_default_190, primals_220, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 864)
        convolution_default_356 = torch.ops.aten.convolution.default(convolution_default_355, primals_221, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_192 = torch.ops.aten.native_batch_norm.default(convolution_default_356, primals_217, primals_213, primals_215, primals_216, True, 0.1, 0.001);  primals_213 = None
        getitem_656 = native_batch_norm_default_192[0]
        getitem_657 = native_batch_norm_default_192[1]
        getitem_658 = native_batch_norm_default_192[2];  native_batch_norm_default_192 = None
        max_pool2d_with_indices_default_40 = torch.ops.aten.max_pool2d_with_indices.default(getitem_642, [3, 3], [1, 1], [1, 1])
        getitem_659 = max_pool2d_with_indices_default_40[0]
        getitem_660 = max_pool2d_with_indices_default_40[1];  max_pool2d_with_indices_default_40 = None
        add_tensor_67 = torch.ops.aten.add.Tensor(getitem_656, getitem_659);  getitem_656 = getitem_659 = None
        relu_default_191 = torch.ops.aten.relu.default(getitem_642)
        convolution_default_357 = torch.ops.aten.convolution.default(relu_default_191, primals_232, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 864)
        convolution_default_358 = torch.ops.aten.convolution.default(convolution_default_357, primals_233, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_193 = torch.ops.aten.native_batch_norm.default(convolution_default_358, primals_226, primals_222, primals_224, primals_225, True, 0.1, 0.001);  primals_222 = None
        getitem_661 = native_batch_norm_default_193[0]
        getitem_662 = native_batch_norm_default_193[1]
        getitem_663 = native_batch_norm_default_193[2];  native_batch_norm_default_193 = None
        relu_default_192 = torch.ops.aten.relu.default(getitem_661);  getitem_661 = None
        convolution_default_359 = torch.ops.aten.convolution.default(relu_default_192, primals_234, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 864)
        convolution_default_360 = torch.ops.aten.convolution.default(convolution_default_359, primals_235, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_194 = torch.ops.aten.native_batch_norm.default(convolution_default_360, primals_231, primals_227, primals_229, primals_230, True, 0.1, 0.001);  primals_227 = None
        getitem_664 = native_batch_norm_default_194[0]
        getitem_665 = native_batch_norm_default_194[1]
        getitem_666 = native_batch_norm_default_194[2];  native_batch_norm_default_194 = None
        relu_default_193 = torch.ops.aten.relu.default(getitem_642)
        convolution_default_361 = torch.ops.aten.convolution.default(relu_default_193, primals_246, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_362 = torch.ops.aten.convolution.default(convolution_default_361, primals_247, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_195 = torch.ops.aten.native_batch_norm.default(convolution_default_362, primals_240, primals_236, primals_238, primals_239, True, 0.1, 0.001);  primals_236 = None
        getitem_667 = native_batch_norm_default_195[0]
        getitem_668 = native_batch_norm_default_195[1]
        getitem_669 = native_batch_norm_default_195[2];  native_batch_norm_default_195 = None
        relu_default_194 = torch.ops.aten.relu.default(getitem_667);  getitem_667 = None
        convolution_default_363 = torch.ops.aten.convolution.default(relu_default_194, primals_248, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_364 = torch.ops.aten.convolution.default(convolution_default_363, primals_249, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_196 = torch.ops.aten.native_batch_norm.default(convolution_default_364, primals_245, primals_241, primals_243, primals_244, True, 0.1, 0.001);  primals_241 = None
        getitem_670 = native_batch_norm_default_196[0]
        getitem_671 = native_batch_norm_default_196[1]
        getitem_672 = native_batch_norm_default_196[2];  native_batch_norm_default_196 = None
        add_tensor_68 = torch.ops.aten.add.Tensor(getitem_664, getitem_670);  getitem_664 = getitem_670 = None
        relu_default_195 = torch.ops.aten.relu.default(add_tensor_68)
        convolution_default_365 = torch.ops.aten.convolution.default(relu_default_195, primals_260, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_366 = torch.ops.aten.convolution.default(convolution_default_365, primals_261, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_197 = torch.ops.aten.native_batch_norm.default(convolution_default_366, primals_254, primals_250, primals_252, primals_253, True, 0.1, 0.001);  primals_250 = None
        getitem_673 = native_batch_norm_default_197[0]
        getitem_674 = native_batch_norm_default_197[1]
        getitem_675 = native_batch_norm_default_197[2];  native_batch_norm_default_197 = None
        relu_default_196 = torch.ops.aten.relu.default(getitem_673);  getitem_673 = None
        convolution_default_367 = torch.ops.aten.convolution.default(relu_default_196, primals_262, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_368 = torch.ops.aten.convolution.default(convolution_default_367, primals_263, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_198 = torch.ops.aten.native_batch_norm.default(convolution_default_368, primals_259, primals_255, primals_257, primals_258, True, 0.1, 0.001);  primals_255 = None
        getitem_676 = native_batch_norm_default_198[0]
        getitem_677 = native_batch_norm_default_198[1]
        getitem_678 = native_batch_norm_default_198[2];  native_batch_norm_default_198 = None
        max_pool2d_with_indices_default_41 = torch.ops.aten.max_pool2d_with_indices.default(getitem_642, [3, 3], [1, 1], [1, 1])
        getitem_679 = max_pool2d_with_indices_default_41[0]
        getitem_680 = max_pool2d_with_indices_default_41[1];  max_pool2d_with_indices_default_41 = None
        add_tensor_69 = torch.ops.aten.add.Tensor(getitem_676, getitem_679);  getitem_676 = getitem_679 = None
        relu_default_197 = torch.ops.aten.relu.default(getitem_639)
        convolution_default_369 = torch.ops.aten.convolution.default(relu_default_197, primals_274, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_370 = torch.ops.aten.convolution.default(convolution_default_369, primals_275, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_199 = torch.ops.aten.native_batch_norm.default(convolution_default_370, primals_268, primals_264, primals_266, primals_267, True, 0.1, 0.001);  primals_264 = None
        getitem_681 = native_batch_norm_default_199[0]
        getitem_682 = native_batch_norm_default_199[1]
        getitem_683 = native_batch_norm_default_199[2];  native_batch_norm_default_199 = None
        relu_default_198 = torch.ops.aten.relu.default(getitem_681);  getitem_681 = None
        convolution_default_371 = torch.ops.aten.convolution.default(relu_default_198, primals_276, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 864)
        convolution_default_372 = torch.ops.aten.convolution.default(convolution_default_371, primals_277, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_200 = torch.ops.aten.native_batch_norm.default(convolution_default_372, primals_273, primals_269, primals_271, primals_272, True, 0.1, 0.001);  primals_269 = None
        getitem_684 = native_batch_norm_default_200[0]
        getitem_685 = native_batch_norm_default_200[1]
        getitem_686 = native_batch_norm_default_200[2];  native_batch_norm_default_200 = None
        add_tensor_70 = torch.ops.aten.add.Tensor(getitem_684, getitem_642);  getitem_684 = None
        cat_default_17 = torch.ops.aten.cat.default([add_tensor_66, add_tensor_67, add_tensor_68, add_tensor_69, add_tensor_70], 1);  add_tensor_66 = add_tensor_67 = add_tensor_68 = add_tensor_69 = add_tensor_70 = None
        relu_default_199 = torch.ops.aten.relu.default(cat_default_17);  cat_default_17 = None
        mean_dim = torch.ops.aten.mean.dim(relu_default_199, [-1, -2], True)
        view_default = torch.ops.aten.view.default(mean_dim, [32, 4320]);  mean_dim = None
        t_default = torch.ops.aten.t.default(primals_1375);  primals_1375 = None
        addmm_default = torch.ops.aten.addmm.default(primals_1374, view_default, t_default);  primals_1374 = None
        return [addmm_default, add_tensor, getitem_671, convolution_default_38, getitem_412, getitem_411, getitem_672, convolution_default_241, relu_default_43, getitem_116, relu_default_119, getitem_115, convolution_default_366, convolution_default_365, convolution_default_62, convolution_default_37, getitem_70, convolution_default_223, relu_default_33, getitem_675, getitem_113, convolution_default_224, relu_default_19, getitem_415, getitem_674, relu_default_120, getitem_414, relu_default_196, getitem_112, convolution_default_367, relu_default_32, getitem_417, convolution_default_368, convolution_default_225, constant_pad_nd_default_12, getitem_69, convolution_default_61, primals_830, primals_1186, convolution_default_214, convolution_default_342, convolution_default_321, primals_894, primals_1248, relu_default_42, getitem_392, getitem_391, getitem_627, getitem_626, primals_1191, primals_1251, primals_891, primals_832, primals_828, primals_1192, primals_1195, relu_default_113, convolution_default_306, primals_1197, relu_default_182, convolution_default_305, primals_836, getitem_152, getitem_564, convolution_default_213, primals_1198, convolution_default_341, primals_1257, convolution_default_27, primals_898, convolution_default_25, getitem_151, primals_895, getitem_27, getitem_44, getitem_567, primals_835, primals_1247, primals_1187, getitem_154, primals_1254, getitem_395, primals_1256, getitem_630, primals_899, getitem_155, primals_1246, relu_default_12, relu_default_13, primals_900, primals_1253, convolution_default_82, primals_827, getitem_566, relu_default_183, getitem_394, primals_896, getitem_629, getitem_42, relu_default_164, primals_837, primals_1190, primals_1240, primals_897, primals_840, primals_831, primals_885, primals_890, primals_889, primals_1242, getitem_153, primals_1255, getitem_397, primals_829, primals_1199, primals_1200, relu_default_44, convolution_default_307, primals_884, primals_1243, primals_886, getitem_398, getitem_632, primals_1185, primals_826, primals_1196, primals_1252, getitem_47, getitem_396, convolution_default_84, convolution_default_308, primals_1241, getitem_87, primals_942, relu_default_18, relu_default_142, getitem_330, constant_pad_nd_default_11, getitem_90, convolution_default_47, getitem_65, convolution_default_248, constant_pad_nd_default_17, getitem_329, convolution_default_247, getitem_457, primals_941, primals_947, getitem_460, primals_939, convolution_default_180, convolution_default_35, convolution_default_179, getitem_459, primals_946, convolution_default_48, constant_pad_nd_default_24, primals_950, relu_default_133, getitem_64, primals_940, getitem_89, primals_953, getitem_333, convolution_default_181, getitem_86, getitem_332, convolution_default_249, convolution_default_46, getitem_67, primals_951, relu_default_96, primals_952, primals_945, primals_954, convolution_default_250, convolution_default_36, primals_938, getitem_177, getitem_176, primals_1170, relu_default_50, convolution_default_95, primals_1179, convolution_default_96, getitem_180, primals_1180, primals_1182, getitem_179, primals_1181, primals_1178, relu_default_51, primals_1172, primals_1175, primals_1176, primals_1171, convolution_default_97, primals_1177, convolution_default_98, convolution_default_135, primals_661, getitem_222, primals_666, primals_671, primals_670, getitem_503, getitem_610, convolution_default_120, relu_default_146, relu_default_177, convolution_default_119, getitem_502, getitem_609, getitem_225, getitem_505, relu_default_185, getitem_224, convolution_default_272, convolution_default_330, primals_665, primals_667, primals_677, relu_default_64, primals_676, primals_673, primals_679, getitem_612, relu_default_15, convolution_default_331, convolution_default_121, primals_678, primals_672, convolution_default_332, convolution_default_122, convolution_default_273, constant_pad_nd_default_29, primals_664, convolution_default_274, primals_931, getitem_120, getitem_132, relu_default_39, primals_924, primals_1050, primals_636, constant_pad_nd_default_1, getitem_131, primals_637, getitem_268, relu_default_77, primals_1055, primals_1049, getitem_7, convolution_default_238, primals_1057, getitem_121, convolution_default_237, primals_628, primals_33, relu_default_37, primals_32, getitem_267, primals_42, getitem_437, primals_38, primals_641, primals_1063, primals_629, primals_36, primals_630, primals_632, primals_925, convolution_default_72, getitem_440, convolution_default_71, convolution_default_144, primals_1056, convolution_default_65, primals_1062, primals_1051, primals_40, primals_37, getitem_439, primals_922, primals_633, primals_1064, getitem_135, primals_937, relu_default_127, primals_41, primals_631, getitem_134, getitem_270, primals_1048, primals_933, convolution_default_145, primals_638, primals_1061, primals_642, relu_default_38, primals_936, convolution_default_66, convolution_default_63, convolution_default_239, getitem_118, primals_928, convolution_default_4, convolution_default_146, primals_926, convolution_default_64, relu_default_34, primals_932, primals_923, getitem_8, convolution_default_74, primals_927, convolution_default_73, convolution_default_240, primals_39, primals_1058, getitem_272, primals_31, primals_1052, relu_default_170, primals_1213, primals_469, primals_1211, convolution_default_168, primals_1219, getitem_655, primals_427, primals_1214, convolution_default_167, primals_421, primals_1210, primals_468, convolution_default_356, primals_430, primals_809, getitem_654, primals_432, getitem_590, primals_467, convolution_default_1, primals_821, getitem_313, primals_817, relu_default_190, primals_1201, primals_816, getitem_312, getitem_589, primals_1209, primals_1205, primals_431, relu_default_90, getitem_591, primals_425, primals_818, primals_1212, primals_472, convolution_default_355, convolution_default_320, primals_823, getitem_592, primals_1218, primals_822, primals_812, primals_813, convolution_default_169, primals_1206, primals_815, getitem_593, primals_464, primals_475, primals_426, getitem_658, primals_418, primals_814, getitem_315, primals_474, relu_default_172, getitem_657, primals_479, convolution_default_170, primals_478, primals_1204, primals_480, constant_pad_nd_default_21, relu_default_191, getitem_660, primals_422, primals_424, primals_466, getitem_316, primals_423, primals_465, primals_1215, relu_default_91, convolution_default_322, primals_473, getitem_544, getitem_201, getitem_202, getitem_545, convolution_default_41, getitem_248, relu_default_128, getitem_203, getitem_375, getitem_543, relu_default_58, avg_pool2d_default, getitem_247, getitem_374, getitem_249, relu_default_158, relu_default_108, convolution_default_110, convolution_default_134, getitem_250, convolution_default_202, convolution_default_296, getitem_206, constant_pad_nd_default_25, getitem_205, getitem_251, getitem_78, getitem_204, convolution_default_39, convolution_default_203, getitem_548, convolution_default_40, getitem_547, getitem_546, relu_default_72, getitem_77, relu_default_59, relu_default_21, convolution_default_204, relu_default_159, convolution_default_136, getitem_377, convolution_default_111, getitem_378, convolution_default_209, convolution_default_298, getitem_4, convolution_default_297, getitem_5, convolution_default_112, primals_463, primals_454, primals_1226, primals_1339, primals_604, primals_1329, primals_603, primals_1038, primals_1233, primals_605, primals_453, getitem_483, primals_1234, primals_1328, relu_default_140, primals_452, primals_595, primals_1046, primals_1342, primals_1228, primals_449, primals_596, primals_1220, primals_600, primals_1237, getitem_482, primals_1238, primals_1047, primals_1343, primals_451, primals_1035, primals_1338, primals_455, primals_459, primals_1239, primals_1229, convolution_default_262, primals_1037, primals_1034, primals_1227, primals_460, primals_599, primals_1036, primals_458, primals_1336, primals_1225, primals_1333, primals_450, primals_1224, primals_1334, primals_601, primals_1042, getitem_485, primals_602, primals_1043, primals_1033, primals_1232, primals_1330, convolution_default_263, primals_608, primals_1335, primals_594, primals_1337, primals_1032, convolution_default_264, primals_1223, primals_1325, primals_1041, convolution_default_267, convolution_default_343, getitem_525, getitem_293, convolution_default_344, primals_733, constant_pad_nd_default_6, primals_725, relu_default_10, primals_735, convolution_default_160, getitem_524, getitem_635, getitem_292, primals_734, convolution_default_286, convolution_default_285, primals_739, relu_default_84, primals_720, getitem_634, primals_729, getitem_528, primals_731, relu_default_184, primals_732, convolution_default_159, getitem_527, primals_730, primals_738, convolution_default_345, primals_726, relu_default_153, primals_724, getitem_296, getitem_295, convolution_default_346, constant_pad_nd_default_33, convolution_default_287, getitem_38, convolution_default_21, convolution_default_205, getitem_638, primals_721, getitem_637, convolution_default_288, getitem_39, primals_382, getitem_677, getitem_508, getitem_678, relu_default_102, primals_383, getitem_507, convolution_default_31, primals_388, relu_default_197, getitem_59, convolution_default_192, convolution_default_191, relu_default_147, primals_384, primals_393, relu_default_16, getitem_356, convolution_default_276, primals_395, convolution_default_32, convolution_default_275, convolution_default_30, convolution_default_370, primals_389, convolution_default_369, getitem_46, getitem_680, primals_385, getitem_58, getitem_355, primals_397, getitem_511, primals_398, relu_default_103, primals_396, relu_default_148, getitem_683, getitem_510, primals_390, primals_394, relu_default_157, getitem_682, convolution_default_193, avg_pool2d_default_2, relu_default_198, cat_default_14, primals_399, convolution_default_194, constant_pad_nd_default_30, constant_pad_nd_default_9, convolution_default_372, convolution_default_371, getitem_513, constant_pad_nd_default_31, primals_150, primals_914, primals_1111, primals_412, convolution_default_182, convolution_default_226, getitem_462, relu_default_134, primals_402, getitem_569, getitem_570, primals_408, primals_710, getitem_463, getitem_336, primals_144, primals_711, primals_1109, relu_default_11, getitem_158, primals_1106, getitem_420, primals_156, primals_411, primals_152, primals_707, relu_default_97, primals_1344, getitem_157, getitem_156, convolution_default_228, relu_default_165, primals_715, getitem_335, primals_911, primals_147, primals_1350, primals_719, getitem_419, primals_1351, relu_default_45, primals_712, primals_904, getitem_338, convolution_default_310, primals_908, primals_1103, getitem_35, relu_default_121, convolution_default_252, convolution_default_309, primals_1107, convolution_default_251, relu_default_167, relu_default_110, convolution_default_86, getitem_465, primals_1347, convolution_default_85, primals_404, primals_142, primals_1353, getitem_573, primals_718, convolution_default_227, primals_149, primals_157, primals_905, primals_410, primals_910, primals_1357, constant_pad_nd_default_4, primals_407, primals_416, primals_1116, primals_703, primals_704, getitem_572, primals_702, primals_153, primals_1117, convolution_default_254, primals_151, primals_1108, primals_1349, getitem_161, primals_918, getitem_467, getitem_468, primals_913, getitem_160, relu_default_166, primals_403, primals_143, primals_1352, getitem_423, primals_706, primals_1348, primals_716, getitem_422, relu_default_135, relu_default_46, primals_158, primals_409, primals_705, primals_903, convolution_default_183, primals_1356, primals_1112, convolution_default_184, primals_717, primals_912, primals_1110, primals_148, convolution_default_311, primals_909, primals_917, primals_919, primals_413, primals_1115, primals_417, convolution_default_88, primals_701, convolution_default_87, relu_default_122, convolution_default_253, convolution_default_312, getitem_614, primals_301, convolution_default_100, getitem_615, primals_299, primals_307, getitem_182, convolution_default_334, relu_default_178, relu_default_52, primals_303, convolution_default_44, getitem_183, primals_300, convolution_default_333, primals_302, convolution_default_99, getitem_618, primals_308, getitem_83, primals_306, relu_default_6, primals_294, getitem_617, getitem_186, relu_default_53, relu_default_179, getitem_185, convolution_default_14, convolution_default_45, relu_default_23, getitem_84, convolution_default_335, convolution_default_101, primals_297, convolution_default_336, convolution_default_102, primals_298, relu_default_67, getitem_227, primals_1143, primals_859, getitem_228, getitem_551, primals_1122, getitem_281, primals_860, convolution_default_300, relu_default_65, primals_1008, getitem_550, primals_864, primals_1139, primals_609, convolution_default_124, primals_627, convolution_default_123, relu_default_160, primals_1138, primals_1145, primals_1137, primals_1134, primals_615, primals_1149, primals_1121, getitem_231, primals_623, primals_866, convolution_default_299, primals_618, primals_1136, primals_1129, primals_619, primals_1009, primals_1131, primals_1124, getitem_230, primals_865, primals_617, primals_1004, convolution_default, convolution_default_26, relu_default_66, primals_1120, getitem_554, primals_1007, primals_1150, getitem_553, getitem_50, primals_614, primals_1010, primals_624, primals_616, primals_1001, relu_default_161, primals_610, primals_1135, convolution_default_125, getitem_556, primals_1125, primals_1148, primals_858, primals_1006, primals_1140, primals_613, primals_1014, primals_622, primals_1123, primals_1013, primals_1130, primals_863, primals_1005, primals_1126, convolution_default_126, primals_1144, getitem_443, getitem_442, getitem_138, convolution_default_358, convolution_default_357, convolution_default_24, getitem_137, getitem_444, getitem_445, getitem_663, getitem_446, getitem_662, convolution_default_76, cat_default_1, relu_default_129, convolution_default_75, relu_default_192, getitem_49, convolution_default_78, convolution_default_242, convolution_default_359, getitem_141, getitem_447, getitem_140, relu_default_40, convolution_default_360, relu_default_130, getitem_448, getitem_449, getitem_665, convolution_default_77, getitem_273, primals_531, relu_default_115, relu_default_141, primals_533, convolution_default_266, primals_367, primals_528, relu_default_78, primals_527, getitem_487, convolution_default_51, getitem_95, primals_523, convolution_default_216, primals_1373, getitem_488, convolution_default_265, primals_534, convolution_default_53, primals_379, getitem_29, primals_378, primals_520, getitem_401, getitem_276, getitem_400, getitem_399, getitem_491, primals_1370, primals_377, primals_517, relu_default_7, primals_372, getitem_275, primals_1376, getitem_490, relu_default_116, primals_1379, primals_376, relu_default_79, getitem_98, primals_521, convolution_default_52, getitem_493, primals_368, convolution_default_148, primals_1372, relu_default_27, convolution_default_217, primals_369, getitem_97, primals_1371, getitem_494, primals_519, primals_1380, convolution_default_149, convolution_default_218, primals_373, primals_1369, constant_pad_nd_default_5, convolution_default_293, primals_522, primals_532, convolution_default_54, relu_default_171, primals_371, convolution_default_150, primals_1378, primals_518, getitem_403, relu_default_143, primals_526, primals_370, getitem_30, getitem_404, primals_850, relu_default_154, getitem_318, getitem_530, relu_default_109, primals_857, getitem_531, primals_843, primals_129, getitem_533, primals_139, primals_856, getitem_26, getitem_381, primals_125, convolution_default_172, relu_default_9, primals_845, primals_849, relu_default_36, getitem_380, convolution_default_290, convolution_default_171, primals_134, primals_841, constant_pad_nd_default_22, primals_136, getitem_129, convolution_default_289, getitem_128, convolution_default_206, getitem_321, getitem_320, convolution_default_292, primals_842, primals_128, primals_854, primals_130, convolution_default_70, primals_851, relu_default_92, convolution_default_207, getitem_535, primals_846, getitem_536, primals_133, primals_855, primals_137, convolution_default_208, primals_135, relu_default_155, convolution_default_173, primals_844, convolution_default_69, getitem_383, convolution_default_174, primals_138, getitem_384, convolution_default_291, getitem_254, getitem_253, getitem_640, getitem_641, getitem_639, getitem_252, relu_default_186, relu_default_73, convolution_default_138, convolution_default_137, convolution_default_348, primals_116, primals_108, getitem_257, primals_124, getitem_644, getitem_643, primals_123, getitem_642, primals_122, getitem_256, primals_111, relu_default_187, relu_default_74, primals_119, primals_109, primals_115, primals_114, convolution_default_349, convolution_default_139, convolution_default_140, primals_121, primals_107, primals_120, convolution_default_350, primals_110, primals_1164, getitem_358, primals_761, primals_1151, getitem_209, primals_1166, getitem_359, getitem_596, convolution_default_114, primals_1159, getitem_594, relu_default_114, getitem_595, getitem_208, relu_default_104, primals_1154, relu_default_173, primals_753, relu_default_60, convolution_default_18, convolution_default_196, convolution_default_195, getitem_361, convolution_default_324, primals_763, convolution_default_323, convolution_default_113, primals_767, relu_default_71, primals_769, primals_766, getitem_364, getitem_599, primals_1163, getitem_212, primals_762, primals_754, primals_1152, relu_default_61, getitem_363, getitem_598, primals_757, getitem_211, primals_1153, relu_default_105, relu_default_174, primals_768, primals_1157, primals_1167, getitem_576, primals_1158, primals_760, primals_759, primals_1160, convolution_default_197, convolution_default_325, getitem_214, convolution_default_326, primals_1165, primals_758, convolution_default_198, primals_1368, getitem_621, getitem_620, getitem_24, constant_pad_nd_default_16, getitem_686, convolution_default_23, primals_1364, relu_default_25, getitem_685, primals_75, primals_233, primals_74, primals_93, constant_pad_nd_default_7, relu_default_180, primals_95, primals_81, primals_243, primals_235, view_default, convolution_default_337, primals_1359, primals_246, primals_90, convolution_default_338, getitem_624, t_default, primals_82, primals_69, getitem_41, relu_default_181, primals_234, primals_1358, getitem_623, primals_105, primals_245, primals_84, primals_101, convolution_default_22, primals_238, primals_1365, primals_88, primals_70, primals_79, primals_102, primals_97, primals_240, primals_1362, primals_68, primals_100, primals_89, primals_73, primals_96, convolution_default_339, primals_80, getitem_92, convolution_default_347, primals_244, primals_106, convolution_default_340, primals_83, convolution_default_50, getitem_93, primals_239, primals_94, primals_1363, primals_78, primals_247, primals_87, convolution_default_186, primals_587, getitem_341, convolution_default_230, relu_default_47, getitem_234, getitem_298, getitem_13, getitem_233, convolution_default_187, getitem_164, convolution_default_229, getitem_471, getitem_299, relu_default_98, convolution_default_16, primals_580, getitem_340, relu_default_138, getitem_426, getitem_163, relu_default_86, primals_586, getitem_470, convolution_default_185, getitem_425, relu_default_136, convolution_default_128, getitem_12, convolution_default_127, convolution_default_162, avg_pool2d_default_1, getitem_344, convolution_default_147, primals_591, relu_default_123, primals_589, getitem_302, getitem_343, avg_pool2d_default_4, getitem_237, getitem_301, getitem_52, convolution_default_255, convolution_default_256, relu_default_99, convolution_default_231, getitem_236, relu_default_87, getitem_166, convolution_default_89, relu_default_68, primals_585, getitem_428, getitem_10, getitem_474, convolution_default_257, primals_581, getitem_473, convolution_default_232, convolution_default_90, getitem_11, primals_588, relu_default_2, relu_default_137, convolution_default_129, primals_590, getitem_53, convolution_default_163, getitem_429, getitem_168, constant_pad_nd_default_18, relu_default_124, getitem_347, primals_582, convolution_default_130, convolution_default_164, convolution_default_5, getitem_169, convolution_default_6, getitem_346, primals_329, primals_692, primals_800, getitem_189, primals_56, primals_325, primals_688, convolution_default_104, primals_314, convolution_default_278, primals_320, primals_684, primals_793, primals_799, primals_64, primals_682, primals_51, primals_798, convolution_default_277, getitem_575, primals_335, primals_66, primals_341, primals_747, convolution_default_12, getitem_188, primals_331, primals_330, primals_311, relu_default_54, primals_1096, primals_50, primals_790, primals_683, getitem_518, primals_316, primals_744, primals_803, getitem_516, primals_61, primals_344, primals_67, getitem_515, convolution_default_314, primals_336, primals_47, primals_1095, primals_321, primals_1088, convolution_default_313, primals_343, primals_1092, convolution_default_103, primals_334, relu_default_149, primals_55, primals_740, primals_59, primals_802, primals_315, primals_749, getitem_579, primals_322, getitem_192, primals_345, primals_794, primals_313, convolution_default_279, relu_default_55, primals_312, primals_697, primals_795, getitem_578, getitem_191, primals_65, primals_52, primals_687, primals_745, primals_54, primals_801, relu_default_168, primals_60, constant_pad_nd_default_34, primals_1101, primals_698, primals_1098, primals_690, primals_746, primals_748, primals_1087, convolution_default_280, primals_342, primals_340, primals_1094, primals_693, primals_1093, primals_689, primals_807, primals_1089, getitem_519, primals_1097, primals_328, primals_808, primals_327, primals_743, primals_53, primals_339, primals_696, primals_317, getitem_194, primals_1102, primals_326, convolution_default_316, primals_752, primals_691, primals_804, primals_869, primals_877, convolution_default_67, primals_880, getitem_124, getitem_126, primals_881, convolution_default_68, primals_876, primals_875, primals_870, primals_772, convolution_default_91, relu_default_35, primals_779, primals_786, primals_773, primals_787, primals_774, primals_780, primals_872, primals_776, primals_775, primals_789, primals_871, getitem_123, primals_882, primals_785, primals_788, primals_784, getitem_353, primals_883, primals_781, primals_225, primals_349, primals_221, primals_350, convolution_default_59, getitem_279, convolution_default_302, relu_default_117, convolution_default_301, primals_441, convolution_default_60, relu_default_193, relu_default_31, getitem_666, getitem_81, convolution_default_152, relu_default_80, primals_439, primals_217, primals_971, convolution_default_362, primals_484, primals_972, convolution_default_315, primals_982, getitem_108, convolution_default_361, getitem_109, primals_353, convolution_default_151, getitem_559, primals_354, getitem_110, getitem_407, relu_default_118, primals_358, primals_197, primals_215, primals_979, primals_355, primals_491, primals_980, getitem_278, getitem_669, primals_977, getitem_558, primals_348, primals_437, getitem_282, getitem_406, primals_444, primals_489, primals_206, primals_226, primals_435, primals_486, primals_229, relu_default_162, getitem_668, primals_356, primals_981, relu_default_81, primals_207, primals_978, getitem_107, primals_446, primals_490, primals_212, relu_default_194, primals_216, primals_445, primals_494, primals_220, convolution_default_220, primals_203, convolution_default_42, primals_204, relu_default_22, primals_436, relu_default_30, relu_default_163, primals_481, convolution_default_303, constant_pad_nd_default_15, primals_211, primals_230, primals_359, primals_976, convolution_default_363, getitem_106, primals_202, primals_224, primals_219, getitem_80, primals_201, convolution_default_58, convolution_default_153, convolution_default_304, relu_default_26, convolution_default_161, primals_232, getitem_409, primals_493, convolution_default_221, primals_198, primals_485, primals_438, convolution_default_43, primals_495, convolution_default_364, primals_231, primals_357, primals_210, primals_440, primals_205, convolution_default_154, primals_364, getitem_561, primals_363, constant_pad_nd_default_14, getitem_105, primals_218, primals_196, primals_362, convolution_default_222, primals_973, primals_492, getitem_562, relu_default_195, primals_1293, primals_248, primals_1300, primals_254, getitem_260, convolution_default_15, getitem_144, getitem_259, primals_1296, relu_default_41, primals_1301, relu_default_85, primals_1297, getitem_143, primals_1306, relu_default_17, primals_257, getitem_61, primals_249, primals_570, getitem_62, primals_259, primals_253, primals_260, primals_1294, relu_default_75, convolution_default_142, primals_1305, convolution_default_141, getitem_262, primals_569, primals_258, primals_1308, primals_575, primals_576, primals_1307, convolution_default_34, getitem_146, constant_pad_nd_default_3, convolution_default_79, primals_568, primals_1302, primals_1292, primals_577, getitem_265, primals_261, convolution_default_143, getitem_264, convolution_default_33, convolution_default_80, primals_574, primals_252, primals_263, constant_pad_nd_default_10, primals_1295, primals_571, getitem_148, primals_1291, relu_default_76, primals_262, getitem_149, convolution_default_244, relu_default_111, convolution_default_243, getitem_539, primals_1281, primals_1282, getitem_75, getitem_1, getitem_452, primals_1283, getitem_73, primals_1278, convolution_default_10, getitem_538, primals_1288, primals_1280, getitem_387, primals_1287, relu_default_112, getitem_451, relu_default_156, getitem_15, getitem_386, relu_default_131, relu_default_20, primals_1286, convolution_default_219, convolution_default_210, relu_default_24, convolution_default_245, avg_pool2d_default_6, getitem_541, getitem_2, getitem_542, convolution_default_13, getitem_454, getitem_16, constant_pad_nd_default_13, convolution_default_246, getitem_389, convolution_default_211, primals_1279, constant_pad_nd_default_35, getitem_455, relu_default_29, relu_default_132, getitem_72, avg_pool2d_default_7, convolution_default_212, primals_276, primals_1267, relu_default_95, primals_18, primals_273, getitem_324, getitem_602, primals_959, primals_985, convolution_default_268, primals_25, getitem_323, primals_1272, primals_13, primals_990, primals_1067, getitem_36, getitem_601, getitem_22, getitem_497, primals_17, primals_19, relu_default, relu_default_93, getitem_496, primals_1075, primals_1268, primals_277, primals_271, primals_1074, convolution_default_55, primals_965, primals_1262, primals_280, primals_1083, primals_10, relu_default_144, primals_275, primals_1084, primals_1078, getitem_21, primals_967, relu_default_175, primals_993, convolution_default_176, primals_961, primals_1000, convolution_default_19, primals_987, convolution_default_49, primals_996, primals_1261, primals_968, primals_995, convolution_default_175, primals_272, primals_1068, primals_962, convolution_default_327, constant_pad_nd_default_23, getitem_604, primals_992, getitem_55, primals_274, primals_267, primals_986, convolution_default_269, primals_23, primals_1080, primals_1269, getitem_56, primals_956, constant_pad_nd_default_27, primals_955, convolution_default_270, relu_default_5, getitem_326, getitem_606, primals_991, primals_960, primals_1273, getitem_327, primals_1082, primals_1260, getitem_499, primals_1263, convolution_default_328, constant_pad_nd_default_28, relu_default_94, primals_11, primals_1073, primals_28, convolution_default_20, primals_281, primals_1069, primals_1274, primals_1081, convolution_default_271, primals_266, primals_999, getitem_607, primals_12, primals_268, primals_994, primals_22, primals_1070, getitem_500, convolution_default_329, primals_14, primals_24, primals_1266, primals_1277, convolution_default_178, primals_27, primals_966, convolution_default_177, relu_default_145, primals_26, primals_1079, relu_default_176, primals_45, primals_176, getitem_32, getitem_647, getitem_646, convolution_default_116, convolution_default_115, primals_178, primals_167, convolution_default_17, getitem_217, relu_default_188, getitem_216, convolution_default_351, primals_166, convolution_default_352, relu_default_62, relu_default_8, getitem_650, convolution_default_11, primals_175, relu_default_189, getitem_649, convolution_default_117, primals_46, primals_170, primals_177, getitem_33, primals_161, primals_163, relu_default_199, getitem_219, primals_164, convolution_default_118, getitem_652, primals_165, primals_162, primals_172, getitem_220, relu_default_63, primals_171, convolution_default_354, convolution_default_353, getitem_367, primals_564, primals_1319, getitem_305, getitem_304, primals_555, getitem_366, primals_5, primals_1321, relu_default_88, primals_4, convolution_default_215, primals_1323, convolution_default_165, primals_554, primals_1310, primals_550, relu_default_106, convolution_default_166, primals_1315, primals_561, getitem_308, constant_pad_nd_default_8, primals_8, primals_560, primals_1322, convolution_default_199, primals_1316, relu_default_89, getitem_369, primals_562, getitem_307, primals_3, primals_551, primals_563, primals_565, cat_default_9, convolution_default_200, convolution_default_201, primals_559, primals_1314, primals_1320, primals_549, primals_9, getitem_372, primals_1324, constant_pad_nd_default_19, primals_1311, getitem_371, relu_default_100, primals_1309, getitem_310, constant_pad_nd_default_20, relu_default_107, primals_556, getitem_582, getitem_103, convolution_default_258, relu_default_48, primals_504, getitem_104, convolution_default_234, convolution_default_233, getitem_477, primals_507, getitem_581, getitem_432, getitem_434, getitem_476, getitem_172, avg_pool2d_default_3, relu_default_49, convolution_default_81, primals_508, getitem_100, getitem_431, primals_179, primals_505, primals_186, getitem_171, primals_185, primals_184, relu_default_125, relu_default_169, primals_506, relu_default_57, primals_187, convolution_default_259, convolution_default_92, convolution_default_317, primals_499, getitem_584, convolution_default_235, primals_192, primals_181, cat_default_3, primals_512, primals_498, primals_513, getitem_586, convolution_default_83, convolution_default_260, relu_default_126, primals_509, relu_default_28, convolution_default_261, convolution_default_318, getitem_174, convolution_default_236, primals_514, convolution_default_93, relu_default_139, primals_503, getitem_480, getitem_101, primals_191, getitem_479, getitem_435, getitem_587, primals_190, convolution_default_319, convolution_default_94, primals_193, primals_500, primals_180, getitem_240, primals_541, primals_650, getitem_239, constant_pad_nd_default, primals_643, primals_655, primals_646, primals_282, primals_548, primals_651, primals_536, primals_660, primals_287, primals_540, relu_default_1, relu_default_69, convolution_default_2, convolution_default_131, primals_286, primals_658, primals_288, getitem_242, convolution_default_132, primals_656, primals_659, primals_644, primals_292, primals_542, primals_547, primals_546, getitem_244, primals_283, convolution_default_133, primals_647, primals_289, primals_537, getitem_245, convolution_default_3, primals_293, primals_645, relu_default_70, primals_535, primals_545, primals_657, primals_652, relu_default_3, getitem_284, relu_default_150, primals_1021, getitem_18, convolution_default_106, convolution_default_105, relu_default_82, getitem_349, constant_pad_nd_default_2, primals_1015, convolution_default_282, getitem_197, getitem_348, convolution_default_281, getitem_285, convolution_default_155, constant_pad_nd_default_32, getitem_196, constant_pad_nd_default_26, relu_default_14, convolution_default_156, getitem_522, relu_default_56, primals_1024, getitem_288, primals_1029, getitem_521, primals_1027, avg_pool2d_default_5, relu_default_83, primals_1028, relu_default_151, convolution_default_9, getitem_287, convolution_default_107, relu_default_101, convolution_default_7, primals_1018, getitem_350, relu_default_4, getitem_199, convolution_default_283, primals_1019, convolution_default_190, convolution_default_108, getitem_290, convolution_default_284, primals_1022, primals_1020, convolution_default_8, relu_default_152, getitem_200, convolution_default_109, getitem_19, getitem_352, convolution_default_158, primals_1023, convolution_default_157, getitem_351]
        
