
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/ese_vovnet19b_dw/ese_vovnet19b_dw_backward_0/state_dict.pt'))

    
    
    def forward(self, primals_21, primals_51, primals_25, primals_55, primals_47, convolution_default_2, primals_16, primals_46, primals_50, primals_24, primals_52, primals_22, primals_56, primals_14, primals_18, primals_20, primals_42, primals_27, primals_48, primals_19, primals_43, primals_44, primals_41, primals_45, primals_28, primals_26, primals_15, primals_17, primals_9, primals_4, getitem_71, convolution_default_9, primals_10, convolution_default_10, primals_11, primals_12, getitem_70, primals_7, getitem_16, relu__default_21, convolution_default_39, primals_6, cat_default_3, getitem_74, getitem_73, primals_8, convolution_default_11, relu__default_5, relu__default_22, primals_5, getitem_17, mean_dim_3, convolution_default_40, getitem_58, primals_77, getitem_59, convolution_default_32, convolution_default_5, mul_tensor_2, to_dtype_5, relu__default_2, primals_75, getitem_8, getitem_61, getitem_62, getitem_10, primals_76, relu__default_18, convolution_default_33, convolution_default_34, cat_default, view_default, primals_160, primals_92, getitem_27, getitem_28, primals_155, convolution_default_12, relu__default_8, to_dtype_7, primals_156, relu__default_6, primals_97, primals_106, primals_151, getitem_20, primals_111, primals_80, primals_91, primals_107, primals_96, convolution_default_16, primals_82, getitem_19, t_default, primals_102, primals_86, primals_105, primals_100, mul_tensor, getitem_13, primals_95, primals_110, getitem_23, primals_162, mean_dim, primals_87, getitem_22, to_dtype_1, primals_101, convolution_default_15, primals_150, primals_112, primals_90, relu__default_4, convolution_default_14, primals_85, relu__default_7, getitem_25, primals_157, primals_81, convolution_default_13, getitem_24, primals_147, primals_161, primals_152, convolution_default_36, getitem_65, relu__default_1, getitem_64, convolution_default_3, primals_126, primals_127, relu__default_19, getitem_4, primals_136, convolution_default_35, getitem_5, getitem_7, getitem_68, primals_130, getitem_67, primals_132, primals_137, relu__default_20, primals_131, primals_125, convolution_default_37, primals_135, convolution_default_4, convolution_default_38, convolution_default_22, convolution_default_7, convolution_default, getitem_31, getitem_30, getitem_42, convolution_default_18, convolution_default_23, mul_tensor_1, to_dtype_3, relu__default_9, convolution_default_1, getitem_41, getitem_2, convolution_default_17, getitem_33, relu__default_3, getitem_44, primals_141, getitem_11, getitem_45, convolution_default_6, primals_142, relu__default, primals_146, primals_145, getitem_34, convolution_default_19, primals_140, relu__default_13, convolution_default_24, relu__default_10, convolution_default_25, getitem_48, convolution_default_27, primals_31, primals_29, primals_34, convolution_default_8, primals_71, primals_70, getitem_47, primals_65, primals_38, primals_32, primals_61, relu__default_14, primals_62, convolution_default_26, primals_60, primals_36, primals_67, getitem_1, primals_39, primals_72, getitem_51, primals_66, primals_35, getitem_50, primals_57, primals_40, primals_37, relu__default_15, convolution_default_29, primals_30, convolution_default_28, convolution_default_20, getitem_54, primals_115, getitem_37, convolution_default_30, convolution_default_21, getitem_53, getitem_36, relu__default_16, primals_117, relu__default_11, getitem_39, cat_default_2, primals_122, getitem_57, primals_120, cat_default_1, getitem_56, relu__default_12, primals_121, getitem_40, getitem_14, primals_116, relu__default_17, mean_dim_1, convolution_default_31, mean_dim_2, tangents_1, tangents_2, tangents_3, tangents_4, tangents_5, tangents_6, tangents_7, tangents_8, tangents_9, tangents_10, tangents_11, tangents_12, tangents_13, tangents_14, tangents_15, tangents_16, tangents_17, tangents_18, tangents_19, tangents_20, tangents_21, tangents_22, tangents_23, tangents_24):
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, view_default);  t_default_2 = view_default = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_1 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        view_default_2 = torch.ops.aten.view.default(mm_default, [128, 1024, 1, 1]);  mm_default = None
        expand_default = torch.ops.aten.expand.default(view_default_2, [128, 1024, 7, 7]);  view_default_2 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 49);  expand_default = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(div_scalar, relu__default_22)
        mul_tensor_5 = torch.ops.aten.mul.Tensor(div_scalar, to_dtype_7);  div_scalar = to_dtype_7 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(mul_tensor_4, [2, 3], True);  mul_tensor_4 = None
        to_dtype_8 = torch.ops.aten.to.dtype(sum_dim_int_list_1, torch.float32);  sum_dim_int_list_1 = None
        to_dtype_9 = torch.ops.aten.to.dtype(convolution_default_40, torch.float32);  convolution_default_40 = None
        gt_scalar = torch.ops.aten.gt.Scalar(to_dtype_9, -3.0)
        lt_scalar = torch.ops.aten.lt.Scalar(to_dtype_9, 3.0);  to_dtype_9 = None
        __and___tensor = torch.ops.aten.__and__.Tensor(gt_scalar, lt_scalar);  gt_scalar = lt_scalar = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(to_dtype_8, 0.16666666666666666)
        new_zeros_default_23 = torch.ops.aten.new_zeros.default(to_dtype_8, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False);  to_dtype_8 = None
        where_self = torch.ops.aten.where.self(__and___tensor, mul_tensor_6, new_zeros_default_23);  __and___tensor = mul_tensor_6 = new_zeros_default_23 = None
        to_dtype_10 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(to_dtype_10, mean_dim_3, primals_34, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_10 = mean_dim_3 = primals_34 = None
        getitem_75 = convolution_backward_default[0]
        getitem_76 = convolution_backward_default[1]
        getitem_77 = convolution_backward_default[2];  convolution_backward_default = None
        expand_default_1 = torch.ops.aten.expand.default(getitem_75, [128, 1024, 7, 7]);  getitem_75 = None
        div_scalar_1 = torch.ops.aten.div.Scalar(expand_default_1, 49);  expand_default_1 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(mul_tensor_5, div_scalar_1);  mul_tensor_5 = div_scalar_1 = None
        to_dtype_11 = torch.ops.aten.to.dtype(add_tensor_27, torch.float32);  add_tensor_27 = None
        to_dtype_12 = torch.ops.aten.to.dtype(relu__default_22, torch.float32);  relu__default_22 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_12, 0);  to_dtype_12 = None
        new_zeros_default_24 = torch.ops.aten.new_zeros.default(to_dtype_11, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar, new_zeros_default_24, to_dtype_11);  le_scalar = new_zeros_default_24 = to_dtype_11 = None
        to_dtype_13 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_13, convolution_default_39, primals_162, primals_160, primals_161, getitem_73, getitem_74, True, 1e-05, [True, True, True]);  to_dtype_13 = convolution_default_39 = primals_162 = primals_160 = primals_161 = getitem_73 = getitem_74 = None
        getitem_78 = native_batch_norm_backward_default[0]
        getitem_79 = native_batch_norm_backward_default[1]
        getitem_80 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_78, cat_default_3, primals_35, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_78 = cat_default_3 = primals_35 = None
        getitem_81 = convolution_backward_default_1[0]
        getitem_82 = convolution_backward_default_1[1];  convolution_backward_default_1 = None
        slice_tensor = torch.ops.aten.slice.Tensor(getitem_81, 1, 0, 768)
        slice_tensor_1 = torch.ops.aten.slice.Tensor(getitem_81, 1, 768, 992)
        slice_tensor_2 = torch.ops.aten.slice.Tensor(getitem_81, 1, 992, 1216)
        slice_tensor_3 = torch.ops.aten.slice.Tensor(getitem_81, 1, 1216, 1440);  getitem_81 = None
        to_dtype_14 = torch.ops.aten.to.dtype(slice_tensor_3, torch.float32);  slice_tensor_3 = None
        to_dtype_15 = torch.ops.aten.to.dtype(relu__default_21, torch.float32);  relu__default_21 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_15, 0);  to_dtype_15 = None
        new_zeros_default_25 = torch.ops.aten.new_zeros.default(to_dtype_14, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_25, to_dtype_14);  le_scalar_1 = new_zeros_default_25 = to_dtype_14 = None
        to_dtype_16 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_16, convolution_default_38, primals_157, primals_155, primals_156, getitem_70, getitem_71, True, 1e-05, [True, True, True]);  to_dtype_16 = convolution_default_38 = primals_157 = primals_155 = primals_156 = getitem_70 = getitem_71 = None
        getitem_84 = native_batch_norm_backward_default_1[0]
        getitem_85 = native_batch_norm_backward_default_1[1]
        getitem_86 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_84, convolution_default_37, primals_41, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_84 = convolution_default_37 = primals_41 = None
        getitem_87 = convolution_backward_default_2[0]
        getitem_88 = convolution_backward_default_2[1];  convolution_backward_default_2 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_87, relu__default_20, primals_40, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 224, [True, True, False]);  getitem_87 = primals_40 = None
        getitem_90 = convolution_backward_default_3[0]
        getitem_91 = convolution_backward_default_3[1];  convolution_backward_default_3 = None
        add_tensor_28 = torch.ops.aten.add.Tensor(slice_tensor_2, getitem_90);  slice_tensor_2 = getitem_90 = None
        to_dtype_17 = torch.ops.aten.to.dtype(add_tensor_28, torch.float32);  add_tensor_28 = None
        to_dtype_18 = torch.ops.aten.to.dtype(relu__default_20, torch.float32);  relu__default_20 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_18, 0);  to_dtype_18 = None
        new_zeros_default_26 = torch.ops.aten.new_zeros.default(to_dtype_17, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_26, to_dtype_17);  le_scalar_2 = new_zeros_default_26 = to_dtype_17 = None
        to_dtype_19 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_19, convolution_default_36, primals_152, primals_150, primals_151, getitem_67, getitem_68, True, 1e-05, [True, True, True]);  to_dtype_19 = convolution_default_36 = primals_152 = primals_150 = primals_151 = getitem_67 = getitem_68 = None
        getitem_93 = native_batch_norm_backward_default_2[0]
        getitem_94 = native_batch_norm_backward_default_2[1]
        getitem_95 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_93, convolution_default_35, primals_39, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_93 = convolution_default_35 = primals_39 = None
        getitem_96 = convolution_backward_default_4[0]
        getitem_97 = convolution_backward_default_4[1];  convolution_backward_default_4 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_96, relu__default_19, primals_38, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 224, [True, True, False]);  getitem_96 = primals_38 = None
        getitem_99 = convolution_backward_default_5[0]
        getitem_100 = convolution_backward_default_5[1];  convolution_backward_default_5 = None
        add_tensor_29 = torch.ops.aten.add.Tensor(slice_tensor_1, getitem_99);  slice_tensor_1 = getitem_99 = None
        to_dtype_20 = torch.ops.aten.to.dtype(add_tensor_29, torch.float32);  add_tensor_29 = None
        to_dtype_21 = torch.ops.aten.to.dtype(relu__default_19, torch.float32);  relu__default_19 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_21, 0);  to_dtype_21 = None
        new_zeros_default_27 = torch.ops.aten.new_zeros.default(to_dtype_20, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_27, to_dtype_20);  le_scalar_3 = new_zeros_default_27 = to_dtype_20 = None
        to_dtype_22 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_22, convolution_default_34, primals_147, primals_145, primals_146, getitem_64, getitem_65, True, 1e-05, [True, True, True]);  to_dtype_22 = convolution_default_34 = primals_147 = primals_145 = primals_146 = getitem_64 = getitem_65 = None
        getitem_102 = native_batch_norm_backward_default_3[0]
        getitem_103 = native_batch_norm_backward_default_3[1]
        getitem_104 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(getitem_102, convolution_default_33, primals_37, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_102 = convolution_default_33 = primals_37 = None
        getitem_105 = convolution_backward_default_6[0]
        getitem_106 = convolution_backward_default_6[1];  convolution_backward_default_6 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(getitem_105, relu__default_18, primals_36, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 224, [True, True, False]);  getitem_105 = primals_36 = None
        getitem_108 = convolution_backward_default_7[0]
        getitem_109 = convolution_backward_default_7[1];  convolution_backward_default_7 = None
        to_dtype_23 = torch.ops.aten.to.dtype(getitem_108, torch.float32);  getitem_108 = None
        to_dtype_24 = torch.ops.aten.to.dtype(relu__default_18, torch.float32);  relu__default_18 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_24, 0);  to_dtype_24 = None
        new_zeros_default_28 = torch.ops.aten.new_zeros.default(to_dtype_23, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_28, to_dtype_23);  le_scalar_4 = new_zeros_default_28 = to_dtype_23 = None
        to_dtype_25 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_25, convolution_default_32, primals_142, primals_140, primals_141, getitem_61, getitem_62, True, 1e-05, [True, True, True]);  to_dtype_25 = convolution_default_32 = primals_142 = primals_140 = primals_141 = getitem_61 = getitem_62 = None
        getitem_111 = native_batch_norm_backward_default_4[0]
        getitem_112 = native_batch_norm_backward_default_4[1]
        getitem_113 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(getitem_111, getitem_58, primals_42, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_111 = getitem_58 = primals_42 = None
        getitem_114 = convolution_backward_default_8[0]
        getitem_115 = convolution_backward_default_8[1];  convolution_backward_default_8 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(slice_tensor, getitem_114);  slice_tensor = getitem_114 = None
        max_pool2d_with_indices_backward_default = torch.ops.aten.max_pool2d_with_indices_backward.default(add_tensor_30, mul_tensor_2, [3, 3], [2, 2], [0, 0], [1, 1], True, getitem_59);  add_tensor_30 = mul_tensor_2 = getitem_59 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(max_pool2d_with_indices_backward_default, relu__default_17)
        mul_tensor_8 = torch.ops.aten.mul.Tensor(max_pool2d_with_indices_backward_default, to_dtype_5);  max_pool2d_with_indices_backward_default = to_dtype_5 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(mul_tensor_7, [2, 3], True);  mul_tensor_7 = None
        to_dtype_26 = torch.ops.aten.to.dtype(sum_dim_int_list_2, torch.float32);  sum_dim_int_list_2 = None
        to_dtype_27 = torch.ops.aten.to.dtype(convolution_default_31, torch.float32);  convolution_default_31 = None
        gt_scalar_1 = torch.ops.aten.gt.Scalar(to_dtype_27, -3.0)
        lt_scalar_1 = torch.ops.aten.lt.Scalar(to_dtype_27, 3.0);  to_dtype_27 = None
        __and___tensor_1 = torch.ops.aten.__and__.Tensor(gt_scalar_1, lt_scalar_1);  gt_scalar_1 = lt_scalar_1 = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(to_dtype_26, 0.16666666666666666)
        new_zeros_default_29 = torch.ops.aten.new_zeros.default(to_dtype_26, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False);  to_dtype_26 = None
        where_self_6 = torch.ops.aten.where.self(__and___tensor_1, mul_tensor_9, new_zeros_default_29);  __and___tensor_1 = mul_tensor_9 = new_zeros_default_29 = None
        to_dtype_28 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(to_dtype_28, mean_dim_2, primals_24, [768], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_28 = mean_dim_2 = primals_24 = None
        getitem_117 = convolution_backward_default_9[0]
        getitem_118 = convolution_backward_default_9[1]
        getitem_119 = convolution_backward_default_9[2];  convolution_backward_default_9 = None
        expand_default_2 = torch.ops.aten.expand.default(getitem_117, [128, 768, 14, 14]);  getitem_117 = None
        div_scalar_2 = torch.ops.aten.div.Scalar(expand_default_2, 196);  expand_default_2 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(mul_tensor_8, div_scalar_2);  mul_tensor_8 = div_scalar_2 = None
        to_dtype_29 = torch.ops.aten.to.dtype(add_tensor_31, torch.float32);  add_tensor_31 = None
        to_dtype_30 = torch.ops.aten.to.dtype(relu__default_17, torch.float32);  relu__default_17 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_30, 0);  to_dtype_30 = None
        new_zeros_default_30 = torch.ops.aten.new_zeros.default(to_dtype_29, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_30, to_dtype_29);  le_scalar_5 = new_zeros_default_30 = to_dtype_29 = None
        to_dtype_31 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_31, convolution_default_30, primals_137, primals_135, primals_136, getitem_56, getitem_57, True, 1e-05, [True, True, True]);  to_dtype_31 = convolution_default_30 = primals_137 = primals_135 = primals_136 = getitem_56 = getitem_57 = None
        getitem_120 = native_batch_norm_backward_default_5[0]
        getitem_121 = native_batch_norm_backward_default_5[1]
        getitem_122 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_120, cat_default_2, primals_25, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_120 = cat_default_2 = primals_25 = None
        getitem_123 = convolution_backward_default_10[0]
        getitem_124 = convolution_backward_default_10[1];  convolution_backward_default_10 = None
        slice_tensor_4 = torch.ops.aten.slice.Tensor(getitem_123, 1, 0, 512)
        slice_tensor_5 = torch.ops.aten.slice.Tensor(getitem_123, 1, 512, 704)
        slice_tensor_6 = torch.ops.aten.slice.Tensor(getitem_123, 1, 704, 896)
        slice_tensor_7 = torch.ops.aten.slice.Tensor(getitem_123, 1, 896, 1088);  getitem_123 = None
        to_dtype_32 = torch.ops.aten.to.dtype(slice_tensor_7, torch.float32);  slice_tensor_7 = None
        to_dtype_33 = torch.ops.aten.to.dtype(relu__default_16, torch.float32);  relu__default_16 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_33, 0);  to_dtype_33 = None
        new_zeros_default_31 = torch.ops.aten.new_zeros.default(to_dtype_32, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_31, to_dtype_32);  le_scalar_6 = new_zeros_default_31 = to_dtype_32 = None
        to_dtype_34 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_34, convolution_default_29, primals_132, primals_130, primals_131, getitem_53, getitem_54, True, 1e-05, [True, True, True]);  to_dtype_34 = convolution_default_29 = primals_132 = primals_130 = primals_131 = getitem_53 = getitem_54 = None
        getitem_126 = native_batch_norm_backward_default_6[0]
        getitem_127 = native_batch_norm_backward_default_6[1]
        getitem_128 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_126, convolution_default_28, primals_31, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_126 = convolution_default_28 = primals_31 = None
        getitem_129 = convolution_backward_default_11[0]
        getitem_130 = convolution_backward_default_11[1];  convolution_backward_default_11 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(getitem_129, relu__default_15, primals_30, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 192, [True, True, False]);  getitem_129 = primals_30 = None
        getitem_132 = convolution_backward_default_12[0]
        getitem_133 = convolution_backward_default_12[1];  convolution_backward_default_12 = None
        add_tensor_32 = torch.ops.aten.add.Tensor(slice_tensor_6, getitem_132);  slice_tensor_6 = getitem_132 = None
        to_dtype_35 = torch.ops.aten.to.dtype(add_tensor_32, torch.float32);  add_tensor_32 = None
        to_dtype_36 = torch.ops.aten.to.dtype(relu__default_15, torch.float32);  relu__default_15 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_36, 0);  to_dtype_36 = None
        new_zeros_default_32 = torch.ops.aten.new_zeros.default(to_dtype_35, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_32, to_dtype_35);  le_scalar_7 = new_zeros_default_32 = to_dtype_35 = None
        to_dtype_37 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_37, convolution_default_27, primals_127, primals_125, primals_126, getitem_50, getitem_51, True, 1e-05, [True, True, True]);  to_dtype_37 = convolution_default_27 = primals_127 = primals_125 = primals_126 = getitem_50 = getitem_51 = None
        getitem_135 = native_batch_norm_backward_default_7[0]
        getitem_136 = native_batch_norm_backward_default_7[1]
        getitem_137 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_135, convolution_default_26, primals_29, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_135 = convolution_default_26 = primals_29 = None
        getitem_138 = convolution_backward_default_13[0]
        getitem_139 = convolution_backward_default_13[1];  convolution_backward_default_13 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_138, relu__default_14, primals_28, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 192, [True, True, False]);  getitem_138 = primals_28 = None
        getitem_141 = convolution_backward_default_14[0]
        getitem_142 = convolution_backward_default_14[1];  convolution_backward_default_14 = None
        add_tensor_33 = torch.ops.aten.add.Tensor(slice_tensor_5, getitem_141);  slice_tensor_5 = getitem_141 = None
        to_dtype_38 = torch.ops.aten.to.dtype(add_tensor_33, torch.float32);  add_tensor_33 = None
        to_dtype_39 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_39, 0);  to_dtype_39 = None
        new_zeros_default_33 = torch.ops.aten.new_zeros.default(to_dtype_38, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_33, to_dtype_38);  le_scalar_8 = new_zeros_default_33 = to_dtype_38 = None
        to_dtype_40 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_40, convolution_default_25, primals_122, primals_120, primals_121, getitem_47, getitem_48, True, 1e-05, [True, True, True]);  to_dtype_40 = convolution_default_25 = primals_122 = primals_120 = primals_121 = getitem_47 = getitem_48 = None
        getitem_144 = native_batch_norm_backward_default_8[0]
        getitem_145 = native_batch_norm_backward_default_8[1]
        getitem_146 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_144, convolution_default_24, primals_27, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_144 = convolution_default_24 = primals_27 = None
        getitem_147 = convolution_backward_default_15[0]
        getitem_148 = convolution_backward_default_15[1];  convolution_backward_default_15 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(getitem_147, relu__default_13, primals_26, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 192, [True, True, False]);  getitem_147 = primals_26 = None
        getitem_150 = convolution_backward_default_16[0]
        getitem_151 = convolution_backward_default_16[1];  convolution_backward_default_16 = None
        to_dtype_41 = torch.ops.aten.to.dtype(getitem_150, torch.float32);  getitem_150 = None
        to_dtype_42 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_42, 0);  to_dtype_42 = None
        new_zeros_default_34 = torch.ops.aten.new_zeros.default(to_dtype_41, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_34, to_dtype_41);  le_scalar_9 = new_zeros_default_34 = to_dtype_41 = None
        to_dtype_43 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_43, convolution_default_23, primals_117, primals_115, primals_116, getitem_44, getitem_45, True, 1e-05, [True, True, True]);  to_dtype_43 = convolution_default_23 = primals_117 = primals_115 = primals_116 = getitem_44 = getitem_45 = None
        getitem_153 = native_batch_norm_backward_default_9[0]
        getitem_154 = native_batch_norm_backward_default_9[1]
        getitem_155 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(getitem_153, getitem_41, primals_32, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_153 = getitem_41 = primals_32 = None
        getitem_156 = convolution_backward_default_17[0]
        getitem_157 = convolution_backward_default_17[1];  convolution_backward_default_17 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(slice_tensor_4, getitem_156);  slice_tensor_4 = getitem_156 = None
        max_pool2d_with_indices_backward_default_1 = torch.ops.aten.max_pool2d_with_indices_backward.default(add_tensor_34, mul_tensor_1, [3, 3], [2, 2], [0, 0], [1, 1], True, getitem_42);  add_tensor_34 = mul_tensor_1 = getitem_42 = None
        mul_tensor_10 = torch.ops.aten.mul.Tensor(max_pool2d_with_indices_backward_default_1, relu__default_12)
        mul_tensor_11 = torch.ops.aten.mul.Tensor(max_pool2d_with_indices_backward_default_1, to_dtype_3);  max_pool2d_with_indices_backward_default_1 = to_dtype_3 = None
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(mul_tensor_10, [2, 3], True);  mul_tensor_10 = None
        to_dtype_44 = torch.ops.aten.to.dtype(sum_dim_int_list_3, torch.float32);  sum_dim_int_list_3 = None
        to_dtype_45 = torch.ops.aten.to.dtype(convolution_default_22, torch.float32);  convolution_default_22 = None
        gt_scalar_2 = torch.ops.aten.gt.Scalar(to_dtype_45, -3.0)
        lt_scalar_2 = torch.ops.aten.lt.Scalar(to_dtype_45, 3.0);  to_dtype_45 = None
        __and___tensor_2 = torch.ops.aten.__and__.Tensor(gt_scalar_2, lt_scalar_2);  gt_scalar_2 = lt_scalar_2 = None
        mul_tensor_12 = torch.ops.aten.mul.Tensor(to_dtype_44, 0.16666666666666666)
        new_zeros_default_35 = torch.ops.aten.new_zeros.default(to_dtype_44, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False);  to_dtype_44 = None
        where_self_12 = torch.ops.aten.where.self(__and___tensor_2, mul_tensor_12, new_zeros_default_35);  __and___tensor_2 = mul_tensor_12 = new_zeros_default_35 = None
        to_dtype_46 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(to_dtype_46, mean_dim_1, primals_14, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_46 = mean_dim_1 = primals_14 = None
        getitem_159 = convolution_backward_default_18[0]
        getitem_160 = convolution_backward_default_18[1]
        getitem_161 = convolution_backward_default_18[2];  convolution_backward_default_18 = None
        expand_default_3 = torch.ops.aten.expand.default(getitem_159, [128, 512, 28, 28]);  getitem_159 = None
        div_scalar_3 = torch.ops.aten.div.Scalar(expand_default_3, 784);  expand_default_3 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(mul_tensor_11, div_scalar_3);  mul_tensor_11 = div_scalar_3 = None
        to_dtype_47 = torch.ops.aten.to.dtype(add_tensor_35, torch.float32);  add_tensor_35 = None
        to_dtype_48 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_48, 0);  to_dtype_48 = None
        new_zeros_default_36 = torch.ops.aten.new_zeros.default(to_dtype_47, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_36, to_dtype_47);  le_scalar_10 = new_zeros_default_36 = to_dtype_47 = None
        to_dtype_49 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_49, convolution_default_21, primals_112, primals_110, primals_111, getitem_39, getitem_40, True, 1e-05, [True, True, True]);  to_dtype_49 = convolution_default_21 = primals_112 = primals_110 = primals_111 = getitem_39 = getitem_40 = None
        getitem_162 = native_batch_norm_backward_default_10[0]
        getitem_163 = native_batch_norm_backward_default_10[1]
        getitem_164 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_162, cat_default_1, primals_15, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_162 = cat_default_1 = primals_15 = None
        getitem_165 = convolution_backward_default_19[0]
        getitem_166 = convolution_backward_default_19[1];  convolution_backward_default_19 = None
        slice_tensor_8 = torch.ops.aten.slice.Tensor(getitem_165, 1, 0, 256)
        slice_tensor_9 = torch.ops.aten.slice.Tensor(getitem_165, 1, 256, 416)
        slice_tensor_10 = torch.ops.aten.slice.Tensor(getitem_165, 1, 416, 576)
        slice_tensor_11 = torch.ops.aten.slice.Tensor(getitem_165, 1, 576, 736);  getitem_165 = None
        to_dtype_50 = torch.ops.aten.to.dtype(slice_tensor_11, torch.float32);  slice_tensor_11 = None
        to_dtype_51 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_51, 0);  to_dtype_51 = None
        new_zeros_default_37 = torch.ops.aten.new_zeros.default(to_dtype_50, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_37, to_dtype_50);  le_scalar_11 = new_zeros_default_37 = to_dtype_50 = None
        to_dtype_52 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_52, convolution_default_20, primals_107, primals_105, primals_106, getitem_36, getitem_37, True, 1e-05, [True, True, True]);  to_dtype_52 = convolution_default_20 = primals_107 = primals_105 = primals_106 = getitem_36 = getitem_37 = None
        getitem_168 = native_batch_norm_backward_default_11[0]
        getitem_169 = native_batch_norm_backward_default_11[1]
        getitem_170 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(getitem_168, convolution_default_19, primals_21, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_168 = convolution_default_19 = primals_21 = None
        getitem_171 = convolution_backward_default_20[0]
        getitem_172 = convolution_backward_default_20[1];  convolution_backward_default_20 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(getitem_171, relu__default_10, primals_20, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 160, [True, True, False]);  getitem_171 = primals_20 = None
        getitem_174 = convolution_backward_default_21[0]
        getitem_175 = convolution_backward_default_21[1];  convolution_backward_default_21 = None
        add_tensor_36 = torch.ops.aten.add.Tensor(slice_tensor_10, getitem_174);  slice_tensor_10 = getitem_174 = None
        to_dtype_53 = torch.ops.aten.to.dtype(add_tensor_36, torch.float32);  add_tensor_36 = None
        to_dtype_54 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_54, 0);  to_dtype_54 = None
        new_zeros_default_38 = torch.ops.aten.new_zeros.default(to_dtype_53, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_38, to_dtype_53);  le_scalar_12 = new_zeros_default_38 = to_dtype_53 = None
        to_dtype_55 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_55, convolution_default_18, primals_102, primals_100, primals_101, getitem_33, getitem_34, True, 1e-05, [True, True, True]);  to_dtype_55 = convolution_default_18 = primals_102 = primals_100 = primals_101 = getitem_33 = getitem_34 = None
        getitem_177 = native_batch_norm_backward_default_12[0]
        getitem_178 = native_batch_norm_backward_default_12[1]
        getitem_179 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(getitem_177, convolution_default_17, primals_19, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_177 = convolution_default_17 = primals_19 = None
        getitem_180 = convolution_backward_default_22[0]
        getitem_181 = convolution_backward_default_22[1];  convolution_backward_default_22 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(getitem_180, relu__default_9, primals_18, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 160, [True, True, False]);  getitem_180 = primals_18 = None
        getitem_183 = convolution_backward_default_23[0]
        getitem_184 = convolution_backward_default_23[1];  convolution_backward_default_23 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(slice_tensor_9, getitem_183);  slice_tensor_9 = getitem_183 = None
        to_dtype_56 = torch.ops.aten.to.dtype(add_tensor_37, torch.float32);  add_tensor_37 = None
        to_dtype_57 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_57, 0);  to_dtype_57 = None
        new_zeros_default_39 = torch.ops.aten.new_zeros.default(to_dtype_56, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_39, to_dtype_56);  le_scalar_13 = new_zeros_default_39 = to_dtype_56 = None
        to_dtype_58 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_58, convolution_default_16, primals_97, primals_95, primals_96, getitem_30, getitem_31, True, 1e-05, [True, True, True]);  to_dtype_58 = convolution_default_16 = primals_97 = primals_95 = primals_96 = getitem_30 = getitem_31 = None
        getitem_186 = native_batch_norm_backward_default_13[0]
        getitem_187 = native_batch_norm_backward_default_13[1]
        getitem_188 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_186, convolution_default_15, primals_17, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_186 = convolution_default_15 = primals_17 = None
        getitem_189 = convolution_backward_default_24[0]
        getitem_190 = convolution_backward_default_24[1];  convolution_backward_default_24 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_189, relu__default_8, primals_16, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 160, [True, True, False]);  getitem_189 = primals_16 = None
        getitem_192 = convolution_backward_default_25[0]
        getitem_193 = convolution_backward_default_25[1];  convolution_backward_default_25 = None
        to_dtype_59 = torch.ops.aten.to.dtype(getitem_192, torch.float32);  getitem_192 = None
        to_dtype_60 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_60, 0);  to_dtype_60 = None
        new_zeros_default_40 = torch.ops.aten.new_zeros.default(to_dtype_59, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_40, to_dtype_59);  le_scalar_14 = new_zeros_default_40 = to_dtype_59 = None
        to_dtype_61 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_61, convolution_default_14, primals_92, primals_90, primals_91, getitem_27, getitem_28, True, 1e-05, [True, True, True]);  to_dtype_61 = convolution_default_14 = primals_92 = primals_90 = primals_91 = getitem_27 = getitem_28 = None
        getitem_195 = native_batch_norm_backward_default_14[0]
        getitem_196 = native_batch_norm_backward_default_14[1]
        getitem_197 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(getitem_195, getitem_24, primals_22, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_195 = getitem_24 = primals_22 = None
        getitem_198 = convolution_backward_default_26[0]
        getitem_199 = convolution_backward_default_26[1];  convolution_backward_default_26 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(slice_tensor_8, getitem_198);  slice_tensor_8 = getitem_198 = None
        max_pool2d_with_indices_backward_default_2 = torch.ops.aten.max_pool2d_with_indices_backward.default(add_tensor_38, mul_tensor, [3, 3], [2, 2], [0, 0], [1, 1], True, getitem_25);  add_tensor_38 = mul_tensor = getitem_25 = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(max_pool2d_with_indices_backward_default_2, relu__default_7)
        mul_tensor_14 = torch.ops.aten.mul.Tensor(max_pool2d_with_indices_backward_default_2, to_dtype_1);  max_pool2d_with_indices_backward_default_2 = to_dtype_1 = None
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(mul_tensor_13, [2, 3], True);  mul_tensor_13 = None
        to_dtype_62 = torch.ops.aten.to.dtype(sum_dim_int_list_4, torch.float32);  sum_dim_int_list_4 = None
        to_dtype_63 = torch.ops.aten.to.dtype(convolution_default_13, torch.float32);  convolution_default_13 = None
        gt_scalar_3 = torch.ops.aten.gt.Scalar(to_dtype_63, -3.0)
        lt_scalar_3 = torch.ops.aten.lt.Scalar(to_dtype_63, 3.0);  to_dtype_63 = None
        __and___tensor_3 = torch.ops.aten.__and__.Tensor(gt_scalar_3, lt_scalar_3);  gt_scalar_3 = lt_scalar_3 = None
        mul_tensor_15 = torch.ops.aten.mul.Tensor(to_dtype_62, 0.16666666666666666)
        new_zeros_default_41 = torch.ops.aten.new_zeros.default(to_dtype_62, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False);  to_dtype_62 = None
        where_self_18 = torch.ops.aten.where.self(__and___tensor_3, mul_tensor_15, new_zeros_default_41);  __and___tensor_3 = mul_tensor_15 = new_zeros_default_41 = None
        to_dtype_64 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(to_dtype_64, mean_dim, primals_4, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_64 = mean_dim = primals_4 = None
        getitem_201 = convolution_backward_default_27[0]
        getitem_202 = convolution_backward_default_27[1]
        getitem_203 = convolution_backward_default_27[2];  convolution_backward_default_27 = None
        expand_default_4 = torch.ops.aten.expand.default(getitem_201, [128, 256, 56, 56]);  getitem_201 = None
        div_scalar_4 = torch.ops.aten.div.Scalar(expand_default_4, 3136);  expand_default_4 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(mul_tensor_14, div_scalar_4);  mul_tensor_14 = div_scalar_4 = None
        to_dtype_65 = torch.ops.aten.to.dtype(add_tensor_39, torch.float32);  add_tensor_39 = None
        to_dtype_66 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_66, 0);  to_dtype_66 = None
        new_zeros_default_42 = torch.ops.aten.new_zeros.default(to_dtype_65, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_19 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_42, to_dtype_65);  le_scalar_15 = new_zeros_default_42 = to_dtype_65 = None
        to_dtype_67 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_67, convolution_default_12, primals_87, primals_85, primals_86, getitem_22, getitem_23, True, 1e-05, [True, True, True]);  to_dtype_67 = convolution_default_12 = primals_87 = primals_85 = primals_86 = getitem_22 = getitem_23 = None
        getitem_204 = native_batch_norm_backward_default_15[0]
        getitem_205 = native_batch_norm_backward_default_15[1]
        getitem_206 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(getitem_204, cat_default, primals_5, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_204 = cat_default = primals_5 = None
        getitem_207 = convolution_backward_default_28[0]
        getitem_208 = convolution_backward_default_28[1];  convolution_backward_default_28 = None
        slice_tensor_12 = torch.ops.aten.slice.Tensor(getitem_207, 1, 0, 64)
        slice_tensor_13 = torch.ops.aten.slice.Tensor(getitem_207, 1, 64, 192)
        slice_tensor_14 = torch.ops.aten.slice.Tensor(getitem_207, 1, 192, 320)
        slice_tensor_15 = torch.ops.aten.slice.Tensor(getitem_207, 1, 320, 448);  getitem_207 = None
        to_dtype_68 = torch.ops.aten.to.dtype(slice_tensor_15, torch.float32);  slice_tensor_15 = None
        to_dtype_69 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_69, 0);  to_dtype_69 = None
        new_zeros_default_43 = torch.ops.aten.new_zeros.default(to_dtype_68, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_20 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_43, to_dtype_68);  le_scalar_16 = new_zeros_default_43 = to_dtype_68 = None
        to_dtype_70 = torch.ops.aten.to.dtype(where_self_20, torch.float32);  where_self_20 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_70, convolution_default_11, primals_82, primals_80, primals_81, getitem_19, getitem_20, True, 1e-05, [True, True, True]);  to_dtype_70 = convolution_default_11 = primals_82 = primals_80 = primals_81 = getitem_19 = getitem_20 = None
        getitem_210 = native_batch_norm_backward_default_16[0]
        getitem_211 = native_batch_norm_backward_default_16[1]
        getitem_212 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(getitem_210, convolution_default_10, primals_11, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_210 = convolution_default_10 = primals_11 = None
        getitem_213 = convolution_backward_default_29[0]
        getitem_214 = convolution_backward_default_29[1];  convolution_backward_default_29 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_213, relu__default_5, primals_10, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 128, [True, True, False]);  getitem_213 = primals_10 = None
        getitem_216 = convolution_backward_default_30[0]
        getitem_217 = convolution_backward_default_30[1];  convolution_backward_default_30 = None
        add_tensor_40 = torch.ops.aten.add.Tensor(slice_tensor_14, getitem_216);  slice_tensor_14 = getitem_216 = None
        to_dtype_71 = torch.ops.aten.to.dtype(add_tensor_40, torch.float32);  add_tensor_40 = None
        to_dtype_72 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_72, 0);  to_dtype_72 = None
        new_zeros_default_44 = torch.ops.aten.new_zeros.default(to_dtype_71, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_21 = torch.ops.aten.where.self(le_scalar_17, new_zeros_default_44, to_dtype_71);  le_scalar_17 = new_zeros_default_44 = to_dtype_71 = None
        to_dtype_73 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_73, convolution_default_9, primals_77, primals_75, primals_76, getitem_16, getitem_17, True, 1e-05, [True, True, True]);  to_dtype_73 = convolution_default_9 = primals_77 = primals_75 = primals_76 = getitem_16 = getitem_17 = None
        getitem_219 = native_batch_norm_backward_default_17[0]
        getitem_220 = native_batch_norm_backward_default_17[1]
        getitem_221 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(getitem_219, convolution_default_8, primals_9, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_219 = convolution_default_8 = primals_9 = None
        getitem_222 = convolution_backward_default_31[0]
        getitem_223 = convolution_backward_default_31[1];  convolution_backward_default_31 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(getitem_222, relu__default_4, primals_8, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 128, [True, True, False]);  getitem_222 = primals_8 = None
        getitem_225 = convolution_backward_default_32[0]
        getitem_226 = convolution_backward_default_32[1];  convolution_backward_default_32 = None
        add_tensor_41 = torch.ops.aten.add.Tensor(slice_tensor_13, getitem_225);  slice_tensor_13 = getitem_225 = None
        to_dtype_74 = torch.ops.aten.to.dtype(add_tensor_41, torch.float32);  add_tensor_41 = None
        to_dtype_75 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_75, 0);  to_dtype_75 = None
        new_zeros_default_45 = torch.ops.aten.new_zeros.default(to_dtype_74, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_22 = torch.ops.aten.where.self(le_scalar_18, new_zeros_default_45, to_dtype_74);  le_scalar_18 = new_zeros_default_45 = to_dtype_74 = None
        to_dtype_76 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_76, convolution_default_7, primals_72, primals_70, primals_71, getitem_13, getitem_14, True, 1e-05, [True, True, True]);  to_dtype_76 = convolution_default_7 = primals_72 = primals_70 = primals_71 = getitem_13 = getitem_14 = None
        getitem_228 = native_batch_norm_backward_default_18[0]
        getitem_229 = native_batch_norm_backward_default_18[1]
        getitem_230 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(getitem_228, convolution_default_6, primals_7, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_228 = convolution_default_6 = primals_7 = None
        getitem_231 = convolution_backward_default_33[0]
        getitem_232 = convolution_backward_default_33[1];  convolution_backward_default_33 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(getitem_231, relu__default_3, primals_6, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 128, [True, True, False]);  getitem_231 = primals_6 = None
        getitem_234 = convolution_backward_default_34[0]
        getitem_235 = convolution_backward_default_34[1];  convolution_backward_default_34 = None
        to_dtype_77 = torch.ops.aten.to.dtype(getitem_234, torch.float32);  getitem_234 = None
        to_dtype_78 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_78, 0);  to_dtype_78 = None
        new_zeros_default_46 = torch.ops.aten.new_zeros.default(to_dtype_77, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(le_scalar_19, new_zeros_default_46, to_dtype_77);  le_scalar_19 = new_zeros_default_46 = to_dtype_77 = None
        to_dtype_79 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_79, convolution_default_5, primals_67, primals_65, primals_66, getitem_10, getitem_11, True, 1e-05, [True, True, True]);  to_dtype_79 = convolution_default_5 = primals_67 = primals_65 = primals_66 = getitem_10 = getitem_11 = None
        getitem_237 = native_batch_norm_backward_default_19[0]
        getitem_238 = native_batch_norm_backward_default_19[1]
        getitem_239 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_237, relu__default_2, primals_12, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_237 = primals_12 = None
        getitem_240 = convolution_backward_default_35[0]
        getitem_241 = convolution_backward_default_35[1];  convolution_backward_default_35 = None
        add_tensor_42 = torch.ops.aten.add.Tensor(slice_tensor_12, getitem_240);  slice_tensor_12 = getitem_240 = None
        to_dtype_80 = torch.ops.aten.to.dtype(add_tensor_42, torch.float32);  add_tensor_42 = None
        to_dtype_81 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_81, 0);  to_dtype_81 = None
        new_zeros_default_47 = torch.ops.aten.new_zeros.default(to_dtype_80, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_24 = torch.ops.aten.where.self(le_scalar_20, new_zeros_default_47, to_dtype_80);  le_scalar_20 = new_zeros_default_47 = to_dtype_80 = None
        to_dtype_82 = torch.ops.aten.to.dtype(where_self_24, torch.float32);  where_self_24 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_82, convolution_default_4, primals_62, primals_60, primals_61, getitem_7, getitem_8, True, 1e-05, [True, True, True]);  to_dtype_82 = convolution_default_4 = primals_62 = primals_60 = primals_61 = getitem_7 = getitem_8 = None
        getitem_243 = native_batch_norm_backward_default_20[0]
        getitem_244 = native_batch_norm_backward_default_20[1]
        getitem_245 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(getitem_243, convolution_default_3, primals_47, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_243 = convolution_default_3 = primals_47 = None
        getitem_246 = convolution_backward_default_36[0]
        getitem_247 = convolution_backward_default_36[1];  convolution_backward_default_36 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(getitem_246, relu__default_1, primals_46, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 64, [True, True, False]);  getitem_246 = primals_46 = None
        getitem_249 = convolution_backward_default_37[0]
        getitem_250 = convolution_backward_default_37[1];  convolution_backward_default_37 = None
        to_dtype_83 = torch.ops.aten.to.dtype(getitem_249, torch.float32);  getitem_249 = None
        to_dtype_84 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_84, 0);  to_dtype_84 = None
        new_zeros_default_48 = torch.ops.aten.new_zeros.default(to_dtype_83, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_25 = torch.ops.aten.where.self(le_scalar_21, new_zeros_default_48, to_dtype_83);  le_scalar_21 = new_zeros_default_48 = to_dtype_83 = None
        to_dtype_85 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_85, convolution_default_2, primals_57, primals_55, primals_56, getitem_4, getitem_5, True, 1e-05, [True, True, True]);  to_dtype_85 = convolution_default_2 = primals_57 = primals_55 = primals_56 = getitem_4 = getitem_5 = None
        getitem_252 = native_batch_norm_backward_default_21[0]
        getitem_253 = native_batch_norm_backward_default_21[1]
        getitem_254 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(getitem_252, convolution_default_1, primals_45, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_252 = convolution_default_1 = primals_45 = None
        getitem_255 = convolution_backward_default_38[0]
        getitem_256 = convolution_backward_default_38[1];  convolution_backward_default_38 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(getitem_255, relu__default, primals_44, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 64, [True, True, False]);  getitem_255 = primals_44 = None
        getitem_258 = convolution_backward_default_39[0]
        getitem_259 = convolution_backward_default_39[1];  convolution_backward_default_39 = None
        to_dtype_86 = torch.ops.aten.to.dtype(getitem_258, torch.float32);  getitem_258 = None
        to_dtype_87 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_87, 0);  to_dtype_87 = None
        new_zeros_default_49 = torch.ops.aten.new_zeros.default(to_dtype_86, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_26 = torch.ops.aten.where.self(le_scalar_22, new_zeros_default_49, to_dtype_86);  le_scalar_22 = new_zeros_default_49 = to_dtype_86 = None
        to_dtype_88 = torch.ops.aten.to.dtype(where_self_26, torch.float32);  where_self_26 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_88, convolution_default, primals_52, primals_50, primals_51, getitem_1, getitem_2, True, 1e-05, [True, True, True]);  to_dtype_88 = convolution_default = primals_52 = primals_50 = primals_51 = getitem_1 = getitem_2 = None
        getitem_261 = native_batch_norm_backward_default_22[0]
        getitem_262 = native_batch_norm_backward_default_22[1]
        getitem_263 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(getitem_261, primals_48, primals_43, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_261 = primals_48 = primals_43 = None
        getitem_265 = convolution_backward_default_40[1];  convolution_backward_default_40 = None
        return [view_default_1, t_default_4, getitem_203, getitem_202, getitem_208, getitem_235, getitem_232, getitem_226, getitem_223, getitem_217, getitem_214, getitem_241, getitem_161, getitem_160, getitem_166, getitem_193, getitem_190, getitem_184, getitem_181, getitem_175, getitem_172, getitem_199, getitem_119, getitem_118, getitem_124, getitem_151, getitem_148, getitem_142, getitem_139, getitem_133, getitem_130, getitem_157, getitem_77, getitem_76, getitem_82, getitem_109, getitem_106, getitem_100, getitem_97, getitem_91, getitem_88, getitem_115, getitem_265, getitem_259, getitem_256, getitem_250, getitem_247, None, None, None, None, getitem_262, getitem_263, None, None, None, getitem_253, getitem_254, None, None, None, getitem_244, getitem_245, None, None, None, getitem_238, getitem_239, None, None, None, getitem_229, getitem_230, None, None, None, getitem_220, getitem_221, None, None, None, getitem_211, getitem_212, None, None, None, getitem_205, getitem_206, None, None, None, getitem_196, getitem_197, None, None, None, getitem_187, getitem_188, None, None, None, getitem_178, getitem_179, None, None, None, getitem_169, getitem_170, None, None, None, getitem_163, getitem_164, None, None, None, getitem_154, getitem_155, None, None, None, getitem_145, getitem_146, None, None, None, getitem_136, getitem_137, None, None, None, getitem_127, getitem_128, None, None, None, getitem_121, getitem_122, None, None, None, getitem_112, getitem_113, None, None, None, getitem_103, getitem_104, None, None, None, getitem_94, getitem_95, None, None, None, getitem_85, getitem_86, None, None, None, getitem_79, getitem_80]
        
