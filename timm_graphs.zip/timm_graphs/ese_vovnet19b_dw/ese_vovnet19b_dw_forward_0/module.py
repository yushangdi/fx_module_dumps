
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/ese_vovnet19b_dw/ese_vovnet19b_dw_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163):
        convolution_default = torch.ops.aten.convolution.default(primals_48, primals_43, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor = torch.ops.aten.add.Tensor(primals_49, 1);  primals_49 = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_52, primals_53, primals_50, primals_51, True, 0.1, 1e-05);  primals_53 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default, primals_44, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        convolution_default_2 = torch.ops.aten.convolution.default(convolution_default_1, primals_45, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_1 = torch.ops.aten.add.Tensor(primals_54, 1);  primals_54 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_57, primals_58, primals_55, primals_56, True, 0.1, 1e-05);  primals_58 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        relu__default_1 = torch.ops.aten.relu_.default(getitem_3);  getitem_3 = None
        convolution_default_3 = torch.ops.aten.convolution.default(relu__default_1, primals_46, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 64)
        convolution_default_4 = torch.ops.aten.convolution.default(convolution_default_3, primals_47, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_2 = torch.ops.aten.add.Tensor(primals_59, 1);  primals_59 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_62, primals_63, primals_60, primals_61, True, 0.1, 1e-05);  primals_63 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        relu__default_2 = torch.ops.aten.relu_.default(getitem_6);  getitem_6 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_2, primals_12, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_3 = torch.ops.aten.add.Tensor(primals_64, 1);  primals_64 = None
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_67, primals_68, primals_65, primals_66, True, 0.1, 1e-05);  primals_68 = None
        getitem_9 = native_batch_norm_default_3[0]
        getitem_10 = native_batch_norm_default_3[1]
        getitem_11 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        relu__default_3 = torch.ops.aten.relu_.default(getitem_9);  getitem_9 = None
        convolution_default_6 = torch.ops.aten.convolution.default(relu__default_3, primals_6, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 128)
        convolution_default_7 = torch.ops.aten.convolution.default(convolution_default_6, primals_7, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_4 = torch.ops.aten.add.Tensor(primals_69, 1);  primals_69 = None
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_72, primals_73, primals_70, primals_71, True, 0.1, 1e-05);  primals_73 = None
        getitem_12 = native_batch_norm_default_4[0]
        getitem_13 = native_batch_norm_default_4[1]
        getitem_14 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        relu__default_4 = torch.ops.aten.relu_.default(getitem_12);  getitem_12 = None
        convolution_default_8 = torch.ops.aten.convolution.default(relu__default_4, primals_8, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 128)
        convolution_default_9 = torch.ops.aten.convolution.default(convolution_default_8, primals_9, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_5 = torch.ops.aten.add.Tensor(primals_74, 1);  primals_74 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_77, primals_78, primals_75, primals_76, True, 0.1, 1e-05);  primals_78 = None
        getitem_15 = native_batch_norm_default_5[0]
        getitem_16 = native_batch_norm_default_5[1]
        getitem_17 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        relu__default_5 = torch.ops.aten.relu_.default(getitem_15);  getitem_15 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default_5, primals_10, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 128)
        convolution_default_11 = torch.ops.aten.convolution.default(convolution_default_10, primals_11, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_6 = torch.ops.aten.add.Tensor(primals_79, 1);  primals_79 = None
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_82, primals_83, primals_80, primals_81, True, 0.1, 1e-05);  primals_83 = None
        getitem_18 = native_batch_norm_default_6[0]
        getitem_19 = native_batch_norm_default_6[1]
        getitem_20 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        relu__default_6 = torch.ops.aten.relu_.default(getitem_18);  getitem_18 = None
        cat_default = torch.ops.aten.cat.default([relu__default_2, relu__default_4, relu__default_5, relu__default_6], 1)
        convolution_default_12 = torch.ops.aten.convolution.default(cat_default, primals_5, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_7 = torch.ops.aten.add.Tensor(primals_84, 1);  primals_84 = None
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_87, primals_88, primals_85, primals_86, True, 0.1, 1e-05);  primals_88 = None
        getitem_21 = native_batch_norm_default_7[0]
        getitem_22 = native_batch_norm_default_7[1]
        getitem_23 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        relu__default_7 = torch.ops.aten.relu_.default(getitem_21);  getitem_21 = None
        mean_dim = torch.ops.aten.mean.dim(relu__default_7, [2, 3], True)
        convolution_default_13 = torch.ops.aten.convolution.default(mean_dim, primals_4, primals_3, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_3 = None
        to_dtype = torch.ops.aten.to.dtype(convolution_default_13, torch.float32)
        add_tensor_8 = torch.ops.aten.add.Tensor(to_dtype, 3);  to_dtype = None
        clamp_default = torch.ops.aten.clamp.default(add_tensor_8, 0);  add_tensor_8 = None
        clamp_default_1 = torch.ops.aten.clamp.default(clamp_default, None, 6);  clamp_default = None
        div_tensor = torch.ops.aten.div.Tensor(clamp_default_1, 6);  clamp_default_1 = None
        to_dtype_1 = torch.ops.aten.to.dtype(div_tensor, torch.float32);  div_tensor = None
        mul_tensor = torch.ops.aten.mul.Tensor(relu__default_7, to_dtype_1)
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(mul_tensor, [3, 3], [2, 2], [0, 0], [1, 1], True)
        getitem_24 = max_pool2d_with_indices_default[0]
        getitem_25 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_14 = torch.ops.aten.convolution.default(getitem_24, primals_22, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_9 = torch.ops.aten.add.Tensor(primals_89, 1);  primals_89 = None
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_92, primals_93, primals_90, primals_91, True, 0.1, 1e-05);  primals_93 = None
        getitem_26 = native_batch_norm_default_8[0]
        getitem_27 = native_batch_norm_default_8[1]
        getitem_28 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        relu__default_8 = torch.ops.aten.relu_.default(getitem_26);  getitem_26 = None
        convolution_default_15 = torch.ops.aten.convolution.default(relu__default_8, primals_16, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 160)
        convolution_default_16 = torch.ops.aten.convolution.default(convolution_default_15, primals_17, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_10 = torch.ops.aten.add.Tensor(primals_94, 1);  primals_94 = None
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_97, primals_98, primals_95, primals_96, True, 0.1, 1e-05);  primals_98 = None
        getitem_29 = native_batch_norm_default_9[0]
        getitem_30 = native_batch_norm_default_9[1]
        getitem_31 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        relu__default_9 = torch.ops.aten.relu_.default(getitem_29);  getitem_29 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu__default_9, primals_18, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 160)
        convolution_default_18 = torch.ops.aten.convolution.default(convolution_default_17, primals_19, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_11 = torch.ops.aten.add.Tensor(primals_99, 1);  primals_99 = None
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_102, primals_103, primals_100, primals_101, True, 0.1, 1e-05);  primals_103 = None
        getitem_32 = native_batch_norm_default_10[0]
        getitem_33 = native_batch_norm_default_10[1]
        getitem_34 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        relu__default_10 = torch.ops.aten.relu_.default(getitem_32);  getitem_32 = None
        convolution_default_19 = torch.ops.aten.convolution.default(relu__default_10, primals_20, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 160)
        convolution_default_20 = torch.ops.aten.convolution.default(convolution_default_19, primals_21, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_12 = torch.ops.aten.add.Tensor(primals_104, 1);  primals_104 = None
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_107, primals_108, primals_105, primals_106, True, 0.1, 1e-05);  primals_108 = None
        getitem_35 = native_batch_norm_default_11[0]
        getitem_36 = native_batch_norm_default_11[1]
        getitem_37 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        relu__default_11 = torch.ops.aten.relu_.default(getitem_35);  getitem_35 = None
        cat_default_1 = torch.ops.aten.cat.default([getitem_24, relu__default_9, relu__default_10, relu__default_11], 1)
        convolution_default_21 = torch.ops.aten.convolution.default(cat_default_1, primals_15, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_13 = torch.ops.aten.add.Tensor(primals_109, 1);  primals_109 = None
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_112, primals_113, primals_110, primals_111, True, 0.1, 1e-05);  primals_113 = None
        getitem_38 = native_batch_norm_default_12[0]
        getitem_39 = native_batch_norm_default_12[1]
        getitem_40 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        relu__default_12 = torch.ops.aten.relu_.default(getitem_38);  getitem_38 = None
        mean_dim_1 = torch.ops.aten.mean.dim(relu__default_12, [2, 3], True)
        convolution_default_22 = torch.ops.aten.convolution.default(mean_dim_1, primals_14, primals_13, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_13 = None
        to_dtype_2 = torch.ops.aten.to.dtype(convolution_default_22, torch.float32)
        add_tensor_14 = torch.ops.aten.add.Tensor(to_dtype_2, 3);  to_dtype_2 = None
        clamp_default_2 = torch.ops.aten.clamp.default(add_tensor_14, 0);  add_tensor_14 = None
        clamp_default_3 = torch.ops.aten.clamp.default(clamp_default_2, None, 6);  clamp_default_2 = None
        div_tensor_1 = torch.ops.aten.div.Tensor(clamp_default_3, 6);  clamp_default_3 = None
        to_dtype_3 = torch.ops.aten.to.dtype(div_tensor_1, torch.float32);  div_tensor_1 = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(relu__default_12, to_dtype_3)
        max_pool2d_with_indices_default_1 = torch.ops.aten.max_pool2d_with_indices.default(mul_tensor_1, [3, 3], [2, 2], [0, 0], [1, 1], True)
        getitem_41 = max_pool2d_with_indices_default_1[0]
        getitem_42 = max_pool2d_with_indices_default_1[1];  max_pool2d_with_indices_default_1 = None
        convolution_default_23 = torch.ops.aten.convolution.default(getitem_41, primals_32, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_15 = torch.ops.aten.add.Tensor(primals_114, 1);  primals_114 = None
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_117, primals_118, primals_115, primals_116, True, 0.1, 1e-05);  primals_118 = None
        getitem_43 = native_batch_norm_default_13[0]
        getitem_44 = native_batch_norm_default_13[1]
        getitem_45 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        relu__default_13 = torch.ops.aten.relu_.default(getitem_43);  getitem_43 = None
        convolution_default_24 = torch.ops.aten.convolution.default(relu__default_13, primals_26, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 192)
        convolution_default_25 = torch.ops.aten.convolution.default(convolution_default_24, primals_27, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_16 = torch.ops.aten.add.Tensor(primals_119, 1);  primals_119 = None
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_122, primals_123, primals_120, primals_121, True, 0.1, 1e-05);  primals_123 = None
        getitem_46 = native_batch_norm_default_14[0]
        getitem_47 = native_batch_norm_default_14[1]
        getitem_48 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        relu__default_14 = torch.ops.aten.relu_.default(getitem_46);  getitem_46 = None
        convolution_default_26 = torch.ops.aten.convolution.default(relu__default_14, primals_28, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 192)
        convolution_default_27 = torch.ops.aten.convolution.default(convolution_default_26, primals_29, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_17 = torch.ops.aten.add.Tensor(primals_124, 1);  primals_124 = None
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_127, primals_128, primals_125, primals_126, True, 0.1, 1e-05);  primals_128 = None
        getitem_49 = native_batch_norm_default_15[0]
        getitem_50 = native_batch_norm_default_15[1]
        getitem_51 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        relu__default_15 = torch.ops.aten.relu_.default(getitem_49);  getitem_49 = None
        convolution_default_28 = torch.ops.aten.convolution.default(relu__default_15, primals_30, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 192)
        convolution_default_29 = torch.ops.aten.convolution.default(convolution_default_28, primals_31, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_18 = torch.ops.aten.add.Tensor(primals_129, 1);  primals_129 = None
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_132, primals_133, primals_130, primals_131, True, 0.1, 1e-05);  primals_133 = None
        getitem_52 = native_batch_norm_default_16[0]
        getitem_53 = native_batch_norm_default_16[1]
        getitem_54 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        relu__default_16 = torch.ops.aten.relu_.default(getitem_52);  getitem_52 = None
        cat_default_2 = torch.ops.aten.cat.default([getitem_41, relu__default_14, relu__default_15, relu__default_16], 1)
        convolution_default_30 = torch.ops.aten.convolution.default(cat_default_2, primals_25, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_19 = torch.ops.aten.add.Tensor(primals_134, 1);  primals_134 = None
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_137, primals_138, primals_135, primals_136, True, 0.1, 1e-05);  primals_138 = None
        getitem_55 = native_batch_norm_default_17[0]
        getitem_56 = native_batch_norm_default_17[1]
        getitem_57 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        relu__default_17 = torch.ops.aten.relu_.default(getitem_55);  getitem_55 = None
        mean_dim_2 = torch.ops.aten.mean.dim(relu__default_17, [2, 3], True)
        convolution_default_31 = torch.ops.aten.convolution.default(mean_dim_2, primals_24, primals_23, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_23 = None
        to_dtype_4 = torch.ops.aten.to.dtype(convolution_default_31, torch.float32)
        add_tensor_20 = torch.ops.aten.add.Tensor(to_dtype_4, 3);  to_dtype_4 = None
        clamp_default_4 = torch.ops.aten.clamp.default(add_tensor_20, 0);  add_tensor_20 = None
        clamp_default_5 = torch.ops.aten.clamp.default(clamp_default_4, None, 6);  clamp_default_4 = None
        div_tensor_2 = torch.ops.aten.div.Tensor(clamp_default_5, 6);  clamp_default_5 = None
        to_dtype_5 = torch.ops.aten.to.dtype(div_tensor_2, torch.float32);  div_tensor_2 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(relu__default_17, to_dtype_5)
        max_pool2d_with_indices_default_2 = torch.ops.aten.max_pool2d_with_indices.default(mul_tensor_2, [3, 3], [2, 2], [0, 0], [1, 1], True)
        getitem_58 = max_pool2d_with_indices_default_2[0]
        getitem_59 = max_pool2d_with_indices_default_2[1];  max_pool2d_with_indices_default_2 = None
        convolution_default_32 = torch.ops.aten.convolution.default(getitem_58, primals_42, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_21 = torch.ops.aten.add.Tensor(primals_139, 1);  primals_139 = None
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_142, primals_143, primals_140, primals_141, True, 0.1, 1e-05);  primals_143 = None
        getitem_60 = native_batch_norm_default_18[0]
        getitem_61 = native_batch_norm_default_18[1]
        getitem_62 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        relu__default_18 = torch.ops.aten.relu_.default(getitem_60);  getitem_60 = None
        convolution_default_33 = torch.ops.aten.convolution.default(relu__default_18, primals_36, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 224)
        convolution_default_34 = torch.ops.aten.convolution.default(convolution_default_33, primals_37, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_22 = torch.ops.aten.add.Tensor(primals_144, 1);  primals_144 = None
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_147, primals_148, primals_145, primals_146, True, 0.1, 1e-05);  primals_148 = None
        getitem_63 = native_batch_norm_default_19[0]
        getitem_64 = native_batch_norm_default_19[1]
        getitem_65 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        relu__default_19 = torch.ops.aten.relu_.default(getitem_63);  getitem_63 = None
        convolution_default_35 = torch.ops.aten.convolution.default(relu__default_19, primals_38, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 224)
        convolution_default_36 = torch.ops.aten.convolution.default(convolution_default_35, primals_39, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_23 = torch.ops.aten.add.Tensor(primals_149, 1);  primals_149 = None
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_152, primals_153, primals_150, primals_151, True, 0.1, 1e-05);  primals_153 = None
        getitem_66 = native_batch_norm_default_20[0]
        getitem_67 = native_batch_norm_default_20[1]
        getitem_68 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        relu__default_20 = torch.ops.aten.relu_.default(getitem_66);  getitem_66 = None
        convolution_default_37 = torch.ops.aten.convolution.default(relu__default_20, primals_40, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 224)
        convolution_default_38 = torch.ops.aten.convolution.default(convolution_default_37, primals_41, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_24 = torch.ops.aten.add.Tensor(primals_154, 1);  primals_154 = None
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_157, primals_158, primals_155, primals_156, True, 0.1, 1e-05);  primals_158 = None
        getitem_69 = native_batch_norm_default_21[0]
        getitem_70 = native_batch_norm_default_21[1]
        getitem_71 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        relu__default_21 = torch.ops.aten.relu_.default(getitem_69);  getitem_69 = None
        cat_default_3 = torch.ops.aten.cat.default([getitem_58, relu__default_19, relu__default_20, relu__default_21], 1)
        convolution_default_39 = torch.ops.aten.convolution.default(cat_default_3, primals_35, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_25 = torch.ops.aten.add.Tensor(primals_159, 1);  primals_159 = None
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_39, primals_162, primals_163, primals_160, primals_161, True, 0.1, 1e-05);  primals_163 = None
        getitem_72 = native_batch_norm_default_22[0]
        getitem_73 = native_batch_norm_default_22[1]
        getitem_74 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        relu__default_22 = torch.ops.aten.relu_.default(getitem_72);  getitem_72 = None
        mean_dim_3 = torch.ops.aten.mean.dim(relu__default_22, [2, 3], True)
        convolution_default_40 = torch.ops.aten.convolution.default(mean_dim_3, primals_34, primals_33, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_33 = None
        to_dtype_6 = torch.ops.aten.to.dtype(convolution_default_40, torch.float32)
        add_tensor_26 = torch.ops.aten.add.Tensor(to_dtype_6, 3);  to_dtype_6 = None
        clamp_default_6 = torch.ops.aten.clamp.default(add_tensor_26, 0);  add_tensor_26 = None
        clamp_default_7 = torch.ops.aten.clamp.default(clamp_default_6, None, 6);  clamp_default_6 = None
        div_tensor_3 = torch.ops.aten.div.Tensor(clamp_default_7, 6);  clamp_default_7 = None
        to_dtype_7 = torch.ops.aten.to.dtype(div_tensor_3, torch.float32);  div_tensor_3 = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(relu__default_22, to_dtype_7)
        mean_dim_4 = torch.ops.aten.mean.dim(mul_tensor_3, [-1, -2], True);  mul_tensor_3 = None
        view_default = torch.ops.aten.view.default(mean_dim_4, [128, 1024]);  mean_dim_4 = None
        t_default = torch.ops.aten.t.default(primals_2);  primals_2 = None
        addmm_default = torch.ops.aten.addmm.default(primals_1, view_default, t_default);  primals_1 = None
        return [addmm_default, add_tensor, add_tensor_1, add_tensor_2, add_tensor_3, add_tensor_4, add_tensor_5, add_tensor_6, add_tensor_7, add_tensor_9, add_tensor_10, add_tensor_11, add_tensor_12, add_tensor_13, add_tensor_15, add_tensor_16, add_tensor_17, add_tensor_18, add_tensor_19, add_tensor_21, add_tensor_22, add_tensor_23, add_tensor_24, add_tensor_25, primals_21, primals_51, primals_25, primals_55, primals_47, convolution_default_2, primals_16, primals_46, primals_50, primals_24, primals_52, primals_22, primals_56, primals_14, primals_18, primals_20, primals_42, primals_27, primals_48, primals_19, primals_43, primals_44, primals_41, primals_45, primals_28, primals_26, primals_15, primals_17, primals_9, primals_4, getitem_71, convolution_default_9, primals_10, convolution_default_10, primals_11, primals_12, getitem_70, primals_7, getitem_16, relu__default_21, convolution_default_39, primals_6, cat_default_3, getitem_74, getitem_73, primals_8, convolution_default_11, relu__default_5, relu__default_22, primals_5, getitem_17, mean_dim_3, convolution_default_40, getitem_58, primals_77, getitem_59, convolution_default_32, convolution_default_5, mul_tensor_2, to_dtype_5, relu__default_2, primals_75, getitem_8, getitem_61, getitem_62, getitem_10, primals_76, relu__default_18, convolution_default_33, convolution_default_34, cat_default, view_default, primals_160, primals_92, getitem_27, getitem_28, primals_155, convolution_default_12, relu__default_8, to_dtype_7, primals_156, relu__default_6, primals_97, primals_106, primals_151, getitem_20, primals_111, primals_80, primals_91, primals_107, primals_96, convolution_default_16, primals_82, getitem_19, t_default, primals_102, primals_86, primals_105, primals_100, mul_tensor, getitem_13, primals_95, primals_110, getitem_23, primals_162, mean_dim, primals_87, getitem_22, to_dtype_1, primals_101, convolution_default_15, primals_150, primals_112, primals_90, relu__default_4, convolution_default_14, primals_85, relu__default_7, getitem_25, primals_157, primals_81, convolution_default_13, getitem_24, primals_147, primals_161, primals_152, convolution_default_36, getitem_65, relu__default_1, getitem_64, convolution_default_3, primals_126, primals_127, relu__default_19, getitem_4, primals_136, convolution_default_35, getitem_5, getitem_7, getitem_68, primals_130, getitem_67, primals_132, primals_137, relu__default_20, primals_131, primals_125, convolution_default_37, primals_135, convolution_default_4, convolution_default_38, convolution_default_22, convolution_default_7, convolution_default, getitem_31, getitem_30, getitem_42, convolution_default_18, convolution_default_23, mul_tensor_1, to_dtype_3, relu__default_9, convolution_default_1, getitem_41, getitem_2, convolution_default_17, getitem_33, relu__default_3, getitem_44, primals_141, getitem_11, getitem_45, convolution_default_6, primals_142, relu__default, primals_146, primals_145, getitem_34, convolution_default_19, primals_140, relu__default_13, convolution_default_24, relu__default_10, convolution_default_25, getitem_48, convolution_default_27, primals_31, primals_29, primals_34, convolution_default_8, primals_71, primals_70, getitem_47, primals_65, primals_38, primals_32, primals_61, relu__default_14, primals_62, convolution_default_26, primals_60, primals_36, primals_67, getitem_1, primals_39, primals_72, getitem_51, primals_66, primals_35, getitem_50, primals_57, primals_40, primals_37, relu__default_15, convolution_default_29, primals_30, convolution_default_28, convolution_default_20, getitem_54, primals_115, getitem_37, convolution_default_30, convolution_default_21, getitem_53, getitem_36, relu__default_16, primals_117, relu__default_11, getitem_39, cat_default_2, primals_122, getitem_57, primals_120, cat_default_1, getitem_56, relu__default_12, primals_121, getitem_40, getitem_14, primals_116, relu__default_17, mean_dim_1, convolution_default_31, mean_dim_2]
        
