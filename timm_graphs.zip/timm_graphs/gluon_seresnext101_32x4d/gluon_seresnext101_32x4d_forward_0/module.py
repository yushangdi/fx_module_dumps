
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/gluon_seresnext101_32x4d/gluon_seresnext101_32x4d_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339, primals_340, primals_341, primals_342, primals_343, primals_344, primals_345, primals_346, primals_347, primals_348, primals_349, primals_350, primals_351, primals_352, primals_353, primals_354, primals_355, primals_356, primals_357, primals_358, primals_359, primals_360, primals_361, primals_362, primals_363, primals_364, primals_365, primals_366, primals_367, primals_368, primals_369, primals_370, primals_371, primals_372, primals_373, primals_374, primals_375, primals_376, primals_377, primals_378, primals_379, primals_380, primals_381, primals_382, primals_383, primals_384, primals_385, primals_386, primals_387, primals_388, primals_389, primals_390, primals_391, primals_392, primals_393, primals_394, primals_395, primals_396, primals_397, primals_398, primals_399, primals_400, primals_401, primals_402, primals_403, primals_404, primals_405, primals_406, primals_407, primals_408, primals_409, primals_410, primals_411, primals_412, primals_413, primals_414, primals_415, primals_416, primals_417, primals_418, primals_419, primals_420, primals_421, primals_422, primals_423, primals_424, primals_425, primals_426, primals_427, primals_428, primals_429, primals_430, primals_431, primals_432, primals_433, primals_434, primals_435, primals_436, primals_437, primals_438, primals_439, primals_440, primals_441, primals_442, primals_443, primals_444, primals_445, primals_446, primals_447, primals_448, primals_449, primals_450, primals_451, primals_452, primals_453, primals_454, primals_455, primals_456, primals_457, primals_458, primals_459, primals_460, primals_461, primals_462, primals_463, primals_464, primals_465, primals_466, primals_467, primals_468, primals_469, primals_470, primals_471, primals_472, primals_473, primals_474, primals_475, primals_476, primals_477, primals_478, primals_479, primals_480, primals_481, primals_482, primals_483, primals_484, primals_485, primals_486, primals_487, primals_488, primals_489, primals_490, primals_491, primals_492, primals_493, primals_494, primals_495, primals_496, primals_497, primals_498, primals_499, primals_500, primals_501, primals_502, primals_503, primals_504, primals_505, primals_506, primals_507, primals_508, primals_509, primals_510, primals_511, primals_512, primals_513, primals_514, primals_515, primals_516, primals_517, primals_518, primals_519, primals_520, primals_521, primals_522, primals_523, primals_524, primals_525, primals_526, primals_527, primals_528, primals_529, primals_530, primals_531, primals_532, primals_533, primals_534, primals_535, primals_536, primals_537, primals_538, primals_539, primals_540, primals_541, primals_542, primals_543, primals_544, primals_545, primals_546, primals_547, primals_548, primals_549, primals_550, primals_551, primals_552, primals_553, primals_554, primals_555, primals_556, primals_557, primals_558, primals_559, primals_560, primals_561, primals_562, primals_563, primals_564, primals_565, primals_566, primals_567, primals_568, primals_569, primals_570, primals_571, primals_572, primals_573, primals_574, primals_575, primals_576, primals_577, primals_578, primals_579, primals_580, primals_581, primals_582, primals_583, primals_584, primals_585, primals_586, primals_587, primals_588, primals_589, primals_590, primals_591, primals_592, primals_593, primals_594, primals_595, primals_596, primals_597, primals_598, primals_599, primals_600, primals_601, primals_602, primals_603, primals_604, primals_605, primals_606, primals_607, primals_608, primals_609, primals_610, primals_611, primals_612, primals_613, primals_614, primals_615, primals_616, primals_617, primals_618, primals_619, primals_620, primals_621, primals_622, primals_623, primals_624, primals_625, primals_626, primals_627, primals_628, primals_629, primals_630, primals_631, primals_632, primals_633, primals_634, primals_635, primals_636, primals_637, primals_638, primals_639, primals_640, primals_641, primals_642, primals_643, primals_644, primals_645, primals_646, primals_647, primals_648, primals_649, primals_650, primals_651, primals_652, primals_653, primals_654, primals_655, primals_656, primals_657, primals_658, primals_659, primals_660, primals_661, primals_662, primals_663, primals_664, primals_665, primals_666, primals_667, primals_668, primals_669, primals_670, primals_671, primals_672, primals_673, primals_674, primals_675, primals_676, primals_677, primals_678, primals_679, primals_680, primals_681, primals_682, primals_683, primals_684, primals_685, primals_686, primals_687, primals_688, primals_689, primals_690, primals_691, primals_692, primals_693, primals_694, primals_695, primals_696, primals_697, primals_698, primals_699, primals_700, primals_701, primals_702, primals_703, primals_704, primals_705, primals_706, primals_707, primals_708, primals_709, primals_710, primals_711, primals_712, primals_713, primals_714, primals_715, primals_716, primals_717, primals_718, primals_719, primals_720, primals_721, primals_722, primals_723, primals_724, primals_725, primals_726, primals_727, primals_728, primals_729, primals_730, primals_731, primals_732, primals_733, primals_734, primals_735, primals_736, primals_737, primals_738, primals_739, primals_740, primals_741, primals_742, primals_743, primals_744, primals_745, primals_746, primals_747, primals_748, primals_749, primals_750, primals_751, primals_752, primals_753, primals_754, primals_755, primals_756, primals_757, primals_758, primals_759):
        convolution_default = torch.ops.aten.convolution.default(primals_759, primals_6, None, [2, 2], [3, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_5, primals_1, primals_3, primals_4, True, 0.1, 1e-05);  primals_1 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu__default, [3, 3], [2, 2], [1, 1])
        getitem_3 = max_pool2d_with_indices_default[0]
        getitem_4 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_1 = torch.ops.aten.convolution.default(getitem_3, primals_24, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_13, primals_9, primals_11, primals_12, True, 0.1, 1e-05);  primals_9 = None
        getitem_5 = native_batch_norm_default_1[0]
        getitem_6 = native_batch_norm_default_1[1]
        getitem_7 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        relu__default_1 = torch.ops.aten.relu_.default(getitem_5);  getitem_5 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_25, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_18, primals_14, primals_16, primals_17, True, 0.1, 1e-05);  primals_14 = None
        getitem_8 = native_batch_norm_default_2[0]
        getitem_9 = native_batch_norm_default_2[1]
        getitem_10 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        relu__default_2 = torch.ops.aten.relu_.default(getitem_8);  getitem_8 = None
        convolution_default_3 = torch.ops.aten.convolution.default(relu__default_2, primals_26, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_23, primals_19, primals_21, primals_22, True, 0.1, 1e-05);  primals_19 = None
        getitem_11 = native_batch_norm_default_3[0]
        getitem_12 = native_batch_norm_default_3[1]
        getitem_13 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        mean_dim = torch.ops.aten.mean.dim(getitem_11, [2, 3], True)
        convolution_default_4 = torch.ops.aten.convolution.default(mean_dim, primals_34, primals_33, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_33 = None
        relu__default_3 = torch.ops.aten.relu_.default(convolution_default_4);  convolution_default_4 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_3, primals_36, primals_35, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_35 = None
        sigmoid_default = torch.ops.aten.sigmoid.default(convolution_default_5);  convolution_default_5 = None
        mul_tensor = torch.ops.aten.mul.Tensor(getitem_11, sigmoid_default)
        convolution_default_6 = torch.ops.aten.convolution.default(getitem_3, primals_27, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_32, primals_28, primals_30, primals_31, True, 0.1, 1e-05);  primals_28 = None
        getitem_14 = native_batch_norm_default_4[0]
        getitem_15 = native_batch_norm_default_4[1]
        getitem_16 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        add__tensor_5 = torch.ops.aten.add_.Tensor(mul_tensor, getitem_14);  mul_tensor = getitem_14 = None
        relu__default_4 = torch.ops.aten.relu_.default(add__tensor_5);  add__tensor_5 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_4, primals_52, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_41, primals_37, primals_39, primals_40, True, 0.1, 1e-05);  primals_37 = None
        getitem_17 = native_batch_norm_default_5[0]
        getitem_18 = native_batch_norm_default_5[1]
        getitem_19 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        relu__default_5 = torch.ops.aten.relu_.default(getitem_17);  getitem_17 = None
        convolution_default_8 = torch.ops.aten.convolution.default(relu__default_5, primals_53, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_46, primals_42, primals_44, primals_45, True, 0.1, 1e-05);  primals_42 = None
        getitem_20 = native_batch_norm_default_6[0]
        getitem_21 = native_batch_norm_default_6[1]
        getitem_22 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        relu__default_6 = torch.ops.aten.relu_.default(getitem_20);  getitem_20 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_6, primals_54, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_51, primals_47, primals_49, primals_50, True, 0.1, 1e-05);  primals_47 = None
        getitem_23 = native_batch_norm_default_7[0]
        getitem_24 = native_batch_norm_default_7[1]
        getitem_25 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        mean_dim_1 = torch.ops.aten.mean.dim(getitem_23, [2, 3], True)
        convolution_default_10 = torch.ops.aten.convolution.default(mean_dim_1, primals_56, primals_55, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_55 = None
        relu__default_7 = torch.ops.aten.relu_.default(convolution_default_10);  convolution_default_10 = None
        convolution_default_11 = torch.ops.aten.convolution.default(relu__default_7, primals_58, primals_57, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_57 = None
        sigmoid_default_1 = torch.ops.aten.sigmoid.default(convolution_default_11);  convolution_default_11 = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(getitem_23, sigmoid_default_1)
        add__tensor_9 = torch.ops.aten.add_.Tensor(mul_tensor_1, relu__default_4);  mul_tensor_1 = None
        relu__default_8 = torch.ops.aten.relu_.default(add__tensor_9);  add__tensor_9 = None
        convolution_default_12 = torch.ops.aten.convolution.default(relu__default_8, primals_74, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_63, primals_59, primals_61, primals_62, True, 0.1, 1e-05);  primals_59 = None
        getitem_26 = native_batch_norm_default_8[0]
        getitem_27 = native_batch_norm_default_8[1]
        getitem_28 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        relu__default_9 = torch.ops.aten.relu_.default(getitem_26);  getitem_26 = None
        convolution_default_13 = torch.ops.aten.convolution.default(relu__default_9, primals_75, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_68, primals_64, primals_66, primals_67, True, 0.1, 1e-05);  primals_64 = None
        getitem_29 = native_batch_norm_default_9[0]
        getitem_30 = native_batch_norm_default_9[1]
        getitem_31 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        relu__default_10 = torch.ops.aten.relu_.default(getitem_29);  getitem_29 = None
        convolution_default_14 = torch.ops.aten.convolution.default(relu__default_10, primals_76, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_73, primals_69, primals_71, primals_72, True, 0.1, 1e-05);  primals_69 = None
        getitem_32 = native_batch_norm_default_10[0]
        getitem_33 = native_batch_norm_default_10[1]
        getitem_34 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        mean_dim_2 = torch.ops.aten.mean.dim(getitem_32, [2, 3], True)
        convolution_default_15 = torch.ops.aten.convolution.default(mean_dim_2, primals_78, primals_77, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_77 = None
        relu__default_11 = torch.ops.aten.relu_.default(convolution_default_15);  convolution_default_15 = None
        convolution_default_16 = torch.ops.aten.convolution.default(relu__default_11, primals_80, primals_79, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_79 = None
        sigmoid_default_2 = torch.ops.aten.sigmoid.default(convolution_default_16);  convolution_default_16 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(getitem_32, sigmoid_default_2)
        add__tensor_13 = torch.ops.aten.add_.Tensor(mul_tensor_2, relu__default_8);  mul_tensor_2 = None
        relu__default_12 = torch.ops.aten.relu_.default(add__tensor_13);  add__tensor_13 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu__default_12, primals_96, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_85, primals_81, primals_83, primals_84, True, 0.1, 1e-05);  primals_81 = None
        getitem_35 = native_batch_norm_default_11[0]
        getitem_36 = native_batch_norm_default_11[1]
        getitem_37 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        relu__default_13 = torch.ops.aten.relu_.default(getitem_35);  getitem_35 = None
        convolution_default_18 = torch.ops.aten.convolution.default(relu__default_13, primals_97, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_90, primals_86, primals_88, primals_89, True, 0.1, 1e-05);  primals_86 = None
        getitem_38 = native_batch_norm_default_12[0]
        getitem_39 = native_batch_norm_default_12[1]
        getitem_40 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        relu__default_14 = torch.ops.aten.relu_.default(getitem_38);  getitem_38 = None
        convolution_default_19 = torch.ops.aten.convolution.default(relu__default_14, primals_98, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_95, primals_91, primals_93, primals_94, True, 0.1, 1e-05);  primals_91 = None
        getitem_41 = native_batch_norm_default_13[0]
        getitem_42 = native_batch_norm_default_13[1]
        getitem_43 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        mean_dim_3 = torch.ops.aten.mean.dim(getitem_41, [2, 3], True)
        convolution_default_20 = torch.ops.aten.convolution.default(mean_dim_3, primals_106, primals_105, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_105 = None
        relu__default_15 = torch.ops.aten.relu_.default(convolution_default_20);  convolution_default_20 = None
        convolution_default_21 = torch.ops.aten.convolution.default(relu__default_15, primals_108, primals_107, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_107 = None
        sigmoid_default_3 = torch.ops.aten.sigmoid.default(convolution_default_21);  convolution_default_21 = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(getitem_41, sigmoid_default_3)
        convolution_default_22 = torch.ops.aten.convolution.default(relu__default_12, primals_99, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_104, primals_100, primals_102, primals_103, True, 0.1, 1e-05);  primals_100 = None
        getitem_44 = native_batch_norm_default_14[0]
        getitem_45 = native_batch_norm_default_14[1]
        getitem_46 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        add__tensor_18 = torch.ops.aten.add_.Tensor(mul_tensor_3, getitem_44);  mul_tensor_3 = getitem_44 = None
        relu__default_16 = torch.ops.aten.relu_.default(add__tensor_18);  add__tensor_18 = None
        convolution_default_23 = torch.ops.aten.convolution.default(relu__default_16, primals_124, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_113, primals_109, primals_111, primals_112, True, 0.1, 1e-05);  primals_109 = None
        getitem_47 = native_batch_norm_default_15[0]
        getitem_48 = native_batch_norm_default_15[1]
        getitem_49 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        relu__default_17 = torch.ops.aten.relu_.default(getitem_47);  getitem_47 = None
        convolution_default_24 = torch.ops.aten.convolution.default(relu__default_17, primals_125, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_118, primals_114, primals_116, primals_117, True, 0.1, 1e-05);  primals_114 = None
        getitem_50 = native_batch_norm_default_16[0]
        getitem_51 = native_batch_norm_default_16[1]
        getitem_52 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        relu__default_18 = torch.ops.aten.relu_.default(getitem_50);  getitem_50 = None
        convolution_default_25 = torch.ops.aten.convolution.default(relu__default_18, primals_126, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_123, primals_119, primals_121, primals_122, True, 0.1, 1e-05);  primals_119 = None
        getitem_53 = native_batch_norm_default_17[0]
        getitem_54 = native_batch_norm_default_17[1]
        getitem_55 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        mean_dim_4 = torch.ops.aten.mean.dim(getitem_53, [2, 3], True)
        convolution_default_26 = torch.ops.aten.convolution.default(mean_dim_4, primals_128, primals_127, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_127 = None
        relu__default_19 = torch.ops.aten.relu_.default(convolution_default_26);  convolution_default_26 = None
        convolution_default_27 = torch.ops.aten.convolution.default(relu__default_19, primals_130, primals_129, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_129 = None
        sigmoid_default_4 = torch.ops.aten.sigmoid.default(convolution_default_27);  convolution_default_27 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(getitem_53, sigmoid_default_4)
        add__tensor_22 = torch.ops.aten.add_.Tensor(mul_tensor_4, relu__default_16);  mul_tensor_4 = None
        relu__default_20 = torch.ops.aten.relu_.default(add__tensor_22);  add__tensor_22 = None
        convolution_default_28 = torch.ops.aten.convolution.default(relu__default_20, primals_146, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_135, primals_131, primals_133, primals_134, True, 0.1, 1e-05);  primals_131 = None
        getitem_56 = native_batch_norm_default_18[0]
        getitem_57 = native_batch_norm_default_18[1]
        getitem_58 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        relu__default_21 = torch.ops.aten.relu_.default(getitem_56);  getitem_56 = None
        convolution_default_29 = torch.ops.aten.convolution.default(relu__default_21, primals_147, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_140, primals_136, primals_138, primals_139, True, 0.1, 1e-05);  primals_136 = None
        getitem_59 = native_batch_norm_default_19[0]
        getitem_60 = native_batch_norm_default_19[1]
        getitem_61 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        relu__default_22 = torch.ops.aten.relu_.default(getitem_59);  getitem_59 = None
        convolution_default_30 = torch.ops.aten.convolution.default(relu__default_22, primals_148, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_145, primals_141, primals_143, primals_144, True, 0.1, 1e-05);  primals_141 = None
        getitem_62 = native_batch_norm_default_20[0]
        getitem_63 = native_batch_norm_default_20[1]
        getitem_64 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        mean_dim_5 = torch.ops.aten.mean.dim(getitem_62, [2, 3], True)
        convolution_default_31 = torch.ops.aten.convolution.default(mean_dim_5, primals_150, primals_149, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_149 = None
        relu__default_23 = torch.ops.aten.relu_.default(convolution_default_31);  convolution_default_31 = None
        convolution_default_32 = torch.ops.aten.convolution.default(relu__default_23, primals_152, primals_151, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_151 = None
        sigmoid_default_5 = torch.ops.aten.sigmoid.default(convolution_default_32);  convolution_default_32 = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(getitem_62, sigmoid_default_5)
        add__tensor_26 = torch.ops.aten.add_.Tensor(mul_tensor_5, relu__default_20);  mul_tensor_5 = None
        relu__default_24 = torch.ops.aten.relu_.default(add__tensor_26);  add__tensor_26 = None
        convolution_default_33 = torch.ops.aten.convolution.default(relu__default_24, primals_168, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_157, primals_153, primals_155, primals_156, True, 0.1, 1e-05);  primals_153 = None
        getitem_65 = native_batch_norm_default_21[0]
        getitem_66 = native_batch_norm_default_21[1]
        getitem_67 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        relu__default_25 = torch.ops.aten.relu_.default(getitem_65);  getitem_65 = None
        convolution_default_34 = torch.ops.aten.convolution.default(relu__default_25, primals_169, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_162, primals_158, primals_160, primals_161, True, 0.1, 1e-05);  primals_158 = None
        getitem_68 = native_batch_norm_default_22[0]
        getitem_69 = native_batch_norm_default_22[1]
        getitem_70 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        relu__default_26 = torch.ops.aten.relu_.default(getitem_68);  getitem_68 = None
        convolution_default_35 = torch.ops.aten.convolution.default(relu__default_26, primals_170, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_167, primals_163, primals_165, primals_166, True, 0.1, 1e-05);  primals_163 = None
        getitem_71 = native_batch_norm_default_23[0]
        getitem_72 = native_batch_norm_default_23[1]
        getitem_73 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        mean_dim_6 = torch.ops.aten.mean.dim(getitem_71, [2, 3], True)
        convolution_default_36 = torch.ops.aten.convolution.default(mean_dim_6, primals_172, primals_171, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_171 = None
        relu__default_27 = torch.ops.aten.relu_.default(convolution_default_36);  convolution_default_36 = None
        convolution_default_37 = torch.ops.aten.convolution.default(relu__default_27, primals_174, primals_173, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_173 = None
        sigmoid_default_6 = torch.ops.aten.sigmoid.default(convolution_default_37);  convolution_default_37 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(getitem_71, sigmoid_default_6)
        add__tensor_30 = torch.ops.aten.add_.Tensor(mul_tensor_6, relu__default_24);  mul_tensor_6 = None
        relu__default_28 = torch.ops.aten.relu_.default(add__tensor_30);  add__tensor_30 = None
        convolution_default_38 = torch.ops.aten.convolution.default(relu__default_28, primals_190, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_179, primals_175, primals_177, primals_178, True, 0.1, 1e-05);  primals_175 = None
        getitem_74 = native_batch_norm_default_24[0]
        getitem_75 = native_batch_norm_default_24[1]
        getitem_76 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        relu__default_29 = torch.ops.aten.relu_.default(getitem_74);  getitem_74 = None
        convolution_default_39 = torch.ops.aten.convolution.default(relu__default_29, primals_191, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_39, primals_184, primals_180, primals_182, primals_183, True, 0.1, 1e-05);  primals_180 = None
        getitem_77 = native_batch_norm_default_25[0]
        getitem_78 = native_batch_norm_default_25[1]
        getitem_79 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        relu__default_30 = torch.ops.aten.relu_.default(getitem_77);  getitem_77 = None
        convolution_default_40 = torch.ops.aten.convolution.default(relu__default_30, primals_192, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_189, primals_185, primals_187, primals_188, True, 0.1, 1e-05);  primals_185 = None
        getitem_80 = native_batch_norm_default_26[0]
        getitem_81 = native_batch_norm_default_26[1]
        getitem_82 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        mean_dim_7 = torch.ops.aten.mean.dim(getitem_80, [2, 3], True)
        convolution_default_41 = torch.ops.aten.convolution.default(mean_dim_7, primals_200, primals_199, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_199 = None
        relu__default_31 = torch.ops.aten.relu_.default(convolution_default_41);  convolution_default_41 = None
        convolution_default_42 = torch.ops.aten.convolution.default(relu__default_31, primals_202, primals_201, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_201 = None
        sigmoid_default_7 = torch.ops.aten.sigmoid.default(convolution_default_42);  convolution_default_42 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(getitem_80, sigmoid_default_7)
        convolution_default_43 = torch.ops.aten.convolution.default(relu__default_28, primals_193, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_43, primals_198, primals_194, primals_196, primals_197, True, 0.1, 1e-05);  primals_194 = None
        getitem_83 = native_batch_norm_default_27[0]
        getitem_84 = native_batch_norm_default_27[1]
        getitem_85 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        add__tensor_35 = torch.ops.aten.add_.Tensor(mul_tensor_7, getitem_83);  mul_tensor_7 = getitem_83 = None
        relu__default_32 = torch.ops.aten.relu_.default(add__tensor_35);  add__tensor_35 = None
        convolution_default_44 = torch.ops.aten.convolution.default(relu__default_32, primals_438, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_427, primals_423, primals_425, primals_426, True, 0.1, 1e-05);  primals_423 = None
        getitem_86 = native_batch_norm_default_28[0]
        getitem_87 = native_batch_norm_default_28[1]
        getitem_88 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        relu__default_33 = torch.ops.aten.relu_.default(getitem_86);  getitem_86 = None
        convolution_default_45 = torch.ops.aten.convolution.default(relu__default_33, primals_439, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_45, primals_432, primals_428, primals_430, primals_431, True, 0.1, 1e-05);  primals_428 = None
        getitem_89 = native_batch_norm_default_29[0]
        getitem_90 = native_batch_norm_default_29[1]
        getitem_91 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        relu__default_34 = torch.ops.aten.relu_.default(getitem_89);  getitem_89 = None
        convolution_default_46 = torch.ops.aten.convolution.default(relu__default_34, primals_440, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_46, primals_437, primals_433, primals_435, primals_436, True, 0.1, 1e-05);  primals_433 = None
        getitem_92 = native_batch_norm_default_30[0]
        getitem_93 = native_batch_norm_default_30[1]
        getitem_94 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        mean_dim_8 = torch.ops.aten.mean.dim(getitem_92, [2, 3], True)
        convolution_default_47 = torch.ops.aten.convolution.default(mean_dim_8, primals_442, primals_441, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_441 = None
        relu__default_35 = torch.ops.aten.relu_.default(convolution_default_47);  convolution_default_47 = None
        convolution_default_48 = torch.ops.aten.convolution.default(relu__default_35, primals_444, primals_443, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_443 = None
        sigmoid_default_8 = torch.ops.aten.sigmoid.default(convolution_default_48);  convolution_default_48 = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(getitem_92, sigmoid_default_8)
        add__tensor_39 = torch.ops.aten.add_.Tensor(mul_tensor_8, relu__default_32);  mul_tensor_8 = None
        relu__default_36 = torch.ops.aten.relu_.default(add__tensor_39);  add__tensor_39 = None
        convolution_default_49 = torch.ops.aten.convolution.default(relu__default_36, primals_526, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_49, primals_515, primals_511, primals_513, primals_514, True, 0.1, 1e-05);  primals_511 = None
        getitem_95 = native_batch_norm_default_31[0]
        getitem_96 = native_batch_norm_default_31[1]
        getitem_97 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        relu__default_37 = torch.ops.aten.relu_.default(getitem_95);  getitem_95 = None
        convolution_default_50 = torch.ops.aten.convolution.default(relu__default_37, primals_527, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_50, primals_520, primals_516, primals_518, primals_519, True, 0.1, 1e-05);  primals_516 = None
        getitem_98 = native_batch_norm_default_32[0]
        getitem_99 = native_batch_norm_default_32[1]
        getitem_100 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        relu__default_38 = torch.ops.aten.relu_.default(getitem_98);  getitem_98 = None
        convolution_default_51 = torch.ops.aten.convolution.default(relu__default_38, primals_528, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_51, primals_525, primals_521, primals_523, primals_524, True, 0.1, 1e-05);  primals_521 = None
        getitem_101 = native_batch_norm_default_33[0]
        getitem_102 = native_batch_norm_default_33[1]
        getitem_103 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        mean_dim_9 = torch.ops.aten.mean.dim(getitem_101, [2, 3], True)
        convolution_default_52 = torch.ops.aten.convolution.default(mean_dim_9, primals_530, primals_529, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_529 = None
        relu__default_39 = torch.ops.aten.relu_.default(convolution_default_52);  convolution_default_52 = None
        convolution_default_53 = torch.ops.aten.convolution.default(relu__default_39, primals_532, primals_531, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_531 = None
        sigmoid_default_9 = torch.ops.aten.sigmoid.default(convolution_default_53);  convolution_default_53 = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(getitem_101, sigmoid_default_9)
        add__tensor_43 = torch.ops.aten.add_.Tensor(mul_tensor_9, relu__default_36);  mul_tensor_9 = None
        relu__default_40 = torch.ops.aten.relu_.default(add__tensor_43);  add__tensor_43 = None
        convolution_default_54 = torch.ops.aten.convolution.default(relu__default_40, primals_548, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_54, primals_537, primals_533, primals_535, primals_536, True, 0.1, 1e-05);  primals_533 = None
        getitem_104 = native_batch_norm_default_34[0]
        getitem_105 = native_batch_norm_default_34[1]
        getitem_106 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        relu__default_41 = torch.ops.aten.relu_.default(getitem_104);  getitem_104 = None
        convolution_default_55 = torch.ops.aten.convolution.default(relu__default_41, primals_549, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_55, primals_542, primals_538, primals_540, primals_541, True, 0.1, 1e-05);  primals_538 = None
        getitem_107 = native_batch_norm_default_35[0]
        getitem_108 = native_batch_norm_default_35[1]
        getitem_109 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        relu__default_42 = torch.ops.aten.relu_.default(getitem_107);  getitem_107 = None
        convolution_default_56 = torch.ops.aten.convolution.default(relu__default_42, primals_550, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_56, primals_547, primals_543, primals_545, primals_546, True, 0.1, 1e-05);  primals_543 = None
        getitem_110 = native_batch_norm_default_36[0]
        getitem_111 = native_batch_norm_default_36[1]
        getitem_112 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        mean_dim_10 = torch.ops.aten.mean.dim(getitem_110, [2, 3], True)
        convolution_default_57 = torch.ops.aten.convolution.default(mean_dim_10, primals_552, primals_551, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_551 = None
        relu__default_43 = torch.ops.aten.relu_.default(convolution_default_57);  convolution_default_57 = None
        convolution_default_58 = torch.ops.aten.convolution.default(relu__default_43, primals_554, primals_553, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_553 = None
        sigmoid_default_10 = torch.ops.aten.sigmoid.default(convolution_default_58);  convolution_default_58 = None
        mul_tensor_10 = torch.ops.aten.mul.Tensor(getitem_110, sigmoid_default_10)
        add__tensor_47 = torch.ops.aten.add_.Tensor(mul_tensor_10, relu__default_40);  mul_tensor_10 = None
        relu__default_44 = torch.ops.aten.relu_.default(add__tensor_47);  add__tensor_47 = None
        convolution_default_59 = torch.ops.aten.convolution.default(relu__default_44, primals_570, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_59, primals_559, primals_555, primals_557, primals_558, True, 0.1, 1e-05);  primals_555 = None
        getitem_113 = native_batch_norm_default_37[0]
        getitem_114 = native_batch_norm_default_37[1]
        getitem_115 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        relu__default_45 = torch.ops.aten.relu_.default(getitem_113);  getitem_113 = None
        convolution_default_60 = torch.ops.aten.convolution.default(relu__default_45, primals_571, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_60, primals_564, primals_560, primals_562, primals_563, True, 0.1, 1e-05);  primals_560 = None
        getitem_116 = native_batch_norm_default_38[0]
        getitem_117 = native_batch_norm_default_38[1]
        getitem_118 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        relu__default_46 = torch.ops.aten.relu_.default(getitem_116);  getitem_116 = None
        convolution_default_61 = torch.ops.aten.convolution.default(relu__default_46, primals_572, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_61, primals_569, primals_565, primals_567, primals_568, True, 0.1, 1e-05);  primals_565 = None
        getitem_119 = native_batch_norm_default_39[0]
        getitem_120 = native_batch_norm_default_39[1]
        getitem_121 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        mean_dim_11 = torch.ops.aten.mean.dim(getitem_119, [2, 3], True)
        convolution_default_62 = torch.ops.aten.convolution.default(mean_dim_11, primals_574, primals_573, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_573 = None
        relu__default_47 = torch.ops.aten.relu_.default(convolution_default_62);  convolution_default_62 = None
        convolution_default_63 = torch.ops.aten.convolution.default(relu__default_47, primals_576, primals_575, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_575 = None
        sigmoid_default_11 = torch.ops.aten.sigmoid.default(convolution_default_63);  convolution_default_63 = None
        mul_tensor_11 = torch.ops.aten.mul.Tensor(getitem_119, sigmoid_default_11)
        add__tensor_51 = torch.ops.aten.add_.Tensor(mul_tensor_11, relu__default_44);  mul_tensor_11 = None
        relu__default_48 = torch.ops.aten.relu_.default(add__tensor_51);  add__tensor_51 = None
        convolution_default_64 = torch.ops.aten.convolution.default(relu__default_48, primals_592, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_64, primals_581, primals_577, primals_579, primals_580, True, 0.1, 1e-05);  primals_577 = None
        getitem_122 = native_batch_norm_default_40[0]
        getitem_123 = native_batch_norm_default_40[1]
        getitem_124 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        relu__default_49 = torch.ops.aten.relu_.default(getitem_122);  getitem_122 = None
        convolution_default_65 = torch.ops.aten.convolution.default(relu__default_49, primals_593, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_65, primals_586, primals_582, primals_584, primals_585, True, 0.1, 1e-05);  primals_582 = None
        getitem_125 = native_batch_norm_default_41[0]
        getitem_126 = native_batch_norm_default_41[1]
        getitem_127 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        relu__default_50 = torch.ops.aten.relu_.default(getitem_125);  getitem_125 = None
        convolution_default_66 = torch.ops.aten.convolution.default(relu__default_50, primals_594, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_66, primals_591, primals_587, primals_589, primals_590, True, 0.1, 1e-05);  primals_587 = None
        getitem_128 = native_batch_norm_default_42[0]
        getitem_129 = native_batch_norm_default_42[1]
        getitem_130 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        mean_dim_12 = torch.ops.aten.mean.dim(getitem_128, [2, 3], True)
        convolution_default_67 = torch.ops.aten.convolution.default(mean_dim_12, primals_596, primals_595, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_595 = None
        relu__default_51 = torch.ops.aten.relu_.default(convolution_default_67);  convolution_default_67 = None
        convolution_default_68 = torch.ops.aten.convolution.default(relu__default_51, primals_598, primals_597, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_597 = None
        sigmoid_default_12 = torch.ops.aten.sigmoid.default(convolution_default_68);  convolution_default_68 = None
        mul_tensor_12 = torch.ops.aten.mul.Tensor(getitem_128, sigmoid_default_12)
        add__tensor_55 = torch.ops.aten.add_.Tensor(mul_tensor_12, relu__default_48);  mul_tensor_12 = None
        relu__default_52 = torch.ops.aten.relu_.default(add__tensor_55);  add__tensor_55 = None
        convolution_default_69 = torch.ops.aten.convolution.default(relu__default_52, primals_614, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_69, primals_603, primals_599, primals_601, primals_602, True, 0.1, 1e-05);  primals_599 = None
        getitem_131 = native_batch_norm_default_43[0]
        getitem_132 = native_batch_norm_default_43[1]
        getitem_133 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        relu__default_53 = torch.ops.aten.relu_.default(getitem_131);  getitem_131 = None
        convolution_default_70 = torch.ops.aten.convolution.default(relu__default_53, primals_615, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_70, primals_608, primals_604, primals_606, primals_607, True, 0.1, 1e-05);  primals_604 = None
        getitem_134 = native_batch_norm_default_44[0]
        getitem_135 = native_batch_norm_default_44[1]
        getitem_136 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        relu__default_54 = torch.ops.aten.relu_.default(getitem_134);  getitem_134 = None
        convolution_default_71 = torch.ops.aten.convolution.default(relu__default_54, primals_616, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_71, primals_613, primals_609, primals_611, primals_612, True, 0.1, 1e-05);  primals_609 = None
        getitem_137 = native_batch_norm_default_45[0]
        getitem_138 = native_batch_norm_default_45[1]
        getitem_139 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        mean_dim_13 = torch.ops.aten.mean.dim(getitem_137, [2, 3], True)
        convolution_default_72 = torch.ops.aten.convolution.default(mean_dim_13, primals_618, primals_617, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_617 = None
        relu__default_55 = torch.ops.aten.relu_.default(convolution_default_72);  convolution_default_72 = None
        convolution_default_73 = torch.ops.aten.convolution.default(relu__default_55, primals_620, primals_619, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_619 = None
        sigmoid_default_13 = torch.ops.aten.sigmoid.default(convolution_default_73);  convolution_default_73 = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(getitem_137, sigmoid_default_13)
        add__tensor_59 = torch.ops.aten.add_.Tensor(mul_tensor_13, relu__default_52);  mul_tensor_13 = None
        relu__default_56 = torch.ops.aten.relu_.default(add__tensor_59);  add__tensor_59 = None
        convolution_default_74 = torch.ops.aten.convolution.default(relu__default_56, primals_636, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(convolution_default_74, primals_625, primals_621, primals_623, primals_624, True, 0.1, 1e-05);  primals_621 = None
        getitem_140 = native_batch_norm_default_46[0]
        getitem_141 = native_batch_norm_default_46[1]
        getitem_142 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        relu__default_57 = torch.ops.aten.relu_.default(getitem_140);  getitem_140 = None
        convolution_default_75 = torch.ops.aten.convolution.default(relu__default_57, primals_637, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(convolution_default_75, primals_630, primals_626, primals_628, primals_629, True, 0.1, 1e-05);  primals_626 = None
        getitem_143 = native_batch_norm_default_47[0]
        getitem_144 = native_batch_norm_default_47[1]
        getitem_145 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        relu__default_58 = torch.ops.aten.relu_.default(getitem_143);  getitem_143 = None
        convolution_default_76 = torch.ops.aten.convolution.default(relu__default_58, primals_638, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_76, primals_635, primals_631, primals_633, primals_634, True, 0.1, 1e-05);  primals_631 = None
        getitem_146 = native_batch_norm_default_48[0]
        getitem_147 = native_batch_norm_default_48[1]
        getitem_148 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        mean_dim_14 = torch.ops.aten.mean.dim(getitem_146, [2, 3], True)
        convolution_default_77 = torch.ops.aten.convolution.default(mean_dim_14, primals_640, primals_639, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_639 = None
        relu__default_59 = torch.ops.aten.relu_.default(convolution_default_77);  convolution_default_77 = None
        convolution_default_78 = torch.ops.aten.convolution.default(relu__default_59, primals_642, primals_641, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_641 = None
        sigmoid_default_14 = torch.ops.aten.sigmoid.default(convolution_default_78);  convolution_default_78 = None
        mul_tensor_14 = torch.ops.aten.mul.Tensor(getitem_146, sigmoid_default_14)
        add__tensor_63 = torch.ops.aten.add_.Tensor(mul_tensor_14, relu__default_56);  mul_tensor_14 = None
        relu__default_60 = torch.ops.aten.relu_.default(add__tensor_63);  add__tensor_63 = None
        convolution_default_79 = torch.ops.aten.convolution.default(relu__default_60, primals_658, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(convolution_default_79, primals_647, primals_643, primals_645, primals_646, True, 0.1, 1e-05);  primals_643 = None
        getitem_149 = native_batch_norm_default_49[0]
        getitem_150 = native_batch_norm_default_49[1]
        getitem_151 = native_batch_norm_default_49[2];  native_batch_norm_default_49 = None
        relu__default_61 = torch.ops.aten.relu_.default(getitem_149);  getitem_149 = None
        convolution_default_80 = torch.ops.aten.convolution.default(relu__default_61, primals_659, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(convolution_default_80, primals_652, primals_648, primals_650, primals_651, True, 0.1, 1e-05);  primals_648 = None
        getitem_152 = native_batch_norm_default_50[0]
        getitem_153 = native_batch_norm_default_50[1]
        getitem_154 = native_batch_norm_default_50[2];  native_batch_norm_default_50 = None
        relu__default_62 = torch.ops.aten.relu_.default(getitem_152);  getitem_152 = None
        convolution_default_81 = torch.ops.aten.convolution.default(relu__default_62, primals_660, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(convolution_default_81, primals_657, primals_653, primals_655, primals_656, True, 0.1, 1e-05);  primals_653 = None
        getitem_155 = native_batch_norm_default_51[0]
        getitem_156 = native_batch_norm_default_51[1]
        getitem_157 = native_batch_norm_default_51[2];  native_batch_norm_default_51 = None
        mean_dim_15 = torch.ops.aten.mean.dim(getitem_155, [2, 3], True)
        convolution_default_82 = torch.ops.aten.convolution.default(mean_dim_15, primals_662, primals_661, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_661 = None
        relu__default_63 = torch.ops.aten.relu_.default(convolution_default_82);  convolution_default_82 = None
        convolution_default_83 = torch.ops.aten.convolution.default(relu__default_63, primals_664, primals_663, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_663 = None
        sigmoid_default_15 = torch.ops.aten.sigmoid.default(convolution_default_83);  convolution_default_83 = None
        mul_tensor_15 = torch.ops.aten.mul.Tensor(getitem_155, sigmoid_default_15)
        add__tensor_67 = torch.ops.aten.add_.Tensor(mul_tensor_15, relu__default_60);  mul_tensor_15 = None
        relu__default_64 = torch.ops.aten.relu_.default(add__tensor_67);  add__tensor_67 = None
        convolution_default_84 = torch.ops.aten.convolution.default(relu__default_64, primals_680, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(convolution_default_84, primals_669, primals_665, primals_667, primals_668, True, 0.1, 1e-05);  primals_665 = None
        getitem_158 = native_batch_norm_default_52[0]
        getitem_159 = native_batch_norm_default_52[1]
        getitem_160 = native_batch_norm_default_52[2];  native_batch_norm_default_52 = None
        relu__default_65 = torch.ops.aten.relu_.default(getitem_158);  getitem_158 = None
        convolution_default_85 = torch.ops.aten.convolution.default(relu__default_65, primals_681, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_53 = torch.ops.aten.native_batch_norm.default(convolution_default_85, primals_674, primals_670, primals_672, primals_673, True, 0.1, 1e-05);  primals_670 = None
        getitem_161 = native_batch_norm_default_53[0]
        getitem_162 = native_batch_norm_default_53[1]
        getitem_163 = native_batch_norm_default_53[2];  native_batch_norm_default_53 = None
        relu__default_66 = torch.ops.aten.relu_.default(getitem_161);  getitem_161 = None
        convolution_default_86 = torch.ops.aten.convolution.default(relu__default_66, primals_682, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_54 = torch.ops.aten.native_batch_norm.default(convolution_default_86, primals_679, primals_675, primals_677, primals_678, True, 0.1, 1e-05);  primals_675 = None
        getitem_164 = native_batch_norm_default_54[0]
        getitem_165 = native_batch_norm_default_54[1]
        getitem_166 = native_batch_norm_default_54[2];  native_batch_norm_default_54 = None
        mean_dim_16 = torch.ops.aten.mean.dim(getitem_164, [2, 3], True)
        convolution_default_87 = torch.ops.aten.convolution.default(mean_dim_16, primals_684, primals_683, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_683 = None
        relu__default_67 = torch.ops.aten.relu_.default(convolution_default_87);  convolution_default_87 = None
        convolution_default_88 = torch.ops.aten.convolution.default(relu__default_67, primals_686, primals_685, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_685 = None
        sigmoid_default_16 = torch.ops.aten.sigmoid.default(convolution_default_88);  convolution_default_88 = None
        mul_tensor_16 = torch.ops.aten.mul.Tensor(getitem_164, sigmoid_default_16)
        add__tensor_71 = torch.ops.aten.add_.Tensor(mul_tensor_16, relu__default_64);  mul_tensor_16 = None
        relu__default_68 = torch.ops.aten.relu_.default(add__tensor_71);  add__tensor_71 = None
        convolution_default_89 = torch.ops.aten.convolution.default(relu__default_68, primals_218, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_55 = torch.ops.aten.native_batch_norm.default(convolution_default_89, primals_207, primals_203, primals_205, primals_206, True, 0.1, 1e-05);  primals_203 = None
        getitem_167 = native_batch_norm_default_55[0]
        getitem_168 = native_batch_norm_default_55[1]
        getitem_169 = native_batch_norm_default_55[2];  native_batch_norm_default_55 = None
        relu__default_69 = torch.ops.aten.relu_.default(getitem_167);  getitem_167 = None
        convolution_default_90 = torch.ops.aten.convolution.default(relu__default_69, primals_219, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_56 = torch.ops.aten.native_batch_norm.default(convolution_default_90, primals_212, primals_208, primals_210, primals_211, True, 0.1, 1e-05);  primals_208 = None
        getitem_170 = native_batch_norm_default_56[0]
        getitem_171 = native_batch_norm_default_56[1]
        getitem_172 = native_batch_norm_default_56[2];  native_batch_norm_default_56 = None
        relu__default_70 = torch.ops.aten.relu_.default(getitem_170);  getitem_170 = None
        convolution_default_91 = torch.ops.aten.convolution.default(relu__default_70, primals_220, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_57 = torch.ops.aten.native_batch_norm.default(convolution_default_91, primals_217, primals_213, primals_215, primals_216, True, 0.1, 1e-05);  primals_213 = None
        getitem_173 = native_batch_norm_default_57[0]
        getitem_174 = native_batch_norm_default_57[1]
        getitem_175 = native_batch_norm_default_57[2];  native_batch_norm_default_57 = None
        mean_dim_17 = torch.ops.aten.mean.dim(getitem_173, [2, 3], True)
        convolution_default_92 = torch.ops.aten.convolution.default(mean_dim_17, primals_222, primals_221, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_221 = None
        relu__default_71 = torch.ops.aten.relu_.default(convolution_default_92);  convolution_default_92 = None
        convolution_default_93 = torch.ops.aten.convolution.default(relu__default_71, primals_224, primals_223, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_223 = None
        sigmoid_default_17 = torch.ops.aten.sigmoid.default(convolution_default_93);  convolution_default_93 = None
        mul_tensor_17 = torch.ops.aten.mul.Tensor(getitem_173, sigmoid_default_17)
        add__tensor_75 = torch.ops.aten.add_.Tensor(mul_tensor_17, relu__default_68);  mul_tensor_17 = None
        relu__default_72 = torch.ops.aten.relu_.default(add__tensor_75);  add__tensor_75 = None
        convolution_default_94 = torch.ops.aten.convolution.default(relu__default_72, primals_240, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_58 = torch.ops.aten.native_batch_norm.default(convolution_default_94, primals_229, primals_225, primals_227, primals_228, True, 0.1, 1e-05);  primals_225 = None
        getitem_176 = native_batch_norm_default_58[0]
        getitem_177 = native_batch_norm_default_58[1]
        getitem_178 = native_batch_norm_default_58[2];  native_batch_norm_default_58 = None
        relu__default_73 = torch.ops.aten.relu_.default(getitem_176);  getitem_176 = None
        convolution_default_95 = torch.ops.aten.convolution.default(relu__default_73, primals_241, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_59 = torch.ops.aten.native_batch_norm.default(convolution_default_95, primals_234, primals_230, primals_232, primals_233, True, 0.1, 1e-05);  primals_230 = None
        getitem_179 = native_batch_norm_default_59[0]
        getitem_180 = native_batch_norm_default_59[1]
        getitem_181 = native_batch_norm_default_59[2];  native_batch_norm_default_59 = None
        relu__default_74 = torch.ops.aten.relu_.default(getitem_179);  getitem_179 = None
        convolution_default_96 = torch.ops.aten.convolution.default(relu__default_74, primals_242, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_60 = torch.ops.aten.native_batch_norm.default(convolution_default_96, primals_239, primals_235, primals_237, primals_238, True, 0.1, 1e-05);  primals_235 = None
        getitem_182 = native_batch_norm_default_60[0]
        getitem_183 = native_batch_norm_default_60[1]
        getitem_184 = native_batch_norm_default_60[2];  native_batch_norm_default_60 = None
        mean_dim_18 = torch.ops.aten.mean.dim(getitem_182, [2, 3], True)
        convolution_default_97 = torch.ops.aten.convolution.default(mean_dim_18, primals_244, primals_243, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_243 = None
        relu__default_75 = torch.ops.aten.relu_.default(convolution_default_97);  convolution_default_97 = None
        convolution_default_98 = torch.ops.aten.convolution.default(relu__default_75, primals_246, primals_245, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_245 = None
        sigmoid_default_18 = torch.ops.aten.sigmoid.default(convolution_default_98);  convolution_default_98 = None
        mul_tensor_18 = torch.ops.aten.mul.Tensor(getitem_182, sigmoid_default_18)
        add__tensor_79 = torch.ops.aten.add_.Tensor(mul_tensor_18, relu__default_72);  mul_tensor_18 = None
        relu__default_76 = torch.ops.aten.relu_.default(add__tensor_79);  add__tensor_79 = None
        convolution_default_99 = torch.ops.aten.convolution.default(relu__default_76, primals_262, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_61 = torch.ops.aten.native_batch_norm.default(convolution_default_99, primals_251, primals_247, primals_249, primals_250, True, 0.1, 1e-05);  primals_247 = None
        getitem_185 = native_batch_norm_default_61[0]
        getitem_186 = native_batch_norm_default_61[1]
        getitem_187 = native_batch_norm_default_61[2];  native_batch_norm_default_61 = None
        relu__default_77 = torch.ops.aten.relu_.default(getitem_185);  getitem_185 = None
        convolution_default_100 = torch.ops.aten.convolution.default(relu__default_77, primals_263, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_62 = torch.ops.aten.native_batch_norm.default(convolution_default_100, primals_256, primals_252, primals_254, primals_255, True, 0.1, 1e-05);  primals_252 = None
        getitem_188 = native_batch_norm_default_62[0]
        getitem_189 = native_batch_norm_default_62[1]
        getitem_190 = native_batch_norm_default_62[2];  native_batch_norm_default_62 = None
        relu__default_78 = torch.ops.aten.relu_.default(getitem_188);  getitem_188 = None
        convolution_default_101 = torch.ops.aten.convolution.default(relu__default_78, primals_264, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_63 = torch.ops.aten.native_batch_norm.default(convolution_default_101, primals_261, primals_257, primals_259, primals_260, True, 0.1, 1e-05);  primals_257 = None
        getitem_191 = native_batch_norm_default_63[0]
        getitem_192 = native_batch_norm_default_63[1]
        getitem_193 = native_batch_norm_default_63[2];  native_batch_norm_default_63 = None
        mean_dim_19 = torch.ops.aten.mean.dim(getitem_191, [2, 3], True)
        convolution_default_102 = torch.ops.aten.convolution.default(mean_dim_19, primals_266, primals_265, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_265 = None
        relu__default_79 = torch.ops.aten.relu_.default(convolution_default_102);  convolution_default_102 = None
        convolution_default_103 = torch.ops.aten.convolution.default(relu__default_79, primals_268, primals_267, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_267 = None
        sigmoid_default_19 = torch.ops.aten.sigmoid.default(convolution_default_103);  convolution_default_103 = None
        mul_tensor_19 = torch.ops.aten.mul.Tensor(getitem_191, sigmoid_default_19)
        add__tensor_83 = torch.ops.aten.add_.Tensor(mul_tensor_19, relu__default_76);  mul_tensor_19 = None
        relu__default_80 = torch.ops.aten.relu_.default(add__tensor_83);  add__tensor_83 = None
        convolution_default_104 = torch.ops.aten.convolution.default(relu__default_80, primals_284, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_64 = torch.ops.aten.native_batch_norm.default(convolution_default_104, primals_273, primals_269, primals_271, primals_272, True, 0.1, 1e-05);  primals_269 = None
        getitem_194 = native_batch_norm_default_64[0]
        getitem_195 = native_batch_norm_default_64[1]
        getitem_196 = native_batch_norm_default_64[2];  native_batch_norm_default_64 = None
        relu__default_81 = torch.ops.aten.relu_.default(getitem_194);  getitem_194 = None
        convolution_default_105 = torch.ops.aten.convolution.default(relu__default_81, primals_285, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_65 = torch.ops.aten.native_batch_norm.default(convolution_default_105, primals_278, primals_274, primals_276, primals_277, True, 0.1, 1e-05);  primals_274 = None
        getitem_197 = native_batch_norm_default_65[0]
        getitem_198 = native_batch_norm_default_65[1]
        getitem_199 = native_batch_norm_default_65[2];  native_batch_norm_default_65 = None
        relu__default_82 = torch.ops.aten.relu_.default(getitem_197);  getitem_197 = None
        convolution_default_106 = torch.ops.aten.convolution.default(relu__default_82, primals_286, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_66 = torch.ops.aten.native_batch_norm.default(convolution_default_106, primals_283, primals_279, primals_281, primals_282, True, 0.1, 1e-05);  primals_279 = None
        getitem_200 = native_batch_norm_default_66[0]
        getitem_201 = native_batch_norm_default_66[1]
        getitem_202 = native_batch_norm_default_66[2];  native_batch_norm_default_66 = None
        mean_dim_20 = torch.ops.aten.mean.dim(getitem_200, [2, 3], True)
        convolution_default_107 = torch.ops.aten.convolution.default(mean_dim_20, primals_288, primals_287, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_287 = None
        relu__default_83 = torch.ops.aten.relu_.default(convolution_default_107);  convolution_default_107 = None
        convolution_default_108 = torch.ops.aten.convolution.default(relu__default_83, primals_290, primals_289, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_289 = None
        sigmoid_default_20 = torch.ops.aten.sigmoid.default(convolution_default_108);  convolution_default_108 = None
        mul_tensor_20 = torch.ops.aten.mul.Tensor(getitem_200, sigmoid_default_20)
        add__tensor_87 = torch.ops.aten.add_.Tensor(mul_tensor_20, relu__default_80);  mul_tensor_20 = None
        relu__default_84 = torch.ops.aten.relu_.default(add__tensor_87);  add__tensor_87 = None
        convolution_default_109 = torch.ops.aten.convolution.default(relu__default_84, primals_306, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_67 = torch.ops.aten.native_batch_norm.default(convolution_default_109, primals_295, primals_291, primals_293, primals_294, True, 0.1, 1e-05);  primals_291 = None
        getitem_203 = native_batch_norm_default_67[0]
        getitem_204 = native_batch_norm_default_67[1]
        getitem_205 = native_batch_norm_default_67[2];  native_batch_norm_default_67 = None
        relu__default_85 = torch.ops.aten.relu_.default(getitem_203);  getitem_203 = None
        convolution_default_110 = torch.ops.aten.convolution.default(relu__default_85, primals_307, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_68 = torch.ops.aten.native_batch_norm.default(convolution_default_110, primals_300, primals_296, primals_298, primals_299, True, 0.1, 1e-05);  primals_296 = None
        getitem_206 = native_batch_norm_default_68[0]
        getitem_207 = native_batch_norm_default_68[1]
        getitem_208 = native_batch_norm_default_68[2];  native_batch_norm_default_68 = None
        relu__default_86 = torch.ops.aten.relu_.default(getitem_206);  getitem_206 = None
        convolution_default_111 = torch.ops.aten.convolution.default(relu__default_86, primals_308, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_69 = torch.ops.aten.native_batch_norm.default(convolution_default_111, primals_305, primals_301, primals_303, primals_304, True, 0.1, 1e-05);  primals_301 = None
        getitem_209 = native_batch_norm_default_69[0]
        getitem_210 = native_batch_norm_default_69[1]
        getitem_211 = native_batch_norm_default_69[2];  native_batch_norm_default_69 = None
        mean_dim_21 = torch.ops.aten.mean.dim(getitem_209, [2, 3], True)
        convolution_default_112 = torch.ops.aten.convolution.default(mean_dim_21, primals_310, primals_309, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_309 = None
        relu__default_87 = torch.ops.aten.relu_.default(convolution_default_112);  convolution_default_112 = None
        convolution_default_113 = torch.ops.aten.convolution.default(relu__default_87, primals_312, primals_311, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_311 = None
        sigmoid_default_21 = torch.ops.aten.sigmoid.default(convolution_default_113);  convolution_default_113 = None
        mul_tensor_21 = torch.ops.aten.mul.Tensor(getitem_209, sigmoid_default_21)
        add__tensor_91 = torch.ops.aten.add_.Tensor(mul_tensor_21, relu__default_84);  mul_tensor_21 = None
        relu__default_88 = torch.ops.aten.relu_.default(add__tensor_91);  add__tensor_91 = None
        convolution_default_114 = torch.ops.aten.convolution.default(relu__default_88, primals_328, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_70 = torch.ops.aten.native_batch_norm.default(convolution_default_114, primals_317, primals_313, primals_315, primals_316, True, 0.1, 1e-05);  primals_313 = None
        getitem_212 = native_batch_norm_default_70[0]
        getitem_213 = native_batch_norm_default_70[1]
        getitem_214 = native_batch_norm_default_70[2];  native_batch_norm_default_70 = None
        relu__default_89 = torch.ops.aten.relu_.default(getitem_212);  getitem_212 = None
        convolution_default_115 = torch.ops.aten.convolution.default(relu__default_89, primals_329, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_71 = torch.ops.aten.native_batch_norm.default(convolution_default_115, primals_322, primals_318, primals_320, primals_321, True, 0.1, 1e-05);  primals_318 = None
        getitem_215 = native_batch_norm_default_71[0]
        getitem_216 = native_batch_norm_default_71[1]
        getitem_217 = native_batch_norm_default_71[2];  native_batch_norm_default_71 = None
        relu__default_90 = torch.ops.aten.relu_.default(getitem_215);  getitem_215 = None
        convolution_default_116 = torch.ops.aten.convolution.default(relu__default_90, primals_330, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_72 = torch.ops.aten.native_batch_norm.default(convolution_default_116, primals_327, primals_323, primals_325, primals_326, True, 0.1, 1e-05);  primals_323 = None
        getitem_218 = native_batch_norm_default_72[0]
        getitem_219 = native_batch_norm_default_72[1]
        getitem_220 = native_batch_norm_default_72[2];  native_batch_norm_default_72 = None
        mean_dim_22 = torch.ops.aten.mean.dim(getitem_218, [2, 3], True)
        convolution_default_117 = torch.ops.aten.convolution.default(mean_dim_22, primals_332, primals_331, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_331 = None
        relu__default_91 = torch.ops.aten.relu_.default(convolution_default_117);  convolution_default_117 = None
        convolution_default_118 = torch.ops.aten.convolution.default(relu__default_91, primals_334, primals_333, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_333 = None
        sigmoid_default_22 = torch.ops.aten.sigmoid.default(convolution_default_118);  convolution_default_118 = None
        mul_tensor_22 = torch.ops.aten.mul.Tensor(getitem_218, sigmoid_default_22)
        add__tensor_95 = torch.ops.aten.add_.Tensor(mul_tensor_22, relu__default_88);  mul_tensor_22 = None
        relu__default_92 = torch.ops.aten.relu_.default(add__tensor_95);  add__tensor_95 = None
        convolution_default_119 = torch.ops.aten.convolution.default(relu__default_92, primals_350, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_73 = torch.ops.aten.native_batch_norm.default(convolution_default_119, primals_339, primals_335, primals_337, primals_338, True, 0.1, 1e-05);  primals_335 = None
        getitem_221 = native_batch_norm_default_73[0]
        getitem_222 = native_batch_norm_default_73[1]
        getitem_223 = native_batch_norm_default_73[2];  native_batch_norm_default_73 = None
        relu__default_93 = torch.ops.aten.relu_.default(getitem_221);  getitem_221 = None
        convolution_default_120 = torch.ops.aten.convolution.default(relu__default_93, primals_351, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_74 = torch.ops.aten.native_batch_norm.default(convolution_default_120, primals_344, primals_340, primals_342, primals_343, True, 0.1, 1e-05);  primals_340 = None
        getitem_224 = native_batch_norm_default_74[0]
        getitem_225 = native_batch_norm_default_74[1]
        getitem_226 = native_batch_norm_default_74[2];  native_batch_norm_default_74 = None
        relu__default_94 = torch.ops.aten.relu_.default(getitem_224);  getitem_224 = None
        convolution_default_121 = torch.ops.aten.convolution.default(relu__default_94, primals_352, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_75 = torch.ops.aten.native_batch_norm.default(convolution_default_121, primals_349, primals_345, primals_347, primals_348, True, 0.1, 1e-05);  primals_345 = None
        getitem_227 = native_batch_norm_default_75[0]
        getitem_228 = native_batch_norm_default_75[1]
        getitem_229 = native_batch_norm_default_75[2];  native_batch_norm_default_75 = None
        mean_dim_23 = torch.ops.aten.mean.dim(getitem_227, [2, 3], True)
        convolution_default_122 = torch.ops.aten.convolution.default(mean_dim_23, primals_354, primals_353, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_353 = None
        relu__default_95 = torch.ops.aten.relu_.default(convolution_default_122);  convolution_default_122 = None
        convolution_default_123 = torch.ops.aten.convolution.default(relu__default_95, primals_356, primals_355, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_355 = None
        sigmoid_default_23 = torch.ops.aten.sigmoid.default(convolution_default_123);  convolution_default_123 = None
        mul_tensor_23 = torch.ops.aten.mul.Tensor(getitem_227, sigmoid_default_23)
        add__tensor_99 = torch.ops.aten.add_.Tensor(mul_tensor_23, relu__default_92);  mul_tensor_23 = None
        relu__default_96 = torch.ops.aten.relu_.default(add__tensor_99);  add__tensor_99 = None
        convolution_default_124 = torch.ops.aten.convolution.default(relu__default_96, primals_372, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_76 = torch.ops.aten.native_batch_norm.default(convolution_default_124, primals_361, primals_357, primals_359, primals_360, True, 0.1, 1e-05);  primals_357 = None
        getitem_230 = native_batch_norm_default_76[0]
        getitem_231 = native_batch_norm_default_76[1]
        getitem_232 = native_batch_norm_default_76[2];  native_batch_norm_default_76 = None
        relu__default_97 = torch.ops.aten.relu_.default(getitem_230);  getitem_230 = None
        convolution_default_125 = torch.ops.aten.convolution.default(relu__default_97, primals_373, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_77 = torch.ops.aten.native_batch_norm.default(convolution_default_125, primals_366, primals_362, primals_364, primals_365, True, 0.1, 1e-05);  primals_362 = None
        getitem_233 = native_batch_norm_default_77[0]
        getitem_234 = native_batch_norm_default_77[1]
        getitem_235 = native_batch_norm_default_77[2];  native_batch_norm_default_77 = None
        relu__default_98 = torch.ops.aten.relu_.default(getitem_233);  getitem_233 = None
        convolution_default_126 = torch.ops.aten.convolution.default(relu__default_98, primals_374, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_78 = torch.ops.aten.native_batch_norm.default(convolution_default_126, primals_371, primals_367, primals_369, primals_370, True, 0.1, 1e-05);  primals_367 = None
        getitem_236 = native_batch_norm_default_78[0]
        getitem_237 = native_batch_norm_default_78[1]
        getitem_238 = native_batch_norm_default_78[2];  native_batch_norm_default_78 = None
        mean_dim_24 = torch.ops.aten.mean.dim(getitem_236, [2, 3], True)
        convolution_default_127 = torch.ops.aten.convolution.default(mean_dim_24, primals_376, primals_375, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_375 = None
        relu__default_99 = torch.ops.aten.relu_.default(convolution_default_127);  convolution_default_127 = None
        convolution_default_128 = torch.ops.aten.convolution.default(relu__default_99, primals_378, primals_377, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_377 = None
        sigmoid_default_24 = torch.ops.aten.sigmoid.default(convolution_default_128);  convolution_default_128 = None
        mul_tensor_24 = torch.ops.aten.mul.Tensor(getitem_236, sigmoid_default_24)
        add__tensor_103 = torch.ops.aten.add_.Tensor(mul_tensor_24, relu__default_96);  mul_tensor_24 = None
        relu__default_100 = torch.ops.aten.relu_.default(add__tensor_103);  add__tensor_103 = None
        convolution_default_129 = torch.ops.aten.convolution.default(relu__default_100, primals_394, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_79 = torch.ops.aten.native_batch_norm.default(convolution_default_129, primals_383, primals_379, primals_381, primals_382, True, 0.1, 1e-05);  primals_379 = None
        getitem_239 = native_batch_norm_default_79[0]
        getitem_240 = native_batch_norm_default_79[1]
        getitem_241 = native_batch_norm_default_79[2];  native_batch_norm_default_79 = None
        relu__default_101 = torch.ops.aten.relu_.default(getitem_239);  getitem_239 = None
        convolution_default_130 = torch.ops.aten.convolution.default(relu__default_101, primals_395, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_80 = torch.ops.aten.native_batch_norm.default(convolution_default_130, primals_388, primals_384, primals_386, primals_387, True, 0.1, 1e-05);  primals_384 = None
        getitem_242 = native_batch_norm_default_80[0]
        getitem_243 = native_batch_norm_default_80[1]
        getitem_244 = native_batch_norm_default_80[2];  native_batch_norm_default_80 = None
        relu__default_102 = torch.ops.aten.relu_.default(getitem_242);  getitem_242 = None
        convolution_default_131 = torch.ops.aten.convolution.default(relu__default_102, primals_396, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_81 = torch.ops.aten.native_batch_norm.default(convolution_default_131, primals_393, primals_389, primals_391, primals_392, True, 0.1, 1e-05);  primals_389 = None
        getitem_245 = native_batch_norm_default_81[0]
        getitem_246 = native_batch_norm_default_81[1]
        getitem_247 = native_batch_norm_default_81[2];  native_batch_norm_default_81 = None
        mean_dim_25 = torch.ops.aten.mean.dim(getitem_245, [2, 3], True)
        convolution_default_132 = torch.ops.aten.convolution.default(mean_dim_25, primals_398, primals_397, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_397 = None
        relu__default_103 = torch.ops.aten.relu_.default(convolution_default_132);  convolution_default_132 = None
        convolution_default_133 = torch.ops.aten.convolution.default(relu__default_103, primals_400, primals_399, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_399 = None
        sigmoid_default_25 = torch.ops.aten.sigmoid.default(convolution_default_133);  convolution_default_133 = None
        mul_tensor_25 = torch.ops.aten.mul.Tensor(getitem_245, sigmoid_default_25)
        add__tensor_107 = torch.ops.aten.add_.Tensor(mul_tensor_25, relu__default_100);  mul_tensor_25 = None
        relu__default_104 = torch.ops.aten.relu_.default(add__tensor_107);  add__tensor_107 = None
        convolution_default_134 = torch.ops.aten.convolution.default(relu__default_104, primals_416, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_82 = torch.ops.aten.native_batch_norm.default(convolution_default_134, primals_405, primals_401, primals_403, primals_404, True, 0.1, 1e-05);  primals_401 = None
        getitem_248 = native_batch_norm_default_82[0]
        getitem_249 = native_batch_norm_default_82[1]
        getitem_250 = native_batch_norm_default_82[2];  native_batch_norm_default_82 = None
        relu__default_105 = torch.ops.aten.relu_.default(getitem_248);  getitem_248 = None
        convolution_default_135 = torch.ops.aten.convolution.default(relu__default_105, primals_417, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_83 = torch.ops.aten.native_batch_norm.default(convolution_default_135, primals_410, primals_406, primals_408, primals_409, True, 0.1, 1e-05);  primals_406 = None
        getitem_251 = native_batch_norm_default_83[0]
        getitem_252 = native_batch_norm_default_83[1]
        getitem_253 = native_batch_norm_default_83[2];  native_batch_norm_default_83 = None
        relu__default_106 = torch.ops.aten.relu_.default(getitem_251);  getitem_251 = None
        convolution_default_136 = torch.ops.aten.convolution.default(relu__default_106, primals_418, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_84 = torch.ops.aten.native_batch_norm.default(convolution_default_136, primals_415, primals_411, primals_413, primals_414, True, 0.1, 1e-05);  primals_411 = None
        getitem_254 = native_batch_norm_default_84[0]
        getitem_255 = native_batch_norm_default_84[1]
        getitem_256 = native_batch_norm_default_84[2];  native_batch_norm_default_84 = None
        mean_dim_26 = torch.ops.aten.mean.dim(getitem_254, [2, 3], True)
        convolution_default_137 = torch.ops.aten.convolution.default(mean_dim_26, primals_420, primals_419, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_419 = None
        relu__default_107 = torch.ops.aten.relu_.default(convolution_default_137);  convolution_default_137 = None
        convolution_default_138 = torch.ops.aten.convolution.default(relu__default_107, primals_422, primals_421, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_421 = None
        sigmoid_default_26 = torch.ops.aten.sigmoid.default(convolution_default_138);  convolution_default_138 = None
        mul_tensor_26 = torch.ops.aten.mul.Tensor(getitem_254, sigmoid_default_26)
        add__tensor_111 = torch.ops.aten.add_.Tensor(mul_tensor_26, relu__default_104);  mul_tensor_26 = None
        relu__default_108 = torch.ops.aten.relu_.default(add__tensor_111);  add__tensor_111 = None
        convolution_default_139 = torch.ops.aten.convolution.default(relu__default_108, primals_460, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_85 = torch.ops.aten.native_batch_norm.default(convolution_default_139, primals_449, primals_445, primals_447, primals_448, True, 0.1, 1e-05);  primals_445 = None
        getitem_257 = native_batch_norm_default_85[0]
        getitem_258 = native_batch_norm_default_85[1]
        getitem_259 = native_batch_norm_default_85[2];  native_batch_norm_default_85 = None
        relu__default_109 = torch.ops.aten.relu_.default(getitem_257);  getitem_257 = None
        convolution_default_140 = torch.ops.aten.convolution.default(relu__default_109, primals_461, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_86 = torch.ops.aten.native_batch_norm.default(convolution_default_140, primals_454, primals_450, primals_452, primals_453, True, 0.1, 1e-05);  primals_450 = None
        getitem_260 = native_batch_norm_default_86[0]
        getitem_261 = native_batch_norm_default_86[1]
        getitem_262 = native_batch_norm_default_86[2];  native_batch_norm_default_86 = None
        relu__default_110 = torch.ops.aten.relu_.default(getitem_260);  getitem_260 = None
        convolution_default_141 = torch.ops.aten.convolution.default(relu__default_110, primals_462, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_87 = torch.ops.aten.native_batch_norm.default(convolution_default_141, primals_459, primals_455, primals_457, primals_458, True, 0.1, 1e-05);  primals_455 = None
        getitem_263 = native_batch_norm_default_87[0]
        getitem_264 = native_batch_norm_default_87[1]
        getitem_265 = native_batch_norm_default_87[2];  native_batch_norm_default_87 = None
        mean_dim_27 = torch.ops.aten.mean.dim(getitem_263, [2, 3], True)
        convolution_default_142 = torch.ops.aten.convolution.default(mean_dim_27, primals_464, primals_463, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_463 = None
        relu__default_111 = torch.ops.aten.relu_.default(convolution_default_142);  convolution_default_142 = None
        convolution_default_143 = torch.ops.aten.convolution.default(relu__default_111, primals_466, primals_465, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_465 = None
        sigmoid_default_27 = torch.ops.aten.sigmoid.default(convolution_default_143);  convolution_default_143 = None
        mul_tensor_27 = torch.ops.aten.mul.Tensor(getitem_263, sigmoid_default_27)
        add__tensor_115 = torch.ops.aten.add_.Tensor(mul_tensor_27, relu__default_108);  mul_tensor_27 = None
        relu__default_112 = torch.ops.aten.relu_.default(add__tensor_115);  add__tensor_115 = None
        convolution_default_144 = torch.ops.aten.convolution.default(relu__default_112, primals_482, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_88 = torch.ops.aten.native_batch_norm.default(convolution_default_144, primals_471, primals_467, primals_469, primals_470, True, 0.1, 1e-05);  primals_467 = None
        getitem_266 = native_batch_norm_default_88[0]
        getitem_267 = native_batch_norm_default_88[1]
        getitem_268 = native_batch_norm_default_88[2];  native_batch_norm_default_88 = None
        relu__default_113 = torch.ops.aten.relu_.default(getitem_266);  getitem_266 = None
        convolution_default_145 = torch.ops.aten.convolution.default(relu__default_113, primals_483, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_89 = torch.ops.aten.native_batch_norm.default(convolution_default_145, primals_476, primals_472, primals_474, primals_475, True, 0.1, 1e-05);  primals_472 = None
        getitem_269 = native_batch_norm_default_89[0]
        getitem_270 = native_batch_norm_default_89[1]
        getitem_271 = native_batch_norm_default_89[2];  native_batch_norm_default_89 = None
        relu__default_114 = torch.ops.aten.relu_.default(getitem_269);  getitem_269 = None
        convolution_default_146 = torch.ops.aten.convolution.default(relu__default_114, primals_484, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_90 = torch.ops.aten.native_batch_norm.default(convolution_default_146, primals_481, primals_477, primals_479, primals_480, True, 0.1, 1e-05);  primals_477 = None
        getitem_272 = native_batch_norm_default_90[0]
        getitem_273 = native_batch_norm_default_90[1]
        getitem_274 = native_batch_norm_default_90[2];  native_batch_norm_default_90 = None
        mean_dim_28 = torch.ops.aten.mean.dim(getitem_272, [2, 3], True)
        convolution_default_147 = torch.ops.aten.convolution.default(mean_dim_28, primals_486, primals_485, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_485 = None
        relu__default_115 = torch.ops.aten.relu_.default(convolution_default_147);  convolution_default_147 = None
        convolution_default_148 = torch.ops.aten.convolution.default(relu__default_115, primals_488, primals_487, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_487 = None
        sigmoid_default_28 = torch.ops.aten.sigmoid.default(convolution_default_148);  convolution_default_148 = None
        mul_tensor_28 = torch.ops.aten.mul.Tensor(getitem_272, sigmoid_default_28)
        add__tensor_119 = torch.ops.aten.add_.Tensor(mul_tensor_28, relu__default_112);  mul_tensor_28 = None
        relu__default_116 = torch.ops.aten.relu_.default(add__tensor_119);  add__tensor_119 = None
        convolution_default_149 = torch.ops.aten.convolution.default(relu__default_116, primals_504, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_91 = torch.ops.aten.native_batch_norm.default(convolution_default_149, primals_493, primals_489, primals_491, primals_492, True, 0.1, 1e-05);  primals_489 = None
        getitem_275 = native_batch_norm_default_91[0]
        getitem_276 = native_batch_norm_default_91[1]
        getitem_277 = native_batch_norm_default_91[2];  native_batch_norm_default_91 = None
        relu__default_117 = torch.ops.aten.relu_.default(getitem_275);  getitem_275 = None
        convolution_default_150 = torch.ops.aten.convolution.default(relu__default_117, primals_505, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_92 = torch.ops.aten.native_batch_norm.default(convolution_default_150, primals_498, primals_494, primals_496, primals_497, True, 0.1, 1e-05);  primals_494 = None
        getitem_278 = native_batch_norm_default_92[0]
        getitem_279 = native_batch_norm_default_92[1]
        getitem_280 = native_batch_norm_default_92[2];  native_batch_norm_default_92 = None
        relu__default_118 = torch.ops.aten.relu_.default(getitem_278);  getitem_278 = None
        convolution_default_151 = torch.ops.aten.convolution.default(relu__default_118, primals_506, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_93 = torch.ops.aten.native_batch_norm.default(convolution_default_151, primals_503, primals_499, primals_501, primals_502, True, 0.1, 1e-05);  primals_499 = None
        getitem_281 = native_batch_norm_default_93[0]
        getitem_282 = native_batch_norm_default_93[1]
        getitem_283 = native_batch_norm_default_93[2];  native_batch_norm_default_93 = None
        mean_dim_29 = torch.ops.aten.mean.dim(getitem_281, [2, 3], True)
        convolution_default_152 = torch.ops.aten.convolution.default(mean_dim_29, primals_508, primals_507, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_507 = None
        relu__default_119 = torch.ops.aten.relu_.default(convolution_default_152);  convolution_default_152 = None
        convolution_default_153 = torch.ops.aten.convolution.default(relu__default_119, primals_510, primals_509, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_509 = None
        sigmoid_default_29 = torch.ops.aten.sigmoid.default(convolution_default_153);  convolution_default_153 = None
        mul_tensor_29 = torch.ops.aten.mul.Tensor(getitem_281, sigmoid_default_29)
        add__tensor_123 = torch.ops.aten.add_.Tensor(mul_tensor_29, relu__default_116);  mul_tensor_29 = None
        relu__default_120 = torch.ops.aten.relu_.default(add__tensor_123);  add__tensor_123 = None
        convolution_default_154 = torch.ops.aten.convolution.default(relu__default_120, primals_702, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_94 = torch.ops.aten.native_batch_norm.default(convolution_default_154, primals_691, primals_687, primals_689, primals_690, True, 0.1, 1e-05);  primals_687 = None
        getitem_284 = native_batch_norm_default_94[0]
        getitem_285 = native_batch_norm_default_94[1]
        getitem_286 = native_batch_norm_default_94[2];  native_batch_norm_default_94 = None
        relu__default_121 = torch.ops.aten.relu_.default(getitem_284);  getitem_284 = None
        convolution_default_155 = torch.ops.aten.convolution.default(relu__default_121, primals_703, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_95 = torch.ops.aten.native_batch_norm.default(convolution_default_155, primals_696, primals_692, primals_694, primals_695, True, 0.1, 1e-05);  primals_692 = None
        getitem_287 = native_batch_norm_default_95[0]
        getitem_288 = native_batch_norm_default_95[1]
        getitem_289 = native_batch_norm_default_95[2];  native_batch_norm_default_95 = None
        relu__default_122 = torch.ops.aten.relu_.default(getitem_287);  getitem_287 = None
        convolution_default_156 = torch.ops.aten.convolution.default(relu__default_122, primals_704, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_96 = torch.ops.aten.native_batch_norm.default(convolution_default_156, primals_701, primals_697, primals_699, primals_700, True, 0.1, 1e-05);  primals_697 = None
        getitem_290 = native_batch_norm_default_96[0]
        getitem_291 = native_batch_norm_default_96[1]
        getitem_292 = native_batch_norm_default_96[2];  native_batch_norm_default_96 = None
        mean_dim_30 = torch.ops.aten.mean.dim(getitem_290, [2, 3], True)
        convolution_default_157 = torch.ops.aten.convolution.default(mean_dim_30, primals_712, primals_711, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_711 = None
        relu__default_123 = torch.ops.aten.relu_.default(convolution_default_157);  convolution_default_157 = None
        convolution_default_158 = torch.ops.aten.convolution.default(relu__default_123, primals_714, primals_713, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_713 = None
        sigmoid_default_30 = torch.ops.aten.sigmoid.default(convolution_default_158);  convolution_default_158 = None
        mul_tensor_30 = torch.ops.aten.mul.Tensor(getitem_290, sigmoid_default_30)
        convolution_default_159 = torch.ops.aten.convolution.default(relu__default_120, primals_705, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_97 = torch.ops.aten.native_batch_norm.default(convolution_default_159, primals_710, primals_706, primals_708, primals_709, True, 0.1, 1e-05);  primals_706 = None
        getitem_293 = native_batch_norm_default_97[0]
        getitem_294 = native_batch_norm_default_97[1]
        getitem_295 = native_batch_norm_default_97[2];  native_batch_norm_default_97 = None
        add__tensor_128 = torch.ops.aten.add_.Tensor(mul_tensor_30, getitem_293);  mul_tensor_30 = getitem_293 = None
        relu__default_124 = torch.ops.aten.relu_.default(add__tensor_128);  add__tensor_128 = None
        convolution_default_160 = torch.ops.aten.convolution.default(relu__default_124, primals_730, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_98 = torch.ops.aten.native_batch_norm.default(convolution_default_160, primals_719, primals_715, primals_717, primals_718, True, 0.1, 1e-05);  primals_715 = None
        getitem_296 = native_batch_norm_default_98[0]
        getitem_297 = native_batch_norm_default_98[1]
        getitem_298 = native_batch_norm_default_98[2];  native_batch_norm_default_98 = None
        relu__default_125 = torch.ops.aten.relu_.default(getitem_296);  getitem_296 = None
        convolution_default_161 = torch.ops.aten.convolution.default(relu__default_125, primals_731, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_99 = torch.ops.aten.native_batch_norm.default(convolution_default_161, primals_724, primals_720, primals_722, primals_723, True, 0.1, 1e-05);  primals_720 = None
        getitem_299 = native_batch_norm_default_99[0]
        getitem_300 = native_batch_norm_default_99[1]
        getitem_301 = native_batch_norm_default_99[2];  native_batch_norm_default_99 = None
        relu__default_126 = torch.ops.aten.relu_.default(getitem_299);  getitem_299 = None
        convolution_default_162 = torch.ops.aten.convolution.default(relu__default_126, primals_732, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_100 = torch.ops.aten.native_batch_norm.default(convolution_default_162, primals_729, primals_725, primals_727, primals_728, True, 0.1, 1e-05);  primals_725 = None
        getitem_302 = native_batch_norm_default_100[0]
        getitem_303 = native_batch_norm_default_100[1]
        getitem_304 = native_batch_norm_default_100[2];  native_batch_norm_default_100 = None
        mean_dim_31 = torch.ops.aten.mean.dim(getitem_302, [2, 3], True)
        convolution_default_163 = torch.ops.aten.convolution.default(mean_dim_31, primals_734, primals_733, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_733 = None
        relu__default_127 = torch.ops.aten.relu_.default(convolution_default_163);  convolution_default_163 = None
        convolution_default_164 = torch.ops.aten.convolution.default(relu__default_127, primals_736, primals_735, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_735 = None
        sigmoid_default_31 = torch.ops.aten.sigmoid.default(convolution_default_164);  convolution_default_164 = None
        mul_tensor_31 = torch.ops.aten.mul.Tensor(getitem_302, sigmoid_default_31)
        add__tensor_132 = torch.ops.aten.add_.Tensor(mul_tensor_31, relu__default_124);  mul_tensor_31 = None
        relu__default_128 = torch.ops.aten.relu_.default(add__tensor_132);  add__tensor_132 = None
        convolution_default_165 = torch.ops.aten.convolution.default(relu__default_128, primals_752, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_101 = torch.ops.aten.native_batch_norm.default(convolution_default_165, primals_741, primals_737, primals_739, primals_740, True, 0.1, 1e-05);  primals_737 = None
        getitem_305 = native_batch_norm_default_101[0]
        getitem_306 = native_batch_norm_default_101[1]
        getitem_307 = native_batch_norm_default_101[2];  native_batch_norm_default_101 = None
        relu__default_129 = torch.ops.aten.relu_.default(getitem_305);  getitem_305 = None
        convolution_default_166 = torch.ops.aten.convolution.default(relu__default_129, primals_753, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_102 = torch.ops.aten.native_batch_norm.default(convolution_default_166, primals_746, primals_742, primals_744, primals_745, True, 0.1, 1e-05);  primals_742 = None
        getitem_308 = native_batch_norm_default_102[0]
        getitem_309 = native_batch_norm_default_102[1]
        getitem_310 = native_batch_norm_default_102[2];  native_batch_norm_default_102 = None
        relu__default_130 = torch.ops.aten.relu_.default(getitem_308);  getitem_308 = None
        convolution_default_167 = torch.ops.aten.convolution.default(relu__default_130, primals_754, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_103 = torch.ops.aten.native_batch_norm.default(convolution_default_167, primals_751, primals_747, primals_749, primals_750, True, 0.1, 1e-05);  primals_747 = None
        getitem_311 = native_batch_norm_default_103[0]
        getitem_312 = native_batch_norm_default_103[1]
        getitem_313 = native_batch_norm_default_103[2];  native_batch_norm_default_103 = None
        mean_dim_32 = torch.ops.aten.mean.dim(getitem_311, [2, 3], True)
        convolution_default_168 = torch.ops.aten.convolution.default(mean_dim_32, primals_756, primals_755, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_755 = None
        relu__default_131 = torch.ops.aten.relu_.default(convolution_default_168);  convolution_default_168 = None
        convolution_default_169 = torch.ops.aten.convolution.default(relu__default_131, primals_758, primals_757, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_757 = None
        sigmoid_default_32 = torch.ops.aten.sigmoid.default(convolution_default_169);  convolution_default_169 = None
        mul_tensor_32 = torch.ops.aten.mul.Tensor(getitem_311, sigmoid_default_32)
        add__tensor_136 = torch.ops.aten.add_.Tensor(mul_tensor_32, relu__default_128);  mul_tensor_32 = None
        relu__default_132 = torch.ops.aten.relu_.default(add__tensor_136);  add__tensor_136 = None
        mean_dim_33 = torch.ops.aten.mean.dim(relu__default_132, [-1, -2], True)
        view_default = torch.ops.aten.view.default(mean_dim_33, [128, 2048]);  mean_dim_33 = None
        t_default = torch.ops.aten.t.default(primals_8);  primals_8 = None
        addmm_default = torch.ops.aten.addmm.default(primals_7, view_default, t_default);  primals_7 = None
        return [addmm_default, relu__default_116, convolution_default_149, convolution_default_9, getitem_187, getitem_186, getitem_22, primals_337, getitem_151, getitem_21, mean_dim_8, getitem_150, primals_338, relu__default_47, relu__default_77, primals_334, relu__default_6, getitem_277, relu__default_61, getitem_276, getitem_90, convolution_default_80, convolution_default_100, getitem_190, relu__default_117, primals_339, getitem_189, getitem_25, primals_328, primals_332, getitem_24, sigmoid_default_11, getitem_23, primals_330, getitem_154, getitem_153, convolution_default_150, primals_327, relu__default_78, primals_326, relu__default_62, convolution_default_101, mean_dim_29, mean_dim_19, mean_dim_1, convolution_default_151, primals_344, convolution_default_81, getitem_279, primals_343, getitem_280, primals_329, relu__default_7, relu__default_51, mean_dim_15, relu__default_118, primals_342, getitem_192, getitem_191, primals_111, relu__default_39, getitem_58, convolution_default_49, getitem_136, relu__default_36, primals_104, getitem_135, primals_113, primals_112, relu__default_54, getitem_76, convolution_default_71, primals_58, relu__default_29, convolution_default_39, primals_106, getitem_139, getitem_138, primals_108, getitem_137, getitem_75, mean_dim_13, primals_56, relu__default_55, getitem_223, getitem_222, relu__default_93, convolution_default_120, getitem_100, convolution_default_51, getitem_226, getitem_228, getitem_225, getitem_102, relu__default_38, getitem_101, relu__default_94, mean_dim_9, convolution_default_121, mean_dim_23, getitem_99, getitem_227, getitem_87, getitem_229, getitem_103, primals_655, primals_744, relu__default_23, primals_657, primals_745, primals_642, primals_741, primals_658, primals_740, primals_739, primals_645, primals_659, primals_668, primals_647, primals_664, primals_650, primals_660, primals_736, primals_734, primals_667, primals_633, primals_662, primals_652, primals_732, sigmoid_default_5, primals_731, primals_730, primals_729, primals_637, primals_646, primals_728, primals_635, primals_636, primals_669, primals_634, primals_656, primals_727, primals_640, primals_651, primals_638, getitem_259, primals_359, primals_546, getitem_172, primals_51, getitem_171, primals_50, relu__default_109, primals_360, convolution_default_140, getitem_67, convolution_default_141, convolution_default_91, relu__default_70, primals_356, primals_373, primals_537, primals_365, primals_361, getitem_262, primals_45, getitem_261, primals_545, primals_536, primals_46, primals_54, primals_540, getitem_175, sigmoid_default_10, relu__default_110, primals_547, getitem_174, getitem_173, primals_372, primals_364, getitem_263, primals_548, getitem_66, primals_371, primals_370, primals_366, primals_554, getitem_264, mean_dim_17, getitem_265, primals_53, primals_541, primals_369, primals_552, relu__default_71, mean_dim_6, primals_52, primals_542, primals_44, primals_550, primals_354, primals_549, primals_49, convolution_default_34, sigmoid_default_17, mean_dim_27, sigmoid_default_32, relu__default_132, view_default, t_default, getitem_41, convolution_default_161, primals_271, getitem_42, primals_452, primals_273, getitem_43, getitem_298, getitem_297, primals_264, relu__default_125, primals_276, relu__default_15, relu__default_16, primals_268, sigmoid_default_3, primals_454, getitem_301, primals_448, getitem_300, primals_272, primals_277, convolution_default_23, primals_449, convolution_default_22, primals_262, primals_263, relu__default_126, getitem_45, primals_278, convolution_default_162, getitem_302, mean_dim_31, primals_266, getitem_46, primals_447, primals_453, primals_304, getitem_208, relu__default_102, primals_288, primals_620, convolution_default_131, primals_306, getitem_207, primals_30, primals_300, relu__default_86, primals_303, primals_36, primals_628, convolution_default_111, primals_294, primals_299, primals_629, primals_40, primals_290, getitem_247, primals_293, primals_630, getitem_246, getitem_245, primals_32, primals_625, primals_39, getitem_211, primals_624, getitem_210, getitem_209, primals_623, primals_305, primals_611, primals_612, mean_dim_21, primals_41, primals_31, primals_618, relu__default_103, relu__default_87, sigmoid_default_25, primals_34, primals_616, sigmoid_default_21, primals_298, primals_295, primals_615, relu__default_104, primals_614, primals_613, convolution_default_134, getitem_157, getitem_156, getitem_155, primals_754, primals_753, relu__default_63, primals_746, sigmoid_default_15, primals_756, relu__default_64, primals_759, primals_758, convolution_default_84, primals_749, primals_750, primals_751, getitem_159, primals_752, getitem_3, relu__default_8, convolution_default_12, primals_202, getitem_2, getitem_1, sigmoid_default_1, primals_215, primals_217, relu__default, primals_205, getitem_4, primals_216, getitem_28, getitem_27, primals_218, primals_219, relu__default_9, primals_211, convolution_default_1, sigmoid_default_12, primals_210, getitem_6, convolution_default_13, primals_207, getitem_7, mean_dim_2, primals_212, relu__default_1, getitem_30, primals_206, getitem_31, convolution_default_2, getitem_193, primals_165, primals_479, primals_168, primals_161, primals_234, primals_497, getitem_283, primals_496, getitem_110, getitem_106, getitem_120, getitem_282, getitem_281, getitem_119, primals_233, primals_593, getitem_111, relu__default_79, primals_602, primals_493, primals_594, sigmoid_default_19, primals_608, primals_492, primals_592, primals_491, relu__default_80, relu__default_41, primals_598, primals_167, relu__default_119, primals_601, primals_488, primals_596, primals_238, convolution_default_104, sigmoid_default_29, primals_486, primals_232, primals_169, primals_160, getitem_195, primals_603, primals_484, primals_241, convolution_default_105, primals_483, primals_239, relu__default_120, primals_242, primals_482, primals_607, primals_162, primals_240, convolution_default_154, primals_481, primals_480, relu__default_24, getitem_196, getitem_121, primals_237, primals_166, primals_606, primals_27, primals_23, relu__default_95, relu__default_40, primals_17, sigmoid_default_23, relu__default_96, primals_21, primals_12, convolution_default_124, primals_13, primals_22, getitem_105, primals_26, primals_16, primals_24, primals_18, getitem_231, getitem_232, relu__default_97, convolution_default_125, primals_11, primals_25, primals_518, primals_557, primals_564, primals_254, primals_568, primals_519, primals_567, relu__default_42, primals_523, primals_246, primals_249, primals_527, primals_574, relu__default_27, primals_572, primals_524, primals_571, primals_526, primals_250, convolution_default_56, primals_255, primals_563, primals_520, primals_244, primals_528, primals_525, primals_569, primals_260, primals_562, primals_530, primals_251, primals_259, primals_532, primals_535, primals_559, sigmoid_default_6, primals_558, primals_570, primals_261, primals_256, relu__default_72, getitem_128, convolution_default_94, relu__default_33, getitem_178, getitem_130, getitem_177, mean_dim_12, relu__default_73, getitem_129, getitem_126, getitem_127, convolution_default_95, relu__default_50, relu__default_49, convolution_default_66, mean_dim_18, convolution_default_96, getitem_180, getitem_181, relu__default_74, sigmoid_default_13, primals_405, getitem_93, relu__default_56, primals_415, getitem_92, primals_409, primals_417, primals_404, convolution_default_74, primals_410, getitem_142, getitem_141, primals_408, primals_403, primals_416, relu__default_57, primals_414, convolution_default_75, mean_dim_14, getitem_94, getitem_144, getitem_145, primals_413, relu__default_81, relu__default_88, getitem_64, convolution_default_114, primals_220, relu__default_111, getitem_62, convolution_default_115, primals_177, primals_179, primals_138, sigmoid_default_27, getitem_199, primals_178, getitem_198, getitem_214, relu__default_112, getitem_213, primals_228, primals_172, primals_135, primals_229, convolution_default_144, primals_128, convolution_default_33, relu__default_82, relu__default_89, primals_227, convolution_default_106, getitem_268, primals_134, getitem_267, primals_130, getitem_202, primals_222, convolution_default_45, mean_dim_22, getitem_201, getitem_200, getitem_216, primals_126, primals_170, getitem_217, relu__default_113, relu__default_90, sigmoid_default_7, relu__default_83, primals_133, primals_174, convolution_default_145, getitem_63, convolution_default_44, mean_dim_20, primals_224, convolution_default_116, primals_352, primals_510, relu__default_31, primals_93, primals_508, relu__default_32, primals_94, getitem_49, primals_678, primals_376, getitem_48, primals_95, primals_677, relu__default_43, primals_96, primals_351, primals_466, primals_515, primals_673, relu__default_17, primals_514, convolution_default_69, primals_469, relu__default_52, primals_458, convolution_default_24, primals_350, primals_99, primals_459, getitem_81, primals_674, primals_503, getitem_82, primals_513, primals_460, getitem_112, primals_374, primals_97, getitem_52, primals_470, primals_102, primals_504, getitem_51, convolution_default_59, primals_98, primals_461, primals_505, primals_672, primals_679, primals_89, primals_506, primals_349, primals_680, relu__default_18, primals_90, primals_464, primals_462, getitem_80, primals_103, primals_474, primals_681, primals_501, primals_475, primals_476, primals_498, primals_378, primals_471, primals_682, convolution_default_25, primals_684, primals_88, primals_457, primals_502, mean_dim_4, primals_348, primals_347, primals_71, getitem_10, primals_68, primals_117, getitem_9, mean_dim_10, convolution_default_64, relu__default_48, getitem_123, primals_67, relu__default_2, primals_116, primals_66, convolution_default_3, primals_121, getitem_13, getitem_12, getitem_11, getitem_61, convolution_default_65, getitem_60, relu__default_22, primals_118, mean_dim_5, sigmoid_default, primals_123, primals_62, primals_61, primals_124, getitem_124, mean_dim, primals_63, primals_122, relu__default_3, convolution_default_30, primals_125, convolution_default_155, getitem_303, primals_316, getitem_304, getitem_286, primals_317, getitem_285, primals_321, getitem_250, getitem_249, relu__default_121, relu__default_127, relu__default_105, primals_325, sigmoid_default_31, convolution_default_135, relu__default_128, getitem_289, getitem_288, primals_322, getitem_253, getitem_252, primals_320, relu__default_122, getitem_306, primals_307, convolution_default_165, primals_308, convolution_default_166, relu__default_106, convolution_default_156, primals_312, mean_dim_30, convolution_default_136, primals_310, getitem_307, mean_dim_26, getitem_291, primals_315, getitem_290, primals_704, primals_691, getitem_160, primals_690, relu__default_21, relu__default_65, convolution_default_85, primals_689, primals_696, getitem_163, primals_694, getitem_162, primals_695, relu__default_66, primals_702, convolution_default_86, getitem_164, primals_703, getitem_165, primals_701, convolution_default_29, primals_700, primals_686, getitem_166, primals_699, mean_dim_16, relu__default_10, convolution_default_14, primals_383, primals_398, getitem_132, primals_381, primals_382, getitem_34, primals_396, getitem_33, primals_394, getitem_32, getitem_133, primals_392, primals_386, primals_393, relu__default_11, primals_387, primals_391, sigmoid_default_2, primals_388, primals_395, primals_400, relu__default_12, convolution_default_17, primals_442, getitem_235, getitem_234, relu__default_98, sigmoid_default_8, convolution_default_126, getitem_238, getitem_237, getitem_236, primals_444, mean_dim_24, relu__default_35, relu__default_99, getitem_271, getitem_270, relu__default_114, convolution_default_146, getitem_274, getitem_273, getitem_272, convolution_default_43, mean_dim_28, relu__default_115, sigmoid_default_28, getitem_115, relu__default_58, convolution_default_76, getitem_184, getitem_183, getitem_182, getitem_148, getitem_147, getitem_146, relu__default_45, relu__default_75, convolution_default_60, getitem_114, relu__default_44, sigmoid_default_18, relu__default_59, sigmoid_default_14, relu__default_76, convolution_default_79, convolution_default_99, relu__default_60, primals_418, convolution_default_6, convolution_default_7, getitem_97, relu__default_37, getitem_16, getitem_15, getitem_96, convolution_default_50, primals_422, primals_420, relu__default_4, getitem_18, getitem_19, relu__default_5, convolution_default_8, getitem_55, getitem_54, getitem_220, convolution_default_40, getitem_219, getitem_53, getitem_79, getitem_218, primals_6, relu__default_19, primals_4, convolution_default_55, convolution_default_70, relu__default_91, sigmoid_default_4, getitem_78, sigmoid_default_9, relu__default_20, sigmoid_default_22, primals_3, relu__default_92, convolution_default_28, relu__default_53, relu__default_30, primals_5, getitem_84, convolution_default_119, convolution_default_54, getitem_57, mean_dim_7, getitem_256, primals_76, getitem_255, relu__default_28, getitem_254, primals_193, primals_75, primals_191, primals_74, primals_188, convolution_default_38, primals_80, primals_190, relu__default_107, primals_85, primals_192, primals_281, getitem_85, sigmoid_default_26, primals_196, primals_184, primals_283, relu__default_108, primals_189, primals_187, primals_286, primals_73, primals_182, primals_284, primals_84, primals_198, convolution_default_139, primals_78, primals_282, primals_72, primals_83, primals_197, getitem_258, primals_200, primals_183, primals_285, relu__default_129, primals_590, getitem_310, primals_585, getitem_309, primals_581, relu__default_130, primals_576, primals_584, convolution_default_167, getitem_311, primals_589, getitem_312, relu__default_131, getitem_313, primals_579, primals_591, primals_580, mean_dim_32, primals_586, primals_147, getitem_292, primals_425, relu__default_67, getitem_37, getitem_36, sigmoid_default_16, primals_145, primals_155, relu__default_68, primals_430, relu__default_123, primals_438, primals_148, relu__default_13, primals_152, convolution_default_89, sigmoid_default_30, primals_431, convolution_default_18, primals_143, primals_157, convolution_default_159, primals_427, relu__default_124, primals_435, primals_439, getitem_40, getitem_39, primals_426, getitem_169, primals_436, primals_156, getitem_168, primals_440, getitem_294, primals_150, relu__default_14, primals_432, primals_144, getitem_295, primals_437, relu__default_69, primals_140, convolution_default_19, mean_dim_3, convolution_default_90, convolution_default_160, primals_139, primals_146, convolution_default, convolution_default_46, primals_708, getitem_70, primals_709, getitem_73, sigmoid_default_20, primals_717, relu__default_84, getitem_109, primals_714, getitem_71, convolution_default_35, getitem_91, primals_712, getitem_72, getitem_108, convolution_default_109, primals_710, getitem_205, getitem_204, relu__default_25, primals_718, relu__default_85, primals_719, relu__default_26, primals_724, primals_705, convolution_default_110, primals_723, primals_722, getitem_69, relu__default_34, convolution_default_129, sigmoid_default_24, relu__default_46, relu__default_100, getitem_117, getitem_118, getitem_241, getitem_240, relu__default_101, convolution_default_61, convolution_default_130, mean_dim_11, mean_dim_25, getitem_243, getitem_244, getitem_88]
        
