
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/ssl_resnext101_32x16d/ssl_resnext101_32x16d_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339, primals_340, primals_341, primals_342, primals_343, primals_344, primals_345, primals_346, primals_347, primals_348, primals_349, primals_350, primals_351, primals_352, primals_353, primals_354, primals_355, primals_356, primals_357, primals_358, primals_359, primals_360, primals_361, primals_362, primals_363, primals_364, primals_365, primals_366, primals_367, primals_368, primals_369, primals_370, primals_371, primals_372, primals_373, primals_374, primals_375, primals_376, primals_377, primals_378, primals_379, primals_380, primals_381, primals_382, primals_383, primals_384, primals_385, primals_386, primals_387, primals_388, primals_389, primals_390, primals_391, primals_392, primals_393, primals_394, primals_395, primals_396, primals_397, primals_398, primals_399, primals_400, primals_401, primals_402, primals_403, primals_404, primals_405, primals_406, primals_407, primals_408, primals_409, primals_410, primals_411, primals_412, primals_413, primals_414, primals_415, primals_416, primals_417, primals_418, primals_419, primals_420, primals_421, primals_422, primals_423, primals_424, primals_425, primals_426, primals_427, primals_428, primals_429, primals_430, primals_431, primals_432, primals_433, primals_434, primals_435, primals_436, primals_437, primals_438, primals_439, primals_440, primals_441, primals_442, primals_443, primals_444, primals_445, primals_446, primals_447, primals_448, primals_449, primals_450, primals_451, primals_452, primals_453, primals_454, primals_455, primals_456, primals_457, primals_458, primals_459, primals_460, primals_461, primals_462, primals_463, primals_464, primals_465, primals_466, primals_467, primals_468, primals_469, primals_470, primals_471, primals_472, primals_473, primals_474, primals_475, primals_476, primals_477, primals_478, primals_479, primals_480, primals_481, primals_482, primals_483, primals_484, primals_485, primals_486, primals_487, primals_488, primals_489, primals_490, primals_491, primals_492, primals_493, primals_494, primals_495, primals_496, primals_497, primals_498, primals_499, primals_500, primals_501, primals_502, primals_503, primals_504, primals_505, primals_506, primals_507, primals_508, primals_509, primals_510, primals_511, primals_512, primals_513, primals_514, primals_515, primals_516, primals_517, primals_518, primals_519, primals_520, primals_521, primals_522, primals_523, primals_524, primals_525, primals_526, primals_527, primals_528, primals_529, primals_530, primals_531, primals_532, primals_533, primals_534, primals_535, primals_536, primals_537, primals_538, primals_539, primals_540, primals_541, primals_542, primals_543, primals_544, primals_545, primals_546, primals_547, primals_548, primals_549, primals_550, primals_551, primals_552, primals_553, primals_554, primals_555, primals_556, primals_557, primals_558, primals_559, primals_560, primals_561, primals_562, primals_563, primals_564, primals_565, primals_566, primals_567, primals_568, primals_569, primals_570, primals_571, primals_572, primals_573, primals_574, primals_575, primals_576, primals_577, primals_578, primals_579, primals_580, primals_581, primals_582, primals_583, primals_584, primals_585, primals_586, primals_587, primals_588, primals_589, primals_590, primals_591, primals_592, primals_593, primals_594, primals_595, primals_596, primals_597, primals_598, primals_599, primals_600, primals_601, primals_602, primals_603, primals_604, primals_605, primals_606, primals_607, primals_608, primals_609, primals_610, primals_611, primals_612, primals_613, primals_614, primals_615, primals_616, primals_617, primals_618, primals_619, primals_620, primals_621, primals_622, primals_623, primals_624, primals_625, primals_626, primals_627):
        convolution_default = torch.ops.aten.convolution.default(primals_627, primals_6, None, [2, 2], [3, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_5, primals_1, primals_3, primals_4, True, 0.1, 1e-05);  primals_1 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu__default, [3, 3], [2, 2], [1, 1])
        getitem_3 = max_pool2d_with_indices_default[0]
        getitem_4 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_1 = torch.ops.aten.convolution.default(getitem_3, primals_24, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_13, primals_9, primals_11, primals_12, True, 0.1, 1e-05);  primals_9 = None
        getitem_5 = native_batch_norm_default_1[0]
        getitem_6 = native_batch_norm_default_1[1]
        getitem_7 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        relu__default_1 = torch.ops.aten.relu_.default(getitem_5);  getitem_5 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_25, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_18, primals_14, primals_16, primals_17, True, 0.1, 1e-05);  primals_14 = None
        getitem_8 = native_batch_norm_default_2[0]
        getitem_9 = native_batch_norm_default_2[1]
        getitem_10 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        relu__default_2 = torch.ops.aten.relu_.default(getitem_8);  getitem_8 = None
        convolution_default_3 = torch.ops.aten.convolution.default(relu__default_2, primals_26, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_23, primals_19, primals_21, primals_22, True, 0.1, 1e-05);  primals_19 = None
        getitem_11 = native_batch_norm_default_3[0]
        getitem_12 = native_batch_norm_default_3[1]
        getitem_13 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        convolution_default_4 = torch.ops.aten.convolution.default(getitem_3, primals_27, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_32, primals_28, primals_30, primals_31, True, 0.1, 1e-05);  primals_28 = None
        getitem_14 = native_batch_norm_default_4[0]
        getitem_15 = native_batch_norm_default_4[1]
        getitem_16 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        add__tensor_5 = torch.ops.aten.add_.Tensor(getitem_11, getitem_14);  getitem_11 = getitem_14 = None
        relu__default_3 = torch.ops.aten.relu_.default(add__tensor_5);  add__tensor_5 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_3, primals_48, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_37, primals_33, primals_35, primals_36, True, 0.1, 1e-05);  primals_33 = None
        getitem_17 = native_batch_norm_default_5[0]
        getitem_18 = native_batch_norm_default_5[1]
        getitem_19 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        relu__default_4 = torch.ops.aten.relu_.default(getitem_17);  getitem_17 = None
        convolution_default_6 = torch.ops.aten.convolution.default(relu__default_4, primals_49, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_42, primals_38, primals_40, primals_41, True, 0.1, 1e-05);  primals_38 = None
        getitem_20 = native_batch_norm_default_6[0]
        getitem_21 = native_batch_norm_default_6[1]
        getitem_22 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        relu__default_5 = torch.ops.aten.relu_.default(getitem_20);  getitem_20 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_5, primals_50, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_47, primals_43, primals_45, primals_46, True, 0.1, 1e-05);  primals_43 = None
        getitem_23 = native_batch_norm_default_7[0]
        getitem_24 = native_batch_norm_default_7[1]
        getitem_25 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        add__tensor_9 = torch.ops.aten.add_.Tensor(getitem_23, relu__default_3);  getitem_23 = None
        relu__default_6 = torch.ops.aten.relu_.default(add__tensor_9);  add__tensor_9 = None
        convolution_default_8 = torch.ops.aten.convolution.default(relu__default_6, primals_66, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_55, primals_51, primals_53, primals_54, True, 0.1, 1e-05);  primals_51 = None
        getitem_26 = native_batch_norm_default_8[0]
        getitem_27 = native_batch_norm_default_8[1]
        getitem_28 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        relu__default_7 = torch.ops.aten.relu_.default(getitem_26);  getitem_26 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_7, primals_67, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_60, primals_56, primals_58, primals_59, True, 0.1, 1e-05);  primals_56 = None
        getitem_29 = native_batch_norm_default_9[0]
        getitem_30 = native_batch_norm_default_9[1]
        getitem_31 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        relu__default_8 = torch.ops.aten.relu_.default(getitem_29);  getitem_29 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default_8, primals_68, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_65, primals_61, primals_63, primals_64, True, 0.1, 1e-05);  primals_61 = None
        getitem_32 = native_batch_norm_default_10[0]
        getitem_33 = native_batch_norm_default_10[1]
        getitem_34 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        add__tensor_13 = torch.ops.aten.add_.Tensor(getitem_32, relu__default_6);  getitem_32 = None
        relu__default_9 = torch.ops.aten.relu_.default(add__tensor_13);  add__tensor_13 = None
        convolution_default_11 = torch.ops.aten.convolution.default(relu__default_9, primals_84, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_73, primals_69, primals_71, primals_72, True, 0.1, 1e-05);  primals_69 = None
        getitem_35 = native_batch_norm_default_11[0]
        getitem_36 = native_batch_norm_default_11[1]
        getitem_37 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        relu__default_10 = torch.ops.aten.relu_.default(getitem_35);  getitem_35 = None
        convolution_default_12 = torch.ops.aten.convolution.default(relu__default_10, primals_85, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_78, primals_74, primals_76, primals_77, True, 0.1, 1e-05);  primals_74 = None
        getitem_38 = native_batch_norm_default_12[0]
        getitem_39 = native_batch_norm_default_12[1]
        getitem_40 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        relu__default_11 = torch.ops.aten.relu_.default(getitem_38);  getitem_38 = None
        convolution_default_13 = torch.ops.aten.convolution.default(relu__default_11, primals_86, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_83, primals_79, primals_81, primals_82, True, 0.1, 1e-05);  primals_79 = None
        getitem_41 = native_batch_norm_default_13[0]
        getitem_42 = native_batch_norm_default_13[1]
        getitem_43 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        convolution_default_14 = torch.ops.aten.convolution.default(relu__default_9, primals_87, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_92, primals_88, primals_90, primals_91, True, 0.1, 1e-05);  primals_88 = None
        getitem_44 = native_batch_norm_default_14[0]
        getitem_45 = native_batch_norm_default_14[1]
        getitem_46 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        add__tensor_18 = torch.ops.aten.add_.Tensor(getitem_41, getitem_44);  getitem_41 = getitem_44 = None
        relu__default_12 = torch.ops.aten.relu_.default(add__tensor_18);  add__tensor_18 = None
        convolution_default_15 = torch.ops.aten.convolution.default(relu__default_12, primals_108, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_97, primals_93, primals_95, primals_96, True, 0.1, 1e-05);  primals_93 = None
        getitem_47 = native_batch_norm_default_15[0]
        getitem_48 = native_batch_norm_default_15[1]
        getitem_49 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        relu__default_13 = torch.ops.aten.relu_.default(getitem_47);  getitem_47 = None
        convolution_default_16 = torch.ops.aten.convolution.default(relu__default_13, primals_109, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_102, primals_98, primals_100, primals_101, True, 0.1, 1e-05);  primals_98 = None
        getitem_50 = native_batch_norm_default_16[0]
        getitem_51 = native_batch_norm_default_16[1]
        getitem_52 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        relu__default_14 = torch.ops.aten.relu_.default(getitem_50);  getitem_50 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu__default_14, primals_110, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_107, primals_103, primals_105, primals_106, True, 0.1, 1e-05);  primals_103 = None
        getitem_53 = native_batch_norm_default_17[0]
        getitem_54 = native_batch_norm_default_17[1]
        getitem_55 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        add__tensor_22 = torch.ops.aten.add_.Tensor(getitem_53, relu__default_12);  getitem_53 = None
        relu__default_15 = torch.ops.aten.relu_.default(add__tensor_22);  add__tensor_22 = None
        convolution_default_18 = torch.ops.aten.convolution.default(relu__default_15, primals_126, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_115, primals_111, primals_113, primals_114, True, 0.1, 1e-05);  primals_111 = None
        getitem_56 = native_batch_norm_default_18[0]
        getitem_57 = native_batch_norm_default_18[1]
        getitem_58 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        relu__default_16 = torch.ops.aten.relu_.default(getitem_56);  getitem_56 = None
        convolution_default_19 = torch.ops.aten.convolution.default(relu__default_16, primals_127, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_120, primals_116, primals_118, primals_119, True, 0.1, 1e-05);  primals_116 = None
        getitem_59 = native_batch_norm_default_19[0]
        getitem_60 = native_batch_norm_default_19[1]
        getitem_61 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        relu__default_17 = torch.ops.aten.relu_.default(getitem_59);  getitem_59 = None
        convolution_default_20 = torch.ops.aten.convolution.default(relu__default_17, primals_128, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_125, primals_121, primals_123, primals_124, True, 0.1, 1e-05);  primals_121 = None
        getitem_62 = native_batch_norm_default_20[0]
        getitem_63 = native_batch_norm_default_20[1]
        getitem_64 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        add__tensor_26 = torch.ops.aten.add_.Tensor(getitem_62, relu__default_15);  getitem_62 = None
        relu__default_18 = torch.ops.aten.relu_.default(add__tensor_26);  add__tensor_26 = None
        convolution_default_21 = torch.ops.aten.convolution.default(relu__default_18, primals_144, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_133, primals_129, primals_131, primals_132, True, 0.1, 1e-05);  primals_129 = None
        getitem_65 = native_batch_norm_default_21[0]
        getitem_66 = native_batch_norm_default_21[1]
        getitem_67 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        relu__default_19 = torch.ops.aten.relu_.default(getitem_65);  getitem_65 = None
        convolution_default_22 = torch.ops.aten.convolution.default(relu__default_19, primals_145, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_138, primals_134, primals_136, primals_137, True, 0.1, 1e-05);  primals_134 = None
        getitem_68 = native_batch_norm_default_22[0]
        getitem_69 = native_batch_norm_default_22[1]
        getitem_70 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        relu__default_20 = torch.ops.aten.relu_.default(getitem_68);  getitem_68 = None
        convolution_default_23 = torch.ops.aten.convolution.default(relu__default_20, primals_146, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_143, primals_139, primals_141, primals_142, True, 0.1, 1e-05);  primals_139 = None
        getitem_71 = native_batch_norm_default_23[0]
        getitem_72 = native_batch_norm_default_23[1]
        getitem_73 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        add__tensor_30 = torch.ops.aten.add_.Tensor(getitem_71, relu__default_18);  getitem_71 = None
        relu__default_21 = torch.ops.aten.relu_.default(add__tensor_30);  add__tensor_30 = None
        convolution_default_24 = torch.ops.aten.convolution.default(relu__default_21, primals_162, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_151, primals_147, primals_149, primals_150, True, 0.1, 1e-05);  primals_147 = None
        getitem_74 = native_batch_norm_default_24[0]
        getitem_75 = native_batch_norm_default_24[1]
        getitem_76 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        relu__default_22 = torch.ops.aten.relu_.default(getitem_74);  getitem_74 = None
        convolution_default_25 = torch.ops.aten.convolution.default(relu__default_22, primals_163, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_156, primals_152, primals_154, primals_155, True, 0.1, 1e-05);  primals_152 = None
        getitem_77 = native_batch_norm_default_25[0]
        getitem_78 = native_batch_norm_default_25[1]
        getitem_79 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        relu__default_23 = torch.ops.aten.relu_.default(getitem_77);  getitem_77 = None
        convolution_default_26 = torch.ops.aten.convolution.default(relu__default_23, primals_164, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_161, primals_157, primals_159, primals_160, True, 0.1, 1e-05);  primals_157 = None
        getitem_80 = native_batch_norm_default_26[0]
        getitem_81 = native_batch_norm_default_26[1]
        getitem_82 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        convolution_default_27 = torch.ops.aten.convolution.default(relu__default_21, primals_165, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_170, primals_166, primals_168, primals_169, True, 0.1, 1e-05);  primals_166 = None
        getitem_83 = native_batch_norm_default_27[0]
        getitem_84 = native_batch_norm_default_27[1]
        getitem_85 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        add__tensor_35 = torch.ops.aten.add_.Tensor(getitem_80, getitem_83);  getitem_80 = getitem_83 = None
        relu__default_24 = torch.ops.aten.relu_.default(add__tensor_35);  add__tensor_35 = None
        convolution_default_28 = torch.ops.aten.convolution.default(relu__default_24, primals_366, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_355, primals_351, primals_353, primals_354, True, 0.1, 1e-05);  primals_351 = None
        getitem_86 = native_batch_norm_default_28[0]
        getitem_87 = native_batch_norm_default_28[1]
        getitem_88 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        relu__default_25 = torch.ops.aten.relu_.default(getitem_86);  getitem_86 = None
        convolution_default_29 = torch.ops.aten.convolution.default(relu__default_25, primals_367, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_360, primals_356, primals_358, primals_359, True, 0.1, 1e-05);  primals_356 = None
        getitem_89 = native_batch_norm_default_29[0]
        getitem_90 = native_batch_norm_default_29[1]
        getitem_91 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        relu__default_26 = torch.ops.aten.relu_.default(getitem_89);  getitem_89 = None
        convolution_default_30 = torch.ops.aten.convolution.default(relu__default_26, primals_368, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_365, primals_361, primals_363, primals_364, True, 0.1, 1e-05);  primals_361 = None
        getitem_92 = native_batch_norm_default_30[0]
        getitem_93 = native_batch_norm_default_30[1]
        getitem_94 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        add__tensor_39 = torch.ops.aten.add_.Tensor(getitem_92, relu__default_24);  getitem_92 = None
        relu__default_27 = torch.ops.aten.relu_.default(add__tensor_39);  add__tensor_39 = None
        convolution_default_31 = torch.ops.aten.convolution.default(relu__default_27, primals_438, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_31, primals_427, primals_423, primals_425, primals_426, True, 0.1, 1e-05);  primals_423 = None
        getitem_95 = native_batch_norm_default_31[0]
        getitem_96 = native_batch_norm_default_31[1]
        getitem_97 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        relu__default_28 = torch.ops.aten.relu_.default(getitem_95);  getitem_95 = None
        convolution_default_32 = torch.ops.aten.convolution.default(relu__default_28, primals_439, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_432, primals_428, primals_430, primals_431, True, 0.1, 1e-05);  primals_428 = None
        getitem_98 = native_batch_norm_default_32[0]
        getitem_99 = native_batch_norm_default_32[1]
        getitem_100 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        relu__default_29 = torch.ops.aten.relu_.default(getitem_98);  getitem_98 = None
        convolution_default_33 = torch.ops.aten.convolution.default(relu__default_29, primals_440, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_437, primals_433, primals_435, primals_436, True, 0.1, 1e-05);  primals_433 = None
        getitem_101 = native_batch_norm_default_33[0]
        getitem_102 = native_batch_norm_default_33[1]
        getitem_103 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        add__tensor_43 = torch.ops.aten.add_.Tensor(getitem_101, relu__default_27);  getitem_101 = None
        relu__default_30 = torch.ops.aten.relu_.default(add__tensor_43);  add__tensor_43 = None
        convolution_default_34 = torch.ops.aten.convolution.default(relu__default_30, primals_456, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_445, primals_441, primals_443, primals_444, True, 0.1, 1e-05);  primals_441 = None
        getitem_104 = native_batch_norm_default_34[0]
        getitem_105 = native_batch_norm_default_34[1]
        getitem_106 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        relu__default_31 = torch.ops.aten.relu_.default(getitem_104);  getitem_104 = None
        convolution_default_35 = torch.ops.aten.convolution.default(relu__default_31, primals_457, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_450, primals_446, primals_448, primals_449, True, 0.1, 1e-05);  primals_446 = None
        getitem_107 = native_batch_norm_default_35[0]
        getitem_108 = native_batch_norm_default_35[1]
        getitem_109 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        relu__default_32 = torch.ops.aten.relu_.default(getitem_107);  getitem_107 = None
        convolution_default_36 = torch.ops.aten.convolution.default(relu__default_32, primals_458, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_455, primals_451, primals_453, primals_454, True, 0.1, 1e-05);  primals_451 = None
        getitem_110 = native_batch_norm_default_36[0]
        getitem_111 = native_batch_norm_default_36[1]
        getitem_112 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        add__tensor_47 = torch.ops.aten.add_.Tensor(getitem_110, relu__default_30);  getitem_110 = None
        relu__default_33 = torch.ops.aten.relu_.default(add__tensor_47);  add__tensor_47 = None
        convolution_default_37 = torch.ops.aten.convolution.default(relu__default_33, primals_474, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_37, primals_463, primals_459, primals_461, primals_462, True, 0.1, 1e-05);  primals_459 = None
        getitem_113 = native_batch_norm_default_37[0]
        getitem_114 = native_batch_norm_default_37[1]
        getitem_115 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        relu__default_34 = torch.ops.aten.relu_.default(getitem_113);  getitem_113 = None
        convolution_default_38 = torch.ops.aten.convolution.default(relu__default_34, primals_475, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_468, primals_464, primals_466, primals_467, True, 0.1, 1e-05);  primals_464 = None
        getitem_116 = native_batch_norm_default_38[0]
        getitem_117 = native_batch_norm_default_38[1]
        getitem_118 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        relu__default_35 = torch.ops.aten.relu_.default(getitem_116);  getitem_116 = None
        convolution_default_39 = torch.ops.aten.convolution.default(relu__default_35, primals_476, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_39, primals_473, primals_469, primals_471, primals_472, True, 0.1, 1e-05);  primals_469 = None
        getitem_119 = native_batch_norm_default_39[0]
        getitem_120 = native_batch_norm_default_39[1]
        getitem_121 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        add__tensor_51 = torch.ops.aten.add_.Tensor(getitem_119, relu__default_33);  getitem_119 = None
        relu__default_36 = torch.ops.aten.relu_.default(add__tensor_51);  add__tensor_51 = None
        convolution_default_40 = torch.ops.aten.convolution.default(relu__default_36, primals_492, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_481, primals_477, primals_479, primals_480, True, 0.1, 1e-05);  primals_477 = None
        getitem_122 = native_batch_norm_default_40[0]
        getitem_123 = native_batch_norm_default_40[1]
        getitem_124 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        relu__default_37 = torch.ops.aten.relu_.default(getitem_122);  getitem_122 = None
        convolution_default_41 = torch.ops.aten.convolution.default(relu__default_37, primals_493, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_41, primals_486, primals_482, primals_484, primals_485, True, 0.1, 1e-05);  primals_482 = None
        getitem_125 = native_batch_norm_default_41[0]
        getitem_126 = native_batch_norm_default_41[1]
        getitem_127 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        relu__default_38 = torch.ops.aten.relu_.default(getitem_125);  getitem_125 = None
        convolution_default_42 = torch.ops.aten.convolution.default(relu__default_38, primals_494, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_42, primals_491, primals_487, primals_489, primals_490, True, 0.1, 1e-05);  primals_487 = None
        getitem_128 = native_batch_norm_default_42[0]
        getitem_129 = native_batch_norm_default_42[1]
        getitem_130 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        add__tensor_55 = torch.ops.aten.add_.Tensor(getitem_128, relu__default_36);  getitem_128 = None
        relu__default_39 = torch.ops.aten.relu_.default(add__tensor_55);  add__tensor_55 = None
        convolution_default_43 = torch.ops.aten.convolution.default(relu__default_39, primals_510, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_43, primals_499, primals_495, primals_497, primals_498, True, 0.1, 1e-05);  primals_495 = None
        getitem_131 = native_batch_norm_default_43[0]
        getitem_132 = native_batch_norm_default_43[1]
        getitem_133 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        relu__default_40 = torch.ops.aten.relu_.default(getitem_131);  getitem_131 = None
        convolution_default_44 = torch.ops.aten.convolution.default(relu__default_40, primals_511, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_504, primals_500, primals_502, primals_503, True, 0.1, 1e-05);  primals_500 = None
        getitem_134 = native_batch_norm_default_44[0]
        getitem_135 = native_batch_norm_default_44[1]
        getitem_136 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        relu__default_41 = torch.ops.aten.relu_.default(getitem_134);  getitem_134 = None
        convolution_default_45 = torch.ops.aten.convolution.default(relu__default_41, primals_512, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_45, primals_509, primals_505, primals_507, primals_508, True, 0.1, 1e-05);  primals_505 = None
        getitem_137 = native_batch_norm_default_45[0]
        getitem_138 = native_batch_norm_default_45[1]
        getitem_139 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        add__tensor_59 = torch.ops.aten.add_.Tensor(getitem_137, relu__default_39);  getitem_137 = None
        relu__default_42 = torch.ops.aten.relu_.default(add__tensor_59);  add__tensor_59 = None
        convolution_default_46 = torch.ops.aten.convolution.default(relu__default_42, primals_528, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(convolution_default_46, primals_517, primals_513, primals_515, primals_516, True, 0.1, 1e-05);  primals_513 = None
        getitem_140 = native_batch_norm_default_46[0]
        getitem_141 = native_batch_norm_default_46[1]
        getitem_142 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        relu__default_43 = torch.ops.aten.relu_.default(getitem_140);  getitem_140 = None
        convolution_default_47 = torch.ops.aten.convolution.default(relu__default_43, primals_529, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(convolution_default_47, primals_522, primals_518, primals_520, primals_521, True, 0.1, 1e-05);  primals_518 = None
        getitem_143 = native_batch_norm_default_47[0]
        getitem_144 = native_batch_norm_default_47[1]
        getitem_145 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        relu__default_44 = torch.ops.aten.relu_.default(getitem_143);  getitem_143 = None
        convolution_default_48 = torch.ops.aten.convolution.default(relu__default_44, primals_530, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_48, primals_527, primals_523, primals_525, primals_526, True, 0.1, 1e-05);  primals_523 = None
        getitem_146 = native_batch_norm_default_48[0]
        getitem_147 = native_batch_norm_default_48[1]
        getitem_148 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        add__tensor_63 = torch.ops.aten.add_.Tensor(getitem_146, relu__default_42);  getitem_146 = None
        relu__default_45 = torch.ops.aten.relu_.default(add__tensor_63);  add__tensor_63 = None
        convolution_default_49 = torch.ops.aten.convolution.default(relu__default_45, primals_546, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(convolution_default_49, primals_535, primals_531, primals_533, primals_534, True, 0.1, 1e-05);  primals_531 = None
        getitem_149 = native_batch_norm_default_49[0]
        getitem_150 = native_batch_norm_default_49[1]
        getitem_151 = native_batch_norm_default_49[2];  native_batch_norm_default_49 = None
        relu__default_46 = torch.ops.aten.relu_.default(getitem_149);  getitem_149 = None
        convolution_default_50 = torch.ops.aten.convolution.default(relu__default_46, primals_547, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(convolution_default_50, primals_540, primals_536, primals_538, primals_539, True, 0.1, 1e-05);  primals_536 = None
        getitem_152 = native_batch_norm_default_50[0]
        getitem_153 = native_batch_norm_default_50[1]
        getitem_154 = native_batch_norm_default_50[2];  native_batch_norm_default_50 = None
        relu__default_47 = torch.ops.aten.relu_.default(getitem_152);  getitem_152 = None
        convolution_default_51 = torch.ops.aten.convolution.default(relu__default_47, primals_548, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(convolution_default_51, primals_545, primals_541, primals_543, primals_544, True, 0.1, 1e-05);  primals_541 = None
        getitem_155 = native_batch_norm_default_51[0]
        getitem_156 = native_batch_norm_default_51[1]
        getitem_157 = native_batch_norm_default_51[2];  native_batch_norm_default_51 = None
        add__tensor_67 = torch.ops.aten.add_.Tensor(getitem_155, relu__default_45);  getitem_155 = None
        relu__default_48 = torch.ops.aten.relu_.default(add__tensor_67);  add__tensor_67 = None
        convolution_default_52 = torch.ops.aten.convolution.default(relu__default_48, primals_564, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(convolution_default_52, primals_553, primals_549, primals_551, primals_552, True, 0.1, 1e-05);  primals_549 = None
        getitem_158 = native_batch_norm_default_52[0]
        getitem_159 = native_batch_norm_default_52[1]
        getitem_160 = native_batch_norm_default_52[2];  native_batch_norm_default_52 = None
        relu__default_49 = torch.ops.aten.relu_.default(getitem_158);  getitem_158 = None
        convolution_default_53 = torch.ops.aten.convolution.default(relu__default_49, primals_565, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_53 = torch.ops.aten.native_batch_norm.default(convolution_default_53, primals_558, primals_554, primals_556, primals_557, True, 0.1, 1e-05);  primals_554 = None
        getitem_161 = native_batch_norm_default_53[0]
        getitem_162 = native_batch_norm_default_53[1]
        getitem_163 = native_batch_norm_default_53[2];  native_batch_norm_default_53 = None
        relu__default_50 = torch.ops.aten.relu_.default(getitem_161);  getitem_161 = None
        convolution_default_54 = torch.ops.aten.convolution.default(relu__default_50, primals_566, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_54 = torch.ops.aten.native_batch_norm.default(convolution_default_54, primals_563, primals_559, primals_561, primals_562, True, 0.1, 1e-05);  primals_559 = None
        getitem_164 = native_batch_norm_default_54[0]
        getitem_165 = native_batch_norm_default_54[1]
        getitem_166 = native_batch_norm_default_54[2];  native_batch_norm_default_54 = None
        add__tensor_71 = torch.ops.aten.add_.Tensor(getitem_164, relu__default_48);  getitem_164 = None
        relu__default_51 = torch.ops.aten.relu_.default(add__tensor_71);  add__tensor_71 = None
        convolution_default_55 = torch.ops.aten.convolution.default(relu__default_51, primals_186, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_55 = torch.ops.aten.native_batch_norm.default(convolution_default_55, primals_175, primals_171, primals_173, primals_174, True, 0.1, 1e-05);  primals_171 = None
        getitem_167 = native_batch_norm_default_55[0]
        getitem_168 = native_batch_norm_default_55[1]
        getitem_169 = native_batch_norm_default_55[2];  native_batch_norm_default_55 = None
        relu__default_52 = torch.ops.aten.relu_.default(getitem_167);  getitem_167 = None
        convolution_default_56 = torch.ops.aten.convolution.default(relu__default_52, primals_187, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_56 = torch.ops.aten.native_batch_norm.default(convolution_default_56, primals_180, primals_176, primals_178, primals_179, True, 0.1, 1e-05);  primals_176 = None
        getitem_170 = native_batch_norm_default_56[0]
        getitem_171 = native_batch_norm_default_56[1]
        getitem_172 = native_batch_norm_default_56[2];  native_batch_norm_default_56 = None
        relu__default_53 = torch.ops.aten.relu_.default(getitem_170);  getitem_170 = None
        convolution_default_57 = torch.ops.aten.convolution.default(relu__default_53, primals_188, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_57 = torch.ops.aten.native_batch_norm.default(convolution_default_57, primals_185, primals_181, primals_183, primals_184, True, 0.1, 1e-05);  primals_181 = None
        getitem_173 = native_batch_norm_default_57[0]
        getitem_174 = native_batch_norm_default_57[1]
        getitem_175 = native_batch_norm_default_57[2];  native_batch_norm_default_57 = None
        add__tensor_75 = torch.ops.aten.add_.Tensor(getitem_173, relu__default_51);  getitem_173 = None
        relu__default_54 = torch.ops.aten.relu_.default(add__tensor_75);  add__tensor_75 = None
        convolution_default_58 = torch.ops.aten.convolution.default(relu__default_54, primals_204, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_58 = torch.ops.aten.native_batch_norm.default(convolution_default_58, primals_193, primals_189, primals_191, primals_192, True, 0.1, 1e-05);  primals_189 = None
        getitem_176 = native_batch_norm_default_58[0]
        getitem_177 = native_batch_norm_default_58[1]
        getitem_178 = native_batch_norm_default_58[2];  native_batch_norm_default_58 = None
        relu__default_55 = torch.ops.aten.relu_.default(getitem_176);  getitem_176 = None
        convolution_default_59 = torch.ops.aten.convolution.default(relu__default_55, primals_205, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_59 = torch.ops.aten.native_batch_norm.default(convolution_default_59, primals_198, primals_194, primals_196, primals_197, True, 0.1, 1e-05);  primals_194 = None
        getitem_179 = native_batch_norm_default_59[0]
        getitem_180 = native_batch_norm_default_59[1]
        getitem_181 = native_batch_norm_default_59[2];  native_batch_norm_default_59 = None
        relu__default_56 = torch.ops.aten.relu_.default(getitem_179);  getitem_179 = None
        convolution_default_60 = torch.ops.aten.convolution.default(relu__default_56, primals_206, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_60 = torch.ops.aten.native_batch_norm.default(convolution_default_60, primals_203, primals_199, primals_201, primals_202, True, 0.1, 1e-05);  primals_199 = None
        getitem_182 = native_batch_norm_default_60[0]
        getitem_183 = native_batch_norm_default_60[1]
        getitem_184 = native_batch_norm_default_60[2];  native_batch_norm_default_60 = None
        add__tensor_79 = torch.ops.aten.add_.Tensor(getitem_182, relu__default_54);  getitem_182 = None
        relu__default_57 = torch.ops.aten.relu_.default(add__tensor_79);  add__tensor_79 = None
        convolution_default_61 = torch.ops.aten.convolution.default(relu__default_57, primals_222, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_61 = torch.ops.aten.native_batch_norm.default(convolution_default_61, primals_211, primals_207, primals_209, primals_210, True, 0.1, 1e-05);  primals_207 = None
        getitem_185 = native_batch_norm_default_61[0]
        getitem_186 = native_batch_norm_default_61[1]
        getitem_187 = native_batch_norm_default_61[2];  native_batch_norm_default_61 = None
        relu__default_58 = torch.ops.aten.relu_.default(getitem_185);  getitem_185 = None
        convolution_default_62 = torch.ops.aten.convolution.default(relu__default_58, primals_223, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_62 = torch.ops.aten.native_batch_norm.default(convolution_default_62, primals_216, primals_212, primals_214, primals_215, True, 0.1, 1e-05);  primals_212 = None
        getitem_188 = native_batch_norm_default_62[0]
        getitem_189 = native_batch_norm_default_62[1]
        getitem_190 = native_batch_norm_default_62[2];  native_batch_norm_default_62 = None
        relu__default_59 = torch.ops.aten.relu_.default(getitem_188);  getitem_188 = None
        convolution_default_63 = torch.ops.aten.convolution.default(relu__default_59, primals_224, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_63 = torch.ops.aten.native_batch_norm.default(convolution_default_63, primals_221, primals_217, primals_219, primals_220, True, 0.1, 1e-05);  primals_217 = None
        getitem_191 = native_batch_norm_default_63[0]
        getitem_192 = native_batch_norm_default_63[1]
        getitem_193 = native_batch_norm_default_63[2];  native_batch_norm_default_63 = None
        add__tensor_83 = torch.ops.aten.add_.Tensor(getitem_191, relu__default_57);  getitem_191 = None
        relu__default_60 = torch.ops.aten.relu_.default(add__tensor_83);  add__tensor_83 = None
        convolution_default_64 = torch.ops.aten.convolution.default(relu__default_60, primals_240, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_64 = torch.ops.aten.native_batch_norm.default(convolution_default_64, primals_229, primals_225, primals_227, primals_228, True, 0.1, 1e-05);  primals_225 = None
        getitem_194 = native_batch_norm_default_64[0]
        getitem_195 = native_batch_norm_default_64[1]
        getitem_196 = native_batch_norm_default_64[2];  native_batch_norm_default_64 = None
        relu__default_61 = torch.ops.aten.relu_.default(getitem_194);  getitem_194 = None
        convolution_default_65 = torch.ops.aten.convolution.default(relu__default_61, primals_241, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_65 = torch.ops.aten.native_batch_norm.default(convolution_default_65, primals_234, primals_230, primals_232, primals_233, True, 0.1, 1e-05);  primals_230 = None
        getitem_197 = native_batch_norm_default_65[0]
        getitem_198 = native_batch_norm_default_65[1]
        getitem_199 = native_batch_norm_default_65[2];  native_batch_norm_default_65 = None
        relu__default_62 = torch.ops.aten.relu_.default(getitem_197);  getitem_197 = None
        convolution_default_66 = torch.ops.aten.convolution.default(relu__default_62, primals_242, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_66 = torch.ops.aten.native_batch_norm.default(convolution_default_66, primals_239, primals_235, primals_237, primals_238, True, 0.1, 1e-05);  primals_235 = None
        getitem_200 = native_batch_norm_default_66[0]
        getitem_201 = native_batch_norm_default_66[1]
        getitem_202 = native_batch_norm_default_66[2];  native_batch_norm_default_66 = None
        add__tensor_87 = torch.ops.aten.add_.Tensor(getitem_200, relu__default_60);  getitem_200 = None
        relu__default_63 = torch.ops.aten.relu_.default(add__tensor_87);  add__tensor_87 = None
        convolution_default_67 = torch.ops.aten.convolution.default(relu__default_63, primals_258, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_67 = torch.ops.aten.native_batch_norm.default(convolution_default_67, primals_247, primals_243, primals_245, primals_246, True, 0.1, 1e-05);  primals_243 = None
        getitem_203 = native_batch_norm_default_67[0]
        getitem_204 = native_batch_norm_default_67[1]
        getitem_205 = native_batch_norm_default_67[2];  native_batch_norm_default_67 = None
        relu__default_64 = torch.ops.aten.relu_.default(getitem_203);  getitem_203 = None
        convolution_default_68 = torch.ops.aten.convolution.default(relu__default_64, primals_259, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_68 = torch.ops.aten.native_batch_norm.default(convolution_default_68, primals_252, primals_248, primals_250, primals_251, True, 0.1, 1e-05);  primals_248 = None
        getitem_206 = native_batch_norm_default_68[0]
        getitem_207 = native_batch_norm_default_68[1]
        getitem_208 = native_batch_norm_default_68[2];  native_batch_norm_default_68 = None
        relu__default_65 = torch.ops.aten.relu_.default(getitem_206);  getitem_206 = None
        convolution_default_69 = torch.ops.aten.convolution.default(relu__default_65, primals_260, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_69 = torch.ops.aten.native_batch_norm.default(convolution_default_69, primals_257, primals_253, primals_255, primals_256, True, 0.1, 1e-05);  primals_253 = None
        getitem_209 = native_batch_norm_default_69[0]
        getitem_210 = native_batch_norm_default_69[1]
        getitem_211 = native_batch_norm_default_69[2];  native_batch_norm_default_69 = None
        add__tensor_91 = torch.ops.aten.add_.Tensor(getitem_209, relu__default_63);  getitem_209 = None
        relu__default_66 = torch.ops.aten.relu_.default(add__tensor_91);  add__tensor_91 = None
        convolution_default_70 = torch.ops.aten.convolution.default(relu__default_66, primals_276, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_70 = torch.ops.aten.native_batch_norm.default(convolution_default_70, primals_265, primals_261, primals_263, primals_264, True, 0.1, 1e-05);  primals_261 = None
        getitem_212 = native_batch_norm_default_70[0]
        getitem_213 = native_batch_norm_default_70[1]
        getitem_214 = native_batch_norm_default_70[2];  native_batch_norm_default_70 = None
        relu__default_67 = torch.ops.aten.relu_.default(getitem_212);  getitem_212 = None
        convolution_default_71 = torch.ops.aten.convolution.default(relu__default_67, primals_277, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_71 = torch.ops.aten.native_batch_norm.default(convolution_default_71, primals_270, primals_266, primals_268, primals_269, True, 0.1, 1e-05);  primals_266 = None
        getitem_215 = native_batch_norm_default_71[0]
        getitem_216 = native_batch_norm_default_71[1]
        getitem_217 = native_batch_norm_default_71[2];  native_batch_norm_default_71 = None
        relu__default_68 = torch.ops.aten.relu_.default(getitem_215);  getitem_215 = None
        convolution_default_72 = torch.ops.aten.convolution.default(relu__default_68, primals_278, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_72 = torch.ops.aten.native_batch_norm.default(convolution_default_72, primals_275, primals_271, primals_273, primals_274, True, 0.1, 1e-05);  primals_271 = None
        getitem_218 = native_batch_norm_default_72[0]
        getitem_219 = native_batch_norm_default_72[1]
        getitem_220 = native_batch_norm_default_72[2];  native_batch_norm_default_72 = None
        add__tensor_95 = torch.ops.aten.add_.Tensor(getitem_218, relu__default_66);  getitem_218 = None
        relu__default_69 = torch.ops.aten.relu_.default(add__tensor_95);  add__tensor_95 = None
        convolution_default_73 = torch.ops.aten.convolution.default(relu__default_69, primals_294, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_73 = torch.ops.aten.native_batch_norm.default(convolution_default_73, primals_283, primals_279, primals_281, primals_282, True, 0.1, 1e-05);  primals_279 = None
        getitem_221 = native_batch_norm_default_73[0]
        getitem_222 = native_batch_norm_default_73[1]
        getitem_223 = native_batch_norm_default_73[2];  native_batch_norm_default_73 = None
        relu__default_70 = torch.ops.aten.relu_.default(getitem_221);  getitem_221 = None
        convolution_default_74 = torch.ops.aten.convolution.default(relu__default_70, primals_295, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_74 = torch.ops.aten.native_batch_norm.default(convolution_default_74, primals_288, primals_284, primals_286, primals_287, True, 0.1, 1e-05);  primals_284 = None
        getitem_224 = native_batch_norm_default_74[0]
        getitem_225 = native_batch_norm_default_74[1]
        getitem_226 = native_batch_norm_default_74[2];  native_batch_norm_default_74 = None
        relu__default_71 = torch.ops.aten.relu_.default(getitem_224);  getitem_224 = None
        convolution_default_75 = torch.ops.aten.convolution.default(relu__default_71, primals_296, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_75 = torch.ops.aten.native_batch_norm.default(convolution_default_75, primals_293, primals_289, primals_291, primals_292, True, 0.1, 1e-05);  primals_289 = None
        getitem_227 = native_batch_norm_default_75[0]
        getitem_228 = native_batch_norm_default_75[1]
        getitem_229 = native_batch_norm_default_75[2];  native_batch_norm_default_75 = None
        add__tensor_99 = torch.ops.aten.add_.Tensor(getitem_227, relu__default_69);  getitem_227 = None
        relu__default_72 = torch.ops.aten.relu_.default(add__tensor_99);  add__tensor_99 = None
        convolution_default_76 = torch.ops.aten.convolution.default(relu__default_72, primals_312, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_76 = torch.ops.aten.native_batch_norm.default(convolution_default_76, primals_301, primals_297, primals_299, primals_300, True, 0.1, 1e-05);  primals_297 = None
        getitem_230 = native_batch_norm_default_76[0]
        getitem_231 = native_batch_norm_default_76[1]
        getitem_232 = native_batch_norm_default_76[2];  native_batch_norm_default_76 = None
        relu__default_73 = torch.ops.aten.relu_.default(getitem_230);  getitem_230 = None
        convolution_default_77 = torch.ops.aten.convolution.default(relu__default_73, primals_313, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_77 = torch.ops.aten.native_batch_norm.default(convolution_default_77, primals_306, primals_302, primals_304, primals_305, True, 0.1, 1e-05);  primals_302 = None
        getitem_233 = native_batch_norm_default_77[0]
        getitem_234 = native_batch_norm_default_77[1]
        getitem_235 = native_batch_norm_default_77[2];  native_batch_norm_default_77 = None
        relu__default_74 = torch.ops.aten.relu_.default(getitem_233);  getitem_233 = None
        convolution_default_78 = torch.ops.aten.convolution.default(relu__default_74, primals_314, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_78 = torch.ops.aten.native_batch_norm.default(convolution_default_78, primals_311, primals_307, primals_309, primals_310, True, 0.1, 1e-05);  primals_307 = None
        getitem_236 = native_batch_norm_default_78[0]
        getitem_237 = native_batch_norm_default_78[1]
        getitem_238 = native_batch_norm_default_78[2];  native_batch_norm_default_78 = None
        add__tensor_103 = torch.ops.aten.add_.Tensor(getitem_236, relu__default_72);  getitem_236 = None
        relu__default_75 = torch.ops.aten.relu_.default(add__tensor_103);  add__tensor_103 = None
        convolution_default_79 = torch.ops.aten.convolution.default(relu__default_75, primals_330, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_79 = torch.ops.aten.native_batch_norm.default(convolution_default_79, primals_319, primals_315, primals_317, primals_318, True, 0.1, 1e-05);  primals_315 = None
        getitem_239 = native_batch_norm_default_79[0]
        getitem_240 = native_batch_norm_default_79[1]
        getitem_241 = native_batch_norm_default_79[2];  native_batch_norm_default_79 = None
        relu__default_76 = torch.ops.aten.relu_.default(getitem_239);  getitem_239 = None
        convolution_default_80 = torch.ops.aten.convolution.default(relu__default_76, primals_331, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_80 = torch.ops.aten.native_batch_norm.default(convolution_default_80, primals_324, primals_320, primals_322, primals_323, True, 0.1, 1e-05);  primals_320 = None
        getitem_242 = native_batch_norm_default_80[0]
        getitem_243 = native_batch_norm_default_80[1]
        getitem_244 = native_batch_norm_default_80[2];  native_batch_norm_default_80 = None
        relu__default_77 = torch.ops.aten.relu_.default(getitem_242);  getitem_242 = None
        convolution_default_81 = torch.ops.aten.convolution.default(relu__default_77, primals_332, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_81 = torch.ops.aten.native_batch_norm.default(convolution_default_81, primals_329, primals_325, primals_327, primals_328, True, 0.1, 1e-05);  primals_325 = None
        getitem_245 = native_batch_norm_default_81[0]
        getitem_246 = native_batch_norm_default_81[1]
        getitem_247 = native_batch_norm_default_81[2];  native_batch_norm_default_81 = None
        add__tensor_107 = torch.ops.aten.add_.Tensor(getitem_245, relu__default_75);  getitem_245 = None
        relu__default_78 = torch.ops.aten.relu_.default(add__tensor_107);  add__tensor_107 = None
        convolution_default_82 = torch.ops.aten.convolution.default(relu__default_78, primals_348, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_82 = torch.ops.aten.native_batch_norm.default(convolution_default_82, primals_337, primals_333, primals_335, primals_336, True, 0.1, 1e-05);  primals_333 = None
        getitem_248 = native_batch_norm_default_82[0]
        getitem_249 = native_batch_norm_default_82[1]
        getitem_250 = native_batch_norm_default_82[2];  native_batch_norm_default_82 = None
        relu__default_79 = torch.ops.aten.relu_.default(getitem_248);  getitem_248 = None
        convolution_default_83 = torch.ops.aten.convolution.default(relu__default_79, primals_349, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_83 = torch.ops.aten.native_batch_norm.default(convolution_default_83, primals_342, primals_338, primals_340, primals_341, True, 0.1, 1e-05);  primals_338 = None
        getitem_251 = native_batch_norm_default_83[0]
        getitem_252 = native_batch_norm_default_83[1]
        getitem_253 = native_batch_norm_default_83[2];  native_batch_norm_default_83 = None
        relu__default_80 = torch.ops.aten.relu_.default(getitem_251);  getitem_251 = None
        convolution_default_84 = torch.ops.aten.convolution.default(relu__default_80, primals_350, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_84 = torch.ops.aten.native_batch_norm.default(convolution_default_84, primals_347, primals_343, primals_345, primals_346, True, 0.1, 1e-05);  primals_343 = None
        getitem_254 = native_batch_norm_default_84[0]
        getitem_255 = native_batch_norm_default_84[1]
        getitem_256 = native_batch_norm_default_84[2];  native_batch_norm_default_84 = None
        add__tensor_111 = torch.ops.aten.add_.Tensor(getitem_254, relu__default_78);  getitem_254 = None
        relu__default_81 = torch.ops.aten.relu_.default(add__tensor_111);  add__tensor_111 = None
        convolution_default_85 = torch.ops.aten.convolution.default(relu__default_81, primals_384, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_85 = torch.ops.aten.native_batch_norm.default(convolution_default_85, primals_373, primals_369, primals_371, primals_372, True, 0.1, 1e-05);  primals_369 = None
        getitem_257 = native_batch_norm_default_85[0]
        getitem_258 = native_batch_norm_default_85[1]
        getitem_259 = native_batch_norm_default_85[2];  native_batch_norm_default_85 = None
        relu__default_82 = torch.ops.aten.relu_.default(getitem_257);  getitem_257 = None
        convolution_default_86 = torch.ops.aten.convolution.default(relu__default_82, primals_385, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_86 = torch.ops.aten.native_batch_norm.default(convolution_default_86, primals_378, primals_374, primals_376, primals_377, True, 0.1, 1e-05);  primals_374 = None
        getitem_260 = native_batch_norm_default_86[0]
        getitem_261 = native_batch_norm_default_86[1]
        getitem_262 = native_batch_norm_default_86[2];  native_batch_norm_default_86 = None
        relu__default_83 = torch.ops.aten.relu_.default(getitem_260);  getitem_260 = None
        convolution_default_87 = torch.ops.aten.convolution.default(relu__default_83, primals_386, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_87 = torch.ops.aten.native_batch_norm.default(convolution_default_87, primals_383, primals_379, primals_381, primals_382, True, 0.1, 1e-05);  primals_379 = None
        getitem_263 = native_batch_norm_default_87[0]
        getitem_264 = native_batch_norm_default_87[1]
        getitem_265 = native_batch_norm_default_87[2];  native_batch_norm_default_87 = None
        add__tensor_115 = torch.ops.aten.add_.Tensor(getitem_263, relu__default_81);  getitem_263 = None
        relu__default_84 = torch.ops.aten.relu_.default(add__tensor_115);  add__tensor_115 = None
        convolution_default_88 = torch.ops.aten.convolution.default(relu__default_84, primals_402, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_88 = torch.ops.aten.native_batch_norm.default(convolution_default_88, primals_391, primals_387, primals_389, primals_390, True, 0.1, 1e-05);  primals_387 = None
        getitem_266 = native_batch_norm_default_88[0]
        getitem_267 = native_batch_norm_default_88[1]
        getitem_268 = native_batch_norm_default_88[2];  native_batch_norm_default_88 = None
        relu__default_85 = torch.ops.aten.relu_.default(getitem_266);  getitem_266 = None
        convolution_default_89 = torch.ops.aten.convolution.default(relu__default_85, primals_403, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_89 = torch.ops.aten.native_batch_norm.default(convolution_default_89, primals_396, primals_392, primals_394, primals_395, True, 0.1, 1e-05);  primals_392 = None
        getitem_269 = native_batch_norm_default_89[0]
        getitem_270 = native_batch_norm_default_89[1]
        getitem_271 = native_batch_norm_default_89[2];  native_batch_norm_default_89 = None
        relu__default_86 = torch.ops.aten.relu_.default(getitem_269);  getitem_269 = None
        convolution_default_90 = torch.ops.aten.convolution.default(relu__default_86, primals_404, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_90 = torch.ops.aten.native_batch_norm.default(convolution_default_90, primals_401, primals_397, primals_399, primals_400, True, 0.1, 1e-05);  primals_397 = None
        getitem_272 = native_batch_norm_default_90[0]
        getitem_273 = native_batch_norm_default_90[1]
        getitem_274 = native_batch_norm_default_90[2];  native_batch_norm_default_90 = None
        add__tensor_119 = torch.ops.aten.add_.Tensor(getitem_272, relu__default_84);  getitem_272 = None
        relu__default_87 = torch.ops.aten.relu_.default(add__tensor_119);  add__tensor_119 = None
        convolution_default_91 = torch.ops.aten.convolution.default(relu__default_87, primals_420, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_91 = torch.ops.aten.native_batch_norm.default(convolution_default_91, primals_409, primals_405, primals_407, primals_408, True, 0.1, 1e-05);  primals_405 = None
        getitem_275 = native_batch_norm_default_91[0]
        getitem_276 = native_batch_norm_default_91[1]
        getitem_277 = native_batch_norm_default_91[2];  native_batch_norm_default_91 = None
        relu__default_88 = torch.ops.aten.relu_.default(getitem_275);  getitem_275 = None
        convolution_default_92 = torch.ops.aten.convolution.default(relu__default_88, primals_421, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_92 = torch.ops.aten.native_batch_norm.default(convolution_default_92, primals_414, primals_410, primals_412, primals_413, True, 0.1, 1e-05);  primals_410 = None
        getitem_278 = native_batch_norm_default_92[0]
        getitem_279 = native_batch_norm_default_92[1]
        getitem_280 = native_batch_norm_default_92[2];  native_batch_norm_default_92 = None
        relu__default_89 = torch.ops.aten.relu_.default(getitem_278);  getitem_278 = None
        convolution_default_93 = torch.ops.aten.convolution.default(relu__default_89, primals_422, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_93 = torch.ops.aten.native_batch_norm.default(convolution_default_93, primals_419, primals_415, primals_417, primals_418, True, 0.1, 1e-05);  primals_415 = None
        getitem_281 = native_batch_norm_default_93[0]
        getitem_282 = native_batch_norm_default_93[1]
        getitem_283 = native_batch_norm_default_93[2];  native_batch_norm_default_93 = None
        add__tensor_123 = torch.ops.aten.add_.Tensor(getitem_281, relu__default_87);  getitem_281 = None
        relu__default_90 = torch.ops.aten.relu_.default(add__tensor_123);  add__tensor_123 = None
        convolution_default_94 = torch.ops.aten.convolution.default(relu__default_90, primals_582, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_94 = torch.ops.aten.native_batch_norm.default(convolution_default_94, primals_571, primals_567, primals_569, primals_570, True, 0.1, 1e-05);  primals_567 = None
        getitem_284 = native_batch_norm_default_94[0]
        getitem_285 = native_batch_norm_default_94[1]
        getitem_286 = native_batch_norm_default_94[2];  native_batch_norm_default_94 = None
        relu__default_91 = torch.ops.aten.relu_.default(getitem_284);  getitem_284 = None
        convolution_default_95 = torch.ops.aten.convolution.default(relu__default_91, primals_583, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_95 = torch.ops.aten.native_batch_norm.default(convolution_default_95, primals_576, primals_572, primals_574, primals_575, True, 0.1, 1e-05);  primals_572 = None
        getitem_287 = native_batch_norm_default_95[0]
        getitem_288 = native_batch_norm_default_95[1]
        getitem_289 = native_batch_norm_default_95[2];  native_batch_norm_default_95 = None
        relu__default_92 = torch.ops.aten.relu_.default(getitem_287);  getitem_287 = None
        convolution_default_96 = torch.ops.aten.convolution.default(relu__default_92, primals_584, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_96 = torch.ops.aten.native_batch_norm.default(convolution_default_96, primals_581, primals_577, primals_579, primals_580, True, 0.1, 1e-05);  primals_577 = None
        getitem_290 = native_batch_norm_default_96[0]
        getitem_291 = native_batch_norm_default_96[1]
        getitem_292 = native_batch_norm_default_96[2];  native_batch_norm_default_96 = None
        convolution_default_97 = torch.ops.aten.convolution.default(relu__default_90, primals_585, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_97 = torch.ops.aten.native_batch_norm.default(convolution_default_97, primals_590, primals_586, primals_588, primals_589, True, 0.1, 1e-05);  primals_586 = None
        getitem_293 = native_batch_norm_default_97[0]
        getitem_294 = native_batch_norm_default_97[1]
        getitem_295 = native_batch_norm_default_97[2];  native_batch_norm_default_97 = None
        add__tensor_128 = torch.ops.aten.add_.Tensor(getitem_290, getitem_293);  getitem_290 = getitem_293 = None
        relu__default_93 = torch.ops.aten.relu_.default(add__tensor_128);  add__tensor_128 = None
        convolution_default_98 = torch.ops.aten.convolution.default(relu__default_93, primals_606, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_98 = torch.ops.aten.native_batch_norm.default(convolution_default_98, primals_595, primals_591, primals_593, primals_594, True, 0.1, 1e-05);  primals_591 = None
        getitem_296 = native_batch_norm_default_98[0]
        getitem_297 = native_batch_norm_default_98[1]
        getitem_298 = native_batch_norm_default_98[2];  native_batch_norm_default_98 = None
        relu__default_94 = torch.ops.aten.relu_.default(getitem_296);  getitem_296 = None
        convolution_default_99 = torch.ops.aten.convolution.default(relu__default_94, primals_607, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_99 = torch.ops.aten.native_batch_norm.default(convolution_default_99, primals_600, primals_596, primals_598, primals_599, True, 0.1, 1e-05);  primals_596 = None
        getitem_299 = native_batch_norm_default_99[0]
        getitem_300 = native_batch_norm_default_99[1]
        getitem_301 = native_batch_norm_default_99[2];  native_batch_norm_default_99 = None
        relu__default_95 = torch.ops.aten.relu_.default(getitem_299);  getitem_299 = None
        convolution_default_100 = torch.ops.aten.convolution.default(relu__default_95, primals_608, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_100 = torch.ops.aten.native_batch_norm.default(convolution_default_100, primals_605, primals_601, primals_603, primals_604, True, 0.1, 1e-05);  primals_601 = None
        getitem_302 = native_batch_norm_default_100[0]
        getitem_303 = native_batch_norm_default_100[1]
        getitem_304 = native_batch_norm_default_100[2];  native_batch_norm_default_100 = None
        add__tensor_132 = torch.ops.aten.add_.Tensor(getitem_302, relu__default_93);  getitem_302 = None
        relu__default_96 = torch.ops.aten.relu_.default(add__tensor_132);  add__tensor_132 = None
        convolution_default_101 = torch.ops.aten.convolution.default(relu__default_96, primals_624, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_101 = torch.ops.aten.native_batch_norm.default(convolution_default_101, primals_613, primals_609, primals_611, primals_612, True, 0.1, 1e-05);  primals_609 = None
        getitem_305 = native_batch_norm_default_101[0]
        getitem_306 = native_batch_norm_default_101[1]
        getitem_307 = native_batch_norm_default_101[2];  native_batch_norm_default_101 = None
        relu__default_97 = torch.ops.aten.relu_.default(getitem_305);  getitem_305 = None
        convolution_default_102 = torch.ops.aten.convolution.default(relu__default_97, primals_625, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_102 = torch.ops.aten.native_batch_norm.default(convolution_default_102, primals_618, primals_614, primals_616, primals_617, True, 0.1, 1e-05);  primals_614 = None
        getitem_308 = native_batch_norm_default_102[0]
        getitem_309 = native_batch_norm_default_102[1]
        getitem_310 = native_batch_norm_default_102[2];  native_batch_norm_default_102 = None
        relu__default_98 = torch.ops.aten.relu_.default(getitem_308);  getitem_308 = None
        convolution_default_103 = torch.ops.aten.convolution.default(relu__default_98, primals_626, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_103 = torch.ops.aten.native_batch_norm.default(convolution_default_103, primals_623, primals_619, primals_621, primals_622, True, 0.1, 1e-05);  primals_619 = None
        getitem_311 = native_batch_norm_default_103[0]
        getitem_312 = native_batch_norm_default_103[1]
        getitem_313 = native_batch_norm_default_103[2];  native_batch_norm_default_103 = None
        add__tensor_136 = torch.ops.aten.add_.Tensor(getitem_311, relu__default_96);  getitem_311 = None
        relu__default_99 = torch.ops.aten.relu_.default(add__tensor_136);  add__tensor_136 = None
        mean_dim = torch.ops.aten.mean.dim(relu__default_99, [-1, -2], True)
        view_default = torch.ops.aten.view.default(mean_dim, [64, 2048]);  mean_dim = None
        t_default = torch.ops.aten.t.default(primals_8);  primals_8 = None
        addmm_default = torch.ops.aten.addmm.default(primals_7, view_default, t_default);  primals_7 = None
        return [addmm_default, primals_479, primals_124, convolution_default_58, primals_11, primals_238, primals_417, primals_480, primals_123, primals_224, relu__default_54, getitem_127, primals_125, primals_418, primals_481, convolution_default_59, primals_133, primals_223, primals_419, getitem_126, primals_222, primals_247, primals_242, primals_420, primals_221, relu__default_92, primals_239, primals_138, primals_421, primals_484, relu__default_38, getitem_178, primals_17, getitem_177, primals_131, primals_220, primals_252, primals_422, primals_485, primals_245, primals_16, primals_250, primals_219, primals_12, primals_486, convolution_default_42, relu__default_55, primals_108, primals_128, primals_425, primals_126, primals_227, primals_4, primals_426, primals_489, getitem_130, primals_427, primals_490, getitem_129, primals_3, primals_137, primals_228, primals_251, primals_491, primals_127, primals_6, primals_237, primals_492, relu__default_39, primals_13, primals_430, primals_493, getitem_180, primals_136, primals_229, primals_431, primals_494, getitem_181, primals_432, primals_216, primals_132, convolution_default_43, primals_232, relu__default_56, primals_241, primals_107, relu__default_93, primals_497, primals_5, primals_233, primals_246, primals_435, primals_498, primals_240, primals_234, primals_436, primals_499, convolution_default_60, getitem_132, primals_72, getitem_133, getitem_76, primals_71, relu__default_85, primals_82, getitem_75, convolution_default_89, relu__default_40, convolution_default_90, primals_84, relu__default_96, convolution_default_44, primals_83, relu__default_22, getitem_271, primals_90, getitem_270, primals_87, convolution_default_25, getitem_136, getitem_135, primals_86, relu__default_86, convolution_default_81, getitem_79, getitem_78, relu__default_41, primals_73, relu__default_23, convolution_default_45, primals_85, primals_76, getitem_273, convolution_default_26, getitem_274, primals_77, primals_78, convolution_default_46, relu__default_87, getitem_138, getitem_139, convolution_default_91, relu__default_42, primals_81, getitem_81, getitem_306, primals_48, primals_584, relu__default_33, primals_146, getitem_82, getitem_60, getitem_154, primals_159, primals_327, getitem_262, primals_47, primals_317, primals_585, primals_330, getitem_111, getitem_261, relu__default_8, getitem_61, getitem_184, relu__default_47, getitem_241, primals_46, primals_318, getitem_31, getitem_112, convolution_default_10, convolution_default_51, getitem_183, getitem_277, relu__default_9, convolution_default_27, relu__default_17, relu__default_48, getitem_240, relu__default_83, primals_149, primals_588, convolution_default_87, convolution_default_20, getitem_307, getitem_292, primals_150, getitem_85, primals_589, relu__default_24, relu__default_76, getitem_84, getitem_291, primals_151, convolution_default_37, relu__default_88, primals_590, getitem_34, getitem_157, primals_156, primals_41, getitem_33, getitem_156, primals_45, primals_324, relu__default_97, primals_40, getitem_64, getitem_63, convolution_default_61, convolution_default_92, primals_154, getitem_115, primals_593, getitem_114, relu__default_57, convolution_default_28, convolution_default_80, primals_155, getitem_264, getitem_265, convolution_default_102, primals_42, primals_594, convolution_default_97, getitem_244, primals_37, primals_329, getitem_187, relu__default_18, getitem_243, primals_328, primals_595, getitem_186, getitem_280, relu__default_34, getitem_279, getitem_294, relu__default_84, primals_323, convolution_default_11, getitem_88, convolution_default_52, getitem_310, getitem_87, relu__default_77, getitem_309, primals_50, relu__default_58, primals_319, primals_598, convolution_default_21, convolution_default_38, relu__default_89, primals_49, primals_332, primals_599, convolution_default_88, getitem_295, getitem_36, primals_600, getitem_159, primals_141, relu__default_25, getitem_37, getitem_66, primals_331, getitem_160, convolution_default_62, convolution_default_98, convolution_default_22, convolution_default_93, primals_142, primals_36, primals_35, primals_143, getitem_117, primals_603, relu__default_10, convolution_default_29, primals_144, getitem_118, relu__default_49, getitem_267, convolution_default_103, convolution_default_12, convolution_default_53, primals_604, getitem_67, primals_145, primals_322, getitem_246, getitem_268, primals_458, primals_521, getitem_313, primals_186, primals_522, primals_180, getitem_312, primals_197, primals_178, getitem_163, primals_461, getitem_106, getitem_162, primals_183, getitem_105, primals_179, primals_462, primals_525, relu__default_99, primals_184, primals_463, primals_526, primals_174, primals_527, primals_170, relu__default_31, relu__default_50, primals_162, primals_528, primals_196, primals_175, primals_188, primals_466, primals_529, convolution_default_54, relu__default_79, view_default, convolution_default_35, primals_467, primals_530, primals_160, primals_468, primals_185, primals_169, getitem_166, primals_168, getitem_109, primals_533, getitem_108, getitem_165, primals_193, t_default, primals_471, primals_534, primals_472, primals_535, relu__default_51, primals_187, primals_473, primals_191, relu__default_32, primals_192, primals_164, primals_474, primals_475, primals_538, convolution_default_36, convolution_default_55, primals_476, primals_539, primals_173, primals_540, primals_165, primals_161, primals_163, primals_304, primals_377, primals_395, primals_563, primals_382, primals_384, getitem_190, getitem_225, primals_301, primals_396, primals_564, convolution_default_83, getitem_93, primals_26, convolution_default_70, getitem_226, primals_565, relu__default_66, getitem_276, relu__default_59, getitem_40, primals_566, getitem_189, getitem_39, convolution_default_71, primals_21, convolution_default_63, primals_376, relu__default_71, convolution_default_75, primals_399, getitem_142, primals_24, relu__default_60, primals_31, getitem_141, primals_32, primals_385, primals_23, primals_400, primals_311, primals_381, primals_401, primals_569, relu__default_11, getitem_214, getitem_213, primals_25, primals_402, primals_570, relu__default_43, getitem_193, getitem_192, getitem_231, primals_390, primals_386, primals_403, primals_571, convolution_default_13, getitem_229, getitem_228, primals_295, primals_404, primals_300, relu__default_67, convolution_default_47, primals_313, primals_18, primals_389, primals_574, relu__default_72, getitem_43, primals_407, primals_575, getitem_42, primals_312, primals_27, getitem_145, primals_408, primals_576, getitem_144, convolution_default_64, primals_409, relu__default_12, primals_296, convolution_default_76, convolution_default_14, primals_305, convolution_default_77, relu__default_98, primals_22, getitem_216, primals_579, relu__default_44, getitem_217, primals_309, primals_314, primals_412, primals_580, primals_394, primals_391, primals_413, primals_581, convolution_default_65, relu__default_68, convolution_default_72, primals_306, primals_378, convolution_default_48, primals_299, primals_414, primals_582, getitem_195, getitem_196, getitem_232, primals_310, primals_583, getitem_45, relu__default_61, primals_30, primals_383, primals_211, getitem_3, primals_360, primals_437, primals_626, relu__default_3, getitem_247, getitem_91, relu__default_73, getitem_297, primals_438, getitem_10, primals_627, getitem_90, primals_341, primals_439, primals_502, getitem_1, getitem_2, getitem_9, convolution_default_82, primals_342, primals_363, primals_440, primals_503, relu__default_78, relu__default_94, primals_204, convolution_default_30, primals_364, primals_504, relu__default_2, relu__default_26, convolution_default_99, getitem_235, relu__default, getitem_234, primals_198, primals_365, primals_443, primals_345, primals_366, convolution_default_3, primals_444, primals_507, getitem_4, primals_281, primals_346, getitem_250, primals_367, getitem_249, getitem_301, primals_286, primals_353, primals_445, primals_274, primals_508, relu__default_74, primals_368, getitem_300, primals_509, primals_348, getitem_94, primals_275, getitem_13, primals_206, primals_349, primals_201, primals_287, primals_282, primals_510, primals_202, getitem_12, primals_448, primals_511, primals_371, relu__default_95, primals_276, primals_449, primals_512, convolution_default_1, primals_347, primals_372, relu__default_27, primals_205, primals_278, getitem_7, primals_450, convolution_default_4, primals_337, getitem_6, primals_291, getitem_211, primals_355, convolution_default_100, primals_359, primals_336, getitem_237, primals_340, primals_210, primals_515, getitem_238, primals_335, convolution_default_31, primals_288, primals_453, primals_516, primals_277, getitem_15, getitem_303, primals_293, primals_358, relu__default_1, primals_454, primals_517, primals_214, relu__default_75, primals_209, primals_292, primals_294, primals_455, convolution_default_84, primals_350, getitem_252, getitem_253, primals_456, convolution_default_101, convolution_default_2, getitem_304, primals_203, primals_457, primals_520, getitem_16, primals_373, getitem_96, primals_283, convolution_default_79, primals_215, primals_354, relu__default_80, getitem_46, convolution_default_56, getitem_282, convolution_default_5, convolution_default_6, relu__default_19, relu__default_35, getitem_168, getitem_283, relu__default_28, primals_54, convolution_default_39, convolution_default_15, relu__default_36, getitem_169, getitem_97, convolution_default_16, convolution_default_32, getitem_220, convolution_default_33, getitem_219, primals_55, relu__default_52, getitem_199, primals_63, getitem_19, primals_255, getitem_198, relu__default_90, getitem_18, getitem_70, primals_258, getitem_69, getitem_121, convolution_default_94, primals_260, getitem_120, getitem_49, primals_259, getitem_48, getitem_100, getitem_99, relu__default_62, relu__default_4, relu__default_20, getitem_286, getitem_172, relu__default_69, primals_67, getitem_174, getitem_285, primals_263, getitem_171, primals_65, convolution_default, relu__default_13, convolution_default_66, relu__default_29, convolution_default_73, primals_68, convolution_default_23, relu__default_91, primals_60, relu__default_53, getitem_223, convolution_default_40, primals_265, getitem_222, getitem_202, getitem_22, getitem_201, getitem_21, getitem_73, primals_264, getitem_72, convolution_default_78, primals_64, convolution_default_95, convolution_default_57, primals_53, getitem_123, relu__default_70, primals_59, primals_273, getitem_51, getitem_124, relu__default_63, primals_270, getitem_102, relu__default_5, getitem_52, relu__default_21, getitem_103, getitem_288, primals_256, primals_58, primals_269, convolution_default_96, relu__default_37, convolution_default_74, relu__default_14, convolution_default_17, convolution_default_34, primals_257, convolution_default_7, getitem_175, convolution_default_67, primals_66, convolution_default_24, relu__default_30, primals_268, getitem_289, convolution_default_41, primals_605, getitem_25, getitem_205, primals_543, primals_606, getitem_147, getitem_148, getitem_24, primals_544, primals_607, getitem_55, getitem_204, getitem_54, primals_545, primals_608, primals_113, getitem_256, primals_100, primals_546, relu__default_6, relu__default_64, getitem_255, primals_91, convolution_default_68, primals_547, relu__default_45, primals_96, primals_548, primals_114, primals_611, primals_612, primals_109, convolution_default_8, convolution_default_49, primals_92, relu__default_15, primals_95, primals_613, primals_551, convolution_default_18, relu__default_81, getitem_208, primals_118, getitem_28, getitem_151, getitem_207, primals_552, getitem_27, getitem_150, convolution_default_85, primals_553, getitem_58, primals_616, getitem_57, primals_120, primals_119, primals_617, relu__default_65, getitem_259, relu__default_7, relu__default_46, getitem_258, primals_618, primals_556, relu__default_16, primals_97, primals_110, primals_557, convolution_default_69, convolution_default_9, convolution_default_50, relu__default_82, primals_558, primals_101, primals_115, primals_621, convolution_default_19, primals_622, getitem_298, primals_106, primals_623, convolution_default_86, primals_561, primals_624, getitem_210, getitem_30, getitem_153, primals_562, primals_105, primals_625, primals_102]
        
