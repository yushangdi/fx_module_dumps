
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/resnest101e/resnest101e_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339, primals_340, primals_341, primals_342, primals_343, primals_344, primals_345, primals_346, primals_347, primals_348, primals_349, primals_350, primals_351, primals_352, primals_353, primals_354, primals_355, primals_356, primals_357, primals_358, primals_359, primals_360, primals_361, primals_362, primals_363, primals_364, primals_365, primals_366, primals_367, primals_368, primals_369, primals_370, primals_371, primals_372, primals_373, primals_374, primals_375, primals_376, primals_377, primals_378, primals_379, primals_380, primals_381, primals_382, primals_383, primals_384, primals_385, primals_386, primals_387, primals_388, primals_389, primals_390, primals_391, primals_392, primals_393, primals_394, primals_395, primals_396, primals_397, primals_398, primals_399, primals_400, primals_401, primals_402, primals_403, primals_404, primals_405, primals_406, primals_407, primals_408, primals_409, primals_410, primals_411, primals_412, primals_413, primals_414, primals_415, primals_416, primals_417, primals_418, primals_419, primals_420, primals_421, primals_422, primals_423, primals_424, primals_425, primals_426, primals_427, primals_428, primals_429, primals_430, primals_431, primals_432, primals_433, primals_434, primals_435, primals_436, primals_437, primals_438, primals_439, primals_440, primals_441, primals_442, primals_443, primals_444, primals_445, primals_446, primals_447, primals_448, primals_449, primals_450, primals_451, primals_452, primals_453, primals_454, primals_455, primals_456, primals_457, primals_458, primals_459, primals_460, primals_461, primals_462, primals_463, primals_464, primals_465, primals_466, primals_467, primals_468, primals_469, primals_470, primals_471, primals_472, primals_473, primals_474, primals_475, primals_476, primals_477, primals_478, primals_479, primals_480, primals_481, primals_482, primals_483, primals_484, primals_485, primals_486, primals_487, primals_488, primals_489, primals_490, primals_491, primals_492, primals_493, primals_494, primals_495, primals_496, primals_497, primals_498, primals_499, primals_500, primals_501, primals_502, primals_503, primals_504, primals_505, primals_506, primals_507, primals_508, primals_509, primals_510, primals_511, primals_512, primals_513, primals_514, primals_515, primals_516, primals_517, primals_518, primals_519, primals_520, primals_521, primals_522, primals_523, primals_524, primals_525, primals_526, primals_527, primals_528, primals_529, primals_530, primals_531, primals_532, primals_533, primals_534, primals_535, primals_536, primals_537, primals_538, primals_539, primals_540, primals_541, primals_542, primals_543, primals_544, primals_545, primals_546, primals_547, primals_548, primals_549, primals_550, primals_551, primals_552, primals_553, primals_554, primals_555, primals_556, primals_557, primals_558, primals_559, primals_560, primals_561, primals_562, primals_563, primals_564, primals_565, primals_566, primals_567, primals_568, primals_569, primals_570, primals_571, primals_572, primals_573, primals_574, primals_575, primals_576, primals_577, primals_578, primals_579, primals_580, primals_581, primals_582, primals_583, primals_584, primals_585, primals_586, primals_587, primals_588, primals_589, primals_590, primals_591, primals_592, primals_593, primals_594, primals_595, primals_596, primals_597, primals_598, primals_599, primals_600, primals_601, primals_602, primals_603, primals_604, primals_605, primals_606, primals_607, primals_608, primals_609, primals_610, primals_611, primals_612, primals_613, primals_614, primals_615, primals_616, primals_617, primals_618, primals_619, primals_620, primals_621, primals_622, primals_623, primals_624, primals_625, primals_626, primals_627, primals_628, primals_629, primals_630, primals_631, primals_632, primals_633, primals_634, primals_635, primals_636, primals_637, primals_638, primals_639, primals_640, primals_641, primals_642, primals_643, primals_644, primals_645, primals_646, primals_647, primals_648, primals_649, primals_650, primals_651, primals_652, primals_653, primals_654, primals_655, primals_656, primals_657, primals_658, primals_659, primals_660, primals_661, primals_662, primals_663, primals_664, primals_665, primals_666, primals_667, primals_668, primals_669, primals_670, primals_671, primals_672, primals_673, primals_674, primals_675, primals_676, primals_677, primals_678, primals_679, primals_680, primals_681, primals_682, primals_683, primals_684, primals_685, primals_686, primals_687, primals_688, primals_689, primals_690, primals_691, primals_692, primals_693, primals_694, primals_695, primals_696, primals_697, primals_698, primals_699, primals_700, primals_701, primals_702, primals_703, primals_704, primals_705, primals_706, primals_707, primals_708, primals_709, primals_710, primals_711, primals_712, primals_713, primals_714, primals_715, primals_716, primals_717, primals_718, primals_719, primals_720, primals_721, primals_722, primals_723, primals_724, primals_725, primals_726, primals_727, primals_728, primals_729, primals_730, primals_731, primals_732, primals_733, primals_734, primals_735, primals_736, primals_737, primals_738, primals_739, primals_740, primals_741, primals_742, primals_743, primals_744, primals_745, primals_746, primals_747, primals_748, primals_749, primals_750, primals_751, primals_752, primals_753, primals_754, primals_755, primals_756, primals_757, primals_758, primals_759, primals_760, primals_761, primals_762, primals_763, primals_764, primals_765, primals_766, primals_767, primals_768, primals_769, primals_770, primals_771, primals_772, primals_773, primals_774, primals_775, primals_776, primals_777, primals_778, primals_779, primals_780, primals_781, primals_782, primals_783, primals_784, primals_785, primals_786, primals_787, primals_788, primals_789, primals_790, primals_791, primals_792, primals_793, primals_794, primals_795, primals_796, primals_797, primals_798, primals_799, primals_800, primals_801, primals_802, primals_803, primals_804, primals_805, primals_806, primals_807, primals_808, primals_809, primals_810, primals_811, primals_812, primals_813, primals_814, primals_815, primals_816, primals_817, primals_818, primals_819, primals_820, primals_821, primals_822, primals_823, primals_824, primals_825, primals_826, primals_827, primals_828, primals_829, primals_830, primals_831, primals_832, primals_833, primals_834, primals_835, primals_836, primals_837, primals_838, primals_839, primals_840, primals_841, primals_842, primals_843, primals_844, primals_845, primals_846, primals_847, primals_848, primals_849, primals_850, primals_851, primals_852, primals_853, primals_854, primals_855, primals_856, primals_857, primals_858, primals_859, primals_860, primals_861, primals_862, primals_863, primals_864, primals_865, primals_866, primals_867, primals_868, primals_869, primals_870, primals_871, primals_872, primals_873, primals_874, primals_875, primals_876, primals_877, primals_878, primals_879, primals_880, primals_881, primals_882, primals_883, primals_884, primals_885, primals_886, primals_887, primals_888, primals_889, primals_890, primals_891, primals_892, primals_893, primals_894, primals_895, primals_896, primals_897, primals_898, primals_899, primals_900, primals_901, primals_902, primals_903, primals_904, primals_905, primals_906, primals_907, primals_908, primals_909, primals_910, primals_911, primals_912, primals_913, primals_914, primals_915, primals_916, primals_917, primals_918, primals_919, primals_920, primals_921, primals_922, primals_923, primals_924, primals_925, primals_926, primals_927, primals_928, primals_929, primals_930, primals_931, primals_932, primals_933, primals_934, primals_935, primals_936):
        convolution_default = torch.ops.aten.convolution.default(primals_936, primals_6, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_11, primals_7, primals_9, primals_10, True, 0.1, 1e-05);  primals_7 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default, primals_12, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_17, primals_13, primals_15, primals_16, True, 0.1, 1e-05);  primals_13 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        relu__default_1 = torch.ops.aten.relu_.default(getitem_3);  getitem_3 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_18, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_5, primals_1, primals_3, primals_4, True, 0.1, 1e-05);  primals_1 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        relu__default_2 = torch.ops.aten.relu_.default(getitem_6);  getitem_6 = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu__default_2, [3, 3], [2, 2], [1, 1])
        getitem_9 = max_pool2d_with_indices_default[0]
        getitem_10 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_3 = torch.ops.aten.convolution.default(getitem_9, primals_31, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_25, primals_21, primals_23, primals_24, True, 0.1, 1e-05);  primals_21 = None
        getitem_11 = native_batch_norm_default_3[0]
        getitem_12 = native_batch_norm_default_3[1]
        getitem_13 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        relu__default_3 = torch.ops.aten.relu_.default(getitem_11);  getitem_11 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu__default_3, primals_42, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_36, primals_32, primals_34, primals_35, True, 0.1, 1e-05);  primals_32 = None
        getitem_14 = native_batch_norm_default_4[0]
        getitem_15 = native_batch_norm_default_4[1]
        getitem_16 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        relu__default_4 = torch.ops.aten.relu_.default(getitem_14);  getitem_14 = None
        view_default = torch.ops.aten.view.default(relu__default_4, [128, 2, 64, 64, 64])
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(view_default, [1])
        mean_dim = torch.ops.aten.mean.dim(sum_dim_int_list, [2, 3], True);  sum_dim_int_list = None
        convolution_default_5 = torch.ops.aten.convolution.default(mean_dim, primals_44, primals_43, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_43 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_41, primals_37, primals_39, primals_40, True, 0.1, 1e-05);  primals_37 = None
        getitem_17 = native_batch_norm_default_5[0]
        getitem_18 = native_batch_norm_default_5[1]
        getitem_19 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        relu__default_5 = torch.ops.aten.relu_.default(getitem_17);  getitem_17 = None
        convolution_default_6 = torch.ops.aten.convolution.default(relu__default_5, primals_46, primals_45, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_45 = None
        view_default_1 = torch.ops.aten.view.default(convolution_default_6, [128, 1, 2, -1]);  convolution_default_6 = None
        transpose_int = torch.ops.aten.transpose.int(view_default_1, 1, 2);  view_default_1 = None
        _softmax_default = torch.ops.aten._softmax.default(transpose_int, 1, False);  transpose_int = None
        view_default_2 = torch.ops.aten.view.default(_softmax_default, [128, 128])
        view_default_3 = torch.ops.aten.view.default(view_default_2, [128, -1, 1, 1]);  view_default_2 = None
        view_default_4 = torch.ops.aten.view.default(view_default_3, [128, 2, 64, 1, 1]);  view_default_3 = None
        mul_tensor = torch.ops.aten.mul.Tensor(view_default, view_default_4)
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(mul_tensor, [1]);  mul_tensor = None
        convolution_default_7 = torch.ops.aten.convolution.default(sum_dim_int_list_1, primals_47, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_30, primals_26, primals_28, primals_29, True, 0.1, 1e-05);  primals_26 = None
        getitem_20 = native_batch_norm_default_6[0]
        getitem_21 = native_batch_norm_default_6[1]
        getitem_22 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        convolution_default_8 = torch.ops.aten.convolution.default(getitem_9, primals_48, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_53, primals_49, primals_51, primals_52, True, 0.1, 1e-05);  primals_49 = None
        getitem_23 = native_batch_norm_default_7[0]
        getitem_24 = native_batch_norm_default_7[1]
        getitem_25 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        add__tensor_8 = torch.ops.aten.add_.Tensor(getitem_20, getitem_23);  getitem_20 = getitem_23 = None
        relu__default_6 = torch.ops.aten.relu_.default(add__tensor_8);  add__tensor_8 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_6, primals_64, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_58, primals_54, primals_56, primals_57, True, 0.1, 1e-05);  primals_54 = None
        getitem_26 = native_batch_norm_default_8[0]
        getitem_27 = native_batch_norm_default_8[1]
        getitem_28 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        relu__default_7 = torch.ops.aten.relu_.default(getitem_26);  getitem_26 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default_7, primals_75, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_69, primals_65, primals_67, primals_68, True, 0.1, 1e-05);  primals_65 = None
        getitem_29 = native_batch_norm_default_9[0]
        getitem_30 = native_batch_norm_default_9[1]
        getitem_31 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        relu__default_8 = torch.ops.aten.relu_.default(getitem_29);  getitem_29 = None
        view_default_5 = torch.ops.aten.view.default(relu__default_8, [128, 2, 64, 64, 64])
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(view_default_5, [1])
        mean_dim_1 = torch.ops.aten.mean.dim(sum_dim_int_list_2, [2, 3], True);  sum_dim_int_list_2 = None
        convolution_default_11 = torch.ops.aten.convolution.default(mean_dim_1, primals_77, primals_76, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_76 = None
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_74, primals_70, primals_72, primals_73, True, 0.1, 1e-05);  primals_70 = None
        getitem_32 = native_batch_norm_default_10[0]
        getitem_33 = native_batch_norm_default_10[1]
        getitem_34 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        relu__default_9 = torch.ops.aten.relu_.default(getitem_32);  getitem_32 = None
        convolution_default_12 = torch.ops.aten.convolution.default(relu__default_9, primals_79, primals_78, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_78 = None
        view_default_6 = torch.ops.aten.view.default(convolution_default_12, [128, 1, 2, -1]);  convolution_default_12 = None
        transpose_int_1 = torch.ops.aten.transpose.int(view_default_6, 1, 2);  view_default_6 = None
        _softmax_default_1 = torch.ops.aten._softmax.default(transpose_int_1, 1, False);  transpose_int_1 = None
        view_default_7 = torch.ops.aten.view.default(_softmax_default_1, [128, 128])
        view_default_8 = torch.ops.aten.view.default(view_default_7, [128, -1, 1, 1]);  view_default_7 = None
        view_default_9 = torch.ops.aten.view.default(view_default_8, [128, 2, 64, 1, 1]);  view_default_8 = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(view_default_5, view_default_9)
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(mul_tensor_1, [1]);  mul_tensor_1 = None
        convolution_default_13 = torch.ops.aten.convolution.default(sum_dim_int_list_3, primals_80, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_63, primals_59, primals_61, primals_62, True, 0.1, 1e-05);  primals_59 = None
        getitem_35 = native_batch_norm_default_11[0]
        getitem_36 = native_batch_norm_default_11[1]
        getitem_37 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        add__tensor_13 = torch.ops.aten.add_.Tensor(getitem_35, relu__default_6);  getitem_35 = None
        relu__default_10 = torch.ops.aten.relu_.default(add__tensor_13);  add__tensor_13 = None
        convolution_default_14 = torch.ops.aten.convolution.default(relu__default_10, primals_91, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_85, primals_81, primals_83, primals_84, True, 0.1, 1e-05);  primals_81 = None
        getitem_38 = native_batch_norm_default_12[0]
        getitem_39 = native_batch_norm_default_12[1]
        getitem_40 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        relu__default_11 = torch.ops.aten.relu_.default(getitem_38);  getitem_38 = None
        convolution_default_15 = torch.ops.aten.convolution.default(relu__default_11, primals_102, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_96, primals_92, primals_94, primals_95, True, 0.1, 1e-05);  primals_92 = None
        getitem_41 = native_batch_norm_default_13[0]
        getitem_42 = native_batch_norm_default_13[1]
        getitem_43 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        relu__default_12 = torch.ops.aten.relu_.default(getitem_41);  getitem_41 = None
        view_default_10 = torch.ops.aten.view.default(relu__default_12, [128, 2, 64, 64, 64])
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(view_default_10, [1])
        mean_dim_2 = torch.ops.aten.mean.dim(sum_dim_int_list_4, [2, 3], True);  sum_dim_int_list_4 = None
        convolution_default_16 = torch.ops.aten.convolution.default(mean_dim_2, primals_104, primals_103, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_103 = None
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_101, primals_97, primals_99, primals_100, True, 0.1, 1e-05);  primals_97 = None
        getitem_44 = native_batch_norm_default_14[0]
        getitem_45 = native_batch_norm_default_14[1]
        getitem_46 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        relu__default_13 = torch.ops.aten.relu_.default(getitem_44);  getitem_44 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu__default_13, primals_106, primals_105, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_105 = None
        view_default_11 = torch.ops.aten.view.default(convolution_default_17, [128, 1, 2, -1]);  convolution_default_17 = None
        transpose_int_2 = torch.ops.aten.transpose.int(view_default_11, 1, 2);  view_default_11 = None
        _softmax_default_2 = torch.ops.aten._softmax.default(transpose_int_2, 1, False);  transpose_int_2 = None
        view_default_12 = torch.ops.aten.view.default(_softmax_default_2, [128, 128])
        view_default_13 = torch.ops.aten.view.default(view_default_12, [128, -1, 1, 1]);  view_default_12 = None
        view_default_14 = torch.ops.aten.view.default(view_default_13, [128, 2, 64, 1, 1]);  view_default_13 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(view_default_10, view_default_14)
        sum_dim_int_list_5 = torch.ops.aten.sum.dim_IntList(mul_tensor_2, [1]);  mul_tensor_2 = None
        convolution_default_18 = torch.ops.aten.convolution.default(sum_dim_int_list_5, primals_107, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_90, primals_86, primals_88, primals_89, True, 0.1, 1e-05);  primals_86 = None
        getitem_47 = native_batch_norm_default_15[0]
        getitem_48 = native_batch_norm_default_15[1]
        getitem_49 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        add__tensor_18 = torch.ops.aten.add_.Tensor(getitem_47, relu__default_10);  getitem_47 = None
        relu__default_14 = torch.ops.aten.relu_.default(add__tensor_18);  add__tensor_18 = None
        convolution_default_19 = torch.ops.aten.convolution.default(relu__default_14, primals_118, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_112, primals_108, primals_110, primals_111, True, 0.1, 1e-05);  primals_108 = None
        getitem_50 = native_batch_norm_default_16[0]
        getitem_51 = native_batch_norm_default_16[1]
        getitem_52 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        relu__default_15 = torch.ops.aten.relu_.default(getitem_50);  getitem_50 = None
        convolution_default_20 = torch.ops.aten.convolution.default(relu__default_15, primals_129, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_123, primals_119, primals_121, primals_122, True, 0.1, 1e-05);  primals_119 = None
        getitem_53 = native_batch_norm_default_17[0]
        getitem_54 = native_batch_norm_default_17[1]
        getitem_55 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        relu__default_16 = torch.ops.aten.relu_.default(getitem_53);  getitem_53 = None
        view_default_15 = torch.ops.aten.view.default(relu__default_16, [128, 2, 128, 64, 64])
        sum_dim_int_list_6 = torch.ops.aten.sum.dim_IntList(view_default_15, [1])
        mean_dim_3 = torch.ops.aten.mean.dim(sum_dim_int_list_6, [2, 3], True);  sum_dim_int_list_6 = None
        convolution_default_21 = torch.ops.aten.convolution.default(mean_dim_3, primals_131, primals_130, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_130 = None
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_128, primals_124, primals_126, primals_127, True, 0.1, 1e-05);  primals_124 = None
        getitem_56 = native_batch_norm_default_18[0]
        getitem_57 = native_batch_norm_default_18[1]
        getitem_58 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        relu__default_17 = torch.ops.aten.relu_.default(getitem_56);  getitem_56 = None
        convolution_default_22 = torch.ops.aten.convolution.default(relu__default_17, primals_133, primals_132, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_132 = None
        view_default_16 = torch.ops.aten.view.default(convolution_default_22, [128, 1, 2, -1]);  convolution_default_22 = None
        transpose_int_3 = torch.ops.aten.transpose.int(view_default_16, 1, 2);  view_default_16 = None
        _softmax_default_3 = torch.ops.aten._softmax.default(transpose_int_3, 1, False);  transpose_int_3 = None
        view_default_17 = torch.ops.aten.view.default(_softmax_default_3, [128, 256])
        view_default_18 = torch.ops.aten.view.default(view_default_17, [128, -1, 1, 1]);  view_default_17 = None
        view_default_19 = torch.ops.aten.view.default(view_default_18, [128, 2, 128, 1, 1]);  view_default_18 = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(view_default_15, view_default_19)
        sum_dim_int_list_7 = torch.ops.aten.sum.dim_IntList(mul_tensor_3, [1]);  mul_tensor_3 = None
        avg_pool2d_default = torch.ops.aten.avg_pool2d.default(sum_dim_int_list_7, [3, 3], [2, 2], [1, 1])
        convolution_default_23 = torch.ops.aten.convolution.default(avg_pool2d_default, primals_134, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_117, primals_113, primals_115, primals_116, True, 0.1, 1e-05);  primals_113 = None
        getitem_59 = native_batch_norm_default_19[0]
        getitem_60 = native_batch_norm_default_19[1]
        getitem_61 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        avg_pool2d_default_1 = torch.ops.aten.avg_pool2d.default(relu__default_14, [2, 2], [2, 2], [0, 0], True, False)
        convolution_default_24 = torch.ops.aten.convolution.default(avg_pool2d_default_1, primals_135, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_140, primals_136, primals_138, primals_139, True, 0.1, 1e-05);  primals_136 = None
        getitem_62 = native_batch_norm_default_20[0]
        getitem_63 = native_batch_norm_default_20[1]
        getitem_64 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        add__tensor_24 = torch.ops.aten.add_.Tensor(getitem_59, getitem_62);  getitem_59 = getitem_62 = None
        relu__default_18 = torch.ops.aten.relu_.default(add__tensor_24);  add__tensor_24 = None
        convolution_default_25 = torch.ops.aten.convolution.default(relu__default_18, primals_151, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_145, primals_141, primals_143, primals_144, True, 0.1, 1e-05);  primals_141 = None
        getitem_65 = native_batch_norm_default_21[0]
        getitem_66 = native_batch_norm_default_21[1]
        getitem_67 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        relu__default_19 = torch.ops.aten.relu_.default(getitem_65);  getitem_65 = None
        convolution_default_26 = torch.ops.aten.convolution.default(relu__default_19, primals_162, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_156, primals_152, primals_154, primals_155, True, 0.1, 1e-05);  primals_152 = None
        getitem_68 = native_batch_norm_default_22[0]
        getitem_69 = native_batch_norm_default_22[1]
        getitem_70 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        relu__default_20 = torch.ops.aten.relu_.default(getitem_68);  getitem_68 = None
        view_default_20 = torch.ops.aten.view.default(relu__default_20, [128, 2, 128, 32, 32])
        sum_dim_int_list_8 = torch.ops.aten.sum.dim_IntList(view_default_20, [1])
        mean_dim_4 = torch.ops.aten.mean.dim(sum_dim_int_list_8, [2, 3], True);  sum_dim_int_list_8 = None
        convolution_default_27 = torch.ops.aten.convolution.default(mean_dim_4, primals_164, primals_163, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_163 = None
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_161, primals_157, primals_159, primals_160, True, 0.1, 1e-05);  primals_157 = None
        getitem_71 = native_batch_norm_default_23[0]
        getitem_72 = native_batch_norm_default_23[1]
        getitem_73 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        relu__default_21 = torch.ops.aten.relu_.default(getitem_71);  getitem_71 = None
        convolution_default_28 = torch.ops.aten.convolution.default(relu__default_21, primals_166, primals_165, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_165 = None
        view_default_21 = torch.ops.aten.view.default(convolution_default_28, [128, 1, 2, -1]);  convolution_default_28 = None
        transpose_int_4 = torch.ops.aten.transpose.int(view_default_21, 1, 2);  view_default_21 = None
        _softmax_default_4 = torch.ops.aten._softmax.default(transpose_int_4, 1, False);  transpose_int_4 = None
        view_default_22 = torch.ops.aten.view.default(_softmax_default_4, [128, 256])
        view_default_23 = torch.ops.aten.view.default(view_default_22, [128, -1, 1, 1]);  view_default_22 = None
        view_default_24 = torch.ops.aten.view.default(view_default_23, [128, 2, 128, 1, 1]);  view_default_23 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(view_default_20, view_default_24)
        sum_dim_int_list_9 = torch.ops.aten.sum.dim_IntList(mul_tensor_4, [1]);  mul_tensor_4 = None
        convolution_default_29 = torch.ops.aten.convolution.default(sum_dim_int_list_9, primals_167, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_150, primals_146, primals_148, primals_149, True, 0.1, 1e-05);  primals_146 = None
        getitem_74 = native_batch_norm_default_24[0]
        getitem_75 = native_batch_norm_default_24[1]
        getitem_76 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        add__tensor_29 = torch.ops.aten.add_.Tensor(getitem_74, relu__default_18);  getitem_74 = None
        relu__default_22 = torch.ops.aten.relu_.default(add__tensor_29);  add__tensor_29 = None
        convolution_default_30 = torch.ops.aten.convolution.default(relu__default_22, primals_178, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_172, primals_168, primals_170, primals_171, True, 0.1, 1e-05);  primals_168 = None
        getitem_77 = native_batch_norm_default_25[0]
        getitem_78 = native_batch_norm_default_25[1]
        getitem_79 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        relu__default_23 = torch.ops.aten.relu_.default(getitem_77);  getitem_77 = None
        convolution_default_31 = torch.ops.aten.convolution.default(relu__default_23, primals_189, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_31, primals_183, primals_179, primals_181, primals_182, True, 0.1, 1e-05);  primals_179 = None
        getitem_80 = native_batch_norm_default_26[0]
        getitem_81 = native_batch_norm_default_26[1]
        getitem_82 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        relu__default_24 = torch.ops.aten.relu_.default(getitem_80);  getitem_80 = None
        view_default_25 = torch.ops.aten.view.default(relu__default_24, [128, 2, 128, 32, 32])
        sum_dim_int_list_10 = torch.ops.aten.sum.dim_IntList(view_default_25, [1])
        mean_dim_5 = torch.ops.aten.mean.dim(sum_dim_int_list_10, [2, 3], True);  sum_dim_int_list_10 = None
        convolution_default_32 = torch.ops.aten.convolution.default(mean_dim_5, primals_191, primals_190, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_190 = None
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_188, primals_184, primals_186, primals_187, True, 0.1, 1e-05);  primals_184 = None
        getitem_83 = native_batch_norm_default_27[0]
        getitem_84 = native_batch_norm_default_27[1]
        getitem_85 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        relu__default_25 = torch.ops.aten.relu_.default(getitem_83);  getitem_83 = None
        convolution_default_33 = torch.ops.aten.convolution.default(relu__default_25, primals_193, primals_192, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_192 = None
        view_default_26 = torch.ops.aten.view.default(convolution_default_33, [128, 1, 2, -1]);  convolution_default_33 = None
        transpose_int_5 = torch.ops.aten.transpose.int(view_default_26, 1, 2);  view_default_26 = None
        _softmax_default_5 = torch.ops.aten._softmax.default(transpose_int_5, 1, False);  transpose_int_5 = None
        view_default_27 = torch.ops.aten.view.default(_softmax_default_5, [128, 256])
        view_default_28 = torch.ops.aten.view.default(view_default_27, [128, -1, 1, 1]);  view_default_27 = None
        view_default_29 = torch.ops.aten.view.default(view_default_28, [128, 2, 128, 1, 1]);  view_default_28 = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(view_default_25, view_default_29)
        sum_dim_int_list_11 = torch.ops.aten.sum.dim_IntList(mul_tensor_5, [1]);  mul_tensor_5 = None
        convolution_default_34 = torch.ops.aten.convolution.default(sum_dim_int_list_11, primals_194, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_177, primals_173, primals_175, primals_176, True, 0.1, 1e-05);  primals_173 = None
        getitem_86 = native_batch_norm_default_28[0]
        getitem_87 = native_batch_norm_default_28[1]
        getitem_88 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        add__tensor_34 = torch.ops.aten.add_.Tensor(getitem_86, relu__default_22);  getitem_86 = None
        relu__default_26 = torch.ops.aten.relu_.default(add__tensor_34);  add__tensor_34 = None
        convolution_default_35 = torch.ops.aten.convolution.default(relu__default_26, primals_205, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_199, primals_195, primals_197, primals_198, True, 0.1, 1e-05);  primals_195 = None
        getitem_89 = native_batch_norm_default_29[0]
        getitem_90 = native_batch_norm_default_29[1]
        getitem_91 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        relu__default_27 = torch.ops.aten.relu_.default(getitem_89);  getitem_89 = None
        convolution_default_36 = torch.ops.aten.convolution.default(relu__default_27, primals_216, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_210, primals_206, primals_208, primals_209, True, 0.1, 1e-05);  primals_206 = None
        getitem_92 = native_batch_norm_default_30[0]
        getitem_93 = native_batch_norm_default_30[1]
        getitem_94 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        relu__default_28 = torch.ops.aten.relu_.default(getitem_92);  getitem_92 = None
        view_default_30 = torch.ops.aten.view.default(relu__default_28, [128, 2, 128, 32, 32])
        sum_dim_int_list_12 = torch.ops.aten.sum.dim_IntList(view_default_30, [1])
        mean_dim_6 = torch.ops.aten.mean.dim(sum_dim_int_list_12, [2, 3], True);  sum_dim_int_list_12 = None
        convolution_default_37 = torch.ops.aten.convolution.default(mean_dim_6, primals_218, primals_217, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_217 = None
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_37, primals_215, primals_211, primals_213, primals_214, True, 0.1, 1e-05);  primals_211 = None
        getitem_95 = native_batch_norm_default_31[0]
        getitem_96 = native_batch_norm_default_31[1]
        getitem_97 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        relu__default_29 = torch.ops.aten.relu_.default(getitem_95);  getitem_95 = None
        convolution_default_38 = torch.ops.aten.convolution.default(relu__default_29, primals_220, primals_219, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_219 = None
        view_default_31 = torch.ops.aten.view.default(convolution_default_38, [128, 1, 2, -1]);  convolution_default_38 = None
        transpose_int_6 = torch.ops.aten.transpose.int(view_default_31, 1, 2);  view_default_31 = None
        _softmax_default_6 = torch.ops.aten._softmax.default(transpose_int_6, 1, False);  transpose_int_6 = None
        view_default_32 = torch.ops.aten.view.default(_softmax_default_6, [128, 256])
        view_default_33 = torch.ops.aten.view.default(view_default_32, [128, -1, 1, 1]);  view_default_32 = None
        view_default_34 = torch.ops.aten.view.default(view_default_33, [128, 2, 128, 1, 1]);  view_default_33 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(view_default_30, view_default_34)
        sum_dim_int_list_13 = torch.ops.aten.sum.dim_IntList(mul_tensor_6, [1]);  mul_tensor_6 = None
        convolution_default_39 = torch.ops.aten.convolution.default(sum_dim_int_list_13, primals_221, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_39, primals_204, primals_200, primals_202, primals_203, True, 0.1, 1e-05);  primals_200 = None
        getitem_98 = native_batch_norm_default_32[0]
        getitem_99 = native_batch_norm_default_32[1]
        getitem_100 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        add__tensor_39 = torch.ops.aten.add_.Tensor(getitem_98, relu__default_26);  getitem_98 = None
        relu__default_30 = torch.ops.aten.relu_.default(add__tensor_39);  add__tensor_39 = None
        convolution_default_40 = torch.ops.aten.convolution.default(relu__default_30, primals_232, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_226, primals_222, primals_224, primals_225, True, 0.1, 1e-05);  primals_222 = None
        getitem_101 = native_batch_norm_default_33[0]
        getitem_102 = native_batch_norm_default_33[1]
        getitem_103 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        relu__default_31 = torch.ops.aten.relu_.default(getitem_101);  getitem_101 = None
        convolution_default_41 = torch.ops.aten.convolution.default(relu__default_31, primals_243, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_41, primals_237, primals_233, primals_235, primals_236, True, 0.1, 1e-05);  primals_233 = None
        getitem_104 = native_batch_norm_default_34[0]
        getitem_105 = native_batch_norm_default_34[1]
        getitem_106 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        relu__default_32 = torch.ops.aten.relu_.default(getitem_104);  getitem_104 = None
        view_default_35 = torch.ops.aten.view.default(relu__default_32, [128, 2, 256, 32, 32])
        sum_dim_int_list_14 = torch.ops.aten.sum.dim_IntList(view_default_35, [1])
        mean_dim_7 = torch.ops.aten.mean.dim(sum_dim_int_list_14, [2, 3], True);  sum_dim_int_list_14 = None
        convolution_default_42 = torch.ops.aten.convolution.default(mean_dim_7, primals_245, primals_244, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_244 = None
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_42, primals_242, primals_238, primals_240, primals_241, True, 0.1, 1e-05);  primals_238 = None
        getitem_107 = native_batch_norm_default_35[0]
        getitem_108 = native_batch_norm_default_35[1]
        getitem_109 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        relu__default_33 = torch.ops.aten.relu_.default(getitem_107);  getitem_107 = None
        convolution_default_43 = torch.ops.aten.convolution.default(relu__default_33, primals_247, primals_246, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_246 = None
        view_default_36 = torch.ops.aten.view.default(convolution_default_43, [128, 1, 2, -1]);  convolution_default_43 = None
        transpose_int_7 = torch.ops.aten.transpose.int(view_default_36, 1, 2);  view_default_36 = None
        _softmax_default_7 = torch.ops.aten._softmax.default(transpose_int_7, 1, False);  transpose_int_7 = None
        view_default_37 = torch.ops.aten.view.default(_softmax_default_7, [128, 512])
        view_default_38 = torch.ops.aten.view.default(view_default_37, [128, -1, 1, 1]);  view_default_37 = None
        view_default_39 = torch.ops.aten.view.default(view_default_38, [128, 2, 256, 1, 1]);  view_default_38 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(view_default_35, view_default_39)
        sum_dim_int_list_15 = torch.ops.aten.sum.dim_IntList(mul_tensor_7, [1]);  mul_tensor_7 = None
        avg_pool2d_default_2 = torch.ops.aten.avg_pool2d.default(sum_dim_int_list_15, [3, 3], [2, 2], [1, 1])
        convolution_default_44 = torch.ops.aten.convolution.default(avg_pool2d_default_2, primals_248, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_231, primals_227, primals_229, primals_230, True, 0.1, 1e-05);  primals_227 = None
        getitem_110 = native_batch_norm_default_36[0]
        getitem_111 = native_batch_norm_default_36[1]
        getitem_112 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        avg_pool2d_default_3 = torch.ops.aten.avg_pool2d.default(relu__default_30, [2, 2], [2, 2], [0, 0], True, False)
        convolution_default_45 = torch.ops.aten.convolution.default(avg_pool2d_default_3, primals_249, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_45, primals_254, primals_250, primals_252, primals_253, True, 0.1, 1e-05);  primals_250 = None
        getitem_113 = native_batch_norm_default_37[0]
        getitem_114 = native_batch_norm_default_37[1]
        getitem_115 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        add__tensor_45 = torch.ops.aten.add_.Tensor(getitem_110, getitem_113);  getitem_110 = getitem_113 = None
        relu__default_34 = torch.ops.aten.relu_.default(add__tensor_45);  add__tensor_45 = None
        convolution_default_46 = torch.ops.aten.convolution.default(relu__default_34, primals_535, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_46, primals_529, primals_525, primals_527, primals_528, True, 0.1, 1e-05);  primals_525 = None
        getitem_116 = native_batch_norm_default_38[0]
        getitem_117 = native_batch_norm_default_38[1]
        getitem_118 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        relu__default_35 = torch.ops.aten.relu_.default(getitem_116);  getitem_116 = None
        convolution_default_47 = torch.ops.aten.convolution.default(relu__default_35, primals_546, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_47, primals_540, primals_536, primals_538, primals_539, True, 0.1, 1e-05);  primals_536 = None
        getitem_119 = native_batch_norm_default_39[0]
        getitem_120 = native_batch_norm_default_39[1]
        getitem_121 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        relu__default_36 = torch.ops.aten.relu_.default(getitem_119);  getitem_119 = None
        view_default_40 = torch.ops.aten.view.default(relu__default_36, [128, 2, 256, 16, 16])
        sum_dim_int_list_16 = torch.ops.aten.sum.dim_IntList(view_default_40, [1])
        mean_dim_8 = torch.ops.aten.mean.dim(sum_dim_int_list_16, [2, 3], True);  sum_dim_int_list_16 = None
        convolution_default_48 = torch.ops.aten.convolution.default(mean_dim_8, primals_548, primals_547, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_547 = None
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_48, primals_545, primals_541, primals_543, primals_544, True, 0.1, 1e-05);  primals_541 = None
        getitem_122 = native_batch_norm_default_40[0]
        getitem_123 = native_batch_norm_default_40[1]
        getitem_124 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        relu__default_37 = torch.ops.aten.relu_.default(getitem_122);  getitem_122 = None
        convolution_default_49 = torch.ops.aten.convolution.default(relu__default_37, primals_550, primals_549, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_549 = None
        view_default_41 = torch.ops.aten.view.default(convolution_default_49, [128, 1, 2, -1]);  convolution_default_49 = None
        transpose_int_8 = torch.ops.aten.transpose.int(view_default_41, 1, 2);  view_default_41 = None
        _softmax_default_8 = torch.ops.aten._softmax.default(transpose_int_8, 1, False);  transpose_int_8 = None
        view_default_42 = torch.ops.aten.view.default(_softmax_default_8, [128, 512])
        view_default_43 = torch.ops.aten.view.default(view_default_42, [128, -1, 1, 1]);  view_default_42 = None
        view_default_44 = torch.ops.aten.view.default(view_default_43, [128, 2, 256, 1, 1]);  view_default_43 = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(view_default_40, view_default_44)
        sum_dim_int_list_17 = torch.ops.aten.sum.dim_IntList(mul_tensor_8, [1]);  mul_tensor_8 = None
        convolution_default_50 = torch.ops.aten.convolution.default(sum_dim_int_list_17, primals_551, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_50, primals_534, primals_530, primals_532, primals_533, True, 0.1, 1e-05);  primals_530 = None
        getitem_125 = native_batch_norm_default_41[0]
        getitem_126 = native_batch_norm_default_41[1]
        getitem_127 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        add__tensor_50 = torch.ops.aten.add_.Tensor(getitem_125, relu__default_34);  getitem_125 = None
        relu__default_38 = torch.ops.aten.relu_.default(add__tensor_50);  add__tensor_50 = None
        convolution_default_51 = torch.ops.aten.convolution.default(relu__default_38, primals_643, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_51, primals_637, primals_633, primals_635, primals_636, True, 0.1, 1e-05);  primals_633 = None
        getitem_128 = native_batch_norm_default_42[0]
        getitem_129 = native_batch_norm_default_42[1]
        getitem_130 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        relu__default_39 = torch.ops.aten.relu_.default(getitem_128);  getitem_128 = None
        convolution_default_52 = torch.ops.aten.convolution.default(relu__default_39, primals_654, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_52, primals_648, primals_644, primals_646, primals_647, True, 0.1, 1e-05);  primals_644 = None
        getitem_131 = native_batch_norm_default_43[0]
        getitem_132 = native_batch_norm_default_43[1]
        getitem_133 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        relu__default_40 = torch.ops.aten.relu_.default(getitem_131);  getitem_131 = None
        view_default_45 = torch.ops.aten.view.default(relu__default_40, [128, 2, 256, 16, 16])
        sum_dim_int_list_18 = torch.ops.aten.sum.dim_IntList(view_default_45, [1])
        mean_dim_9 = torch.ops.aten.mean.dim(sum_dim_int_list_18, [2, 3], True);  sum_dim_int_list_18 = None
        convolution_default_53 = torch.ops.aten.convolution.default(mean_dim_9, primals_656, primals_655, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_655 = None
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_53, primals_653, primals_649, primals_651, primals_652, True, 0.1, 1e-05);  primals_649 = None
        getitem_134 = native_batch_norm_default_44[0]
        getitem_135 = native_batch_norm_default_44[1]
        getitem_136 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        relu__default_41 = torch.ops.aten.relu_.default(getitem_134);  getitem_134 = None
        convolution_default_54 = torch.ops.aten.convolution.default(relu__default_41, primals_658, primals_657, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_657 = None
        view_default_46 = torch.ops.aten.view.default(convolution_default_54, [128, 1, 2, -1]);  convolution_default_54 = None
        transpose_int_9 = torch.ops.aten.transpose.int(view_default_46, 1, 2);  view_default_46 = None
        _softmax_default_9 = torch.ops.aten._softmax.default(transpose_int_9, 1, False);  transpose_int_9 = None
        view_default_47 = torch.ops.aten.view.default(_softmax_default_9, [128, 512])
        view_default_48 = torch.ops.aten.view.default(view_default_47, [128, -1, 1, 1]);  view_default_47 = None
        view_default_49 = torch.ops.aten.view.default(view_default_48, [128, 2, 256, 1, 1]);  view_default_48 = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(view_default_45, view_default_49)
        sum_dim_int_list_19 = torch.ops.aten.sum.dim_IntList(mul_tensor_9, [1]);  mul_tensor_9 = None
        convolution_default_55 = torch.ops.aten.convolution.default(sum_dim_int_list_19, primals_659, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_55, primals_642, primals_638, primals_640, primals_641, True, 0.1, 1e-05);  primals_638 = None
        getitem_137 = native_batch_norm_default_45[0]
        getitem_138 = native_batch_norm_default_45[1]
        getitem_139 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        add__tensor_55 = torch.ops.aten.add_.Tensor(getitem_137, relu__default_38);  getitem_137 = None
        relu__default_42 = torch.ops.aten.relu_.default(add__tensor_55);  add__tensor_55 = None
        convolution_default_56 = torch.ops.aten.convolution.default(relu__default_42, primals_670, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(convolution_default_56, primals_664, primals_660, primals_662, primals_663, True, 0.1, 1e-05);  primals_660 = None
        getitem_140 = native_batch_norm_default_46[0]
        getitem_141 = native_batch_norm_default_46[1]
        getitem_142 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        relu__default_43 = torch.ops.aten.relu_.default(getitem_140);  getitem_140 = None
        convolution_default_57 = torch.ops.aten.convolution.default(relu__default_43, primals_681, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(convolution_default_57, primals_675, primals_671, primals_673, primals_674, True, 0.1, 1e-05);  primals_671 = None
        getitem_143 = native_batch_norm_default_47[0]
        getitem_144 = native_batch_norm_default_47[1]
        getitem_145 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        relu__default_44 = torch.ops.aten.relu_.default(getitem_143);  getitem_143 = None
        view_default_50 = torch.ops.aten.view.default(relu__default_44, [128, 2, 256, 16, 16])
        sum_dim_int_list_20 = torch.ops.aten.sum.dim_IntList(view_default_50, [1])
        mean_dim_10 = torch.ops.aten.mean.dim(sum_dim_int_list_20, [2, 3], True);  sum_dim_int_list_20 = None
        convolution_default_58 = torch.ops.aten.convolution.default(mean_dim_10, primals_683, primals_682, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_682 = None
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_58, primals_680, primals_676, primals_678, primals_679, True, 0.1, 1e-05);  primals_676 = None
        getitem_146 = native_batch_norm_default_48[0]
        getitem_147 = native_batch_norm_default_48[1]
        getitem_148 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        relu__default_45 = torch.ops.aten.relu_.default(getitem_146);  getitem_146 = None
        convolution_default_59 = torch.ops.aten.convolution.default(relu__default_45, primals_685, primals_684, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_684 = None
        view_default_51 = torch.ops.aten.view.default(convolution_default_59, [128, 1, 2, -1]);  convolution_default_59 = None
        transpose_int_10 = torch.ops.aten.transpose.int(view_default_51, 1, 2);  view_default_51 = None
        _softmax_default_10 = torch.ops.aten._softmax.default(transpose_int_10, 1, False);  transpose_int_10 = None
        view_default_52 = torch.ops.aten.view.default(_softmax_default_10, [128, 512])
        view_default_53 = torch.ops.aten.view.default(view_default_52, [128, -1, 1, 1]);  view_default_52 = None
        view_default_54 = torch.ops.aten.view.default(view_default_53, [128, 2, 256, 1, 1]);  view_default_53 = None
        mul_tensor_10 = torch.ops.aten.mul.Tensor(view_default_50, view_default_54)
        sum_dim_int_list_21 = torch.ops.aten.sum.dim_IntList(mul_tensor_10, [1]);  mul_tensor_10 = None
        convolution_default_60 = torch.ops.aten.convolution.default(sum_dim_int_list_21, primals_686, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(convolution_default_60, primals_669, primals_665, primals_667, primals_668, True, 0.1, 1e-05);  primals_665 = None
        getitem_149 = native_batch_norm_default_49[0]
        getitem_150 = native_batch_norm_default_49[1]
        getitem_151 = native_batch_norm_default_49[2];  native_batch_norm_default_49 = None
        add__tensor_60 = torch.ops.aten.add_.Tensor(getitem_149, relu__default_42);  getitem_149 = None
        relu__default_46 = torch.ops.aten.relu_.default(add__tensor_60);  add__tensor_60 = None
        convolution_default_61 = torch.ops.aten.convolution.default(relu__default_46, primals_697, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(convolution_default_61, primals_691, primals_687, primals_689, primals_690, True, 0.1, 1e-05);  primals_687 = None
        getitem_152 = native_batch_norm_default_50[0]
        getitem_153 = native_batch_norm_default_50[1]
        getitem_154 = native_batch_norm_default_50[2];  native_batch_norm_default_50 = None
        relu__default_47 = torch.ops.aten.relu_.default(getitem_152);  getitem_152 = None
        convolution_default_62 = torch.ops.aten.convolution.default(relu__default_47, primals_708, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(convolution_default_62, primals_702, primals_698, primals_700, primals_701, True, 0.1, 1e-05);  primals_698 = None
        getitem_155 = native_batch_norm_default_51[0]
        getitem_156 = native_batch_norm_default_51[1]
        getitem_157 = native_batch_norm_default_51[2];  native_batch_norm_default_51 = None
        relu__default_48 = torch.ops.aten.relu_.default(getitem_155);  getitem_155 = None
        view_default_55 = torch.ops.aten.view.default(relu__default_48, [128, 2, 256, 16, 16])
        sum_dim_int_list_22 = torch.ops.aten.sum.dim_IntList(view_default_55, [1])
        mean_dim_11 = torch.ops.aten.mean.dim(sum_dim_int_list_22, [2, 3], True);  sum_dim_int_list_22 = None
        convolution_default_63 = torch.ops.aten.convolution.default(mean_dim_11, primals_710, primals_709, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_709 = None
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(convolution_default_63, primals_707, primals_703, primals_705, primals_706, True, 0.1, 1e-05);  primals_703 = None
        getitem_158 = native_batch_norm_default_52[0]
        getitem_159 = native_batch_norm_default_52[1]
        getitem_160 = native_batch_norm_default_52[2];  native_batch_norm_default_52 = None
        relu__default_49 = torch.ops.aten.relu_.default(getitem_158);  getitem_158 = None
        convolution_default_64 = torch.ops.aten.convolution.default(relu__default_49, primals_712, primals_711, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_711 = None
        view_default_56 = torch.ops.aten.view.default(convolution_default_64, [128, 1, 2, -1]);  convolution_default_64 = None
        transpose_int_11 = torch.ops.aten.transpose.int(view_default_56, 1, 2);  view_default_56 = None
        _softmax_default_11 = torch.ops.aten._softmax.default(transpose_int_11, 1, False);  transpose_int_11 = None
        view_default_57 = torch.ops.aten.view.default(_softmax_default_11, [128, 512])
        view_default_58 = torch.ops.aten.view.default(view_default_57, [128, -1, 1, 1]);  view_default_57 = None
        view_default_59 = torch.ops.aten.view.default(view_default_58, [128, 2, 256, 1, 1]);  view_default_58 = None
        mul_tensor_11 = torch.ops.aten.mul.Tensor(view_default_55, view_default_59)
        sum_dim_int_list_23 = torch.ops.aten.sum.dim_IntList(mul_tensor_11, [1]);  mul_tensor_11 = None
        convolution_default_65 = torch.ops.aten.convolution.default(sum_dim_int_list_23, primals_713, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_53 = torch.ops.aten.native_batch_norm.default(convolution_default_65, primals_696, primals_692, primals_694, primals_695, True, 0.1, 1e-05);  primals_692 = None
        getitem_161 = native_batch_norm_default_53[0]
        getitem_162 = native_batch_norm_default_53[1]
        getitem_163 = native_batch_norm_default_53[2];  native_batch_norm_default_53 = None
        add__tensor_65 = torch.ops.aten.add_.Tensor(getitem_161, relu__default_46);  getitem_161 = None
        relu__default_50 = torch.ops.aten.relu_.default(add__tensor_65);  add__tensor_65 = None
        convolution_default_66 = torch.ops.aten.convolution.default(relu__default_50, primals_724, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_54 = torch.ops.aten.native_batch_norm.default(convolution_default_66, primals_718, primals_714, primals_716, primals_717, True, 0.1, 1e-05);  primals_714 = None
        getitem_164 = native_batch_norm_default_54[0]
        getitem_165 = native_batch_norm_default_54[1]
        getitem_166 = native_batch_norm_default_54[2];  native_batch_norm_default_54 = None
        relu__default_51 = torch.ops.aten.relu_.default(getitem_164);  getitem_164 = None
        convolution_default_67 = torch.ops.aten.convolution.default(relu__default_51, primals_735, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_55 = torch.ops.aten.native_batch_norm.default(convolution_default_67, primals_729, primals_725, primals_727, primals_728, True, 0.1, 1e-05);  primals_725 = None
        getitem_167 = native_batch_norm_default_55[0]
        getitem_168 = native_batch_norm_default_55[1]
        getitem_169 = native_batch_norm_default_55[2];  native_batch_norm_default_55 = None
        relu__default_52 = torch.ops.aten.relu_.default(getitem_167);  getitem_167 = None
        view_default_60 = torch.ops.aten.view.default(relu__default_52, [128, 2, 256, 16, 16])
        sum_dim_int_list_24 = torch.ops.aten.sum.dim_IntList(view_default_60, [1])
        mean_dim_12 = torch.ops.aten.mean.dim(sum_dim_int_list_24, [2, 3], True);  sum_dim_int_list_24 = None
        convolution_default_68 = torch.ops.aten.convolution.default(mean_dim_12, primals_737, primals_736, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_736 = None
        native_batch_norm_default_56 = torch.ops.aten.native_batch_norm.default(convolution_default_68, primals_734, primals_730, primals_732, primals_733, True, 0.1, 1e-05);  primals_730 = None
        getitem_170 = native_batch_norm_default_56[0]
        getitem_171 = native_batch_norm_default_56[1]
        getitem_172 = native_batch_norm_default_56[2];  native_batch_norm_default_56 = None
        relu__default_53 = torch.ops.aten.relu_.default(getitem_170);  getitem_170 = None
        convolution_default_69 = torch.ops.aten.convolution.default(relu__default_53, primals_739, primals_738, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_738 = None
        view_default_61 = torch.ops.aten.view.default(convolution_default_69, [128, 1, 2, -1]);  convolution_default_69 = None
        transpose_int_12 = torch.ops.aten.transpose.int(view_default_61, 1, 2);  view_default_61 = None
        _softmax_default_12 = torch.ops.aten._softmax.default(transpose_int_12, 1, False);  transpose_int_12 = None
        view_default_62 = torch.ops.aten.view.default(_softmax_default_12, [128, 512])
        view_default_63 = torch.ops.aten.view.default(view_default_62, [128, -1, 1, 1]);  view_default_62 = None
        view_default_64 = torch.ops.aten.view.default(view_default_63, [128, 2, 256, 1, 1]);  view_default_63 = None
        mul_tensor_12 = torch.ops.aten.mul.Tensor(view_default_60, view_default_64)
        sum_dim_int_list_25 = torch.ops.aten.sum.dim_IntList(mul_tensor_12, [1]);  mul_tensor_12 = None
        convolution_default_70 = torch.ops.aten.convolution.default(sum_dim_int_list_25, primals_740, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_57 = torch.ops.aten.native_batch_norm.default(convolution_default_70, primals_723, primals_719, primals_721, primals_722, True, 0.1, 1e-05);  primals_719 = None
        getitem_173 = native_batch_norm_default_57[0]
        getitem_174 = native_batch_norm_default_57[1]
        getitem_175 = native_batch_norm_default_57[2];  native_batch_norm_default_57 = None
        add__tensor_70 = torch.ops.aten.add_.Tensor(getitem_173, relu__default_50);  getitem_173 = None
        relu__default_54 = torch.ops.aten.relu_.default(add__tensor_70);  add__tensor_70 = None
        convolution_default_71 = torch.ops.aten.convolution.default(relu__default_54, primals_751, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_58 = torch.ops.aten.native_batch_norm.default(convolution_default_71, primals_745, primals_741, primals_743, primals_744, True, 0.1, 1e-05);  primals_741 = None
        getitem_176 = native_batch_norm_default_58[0]
        getitem_177 = native_batch_norm_default_58[1]
        getitem_178 = native_batch_norm_default_58[2];  native_batch_norm_default_58 = None
        relu__default_55 = torch.ops.aten.relu_.default(getitem_176);  getitem_176 = None
        convolution_default_72 = torch.ops.aten.convolution.default(relu__default_55, primals_762, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_59 = torch.ops.aten.native_batch_norm.default(convolution_default_72, primals_756, primals_752, primals_754, primals_755, True, 0.1, 1e-05);  primals_752 = None
        getitem_179 = native_batch_norm_default_59[0]
        getitem_180 = native_batch_norm_default_59[1]
        getitem_181 = native_batch_norm_default_59[2];  native_batch_norm_default_59 = None
        relu__default_56 = torch.ops.aten.relu_.default(getitem_179);  getitem_179 = None
        view_default_65 = torch.ops.aten.view.default(relu__default_56, [128, 2, 256, 16, 16])
        sum_dim_int_list_26 = torch.ops.aten.sum.dim_IntList(view_default_65, [1])
        mean_dim_13 = torch.ops.aten.mean.dim(sum_dim_int_list_26, [2, 3], True);  sum_dim_int_list_26 = None
        convolution_default_73 = torch.ops.aten.convolution.default(mean_dim_13, primals_764, primals_763, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_763 = None
        native_batch_norm_default_60 = torch.ops.aten.native_batch_norm.default(convolution_default_73, primals_761, primals_757, primals_759, primals_760, True, 0.1, 1e-05);  primals_757 = None
        getitem_182 = native_batch_norm_default_60[0]
        getitem_183 = native_batch_norm_default_60[1]
        getitem_184 = native_batch_norm_default_60[2];  native_batch_norm_default_60 = None
        relu__default_57 = torch.ops.aten.relu_.default(getitem_182);  getitem_182 = None
        convolution_default_74 = torch.ops.aten.convolution.default(relu__default_57, primals_766, primals_765, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_765 = None
        view_default_66 = torch.ops.aten.view.default(convolution_default_74, [128, 1, 2, -1]);  convolution_default_74 = None
        transpose_int_13 = torch.ops.aten.transpose.int(view_default_66, 1, 2);  view_default_66 = None
        _softmax_default_13 = torch.ops.aten._softmax.default(transpose_int_13, 1, False);  transpose_int_13 = None
        view_default_67 = torch.ops.aten.view.default(_softmax_default_13, [128, 512])
        view_default_68 = torch.ops.aten.view.default(view_default_67, [128, -1, 1, 1]);  view_default_67 = None
        view_default_69 = torch.ops.aten.view.default(view_default_68, [128, 2, 256, 1, 1]);  view_default_68 = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(view_default_65, view_default_69)
        sum_dim_int_list_27 = torch.ops.aten.sum.dim_IntList(mul_tensor_13, [1]);  mul_tensor_13 = None
        convolution_default_75 = torch.ops.aten.convolution.default(sum_dim_int_list_27, primals_767, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_61 = torch.ops.aten.native_batch_norm.default(convolution_default_75, primals_750, primals_746, primals_748, primals_749, True, 0.1, 1e-05);  primals_746 = None
        getitem_185 = native_batch_norm_default_61[0]
        getitem_186 = native_batch_norm_default_61[1]
        getitem_187 = native_batch_norm_default_61[2];  native_batch_norm_default_61 = None
        add__tensor_75 = torch.ops.aten.add_.Tensor(getitem_185, relu__default_54);  getitem_185 = None
        relu__default_58 = torch.ops.aten.relu_.default(add__tensor_75);  add__tensor_75 = None
        convolution_default_76 = torch.ops.aten.convolution.default(relu__default_58, primals_778, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_62 = torch.ops.aten.native_batch_norm.default(convolution_default_76, primals_772, primals_768, primals_770, primals_771, True, 0.1, 1e-05);  primals_768 = None
        getitem_188 = native_batch_norm_default_62[0]
        getitem_189 = native_batch_norm_default_62[1]
        getitem_190 = native_batch_norm_default_62[2];  native_batch_norm_default_62 = None
        relu__default_59 = torch.ops.aten.relu_.default(getitem_188);  getitem_188 = None
        convolution_default_77 = torch.ops.aten.convolution.default(relu__default_59, primals_789, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_63 = torch.ops.aten.native_batch_norm.default(convolution_default_77, primals_783, primals_779, primals_781, primals_782, True, 0.1, 1e-05);  primals_779 = None
        getitem_191 = native_batch_norm_default_63[0]
        getitem_192 = native_batch_norm_default_63[1]
        getitem_193 = native_batch_norm_default_63[2];  native_batch_norm_default_63 = None
        relu__default_60 = torch.ops.aten.relu_.default(getitem_191);  getitem_191 = None
        view_default_70 = torch.ops.aten.view.default(relu__default_60, [128, 2, 256, 16, 16])
        sum_dim_int_list_28 = torch.ops.aten.sum.dim_IntList(view_default_70, [1])
        mean_dim_14 = torch.ops.aten.mean.dim(sum_dim_int_list_28, [2, 3], True);  sum_dim_int_list_28 = None
        convolution_default_78 = torch.ops.aten.convolution.default(mean_dim_14, primals_791, primals_790, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_790 = None
        native_batch_norm_default_64 = torch.ops.aten.native_batch_norm.default(convolution_default_78, primals_788, primals_784, primals_786, primals_787, True, 0.1, 1e-05);  primals_784 = None
        getitem_194 = native_batch_norm_default_64[0]
        getitem_195 = native_batch_norm_default_64[1]
        getitem_196 = native_batch_norm_default_64[2];  native_batch_norm_default_64 = None
        relu__default_61 = torch.ops.aten.relu_.default(getitem_194);  getitem_194 = None
        convolution_default_79 = torch.ops.aten.convolution.default(relu__default_61, primals_793, primals_792, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_792 = None
        view_default_71 = torch.ops.aten.view.default(convolution_default_79, [128, 1, 2, -1]);  convolution_default_79 = None
        transpose_int_14 = torch.ops.aten.transpose.int(view_default_71, 1, 2);  view_default_71 = None
        _softmax_default_14 = torch.ops.aten._softmax.default(transpose_int_14, 1, False);  transpose_int_14 = None
        view_default_72 = torch.ops.aten.view.default(_softmax_default_14, [128, 512])
        view_default_73 = torch.ops.aten.view.default(view_default_72, [128, -1, 1, 1]);  view_default_72 = None
        view_default_74 = torch.ops.aten.view.default(view_default_73, [128, 2, 256, 1, 1]);  view_default_73 = None
        mul_tensor_14 = torch.ops.aten.mul.Tensor(view_default_70, view_default_74)
        sum_dim_int_list_29 = torch.ops.aten.sum.dim_IntList(mul_tensor_14, [1]);  mul_tensor_14 = None
        convolution_default_80 = torch.ops.aten.convolution.default(sum_dim_int_list_29, primals_794, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_65 = torch.ops.aten.native_batch_norm.default(convolution_default_80, primals_777, primals_773, primals_775, primals_776, True, 0.1, 1e-05);  primals_773 = None
        getitem_197 = native_batch_norm_default_65[0]
        getitem_198 = native_batch_norm_default_65[1]
        getitem_199 = native_batch_norm_default_65[2];  native_batch_norm_default_65 = None
        add__tensor_80 = torch.ops.aten.add_.Tensor(getitem_197, relu__default_58);  getitem_197 = None
        relu__default_62 = torch.ops.aten.relu_.default(add__tensor_80);  add__tensor_80 = None
        convolution_default_81 = torch.ops.aten.convolution.default(relu__default_62, primals_805, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_66 = torch.ops.aten.native_batch_norm.default(convolution_default_81, primals_799, primals_795, primals_797, primals_798, True, 0.1, 1e-05);  primals_795 = None
        getitem_200 = native_batch_norm_default_66[0]
        getitem_201 = native_batch_norm_default_66[1]
        getitem_202 = native_batch_norm_default_66[2];  native_batch_norm_default_66 = None
        relu__default_63 = torch.ops.aten.relu_.default(getitem_200);  getitem_200 = None
        convolution_default_82 = torch.ops.aten.convolution.default(relu__default_63, primals_816, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_67 = torch.ops.aten.native_batch_norm.default(convolution_default_82, primals_810, primals_806, primals_808, primals_809, True, 0.1, 1e-05);  primals_806 = None
        getitem_203 = native_batch_norm_default_67[0]
        getitem_204 = native_batch_norm_default_67[1]
        getitem_205 = native_batch_norm_default_67[2];  native_batch_norm_default_67 = None
        relu__default_64 = torch.ops.aten.relu_.default(getitem_203);  getitem_203 = None
        view_default_75 = torch.ops.aten.view.default(relu__default_64, [128, 2, 256, 16, 16])
        sum_dim_int_list_30 = torch.ops.aten.sum.dim_IntList(view_default_75, [1])
        mean_dim_15 = torch.ops.aten.mean.dim(sum_dim_int_list_30, [2, 3], True);  sum_dim_int_list_30 = None
        convolution_default_83 = torch.ops.aten.convolution.default(mean_dim_15, primals_818, primals_817, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_817 = None
        native_batch_norm_default_68 = torch.ops.aten.native_batch_norm.default(convolution_default_83, primals_815, primals_811, primals_813, primals_814, True, 0.1, 1e-05);  primals_811 = None
        getitem_206 = native_batch_norm_default_68[0]
        getitem_207 = native_batch_norm_default_68[1]
        getitem_208 = native_batch_norm_default_68[2];  native_batch_norm_default_68 = None
        relu__default_65 = torch.ops.aten.relu_.default(getitem_206);  getitem_206 = None
        convolution_default_84 = torch.ops.aten.convolution.default(relu__default_65, primals_820, primals_819, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_819 = None
        view_default_76 = torch.ops.aten.view.default(convolution_default_84, [128, 1, 2, -1]);  convolution_default_84 = None
        transpose_int_15 = torch.ops.aten.transpose.int(view_default_76, 1, 2);  view_default_76 = None
        _softmax_default_15 = torch.ops.aten._softmax.default(transpose_int_15, 1, False);  transpose_int_15 = None
        view_default_77 = torch.ops.aten.view.default(_softmax_default_15, [128, 512])
        view_default_78 = torch.ops.aten.view.default(view_default_77, [128, -1, 1, 1]);  view_default_77 = None
        view_default_79 = torch.ops.aten.view.default(view_default_78, [128, 2, 256, 1, 1]);  view_default_78 = None
        mul_tensor_15 = torch.ops.aten.mul.Tensor(view_default_75, view_default_79)
        sum_dim_int_list_31 = torch.ops.aten.sum.dim_IntList(mul_tensor_15, [1]);  mul_tensor_15 = None
        convolution_default_85 = torch.ops.aten.convolution.default(sum_dim_int_list_31, primals_821, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_69 = torch.ops.aten.native_batch_norm.default(convolution_default_85, primals_804, primals_800, primals_802, primals_803, True, 0.1, 1e-05);  primals_800 = None
        getitem_209 = native_batch_norm_default_69[0]
        getitem_210 = native_batch_norm_default_69[1]
        getitem_211 = native_batch_norm_default_69[2];  native_batch_norm_default_69 = None
        add__tensor_85 = torch.ops.aten.add_.Tensor(getitem_209, relu__default_62);  getitem_209 = None
        relu__default_66 = torch.ops.aten.relu_.default(add__tensor_85);  add__tensor_85 = None
        convolution_default_86 = torch.ops.aten.convolution.default(relu__default_66, primals_832, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_70 = torch.ops.aten.native_batch_norm.default(convolution_default_86, primals_826, primals_822, primals_824, primals_825, True, 0.1, 1e-05);  primals_822 = None
        getitem_212 = native_batch_norm_default_70[0]
        getitem_213 = native_batch_norm_default_70[1]
        getitem_214 = native_batch_norm_default_70[2];  native_batch_norm_default_70 = None
        relu__default_67 = torch.ops.aten.relu_.default(getitem_212);  getitem_212 = None
        convolution_default_87 = torch.ops.aten.convolution.default(relu__default_67, primals_843, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_71 = torch.ops.aten.native_batch_norm.default(convolution_default_87, primals_837, primals_833, primals_835, primals_836, True, 0.1, 1e-05);  primals_833 = None
        getitem_215 = native_batch_norm_default_71[0]
        getitem_216 = native_batch_norm_default_71[1]
        getitem_217 = native_batch_norm_default_71[2];  native_batch_norm_default_71 = None
        relu__default_68 = torch.ops.aten.relu_.default(getitem_215);  getitem_215 = None
        view_default_80 = torch.ops.aten.view.default(relu__default_68, [128, 2, 256, 16, 16])
        sum_dim_int_list_32 = torch.ops.aten.sum.dim_IntList(view_default_80, [1])
        mean_dim_16 = torch.ops.aten.mean.dim(sum_dim_int_list_32, [2, 3], True);  sum_dim_int_list_32 = None
        convolution_default_88 = torch.ops.aten.convolution.default(mean_dim_16, primals_845, primals_844, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_844 = None
        native_batch_norm_default_72 = torch.ops.aten.native_batch_norm.default(convolution_default_88, primals_842, primals_838, primals_840, primals_841, True, 0.1, 1e-05);  primals_838 = None
        getitem_218 = native_batch_norm_default_72[0]
        getitem_219 = native_batch_norm_default_72[1]
        getitem_220 = native_batch_norm_default_72[2];  native_batch_norm_default_72 = None
        relu__default_69 = torch.ops.aten.relu_.default(getitem_218);  getitem_218 = None
        convolution_default_89 = torch.ops.aten.convolution.default(relu__default_69, primals_847, primals_846, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_846 = None
        view_default_81 = torch.ops.aten.view.default(convolution_default_89, [128, 1, 2, -1]);  convolution_default_89 = None
        transpose_int_16 = torch.ops.aten.transpose.int(view_default_81, 1, 2);  view_default_81 = None
        _softmax_default_16 = torch.ops.aten._softmax.default(transpose_int_16, 1, False);  transpose_int_16 = None
        view_default_82 = torch.ops.aten.view.default(_softmax_default_16, [128, 512])
        view_default_83 = torch.ops.aten.view.default(view_default_82, [128, -1, 1, 1]);  view_default_82 = None
        view_default_84 = torch.ops.aten.view.default(view_default_83, [128, 2, 256, 1, 1]);  view_default_83 = None
        mul_tensor_16 = torch.ops.aten.mul.Tensor(view_default_80, view_default_84)
        sum_dim_int_list_33 = torch.ops.aten.sum.dim_IntList(mul_tensor_16, [1]);  mul_tensor_16 = None
        convolution_default_90 = torch.ops.aten.convolution.default(sum_dim_int_list_33, primals_848, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_73 = torch.ops.aten.native_batch_norm.default(convolution_default_90, primals_831, primals_827, primals_829, primals_830, True, 0.1, 1e-05);  primals_827 = None
        getitem_221 = native_batch_norm_default_73[0]
        getitem_222 = native_batch_norm_default_73[1]
        getitem_223 = native_batch_norm_default_73[2];  native_batch_norm_default_73 = None
        add__tensor_90 = torch.ops.aten.add_.Tensor(getitem_221, relu__default_66);  getitem_221 = None
        relu__default_70 = torch.ops.aten.relu_.default(add__tensor_90);  add__tensor_90 = None
        convolution_default_91 = torch.ops.aten.convolution.default(relu__default_70, primals_265, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_74 = torch.ops.aten.native_batch_norm.default(convolution_default_91, primals_259, primals_255, primals_257, primals_258, True, 0.1, 1e-05);  primals_255 = None
        getitem_224 = native_batch_norm_default_74[0]
        getitem_225 = native_batch_norm_default_74[1]
        getitem_226 = native_batch_norm_default_74[2];  native_batch_norm_default_74 = None
        relu__default_71 = torch.ops.aten.relu_.default(getitem_224);  getitem_224 = None
        convolution_default_92 = torch.ops.aten.convolution.default(relu__default_71, primals_276, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_75 = torch.ops.aten.native_batch_norm.default(convolution_default_92, primals_270, primals_266, primals_268, primals_269, True, 0.1, 1e-05);  primals_266 = None
        getitem_227 = native_batch_norm_default_75[0]
        getitem_228 = native_batch_norm_default_75[1]
        getitem_229 = native_batch_norm_default_75[2];  native_batch_norm_default_75 = None
        relu__default_72 = torch.ops.aten.relu_.default(getitem_227);  getitem_227 = None
        view_default_85 = torch.ops.aten.view.default(relu__default_72, [128, 2, 256, 16, 16])
        sum_dim_int_list_34 = torch.ops.aten.sum.dim_IntList(view_default_85, [1])
        mean_dim_17 = torch.ops.aten.mean.dim(sum_dim_int_list_34, [2, 3], True);  sum_dim_int_list_34 = None
        convolution_default_93 = torch.ops.aten.convolution.default(mean_dim_17, primals_278, primals_277, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_277 = None
        native_batch_norm_default_76 = torch.ops.aten.native_batch_norm.default(convolution_default_93, primals_275, primals_271, primals_273, primals_274, True, 0.1, 1e-05);  primals_271 = None
        getitem_230 = native_batch_norm_default_76[0]
        getitem_231 = native_batch_norm_default_76[1]
        getitem_232 = native_batch_norm_default_76[2];  native_batch_norm_default_76 = None
        relu__default_73 = torch.ops.aten.relu_.default(getitem_230);  getitem_230 = None
        convolution_default_94 = torch.ops.aten.convolution.default(relu__default_73, primals_280, primals_279, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_279 = None
        view_default_86 = torch.ops.aten.view.default(convolution_default_94, [128, 1, 2, -1]);  convolution_default_94 = None
        transpose_int_17 = torch.ops.aten.transpose.int(view_default_86, 1, 2);  view_default_86 = None
        _softmax_default_17 = torch.ops.aten._softmax.default(transpose_int_17, 1, False);  transpose_int_17 = None
        view_default_87 = torch.ops.aten.view.default(_softmax_default_17, [128, 512])
        view_default_88 = torch.ops.aten.view.default(view_default_87, [128, -1, 1, 1]);  view_default_87 = None
        view_default_89 = torch.ops.aten.view.default(view_default_88, [128, 2, 256, 1, 1]);  view_default_88 = None
        mul_tensor_17 = torch.ops.aten.mul.Tensor(view_default_85, view_default_89)
        sum_dim_int_list_35 = torch.ops.aten.sum.dim_IntList(mul_tensor_17, [1]);  mul_tensor_17 = None
        convolution_default_95 = torch.ops.aten.convolution.default(sum_dim_int_list_35, primals_281, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_77 = torch.ops.aten.native_batch_norm.default(convolution_default_95, primals_264, primals_260, primals_262, primals_263, True, 0.1, 1e-05);  primals_260 = None
        getitem_233 = native_batch_norm_default_77[0]
        getitem_234 = native_batch_norm_default_77[1]
        getitem_235 = native_batch_norm_default_77[2];  native_batch_norm_default_77 = None
        add__tensor_95 = torch.ops.aten.add_.Tensor(getitem_233, relu__default_70);  getitem_233 = None
        relu__default_74 = torch.ops.aten.relu_.default(add__tensor_95);  add__tensor_95 = None
        convolution_default_96 = torch.ops.aten.convolution.default(relu__default_74, primals_292, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_78 = torch.ops.aten.native_batch_norm.default(convolution_default_96, primals_286, primals_282, primals_284, primals_285, True, 0.1, 1e-05);  primals_282 = None
        getitem_236 = native_batch_norm_default_78[0]
        getitem_237 = native_batch_norm_default_78[1]
        getitem_238 = native_batch_norm_default_78[2];  native_batch_norm_default_78 = None
        relu__default_75 = torch.ops.aten.relu_.default(getitem_236);  getitem_236 = None
        convolution_default_97 = torch.ops.aten.convolution.default(relu__default_75, primals_303, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_79 = torch.ops.aten.native_batch_norm.default(convolution_default_97, primals_297, primals_293, primals_295, primals_296, True, 0.1, 1e-05);  primals_293 = None
        getitem_239 = native_batch_norm_default_79[0]
        getitem_240 = native_batch_norm_default_79[1]
        getitem_241 = native_batch_norm_default_79[2];  native_batch_norm_default_79 = None
        relu__default_76 = torch.ops.aten.relu_.default(getitem_239);  getitem_239 = None
        view_default_90 = torch.ops.aten.view.default(relu__default_76, [128, 2, 256, 16, 16])
        sum_dim_int_list_36 = torch.ops.aten.sum.dim_IntList(view_default_90, [1])
        mean_dim_18 = torch.ops.aten.mean.dim(sum_dim_int_list_36, [2, 3], True);  sum_dim_int_list_36 = None
        convolution_default_98 = torch.ops.aten.convolution.default(mean_dim_18, primals_305, primals_304, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_304 = None
        native_batch_norm_default_80 = torch.ops.aten.native_batch_norm.default(convolution_default_98, primals_302, primals_298, primals_300, primals_301, True, 0.1, 1e-05);  primals_298 = None
        getitem_242 = native_batch_norm_default_80[0]
        getitem_243 = native_batch_norm_default_80[1]
        getitem_244 = native_batch_norm_default_80[2];  native_batch_norm_default_80 = None
        relu__default_77 = torch.ops.aten.relu_.default(getitem_242);  getitem_242 = None
        convolution_default_99 = torch.ops.aten.convolution.default(relu__default_77, primals_307, primals_306, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_306 = None
        view_default_91 = torch.ops.aten.view.default(convolution_default_99, [128, 1, 2, -1]);  convolution_default_99 = None
        transpose_int_18 = torch.ops.aten.transpose.int(view_default_91, 1, 2);  view_default_91 = None
        _softmax_default_18 = torch.ops.aten._softmax.default(transpose_int_18, 1, False);  transpose_int_18 = None
        view_default_92 = torch.ops.aten.view.default(_softmax_default_18, [128, 512])
        view_default_93 = torch.ops.aten.view.default(view_default_92, [128, -1, 1, 1]);  view_default_92 = None
        view_default_94 = torch.ops.aten.view.default(view_default_93, [128, 2, 256, 1, 1]);  view_default_93 = None
        mul_tensor_18 = torch.ops.aten.mul.Tensor(view_default_90, view_default_94)
        sum_dim_int_list_37 = torch.ops.aten.sum.dim_IntList(mul_tensor_18, [1]);  mul_tensor_18 = None
        convolution_default_100 = torch.ops.aten.convolution.default(sum_dim_int_list_37, primals_308, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_81 = torch.ops.aten.native_batch_norm.default(convolution_default_100, primals_291, primals_287, primals_289, primals_290, True, 0.1, 1e-05);  primals_287 = None
        getitem_245 = native_batch_norm_default_81[0]
        getitem_246 = native_batch_norm_default_81[1]
        getitem_247 = native_batch_norm_default_81[2];  native_batch_norm_default_81 = None
        add__tensor_100 = torch.ops.aten.add_.Tensor(getitem_245, relu__default_74);  getitem_245 = None
        relu__default_78 = torch.ops.aten.relu_.default(add__tensor_100);  add__tensor_100 = None
        convolution_default_101 = torch.ops.aten.convolution.default(relu__default_78, primals_319, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_82 = torch.ops.aten.native_batch_norm.default(convolution_default_101, primals_313, primals_309, primals_311, primals_312, True, 0.1, 1e-05);  primals_309 = None
        getitem_248 = native_batch_norm_default_82[0]
        getitem_249 = native_batch_norm_default_82[1]
        getitem_250 = native_batch_norm_default_82[2];  native_batch_norm_default_82 = None
        relu__default_79 = torch.ops.aten.relu_.default(getitem_248);  getitem_248 = None
        convolution_default_102 = torch.ops.aten.convolution.default(relu__default_79, primals_330, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_83 = torch.ops.aten.native_batch_norm.default(convolution_default_102, primals_324, primals_320, primals_322, primals_323, True, 0.1, 1e-05);  primals_320 = None
        getitem_251 = native_batch_norm_default_83[0]
        getitem_252 = native_batch_norm_default_83[1]
        getitem_253 = native_batch_norm_default_83[2];  native_batch_norm_default_83 = None
        relu__default_80 = torch.ops.aten.relu_.default(getitem_251);  getitem_251 = None
        view_default_95 = torch.ops.aten.view.default(relu__default_80, [128, 2, 256, 16, 16])
        sum_dim_int_list_38 = torch.ops.aten.sum.dim_IntList(view_default_95, [1])
        mean_dim_19 = torch.ops.aten.mean.dim(sum_dim_int_list_38, [2, 3], True);  sum_dim_int_list_38 = None
        convolution_default_103 = torch.ops.aten.convolution.default(mean_dim_19, primals_332, primals_331, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_331 = None
        native_batch_norm_default_84 = torch.ops.aten.native_batch_norm.default(convolution_default_103, primals_329, primals_325, primals_327, primals_328, True, 0.1, 1e-05);  primals_325 = None
        getitem_254 = native_batch_norm_default_84[0]
        getitem_255 = native_batch_norm_default_84[1]
        getitem_256 = native_batch_norm_default_84[2];  native_batch_norm_default_84 = None
        relu__default_81 = torch.ops.aten.relu_.default(getitem_254);  getitem_254 = None
        convolution_default_104 = torch.ops.aten.convolution.default(relu__default_81, primals_334, primals_333, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_333 = None
        view_default_96 = torch.ops.aten.view.default(convolution_default_104, [128, 1, 2, -1]);  convolution_default_104 = None
        transpose_int_19 = torch.ops.aten.transpose.int(view_default_96, 1, 2);  view_default_96 = None
        _softmax_default_19 = torch.ops.aten._softmax.default(transpose_int_19, 1, False);  transpose_int_19 = None
        view_default_97 = torch.ops.aten.view.default(_softmax_default_19, [128, 512])
        view_default_98 = torch.ops.aten.view.default(view_default_97, [128, -1, 1, 1]);  view_default_97 = None
        view_default_99 = torch.ops.aten.view.default(view_default_98, [128, 2, 256, 1, 1]);  view_default_98 = None
        mul_tensor_19 = torch.ops.aten.mul.Tensor(view_default_95, view_default_99)
        sum_dim_int_list_39 = torch.ops.aten.sum.dim_IntList(mul_tensor_19, [1]);  mul_tensor_19 = None
        convolution_default_105 = torch.ops.aten.convolution.default(sum_dim_int_list_39, primals_335, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_85 = torch.ops.aten.native_batch_norm.default(convolution_default_105, primals_318, primals_314, primals_316, primals_317, True, 0.1, 1e-05);  primals_314 = None
        getitem_257 = native_batch_norm_default_85[0]
        getitem_258 = native_batch_norm_default_85[1]
        getitem_259 = native_batch_norm_default_85[2];  native_batch_norm_default_85 = None
        add__tensor_105 = torch.ops.aten.add_.Tensor(getitem_257, relu__default_78);  getitem_257 = None
        relu__default_82 = torch.ops.aten.relu_.default(add__tensor_105);  add__tensor_105 = None
        convolution_default_106 = torch.ops.aten.convolution.default(relu__default_82, primals_346, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_86 = torch.ops.aten.native_batch_norm.default(convolution_default_106, primals_340, primals_336, primals_338, primals_339, True, 0.1, 1e-05);  primals_336 = None
        getitem_260 = native_batch_norm_default_86[0]
        getitem_261 = native_batch_norm_default_86[1]
        getitem_262 = native_batch_norm_default_86[2];  native_batch_norm_default_86 = None
        relu__default_83 = torch.ops.aten.relu_.default(getitem_260);  getitem_260 = None
        convolution_default_107 = torch.ops.aten.convolution.default(relu__default_83, primals_357, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_87 = torch.ops.aten.native_batch_norm.default(convolution_default_107, primals_351, primals_347, primals_349, primals_350, True, 0.1, 1e-05);  primals_347 = None
        getitem_263 = native_batch_norm_default_87[0]
        getitem_264 = native_batch_norm_default_87[1]
        getitem_265 = native_batch_norm_default_87[2];  native_batch_norm_default_87 = None
        relu__default_84 = torch.ops.aten.relu_.default(getitem_263);  getitem_263 = None
        view_default_100 = torch.ops.aten.view.default(relu__default_84, [128, 2, 256, 16, 16])
        sum_dim_int_list_40 = torch.ops.aten.sum.dim_IntList(view_default_100, [1])
        mean_dim_20 = torch.ops.aten.mean.dim(sum_dim_int_list_40, [2, 3], True);  sum_dim_int_list_40 = None
        convolution_default_108 = torch.ops.aten.convolution.default(mean_dim_20, primals_359, primals_358, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_358 = None
        native_batch_norm_default_88 = torch.ops.aten.native_batch_norm.default(convolution_default_108, primals_356, primals_352, primals_354, primals_355, True, 0.1, 1e-05);  primals_352 = None
        getitem_266 = native_batch_norm_default_88[0]
        getitem_267 = native_batch_norm_default_88[1]
        getitem_268 = native_batch_norm_default_88[2];  native_batch_norm_default_88 = None
        relu__default_85 = torch.ops.aten.relu_.default(getitem_266);  getitem_266 = None
        convolution_default_109 = torch.ops.aten.convolution.default(relu__default_85, primals_361, primals_360, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_360 = None
        view_default_101 = torch.ops.aten.view.default(convolution_default_109, [128, 1, 2, -1]);  convolution_default_109 = None
        transpose_int_20 = torch.ops.aten.transpose.int(view_default_101, 1, 2);  view_default_101 = None
        _softmax_default_20 = torch.ops.aten._softmax.default(transpose_int_20, 1, False);  transpose_int_20 = None
        view_default_102 = torch.ops.aten.view.default(_softmax_default_20, [128, 512])
        view_default_103 = torch.ops.aten.view.default(view_default_102, [128, -1, 1, 1]);  view_default_102 = None
        view_default_104 = torch.ops.aten.view.default(view_default_103, [128, 2, 256, 1, 1]);  view_default_103 = None
        mul_tensor_20 = torch.ops.aten.mul.Tensor(view_default_100, view_default_104)
        sum_dim_int_list_41 = torch.ops.aten.sum.dim_IntList(mul_tensor_20, [1]);  mul_tensor_20 = None
        convolution_default_110 = torch.ops.aten.convolution.default(sum_dim_int_list_41, primals_362, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_89 = torch.ops.aten.native_batch_norm.default(convolution_default_110, primals_345, primals_341, primals_343, primals_344, True, 0.1, 1e-05);  primals_341 = None
        getitem_269 = native_batch_norm_default_89[0]
        getitem_270 = native_batch_norm_default_89[1]
        getitem_271 = native_batch_norm_default_89[2];  native_batch_norm_default_89 = None
        add__tensor_110 = torch.ops.aten.add_.Tensor(getitem_269, relu__default_82);  getitem_269 = None
        relu__default_86 = torch.ops.aten.relu_.default(add__tensor_110);  add__tensor_110 = None
        convolution_default_111 = torch.ops.aten.convolution.default(relu__default_86, primals_373, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_90 = torch.ops.aten.native_batch_norm.default(convolution_default_111, primals_367, primals_363, primals_365, primals_366, True, 0.1, 1e-05);  primals_363 = None
        getitem_272 = native_batch_norm_default_90[0]
        getitem_273 = native_batch_norm_default_90[1]
        getitem_274 = native_batch_norm_default_90[2];  native_batch_norm_default_90 = None
        relu__default_87 = torch.ops.aten.relu_.default(getitem_272);  getitem_272 = None
        convolution_default_112 = torch.ops.aten.convolution.default(relu__default_87, primals_384, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_91 = torch.ops.aten.native_batch_norm.default(convolution_default_112, primals_378, primals_374, primals_376, primals_377, True, 0.1, 1e-05);  primals_374 = None
        getitem_275 = native_batch_norm_default_91[0]
        getitem_276 = native_batch_norm_default_91[1]
        getitem_277 = native_batch_norm_default_91[2];  native_batch_norm_default_91 = None
        relu__default_88 = torch.ops.aten.relu_.default(getitem_275);  getitem_275 = None
        view_default_105 = torch.ops.aten.view.default(relu__default_88, [128, 2, 256, 16, 16])
        sum_dim_int_list_42 = torch.ops.aten.sum.dim_IntList(view_default_105, [1])
        mean_dim_21 = torch.ops.aten.mean.dim(sum_dim_int_list_42, [2, 3], True);  sum_dim_int_list_42 = None
        convolution_default_113 = torch.ops.aten.convolution.default(mean_dim_21, primals_386, primals_385, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_385 = None
        native_batch_norm_default_92 = torch.ops.aten.native_batch_norm.default(convolution_default_113, primals_383, primals_379, primals_381, primals_382, True, 0.1, 1e-05);  primals_379 = None
        getitem_278 = native_batch_norm_default_92[0]
        getitem_279 = native_batch_norm_default_92[1]
        getitem_280 = native_batch_norm_default_92[2];  native_batch_norm_default_92 = None
        relu__default_89 = torch.ops.aten.relu_.default(getitem_278);  getitem_278 = None
        convolution_default_114 = torch.ops.aten.convolution.default(relu__default_89, primals_388, primals_387, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_387 = None
        view_default_106 = torch.ops.aten.view.default(convolution_default_114, [128, 1, 2, -1]);  convolution_default_114 = None
        transpose_int_21 = torch.ops.aten.transpose.int(view_default_106, 1, 2);  view_default_106 = None
        _softmax_default_21 = torch.ops.aten._softmax.default(transpose_int_21, 1, False);  transpose_int_21 = None
        view_default_107 = torch.ops.aten.view.default(_softmax_default_21, [128, 512])
        view_default_108 = torch.ops.aten.view.default(view_default_107, [128, -1, 1, 1]);  view_default_107 = None
        view_default_109 = torch.ops.aten.view.default(view_default_108, [128, 2, 256, 1, 1]);  view_default_108 = None
        mul_tensor_21 = torch.ops.aten.mul.Tensor(view_default_105, view_default_109)
        sum_dim_int_list_43 = torch.ops.aten.sum.dim_IntList(mul_tensor_21, [1]);  mul_tensor_21 = None
        convolution_default_115 = torch.ops.aten.convolution.default(sum_dim_int_list_43, primals_389, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_93 = torch.ops.aten.native_batch_norm.default(convolution_default_115, primals_372, primals_368, primals_370, primals_371, True, 0.1, 1e-05);  primals_368 = None
        getitem_281 = native_batch_norm_default_93[0]
        getitem_282 = native_batch_norm_default_93[1]
        getitem_283 = native_batch_norm_default_93[2];  native_batch_norm_default_93 = None
        add__tensor_115 = torch.ops.aten.add_.Tensor(getitem_281, relu__default_86);  getitem_281 = None
        relu__default_90 = torch.ops.aten.relu_.default(add__tensor_115);  add__tensor_115 = None
        convolution_default_116 = torch.ops.aten.convolution.default(relu__default_90, primals_400, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_94 = torch.ops.aten.native_batch_norm.default(convolution_default_116, primals_394, primals_390, primals_392, primals_393, True, 0.1, 1e-05);  primals_390 = None
        getitem_284 = native_batch_norm_default_94[0]
        getitem_285 = native_batch_norm_default_94[1]
        getitem_286 = native_batch_norm_default_94[2];  native_batch_norm_default_94 = None
        relu__default_91 = torch.ops.aten.relu_.default(getitem_284);  getitem_284 = None
        convolution_default_117 = torch.ops.aten.convolution.default(relu__default_91, primals_411, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_95 = torch.ops.aten.native_batch_norm.default(convolution_default_117, primals_405, primals_401, primals_403, primals_404, True, 0.1, 1e-05);  primals_401 = None
        getitem_287 = native_batch_norm_default_95[0]
        getitem_288 = native_batch_norm_default_95[1]
        getitem_289 = native_batch_norm_default_95[2];  native_batch_norm_default_95 = None
        relu__default_92 = torch.ops.aten.relu_.default(getitem_287);  getitem_287 = None
        view_default_110 = torch.ops.aten.view.default(relu__default_92, [128, 2, 256, 16, 16])
        sum_dim_int_list_44 = torch.ops.aten.sum.dim_IntList(view_default_110, [1])
        mean_dim_22 = torch.ops.aten.mean.dim(sum_dim_int_list_44, [2, 3], True);  sum_dim_int_list_44 = None
        convolution_default_118 = torch.ops.aten.convolution.default(mean_dim_22, primals_413, primals_412, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_412 = None
        native_batch_norm_default_96 = torch.ops.aten.native_batch_norm.default(convolution_default_118, primals_410, primals_406, primals_408, primals_409, True, 0.1, 1e-05);  primals_406 = None
        getitem_290 = native_batch_norm_default_96[0]
        getitem_291 = native_batch_norm_default_96[1]
        getitem_292 = native_batch_norm_default_96[2];  native_batch_norm_default_96 = None
        relu__default_93 = torch.ops.aten.relu_.default(getitem_290);  getitem_290 = None
        convolution_default_119 = torch.ops.aten.convolution.default(relu__default_93, primals_415, primals_414, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_414 = None
        view_default_111 = torch.ops.aten.view.default(convolution_default_119, [128, 1, 2, -1]);  convolution_default_119 = None
        transpose_int_22 = torch.ops.aten.transpose.int(view_default_111, 1, 2);  view_default_111 = None
        _softmax_default_22 = torch.ops.aten._softmax.default(transpose_int_22, 1, False);  transpose_int_22 = None
        view_default_112 = torch.ops.aten.view.default(_softmax_default_22, [128, 512])
        view_default_113 = torch.ops.aten.view.default(view_default_112, [128, -1, 1, 1]);  view_default_112 = None
        view_default_114 = torch.ops.aten.view.default(view_default_113, [128, 2, 256, 1, 1]);  view_default_113 = None
        mul_tensor_22 = torch.ops.aten.mul.Tensor(view_default_110, view_default_114)
        sum_dim_int_list_45 = torch.ops.aten.sum.dim_IntList(mul_tensor_22, [1]);  mul_tensor_22 = None
        convolution_default_120 = torch.ops.aten.convolution.default(sum_dim_int_list_45, primals_416, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_97 = torch.ops.aten.native_batch_norm.default(convolution_default_120, primals_399, primals_395, primals_397, primals_398, True, 0.1, 1e-05);  primals_395 = None
        getitem_293 = native_batch_norm_default_97[0]
        getitem_294 = native_batch_norm_default_97[1]
        getitem_295 = native_batch_norm_default_97[2];  native_batch_norm_default_97 = None
        add__tensor_120 = torch.ops.aten.add_.Tensor(getitem_293, relu__default_90);  getitem_293 = None
        relu__default_94 = torch.ops.aten.relu_.default(add__tensor_120);  add__tensor_120 = None
        convolution_default_121 = torch.ops.aten.convolution.default(relu__default_94, primals_427, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_98 = torch.ops.aten.native_batch_norm.default(convolution_default_121, primals_421, primals_417, primals_419, primals_420, True, 0.1, 1e-05);  primals_417 = None
        getitem_296 = native_batch_norm_default_98[0]
        getitem_297 = native_batch_norm_default_98[1]
        getitem_298 = native_batch_norm_default_98[2];  native_batch_norm_default_98 = None
        relu__default_95 = torch.ops.aten.relu_.default(getitem_296);  getitem_296 = None
        convolution_default_122 = torch.ops.aten.convolution.default(relu__default_95, primals_438, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_99 = torch.ops.aten.native_batch_norm.default(convolution_default_122, primals_432, primals_428, primals_430, primals_431, True, 0.1, 1e-05);  primals_428 = None
        getitem_299 = native_batch_norm_default_99[0]
        getitem_300 = native_batch_norm_default_99[1]
        getitem_301 = native_batch_norm_default_99[2];  native_batch_norm_default_99 = None
        relu__default_96 = torch.ops.aten.relu_.default(getitem_299);  getitem_299 = None
        view_default_115 = torch.ops.aten.view.default(relu__default_96, [128, 2, 256, 16, 16])
        sum_dim_int_list_46 = torch.ops.aten.sum.dim_IntList(view_default_115, [1])
        mean_dim_23 = torch.ops.aten.mean.dim(sum_dim_int_list_46, [2, 3], True);  sum_dim_int_list_46 = None
        convolution_default_123 = torch.ops.aten.convolution.default(mean_dim_23, primals_440, primals_439, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_439 = None
        native_batch_norm_default_100 = torch.ops.aten.native_batch_norm.default(convolution_default_123, primals_437, primals_433, primals_435, primals_436, True, 0.1, 1e-05);  primals_433 = None
        getitem_302 = native_batch_norm_default_100[0]
        getitem_303 = native_batch_norm_default_100[1]
        getitem_304 = native_batch_norm_default_100[2];  native_batch_norm_default_100 = None
        relu__default_97 = torch.ops.aten.relu_.default(getitem_302);  getitem_302 = None
        convolution_default_124 = torch.ops.aten.convolution.default(relu__default_97, primals_442, primals_441, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_441 = None
        view_default_116 = torch.ops.aten.view.default(convolution_default_124, [128, 1, 2, -1]);  convolution_default_124 = None
        transpose_int_23 = torch.ops.aten.transpose.int(view_default_116, 1, 2);  view_default_116 = None
        _softmax_default_23 = torch.ops.aten._softmax.default(transpose_int_23, 1, False);  transpose_int_23 = None
        view_default_117 = torch.ops.aten.view.default(_softmax_default_23, [128, 512])
        view_default_118 = torch.ops.aten.view.default(view_default_117, [128, -1, 1, 1]);  view_default_117 = None
        view_default_119 = torch.ops.aten.view.default(view_default_118, [128, 2, 256, 1, 1]);  view_default_118 = None
        mul_tensor_23 = torch.ops.aten.mul.Tensor(view_default_115, view_default_119)
        sum_dim_int_list_47 = torch.ops.aten.sum.dim_IntList(mul_tensor_23, [1]);  mul_tensor_23 = None
        convolution_default_125 = torch.ops.aten.convolution.default(sum_dim_int_list_47, primals_443, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_101 = torch.ops.aten.native_batch_norm.default(convolution_default_125, primals_426, primals_422, primals_424, primals_425, True, 0.1, 1e-05);  primals_422 = None
        getitem_305 = native_batch_norm_default_101[0]
        getitem_306 = native_batch_norm_default_101[1]
        getitem_307 = native_batch_norm_default_101[2];  native_batch_norm_default_101 = None
        add__tensor_125 = torch.ops.aten.add_.Tensor(getitem_305, relu__default_94);  getitem_305 = None
        relu__default_98 = torch.ops.aten.relu_.default(add__tensor_125);  add__tensor_125 = None
        convolution_default_126 = torch.ops.aten.convolution.default(relu__default_98, primals_454, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_102 = torch.ops.aten.native_batch_norm.default(convolution_default_126, primals_448, primals_444, primals_446, primals_447, True, 0.1, 1e-05);  primals_444 = None
        getitem_308 = native_batch_norm_default_102[0]
        getitem_309 = native_batch_norm_default_102[1]
        getitem_310 = native_batch_norm_default_102[2];  native_batch_norm_default_102 = None
        relu__default_99 = torch.ops.aten.relu_.default(getitem_308);  getitem_308 = None
        convolution_default_127 = torch.ops.aten.convolution.default(relu__default_99, primals_465, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_103 = torch.ops.aten.native_batch_norm.default(convolution_default_127, primals_459, primals_455, primals_457, primals_458, True, 0.1, 1e-05);  primals_455 = None
        getitem_311 = native_batch_norm_default_103[0]
        getitem_312 = native_batch_norm_default_103[1]
        getitem_313 = native_batch_norm_default_103[2];  native_batch_norm_default_103 = None
        relu__default_100 = torch.ops.aten.relu_.default(getitem_311);  getitem_311 = None
        view_default_120 = torch.ops.aten.view.default(relu__default_100, [128, 2, 256, 16, 16])
        sum_dim_int_list_48 = torch.ops.aten.sum.dim_IntList(view_default_120, [1])
        mean_dim_24 = torch.ops.aten.mean.dim(sum_dim_int_list_48, [2, 3], True);  sum_dim_int_list_48 = None
        convolution_default_128 = torch.ops.aten.convolution.default(mean_dim_24, primals_467, primals_466, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_466 = None
        native_batch_norm_default_104 = torch.ops.aten.native_batch_norm.default(convolution_default_128, primals_464, primals_460, primals_462, primals_463, True, 0.1, 1e-05);  primals_460 = None
        getitem_314 = native_batch_norm_default_104[0]
        getitem_315 = native_batch_norm_default_104[1]
        getitem_316 = native_batch_norm_default_104[2];  native_batch_norm_default_104 = None
        relu__default_101 = torch.ops.aten.relu_.default(getitem_314);  getitem_314 = None
        convolution_default_129 = torch.ops.aten.convolution.default(relu__default_101, primals_469, primals_468, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_468 = None
        view_default_121 = torch.ops.aten.view.default(convolution_default_129, [128, 1, 2, -1]);  convolution_default_129 = None
        transpose_int_24 = torch.ops.aten.transpose.int(view_default_121, 1, 2);  view_default_121 = None
        _softmax_default_24 = torch.ops.aten._softmax.default(transpose_int_24, 1, False);  transpose_int_24 = None
        view_default_122 = torch.ops.aten.view.default(_softmax_default_24, [128, 512])
        view_default_123 = torch.ops.aten.view.default(view_default_122, [128, -1, 1, 1]);  view_default_122 = None
        view_default_124 = torch.ops.aten.view.default(view_default_123, [128, 2, 256, 1, 1]);  view_default_123 = None
        mul_tensor_24 = torch.ops.aten.mul.Tensor(view_default_120, view_default_124)
        sum_dim_int_list_49 = torch.ops.aten.sum.dim_IntList(mul_tensor_24, [1]);  mul_tensor_24 = None
        convolution_default_130 = torch.ops.aten.convolution.default(sum_dim_int_list_49, primals_470, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_105 = torch.ops.aten.native_batch_norm.default(convolution_default_130, primals_453, primals_449, primals_451, primals_452, True, 0.1, 1e-05);  primals_449 = None
        getitem_317 = native_batch_norm_default_105[0]
        getitem_318 = native_batch_norm_default_105[1]
        getitem_319 = native_batch_norm_default_105[2];  native_batch_norm_default_105 = None
        add__tensor_130 = torch.ops.aten.add_.Tensor(getitem_317, relu__default_98);  getitem_317 = None
        relu__default_102 = torch.ops.aten.relu_.default(add__tensor_130);  add__tensor_130 = None
        convolution_default_131 = torch.ops.aten.convolution.default(relu__default_102, primals_481, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_106 = torch.ops.aten.native_batch_norm.default(convolution_default_131, primals_475, primals_471, primals_473, primals_474, True, 0.1, 1e-05);  primals_471 = None
        getitem_320 = native_batch_norm_default_106[0]
        getitem_321 = native_batch_norm_default_106[1]
        getitem_322 = native_batch_norm_default_106[2];  native_batch_norm_default_106 = None
        relu__default_103 = torch.ops.aten.relu_.default(getitem_320);  getitem_320 = None
        convolution_default_132 = torch.ops.aten.convolution.default(relu__default_103, primals_492, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_107 = torch.ops.aten.native_batch_norm.default(convolution_default_132, primals_486, primals_482, primals_484, primals_485, True, 0.1, 1e-05);  primals_482 = None
        getitem_323 = native_batch_norm_default_107[0]
        getitem_324 = native_batch_norm_default_107[1]
        getitem_325 = native_batch_norm_default_107[2];  native_batch_norm_default_107 = None
        relu__default_104 = torch.ops.aten.relu_.default(getitem_323);  getitem_323 = None
        view_default_125 = torch.ops.aten.view.default(relu__default_104, [128, 2, 256, 16, 16])
        sum_dim_int_list_50 = torch.ops.aten.sum.dim_IntList(view_default_125, [1])
        mean_dim_25 = torch.ops.aten.mean.dim(sum_dim_int_list_50, [2, 3], True);  sum_dim_int_list_50 = None
        convolution_default_133 = torch.ops.aten.convolution.default(mean_dim_25, primals_494, primals_493, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_493 = None
        native_batch_norm_default_108 = torch.ops.aten.native_batch_norm.default(convolution_default_133, primals_491, primals_487, primals_489, primals_490, True, 0.1, 1e-05);  primals_487 = None
        getitem_326 = native_batch_norm_default_108[0]
        getitem_327 = native_batch_norm_default_108[1]
        getitem_328 = native_batch_norm_default_108[2];  native_batch_norm_default_108 = None
        relu__default_105 = torch.ops.aten.relu_.default(getitem_326);  getitem_326 = None
        convolution_default_134 = torch.ops.aten.convolution.default(relu__default_105, primals_496, primals_495, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_495 = None
        view_default_126 = torch.ops.aten.view.default(convolution_default_134, [128, 1, 2, -1]);  convolution_default_134 = None
        transpose_int_25 = torch.ops.aten.transpose.int(view_default_126, 1, 2);  view_default_126 = None
        _softmax_default_25 = torch.ops.aten._softmax.default(transpose_int_25, 1, False);  transpose_int_25 = None
        view_default_127 = torch.ops.aten.view.default(_softmax_default_25, [128, 512])
        view_default_128 = torch.ops.aten.view.default(view_default_127, [128, -1, 1, 1]);  view_default_127 = None
        view_default_129 = torch.ops.aten.view.default(view_default_128, [128, 2, 256, 1, 1]);  view_default_128 = None
        mul_tensor_25 = torch.ops.aten.mul.Tensor(view_default_125, view_default_129)
        sum_dim_int_list_51 = torch.ops.aten.sum.dim_IntList(mul_tensor_25, [1]);  mul_tensor_25 = None
        convolution_default_135 = torch.ops.aten.convolution.default(sum_dim_int_list_51, primals_497, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_109 = torch.ops.aten.native_batch_norm.default(convolution_default_135, primals_480, primals_476, primals_478, primals_479, True, 0.1, 1e-05);  primals_476 = None
        getitem_329 = native_batch_norm_default_109[0]
        getitem_330 = native_batch_norm_default_109[1]
        getitem_331 = native_batch_norm_default_109[2];  native_batch_norm_default_109 = None
        add__tensor_135 = torch.ops.aten.add_.Tensor(getitem_329, relu__default_102);  getitem_329 = None
        relu__default_106 = torch.ops.aten.relu_.default(add__tensor_135);  add__tensor_135 = None
        convolution_default_136 = torch.ops.aten.convolution.default(relu__default_106, primals_508, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_110 = torch.ops.aten.native_batch_norm.default(convolution_default_136, primals_502, primals_498, primals_500, primals_501, True, 0.1, 1e-05);  primals_498 = None
        getitem_332 = native_batch_norm_default_110[0]
        getitem_333 = native_batch_norm_default_110[1]
        getitem_334 = native_batch_norm_default_110[2];  native_batch_norm_default_110 = None
        relu__default_107 = torch.ops.aten.relu_.default(getitem_332);  getitem_332 = None
        convolution_default_137 = torch.ops.aten.convolution.default(relu__default_107, primals_519, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_111 = torch.ops.aten.native_batch_norm.default(convolution_default_137, primals_513, primals_509, primals_511, primals_512, True, 0.1, 1e-05);  primals_509 = None
        getitem_335 = native_batch_norm_default_111[0]
        getitem_336 = native_batch_norm_default_111[1]
        getitem_337 = native_batch_norm_default_111[2];  native_batch_norm_default_111 = None
        relu__default_108 = torch.ops.aten.relu_.default(getitem_335);  getitem_335 = None
        view_default_130 = torch.ops.aten.view.default(relu__default_108, [128, 2, 256, 16, 16])
        sum_dim_int_list_52 = torch.ops.aten.sum.dim_IntList(view_default_130, [1])
        mean_dim_26 = torch.ops.aten.mean.dim(sum_dim_int_list_52, [2, 3], True);  sum_dim_int_list_52 = None
        convolution_default_138 = torch.ops.aten.convolution.default(mean_dim_26, primals_521, primals_520, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_520 = None
        native_batch_norm_default_112 = torch.ops.aten.native_batch_norm.default(convolution_default_138, primals_518, primals_514, primals_516, primals_517, True, 0.1, 1e-05);  primals_514 = None
        getitem_338 = native_batch_norm_default_112[0]
        getitem_339 = native_batch_norm_default_112[1]
        getitem_340 = native_batch_norm_default_112[2];  native_batch_norm_default_112 = None
        relu__default_109 = torch.ops.aten.relu_.default(getitem_338);  getitem_338 = None
        convolution_default_139 = torch.ops.aten.convolution.default(relu__default_109, primals_523, primals_522, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_522 = None
        view_default_131 = torch.ops.aten.view.default(convolution_default_139, [128, 1, 2, -1]);  convolution_default_139 = None
        transpose_int_26 = torch.ops.aten.transpose.int(view_default_131, 1, 2);  view_default_131 = None
        _softmax_default_26 = torch.ops.aten._softmax.default(transpose_int_26, 1, False);  transpose_int_26 = None
        view_default_132 = torch.ops.aten.view.default(_softmax_default_26, [128, 512])
        view_default_133 = torch.ops.aten.view.default(view_default_132, [128, -1, 1, 1]);  view_default_132 = None
        view_default_134 = torch.ops.aten.view.default(view_default_133, [128, 2, 256, 1, 1]);  view_default_133 = None
        mul_tensor_26 = torch.ops.aten.mul.Tensor(view_default_130, view_default_134)
        sum_dim_int_list_53 = torch.ops.aten.sum.dim_IntList(mul_tensor_26, [1]);  mul_tensor_26 = None
        convolution_default_140 = torch.ops.aten.convolution.default(sum_dim_int_list_53, primals_524, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_113 = torch.ops.aten.native_batch_norm.default(convolution_default_140, primals_507, primals_503, primals_505, primals_506, True, 0.1, 1e-05);  primals_503 = None
        getitem_341 = native_batch_norm_default_113[0]
        getitem_342 = native_batch_norm_default_113[1]
        getitem_343 = native_batch_norm_default_113[2];  native_batch_norm_default_113 = None
        add__tensor_140 = torch.ops.aten.add_.Tensor(getitem_341, relu__default_106);  getitem_341 = None
        relu__default_110 = torch.ops.aten.relu_.default(add__tensor_140);  add__tensor_140 = None
        convolution_default_141 = torch.ops.aten.convolution.default(relu__default_110, primals_562, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_114 = torch.ops.aten.native_batch_norm.default(convolution_default_141, primals_556, primals_552, primals_554, primals_555, True, 0.1, 1e-05);  primals_552 = None
        getitem_344 = native_batch_norm_default_114[0]
        getitem_345 = native_batch_norm_default_114[1]
        getitem_346 = native_batch_norm_default_114[2];  native_batch_norm_default_114 = None
        relu__default_111 = torch.ops.aten.relu_.default(getitem_344);  getitem_344 = None
        convolution_default_142 = torch.ops.aten.convolution.default(relu__default_111, primals_573, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_115 = torch.ops.aten.native_batch_norm.default(convolution_default_142, primals_567, primals_563, primals_565, primals_566, True, 0.1, 1e-05);  primals_563 = None
        getitem_347 = native_batch_norm_default_115[0]
        getitem_348 = native_batch_norm_default_115[1]
        getitem_349 = native_batch_norm_default_115[2];  native_batch_norm_default_115 = None
        relu__default_112 = torch.ops.aten.relu_.default(getitem_347);  getitem_347 = None
        view_default_135 = torch.ops.aten.view.default(relu__default_112, [128, 2, 256, 16, 16])
        sum_dim_int_list_54 = torch.ops.aten.sum.dim_IntList(view_default_135, [1])
        mean_dim_27 = torch.ops.aten.mean.dim(sum_dim_int_list_54, [2, 3], True);  sum_dim_int_list_54 = None
        convolution_default_143 = torch.ops.aten.convolution.default(mean_dim_27, primals_575, primals_574, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_574 = None
        native_batch_norm_default_116 = torch.ops.aten.native_batch_norm.default(convolution_default_143, primals_572, primals_568, primals_570, primals_571, True, 0.1, 1e-05);  primals_568 = None
        getitem_350 = native_batch_norm_default_116[0]
        getitem_351 = native_batch_norm_default_116[1]
        getitem_352 = native_batch_norm_default_116[2];  native_batch_norm_default_116 = None
        relu__default_113 = torch.ops.aten.relu_.default(getitem_350);  getitem_350 = None
        convolution_default_144 = torch.ops.aten.convolution.default(relu__default_113, primals_577, primals_576, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_576 = None
        view_default_136 = torch.ops.aten.view.default(convolution_default_144, [128, 1, 2, -1]);  convolution_default_144 = None
        transpose_int_27 = torch.ops.aten.transpose.int(view_default_136, 1, 2);  view_default_136 = None
        _softmax_default_27 = torch.ops.aten._softmax.default(transpose_int_27, 1, False);  transpose_int_27 = None
        view_default_137 = torch.ops.aten.view.default(_softmax_default_27, [128, 512])
        view_default_138 = torch.ops.aten.view.default(view_default_137, [128, -1, 1, 1]);  view_default_137 = None
        view_default_139 = torch.ops.aten.view.default(view_default_138, [128, 2, 256, 1, 1]);  view_default_138 = None
        mul_tensor_27 = torch.ops.aten.mul.Tensor(view_default_135, view_default_139)
        sum_dim_int_list_55 = torch.ops.aten.sum.dim_IntList(mul_tensor_27, [1]);  mul_tensor_27 = None
        convolution_default_145 = torch.ops.aten.convolution.default(sum_dim_int_list_55, primals_578, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_117 = torch.ops.aten.native_batch_norm.default(convolution_default_145, primals_561, primals_557, primals_559, primals_560, True, 0.1, 1e-05);  primals_557 = None
        getitem_353 = native_batch_norm_default_117[0]
        getitem_354 = native_batch_norm_default_117[1]
        getitem_355 = native_batch_norm_default_117[2];  native_batch_norm_default_117 = None
        add__tensor_145 = torch.ops.aten.add_.Tensor(getitem_353, relu__default_110);  getitem_353 = None
        relu__default_114 = torch.ops.aten.relu_.default(add__tensor_145);  add__tensor_145 = None
        convolution_default_146 = torch.ops.aten.convolution.default(relu__default_114, primals_589, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_118 = torch.ops.aten.native_batch_norm.default(convolution_default_146, primals_583, primals_579, primals_581, primals_582, True, 0.1, 1e-05);  primals_579 = None
        getitem_356 = native_batch_norm_default_118[0]
        getitem_357 = native_batch_norm_default_118[1]
        getitem_358 = native_batch_norm_default_118[2];  native_batch_norm_default_118 = None
        relu__default_115 = torch.ops.aten.relu_.default(getitem_356);  getitem_356 = None
        convolution_default_147 = torch.ops.aten.convolution.default(relu__default_115, primals_600, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_119 = torch.ops.aten.native_batch_norm.default(convolution_default_147, primals_594, primals_590, primals_592, primals_593, True, 0.1, 1e-05);  primals_590 = None
        getitem_359 = native_batch_norm_default_119[0]
        getitem_360 = native_batch_norm_default_119[1]
        getitem_361 = native_batch_norm_default_119[2];  native_batch_norm_default_119 = None
        relu__default_116 = torch.ops.aten.relu_.default(getitem_359);  getitem_359 = None
        view_default_140 = torch.ops.aten.view.default(relu__default_116, [128, 2, 256, 16, 16])
        sum_dim_int_list_56 = torch.ops.aten.sum.dim_IntList(view_default_140, [1])
        mean_dim_28 = torch.ops.aten.mean.dim(sum_dim_int_list_56, [2, 3], True);  sum_dim_int_list_56 = None
        convolution_default_148 = torch.ops.aten.convolution.default(mean_dim_28, primals_602, primals_601, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_601 = None
        native_batch_norm_default_120 = torch.ops.aten.native_batch_norm.default(convolution_default_148, primals_599, primals_595, primals_597, primals_598, True, 0.1, 1e-05);  primals_595 = None
        getitem_362 = native_batch_norm_default_120[0]
        getitem_363 = native_batch_norm_default_120[1]
        getitem_364 = native_batch_norm_default_120[2];  native_batch_norm_default_120 = None
        relu__default_117 = torch.ops.aten.relu_.default(getitem_362);  getitem_362 = None
        convolution_default_149 = torch.ops.aten.convolution.default(relu__default_117, primals_604, primals_603, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_603 = None
        view_default_141 = torch.ops.aten.view.default(convolution_default_149, [128, 1, 2, -1]);  convolution_default_149 = None
        transpose_int_28 = torch.ops.aten.transpose.int(view_default_141, 1, 2);  view_default_141 = None
        _softmax_default_28 = torch.ops.aten._softmax.default(transpose_int_28, 1, False);  transpose_int_28 = None
        view_default_142 = torch.ops.aten.view.default(_softmax_default_28, [128, 512])
        view_default_143 = torch.ops.aten.view.default(view_default_142, [128, -1, 1, 1]);  view_default_142 = None
        view_default_144 = torch.ops.aten.view.default(view_default_143, [128, 2, 256, 1, 1]);  view_default_143 = None
        mul_tensor_28 = torch.ops.aten.mul.Tensor(view_default_140, view_default_144)
        sum_dim_int_list_57 = torch.ops.aten.sum.dim_IntList(mul_tensor_28, [1]);  mul_tensor_28 = None
        convolution_default_150 = torch.ops.aten.convolution.default(sum_dim_int_list_57, primals_605, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_121 = torch.ops.aten.native_batch_norm.default(convolution_default_150, primals_588, primals_584, primals_586, primals_587, True, 0.1, 1e-05);  primals_584 = None
        getitem_365 = native_batch_norm_default_121[0]
        getitem_366 = native_batch_norm_default_121[1]
        getitem_367 = native_batch_norm_default_121[2];  native_batch_norm_default_121 = None
        add__tensor_150 = torch.ops.aten.add_.Tensor(getitem_365, relu__default_114);  getitem_365 = None
        relu__default_118 = torch.ops.aten.relu_.default(add__tensor_150);  add__tensor_150 = None
        convolution_default_151 = torch.ops.aten.convolution.default(relu__default_118, primals_616, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_122 = torch.ops.aten.native_batch_norm.default(convolution_default_151, primals_610, primals_606, primals_608, primals_609, True, 0.1, 1e-05);  primals_606 = None
        getitem_368 = native_batch_norm_default_122[0]
        getitem_369 = native_batch_norm_default_122[1]
        getitem_370 = native_batch_norm_default_122[2];  native_batch_norm_default_122 = None
        relu__default_119 = torch.ops.aten.relu_.default(getitem_368);  getitem_368 = None
        convolution_default_152 = torch.ops.aten.convolution.default(relu__default_119, primals_627, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_123 = torch.ops.aten.native_batch_norm.default(convolution_default_152, primals_621, primals_617, primals_619, primals_620, True, 0.1, 1e-05);  primals_617 = None
        getitem_371 = native_batch_norm_default_123[0]
        getitem_372 = native_batch_norm_default_123[1]
        getitem_373 = native_batch_norm_default_123[2];  native_batch_norm_default_123 = None
        relu__default_120 = torch.ops.aten.relu_.default(getitem_371);  getitem_371 = None
        view_default_145 = torch.ops.aten.view.default(relu__default_120, [128, 2, 256, 16, 16])
        sum_dim_int_list_58 = torch.ops.aten.sum.dim_IntList(view_default_145, [1])
        mean_dim_29 = torch.ops.aten.mean.dim(sum_dim_int_list_58, [2, 3], True);  sum_dim_int_list_58 = None
        convolution_default_153 = torch.ops.aten.convolution.default(mean_dim_29, primals_629, primals_628, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_628 = None
        native_batch_norm_default_124 = torch.ops.aten.native_batch_norm.default(convolution_default_153, primals_626, primals_622, primals_624, primals_625, True, 0.1, 1e-05);  primals_622 = None
        getitem_374 = native_batch_norm_default_124[0]
        getitem_375 = native_batch_norm_default_124[1]
        getitem_376 = native_batch_norm_default_124[2];  native_batch_norm_default_124 = None
        relu__default_121 = torch.ops.aten.relu_.default(getitem_374);  getitem_374 = None
        convolution_default_154 = torch.ops.aten.convolution.default(relu__default_121, primals_631, primals_630, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_630 = None
        view_default_146 = torch.ops.aten.view.default(convolution_default_154, [128, 1, 2, -1]);  convolution_default_154 = None
        transpose_int_29 = torch.ops.aten.transpose.int(view_default_146, 1, 2);  view_default_146 = None
        _softmax_default_29 = torch.ops.aten._softmax.default(transpose_int_29, 1, False);  transpose_int_29 = None
        view_default_147 = torch.ops.aten.view.default(_softmax_default_29, [128, 512])
        view_default_148 = torch.ops.aten.view.default(view_default_147, [128, -1, 1, 1]);  view_default_147 = None
        view_default_149 = torch.ops.aten.view.default(view_default_148, [128, 2, 256, 1, 1]);  view_default_148 = None
        mul_tensor_29 = torch.ops.aten.mul.Tensor(view_default_145, view_default_149)
        sum_dim_int_list_59 = torch.ops.aten.sum.dim_IntList(mul_tensor_29, [1]);  mul_tensor_29 = None
        convolution_default_155 = torch.ops.aten.convolution.default(sum_dim_int_list_59, primals_632, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_125 = torch.ops.aten.native_batch_norm.default(convolution_default_155, primals_615, primals_611, primals_613, primals_614, True, 0.1, 1e-05);  primals_611 = None
        getitem_377 = native_batch_norm_default_125[0]
        getitem_378 = native_batch_norm_default_125[1]
        getitem_379 = native_batch_norm_default_125[2];  native_batch_norm_default_125 = None
        add__tensor_155 = torch.ops.aten.add_.Tensor(getitem_377, relu__default_118);  getitem_377 = None
        relu__default_122 = torch.ops.aten.relu_.default(add__tensor_155);  add__tensor_155 = None
        convolution_default_156 = torch.ops.aten.convolution.default(relu__default_122, primals_859, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_126 = torch.ops.aten.native_batch_norm.default(convolution_default_156, primals_853, primals_849, primals_851, primals_852, True, 0.1, 1e-05);  primals_849 = None
        getitem_380 = native_batch_norm_default_126[0]
        getitem_381 = native_batch_norm_default_126[1]
        getitem_382 = native_batch_norm_default_126[2];  native_batch_norm_default_126 = None
        relu__default_123 = torch.ops.aten.relu_.default(getitem_380);  getitem_380 = None
        convolution_default_157 = torch.ops.aten.convolution.default(relu__default_123, primals_870, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_127 = torch.ops.aten.native_batch_norm.default(convolution_default_157, primals_864, primals_860, primals_862, primals_863, True, 0.1, 1e-05);  primals_860 = None
        getitem_383 = native_batch_norm_default_127[0]
        getitem_384 = native_batch_norm_default_127[1]
        getitem_385 = native_batch_norm_default_127[2];  native_batch_norm_default_127 = None
        relu__default_124 = torch.ops.aten.relu_.default(getitem_383);  getitem_383 = None
        view_default_150 = torch.ops.aten.view.default(relu__default_124, [128, 2, 512, 16, 16])
        sum_dim_int_list_60 = torch.ops.aten.sum.dim_IntList(view_default_150, [1])
        mean_dim_30 = torch.ops.aten.mean.dim(sum_dim_int_list_60, [2, 3], True);  sum_dim_int_list_60 = None
        convolution_default_158 = torch.ops.aten.convolution.default(mean_dim_30, primals_872, primals_871, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_871 = None
        native_batch_norm_default_128 = torch.ops.aten.native_batch_norm.default(convolution_default_158, primals_869, primals_865, primals_867, primals_868, True, 0.1, 1e-05);  primals_865 = None
        getitem_386 = native_batch_norm_default_128[0]
        getitem_387 = native_batch_norm_default_128[1]
        getitem_388 = native_batch_norm_default_128[2];  native_batch_norm_default_128 = None
        relu__default_125 = torch.ops.aten.relu_.default(getitem_386);  getitem_386 = None
        convolution_default_159 = torch.ops.aten.convolution.default(relu__default_125, primals_874, primals_873, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_873 = None
        view_default_151 = torch.ops.aten.view.default(convolution_default_159, [128, 1, 2, -1]);  convolution_default_159 = None
        transpose_int_30 = torch.ops.aten.transpose.int(view_default_151, 1, 2);  view_default_151 = None
        _softmax_default_30 = torch.ops.aten._softmax.default(transpose_int_30, 1, False);  transpose_int_30 = None
        view_default_152 = torch.ops.aten.view.default(_softmax_default_30, [128, 1024])
        view_default_153 = torch.ops.aten.view.default(view_default_152, [128, -1, 1, 1]);  view_default_152 = None
        view_default_154 = torch.ops.aten.view.default(view_default_153, [128, 2, 512, 1, 1]);  view_default_153 = None
        mul_tensor_30 = torch.ops.aten.mul.Tensor(view_default_150, view_default_154)
        sum_dim_int_list_61 = torch.ops.aten.sum.dim_IntList(mul_tensor_30, [1]);  mul_tensor_30 = None
        avg_pool2d_default_4 = torch.ops.aten.avg_pool2d.default(sum_dim_int_list_61, [3, 3], [2, 2], [1, 1])
        convolution_default_160 = torch.ops.aten.convolution.default(avg_pool2d_default_4, primals_875, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_129 = torch.ops.aten.native_batch_norm.default(convolution_default_160, primals_858, primals_854, primals_856, primals_857, True, 0.1, 1e-05);  primals_854 = None
        getitem_389 = native_batch_norm_default_129[0]
        getitem_390 = native_batch_norm_default_129[1]
        getitem_391 = native_batch_norm_default_129[2];  native_batch_norm_default_129 = None
        avg_pool2d_default_5 = torch.ops.aten.avg_pool2d.default(relu__default_122, [2, 2], [2, 2], [0, 0], True, False)
        convolution_default_161 = torch.ops.aten.convolution.default(avg_pool2d_default_5, primals_876, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_130 = torch.ops.aten.native_batch_norm.default(convolution_default_161, primals_881, primals_877, primals_879, primals_880, True, 0.1, 1e-05);  primals_877 = None
        getitem_392 = native_batch_norm_default_130[0]
        getitem_393 = native_batch_norm_default_130[1]
        getitem_394 = native_batch_norm_default_130[2];  native_batch_norm_default_130 = None
        add__tensor_161 = torch.ops.aten.add_.Tensor(getitem_389, getitem_392);  getitem_389 = getitem_392 = None
        relu__default_126 = torch.ops.aten.relu_.default(add__tensor_161);  add__tensor_161 = None
        convolution_default_162 = torch.ops.aten.convolution.default(relu__default_126, primals_892, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_131 = torch.ops.aten.native_batch_norm.default(convolution_default_162, primals_886, primals_882, primals_884, primals_885, True, 0.1, 1e-05);  primals_882 = None
        getitem_395 = native_batch_norm_default_131[0]
        getitem_396 = native_batch_norm_default_131[1]
        getitem_397 = native_batch_norm_default_131[2];  native_batch_norm_default_131 = None
        relu__default_127 = torch.ops.aten.relu_.default(getitem_395);  getitem_395 = None
        convolution_default_163 = torch.ops.aten.convolution.default(relu__default_127, primals_903, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_132 = torch.ops.aten.native_batch_norm.default(convolution_default_163, primals_897, primals_893, primals_895, primals_896, True, 0.1, 1e-05);  primals_893 = None
        getitem_398 = native_batch_norm_default_132[0]
        getitem_399 = native_batch_norm_default_132[1]
        getitem_400 = native_batch_norm_default_132[2];  native_batch_norm_default_132 = None
        relu__default_128 = torch.ops.aten.relu_.default(getitem_398);  getitem_398 = None
        view_default_155 = torch.ops.aten.view.default(relu__default_128, [128, 2, 512, 8, 8])
        sum_dim_int_list_62 = torch.ops.aten.sum.dim_IntList(view_default_155, [1])
        mean_dim_31 = torch.ops.aten.mean.dim(sum_dim_int_list_62, [2, 3], True);  sum_dim_int_list_62 = None
        convolution_default_164 = torch.ops.aten.convolution.default(mean_dim_31, primals_905, primals_904, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_904 = None
        native_batch_norm_default_133 = torch.ops.aten.native_batch_norm.default(convolution_default_164, primals_902, primals_898, primals_900, primals_901, True, 0.1, 1e-05);  primals_898 = None
        getitem_401 = native_batch_norm_default_133[0]
        getitem_402 = native_batch_norm_default_133[1]
        getitem_403 = native_batch_norm_default_133[2];  native_batch_norm_default_133 = None
        relu__default_129 = torch.ops.aten.relu_.default(getitem_401);  getitem_401 = None
        convolution_default_165 = torch.ops.aten.convolution.default(relu__default_129, primals_907, primals_906, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_906 = None
        view_default_156 = torch.ops.aten.view.default(convolution_default_165, [128, 1, 2, -1]);  convolution_default_165 = None
        transpose_int_31 = torch.ops.aten.transpose.int(view_default_156, 1, 2);  view_default_156 = None
        _softmax_default_31 = torch.ops.aten._softmax.default(transpose_int_31, 1, False);  transpose_int_31 = None
        view_default_157 = torch.ops.aten.view.default(_softmax_default_31, [128, 1024])
        view_default_158 = torch.ops.aten.view.default(view_default_157, [128, -1, 1, 1]);  view_default_157 = None
        view_default_159 = torch.ops.aten.view.default(view_default_158, [128, 2, 512, 1, 1]);  view_default_158 = None
        mul_tensor_31 = torch.ops.aten.mul.Tensor(view_default_155, view_default_159)
        sum_dim_int_list_63 = torch.ops.aten.sum.dim_IntList(mul_tensor_31, [1]);  mul_tensor_31 = None
        convolution_default_166 = torch.ops.aten.convolution.default(sum_dim_int_list_63, primals_908, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_134 = torch.ops.aten.native_batch_norm.default(convolution_default_166, primals_891, primals_887, primals_889, primals_890, True, 0.1, 1e-05);  primals_887 = None
        getitem_404 = native_batch_norm_default_134[0]
        getitem_405 = native_batch_norm_default_134[1]
        getitem_406 = native_batch_norm_default_134[2];  native_batch_norm_default_134 = None
        add__tensor_166 = torch.ops.aten.add_.Tensor(getitem_404, relu__default_126);  getitem_404 = None
        relu__default_130 = torch.ops.aten.relu_.default(add__tensor_166);  add__tensor_166 = None
        convolution_default_167 = torch.ops.aten.convolution.default(relu__default_130, primals_919, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_135 = torch.ops.aten.native_batch_norm.default(convolution_default_167, primals_913, primals_909, primals_911, primals_912, True, 0.1, 1e-05);  primals_909 = None
        getitem_407 = native_batch_norm_default_135[0]
        getitem_408 = native_batch_norm_default_135[1]
        getitem_409 = native_batch_norm_default_135[2];  native_batch_norm_default_135 = None
        relu__default_131 = torch.ops.aten.relu_.default(getitem_407);  getitem_407 = None
        convolution_default_168 = torch.ops.aten.convolution.default(relu__default_131, primals_930, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 2)
        native_batch_norm_default_136 = torch.ops.aten.native_batch_norm.default(convolution_default_168, primals_924, primals_920, primals_922, primals_923, True, 0.1, 1e-05);  primals_920 = None
        getitem_410 = native_batch_norm_default_136[0]
        getitem_411 = native_batch_norm_default_136[1]
        getitem_412 = native_batch_norm_default_136[2];  native_batch_norm_default_136 = None
        relu__default_132 = torch.ops.aten.relu_.default(getitem_410);  getitem_410 = None
        view_default_160 = torch.ops.aten.view.default(relu__default_132, [128, 2, 512, 8, 8])
        sum_dim_int_list_64 = torch.ops.aten.sum.dim_IntList(view_default_160, [1])
        mean_dim_32 = torch.ops.aten.mean.dim(sum_dim_int_list_64, [2, 3], True);  sum_dim_int_list_64 = None
        convolution_default_169 = torch.ops.aten.convolution.default(mean_dim_32, primals_932, primals_931, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_931 = None
        native_batch_norm_default_137 = torch.ops.aten.native_batch_norm.default(convolution_default_169, primals_929, primals_925, primals_927, primals_928, True, 0.1, 1e-05);  primals_925 = None
        getitem_413 = native_batch_norm_default_137[0]
        getitem_414 = native_batch_norm_default_137[1]
        getitem_415 = native_batch_norm_default_137[2];  native_batch_norm_default_137 = None
        relu__default_133 = torch.ops.aten.relu_.default(getitem_413);  getitem_413 = None
        convolution_default_170 = torch.ops.aten.convolution.default(relu__default_133, primals_934, primals_933, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_933 = None
        view_default_161 = torch.ops.aten.view.default(convolution_default_170, [128, 1, 2, -1]);  convolution_default_170 = None
        transpose_int_32 = torch.ops.aten.transpose.int(view_default_161, 1, 2);  view_default_161 = None
        _softmax_default_32 = torch.ops.aten._softmax.default(transpose_int_32, 1, False);  transpose_int_32 = None
        view_default_162 = torch.ops.aten.view.default(_softmax_default_32, [128, 1024])
        view_default_163 = torch.ops.aten.view.default(view_default_162, [128, -1, 1, 1]);  view_default_162 = None
        view_default_164 = torch.ops.aten.view.default(view_default_163, [128, 2, 512, 1, 1]);  view_default_163 = None
        mul_tensor_32 = torch.ops.aten.mul.Tensor(view_default_160, view_default_164)
        sum_dim_int_list_65 = torch.ops.aten.sum.dim_IntList(mul_tensor_32, [1]);  mul_tensor_32 = None
        convolution_default_171 = torch.ops.aten.convolution.default(sum_dim_int_list_65, primals_935, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_138 = torch.ops.aten.native_batch_norm.default(convolution_default_171, primals_918, primals_914, primals_916, primals_917, True, 0.1, 1e-05);  primals_914 = None
        getitem_416 = native_batch_norm_default_138[0]
        getitem_417 = native_batch_norm_default_138[1]
        getitem_418 = native_batch_norm_default_138[2];  native_batch_norm_default_138 = None
        add__tensor_171 = torch.ops.aten.add_.Tensor(getitem_416, relu__default_130);  getitem_416 = None
        relu__default_134 = torch.ops.aten.relu_.default(add__tensor_171);  add__tensor_171 = None
        mean_dim_33 = torch.ops.aten.mean.dim(relu__default_134, [-1, -2], True)
        view_default_165 = torch.ops.aten.view.default(mean_dim_33, [128, 2048]);  mean_dim_33 = None
        t_default = torch.ops.aten.t.default(primals_20);  primals_20 = None
        addmm_default = torch.ops.aten.addmm.default(primals_19, view_default_165, t_default);  primals_19 = None
        return [addmm_default, convolution_default_121, mean_dim_20, getitem_294, getitem_295, getitem_331, primals_6, getitem_330, primals_240, relu__default_94, primals_236, primals_230, getitem_298, getitem_297, primals_235, relu__default_106, convolution_default_67, convolution_default_136, relu__default_95, getitem_334, primals_4, getitem_333, convolution_default_122, convolution_default_77, getitem_300, relu__default_107, primals_3, primals_229, primals_237, primals_232, convolution_default_137, primals_231, getitem_301, primals_5, relu__default_96, relu__default_52, primals_863, convolution_default_68, primals_879, getitem_349, primals_143, getitem_348, primals_864, primals_872, primals_870, relu__default_112, primals_880, primals_874, primals_868, getitem_169, primals_140, getitem_184, convolution_default_143, primals_876, getitem_168, primals_869, _softmax_default_14, mean_dim_27, getitem_351, primals_867, _softmax_default_27, view_default_135, getitem_352, relu__default_57, primals_875, relu__default_113, mean_dim_12, primals_881, view_default_60, getitem_381, getitem_400, getitem_382, relu__default_128, relu__default_123, primals_149, convolution_default_157, getitem_171, primals_144, primals_145, getitem_403, convolution_default_164, getitem_385, getitem_384, getitem_402, mean_dim_31, view_default_155, primals_148, relu__default_124, relu__default_129, primals_156, primals_155, primals_154, convolution_default_85, convolution_default_166, convolution_default_158, primals_159, _softmax_default_31, sum_dim_int_list_63, mean_dim_30, primals_151, view_default_150, getitem_387, primals_150, view_default_159, primals_297, getitem_49, primals_361, primals_421, view_default_94, primals_290, primals_301, primals_296, primals_303, primals_686, _softmax_default_1, getitem_204, getitem_34, getitem_48, view_default_79, primals_694, primals_302, getitem_250, mean_dim_1, relu__default_14, primals_366, primals_420, getitem_33, primals_685, primals_295, primals_365, primals_416, convolution_default_19, primals_409, primals_413, primals_683, relu__default_9, primals_419, primals_690, primals_411, primals_695, relu__default_78, primals_696, getitem_52, primals_410, getitem_51, getitem_249, primals_300, primals_691, getitem_246, primals_359, relu__default_15, primals_408, primals_291, primals_689, primals_415, getitem_240, primals_371, convolution_default_20, primals_370, primals_292, sum_dim_int_list_3, primals_372, convolution_default_102, view_default_9, primals_362, getitem_247, relu__default_79, convolution_default_101, getitem_54, getitem_55, convolution_default_13, primals_367, getitem_85, getitem_13, primals_705, _softmax_default_5, getitem_84, primals_100, primals_710, primals_101, relu__default_3, convolution_default_4, relu__default_25, primals_99, primals_102, primals_716, mean_dim_15, getitem_16, getitem_15, primals_712, primals_104, primals_701, relu__default_4, getitem_87, primals_702, sum_dim_int_list_11, primals_700, primals_110, convolution_default_34, primals_697, getitem_88, convolution_default_5, primals_106, primals_111, view_default_29, primals_706, mean_dim, primals_107, primals_707, view_default, convolution_default_35, primals_708, getitem_18, getitem_19, relu__default_26, primals_713, primals_112, getitem_66, getitem_418, getitem_417, view_default_95, getitem_67, mean_dim_19, primals_840, primals_832, relu__default_19, getitem_121, convolution_default_26, getitem_120, _softmax_default_19, relu__default_81, primals_831, view_default_164, relu__default_36, view_default_165, getitem_70, getitem_69, relu__default_70, primals_835, getitem_253, relu__default_134, getitem_252, primals_837, relu__default_20, relu__default_80, primals_836, convolution_default_91, convolution_default_48, convolution_default_106, t_default, mean_dim_8, view_default_40, getitem_123, view_default_100, convolution_default_27, primals_830, getitem_124, convolution_default_103, getitem_222, mean_dim_4, relu__default_37, primals_841, getitem_223, getitem_256, view_default_20, getitem_207, getitem_255, primals_799, primals_798, convolution_default_90, convolution_default_40, primals_724, relu__default_41, relu__default_30, primals_797, convolution_default_41, relu__default_65, getitem_138, getitem_139, primals_722, getitem_103, primals_803, primals_721, getitem_102, sum_dim_int_list_19, view_default_84, getitem_220, relu__default_31, convolution_default_55, primals_718, _softmax_default_9, primals_793, primals_789, primals_802, primals_794, primals_723, view_default_49, relu__default_42, primals_791, getitem_105, primals_727, getitem_106, primals_808, relu__default_69, relu__default_32, convolution_default_56, convolution_default_42, getitem_219, primals_717, primals_805, primals_804, view_default_35, mean_dim_7, primals_57, getitem_154, getitem_153, relu__default_86, primals_61, getitem_259, primals_678, relu__default_47, primals_62, primals_58, convolution_default_62, getitem_273, primals_56, primals_53, sum_dim_int_list_31, primals_505, mean_dim_11, primals_670, getitem_157, getitem_156, primals_681, convolution_default_111, primals_675, relu__default_48, convolution_default_72, primals_63, primals_680, primals_664, primals_52, primals_508, primals_669, primals_663, primals_679, relu__default_55, primals_668, primals_507, primals_667, primals_48, primals_51, primals_673, primals_674, getitem_180, convolution_default_63, primals_662, view_default_55, primals_506, primals_64, primals_459, primals_72, primals_458, getitem_304, primals_454, convolution_default_123, primals_77, primals_79, primals_457, primals_464, getitem_303, primals_68, mean_dim_23, view_default_115, primals_75, primals_453, relu__default_97, primals_69, primals_74, _softmax_default_23, primals_465, primals_463, primals_462, primals_67, sum_dim_int_list_47, primals_73, relu__default_51, view_default_119, convolution_default_125, getitem_337, getitem_336, relu__default_108, _softmax_default_26, convolution_default_138, getitem_340, getitem_192, getitem_339, mean_dim_26, view_default_130, getitem_193, relu__default_109, relu__default_60, convolution_default_145, getitem_354, convolution_default_80, sum_dim_int_list_55, primals_210, primals_216, getitem_355, view_default_139, primals_213, relu__default_114, primals_214, convolution_default_146, view_default_74, sum_dim_int_list_29, getitem_357, getitem_202, primals_215, getitem_198, getitem_358, convolution_default_147, relu__default_115, primals_600, relu__default_102, primals_490, primals_627, primals_635, primals_734, primals_497, primals_632, relu__default_62, primals_500, primals_728, convolution_default_116, primals_625, relu__default_90, getitem_319, getitem_318, primals_729, convolution_default_117, primals_599, primals_492, primals_740, getitem_286, primals_489, primals_732, getitem_285, primals_735, primals_631, primals_598, convolution_default_131, relu__default_91, primals_621, primals_629, getitem_322, primals_737, getitem_321, primals_593, getitem_199, primals_739, primals_496, primals_604, primals_502, primals_494, convolution_default_81, relu__default_103, primals_592, getitem_288, primals_594, convolution_default_118, getitem_289, convolution_default_132, primals_491, primals_605, relu__default_92, primals_597, primals_602, primals_626, primals_733, getitem_201, primals_501, primals_624, primals_29, primals_30, sum_dim_int_list_41, primals_171, getitem_271, primals_175, primals_166, primals_25, primals_24, view_default_104, primals_176, convolution_default_110, primals_31, primals_167, primals_177, primals_170, primals_172, primals_28, primals_23, primals_178, getitem_270, _softmax_default_20, primals_848, getitem_388, relu__default_5, primals_847, relu__default_16, relu__default_125, _softmax_default, primals_218, getitem_205, primals_845, convolution_default_97, getitem_21, _softmax_default_30, getitem_22, primals_843, getitem_58, convolution_default_21, primals_225, sum_dim_int_list_1, getitem_57, mean_dim_3, primals_862, sum_dim_int_list_61, view_default_15, convolution_default_7, primals_859, getitem_237, primals_842, avg_pool2d_default_4, primals_221, primals_858, convolution_default_160, relu__default_17, primals_857, primals_856, getitem_390, view_default_4, relu__default_6, convolution_default_8, relu__default_75, view_default_154, primals_224, primals_853, convolution_default_161, sum_dim_int_list_7, getitem_391, primals_226, getitem_238, _softmax_default_3, primals_852, primals_851, convolution_default_82, convolution_default_23, primals_220, getitem_24, view_default_19, avg_pool2d_default, avg_pool2d_default_5, primals_330, getitem_405, _softmax_default_7, getitem_406, primals_338, getitem_109, relu__default_119, primals_329, convolution_default_152, primals_46, primals_756, primals_327, primals_41, primals_247, getitem_108, primals_770, primals_34, primals_254, primals_332, getitem_373, primals_335, getitem_372, primals_47, relu__default_33, primals_248, primals_759, primals_242, relu__default_130, relu__default_120, primals_42, primals_328, convolution_default_167, primals_245, primals_760, primals_772, getitem_375, primals_36, getitem_409, getitem_408, primals_249, primals_764, primals_252, convolution_default_44, primals_241, primals_767, sum_dim_int_list_15, primals_771, convolution_default_153, relu__default_131, primals_766, primals_339, avg_pool2d_default_2, primals_762, primals_39, mean_dim_29, primals_761, view_default_145, convolution_default_168, primals_35, primals_340, getitem_376, primals_44, primals_243, primals_253, primals_40, view_default_39, primals_334, primals_194, getitem_73, view_default_70, getitem_37, convolution_default_75, relu__default_21, primals_197, convolution_default_14, getitem_36, getitem_72, relu__default_10, _softmax_default_4, relu__default_64, getitem_75, getitem_76, primals_83, primals_90, getitem_40, primals_85, sum_dim_int_list_27, getitem_39, convolution_default, sum_dim_int_list_9, primals_518, primals_198, primals_523, relu__default_11, primals_513, convolution_default_29, view_default_69, convolution_default_78, primals_516, convolution_default_15, mean_dim_14, view_default_24, primals_193, relu__default_22, primals_89, primals_519, primals_521, primals_88, primals_84, getitem_42, getitem_43, _softmax_default_13, convolution_default_30, primals_80, primals_512, relu__default_59, primals_517, relu__default_12, primals_199, primals_511, primals_91, getitem_126, getitem_127, getitem_91, getitem_90, primals_895, primals_896, sum_dim_int_list_17, primals_892, relu__default_27, getitem_258, primals_890, convolution_default_50, primals_891, convolution_default_36, _softmax_default_8, primals_900, primals_901, view_default_44, convolution_default_37, getitem_94, relu__default_38, getitem_93, primals_885, primals_884, relu__default_28, convolution_default_51, primals_886, primals_897, view_default_30, primals_889, getitem_129, mean_dim_6, getitem_130, getitem_141, getitem_159, _softmax_default_11, getitem_243, getitem_142, getitem_160, relu__default_43, relu__default_49, convolution_default_57, getitem_174, getitem_241, primals_284, primals_540, primals_539, getitem_145, getitem_144, convolution_default_98, getitem_162, relu__default_76, sum_dim_int_list_23, relu__default_44, primals_289, convolution_default_65, primals_544, view_default_90, primals_285, getitem_163, mean_dim_18, primals_538, view_default_59, primals_286, convolution_default_58, relu__default_50, mean_dim_10, convolution_default_66, primals_545, primals_543, view_default_50, getitem_147, primals_316, primals_311, primals_589, getitem_292, primals_586, primals_307, mean_dim_22, getitem_291, view_default_110, primals_313, primals_581, primals_308, relu__default_93, primals_305, primals_582, _softmax_default_22, primals_583, primals_587, primals_588, convolution_default_120, primals_312, sum_dim_int_list_45, view_default_114, primals_183, primals_566, sum_dim_int_list_37, primals_567, primals_554, primals_561, primals_559, convolution_default_100, primals_555, primals_187, mean_dim_16, primals_562, primals_182, primals_556, getitem_244, primals_565, primals_571, relu__default_77, primals_572, primals_189, primals_577, _softmax_default_18, primals_560, primals_191, primals_188, getitem_217, view_default_80, primals_573, primals_186, primals_575, primals_181, relu__default_68, primals_570, primals_578, primals_161, convolution_default_140, getitem_195, getitem_324, getitem_343, getitem_325, getitem_342, primals_356, _softmax_default_12, relu__default_104, sum_dim_int_list_53, primals_350, relu__default_110, convolution_default_73, convolution_default_133, getitem_196, view_default_134, getitem_328, relu__default_56, view_default_129, primals_160, getitem_327, mean_dim_25, primals_354, primals_357, view_default_125, primals_355, relu__default_53, convolution_default_141, primals_346, relu__default_105, primals_162, view_default_64, primals_351, getitem_345, primals_164, mean_dim_13, getitem_346, view_default_65, sum_dim_int_list_25, sum_dim_int_list_51, primals_344, convolution_default_70, relu__default_111, convolution_default_142, getitem_181, primals_349, convolution_default_135, primals_343, getitem_172, _softmax_default_25, primals_345, getitem_213, getitem_307, getitem_306, primals_323, primals_393, primals_322, convolution_default_9, getitem_25, convolution_default_10, relu__default_67, primals_643, convolution_default_105, primals_397, primals_392, primals_388, relu__default_98, primals_641, getitem_28, primals_636, convolution_default_87, primals_317, getitem_27, getitem_264, getitem_261, convolution_default_126, sum_dim_int_list_39, primals_389, relu__default_83, primals_648, relu__default_7, primals_319, primals_646, getitem_262, getitem_310, primals_318, getitem_309, view_default_99, getitem_214, relu__default_99, primals_642, primals_394, primals_637, getitem_30, convolution_default_127, primals_324, getitem_31, primals_386, primals_647, convolution_default_108, relu__default_8, convolution_default_11, view_default_5, getitem_312, convolution_default_107, primals_640, getitem_313, relu__default_121, getitem_378, getitem_379, getitem_361, getitem_360, primals_548, sum_dim_int_list_59, relu__default_116, getitem_190, convolution_default_155, _softmax_default_29, getitem_187, view_default_149, convolution_default_148, relu__default_122, primals_550, mean_dim_28, getitem_189, view_default_140, getitem_363, convolution_default_156, getitem_186, getitem_364, primals_546, relu__default_117, primals_551, getitem_412, getitem_411, primals_443, getitem_268, primals_438, relu__default_132, getitem_46, convolution_default_16, getitem_45, mean_dim_2, view_default_10, _softmax_default_32, convolution_default_169, primals_452, primals_440, getitem_415, relu__default_13, relu__default_85, primals_448, getitem_2, getitem_414, primals_442, mean_dim_32, primals_451, primals_447, getitem_1, view_default_160, _softmax_default_2, primals_437, relu__default, relu__default_133, primals_446, sum_dim_int_list_5, convolution_default_1, sum_dim_int_list_65, convolution_default_171, convolution_default_18, getitem_267, view_default_14, getitem_4, getitem_148, primals_620, getitem_79, primals_935, getitem_394, relu__default_45, getitem_78, relu__default_126, primals_934, primals_929, _softmax_default_10, getitem_393, relu__default_23, primals_615, getitem_150, getitem_151, primals_619, primals_932, convolution_default_162, convolution_default_31, view_default_75, sum_dim_int_list_21, primals_924, primals_936, mean_dim_5, getitem_82, getitem_397, getitem_81, convolution_default_60, getitem_396, primals_930, primals_609, primals_922, relu__default_24, primals_923, relu__default_127, primals_610, view_default_54, primals_614, relu__default_46, primals_613, convolution_default_163, primals_608, primals_927, convolution_default_32, primals_616, convolution_default_88, convolution_default_61, view_default_25, getitem_399, primals_928, relu__default_34, getitem_111, primals_131, primals_209, getitem_97, getitem_112, relu__default_18, _softmax_default_6, primals_138, getitem_61, getitem_96, getitem_60, avg_pool2d_default_3, convolution_default_45, primals_204, relu__default_29, primals_139, primals_134, convolution_default_83, getitem_115, primals_203, getitem_114, convolution_default_24, primals_202, avg_pool2d_default_1, getitem_64, primals_133, getitem_63, sum_dim_int_list_13, getitem_99, convolution_default_46, primals_208, primals_135, primals_129, getitem_117, convolution_default_25, convolution_default_39, view_default_34, getitem_118, getitem_100, convolution_default_47, primals_205, relu__default_35, relu__default_54, primals_470, relu__default_72, primals_94, convolution_default_93, getitem_265, getitem_178, getitem_175, primals_469, getitem_228, primals_467, primals_95, getitem_229, primals_96, relu__default_84, primals_473, primals_474, convolution_default_71, primals_475, getitem_177, primals_778, primals_486, primals_788, relu__default_39, convolution_default_52, getitem_166, primals_479, getitem_165, convolution_default_112, getitem_274, getitem_133, getitem_132, relu__default_87, relu__default_58, primals_18, primals_783, primals_781, relu__default_40, primals_15, convolution_default_76, primals_10, getitem_135, primals_782, convolution_default_113, primals_11, primals_480, primals_16, getitem_208, getitem_277, primals_478, primals_776, getitem_276, primals_786, primals_17, convolution_default_53, primals_777, relu__default_88, mean_dim_9, primals_484, view_default_45, primals_485, primals_481, primals_787, getitem_136, relu__default_82, view_default_105, mean_dim_21, primals_9, primals_12, primals_775, getitem_225, primals_527, primals_258, primals_534, relu__default_1, primals_532, primals_826, convolution_default_2, primals_825, primals_535, primals_824, relu__default_63, primals_376, getitem_9, primals_263, getitem_5, primals_382, primals_821, getitem_8, convolution_default_86, primals_820, getitem_7, getitem_231, primals_257, getitem_211, primals_533, mean_dim_17, primals_818, relu__default_73, relu__default_2, relu__default_66, primals_373, primals_528, view_default_85, getitem_10, primals_810, getitem_210, primals_262, primals_381, primals_264, primals_377, primals_809, getitem_232, primals_524, primals_813, primals_259, primals_814, primals_265, convolution_default_3, primals_383, primals_815, primals_384, primals_829, primals_816, primals_378, getitem_12, primals_529, _softmax_default_21, getitem_280, primals_751, primals_424, getitem_279, primals_398, getitem_235, primals_399, primals_750, primals_126, primals_404, convolution_default_95, primals_118, primals_400, primals_425, primals_745, primals_128, sum_dim_int_list_35, relu__default_89, primals_744, primals_116, primals_121, primals_749, primals_122, getitem_216, primals_405, relu__default_61, primals_430, view_default_89, primals_123, primals_436, primals_127, primals_432, sum_dim_int_list_33, primals_426, primals_754, _softmax_default_17, sum_dim_int_list_43, primals_117, getitem_183, _softmax_default_16, _softmax_default_15, relu__default_74, primals_755, primals_403, primals_435, getitem_234, primals_431, getitem_282, convolution_default_115, primals_748, convolution_default_96, primals_115, getitem_283, view_default_109, primals_427, primals_743, primals_275, getitem_366, relu__default_100, getitem_367, primals_276, primals_658, primals_273, relu__default_71, primals_280, primals_903, sum_dim_int_list_57, primals_278, primals_651, getitem_316, primals_912, convolution_default_128, convolution_default_150, primals_268, getitem_315, mean_dim_24, _softmax_default_28, primals_653, view_default_120, primals_908, primals_919, view_default_144, getitem_226, relu__default_101, primals_659, primals_656, relu__default_118, primals_916, primals_654, primals_902, primals_918, primals_281, primals_652, convolution_default_151, primals_907, _softmax_default_24, view_default_124, primals_913, convolution_default_130, primals_917, primals_269, primals_911, primals_274, convolution_default_92, getitem_369, primals_270, primals_905, sum_dim_int_list_49, getitem_370]
        
